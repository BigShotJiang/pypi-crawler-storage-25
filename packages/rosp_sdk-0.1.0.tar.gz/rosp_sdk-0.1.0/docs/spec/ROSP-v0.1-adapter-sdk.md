# ROSP v0.1 Adapter SDK Specification

**Version:** 0.1.0
**Status:** Draft
**Date:** 2026-03-25
**License:** Apache 2.0

---

## Table of Contents

1. [Adapter Architecture](#1-adapter-architecture)
2. [Core Interface (Python)](#2-core-interface-python)
3. [TypeScript Interface](#3-typescript-interface)
4. [Adapter Registration](#4-adapter-registration)
5. [Implementing a Minimal Adapter (Tutorial)](#5-implementing-a-minimal-adapter-tutorial)
6. [Testing an Adapter](#6-testing-an-adapter)
7. [Packaging and Distribution](#7-packaging-and-distribution)

---

## 1. Adapter Architecture

### What Is an Adapter?

An adapter is a standalone process (or container) that bridges the ROSP protocol to a robot's native communication interface. It translates between ROSP's standardized API and whatever protocol the robot already speaks -- ROS2/DDS, gRPC, VDA 5050, RTDE, OPC UA, or a proprietary SDK.

An adapter does NOT replace the robot's existing software stack. It runs alongside it, connecting to the robot's native interface as a client. The robot's firmware, controllers, SLAM nodes, planners, and safety systems remain untouched.

### Deployment Topology

```
+------------------+          +-------------------+          +------------------+
|                  |  ROSP    |                   |  Native  |                  |
|  RoboSwarm       |  over    |  Adapter          |  Protocol|  Robot           |
|  Platform        |<-------->|  (rosp-adapter-*)  |<-------->|  Software        |
|                  |  Zenoh   |                   |  (DDS,   |  (ROS2, SDK,     |
|  - Registry      |          |  - describe()     |   gRPC,  |   firmware)      |
|  - Fleet Mgmt    |          |  - stream()       |   REST,  |                  |
|  - Analytics     |          |  - discover()     |   MQTT)  |  - Sensors       |
|  - Dashboard     |          |  - command()      |          |  - Actuators     |
|                  |          |  - health_check() |          |  - Controllers   |
+------------------+          +-------------------+          +------------------+
       ^                              ^                              ^
       |                              |                              |
   Proprietary                  Open-source                   Vendor-specific
   (RoboSwarm)                  (Apache 2.0)                  (unchanged)
```

### Design Principles

1. **Non-invasive.** The adapter connects to the robot's existing interfaces. No firmware changes, no ROS node modifications, no SDK patches required.

2. **One adapter per robot.** Each physical robot has exactly one adapter process. The adapter is the single point of translation between ROSP and that robot.

3. **Adapter owns the Robot Card.** The adapter is the authoritative source for the robot's description (identity, capabilities, sensors, actuators, safety constraints). It constructs and serves the Robot Card.

4. **Two modes of operation.** In v0.1, adapters may operate in:
   - **Description Mode** (required): The adapter exposes `describe()`, `stream()`, `discover()`, and `health_check()`. It provides read-only access to robot data and telemetry.
   - **Control Mode** (optional, DRAFT): The adapter additionally exposes `command()` for sending actions to the robot. Control Mode is marked DRAFT in v0.1 and its interface may change in v0.2.

5. **Transport via Zenoh.** The ROSP-facing side of the adapter communicates over Zenoh. Zenoh was selected for its peer-to-peer design, sub-millisecond LAN latency, built-in QoS, and ability to bridge transparently between LAN and WAN without a broker. The adapter publishes sensor data to Zenoh topics and listens for commands on Zenoh queryables.

6. **Fail-safe defaults.** If the adapter loses connection to the robot, it must report degraded status via `health_check()` and stop publishing stale data. It must NOT fabricate or replay old sensor readings.

### Data Flow

**Sensor data (robot to platform):**

```
Robot sensor  -->  Native topic/API  -->  Adapter  -->  Zenoh pub  -->  Platform
(e.g. /scan)      (e.g. ROS2 topic)     (translate     (ROSP topic)
                                          + compress)
```

**Commands (platform to robot):**

```
Platform  -->  Zenoh queryable  -->  Adapter  -->  Native API  -->  Robot actuator
(action)       (ROSP command)       (translate)   (e.g. ROS2       (execute)
                                                   action client)
```

**Discovery (adapter to platform):**

```
Adapter  -->  Zenoh pub (liveliness)  -->  Platform registry
             + mDNS announcement          (discovers and catalogs)
```

---

## 2. Core Interface (Python)

Every ROSP adapter must subclass `ROSPAdapter` and implement all abstract methods. The base class is provided by the `rosp-sdk` package.

### Data Classes

```python
from abc import ABC, abstractmethod
from typing import AsyncIterator, Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class CommandState(Enum):
    """Lifecycle states for a command execution."""
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"
    PREEMPTED = "preempted"


class AdapterStatus(Enum):
    """Health states for the adapter process."""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    DISCONNECTED = "disconnected"
    ERROR = "error"


class RobotStatus(Enum):
    """Health states for the robot connection."""
    CONNECTED = "connected"
    DEGRADED = "degraded"
    DISCONNECTED = "disconnected"
    ESTOP = "estop"
    UNKNOWN = "unknown"


@dataclass
class RobotCard:
    """Complete robot description. Conforms to robot-card.schema.json.

    The Robot Card is the canonical representation of a robot in the ROSP
    ecosystem. It describes what the robot IS, what it CAN DO, and how to
    interact with it.

    Fields:
        rosp_version: ROSP spec version this card conforms to (e.g., "0.1.0").
        id: Globally unique URN. Format: "urn:rosp:robot:{manufacturer}:{model}:{serial}".
        identity: Human-readable identity (name, manufacturer, model, firmware version).
        hardware: Physical characteristics (dimensions, weight, DOF, payload, battery).
        sensors: List of sensor descriptors with data schemas.
        actuators: List of actuator descriptors with command schemas.
        capabilities: List of high-level capability tags (e.g., "navigation", "manipulation").
        integration: Native protocol info (protocol name, version, endpoint).
        safety: Safety constraints (max speed, geofence, e-stop availability).
        skills: List of executable skill descriptors (Control Mode only).
    """
    rosp_version: str
    id: str
    identity: Dict[str, Any]
    hardware: Dict[str, Any]
    sensors: List[Dict[str, Any]]
    actuators: List[Dict[str, Any]]
    capabilities: List[str]
    integration: Dict[str, Any]
    safety: Dict[str, Any]
    skills: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class StreamQoS:
    """Quality of Service parameters for a sensor stream subscription.

    Fields:
        reliability: "best_effort" for lossy high-frequency data (LiDAR, camera),
                     "reliable" for data that must not be dropped (force/torque, proximity).
        frequency_hz: Desired delivery frequency. The adapter returns the actual
                      achievable frequency in the first StreamMessage metadata.
                      Set to 0 for "as fast as possible".
        compression: "none" for raw data, "lz4" for fast compression (recommended
                     for point clouds), "zstd" for high-ratio compression (recommended
                     for images when H.265 is not used).
        history_depth: Number of most recent messages to buffer. Default 1
                       (only latest). Relevant when subscriber is slower than publisher.
    """
    reliability: str = "best_effort"
    frequency_hz: float = 0
    compression: str = "none"
    history_depth: int = 1


@dataclass
class StreamMessage:
    """A single message from a sensor data stream.

    Fields:
        topic: The ROSP resource path (e.g., "/sensor/lidar/pointcloud").
        seq: Monotonically increasing sequence number per topic. Starts at 0
             when the stream is opened. Gaps indicate dropped messages.
        timestamp: UTC timestamp of when the robot produced the data (not when
                   the adapter forwarded it). Use the robot's clock if available.
        encoding: Data encoding format (e.g., "json", "cbor", "raw").
        data: The sensor payload. Structure depends on sensor type and is
              defined in the Robot Card's sensor schema.
        metadata: Optional per-message metadata (actual_hz, compression_ratio, etc.).
    """
    topic: str
    seq: int
    timestamp: datetime
    encoding: str
    data: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class CommandResult:
    """A status update from a command execution.

    The command lifecycle is:
        ACCEPTED -> IN_PROGRESS (0+ times, with progress) -> COMPLETED | FAILED | PREEMPTED

    A command may also be immediately REJECTED if it violates safety constraints
    or the robot does not support the requested action.

    Fields:
        state: Current lifecycle state.
        progress: Completion fraction [0.0, 1.0]. Only meaningful in IN_PROGRESS state.
        result: Action-specific result payload. Only populated in COMPLETED state.
        error: Error details. Only populated in FAILED or REJECTED states.
                Must include "code" (string) and "message" (string).
        timestamp: When this status update was generated.
    """
    state: CommandState
    progress: Optional[float] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None
    timestamp: Optional[datetime] = None


@dataclass
class DiscoveryInfo:
    """Information broadcast during adapter discovery.

    This is the minimal payload advertised via Zenoh liveliness and/or mDNS
    so that the RoboSwarm platform can find and catalog the robot.

    Fields:
        robot_id: The robot's URN (same as RobotCard.id).
        model: Human-readable model name (e.g., "UR5e").
        manufacturer: Manufacturer name (e.g., "Universal Robots").
        rosp_version: ROSP spec version supported.
        adapter_version: Adapter software version.
        capabilities_summary: List of high-level capability tags.
        endpoint: Zenoh endpoint where the adapter is reachable.
        mode: "description" or "control" indicating adapter capabilities.
    """
    robot_id: str
    model: str
    manufacturer: str
    rosp_version: str
    adapter_version: str
    capabilities_summary: List[str]
    endpoint: str
    mode: str = "description"


@dataclass
class HealthStatus:
    """Adapter and robot health report.

    Fields:
        adapter_status: Current adapter process health.
        robot_status: Current robot connection health.
        latency_ms: Round-trip latency to the robot's native interface, in milliseconds.
                    Measured by the adapter via a lightweight ping or heartbeat.
        uptime_seconds: Seconds since the adapter process started.
        details: Optional dict with adapter-specific diagnostics (CPU, memory,
                 queue depth, dropped message count, etc.).
    """
    adapter_status: AdapterStatus
    robot_status: RobotStatus
    latency_ms: float
    uptime_seconds: float
    details: Optional[Dict[str, Any]] = None
```

### Abstract Base Class

```python
class ROSPAdapter(ABC):
    """Base class for all ROSP robot adapters.

    Implementors must subclass this and provide concrete implementations for
    all abstract methods. The adapter lifecycle is:

        1. Instantiate the adapter with configuration.
        2. Call connect() to establish the native robot connection.
        3. Call describe(), stream(), discover(), health_check() as needed.
        4. Call disconnect() for clean shutdown.

    Control Mode methods (command) have default implementations that raise
    NotImplementedError. Override them only if the adapter supports Control Mode.
    """

    @abstractmethod
    async def describe(self, depth: str = "full") -> RobotCard:
        """Return the robot's complete description as a Robot Card.

        This method must be idempotent and safe to call at any time after
        connect(). The adapter should cache the Robot Card and refresh it
        only when the robot's configuration changes (e.g., a tool is swapped).

        Args:
            depth: Level of detail to return.
                - "summary": Only identity, capabilities list, and integration
                  info. Suitable for fleet overview displays.
                - "full": Complete Robot Card including sensor schemas, actuator
                  schemas, safety constraints, and skills. Required for
                  platform registration.

        Returns:
            A RobotCard instance with all requested fields populated.

        Raises:
            ConnectionError: If the adapter is not connected to the robot.
        """
        ...

    @abstractmethod
    async def stream(
        self, topics: List[str], qos: StreamQoS
    ) -> AsyncIterator[StreamMessage]:
        """Subscribe to one or more sensor data streams.

        Opens subscriptions to the specified ROSP resource paths and yields
        messages as they arrive from the robot. The adapter is responsible for:

        1. Mapping ROSP topic paths to native robot topics/endpoints.
        2. Translating native message formats to ROSP StreamMessage.
        3. Applying the requested QoS (frequency throttling, compression).
        4. Reporting the actual achievable QoS in the first message's metadata.

        The iterator runs indefinitely until the caller breaks out of the
        async for loop or calls aclose() on the iterator.

        Args:
            topics: List of ROSP resource paths to subscribe to.
                Examples: ["/sensor/lidar/pointcloud"],
                          ["/sensor/camera/rgb", "/sensor/imu/data"],
                          ["/sensor/joint_states"].
                Use describe() to discover available topics.

            qos: Quality of service parameters for the subscription.

        Yields:
            StreamMessage for each sensor reading, across all subscribed topics.
            Messages from different topics may be interleaved.

        Raises:
            ValueError: If any topic in the list is not available on this robot.
            ConnectionError: If the adapter is not connected to the robot.
        """
        ...

    @abstractmethod
    async def discover(self) -> DiscoveryInfo:
        """Return discovery information for this robot.

        Called by the ROSP SDK to generate the discovery payload that is
        broadcast via Zenoh liveliness tokens and (optionally) mDNS.

        This method must return quickly (< 100 ms) as it may be called
        periodically for heartbeat purposes.

        Returns:
            DiscoveryInfo with all required fields populated.
        """
        ...

    # --- Control Mode (DRAFT — interface may change in v0.2) ---

    async def command(
        self,
        action: str,
        params: Dict[str, Any],
        timeout_ms: int = 30000,
    ) -> AsyncIterator[CommandResult]:
        """Send a command to the robot and stream execution status.

        DRAFT: This method is part of Control Mode, which is optional in v0.1
        and whose interface may change in v0.2. Adapters that only support
        Description Mode should not override this method.

        The command lifecycle is:
            1. Adapter validates the action and params against the robot's skills.
            2. If valid, yields ACCEPTED.
            3. Translates the action to native robot commands.
            4. Yields IN_PROGRESS with progress updates as the robot executes.
            5. Yields COMPLETED (with result) or FAILED (with error) on finish.

        A command may be REJECTED immediately if:
            - The action is not in the robot's skill list.
            - The params fail validation.
            - Safety constraints would be violated.

        A command may be PREEMPTED if:
            - A higher-priority command is received.
            - An emergency stop is triggered.
            - The caller explicitly cancels.

        Args:
            action: The skill/action to execute. Must match a skill name from
                    the Robot Card's skills list (e.g., "navigate", "pick", "home").
            params: Action-specific parameters. Schema is defined in the
                    Robot Card's skill descriptor for this action.
            timeout_ms: Maximum wall-clock time for the command to complete.
                        If exceeded, the adapter must abort the action on the
                        robot and yield FAILED with error code "timeout".
                        Default: 30000 ms (30 seconds).

        Yields:
            CommandResult updates through the lifecycle.

        Raises:
            NotImplementedError: If the adapter only supports Description Mode.
        """
        raise NotImplementedError(
            f"Control Mode not supported by this adapter. "
            f"Action '{action}' cannot be executed."
        )

    # --- Lifecycle ---

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the robot's native interface.

        This method must:
            1. Connect to the robot's native endpoint (e.g., rosbridge, gRPC).
            2. Verify the connection is functional (e.g., read a known topic).
            3. Return only after the connection is confirmed.

        If the connection cannot be established, raise ConnectionError with
        a descriptive message including the native endpoint URL.

        The adapter must handle reconnection internally. If the native
        connection drops after connect() returns, the adapter should attempt
        to reconnect automatically and report DEGRADED status via health_check()
        until the connection is restored.

        Raises:
            ConnectionError: If the initial connection cannot be established.
            TimeoutError: If the connection attempt exceeds a reasonable timeout.
        """
        ...

    @abstractmethod
    async def disconnect(self) -> None:
        """Cleanly disconnect from the robot.

        This method must:
            1. Stop all active sensor stream subscriptions.
            2. Abort any in-progress commands (if Control Mode is supported).
            3. Close the native connection to the robot.
            4. Release all resources (sockets, threads, file handles).

        After disconnect(), the adapter is in a stopped state. Calling any
        method other than connect() must raise ConnectionError.

        This method must not raise exceptions. If the native connection is
        already lost, disconnect() should clean up local resources silently.
        """
        ...

    @abstractmethod
    async def health_check(self) -> HealthStatus:
        """Return the current health status of the adapter and robot connection.

        This method must return quickly (< 50 ms). It should not perform
        expensive operations. The adapter should maintain health metrics
        internally and return the latest snapshot.

        The adapter must measure latency by periodically pinging the robot's
        native interface (e.g., reading a lightweight topic, calling a no-op
        service). The latency_ms field reflects the most recent measurement.

        Returns:
            HealthStatus with current adapter and robot state.
        """
        ...
```

### Method Summary

| Method | Mode | Required | Returns | Purpose |
|--------|------|----------|---------|---------|
| `describe()` | Description | Yes | `RobotCard` | What is this robot? |
| `stream()` | Description | Yes | `AsyncIterator[StreamMessage]` | Subscribe to sensor data |
| `discover()` | Description | Yes | `DiscoveryInfo` | Advertise on the network |
| `health_check()` | Description | Yes | `HealthStatus` | Is everything working? |
| `command()` | Control | No | `AsyncIterator[CommandResult]` | Send actions to the robot |
| `connect()` | Lifecycle | Yes | `None` | Open native connection |
| `disconnect()` | Lifecycle | Yes | `None` | Close native connection |

---

## 3. TypeScript Interface

The TypeScript interface is equivalent to the Python ABC. Adapter developers targeting Node.js or Deno environments implement this interface.

```typescript
// rosp-sdk/types.ts

/** Lifecycle states for a command execution. */
type CommandState =
  | "accepted"
  | "in_progress"
  | "completed"
  | "failed"
  | "rejected"
  | "preempted";

/** Health states for the adapter process. */
type AdapterStatus = "healthy" | "degraded" | "disconnected" | "error";

/** Health states for the robot connection. */
type RobotStatus = "connected" | "degraded" | "disconnected" | "estop" | "unknown";

/** Complete robot description conforming to robot-card.schema.json. */
interface RobotCard {
  rosp_version: string;
  id: string;
  identity: {
    name: string;
    manufacturer: string;
    model: string;
    firmware_version?: string;
    [key: string]: unknown;
  };
  hardware: Record<string, unknown>;
  sensors: SensorDescriptor[];
  actuators: ActuatorDescriptor[];
  capabilities: string[];
  integration: {
    protocol: string;
    protocol_version?: string;
    native_endpoint: string;
    [key: string]: unknown;
  };
  safety: Record<string, unknown>;
  skills: SkillDescriptor[];
}

interface SensorDescriptor {
  id: string;
  type: string;
  topic: string;
  frequency_hz: number;
  data_schema: Record<string, unknown>;
  [key: string]: unknown;
}

interface ActuatorDescriptor {
  id: string;
  type: string;
  command_schema: Record<string, unknown>;
  [key: string]: unknown;
}

interface SkillDescriptor {
  name: string;
  description: string;
  params_schema: Record<string, unknown>;
  result_schema?: Record<string, unknown>;
  [key: string]: unknown;
}

/** Quality of Service parameters for a sensor stream subscription. */
interface StreamQoS {
  reliability: "best_effort" | "reliable";
  frequency_hz: number;
  compression: "none" | "lz4" | "zstd";
  history_depth?: number;
}

/** A single message from a sensor data stream. */
interface StreamMessage {
  topic: string;
  seq: number;
  timestamp: string; // ISO-8601 UTC
  encoding: string;
  data: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

/** A status update from a command execution. */
interface CommandResult {
  state: CommandState;
  progress?: number;
  result?: Record<string, unknown>;
  error?: { code: string; message: string; [key: string]: unknown };
  timestamp?: string; // ISO-8601 UTC
}

/** Discovery payload broadcast by the adapter. */
interface DiscoveryInfo {
  robot_id: string;
  model: string;
  manufacturer: string;
  rosp_version: string;
  adapter_version: string;
  capabilities_summary: string[];
  endpoint: string;
  mode: "description" | "control";
}

/** Adapter and robot health report. */
interface HealthStatus {
  adapter_status: AdapterStatus;
  robot_status: RobotStatus;
  latency_ms: number;
  uptime_seconds: number;
  details?: Record<string, unknown>;
}

// --- Adapter Interface ---

/**
 * The interface every ROSP adapter must implement.
 *
 * `command` is optional — omit it for Description Mode adapters.
 */
interface ROSPAdapter {
  /**
   * Return the robot's complete description as a Robot Card.
   * @param depth - "summary" for overview, "full" for complete card.
   */
  describe(depth?: "summary" | "full"): Promise<RobotCard>;

  /**
   * Subscribe to sensor data streams.
   * @param topics - ROSP resource paths to subscribe to.
   * @param qos - Quality of service parameters.
   * @returns An async iterable yielding StreamMessage objects.
   */
  stream(topics: string[], qos: StreamQoS): AsyncIterable<StreamMessage>;

  /**
   * Return discovery information for network advertisement.
   */
  discover(): Promise<DiscoveryInfo>;

  /**
   * Send a command to the robot (Control Mode, DRAFT).
   * Optional — omit for Description Mode adapters.
   * @param action - Skill name to execute.
   * @param params - Action-specific parameters.
   * @param timeoutMs - Max execution time in milliseconds.
   */
  command?(
    action: string,
    params: Record<string, unknown>,
    timeoutMs?: number
  ): AsyncIterable<CommandResult>;

  /**
   * Establish connection to the robot's native interface.
   */
  connect(): Promise<void>;

  /**
   * Cleanly disconnect from the robot.
   */
  disconnect(): Promise<void>;

  /**
   * Return current adapter and robot health status.
   */
  healthCheck(): Promise<HealthStatus>;
}

export type {
  ROSPAdapter,
  RobotCard,
  StreamQoS,
  StreamMessage,
  CommandResult,
  DiscoveryInfo,
  HealthStatus,
  SensorDescriptor,
  ActuatorDescriptor,
  SkillDescriptor,
  CommandState,
  AdapterStatus,
  RobotStatus,
};
```

---

## 4. Adapter Registration

When an adapter starts, it must register itself with the ROSP platform so the platform can discover it, catalog the robot, and route requests to it. Registration has two parts: a static configuration file and a runtime discovery protocol.

### 4.1 Configuration File

Every adapter ships with a YAML configuration file. The file path defaults to `/etc/rosp/adapter.yaml` but can be overridden via the `ROSP_ADAPTER_CONFIG` environment variable.

```yaml
# /etc/rosp/adapter.yaml

adapter:
  # Human-readable adapter name. Must match the pip package name.
  name: "rosp-adapter-ros2"

  # Adapter software version. Follows semver.
  version: "0.1.0"

  # The native protocol this adapter bridges to.
  protocol: "ros2"

  # Transport used on the ROSP-facing side.
  transport: "zenoh"

  # Zenoh endpoint where the adapter listens for ROSP requests.
  # The platform connects to this endpoint.
  endpoint: "zenoh://192.168.1.50:7447"

  # Zenoh configuration overrides (optional).
  zenoh:
    # Peers to connect to (e.g., a Zenoh router for WAN bridging).
    connect: []
    # Listen addresses.
    listen:
      - "tcp/0.0.0.0:7447"
    # Shared memory for local high-bandwidth streams (e.g., point clouds).
    shared_memory: true

robot:
  # Globally unique robot URN.
  # Format: urn:rosp:robot:{manufacturer}:{model}:{serial}
  id: "urn:rosp:robot:universal-robots:ur5e:ABC123"

  # How the adapter connects to the robot's native interface.
  native_endpoint: "ros2://localhost"

  # Native protocol-specific configuration.
  native_config:
    # ROS2-specific: DDS domain ID.
    domain_id: 0
    # ROS2-specific: namespace prefix for this robot's topics.
    namespace: "/ur5e"

auth:
  # Authentication method for ROSP platform communication.
  # Options: "mtls", "token", "none" (development only).
  method: "mtls"

  # mTLS certificate paths.
  cert_path: "/etc/rosp/certs/adapter.pem"
  key_path: "/etc/rosp/certs/adapter.key"
  ca_path: "/etc/rosp/certs/ca.pem"

logging:
  # Log level: "debug", "info", "warning", "error".
  level: "info"

  # Log output: "stdout", "file", "both".
  output: "stdout"

  # Log file path (when output is "file" or "both").
  file: "/var/log/rosp/adapter.log"
```

### 4.2 Runtime Discovery Protocol

When the adapter starts and calls `connect()`, it performs the following registration sequence:

1. **Zenoh liveliness token.** The adapter declares a Zenoh liveliness token at the key `rosp/{robot_id}/alive`. The platform subscribes to `rosp/*/alive` to detect adapters joining and leaving the network. The token is automatically removed if the adapter process crashes.

2. **Discovery publication.** The adapter publishes its `DiscoveryInfo` payload to the Zenoh key `rosp/{robot_id}/discovery` with `TRANSIENT_LOCAL` durability so that late-joining platform instances receive it.

3. **mDNS announcement (optional).** For LAN discovery without a Zenoh router, the adapter may announce itself via mDNS with service type `_rosp._tcp`. The TXT record contains `robot_id`, `rosp_version`, and `endpoint`.

4. **Health heartbeat.** The adapter publishes its `HealthStatus` to `rosp/{robot_id}/health` every 5 seconds. If the platform does not receive a heartbeat for 15 seconds, it marks the robot as unreachable.

### 4.3 Zenoh Key Space Convention

All ROSP communication uses the following Zenoh key hierarchy:

```
rosp/{robot_id}/alive                          # Liveliness token
rosp/{robot_id}/discovery                      # DiscoveryInfo (TRANSIENT_LOCAL)
rosp/{robot_id}/health                         # HealthStatus (periodic)
rosp/{robot_id}/card                           # RobotCard (TRANSIENT_LOCAL)
rosp/{robot_id}/stream/{sensor_topic}          # Sensor data streams
rosp/{robot_id}/command/{action}               # Command requests (queryable)
rosp/{robot_id}/command/{action}/{cmd_id}/status  # Command status updates
```

Where `{robot_id}` is the URN with colons replaced by slashes for Zenoh compatibility. Example: `urn:rosp:robot:universal-robots:ur5e:ABC123` becomes `universal-robots/ur5e/ABC123`.

---

## 5. Implementing a Minimal Adapter (Tutorial)

This tutorial walks through building a Description Mode adapter for a ROS2 robot. The adapter connects to ROS2 via `rclpy` (the ROS2 Python client library), reads the robot's URDF and topic list, and exposes them through the ROSP interface.

### Prerequisites

- ROS2 Humble or later installed
- A ROS2 robot simulation running (e.g., TurtleBot3 in Gazebo)
- Python 3.10+
- `pip install rosp-sdk rclpy`

### Full Implementation

```python
"""
rosp-adapter-ros2: Minimal ROSP adapter for ROS2 robots (Description Mode).

Connects to a ROS2 system via rclpy, introspects available topics and
parameters, and exposes them through the ROSP Adapter interface.

Usage:
    python adapter_ros2.py --config /etc/rosp/adapter.yaml
"""

import asyncio
import time
from datetime import datetime, timezone
from typing import AsyncIterator, Dict, Any, List, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
import yaml

from rosp_sdk import (
    ROSPAdapter,
    RobotCard,
    StreamQoS,
    StreamMessage,
    DiscoveryInfo,
    HealthStatus,
    AdapterStatus,
    RobotStatus,
)


class ROS2Adapter(ROSPAdapter):
    """ROSP adapter for ROS2 robots.

    Connects to the local ROS2 network via rclpy, introspects topics,
    and translates sensor data into ROSP StreamMessages.
    """

    def __init__(self, config_path: str):
        with open(config_path, "r") as f:
            self.config = yaml.safe_load(f)

        self._node: Optional[Node] = None
        self._start_time: float = time.monotonic()
        self._connected: bool = False
        self._subscriptions: Dict[str, Any] = {}

        # Extract config values.
        self._robot_id = self.config["robot"]["id"]
        self._namespace = self.config["robot"].get("native_config", {}).get(
            "namespace", ""
        )
        self._domain_id = self.config["robot"].get("native_config", {}).get(
            "domain_id", 0
        )

    # ---- Lifecycle ----

    async def connect(self) -> None:
        """Initialize rclpy and create the adapter node."""
        rclpy.init(domain_id=self._domain_id)
        self._node = Node(
            "rosp_adapter",
            namespace=self._namespace,
        )
        self._connected = True
        self._start_time = time.monotonic()

        # Verify connection by checking that at least one topic exists.
        topics = self._node.get_topic_names_and_types()
        if not topics:
            raise ConnectionError(
                f"No ROS2 topics found on domain {self._domain_id}. "
                f"Is a robot running?"
            )

    async def disconnect(self) -> None:
        """Destroy the node and shut down rclpy."""
        self._connected = False
        for sub in self._subscriptions.values():
            self._node.destroy_subscription(sub)
        self._subscriptions.clear()

        if self._node is not None:
            self._node.destroy_node()
            self._node = None
        rclpy.shutdown()

    async def health_check(self) -> HealthStatus:
        """Check ROS2 connectivity by listing topics."""
        if not self._connected or self._node is None:
            return HealthStatus(
                adapter_status=AdapterStatus.DISCONNECTED,
                robot_status=RobotStatus.DISCONNECTED,
                latency_ms=0.0,
                uptime_seconds=time.monotonic() - self._start_time,
            )

        t0 = time.monotonic()
        try:
            topics = self._node.get_topic_names_and_types()
            latency_ms = (time.monotonic() - t0) * 1000
            return HealthStatus(
                adapter_status=AdapterStatus.HEALTHY,
                robot_status=(
                    RobotStatus.CONNECTED if topics else RobotStatus.DEGRADED
                ),
                latency_ms=latency_ms,
                uptime_seconds=time.monotonic() - self._start_time,
                details={"topic_count": len(topics)},
            )
        except Exception as e:
            return HealthStatus(
                adapter_status=AdapterStatus.ERROR,
                robot_status=RobotStatus.UNKNOWN,
                latency_ms=0.0,
                uptime_seconds=time.monotonic() - self._start_time,
                details={"error": str(e)},
            )

    # ---- Description Mode ----

    async def describe(self, depth: str = "full") -> RobotCard:
        """Build a Robot Card by introspecting the ROS2 system."""
        self._require_connected()

        topics = self._node.get_topic_names_and_types()

        # Build sensor list from published topics.
        sensors = []
        for topic_name, topic_types in topics:
            sensors.append(
                {
                    "id": topic_name.replace("/", "_").strip("_"),
                    "type": self._classify_sensor(topic_name, topic_types),
                    "topic": topic_name,
                    "frequency_hz": 0,  # Unknown until subscribed.
                    "data_schema": {
                        "ros2_type": topic_types[0] if topic_types else "unknown"
                    },
                }
            )

        # Try to read robot_description parameter for hardware info.
        hardware = {}
        try:
            urdf = (
                self._node.get_parameter("robot_description")
                .get_parameter_value()
                .string_value
            )
            hardware["urdf_available"] = True
            hardware["urdf_length_bytes"] = len(urdf)
        except Exception:
            hardware["urdf_available"] = False

        card = RobotCard(
            rosp_version="0.1.0",
            id=self._robot_id,
            identity={
                "name": self.config["robot"].get("name", "ROS2 Robot"),
                "manufacturer": "unknown",
                "model": "unknown",
                "firmware_version": "unknown",
            },
            hardware=hardware,
            sensors=sensors if depth == "full" else [],
            actuators=[],
            capabilities=self._infer_capabilities(topics),
            integration={
                "protocol": "ros2",
                "native_endpoint": self.config["robot"]["native_endpoint"],
                "domain_id": self._domain_id,
                "namespace": self._namespace,
            },
            safety={
                "estop_available": False,
                "max_speed_m_s": None,
                "geofence": None,
            },
            skills=[],
        )
        return card

    async def stream(
        self, topics: List[str], qos: StreamQoS
    ) -> AsyncIterator[StreamMessage]:
        """Subscribe to ROS2 topics and yield ROSP StreamMessages."""
        self._require_connected()

        queue: asyncio.Queue[StreamMessage] = asyncio.Queue(maxsize=100)
        seq_counters: Dict[str, int] = {t: 0 for t in topics}

        # Map QoS.
        ros_qos = QoSProfile(depth=qos.history_depth)
        if qos.reliability == "reliable":
            ros_qos.reliability = ReliabilityPolicy.RELIABLE
        else:
            ros_qos.reliability = ReliabilityPolicy.BEST_EFFORT
        ros_qos.history = HistoryPolicy.KEEP_LAST

        def make_callback(topic: str):
            def callback(msg):
                seq = seq_counters[topic]
                seq_counters[topic] = seq + 1
                stream_msg = StreamMessage(
                    topic=topic,
                    seq=seq,
                    timestamp=datetime.now(timezone.utc),
                    encoding="json",
                    data=self._ros_msg_to_dict(msg),
                    metadata={
                        "ros2_type": type(msg).__module__ + "/" + type(msg).__name__
                    },
                )
                try:
                    queue.put_nowait(stream_msg)
                except asyncio.QueueFull:
                    pass  # Drop oldest-style: best-effort delivery.

            return callback

        # Subscribe to each requested topic.
        available = dict(self._node.get_topic_names_and_types())
        for topic in topics:
            if topic not in available:
                raise ValueError(
                    f"Topic '{topic}' not available. "
                    f"Available: {list(available.keys())}"
                )
            msg_type = self._resolve_msg_type(available[topic][0])
            sub = self._node.create_subscription(
                msg_type, topic, make_callback(topic), ros_qos
            )
            self._subscriptions[topic] = sub

        # Yield messages from the queue.
        try:
            while self._connected:
                try:
                    msg = await asyncio.wait_for(queue.get(), timeout=1.0)
                    yield msg
                except asyncio.TimeoutError:
                    continue
        finally:
            for topic in topics:
                if topic in self._subscriptions:
                    self._node.destroy_subscription(self._subscriptions.pop(topic))

    async def discover(self) -> DiscoveryInfo:
        """Return discovery payload for this adapter."""
        return DiscoveryInfo(
            robot_id=self._robot_id,
            model=self.config["robot"].get("name", "ROS2 Robot"),
            manufacturer="unknown",
            rosp_version="0.1.0",
            adapter_version=self.config["adapter"]["version"],
            capabilities_summary=self._infer_capabilities(
                self._node.get_topic_names_and_types() if self._node else []
            ),
            endpoint=self.config["adapter"]["endpoint"],
            mode="description",
        )

    # ---- Private Helpers ----

    def _require_connected(self) -> None:
        if not self._connected or self._node is None:
            raise ConnectionError("Adapter is not connected. Call connect() first.")

    @staticmethod
    def _classify_sensor(topic_name: str, topic_types: list) -> str:
        """Infer sensor type from the ROS2 topic name and message type."""
        type_str = topic_types[0].lower() if topic_types else ""
        name = topic_name.lower()
        if "lidar" in name or "scan" in name or "pointcloud" in type_str:
            return "lidar"
        if "camera" in name or "image" in type_str:
            return "camera"
        if "imu" in name or "imu" in type_str:
            return "imu"
        if "odom" in name:
            return "odometry"
        if "joint" in name:
            return "joint_state"
        if "cmd_vel" in name or "twist" in type_str:
            return "velocity_command"
        return "unknown"

    @staticmethod
    def _infer_capabilities(topics: list) -> List[str]:
        """Infer robot capabilities from its ROS2 topic list."""
        caps = set()
        for name, types in topics:
            name_lower = name.lower()
            if "scan" in name_lower or "lidar" in name_lower:
                caps.add("perception:lidar")
            if "camera" in name_lower or "image" in name_lower:
                caps.add("perception:camera")
            if "odom" in name_lower:
                caps.add("navigation:odometry")
            if "cmd_vel" in name_lower:
                caps.add("navigation:velocity_control")
            if "map" in name_lower:
                caps.add("navigation:mapping")
            if "joint" in name_lower:
                caps.add("manipulation:joint_control")
        return sorted(caps)

    @staticmethod
    def _ros_msg_to_dict(msg) -> Dict[str, Any]:
        """Convert a ROS2 message to a plain dict.

        Uses the message's __slots__ and get_fields_and_field_types() if
        available, falling back to a simple attribute scan.
        """
        result = {}
        if hasattr(msg, "get_fields_and_field_types"):
            for field_name in msg.get_fields_and_field_types():
                value = getattr(msg, field_name)
                if hasattr(value, "get_fields_and_field_types"):
                    result[field_name] = ROS2Adapter._ros_msg_to_dict(value)
                elif isinstance(value, (list, tuple)):
                    result[field_name] = [
                        ROS2Adapter._ros_msg_to_dict(v)
                        if hasattr(v, "get_fields_and_field_types")
                        else v
                        for v in value
                    ]
                else:
                    result[field_name] = value
        return result

    @staticmethod
    def _resolve_msg_type(type_str: str):
        """Dynamically import a ROS2 message type from its string name.

        Args:
            type_str: Fully qualified ROS2 type (e.g., "sensor_msgs/msg/LaserScan").

        Returns:
            The message class.
        """
        parts = type_str.split("/")
        if len(parts) == 3:
            package, interface, name = parts
        elif len(parts) == 2:
            package, name = parts
            interface = "msg"
        else:
            raise ValueError(f"Cannot parse ROS2 message type: {type_str}")

        module = __import__(f"{package}.{interface}", fromlist=[name])
        return getattr(module, name)


# ---- Entry Point ----

async def main():
    import argparse

    parser = argparse.ArgumentParser(description="ROSP ROS2 Adapter")
    parser.add_argument(
        "--config",
        default="/etc/rosp/adapter.yaml",
        help="Path to adapter configuration file.",
    )
    args = parser.parse_args()

    adapter = ROS2Adapter(args.config)

    try:
        print("[rosp-adapter-ros2] Connecting to ROS2...")
        await adapter.connect()
        print("[rosp-adapter-ros2] Connected.")

        # Print the Robot Card.
        card = await adapter.describe()
        print(f"[rosp-adapter-ros2] Robot: {card.id}")
        print(f"[rosp-adapter-ros2] Sensors: {len(card.sensors)}")
        print(f"[rosp-adapter-ros2] Capabilities: {card.capabilities}")

        # Print discovery info.
        info = await adapter.discover()
        print(f"[rosp-adapter-ros2] Discovery endpoint: {info.endpoint}")

        # Run health checks in a loop.
        while True:
            health = await adapter.health_check()
            print(
                f"[rosp-adapter-ros2] Health: adapter={health.adapter_status.value}, "
                f"robot={health.robot_status.value}, "
                f"latency={health.latency_ms:.1f}ms"
            )
            await asyncio.sleep(5)
    except KeyboardInterrupt:
        pass
    finally:
        print("[rosp-adapter-ros2] Disconnecting...")
        await adapter.disconnect()
        print("[rosp-adapter-ros2] Stopped.")


if __name__ == "__main__":
    asyncio.run(main())
```

### What This Adapter Does

1. **`connect()`** initializes `rclpy`, creates a ROS2 node, and verifies at least one topic is visible.
2. **`describe()`** introspects all ROS2 topics, classifies them by sensor type, checks for a URDF via the `robot_description` parameter, and assembles a Robot Card.
3. **`stream()`** creates ROS2 subscriptions on the requested topics, converts incoming ROS2 messages to `StreamMessage` dicts, and yields them through an async queue.
4. **`discover()`** returns a static discovery payload built from the configuration and introspected capabilities.
5. **`health_check()`** measures the time to list ROS2 topics as a connectivity/latency proxy.
6. **`command()`** is not overridden, so it raises `NotImplementedError` (Description Mode only).

### What This Adapter Does NOT Do (Left for v0.2+)

- It does not publish to Zenoh. In production, the `rosp-sdk` runtime wraps the adapter and handles Zenoh publication. The adapter author only implements the `ROSPAdapter` interface.
- It does not implement mDNS announcement. The SDK runtime handles this.
- It does not implement authentication. The SDK runtime handles mTLS on the Zenoh connection.

---

## 6. Testing an Adapter

Every adapter must pass the ROSP conformance test suite before it can be listed in the RoboSwarm registry. The test suite is provided by the `rosp-sdk[test]` package.

### 6.1 Running the Tests

```bash
# Install the test dependencies.
pip install rosp-sdk[test]

# Run the conformance suite against your adapter.
rosp-test --adapter your_adapter_module:YourAdapterClass --config adapter.yaml

# Run with verbose output.
rosp-test --adapter your_adapter_module:YourAdapterClass --config adapter.yaml -v

# Run only Description Mode tests (skip Control Mode).
rosp-test --adapter your_adapter_module:YourAdapterClass --config adapter.yaml --mode description
```

The test runner instantiates your adapter, calls `connect()`, runs all applicable tests, and calls `disconnect()`. It requires a real or simulated robot to be running.

### 6.2 Required Tests (Description Mode)

These tests MUST pass for an adapter to be ROSP-compliant.

#### `test_describe_returns_valid_robot_card`

Calls `describe(depth="full")` and validates the returned `RobotCard` against `robot-card.schema.json`.

Checks:
- `rosp_version` is a valid semver string matching "0.1.*".
- `id` matches the URN format `urn:rosp:robot:{manufacturer}:{model}:{serial}`.
- `identity` contains `name`, `manufacturer`, and `model` (all non-empty strings).
- `sensors` is a list; each entry has `id`, `type`, `topic`, and `data_schema`.
- `capabilities` is a non-empty list of strings.
- `integration` contains `protocol` and `native_endpoint`.
- `safety` is present (may be empty dict, but must exist).

#### `test_describe_summary_mode`

Calls `describe(depth="summary")` and verifies:
- Response returns in under 500 ms.
- `identity` and `capabilities` are populated.
- `sensors` may be empty (summary does not require full sensor schemas).

#### `test_stream_delivers_data`

Picks the first sensor topic from the Robot Card, subscribes to it with default QoS, and asserts:
- At least one `StreamMessage` is received within 10 seconds.
- The message has a valid `topic`, `seq >= 0`, `timestamp`, and non-empty `data`.
- The `topic` field matches the subscribed topic.

#### `test_stream_multiple_topics`

Subscribes to two or more sensor topics simultaneously and verifies messages are received from each topic within 10 seconds. This confirms the adapter can multiplex multiple streams.

#### `test_stream_invalid_topic`

Calls `stream()` with a non-existent topic and asserts that `ValueError` is raised.

#### `test_discover_returns_required_fields`

Calls `discover()` and validates:
- `robot_id` matches the robot's URN from describe().
- `rosp_version` is present and matches "0.1.*".
- `capabilities_summary` is a non-empty list.
- `endpoint` is a non-empty string.
- `mode` is either "description" or "control".

#### `test_health_check_reports_status`

Calls `health_check()` and validates:
- `adapter_status` is a valid `AdapterStatus` value.
- `robot_status` is a valid `RobotStatus` value.
- `latency_ms` is a non-negative number.
- `uptime_seconds` is a positive number.
- Response returns in under 100 ms.

#### `test_health_check_after_disconnect`

Calls `disconnect()`, then attempts `health_check()` and verifies the adapter reports `DISCONNECTED` status (or raises `ConnectionError`).

#### `test_qos_negotiation`

Subscribes with a specific QoS (e.g., `frequency_hz=10`, `reliability="reliable"`) and checks:
- The first `StreamMessage.metadata` contains an `actual_hz` field.
- If the adapter cannot match the requested frequency, the `actual_hz` reflects the real rate.
- The adapter does not crash or silently ignore QoS parameters.

#### `test_lifecycle_connect_disconnect`

Verifies:
- `connect()` succeeds and the adapter is functional.
- `disconnect()` completes without error.
- After disconnect, calling `describe()` raises `ConnectionError`.
- `connect()` can be called again after `disconnect()` (adapter is reusable).

### 6.3 Optional Tests (Control Mode)

These tests apply only to adapters that override `command()`. They are skipped if `command()` raises `NotImplementedError`.

#### `test_command_lifecycle`

Sends a known-valid command (using a skill from the Robot Card) and asserts:
- First yield is `CommandState.ACCEPTED`.
- At least one `CommandState.IN_PROGRESS` yield occurs (with `progress` between 0.0 and 1.0).
- Final yield is `CommandState.COMPLETED` with a non-None `result`.

#### `test_command_rejected_invalid_action`

Sends a command with an action name not in the Robot Card's skills and asserts:
- Yield is `CommandState.REJECTED` with an `error` containing `code` and `message`.

#### `test_command_rejected_invalid_params`

Sends a command with a valid action but invalid parameters and asserts:
- Yield is `CommandState.REJECTED` with a validation error.

#### `test_command_timeout`

Sends a command with `timeout_ms=1` (effectively immediate timeout) and asserts:
- The adapter yields `CommandState.FAILED` with `error.code == "timeout"`.
- The command does not continue executing after the timeout.

#### `test_command_preemption`

Sends a long-running command, then sends a second command to the same action and asserts:
- The first command yields `CommandState.PREEMPTED`.
- The second command proceeds through the normal lifecycle.

### 6.4 Performance Benchmarks (Informational)

These benchmarks are not pass/fail but are reported in the conformance results. They help adapter developers and platform operators understand performance characteristics.

| Benchmark | What It Measures | Target |
|-----------|-----------------|--------|
| `bench_describe_latency` | Time to return a full Robot Card | < 500 ms |
| `bench_stream_first_message` | Time from subscribe to first message | < 2 s |
| `bench_stream_throughput` | Messages per second at max rate | Report only |
| `bench_stream_latency` | End-to-end latency (robot timestamp to receive) | Report only |
| `bench_health_check_latency` | Time to return health status | < 100 ms |
| `bench_command_round_trip` | Time from send to ACCEPTED | < 500 ms |

---

## 7. Packaging and Distribution

### 7.1 Package Naming

All ROSP adapters follow the naming convention:

```
rosp-adapter-{protocol}
```

Where `{protocol}` is the native robot protocol the adapter bridges to. Examples:

| Package Name | Protocol | Target Robots |
|-------------|----------|---------------|
| `rosp-adapter-ros2` | ROS2 / DDS | Any ROS2 robot (TurtleBot, UR, Clearpath, etc.) |
| `rosp-adapter-grpc` | gRPC | Boston Dynamics Spot, Viam-connected robots |
| `rosp-adapter-vda5050` | VDA 5050 | Warehouse AMRs (MiR, Kollmorgen, Seegrid) |
| `rosp-adapter-rtde` | RTDE | Universal Robots (direct, no ROS2) |
| `rosp-adapter-opcua` | OPC UA | Industrial robots (FANUC, KUKA, ABB) |

For vendor-specific adapters that target a single robot model:

```
rosp-adapter-{vendor}-{model}
```

Example: `rosp-adapter-unitree-go2`, `rosp-adapter-spot`.

### 7.2 Python Package Structure

```
rosp-adapter-ros2/
    pyproject.toml
    README.md
    LICENSE                         # Apache 2.0
    src/
        rosp_adapter_ros2/
            __init__.py
            adapter.py              # ROSPAdapter subclass
            config.py               # Config loading and validation
            ros2_bridge.py          # Native ROS2 connection logic
            msg_convert.py          # ROS2 message -> ROSP dict conversion
    tests/
        conftest.py
        test_adapter.py             # Adapter-specific unit tests
    config/
        adapter.yaml.example        # Example configuration
    Dockerfile                      # Container deployment
```

### 7.3 pyproject.toml

```toml
[project]
name = "rosp-adapter-ros2"
version = "0.1.0"
description = "ROSP adapter for ROS2 robots"
license = {text = "Apache-2.0"}
requires-python = ">=3.10"
dependencies = [
    "rosp-sdk>=0.1.0,<0.2.0",
]

[project.optional-dependencies]
# ROS2 dependencies are typically installed via apt, not pip.
# This extra is for environments where pip-installed rclpy is available.
ros2 = ["rclpy"]
test = ["rosp-sdk[test]"]

[project.entry-points."rosp.adapters"]
ros2 = "rosp_adapter_ros2.adapter:ROS2Adapter"

[project.scripts]
rosp-adapter-ros2 = "rosp_adapter_ros2.__main__:main"
```

The `rosp.adapters` entry point allows the SDK to discover installed adapters automatically:

```python
from importlib.metadata import entry_points

adapters = entry_points(group="rosp.adapters")
for ep in adapters:
    adapter_class = ep.load()
    print(f"Found adapter: {ep.name} -> {adapter_class}")
```

### 7.4 Docker Image

Adapters should provide a Docker image for containerized deployment. The image should:

1. Be based on a ROS2 base image (for ROS2 adapters) or a slim Python image (for non-ROS adapters).
2. Include the adapter package and all dependencies.
3. Accept configuration via environment variables or a mounted config file.
4. Expose the Zenoh port (default 7447).

```dockerfile
# Dockerfile for rosp-adapter-ros2
FROM ros:humble-ros-base

# Install Python dependencies.
RUN pip install rosp-sdk>=0.1.0

# Copy adapter code.
COPY src/ /opt/rosp/src/
COPY config/adapter.yaml.example /etc/rosp/adapter.yaml

WORKDIR /opt/rosp

# Zenoh port.
EXPOSE 7447

# Environment variable for config override.
ENV ROSP_ADAPTER_CONFIG=/etc/rosp/adapter.yaml

ENTRYPOINT ["python", "-m", "rosp_adapter_ros2", "--config", "/etc/rosp/adapter.yaml"]
```

```bash
# Build.
docker build -t rosp-adapter-ros2:0.1.0 .

# Run with custom config.
docker run -d \
  --name rosp-ros2 \
  --network host \
  -v /path/to/adapter.yaml:/etc/rosp/adapter.yaml:ro \
  -v /etc/rosp/certs:/etc/rosp/certs:ro \
  rosp-adapter-ros2:0.1.0
```

### 7.5 Version Compatibility

Adapter versions must declare which ROSP spec version they target. The version compatibility rule is:

- **Patch versions** (0.1.0 -> 0.1.1): Backward compatible. Adapters built for 0.1.0 work with 0.1.1 platforms and vice versa.
- **Minor versions** (0.1.x -> 0.2.x): The platform must support both. Adapters may need updates for new required methods.
- **Major versions** (0.x -> 1.x): Breaking. Adapters must be rewritten or significantly updated.

The adapter declares its compatible ROSP version range in `pyproject.toml` via the `rosp-sdk` dependency pin:

```
rosp-sdk>=0.1.0,<0.2.0    # Compatible with ROSP 0.1.x
```

The `rosp_version` field in the Robot Card and DiscoveryInfo must match the actual spec version the adapter implements.

---

## Appendix A: Error Codes

Adapters must use these standardized error codes in `CommandResult.error.code`:

| Code | Meaning |
|------|---------|
| `timeout` | Command exceeded its timeout_ms |
| `rejected_unknown_action` | Action name not in robot's skill list |
| `rejected_invalid_params` | Parameters failed schema validation |
| `rejected_safety_violation` | Command would violate safety constraints |
| `rejected_busy` | Robot is executing a non-preemptable command |
| `failed_hardware` | Robot hardware error during execution |
| `failed_planning` | Motion/task planning failed |
| `failed_execution` | Runtime error during execution |
| `preempted` | Command was preempted by another command or e-stop |
| `adapter_error` | Internal adapter error (bug) |

## Appendix B: Topic Path Conventions

ROSP sensor topic paths follow this hierarchy:

```
/sensor/{sensor_type}/{data_kind}
```

Examples:
- `/sensor/lidar/pointcloud`
- `/sensor/lidar/scan` (2D scan)
- `/sensor/camera/rgb`
- `/sensor/camera/depth`
- `/sensor/camera/stereo`
- `/sensor/imu/data`
- `/sensor/gps/fix`
- `/sensor/force_torque/wrench`
- `/sensor/joint_states`
- `/sensor/battery/state`
- `/sensor/odometry/pose`

Actuator command topics:
- `/actuator/velocity`
- `/actuator/joint_trajectory`
- `/actuator/gripper`

The adapter maps these ROSP paths to native robot topics. The mapping is adapter-specific and may be configured in the adapter YAML:

```yaml
# Optional: explicit topic mapping overrides.
topic_map:
  "/sensor/lidar/scan": "/scan"
  "/sensor/camera/rgb": "/camera/color/image_raw"
  "/sensor/imu/data": "/imu/data"
  "/sensor/joint_states": "/joint_states"
  "/actuator/velocity": "/cmd_vel"
```

If no explicit mapping is provided, the adapter should use heuristics (as shown in the tutorial's `_classify_sensor` method) to auto-map topics.

## Appendix C: Glossary

| Term | Definition |
|------|-----------|
| **Adapter** | A process that bridges ROSP to a robot's native protocol. |
| **Robot Card** | The canonical JSON/dict description of a robot's identity, capabilities, sensors, and constraints. |
| **Description Mode** | Adapter mode providing read-only access (describe, stream, discover, health). Required in v0.1. |
| **Control Mode** | Adapter mode adding command execution. Optional and DRAFT in v0.1. |
| **Zenoh** | The default transport for ROSP communication. Peer-to-peer, low-latency, QoS-aware. |
| **Native Protocol** | The robot's existing communication interface (ROS2, gRPC, VDA 5050, etc.). |
| **ROSP** | Robot Open Specification Protocol. |
| **URN** | Uniform Resource Name. ROSP robot IDs use the format `urn:rosp:robot:{mfr}:{model}:{serial}`. |
| **QoS** | Quality of Service. Parameters controlling reliability, frequency, and compression of data streams. |
| **Skill** | A named, parameterized action a robot can perform (navigate, pick, place, home). |
