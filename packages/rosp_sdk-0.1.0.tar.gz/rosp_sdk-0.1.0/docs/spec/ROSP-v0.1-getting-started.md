# ROSP v0.1 — Getting Started Guide

**Version:** 0.1
**Date:** 2026-03-25
**Time estimate:** ~30 minutes
**License:** Apache 2.0

---

## Table of Contents

1. [Overview](#1-overview)
2. [Install Prerequisites](#2-install-prerequisites)
3. [Launch the Simulated Robot](#3-launch-the-simulated-robot)
4. [Understand What the Robot Exposes](#4-understand-what-the-robot-exposes)
5. [Write Your First ROSP Adapter](#5-write-your-first-rosp-adapter)
6. [Run the Adapter](#6-run-the-adapter)
7. [Generate a Robot Card](#7-generate-a-robot-card)
8. [What's Next](#8-whats-next)
9. [Troubleshooting](#9-troubleshooting)
10. [Alternative: No-ROS Quick Start (Docker)](#10-alternative-no-ros-quick-start-docker)
11. [References](#11-references)

---

## 1. Overview

The **Robot Open Specification Protocol (ROSP)** is a vendor-agnostic, transport-agnostic communication protocol that standardizes how software platforms describe, discover, monitor, and command robots. ROSP reduces the robot integration problem from M platforms x N robot types (M*N custom integrations) to M + N standardized adapters — analogous to how LSP standardized IDE-to-language connectivity. Every robot gets an **adapter** that translates between ROSP and the robot's native protocol, and every platform speaks ROSP.

### What You Will Build

In this guide, you will build a **ROSP adapter** that:

1. Connects to a simulated **TurtleBot3 Burger** running in Gazebo
2. Introspects the robot's sensors, actuators, and parameters via ROS2
3. Streams live LiDAR, odometry, and IMU data through the ROSP `stream()` interface
4. Generates a **Robot Card** — a machine-readable description of everything the robot is and can do

By the end, you will have a working single-file Python adapter that any ROSP-compatible platform can connect to.

### Prerequisites

- **OS:** Ubuntu 22.04 (native or WSL2 on Windows 10/11)
- **Knowledge:** Basic Python (async/await helps but is not required)
- **Disk space:** ~4 GB free (ROS2 + Gazebo + TurtleBot3 packages)
- **Hardware:** A GPU is recommended for Gazebo rendering but not strictly required (headless mode works without one)

---

## 2. Install Prerequisites

Run every command block in a terminal on your Ubuntu 22.04 system (or inside a WSL2 Ubuntu 22.04 instance).

### 2.1 Install ROS2 Humble

ROS2 Humble Hawksbill is the LTS release targeting Ubuntu 22.04.

```bash
# Set locale
sudo apt update && sudo apt install -y locales
sudo locale-gen en_US en_US.UTF-8
sudo update-locale LC_ALL=en_US.UTF-8 LANG=en_US.UTF-8
export LANG=en_US.UTF-8

# Add the ROS2 apt repository
sudo apt install -y software-properties-common
sudo add-apt-repository universe
sudo apt update && sudo apt install -y curl gnupg lsb-release

sudo curl -sSL https://raw.githubusercontent.com/ros/rosdistro/master/ros.key \
  -o /usr/share/keyrings/ros-archive-keyring.gpg

echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/ros-archive-keyring.gpg] \
  http://packages.ros.org/ros2/ubuntu $(. /etc/os-release && echo $UBUNTU_CODENAME) main" \
  | sudo tee /etc/apt/sources.list.d/ros2.list > /dev/null

# Install ROS2 Humble Desktop (includes RViz2, demo nodes, dev tools)
sudo apt update
sudo apt install -y ros-humble-desktop
```

Source the ROS2 setup script (add this to your `~/.bashrc` so it persists):

```bash
echo "source /opt/ros/humble/setup.bash" >> ~/.bashrc
source /opt/ros/humble/setup.bash
```

Verify the installation:

```bash
ros2 --version
# Expected: ros2 0.x.x (any Humble version)
```

### 2.2 Install Gazebo (Classic)

TurtleBot3 simulation packages for ROS2 Humble use **Gazebo Classic** (version 11), not the newer Gazebo Harmonic. Gazebo Classic is included in the ROS2 Humble desktop install, but install the integration packages explicitly:

```bash
sudo apt install -y ros-humble-gazebo-ros-pkgs ros-humble-gazebo-ros2-control
```

### 2.3 Install TurtleBot3 Simulation Packages

```bash
sudo apt install -y \
  ros-humble-turtlebot3* \
  ros-humble-turtlebot3-simulations
```

### 2.4 Install Python Dependencies

```bash
pip3 install --upgrade pip
pip3 install pyyaml
```

> **Note:** The `rosp-sdk` package is not yet published to PyPI (it will be released alongside ROSP v0.1 GA). This guide includes the necessary ROSP data classes directly in the adapter source file so you can run it without waiting for the package.

### 2.5 Install RViz2 (Optional — for Visualization)

RViz2 is included with `ros-humble-desktop`. Verify:

```bash
ros2 run rviz2 rviz2 --help
```

### 2.6 Set Environment Variables

Add these to your `~/.bashrc`:

```bash
# TurtleBot3 model selection — "burger" is the smallest/simplest
echo 'export TURTLEBOT3_MODEL=burger' >> ~/.bashrc

# ROS2 domain ID — isolates your DDS traffic from others on the network
echo 'export ROS_DOMAIN_ID=30' >> ~/.bashrc

# Gazebo model path for TurtleBot3
echo 'export GAZEBO_MODEL_PATH=$GAZEBO_MODEL_PATH:/opt/ros/humble/share/turtlebot3_gazebo/models' >> ~/.bashrc

source ~/.bashrc
```

Verify everything is set:

```bash
echo "TURTLEBOT3_MODEL=$TURTLEBOT3_MODEL"
echo "ROS_DOMAIN_ID=$ROS_DOMAIN_ID"
# Expected: burger, 30
```

---

## 3. Launch the Simulated Robot

### 3.1 Launch Gazebo with TurtleBot3

Open a terminal and run:

```bash
ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py
```

Gazebo will open with a TurtleBot3 Burger in a small obstacle world. Wait until you see the robot rendered and the terminal settles (no more `[INFO]` lines scrolling). This typically takes 10-30 seconds.

> **Headless mode (no GPU / WSL2 without display):** If Gazebo fails to open a window, launch in headless mode:
> ```bash
> ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py \
>   extra_gazebo_args:="--verbose -s libgazebo_ros_init.so -s libgazebo_ros_factory.so --headless"
> ```

### 3.2 Verify the Robot Is Running

Open a **second terminal** and run:

```bash
ros2 topic list
```

You should see output similar to:

```
/camera/camera_info
/camera/image_raw
/clock
/cmd_vel
/imu
/joint_states
/odom
/parameter_events
/performance_metrics
/robot_description
/rosout
/scan
/tf
/tf_static
```

Key topics to look for:
- `/scan` — 2D LiDAR data (360-degree laser scan)
- `/odom` — Wheel odometry (position + velocity)
- `/imu` — Inertial measurement unit (orientation + acceleration)
- `/cmd_vel` — Velocity command input (the actuator)
- `/camera/image_raw` — RGB camera feed
- `/robot_description` — URDF model of the robot

If you see these topics, the simulation is running correctly.

### 3.3 Launch RViz2 (Optional)

To visualize the robot's sensor data:

```bash
ros2 launch turtlebot3_bringup rviz2.launch.py
```

RViz2 will open showing the TurtleBot3 model, laser scan overlay, and odometry trail.

---

## 4. Understand What the Robot Exposes

Before writing the ROSP adapter, let's introspect the simulated robot to understand what data it provides. This is exactly what the adapter will do programmatically.

### 4.1 List Available Topics

```bash
ros2 topic list -t
```

Output (abbreviated):

```
/camera/image_raw [sensor_msgs/msg/Image]
/cmd_vel [geometry_msgs/msg/Twist]
/imu [sensor_msgs/msg/Imu]
/joint_states [sensor_msgs/msg/JointState]
/odom [nav_msgs/msg/Odometry]
/scan [sensor_msgs/msg/LaserScan]
/tf [tf2_msgs/msg/TFMessage]
```

Each topic has a **message type** (e.g., `sensor_msgs/msg/LaserScan`) that defines the data schema.

### 4.2 Inspect a Specific Topic

```bash
# What type and QoS does the /scan topic use?
ros2 topic info /scan --verbose
```

Output (key parts):

```
Type: sensor_msgs/msg/LaserScan
Publisher count: 1
  Node name: turtlebot3_laserscan
  QoS: Reliability: BEST_EFFORT, Durability: VOLATILE, History: KEEP_LAST (5)
```

```bash
# Peek at one message from /scan
ros2 topic echo /scan --once
```

This prints a single laser scan with `ranges[]`, `angle_min`, `angle_max`, `angle_increment`, etc.

### 4.3 List Robot Parameters

```bash
ros2 param list /robot_state_publisher
```

Output:

```
  robot_description
  use_sim_time
```

The `robot_description` parameter contains the full URDF (Unified Robot Description Format) XML.

### 4.4 List Available Services

```bash
ros2 service list
```

Output includes:

```
/reset
/spawn_entity
/gazebo/set_entity_state
...
```

### 4.5 Mapping to ROSP Concepts

Here is how the ROS2 robot maps to ROSP:

| ROS2 Concept | Example | ROSP Concept | Robot Card Field |
|---|---|---|---|
| Topic (sensor) | `/scan`, `/odom`, `/imu` | `stream` resource | `sensors[].topics[]` |
| Topic (command) | `/cmd_vel` | `command` endpoint | `actuators[].commands[]` |
| Parameter | `robot_description` | Robot Card config | `hardware.geometry` (URDF) |
| Service | `/reset` | `command` (Control Mode) | `skills[]` |
| URDF | XML in `robot_description` | Physical description | `hardware.dimensions`, `hardware.weight` |
| Message type | `sensor_msgs/msg/LaserScan` | Stream data schema | `sensors[].data_schema` |
| QoS profile | `BEST_EFFORT`, `KEEP_LAST` | `StreamQoS` | `qos.reliability`, `qos.history_depth` |

---

## 5. Write Your First ROSP Adapter

Create a single file called `turtlebot3_adapter.py`. This adapter implements ROSP Description Mode: `describe()`, `stream()`, `discover()`, and `health_check()`.

```bash
mkdir -p ~/rosp-quickstart
cd ~/rosp-quickstart
```

Create the file `~/rosp-quickstart/turtlebot3_adapter.py` with the following content:

```python
#!/usr/bin/env python3
"""
turtlebot3_adapter.py — ROSP v0.1 Adapter for TurtleBot3 (Gazebo Simulation)

A single-file ROSP adapter that connects to a simulated TurtleBot3 Burger
via ROS2, introspects its sensors and parameters, streams sensor data, and
generates a Robot Card.

Usage:
    python3 turtlebot3_adapter.py                  # Run the adapter
    python3 turtlebot3_adapter.py --export-card     # Export Robot Card as JSON
    python3 turtlebot3_adapter.py --stream /scan    # Stream a specific topic

Requires:
    - ROS2 Humble installed and sourced
    - TurtleBot3 simulation running in Gazebo
    - TURTLEBOT3_MODEL=burger and ROS_DOMAIN_ID set
"""

import argparse
import asyncio
import json
import sys
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum
from typing import AsyncIterator, Dict, Any, List, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    QoSProfile,
    ReliabilityPolicy,
    HistoryPolicy,
    DurabilityPolicy,
)


# ---------------------------------------------------------------------------
# ROSP SDK Data Classes (embedded — will move to rosp-sdk package)
# ---------------------------------------------------------------------------

class AdapterStatus(Enum):
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    DISCONNECTED = "disconnected"
    ERROR = "error"


class RobotStatus(Enum):
    CONNECTED = "connected"
    DEGRADED = "degraded"
    DISCONNECTED = "disconnected"
    ESTOP = "estop"
    UNKNOWN = "unknown"


@dataclass
class RobotCard:
    rosp_version: str
    id: str
    identity: Dict[str, Any]
    hardware: Dict[str, Any]
    sensors: List[Dict[str, Any]]
    actuators: List[Dict[str, Any]]
    capabilities: List[str]
    integration: Dict[str, Any]
    safety: Dict[str, Any]
    skills: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class StreamQoS:
    reliability: str = "best_effort"
    frequency_hz: float = 0
    compression: str = "none"
    history_depth: int = 1


@dataclass
class StreamMessage:
    topic: str
    seq: int
    timestamp: datetime
    encoding: str
    data: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None


@dataclass
class DiscoveryInfo:
    robot_id: str
    model: str
    manufacturer: str
    rosp_version: str
    adapter_version: str
    capabilities_summary: List[str]
    endpoint: str
    mode: str = "description"


@dataclass
class HealthStatus:
    adapter_status: AdapterStatus
    robot_status: RobotStatus
    latency_ms: float
    uptime_seconds: float
    details: Optional[Dict[str, Any]] = None


class ROSPAdapter(ABC):
    """Base class for all ROSP adapters."""

    @abstractmethod
    async def describe(self, depth: str = "full") -> RobotCard:
        ...

    @abstractmethod
    async def stream(
        self, topics: List[str], qos: StreamQoS
    ) -> AsyncIterator[StreamMessage]:
        ...

    @abstractmethod
    async def discover(self) -> DiscoveryInfo:
        ...

    @abstractmethod
    async def health_check(self) -> HealthStatus:
        ...

    @abstractmethod
    async def connect(self) -> None:
        ...

    @abstractmethod
    async def disconnect(self) -> None:
        ...


# ---------------------------------------------------------------------------
# TurtleBot3 ROSP Adapter
# ---------------------------------------------------------------------------

class TurtleBot3Adapter(ROSPAdapter):
    """ROSP adapter for TurtleBot3 Burger running in Gazebo via ROS2.

    Implements Description Mode: describe(), stream(), discover(), health_check().
    """

    ADAPTER_VERSION = "0.1.0"
    ROBOT_ID = "urn:rosp:robot:robotis:turtlebot3-burger:sim-001"

    # Known TurtleBot3 Burger specs (from ROBOTIS documentation)
    TURTLEBOT3_SPECS = {
        "dimensions_m": {"length": 0.138, "width": 0.178, "height": 0.192},
        "weight_kg": 1.0,
        "max_velocity_ms": 0.22,
        "max_angular_velocity_rads": 2.84,
        "payload_capacity_kg": 15.0,
        "battery": {
            "type": "lithium_polymer",
            "capacity_wh": 32.4,  # 11.1V x 1800mAh
            "nominal_voltage_v": 11.1,
        },
        "compute": {
            "sbc": "Raspberry Pi 4 (simulated)",
            "mcu": "OpenCR 1.0 (ARM Cortex-M7)",
        },
    }

    # Map ROS2 topics to ROSP sensor descriptors
    SENSOR_MAP = {
        "/scan": {
            "sensor_id": "lidar",
            "type": "lidar_2d",
            "manufacturer": "ROBOTIS",
            "model": "LDS-02 (HLS-LFCD2)",
            "specifications": {
                "range_m": {"min": 0.12, "max": 3.5},
                "angular_range_deg": 360,
                "angular_resolution_deg": 1.0,
                "scan_frequency_hz": 5,
                "samples_per_scan": 360,
            },
            "topics": [
                {
                    "topic_id": "scan",
                    "ros2_topic": "/scan",
                    "data_type": "laser_scan",
                    "ros2_type": "sensor_msgs/msg/LaserScan",
                    "frequency_hz": 5,
                    "encoding": "json",
                }
            ],
        },
        "/odom": {
            "sensor_id": "odometry",
            "type": "wheel_odometry",
            "manufacturer": "ROBOTIS",
            "model": "Dynamixel XL430-W250 encoders",
            "specifications": {
                "linear_resolution_m": 0.001,
                "angular_resolution_rad": 0.001,
            },
            "topics": [
                {
                    "topic_id": "odom",
                    "ros2_topic": "/odom",
                    "data_type": "odometry",
                    "ros2_type": "nav_msgs/msg/Odometry",
                    "frequency_hz": 30,
                    "encoding": "json",
                }
            ],
        },
        "/imu": {
            "sensor_id": "imu",
            "type": "imu_9dof",
            "manufacturer": "ROBOTIS",
            "model": "OpenCR IMU (MPU9250-compatible)",
            "specifications": {
                "accelerometer_range_g": 2,
                "gyroscope_range_dps": 2000,
                "output_frequency_hz": 30,
            },
            "topics": [
                {
                    "topic_id": "data",
                    "ros2_topic": "/imu",
                    "data_type": "imu",
                    "ros2_type": "sensor_msgs/msg/Imu",
                    "frequency_hz": 30,
                    "encoding": "json",
                }
            ],
        },
        "/camera/image_raw": {
            "sensor_id": "camera",
            "type": "rgb_camera",
            "manufacturer": "Simulated",
            "model": "Gazebo Camera Plugin",
            "specifications": {
                "resolution": {"width": 640, "height": 480},
                "fov_deg": 60,
                "fps": 30,
            },
            "topics": [
                {
                    "topic_id": "image_raw",
                    "ros2_topic": "/camera/image_raw",
                    "data_type": "image",
                    "ros2_type": "sensor_msgs/msg/Image",
                    "frequency_hz": 30,
                    "encoding": "json",
                }
            ],
        },
    }

    ACTUATOR_MAP = {
        "/cmd_vel": {
            "actuator_id": "differential_drive",
            "type": "differential_drive",
            "manufacturer": "ROBOTIS",
            "model": "2x Dynamixel XL430-W250",
            "specifications": {
                "wheel_separation_m": 0.160,
                "wheel_radius_m": 0.033,
                "max_linear_velocity_ms": 0.22,
                "max_angular_velocity_rads": 2.84,
                "motor_torque_nm": 1.5,
            },
            "commands": [
                {
                    "command_id": "velocity",
                    "ros2_topic": "/cmd_vel",
                    "data_type": "twist",
                    "ros2_type": "geometry_msgs/msg/Twist",
                    "description": "Set linear.x (m/s) and angular.z (rad/s) velocity",
                }
            ],
        },
    }

    def __init__(self, domain_id: int = 30):
        self._domain_id = domain_id
        self._node: Optional[Node] = None
        self._connected = False
        self._start_time = time.monotonic()
        self._subscriptions: Dict[str, Any] = {}
        self._executor = None
        self._spin_task: Optional[asyncio.Task] = None

    # ---- Lifecycle ----

    async def connect(self) -> None:
        """Initialize rclpy and verify the TurtleBot3 simulation is running."""
        rclpy.init(domain_id=self._domain_id)
        self._node = Node("rosp_turtlebot3_adapter")
        self._connected = True
        self._start_time = time.monotonic()

        # Start spinning in the background so subscriptions receive callbacks
        self._spin_task = asyncio.get_event_loop().run_in_executor(
            None, self._spin_node
        )

        # Wait briefly for DDS discovery
        await asyncio.sleep(2.0)

        # Verify simulation is running
        topics = self._node.get_topic_names_and_types()
        topic_names = [t[0] for t in topics]

        required = ["/scan", "/odom", "/cmd_vel"]
        missing = [t for t in required if t not in topic_names]
        if missing:
            raise ConnectionError(
                f"TurtleBot3 simulation not detected. Missing topics: {missing}. "
                f"Is 'ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py' running?"
            )

    def _spin_node(self):
        """Spin the ROS2 node in a background thread."""
        try:
            while self._connected and rclpy.ok():
                rclpy.spin_once(self._node, timeout_sec=0.1)
        except Exception:
            pass

    async def disconnect(self) -> None:
        """Shut down the ROS2 node and rclpy."""
        self._connected = False
        if self._spin_task:
            self._spin_task.cancel()
        for sub in self._subscriptions.values():
            self._node.destroy_subscription(sub)
        self._subscriptions.clear()
        if self._node is not None:
            self._node.destroy_node()
            self._node = None
        try:
            rclpy.shutdown()
        except Exception:
            pass

    # ---- Description Mode: describe() ----

    async def describe(self, depth: str = "full") -> RobotCard:
        """Build a Robot Card for the TurtleBot3 by introspecting ROS2."""
        self._require_connected()

        topics = self._node.get_topic_names_and_types()
        topic_names = [t[0] for t in topics]

        # Build sensor list from known sensor topics that are actually present
        sensors = []
        for ros_topic, descriptor in self.SENSOR_MAP.items():
            if ros_topic in topic_names:
                sensors.append(descriptor)

        # Build actuator list
        actuators = []
        for ros_topic, descriptor in self.ACTUATOR_MAP.items():
            if ros_topic in topic_names:
                actuators.append(descriptor)

        # Attempt to read the URDF from robot_description topic
        urdf_info = await self._read_robot_description()

        # Build hardware section
        hardware = {
            **self.TURTLEBOT3_SPECS,
            "geometry": urdf_info,
        }

        # Infer capabilities from available topics
        capabilities = self._infer_capabilities(topic_names)

        card = RobotCard(
            rosp_version="0.1.0",
            id=self.ROBOT_ID,
            identity={
                "robot_id": "turtlebot3-burger-sim-001",
                "name": "TurtleBot3 Burger (Simulated)",
                "manufacturer": "ROBOTIS",
                "model": "TurtleBot3 Burger",
                "serial_number": "SIM-001",
                "firmware_version": "humble-gazebo",
                "rosp_version": "0.1",
                "type": "mobile_robot",
                "description": (
                    "Simulated TurtleBot3 Burger — a compact differential-drive "
                    "mobile robot with 360-degree LiDAR, IMU, and camera. "
                    "Running in Gazebo Classic with ROS2 Humble."
                ),
            },
            hardware=hardware,
            sensors=sensors if depth == "full" else [],
            actuators=actuators if depth == "full" else [],
            capabilities=capabilities,
            integration={
                "protocol": "ros2",
                "protocol_version": "humble",
                "native_endpoint": f"ros2://localhost (domain_id={self._domain_id})",
                "domain_id": self._domain_id,
                "middleware": "DDS (CycloneDDS or FastDDS)",
                "topics_available": topic_names,
            },
            safety={
                "emergency_stop": False,
                "max_velocity_ms": 0.22,
                "max_angular_velocity_rads": 2.84,
                "geofence": None,
                "notes": "Simulated robot — no physical safety systems.",
            },
            skills=[],
        )
        return card

    async def _read_robot_description(self) -> Dict[str, Any]:
        """Try to read the URDF from /robot_description topic."""
        try:
            # In Gazebo, robot_description is typically published as a latched topic
            from std_msgs.msg import String
            future = asyncio.get_event_loop().create_future()

            def callback(msg):
                if not future.done():
                    future.get_event_loop().call_soon_threadsafe(
                        future.set_result, msg.data
                    )

            sub = self._node.create_subscription(
                String, "/robot_description", callback,
                QoSProfile(
                    depth=1,
                    reliability=ReliabilityPolicy.RELIABLE,
                    durability=DurabilityPolicy.TRANSIENT_LOCAL,
                )
            )
            try:
                urdf_xml = await asyncio.wait_for(future, timeout=3.0)
                return {
                    "urdf_available": True,
                    "urdf_length_bytes": len(urdf_xml),
                    "format": "URDF/XML",
                }
            except asyncio.TimeoutError:
                return {"urdf_available": False, "reason": "Timeout reading /robot_description"}
            finally:
                self._node.destroy_subscription(sub)
        except Exception as e:
            return {"urdf_available": False, "reason": str(e)}

    @staticmethod
    def _infer_capabilities(topic_names: List[str]) -> List[str]:
        """Infer robot capabilities from the available ROS2 topics."""
        caps = []
        checks = [
            (["/scan"], "perception:lidar"),
            (["/camera/image_raw"], "perception:camera"),
            (["/imu"], "perception:imu"),
            (["/odom"], "navigation:odometry"),
            (["/cmd_vel"], "navigation:velocity_control"),
            (["/map"], "navigation:mapping"),
            (["/scan", "/cmd_vel"], "navigation:obstacle_avoidance"),
        ]
        for required_topics, capability in checks:
            if all(t in topic_names for t in required_topics):
                caps.append(capability)
        return sorted(caps)

    # ---- Description Mode: stream() ----

    async def stream(
        self, topics: List[str], qos: StreamQoS
    ) -> AsyncIterator[StreamMessage]:
        """Subscribe to ROS2 topics and yield ROSP StreamMessages."""
        self._require_connected()

        queue: asyncio.Queue[StreamMessage] = asyncio.Queue(maxsize=200)
        seq_counters: Dict[str, int] = {}

        # Map ROSP QoS to ROS2 QoS
        ros_qos = QoSProfile(depth=max(qos.history_depth, 1))
        if qos.reliability == "reliable":
            ros_qos.reliability = ReliabilityPolicy.RELIABLE
        else:
            ros_qos.reliability = ReliabilityPolicy.BEST_EFFORT
        ros_qos.history = HistoryPolicy.KEEP_LAST

        # Resolve ROSP topic paths to ROS2 topics
        available = dict(self._node.get_topic_names_and_types())
        active_subs = []

        for topic in topics:
            # Support both raw ROS2 topic names and ROSP sensor paths
            ros_topic = self._resolve_topic(topic)
            if ros_topic not in available:
                raise ValueError(
                    f"Topic '{topic}' (resolved to '{ros_topic}') not available. "
                    f"Available: {sorted(available.keys())}"
                )

            seq_counters[topic] = 0
            msg_type = self._resolve_msg_type(available[ros_topic][0])

            def make_callback(rosp_topic, ros_t):
                def callback(msg):
                    seq = seq_counters[rosp_topic]
                    seq_counters[rosp_topic] = seq + 1
                    stream_msg = StreamMessage(
                        topic=rosp_topic,
                        seq=seq,
                        timestamp=datetime.now(timezone.utc),
                        encoding="json",
                        data=self._ros_msg_to_dict(msg),
                        metadata={
                            "ros2_topic": ros_t,
                            "ros2_type": available[ros_t][0],
                        },
                    )
                    try:
                        queue.put_nowait(stream_msg)
                    except asyncio.QueueFull:
                        pass  # Best-effort: drop if consumer is slow
                return callback

            sub = self._node.create_subscription(
                msg_type, ros_topic, make_callback(topic, ros_topic), ros_qos
            )
            active_subs.append((topic, sub))
            self._subscriptions[topic] = sub

        # Yield messages from the queue
        try:
            while self._connected:
                try:
                    msg = await asyncio.wait_for(queue.get(), timeout=1.0)
                    yield msg
                except asyncio.TimeoutError:
                    continue
        finally:
            for topic, sub in active_subs:
                self._node.destroy_subscription(sub)
                self._subscriptions.pop(topic, None)

    # ---- Description Mode: discover() ----

    async def discover(self) -> DiscoveryInfo:
        """Return discovery information for this adapter."""
        self._require_connected()
        topics = self._node.get_topic_names_and_types()
        topic_names = [t[0] for t in topics]

        return DiscoveryInfo(
            robot_id=self.ROBOT_ID,
            model="TurtleBot3 Burger",
            manufacturer="ROBOTIS",
            rosp_version="0.1.0",
            adapter_version=self.ADAPTER_VERSION,
            capabilities_summary=self._infer_capabilities(topic_names),
            endpoint=f"ros2://localhost:{self._domain_id}",
            mode="description",
        )

    # ---- Description Mode: health_check() ----

    async def health_check(self) -> HealthStatus:
        """Check adapter and robot connection health."""
        if not self._connected or self._node is None:
            return HealthStatus(
                adapter_status=AdapterStatus.DISCONNECTED,
                robot_status=RobotStatus.DISCONNECTED,
                latency_ms=0.0,
                uptime_seconds=time.monotonic() - self._start_time,
            )

        t0 = time.monotonic()
        try:
            topics = self._node.get_topic_names_and_types()
            latency_ms = (time.monotonic() - t0) * 1000
            topic_names = [t[0] for t in topics]

            # Check if critical topics are still present
            critical = ["/scan", "/odom", "/cmd_vel"]
            missing = [t for t in critical if t not in topic_names]

            if missing:
                return HealthStatus(
                    adapter_status=AdapterStatus.HEALTHY,
                    robot_status=RobotStatus.DEGRADED,
                    latency_ms=latency_ms,
                    uptime_seconds=time.monotonic() - self._start_time,
                    details={
                        "topic_count": len(topics),
                        "missing_critical_topics": missing,
                    },
                )

            return HealthStatus(
                adapter_status=AdapterStatus.HEALTHY,
                robot_status=RobotStatus.CONNECTED,
                latency_ms=latency_ms,
                uptime_seconds=time.monotonic() - self._start_time,
                details={"topic_count": len(topics)},
            )
        except Exception as e:
            return HealthStatus(
                adapter_status=AdapterStatus.ERROR,
                robot_status=RobotStatus.UNKNOWN,
                latency_ms=0.0,
                uptime_seconds=time.monotonic() - self._start_time,
                details={"error": str(e)},
            )

    # ---- Private Helpers ----

    def _require_connected(self):
        if not self._connected or self._node is None:
            raise ConnectionError("Adapter not connected. Call connect() first.")

    @staticmethod
    def _resolve_topic(topic: str) -> str:
        """Resolve a ROSP sensor path to a ROS2 topic name.

        Supports both direct ROS2 topic names ("/scan") and ROSP-style paths
        ("/sensor/lidar/scan").
        """
        # If it starts with /sensor/, map to ROS2 topic
        rosp_to_ros2 = {
            "/sensor/lidar/scan": "/scan",
            "/sensor/odometry/odom": "/odom",
            "/sensor/imu/data": "/imu",
            "/sensor/camera/image_raw": "/camera/image_raw",
        }
        return rosp_to_ros2.get(topic, topic)

    @staticmethod
    def _resolve_msg_type(type_str: str):
        """Dynamically import a ROS2 message type from its string name."""
        parts = type_str.split("/")
        if len(parts) == 3:
            package, interface, name = parts
        elif len(parts) == 2:
            package, name = parts
            interface = "msg"
        else:
            raise ValueError(f"Cannot parse ROS2 message type: {type_str}")
        module = __import__(f"{package}.{interface}", fromlist=[name])
        return getattr(module, name)

    @staticmethod
    def _ros_msg_to_dict(msg) -> Dict[str, Any]:
        """Recursively convert a ROS2 message to a plain dict."""
        result = {}
        if hasattr(msg, "get_fields_and_field_types"):
            for field_name in msg.get_fields_and_field_types():
                value = getattr(msg, field_name)
                if hasattr(value, "get_fields_and_field_types"):
                    result[field_name] = TurtleBot3Adapter._ros_msg_to_dict(value)
                elif isinstance(value, (list, tuple)):
                    result[field_name] = [
                        TurtleBot3Adapter._ros_msg_to_dict(v)
                        if hasattr(v, "get_fields_and_field_types")
                        else (float(v) if hasattr(v, '__float__') else v)
                        for v in value
                    ]
                elif hasattr(value, '__float__'):
                    result[field_name] = float(value)
                elif hasattr(value, '__int__'):
                    result[field_name] = int(value)
                else:
                    result[field_name] = value
        return result


# ---------------------------------------------------------------------------
# JSON Serialization Helper
# ---------------------------------------------------------------------------

class ROSPEncoder(json.JSONEncoder):
    """JSON encoder that handles ROSP data classes."""

    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        if isinstance(obj, Enum):
            return obj.value
        if hasattr(obj, "__dataclass_fields__"):
            return asdict(obj)
        return super().default(obj)


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------

async def main():
    parser = argparse.ArgumentParser(
        description="ROSP v0.1 Adapter for TurtleBot3 (Gazebo Simulation)"
    )
    parser.add_argument(
        "--export-card",
        action="store_true",
        help="Export the Robot Card as JSON to stdout and exit.",
    )
    parser.add_argument(
        "--stream",
        nargs="+",
        metavar="TOPIC",
        help="Stream data from one or more topics (e.g., /scan /odom /imu).",
    )
    parser.add_argument(
        "--domain-id",
        type=int,
        default=30,
        help="ROS2 domain ID (default: 30, must match ROS_DOMAIN_ID).",
    )
    parser.add_argument(
        "--stream-count",
        type=int,
        default=0,
        help="Number of stream messages to print before exiting (0 = infinite).",
    )
    args = parser.parse_args()

    adapter = TurtleBot3Adapter(domain_id=args.domain_id)

    try:
        # --- Connect ---
        print("[rosp-adapter] Connecting to TurtleBot3 via ROS2...", file=sys.stderr)
        await adapter.connect()
        print("[rosp-adapter] Connected.", file=sys.stderr)

        # --- Health Check ---
        health = await adapter.health_check()
        print(
            f"[rosp-adapter] Health: adapter={health.adapter_status.value}, "
            f"robot={health.robot_status.value}, "
            f"latency={health.latency_ms:.1f}ms",
            file=sys.stderr,
        )

        # --- Export Robot Card ---
        if args.export_card:
            card = await adapter.describe(depth="full")
            print(json.dumps(asdict(card), indent=2, cls=ROSPEncoder))
            return

        # --- Discovery ---
        discovery = await adapter.discover()
        print(
            f"[rosp-adapter] Discovery: {discovery.robot_id}",
            file=sys.stderr,
        )
        print(
            f"[rosp-adapter]   Model: {discovery.model} ({discovery.manufacturer})",
            file=sys.stderr,
        )
        print(
            f"[rosp-adapter]   Capabilities: {discovery.capabilities_summary}",
            file=sys.stderr,
        )

        # --- Describe ---
        card = await adapter.describe()
        print(
            f"[rosp-adapter] Robot Card: {card.identity['name']}",
            file=sys.stderr,
        )
        print(
            f"[rosp-adapter]   Sensors: {[s['sensor_id'] for s in card.sensors]}",
            file=sys.stderr,
        )
        print(
            f"[rosp-adapter]   Actuators: {[a['actuator_id'] for a in card.actuators]}",
            file=sys.stderr,
        )
        print(
            f"[rosp-adapter]   Capabilities: {card.capabilities}",
            file=sys.stderr,
        )

        # --- Stream ---
        if args.stream:
            topics = args.stream
            qos = StreamQoS(reliability="best_effort", history_depth=5)
            print(
                f"[rosp-adapter] Streaming topics: {topics}",
                file=sys.stderr,
            )
            print(
                f"[rosp-adapter] Press Ctrl+C to stop.\n",
                file=sys.stderr,
            )
            count = 0
            async for msg in adapter.stream(topics, qos):
                output = {
                    "topic": msg.topic,
                    "seq": msg.seq,
                    "timestamp": msg.timestamp.isoformat(),
                    "data_keys": list(msg.data.keys()),
                    "data_preview": {
                        k: (v if not isinstance(v, list) or len(v) <= 5
                            else f"[{len(v)} items, first 5: {v[:5]}]")
                        for k, v in list(msg.data.items())[:6]
                    },
                }
                print(json.dumps(output, indent=2, cls=ROSPEncoder))
                count += 1
                if args.stream_count > 0 and count >= args.stream_count:
                    break
        else:
            # Default: just print summary and keep running
            print(
                "\n[rosp-adapter] Adapter is running. Available actions:",
                file=sys.stderr,
            )
            print(
                "  --export-card          Export Robot Card as JSON",
                file=sys.stderr,
            )
            print(
                "  --stream /scan /odom   Stream sensor data",
                file=sys.stderr,
            )
            print(
                "\n[rosp-adapter] Press Ctrl+C to stop.",
                file=sys.stderr,
            )

            # Keep alive and report health every 10 seconds
            while True:
                await asyncio.sleep(10)
                health = await adapter.health_check()
                print(
                    f"[rosp-adapter] Heartbeat: "
                    f"robot={health.robot_status.value}, "
                    f"uptime={health.uptime_seconds:.0f}s, "
                    f"latency={health.latency_ms:.1f}ms",
                    file=sys.stderr,
                )

    except KeyboardInterrupt:
        print("\n[rosp-adapter] Shutting down...", file=sys.stderr)
    except ConnectionError as e:
        print(f"[rosp-adapter] Connection failed: {e}", file=sys.stderr)
        sys.exit(1)
    finally:
        await adapter.disconnect()
        print("[rosp-adapter] Disconnected.", file=sys.stderr)


if __name__ == "__main__":
    asyncio.run(main())
```

---

## 6. Run the Adapter

Make sure Gazebo with TurtleBot3 is still running in another terminal (from Section 3.1).

### 6.1 Start the Adapter

```bash
cd ~/rosp-quickstart
python3 turtlebot3_adapter.py
```

### 6.2 Expected Output

```
[rosp-adapter] Connecting to TurtleBot3 via ROS2...
[rosp-adapter] Connected.
[rosp-adapter] Health: adapter=healthy, robot=connected, latency=0.8ms
[rosp-adapter] Discovery: urn:rosp:robot:robotis:turtlebot3-burger:sim-001
[rosp-adapter]   Model: TurtleBot3 Burger (ROBOTIS)
[rosp-adapter]   Capabilities: ['navigation:obstacle_avoidance', 'navigation:odometry', 'navigation:velocity_control', 'perception:camera', 'perception:imu', 'perception:lidar']
[rosp-adapter] Robot Card: TurtleBot3 Burger (Simulated)
[rosp-adapter]   Sensors: ['lidar', 'odometry', 'imu', 'camera']
[rosp-adapter]   Actuators: ['differential_drive']
[rosp-adapter]   Capabilities: ['navigation:obstacle_avoidance', 'navigation:odometry', 'navigation:velocity_control', 'perception:camera', 'perception:imu', 'perception:lidar']

[rosp-adapter] Adapter is running. Available actions:
  --export-card          Export Robot Card as JSON
  --stream /scan /odom   Stream sensor data

[rosp-adapter] Press Ctrl+C to stop.
[rosp-adapter] Heartbeat: robot=connected, uptime=10s, latency=0.6ms
[rosp-adapter] Heartbeat: robot=connected, uptime=20s, latency=0.7ms
```

### 6.3 Verify: Describe (Export the Robot Card)

In a separate terminal:

```bash
cd ~/rosp-quickstart
python3 turtlebot3_adapter.py --export-card 2>/dev/null | python3 -m json.tool | head -40
```

This prints the Robot Card as formatted JSON. The `2>/dev/null` suppresses the status messages (written to stderr) so only the clean JSON goes to stdout.

### 6.4 Verify: Stream LiDAR Data

```bash
python3 turtlebot3_adapter.py --stream /scan --stream-count 3
```

Expected output (3 messages then exit):

```
[rosp-adapter] Connecting to TurtleBot3 via ROS2...
[rosp-adapter] Connected.
[rosp-adapter] Streaming topics: ['/scan']
[rosp-adapter] Press Ctrl+C to stop.

{
  "topic": "/scan",
  "seq": 0,
  "timestamp": "2026-03-25T14:35:01.234567+00:00",
  "data_keys": ["header", "angle_min", "angle_max", "angle_increment", "time_increment", "scan_time", "range_min", "range_max", "ranges", "intensities"],
  "data_preview": {
    "angle_min": -3.1415927410125732,
    "angle_max": 3.1415927410125732,
    "angle_increment": 0.017501922324299812,
    "range_min": 0.11999999731779099,
    "range_max": 3.5,
    "ranges": "[360 items, first 5: [0.0, 0.0, 0.0, 3.12, 2.98]]"
  }
}
```

### 6.5 Verify: Stream Multiple Topics

```bash
python3 turtlebot3_adapter.py --stream /scan /odom /imu --stream-count 10
```

You will see interleaved messages from all three sensors.

### 6.6 Verify: Health Check

The adapter prints health heartbeats every 10 seconds automatically when running in default mode. The health status includes:

- **adapter_status**: `healthy` means the adapter process is running normally
- **robot_status**: `connected` means all critical ROS2 topics are publishing
- **latency_ms**: Round-trip time to query the ROS2 topic graph

---

## 7. Generate a Robot Card

The Robot Card is the core deliverable of a ROSP adapter. It is a machine-readable JSON document that fully describes what the robot is, what it can sense, what it can do, and how to connect to it.

### 7.1 Export the Robot Card

```bash
cd ~/rosp-quickstart
python3 turtlebot3_adapter.py --export-card > turtlebot3.robot-card.json 2>/dev/null
```

### 7.2 Robot Card Contents

View the generated card:

```bash
cat turtlebot3.robot-card.json | python3 -m json.tool
```

Here is what each section means:

```json
{
  "rosp_version": "0.1.0",
  "id": "urn:rosp:robot:robotis:turtlebot3-burger:sim-001",

  "identity": {
    "robot_id": "turtlebot3-burger-sim-001",
    "name": "TurtleBot3 Burger (Simulated)",
    "manufacturer": "ROBOTIS",
    "model": "TurtleBot3 Burger",
    "serial_number": "SIM-001",
    "firmware_version": "humble-gazebo",
    "rosp_version": "0.1",
    "type": "mobile_robot",
    "description": "Simulated TurtleBot3 Burger — a compact differential-drive mobile robot..."
  },

  "hardware": {
    "dimensions_m": { "length": 0.138, "width": 0.178, "height": 0.192 },
    "weight_kg": 1.0,
    "max_velocity_ms": 0.22,
    "max_angular_velocity_rads": 2.84,
    "payload_capacity_kg": 15.0,
    "battery": {
      "type": "lithium_polymer",
      "capacity_wh": 32.4,
      "nominal_voltage_v": 11.1
    },
    "compute": {
      "sbc": "Raspberry Pi 4 (simulated)",
      "mcu": "OpenCR 1.0 (ARM Cortex-M7)"
    },
    "geometry": {
      "urdf_available": true,
      "urdf_length_bytes": 4523,
      "format": "URDF/XML"
    }
  },

  "sensors": [
    {
      "sensor_id": "lidar",
      "type": "lidar_2d",
      "manufacturer": "ROBOTIS",
      "model": "LDS-02 (HLS-LFCD2)",
      "specifications": {
        "range_m": { "min": 0.12, "max": 3.5 },
        "angular_range_deg": 360,
        "angular_resolution_deg": 1.0,
        "scan_frequency_hz": 5,
        "samples_per_scan": 360
      },
      "topics": [
        {
          "topic_id": "scan",
          "ros2_topic": "/scan",
          "data_type": "laser_scan",
          "ros2_type": "sensor_msgs/msg/LaserScan",
          "frequency_hz": 5,
          "encoding": "json"
        }
      ]
    }
  ],

  "actuators": [
    {
      "actuator_id": "differential_drive",
      "type": "differential_drive",
      "manufacturer": "ROBOTIS",
      "model": "2x Dynamixel XL430-W250",
      "specifications": {
        "wheel_separation_m": 0.160,
        "wheel_radius_m": 0.033,
        "max_linear_velocity_ms": 0.22,
        "max_angular_velocity_rads": 2.84,
        "motor_torque_nm": 1.5
      }
    }
  ],

  "capabilities": [
    "navigation:obstacle_avoidance",
    "navigation:odometry",
    "navigation:velocity_control",
    "perception:camera",
    "perception:imu",
    "perception:lidar"
  ],

  "integration": {
    "protocol": "ros2",
    "protocol_version": "humble",
    "native_endpoint": "ros2://localhost (domain_id=30)",
    "domain_id": 30,
    "middleware": "DDS (CycloneDDS or FastDDS)"
  },

  "safety": {
    "emergency_stop": false,
    "max_velocity_ms": 0.22,
    "max_angular_velocity_rads": 2.84,
    "geofence": null,
    "notes": "Simulated robot — no physical safety systems."
  }
}
```

### 7.3 Section Breakdown

| Section | Purpose |
|---|---|
| **identity** | Who is this robot? Name, manufacturer, model, serial number. Used for display and inventory. |
| **hardware** | Physical specs: dimensions, weight, battery, compute. Used for task assignment (can this robot fit through a 20cm gap?). |
| **sensors** | Every sensor on the robot with full specs and available data topics. Used to determine what data a platform can subscribe to. |
| **actuators** | Every actuator with command schemas. Used by Control Mode to know what commands the robot accepts. |
| **capabilities** | High-level tags for what the robot can do. Used for discovery filtering ("find me all robots with LiDAR"). |
| **integration** | How to connect: protocol, endpoint, middleware. Used by the platform to establish communication. |
| **safety** | Speed limits, e-stop availability, geofence. Used to enforce safe operation. |

---

## 8. What's Next

Now that you have a working ROSP adapter for a simulated TurtleBot3, here are the natural next steps:

### Connect to a Different Simulated Robot

The same adapter pattern works for any ROS2 robot. Try:

- **UR5e robotic arm** in Gazebo — uses `joint_states`, `joint_trajectory_controller`
- **Husarion ROSbot** — another differential-drive robot with different sensor suites
- **Custom URDF robot** — design your own robot in SolidWorks/Fusion360, export URDF, simulate in Gazebo

### Write an Adapter for a Non-ROS2 Robot

ROSP is transport-agnostic. You can write adapters for:

- **gRPC robots** (Boston Dynamics Spot, Viam-connected robots) — implement `describe()` by calling the robot's gRPC status endpoint
- **VDA 5050 AMRs** (MiR, OTTO Motors) — bridge MQTT messages to ROSP
- **REST API robots** — wrap HTTP calls in the ROSP adapter interface
- **Proprietary SDK robots** (FANUC, KUKA, ABB) — use the vendor SDK as the native protocol

See the [Adapter SDK Specification](ROSP-v0.1-adapter-sdk.md) for the full interface definition, including TypeScript support.

### Register with a RoboSwarm Platform Instance

When the RoboSwarm platform is available, you can:

1. Register your Robot Card in the centralized registry
2. Discover other robots on the network
3. Build cross-robot applications using the standardized ROSP API

### Run Capability Tests Against the Adapter

Validate your adapter with the ROSP conformance test suite (coming soon):

```bash
# Future: rosp-test validate turtlebot3_adapter.py
```

### Contribute Your Adapter to the Community

ROSP adapters are open-source (Apache 2.0). If you write an adapter for a robot that others use, consider publishing it as a `rosp-adapter-*` package.

---

## 9. Troubleshooting

### "No topics found" / "Missing topics: ['/scan', '/odom', '/cmd_vel']"

**Cause:** The TurtleBot3 simulation is not running, or the adapter is using a different ROS2 domain ID.

**Fix:**
1. Verify Gazebo is running: `ros2 topic list` should show topics.
2. Verify `ROS_DOMAIN_ID` matches in both terminals:
   ```bash
   echo $ROS_DOMAIN_ID
   ```
3. If using a custom domain ID, pass it to the adapter:
   ```bash
   python3 turtlebot3_adapter.py --domain-id 0
   ```

### "rclpy.init() has already been called"

**Cause:** A previous adapter instance did not shut down cleanly.

**Fix:** Kill any lingering Python processes and try again:
```bash
pkill -f turtlebot3_adapter.py
python3 turtlebot3_adapter.py
```

### "Permission denied on /dev/ttyUSB0" or "/dev/ttyACM0"

**Cause:** On physical robots, the serial port needs user permissions.

**Fix:**
```bash
sudo usermod -aG dialout $USER
# Log out and log back in for the group change to take effect
```

### DDS Discovery Not Working (No Topics Visible Between Machines)

**Cause:** Multicast traffic is blocked by a firewall or the machines are on different subnets.

**Fix:**
1. Check the firewall:
   ```bash
   sudo ufw allow 7400:7500/udp
   ```
2. Use Zenoh as the DDS transport (avoids multicast):
   ```bash
   sudo apt install -y ros-humble-rmw-zenoh-cpp
   export RMW_IMPLEMENTATION=rmw_zenoh_cpp
   ```
3. Alternatively, configure FastDDS/CycloneDDS for unicast discovery with an XML profile.

### Gazebo Crashes on Startup

**Cause:** GPU driver issues (common in VMs and WSL2).

**Fix:**
1. Update GPU drivers:
   ```bash
   sudo apt install -y mesa-utils
   glxinfo | grep "OpenGL renderer"
   ```
2. Try software rendering:
   ```bash
   export LIBGL_ALWAYS_SOFTWARE=1
   ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py
   ```
3. Use headless mode (no GUI, simulation still runs):
   ```bash
   ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py \
     extra_gazebo_args:="--verbose --headless"
   ```

### WSL2-Specific Issues

**Display forwarding for Gazebo/RViz2:**

WSL2 requires an X server or WSLg for GUI applications.

1. **WSLg (Windows 11):** Should work out of the box. Verify:
   ```bash
   echo $DISPLAY
   # Expected: :0 or similar
   ```
2. **X Server (Windows 10):** Install VcXsrv or Xming on Windows, then:
   ```bash
   export DISPLAY=$(grep nameserver /etc/resolv.conf | awk '{print $2}'):0
   export LIBGL_ALWAYS_INDIRECT=0
   ```
3. **Performance tip:** Gazebo GUI is slow over WSLg. Use headless mode and visualize with RViz2 only (RViz2 is lighter than Gazebo GUI).

### "Cannot parse ROS2 message type: ..."

**Cause:** A topic is using a message type from a package that is not installed.

**Fix:**
```bash
# Find the package that provides the message type
ros2 interface list | grep <MessageType>
# Install it
sudo apt install -y ros-humble-<package-name>
```

---

## 10. Alternative: No-ROS Quick Start (Docker)

If you do not want to install ROS2, Gazebo, and TurtleBot3 packages on your system, use this Docker-based path. This is the fastest way to try ROSP.

### 10.1 Prerequisites

- Docker and Docker Compose installed ([install Docker](https://docs.docker.com/get-docker/))
- ~4 GB free disk space for the container image

### 10.2 Docker Compose File

Create a file called `docker-compose.yml`:

```yaml
# docker-compose.yml — ROSP TurtleBot3 Quick Start
# Launches Gazebo + TurtleBot3 + ROSP adapter in a single command.

version: "3.8"

services:
  turtlebot3-sim:
    image: osrf/ros:humble-desktop
    container_name: rosp-turtlebot3
    environment:
      - TURTLEBOT3_MODEL=burger
      - ROS_DOMAIN_ID=30
      - GAZEBO_MODEL_PATH=/opt/ros/humble/share/turtlebot3_gazebo/models
      - DISPLAY=${DISPLAY:-:0}
      - LIBGL_ALWAYS_SOFTWARE=1
    volumes:
      - /tmp/.X11-unix:/tmp/.X11-unix:rw
      - ./turtlebot3_adapter.py:/workspace/turtlebot3_adapter.py:ro
    network_mode: host
    stdin_open: true
    tty: true
    command: >
      bash -c "
        apt-get update -qq &&
        apt-get install -y -qq ros-humble-turtlebot3* ros-humble-turtlebot3-simulations > /dev/null 2>&1 &&
        source /opt/ros/humble/setup.bash &&
        export TURTLEBOT3_MODEL=burger &&
        export ROS_DOMAIN_ID=30 &&
        echo '[rosp-docker] Starting Gazebo with TurtleBot3...' &&
        ros2 launch turtlebot3_gazebo turtlebot3_world.launch.py &
        sleep 15 &&
        echo '[rosp-docker] Starting ROSP adapter...' &&
        python3 /workspace/turtlebot3_adapter.py
      "

  rosp-adapter-export:
    image: osrf/ros:humble-desktop
    container_name: rosp-export-card
    environment:
      - TURTLEBOT3_MODEL=burger
      - ROS_DOMAIN_ID=30
    network_mode: host
    profiles:
      - export
    command: >
      bash -c "
        apt-get update -qq &&
        apt-get install -y -qq ros-humble-turtlebot3* > /dev/null 2>&1 &&
        source /opt/ros/humble/setup.bash &&
        export ROS_DOMAIN_ID=30 &&
        sleep 20 &&
        python3 /workspace/turtlebot3_adapter.py --export-card
      "
    volumes:
      - ./turtlebot3_adapter.py:/workspace/turtlebot3_adapter.py:ro
```

### 10.3 Launch Everything

```bash
# Make sure turtlebot3_adapter.py is in the same directory as docker-compose.yml
docker compose up
```

Wait approximately 60 seconds for the packages to install, Gazebo to start, and the adapter to connect. You will see the same adapter output as in Section 6.2.

### 10.4 Export the Robot Card (Docker)

In a separate terminal:

```bash
docker exec rosp-turtlebot3 bash -c \
  "source /opt/ros/humble/setup.bash && \
   export ROS_DOMAIN_ID=30 && \
   python3 /workspace/turtlebot3_adapter.py --export-card 2>/dev/null"
```

### 10.5 Stream Sensor Data (Docker)

```bash
docker exec -it rosp-turtlebot3 bash -c \
  "source /opt/ros/humble/setup.bash && \
   export ROS_DOMAIN_ID=30 && \
   python3 /workspace/turtlebot3_adapter.py --stream /scan --stream-count 5"
```

### 10.6 Clean Up

```bash
docker compose down
```

---

## 11. References

| Resource | Link |
|---|---|
| **ROSP v0.1 Specification** | [ROSP-v0.1-spec.md](ROSP-v0.1-spec.md) |
| **ROSP Adapter SDK Specification** | [ROSP-v0.1-adapter-sdk.md](ROSP-v0.1-adapter-sdk.md) |
| **Robot Card Schema** | Defined in ROSP v0.1 Spec, Appendix A |
| **ROS2 Humble Documentation** | [https://docs.ros.org/en/humble/](https://docs.ros.org/en/humble/) |
| **ROS2 Humble Installation (Ubuntu)** | [https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debs.html](https://docs.ros.org/en/humble/Installation/Ubuntu-Install-Debs.html) |
| **TurtleBot3 Documentation** | [https://emanual.robotis.com/docs/en/platform/turtlebot3/overview/](https://emanual.robotis.com/docs/en/platform/turtlebot3/overview/) |
| **TurtleBot3 Simulation (ROS2)** | [https://emanual.robotis.com/docs/en/platform/turtlebot3/simulation/](https://emanual.robotis.com/docs/en/platform/turtlebot3/simulation/) |
| **Gazebo Classic Documentation** | [https://classic.gazebosim.org/](https://classic.gazebosim.org/) |
| **RoboSwarm Project** | [https://github.com/roboswarm](https://github.com/roboswarm) (coming soon) |

---

*This guide is part of the ROSP v0.1 specification suite. Licensed under Apache 2.0.*
