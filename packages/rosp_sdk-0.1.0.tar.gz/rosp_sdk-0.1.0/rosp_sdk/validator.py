"""ROSP Robot Card validator — validates Robot Cards against the JSON Schema.

Usage:
    from rosp_sdk import validate_robot_card

    errors = validate_robot_card(card_dict)
    if errors:
        for error in errors:
            print(f"Validation error: {error}")
    else:
        print("Robot Card is valid!")
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from rosp_sdk.models import RobotCard

# Schema files — search multiple possible locations
def _find_schema_dir() -> Path:
    """Find the schemas directory. Checks multiple locations to support
    different install layouts (development, pip install, Docker, microservice)."""
    candidates = [
        # Pip-installed: schemas bundled inside rosp_sdk/ package
        Path(__file__).parent / "schemas",
        # Development layout: rosp/rosp_sdk/ → docs/spec/schemas/
        Path(__file__).parent.parent / "docs" / "spec" / "schemas",
        # Monorepo layout: libs/rosp-sdk/rosp_sdk/ → docs/spec/schemas/
        Path(__file__).parent.parent.parent.parent / "docs" / "spec" / "schemas",
        # Docker layout: /rosp/spec/schemas/
        Path("/rosp/spec/schemas"),
        # Relative to CWD
        Path("docs/spec/schemas"),
    ]
    for candidate in candidates:
        if candidate.exists() and (candidate / "robot-card.schema.json").exists():
            return candidate
    # Fallback: return the first candidate (will raise FileNotFoundError later)
    return candidates[0]

_SCHEMA_DIR = _find_schema_dir()


def _load_schema(schema_name: str) -> Dict[str, Any]:
    """Load a JSON Schema file from the spec/schemas directory."""
    schema_path = _SCHEMA_DIR / schema_name
    if not schema_path.exists():
        raise FileNotFoundError(
            f"Schema file not found: {schema_path}. "
            f"Ensure the spec/schemas directory is at: {_SCHEMA_DIR}"
        )
    with open(schema_path) as f:
        return json.load(f)


def _build_validator(schema: Dict[str, Any]):
    """Build a JSON Schema validator with local $ref resolution.

    Loads all *.schema.json files from the spec/schemas directory and
    registers them so that $ref URIs (e.g., https://rosp.dev/schemas/v0.1/...)
    resolve to the local files.
    """
    try:
        import jsonschema
    except ImportError:
        raise ImportError(
            "jsonschema is required for validation. Install with: pip install jsonschema"
        )

    try:
        from referencing import Registry, Resource
        from referencing.jsonschema import DRAFT202012

        local_schemas = []
        for schema_file in _SCHEMA_DIR.glob("*.schema.json"):
            s = json.loads(schema_file.read_text())
            if "$id" in s:
                local_schemas.append(
                    (s["$id"], Resource.from_contents(s, default_specification=DRAFT202012))
                )

        registry = Registry().with_resources(local_schemas)
        return jsonschema.Draft202012Validator(schema, registry=registry)
    except ImportError:
        # Fallback: validate without $ref resolution (may skip some checks)
        return jsonschema.Draft202012Validator(schema)


def _collect_errors(validator, data: Dict[str, Any]) -> List[str]:
    """Run a validator and collect all errors as formatted strings."""
    errors: List[str] = []
    for error in validator.iter_errors(data):
        path = (
            " -> ".join(str(p) for p in error.absolute_path)
            if error.absolute_path
            else "(root)"
        )
        errors.append(f"[{path}] {error.message}")
    return errors


def validate_robot_card(
    card: Union[Dict[str, Any], RobotCard],
    schema: Optional[Dict[str, Any]] = None,
) -> List[str]:
    """Validate a Robot Card against the ROSP JSON Schema.

    Args:
        card: A Robot Card as a dictionary or RobotCard instance.
        schema: Optional custom schema. If None, loads robot-card.schema.json.

    Returns:
        List of validation error messages. Empty list means valid.
    """
    if isinstance(card, RobotCard):
        card_dict = card.to_dict()
    else:
        card_dict = card

    if schema is None:
        schema = _load_schema("robot-card.schema.json")

    validator = _build_validator(schema)
    return _collect_errors(validator, card_dict)


def validate_integration_manifest(manifest: Dict[str, Any]) -> List[str]:
    """Validate an Integration Manifest against the ROSP JSON Schema.

    Args:
        manifest: Integration Manifest as a dictionary.

    Returns:
        List of validation error messages. Empty list means valid.
    """
    schema = _load_schema("integration-manifest.schema.json")
    validator = _build_validator(schema)
    return _collect_errors(validator, manifest)


def validate_skill_description(skill: Dict[str, Any]) -> List[str]:
    """Validate a Skill Description against the ROSP JSON Schema.

    Args:
        skill: Skill Description as a dictionary.

    Returns:
        List of validation error messages. Empty list means valid.
    """
    schema = _load_schema("skill-description.schema.json")
    validator = _build_validator(schema)
    return _collect_errors(validator, skill)


def validate_card_file(file_path: Union[str, Path]) -> List[str]:
    """Validate a Robot Card JSON file.

    Args:
        file_path: Path to a .json file containing a Robot Card.

    Returns:
        List of validation error messages.
    """
    path = Path(file_path)
    if not path.exists():
        return [f"File not found: {path}"]

    try:
        with open(path) as f:
            card_dict = json.load(f)
    except json.JSONDecodeError as e:
        return [f"Invalid JSON: {e}"]

    return validate_robot_card(card_dict)
