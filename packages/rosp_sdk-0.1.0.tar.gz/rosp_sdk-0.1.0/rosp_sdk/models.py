"""ROSP data models — dataclasses for Robot Card, stream messages, commands, and health.

These models match the ROSP v0.1 specification exactly. See:
- rosp_sdk/spec/schemas/robot-card.schema.json
- rosp_sdk/spec/ROSP-v0.1-adapter-sdk.md Section 2
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional


# --- Enums ---


class CommandState(Enum):
    """Lifecycle states for a command execution.

    State machine:
        ACCEPTED -> IN_PROGRESS (0+ times) -> COMPLETED | FAILED | PREEMPTED
        Or immediately: REJECTED (if safety/capability check fails)
    """

    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"
    PREEMPTED = "preempted"


class AdapterStatus(Enum):
    """Health states for the adapter process."""

    HEALTHY = "healthy"
    DEGRADED = "degraded"
    DISCONNECTED = "disconnected"
    ERROR = "error"


class RobotStatus(Enum):
    """Health states for the robot connection."""

    CONNECTED = "connected"
    DEGRADED = "degraded"
    DISCONNECTED = "disconnected"
    ESTOP = "estop"
    UNKNOWN = "unknown"


# --- Core Data Models ---


@dataclass
class RobotCard:
    """Complete robot description. Conforms to robot-card.schema.json.

    The Robot Card is the canonical representation of a robot in the ROSP
    ecosystem. It describes what the robot IS, what it CAN DO, and how to
    interact with it.

    Attributes:
        rosp_version: ROSP spec version (e.g., "0.1").
        id: Globally unique URN. Format: "urn:rosp:robot:{manufacturer}:{model}:{serial}".
        identity: Human-readable identity (manufacturer, model, type, firmware).
        hardware: Physical characteristics (dimensions, weight, DOF, payload, battery, etc.).
        sensors: List of sensor descriptors with SOSA/SSN metadata.
        actuators: List of actuator descriptors with limits and control modes.
        capabilities: List of capability declarations.
        integration: Integration Manifest — how to connect to this robot.
        safety: Safety parameters and constraints.
        skills: List of skill descriptors (optional, Control Mode).
        calibration: Calibration data (joint offsets, camera intrinsics, etc.).
        coordinate_frames: Frame conventions (base, tool, world, units).
        end_effector: End-effector configuration (TCP, mass, tool I/O).
        environment: Environment requirements (maps, charging, infrastructure).
        diagnostics: Available diagnostics and maintenance schedule.
        simulation: Simulation compatibility (supported simulators, model URLs).
    """

    rosp_version: str
    id: str
    identity: Dict[str, Any]
    hardware: Dict[str, Any]
    sensors: List[Dict[str, Any]]
    actuators: List[Dict[str, Any]]
    capabilities: List[Dict[str, Any]]
    integration: Dict[str, Any]
    safety: Optional[Dict[str, Any]] = field(default_factory=dict)
    skills: List[Dict[str, Any]] = field(default_factory=list)
    calibration: Optional[Dict[str, Any]] = None
    coordinate_frames: Optional[Dict[str, Any]] = None
    end_effector: Optional[Dict[str, Any]] = None
    environment: Optional[Dict[str, Any]] = None
    diagnostics: Optional[Dict[str, Any]] = None
    simulation: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a dictionary suitable for JSON encoding."""
        result = {
            "rosp_version": self.rosp_version,
            "id": self.id,
            "identity": self.identity,
            "hardware": self.hardware,
            "sensors": self.sensors,
            "actuators": self.actuators,
            "capabilities": self.capabilities,
            "integration": self.integration,
        }
        if self.safety:
            result["safety"] = self.safety
        if self.skills:
            result["skills"] = self.skills
        if self.calibration:
            result["calibration"] = self.calibration
        if self.coordinate_frames:
            result["coordinate_frames"] = self.coordinate_frames
        if self.end_effector:
            result["end_effector"] = self.end_effector
        if self.environment:
            result["environment"] = self.environment
        if self.diagnostics:
            result["diagnostics"] = self.diagnostics
        if self.simulation:
            result["simulation"] = self.simulation
        if self.created_at:
            result["created_at"] = self.created_at
        if self.updated_at:
            result["updated_at"] = self.updated_at
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RobotCard":
        """Deserialize from a dictionary.

        Raises:
            ValueError: If required fields are missing, with a descriptive message
                        listing all missing fields.
        """
        # These match the schema's "required" array in robot-card.schema.json (Phase 0.2)
        required_fields = ["rosp_version", "id", "identity"]
        missing = [f for f in required_fields if f not in data]
        if missing:
            raise ValueError(
                f"Invalid Robot Card: missing required field(s): {', '.join(missing)}. "
                f"See robot-card.schema.json for the full specification."
            )
        return cls(
            rosp_version=data["rosp_version"],
            id=data["id"],
            identity=data["identity"],
            hardware=data.get("hardware", {}),
            sensors=data.get("sensors", []),
            actuators=data.get("actuators", []),
            capabilities=data.get("capabilities", []),
            integration=data.get("integration", {}),
            safety=data.get("safety", {}),
            skills=data.get("skills", []),
            calibration=data.get("calibration"),
            coordinate_frames=data.get("coordinate_frames"),
            end_effector=data.get("end_effector"),
            environment=data.get("environment"),
            diagnostics=data.get("diagnostics"),
            simulation=data.get("simulation"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
        )


@dataclass
class StreamQoS:
    """Quality of Service parameters for a sensor stream subscription.

    Attributes:
        reliability: "best_effort" for lossy high-frequency data (LiDAR, camera),
                     "reliable" for data that must not be dropped (force/torque).
        frequency_hz: Desired frequency. 0 means "as fast as possible".
                      Adapter returns actual achievable frequency in response.
        compression: "none", "lz4" (fast, good for point clouds), or
                     "zstd" (high ratio, good for images).
        history_depth: Number of most recent messages to buffer. Default 1.
    """

    reliability: str = "best_effort"
    frequency_hz: float = 0
    compression: str = "none"
    history_depth: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reliability": self.reliability,
            "frequency_hz": self.frequency_hz,
            "compression": self.compression,
            "history_depth": self.history_depth,
        }


@dataclass
class StreamMessage:
    """A single message from a sensor data stream.

    Attributes:
        topic: ROSP resource path (e.g., "/sensor/lidar/pointcloud").
        seq: Monotonically increasing sequence number per topic.
        timestamp: UTC timestamp when the robot produced the data.
        encoding: Data format ("json", "cbor", "raw").
        data: Sensor payload — structure defined by Robot Card sensor schema.
        metadata: Optional per-message metadata (actual_hz, compression_ratio).
    """

    topic: str
    seq: int
    timestamp: datetime
    encoding: str
    data: Dict[str, Any]
    metadata: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "topic": self.topic,
            "seq": self.seq,
            "timestamp": self.timestamp.isoformat(),
            "encoding": self.encoding,
            "data": self.data,
        }
        if self.metadata:
            result["metadata"] = self.metadata
        return result


@dataclass
class CommandResult:
    """A status update from a command execution (Control Mode — DRAFT).

    Lifecycle: ACCEPTED -> IN_PROGRESS (with feedback) -> COMPLETED | FAILED | PREEMPTED
    Or immediately: REJECTED

    Attributes:
        state: Current lifecycle state.
        progress: Completion fraction [0.0, 1.0]. Only meaningful in IN_PROGRESS.
        result: Action-specific result. Only populated in COMPLETED state.
        error: Error details with "code" and "message". Only in FAILED/REJECTED.
        timestamp: When this status update was generated.
    """

    state: CommandState
    progress: Optional[float] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[Dict[str, Any]] = None
    timestamp: Optional[datetime] = None

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {"state": self.state.value}
        if self.progress is not None:
            result["progress"] = self.progress
        if self.result is not None:
            result["result"] = self.result
        if self.error is not None:
            result["error"] = self.error
        if self.timestamp:
            result["timestamp"] = self.timestamp.isoformat()
        return result


@dataclass
class DiscoveryInfo:
    """Information broadcast during adapter discovery.

    Advertised via Zenoh liveliness and/or mDNS so platforms can find robots.

    Attributes:
        robot_id: The robot's URN (same as RobotCard.id).
        model: Human-readable model name.
        manufacturer: Manufacturer name.
        rosp_version: ROSP spec version supported.
        adapter_version: Adapter software version.
        capabilities_summary: List of high-level capability tags.
        endpoint: Zenoh endpoint where the adapter is reachable.
        mode: "description" or "control" indicating adapter capabilities.
    """

    robot_id: str
    model: str
    manufacturer: str
    rosp_version: str
    adapter_version: str
    capabilities_summary: List[str]
    endpoint: str
    mode: str = "description"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "robot_id": self.robot_id,
            "model": self.model,
            "manufacturer": self.manufacturer,
            "rosp_version": self.rosp_version,
            "adapter_version": self.adapter_version,
            "capabilities_summary": self.capabilities_summary,
            "endpoint": self.endpoint,
            "mode": self.mode,
        }


@dataclass
class HealthStatus:
    """Adapter and robot health report.

    Attributes:
        adapter_status: Current adapter process health.
        robot_status: Current robot connection health.
        latency_ms: Round-trip latency to robot's native interface (ms).
        uptime_seconds: Seconds since adapter process started.
        details: Optional adapter-specific diagnostics.
    """

    adapter_status: AdapterStatus
    robot_status: RobotStatus
    latency_ms: float
    uptime_seconds: float
    details: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        result: Dict[str, Any] = {
            "adapter_status": self.adapter_status.value,
            "robot_status": self.robot_status.value,
            "latency_ms": self.latency_ms,
            "uptime_seconds": self.uptime_seconds,
        }
        if self.details:
            result["details"] = self.details
        return result
