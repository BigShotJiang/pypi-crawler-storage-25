"""ROSP Message Envelope — the universal wire format for all ROSP messages.

Every ROSP message uses this envelope format regardless of transport (Zenoh, gRPC, WebSocket, MQTT).
See ROSP-v0.1-spec.md Section 4 for the full specification.
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, Optional


# Valid operation types per ROSP v0.1 spec
VALID_TYPES = frozenset({"describe", "stream", "command", "discover", "coordinate", "error"})


@dataclass
class ROSPEnvelope:
    """Universal ROSP message envelope.

    Attributes:
        type: Operation type — one of: describe, stream, command, discover, coordinate, error.
        path: Hierarchical resource path.
              Single robot: /robot/{robot_id}/sensor/lidar/scan
              Fleet context: /fleet/{fleet_id}/robot/{robot_id}/sensor/lidar/scan
              Wildcard: /fleet/{fleet_id}/robot/*/health
        body: Operation-specific payload.
        id: Client-assigned correlation ID for request-response matching.
            Auto-generated UUID if not provided.
        rosp: Protocol version string (default "0.1").
        timestamp: UTC timestamp in ISO 8601 format with nanosecond precision.
                   Auto-generated if not provided.
    """

    type: str
    path: str
    body: Dict[str, Any]
    id: str = ""
    rosp: str = "0.1"
    timestamp: str = ""

    def __post_init__(self):
        if not self.id:
            self.id = str(uuid.uuid4())
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()
        if self.type not in VALID_TYPES:
            raise ValueError(
                f"Invalid message type '{self.type}'. Must be one of: {', '.join(sorted(VALID_TYPES))}"
            )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "rosp": self.rosp,
            "type": self.type,
            "path": self.path,
            "id": self.id,
            "timestamp": self.timestamp,
            "body": self.body,
        }

    def to_json(self, **kwargs) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), default=str, **kwargs)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> ROSPEnvelope:
        """Deserialize from dictionary."""
        return cls(
            rosp=data.get("rosp", "0.1"),
            type=data["type"],
            path=data["path"],
            id=data.get("id", ""),
            timestamp=data.get("timestamp", ""),
            body=data.get("body", {}),
        )

    @classmethod
    def from_json(cls, json_str: str) -> ROSPEnvelope:
        """Deserialize from JSON string."""
        return cls.from_dict(json.loads(json_str))

    # --- Factory methods for common operations ---

    @classmethod
    def describe_request(cls, robot_id: str, depth: str = "full") -> ROSPEnvelope:
        """Create a describe request envelope."""
        return cls(
            type="describe",
            path=f"/robot/{robot_id}",
            body={"depth": depth},
        )

    @classmethod
    def stream_subscribe(
        cls,
        robot_id: str,
        topics: list[str],
        reliability: str = "best_effort",
        frequency_hz: float = 0,
        compression: str = "none",
    ) -> ROSPEnvelope:
        """Create a stream subscribe request envelope."""
        return cls(
            type="stream",
            path=f"/robot/{robot_id}",
            body={
                "action": "subscribe",
                "topics": topics,
                "qos": {
                    "reliability": reliability,
                    "frequency_hz": frequency_hz,
                    "compression": compression,
                },
            },
        )

    @classmethod
    def stream_unsubscribe(cls, robot_id: str, topics: list[str]) -> ROSPEnvelope:
        """Create a stream unsubscribe request envelope."""
        return cls(
            type="stream",
            path=f"/robot/{robot_id}",
            body={"action": "unsubscribe", "topics": topics},
        )

    @classmethod
    def discover_request(
        cls, filter_params: Optional[Dict[str, Any]] = None
    ) -> ROSPEnvelope:
        """Create a discover request envelope."""
        return cls(
            type="discover",
            path="/fleet/*/robot/*",
            body={"filter": filter_params or {}},
        )

    @classmethod
    def command_request(
        cls,
        robot_id: str,
        action: str,
        params: Dict[str, Any],
        timeout_ms: int = 30000,
        priority: str = "normal",
    ) -> ROSPEnvelope:
        """Create a command request envelope (Control Mode — DRAFT)."""
        return cls(
            type="command",
            path=f"/robot/{robot_id}",
            body={
                "action": action,
                "params": params,
                "timeout_ms": timeout_ms,
                "priority": priority,
            },
        )

    @classmethod
    def error_response(
        cls,
        request_id: str,
        code: int,
        category: str,
        message: str,
        path: str = "/error",
        details: Optional[Dict[str, Any]] = None,
    ) -> ROSPEnvelope:
        """Create an error response envelope.

        Args:
            request_id: Correlation ID from the original request.
            code: Numeric error code (1xxx transport, 2xxx protocol,
                  3xxx robot, 4xxx auth, 5xxx safety).
            category: Error category string.
            message: Human-readable error description.
            path: Resource path from the original request. Defaults to "/error".
            details: Optional additional error context.
        """
        return cls(
            type="error",
            path=path,
            id=request_id,
            body={
                "code": code,
                "category": category,
                "message": message,
                "details": details or {},
            },
        )
