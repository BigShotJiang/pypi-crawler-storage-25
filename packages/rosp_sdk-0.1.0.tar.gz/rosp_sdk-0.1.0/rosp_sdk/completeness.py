"""ROSP Robot Card completeness scorer.

Calculates how much of a Robot Card is filled in, distinguishing between
required, recommended, and optional fields. Returns a score and a list
of missing recommended fields.

Usage:
    from rosp_sdk.completeness import score_completeness

    result = score_completeness(card_dict)
    print(f"Score: {result['score']}%")
    print(f"Level: {result['level']}")
    print(f"Missing: {result['missing_recommended']}")
"""

from __future__ import annotations

from typing import Any, Dict, List, Tuple, Union

from rosp_sdk.models import RobotCard

# Recommended fields: (dotted_path, human_label)
# These are the fields that contribute to the completeness score.
RECOMMENDED_FIELDS: List[Tuple[str, str]] = [
    ("identity.manufacturer", "Manufacturer name"),
    ("identity.model", "Model name"),
    ("identity.firmware_version", "Firmware version"),
    ("hardware", "Hardware specifications"),
    ("hardware.weight_kg", "Robot weight"),
    ("hardware.dimensions", "Physical dimensions"),
    ("hardware.payload_kg", "Payload capacity"),
    ("sensors", "Sensor descriptions (non-empty list)"),
    ("actuators", "Actuator descriptions (non-empty list)"),
    ("capabilities", "Capability declarations (non-empty list)"),
    ("integration", "Integration manifest"),
    ("integration.supported_protocols", "Supported protocols"),
    ("safety", "Safety parameters"),
    ("safety.e_stop_available", "E-stop availability"),
    ("coordinate_frames", "Coordinate frame conventions"),
    ("coordinate_frames.unit_convention", "Unit conventions (m/rad)"),
    ("calibration", "Calibration data"),
    ("simulation", "Simulation compatibility"),
]

# Completeness levels and their score thresholds (upper bound exclusive).
_LEVELS = [
    (26, "minimal"),
    (51, "basic"),
    (76, "standard"),
    (101, "complete"),
]


_MISSING = object()
"""Sentinel indicating a field was not found during path resolution."""


def _resolve_path(data: Dict[str, Any], dotted_path: str) -> Any:
    """Walk a dotted path like 'identity.manufacturer' into a nested dict.

    Returns the value if found, or the sentinel ``_MISSING`` otherwise.
    """
    parts = dotted_path.split(".")
    current: Any = data
    for part in parts:
        if not isinstance(current, dict) or part not in current:
            return _MISSING
        current = current[part]
    return current


def _is_populated(value: Any) -> bool:
    """Return True if a value counts as 'populated' for scoring purposes.

    - ``_MISSING`` and ``None`` are not populated.
    - Empty dicts ``{}`` and empty lists ``[]`` are not populated.
    - Everything else (including ``False``, ``0``, ``0.0``) is populated.
    """
    if value is _MISSING or value is None:
        return False
    if isinstance(value, (dict, list)) and len(value) == 0:
        return False
    return True


def _determine_level(score: float) -> str:
    """Map a numeric score (0-100) to a completeness level string."""
    for threshold, level in _LEVELS:
        if score < threshold:
            return level
    return "complete"  # Defensive fallback — _LEVELS covers 0-100 but kept for safety


def score_completeness(
    card: Union[Dict[str, Any], RobotCard],
) -> Dict[str, Any]:
    """Score how complete a Robot Card is.

    Args:
        card: A Robot Card as a dictionary or :class:`RobotCard` instance.

    Returns:
        A dictionary with the following keys:

        - **score** (*float*): Completeness percentage (0-100), rounded to 1 decimal.
        - **level** (*str*): One of ``"minimal"``, ``"basic"``, ``"standard"``,
          or ``"complete"``.
        - **missing_recommended** (*list[str]*): Dotted paths of recommended
          fields that are missing or empty.
        - **populated_count** (*int*): Number of recommended fields that are
          populated.
        - **total_count** (*int*): Total number of recommended fields checked.
    """
    if isinstance(card, RobotCard):
        card_dict = card.to_dict()
    else:
        card_dict = card

    total = len(RECOMMENDED_FIELDS)
    populated = 0
    missing: List[str] = []

    for dotted_path, label in RECOMMENDED_FIELDS:
        value = _resolve_path(card_dict, dotted_path)
        if _is_populated(value):
            populated += 1
        else:
            missing.append(f"{dotted_path} ({label})")

    score = round((populated / total) * 100, 1) if total > 0 else 0.0
    level = _determine_level(score)

    return {
        "score": score,
        "level": level,
        "missing_recommended": missing,
        "populated_count": populated,
        "total_count": total,
    }
