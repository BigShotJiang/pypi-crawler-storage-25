"""ROSP Adapter base class — the interface every adapter must implement.

See ROSP-v0.1-adapter-sdk.md Section 2 for the full specification.

Usage:
    class MyROS2Adapter(ROSPAdapter):
        async def describe(self, depth="full") -> RobotCard:
            # Read URDF, introspect topics, build Robot Card
            ...

        async def stream(self, topics, qos) -> AsyncIterator[StreamMessage]:
            # Subscribe to ROS2 topics, yield ROSP StreamMessages
            ...
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from typing import Any, AsyncIterator, Dict, List, Optional

from rosp_sdk.models import (
    CommandResult,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    StreamMessage,
    StreamQoS,
)


class ROSPAdapter(ABC):
    """Base class for all ROSP robot adapters.

    Implementors must subclass this and provide concrete implementations for
    all abstract methods. The adapter lifecycle is:

        1. Instantiate the adapter with configuration.
        2. Call connect() to establish the native robot connection.
        3. Call describe(), stream(), discover(), health_check() as needed.
        4. Call disconnect() for clean shutdown.

    Control Mode methods (command) have default implementations that raise
    NotImplementedError. Override them only if the adapter supports Control Mode.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the adapter with optional configuration.

        Args:
            config: Adapter configuration dictionary. Typically loaded from
                    a YAML file matching the adapter registration spec.
        """
        self.config = config or {}
        self._start_time = time.monotonic()
        self._connected = False

    @property
    def uptime_seconds(self) -> float:
        """Seconds since the adapter was instantiated."""
        return time.monotonic() - self._start_time

    @property
    def is_connected(self) -> bool:
        """Whether the adapter is currently connected to the robot."""
        return self._connected

    # --- Lifecycle ---

    @abstractmethod
    async def connect(self) -> None:
        """Establish connection to the robot's native interface.

        This should:
        - Open the native protocol connection (ROS2 node, gRPC channel, etc.)
        - Verify the robot is reachable
        - Set self._connected = True on success

        Raises:
            ConnectionError: If the robot is not reachable.
            TimeoutError: If the connection attempt times out.
        """
        ...

    @abstractmethod
    async def disconnect(self) -> None:
        """Cleanly disconnect from the robot.

        This should:
        - Unsubscribe from all active streams
        - Close the native protocol connection
        - Set self._connected = False
        """
        ...

    # --- Description Mode (required) ---

    @abstractmethod
    async def describe(self, depth: str = "full") -> RobotCard:
        """Return the robot's complete description as a Robot Card.

        Args:
            depth: "summary" returns identity + capabilities list only.
                   "full" returns the complete Robot Card with sensor schemas,
                   actuator details, integration manifest, and all metadata.

        Returns:
            A RobotCard instance conforming to robot-card.schema.json.
        """
        ...

    @abstractmethod
    async def stream(
        self, topics: List[str], qos: Optional[StreamQoS] = None
    ) -> AsyncIterator[StreamMessage]:
        """Subscribe to sensor data streams.

        Args:
            topics: List of ROSP resource paths to subscribe to
                    (e.g., ["/sensor/lidar/scan", "/sensor/imu/orientation"]).
            qos: Quality of service parameters. If None, defaults are used
                 (best_effort, max frequency, no compression).

        Yields:
            StreamMessage for each sensor reading. Messages are ordered by
            timestamp within each topic. Cross-topic ordering is not guaranteed.

        The adapter should:
        - Map ROSP topic paths to native protocol topics
        - Subscribe to the native topics
        - Convert native messages to StreamMessage format
        - Apply requested QoS (frequency limiting, compression)
        - Yield messages until the caller stops iterating
        """
        ...

    @abstractmethod
    async def discover(self) -> DiscoveryInfo:
        """Return discovery information for this robot.

        Returns:
            DiscoveryInfo with robot identity, capabilities summary, and
            the endpoint where this adapter is reachable.
        """
        ...

    @abstractmethod
    async def health_check(self) -> HealthStatus:
        """Return adapter and robot health status.

        Returns:
            HealthStatus with adapter process health, robot connection health,
            round-trip latency, and uptime.

        The adapter should:
        - Ping the robot's native interface to measure latency
        - Check for active connections, error states, e-stop conditions
        - Return DEGRADED if data is stale or connection is intermittent
        - Return DISCONNECTED if the robot is unreachable
        """
        ...

    # --- Control Mode (optional, DRAFT in v0.1) ---

    async def command(
        self,
        action: str,
        params: Dict[str, Any],
        timeout_ms: int = 30000,
        priority: str = "normal",
    ) -> AsyncIterator[CommandResult]:
        """Send a command to the robot (Control Mode — DRAFT).

        Args:
            action: The action to execute (e.g., "navigate", "pick", "home").
            params: Action-specific parameters.
            timeout_ms: Maximum execution time in milliseconds.
            priority: "normal", "urgent", or "critical".

        Yields:
            CommandResult updates following the lifecycle:
            ACCEPTED -> IN_PROGRESS (with feedback) -> COMPLETED | FAILED | PREEMPTED

        Raises:
            NotImplementedError: If adapter only supports Description Mode.

        Note:
            Subclasses override this as an async generator that yields
            CommandResult updates. The base implementation raises
            NotImplementedError on the first iteration.
        """
        # The yield before raise ensures this IS an async generator.
        # When a caller does `async for result in adapter.command(...)`,
        # Python enters the generator, hits the raise, and propagates it
        # as a StopAsyncIteration with the error — which is correct behavior.
        #
        # Without the yield, this would be a coroutine (not a generator),
        # and `async for` would TypeError.
        if False:
            yield CommandResult(state=CommandState.ACCEPTED)  # type: ignore[unreachable]
        raise NotImplementedError(
            f"Control Mode not supported by {self.__class__.__name__}. "
            "This adapter operates in Description Mode only."
        )

    # --- Utility Methods ---

    async def export_card_json(self, depth: str = "full") -> str:
        """Export the Robot Card as a JSON string.

        Convenience method that calls describe() and serializes the result.

        Args:
            depth: Passed to describe().

        Returns:
            JSON string of the Robot Card.
        """
        import json

        card = await self.describe(depth=depth)
        return json.dumps(card.to_dict(), indent=2, default=str)

    async def __aenter__(self):
        """Async context manager support: connect on enter."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager support: disconnect on exit."""
        await self.disconnect()
        return False
