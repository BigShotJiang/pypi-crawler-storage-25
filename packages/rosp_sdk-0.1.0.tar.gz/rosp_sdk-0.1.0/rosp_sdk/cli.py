"""ROSP CLI — command-line interface for interacting with ROSP adapters and Robot Cards.

Usage:
    rosp describe <robot_id>          Show a robot's Robot Card
    rosp stream <robot_id> <topics>   Stream sensor data from a robot
    rosp discover                     Find robots on the network
    rosp validate <file>              Validate a Robot Card JSON file
    rosp export-card <file>           Pretty-print a Robot Card file
    rosp health <robot_id>            Check adapter and robot health
    rosp scan                         Scan for ROS2 robots on the network
    rosp card <file>                  Display or update a Robot Card
    rosp version                      Show ROSP SDK version
"""

from __future__ import annotations

import json
import os
import sys


def main():
    """ROSP CLI entry point."""
    try:
        import click
        from rich.console import Console
        from rich.table import Table
        from rich.syntax import Syntax
    except ImportError:
        print("CLI dependencies not installed. Run: pip install rosp-sdk[cli]")
        sys.exit(1)

    console = Console()

    @click.group()
    @click.version_option(version="0.1.0", prog_name="rosp")
    def cli():
        """ROSP — Robot Open Specification Protocol CLI."""
        pass

    # ------------------------------------------------------------------ #
    # validate
    # ------------------------------------------------------------------ #

    @cli.command()
    @click.argument("file_path", type=click.Path(exists=True))
    def validate(file_path: str):
        """Validate a Robot Card JSON file against the ROSP schema."""
        from rosp_sdk.validator import validate_card_file
        from rosp_sdk.completeness import score_completeness

        errors = validate_card_file(file_path)
        if errors:
            console.print(f"\n[red bold][X] Schema validation: FAILED[/] — {len(errors)} error(s):\n")
            for i, error in enumerate(errors, 1):
                console.print(f"  {i}. {error}")
            console.print()
            sys.exit(1)
        else:
            console.print("\n[green bold][OK] Schema validation: PASSED[/]")

        # Show completeness score after successful validation
        with open(file_path) as f:
            card_dict = json.load(f)
        result = score_completeness(card_dict)
        console.print(
            f"Completeness: {result['score']:.0f}% ({result['level']})"
        )
        missing = result["missing_recommended"]
        if missing:
            console.print("[yellow][!] Missing recommended fields:[/]")
            for field in missing:
                console.print(f"    - {field}")
        console.print()

    # ------------------------------------------------------------------ #
    # export-card
    # ------------------------------------------------------------------ #

    @cli.command(name="export-card")
    @click.argument("file_path", type=click.Path(exists=True))
    @click.option("--format", "fmt", type=click.Choice(["json", "summary"]), default="json")
    def export_card(file_path: str, fmt: str):
        """Pretty-print a Robot Card JSON file."""
        with open(file_path) as f:
            card = json.load(f)

        if fmt == "summary":
            identity = card.get("identity", {})
            hardware = card.get("hardware", {})
            sensors = card.get("sensors", [])
            actuators = card.get("actuators", [])
            capabilities = card.get("capabilities", [])

            table = Table(title=f"Robot Card: {card.get('id', 'unknown')}")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="white")

            table.add_row("Manufacturer", identity.get("manufacturer", "?"))
            table.add_row("Model", identity.get("model", "?"))
            table.add_row("Type", identity.get("type", "?"))
            table.add_row("Firmware", identity.get("firmware_version", "?"))
            table.add_row("Weight", f"{hardware.get('weight_kg', '?')} kg")
            table.add_row("Payload", f"{hardware.get('payload_kg', '?')} kg")
            table.add_row("DOF", str(hardware.get("degrees_of_freedom", "?")))
            table.add_row("Sensors", str(len(sensors)))
            table.add_row("Actuators", str(len(actuators)))
            table.add_row("Capabilities", str(len(capabilities)))
            table.add_row("ROSP Version", card.get("rosp_version", "?"))

            console.print(table)
        else:
            syntax = Syntax(
                json.dumps(card, indent=2),
                "json",
                theme="monokai",
                line_numbers=True,
            )
            console.print(syntax)

    # ------------------------------------------------------------------ #
    # version
    # ------------------------------------------------------------------ #

    @cli.command()
    def version():
        """Show ROSP SDK version and spec version."""
        from rosp_sdk import __version__

        table = Table(show_header=False)
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="white")
        table.add_row("SDK Version", __version__)
        table.add_row("Spec Version", "0.1")
        table.add_row("Protocol", "ROSP (Robot Open Specification Protocol)")
        table.add_row("License", "Apache 2.0 (spec + SDK)")
        console.print(table)

    # ------------------------------------------------------------------ #
    # inspect
    # ------------------------------------------------------------------ #

    @cli.command()
    @click.argument("file_path", type=click.Path(exists=True))
    def inspect(file_path: str):
        """Inspect a Robot Card and show sensor/actuator details."""
        with open(file_path) as f:
            card = json.load(f)

        # Sensors table
        sensors = card.get("sensors", [])
        if sensors:
            table = Table(title="Sensors")
            table.add_column("ID", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Frequency", style="yellow")
            table.add_column("Data Format")

            for s in sensors:
                freq = s.get("observation_properties", {}).get("frequency_hz", "?")
                table.add_row(
                    s.get("sensor_id", "?"),
                    s.get("type", "?"),
                    f"{freq} Hz",
                    s.get("data_format", {}).get("message_type", "?"),
                )
            console.print(table)

        # Actuators table
        actuators = card.get("actuators", [])
        if actuators:
            table = Table(title="Actuators")
            table.add_column("ID", style="cyan")
            table.add_column("Type", style="green")
            table.add_column("Control Modes", style="yellow")

            for a in actuators:
                modes = ", ".join(a.get("control_modes", []))
                table.add_row(
                    a.get("actuator_id", "?"),
                    a.get("type", "?"),
                    modes or "?",
                )
            console.print(table)

        # Integration info
        integration = card.get("integration", {})
        protocols = integration.get("supported_protocols", [])
        if protocols:
            table = Table(title="Integration")
            table.add_column("Protocol", style="cyan")
            table.add_column("Endpoint", style="white")
            table.add_column("Auth", style="yellow")

            for p in protocols:
                table.add_row(
                    p.get("protocol", "?"),
                    p.get("endpoint", "?"),
                    p.get("auth_method", "none"),
                )
            console.print(table)

    # ------------------------------------------------------------------ #
    # scan (NEW)
    # ------------------------------------------------------------------ #

    @cli.command()
    def scan():
        """Scan for ROSP adapters or ROS2 robots on the network."""
        domain_id = os.environ.get("ROS_DOMAIN_ID", "0")
        console.print(
            f"\n\U0001f50d Scanning ROS2 network (domain {domain_id})...\n"
        )

        try:
            import rclpy
            from rclpy.node import Node
        except ImportError:
            console.print(
                "[dim]rclpy not available — showing placeholder scan results.[/]\n"
            )
            console.print(
                "To enable live ROS2 scanning, install ROS2 and ensure rclpy is\n"
                "available in your Python environment:\n"
            )
            console.print("  [cyan]sudo apt install ros-humble-desktop[/]  (Ubuntu)")
            console.print("  [cyan]pip install rosp-sdk[ros2][/]           (when available)\n")
            console.print(
                "[dim]In the meantime, you can create Robot Cards manually with:[/]\n"
                "  [cyan]rosp card my-robot.json --completeness[/]\n"
            )
            return

        node = None
        try:
            rclpy.init()
            node = Node("rosp_scanner")

            topic_names_and_types = node.get_topic_names_and_types()
            if not topic_names_and_types:
                console.print("[yellow]No topics found on the ROS2 network.[/]")
                return

            # Group topics by potential robot namespace
            namespaces: dict[str, list] = {}
            for topic_name, topic_types in topic_names_and_types:
                parts = topic_name.strip("/").split("/")
                ns = parts[0] if len(parts) > 1 else "(root)"
                namespaces.setdefault(ns, []).append(
                    (topic_name, topic_types)
                )

            table = Table(title="Discovered ROS2 Topics")
            table.add_column("Namespace", style="cyan")
            table.add_column("Topic", style="white")
            table.add_column("Type(s)", style="green")

            for ns in sorted(namespaces):
                for topic_name, topic_types in namespaces[ns]:
                    table.add_row(ns, topic_name, ", ".join(topic_types))

            console.print(table)
            console.print(
                f"\nFound [bold]{len(topic_names_and_types)}[/] topic(s) "
                f"across [bold]{len(namespaces)}[/] namespace(s).\n"
            )
        except Exception as exc:
            console.print(f"[red]Scan error:[/] {exc}\n")
        finally:
            if node is not None:
                node.destroy_node()
            try:
                rclpy.shutdown()
            except Exception:
                pass

    # ------------------------------------------------------------------ #
    # card (NEW)
    # ------------------------------------------------------------------ #

    @cli.command()
    @click.argument("file_path", type=click.Path(exists=True))
    @click.option("--completeness", is_flag=True, help="Show completeness score.")
    @click.option("--update", is_flag=True, help="Update card fields in-place.")
    @click.option("--weight", type=float, default=None, help="Set hardware.weight_kg.")
    @click.option("--payload", type=float, default=None, help="Set hardware.payload_kg.")
    @click.option("--format", "fmt", type=click.Choice(["json", "summary"]), default="summary")
    def card(file_path: str, completeness: bool, update: bool, weight, payload, fmt: str):
        """Display, score, or update a Robot Card.

        \b
        Examples:
            rosp card my-robot.json
            rosp card my-robot.json --completeness
            rosp card my-robot.json --update --weight 1.0 --payload 5.0
        """
        with open(file_path) as f:
            card_dict = json.load(f)

        # --- Update mode ---
        if update:
            changed = False
            if weight is not None:
                card_dict.setdefault("hardware", {})["weight_kg"] = weight
                changed = True
            if payload is not None:
                card_dict.setdefault("hardware", {})["payload_kg"] = payload
                changed = True

            if changed:
                with open(file_path, "w") as f:
                    json.dump(card_dict, f, indent=2)
                console.print(f"[green][OK] Updated {file_path}[/]\n")
            else:
                console.print("[yellow]No update flags provided (--weight, --payload).[/]\n")

        # --- Display ---
        identity = card_dict.get("identity", {})
        hardware = card_dict.get("hardware", {})
        sensors = card_dict.get("sensors", [])
        actuators = card_dict.get("actuators", [])
        capabilities = card_dict.get("capabilities", [])

        if fmt == "summary":
            table = Table(title=f"Robot Card: {card_dict.get('id', 'unknown')}")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="white")

            table.add_row("Manufacturer", identity.get("manufacturer", "?"))
            table.add_row("Model", identity.get("model", "?"))
            table.add_row("Type", identity.get("type", "?"))
            table.add_row("Firmware", identity.get("firmware_version", "?"))
            table.add_row("Weight", f"{hardware.get('weight_kg', '?')} kg")
            table.add_row("Payload", f"{hardware.get('payload_kg', '?')} kg")
            table.add_row("DOF", str(hardware.get("degrees_of_freedom", "?")))
            table.add_row("Sensors", str(len(sensors)))
            table.add_row("Actuators", str(len(actuators)))
            table.add_row("Capabilities", str(len(capabilities)))
            table.add_row("ROSP Version", card_dict.get("rosp_version", "?"))

            console.print(table)
        else:
            syntax = Syntax(
                json.dumps(card_dict, indent=2),
                "json",
                theme="monokai",
                line_numbers=True,
            )
            console.print(syntax)

        # --- Completeness ---
        if completeness:
            from rosp_sdk.completeness import score_completeness

            result = score_completeness(card_dict)
            console.print(
                f"\nCompleteness: {result['score']:.0f}% ({result['level']})"
            )
            console.print(
                f"    Populated: {result['populated_count']}/{result['total_count']} recommended fields"
            )
            missing = result["missing_recommended"]
            if missing:
                console.print("[yellow][!] Missing recommended fields:[/]")
                for field_name in missing:
                    console.print(f"    - {field_name}")
            console.print()

    cli()


if __name__ == "__main__":
    main()
