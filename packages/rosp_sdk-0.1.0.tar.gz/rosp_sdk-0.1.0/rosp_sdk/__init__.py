"""ROSP SDK — Robot Open Specification Protocol.

Base classes, data models, and tools for building ROSP robot adapters.

Usage:
    from rosp_sdk import ROSPAdapter, RobotCard, StreamMessage, StreamQoS

    class MyAdapter(ROSPAdapter):
        async def describe(self, depth="full") -> RobotCard:
            ...
"""

__version__ = "0.1.0"

from rosp_sdk.models import (
    AdapterStatus,
    CommandResult,
    CommandState,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
    StreamQoS,
)
from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.envelope import ROSPEnvelope
from rosp_sdk.validator import validate_robot_card
from rosp_sdk.completeness import score_completeness

__all__ = [
    "ROSPAdapter",
    "ROSPEnvelope",
    "RobotCard",
    "StreamMessage",
    "StreamQoS",
    "CommandResult",
    "CommandState",
    "DiscoveryInfo",
    "HealthStatus",
    "AdapterStatus",
    "RobotStatus",
    "validate_robot_card",
    "score_completeness",
]
