"""Tests for ROSP completeness scorer module."""

import pytest

from rosp_sdk.completeness import score_completeness, RECOMMENDED_FIELDS
from rosp_sdk.models import RobotCard


def _make_minimal_card() -> dict:
    """Card with only the absolute bare minimum: rosp_version, id, identity.type."""
    return {
        "rosp_version": "0.1",
        "id": "urn:rosp:robot:test:testbot:001",
        "identity": {
            "type": "mobile_robot",
        },
        "hardware": {},
        "sensors": [],
        "actuators": [],
        "capabilities": [],
        "integration": {},
    }


def _make_full_card() -> dict:
    """Card with ALL recommended fields populated."""
    return {
        "rosp_version": "0.1",
        "id": "urn:rosp:robot:acme:arm7:001",
        "identity": {
            "manufacturer": "ACME Robotics",
            "model": "Arm7",
            "type": "manipulator",
            "firmware_version": "2.4.1",
        },
        "hardware": {
            "weight_kg": 25.0,
            "dimensions": {"length_m": 0.8, "width_m": 0.4, "height_m": 1.2},
            "payload_kg": 7.0,
            "degrees_of_freedom": 7,
        },
        "sensors": [
            {"sensor_id": "ft_wrist", "type": "force_torque"},
        ],
        "actuators": [
            {"actuator_id": "joint_1", "type": "revolute"},
        ],
        "capabilities": [
            {"capability_id": "pick_and_place", "type": "manipulation"},
        ],
        "integration": {
            "supported_protocols": [{"protocol": "ros2"}],
        },
        "safety": {
            "e_stop_available": True,
            "max_speed_m_s": 1.5,
        },
        "coordinate_frames": {
            "base_frame": "base_link",
            "unit_convention": {"length": "m", "angle": "rad"},
        },
        "calibration": {
            "joint_offsets": [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        },
        "simulation": {
            "supported_simulators": ["gazebo", "isaac_sim"],
        },
    }


# ------------------------------------------------------------------ #
# Score range tests
# ------------------------------------------------------------------ #


class TestMinimalCard:
    """A minimal card should score low (minimal level)."""

    def test_score_range(self):
        result = score_completeness(_make_minimal_card())
        assert 0 <= result["score"] <= 25, (
            f"Minimal card scored {result['score']}%, expected 0-25%"
        )

    def test_level_is_minimal(self):
        result = score_completeness(_make_minimal_card())
        assert result["level"] == "minimal"

    def test_missing_list_not_empty(self):
        result = score_completeness(_make_minimal_card())
        assert len(result["missing_recommended"]) > 0


class TestFullCard:
    """A card with all recommended fields should score 100%."""

    def test_score_is_100(self):
        result = score_completeness(_make_full_card())
        assert result["score"] == 100.0, (
            f"Full card scored {result['score']}%, expected 100%"
        )

    def test_level_is_complete(self):
        result = score_completeness(_make_full_card())
        assert result["level"] == "complete"

    def test_no_missing(self):
        result = score_completeness(_make_full_card())
        assert result["missing_recommended"] == []

    def test_populated_equals_total(self):
        result = score_completeness(_make_full_card())
        assert result["populated_count"] == result["total_count"]


# ------------------------------------------------------------------ #
# Missing fields are correctly listed
# ------------------------------------------------------------------ #


class TestMissingFields:
    def test_missing_fields_are_strings(self):
        result = score_completeness(_make_minimal_card())
        for field in result["missing_recommended"]:
            assert isinstance(field, str)

    def test_removing_one_field_adds_it_to_missing(self):
        card = _make_full_card()
        del card["calibration"]
        result = score_completeness(card)
        assert any("calibration" in f for f in result["missing_recommended"])

    def test_empty_list_counts_as_missing(self):
        card = _make_full_card()
        card["sensors"] = []
        result = score_completeness(card)
        assert any("sensors" in f for f in result["missing_recommended"])

    def test_empty_dict_counts_as_missing(self):
        card = _make_full_card()
        card["safety"] = {}
        result = score_completeness(card)
        assert any("safety (" in f for f in result["missing_recommended"])
        assert any("safety.e_stop_available" in f for f in result["missing_recommended"])


# ------------------------------------------------------------------ #
# Level transitions
# ------------------------------------------------------------------ #


class TestLevelTransitions:
    """Verify that scores map to the correct levels."""

    def test_minimal_level(self):
        result = score_completeness(_make_minimal_card())
        assert result["level"] == "minimal"

    def test_basic_level(self):
        """Add manufacturer, model, and hardware to push into basic."""
        card = _make_minimal_card()
        card["identity"]["manufacturer"] = "TestCorp"
        card["identity"]["model"] = "TestBot"
        card["identity"]["firmware_version"] = "1.0.0"
        card["hardware"] = {"weight_kg": 5.0, "dimensions": {"x": 1}, "payload_kg": 2.0}
        card["integration"] = {"supported_protocols": [{"protocol": "ros2"}]}
        # That's 7/18 ~ 38.9%
        result = score_completeness(card)
        assert result["level"] == "basic", f"Expected basic, got {result['level']} ({result['score']}%)"

    def test_standard_level(self):
        """Add sensors, actuators, capabilities, integration to get standard."""
        card = _make_minimal_card()
        card["identity"]["manufacturer"] = "TestCorp"
        card["identity"]["model"] = "TestBot"
        card["identity"]["firmware_version"] = "1.0.0"
        card["hardware"] = {"weight_kg": 5.0, "payload_kg": 2.0}
        card["sensors"] = [{"sensor_id": "cam", "type": "camera"}]
        card["actuators"] = [{"actuator_id": "j1", "type": "revolute"}]
        card["capabilities"] = [{"capability_id": "nav", "type": "navigation"}]
        card["integration"] = {"supported_protocols": [{"protocol": "ros2"}]}
        # That's 10/18 ~ 55.6%
        result = score_completeness(card)
        assert result["level"] == "standard", f"Expected standard, got {result['level']} ({result['score']}%)"

    def test_complete_level(self):
        result = score_completeness(_make_full_card())
        assert result["level"] == "complete"


# ------------------------------------------------------------------ #
# Works on both dict and RobotCard instances
# ------------------------------------------------------------------ #


class TestRobotCardInstance:
    def test_from_robotcard_matches_dict(self):
        card_dict = _make_full_card()
        robot_card = RobotCard.from_dict(card_dict)
        result_dict = score_completeness(card_dict)
        result_obj = score_completeness(robot_card)
        assert result_dict["score"] == result_obj["score"]
        assert result_dict["level"] == result_obj["level"]
        assert result_dict["missing_recommended"] == result_obj["missing_recommended"]

    def test_minimal_robotcard(self):
        card_dict = _make_minimal_card()
        robot_card = RobotCard.from_dict(card_dict)
        result = score_completeness(robot_card)
        assert result["level"] == "minimal"


# ------------------------------------------------------------------ #
# Return structure
# ------------------------------------------------------------------ #


class TestReturnStructure:
    def test_keys_present(self):
        result = score_completeness(_make_minimal_card())
        expected_keys = {"score", "level", "missing_recommended", "populated_count", "total_count"}
        assert set(result.keys()) == expected_keys

    def test_total_count_matches_recommended_fields(self):
        result = score_completeness(_make_minimal_card())
        assert result["total_count"] == len(RECOMMENDED_FIELDS)

    def test_populated_plus_missing_equals_total(self):
        result = score_completeness(_make_minimal_card())
        assert result["populated_count"] + len(result["missing_recommended"]) == result["total_count"]
