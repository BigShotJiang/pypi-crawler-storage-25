"""Tests for ROSP validator module."""

import json
import tempfile
from pathlib import Path

import pytest

from rosp_sdk.models import RobotCard
from rosp_sdk.validator import validate_robot_card, validate_card_file


def _make_valid_card_dict() -> dict:
    """Create a minimal valid Robot Card dictionary."""
    return {
        "rosp_version": "0.1",
        "id": "urn:rosp:robot:test:testbot:001",
        "identity": {
            "manufacturer": "TestCorp",
            "model": "TestBot",
            "type": "mobile_robot",
        },
        "hardware": {"weight_kg": 5.0},
        "sensors": [],
        "actuators": [],
        "capabilities": [],
        "integration": {
            "supported_protocols": [{"protocol": "ros2"}],
        },
        "safety": {},
    }


def test_valid_card_passes():
    """A valid Robot Card should have zero validation errors."""
    errors = validate_robot_card(_make_valid_card_dict())
    assert errors == [], f"Expected no errors, got: {errors}"


def test_missing_required_field_fails():
    """A card missing a required field should fail validation."""
    card = _make_valid_card_dict()
    del card["identity"]
    errors = validate_robot_card(card)
    assert len(errors) > 0
    assert any("identity" in e.lower() for e in errors)


def test_multiple_missing_fields():
    """A card missing multiple required fields should report all of them."""
    card = {"rosp_version": "0.1"}
    errors = validate_robot_card(card)
    assert len(errors) > 0


def test_robot_card_instance_accepted():
    """Passing a RobotCard instance (constructed from valid dict) should pass validation."""
    card = RobotCard.from_dict(_make_valid_card_dict())
    errors = validate_robot_card(card)
    assert errors == [], f"Expected no errors for valid RobotCard instance, got: {errors}"


def test_validate_card_file_not_found():
    """validate_card_file with non-existent file should return an error."""
    errors = validate_card_file("/nonexistent/path/robot.json")
    assert len(errors) == 1
    assert "not found" in errors[0].lower()


def test_validate_card_file_invalid_json():
    """validate_card_file with invalid JSON should return an error."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        f.write("{invalid json!!!")
        f.flush()
        errors = validate_card_file(f.name)

    assert len(errors) == 1
    assert "invalid json" in errors[0].lower()


def test_validate_card_file_valid():
    """validate_card_file with a valid JSON card should pass."""
    card = _make_valid_card_dict()
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(card, f)
        f.flush()
        errors = validate_card_file(f.name)

    assert errors == [], f"Expected no errors, got: {errors}"


def test_schema_minimal_card_valid():
    """Phase 0.2: A card with only rosp_version + id + identity should be valid."""
    minimal = {
        "rosp_version": "0.1",
        "id": "urn:rosp:device:ouster:os1:001",
        "identity": {"type": "sensor"},
    }
    errors = validate_robot_card(minimal)
    assert errors == [], f"Minimal card should be valid, got: {errors}"


def test_schema_minimal_card_from_dict():
    """Phase 0.2: from_dict should accept a minimal card (3 required fields only)."""
    minimal = {
        "rosp_version": "0.1",
        "id": "urn:rosp:device:test:minimal:001",
        "identity": {"type": "custom"},
    }
    card = RobotCard.from_dict(minimal)
    assert card.id == "urn:rosp:device:test:minimal:001"
    assert card.identity["type"] == "custom"
    assert card.sensors == []
    assert card.actuators == []
    assert card.hardware == {}
    assert card.integration == {}
