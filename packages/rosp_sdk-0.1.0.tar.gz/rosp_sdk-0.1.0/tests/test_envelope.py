"""Tests for ROSP message envelope."""

import json

import pytest

from rosp_sdk.envelope import ROSPEnvelope


def test_envelope_creation():
    """Envelope should auto-generate id and timestamp."""
    env = ROSPEnvelope(type="describe", path="/robot/tb3_001", body={"depth": "full"})
    assert env.rosp == "0.1"
    assert env.type == "describe"
    assert env.id  # auto-generated UUID
    assert env.timestamp  # auto-generated


def test_envelope_invalid_type():
    """Envelope should reject invalid operation types."""
    with pytest.raises(ValueError, match="Invalid message type"):
        ROSPEnvelope(type="invalid_op", path="/robot/x", body={})


def test_envelope_roundtrip():
    """Envelope should survive JSON roundtrip."""
    env = ROSPEnvelope(
        type="stream",
        path="/fleet/warehouse_1/robot/tb3_001/sensor/lidar/scan",
        body={"action": "subscribe", "topics": ["/sensor/lidar/scan"]},
    )

    json_str = env.to_json()
    env2 = ROSPEnvelope.from_json(json_str)

    assert env2.type == env.type
    assert env2.path == env.path
    assert env2.id == env.id
    assert env2.body == env.body


def test_describe_factory():
    """Factory method should create correct describe request."""
    env = ROSPEnvelope.describe_request("tb3_001", depth="summary")
    assert env.type == "describe"
    assert env.path == "/robot/tb3_001"
    assert env.body["depth"] == "summary"


def test_stream_subscribe_factory():
    """Factory method should create correct stream subscribe."""
    env = ROSPEnvelope.stream_subscribe(
        "tb3_001",
        topics=["/sensor/lidar/scan", "/sensor/imu/orientation"],
        reliability="reliable",
        frequency_hz=10,
    )
    assert env.type == "stream"
    assert env.body["action"] == "subscribe"
    assert len(env.body["topics"]) == 2
    assert env.body["qos"]["reliability"] == "reliable"
    assert env.body["qos"]["frequency_hz"] == 10


def test_discover_factory():
    """Factory method should create discover with wildcard path."""
    env = ROSPEnvelope.discover_request({"type": "mobile_robot", "sensors": ["lidar"]})
    assert env.type == "discover"
    assert env.path == "/fleet/*/robot/*"
    assert env.body["filter"]["type"] == "mobile_robot"


def test_command_factory():
    """Factory method should create correct command request."""
    env = ROSPEnvelope.command_request(
        "tb3_001",
        action="navigate",
        params={"target": {"x": 1.5, "y": 2.3, "theta": 0.0}},
        timeout_ms=15000,
        priority="urgent",
    )
    assert env.type == "command"
    assert env.body["action"] == "navigate"
    assert env.body["timeout_ms"] == 15000
    assert env.body["priority"] == "urgent"


def test_error_response_factory():
    """Factory method should create correct error response."""
    env = ROSPEnvelope.error_response(
        request_id="req-123",
        code=4001,
        category="auth",
        message="Authentication required",
    )
    assert env.type == "error"
    assert env.id == "req-123"
    assert env.body["code"] == 4001
    assert env.body["category"] == "auth"
    assert env.path == "/error"  # Default path, not empty


def test_error_response_with_custom_path():
    """Error response should accept custom path from original request."""
    env = ROSPEnvelope.error_response(
        request_id="req-456",
        code=3001,
        category="robot",
        message="Robot unreachable",
        path="/robot/tb3_001/sensor/lidar",
    )
    assert env.path == "/robot/tb3_001/sensor/lidar"


# --- Negative tests (Issue #13) ---


def test_envelope_empty_type_rejected():
    """Empty string type should be rejected."""
    with pytest.raises(ValueError, match="Invalid message type"):
        ROSPEnvelope(type="", path="/robot/x", body={})


def test_from_dict_missing_type():
    """from_dict with missing 'type' key should raise KeyError."""
    with pytest.raises(KeyError):
        ROSPEnvelope.from_dict({"path": "/x", "body": {}})


def test_from_dict_missing_path():
    """from_dict with missing 'path' key should raise KeyError."""
    with pytest.raises(KeyError):
        ROSPEnvelope.from_dict({"type": "describe", "body": {}})


def test_from_json_invalid_json():
    """from_json with invalid JSON should raise json.JSONDecodeError."""
    import json as json_module
    with pytest.raises(json_module.JSONDecodeError):
        ROSPEnvelope.from_json("not valid json{{{")


def test_all_valid_types_accepted():
    """All 6 valid operation types should be accepted."""
    for op_type in ["describe", "stream", "command", "discover", "coordinate", "error"]:
        env = ROSPEnvelope(type=op_type, path="/test", body={})
        assert env.type == op_type
