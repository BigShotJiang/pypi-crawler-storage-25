"""Tests for ROSPAdapter base class contracts."""

import asyncio

import pytest

from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.models import (
    CommandState,
    DiscoveryInfo,
    HealthStatus,
    AdapterStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
    StreamQoS,
)


class MinimalAdapter(ROSPAdapter):
    """Minimal concrete adapter for testing the base class."""

    async def connect(self):
        self._connected = True

    async def disconnect(self):
        self._connected = False

    async def describe(self, depth="full"):
        return RobotCard(
            rosp_version="0.1",
            id="urn:rosp:robot:test:minimal:001",
            identity={"manufacturer": "Test", "model": "Minimal", "type": "custom"},
            hardware={},
            sensors=[],
            actuators=[],
            capabilities=[],
            integration={"supported_protocols": []},
            safety={},
        )

    async def stream(self, topics, qos=None):
        yield StreamMessage(
            topic="/sensor/test",
            seq=0,
            timestamp=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
            encoding="json",
            data={"value": 42},
        )

    async def discover(self):
        return DiscoveryInfo(
            robot_id="urn:rosp:robot:test:minimal:001",
            model="Minimal",
            manufacturer="Test",
            rosp_version="0.1",
            adapter_version="0.1.0",
            capabilities_summary=[],
            endpoint="test://localhost",
        )

    async def health_check(self):
        return HealthStatus(
            adapter_status=AdapterStatus.HEALTHY,
            robot_status=RobotStatus.CONNECTED,
            latency_ms=1.0,
            uptime_seconds=self.uptime_seconds,
        )


@pytest.mark.asyncio
async def test_uptime_increases():
    """uptime_seconds should increase over time."""
    adapter = MinimalAdapter()
    t1 = adapter.uptime_seconds
    await asyncio.sleep(0.05)
    t2 = adapter.uptime_seconds
    assert t2 > t1


@pytest.mark.asyncio
async def test_is_connected_default_false():
    """is_connected should be False before connect()."""
    adapter = MinimalAdapter()
    assert adapter.is_connected is False


@pytest.mark.asyncio
async def test_connect_sets_connected():
    """connect() should set is_connected to True."""
    adapter = MinimalAdapter()
    await adapter.connect()
    assert adapter.is_connected is True
    await adapter.disconnect()
    assert adapter.is_connected is False


@pytest.mark.asyncio
async def test_context_manager():
    """async with should connect on enter and disconnect on exit."""
    adapter = MinimalAdapter()
    async with adapter:
        assert adapter.is_connected is True
    assert adapter.is_connected is False


@pytest.mark.asyncio
async def test_export_card_json():
    """export_card_json should return valid JSON string."""
    import json

    adapter = MinimalAdapter()
    await adapter.connect()
    card_json = await adapter.export_card_json()
    card_dict = json.loads(card_json)
    assert card_dict["id"] == "urn:rosp:robot:test:minimal:001"
    await adapter.disconnect()


@pytest.mark.asyncio
async def test_command_not_implemented():
    """command() on a Description Mode adapter should raise NotImplementedError."""
    adapter = MinimalAdapter()
    await adapter.connect()

    with pytest.raises(NotImplementedError, match="Control Mode not supported"):
        async for _ in adapter.command("navigate", {"x": 1.0}):
            pass

    await adapter.disconnect()


@pytest.mark.asyncio
async def test_stream_yields_messages():
    """stream() should yield StreamMessage objects."""
    adapter = MinimalAdapter()
    await adapter.connect()

    messages = []
    async for msg in adapter.stream(["/sensor/test"]):
        messages.append(msg)
        break  # Just get one

    assert len(messages) == 1
    assert messages[0].topic == "/sensor/test"
    assert messages[0].data["value"] == 42
    await adapter.disconnect()
