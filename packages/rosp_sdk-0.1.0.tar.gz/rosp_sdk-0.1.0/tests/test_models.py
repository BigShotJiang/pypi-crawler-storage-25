"""Tests for ROSP SDK data models."""

from datetime import datetime, timezone

from rosp_sdk.models import (
    AdapterStatus,
    CommandResult,
    CommandState,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
    StreamQoS,
)


def test_robot_card_roundtrip():
    """Robot Card should serialize and deserialize without data loss."""
    card = RobotCard(
        rosp_version="0.1",
        id="urn:rosp:robot:robotis:turtlebot3:001",
        identity={
            "manufacturer": "ROBOTIS",
            "model": "TurtleBot3 Burger",
            "type": "mobile_robot",
            "firmware_version": "2.1.0",
        },
        hardware={
            "weight_kg": 1.0,
            "dimensions": {"length_m": 0.138, "width_m": 0.178, "height_m": 0.192},
            "payload_kg": 15.0,
        },
        sensors=[
            {
                "sensor_id": "lidar_front",
                "type": "lidar_2d",
                "observation_properties": {"frequency_hz": 5, "measurement_range": {"min_m": 0.12, "max_m": 3.5}},
            }
        ],
        actuators=[
            {"actuator_id": "left_wheel", "type": "wheel", "control_modes": ["velocity"]},
            {"actuator_id": "right_wheel", "type": "wheel", "control_modes": ["velocity"]},
        ],
        capabilities=[{"capability_id": "navigation", "type": "navigation"}],
        integration={
            "supported_protocols": [{"protocol": "ros2", "version": "humble"}],
        },
        safety={"e_stop_available": True},
    )

    # Serialize
    card_dict = card.to_dict()
    assert card_dict["id"] == "urn:rosp:robot:robotis:turtlebot3:001"
    assert card_dict["identity"]["manufacturer"] == "ROBOTIS"
    assert len(card_dict["sensors"]) == 1
    assert len(card_dict["actuators"]) == 2

    # Deserialize
    card2 = RobotCard.from_dict(card_dict)
    assert card2.id == card.id
    assert card2.identity == card.identity
    assert card2.sensors == card.sensors


def test_stream_message_serialization():
    """StreamMessage should serialize with ISO timestamp."""
    msg = StreamMessage(
        topic="/sensor/lidar/scan",
        seq=42,
        timestamp=datetime(2026, 3, 25, 14, 30, 0, tzinfo=timezone.utc),
        encoding="json",
        data={"ranges": [1.0, 1.2, 0.8], "angle_min": -1.57, "angle_max": 1.57},
    )

    d = msg.to_dict()
    assert d["topic"] == "/sensor/lidar/scan"
    assert d["seq"] == 42
    assert "2026-03-25" in d["timestamp"]
    assert d["data"]["ranges"] == [1.0, 1.2, 0.8]


def test_stream_qos_defaults():
    """StreamQoS should have sensible defaults."""
    qos = StreamQoS()
    assert qos.reliability == "best_effort"
    assert qos.frequency_hz == 0
    assert qos.compression == "none"
    assert qos.history_depth == 1


def test_command_result_lifecycle():
    """CommandResult states should follow the spec lifecycle."""
    accepted = CommandResult(state=CommandState.ACCEPTED)
    assert accepted.state.value == "accepted"
    assert accepted.progress is None

    in_progress = CommandResult(state=CommandState.IN_PROGRESS, progress=0.5)
    assert in_progress.progress == 0.5

    completed = CommandResult(
        state=CommandState.COMPLETED,
        result={"final_position": {"x": 1.5, "y": 2.3}},
    )
    assert completed.result is not None

    failed = CommandResult(
        state=CommandState.FAILED,
        error={"code": "NAVIGATION_BLOCKED", "message": "Path blocked by obstacle"},
    )
    assert failed.error["code"] == "NAVIGATION_BLOCKED"


def test_discovery_info():
    """DiscoveryInfo should serialize all fields."""
    info = DiscoveryInfo(
        robot_id="urn:rosp:robot:robotis:turtlebot3:001",
        model="TurtleBot3 Burger",
        manufacturer="ROBOTIS",
        rosp_version="0.1",
        adapter_version="0.1.0",
        capabilities_summary=["navigation", "obstacle_avoidance"],
        endpoint="zenoh://192.168.1.100:7447",
        mode="description",
    )

    d = info.to_dict()
    assert d["robot_id"] == "urn:rosp:robot:robotis:turtlebot3:001"
    assert d["mode"] == "description"
    assert "navigation" in d["capabilities_summary"]


def test_health_status():
    """HealthStatus should report adapter and robot states."""
    health = HealthStatus(
        adapter_status=AdapterStatus.HEALTHY,
        robot_status=RobotStatus.CONNECTED,
        latency_ms=2.3,
        uptime_seconds=3600.0,
        details={"cpu_percent": 12.5, "memory_mb": 256},
    )

    d = health.to_dict()
    assert d["adapter_status"] == "healthy"
    assert d["robot_status"] == "connected"
    assert d["latency_ms"] == 2.3


def test_robot_card_optional_fields():
    """Robot Card optional fields (calibration, end_effector, etc.) should be included when set."""
    card = RobotCard(
        rosp_version="0.1",
        id="urn:rosp:robot:universal-robots:ur5e:ABC123",
        identity={"manufacturer": "Universal Robots", "model": "UR5e", "type": "cobot"},
        hardware={"weight_kg": 20.6, "payload_kg": 5.0, "degrees_of_freedom": 6},
        sensors=[],
        actuators=[],
        capabilities=[],
        integration={"supported_protocols": [{"protocol": "rtde"}]},
        safety={},
        end_effector={
            "tool_center_point": {"x_m": 0, "y_m": 0, "z_m": 0.15},
            "mass_kg": 0.5,
            "type": "gripper_parallel",
        },
        calibration={
            "joint_offsets_rad": [0.001, -0.002, 0.0, 0.001, -0.001, 0.0],
            "calibration_date": "2026-01-15T10:00:00Z",
        },
        coordinate_frames={
            "base_frame": "base_link",
            "tool_frame": "tool0",
            "unit_convention": {"linear": "meters", "angular": "radians"},
        },
    )

    d = card.to_dict()
    assert "end_effector" in d
    assert d["end_effector"]["mass_kg"] == 0.5
    assert "calibration" in d
    assert len(d["calibration"]["joint_offsets_rad"]) == 6
    assert "coordinate_frames" in d
    assert d["coordinate_frames"]["unit_convention"]["angular"] == "radians"


def test_robot_card_optional_fields_omitted_when_none():
    """Optional fields that are None should NOT appear in to_dict output."""
    card = RobotCard(
        rosp_version="0.1",
        id="urn:rosp:robot:test:basic:001",
        identity={"manufacturer": "Test", "model": "Basic", "type": "custom"},
        hardware={},
        sensors=[],
        actuators=[],
        capabilities=[],
        integration={"supported_protocols": []},
        safety={},
        # All optional fields default to None
    )

    d = card.to_dict()
    # These should NOT be in the dict since they're None/empty
    assert "safety" not in d  # empty dict is falsy, omitted
    assert "calibration" not in d
    assert "coordinate_frames" not in d
    assert "end_effector" not in d
    assert "environment" not in d
    assert "diagnostics" not in d
    assert "simulation" not in d
    assert "created_at" not in d
    assert "updated_at" not in d
    # Empty skills list should also be omitted
    assert "skills" not in d


def test_robot_card_from_dict_missing_field_raises_value_error():
    """from_dict with missing required fields should raise ValueError, not KeyError."""
    import pytest

    with pytest.raises(ValueError, match="missing required field"):
        RobotCard.from_dict({"rosp_version": "0.1", "id": "test"})


def test_robot_card_from_dict_lists_all_missing_fields():
    """from_dict error message should list ALL missing fields (Phase 0.2: only 3 required)."""
    try:
        RobotCard.from_dict({"rosp_version": "0.1"})
        assert False, "Should have raised ValueError"
    except ValueError as e:
        msg = str(e)
        assert "id" in msg
        assert "identity" in msg
        # hardware, sensors, actuators, etc. are NO LONGER required (Phase 0.2)
        assert "hardware" not in msg
