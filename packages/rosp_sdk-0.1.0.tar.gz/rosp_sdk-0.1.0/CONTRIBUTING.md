# Contributing to ROSP

Thank you for your interest in ROSP (Robot Open Specification Protocol). We welcome contributions from the robotics community.

## Getting Started

```bash
git clone https://github.com/FaultLine-labs/rosp.git
cd rosp
pip install -e ".[dev,cli]"
pytest
```

## How to Contribute

### Reporting Issues

- Use [GitHub Issues](https://github.com/FaultLine-labs/rosp/issues)
- Include: ROSP version, Python version, OS, adapter (if applicable)
- For bugs: steps to reproduce, expected vs actual behavior

### Pull Requests

1. Fork the repo and create a branch from `main`
2. Write tests for new functionality
3. Ensure all tests pass: `pytest`
4. Ensure code passes lint: `ruff check .`
5. Update documentation if needed
6. Submit a PR with a clear description

### Building a New Adapter

The most impactful contribution is a new adapter. ROSP adapters bridge a robot platform to the protocol.

**Minimum implementation:**

```python
from rosp_sdk import ROSPAdapter, RobotCard, StreamMessage, HealthStatus

class MyAdapter(ROSPAdapter):
    async def connect(self) -> None: ...
    async def disconnect(self) -> None: ...
    async def describe(self, depth="full") -> RobotCard: ...
    async def stream(self, topics, qos=None) -> AsyncIterator[StreamMessage]: ...
    async def discover(self) -> DiscoveryInfo: ...
    async def health_check(self) -> HealthStatus: ...
```

See `adapters/ros2/` for a reference implementation and `docs/spec/ROSP-v0.1-adapter-sdk.md` for the full guide.

**Register your adapter** in `pyproject.toml`:
```toml
[project.entry-points."rosp.adapters"]
myplatform = "my_adapter:MyAdapter"
```

### Adapter Checklist

- [ ] Implements all 5 required `ROSPAdapter` methods
- [ ] Returns a valid `RobotCard` from `describe()`
- [ ] `rosp validate` passes on the generated Robot Card
- [ ] Completeness score is documented
- [ ] Tests included (unit tests, no real hardware needed)
- [ ] README with install instructions and usage example
- [ ] `pyproject.toml` with proper dependencies and entry point

## Code Style

- Python 3.10+
- Formatted with [ruff](https://docs.astral.sh/ruff/) (line length: 100)
- Type hints on all public APIs
- Docstrings on all public classes and methods

## Spec Contributions

Protocol specification changes go through a different process:
1. Open an issue tagged `spec` describing the proposed change
2. Discuss in the issue before submitting a PR
3. Changes to the spec require a version bump (e.g., v0.1 -> v0.2)

## License

By contributing, you agree that your contributions will be licensed under the Apache License 2.0.
