"""Example: Building a custom ROSP adapter for a mock robot.

This shows the minimum implementation needed to create an adapter
for a new robot platform.
"""

import asyncio
import time
import random
from typing import AsyncIterator

from rosp_sdk import (
    ROSPAdapter,
    RobotCard,
    StreamMessage,
    StreamQoS,
    DiscoveryInfo,
    HealthStatus,
    AdapterStatus,
    RobotStatus,
)


class MockRobotAdapter(ROSPAdapter):
    """Adapter for a simulated robot that produces random sensor data."""

    def __init__(self, robot_id: str = "mock-001"):
        super().__init__()
        self._robot_id = robot_id

    async def connect(self) -> None:
        print(f"Connected to mock robot: {self._robot_id}")

    async def disconnect(self) -> None:
        print(f"Disconnected from mock robot: {self._robot_id}")

    async def describe(self, depth: str = "full") -> RobotCard:
        return RobotCard(
            rosp_version="0.1",
            id=f"urn:rosp:robot:mock:simbot:{self._robot_id}",
            identity={
                "type": "mobile_robot",
                "manufacturer": "MockRobotics",
                "model": "SimBot v1",
            },
            hardware={"weight_kg": 5.0, "max_velocity_mps": 1.0},
            sensors=[
                {"sensor_id": "lidar", "type": "lidar_2d", "rate_hz": 10},
                {"sensor_id": "battery", "type": "battery_monitor", "rate_hz": 1},
            ],
            actuators=[{"actuator_id": "base", "type": "differential_drive"}],
            capabilities=["navigation"],
            integration={"protocol": "custom", "transport": "tcp"},
        )

    async def stream(
        self, topics: list[str], qos: StreamQoS | None = None
    ) -> AsyncIterator[StreamMessage]:
        """Generate mock sensor data at ~5 Hz."""
        seq = 0
        while True:
            yield StreamMessage(
                topic="/sensor/lidar/scan",
                seq=seq,
                data={
                    "ranges": [random.uniform(0.1, 10.0) for _ in range(360)],
                    "angle_min": 0.0,
                    "angle_max": 6.28,
                },
            )
            seq += 1
            await asyncio.sleep(0.2)

    async def discover(self) -> DiscoveryInfo:
        return DiscoveryInfo(
            robot_id=self._robot_id,
            model="SimBot v1",
            manufacturer="MockRobotics",
            capabilities_summary=["navigation"],
            endpoint="tcp://localhost:9999",
        )

    async def health_check(self) -> HealthStatus:
        return HealthStatus(
            adapter_status=AdapterStatus.HEALTHY,
            robot_status=RobotStatus.CONNECTED,
            latency_ms=1.2,
            uptime_seconds=self.uptime_seconds,
        )


async def main():
    adapter = MockRobotAdapter()

    async with adapter:
        # Describe the robot
        card = adapter.export_card_json()
        print("Robot Card:", (await card)[:200], "...")

        # Stream 5 messages
        count = 0
        async for msg in adapter.stream(["/sensor/lidar/scan"]):
            print(f"[{msg.seq}] {msg.topic}: {len(msg.data['ranges'])} rays")
            count += 1
            if count >= 5:
                break

        # Health check
        health = await adapter.health_check()
        print(f"Health: {health.adapter_status.value}, uptime: {health.uptime_seconds:.1f}s")


if __name__ == "__main__":
    asyncio.run(main())
