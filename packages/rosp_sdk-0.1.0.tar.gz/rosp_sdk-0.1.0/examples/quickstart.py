"""ROSP Quickstart — create, validate, and score a Robot Card."""

from rosp_sdk import RobotCard, validate_robot_card, score_completeness

# 1. Describe your robot
card = RobotCard(
    rosp_version="0.1",
    id="urn:rosp:robot:robotis:turtlebot3:waffle-001",
    identity={
        "type": "mobile_robot",
        "manufacturer": "ROBOTIS",
        "model": "TurtleBot3 Waffle",
        "firmware_version": "2.1.0",
    },
    hardware={
        "weight_kg": 1.8,
        "max_velocity_mps": 0.26,
        "battery": {"type": "Li-Po", "capacity_wh": 32.4, "nominal_voltage": 11.1},
    },
    sensors=[
        {"sensor_id": "lidar-360", "type": "lidar", "model": "LDS-01", "rate_hz": 5},
        {"sensor_id": "imu", "type": "imu", "model": "ICM-20948", "rate_hz": 100},
        {"sensor_id": "camera-front", "type": "camera_rgb", "model": "RealSense R200"},
    ],
    actuators=[
        {"actuator_id": "base", "type": "wheel", "max_velocity": 0.26},
    ],
    capabilities=[
        {"capability_id": "cap:nav", "name": "Navigation", "type": "navigation",
         "description": "Autonomous waypoint navigation with obstacle avoidance"},
        {"capability_id": "cap:slam", "name": "SLAM Mapping", "type": "perception",
         "description": "Simultaneous localization and mapping"},
    ],
    integration={
        "supported_protocols": [
            {"protocol": "ros2", "version": "humble", "description": "ROS2 DDS interface"},
        ],
    },
)

# 2. Validate against the ROSP schema
errors = validate_robot_card(card)
if errors:
    print("Validation errors:")
    for e in errors:
        print(f"  - {e}")
else:
    print("Robot Card is valid!")

# 3. Score completeness
result = score_completeness(card)
print(f"Completeness: {result['score']:.0f}% ({result['level']})")
print(f"Missing recommended: {len(result['missing_recommended'])} fields")
for field in result["missing_recommended"]:
    print(f"  - {field}")

# 4. Export as JSON
import json

print("\nRobot Card JSON:")
print(json.dumps(card.to_dict(), indent=2)[:500] + "...")
