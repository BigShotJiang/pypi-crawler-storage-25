# rosp-adapter-ros2

ROSP adapter for ROS2 robots. Connects any ROS2 robot to the ROSP ecosystem.

## Install

```bash
pip install rosp-adapter-ros2
```

## Usage

```bash
# Export Robot Card from a running ROS2 robot
rosp-ros2 --robot-id urn:rosp:robot:robotis:turtlebot3:001 \
          --model "TurtleBot3 Burger" --manufacturer ROBOTIS --type mobile_robot \
          --export-card

# Stream sensor data
rosp-ros2 --robot-id urn:rosp:robot:robotis:turtlebot3:001 \
          --model "TurtleBot3 Burger" --manufacturer ROBOTIS --type mobile_robot \
          --stream /sensor/lidar/scan
```

Requires ROS2 Humble or later.
