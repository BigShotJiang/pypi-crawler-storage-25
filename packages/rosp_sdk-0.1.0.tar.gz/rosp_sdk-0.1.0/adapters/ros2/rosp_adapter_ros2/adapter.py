"""ROSP ROS2 Adapter — bridges ROSP to any ROS2 robot.

Connects to a ROS2 robot's native DDS topics, services, and actions,
and exposes them through the standard ROSP adapter interface.

This adapter:
- Reads URDF from /robot_description to build geometry info
- Introspects available topics, services, and actions
- Maps ROS2 QoS profiles to ROSP StreamQoS
- Streams sensor data from ROS2 topics as ROSP StreamMessages
- Generates a complete Robot Card

Requires: ROS2 (Humble or later) installed and sourced.
"""

from __future__ import annotations

import asyncio
import logging
import os
import queue as thread_queue  # Thread-safe queue for ROS2 callback → asyncio bridge
import threading
import time
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Dict, List, Optional

from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.models import (
    AdapterStatus,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
    StreamQoS,
)

logger = logging.getLogger(__name__)


class ROS2Adapter(ROSPAdapter):
    """ROSP adapter for ROS2 robots.

    Connects to a ROS2 robot via rclpy and exposes ROSP Description Mode
    operations (describe, stream, discover, health_check).

    Args:
        config: Adapter configuration dictionary with keys:
            - robot_id: URN identifier (e.g., "urn:rosp:robot:robotis:turtlebot3:001")
            - robot_name: Human-readable name
            - manufacturer: Robot manufacturer
            - model: Robot model name
            - robot_type: ROSP type enum (e.g., "mobile_robot", "cobot")
            - node_name: ROS2 node name for this adapter (default: "rosp_adapter")
            - namespace: ROS2 namespace (default: "")
            - domain_id: ROS2 DDS domain ID (default: from ROS_DOMAIN_ID env)
            - topic_map: Optional mapping of ROSP paths to ROS2 topics
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(config)
        self._node = None
        self._executor = None
        self._spin_task = None
        self._owns_rclpy = False
        # Use thread-safe queues (not asyncio.Queue) because ROS2 callbacks
        # run in the executor's background thread, not the asyncio event loop.
        self._subscriptions: Dict[str, Any] = {}
        self._message_queues: Dict[str, thread_queue.Queue] = {}
        self._seq_lock = threading.Lock()
        self._seq_counters: Dict[str, int] = {}
        self._last_ping_ms: float = 0.0

    async def connect(self) -> None:
        """Initialize rclpy and create a ROS2 node."""
        try:
            import rclpy
        except ImportError:
            raise ImportError(
                "rclpy not found. Ensure ROS2 is installed and sourced:\n"
                "  source /opt/ros/humble/setup.bash\n"
                "  # or: source /opt/ros/jazzy/setup.bash"
            )

        # Initialize rclpy if not already done (handles shared process scenarios)
        if not rclpy.ok():
            rclpy.init()
            self._owns_rclpy = True

        node_name = self.config.get("node_name", "rosp_adapter")
        namespace = self.config.get("namespace", "")

        self._node = rclpy.create_node(node_name, namespace=namespace)
        self._connected = True

        # Start spinning in a background thread
        self._executor = rclpy.executors.SingleThreadedExecutor()
        self._executor.add_node(self._node)
        self._spin_task = asyncio.get_running_loop().run_in_executor(
            None, self._spin_executor
        )

        self._node.get_logger().info(
            f"ROSP ROS2 Adapter connected: {self.config.get('robot_id', 'unknown')}"
        )

    def _spin_executor(self):
        """Spin the ROS2 executor in a background thread."""
        import rclpy
        while self._connected and self._executor:
            try:
                self._executor.spin_once(timeout_sec=0.1)
            except rclpy.executors.ExternalShutdownException:
                break
            except Exception as e:
                if not self._connected:
                    break
                logger.warning(f"Exception in ROS2 executor spin: {e}", exc_info=True)

    async def disconnect(self) -> None:
        """Shut down the ROS2 node and clean up subscriptions."""
        self._connected = False

        # Cancel all subscriptions
        if self._node:
            for sub in self._subscriptions.values():
                self._node.destroy_subscription(sub)
            self._subscriptions.clear()
            self._message_queues.clear()
            self._seq_counters.clear()

            self._node.destroy_node()
            self._node = None

        if self._executor:
            self._executor.shutdown()
            self._executor = None

        # Wait for the spin thread to finish
        if self._spin_task:
            try:
                await asyncio.wait_for(self._spin_task, timeout=5.0)
            except (asyncio.TimeoutError, Exception):
                pass
            self._spin_task = None

    async def describe(self, depth: str = "full") -> RobotCard:
        """Build a Robot Card by introspecting the ROS2 system."""
        self._ensure_connected()

        identity = self._build_identity()
        hardware = self._build_hardware()
        capabilities = self._infer_capabilities()

        if depth == "full":
            sensors = self._discover_sensors()
            actuators = self._discover_actuators()
            integration = self._build_integration()
        else:
            # Summary mode: minimal but schema-valid fields
            sensors = []
            actuators = []
            integration = self._build_integration_stub()

        return RobotCard(
            rosp_version="0.1",
            id=self.config.get("robot_id", "urn:rosp:robot:unknown:unknown:000"),
            identity=identity,
            hardware=hardware,
            sensors=sensors,
            actuators=actuators,
            capabilities=capabilities,
            integration=integration,
            safety=self._build_safety(),
            coordinate_frames={
                "base_frame": "base_link",
                "odom_frame": "odom",
                "map_frame": "map",
                "convention": "ROS_ENU",
                "unit_convention": {
                    "linear": "meters",
                    "angular": "radians",
                    "force": "newtons",
                    "torque": "newton_meters",
                },
            },
            simulation={
                "supported_simulators": ["gazebo", "isaac_sim", "webots"],
            },
            created_at=datetime.now(timezone.utc).isoformat(),
            updated_at=datetime.now(timezone.utc).isoformat(),
        )

    async def stream(
        self, topics: List[str], qos: Optional[StreamQoS] = None
    ) -> AsyncIterator[StreamMessage]:
        """Subscribe to ROS2 topics and yield ROSP StreamMessages."""
        self._ensure_connected()
        qos = qos or StreamQoS()

        # Track ALL requested topics for cleanup (not just mapped ones)
        all_requested = set(topics)

        # Map ROSP paths to ROS2 topics and subscribe
        ros2_topics = self._map_topics(topics)
        for rosp_path, ros2_topic_info in ros2_topics.items():
            self._subscribe_topic(rosp_path, ros2_topic_info, qos)

        # Yield messages from all subscribed topics
        try:
            while self._connected:
                found_message = False
                for rosp_path, q in list(self._message_queues.items()):
                    try:
                        msg = q.get_nowait()
                        found_message = True
                        yield msg
                    except thread_queue.Empty:
                        continue
                if not found_message:
                    await asyncio.sleep(0.005)  # Prevent busy loop
        finally:
            # Clean up ALL requested topics (including partially-subscribed)
            for rosp_path in all_requested:
                self._unsubscribe_topic(rosp_path)

    async def discover(self) -> DiscoveryInfo:
        """Return discovery information for this adapter."""
        capabilities = self._infer_capabilities()
        # Use a placeholder endpoint — real Zenoh endpoint set at transport layer
        endpoint = self.config.get(
            "zenoh_endpoint",
            f"rosp+ros2://{self.config.get('node_name', 'rosp_adapter')}",
        )
        return DiscoveryInfo(
            robot_id=self.config.get("robot_id", "urn:rosp:robot:unknown:unknown:000"),
            model=self.config.get("model", "Unknown"),
            manufacturer=self.config.get("manufacturer", "Unknown"),
            rosp_version="0.1",
            adapter_version="0.1.0",
            capabilities_summary=[c.get("capability_id", "") for c in capabilities],
            endpoint=endpoint,
            mode="description",
        )

    async def health_check(self) -> HealthStatus:
        """Check adapter and ROS2 connection health."""
        if not self._connected or not self._node:
            return HealthStatus(
                adapter_status=AdapterStatus.DISCONNECTED,
                robot_status=RobotStatus.DISCONNECTED,
                latency_ms=0.0,
                uptime_seconds=self.uptime_seconds,
            )

        # Measure latency by checking topic availability
        start = time.monotonic()
        topic_names = self._node.get_topic_names_and_types()
        latency_ms = (time.monotonic() - start) * 1000
        self._last_ping_ms = latency_ms

        has_topics = len(topic_names) > 0
        robot_status = RobotStatus.CONNECTED if has_topics else RobotStatus.DEGRADED

        return HealthStatus(
            adapter_status=AdapterStatus.HEALTHY,
            robot_status=robot_status,
            latency_ms=latency_ms,
            uptime_seconds=self.uptime_seconds,
            details={
                "ros2_topics_count": len(topic_names),
                "active_subscriptions": len(self._subscriptions),
                "node_name": self._node.get_name(),
                "namespace": self._node.get_namespace(),
            },
        )

    # --- Private helpers ---

    def _ensure_connected(self):
        if not self._connected or not self._node:
            raise ConnectionError(
                "Adapter not connected. Call connect() first or use async context manager."
            )

    def _build_identity(self) -> Dict[str, Any]:
        return {
            "manufacturer": self.config.get("manufacturer", "Unknown"),
            "model": self.config.get("model", "Unknown"),
            "type": self.config.get("robot_type", "custom"),
            "firmware_version": self.config.get("firmware_version", "unknown"),
            "description": self.config.get("description", ""),
        }

    def _build_hardware(self) -> Dict[str, Any]:
        """Build hardware section, reading URDF if available."""
        hardware: Dict[str, Any] = {}

        # Try to read URDF from /robot_description parameter
        try:
            urdf_param = self._node.get_parameter("robot_description")
            if urdf_param.value:
                hardware["geometry"] = {
                    "urdf_source": "parameter",
                    "urdf_content_length": len(urdf_param.value),
                }
        except Exception as e:
            # Parameter not available — this is normal for many robots
            logger.debug(f"Could not read robot_description parameter: {e}")

        # Add config-provided hardware specs
        for key in [
            "weight_kg", "dimensions", "payload_kg", "degrees_of_freedom",
            "reach_m", "battery", "compute",
        ]:
            if key in self.config:
                hardware[key] = self.config[key]

        return hardware

    def _build_integration(self) -> Dict[str, Any]:
        """Build the Integration Manifest from ROS2 introspection."""
        # Determine which topics we subscribe to (sensors) vs publish (commands)
        command_msg_types = {
            "geometry_msgs/msg/Twist",
            "trajectory_msgs/msg/JointTrajectory",
            "control_msgs/msg/GripperCommand",
            "std_msgs/msg/Float64MultiArray",
        }

        topics = []
        for topic_name, type_list in self._node.get_topic_names_and_types():
            for msg_type in type_list:
                direction = "subscribe" if msg_type in command_msg_types else "publish"
                topics.append({
                    "name": topic_name,
                    "message_type": msg_type,
                    "direction": direction,
                })

        services = []
        for svc_name, type_list in self._node.get_service_names_and_types():
            for svc_type in type_list:
                services.append({
                    "name": svc_name,
                    "service_type": svc_type,
                })

        return {
            "supported_protocols": [
                {
                    "protocol": "ros2",
                    "version": self._get_ros_distro(),
                    "endpoint": f"ros2://{self._node.get_fully_qualified_name()}",
                }
            ],
            "ros2_interfaces": {
                "topics": topics,
                "services": services,
                **({"domain_id": int(self.config.get("domain_id", os.environ.get("ROS_DOMAIN_ID", 0)))}
                   if self.config.get("domain_id") is not None or "ROS_DOMAIN_ID" in os.environ
                   else {}),
            },
            "discovery": {
                "method": "dds_discovery",
                "heartbeat_interval_s": 1,
            },
        }

    def _build_integration_stub(self) -> Dict[str, Any]:
        """Build a minimal but schema-valid integration section for summary mode."""
        return {
            "supported_protocols": [
                {
                    "protocol": "ros2",
                    "version": self._get_ros_distro(),
                }
            ],
        }

    def _build_safety(self) -> Dict[str, Any]:
        """Build safety section."""
        return {
            "e_stop_available": self.config.get("e_stop_available", False),
            "operational_limits": self.config.get("operational_limits", {}),
        }

    def _discover_sensors(self) -> List[Dict[str, Any]]:
        """Discover sensors by introspecting ROS2 topics."""
        sensors = []
        topic_names_and_types = self._node.get_topic_names_and_types()

        # Values MUST match robot-card.schema.json sensor type enum:
        # lidar, camera_rgb, camera_depth, camera_stereo, camera_thermal,
        # imu, force_torque, encoder, proximity, ultrasonic, gps, rtk_gps,
        # microphone, tactile, barometer, magnetometer, current_sensor,
        # temperature, custom
        type_mapping = {
            "sensor_msgs/msg/LaserScan": ("lidar", "lidar"),
            "sensor_msgs/msg/PointCloud2": ("lidar", "lidar"),
            "sensor_msgs/msg/Image": ("camera_rgb", "camera"),
            "sensor_msgs/msg/CompressedImage": ("camera_rgb", "camera"),
            "sensor_msgs/msg/CameraInfo": (None, None),
            "sensor_msgs/msg/Imu": ("imu", "imu"),
            "nav_msgs/msg/Odometry": ("custom", "odometry"),
            "geometry_msgs/msg/WrenchStamped": ("force_torque", "force_torque"),
            "sensor_msgs/msg/Range": ("proximity", "proximity"),
            "sensor_msgs/msg/NavSatFix": ("gps", "gps"),
            "sensor_msgs/msg/BatteryState": ("current_sensor", "battery"),
            "sensor_msgs/msg/JointState": ("encoder", "encoder"),
            "sensor_msgs/msg/MagneticField": ("magnetometer", "magnetometer"),
            "sensor_msgs/msg/Temperature": ("temperature", "temperature"),
            "sensor_msgs/msg/FluidPressure": ("barometer", "barometer"),
        }

        for topic_name, type_list in topic_names_and_types:
            for msg_type in type_list:
                if msg_type in type_mapping:
                    sensor_type, category = type_mapping[msg_type]
                    if sensor_type is None:
                        continue
                    sensor_id = topic_name.strip("/").replace("/", "_")
                    sensors.append({
                        "sensor_id": sensor_id,
                        "type": sensor_type,
                        "data_format": {
                            "message_type": msg_type,
                            "encoding": "json",
                        },
                        "ros2_topic": topic_name,
                        "coordinate_frame": self._guess_frame(topic_name),
                    })

        return sensors

    def _discover_actuators(self) -> List[Dict[str, Any]]:
        """Discover actuators by looking for command topics."""
        actuators = []
        topic_names_and_types = self._node.get_topic_names_and_types()

        command_topics = {
            "geometry_msgs/msg/Twist": ("differential_drive", "wheel"),
            "trajectory_msgs/msg/JointTrajectory": ("joint_trajectory", "joint"),
            "control_msgs/msg/GripperCommand": ("gripper", "gripper"),
            "std_msgs/msg/Float64MultiArray": ("joint_position", "joint"),
        }

        for topic_name, type_list in topic_names_and_types:
            for msg_type in type_list:
                if msg_type in command_topics:
                    actuator_name, actuator_type = command_topics[msg_type]
                    actuator_id = topic_name.strip("/").replace("/", "_")
                    actuators.append({
                        "actuator_id": actuator_id,
                        "type": actuator_type,
                        "control_modes": ["velocity"] if actuator_type == "wheel" else ["position"],
                        "command_topic": topic_name,
                        "command_type": msg_type,
                    })

        return actuators

    def _infer_capabilities(self) -> List[Dict[str, Any]]:
        """Infer robot capabilities from available topics and services."""
        capabilities = []
        if not self._node:
            return capabilities

        topic_names = [t[0] for t in self._node.get_topic_names_and_types()]

        # Each capability MUST have: capability_id, name, type (per schema)
        nav_topics = {"/cmd_vel", "/odom", "/scan", "/map", "/goal_pose",
                      "/navigate_to_pose", "/plan"}
        if len(set(topic_names) & nav_topics) >= 2:
            capabilities.append({
                "capability_id": "navigation",
                "name": "Autonomous Navigation",
                "type": "navigation",
                "description": "Autonomous navigation using sensor data",
            })

        if "/scan" in topic_names or "/pointcloud" in topic_names:
            capabilities.append({
                "capability_id": "obstacle_avoidance",
                "name": "Obstacle Avoidance",
                "type": "perception",
                "description": "Obstacle detection and avoidance",
            })

        manip_topics = {"/joint_states", "/joint_trajectory_controller",
                        "/gripper_controller"}
        if len(set(topic_names) & manip_topics) >= 1:
            capabilities.append({
                "capability_id": "manipulation",
                "name": "Robotic Manipulation",
                "type": "manipulation",
                "description": "Robotic arm manipulation",
            })

        if "/amcl_pose" in topic_names or "/tf" in topic_names:
            capabilities.append({
                "capability_id": "localization",
                "name": "Self-Localization",
                "type": "perception",
                "description": "Self-localization in environment",
            })

        if "/cmd_vel" in topic_names:
            capabilities.append({
                "capability_id": "teleoperation",
                "name": "Teleoperation",
                "type": "navigation",
                "description": "Remote velocity control",
            })

        return capabilities

    def _map_topics(self, rosp_paths: List[str]) -> Dict[str, Dict[str, Any]]:
        """Map ROSP resource paths to ROS2 topic info."""
        topic_map = self.config.get("topic_map", {})
        all_topics = dict(self._node.get_topic_names_and_types())
        result = {}

        for path in rosp_paths:
            if path in topic_map:
                ros2_topic = topic_map[path]
                msg_types = all_topics.get(ros2_topic, [])
                result[path] = {"ros2_topic": ros2_topic, "msg_types": msg_types}
                continue

            possible_ros2_topics = self._generate_ros2_topic_guesses(path)
            for guess in possible_ros2_topics:
                if guess in all_topics:
                    result[path] = {"ros2_topic": guess, "msg_types": all_topics[guess]}
                    break
            else:
                if path in all_topics:
                    result[path] = {"ros2_topic": path, "msg_types": all_topics[path]}

        return result

    def _generate_ros2_topic_guesses(self, rosp_path: str) -> List[str]:
        """Generate possible ROS2 topic names from a ROSP resource path."""
        parts = rosp_path.strip("/").split("/")
        guesses = []

        if len(parts) >= 1:
            guesses.append(f"/{parts[-1]}")
        if len(parts) >= 2:
            guesses.append(f"/{parts[-2]}/{parts[-1]}")
        guesses.append(rosp_path)

        sensor_map = {
            "lidar": ["/scan", "/lidar/scan", "/laser/scan"],
            "imu": ["/imu", "/imu/data", "/imu/data_raw"],
            "camera": ["/image_raw", "/camera/image_raw", "/camera/rgb/image_raw"],
            "depth": ["/depth/image_raw", "/camera/depth/image_raw"],
            "odom": ["/odom", "/odometry/filtered"],
            "gps": ["/gps/fix", "/navsat/fix"],
            "pointcloud": ["/points", "/pointcloud", "/velodyne_points"],
            "battery": ["/battery_state", "/battery"],
            "joint": ["/joint_states"],
        }

        for keyword, ros2_topics in sensor_map.items():
            if keyword in rosp_path.lower():
                guesses.extend(ros2_topics)

        return guesses

    def _subscribe_topic(
        self, rosp_path: str, topic_info: Dict[str, Any], qos: StreamQoS
    ):
        """Create a ROS2 subscription and wire it to a thread-safe queue."""
        if rosp_path in self._subscriptions:
            return

        ros2_topic = topic_info["ros2_topic"]
        msg_types = topic_info.get("msg_types", [])

        if not msg_types:
            logger.warning(f"No message types for topic {ros2_topic}, skipping")
            return

        msg_class = self._import_message_type(msg_types[0])
        if not msg_class:
            return

        # Use thread-safe queue (Issue #1 fix: ROS2 callbacks run in executor thread)
        q = thread_queue.Queue(maxsize=max(qos.history_depth, 10))
        self._message_queues[rosp_path] = q
        self._seq_counters[rosp_path] = 0

        from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

        ros2_qos = QoSProfile(depth=max(qos.history_depth, 10))
        if qos.reliability == "best_effort":
            ros2_qos.reliability = ReliabilityPolicy.BEST_EFFORT
        else:
            ros2_qos.reliability = ReliabilityPolicy.RELIABLE
        ros2_qos.history = HistoryPolicy.KEEP_LAST

        def callback(msg):
            with self._seq_lock:
                seq = self._seq_counters.get(rosp_path, 0)
                self._seq_counters[rosp_path] = seq + 1

            stream_msg = StreamMessage(
                topic=rosp_path,
                seq=seq,
                timestamp=datetime.now(timezone.utc),
                encoding="json",
                data=self._ros_msg_to_dict(msg),
            )

            try:
                q.put_nowait(stream_msg)
            except thread_queue.Full:
                # Drop oldest message (best-effort behavior)
                try:
                    q.get_nowait()
                    q.put_nowait(stream_msg)
                except (thread_queue.Empty, thread_queue.Full):
                    pass

        sub = self._node.create_subscription(msg_class, ros2_topic, callback, ros2_qos)
        self._subscriptions[rosp_path] = sub

    def _unsubscribe_topic(self, rosp_path: str):
        """Remove a subscription and clean up all related state."""
        if rosp_path in self._subscriptions and self._node:
            self._node.destroy_subscription(self._subscriptions[rosp_path])
            del self._subscriptions[rosp_path]
        self._message_queues.pop(rosp_path, None)
        self._seq_counters.pop(rosp_path, None)

    def _import_message_type(self, type_str: str):
        """Dynamically import a ROS2 message type from its string representation."""
        try:
            parts = type_str.split("/")
            if len(parts) == 3:
                package, _, class_name = parts
                module = __import__(f"{package}.msg", fromlist=[class_name])
                return getattr(module, class_name)
        except (ImportError, AttributeError) as e:
            logger.warning(f"Could not import {type_str}: {e}")
            return None

    def _ros_msg_to_dict(self, msg) -> Dict[str, Any]:
        """Convert a ROS2 message to a Python dictionary."""
        result = {}
        for field_name in msg.get_fields_and_field_types():
            value = getattr(msg, field_name)
            if hasattr(value, "get_fields_and_field_types"):
                result[field_name] = self._ros_msg_to_dict(value)
            elif hasattr(value, "tolist"):
                result[field_name] = value.tolist()
            elif isinstance(value, (list, tuple)):
                if value and hasattr(value[0], "get_fields_and_field_types"):
                    result[field_name] = [self._ros_msg_to_dict(v) for v in value]
                else:
                    result[field_name] = list(value)
            elif isinstance(value, bytes):
                result[field_name] = f"<bytes:{len(value)}>"
            else:
                result[field_name] = value
        return result

    def _guess_frame(self, topic_name: str) -> str:
        """Guess the TF frame for a topic based on common conventions."""
        frame_guesses = {
            "/scan": "base_scan",
            "/imu": "imu_link",
            "/camera": "camera_link",
            "/odom": "odom",
            "/gps": "gps_link",
            "/joint_states": "base_link",
        }
        for pattern, frame in frame_guesses.items():
            if pattern in topic_name:
                return frame
        return "base_link"

    def _get_ros_distro(self) -> str:
        """Get the current ROS2 distribution name."""
        return os.environ.get("ROS_DISTRO", "unknown")
