"""ROSP ROS2 Adapter CLI — run the adapter from the command line.

Usage:
    rosp-ros2 --robot-id urn:rosp:robot:robotis:turtlebot3:001 \
              --model "TurtleBot3 Burger" \
              --manufacturer "ROBOTIS" \
              --type mobile_robot

    rosp-ros2 --config adapter-config.yaml

    rosp-ros2 --export-card > turtlebot3.robot-card.json
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import signal


def parse_args():
    parser = argparse.ArgumentParser(
        description="ROSP ROS2 Adapter — connect a ROS2 robot to the ROSP ecosystem",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Run adapter for TurtleBot3
  rosp-ros2 --robot-id urn:rosp:robot:robotis:turtlebot3:001 \\
            --model "TurtleBot3 Burger" --manufacturer ROBOTIS --type mobile_robot

  # Export Robot Card to JSON
  rosp-ros2 --robot-id urn:rosp:robot:robotis:turtlebot3:001 \\
            --model "TurtleBot3 Burger" --manufacturer ROBOTIS --type mobile_robot \\
            --export-card

  # Stream sensor data
  rosp-ros2 --robot-id urn:rosp:robot:robotis:turtlebot3:001 \\
            --model "TurtleBot3 Burger" --manufacturer ROBOTIS --type mobile_robot \\
            --stream /sensor/lidar/scan
        """,
    )

    parser.add_argument("--robot-id", required=True, help="Robot URN identifier")
    parser.add_argument("--model", default="Unknown", help="Robot model name")
    parser.add_argument("--manufacturer", default="Unknown", help="Manufacturer name")
    parser.add_argument(
        "--type",
        default="custom",
        choices=[
            "mobile_robot", "articulated_arm", "humanoid", "cobot",
            "agv", "amr", "quadruped", "drone",
            "sensor", "actuator", "infrastructure", "station", "controller", "end_effector",
            "custom",
        ],
        help="Robot type",
    )
    parser.add_argument("--node-name", default="rosp_adapter", help="ROS2 node name")
    parser.add_argument("--namespace", default="", help="ROS2 namespace")

    # Actions
    parser.add_argument("--export-card", action="store_true", help="Export Robot Card as JSON and exit")
    parser.add_argument("--stream", nargs="+", help="Stream sensor topics (e.g., /sensor/lidar/scan)")
    parser.add_argument("--health", action="store_true", help="Check health and exit")
    parser.add_argument("--discover", action="store_true", help="Print discovery info and exit")

    return parser.parse_args()


async def run_adapter(args):
    from rosp_adapter_ros2 import ROS2Adapter

    config = {
        "robot_id": args.robot_id,
        "model": args.model,
        "manufacturer": args.manufacturer,
        "robot_type": args.type,
        "node_name": args.node_name,
        "namespace": args.namespace,
    }

    async with ROS2Adapter(config) as adapter:
        if args.export_card:
            card_json = await adapter.export_card_json()
            print(card_json)
            return

        if args.health:
            health = await adapter.health_check()
            print(json.dumps(health.to_dict(), indent=2))
            return

        if args.discover:
            info = await adapter.discover()
            print(json.dumps(info.to_dict(), indent=2))
            return

        if args.stream:
            print(f"Streaming from topics: {args.stream}", file=sys.stderr)
            print(f"Press Ctrl+C to stop.\n", file=sys.stderr)

            count = 0
            async for msg in adapter.stream(args.stream):
                count += 1
                output = {
                    "topic": msg.topic,
                    "seq": msg.seq,
                    "timestamp": msg.timestamp.isoformat(),
                    "data_keys": list(msg.data.keys()),
                }
                print(json.dumps(output))

                if count % 100 == 0:
                    print(f"[{count} messages received]", file=sys.stderr)

            return

        # Default: run adapter and wait
        print(f"ROSP ROS2 Adapter running for: {args.robot_id}", file=sys.stderr)
        print(f"Model: {args.model} ({args.manufacturer})", file=sys.stderr)

        health = await adapter.health_check()
        print(f"Status: {health.adapter_status.value} / {health.robot_status.value}", file=sys.stderr)
        print(f"ROS2 topics: {(health.details or {}).get('ros2_topics_count', 0)}", file=sys.stderr)
        print(f"\nAdapter is running. Press Ctrl+C to stop.", file=sys.stderr)

        # Keep running until interrupted
        stop_event = asyncio.Event()

        def signal_handler():
            stop_event.set()

        loop = asyncio.get_event_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, signal_handler)
            except NotImplementedError:
                # Windows doesn't support add_signal_handler
                pass

        try:
            await stop_event.wait()
        except KeyboardInterrupt:
            pass

        print("\nShutting down adapter...", file=sys.stderr)


def main():
    args = parse_args()

    try:
        asyncio.run(run_adapter(args))
    except KeyboardInterrupt:
        pass
    except ImportError as e:
        print(f"Error: {e}", file=sys.stderr)
        print(
            "\nMake sure ROS2 is installed and sourced:\n"
            "  source /opt/ros/humble/setup.bash",
            file=sys.stderr,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
