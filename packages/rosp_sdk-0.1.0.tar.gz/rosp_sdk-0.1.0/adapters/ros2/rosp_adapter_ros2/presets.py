"""Pre-built configurations for common ROS2 robots.

These presets provide hardware specs, topic mappings, and safety parameters
for robots that are commonly used with ROS2. They supplement the auto-discovery
with accurate manufacturer specifications.

Usage:
    from rosp_adapter_ros2.presets import TURTLEBOT3_BURGER

    adapter = ROS2Adapter(TURTLEBOT3_BURGER)
"""

from __future__ import annotations

import copy
from typing import Any, Dict


TURTLEBOT3_BURGER: Dict[str, Any] = {
    "robot_id": "urn:rosp:robot:robotis:turtlebot3-burger:SERIAL",
    "manufacturer": "ROBOTIS",
    "model": "TurtleBot3 Burger",
    "robot_type": "mobile_robot",
    "firmware_version": "2.1.0",
    "description": "Compact differential-drive mobile robot for education and research.",
    "weight_kg": 1.0,
    "dimensions": {"length_m": 0.138, "width_m": 0.178, "height_m": 0.192},
    "payload_kg": 15.0,
    "battery": {
        "capacity_wh": 25.2,
        "voltage_v": 11.1,
        "runtime_hours": 2.5,
        "charge_time_hours": 2.5,
        "charging_method": "cable",
    },
    "compute": {
        "platform": "Raspberry Pi 4",
        "cpu": "Broadcom BCM2711 quad-core Cortex-A72",
        "ram_gb": 4,
        "os": "Ubuntu 22.04",
        "middleware": ["ROS2 Humble"],
    },
    "e_stop_available": False,
    "operational_limits": {
        "max_linear_velocity_m_s": 0.22,
        "max_angular_velocity_rad_s": 2.84,
    },
    "topic_map": {
        "/sensor/lidar/scan": "/scan",
        "/sensor/imu/data": "/imu",
        "/sensor/odom": "/odom",
        "/actuator/cmd_vel": "/cmd_vel",
    },
    "node_name": "rosp_adapter_tb3",
}


TURTLEBOT3_WAFFLE: Dict[str, Any] = {
    **TURTLEBOT3_BURGER,
    "robot_id": "urn:rosp:robot:robotis:turtlebot3-waffle:SERIAL",
    "model": "TurtleBot3 Waffle Pi",
    "weight_kg": 1.8,
    "dimensions": {"length_m": 0.281, "width_m": 0.306, "height_m": 0.141},
    "payload_kg": 30.0,
    "battery": {
        "capacity_wh": 25.2,
        "voltage_v": 11.1,
        "runtime_hours": 2.0,
        "charge_time_hours": 2.5,
        "charging_method": "cable",
    },
    "operational_limits": {
        "max_linear_velocity_m_s": 0.26,
        "max_angular_velocity_rad_s": 1.82,
    },
    # Waffle Pi has cameras that Burger doesn't — override topic_map
    "topic_map": {
        "/sensor/lidar/scan": "/scan",
        "/sensor/imu/data": "/imu",
        "/sensor/odom": "/odom",
        "/sensor/camera/rgb": "/camera/rgb/image_raw",
        "/sensor/camera/depth": "/camera/depth/image_raw",
        "/actuator/cmd_vel": "/cmd_vel",
    },
    "node_name": "rosp_adapter_waffle",
}


UR5E_COBOT: Dict[str, Any] = {
    "robot_id": "urn:rosp:robot:universal-robots:ur5e:SERIAL",
    "manufacturer": "Universal Robots",
    "model": "UR5e",
    "robot_type": "cobot",
    "firmware_version": "5.14",
    "description": "6-DOF collaborative robot arm, 5kg payload, 850mm reach.",
    "weight_kg": 20.6,
    "payload_kg": 5.0,
    "degrees_of_freedom": 6,
    "reach_m": 0.85,
    "e_stop_available": True,
    "operational_limits": {
        "max_joint_speed_rad_s": 3.14,
        "max_tcp_speed_m_s": 1.0,
        "max_tcp_force_n": 150.0,
        "repeatability_m": 0.00003,
    },
    "topic_map": {
        "/sensor/joint_states": "/joint_states",
        "/sensor/force_torque": "/wrench",
        "/actuator/trajectory": "/scaled_joint_trajectory_controller/joint_trajectory",
    },
    "node_name": "rosp_adapter_ur5e",
}


# Registry of all presets
PRESETS: Dict[str, Dict[str, Any]] = {
    "turtlebot3_burger": TURTLEBOT3_BURGER,
    "turtlebot3_waffle": TURTLEBOT3_WAFFLE,
    "ur5e": UR5E_COBOT,
}


def get_preset(name: str) -> Dict[str, Any]:
    """Get a preset configuration by name.

    Note: Presets use 'SERIAL' as a placeholder in robot_id.
    Replace with the actual serial number before use:
        config = get_preset("turtlebot3_burger")
        config["robot_id"] = config["robot_id"].replace("SERIAL", "my_serial_123")

    Args:
        name: Preset name (e.g., "turtlebot3_burger", "ur5e").

    Returns:
        Configuration dictionary for the adapter.

    Raises:
        KeyError: If preset name is not found.
    """
    if name not in PRESETS:
        available = ", ".join(sorted(PRESETS.keys()))
        raise KeyError(f"Unknown preset '{name}'. Available: {available}")
    return copy.deepcopy(PRESETS[name])
