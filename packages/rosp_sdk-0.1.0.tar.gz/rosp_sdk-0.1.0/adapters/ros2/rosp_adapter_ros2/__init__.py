"""ROSP ROS2 Adapter — connects any ROS2 robot to the ROSP ecosystem.

Usage:
    from rosp_adapter_ros2 import ROS2Adapter

    async with ROS2Adapter(config) as adapter:
        card = await adapter.describe()
        async for msg in adapter.stream(["/sensor/lidar/scan"]):
            print(msg.data)
"""

__version__ = "0.1.0"

from rosp_adapter_ros2.adapter import ROS2Adapter

__all__ = ["ROS2Adapter"]
