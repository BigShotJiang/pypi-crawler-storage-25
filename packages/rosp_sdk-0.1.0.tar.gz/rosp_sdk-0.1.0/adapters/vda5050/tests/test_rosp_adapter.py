"""Tests for VDA 5050 ROSP Adapter integration.

Tests the adapter-of-adapters pattern: VDA5050ROSPAdapter wrapping
VDA5050Adapter to produce ROSP-compliant envelopes.
"""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any, Dict
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from rosp_sdk.models import (
    AdapterStatus,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
)

from rosp_adapter_vda5050.robot_card_builder import build_robot_card
from rosp_adapter_vda5050.stream_converter import (
    TOPIC_MAP,
    convert_state_to_stream_messages,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def sample_config() -> Dict[str, Any]:
    """Minimal VDA 5050 adapter configuration for testing."""
    return {
        "mqtt": {
            "broker": "test-broker.local",
            "port": 1883,
        },
        "vda5050": {
            "interface_name": "uagv",
            "version": "v2",
            "state_rate_hz": 1.0,
            "manufacturers": [
                {
                    "name": "testbot",
                    "serial_numbers": ["tb-001"],
                }
            ],
        },
        "rosp": {
            "adapter_version": "0.1.0",
        },
    }


@pytest.fixture
def sample_state_payload() -> Dict[str, Any]:
    """A minimal VDA 5050 state message payload."""
    return {
        "headerId": 42,
        "timestamp": "2026-03-28T12:00:00.000Z",
        "version": "2.0.0",
        "manufacturer": "testbot",
        "serialNumber": "tb-001",
        "orderId": "order-1",
        "orderUpdateId": 0,
        "lastNodeId": "node-1",
        "lastNodeSequenceId": 0,
        "agvPosition": {
            "x": 10.5,
            "y": 3.2,
            "theta": 1.57,
            "mapId": "warehouse-a",
            "positionInitialized": True,
        },
        "batteryState": {
            "batteryCharge": 78.5,
            "batteryVoltage": 24.1,
            "charging": False,
        },
        "velocity": {
            "vx": 0.5,
            "vy": 0.0,
            "omega": 0.0,
        },
        "operatingMode": "AUTOMATIC",
        "safetyState": {
            "eStop": "NONE",
            "fieldViolation": False,
        },
        "loads": [
            {"loadId": "pallet-42", "loadType": "EURO_PALLET"},
        ],
        "driving": True,
        "paused": False,
        "errors": [],
        "nodeStates": [],
        "edgeStates": [],
        "actionStates": [],
    }


# ---------------------------------------------------------------------------
# robot_card_builder tests
# ---------------------------------------------------------------------------

class TestRobotCardBuilder:
    """Tests for build_robot_card()."""

    def test_build_basic_card(self) -> None:
        """Card has correct ID, identity, and sensors."""
        card = build_robot_card(
            manufacturer="acme",
            serial_number="agv-001",
            config={"interface_name": "uagv", "version": "v2"},
        )

        assert isinstance(card, RobotCard)
        assert card.rosp_version == "0.1"
        assert card.id == "urn:rosp:robot:acme:agv-001"
        assert card.identity["manufacturer"] == "acme"
        assert card.identity["serial_number"] == "agv-001"
        assert card.identity["protocol"] == "vda5050"
        assert len(card.sensors) == 3
        assert card.sensors[0]["name"] == "pose"

    def test_build_card_with_factsheet(self) -> None:
        """Factsheet enriches the card with hardware details."""
        factsheet = {
            "typeSpecification": {
                "agvClass": "forklift",
                "dimensions": {"length": 2.0, "width": 1.2, "height": 1.5},
                "weight": 500,
                "maxSpeed": 2.0,
                "batteryType": "LiFePO4",
            }
        }
        card = build_robot_card(
            manufacturer="acme",
            serial_number="agv-001",
            config={"interface_name": "uagv", "version": "v2"},
            factsheet=factsheet,
        )

        assert card.identity["model"] == "forklift"
        assert card.hardware["weight_kg"] == 500
        assert card.hardware["max_speed_mps"] == 2.0
        assert card.hardware["battery_type"] == "LiFePO4"

    def test_card_serializes_to_dict(self) -> None:
        """RobotCard.to_dict() produces a valid dictionary."""
        card = build_robot_card("mfr", "sn-1", {})
        d = card.to_dict()
        assert d["rosp_version"] == "0.1"
        assert d["id"] == "urn:rosp:robot:mfr:sn-1"
        assert "sensors" in d
        assert "capabilities" in d

    def test_card_capabilities(self) -> None:
        """Card includes default AGV capabilities."""
        card = build_robot_card("mfr", "sn-1", {})
        cap_names = [c["name"] for c in card.capabilities]
        assert "navigate" in cap_names
        assert "charge" in cap_names
        assert "pick" in cap_names
        assert "drop" in cap_names


# ---------------------------------------------------------------------------
# stream_converter tests
# ---------------------------------------------------------------------------

class TestStreamConverter:
    """Tests for convert_state_to_stream_messages()."""

    def test_converts_pose(self, sample_state_payload: Dict[str, Any]) -> None:
        """Pose topic extracts agvPosition from state."""
        seq = {}
        msgs = convert_state_to_stream_messages(
            sample_state_payload, ["/sensor/pose"], seq
        )
        assert len(msgs) == 1
        assert msgs[0].topic == "/sensor/pose"
        assert msgs[0].data["x"] == 10.5
        assert msgs[0].seq == 1
        assert seq["/sensor/pose"] == 1

    def test_converts_battery(self, sample_state_payload: Dict[str, Any]) -> None:
        """Battery topic extracts batteryState."""
        seq = {}
        msgs = convert_state_to_stream_messages(
            sample_state_payload, ["/sensor/battery"], seq
        )
        assert len(msgs) == 1
        assert msgs[0].data["batteryCharge"] == 78.5

    def test_converts_velocity(self, sample_state_payload: Dict[str, Any]) -> None:
        """Velocity topic extracts velocity field."""
        seq = {}
        msgs = convert_state_to_stream_messages(
            sample_state_payload, ["/sensor/velocity"], seq
        )
        assert len(msgs) == 1
        assert msgs[0].data["vx"] == 0.5

    def test_converts_multiple_topics(self, sample_state_payload: Dict[str, Any]) -> None:
        """Multiple topics produce multiple messages."""
        seq = {}
        msgs = convert_state_to_stream_messages(
            sample_state_payload,
            ["/sensor/pose", "/sensor/battery", "/sensor/velocity"],
            seq,
        )
        assert len(msgs) == 3
        topics = {m.topic for m in msgs}
        assert topics == {"/sensor/pose", "/sensor/battery", "/sensor/velocity"}

    def test_unknown_topic_ignored(self, sample_state_payload: Dict[str, Any]) -> None:
        """Topics not in TOPIC_MAP are silently ignored."""
        seq = {}
        msgs = convert_state_to_stream_messages(
            sample_state_payload, ["/sensor/lidar"], seq
        )
        assert len(msgs) == 0

    def test_missing_field_skipped(self) -> None:
        """If the VDA field is missing from state, no message is produced."""
        state = {"timestamp": "2026-03-28T12:00:00Z"}
        seq = {}
        msgs = convert_state_to_stream_messages(state, ["/sensor/pose"], seq)
        assert len(msgs) == 0

    def test_seq_counter_increments(self, sample_state_payload: Dict[str, Any]) -> None:
        """Sequence counter increments across calls."""
        seq: Dict[str, int] = {}
        convert_state_to_stream_messages(sample_state_payload, ["/sensor/pose"], seq)
        convert_state_to_stream_messages(sample_state_payload, ["/sensor/pose"], seq)
        assert seq["/sensor/pose"] == 2

    def test_timestamp_parsing(self) -> None:
        """VDA 5050 ISO timestamp is correctly parsed."""
        state = {
            "timestamp": "2026-03-28T12:00:00.000Z",
            "agvPosition": {"x": 1, "y": 2, "theta": 0},
        }
        seq = {}
        msgs = convert_state_to_stream_messages(state, ["/sensor/pose"], seq)
        assert msgs[0].timestamp.year == 2026
        assert msgs[0].timestamp.month == 3

    def test_status_topics(self, sample_state_payload: Dict[str, Any]) -> None:
        """Safety and mode status topics work."""
        seq = {}
        msgs = convert_state_to_stream_messages(
            sample_state_payload,
            ["/status/safety", "/status/mode"],
            seq,
        )
        assert len(msgs) == 2
        safety_msg = next(m for m in msgs if m.topic == "/status/safety")
        assert safety_msg.data["eStop"] == "NONE"
        mode_msg = next(m for m in msgs if m.topic == "/status/mode")
        assert mode_msg.data == {"value": "AUTOMATIC"}

    def test_topic_map_completeness(self) -> None:
        """All TOPIC_MAP entries are documented."""
        expected = {
            "/sensor/pose", "/sensor/battery", "/sensor/velocity",
            "/sensor/loads", "/status/safety", "/status/mode",
        }
        assert set(TOPIC_MAP.keys()) == expected


# ---------------------------------------------------------------------------
# VDA5050ROSPAdapter tests (mocked MQTT)
# ---------------------------------------------------------------------------

class TestVDA5050ROSPAdapter:
    """Tests for the ROSP adapter wrapper."""

    @pytest.fixture
    def adapter(self, sample_config: Dict[str, Any]):
        """Create VDA5050ROSPAdapter without connecting."""
        from rosp_adapter_vda5050.rosp_adapter import VDA5050ROSPAdapter
        return VDA5050ROSPAdapter(sample_config)

    def test_init_state(self, adapter) -> None:
        """Adapter starts disconnected with no devices."""
        assert adapter.is_connected is False
        assert adapter._vda_adapter is None
        assert adapter._known_devices == {}

    @pytest.mark.asyncio
    async def test_discover(self, adapter) -> None:
        """discover() returns valid DiscoveryInfo from config."""
        info = await adapter.discover()

        assert isinstance(info, DiscoveryInfo)
        assert info.robot_id == "urn:rosp:robot:testbot:tb-001"
        assert info.manufacturer == "testbot"
        assert info.rosp_version == "0.1"
        assert info.adapter_version == "0.1.0"
        assert info.endpoint == "mqtt://test-broker.local:1883"
        assert info.mode == "description"
        assert "stream" in info.capabilities_summary

    @pytest.mark.asyncio
    async def test_describe(self, adapter) -> None:
        """describe() returns valid RobotCard from config."""
        card = await adapter.describe()

        assert isinstance(card, RobotCard)
        assert card.id == "urn:rosp:robot:testbot:tb-001"
        assert card.identity["manufacturer"] == "testbot"
        assert card.identity["serial_number"] == "tb-001"
        assert card.identity["protocol"] == "vda5050"
        assert len(card.sensors) == 3

    @pytest.mark.asyncio
    async def test_describe_with_known_device(self, adapter) -> None:
        """describe() prefers MQTT-discovered devices over config."""
        adapter._known_devices["realbot:rb-999"] = {
            "manufacturer": "realbot",
            "serial_number": "rb-999",
        }
        card = await adapter.describe()
        assert card.id == "urn:rosp:robot:realbot:rb-999"

    @pytest.mark.asyncio
    async def test_health_check_disconnected(self, adapter) -> None:
        """health_check() returns DISCONNECTED when not connected."""
        health = await adapter.health_check()

        assert isinstance(health, HealthStatus)
        assert health.adapter_status == AdapterStatus.DISCONNECTED
        assert health.robot_status == RobotStatus.DISCONNECTED
        assert health.uptime_seconds >= 0

    @pytest.mark.asyncio
    async def test_health_check_connected(self, adapter) -> None:
        """health_check() returns HEALTHY when connected with devices."""
        adapter._connected = True
        adapter._mqtt_connected = True
        adapter._known_devices["bot:001"] = {"manufacturer": "bot", "serial_number": "001"}

        # Mock the VDA adapter with a running MQTT task
        mock_vda = MagicMock()
        mock_task = MagicMock()
        mock_task.done.return_value = False
        mock_vda._mqtt._task = mock_task
        adapter._vda_adapter = mock_vda

        health = await adapter.health_check()

        assert health.adapter_status == AdapterStatus.HEALTHY
        assert health.robot_status == RobotStatus.CONNECTED
        assert health.details["known_devices"] == 1
        assert health.details["mqtt_task_alive"] is True

    @pytest.mark.asyncio
    async def test_health_check_degraded(self, adapter) -> None:
        """health_check() returns DEGRADED when MQTT task is dead."""
        adapter._connected = True
        adapter._mqtt_connected = True

        mock_vda = MagicMock()
        mock_task = MagicMock()
        mock_task.done.return_value = True  # Task has crashed
        mock_vda._mqtt._task = mock_task
        adapter._vda_adapter = mock_vda

        health = await adapter.health_check()
        assert health.adapter_status == AdapterStatus.DEGRADED

    @pytest.mark.asyncio
    async def test_discover_serializes(self, adapter) -> None:
        """DiscoveryInfo serializes to a valid dict."""
        info = await adapter.discover()
        d = info.to_dict()
        assert d["robot_id"].startswith("urn:rosp:robot:")
        assert d["mode"] == "description"

    @pytest.mark.asyncio
    async def test_stream_invalid_topics(self, adapter) -> None:
        """stream() with no valid topics returns immediately."""
        messages = []
        async for msg in adapter.stream(["/invalid/topic"]):
            messages.append(msg)
        assert messages == []

    @pytest.mark.asyncio
    async def test_connect_disconnect(self, sample_config: Dict[str, Any]) -> None:
        """connect/disconnect lifecycle with mocked MQTT."""
        from rosp_adapter_vda5050.rosp_adapter import VDA5050ROSPAdapter

        adapter = VDA5050ROSPAdapter(sample_config)

        with patch("rosp_adapter_vda5050.adapter.MQTTClient") as MockMQTT:
            mock_mqtt_instance = AsyncMock()
            MockMQTT.return_value = mock_mqtt_instance

            await adapter.connect()
            assert adapter.is_connected is True
            assert adapter._mqtt_connected is True

            await adapter.disconnect()
            assert adapter.is_connected is False
            assert adapter._mqtt_connected is False
