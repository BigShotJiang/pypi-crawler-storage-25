"""Tests for VDA 5050 order -> mission lifecycle mapping."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import MagicMock, call, patch

import pytest


# ---------------------------------------------------------------------------
# Minimal order-handler logic under test (self-contained, no adapter import)
# ---------------------------------------------------------------------------

class OrderTracker:
    """Tracks VDA 5050 orders and maps them to RoboTrace missions.

    Each (serialNumber, orderId) pair corresponds to one RoboTrace mission.
    Order updates (same orderId, higher orderUpdateId) continue the same mission.
    """

    def __init__(self) -> None:
        # Key: (serial, orderId) -> mission state
        self._missions: dict[tuple[str, str], dict[str, Any]] = {}

    def handle_order(self, serial: str, order: dict[str, Any]) -> dict[str, Any]:
        """Process an incoming VDA 5050 order message.

        Returns an action dict describing what happened:
          {"action": "started", "mission_id": ...}
          {"action": "updated", "mission_id": ...}
        """
        order_id = order["orderId"]
        update_id = order.get("orderUpdateId", 0)
        key = (serial, order_id)

        if key not in self._missions:
            mission_id = f"mission-{serial}-{order_id}"
            self._missions[key] = {
                "mission_id": mission_id,
                "order_id": order_id,
                "update_id": update_id,
                "serial": serial,
                "status": "active",
                "nodes": order.get("nodes", []),
                "edges": order.get("edges", []),
                "phases": [],
                "decisions": [],
            }
            return {"action": "started", "mission_id": mission_id}
        else:
            existing = self._missions[key]
            if update_id > existing["update_id"]:
                existing["update_id"] = update_id
                existing["nodes"] = order.get("nodes", existing["nodes"])
                existing["edges"] = order.get("edges", existing["edges"])
                return {"action": "updated", "mission_id": existing["mission_id"]}
            return {"action": "ignored", "mission_id": existing["mission_id"]}

    def handle_state(self, serial: str, state: dict[str, Any]) -> dict[str, Any] | None:
        """Process a VDA 5050 state message for node/action progress.

        Returns a progress dict or None if no matching mission.
        """
        order_id = state.get("orderId", "")
        key = (serial, order_id)
        mission = self._missions.get(key)
        if mission is None:
            return None

        progress: dict[str, Any] = {
            "mission_id": mission["mission_id"],
            "phases": [],
            "decisions": [],
            "completed": False,
        }

        # Map nodeStates to phases
        node_states = state.get("nodeStates", [])
        for ns in node_states:
            phase = {
                "name": f"node_{ns.get('nodeId', 'unknown')}",
                "sequence_id": ns.get("sequenceId", 0),
                "released": ns.get("released", False),
            }
            progress["phases"].append(phase)
            if phase not in mission["phases"]:
                mission["phases"].append(phase)

        # Map actionStates to decisions
        action_states = state.get("actionStates", [])
        for action in action_states:
            if action.get("actionStatus") == "FINISHED":
                decision = {
                    "name": f"action_{action.get('actionType', 'unknown')}",
                    "action_id": action.get("actionId", ""),
                    "status": "FINISHED",
                    "result": action.get("resultDescription", ""),
                }
                progress["decisions"].append(decision)
                if decision not in mission["decisions"]:
                    mission["decisions"].append(decision)

        # Check for completion: all nodes visited, not driving
        if not state.get("driving", True) and not node_states:
            progress["completed"] = True
            mission["status"] = "completed"

        return progress

    def get_mission(self, serial: str, order_id: str) -> dict[str, Any] | None:
        return self._missions.get((serial, order_id))


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def _make_order(serial: str, order_id: str, update_id: int = 0,
                nodes: list | None = None, edges: list | None = None) -> dict[str, Any]:
    """Helper to build a VDA 5050 order message."""
    return {
        "headerId": 1,
        "timestamp": "2026-03-28T12:00:00Z",
        "version": "2.0.0",
        "manufacturer": "RoboSwarm",
        "serialNumber": serial,
        "orderId": order_id,
        "orderUpdateId": update_id,
        "nodes": nodes or [
            {"nodeId": "N1", "sequenceId": 0, "released": True,
             "nodePosition": {"x": 0.0, "y": 0.0, "theta": 0.0, "mapId": "test"},
             "actions": []},
            {"nodeId": "N2", "sequenceId": 2, "released": True,
             "nodePosition": {"x": 5.0, "y": 0.0, "theta": 0.0, "mapId": "test"},
             "actions": []},
        ],
        "edges": edges or [
            {"edgeId": "e0", "sequenceId": 1, "released": True,
             "startNodeId": "N1", "endNodeId": "N2", "actions": []},
        ],
    }


def _make_state(serial: str, order_id: str, driving: bool = True,
                node_states: list | None = None,
                action_states: list | None = None) -> dict[str, Any]:
    """Helper to build a VDA 5050 state message."""
    return {
        "headerId": 10,
        "timestamp": "2026-03-28T12:00:05Z",
        "version": "2.0.0",
        "manufacturer": "RoboSwarm",
        "serialNumber": serial,
        "orderId": order_id,
        "orderUpdateId": 0,
        "driving": driving,
        "paused": False,
        "nodeStates": node_states if node_states is not None else [],
        "edgeStates": [],
        "actionStates": action_states if action_states is not None else [],
    }


class TestNewOrderCreatesMission:
    """A new orderId for a device creates a new mission."""

    def test_new_order_creates_mission(self):
        tracker = OrderTracker()
        order = _make_order("TB3-001", "order-001")
        result = tracker.handle_order("TB3-001", order)

        assert result["action"] == "started"
        assert "mission" in result["mission_id"]
        mission = tracker.get_mission("TB3-001", "order-001")
        assert mission is not None
        assert mission["status"] == "active"
        assert len(mission["nodes"]) == 2

    def test_new_order_different_device(self):
        tracker = OrderTracker()
        result1 = tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))
        result2 = tracker.handle_order("TB3-002", _make_order("TB3-002", "o-1"))

        assert result1["action"] == "started"
        assert result2["action"] == "started"
        assert result1["mission_id"] != result2["mission_id"]


class TestOrderUpdate:
    """Same orderId with higher updateId continues the mission."""

    def test_order_update_higher_id(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1", update_id=0))
        result = tracker.handle_order(
            "TB3-001",
            _make_order("TB3-001", "o-1", update_id=1, nodes=[
                {"nodeId": "N1", "sequenceId": 0, "released": True,
                 "nodePosition": {"x": 0, "y": 0, "theta": 0, "mapId": "t"}, "actions": []},
                {"nodeId": "N3", "sequenceId": 2, "released": True,
                 "nodePosition": {"x": 10, "y": 0, "theta": 0, "mapId": "t"}, "actions": []},
            ]),
        )
        assert result["action"] == "updated"
        mission = tracker.get_mission("TB3-001", "o-1")
        assert mission["update_id"] == 1
        # Nodes should be updated
        assert mission["nodes"][1]["nodeId"] == "N3"

    def test_order_update_same_id_ignored(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1", update_id=0))
        result = tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1", update_id=0))
        assert result["action"] == "ignored"


class TestNodeProgressCreatesPhases:
    """nodeStates in state messages create phases."""

    def test_node_progress(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))

        state = _make_state("TB3-001", "o-1", driving=True, node_states=[
            {"nodeId": "N1", "sequenceId": 0, "released": True},
        ])
        progress = tracker.handle_state("TB3-001", state)

        assert progress is not None
        assert len(progress["phases"]) == 1
        assert progress["phases"][0]["name"] == "node_N1"
        assert progress["phases"][0]["sequence_id"] == 0

    def test_multiple_node_states(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))

        state = _make_state("TB3-001", "o-1", driving=True, node_states=[
            {"nodeId": "N1", "sequenceId": 0, "released": True},
            {"nodeId": "N2", "sequenceId": 2, "released": True},
        ])
        progress = tracker.handle_state("TB3-001", state)
        assert len(progress["phases"]) == 2


class TestActionFinishedLogsDecision:
    """actionStatus FINISHED -> decision logged."""

    def test_action_finished(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))

        state = _make_state("TB3-001", "o-1", driving=True, action_states=[
            {
                "actionId": "a-1",
                "actionType": "pick",
                "actionStatus": "FINISHED",
                "resultDescription": "Pallet picked successfully",
            },
        ])
        progress = tracker.handle_state("TB3-001", state)

        assert len(progress["decisions"]) == 1
        assert progress["decisions"][0]["name"] == "action_pick"
        assert progress["decisions"][0]["status"] == "FINISHED"
        assert "Pallet picked" in progress["decisions"][0]["result"]

    def test_action_running_not_logged(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))

        state = _make_state("TB3-001", "o-1", driving=True, action_states=[
            {"actionId": "a-1", "actionType": "pick", "actionStatus": "RUNNING"},
        ])
        progress = tracker.handle_state("TB3-001", state)
        assert len(progress["decisions"]) == 0


class TestOrderCompletion:
    """All nodes done -> mission ended."""

    def test_order_completion(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))

        # Final state: not driving, no remaining nodeStates
        state = _make_state("TB3-001", "o-1", driving=False, node_states=[])
        progress = tracker.handle_state("TB3-001", state)

        assert progress["completed"] is True
        mission = tracker.get_mission("TB3-001", "o-1")
        assert mission["status"] == "completed"

    def test_still_driving_not_completed(self):
        tracker = OrderTracker()
        tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))

        state = _make_state("TB3-001", "o-1", driving=True, node_states=[])
        progress = tracker.handle_state("TB3-001", state)
        assert progress["completed"] is False


class TestMultipleDevices:
    """Separate missions per device."""

    def test_separate_missions_per_device(self):
        tracker = OrderTracker()
        r1 = tracker.handle_order("TB3-001", _make_order("TB3-001", "o-1"))
        r2 = tracker.handle_order("TB3-002", _make_order("TB3-002", "o-1"))

        assert r1["mission_id"] != r2["mission_id"]

        # Progress on device 1 doesn't affect device 2
        state1 = _make_state("TB3-001", "o-1", driving=False, node_states=[])
        progress1 = tracker.handle_state("TB3-001", state1)
        assert progress1["completed"] is True

        mission2 = tracker.get_mission("TB3-002", "o-1")
        assert mission2["status"] == "active"

    def test_unknown_device_state_returns_none(self):
        tracker = OrderTracker()
        state = _make_state("TB3-999", "o-unknown", driving=True)
        result = tracker.handle_state("TB3-999", state)
        assert result is None

    def test_three_devices_concurrent(self):
        tracker = OrderTracker()
        serials = ["AGV-A", "AGV-B", "AGV-C"]
        for s in serials:
            tracker.handle_order(s, _make_order(s, f"order-{s}"))

        for s in serials:
            m = tracker.get_mission(s, f"order-{s}")
            assert m is not None
            assert m["serial"] == s
