"""Tests for VDA 5050 state handler — telemetry extraction and rate limiting.

Tests the StateHandler class directly using a fake RoboTrace client,
as well as standalone parsing logic for VDA 5050 state messages.
"""

from __future__ import annotations

import json
import math
import time
from typing import Any
from unittest.mock import MagicMock

import pytest

from rosp_adapter_vda5050.state_handler import StateHandler
from rosp_adapter_vda5050.mqtt_client import parse_vda5050_topic


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


class FakeRoboTrace:
    """Minimal fake RoboTrace client that records log() calls."""

    def __init__(self) -> None:
        self.logged: list[tuple[str, Any]] = []

    def log(self, path: str, data: Any) -> None:
        self.logged.append((path, data))


@pytest.fixture
def fake_rt() -> FakeRoboTrace:
    return FakeRoboTrace()


@pytest.fixture
def handler(fake_rt: FakeRoboTrace) -> StateHandler:
    """StateHandler wired to a fake RoboTrace client."""
    return StateHandler(
        get_rt_client=lambda device_id: fake_rt,
        min_interval_s=0.0,  # Disable rate limiting for tests
    )


def _make_state_payload(
    x: float = 1.0,
    y: float = 2.0,
    theta: float = 0.5,
    battery_charge: float = 87.5,
    vx: float = 0.3,
    vy: float = 0.0,
    omega: float = 0.1,
    errors: list[dict[str, Any]] | None = None,
    estop: str = "NONE",
    field_violation: bool = False,
    driving: bool | None = None,
    paused: bool | None = None,
    operating_mode: str | None = None,
    loads: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Build a minimal VDA 5050 state payload for testing."""
    payload: dict[str, Any] = {
        "headerId": 1,
        "timestamp": "2026-03-28T12:00:00Z",
        "version": "2.0.0",
        "manufacturer": "test_mfr",
        "serialNumber": "agv_001",
        "orderId": "",
        "orderUpdateId": 0,
        "agvPosition": {
            "x": x,
            "y": y,
            "theta": theta,
            "positionInitialized": True,
            "mapId": "warehouse-1",
        },
        "batteryState": {
            "batteryCharge": battery_charge,
            "batteryVoltage": 48.2,
            "charging": False,
            "reach": 12000,
        },
        "velocity": {
            "vx": vx,
            "vy": vy,
            "omega": omega,
        },
        "safetyState": {
            "eStop": estop,
            "fieldViolation": field_violation,
        },
        "nodeStates": [],
        "edgeStates": [],
        "actionStates": [],
        "errors": errors or [],
    }

    if driving is not None:
        payload["driving"] = driving
    if paused is not None:
        payload["paused"] = paused
    if operating_mode is not None:
        payload["operatingMode"] = operating_mode
    if loads is not None:
        payload["loads"] = loads

    return payload


# ---------------------------------------------------------------------------
# Position extraction tests
# ---------------------------------------------------------------------------


class TestPositionExtraction:
    """Verify agvPosition is correctly mapped to Pose3D."""

    @pytest.mark.asyncio
    async def test_position_logged_as_pose3d(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(x=3.0, y=4.0, theta=1.57)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        pose_entries = [(p, d) for p, d in fake_rt.logged if p == "robot/pose"]
        assert len(pose_entries) == 1

        _, pose = pose_entries[0]
        assert pose.x == 3.0
        assert pose.y == 4.0
        assert pose.z == 0.0
        assert abs(pose.qz - math.sin(1.57 / 2.0)) < 1e-6
        assert abs(pose.qw - math.cos(1.57 / 2.0)) < 1e-6

    @pytest.mark.asyncio
    async def test_position_theta_zero(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(x=0.0, y=0.0, theta=0.0)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        pose_entries = [(p, d) for p, d in fake_rt.logged if p == "robot/pose"]
        _, pose = pose_entries[0]
        assert pose.qz == pytest.approx(0.0)
        assert pose.qw == pytest.approx(1.0)

    @pytest.mark.asyncio
    async def test_missing_position_no_log(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload()
        del payload["agvPosition"]
        await handler.handle("test_mfr", "agv_001", "state", payload)

        pose_entries = [(p, d) for p, d in fake_rt.logged if p == "robot/pose"]
        assert len(pose_entries) == 0


# ---------------------------------------------------------------------------
# Battery extraction tests
# ---------------------------------------------------------------------------


class TestBatteryExtraction:
    """Verify batteryState is mapped to Scalar telemetry."""

    @pytest.mark.asyncio
    async def test_battery_charge_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(battery_charge=92.3)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        battery_entries = [(p, d) for p, d in fake_rt.logged if p == "sensors/battery"]
        assert len(battery_entries) == 1
        _, scalar = battery_entries[0]
        assert scalar.value == 92.3

    @pytest.mark.asyncio
    async def test_battery_voltage_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload()
        await handler.handle("test_mfr", "agv_001", "state", payload)

        voltage_entries = [
            (p, d) for p, d in fake_rt.logged if p == "sensors/battery_voltage"
        ]
        assert len(voltage_entries) == 1
        _, scalar = voltage_entries[0]
        assert scalar.value == 48.2

    @pytest.mark.asyncio
    async def test_missing_battery_no_log(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload()
        del payload["batteryState"]
        await handler.handle("test_mfr", "agv_001", "state", payload)

        battery_entries = [(p, d) for p, d in fake_rt.logged if p == "sensors/battery"]
        assert len(battery_entries) == 0


# ---------------------------------------------------------------------------
# Velocity extraction tests
# ---------------------------------------------------------------------------


class TestVelocityExtraction:
    """Verify velocity is mapped to Twist."""

    @pytest.mark.asyncio
    async def test_velocity_logged_as_twist(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(vx=0.5, vy=0.1, omega=0.2)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        vel_entries = [(p, d) for p, d in fake_rt.logged if p == "robot/velocity"]
        assert len(vel_entries) == 1
        _, twist = vel_entries[0]
        assert twist.linear_x == 0.5
        assert twist.linear_y == 0.1
        assert twist.angular_z == 0.2

    @pytest.mark.asyncio
    async def test_missing_velocity_no_log(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload()
        del payload["velocity"]
        await handler.handle("test_mfr", "agv_001", "state", payload)

        vel_entries = [(p, d) for p, d in fake_rt.logged if p == "robot/velocity"]
        assert len(vel_entries) == 0


# ---------------------------------------------------------------------------
# Error extraction tests
# ---------------------------------------------------------------------------


class TestErrorExtraction:
    """Verify errors are logged as events."""

    @pytest.mark.asyncio
    async def test_errors_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        errors = [
            {
                "errorType": "NAVIGATION_ERROR",
                "errorLevel": "WARNING",
                "errorDescription": "Path blocked",
            },
            {
                "errorType": "HARDWARE_FAULT",
                "errorLevel": "FATAL",
                "errorDescription": "Motor overheat",
            },
        ]
        payload = _make_state_payload(errors=errors)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        error_entries = [(p, d) for p, d in fake_rt.logged if p == "events/errors"]
        assert len(error_entries) == 2

        # First error is WARNING level
        assert error_entries[0][1].level == "WARNING"
        assert "NAVIGATION_ERROR" in error_entries[0][1].message

        # Second error (FATAL) is mapped to ERROR level
        assert error_entries[1][1].level == "ERROR"
        assert "HARDWARE_FAULT" in error_entries[1][1].message

    @pytest.mark.asyncio
    async def test_no_errors_no_log(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(errors=[])
        await handler.handle("test_mfr", "agv_001", "state", payload)

        error_entries = [(p, d) for p, d in fake_rt.logged if p == "events/errors"]
        assert len(error_entries) == 0


# ---------------------------------------------------------------------------
# Safety state tests
# ---------------------------------------------------------------------------


class TestSafetyState:
    """Verify safety events are logged for e-stop and field violations."""

    @pytest.mark.asyncio
    async def test_estop_active_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(estop="MANUAL")
        await handler.handle("test_mfr", "agv_001", "state", payload)

        safety_entries = [(p, d) for p, d in fake_rt.logged if p == "events/safety"]
        assert len(safety_entries) == 1
        assert "E-STOP" in safety_entries[0][1].message

    @pytest.mark.asyncio
    async def test_field_violation_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(field_violation=True)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        safety_entries = [(p, d) for p, d in fake_rt.logged if p == "events/safety"]
        assert len(safety_entries) == 1
        assert "field violation" in safety_entries[0][1].message.lower()

    @pytest.mark.asyncio
    async def test_estop_and_field_violation_both_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(estop="AUTOACK", field_violation=True)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        safety_entries = [(p, d) for p, d in fake_rt.logged if p == "events/safety"]
        assert len(safety_entries) == 2

    @pytest.mark.asyncio
    async def test_no_safety_event_when_normal(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(estop="NONE", field_violation=False)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        safety_entries = [(p, d) for p, d in fake_rt.logged if p == "events/safety"]
        assert len(safety_entries) == 0


# ---------------------------------------------------------------------------
# Rate limiting tests
# ---------------------------------------------------------------------------


class TestRateLimiting:
    """Verify message rate limiting per device."""

    @pytest.mark.asyncio
    async def test_rate_limiting_drops_fast_messages(
        self, fake_rt: FakeRoboTrace
    ) -> None:
        handler = StateHandler(
            get_rt_client=lambda device_id: fake_rt,
            min_interval_s=10.0,  # Very long interval
        )

        payload = _make_state_payload()
        await handler.handle("test_mfr", "agv_001", "state", payload)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        assert handler.stats["messages_received"] == 2
        assert handler.stats["messages_processed"] == 1
        assert handler.stats["messages_rate_limited"] == 1

    @pytest.mark.asyncio
    async def test_different_devices_rate_limited_independently(
        self, fake_rt: FakeRoboTrace
    ) -> None:
        handler = StateHandler(
            get_rt_client=lambda device_id: fake_rt,
            min_interval_s=10.0,
        )

        payload = _make_state_payload()
        await handler.handle("test_mfr", "agv_001", "state", payload)
        await handler.handle("test_mfr", "agv_002", "state", payload)

        # Both should be processed (different devices)
        assert handler.stats["messages_processed"] == 2

    @pytest.mark.asyncio
    async def test_no_rate_limiting_when_disabled(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        """With min_interval_s=0.0, all messages are processed."""
        payload = _make_state_payload()
        for _ in range(5):
            await handler.handle("test_mfr", "agv_001", "state", payload)

        assert handler.stats["messages_processed"] == 5
        assert handler.stats["messages_rate_limited"] == 0


# ---------------------------------------------------------------------------
# Operating mode and motion state tests
# ---------------------------------------------------------------------------


class TestOperatingModeAndMotion:
    """Verify operating mode and driving/paused flags are logged."""

    @pytest.mark.asyncio
    async def test_operating_mode_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(operating_mode="AUTOMATIC")
        await handler.handle("test_mfr", "agv_001", "state", payload)

        mode_entries = [
            (p, d) for p, d in fake_rt.logged if p == "robot/operating_mode"
        ]
        assert len(mode_entries) == 1
        assert mode_entries[0][1].message == "AUTOMATIC"

    @pytest.mark.asyncio
    async def test_driving_state_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(driving=True, paused=False)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        motion_entries = [
            (p, d) for p, d in fake_rt.logged if p == "robot/motion_state"
        ]
        assert len(motion_entries) == 1
        assert motion_entries[0][1].message == "DRIVING"

    @pytest.mark.asyncio
    async def test_paused_state_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(driving=False, paused=True)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        motion_entries = [
            (p, d) for p, d in fake_rt.logged if p == "robot/motion_state"
        ]
        assert len(motion_entries) == 1
        assert motion_entries[0][1].message == "PAUSED"

    @pytest.mark.asyncio
    async def test_idle_state_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        payload = _make_state_payload(driving=False, paused=False)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        motion_entries = [
            (p, d) for p, d in fake_rt.logged if p == "robot/motion_state"
        ]
        assert len(motion_entries) == 1
        assert motion_entries[0][1].message == "IDLE"


# ---------------------------------------------------------------------------
# Loads tests
# ---------------------------------------------------------------------------


class TestLoadsExtraction:
    """Verify loads are logged."""

    @pytest.mark.asyncio
    async def test_loads_logged(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        loads = [
            {"loadId": "pallet-001", "loadType": "EUR_PALLET", "weight": 500.0},
        ]
        payload = _make_state_payload(loads=loads)
        await handler.handle("test_mfr", "agv_001", "state", payload)

        count_entries = [
            (p, d) for p, d in fake_rt.logged if p == "robot/load_count"
        ]
        assert len(count_entries) == 1
        assert count_entries[0][1].value == 1.0


# ---------------------------------------------------------------------------
# Standalone mode tests (no RoboTrace client)
# ---------------------------------------------------------------------------


class TestStandaloneMode:
    """Verify handler works without a RoboTrace client."""

    @pytest.mark.asyncio
    async def test_handles_without_rt_client(self) -> None:
        handler = StateHandler(get_rt_client=None, min_interval_s=0.0)
        payload = _make_state_payload()

        # Should not raise
        await handler.handle("test_mfr", "agv_001", "state", payload)
        assert handler.stats["messages_processed"] == 1

    @pytest.mark.asyncio
    async def test_handles_with_none_returning_getter(self) -> None:
        handler = StateHandler(
            get_rt_client=lambda device_id: None,
            min_interval_s=0.0,
        )
        payload = _make_state_payload()
        await handler.handle("test_mfr", "agv_001", "state", payload)
        assert handler.stats["messages_processed"] == 1


# ---------------------------------------------------------------------------
# Topic parsing tests
# ---------------------------------------------------------------------------


class TestTopicParsing:
    """Verify VDA 5050 MQTT topic parsing."""

    def test_valid_state_topic(self) -> None:
        parsed = parse_vda5050_topic("uagv/v2/robotis/tb3_001/state")
        assert parsed is not None
        assert parsed.interface_name == "uagv"
        assert parsed.version == "v2"
        assert parsed.manufacturer == "robotis"
        assert parsed.serial_number == "tb3_001"
        assert parsed.topic_type == "state"

    def test_valid_order_topic(self) -> None:
        parsed = parse_vda5050_topic("uagv/v2/acme/agv_99/order")
        assert parsed is not None
        assert parsed.topic_type == "order"

    def test_valid_connection_topic(self) -> None:
        parsed = parse_vda5050_topic("uagv/v2/acme/agv_99/connection")
        assert parsed is not None
        assert parsed.topic_type == "connection"

    def test_valid_visualization_topic(self) -> None:
        parsed = parse_vda5050_topic("uagv/v2/acme/agv_99/visualization")
        assert parsed is not None
        assert parsed.topic_type == "visualization"

    def test_invalid_topic_wrong_segments(self) -> None:
        assert parse_vda5050_topic("uagv/v2/robotis/state") is None

    def test_invalid_topic_unknown_type(self) -> None:
        assert parse_vda5050_topic("uagv/v2/robotis/tb3/foobar") is None

    def test_empty_topic(self) -> None:
        assert parse_vda5050_topic("") is None


# ---------------------------------------------------------------------------
# Device ID construction
# ---------------------------------------------------------------------------


class TestDeviceId:
    """Verify device URN construction."""

    def test_device_id_format(self) -> None:
        handler = StateHandler()
        device_id = handler._make_device_id("robotis", "tb3_001")
        assert device_id == "urn:rosp:device:robotis:tb3_001"


# ---------------------------------------------------------------------------
# Malformed payload resilience
# ---------------------------------------------------------------------------


class TestMalformedPayloads:
    """Verify handler doesn't crash on unexpected payload shapes."""

    @pytest.mark.asyncio
    async def test_empty_payload(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        await handler.handle("test_mfr", "agv_001", "state", {})
        assert handler.stats["messages_processed"] == 1

    @pytest.mark.asyncio
    async def test_position_with_missing_fields(
        self, handler: StateHandler, fake_rt: FakeRoboTrace
    ) -> None:
        """agvPosition present but missing x/y should use defaults."""
        payload: dict[str, Any] = {"agvPosition": {}}
        await handler.handle("test_mfr", "agv_001", "state", payload)

        pose_entries = [(p, d) for p, d in fake_rt.logged if p == "robot/pose"]
        assert len(pose_entries) == 1
        _, pose = pose_entries[0]
        assert pose.x == 0.0
        assert pose.y == 0.0
