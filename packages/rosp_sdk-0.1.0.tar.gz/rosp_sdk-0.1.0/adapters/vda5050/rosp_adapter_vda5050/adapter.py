"""VDA 5050 MQTT -> RoboTrace bridge — main adapter orchestrator.

Subscribes to VDA 5050 MQTT topics for one or more AGVs and maps:

- State messages   -> telemetry (position, battery, velocity, errors, safety)
- Order lifecycle  -> missions (order -> mission, nodes -> phases, actions -> decisions)
- Connection status -> device health events
- Visualization    -> high-frequency pose (optional)

The adapter creates per-device RoboTrace clients and routes incoming MQTT
messages to the appropriate handler.
"""

from __future__ import annotations

import asyncio
import logging
import signal
from typing import Any

from .connection_handler import ConnectionHandler
from .mqtt_client import MQTTClient
from .order_handler import OrderHandler
from .state_handler import StateHandler

logger = logging.getLogger("rosp_adapter_vda5050")

# Attempt to import RoboTrace SDK — adapter works without it for standalone MQTT testing
try:
    from robotrace import RoboTrace

    _HAS_ROBOTRACE = True
except ImportError:
    _HAS_ROBOTRACE = False
    logger.info(
        "robotrace SDK not installed — running in standalone MQTT mode "
        "(messages will be logged but not sent to RoboTrace)"
    )


class VDA5050Adapter:
    """VDA 5050 MQTT -> RoboTrace bridge.

    Subscribes to VDA 5050 MQTT topics for one or more AGVs and maps:

    - State messages   -> telemetry (position, battery, velocity, errors, safety)
    - Order lifecycle  -> missions (order -> mission, nodes -> phases, actions -> decisions)
    - Connection status -> device health events

    Parameters
    ----------
    config : dict
        Configuration dictionary with the following structure::

            {
                "mqtt": {
                    "broker": "localhost",
                    "port": 1883,
                    "username": null,
                    "password": null,
                    "client_id": null,
                },
                "robotrace": {
                    "host": "http://localhost:8080",
                    "public_key": "rt-pk-dev-default",
                    "secret_key": "rt-sk-dev-default",
                },
                "vda5050": {
                    "interface_name": "uagv",
                    "version": "v2",
                    "manufacturers": [],
                    "state_rate_hz": 1.0,
                },
            }
    """

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config
        self._mqtt_config = config.get("mqtt", {})
        self._rt_config = config.get("robotrace", {})
        self._vda_config = config.get("vda5050", {})

        # Per-device RoboTrace clients
        self._rt_clients: dict[str, Any] = {}

        # Rate limit: convert Hz to seconds interval
        state_rate_hz = float(self._vda_config.get("state_rate_hz", 1.0))
        min_interval_s = 1.0 / state_rate_hz if state_rate_hz > 0 else 1.0

        # Initialize handlers
        self._state_handler = StateHandler(
            get_rt_client=self._get_rt_client,
            min_interval_s=min_interval_s,
        )
        self._order_handler = OrderHandler(
            get_rt_client=self._get_rt_client,
        )
        self._connection_handler = ConnectionHandler(
            get_rt_client=self._get_rt_client,
        )

        # Initialize MQTT client
        self._mqtt = MQTTClient(
            broker=self._mqtt_config.get("broker", "localhost"),
            port=int(self._mqtt_config.get("port", 1883)),
            interface_name=self._vda_config.get("interface_name", "uagv"),
            version=self._vda_config.get("version", "v2"),
            manufacturers=self._vda_config.get("manufacturers"),
            username=self._mqtt_config.get("username"),
            password=self._mqtt_config.get("password"),
            client_id=self._mqtt_config.get("client_id"),
        )

        # Register handlers
        self._mqtt.register_handler("state", self._handle_state)
        self._mqtt.register_handler("order", self._order_handler.handle_order)
        self._mqtt.register_handler("connection", self._connection_handler.handle)
        self._mqtt.register_handler("visualization", self._handle_visualization)

        self._stop_event = asyncio.Event()

    def _get_rt_client(self, device_id: str) -> Any:
        """Get or create a RoboTrace client for the given device.

        Returns None if the SDK is not installed or configuration is missing.
        """
        if not _HAS_ROBOTRACE:
            return None

        host = self._rt_config.get("host")
        public_key = self._rt_config.get("public_key")
        secret_key = self._rt_config.get("secret_key")

        if not all([host, public_key, secret_key]):
            return None

        if device_id not in self._rt_clients:
            try:
                # Each device gets its own RoboTrace client instance.
                # Using a device-specific public key suffix to avoid singleton collision.
                rt = RoboTrace(
                    host=host,
                    public_key=f"{public_key}:{device_id}",
                    secret_key=secret_key,
                    device_id=device_id,
                    environment=self._rt_config.get("environment", "production"),
                    release=self._rt_config.get("release"),
                )
                self._rt_clients[device_id] = rt
                logger.info("Created RoboTrace client for device: %s", device_id)
            except Exception:
                logger.exception(
                    "Failed to create RoboTrace client for %s", device_id
                )
                return None

        return self._rt_clients.get(device_id)

    async def _handle_state(
        self,
        manufacturer: str,
        serial_number: str,
        topic_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Route state messages to both the state handler and order handler.

        The state handler extracts telemetry (position, battery, etc.).
        The order handler tracks node/action progress within active missions.
        """
        await self._state_handler.handle(manufacturer, serial_number, topic_type, payload)
        await self._order_handler.handle_state_progress(manufacturer, serial_number, payload)

    async def _handle_visualization(
        self,
        manufacturer: str,
        serial_number: str,
        topic_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Handle visualization messages (high-frequency pose updates).

        Visualization messages contain the same position data as state but
        at higher frequency. We reuse the state handler but with a separate
        rate-limit path that allows higher throughput if configured.
        """
        # For now, treat visualization as a lightweight state update (position only)
        device_id = self._state_handler._make_device_id(manufacturer, serial_number)
        pos = payload.get("agvPosition")
        if pos is None:
            return

        logger.debug(
            "Visualization [%s]: position update", device_id
        )

        rt = self._get_rt_client(device_id)
        if rt is not None and _HAS_ROBOTRACE:
            import math
            from robotrace import Pose3D

            x = float(pos.get("x", 0.0))
            y = float(pos.get("y", 0.0))
            theta = float(pos.get("theta", 0.0))
            qz = math.sin(theta / 2.0)
            qw = math.cos(theta / 2.0)
            rt.log("robot/pose_viz", Pose3D(x=x, y=y, z=0.0, qz=qz, qw=qw))

    async def start(self) -> None:
        """Connect to MQTT broker and start processing VDA 5050 messages.

        Blocks until ``stop()`` is called or a shutdown signal is received.
        """
        logger.info("VDA 5050 Adapter starting...")
        logger.info(
            "MQTT broker: %s:%s",
            self._mqtt_config.get("broker", "localhost"),
            self._mqtt_config.get("port", 1883),
        )

        if _HAS_ROBOTRACE:
            logger.info(
                "RoboTrace host: %s",
                self._rt_config.get("host", "(not configured)"),
            )
        else:
            logger.info("RoboTrace SDK not available — standalone MQTT mode")

        # Install signal handlers for graceful shutdown
        loop = asyncio.get_running_loop()
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.add_signal_handler(sig, self._signal_shutdown)
            except NotImplementedError:
                # Windows does not support add_signal_handler for SIGTERM
                pass

        await self._mqtt.start()

        logger.info("VDA 5050 Adapter running. Press Ctrl+C to stop.")

        # Block until shutdown is requested
        await self._stop_event.wait()

        # Graceful shutdown
        await self.stop()

    def _signal_shutdown(self) -> None:
        """Handle shutdown signal (SIGINT/SIGTERM)."""
        logger.info("Shutdown signal received")
        self._stop_event.set()

    async def stop(self) -> None:
        """Disconnect MQTT and clean up all resources."""
        logger.info("VDA 5050 Adapter shutting down...")

        # Stop MQTT first to prevent new messages
        await self._mqtt.stop()

        # Finish any active missions
        await self._order_handler.shutdown()

        # Log final statistics
        logger.info("State handler stats: %s", self._state_handler.stats)
        logger.info("Order handler stats: %s", self._order_handler.stats)
        logger.info("Connection handler stats: %s", self._connection_handler.stats)

        logger.info("VDA 5050 Adapter stopped")
