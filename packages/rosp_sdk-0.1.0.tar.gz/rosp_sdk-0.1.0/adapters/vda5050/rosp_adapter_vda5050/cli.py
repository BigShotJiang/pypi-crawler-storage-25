"""ROSP VDA 5050 Adapter CLI — run the adapter from the command line.

Usage:
    rosp-vda5050                          # Uses env vars or defaults
    rosp-vda5050 vda5050-config.yaml      # Load config from YAML file
    rosp-vda5050 --help                   # Show help

Environment variables (used when no config file is provided):
    MQTT_BROKER           — MQTT broker host (default: localhost)
    MQTT_PORT             — MQTT broker port (default: 1883)
    MQTT_USERNAME         — MQTT username (optional)
    MQTT_PASSWORD         — MQTT password (optional)
    ROBOTRACE_HOST        — RoboTrace server URL (default: http://localhost:8080)
    ROBOTRACE_PUBLIC_KEY  — RoboTrace public key (default: rt-pk-dev-default)
    ROBOTRACE_SECRET_KEY  — RoboTrace secret key (default: rt-sk-dev-default)
    VDA5050_INTERFACE     — VDA 5050 interface name (default: uagv)
    VDA5050_VERSION       — VDA 5050 protocol version (default: v2)
    VDA5050_STATE_RATE_HZ — Max state message rate per device (default: 1.0)
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys
from typing import Any

import yaml

from .adapter import VDA5050Adapter

logger = logging.getLogger("rosp_adapter_vda5050.cli")

_ROSP_MODE_HELP = (
    "Run in ROSP mode: start the VDA5050ROSPAdapter instead of the standalone "
    "VDA5050Adapter. The ROSP adapter exposes describe/stream/discover/health_check "
    "endpoints conforming to the ROSP SDK interface."
)


def _setup_logging(config: dict[str, Any]) -> None:
    """Configure structured logging for the adapter."""
    log_config = config.get("logging", {})
    level_str = log_config.get(
        "level", os.getenv("LOG_LEVEL", "INFO")
    ).upper()
    level = getattr(logging, level_str, logging.INFO)

    fmt = "%(asctime)s [%(name)s] %(levelname)s: %(message)s"
    logging.basicConfig(level=level, format=fmt, stream=sys.stderr)

    # Suppress noisy third-party loggers
    logging.getLogger("aiomqtt").setLevel(logging.WARNING)


def _build_config_from_env() -> dict[str, Any]:
    """Build adapter configuration from environment variables."""
    return {
        "mqtt": {
            "broker": os.getenv("MQTT_BROKER", "localhost"),
            "port": int(os.getenv("MQTT_PORT", "1883")),
            "username": os.getenv("MQTT_USERNAME"),
            "password": os.getenv("MQTT_PASSWORD"),
            "client_id": os.getenv("MQTT_CLIENT_ID"),
        },
        "robotrace": {
            "host": os.getenv("ROBOTRACE_HOST", "http://localhost:8080"),
            "public_key": os.getenv("ROBOTRACE_PUBLIC_KEY", "rt-pk-dev-default"),
            "secret_key": os.getenv("ROBOTRACE_SECRET_KEY", "rt-sk-dev-default"),
            "environment": os.getenv("ROBOTRACE_ENVIRONMENT", "production"),
            "release": os.getenv("ROBOTRACE_RELEASE"),
        },
        "vda5050": {
            "interface_name": os.getenv("VDA5050_INTERFACE", "uagv"),
            "version": os.getenv("VDA5050_VERSION", "v2"),
            "state_rate_hz": float(os.getenv("VDA5050_STATE_RATE_HZ", "1.0")),
        },
    }


def _load_config(config_path: str | None) -> dict[str, Any]:
    """Load configuration from a YAML file or fall back to environment variables."""
    if config_path and os.path.exists(config_path):
        logger.info("Loading config from: %s", config_path)
        with open(config_path) as f:
            config = yaml.safe_load(f) or {}
        return config

    logger.info("No config file found — using environment variables")
    return _build_config_from_env()


async def _run_rosp_adapter(config: dict[str, Any]) -> None:
    """Run the ROSP adapter with a basic health-check loop."""
    from .rosp_adapter import VDA5050ROSPAdapter

    adapter = VDA5050ROSPAdapter(config)
    await adapter.connect()
    logger.info("ROSP adapter running. Press Ctrl+C to stop.")

    try:
        # Periodically log health status
        while True:
            health = await adapter.health_check()
            logger.info(
                "Health: adapter=%s robot=%s uptime=%.0fs devices=%d",
                health.adapter_status.value,
                health.robot_status.value,
                health.uptime_seconds,
                health.details.get("known_devices", 0) if health.details else 0,
            )
            await asyncio.sleep(30)
    except asyncio.CancelledError:
        pass
    finally:
        await adapter.disconnect()


def main() -> None:
    """CLI entry point for the VDA 5050 adapter."""
    # Check for --rosp flag
    rosp_mode = "--rosp" in sys.argv
    args = [a for a in sys.argv[1:] if a != "--rosp"]

    if "--help" in sys.argv or "-h" in sys.argv:
        print(__doc__)
        if rosp_mode:
            print(f"\n--rosp: {_ROSP_MODE_HELP}")
        print("\nFlags:")
        print("  --rosp    " + _ROSP_MODE_HELP)
        sys.exit(0)

    config_path = args[0] if args else "vda5050-config.yaml"
    config = _load_config(config_path)
    _setup_logging(config)

    if rosp_mode:
        logger.info("Starting in ROSP mode")
        try:
            asyncio.run(_run_rosp_adapter(config))
        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        except Exception:
            logger.exception("Fatal error in ROSP adapter")
            sys.exit(1)
    else:
        adapter = VDA5050Adapter(config)
        try:
            asyncio.run(adapter.start())
        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        except Exception:
            logger.exception("Fatal error in VDA 5050 adapter")
            sys.exit(1)


if __name__ == "__main__":
    main()
