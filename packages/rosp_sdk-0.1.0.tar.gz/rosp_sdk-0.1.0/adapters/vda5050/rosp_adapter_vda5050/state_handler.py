"""VDA 5050 state message handler — extracts telemetry and logs to RoboTrace.

Maps VDA 5050 ``state`` message fields to RoboTrace SDK semantic types:

- ``agvPosition``           -> ``robot/pose`` (Pose3D)
- ``batteryState``          -> ``sensors/battery`` (Scalar)
- ``velocity``              -> ``robot/velocity`` (Twist)
- ``errors[]``              -> logged as events with severity
- ``safetyState``           -> critical safety events
- ``loads[]``               -> ``robot/loads`` (JSON)
- ``operatingMode``         -> ``robot/operating_mode`` (Log)
- ``driving`` / ``paused``  -> ``robot/motion_state`` (Log)

Implements rate limiting to downsample high-frequency state messages.
"""

from __future__ import annotations

import json
import logging
import math
import time
from typing import Any, Optional

logger = logging.getLogger("rosp_adapter_vda5050.state")

# Attempt to import RoboTrace SDK — gracefully degrade if not installed
try:
    from robotrace import Pose3D, Scalar, Twist, Log

    _HAS_ROBOTRACE = True
except ImportError:
    _HAS_ROBOTRACE = False
    logger.info("robotrace SDK not installed — state handler will log to console only")


class StateHandler:
    """Processes VDA 5050 state messages and logs telemetry to RoboTrace.

    Parameters
    ----------
    get_rt_client : callable | None
        Callable that returns a RoboTrace client for a given device_id.
        Signature: ``(device_id: str) -> RoboTrace | None``
    min_interval_s : float
        Minimum interval between processed state messages per device (rate limiting).
        Default 1.0s (1 Hz).
    """

    def __init__(
        self,
        get_rt_client: Any = None,
        min_interval_s: float = 1.0,
    ) -> None:
        self._get_rt_client = get_rt_client
        self._min_interval_s = min_interval_s
        # Per-device timestamp of last processed state message
        self._last_processed: dict[str, float] = {}
        # Counters for observability
        self._stats = {
            "messages_received": 0,
            "messages_processed": 0,
            "messages_rate_limited": 0,
        }

    @property
    def stats(self) -> dict[str, int]:
        """Return a copy of handler statistics."""
        return dict(self._stats)

    def _make_device_id(self, manufacturer: str, serial_number: str) -> str:
        """Build a ROSP-style device URN from manufacturer and serial."""
        return f"urn:rosp:device:{manufacturer}:{serial_number}"

    def _should_process(self, device_id: str) -> bool:
        """Check if enough time has passed since the last processed message."""
        now = time.monotonic()
        last = self._last_processed.get(device_id, 0.0)
        if (now - last) < self._min_interval_s:
            self._stats["messages_rate_limited"] += 1
            return False
        self._last_processed[device_id] = now
        return True

    async def handle(
        self,
        manufacturer: str,
        serial_number: str,
        topic_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Process a VDA 5050 state message.

        Parameters
        ----------
        manufacturer : str
            AGV manufacturer name extracted from the MQTT topic.
        serial_number : str
            AGV serial number extracted from the MQTT topic.
        topic_type : str
            Always "state" for this handler.
        payload : dict
            Parsed JSON payload of the VDA 5050 state message.
        """
        self._stats["messages_received"] += 1
        device_id = self._make_device_id(manufacturer, serial_number)

        # Rate limiting
        if not self._should_process(device_id):
            return

        self._stats["messages_processed"] += 1

        rt = None
        if _HAS_ROBOTRACE and self._get_rt_client is not None:
            rt = self._get_rt_client(device_id)

        # Extract and log each telemetry field
        self._process_position(rt, device_id, payload)
        self._process_battery(rt, device_id, payload)
        self._process_velocity(rt, device_id, payload)
        self._process_errors(rt, device_id, payload)
        self._process_safety_state(rt, device_id, payload)
        self._process_loads(rt, device_id, payload)
        self._process_operating_mode(rt, device_id, payload)
        self._process_motion_state(rt, device_id, payload)

    def _process_position(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract agvPosition and log as Pose3D."""
        pos = payload.get("agvPosition")
        if pos is None:
            return

        x = float(pos.get("x", 0.0))
        y = float(pos.get("y", 0.0))
        theta = float(pos.get("theta", 0.0))

        # Convert theta (yaw angle in radians) to quaternion
        qz = math.sin(theta / 2.0)
        qw = math.cos(theta / 2.0)

        logger.debug(
            "Position [%s]: x=%.3f y=%.3f theta=%.3f", device_id, x, y, theta
        )

        if rt is not None and _HAS_ROBOTRACE:
            rt.log("robot/pose", Pose3D(x=x, y=y, z=0.0, qz=qz, qw=qw))

    def _process_battery(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract batteryState and log charge as Scalar."""
        battery = payload.get("batteryState")
        if battery is None:
            return

        charge = battery.get("batteryCharge")
        if charge is None:
            return

        charge_val = float(charge)
        logger.debug("Battery [%s]: %.1f%%", device_id, charge_val)

        if rt is not None and _HAS_ROBOTRACE:
            rt.log("sensors/battery", Scalar(charge_val))

        # Also log voltage and reach if available
        voltage = battery.get("batteryVoltage")
        if voltage is not None and rt is not None and _HAS_ROBOTRACE:
            rt.log("sensors/battery_voltage", Scalar(float(voltage)))

        reach = battery.get("reach")
        if reach is not None and rt is not None and _HAS_ROBOTRACE:
            rt.log("sensors/battery_reach", Scalar(float(reach)))

    def _process_velocity(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract velocity and log as Twist."""
        vel = payload.get("velocity")
        if vel is None:
            return

        vx = float(vel.get("vx", 0.0))
        vy = float(vel.get("vy", 0.0))
        omega = float(vel.get("omega", 0.0))

        logger.debug(
            "Velocity [%s]: vx=%.3f vy=%.3f omega=%.3f", device_id, vx, vy, omega
        )

        if rt is not None and _HAS_ROBOTRACE:
            rt.log(
                "robot/velocity",
                Twist(linear_x=vx, linear_y=vy, angular_z=omega),
            )

    def _process_errors(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract errors array and log each as an event."""
        errors = payload.get("errors")
        if not errors:
            return

        for error in errors:
            error_type = error.get("errorType", "UNKNOWN")
            error_level = error.get("errorLevel", "WARNING")
            description = error.get("errorDescription", "")
            references = error.get("errorReferences", [])

            level_str = "ERROR" if error_level == "FATAL" else "WARNING"
            message = f"VDA5050 {error_level}: {error_type}"
            if description:
                message += f" — {description}"

            logger.warning(
                "AGV error [%s]: type=%s level=%s desc=%s",
                device_id,
                error_type,
                error_level,
                description,
            )

            if rt is not None and _HAS_ROBOTRACE:
                rt.log(
                    "events/errors",
                    Log(message=message, level=level_str),
                )

    def _process_safety_state(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract safetyState and log critical safety events."""
        safety = payload.get("safetyState")
        if safety is None:
            return

        estop = safety.get("eStop", "NONE")
        field_violation = safety.get("fieldViolation", False)

        if estop != "NONE":
            message = f"E-STOP ACTIVE: {estop}"
            logger.critical("Safety [%s]: %s", device_id, message)
            if rt is not None and _HAS_ROBOTRACE:
                rt.log("events/safety", Log(message=message, level="ERROR"))

        if field_violation:
            message = "Protective field violation detected"
            logger.critical("Safety [%s]: %s", device_id, message)
            if rt is not None and _HAS_ROBOTRACE:
                rt.log("events/safety", Log(message=message, level="ERROR"))

    def _process_loads(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract loads array and log as JSON telemetry."""
        loads = payload.get("loads")
        if loads is None:
            return

        logger.debug("Loads [%s]: %d items", device_id, len(loads))

        if rt is not None and _HAS_ROBOTRACE:
            # Log loads summary as a scalar (count) and details as a log entry
            rt.log("robot/load_count", Scalar(float(len(loads))))
            if loads:
                rt.log(
                    "robot/loads",
                    Log(message=json.dumps(loads), level="INFO"),
                )

    def _process_operating_mode(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract operatingMode and log as a tag."""
        mode = payload.get("operatingMode")
        if mode is None:
            return

        logger.debug("Operating mode [%s]: %s", device_id, mode)

        if rt is not None and _HAS_ROBOTRACE:
            rt.log("robot/operating_mode", Log(message=mode, level="INFO"))

    def _process_motion_state(
        self, rt: Any, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Extract driving and paused flags and log motion state."""
        driving = payload.get("driving")
        paused = payload.get("paused")

        if driving is None and paused is None:
            return

        if paused:
            state = "PAUSED"
        elif driving:
            state = "DRIVING"
        else:
            state = "IDLE"

        logger.debug("Motion state [%s]: %s", device_id, state)

        if rt is not None and _HAS_ROBOTRACE:
            rt.log("robot/motion_state", Log(message=state, level="INFO"))
