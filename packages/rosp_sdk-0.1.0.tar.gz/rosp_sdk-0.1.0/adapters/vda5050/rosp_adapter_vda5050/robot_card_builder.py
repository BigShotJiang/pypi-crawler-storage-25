"""Build ROSP RobotCard from VDA 5050 config and factsheet data.

Creates a fully populated RobotCard for a VDA 5050 AGV based on
manufacturer/serial metadata and optional factsheet information.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List

from rosp_sdk.models import RobotCard


# Default sensor descriptors for a VDA 5050 AGV
_DEFAULT_SENSORS: List[Dict[str, Any]] = [
    {
        "name": "pose",
        "type": "Pose3D",
        "description": "AGV position from agvPosition field",
        "rate_hz": 1.0,
        "rosp_topic": "/sensor/pose",
    },
    {
        "name": "battery",
        "type": "Scalar",
        "description": "Battery state from batteryState field",
        "rate_hz": 0.1,
        "rosp_topic": "/sensor/battery",
    },
    {
        "name": "velocity",
        "type": "Twist",
        "description": "AGV velocity from velocity field",
        "rate_hz": 1.0,
        "rosp_topic": "/sensor/velocity",
    },
]

# Default capabilities for a VDA 5050 AGV
_DEFAULT_CAPABILITIES: List[Dict[str, Any]] = [
    {"name": "navigate", "description": "Navigate to a node via VDA 5050 order"},
    {"name": "charge", "description": "Navigate to charging station"},
    {"name": "pick", "description": "Pick up a load at a station"},
    {"name": "drop", "description": "Drop off a load at a station"},
]


def build_robot_card(
    manufacturer: str,
    serial_number: str,
    config: Dict[str, Any],
    factsheet: Dict[str, Any] | None = None,
) -> RobotCard:
    """Create a RobotCard from VDA 5050 device information.

    Parameters
    ----------
    manufacturer : str
        AGV manufacturer name (from VDA 5050 topic structure).
    serial_number : str
        AGV serial number (from VDA 5050 topic structure).
    config : dict
        VDA 5050 adapter configuration section.
    factsheet : dict | None
        Optional VDA 5050 factsheet payload for richer metadata.

    Returns
    -------
    RobotCard
        A fully populated Robot Card conforming to ROSP spec.
    """
    robot_id = f"urn:rosp:robot:{manufacturer}:{serial_number}"
    model = config.get("model", "unknown")

    # If a factsheet is available, extract richer info
    if factsheet:
        model = factsheet.get("typeSpecification", {}).get("agvClass", model)
        hw_info = {
            "dimensions": factsheet.get("typeSpecification", {}).get("dimensions", {}),
            "weight_kg": factsheet.get("typeSpecification", {}).get("weight", None),
            "max_speed_mps": factsheet.get("typeSpecification", {}).get("maxSpeed", None),
            "battery_type": factsheet.get("typeSpecification", {}).get("batteryType", None),
        }
    else:
        hw_info = {
            "device_type": config.get("device_type", "agv"),
        }

    return RobotCard(
        rosp_version="0.1",
        id=robot_id,
        identity={
            "manufacturer": manufacturer,
            "model": model,
            "serial_number": serial_number,
            "firmware_version": config.get("firmware", ""),
            "type": config.get("device_type", "agv"),
            "protocol": "vda5050",
            "protocol_version": config.get("version", "v2"),
        },
        hardware=hw_info,
        sensors=_DEFAULT_SENSORS,
        actuators=[],
        capabilities=_DEFAULT_CAPABILITIES,
        integration={
            "protocol": "mqtt",
            "broker": config.get("broker", "localhost"),
            "interface_name": config.get("interface_name", "uagv"),
            "vda5050_version": config.get("version", "v2"),
            "topic_prefix": f"{config.get('interface_name', 'uagv')}/{config.get('version', 'v2')}/{manufacturer}/{serial_number}",
        },
        created_at=datetime.now(timezone.utc).isoformat(),
    )
