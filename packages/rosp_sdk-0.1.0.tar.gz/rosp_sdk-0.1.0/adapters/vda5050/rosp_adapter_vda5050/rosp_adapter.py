"""VDA 5050 ROSP Adapter -- wraps VDA5050Adapter to emit ROSP envelopes.

This is the adapter-of-adapters pattern: VDA5050ROSPAdapter implements the
ROSP SDK abstract interface (ROSPAdapter) while internally delegating to
VDA5050Adapter for actual MQTT communication with VDA 5050 AGVs.

ROSP is the external API; VDA 5050 is the transport protocol.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, AsyncIterator, Dict, List, Optional

from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.models import (
    AdapterStatus,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
    StreamQoS,
)

from .adapter import VDA5050Adapter
from .robot_card_builder import build_robot_card
from .stream_converter import TOPIC_MAP, convert_state_to_stream_messages

logger = logging.getLogger("rosp_adapter_vda5050.rosp")


class VDA5050ROSPAdapter(ROSPAdapter):
    """Adapter-of-adapters: wraps VDA5050Adapter for ROSP protocol compliance.

    Maps ROSP abstract methods to VDA 5050 concepts:
        - describe()      -> RobotCard from config + optional factsheet
        - stream(topics)   -> subscribe to MQTT state/visualization, yield StreamMessage
        - discover()       -> DiscoveryInfo from config
        - health_check()   -> MQTT connection status

    Parameters
    ----------
    config : dict
        Same configuration dict as VDA5050Adapter, with optional 'rosp' section::

            {
                "mqtt": { "broker": "...", "port": 1883, ... },
                "vda5050": { "interface_name": "uagv", "version": "v2", ... },
                "rosp": { "adapter_version": "0.1.0" },  # optional
            }
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        super().__init__(config)
        self._vda_adapter: Optional[VDA5050Adapter] = None
        self._stream_queues: List[asyncio.Queue[StreamMessage]] = []
        self._seq_counters: Dict[str, int] = {}
        self._factsheets: Dict[str, Dict[str, Any]] = {}
        self._known_devices: Dict[str, Dict[str, str]] = {}
        self._mqtt_connected = False

    # --- Lifecycle ---

    async def connect(self) -> None:
        """Start the underlying VDA5050Adapter and hook MQTT handlers.

        Creates the VDA5050Adapter, registers a state handler that feeds
        incoming state messages into any active stream queues, then starts
        the MQTT connection.
        """
        self._vda_adapter = VDA5050Adapter(self.config)

        # Intercept state messages for streaming
        original_state_handler = self._vda_adapter._handle_state

        async def _rosp_state_hook(
            manufacturer: str,
            serial_number: str,
            topic_type: str,
            payload: Dict[str, Any],
        ) -> None:
            # Track known devices
            device_id = f"{manufacturer}:{serial_number}"
            if device_id not in self._known_devices:
                self._known_devices[device_id] = {
                    "manufacturer": manufacturer,
                    "serial_number": serial_number,
                }
                logger.info("Discovered VDA 5050 device: %s", device_id)

            # Convert state to stream messages and push to all queues
            if self._stream_queues:
                # Determine which topics any queue cares about (all for now)
                all_topics = list(TOPIC_MAP.keys())
                messages = convert_state_to_stream_messages(
                    payload, all_topics, self._seq_counters
                )
                for msg in messages:
                    for queue in self._stream_queues:
                        try:
                            queue.put_nowait(msg)
                        except asyncio.QueueFull:
                            logger.debug(
                                "Stream queue full, dropping message for %s",
                                msg.topic,
                            )

            # Call original handler for RoboTrace integration
            await original_state_handler(manufacturer, serial_number, topic_type, payload)

        # Replace the state handler with our hook
        self._vda_adapter._handle_state = _rosp_state_hook  # type: ignore[assignment]

        # Start MQTT (non-blocking -- start() creates a background task)
        await self._vda_adapter._mqtt.start()
        self._mqtt_connected = True
        self._connected = True
        logger.info("VDA5050ROSPAdapter connected")

    async def disconnect(self) -> None:
        """Stop the underlying VDA5050Adapter and clean up."""
        if self._vda_adapter:
            await self._vda_adapter._mqtt.stop()
            await self._vda_adapter._order_handler.shutdown()

        # Signal all stream queues to stop
        for queue in self._stream_queues:
            await queue.put(None)  # type: ignore[arg-type]
        self._stream_queues.clear()

        self._mqtt_connected = False
        self._connected = False
        logger.info("VDA5050ROSPAdapter disconnected")

    # --- Description Mode ---

    async def describe(self, depth: str = "full") -> RobotCard:
        """Build a RobotCard from VDA 5050 config and known devices.

        If a specific device has been seen via MQTT, its manufacturer and
        serial number are used. Otherwise, the first configured manufacturer
        from the config is used.

        Parameters
        ----------
        depth : str
            "summary" or "full" (full includes sensor schemas and integration).

        Returns
        -------
        RobotCard
        """
        vda_config = self.config.get("vda5050", {})
        mqtt_config = self.config.get("mqtt", {})

        # Merge relevant config for the card builder
        merged_config = {
            **vda_config,
            "broker": mqtt_config.get("broker", "localhost"),
        }

        # Pick a device -- prefer first known device from MQTT traffic
        if self._known_devices:
            first_device = next(iter(self._known_devices.values()))
            manufacturer = first_device["manufacturer"]
            serial_number = first_device["serial_number"]
        else:
            # Fall back to configured manufacturers
            manufacturers = vda_config.get("manufacturers", [])
            if manufacturers:
                mfr = manufacturers[0]
                manufacturer = mfr.get("name", "unknown")
                serials = mfr.get("serial_numbers", [])
                serial_number = serials[0] if serials else "unknown"
            else:
                manufacturer = "unknown"
                serial_number = "unknown"

        device_id = f"{manufacturer}:{serial_number}"
        factsheet = self._factsheets.get(device_id)

        return build_robot_card(manufacturer, serial_number, merged_config, factsheet)

    async def stream(
        self, topics: List[str], qos: Optional[StreamQoS] = None
    ) -> AsyncIterator[StreamMessage]:
        """Subscribe to VDA 5050 MQTT state data and yield ROSP StreamMessages.

        Uses an asyncio.Queue as a bridge between the MQTT callback thread
        and this async iterator. The MQTT state handler pushes converted
        StreamMessages into the queue; this method yields them.

        Parameters
        ----------
        topics : list[str]
            ROSP topic paths (e.g., ["/sensor/pose", "/sensor/battery"]).
        qos : StreamQoS | None
            Quality of service parameters (frequency limiting, etc.).

        Yields
        ------
        StreamMessage
            One message per sensor reading that matches the requested topics.
        """
        # Validate topics
        valid_topics = [t for t in topics if t in TOPIC_MAP]
        if not valid_topics:
            logger.warning(
                "No valid topics in stream request: %s. Available: %s",
                topics,
                list(TOPIC_MAP.keys()),
            )
            return

        queue: asyncio.Queue[Optional[StreamMessage]] = asyncio.Queue(maxsize=1000)
        self._stream_queues.append(queue)  # type: ignore[arg-type]

        try:
            while True:
                msg = await queue.get()
                if msg is None:
                    # Sentinel: stream has been closed
                    break
                # Filter to only requested topics
                if msg.topic in valid_topics:
                    yield msg
        finally:
            # Remove queue on cleanup
            try:
                self._stream_queues.remove(queue)  # type: ignore[arg-type]
            except ValueError:
                pass

    async def discover(self) -> DiscoveryInfo:
        """Return adapter discovery information from config.

        Returns
        -------
        DiscoveryInfo
            Adapter identity, capabilities, and endpoint.
        """
        vda_config = self.config.get("vda5050", {})
        mqtt_config = self.config.get("mqtt", {})
        rosp_config = self.config.get("rosp", {})

        # Build robot_id from first known or configured device
        if self._known_devices:
            first = next(iter(self._known_devices.values()))
            robot_id = f"urn:rosp:robot:{first['manufacturer']}:{first['serial_number']}"
            manufacturer = first["manufacturer"]
        else:
            manufacturers = vda_config.get("manufacturers", [])
            if manufacturers:
                mfr = manufacturers[0]
                name = mfr.get("name", "unknown")
                serials = mfr.get("serial_numbers", [])
                serial = serials[0] if serials else "unknown"
                robot_id = f"urn:rosp:robot:{name}:{serial}"
                manufacturer = name
            else:
                robot_id = "urn:rosp:robot:unknown:unknown"
                manufacturer = "unknown"

        return DiscoveryInfo(
            robot_id=robot_id,
            model=vda_config.get("model", "vda5050-agv"),
            manufacturer=manufacturer,
            rosp_version="0.1",
            adapter_version=rosp_config.get("adapter_version", "0.1.0"),
            capabilities_summary=["stream", "describe", "health_check"],
            endpoint=f"mqtt://{mqtt_config.get('broker', 'localhost')}:{mqtt_config.get('port', 1883)}",
            mode="description",
        )

    async def health_check(self) -> HealthStatus:
        """Check MQTT connection and adapter health.

        Returns
        -------
        HealthStatus
            Current adapter and robot connection status.
        """
        # Determine adapter status
        if not self._connected:
            adapter_status = AdapterStatus.DISCONNECTED
        elif self._mqtt_connected:
            adapter_status = AdapterStatus.HEALTHY
        else:
            adapter_status = AdapterStatus.DEGRADED

        # Determine robot status based on MQTT connectivity and known devices
        if not self._mqtt_connected:
            robot_status = RobotStatus.DISCONNECTED
        elif self._known_devices:
            robot_status = RobotStatus.CONNECTED
        else:
            robot_status = RobotStatus.UNKNOWN

        # Check MQTT client task health
        mqtt_task_alive = False
        if self._vda_adapter and self._vda_adapter._mqtt._task:
            mqtt_task_alive = not self._vda_adapter._mqtt._task.done()

        if self._connected and not mqtt_task_alive:
            adapter_status = AdapterStatus.DEGRADED
            robot_status = RobotStatus.DEGRADED

        return HealthStatus(
            adapter_status=adapter_status,
            robot_status=robot_status,
            latency_ms=-1.0,  # MQTT does not have a simple ping; -1 indicates unknown
            uptime_seconds=self.uptime_seconds,
            details={
                "mqtt_connected": self._mqtt_connected,
                "mqtt_task_alive": mqtt_task_alive,
                "known_devices": len(self._known_devices),
                "active_streams": len(self._stream_queues),
                "protocol": "vda5050",
            },
        )
