"""VDA 5050 connection status handler — monitors AGV device health.

Maps VDA 5050 ``connection`` topic messages to RoboTrace health events:

- ``ONLINE``            -> info event (device connected)
- ``OFFLINE``           -> warning event (device disconnected gracefully)
- ``CONNECTIONBROKEN``  -> warning event (unexpected disconnect)
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("rosp_adapter_vda5050.connection")

# Attempt to import RoboTrace SDK
try:
    from robotrace import Log

    _HAS_ROBOTRACE = True
except ImportError:
    _HAS_ROBOTRACE = False


class ConnectionHandler:
    """Processes VDA 5050 connection status messages.

    Parameters
    ----------
    get_rt_client : callable | None
        Callable that returns a RoboTrace client for a given device_id.
        Signature: ``(device_id: str) -> RoboTrace | None``
    """

    def __init__(self, get_rt_client: Any = None) -> None:
        self._get_rt_client = get_rt_client
        # Track current connection state per device
        self._device_states: dict[str, str] = {}
        self._stats = {
            "messages_received": 0,
            "online_events": 0,
            "offline_events": 0,
            "broken_events": 0,
        }

    @property
    def stats(self) -> dict[str, int]:
        """Return a copy of handler statistics."""
        return dict(self._stats)

    @property
    def device_states(self) -> dict[str, str]:
        """Return current connection state of each known device."""
        return dict(self._device_states)

    def _make_device_id(self, manufacturer: str, serial_number: str) -> str:
        """Build a ROSP-style device URN from manufacturer and serial."""
        return f"urn:rosp:device:{manufacturer}:{serial_number}"

    async def handle(
        self,
        manufacturer: str,
        serial_number: str,
        topic_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Process a VDA 5050 connection status message.

        Parameters
        ----------
        manufacturer : str
            AGV manufacturer name.
        serial_number : str
            AGV serial number.
        topic_type : str
            Always "connection" for this handler.
        payload : dict
            Parsed VDA 5050 connection message. Expected to contain
            ``connectionState`` with value ONLINE, OFFLINE, or CONNECTIONBROKEN.
        """
        self._stats["messages_received"] += 1
        device_id = self._make_device_id(manufacturer, serial_number)

        connection_state = payload.get("connectionState", "").upper()
        if not connection_state:
            logger.warning(
                "Connection message missing connectionState from %s", device_id
            )
            return

        previous_state = self._device_states.get(device_id)
        self._device_states[device_id] = connection_state

        # Only log events on state changes to avoid noise
        if connection_state == previous_state:
            return

        if connection_state == "ONLINE":
            self._stats["online_events"] += 1
            message = f"AGV online: {manufacturer}/{serial_number}"
            log_level = "INFO"
            logger.info("Connection [%s]: ONLINE", device_id)

        elif connection_state == "OFFLINE":
            self._stats["offline_events"] += 1
            message = f"AGV offline (graceful): {manufacturer}/{serial_number}"
            log_level = "WARNING"
            logger.warning("Connection [%s]: OFFLINE", device_id)

        elif connection_state == "CONNECTIONBROKEN":
            self._stats["broken_events"] += 1
            message = f"AGV connection broken: {manufacturer}/{serial_number}"
            log_level = "WARNING"
            logger.warning("Connection [%s]: CONNECTIONBROKEN", device_id)

        else:
            logger.warning(
                "Unknown connection state [%s]: %s", device_id, connection_state
            )
            return

        # Log to RoboTrace
        if _HAS_ROBOTRACE and self._get_rt_client is not None:
            rt = self._get_rt_client(device_id)
            if rt is not None:
                try:
                    rt.log(
                        "events/connection",
                        Log(message=message, level=log_level),
                    )
                except Exception:
                    logger.debug(
                        "Failed to log connection event for %s", device_id
                    )
