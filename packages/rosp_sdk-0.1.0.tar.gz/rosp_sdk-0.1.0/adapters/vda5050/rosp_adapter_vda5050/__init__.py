"""ROSP VDA 5050 Adapter — bridges VDA 5050 MQTT AGVs to RoboTrace.

Usage (standalone):
    from rosp_adapter_vda5050 import VDA5050Adapter

    adapter = VDA5050Adapter(config)
    await adapter.start()

Usage (ROSP SDK):
    from rosp_adapter_vda5050 import VDA5050ROSPAdapter

    async with VDA5050ROSPAdapter(config) as adapter:
        card = await adapter.describe()
        async for msg in await adapter.stream(["/sensor/pose"]):
            print(msg)
"""

__version__ = "0.1.0"

from rosp_adapter_vda5050.adapter import VDA5050Adapter
from rosp_adapter_vda5050.rosp_adapter import VDA5050ROSPAdapter

__all__ = ["VDA5050Adapter", "VDA5050ROSPAdapter"]
