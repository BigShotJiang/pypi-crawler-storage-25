"""MQTT connection and subscription management for VDA 5050 topics.

Handles async MQTT connectivity via aiomqtt, subscribes to VDA 5050 topic
patterns, parses topic structure to extract manufacturer/serial, and routes
messages to the appropriate handler callbacks.
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, Callable, Coroutine

import aiomqtt

logger = logging.getLogger("rosp_adapter_vda5050.mqtt")

# VDA 5050 topic suffixes and their semantic meaning
VDA5050_TOPICS = ("state", "order", "connection", "visualization")


@dataclass(frozen=True, slots=True)
class ParsedTopic:
    """Parsed components of a VDA 5050 MQTT topic."""

    interface_name: str   # e.g. "uagv"
    version: str          # e.g. "v2"
    manufacturer: str     # e.g. "robotis"
    serial_number: str    # e.g. "turtlebot3_001"
    topic_type: str       # e.g. "state", "order", "connection", "visualization"


def parse_vda5050_topic(topic: str) -> ParsedTopic | None:
    """Parse a VDA 5050 MQTT topic string into its components.

    Expected format: ``{interface_name}/{version}/{manufacturer}/{serial}/{type}``

    Returns None if the topic does not match the expected structure.
    """
    parts = topic.split("/")
    if len(parts) != 5:
        return None

    interface_name, version, manufacturer, serial_number, topic_type = parts

    if topic_type not in VDA5050_TOPICS:
        return None

    return ParsedTopic(
        interface_name=interface_name,
        version=version,
        manufacturer=manufacturer,
        serial_number=serial_number,
        topic_type=topic_type,
    )


# Type alias for message handler callbacks
MessageHandler = Callable[[str, str, str, dict[str, Any]], Coroutine[Any, Any, None]]
# Signature: (manufacturer, serial_number, topic_type, payload) -> None


class MQTTClient:
    """Async MQTT client for VDA 5050 topic subscription and message routing.

    Parameters
    ----------
    broker : str
        MQTT broker hostname or IP address.
    port : int
        MQTT broker port (default 1883).
    interface_name : str
        VDA 5050 interface name (default "uagv").
    version : str
        VDA 5050 protocol version (default "v2").
    manufacturers : list[dict] | None
        List of manufacturer configs: ``[{"name": "robotis", "serial_numbers": ["001"]}]``.
        If None or empty, subscribes to wildcard ``+/+`` for all AGVs.
    username : str | None
        MQTT username for authentication.
    password : str | None
        MQTT password for authentication.
    client_id : str | None
        MQTT client identifier.
    """

    def __init__(
        self,
        broker: str = "localhost",
        port: int = 1883,
        interface_name: str = "uagv",
        version: str = "v2",
        manufacturers: list[dict[str, Any]] | None = None,
        username: str | None = None,
        password: str | None = None,
        client_id: str | None = None,
    ) -> None:
        self._broker = broker
        self._port = port
        self._interface_name = interface_name
        self._version = version
        self._manufacturers = manufacturers or []
        self._username = username
        self._password = password
        self._client_id = client_id

        self._handlers: dict[str, MessageHandler] = {}
        self._running = False
        self._task: asyncio.Task[None] | None = None

    def register_handler(self, topic_type: str, handler: MessageHandler) -> None:
        """Register a handler callback for a VDA 5050 topic type.

        Parameters
        ----------
        topic_type : str
            One of "state", "order", "connection", "visualization".
        handler : MessageHandler
            Async callable ``(manufacturer, serial, topic_type, payload) -> None``.
        """
        if topic_type not in VDA5050_TOPICS:
            raise ValueError(
                f"Unknown topic type '{topic_type}'. Must be one of {VDA5050_TOPICS}"
            )
        self._handlers[topic_type] = handler
        logger.debug("Registered handler for topic type: %s", topic_type)

    def _build_subscriptions(self) -> list[str]:
        """Build the list of MQTT topic patterns to subscribe to."""
        prefix = f"{self._interface_name}/{self._version}"
        topics: list[str] = []

        if not self._manufacturers:
            # Wildcard: subscribe to all manufacturers and serial numbers
            for topic_type in VDA5050_TOPICS:
                topics.append(f"{prefix}/+/+/{topic_type}")
        else:
            for mfr in self._manufacturers:
                name = mfr.get("name", "+")
                serial_numbers = mfr.get("serial_numbers", [])
                if not serial_numbers:
                    # Wildcard for all serial numbers of this manufacturer
                    for topic_type in VDA5050_TOPICS:
                        topics.append(f"{prefix}/{name}/+/{topic_type}")
                else:
                    for serial in serial_numbers:
                        for topic_type in VDA5050_TOPICS:
                            topics.append(f"{prefix}/{name}/{serial}/{topic_type}")

        return topics

    async def start(self) -> None:
        """Connect to the MQTT broker and begin processing messages."""
        self._running = True
        self._task = asyncio.create_task(self._run_loop())
        logger.info(
            "MQTT client starting: broker=%s:%d", self._broker, self._port
        )

    async def stop(self) -> None:
        """Stop the MQTT client and disconnect."""
        self._running = False
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        logger.info("MQTT client stopped")

    async def _run_loop(self) -> None:
        """Main MQTT connection loop with automatic reconnection."""
        subscriptions = self._build_subscriptions()
        reconnect_delay = 1.0
        max_reconnect_delay = 60.0

        while self._running:
            try:
                async with aiomqtt.Client(
                    hostname=self._broker,
                    port=self._port,
                    username=self._username,
                    password=self._password,
                    identifier=self._client_id,
                ) as client:
                    # Subscribe to all VDA 5050 topics
                    for topic in subscriptions:
                        await client.subscribe(topic)
                        logger.debug("Subscribed to: %s", topic)

                    logger.info(
                        "MQTT connected to %s:%d (%d subscriptions)",
                        self._broker,
                        self._port,
                        len(subscriptions),
                    )
                    reconnect_delay = 1.0  # Reset on successful connection

                    async for message in client.messages:
                        if not self._running:
                            break
                        await self._dispatch_message(message)

            except aiomqtt.MqttError as exc:
                if not self._running:
                    break
                logger.warning(
                    "MQTT connection lost (%s), reconnecting in %.1fs",
                    exc,
                    reconnect_delay,
                )
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, max_reconnect_delay)

            except asyncio.CancelledError:
                break

            except Exception:
                if not self._running:
                    break
                logger.exception("Unexpected error in MQTT loop, reconnecting in %.1fs", reconnect_delay)
                await asyncio.sleep(reconnect_delay)
                reconnect_delay = min(reconnect_delay * 2, max_reconnect_delay)

    async def _dispatch_message(self, message: aiomqtt.Message) -> None:
        """Parse topic and route message to the appropriate handler."""
        topic_str = str(message.topic)
        parsed = parse_vda5050_topic(topic_str)

        if parsed is None:
            logger.debug("Ignoring unrecognized topic: %s", topic_str)
            return

        handler = self._handlers.get(parsed.topic_type)
        if handler is None:
            logger.debug("No handler for topic type: %s", parsed.topic_type)
            return

        # Parse JSON payload
        try:
            payload_bytes = message.payload
            if isinstance(payload_bytes, (bytes, bytearray)):
                payload = json.loads(payload_bytes.decode("utf-8"))
            else:
                payload = json.loads(str(payload_bytes))
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            logger.warning(
                "Malformed JSON payload on %s: %s", topic_str, exc
            )
            return

        if not isinstance(payload, dict):
            logger.warning(
                "Expected JSON object on %s, got %s", topic_str, type(payload).__name__
            )
            return

        try:
            await handler(
                parsed.manufacturer,
                parsed.serial_number,
                parsed.topic_type,
                payload,
            )
        except Exception:
            logger.exception(
                "Handler error for %s/%s on %s",
                parsed.manufacturer,
                parsed.serial_number,
                parsed.topic_type,
            )
