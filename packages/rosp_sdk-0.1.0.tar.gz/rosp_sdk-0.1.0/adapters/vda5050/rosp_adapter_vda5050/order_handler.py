"""VDA 5050 order handler — maps order lifecycle to RoboTrace missions.

- New order (new ``orderId``)    -> start mission via ``rt.mission()``
- Node/edge progress from state  -> create phases within the mission
- Action state changes           -> log decisions when FINISHED
- Order completion               -> end mission
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("rosp_adapter_vda5050.order")

# Attempt to import RoboTrace SDK
try:
    from robotrace import Log

    _HAS_ROBOTRACE = True
except ImportError:
    _HAS_ROBOTRACE = False


@dataclass
class ActiveMission:
    """Tracks an active VDA 5050 order mapped to a RoboTrace mission."""

    order_id: str
    order_update_id: int
    mission: Any  # RoboTrace Mission object or None
    current_phase: Any = None  # Current phase context manager
    completed_nodes: set[str] = field(default_factory=set)
    completed_edges: set[str] = field(default_factory=set)
    completed_actions: set[str] = field(default_factory=set)


class OrderHandler:
    """Processes VDA 5050 order messages and manages RoboTrace mission lifecycle.

    Parameters
    ----------
    get_rt_client : callable | None
        Callable that returns a RoboTrace client for a given device_id.
        Signature: ``(device_id: str) -> RoboTrace | None``
    """

    def __init__(self, get_rt_client: Any = None) -> None:
        self._get_rt_client = get_rt_client
        # Active missions keyed by device_id
        self._active_missions: dict[str, ActiveMission] = {}
        self._stats = {
            "orders_received": 0,
            "missions_started": 0,
            "missions_completed": 0,
            "phases_created": 0,
        }

    @property
    def stats(self) -> dict[str, int]:
        """Return a copy of handler statistics."""
        return dict(self._stats)

    @property
    def active_missions(self) -> dict[str, ActiveMission]:
        """Return active missions (read-only reference for testing)."""
        return self._active_missions

    def _make_device_id(self, manufacturer: str, serial_number: str) -> str:
        """Build a ROSP-style device URN from manufacturer and serial."""
        return f"urn:rosp:device:{manufacturer}:{serial_number}"

    async def handle_order(
        self,
        manufacturer: str,
        serial_number: str,
        topic_type: str,
        payload: dict[str, Any],
    ) -> None:
        """Process a VDA 5050 order message.

        When a new orderId is seen, a new RoboTrace mission is started.
        Order updates (same orderId, higher orderUpdateId) update the
        existing mission with new nodes/edges/actions.

        Parameters
        ----------
        manufacturer : str
            AGV manufacturer name.
        serial_number : str
            AGV serial number.
        topic_type : str
            Always "order" for this handler.
        payload : dict
            Parsed VDA 5050 order message.
        """
        self._stats["orders_received"] += 1
        device_id = self._make_device_id(manufacturer, serial_number)

        order_id = payload.get("orderId")
        if order_id is None:
            logger.warning("Order message missing orderId from %s", device_id)
            return

        order_update_id = int(payload.get("orderUpdateId", 0))

        active = self._active_missions.get(device_id)

        if active is None or active.order_id != order_id:
            # New order — finish any existing mission first
            await self._finish_mission(device_id)
            await self._start_mission(device_id, order_id, order_update_id, payload)
        elif order_update_id > active.order_update_id:
            # Order update — extend the current mission
            active.order_update_id = order_update_id
            logger.info(
                "Order update [%s]: orderId=%s updateId=%d",
                device_id,
                order_id,
                order_update_id,
            )
            # Log the update event
            self._log_event(
                device_id,
                f"Order updated: {order_id} (update {order_update_id})",
            )

    async def handle_state_progress(
        self,
        manufacturer: str,
        serial_number: str,
        payload: dict[str, Any],
    ) -> None:
        """Extract order progress from a VDA 5050 state message.

        Called by the adapter when a state message is received, to track
        node/edge traversal and action completion within the active mission.

        Parameters
        ----------
        manufacturer : str
            AGV manufacturer name.
        serial_number : str
            AGV serial number.
        payload : dict
            Parsed VDA 5050 state message (contains nodeStates, edgeStates, actionStates).
        """
        device_id = self._make_device_id(manufacturer, serial_number)
        active = self._active_missions.get(device_id)
        if active is None:
            return

        # Track node progress
        node_states = payload.get("nodeStates", [])
        for node in node_states:
            node_id = node.get("nodeId", "")
            released = node.get("released", False)
            if released and node_id and node_id not in active.completed_nodes:
                active.completed_nodes.add(node_id)
                self._stats["phases_created"] += 1
                logger.info(
                    "Node reached [%s]: %s (order=%s)",
                    device_id,
                    node_id,
                    active.order_id,
                )
                self._log_event(
                    device_id,
                    f"Node reached: {node_id}",
                )

        # Track action states
        action_states = payload.get("actionStates", [])
        for action in action_states:
            action_id = action.get("actionId", "")
            action_status = action.get("actionStatus", "")
            action_type = action.get("actionType", "")

            if action_status == "FINISHED" and action_id not in active.completed_actions:
                active.completed_actions.add(action_id)
                logger.info(
                    "Action completed [%s]: %s (%s) order=%s",
                    device_id,
                    action_id,
                    action_type,
                    active.order_id,
                )
                self._log_event(
                    device_id,
                    f"Action finished: {action_type} ({action_id})",
                )
            elif action_status == "FAILED":
                logger.warning(
                    "Action failed [%s]: %s (%s) order=%s",
                    device_id,
                    action_id,
                    action_type,
                    active.order_id,
                )
                self._log_event(
                    device_id,
                    f"Action FAILED: {action_type} ({action_id})",
                    level="ERROR",
                )

        # Check if order is complete: all nodes traversed and no running actions
        await self._check_order_completion(device_id, payload)

    async def _start_mission(
        self,
        device_id: str,
        order_id: str,
        order_update_id: int,
        payload: dict[str, Any],
    ) -> None:
        """Start a new RoboTrace mission for an order."""
        self._stats["missions_started"] += 1

        mission = None
        rt = None
        if _HAS_ROBOTRACE and self._get_rt_client is not None:
            rt = self._get_rt_client(device_id)
            if rt is not None:
                # Extract order metadata for tags
                zones = payload.get("zoneSetId", "")
                tags = [f"vda5050-order:{order_id}"]
                if zones:
                    tags.append(f"zone-set:{zones}")

                mission_name = f"vda5050-{order_id}"
                try:
                    mission = rt.mission(
                        name=mission_name,
                        tags=tags,
                        metadata={
                            "order_id": order_id,
                            "order_update_id": order_update_id,
                            "source": "vda5050",
                        },
                    )
                    # Enter the mission context
                    mission.__enter__()
                except Exception:
                    logger.exception(
                        "Failed to start RoboTrace mission for order %s",
                        order_id,
                    )
                    mission = None

        self._active_missions[device_id] = ActiveMission(
            order_id=order_id,
            order_update_id=order_update_id,
            mission=mission,
        )

        logger.info(
            "Mission started [%s]: orderId=%s updateId=%d",
            device_id,
            order_id,
            order_update_id,
        )

    async def _finish_mission(self, device_id: str) -> None:
        """End the active mission for a device, if any."""
        active = self._active_missions.pop(device_id, None)
        if active is None:
            return

        self._stats["missions_completed"] += 1

        if active.mission is not None:
            try:
                active.mission.__exit__(None, None, None)
            except Exception:
                logger.exception(
                    "Failed to end RoboTrace mission for order %s",
                    active.order_id,
                )

        logger.info(
            "Mission completed [%s]: orderId=%s nodes=%d actions=%d",
            device_id,
            active.order_id,
            len(active.completed_nodes),
            len(active.completed_actions),
        )

    async def _check_order_completion(
        self, device_id: str, payload: dict[str, Any]
    ) -> None:
        """Check if the current order is complete and end the mission if so.

        An order is considered complete when:
        - ``orderId`` in state matches the active order
        - No action is in RUNNING or WAITING state
        - The AGV reports ``lastNodeId`` matching the last node in the order
        """
        active = self._active_missions.get(device_id)
        if active is None:
            return

        state_order_id = payload.get("orderId", "")
        if state_order_id != active.order_id:
            return

        # Check if any actions are still running
        action_states = payload.get("actionStates", [])
        has_running = any(
            a.get("actionStatus") in ("RUNNING", "WAITING", "INITIALIZING")
            for a in action_states
        )
        if has_running:
            return

        # Check if the AGV has reached the last node and has no more base nodes
        node_states = payload.get("nodeStates", [])
        if not node_states and active.completed_nodes:
            # No remaining nodes to traverse AND at least one node was reached — order is done
            await self._finish_mission(device_id)

    def _log_event(
        self, device_id: str, message: str, level: str = "INFO"
    ) -> None:
        """Log an event to RoboTrace if the SDK is available."""
        if not _HAS_ROBOTRACE or self._get_rt_client is None:
            return

        rt = self._get_rt_client(device_id)
        if rt is not None:
            try:
                rt.log("events/order", Log(message=message, level=level))
            except Exception:
                logger.debug("Failed to log order event: %s", message)

    async def shutdown(self) -> None:
        """Finish all active missions during shutdown."""
        device_ids = list(self._active_missions.keys())
        for device_id in device_ids:
            await self._finish_mission(device_id)
        logger.info("Order handler shutdown: completed %d missions", len(device_ids))
