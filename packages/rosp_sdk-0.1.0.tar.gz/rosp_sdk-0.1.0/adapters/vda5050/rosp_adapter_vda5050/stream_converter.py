"""Convert VDA 5050 state payloads to ROSP StreamMessage format.

Maps ROSP sensor topic paths to VDA 5050 state message fields:
    /sensor/pose      -> agvPosition
    /sensor/battery   -> batteryState
    /sensor/velocity  -> velocity
    /sensor/loads     -> loads
    /status/safety    -> safetyState
    /status/mode      -> operatingMode
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, List

from rosp_sdk.models import StreamMessage

# Map ROSP topic paths to VDA 5050 state message field names
TOPIC_MAP: Dict[str, str] = {
    "/sensor/pose": "agvPosition",
    "/sensor/battery": "batteryState",
    "/sensor/velocity": "velocity",
    "/sensor/loads": "loads",
    "/status/safety": "safetyState",
    "/status/mode": "operatingMode",
}

# Reverse map for looking up ROSP topic from VDA 5050 field
FIELD_TO_TOPIC: Dict[str, str] = {v: k for k, v in TOPIC_MAP.items()}


def convert_state_to_stream_messages(
    state: Dict[str, Any],
    topics: List[str],
    seq_counters: Dict[str, int],
) -> List[StreamMessage]:
    """Extract requested topics from a VDA 5050 state message.

    Parameters
    ----------
    state : dict
        Raw VDA 5050 state payload.
    topics : list[str]
        ROSP topic paths to extract (e.g., ["/sensor/pose", "/sensor/battery"]).
    seq_counters : dict[str, int]
        Mutable dict tracking per-topic sequence numbers. Updated in place.

    Returns
    -------
    list[StreamMessage]
        One StreamMessage per matched topic that has data in the state payload.
    """
    # Parse VDA 5050 timestamp or use current UTC time
    ts_str = state.get("timestamp")
    if ts_str:
        try:
            timestamp = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        except (ValueError, AttributeError):
            timestamp = datetime.now(timezone.utc)
    else:
        timestamp = datetime.now(timezone.utc)

    messages: List[StreamMessage] = []
    for topic in topics:
        vda_field = TOPIC_MAP.get(topic)
        if vda_field is None:
            continue

        data = state.get(vda_field)
        if data is None:
            continue

        # Increment sequence counter for this topic
        seq = seq_counters.get(topic, 0) + 1
        seq_counters[topic] = seq

        messages.append(
            StreamMessage(
                topic=topic,
                seq=seq,
                timestamp=timestamp,
                encoding="json",
                data=data if isinstance(data, dict) else {"value": data},
            )
        )

    return messages
