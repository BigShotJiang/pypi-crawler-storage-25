"""Tests for ROSP gRPC Adapter — unit tests (no server needed)."""

import asyncio

import pytest

from rosp_adapter_grpc import GRPCAdapter
from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.models import (
    AdapterStatus,
    RobotCard,
    RobotStatus,
    StreamQoS,
)


class TestGRPCAdapterInterface:
    """Verify GRPCAdapter implements the ROSPAdapter interface correctly."""

    def test_is_rosp_adapter_subclass(self):
        assert issubclass(GRPCAdapter, ROSPAdapter)

    def test_has_all_required_methods(self):
        methods = ["connect", "disconnect", "describe", "stream", "discover", "health_check"]
        for method in methods:
            assert hasattr(GRPCAdapter, method)
            assert callable(getattr(GRPCAdapter, method))

    def test_instantiation_with_config(self):
        config = {
            "robot_id": "urn:rosp:device:test:bot:001",
            "grpc_endpoint": "localhost:50051",
        }
        adapter = GRPCAdapter(config)
        assert adapter.is_connected is False
        assert adapter.config["grpc_endpoint"] == "localhost:50051"

    def test_instantiation_without_config(self):
        adapter = GRPCAdapter()
        assert adapter.is_connected is False
        assert adapter.config == {}


class TestGRPCAdapterDisconnected:
    """Tests that run without a gRPC server connection."""

    @pytest.mark.asyncio
    async def test_describe_without_connect_raises(self):
        adapter = GRPCAdapter({"grpc_endpoint": "localhost:99999"})
        with pytest.raises(ConnectionError, match="not connected"):
            await adapter.describe()

    @pytest.mark.asyncio
    async def test_health_when_disconnected(self):
        adapter = GRPCAdapter({"grpc_endpoint": "localhost:99999"})
        health = await adapter.health_check()
        assert health.adapter_status == AdapterStatus.DISCONNECTED
        assert health.robot_status == RobotStatus.DISCONNECTED
        assert health.latency_ms == 0.0

    @pytest.mark.asyncio
    async def test_connect_timeout(self):
        adapter = GRPCAdapter({
            "grpc_endpoint": "localhost:99999",
            "connect_timeout_s": 1,
        })
        with pytest.raises(ConnectionError, match="timed out"):
            await adapter.connect()
        # Issue #2: Channel should be cleaned up after timeout
        assert adapter._channel is None

    @pytest.mark.asyncio
    async def test_discover_without_connect(self):
        adapter = GRPCAdapter({
            "robot_id": "urn:rosp:device:test:bot:001",
            "model": "TestBot",
            "manufacturer": "TestCorp",
            "grpc_endpoint": "localhost:50051",
        })
        # discover() doesn't require connection (returns config-based info)
        info = await adapter.discover()
        assert info.robot_id == "urn:rosp:device:test:bot:001"
        assert info.endpoint == "grpc://localhost:50051"
        assert info.mode == "description"


class TestGRPCAdapterConfigBased:
    """Test config-based Robot Card generation (no server needed)."""

    @pytest.mark.asyncio
    async def test_describe_falls_back_to_config(self):
        """When no gRPC server is available, describe() should use config."""
        # We can't connect, but we can test the config-based fallback
        # by mocking the connection state
        config = {
            "robot_id": "urn:rosp:device:test:cobot:001",
            "manufacturer": "TestCorp",
            "model": "TestCobot",
            "robot_type": "cobot",
            "grpc_endpoint": "localhost:50051",
            "weight_kg": 20.0,
            "payload_kg": 5.0,
            "degrees_of_freedom": 6,
            "sensors": [
                {"sensor_id": "joints", "type": "encoder"},
                {"sensor_id": "ft", "type": "force_torque"},
            ],
            "actuators": [
                {"actuator_id": "j0", "type": "joint", "control_modes": ["position"]},
            ],
        }
        adapter = GRPCAdapter(config)
        # Manually set connected state to test describe logic
        adapter._connected = True
        adapter._channel = True  # Fake channel (won't be used for config path)

        # Force config-based path by ensuring ROSP stubs aren't available
        card = await adapter.describe()
        assert card.rosp_version == "0.1"
        assert card.identity["manufacturer"] == "TestCorp"
        assert card.identity["type"] == "cobot"
        assert len(card.sensors) == 2
        assert len(card.actuators) == 1

    def test_infer_capabilities_manipulation(self):
        adapter = GRPCAdapter({})
        caps = adapter._infer_capabilities(
            sensors=[{"type": "force_torque"}],
            actuators=[{"type": "joint"}, {"type": "gripper"}],
        )
        cap_ids = {c["capability_id"] for c in caps}
        assert "manipulation" in cap_ids
        assert "force_control" in cap_ids

    def test_infer_capabilities_navigation(self):
        adapter = GRPCAdapter({})
        caps = adapter._infer_capabilities(
            sensors=[{"type": "lidar"}],
            actuators=[{"type": "wheel"}],
        )
        cap_ids = {c["capability_id"] for c in caps}
        assert "navigation" in cap_ids

    def test_infer_capabilities_empty(self):
        adapter = GRPCAdapter({})
        caps = adapter._infer_capabilities(sensors=[], actuators=[])
        assert caps == []

    def test_build_identity(self):
        adapter = GRPCAdapter({
            "manufacturer": "Boston Dynamics",
            "model": "Spot",
            "robot_type": "quadruped",
        })
        identity = adapter._build_identity()
        assert identity["manufacturer"] == "Boston Dynamics"
        assert identity["type"] == "quadruped"

    def test_build_hardware(self):
        adapter = GRPCAdapter({
            "weight_kg": 32.0,
            "payload_kg": 14.0,
            "degrees_of_freedom": 12,
        })
        hw = adapter._build_hardware()
        assert hw["weight_kg"] == 32.0
        assert hw["degrees_of_freedom"] == 12

    def test_build_integration(self):
        adapter = GRPCAdapter({
            "grpc_endpoint": "192.168.1.100:50051",
            "use_tls": True,
        })
        integration = adapter._build_integration()
        assert integration["supported_protocols"][0]["protocol"] == "grpc"
        assert "192.168.1.100:50051" in integration["supported_protocols"][0]["endpoint"]
        assert integration["supported_protocols"][0]["auth_method"] == "tls"


class TestGRPCAdapterUptime:
    """Test uptime tracking."""

    @pytest.mark.asyncio
    async def test_uptime_increases(self):
        adapter = GRPCAdapter({})
        t1 = adapter.uptime_seconds
        await asyncio.sleep(0.05)
        t2 = adapter.uptime_seconds
        assert t2 > t1


class TestProtoToDict:
    """Test protobuf message conversion."""

    def test_dict_passthrough(self):
        adapter = GRPCAdapter({})
        result = adapter._proto_to_dict({"key": "value"})
        assert result == {"key": "value"}

    def test_json_bytes(self):
        adapter = GRPCAdapter({})
        result = adapter._proto_to_dict(b'{"temperature": 42.5}')
        assert result["temperature"] == 42.5

    def test_invalid_bytes(self):
        adapter = GRPCAdapter({})
        result = adapter._proto_to_dict(b'\x00\x01\x02')
        assert "raw_bytes" in result
