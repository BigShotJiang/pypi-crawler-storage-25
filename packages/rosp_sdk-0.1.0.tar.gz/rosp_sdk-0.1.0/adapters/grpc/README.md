# rosp-adapter-grpc

ROSP adapter for gRPC-based robots. Connects Boston Dynamics Spot, Viam robots, and any custom gRPC robot to the ROSP ecosystem.

## Install

```bash
pip install rosp-adapter-grpc
```

## Usage

```bash
# Connect to a gRPC robot and export its Robot Card
rosp-grpc --robot-id urn:rosp:device:fakerobot:cobot6dof:001 \
          --endpoint localhost:50051 \
          --model "Cobot-6DOF" --manufacturer "FakeRobot" --type cobot \
          --export-card

# Stream sensor data
rosp-grpc --robot-id urn:rosp:device:fakerobot:cobot6dof:001 \
          --endpoint localhost:50051 \
          --stream /sensor/joint_states /sensor/force_torque

# Check health
rosp-grpc --endpoint localhost:50051 --robot-id test --health
```

## Supported Robots

- **ROSP-native**: Any robot implementing the ROSP Robot Service proto
- **Boston Dynamics Spot**: Via service mapping (coming soon)
- **Viam-connected robots**: Via Viam gRPC API mapping (coming soon)
- **Custom gRPC robots**: Configure service mapping in config

Requires gRPC server to be accessible at the specified endpoint.
