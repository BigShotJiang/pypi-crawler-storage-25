"""ROSP gRPC Adapter — connects any gRPC-based robot to the ROSP ecosystem.

Supports:
- Robots implementing the ROSP Robot Service (proto/rosp/v1/robot_service.proto)
- Generic gRPC robots with custom service definitions
- Configurable service mapping for Spot, Viam, and custom APIs

Usage:
    from rosp_adapter_grpc import GRPCAdapter

    async with GRPCAdapter(config) as adapter:
        card = await adapter.describe()
        async for msg in adapter.stream(["/sensor/joint_states"]):
            print(msg.data)
"""

__version__ = "0.1.0"

from rosp_adapter_grpc.adapter import GRPCAdapter

__all__ = ["GRPCAdapter"]
