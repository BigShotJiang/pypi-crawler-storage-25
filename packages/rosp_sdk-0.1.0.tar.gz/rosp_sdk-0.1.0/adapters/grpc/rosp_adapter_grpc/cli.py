"""ROSP gRPC Adapter CLI — run the adapter from the command line.

Usage:
    rosp-grpc --robot-id urn:rosp:device:boston-dynamics:spot:001 \
              --endpoint localhost:50051 \
              --model "Spot" --manufacturer "Boston Dynamics" --type quadruped

    rosp-grpc --endpoint localhost:50051 --export-card
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
import signal


def parse_args():
    parser = argparse.ArgumentParser(
        description="ROSP gRPC Adapter — connect a gRPC robot to the ROSP ecosystem",
    )

    parser.add_argument("--robot-id", required=True, help="Robot URN identifier")
    parser.add_argument("--endpoint", default="localhost:50051", help="gRPC server address")
    parser.add_argument("--model", default="Unknown", help="Robot model name")
    parser.add_argument("--manufacturer", default="Unknown", help="Manufacturer name")
    parser.add_argument(
        "--type", default="custom",
        choices=[
            "mobile_robot", "articulated_arm", "humanoid", "cobot",
            "agv", "amr", "quadruped", "drone",
            "sensor", "actuator", "infrastructure", "station", "controller", "end_effector",
            "custom",
        ],
        help="Robot type",
    )
    parser.add_argument("--tls", action="store_true", help="Use TLS")
    parser.add_argument("--cert", default=None, help="TLS certificate path")

    # Actions
    parser.add_argument("--export-card", action="store_true", help="Export Robot Card as JSON")
    parser.add_argument("--stream", nargs="+", help="Stream sensor topics")
    parser.add_argument("--health", action="store_true", help="Check health and exit")
    parser.add_argument("--discover", action="store_true", help="Print discovery info")

    return parser.parse_args()


async def run_adapter(args):
    from rosp_adapter_grpc import GRPCAdapter

    config = {
        "robot_id": args.robot_id,
        "model": args.model,
        "manufacturer": args.manufacturer,
        "robot_type": args.type,
        "grpc_endpoint": args.endpoint,
        "use_tls": args.tls,
        "tls_cert_path": args.cert,
    }

    async with GRPCAdapter(config) as adapter:
        if args.export_card:
            card_json = await adapter.export_card_json()
            print(card_json)
            return

        if args.health:
            health = await adapter.health_check()
            print(json.dumps(health.to_dict(), indent=2))
            return

        if args.discover:
            info = await adapter.discover()
            print(json.dumps(info.to_dict(), indent=2))
            return

        if args.stream:
            print(f"Streaming from topics: {args.stream}", file=sys.stderr)
            count = 0
            async for msg in adapter.stream(args.stream):
                count += 1
                print(json.dumps({
                    "topic": msg.topic,
                    "seq": msg.seq,
                    "timestamp": msg.timestamp.isoformat(),
                    "data_keys": list(msg.data.keys()),
                }))
                if count % 100 == 0:
                    print(f"[{count} messages]", file=sys.stderr)
            return

        # Default: show status
        print(f"ROSP gRPC Adapter for: {args.robot_id}", file=sys.stderr)
        health = await adapter.health_check()
        print(f"Status: {health.adapter_status.value} / {health.robot_status.value}", file=sys.stderr)
        print(f"\nPress Ctrl+C to stop.", file=sys.stderr)

        stop = asyncio.Event()
        try:
            await stop.wait()
        except KeyboardInterrupt:
            pass


def main():
    args = parse_args()
    try:
        asyncio.run(run_adapter(args))
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
