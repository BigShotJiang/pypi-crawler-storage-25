"""ROSP gRPC Adapter — bridges ROSP to any gRPC-based robot.

Connects to robots that expose gRPC APIs and translates them to the
standard ROSP adapter interface. Supports three connection modes:

1. **ROSP-native**: Robot implements the ROSP Robot Service proto
2. **Generic gRPC**: Robot has custom gRPC services, mapped via config
3. **Reflection**: Auto-discovers services via gRPC server reflection

Requires: grpcio, grpcio-tools, protobuf
"""

from __future__ import annotations

import asyncio
import json
import logging
import queue as thread_queue
import time
from datetime import datetime, timezone
from typing import Any, AsyncIterator, Dict, List, Optional

import grpc
import grpc.aio

from rosp_sdk.adapter import ROSPAdapter
from rosp_sdk.models import (
    AdapterStatus,
    DiscoveryInfo,
    HealthStatus,
    RobotCard,
    RobotStatus,
    StreamMessage,
    StreamQoS,
)

logger = logging.getLogger(__name__)


class GRPCAdapter(ROSPAdapter):
    """ROSP adapter for gRPC-based robots."""

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        super().__init__(config)
        self._channel: Optional[grpc.aio.Channel] = None
        # Cached ROSP stubs — created once on first use (Issue #11)
        self._rosp_stub = None
        self._rosp_pb2 = None
        # Message queue for multi-topic streaming (Issue #8)
        self._stream_queue: Optional[thread_queue.Queue] = None
        self._active_stream_tasks: List[asyncio.Task] = []

    async def connect(self) -> None:
        """Establish gRPC channel to the robot."""
        endpoint = self.config.get("grpc_endpoint", "localhost:50051")
        use_tls = self.config.get("use_tls", False)

        if use_tls:
            cert_path = self.config.get("tls_cert_path")
            if cert_path:
                with open(cert_path, "rb") as f:
                    credentials = grpc.ssl_channel_credentials(f.read())
            else:
                credentials = grpc.ssl_channel_credentials()
            self._channel = grpc.aio.secure_channel(endpoint, credentials)
        else:
            self._channel = grpc.aio.insecure_channel(endpoint)

        # Issue #2: Close channel on timeout to prevent resource leak
        try:
            await asyncio.wait_for(
                self._channel.channel_ready(),
                timeout=self.config.get("connect_timeout_s", 10),
            )
        except asyncio.TimeoutError:
            await self._channel.close()
            self._channel = None
            raise ConnectionError(
                f"gRPC connection to {endpoint} timed out after "
                f"{self.config.get('connect_timeout_s', 10)}s"
            )

        self._connected = True
        # Reset cached stubs on new connection
        self._rosp_stub = None
        self._rosp_pb2 = None
        logger.info(f"ROSP gRPC Adapter connected to {endpoint}")

    async def disconnect(self) -> None:
        """Close the gRPC channel and cancel active streams."""
        self._connected = False

        # Cancel active stream tasks (Issue #9: now properly populated)
        for task in self._active_stream_tasks:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, Exception):
                pass
        self._active_stream_tasks.clear()

        # Clear cached stubs
        self._rosp_stub = None
        self._rosp_pb2 = None

        if self._channel:
            await self._channel.close()
            self._channel = None

    async def describe(self, depth: str = "full") -> RobotCard:
        """Build a Robot Card from gRPC robot information."""
        self._ensure_connected()

        # Try ROSP-native describe first
        native_card = await self._try_rosp_native_describe(depth)
        if native_card:
            return native_card

        # Fall back to config-based description
        identity = self._build_identity()
        hardware = self._build_hardware()
        sensors = self.config.get("sensors", [])
        actuators = self.config.get("actuators", [])
        capabilities = self._infer_capabilities(sensors, actuators)

        # Try gRPC reflection to discover services
        if not sensors and not actuators:
            reflected = await self._try_reflection_discovery()
            if reflected:
                sensors = reflected.get("sensors", [])
                actuators = reflected.get("actuators", [])
                capabilities = reflected.get("capabilities", [])

        integration = self._build_integration()

        return RobotCard(
            rosp_version="0.1",
            id=self.config.get("robot_id", "urn:rosp:device:unknown:unknown:000"),
            identity=identity,
            hardware=hardware,
            sensors=sensors,
            actuators=actuators,
            capabilities=capabilities,
            integration=integration,
            safety=self.config.get("safety", {}),
            coordinate_frames=self.config.get("coordinate_frames"),
            created_at=datetime.now(timezone.utc).isoformat(),
            updated_at=datetime.now(timezone.utc).isoformat(),
        )

    async def stream(
        self, topics: List[str], qos: Optional[StreamQoS] = None
    ) -> AsyncIterator[StreamMessage]:
        """Stream sensor data from the gRPC robot.

        Issue #8 fix: Uses a shared queue with per-topic async tasks
        to handle multiple infinite streams concurrently (same pattern
        as the ROS2 adapter).
        """
        self._ensure_connected()
        qos = qos or StreamQoS()

        # Try ROSP-native streaming first
        if await self._has_rosp_service():
            async for msg in self._stream_rosp_native(topics, qos):
                yield msg
            return

        # Fall back to mapped gRPC calls with concurrent topic handling
        service_mapping = self.config.get("service_mapping", {})
        msg_queue: asyncio.Queue = asyncio.Queue(maxsize=1000)

        async def _stream_topic(topic: str, mapping: dict):
            """Stream a single topic into the shared queue."""
            seq = 0
            try:
                method = self._get_grpc_method(mapping["service"], mapping["method"])
                request = self._build_request(mapping.get("request", {}))
                async for response in method(request):
                    msg = StreamMessage(
                        topic=topic,
                        seq=seq,
                        timestamp=datetime.now(timezone.utc),
                        encoding="json",
                        data=self._proto_to_dict(response),
                    )
                    await msg_queue.put(msg)
                    seq += 1
            except asyncio.CancelledError:
                pass
            except grpc.aio.AioRpcError as e:
                logger.warning(f"gRPC stream error on {topic}: {e.code()} {e.details()}")
            except Exception as e:
                logger.warning(f"Stream error on {topic}: {e}")

        # Start a task per mapped topic
        tasks = []
        for topic in topics:
            if topic in service_mapping:
                task = asyncio.create_task(_stream_topic(topic, service_mapping[topic]))
                tasks.append(task)
                self._active_stream_tasks.append(task)

        # Yield from shared queue
        try:
            while self._connected and (tasks or not msg_queue.empty()):
                try:
                    msg = await asyncio.wait_for(msg_queue.get(), timeout=0.1)
                    yield msg
                except asyncio.TimeoutError:
                    # Check if all tasks are done
                    tasks = [t for t in tasks if not t.done()]
                    if not tasks and msg_queue.empty():
                        break
        finally:
            for task in tasks:
                task.cancel()
            self._active_stream_tasks = [
                t for t in self._active_stream_tasks if t not in tasks
            ]

    async def discover(self) -> DiscoveryInfo:
        """Return discovery information for this adapter."""
        endpoint = self.config.get("grpc_endpoint", "localhost:50051")
        return DiscoveryInfo(
            robot_id=self.config.get("robot_id", "urn:rosp:device:unknown:unknown:000"),
            model=self.config.get("model", "Unknown"),
            manufacturer=self.config.get("manufacturer", "Unknown"),
            rosp_version="0.1",
            adapter_version="0.1.0",
            capabilities_summary=self.config.get("capabilities_summary", []),
            endpoint=f"grpc://{endpoint}",
            mode="description",
        )

    async def health_check(self) -> HealthStatus:
        """Check gRPC connection health."""
        if not self._connected or not self._channel:
            return HealthStatus(
                adapter_status=AdapterStatus.DISCONNECTED,
                robot_status=RobotStatus.DISCONNECTED,
                latency_ms=0.0,
                uptime_seconds=self.uptime_seconds,
            )

        start = time.monotonic()
        state = self._channel.get_state(try_to_connect=True)
        latency_ms = (time.monotonic() - start) * 1000

        # Issue #6: Map channel state to BOTH adapter and robot status
        robot_state_map = {
            grpc.ChannelConnectivity.READY: RobotStatus.CONNECTED,
            grpc.ChannelConnectivity.IDLE: RobotStatus.CONNECTED,
            grpc.ChannelConnectivity.CONNECTING: RobotStatus.DEGRADED,
            grpc.ChannelConnectivity.TRANSIENT_FAILURE: RobotStatus.DEGRADED,
            grpc.ChannelConnectivity.SHUTDOWN: RobotStatus.DISCONNECTED,
        }
        adapter_state_map = {
            grpc.ChannelConnectivity.READY: AdapterStatus.HEALTHY,
            grpc.ChannelConnectivity.IDLE: AdapterStatus.HEALTHY,
            grpc.ChannelConnectivity.CONNECTING: AdapterStatus.DEGRADED,
            grpc.ChannelConnectivity.TRANSIENT_FAILURE: AdapterStatus.DEGRADED,
            grpc.ChannelConnectivity.SHUTDOWN: AdapterStatus.DISCONNECTED,
        }

        return HealthStatus(
            adapter_status=adapter_state_map.get(state, AdapterStatus.DEGRADED),
            robot_status=robot_state_map.get(state, RobotStatus.UNKNOWN),
            latency_ms=latency_ms,
            uptime_seconds=self.uptime_seconds,
            details={
                "grpc_state": str(state),
                "endpoint": self.config.get("grpc_endpoint", "unknown"),
                "use_tls": self.config.get("use_tls", False),
            },
        )

    # --- Private helpers ---

    def _ensure_connected(self):
        if not self._connected or not self._channel:
            raise ConnectionError(
                "Adapter not connected. Call connect() first or use async context manager."
            )

    def _build_identity(self) -> Dict[str, Any]:
        return {
            "manufacturer": self.config.get("manufacturer", "Unknown"),
            "model": self.config.get("model", "Unknown"),
            "type": self.config.get("robot_type", "custom"),
            "firmware_version": self.config.get("firmware_version", "unknown"),
            "description": self.config.get("description", ""),
        }

    def _build_hardware(self) -> Dict[str, Any]:
        hardware: Dict[str, Any] = {}
        for key in [
            "weight_kg", "dimensions", "payload_kg", "degrees_of_freedom",
            "reach_m", "battery", "compute",
        ]:
            if key in self.config:
                hardware[key] = self.config[key]
        return hardware

    def _build_integration(self) -> Dict[str, Any]:
        endpoint = self.config.get("grpc_endpoint", "localhost:50051")
        return {
            "supported_protocols": [
                {
                    "protocol": "grpc",
                    "version": grpc.__version__,
                    "endpoint": f"grpc://{endpoint}",
                    "auth_method": "tls" if self.config.get("use_tls") else "none",
                }
            ],
        }

    def _infer_capabilities(
        self, sensors: List[Dict], actuators: List[Dict]
    ) -> List[Dict[str, Any]]:
        capabilities = []
        sensor_types = {s.get("type") for s in sensors}
        actuator_types = {a.get("type") for a in actuators}

        if "joint" in actuator_types or "gripper" in actuator_types:
            capabilities.append({
                "capability_id": "manipulation", "name": "Robotic Manipulation", "type": "manipulation",
            })
        if "wheel" in actuator_types and ("lidar" in sensor_types or "camera_rgb" in sensor_types):
            capabilities.append({
                "capability_id": "navigation", "name": "Autonomous Navigation", "type": "navigation",
            })
        if "camera_rgb" in sensor_types or "camera_depth" in sensor_types:
            capabilities.append({
                "capability_id": "perception", "name": "Visual Perception", "type": "perception",
            })
        if "force_torque" in sensor_types:
            capabilities.append({
                "capability_id": "force_control", "name": "Force-Controlled Manipulation", "type": "manipulation",
            })
        return capabilities

    # --- ROSP-native gRPC (compiled protobuf stubs) ---

    def _get_rosp_stubs(self):
        """Get cached ROSP stubs. Issue #11: Only created once per connection."""
        if self._rosp_stub is not None:
            return self._rosp_stub, self._rosp_pb2
        try:
            from rosp_adapter_grpc.rosp.v1 import robot_service_pb2 as pb2
            from rosp_adapter_grpc.rosp.v1 import robot_service_pb2_grpc as pb2_grpc
            self._rosp_stub = pb2_grpc.RobotServiceStub(self._channel)
            self._rosp_pb2 = pb2
            return self._rosp_stub, self._rosp_pb2
        except ImportError:
            logger.debug("Compiled ROSP proto stubs not available")
            return None, None

    async def _has_rosp_service(self) -> bool:
        stub, pb2 = self._get_rosp_stubs()
        if not stub:
            return False
        try:
            await stub.GetHealth(pb2.HealthRequest())
            return True
        except grpc.aio.AioRpcError:
            return False
        except Exception:
            return False

    async def _try_rosp_native_describe(self, depth: str) -> Optional[RobotCard]:
        stub, pb2 = self._get_rosp_stubs()
        if not stub:
            return None
        try:
            response = await stub.Describe(pb2.DescribeRequest(depth=depth))
            return self._proto_card_to_rosp(response)
        except grpc.aio.AioRpcError as e:
            logger.debug(f"ROSP-native describe failed: {e.code()}")
        except Exception as e:
            logger.debug(f"ROSP-native describe error: {e}")
        return None

    def _proto_card_to_rosp(self, proto_card) -> RobotCard:
        """Convert a protobuf RobotCard to an SDK RobotCard."""
        from google.protobuf.json_format import MessageToDict

        card_dict = MessageToDict(proto_card, preserving_proto_field_name=True)
        identity = card_dict.get("identity", {})

        sensors = [
            {"sensor_id": s.get("sensor_id", ""), "type": s.get("type", "custom"),
             **{k: v for k, v in s.items() if k not in ("sensor_id", "type")}}
            for s in card_dict.get("sensors", [])
        ]
        actuators = [
            {"actuator_id": a.get("actuator_id", ""), "type": a.get("type", "custom"),
             **{k: v for k, v in a.items() if k not in ("actuator_id", "type")}}
            for a in card_dict.get("actuators", [])
        ]
        capabilities = [
            {"capability_id": c.get("capability_id", ""), "name": c.get("name", ""),
             "type": c.get("type", "custom"),
             **{k: v for k, v in c.items() if k not in ("capability_id", "name", "type")}}
            for c in card_dict.get("capabilities", [])
        ]

        # Issue #7: Preserve proto timestamps, fall back to now() only if absent
        return RobotCard(
            rosp_version=card_dict.get("rosp_version", "0.1"),
            id=card_dict.get("id", ""),
            identity=identity,
            hardware=card_dict.get("hardware", {}),
            sensors=sensors,
            actuators=actuators,
            capabilities=capabilities,
            integration=card_dict.get("integration", {}),
            safety=card_dict.get("safety", {}),
            coordinate_frames=card_dict.get("coordinate_frames"),
            created_at=card_dict.get("created_at") or datetime.now(timezone.utc).isoformat(),
            updated_at=card_dict.get("updated_at") or datetime.now(timezone.utc).isoformat(),
        )

    async def _stream_rosp_native(
        self, topics: List[str], qos: StreamQoS
    ) -> AsyncIterator[StreamMessage]:
        """Stream using ROSP-native StreamSensors RPC."""
        stub, pb2 = self._get_rosp_stubs()
        if not stub:
            return

        try:
            stream_qos = pb2.StreamQoS(
                reliability=qos.reliability,
                frequency_hz=qos.frequency_hz,
                compression=qos.compression,
                history_depth=qos.history_depth,
            )
            request = pb2.StreamRequest(topics=topics, qos=stream_qos)

            async for msg in stub.StreamSensors(request):
                data = {}
                if msg.data:
                    try:
                        data = json.loads(msg.data)
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        data = {"raw_bytes": len(msg.data)}

                yield StreamMessage(
                    topic=msg.topic,
                    seq=msg.seq,
                    timestamp=datetime.now(timezone.utc),
                    encoding=msg.encoding or "json",
                    data=data,
                )
        except grpc.aio.AioRpcError as e:
            # Issue #1: Re-raise so caller knows stream died due to error
            logger.warning(f"ROSP-native stream error: {e.code()}")
            raise

    # --- Reflection discovery ---

    async def _try_reflection_discovery(self) -> Optional[Dict[str, Any]]:
        """Try to discover robot services via gRPC server reflection."""
        try:
            from grpc_reflection.v1alpha import reflection_pb2, reflection_pb2_grpc

            stub = reflection_pb2_grpc.ServerReflectionStub(self._channel)

            # Issue #3: Use async iterator for bidirectional streaming RPC
            async def _async_iter(items):
                for item in items:
                    yield item

            request = reflection_pb2.ServerReflectionRequest(list_services="")
            responses = stub.ServerReflectionInfo(_async_iter([request]))
            services = []
            async for response in responses:
                if response.HasField("list_services_response"):
                    for svc in response.list_services_response.service:
                        services.append(svc.name)

            logger.info(f"gRPC reflection found services: {services}")
            return self._map_reflected_services(services)

        except ImportError:
            logger.debug("grpc_reflection not available")
        except Exception as e:
            logger.debug(f"Reflection discovery failed: {e}")
        return None

    def _map_reflected_services(self, services: List[str]) -> Dict[str, Any]:
        sensors, actuators, capabilities = [], [], []
        service_patterns = {
            "ImageService": {"sensor": {"sensor_id": "camera", "type": "camera_rgb"}},
            "RobotState": {"sensor": {"sensor_id": "state", "type": "custom"}},
            "SpotCheck": {"capability": {"capability_id": "self_check", "name": "Self Check", "type": "perception"}},
            "ArmCommand": {"actuator": {"actuator_id": "arm", "type": "joint", "control_modes": ["position"]}},
            "Gripper": {"actuator": {"actuator_id": "gripper", "type": "gripper", "control_modes": ["position"]}},
            "Navigation": {"capability": {"capability_id": "navigation", "name": "Navigation", "type": "navigation"}},
        }
        for service in services:
            for pattern, mapping in service_patterns.items():
                if pattern.lower() in service.lower():
                    if "sensor" in mapping:
                        sensors.append(mapping["sensor"])
                    if "actuator" in mapping:
                        actuators.append(mapping["actuator"])
                    if "capability" in mapping:
                        capabilities.append(mapping["capability"])
        return {"sensors": sensors, "actuators": actuators, "capabilities": capabilities}

    # --- Generic gRPC helpers ---

    def _get_grpc_method(self, service: str, method: str):
        full_method = f"/{service}/{method}"
        return self._channel.unary_stream(
            full_method,
            request_serializer=self._json_serializer,
            response_deserializer=self._json_deserializer,
        )

    def _build_request(self, params: Dict[str, Any]) -> Dict[str, Any]:
        return params

    def _proto_to_dict(self, proto_msg) -> Dict[str, Any]:
        if isinstance(proto_msg, dict):
            return proto_msg
        if isinstance(proto_msg, bytes):
            try:
                return json.loads(proto_msg)
            except (json.JSONDecodeError, UnicodeDecodeError):
                return {"raw_bytes": len(proto_msg)}
        try:
            from google.protobuf.json_format import MessageToDict
            return MessageToDict(proto_msg, preserving_proto_field_name=True)
        except Exception:
            return {"value": str(proto_msg)}

    @staticmethod
    def _json_serializer(data: Dict[str, Any]) -> bytes:
        return json.dumps(data).encode("utf-8")

    @staticmethod
    def _json_deserializer(data: bytes) -> Dict[str, Any]:
        try:
            return json.loads(data)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return {"raw": data.hex() if isinstance(data, bytes) else str(data)}
