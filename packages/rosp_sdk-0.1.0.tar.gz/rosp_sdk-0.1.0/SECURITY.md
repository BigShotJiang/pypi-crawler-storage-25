# Security Policy

## Reporting a Vulnerability

If you discover a security vulnerability in ROSP, please report it responsibly.

**Do NOT open a public GitHub issue for security vulnerabilities.**

Instead, email: **security@roboswarm.io**

We will:
- Acknowledge receipt within 48 hours
- Provide an initial assessment within 5 business days
- Coordinate responsible disclosure

## Scope

This policy covers:
- `rosp-sdk` (core SDK)
- All official adapters (`rosp-adapter-ros2`, `rosp-adapter-grpc`, `rosp-adapter-vda5050`)
- The ROSP specification itself (protocol-level vulnerabilities)

## Security Model

ROSP v0.1 Description Mode (describe, stream, discover) is read-only and does not execute commands on robots.

ROSP v0.1 Control Mode (command, coordinate) is marked **DRAFT** and should NOT be used in production without additional security controls. See the specification Section 8 (Security Model) for details.

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |
