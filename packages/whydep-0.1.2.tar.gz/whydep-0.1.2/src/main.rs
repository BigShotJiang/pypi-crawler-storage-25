use clap::Parser;
use std::collections::HashSet;
use std::path::PathBuf;

use whydep::lock::{build_reverse, find_lock_file, normalize, parse_lock_file};
use whydep::scan::{
    find_py_files, find_usages, find_venv_site_packages, get_import_names, read_src_dirs,
};
use whydep::tree::{TreeCtx, print_tree, show_usage};

#[derive(Parser)]
#[command(about = "Show why a Python package is in your project (reads uv.lock / poetry.lock)")]
struct Cli {
    /// The package name to look up
    #[arg(conflicts_with = "find_deprecated")]
    package: Option<String>,

    /// Scan all direct dependencies and list those with no imports found
    #[arg(long, conflicts_with = "package")]
    find_deprecated: bool,

    /// Project directory containing the lock file (default: current dir)
    #[arg(short, long, default_value = ".")]
    dir: PathBuf,
}

fn main() {
    let cli = Cli::parse();

    if !cli.find_deprecated && cli.package.is_none() {
        eprintln!("error: provide a package name or use --find-deprecated");
        std::process::exit(1);
    }

    let (lock_path, lock_kind) = find_lock_file(&cli.dir).unwrap_or_else(|| {
        eprintln!(
            "Could not find uv.lock or poetry.lock in '{}' or its parents.",
            cli.dir.display()
        );
        std::process::exit(1);
    });

    let info = parse_lock_file(&lock_path, lock_kind).unwrap_or_else(|e| {
        eprintln!("Failed to parse {}: {}", lock_path.display(), e);
        std::process::exit(1);
    });

    let src_dirs = read_src_dirs(&info.project_dir);
    let py_files: Vec<_> = src_dirs.iter().flat_map(|d| find_py_files(d)).collect();
    let site_packages = find_venv_site_packages(&info.project_dir);

    if cli.find_deprecated {
        run_find_deprecated(&info, &py_files, site_packages.as_ref());
        return;
    }

    let package = cli.package.unwrap();
    let reverse = build_reverse(&info.forward);
    let target_norm = normalize(&package);

    if !info.forward.contains_key(&target_norm) && !reverse.contains_key(&target_norm) {
        eprintln!("Package '{}' not found in lock file.", package);
        std::process::exit(1);
    }

    let display = info
        .display_names
        .get(&target_norm)
        .map(|s| s.as_str())
        .unwrap_or(&package);

    let ctx = TreeCtx {
        reverse: &reverse,
        display_names: &info.display_names,
        project_deps: &info.project_deps,
        py_files: &py_files,
        site_packages: site_packages.as_ref(),
        project_dir: &info.project_dir,
    };

    println!("\nWhy is '{}' installed?\n", display);

    let mut usage_shown: HashSet<String> = HashSet::new();

    if info.project_deps.contains(&target_norm) {
        usage_shown.insert(target_norm.clone());
        let has_usages = show_usage(&target_norm, "", &ctx);
        if !has_usages {
            println!("(can be removed)");
        }
        println!();
    }

    let mut visited = HashSet::new();
    visited.insert(target_norm.clone());
    print_tree(&target_norm, &ctx, &mut visited, &mut usage_shown, "", true);

    if !reverse.contains_key(&target_norm) {
        println!("(project root — nothing depends on it)");
    }
}

fn run_find_deprecated(
    info: &whydep::lock::LockInfo,
    py_files: &[PathBuf],
    site_packages: Option<&PathBuf>,
) {
    let sp = site_packages.map(|p| p.as_path());

    let mut unused: Vec<&str> = info
        .project_deps
        .iter()
        .filter(|pkg| {
            let import_names = get_import_names(pkg, sp);
            find_usages(&import_names, py_files).is_empty()
        })
        .map(|s| s.as_str())
        .collect();

    unused.sort();

    if unused.is_empty() {
        println!("All direct dependencies have imports found in source files.");
        return;
    }

    println!("\nUnused direct dependencies ({}):\n", unused.len());
    for pkg in &unused {
        let display = info
            .display_names
            .get(*pkg)
            .map(|s| s.as_str())
            .unwrap_or(pkg);
        println!("  {display} — no imports found, can be removed");
    }
    println!();
}
