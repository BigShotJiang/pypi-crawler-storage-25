## v0.1.2 (2026-04-11)

### Refactor

- rename depwhy → whydep, dw → wd

## v0.1.1 (2026-04-11)

### Fix

- resolve clippy warnings
- remove incorrect working-directory from all workflows
