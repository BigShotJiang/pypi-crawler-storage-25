import subprocess
import argparse
import sys
import os

sys.path.append('../crawler')
from crawler.crawler import QuokkoBot

def main():
  parser = argparse.ArgumentParser()
  parser.add_argument("command", default=None)
  args = parser.parse_args()
  
  if args.command is None:
    print("Quokko is a nice little search engine and web crawler. See more here: https://codeberg.org/splot-dev/quokko")
    sys.exit()
  
  if args.command == "crawl":
    try:
      user_agent = os.environ.get("QUOKKO_CRAWL_USER_AGENT", "QuokkoBot/1.0 (an instance of QuokkoBot; find source code at https://codeberg.org/splot-dev/quokko)")
      seed = os.environ.get("QUOKKO_CRAWL_SEED_URL", "https://news.ycombinator.com")
      regex = os.environ.get("QUOKKO_CRAWL_REGEX_FILTER", "https://.{1,33}")
      db_path = os.environ.get("QUOKKO_CRAWL_DB_PATH", None)
      no_crawl = os.environ.get("QUOKKO_CRAWL_NO_CRAWL", None)
      if not no_crawl:
        no_crawl = [
          "linkedin.com", 
          "google.com", 
          "bbc.com", 
          "reddit.com", 
          "nytimes.com", 
          "instagram.com",
          "facebook.com",
          "whatsapp.com",
          "yahoo.com",
          "bing.com",
          "github.com",
          "duckduckgo.com",
          "quora.com"
        ]
      else:
        no_crawl = no_crawl.split()
      
      if db_path is None:
        print("QUOKKO_CRAWL_DB_PATH is an environment variable that is required, and does not currently exist.")
        sys.exit()
      
      qb = QuokkoBot(user_agent, db_path, seed, regex)
      qb.crawl(log=True, no_crawl=no_crawl)
    except Exception as e:
      print(f"Something unexpected happened while crawling:\n{e}")
      sys.exit()
      
  elif args.command == "webapp":
    try:
      subprocess.run(["flask", "--app", "../interface/main", "run"], check=True)
    except Exception as e:
      print(f"Something unexpected happened while running webapp:\n{e}")
      sys.exit()
  else:
    print("Invalid command.")
    sys.exit()

if __name__ == "__main__":
  main()