import os

from django.core.management.utils import get_random_secret_key


def env_bool(name, default=False):
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_list(name, default=""):
    raw = os.getenv(name, default)
    return [item.strip() for item in raw.split(",") if item.strip()]


def env_set(name, default=""):
    return {item.strip() for item in os.getenv(name, default).split(",") if item.strip()}


def normalize_public_storage_origin(value):
    if not value:
        return ""

    value = value.strip().rstrip("/")
    if value.startswith("http://") or value.startswith("https://"):
        parts = value.split("//", 1)
        host = parts[1].split("/", 1)[0]
        return f"{parts[0]}//{host}"

    host = value.split("/", 1)[0]
    return f"https://{host}"


def build_security_config(
    default_csrf_trusted_origins="",
    default_allowed_hosts="*",
):
    debug = env_bool("DEBUG", env_bool("DJANGO_DEBUG", False))

    return {
        "DEBUG": debug,
        "SECRET_KEY": os.getenv("DJANGO_SECRET_KEY", get_random_secret_key()),
        "SECURE_CONTENT_TYPE_NOSNIFF": True,
        "SECURE_HSTS_SECONDS": 31536000 if not debug else 0,
        "SECURE_HSTS_INCLUDE_SUBDOMAINS": not debug,
        "SECURE_HSTS_PRELOAD": not debug,
        "SECURE_SSL_REDIRECT": env_bool("SECURE_SSL_REDIRECT", False),
        "USE_X_FORWARDED_HOST": True,
        "SECURE_PROXY_SSL_HEADER": ("HTTP_X_FORWARDED_PROTO", "https"),
        "SECURE_BROWSER_XSS_FILTER": True,
        "X_FRAME_OPTIONS": "DENY",
        "SECURE_REFERRER_POLICY": "same-origin",
        "CSRF_TRUSTED_ORIGINS": env_list(
            "DJANGO_CSRF_TRUSTED_ORIGINS",
            default_csrf_trusted_origins,
        ),
        "ALLOWED_HOSTS": env_list("DJANGO_ALLOWED_HOSTS", default_allowed_hosts),
        "CSRF_COOKIE_SECURE": not debug,
        "SESSION_COOKIE_SECURE": not debug,
    }


def build_database_config(prefix="POSTGRES"):
    return {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": os.getenv(f"{prefix}_DB", "postgres"),
        "USER": os.getenv(f"{prefix}_USER", "postgres"),
        "PASSWORD": os.getenv(f"{prefix}_PASSWORD", "postgres"),
        "HOST": os.getenv(f"{prefix}_HOST", "postgres-service"),
        "PORT": os.getenv(f"{prefix}_PORT", "5432"),
    }


def _slugify_prefix(value):
    value = (value or "").strip().lower().replace("_", "-")
    return "-".join(part for part in value.split("-") if part)


def _resolve_storage_prefix(app_name=None):
    explicit = os.getenv("CLOUD_STORAGE_PREFIX", "").strip("/")
    if explicit:
        return explicit

    app_value = os.getenv("APP_NAME") or app_name or "app"
    return _slugify_prefix(app_value) or "app"


def build_storage_config(base_dir=None, app_name=None):
    storage_type = os.getenv("STORAGE_TYPE", "local").strip().lower()
    prefix = _resolve_storage_prefix(app_name)
    if storage_type != "cloud":
        local = {
            "storage_type": "local",
            "needs_storages_app": False,
            "storages": {
                "default": {
                    "BACKEND": "django.core.files.storage.FileSystemStorage",
                },
                "staticfiles": {
                    "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage",
                },
            },
            "static_url": "/static/",
            "media_url": "/media/",
        }
        if base_dir is not None:
            local["static_root"] = base_dir / "staticfiles"
            local["media_root"] = base_dir / "media"
        return local

    bucket_name = os.getenv("AWS_STORAGE_BUCKET_NAME")
    endpoint_url = os.getenv("AWS_S3_ENDPOINT_URL")
    custom_domain = os.getenv("AWS_S3_CUSTOM_DOMAIN")
    region_name = os.getenv("AWS_S3_REGION_NAME", "auto")
    location_static = f"{prefix}/static"
    location_media = f"{prefix}/media"
    static_origin = normalize_public_storage_origin(custom_domain or endpoint_url)

    return {
        "storage_type": "cloud",
        "needs_storages_app": True,
        "prefix": prefix,
        "bucket_name": bucket_name,
        "endpoint_url": endpoint_url,
        "custom_domain": custom_domain,
        "region_name": region_name,
        "static_url": f"{static_origin}/{location_static}/" if static_origin else "/static/",
        "media_url": f"{static_origin}/{location_media}/" if static_origin else "/media/",
        "aws": {
            "AWS_ACCESS_KEY_ID": os.getenv("AWS_ACCESS_KEY_ID"),
            "AWS_SECRET_ACCESS_KEY": os.getenv("AWS_SECRET_ACCESS_KEY"),
            "AWS_STORAGE_BUCKET_NAME": bucket_name,
            "AWS_S3_ENDPOINT_URL": endpoint_url,
            "AWS_S3_REGION_NAME": region_name,
            "AWS_S3_CUSTOM_DOMAIN": custom_domain,
            "AWS_S3_ADDRESSING_STYLE": "virtual",
            "AWS_DEFAULT_ACL": None,
            "AWS_S3_SIGNATURE_VERSION": "s3v4",
            "AWS_QUERYSTRING_AUTH": False,
        },
        "storages": {
            "default": {
                "BACKEND": "storages.backends.s3.S3Storage",
                "OPTIONS": {
                    "bucket_name": bucket_name,
                    "endpoint_url": endpoint_url,
                    "region_name": region_name,
                    "custom_domain": custom_domain,
                    "location": location_media,
                    "default_acl": None,
                    "file_overwrite": False,
                    "object_parameters": {"CacheControl": "max-age=3600, must-revalidate"},
                },
            },
            "staticfiles": {
                "BACKEND": "storages.backends.s3.S3Storage",
                "OPTIONS": {
                    "bucket_name": bucket_name,
                    "endpoint_url": endpoint_url,
                    "region_name": region_name,
                    "custom_domain": custom_domain,
                    "location": location_static,
                    "default_acl": None,
                    "object_parameters": {"CacheControl": "max-age=86400, must-revalidate"},
                },
            },
        },
    }


# Shared OIDC settings builder used by app settings to avoid duplication.
def build_oidc_config(
    default_scopes="openid profile email",
    default_admin_group="admin",
    default_groups_claim="groups",
):
    client_id = os.getenv("OIDC_RP_CLIENT_ID", "").strip()
    client_secret = os.getenv("OIDC_RP_CLIENT_SECRET", "").strip()
    auth_endpoint = os.getenv("OIDC_OP_AUTHORIZATION_ENDPOINT", "").strip()
    token_endpoint = os.getenv("OIDC_OP_TOKEN_ENDPOINT", "").strip()
    user_endpoint = os.getenv("OIDC_OP_USER_ENDPOINT", "").strip()
    jwks_endpoint = os.getenv("OIDC_OP_JWKS_ENDPOINT", "").strip()

    explicit_enabled = os.getenv("OIDC_ENABLED")
    if explicit_enabled is None:
        enabled = all([client_id, client_secret, auth_endpoint, token_endpoint, user_endpoint, jwks_endpoint])
    else:
        enabled = env_bool("OIDC_ENABLED", False)

    config = {
        "ENABLED": enabled,
        "OIDC_RP_CLIENT_ID": client_id,
        "OIDC_RP_CLIENT_SECRET": client_secret,
        "OIDC_RP_SIGN_ALGO": os.getenv("OIDC_RP_SIGN_ALGO", "RS256").strip(),
        "OIDC_RP_SCOPES": os.getenv("OIDC_RP_SCOPES", default_scopes).strip(),
        "OIDC_OP_AUTHORIZATION_ENDPOINT": auth_endpoint,
        "OIDC_OP_TOKEN_ENDPOINT": token_endpoint,
        "OIDC_OP_USER_ENDPOINT": user_endpoint,
        "OIDC_OP_JWKS_ENDPOINT": jwks_endpoint,
        "OIDC_OP_LOGOUT_ENDPOINT": os.getenv("OIDC_OP_LOGOUT_ENDPOINT", "").strip(),
        "OIDC_STORE_ID_TOKEN": env_bool("OIDC_STORE_ID_TOKEN", True),
        "OIDC_VERIFY_SSL": env_bool("OIDC_VERIFY_SSL", True),
        "OIDC_ADMIN_GROUP": os.getenv("OIDC_ADMIN_GROUP", default_admin_group),
        "OIDC_GROUPS_CLAIM": os.getenv("OIDC_GROUPS_CLAIM", default_groups_claim),
        "LOGIN_URL": os.getenv("OIDC_LOGIN_URL", "/oidc/authenticate/"),
        "LOGIN_REDIRECT_URL": os.getenv("OIDC_LOGIN_REDIRECT_URL", "/"),
        "LOGOUT_REDIRECT_URL": os.getenv("OIDC_LOGOUT_REDIRECT_URL", "/"),
        "AUTHENTICATION_BACKENDS": ["django.contrib.auth.backends.ModelBackend"],
    }

    if enabled:
        config["AUTHENTICATION_BACKENDS"] = [
            "infra_core.oidc.AuthentikOIDCBackend",
            "django.contrib.auth.backends.ModelBackend",
        ]

    return config
