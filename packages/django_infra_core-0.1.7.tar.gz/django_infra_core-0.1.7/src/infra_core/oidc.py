from urllib.parse import urlencode

from django.conf import settings
from django.contrib.auth import logout
from django.shortcuts import redirect
from mozilla_django_oidc.auth import OIDCAuthenticationBackend


class AuthentikOIDCBackend(OIDCAuthenticationBackend):
    """Shared Authentik OIDC backend extracted from Takibat for reuse."""

    def _resolve_username(self, claims):
        preferred_username = (claims.get("preferred_username") or "").strip()
        subject = (claims.get("sub") or "").strip()
        email = (claims.get("email") or "").strip()

        base = preferred_username or subject or email
        base = base[:150] if base else "user"

        username = base
        counter = 2
        while self.UserModel.objects.filter(username=username).exists():
            suffix = f"-{counter}"
            username = f"{base[:150 - len(suffix)]}{suffix}"
            counter += 1
        return username

    def filter_users_by_claims(self, claims):
        email = claims.get("email")
        if not email:
            return self.UserModel.objects.none()
        return self.UserModel.objects.filter(email__iexact=email)

    def create_user(self, claims):
        email = claims.get("email") or ""
        username = self._resolve_username(claims)
        user = self.UserModel.objects.create_user(username=username, email=email)
        return user

    def update_user(self, user, claims):
        email = claims.get("email") or ""
        if email and user.email != email:
            user.email = email

        preferred_username = (claims.get("preferred_username") or "").strip()
        if preferred_username and user.username == email:
            user.username = self._resolve_username(claims)

        first_name = claims.get("given_name") or claims.get("name") or ""
        last_name = claims.get("family_name") or ""
        if first_name:
            user.first_name = first_name
        if last_name:
            user.last_name = last_name

        groups_claim = getattr(settings, "OIDC_GROUPS_CLAIM", "groups")
        groups = claims.get(groups_claim, [])
        if isinstance(groups, str):
            groups = [groups]

        admin_group = getattr(settings, "OIDC_ADMIN_GROUP", "admin")
        user.is_staff = admin_group in groups
        user.save()
        return user


def auth_login_view(request):
    if getattr(settings, "OIDC_RP_CLIENT_ID", ""):
        return redirect("/oidc/authenticate/?next=/admin/")
    return redirect("/admin/login/")


def auth_logout_view(request):
    """Log out from Django, then from Authentik when OIDC is enabled."""
    id_token = request.session.get("oidc_id_token")
    logout(request)

    logout_endpoint = getattr(settings, "OIDC_OP_LOGOUT_ENDPOINT", "").strip()
    if not logout_endpoint:
        return redirect(getattr(settings, "LOGOUT_REDIRECT_URL", "/"))

    params = {}
    post_logout = getattr(settings, "LOGOUT_REDIRECT_URL", "")
    if post_logout:
        params["post_logout_redirect_uri"] = post_logout
    client_id = getattr(settings, "OIDC_RP_CLIENT_ID", "")
    if client_id:
        params["client_id"] = client_id
    if id_token:
        params["id_token_hint"] = id_token

    if params:
        return redirect(f"{logout_endpoint}?{urlencode(params)}")
    return redirect(logout_endpoint)
