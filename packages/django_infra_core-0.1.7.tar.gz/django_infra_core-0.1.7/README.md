# django-infra-core

Reusable package for shared Django architecture across multiple services.

## What this package provides

- Abstract base models for institution and student domains
- Admin mixin for institution scoped access
- Settings helpers for env driven configuration
- Auth utilities and middleware to attach institution context

## Installation

```bash
pip install django-infra-core==0.1.7
```

## Quick usage

```python
# settings.py
INSTALLED_APPS = [
    # ...
    "infra_core",
]

# models.py
from infra_core.models import BaseInstitution, BaseStudent
from infra_core.admin import InstitutionScopedAdminMixin, ImportExportAdminMixin, BaseModelResource

class Institution(BaseInstitution):
    pass

class Student(BaseStudent):
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name="students",
    )

## Included Institution fields (BaseInstitution)

- name (Kurum Adı)
- code (Kurum Kodu)
- address (Adres)
- location (Konum)
- phone (Telefon)
- email (E-posta)
- gender (Cinsiyet)
- institution_type (Kurum Türü)
- manager (Kurum Yöneticisi)
- is_active (Aktif)
- created_at / updated_at (Oluşturulma/Güncellenme Tarihi)

## Included Student fields (BaseStudent)

- first_name (Öğrenci Adı)
- last_name (Öğrenci Soyadı)
- grade (Sınıf)
- level (Seviye)
- status (Aktif)
- created_at / updated_at (Oluşturulma/Güncellenme Tarihi)

`BaseStudent.clean()` metodu, `institution.institution_type` değerine göre `grade` ve `level` alanlarını doğrular.

## Import/Export shared classes

- `BaseModelResource`: Ortak import/export resource ayarları
- `ImportExportAdminMixin`: Ortak import/export admin mixin
```
