"""PiBot cogs package."""
