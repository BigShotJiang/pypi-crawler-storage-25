import requests
import uuid
import os
BASE_URL = os.getenv("AGENTLENS_BASE_URL", "http://localhost:8000")

class AgentLensClient:
    def __init__(self, api_key, agent: str = "default"):
        self.api_key = api_key
        self.agent = agent or "default"
        self.new_run()

    def new_run(self):
        self.run_id = str(uuid.uuid4())

    def send_event(self, event):
        payload = {
            "run_id": self.run_id,
            **event,
            "agent": self.agent,
        }

        headers = {
            "api-key": self.api_key
        }

        try:
            res = requests.post(   # 🆕 FIXED
                f"{BASE_URL}/events",
                json=payload,
                headers=headers
            )

            print("Response:", res.status_code, res.text)

        except Exception as e:
            print("AgentLens error:", e)


client = None


def init(api_key, agent: str = "default"):
    """Initialize the global client. One project per API key; use *agent* to separate workflows."""
    global client
    client = AgentLensClient(api_key, agent=agent)