import time
import agentlens.client as client_module   # 👈 IMPORTANT


def track(step_type):
    def decorator(func):
        def wrapper(*args, **kwargs):
            start = time.time()

            try:
                result = func(*args, **kwargs)
                error = None
            except Exception as e:
                result = None
                error = str(e)

            end = time.time()

            # 👇 fetch client dynamically
            client = client_module.client

            if client:
                client.send_event({
                    "type": step_type,
                    "input": str(args),
                    "output": str(result),
                    "error": error,
                    "latency": int((end - start) * 1000)
                })

            if error:
                raise Exception(error)

            return result

        return wrapper
    return decorator