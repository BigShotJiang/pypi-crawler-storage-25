from setuptools import setup, find_packages

setup(
    name="agentlens-tracker",
    version="0.1.0",
    packages=find_packages(),
    install_requires=["requests"],
    author="Samarth Sharma",
    description="Track and debug AI agents step-by-step",
)