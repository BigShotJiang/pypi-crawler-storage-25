# PyAgentKit — Usage Guide

---

## Table of Contents

1. [Basic Agent](#1-basic-agent)
2. [Writing Tools](#2-writing-tools)
3. [Instance vs Class Tools](#3-instance-vs-class-tools)
4. [Dependencies](#4-dependencies)
5. [Custom Response Models](#5-custom-response-models)
6. [Async Agent](#6-async-agent)
7. [Lifecycle Hooks](#7-lifecycle-hooks)
8. [Validation Hook](#8-validation-hook)
9. [Agent Composition](#9-agent-composition)
10. [Message History](#10-message-history)
11. [Token Usage](#11-token-usage)
12. [Error Handling](#12-error-handling)
13. [Configuration Reference](#13-configuration-reference)

---

## 1. Basic Agent

```python
from pyagentkit import Agent

agent = Agent(
    llm_name="<llm_name>",
    system_prompt="You are a helpful assistant.",
    agent_name="my-agent",
)

response = agent.handle_response("What is 2 + 2?")
print(response.response.message)  # "The answer is 4"
```

`handle_response` blocks until the agent produces a `final` response or exhausts its retries.

---

## 2. Writing Tools

A tool is any plain Python function that returns a `ToolResult`. It **must** have a docstring — the docstring is what the agent reads to understand what the tool does.

```python
from pyagentkit.definitions import ToolResult, ToolReturnValue


def add_numbers(a: int, b: int) -> ToolResult:
    """Add two integers together and return their sum."""
    total = a + b
    return ToolResult(return_value=ToolReturnValue.success, content=str(total))


def divide(a: float, b: float) -> ToolResult:
    """Divide a by b. Returns an error if b is zero."""
    if b == 0:
        return ToolResult(return_value=ToolReturnValue.error, content="Cannot divide by zero")
    return ToolResult(return_value=ToolReturnValue.success, content=str(a / b))
```

### ToolReturnValue options

| Value | Effect |
|-------|--------|
| `success` | Result appended to history; agent continues |
| `error` | Error message sent back to agent; counts as a tool retry |
| `fatal` | Immediately raises `ExceptionFatalError`; no retry |

### Passing tools to an agent

```python
agent = Agent(
    llm_name="<llm_name>",
    tools=[add_numbers, divide],
)
```

Tools passed via the `tools=` constructor parameter use `requires_approval=True` by default, meaning the user will be prompted before each execution. To skip that, register them with `add_tool` instead:

```python
agent.add_tool(add_numbers, requires_approval=False)
```

---

## 3. Instance vs Class Tools

### Instance tools

Registered on a single agent instance. Use `add_tool` or pass `tools=` to the constructor.

```python
agent = Agent(llm_name="<llm_name>")
agent.add_tool(my_tool, requires_approval=False)
```

### Class tools

Registered on the class and shared across **all instances** of that subclass.

```python
class MyAgent(Agent):
    pass


@MyAgent.register_tool(requires_approval=False)
def get_time() -> ToolResult:
    """Return the current UTC time as an ISO string."""
    from datetime import datetime, timezone
    return ToolResult(
        return_value=ToolReturnValue.success,
        content=datetime.now(timezone.utc).isoformat(),
    )


agent_a = MyAgent(llm_name="<llm_name>")
agent_b = MyAgent(llm_name="<llm_name>", agent_name="second")
# Both agents can call get_time
```

---

## 4. Dependencies

Use `AgentDependencies` to inject runtime state (database handles, API clients, config) into tools without exposing them in the tool's public signature shown to the LLM.

```python
from pydantic import Field
from pyagentkit.definitions import AgentDependencies, ToolResult, ToolReturnValue


class MyDeps(AgentDependencies):
    db_url: str = Field(description="Database connection URL")
    api_key: str = Field(description="External API key")


def fetch_user(deps: MyDeps, user_id: str) -> ToolResult:
    """Fetch a user record from the database by user ID."""
    # deps.db_url and deps.api_key are available here,
    # but `deps` is hidden from the LLM's view of the tool signature
    result = f"User {user_id} from {deps.db_url}"
    return ToolResult(return_value=ToolReturnValue.success, content=result)


deps = MyDeps(db_url="postgresql://...", api_key="sk-...")

agent = Agent(llm_name="<llm_name>", tools=[fetch_user])
response = agent.handle_response("Find user 42", deps=deps)
```

The `deps` first parameter is detected automatically by inspecting whether the first parameter is a subclass of `AgentDependencies`. It is stripped from the tool signature shown to the LLM.

---

## 5. Custom Response Models

Extend `AgentResponse` to add typed fields that the agent must populate on every response.

```python
from pydantic import Field
from pyagentkit.definitions import AgentResponse


class SentimentResponse(AgentResponse):
    sentiment: str = Field(description="positive, negative, or neutral")
    confidence: float = Field(description="Confidence score between 0 and 1")


agent = Agent(
    llm_name="<llm_name>",
    response_model=SentimentResponse,
    system_prompt="You are a sentiment analysis assistant.",
)

response = agent.handle_response("I love this product!")
print(response.sentiment)    # "positive"
print(response.confidence)   # 0.95
```

The schema examples injected into the system prompt are generated automatically from the model's field annotations, so the LLM always sees the correct shape.

---

## 6. Async Agent

Use `AsyncAgent` in `asyncio` contexts. The API mirrors `Agent` except all relevant methods are coroutines and the Ollama client is `ollama.AsyncClient`. Both sync and async callables are accepted for all hooks.

```python
import asyncio
from pyagentkit import AsyncAgent
from pyagentkit.definitions import ToolResult, ToolReturnValue


async def get_weather(city: str) -> ToolResult:
    """Return current weather for a given city name."""
    return ToolResult(return_value=ToolReturnValue.success, content=f"Sunny in {city}")


async def main():
    agent = await AsyncAgent.create(
        llm_name="<llm_name>",
        tools=[get_weather],
        agent_name="weather-agent",
    )
    response = await agent.handle_response("What is the weather in Istanbul?")
    print(response.response.message)
    agent.dispose()


asyncio.run(main())
```

> **Important:** Use `await AsyncAgent.create(...)` rather than constructing `AsyncAgent(...)` directly. The constructor is synchronous and cannot run the async Ollama environment check — `create` does this for you. Constructing directly will emit a warning and skip validation.

---

## 7. Lifecycle Hooks

Hooks let you observe what the agent is doing without modifying its core logic. All hooks accept both sync and async callables in `AsyncAgent`; `Agent` accepts sync callables only.

```python
from pyagentkit.definitions import AgentResponse


def on_tool_call(tool_name: str, params: dict) -> None:
    print(f"[CALL]    {tool_name} | params={params}")


def on_tool_retry(tool_name: str, params: dict, error: str) -> None:
    print(f"[RETRY]   {tool_name} | error={error}")


def on_tool_success(tool_name: str, params: dict) -> None:
    print(f"[SUCCESS] {tool_name}")


def on_response(response: AgentResponse) -> None:
    print(f"[FINAL]   {response.response.message}")


def on_response_retry(attempt: int, response_str: str, error: str) -> None:
    print(f"[RESP RETRY] attempt={attempt} | error={error}")


agent = Agent(
    llm_name="<llm_name>",
    on_tool_call=on_tool_call,
    on_tool_retry=on_tool_retry,
    on_tool_success=on_tool_success,
    on_response=on_response,
    on_response_retry=on_response_retry,
)
```

---

## 8. Validation Hook

`on_validate` runs after every response is parsed and validated by Pydantic, before the agent decides whether to call a tool or return a final answer. Raise `ExceptionAgentError` to send a correction back to the agent and consume a response retry. Raise `ExceptionAgentFatal` to abort immediately.

```python
from pyagentkit.definitions import AgentResponse
from pyagentkit.exceptions import ExceptionAgentError


def validate(response: AgentResponse) -> None:
    if response.response.type == "final" and len(response.response.message) < 10:
        raise ExceptionAgentError("Final response is too short. Please elaborate.")


agent = Agent(
    llm_name="<llm_name>",
    on_validate=validate,
)
```

Async validators work the same way in `AsyncAgent`:

```python
async def validate(response: AgentResponse) -> None:
    result = await some_async_check(response.response.message)
    if not result:
        raise ExceptionAgentError("Response failed async validation.")


agent = await AsyncAgent.create(llm_name="<llm_name>", on_validate=validate)
```

---

## 9. Agent Composition

Any agent can expose itself as a tool for another agent via `.as_tool()`.

```python
from pyagentkit import Agent


researcher = Agent(
    llm_name="<llm_name>",
    agent_name="researcher",
    system_prompt="You are a research specialist. Answer factual questions concisely.",
)

orchestrator = Agent(
    llm_name="<llm_name>",
    agent_name="orchestrator",
    system_prompt="You are an orchestrator. Delegate research tasks to the researcher agent.",
    tools=[researcher.as_tool(description="Ask the researcher agent a factual question.")],
)

response = orchestrator.handle_response("What is the capital of Japan?")
print(response.response.message)
```

`.as_tool()` wraps `handle_response` in a `ToolResult`-returning function named after the agent. If the inner agent raises a `PyAgentKitError`, it is caught and returned to the outer agent as a recoverable tool error rather than propagating.

---

## 10. Message History

History is maintained automatically within a session. Each call to `handle_response` appends to the same history, giving the agent memory of prior turns.

```python
agent = Agent(llm_name="<llm_name>", agent_name="chat-agent")

r1 = agent.handle_response("My name is Alice.")
r2 = agent.handle_response("What is my name?")
print(r2.response.message)  # "Your name is Alice."
```

### Trimming history

Set `max_history` to limit how many non-system messages the agent sees. Older messages are dropped automatically. Orphaned assistant messages (those without a preceding user message after trimming) are also removed.

```python
agent = Agent(llm_name="<llm_name>", max_history=20)
```

### Saving and loading history

```python
agent.save_history("history.json")

# In a new session:
agent.load_history("history.json")
```

### Clearing history

```python
agent.clear_history()
```

---

## 11. Token Usage

`agent.token_usage` is a `TokenUsage` object that accumulates across all `handle_response` calls on an instance.

```python
response = agent.handle_response("Summarize the water cycle.")
print(agent.token_usage.prompt_tokens)
print(agent.token_usage.response_tokens)
print(agent.token_usage.total_tokens)
```

---

## 12. Error Handling

```python
from pyagentkit import (
    ExceptionToolRetriesExhausted,
    ExceptionResponseRetriesExhausted,
    ExceptionFatalError,
    ExceptionEnvironmentError,
)
from pyagentkit.exceptions import ExceptionUnhandledError

try:
    response = agent.handle_response("Do something complex.")
except ExceptionEnvironmentError as e:
    print(f"Ollama not reachable or model missing: {e.message}")
except ExceptionToolRetriesExhausted as e:
    print(f"Tool retries exhausted after {e.retries} attempts")
except ExceptionResponseRetriesExhausted as e:
    print(f"Response retries exhausted after {e.retries} attempts")
except ExceptionFatalError as e:
    print(f"Fatal error, cannot recover: {e.message}")
except ExceptionUnhandledError as e:
    print(f"Unexpected error: {e}")
```

Inside a tool, signal errors using return values rather than raising exceptions directly:

```python
def risky_tool(path: str) -> ToolResult:
    """Read a file from the given path."""
    try:
        with open(path) as f:
            return ToolResult(return_value=ToolReturnValue.success, content=f.read())
    except FileNotFoundError:
        # Recoverable — agent will retry with corrected params
        return ToolResult(return_value=ToolReturnValue.error, content=f"File not found: {path}")
    except PermissionError:
        # Irrecoverable — raises ExceptionFatalError immediately
        return ToolResult(return_value=ToolReturnValue.fatal, content=f"Permission denied: {path}")
```

---

## 13. Configuration Reference

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `llm_name` | `str` | required | Ollama model name |
| `agent_name` | `str \| None` | `llm_name` | Name for this agent; auto-suffixed if already taken |
| `system_prompt` | `str \| None` | `""` | Base system prompt prepended to all requests |
| `instructions` | `str \| None` | `""` | Text appended to every user prompt |
| `response_model` | `Type[AgentResponse]` | `AgentResponse` | Pydantic model for response validation |
| `tool_retries` | `int` | `3` | Max tool call retries before raising |
| `response_retries` | `int` | `3` | Max response validation retries before raising |
| `num_ctx` | `int` | `8192` | Ollama context window size |
| `temperature` | `float` | `0.0` | Sampling temperature |
| `top_p` | `float` | `0.0` | Nucleus sampling probability |
| `top_k` | `float` | `0.0` | Top-k sampling |
| `seed` | `int` | `42` | Random seed for reproducibility |
| `ollama_url` | `str \| None` | `None` | Custom Ollama host URL; uses default if `None` |
| `tools` | `list \| None` | `None` | Tool functions to register on init |
| `max_history` | `int \| None` | `None` | Max non-system messages to retain |
| `log_level` | `int` | `logging.INFO` | Python logging level |
| `think` | `bool` | `False` | Enable chain-of-thought on supported models |
| `on_tool_call` | callable | `None` | Hook called before each tool execution |
| `on_tool_retry` | callable | `None` | Hook called on tool error/retry |
| `on_tool_success` | callable | `None` | Hook called on tool success |
| `on_response` | callable | `None` | Hook called on final response |
| `on_response_retry` | callable | `None` | Hook called on response validation failure |
| `on_validate` | callable | `None` | Hook called after parsing; raise to trigger retry or abort |
