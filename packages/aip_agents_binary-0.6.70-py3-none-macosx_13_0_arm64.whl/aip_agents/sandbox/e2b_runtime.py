"""E2B Sandbox Runtime for PTC.

This module provides direct E2B SDK integration for sandbox code execution.

Authors:
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

import asyncio
from collections.abc import Callable
from typing import Any

from e2b_code_interpreter import AsyncSandbox, OutputMessage

from aip_agents.sandbox.defaults import (
    DEFAULT_SANDBOX_PACKAGES,
    DEFAULT_SANDBOX_TEMPLATE,
)
from aip_agents.sandbox.types import SandboxExecutionResult
from aip_agents.sandbox.validation import validate_package_names
from aip_agents.utils.logger import get_logger

# Type alias for package selector callback.
# Called after sandbox creation with actual template status (None if template failed).
PackageSelector = Callable[[str | None], list[str] | None]

logger = get_logger(__name__)

SANDBOX_NOT_INITIALIZED_ERROR = "Sandbox not initialized"
DEFAULT_PACKAGE_INSTALL_TIMEOUT_SECONDS = 300.0


class E2BSandboxRuntime:
    """E2B Sandbox runtime for executing code in isolated environments.

    This runtime manages per-run sandbox lifecycle:
    - Create sandbox on first execute
    - Reuse sandbox for subsequent executes
    - Destroy sandbox on cleanup

    Example:
        runtime = E2BSandboxRuntime()
        result = await runtime.execute(
            code="print('Hello')",
            timeout=60.0,
            files={"tools/mcp.py": "# MCP client code"},
        )
        await runtime.cleanup()
    """

    def __init__(
        self,
        template: str | None = None,
        packages: list[str] | None = None,
        package_selector: PackageSelector | None = None,
        sandbox_timeout: int = 300,
        package_install_timeout: float | None = None,
        auto_build_template: bool = False,
        build_base_template: str = "code-interpreter-v1",
        # Backward compatibility: accept old parameter name
        ptc_packages: list[str] | None = None,
    ) -> None:
        """Initialize E2B sandbox runtime.

        Args:
            template: Optional E2B template ID for custom sandbox environments.
            packages: Packages to install in sandbox. If None or empty, skip install.
                Overwritten by package_selector if provided.
            package_selector: Optional callback to select packages after sandbox creation.
                Called with actual template (None if template failed) to enable smart
                package selection based on whether template was successfully created.
            sandbox_timeout: Timeout in seconds for the sandbox session. Defaults to 300.
                This prevents "port is not open" errors by keeping the sandbox alive.
            package_install_timeout: Timeout in seconds for package installation.
                When None, uses the runtime default. Values <= 0 disable the E2B
                command timeout for package installation.
            auto_build_template: If True and the requested template returns 404, attempt
                to build it automatically before falling back to the default sandbox.
                Building can take several minutes. Defaults to False.
            build_base_template: Base E2B template to build from when auto-building.
                Defaults to ``"code-interpreter-v1"``.
            ptc_packages: Deprecated. Use `packages` instead.
        """
        self._template = template
        # Handle backward compatibility
        if ptc_packages is not None and packages is None:
            packages = ptc_packages
        self._packages = packages
        self._package_selector = package_selector
        self._sandbox: AsyncSandbox | None = None
        self._sandbox_created_with_template = False
        self._sandbox_timeout = sandbox_timeout
        self._package_install_timeout = (
            DEFAULT_PACKAGE_INSTALL_TIMEOUT_SECONDS if package_install_timeout is None else package_install_timeout
        )
        self._auto_build_template = auto_build_template
        self._build_base_template = build_base_template

    async def execute(
        self,
        code: str,
        *,
        timeout: float = 300,
        files: dict[str, str] | None = None,
        env: dict[str, str] | None = None,
        template: str | None = None,
    ) -> SandboxExecutionResult:
        """Execute code inside the sandbox.

        Args:
            code: Python code to execute.
            timeout: Execution timeout in seconds.
            files: Files to upload to the sandbox (path -> content).
            env: Environment variables to set.
            template: Optional template override for this execution.

        Returns:
            SandboxExecutionResult with stdout, stderr, and exit_code.
        """
        # Create sandbox if not exists
        if self._sandbox is None:
            await self._create_sandbox(template or self._template)

        # Refresh sandbox lease before execution so the VM doesn't expire mid-run
        await self._apply_sandbox_timeout()

        # Upload files if provided
        if files:
            await self._upload_files(files)

        # Use asyncio.timeout context manager for cancellation (S6966)
        async with asyncio.timeout(timeout):
            return await self._run_code(code, env, language="python")

    async def execute_command(
        self,
        command: str,
        *,
        timeout: float = 30,
        env: dict[str, str] | None = None,
    ) -> SandboxExecutionResult:
        """Execute a shell command in the sandbox.

        Args:
            command: Shell command to execute.
            timeout: Command timeout in seconds.
            env: Optional environment variables.

        Returns:
            SandboxExecutionResult containing stdout, stderr, and exit_code.

        Notes:
            Preferred path uses ``commands.run``. If unavailable, it falls back to
            ``run_code(language='bash')``.
        """
        if self._sandbox is None:
            await self._create_sandbox(self._template)

        if self._sandbox is None:
            raise RuntimeError(SANDBOX_NOT_INITIALIZED_ERROR)

        # Refresh sandbox lease before execution so the VM doesn't expire mid-run
        await self._apply_sandbox_timeout()

        # Use asyncio.timeout context manager for cancellation (S6966)
        async with asyncio.timeout(timeout):
            try:
                run_kwargs: dict[str, Any] = {}
                if env is not None:
                    run_kwargs["envs"] = env
                result = await self._sandbox.commands.run(command, **run_kwargs)
                return SandboxExecutionResult(
                    stdout=result.stdout,
                    stderr=result.stderr,
                    exit_code=result.exit_code,
                )
            except Exception as e:
                logger.warning(f"commands.run failed, falling back to bash run_code: {e}")
                return await self._run_code(command, env, language="bash")

    async def cleanup(self) -> None:
        """Destroy the sandbox and release resources."""
        if self._sandbox is not None:
            try:
                logger.info("Destroying E2B sandbox")
                await self._sandbox.kill()
            except Exception as e:
                logger.warning(f"Error destroying sandbox: {e}")
            finally:
                self._sandbox = None

        self._reset_async_transport()

    @property
    def is_active(self) -> bool:
        """Check if a sandbox is currently active."""
        return self._sandbox is not None

    def _reset_async_transport(self) -> None:
        """Reset AsyncTransportWithLogger singleton to prevent cross-run logging issues."""
        try:
            from e2b.api.client_async import AsyncTransportWithLogger

            AsyncTransportWithLogger.singleton = None
        except Exception:
            return

    def _should_skip_default_package_install(self, template: str | None) -> bool:
        """Determine whether to skip package installation for the default template."""
        if not self._sandbox_created_with_template:
            return False

        if template != DEFAULT_SANDBOX_TEMPLATE:
            return False

        return self._packages == list(DEFAULT_SANDBOX_PACKAGES)

    def _resolve_auto_build_dockerfile(self, template_id: str) -> str | None:
        """Resolve Dockerfile path for auto-build template wiring.

        Args:
            template_id: Target template alias requested for auto-build.

        Returns:
            str | None: Absolute Dockerfile path for a packaged managed alias,
            otherwise ``None``.
        """
        from aip_agents.sandbox.template_builder import get_sandbox_dockerfile_path

        try:
            return str(get_sandbox_dockerfile_path(template_id))
        except ValueError:
            return None

    async def _auto_build(self, template_id: str) -> bool:
        """Attempt to build an E2B template that does not exist yet.

        Runs ``ensure_sandbox_template`` in a thread executor because the
        underlying E2B SDK build call is synchronous and can take several
        minutes.

        Args:
            template_id: The template alias to build.

        Returns:
            True if the template was built (or already existed after the
            attempt), False if building failed.
        """
        from aip_agents.sandbox.template_builder import ensure_sandbox_template

        dockerfile = self._resolve_auto_build_dockerfile(template_id)
        if dockerfile:
            # Dockerfile-backed templates include all packages baked in;
            # callers must ensure the Dockerfile installs aip-agents-binary
            # and any other required dependencies.
            packages = None
        else:
            packages = list(self._packages) if self._packages else None
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: ensure_sandbox_template(
                template_id,
                self._build_base_template,
                packages,
                dockerfile=dockerfile,
            ),
        )
        return result is not None

    async def _create_sandbox(self, template: str | None = None) -> None:
        """Create a new E2B sandbox.

        Implements canonical runtime rules:
        - If template provided, try creating sandbox with template
        - On any error, fall back to default sandbox (without template)
        - Install packages regardless of template usage (even after fallback)

        Note: Package installation occurs after sandbox creation, so fallback
        to default sandbox does not skip package installation.

        Args:
            template: Optional template ID.
        """
        logger.info(f"Creating E2B sandbox (template={template})")
        if template:
            await self._create_sandbox_from_template(template)
        else:
            self._sandbox_created_with_template = False
            await self._create_default_sandbox()
        await self._post_sandbox_setup(template)

    async def _create_default_sandbox(self) -> None:
        """Create a sandbox using the default (no-template) path."""
        self._sandbox = await AsyncSandbox.create()
        await self._apply_sandbox_timeout()
        logger.info(f"E2B sandbox created (default): {self._sandbox.sandbox_id}")

    async def _create_sandbox_from_template(self, template: str) -> None:
        """Attempt to create a sandbox using *template*, falling back on failure."""
        try:
            self._sandbox = await AsyncSandbox.create(template=template)
            await self._apply_sandbox_timeout()
            self._sandbox_created_with_template = True
            logger.info(f"E2B sandbox created: {self._sandbox.sandbox_id}")
        except Exception as e:
            await self._handle_template_failure(template, e)

    async def _handle_template_failure(self, template: str, error: Exception) -> None:
        """Decide whether to auto-build or fall straight back to default sandbox."""
        is_not_found = "404" in str(error) or "not found" in str(error).lower()
        if is_not_found and self._auto_build_template:
            logger.info(f"Template '{template}' not found — attempting to build it automatically")
            await self._try_auto_build_and_retry(template)
            return
        logger.warning(f"Template creation failed ({template}): {error}")
        logger.info("Falling back to default sandbox")
        self._sandbox_created_with_template = False
        await self._create_default_sandbox()

    async def _try_auto_build_and_retry(self, template: str) -> None:
        """Auto-build *template* and retry sandbox creation; fall back on failure."""
        built = await self._auto_build(template)
        if not built:
            logger.warning(f"Auto-build failed for template '{template}', falling back to default sandbox")
            self._sandbox_created_with_template = False
            await self._create_default_sandbox()
            return
        try:
            self._sandbox = await AsyncSandbox.create(template=template)
            await self._apply_sandbox_timeout()
            self._sandbox_created_with_template = True
            logger.info(f"E2B sandbox created after auto-build: {self._sandbox.sandbox_id}")
        except Exception as e2:
            logger.warning(f"Template creation failed after auto-build ({template}): {e2}")
            logger.info("Falling back to default sandbox")
            self._sandbox_created_with_template = False
            await self._create_default_sandbox()

    async def _post_sandbox_setup(self, template: str | None) -> None:
        """Run package-selector and package installation after sandbox creation."""
        if self._package_selector is not None:
            actual_template = template if self._sandbox_created_with_template else None
            try:
                self._packages = self._package_selector(actual_template)
                logger.info(
                    f"Package selector called with actual_template={actual_template}, "
                    f"selected packages: {self._packages}"
                )
            except Exception as e:
                logger.error(f"Package selector failed: {e}")
                await self.cleanup()
                raise

        # Validate native-tool compatibility after packages are selected
        await self._validate_native_tool_compatibility(template)

        if self._packages:
            if self._should_skip_default_package_install(template):
                logger.info("Skipping package install (default template already includes defaults)")
            else:
                await self._install_packages()

    async def _validate_native_tool_compatibility(self, template: str | None) -> None:
        """Validate that native AIP tools are only used with the compatible baseline template.

        Native AIP tools require ``DEFAULT_SANDBOX_TEMPLATE``.

        Args:
            template: The template alias requested by the caller.

        Raises:
            RuntimeError: If native AIP tools are requested but the effective template
                is fallback/default or a non-compatible alias.
        """
        if not self._packages:
            return

        # Check if native AIP tools package is in the selected packages
        has_native_tools = any(
            pkg.startswith("aip-agents") or pkg.startswith("aip-agents-binary") for pkg in self._packages
        )

        if has_native_tools and not self._sandbox_created_with_template:
            error_msg = (
                f"Native AIP tools require a compatible sandbox template "
                f"('{DEFAULT_SANDBOX_TEMPLATE}'), but sandbox fell back to the default "
                f"E2B template which uses an incompatible Python version. "
                f"Ensure the template '{DEFAULT_SANDBOX_TEMPLATE}' is built and available, "
                f"or disable native tools."
            )
            logger.error(f"ptc_native_runtime_incompatible: template_fallback=True, requested_template={template}")
            await self.cleanup()
            raise RuntimeError(error_msg)

        if has_native_tools and template is not None and template != DEFAULT_SANDBOX_TEMPLATE:
            error_msg = (
                f"Native AIP tools require template '{DEFAULT_SANDBOX_TEMPLATE}', "
                f"but received template '{template}'. "
                f"Use template='{DEFAULT_SANDBOX_TEMPLATE}' or omit template to use the default."
            )
            logger.error(
                "ptc_native_runtime_incompatible: "
                f"template_alias={template}, expected_alias={DEFAULT_SANDBOX_TEMPLATE}"
            )
            await self.cleanup()
            raise RuntimeError(error_msg)

    async def _install_packages(self) -> None:
        """Install packages in the sandbox."""
        if self._sandbox is None:
            raise RuntimeError(SANDBOX_NOT_INITIALIZED_ERROR)

        packages = self._packages
        if packages is None or not packages:
            return

        # Validate all packages before constructing command
        validate_package_names(packages)

        # Note: packages_str is safe because packages is a controlled list from
        # configuration, not user input. E2B SDK's commands.run() only accepts str,
        # not list, so string joining is required.
        packages_str = " ".join(packages)
        logger.info(f"Installing packages in sandbox: {packages_str}")

        try:
            run_kwargs: dict[str, Any] = {}
            if self._package_install_timeout > 0:
                run_kwargs["timeout"] = self._package_install_timeout
            else:
                run_kwargs["timeout"] = 0
            result = await self._sandbox.commands.run(f"pip install -q {packages_str}", **run_kwargs)
        except Exception as e:
            logger.error(f"Error installing packages: {e}")
            raise

        if result.exit_code != 0:
            logger.error(f"Failed to install packages: {result.stderr}")
            raise RuntimeError(f"Failed to install PTC packages: {result.stderr}")

        logger.info("Packages installed successfully")

    # Backward compatibility alias
    _install_ptc_packages = _install_packages

    async def _upload_files(self, files: dict[str, str]) -> None:
        """Upload files to the sandbox.

        Args:
            files: Mapping of path -> content.
        """
        if self._sandbox is None:
            raise RuntimeError(SANDBOX_NOT_INITIALIZED_ERROR)

        for path, content in files.items():
            logger.debug(f"Uploading file to sandbox: {path}")
            await self._sandbox.files.write(path, content)

    async def _apply_sandbox_timeout(self) -> None:
        """Apply configured sandbox session timeout when supported by SDK."""
        if self._sandbox is None:
            return

        set_timeout = getattr(self._sandbox, "set_timeout", None)
        if set_timeout is None:
            return

        try:
            maybe_awaitable = set_timeout(self._sandbox_timeout)
            if hasattr(maybe_awaitable, "__await__"):
                await maybe_awaitable
        except Exception as e:
            logger.warning(f"Failed to set sandbox timeout to {self._sandbox_timeout}: {e}")

    async def _run_code(
        self,
        code: str,
        env: dict[str, str] | None = None,
        language: str = "python",
    ) -> SandboxExecutionResult:
        """Run code in the sandbox.

        Args:
            code: Code to execute.
            env: Environment variables.
            language: Execution language. Defaults to ``"python"``.
                Timeout is handled by the caller via ``asyncio.timeout``.

        Returns:
            SandboxExecutionResult with execution output.
        """
        if self._sandbox is None:
            raise RuntimeError(SANDBOX_NOT_INITIALIZED_ERROR)

        stdout_lines: list[str] = []
        stderr_lines: list[str] = []

        def on_stdout(msg: OutputMessage) -> None:
            if hasattr(msg, "line"):
                stdout_lines.append(msg.line)

        def on_stderr(msg: OutputMessage) -> None:
            if hasattr(msg, "line"):
                stderr_lines.append(msg.line)

        try:
            execution = await self._sandbox.run_code(
                code=code,
                language=language,
                on_stdout=on_stdout,
                on_stderr=on_stderr,
                envs=env,
            )

            # Determine exit code
            exit_code = 0
            if execution.error:
                exit_code = 1
                # Add error to stderr
                error_msg = f"{execution.error.name}: {execution.error.value}"
                if execution.error.traceback:
                    error_msg = f"{execution.error.traceback}\n{error_msg}"
                stderr_lines.append(error_msg)

            return SandboxExecutionResult(
                stdout="\n".join(stdout_lines),
                stderr="\n".join(stderr_lines),
                exit_code=exit_code,
            )

        except Exception as e:
            logger.error(f"Sandbox execution failed: {e}")
            return SandboxExecutionResult(
                stdout="",
                stderr=str(e),
                exit_code=1,
            )
