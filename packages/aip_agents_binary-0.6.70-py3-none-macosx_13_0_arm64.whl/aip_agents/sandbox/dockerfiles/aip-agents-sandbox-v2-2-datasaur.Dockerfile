FROM python:3.12

USER root
WORKDIR /root

ENV JUPYTER_CONFIG_PATH=/root/.jupyter \
    IPYTHON_CONFIG_PATH=/root/.ipython \
    SERVER_PATH=/root/.server \
    BUN_VERSION=1.1.38

RUN : "1) Install base OS deps + signed NodeSource repo + nodejs" && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive DEBCONF_NOWARNINGS=yes \
    apt-get install -y --no-install-recommends \
    build-essential \
    ca-certificates \
    curl \
    fonts-noto-cjk \
    git \
    gnupg \
    jq \
    libcairo2-dev \
    libgirepository1.0-dev \
    pkg-config \
    python3-dev \
    ripgrep \
    sudo \
    util-linux && \
    mkdir -p /etc/apt/keyrings && \
    curl --proto '=https' --tlsv1.2 -fsSL \
    -o /etc/apt/keyrings/nodesource.asc \
    https://deb.nodesource.com/gpgkey/nodesource-repo.gpg.key && \
    gpg --dearmor -o /etc/apt/keyrings/nodesource.gpg /etc/apt/keyrings/nodesource.asc && \
    chmod 644 /etc/apt/keyrings/nodesource.gpg && \
    rm -f /etc/apt/keyrings/nodesource.asc && \
    echo "deb [signed-by=/etc/apt/keyrings/nodesource.gpg] https://deb.nodesource.com/node_20.x nodistro main" > /etc/apt/sources.list.d/nodesource.list && \
    apt-get update && \
    DEBIAN_FRONTEND=noninteractive DEBCONF_NOWARNINGS=yes \
    apt-get install -y --no-install-recommends nodejs && \
    rm -rf /var/lib/apt/lists/* && \
    : "" && \
    : "2) Bootstrap code-interpreter template files" && \
    git clone --depth 1 --branch "@e2b/code-interpreter-template@0.2.1" \
    https://github.com/e2b-dev/code-interpreter /tmp/code-interpreter-template && \
    cp /tmp/code-interpreter-template/template/requirements.txt /root/requirements.txt && \
    cp -r /tmp/code-interpreter-template/template/server /root/.server && \
    mkdir -p /root/.config/matplotlib /root/.jupyter /root/.ipython/profile_default/startup && \
    cp /tmp/code-interpreter-template/template/matplotlibrc /root/.config/matplotlib/.matplotlibrc && \
    cp /tmp/code-interpreter-template/template/start-up.sh /root/.jupyter/start-up.sh && \
    cp /tmp/code-interpreter-template/template/jupyter_server_config.py /root/.jupyter/ && \
    cp /tmp/code-interpreter-template/template/ipython_kernel_config.py /root/.ipython/profile_default/ && \
    cp -r /tmp/code-interpreter-template/template/startup_scripts /root/.ipython/profile_default/startup && \
    rm -rf /tmp/code-interpreter-template && \
    : "" && \
    : "3) Install Python/Node runtimes and patch server timeout" && \
    PIP_INDEX_URL=https://download.pytorch.org/whl/cpu \
    PIP_EXTRA_INDEX_URL=https://pypi.org/simple \
    TMPDIR=/var/tmp pip install --no-cache-dir --only-binary :all: "torch==2.5.1+cpu" && \
    echo "torch==2.5.1+cpu" > /tmp/constraints.txt && \
    PIP_INDEX_URL=https://download.pytorch.org/whl/cpu \
    PIP_EXTRA_INDEX_URL=https://pypi.org/simple \
    TMPDIR=/var/tmp pip install --no-cache-dir --only-binary :all: -c /tmp/constraints.txt -r requirements.txt && \
    PIP_INDEX_URL=https://download.pytorch.org/whl/cpu \
    PIP_EXTRA_INDEX_URL=https://pypi.org/simple \
    TMPDIR=/var/tmp pip install --no-cache-dir --only-binary :all: \
    "aip-agents-binary[local]~=0.6.62" \
    "boto3==1.43.6" \
    "httpx==0.28.1" \
    "mcp==1.25.0" && \
    TMPDIR=/var/tmp pip install --no-cache-dir --only-binary :all: "bash_kernel==0.10.0" && \
    ipython kernel install --name "python3" --user && \
    python -m bash_kernel.install --user && \
    npm install -g --ignore-scripts "git+https://github.com/e2b-dev/ijavascript.git#1.3.0" && \
    npm rebuild -g && \
    ijsinstall --install=global && \
    sed -i \
    "s/client = httpx.AsyncClient()/client = httpx.AsyncClient(timeout=httpx.Timeout(30.0))/" \
    /root/.server/main.py && \
    grep -q \
    "client = httpx.AsyncClient(timeout=httpx.Timeout(30.0))" \
    /root/.server/main.py && \
    python -m venv .server/.venv && \
    .server/.venv/bin/pip install --no-cache-dir --only-binary :all: -r .server/requirements.txt && \
    chmod +x .jupyter/start-up.sh && \
    : "" && \
    : "4) Install Datasaur runtime dependencies" && \
    apt-get update && \
    apt-get install -y --no-install-recommends unzip && \
    mkdir -p /etc/apt/keyrings && \
    curl --proto '=https' --tlsv1.2 -fsSL \
    -o /tmp/githubcli-archive-keyring.gpg \
    https://cli.github.com/packages/githubcli-archive-keyring.gpg && \
    gpg --dearmor -o /etc/apt/keyrings/githubcli-archive-keyring.gpg \
    /tmp/githubcli-archive-keyring.gpg && \
    rm -f /tmp/githubcli-archive-keyring.gpg && \
    chmod go+r /etc/apt/keyrings/githubcli-archive-keyring.gpg && \
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" \
    > /etc/apt/sources.list.d/github-cli.list && \
    apt-get update && \
    apt-get install -y --no-install-recommends gh && \
    curl --proto '=https' --tlsv1.2 -fsSL \
    -o /tmp/bun-install.sh \
    https://bun.sh/install && \
    echo "bab8acfb046aac8c72407bdcce903957665d655d7acaa3e11c7c4616beae68dd  /tmp/bun-install.sh" | sha256sum -c - && \
    bash /tmp/bun-install.sh -- "bun-v${BUN_VERSION}" && \
    rm -f /tmp/bun-install.sh && \
    export BUN_INSTALL=/root/.bun && \
    export PATH="$BUN_INSTALL/bin:$PATH" && \
    npm install -g @playwright/cli@0.1.11 --ignore-scripts && \
    playwright-cli install --skills && \
    npx --ignore-scripts -y playwright install chrome && \
    command -v gh && \
    command -v node && \
    command -v npm && \
    command -v bun && \
    command -v playwright-cli && \
    gh --version && \
    node --version && \
    npm --version && \
    bun --version && \
    playwright-cli --version && \
    rm -rf /var/lib/apt/lists/* && \
    : "" && \
    : "5) Create runtime user and sudo policy" && \
    (id -u user >/dev/null 2>&1 || useradd -m user) && \
    mkdir -p /home/user && \
    chown -R user:user /home/user && \
    (grep -q "^user ALL=(ALL) NOPASSWD: ALL$" /etc/sudoers || \
    echo "user ALL=(ALL) NOPASSWD: ALL" >> /etc/sudoers)

ENV BUN_INSTALL=/root/.bun
ENV PATH="$BUN_INSTALL/bin:$PATH"

USER user
WORKDIR /home/user

ENTRYPOINT ["sudo", "/root/.jupyter/start-up.sh"]
