"""Mem0-specific adapter built on top of the BaseMemoryAdapter.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import os
from typing import Any
from urllib.parse import urlparse

try:
    from gllm_memory import MemoryManager

    _HAS_GLLM_MEMORY = True
except ImportError:  # pragma: no cover
    MemoryManager = Any  # type: ignore[assignment]
    _HAS_GLLM_MEMORY = False

from aip_agents.memory.adapters.base_adapter import BaseMemoryAdapter
from aip_agents.memory.constants import MemoryDefaults


class Mem0Memory(BaseMemoryAdapter):
    """Mem0-backed long-term memory adapter using the gllm_memory SDK."""

    _SELF_HOST_PLACEHOLDER_KEY = "self-host-no-auth"
    _KNOWN_SAAS_HOSTS: frozenset[str] = frozenset({"api.mem0.ai"})

    def __init__(
        self,
        *,
        agent_id: str,
        namespace: str | None = None,
        limit: int = MemoryDefaults.RETRIEVAL_LIMIT,
        max_chars: int = MemoryDefaults.MAX_CHARS,
        host: str | None = None,
        instruction: str | None = None,
    ) -> None:
        """Initialize the Mem0 memory adapter.

        Args:
            agent_id: Unique identifier for the agent using this memory.
            namespace: Optional namespace for organizing memories.
            limit: Maximum number of memories to retrieve in search operations.
            max_chars: Maximum character length for text content.
            host: Optional host URL for the Mem0 service.
            instruction: Optional instruction text for memory operations.
        """
        if not _HAS_GLLM_MEMORY:
            raise ImportError("optional dependency 'gllm-memory' is required for Mem0Memory")

        self._resolved_host = self._resolve_host_url(host)
        manager = self._initialize_manager(host=self._resolved_host, instruction=instruction)
        super().__init__(
            agent_id=agent_id,
            manager=manager,
            namespace=namespace,
            limit=limit,
            max_chars=max_chars,
        )
        if self._resolved_host:
            self._retrieve_retry_count = 3
            self._retrieve_retry_delay = 0.5

    @classmethod
    def validate_env(cls) -> None:
        """Ensure Mem0 environment is configured for SaaS or self-host."""
        host = cls._resolve_host_url()
        cls._resolve_api_key(host=host)

    @staticmethod
    def _resolve_host_url(host: str | None = None) -> str | None:
        """Resolve Mem0 host with explicit host taking precedence."""
        return host or os.getenv("MEM0_HOST") or os.getenv("GLLM_MEMORY_HOST")

    @staticmethod
    def _resolve_api_key(host: str | None = None) -> str:
        api_key = os.getenv("MEM0_API_KEY") or os.getenv("GLLM_MEMORY_API_KEY")
        if api_key:
            return api_key
        if host and Mem0Memory._is_self_host_url(host):
            return Mem0Memory._SELF_HOST_PLACEHOLDER_KEY
        if host:
            raise ValueError(
                f"Mem0 host '{host}' appears to be a SaaS endpoint. "
                "Set MEM0_API_KEY (or GLLM_MEMORY_API_KEY) for SaaS access."
            )
        raise ValueError("MEM0_API_KEY (or GLLM_MEMORY_API_KEY) must be configured for Mem0 access.")

    @staticmethod
    def _is_self_host_url(url: str) -> bool:
        """Return True when URL host does not match known Mem0 SaaS hosts."""
        try:
            hostname = (urlparse(url).hostname or "").lower()
        except Exception:  # noqa: BLE001
            return True
        return hostname not in Mem0Memory._KNOWN_SAAS_HOSTS

    def _initialize_manager(self, host: str | None, instruction: str | None) -> MemoryManager:
        """Create a MemoryManager tailored for the Mem0 backend.

        Args:
            host: Optional host URL for the Mem0 service.
            instruction: Optional instruction text for memory operations.

        Returns:
            Configured MemoryManager instance for Mem0.
        """
        resolved_host = self._resolve_host_url(host)
        api_key = self._resolve_api_key(host=resolved_host)
        resolved_instruction = instruction or os.getenv("GLLM_MEMORY_INSTRUCTION")
        return MemoryManager(api_key=api_key, host=resolved_host, instruction=resolved_instruction)

    def _get_scope_agent_id(self) -> str | None:
        """Disable agent-id scope filters for self-hosted Mem0 reads/deletes.

        Self-host deployments can persist memories without source/target metadata
        expected by gllm-memory's scoped filters, causing empty search/list results
        when agent_id is supplied.
        """
        if self._resolved_host:
            return None
        return self.agent_id
