"""Local disk filesystem backend implementation.

This module provides LocalDiskBackend, a BackendProtocol implementation
that stores files on the actual filesystem using pathlib.

TODO: When migrating to deepagents:
  1. Import BackendProtocol and types from deepagents.backends.protocol
  2. Keep LocalDiskBackend as wrapper around FilesystemBackend (adapter pattern)

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
    Putu Ravindra Wiguna (putu.r.wiguna@gdplabs.id)
"""

from __future__ import annotations

import json
import os
import re
import shlex
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from aip_agents.middleware.backends.protocol import (
    BackendProtocol,
    EditResult,
    ExecuteResult,
    FileInfo,
    GrepMatch,
    WriteResult,
)
from aip_agents.middleware.backends.utils import (
    format_content_with_line_numbers,
    perform_string_replacement,
    redact_secrets,
)

__all__ = ["LocalDiskBackend"]

# macOS path aliases for /var directory
_MACOS_PRIVATE_VAR = "/private/var/"
_MACOS_VAR = "/var/"
_READ_CHARS_SKIP_CHUNK_SIZE = 8192
_ALLOWLISTED_AMBIENT_ENV_KEYS: frozenset[str] = frozenset(
    {
        "PATH",
        "HOME",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "TERM",
        "TMPDIR",
        "SYSTEMROOT",
        "WINDIR",
    }
)


class LocalDiskBackend(BackendProtocol):
    """Local disk filesystem backend.

    Implements BackendProtocol using actual filesystem storage via pathlib.
    Files persist across sessions and are stored on disk.

    Security:
        All paths are validated to prevent directory traversal attacks.
        Operations are restricted to the base_directory.

    Attributes:
        base_path: Root directory for all file operations.

    Example:
        >>> backend = LocalDiskBackend(base_directory="/tmp/agent_files")
        >>> backend.write("/test.txt", "Hello World")
        >>> content = backend.read("/test.txt")
    """

    def __init__(
        self,
        base_directory: str | Path | None = None,
        allow_execute: bool = False,  # SECURITY: disabled by default
        env: dict[str, str] | None = None,
    ) -> None:
        """Initialize local disk backend.

        Args:
            base_directory: Root directory for file storage. Created if
                it doesn't exist. If None, use system temp directory.
            allow_execute: Whether to allow command execution. Disabled by
                default for security. Set True only for trusted environments.
            env: Optional environment variables to merge into execute() calls.
                Values from this mapping override same-name variables from the
                ambient process environment.
        """
        if base_directory is None:
            temp_dir = tempfile.mkdtemp(prefix="agent_files_")
            base_path = Path(temp_dir)
        else:
            base_path = Path(base_directory)

        base_path = base_path.resolve()
        self._ensure_safe_directory(base_path)
        self.base_path = base_path
        self.allow_execute = allow_execute
        self._env = dict(env) if env else None

    def _ensure_safe_directory(self, path: Path) -> None:
        """Ensure the directory exists with safe permissions and ownership.

        Args:
            path: The directory path to verify/create.

        Raises:
            PermissionError: If the directory is owned by another user.
        """
        path.mkdir(parents=True, exist_ok=True, mode=0o700)

        if os.name != "nt":
            stat_info = path.stat()
            if stat_info.st_uid != os.getuid():
                raise PermissionError(
                    f"Security risk: Directory '{path}' is owned by another user (uid {stat_info.st_uid}). "
                    "In a shared publicly writable directory like /tmp, this could lead to symlink attacks. "
                    "Please use a private directory or delete the existing one."
                )

            if stat_info.st_mode & 0o077:
                path.chmod(0o700)

    def _rel_posix(self, p: Path) -> str:
        """Convert path to relative POSIX-style path string.

        Args:
            p: Path to convert.

        Returns:
            Relative path with forward slashes.
        """
        base_candidates = self._canonical_path_candidates(self.base_path)
        target_candidates = self._canonical_path_candidates(p)

        for candidate_target in target_candidates:
            for candidate_base in base_candidates:
                try:
                    return candidate_target.relative_to(candidate_base).as_posix()
                except ValueError:
                    continue

        target_real = target_candidates[-1]
        base_real = base_candidates[-1]
        try:
            rel = os.path.relpath(str(target_real), str(base_real))
        except ValueError as e:
            raise ValueError(f"Path '{target_real}' is not within base directory '{base_real}'") from e

        rel_posix = rel.replace("\\", "/")
        if rel_posix == ".." or rel_posix.startswith("../") or os.path.isabs(rel):
            raise ValueError(f"Path '{target_real}' is not within base directory '{base_real}'")

        return rel_posix

    @staticmethod
    def _macos_var_alias(path: Path) -> Path | None:
        """Return alternate /var <-> /private/var alias when applicable."""
        posix_path = path.as_posix()
        if posix_path.startswith(_MACOS_PRIVATE_VAR):
            return Path(posix_path.replace(_MACOS_PRIVATE_VAR, _MACOS_VAR, 1))
        if posix_path.startswith(_MACOS_VAR):
            return Path(posix_path.replace(_MACOS_VAR, _MACOS_PRIVATE_VAR, 1))
        return None

    def _canonical_path_candidates(self, path: Path) -> list[Path]:
        """Build canonical path variants for robust cross-platform comparisons."""
        resolved = path.resolve(strict=False)
        candidates = [resolved]

        realpath_candidate = Path(os.path.realpath(resolved.as_posix()))
        if realpath_candidate not in candidates:
            candidates.append(realpath_candidate)

        index = 0
        while index < len(candidates):
            alias_candidate = self._macos_var_alias(candidates[index])
            if alias_candidate is not None and alias_candidate not in candidates:
                candidates.append(alias_candidate)
            index += 1

        return candidates

    def _resolve_path(self, path: str) -> Path:
        """Resolve a path relative to base_path securely.

        Args:
            path: Path to resolve (absolute or relative).

        Returns:
            Resolved Path object.

        Raises:
            ValueError: If path attempts directory traversal outside base_path.
        """
        if "\x00" in path:
            raise ValueError("Path contains null byte")

        base_candidates = self._canonical_path_candidates(self.base_path)

        def _is_within_base(candidate: Path) -> bool:
            candidate_variants = self._canonical_path_candidates(candidate.resolve(strict=False))
            for candidate_target in candidate_variants:
                for candidate_base in base_candidates:
                    try:
                        candidate_target.relative_to(candidate_base)
                        return True
                    except ValueError:
                        continue
            return False

        raw_path = Path(path)
        if raw_path.is_absolute():
            absolute_target = raw_path.resolve(strict=False)
            if _is_within_base(absolute_target):
                return absolute_target

        rel_path = path.lstrip("/")
        virtual_target = (self.base_path / rel_path).resolve(strict=False)
        if _is_within_base(virtual_target):
            return virtual_target

        raise ValueError(f"Path '{path}' attempts to escape base directory")

    def ls_info(self, path: str) -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path to list (absolute, relative to base).

        Returns:
            List of FileInfo objects.

        Raises:
            FileNotFoundError: If path does not exist.
            NotADirectoryError: If path is not a directory.
        """
        target = self._resolve_path(path)

        if not target.exists():
            raise FileNotFoundError(f"Directory not found: {path}")

        if not target.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {path}")

        result = []
        for item in target.iterdir():
            if item.is_file():
                stat = item.stat()
                result.append(
                    FileInfo(
                        path=self._rel_posix(item),
                        type="file",
                        size=stat.st_size,
                    )
                )
            elif item.is_dir():
                result.append(
                    FileInfo(
                        path=self._rel_posix(item),
                        type="directory",
                        size=None,
                    )
                )

        return result

    def read(
        self,
        file_path: str,
        line_offset: int = 0,
        limit: int = 2000,
        *,
        offset: int | None = None,
        thread_id: str = "default",
    ) -> str:
        """Read a file's contents with line numbers.

        Args:
            file_path: Path to the file (absolute, relative to base).
            line_offset: Line number to start from (0-indexed). Defaults to 0.
            limit: Maximum number of lines to read. Defaults to 2000.
            offset: Deprecated alias for ``line_offset``.
            thread_id: Unused for local disk backends. Accepted for protocol compatibility.

        Returns:
            File content formatted with line numbers.

        Raises:
            FileNotFoundError: If file does not exist.
            IsADirectoryError: If path is a directory.
        """
        target = self._resolve_path(file_path)

        if not target.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if target.is_dir():
            raise IsADirectoryError(f"Cannot read directory: {file_path}")

        if offset is not None:
            if line_offset != 0 and line_offset != offset:
                raise ValueError("Conflicting values provided for line_offset and offset")
            line_offset = offset

        content = target.read_text(encoding="utf-8")
        lines = content.split("\n")

        start = max(0, line_offset)
        end = min(len(lines), start + limit)
        selected_lines = lines[start:end]

        selected_content = "\n".join(selected_lines)
        if not selected_content:
            return ""
        return format_content_with_line_numbers(selected_content, offset=start)

    def read_bytes(self, file_path: str) -> bytes:
        """Read a file's raw bytes content.

        Args:
            file_path: Path to the file (absolute, relative to base).

        Returns:
            File content as raw bytes.

        Raises:
            FileNotFoundError: If file does not exist.
            IsADirectoryError: If path is a directory.
        """
        target = self._resolve_path(file_path)

        if not target.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if target.is_dir():
            raise IsADirectoryError(f"Cannot read directory: {file_path}")

        return target.read_bytes()

    def read_chars(
        self,
        file_path: str,
        char_offset: int = 0,
        max_chars: int = 20000,
    ) -> str:
        """Read a file's contents by character position.

        Provides character-based pagination for reading large files
        that may have very long single lines. Uses seek/read to avoid
        loading entire file into memory.

        Args:
            file_path: Path to the file (absolute, relative to base).
            char_offset: Character position to start from (0-indexed).
            max_chars: Maximum number of characters to read.

        Returns:
            File content without line numbers (raw characters).

        Raises:
            FileNotFoundError: If file does not exist.
            IsADirectoryError: If path is a directory.
        """
        target = self._resolve_path(file_path)

        if not target.exists():
            raise FileNotFoundError(f"File not found: {file_path}")

        if target.is_dir():
            raise IsADirectoryError(f"Cannot read directory: {file_path}")

        with target.open("r", encoding="utf-8", errors="replace") as f:
            remaining = max(0, char_offset)
            while remaining > 0:
                skipped = f.read(min(_READ_CHARS_SKIP_CHUNK_SIZE, remaining))
                if skipped == "":
                    return "[End of file reached]"
                remaining -= len(skipped)
            content = f.read(max_chars)

        if not content and char_offset <= 0:
            return ""

        if not content:
            return "[End of file reached]"

        return content

    def write(self, file_path: str, content: str) -> WriteResult:
        """Write content to a file.

        Args:
            file_path: Path where to write (absolute, relative to base).
            content: Content to write.

        Returns:
            WriteResult indicating success.
        """
        target = self._resolve_path(file_path)

        # Ensure parent directory exists
        target.parent.mkdir(parents=True, exist_ok=True)

        # Write content
        target.write_text(content, encoding="utf-8")

        return WriteResult(path=file_path, success=True)

    def edit(
        self,
        file_path: str,
        old_string: str,
        new_string: str,
        replace_all: bool = False,
    ) -> EditResult:
        """Edit a file by replacing old_string with new_string.

        Args:
            file_path: Path to the file (absolute, relative to base).
            old_string: String to find and replace.
            new_string: String to replace with.
            replace_all: If True, replace all occurrences. If False,
                old_string must appear exactly once. Defaults to False.

        Returns:
            EditResult with number of replacements.

        Notes:
            Returns errors via EditResult.error to match deepagents-style tool flow.
        """
        target = self._resolve_path(file_path)

        if not target.exists():
            return EditResult(path=file_path, error=f"Error: File '{file_path}' not found", success=False)

        content = target.read_text(encoding="utf-8")
        replacement = perform_string_replacement(content, old_string, new_string, replace_all)
        if isinstance(replacement, str):
            return EditResult(path=file_path, error=replacement, success=False)

        new_content, occurrences = replacement

        # Write back
        target.write_text(new_content, encoding="utf-8")

        return EditResult(
            path=file_path,
            occurrences=occurrences,
            success=True,
        )

    def glob_info(self, pattern: str, path: str = "/") -> list[FileInfo]:
        """Find files matching a glob pattern.

        Args:
            pattern: Glob pattern (e.g., "**/*.py", "*.txt").
            path: Base directory to search from. Defaults to "/".

        Returns:
            List of FileInfo objects for matching files.
        """
        base = self._resolve_path(path)
        result = []

        # Use rglob for recursive patterns
        if "**" in pattern:
            files = base.rglob(pattern.replace("**/", "").replace("**", ""))
        else:
            files = base.glob(pattern)

        for item in files:
            if item.is_file():
                stat = item.stat()
                result.append(
                    FileInfo(
                        path=self._rel_posix(item),
                        type="file",
                        size=stat.st_size,
                    )
                )

        return result

    def grep(
        self,
        pattern: str,
        path: str | None = None,
    ) -> list[GrepMatch]:
        """Search for text pattern across files.

        Uses ripgrep (rg) if available for fast searching, falling back to
        Python regex search. Requires ripgrep to be installed in the
        environment (e.g., via Docker).

        Args:
            pattern: Text pattern to search (literal string, not regex).
            path: Directory to search in. Defaults to None (search all).

        Returns:
            List of GrepMatch objects.

        Raises:
            FileNotFoundError: If path is specified but does not exist.
        """
        base = self._resolve_path(path) if path else self.base_path

        if not base.exists():
            raise FileNotFoundError(f"Path not found: {path}")

        # Try ripgrep first for performance
        results = self._ripgrep_search(pattern, base)
        if results is not None:
            return results

        # Fallback to Python implementation
        return self._python_search(pattern, base)

    def _ripgrep_search(self, pattern: str, base: Path) -> list[GrepMatch] | None:
        """Search using ripgrep with fixed-string (literal) mode.

        Args:
            pattern: Literal string to search for.
            base: Resolved base path to search in.

        Returns:
            List of GrepMatch objects, or None if ripgrep is unavailable.
        """
        cmd = ["rg", "--json", "-F", "--", pattern, str(base)]

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
                check=False,
            )
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return None

        matches: list[GrepMatch] = []
        for line in proc.stdout.splitlines():
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue
            if data.get("type") != "match":
                continue
            pdata = data.get("data", {})
            ftext = pdata.get("path", {}).get("text")
            if not ftext:
                continue
            p = Path(ftext)
            rel_path = self._rel_posix(p)
            ln = pdata.get("line_number")
            lt = pdata.get("lines", {}).get("text", "").rstrip("\n")
            if ln is None:
                continue
            matches.append(
                GrepMatch(
                    path=rel_path,
                    line_number=int(ln),
                    content=lt,
                )
            )

        return matches

    def _python_search(self, pattern: str, base: Path) -> list[GrepMatch]:
        """Fallback search using Python when ripgrep is unavailable.

        Args:
            pattern: Text pattern to search for.
            base: Resolved base path to search in.

        Returns:
            List of GrepMatch objects.
        """
        try:
            regex = re.compile(pattern, re.IGNORECASE)
        except re.error:
            regex = re.compile(re.escape(pattern), re.IGNORECASE)

        matches: list[GrepMatch] = []

        if base.is_file():
            files = [base]
        else:
            files = [f for f in base.rglob("*") if f.is_file()]

        for file_path in files:
            try:
                content = file_path.read_text(encoding="utf-8")
                lines = content.split("\n")

                for line_num, line in enumerate(lines, start=1):
                    if regex.search(line):
                        rel_path = self._rel_posix(file_path)
                        matches.append(
                            GrepMatch(
                                path=rel_path,
                                line_number=line_num,
                                content=line,
                            )
                        )
            except (UnicodeDecodeError, PermissionError):
                continue

        return matches

    # Alias grep_raw to grep for protocol compatibility
    grep_raw = grep

    # State sync helpers (required by BackendProtocol)
    def set_files(self, files: dict[str, Any], thread_id: str = "default") -> None:
        """Load files from state (no-op for disk backend).

        Files are already persisted on disk, so this is a no-op.
        The thread_id parameter is accepted for protocol compatibility
        but ignored since disk storage is not thread-isolated.

        Args:
            files: Dictionary mapping file paths to file data (ignored).
            thread_id: Thread identifier (ignored for disk backend).
        """
        # Disk backend persists files automatically, no state sync needed
        pass

    def get_files(self, thread_id: str = "default") -> dict[str, Any]:
        """Get files for a specific thread (no-op for disk backend).

        Returns empty dict since disk backend doesn't track files in memory.
        The thread_id parameter is accepted for protocol compatibility
        but ignored.

        Args:
            thread_id: Thread identifier (ignored for disk backend).

        Returns:
            Empty dictionary.
        """
        # Disk backend doesn't track files in memory
        return {}

    DANGEROUS_PATTERNS = [
        r"mkfs",  # Format filesystem
        r"dd\s+if=/dev/zero",  # Overwrite with zeros
        r">\s*/dev/",  # Redirect to device files
        r"\bsudo\b",  # sudo commands
        r"\bsu\s+-",  # su - root
        r"chmod\s+.*777",  # Make everything executable (includes -R)
        r"apt-get",  # Package manager
        r"yum\s+install",  # Package manager
        r"pacman",  # Package manager
        r"curl\s+.*\s*\|",  # curl | bash patterns
        r"wget\s+.*\s*\|",  # wget | bash patterns
        r":\s*\(\)\s*{\s*:\s*\|",  # Fork bomb
    ]
    _SHELL_OPERATORS = frozenset({"&&", "||", ";", "|", "&"})
    _SHELL_OPERATOR_TOKENS = frozenset({"&&", "||", ";", "|", "&", ">", ">>", "<", "<<"})

    @staticmethod
    def _is_dangerous_rm_target(target: str) -> bool:
        return target in {"/", ".", "..", "~"} or target.startswith("/") or target.startswith("~/")

    @staticmethod
    def _is_recursive_rm_option(token: str) -> bool:
        """Check if a token is a recursive option for rm command."""
        if token.startswith("--"):
            return token == "--recursive"
        if token.startswith("-"):
            return "r" in token[1:]
        return False

    def _scan_rm_segment(self, tokens: list[str], start_index: int) -> tuple[int, bool]:
        """Scan tokens following an rm command for dangerous recursive delete patterns."""
        recursive = False
        index = start_index

        while index < len(tokens):
            token = tokens[index]

            if token in self._SHELL_OPERATORS:
                return index + 1, False

            if self._is_recursive_rm_option(token):
                recursive = True
                index += 1
                continue

            if recursive and self._is_dangerous_rm_target(token):
                return index + 1, True

            index += 1

        return index, False

    def _is_dangerous_rm_command(self, command: str) -> bool:
        """Check if the command contains a dangerous rm recursive delete pattern."""
        try:
            tokens = shlex.split(command.lower())
        except ValueError:
            return False

        index = 0

        while index < len(tokens):
            if tokens[index] != "rm":
                index += 1
                continue

            index, is_dangerous = self._scan_rm_segment(tokens, index + 1)
            if is_dangerous:
                return True

        return False

    def _is_dangerous_command(self, command: str) -> tuple[bool, str]:
        """Check if command matches dangerous patterns.

        Args:
            command: Shell command to check.

        Returns:
            Tuple of (is_dangerous, reason).
        """
        if self._is_dangerous_rm_command(command):
            return True, "Command matches dangerous rm recursive delete pattern"

        command_lower = command.lower()
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, command_lower):
                return True, f"Command matches dangerous pattern: {pattern}"
        return False, ""

    def _build_runtime_env(self) -> dict[str, str]:
        """Build the environment variables for command execution.

        Returns:
            Dictionary of environment variables to use for subprocess execution.
        """
        runtime_env = {key: value for key, value in os.environ.items() if key in _ALLOWLISTED_AMBIENT_ENV_KEYS}
        if self._env is not None:
            runtime_env.update(self._env)
        return runtime_env

    def execute(self, command: str, timeout: int = 30) -> ExecuteResult:
        """Execute a shell command using subprocess.

        SECURITY: Disabled by default. Even when enabled, dangerous
        commands are blocked. Use only in trusted development environments.
        Production should use SandboxBackend (PR 007).

        Args:
            command: Shell command to execute.
            timeout: Timeout in seconds.

        Returns:
            ExecuteResult with output and exit code.
        """
        # Security check 1: Must be explicitly enabled
        if not self.allow_execute:
            return ExecuteResult(
                stdout="",
                stderr=(
                    "Error: Command execution is disabled for security. "
                    "Enable with LocalDiskBackend(allow_execute=True). "
                    "For production, use SandboxBackend (PR 007)."
                ),
                exit_code=-1,
                truncated=False,
            )

        # Security check 2: Block dangerous commands
        is_dangerous, reason = self._is_dangerous_command(command)
        if is_dangerous:
            return ExecuteResult(
                stdout="",
                stderr=f"Error: Command blocked for security. {reason}",
                exit_code=-1,
                truncated=False,
            )

        # Resolve virtual paths to actual filesystem paths
        resolved_command = self._resolve_command_paths(command)

        # Execute the command with cwd set to base_path for containment
        try:
            runtime_env = self._build_runtime_env()

            result = subprocess.run(
                resolved_command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=str(self.base_path),
                env=runtime_env,
            )
            return ExecuteResult(
                stdout=redact_secrets(result.stdout, self._env),
                stderr=redact_secrets(result.stderr, self._env),
                exit_code=result.returncode,
                truncated=False,
            )
        except subprocess.TimeoutExpired:
            return ExecuteResult(
                stdout="",
                stderr=f"Command timed out after {timeout} seconds",
                exit_code=-1,
                truncated=False,
            )
        except Exception as e:
            return ExecuteResult(
                stdout="",
                stderr=f"Execution error: {str(e)}",
                exit_code=-1,
                truncated=False,
            )

    def _resolve_command_paths(self, command: str) -> str:
        """Resolve virtual paths in command to actual filesystem paths.

        Replaces paths that start with '/' (virtual paths) with their
        actual resolved paths relative to base_path.

        Args:
            command: Shell command with potentially virtual paths.

        Returns:
            Command with resolved paths.
        """
        # Try to parse the command to handle arguments correctly
        try:
            parts = shlex.split(command)
        except ValueError:
            # If parsing fails, fall back to the original command
            return command

        resolved_parts = []
        for part in parts:
            # Check if this part looks like an absolute virtual path
            if part.startswith("/") and len(part) > 1:
                try:
                    # Try to resolve the path
                    resolved = self._resolve_path(part)
                    resolved_parts.append(str(resolved))
                except (ValueError, OSError):
                    # If resolution fails, keep the original
                    resolved_parts.append(part)
            else:
                resolved_parts.append(part)

        reconstructed_parts = []
        for part in resolved_parts:
            if part in self._SHELL_OPERATOR_TOKENS:
                reconstructed_parts.append(part)
                continue
            # cmd.exe does not interpret POSIX single-quote escaping.
            # Use Windows-native quoting there, POSIX quoting elsewhere.
            if os.name == "nt":
                reconstructed_parts.append(subprocess.list2cmdline([part]))
            else:
                reconstructed_parts.append(shlex.quote(part))

        return " ".join(reconstructed_parts)
