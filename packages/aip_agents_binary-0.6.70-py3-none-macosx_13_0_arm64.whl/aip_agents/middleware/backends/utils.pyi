from aip_agents.middleware.backends.protocol import GrepMatch

__all__ = ['ensure_absolute_path', 'format_content_with_line_numbers', 'format_grep_matches', 'perform_string_replacement', 'redact_secrets', 'sanitize_tool_call_id', 'truncate_if_too_long', 'EMPTY_CONTENT_WARNING', 'MAX_LINE_LENGTH', 'LINE_NUMBER_WIDTH', 'TRUNCATION_GUIDANCE']

EMPTY_CONTENT_WARNING: str
MAX_LINE_LENGTH: int
LINE_NUMBER_WIDTH: int
TRUNCATION_GUIDANCE: str

def ensure_absolute_path(path: str) -> str:
    '''Normalize path to absolute form (leading /) for tool output consistency.

    Backends may return relative paths (e.g. LocalDiskBackend). Tools that return
    paths to the agent must use absolute paths so read_file and other tools
    receive consistent input per the filesystem contract.

    Args:
        path: Path from backend (may be relative or absolute).

    Returns:
        Path with leading / (absolute form). Idempotent if already absolute.

    Example:
        >>> ensure_absolute_path("workspace/file.txt")
        \'/workspace/file.txt\'
        >>> ensure_absolute_path("/workspace/file.txt")
        \'/workspace/file.txt\'
    '''
def format_content_with_line_numbers(content: str, offset: int = 0, line_number_width: int = ...) -> str:
    '''Format content with cat -n style line numbers.

    Args:
        content: The file content to format.
        offset: Starting line number (0-indexed). Defaults to 0.
        line_number_width: Width of line number column. Defaults to 6.

    Returns:
        Formatted string with line numbers.

    Example:
        >>> format_content_with_line_numbers("line1\\nline2", offset=0)
        \'     1\\tline1\\n     2\\tline2\'
    '''
def perform_string_replacement(content: str, old_string: str, new_string: str, replace_all: bool = False) -> tuple[str, int] | str:
    """Perform string replacement in content.

    Args:
        content: Original content.
        old_string: String to find and replace.
        new_string: String to replace with.
        replace_all: If True, replace all occurrences. Defaults to False.

    Returns:
        Tuple of (new_content, occurrences) on success, or error message string.
    """
def format_grep_matches(matches: list[GrepMatch], output_mode: str = 'files_with_matches') -> str:
    '''Format grep matches for display.

    Args:
        matches: List of GrepMatch objects.
        output_mode: One of "files_with_matches", "content", or "count".
            Defaults to "files_with_matches".

    Returns:
        Formatted string based on output_mode.

    Raises:
        ValueError: If output_mode is invalid.
    '''
def truncate_if_too_long(content: list[str] | str, token_limit: int = ...) -> list[str] | str:
    """Truncate content if it exceeds token limit.

    Uses 4 characters per token as a rough estimate.
    For lists, keeps whole items (drops from end) to avoid broken paths/lines.

    Args:
        content: String or list of strings to truncate.
        token_limit: Maximum tokens allowed. Defaults to 8000.

    Returns:
        Truncated content if too long, otherwise original content.
    """
def sanitize_tool_call_id(tool_call_id: str) -> str:
    """Sanitize tool call ID for use in filenames.

    Replaces dangerous characters that could cause path traversal.

    Args:
        tool_call_id: The tool call ID to sanitize.

    Returns:
        Sanitized string safe for use in filenames.
    """
def redact_secrets(text: str, secrets: dict[str, str] | None, placeholder: str = '***') -> str:
    '''Redact secret values from text.

    Replaces exact occurrences of values from *secrets* with *placeholder*.
    Values are sorted by length (longest first) to avoid substring collisions
    where a shorter secret is contained within a longer one.

    Args:
        text: The text to redact.
        secrets: Mapping of secret names to secret values. Only the values
            are redacted, not the keys.
        placeholder: The replacement string. Defaults to "***".

    Returns:
        Text with secret values replaced by the placeholder.

    Example:
        >>> redact_secrets("token=abc123", {"TOKEN": "abc123"})
        \'token=***\'
        >>> redact_secrets("ok", None)
        \'ok\'
    '''
