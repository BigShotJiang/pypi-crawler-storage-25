"""
AGE 图同步模块单元测试

测试覆盖：
- 知识节点同步
- 关系边同步
- 图查询方法
- 错误处理
"""

import pytest
from unittest.mock import Mock, patch, MagicMock
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from generic_causal_architecture.knowledge.models import (
    KnowledgeUnit,
    KnowledgeType,
    VerificationStatus,
    Relation,
)


class TestAGEGraphSync:
    """AGE 图同步测试类"""
    
    @pytest.fixture
    def mock_storage(self):
        """创建模拟存储"""
        storage = Mock()
        storage._initialized = True
        storage._execute_cypher = Mock(return_value=[])
        return storage
    
    @pytest.fixture
    def sample_knowledge(self):
        """创建样本知识单元"""
        return KnowledgeUnit(
            name="商鞅变法",
            content="商鞅在秦国推行变法",
            knowledge_type=KnowledgeType.EVENT,
            confidence=0.95,
            relations=[
                Relation(
                    type="causes",
                    target_id="target-123",
                    strength=0.85
                )
            ]
        )
    
    def test_sync_knowledge_to_graph(self, mock_storage, sample_knowledge):
        """测试知识节点同步到图"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        with patch.object(PostgreSQLStorage, '_execute_cypher') as mock_cypher:
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            storage._sync_knowledge_to_graph(sample_knowledge)
            
            assert mock_cypher.call_count >= 2
            
            first_call = mock_cypher.call_args_list[0]
            assert "create_vlabel" in str(first_call)
            
            second_call = mock_cypher.call_args_list[1]
            assert "MERGE" in str(second_call)
            assert "商鞅变法" in str(second_call)
    
    def test_sync_knowledge_relation_to_graph(self, mock_storage):
        """测试关系边同步到图"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        with patch.object(PostgreSQLStorage, '_execute_cypher') as mock_cypher:
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            relation = Relation(
                type="causes",
                target_id="target-123",
                strength=0.8
            )
            
            storage._sync_knowledge_relation_to_graph("source-123", relation)
            
            mock_cypher.assert_called_once()
            call_args = str(mock_cypher.call_args)
            assert "CAUSES" in call_args
            assert "source-123" in call_args
            assert "target-123" in call_args
    
    def test_sync_knowledge_with_special_chars(self, mock_storage):
        """测试包含特殊字符的知识同步"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        with patch.object(PostgreSQLStorage, '_execute_cypher') as mock_cypher:
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            knowledge = KnowledgeUnit(
                name="知识'包含'引号",
                content="内容\\n换行",
                knowledge_type=KnowledgeType.EVENT,
                confidence=0.9
            )
            
            storage._sync_knowledge_to_graph(knowledge)
            
            assert mock_cypher.called
            call_str = str(mock_cypher.call_args)
            assert "\\\\'" in call_str or "知识" in call_str
    
    def test_query_causal_chain_via_graph(self):
        """测试因果链查询"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        mock_result = [
            {"result": '{"chain": ["A", "B", "C"], "depth": 2}'}
        ]
        
        with patch.object(PostgreSQLStorage, '_execute_cypher', return_value=mock_result):
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            chains = storage.query_causal_chain_via_graph("A", "C", max_depth=3)
            
            assert isinstance(chains, list)
    
    def test_query_neighbors_via_graph(self):
        """测试邻居查询"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        mock_result = [
            {"result": '"邻居1"'},
            {"result": '"邻居2"'}
        ]
        
        with patch.object(PostgreSQLStorage, '_execute_cypher', return_value=mock_result):
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            result = storage.query_neighbors_via_graph("中心节点", direction="outgoing")
            
            assert "node_name" in result
            assert "neighbors" in result
            assert result["node_name"] == "中心节点"
    
    def test_get_graph_stats(self):
        """测试图统计查询"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        with patch.object(PostgreSQLStorage, '_execute_cypher', return_value=[]):
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            stats = storage.get_graph_stats()
            
            assert "total_nodes" in stats
            assert "total_edges" in stats
            assert "graph_name" in stats
    
    def test_sync_not_initialized(self):
        """测试未初始化时抛出异常"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
        storage._initialized = False
        
        knowledge = KnowledgeUnit(
            name="测试",
            content="测试内容",
            knowledge_type=KnowledgeType.EVENT
        )
        
        with pytest.raises(RuntimeError, match="not initialized"):
            storage._sync_knowledge_to_graph(knowledge)


class TestGraphQueryEdgeCases:
    """图查询边界情况测试"""
    
    def test_empty_graph_query(self):
        """测试空图查询"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        with patch.object(PostgreSQLStorage, '_execute_cypher', return_value=[]):
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            chains = storage.query_causal_chain_via_graph("不存在A", "不存在B")
            assert chains == []
            
            neighbors = storage.query_neighbors_via_graph("不存在")
            assert neighbors["count"] == 0
    
    def test_query_with_empty_name(self):
        """测试空名称查询"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        with patch.object(PostgreSQLStorage, '_execute_cypher', return_value=[]):
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            result = storage.query_neighbors_via_graph("")
            assert result["node_name"] == ""
    
    def test_query_with_very_long_name(self):
        """测试超长名称查询"""
        from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
        
        long_name = "A" * 1000
        
        with patch.object(PostgreSQLStorage, '_execute_cypher', return_value=[]):
            storage = PostgreSQLStorage.__new__(PostgreSQLStorage)
            storage._initialized = True
            
            result = storage.query_neighbors_via_graph(long_name)
            assert result["node_name"] == long_name


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
