"""
PostgreSQL 存储性能基准测试

测试内容:
1. 事件插入性能 (单条 vs 批量)
2. 事件查询性能 (按 ID、按类型、按时间)
3. 因果关系插入性能
4. 图查询性能 (Cypher)
5. 并发性能

使用方式:
    python tests/test_postgresql_performance.py
"""

import sys
import time
import random
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.storage.storage_interface import EventData, CausalRelation


class PerformanceTester:
    """性能测试器"""
    
    def __init__(self, storage: PostgreSQLStorage):
        self.storage = storage
        self.results: Dict[str, float] = {}
    
    def benchmark(self, name: str, func, iterations: int = 1) -> float:
        """性能测试装饰器"""
        print(f"\n测试：{name}")
        print(f"  迭代次数：{iterations}")
        
        start_time = time.time()
        
        for i in range(iterations):
            func(i)
        
        end_time = time.time()
        duration = end_time - start_time
        avg_time = duration / iterations
        
        self.results[name] = {
            'total': duration,
            'avg': avg_time,
            'iterations': iterations,
            'ops_per_sec': iterations / duration if duration > 0 else 0
        }
        
        print(f"  总耗时：{duration:.4f} 秒")
        print(f"  平均耗时：{avg_time:.6f} 秒")
        print(f"  操作/秒：{iterations / duration:.2f}")
        
        return duration
    
    def print_summary(self):
        """打印性能测试总结"""
        print("\n" + "=" * 80)
        print("性能测试总结")
        print("=" * 80)
        
        for name, result in self.results.items():
            print(f"\n{name}:")
            print(f"  总耗时：{result['total']:.4f} 秒")
            print(f"  平均耗时：{result['avg']:.6f} 秒")
            print(f"  操作/秒：{result['ops_per_sec']:.2f}")
        
        print("=" * 80)


def create_test_event(index: int) -> EventData:
    """创建测试事件"""
    return EventData(
        id=f"test_event_{index}",
        name=f"测试事件 {index}",
        timestamp={
            'year': random.randint(1900, 2024),
            'month': random.randint(1, 12),
            'day': random.randint(1, 28)
        },
        location=f"地点 {random.randint(1, 100)}",
        event_type=random.choice(['POLITICAL', 'MILITARY', 'ECONOMIC', 'CULTURAL']),
        description=f"这是测试事件 {index} 的描述",
        participants=[f"人物 {i}" for i in range(random.randint(1, 5))],
        evidence_sources=[f"来源 {i}" for i in range(random.randint(1, 3))]
    )


def create_test_relation(index: int) -> CausalRelation:
    """创建测试因果关系"""
    return CausalRelation(
        source_id=f"test_event_{index}",
        target_id=f"test_event_{index + 1}",
        relation_type=random.choice(['causes', 'enables', 'prevents']),
        confidence=random.uniform(0.7, 0.99),
        evidence=[f"证据 {i}" for i in range(random.randint(1, 3))],
        reasoning_steps=[
            {'step': 1, 'description': f'推理步骤 {i}'}
            for i in range(random.randint(1, 3))
        ]
    )


# ============================================================================
# 测试用例
# ============================================================================

def test_single_insert(i: int):
    """单条插入测试"""
    event = create_test_event(i)
    tester.storage.add_event(event)


def test_batch_insert(i: int):
    """批量插入测试 (100 条/批)"""
    base = i * 100
    for j in range(100):
        event = create_test_event(base + j)
        tester.storage.add_event(event)


def test_query_by_id(i: int):
    """按 ID 查询测试"""
    event_id = f"test_event_{random.randint(0, 99)}"
    tester.storage.get_event(event_id)


def test_query_by_type(i: int):
    """按类型查询测试"""
    event_type = random.choice(['POLITICAL', 'MILITARY', 'ECONOMIC', 'CULTURAL'])
    tester.storage.get_events_by_type(event_type)


def test_query_by_time_range(i: int):
    """按时间范围查询测试"""
    start_year = 1900 + random.randint(0, 50)
    end_year = start_year + random.randint(1, 20)
    tester.storage.get_events_by_time_range(
        {'year': start_year},
        {'year': end_year}
    )


def test_relation_insert(i: int):
    """因果关系插入测试"""
    if i < 999:
        relation = create_test_relation(i)
        tester.storage.add_causal_relation(relation)


def test_causal_path_query(i: int):
    """因果路径查询测试"""
    source_id = f"test_event_{random.randint(0, 100)}"
    target_id = f"test_event_{random.randint(source_id.split('_')[-1], 999)}"
    try:
        tester.storage.get_causal_path(source_id, target_id)
    except:
        pass  # 路径可能不存在


def test_cypher_query(i: int):
    """Cypher 图查询测试"""
    cypher = f"""
        MATCH (e:Event {{id: 'test_event_{i % 100}'}})-[:CAUSES*1..3]->(e2:Event)
        RETURN e2
    """
    try:
        tester.storage._execute_cypher(cypher)
    except:
        pass


# ============================================================================
# 主测试流程
# ============================================================================

def main():
    """运行所有性能测试"""
    global tester
    
    print("=" * 80)
    print("PostgreSQL 存储性能基准测试")
    print("=" * 80)
    print(f"开始时间：{datetime.now()}")
    
    # 1. 初始化存储
    print("\n[1/8] 初始化 PostgreSQL 存储...")
    storage = PostgreSQLStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db",
        pool_size=10,
        echo=False
    )
    storage.initialize()
    print("✓ 存储初始化完成")
    
    # 2. 清理旧数据
    print("\n[2/8] 清理旧测试数据...")
    storage._execute_sql("DELETE FROM relations WHERE source_id LIKE 'test_event_%'", fetch=False)
    storage._execute_sql("DELETE FROM events WHERE id LIKE 'test_event_%'", fetch=False)
    print("✓ 清理完成")
    
    # 3. 创建测试器
    tester = PerformanceTester(storage)
    
    # 4. 运行测试
    print("\n[3/8] 测试单条插入性能...")
    tester.benchmark("单条插入 (1000 次)", test_single_insert, iterations=1000)
    
    print("\n[4/8] 测试批量插入性能...")
    tester.benchmark("批量插入 (100 批×100 条)", test_batch_insert, iterations=100)
    
    print("\n[5/8] 测试查询性能...")
    tester.benchmark("按 ID 查询 (100 次)", test_query_by_id, iterations=100)
    tester.benchmark("按类型查询 (100 次)", test_query_by_type, iterations=100)
    tester.benchmark("按时间范围查询 (100 次)", test_query_by_time_range, iterations=100)
    
    print("\n[6/8] 测试因果关系插入...")
    tester.benchmark("因果关系插入 (500 次)", test_relation_insert, iterations=500)
    
    print("\n[7/8] 测试图查询性能...")
    tester.benchmark("因果路径查询 (50 次)", test_causal_path_query, iterations=50)
    tester.benchmark("Cypher 图查询 (50 次)", test_cypher_query, iterations=50)
    
    # 5. 打印总结
    print("\n[8/8] 性能测试总结...")
    tester.print_summary()
    
    # 6. 清理测试数据
    print("\n清理测试数据...")
    storage._execute_sql("DELETE FROM relations WHERE source_id LIKE 'test_event_%'", fetch=False)
    storage._execute_sql("DELETE FROM events WHERE id LIKE 'test_event_%'", fetch=False)
    print("✓ 清理完成")
    
    print(f"\n结束时间：{datetime.now()}")
    print("=" * 80)
    
    return True


if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ 测试失败：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
