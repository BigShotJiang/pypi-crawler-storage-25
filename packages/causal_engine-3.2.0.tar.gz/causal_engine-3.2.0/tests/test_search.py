"""
搜索功能测试

测试所有存储实现的搜索功能：
1. MemoryStorage.search_events()
2. SQLiteStorage.search_events()
3. PostgreSQLStorage.search_events()

运行测试：
    python -m pytest tests/test_search.py -v
"""

import pytest
from generic_causal_architecture.storage import (
    MemoryStorage,
    SQLiteStorage,
    EventData
)
import tempfile
import os


class TestMemoryStorageSearch:
    """测试 MemoryStorage 搜索功能"""
    
    @pytest.fixture
    def storage(self):
        """创建带有测试数据的存储"""
        storage = MemoryStorage()
        storage.initialize()
        
        # 添加测试事件
        events = [
            EventData(
                id="e1",
                name="商鞅变法",
                timestamp=-356,
                location="秦国",
                event_type="political",
                description="商鞅在秦国实施的变法改革",
                metadata={"domain": "history"}
            ),
            EventData(
                id="e2",
                name="秦统一六国",
                timestamp=-221,
                location="中国",
                event_type="military",
                description="秦始皇统一六国，建立秦朝",
                metadata={"domain": "history"}
            ),
            EventData(
                id="e3",
                name="焚书坑儒",
                timestamp=-213,
                location="咸阳",
                event_type="cultural",
                description="秦始皇焚毁书籍，坑杀儒生",
                metadata={"domain": "history"}
            ),
            EventData(
                id="e4",
                name="陈胜吴广起义",
                timestamp=-209,
                location="大泽乡",
                event_type="rebellion",
                description="秦末农民起义",
                metadata={"domain": "history"}
            ),
        ]
        
        for event in events:
            storage.add_event(event)
        
        return storage
    
    def test_search_by_name(self, storage):
        """测试按名称搜索"""
        results = storage.search_events("商鞅")
        assert len(results) == 1
        assert results[0].name == "商鞅变法"
    
    def test_search_by_description(self, storage):
        """测试按描述搜索"""
        results = storage.search_events("变法")
        assert len(results) >= 1
        assert any("变法" in (e.description or "") for e in results)
    
    def test_search_by_location(self, storage):
        """测试按地点搜索"""
        results = storage.search_events("咸阳")
        assert len(results) == 1
        assert results[0].location == "咸阳"
    
    def test_search_with_type_filter(self, storage):
        """测试按类型过滤"""
        results = storage.search_events("秦", event_type="military")
        assert len(results) == 1
        assert results[0].event_type == "military"
    
    def test_search_with_domain_filter(self, storage):
        """测试按领域过滤"""
        results = storage.search_events("秦", domain="history")
        assert len(results) >= 2  # 商鞅变法、秦统一六国、焚书坑儒等
    
    def test_search_empty_query(self, storage):
        """测试空查询"""
        results = storage.search_events("")
        assert len(results) == 0
    
    def test_search_no_results(self, storage):
        """测试无结果"""
        results = storage.search_events("不存在的关键词")
        assert len(results) == 0
    
    def test_search_limit(self, storage):
        """测试限制数量"""
        results = storage.search_events("秦", limit=2)
        assert len(results) <= 2
    
    def test_search_relevance_order(self, storage):
        """测试相关性排序（标题匹配优先）"""
        results = storage.search_events("秦")
        
        # 标题包含"秦"的应该排在前面
        if len(results) > 1:
            # 秦统一六国（标题有秦）应该比陈胜吴广起义（描述有秦）排名高
            qin_titles = [r for r in results if "秦" in r.name]
            qin_descs = [r for r in results if "秦" in (r.description or "")]
            
            # 标题匹配的应该在前面
            if qin_titles and qin_descs:
                assert results.index(qin_titles[0]) < results.index(qin_descs[0])


class TestSQLiteStorageSearch:
    """测试 SQLiteStorage 搜索功能"""
    
    @pytest.fixture
    def db_path(self):
        """创建临时数据库文件"""
        fd, path = tempfile.mkstemp(suffix='.db')
        os.close(fd)
        yield path
        os.unlink(path)
    
    @pytest.fixture
    def storage(self, db_path):
        """创建带有测试数据的存储"""
        storage = SQLiteStorage(db_path=db_path)
        storage.initialize()
        
        # 添加测试事件（同 MemoryStorage）
        events = [
            EventData(
                id="e1",
                name="商鞅变法",
                timestamp=-356,
                location="秦国",
                event_type="political",
                description="商鞅在秦国实施的变法改革",
                metadata={"domain": "history"}
            ),
            EventData(
                id="e2",
                name="秦统一六国",
                timestamp=-221,
                location="中国",
                event_type="military",
                description="秦始皇统一六国，建立秦朝",
                metadata={"domain": "history"}
            ),
            EventData(
                id="e3",
                name="焚书坑儒",
                timestamp=-213,
                location="咸阳",
                event_type="cultural",
                description="秦始皇焚毁书籍，坑杀儒生",
                metadata={"domain": "history"}
            ),
        ]
        
        for event in events:
            storage.add_event(event)
        
        return storage
    
    def test_search_by_name(self, storage):
        """测试按名称搜索"""
        results = storage.search_events("商鞅")
        assert len(results) == 1
        assert results[0].name == "商鞅变法"
    
    def test_search_by_description(self, storage):
        """测试按描述搜索"""
        results = storage.search_events("变法")
        assert len(results) >= 1
    
    def test_search_with_type_filter(self, storage):
        """测试按类型过滤"""
        results = storage.search_events("秦", event_type="military")
        assert len(results) == 1
        assert results[0].event_type == "military"
    
    def test_search_empty_query(self, storage):
        """测试空查询"""
        results = storage.search_events("")
        assert len(results) == 0
    
    def test_search_limit(self, storage):
        """测试限制数量"""
        results = storage.search_events("秦", limit=1)
        assert len(results) <= 1


class TestSearchIntegration:
    """搜索功能集成测试"""
    
    @pytest.fixture
    def storage(self):
        """创建 MemoryStorage 用于集成测试"""
        storage = MemoryStorage()
        storage.initialize()
        
        # 添加复杂测试数据
        events = [
            EventData(
                id="e1",
                name="工业革命",
                timestamp=1760,
                location="英国",
                event_type="technological",
                description="第一次工业革命，蒸汽机的发明",
                participants=["詹姆斯·瓦特"],
                metadata={"domain": "technology"}
            ),
            EventData(
                id="e2",
                name="法国大革命",
                timestamp=1789,
                location="法国",
                event_type="political",
                description="法国资产阶级革命",
                participants=["罗伯斯庇尔", "拿破仑"],
                metadata={"domain": "history"}
            ),
        ]
        
        for event in events:
            storage.add_event(event)
        
        return storage
    
    def test_search_participants(self, storage):
        """测试搜索参与者"""
        results = storage.search_events("瓦特")
        assert len(results) == 1
        assert results[0].name == "工业革命"
    
    def test_search_cross_domain(self, storage):
        """测试跨领域搜索"""
        # 不过滤领域
        results_all = storage.search_events("革命")
        assert len(results_all) == 2  # 工业革命 + 法国大革命
        
        # 过滤到 history 领域
        results_history = storage.search_events("革命", domain="history")
        assert len(results_history) == 1
        assert results_history[0].name == "法国大革命"
    
    def test_search_case_insensitive(self, storage):
        """测试大小写不敏感"""
        results1 = storage.search_events("革命")
        results2 = storage.search_events("革命")  # 中文没有大小写，但测试逻辑保留
        
        assert len(results1) == len(results2)


if __name__ == "__main__":
    # 手动运行测试
    pytest.main([__file__, "-v"])
