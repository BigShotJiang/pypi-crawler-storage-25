"""
知识提取模块单元测试

测试覆盖：
- KnowledgeExtractor 初始化
- 提示词构建
- LLM 响应解析
- 知识单元创建
- 错误处理
"""

import pytest
import json
from datetime import datetime
from unittest.mock import Mock, AsyncMock, patch
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).parent.parent))

from generic_causal_architecture.knowledge.models import (
    KnowledgeUnit,
    KnowledgeType,
    VerificationStatus,
    Evidence,
    Source,
    Relation,
)


class TestKnowledgeExtractor:
    """知识提取器测试类"""
    
    @pytest.fixture
    def mock_llm(self):
        """创建模拟 LLM Provider"""
        llm = Mock()
        llm.chat = AsyncMock()
        llm.get_usage = Mock(return_value={
            "request_count": 1,
            "total_tokens": 100,
            "cost_usd": 0.001
        })
        return llm
    
    @pytest.fixture
    def sample_extraction_response(self):
        """样本 LLM 提取响应"""
        return json.dumps({
            "knowledge": [
                {
                    "name": "商鞅变法",
                    "content": "商鞅在秦国推行变法，使秦国国力大增",
                    "knowledge_type": "event",
                    "confidence": 0.95,
                    "evidence": [
                        {
                            "content": "孝公以为然，遂变法",
                            "type": "literature",
                            "strength": 0.9,
                            "supports": True
                        }
                    ]
                }
            ],
            "relations": [
                {
                    "type": "causes",
                    "source_name": "商鞅变法",
                    "target_name": "秦统一六国",
                    "description": "变法导致秦国强大，最终统一六国",
                    "strength": 0.85
                }
            ]
        })
    
    @pytest.mark.asyncio
    async def test_extract_from_text_success(self, mock_llm, sample_extraction_response):
        """测试成功提取知识"""
        from generic_causal_architecture.knowledge.extractor import KnowledgeExtractor
        
        mock_llm.chat.return_value = sample_extraction_response
        
        extractor = KnowledgeExtractor(llm=mock_llm)
        
        text = "孝公以为然，遂变法。秦因变法而强，终统一六国。"
        result = await extractor.extract_from_text(text)
        
        assert result is not None
        assert len(result) == 1
        assert result[0].name == "商鞅变法"
        assert result[0].knowledge_type == KnowledgeType.EVENT
        assert result[0].confidence == 0.95
        
        mock_llm.chat.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_extract_from_text_empty_response(self, mock_llm):
        """测试空响应处理"""
        from generic_causal_architecture.knowledge.extractor import KnowledgeExtractor
        
        mock_llm.chat.return_value = json.dumps({"knowledge": [], "relations": []})
        
        extractor = KnowledgeExtractor(llm=mock_llm)
        result = await extractor.extract_from_text("一些无关文本")
        
        assert result == []
    
    @pytest.mark.asyncio
    async def test_extract_from_text_invalid_json(self, mock_llm):
        """测试无效 JSON 处理"""
        from generic_causal_architecture.knowledge.extractor import KnowledgeExtractor
        
        mock_llm.chat.return_value = "不是有效的 JSON"
        
        extractor = KnowledgeExtractor(llm=mock_llm)
        result = await extractor.extract_from_text("一些文本")
        
        assert result == []
    
    @pytest.mark.asyncio
    async def test_extract_from_text_llm_error(self, mock_llm):
        """测试 LLM 错误处理"""
        from generic_causal_architecture.knowledge.extractor import KnowledgeExtractor
        
        mock_llm.chat.side_effect = Exception("API 错误")
        
        extractor = KnowledgeExtractor(llm=mock_llm)
        result = await extractor.extract_from_text("一些文本")
        
        assert result == []
    
    def test_build_extraction_prompt(self, mock_llm):
        """测试提示词构建"""
        from generic_causal_architecture.knowledge.extractor import KnowledgeExtractor
        
        extractor = KnowledgeExtractor(llm=mock_llm)
        
        text = "测试文本"
        context = {"book_title": "测试书", "section_title": "第一章"}
        
        prompt = extractor._build_extraction_prompt(text, context)
        
        assert "测试文本" in prompt
        assert "测试书" in prompt
        assert "第一章" in prompt
        assert "JSON" in prompt
        assert "knowledge" in prompt
        assert "relations" in prompt


class TestKnowledgeUnit:
    """知识单元模型测试"""
    
    def test_knowledge_unit_creation(self):
        """测试知识单元创建"""
        ku = KnowledgeUnit(
            name="测试知识",
            content="测试内容",
            knowledge_type=KnowledgeType.EVENT,
            confidence=0.8,
            verification_status=VerificationStatus.VERIFIED
        )
        
        assert ku.name == "测试知识"
        assert ku.content == "测试内容"
        assert ku.knowledge_type == KnowledgeType.EVENT
        assert ku.confidence == 0.8
        assert ku.verification_status == VerificationStatus.VERIFIED
        assert ku.id is not None
    
    def test_knowledge_unit_to_dict(self):
        """测试知识单元序列化"""
        ku = KnowledgeUnit(
            name="测试知识",
            content="测试内容",
            knowledge_type=KnowledgeType.THEORY,
            confidence=0.9
        )
        
        data = ku.to_dict()
        
        assert data["name"] == "测试知识"
        assert data["content"] == "测试内容"
        assert data["knowledge_type"] == "theory"
        assert data["confidence"] == 0.9
    
    def test_knowledge_unit_from_dict(self):
        """测试知识单元反序列化"""
        data = {
            "id": "test-id",
            "name": "测试知识",
            "content": "测试内容",
            "knowledge_type": "event",
            "confidence": 0.85,
            "verification_status": "unverified",
            "evidence": [],
            "sources": [],
            "relations": [],
            "metadata": {},
            "created_at": datetime.now().isoformat(),
            "updated_at": datetime.now().isoformat()
        }
        
        ku = KnowledgeUnit.from_dict(data)
        
        assert ku.id == "test-id"
        assert ku.name == "测试知识"
        assert ku.knowledge_type == KnowledgeType.EVENT
        assert ku.confidence == 0.85


class TestEvidence:
    """证据模型测试"""
    
    def test_evidence_creation(self):
        """测试证据创建"""
        evidence = Evidence(
            content="原文证据",
            type="literature",
            strength=0.9,
            supports=True
        )
        
        assert evidence.content == "原文证据"
        assert evidence.type == "literature"
        assert evidence.strength == 0.9
        assert evidence.supports is True


class TestSource:
    """来源模型测试"""
    
    def test_source_creation(self):
        """测试来源创建"""
        source = Source(
            type="literature",
            title="史记",
            author="司马迁",
            extra_info={"dynasty": "汉"}
        )
        
        assert source.type == "literature"
        assert source.title == "史记"
        assert source.author == "司马迁"
        assert source.extra_info["dynasty"] == "汉"


class TestRelation:
    """关系模型测试"""
    
    def test_relation_creation(self):
        """测试关系创建"""
        relation = Relation(
            type="causes",
            target_id="target-123",
            description="导致关系",
            strength=0.8
        )
        
        assert relation.type == "causes"
        assert relation.target_id == "target-123"
        assert relation.description == "导致关系"
        assert relation.strength == 0.8


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
