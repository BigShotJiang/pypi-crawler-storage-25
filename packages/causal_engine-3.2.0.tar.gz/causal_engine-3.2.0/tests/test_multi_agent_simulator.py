"""
多智能体模拟器测试
"""

import sys
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.simulation.multi_agent_simulator import (
    MultiAgentSimulator,
    DigitalWorld,
    Agent,
    AgentCognition
)
from generic_causal_architecture.storage.memory_storage import MemoryStorage
from generic_causal_architecture.core.causal_engine import CausalEngine
from generic_causal_architecture.storage.storage_interface import EventData
from generic_causal_architecture.adapters.history_adapter import EventType


def test_agent_initialization():
    """测试智能体初始化"""
    print("\n" + "=" * 60)
    print("测试 1：智能体初始化")
    print("=" * 60)
    
    cognition = AgentCognition(
        agent_id="test_agent",
        world_model={'key': 'value'},
        beliefs=['belief1', 'belief2'],
        goals=['goal1'],
        knowledge={'fact': 'data'}
    )
    
    agent = Agent(
        agent_id="test_agent",
        cognition=cognition,
        strategy='rational'
    )
    
    assert agent.agent_id == "test_agent"
    assert agent.strategy == 'rational'
    assert len(agent.cognition.beliefs) == 2
    
    print(f"✓ 智能体初始化成功")
    print(f"  - ID: {agent.agent_id}")
    print(f"  - 策略：{agent.strategy}")
    print(f"  - 信念数量：{len(agent.cognition.beliefs)}")
    
    print("✓ 智能体初始化测试通过")
    return True


def test_digital_world_initialization():
    """测试数字世界初始化"""
    print("\n" + "=" * 60)
    print("测试 2：数字世界初始化")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    world = DigitalWorld(
        world_id="test_world",
        causal_engine=causal_engine
    )
    
    assert world.world_id == "test_world"
    assert world.causal_engine is causal_engine
    
    print(f"✓ 数字世界初始化成功")
    print(f"  - 世界 ID: {world.world_id}")
    print(f"  - 因果引擎：{type(world.causal_engine).__name__}")
    
    print("✓ 数字世界初始化测试通过")
    return True


def test_world_add_event():
    """测试世界添加事件"""
    print("\n" + "=" * 60)
    print("测试 3：世界添加事件")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    world = DigitalWorld(
        world_id="test_world",
        causal_engine=causal_engine
    )
    
    # 添加事件
    event = EventData(
        id="test_event",
        name="测试事件",
        timestamp={'year': 2024},
        event_type=EventType.CULTURAL
    )
    
    world.add_event(event)
    
    assert len(world.state['events']) == 1
    assert len(world.history) == 1
    
    print(f"✓ 成功添加事件到世界")
    print(f"  - 事件数量：{len(world.state['events'])}")
    print(f"  - 历史记录：{len(world.history)}")
    
    print("✓ 世界添加事件测试通过")
    return True


def test_agent_perception():
    """测试智能体感知"""
    print("\n" + "=" * 60)
    print("测试 4：智能体感知")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    world = DigitalWorld(
        world_id="test_world",
        causal_engine=causal_engine
    )
    
    # 添加一些事件
    for i in range(10):
        event = EventData(
            id=f"event_{i}",
            name=f"事件{i}",
            timestamp={'year': 2024 + i},
            event_type=EventType.CULTURAL
        )
        world.add_event(event)
    
    # 创建智能体
    cognition = AgentCognition(agent_id="observer", world_model={})
    agent = Agent(agent_id="observer", cognition=cognition, strategy='rational')
    
    # 感知世界
    perception = agent.perceive(world)
    
    # 智能体应该只感知到最近的事件 (最多 5 个)
    assert len(perception['events']) <= 5
    
    print(f"✓ 智能体感知成功")
    print(f"  - 感知到的事件数量：{len(perception['events'])}")
    print(f"  - 感知到的实体数量：{len(perception.get('entities', []))}")
    
    print("✓ 智能体感知测试通过")
    return True


def test_agent_decision():
    """测试智能体决策"""
    print("\n" + "=" * 60)
    print("测试 5：智能体决策")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    world = DigitalWorld(
        world_id="test_world",
        causal_engine=causal_engine
    )
    
    # 创建不同策略的智能体
    strategies = ['rational', 'emotional', 'random']
    
    for strategy in strategies:
        cognition = AgentCognition(agent_id=f"agent_{strategy}", world_model={})
        agent = Agent(agent_id=f"agent_{strategy}", cognition=cognition, strategy=strategy)
        
        perception = {'events': [], 'entities': []}
        action = agent.decide(perception, world)
        
        assert 'type' in action
        print(f"  - {strategy} 策略：{action['type']}")
    
    print(f"✓ 不同策略的智能体都能做出决策")
    
    print("✓ 智能体决策测试通过")
    return True


def test_multi_agent_simulator_initialization():
    """测试多智能体模拟器初始化"""
    print("\n" + "=" * 60)
    print("测试 6：多智能体模拟器初始化")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    simulator = MultiAgentSimulator(
        causal_engine=causal_engine,
        num_agents=5,
        simulation_steps=10
    )
    
    assert simulator.num_agents == 5
    assert simulator.simulation_steps == 10
    assert simulator.causal_engine is causal_engine
    
    print(f"✓ 多智能体模拟器初始化成功")
    print(f"  - 智能体数量：{simulator.num_agents}")
    print(f"  - 模拟步数：{simulator.simulation_steps}")
    
    print("✓ 多智能体模拟器初始化测试通过")
    return True


def test_create_agents():
    """测试创建智能体"""
    print("\n" + "=" * 60)
    print("测试 7：创建智能体")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    simulator = MultiAgentSimulator(
        causal_engine=causal_engine,
        num_agents=3,
        simulation_steps=5
    )
    
    # 创建默认智能体
    simulator.create_agents()
    
    assert len(simulator.agents) == 3
    print(f"✓ 成功创建 {len(simulator.agents)} 个智能体")
    
    # 验证智能体策略多样性
    strategies = [agent.strategy for agent in simulator.agents]
    print(f"  - 智能体策略：{strategies}")
    
    print("✓ 创建智能体测试通过")
    return True


def test_build_world():
    """测试构建世界"""
    print("\n" + "=" * 60)
    print("测试 8：构建世界")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    simulator = MultiAgentSimulator(
        causal_engine=causal_engine,
        num_agents=3,
        simulation_steps=5
    )
    
    # 创建初始事件
    initial_events = [
        EventData(
            id="initial_event_1",
            name="初始事件 1",
            timestamp={'year': 2024},
            event_type=EventType.CULTURAL
        ),
        EventData(
            id="initial_event_2",
            name="初始事件 2",
            timestamp={'year': 2025},
            event_type=EventType.CULTURAL
        )
    ]
    
    # 构建世界
    simulator.build_world(initial_events)
    
    assert simulator.world is not None
    assert len(simulator.world.state['events']) == 2
    
    print(f"✓ 成功构建世界")
    print(f"  - 世界 ID: {simulator.world.world_id}")
    print(f"  - 初始事件数量：{len(simulator.world.state['events'])}")
    
    print("✓ 构建世界测试通过")
    return True


def test_simulate():
    """测试完整模拟"""
    print("\n" + "=" * 60)
    print("测试 9：完整模拟")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    simulator = MultiAgentSimulator(
        causal_engine=causal_engine,
        num_agents=3,
        simulation_steps=5
    )
    
    # 创建智能体
    simulator.create_agents()
    
    # 创建初始事件
    initial_events = [
        EventData(
            id="seed_event",
            name="种子事件",
            timestamp={'year': 2024},
            event_type=EventType.CULTURAL
        )
    ]
    
    # 运行模拟
    result = simulator.simulate(initial_events)
    
    assert result is not None
    assert result.simulation_id is not None
    assert len(result.timeline) == 5  # 5 步模拟
    
    print(f"✓ 完整模拟成功")
    print(f"  - 模拟 ID: {result.simulation_id}")
    print(f"  - 时间线长度：{len(result.timeline)}")
    print(f"  - 涌现模式数量：{len(result.emergence_patterns)}")
    
    if result.emergence_patterns:
        print(f"  - 涌现模式:")
        for pattern in result.emergence_patterns:
            print(f"    · {pattern}")
    
    print("✓ 完整模拟测试通过")
    return True


def test_simulation_result_to_dict():
    """测试模拟结果转字典"""
    print("\n" + "=" * 60)
    print("测试 10：模拟结果转字典")
    print("=" * 60)
    
    storage = MemoryStorage()
    causal_engine = CausalEngine(storage)
    
    simulator = MultiAgentSimulator(
        causal_engine=causal_engine,
        num_agents=2,
        simulation_steps=3
    )
    
    simulator.create_agents()
    
    initial_events = [
        EventData(
            id="test_event",
            name="测试事件",
            timestamp={'year': 2024},
            event_type=EventType.CULTURAL
        )
    ]
    
    result = simulator.simulate(initial_events)
    
    # 转换为字典
    result_dict = result.to_dict()
    
    assert 'simulation_id' in result_dict
    assert 'timeline' in result_dict
    assert 'emergence_patterns' in result_dict
    assert len(result_dict['timeline']) == 3
    
    print(f"✓ 模拟结果转字典成功")
    print(f"  - 字典键：{list(result_dict.keys())}")
    
    print("✓ 模拟结果转字典测试通过")
    return True


def main():
    """运行所有测试"""
    print("=" * 60)
    print("多智能体模拟器测试")
    print("=" * 60)
    
    tests = [
        ("智能体初始化", test_agent_initialization),
        ("数字世界初始化", test_digital_world_initialization),
        ("世界添加事件", test_world_add_event),
        ("智能体感知", test_agent_perception),
        ("智能体决策", test_agent_decision),
        ("多智能体模拟器初始化", test_multi_agent_simulator_initialization),
        ("创建智能体", test_create_agents),
        ("构建世界", test_build_world),
        ("完整模拟", test_simulate),
        ("模拟结果转字典", test_simulation_result_to_dict),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            print(f"\n运行测试：{test_name}")
            if test_func():
                passed += 1
                print(f"✓ {test_name} 测试通过")
        except Exception as e:
            failed += 1
            print(f"✗ {test_name} 测试失败：{e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
