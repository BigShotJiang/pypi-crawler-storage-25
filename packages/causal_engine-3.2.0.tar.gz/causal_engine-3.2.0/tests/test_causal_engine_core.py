"""
CausalEngine 核心功能测试

测试重点：
1. 7 步因果检查的完整性
2. 置信度计算的准确性
3. 推理链的可解释性
4. 缓存机制的有效性
5. 领域适配器的集成
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from generic_causal_architecture.core import CausalEngine, EventData, CausalRelation
from generic_causal_architecture.storage import MemoryStorage
from generic_causal_architecture.config import Config
from generic_causal_architecture.methods import LancetMethod, IterativeWorkflow
from typing import Dict, Any


def create_test_events() -> Dict[str, EventData]:
    """创建测试事件"""
    events = {
        'wuchang_uprising': EventData(
            id='wuchang_uprising',
            name='武昌起义',
            timestamp={'year': 1911, 'month': 10, 'day': 10},
            location='武昌',
            participants=['革命党人', '新军'],
            description='武昌起义爆发，标志着辛亥革命的开始',
            event_type='revolution',
            evidence_sources=['历史记载', '学术研究'],
            metadata={'outcome': '成功占领武昌'}
        ),
        'qing_dynasty_end': EventData(
            id='qing_dynasty_end',
            name='清朝结束',
            timestamp={'year': 1912, 'month': 2, 'day': 12},
            location='北京',
            participants=['清政府', '袁世凯'],
            description='清帝退位，清朝统治结束',
            event_type='regime_change',
            evidence_sources=['历史记载', '官方文件'],
            metadata={'outcome': '清帝退位'}
        ),
        'intermediate_event': EventData(
            id='intermediate_event',
            name='各省独立',
            timestamp={'year': 1911, 'month': 11},
            location='全国多地',
            participants=['各省督抚', '革命党人'],
            description='武昌起义后，多个省份宣布独立',
            event_type='political_change',
            evidence_sources=['历史记载'],
            metadata={'outcome': '多个省份独立'}
        )
    }
    return events


def create_causal_relations() -> list:
    """创建测试因果关系"""
    relations = [
        CausalRelation(
            source_id='wuchang_uprising',
            target_id='intermediate_event',
            relation_type='direct_cause',
            confidence=0.85,
            evidence=['时间顺序', '历史记载', '学术研究'],
            reasoning_steps=['武昌起义爆发', '引发各省响应', '纷纷宣布独立'],
            metadata={'mechanism': '示范效应'}
        ),
        CausalRelation(
            source_id='intermediate_event',
            target_id='qing_dynasty_end',
            relation_type='contributing_factor',
            confidence=0.75,
            evidence=['历史记载', '政治分析'],
            reasoning_steps=['各省独立', '削弱清朝统治', '加速清帝退位'],
            metadata={'mechanism': '政治压力'}
        )
    ]
    return relations


def test_temporal_check():
    """测试时序检查"""
    print("\n" + "=" * 60)
    print("测试 1：时序检查")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    events = create_test_events()
    
    # 测试正常时序（原因在前，结果在后）
    result = engine.infer_causality(events['wuchang_uprising'], events['qing_dynasty_end'])
    confidence = engine.get_causal_confidence(events['wuchang_uprising'], events['qing_dynasty_end'])
    print(f"✓ 武昌起义 → 清朝结束：{result} (置信度：{confidence:.2f})")
    
    # 时序检查应该通过（置信度应该高于 0.5）
    assert confidence > 0.5, f"时序检查应该通过，置信度应该>0.5，实际{confidence:.2f}"
    
    # 测试反向时序（结果在前，原因在后）
    result_reverse = engine.infer_causality(events['qing_dynasty_end'], events['wuchang_uprising'])
    confidence_reverse = engine.get_causal_confidence(events['qing_dynasty_end'], events['wuchang_uprising'])
    print(f"✓ 清朝结束 → 武昌起义：{result_reverse} (置信度：{confidence_reverse:.2f})")
    
    # 反向时序应该不通过（置信度应该很低）
    assert confidence_reverse < 0.3, f"反向时序应该不通过，置信度应该<0.3，实际{confidence_reverse:.2f}"
    
    print("✓ 时序检查测试通过")
    return True


def test_confidence_calculation():
    """测试置信度计算"""
    print("\n" + "=" * 60)
    print("测试 2：置信度计算")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    events = create_test_events()
    
    # 获取置信度
    confidence = engine.get_causal_confidence(
        events['wuchang_uprising'],
        events['qing_dynasty_end']
    )
    
    print(f"✓ 武昌起义 → 清朝结束 置信度：{confidence:.2f}")
    assert 0.0 <= confidence <= 1.0, "置信度应该在 0-1 之间"
    
    # 置信度应该合理（对于历史事件，0.7 以上就算高）
    assert confidence >= 0.6, \
        f"置信度 {confidence:.2f} 应该>=0.6（历史事件的合理阈值）"
    
    print("✓ 置信度计算测试通过")
    return True


def test_reasoning_chain():
    """测试推理链生成"""
    print("\n" + "=" * 60)
    print("测试 3：推理链生成")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    events = create_test_events()
    
    # 获取因果解释
    explanation = engine.explain_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end']
    )
    
    print(f"✓ 因果关系：{explanation['has_causality']}")
    print(f"✓ 关系类型：{explanation['relation_type']}")
    print(f"✓ 置信度：{explanation['confidence']:.2f}")
    print(f"✓ 推理链:")
    for step in explanation['reasoning_chain']:
        print(f"  {step}")
    
    # 验证推理链完整性
    assert len(explanation['reasoning_chain']) > 0, "推理链不应为空"
    assert len(explanation['checks']) > 0, "检查步骤不应为空"
    
    # 验证至少包含时序检查
    check_types = [check['type'] for check in explanation['checks']]
    assert 'temporal' in check_types, "应该包含时序检查"
    
    print("✓ 推理链生成测试通过")
    return True


def test_cache_mechanism():
    """测试缓存机制"""
    print("\n" + "=" * 60)
    print("测试 4：缓存机制")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    events = create_test_events()
    
    # 第一次推断（未缓存）
    result1 = engine.infer_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end'],
        use_cache=True
    )
    
    stats1 = engine.get_stats()
    print(f"✓ 第一次推断：inference_count={stats1['inference_count']}, cache_hits={stats1['cache_hits']}")
    
    # 第二次推断（使用缓存）
    result2 = engine.infer_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end'],
        use_cache=True
    )
    
    stats2 = engine.get_stats()
    print(f"✓ 第二次推断：inference_count={stats2['inference_count']}, cache_hits={stats2['cache_hits']}")
    
    # 验证缓存命中
    assert stats2['cache_hits'] > stats1['cache_hits'], "第二次应该命中缓存"
    assert result1 == result2, "缓存结果应该一致"
    
    # 测试清除缓存
    engine.clear_cache()
    stats3 = engine.get_stats()
    print(f"✓ 清除缓存后：cache_size={stats3['cache_size']}")
    assert stats3['cache_size'] == 0, "缓存应该被清空"
    
    print("✓ 缓存机制测试通过")
    return True


def test_methodology_integration():
    """测试方法论组件集成"""
    print("\n" + "=" * 60)
    print("测试 5：方法论组件集成")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    # 创建方法论组件
    lancet = LancetMethod(config.layer)
    workflow = IterativeWorkflow(engine, lancet)
    
    # 设置方法论
    engine.set_methodology(lancet, workflow)
    
    events = create_test_events()
    
    # 测试带方法论的因果推断
    result = engine.infer_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end']
    )
    
    explanation = engine.explain_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end']
    )
    
    print(f"✓ 带方法论的因果推断：{result}")
    print(f"✓ 关系类型：{explanation['relation_type']}")
    
    # 验证机制检查是否执行
    check_types = [check['type'] for check in explanation['checks']]
    assert 'mechanism' in check_types, "应该包含机制检查"
    
    print("✓ 方法论组件集成测试通过")
    return True


def test_alternative_explanations():
    """测试替代解释生成"""
    print("\n" + "=" * 60)
    print("测试 6：替代解释生成")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    events = create_test_events()
    
    # 获取替代解释
    explanation = engine.explain_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end']
    )
    
    print(f"✓ 替代解释:")
    for alt in explanation['alternative_explanations']:
        print(f"  - {alt}")
    
    print(f"✓ 改进建议:")
    for suggestion in explanation['suggestions']:
        print(f"  - {suggestion}")
    
    # 验证替代解释和建议生成
    assert isinstance(explanation['alternative_explanations'], list), \
        "替代解释应该是列表"
    assert isinstance(explanation['suggestions'], list), \
        "建议应该是列表"
    
    print("✓ 替代解释生成测试通过")
    return True


def test_evidence_sources():
    """测试证据来源收集"""
    print("\n" + "=" * 60)
    print("测试 7：证据来源收集")
    print("=" * 60)
    
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    
    events = create_test_events()
    
    # 获取证据来源
    explanation = engine.explain_causality(
        events['wuchang_uprising'],
        events['qing_dynasty_end']
    )
    
    print(f"✓ 证据来源:")
    for source in explanation['evidence_sources']:
        print(f"  - {source}")
    
    # 验证证据来源收集
    assert len(explanation['evidence_sources']) > 0, \
        "应该有证据来源"
    
    print("✓ 证据来源收集测试通过")
    return True


def main():
    """主测试函数"""
    print("\n" + "=" * 60)
    print("CausalEngine 核心功能测试")
    print("=" * 60)
    
    tests = [
        ("时序检查", test_temporal_check),
        ("置信度计算", test_confidence_calculation),
        ("推理链生成", test_reasoning_chain),
        ("缓存机制", test_cache_mechanism),
        ("方法论集成", test_methodology_integration),
        ("替代解释", test_alternative_explanations),
        ("证据来源", test_evidence_sources)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            print(f"\n运行测试：{test_name}")
            if test_func():
                passed += 1
                print(f"✓ {test_name} 测试通过")
        except AssertionError as e:
            failed += 1
            print(f"✗ {test_name} 测试失败：{e}")
        except Exception as e:
            failed += 1
            print(f"✗ {test_name} 测试异常：{e}")
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
