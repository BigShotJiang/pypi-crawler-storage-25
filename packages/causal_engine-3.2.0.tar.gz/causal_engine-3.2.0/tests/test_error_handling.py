"""
错误处理和日志系统测试
"""

import sys
import logging
from pathlib import Path

# 添加项目根目录到 Python 路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.utils.error_handling import (
    CausalArchitectureError,
    StorageError,
    StorageConnectionError,
    StorageQueryError,
    EngineError,
    EventNotFoundError,
    CausalInferenceError,
    MethodError,
    TaskDecompositionError,
    IntegrationError,
    ConfigError,
    ConfigNotFoundError,
    log_errors,
    error_context,
    timed_operation,
    setup_logging
)


def test_error_hierarchy():
    """测试错误层次结构"""
    print("\n" + "=" * 60)
    print("测试 1：错误层次结构")
    print("=" * 60)
    
    # 测试基础错误
    base_error = CausalArchitectureError("基础错误")
    assert isinstance(base_error, Exception)
    print(f"✓ CausalArchitectureError 是 Exception 的子类")
    
    # 测试存储错误
    storage_error = StorageError("存储错误")
    assert isinstance(storage_error, CausalArchitectureError)
    print(f"✓ StorageError 是 CausalArchitectureError 的子类")
    
    # 测试引擎错误
    engine_error = EngineError("引擎错误")
    assert isinstance(engine_error, CausalArchitectureError)
    print(f"✓ EngineError 是 CausalArchitectureError 的子类")
    
    # 测试事件未找到错误
    event_error = EventNotFoundError("event_123", {'context': 'test'})
    assert isinstance(event_error, EngineError)
    assert 'event_123' in str(event_error)
    assert event_error.context['event_id'] == 'event_123'
    print(f"✓ EventNotFoundError 包含事件 ID 和上下文")
    
    # 测试方法错误
    method_error = MethodError("方法错误")
    assert isinstance(method_error, CausalArchitectureError)
    print(f"✓ MethodError 是 CausalArchitectureError 的子类")
    
    # 测试集成错误
    integration_error = IntegrationError("集成错误")
    assert isinstance(integration_error, CausalArchitectureError)
    print(f"✓ IntegrationError 是 CausalArchitectureError 的子类")
    
    # 测试配置错误
    config_error = ConfigError("配置错误")
    assert isinstance(config_error, CausalArchitectureError)
    print(f"✓ ConfigError 是 CausalArchitectureError 的子类")
    
    print("✓ 错误层次结构测试通过")
    return True


def test_error_to_dict():
    """测试错误转换为字典"""
    print("\n" + "=" * 60)
    print("测试 2：错误转换为字典")
    print("=" * 60)
    
    error = EventNotFoundError("event_123", {'user': 'test', 'action': 'query'})
    error_dict = error.to_dict()
    
    assert 'error_type' in error_dict
    assert error_dict['error_type'] == 'EventNotFoundError'
    print(f"✓ 错误类型：{error_dict['error_type']}")
    
    assert 'message' in error_dict
    assert 'event_123' in error_dict['message']
    print(f"✓ 错误消息：{error_dict['message']}")
    
    assert 'context' in error_dict
    assert error_dict['context']['user'] == 'test'
    print(f"✓ 错误上下文：{error_dict['context']}")
    
    assert 'timestamp' in error_dict
    print(f"✓ 错误时间戳：{error_dict['timestamp']}")
    
    print("✓ 错误转换为字典测试通过")
    return True


def test_log_errors_decorator():
    """测试错误日志装饰器"""
    print("\n" + "=" * 60)
    print("测试 3：错误日志装饰器")
    print("=" * 60)
    
    # 设置测试日志
    logger = setup_logging(log_level='DEBUG', enable_file_logging=False)
    
    @log_errors(logger=logger)
    def successful_function(x, y):
        return x + y
    
    @log_errors(logger=logger)
    def failing_function():
        raise ValueError("测试错误")
    
    # 测试成功执行
    result = successful_function(2, 3)
    assert result == 5
    print(f"✓ 装饰器处理成功函数：2 + 3 = {result}")
    
    # 测试失败执行
    try:
        failing_function()
        assert False, "应该抛出错误"
    except CausalArchitectureError as e:
        print(f"✓ 装饰器捕获异常：{e.message}")
    
    print("✓ 错误日志装饰器测试通过")
    return True


def test_error_context_manager():
    """测试错误上下文管理器"""
    print("\n" + "=" * 60)
    print("测试 4：错误上下文管理器")
    print("=" * 60)
    
    logger = setup_logging(log_level='DEBUG', enable_file_logging=False)
    
    # 测试成功执行
    with error_context("成功操作", logger=logger) as ctx:
        result = 10 / 2
        print(f"✓ 上下文管理器处理成功操作：10 / 2 = {result}")
    
    # 测试失败执行
    try:
        with error_context("失败操作", logger=logger, raise_on_error=True) as ctx:
            result = 10 / 0
    except Exception as e:
        print(f"✓ 上下文管理器捕获异常：{type(e).__name__}")
    
    print("✓ 错误上下文管理器测试通过")
    return True


def test_timed_operation():
    """测试性能监控装饰器"""
    print("\n" + "=" * 60)
    print("测试 5：性能监控装饰器")
    print("=" * 60)
    
    logger = setup_logging(log_level='DEBUG', enable_file_logging=False)
    
    @timed_operation(logger=logger, log_level='DEBUG')
    def fast_function():
        return sum(range(100))
    
    @timed_operation(logger=logger, log_level='INFO')
    def slow_function():
        import time
        time.sleep(0.1)
        return sum(range(1000))
    
    # 测试快速函数
    result1 = fast_function()
    print(f"✓ 快速函数执行完成：sum(range(100)) = {result1}")
    
    # 测试慢速函数
    result2 = slow_function()
    print(f"✓ 慢速函数执行完成：sum(range(1000)) = {result2}")
    
    print("✓ 性能监控装饰器测试通过")
    return True


def test_logging_setup():
    """测试日志系统设置"""
    print("\n" + "=" * 60)
    print("测试 6：日志系统设置")
    print("=" * 60)
    
    # 测试基本日志设置
    logger = setup_logging(log_level='DEBUG', enable_file_logging=False)
    assert logger is not None
    print(f"✓ 日志系统设置成功")
    
    # 测试日志级别
    assert logger.level == logging.DEBUG
    print(f"✓ 日志级别正确：DEBUG")
    
    # 测试日志输出
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    print(f"✓ 各级别日志输出正常")
    
    print("✓ 日志系统设置测试通过")
    return True


def test_specific_error_types():
    """测试特定错误类型"""
    print("\n" + "=" * 60)
    print("测试 7：特定错误类型")
    print("=" * 60)
    
    # 测试存储连接错误
    try:
        raise StorageConnectionError("无法连接到数据库", {'host': 'localhost', 'port': 5432})
    except StorageConnectionError as e:
        print(f"✓ 存储连接错误：{e.message}")
        assert e.context['host'] == 'localhost'
    
    # 测试存储查询错误
    try:
        raise StorageQueryError("SQL 查询失败", {'query': 'SELECT * FROM events'})
    except StorageQueryError as e:
        print(f"✓ 存储查询错误：{e.message}")
    
    # 测试因果推断错误
    try:
        raise CausalInferenceError("因果推断失败", {'event_a': 'A', 'event_b': 'B'})
    except CausalInferenceError as e:
        print(f"✓ 因果推断错误：{e.message}")
    
    # 测试任务分解错误
    try:
        raise TaskDecompositionError("任务分解失败", {'task': 'complex_task'})
    except TaskDecompositionError as e:
        print(f"✓ 任务分解错误：{e.message}")
    
    # 测试配置未找到错误
    try:
        raise ConfigNotFoundError("/path/to/config.yaml")
    except ConfigNotFoundError as e:
        print(f"✓ 配置未找到错误：{e.message}")
        assert '/path/to/config.yaml' in e.message
    
    print("✓ 特定错误类型测试通过")
    return True


def main():
    """运行所有测试"""
    print("=" * 60)
    print("错误处理和日志系统测试")
    print("=" * 60)
    
    tests = [
        ("错误层次结构", test_error_hierarchy),
        ("错误转换为字典", test_error_to_dict),
        ("错误日志装饰器", test_log_errors_decorator),
        ("错误上下文管理器", test_error_context_manager),
        ("性能监控装饰器", test_timed_operation),
        ("日志系统设置", test_logging_setup),
        ("特定错误类型", test_specific_error_types),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            print(f"\n运行测试：{test_name}")
            if test_func():
                passed += 1
                print(f"✓ {test_name} 测试通过")
        except Exception as e:
            failed += 1
            print(f"✗ {test_name} 测试失败：{e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
