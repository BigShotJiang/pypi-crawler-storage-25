"""
方法论组件测试

测试重点：
1. LancetMethod 的任务分解能力
2. 方案选择和分层调用逻辑
3. IterativeWorkflow 的迭代优化流程
4. 质量评估和成本控制
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from generic_causal_architecture.methods import LancetMethod, IterativeWorkflow
from generic_causal_architecture.config import Config
from generic_causal_architecture.storage import MemoryStorage
from generic_causal_architecture.core import CausalEngine


def test_task_decomposition():
    """测试任务分解能力"""
    print("\n" + "=" * 60)
    print("测试 1：任务分解能力")
    print("=" * 60)
    
    config = Config()
    lancet = LancetMethod(config.layer)
    
    # 测试因果推断任务分解
    causal_task = {
        'type': 'causal_inference',
        'id': 'test_causal_001',
        'description': '分析武昌起义和清朝结束的因果关系',
        'sample_size': 100
    }
    
    subtasks = lancet.decompose_task(causal_task)
    
    print(f"✓ 因果推断任务分解为 {len(subtasks)} 个子任务:")
    for i, subtask in enumerate(subtasks, 1):
        print(f"  {i}. {subtask.task_type}: {subtask.description}")
    
    # 验证分解结果
    assert len(subtasks) >= 5, "因果推断任务应该分解为至少 5 个子任务"
    
    # 验证包含关键步骤
    task_types = [st.task_type for st in subtasks]
    assert 'temporal_analysis' in task_types, "应该包含时序分析"
    assert 'synthesis' in task_types, "应该包含综合判断"
    
    print("✓ 任务分解测试通过")
    return True


def test_solution_selection():
    """测试方案选择逻辑"""
    print("\n" + "=" * 60)
    print("测试 2：方案选择逻辑")
    print("=" * 60)
    
    config = Config()
    lancet = LancetMethod(config.layer)
    
    from generic_causal_architecture.methods.lancet_method import TaskFeatures
    
    # 测试场景 1：高确定性任务 → 应该选择规则
    features1 = TaskFeatures(
        deterministic=0.95,
        semantic_depth=1,
        precision_required=0.9
    )
    
    solution1, layer1 = lancet.select_solution(features1)
    print(f"✓ 高确定性任务：{solution1.value}, {layer1.value}")
    assert layer1.value == 'l1_rule', "高确定性任务应该选择 L1 规则引擎"
    
    # 测试场景 2：高语义深度 + 小样本 → 应该选择 LLM
    features2 = TaskFeatures(
        deterministic=0.3,
        semantic_depth=5,
        samples=20,
        context_length=3000
    )
    
    solution2, layer2 = lancet.select_solution(features2)
    print(f"✓ 高语义深度任务：{solution2.value}, {layer2.value}")
    
    # 测试场景 3：需要可解释性 → 应该选择混合方案
    features3 = TaskFeatures(
        deterministic=0.6,
        semantic_depth=3,
        explainability_required=True,
        precision_required=0.85
    )
    
    solution3, layer3 = lancet.select_solution(features3)
    print(f"✓ 需要可解释性：{solution3.value}, {layer3.value}")
    from generic_causal_architecture.methods.lancet_method import SolutionType
    assert solution3 == SolutionType.HYBRID, "需要可解释性应该选择混合方案"
    
    print("✓ 方案选择测试通过")
    return True


def test_layer_execution():
    """测试分层执行"""
    print("\n" + "=" * 60)
    print("测试 3：分层执行")
    print("=" * 60)
    
    config = Config()
    lancet = LancetMethod(config.layer)
    
    from generic_causal_architecture.methods.lancet_method import SubTask, TaskFeatures, LayerLevel
    
    # 创建 L1 测试任务
    l1_task = SubTask(
        task_id='test_l1',
        task_type='temporal_analysis',
        description='时序分析测试',
        features=TaskFeatures(deterministic=0.95),
        layer_level=LayerLevel.L1_RULE
    )
    
    context = {
        'cause_event': {'timestamp': 1911},
        'effect_event': {'timestamp': 1912},
        'max_interval_years': 100
    }
    
    result = lancet.execute_subtask(l1_task, context)
    
    print(f"✓ L1 执行结果：success={result.success}, quality={result.quality_score:.2f}, cost=${result.cost:.4f}")
    assert result.success, "L1 执行应该成功"
    assert result.cost == 0.0, "L1 规则执行应该几乎免费"
    
    # 创建 L2 测试任务
    l2_task = SubTask(
        task_id='test_l2',
        task_type='similarity',
        description='相似度计算测试',
        features=TaskFeatures(deterministic=0.8),
        layer_level=LayerLevel.L2_STATISTICAL
    )
    
    context2 = {
        'text1': '武昌起义爆发',
        'text2': '辛亥革命开始'
    }
    
    result2 = lancet.execute_subtask(l2_task, context2)
    
    print(f"✓ L2 执行结果：success={result2.success}, quality={result2.quality_score:.2f}, cost=${result2.cost:.4f}")
    assert result2.success, "L2 执行应该成功"
    assert result2.cost < 0.01, "L2 统计方法成本应该很低"
    
    print("✓ 分层执行测试通过")
    return True


def test_cost_tracking():
    """测试成本追踪"""
    print("\n" + "=" * 60)
    print("测试 4：成本追踪")
    print("=" * 60)
    
    config = Config()
    lancet = LancetMethod(config.layer)
    
    # 模拟 L4 调用（更新成本）
    lancet._update_cost(0.05)
    lancet._update_cost(0.03)
    
    print(f"✓ 累计成本：${lancet._daily_cost:.2f}")
    print(f"✓ 请求次数：{lancet._request_count}")
    
    assert lancet._daily_cost == 0.08, "累计成本应该是 0.08"
    assert lancet._request_count == 2, "请求次数应该是 2"
    
    # 测试预算检查
    assert lancet._check_llm_budget(), "预算内应该允许 LLM 调用"
    
    print("✓ 成本追踪测试通过")
    return True


def test_iterative_workflow():
    """测试迭代工作流"""
    print("\n" + "=" * 60)
    print("测试 5：迭代工作流")
    print("=" * 60)
    
    # 创建完整的工作流
    storage = MemoryStorage()
    storage.initialize()
    
    config = Config()
    engine = CausalEngine(storage, config.causal)
    lancet = LancetMethod(config.layer)
    workflow = IterativeWorkflow(engine, lancet)
    
    # 创建测试数据
    test_events = [
        {'id': 'event1', 'name': '事件 1', 'timestamp': 1911},
        {'id': 'event2', 'name': '事件 2', 'timestamp': 1912},
        {'id': 'event3', 'name': '事件 3', 'timestamp': 1913}
    ]
    
    # 执行第一轮迭代
    result1 = workflow.run_iteration(
        data=test_events,
        current_version=1,
        target_quality=0.9
    )
    
    print(f"✓ 第一轮迭代：")
    print(f"  - 版本：{result1.version}")
    print(f"  - 成功：{result1.success}")
    print(f"  - 整体质量：{result1.metrics.overall_quality:.2f}")
    print(f"  - 总成本：${result1.metrics.total_cost:.2f}")
    print(f"  - 发现问题：{result1.metrics.issues_identified}")
    print(f"  - 应用改进：{result1.metrics.improvements_applied}")
    
    # 验证迭代结果
    assert result1.version == 1, "版本号应该是 1"
    assert isinstance(result1.metrics.overall_quality, float), "质量应该是浮点数"
    assert 0.0 <= result1.metrics.overall_quality <= 1.0, "质量应该在 0-1 之间"
    
    # 验证问题和改进
    print(f"✓ 识别到的问题:")
    for issue in result1.issues:
        print(f"  - {issue.issue_type.value}: {issue.description}")
    
    print(f"✓ 应用的改进:")
    for improvement in result1.improvements:
        print(f"  - {improvement.improvement_type.value}: {improvement.description}")
    
    print(f"✓ 下一步建议:")
    for step in result1.next_steps:
        print(f"  - {step}")
    
    print("✓ 迭代工作流测试通过")
    return True


def test_quality_evaluation():
    """测试质量评估"""
    print("\n" + "=" * 60)
    print("测试 6：质量评估")
    print("=" * 60)
    
    config = Config()
    lancet = LancetMethod(config.layer)
    
    from generic_causal_architecture.methods.lancet_method import SubTask, TaskFeatures
    
    # 创建测试子任务
    test_task = SubTask(
        task_id='test_quality',
        task_type='temporal_analysis',
        description='质量评估测试',
        features=TaskFeatures(precision_required=0.9)
    )
    
    # 测试不同结果的质量评分
    result_good = {'valid': True, 'confidence': 0.9}
    quality_good = lancet._evaluate_result(test_task, result_good)
    
    result_bad = None
    quality_bad = lancet._evaluate_result(test_task, result_bad)
    
    print(f"✓ 好结果质量：{quality_good:.2f}")
    print(f"✓ 坏结果质量：{quality_bad:.2f}")
    
    assert quality_good > quality_bad, "好结果的质量应该高于坏结果"
    assert quality_good >= 0.7, "好结果的质量应该>=0.7"
    assert quality_bad == 0.0, "坏结果的质量应该是 0"
    
    print("✓ 质量评估测试通过")
    return True


def main():
    """主测试函数"""
    print("\n" + "=" * 60)
    print("方法论组件测试")
    print("=" * 60)
    
    tests = [
        ("任务分解", test_task_decomposition),
        ("方案选择", test_solution_selection),
        ("分层执行", test_layer_execution),
        ("成本追踪", test_cost_tracking),
        ("迭代工作流", test_iterative_workflow),
        ("质量评估", test_quality_evaluation)
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        try:
            print(f"\n运行测试：{test_name}")
            if test_func():
                passed += 1
                print(f"✓ {test_name} 测试通过")
        except AssertionError as e:
            failed += 1
            print(f"✗ {test_name} 测试失败：{e}")
        except Exception as e:
            failed += 1
            print(f"✗ {test_name} 测试异常：{e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "=" * 60)
    print(f"测试结果：{passed} 通过，{failed} 失败")
    print("=" * 60)
    
    return failed == 0


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
