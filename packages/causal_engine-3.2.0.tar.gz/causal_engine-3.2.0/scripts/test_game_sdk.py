"""
Game SDK integration test - validates all CausalGame methods work end-to-end.
"""
import asyncio
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from generic_causal_architecture.game import CausalGame


def _make_rule_pack(path):
    data = {
        "version": "1.0",
        "entities": [
            {"name": "high taxes", "type": "policy"},
            {"name": "public anger", "type": "emotion"},
            {"name": "rebellion", "type": "event"},
            {"name": "civil war", "type": "event"},
            {"name": "trade", "type": "activity"},
            {"name": "prosperity", "type": "state"},
            {"name": "tyranny", "type": "governance"},
            {"name": "reforms", "type": "policy"},
        ],
        "relations": [
            {"source": "high taxes", "target": "public anger", "relation_type": "causes", "confidence": 0.85},
            {"source": "public anger", "target": "rebellion", "relation_type": "causes", "confidence": 0.75},
            {"source": "rebellion", "target": "civil war", "relation_type": "causes", "confidence": 0.6},
            {"source": "trade", "target": "prosperity", "relation_type": "causes", "confidence": 0.8},
            {"source": "tyranny", "target": "rebellion", "relation_type": "causes", "confidence": 0.9},
            {"source": "reforms", "target": "prosperity", "relation_type": "enables", "confidence": 0.7},
        ],
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return path


def test_init_and_stats():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)
        stats = game.stats()
        assert stats["entity_count"] == 8, f"Expected 8 entities, got {stats['entity_count']}"
        assert stats["relation_count"] == 6, f"Expected 6 relations, got {stats['relation_count']}"
        print("PASS: init_and_stats")
    finally:
        os.unlink(path)


def test_decide():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        result = game.decide("player", "raise taxes", [
            ("high taxes", "public anger", "causes", 0.85),
        ])

        assert result.actor == "player"
        assert result.action == "raise taxes"
        assert len(result.immediate) > 0, "Should have immediate effects"
        assert "high taxes" in result.entities_affected
        assert "public anger" in result.entities_affected
        print(f"  immediate effects: {result.immediate}")
        print(f"  chains: {len(result.chains)}")
        print("PASS: decide")
    finally:
        os.unlink(path)


def test_check():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        rel = game.check("tyranny", "rebellion", "causes")
        assert rel.found, "Should find tyranny -> rebellion"
        assert rel.strength == 0.9, f"Expected 0.9, got {rel.strength}"

        rel2 = game.check("peace", "war", "causes")
        assert not rel2.found, "Should not find peace -> war"
        print("PASS: check")
    finally:
        os.unlink(path)


def test_search():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        results = game.search("rebellion")
        assert len(results) > 0, "Should find rebellion-related rules"
        print(f"  found {len(results)} results for 'rebellion'")
        print("PASS: search")
    finally:
        os.unlink(path)


def test_save_and_load():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        game.decide("player", "new policy", [
            ("new policy", "social change", "causes", 0.6),
        ])

        save_path = path + ".save.json"
        game.save(save_path)

        loaded = CausalGame.load(save_path)
        stats = loaded.stats()
        assert stats["entity_count"] >= 8, f"Loaded game should have entities, got {stats['entity_count']}"
        print(f"  loaded: {stats['entity_count']} entities, {stats['relation_count']} relations")
        print("PASS: save_and_load")
        os.unlink(save_path)
    finally:
        os.unlink(path)


def test_feedback():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        result = game.feedback("high taxes", "public anger", "anger", "anger", True)
        assert "status" in result or "message" in result, f"Feedback should return a result, got {result}"
        print(f"  feedback result: {result}")
        print("PASS: feedback")
    finally:
        os.unlink(path)


def test_validate_rule():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        result = game.validate_rule("peace", "happiness", "causes", 0.8)
        assert "is_valid" in result, f"Should have is_valid field, got {result}"
        print(f"  validation: {result}")
        print("PASS: validate_rule")
    finally:
        os.unlink(path)


def test_adjust_confidence():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        ok = game.adjust_confidence("trade", "prosperity", "causes", 0.05)
        assert ok, "Should successfully adjust confidence"

        rel = game.check("trade", "prosperity", "causes")
        assert rel.strength > 0.8, f"Strength should be > 0.8 after boost, got {rel.strength}"
        print(f"  adjusted strength: {rel.strength}")
        print("PASS: adjust_confidence")
    finally:
        os.unlink(path)


def test_consequences():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        chains = game.consequences("public anger")
        print(f"  consequence chains from 'public anger': {len(chains)}")
        for c in chains:
            print(f"    steps: {c.get('steps', [])}")
        print("PASS: consequences")
    finally:
        os.unlink(path)


def test_trace():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        forward = game.trace("high taxes", "forward")
        print(f"  forward chains from 'high taxes': {len(forward)}")

        backward = game.trace("civil war", "backward")
        print(f"  backward chains to 'civil war': {len(backward)}")
        print("PASS: trace")
    finally:
        os.unlink(path)


def test_predict():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        preview = game.predict("provoke rebellion", [
            ("public anger", "rebellion", "causes", 0.7),
        ])
        print(f"  predicted chains: {len(preview)}")
        print("PASS: predict")
    finally:
        os.unlink(path)


def test_is_cause():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        result = game.is_cause("high taxes", "public anger")
        assert "is_cause" in result
        assert "certainty" in result
        assert "checks" in result
        assert "reasoning" in result
        assert isinstance(result["checks"], list)
        print(f"  is_cause: {result['is_cause']}, certainty: {result['certainty']}")
        print(f"  checks: {len(result['checks'])}, reasoning: {len(result['reasoning'])}")
        print("PASS: is_cause")
    finally:
        os.unlink(path)


def test_why():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        result = game.why("tyranny", "rebellion")
        assert "cause" in result
        assert "narrative" in result
        assert "certainty" in result
        assert "reasoning" in result
        assert isinstance(result["narrative"], str)
        print(f"  narrative: {result['narrative']}")
        print("PASS: why")
    finally:
        os.unlink(path)


def test_certainty_of():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        c = game.certainty_of("high taxes", "public anger")
        assert isinstance(c, float)
        assert c >= 0.0 and c <= 1.0
        print(f"  certainty_of('high taxes', 'public anger'): {c}")

        c2 = game.certainty_of("peace", "nothing")
        assert isinstance(c2, float)
        print(f"  certainty_of('peace', 'nothing'): {c2}")
        print("PASS: certainty_of")
    finally:
        os.unlink(path)


def test_network():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        graph = game.network(["tyranny", "trade"])
        assert isinstance(graph, dict)
        print(f"  filtered network: {list(graph.keys())}")

        full = game.network()
        assert isinstance(full, dict)
        assert len(full) > 0
        for entity, links in full.items():
            for link in links:
                assert "target" in link
                assert "strength" in link
        print(f"  full network: {len(full)} source entities")
        print("PASS: network")
    finally:
        os.unlink(path)


def test_discover_hidden():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        result = game.discover_hidden(min_strength=0.3)
        assert isinstance(result, list)
        print(f"  discovered {len(result)} hidden relations")
        for h in result[:3]:
            print(f"    {h['source']} -> {h['target']} ({h['likelihood']})")
        print("PASS: discover_hidden")
    finally:
        os.unlink(path)


def test_engine_and_storage_access():
    with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
        path = f.name
    try:
        _make_rule_pack(path)
        game = CausalGame(path)

        assert game.engine is not None
        assert game.storage is not None
        print("PASS: engine_and_storage_access")
    finally:
        os.unlink(path)


if __name__ == "__main__":
    tests = [
        test_init_and_stats,
        test_decide,
        test_check,
        test_search,
        test_save_and_load,
        test_feedback,
        test_validate_rule,
        test_adjust_confidence,
        test_consequences,
        test_trace,
        test_predict,
        test_is_cause,
        test_why,
        test_certainty_of,
        test_network,
        test_discover_hidden,
        test_engine_and_storage_access,
    ]

    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__}: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n{'='*40}")
    print(f"Results: {passed} passed, {failed} failed out of {len(tests)}")
    if failed == 0:
        print("ALL TESTS PASSED!")
