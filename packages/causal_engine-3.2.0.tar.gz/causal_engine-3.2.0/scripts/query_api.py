"""
因果知识查询 API - 轻量版

直接查询 PostgreSQL，验证数据价值。
不依赖 Config/CausalEngine/LLM 等重型组件。

启动：
    cd t:\Item\AI\discuss\sources\generic-causal-architecture
    python scripts/query_api.py

访问：
    http://localhost:8080/
"""

import sys
import json
import time
import logging
import os
from pathlib import Path
from typing import Optional

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from fastapi import FastAPI, Query
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel
import uvicorn
import httpx

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = os.environ.get("DATABASE_URL", "postgresql://postgres:causal_password@localhost:5432/causal_db")
SILICONFLOW_KEY = os.environ.get("SILICONFLOW_KEY", "")
EMBEDDING_URL = os.environ.get("EMBEDDING_URL", "https://api.siliconflow.cn/v1/embeddings")
EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-large-zh-v1.5")
API_PORT = int(os.environ.get("API_PORT", "8080"))

logger = logging.getLogger(__name__)

app = FastAPI(title="Causal Inference Engine API", version="3.0.0")
storage: Optional[PostgreSQLStorage] = None


@app.on_event("startup")
async def startup():
    global storage
    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()
    print(f"API started: http://0.0.0.0:{API_PORT}/")


# ============ 数据接口 ============

class SearchResult(BaseModel):
    results: list
    total: int
    query: str
    elapsed_ms: float


@app.get("/api/search")
async def search_knowledge(q: str = Query(..., min_length=1), limit: int = 20):
    t0 = time.time()
    rows = storage._execute_sql("""
        SELECT id, name, knowledge_json->>'content' as content,
               knowledge_json->>'knowledge_type' as ktype,
               knowledge_json->>'confidence' as confidence,
               knowledge_json->'sources'->0->>'title' as source_title,
               knowledge_json->'sources'->0->'extra_info'->>'dynasty' as dynasty,
               knowledge_json->'perspective'->>'tradition' as tradition,
               knowledge_json->'perspective'->>'reliability' as reliability,
               jsonb_array_length(knowledge_json->'relations') as rel_count
        FROM knowledge
        WHERE name ILIKE :q1 OR knowledge_json->>'content' ILIKE :q2
        ORDER BY rel_count DESC NULLS LAST
        LIMIT :lim
    """, {"q1": f"%{q}%", "q2": f"%{q}%", "lim": limit})

    total = storage._execute_sql("""
        SELECT COUNT(*) as cnt FROM knowledge
        WHERE name ILIKE :q1 OR knowledge_json->>'content' ILIKE :q2
    """, {"q1": f"%{q}%", "q2": f"%{q}%"})

    elapsed = (time.time() - t0) * 1000
    return {"results": rows, "total": total[0]["cnt"], "query": q, "mode": "keyword", "elapsed_ms": round(elapsed, 1)}


@app.get("/api/semantic_search")
async def semantic_search(q: str = Query(..., min_length=1), limit: int = 20):
    t0 = time.time()
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                EMBEDDING_URL,
                headers={"Authorization": f"Bearer {SILICONFLOW_KEY}"},
                json={"model": EMBEDDING_MODEL, "input": [q]},
            )
        if resp.status_code != 200:
            return JSONResponse({"error": f"Embedding API error: {resp.status_code}"}, status_code=502)
        emb = resp.json()["data"][0]["embedding"]
        emb_str = "[" + ",".join(str(v) for v in emb) + "]"
    except Exception as e:
        return JSONResponse({"error": f"Embedding failed: {str(e)}"}, status_code=502)

    rows = storage._execute_sql(f"""
        SELECT id, name, knowledge_json->>'content' as content,
               knowledge_json->>'knowledge_type' as ktype,
               knowledge_json->>'confidence' as confidence,
               knowledge_json->'sources'->0->>'title' as source_title,
               knowledge_json->'sources'->0->'extra_info'->>'dynasty' as dynasty,
               knowledge_json->'perspective'->>'tradition' as tradition,
               knowledge_json->'perspective'->>'reliability' as reliability,
               1 - (embedding <=> CAST(:emb AS vector)) as similarity
        FROM knowledge
        ORDER BY embedding <=> CAST(:emb AS vector)
        LIMIT :lim
    """, {"emb": emb_str, "lim": limit})

    elapsed = (time.time() - t0) * 1000
    return {"results": rows, "total": len(rows), "query": q, "mode": "semantic", "elapsed_ms": round(elapsed, 1)}


@app.get("/api/knowledge/{knowledge_id}")
async def get_knowledge_detail(knowledge_id: str):
    rows = storage._execute_sql("""
        SELECT knowledge_json FROM knowledge WHERE id = :kid
    """, {"kid": knowledge_id})
    if not rows:
        return JSONResponse({"error": "not found"}, status_code=404)
    return rows[0]["knowledge_json"]


@app.get("/api/causal_chain/{knowledge_id}")
async def get_causal_chain(knowledge_id: str, depth: int = Query(default=2, ge=1, le=4)):
    t0 = time.time()

    chain_nodes = {}
    chain_edges = []
    visited = set()
    frontier = {knowledge_id}

    for step in range(depth):
        if not frontier:
            break
        next_frontier = set()

        ids_str = ",".join(f"'{fid}'" for fid in frontier)
        rows = storage._execute_sql(f"""
            SELECT k.id, k.name, k.knowledge_json->>'content' as content,
                   k.knowledge_json->>'knowledge_type' as ktype,
                   k.knowledge_json->>'confidence' as confidence,
                   k.knowledge_json->'sources'->0->>'title' as source_title
            FROM knowledge k WHERE k.id IN ({ids_str})
        """)

        for r in rows:
            if r["id"] not in visited:
                chain_nodes[r["id"]] = {
                    "id": r["id"],
                    "name": r["name"],
                    "content": (r["content"] or "")[:200],
                    "type": r["ktype"],
                    "confidence": r["confidence"],
                    "source": r["source_title"],
                }
                visited.add(r["id"])

        rels = storage._execute_sql(f"""
            SELECT r.source_id, r.target_id, r.relation_type, r.confidence,
                   r.metadata_json->>'description' as description
            FROM relations r
            WHERE r.source_id IN ({ids_str}) OR r.target_id IN ({ids_str})
        """)

        for rel in rels:
            chain_edges.append({
                "source": rel["source_id"],
                "target": rel["target_id"],
                "type": rel["relation_type"],
                "confidence": rel["confidence"],
                "description": (rel["description"] or "")[:200],
            })
            for fid in [rel["source_id"], rel["target_id"]]:
                if fid not in visited:
                    next_frontier.add(fid)

        frontier = next_frontier

    for fid in frontier:
        if fid not in chain_nodes:
            r = storage._execute_sql(
                "SELECT id, name, knowledge_json->>'content' as content, knowledge_json->>'knowledge_type' as ktype FROM knowledge WHERE id = :kid",
                {"kid": fid}
            )
            if r:
                chain_nodes[fid] = {
                    "id": r[0]["id"], "name": r[0]["name"],
                    "content": (r[0]["content"] or "")[:200], "type": r[0]["ktype"],
                }

    elapsed = (time.time() - t0) * 1000
    return {
        "center_id": knowledge_id,
        "depth": depth,
        "nodes": list(chain_nodes.values()),
        "edges": chain_edges,
        "elapsed_ms": round(elapsed, 1),
    }


@app.get("/api/random_chain")
async def random_chain(depth: int = 2):
    r = storage._execute_sql("""
        SELECT k.id FROM knowledge k
        JOIN relations r ON k.id = r.source_id
        ORDER BY RANDOM() LIMIT 1
    """)
    if not r:
        return JSONResponse({"error": "no connected knowledge found"}, status_code=404)
    return await get_causal_chain(r[0]["id"], depth)


# ============ 链式推理接口 ============

from generic_causal_architecture.core.causal_engine import CausalEngine

_engine: Optional[CausalEngine] = None


def _get_engine() -> Optional[CausalEngine]:
    global _engine
    if _engine is None:
        try:
            _engine = CausalEngine(storage=storage)
        except Exception as e:
            logger.error(f"Failed to init CausalEngine: {e}")
    return _engine


@app.get("/api/entity/search")
async def entity_search(q: str = Query(..., min_length=1), limit: int = 10):
    rows = storage._execute_sql("""
        SELECT id, canonical_name, traditions, sources,
               jsonb_array_length(sources) as src_count
        FROM public.unified_entities
        WHERE canonical_name ILIKE :q OR aliases ILIKE :q
        ORDER BY src_count DESC NULLS LAST
        LIMIT :lim
    """, {"q": f"%{q}%", "lim": limit})
    return {"results": rows, "total": len(rows), "query": q}


@app.get("/api/chain/forward")
async def chain_forward(entity: str = Query(...),
                        max_depth: int = Query(default=4, ge=1, le=6)):
    engine = _get_engine()
    if not engine or not engine.kg_reasoner:
        return JSONResponse({"error": "KG reasoner not available"}, status_code=503)
    t0 = time.time()
    chains = engine.kg_reasoner.trace_forward(entity, max_depth)
    elapsed = (time.time() - t0) * 1000
    return {
        "entity": entity,
        "direction": "forward",
        "chains_found": len(chains),
        "chains": [c.to_dict() for c in chains[:50]],
        "elapsed_ms": round(elapsed, 1),
    }


@app.get("/api/chain/backward")
async def chain_backward(entity: str = Query(...),
                         max_depth: int = Query(default=4, ge=1, le=6)):
    engine = _get_engine()
    if not engine or not engine.kg_reasoner:
        return JSONResponse({"error": "KG reasoner not available"}, status_code=503)
    t0 = time.time()
    chains = engine.kg_reasoner.trace_backward(entity, max_depth)
    elapsed = (time.time() - t0) * 1000
    return {
        "entity": entity,
        "direction": "backward",
        "chains_found": len(chains),
        "chains": [c.to_dict() for c in chains[:50]],
        "elapsed_ms": round(elapsed, 1),
    }


@app.get("/api/chain/between")
async def chain_between(source: str = Query(...), target: str = Query(...),
                        max_depth: int = Query(default=4, ge=1, le=6)):
    engine = _get_engine()
    if not engine or not engine.kg_reasoner:
        return JSONResponse({"error": "KG reasoner not available"}, status_code=503)
    t0 = time.time()
    chains = engine.kg_reasoner.trace_between(source, target, max_depth)
    elapsed = (time.time() - t0) * 1000
    return {
        "source": source, "target": target,
        "chains_found": len(chains),
        "chains": [c.to_dict() for c in chains[:20]],
        "elapsed_ms": round(elapsed, 1),
    }


@app.get("/api/discover")
async def discover_relations(min_confidence: float = Query(default=0.50, ge=0.1, le=1.0),
                             max_length: int = Query(default=3, ge=2, le=5),
                             persist: bool = Query(default=False)):
    engine = _get_engine()
    if not engine or not engine.kg_reasoner:
        return JSONResponse({"error": "KG reasoner not available"}, status_code=503)

    if persist:
        result = engine.persist_discoveries(min_confidence, max_length)
        return {"mode": "persisted", **result}
    else:
        relations = engine.discover_relations(min_confidence, max_length)
        return {
            "mode": "preview",
            "discovered": len(relations),
            "relations": relations[:100],
        }


# ============ 实体与 KG 接口 ============

@app.get("/api/entity/{entity_id}")
async def get_entity_detail(entity_id: str):
    row = storage._execute_sql("""
        SELECT id, canonical_name, aliases, traditions, sources,
               entity_type, description
        FROM public.unified_entities WHERE id = :eid
    """, {"eid": entity_id})
    if not row:
        return JSONResponse({"error": "entity not found"}, status_code=404)
    entity = row[0]

    fwd = storage._execute_sql("""
        SELECT r.target_entity_id, ue.canonical_name as target_name,
               r.relation_type, r.confidence, r.is_inferred
        FROM public.entity_relations r
        JOIN public.unified_entities ue ON r.target_entity_id = ue.id
        WHERE r.source_entity_id = :eid
        ORDER BY r.confidence DESC LIMIT 20
    """, {"eid": entity_id})

    bwd = storage._execute_sql("""
        SELECT r.source_entity_id, ue.canonical_name as source_name,
               r.relation_type, r.confidence, r.is_inferred
        FROM public.entity_relations r
        JOIN public.unified_entities ue ON r.source_entity_id = ue.id
        WHERE r.target_entity_id = :eid
        ORDER BY r.confidence DESC LIMIT 20
    """, {"eid": entity_id})

    related_knowledge = storage._execute_sql("""
        SELECT k.id, k.name, k.knowledge_json->>'content' as content,
               k.knowledge_json->>'knowledge_type' as ktype
        FROM knowledge k WHERE k.entity_id = :eid
        LIMIT 10
    """, {"eid": entity_id})

    return {
        **entity,
        "forward_relations": fwd,
        "backward_relations": bwd,
        "related_knowledge": related_knowledge,
        "forward_count": len(fwd),
        "backward_count": len(bwd),
    }


@app.get("/api/stats")
async def get_stats():
    total_k = storage._execute_sql("SELECT COUNT(*) as cnt FROM knowledge")
    total_r = storage._execute_sql("SELECT COUNT(*) as cnt FROM relations")
    types = storage._execute_sql("""
        SELECT knowledge_type, COUNT(*) as cnt FROM knowledge GROUP BY knowledge_type ORDER BY cnt DESC
    """)
    rel_types = storage._execute_sql("""
        SELECT relation_type, COUNT(*) as cnt FROM relations GROUP BY relation_type ORDER BY cnt DESC
    """)
    books = storage._execute_sql("""
        SELECT knowledge_json->'sources'->0->>'title' as title, COUNT(*) as cnt
        FROM knowledge
        WHERE jsonb_array_length(knowledge_json->'sources') > 0
        GROUP BY title ORDER BY cnt DESC LIMIT 20
    """)
    top_connected = storage._execute_sql("""
        SELECT k.name, k.knowledge_json->>'knowledge_type' as ktype, COUNT(r.target_id) as cnt
        FROM knowledge k JOIN relations r ON k.id = r.source_id
        GROUP BY k.id, k.name, ktype ORDER BY cnt DESC LIMIT 10
    """)

    kg_stats = {}
    try:
        ent_count = storage._execute_sql("SELECT COUNT(*) as cnt FROM public.unified_entities")
        erel_count = storage._execute_sql("SELECT COUNT(*) as cnt FROM public.entity_relations")
        inferred_count = storage._execute_sql(
            "SELECT COUNT(*) as cnt FROM public.entity_relations WHERE is_inferred = TRUE"
        )
        erel_types = storage._execute_sql("""
            SELECT relation_type, COUNT(*) as cnt FROM public.entity_relations
            GROUP BY relation_type ORDER BY cnt DESC
        """)
        kg_stats = {
            "entity_count": ent_count[0]["cnt"],
            "entity_relation_count": erel_count[0]["cnt"],
            "inferred_relation_count": inferred_count[0]["cnt"],
            "entity_relation_types": erel_types,
        }
    except Exception:
        kg_stats = {"error": "KG tables not available"}

    engine_info = {}
    e = _get_engine()
    if e and e.kg_reasoner:
        engine_info = {
            "kg_reasoner_loaded": True,
            "kg_nodes": len(e.kg_reasoner._names),
            "kg_edges": sum(len(v) for v in e.kg_reasoner._fwd.values()),
        }
    elif e:
        engine_info = {"kg_reasoner_loaded": False}
    else:
        engine_info = {"engine_init_failed": True}

    return {
        "knowledge_count": total_k[0]["cnt"],
        "relation_count": total_r[0]["cnt"],
        "type_distribution": types,
        "relation_type_distribution": rel_types,
        "top_books": books,
        "top_connected": top_connected,
        "knowledge_graph": kg_stats,
        "engine": engine_info,
    }


# ============ 模拟器接口 ============

_simulator: Optional["MultiAgentSimulator"] = None


def _get_simulator():
    global _simulator
    if _simulator is None:
        try:
            from generic_causal_architecture.simulation.multi_agent_simulator import MultiAgentSimulator
            _simulator = MultiAgentSimulator(storage, num_agents=5)
            _simulator.build_world_from_kg()
            _simulator.create_agents()
        except Exception as ex:
            logger.error(f"Failed to init simulator: {ex}")
    return _simulator


@app.get("/api/simulate")
async def run_simulation(steps: int = Query(default=8, ge=1, le=20)):
    sim = _get_simulator()
    if not sim:
        return JSONResponse({"error": "simulator not available"}, status_code=503)
    t0 = time.time()
    result = sim.simulate_sync(steps=steps)
    elapsed = (time.time() - t0) * 1000
    return {
        "simulation_id": result.simulation_id,
        "num_agents": result.num_agents,
        "total_steps": result.total_steps,
        "confidence": result.confidence,
        "emergence_patterns": result.emergence_patterns,
        "consensus_findings": result.consensus_findings,
        "summary": result.summary(),
        "elapsed_ms": round(elapsed, 1),
    }


# ============ Action Injection 接口 ============

from pydantic import BaseModel as PydanticModel
from typing import List as TypingList, Optional as TypingOptional


class ActionRelationInput(PydanticModel):
    source: str
    target: str
    relation_type: str = "causes"
    confidence: float = 0.8


class ActionInput(PydanticModel):
    name: str
    relations: TypingList[ActionRelationInput]
    actor: TypingOptional[str] = None
    metadata: dict = {}
    trace_depth: int = 4


@app.post("/api/action/inject")
async def inject_action(action: ActionInput):
    """
    Inject an action into the causal engine.

    The engine will:
    1. Create entities if they don't exist
    2. Persist declared causal relations
    3. Trace forward to predict consequences
    4. Return immediate effects + downstream chains
    """
    engine = _get_engine()
    if not engine:
        return JSONResponse({"error": "engine not available"}, status_code=503)

    from generic_causal_architecture.core.action_models import (
        Action, ActionRelation,
    )
    action_obj = Action(
        name=action.name,
        relations=[
            ActionRelation(
                source=r.source,
                target=r.target,
                relation_type=r.relation_type,
                confidence=r.confidence,
            )
            for r in action.relations
        ],
        actor=action.actor,
        metadata=action.metadata,
    )

    t0 = time.time()
    result = engine.inject_action(action_obj, trace_depth=action.trace_depth)
    elapsed = (time.time() - t0) * 1000

    return {
        **result.to_dict(),
        "elapsed_ms": round(elapsed, 1),
    }


# ============ Rule Discovery 接口 ============

class DiscoverInput(PydanticModel):
    context: str
    world_state: dict = {}
    existing_rules_hint: TypingList[str] = []
    max_candidates: int = 5


class ValidateInput(PydanticModel):
    source: str
    target: str
    relation_type: str = "causes"
    confidence: float = 0.7
    reasoning: str = ""
    catalysts: TypingList[str] = []
    inhibitors: TypingList[str] = []


class FeedbackInput(PydanticModel):
    rule_source: str
    rule_target: str
    rule_relation_type: str
    predicted_outcome: str
    actual_outcome: str
    match: bool
    context: dict = {}


class AdjustConfidenceInput(PydanticModel):
    source: str
    target: str
    relation_type: str
    delta: float


@app.post("/api/rules/discover")
async def api_discover_rules(req: DiscoverInput):
    engine = _get_engine()
    if not engine:
        return JSONResponse({"error": "engine not available"}, status_code=503)

    from generic_causal_architecture.core.protocol import DiscoverRequest
    request = DiscoverRequest(
        context=req.context,
        world_state=req.world_state,
        existing_rules_hint=req.existing_rules_hint,
        max_candidates=req.max_candidates,
    )

    result = await engine.discover_rules(request)
    return result.to_dict()


@app.post("/api/rules/validate")
async def api_validate_rule(req: ValidateInput):
    engine = _get_engine()
    if not engine:
        return JSONResponse({"error": "engine not available"}, status_code=503)

    from generic_causal_architecture.core.protocol import CandidateRule
    rule = CandidateRule(
        source=req.source,
        target=req.target,
        relation_type=req.relation_type,
        confidence=req.confidence,
        reasoning=req.reasoning,
        catalysts=req.catalysts,
        inhibitors=req.inhibitors,
    )
    result = engine.validate_rule(rule)
    return result.to_dict()


@app.post("/api/rules/feedback")
async def api_process_feedback(req: FeedbackInput):
    engine = _get_engine()
    if not engine:
        return JSONResponse({"error": "engine not available"}, status_code=503)

    from generic_causal_architecture.core.protocol import FeedbackRequest
    feedback = FeedbackRequest(
        rule_source=req.rule_source,
        rule_target=req.rule_target,
        rule_relation_type=req.rule_relation_type,
        predicted_outcome=req.predicted_outcome,
        actual_outcome=req.actual_outcome,
        match=req.match,
        context=req.context,
    )
    return engine.process_feedback(feedback)


@app.post("/api/rules/adjust_confidence")
async def api_adjust_confidence(req: AdjustConfidenceInput):
    engine = _get_engine()
    if not engine:
        return JSONResponse({"error": "engine not available"}, status_code=503)

    success = engine.adjust_confidence(
        req.source, req.target, req.relation_type, req.delta
    )
    return {"success": success}


@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse(CONTENT)


CONTENT = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>因果知识探索</title>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: -apple-system, "Microsoft YaHei", sans-serif; background: #0f0f0f; color: #e0e0e0; min-height: 100vh; }
.header { background: #1a1a2e; padding: 20px 30px; border-bottom: 1px solid #333; }
.header h1 { font-size: 22px; color: #00d4ff; }
.header p { color: #888; font-size: 13px; margin-top: 4px; }
.container { max-width: 1200px; margin: 0 auto; padding: 20px; }
.search-box { display: flex; gap: 10px; margin-bottom: 20px; }
.search-box input { flex: 1; padding: 12px 16px; background: #1a1a1a; border: 1px solid #333; border-radius: 8px; color: #fff; font-size: 15px; }
.search-box input:focus { outline: none; border-color: #00d4ff; }
.search-box button { padding: 12px 24px; background: #00d4ff; color: #000; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; }
.search-box button:hover { background: #00b8d4; }
.stats-bar { display: flex; gap: 16px; margin-bottom: 20px; flex-wrap: wrap; }
.stat-card { background: #1a1a2e; padding: 12px 20px; border-radius: 8px; border: 1px solid #333; }
.stat-card .label { color: #888; font-size: 12px; }
.stat-card .value { color: #00d4ff; font-size: 24px; font-weight: bold; }
.results { display: flex; flex-direction: column; gap: 12px; }
.knowledge-card { background: #1a1a2e; border: 1px solid #333; border-radius: 10px; padding: 16px; cursor: pointer; transition: border-color 0.2s; }
.knowledge-card:hover { border-color: #00d4ff; }
.knowledge-card .name { font-size: 16px; font-weight: bold; color: #fff; margin-bottom: 6px; }
.knowledge-card .content { color: #bbb; font-size: 13px; line-height: 1.6; margin-bottom: 8px; }
.knowledge-card .meta { display: flex; gap: 12px; font-size: 12px; color: #888; }
.knowledge-card .meta .tag { background: #2a2a4a; padding: 2px 8px; border-radius: 4px; color: #00d4ff; }
.chain-container { margin-top: 20px; }
.chain-title { font-size: 18px; color: #00d4ff; margin-bottom: 12px; }
.node-list { display: flex; flex-direction: column; gap: 8px; }
.node-item { background: #1a1a1a; border: 1px solid #333; border-radius: 8px; padding: 12px; }
.node-item .node-name { font-weight: bold; color: #fff; cursor: pointer; }
.node-item .node-name:hover { color: #00d4ff; }
.node-item .node-content { color: #aaa; font-size: 13px; margin-top: 4px; }
.node-item .node-meta { font-size: 11px; color: #666; margin-top: 4px; }
.edge-item { background: #1a1a1a; border-left: 3px solid #00d4ff; padding: 10px 12px; margin-left: 20px; }
.edge-item .edge-type { font-size: 11px; color: #00d4ff; text-transform: uppercase; }
.edge-item .edge-desc { color: #ccc; font-size: 13px; margin-top: 4px; line-height: 1.5; }
.edge-item .edge-source { font-size: 11px; color: #666; margin-top: 4px; }
#loading { display: none; color: #00d4ff; text-align: center; padding: 40px; }
.btn-sm { padding: 6px 14px; background: #2a2a4a; color: #00d4ff; border: 1px solid #333; border-radius: 6px; cursor: pointer; font-size: 12px; }
.btn-sm:hover { background: #3a3a5a; }
.detail-panel { background: #1a1a2e; border: 1px solid #333; border-radius: 10px; padding: 20px; margin-top: 20px; }
.detail-panel h3 { color: #00d4ff; margin-bottom: 12px; }
.detail-panel .field { margin-bottom: 8px; }
.detail-panel .field .field-label { color: #888; font-size: 12px; }
.detail-panel .field .field-value { color: #e0e0e0; font-size: 14px; line-height: 1.6; }
.evidence-box { background: #111; border-radius: 6px; padding: 10px; margin-top: 6px; border-left: 3px solid #4caf50; }
</style>
</head>
<body>
<div class="header">
  <h1>因果知识探索</h1>
  <p>搜索概念、探索因果链、验证数据价值</p>
</div>
<div class="container">
  <div class="stats-bar" id="stats"></div>
  <div class="search-box">
    <input id="searchInput" type="text" placeholder="搜索因果知识，如：火攻、九变、谋略、地形..." onkeydown="if(event.key==='Enter')doSearch()">
    <button onclick="doSearch()">关键词搜索</button>
    <button onclick="doSemanticSearch()" style="background:#6a1b9a;color:#fff;">语义搜索</button>
    <button onclick="randomExplore()" style="background:#2a2a4a;color:#00d4ff;">随机探索</button>
  </div>
  <div id="loading">加载中...</div>
  <div id="results" class="results"></div>
  <div id="chain" class="chain-container"></div>
  <div id="detail" class="detail-panel" style="display:none"></div>
</div>
<script>
let currentStats = null;

async function loadStats() {
  const r = await fetch('/api/stats');
  currentStats = await r.json();
  const s = currentStats;
  document.getElementById('stats').innerHTML = `
    <div class="stat-card"><div class="label">知识总数</div><div class="value">${s.knowledge_count}</div></div>
    <div class="stat-card"><div class="label">关系总数</div><div class="value">${s.relation_count}</div></div>
    <div class="stat-card"><div class="label">书籍数</div><div class="value">${s.top_books.length}</div></div>
    <div class="stat-card"><div class="label">类型数</div><div class="value">${s.type_distribution.length}</div></div>
  `;
}

async function doSearch() {
  const q = document.getElementById('searchInput').value.trim();
  if (!q) return;
  showLoading(true);
  const r = await fetch('/api/search?q=' + encodeURIComponent(q) + '&limit=20');
  const data = await r.json();
  showLoading(false);
  document.getElementById('chain').innerHTML = '';
  document.getElementById('detail').style.display = 'none';

  if (data.total === 0) {
    document.getElementById('results').innerHTML = '<div style="color:#888;padding:20px;">没有找到相关知识</div>';
    return;
  }

  renderResults(data);
}

async function doSemanticSearch() {
  const q = document.getElementById('searchInput').value.trim();
  if (!q) return;
  showLoading(true);
  const r = await fetch('/api/semantic_search?q=' + encodeURIComponent(q) + '&limit=20');
  const data = await r.json();
  showLoading(false);
  document.getElementById('chain').innerHTML = '';
  document.getElementById('detail').style.display = 'none';

  if (!data.results || data.results.length === 0) {
    document.getElementById('results').innerHTML = '<div style="color:#888;padding:20px;">没有找到语义相关的知识</div>';
    return;
  }
  renderResults(data);
}

function renderResults(data) {
  const isSemantic = data.mode === 'semantic';
  const headerColor = isSemantic ? '#ce93d8' : '#888';
  const modeLabel = isSemantic ? '语义搜索' : '关键词搜索';
  let html = '<div style="color:'+headerColor+';font-size:13px;margin-bottom:12px;">'+modeLabel+'找到 ' + data.total + ' 条结果 (' + data.elapsed_ms + 'ms)</div>';
  for (const item of data.results) {
    const tradTag = item.tradition ? '<span class="tag" style="background:#2a1a3a;color:#ce93d8;">' + esc(item.tradition) + '</span>' : '';
    const relColor = item.reliability==='high'?'#4caf50':item.reliability==='medium'?'#ff9800':'#f44336';
    const relTag = item.reliability ? '<span style="color:'+relColor+'">' + esc(item.reliability) + '</span>' : '';
    const srcTag = item.source_title ? '<span>' + esc(item.source_title) + (item.dynasty ? ' ('+esc(item.dynasty)+')' : '') + '</span>' : '';
    const connTag = item.rel_count > 0 ? '<span>关系: ' + item.rel_count + '</span>' : '';
    const simTag = item.similarity ? '<span style="color:#ce93d8;">相似: ' + (item.similarity*100).toFixed(1) + '%</span>' : '';
    html += '<div class="knowledge-card" onclick="showChain(\\''+item.id+'\\')">' +
      '<div class="name">' + esc(item.name) + '</div>' +
      '<div class="content">' + esc((item.content||'').substring(0,200)) + '</div>' +
      '<div class="meta"><span class="tag">' + esc(item.ktype) + '</span>' +
        tradTag + relTag + srcTag + connTag + simTag +
      '</div></div>';
  }
  document.getElementById('results').innerHTML = html;
}

async function showChain(id) {
  showLoading(true);
  const r = await fetch('/api/causal_chain/' + id + '?depth=2');
  const data = await r.json();
  showLoading(false);
  document.getElementById('detail').style.display = 'none';

  let html = '<div class="chain-title">因果网络 (' + data.nodes.length + ' 个节点, ' + data.edges.length + ' 条关系, ' + data.elapsed_ms + 'ms)</div>';

  const nodesMap = {};
  for (const n of data.nodes) nodesMap[n.id] = n;

  const outgoing = {};
  for (const e of data.edges) {
    if (!outgoing[e.source]) outgoing[e.source] = [];
    outgoing[e.source].push(e);
  }

  html += '<div class="node-list">';
  for (const node of data.nodes) {
    html += '<div class="node-item">' +
      '<div class="node-name" onclick="showDetail(\\''+node.id+'\\')">' + esc(node.name) + '</div>' +
      '<div class="node-content">' + esc((node.content||'').substring(0,150)) + '</div>' +
      '<div class="node-meta">' + esc(node.type||'') + (node.source ? ' | ' + esc(node.source) : '') +
      ' | 置信度: ' + (node.confidence||'-') + '</div></div>';

    if (outgoing[node.id]) {
      for (const edge of outgoing[node.id]) {
        const tgt = nodesMap[edge.target];
        html += '<div class="edge-item">' +
          '<div class="edge-type">' + esc(edge.type) + ' (置信度: ' + edge.confidence + ')</div>' +
          '<div class="edge-desc">' + esc(edge.description||'') + '</div>' +
          (tgt ? '<div class="edge-source">→ <span style="cursor:pointer;color:#00d4ff" onclick="showChain(\\''+tgt.id+'\\')">' + esc(tgt.name) + '</span></div>' : '') +
          '</div>';
      }
    }
  }
  html += '</div>';
  document.getElementById('chain').innerHTML = html;
}

async function showDetail(id) {
  const r = await fetch('/api/knowledge/' + id);
  const data = await r.json();
  const panel = document.getElementById('detail');
  panel.style.display = 'block';

  let html = '<h3>' + esc(data.name) + '</h3>';
  html += '<div class="field"><div class="field-label">类型</div><div class="field-value">' + esc(data.knowledge_type) + '</div></div>';
  html += '<div class="field"><div class="field-label">置信度</div><div class="field-value">' + (data.confidence||'-') + '</div></div>';
  html += '<div class="field"><div class="field-label">内容</div><div class="field-value">' + esc(data.content||'') + '</div></div>';

  if (data.evidence && data.evidence.length > 0) {
    html += '<div class="field"><div class="field-label">证据</div>';
    for (const ev of data.evidence) {
      html += '<div class="evidence-box"><div class="field-value">' + esc(ev.content||'') + '</div>' +
        '<div style="font-size:11px;color:#666;margin-top:4px;">类型: ' + esc(ev.type||'') + ' | 强度: ' + (ev.strength||'-') + ' | 支撑: ' + (ev.supports ? '是' : '否') + '</div></div>';
    }
    html += '</div>';
  }

  if (data.sources && data.sources.length > 0) {
    const s = data.sources[0];
    const extra = s.extra_info || {};
    html += '<div class="field"><div class="field-label">来源</div><div class="field-value">' +
      esc(s.title||'') + ' - ' + esc(s.author||'') +
      (extra.dynasty ? ' (' + esc(extra.dynasty) + ')' : '') +
      (extra.section_title ? ' | ' + esc(extra.section_title) : '') +
      '</div></div>';
  }

  html += '<div style="margin-top:12px;"><button class="btn-sm" onclick="showChain(\\''+id+'\\')">查看因果链</button></div>';
  panel.innerHTML = html;
  panel.scrollIntoView({behavior:'smooth'});
}

async function randomExplore() {
  showLoading(true);
  const r = await fetch('/api/random_chain?depth=2');
  const data = await r.json();
  showLoading(false);
  document.getElementById('results').innerHTML = '';
  document.getElementById('detail').style.display = 'none';

  const center = data.nodes.find(n => n.id === data.center_id);
  let html = '<div class="chain-title">随机探索: ' + (center ? esc(center.name) : '...') +
    ' (' + data.nodes.length + ' 节点, ' + data.edges.length + ' 关系)</div>';

  const nodesMap = {};
  for (const n of data.nodes) nodesMap[n.id] = n;
  const outgoing = {};
  for (const e of data.edges) {
    if (!outgoing[e.source]) outgoing[e.source] = [];
    outgoing[e.source].push(e);
  }

  html += '<div class="node-list">';
  for (const node of data.nodes) {
    html += '<div class="node-item">' +
      '<div class="node-name" onclick="showDetail(\\''+node.id+'\\')">' + esc(node.name) + '</div>' +
      '<div class="node-content">' + esc((node.content||'').substring(0,150)) + '</div>' +
      '<div class="node-meta">' + esc(node.type||'') + (node.source ? ' | '+esc(node.source) : '') + '</div></div>';
    if (outgoing[node.id]) {
      for (const edge of outgoing[node.id]) {
        const tgt = nodesMap[edge.target];
        html += '<div class="edge-item">' +
          '<div class="edge-type">' + esc(edge.type) + '</div>' +
          '<div class="edge-desc">' + esc(edge.description||'') + '</div>' +
          (tgt ? '<div class="edge-source">→ <span style="cursor:pointer;color:#00d4ff" onclick="showChain(\\''+tgt.id+'\\')">' + esc(tgt.name) + '</span></div>' : '') +
          '</div>';
      }
    }
  }
  html += '</div>';
  html += '<div style="margin-top:16px;"><button class="btn-sm" onclick="randomExplore()">再来一个</button></div>';
  document.getElementById('chain').innerHTML = html;
}

function showLoading(on) {
  document.getElementById('loading').style.display = on ? 'block' : 'none';
}

function esc(s) {
  if (!s) return '';
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

loadStats();
</script>
</body>
</html>
"""


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=API_PORT)
