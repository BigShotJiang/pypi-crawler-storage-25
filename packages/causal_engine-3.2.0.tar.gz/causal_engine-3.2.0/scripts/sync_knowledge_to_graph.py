"""
批量同步知识到 AGE 图数据库

用途：
1. 初次全量同步：把所有已提取的知识同步到 AGE 图
2. 增量同步：只同步新添加的知识
3. 修复同步：修复之前同步失败的数据

使用方法：
    # 全量同步
    python scripts/sync_knowledge_to_graph.py --all
    
    # 只同步最近 N 条
    python scripts/sync_knowledge_to_graph.py --limit 100
    
    # 查看统计
    python scripts/sync_knowledge_to_graph.py --stats
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import logging
from typing import List, Tuple
from tqdm import tqdm

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.knowledge import KnowledgeUnit

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


def get_knowledge_batch(
    storage: PostgreSQLStorage,
    offset: int = 0,
    limit: int = 100
) -> List[KnowledgeUnit]:
    """批量获取知识"""
    try:
        return storage.list_knowledge(limit=limit, offset=offset)
    except Exception as e:
        logger.error(f"获取知识失败: {e}")
        return []


def sync_knowledge_to_graph(
    storage: PostgreSQLStorage,
    knowledge: KnowledgeUnit
) -> bool:
    """同步单个知识到图"""
    try:
        storage._sync_knowledge_to_graph(knowledge)
        return True
    except Exception as e:
        logger.warning(f"同步失败 {knowledge.id}: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(description='批量同步知识到 AGE 图')
    parser.add_argument('--all', action='store_true', help='同步所有知识')
    parser.add_argument('--limit', type=int, default=100, help='最多同步数量')
    parser.add_argument('--batch-size', type=int, default=50, help='每批处理数量')
    parser.add_argument('--stats', action='store_true', help='只显示统计信息')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("知识 → AGE 图 批量同步工具")
    print("=" * 60)
    
    storage = PostgreSQLStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
    )
    storage.initialize()
    
    # 获取统计信息
    try:
        result = storage._execute_sql("SELECT COUNT(*) as count FROM knowledge")
        total_knowledge = result[0]['count'] if result else 0
        print(f"\n📊 数据库统计:")
        print(f"  总知识数: {total_knowledge}")
    except Exception as e:
        logger.error(f"获取统计失败: {e}")
        return
    
    if args.stats:
        # 只显示统计
        try:
            result = storage._execute_sql(
                "SELECT * FROM cypher('causal_graph', $$ MATCH (k:Knowledge) RETURN count(k) $$) AS (count agtype)"
            )
            graph_count = int(result[0]['count']) if result else 0
            print(f"  图中知识数: {graph_count}")
            print(f"  待同步: {total_knowledge - graph_count}")
        except Exception as e:
            print(f"  图中知识数: 获取失败 ({e})")
        return
    
    if not args.all and args.limit <= 0:
        print("\n❌ 请指定 --all 或 --limit")
        return
    
    limit = total_knowledge if args.all else min(args.limit, total_knowledge)
    
    print(f"\n🔄 开始同步 (共 {limit} 条知识)...")
    print(f"   批次大小: {args.batch_size}")
    
    success_count = 0
    fail_count = 0
    
    with tqdm(total=limit, desc="同步进度") as pbar:
        for offset in range(0, limit, args.batch_size):
            batch_size = min(args.batch_size, limit - offset)
            knowledge_list = get_knowledge_batch(storage, offset, batch_size)
            
            for knowledge in knowledge_list:
                if sync_knowledge_to_graph(storage, knowledge):
                    success_count += 1
                else:
                    fail_count += 1
                pbar.update(1)
    
    print(f"\n✅ 同步完成!")
    print(f"  成功: {success_count}")
    print(f"  失败: {fail_count}")
    print(f"  总计: {success_count + fail_count}")
    
    # 显示图统计
    try:
        # AGE 的 count 查询需要特殊处理返回类型
        result = storage._execute_sql(
            "SELECT * FROM cypher('causal_graph', $$ MATCH (k:Knowledge) RETURN count(k) $$) AS (count agtype)"
        )
        graph_count = int(result[0]['count']) if result else 0
        print(f"\n📈 图中知识总数: {graph_count}")
    except Exception as e:
        logger.warning(f"获取图统计失败: {e}")


if __name__ == "__main__":
    main()
