"""
语义去重脚本：用硅基流动 Embedding API + 余弦相似度合并同类模式

流程：
1. 读取 pattern_results.json (170 个模式)
2. 对每个模式的 name + abstract_logic 做 embedding
3. 计算余弦相似度矩阵
4. 用相似度阈值做层次聚类
5. 同一簇内选最佳代表，合并 merge_count
6. 输出去重后的结果

用法:
    cd t:\Item\AI\discuss\sources\generic-causal-architecture
    python scripts/semantic_dedup.py
"""

import json
import time
import numpy as np
from pathlib import Path

project_root = Path(__file__).parent.parent

SILICONFLOW_API_KEY = "sk-eahardciwonesiiwlbyljngvyvzutzahkxlezbyahfnidayr"
SILICONFLOW_BASE_URL = "https://api.siliconflow.cn/v1"
EMBEDDING_MODEL = "netease-youdao/bce-embedding-base_v1"
SIMILARITY_THRESHOLD = 0.85

INPUT_FILE = project_root / "scripts" / "pattern_results.json"
OUTPUT_FILE = project_root / "scripts" / "pattern_deduped.json"


def get_embeddings_batch(texts: list[str]) -> list[list[float]]:
    import requests as http_requests

    all_embeddings = []
    batch_size = 32

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        print(f"  Embedding {i+1}-{min(i+batch_size, len(texts))}/{len(texts)}...", end=" ")

        resp = http_requests.post(
            f"{SILICONFLOW_BASE_URL}/embeddings",
            headers={
                "Authorization": f"Bearer {SILICONFLOW_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": EMBEDDING_MODEL,
                "input": batch,
                "encoding_format": "float",
            },
            timeout=60,
        )

        if resp.status_code != 200:
            print(f"ERROR: {resp.status_code} {resp.text[:200]}")
            raise Exception(f"Embedding API error: {resp.status_code}")

        data = resp.json()["data"]
        sorted_data = sorted(data, key=lambda x: x["index"])
        batch_embeddings = [d["embedding"] for d in sorted_data]
        all_embeddings.extend(batch_embeddings)

        used = resp.json().get("usage", {})
        print(f"OK (tokens: {used.get('total_tokens', '?')})")
        time.sleep(0.5)

    return all_embeddings


def cosine_similarity_matrix(vectors: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms = np.where(norms == 0, 1, norms)
    normalized = vectors / norms
    return normalized @ normalized.T


def agglomerative_cluster(sim_matrix: np.ndarray, threshold: float) -> list[list[int]]:
    n = sim_matrix.shape[0]
    clusters: list[list[int]] = [[i] for i in range(n)]

    while True:
        max_sim = -1
        merge_pair = (-1, -1)

        for i in range(len(clusters)):
            for j in range(i + 1, len(clusters)):
                sims = []
                for a in clusters[i]:
                    for b in clusters[j]:
                        sims.append(sim_matrix[a][b])
                avg_sim = sum(sims) / len(sims)
                if avg_sim > max_sim:
                    max_sim = avg_sim
                    merge_pair = (i, j)

        if max_sim < threshold:
            break

        i, j = merge_pair
        clusters[i] = clusters[i] + clusters[j]
        del clusters[j]

    return clusters


def select_representative(cluster_indices: list[int], patterns: list[dict], sim_matrix: np.ndarray) -> int:
    if len(cluster_indices) == 1:
        return cluster_indices[0]

    best_idx = cluster_indices[0]
    best_score = 0

    for idx in cluster_indices:
        sim_sum = sum(sim_matrix[idx][other] for other in cluster_indices if other != idx)
        mc = patterns[idx].get("merge_count", 1)
        score = sim_sum + mc * 0.5
        if score > best_score:
            best_score = score
            best_idx = idx

    return best_idx


def main():
    print(f"读取模式文件: {INPUT_FILE}")
    with open(INPUT_FILE, encoding="utf-8") as f:
        patterns = json.load(f)
    print(f"  加载 {len(patterns)} 个模式")

    print(f"\n[Step 1] 生成 Embedding (模型: {EMBEDDING_MODEL})...")
    texts = []
    for p in patterns:
        text = f"{p['pattern_name']}：{p.get('abstract_logic', '')}"
        texts.append(text)

    embeddings = get_embeddings_batch(texts)
    vectors = np.array(embeddings)
    print(f"  向量维度: {vectors.shape}")

    print(f"\n[Step 2] 计算相似度矩阵...")
    sim_matrix = cosine_similarity_matrix(vectors)
    print(f"  矩阵大小: {sim_matrix.shape}")

    high_sim_pairs = []
    for i in range(len(patterns)):
        for j in range(i + 1, len(patterns)):
            if sim_matrix[i][j] >= 0.8:
                high_sim_pairs.append((i, j, sim_matrix[i][j]))
    high_sim_pairs.sort(key=lambda x: -x[2])
    print(f"  相似度 >= 0.8 的配对: {len(high_sim_pairs)}")

    print(f"\n  Top 20 相似配对:")
    for i, j, sim in high_sim_pairs[:20]:
        print(f"    {patterns[i]['pattern_name']} <-> {patterns[j]['pattern_name']} ({sim:.4f})")

    print(f"\n[Step 3] 层次聚类 (阈值: {SIMILARITY_THRESHOLD})...")
    clusters = agglomerative_cluster(sim_matrix, SIMILARITY_THRESHOLD)
    print(f"  聚类结果: {len(clusters)} 个簇")

    multi_clusters = [c for c in clusters if len(c) > 1]
    print(f"  多元素簇: {len(multi_clusters)} 个")
    for c in sorted(multi_clusters, key=lambda x: -len(x)):
        names = [patterns[idx]["pattern_name"] for idx in c]
        print(f"    [{len(c)}个] {', '.join(names)}")

    print(f"\n[Step 4] 选代表 + 合并...")
    deduped = []
    for cluster in clusters:
        rep_idx = select_representative(cluster, patterns, sim_matrix)
        rep = dict(patterns[rep_idx])

        total_merge = rep.get("merge_count", 1)
        merged_names = [patterns[idx]["pattern_name"] for idx in cluster if idx != rep_idx]

        if len(cluster) > 1:
            for idx in cluster:
                if idx != rep_idx:
                    total_merge += patterns[idx].get("merge_count", 1)

        rep["merge_count"] = total_merge
        rep["cluster_size"] = len(cluster)
        rep["merged_names"] = merged_names if merged_names else None

        deduped.append(rep)

    deduped.sort(key=lambda x: (-x.get("merge_count", 1), -x.get("cluster_size", 1)))

    high = [p for p in deduped if p.get("generality") == "high"]
    medium = [p for p in deduped if p.get("generality") == "medium"]
    low = [p for p in deduped if p.get("generality") == "low"]

    print(f"\n{'='*70}")
    print(f"去重结果")
    print(f"{'='*70}")
    print(f"原始: {len(patterns)} 个模式")
    print(f"去重: {len(deduped)} 个模式")
    print(f"合并: {len(patterns) - len(deduped)} 个被合并")
    print(f"高: {len(high)} | 中: {len(medium)} | 低: {len(low)}")

    print(f"\n{'─'*40}")
    print(f"高通用性 ({len(high)} 个)")
    print(f"{'─'*40}")
    for p in high:
        cs = p.get("cluster_size", 1)
        mc = p.get("merge_count", 1)
        mn = p.get("merged_names", [])
        extra = f" ← 合并了 {mn}" if mn else ""
        print(f"\n  【{p['pattern_name']}】(原始{mc}次, 簇{cs}个{extra})")
        print(f"  逻辑: {p.get('abstract_logic', '')}")
        print(f"  机制: {p.get('mechanism', '')}")
        print(f"  类比: {p.get('modern_analogy', '')}")
        fe = p.get("final_eval", {})
        if fe:
            print(f"  置信度: {fe.get('confidence', '-')}")

    print(f"\n{'─'*40}")
    print(f"中通用性 ({len(medium)} 个)")
    print(f"{'─'*40}")
    for p in medium:
        cs = p.get("cluster_size", 1)
        mc = p.get("merge_count", 1)
        mn = p.get("merged_names", [])
        extra = f" ← {mn}" if mn else ""
        print(f"  【{p['pattern_name']}】({mc}x, 簇{cs}{extra})")
        print(f"    {p.get('abstract_logic', '')[:60]}")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(deduped, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
