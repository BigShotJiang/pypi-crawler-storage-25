#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
史记知识库数据导入脚本

将 shiji-kb 的结构化数据导入到通用因果架构的 PostgreSQL 存储中

使用方法:
    # 快速导入前 5 章
    python scripts/import_shiji_kb.py --chapters 001-005
    
    # 导入全部数据
    python scripts/import_shiji_kb.py --all
    
    # 只导入实体
    python scripts/import_shiji_kb.py --entities --chapters 001-010
    
    # 只导入事件和关系
    python scripts/import_shiji_kb.py --events --relations
"""

import os
import sys

# 修复 Windows 编码问题
os.environ['PYTHONIOENCODING'] = 'utf-8'
if sys.platform == 'win32':
    import codecs
    sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
    sys.stderr = codecs.getwriter('utf-8')(sys.stderr.buffer, 'strict')
import json
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.storage.storage_interface import EventData, CausalRelation
from generic_causal_architecture.adapters.history_adapter import HistoryAdapter, EventType


class ShijiKBImporter:
    """shiji-kb 数据导入器"""
    
    def __init__(self, storage: PostgreSQLStorage, verbose: bool = True):
        self.storage = storage
        self.verbose = verbose
        self.stats = {
            'entities_imported': 0,
            'events_imported': 0,
            'relations_imported': 0,
            'errors': 0
        }
    
    def log(self, message: str):
        """打印日志"""
        if self.verbose:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] {message}")
    
    def load_json(self, file_path: str) -> Any:
        """加载 JSON 文件"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            self.log(f"❌ 加载文件失败 {file_path}: {e}")
            self.stats['errors'] += 1
            return None
    
    def import_entities(self, entity_file: str, limit: Optional[int] = None) -> int:
        """导入实体数据"""
        self.log(f"📦 开始导入实体数据：{entity_file}")
        
        data = self.load_json(entity_file)
        if not data:
            return 0
        
        # entity_index.json 格式：{category: {entity_name: data}}
        # 需要遍历所有 category 和 entity
        entities = []
        for category, entity_dict in data.items():
            if isinstance(entity_dict, dict):
                for entity_name, entity_data in entity_dict.items():
                    entity_data['_name'] = entity_name  # 保存实体名
                    entity_data['_category'] = category  # 保存分类
                    entities.append(entity_data)
        
        if limit:
            entities = entities[:limit]
        
        count = 0
        for i, entity in enumerate(entities):
            try:
                # 转换为 EventData
                event = EventData(
                    id=entity.get('_name', f"entity_{i}"),
                    name=entity.get('_name', ''),
                    event_type=self._map_entity_type(entity.get('_category', 'UNKNOWN')),
                    timestamp=self._parse_timestamp(entity),
                    location=entity.get('location'),
                    participants=entity.get('participants'),
                    description=entity.get('description', entity.get('text', '')),
                    metadata=entity,
                    evidence_sources=[entity.get('source', 'shiji-kb')]
                )
                
                self.storage.add_event(event)
                count += 1
                
                if count % 100 == 0:
                    self.log(f"  已导入 {count} 个实体...")
                    
            except Exception as e:
                self.log(f"  ⚠️  导入实体失败 {i}: {e}")
                self.stats['errors'] += 1
        
        self.stats['entities_imported'] += count
        self.log(f"✅ 完成导入 {count}/{len(entities)} 个实体")
        return count
    
    def import_events(self, event_file: str, limit: Optional[int] = None) -> int:
        """导入事件数据"""
        self.log(f"📦 开始导入事件数据：{event_file}")
        
        data = self.load_json(event_file)
        if not data:
            return 0
        
        # 处理 dict 或 list
        if isinstance(data, dict):
            events = list(data.values())
        else:
            events = data
        
        if limit:
            events = events[:limit]
        
        count = 0
        for i, event in enumerate(events):
            try:
                # 转换为 EventData
                event_data = EventData(
                    id=event.get('war_id', event.get('event_id', f"event_{i}")),
                    name=event.get('war_name', event.get('event_name', '')),
                    event_type=EventType.POLITICAL,  # 默认类型
                    timestamp=self._parse_event_timestamp(event),
                    location=self._extract_location(event.get('description', '')),
                    participants=self._extract_participants(event.get('description', '')),
                    description=event.get('full_description', event.get('description', '')),
                    metadata=event,
                    evidence_sources=event.get('chapters', ['shiji-kb'])
                )
                
                self.storage.add_event(event_data)
                count += 1
                
                if count % 50 == 0:
                    self.log(f"  已导入 {count} 个事件...")
                    
            except Exception as e:
                self.log(f"  ⚠️  导入事件失败 {i}: {e}")
                self.stats['errors'] += 1
        
        self.stats['events_imported'] += count
        self.log(f"✅ 完成导入 {count}/{len(events)} 个事件")
        return count
    
    def import_relations(self, relation_file: str, limit: Optional[int] = None) -> int:
        """导入关系数据"""
        self.log(f"📦 开始导入关系数据：{relation_file}")
        
        data = self.load_json(relation_file)
        if not data:
            return 0
        
        # 处理 dict 或 list
        if isinstance(data, dict):
            relations = list(data.values())
        else:
            relations = data
        
        if limit:
            relations = relations[:limit]
        
        count = 0
        for i, rel in enumerate(relations):
            try:
                # 转换为 CausalRelation
                causal_rel = CausalRelation(
                    source_id=rel.get('source_id', rel.get('from_id', '')),
                    target_id=rel.get('target_id', rel.get('to_id', '')),
                    relation_type=rel.get('type', 'causal'),
                    confidence=rel.get('confidence', 0.8),
                    evidence=rel.get('sources', []),
                    metadata=rel
                )
                
                self.storage.add_causal_relation(causal_rel)
                count += 1
                
                if count % 100 == 0:
                    self.log(f"  已导入 {count} 条关系...")
                    
            except Exception as e:
                self.log(f"  ⚠️  导入关系失败 {i}: {e}")
                self.stats['errors'] += 1
        
        self.stats['relations_imported'] += count
        self.log(f"✅ 完成导入 {count}/{len(relations)} 条关系")
        return count
    
    def import_wars(self, wars_file: str, limit: Optional[int] = None) -> int:
        """导入战争数据"""
        self.log(f"📦 开始导入战争数据：{wars_file}")
        
        wars = self.load_json(wars_file)
        if not wars:
            return 0
        
        if limit:
            wars = wars[:limit]
        
        count = 0
        for i, war in enumerate(wars):
            try:
                # 转换为 EventData (战争是特殊事件)
                event = EventData(
                    id=war.get('war_id', f"war_{i}"),
                    name=war.get('war_name', ''),
                    event_type=EventType.MILITARY,
                    timestamp=self._parse_war_timestamp(war),
                    location=self._extract_location(war.get('description', '')),
                    description=war.get('full_description', war.get('description', '')),
                    metadata=war,
                    evidence_sources=war.get('chapters', ['shiji-kb'])
                )
                
                self.storage.add_event(event)
                count += 1
                
                if count % 50 == 0:
                    self.log(f"  已导入 {count} 场战争...")
                    
            except Exception as e:
                self.log(f"  ⚠️  导入战争失败 {i}: {e}")
                self.stats['errors'] += 1
        
        self.stats['events_imported'] += count
        self.log(f"✅ 完成导入 {count}/{len(wars)} 场战争")
        return count
    
    def _map_entity_type(self, entity_type: str) -> str:
        """映射实体类型到 EventType"""
        type_mapping = {
            'PERSON': 'POLITICAL',
            'LOCATION': 'GEOGRAPHICAL',
            'EVENT': 'POLITICAL',
            'DATE': 'CULTURAL',
            'TITLE': 'POLITICAL',
            'ORGANIZATION': 'POLITICAL',
        }
        return type_mapping.get(entity_type, 'UNKNOWN')
    
    def _parse_timestamp(self, entity: Dict) -> Dict[str, Any]:
        """解析时间戳"""
        # 尝试从 metadata 中提取时间
        timestamp = entity.get('timestamp', {})
        if not timestamp:
            # 尝试从其他字段提取
            year = entity.get('year')
            if year:
                timestamp = {'year': year}
        return timestamp
    
    def _parse_event_timestamp(self, event: Dict) -> Dict[str, Any]:
        """解析事件时间戳"""
        desc = event.get('description', '')
        
        # 尝试从描述中提取时间
        if '**时间**:' in desc:
            time_str = desc.split('**时间**:')[1].split('\n')[0].strip()
            # 提取年份
            if '公元前' in time_str:
                year = int(time_str.split('公元前')[1].split('年')[0])
                return {'year': -year, 'era': 'BC'}
            elif '公元' in time_str:
                year = int(time_str.split('公元')[1].split('年')[0])
                return {'year': year, 'era': 'AD'}
        
        return {}
    
    def _parse_war_timestamp(self, war: Dict) -> Dict[str, Any]:
        """解析战争时间戳"""
        return self._parse_event_timestamp(war)
    
    def _extract_location(self, description: str) -> Optional[str]:
        """从描述中提取地点"""
        if '**地点**:' in description:
            location = description.split('**地点**:')[1].split('\n')[0].strip()
            if location and location != '-':
                return location
        return None
    
    def _extract_participants(self, description: str) -> Optional[List[str]]:
        """从描述中提取参与者"""
        # 简单实现，可以根据需要改进
        # 查找人名（ capitalized Chinese names）
        import re
        names = re.findall(r'[A-Za-z·]{2,20}', description)
        return names if names else None
    
    def get_stats(self) -> Dict[str, int]:
        """获取统计信息"""
        return self.stats


def parse_chapter_range(chapter_range: str) -> List[str]:
    """解析章节范围，如 '001-005' -> ['001', '002', '003', '004', '005']"""
    if '-' in chapter_range:
        start, end = chapter_range.split('-')
        return [f"{i:03d}" for i in range(int(start), int(end) + 1)]
    else:
        return [chapter_range]


def main():
    parser = argparse.ArgumentParser(description='史记知识库数据导入工具')
    parser.add_argument('--all', action='store_true', help='导入全部数据')
    parser.add_argument('--entities', action='store_true', help='导入实体')
    parser.add_argument('--events', action='store_true', help='导入事件')
    parser.add_argument('--relations', action='store_true', help='导入关系')
    parser.add_argument('--wars', action='store_true', help='导入战争')
    parser.add_argument('--chapters', type=str, help='章节范围，如 001-005')
    parser.add_argument('--limit', type=int, help='每类数据导入数量限制')
    parser.add_argument('--quiet', action='store_true', help='减少输出')
    parser.add_argument('--dry-run', action='store_true', help='只解析不导入')
    
    args = parser.parse_args()
    
    # 如果没有指定任何选项，默认导入前 5 章的实体和事件
    if not any([args.all, args.entities, args.events, args.relations, args.wars]):
        args.entities = True
        args.events = True
        args.wars = True
        if not args.chapters:
            args.chapters = '001-005'
    
    # 确定 shiji-kb 数据目录
    shiji_kb_dir = Path(__file__).parent.parent.parent / 'shiji-kb'
    if not shiji_kb_dir.exists():
        print(f"❌ shiji-kb 目录不存在：{shiji_kb_dir}")
        sys.exit(1)
    
    # 初始化存储
    print("🔌 连接 PostgreSQL 数据库...")
    
    from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
    storage = PostgreSQLStorage()
    
    try:
        storage.initialize()
        print("✅ 数据库连接成功")
    except Exception as e:
        print(f"❌ 数据库连接失败：{e}")
        print("\n请确保:")
        print("1. PostgreSQL 服务已启动")
        print("2. docker start causal-postgres")
        print("3. 密码配置正确")
        sys.exit(1)
    
    # 创建导入器
    importer = ShijiKBImporter(storage, verbose=not args.quiet)
    
    # 解析章节范围
    chapter_nums = []
    if args.chapters:
        chapter_nums = parse_chapter_range(args.chapters)
        print(f"📖 处理章节：{', '.join(chapter_nums)}")
    
    try:
        # 导入实体
        if args.entities or args.all:
            entity_file = shiji_kb_dir / 'kg' / 'entity_index.json'
            if entity_file.exists():
                limit = args.limit if args.limit else (500 if args.chapters else None)
                if not args.dry_run:
                    importer.import_entities(str(entity_file), limit=limit)
                else:
                    print(f"[DRY RUN] 将导入实体：{entity_file}")
            else:
                print(f"⚠️  实体文件不存在：{entity_file}")
        
        # 导入事件
        if args.events or args.all:
            event_file = shiji_kb_dir / 'kg' / 'events' / 'events_summary.json'
            if event_file.exists():
                limit = args.limit if args.limit else (100 if args.chapters else None)
                if not args.dry_run:
                    importer.import_events(str(event_file), limit=limit)
                else:
                    print(f"[DRY RUN] 将导入事件：{event_file}")
            else:
                print(f"⚠️  事件文件不存在：{event_file}")
        
        # 导入关系
        if args.relations or args.all:
            relation_file = shiji_kb_dir / 'kg' / 'relations' / 'causal_relations.json'
            if relation_file.exists():
                limit = args.limit if args.limit else (200 if args.chapters else None)
                if not args.dry_run:
                    importer.import_relations(str(relation_file), limit=limit)
                else:
                    print(f"[DRY RUN] 将导入关系：{relation_file}")
            else:
                print(f"⚠️  关系文件不存在：{relation_file}")
        
        # 导入战争
        if args.wars or args.all:
            wars_file = shiji_kb_dir / 'data' / 'wars.json'
            if wars_file.exists():
                limit = args.limit if args.limit else (50 if args.chapters else None)
                if not args.dry_run:
                    importer.import_wars(str(wars_file), limit=limit)
                else:
                    print(f"[DRY RUN] 将导入战争：{wars_file}")
            else:
                print(f"⚠️  战争文件不存在：{wars_file}")
        
        # 打印统计
        stats = importer.get_stats()
        print("\n" + "=" * 50)
        print("📊 导入统计:")
        print(f"  实体：{stats['entities_imported']}")
        print(f"  事件：{stats['events_imported']}")
        print(f"  关系：{stats['relations_imported']}")
        print(f"  错误：{stats['errors']}")
        print("=" * 50)
        
        if stats['errors'] > 0:
            print(f"\n⚠️  有 {stats['errors']} 个错误，请检查日志")
        
        print("\n✅ 导入完成！")
        print("\n下一步:")
        print("  python examples/mvp_causal_test.py")
        
    except Exception as e:
        print(f"\n❌ 导入过程中出错：{e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    finally:
        storage.close()


if __name__ == '__main__':
    main()
