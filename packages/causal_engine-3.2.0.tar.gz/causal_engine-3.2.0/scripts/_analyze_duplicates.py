import sys
from pathlib import Path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))
from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
storage = PostgreSQLStorage(database_url=DB_URL)
storage.initialize()

print("=" * 60)
print("1. 同名概念 Top 30")
print("=" * 60)
rows = storage._execute_sql("""
    SELECT name, COUNT(*) as cnt 
    FROM knowledge 
    GROUP BY name 
    HAVING COUNT(*) > 1 
    ORDER BY cnt DESC 
    LIMIT 30
""")
total_dup_names = storage._execute_sql("""
    SELECT COUNT(*) as cnt FROM (
        SELECT name FROM knowledge GROUP BY name HAVING COUNT(*) > 1
    ) t
""")
total_dup_entries = storage._execute_sql("""
    SELECT COUNT(*) as cnt FROM knowledge 
    WHERE name IN (SELECT name FROM knowledge GROUP BY name HAVING COUNT(*) > 1)
""")
for r in rows:
    print(f"  {r['name']}: {r['cnt']} 条")
print(f"\n同名概念组数: {total_dup_names[0]['cnt']}")
print(f"涉及知识条目: {total_dup_entries[0]['cnt']}")

print(f"\n{'=' * 60}")
print("2. 同名概念的分布（出现次数分布）")
print("=" * 60)
dist = storage._execute_sql("""
    SELECT cnt, COUNT(*) as groups FROM (
        SELECT name, COUNT(*) as cnt FROM knowledge GROUP BY name HAVING COUNT(*) > 1
    ) t GROUP BY cnt ORDER BY cnt
""")
for d in dist:
    print(f"  出现 {d['cnt']} 次的概念: {d['groups']} 个")

print(f"\n{'=' * 60}")
print("3. 抽样看具体同名条目的差异")
print("=" * 60)
samples = ["赏罚", "法治", "用兵之道", "地形", "民心"]
for name in samples:
    entries = storage._execute_sql("""
        SELECT id, knowledge_json->>'content' as content,
               knowledge_json->'sources'->0->>'title' as source,
               knowledge_json->'perspective'->>'tradition' as tradition
        FROM knowledge WHERE name = :n
    """, {"n": name})
    if len(entries) <= 1:
        continue
    print(f"\n  【{name}】({len(entries)} 条)")
    for e in entries[:5]:
        content_preview = (e['content'] or '')[:80]
        print(f"    [{e['tradition']}] {e['source']}: {content_preview}...")

print(f"\n{'=' * 60}")
print("4. 语义相似的同名概念（embedding 距离）")
print("=" * 60)
semb = storage._execute_sql("""
    WITH dup_names AS (
        SELECT name FROM knowledge GROUP BY name HAVING COUNT(*) > 1
    ),
    pairs AS (
        SELECT k1.name, k1.id as id1, k2.id as id2,
               k1.knowledge_json->'sources'->0->>'title' as src1,
               k2.knowledge_json->'sources'->0->>'title' as src2,
               k1.knowledge_json->'perspective'->>'tradition' as trad1,
               k2.knowledge_json->'perspective'->>'tradition' as trad2,
               1 - (k1.embedding <=> k2.embedding) as sim
        FROM knowledge k1
        JOIN knowledge k2 ON k1.name = k2.name AND k1.id < k2.id
        WHERE k1.name = ANY(SELECT name FROM dup_names)
    )
    SELECT name, src1, src2, trad1, trad2, sim FROM pairs
    ORDER BY sim ASC LIMIT 10
""")
print("  最不相似的同名对（可能是同名异义）:")
for s in semb:
    print(f"    {s['name']}: {s['src1']}({s['trad1']}) vs {s['src2']}({s['trad2']}) = {float(s['sim']):.3f}")

semb2 = storage._execute_sql("""
    WITH dup_names AS (
        SELECT name FROM knowledge GROUP BY name HAVING COUNT(*) > 1
    ),
    pairs AS (
        SELECT k1.name, k1.id as id1, k2.id as id2,
               k1.knowledge_json->'sources'->0->>'title' as src1,
               k2.knowledge_json->'sources'->0->>'title' as src2,
               1 - (k1.embedding <=> k2.embedding) as sim
        FROM knowledge k1
        JOIN knowledge k2 ON k1.name = k2.name AND k1.id < k2.id
        WHERE k1.name = ANY(SELECT name FROM dup_names)
    )
    SELECT AVG(sim) as avg_sim, MIN(sim) as min_sim, MAX(sim) as max_sim, COUNT(*) as pair_count FROM pairs
""")
print(f"\n  同名对整体统计:")
print(f"    总配对数: {semb2[0]['pair_count']}")
print(f"    平均相似度: {float(semb2[0]['avg_sim']):.3f}")
print(f"    最低相似度: {float(semb2[0]['min_sim']):.3f}")
print(f"    最高相似度: {float(semb2[0]['max_sim']):.3f}")
