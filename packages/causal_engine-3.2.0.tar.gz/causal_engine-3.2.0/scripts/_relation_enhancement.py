"""
Relation Enhancement: upgrade knowledge-level relations to entity-level.

Steps:
  1. Map source_id/target_id (knowledge.id) → entity_id via knowledge.entity_id
  2. Group by (src_entity, tgt_entity, relation_type)
  3. Merge: aggregate confidence, collect all evidence descriptions, count sources
  4. Insert into public.entity_relations

Output:
  - public.entity_relations table
"""
import sys
import time
import json
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
TABLE = "public.entity_relations"


def create_table(storage):
    storage._execute_sql(f"""
        CREATE TABLE IF NOT EXISTS {TABLE} (
            id VARCHAR(36) PRIMARY KEY,
            source_entity_id VARCHAR(36) NOT NULL,
            target_entity_id VARCHAR(36) NOT NULL,
            relation_type VARCHAR(50) NOT NULL,
            confidence FLOAT NOT NULL,
            source_count INT DEFAULT 1,
            evidence_descriptions JSONB,
            source_names JSONB,
            target_names JSONB,
            created_at TIMESTAMP DEFAULT NOW(),
            FOREIGN KEY (source_entity_id) REFERENCES public.unified_entities(id),
            FOREIGN KEY (target_entity_id) REFERENCES public.unified_entities(id)
        )
    """, fetch=False, commit=True)

    storage._execute_sql(f"TRUNCATE {TABLE}", fetch=False, commit=True)
    print("entity_relations table ready")


def run_enhancement(storage):
    print("Step 1: Map relations to entity level...")
    t0 = time.time()

    entity_rels = storage._execute_sql("""
        SELECT
            k1.entity_id as src_entity,
            k2.entity_id as tgt_entity,
            r.relation_type,
            r.confidence,
            r.metadata_json->>'description' as description,
            k1.name as src_name,
            k2.name as tgt_name,
            r.source_id as orig_source_id,
            r.target_id as orig_target_id
        FROM relations r
        JOIN knowledge k1 ON r.source_id = k1.id::text
        JOIN knowledge k2 ON r.target_id = k2.id::text
        WHERE k1.entity_id IS NOT NULL AND k2.entity_id IS NOT NULL
    """)
    print(f"  Loaded {len(entity_rels)} knowledge-level relations")

    print("Step 2: Group and merge...")
    groups = {}
    for rel in entity_rels:
        key = (rel["src_entity"], rel["tgt_entity"], rel["relation_type"])
        if key not in groups:
            groups[key] = {
                "confidences": [],
                "descriptions": [],
                "src_names": set(),
                "tgt_names": set(),
            }
        groups[key]["confidences"].append(float(rel["confidence"]))
        desc = rel.get("description", "")
        if desc:
            groups[key]["descriptions"].append(desc)
        if rel.get("src_name"):
            groups[key]["src_names"].add(rel["src_name"])
        if rel.get("tgt_name"):
            groups[key]["tgt_names"].add(rel["tgt_name"])

    print(f"  {len(groups)} unique entity-level relations after dedup")

    print("Step 3: Compute aggregated confidence and insert...")

    def aggregate_confidence(confs):
        n = len(confs)
        if n == 1:
            return confs[0]
        avg = sum(confs) / n
        bonus = min(0.1 * (n - 1), 0.15)
        return min(avg + bonus, 1.0)

    stats = {"enables": 0, "causes": 0, "correlates": 0, "prevents": 0, "other": 0}
    batch_count = 0

    for (src_e, tgt_e, rel_type), data in groups.items():
        import uuid
        ent_id = str(uuid.uuid4())
        conf = aggregate_confidence(data["confidences"])
        src_count = len(data["confidences"])

        descs = data["descriptions"][:20]
        src_names = list(data["src_names"])[:5]
        tgt_names = list(data["tgt_names"])[:5]

        storage._execute_sql(f"""
            INSERT INTO {TABLE} (id, source_entity_id, target_entity_id, relation_type,
                                 confidence, source_count, evidence_descriptions,
                                 source_names, target_names)
            VALUES (:id, :src, :tgt, :rtype, :conf, :scnt,
                    CAST(:descs AS jsonb), CAST(:snames AS jsonb), CAST(:tnames AS jsonb))
        """, {
            "id": ent_id, "src": src_e, "tgt": tgt_e, "rtype": rel_type,
            "conf": conf, "scnt": src_count,
            "descs": json.dumps(descs, ensure_ascii=False),
            "snames": json.dumps(src_names, ensure_ascii=False),
            "tnames": json.dumps(tgt_names, ensure_ascii=False),
        }, fetch=False, commit=True)

        if rel_type in stats:
            stats[rel_type] += 1
        else:
            stats["other"] += 1

        batch_count += 1
        if batch_count % 2000 == 0:
            print(f"    {batch_count}/{len(groups)}")

    elapsed = time.time() - t0
    print(f"\nEnhancement done ({elapsed:.1f}s)")
    print(f"  Total entity relations: {len(groups)}")
    for k, v in stats.items():
        if v > 0:
            print(f"    {k}: {v}")


def verify(storage):
    print(f"\n{'='*60}")
    print("Verification")
    print("="*60)

    total = storage._execute_sql(f"SELECT COUNT(*) as cnt FROM {TABLE}")
    multi = storage._execute_sql(f"""
        SELECT COUNT(*) as cnt FROM {TABLE} WHERE source_count > 1
    """)
    avg_conf = storage._execute_sql(f"""
        SELECT relation_type, AVG(confidence) as avg_c, MIN(confidence) as min_c,
               MAX(confidence) as max_c, COUNT(*) as cnt
        FROM {TABLE} GROUP BY relation_type ORDER BY cnt DESC
    """)

    print(f"  Total entity relations: {total[0]['cnt']}")
    print(f"  Multi-source relations: {multi[0]['cnt']}")
    print(f"\n  By type:")
    for row in avg_conf:
        print(f"    {row['relation_type']}: {row['cnt']} | "
              f"conf avg={float(row['avg_c']):.3f} range=[{float(row['min_c']):.2f}-{float(row['max_c']):.2f}]")

    top_multi = storage._execute_sql(f"""
        SELECT er.relation_type, er.confidence, er.source_count,
               e1.canonical_name as src_name, e2.canonical_name as tgt_name
        FROM {TABLE} er
        JOIN public.unified_entities e1 ON er.source_entity_id = e1.id
        JOIN public.unified_entities e2 ON er.target_entity_id = e2.id
        ORDER BY er.source_count DESC, er.confidence DESC
        LIMIT 15
    """)
    print(f"\n  Top multi-source relations:")
    for row in top_multi:
        print(f"    {row['src_name']} --[{row['relation_type']}]--> {row['tgt_name']} "
              f"| conf={float(row['confidence']):.3f} | {row['source_count']} sources")

    top_conf = storage._execute_sql(f"""
        SELECT er.relation_type, er.confidence, er.source_count,
               e1.canonical_name as src_name, e2.canonical_name as tgt_name
        FROM {TABLE} er
        JOIN public.unified_entities e1 ON er.source_entity_id = e1.id
        JOIN public.unified_entities e2 ON er.target_entity_id = e2.id
        WHERE er.source_count >= 2
        ORDER BY er.confidence DESC
        LIMIT 10
    """)
    if top_conf:
        print(f"\n  Highest confidence multi-source relations:")
        for row in top_conf:
            print(f"    {row['src_name']} --[{row['relation_type']}]--> {row['tgt_name']} "
                  f"| conf={float(row['confidence']):.3f}")


if __name__ == "__main__":
    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()
    create_table(storage)
    run_enhancement(storage)
    verify(storage)
