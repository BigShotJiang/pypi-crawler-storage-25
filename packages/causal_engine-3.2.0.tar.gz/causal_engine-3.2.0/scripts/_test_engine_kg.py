"""
End-to-end test: CausalEngine with KG Reasoner integration.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.core.causal_engine import CausalEngine

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"


def main():
    storage = PostgreSQLStorage(DB_URL)
    storage.initialize()

    engine = CausalEngine(storage)
    print("=== CausalEngine + KG Reasoner Integration Test ===\n")

    # 1. Enable KG reasoner
    print("1. Enabling KG reasoner...")
    result = engine.enable_kg_reasoner()
    print(f"   Result: {result}\n")

    # 2. Check stats
    print("2. Engine stats:")
    stats = engine.get_stats()
    for k, v in stats.items():
        print(f"   {k}: {v}")
    print()

    # 3. Trace chain forward from 格物
    print("3. Trace forward from '格物':")
    chains = engine.trace_chain("格物", direction="forward", max_depth=3)
    print(f"   Found {len(chains)} chains")
    for i, c in enumerate(chains[:5]):
        path = " -> ".join(l["to"] for l in c["chain"])
        print(f"   Chain {i+1}: 格物 -> {path} (conf={c['confidence']}, cross={c['cross_text']})")
    print()

    # 4. Trace chain backward to 知行合一
    print("4. Trace backward to '知行合一':")
    chains = engine.trace_chain("知行合一", direction="backward", max_depth=3)
    print(f"   Found {len(chains)} chains")
    for i, c in enumerate(chains[:5]):
        path = " -> ".join(l["from"] for l in c["chain"])
        print(f"   Chain {i+1}: {path} -> 知行合一 (conf={c['confidence']})")
    print()

    # 5. Find chain between two concepts
    print("5. Find chains: 心即理 -> 致良知")
    chains = engine.find_chain_between("心即理", "致良知", max_depth=4)
    print(f"   Found {len(chains)} paths")
    for i, c in enumerate(chains[:3]):
        path = " -> ".join(
            [c["chain"][0]["from"]] + [l["to"] for l in c["chain"]]
        )
        print(f"   Path {i+1}: {path} (conf={c['confidence']}, len={c['length']})")
    print()

    # 6. Discover transitive relations
    print("6. Discover transitive relations (top 15):")
    discovered = engine.discover_relations(min_confidence=0.55, max_length=2)
    cross = [d for d in discovered if d["cross_text"]]
    print(f"   Total: {len(discovered)}, Cross-text: {len(cross)}")
    for i, d in enumerate(discovered[:15]):
        evidence = " -> ".join(e["from"] for e in d["evidence_chain"]) + " -> " + d["evidence_chain"][-1]["to"]
        print(f"   {i+1}. {d['source']} --[{d['relation_type']}]--> {d['target']} "
              f"(conf={d['confidence']}, cross={d['cross_text']})")
        print(f"      via: {evidence}")
    print()

    # 7. Cross-text discoveries
    if cross:
        print("7. Cross-text discoveries:")
        for i, d in enumerate(cross[:10]):
            print(f"   {i+1}. {d['source']} --[{d['relation_type']}]--> {d['target']} "
                  f"(conf={d['confidence']})")
            evidence = " -> ".join(e["from"] for e in d["evidence_chain"]) + " -> " + d["evidence_chain"][-1]["to"]
            print(f"      via: {evidence}")

    storage.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
