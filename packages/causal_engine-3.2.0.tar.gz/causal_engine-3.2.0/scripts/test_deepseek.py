"""
测试 DeepSeek API 连接
"""

import asyncio
import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.llm import create_llm_provider

async def test_deepseek():
    print("=" * 60)
    print("测试 DeepSeek API")
    print("=" * 60)
    
    llm = create_llm_provider({
        "provider": "openai",
        "api_key": "sk-ff312533ad1e41c896885cce8f5d2e4d",
        "model": "deepseek-chat",
        "base_url": "https://api.deepseek.com/v1",
        "temperature": 0.3,
        "max_tokens": 1024,
    })
    
    print("\n发送测试请求...")
    
    try:
        response = await llm.chat([
            {"role": "user", "content": "你好，请用一句话介绍商鞅变法。"}
        ])
        
        print(f"\n✅ API 测试成功！")
        print(f"\n回复内容:\n{response}")
        
        usage = llm.get_usage()
        print(f"\n用量统计:")
        print(f"  请求次数: {usage.get('request_count', 0)}")
        print(f"  Token 用量: {usage.get('total_tokens', 0)}")
        print(f"  预估费用: ${usage.get('cost_usd', 0):.4f}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ API 测试失败: {e}")
        return False

if __name__ == "__main__":
    success = asyncio.run(test_deepseek())
    sys.exit(0 if success else 1)
