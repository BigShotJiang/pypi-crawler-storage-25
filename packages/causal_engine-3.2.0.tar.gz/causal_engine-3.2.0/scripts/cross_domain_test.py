"""
跨领域验证实验：用古代因果知识分析诺基亚衰落

实验逻辑：
1. 从数据库搜索与诺基亚衰落相关的因果模式
2. 用古代兵法/历史的因果知识去"解释"现代商业事件
3. 评估这些因果模式是否具有跨领域通用性
"""

import sys
import json
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
storage = PostgreSQLStorage(database_url=DB_URL)
storage.initialize()

keywords_map = {
    "骄傲/自满 → 判断失误": ["骄", "傲", "满", "自满", "恃"],
    "固守旧法/不创新": ["守", "固", "不变", "拘", "旧"],
    "忽视对手/轻敌": ["轻", "忽", "敌", "备", "懈"],
    "内部不和/分裂": ["不和", "内", "争", "离", "叛"],
    "决策失误/无谋": ["谋", "策", "算", "庙算", "断"],
    "失去民心/市场": ["民", "心", "众", "信", "德"],
}

print("=" * 70)
print("跨领域因果验证：诺基亚衰落 vs 古代因果知识")
print("=" * 70)

all_matches = []

for theme, keywords in keywords_map.items():
    print(f"\n{'='*60}")
    print(f"主题: {theme}")
    print(f"{'='*60}")

    for kw in keywords:
        rows = storage._execute_sql("""
            SELECT k.id, k.name, k.knowledge_json->>'content' as content,
                   k.knowledge_json->>'knowledge_type' as ktype,
                   k.knowledge_json->'sources'->0->>'title' as source,
                   k.knowledge_json->'sources'->0->'extra_info'->>'dynasty' as dynasty
            FROM knowledge k
            WHERE k.name ILIKE :q1 OR k.knowledge_json->>'content' ILIKE :q2
            LIMIT 5
        """, {"q1": f"%{kw}%", "q2": f"%{kw}%"})

        for r in rows:
            rels = storage._execute_sql("""
                SELECT r.relation_type, r.metadata_json->>'description' as desc,
                       t.name as target_name
                FROM relations r JOIN knowledge t ON r.target_id = t.id
                WHERE r.source_id = :sid
            """, {"sid": r["id"]})

            if rels:
                print(f"\n  [{r['ktype']}] {r['name']} ({r['source']}, {r['dynasty']})")
                print(f"    {(r['content'] or '')[:100]}")
                for rel in rels:
                    print(f"      --[{rel['relation_type']}]--> {rel['target_name']}")
                    print(f"         {(rel['desc'] or '')[:120]}")
                all_matches.append({
                    "theme": theme,
                    "name": r["name"],
                    "type": r["ktype"],
                    "source": r["source"],
                    "content": (r["content"] or "")[:150],
                    "relations": [{"type": rel["relation_type"], "target": rel["target_name"], "desc": (rel["desc"] or "")[:150]} for rel in rels]
                })

print(f"\n{'='*70}")
print(f"总计: 找到 {len(all_matches)} 条相关因果知识")
print(f"{'='*70}")

print("\n\n" + "=" * 70)
print("诺基亚衰落的关键事件（对照用）")
print("=" * 70)
print("""
诺基亚衰落核心因果链（公认版）:
1. 2007年 iPhone 发布 → 诺基亚高层轻视，认为"不是威胁"
2. 塞班系统老旧 → 无法适应触屏时代 → 但诺基亚固守塞班
3. 内部组织僵化 → 各部门各自为战 → 决策缓慢
4. 微软合作失败 → 内部进一步分裂 → 人才流失
5. 最终：市场份额从 40% 跌至 3% → 出售手机业务
""")

print("=" * 70)
print("古代因果知识 → 诺基亚映射分析")
print("=" * 70)

mappings = [
    {
        "nokia_event": "诺基亚2007年市场份额40%，自认无敌",
        "ancient_match": None,
        "theme": "骄傲/自满 → 判断失误"
    },
    {
        "nokia_event": "忽视 iPhone 威胁，认为触屏是噱头",
        "ancient_match": None,
        "theme": "忽视对手/轻敌"
    },
    {
        "nokia_event": "固守塞班系统，拒绝安卓",
        "ancient_match": None,
        "theme": "固守旧法/不创新"
    },
    {
        "nokia_event": "内部部门各自为战，决策缓慢",
        "ancient_match": None,
        "theme": "内部不和/分裂"
    },
]

for m in mappings:
    matches = [a for a in all_matches if a["theme"] == m["theme"]]
    m["ancient_match"] = matches[:3]

    print(f"\n现代事件: {m['nokia_event']}")
    print(f"因果主题: {m['theme']}")
    if matches:
        print(f"古代匹配 ({len(matches)} 条):")
        for match in matches[:3]:
            print(f"  [{match['type']}] {match['name']} ({match['source']})")
            print(f"    {match['content'][:100]}")
            for rel in match["relations"][:2]:
                print(f"    --[{rel['type']}]--> {rel['target']}")
                print(f"       {rel['desc'][:100]}")
    else:
        print("  ⚠️ 未找到匹配")
