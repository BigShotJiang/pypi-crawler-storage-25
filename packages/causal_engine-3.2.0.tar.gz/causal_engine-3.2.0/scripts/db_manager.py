#!/usr/bin/env python3
"""
PostgreSQL 数据库管理工具

功能:
- 查看数据库状态
- 备份和恢复
- 清理数据
- 性能诊断
- 图查询

使用方式:
    python scripts/db_manager.py status     # 查看状态
    python scripts/db_manager.py backup     # 备份
    python scripts/db_manager.py clean      # 清理
    python scripts/db_manager.py diagnose   # 诊断
    python scripts/db_manager.py query      # 执行 Cypher 查询
"""

import sys
import argparse
import json
from pathlib import Path
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from generic_causal_architecture.storage import PostgreSQLStorage


def get_storage():
    """创建存储实例"""
    return PostgreSQLStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db",
        pool_size=5,
        echo=False
    )


def cmd_status(args):
    """查看数据库状态"""
    print("=" * 80)
    print("数据库状态")
    print("=" * 80)
    
    storage = get_storage()
    storage.initialize()
    
    # 基本信息
    print("\n基本信息:")
    stats = storage.get_statistics()
    print(f"  事件数量：{stats['event_count']}")
    print(f"  关系数量：{stats['relation_count']}")
    print(f"  存储类型：{stats['storage_type']}")
    
    # 表大小
    print("\n表大小:")
    result = storage._execute_sql("""
        SELECT 
            relname AS table_name,
            pg_size_pretty(pg_total_relation_size(relid)) AS total_size,
            pg_size_pretty(pg_relation_size(relid)) AS data_size,
            pg_size_pretty(pg_total_relation_size(relid) - pg_relation_size(relid)) AS index_size
        FROM pg_catalog.pg_statio_user_tables
        ORDER BY pg_total_relation_size(relid) DESC
    """)
    
    for row in result:
        print(f"  {row['table_name']}: {row['total_size']} (数据：{row['data_size']}, 索引：{row['index_size']})")
    
    # 数据库大小
    print("\n数据库大小:")
    result = storage._execute_sql("SELECT pg_size_pretty(pg_database_size(current_database()))")
    print(f"  {result[0][0]}")
    
    # 连接数
    print("\n连接数:")
    result = storage._execute_sql("""
        SELECT count(*) as active_connections 
        FROM pg_stat_activity 
        WHERE datname = current_database()
    """)
    print(f"  活跃连接：{result[0]['active_connections']}")
    
    print("\n" + "=" * 80)


def cmd_backup(args):
    """备份数据库"""
    print("=" * 80)
    print("备份数据库")
    print("=" * 80)
    
    storage = get_storage()
    storage.initialize()
    
    # 生成备份文件名
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"data/backup_{timestamp}.json"
    
    # 导出所有事件
    print("\n导出事件...")
    events = storage._execute_sql("SELECT * FROM events")
    events_data = [dict(row) for row in events]
    print(f"  ✓ 导出 {len(events_data)} 个事件")
    
    # 导出所有关系
    print("\n导出关系...")
    relations = storage._execute_sql("SELECT * FROM relations")
    relations_data = [dict(row) for row in relations]
    print(f"  ✓ 导出 {len(relations_data)} 个关系")
    
    # 保存为 JSON
    backup_data = {
        'timestamp': timestamp,
        'events': events_data,
        'relations': relations_data
    }
    
    # 创建 data 目录
    Path("data").mkdir(exist_ok=True)
    
    with open(backup_file, 'w', encoding='utf-8') as f:
        json.dump(backup_data, f, ensure_ascii=False, indent=2)
    
    print(f"\n✓ 备份完成：{backup_file}")
    print("=" * 80)


def cmd_clean(args):
    """清理数据"""
    print("=" * 80)
    print("清理数据")
    print("=" * 80)
    
    if not args.confirm:
        print("\n⚠ 警告：此操作将删除所有测试数据！")
        response = input("确认删除？(yes/no): ")
        if response.lower() != 'yes':
            print("已取消")
            return
    
    storage = get_storage()
    storage.initialize()
    
    # 删除测试数据
    print("\n删除测试数据...")
    storage._execute_sql("DELETE FROM relations WHERE source_id LIKE 'test_%'", fetch=False)
    storage._execute_sql("DELETE FROM events WHERE id LIKE 'test_%'", fetch=False)
    print("✓ 测试数据已删除")
    
    # 可选：删除所有数据
    if args.all:
        print("\n删除所有数据...")
        response = input("确认删除所有数据？(yes/no): ")
        if response.lower() == 'yes':
            storage._execute_sql("DELETE FROM relations", fetch=False)
            storage._execute_sql("DELETE FROM events", fetch=False)
            print("✓ 所有数据已删除")
    
    print("\n" + "=" * 80)


def cmd_diagnose(args):
    """性能诊断"""
    print("=" * 80)
    print("性能诊断")
    print("=" * 80)
    
    storage = get_storage()
    storage.initialize()
    
    # 检查索引
    print("\n索引使用情况:")
    result = storage._execute_sql("""
        SELECT 
            schemaname,
            tablename,
            indexname,
            idx_scan as index_scans,
            pg_size_pretty(pg_relation_size(indexrelid)) as index_size
        FROM pg_stat_user_indexes
        ORDER BY tablename, indexname
    """)
    
    for row in result:
        print(f"  {row['tablename']}.{row['indexname']}: "
              f"扫描 {row['index_scans']} 次，大小 {row['index_size']}")
    
    # 慢查询
    print("\n慢查询统计:")
    result = storage._execute_sql("""
        SELECT 
            query,
            calls,
            mean_exec_time,
            total_exec_time
        FROM pg_stat_statements
        ORDER BY total_exec_time DESC
        LIMIT 5
    """)
    
    if result:
        for row in result:
            print(f"  查询：{row['query'][:50]}...")
            print(f"    调用：{row['calls']} 次，平均：{row['mean_exec_time']:.2f}ms, "
                  f"总计：{row['total_exec_time']:.2f}ms")
    else:
        print("  (需要启用 pg_stat_statements 扩展)")
    
    # 表健康状态
    print("\n表健康状态:")
    result = storage._execute_sql("""
        SELECT 
            relname,
            last_vacuum,
            last_autovacuum,
            last_analyze,
            last_autoanalyze
        FROM pg_stat_user_tables
        ORDER BY relname
    """)
    
    for row in result:
        print(f"  {row['relname']}:")
        print(f"    最后清理：{row['last_autovacuum'] or row['last_vacuum'] or '从未'}")
        print(f"    最后分析：{row['last_autoanalyze'] or row['last_analyze'] or '从未'}")
    
    print("\n" + "=" * 80)


def cmd_query(args):
    """执行 Cypher 查询"""
    print("=" * 80)
    print("Cypher 查询")
    print("=" * 80)
    
    storage = get_storage()
    storage.initialize()
    
    # 交互式查询
    if args.query:
        cypher = args.query
    else:
        print("\n输入 Cypher 查询 (输入 'quit' 退出):")
        while True:
            cypher = input("cypher> ").strip()
            if cypher.lower() in ['quit', 'exit', 'q']:
                break
            
            try:
                result = storage._execute_cypher(cypher)
                if result:
                    print(f"\n结果：{len(result)} 行")
                    for row in result[:10]:  # 只显示前 10 行
                        print(f"  {row}")
                    if len(result) > 10:
                        print(f"  ... 还有 {len(result) - 10} 行")
                else:
                    print("  (无结果)")
            except Exception as e:
                print(f"  ❌ 错误：{e}")
    
    print("=" * 80)


def main():
    parser = argparse.ArgumentParser(description='PostgreSQL 数据库管理工具')
    subparsers = parser.add_subparsers(dest='command', help='命令')
    
    # status 命令
    status_parser = subparsers.add_parser('status', help='查看数据库状态')
    status_parser.set_defaults(func=cmd_status)
    
    # backup 命令
    backup_parser = subparsers.add_parser('backup', help='备份数据库')
    backup_parser.set_defaults(func=cmd_backup)
    
    # clean 命令
    clean_parser = subparsers.add_parser('clean', help='清理数据')
    clean_parser.add_argument('--confirm', action='store_true', help='确认删除')
    clean_parser.add_argument('--all', action='store_true', help='删除所有数据')
    clean_parser.set_defaults(func=cmd_clean)
    
    # diagnose 命令
    diagnose_parser = subparsers.add_parser('diagnose', help='性能诊断')
    diagnose_parser.set_defaults(func=cmd_diagnose)
    
    # query 命令
    query_parser = subparsers.add_parser('query', help='执行 Cypher 查询')
    query_parser.add_argument('query', nargs='?', help='Cypher 查询语句')
    query_parser.set_defaults(func=cmd_query)
    
    args = parser.parse_args()
    
    if args.command:
        args.func(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
