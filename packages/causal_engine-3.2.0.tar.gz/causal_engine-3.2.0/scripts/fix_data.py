"""
补丁脚本：修复 relations 表并从 knowledge_json 提取关系数据

问题：relations 表的 FOREIGN KEY 指向 events 表，但数据都在 knowledge 表
修复：删除旧外键，重建指向 knowledge 表的外键，然后从 knowledge_json 提取关系

使用方法：
    python scripts/fix_data.py
"""

import sys
from pathlib import Path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import json
from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"


def fix_foreign_keys(storage: PostgreSQLStorage):
    print("=" * 60)
    print("Step 1: 修复外键约束")
    print("=" * 60)

    try:
        storage._execute_sql("""
            ALTER TABLE relations 
            DROP CONSTRAINT IF EXISTS relations_source_id_fkey,
            DROP CONSTRAINT IF EXISTS relations_target_id_fkey
        """, fetch=False, commit=True)
        print("已删除旧外键约束")
    except Exception as e:
        print("删除外键失败（可能不存在）:", e)

    try:
        storage._execute_sql("""
            ALTER TABLE relations
            ADD CONSTRAINT relations_source_id_fkey 
                FOREIGN KEY (source_id) REFERENCES knowledge(id) ON DELETE CASCADE,
            ADD CONSTRAINT relations_target_id_fkey 
                FOREIGN KEY (target_id) REFERENCES knowledge(id) ON DELETE CASCADE
        """, fetch=False, commit=True)
        print("已创建新外键约束（指向 knowledge 表）")
    except Exception as e:
        print("创建新外键失败:", e)


def fix_relations(storage: PostgreSQLStorage):
    print("\n" + "=" * 60)
    print("Step 2: 从 knowledge_json 提取关系到 relations 表")
    print("=" * 60)

    knowledge_with_rels = storage._execute_sql("""
        SELECT id, knowledge_json->'relations' as rels
        FROM knowledge
        WHERE knowledge_json->'relations' IS NOT NULL
        AND jsonb_array_length(knowledge_json->'relations') > 0
    """)
    print("找到 {} 条知识有关系数据".format(len(knowledge_with_rels)))

    total_rels = 0
    inserted_rels = 0
    skipped_no_target = 0
    skipped_broken = 0
    errors = 0

    existing_rels = storage._execute_sql("""
        SELECT source_id, target_id FROM relations
    """)
    existing_set = set()
    for er in existing_rels:
        existing_set.add((er["source_id"], er["target_id"]))

    all_knowledge_ids = set()
    id_batch = storage._execute_sql("SELECT id FROM knowledge")
    for r in id_batch:
        all_knowledge_ids.add(r["id"])

    for row in knowledge_with_rels:
        source_id = row["id"]
        rels = row["rels"]
        for rel in rels:
            total_rels += 1
            target_id = rel.get("target_id", "")
            if not target_id:
                skipped_no_target += 1
                continue

            if target_id not in all_knowledge_ids:
                skipped_broken += 1
                continue

            rel_type = rel.get("type", "related")
            confidence = rel.get("strength", 0.5)

            key = (source_id, target_id)
            if key in existing_set:
                continue

            metadata = {
                "description": rel.get("description", ""),
                "target_name": rel.get("target_name", ""),
            }

            try:
                storage._execute_sql("""
                    INSERT INTO relations (source_id, target_id, relation_type, confidence, metadata_json, created_at, updated_at)
                    VALUES (:sid, :tid, :rtype, :conf, :meta, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
                    ON CONFLICT DO NOTHING
                """, {
                    "sid": source_id,
                    "tid": target_id,
                    "rtype": rel_type,
                    "conf": confidence,
                    "meta": json.dumps(metadata, ensure_ascii=False),
                }, fetch=False, commit=True)
                inserted_rels += 1
                existing_set.add(key)
            except Exception as e:
                errors += 1
                if errors <= 3:
                    print("  ERROR: {} -> {}: {}".format(source_id[:8], target_id[:8], str(e)[:80]))

    print("总关系数:", total_rels)
    print("新插入:", inserted_rels)
    print("跳过(无target_id):", skipped_no_target)
    print("跳过(target不存在于knowledge):", skipped_broken)
    print("错误:", errors)


def print_summary(storage: PostgreSQLStorage):
    print("\n" + "=" * 60)
    print("修复后统计")
    print("=" * 60)

    total_k = storage._execute_sql("SELECT COUNT(*) as cnt FROM knowledge")
    total_r = storage._execute_sql("SELECT COUNT(*) as cnt FROM relations")
    print("知识总数:", total_k[0]["cnt"])
    print("关系总数:", total_r[0]["cnt"])

    rel_types = storage._execute_sql("""
        SELECT relation_type, COUNT(*) as cnt
        FROM relations GROUP BY relation_type ORDER BY cnt DESC
    """)
    print("\n关系类型分布:")
    for rt in rel_types:
        print("  {}: {}".format(rt["relation_type"], rt["cnt"]))

    connected = storage._execute_sql("""
        SELECT COUNT(DISTINCT k.id) as cnt FROM knowledge k
        WHERE EXISTS (SELECT 1 FROM relations r WHERE r.source_id = k.id OR r.target_id = k.id)
    """)
    isolated = storage._execute_sql("""
        SELECT COUNT(*) as cnt FROM knowledge k
        WHERE NOT EXISTS (SELECT 1 FROM relations r WHERE r.source_id = k.id OR r.target_id = k.id)
    """)
    print("\n有连接的知识:", connected[0]["cnt"])
    print("孤立的知识:", isolated[0]["cnt"])

    source_info = storage._execute_sql("""
        SELECT 
            knowledge_json->'sources'->0->>'title' as book_title,
            COUNT(*) as cnt
        FROM knowledge
        WHERE jsonb_array_length(knowledge_json->'sources') > 0
        GROUP BY book_title
        ORDER BY cnt DESC
        LIMIT 15
    """)
    print("\n按书籍分布 (Top 15):")
    for s in source_info:
        print("  {}: {} 条".format(s["book_title"], s["cnt"]))


if __name__ == "__main__":
    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()

    fix_foreign_keys(storage)
    fix_relations(storage)
    print_summary(storage)

    print("\n完成！")
