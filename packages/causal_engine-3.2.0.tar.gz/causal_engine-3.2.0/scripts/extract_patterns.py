"""
从数据库提取抽象因果模式，用于跨领域验证。
"""

import sys
import json
from pathlib import Path
from collections import Counter

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
storage = PostgreSQLStorage(database_url=DB_URL)
storage.initialize()

print("=" * 70)
print("1. 关系类型分布 + 典型因果链")
print("=" * 70)

rel_types = storage._execute_sql("""
    SELECT relation_type, COUNT(*) as cnt FROM relations
    GROUP BY relation_type ORDER BY cnt DESC
""")
for rt in rel_types:
    print(f"\n--- {rt['relation_type']} ({rt['cnt']} 条) ---")
    samples = storage._execute_sql(f"""
        SELECT r.source_id, r.target_id, r.metadata_json->>'description' as desc,
               s.name as src_name, t.name as tgt_name
        FROM relations r
        JOIN knowledge s ON r.source_id = s.id
        JOIN knowledge t ON r.target_id = t.id
        WHERE r.relation_type = '{rt['relation_type']}'
        AND LENGTH(r.metadata_json->>'description') > 30
        ORDER BY RANDOM() LIMIT 3
    """)
    for s in samples:
        print(f"  {s['src_name']} --> {s['tgt_name']}")
        print(f"    {s['desc'][:150]}")

print("\n" + "=" * 70)
print("2. 高连接度枢纽节点（跨概念因果中心）")
print("=" * 70)

hubs = storage._execute_sql("""
    SELECT k.name, k.knowledge_json->>'content' as content,
           k.knowledge_json->>'knowledge_type' as ktype,
           COUNT(r.target_id) as out_count
    FROM knowledge k
    JOIN relations r ON k.id = r.source_id
    GROUP BY k.id, k.name, k.knowledge_json, ktype
    HAVING COUNT(r.target_id) >= 5
    ORDER BY out_count DESC LIMIT 15
""")
for h in hubs:
    print(f"\n  [{h['ktype']}] {h['name']} (关系数: {h['out_count']})")
    print(f"    {(h['content'] or '')[:120]}")

    targets = storage._execute_sql("""
        SELECT t.name, r.relation_type, r.metadata_json->>'description' as desc
        FROM relations r JOIN knowledge t ON r.target_id = t.id
        WHERE r.source_id = :sid LIMIT 5
    """, {"sid": h['name']})
    for t in targets:
        print(f"      --[{t['relation_type']}]--> {t['name']}")

print("\n" + "=" * 70)
print("3. 因果链路径（2-3步连贯因果）")
print("=" * 70)

chains = storage._execute_sql("""
    SELECT r1.source_id as start_id, s1.name as start_name,
           r1.target_id as mid_id, m.name as mid_name,
           r2.target_id as end_id, e.name as end_name,
           r1.relation_type as rel1, r2.relation_type as rel2,
           r1.metadata_json->>'description' as desc1,
           r2.metadata_json->>'description' as desc2
    FROM relations r1
    JOIN relations r2 ON r1.target_id = r2.source_id
    JOIN knowledge s1 ON r1.source_id = s1.id
    JOIN knowledge m ON r1.target_id = m.id
    JOIN knowledge e ON r2.target_id = e.id
    WHERE LENGTH(r1.metadata_json->>'description') > 30
    AND LENGTH(r2.metadata_json->>'description') > 30
    AND r1.source_id != r2.target_id
    ORDER BY RANDOM() LIMIT 10
""")

for c in chains:
    print(f"\n  {c['start_name']} --[{c['rel1']}]--> {c['mid_name']} --[{c['rel2']}]--> {c['end_name']}")
    print(f"    步骤1: {(c['desc1'] or '')[:120]}")
    print(f"    步骤2: {(c['desc2'] or '')[:120]}")

print("\n" + "=" * 70)
print("4. 知识类型分布")
print("=" * 70)

types = storage._execute_sql("""
    SELECT knowledge_json->>'knowledge_type' as ktype, COUNT(*) as cnt
    FROM knowledge GROUP BY knowledge_json->>'knowledge_type'
    ORDER BY cnt DESC
""")
for t in types:
    print(f"  {t['ktype']}: {t['cnt']}")
