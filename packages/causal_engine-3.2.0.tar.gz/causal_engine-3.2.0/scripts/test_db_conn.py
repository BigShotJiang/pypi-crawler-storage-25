"""Test database connection"""
import sys
import io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

print("Testing database connection...")
print()

# Test 1: pg8000 with causal_user
print("=== Test 1: pg8000 (causal_user / password123) ===")
try:
    import pg8000
    print(f"  pg8000 version: {pg8000.__version__}")
    conn = pg8000.connect(
        host='127.0.0.1',
        port=5432,
        user='causal_user',
        password='password123',
        database='causal_db'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT current_user, current_database()")
    row = cursor.fetchone()
    print(f"  SUCCESS! user={row[0]}, db={row[1]}")
    conn.close()
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")

print()

# Test 2: pg8000 with postgres user
print("=== Test 2: pg8000 (postgres / causal_password) ===")
try:
    import pg8000
    conn = pg8000.connect(
        host='127.0.0.1',
        port=5432,
        user='postgres',
        password='causal_password',
        database='causal_db'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT current_user, current_database()")
    row = cursor.fetchone()
    print(f"  SUCCESS! user={row[0]}, db={row[1]}")
    conn.close()
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")

print()

# Test 3: pg8000 with postgres / password123
print("=== Test 3: pg8000 (postgres / password123) ===")
try:
    import pg8000
    conn = pg8000.connect(
        host='127.0.0.1',
        port=5432,
        user='postgres',
        password='password123',
        database='causal_db'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT current_user, current_database()")
    row = cursor.fetchone()
    print(f"  SUCCESS! user={row[0]}, db={row[1]}")
    conn.close()
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")

print()

# Test 4: psycopg2
print("=== Test 4: psycopg2 (causal_user / password123) ===")
try:
    import psycopg2
    conn = psycopg2.connect(
        host='127.0.0.1',
        port=5432,
        user='causal_user',
        password='password123',
        dbname='causal_db'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT current_user, current_database()")
    row = cursor.fetchone()
    print(f"  SUCCESS! user={row[0]}, db={row[1]}")
    conn.close()
except ImportError:
    print("  SKIPPED: psycopg2 not installed")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")

print()

# Test 5: psycopg2 with postgres
print("=== Test 5: psycopg2 (postgres / causal_password) ===")
try:
    import psycopg2
    conn = psycopg2.connect(
        host='127.0.0.1',
        port=5432,
        user='postgres',
        password='causal_password',
        dbname='causal_db'
    )
    cursor = conn.cursor()
    cursor.execute("SELECT current_user, current_database()")
    row = cursor.fetchone()
    print(f"  SUCCESS! user={row[0]}, db={row[1]}")
    conn.close()
except ImportError:
    print("  SKIPPED: psycopg2 not installed")
except Exception as e:
    print(f"  FAILED: {type(e).__name__}: {e}")

print()
print("Done!")
