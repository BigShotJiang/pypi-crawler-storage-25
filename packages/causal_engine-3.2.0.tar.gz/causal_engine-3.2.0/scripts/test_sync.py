"""
测试脚本：将已有知识同步到 AGE 图
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

print("=" * 60)
print("知识同步测试")
print("=" * 60)

storage = PostgreSQLStorage(
    database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
)
storage.initialize()

print("\n1. 读取现有知识...")
all_knowledge = storage.list_knowledge(limit=100)
print(f"   找到 {len(all_knowledge)} 个知识")

print("\n2. 逐个同步到 AGE 图...")
for ku in all_knowledge:
    print(f"   - [{ku.knowledge_type.value}] {ku.name}")
    storage._sync_knowledge_to_graph(ku)

print("\n3. 查询 AGE 图状态...")
stats = storage.get_graph_stats()
print(f"   节点数: {stats['total_nodes']}")
print(f"   边数: {stats['total_edges']}")

print("\n4. 测试邻居查询...")
if all_knowledge:
    first_ku = all_knowledge[0]
    result = storage.query_neighbors_via_graph(first_ku.name)
    print(f"   '{first_ku.name}' 的邻居:")
    for n in result['neighbors']:
        print(f"     - {n['name']} ({n['relation']})")

print("\n" + "=" * 60)
print("同步完成！")
print("=" * 60)

storage.close()
