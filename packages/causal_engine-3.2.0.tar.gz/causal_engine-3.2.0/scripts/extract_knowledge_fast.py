"""
高速知识提取脚本 - 优化版本

优化策略：
1. 并发 API 调用 - 同时处理多个章节
2. 连接池 - 复用数据库连接
3. 批量写入 - 减少数据库操作次数
4. 异步流水线 - 提取和存储并行

使用方法：
    python scripts/extract_knowledge_fast.py --all --max-concurrent 10
"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import argparse
import asyncio
import json
import logging
from datetime import datetime
from typing import List, Tuple, Optional
from tqdm import tqdm
import aiohttp
from concurrent.futures import ThreadPoolExecutor

from generic_causal_architecture.llm import create_llm_provider
from generic_causal_architecture.books.postgresql_storage import PostgreSQLBookStorage
from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.knowledge.models import (
    KnowledgeUnit, KnowledgeType, Evidence, Source, Relation, VerificationStatus
)
from generic_causal_architecture.books.models import Book

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

EXTRACTION_PROMPT = """你是一个专业的古籍知识提取专家。请从以下古籍文本中提取因果知识和事件信息。

## 提取要求

1. **知识单元 (knowledge)**: 提取文本中的重要概念、事件、人物、策略等
   - name: 知识名称（简洁，10字以内）
   - content: 详细内容（50-200字）
   - knowledge_type: 类型（event-事件, concept-概念, person-人物, strategy-策略, rule-规律, other-其他）
   - confidence: 置信度（0.0-1.0）
   - evidence: 证据列表，包含原文引用

2. **因果关系 (relations)**: 识别知识单元之间的因果、条件、影响关系
   - source_name: 原因/前提知识名称
   - target_name: 结果/影响知识名称
   - type: 关系类型（causes-导致, enables-使能, prevents-阻止, correlates-相关）
   - description: 关系描述
   - strength: 关系强度（0.0-1.0）

## 古籍信息
- 书名: {book_title}
- 章节: {section_title}
- 朝代: {dynasty}
- 作者: {author}

## 文本内容
{content}

## 输出格式
请严格按照以下 JSON 格式输出，不要添加任何其他文字：

```json
{{
  "knowledge": [
    {{
      "name": "知识名称",
      "content": "详细描述...",
      "knowledge_type": "event",
      "confidence": 0.9,
      "evidence": [
        {{
          "content": "原文引用",
          "type": "literature",
          "strength": 0.9,
          "supports": true
        }}
      ]
    }}
  ],
  "relations": [
    {{
      "source_name": "原因知识名称",
      "target_name": "结果知识名称",
      "type": "causes",
      "description": "关系描述",
      "strength": 0.8
    }}
  ]
}}
```

注意：
1. 只输出 JSON，不要有其他文字
2. 确保知识名称在 knowledge 和 relations 中一致
3. 如果没有因果关系，relations 可以为空数组
4. 确保 JSON 格式正确，可以被解析
"""


class FastKnowledgeExtractor:
    """高速知识提取器 - 支持并发处理"""
    
    def __init__(
        self,
        llm,
        storage: PostgreSQLStorage,
        max_concurrent: int = 10,
        batch_size: int = 50
    ):
        self.llm = llm
        self.storage = storage
        self.max_concurrent = max_concurrent
        self.batch_size = batch_size
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.extracted_sections = self._load_extracted_sections()
        
    def _load_extracted_sections(self) -> set:
        """加载已提取的章节记录"""
        try:
            result = self.storage._execute_sql(
                "SELECT DISTINCT metadata->>'section_id' as section_id FROM knowledge "
                "WHERE metadata->>'section_id' IS NOT NULL"
            )
            return set(row['section_id'] for row in result if row['section_id'])
        except Exception as e:
            logger.warning(f"加载已提取记录失败: {e}")
            return set()
    
    async def extract_from_section(
        self,
        section,
        book: Book
    ) -> Tuple[List[KnowledgeUnit], List[str], str]:
        """从单个章节提取知识（带并发控制）"""
        async with self.semaphore:
            if not section.content or len(section.content.strip()) < 20:
                return [], [], "内容太短，跳过"
            
            # 检查是否已提取
            if section.id in self.extracted_sections:
                return [], [], "已提取，跳过"
            
            prompt = EXTRACTION_PROMPT.format(
                book_title=book.title,
                section_title=section.title,
                dynasty=book.dynasty or "未知",
                author=book.author or "未知",
                content=section.content[:3000]
            )
            
            try:
                response = await self.llm.chat(
                    [{"role": "user", "content": prompt}],
                    temperature=0.3,
                    max_tokens=4096
                )
                
                # 解析 JSON
                response_clean = response.strip()
                if response_clean.startswith("```json"):
                    response_clean = response_clean[7:]
                if response_clean.startswith("```"):
                    response_clean = response_clean[3:]
                if response_clean.endswith("```"):
                    response_clean = response_clean[:-3]
                response_clean = response_clean.strip()
                
                data = json.loads(response_clean)
                
                # 构建知识单元
                knowledge_items = []
                name_to_id = {}
                
                for item_data in data.get("knowledge", []):
                    ku = self._create_knowledge_unit(item_data, book, section)
                    if ku:
                        knowledge_items.append(ku)
                        name_to_id[ku.name] = ku.id
                
                # 构建关系
                for rel_data in data.get("relations", []):
                    self._add_relation(rel_data, knowledge_items, name_to_id)
                
                # 批量存储
                if knowledge_items:
                    await self._batch_store(knowledge_items)
                
                self.extracted_sections.add(section.id)
                
                return knowledge_items, [], "成功"
                
            except json.JSONDecodeError as e:
                return [], [], f"JSON解析失败: {e}"
            except Exception as e:
                return [], [], f"提取失败: {e}"
    
    def _create_knowledge_unit(
        self,
        item_data: dict,
        book: Book,
        section
    ) -> Optional[KnowledgeUnit]:
        """创建知识单元"""
        try:
            evidence_list = []
            for ev in item_data.get("evidence", []):
                evidence_list.append(Evidence(
                    content=ev.get("content", ""),
                    type=ev.get("type", "literature"),
                    strength=ev.get("strength", 0.5),
                    supports=ev.get("supports", True)
                ))
            
            knowledge_type_str = item_data.get("knowledge_type", "event")
            try:
                knowledge_type = KnowledgeType(knowledge_type_str)
            except ValueError:
                knowledge_type = KnowledgeType.EVENT
            
            verification_str = item_data.get("verification_status", "unverified")
            try:
                verification_status = VerificationStatus(verification_str)
            except ValueError:
                verification_status = VerificationStatus.UNVERIFIED
            
            return KnowledgeUnit(
                name=item_data.get("name", ""),
                content=item_data.get("content", ""),
                knowledge_type=knowledge_type,
                confidence=item_data.get("confidence", 0.5),
                verification_status=verification_status,
                evidence=evidence_list,
                sources=[
                    Source(
                        type="literature",
                        title=book.title,
                        author=book.author,
                        extra_info={
                            "dynasty": book.dynasty,
                            "category": book.category,
                            "section_title": section.title,
                            "section_id": section.id,
                        }
                    )
                ],
                metadata={
                    "book_id": book.id,
                    "section_id": section.id,
                    "extraction_time": datetime.now().isoformat(),
                }
            )
        except Exception as e:
            logger.warning(f"创建知识单元失败: {e}")
            return None
    
    def _add_relation(
        self,
        rel_data: dict,
        knowledge_items: List[KnowledgeUnit],
        name_to_id: dict
    ):
        """添加关系到知识单元"""
        source_name = rel_data.get("source_name", "")
        target_name = rel_data.get("target_name", "")
        source_id = name_to_id.get(source_name)
        target_id = name_to_id.get(target_name)
        
        if source_id and target_id:
            for ku in knowledge_items:
                if ku.id == source_id:
                    ku.relations.append(Relation(
                        type=rel_data.get("type", "related"),
                        target_id=target_id,
                        description=rel_data.get("description", ""),
                        strength=rel_data.get("strength", 0.5)
                    ))
    
    async def _batch_store(self, knowledge_items: List[KnowledgeUnit]):
        """批量存储知识单元"""
        # 使用线程池执行同步存储操作
        loop = asyncio.get_event_loop()
        for ku in knowledge_items:
            await loop.run_in_executor(None, self.storage.add_knowledge, ku)
    
    async def process_book(
        self,
        book: Book,
        max_sections: int = 20
    ) -> Tuple[int, int]:
        """处理一本书，返回 (成功章节数, 总知识数)"""
        sections_to_process = []
        for section in book.sections[:max_sections]:
            if section.id not in self.extracted_sections:
                sections_to_process.append(section)
        
        if not sections_to_process:
            return 0, 0
        
        tasks = [
            self.extract_from_section(section, book)
            for section in sections_to_process
        ]
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        total_knowledge = 0
        success_count = 0
        
        for result in results:
            if isinstance(result, Exception):
                logger.warning(f"处理章节异常: {result}")
                continue
            knowledge_items, _, status = result
            if status == "成功":
                success_count += 1
                total_knowledge += len(knowledge_items)
        
        return success_count, total_knowledge


async def main():
    parser = argparse.ArgumentParser(description='高速古籍知识提取工具')
    parser.add_argument('--all', action='store_true', help='处理所有书籍')
    parser.add_argument('--book', type=str, help='指定书名关键词')
    parser.add_argument('--category', type=str, help='指定分类')
    parser.add_argument('--max-sections', type=int, default=20, help='每本书最大章节数')
    parser.add_argument('--max-concurrent', type=int, default=10, help='最大并发数')
    parser.add_argument('--batch-size', type=int, default=50, help='批处理大小')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("古籍因果知识提取工具 - 高速版")
    print("=" * 60)
    
    storage = PostgreSQLStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
    )
    storage.initialize()
    
    book_storage = PostgreSQLBookStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db",
        schema="books"
    )
    
    # DeepSeek API 配置
    api_key = "sk-ff312533ad1e41c896885cce8f5d2e4d"
    base_url = "https://api.deepseek.com/v1"
    model = "deepseek-chat"
    
    print(f"\n🤖 使用 DeepSeek API")
    print(f"   模型: {model}")
    print(f"   API: {base_url}")
    print(f"   并发数: {args.max_concurrent}")
    
    llm = create_llm_provider({
        "provider": "openai",
        "api_key": api_key,
        "model": model,
        "base_url": base_url,
        "temperature": 0.3,
        "max_tokens": 4096,
    })
    
    # 创建高速提取器
    extractor = FastKnowledgeExtractor(
        llm=llm,
        storage=storage,
        max_concurrent=args.max_concurrent,
        batch_size=args.batch_size
    )
    
    print(f"\n📚 正在加载书籍列表...")
    
    # 获取要处理的书籍
    if args.book:
        all_books = book_storage.get_all_books(limit=1000)
        books = [b for b in all_books if args.book in b.title]
    elif args.category:
        books = book_storage.get_all_books(category=args.category, limit=1000)
    elif args.all:
        books = book_storage.get_all_books(limit=1000)
    else:
        print("❌ 请指定 --all, --book 或 --category")
        return
    
    if not books:
        print("❌ 没有找到匹配的书籍")
        return
    
    # 加载完整书籍数据
    full_books = []
    for b in books:
        full_book = book_storage.get_book(b.id)
        if full_book:
            full_books.append(full_book)
    
    total_sections = sum(len(b.sections) for b in full_books)
    print(f"找到 {len(full_books)} 本书，共 {total_sections} 个章节")
    print(f"已提取章节: {len(extractor.extracted_sections)} 个")
    
    # 处理书籍
    start_time = datetime.now()
    total_knowledge = 0
    processed_books = 0
    
    for i, book in enumerate(full_books, 1):
        print(f"\n[{i}/{len(full_books)}] 📖 《{book.title}》({book.author or '不详'})")
        
        success_count, knowledge_count = await extractor.process_book(
            book, max_sections=args.max_sections
        )
        
        if success_count > 0:
            print(f"  ✅ {success_count} 章节, {knowledge_count} 知识")
            total_knowledge += knowledge_count
            processed_books += 1
        elif success_count == 0 and knowledge_count == 0:
            print(f"  ⏭️  所有章节已提取，跳过")
        else:
            print(f"  ⚠️  提取失败")
    
    # 统计
    elapsed = (datetime.now() - start_time).total_seconds()
    print(f"\n{'='*60}")
    print("提取完成!")
    print(f"  处理书籍: {processed_books}/{len(full_books)}")
    print(f"  总知识数: {total_knowledge}")
    print(f"  耗时: {elapsed:.1f} 秒")
    print(f"  平均速度: {total_knowledge/elapsed*60:.1f} 知识/分钟")
    
    # 显示用量
    usage = llm.get_usage()
    print(f"\n📊 API 用量:")
    print(f"  请求次数: {usage.get('request_count', 0)}")
    print(f"  Token 用量: {usage.get('total_tokens', 0)}")
    print(f"  预估费用: ${usage.get('cost_usd', 0):.4f}")


if __name__ == "__main__":
    asyncio.run(main())
