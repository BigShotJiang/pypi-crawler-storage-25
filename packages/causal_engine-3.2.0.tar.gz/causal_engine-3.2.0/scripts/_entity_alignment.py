"""
Entity alignment: group same-name knowledge entries into unified entities.
"""
import sys
import time
import uuid
import json
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
TABLE = "public.unified_entities"
SIM_AUTO = 0.80
SIM_MIN = 0.60


def create_tables(storage):
    storage._execute_sql(f"""
        CREATE TABLE IF NOT EXISTS {TABLE} (
            id VARCHAR(36) PRIMARY KEY,
            canonical_name VARCHAR(500) NOT NULL,
            knowledge_count INT DEFAULT 0,
            avg_similarity FLOAT,
            traditions JSONB,
            sources JSONB,
            alignment_status VARCHAR(20) NOT NULL DEFAULT 'auto',
            created_at TIMESTAMP DEFAULT NOW()
        )
    """, fetch=False, commit=True)

    col = storage._execute_sql("""
        SELECT column_name FROM information_schema.columns
        WHERE table_name = 'knowledge' AND column_name = 'entity_id'
    """)
    if not col:
        storage._execute_sql("ALTER TABLE knowledge ADD COLUMN entity_id VARCHAR(36)",
                             fetch=False, commit=True)

    storage._execute_sql(f"TRUNCATE {TABLE}", fetch=False, commit=True)
    storage._execute_sql("UPDATE knowledge SET entity_id = NULL WHERE entity_id IS NOT NULL",
                         fetch=False, commit=True)
    print("Tables ready")


def run_alignment(storage):
    print("Loading duplicate name groups...")
    dup_groups = storage._execute_sql("""
        SELECT name, COUNT(*) as cnt
        FROM knowledge GROUP BY name HAVING COUNT(*) > 1 ORDER BY cnt DESC
    """)
    print(f"  {len(dup_groups)} duplicate groups")

    stats = {"auto_merge": 0, "needs_review": 0, "separate": 0}
    t0 = time.time()

    for gi, group in enumerate(dup_groups):
        name = group["name"]
        entries = storage._execute_sql("""
            SELECT id, knowledge_json->'sources'->0->>'title' as source,
                   knowledge_json->'perspective'->>'tradition' as tradition
            FROM knowledge WHERE name = :n ORDER BY id
        """, {"n": name})

        entity_id = str(uuid.uuid4())
        traditions = list(set(e["tradition"] for e in entries if e["tradition"]))
        sources = list(set(e["source"] for e in entries if e["source"]))

        if len(entries) > 1:
            avg_sim = compute_avg_similarity(storage, entries)
            if avg_sim >= SIM_AUTO:
                status = "auto_merge"
            elif avg_sim >= SIM_MIN:
                status = "needs_review"
            else:
                status = "separate"
        else:
            avg_sim = None
            status = "auto"

        storage._execute_sql(f"""
            INSERT INTO {TABLE} (id, canonical_name, knowledge_count, avg_similarity,
                                 traditions, sources, alignment_status)
            VALUES (:eid, :name, :cnt, :sim,
                    CAST(:trads AS jsonb), CAST(:srcs AS jsonb), :status)
        """, {
            "eid": entity_id, "name": name, "cnt": len(entries),
            "sim": avg_sim,
            "trads": json.dumps(traditions, ensure_ascii=False),
            "srcs": json.dumps(sources, ensure_ascii=False),
            "status": status,
        }, fetch=False, commit=True)

        for entry in entries:
            storage._execute_sql("UPDATE knowledge SET entity_id = :eid WHERE id = :kid",
                                 {"eid": entity_id, "kid": entry["id"]},
                                 fetch=False, commit=True)

        if status in stats:
            stats[status] += 1

        if (gi + 1) % 100 == 0:
            elapsed = time.time() - t0
            rate = (gi + 1) / elapsed
            eta = (len(dup_groups) - gi - 1) / rate
            print(f"  {gi+1}/{len(dup_groups)} | {rate:.0f} groups/s | ETA {eta:.0f}s")

    print(f"\nCreating singleton entities...")
    singletons = storage._execute_sql("""
        SELECT id, name, knowledge_json->'perspective'->>'tradition' as tradition,
               knowledge_json->'sources'->0->>'title' as source
        FROM knowledge WHERE entity_id IS NULL
    """)
    for i, s in enumerate(singletons):
        entity_id = str(uuid.uuid4())
        trads = [s["tradition"]] if s["tradition"] else []
        srcs = [s["source"]] if s["source"] else []
        storage._execute_sql(f"""
            INSERT INTO {TABLE} (id, canonical_name, knowledge_count, traditions, sources, alignment_status)
            VALUES (:eid, :name, 1, CAST(:trads AS jsonb), CAST(:srcs AS jsonb), 'auto')
        """, {
            "eid": entity_id, "name": s["name"],
            "trads": json.dumps(trads, ensure_ascii=False),
            "srcs": json.dumps(srcs, ensure_ascii=False),
        }, fetch=False, commit=True)
        storage._execute_sql("UPDATE knowledge SET entity_id = :eid WHERE id = :kid",
                             {"eid": entity_id, "kid": s["id"]}, fetch=False, commit=True)
        if (i + 1) % 2000 == 0:
            print(f"    {i+1}/{len(singletons)}")

    elapsed = time.time() - t0
    print(f"\nAlignment done ({elapsed:.1f}s)")
    print(f"  Multi-knowledge entities: {len(dup_groups)}")
    print(f"  auto_merge: {stats['auto_merge']}")
    print(f"  needs_review: {stats['needs_review']}")
    print(f"  separate: {stats['separate']}")
    print(f"  Singletons: {len(singletons)}")
    print(f"  Total entities: {len(dup_groups) + len(singletons)}")


def compute_avg_similarity(storage, entries):
    if len(entries) < 2:
        return None
    total_sim = 0.0
    pair_count = 0
    ids = [e["id"] for e in entries]
    for i in range(len(ids)):
        for j in range(i + 1, len(ids)):
            row = storage._execute_sql("""
                SELECT 1 - (a.embedding <=> b.embedding) as sim
                FROM knowledge a, knowledge b
                WHERE a.id = :id1 AND b.id = :id2
            """, {"id1": ids[i], "id2": ids[j]})
            if row:
                total_sim += float(row[0]["sim"])
                pair_count += 1
    return total_sim / pair_count if pair_count > 0 else None


def verify(storage):
    print(f"\n{'='*60}")
    print("Verification")
    print("="*60)

    total_e = storage._execute_sql(f"SELECT COUNT(*) as cnt FROM {TABLE}")
    total_k = storage._execute_sql("SELECT COUNT(*) as cnt FROM knowledge WHERE entity_id IS NOT NULL")
    all_k = storage._execute_sql("SELECT COUNT(*) as cnt FROM knowledge")

    print(f"  Total entities: {total_e[0]['cnt']}")
    print(f"  Linked knowledge: {total_k[0]['cnt']}/{all_k[0]['cnt']}")

    status_dist = storage._execute_sql(f"""
        SELECT alignment_status, COUNT(*) as cnt FROM {TABLE} GROUP BY alignment_status
    """)
    for s in status_dist:
        print(f"    {s['alignment_status']}: {s['cnt']}")

    multi = storage._execute_sql(f"""
        SELECT canonical_name, knowledge_count, avg_similarity, alignment_status
        FROM {TABLE} WHERE knowledge_count > 1
        ORDER BY knowledge_count DESC LIMIT 15
    """)
    print(f"\n  Top multi-knowledge entities:")
    for m in multi:
        sim = f"{float(m['avg_similarity']):.3f}" if m['avg_similarity'] else "N/A"
        print(f"    {m['canonical_name']}: {m['knowledge_count']} | sim={sim} | {m['alignment_status']}")

    review = storage._execute_sql(f"""
        SELECT canonical_name, knowledge_count, avg_similarity
        FROM {TABLE} WHERE alignment_status = 'needs_review'
        ORDER BY avg_similarity ASC LIMIT 10
    """)
    if review:
        print(f"\n  Needs review (potential homonyms):")
        for r in review:
            print(f"    {r['canonical_name']}: {r['knowledge_count']} | sim={float(r['avg_similarity']):.3f}")


if __name__ == "__main__":
    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()
    create_tables(storage)
    run_alignment(storage)
    verify(storage)
