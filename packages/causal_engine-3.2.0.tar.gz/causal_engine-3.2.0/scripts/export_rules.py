#!/usr/bin/env python
"""
Export causal rules from PostgreSQL to a portable JSON file.

Usage:
    python scripts/export_rules.py [options] -o game_rules.json

    # Export everything
    python scripts/export_rules.py -o rules.json

    # Export only high-confidence rules (>= 0.7)
    python scripts/export_rules.py -o rules.json --min-confidence 0.7

    # Export rules matching specific keywords
    python scripts/export_rules.py -o rules.json --filter "仁政,暴政"

    # Export with meta-patterns included
    python scripts/export_rules.py -o rules.json --include-meta-patterns

Output format (RulePack JSON):
    {
        "version": "1.0",
        "exported_at": "2026-04-05T12:00:00",
        "source": "postgresql://...",
        "stats": { "entities": 150, "relations": 300, "meta_patterns": 8 },
        "entities": [
            { "name": "提高税收", "type": "policy", "description": "" }
        ],
        "relations": [
            {
                "source": "提高税收",
                "target": "民众不满",
                "relation_type": "causes",
                "confidence": 0.82,
                "conditions": { "catalysts": ["天灾"], "inhibitors": ["仁政"] }
            }
        ],
        "meta_patterns": [
            {
                "name": "资源耗竭→崩溃",
                "abstract_logic": "...",
                "mechanism": "...",
                "keywords": ["耗竭", "枯竭", "匮乏"],
                ...
            }
        ]
    }
"""

import argparse
import json
import os
import sys
import io
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

sys.path.insert(0, str(Path(__file__).parent.parent))


def get_storage():
    from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
    db_url = os.environ.get(
        "DATABASE_URL",
        "postgresql://postgres:causal_password@localhost:5432/causal_db",
    )
    storage = PostgreSQLStorage(database_url=db_url)
    storage.initialize()
    return storage


def export_entities(storage, keyword_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    sql = "SELECT canonical_name, entity_type, description FROM public.unified_entities"
    params: Dict[str, Any] = {}

    if keyword_filter:
        conditions = []
        for kw in keyword_filter.split(","):
            kw = kw.strip()
            if kw:
                param_name = f"kw_{len(params)}"
                conditions.append(f"canonical_name LIKE :{param_name}")
                params[param_name] = f"%{kw}%"
        if conditions:
            sql += " WHERE " + " OR ".join(conditions)

    rows = storage._execute_sql(sql, params)
    entities = []
    for row in rows:
        entities.append({
            "name": row["canonical_name"],
            "type": row.get("entity_type", "action_entity"),
            "description": row.get("description", ""),
        })
    return entities


def export_relations(
    storage,
    min_confidence: float = 0.0,
    keyword_filter: Optional[str] = None,
) -> List[Dict[str, Any]]:
    sql = (
        "SELECT "
        "  ue_src.canonical_name AS source_name, "
        "  ue_tgt.canonical_name AS target_name, "
        "  er.relation_type, "
        "  er.confidence, "
        "  er.metadata "
        "FROM public.entity_relations er "
        "JOIN public.unified_entities ue_src ON er.source_entity_id = ue_src.id "
        "JOIN public.unified_entities ue_tgt ON er.target_entity_id = ue_tgt.id "
        "WHERE er.confidence >= :min_conf"
    )
    params: Dict[str, Any] = {"min_conf": min_confidence}

    if keyword_filter:
        conditions = []
        for kw in keyword_filter.split(","):
            kw = kw.strip()
            if kw:
                param_name = f"kw_{len(params)}"
                conditions.append(
                    f"(ue_src.canonical_name LIKE :{param_name} "
                    f"OR ue_tgt.canonical_name LIKE :{param_name})"
                )
                params[param_name] = f"%{kw}%"
        if conditions:
            sql += " AND (" + " OR ".join(conditions) + ")"

    sql += " ORDER BY er.confidence DESC"

    rows = storage._execute_sql(sql, params)
    relations = []
    for row in rows:
        metadata = {}
        raw_meta = row.get("metadata")
        if raw_meta:
            if isinstance(raw_meta, str):
                try:
                    metadata = json.loads(raw_meta)
                except (json.JSONDecodeError, TypeError):
                    metadata = {}
            elif isinstance(raw_meta, dict):
                metadata = raw_meta

        conditions = metadata.get("conditions", {})
        if isinstance(conditions, str):
            try:
                conditions = json.loads(conditions)
            except (json.JSONDecodeError, TypeError):
                conditions = {}

        rel_entry = {
            "source": row["source_name"],
            "target": row["target_name"],
            "relation_type": row["relation_type"],
            "confidence": float(row["confidence"]),
        }
        if conditions:
            rel_entry["conditions"] = conditions

        relations.append(rel_entry)

    return relations


def export_meta_patterns() -> List[Dict[str, Any]]:
    from generic_causal_architecture.core.meta_patterns import MetaPatternStore

    store = MetaPatternStore()
    patterns = store.list_all()
    result = []
    for p in patterns:
        result.append({
            "name": p.name,
            "abstract_logic": p.abstract_logic,
            "mechanism": p.mechanism,
            "generality": p.generality,
            "confidence": p.confidence,
            "modern_analogy": p.modern_analogy,
            "keywords": p.keywords,
            "cross_domain_value": p.cross_domain_value,
            "source_patterns": p.source_patterns,
        })
    return result


def main():
    parser = argparse.ArgumentParser(description="Export causal rules from PostgreSQL to JSON")
    parser.add_argument("-o", "--output", required=True, help="Output JSON file path")
    parser.add_argument(
        "--min-confidence", type=float, default=0.0,
        help="Minimum confidence threshold (default: 0.0, export all)",
    )
    parser.add_argument(
        "--filter", dest="keyword_filter", default=None,
        help="Comma-separated keywords to filter entities/relations by name",
    )
    parser.add_argument(
        "--include-meta-patterns", action="store_true",
        help="Include built-in meta-patterns in export",
    )
    parser.add_argument(
        "--pretty", action="store_true",
        help="Pretty-print JSON output",
    )
    args = parser.parse_args()

    print(f"Connecting to PostgreSQL...")
    storage = get_storage()

    print(f"Exporting entities...")
    entities = export_entities(storage, keyword_filter=args.keyword_filter)
    print(f"  Found {len(entities)} entities")

    print(f"Exporting relations (min_confidence={args.min_confidence})...")
    relations = export_relations(
        storage,
        min_confidence=args.min_confidence,
        keyword_filter=args.keyword_filter,
    )
    print(f"  Found {len(relations)} relations")

    meta_patterns = []
    if args.include_meta_patterns:
        print(f"Exporting meta-patterns...")
        meta_patterns = export_meta_patterns()
        print(f"  Found {len(meta_patterns)} meta-patterns")

    rule_pack = {
        "version": "1.0",
        "exported_at": datetime.now().isoformat(),
        "source": "postgresql",
        "stats": {
            "entities": len(entities),
            "relations": len(relations),
            "meta_patterns": len(meta_patterns),
        },
        "entities": entities,
        "relations": relations,
        "meta_patterns": meta_patterns,
    }

    os.makedirs(os.path.dirname(os.path.abspath(args.output)), exist_ok=True)

    indent = 2 if args.pretty else None
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(rule_pack, f, ensure_ascii=False, indent=indent)

    file_size = os.path.getsize(args.output)
    size_str = f"{file_size / 1024:.1f} KB" if file_size < 1024 * 1024 else f"{file_size / (1024 * 1024):.1f} MB"

    print(f"\n{'='*60}")
    print(f"Export complete!")
    print(f"  File: {args.output}")
    print(f"  Size: {size_str}")
    print(f"  Entities: {len(entities)}")
    print(f"  Relations: {len(relations)}")
    print(f"  Meta-patterns: {len(meta_patterns)}")
    print(f"{'='*60}")


if __name__ == "__main__":
    main()
