"""
Test KnowledgeGraphReasoner with real data.
"""
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.core.kg_reasoner import KnowledgeGraphReasoner

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"


def main():
    storage = PostgreSQLStorage(DB_URL)
    storage.initialize()

    reasoner = KnowledgeGraphReasoner(storage)
    n_nodes, n_edges = reasoner.load_graph()
    print(f"Graph: {n_nodes} nodes, {n_edges} edges\n")

    # Test 1: find a well-known entity
    test_names = ["心即理", "知行合一", "致良知", "格物", "道", "仁"]
    for name in test_names:
        eid = reasoner.get_entity_id(name)
        if eid:
            print(f"  Found: {name} -> {eid[:8]}...")
        else:
            print(f"  NOT found: {name}")

    print("\n" + "=" * 60)

    # Test 2: trace forward from a key concept
    for name in ["心即理", "格物"]:
        eid = reasoner.get_entity_id(name)
        if not eid:
            print(f"\n[{name}] not found, skipping")
            continue

        chains = reasoner.trace_forward(name, max_depth=3)
        print(f"\n[{name}] Forward chains: {len(chains)}")
        for i, chain in enumerate(chains[:5]):
            print(f"  Chain {i+1}: {chain.start_name} -> ... -> {chain.end_name} "
                  f"(len={chain.length}, conf={chain.total_confidence:.3f}, "
                  f"cross={chain.cross_text})")
            for link in chain.links:
                print(f"    {link.source_name} --[{link.relation_type}]--> "
                      f"{link.target_name} ({link.confidence:.3f})")

    print("\n" + "=" * 60)

    # Test 3: trace between two concepts
    pairs = [("心即理", "知行合一"), ("格物", "致良知")]
    for src, tgt in pairs:
        chains = reasoner.trace_between(src, tgt, max_depth=4)
        print(f"\n[{src} -> {tgt}] Chains: {len(chains)}")
        for i, chain in enumerate(chains[:3]):
            print(f"  Chain {i+1}: conf={chain.total_confidence:.3f}, "
                  f"len={chain.length}, cross={chain.cross_text}")
            for link in chain.links:
                print(f"    {link.source_name} --[{link.relation_type}]--> "
                      f"{link.target_name} ({link.confidence:.3f})")

    print("\n" + "=" * 60)

    # Test 4: discover transitive relations (limited for testing)
    print("\nDiscovering transitive relations (max_length=2)...")
    inferred = reasoner.discover_transitive(min_confidence=0.55, max_length=2)
    print(f"Total discovered: {len(inferred)}")

    cross_count = sum(1 for r in inferred if r.cross_text)
    print(f"Cross-text: {cross_count}")

    print("\nTop 10 discovered relations:")
    for i, rel in enumerate(inferred[:10]):
        print(f"  {i+1}. {rel.source_name} --[{rel.relation_type}]--> "
              f"{rel.target_name} (conf={rel.confidence:.3f}, "
              f"len={rel.chain_length}, cross={rel.cross_text})")
        print(f"     Evidence: {' -> '.join(e['from'] for e in rel.evidence_chain)}"
              f" -> {rel.evidence_chain[-1]['to']}")

    storage.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
