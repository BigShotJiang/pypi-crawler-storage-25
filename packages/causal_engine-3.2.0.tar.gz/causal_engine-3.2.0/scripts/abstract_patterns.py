"""
因果模式抽象管线 v2

方案：用 LLM 直接做语义分组 + 抽象（不需要 embedding API）

流程：
1. 从数据库提取所有因果关系
2. 分批让 LLM 识别因果模式
3. 汇总去重，得到最终模式列表

用法:
    cd t:\Item\AI\discuss\sources\generic-causal-architecture
    python scripts/abstract_patterns.py
"""

import sys
import json
import time
from pathlib import Path
from collections import defaultdict

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import requests as http_requests

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
DEEPSEEK_API_KEY = "sk-ff312533ad1e41c896885cce8f5d2e4d"
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"


def call_llm(prompt: str, temperature: float = 0.3) -> str:
    resp = http_requests.post(
        f"{DEEPSEEK_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {DEEPSEEK_API_KEY}"},
        json={
            "model": "deepseek-chat",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": 4096,
        },
        timeout=60,
    )
    if resp.status_code != 200:
        raise Exception(f"API error {resp.status_code}: {resp.text[:200]}")
    return resp.json()["choices"][0]["message"]["content"]


def extract_json(text: str):
    for start_char, end_char in [("[", "]"), ("{", "}")]:
        json_start = text.find(start_char)
        if json_start == -1:
            continue
        depth = 0
        in_string = False
        escape_next = False
        for i in range(json_start, len(text)):
            c = text[i]
            if escape_next:
                escape_next = False
                continue
            if c == "\\":
                escape_next = True
                continue
            if c == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if c == start_char:
                depth += 1
            elif c == end_char:
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[json_start : i + 1])
                    except json.JSONDecodeError:
                        break
    return None


def extract_relations(storage) -> list[dict]:
    print("\n[Step 1] 提取所有因果关系...")
    rows = storage._execute_sql("""
        SELECT r.source_id, r.target_id, r.relation_type,
               r.metadata_json->>'description' as description,
               r.confidence,
               s.name as source_name, s.knowledge_json->>'content' as source_content,
               s.knowledge_json->>'knowledge_type' as source_type,
               s.knowledge_json->'sources'->0->>'title' as source_book,
               t.name as target_name, t.knowledge_json->>'knowledge_type' as target_type
        FROM relations r
        JOIN knowledge s ON r.source_id = s.id
        JOIN knowledge t ON r.target_id = t.id
        WHERE LENGTH(r.metadata_json->>'description') > 10
    """)

    relations = []
    for r in rows:
        if not r["description"] or len(r["description"].strip()) < 10:
            continue
        relations.append({
            "source_name": r["source_name"],
            "target_name": r["target_name"],
            "relation_type": r["relation_type"],
            "description": r["description"],
            "confidence": r["confidence"],
            "source_book": r["source_book"],
            "source_type": r["source_type"],
            "target_type": r["target_type"],
        })

    print(f"  有效关系: {len(relations)} 条")
    return relations


def batch_identify_patterns(relations: list[dict], batch_size: int = 40) -> list[dict]:
    print(f"\n[Step 2] LLM 分批识别模式 (每批 {batch_size} 条)...")
    all_patterns = []
    total_batches = (len(relations) + batch_size - 1) // batch_size

    shuffled = list(relations)
    import random
    random.seed(42)
    random.shuffle(shuffled)

    for batch_idx in range(total_batches):
        batch = shuffled[batch_idx * batch_size : (batch_idx + 1) * batch_size]

        examples = ""
        for i, r in enumerate(batch, 1):
            examples += f"\n{i}. {r['source_name']} --[{r['relation_type']}]--> {r['target_name']}"
            examples += f"\n   因果: {r['description'][:150]}"
            examples += f"\n   来源: {r['source_book']} ({r['source_type']})\n"

        prompt = f"""分析以下{len(batch)}条因果关系，识别其中的因果模式。

{examples}

要求：
1. 将这些因果归纳为 3-8 个通用因果模式
2. 每个模式要抽象掉具体人名地名，保留因果机制
3. 评估每个模式的跨领域通用性

直接输出 JSON 数组（不要输出任何其他文字，不要用 markdown 代码块）：
[
  {{
    "pattern_name": "模式名称（4字以内）",
    "abstract_logic": "抽象因果逻辑",
    "mechanism": "因果传导机制（50字内）",
    "generality": "high/medium/low",
    "generality_reason": "为什么是这个等级",
    "modern_analogy": "现代场景中的具体类比",
    "matched_examples": [1, 3, 5]
  }}
]

matched_examples 是上面编号列表中符合该模式的序号。只输出真正的因果模式。"""

        for retry in range(2):
            try:
                print(f"  批次 {batch_idx+1}/{total_batches} ({len(batch)} 条)...", end=" ")
                result = call_llm(prompt)
                cleaned = result.strip()
                if cleaned.startswith("```"):
                    cleaned = cleaned.split("\n", 1)[-1]
                    if cleaned.endswith("```"):
                        cleaned = cleaned[:-3]
                    cleaned = cleaned.strip()
                patterns = extract_json(cleaned)

                if patterns and isinstance(patterns, list):
                    for p in patterns:
                        p["batch"] = batch_idx
                        p["batch_count"] = len(batch)
                    all_patterns.extend(patterns)
                    print(f"得到 {len(patterns)} 个模式")
                    break
                else:
                    if retry == 0:
                        print(f"解析失败，重试...")
                    else:
                        print(f"解析失败")
            except Exception as e:
                if retry == 0:
                    print(f"错误，重试: {e}")
                else:
                    print(f"错误: {e}")

        time.sleep(1)

    return all_patterns


def merge_patterns(patterns: list[dict]) -> list[dict]:
    print(f"\n[Step 3] 合并去重 ({len(patterns)} 个候选模式)...")

    name_groups = defaultdict(list)
    for p in patterns:
        name = p.get("pattern_name", "未知").strip()
        name_groups[name].append(p)

    merged = []
    for name, group in name_groups.items():
        best = max(group, key=lambda x: len(x.get("matched_examples", [])))
        best["merge_count"] = len(group)
        merged.append(best)

    merged.sort(key=lambda x: (x.get("generality", "low"), x.get("merge_count", 1)), reverse=True)

    print(f"  去重后: {len(merged)} 个唯一模式")
    return merged


def final_abstract(patterns: list[dict]) -> list[dict]:
    print(f"\n[Step 4] 最终抽象和评估...")

    high = [p for p in patterns if p.get("generality") == "high"]
    medium = [p for p in patterns if p.get("generality") == "medium"]
    low = [p for p in patterns if p.get("generality") == "low"]

    interesting = high + medium[:10]

    if not interesting:
        print("  没有高/中通用性模式，跳过最终抽象")
        return patterns

    summary = ""
    for i, p in enumerate(interesting, 1):
        summary += f"\n{i}. 【{p['pattern_name']}】{p['abstract_logic']}"
        summary += f"\n   机制: {p.get('mechanism', '')}"
        summary += f"\n   通用性: {p.get('generality', '')} | 出现次数: {p.get('merge_count', 1)}"
        summary += f"\n   现代类比: {p.get('modern_analogy', '')}\n"

    prompt = f"""以下是因果模式抽象的初步结果，请你进行最终评审：

{summary}

请对每个模式进行评审，输出 JSON 数组：
[
  {{
    "pattern_name": "模式名称",
    "final_generality": "high/medium/low",
    "cross_domain_value": "这个模式跨领域应用的真实价值评估（1-2句话）",
    "best_modern_application": "最合适的应用场景描述（要具体，比如'预测垄断企业因自满被颠覆的风险'）",
    "confidence": 0.0-1.0,
    "note": "额外说明（如果有）"
  }}
]

评审标准：
- high: 确实跨领域通用，机制清晰，有预测价值
- medium: 有一定通用性，但需要适配
- low: 过于具体或因果牵强"""

    try:
        result = call_llm(prompt, temperature=0.2)
        evaluations = extract_json(result)
        if evaluations:
            eval_map = {e["pattern_name"]: e for e in evaluations}
            for p in interesting:
                ev = eval_map.get(p["pattern_name"])
                if ev:
                    p["final_eval"] = ev
            print(f"  评审完成: {len(evaluations)} 个模式")
    except Exception as e:
        print(f"  评审失败: {e}")

    return patterns


def main():
    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()

    relations = extract_relations(storage)
    if not relations:
        print("没有可用的关系数据")
        return

    raw_patterns = batch_identify_patterns(relations)
    merged = merge_patterns(raw_patterns)
    final = final_abstract(merged)

    print(f"\n{'='*70}")
    print(f"最终结果")
    print(f"{'='*70}")

    for g in ["high", "medium", "low"]:
        group = [p for p in final if p.get("generality") == g]
        if not group:
            continue
        label = {"high": "高通用性", "medium": "中通用性", "low": "低通用性"}[g]
        print(f"\n{'─'*40}")
        print(f"{label} ({len(group)} 个)")
        print(f"{'─'*40}")
        for p in group:
            print(f"\n  【{p['pattern_name']}】(出现{p.get('merge_count',1)}次)")
            print(f"  逻辑: {p.get('abstract_logic', '')}")
            print(f"  机制: {p.get('mechanism', '')}")
            print(f"  现代类比: {p.get('modern_analogy', '')}")
            fe = p.get("final_eval", {})
            if fe:
                print(f"  最终评估: {fe.get('cross_domain_value', '')}")
                print(f"  最佳应用: {fe.get('best_modern_application', '')}")
                print(f"  置信度: {fe.get('confidence', '-')}")

    high_count = len([p for p in final if p.get("generality") == "high"])
    medium_count = len([p for p in final if p.get("generality") == "medium"])
    low_count = len([p for p in final if p.get("generality") == "low"])
    print(f"\n汇总: {len(final)} 个模式 | {high_count} 高 | {medium_count} 中 | {low_count} 低")

    output_path = project_root / "scripts" / "pattern_results.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(final, f, ensure_ascii=False, indent=2)
    print(f"结果已保存: {output_path}")


if __name__ == "__main__":
    main()
