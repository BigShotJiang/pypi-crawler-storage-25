"""
知识提取脚本 - 从古籍文献中提取因果知识

功能：
1. 从数据库读取古籍章节
2. 调用 LLM 提取因果知识（事件、理论、因果关系等）
3. 存入知识表并自动同步到 AGE 图
4. 支持增量提取（跳过已提取的章节）
5. 支持指定书籍/章节范围

使用方式：
    # 提取指定书籍的所有章节
    python scripts/extract_knowledge.py --book "孙子兵法"
    
    # 提取指定分类的所有书籍
    python scripts/extract_knowledge.py --category "子藏/兵家"
    
    # 提取所有未处理的书籍（增量模式）
    python scripts/extract_knowledge.py --all
    
    # 指定 LLM 模型和批次大小
    python scripts/extract_knowledge.py --book "论语" --model gpt-4o --batch-size 5

配置要求：
    环境变量 LLM_API_KEY 或 config/default.yaml 中的 llm.api_key
"""

import os
import sys
import io
import json
import asyncio
import argparse
import logging
import time
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.books.postgresql_storage import PostgreSQLBookStorage
from generic_causal_architecture.books.models import Book, BookSection
from generic_causal_architecture.knowledge.models import (
    KnowledgeUnit,
    KnowledgeType,
    VerificationStatus,
    Evidence,
    Source,
    Relation,
)
from generic_causal_architecture.llm import create_llm_provider

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)

EXTRACTION_PROMPT = """你是一位精通中国古代历史的因果分析专家。请从以下文言文文本中提取因果关系知识。

## 提取要求

1. **只提取有明确因果关系的知识**，不要提取纯描述性内容
2. **因果关系必须有逻辑依据**，不能是无关联的并列事件
3. **每个知识必须包含原文证据**

## 输出格式

请输出严格的 JSON 格式：

```json
{{
  "knowledge": [
    {{
      "name": "知识名称（简洁概括）",
      "content": "详细描述（包含因果关系说明）",
      "knowledge_type": "event|theory|methodology|concept|rule|pattern|causal_relation",
      "confidence": 0.0到1.0之间的置信度,
      "evidence": [
        {{
          "content": "原文中的关键句子",
          "type": "literature",
          "strength": 0.0到1.0,
          "supports": true
        }}
      ]
    }}
  ],
  "relations": [
    {{
      "type": "causes|supports|conflicts|related",
      "source_name": "源知识名称",
      "target_name": "目标知识名称",
      "description": "关系描述",
      "strength": 0.0到1.0
    }}
  ]
}}
```

## 知识类型说明
- event: 具体历史事件（如"商鞅变法"）
- theory: 理论或观点（如"改革强国论"）
- methodology: 方法论（如"远交近攻"）
- concept: 核心概念（如"仁政"）
- rule: 规律或法则（如"分久必合"）
- pattern: 因果模式（如"变法→国强→扩张"）
- causal_relation: 明确的因果关系

## 关系类型说明
- causes: A 导致 B（最核心的关系类型）
- supports: A 支持/佐证 B
- conflicts: A 与 B 矛盾/冲突
- related: A 与 B 相关（但没有直接因果）

## 待提取文本

出处：《{book_title}》- {section_title}
朝代：{dynasty}
作者：{author}

{content}

## 开始提取

请严格按照 JSON 格式输出，不要添加任何额外说明。如果文本中没有可提取的因果知识，输出空的 JSON：
{{"knowledge": [], "relations": []}}"""


EXTRACTED_SECTIONS_FILE = project_root / "data" / "extracted_sections.json"


def load_extracted_sections() -> set:
    if EXTRACTED_SECTIONS_FILE.exists():
        with open(EXTRACTED_SECTIONS_FILE, "r", encoding="utf-8") as f:
            return set(json.load(f))
    return set()


def save_extracted_sections(sections: set):
    EXTRACTED_SECTIONS_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(EXTRACTED_SECTIONS_FILE, "w", encoding="utf-8") as f:
        json.dump(list(sections), f, ensure_ascii=False, indent=2)


def get_books_to_process(
    book_storage: PostgreSQLBookStorage,
    args: argparse.Namespace
) -> List[Book]:
    if args.book:
        books = []
        all_books = book_storage.get_all_books(limit=1000)
        for b in all_books:
            if args.book in b.title:
                full_book = book_storage.get_book(b.id)
                if full_book:
                    books.append(full_book)
        if not books:
            print(f"❌ 未找到包含 '{args.book}' 的书籍")
        return books
    
    elif args.category:
        all_books = book_storage.get_all_books(category=args.category, limit=1000)
        books = []
        for b in all_books:
            full_book = book_storage.get_book(b.id)
            if full_book:
                books.append(full_book)
        if not books:
            print(f"❌ 未找到分类 '{args.category}' 下的书籍")
        return books
    
    elif args.all:
        all_books = book_storage.get_all_books(limit=1000)
        books = []
        for b in all_books:
            full_book = book_storage.get_book(b.id)
            if full_book:
                books.append(full_book)
        return books
    
    else:
        return []


async def extract_from_section(
    llm,
    section: BookSection,
    book: Book,
) -> tuple:
    if not section.content or len(section.content.strip()) < 20:
        return [], [], "内容太短，跳过"
    
    prompt = EXTRACTION_PROMPT.format(
        book_title=book.title,
        section_title=section.title,
        dynasty=book.dynasty or "未知",
        author=book.author or "未知",
        content=section.content[:3000]
    )
    
    try:
        response = await llm.chat(
            [{"role": "user", "content": prompt}],
            temperature=0.3,
            max_tokens=4096
        )
        
        response_clean = response.strip()
        if response_clean.startswith("```json"):
            response_clean = response_clean[7:]
        if response_clean.startswith("```"):
            response_clean = response_clean[3:]
        if response_clean.endswith("```"):
            response_clean = response_clean[:-3]
        response_clean = response_clean.strip()
        
        data = json.loads(response_clean)
        
        knowledge_items = []
        name_to_id = {}
        
        for item_data in data.get("knowledge", []):
            evidence_list = []
            for ev in item_data.get("evidence", []):
                evidence_list.append(Evidence(
                    content=ev.get("content", ""),
                    type=ev.get("type", "literature"),
                    strength=ev.get("strength", 0.5),
                    supports=ev.get("supports", True)
                ))
            
            knowledge_type_str = item_data.get("knowledge_type", "event")
            try:
                knowledge_type = KnowledgeType(knowledge_type_str)
            except ValueError:
                knowledge_type = KnowledgeType.EVENT
            
            verification_str = item_data.get("verification_status", "unverified")
            try:
                verification_status = VerificationStatus(verification_str)
            except ValueError:
                verification_status = VerificationStatus.UNVERIFIED
            
            ku = KnowledgeUnit(
                name=item_data.get("name", ""),
                content=item_data.get("content", ""),
                knowledge_type=knowledge_type,
                confidence=item_data.get("confidence", 0.5),
                verification_status=verification_status,
                evidence=evidence_list,
                sources=[
                    Source(
                        type="literature",
                        title=book.title,
                        author=book.author,
                        extra_info={
                            "dynasty": book.dynasty,
                            "category": book.category,
                            "section_title": section.title,
                            "section_id": section.id,
                        }
                    )
                ],
                metadata={
                    "book_id": book.id,
                    "section_id": section.id,
                    "extraction_time": datetime.now().isoformat(),
                }
            )
            
            knowledge_items.append(ku)
            name_to_id[ku.name] = ku.id
        
        relations = []
        for rel_data in data.get("relations", []):
            source_name = rel_data.get("source_name", "")
            target_name = rel_data.get("target_name", "")
            source_id = name_to_id.get(source_name)
            target_id = name_to_id.get(target_name)
            
            if source_id and target_id:
                for ku in knowledge_items:
                    if ku.id == source_id:
                        ku.relations.append(Relation(
                            type=rel_data.get("type", "related"),
                            target_id=target_id,
                            description=rel_data.get("description", ""),
                            strength=rel_data.get("strength", 0.5)
                        ))
                        relations.append({
                            "source": source_name,
                            "target": target_name,
                            "type": rel_data.get("type", "related"),
                        })
        
        return knowledge_items, relations, None
        
    except json.JSONDecodeError as e:
        return [], [], f"JSON 解析失败: {e}"
    except Exception as e:
        return [], [], f"提取失败: {e}"


async def main():
    parser = argparse.ArgumentParser(description="从古籍文献中提取因果知识")
    parser.add_argument("--book", type=str, help="指定书籍名称（模糊匹配）")
    parser.add_argument("--category", type=str, help="指定分类（如 '子藏/兵家'）")
    parser.add_argument("--all", action="store_true", help="提取所有书籍")
    parser.add_argument("--model", type=str, default="gemini-2.0-flash", help="LLM 模型名称")
    parser.add_argument("--batch-size", type=int, default=10, help="每本书最多提取的章节数")
    parser.add_argument("--force", action="store_true", help="强制重新提取（忽略增量记录）")
    parser.add_argument("--dry-run", action="store_true", help="只显示将要处理的章节，不实际提取")
    
    args = parser.parse_args()
    
    if not args.book and not args.category and not args.all:
        parser.print_help()
        print("\n❌ 请指定至少一个选项：--book, --category, 或 --all")
        sys.exit(1)
    
    print("=" * 60)
    print("古籍因果知识提取工具")
    print("=" * 60)
    
    storage = PostgreSQLStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
    )
    storage.initialize()
    
    book_storage = PostgreSQLBookStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db",
        schema="books"
    )
    
    # DeepSeek API 配置
    api_key = "sk-ff312533ad1e41c896885cce8f5d2e4d"
    base_url = "https://api.deepseek.com/v1"
    model = "deepseek-chat"
    
    print(f"\n🤖 使用 DeepSeek API")
    print(f"   模型: {model}")
    print(f"   API: {base_url}")
    
    llm = create_llm_provider({
        "provider": "openai",  # DeepSeek 兼容 OpenAI API
        "api_key": api_key,
        "model": model,
        "base_url": base_url,
        "temperature": 0.3,
        "max_tokens": 4096,
    })
    
    print(f"\n📚 正在加载书籍列表...")
    books = get_books_to_process(book_storage, args)
    
    if not books:
        print("❌ 没有找到匹配的书籍")
        sys.exit(1)
    
    total_sections = sum(len(b.sections) for b in books)
    print(f"找到 {len(books)} 本书，共 {total_sections} 个章节")
    
    extracted_sections = set() if args.force else load_extracted_sections()
    
    if args.dry_run:
        print("\n--- DRY RUN 模式 ---")
        for book in books:
            unextracted = [s for s in book.sections if s.id not in extracted_sections]
            print(f"\n📖 《{book.title}》({book.author or '未知作者'})")
            print(f"   总章节：{len(book.sections)}，待提取：{len(unextracted)}")
            for s in unextracted[:5]:
                print(f"   - {s.title} ({len(s.content)} 字)")
            if len(unextracted) > 5:
                print(f"   ... 还有 {len(unextracted) - 5} 个章节")
        return
    
    print(f"\n已有提取记录：{len(extracted_sections)} 个章节")
    print(f"模型：{args.model}")
    print(f"每本书最多提取：{args.batch_size} 个章节")
    print()
    
    total_knowledge = 0
    total_relations = 0
    total_sections_processed = 0
    total_errors = 0
    start_time = time.time()
    
    for book_idx, book in enumerate(books, 1):
        print(f"\n[{book_idx}/{len(books)}] 📖 《{book.title}》({book.author or '未知作者'})")
        
        unextracted = [
            s for s in book.sections
            if s.id not in extracted_sections
        ]
        
        if not unextracted:
            print(f"  ⏭️  所有章节已提取，跳过")
            continue
        
        sections_to_process = unextracted[:args.batch_size]
        print(f"  待提取：{len(sections_to_process)}/{len(unextracted)} 个章节")
        
        book_knowledge = 0
        book_relations = 0
        
        for sec_idx, section in enumerate(sections_to_process, 1):
            print(f"  [{sec_idx}/{len(sections_to_process)}] {section.title}...", end=" ", flush=True)
            
            knowledge_items, relations, error = await extract_from_section(
                llm, section, book
            )
            
            if error:
                print(f"⚠️  {error}")
                total_errors += 1
                continue
            
            if not knowledge_items:
                print("∅ 无因果知识")
                extracted_sections.add(section.id)
                continue
            
            saved_count = 0
            for ku in knowledge_items:
                if storage.add_knowledge(ku):
                    saved_count += 1
            
            book_knowledge += saved_count
            book_relations += len(relations)
            
            rel_str = f", {len(relations)} 关系" if relations else ""
            print(f"✅ {saved_count} 知识{rel_str}")
            
            extracted_sections.add(section.id)
            save_extracted_sections(extracted_sections)
            
            total_sections_processed += 1
            
            await asyncio.sleep(1)
        
        total_knowledge += book_knowledge
        total_relations += book_relations
        print(f"  📊 本书提取：{book_knowledge} 知识，{book_relations} 关系")
    
    elapsed = time.time() - start_time
    
    print("\n" + "=" * 60)
    print("提取完成！")
    print("=" * 60)
    print(f"处理书籍：{len(books)} 本")
    print(f"处理章节：{total_sections_processed} 个")
    print(f"提取知识：{total_knowledge} 个")
    print(f"提取关系：{total_relations} 个")
    print(f"错误数量：{total_errors}")
    print(f"耗时：{elapsed:.1f} 秒")
    
    usage = llm.get_usage()
    print(f"\nLLM 用量：")
    print(f"  请求次数：{usage.get('request_count', 0)}")
    print(f"  Token 用量：{usage.get('total_tokens', 0)}")
    print(f"  预估费用：${usage.get('cost_usd', 0):.4f}")
    
    graph_stats = storage.get_graph_stats()
    print(f"\nAGE 图状态：")
    print(f"  节点数：{graph_stats['total_nodes']}")
    print(f"  边数：{graph_stats['total_edges']}")
    
    storage.close()


if __name__ == "__main__":
    asyncio.run(main())
