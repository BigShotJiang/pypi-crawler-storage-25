"""
因果推理查询工具 - 基于 AGE 图的因果链查询和多跳推理

功能：
1. 因果链查询：查找 A → B 之间的所有因果路径
2. 多跳推理：从某个事件出发，沿因果链向前/向后探索
3. 邻居查询：查看某个知识的直接关联
4. 图谱统计：查看整个知识图谱的状态
5. 知识搜索：全文搜索知识库

使用方式：
    # 因果链查询
    python scripts/query_causal.py chain --from "商鞅变法" --to "秦统一"
    
    # 多跳推理（向前推理）
    python scripts/query_causal.py hop --from "商鞅变法" --depth 3 --direction outgoing
    
    # 多跳推理（向后追溯原因）
    python scripts/query_causal.py hop --from "秦统一" --depth 3 --direction incoming
    
    # 邻居查询
    python scripts/query_causal.py neighbors --name "商鞅变法"
    
    # 知识搜索
    python scripts/query_causal.py search --query "变法"
    
    # 图谱统计
    python scripts/query_causal.py stats
"""

import os
import sys
import io
import argparse
import json
import logging
from pathlib import Path

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

logging.basicConfig(
    level=logging.WARNING,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)


def cmd_chain(storage: PostgreSQLStorage, args):
    print("=" * 60)
    print(f"🔗 因果链查询：'{args.from_name}' → '{args.to_name}'")
    print("=" * 60)
    
    chains = storage.query_causal_chain_via_graph(
        source_name=args.from_name,
        target_name=args.to_name,
        max_depth=args.max_depth
    )
    
    if not chains:
        print(f"\n未找到从 '{args.from_name}' 到 '{args.to_name}' 的因果链")
        
        print("\n尝试从知识库搜索相关知识...")
        from_results = storage.search_knowledge(args.from_name, limit=5)
        to_results = storage.search_knowledge(args.to_name, limit=5)
        
        if from_results:
            print(f"\n与 '{args.from_name}' 相关的知识：")
            for k in from_results:
                print(f"  - [{k.knowledge_type.value}] {k.name} (置信度: {k.confidence:.2f})")
        
        if to_results:
            print(f"\n与 '{args.to_name}' 相关的知识：")
            for k in to_results:
                print(f"  - [{k.knowledge_type.value}] {k.name} (置信度: {k.confidence:.2f})")
        
        if not from_results and not to_results:
            print("\n知识库中也没有找到相关知识。请先运行知识提取脚本。")
        
        return
    
    print(f"\n找到 {len(chains)} 条因果链：\n")
    
    for i, chain_data in enumerate(chains, 1):
        chain = chain_data.get("chain", [])
        depth = chain_data.get("depth", 0)
        
        print(f"路径 {i}（深度: {depth}）:")
        
        for j, node in enumerate(chain):
            prefix = "  " * j
            if j == 0:
                print(f"  📍 {node}")
            elif j == len(chain) - 1:
                print(f"  {prefix}⬇️")
                print(f"  {prefix}🎯 {node}")
            else:
                print(f"  {prefix}⬇️")
                print(f"  {prefix}📌 {node}")
        
        print()


def cmd_hop(storage: PostgreSQLStorage, args):
    direction_label = "结果" if args.direction == "outgoing" else "原因"
    print("=" * 60)
    print(f"🔀 多跳推理：'{args.from_name}' 的{direction_label}链（深度: {args.depth}）")
    print("=" * 60)
    
    paths = storage.query_multi_hop_reasoning(
        start_name=args.from_name,
        hops=args.depth,
        direction=args.direction,
        rel_type=args.rel_type
    )
    
    if not paths:
        print(f"\n未找到 '{args.from_name}' 的{direction_label}链")
        
        results = storage.search_knowledge(args.from_name, limit=5)
        if results:
            print(f"\n与 '{args.from_name}' 相关的知识：")
            for k in results:
                print(f"  - [{k.knowledge_type.value}] {k.name}")
                if k.content:
                    print(f"    {k.content[:100]}...")
        else:
            print("\n知识库中也没有找到相关知识。")
        
        return
    
    print(f"\n找到 {len(paths)} 条推理路径：\n")
    
    for i, path_data in enumerate(paths, 1):
        chain = path_data.get("chain", [])
        depth = path_data.get("depth", 0)
        
        arrow = "→" if args.direction == "outgoing" else "←"
        path_str = f" {arrow} ".join(chain)
        
        print(f"路径 {i}（深度: {depth}）:")
        print(f"  {path_str}")
        print()


def cmd_neighbors(storage: PostgreSQLStorage, args):
    print("=" * 60)
    print(f"👥 邻居查询：'{args.name}'")
    print("=" * 60)
    
    result = storage.query_neighbors_via_graph(
        node_name=args.name,
        direction=args.direction,
        limit=args.limit
    )
    
    neighbors = result.get("neighbors", [])
    
    if not neighbors:
        print(f"\n未找到 '{args.name}' 的邻居节点")
        return
    
    print(f"\n找到 {len(neighbors)} 个邻居：\n")
    
    direction_map = {"outgoing": "→ 导致", "incoming": "← 被导致", "both": "↔ 关联"}
    
    for n in neighbors:
        name = n.get("name", "未知")
        ktype = n.get("knowledge_type", "未知")
        relation = n.get("relation", "关联")
        strength = n.get("strength", "")
        
        strength_str = f" (强度: {strength})" if strength else ""
        print(f"  [{ktype}] {name} — {relation}{strength_str}")


def cmd_search(storage: PostgreSQLStorage, args):
    print("=" * 60)
    print(f"🔍 知识搜索：'{args.query}'")
    print("=" * 60)
    
    results = storage.search_knowledge(
        query=args.query,
        knowledge_type=args.type,
        limit=args.limit
    )
    
    if not results:
        print(f"\n未找到与 '{args.query}' 相关的知识")
        return
    
    print(f"\n找到 {len(results)} 个相关知识：\n")
    
    for i, k in enumerate(results, 1):
        print(f"{i}. [{k.knowledge_type.value}] {k.name}")
        print(f"   置信度: {k.confidence:.2f} | 验证状态: {k.verification_status.value}")
        if k.content:
            content_preview = k.content[:150].replace("\n", " ")
            print(f"   内容: {content_preview}...")
        
        if k.sources:
            for src in k.sources[:2]:
                author_str = f" ({src.author})" if src.author else ""
                print(f"   📖 来源: 《{src.title}》{author_str}")
        
        if k.relations:
            rel_strs = []
            for rel in k.relations[:3]:
                rel_strs.append(f"{rel.type}→{rel.target_id[:8]}...")
            print(f"   🔗 关系: {', '.join(rel_strs)}")
        
        print()


def cmd_stats(storage: PostgreSQLStorage, args):
    print("=" * 60)
    print("📊 知识图谱统计")
    print("=" * 60)
    
    knowledge_stats = storage.get_knowledge_statistics()
    graph_stats = storage.get_graph_stats()
    
    print(f"\n📝 知识库：")
    print(f"  总知识数: {knowledge_stats.get('total_count', 0)}")
    print(f"  平均置信度: {knowledge_stats.get('avg_confidence', 0):.3f}")
    
    by_type = knowledge_stats.get('by_type', {})
    if by_type:
        print(f"  按类型分布:")
        for ktype, count in sorted(by_type.items(), key=lambda x: -x[1]):
            print(f"    - {ktype}: {count}")
    
    print(f"\n🕸️  AGE 图：")
    print(f"  总节点数: {graph_stats.get('total_nodes', 0)}")
    print(f"  总边数: {graph_stats.get('total_edges', 0)}")
    
    try:
        import psycopg2
        conn = psycopg2.connect(
            host="localhost",
            port=5432,
            database="causal_db",
            user="causal_user",
            password="causal_password"
        )
        cursor = conn.cursor()
        cursor.execute("SET search_path = books; SELECT COUNT(*) FROM books;")
        book_count = cursor.fetchone()[0]
        cursor.execute("SET search_path = books; SELECT COUNT(*) FROM sections;")
        section_count = cursor.fetchone()[0]
        conn.close()
        
        print(f"\n📚 文献库：")
        print(f"  古籍数量: {book_count}")
        print(f"  章节总数: {section_count}")
    except Exception:
        pass
    
    print()


def main():
    parser = argparse.ArgumentParser(description="因果推理查询工具")
    subparsers = parser.add_subparsers(dest="command", help="查询命令")
    
    chain_parser = subparsers.add_parser("chain", help="因果链查询")
    chain_parser.add_argument("--from", dest="from_name", required=True, help="起始知识名称")
    chain_parser.add_argument("--to", dest="to_name", required=True, help="目标知识名称")
    chain_parser.add_argument("--max-depth", type=int, default=5, help="最大搜索深度")
    
    hop_parser = subparsers.add_parser("hop", help="多跳推理")
    hop_parser.add_argument("--from", dest="from_name", required=True, help="起始知识名称")
    hop_parser.add_argument("--depth", type=int, default=3, help="跳数")
    hop_parser.add_argument("--direction", choices=["outgoing", "incoming"], default="outgoing",
                          help="方向：outgoing=结果链, incoming=原因链")
    hop_parser.add_argument("--rel-type", default="CAUSES", help="关系类型")
    
    neighbor_parser = subparsers.add_parser("neighbors", help="邻居查询")
    neighbor_parser.add_argument("--name", required=True, help="节点名称")
    neighbor_parser.add_argument("--direction", choices=["outgoing", "incoming", "both"],
                               default="both", help="查询方向")
    neighbor_parser.add_argument("--limit", type=int, default=20, help="返回数量")
    
    search_parser = subparsers.add_parser("search", help="知识搜索")
    search_parser.add_argument("--query", required=True, help="搜索关键词")
    search_parser.add_argument("--type", help="知识类型过滤")
    search_parser.add_argument("--limit", type=int, default=20, help="返回数量")
    
    subparsers.add_parser("stats", help="图谱统计")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    storage = PostgreSQLStorage(
        database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
    )
    storage.initialize()
    
    try:
        if args.command == "chain":
            cmd_chain(storage, args)
        elif args.command == "hop":
            cmd_hop(storage, args)
        elif args.command == "neighbors":
            cmd_neighbors(storage, args)
        elif args.command == "search":
            cmd_search(storage, args)
        elif args.command == "stats":
            cmd_stats(storage, args)
    finally:
        storage.close()


if __name__ == "__main__":
    main()
