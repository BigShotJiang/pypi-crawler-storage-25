"""
因果元模式提取 v3 — 两轮方案

Round 1: 把 142 个去重模式喂给 LLM，归纳出 25-30 个核心元模式
Round 2: 把 2011 条原始关系分批映射到核心元模式

这样避免了同义词问题（条件促成/前提保障/条件赋能 都归入同一个元模式）

用法:
    cd t:\Item\AI\discuss\sources\generic-causal-architecture
    python scripts/meta_patterns_v3.py
"""

import sys
import json
import time
import numpy as np
from pathlib import Path
from collections import defaultdict

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import requests as http_requests

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
DEEPSEEK_API_KEY = "sk-ff312533ad1e41c896885cce8f5d2e4d"
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

SILICONFLOW_API_KEY = "sk-eahardciwonesiiwlbyljngvyvzutzahkxlezbyahfnidayr"
SILICONFLOW_BASE_URL = "https://api.siliconflow.cn/v1"
EMBEDDING_MODEL = "netease-youdao/bce-embedding-base_v1"

PATTERNS_FILE = project_root / "scripts" / "pattern_deduped.json"
OUTPUT_FILE = project_root / "scripts" / "meta_patterns_v3.json"


def call_llm(prompt: str, temperature: float = 0.3, max_tokens: int = 8192) -> str:
    resp = http_requests.post(
        f"{DEEPSEEK_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {DEEPSEEK_API_KEY}"},
        json={
            "model": "deepseek-chat",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": max_tokens,
        },
        timeout=120,
    )
    if resp.status_code != 200:
        raise Exception(f"API error {resp.status_code}: {resp.text[:200]}")
    return resp.json()["choices"][0]["message"]["content"]


def extract_json(text: str):
    for start_char, end_char in [("[", "]"), ("{", "}")]:
        json_start = text.find(start_char)
        if json_start == -1:
            continue
        depth = 0
        in_string = False
        escape_next = False
        for i in range(json_start, len(text)):
            c = text[i]
            if escape_next:
                escape_next = False
                continue
            if c == "\\":
                escape_next = True
                continue
            if c == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if c == start_char:
                depth += 1
            elif c == end_char:
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[json_start : i + 1])
                    except json.JSONDecodeError:
                        break
    return None


def clean_json_response(text: str) -> str:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1]
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3]
    return cleaned.strip()


def get_embeddings_batch(texts: list[str]) -> list[list[float]]:
    all_embeddings = []
    batch_size = 32

    for i in range(0, len(texts), batch_size):
        batch = texts[i : i + batch_size]
        print(f"  Embedding {i+1}-{min(i+batch_size, len(texts))}/{len(texts)}...", end=" ")

        resp = http_requests.post(
            f"{SILICONFLOW_BASE_URL}/embeddings",
            headers={
                "Authorization": f"Bearer {SILICONFLOW_API_KEY}",
                "Content-Type": "application/json",
            },
            json={
                "model": EMBEDDING_MODEL,
                "input": batch,
                "encoding_format": "float",
            },
            timeout=60,
        )

        if resp.status_code != 200:
            print(f"ERROR: {resp.status_code} {resp.text[:200]}")
            raise Exception(f"Embedding API error: {resp.status_code}")

        data = resp.json()["data"]
        sorted_data = sorted(data, key=lambda x: x["index"])
        all_embeddings.extend([d["embedding"] for d in sorted_data])
        print(f"OK")
        time.sleep(0.3)

    return all_embeddings


def extract_relations(storage) -> list[dict]:
    rows = storage._execute_sql("""
        SELECT r.source_id, r.target_id, r.relation_type,
               r.metadata_json->>'description' as description,
               r.confidence,
               s.name as source_name, t.name as target_name
        FROM relations r
        JOIN knowledge s ON r.source_id = s.id
        JOIN knowledge t ON r.target_id = t.id
        WHERE LENGTH(r.metadata_json->>'description') > 10
    """)

    relations = []
    for r in rows:
        desc = r.get("description", "")
        if not desc or len(desc.strip()) < 10:
            continue
        relations.append({
            "id": r["source_id"],
            "source": r["source_name"],
            "target": r["target_name"],
            "relation_type": r["relation_type"],
        })

    print(f"  有效关系: {len(relations)} 条")
    return relations


def round1_define_meta_patterns(patterns: list[dict]) -> list[dict]:
    print("\n" + "=" * 70)
    print("Round 1: 从已有模式中归纳核心元模式")
    print("=" * 70)

    pattern_list = []
    for i, p in enumerate(patterns):
        name = p["pattern_name"]
        logic = p.get("abstract_logic", "")
        mc = p.get("merge_count", 1)
        pattern_list.append(f"{i+1}. 【{name}】({mc}次): {logic}")

    pattern_text = "\n".join(pattern_list)

    prompt = f"""你是一个因果推断专家。以下是{len(patterns)}个从古籍中提取的因果模式，它们之间存在大量同义重复和粒度不一致的问题。

{pattern_text}

请将以上所有模式归纳为 20-30 个核心元模式（meta-pattern），要求：

1. **互斥且完备**：每个原始模式只能归入一个元模式，所有原始模式都要被覆盖
2. **语义精确**：元模式名称要精准反映因果机制，不要用太泛的名称（如"因果关系"）
3. **跨领域通用**：每个元模式应该能适用于现代商业、政治、管理、科技等领域
4. **有层次**：区分"核心因果"（有明确因果方向）和"逻辑关联"（相关性、例证性）

每个元模式输出：
{{
  "meta_id": "M01",
  "meta_name": "元模式名称（2-6字）",
  "category": "核心因果|逻辑关联|条件关系",
  "description": "这个元模式的精确定义（30字内）",
  "mechanism": "因果传导机制（50字内）",
  "modern_example": "一个现代商业/管理场景中的具体例子",
  "subsumed": [1, 5, 12],
  "generality": "high/medium"
}}

subsumed 是上面列表中被归入此元模式的编号。
直接输出 JSON 数组，不要任何其他文字。"""

    for retry in range(3):
        try:
            print(f"\n  调用 LLM 归纳元模式 (尝试 {retry+1})...", end=" ")
            result = call_llm(prompt, temperature=0.2, max_tokens=8192)
            cleaned = clean_json_response(result)
            meta_patterns = extract_json(cleaned)

            if meta_patterns and isinstance(meta_patterns, list):
                print(f"得到 {len(meta_patterns)} 个元模式")

                total_subsumed = 0
                for mp in meta_patterns:
                    total_subsumed += len(mp.get("subsumed", []))
                print(f"  覆盖原始模式: {total_subsumed}/{len(patterns)}")

                return meta_patterns
            else:
                print(f"解析失败，重试...")
        except Exception as e:
            print(f"错误: {e}，重试...")

    raise Exception("Round 1 失败：无法获取元模式")


def round2_map_relations(relations: list[dict], meta_patterns: list[dict]) -> dict:
    print("\n" + "=" * 70)
    print("Round 2: 将原始关系映射到核心元模式")
    print("=" * 70)

    meta_descriptions = []
    for mp in meta_patterns:
        meta_descriptions.append(
            f"{mp['meta_id']}. 【{mp['meta_name']}】{mp['description']}"
        )
    meta_text = "\n".join(meta_descriptions)

    meta_pattern_map = {}
    for mp in meta_patterns:
        meta_pattern_map[mp["meta_id"]] = mp

    mapping_results = defaultdict(list)
    batch_size = 50
    total = len(relations)

    for i in range(0, total, batch_size):
        batch = relations[i : i + batch_size]
        examples = []
        for j, r in enumerate(batch):
            examples.append(
                f"{j+1}. [{r['relation_type']}] {r['source']} → {r['target']}"
            )
        examples_text = "\n".join(examples)

        prompt = f"""将以下{len(batch)}条因果关系映射到最合适的核心元模式。

核心元模式列表：
{meta_text}

关系列表：
{examples_text}

对每条关系，输出它最匹配的元模式ID和匹配置信度。
直接输出 JSON 数组，不要任何其他文字：
[
  {{"idx": 1, "meta_id": "M01", "confidence": 0.9}},
  {{"idx": 2, "meta_id": "M05", "confidence": 0.8}}
]

idx 是关系编号。confidence 范围 0-1，表示匹配程度。"""

        for retry in range(2):
            try:
                print(f"  映射 {i+1}-{min(i+batch_size, total)}/{total}...", end=" ")
                result = call_llm(prompt, temperature=0.1)
                cleaned = clean_json_response(result)
                mappings = extract_json(cleaned)

                if mappings and isinstance(mappings, list):
                    for m in mappings:
                        idx = m.get("idx", 0) - 1
                        if 0 <= idx < len(batch):
                            mid = m.get("meta_id", "")
                            conf = m.get("confidence", 0.5)
                            r = batch[idx]
                            mapping_results[mid].append({
                                "relation_id": r["id"],
                                "source": r["source"],
                                "target": r["target"],
                                "relation_type": r["relation_type"],
                                "confidence": conf,
                            })
                    print(f"映射 {len(mappings)} 条")
                    break
                else:
                    if retry == 0:
                        print("解析失败，重试...")
                    else:
                        print("解析失败")
            except Exception as e:
                if retry == 0:
                    print(f"错误，重试: {e}")
                else:
                    print(f"错误: {e}")

        time.sleep(1)

    return mapping_results


def build_final_results(meta_patterns: list[dict], mapping_results: dict) -> list[dict]:
    results = []
    for mp in meta_patterns:
        mid = mp["meta_id"]
        mapped = mapping_results.get(mid, [])

        entry = {
            "meta_id": mid,
            "meta_name": mp["meta_name"],
            "category": mp.get("category", ""),
            "description": mp.get("description", ""),
            "mechanism": mp.get("mechanism", ""),
            "modern_example": mp.get("modern_example", ""),
            "generality": mp.get("generality", "medium"),
            "relation_count": len(mapped),
            "avg_confidence": 0,
            "top_relations": [],
        }

        if mapped:
            avg_conf = sum(r["confidence"] for r in mapped) / len(mapped)
            entry["avg_confidence"] = round(avg_conf, 3)
            sorted_mapped = sorted(mapped, key=lambda x: -x["confidence"])
            entry["top_relations"] = [
                {
                    "source": r["source"],
                    "target": r["target"],
                    "type": r["relation_type"],
                    "confidence": r["confidence"],
                }
                for r in sorted_mapped[:5]
            ]

        results.append(entry)

    results.sort(key=lambda x: (-x["relation_count"], -x["avg_confidence"]))
    return results


def main():
    print("读取去重模式...")
    with open(PATTERNS_FILE, encoding="utf-8") as f:
        patterns = json.load(f)
    print(f"  加载 {len(patterns)} 个模式")

    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()
    relations = extract_relations(storage)

    meta_patterns = round1_define_meta_patterns(patterns)

    mapping_results = round2_map_relations(relations, meta_patterns)

    final = build_final_results(meta_patterns, mapping_results)

    print(f"\n{'='*70}")
    print(f"最终结果")
    print(f"{'='*70}")

    total_mapped = sum(p["relation_count"] for p in final)
    print(f"元模式: {len(final)} 个")
    print(f"已映射关系: {total_mapped}/{len(relations)} ({total_mapped/len(relations)*100:.1f}%)")

    for cat in ["核心因果", "条件关系", "逻辑关联"]:
        group = [p for p in final if p.get("category") == cat]
        if not group:
            continue
        print(f"\n{'─'*40}")
        print(f"{cat} ({len(group)} 个)")
        print(f"{'─'*40}")
        for p in group:
            rc = p["relation_count"]
            ac = p["avg_confidence"]
            print(f"\n  【{p['meta_name']}】({p['meta_id']})")
            print(f"  描述: {p['description']}")
            print(f"  机制: {p['mechanism']}")
            print(f"  现代例子: {p['modern_example']}")
            print(f"  映射: {rc} 条关系, 平均置信度 {ac}")
            if p["top_relations"]:
                print(f"  代表性关系:")
                for r in p["top_relations"][:3]:
                    print(f"    [{r['type']}] {r['source']} → {r['target']} ({r['confidence']:.2f})")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(final, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
