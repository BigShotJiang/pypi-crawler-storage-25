"""检查知识元数据结构"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
import json

storage = PostgreSQLStorage(
    database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
)
storage.initialize()

# 查询提取的知识
result = storage._execute_sql("SELECT knowledge_json FROM knowledge LIMIT 10")
print(f"总记录数查询: {len(result) if result else 0}")

section_ids = set()
for row in result:
    data = row['knowledge_json']
    metadata = data.get('metadata', {})
    section_id = metadata.get('section_id')
    book_id = metadata.get('book_id')
    if section_id:
        section_ids.add(section_id)
        print(f"Book: {book_id}, Section: {section_id}")

print(f"\n共有 {len(section_ids)} 条带 section_id 的记录")
