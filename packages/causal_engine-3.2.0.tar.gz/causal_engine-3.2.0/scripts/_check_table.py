import sys
sys.path.insert(0, '.')
from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
s = PostgreSQLStorage(database_url='postgresql://postgres:causal_password@localhost:5432/causal_db')
s.initialize()
r = s._execute_sql("""
    SELECT table_name, column_name, data_type 
    FROM information_schema.columns 
    WHERE table_name = 'unified_entities'
""")
if r:
    for row in r:
        print(f"  {row['column_name']}: {row['data_type']}")
else:
    print("  table does not exist")
