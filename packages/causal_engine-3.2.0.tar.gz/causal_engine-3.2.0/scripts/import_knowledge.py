#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
知识导入工具 - 将 JSON 知识文件导入到数据库

使用方法:
    # 导入单个文件
    python scripts/import_knowledge.py 待导入知识/商鞅变法.json
    
    # 导入整个文件夹
    python scripts/import_knowledge.py 待导入知识/
    
    # 导入多个文件夹
    python scripts/import_knowledge.py 文件夹 1/ 文件夹 2/

作者：Generic Causal Architecture Team
版本：1.0
最后更新：2026-03-30
"""

import os
import sys
import io

if sys.stdout.encoding != 'utf-8':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
if sys.stderr.encoding != 'utf-8':
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
import json
from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime

# 添加项目根目录到路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from generic_causal_architecture.knowledge.models import (
    KnowledgeUnit,
    KnowledgeSet,
    KnowledgeType,
    VerificationStatus,
    Evidence,
    Source,
    Relation
)
from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
from generic_causal_architecture.storage.storage_interface import CausalRelation
from generic_causal_architecture.config.config import Config
from generic_causal_architecture.books.models import Book, BookSection
from generic_causal_architecture.books.postgresql_storage import PostgreSQLBookStorage


def load_config():
    """加载配置"""
    try:
        # 设置 PGPASSFILE 环境变量，避免手动输入密码
        current_dir = os.path.dirname(os.path.abspath(__file__))
        pgpass_file = os.path.join(current_dir, '.pgpass')
        if os.path.exists(pgpass_file):
            os.environ['PGPASSFILE'] = pgpass_file
        
        # 从环境变量或配置文件加载
        # 使用专门创建的 causal_user 用户（已授权访问 causal_db）
        database_url = os.getenv(
            "DATABASE_URL",
            "postgresql://causal_user:password123@localhost:5432/causal_db"
        )
        return {"database_url": database_url}
    except Exception as e:
        print(f"❌ 加载配置失败：{e}")
        sys.exit(1)


def validate_json_file(json_path: str) -> tuple[bool, Any, str]:
    """
    验证 JSON 文件格式
    
    Args:
        json_path: JSON 文件路径
        
    Returns:
        (是否有效，数据，错误信息)
    """
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        # 检查基本结构
        if not isinstance(data, dict):
            return False, None, "JSON 根对象必须是字典"
        
        # 检查是知识格式还是文献格式
        if "knowledge" in data:
            # 知识格式
            return validate_knowledge_format(data)
        elif "title" in data and "sections" in data:
            # 文献格式（书籍）
            return validate_book_format(data)
        else:
            return False, None, "无法识别的格式：缺少 'knowledge' 或 'title+sections' 字段"
        
    except json.JSONDecodeError as e:
        return False, None, f"JSON 格式错误：{e}"
    except Exception as e:
        return False, None, f"读取文件失败：{e}"


def validate_knowledge_format(data: Dict[str, Any]) -> tuple[bool, Any, str]:
    """验证知识格式"""
    if not isinstance(data["knowledge"], list):
        return False, None, "knowledge 必须是数组"
    
    # 检查每个知识
    for i, item in enumerate(data["knowledge"]):
        if not isinstance(item, dict):
            return False, None, f"第{i+1}个知识必须是字典"
        
        # 检查必填字段
        required_fields = ["name", "content", "knowledge_type", "confidence"]
        for field in required_fields:
            if field not in item:
                return False, None, f"第{i+1}个知识缺少必填字段：{field}"
        
        # 检查 knowledge_type 是否合法
        valid_types = ["event", "theory", "methodology", "concept", 
                      "rule", "pattern", "argument", "causal_relation"]
        if item["knowledge_type"] not in valid_types:
            return False, None, f"第{i+1}个知识的 knowledge_type 不合法：{item['knowledge_type']}"
        
        # 检查 confidence 是否在 0-1 之间
        if not (0.0 <= item["confidence"] <= 1.0):
            return False, None, f"第{i+1}个知识的 confidence 必须在 0-1 之间"
    
    # 检查 relations（可选）
    if "relations" in data:
        if not isinstance(data["relations"], list):
            return False, None, "relations 必须是数组"
        
        for i, rel in enumerate(data["relations"]):
            if not isinstance(rel, dict):
                return False, None, f"第{i+1}个关系必须是字典"
            
            if "type" not in rel or "source_id" not in rel or "target_id" not in rel:
                return False, None, f"第{i+1}个关系缺少必填字段：type, source_id, target_id"
    
    return True, data, ""


def validate_book_format(data: Dict[str, Any]) -> tuple[bool, Any, str]:
    """验证文献格式（书籍）"""
    # 检查必填字段
    if "title" not in data:
        return False, None, "缺少必填字段：title"
    
    if "author" not in data:
        return False, None, "缺少必填字段：author"
    
    if "sections" not in data:
        return False, None, "缺少必填字段：sections"
    
    if not isinstance(data["sections"], list):
        return False, None, "sections 必须是数组"
    
    # 检查每个章节
    for i, section in enumerate(data["sections"]):
        if not isinstance(section, dict):
            return False, None, f"第{i+1}个章节必须是字典"
        
        if "title" not in section:
            return False, None, f"第{i+1}个章节缺少 title"
        
        if "content" not in section:
            return False, None, f"第{i+1}个章节缺少 content"
    
    return True, data, ""


def create_knowledge_from_json(item: Dict[str, Any]) -> KnowledgeUnit:
    """从 JSON 创建知识单元"""
    # 转换知识类型
    knowledge_type = KnowledgeType(item.get("knowledge_type", "event"))
    
    # 转换验证状态
    verification_status_str = item.get("verification_status", "unverified")
    try:
        verification_status = VerificationStatus(verification_status_str)
    except ValueError:
        verification_status = VerificationStatus.UNVERIFIED
    
    # 转换证据
    evidence = []
    for ev_data in item.get("evidence", []):
        ev = Evidence(
            content=ev_data.get("content", ""),
            type=ev_data.get("type", "literature"),
            strength=ev_data.get("strength", 0.5),
            supports=ev_data.get("supports", True)
        )
        evidence.append(ev)
    
    # 转换来源
    sources = []
    for src_data in item.get("sources", []):
        src = Source(
            type=src_data.get("type", "literature"),
            title=src_data.get("title", ""),
            author=src_data.get("author"),
            year=src_data.get("year"),
            url=src_data.get("url"),
            extra_info=src_data.get("extra_info")
        )
        sources.append(src)
    
    # 转换关系
    relations = []
    for rel_data in item.get("relations", []):
        rel = Relation(
            type=rel_data.get("type", "related"),
            target_id=rel_data.get("target_id", ""),
            description=rel_data.get("description", "")
        )
        relations.append(rel)
    
    # 创建知识单元
    return KnowledgeUnit(
        name=item.get("name", ""),
        content=item.get("content", ""),
        knowledge_type=knowledge_type,
        confidence=item.get("confidence", 0.5),
        verification_status=verification_status,
        evidence=evidence,
        sources=sources,
        relations=relations,
        metadata=item.get("metadata", {})
    )


def import_knowledge_file(json_path: str, storage: PostgreSQLStorage) -> tuple[int, int, List[str]]:
    """
    导入单个 JSON 文件（知识格式）
    
    Args:
        json_path: JSON 文件路径
        storage: 存储对象
        
    Returns:
        (知识数量，关系数量，错误列表)
    """
    errors = []
    knowledge_count = 0
    relation_count = 0
    
    # 验证文件
    valid, data, error = validate_json_file(json_path)
    if not valid:
        return 0, 0, [error]
    
    print(f"  ✅ 验证通过：包含 {len(data['knowledge'])} 个知识")
    
    # 创建知识名称到 ID 的映射
    name_to_id = {}
    skipped = 0
    
    # 导入前先查已有知识（按名称去重）
    existing_map = {}
    try:
        for item in data["knowledge"]:
            name = item.get("name", "")
            if not name:
                continue
            results = storage.search_knowledge(name, limit=1)
            for k in results:
                if k.name == name:
                    existing_map[name] = k.id
                    break
    except Exception:
        pass
    
    # 导入知识
    for item in data["knowledge"]:
        try:
            knowledge = create_knowledge_from_json(item)
            name = item.get("name", "")
            
            if name in existing_map:
                knowledge.id = existing_map[name]
                skipped += 1
            
            storage.add_knowledge(knowledge)
            name_to_id[knowledge.name] = knowledge.id
            knowledge_count += 1
            
        except Exception as e:
            errors.append(f"导入知识 '{item.get('name', 'unknown')}' 失败：{e}")
    
    # 导入关系（如果有）- 存储到知识的 JSON 数据中
    if "relations" in data and knowledge_count > 0:
        from generic_causal_architecture.knowledge.models import Relation as KnowledgeRelation
        
        source_relations = {}
        for rel_data in data["relations"]:
            source_name = rel_data.get("source_id")
            target_name = rel_data.get("target_id")
            
            if source_name in name_to_id and target_name in name_to_id:
                rel = KnowledgeRelation(
                    target_id=name_to_id[target_name],
                    type=rel_data.get("type", "related"),
                    strength=rel_data.get("confidence", 0.5),
                    description=rel_data.get("description", "")
                )
                source_relations.setdefault(source_name, []).append(rel)
        
        for source_name, rels in source_relations.items():
            try:
                knowledge_data = storage.get_knowledge(name_to_id[source_name])
                if knowledge_data:
                    knowledge_data.relations = rels
                    storage.add_knowledge(knowledge_data)
                    relation_count += len(rels)
            except Exception as e:
                errors.append(f"更新关系 '{source_name}' 失败：{e}")
    
    return knowledge_count, relation_count, errors


def import_book_file(json_path: str, book_storage: PostgreSQLBookStorage) -> tuple[str, int, List[str]]:
    """
    导入单个 JSON 文件（文献格式）
    
    Args:
        json_path: JSON 文件路径
        book_storage: 文献存储对象
        
    Returns:
        (书籍 ID，章节数量，错误列表)
    """
    errors = []
    
    # 验证文件
    valid, data, error = validate_json_file(json_path)
    if not valid:
        return "", 0, [error]
    
    try:
        # 创建 Book 对象
        book = Book(
            id=data.get("id", f"book_{data['title'].replace(' ', '_')}"),
            title=data["title"],
            author=data["author"],
            dynasty=data.get("dynasty"),
            category=data.get("category"),
            metadata={
                k: v for k, v in data.items()
                if k not in ("id", "title", "author", "dynasty", "category", "sections")
            }
        )
        
        # 创建 BookSection 对象并添加到 book
        for i, section_data in enumerate(data["sections"], 1):
            raw_id = section_data.get("id", f"section_{i}")
            section = BookSection(
                id=f"{book.id}_{raw_id}",
                book_id=book.id,
                title=section_data["title"],
                content=section_data["content"],
                section_type=section_data.get("type", "chapter"),
                order=section_data.get("order", 0)
            )
            book.sections.append(section)
        
        # 保存到数据库（book + sections 一起）
        book_storage.add_book(book)
        
        return book.id, len(book.sections), []
        
    except Exception as e:
        errors.append(f"导入文献 '{data.get('title', 'unknown')}' 失败：{e}")
        return "", 0, errors


def main():
    """主函数"""
    import argparse
    
    # 解析命令行参数
    parser = argparse.ArgumentParser(description="知识导入工具")
    parser.add_argument(
        "paths",
        nargs="+",
        help="JSON 文件或文件夹路径"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="显示详细信息"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="只验证格式，不导入数据库"
    )
    
    args = parser.parse_args()
    
    # 打印欢迎信息
    print("=" * 60)
    print("知识导入工具")
    if args.dry_run:
        print("(仅验证模式)")
    print("=" * 60)
    print()
    
    # 收集所有 JSON 文件
    json_files = []
    for path in args.paths:
        path = Path(path)
        if path.is_file() and path.suffix == ".json":
            json_files.append(path)
        elif path.is_dir():
            json_files.extend(list(path.rglob("*.json")))
        else:
            print(f"⚠️  跳过无效路径：{path}")
    
    if not json_files:
        print("❌ 没有找到 JSON 文件")
        sys.exit(1)
    
    print(f"找到 {len(json_files)} 个 JSON 文件")
    print()
    
    # 如果是 dry-run 模式，只验证格式
    if args.dry_run:
        print("开始验证文件格式...")
        print()
        
        total_valid = 0
        failed_files = []
        
        for i, json_file in enumerate(json_files, 1):
            print(f"[{i}/{len(json_files)}] 验证：{json_file.name}")
            
            valid, data, error = validate_json_file(str(json_file))
            
            if valid:
                # 检查是哪种格式
                if "knowledge" in data:
                    print(f"  ✅ 知识格式：{len(data['knowledge'])} 个知识")
                elif "title" in data and "sections" in data:
                    print(f"  ✅ 文献格式：{data['title']} ({len(data['sections'])} 个章节)")
                total_valid += 1
            else:
                print(f"  ❌ 格式错误：{error}")
                failed_files.append((json_file.name, error))
            
            print()
        
        print("=" * 60)
        print("验证完成！")
        print("=" * 60)
        print(f"有效文件：{total_valid}/{len(json_files)}")
        
        if failed_files:
            print(f"失败文件：{len(failed_files)}")
            print()
            for filename, error in failed_files:
                print(f"  - {filename}: {error}")
        
        sys.exit(0)
    
    # 正常模式：连接数据库并导入
    # 加载配置
    config = load_config()
    
    # 初始化存储
    print("正在连接数据库...")
    try:
        # 知识存储
        storage = PostgreSQLStorage(database_url=config["database_url"])
        storage.initialize()
        print("✅ 知识库存连接成功")
        
        # 文献存储（使用同一个数据库，不同的 schema）
        book_storage = PostgreSQLBookStorage(
            database_url=config["database_url"],
            schema="books"
        )
        print("✅ 文献库连接成功")
        print()
    except Exception as e:
        print(f"❌ 数据库连接失败：{e}")
        print()
        print("请确认：")
        print("1. 数据库已启动")
        print("2. 数据库地址正确")
        print("3. 网络连接正常")
        sys.exit(1)
    
    # 分类文件
    knowledge_files = []
    book_files = []
    
    for json_file in json_files:
        valid, data, error = validate_json_file(str(json_file))
        if valid:
            if "knowledge" in data:
                knowledge_files.append(json_file)
            elif "title" in data and "sections" in data:
                book_files.append(json_file)
    
    # 导入文献
    total_books = 0
    total_sections = 0
    failed_books = []
    
    if book_files:
        print(f"开始导入文献 ({len(book_files)} 个文件)...")
        print()
        
        for i, json_file in enumerate(book_files, 1):
            print(f"[{i}/{len(book_files)}] 导入：{json_file.name}")
            
            book_id, section_count, errors = import_book_file(str(json_file), book_storage)
            
            if errors:
                print(f"  ❌ 导入失败：")
                for error in errors:
                    print(f"     - {error}")
                failed_books.append((json_file.name, errors))
            else:
                print(f"  ✅ 导入成功：{book_id} ({section_count} 个章节)")
                total_books += 1
                total_sections += section_count
            
            print()
        
        print("=" * 60)
        print("文献导入完成！")
        print("=" * 60)
        print(f"总计：{total_books} 本书，{total_sections} 个章节")
        print(f"成功：{len(book_files) - len(failed_books)}/{len(book_files)}")
        print()
    
    # 导入知识
    total_knowledge = 0
    total_relations = 0
    failed_knowledge = []
    
    if knowledge_files:
        print(f"开始导入知识 ({len(knowledge_files)} 个文件)...")
        print()
        
        for i, json_file in enumerate(knowledge_files, 1):
            print(f"[{i}/{len(knowledge_files)}] 导入：{json_file.name}")
            
            knowledge_count, relation_count, errors = import_knowledge_file(
                str(json_file),
                storage
            )
            
            if errors:
                print(f"  ❌ 导入失败：")
                for error in errors:
                    print(f"     - {error}")
                failed_knowledge.append((json_file.name, errors))
            else:
                print(f"  ✅ 导入成功：{knowledge_count} 个知识，{relation_count} 个关系")
                total_knowledge += knowledge_count
                total_relations += relation_count
            
            print()
        
        print("=" * 60)
        print("知识导入完成！")
        print("=" * 60)
        print(f"总计：{total_knowledge} 个知识，{total_relations} 个关系")
        print(f"成功：{len(knowledge_files) - len(failed_knowledge)}/{len(knowledge_files)}")
        print()
    
    # 关闭存储
    storage.close()
    book_storage.close()


if __name__ == "__main__":
    main()
