"""
End-to-end demo: full causal engine flow using MemoryStorage (no database needed).

Demonstrates:
1. Create engine with in-memory storage
2. Inject causal rules (simulate a historical/game scenario)
3. Validate candidate rules (dedup + conflict detection)
4. Inject new actions and observe predicted consequences
5. Adjust confidence via feedback loop
6. Search and inspect the knowledge graph

Run: python scripts/demo_e2e.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from generic_causal_architecture import (
    CausalEngine,
    CandidateRule,
    ValidationResult,
    FeedbackRequest,
)
from generic_causal_architecture.storage import MemoryStorage
from generic_causal_architecture.core.action_models import Action, ActionRelation


def separator(title: str):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")


def main():
    separator("Step 1: Create Engine with MemoryStorage")
    storage = MemoryStorage()
    storage.initialize()
    engine = CausalEngine(storage)
    print("[OK] Engine created, no database required")

    separator("Step 2: Inject Base Causal Rules (Historical Scenario)")
    base_rules = [
        ("提高税收", "民众不满", "causes", 0.85),
        ("民众不满", "社会动荡", "causes", 0.80),
        ("社会动荡", "政权动摇", "causes", 0.75),
        ("开仓放粮", "民众安抚", "causes", 0.80),
        ("民众安抚", "社会稳定", "causes", 0.75),
        ("社会稳定", "政权巩固", "causes", 0.70),
        ("提高税收", "国库充盈", "causes", 0.90),
        ("国库充盈", "军力增强", "enables", 0.70),
        ("军力增强", "外敌退却", "causes", 0.65),
        ("开仓放粮", "国库空虚", "causes", 0.70),
        ("国库空虚", "军力衰退", "enables", 0.60),
        ("外敌入侵", "社会动荡", "causes", 0.80),
    ]

    action = Action(
        name="initialize_base_rules",
        relations=[
            ActionRelation(source=s, target=t, relation_type=rt, confidence=c)
            for s, t, rt, c in base_rules
        ],
    )
    result = engine.inject_action(action)
    print(f"  Injected {result.relations_added} new relations")
    print(f"  Entities affected: {len(result.entities_affected)}")
    print(f"  Immediate effects recorded: {len(result.immediate_effects)}")
    for eff in result.immediate_effects:
        print(f"    {eff['source']} --[{eff['relation_type']}]--> {eff['target']} "
              f"(conf={eff['confidence']}, {eff['status']})")

    separator("Step 3: Validate Candidate Rules")
    test_candidates = [
        CandidateRule(
            source="提高税收", target="民众不满",
            relation_type="causes", confidence=0.85,
            reasoning="Already exists - should be detected as duplicate",
        ),
        CandidateRule(
            source="提高税收", target="民众安抚",
            relation_type="causes", confidence=0.40,
            reasoning="Contradicts: raising taxes doesn't comfort people",
        ),
        CandidateRule(
            source="天灾", target="粮食减产",
            relation_type="causes", confidence=0.85,
            reasoning="New valid rule",
        ),
        CandidateRule(
            source="粮食减产", target="饥荒",
            relation_type="causes", confidence=0.80,
            reasoning="New valid rule",
        ),
    ]

    for candidate in test_candidates:
        validation = engine.validate_rule(candidate)
        status = "DUPLICATE" if validation.is_duplicate else (
            "CONFLICT" if validation.conflicts else (
                "VALID" if validation.is_valid else "REJECTED"
            )
        )
        level = validation.recommended_level
        print(f"  [{status}] {candidate.source} → {candidate.target} "
              f"({candidate.relation_type}, conf={candidate.confidence:.2f}) "
              f"→ Level {level}")
        if validation.conflicts:
            for c in validation.conflicts:
                print(f"    ⚠ Conflict: {c['existing']} (conf={c['confidence']})")

    separator("Step 4: Inject Validated New Rules")
    new_rules_action = Action(
        name="add_nature_disaster_rules",
        relations=[
            ActionRelation(source="天灾", target="粮食减产",
                           relation_type="causes", confidence=0.85),
            ActionRelation(source="粮食减产", target="饥荒",
                           relation_type="causes", confidence=0.80),
            ActionRelation(source="饥荒", target="民众不满",
                           relation_type="causes", confidence=0.75),
        ],
    )
    result2 = engine.inject_action(new_rules_action)
    print(f"  Injected {result2.relations_added} new relations")
    for eff in result2.immediate_effects:
        print(f"    {eff['source']} --[{eff['relation_type']}]--> {eff['target']} "
              f"(conf={eff['confidence']}, {eff['status']})")

    separator("Step 5: Search Knowledge Graph")
    results = storage.search_entity_relations("民众", limit=10)
    print(f"  Search '民众' → found {len(results)} relations:")
    for r in results:
        print(f"    {r['source']} --[{r['relation_type']}]--> {r['target']} "
              f"(conf={r['confidence']})")

    results2 = storage.search_entity_relations("税收", limit=10)
    print(f"\n  Search '税收' → found {len(results2)} relations:")
    for r in results2:
        print(f"    {r['source']} --[{r['relation_type']}]--> {r['target']} "
              f"(conf={r['confidence']})")

    separator("Step 6: Feedback Loop - Confidence Adjustment")
    print("  Simulate: prediction was correct (提高税收→民众不满)")
    ok = engine.adjust_confidence("提高税收", "民众不满", "causes", +0.05)
    rel = storage.find_entity_relation("提高税收", "民众不满", "causes")
    print(f"    Adjusted: {ok}, new confidence = {rel['confidence']}")

    print("\n  Simulate: prediction was wrong (a low-confidence rule)")
    engine.adjust_confidence("提高税收", "民众安抚", "causes", -0.05)

    print("\n  Process feedback via FeedbackRequest:")
    feedback = FeedbackRequest(
        rule_source="民众不满",
        rule_target="社会动荡",
        rule_relation_type="causes",
        match=True,
        predicted_outcome="社会动荡",
        actual_outcome="社会动荡",
    )
    fb_result = engine.process_feedback(feedback)
    print(f"    Action: {fb_result['action']}")
    print(f"    Message: {fb_result['message']}")

    separator("Step 7: Meta-Pattern Fallback Reasoning")
    print("  When event rules don't match, fall back to abstract patterns:")
    contexts = [
        "皇帝过度消耗国库资源导致民众不满和反抗",
        "一个王朝长期沿用旧制度，拒绝变革",
        "邻国突然入侵，国内刚好粮食歉收",
    ]
    for ctx in contexts:
        matched = engine.match_meta_patterns(ctx, top_k=2)
        print(f"\n  Context: {ctx}")
        for m in matched:
            p = m["pattern"]
            print(f"    [{m['match_score']:.2f}] {p['name']}: {p['abstract_logic']}")

    separator("Step 8: Conditional Rules")
    from generic_causal_architecture import Relation

    cond_rule = Relation(
        "外敌入侵", "征兵动员",
        relation_type="causes", confidence=0.85,
        conditions={
            "catalysts": ["战争状态"],
            "inhibitors": ["和平条约"],
        },
    )
    print(f"  Rule: {cond_rule.source} → {cond_rule.target}")
    print(f"  Conditions: catalysts={cond_rule.conditions.get('catalysts')}, "
          f"inhibitors={cond_rule.conditions.get('inhibitors')}")
    print(f"    In wartime: {cond_rule.matches_conditions({'战争状态': True})}")
    print(f"    With peace treaty: {cond_rule.matches_conditions({'和平条约': True})}")
    print(f"    No context: {cond_rule.matches_conditions({})}")

    separator("Step 9: Inspect Final KG State")
    all_relations = storage.search_entity_relations("", limit=50)
    print(f"  Total entity relations in KG: {len(all_relations)}")
    print(f"  Entities: {len(storage._entities)}")

    print("\n  All relations:")
    for r in sorted(all_relations, key=lambda x: -x["confidence"]):
        print(f"    {r['source']} --[{r['relation_type']}]--> {r['target']} "
              f"(conf={r['confidence']})")

    separator("Summary")
    print(f"  Total rules: {len(all_relations)}")
    print(f"  Entities: {len(storage._entities)}")
    print(f"  Meta-patterns: {len(engine.list_meta_patterns())}")
    print(f"  No database was used - pure in-memory!")
    print(f"  Full pipeline: inject → validate → search → feedback → meta-patterns → conditional rules ✓")


if __name__ == "__main__":
    main()
