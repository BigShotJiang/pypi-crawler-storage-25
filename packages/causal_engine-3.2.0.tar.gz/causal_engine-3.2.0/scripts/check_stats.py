"""检查知识统计"""

import sys
from pathlib import Path

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage
import json

storage = PostgreSQLStorage(
    database_url="postgresql://postgres:causal_password@localhost:5432/causal_db"
)
storage.initialize()

# 统计总知识数
result = storage._execute_sql("SELECT COUNT(*) as count FROM knowledge")
total = result[0]['count'] if result else 0
print(f"总知识数: {total}")

# 统计带 section_id 的知识
result = storage._execute_sql(
    "SELECT knowledge_json FROM knowledge WHERE knowledge_json->>'metadata' IS NOT NULL"
)
section_ids = set()
for row in result:
    data = row['knowledge_json']
    if isinstance(data, dict):
        metadata = data.get('metadata', {})
        section_id = metadata.get('section_id')
        if section_id:
            section_ids.add(section_id)

print(f"已提取章节数: {len(section_ids)}")
print(f"章节ID示例: {list(section_ids)[:5]}")
