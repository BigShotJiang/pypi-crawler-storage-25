"""
全量元模式分析 — 基于已有 24 元模式 + 新数据扩展

方案 C：
1. 从 meta_patterns_v3.json 加载已有 24 个元模式
2. 抽样新数据中的 500 条关系，让 LLM 判断是否需要新增元模式
3. 用扩展后的元模式映射全部 8603 条关系

比完整重跑 abstract_patterns 快 5 倍，且能发现新模式
"""

import sys
import json
import time
import random
from pathlib import Path
from collections import defaultdict

project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

import requests as http_requests

from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
DEEPSEEK_API_KEY = "sk-ff312533ad1e41c896885cce8f5d2e4d"
DEEPSEEK_BASE_URL = "https://api.deepseek.com/v1"

EXISTING_META_FILE = project_root / "scripts" / "meta_patterns_v3.json"
OUTPUT_FILE = project_root / "scripts" / "meta_patterns_full.json"


def call_llm(prompt: str, temperature: float = 0.3, max_tokens: int = 8192) -> str:
    resp = http_requests.post(
        f"{DEEPSEEK_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {DEEPSEEK_API_KEY}"},
        json={
            "model": "deepseek-chat",
            "messages": [{"role": "user", "content": prompt}],
            "temperature": temperature,
            "max_tokens": max_tokens,
        },
        timeout=120,
    )
    if resp.status_code != 200:
        raise Exception(f"API error {resp.status_code}: {resp.text[:200]}")
    return resp.json()["choices"][0]["message"]["content"]


def extract_json(text: str):
    text = text.strip()
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

    for start_char, end_char in [("[", "]"), ("{", "}")]:
        json_start = text.find(start_char)
        if json_start == -1:
            continue
        depth = 0
        in_string = False
        escape_next = False
        for i in range(json_start, len(text)):
            c = text[i]
            if escape_next:
                escape_next = False
                continue
            if c == "\\":
                escape_next = True
                continue
            if c == '"':
                in_string = not in_string
                continue
            if in_string:
                continue
            if c == start_char:
                depth += 1
            elif c == end_char:
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[json_start : i + 1])
                    except json.JSONDecodeError:
                        break
    return None


def extract_relations(storage) -> list[dict]:
    rows = storage._execute_sql("""
        SELECT r.source_id, r.target_id, r.relation_type,
               r.metadata_json->>'description' as description,
               r.confidence,
               s.name as source_name, t.name as target_name,
               s.knowledge_json->'sources'->0->>'title' as source_book
        FROM relations r
        JOIN knowledge s ON r.source_id = s.id
        JOIN knowledge t ON r.target_id = t.id
        WHERE LENGTH(r.metadata_json->>'description') > 10
    """)

    relations = []
    for r in rows:
        desc = r.get("description", "")
        if not desc or len(desc.strip()) < 10:
            continue
        relations.append({
            "id": r["source_id"],
            "source": r["source_name"],
            "target": r["target_name"],
            "relation_type": r["relation_type"],
            "source_book": r.get("source_book", ""),
        })

    print(f"  有效关系: {len(relations)} 条")
    return relations


def expand_meta_patterns(existing: list[dict], sample_relations: list[dict]) -> list[dict]:
    print("\n" + "=" * 70)
    print("Round 1: 检查已有元模式是否需要扩展")
    print("=" * 70)

    meta_list = []
    for mp in existing:
        meta_list.append(f"{mp['meta_id']}. 【{mp['meta_name']}】{mp['description']} | 机制: {mp['mechanism']}")
    meta_text = "\n".join(meta_list)

    random.seed(42)
    sample = random.sample(sample_relations, min(500, len(sample_relations)))

    sample_text = ""
    for i, r in enumerate(sample, 1):
        sample_text += f"{i}. [{r['relation_type']}] {r['source']} → {r['target']} (来源: {r['source_book']})\n"

    prompt = f"""你是一个因果推断专家。我们已有 {len(existing)} 个核心元模式，用于分类古籍中的因果关系。

已有元模式：
{meta_text}

现在有 {len(sample)} 条新提取的因果关系（来自 166 本古籍，包括兵法、史籍、儒学、政论等）：
{sample_text}

请分析：
1. 这些新关系是否都能被已有元模式覆盖？
2. 如果有大量关系无法被现有模式覆盖，请新增必要的元模式
3. 新增模式要遵循相同的格式，编号从 M25 开始

直接输出 JSON 数组。如果不需要新增，输出空数组 []。
如果需要新增，每个新模式格式：
{{
  "meta_id": "M25",
  "meta_name": "模式名称（2-6字）",
  "category": "核心因果|逻辑关联|条件关系",
  "description": "精确定义（30字内）",
  "mechanism": "因果传导机制（50字内）",
  "modern_example": "现代场景例子",
  "reason": "为什么现有模式不够用",
  "generality": "high/medium"
}}"""

    for retry in range(3):
        try:
            print(f"  调用 LLM 分析 (尝试 {retry+1})...", end=" ")
            result = call_llm(prompt, temperature=0.2, max_tokens=4096)
            new_patterns = extract_json(result)

            if new_patterns is None:
                new_patterns = []

            if isinstance(new_patterns, list):
                print(f"新增 {len(new_patterns)} 个元模式")
                for np_item in new_patterns:
                    print(f"  + {np_item.get('meta_id')}. {np_item.get('meta_name')}: {np_item.get('reason', '')[:60]}")

                all_meta = existing + new_patterns
                print(f"\n总元模式: {len(all_meta)} 个 (原有 {len(existing)} + 新增 {len(new_patterns)})")
                return all_meta
            else:
                print("解析失败，重试...")
        except Exception as e:
            print(f"错误: {e}，重试...")

    print("未能获取扩展，使用原有元模式")
    return existing


def map_all_relations(relations: list[dict], meta_patterns: list[dict]) -> dict:
    print("\n" + "=" * 70)
    print(f"Round 2: 映射 {len(relations)} 条关系到 {len(meta_patterns)} 个元模式")
    print("=" * 70)

    meta_descriptions = []
    for mp in meta_patterns:
        meta_descriptions.append(
            f"{mp['meta_id']}. 【{mp['meta_name']}】{mp['description']}"
        )
    meta_text = "\n".join(meta_descriptions)

    mapping_results = defaultdict(list)
    batch_size = 50
    total = len(relations)

    for i in range(0, total, batch_size):
        batch = relations[i : i + batch_size]
        examples = []
        for j, r in enumerate(batch):
            examples.append(
                f"{j+1}. [{r['relation_type']}] {r['source']} → {r['target']}"
            )
        examples_text = "\n".join(examples)

        prompt = f"""将以下{len(batch)}条因果关系映射到最合适的核心元模式。

核心元模式列表：
{meta_text}

关系列表：
{examples_text}

对每条关系，输出它最匹配的元模式ID和匹配置信度。
直接输出 JSON 数组，不要任何其他文字：
[
  {{"idx": 1, "meta_id": "M01", "confidence": 0.9}},
  {{"idx": 2, "meta_id": "M05", "confidence": 0.8}}
]"""

        for retry in range(2):
            try:
                print(f"  映射 {i+1}-{min(i+batch_size, total)}/{total}...", end=" ")
                result = call_llm(prompt, temperature=0.1)
                mappings = extract_json(result)

                if mappings and isinstance(mappings, list):
                    for m in mappings:
                        idx = m.get("idx", 0) - 1
                        if 0 <= idx < len(batch):
                            mid = m.get("meta_id", "")
                            conf = m.get("confidence", 0.5)
                            r = batch[idx]
                            mapping_results[mid].append({
                                "relation_id": r["id"],
                                "source": r["source"],
                                "target": r["target"],
                                "relation_type": r["relation_type"],
                                "confidence": conf,
                            })
                    print(f"映射 {len(mappings)} 条")
                    break
                else:
                    if retry == 0:
                        print("解析失败，重试...")
                    else:
                        print("解析失败")
            except Exception as e:
                if retry == 0:
                    print(f"错误，重试: {e}")
                else:
                    print(f"错误: {e}")

        time.sleep(0.8)

    return mapping_results


def build_final_results(meta_patterns: list[dict], mapping_results: dict) -> list[dict]:
    results = []
    for mp in meta_patterns:
        mid = mp["meta_id"]
        mapped = mapping_results.get(mid, [])

        entry = {
            "meta_id": mid,
            "meta_name": mp["meta_name"],
            "category": mp.get("category", ""),
            "description": mp.get("description", ""),
            "mechanism": mp.get("mechanism", ""),
            "modern_example": mp.get("modern_example", ""),
            "generality": mp.get("generality", "medium"),
            "relation_count": len(mapped),
            "avg_confidence": 0,
            "top_relations": [],
        }

        if mapped:
            avg_conf = sum(r["confidence"] for r in mapped) / len(mapped)
            entry["avg_confidence"] = round(avg_conf, 3)
            sorted_mapped = sorted(mapped, key=lambda x: -x["confidence"])
            entry["top_relations"] = [
                {
                    "source": r["source"],
                    "target": r["target"],
                    "type": r["relation_type"],
                    "confidence": r["confidence"],
                }
                for r in sorted_mapped[:5]
            ]

        results.append(entry)

    results.sort(key=lambda x: (-x["relation_count"], -x["avg_confidence"]))
    return results


def main():
    print("加载已有元模式...")
    with open(EXISTING_META_FILE, encoding="utf-8") as f:
        existing = json.load(f)
    print(f"  已有 {len(existing)} 个元模式")

    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()
    relations = extract_relations(storage)

    all_meta = expand_meta_patterns(existing, relations)

    mapping_results = map_all_relations(relations, all_meta)

    final = build_final_results(all_meta, mapping_results)

    print(f"\n{'='*70}")
    print(f"全量元模式分析结果")
    print(f"{'='*70}")

    total_mapped = sum(p["relation_count"] for p in final)
    print(f"元模式: {len(final)} 个")
    print(f"已映射关系: {total_mapped}/{len(relations)} ({total_mapped/len(relations)*100:.1f}%)")

    for cat in ["核心因果", "条件关系", "逻辑关联"]:
        group = [p for p in final if p.get("category") == cat]
        if not group:
            continue
        print(f"\n{'─'*40}")
        print(f"{cat} ({len(group)} 个)")
        print(f"{'─'*40}")
        for p in group:
            rc = p["relation_count"]
            ac = p["avg_confidence"]
            print(f"\n  【{p['meta_name']}】({p['meta_id']})")
            print(f"  描述: {p['description']}")
            print(f"  机制: {p['mechanism']}")
            print(f"  映射: {rc} 条关系, 平均置信度 {ac}")

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(final, f, ensure_ascii=False, indent=2)
    print(f"\n结果已保存: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
