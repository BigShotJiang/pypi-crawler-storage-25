"""
Game SDK - One-line integration for game applications.

This is the ONLY module game developers need to import.

    from causal_engine.game import CausalGame

    game = CausalGame("data/rules.json")
    consequences = game.decide("player", "increase taxes", {"target": "treasury"})
    game.save("save.json")

No knowledge of CausalEngine, MemoryStorage, Action, ActionRelation, etc. needed.
Everything is handled internally.
"""

from .game_sdk import CausalGame

__all__ = ["CausalGame"]
