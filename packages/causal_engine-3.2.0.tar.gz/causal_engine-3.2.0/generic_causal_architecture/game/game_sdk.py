"""
CausalGame - Game-facing SDK for the causal inference engine.

One class, game-developer-friendly method names, zero knowledge of
internal architecture required.

Design principle:
    Every method name should be instantly understood by a game developer.
    No "inject_action", no "entity_relation", no "ActionResult".
    Instead: decide(), consequences(), check(), predict(), ...

Usage:
    from causal_engine.game import CausalGame

    game = CausalGame("rules.json")

    # Player makes a decision
    result = game.decide("player", "raise taxes", [
        ("high taxes", "public anger", "causes", 0.8),
    ])
    # result.immediate -> [{"source": "high taxes", "target": "public anger", ...}]
    # result.chains   -> [consequence chains...]

    # What happens if we follow this path?
    prediction = game.predict("raise taxes")

    # Does A cause B?
    relation = game.check("tyranny", "rebellion")

    # Save game
    game.save("slot1.json")
"""

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from ..core.causal_engine import CausalEngine
from ..core.action_models import Action, ActionRelation, ActionResult
from ..core.protocol import (
    CandidateRule,
    FeedbackRequest,
    RelationType,
)
from ..storage.memory_storage import MemoryStorage

logger = logging.getLogger(__name__)


@dataclass
class DecisionResult:
    """
    What happened after a game entity made a decision.

    Attributes:
        actor: who made the decision
        action: what they did
        immediate: direct effects (1-step consequences)
        chains: multi-step consequence chains (downstream ripple effects)
        entities_affected: all entities touched by this decision
        relations_added: how many new rules were learned
        raw: the underlying ActionResult (for advanced use)
    """
    actor: str
    action: str
    immediate: List[Dict[str, Any]] = field(default_factory=list)
    chains: List[Dict[str, Any]] = field(default_factory=list)
    entities_affected: List[str] = field(default_factory=list)
    relations_added: int = 0
    raw: Optional[ActionResult] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "actor": self.actor,
            "action": self.action,
            "immediate": self.immediate,
            "chains": self.chains,
            "entities_affected": self.entities_affected,
            "relations_added": self.relations_added,
        }


@dataclass
class RelationInfo:
    """
    Information about a causal relationship between two game concepts.

    Attributes:
        source: the cause
        target: the effect
        type: causes / enables / prevents / correlates
        strength: how strong this rule is (0.0 - 1.0)
                 High = well-established pattern, low = weak / speculative
        found: whether this relationship exists in the engine
    """
    source: str
    target: str
    type: str = ""
    strength: float = 0.0
    found: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "type": self.type,
            "strength": round(self.strength, 3),
            "found": self.found,
        }


@dataclass
class PatternMatch:
    """
    A historical/abstract pattern that matches the current game situation.

    Attributes:
        name: pattern name
        description: what this pattern describes
        score: how well it matches (0.0 - 1.0)
        advice: suggested actions based on this pattern
    """
    name: str
    description: str
    score: float = 0.0
    advice: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "score": round(self.score, 3),
            "advice": self.advice,
        }


class CausalGame:
    """
    Game-facing causal engine. One class to rule them all.

    Wraps CausalEngine + MemoryStorage into a simple interface
    designed for game developers. No internal architecture knowledge needed.

    Quick start:
        game = CausalGame("data/rules.json")
        result = game.decide("player", "raise taxes", [("tax", "anger", "causes")])
        game.save("save.json")

    Args:
        rules_path: path to a rule pack JSON file (optional)
        storage: a pre-initialized StorageInterface (optional, overrides rules_path)
        trace_depth: how deep to trace consequence chains (default 5)
        llm: an LLMProvider for runtime rule discovery (optional)
    """

    def __init__(
        self,
        rules_path: Optional[str] = None,
        storage: Optional[Any] = None,
        trace_depth: int = 5,
        llm: Optional[Any] = None,
    ):
        if storage is not None:
            self._storage = storage
        else:
            self._storage = MemoryStorage()
            self._storage.initialize()

        self._engine = CausalEngine(self._storage)
        self._trace_depth = trace_depth
        self._llm = llm
        self._rules_path = rules_path

        if rules_path and storage is None:
            self._storage.load_rules(rules_path)

        if llm is not None:
            self._engine.get_rule_discovery(llm_provider=llm)

    # ================================================================
    # Core: Decisions & Consequences
    # ================================================================

    def decide(
        self,
        actor: str,
        action_name: str,
        effects: List[Tuple[str, str, str, float]],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> DecisionResult:
        """
        A game entity (player, NPC, faction) makes a decision.

        This is the PRIMARY method for game integration.
        Every player action, NPC decision, or world event should go through here.

        Args:
            actor: who is acting (e.g. "player", "kingdom_wei", "merchant_guild")
            action_name: what they're doing (e.g. "raise taxes", "declare war")
            effects: list of (source, target, relation_type, strength) tuples
                     e.g. [("high taxes", "public anger", "causes", 0.8)]
                     relation_type: causes / enables / prevents / correlates
                     strength: how likely this effect is (0.0 - 1.0)
            metadata: optional extra data to attach

        Returns:
            DecisionResult with immediate effects and downstream chains

        Example:
            result = game.decide("player", "raise taxes", [
                ("high taxes", "public anger", "causes", 0.8),
                ("high taxes", "treasury full", "causes", 0.9),
            ])
            print(result.immediate)   # direct effects
            print(result.chains)      # ripple effects (anger -> rebellion -> ...)
        """
        relations = [
            ActionRelation(source=s, target=t, relation_type=rt, confidence=c)
            for s, t, rt, c in effects
        ]

        action = Action(
            name=action_name,
            actor=actor,
            relations=relations,
            metadata=metadata or {},
        )

        raw = self._engine.inject_action(action, trace_depth=self._trace_depth)

        chains_data = []
        for chain in raw.consequence_chains:
            chains_data.append(chain.to_dict())

        return DecisionResult(
            actor=actor,
            action=action_name,
            immediate=raw.immediate_effects,
            chains=chains_data,
            entities_affected=raw.entities_affected,
            relations_added=raw.relations_added,
            raw=raw,
        )

    def consequences(self, entity: str, depth: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        What are the consequences of a game concept/event?

        Traces forward from the given entity through the causal graph.

        Args:
            entity: the game concept to trace from (e.g. "public anger")
            depth: how deep to trace (default: self.trace_depth)

        Returns:
            List of consequence chains

        Example:
            chains = game.consequences("public anger")
            # [{"trigger": "public anger", "steps": [...], "total_confidence": 0.6}, ...]
        """
        if not self._engine.kg_reasoner:
            return []

        d = depth or self._trace_depth
        raw_chains = self._engine.kg_reasoner.trace_forward(entity, d)

        result = []
        for chain in raw_chains:
            steps = []
            for link in chain.links:
                steps.append({
                    "source": link.source_name,
                    "target": link.target_name,
                    "relation_type": link.relation_type,
                    "likelihood": round(link.confidence, 3),
                })
            result.append({
                "trigger": entity,
                "steps": steps,
                "length": len(steps),
            })
        return result

    def predict(self, action_name: str, effects: List[Tuple[str, str, str, float]]) -> List[Dict[str, Any]]:
        """
        Preview what would happen WITHOUT actually applying it.

        Like decide() but does not persist anything to the engine.
        Useful for showing players "if you do X, Y might happen" before
        they commit.

        Args:
            action_name: what action to preview
            effects: list of (source, target, type, strength) tuples

        Returns:
            List of predicted consequence chains (from existing rules only)

        Example:
            preview = game.predict("declare war", [
                ("war", "casualties", "causes", 0.9),
            ])
        """
        all_targets = [t for _, t, _, _ in effects]
        result = []
        for target in all_targets:
            chains = self.consequences(target)
            result.extend(chains)
        return result

    # ================================================================
    # Query: Check & Search
    # ================================================================

    def check(self, source: str, target: str, relation_type: str = "causes") -> RelationInfo:
        """
        Does A cause (or enable/prevent/correlate with) B?

        Args:
            source: the cause (e.g. "tyranny")
            target: the effect (e.g. "rebellion")
            relation_type: causes / enables / prevents / correlates

        Returns:
            RelationInfo with found status and confidence

        Example:
            rel = game.check("tyranny", "rebellion")
            if rel.found:
                print(f"Tyranny {rel.type} rebellion (strength: {rel.strength:.0%})")
        """
        found = self._storage.find_entity_relation(source, target, relation_type)
        if found:
            return RelationInfo(
                source=source,
                target=target,
                type=relation_type,
                strength=found.get("confidence", 0.0),
                found=True,
            )
        return RelationInfo(source=source, target=target, found=False)

    def check_conflicts(self, source: str, target: str) -> List[RelationInfo]:
        """
        Are there conflicting rules about A -> B?

        E.g. "trade causes prosperity" vs "trade causes dependency"

        Args:
            source: the cause
            target: the effect

        Returns:
            List of conflicting relations

        Example:
            conflicts = game.check_conflicts("trade", "prosperity")
            for c in conflicts:
                print(f"Conflict: {c.type} (strength: {c.strength})")
        """
        raw = self._storage.find_conflicting_relations(source, target, "causes")
        results = []
        for r in raw:
            results.append(RelationInfo(
                source=source,
                target=target,
                type=r.get("relation_type", ""),
                strength=r.get("confidence", 0.0),
                found=True,
            ))
        return results

    def search(self, keyword: str, limit: int = 20) -> List[Dict[str, Any]]:
        """
        Search for game rules matching a keyword.

        Args:
            keyword: search term (e.g. "war", "trade", "tax")
            limit: max results

        Returns:
            List of matching relations

        Example:
            rules = game.search("rebellion")
            # [{"source": "tyranny", "target": "rebellion", ...}, ...]
        """
        return self._storage.search_entity_relations(keyword, limit=limit)

    # ================================================================
    # Patterns: Historical / Abstract Pattern Matching
    # ================================================================

    def match_pattern(self, situation: str, top_k: int = 3) -> List[PatternMatch]:
        """
        Does the current game situation match any known historical pattern?

        Uses keyword matching (no LLM needed).

        Args:
            situation: description of the current situation
                       (e.g. "heavy taxation leads to widespread discontent")
            top_k: how many matches to return

        Returns:
            List of matching patterns with scores and advice

        Example:
            matches = game.match_pattern("king raises taxes, people angry")
            for m in matches:
                print(f"{m.name}: {m.advice} (score: {m.score})")
        """
        raw = self._engine.match_meta_patterns(situation, top_k=top_k)
        results = []
        for r in raw:
            results.append(PatternMatch(
                name=r.get("name", ""),
                description=r.get("description", ""),
                score=r.get("score", 0.0),
                advice=r.get("advice", r.get("description", "")),
            ))
        return results

    async def match_pattern_smart(self, situation: str, top_k: int = 3) -> List[PatternMatch]:
        """
        Semantic pattern matching using LLM (more accurate, requires LLM).

        Like match_pattern() but understands meaning, not just keywords.

        Args:
            situation: description of the current situation
            top_k: how many matches to return

        Returns:
            List of matching patterns with scores and advice
        """
        raw = await self._engine.match_meta_patterns_semantic(situation, top_k=top_k)
        results = []
        for r in raw:
            results.append(PatternMatch(
                name=r.get("name", ""),
                description=r.get("description", ""),
                score=r.get("score", 0.0),
                advice=r.get("advice", r.get("description", "")),
            ))
        return results

    def list_patterns(self) -> List[Dict[str, Any]]:
        """
        List all known historical/abstract patterns.

        Returns:
            List of all meta-patterns
        """
        return self._engine.list_meta_patterns()

    # ================================================================
    # Feedback & Learning
    # ================================================================

    def feedback(
        self,
        source: str,
        target: str,
        predicted: str,
        actual: str,
        matched: bool,
    ) -> Dict[str, Any]:
        """
        Report whether a prediction came true.

        The engine learns from this: correct predictions increase confidence,
        wrong ones decrease it.

        Args:
            source: rule source (e.g. "high taxes")
            target: rule target (e.g. "rebellion")
            predicted: what the engine predicted would happen
            actual: what actually happened
            matched: did the prediction match reality?

        Returns:
            Feedback processing result

        Example:
            # Player's rebellion actually happened
            game.feedback("high taxes", "rebellion", "rebellion occurs", "rebellion occurs", True)

            # Player's rebellion did NOT happen (maybe they were appeased)
            game.feedback("high taxes", "rebellion", "rebellion occurs", "peace maintained", False)
        """
        fb = FeedbackRequest(
            rule_source=source,
            rule_target=target,
            rule_relation_type="causes",
            predicted_outcome=predicted,
            actual_outcome=actual,
            match=matched,
        )
        return self._engine.process_feedback(fb)

    def adjust_confidence(
        self, source: str, target: str, relation_type: str, delta: float
    ) -> bool:
        """
        Manually adjust how confident the engine is about a rule.

        Positive delta = more confident, negative = less confident.

        Args:
            source: cause
            target: effect
            relation_type: causes / enables / prevents / correlates
            delta: adjustment (-1.0 to +1.0)

        Returns:
            Whether the adjustment was applied

        Example:
            # A game event proves this rule is reliable
            game.adjust_confidence("trade", "prosperity", "causes", 0.1)

            # A game event casts doubt on this rule
            game.adjust_confidence("trade", "prosperity", "causes", -0.2)
        """
        return self._engine.adjust_confidence(source, target, relation_type, delta)

    async def discover_rules(self, context: str, world_state: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Let the engine discover new rules from game context using LLM.

        Requires an LLM provider to be set in the constructor.

        Args:
            context: what's happening in the game right now
            world_state: current game state (optional)

        Returns:
            Discovery result with new candidate rules

        Example:
            result = await game.discover_rules(
                "The merchant guild is protesting high tariffs",
                {"tariff_rate": 0.3, "guild_power": 0.7}
            )
        """
        from ..core.protocol import DiscoverRequest
        req = DiscoverRequest(
            context=context,
            world_state=world_state or {},
        )
        result = await self._engine.discover_rules(req)
        return result.to_dict()

    def validate_rule(
        self,
        source: str,
        target: str,
        relation_type: str = "causes",
        confidence: float = 0.7,
    ) -> Dict[str, Any]:
        """
        Check if a potential rule is valid (no conflicts with existing rules).

        Useful before adding custom rules or when NPCs are reasoning about
        whether something makes sense.

        Args:
            source: cause
            target: effect
            relation_type: causes / enables / prevents / correlates
            confidence: proposed confidence level

        Returns:
            Validation result with conflicts and recommendations

        Example:
            result = game.validate_rule("democracy", "stability")
            if result["is_valid"]:
                print("This rule is consistent with existing knowledge")
            else:
                print(f"Conflicts: {result['conflicts']}")
        """
        from ..core.protocol import CandidateRule
        rule = CandidateRule(
            source=source,
            target=target,
            relation_type=relation_type,
            confidence=confidence,
        )
        result = self._engine.validate_rule(rule)
        return result.to_dict()

    # ================================================================
    # Save / Load
    # ================================================================

    def save(self, filepath: str) -> str:
        """
        Save all current rules to a JSON file (game save).

        Args:
            filepath: where to save (e.g. "saves/slot1.json")

        Returns:
            The filepath that was written to

        Example:
            game.save("saves/slot1.json")
        """
        return self._storage.export_rules(filepath)

    @classmethod
    def load(cls, filepath: str, **kwargs) -> "CausalGame":
        """
        Load a saved game from a JSON file.

        Alternative to the constructor when you have a save file.

        Args:
            filepath: path to the save file
            **kwargs: additional constructor args (trace_depth, llm, etc.)

        Returns:
            A new CausalGame instance with the saved rules loaded

        Example:
            game = CausalGame.load("saves/slot1.json")
        """
        return cls(rules_path=filepath, **kwargs)

    def reload(self) -> None:
        """
        Reload rules from the original rules file (if any).

        Useful for hot-reloading rules during development.
        """
        if self._rules_path and os.path.exists(self._rules_path):
            if isinstance(self._storage, MemoryStorage):
                self._storage._entity_relations.clear()
                self._storage._entities.clear()
                self._storage._entity_by_name.clear()
            self._storage.load_rules(self._rules_path)

    # ================================================================
    # NPC & World Simulation
    # ================================================================

    def create_world(self, num_npcs: int = 5, npc_configs: Optional[List[Dict]] = None) -> Any:
        """
        Create a multi-agent simulation world from the current rule set.

        NPCs will autonomously make decisions based on the causal graph,
        creating emergent behavior.

        Args:
            num_npcs: number of NPC agents to create
            npc_configs: optional list of NPC configurations
                         [{"role": "king", "strategy": "analyst"}, ...]
                         Strategies: analyst, explorer, skeptic, synthesizer, predictor

        Returns:
            MultiAgentSimulator instance (call .run_simulation() on it)

        Example:
            world = game.create_world(num_npcs=10)
            result = await world.run_simulation(steps=20)
        """
        from ..simulation.multi_agent_simulator import MultiAgentSimulator

        sim = MultiAgentSimulator(storage=self._storage, num_agents=num_npcs)
        sim.build_world_from_kg()
        sim.create_agents(configs=npc_configs)
        return sim

    # ================================================================
    # Info & Stats
    # ================================================================

    def stats(self) -> Dict[str, Any]:
        """
        Get engine statistics.

        Returns:
            Dict with entity_count, relation_count, plus engine internals

        Example:
            info = game.stats()
            print(f"{info['entity_count']} entities, {info['relation_count']} rules")
        """
        engine_stats = self._engine.get_stats()
        entity_count = 0
        relation_count = 0
        if isinstance(self._storage, MemoryStorage):
            entity_count = len(self._storage._entities)
            relation_count = len(self._storage._entity_relations)
        return {
            "entity_count": entity_count,
            "relation_count": relation_count,
            **engine_stats,
        }

    def chain_between(self, source: str, target: str) -> List[Dict[str, Any]]:
        """
        Find causal paths between two game concepts.

        E.g. "How does 'tax increase' lead to 'civil war'?"

        Args:
            source: starting concept
            target: ending concept

        Returns:
            List of causal chains connecting source to target

        Example:
            paths = game.chain_between("tax increase", "civil war")
            for path in paths:
                steps = " -> ".join(s["target"] for s in path["steps"])
                print(f"tax increase -> {steps}")
        """
        if not self._engine.kg_reasoner:
            return []

        raw = self._engine.find_chain_between(source, target)
        if not raw:
            return []

        result = []
        for chain in raw:
            steps = []
            for link in chain.links:
                steps.append({
                    "source": link.source_name,
                    "target": link.target_name,
                    "relation_type": link.relation_type,
                    "likelihood": round(link.confidence, 3),
                })
            result.append({"steps": steps, "length": len(steps)})
        return result

    def trace(self, entity: str, direction: str = "forward", depth: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Trace all causal chains from/to a game concept.

        Args:
            entity: the concept to trace from
            direction: "forward" (consequences) or "backward" (causes)
            depth: how deep to trace

        Returns:
            List of traced chains

        Example:
            # What does "rebellion" lead to?
            forward = game.trace("rebellion", "forward")

            # What causes "rebellion"?
            backward = game.trace("rebellion", "backward")
        """
        if not self._engine.kg_reasoner:
            return []

        d = depth or self._trace_depth
        raw_chains = self._engine.trace_chain(entity, direction=direction, depth=d)

        result = []
        for chain in raw_chains:
            steps = []
            for link in chain.links:
                steps.append({
                    "source": link.source_name,
                    "target": link.target_name,
                    "relation_type": link.relation_type,
                    "likelihood": round(link.confidence, 3),
                })
            result.append({
                "entity": entity,
                "direction": direction,
                "steps": steps,
                "length": len(steps),
            })
        return result

    # ================================================================
    # Deep Reasoning: LANCET 7-dimension checks
    # ================================================================

    def is_cause(self, event_a: str, event_b: str) -> Dict[str, Any]:
        """
        Does A really cause B? Deep LANCET 7-dimension reasoning.

        Goes beyond database lookup: runs temporal, necessity, sufficiency,
        directness, confounding, evidence, and mechanism checks.

        Use this when you need a DEFINTIVE answer, not just a lookup.

        Args:
            event_a: the suspected cause (e.g. "high taxes")
            event_b: the suspected effect (e.g. "rebellion")

        Returns:
            Dict with:
              - is_cause (bool): definitive answer
              - relation_type (str): causes / enables / prevents / correlates
              - certainty (float): 0.0-1.0, how certain the engine is
              - checks (list): 7 individual check results with scores
              - reasoning (list): step-by-step reasoning chain
              - evidence (list): supporting evidence sources
              - alternatives (list): alternative explanations
              - suggestions (list): how to strengthen the conclusion

        Example:
            result = game.is_cause("high taxes", "rebellion")
            if result["is_cause"]:
                print(f"Certainty: {result['certainty']:.0%}")
                for check in result["checks"]:
                    print(f"  {check['type']}: {'PASS' if check['passed'] else 'FAIL'} ({check['score']:.2f})")
        """
        explanation = self._engine.explain_causality(event_a, event_b)
        return {
            "is_cause": explanation["has_causality"],
            "relation_type": explanation.get("relation_type"),
            "certainty": round(explanation["confidence"], 3),
            "checks": explanation["checks"],
            "reasoning": explanation["reasoning_chain"],
            "evidence": explanation["evidence_sources"],
            "alternatives": explanation["alternative_explanations"],
            "suggestions": explanation["suggestions"],
        }

    def why(self, source: str, target: str) -> Dict[str, Any]:
        """
        Explain WHY source causes target. Returns the reasoning chain.

        Like is_cause() but focused on the explanation narrative,
        perfect for showing players or NPC dialogue.

        Args:
            source: the cause
            target: the effect

        Returns:
            Dict with:
              - cause (bool): whether causality exists
              - reasoning (list): step-by-step explanation
              - certainty (float): overall certainty
              - evidence (list): evidence sources
              - alternatives (list): other possible explanations
              - narrative (str): human-readable one-line summary

        Example:
            result = game.why("tyranny", "rebellion")
            print(result["narrative"])
            # "Tyranny leads to rebellion because of sustained oppression
            #  that eliminates peaceful alternatives (certainty: 88%)"
        """
        explanation = self._engine.explain_causality(source, target)
        reasoning = explanation["reasoning_chain"]
        certainty = round(explanation["confidence"], 3)
        narrative = ""
        if explanation["has_causality"] and reasoning:
            steps = " -> ".join(reasoning[:4])
            narrative = f"{source} leads to {target}: {steps} (certainty: {certainty:.0%})"
        elif not explanation["has_causality"]:
            narrative = f"{source} does not appear to cause {target}"
            if explanation["alternative_explanations"]:
                alts = ", ".join(explanation["alternative_explanations"][:2])
                narrative += f". Alternative: {alts}"
        return {
            "cause": explanation["has_causality"],
            "reasoning": reasoning,
            "certainty": certainty,
            "evidence": explanation["evidence_sources"],
            "alternatives": explanation["alternative_explanations"],
            "narrative": narrative,
        }

    def certainty_of(self, source: str, target: str) -> float:
        """
        How certain is the engine that A causes B?

        Quick numeric check without full explanation overhead.
        Returns 0.0 if no relationship exists.

        Args:
            source: the cause
            target: the effect

        Returns:
            float: certainty score (0.0 - 1.0)

        Example:
            if game.certainty_of("trade", "prosperity") > 0.8:
                print("This is a very reliable rule")
        """
        return round(self._engine.get_causal_confidence(source, target), 3)

    def network(self, entities: Optional[List[str]] = None) -> Dict[str, List[Dict[str, Any]]]:
        """
        Build a complete causal network graph.

        Returns all known causal relationships, optionally filtered to
        a set of entities. Perfect for rendering relationship diagrams,
        faction power maps, or world state visualizations.

        Args:
            entities: optional list of entity names to include.
                      If None, includes ALL entities in the engine.

        Returns:
            Dict mapping each entity to its outgoing causal links:
              {
                "tyranny": [{"target": "rebellion", "type": "causes", "strength": 0.9}, ...],
                "trade": [{"target": "prosperity", "type": "causes", "strength": 0.8}, ...],
              }

        Example:
            graph = game.network(["tyranny", "rebellion", "trade", "prosperity"])
            for entity, links in graph.items():
                for link in links:
                    print(f"{entity} --{link['type']}--> {link['target']} ({link['strength']})")
        """
        if entities:
            result = {}
            for name in entities:
                rels = self._storage.search_entity_relations(name, limit=100)
                outgoing = []
                for r in rels:
                    if r.get("source") == name:
                        outgoing.append({
                            "target": r["target"],
                            "type": r.get("relation_type", "causes"),
                            "strength": round(r.get("confidence", 0.0), 3),
                        })
                if outgoing:
                    result[name] = outgoing
            return result

        all_rels = self._storage.search_entity_relations("", limit=9999)
        result = {}
        for r in all_rels:
            src = r.get("source", "")
            if not src:
                continue
            if src not in result:
                result[src] = []
            result[src].append({
                "target": r.get("target", ""),
                "type": r.get("relation_type", "causes"),
                "strength": round(r.get("confidence", 0.0), 3),
            })
        return result

    def discover_hidden(self, min_strength: float = 0.5, max_depth: int = 3) -> List[Dict[str, Any]]:
        """
        Discover hidden / implicit relationships via transitive reasoning.

        Finds A->C where A->B and B->C exist but A->C is not yet recorded.
        Like connecting dots the engine hasn't explicitly linked yet.

        Requires the KG reasoner to be loaded (happens automatically after
        enough rules are loaded via decide() or the constructor).

        Args:
            min_strength: minimum confidence threshold for discovered relations
            max_depth: max chain length to explore

        Returns:
            List of discovered relations:
              [{
                 "source": "tax increase",
                 "target": "civil war",
                 "relation_type": "causes",
                 "likelihood": 0.6,
                 "chain_length": 2,
                 "evidence_chain": "tax increase -> public anger -> rebellion",
              }, ...]

        Example:
            hidden = game.discover_hidden(min_strength=0.6)
            for h in hidden:
                print(f"Hidden: {h['source']} -> {h['target']} ({h['likelihood']:.0%})")
                print(f"  via: {h['evidence_chain']}")
        """
        raw = self._engine.discover_relations(min_confidence=min_strength, max_length=max_depth)
        return [
            {
                "source": r["source"],
                "target": r["target"],
                "relation_type": r["relation_type"],
                "likelihood": r["confidence"],
                "chain_length": r.get("chain_length", 0),
                "evidence_chain": r.get("evidence_chain", ""),
            }
            for r in raw
        ]

    # ================================================================
    # Advanced: Direct engine access
    # ================================================================

    @property
    def engine(self) -> CausalEngine:
        """
        Direct access to the underlying CausalEngine.

        For advanced use cases not covered by the Game SDK.
        """
        return self._engine

    @property
    def storage(self) -> Any:
        """
        Direct access to the underlying storage.

        For advanced use cases not covered by the Game SDK.
        """
        return self._storage
