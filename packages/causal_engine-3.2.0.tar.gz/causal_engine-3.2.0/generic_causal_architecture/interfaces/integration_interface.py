"""
项目整合接口定义
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class IIntegration(ABC):
    """项目整合接口定义
    
    所有外部项目整合（如 gitnexus、langextract、mirofish 等）都必须实现此接口。
    """
    
    @property
    @abstractmethod
    def integration_name(self) -> str:
        """获取整合项目名称
        
        Returns:
            str: 项目名称
        """
        pass
    
    @property
    @abstractmethod
    def external_project_path(self) -> Optional[str]:
        """获取外部项目路径
        
        Returns:
            Optional[str]: 外部项目路径，如果没有设置返回 None
        """
        pass
    
    @abstractmethod
    def connect(self, **kwargs) -> bool:
        """连接到外部项目
        
        Args:
            **kwargs: 连接参数
            
        Returns:
            bool: 连接成功返回 True
        """
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        """断开与外部项目的连接"""
        pass
    
    @abstractmethod
    def integrate(self, external_data: Any, **kwargs) -> Dict[str, Any]:
        """整合外部项目的数据和能力
        
        Args:
            external_data: 外部项目的数据
            **kwargs: 额外的参数
            
        Returns:
            Dict[str, Any]: 整合后的数据
        """
        pass
    
    @abstractmethod
    def extract_knowledge(self, **kwargs) -> List[Dict[str, Any]]:
        """从外部项目提取知识
        
        Args:
            **kwargs: 提取参数
            
        Returns:
            List[Dict[str, Any]]: 提取的知识列表
        """
        pass
    
    @abstractmethod
    def transform_to_internal_format(self, external_data: Any) -> Any:
        """将外部数据转换为内部格式
        
        Args:
            external_data: 外部数据
            
        Returns:
            Any: 内部格式的数据
        """
        pass
    
    @abstractmethod
    def get_capabilities(self) -> Dict[str, Any]:
        """获取外部项目提供的能力
        
        Returns:
            Dict[str, Any]: 能力描述字典
        """
        pass
