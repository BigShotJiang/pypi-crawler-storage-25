"""
因果引擎接口定义
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class ICausalEngine(ABC):
    """因果引擎接口定义
    
    这是架构的核心接口，所有因果推断引擎都必须实现此接口。
    通过依赖这个接口而不是具体实现，我们可以轻松替换不同的引擎实现。
    """
    
    @abstractmethod
    def infer_causality(self, event_a: Any, event_b: Any) -> bool:
        """推断两个事件之间的因果关系
        
        Args:
            event_a: 可能的原因事件
            event_b: 可能的结果事件
            
        Returns:
            bool: 如果存在因果关系返回 True，否则返回 False
        """
        pass
    
    @abstractmethod
    def get_causal_network(self, events: List[Any]) -> Dict[Any, List[Any]]:
        """构建事件网络中的因果关系图
        
        Args:
            events: 事件列表
            
        Returns:
            Dict[Any, List[Any]]: 因果关系图，键为事件，值为该事件导致的事件列表
        """
        pass
    
    @abstractmethod
    def set_domain_adapter(self, domain_adapter: 'IDomainAdapter') -> None:
        """设置领域适配器
        
        Args:
            domain_adapter: 领域适配器实例
        """
        pass
    
    @abstractmethod
    def get_causal_confidence(self, event_a: Any, event_b: Any) -> float:
        """获取因果关系的置信度
        
        Args:
            event_a: 可能的原因事件
            event_b: 可能的结果事件
            
        Returns:
            float: 置信度分数，范围 0-1
        """
        pass
    
    @abstractmethod
    def explain_causality(self, event_a: Any, event_b: Any) -> Dict[str, Any]:
        """解释因果关系推断的理由
        
        Args:
            event_a: 可能的原因事件
            event_b: 可能的结果事件
            
        Returns:
            Dict[str, Any]: 解释信息，包含推断依据、检查项等
        """
        pass
