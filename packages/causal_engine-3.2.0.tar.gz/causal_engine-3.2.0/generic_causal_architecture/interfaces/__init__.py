"""
接口定义层 - 定义所有抽象基类和接口

这一层是架构的核心，所有其他层都依赖这些接口定义，而不是具体实现。
这样可以确保完全解耦，便于未来扩展。
"""

from .causal_engine_interface import ICausalEngine
from .domain_adapter_interface import IDomainAdapter
from .method_interface import IMethod
from .integration_interface import IIntegration

__all__ = [
    'ICausalEngine',
    'IDomainAdapter',
    'IMethod',
    'IIntegration'
]
