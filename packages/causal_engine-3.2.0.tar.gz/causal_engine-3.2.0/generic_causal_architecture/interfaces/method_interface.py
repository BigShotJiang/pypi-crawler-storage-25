"""
方法论接口定义
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List


class IMethod(ABC):
    """方法论接口定义
    
    所有方法论实现（如柳叶刀方法、迭代工作流等）都必须实现此接口。
    """
    
    @property
    @abstractmethod
    def method_name(self) -> str:
        """获取方法名称
        
        Returns:
            str: 方法名称
        """
        pass
    
    @abstractmethod
    def decompose_task(self, task: Any, **kwargs) -> List[Dict[str, Any]]:
        """将复杂任务分解为子任务
        
        Args:
            task: 复杂任务
            **kwargs: 额外的参数
            
        Returns:
            List[Dict[str, Any]]: 子任务列表，每个子任务是一个字典
        """
        pass
    
    @abstractmethod
    def select_solution(self, task_features: Dict[str, Any]) -> str:
        """根据任务特征选择最优解决方案
        
        Args:
            task_features: 任务特征字典
            
        Returns:
            str: 解决方案类型，如 'rule_based', 'llm_based', 'code_optimized', 'hybrid'
        """
        pass
    
    @abstractmethod
    def apply_method(self, data: Any, **kwargs) -> Dict[str, Any]:
        """应用方法论到数据
        
        Args:
            data: 输入数据
            **kwargs: 额外的参数
            
        Returns:
            Dict[str, Any]: 应用结果
        """
        pass
    
    @abstractmethod
    def evaluate_result(self, result: Any, expected: Any = None) -> Dict[str, float]:
        """评估结果质量
        
        Args:
            result: 实际结果
            expected: 期望结果（可选）
            
        Returns:
            Dict[str, float]: 评估指标字典
        """
        pass
