"""
领域适配器接口定义
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class IDomainAdapter(ABC):
    """领域适配器接口定义
    
    领域适配器是架构可扩展到任何领域的关键。通过实现这个接口，
    我们可以让同一个因果引擎适应不同领域的特定需求。
    """
    
    @property
    @abstractmethod
    def domain_name(self) -> str:
        """获取领域名称
        
        Returns:
            str: 领域名称，如 'history', 'natural_science', 'social_science' 等
        """
        pass
    
    @abstractmethod
    def preprocess(self, data: Any) -> Any:
        """预处理领域特定数据
        
        Args:
            data: 原始数据
            
        Returns:
            Any: 预处理后的数据
        """
        pass
    
    @abstractmethod
    def is_before(self, event_a: Any, event_b: Any) -> bool:
        """领域特定时序检查
        
        不同领域对"先后"的定义可能不同：
        - 历史领域：基于时间戳
        - 自然科学：基于实验顺序或逻辑顺序
        - 社会科学：基于调查时间或事件发生时间
        
        Args:
            event_a: 第一个事件
            event_b: 第二个事件
            
        Returns:
            bool: 如果 event_a 发生在 event_b 之前返回 True
        """
        pass
    
    @abstractmethod
    def is_possible_without(self, event_b: Any, event_a: Any) -> bool:
        """领域特定充分性检查
        
        检查在没有 event_a 的情况下，event_b 是否仍可能发生。
        这是因果推断的关键检查之一。
        
        Args:
            event_b: 结果事件
            event_a: 原因事件
            
        Returns:
            bool: 如果 event_b 可能在沒有 event_a 的情况下发生返回 True
        """
        pass
    
    @abstractmethod
    def has_intermediate_events(self, event_a: Any, event_b: Any, 
                                all_events: List[Any]) -> bool:
        """领域特定直接性检查
        
        检查 event_a 和 event_b 之间是否存在中间事件。
        如果存在中间事件，则 event_a 和 event_b 之间可能不是直接因果关系。
        
        Args:
            event_a: 起始事件
            event_b: 结束事件
            all_events: 所有事件的列表
            
        Returns:
            bool: 如果存在中间事件返回 True
        """
        pass
    
    @abstractmethod
    def extract_event_features(self, event: Any) -> Dict[str, Any]:
        """提取事件特征
        
        不同领域的事件可能有不同的特征表示。
        
        Args:
            event: 事件对象
            
        Returns:
            Dict[str, Any]: 事件特征字典
        """
        pass
    
    @abstractmethod
    def validate_event(self, event: Any) -> bool:
        """验证事件是否符合领域规范
        
        Args:
            event: 事件对象
            
        Returns:
            bool: 如果事件有效返回 True
        """
        pass
    
    @abstractmethod
    def get_domain_specific_rules(self) -> List[Dict[str, Any]]:
        """获取领域特定规则
        
        Returns:
            List[Dict[str, Any]]: 领域特定规则列表
        """
        pass
