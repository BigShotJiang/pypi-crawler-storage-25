"""
API 认证模块

支持多种认证方式：
1. API Key（简单场景）
2. JWT Token（生产场景）

使用示例：
    # API Key 认证
    headers = {"X-API-Key": "your-api-key"}
    response = requests.get("http://localhost:8000/health", headers=headers)
    
    # JWT Token 认证
    headers = {"Authorization": "Bearer your-jwt-token"}
    response = requests.get("http://localhost:8000/health", headers=headers)
"""

from fastapi import HTTPException, status, Security, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, APIKeyHeader
from typing import Optional
import os
import jwt
import time
from functools import lru_cache

# 安全配置
API_KEY_HEADER = APIKeyHeader(name="X-API-Key", auto_error=False)
security = HTTPBearer(auto_error=False)

# JWT 配置（从环境变量读取）
JWT_SECRET = os.getenv("JWT_SECRET", "dev-secret-key-change-in-production")
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION = 3600  # 1 小时


@lru_cache()
def get_valid_api_keys():
    """获取有效的 API Keys（从环境变量）"""
    keys_str = os.getenv("VALID_API_KEYS", "")
    if not keys_str:
        # 开发环境默认 key
        return {"dev-api-key"}
    
    return set(keys_str.split(","))


async def verify_api_key(
    api_key: Optional[str] = Security(API_KEY_HEADER)
) -> str:
    """
    验证 API Key
    
    Returns:
        user identifier
    
    Raises:
        HTTPException: 认证失败
    """
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API Key required"
        )
    
    valid_keys = get_valid_api_keys()
    
    if api_key not in valid_keys:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key"
        )
    
    # 返回用户标识（简单实现，返回 API Key 前缀）
    return f"user_{api_key[:8]}"


async def verify_jwt_token(
    credentials: Optional[HTTPAuthorizationCredentials] = Security(security)
) -> str:
    """
    验证 JWT Token
    
    Returns:
        user identifier (sub from JWT)
    
    Raises:
        HTTPException: 认证失败
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required"
        )
    
    try:
        payload = jwt.decode(
            credentials.credentials,
            JWT_SECRET,
            algorithms=[JWT_ALGORITHM]
        )
        
        # 检查过期
        exp = payload.get("exp")
        if exp and exp < time.time():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token expired"
            )
        
        # 返回用户标识
        sub = payload.get("sub")
        if not sub:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
        
        return sub
        
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid token"
        )


async def get_current_user(
    api_key: Optional[str] = Security(API_KEY_HEADER),
    credentials: Optional[HTTPAuthorizationCredentials] = Security(security)
) -> str:
    """
    获取当前用户（支持 API Key 和 JWT）
    
    优先级：
    1. JWT Token（如果提供）
    2. API Key（如果提供）
    3. 开发模式（返回 dev_user）
    
    Returns:
        user identifier
    """
    # 尝试 JWT Token
    if credentials:
        return await verify_jwt_token(credentials)
    
    # 尝试 API Key
    if api_key:
        return await verify_api_key(api_key)
    
    # 开发模式
    if os.getenv("DEBUG", "false").lower() == "true":
        return "dev_user"
    
    # 都需要，抛出异常
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required"
    )


def create_jwt_token(user_id: str, expires_in: int = JWT_EXPIRATION) -> str:
    """
    创建 JWT Token
    
    Args:
        user_id: 用户 ID
        expires_in: 过期时间（秒）
    
    Returns:
        JWT Token
    """
    payload = {
        "sub": user_id,
        "iat": time.time(),
        "exp": time.time() + expires_in
    }
    
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token


# 便捷函数
def require_auth(func):
    """
    装饰器：要求认证
    
    使用示例：
        @app.get("/protected")
        @require_auth
        async def protected_endpoint(user: str = Depends(get_current_user)):
            return {"user": user}
    """
    from functools import wraps
    
    @wraps(func)
    async def wrapper(*args, **kwargs):
        # 强制要求认证
        kwargs["user"] = await get_current_user()
        return await func(*args, **kwargs)
    
    return wrapper
