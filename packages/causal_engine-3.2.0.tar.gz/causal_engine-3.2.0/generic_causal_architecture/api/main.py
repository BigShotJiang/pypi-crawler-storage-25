"""
REST API 服务 - 生产级因果推断 API

功能：
1. 因果推断接口
2. 会话管理（多轮对话）
3. LLM 编排集成
4. 用户认证
5. 监控指标

使用示例：
    # 启动服务
    uvicorn generic_causal_architecture.api.main:app --reload
    
    # API 文档
    # http://localhost:8000/docs
"""

from fastapi import FastAPI, HTTPException, Depends, status, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import asyncio
import time
import os

# 导入核心组件
from ..config.config import Config
from ..core.causal_engine import CausalEngine
from ..storage.postgresql_storage import PostgreSQLStorage
from ..llm import create_llm_provider
from ..orchestrator import LLMOrchestrator
from ..utils.logging_setup import setup_logging
from .auth import get_current_user, verify_api_key

# 导入监控
from prometheus_fastapi_instrumentator import Instrumentator

# 设置日志
logger = setup_logging(__name__)

# 创建 FastAPI 应用
app = FastAPI(
    title="Generic Causal Architecture API",
    description="生产级因果推断 API 服务",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS 中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该限制
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局变量
config: Optional[Config] = None
causal_engine: Optional[CausalEngine] = None
llm_orchestrator: Optional[LLMOrchestrator] = None
sessions: Dict[str, Dict[str, Any]] = {}


# ============== 请求/响应模型 ==============

class InferenceRequest(BaseModel):
    """因果推断请求"""
    domain: str = Field(..., description="领域（history/economics 等）")
    events: List[Dict[str, Any]] = Field(..., description="事件列表")
    method: str = Field(default="lancet", description="推断方法")
    options: Dict[str, Any] = Field(default_factory=dict, description="选项")


class InferenceResponse(BaseModel):
    """因果推断响应"""
    task_id: str
    status: str  # processing/completed/failed
    result_url: Optional[str] = None


class ChatRequest(BaseModel):
    """会话请求"""
    content: str = Field(..., description="用户输入")
    domain: Optional[str] = None


class ChatResponse(BaseModel):
    """会话响应"""
    content: str
    intent: Dict[str, Any]
    events_count: int
    relations_count: int
    llm_usage: Dict[str, Any]
    latency: float


# ============== 生命周期管理 ==============

@app.on_event("startup")
async def startup_event():
    """服务启动时初始化"""
    global config, causal_engine, llm_orchestrator
    
    logger.info("Starting Generic Causal Architecture API")
    
    # 1. 加载配置
    config_path = os.getenv("CONFIG_PATH", "config/production.yaml")
    config = Config.from_yaml(config_path)
    logger.info(f"Loaded config from {config_path}")
    
    # 2. 初始化存储
    storage = PostgreSQLStorage(
        database_url=config.storage.database_url,
        pool_size=config.storage.pool_size,
        max_overflow=config.storage.max_overflow
    )
    logger.info("PostgreSQL storage initialized")
    
    # 3. 初始化因果引擎
    causal_engine = CausalEngine(
        storage=storage,
        config=config.causal
    )
    logger.info("Causal engine initialized")
    
    # 4. 初始化 LLM Provider（用户配置）
    try:
        llm_provider = create_llm_provider({
            "provider": config.llm.provider,
            "api_key": config.llm.api_key,
            "model": config.llm.model,
            "base_url": config.llm.base_url,
            "temperature": config.llm.temperature,
            "max_tokens": config.llm.max_tokens,
        })
        logger.info(f"LLM provider initialized: {config.llm.provider}")
    except Exception as e:
        logger.warning(f"LLM provider not configured: {e}")
        llm_provider = None
    
    # 5. 初始化编排器
    if llm_provider:
        llm_orchestrator = LLMOrchestrator(
            llm_provider=llm_provider,
            causal_engine=causal_engine
        )
        logger.info("LLM orchestrator initialized")
    else:
        logger.info("LLM orchestrator disabled (no LLM provider)")
    
    logger.info("Startup complete")


@app.on_event("shutdown")
async def shutdown_event():
    """服务关闭时清理"""
    logger.info("Shutting down Generic Causal Architecture API")


# ============== 中间件 ==============

@app.middleware("http")
async def log_requests(request: Request, call_next):
    """记录所有请求"""
    start_time = time.time()
    
    response = await call_next(request)
    
    duration = time.time() - start_time
    
    logger.info(
        "request_completed",
        extra={
            "method": request.method,
            "path": request.url.path,
            "status": response.status_code,
            "duration_sec": round(duration, 3)
        }
    )
    
    return response


# ============== 健康检查 ==============

@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": time.time()
    }


@app.get("/ready")
async def readiness_check():
    """就绪检查"""
    checks = {
        "api": True,
        "storage": False,
        "engine": False,
        "llm": False
    }
    
    # 检查存储
    if causal_engine and causal_engine.storage:
        checks["storage"] = True
    
    # 检查引擎
    if causal_engine:
        checks["engine"] = True
    
    # 检查 LLM
    if llm_orchestrator:
        checks["llm"] = True
    
    all_healthy = all(checks.values())
    
    return {
        "status": "ready" if all_healthy else "degraded",
        "checks": checks
    }


# ============== 因果推断接口 ==============

@app.post("/api/v1/inference", response_model=InferenceResponse)
async def create_inference(
    request: InferenceRequest,
    user: str = Depends(get_current_user)
):
    """
    创建因果推断任务
    
    返回 task_id，用于异步查询结果
    """
    task_id = f"task_{asyncio.get_event_loop().time()}"
    
    logger.info(
        "inference_started",
        extra={
            "task_id": task_id,
            "user": user,
            "domain": request.domain,
            "event_count": len(request.events)
        }
    )
    
    # 转换为内部数据结构
    from ..model.event_data import EventData
    events = [
        EventData(
            id=e.get("id"),
            name=e.get("name"),
            timestamp=e.get("timestamp"),
            location=e.get("location"),
            event_type=e.get("event_type"),
            description=e.get("description"),
            metadata=e.get("metadata")
        )
        for e in request.events
    ]
    
    # 异步执行推断
    async def run_inference():
        try:
            result = causal_engine.infer_causality(
                events,
                method=request.method,
                options=request.options
            )
            
            # 存储结果
            sessions[task_id] = {
                "status": "completed",
                "result": {
                    "relations": [
                        {
                            "source": r.source,
                            "target": r.target,
                            "confidence": r.confidence,
                            "method": r.method
                        }
                        for r in result.relations
                    ]
                },
                "user": user
            }
            
        except Exception as e:
            logger.error(
                "inference_failed",
                extra={
                    "task_id": task_id,
                    "error": str(e),
                    "exc_info": True
                }
            )
            sessions[task_id] = {
                "status": "failed",
                "error": str(e)
            }
    
    # 后台执行
    asyncio.create_task(run_inference())
    
    # 立即返回 task_id
    return InferenceResponse(
        task_id=task_id,
        status="processing",
        result_url=f"/api/v1/tasks/{task_id}/result"
    )


@app.get("/api/v1/tasks/{task_id}/result")
async def get_task_result(task_id: str, user: str = Depends(get_current_user)):
    """获取任务结果"""
    if task_id not in sessions:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Task not found"
        )
    
    task = sessions[task_id]
    
    # 权限检查
    if task.get("user") != user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    return {
        "task_id": task_id,
        "status": task["status"],
        "result": task.get("result"),
        "error": task.get("error")
    }


# ============== 会话接口（LLM 编排） ==============

@app.post("/api/v1/chat", response_model=ChatResponse)
async def create_chat(
    request: ChatRequest,
    session_id: Optional[str] = None,
    user: str = Depends(get_current_user)
):
    """
    创建会话（使用 LLM 编排器）
    
    自动：
    1. 理解意图
    2. 准备数据
    3. 因果推断
    4. 生成解释
    """
    if not llm_orchestrator:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="LLM orchestrator not available"
        )
    
    # 生成会话 ID
    if not session_id:
        session_id = f"session_{user}_{time.time()}"
    
    logger.info(
        "chat_started",
        extra={
            "session_id": session_id,
            "user": user,
            "input": request.content[:100]
        }
    )
    
    try:
        # 调用编排器
        response = await llm_orchestrator.chat(
            user_input=request.content,
            session_id=session_id,
            domain=request.domain
        )
        
        # 保存会话
        sessions[session_id] = {
            "user": user,
            "last_input": request.content,
            "last_response": response.content,
            "updated_at": time.time()
        }
        
        logger.info(
            "chat_completed",
            extra={
                "session_id": session_id,
                "latency": response.latency,
                "llm_cost": response.usage.get("cost_usd", 0)
            }
        )
        
        return ChatResponse(
            content=response.content,
            intent=response.intent,
            events_count=len(response.events),
            relations_count=len(response.relations),
            llm_usage=response.usage,
            latency=response.latency
        )
        
    except Exception as e:
        logger.error(
            "chat_failed",
            extra={
                "session_id": session_id,
                "error": str(e),
                "exc_info": True
            }
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Chat failed: {str(e)}"
        )


@app.get("/api/v1/sessions/{session_id}")
async def get_session(
    session_id: str,
    user: str = Depends(get_current_user)
):
    """获取会话信息"""
    if session_id not in sessions:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    session = sessions[session_id]
    
    # 权限检查
    if session.get("user") != user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    return {
        "session_id": session_id,
        "user": session["user"],
        "last_input": session.get("last_input"),
        "last_response": session.get("last_response"),
        "updated_at": session.get("updated_at")
    }


@app.delete("/api/v1/sessions/{session_id}")
async def delete_session(
    session_id: str,
    user: str = Depends(get_current_user)
):
    """删除会话"""
    if session_id not in sessions:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found"
        )
    
    session = sessions[session_id]
    
    # 权限检查
    if session.get("user") != user:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied"
        )
    
    # 清除编排器会话
    if llm_orchestrator:
        llm_orchestrator.clear_session(session_id)
    
    del sessions[session_id]
    
    return {"status": "deleted", "session_id": session_id}


# ============== 监控指标 ==============

@app.get("/metrics")
async def metrics():
    """Prometheus 监控指标"""
    from prometheus_client import generate_latest
    return Response(content=generate_latest(), media_type="text/plain")


# 添加 Prometheus 监控
Instrumentator().instrument(app).expose(app, endpoint="/metrics")


# ============== 错误处理 ==============

@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    """HTTP 异常处理"""
    logger.warning(
        "http_exception",
        extra={
            "path": request.url.path,
            "status": exc.status_code,
            "detail": exc.detail
        }
    )
    
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": exc.detail}
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """通用异常处理"""
    logger.error(
        "internal_error",
        extra={
            "path": request.url.path,
            "error": str(exc),
            "exc_info": True
        }
    )
    
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"error": "Internal server error"}
    )


# ============== 开发工具 ==============

if __name__ == "__main__":
    import uvicorn
    
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
