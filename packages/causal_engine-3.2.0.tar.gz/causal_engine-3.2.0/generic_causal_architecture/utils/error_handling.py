"""
统一错误处理和日志系统

生产级错误处理原则:
1. 所有错误必须有意义的日志
2. 错误应该分层 (存储层、引擎层、方法层、集成层)
3. 错误应该可追踪 (包含上下文信息)
4. 错误应该可恢复 (提供降级方案)

日志系统要求:
1. 支持多级别日志 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
2. 支持结构化日志 (JSON 格式)
3. 支持日志轮转 (避免日志文件过大)
4. 支持日志聚合 (方便问题排查)
"""

import logging
import sys
import traceback
import json
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Callable
from functools import wraps
from contextlib import contextmanager
import time


# ============================================================================
# 错误类定义 - 分层错误体系
# ============================================================================

class CausalArchitectureError(Exception):
    """基础错误类 - 所有自定义错误的基类"""
    
    def __init__(self, message: str, context: Optional[Dict[str, Any]] = None):
        self.message = message
        self.context = context or {}
        self.timestamp = datetime.now().isoformat()
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典格式，方便日志记录"""
        return {
            'error_type': self.__class__.__name__,
            'message': self.message,
            'context': self.context,
            'timestamp': self.timestamp,
            'traceback': traceback.format_exc() if traceback.format_exc() else None
        }


# 存储层错误
class StorageError(CausalArchitectureError):
    """存储层错误基类"""
    pass


class StorageConnectionError(StorageError):
    """存储连接错误"""
    pass


class StorageQueryError(StorageError):
    """存储查询错误"""
    pass


class StorageWriteError(StorageError):
    """存储写入错误"""
    pass


class StorageValidationError(StorageError):
    """存储数据验证错误"""
    pass


# 引擎层错误
class EngineError(CausalArchitectureError):
    """引擎层错误基类"""
    pass


class CausalInferenceError(EngineError):
    """因果推断错误"""
    pass


class EventNotFoundError(EngineError):
    """事件未找到错误"""
    
    def __init__(self, event_id: str, context: Optional[Dict[str, Any]] = None):
        message = f"Event not found: {event_id}"
        super().__init__(message, {'event_id': event_id, **(context or {})})


class RelationNotFoundError(EngineError):
    """关系未找到错误"""
    pass


# 方法论层错误
class MethodError(CausalArchitectureError):
    """方法论层错误基类"""
    pass


class TaskDecompositionError(MethodError):
    """任务分解错误"""
    pass


class SolutionSelectionError(MethodError):
    """方案选择错误"""
    pass


class LayerExecutionError(MethodError):
    """层执行错误"""
    pass


class IterationError(MethodError):
    """迭代错误"""
    pass


# 集成层错误
class IntegrationError(CausalArchitectureError):
    """集成层错误基类"""
    pass


class LangExtractIntegrationError(IntegrationError):
    """LangExtract 集成错误"""
    pass


class MirofishIntegrationError(IntegrationError):
    """Mirofish 集成错误"""
    pass


class KnowledgeGraphIntegrationError(IntegrationError):
    """知识图谱集成错误"""
    pass


# 配置错误
class ConfigError(CausalArchitectureError):
    """配置错误"""
    pass


class ConfigNotFoundError(ConfigError):
    """配置文件未找到"""
    
    def __init__(self, config_path: str):
        message = f"Configuration file not found: {config_path}"
        super().__init__(message, {'config_path': config_path})


class ConfigValidationError(ConfigError):
    """配置验证错误"""
    pass


# ============================================================================
# 日志系统 - 生产级日志配置
# ============================================================================

class StructuredFormatter(logging.Formatter):
    """结构化日志格式化器 (JSON 格式)"""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
        }
        
        # 添加额外字段
        if hasattr(record, 'context'):
            log_data['context'] = record.context
        
        # 添加异常信息
        if record.exc_info:
            log_data['exception'] = {
                'type': record.exc_info[0].__name__ if record.exc_info[0] else None,
                'message': str(record.exc_info[1]) if record.exc_info[1] else None,
                'traceback': self.formatException(record.exc_info)
            }
        
        return json.dumps(log_data, ensure_ascii=False, default=str)


class ColoredFormatter(logging.Formatter):
    """彩色控制台格式化器"""
    
    # ANSI 颜色代码
    COLORS = {
        'DEBUG': '\033[36m',     # 青色
        'INFO': '\033[32m',      # 绿色
        'WARNING': '\033[33m',   # 黄色
        'ERROR': '\033[31m',     # 红色
        'CRITICAL': '\033[35m',  # 紫色
        'RESET': '\033[0m'       # 重置
    }
    
    def format(self, record: logging.LogRecord) -> str:
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']
        
        log_format = (
            f"{color}[%(asctime)s] [%(levelname)s] [%(name)s]{reset} "
            f"%(message)s"
        )
        
        formatter = logging.Formatter(log_format)
        return formatter.format(record)


def setup_logging(
    log_level: str = 'INFO',
    log_dir: Optional[str] = None,
    enable_file_logging: bool = True,
    enable_json_format: bool = False,
    max_bytes: int = 10 * 1024 * 1024,  # 10MB
    backup_count: int = 5
) -> logging.Logger:
    """
    设置日志系统
    
    Args:
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_dir: 日志文件目录 (默认: ./logs)
        enable_file_logging: 是否启用文件日志
        enable_json_format: 是否启用 JSON 格式 (默认 False，使用人类可读格式)
        max_bytes: 单个日志文件最大大小 (字节)
        backup_count: 保留的日志文件数量
    
    Returns:
        根 logger
    """
    # 创建根 logger
    root_logger = logging.getLogger('generic_causal_architecture')
    root_logger.setLevel(getattr(logging, log_level.upper()))
    
    # 清除现有 handler
    if root_logger.handlers:
        root_logger.handlers.clear()
    
    # 创建控制台 handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    
    # 设置控制台格式化器 (彩色)
    console_formatter = ColoredFormatter(
        '[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)
    
    # 创建文件 handler (如果启用)
    if enable_file_logging:
        if log_dir is None:
            log_dir = Path(__file__).parent.parent / 'logs'
        
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        
        # 日志文件名 (带日期)
        log_file = log_path / f"gca_{datetime.now().strftime('%Y%m%d')}.log"
        
        # 文件 handler (带轮转)
        from logging.handlers import RotatingFileHandler
        file_handler = RotatingFileHandler(
            log_file,
            maxBytes=max_bytes,
            backupCount=backup_count,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        
        # 设置文件格式化器
        if enable_json_format:
            file_formatter = StructuredFormatter()
        else:
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - '
                '%(module)s:%(lineno)d - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
        
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)
    
    return root_logger


# ============================================================================
# 错误处理装饰器和上下文管理器
# ============================================================================

def log_errors(logger: Optional[logging.Logger] = None):
    """
    错误处理装饰器 - 自动记录错误日志
    
    使用方式:
        @log_errors()
        def my_function():
            ...
    
        @log_errors(logger=my_logger)
        def my_function():
            ...
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = logging.getLogger(f'generic_causal_architecture.{func.__module__}')
            
            try:
                logger.debug(f"Calling {func.__name__} with args={args}, kwargs={kwargs}")
                result = func(*args, **kwargs)
                logger.debug(f"{func.__name__} returned successfully")
                return result
            except CausalArchitectureError as e:
                logger.error(
                    f"{func.__name__} raised {e.__class__.__name__}: {e.message}",
                    extra={'context': e.context},
                    exc_info=True
                )
                raise
            except Exception as e:
                logger.error(
                    f"{func.__name__} raised unexpected exception: {type(e).__name__}: {str(e)}",
                    exc_info=True
                )
                # 包装为通用错误
                raise CausalArchitectureError(
                    f"Unexpected error in {func.__name__}: {str(e)}",
                    context={'original_exception': str(e)}
                )
        
        return wrapper
    return decorator


@contextmanager
def error_context(
    context_name: str,
    logger: Optional[logging.Logger] = None,
    raise_on_error: bool = True
):
    """
    错误处理上下文管理器
    
    使用方式:
        with error_context("Loading data", logger=my_logger):
            # 可能出错的代码
            load_data()
    
    Args:
        context_name: 上下文名称 (用于日志)
        logger: logger 实例
        raise_on_error: 是否抛出错误 (默认 True)
    """
    if logger is None:
        logger = logging.getLogger('generic_causal_architecture')
    
    try:
        logger.debug(f"Entering context: {context_name}")
        yield
        logger.debug(f"Exited context successfully: {context_name}")
    except CausalArchitectureError as e:
        logger.error(
            f"Error in {context_name}: {e.__class__.__name__}: {e.message}",
            extra={'context': e.context},
            exc_info=True
        )
        if raise_on_error:
            raise
    except Exception as e:
        logger.error(
            f"Unexpected error in {context_name}: {type(e).__name__}: {str(e)}",
            exc_info=True
        )
        if raise_on_error:
            raise CausalArchitectureError(
                f"Error in {context_name}: {str(e)}",
                context={'original_exception': str(e)}
            )


# ============================================================================
# 性能监控和日志
# ============================================================================

def timed_operation(logger: Optional[logging.Logger] = None, log_level: str = 'INFO'):
    """
    性能监控装饰器 - 记录函数执行时间
    
    使用方式:
        @timed_operation()
        def slow_function():
            ...
    
        @timed_operation(logger=my_logger, log_level='DEBUG')
        def another_function():
            ...
    """
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal logger
            if logger is None:
                logger = logging.getLogger(f'generic_causal_architecture.{func.__module__}')
            
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                elapsed_time = time.time() - start_time
                log_method = getattr(logger, log_level.lower())
                log_method(f"{func.__name__} completed in {elapsed_time:.3f}s")
                return result
            except Exception as e:
                elapsed_time = time.time() - start_time
                logger.error(f"{func.__name__} failed after {elapsed_time:.3f}s: {str(e)}", exc_info=True)
                raise
        
        return wrapper
    return decorator


# ============================================================================
# 全局配置
# ============================================================================

# 自动设置日志 (模块导入时)
try:
    setup_logging()
except Exception as e:
    # 如果日志设置失败，使用基本配置
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

logger = logging.getLogger(__name__)
