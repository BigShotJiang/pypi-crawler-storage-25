"""
日志系统 - 生产级日志管理

重要说明：
1. 使用 Python 标准 logging 模块
2. 支持多输出（控制台 + 文件）
3. 支持日志轮转（RotatingFileHandler）
4. 支持不同级别日志输出到不同文件

使用示例：
    from generic_causal_architecture.utils.logging_setup import setup_logging
    from generic_causal_architecture.config import Config
    
    config = Config.from_yaml("config/production.yaml")
    setup_logging(config.logging)
    
    logger = logging.getLogger(__name__)
    logger.info("Application started")
"""

import logging
import os
import sys
from logging.handlers import RotatingFileHandler
from typing import Optional


def setup_logging(logging_config, app_name: str = "causal-architecture"):
    """
    设置日志系统
    
    参数:
        logging_config: LoggingConfig 对象
        app_name: 应用名称（用于日志标识）
    
    返回:
        根 logger 实例
    """
    # 获取日志级别
    level = getattr(logging, logging_config.level.upper(), logging.INFO)
    
    # 创建根 logger
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    # 清除已有的 handler（避免重复）
    root_logger.handlers.clear()
    
    # 创建 formatter
    formatter = logging.Formatter(logging_config.format)
    
    # 1. 控制台 Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # 2. 文件 Handler（如果配置了文件路径）
    if logging_config.file:
        # 确保目录存在
        log_dir = os.path.dirname(logging_config.file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        
        # 使用轮转文件 Handler
        file_handler = RotatingFileHandler(
            logging_config.file,
            maxBytes=logging_config.max_bytes,
            backupCount=logging_config.backup_count,
            encoding='utf-8'
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)
    
    # 记录启动日志
    logging.info(f"{app_name} logging initialized - Level: {logging_config.level}")
    
    return root_logger


def get_logger(name: str) -> logging.Logger:
    """
    获取 logger 实例
    
    参数:
        name: logger 名称（通常是 __name__）
    
    返回:
        logger 实例
    
    使用示例:
        logger = get_logger(__name__)
    """
    return logging.getLogger(name)
