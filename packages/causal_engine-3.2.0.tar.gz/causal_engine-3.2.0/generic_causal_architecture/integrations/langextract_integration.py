"""
LangExtract 深度集成 - 结构化信息提取能力

LangExtract 核心原理:
1. 结构化信息提取 (从非结构化文本中提取结构化数据)
2. 精确源定位 (提取结果包含精确的文本位置)
3. 结构化输出 (JSON 格式，易于处理)
4. 长文档优化 (分块处理，保持上下文)

本模块集成 LangExtract 能力:
1. 历史事件提取 (从史料中提取事件)
2. 实体识别 (人名、地名、机构名等)
3. 关系提取 (因果关系、时序关系等)
4. 时间表达式识别 (年号、朝代、日期等)

集成策略:
- 直接调用 langextract 的 extract() 函数
- 将提取结果转换为架构内部的数据结构
- 支持批量处理和流式处理
"""

import logging
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json

from ..storage.storage_interface import EventData, CausalRelation
from ..adapters.history_adapter import EventType, HistoricalPeriod

logger = logging.getLogger(__name__)


class ExtractionType(Enum):
    """提取类型"""
    EVENT = "event"  # 事件提取
    ENTITY = "entity"  # 实体提取
    RELATION = "relation"  # 关系提取
    TEMPORAL = "temporal"  # 时间表达式
    CAUSAL = "causal"  # 因果关系


@dataclass
class ExtractionResult:
    """提取结果"""
    extraction_type: ExtractionType
    data: Any
    source_text: str
    source_location: Optional[Dict[str, int]] = None  # {start, end}
    confidence: float = 1.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'type': self.extraction_type.value,
            'data': self.data,
            'source_text': self.source_text,
            'source_location': self.source_location,
            'confidence': self.confidence,
            'metadata': self.metadata
        }


class LangExtractIntegration:
    """
    LangExtract 深度集成
    
    提供结构化信息提取能力:
    1. 事件提取：从文本中提取历史事件
    2. 实体识别：识别人名、地名、机构名等
    3. 关系提取：发现因果关系、时序关系等
    4. 时间识别：识别年号、朝代、日期等
    
    使用方式:
        integration = LangExtractIntegration()
        
        # 提取事件
        events = integration.extract_events("武昌起义爆发于 1911 年 10 月 10 日")
        
        # 提取实体
        entities = integration.extract_entities("孙中山领导了辛亥革命")
        
        # 提取关系
        relations = integration.extract_relations(text)
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化 LangExtract 集成
        
        Args:
            config: 配置字典 (可选)
        """
        self.config = config or {}
        self._langextract_available = False
        
        # 尝试导入 langextract
        try:
            import langextract
            self._langextract = langextract
            self._langextract_available = True
            logger.info("LangExtract library imported successfully")
        except ImportError:
            logger.warning("LangExtract not installed, using mock mode")
            self._langextract = None
    
    def extract_events(self, text: str, source: Optional[str] = None) -> List[EventData]:
        """
        从文本中提取历史事件
        
        Args:
            text: 输入文本
            source: 来源标注 (可选)
        
        Returns:
            EventData 列表
        """
        logger.info(f"Extracting events from text ({len(text)} chars)")
        
        if self._langextract_available:
            return self._extract_events_langextract(text, source)
        else:
            return self._extract_events_mock(text, source)
    
    def _extract_events_langextract(self, text: str, source: Optional[str] = None) -> List[EventData]:
        """使用 LangExtract 提取事件"""
        try:
            # 定义提取 schema
            event_schema = {
                'type': 'object',
                'properties': {
                    'events': {
                        'type': 'array',
                        'items': {
                            'type': 'object',
                            'properties': {
                                'name': {'type': 'string'},
                                'time': {'type': 'string'},
                                'location': {'type': 'string'},
                                'participants': {'type': 'array', 'items': {'type': 'string'}},
                                'description': {'type': 'string'},
                                'type': {'type': 'string'}
                            },
                            'required': ['name', 'time']
                        }
                    }
                }
            }
            
            # 调用 LangExtract extract() 函数
            # 注意：LangExtract 是 Google 开发的 Python 库
            # 实际 API 可能需要根据版本调整
            result = None
            
            # 尝试不同的 API 调用方式
            try:
                # 方式 1: 直接调用 extract() 函数
                if hasattr(self._langextract, 'extract'):
                    result = self._langextract.extract(
                        text=text,
                        schema=event_schema
                    )
                # 方式 2: 使用 LLM 驱动提取
                elif hasattr(self._langextract, 'LLMContext'):
                    context = self._langextract.LLMContext()
                    result = context.extract(
                        text=text,
                        schema=event_schema,
                        prompt="从文本中提取历史事件，包含事件名称、时间、地点、参与者、描述和类型"
                    )
            except Exception as api_error:
                logger.warning(f"LangExtract API 调用失败：{api_error}, 回退到 mock 模式")
                return self._extract_events_mock(text, source)
            
            # 转换为 EventData
            events = []
            if result and 'events' in result:
                for i, event_data in enumerate(result['events']):
                    event = EventData(
                        id=f"extracted_event_{i}",
                        name=event_data.get('name', ''),
                        timestamp=self._parse_time(event_data.get('time', '')),
                        location=event_data.get('location'),
                        participants=event_data.get('participants'),
                        description=event_data.get('description'),
                        event_type=event_data.get('type'),
                        evidence_sources=[source] if source else []
                    )
                    events.append(event)
            
            logger.info(f"Extracted {len(events)} events using LangExtract")
            return events
            
        except Exception as e:
            logger.error(f"LangExtract event extraction failed: {e}")
            # 失败时回退到 mock 模式
            return self._extract_events_mock(text, source)
    
    def _extract_events_mock(self, text: str, source: Optional[str] = None) -> List[EventData]:
        """模拟事件提取 (基于规则)"""
        logger.warning("Using mock event extraction (rule-based)")
        
        # 简化的基于规则的提取
        events = []
        
        # 查找包含时间的句子
        import re
        time_pattern = r'(\d{4} 年|\d{3,4} 年|\d+世纪)'
        matches = re.finditer(time_pattern, text)
        
        for match in matches:
            time_str = match.group(1)
            # 提取前后文作为事件描述
            start = max(0, match.start() - 50)
            end = min(len(text), match.end() + 50)
            context = text[start:end].strip()
            
            event = EventData(
                id=f"mock_event_{len(events)}",
                name=f"事件_{len(events)}",
                timestamp={'year': self._extract_year(time_str)},
                description=context,
                evidence_sources=[source] if source else []
            )
            events.append(event)
        
        logger.info(f"Mock extracted {len(events)} events")
        return events
    
    def _parse_time(self, time_str: str) -> Dict[str, Any]:
        """解析时间字符串"""
        import re
        
        # 尝试提取年份
        year_match = re.search(r'(\d{4}) 年', time_str)
        if year_match:
            return {'year': int(year_match.group(1))}
        
        # 尝试提取世纪
        century_match = re.search(r'(\d+) 世纪', time_str)
        if century_match:
            century = int(century_match.group(1))
            return {'century': century, 'approximate': True}
        
        # 返回原始字符串
        return {'raw': time_str}
    
    def _extract_year(self, time_str: str) -> Optional[int]:
        """从时间字符串提取年份"""
        import re
        match = re.search(r'(\d{4})', time_str)
        if match:
            return int(match.group(1))
        return None
    
    def extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """
        从文本中提取实体
        
        Args:
            text: 输入文本
        
        Returns:
            实体列表，每个实体包含：
            - text: 实体文本
            - type: 实体类型 (PERSON, LOCATION, ORGANIZATION 等)
            - start: 起始位置
            - end: 结束位置
        """
        logger.info(f"Extracting entities from text ({len(text)} chars)")
        
        if self._langextract_available:
            return self._extract_entities_langextract(text)
        else:
            return self._extract_entities_mock(text)
    
    def _extract_entities_langextract(self, text: str) -> List[Dict[str, Any]]:
        """使用 LangExtract 提取实体"""
        try:
            entity_schema = {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'properties': {
                        'text': {'type': 'string'},
                        'type': {'type': 'string'},
                        'start': {'type': 'integer'},
                        'end': {'type': 'integer'}
                    },
                    'required': ['text', 'type']
                }
            }
            
            result = self._langextract.extract(
                text=text,
                schema=entity_schema,
                prompt="从文本中提取实体，包括人名、地名、机构名、时间表达式等"
            )
            
            logger.info(f"Extracted {len(result) if result else 0} entities using LangExtract")
            return result or []
            
        except Exception as e:
            logger.error(f"LangExtract entity extraction failed: {e}")
            return []
    
    def _extract_entities_mock(self, text: str) -> List[Dict[str, Any]]:
        """模拟实体提取"""
        logger.warning("Using mock entity extraction")
        
        # 简化的规则提取
        entities = []
        
        # 查找人名 (简化的中文人名模式)
        import re
        person_pattern = r'[张王李赵刘陈杨黄吴周徐孙朱马胡郭何高罗郑谢萧唐冯韩曹彭曾潘袁于董袁邓许傅钟汪姜范韦方廖石熊金邱夏侯聂章汪毛邱白崔康顾万武乔赖殷阎段邵谭熊阎汪]'
        # 这里只是示例，实际应该使用 NER 模型
        
        return entities
    
    def extract_relations(self, text: str, relation_type: str = 'causal') -> List[Dict[str, Any]]:
        """
        从文本中提取关系
        
        Args:
            text: 输入文本
            relation_type: 关系类型 ('causal', 'temporal', 'correlational')
        
        Returns:
            关系列表，每个关系包含:
            - source: 源实体
            - target: 目标实体
            - type: 关系类型
            - evidence: 证据文本
        """
        logger.info(f"Extracting {relation_type} relations from text ({len(text)} chars)")
        
        if self._langextract_available:
            return self._extract_relations_langextract(text, relation_type)
        else:
            return self._extract_relations_mock(text, relation_type)
    
    def _extract_relations_langextract(self, text: str, relation_type: str) -> List[Dict[str, Any]]:
        """使用 LangExtract 提取关系"""
        try:
            relation_schema = {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'properties': {
                        'source': {'type': 'string'},
                        'target': {'type': 'string'},
                        'type': {'type': 'string'},
                        'evidence': {'type': 'string'}
                    },
                    'required': ['source', 'target', 'type']
                }
            }
            
            prompt_map = {
                'causal': '从文本中提取因果关系，包括原因事件、结果事件和证据',
                'temporal': '从文本中提取时序关系，包括先后顺序',
                'correlational': '从文本中提取相关关系'
            }
            
            result = self._langextract.extract(
                text=text,
                schema=relation_schema,
                prompt=prompt_map.get(relation_type, '从文本中提取关系')
            )
            
            logger.info(f"Extracted {len(result) if result else 0} {relation_type} relations")
            return result or []
            
        except Exception as e:
            logger.error(f"LangExtract relation extraction failed: {e}")
            return []
    
    def _extract_relations_mock(self, text: str, relation_type: str) -> List[Dict[str, Any]]:
        """模拟关系提取"""
        logger.warning("Using mock relation extraction")
        return []
    
    def extract_temporal_expressions(self, text: str) -> List[Dict[str, Any]]:
        """
        从文本中提取时间表达式
        
        Args:
            text: 输入文本
        
        Returns:
            时间表达式列表，每个包含:
            - text: 原始文本
            - type: 类型 (date, time, duration, set)
            - value: 标准化值
            - start: 起始位置
            - end: 结束位置
        """
        logger.info(f"Extracting temporal expressions from text ({len(text)} chars)")
        
        if self._langextract_available:
            return self._extract_temporal_langextract(text)
        else:
            return self._extract_temporal_mock(text)
    
    def _extract_temporal_langextract(self, text: str) -> List[Dict[str, Any]]:
        """使用 LangExtract 提取时间表达式"""
        try:
            temporal_schema = {
                'type': 'array',
                'items': {
                    'type': 'object',
                    'properties': {
                        'text': {'type': 'string'},
                        'type': {'type': 'string'},
                        'value': {'type': 'string'},
                        'start': {'type': 'integer'},
                        'end': {'type': 'integer'}
                    },
                    'required': ['text', 'type']
                }
            }
            
            result = self._langextract.extract(
                text=text,
                schema=temporal_schema,
                prompt="从文本中提取所有时间表达式，包括日期、时间、持续时间、频率等"
            )
            
            logger.info(f"Extracted {len(result) if result else 0} temporal expressions")
            return result or []
            
        except Exception as e:
            logger.error(f"LangExtract temporal extraction failed: {e}")
            return []
    
    def _extract_temporal_mock(self, text: str) -> List[Dict[str, Any]]:
        """模拟时间表达式提取"""
        import re
        
        temporal_expressions = []
        
        # 查找年份
        year_pattern = r'(\d{4}) 年'
        for match in re.finditer(year_pattern, text):
            temporal_expressions.append({
                'text': match.group(0),
                'type': 'date',
                'value': match.group(1),
                'start': match.start(),
                'end': match.end()
            })
        
        # 查找朝代
        dynasty_pattern = r'(唐朝 | 宋朝 | 元朝 | 明朝 | 清朝 | 民国)'
        for match in re.finditer(dynasty_pattern, text):
            temporal_expressions.append({
                'text': match.group(0),
                'type': 'set',
                'value': match.group(1),
                'start': match.start(),
                'end': match.end()
            })
        
        return temporal_expressions
    
    def batch_extract(self, texts: List[str], extraction_types: List[ExtractionType]) -> List[List[ExtractionResult]]:
        """
        批量提取
        
        Args:
            texts: 文本列表
            extraction_types: 要提取的类型列表
        
        Returns:
            提取结果列表的列表
        """
        logger.info(f"Batch extracting {extraction_types} from {len(texts)} texts")
        
        all_results = []
        
        for i, text in enumerate(texts):
            text_results = []
            
            for ext_type in extraction_types:
                if ext_type == ExtractionType.EVENT:
                    events = self.extract_events(text)
                    for event in events:
                        text_results.append(ExtractionResult(
                            extraction_type=ext_type,
                            data=event,
                            source_text=text,
                            confidence=0.8
                        ))
                elif ext_type == ExtractionType.ENTITY:
                    entities = self.extract_entities(text)
                    for entity in entities:
                        text_results.append(ExtractionResult(
                            extraction_type=ext_type,
                            data=entity,
                            source_text=text,
                            confidence=0.9
                        ))
                elif ext_type == ExtractionType.RELATION:
                    relations = self.extract_relations(text)
                    for relation in relations:
                        text_results.append(ExtractionResult(
                            extraction_type=ext_type,
                            data=relation,
                            source_text=text,
                            confidence=0.85
                        ))
                elif ext_type == ExtractionType.TEMPORAL:
                    temporals = self.extract_temporal_expressions(text)
                    for temporal in temporals:
                        text_results.append(ExtractionResult(
                            extraction_type=ext_type,
                            data=temporal,
                            source_text=text,
                            confidence=0.95
                        ))
            
            all_results.append(text_results)
            logger.debug(f"Processed text {i+1}/{len(texts)}: {len(text_results)} results")
        
        logger.info(f"Batch extraction completed: {sum(len(r) for r in all_results)} total results")
        return all_results
