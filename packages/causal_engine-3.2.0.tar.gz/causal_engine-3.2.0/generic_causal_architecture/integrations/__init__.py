"""
整合模块 - 统一管理所有外部项目整合

包含的整合：
1. LangExtract: 文本信息提取
2. KnowledgeGraph: 知识图谱（借鉴 GitNexus）
3. Mirofish: 预测能力
"""

from .langextract_integration import LangExtractIntegration
from .knowledge_graph_integration import KnowledgeGraphIntegration
from .mirofish_integration import MirofishIntegration
from .integration_manager import IntegrationManager, UnifiedWorkflow

__all__ = [
    'LangExtractIntegration',
    'KnowledgeGraphIntegration',
    'MirofishIntegration',
    'IntegrationManager',
    'UnifiedWorkflow'
]
