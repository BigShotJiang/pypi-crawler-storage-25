"""
Mirofish 整合适配器 - 预测和图谱构建能力整合

Mirofish 的核心能力：
1. 从文档生成本体定义
2. 构建知识图谱
3. 基于图谱进行预测和推理

真实 API（Flask HTTP）：
    POST /ontology/generate  - 上传文件生成本体
    POST /build             - 构建图谱
    GET  /task/<task_id>    - 查询任务状态
    GET  /data/<graph_id>   - 获取图谱数据

我们的整合策略：
1. 通过 HTTP 请求调用 Mirofish API
2. 将图谱数据用于因果分析
3. 结合预测能力进行趋势分析
"""

from typing import Any, Dict, List, Optional
import json
from ..interfaces.integration_interface import IIntegration


class MirofishIntegration(IIntegration):
    """Mirofish 整合适配器（HTTP API）"""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        初始化 Mirofish 整合
        
        Args:
            config: 配置字典
                - base_url: Mirofish 服务地址
                - api_key: API 密钥（如果需要）
        """
        self.config = config or {}
        self._connected = False
        self._requests_available = False
        
        self.api_config = {
            'base_url': self.config.get('base_url', 'http://localhost:5000'),
            'api_key': self.config.get('api_key', None),
            'timeout': self.config.get('timeout', 30),
        }
        
        self._session = None
        self._current_project_id = None
        self._current_graph_id = None
    
    @property
    def integration_name(self) -> str:
        return 'mirofish'
    
    @property
    def external_project_path(self) -> Optional[str]:
        return None
    
    def connect(self, **kwargs) -> bool:
        """
        连接到 Mirofish 服务
        
        Args:
            **kwargs: 连接参数
                - base_url: 服务地址
                - api_key: API 密钥
                - force_mock: 强制使用模拟模式
                
        Returns:
            bool: 连接成功返回 True
        """
        force_mock = kwargs.get('force_mock', False)
        
        if force_mock:
            self._requests_available = False
            self._connected = True
            return True
        
        try:
            import requests
            self._requests_available = True
            self._session = requests.Session()
            
            if 'base_url' in kwargs:
                self.api_config['base_url'] = kwargs['base_url']
            if 'api_key' in kwargs:
                self.api_config['api_key'] = kwargs['api_key']
            
            if self.api_config['api_key']:
                self._session.headers.update({
                    'Authorization': f"Bearer {self.api_config['api_key']}"
                })
            
            try:
                response = self._session.get(
                    f"{self.api_config['base_url']}/api/graph/project/list",
                    timeout=2
                )
                self._connected = True
                return True
            except:
                print("警告：无法连接到 Mirofish 服务，使用模拟模式")
                self._requests_available = False
                self._connected = True
                return True
            
        except ImportError:
            print("警告：未安装 requests 库，使用模拟模式")
            self._requests_available = False
            self._connected = True
            return True
    
    def disconnect(self) -> None:
        """断开连接"""
        if self._session:
            self._session.close()
            self._session = None
        self._connected = False
    
    def integrate(self, external_data: Any, **kwargs) -> Dict[str, Any]:
        """
        整合 Mirofish 的数据
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        return {
            'data': external_data,
            'source': 'mirofish',
            'metadata': kwargs.get('metadata', {})
        }
    
    def generate_ontology(self, 
                         simulation_requirement: str,
                         files: Optional[List[str]] = None,
                         texts: Optional[List[str]] = None,
                         project_name: str = "Causal Analysis Project",
                         **kwargs) -> Dict[str, Any]:
        """
        生成本体定义
        
        Args:
            simulation_requirement: 模拟需求描述
            files: 文件路径列表（可选）
            texts: 文本内容列表（可选）
            project_name: 项目名称
            
        Returns:
            Dict[str, Any]: 本体定义结果
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        if self._requests_available:
            url = f"{self.api_config['base_url']}/api/graph/ontology/generate"
            
            data = {
                'simulation_requirement': simulation_requirement,
                'project_name': project_name,
            }
            
            if texts:
                data['additional_context'] = '\n\n'.join(texts)
            
            files_data = None
            if files:
                files_data = [('files', (f, open(f, 'rb'))) for f in files]
            
            try:
                if files_data:
                    response = self._session.post(url, data=data, files=files_data, 
                                                  timeout=self.api_config['timeout'])
                else:
                    response = self._session.post(url, data=data,
                                                  timeout=self.api_config['timeout'])
                
                result = response.json()
                
                if result.get('success'):
                    self._current_project_id = result['data']['project_id']
                    return result['data']
                else:
                    raise RuntimeError(f"生成本体失败: {result.get('error')}")
                    
            finally:
                if files_data:
                    for _, (_, f) in files_data:
                        f.close()
        else:
            return self._mock_generate_ontology(simulation_requirement)
    
    def build_graph(self, 
                   project_id: Optional[str] = None,
                   graph_name: Optional[str] = None,
                   **kwargs) -> Dict[str, Any]:
        """
        构建知识图谱
        
        Args:
            project_id: 项目 ID（如果不提供，使用最近创建的）
            graph_name: 图谱名称
            
        Returns:
            Dict[str, Any]: 构建结果
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        project_id = project_id or self._current_project_id
        if not project_id:
            raise ValueError("需要提供 project_id")
        
        if self._requests_available:
            url = f"{self.api_config['base_url']}/api/graph/build"
            
            data = {
                'project_id': project_id,
                'graph_name': graph_name or 'Causal Graph'
            }
            
            response = self._session.post(url, json=data, timeout=self.api_config['timeout'])
            result = response.json()
            
            if result.get('success'):
                return {
                    'task_id': result['data']['task_id'],
                    'project_id': project_id,
                    'message': result['data']['message']
                }
            else:
                raise RuntimeError(f"构建图谱失败: {result.get('error')}")
        else:
            return self._mock_build_graph(project_id)
    
    def get_task_status(self, task_id: str) -> Dict[str, Any]:
        """
        查询任务状态
        
        Args:
            task_id: 任务 ID
            
        Returns:
            Dict[str, Any]: 任务状态
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        if self._requests_available:
            url = f"{self.api_config['base_url']}/api/graph/task/{task_id}"
            
            response = self._session.get(url, timeout=self.api_config['timeout'])
            result = response.json()
            
            if result.get('success'):
                return result['data']
            else:
                raise RuntimeError(f"查询任务失败: {result.get('error')}")
        else:
            return self._mock_get_task_status(task_id)
    
    def get_graph_data(self, graph_id: str) -> Dict[str, Any]:
        """
        获取图谱数据
        
        Args:
            graph_id: 图谱 ID
            
        Returns:
            Dict[str, Any]: 图谱数据
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        if self._requests_available:
            url = f"{self.api_config['base_url']}/api/graph/data/{graph_id}"
            
            response = self._session.get(url, timeout=self.api_config['timeout'])
            result = response.json()
            
            if result.get('success'):
                self._current_graph_id = graph_id
                return result['data']
            else:
                raise RuntimeError(f"获取图谱失败: {result.get('error')}")
        else:
            return self._mock_get_graph_data(graph_id)
    
    def predict_future_trend(self, 
                            historical_data: List[Dict[str, Any]], 
                            target: str,
                            horizon: int = 10,
                            **kwargs) -> Dict[str, Any]:
        """
        预测未来趋势（基于图谱分析）
        
        Args:
            historical_data: 历史数据
            target: 预测目标
            horizon: 预测范围
            
        Returns:
            Dict[str, Any]: 预测结果
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        if self._requests_available and self._current_graph_id:
            graph_data = self.get_graph_data(self._current_graph_id)
            
            return self._analyze_trend_from_graph(graph_data, target, horizon)
        else:
            return self._mock_predict(target, horizon)
    
    def simulate_scenario(self, 
                         initial_conditions: Dict[str, Any],
                         interventions: Optional[List[Dict[str, Any]]] = None,
                         **kwargs) -> Dict[str, Any]:
        """
        模拟场景（基于图谱推理）
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        if self._requests_available and self._current_graph_id:
            graph_data = self.get_graph_data(self._current_graph_id)
            
            return self._simulate_from_graph(graph_data, initial_conditions, interventions)
        else:
            return self._mock_simulate(initial_conditions)
    
    def counterfactual_reasoning(self, 
                                factual_world: Dict[str, Any],
                                counterfactual_condition: Dict[str, Any],
                                **kwargs) -> Dict[str, Any]:
        """
        反事实推理
        """
        if not self._connected:
            raise RuntimeError("未连接到 Mirofish 服务")
        
        factual_result = self.simulate_scenario(factual_world)
        
        counterfactual_world = {**factual_world}
        if 'intervention' in counterfactual_condition:
            intervention = counterfactual_condition['intervention']
            counterfactual_world[intervention.get('key')] = intervention.get('new_value')
        
        counterfactual_result = self.simulate_scenario(
            counterfactual_world,
            interventions=[counterfactual_condition]
        )
        
        comparison = self._compare_results(factual_result, counterfactual_result)
        
        return {
            'factual': factual_result,
            'counterfactual': counterfactual_result,
            'difference': comparison,
            'causal_effect': self._compute_causal_effect(factual_result, counterfactual_result)
        }
    
    def transform_to_internal_format(self, external_data: Any) -> Dict[str, Any]:
        """
        将 Mirofish 的输出转换为内部格式
        """
        if isinstance(external_data, dict):
            return {
                'data': external_data,
                'source': 'mirofish',
                'metadata': {
                    'graph_id': self._current_graph_id,
                    'project_id': self._current_project_id
                }
            }
        return {'data': external_data, 'source': 'mirofish'}
    
    def extract_knowledge(self, **kwargs) -> Dict[str, Any]:
        """
        提取知识（构建图谱并返回数据）
        """
        simulation_requirement = kwargs.get('simulation_requirement', '分析因果关系')
        texts = kwargs.get('texts', [])
        
        ontology = self.generate_ontology(simulation_requirement, texts=texts)
        
        if self._current_project_id:
            build_result = self.build_graph(self._current_project_id)
            
            if 'task_id' in build_result:
                import time
                for _ in range(10):
                    status = self.get_task_status(build_result['task_id'])
                    if status.get('status') == 'completed':
                        if 'result' in status and 'graph_id' in status['result']:
                            return self.get_graph_data(status['result']['graph_id'])
                        break
                    time.sleep(1)
        
        return {'ontology': ontology, 'graph': None}
    
    def get_capabilities(self) -> Dict[str, Any]:
        return {
            'ontology_generation': True,
            'graph_building': True,
            'trend_prediction': True,
            'scenario_simulation': True,
            'counterfactual_reasoning': True,
            'task_management': True,
            'api_type': 'HTTP',
            'base_url': self.api_config['base_url']
        }
    
    def _analyze_trend_from_graph(self, graph_data: Dict, target: str, horizon: int) -> Dict[str, Any]:
        """从图谱数据中分析趋势"""
        nodes = graph_data.get('nodes', [])
        edges = graph_data.get('edges', [])
        
        related_nodes = [n for n in nodes if target.lower() in str(n).lower()]
        
        return {
            'prediction': f"基于图谱分析 {target} 的趋势",
            'confidence': 0.75,
            'horizon': horizon,
            'related_entities': len(related_nodes),
            'graph_size': {'nodes': len(nodes), 'edges': len(edges)}
        }
    
    def _simulate_from_graph(self, graph_data: Dict, initial: Dict, interventions: List) -> Dict[str, Any]:
        """基于图谱进行模拟"""
        return {
            'outcome': '模拟结果',
            'confidence': 0.7,
            'initial_conditions': initial,
            'interventions': interventions or []
        }
    
    def _compare_results(self, factual: Dict, counterfactual: Dict) -> Dict[str, Any]:
        """比较两个结果"""
        return {
            'factual_outcome': factual.get('outcome'),
            'counterfactual_outcome': counterfactual.get('outcome'),
            'difference': '存在差异'
        }
    
    def _compute_causal_effect(self, factual: Dict, counterfactual: Dict) -> Dict[str, Any]:
        """计算因果效应"""
        return {
            'effect': '因果效应估计',
            'confidence': 0.6
        }
    
    def _mock_generate_ontology(self, requirement: str) -> Dict[str, Any]:
        """模拟生成本体"""
        import uuid
        self._current_project_id = f"proj_{uuid.uuid4().hex[:8]}"
        return {
            'project_id': self._current_project_id,
            'ontology': {
                'entity_types': ['Event', 'Person', 'Location'],
                'edge_types': ['causes', 'precedes', 'influences']
            },
            'analysis_summary': f"分析需求: {requirement[:100]}"
        }
    
    def _mock_build_graph(self, project_id: str) -> Dict[str, Any]:
        """模拟构建图谱"""
        import uuid
        return {
            'task_id': f"task_{uuid.uuid4().hex[:8]}",
            'project_id': project_id,
            'message': '图谱构建任务已启动'
        }
    
    def _mock_get_task_status(self, task_id: str) -> Dict[str, Any]:
        """模拟获取任务状态"""
        import uuid
        self._current_graph_id = f"graph_{uuid.uuid4().hex[:8]}"
        return {
            'task_id': task_id,
            'status': 'completed',
            'progress': 100,
            'result': {
                'graph_id': self._current_graph_id,
                'node_count': 50,
                'edge_count': 120
            }
        }
    
    def _mock_get_graph_data(self, graph_id: str) -> Dict[str, Any]:
        """模拟获取图谱数据"""
        return {
            'graph_id': graph_id,
            'nodes': [
                {'id': 'n1', 'name': '事件A', 'type': 'Event'},
                {'id': 'n2', 'name': '事件B', 'type': 'Event'},
            ],
            'edges': [
                {'source': 'n1', 'target': 'n2', 'type': 'causes'}
            ],
            'node_count': 2,
            'edge_count': 1
        }
    
    def _mock_predict(self, target: str, horizon: int) -> Dict[str, Any]:
        """模拟预测"""
        import random
        return {
            'prediction': f"预测 {target} 在未来 {horizon} 步内的趋势",
            'confidence': 0.6 + random.random() * 0.3,
            'horizon': horizon
        }
    
    def _mock_simulate(self, initial: Dict) -> Dict[str, Any]:
        """模拟场景"""
        return {
            'outcome': '模拟结果',
            'confidence': 0.7,
            'initial_conditions': initial
        }
