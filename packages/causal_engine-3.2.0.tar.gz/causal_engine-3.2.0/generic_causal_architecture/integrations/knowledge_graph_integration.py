"""
知识图谱集成 - 基于 GitNexus 原理

GitNexus 核心原理:
1. 代码知识图谱 (依赖关系、调用链、聚类、执行流)
2. 图查询语言 (Cypher)
3. 语义搜索 (BM25 + 向量混合检索)
4. 影响分析 (变更影响范围)

本模块将这些原理应用到通用知识图谱:
1. 事件知识图谱 (因果关系、时序关系、关联关系)
2. 图查询 (Cypher for Apache AGE)
3. 语义搜索 (关键词 + 语义混合检索)
4. 因果链分析 (因果影响范围)
"""

import logging
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

from ..storage.postgresql_storage import PostgreSQLStorage

logger = logging.getLogger(__name__)


class RelationType(Enum):
    """关系类型"""
    CAUSAL = "causal"  # 因果关系
    TEMPORAL = "temporal"  # 时序关系
    CORRELATIONAL = "correlational"  # 相关关系
    HIERARCHICAL = "hierarchical"  # 层级关系
    SPATIAL = "spatial"  # 空间关系


@dataclass
class GraphNode:
    """图谱节点"""
    id: str
    label: str
    properties: Dict[str, Any]
    node_type: str = "event"  # event, entity, concept, etc.


@dataclass
class GraphEdge:
    """图谱边"""
    source_id: str
    target_id: str
    relation_type: RelationType
    properties: Dict[str, Any]
    confidence: float = 1.0


@dataclass
class GraphPath:
    """图谱路径"""
    nodes: List[GraphNode]
    edges: List[GraphEdge]
    total_confidence: float
    
    def __str__(self):
        node_labels = " -> ".join([n.label for n in self.nodes])
        return f"{node_labels} (confidence: {self.total_confidence:.2f})"


class KnowledgeGraphIntegration:
    """
    知识图谱集成
    
    基于 GitNexus 原理，提供:
    1. 图谱构建：从存储数据构建知识图谱
    2. 图谱查询：使用 Cypher 查询语言
    3. 路径发现：发现节点间的关系路径
    4. 影响分析：分析事件变更的影响范围
    5. 语义搜索：混合关键词和语义检索
    """
    
    def __init__(self, storage: PostgreSQLStorage):
        """
        初始化知识图谱集成
        
        Args:
            storage: PostgreSQL 存储实例 (带 Apache AGE 扩展)
        """
        self.storage = storage
        self._cache = {}  # 简单的缓存
        
    def build_graph(self, event_ids: Optional[List[str]] = None) -> Tuple[List[GraphNode], List[GraphEdge]]:
        """
        构建知识图谱
        
        Args:
            event_ids: 要包含的事件 ID 列表，None 表示所有事件
        
        Returns:
            (nodes, edges) 元组
        """
        logger.info(f"Building knowledge graph for {len(event_ids) if event_ids else 'all'} events")
        
        nodes = []
        edges = []
        
        # 获取事件数据
        if event_ids:
            events = []
            for event_id in event_ids:
                event = self.storage.get_event(event_id)
                if event:
                    events.append(event)
        else:
            # 获取所有事件 (简化实现，实际应该分页)
            all_relations = self.storage.get_all_relations()
            event_ids_set = set()
            for relation in all_relations:
                event_ids_set.add(relation.source_id)
                event_ids_set.add(relation.target_id)
            
            events = []
            for event_id in event_ids_set:
                event = self.storage.get_event(event_id)
                if event:
                    events.append(event)
        
        # 创建节点
            for event in events:
                node = GraphNode(
                    id=event.id,
                    label=event.name,
                    properties={
                        'event_type': event.event_type if event.event_type else 'unknown',
                        'timestamp': event.timestamp,
                        'source': event.description,
                        'entities': event.participants or [],
                        'location': event.location
                    },
                    node_type='event'
                )
                nodes.append(node)
        
        # 创建边 (从因果关系到图谱关系)
        all_relations = self.storage.get_all_relations()
        for relation in all_relations:
            if event_ids and (relation.source_id not in event_ids or relation.target_id not in event_ids):
                continue
            
            edge = GraphEdge(
                source_id=relation.source_id,
                target_id=relation.target_id,
                relation_type=RelationType.CAUSAL,
                properties={
                    'relation_type': relation.relation_type,
                    'confidence': relation.confidence,
                    'evidence': relation.evidence or []
                },
                confidence=relation.confidence
            )
            edges.append(edge)
        
        logger.info(f"Built graph with {len(nodes)} nodes and {len(edges)} edges")
        return nodes, edges
    
    def query_cypher(self, cypher_query: str) -> List[Dict[str, Any]]:
        """
        执行 Cypher 查询
        
        GitNexus 原理应用:
        - 使用 Cypher 查询语言
        - 支持 MATCH, WHERE, RETURN 等子句
        - 支持路径查询、聚合等
        
        Args:
            cypher_query: Cypher 查询语句
        
        Returns:
            查询结果列表
        
        Example:
            ```cypher
            MATCH (a:event)-[r:CAUSAL]->(b:event)
            WHERE a.event_type = 'military'
            RETURN a.label, b.label, r.strength
            ```
        """
        logger.info(f"Executing Cypher query: {cypher_query[:100]}...")
        
        try:
            # 使用 PostgreSQL+AGE 执行 Cypher 查询
            # 注意：实际实现需要通过 psycopg2 执行 AGE 的 Cypher 查询
            # 这里简化为示例
            
            # 实际代码示例:
            # with self.storage.connection.cursor() as cursor:
            #     cursor.execute("SELECT * FROM cypher('graph_name', %s) AS (a agtype, b agtype, r agtype)", 
            #                    (cypher_query,))
            #     results = cursor.fetchall()
            
            # 简化实现：返回模拟结果
            logger.warning("Cypher query execution requires Apache AGE setup")
            return []
            
        except Exception as e:
            logger.error(f"Cypher query failed: {e}")
            return []
    
    def find_paths(self, 
                   source_id: str, 
                   target_id: str, 
                   max_depth: int = 5,
                   relation_types: Optional[List[RelationType]] = None) -> List[GraphPath]:
        """
        查找两个节点之间的所有路径
        
        GitNexus 原理应用:
        - 执行流追踪 (类似 GitNexus 的 process trace)
        - 支持深度限制
        - 支持关系类型过滤
        
        Args:
            source_id: 起始节点 ID
            target_id: 目标节点 ID
            max_depth: 最大深度
            relation_types: 允许的关系类型，None 表示所有类型
        
        Returns:
            路径列表，按置信度排序
        """
        logger.info(f"Finding paths from {source_id} to {target_id}, max_depth={max_depth}")
        
        # 构建图
        nodes, edges = self.build_graph()
        
        # 创建邻接表
        node_map = {n.id: n for n in nodes}
        adjacency = {}
        for node in nodes:
            adjacency[node.id] = []
        
        for edge in edges:
            if relation_types and edge.relation_type not in relation_types:
                continue
            if edge.source_id in adjacency:
                adjacency[edge.source_id].append((edge.target_id, edge))
        
        # BFS 查找所有路径
        paths = []
        queue = [(source_id, [node_map[source_id]], [])]
        
        while queue and len(paths) < 100:  # 限制路径数量
            current_id, current_nodes, current_edges = queue.pop(0)
            
            if current_id == target_id:
                # 找到一条路径
                total_confidence = 1.0
                for edge in current_edges:
                    total_confidence *= edge.confidence
                
                path = GraphPath(
                    nodes=current_nodes,
                    edges=current_edges,
                    total_confidence=total_confidence
                )
                paths.append(path)
                continue
            
            if len(current_nodes) >= max_depth:
                continue
            
            for neighbor_id, edge in adjacency.get(current_id, []):
                if neighbor_id not in [n.id for n in current_nodes]:  # 避免环
                    new_nodes = current_nodes + [node_map[neighbor_id]]
                    new_edges = current_edges + [edge]
                    queue.append((neighbor_id, new_nodes, new_edges))
        
        # 按置信度排序
        paths.sort(key=lambda p: p.total_confidence, reverse=True)
        
        logger.info(f"Found {len(paths)} paths")
        return paths
    
    def analyze_impact(self, event_id: str, depth: int = 3) -> Dict[str, Any]:
        """
        分析事件变更的影响范围
        
        GitNexus 原理应用:
        - 变更影响分析 (类似 GitNexus 的 detect_changes)
        - 支持深度遍历
        - 返回直接和间接影响
        
        Args:
            event_id: 要分析的事件 ID
            depth: 分析深度
        
        Returns:
            影响分析结果
        """
        logger.info(f"Analyzing impact of {event_id}, depth={depth}")
        
        nodes, edges = self.build_graph()
        node_map = {n.id: n for n in nodes}
        
        if event_id not in node_map:
            return {
                'error': f'Event {event_id} not found',
                'direct_impacts': [],
                'indirect_impacts': [],
                'total_affected': 0
            }
        
        # 构建反向邻接表 (查找受影响的节点)
        reverse_adjacency = {}
        for node in nodes:
            reverse_adjacency[node.id] = []
        
        for edge in edges:
            if edge.target_id in reverse_adjacency:
                reverse_adjacency[edge.target_id].append((edge.source_id, edge))
        
        # BFS 查找受影响节点
        direct_impacts = []
        indirect_impacts = []
        visited = {event_id}
        queue = [(event_id, 0)]
        
        while queue:
            current_id, current_depth = queue.pop(0)
            
            if current_depth >= depth:
                continue
            
            for source_id, edge in reverse_adjacency.get(current_id, []):
                if source_id not in visited:
                    visited.add(source_id)
                    impact_info = {
                        'event_id': source_id,
                        'label': node_map[source_id].label,
                        'depth': current_depth + 1,
                        'relation_type': edge.relation_type.value,
                        'confidence': edge.confidence
                    }
                    
                    if current_depth == 0:
                        direct_impacts.append(impact_info)
                    else:
                        indirect_impacts.append(impact_info)
                    
                    queue.append((source_id, current_depth + 1))
        
        return {
            'event_id': event_id,
            'direct_impacts': direct_impacts,
            'indirect_impacts': indirect_impacts,
            'total_affected': len(direct_impacts) + len(indirect_impacts),
            'max_depth_reached': depth
        }
    
    def semantic_search(self, 
                       query: str, 
                       keywords: Optional[List[str]] = None,
                       limit: int = 10) -> List[Tuple[GraphNode, float]]:
        """
        语义搜索
        
        GitNexus 原理应用:
        - 混合检索 (BM25 关键词 + 语义向量)
        - 按相关性排序
        
        Args:
            query: 搜索查询
            keywords: 额外关键词
            limit: 返回数量限制
        
        Returns:
            (节点，相关性分数) 列表
        """
        logger.info(f"Semantic search: {query}, keywords={keywords}")
        
        nodes, edges = self.build_graph()
        
        # 简化实现：仅关键词匹配
        # 实际应该使用向量数据库 (如 pgvector) 进行语义搜索
        
        results = []
        query_lower = query.lower()
        keywords_lower = [k.lower() for k in keywords] if keywords else []
        
        for node in nodes:
            score = 0.0
            
            # 检查标签匹配
            if query_lower in node.label.lower():
                score += 0.5
            
            # 检查属性匹配
            for key, value in node.properties.items():
                if isinstance(value, str) and query_lower in value.lower():
                    score += 0.3
                elif isinstance(value, list):
                    for item in value:
                        if isinstance(item, str) and query_lower in item.lower():
                            score += 0.3
            
            # 检查关键词
            for keyword in keywords_lower:
                if keyword in node.label.lower():
                    score += 0.2
            
            if score > 0:
                results.append((node, score))
        
        # 按分数排序
        results.sort(key=lambda x: x[1], reverse=True)
        
        return results[:limit]
    
    def get_causal_chain(self, event_id: str, direction: str = 'both') -> GraphPath:
        """
        获取事件的完整因果链
        
        Args:
            event_id: 事件 ID
            direction: 'upstream' (原因), 'downstream' (结果), 'both' (双向)
        
        Returns:
            因果链路径
        """
        logger.info(f"Getting causal chain for {event_id}, direction={direction}")
        
        nodes, edges = self.build_graph()
        node_map = {n.id: n for n in nodes}
        
        # 只保留因果关系边
        causal_edges = [e for e in edges if e.relation_type == RelationType.CAUSAL]
        
        # 构建邻接表
        upstream_adj = {}  # 查找原因
        downstream_adj = {}  # 查找结果
        for node in nodes:
            upstream_adj[node.id] = []
            downstream_adj[node.id] = []
        
        for edge in causal_edges:
            if edge.source_id in downstream_adj:
                downstream_adj[edge.source_id].append((edge.target_id, edge))
            if edge.target_id in upstream_adj:
                upstream_adj[edge.target_id].append((edge.source_id, edge))
        
        # 收集因果链节点
        chain_nodes = [node_map[event_id]]
        chain_edges = []
        visited = {event_id}
        
        # 上游 (原因)
        if direction in ['upstream', 'both']:
            queue = [(event_id, 0)]
            while queue:
                current_id, depth = queue.pop(0)
                if depth >= 10:  # 限制深度
                    continue
                
                for cause_id, edge in upstream_adj.get(current_id, []):
                    if cause_id not in visited:
                        visited.add(cause_id)
                        chain_nodes.insert(0, node_map[cause_id])
                        chain_edges.insert(0, edge)
                        queue.append((cause_id, depth + 1))
        
        # 下游 (结果)
        if direction in ['downstream', 'both']:
            queue = [(event_id, 0)]
            while queue:
                current_id, depth = queue.pop(0)
                if depth >= 10:
                    continue
                
                for result_id, edge in downstream_adj.get(current_id, []):
                    if result_id not in visited:
                        visited.add(result_id)
                        chain_nodes.append(node_map[result_id])
                        chain_edges.append(edge)
                        queue.append((result_id, depth + 1))
        
        # 计算总置信度
        total_confidence = 1.0
        for edge in chain_edges:
            total_confidence *= edge.confidence
        
        return GraphPath(
            nodes=chain_nodes,
            edges=chain_edges,
            total_confidence=total_confidence
        )
