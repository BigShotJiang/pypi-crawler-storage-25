"""
整合管理器 - 统一管理所有外部项目整合

整合管理器的职责：
1. 统一管理所有整合实例
2. 协调多个整合的协同工作
3. 提供统一的工作流接口
4. 管理整合的生命周期
"""

from typing import Any, Dict, List, Optional, Type
from ..container import Container
from ..interfaces.integration_interface import IIntegration


class IntegrationManager:
    """整合管理器"""
    
    def __init__(self, container: Optional[Container] = None):
        """
        初始化整合管理器
        
        Args:
            container: 依赖注入容器（可选）
        """
        self.container = container or Container()
        self.integrations: Dict[str, IIntegration] = {}
        self._initialized = False
    
    def register_integration(self, name: str, integration_class: Type[IIntegration],
                           config: Optional[Dict[str, Any]] = None) -> None:
        """
        注册整合
        
        Args:
            name: 整合名称
            integration_class: 整合类
            config: 配置字典
        """
        # 创建整合实例
        if config:
            integration = integration_class(config=config)
        else:
            integration = integration_class()
        
        # 注册到容器
        self.container.register(f'integration_{name}', lambda: integration)
        
        # 添加到整合字典
        self.integrations[name] = integration
    
    def get_integration(self, name: str) -> Optional[IIntegration]:
        """
        获取整合实例
        
        Args:
            name: 整合名称
            
        Returns:
            IIntegration: 整合实例，不存在返回 None
        """
        return self.integrations.get(name)
    
    def connect_all(self) -> Dict[str, bool]:
        """
        连接所有整合
        
        Returns:
            Dict[str, bool]: 每个整合的连接状态
        """
        results = {}
        
        for name, integration in self.integrations.items():
            try:
                success = integration.connect()
                results[name] = success
            except Exception as e:
                print(f"连接 {name} 失败：{e}")
                results[name] = False
        
        self._initialized = all(results.values())
        return results
    
    def disconnect_all(self) -> None:
        """断开所有整合的连接"""
        for integration in self.integrations.values():
            try:
                integration.disconnect()
            except Exception as e:
                print(f"断开连接失败：{e}")
        
        self._initialized = False
    
    def analyze_with_all(self, data: Any, **kwargs) -> Dict[str, Any]:
        """
        使用所有整合分析数据
        
        Args:
            data: 输入数据
            **kwargs: 额外参数
            
        Returns:
            Dict[str, Any]: 分析结果
        """
        if not self._initialized:
            self.connect_all()
        
        results = {}
        
        for name, integration in self.integrations.items():
            try:
                # 提取知识
                knowledge = integration.extract_knowledge(data=data, **kwargs)
                results[name] = {
                    'success': True,
                    'knowledge': knowledge,
                    'capabilities': integration.get_capabilities()
                }
            except Exception as e:
                results[name] = {
                    'success': False,
                    'error': str(e)
                }
        
        return results
    
    def create_unified_workflow(self, workflow_name: str,
                              steps: List[Dict[str, Any]]) -> 'UnifiedWorkflow':
        """
        创建统一工作流
        
        Args:
            workflow_name: 工作流名称
            steps: 工作流步骤
            
        Returns:
            UnifiedWorkflow: 创建的工作流
        """
        return UnifiedWorkflow(self, workflow_name, steps)
    
    def get_all_capabilities(self) -> Dict[str, Any]:
        """获取所有整合的能力"""
        capabilities = {}
        
        for name, integration in self.integrations.items():
            capabilities[name] = integration.get_capabilities()
        
        return capabilities


class UnifiedWorkflow:
    """统一工作流 - 协调多个整合完成复杂任务"""
    
    def __init__(self, manager: IntegrationManager, name: str,
                 steps: List[Dict[str, Any]]):
        """
        初始化统一工作流
        
        Args:
            manager: 整合管理器
            name: 工作流名称
            steps: 工作流步骤
        """
        self.manager = manager
        self.name = name
        self.steps = steps
        self.results = {}
    
    def execute(self, input_data: Any, **kwargs) -> Dict[str, Any]:
        """
        执行工作流
        
        Args:
            input_data: 输入数据
            **kwargs: 额外参数
            
        Returns:
            Dict[str, Any]: 执行结果
        """
        current_data = input_data
        
        for i, step in enumerate(self.steps):
            step_name = step.get('name', f'step_{i}')
            integration_name = step.get('integration')
            action = step.get('action')
            params = step.get('params', {})
            
            # 获取整合
            integration = self.manager.get_integration(integration_name)
            if not integration:
                raise ValueError(f"整合 {integration_name} 不存在")
            
            # 执行动作
            if action == 'extract':
                result = integration.extract_events(current_data, **params)
            elif action == 'analyze':
                result = integration.integrate(current_data, **params)
            elif action == 'predict':
                result = integration.predict_future_trend(current_data, **params)
            else:
                raise ValueError(f"未知动作：{action}")
            
            # 保存结果
            self.results[step_name] = result
            
            # 传递给下一步
            if step.get('pass_to_next', True):
                current_data = result
        
        return self.results
    
    def get_results(self) -> Dict[str, Any]:
        """获取所有步骤的结果"""
        return self.results
    
    def merge_results(self, merge_strategy: str = 'sequential') -> Dict[str, Any]:
        """
        合并所有步骤的结果
        
        Args:
            merge_strategy: 合并策略 ('sequential', 'parallel', 'custom')
            
        Returns:
            Dict[str, Any]: 合并后的结果
        """
        if merge_strategy == 'sequential':
            return self._merge_sequential()
        elif merge_strategy == 'parallel':
            return self._merge_parallel()
        else:
            return self.results
    
    def _merge_sequential(self) -> Dict[str, Any]:
        """顺序合并结果"""
        merged = {
            'workflow_name': self.name,
            'steps': len(self.steps),
            'results': self.results,
            'final_output': None
        }
        
        # 获取最后一步的结果作为最终输出
        if self.results:
            last_step = list(self.results.keys())[-1]
            merged['final_output'] = self.results[last_step]
        
        return merged
    
    def _merge_parallel(self) -> Dict[str, Any]:
        """并行合并结果"""
        merged = {
            'workflow_name': self.name,
            'steps': len(self.steps),
            'parallel_results': {}
        }
        
        for step_name, result in self.results.items():
            merged['parallel_results'][step_name] = result
        
        return merged


# ========== 预定义的工作流模板 ==========

def create_historical_analysis_workflow(manager: IntegrationManager) -> UnifiedWorkflow:
    """
    创建历史分析工作流
    
    工作流步骤：
    1. LangExtract: 从史料提取事件
    2. KnowledgeGraph: 建立事件关系
    3. CausalEngine: 验证因果关系
    4. Mirofish: 预测历史趋势（如果适用）
    """
    steps = [
        {
            'name': 'extract_events',
            'integration': 'langextract',
            'action': 'extract',
            'params': {'extraction_type': 'events'},
            'pass_to_next': True
        },
        {
            'name': 'build_relations',
            'integration': 'knowledge_graph',
            'action': 'analyze',
            'params': {'relation_types': ['causes', 'precedes', 'influences']},
            'pass_to_next': True
        },
        {
            'name': 'verify_causality',
            'integration': 'causal_engine',
            'action': 'infer',
            'params': {'min_confidence': 0.7},
            'pass_to_next': True
        },
        {
            'name': 'predict_trends',
            'integration': 'mirofish',
            'action': 'predict',
            'params': {'horizon': 5},
            'pass_to_next': False
        }
    ]
    
    return manager.create_unified_workflow('historical_analysis', steps)


def create_social_science_workflow(manager: IntegrationManager) -> UnifiedWorkflow:
    """
    创建社会科学分析工作流
    
    工作流步骤：
    1. LangExtract: 从文献/数据提取现象
    2. KnowledgeGraph: 建立社会现象关系网
    3. CausalEngine: 推断因果机制
    4. Mirofish: 模拟干预效果
    """
    steps = [
        {
            'name': 'extract_phenomena',
            'integration': 'langextract',
            'action': 'extract',
            'params': {'extraction_type': 'phenomena'},
            'pass_to_next': True
        },
        {
            'name': 'build_network',
            'integration': 'knowledge_graph',
            'action': 'analyze',
            'params': {'relation_types': ['influences', 'correlates', 'mediates']},
            'pass_to_next': True
        },
        {
            'name': 'infer_mechanism',
            'integration': 'causal_engine',
            'action': 'infer',
            'params': {'require_mechanism': True},
            'pass_to_next': True
        },
        {
            'name': 'simulate_intervention',
            'integration': 'mirofish',
            'action': 'simulate',
            'params': {'num_simulations': 100},
            'pass_to_next': False
        }
    ]
    
    return manager.create_unified_workflow('social_science_analysis', steps)
