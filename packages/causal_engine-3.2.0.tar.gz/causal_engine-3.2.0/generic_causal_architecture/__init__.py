"""
Generic Causal Architecture - 通用因果架构

基于因果论和方法论的通用底层架构，为各种领域提供因果推断能力。

核心定位:
    不是"又一个机器学习框架"
    而是"因果推断的基础设施"

使用示例:
    >>> from generic_causal_architecture import CausalEngine, LLMOrchestrator
    >>> from generic_causal_architecture.storage import MemoryStorage
    >>> from generic_causal_architecture.storage.storage_interface import EventData
    
    >>> # 创建存储和引擎
    >>> storage = MemoryStorage()
    >>> storage.initialize()
    >>> engine = CausalEngine(storage)
    
    >>> # 添加事件
    >>> event1 = EventData(id="e1", name="商鞅变法", timestamp=-356)
    >>> event2 = EventData(id="e2", name="秦统一六国", timestamp=-221)
    >>> storage.add_event(event1)
    >>> storage.add_event(event2)
    
    >>> # 因果推断
    >>> result = engine.infer_causality(event1, event2)
    >>> print(f"置信度：{result.overall_confidence}")
"""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

# 核心组件 - 直接导入
from .core.causal_engine import CausalEngine
from .orchestrator import LLMOrchestrator

# 存储 - 通过 storage 子模块导入
from . import storage

# 领域适配器 - 通过 adapters 子模块导入
from . import adapters

# 方法论 - 通过 methods 子模块导入
from . import methods

# LLM Provider - 通过 llm 子模块导入
from . import llm

# 工具 - 通过 utils 子模块导入
from . import utils

# 配置 - 通过 config 子模块导入
from . import config

# 集成 - 通过 integrations 子模块导入
from . import integrations

# 游戏SDK - 通过 game 子模块导入
from . import game

# 模拟 - 通过 simulation 子模块导入
from . import simulation

# 图 - 通过 graph 子模块导入
from . import graph

# CLI - 通过 cli 子模块导入
from . import cli

# API - 通过 api 子模块导入
from . import api

# 导入器 - 通过 importers 子模块导入
from . import importers

# 常用类的快捷导入
from .storage.storage_interface import EventData, CausalRelation
from .storage.memory_storage import MemoryStorage
from .storage.sqlite_storage import SQLiteStorage
from .storage.postgresql_storage import PostgreSQLStorage

from .core.action_models import Action, ActionRelation, ActionResult, ConsequenceChain

from .core.protocol import (
    RelationType,
    RuleLevel,
    Relation,
    ActionRequest,
    Chain,
    ChainLink,
    CandidateRule,
    ValidationResult,
    DiscoverRequest,
    DiscoverResult,
    FeedbackRequest,
    VALID_RELATION_TYPES,
    VALID_RULE_LEVELS,
)

from .core.rule_discovery import RuleDiscovery

from .core.meta_patterns import MetaPattern, MetaPatternStore, MetaPatternMatcher

# 方法论快捷导入
from .methods.lancet_method import LancetMethod
from .methods.iterative_workflow import IterativeWorkflow

# 领域适配器快捷导入
from .adapters.history_adapter import HistoryAdapter

__all__ = [
    # 核心组件
    "CausalEngine",
    "LLMOrchestrator",
    
    # 存储
    "storage",
    "MemoryStorage",
    "SQLiteStorage",
    "PostgreSQLStorage",
    "EventData",
    "CausalRelation",
    "Action",
    "ActionRelation",
    "ActionResult",
    "ConsequenceChain",

    # 协议层（统一标准）
    "RelationType",
    "RuleLevel",
    "Relation",
    "ActionRequest",
    "Chain",
    "ChainLink",
    "CandidateRule",
    "ValidationResult",
    "DiscoverRequest",
    "DiscoverResult",
    "FeedbackRequest",
    "VALID_RELATION_TYPES",
    "VALID_RULE_LEVELS",

    # 规则发现
    "RuleDiscovery",

    # 元模式
    "MetaPattern",
    "MetaPatternStore",
    "MetaPatternMatcher",
    
    # 方法论
    "methods",
    "LancetMethod",
    "IterativeWorkflow",
    
    # 适配器
    "adapters",
    "HistoryAdapter",
    
    # LLM
    "llm",
    
    # Game SDK
    "game",

    # 其他模块
    "config",
    "utils",
    "integrations",
    "simulation",
    "graph",
    "cli",
    "api",
    "importers",
    
    # 版本信息
    "__version__",
    "__author__",
    "__email__",
]
