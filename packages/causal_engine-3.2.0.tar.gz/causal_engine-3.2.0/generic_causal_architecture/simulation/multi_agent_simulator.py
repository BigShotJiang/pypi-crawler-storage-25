"""
多智能体因果世界模拟器

基于因果知识图谱的多智能体模拟：
1. 数字世界 = 因果图谱（实体 + 关系）
2. 智能体 = 自主决策实体，用链式推理做决策
3. 演化 = 沿因果链传播效应
4. 涌现 = 多智能体决策的群体模式

用法:
    from generic_causal_architecture.simulation.multi_agent_simulator import MultiAgentSimulator

    sim = MultiAgentSimulator(storage=storage, num_agents=5)
    sim.create_agents()
    sim.build_world_from_kg()
    result = await sim.run_simulation(steps=10)
"""

import logging
import asyncio
import uuid
from typing import List, Dict, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
import random
import json

logger = logging.getLogger(__name__)


@dataclass
class AgentCognition:
    agent_id: str
    role: str = ""
    beliefs: Dict[str, float] = field(default_factory=dict)
    goals: List[str] = field(default_factory=list)
    knowledge: Set[str] = field(default_factory=set)
    focus_entities: Set[str] = field(default_factory=set)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "role": self.role,
            "beliefs": self.beliefs,
            "goals": self.goals,
            "knowledge_count": len(self.knowledge),
            "focus_entities": list(self.focus_entities),
        }


@dataclass
class SimulationStepResult:
    step: int
    agent_decisions: List[Dict[str, Any]]
    world_changes: List[Dict[str, Any]]
    state_snapshot: Dict[str, Any]


@dataclass
class SimulationResult:
    simulation_id: str
    num_agents: int
    total_steps: int
    timeline: List[SimulationStepResult]
    agent_final_states: Dict[str, AgentCognition]
    emergence_patterns: List[Dict[str, Any]]
    consensus_findings: List[Dict[str, Any]]
    confidence: float

    def summary(self) -> str:
        lines = [
            f"=== 模拟结果 {self.simulation_id} ===",
            f"  智能体: {self.num_agents} | 步数: {self.total_steps}",
            f"  置信度: {self.confidence:.2f}",
            f"  涌现模式: {len(self.emergence_patterns)}",
            f"  共识发现: {len(self.consensus_findings)}",
        ]
        for p in self.emergence_patterns[:5]:
            lines.append(f"  📈 {p.get('description', '?')}")
        return "\n".join(lines)


class CausalWorld:
    """
    因果数字世界
    
    世界状态由因果图谱驱动：
    - entities: 所有可用实体
    - relations: 实体间的因果关系
    - active_effects: 当前正在传播的效应
    """

    def __init__(self, storage):
        self.storage = storage
        self.entities: Dict[str, Dict] = {}
        self.relations: List[Dict] = []
        self.active_effects: List[Dict] = []
        self.effect_history: List[Dict] = []
        self.step_counter = 0

    def load_from_kg(self) -> Tuple[int, int]:
        """从知识图谱加载世界数据."""
        rows = self.storage._execute_sql("""
            SELECT id, canonical_name, traditions, sources, aliases
            FROM public.unified_entities
            LIMIT 5000
        """)
        for r in rows:
            self.entities[r["id"]] = {
                "id": r["id"],
                "name": r["canonical_name"],
                "traditions": r.get("traditions") or [],
                "sources": r.get("sources") or [],
                "aliases": r.get("aliases") or "",
                "active": False,
                "activation_step": -1,
            }

        rels = self.storage._execute_sql("""
            SELECT source_entity_id, target_entity_id, relation_type, confidence,
                   is_inferred, evidence_descriptions
            FROM public.entity_relations
            WHERE confidence >= 0.30
            LIMIT 20000
        """)
        self.relations = [dict(r) for r in rels]

        logger.info(f"CausalWorld loaded: {len(self.entities)} entities, {len(self.relations)} relations")
        return len(self.entities), len(self.relations)

    def get_entity_by_name(self, name: str) -> Optional[Dict]:
        for e in self.entities.values():
            if e["name"] == name:
                return e
        names_lower = name.lower()
        for e in self.entities.values():
            if e["name"].lower() == names_lower or names_lower in e["name"].lower():
                return e
        return None

    def get_forward_relations(self, entity_id: str) -> List[Dict]:
        return [r for r in self.relations if r["source_entity_id"] == entity_id]

    def get_backward_relations(self, entity_id: str) -> List[Dict]:
        return [r for r in self.relations if r["target_entity_id"] == entity_id]

    def activate(self, entity_name: str, source_agent: str = "world") -> bool:
        """激活一个实体，开始沿因果链传播效应."""
        entity = self.get_entity_by_name(entity_name)
        if not entity:
            return False
        entity["active"] = True
        entity["activation_step"] = self.step_counter
        effect = {
            "step": self.step_counter,
            "entity_id": entity["id"],
            "entity_name": entity["name"],
            "source_agent": source_agent,
            "type": "activation",
        }
        self.active_effects.append(effect)
        self.effect_history.append(effect)
        return True

    def propagate(self, max_depth: int = 2) -> List[Dict]:
        """
        沿因果链传播效应.

        对每个活跃实体，查找其 forward relations 并激活目标.
        返回新激活的实体列表.
        """
        newly_activated = []
        activated_ids = set()

        active_entities = {
            eid: e for eid, e in self.entities.items()
            if e["active"] and e["activation_step"] == self.step_counter
        }

        for eid, entity in active_entities.items():
            fwd_rels = self.get_forward_relations(eid)
            for rel in fwd_rels:
                tgt_id = rel["target_entity_id"]
                if tgt_id in self.entities and tgt_id not in activated_ids:
                    target = self.entities[tgt_id]
                    if not target["active"]:
                        target["active"] = True
                        target["activation_step"] = self.step_counter + 1
                        activated_ids.add(tgt_id)
                        effect = {
                            "step": self.step_counter + 1,
                            "entity_id": tgt_id,
                            "entity_name": target["name"],
                            "triggered_by": entity["name"],
                            "relation_type": rel["relation_type"],
                            "confidence": rel["confidence"],
                            "is_inferred": rel.get("is_inferred", False),
                            "type": "propagation",
                        }
                        newly_activated.append(effect)
                        self.effect_history.append(effect)

        return newly_activated

    def evolve(self) -> Dict[str, Any]:
        """演化一步."""
        self.step_counter += 1
        new_effects = self.propagate(max_depth=2)

        for e in new_effects:
            self.active_effects.append(e)

        return {
            "step": self.step_counter,
            "new_propagations": len(new_effects),
            "total_active": sum(1 for e in self.entities.values() if e["active"]),
            "total_effects": len(self.effect_history),
        }

    def get_state(self) -> Dict[str, Any]:
        active_list = [
            {"name": e["name"], "activated_at": e["activation_step"]}
            for e in self.entities.values() if e["active"]
        ]
        return {
            "step": self.step_counter,
            "active_entities": active_list,
            "total_entities": len(self.entities),
            "total_active": len(active_list),
            "effect_count": len(self.effect_history),
        }


class CausalAgent:
    """
    因果推理智能体

    使用链式推理做决策的自主智能体。
    """

    STRATEGIES = ["analyst", "explorer", "skeptic", "synthesizer", "predictor"]

    def __init__(self, agent_id: str, strategy: str, world: CausalWorld,
                 kg_reasoner=None):
        self.agent_id = agent_id
        self.strategy = strategy
        self.world = world
        self.kg_reasoner = kg_reasoner
        self.cognition = AgentCognition(
            agent_id=agent_id,
            role=strategy,
        )
        self.decision_history: List[Dict] = []

    def perceive(self) -> Dict[str, Any]:
        """感知世界状态."""
        state = self.world.get_state()
        sample_size = min(20, len(state["active_entities"]))
        perceived_active = random.sample(
            state["active_entities"], sample_size
        ) if state["active_entities"] else []

        all_names = list(self.world.entities.keys())
        sample_entities = random.sample(
            all_names, min(15, len(all_names))
        )
        perceived_entities = [
            self.world.entities[eid]["name"]
            for eid in sample_entities if eid in self.world.entities
        ]

        return {
            "active_entities": perceived_active,
            "known_entities": perceived_entities,
            "total_active": state["total_active"],
            "step": state["step"],
        }

    def decide(self, perception: Dict[str, Any]) -> Dict[str, Any]:
        """基于策略和感知做出决策."""
        if self.strategy == "analyst":
            return self._decide_analyst(perception)
        elif self.strategy == "explorer":
            return self._decide_explorer(perception)
        elif self.strategy == "skeptic":
            return self._decide_skeptic(perception)
        elif self.strategy == "synthesizer":
            return self._decide_synthesizer(perception)
        elif self.strategy == "predictor":
            return self._decide_predictor(perception)
        else:
            return self._decide_analyst(perception)

    def _pick_focus_entity(self, perception: Dict[str, Any]) -> Optional[str]:
        """选择一个关注实体."""
        candidates = perception.get("known_entities", [])
        if not candidates:
            all_entities = list(self.world.entities.values())
            if all_entities:
                candidates = [e["name"] for e in random.sample(all_entities, min(10, len(all_entities)))]
        if candidates:
            return random.choice(candidates)
        return None

    def _decide_analyst(self, perception: Dict[str, Any]) -> Dict[str, Any]:
        """分析师策略: 深入分析一个实体的前向因果链."""
        entity = self._pick_focus_entity(perception)
        if not entity:
            return {"action": "observe", "reason": "无可用实体"}

        chains = []
        if self.kg_reasoner:
            try:
                chains = self.kg_reasoner.trace_forward(entity, max_depth=3)
            except Exception as e:
                logger.debug(f"Agent {self.agent_id} trace error: {e}")

        if chains:
            best = chains[0]
            target = best.links[-1].target_name if best.links else None
            activation_target = target if target and random.random() > 0.3 else entity
            return {
                "action": "analyze_and_activate",
                "focus_entity": entity,
                "chains_found": len(chains),
                "best_chain_confidence": round(best.total_confidence, 3),
                "chain_length": best.length,
                "activate": activation_target,
                "reason": f"分析{entity}发现{len(chains)}条因果链，最佳置信度{best.total_confidence:.2f}",
            }
        return {
            "action": "observe",
            "focus_entity": entity,
            "reason": f"分析{entity}未找到因果链",
        }

    def _decide_explorer(self, perception: Dict[str, Any]) -> Dict[str, Any]:
        """探索者策略: 随机探索未知区域."""
        entity = self._pick_focus_entity(perception)
        if not entity:
            return {"action": "explore", "reason": "随机探索"}

        if self.kg_reasoner:
            try:
                backward = self.kg_reasoner.trace_backward(entity, max_depth=2)
                forward = self.kg_reasoner.trace_forward(entity, max_depth=2)
            except Exception:
                backward, forward = [], []
        else:
            backward, forward = [], []

        activate_choice = entity
        if forward and random.random() > 0.4:
            activate_choice = forward[0].links[-1].target_name if forward[0].links else entity

        return {
            "action": "explore_and_activate",
            "focus_entity": entity,
            "backward_chains": len(backward),
            "forward_chains": len(forward),
            "activate": activate_choice,
            "reason": f"探索{entity}周围因果空间",
        }

    def _decide_skeptic(self, perception: Dict[str, Any]) -> Dict[str, Any]:
        """怀疑者策略: 质疑高置信度关系."""
        entity = self._pick_focus_entity(perception)
        if not entity:
            return {"action": "question", "reason": "质疑模式"}

        high_conf_rels = [
            r for r in self.world.get_forward_relations(
                next((e["id"] for e in self.world.entities.values() if e["name"] == entity), "")
            ) if r.get("confidence", 0) > 0.7
        ]

        if high_conf_rels and random.random() > 0.5:
            target_rel = random.choice(high_conf_rels)
            target_name = self.world.entities.get(target_rel["target_entity_id"], {}).get("name", "?")
            return {
                "action": "question_relation",
                "focus_entity": entity,
                "questioned_relation": f"{entity} → {target_name}",
                "relation_confidence": target_rel.get("confidence"),
                "reason": f"质疑{entity}→{target_name}的高置信度({target_rel['confidence']})关系",
            }
        return {
            "action": "observe",
            "focus_entity": entity,
            "reason": f"观察{entity}暂未发现可疑关系",
        }

    def _decide_synthesizer(self, perception: Dict[str, Any]) -> Dict[str, Any]:
        """综合者策略: 寻找跨领域连接."""
        entity = self._pick_focus_entity(perception)
        if not entity:
            return {"action": "synthesize", "reason": "综合分析"}

        if self.kg_reasoner:
            try:
                chains = self.kg_reasoner.trace_forward(entity, max_depth=4)
            except Exception:
                chains = []
        else:
            chains = []

        cross_text_chains = [c for c in chains if c.cross_text]
        activate_target = entity
        if cross_text_chains:
            best_cross = cross_text_chains[0]
            activate_target = best_cross.links[-1].target_name if best_cross.links else entity
            return {
                "action": "synthesize_and_activate",
                "focus_entity": entity,
                "cross_text_chains": len(cross_text_chains),
                "total_chains": len(chains),
                "activate": activate_target,
                "reason": f"发现{len(cross_text_chains)}条跨文本因果链，尝试连接不同来源的知识",
            }
        return {
            "action": "observe",
            "focus_entity": entity,
            "reason": f"{entity}周围未发现跨文本连接",
        }

    def _decide_predictor(self, perception: Dict[str, Any]) -> Dict[str, Any]:
        """预测者策略: 预测远期后果."""
        entity = self._pick_focus_entity(perception)
        if not entity:
            return {"action": "predict", "reason": "预测模式"}

        if self.kg_reasoner:
            try:
                long_chains = self.kg_reasoner.trace_forward(entity, max_depth=5)
            except Exception:
                long_chains = []
        else:
            long_chains = []

        deep_chains = [c for c in long_chains if c.length >= 3]
        if deep_chains:
            best = deep_chains[0]
            final_target = best.links[-1].target_name if best.links else entity
            return {
                "action": "predict_and_activate",
                "focus_entity": entity,
                "deep_chains_found": len(deep_chains),
                "predicted_outcome": final_target,
                "prediction_confidence": round(best.total_confidence, 3),
                "chain_length": best.length,
                "activate": final_target if random.random() > 0.4 else entity,
                "reason": f"预测{entity}经{best.length}步传导→{final_target}(置信{best.total_confidence:.2f})",
            }
        return {
            "action": "observe",
            "focus_entity": entity,
            "reason": f"{entity}未发现足够长的传导链",
        }

    def execute(self, decision: Dict[str, Any]) -> Optional[Dict]:
        """执行决策."""
        action = decision.get("action", "observe")
        activate_target = decision.get("activate")

        result = {
            "agent_id": self.agent_id,
            "strategy": self.strategy,
            "decision": decision,
            "executed_action": action,
        }

        if activate_target and action.endswith("_activate"):
            success = self.world.activate(activate_target, source_agent=self.agent_id)
            result["activation_result"] = "success" if success else "failed"
            if success:
                self.cognition.focus_entities.add(activate_target)
        else:
            result["activation_result"] = "none"

        self.decision_history.append(result)
        return result


class MultiAgentSimulator:
    """
    多智能体因果模拟器

    流程:
    1. build_world_from_kg() — 从知识图谱加载世界
    2. create_agents() — 创建多个策略不同的智能体
    3. run_simulation() — 运行多步模拟
    4. 分析涌现模式和共识
    """

    def __init__(self, storage, num_agents: int = 5,
                 strategies: Optional[List[str]] = None):
        self.storage = storage
        self.num_agents = num_agents
        self.strategies = strategies or list(CausalAgent.STRATEGIES)
        self.world: Optional[CausalWorld] = None
        self.agents: List[CausalAgent] = []
        self._kg_reasoner = None

    def _ensure_reasoner(self):
        """初始化 KG Reasoner."""
        if self._kg_reasoner is None:
            try:
                from ..core.kg_reasoner import KnowledgeGraphReasoner
                self._kg_reasoner = KnowledgeGraphReasoner(self.storage)
                self._kg_reasoner.load_graph()
                logger.info(f"KG Reasoner loaded for simulation: "
                            f"{len(self._kg_reasoner._names)} nodes")
            except Exception as e:
                logger.warning(f"KG Reasoner init failed: {e}")

    def build_world_from_kg(self, limit_entities: int = 5000,
                            limit_relations: int = 20000) -> Tuple[int, int]:
        """从知识图谱构建数字世界."""
        self.world = CausalWorld(self.storage)
        return self.world.load_from_kg()

    def create_agents(self, configs: Optional[List[Dict]] = None):
        """创建智能体."""
        self.agents = []
        if configs:
            for cfg in configs:
                agent = CausalAgent(
                    agent_id=cfg.get("agent_id", f"agent_{len(self.agents)}"),
                    strategy=cfg.get("strategy", "analyst"),
                    world=self.world,
                    kg_reasoner=self._kg_reasoner,
                )
                if cfg.get("goals"):
                    agent.cognition.goals = cfg["goals"]
                self.agents.append(agent)
        else:
            for i in range(self.num_agents):
                strategy = self.strategies[i % len(self.strategies)]
                agent = CausalAgent(
                    agent_id=f"agent_{i}",
                    strategy=strategy,
                    world=self.world,
                    kg_reasoner=self._kg_reasoner,
                )
                self.agents.append(agent)

        self._ensure_reasoner()
        for agent in self.agents:
            agent.kg_reasoner = self._kg_reasoner

        logger.info(f"Created {len(self.agents)} agents: "
                    f"{[a.strategy for a in self.agents]}")

    async def run_simulation(self, steps: int = 10) -> SimulationResult:
        """运行完整模拟."""
        if not self.world:
            raise ValueError("World not built. Call build_world_from_kg() first.")
        if not self.agents:
            raise ValueError("No agents. Call create_agents() first.")

        sim_id = f"sim_{uuid.uuid4().hex[:8]}"
        logger.info(f"Starting simulation {sim_id}: "
                    f"{len(self.agents)} agents, {steps} steps")

        timeline: List[SimulationStepResult] = []

        seed_entities = list(self.world.entities.values())
        random.seed(42)
        seeds = random.sample(seed_entities, min(self.num_agents * 2, len(seed_entities)))

        for i, agent in enumerate(self.agents):
            if i < len(seeds):
                self.world.activate(seeds[i]["name"], source_agent=agent.agent_id)

        for step in range(steps):
            step_results: List[Dict] = []
            world_changes: List[Dict] = []

            for agent in self.agents:
                perception = agent.perceive()
                decision = agent.decide(perception)
                exec_result = agent.execute(decision)
                step_results.append(exec_result)

                if exec_result and exec_result.get("activation_result") == "success":
                    world_changes.append({
                        "agent": agent.agent_id,
                        "activated": decision.get("activate"),
                    })

            world_state = self.world.evolve()
            if world_state["new_propagations"] > 0:
                world_changes.extend([
                    {"agent": "world", "type": "propagation",
                     "count": world_state["new_propagations"]}
                ])

            timeline.append(SimulationStepResult(
                step=step,
                agent_decisions=step_results,
                world_changes=world_changes,
                state_snapshot=world_state,
            ))

            if (step + 1) % 5 == 0:
                logger.info(f"  Step {step+1}/{steps}: "
                            f"{world_state['total_active']} active, "
                            f"{world_state['effect_count']} effects")

        emergence = self._detect_emergence(timeline)
        consensus = self._detect_consensus(timeline)

        final_states = {a.agent_id: a.cognition for a in self.agents}
        avg_conf = self._compute_confidence(timeline)

        result = SimulationResult(
            simulation_id=sim_id,
            num_agents=len(self.agents),
            total_steps=steps,
            timeline=timeline,
            agent_final_states=final_states,
            emergence_patterns=emergence,
            consensus_findings=consensus,
            confidence=avg_conf,
        )

        logger.info(f"Simulation {sim_id} complete: "
                    f"{len(emergence)} patterns, {len(consensus)} consensus")
        return result

    def _detect_emergence(self, timeline: List[SimulationStepResult]) -> List[Dict[str, Any]]:
        """检测涌现模式."""
        patterns = []

        all_activations: Dict[str, int] = {}
        for step in timeline:
            for d in step.agent_decisions:
                act = d.get("decision", {}).get("activate")
                if act:
                    all_activations[act] = all_activations.get(act, 0) + 1

        top_activated = sorted(all_activations.items(), key=lambda x: -x[1])[:10]
        if top_activated:
            patterns.append({
                "type": "hotspot_convergence",
                "description": f"热点收敛: {top_activated[0][0]} 被激活 {top_activated[0][1]} 次",
                "top_entities": [{"name": n, "count": c} for n, c in top_activated[:5]],
            })

        strategy_actions: Dict[str, Dict[str, int]] = {}
        for step in timeline:
            for d in step.agent_decisions:
                strat = d.get("strategy", "?")
                action = d.get("executed_action", "?")
                if strat not in strategy_actions:
                    strategy_actions[strat] = {}
                strategy_actions[strat][action] = strategy_actions[strat].get(action, 0) + 1

        divergent_strategies = {
            s: actions for s, actions in strategy_actions.items()
            if len(actions) > 1
        }
        if divergent_strategies:
            patterns.append({
                "type": "behavioral_diversity",
                "description": f"行为多样性: {len(divergent_strategies)} 种策略展现出不同行为模式",
                "strategy_breakdown": {
                    s: dict(actions) for s, actions in list(divergent_strategies.items())[:3]
                },
            })

        growth_curve = [s.state_snapshot["total_active"] for s in timeline]
        if len(growth_curve) > 2 and growth_curve[-1] > growth_curve[0] * 2:
            patterns.append({
                "type": "network_growth",
                "description": f"网络增长: 活跃实体从 {growth_curve[0]} 增长到 {growth_curve[-1]} ({growth_curve[-1]/max(growth_curve[0],1):.1f}x)",
                "growth_curve": growth_curve,
            })

        cross_text_activations = sum(
            1 for step in timeline
            for d in step.agent_decisions
            if d.get("decision", {}).get("action") == "synthesize_and_activate"
        )
        if cross_text_activations > 0:
            patterns.append({
                "type": "cross_source_discovery",
                "description": f"跨源发现: {cross_text_activations} 次跨文本/跨来源连接尝试",
                "count": cross_text_activations,
            })

        if not patterns:
            patterns.append({
                "type": "baseline",
                "description": "基础模式：各智能体独立行动，无明显涌现",
            })

        return patterns

    def _detect_consensus(self, timeline: List[SimulationStepResult]) -> List[Dict[str, Any]]:
        """检测多智能体共识."""
        findings = []

        entity_votes: Dict[str, Set[str]] = {}
        for step in timeline:
            for d in step.agent_decisions:
                act = d.get("decision", {}).get("activate")
                agent = d.get("agent_id", "")
                if act:
                    if act not in entity_votes:
                        entity_votes[act] = set()
                    entity_votes[act].add(agent)

        consensus_entities = [
            (name, agents) for name, agents in entity_votes.items()
            if len(agents) >= 2
        ]
        consensus_entities.sort(key=lambda x: -len(x[1]))

        for name, agents in consensus_entities[:5]:
            findings.append({
                "type": "entity_consensus",
                "entity": name,
                "agreeing_agents": list(agents),
                "agreement_level": len(agents) / max(len(self.agents), 1),
                "description": f"{'、'.join(sorted(agents))} 共同关注/激活了 [{name}]",
            })

        relation_questions = []
        for step in timeline:
            for d in step.agent_decisions:
                if d.get("executed_action") == "question_relation":
                    relation_questions.append(d.get("decision", {}))

        if relation_questions:
            questioned = [q.get("questioned_relation") for q in relation_questions]
            findings.append({
                "type": "skeptic_consensus",
                "description": f"怀疑者策略共质疑 {len(relation_questions)} 个高置信度关系",
                "questioned_relations": questioned[:5],
            })

        predictions = []
        for step in timeline:
            for d in step.agent_decisions:
                if d.get("decision", {}).get("action") == "predict_and_activate":
                    predictions.append(d["decision"])

        if predictions:
            pred_targets = [p.get("predicted_outcome") for p in predictions]
            from collections import Counter
            pred_counts = Counter(pred_targets)
            top_pred = pred_counts.most_common(3)
            findings.append({
                "type": "prediction_alignment",
                "description": f"预测者策略产生 {len(predictions)} 条预测，最常预测的结果: {[t for t, c in top_pred]}",
                "prediction_distribution": dict(pred_counts.most_common(5)),
            })

        return findings

    def _compute_confidence(self, timeline: List[SimulationStepResult]) -> float:
        """计算整体模拟置信度."""
        if not timeline:
            return 0.0

        total_decisions = sum(len(s.agent_decisions) for s in timeline)
        activations = sum(
            1 for s in timeline
            for d in s.agent_decisions
            if d.get("activation_result") == "success"
        )

        decision_rate = total_decisions / max(len(timeline) * len(self.agents), 1)
        activation_rate = activations / max(total_decisions, 1)
        growth = timeline[-1].state_snapshot["total_active"] / max(timeline[0].state_snapshot["total_active"] or 1, 1)

        conf = (decision_rate * 0.3 + activation_rate * 0.4 + min(growth / 10, 1.0) * 0.3)
        return round(min(conf, 0.95), 3)

    def simulate_sync(self, steps: int = 10) -> SimulationResult:
        """同步运行模拟（非异步环境）."""
        return asyncio.get_event_loop().run_until_complete(
            self.run_simulation(steps)
        )


if __name__ == "__main__":
    import sys
    from pathlib import Path
    sys.path.insert(0, str(Path(__file__).parent.parent.parent))

    from generic_causal_architecture.storage.postgresql_storage import PostgreSQLStorage

    DB_URL = "postgresql://postgres:causal_password@localhost:5432/causal_db"
    storage = PostgreSQLStorage(database_url=DB_URL)
    storage.initialize()

    print("=" * 60)
    print("多智能体因果模拟器")
    print("=" * 60)

    sim = MultiAgentSimulator(storage, num_agents=5)
    n_ent, n_rel = sim.build_world_from_kg()
    print(f"  世界加载: {n_ent} 实体, {n_rel} 关系")

    sim.create_agents()
    print(f"  智能体: {[a.strategy for a in sim.agents]}")

    result = sim.simulate_sync(steps=8)
    print()
    print(result.summary())
