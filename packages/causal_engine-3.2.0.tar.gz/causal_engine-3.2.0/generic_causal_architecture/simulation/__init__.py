"""
因果世界模拟层

基于因果知识图谱的多智能体模拟：
- CausalWorld: 因果数字世界（从 KG 加载）
- CausalAgent: 因果推理智能体（5 种策略）
- MultiAgentSimulator: 多智能体模拟器
"""

from .multi_agent_simulator import (
    MultiAgentSimulator,
    CausalWorld,
    CausalAgent,
    AgentCognition,
    SimulationStepResult,
    SimulationResult
)

__all__ = [
    'MultiAgentSimulator',
    'CausalWorld',
    'CausalAgent',
    'AgentCognition',
    'SimulationStepResult',
    'SimulationResult'
]
