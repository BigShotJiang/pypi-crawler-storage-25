"""
LLM Provider 抽象层 - 统一不同 LLM 的调用接口

设计原则：
1. 统一接口 - 所有 LLM 提供商使用相同的调用方式
2. 灵活扩展 - 添加新 LLM 只需实现 Provider 接口
3. 用户配置 - LLM API Key 由用户自己配置
4. 成本透明 - 实时统计 Token 用量和费用

使用示例：
    from generic_causal_architecture.llm import create_llm_provider
    
    # 创建 Provider（用户自己配置 API Key）
    llm = create_llm_provider({
        "provider": "openai",
        "api_key": "sk-...",  # 用户自己的 Key
        "model": "gpt-4"
    })
    
    # 调用
    response = await llm.chat([
        {"role": "user", "content": "你好"}
    ])
    
    # 查看用量
    usage = llm.get_usage()
    print(f"费用：${usage['cost']}")
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, field
import time


@dataclass
class TokenUsage:
    """Token 用量统计"""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost: float = 0.0  # 费用（美元）
    request_count: int = 0  # 请求次数
    avg_latency: float = 0.0  # 平均延迟（秒）
    
    def add_request(self, prompt: int, completion: int, latency: float, cost: float):
        """添加一次请求的统计"""
        self.prompt_tokens += prompt
        self.completion_tokens += completion
        self.total_tokens += prompt + completion
        self.cost += cost
        self.request_count += 1
        
        # 计算平均延迟
        total_latency = self.avg_latency * (self.request_count - 1) + latency
        self.avg_latency = total_latency / self.request_count
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "cost_usd": round(self.cost, 6),
            "request_count": self.request_count,
            "avg_latency_sec": round(self.avg_latency, 3)
        }


class LLMProvider(ABC):
    """
    LLM 提供商抽象基类
    
    所有 LLM 提供商（OpenAI、Claude、Ollama 等）都必须实现这个接口
    
    使用示例：
        provider = OpenAIProvider(api_key="sk-...", model="gpt-4")
        response = await provider.chat([...])
    """
    
    def __init__(self, model: str, **kwargs):
        """
        初始化 LLM Provider
        
        Args:
            model: 模型名称
            **kwargs: 其他配置参数
        """
        self.model = model
        self.usage = TokenUsage()
        self.config = kwargs
    
    @abstractmethod
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """
        发送对话请求
        
        Args:
            messages: 对话历史，格式为 [{"role": "user", "content": "..."}]
            **kwargs: 其他参数（temperature, max_tokens 等）
        
        Returns:
            AI 的回复内容
        """
        pass
    
    @abstractmethod
    async def complete(self, prompt: str, **kwargs) -> str:
        """
        文本补全
        
        Args:
            prompt: 输入文本
            **kwargs: 其他参数
        
        Returns:
            补全的文本
        """
        pass
    
    @abstractmethod
    def get_usage(self) -> Dict[str, Any]:
        """
        获取用量统计
        
        Returns:
            包含 token 用量和费用的字典
        """
        pass
    
    def reset_usage(self):
        """重置用量统计"""
        self.usage = TokenUsage()
    
    def _record_usage(
        self,
        prompt_tokens: int,
        completion_tokens: int,
        latency: float,
        cost: float
    ):
        """记录一次请求的用量"""
        self.usage.add_request(
            prompt=prompt_tokens,
            completion=completion_tokens,
            latency=latency,
            cost=cost
        )
    
    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(model={self.model})"
