"""
LLM Provider 模块

提供统一的 LLM 接口，支持多种 LLM 提供商：
- OpenAI (GPT-4, GPT-3.5-Turbo)
- Anthropic (Claude)
- Ollama (本地模型，免费离线)
- Hybrid (云端优先，失败自动降级到本地)

使用示例：
    from generic_causal_architecture.llm import create_llm_provider
    
    # OpenAI 云端
    llm = create_llm_provider({
        "provider": "openai",
        "api_key": "sk-...",
        "model": "gpt-4"
    })
    
    # 本地模型（免费，离线）
    llm = create_llm_provider({
        "provider": "local",
        "model": "qwen2.5:7b"
    })
    
    # 混合模式（推荐：云端优先，失败降级到本地）
    llm = create_llm_provider({
        "provider": "hybrid",
        "primary": {"provider": "openai", "api_key": "sk-...", "model": "gpt-4"},
        "fallback": {"provider": "local", "model": "qwen2.5:7b"}
    })
    
    # 调用
    response = await llm.chat([...])
    
    # 查看用量
    usage = llm.get_usage()
    print(f"费用：${usage['cost_usd']}")
"""

from typing import Dict, Any, Optional
from .provider import LLMProvider, TokenUsage
from .providers.openai_provider import OpenAIProvider
from .providers.claude_provider import ClaudeProvider
from .providers.ollama_provider import OllamaProvider
from .providers.fallback_provider import FallbackProvider

__all__ = [
    "LLMProvider",
    "TokenUsage",
    "OpenAIProvider",
    "ClaudeProvider",
    "OllamaProvider",
    "FallbackProvider",
    "create_llm_provider",
]


def create_llm_provider(config: Dict[str, Any]) -> LLMProvider:
    """
    根据配置创建 LLM Provider 实例
    
    工厂模式，自动根据 provider 类型创建对应的实例
    
    Args:
        config: 配置字典，包含 provider 类型和其他参数
    
    Returns:
        LLMProvider 实例
    
    Raises:
        ValueError: provider 类型不支持
        ImportError: 缺少必要的依赖库
    
    使用示例：
        # OpenAI
        llm = create_llm_provider({
            "provider": "openai",
            "api_key": "sk-...",
            "model": "gpt-4"
        })
        
        # Claude
        llm = create_llm_provider({
            "provider": "claude",
            "api_key": "sk-ant-...",
            "model": "claude-3-opus"
        })
        
        # 本地模型（Ollama，免费离线）
        llm = create_llm_provider({
            "provider": "local",
            "model": "qwen2.5:7b"
        })
        
        # Ollama（显式指定）
        llm = create_llm_provider({
            "provider": "ollama",
            "model": "qwen:7b",
            "base_url": "http://localhost:11434"
        })
        
        # 混合模式（云端优先，失败自动降级到本地）
        llm = create_llm_provider({
            "provider": "hybrid",
            "primary": {
                "provider": "openai",
                "api_key": "sk-...",
                "model": "gpt-4"
            },
            "fallback": {
                "provider": "local",
                "model": "qwen2.5:7b"
            }
        })
    """
    provider_type = config.get("provider", "openai").lower()
    
    if provider_type == "openai":
        return OpenAIProvider(
            api_key=config.get("api_key"),
            model=config.get("model", "gpt-4"),
            base_url=config.get("base_url"),
            temperature=config.get("temperature", 0.7),
            max_tokens=config.get("max_tokens", 2000),
        )
    
    elif provider_type == "claude":
        return ClaudeProvider(
            api_key=config.get("api_key"),
            model=config.get("model", "claude-3-sonnet-20240229"),
            temperature=config.get("temperature", 0.7),
            max_tokens=config.get("max_tokens", 2000),
        )
    
    elif provider_type == "ollama":
        return OllamaProvider(
            model=config.get("model", "qwen:7b"),
            base_url=config.get("base_url", "http://localhost:11434"),
            temperature=config.get("temperature", 0.7),
            max_tokens=config.get("max_tokens", 2000),
            timeout=config.get("timeout", 120),
        )
    
    elif provider_type == "local":
        return OllamaProvider(
            model=config.get("model", "qwen2.5:7b"),
            base_url=config.get("base_url", "http://localhost:11434"),
            temperature=config.get("temperature", 0.7),
            max_tokens=config.get("max_tokens", 2000),
            timeout=config.get("timeout", 120),
        )
    
    elif provider_type == "hybrid":
        primary_config = config.get("primary")
        fallback_config = config.get("fallback")
        if not primary_config:
            raise ValueError(
                "Hybrid provider requires 'primary' config. "
                "Example: {\"provider\": \"hybrid\", "
                "\"primary\": {\"provider\": \"openai\", ...}, "
                "\"fallback\": {\"provider\": \"local\", ...}}"
            )
        if not fallback_config:
            raise ValueError(
                "Hybrid provider requires 'fallback' config. "
                "Example: {\"provider\": \"hybrid\", "
                "\"primary\": {\"provider\": \"openai\", ...}, "
                "\"fallback\": {\"provider\": \"local\", ...}}"
            )
        primary = create_llm_provider(primary_config)
        fallback = create_llm_provider(fallback_config)
        return FallbackProvider(
            primary=primary,
            fallback=fallback,
            max_retries=config.get("max_retries", 1),
            retry_delay=config.get("retry_delay", 0),
            fallback_on_timeout=config.get("fallback_on_timeout", True),
            fallback_on_error=config.get("fallback_on_error", True),
        )
    
    else:
        raise ValueError(
            f"Unsupported LLM provider: {provider_type}\n"
            f"Supported: openai, claude, ollama, local, hybrid"
        )


# 便捷函数
def get_openai_provider(
    api_key: Optional[str] = None,
    model: str = "gpt-4",
    **kwargs
) -> OpenAIProvider:
    """
    快速创建 OpenAI Provider
    
    使用示例：
        llm = get_openai_provider(model="gpt-4")
    """
    return create_llm_provider({
        "provider": "openai",
        "api_key": api_key,
        "model": model,
        **kwargs
    })


def get_claude_provider(
    api_key: Optional[str] = None,
    model: str = "claude-3-sonnet-20240229",
    **kwargs
) -> ClaudeProvider:
    """
    快速创建 Claude Provider
    
    使用示例：
        llm = get_claude_provider(model="claude-3-opus")
    """
    return create_llm_provider({
        "provider": "claude",
        "api_key": api_key,
        "model": model,
        **kwargs
    })


def get_ollama_provider(
    model: str = "qwen:7b",
    base_url: str = "http://localhost:11434",
    **kwargs
) -> OllamaProvider:
    """
    快速创建 Ollama Provider
    
    使用示例：
        llm = get_ollama_provider(model="qwen:7b")
    """
    return create_llm_provider({
        "provider": "ollama",
        "model": model,
        "base_url": base_url,
        **kwargs
    })


def get_local_provider(
    model: str = "qwen2.5:7b",
    base_url: str = "http://localhost:11434",
    **kwargs,
) -> OllamaProvider:
    """Quick-create a local (Ollama) Provider."""
    return create_llm_provider({
        "provider": "local",
        "model": model,
        "base_url": base_url,
        **kwargs,
    })


def get_hybrid_provider(
    primary_config: Dict[str, Any],
    fallback_config: Dict[str, Any],
    **kwargs,
) -> FallbackProvider:
    """Quick-create a hybrid Provider (cloud + local fallback)."""
    return create_llm_provider({
        "provider": "hybrid",
        "primary": primary_config,
        "fallback": fallback_config,
        **kwargs,
    })
