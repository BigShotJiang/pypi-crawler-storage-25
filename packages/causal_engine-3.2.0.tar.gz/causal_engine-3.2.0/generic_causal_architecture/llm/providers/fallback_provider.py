"""
Fallback LLM Provider - 云端失败时自动降级到本地模型

使用场景：
- 游戏运行时优先用云端 API（推理能力强）
- 网络故障 / API 限流 / Key 过期时自动降级到本地 Ollama
- 用户选择"离线模式"时直接走本地

配置示例：
    from generic_causal_architecture.llm import create_llm_provider

    llm = create_llm_provider({
        "provider": "hybrid",
        "primary": {
            "provider": "openai",
            "api_key": "sk-...",
            "model": "gpt-4"
        },
        "fallback": {
            "provider": "ollama",
            "model": "qwen2.5:7b"
        }
    })

    # 正常情况走 OpenAI，失败时自动走 Ollama
    response = await llm.chat([{"role": "user", "content": "..."}])
"""

import logging
import time
from typing import Any, Dict, List, Optional

from ..provider import LLMProvider

logger = logging.getLogger(__name__)


class FallbackProvider(LLMProvider):
    """
    混合 LLM Provider - 主用云端，失败时降级到本地

    Args:
        primary: 主 LLM Provider（通常是云端 API）
        fallback: 备用 LLM Provider（通常是本地 Ollama）
        max_retries: 主 Provider 失败后重试次数（默认 1 次）
        retry_delay: 重试间隔秒数（默认 0）
        fallback_on_timeout: 超时是否触发降级（默认 True）
        fallback_on_error: 其他错误是否触发降级（默认 True）
    """

    def __init__(
        self,
        primary: LLMProvider,
        fallback: LLMProvider,
        max_retries: int = 1,
        retry_delay: float = 0,
        fallback_on_timeout: bool = True,
        fallback_on_error: bool = True,
        **kwargs,
    ):
        super().__init__(model=f"hybrid({primary.model}+{fallback.model})", **kwargs)
        self.primary = primary
        self.fallback = fallback
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.fallback_on_timeout = fallback_on_timeout
        self.fallback_on_error = fallback_on_error

        self._primary_calls = 0
        self._fallback_calls = 0
        self._primary_failures = 0

    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """先尝试主 Provider，失败则降级到备用 Provider。"""
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                result = await self.primary.chat(messages, **kwargs)
                self._primary_calls += 1
                if attempt > 0:
                    logger.info(f"Primary provider succeeded on attempt {attempt + 1}")
                return result
            except Exception as e:
                last_error = e
                self._primary_failures += 1
                error_type = type(e).__name__

                should_fallback = False
                if self.fallback_on_timeout and "timeout" in str(e).lower():
                    should_fallback = True
                elif self.fallback_on_error:
                    should_fallback = True

                if should_fallback and attempt < self.max_retries:
                    logger.warning(
                        f"Primary provider failed ({error_type}: {e}), "
                        f"retrying ({attempt + 1}/{self.max_retries})..."
                    )
                    if self.retry_delay > 0:
                        time.sleep(self.retry_delay)
                    continue
                elif should_fallback:
                    break
                else:
                    raise

        logger.warning(
            f"Primary provider failed after {self.max_retries + 1} attempts "
            f"({type(last_error).__name__}: {last_error}). "
            f"Falling back to {self.fallback.model}..."
        )

        try:
            result = await self.fallback.chat(messages, **kwargs)
            self._fallback_calls += 1
            return result
        except Exception as fallback_error:
            logger.error(
                f"Both providers failed. "
                f"Primary: {type(last_error).__name__}: {last_error}. "
                f"Fallback: {type(fallback_error).__name__}: {fallback_error}"
            )
            raise RuntimeError(
                f"Both providers failed. "
                f"Primary error: {last_error}. "
                f"Fallback error: {fallback_error}"
            ) from fallback_error

    async def complete(self, prompt: str, **kwargs) -> str:
        """先尝试主 Provider，失败则降级到备用 Provider。"""
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                result = await self.primary.complete(prompt, **kwargs)
                self._primary_calls += 1
                return result
            except Exception as e:
                last_error = e
                self._primary_failures += 1
                if self.fallback_on_error and attempt < self.max_retries:
                    logger.warning(
                        f"Primary provider complete() failed ({type(e).__name__}), "
                        f"retrying ({attempt + 1}/{self.max_retries})..."
                    )
                    if self.retry_delay > 0:
                        time.sleep(self.retry_delay)
                    continue
                elif self.fallback_on_error:
                    break
                else:
                    raise

        logger.warning(
            f"Primary provider failed, falling back to {self.fallback.model}"
        )

        try:
            result = await self.fallback.complete(prompt, **kwargs)
            self._fallback_calls += 1
            return result
        except Exception as fallback_error:
            raise RuntimeError(
                f"Both providers failed. "
                f"Primary: {last_error}. Fallback: {fallback_error}"
            ) from fallback_error

    def get_usage(self) -> Dict[str, Any]:
        """合并两个 Provider 的用量统计。"""
        primary_usage = self.primary.get_usage()
        fallback_usage = self.fallback.get_usage()

        total_cost = (
            primary_usage.get("cost_usd", 0) + fallback_usage.get("cost_usd", 0)
        )
        total_tokens = (
            primary_usage.get("total_tokens", 0)
            + fallback_usage.get("total_tokens", 0)
        )

        return {
            "provider": "hybrid",
            "primary": primary_usage,
            "fallback": fallback_usage,
            "primary_calls": self._primary_calls,
            "fallback_calls": self._fallback_calls,
            "primary_failures": self._primary_failures,
            "total_tokens": total_tokens,
            "cost_usd": total_cost,
        }

    async def close(self):
        """关闭两个 Provider 的资源。"""
        for provider in (self.primary, self.fallback):
            if hasattr(provider, "close") and callable(provider.close):
                try:
                    await provider.close()
                except Exception:
                    pass

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    def __repr__(self) -> str:
        return (
            f"FallbackProvider("
            f"primary={self.primary}, "
            f"fallback={self.fallback})"
        )
