"""
Anthropic Claude LLM Provider - Claude API 实现

支持模型：
- Claude-3-Opus
- Claude-3-Sonnet
- Claude-3-Haiku
- Claude-2.1

使用示例：
    from generic_causal_architecture.llm.providers.claude_provider import ClaudeProvider
    
    llm = ClaudeProvider(
        api_key="sk-ant-...",  # 用户自己的 API Key
        model="claude-3-opus-20240229"
    )
    
    response = await llm.chat([
        {"role": "user", "content": "分析秦朝灭亡的原因"}
    ])
"""

from typing import List, Dict, Any, Optional
import time
import os

from ..provider import LLMProvider


# Claude 模型价格（美元/1000 tokens）
# 来源：https://www.anthropic.com/pricing
CLAUDE_PRICES = {
    # Claude 3 系列
    "claude-3-opus": {"prompt": 0.015, "completion": 0.075},
    "claude-3-sonnet": {"prompt": 0.003, "completion": 0.015},
    "claude-3-haiku": {"prompt": 0.00025, "completion": 0.00125},
    
    # Claude 2 系列
    "claude-2": {"prompt": 0.008, "completion": 0.024},
    "claude-2.1": {"prompt": 0.008, "completion": 0.024},
    "claude-instant": {"prompt": 0.0008, "completion": 0.0024},
    
    # 默认价格
    "default": {"prompt": 0.003, "completion": 0.015}
}


class ClaudeProvider(LLMProvider):
    """
    Anthropic Claude LLM Provider
    
    使用用户提供的 API Key 调用 Claude API
    
    支持的环境变量：
    - ANTHROPIC_API_KEY: Claude API Key
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-3-sonnet-20240229",
        temperature: float = 0.7,
        max_tokens: int = 2000,
        **kwargs
    ):
        """
        初始化 Claude Provider
        
        Args:
            api_key: Claude API Key（可选，从环境变量读取）
            model: 模型名称
            temperature: 温度参数（0-1）
            max_tokens: 最大 token 数
            **kwargs: 其他参数
        """
        super().__init__(model=model, **kwargs)
        
        # 获取 API Key
        self.api_key = api_key or os.getenv("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise ValueError(
                "Claude API Key 未提供\n"
                "请设置 ANTHROPIC_API_KEY 环境变量或在配置中提供 api_key"
            )
        
        # API 配置
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # 初始化 Anthropic 客户端
        try:
            import anthropic
            self.client = anthropic.AsyncAnthropic(api_key=self.api_key)
        except ImportError:
            raise ImportError(
                "需要安装 anthropic 库：pip install anthropic"
            )
    
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """
        发送对话请求
        
        Claude API 的消息格式与 OpenAI 略有不同，需要转换
        """
        start_time = time.time()
        
        # 提取系统消息和用户消息
        system_message = ""
        chat_messages = []
        
        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            
            if role == "system":
                system_message = content
            elif role == "user":
                chat_messages.append({"role": "user", "content": content})
            elif role == "assistant":
                chat_messages.append({"role": "assistant", "content": content})
        
        # 如果没有消息，至少需要一个用户消息
        if not chat_messages:
            chat_messages.append({"role": "user", "content": "你好"})
        
        # 调用 Claude API
        response = await self.client.messages.create(
            model=self.model,
            max_tokens=kwargs.get("max_tokens", self.max_tokens),
            temperature=kwargs.get("temperature", self.temperature),
            system=system_message if system_message else anthropic.NOT_GIVEN,
            messages=chat_messages
        )
        
        # 计算延迟
        latency = time.time() - start_time
        
        # 提取回复内容
        content = response.content[0].text
        
        # 统计用量
        prompt_tokens = response.usage.input_tokens
        completion_tokens = response.usage.output_tokens
        
        # 计算费用
        cost = self._calculate_cost(prompt_tokens, completion_tokens)
        
        # 记录用量
        self._record_usage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency=latency,
            cost=cost
        )
        
        return content
    
    async def complete(self, prompt: str, **kwargs) -> str:
        """
        文本补全
        
        Claude 没有专门的补全 API，用对话模拟
        """
        messages = [{"role": "user", "content": prompt}]
        return await self.chat(messages, **kwargs)
    
    def get_usage(self) -> Dict[str, Any]:
        """获取用量统计"""
        usage_dict = self.usage.to_dict()
        usage_dict["provider"] = "anthropic"
        usage_dict["model"] = self.model
        return usage_dict
    
    def _calculate_cost(self, prompt_tokens: int, completion_tokens: int) -> float:
        """计算费用"""
        # 获取价格（支持模型别名）
        prices = self._get_prices()
        
        # 计算费用
        cost = (
            prompt_tokens * prices["prompt"] / 1000 +
            completion_tokens * prices["completion"] / 1000
        )
        
        return cost
    
    def _get_prices(self) -> Dict[str, float]:
        """获取当前模型的价格"""
        # 提取模型基础名称（去掉日期后缀）
        base_model = self.model.split("-20")[0]  # claude-3-opus-20240229 -> claude-3-opus
        
        # 查找价格
        for model_name, prices in CLAUDE_PRICES.items():
            if model_name in base_model or base_model in model_name:
                return prices
        
        return CLAUDE_PRICES["default"]
    
    def __repr__(self) -> str:
        return f"ClaudeProvider(model={self.model}, api_key={'*' * 12})"
