"""
Ollama LLM Provider - 本地模型实现

支持本地运行的大模型：
- Qwen（通义千问）
- Llama
- Mistral
- 以及其他 Ollama 支持的模型

优势：
- 完全免费（本地运行）
- 隐私保护（数据不出本地）
- 低延迟（无网络请求）
- 可离线使用

使用示例：
    from generic_causal_architecture.llm.providers.ollama_provider import OllamaProvider
    
    # 本地运行 Qwen 7B 模型
    llm = OllamaProvider(
        model="qwen:7b",
        base_url="http://localhost:11434"  # Ollama 服务地址
    )
    
    response = await llm.chat([
        {"role": "user", "content": "分析秦朝灭亡的原因"}
    ])
    
    # 本地模型免费
    usage = llm.get_usage()
    print(f"费用：${usage['cost_usd']}")  # $0
"""

from typing import List, Dict, Any, Optional
import time
import aiohttp
import os

from ..provider import LLMProvider


class OllamaProvider(LLMProvider):
    """
    Ollama 本地模型 Provider
    
    通过 Ollama 服务调用本地运行的大模型
    
    前置条件：
    1. 安装 Ollama：https://ollama.ai
    2. 下载模型：ollama pull qwen:7b
    3. 启动服务：ollama serve
    
    支持的环境变量：
    - OLLAMA_BASE_URL: Ollama 服务地址（默认：http://localhost:11434）
    """
    
    def __init__(
        self,
        model: str = "qwen:7b",
        base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2000,
        timeout: int = 120,
        **kwargs
    ):
        """
        初始化 Ollama Provider
        
        Args:
            model: 模型名称（如 qwen:7b, llama2:13b）
            base_url: Ollama 服务地址
            temperature: 温度参数
            max_tokens: 最大 token 数
            timeout: 请求超时（秒）
            **kwargs: 其他参数
        """
        super().__init__(model=model, **kwargs)
        
        # API 配置
        self.base_url = base_url or os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout = timeout
        
        # HTTP 会话
        self._session: Optional[aiohttp.ClientSession] = None
    
    async def _get_session(self) -> aiohttp.ClientSession:
        """获取或创建 HTTP 会话"""
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=self.timeout)
            )
        return self._session
    
    async def close(self):
        """关闭 HTTP 会话"""
        if self._session and not self._session.closed:
            await self._session.close()
    
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """
        发送对话请求
        
        Ollama API 文档：https://github.com/ollama/ollama/blob/main/docs/api.md
        """
        start_time = time.time()
        
        # 获取会话
        session = await self._get_session()
        
        # 构建请求
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,  # 不流式输出
            "options": {
                "temperature": kwargs.get("temperature", self.temperature),
                "num_predict": kwargs.get("max_tokens", self.max_tokens),
            }
        }
        
        # 发送请求
        try:
            async with session.post(
                f"{self.base_url}/api/chat",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama API 错误：{response.status} - {error_text}")
                
                result = await response.json()
        except aiohttp.ClientError as e:
            raise RuntimeError(
                f"无法连接到 Ollama 服务：{self.base_url}\n"
                f"请确保 Ollama 已安装并运行：ollama serve\n"
                f"错误：{e}"
            )
        
        # 计算延迟
        latency = time.time() - start_time
        
        # 提取回复内容
        content = result.get("message", {}).get("content", "")
        
        # 统计用量（Ollama 不提供 token 统计，估算）
        prompt_tokens = sum(len(msg["content"]) // 4 for msg in messages)
        completion_tokens = len(content) // 4
        total_tokens = prompt_tokens + completion_tokens
        
        # 本地模型免费
        cost = 0.0
        
        # 记录用量
        self._record_usage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency=latency,
            cost=cost
        )
        
        return content
    
    async def complete(self, prompt: str, **kwargs) -> str:
        """
        文本补全
        
        Ollama 的生成 API
        """
        start_time = time.time()
        
        session = await self._get_session()
        
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": kwargs.get("temperature", self.temperature),
                "num_predict": kwargs.get("max_tokens", self.max_tokens),
            }
        }
        
        try:
            async with session.post(
                f"{self.base_url}/api/generate",
                json=payload
            ) as response:
                if response.status != 200:
                    error_text = await response.text()
                    raise RuntimeError(f"Ollama API 错误：{response.status} - {error_text}")
                
                result = await response.json()
        except aiohttp.ClientError as e:
            raise RuntimeError(
                f"无法连接到 Ollama 服务：{self.base_url}\n"
                f"错误：{e}"
            )
        
        # 计算延迟
        latency = time.time() - start_time
        
        # 提取回复内容
        content = result.get("response", "")
        
        # 统计用量
        prompt_tokens = len(prompt) // 4
        completion_tokens = result.get("eval_count", len(content) // 4)
        
        # 本地模型免费
        cost = 0.0
        
        # 记录用量
        self._record_usage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency=latency,
            cost=cost
        )
        
        return content
    
    def get_usage(self) -> Dict[str, Any]:
        """获取用量统计"""
        usage_dict = self.usage.to_dict()
        usage_dict["provider"] = "ollama"
        usage_dict["model"] = self.model
        usage_dict["local"] = True
        usage_dict["cost_usd"] = 0.0  # 本地模型免费
        return usage_dict
    
    async def __aenter__(self):
        """异步上下文管理器"""
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """异步上下文管理器"""
        await self.close()
    
    def __repr__(self) -> str:
        return f"OllamaProvider(model={self.model}, base_url={self.base_url})"
