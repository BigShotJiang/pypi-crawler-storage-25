"""
OpenAI LLM Provider - OpenAI API 实现

支持模型：
- GPT-4
- GPT-3.5-Turbo
- GPT-4-Turbo
- 以及其他 OpenAI 兼容模型

使用示例：
    from generic_causal_architecture.llm.providers.openai_provider import OpenAIProvider
    
    llm = OpenAIProvider(
        api_key="sk-...",  # 用户自己的 API Key
        model="gpt-4"
    )
    
    response = await llm.chat([
        {"role": "user", "content": "分析秦朝灭亡的原因"}
    ])
    
    # 查看用量和费用
    usage = llm.get_usage()
    print(f"费用：${usage['cost_usd']}")
"""

from typing import List, Dict, Any, Optional
import time
import os

from ..provider import LLMProvider, TokenUsage


# OpenAI 模型价格（美元/1000 tokens）
# 来源：https://openai.com/pricing
OPENAI_PRICES = {
    # GPT-4 系列
    "gpt-4": {"prompt": 0.03, "completion": 0.06},
    "gpt-4-32k": {"prompt": 0.06, "completion": 0.12},
    "gpt-4-turbo": {"prompt": 0.01, "completion": 0.03},
    "gpt-4o": {"prompt": 0.005, "completion": 0.015},
    "gpt-4o-mini": {"prompt": 0.00015, "completion": 0.0006},
    
    # GPT-3.5 系列
    "gpt-3.5-turbo": {"prompt": 0.0005, "completion": 0.0015},
    "gpt-3.5-turbo-16k": {"prompt": 0.001, "completion": 0.002},
    
    # 默认价格（如果模型不在列表中）
    "default": {"prompt": 0.001, "completion": 0.002}
}


class OpenAIProvider(LLMProvider):
    """
    OpenAI LLM Provider
    
    使用用户提供的 API Key 调用 OpenAI API
    
    支持的环境变量：
    - OPENAI_API_KEY: OpenAI API Key
    - OPENAI_BASE_URL: API 基础 URL（可选，用于兼容其他服务）
    """
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "gpt-4",
        base_url: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 2000,
        **kwargs
    ):
        """
        初始化 OpenAI Provider
        
        Args:
            api_key: OpenAI API Key（可选，从环境变量读取）
            model: 模型名称（默认：gpt-4）
            base_url: API 基础 URL（可选，用于兼容其他服务）
            temperature: 温度参数（0-2）
            max_tokens: 最大 token 数
            **kwargs: 其他参数
        """
        super().__init__(model=model, **kwargs)
        
        # 获取 API Key（优先级：参数 > 环境变量）
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError(
                "OpenAI API Key 未提供\n"
                "请设置 OPENAI_API_KEY 环境变量或在配置中提供 api_key"
            )
        
        # API 配置
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL")
        self.temperature = temperature
        self.max_tokens = max_tokens
        
        # 初始化 OpenAI 客户端
        try:
            from openai import AsyncOpenAI
            self.client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url
            )
        except ImportError:
            raise ImportError(
                "需要安装 openai 库：pip install openai"
            )
    
    async def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        """
        发送对话请求
        
        Args:
            messages: 对话历史
            **kwargs: 其他参数（覆盖默认参数）
        
        Returns:
            AI 的回复内容
        """
        start_time = time.time()
        
        # 合并参数
        params = {
            "model": self.model,
            "messages": messages,
            "temperature": kwargs.get("temperature", self.temperature),
            "max_tokens": kwargs.get("max_tokens", self.max_tokens),
        }
        
        # 调用 API
        response = await self.client.chat.completions.create(**params)
        
        # 计算延迟
        latency = time.time() - start_time
        
        # 提取回复内容
        content = response.choices[0].message.content
        
        # 统计用量
        usage = response.usage
        prompt_tokens = usage.prompt_tokens
        completion_tokens = usage.completion_tokens
        
        # 计算费用
        cost = self._calculate_cost(prompt_tokens, completion_tokens)
        
        # 记录用量
        self._record_usage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency=latency,
            cost=cost
        )
        
        return content
    
    async def complete(self, prompt: str, **kwargs) -> str:
        """
        文本补全
        
        Args:
            prompt: 输入文本
            **kwargs: 其他参数
        
        Returns:
            补全的文本
        """
        # 将文本补全转换为对话格式
        messages = [{"role": "user", "content": prompt}]
        return await self.chat(messages, **kwargs)
    
    def get_usage(self) -> Dict[str, Any]:
        """获取用量统计"""
        usage_dict = self.usage.to_dict()
        usage_dict["provider"] = "openai"
        usage_dict["model"] = self.model
        return usage_dict
    
    def _calculate_cost(self, prompt_tokens: int, completion_tokens: int) -> float:
        """
        计算费用
        
        Args:
            prompt_tokens: 输入 token 数
            completion_tokens: 输出 token 数
        
        Returns:
            费用（美元）
        """
        # 获取价格
        prices = OPENAI_PRICES.get(self.model, OPENAI_PRICES["default"])
        
        # 计算费用
        cost = (
            prompt_tokens * prices["prompt"] / 1000 +
            completion_tokens * prices["completion"] / 1000
        )
        
        return cost
    
    def __repr__(self) -> str:
        return f"OpenAIProvider(model={self.model}, api_key={'*' * 12})"
