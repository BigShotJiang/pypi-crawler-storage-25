"""
SQLite 存储实现 - 用于中等规模数据和持久化存储

重要说明：
1. 这个实现使用 SQLite 数据库，数据自动持久化
2. 适合阶段 2-3 使用，支持百万级事件
3. 使用 networkx 作为图查询的补充（加载到内存）

性能特点：
- 读取速度：快（数据库索引）
- 写入速度：中等（磁盘 IO）
- 持久化：自动（数据库事务）
- 并发：支持（SQLite 有限并发）
- 规模限制：建议<1000 万事件

使用示例：
    storage = SQLiteStorage("data/causal.db")
    storage.initialize()
    storage.add_event(event_data)
    # 不需要手动保存，数据库自动持久化
"""

import sqlite3
import json
import os
import networkx as nx
from typing import Dict, List, Any, Optional
from .storage_interface import (
    StorageInterface, EventData, CausalRelation
)


class SQLiteStorage(StorageInterface):
    """
    SQLite 存储实现
    
    数据库结构：
    - events 表：存储事件数据
    - relations 表：存储因果关系
    - metadata 表：存储元数据
    
    注意：
    - 所有操作都是线程安全的（使用锁）
    - 数据自动保存（数据库事务）
    - 支持 SQL 查询（灵活高效）
    """
    
    def __init__(self, db_path: str = "data/causal.db"):
        """
        初始化 SQLite 存储
        
        参数:
            db_path: 数据库文件路径
        """
        self._db_path = db_path
        self._conn: Optional[sqlite3.Connection] = None
        self._graph_cache: Optional[nx.DiGraph] = None
        self._initialized = False
    
    def _get_connection(self) -> sqlite3.Connection:
        """获取数据库连接（线程安全）"""
        if self._conn is None:
            self._conn = sqlite3.connect(
                self._db_path,
                check_same_thread=False,  # 允许多线程
                timeout=30.0  # 锁等待超时
            )
            self._conn.row_factory = sqlite3.Row  # 返回字典式行
        return self._conn
    
    def initialize(self) -> None:
        """
        初始化数据库（创建表结构）
        
        注意：
        - 这个方法是幂等的（可以多次调用）
        - 如果表已存在，不会报错
        """
        if self._initialized:
            return
        
        # 确保目录存在
        os.makedirs(os.path.dirname(self._db_path) or '.', exist_ok=True)
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # 创建 events 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS events (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                timestamp_json TEXT NOT NULL,
                location TEXT,
                participants_json TEXT,
                description TEXT,
                event_type TEXT,
                metadata_json TEXT,
                evidence_sources_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建 relations 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS relations (
                source_id TEXT NOT NULL,
                target_id TEXT NOT NULL,
                relation_type TEXT NOT NULL,
                confidence REAL NOT NULL CHECK (confidence >= 0 AND confidence <= 1),
                evidence_json TEXT,
                reasoning_steps_json TEXT,
                metadata_json TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (source_id, target_id),
                FOREIGN KEY (source_id) REFERENCES events(id) ON DELETE CASCADE,
                FOREIGN KEY (target_id) REFERENCES events(id) ON DELETE CASCADE
            )
        ''')
        
        # 创建索引（加速查询）
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp_json)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_relations_type ON relations(relation_type)')
        
        # 创建 metadata 表
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS metadata (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
        ''')
        
        # 创建 knowledge 表（支持所有知识类型）
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS knowledge (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                knowledge_type TEXT NOT NULL,
                knowledge_json TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # 创建索引
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_knowledge_type ON knowledge(knowledge_type)')
        
        conn.commit()
        self._initialized = True
    
    def add_event(self, event: EventData) -> bool:
        """
        添加事件（UPSERT 语义）
        
        注意：
        - 如果事件 ID 已存在，会更新现有事件
        - 使用参数化查询防止 SQL 注入
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # 将复杂类型转换为 JSON
            timestamp_json = json.dumps(event.timestamp)
            participants_json = json.dumps(event.participants) if event.participants else None
            metadata_json = json.dumps(event.metadata) if event.metadata else None
            evidence_sources_json = json.dumps(event.evidence_sources) if event.evidence_sources else None
            
            # UPSERT（插入或更新）
            cursor.execute('''
                INSERT INTO events (
                    id, name, timestamp_json, location, participants_json,
                    description, event_type, metadata_json, evidence_sources_json,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    name = excluded.name,
                    timestamp_json = excluded.timestamp_json,
                    location = excluded.location,
                    participants_json = excluded.participants_json,
                    description = excluded.description,
                    event_type = excluded.event_type,
                    metadata_json = excluded.metadata_json,
                    evidence_sources_json = excluded.evidence_sources_json,
                    updated_at = CURRENT_TIMESTAMP
            ''', (
                event.id, event.name, timestamp_json, event.location,
                participants_json, event.description, event.event_type,
                metadata_json, evidence_sources_json
            ))
            
            conn.commit()
            
            # 清除图缓存（下次查询时重建）
            self._graph_cache = None
            
            return True
            
        except Exception as e:
            conn.rollback()
            print(f"Error adding event: {e}")
            return False
    
    def get_event(self, event_id: str) -> Optional[EventData]:
        """获取单个事件"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM events WHERE id = ?', (event_id,))
        row = cursor.fetchone()
        
        if row is None:
            return None
        
        return self._row_to_event(row)
    
    def delete_event(self, event_id: str) -> bool:
        """
        删除事件
        
        注意：
        - 会同时删除相关的因果关系（外键级联删除）
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute('DELETE FROM events WHERE id = ?', (event_id,))
            conn.commit()
            
            # 清除图缓存
            self._graph_cache = None
            
            return cursor.rowcount > 0
            
        except Exception as e:
            conn.rollback()
            print(f"Error deleting event: {e}")
            return False
    
    def add_causal_relation(self, relation: CausalRelation) -> bool:
        """添加因果关系（UPSERT 语义）"""
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            evidence_json = json.dumps(relation.evidence) if relation.evidence else None
            reasoning_steps_json = json.dumps(relation.reasoning_steps) if relation.reasoning_steps else None
            metadata_json = json.dumps(relation.metadata) if relation.metadata else None
            
            cursor.execute('''
                INSERT INTO relations (
                    source_id, target_id, relation_type, confidence,
                    evidence_json, reasoning_steps_json, metadata_json,
                    updated_at
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(source_id, target_id) DO UPDATE SET
                    relation_type = excluded.relation_type,
                    confidence = excluded.confidence,
                    evidence_json = excluded.evidence_json,
                    reasoning_steps_json = excluded.reasoning_steps_json,
                    metadata_json = excluded.metadata_json,
                    updated_at = CURRENT_TIMESTAMP
            ''', (
                relation.source_id, relation.target_id, relation.relation_type,
                relation.confidence, evidence_json, reasoning_steps_json, metadata_json
            ))
            
            conn.commit()
            
            # 清除图缓存
            self._graph_cache = None
            
            return True
            
        except Exception as e:
            conn.rollback()
            print(f"Error adding causal relation: {e}")
            return False
    
    def get_causal_relation(self, source_id: str, target_id: str) -> Optional[CausalRelation]:
        """获取因果关系"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM relations WHERE source_id = ? AND target_id = ?',
            (source_id, target_id)
        )
        row = cursor.fetchone()
        
        if row is None:
            return None
        
        return self._row_to_relation(row)
    
    def delete_causal_relation(self, source_id: str, target_id: str) -> bool:
        """删除因果关系"""
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                'DELETE FROM relations WHERE source_id = ? AND target_id = ?',
                (source_id, target_id)
            )
            conn.commit()
            
            # 清除图缓存
            self._graph_cache = None
            
            return cursor.rowcount > 0
            
        except Exception as e:
            conn.rollback()
            print(f"Error deleting causal relation: {e}")
            return False
    
    def get_causal_path(self, source_id: str, target_id: str, 
                       max_length: int = 10) -> List[str]:
        """
        查找因果路径
        
        实现说明：
        - 使用递归 CTE（Common Table Expression）查询路径
        - 如果找不到路径，返回空列表
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # 使用递归 CTE 查找路径
        cursor.execute('''
            WITH RECURSIVE causal_path(path, depth) AS (
                -- 基础情况：从 source 开始
                SELECT source_id || ',' || target_id, 1
                FROM relations
                WHERE source_id = ?
                
                UNION ALL
                
                -- 递归情况：扩展路径
                SELECT cp.path || ',' || r.target_id, cp.depth + 1
                FROM causal_path cp
                JOIN relations r ON r.source_id = (
                    SELECT value FROM (
                        SELECT cp.path as p
                    ), json_each('["' || replace(cp.path, ',', '","') || '"]')
                    WHERE key = json_array_length(json_each.key) - 1
                )
                WHERE cp.depth < ?
            )
            SELECT path FROM causal_path
            WHERE path LIKE '%,' || ?
            ORDER BY depth
            LIMIT 1
        ''', (source_id, max_length, target_id))
        
        row = cursor.fetchone()
        if row is None:
            return []
        
        return row[0].split(',')
    
    def get_influence_chain(self, event_id: str, direction: str = 'forward',
                           max_depth: int = 10) -> List[str]:
        """
        获取影响链
        
        实现说明：
        - 使用递归 CTE 遍历图
        - forward: 下游事件
        - backward: 上游事件（反转方向）
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        if direction == 'forward':
            cursor.execute('''
                WITH RECURSIVE influence_chain(event_id, depth) AS (
                    SELECT ?, 0
                    UNION ALL
                    SELECT r.target_id, ic.depth + 1
                    FROM influence_chain ic
                    JOIN relations r ON r.source_id = ic.event_id
                    WHERE ic.depth < ?
                )
                SELECT event_id FROM influence_chain
            ''', (event_id, max_depth))
        
        elif direction == 'backward':
            cursor.execute('''
                WITH RECURSIVE influence_chain(event_id, depth) AS (
                    SELECT ?, 0
                    UNION ALL
                    SELECT r.source_id, ic.depth + 1
                    FROM influence_chain ic
                    JOIN relations r ON r.target_id = ic.event_id
                    WHERE ic.depth < ?
                )
                SELECT event_id FROM influence_chain
            ''', (event_id, max_depth))
        
        else:
            raise ValueError(f"Invalid direction: {direction}")
        
        rows = cursor.fetchall()
        return [row[0] for row in rows]
    
    def get_all_events(self) -> List[EventData]:
        """获取所有事件"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM events')
        rows = cursor.fetchall()
        
        return [self._row_to_event(row) for row in rows]
    
    def get_all_relations(self) -> List[CausalRelation]:
        """获取所有因果关系"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM relations')
        rows = cursor.fetchall()
        
        return [self._row_to_relation(row) for row in rows]
    
    def query_events_by_time(self, start_time: Any, end_time: Any) -> List[EventData]:
        """
        按时间范围查询事件
        
        注意：
        - timestamp 存储为 JSON，需要特殊处理
        - 这里使用简单实现，实际可能需要更复杂的查询
        """
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM events')
        all_events = [self._row_to_event(row) for row in cursor.fetchall()]
        
        result = []
        for event in all_events:
            event_time = event.timestamp
            
            # 处理明确时间
            if isinstance(event_time, (int, float)):
                if start_time <= event_time <= end_time:
                    result.append(event)
            
            # 处理模糊时间
            elif isinstance(event_time, dict):
                event_start = event_time.get('start', float('inf'))
                event_end = event_time.get('end', float('-inf'))
                
                if event_start <= end_time and event_end >= start_time:
                    result.append(event)
        
        return result
    
    def query_events_by_type(self, event_type: str) -> List[EventData]:
        """按事件类型查询"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM events WHERE event_type = ?',
            (event_type,)
        )
        rows = cursor.fetchall()
        
        return [self._row_to_event(row) for row in rows]
    
    def search_events(
        self,
        query: str,
        domain: Optional[str] = None,
        event_type: Optional[str] = None,
        limit: int = 50
    ) -> List[EventData]:
        """
        搜索事件（使用 SQL LIKE 查询）
        
        生产级实现：
        1. 搜索标题、描述、地点
        2. 支持领域和类型过滤
        3. 按相关性排序
        4. 限制返回数量
        
        注意：SQLite 简单实现，生产环境可用 FTS5 全文搜索
        """
        if not query:
            return []
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # 构建查询（使用参数化查询防止 SQL 注入）
        search_pattern = f"%{query}%"
        
        # 基础查询
        sql = """
            SELECT * FROM events
            WHERE name LIKE ? OR description LIKE ? OR location LIKE ?
        """
        params = [search_pattern, search_pattern, search_pattern]
        
        # 领域过滤（从 metadata_json 中提取）
        if domain:
            sql += " AND json_extract(metadata_json, '$.domain') = ?"
            params.append(domain)
        
        # 类型过滤
        if event_type:
            sql += " AND event_type = ?"
            params.append(event_type)
        
        # 按相关性排序（简单实现：标题匹配优先）
        sql += """
            ORDER BY 
                CASE WHEN name LIKE ? THEN 1 ELSE 0 END DESC,
                CASE WHEN description LIKE ? THEN 1 ELSE 0 END DESC,
                updated_at DESC
            LIMIT ?
        """
        params.extend([search_pattern, search_pattern, limit])
        
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        
        return [self._row_to_event(row) for row in rows]
    
    def get_event_count(self) -> int:
        """获取事件总数"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM events')
        return cursor.fetchone()[0]
    
    def get_relation_count(self) -> int:
        """获取因果关系总数"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM relations')
        return cursor.fetchone()[0]
    
    def clear(self) -> None:
        """清空所有数据"""
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM relations')
        cursor.execute('DELETE FROM events')
        conn.commit()
        
        self._graph_cache = None
    
    def save(self, filepath: Optional[str] = None) -> str:
        """
        持久化保存（备份）
        
        注意：
        - SQLite 已经自动持久化，这个方法是创建备份
        """
        import shutil
        
        if filepath is None:
            filepath = self._db_path + ".backup"
        
        try:
            shutil.copy2(self._db_path, filepath)
            return filepath
        except Exception as e:
            print(f"Error saving backup: {e}")
            raise
    
    def load(self, filepath: str) -> bool:
        """
        从备份恢复
        
        注意：
        - 会覆盖当前数据库
        """
        import shutil
        
        if not os.path.exists(filepath):
            print(f"Backup file not found: {filepath}")
            return False
        
        try:
            # 关闭当前连接
            if self._conn:
                self._conn.close()
                self._conn = None
            
            # 复制备份
            shutil.copy2(filepath, self._db_path)
            
            # 重新连接
            self._get_connection()
            self._graph_cache = None
            
            return True
            
        except Exception as e:
            print(f"Error loading backup: {e}")
            return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        file_size = os.path.getsize(self._db_path) / (1024 * 1024)  # MB
        
        return {
            'event_count': self.get_event_count(),
            'relation_count': self.get_relation_count(),
            'storage_type': 'sqlite',
            'file_size_mb': round(file_size, 2),
            'db_path': self._db_path,
        }
    
    def close(self) -> None:
        """关闭数据库连接"""
        if self._conn:
            self._conn.close()
            self._conn = None
    
    # 辅助方法
    
    def _row_to_event(self, row: sqlite3.Row) -> EventData:
        """将数据库行转换为 EventData"""
        return EventData(
            id=row['id'],
            name=row['name'],
            timestamp=json.loads(row['timestamp_json']),
            location=row['location'],
            participants=json.loads(row['participants_json']) if row['participants_json'] else None,
            description=row['description'],
            event_type=row['event_type'],
            metadata=json.loads(row['metadata_json']) if row['metadata_json'] else None,
            evidence_sources=json.loads(row['evidence_sources_json']) if row['evidence_sources_json'] else None,
        )
    
    # =========================================================================
    # 知识单元扩展方法（支持所有知识类型）
    # =========================================================================
    
    def add_knowledge(self, knowledge: Any) -> bool:
        """
        添加知识单元到存储（实现 StorageInterface 接口）
        
        参数:
            knowledge: KnowledgeUnit 对象（可以是任何知识类型）
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            # 将复杂类型转换为 JSON
            knowledge_json = json.dumps(knowledge.to_dict())
            
            # UPSERT（插入或更新）
            cursor.execute('''
                INSERT INTO knowledge (
                    id, name, knowledge_type, knowledge_json,
                    updated_at
                )
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(id) DO UPDATE SET
                    name = excluded.name,
                    knowledge_type = excluded.knowledge_type,
                    knowledge_json = excluded.knowledge_json,
                    updated_at = CURRENT_TIMESTAMP
            ''', (
                knowledge.id, knowledge.name, knowledge.knowledge_type.value,
                knowledge_json
            ))
            
            conn.commit()
            return True
            
        except Exception as e:
            conn.rollback()
            print(f"Error adding knowledge: {e}")
            return False
    
    def get_knowledge(self, knowledge_id: str) -> Optional[Any]:
        """
        获取单个知识单元
        
        参数:
            knowledge_id: 知识 ID
        
        返回:
            KnowledgeUnit 对象，如果不存在返回 None
        """
        from ..knowledge import KnowledgeUnit
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM knowledge WHERE id = ?',
            (knowledge_id,)
        )
        row = cursor.fetchone()
        
        if not row:
            return None
        
        knowledge_json = json.loads(row['knowledge_json'])
        return KnowledgeUnit.from_dict(knowledge_json)
    
    def update_knowledge(self, knowledge: Any) -> bool:
        """
        更新知识单元
        
        参数:
            knowledge: KnowledgeUnit 对象（包含更新后的数据）
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        return self.add_knowledge(knowledge)  # UPSERT 语义
    
    def delete_knowledge(self, knowledge_id: str) -> bool:
        """
        删除知识单元
        
        参数:
            knowledge_id: 知识 ID
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        try:
            cursor.execute(
                'DELETE FROM knowledge WHERE id = ?',
                (knowledge_id,)
            )
            conn.commit()
            return cursor.rowcount > 0
            
        except Exception as e:
            conn.rollback()
            print(f"Error deleting knowledge: {e}")
            return False
    
    def query_knowledge_by_type(
        self,
        knowledge_type: str,
        limit: int = 100
    ) -> List[Any]:
        """
        按知识类型查询
        
        参数:
            knowledge_type: 知识类型（KnowledgeType 的 value）
            limit: 返回数量限制
        
        返回:
            KnowledgeUnit 对象列表
        """
        from ..knowledge import KnowledgeUnit
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM knowledge WHERE knowledge_type = ? LIMIT ?',
            (knowledge_type, limit)
        )
        rows = cursor.fetchall()
        
        return [
            KnowledgeUnit.from_dict(json.loads(row['knowledge_json']))
            for row in rows
        ]
    
    def search_knowledge(
        self,
        query: str,
        knowledge_type: Optional[str] = None,
        limit: int = 50
    ) -> List[Any]:
        """
        搜索知识（使用 SQL LIKE 查询）
        
        参数:
            query: 搜索关键词
            knowledge_type: 知识类型过滤（可选）
            limit: 返回数量限制
        
        返回:
            KnowledgeUnit 对象列表
        """
        from ..knowledge import KnowledgeUnit
        
        if not query:
            return []
        
        conn = self._get_connection()
        cursor = conn.cursor()
        
        search_pattern = f"%{query}%"
        
        sql = """
            SELECT * FROM knowledge
            WHERE name LIKE ? OR content LIKE ?
        """
        params = [search_pattern, search_pattern]
        
        if knowledge_type:
            sql += " AND knowledge_type = ?"
            params.append(knowledge_type)
        
        sql += " LIMIT ?"
        params.append(limit)
        
        cursor.execute(sql, params)
        rows = cursor.fetchall()
        
        return [
            KnowledgeUnit.from_dict(json.loads(row['knowledge_json']))
            for row in rows
        ]
    
    def get_knowledge_count(self) -> int:
        """获取知识总数"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT COUNT(*) FROM knowledge')
        return cursor.fetchone()[0]
    
    def get_knowledge_statistics(self) -> Dict[str, Any]:
        """获取知识统计信息"""
        conn = self._get_connection()
        cursor = conn.cursor()
        
        # 按类型统计
        cursor.execute('''
            SELECT knowledge_type, COUNT(*) as count
            FROM knowledge
            GROUP BY knowledge_type
        ''')
        by_type = {row['knowledge_type']: row['count'] for row in cursor.fetchall()}
        
        # 平均置信度
        cursor.execute('''
            SELECT AVG(json_extract(knowledge_json, '$.confidence')) as avg_confidence
            FROM knowledge
        ''')
        avg_confidence = cursor.fetchone()['avg_confidence'] or 0.0
        
        return {
            'total_count': self.get_knowledge_count(),
            'by_type': by_type,
            'avg_confidence': round(avg_confidence, 3),
        }
    
    async def commit(self) -> None:
        """
        提交当前事务
        
        说明：
        - SQLite 支持事务，但当前实现是自动提交的
        - 每个操作（add_event, add_knowledge 等）都会自动 commit
        - 这个方法是为了满足 StorageInterface 接口要求
        
        注意：
        - 未来可以实现批量操作 + 显式提交
        - 当前是空实现
        """
        # TODO: 实现显式事务管理（当前每个操作自动提交）
        pass
    
    async def rollback(self) -> None:
        """
        回滚当前事务
        
        说明：
        - SQLite 支持事务回滚
        - 当前实现是自动提交的，无法回滚
        - 用于错误恢复
        
        注意：
        - 未来可以实现批量操作 + 显式回滚
        - 当前会记录警告日志
        """
        # TODO: 实现显式事务回滚
        import logging
        logger = logging.getLogger(__name__)
        logger.warning("SQLiteStorage.rollback() called but not yet implemented for auto-commit mode")
        pass
    
    def _row_to_relation(self, row: sqlite3.Row) -> CausalRelation:
        """将数据库行转换为 CausalRelation"""
        return CausalRelation(
            source_id=row['source_id'],
            target_id=row['target_id'],
            relation_type=row['relation_type'],
            confidence=row['confidence'],
            evidence=json.loads(row['evidence_json']) if row['evidence_json'] else None,
            reasoning_steps=json.loads(row['reasoning_steps_json']) if row['reasoning_steps_json'] else None,
            metadata=json.loads(row['metadata_json']) if row['metadata_json'] else None,
        )
