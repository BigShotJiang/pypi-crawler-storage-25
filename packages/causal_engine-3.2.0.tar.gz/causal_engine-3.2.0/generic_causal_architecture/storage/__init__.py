"""
Storage module - 存储层

提供统一的存储接口和多种实现：
- StorageInterface: 抽象接口（所有存储实现必须遵循）
- MemoryStorage: 内存实现（开发、测试、小规模）
- SQLiteStorage: SQLite 实现（中等规模、持久化）
- PostgreSQLStorage: PostgreSQL 实现（生产级、支持图查询）

使用示例：
    from generic_causal_architecture.storage import (
        MemoryStorage, SQLiteStorage, PostgreSQLStorage, Config
    )
    
    # 从配置加载
    config = Config.from_yaml("config.yaml")
    storage = config.get_storage()
    
    # 或直接创建
    storage = PostgreSQLStorage(database_url="postgresql://...")
"""

from .storage_interface import StorageInterface, EventData, CausalRelation
from .memory_storage import MemoryStorage
from .sqlite_storage import SQLiteStorage
from .postgresql_storage import PostgreSQLStorage

__all__ = [
    'StorageInterface',
    'EventData',
    'CausalRelation',
    'MemoryStorage',
    'SQLiteStorage',
    'PostgreSQLStorage',
]
