"""
内存存储实现 - 用于开发、测试和小规模数据

重要说明：
1. 这个实现使用纯内存结构（dict + networkx），不需要数据库
2. 数据持久化通过 pickle 实现（保存/加载）
3. 适合阶段 1-2 使用，或者作为其他实现的参考

性能特点：
- 读取速度：极快（内存访问）
- 写入速度：快
- 持久化：需要手动保存
- 并发：不支持（单线程）
- 规模限制：受内存大小限制（建议<10 万事件）

使用示例：
    storage = MemoryStorage()
    storage.initialize()
    storage.add_event(event_data)
    storage.save("data.pkl")  # 手动保存
"""

import networkx as nx
import pickle
import os
import uuid as _uuid
from datetime import datetime as _datetime
from typing import Dict, List, Any, Optional, Tuple
from .storage_interface import (
    StorageInterface, EventData, CausalRelation
)


class MemoryStorage(StorageInterface):
    """
    内存存储实现
    
    数据结构：
    - events: Dict[str, EventData] - 事件字典
    - graph: nx.DiGraph - 因果图（有向图）
    - relations: Dict[Tuple[str, str], CausalRelation] - 关系字典
    
    注意：
    - 所有操作都是线程不安全的（单线程使用）
    - 数据不会自动保存，需要手动调用 save()
    - 适合快速原型开发和测试
    """
    
    def __init__(self, auto_save: bool = False, save_path: str = "data/memory_storage.pkl"):
        """
        初始化内存存储
        
        参数:
            auto_save: 是否自动保存（每次写入后自动保存）
            save_path: 自动保存的路径
        """
        self._events: Dict[str, EventData] = {}
        self._graph: nx.DiGraph = nx.DiGraph()
        self._relations: Dict[tuple, CausalRelation] = {}
        self._knowledge: Dict[str, Any] = {}
        self._entities: Dict[str, Dict[str, Any]] = {}
        self._entity_by_name: Dict[str, str] = {}
        self._entity_relations: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
        self._initialized = False
        self._auto_save = auto_save
        self._save_path = save_path
    
    def initialize(self) -> None:
        """
        初始化存储
        
        注意：
        - 内存存储不需要创建表结构
        - 这个方法主要是标记初始化完成
        """
        self._initialized = True
    
    def add_event(self, event: EventData) -> bool:
        """
        添加事件（实现 StorageInterface 接口）
        
        注意：
        - 如果事件 ID 已存在，会更新现有事件
        - 同时更新 events 字典和 graph 节点
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        try:
            # 添加到事件字典
            self._events[event.id] = event
            
            # 添加到图（作为节点）
            if not self._graph.has_node(event.id):
                self._graph.add_node(
                    event.id,
                    name=event.name,
                    timestamp=event.timestamp,
                    event_type=event.event_type
                )
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error adding event: {e}")
            return False
    
    def get_event(self, event_id: str) -> Optional[EventData]:
        """获取单个事件"""
        return self._events.get(event_id)
    
    def delete_event(self, event_id: str) -> bool:
        """
        删除事件
        
        注意：
        - 会同时删除相关的因果关系
        - 会同时从图和字典中删除
        """
        if event_id not in self._events:
            return False
        
        try:
            # 删除所有相关的关系
            relations_to_delete = [
                key for key in self._relations.keys()
                if key[0] == event_id or key[1] == event_id
            ]
            for key in relations_to_delete:
                del self._relations[key]
            
            # 从图中删除节点（会自动删除相关的边）
            self._graph.remove_node(event_id)
            
            # 从事件字典删除
            del self._events[event_id]
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error deleting event: {e}")
            return False
    
    def add_causal_relation(self, relation: CausalRelation) -> bool:
        """
        添加因果关系
        
        注意：
        - 会验证 source 和 target 事件存在
        - 会同时更新 relations 字典和 graph 边
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        # 验证事件存在
        if relation.source_id not in self._events:
            print(f"Source event {relation.source_id} not found")
            return False
        
        if relation.target_id not in self._events:
            print(f"Target event {relation.target_id} not found")
            return False
        
        # 验证置信度
        if not (0.0 <= relation.confidence <= 1.0):
            print(f"Invalid confidence: {relation.confidence}")
            return False
        
        try:
            key = (relation.source_id, relation.target_id)
            self._relations[key] = relation
            
            # 添加到图（作为边）
            if not self._graph.has_edge(relation.source_id, relation.target_id):
                self._graph.add_edge(
                    relation.source_id,
                    relation.target_id,
                    type=relation.relation_type,
                    confidence=relation.confidence
                )
            else:
                # 更新现有边的属性
                self._graph[relation.source_id][relation.target_id].update({
                    'type': relation.relation_type,
                    'confidence': relation.confidence
                })
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error adding causal relation: {e}")
            return False
    
    def get_causal_relation(self, source_id: str, target_id: str) -> Optional[CausalRelation]:
        """获取单个因果关系"""
        key = (source_id, target_id)
        return self._relations.get(key)
    
    def delete_causal_relation(self, source_id: str, target_id: str) -> bool:
        """删除因果关系"""
        key = (source_id, target_id)
        if key not in self._relations:
            return False
        
        try:
            del self._relations[key]
            
            # 从图中删除边
            if self._graph.has_edge(source_id, target_id):
                self._graph.remove_edge(source_id, target_id)
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error deleting causal relation: {e}")
            return False
    
    def get_causal_path(self, source_id: str, target_id: str, 
                       max_length: int = 10) -> List[str]:
        """
        查找因果路径
        
        实现说明：
        - 使用 networkx 的 shortest_path 算法
        - 如果有多条路径，返回最短的
        - 如果没有路径，返回空列表
        """
        if not self._graph.has_node(source_id) or not self._graph.has_node(target_id):
            return []
        
        try:
            path = nx.shortest_path(
                self._graph,
                source=source_id,
                target=target_id
            )
            # 检查路径长度
            if len(path) > max_length:
                return []
            return path
        except nx.NetworkXNoPath:
            return []
        except Exception as e:
            print(f"Error finding causal path: {e}")
            return []
    
    def get_influence_chain(self, event_id: str, direction: str = 'forward',
                           max_depth: int = 10) -> List[str]:
        """
        获取影响链
        
        实现说明：
        - forward: 使用 DFS 获取所有下游事件
        - backward: 反转图后使用 DFS 获取所有上游事件
        """
        if not self._graph.has_node(event_id):
            return []
        
        try:
            if direction == 'forward':
                # 获取所有可达节点（下游）
                nodes = nx.dfs_postorder_nodes(
                    self._graph,
                    source=event_id,
                    depth_limit=max_depth
                )
            elif direction == 'backward':
                # 反转图，获取所有上游
                reversed_graph = self._graph.reverse()
                nodes = nx.dfs_preorder_nodes(
                    reversed_graph,
                    source=event_id,
                    depth_limit=max_depth
                )
            else:
                raise ValueError(f"Invalid direction: {direction}")
            
            return list(nodes)
            
        except Exception as e:
            print(f"Error getting influence chain: {e}")
            return []
    
    def get_all_events(self) -> List[EventData]:
        """获取所有事件"""
        return list(self._events.values())
    
    def get_all_relations(self) -> List[CausalRelation]:
        """获取所有因果关系"""
        return list(self._relations.values())
    
    def query_events_by_time(self, start_time: Any, end_time: Any) -> List[EventData]:
        """
        按时间范围查询事件
        
        实现说明：
        - 支持明确时间（int/float）
        - 支持模糊时间（dict，包含 start/end）
        """
        result = []
        
        for event in self._events.values():
            event_time = event.timestamp
            
            # 处理明确时间
            if isinstance(event_time, (int, float)):
                if start_time <= event_time <= end_time:
                    result.append(event)
            
            # 处理模糊时间（dict）
            elif isinstance(event_time, dict):
                event_start = event_time.get('start', float('inf'))
                event_end = event_time.get('end', float('-inf'))
                
                # 检查时间范围是否有重叠
                if event_start <= end_time and event_end >= start_time:
                    result.append(event)
        
        # 按时间排序
        result.sort(key=lambda e: (
            e.timestamp if isinstance(e.timestamp, (int, float))
            else e.timestamp.get('start', 0) if isinstance(e.timestamp, dict)
            else 0
        ))
        
        return result
    
    def query_events_by_type(self, event_type: str) -> List[EventData]:
        """按事件类型查询"""
        return [
            event for event in self._events.values()
            if event.event_type == event_type
        ]
    
    def search_events(
        self,
        query: str,
        domain: Optional[str] = None,
        event_type: Optional[str] = None,
        limit: int = 50
    ) -> List[EventData]:
        """
        搜索事件（简单字符串匹配）
        
        生产级实现：
        1. 搜索标题、描述、地点
        2. 按相关性排序（匹配度）
        3. 支持类型过滤
        4. 限制返回数量
        """
        if not query:
            return []
        
        query_lower = query.lower()
        results = []
        
        for event in self._events.values():
            # 领域过滤
            if domain and event.metadata.get('domain') != domain:
                continue
            
            # 类型过滤
            if event_type and event.event_type != event_type:
                continue
            
            # 关键词匹配（标题、描述、地点）
            match_score = 0
            
            # 标题匹配（权重最高）
            if query_lower in event.name.lower():
                match_score += 3
            
            # 描述匹配
            if event.description and query_lower in event.description.lower():
                match_score += 2
            
            # 地点匹配
            if event.location and query_lower in event.location.lower():
                match_score += 1
            
            # 参与者匹配
            if event.participants:
                for participant in event.participants:
                    if query_lower in participant.lower():
                        match_score += 1
                        break
            
            # 只有匹配的事件才加入结果
            if match_score > 0:
                results.append((match_score, event))
        
        # 按相关性排序（降序）
        results.sort(key=lambda x: x[0], reverse=True)
        
        # 返回前 limit 个
        return [event for _, event in results[:limit]]
    
    def get_event_count(self) -> int:
        """获取事件总数"""
        return len(self._events)
    
    def get_relation_count(self) -> int:
        """获取因果关系总数"""
        return len(self._relations)
    
    def clear(self) -> None:
        """清空所有数据"""
        self._events.clear()
        self._graph.clear()
        self._relations.clear()
    
    def save(self, filepath: Optional[str] = None) -> str:
        """
        持久化保存到文件
        
        实现说明：
        - 使用 pickle 序列化
        - 保存 events、graph 结构、relations
        - 不保存 graph 对象本身（重新构建）
        """
        if filepath is None:
            filepath = self._save_path
        
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
            
            # 准备保存的数据
            data = {
                'events': self._events,
                'graph_nodes': list(self._graph.nodes(data=True)),
                'graph_edges': list(self._graph.edges(data=True)),
                'relations': self._relations,
                'knowledge': self._knowledge,  # 新增：保存知识
            }
            
            # 保存
            with open(filepath, 'wb') as f:
                pickle.dump(data, f)
            
            return filepath
            
        except Exception as e:
            print(f"Error saving storage: {e}")
            raise
    
    def load(self, filepath: str) -> bool:
        """
        从文件加载数据
        
        实现说明：
        - 先清空当前数据
        - 重新构建图结构
        """
        if not os.path.exists(filepath):
            print(f"File not found: {filepath}")
            return False
        
        try:
            # 清空当前数据
            self.clear()
            
            # 加载数据
            with open(filepath, 'rb') as f:
                data = pickle.load(f)
            
            # 恢复事件
            self._events = data.get('events', {})
            
            # 恢复关系
            self._relations = data.get('relations', {})
            
            # 恢复知识
            self._knowledge = data.get('knowledge', {})
            
            # 重建图
            self._graph.add_nodes_from(data.get('graph_nodes', []))
            self._graph.add_edges_from(data.get('graph_edges', []))
            
            self._initialized = True
            return True
            
        except Exception as e:
            print(f"Error loading storage: {e}")
            return False
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        import sys
        
        # 估算内存使用
        memory_usage = (
            sys.getsizeof(self._events) +
            sys.getsizeof(self._graph) +
            sys.getsizeof(self._relations) +
            sys.getsizeof(self._knowledge)  # 新增：知识内存
        ) / (1024 * 1024)  # 转换为 MB
        
        return {
            'event_count': len(self._events),
            'relation_count': len(self._relations),
            'knowledge_count': len(self._knowledge),  # 新增：知识数量
            'storage_type': 'memory',
            'memory_usage_mb': round(memory_usage, 2),
            'graph_density': nx.density(self._graph) if self._graph.number_of_nodes() > 0 else 0,
            'auto_save_enabled': self._auto_save,
            'save_path': self._save_path,
        }
    
    def close(self) -> None:
        """
        关闭存储
        
        注意：
        - 内存存储不需要关闭连接
        - 如果启用了自动保存，会在关闭前保存一次
        """
        if self._auto_save:
            self.save()
    
    # =========================================================================
    # 图查询扩展方法（实现 StorageInterface）
    # =========================================================================
    
    def get_relations_by_source(self, source_id: str) -> List[CausalRelation]:
        """
        根据源事件 ID 获取所有关系（出边）
        """
        relations = []
        for (src, _), relation in self._relations.items():
            if src == source_id:
                relations.append(relation)
        
        # 按置信度排序
        relations.sort(key=lambda r: r.confidence, reverse=True)
        return relations
    
    def get_relations_by_target(self, target_id: str) -> List[CausalRelation]:
        """
        根据目标事件 ID 获取所有关系（入边）
        """
        relations = []
        for (_, tgt), relation in self._relations.items():
            if tgt == target_id:
                relations.append(relation)
        
        # 按置信度排序
        relations.sort(key=lambda r: r.confidence, reverse=True)
        return relations
    
    def get_neighbors(self, event_id: str) -> Dict[str, List[CausalRelation]]:
        """
        获取事件的所有邻居（入边和出边）
        """
        return {
            'incoming': self.get_relations_by_target(event_id),
            'outgoing': self.get_relations_by_source(event_id),
        }
    
    # =========================================================================
    # 知识单元扩展方法（实现 StorageInterface 的知识方法）
    # =========================================================================
    
    def add_knowledge(self, knowledge: Any) -> bool:
        """
        添加知识单元到存储（实现 StorageInterface 接口）
        
        参数:
            knowledge: KnowledgeUnit 对象（可以是任何知识类型）
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        if not self._initialized:
            raise RuntimeError("Storage not initialized. Call initialize() first.")
        
        try:
            # 使用知识 ID 作为键
            self._knowledge[knowledge.id] = knowledge
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error adding knowledge: {e}")
            return False
    
    def get_knowledge(self, knowledge_id: str) -> Optional[Any]:
        """
        获取单个知识单元
        
        参数:
            knowledge_id: 知识 ID
        
        返回:
            KnowledgeUnit 对象，如果不存在返回 None
        """
        return self._knowledge.get(knowledge_id)
    
    def update_knowledge(self, knowledge: Any) -> bool:
        """
        更新知识单元
        
        参数:
            knowledge: KnowledgeUnit 对象（包含更新后的数据）
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        if knowledge.id not in self._knowledge:
            return False
        
        try:
            self._knowledge[knowledge.id] = knowledge
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error updating knowledge: {e}")
            return False
    
    def delete_knowledge(self, knowledge_id: str) -> bool:
        """
        删除知识单元
        
        参数:
            knowledge_id: 知识 ID
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        if knowledge_id not in self._knowledge:
            return False
        
        try:
            del self._knowledge[knowledge_id]
            
            # 自动保存
            if self._auto_save:
                self.save()
            
            return True
            
        except Exception as e:
            print(f"Error deleting knowledge: {e}")
            return False
    
    def search_knowledge(
        self,
        query: str,
        knowledge_type: Optional[str] = None,
        limit: int = 50
    ) -> List[Any]:
        """
        搜索知识（简单字符串匹配）
        
        参数:
            query: 搜索关键词
            knowledge_type: 知识类型过滤（可选）
            limit: 最大返回数量（默认 50）
        
        返回:
            KnowledgeUnit 列表，按相关性排序
        """
        if not query:
            return []
        
        query_lower = query.lower()
        results = []
        
        for knowledge in self._knowledge.values():
            # 类型过滤
            if knowledge_type and knowledge.knowledge_type.value != knowledge_type:
                continue
            
            # 关键词匹配（名称、内容）
            match_score = 0
            
            # 名称匹配（权重最高）
            if query_lower in knowledge.name.lower():
                match_score += 3
            
            # 内容匹配
            if knowledge.content and query_lower in knowledge.content.lower():
                match_score += 2
            
            # 只有匹配的知识才加入结果
            if match_score > 0:
                results.append((match_score, knowledge))
        
        # 按相关性排序（降序）
        results.sort(key=lambda x: x[0], reverse=True)
        
        # 返回前 limit 个
        return [knowledge for _, knowledge in results[:limit]]
    
    def get_knowledge_by_type(self, knowledge_type: str) -> List[Any]:
        """
        按知识类型查询
        
        参数:
            knowledge_type: 知识类型（如 "event", "theory", "method" 等）
        
        返回:
            KnowledgeUnit 列表
        """
        return [
            knowledge for knowledge in self._knowledge.values()
            if knowledge.knowledge_type.value == knowledge_type
        ]
    
    def get_knowledge_count(self) -> int:
        """
        获取知识单元总数
        
        返回:
            int: 知识单元数量
        """
        return len(self._knowledge)
    
    def get_knowledge_statistics(self) -> Dict[str, Any]:
        """
        获取知识统计信息
        
        返回:
            dict: 包含统计信息的字典
        """
        from collections import defaultdict
        
        # 按类型统计
        by_type = defaultdict(int)
        by_verification = defaultdict(int)
        total_confidence = 0.0
        
        for knowledge in self._knowledge.values():
            by_type[knowledge.knowledge_type.value] += 1
            by_verification[knowledge.verification_status.value] += 1
            total_confidence += knowledge.confidence
        
        avg_confidence = total_confidence / len(self._knowledge) if self._knowledge else 0.0
        
        return {
            'total_count': len(self._knowledge),
            'by_type': dict(by_type),
            'by_verification_status': dict(by_verification),
            'avg_confidence': round(avg_confidence, 2),
        }
    
    async def commit(self) -> None:
        """
        提交事务（内存存储不需要，空实现）
        
        说明：
        - 内存存储的数据修改是立即生效的，不需要显式提交
        - 这个方法是为了满足 StorageInterface 接口要求
        - 对于生产环境，建议使用 SQLiteStorage 或 PostgreSQLStorage
        """
        pass
    
    async def rollback(self) -> None:
        """
        回滚事务（内存存储不支持，空实现）
        
        说明：
        - 内存存储不支持事务回滚
        - 如果需要回滚功能，建议使用 SQLiteStorage 或 PostgreSQLStorage
        - 这个方法是为了满足 StorageInterface 接口要求
        """
        pass

    # ============ 实体级操作 ============

    def ensure_entity(self, name: str, entity_type: str = "action_entity",
                      description: str = "") -> str:
        if name in self._entity_by_name:
            return self._entity_by_name[name]

        entity_id = str(_uuid.uuid4())
        self._entities[entity_id] = {
            "id": entity_id,
            "canonical_name": name,
            "entity_type": entity_type,
            "description": description,
        }
        self._entity_by_name[name] = entity_id
        return entity_id

    def add_entity_relation(self, source_name: str, target_name: str,
                            relation_type: str, confidence: float,
                            metadata: Optional[Dict[str, Any]] = None) -> bool:
        key = (source_name, target_name, relation_type)
        if key in self._entity_relations:
            return False

        self.ensure_entity(source_name)
        self.ensure_entity(target_name)

        self._entity_relations[key] = {
            "source": source_name,
            "target": target_name,
            "relation_type": relation_type,
            "confidence": confidence,
            "metadata": metadata or {},
        }
        return True

    def find_entity_relation(self, source_name: str, target_name: str,
                             relation_type: str) -> Optional[Dict[str, Any]]:
        key = (source_name, target_name, relation_type)
        rel = self._entity_relations.get(key)
        if rel:
            return {"id": key, "confidence": rel["confidence"]}
        return None

    def update_relation_confidence(self, source_name: str, target_name: str,
                                   relation_type: str, new_confidence: float) -> bool:
        key = (source_name, target_name, relation_type)
        if key not in self._entity_relations:
            return False
        self._entity_relations[key]["confidence"] = round(new_confidence, 3)
        return True

    def find_conflicting_relations(self, source_name: str, target_name: str,
                                   relation_type: str) -> List[Dict[str, Any]]:
        contradictory = {
            "causes": ["prevents"],
            "prevents": ["causes"],
            "enables": ["prevents"],
            "correlates": [],
        }
        conflicting_types = contradictory.get(relation_type, [])
        results = []
        for ct in conflicting_types:
            key = (source_name, target_name, ct)
            if key in self._entity_relations:
                rel = self._entity_relations[key]
                results.append({
                    "relation_type": rel["relation_type"],
                    "confidence": rel["confidence"],
                })
        return results

    def search_entity_relations(self, keyword: str,
                                limit: int = 20) -> List[Dict[str, Any]]:
        results = []
        for (src, tgt, rt), rel in self._entity_relations.items():
            if keyword.lower() in src.lower() or keyword.lower() in tgt.lower():
                results.append({
                    "source": src,
                    "target": tgt,
                    "relation_type": rt,
                    "confidence": rel["confidence"],
                })
                if len(results) >= limit:
                    break
        return results

    def load_rules(self, filepath: str) -> Dict[str, Any]:
        """
        Load a rule pack JSON file into MemoryStorage.

        Populates _entities, _entity_by_name, and _entity_relations from the
        exported JSON so that CausalEngine can reason over the rules without
        a database.

        Args:
            filepath: path to a rule pack JSON file (see export_rules.py)

        Returns:
            dict with loading statistics: {"entities": int, "relations": int, "meta_patterns": int}
        """
        import json as _json

        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Rule pack file not found: {filepath}")

        with open(filepath, "r", encoding="utf-8") as f:
            data = _json.load(f)

        version = data.get("version", "unknown")
        if version not in ("1.0",):
            print(f"WARNING: Unknown rule pack version: {version}, attempting to load anyway")

        entities_loaded = 0
        for ent in data.get("entities", []):
            name = ent["name"]
            if name in self._entity_by_name:
                continue
            entity_id = str(_uuid.uuid4())
            self._entities[entity_id] = {
                "id": entity_id,
                "canonical_name": name,
                "entity_type": ent.get("type", "action_entity"),
                "description": ent.get("description", ""),
            }
            self._entity_by_name[name] = entity_id
            entities_loaded += 1

        relations_loaded = 0
        for rel in data.get("relations", []):
            source = rel["source"]
            target = rel["target"]
            relation_type = rel["relation_type"]
            confidence = float(rel.get("confidence", 0.5))
            key = (source, target, relation_type)
            if key in self._entity_relations:
                continue

            self.ensure_entity(source)
            self.ensure_entity(target)

            metadata = {}
            if "conditions" in rel:
                metadata["conditions"] = rel["conditions"]

            self._entity_relations[key] = {
                "source": source,
                "target": target,
                "relation_type": relation_type,
                "confidence": confidence,
                "metadata": metadata,
            }
            relations_loaded += 1

        meta_count = len(data.get("meta_patterns", []))

        if not self._initialized:
            self._initialized = True

        stats = {
            "entities": entities_loaded,
            "relations": relations_loaded,
            "meta_patterns": meta_count,
        }
        print(
            f"Loaded rule pack from {filepath}: "
            f"{entities_loaded} entities, {relations_loaded} relations, "
            f"{meta_count} meta-patterns"
        )
        return stats

    def export_rules(self, filepath: str, pretty: bool = True) -> str:
        """
        Export current entity-level data as a rule pack JSON file.

        This is the inverse of load_rules(). Useful for saving in-memory
        rules created during a game session.

        Args:
            filepath: output JSON file path
            pretty: whether to pretty-print the JSON

        Returns:
            the file path written to
        """
        import json as _json

        entities = []
        for eid, edata in self._entities.items():
            entities.append({
                "name": edata["canonical_name"],
                "type": edata.get("entity_type", "action_entity"),
                "description": edata.get("description", ""),
            })

        relations = []
        for (src, tgt, rt), rel in self._entity_relations.items():
            entry = {
                "source": rel["source"],
                "target": rel["target"],
                "relation_type": rel["relation_type"],
                "confidence": rel["confidence"],
            }
            conditions = rel.get("metadata", {}).get("conditions")
            if conditions:
                entry["conditions"] = conditions
            relations.append(entry)

        rule_pack = {
            "version": "1.0",
            "exported_at": _get_iso_now(),
            "source": "memory_storage",
            "stats": {
                "entities": len(entities),
                "relations": len(relations),
                "meta_patterns": 0,
            },
            "entities": entities,
            "relations": relations,
            "meta_patterns": [],
        }

        os.makedirs(os.path.dirname(os.path.abspath(filepath)), exist_ok=True)
        indent = 2 if pretty else None
        with open(filepath, "w", encoding="utf-8") as f:
            _json.dump(rule_pack, f, ensure_ascii=False, indent=indent)

        print(f"Exported rule pack to {filepath}: {len(entities)} entities, {len(relations)} relations")
        return filepath


def _get_iso_now() -> str:
    return _datetime.now().isoformat()
