"""
存储接口定义 - 所有存储实现的基类

重要说明：
1. 这个接口从一开始就定好，所有存储实现必须遵循
2. 接口定义后不应该修改，如果需要新功能，添加新方法
3. 具体实现可以不同（内存/SQLite/Neo4j），但接口保持一致

设计原则：
- 依赖倒置：上层模块（CausalEngine）依赖这个接口，不依赖具体实现
- 开闭原则：对扩展开放（添加新实现），对修改关闭（接口不变）
- 单一职责：只负责数据存储和查询，不负责业务逻辑

使用方式：
    config = Config.from_yaml("config.yaml")
    storage = config.get_storage()  # 返回 StorageInterface 的实例
    engine = CausalEngine(storage)
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Set, Union
from dataclasses import dataclass


@dataclass
class EventData:
    """
    事件数据结构
    
    属性:
        id: 事件唯一标识符
        name: 事件名称
        timestamp: 时间戳（可以是具体年份、模糊时间范围）
        location: 地点（可选）
        participants: 参与者列表（可选）
        description: 事件描述
        event_type: 事件类型（如 political, military, economic 等）
        metadata: 其他元数据
        evidence_sources: 证据来源列表（支持多重证据）
    """
    id: str
    name: str
    timestamp: Any  # 可以是 int（明确年份）或 dict（模糊时间）
    location: Optional[str] = None
    participants: Optional[List[str]] = None
    description: Optional[str] = None
    event_type: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    evidence_sources: Optional[List[str]] = None


@dataclass
class CausalRelation:
    """
    因果关系结构
    
    属性:
        source_id: 原因事件 ID
        target_id: 结果事件 ID
        relation_type: 关系类型（causes, enables, prevents 等）
        confidence: 置信度（0-1）
        evidence: 证据列表
        reasoning_steps: 推理步骤记录（用于可解释性）
        metadata: 其他元数据
    """
    source_id: str
    target_id: str
    relation_type: str
    confidence: float
    evidence: Optional[List[str]] = None
    reasoning_steps: Optional[List[Dict[str, Any]]] = None
    metadata: Optional[Dict[str, Any]] = None


class StorageInterface(ABC):
    """
    存储接口 - 所有存储实现必须遵循的规范
    
    重要说明：
    1. 这个接口是存储层的"合同"，定义了所有必需的方法
    2. 无论底层用内存、SQLite 还是 Neo4j，都必须实现这些方法
    3. 接口方法签名不应该修改，如果需要新功能，添加新方法
    
    实现要求：
    - 所有方法必须有完整的错误处理
    - 所有写入操作必须保证数据一致性
    - 所有查询操作必须返回指定类型
    - 支持事务（如果底层存储支持）
    
    使用示例：
        storage = MemoryStorage()  # 或 SQLiteStorage, Neo4jStorage
        storage.add_event(event_data)
        storage.add_causal_relation(relation)
        path = storage.get_causal_path("event1", "event2")
    """
    
    @abstractmethod
    def initialize(self) -> None:
        """
        初始化存储
        
        说明：
        - 创建必要的表结构（对于数据库）
        - 初始化内存结构（对于内存存储）
        - 检查连接（对于远程数据库）
        
        注意：
        - 这个方法应该是幂等的（可以多次调用）
        - 如果已经初始化过，不应该报错
        """
        pass
    
    @abstractmethod
    async def commit(self) -> None:
        """
        提交事务
        
        说明:
        - 如果存储支持事务（如 PostgreSQL），必须实现真正的提交逻辑
        - 如果存储不支持事务（如内存存储），可以实现为空操作
        - 用于保证数据一致性，特别是在批量操作时
        
        使用示例:
            storage.add_knowledge(knowledge1)
            storage.add_knowledge(knowledge2)
            await storage.commit()  # 一次性提交所有更改
        """
        pass
    
    @abstractmethod
    async def rollback(self) -> None:
        """
        回滚事务
        
        说明:
        - 如果存储支持事务（如 PostgreSQL），必须实现真正的回滚逻辑
        - 如果存储不支持事务（如内存存储），可以实现为空操作或抛出异常
        - 用于在错误发生时恢复到之前的状态
        
        使用示例:
            try:
                storage.add_knowledge(knowledge1)
                storage.add_knowledge(knowledge2)
                await storage.commit()
            except Exception:
                await storage.rollback()  # 回滚所有更改
        """
        pass
    
    @abstractmethod
    def add_event(self, event: EventData) -> bool:
        """
        添加事件到存储
        
        参数:
            event: EventData 对象，包含事件的所有信息
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意：
        - 如果事件 ID 已存在，应该更新而不是报错（upsert 语义）
        - 应该验证事件的必填字段（id, name, timestamp）
        """
        pass
    
    @abstractmethod
    def get_event(self, event_id: str) -> Optional[EventData]:
        """
        获取单个事件
        
        参数:
            event_id: 事件 ID
        
        返回:
            EventData 对象，如果不存在返回 None
        """
        pass
    
    @abstractmethod
    def delete_event(self, event_id: str) -> bool:
        """
        删除事件
        
        参数:
            event_id: 事件 ID
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意：
        - 删除事件时，应该同时删除相关的因果关系
        - 如果事件不存在，返回 False
        """
        pass
    
    @abstractmethod
    def add_causal_relation(self, relation: CausalRelation) -> bool:
        """
        添加因果关系
        
        参数:
            relation: CausalRelation 对象
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意：
        - 应该验证 source_id 和 target_id 对应的事件存在
        - 如果关系已存在，应该更新而不是报错（upsert 语义）
        - 应该验证 confidence 在 0-1 范围内
        """
        pass
    
    @abstractmethod
    def get_causal_relation(self, source_id: str, target_id: str) -> Optional[CausalRelation]:
        """
        获取单个因果关系
        
        参数:
            source_id: 原因事件 ID
            target_id: 结果事件 ID
        
        返回:
            CausalRelation 对象，如果不存在返回 None
        """
        pass
    
    @abstractmethod
    def delete_causal_relation(self, source_id: str, target_id: str) -> bool:
        """
        删除因果关系
        
        参数:
            source_id: 原因事件 ID
            target_id: 结果事件 ID
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        pass
    
    @abstractmethod
    def get_causal_path(self, source_id: str, target_id: str, 
                       max_length: int = 10) -> List[str]:
        """
        查找从源事件到目标事件的因果路径
        
        参数:
            source_id: 起始事件 ID
            target_id: 目标事件 ID
            max_length: 最大路径长度（防止无限递归）
        
        返回:
            事件 ID 列表，表示因果链
            例如：["e1", "e2", "e3"] 表示 e1 -> e2 -> e3
            如果没有路径，返回空列表 []
        
        注意：
        - 应该使用图算法（如 BFS 或 DFS）查找路径
        - 如果有多条路径，返回最短的那条
        - 路径长度包括起点和终点
        """
        pass
    
    @abstractmethod
    def get_influence_chain(self, event_id: str, direction: str = 'forward',
                           max_depth: int = 10) -> List[str]:
        """
        获取事件的影响链（所有受影响的或影响它的事件）
        
        参数:
            event_id: 事件 ID
            direction: 方向
                - 'forward': 获取该事件影响的所有事件（下游）
                - 'backward': 获取影响该事件的所有事件（上游）
            max_depth: 最大深度（防止遍历整个图）
        
        返回:
            事件 ID 列表，按影响顺序排列
        
        注意：
        - 使用 DFS 或 BFS 遍历
        - 避免循环依赖（记录已访问节点）
        """
        pass
    
    @abstractmethod
    def get_all_events(self) -> List[EventData]:
        """
        获取所有事件
        
        返回:
            EventData 列表
        """
        pass
    
    @abstractmethod
    def get_all_relations(self) -> List[CausalRelation]:
        """
        获取所有因果关系
        
        返回:
            CausalRelation 列表
        """
        pass
    
    @abstractmethod
    def query_events_by_time(self, start_time: Any, end_time: Any) -> List[EventData]:
        """
        按时间范围查询事件
        
        参数:
            start_time: 起始时间
            end_time: 结束时间
        
        返回:
            EventData 列表，按时间排序
        
        注意：
        - 支持模糊时间查询（如果 timestamp 是范围）
        - 返回的事件应该满足：start_time <= event.timestamp <= end_time
        """
        pass
    
    @abstractmethod
    def query_events_by_type(self, event_type: str) -> List[EventData]:
        """
        按事件类型查询
        
        参数:
            event_type: 事件类型
        
        返回:
            EventData 列表
        """
        pass
    
    @abstractmethod
    def search_events(
        self,
        query: str,
        domain: Optional[str] = None,
        event_type: Optional[str] = None,
        limit: int = 50
    ) -> List[EventData]:
        """
        搜索事件（全文搜索/关键词搜索）
        
        生产级实现应该支持：
        1. 关键词搜索（标题、描述、地点）
        2. 领域过滤（如果支持领域）
        3. 类型过滤
        4. 相关性排序
        5. 限制返回数量
        
        参数:
            query: 搜索关键词
            domain: 领域过滤（可选）
            event_type: 事件类型过滤（可选）
            limit: 最大返回数量（默认 50）
        
        返回:
            EventData 列表，按相关性排序
        
        注意:
        - PostgreSQL 实现应该使用 tsvector/tsquery 全文搜索
        - SQLite 实现可以使用 LIKE 或 FTS5
        - MemoryStorage 实现简单的字符串匹配
        - 返回结果应该按相关性降序排列
        """
        pass
    
    @abstractmethod
    def get_event_count(self) -> int:
        """
        获取事件总数
        
        返回:
            int: 事件数量
        """
        pass
    
    @abstractmethod
    def get_relation_count(self) -> int:
        """
        获取因果关系总数
        
        返回:
            int: 因果关系数量
        """
        pass
    
    @abstractmethod
    def clear(self) -> None:
        """
        清空所有数据
        
        注意：
        - 这个方法用于测试和重置
        - 应该删除所有事件和关系
        - 不应该删除表结构或初始化状态
        """
        pass
    
    @abstractmethod
    def save(self, filepath: Optional[str] = None) -> str:
        """
        持久化保存到文件
        
        参数:
            filepath: 文件路径（可选，如果为 None 使用默认路径）
        
        返回:
            str: 保存的文件路径
        
        注意：
        - 对于内存存储，需要序列化到文件
        - 对于数据库，这个方法可以是备份操作
        - 如果保存失败，应该抛出异常
        """
        pass
    
    @abstractmethod
    def load(self, filepath: str) -> bool:
        """
        从文件加载数据
        
        参数:
            filepath: 文件路径
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意：
        - 加载前应该清空当前数据
        - 如果文件不存在或格式错误，返回 False
        """
        pass
    
    @abstractmethod
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取存储统计信息
        
        返回:
            dict: 包含统计信息的字典
            例如：{
                'event_count': 100,
                'relation_count': 50,
                'storage_type': 'memory',
                'memory_usage_mb': 10.5,  # 对于内存存储
                'file_size_mb': 5.2,  # 对于文件存储
            }
        """
        pass
    
    @abstractmethod
    def close(self) -> None:
        """
        关闭存储连接
        
        注意：
        - 对于数据库，关闭连接
        - 对于内存存储，清理资源
        - 程序退出前应该调用这个方法
        """
        pass
    
    # =========================================================================
    # 图查询扩展方法（用于 CausalGraph）
    # =========================================================================
    
    @abstractmethod
    def get_relations_by_source(self, source_id: str) -> List[CausalRelation]:
        """
        根据源事件 ID 获取所有关系（出边）
        
        参数:
            source_id: 源事件 ID
        
        返回:
            CausalRelation 列表，包含所有以 source_id 为起点的关系
        
        注意：
        - 用于图遍历（BFS/DFS）
        - 返回的关系应该按置信度排序
        """
        pass
    
    @abstractmethod
    def get_relations_by_target(self, target_id: str) -> List[CausalRelation]:
        """
        根据目标事件 ID 获取所有关系（入边）
        
        参数:
            target_id: 目标事件 ID
        
        返回:
            CausalRelation 列表，包含所有以 target_id 为终点的关系
        
        注意：
        - 用于图遍历（查找原因）
        - 返回的关系应该按置信度排序
        """
        pass
    
    @abstractmethod
    def get_neighbors(self, event_id: str) -> Dict[str, List[CausalRelation]]:
        """
        获取事件的所有邻居（入边和出边）
        
        参数:
            event_id: 事件 ID
        
        返回:
            字典，包含：
            - 'incoming': 入边列表（原因）
            - 'outgoing': 出边列表（结果）
        """
        pass
    
    # =========================================================================
    # 知识单元扩展方法（支持所有知识类型）
    # =========================================================================
    
    @abstractmethod
    def add_knowledge(self, knowledge: Any) -> bool:
        """
        添加知识单元到存储
        
        参数:
            knowledge: KnowledgeUnit 对象（可以是任何知识类型）
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意:
        - 支持所有知识类型（Event, Theory, Method, Concept, Rule, Pattern 等）
        - 如果知识 ID 已存在，应该更新而不是报错（upsert 语义）
        - 应该验证知识的必填字段（id, name, content）
        - 这个方法与 add_event 的区别是支持更多知识类型
        """
        pass
    
    @abstractmethod
    def get_knowledge(self, knowledge_id: str) -> Optional[Any]:
        """
        获取单个知识单元
        
        参数:
            knowledge_id: 知识 ID
        
        返回:
            KnowledgeUnit 对象，如果不存在返回 None
        """
        pass
    
    @abstractmethod
    def update_knowledge(self, knowledge: Any) -> bool:
        """
        更新知识单元
        
        参数:
            knowledge: KnowledgeUnit 对象（包含更新后的数据）
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意:
        - 知识必须已经存在
        - 应该保留版本历史
        - 应该更新 modified_at 时间戳
        """
        pass
    
    @abstractmethod
    def delete_knowledge(self, knowledge_id: str) -> bool:
        """
        删除知识单元
        
        参数:
            knowledge_id: 知识 ID
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意:
        - 删除知识时，应该同时删除相关的关系
        - 如果知识不存在，返回 False
        """
        pass
    
    @abstractmethod
    def search_knowledge(
        self,
        query: str,
        knowledge_type: Optional[str] = None,
        limit: int = 50
    ) -> List[Any]:
        """
        搜索知识（全文搜索/关键词搜索）
        
        生产级实现应该支持：
        1. 关键词搜索（名称、内容、元数据）
        2. 类型过滤
        3. 相关性排序
        4. 限制返回数量
        
        参数:
            query: 搜索关键词
            knowledge_type: 知识类型过滤（可选，如 "event", "theory" 等）
            limit: 最大返回数量（默认 50）
        
        返回:
            KnowledgeUnit 列表，按相关性排序
        """
        pass
    
    @abstractmethod
    def get_knowledge_by_type(self, knowledge_type: str) -> List[Any]:
        """
        按知识类型查询
        
        参数:
            knowledge_type: 知识类型（如 "event", "theory", "method" 等）
        
        返回:
            KnowledgeUnit 列表
        """
        pass
    
    @abstractmethod
    def get_knowledge_count(self) -> int:
        """
        获取知识单元总数
        
        返回:
            int: 知识单元数量
        """
        pass
    
    @abstractmethod
    def get_knowledge_statistics(self) -> Dict[str, Any]:
        """
        获取知识统计信息
        
        返回:
            dict: 包含统计信息的字典
            例如：{
                'total_count': 100,
                'by_type': {
                    'event': 50,
                    'theory': 20,
                    'method': 10,
                    ...
                },
                'avg_confidence': 0.75,
                'by_verification_status': {
                    'verified': 30,
                    'partial': 50,
                    'unverified': 20
                }
            }
        """
        pass

    # ============ 实体级操作（统一实体 + 实体关系） ============

    @abstractmethod
    def ensure_entity(self, name: str, entity_type: str = "action_entity",
                      description: str = "") -> str:
        """
        确保实体存在，不存在则创建。

        Args:
            name: 实体名称（canonical_name）
            entity_type: 实体类型
            description: 描述

        Returns:
            实体 ID
        """
        pass

    @abstractmethod
    def add_entity_relation(self, source_name: str, target_name: str,
                            relation_type: str, confidence: float,
                            metadata: Optional[Dict[str, Any]] = None) -> bool:
        """
        添加实体间因果关系。自动通过名称查找或创建实体。

        Args:
            source_name: 源实体名称
            target_name: 目标实体名称
            relation_type: causes / enables / prevents / correlates
            confidence: 0.0 - 1.0
            metadata: 额外元数据（level, catalysts, inhibitors 等）

        Returns:
            是否成功写入（已存在返回 False）
        """
        pass

    @abstractmethod
    def find_entity_relation(self, source_name: str, target_name: str,
                             relation_type: str) -> Optional[Dict[str, Any]]:
        """
        查找指定的实体关系。

        Returns:
            {"id": ..., "confidence": ...} 或 None
        """
        pass

    @abstractmethod
    def update_relation_confidence(self, source_name: str, target_name: str,
                                   relation_type: str, new_confidence: float) -> bool:
        """
        更新指定关系的置信度。

        Returns:
            是否成功更新
        """
        pass

    @abstractmethod
    def find_conflicting_relations(self, source_name: str, target_name: str,
                                  relation_type: str) -> List[Dict[str, Any]]:
        """
        查找冲突关系。例如 source→target 已有 causes，查询 prevents。

        Returns:
            冲突关系列表 [{"relation_type": ..., "confidence": ...}]
        """
        pass

    @abstractmethod
    def search_entity_relations(self, keyword: str,
                                limit: int = 20) -> List[Dict[str, Any]]:
        """
        按关键词搜索实体关系。

        Returns:
            [{"source": ..., "target": ..., "relation_type": ..., "confidence": ...}]
        """
        pass
