"""
数据导入器接口和基础实现

提供统一的数据导入接口，支持多种数据源：
- CSV 文件
- JSON 文件
- shiji-kb API
- 自定义数据源
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
import csv
import json
import logging
from pathlib import Path

from ..storage.storage_interface import EventData

logger = logging.getLogger(__name__)


class DataImporter(ABC):
    """数据导入器抽象基类"""
    
    @abstractmethod
    def import_data(self, **kwargs) -> List[EventData]:
        """
        导入数据
        
        返回:
            EventData 列表
        """
        pass
    
    @abstractmethod
    def validate(self, data: Dict[str, Any]) -> bool:
        """
        验证数据
        
        参数:
            data: 待验证的数据字典
        
        返回:
            是否有效
        """
        pass
    
    def clean_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        清洗数据
        
        参数:
            data: 原始数据
        
        返回:
            清洗后的数据
        """
        # 默认实现：去除字符串字段的空白
        cleaned = {}
        for key, value in data.items():
            if isinstance(value, str):
                cleaned[key] = value.strip()
            else:
                cleaned[key] = value
        return cleaned
    
    def create_event(self, data: Dict[str, Any]) -> Optional[EventData]:
        """
        从数据创建 EventData
        
        参数:
            data: 数据字典
        
        返回:
            EventData 或 None（如果数据无效）
        """
        try:
            # 验证必填字段
            required_fields = ['name', 'timestamp']
            for field in required_fields:
                if field not in data or not data[field]:
                    logger.warning(f"缺少必填字段：{field}")
                    return None
            
            # 验证通过后验证
            if not self.validate(data):
                logger.warning(f"数据验证失败：{data}")
                return None
            
            # 清洗数据
            cleaned = self.clean_data(data)
            
            # 创建 EventData
            event = EventData(
                id=cleaned.get('id'),
                name=cleaned['name'],
                timestamp=cleaned['timestamp'],
                location=cleaned.get('location'),
                event_type=cleaned.get('event_type', 'unknown'),
                description=cleaned.get('description'),
                participants=cleaned.get('participants', []),
                metadata=cleaned.get('metadata', {})
            )
            
            return event
            
        except Exception as e:
            logger.error(f"创建事件失败：{e}", exc_info=True)
            return None


class CSVImporter(DataImporter):
    """CSV 文件导入器"""
    
    def __init__(self, file_path: str, encoding: str = 'utf-8'):
        """
        初始化 CSV 导入器
        
        参数:
            file_path: CSV 文件路径
            encoding: 文件编码（默认 utf-8）
        """
        self.file_path = Path(file_path)
        self.encoding = encoding
        
        if not self.file_path.exists():
            raise FileNotFoundError(f"CSV 文件不存在：{file_path}")
    
    def import_data(self, **kwargs) -> List[EventData]:
        """从 CSV 文件导入数据"""
        events = []
        
        try:
            with open(self.file_path, 'r', encoding=self.encoding) as f:
                reader = csv.DictReader(f)
                
                for row in reader:
                    event = self.create_event(row)
                    if event:
                        events.append(event)
            
            logger.info(f"从 CSV 导入 {len(events)} 个事件")
            return events
            
        except Exception as e:
            logger.error(f"CSV 导入失败：{e}", exc_info=True)
            raise
    
    def validate(self, data: Dict[str, Any]) -> bool:
        """验证 CSV 数据"""
        # 检查必填字段
        if not data.get('name'):
            return False
        
        # 检查 timestamp（可以是数字或字符串）
        timestamp = data.get('timestamp')
        if timestamp is None:
            return False
        
        # 尝试转换为数字
        try:
            float(timestamp)
        except (ValueError, TypeError):
            logger.warning(f"无效的时间戳：{timestamp}")
            return False
        
        return True
    
    def clean_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗 CSV 数据"""
        cleaned = super().clean_data(data)
        
        # 转换 timestamp 为数字
        if 'timestamp' in cleaned:
            try:
                cleaned['timestamp'] = float(cleaned['timestamp'])
            except (ValueError, TypeError):
                pass
        
        # 转换 participants 为列表（如果是字符串）
        if 'participants' in cleaned:
            participants = cleaned['participants']
            if isinstance(participants, str):
                # 假设用分号分隔
                cleaned['participants'] = [p.strip() for p in participants.split(';') if p.strip()]
        
        # 处理 domain 字段（放入 metadata）
        if 'domain' in cleaned and cleaned['domain']:
            if 'metadata' not in cleaned:
                cleaned['metadata'] = {}
            cleaned['metadata']['domain'] = cleaned['domain']
            del cleaned['domain']  # 移除单独的 domain 字段
        
        return cleaned


class JSONImporter(DataImporter):
    """JSON 文件导入器"""
    
    def __init__(self, file_path: str, encoding: str = 'utf-8'):
        """
        初始化 JSON 导入器
        
        参数:
            file_path: JSON 文件路径
            encoding: 文件编码（默认 utf-8）
        """
        self.file_path = Path(file_path)
        self.encoding = encoding
        
        if not self.file_path.exists():
            raise FileNotFoundError(f"JSON 文件不存在：{file_path}")
    
    def import_data(self, **kwargs) -> List[EventData]:
        """从 JSON 文件导入数据"""
        events = []
        
        try:
            with open(self.file_path, 'r', encoding=self.encoding) as f:
                data = json.load(f)
            
            # 支持两种格式：
            # 1. 列表：[{...}, {...}]
            # 2. 对象：{"events": [{...}, {...}]}
            if isinstance(data, list):
                items = data
            elif isinstance(data, dict) and 'events' in data:
                items = data['events']
            else:
                logger.warning(f"不支持的 JSON 格式")
                return []
            
            for item in items:
                event = self.create_event(item)
                if event:
                    events.append(event)
            
            logger.info(f"从 JSON 导入 {len(events)} 个事件")
            return events
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON 解析失败：{e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(f"JSON 导入失败：{e}", exc_info=True)
            raise
    
    def validate(self, data: Dict[str, Any]) -> bool:
        """验证 JSON 数据"""
        # 检查必填字段
        if not data.get('name'):
            return False
        
        # 检查 timestamp
        timestamp = data.get('timestamp')
        if timestamp is None:
            return False
        
        # 尝试转换为数字
        try:
            float(timestamp)
        except (ValueError, TypeError):
            logger.warning(f"无效的时间戳：{timestamp}")
            return False
        
        return True
    
    def clean_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """清洗 JSON 数据"""
        cleaned = super().clean_data(data)
        
        # 确保 timestamp 是数字
        if 'timestamp' in cleaned:
            try:
                cleaned['timestamp'] = float(cleaned['timestamp'])
            except (ValueError, TypeError):
                pass
        
        # 确保 participants 是列表
        if 'participants' in cleaned:
            participants = cleaned['participants']
            if isinstance(participants, str):
                cleaned['participants'] = [participants]
            elif not isinstance(participants, list):
                cleaned['participants'] = []
        
        return cleaned


class ShijiKBImporter(DataImporter):
    """shiji-kb API 导入器"""
    
    def __init__(self, api_url: str = None, api_key: str = None):
        """
        初始化 shiji-kb 导入器
        
        参数:
            api_url: API 基础 URL
            api_key: API Key（如果需要认证）
        """
        self.api_url = api_url or "http://localhost:8000/api"
        self.api_key = api_key
        
        # 延迟导入 requests（避免硬依赖）
        try:
            import requests
            self.requests = requests
        except ImportError:
            logger.warning("requests 库未安装，shiji-kb 导入器不可用")
            self.requests = None
    
    def import_data(self, **kwargs) -> List[EventData]:
        """从 shiji-kb API 导入数据"""
        if not self.requests:
            raise ImportError("requests 库未安装")
        
        events = []
        
        try:
            # 设置请求头
            headers = {}
            if self.api_key:
                headers['Authorization'] = f'Bearer {self.api_key}'
            
            # 获取所有事件
            response = self.requests.get(
                f"{self.api_url}/events",
                headers=headers,
                params=kwargs  # 支持过滤参数
            )
            response.raise_for_status()
            
            data = response.json()
            
            # 处理响应
            items = data.get('events', data.get('data', data))
            if isinstance(items, list):
                for item in items:
                    event = self.create_event(item)
                    if event:
                        events.append(event)
            
            logger.info(f"从 shiji-kb 导入 {len(events)} 个事件")
            return events
            
        except Exception as e:
            logger.error(f"shiji-kb 导入失败：{e}", exc_info=True)
            raise
    
    def validate(self, data: Dict[str, Any]) -> bool:
        """验证 shiji-kb 数据"""
        # 检查必填字段
        if not data.get('name'):
            return False
        
        # 检查 timestamp
        timestamp = data.get('timestamp')
        if timestamp is None:
            return False
        
        # 尝试转换为数字
        try:
            float(timestamp)
        except (ValueError, TypeError):
            logger.warning(f"无效的时间戳：{timestamp}")
            return False
        
        return True


def get_importer(source_type: str, **kwargs) -> DataImporter:
    """
    工厂函数：获取导入器实例
    
    参数:
        source_type: 数据源类型 ('csv', 'json', 'shiji-kb')
        **kwargs: 导入器参数
    
    返回:
        DataImporter 实例
    """
    importers = {
        'csv': CSVImporter,
        'json': JSONImporter,
        'shiji-kb': ShijiKBImporter,
    }
    
    if source_type not in importers:
        raise ValueError(f"不支持的数据源类型：{source_type}")
    
    return importers[source_type](**kwargs)
