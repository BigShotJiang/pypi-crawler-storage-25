"""
核心因果引擎测试 - 验证接口实现
"""

import unittest
from generic_causal_architecture.core.causal_engine import CausalEngine
from generic_causal_architecture.adapters.history_adapter import HistoryAdapter


class TestCausalEngineInterface(unittest.TestCase):
    """测试 CausalEngine 接口实现"""
    
    def test_set_domain_adapter(self):
        """测试设置领域适配器"""
        engine = CausalEngine()
        adapter = HistoryAdapter()
        
        engine.set_domain_adapter(adapter)
        
        self.assertEqual(engine.domain_adapter, adapter)
    
    def test_get_causal_confidence(self):
        """测试获取因果置信度"""
        engine = CausalEngine()
        
        event_a = {'id': '1', 'name': '事件A', 'time': 100}
        event_b = {'id': '2', 'name': '事件B', 'time': 200}
        
        confidence = engine.get_causal_confidence(event_a, event_b)
        
        self.assertIsInstance(confidence, float)
        self.assertGreaterEqual(confidence, 0.0)
        self.assertLessEqual(confidence, 1.0)
    
    def test_explain_causality(self):
        """测试解释因果关系"""
        engine = CausalEngine()
        
        event_a = {'id': '1', 'name': '事件A', 'time': 100}
        event_b = {'id': '2', 'name': '事件B', 'time': 200}
        
        explanation = engine.explain_causality(event_a, event_b)
        
        self.assertIsInstance(explanation, dict)
        self.assertIn('has_causality', explanation)
        self.assertIn('checks', explanation)
        self.assertIn('reasoning', explanation)
        self.assertIn('confidence', explanation)
    
    def test_explain_causality_with_causal_relation(self):
        """测试存在因果关系时的解释"""
        engine = CausalEngine()
        
        event_a = {'id': '1', 'name': '原因事件', 'time': 100}
        event_b = {'id': '2', 'name': '结果事件', 'time': 200}
        
        explanation = engine.explain_causality(event_a, event_b)
        
        self.assertTrue(explanation['has_causality'])
        self.assertGreater(explanation['confidence'], 0)
        self.assertIn('temporal_order', explanation['checks'])
        self.assertTrue(explanation['checks']['temporal_order']['passed'])
    
    def test_explain_causality_without_causal_relation(self):
        """测试不存在因果关系时的解释（时序错误）"""
        engine = CausalEngine()
        
        event_a = {'id': '1', 'name': '事件A', 'time': 200}
        event_b = {'id': '2', 'name': '事件B', 'time': 100}
        
        explanation = engine.explain_causality(event_a, event_b)
        
        self.assertFalse(explanation['has_causality'])
        self.assertFalse(explanation['checks']['temporal_order']['passed'])
    
    def test_get_causal_network(self):
        """测试构建因果网络"""
        engine = CausalEngine()
        
        events = [
            {'id': '1', 'name': '事件A', 'time': 100},
            {'id': '2', 'name': '事件B', 'time': 200},
            {'id': '3', 'name': '事件C', 'time': 300}
        ]
        
        network = engine.get_causal_network(events)
        
        self.assertIsInstance(network, dict)
        self.assertEqual(len(network), 3)
    
    def test_infer_causality_with_adapter(self):
        """测试使用领域适配器进行因果推断"""
        adapter = HistoryAdapter()
        engine = CausalEngine(domain_adapter=adapter)
        
        event_a = {'id': '1', 'name': '事件A', 'timestamp': 100}
        event_b = {'id': '2', 'name': '事件B', 'timestamp': 200}
        
        result = engine.infer_causality(event_a, event_b)
        
        self.assertIsInstance(result, bool)
    
    def test_intermediate_events_detection(self):
        """测试中间事件检测"""
        engine = CausalEngine()
        
        events = [
            {'id': '1', 'name': '事件A', 'time': 100},
            {'id': '2', 'name': '中间事件', 'time': 150},
            {'id': '3', 'name': '事件B', 'time': 200}
        ]
        
        engine._events_cache = events
        
        has_intermediate = engine._has_intermediate_events(events[0], events[2])
        
        self.assertTrue(has_intermediate)
    
    def test_no_intermediate_events(self):
        """测试无中间事件"""
        engine = CausalEngine()
        
        events = [
            {'id': '1', 'name': '事件A', 'time': 100},
            {'id': '2', 'name': '事件B', 'time': 200}
        ]
        
        engine._events_cache = events
        
        has_intermediate = engine._has_intermediate_events(events[0], events[1])
        
        self.assertFalse(has_intermediate)


class TestCausalEngineWithHistoryAdapter(unittest.TestCase):
    """测试 CausalEngine 与 HistoryAdapter 的集成"""
    
    def setUp(self):
        """设置测试环境"""
        self.adapter = HistoryAdapter()
        self.engine = CausalEngine(domain_adapter=self.adapter)
    
    def test_history_time_parsing(self):
        """测试历史时间解析"""
        event = {'name': '辛亥革命', 'time': '1911'}
        
        parsed = self.adapter._parse_historical_time(event['time'])
        
        self.assertEqual(parsed, 1911)
    
    def test_fuzzy_time_handling(self):
        """测试模糊时间处理"""
        event_a = {'name': '事件A', 'timestamp': {'start': 1920, 'end': 1929, 'type': 'decade'}}
        event_b = {'name': '事件B', 'timestamp': 1930}
        
        result = self.adapter.is_before(event_a, event_b)
        
        self.assertTrue(result)
    
    def test_evidence_quality_evaluation(self):
        """测试证据质量评估"""
        event = {
            'name': '历史事件',
            'evidence_sources': [
                {'type': 'primary_source', 'description': '一手史料'},
                {'type': 'secondary_source', 'description': '二手研究'}
            ]
        }
        
        quality = self.adapter._evaluate_evidence_quality(event)
        
        self.assertGreater(quality, 0.5)


if __name__ == '__main__':
    unittest.main()
