"""
知识模块单元测试

测试内容：
1. 知识模型（KnowledgeUnit）
2. 内置知识库（BuiltInKnowledgeBase）
3. 知识提取器（KnowledgeExtractor）
4. 知识更新器（KnowledgeUpdater）
5. 存储知识方法（MemoryStorage）

运行方式：
    pytest tests/test_knowledge.py -v
    pytest tests/test_knowledge.py::TestKnowledgeUnit -v
    pytest tests/test_knowledge.py -k "test_add" -v
"""

import pytest
import asyncio
from datetime import datetime
from typing import Any, Dict

from generic_causal_architecture.knowledge import (
    KnowledgeUnit,
    KnowledgeSet,
    KnowledgeType,
    VerificationStatus,
    ProtectionLevel,
    Source,
    Evidence,
    Relation,
    Version,
    Permissions,
    BuiltInKnowledgeBase,
)
from generic_causal_architecture.storage import MemoryStorage
from generic_causal_architecture.config import Config
from generic_causal_architecture.knowledge import KnowledgeUpdater


# ============================================================================
# 测试 1: 知识模型（KnowledgeUnit）
# ============================================================================

class TestKnowledgeUnit:
    """测试 KnowledgeUnit 基本功能"""
    
    def test_create_knowledge_unit(self):
        """测试创建知识单元"""
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="这是测试内容",
            knowledge_type=KnowledgeType.EVENT,
            confidence=0.8
        )
        
        assert knowledge.name == "测试知识"
        assert knowledge.content == "这是测试内容"
        assert knowledge.knowledge_type == KnowledgeType.EVENT
        assert knowledge.confidence == 0.8
        assert knowledge.verification_status == VerificationStatus.UNVERIFIED
        assert knowledge.id is not None
        assert len(knowledge.id) > 0
    
    def test_knowledge_type_validation(self):
        """测试知识类型验证"""
        # 有效类型
        knowledge = KnowledgeUnit(
            name="测试",
            content="内容",
            knowledge_type=KnowledgeType.THEORY
        )
        assert knowledge.knowledge_type == KnowledgeType.THEORY
        
        # 从字符串转换
        knowledge2 = KnowledgeUnit(
            name="测试",
            content="内容",
            knowledge_type="methodology"
        )
        assert knowledge2.knowledge_type == KnowledgeType.METHOD
    
    def test_confidence_validation(self):
        """测试置信度验证"""
        # 有效范围
        knowledge = KnowledgeUnit(
            name="测试",
            content="内容",
            confidence=0.75
        )
        assert knowledge.confidence == 0.75
        
        # 超出范围应该抛出异常
        with pytest.raises(ValueError):
            KnowledgeUnit(
                name="测试",
                content="内容",
                confidence=1.5
            )
        
        with pytest.raises(ValueError):
            KnowledgeUnit(
                name="测试",
                content="内容",
                confidence=-0.1
            )
    
    def test_add_evidence(self):
        """测试添加证据"""
        knowledge = KnowledgeUnit(
            name="测试",
            content="内容",
            confidence=0.5
        )
        
        # 添加支撑证据
        evidence = Evidence(
            content="这是证据",
            strength=0.8,
            confidence=0.9,
            supports=True
        )
        
        knowledge.add_evidence(evidence)
        assert len(knowledge.evidence) == 1
        assert knowledge.confidence > 0.5  # 置信度应该提升
    
    def test_remove_evidence(self):
        """测试移除证据"""
        knowledge = KnowledgeUnit(
            name="测试",
            content="内容"
        )
        
        evidence1 = Evidence(content="证据 1", strength=0.8, confidence=0.9)
        evidence2 = Evidence(content="证据 2", strength=0.7, confidence=0.8)
        
        knowledge.add_evidence(evidence1)
        knowledge.add_evidence(evidence2)
        
        assert len(knowledge.evidence) == 2
        
        # 移除一个证据
        knowledge.remove_evidence(evidence1.id)
        assert len(knowledge.evidence) == 1
        assert knowledge.evidence[0].content == "证据 2"
    
    def test_add_relation(self):
        """测试添加关系"""
        knowledge1 = KnowledgeUnit(name="知识 1", content="内容 1")
        knowledge2 = KnowledgeUnit(name="知识 2", content="内容 2")
        
        relation = Relation(
            type="causes",
            target_id=knowledge2.id,
            description="知识 1 导致知识 2"
        )
        
        knowledge1.add_relation(relation)
        assert len(knowledge1.relations) == 1
        assert knowledge1.relations[0].target_id == knowledge2.id
    
    def test_version_update(self):
        """测试版本更新"""
        knowledge = KnowledgeUnit(name="测试", content="内容")
        initial_version = knowledge.version.version
        
        # 更新版本
        knowledge.update_version(
            modified_by="user123",
            change_log="修改了内容"
        )
        
        # 版本号应该递增
        assert knowledge.version.version != initial_version
        assert knowledge.version.modified_by == "user123"
        assert knowledge.version.change_log == "修改了内容"
    
    def test_to_dict_and_from_dict(self):
        """测试序列化和反序列化"""
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="测试内容",
            knowledge_type=KnowledgeType.EVENT,
            confidence=0.85,
            verification_status=VerificationStatus.VERIFIED
        )
        
        # 添加证据
        knowledge.add_evidence(Evidence(
            content="证据内容",
            strength=0.9,
            confidence=0.95
        ))
        
        # 序列化
        data = knowledge.to_dict()
        
        # 反序列化
        restored = KnowledgeUnit.from_dict(data)
        
        assert restored.name == knowledge.name
        assert restored.content == knowledge.content
        assert restored.knowledge_type == knowledge.knowledge_type
        assert restored.confidence == knowledge.confidence
        assert restored.verification_status == knowledge.verification_status
        assert len(restored.evidence) == len(knowledge.evidence)
    
    def test_string_representation(self):
        """测试字符串表示"""
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="内容",
            confidence=0.85
        )
        
        str_repr = str(knowledge)
        assert "测试知识" in str_repr
        assert "0.85" in str_repr
        
        repr_repr = repr(knowledge)
        assert knowledge.id in repr_repr


# ============================================================================
# 测试 2: 内置知识库（BuiltInKnowledgeBase）
# ============================================================================

class TestBuiltInKnowledgeBase:
    """测试内置知识库"""
    
    def test_initialization(self):
        """测试初始化"""
        built_in = BuiltInKnowledgeBase()
        
        # 应该包含一定数量的知识
        assert len(built_in) > 0
    
    def test_get_all(self):
        """测试获取所有知识"""
        built_in = BuiltInKnowledgeBase()
        all_knowledge = built_in.get_all()
        
        assert isinstance(all_knowledge, KnowledgeSet)
        assert len(all_knowledge.items) > 0
    
    def test_get_by_type(self):
        """测试按类型获取"""
        built_in = BuiltInKnowledgeBase()
        
        # 获取因果规律
        patterns = built_in.get_causal_patterns()
        assert len(patterns) > 0
        assert all(k.knowledge_type == KnowledgeType.PATTERN for k in patterns)
        
        # 获取方法论
        methods = built_in.get_methodologies()
        assert len(methods) > 0
        assert all(k.knowledge_type == KnowledgeType.METHOD for k in methods)
    
    def test_get_by_id(self):
        """测试按 ID 获取"""
        built_in = BuiltInKnowledgeBase()
        
        # 获取特定知识
        knowledge = built_in.get_by_id("cp_reform_strength_unity")
        assert knowledge is not None
        assert knowledge.name == "改革强国统一论"
        
        # 获取不存在的 ID
        with pytest.raises(KeyError):
            built_in.get_by_id("non_existent_id")
    
    def test_search(self):
        """测试搜索"""
        built_in = BuiltInKnowledgeBase()
        
        # 搜索"改革"
        results = built_in.search("改革")
        assert len(results) > 0
        assert any("改革" in k.name or "改革" in k.content for k in results)
        
        # 搜索"因果"
        results = built_in.search("因果")
        assert len(results) > 0


# ============================================================================
# 测试 3: 知识更新器（KnowledgeUpdater）
# ============================================================================

class TestKnowledgeUpdater:
    """测试知识更新器"""
    
    @pytest.fixture
    def storage(self):
        """创建测试存储"""
        storage = MemoryStorage()
        storage.initialize()
        return storage
    
    @pytest.fixture
    def updater(self, storage):
        """创建测试更新器"""
        return KnowledgeUpdater(storage, auto_commit=True, enable_audit=True)
    
    @pytest.mark.asyncio
    async def test_add_knowledge(self, updater):
        """测试添加知识"""
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="测试内容",
            knowledge_type=KnowledgeType.EVENT
        )
        
        result = await updater.add(knowledge, operated_by="test_user")
        
        assert result.success is True
        assert result.knowledge_id == knowledge.id
        assert "添加成功" in result.message
    
    @pytest.mark.asyncio
    async def test_modify_knowledge(self, updater):
        """测试修改知识"""
        # 先添加（设置允许修改的权限）
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="原始内容",
            knowledge_type=KnowledgeType.EVENT,
            permissions=Permissions(allow_modify=True, allow_delete=True)
        )
        await updater.add(knowledge)
        
        # 修改
        result = await updater.modify(
            knowledge.id,
            {"content": "新内容", "confidence": 0.9},
            operated_by="test_user"
        )
        
        assert result.success is True
        assert "修改成功" in result.message
    
    @pytest.mark.asyncio
    async def test_delete_knowledge(self, updater):
        """测试删除知识"""
        # 先添加（设置允许删除的权限）
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="内容",
            permissions=Permissions(allow_modify=True, allow_delete=True)
        )
        await updater.add(knowledge)
        
        # 删除
        result = await updater.delete(
            knowledge.id,
            operated_by="test_user"
        )
        
        assert result.success is True
        assert "删除成功" in result.message
    
    @pytest.mark.asyncio
    async def test_audit_log(self, updater):
        """测试审计日志"""
        knowledge = KnowledgeUnit(name="测试", content="内容")
        await updater.add(knowledge)
        
        # 获取审计日志
        logs = updater.get_audit_logs()
        
        assert len(logs) > 0
        assert logs[-1].operation == "add"
        assert logs[-1].knowledge_id == knowledge.id


# ============================================================================
# 测试 4: 存储知识方法（MemoryStorage）
# ============================================================================

class TestMemoryStorageKnowledge:
    """测试 MemoryStorage 的知识方法"""
    
    @pytest.fixture
    def storage(self):
        """创建测试存储"""
        storage = MemoryStorage()
        storage.initialize()
        return storage
    
    def test_add_knowledge(self, storage):
        """测试添加知识"""
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="测试内容",
            knowledge_type=KnowledgeType.EVENT
        )
        
        result = storage.add_knowledge(knowledge)
        assert result is True
        
        # 验证已保存
        stored = storage.get_knowledge(knowledge.id)
        assert stored is not None
        assert stored.name == knowledge.name
    
    def test_update_knowledge(self, storage):
        """测试更新知识"""
        knowledge = KnowledgeUnit(
            name="测试知识",
            content="原始内容"
        )
        storage.add_knowledge(knowledge)
        
        # 更新
        knowledge.content = "新内容"
        knowledge.confidence = 0.9
        result = storage.update_knowledge(knowledge)
        
        assert result is True
        
        # 验证已更新
        stored = storage.get_knowledge(knowledge.id)
        assert stored.content == "新内容"
        assert stored.confidence == 0.9
    
    def test_delete_knowledge(self, storage):
        """测试删除知识"""
        knowledge = KnowledgeUnit(name="测试", content="内容")
        storage.add_knowledge(knowledge)
        
        # 删除
        result = storage.delete_knowledge(knowledge.id)
        assert result is True
        
        # 验证已删除
        stored = storage.get_knowledge(knowledge.id)
        assert stored is None
    
    def test_search_knowledge(self, storage):
        """测试搜索知识"""
        # 添加多个知识
        knowledge1 = KnowledgeUnit(name="商鞅变法", content="秦国的改革")
        knowledge2 = KnowledgeUnit(name="明治维新", content="日本的改革")
        knowledge3 = KnowledgeUnit(name=" unrelated", content="不相关内容")
        
        storage.add_knowledge(knowledge1)
        storage.add_knowledge(knowledge2)
        storage.add_knowledge(knowledge3)
        
        # 搜索"改革"
        results = storage.search_knowledge("改革")
        assert len(results) >= 2
        assert any(k.name == "商鞅变法" for k in results)
        assert any(k.name == "明治维新" for k in results)
    
    def test_get_knowledge_by_type(self, storage):
        """测试按类型获取"""
        # 添加不同类型
        event = KnowledgeUnit(name="事件", content="内容", knowledge_type=KnowledgeType.EVENT)
        theory = KnowledgeUnit(name="理论", content="内容", knowledge_type=KnowledgeType.THEORY)
        method = KnowledgeUnit(name="方法", content="内容", knowledge_type=KnowledgeType.METHOD)
        
        storage.add_knowledge(event)
        storage.add_knowledge(theory)
        storage.add_knowledge(method)
        
        # 按类型获取
        events = storage.get_knowledge_by_type("event")
        assert len(events) == 1
        assert events[0].name == "事件"
        
        theories = storage.get_knowledge_by_type("theory")
        assert len(theories) == 1
        assert theories[0].name == "理论"
    
    def test_knowledge_statistics(self, storage):
        """测试知识统计"""
        # 添加多个知识
        for i in range(5):
            knowledge = KnowledgeUnit(
                name=f"知识{i}",
                content="内容",
                knowledge_type=KnowledgeType.EVENT,
                confidence=0.7 + i * 0.05
            )
            storage.add_knowledge(knowledge)
        
        # 获取统计
        stats = storage.get_knowledge_statistics()
        
        assert stats['total_count'] == 5
        assert 'event' in stats['by_type']
        assert stats['by_type']['event'] == 5
        assert 'avg_confidence' in stats


# ============================================================================
# 测试 5: 知识集合（KnowledgeSet）
# ============================================================================

class TestKnowledgeSet:
    """测试知识集合"""
    
    def test_create_knowledge_set(self):
        """测试创建知识集合"""
        knowledge_set = KnowledgeSet(
            name="测试集合",
            description="这是测试集合"
        )
        
        assert knowledge_set.name == "测试集合"
        assert len(knowledge_set.items) == 0
    
    def test_add_knowledge_to_set(self):
        """测试添加知识到集合"""
        knowledge_set = KnowledgeSet(name="测试集合")
        
        knowledge1 = KnowledgeUnit(name="知识 1", content="内容 1")
        knowledge2 = KnowledgeUnit(name="知识 2", content="内容 2")
        
        knowledge_set.add(knowledge1)
        knowledge_set.add(knowledge2)
        
        assert len(knowledge_set.items) == 2
    
    def test_filter_by_type(self):
        """测试按类型过滤"""
        knowledge_set = KnowledgeSet(name="测试集合")
        
        knowledge_set.add(KnowledgeUnit(name="事件", knowledge_type=KnowledgeType.EVENT))
        knowledge_set.add(KnowledgeUnit(name="理论", knowledge_type=KnowledgeType.THEORY))
        knowledge_set.add(KnowledgeUnit(name="方法", knowledge_type=KnowledgeType.METHOD))
        
        events = knowledge_set.filter_by_type(KnowledgeType.EVENT)
        assert len(events) == 1
        assert events[0].name == "事件"
    
    def test_filter_by_confidence(self):
        """测试按置信度过滤"""
        knowledge_set = KnowledgeSet(name="测试集合")
        
        knowledge_set.add(KnowledgeUnit(name="低", confidence=0.3))
        knowledge_set.add(KnowledgeUnit(name="中", confidence=0.6))
        knowledge_set.add(KnowledgeUnit(name="高", confidence=0.9))
        
        high_conf = knowledge_set.filter_by_confidence(0.8)
        assert len(high_conf) == 1
        assert high_conf[0].name == "高"
    
    def test_to_dict_and_from_dict(self):
        """测试序列化和反序列化"""
        knowledge_set = KnowledgeSet(name="测试集合")
        knowledge_set.add(KnowledgeUnit(name="知识 1", content="内容 1"))
        knowledge_set.add(KnowledgeUnit(name="知识 2", content="内容 2"))
        
        # 序列化
        data = knowledge_set.to_dict()
        
        # 反序列化
        restored = KnowledgeSet.from_dict(data)
        
        assert restored.name == knowledge_set.name
        assert len(restored.items) == len(knowledge_set.items)


# ============================================================================
# 运行测试
# ============================================================================

if __name__ == "__main__":
    pytest.main([__file__, "-v"])
