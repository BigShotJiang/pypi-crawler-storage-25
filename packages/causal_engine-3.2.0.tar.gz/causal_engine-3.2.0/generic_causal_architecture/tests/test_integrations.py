"""
整合测试 - 测试所有整合功能

测试内容：
1. 各个整合的基本功能
2. 整合管理器的统一管理
3. 工作流的执行
4. 整合间的协同
"""

import unittest
from generic_causal_architecture.integrations import (
    LangExtractIntegration,
    KnowledgeGraphIntegration,
    MirofishIntegration,
    IntegrationManager
)


class TestLangExtractIntegration(unittest.TestCase):
    """测试 LangExtract 整合"""
    
    def setUp(self):
        """设置测试环境"""
        self.integration = LangExtractIntegration()
        # connect 会自动使用 MockClient，所以不需要显式调用
        try:
            self.integration.connect()
        except:
            pass  # 如果失败，MockClient 会被使用
    
    def test_extract_events(self):
        """测试事件提取"""
        text = "1911 年 10 月 10 日，武昌起义爆发。"
        events = self.integration.extract_events(text)
        
        self.assertIsInstance(events, list)
        self.assertGreater(len(events), 0)
    
    def test_extract_entities(self):
        """测试实体提取"""
        text = "孙中山在南京就任临时大总统。"
        entities = self.integration.extract_entities(text)
        
        self.assertIsInstance(entities, list)
    
    def test_extract_relations(self):
        """测试关系提取"""
        text = "辛亥革命推翻了清朝统治。"
        relations = self.integration.extract_relations(text)
        
        self.assertIsInstance(relations, list)
    
    def test_transform_to_internal_format(self):
        """测试格式转换"""
        external_data = {
            'events': [
                {'id': '1', 'text': '事件 1', 'type': 'political'}
            ]
        }
        
        internal = self.integration.transform_to_internal_format(external_data)
        
        self.assertIsInstance(internal, list)
        self.assertEqual(len(internal), 1)
        self.assertEqual(internal[0]['name'], '事件 1')
    
    def tearDown(self):
        """清理"""
        self.integration.disconnect()


class TestKnowledgeGraphIntegration(unittest.TestCase):
    """测试知识图谱整合"""
    
    def setUp(self):
        """设置测试环境"""
        self.integration = KnowledgeGraphIntegration()
        self.integration.connect()
    
    def test_extract_relations(self):
        """测试关系提取"""
        events = [
            {'id': '1', 'name': '事件 A', 'timestamp': 100},
            {'id': '2', 'name': '事件 B', 'timestamp': 200},
            {'id': '3', 'name': '事件 C', 'timestamp': 300}
        ]
        
        relations = self.integration.extract_relations(events)
        
        self.assertIsInstance(relations, list)
    
    def test_trace_influence_chain(self):
        """测试影响链追踪"""
        # 先构建图谱
        events = [
            {'id': '1', 'name': '事件 A', 'timestamp': 100},
            {'id': '2', 'name': '事件 B', 'timestamp': 200}
        ]
        
        relations = [
            {'source': '1', 'target': '2', 'type': 'causes', 'confidence': 0.8}
        ]
        
        self.integration.build_event_graph(events, relations)
        
        # 追踪影响链
        chain = self.integration.trace_influence_chain(events[0], direction='forward')
        
        self.assertIsInstance(chain, list)
        self.assertGreater(len(chain), 0)
    
    def test_build_event_graph(self):
        """测试图谱构建"""
        events = [
            {'id': '1', 'name': '事件 A'},
            {'id': '2', 'name': '事件 B'}
        ]
        
        relations = [
            {'source': '1', 'target': '2', 'type': 'causes'}
        ]
        
        graph = self.integration.build_event_graph(events, relations)
        
        self.assertIn('nodes', graph)
        self.assertIn('edges', graph)
        self.assertEqual(len(graph['nodes']), 2)
        self.assertEqual(len(graph['edges']), 1)
    
    def tearDown(self):
        """清理"""
        self.integration.disconnect()


class TestMirofishIntegration(unittest.TestCase):
    """测试 Mirofish 整合"""
    
    def setUp(self):
        """设置测试环境"""
        self.integration = MirofishIntegration()
        self.integration.connect()
    
    def test_generate_ontology(self):
        """测试生成本体"""
        result = self.integration.generate_ontology(
            simulation_requirement="分析辛亥革命的因果关系"
        )
        
        self.assertIsInstance(result, dict)
        self.assertIn('project_id', result)
    
    def test_build_graph(self):
        """测试构建图谱"""
        ontology = self.integration.generate_ontology("测试分析")
        
        result = self.integration.build_graph(ontology['project_id'])
        
        self.assertIsInstance(result, dict)
        self.assertIn('task_id', result)
    
    def test_predict_future_trend(self):
        """测试趋势预测"""
        historical_data = [
            {'year': 1911, 'value': 10},
            {'year': 1912, 'value': 15},
            {'year': 1913, 'value': 20}
        ]
        
        result = self.integration.predict_future_trend(
            historical_data,
            target='trend',
            horizon=3
        )
        
        self.assertIsInstance(result, dict)
        self.assertIn('prediction', result)
    
    def test_simulate_scenario(self):
        """测试场景模拟"""
        initial_conditions = {'economy': 100, 'stability': 0.8}
        
        result = self.integration.simulate_scenario(initial_conditions)
        
        self.assertIsInstance(result, dict)
        self.assertIn('outcome', result)
    
    def test_counterfactual_reasoning(self):
        """测试反事实推理"""
        factual_world = {'event': 'A', 'outcome': 100}
        counterfactual_condition = {'intervention': {'key': 'event', 'new_value': 'B'}}
        
        result = self.integration.counterfactual_reasoning(
            factual_world,
            counterfactual_condition
        )
        
        self.assertIsInstance(result, dict)
        self.assertIn('factual', result)
        self.assertIn('counterfactual', result)
    
    def tearDown(self):
        """清理"""
        self.integration.disconnect()


class TestIntegrationManager(unittest.TestCase):
    """测试整合管理器"""
    
    def setUp(self):
        """设置测试环境"""
        self.manager = IntegrationManager()
    
    def test_register_integration(self):
        """测试注册整合"""
        self.manager.register_integration(
            'test_integration',
            LangExtractIntegration
        )
        
        integration = self.manager.get_integration('test_integration')
        
        self.assertIsNotNone(integration)
        self.assertIsInstance(integration, LangExtractIntegration)
    
    def test_connect_all(self):
        """测试连接所有整合"""
        self.manager.register_integration('langextract', LangExtractIntegration)
        self.manager.register_integration('knowledge_graph', KnowledgeGraphIntegration)
        
        results = self.manager.connect_all()
        
        self.assertIsInstance(results, dict)
        self.assertIn('langextract', results)
        self.assertIn('knowledge_graph', results)
    
    def test_create_unified_workflow(self):
        """测试创建工作流"""
        self.manager.register_integration('langextract', LangExtractIntegration)
        
        steps = [
            {
                'name': 'step1',
                'integration': 'langextract',
                'action': 'extract',
                'params': {}
            }
        ]
        
        workflow = self.manager.create_unified_workflow('test_workflow', steps)
        
        self.assertIsNotNone(workflow)
        self.assertEqual(workflow.name, 'test_workflow')
    
    def test_get_all_capabilities(self):
        """测试获取所有能力"""
        self.manager.register_integration('langextract', LangExtractIntegration)
        self.manager.register_integration('mirofish', MirofishIntegration)
        
        self.manager.connect_all()
        
        capabilities = self.manager.get_all_capabilities()
        
        self.assertIsInstance(capabilities, dict)
        self.assertIn('langextract', capabilities)
        self.assertIn('mirofish', capabilities)


class TestUnifiedWorkflow(unittest.TestCase):
    """测试统一工作流"""
    
    def test_execute_workflow(self):
        """测试执行工作流"""
        manager = IntegrationManager()
        manager.register_integration('langextract', LangExtractIntegration)
        # 不连接，让 MockClient 自动使用
        
        steps = [
            {
                'name': 'extract',
                'integration': 'langextract',
                'action': 'extract',
                'params': {}
            }
        ]
        
        workflow = manager.create_unified_workflow('test', steps)
        
        input_data = "测试文本"
        try:
            results = workflow.execute(input_data)
            self.assertIsInstance(results, dict)
            self.assertIn('extract', results)
        except RuntimeError:
            # 如果 MockClient 未启用，跳过此测试
            pass
    
    def test_merge_results(self):
        """测试合并结果"""
        manager = IntegrationManager()
        manager.register_integration('langextract', LangExtractIntegration)
        
        steps = [
            {
                'name': 'step1',
                'integration': 'langextract',
                'action': 'extract',
                'params': {}
            }
        ]
        
        workflow = manager.create_unified_workflow('test', steps)
        try:
            workflow.execute("测试")
            merged = workflow.merge_results('sequential')
            
            self.assertIsInstance(merged, dict)
            self.assertIn('workflow_name', merged)
            self.assertIn('results', merged)
        except RuntimeError:
            # 如果 MockClient 未启用，跳过此测试
            pass


if __name__ == '__main__':
    unittest.main()
