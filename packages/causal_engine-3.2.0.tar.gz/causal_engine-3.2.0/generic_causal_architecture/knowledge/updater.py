"""
知识自更新 - 接收新知识并整合到知识库

这是架构优化的核心能力之一，提供：
- 添加、修改、删除知识
- 版本管理和回滚
- 冲突检测和解决
- 审计日志
- 批量更新

设计原则：
1. 完全开放 - 支持所有更新操作
2. 用户可控 - 用户可以控制更新策略
3. 可追溯 - 完整的版本历史和审计日志
4. 安全性 - 权限检查和冲突检测

版本：2.0.0
最后更新：2026-03-27
"""

import logging
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from .models import (
    KnowledgeUnit,
    KnowledgeSet,
    KnowledgeType,
    VerificationStatus,
    Version,
    Permissions,
)
from ..storage.storage_interface import StorageInterface

logger = logging.getLogger(__name__)


@dataclass
class AuditLog:
    """
    审计日志
    
    记录所有更新操作的日志。
    
    Attributes:
        id: 日志 ID
        operation: 操作类型（add/modify/delete/rollback）
        knowledge_id: 知识 ID
        knowledge_name: 知识名称
        old_value: 旧值（修改/删除时）
        new_value: 新值（添加/修改时）
        operated_by: 操作者
        operated_at: 操作时间
        reason: 操作原因
        metadata: 元数据
    """
    id: str = field(default_factory=lambda: str(datetime.now().timestamp()))
    operation: str = ""  # add, modify, delete, rollback
    knowledge_id: str = ""
    knowledge_name: str = ""
    old_value: Optional[Dict[str, Any]] = None
    new_value: Optional[Dict[str, Any]] = None
    operated_by: Optional[str] = None
    operated_at: datetime = field(default_factory=datetime.now)
    reason: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "operation": self.operation,
            "knowledge_id": self.knowledge_id,
            "knowledge_name": self.knowledge_name,
            "old_value": self.old_value,
            "new_value": self.new_value,
            "operated_by": self.operated_by,
            "operated_at": self.operated_at.isoformat(),
            "reason": self.reason,
            "metadata": self.metadata
        }


@dataclass
class UpdateResult:
    """
    更新结果
    
    Attributes:
        success: 是否成功
        knowledge_id: 知识 ID
        message: 消息
        warnings: 警告列表
        audit_log: 审计日志
    """
    success: bool
    knowledge_id: str
    message: str = ""
    warnings: List[str] = field(default_factory=list)
    audit_log: Optional[AuditLog] = None


class KnowledgeUpdater:
    """
    知识自更新管理器
    
    管理知识的添加、修改、删除，支持版本管理和回滚。
    
    核心能力：
    1. CRUD 操作 - 完整的添加、查询、修改、删除
    2. 版本管理 - 自动版本控制和历史追溯
    3. 冲突检测 - 检测知识冲突并提供解决方案
    4. 审计日志 - 完整的操作记录
    5. 批量更新 - 支持批量操作
    6. 回滚支持 - 支持回滚到历史版本
    
    使用示例：
    ```python
    from generic_causal_architecture.knowledge import KnowledgeUpdater
    from generic_causal_architecture.storage import Config
    
    # 初始化
    config = Config()
    storage = config.get_storage()
    updater = KnowledgeUpdater(storage)
    
    # 添加知识
    knowledge = KnowledgeUnit(name="新知识", content="内容...")
    result = await updater.add(knowledge, operated_by="user123")
    
    # 修改知识
    result = await updater.modify(
        knowledge.id,
        {"content": "新内容", "confidence": 0.9},
        operated_by="user123"
    )
    
    # 回滚
    result = await updater.rollback(knowledge.id, target_version="1.0.2")
    ```
    
    生产级特性：
    - 完整的错误处理
    - 详细的日志记录
    - 权限检查
    - 冲突检测
    - 审计日志
    - 事务支持
    """
    
    def __init__(
        self,
        storage: StorageInterface,
        auto_commit: bool = True,
        enable_audit: bool = True,
    ):
        """
        初始化知识更新器
        
        Args:
            storage: 存储接口
            auto_commit: 是否自动提交
            enable_audit: 是否启用审计日志
        """
        self.storage = storage
        self.auto_commit = auto_commit
        self.enable_audit = enable_audit
        self.audit_logs: List[AuditLog] = []
    
    async def add(
        self,
        knowledge: KnowledgeUnit,
        operated_by: Optional[str] = None,
        reason: str = "",
    ) -> UpdateResult:
        """
        添加知识
        
        Args:
            knowledge: 要添加的知识
            operated_by: 操作者 ID
            reason: 操作原因
            
        Returns:
            UpdateResult: 更新结果
            
        使用示例：
        ```python
        knowledge = KnowledgeUnit(
            name="新知识",
            content="这是新添加的知识",
            knowledge_type=KnowledgeType.EVENT
        )
        
        result = await updater.add(knowledge, operated_by="user123")
        if result.success:
            print(f"添加成功，ID: {result.knowledge_id}")
        ```
        """
        warnings = []
        
        # 1. 检查是否已存在
        try:
            existing = self.storage.get_knowledge(knowledge.id)
            if existing:
                return UpdateResult(
                    success=False,
                    knowledge_id=knowledge.id,
                    message=f"知识已存在：{knowledge.name}",
                    warnings=[f"ID {knowledge.id} 已存在"]
                )
        except Exception:
            pass  # 不存在是正常的
        
        # 2. 检查名称冲突
        existing_by_name = await self._find_by_name(knowledge.name)
        if existing_by_name:
            warnings.append(f"名称 '{knowledge.name}' 已存在，ID: {existing_by_name.id}")
        
        # 3. 添加到存储
        try:
            self.storage.add_knowledge(knowledge)
        except Exception as e:
            logger.error(f"添加知识失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge.id,
                message=f"添加失败：{str(e)}"
            )
        
        # 4. 创建审计日志
        audit_log = None
        if self.enable_audit:
            audit_log = AuditLog(
                operation="add",
                knowledge_id=knowledge.id,
                knowledge_name=knowledge.name,
                new_value=knowledge.to_dict(),
                operated_by=operated_by,
                reason=reason
            )
            self.audit_logs.append(audit_log)
        
        # 5. 自动提交
        if self.auto_commit:
            await self.storage.commit()
        
        return UpdateResult(
            success=True,
            knowledge_id=knowledge.id,
            message=f"添加成功：{knowledge.name}",
            warnings=warnings,
            audit_log=audit_log
        )
    
    async def modify(
        self,
        knowledge_id: str,
        changes: Dict[str, Any],
        operated_by: Optional[str] = None,
        reason: str = "",
    ) -> UpdateResult:
        """
        修改知识
        
        Args:
            knowledge_id: 知识 ID
            changes: 变更字段（字典）
            operated_by: 操作者 ID
            reason: 操作原因
            
        Returns:
            UpdateResult: 更新结果
            
        使用示例：
        ```python
        # 修改内容和置信度
        result = await updater.modify(
            knowledge_id,
            {
                "content": "新内容",
                "confidence": 0.9
            },
            operated_by="user123"
        )
        ```
        """
        warnings = []
        
        # 1. 获取现有知识
        try:
            existing = self.storage.get_knowledge(knowledge_id)
            if not existing:
                return UpdateResult(
                    success=False,
                    knowledge_id=knowledge_id,
                    message=f"知识不存在：{knowledge_id}"
                )
        except Exception as e:
            logger.error(f"获取知识失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"获取失败：{str(e)}"
            )
        
        # 2. 检查权限
        if not existing.permissions.allow_modify:
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"无修改权限：{existing.name}"
            )
        
        # 3. 保存旧值（用于审计和回滚）
        old_value = existing.to_dict()
        
        # 4. 应用变更
        for key, value in changes.items():
            if hasattr(existing, key):
                setattr(existing, key, value)
            elif key in existing.metadata:
                existing.metadata[key] = value
            else:
                warnings.append(f"未知字段：{key}")
        
        # 5. 更新版本
        existing.update_version(
            modified_by=operated_by,
            change_log=reason or ", ".join(f"{k}={v}" for k, v in changes.items())
        )
        
        # 6. 保存到存储
        try:
            self.storage.update_knowledge(existing)
        except Exception as e:
            logger.error(f"更新知识失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"更新失败：{str(e)}"
            )
        
        # 7. 创建审计日志
        audit_log = None
        if self.enable_audit:
            audit_log = AuditLog(
                operation="modify",
                knowledge_id=knowledge_id,
                knowledge_name=existing.name,
                old_value=old_value,
                new_value=existing.to_dict(),
                operated_by=operated_by,
                reason=reason
            )
            self.audit_logs.append(audit_log)
        
        # 8. 自动提交
        if self.auto_commit:
            await self.storage.commit()
        
        return UpdateResult(
            success=True,
            knowledge_id=knowledge_id,
            message=f"修改成功：{existing.name}",
            warnings=warnings,
            audit_log=audit_log
        )
    
    async def delete(
        self,
        knowledge_id: str,
        operated_by: Optional[str] = None,
        reason: str = "",
    ) -> UpdateResult:
        """
        删除知识
        
        Args:
            knowledge_id: 知识 ID
            operated_by: 操作者 ID
            reason: 操作原因
            
        Returns:
            UpdateResult: 更新结果
            
        使用示例：
        ```python
        result = await updater.delete(knowledge_id, operated_by="user123")
        ```
        """
        # 1. 获取现有知识
        try:
            existing = self.storage.get_knowledge(knowledge_id)
            if not existing:
                return UpdateResult(
                    success=False,
                    knowledge_id=knowledge_id,
                    message=f"知识不存在：{knowledge_id}"
                )
        except Exception as e:
            logger.error(f"获取知识失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"获取失败：{str(e)}"
            )
        
        # 2. 检查权限
        if not existing.permissions.allow_delete:
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"无删除权限：{existing.name}"
            )
        
        # 3. 保存旧值（用于审计）
        old_value = existing.to_dict()
        
        # 4. 从存储中删除
        try:
            self.storage.delete_knowledge(knowledge_id)
        except Exception as e:
            logger.error(f"删除知识失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"删除失败：{str(e)}"
            )
        
        # 5. 创建审计日志
        audit_log = None
        if self.enable_audit:
            audit_log = AuditLog(
                operation="delete",
                knowledge_id=knowledge_id,
                knowledge_name=existing.name,
                old_value=old_value,
                operated_by=operated_by,
                reason=reason
            )
            self.audit_logs.append(audit_log)
        
        # 6. 自动提交
        if self.auto_commit:
            await self.storage.commit()
        
        return UpdateResult(
            success=True,
            knowledge_id=knowledge_id,
            message=f"删除成功：{existing.name}",
            audit_log=audit_log
        )
    
    async def rollback(
        self,
        knowledge_id: str,
        target_version: str,
        operated_by: Optional[str] = None,
        reason: str = "",
    ) -> UpdateResult:
        """
        回滚到历史版本
        
        Args:
            knowledge_id: 知识 ID
            target_version: 目标版本号
            operated_by: 操作者 ID
            reason: 操作原因
            
        Returns:
            UpdateResult: 更新结果
            
        使用示例：
        ```python
        # 回滚到版本 1.0.2
        result = await updater.rollback(knowledge_id, "1.0.2")
        ```
        """
        # 1. 获取当前知识
        try:
            current = await self.storage.get_knowledge(knowledge_id)
            if not current:
                return UpdateResult(
                    success=False,
                    knowledge_id=knowledge_id,
                    message=f"知识不存在：{knowledge_id}"
                )
        except Exception as e:
            logger.error(f"获取知识失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"获取失败：{str(e)}"
            )
        
        # 2. 从审计日志中查找历史版本
        historical = None
        for log in reversed(self.audit_logs):
            if (log.knowledge_id == knowledge_id and
                log.operation == "modify" and
                log.old_value):
                # 检查版本号
                version = log.old_value.get("version", {}).get("version", "1.0.0")
                if version == target_version:
                    historical = log.old_value
                    break
        
        if not historical:
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"未找到版本 {target_version}"
            )
        
        # 3. 恢复历史版本
        try:
            restored = KnowledgeUnit.from_dict(historical)
            restored.version.previous_version = current.version.version
            restored.version.change_log = f"回滚到版本 {target_version}"
            
            await self.storage.update_knowledge(restored)
        except Exception as e:
            logger.error(f"回滚失败：{e}")
            return UpdateResult(
                success=False,
                knowledge_id=knowledge_id,
                message=f"回滚失败：{str(e)}"
            )
        
        # 4. 创建审计日志
        audit_log = None
        if self.enable_audit:
            audit_log = AuditLog(
                operation="rollback",
                knowledge_id=knowledge_id,
                knowledge_name=current.name,
                old_value=current.to_dict(),
                new_value=historical,
                operated_by=operated_by,
                reason=reason
            )
            self.audit_logs.append(audit_log)
        
        # 5. 自动提交
        if self.auto_commit:
            await self.storage.commit()
        
        return UpdateResult(
            success=True,
            knowledge_id=knowledge_id,
            message=f"回滚成功：{current.name} -> v{target_version}",
            audit_log=audit_log
        )
    
    async def batch_update(
        self,
        knowledge_set: KnowledgeSet,
        operated_by: Optional[str] = None,
        reason: str = "",
    ) -> List[UpdateResult]:
        """
        批量更新
        
        Args:
            knowledge_set: 知识集合
            operated_by: 操作者 ID
            reason: 操作原因
            
        Returns:
            List[UpdateResult]: 更新结果列表
        """
        logger.info(f"开始批量更新，共 {len(knowledge_set.items)} 个知识")
        
        results = []
        
        for knowledge in knowledge_set.items:
            # 检查是否已存在
            try:
                existing = await self.storage.get_knowledge(knowledge.id)
                if existing:
                    # 已存在，执行修改
                    changes = {
                        "content": knowledge.content,
                        "confidence": knowledge.confidence,
                        "metadata": knowledge.metadata
                    }
                    result = await self.modify(
                        knowledge.id,
                        changes,
                        operated_by,
                        reason
                    )
                else:
                    # 不存在，执行添加
                    result = await self.add(
                        knowledge,
                        operated_by,
                        reason
                    )
            except Exception:
                # 不存在，执行添加
                result = await self.add(knowledge, operated_by, reason)
            
            results.append(result)
        
        return results
    
    async def _find_by_name(self, name: str) -> Optional[KnowledgeUnit]:
        """
        按名称查找知识
        
        Args:
            name: 知识名称
            
        Returns:
            Optional[KnowledgeUnit]: 知识单元（如果找到）
        """
        # 这个方法的实现依赖于存储接口
        # 如果存储接口不支持按名称查询，可以返回 None
        try:
            # 尝试搜索
            results = await self.storage.search_knowledge(name)
            if results:
                # 精确匹配
                for result in results:
                    if result.name == name:
                        return result
        except Exception:
            pass
        
        return None
    
    def get_audit_logs(
        self,
        knowledge_id: Optional[str] = None,
        operation: Optional[str] = None,
        limit: int = 100,
    ) -> List[AuditLog]:
        """
        获取审计日志
        
        Args:
            knowledge_id: 知识 ID（可选，过滤特定知识）
            operation: 操作类型（可选，过滤特定操作）
            limit: 返回数量限制
            
        Returns:
            List[AuditLog]: 审计日志列表
        """
        logs = self.audit_logs
        
        # 过滤
        if knowledge_id:
            logs = [log for log in logs if log.knowledge_id == knowledge_id]
        if operation:
            logs = [log for log in logs if log.operation == operation]
        
        # 限制数量
        logs = logs[:limit]
        
        return logs
    
    async def commit(self):
        """手动提交（当 auto_commit=False 时）"""
        await self.storage.commit()
    
    async def rollback_all(self):
        """回滚所有未提交的更改（如果存储支持事务）"""
        await self.storage.rollback()
