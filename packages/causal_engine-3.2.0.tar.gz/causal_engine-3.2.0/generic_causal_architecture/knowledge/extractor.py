"""
知识提取器 - 从文本/文献中完整提取知识

这是架构优化的核心能力之一，提供：
- 从文本中提取事件、理论、方法、概念、规则、模式等
- 从古籍文献中提取知识（支持文言文、无标点文本）
- 使用 LLM 进行智能提取
- 支持批量提取
- 支持置信度评估和证据标注

设计原则：
1. 完整性 - 提取所有类型的知识，不只是事件
2. 准确性 - 使用 LLM+ 验证确保准确性
3. 效率 - 使用混合策略降低成本
4. 可追溯 - 保留来源信息
5. 通用性 - 支持古籍、毛选、哲学著作等各种文献

版本：2.0.0
最后更新：2026-03-27
"""

import logging
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from ..llm.provider import LLMProvider
from ..config.config import Config
from .models import (
    KnowledgeUnit,
    KnowledgeSet,
    KnowledgeType,
    VerificationStatus,
    Evidence,
    Source,
    Relation,
)
from ..books.models import Book, BookSection

logger = logging.getLogger(__name__)


@dataclass
class ExtractionResult:
    """
    提取结果
    
    包含从文本中提取的所有知识和元信息。
    
    Attributes:
        text: 原始文本
        knowledge_set: 提取的知识集合
        extraction_time: 提取耗时（秒）
        llm_calls: LLM 调用次数
        confidence: 平均置信度
        warnings: 警告信息列表
    """
    text: str
    knowledge_set: KnowledgeSet
    extraction_time: float = 0.0
    llm_calls: int = 0
    confidence: float = 0.0
    warnings: List[str] = field(default_factory=list)


class KnowledgeExtractor:
    """
    知识提取器
    
    从文本中完整提取知识，包括事件、理论、方法、概念、规则、模式等。
    
    核心能力：
    1. 多类型提取 - 不仅提取事件，还提取理论、方法、概念等
    2. 智能识别 - 使用 LLM 识别知识类型和内容
    3. 置信度评估 - 自动评估提取结果的置信度
    4. 证据标注 - 自动标注证据来源
    5. 关系识别 - 识别知识之间的关系
    
    使用示例：
    ```python
    from generic_causal_architecture.knowledge import KnowledgeExtractor
    from generic_causal_architecture.llm import LLMProvider
    
    # 初始化
    llm = LLMProvider(config)
    extractor = KnowledgeExtractor(llm, config)
    
    # 提取知识
    text = "商鞅变法后，秦国国力大增，最终统一六国"
    result = await extractor.extract_from_text(text)
    
    # 查看结果
    for knowledge in result.knowledge_set.items:
        print(f"{knowledge.name}: {knowledge.knowledge_type} (confidence: {knowledge.confidence})")
    ```
    
    生产级特性：
    - 完整的错误处理
    - 详细的日志记录
    - 支持批量处理
    - 支持进度追踪
    - 支持结果验证
    """
    
    def __init__(self, llm: LLMProvider, config: Optional[Config] = None):
        """
        初始化知识提取器
        
        Args:
            llm: LLM 提供者
            config: 配置对象（可选）
        """
        self.llm = llm
        self.config = config or Config()
        self.extraction_count = 0
        self.total_llm_calls = 0
    
    async def extract_from_text(
        self,
        text: str,
        extract_types: Optional[List[KnowledgeType]] = None,
        include_relations: bool = True,
        validate: bool = True,
    ) -> ExtractionResult:
        """
        从文本中提取知识
        
        Args:
            text: 输入文本
            extract_types: 要提取的知识类型列表（None 表示提取所有类型）
            include_relations: 是否提取知识之间的关系
            validate: 是否验证提取结果
            
        Returns:
            ExtractionResult: 提取结果
            
        使用示例：
        ```python
        # 提取所有类型
        result = await extractor.extract_from_text(text)
        
        # 只提取事件和理论
        result = await extractor.extract_from_text(
            text,
            extract_types=[KnowledgeType.EVENT, KnowledgeType.THEORY]
        )
        
        # 不提取关系
        result = await extractor.extract_from_text(text, include_relations=False)
        ```
        """
        import time
        start_time = time.time()
        
        logger.info(f"开始从文本中提取知识，文本长度：{len(text)}")
        
        # 1. 使用 LLM 提取知识
        llm_calls = 0
        knowledge_items = []
        warnings = []
        
        # 构建提取提示
        prompt = self._build_extraction_prompt(
            text,
            extract_types,
            include_relations
        )
        
        # 调用 LLM
        logger.debug("调用 LLM 进行知识提取...")
        response = await self.llm.chat(prompt)
        llm_calls += 1
        
        # 解析 LLM 响应
        try:
            knowledge_items = self._parse_llm_response(response)
        except Exception as e:
            logger.error(f"解析 LLM 响应失败：{e}")
            warnings.append(f"解析失败：{str(e)}")
        
        # 2. 验证提取结果（可选）
        if validate and knowledge_items:
            logger.debug("验证提取结果...")
            validated_items, validation_warnings = await self._validate_extraction(
                knowledge_items,
                text
            )
            knowledge_items = validated_items
            warnings.extend(validation_warnings)
        
        # 3. 创建知识集合
        knowledge_set = KnowledgeSet(
            name=f"Extraction from text",
            description=f"从文本中提取的知识",
            items=knowledge_items
        )
        
        # 4. 计算平均置信度
        avg_confidence = (
            sum(k.confidence for k in knowledge_items) / len(knowledge_items)
            if knowledge_items else 0.0
        )
        
        # 5. 更新统计
        self.extraction_count += 1
        self.total_llm_calls += llm_calls
        
        # 6. 返回结果
        extraction_time = time.time() - start_time
        
        return ExtractionResult(
            text=text,
            knowledge_set=knowledge_set,
            extraction_time=extraction_time,
            llm_calls=llm_calls,
            confidence=avg_confidence,
            warnings=warnings
        )
    
    async def extract_from_book_section(
        self,
        section: BookSection,
        book: Optional[Book] = None,
        extract_types: Optional[List[KnowledgeType]] = None,
        include_relations: bool = True,
        validate: bool = True,
    ) -> ExtractionResult:
        """
        从书籍章节中提取知识
        
        这是从古籍文献（如伤寒论、论语、毛选等）中提取知识的专用方法。
        
        Args:
            section: 书籍章节
            book: 所属书籍（可选，用于添加来源信息）
            extract_types: 要提取的知识类型列表
            include_relations: 是否提取关系
            validate: 是否验证
            
        Returns:
            ExtractionResult: 提取结果
            
        使用示例：
        ```python
        # 从章节提取
        result = await extractor.extract_from_book_section(section)
        
        # 带书籍信息（用于来源标注）
        result = await extractor.extract_from_book_section(section, book)
        
        # 只提取理论和方法
        result = await extractor.extract_from_book_section(
            section,
            book,
            extract_types=[KnowledgeType.THEORY, KnowledgeType.METHOD]
        )
        ```
        """
        logger.info(f"开始从章节提取知识：{section.title}")
        
        # 1. 提取知识
        result = await self.extract_from_text(
            text=section.content,
            extract_types=extract_types,
            include_relations=include_relations,
            validate=validate
        )
        
        # 2. 添加来源信息
        if book:
            source = Source(
                type="literature",
                title=book.title,
                author=book.author,
                year=None,  # 古代文献可能没有明确年份
                extra_info={
                    "dynasty": book.dynasty,
                    "category": book.category,
                    "section_title": section.title,
                    "section_id": section.id
                }
            )
            
            # 为所有提取的知识添加来源
            for knowledge in result.knowledge_set.items:
                knowledge.sources.append(source)
                knowledge.metadata["book_id"] = book.id
                knowledge.metadata["section_id"] = section.id
        
        # 3. 更新描述
        result.knowledge_set.name = f"Extraction from {book.title if book else 'unknown'} - {section.title}"
        result.knowledge_set.description = f"从《{book.title if book else 'unknown'}》的章节'{section.title}'中提取的知识"
        
        logger.info(f"章节提取完成，提取到 {len(result.knowledge_set.items)} 个知识")
        
        return result
    
    async def extract_from_book(
        self,
        book: Book,
        extract_types: Optional[List[KnowledgeType]] = None,
        include_relations: bool = True,
        validate: bool = True,
        progress_callback: Optional[callable] = None,
    ) -> List[ExtractionResult]:
        """
        从整本书中提取知识
        
        遍历所有章节，逐个提取知识。
        
        Args:
            book: 书籍对象
            extract_types: 要提取的知识类型列表
            include_relations: 是否提取关系
            validate: 是否验证
            progress_callback: 进度回调函数（接收当前进度和总进度）
            
        Returns:
            List[ExtractionResult]: 每个章节的提取结果列表
            
        使用示例：
        ```python
        # 提取整本书
        results = await extractor.extract_from_book(book)
        
        # 只提取理论和方法
        results = await extractor.extract_from_book(
            book,
            extract_types=[KnowledgeType.THEORY, KnowledgeType.METHOD]
        )
        
        # 带进度回调
        def progress(current, total):
            print(f"进度：{current}/{total} ({current/total*100:.1f}%)")
        
        results = await extractor.extract_from_book(
            book,
            progress_callback=progress
        )
        ```
        """
        logger.info(f"开始从整本书提取知识：《{book.title}》，共 {len(book.sections)} 个章节")
        
        results = []
        total = len(book.sections)
        
        for i, section in enumerate(book.sections):
            # 提取章节知识
            result = await self.extract_from_book_section(
                section=section,
                book=book,
                extract_types=extract_types,
                include_relations=include_relations,
                validate=validate
            )
            results.append(result)
            
            # 进度回调
            if progress_callback:
                progress_callback(i + 1, total)
            
            logger.debug(f"已处理章节 {i + 1}/{total}: {section.title}")
        
        logger.info(f"整本书提取完成，共提取到 {sum(len(r.knowledge_set.items) for r in results)} 个知识")
        
        return results
    
    async def extract_batch(
        self,
        texts: List[str],
        extract_types: Optional[List[KnowledgeType]] = None,
        include_relations: bool = True,
        validate: bool = True,
        progress_callback: Optional[callable] = None,
    ) -> List[ExtractionResult]:
        """
        批量提取知识
        
        Args:
            texts: 文本列表
            extract_types: 要提取的知识类型列表
            include_relations: 是否提取关系
            validate: 是否验证
            progress_callback: 进度回调函数（接收当前进度和总进度）
            
        Returns:
            List[ExtractionResult]: 提取结果列表
            
        使用示例：
        ```python
        # 批量提取
        texts = ["文本 1", "文本 2", "文本 3"]
        results = await extractor.extract_batch(texts)
        
        # 带进度回调
        def progress(current, total):
            print(f"进度：{current}/{total}")
        
        results = await extractor.extract_batch(
            texts,
            progress_callback=progress
        )
        ```
        """
        logger.info(f"开始批量提取，共 {len(texts)} 个文本")
        
        results = []
        total = len(texts)
        
        for i, text in enumerate(texts):
            # 提取
            result = await self.extract_from_text(
                text,
                extract_types,
                include_relations,
                validate
            )
            results.append(result)
            
            # 进度回调
            if progress_callback:
                progress_callback(i + 1, total)
            
            logger.debug(f"已处理 {i + 1}/{total}")
        
        return results
    
    def _build_extraction_prompt(
        self,
        text: str,
        extract_types: Optional[List[KnowledgeType]],
        include_relations: bool,
    ) -> str:
        """
        构建提取提示
        
        Args:
            text: 输入文本
            extract_types: 要提取的知识类型
            include_relations: 是否包含关系
            
        Returns:
            str: 构建的提示
        """
        # 确定要提取的类型
        if extract_types is None:
            types_str = "所有类型（事件、理论、方法、概念、规则、模式、因果关系）"
        else:
            types_str = ", ".join(t.value for t in extract_types)
        
        # 构建提示
        prompt = f"""
你是一个专业的知识提取专家。请从以下文本中提取知识。

## 要求

1. **提取类型**：{types_str}
2. **完整性**：提取所有相关信息，不要遗漏
3. **准确性**：确保提取的内容准确反映原文
4. **结构化**：按照指定的 JSON 格式输出

## 输出格式

请输出一个 JSON 对象，包含以下结构：

```json
{{
  "knowledge": [
    {{
      "name": "知识名称",
      "content": "知识内容描述",
      "knowledge_type": "event|theory|methodology|concept|rule|pattern|causal_relation",
      "confidence": 0.0-1.0,
      "verification_status": "unverified|partial|verified|contested|refuted",
      "evidence": [
        {{
          "content": "证据内容",
          "type": "literature|data|experiment|observation|other",
          "strength": 0.0-1.0,
          "supports": true|false
        }}
      ],
      "metadata": {{
        "key": "value"
      }}
    }}
  ],
  "relations": [
    {{
      "type": "related|supports|conflicts|causes|inherits",
      "source_id": "知识 1 的 name",
      "target_id": "知识 2 的 name",
      "description": "关系描述"
    }}
  ]
}}
```

## 输入文本

{text}

## 开始提取

请严格按照上述 JSON 格式输出提取结果，不要添加任何额外说明。
""".strip()
        
        return prompt
    
    def _parse_llm_response(self, response: str) -> List[KnowledgeUnit]:
        """
        解析 LLM 响应
        
        Args:
            response: LLM 的响应文本
            
        Returns:
            List[KnowledgeUnit]: 解析出的知识单元列表
        """
        import json
        
        try:
            # 尝试解析 JSON
            # 移除可能的 markdown 代码块标记
            response_clean = response.strip()
            if response_clean.startswith("```json"):
                response_clean = response_clean[7:]
            if response_clean.endswith("```"):
                response_clean = response_clean[:-3]
            response_clean = response_clean.strip()
            
            data = json.loads(response_clean)
            
            # 解析知识
            knowledge_items = []
            for item_data in data.get("knowledge", []):
                knowledge = self._create_knowledge_from_json(item_data)
                knowledge_items.append(knowledge)
            
            # 解析关系（如果有）
            if "relations" in data:
                self._add_relations(knowledge_items, data["relations"])
            
            return knowledge_items
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON 解析失败：{e}")
            logger.debug(f"原始响应：{response}")
            raise ValueError(f"无法解析 LLM 响应为 JSON: {e}")
    
    def _create_knowledge_from_json(self, data: Dict[str, Any]) -> KnowledgeUnit:
        """
        从 JSON 创建知识单元
        
        Args:
            data: JSON 数据
            
        Returns:
            KnowledgeUnit: 知识单元
        """
        # 转换知识类型
        knowledge_type = KnowledgeType(data.get("knowledge_type", "event"))
        
        # 转换验证状态
        verification_status = VerificationStatus(
            data.get("verification_status", "unverified")
        )
        
        # 转换证据
        evidence = []
        for ev_data in data.get("evidence", []):
            ev = Evidence(
                content=ev_data.get("content", ""),
                type=ev_data.get("type", "literature"),
                strength=ev_data.get("strength", 0.5),
                supports=ev_data.get("supports", True)
            )
            evidence.append(ev)
        
        # 创建知识单元
        return KnowledgeUnit(
            name=data.get("name", ""),
            content=data.get("content", ""),
            knowledge_type=knowledge_type,
            confidence=data.get("confidence", 0.5),
            verification_status=verification_status,
            evidence=evidence,
            metadata=data.get("metadata", {})
        )
    
    def _add_relations(
        self,
        knowledge_items: List[KnowledgeUnit],
        relations_data: List[Dict[str, Any]]
    ):
        """
        添加关系
        
        Args:
            knowledge_items: 知识单元列表
            relations_data: 关系数据列表
        """
        # 创建名称到知识的映射
        name_to_knowledge = {k.name: k for k in knowledge_items}
        
        # 添加关系
        for rel_data in relations_data:
            source_name = rel_data.get("source_id")
            target_name = rel_data.get("target_id")
            
            if source_name in name_to_knowledge and target_name in name_to_knowledge:
                relation = Relation(
                    type=rel_data.get("type", "related"),
                    target_id=name_to_knowledge[target_name].id,
                    description=rel_data.get("description", "")
                )
                name_to_knowledge[source_name].relations.append(relation)
    
    async def _validate_extraction(
        self,
        knowledge_items: List[KnowledgeUnit],
        original_text: str
    ) -> Tuple[List[KnowledgeUnit], List[str]]:
        """
        验证提取结果
        
        Args:
            knowledge_items: 提取的知识列表
            original_text: 原始文本
            
        Returns:
            Tuple[List[KnowledgeUnit], List[str]]: (验证后的知识列表，警告列表)
        """
        warnings = []
        validated_items = []
        
        for item in knowledge_items:
            # 1. 检查置信度是否合理
            if item.confidence < 0.0 or item.confidence > 1.0:
                warnings.append(f"知识 '{item.name}' 的置信度 {item.confidence} 超出范围，调整为 0.5")
                item.confidence = 0.5
            
            # 2. 检查证据是否支撑置信度
            if item.evidence and item.confidence > 0.8:
                # 高置信度应该有充分证据
                supporting_evidence = [e for e in item.evidence if e.supports]
                if len(supporting_evidence) < 2:
                    warnings.append(
                        f"知识 '{item.name}' 置信度 {item.confidence} 过高，"
                        f"但只有 {len(supporting_evidence)} 个支撑证据"
                    )
                    item.confidence = 0.7
            
            # 3. 检查内容是否为空
            if not item.content or len(item.content.strip()) < 10:
                warnings.append(f"知识 '{item.name}' 内容过短，可能提取不完整")
                continue  # 跳过这个知识
            
            validated_items.append(item)
        
        return validated_items, warnings
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            Dict[str, Any]: 统计信息
        """
        return {
            "extraction_count": self.extraction_count,
            "total_llm_calls": self.total_llm_calls,
            "avg_llm_calls_per_extraction": (
                self.total_llm_calls / self.extraction_count
                if self.extraction_count > 0 else 0
            )
        }
    
    def reset_statistics(self):
        """重置统计信息"""
        self.extraction_count = 0
        self.total_llm_calls = 0
