"""
知识模块 - 知识模型、提取、管理和自更新

这是架构优化的核心模块，提供：
- 知识模型（KnowledgeUnit 及所有子类型）
- 知识提取（从文本到理论的完整提取）
- 知识管理（内置知识库、权限管理）
- 知识自更新（接收新知识并整合）

版本：2.0.0
最后更新：2026-03-27
"""

from .models import (
    # 核心类
    KnowledgeUnit,
    Knowledge,
    KnowledgeSet,
    
    # 枚举类型
    KnowledgeType,
    VerificationStatus,
    ProtectionLevel,
    
    # 辅助类
    Source,
    Evidence,
    Relation,
    Version,
    Permissions,
)

from .built_in import (
    BuiltInKnowledgeBase,
)

from .extractor import (
    KnowledgeExtractor,
    ExtractionResult,
)

from .updater import (
    KnowledgeUpdater,
    UpdateResult,
    AuditLog,
)

__all__ = [
    # 核心类
    "KnowledgeUnit",
    "Knowledge",
    "KnowledgeSet",
    
    # 枚举类型
    "KnowledgeType",
    "VerificationStatus",
    "ProtectionLevel",
    
    # 辅助类
    "Source",
    "Evidence",
    "Relation",
    "Version",
    "Permissions",
    
    # 内置知识库
    "BuiltInKnowledgeBase",
    
    # 知识提取
    "KnowledgeExtractor",
    "ExtractionResult",
    
    # 知识更新
    "KnowledgeUpdater",
    "UpdateResult",
    "AuditLog",
]
