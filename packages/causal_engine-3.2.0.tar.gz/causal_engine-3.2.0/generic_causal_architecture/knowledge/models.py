"""
知识模型模块 - 所有知识类型的统一数据模型

这是架构优化的核心基础模块，提供：
- 统一的知识单元基类（KnowledgeUnit）
- 所有知识类型的详细模型
- 完整的类型定义和验证
- 生产级代码质量

设计原则：
1. 统一性 - 所有知识类型都继承自 KnowledgeUnit
2. 扩展性 - 易于添加新的知识类型
3. 类型安全 - 完整的类型注解
4. 可序列化 - 支持 JSON 序列化和反序列化
5. 可验证 - 内置数据验证

作者：Generic Causal Architecture Team
版本：2.0.0
最后更新：2026-03-27
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union
import uuid


class KnowledgeType(str, Enum):
    """
    知识类型枚举
    
    定义所有支持的知识类型：
    - EVENT: 事件（历史事件、科学实验等）
    - THEORY: 理论（科学理论、社会理论等）
    - METHOD: 方法论（研究方法、分析方法等）
    - CONCEPT: 概念（基本概念、术语等）
    - RULE: 规则（经验规则、启发式规则等）
    - PATTERN: 模式（因果模式、行为模式等）
    - ARGUMENT: 论证（论点、论据、论证过程）
    - CAUSAL_RELATION: 因果关系（明确的因果链）
    """
    EVENT = "event"
    THEORY = "theory"
    METHOD = "methodology"
    CONCEPT = "concept"
    RULE = "rule"
    PATTERN = "pattern"
    ARGUMENT = "argument"
    CAUSAL_RELATION = "causal_relation"


class VerificationStatus(str, Enum):
    """
    验证状态枚举
    
    定义知识的验证状态：
    - UNVERIFIED: 未验证（新添加，尚未验证）
    - PARTIAL: 部分验证（有支撑证据，但不充分）
    - VERIFIED: 已验证（充分验证）
    - CONTESTED: 有争议（存在相互矛盾的证据）
    - REFUTED: 已被证伪（有充分反证）
    """
    UNVERIFIED = "unverified"
    PARTIAL = "partial"
    VERIFIED = "verified"
    CONTESTED = "contested"
    REFUTED = "refuted"


class ProtectionLevel(str, Enum):
    """
    保护级别枚举
    
    定义知识的保护级别（用于权限控制）：
    - LOW: 低保护（可自由修改和删除）
    - MEDIUM: 中保护（修改需要审批）
    - HIGH: 高保护（修改和删除都需要审批）
    - CRITICAL: 关键保护（禁止修改和删除，只能读取）
    """
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Source:
    """
    来源信息
    
    记录知识的来源，用于追溯和验证。
    
    Attributes:
        id: 来源唯一标识符
        type: 来源类型（文献/数据库/口述/其他）
        title: 来源标题
        author: 作者（可选）
        year: 年份（可选）
        url: URL 链接（可选）
        doi: DOI 编号（可选，用于学术文献）
        pages: 页码范围（可选）
        publisher: 出版者（可选）
        extra_info: 额外信息（可选）
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: str = "literature"  # literature, database, oral, other
    title: str = ""
    author: Optional[str] = None
    year: Optional[int] = None
    url: Optional[str] = None
    doi: Optional[str] = None
    pages: Optional[str] = None
    publisher: Optional[str] = None
    extra_info: Optional[Dict[str, Any]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于序列化）"""
        return {
            "id": self.id,
            "type": self.type,
            "title": self.title,
            "author": self.author,
            "year": self.year,
            "url": self.url,
            "doi": self.doi,
            "pages": self.pages,
            "publisher": self.publisher,
            "extra_info": self.extra_info
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Source":
        """从字典创建（用于反序列化）"""
        return cls(**data)


@dataclass
class Evidence:
    """
    证据
    
    支撑或反驳某个知识的证据。
    
    Attributes:
        id: 证据唯一标识符
        content: 证据内容
        type: 证据类型（文献/数据/实验/观察/其他）
        strength: 证据强度（0.0-1.0）
        source: 来源
        supports: 是否支撑（True=支撑，False=反驳）
        confidence: 置信度（0.0-1.0）
        notes: 备注（可选）
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    content: str = ""
    type: str = "literature"  # literature, data, experiment, observation, other
    strength: float = 0.5  # 0.0-1.0
    source: Optional[Source] = None
    supports: bool = True  # True=支撑，False=反驳
    confidence: float = 0.5  # 0.0-1.0
    notes: Optional[str] = None
    
    def __post_init__(self):
        """验证数据"""
        if not 0.0 <= self.strength <= 1.0:
            raise ValueError(f"Evidence strength must be between 0.0 and 1.0, got {self.strength}")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(f"Confidence must be between 0.0 and 1.0, got {self.confidence}")
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "content": self.content,
            "type": self.type,
            "strength": self.strength,
            "source": self.source.to_dict() if self.source else None,
            "supports": self.supports,
            "confidence": self.confidence,
            "notes": self.notes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Evidence":
        """从字典创建"""
        if data.get("source"):
            data["source"] = Source.from_dict(data["source"])
        return cls(**data)


@dataclass
class Relation:
    """
    关系
    
    知识之间的关系（如相关、冲突、支持等）。
    
    Attributes:
        id: 关系唯一标识符
        type: 关系类型（相关/支持/冲突/因果/继承/其他）
        target_id: 目标知识 ID
        description: 关系描述
        strength: 关系强度（0.0-1.0）
        notes: 备注（可选）
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: str = "related"  # related, supports, conflicts, causes, inherits, other
    target_id: str = ""
    description: str = ""
    strength: float = 0.5  # 0.0-1.0
    notes: Optional[str] = None
    
    def __post_init__(self):
        """验证数据"""
        if not 0.0 <= self.strength <= 1.0:
            raise ValueError(f"Relation strength must be between 0.0 and 1.0, got {self.strength}")
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "type": self.type,
            "target_id": self.target_id,
            "description": self.description,
            "strength": self.strength,
            "notes": self.notes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Relation":
        """从字典创建"""
        return cls(**data)


@dataclass
class Version:
    """
    版本信息
    
    记录知识的版本历史。
    
    Attributes:
        version: 版本号（语义化版本，如 1.0.0）
        created_at: 创建时间
        modified_at: 修改时间
        modified_by: 修改者 ID
        change_log: 变更日志
        previous_version: 前一版本号
    """
    version: str = "1.0.0"
    created_at: datetime = field(default_factory=datetime.now)
    modified_at: datetime = field(default_factory=datetime.now)
    modified_by: Optional[str] = None
    change_log: str = ""
    previous_version: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "version": self.version,
            "created_at": self.created_at.isoformat(),
            "modified_at": self.modified_at.isoformat(),
            "modified_by": self.modified_by,
            "change_log": self.change_log,
            "previous_version": self.previous_version
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Version":
        """从字典创建"""
        if data.get("created_at"):
            data["created_at"] = datetime.fromisoformat(data["created_at"])
        if data.get("modified_at"):
            data["modified_at"] = datetime.fromisoformat(data["modified_at"])
        return cls(**data)


@dataclass
class Permissions:
    """
    权限配置
    
    定义知识的访问和操作权限。
    
    Attributes:
        allow_read: 允许读取
        allow_add: 允许添加
        allow_modify: 允许修改
        allow_delete: 允许删除
        who_can_modify: 可以修改的用户列表
        who_can_delete: 可以删除的用户列表
        require_approval_for_modify: 修改需要审批
        require_approval_for_delete: 删除需要审批
        protection_level: 保护级别
        audit_log: 启用审计日志
        track_changes: 追踪变更历史
    """
    allow_read: bool = True
    allow_add: bool = True
    allow_modify: bool = False
    allow_delete: bool = False
    who_can_modify: List[str] = field(default_factory=list)
    who_can_delete: List[str] = field(default_factory=list)
    require_approval_for_modify: bool = True
    require_approval_for_delete: bool = True
    protection_level: ProtectionLevel = ProtectionLevel.MEDIUM
    audit_log: bool = True
    track_changes: bool = True
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "allow_read": self.allow_read,
            "allow_add": self.allow_add,
            "allow_modify": self.allow_modify,
            "allow_delete": self.allow_delete,
            "who_can_modify": self.who_can_modify,
            "who_can_delete": self.who_can_delete,
            "require_approval_for_modify": self.require_approval_for_modify,
            "require_approval_for_delete": self.require_approval_for_delete,
            "protection_level": self.protection_level.value,
            "audit_log": self.audit_log,
            "track_changes": self.track_changes
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Permissions":
        """从字典创建"""
        if data.get("protection_level"):
            data["protection_level"] = ProtectionLevel(data["protection_level"])
        return cls(**data)


@dataclass
class KnowledgeUnit:
    """
    知识单元 - 所有知识类型的基类
    
    这是架构的核心数据模型，所有知识类型（事件、理论、方法、概念等）
    都继承自这个基类。
    
    设计哲学：
    - 所有知识都是"可验证的假设"
    - 所有知识都有"证据支撑"
    - 所有知识都有"置信度"
    - 所有知识都可以"被质疑和修正"
    
    核心属性：
    - id: 唯一标识符
    - name: 知识名称
    - content: 知识内容
    - knowledge_type: 知识类型
    - evidence: 支撑证据列表
    - confidence: 置信度（0.0-1.0）
    - verification_status: 验证状态
    - sources: 来源文献列表
    - relations: 与其他知识的关系
    - version: 版本信息
    - permissions: 权限配置
    - metadata: 元数据
    
    使用示例：
    ```python
    # 创建事件
    event = KnowledgeUnit(
        name="商鞅变法",
        content="公元前 356 年，商鞅在秦国推行变法...",
        knowledge_type=KnowledgeType.EVENT,
        confidence=0.95,
        verification_status=VerificationStatus.VERIFIED
    )
    
    # 创建理论
    theory = KnowledgeUnit(
        name="改革强国论",
        content="通过深层次改革实现国家综合实力提升...",
        knowledge_type=KnowledgeType.THEORY,
        confidence=0.85,
        verification_status=VerificationStatus.PARTIAL
    )
    ```
    """
    # 核心属性
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    content: str = ""
    knowledge_type: KnowledgeType = KnowledgeType.EVENT
    
    # 证据和验证
    evidence: List[Evidence] = field(default_factory=list)
    confidence: float = 0.5  # 0.0-1.0
    verification_status: VerificationStatus = VerificationStatus.UNVERIFIED
    
    # 来源和追溯
    sources: List[Source] = field(default_factory=list)
    
    # 关系网络
    relations: List[Relation] = field(default_factory=list)
    
    # 版本和权限
    version: Version = field(default_factory=Version)
    permissions: Permissions = field(default_factory=Permissions)
    
    # 元数据
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    # 扩展字段（用于子类）
    extra_fields: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """验证数据"""
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(f"Confidence must be between 0.0 and 1.0, got {self.confidence}")
        
        # 自动转换枚举类型
        if isinstance(self.knowledge_type, str):
            self.knowledge_type = KnowledgeType(self.knowledge_type)
        if isinstance(self.verification_status, str):
            self.verification_status = VerificationStatus(self.verification_status)
    
    def add_evidence(self, evidence: Evidence):
        """添加证据"""
        self.evidence.append(evidence)
        # 重新计算置信度
        self._recalculate_confidence()
    
    def remove_evidence(self, evidence_id: str):
        """移除证据"""
        self.evidence = [e for e in self.evidence if e.id != evidence_id]
        self._recalculate_confidence()
    
    def _recalculate_confidence(self):
        """重新计算置信度"""
        if not self.evidence:
            return
        
        # 简单平均（可以优化为加权平均）
        supporting = [e for e in self.evidence if e.supports]
        opposing = [e for e in self.evidence if not e.supports]
        
        if not supporting and not opposing:
            return
        
        support_strength = sum(e.strength * e.confidence for e in supporting)
        oppose_strength = sum(e.strength * e.confidence for e in opposing)
        
        total = support_strength + oppose_strength
        if total > 0:
            self.confidence = support_strength / total
    
    def add_relation(self, relation: Relation):
        """添加关系"""
        self.relations.append(relation)
    
    def remove_relation(self, relation_id: str):
        """移除关系"""
        self.relations = [r for r in self.relations if r.id != relation_id]
    
    def update_version(self, modified_by: Optional[str] = None, change_log: str = ""):
        """更新版本"""
        self.version.modified_at = datetime.now()
        self.version.modified_by = modified_by
        self.version.change_log = change_log
        # 递增版本号
        parts = self.version.version.split(".")
        parts[-1] = str(int(parts[-1]) + 1)
        self.version.version = ".".join(parts)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "name": self.name,
            "content": self.content,
            "knowledge_type": self.knowledge_type.value,
            "evidence": [e.to_dict() for e in self.evidence],
            "confidence": self.confidence,
            "verification_status": self.verification_status.value,
            "sources": [s.to_dict() for s in self.sources],
            "relations": [r.to_dict() for r in self.relations],
            "version": self.version.to_dict(),
            "permissions": self.permissions.to_dict(),
            "metadata": self.metadata,
            "extra_fields": self.extra_fields
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "KnowledgeUnit":
        """从字典创建"""
        # 转换枚举类型
        if data.get("knowledge_type"):
            data["knowledge_type"] = KnowledgeType(data["knowledge_type"])
        if data.get("verification_status"):
            data["verification_status"] = VerificationStatus(data["verification_status"])
        
        # 转换嵌套对象
        if data.get("evidence"):
            data["evidence"] = [Evidence.from_dict(e) for e in data["evidence"]]
        if data.get("sources"):
            data["sources"] = [Source.from_dict(s) for s in data["sources"]]
        if data.get("relations"):
            data["relations"] = [Relation.from_dict(r) for r in data["relations"]]
        if data.get("version"):
            data["version"] = Version.from_dict(data["version"])
        if data.get("permissions"):
            data["permissions"] = Permissions.from_dict(data["permissions"])
        
        return cls(**data)
    
    def __str__(self) -> str:
        """字符串表示"""
        return f"{self.knowledge_type.value}: {self.name} (confidence: {self.confidence:.2f})"
    
    def __repr__(self) -> str:
        """详细表示"""
        return (
            f"KnowledgeUnit(id='{self.id}', name='{self.name}', "
            f"type={self.knowledge_type.value}, confidence={self.confidence:.2f})"
        )


# 类型别名，方便使用
Knowledge = KnowledgeUnit


@dataclass
class KnowledgeSet:
    """
    知识集合
    
    用于批量操作的知识集合。
    
    Attributes:
        id: 集合唯一标识符
        name: 集合名称
        description: 集合描述
        items: 知识项列表
        created_at: 创建时间
        metadata: 元数据
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    description: str = ""
    items: List[KnowledgeUnit] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add(self, knowledge: KnowledgeUnit):
        """添加知识项"""
        self.items.append(knowledge)
    
    def remove(self, knowledge_id: str):
        """移除知识项"""
        self.items = [item for item in self.items if item.id != knowledge_id]
    
    def filter_by_type(self, knowledge_type: KnowledgeType) -> List[KnowledgeUnit]:
        """按类型过滤"""
        return [item for item in self.items if item.knowledge_type == knowledge_type]
    
    def filter_by_confidence(self, min_confidence: float) -> List[KnowledgeUnit]:
        """按置信度过滤"""
        return [item for item in self.items if item.confidence >= min_confidence]
    
    def filter_by_verification(self, status: VerificationStatus) -> List[KnowledgeUnit]:
        """按验证状态过滤"""
        return [item for item in self.items if item.verification_status == status]
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "items": [item.to_dict() for item in self.items],
            "created_at": self.created_at.isoformat(),
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "KnowledgeSet":
        """从字典创建"""
        if data.get("items"):
            data["items"] = [KnowledgeUnit.from_dict(item) for item in data["items"]]
        if data.get("created_at"):
            data["created_at"] = datetime.fromisoformat(data["created_at"])
        return cls(**data)
