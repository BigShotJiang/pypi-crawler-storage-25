"""
柳叶刀方法 - 应对大模型幻觉的核心技术

核心思想：
1. 细粒度任务分解 - 将复杂任务拆分为可管理的小任务
2. 混合解决方案 - LLM + 规则 + 代码的分工协作
3. 成本优化 - 能用规则绝不用 LLM，能在 L1 解决绝不上 L4
4. 质量评估 - 自动评估结果质量，支持迭代优化

分层架构：
- L1: 规则引擎（成本最低，速度最快）
- L2: 统计计算（成本低，速度较快）
- L3: 符号推理（成本中等，可解释）
- L4: 大模型（成本最高，能力最强）

使用示例：
    from generic_causal_architecture.methods import LancetMethod
    from generic_causal_architecture.config import Config
    
    config = Config.from_yaml("config/default.yaml")
    lancet = LancetMethod(config.layer)
    
    # 任务分解
    subtasks = lancet.decompose_task({
        'type': 'causal_inference',
        'description': '分析武昌起义和清朝结束的因果关系',
        'events': [event1, event2]
    })
    
    # 为每个子任务选择最优解决方案
    for subtask in subtasks:
        solution = lancet.select_solution(subtask['features'])
        subtask['solution'] = solution
    
    # 执行任务
    results = []
    for subtask in subtasks:
        result = lancet.execute_subtask(subtask, llm_client)
        results.append(result)
    
    # 质量评估
    quality = lancet.evaluate_quality(results)
    if quality < threshold:
        # 迭代优化
        ...
"""

from typing import Any, Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from enum import Enum
import logging

logger = logging.getLogger(__name__)


class SolutionType(Enum):
    """解决方案类型"""
    RULE_BASED = "rule_based"  # 基于规则
    CODE_OPTIMIZED = "code_optimized"  # 代码优化
    LLM_BASED = "llm_based"  # 基于大模型
    HYBRID = "hybrid"  # 混合方案


class LayerLevel(Enum):
    """分层调用级别"""
    L1_RULE = "l1_rule"  # 规则引擎
    L2_STATISTICAL = "l2_statistical"  # 统计计算
    L3_SYMBOLIC = "l3_symbolic"  # 符号推理
    L4_LLM = "l4_llm"  # 大模型


@dataclass
class LayerConfig:
    """分层配置"""
    l1_enabled: bool = True
    l2_enabled: bool = True
    l3_enabled: bool = True
    l4_enabled: bool = True
    l4_budget_per_request: float = 1.0  # 每次请求预算（美元）
    l4_daily_budget: float = 100.0  # 每日预算（美元）
    l4_cost_threshold: float = 0.5  # 单次调用成本阈值（美元）
    
    @classmethod
    def from_dict(cls, config: Dict[str, Any]) -> 'LayerConfig':
        """从字典创建配置"""
        return cls(
            l1_enabled=config.get('l1_enabled', True),
            l2_enabled=config.get('l2_enabled', True),
            l3_enabled=config.get('l3_enabled', True),
            l4_enabled=config.get('l4_enabled', True),
            l4_budget_per_request=config.get('l4_budget_per_request', 1.0),
            l4_daily_budget=config.get('l4_daily_budget', 100.0),
            l4_cost_threshold=config.get('l4_cost_threshold', 0.5)
        )


@dataclass
class TaskFeatures:
    """任务特征"""
    deterministic: float = 0.5  # 确定性程度 (0-1)
    semantic_depth: int = 1  # 语义深度 (1-5)
    samples: int = 100  # 样本数量
    scale: int = 1000  # 数据规模
    latency: int = 60  # 延迟要求 (秒)
    rule_complexity: str = "medium"  # 规则复杂度 ('low', 'medium', 'high')
    generalization: str = "medium"  # 泛化需求 ('low', 'medium', 'high')
    context_length: int = 1000  # 上下文长度 (tokens)
    precision_required: float = 0.8  # 精度要求 (0-1)
    explainability_required: bool = True  # 是否需要可解释性
    
    @classmethod
    def from_dict(cls, features: Dict[str, Any]) -> 'TaskFeatures':
        """从字典创建任务特征"""
        return cls(
            deterministic=features.get('deterministic', 0.5),
            semantic_depth=features.get('semantic_depth', 1),
            samples=features.get('samples', 100),
            scale=features.get('scale', 1000),
            latency=features.get('latency', 60),
            rule_complexity=features.get('rule_complexity', 'medium'),
            generalization=features.get('generalization', 'medium'),
            context_length=features.get('context_length', 1000),
            precision_required=features.get('precision_required', 0.8),
            explainability_required=features.get('explainability_required', True)
        )


@dataclass
class SubTask:
    """子任务"""
    task_id: str
    task_type: str
    description: str
    features: TaskFeatures
    solution: Optional[SolutionType] = None
    layer_level: Optional[LayerLevel] = None
    result: Optional[Any] = None
    quality_score: float = 0.0
    cost: float = 0.0
    error: Optional[str] = None


@dataclass
class TaskResult:
    """任务执行结果"""
    task_id: str
    success: bool
    result: Any
    solution_type: SolutionType
    layer_level: LayerLevel
    quality_score: float
    cost: float
    execution_time: float
    error_message: Optional[str] = None


class LancetMethod:
    """
    柳叶刀方法实现
    
    核心功能：
    1. 任务分解 - 将复杂任务拆分为子任务
    2. 方案选择 - 为每个子任务选择最优解决方案
    3. 分层调用 - L1-L4 分层调用策略
    4. 成本优化 - 在预算内最大化效果
    5. 质量评估 - 自动评估结果质量
    6. 迭代优化 - 支持多轮迭代改进
    
    设计原则：
    - 能用规则绝不用 LLM（成本优化）
    - 能在 L1 解决绝不上 L4（分层调用）
    - 混合方案优先（优势互补）
    - 质量第一（不为了省钱牺牲质量）
    """
    
    def __init__(self, layer_config: LayerConfig):
        """
        初始化柳叶刀方法
        
        Args:
            layer_config: 分层配置
        """
        self.layer_config = layer_config
        
        # 规则引擎（L1）
        self.rule_engines: Dict[str, Callable] = {}
        
        # 统计方法（L2）
        self.statistical_methods: Dict[str, Callable] = {}
        
        # 符号推理（L3）
        self.symbolic_reasoners: Dict[str, Callable] = {}
        
        # LLM 客户端（L4）- 延迟绑定
        self._llm_client = None
        
        # 成本追踪
        self._daily_cost = 0.0
        self._request_count = 0
        
        # 质量评估器
        self.quality_evaluators: Dict[str, Callable] = {}
        
        self._register_default_methods()
    
    def set_llm_client(self, llm_client: Any) -> None:
        """设置 LLM 客户端"""
        self._llm_client = llm_client
    
    def _register_default_methods(self) -> None:
        """注册默认方法"""
        # L1: 规则引擎
        self.rule_engines['temporal_check'] = self._rule_temporal_check
        self.rule_engines['temporal_analysis'] = self._rule_temporal_analysis
        self.rule_engines['keyword_match'] = self._rule_keyword_match
        self.rule_engines['pattern_match'] = self._rule_pattern_match
        
        # L2: 统计方法
        self.statistical_methods['similarity'] = self._stat_similarity
        self.statistical_methods['co_occurrence'] = self._stat_co_occurrence
        self.statistical_methods['cooccurrence_analysis'] = self._stat_co_occurrence
        
        # L3: 符号推理
        self.symbolic_reasoners['logic_inference'] = self._symbolic_logic
        self.symbolic_reasoners['causal_chain'] = self._symbolic_causal_chain
        
        # 质量评估器
        self.quality_evaluators['consistency'] = self._eval_consistency
        self.quality_evaluators['completeness'] = self._eval_completeness
        self.quality_evaluators['accuracy'] = self._eval_accuracy
    
    # =========================================================================
    # 核心方法 1: 方案选择
    # =========================================================================
    
    def select_solution(self, task_features: TaskFeatures) -> Tuple[SolutionType, LayerLevel]:
        """
        根据任务特征自动选择最优解决方案和分层级别
        
        决策流程：
        1. 检查预算和成本约束
        2. 分析任务特征
        3. 选择解决方案类型
        4. 选择分层级别
        5. 返回最优组合
        
        Args:
            task_features: 任务特征
        
        Returns:
            (SolutionType, LayerLevel): 最优解决方案和分层级别
        """
        # 检查 LLM 预算
        if not self._check_llm_budget():
            # 预算超支，降级到 L3
            return SolutionType.HYBRID, LayerLevel.L3_SYMBOLIC
        
        # 决策树
        solution_type = self._decide_solution_type(task_features)
        layer_level = self._decide_layer_level(task_features, solution_type)
        
        logger.debug(
            f"Task features: deterministic={task_features.deterministic}, "
            f"semantic_depth={task_features.semantic_depth}, "
            f"samples={task_features.samples}"
        )
        logger.debug(f"Selected solution: {solution_type}, layer: {layer_level}")
        
        return solution_type, layer_level
    
    def _decide_solution_type(self, features: TaskFeatures) -> SolutionType:
        """决策解决方案类型"""
        
        # 1. 高确定性 → 规则优先
        if features.deterministic > 0.9:
            return SolutionType.RULE_BASED
        
        # 2. 低延迟 + 大规模 → 代码优化
        if features.latency < 10 and features.scale > 10000:
            return SolutionType.CODE_OPTIMIZED
        
        # 3. 高语义深度 + 小样本 → LLM
        if (features.semantic_depth >= 4 and 
            features.samples < 50 and
            features.context_length < 4000):
            return SolutionType.LLM_BASED
        
        # 4. 高复杂度 + 高泛化 → 混合
        if (features.rule_complexity == 'high' and 
            features.generalization == 'high'):
            return SolutionType.HYBRID
        
        # 5. 需要可解释性 → 混合（规则 + 符号推理）
        if features.explainability_required:
            return SolutionType.HYBRID
        
        # 6. 高精度要求 → 混合（多方法验证）
        if features.precision_required > 0.9:
            return SolutionType.HYBRID
        
        # 默认：混合方案
        return SolutionType.HYBRID
    
    def _decide_layer_level(self, features: TaskFeatures, 
                           solution_type: SolutionType) -> LayerLevel:
        """决策分层级别"""
        
        # 根据解决方案类型确定层级
        if solution_type == SolutionType.RULE_BASED:
            return LayerLevel.L1_RULE
        
        if solution_type == SolutionType.CODE_OPTIMIZED:
            return LayerLevel.L2_STATISTICAL
        
        if solution_type == SolutionType.HYBRID:
            # 混合方案：根据特征决定主层级
            if features.deterministic > 0.7:
                return LayerLevel.L1_RULE
            elif features.semantic_depth >= 3:
                return LayerLevel.L3_SYMBOLIC
            else:
                return LayerLevel.L2_STATISTICAL
        
        if solution_type == SolutionType.LLM_BASED:
            # LLM 方案：检查是否真的需要 L4
            if (features.semantic_depth >= 4 and 
                features.context_length > 2000):
                return LayerLevel.L4_LLM
            else:
                # 可以降级到 L3
                return LayerLevel.L3_SYMBOLIC
        
        return LayerLevel.L2_STATISTICAL
    
    def _check_llm_budget(self) -> bool:
        """检查 LLM 预算"""
        if not self.layer_config.l4_enabled:
            return False
        
        # 检查每日预算
        if self._daily_cost >= self.layer_config.l4_daily_budget:
            logger.warning(f"Daily LLM budget exceeded: ${self._daily_cost:.2f}")
            return False
        
        # 检查单次预算
        if self.layer_config.l4_cost_threshold < self.layer_config.l4_budget_per_request:
            logger.warning(f"Cost threshold too low: ${self.layer_config.l4_cost_threshold:.2f}")
        
        return True
    
    def _update_cost(self, cost: float) -> None:
        """更新成本追踪"""
        self._daily_cost += cost
        self._request_count += 1
        logger.debug(f"Updated cost: ${self._daily_cost:.2f} ({self._request_count} requests)")
    
    # =========================================================================
    # 核心方法 2: 任务分解
    # =========================================================================
    
    def decompose_task(self, complex_task: Dict[str, Any]) -> List[SubTask]:
        """
        将复杂任务分解为子任务
        
        分解原则：
        1. 每个子任务应该是独立的
        2. 每个子任务应该有明确的输入输出
        3. 子任务应该能并行执行（如果可能）
        4. 子任务的总成本应该小于原任务
        
        Args:
            complex_task: 复杂任务描述
        
        Returns:
            List[SubTask]: 子任务列表
        """
        task_type = complex_task.get('type', 'unknown')
        task_id = complex_task.get('id', 'task_001')
        
        if task_type == 'causal_inference':
            return self._decompose_causal_task(complex_task, task_id)
        elif task_type == 'entity_extraction':
            return self._decompose_entity_task(complex_task, task_id)
        elif task_type == 'relation_discovery':
            return self._decompose_relation_task(complex_task, task_id)
        elif task_type == 'temporal_analysis':
            return self._decompose_temporal_task(complex_task, task_id)
        elif task_type == 'evidence_evaluation':
            return self._decompose_evidence_task(complex_task, task_id)
        else:
            return self._decompose_generic_task(complex_task, task_id)
    
    def _decompose_causal_task(self, task: Dict[str, Any], 
                               task_id: str) -> List[SubTask]:
        """
        分解因果推断任务
        
        因果推断的标准流程：
        1. 时序分析 - 检查因果时序
        2. 共现分析 - 检查是否共同出现
        3. 必要性分析 - 检查是否必要
        4. 充分性分析 - 检查是否充分
        5. 直接性分析 - 检查是否直接
        6. 混杂因素 - 排除混杂因素
        7. 综合判断 - 综合所有证据
        """
        return [
            SubTask(
                task_id=f"{task_id}_temporal",
                task_type="temporal_analysis",
                description="时序分析：检查原因是否在结果之前",
                features=TaskFeatures(
                    deterministic=0.95,
                    semantic_depth=2,
                    precision_required=0.9
                )
            ),
            SubTask(
                task_id=f"{task_id}_cooccurrence",
                task_type="cooccurrence_analysis",
                description="共现分析：检查原因和结果是否共同出现",
                features=TaskFeatures(
                    deterministic=0.8,
                    semantic_depth=2,
                    samples=task.get('sample_size', 100)
                )
            ),
            SubTask(
                task_id=f"{task_id}_necessity",
                task_type="necessity_analysis",
                description="必要性分析：检查原因是否必要",
                features=TaskFeatures(
                    semantic_depth=4,
                    generalization='high',
                    explainability_required=True
                )
            ),
            SubTask(
                task_id=f"{task_id}_sufficiency",
                task_type="sufficiency_analysis",
                description="充分性分析：检查原因是否充分",
                features=TaskFeatures(
                    semantic_depth=4,
                    generalization='high',
                    explainability_required=True
                )
            ),
            SubTask(
                task_id=f"{task_id}_directness",
                task_type="directness_analysis",
                description="直接性分析：检查因果关系是否直接",
                features=TaskFeatures(
                    semantic_depth=3,
                    rule_complexity='high'
                )
            ),
            SubTask(
                task_id=f"{task_id}_confounding",
                task_type="confounding_analysis",
                description="混杂因素分析：排除混杂因素",
                features=TaskFeatures(
                    semantic_depth=4,
                    generalization='high',
                    precision_required=0.85
                )
            ),
            SubTask(
                task_id=f"{task_id}_synthesis",
                task_type="synthesis",
                description="综合判断：综合所有证据做出因果判断",
                features=TaskFeatures(
                    rule_complexity='high',
                    generalization='high',
                    precision_required=0.9,
                    explainability_required=True
                )
            )
        ]
    
    def _decompose_entity_task(self, task: Dict[str, Any], 
                               task_id: str) -> List[SubTask]:
        """
        分解实体提取任务
        
        实体提取的标准流程：
        1. 候选识别 - 识别可能的实体
        2. 分类 - 对实体进行分类
        3. 消歧 - 消除歧义
        4. 验证 - 验证实体有效性
        """
        return [
            SubTask(
                task_id=f"{task_id}_candidate",
                task_type="candidate_identification",
                description="候选实体识别",
                features=TaskFeatures(
                    deterministic=0.8,
                    scale=task.get('text_length', 1000)
                )
            ),
            SubTask(
                task_id=f"{task_id}_classification",
                task_type="entity_classification",
                description="实体分类",
                features=TaskFeatures(
                    semantic_depth=2,
                    samples=task.get('entity_types', 10)
                )
            ),
            SubTask(
                task_id=f"{task_id}_disambiguation",
                task_type="entity_disambiguation",
                description="实体消歧",
                features=TaskFeatures(
                    semantic_depth=3,
                    rule_complexity='high',
                    precision_required=0.85
                )
            ),
            SubTask(
                task_id=f"{task_id}_validation",
                task_type="entity_validation",
                description="实体验证",
                features=TaskFeatures(
                    deterministic=0.9,
                    precision_required=0.9
                )
            )
        ]
    
    def _decompose_relation_task(self, task: Dict[str, Any], 
                                 task_id: str) -> List[SubTask]:
        """
        分解关系发现任务
        
        关系发现的标准流程：
        1. 关系对生成 - 生成可能的关系对
        2. 关系分类 - 对关系进行分类
        3. 置信度评分 - 评估关系置信度
        4. 验证 - 验证关系有效性
        """
        return [
            SubTask(
                task_id=f"{task_id}_generation",
                task_type="pair_generation",
                description="关系对生成",
                features=TaskFeatures(
                    deterministic=0.85,
                    scale=task.get('entity_pairs', 100)
                )
            ),
            SubTask(
                task_id=f"{task_id}_classification",
                task_type="relation_classification",
                description="关系分类",
                features=TaskFeatures(
                    semantic_depth=3,
                    samples=task.get('relation_types', 20)
                )
            ),
            SubTask(
                task_id=f"{task_id}_scoring",
                task_type="confidence_scoring",
                description="置信度评分",
                features=TaskFeatures(
                    rule_complexity='medium',
                    generalization='high',
                    precision_required=0.8
                )
            ),
            SubTask(
                task_id=f"{task_id}_validation",
                task_type="relation_validation",
                description="关系验证",
                features=TaskFeatures(
                    deterministic=0.9,
                    precision_required=0.85
                )
            )
        ]
    
    def _decompose_temporal_task(self, task: Dict[str, Any], 
                                 task_id: str) -> List[SubTask]:
        """分解时间分析任务"""
        return [
            SubTask(
                task_id=f"{task_id}_extraction",
                task_type="time_extraction",
                description="时间表达式提取",
                features=TaskFeatures(
                    deterministic=0.9,
                    scale=task.get('text_length', 1000)
                )
            ),
            SubTask(
                task_id=f"{task_id}_normalization",
                task_type="time_normalization",
                description="时间标准化",
                features=TaskFeatures(
                    rule_complexity='high',
                    deterministic=0.95
                )
            ),
            SubTask(
                task_id=f"{task_id}_ordering",
                task_type="temporal_ordering",
                description="时间排序",
                features=TaskFeatures(
                    deterministic=0.95,
                    precision_required=0.95
                )
            )
        ]
    
    def _decompose_evidence_task(self, task: Dict[str, Any], 
                                 task_id: str) -> List[SubTask]:
        """分解证据评估任务"""
        return [
            SubTask(
                task_id=f"{task_id}_source_check",
                task_type="source_verification",
                description="来源验证",
                features=TaskFeatures(
                    deterministic=0.9,
                    rule_complexity='medium'
                )
            ),
            SubTask(
                task_id=f"{task_id}_quality_check",
                task_type="quality_assessment",
                description="质量评估",
                features=TaskFeatures(
                    semantic_depth=3,
                    generalization='medium'
                )
            ),
            SubTask(
                task_id=f"{task_id}_weighting",
                task_type="evidence_weighting",
                description="证据权重计算",
                features=TaskFeatures(
                    rule_complexity='high',
                    precision_required=0.85
                )
            ),
            SubTask(
                task_id=f"{task_id}_synthesis",
                task_type="evidence_synthesis",
                description="证据综合",
                features=TaskFeatures(
                    semantic_depth=4,
                    generalization='high',
                    explainability_required=True
                )
            )
        ]
    
    def _decompose_generic_task(self, task: Dict[str, Any], 
                                task_id: str) -> List[SubTask]:
        """分解通用任务"""
        return [
            SubTask(
                task_id=f"{task_id}_preprocess",
                task_type="preprocessing",
                description="预处理",
                features=TaskFeatures(
                    deterministic=0.8,
                    scale=task.get('scale', 1000)
                )
            ),
            SubTask(
                task_id=f"{task_id}_process",
                task_type="processing",
                description="核心处理",
                features=TaskFeatures(
                    semantic_depth=task.get('semantic_depth', 2),
                    generalization=task.get('generalization', 'medium')
                )
            ),
            SubTask(
                task_id=f"{task_id}_postprocess",
                task_type="postprocessing",
                description="后处理",
                features=TaskFeatures(
                    deterministic=0.9,
                    precision_required=0.85
                )
            )
        ]
    
    # =========================================================================
    # 核心方法 3: 任务执行
    # =========================================================================
    
    def execute_subtask(self, subtask: SubTask, 
                       context: Optional[Dict[str, Any]] = None) -> TaskResult:
        """
        执行子任务
        
        Args:
            subtask: 子任务
            context: 执行上下文
        
        Returns:
            TaskResult: 任务执行结果
        """
        import time
        start_time = time.time()
        
        try:
            # 根据分层级别选择执行方法
            if subtask.layer_level == LayerLevel.L1_RULE:
                result, cost = self._execute_l1(subtask, context)
            elif subtask.layer_level == LayerLevel.L2_STATISTICAL:
                result, cost = self._execute_l2(subtask, context)
            elif subtask.layer_level == LayerLevel.L3_SYMBOLIC:
                result, cost = self._execute_l3(subtask, context)
            elif subtask.layer_level == LayerLevel.L4_LLM:
                result, cost = self._execute_l4(subtask, context)
            else:
                raise ValueError(f"Unknown layer level: {subtask.layer_level}")
            
            # 质量评估
            quality = self._evaluate_result(subtask, result)
            
            execution_time = time.time() - start_time
            
            return TaskResult(
                task_id=subtask.task_id,
                success=True,
                result=result,
                solution_type=subtask.solution or SolutionType.HYBRID,
                layer_level=subtask.layer_level or LayerLevel.L2_STATISTICAL,
                quality_score=quality,
                cost=cost,
                execution_time=execution_time
            )
        
        except Exception as e:
            subtask.error = str(e)
            execution_time = time.time() - start_time
            
            return TaskResult(
                task_id=subtask.task_id,
                success=False,
                result=None,
                solution_type=subtask.solution or SolutionType.HYBRID,
                layer_level=subtask.layer_level or LayerLevel.L2_STATISTICAL,
                quality_score=0.0,
                cost=0.0,
                execution_time=execution_time,
                error_message=str(e)
            )
    
    def _execute_l1(self, subtask: SubTask, 
                   context: Optional[Dict[str, Any]] = None) -> Tuple[Any, float]:
        """
        L1: 规则引擎执行
        
        特点：
        - 成本最低（几乎免费）
        - 速度最快（毫秒级）
        - 可解释性最好
        - 但泛化能力有限
        """
        task_type = subtask.task_type
        
        if task_type in self.rule_engines:
            rule_func = self.rule_engines[task_type]
            result = rule_func(context or {})
            return result, 0.0  # 规则执行几乎免费
        else:
            # 没有对应规则，降级到 L2
            logger.warning(f"No rule for {task_type}, falling back to L2")
            return self._execute_l2(subtask, context)
    
    def _execute_l2(self, subtask: SubTask, 
                   context: Optional[Dict[str, Any]] = None) -> Tuple[Any, float]:
        """
        L2: 统计方法执行
        
        特点：
        - 成本低（计算成本）
        - 速度较快（秒级）
        - 可解释性中等
        - 泛化能力中等
        """
        task_type = subtask.task_type
        
        if task_type in self.statistical_methods:
            stat_func = self.statistical_methods[task_type]
            result = stat_func(context or {})
            # 统计方法成本很低
            return result, 0.001
        else:
            # 没有对应方法，降级到 L3
            logger.warning(f"No statistical method for {task_type}, falling back to L3")
            return self._execute_l3(subtask, context)
    
    def _execute_l3(self, subtask: SubTask, 
                   context: Optional[Dict[str, Any]] = None) -> Tuple[Any, float]:
        """
        L3: 符号推理执行
        
        特点：
        - 成本中等
        - 速度中等
        - 可解释性好
        - 泛化能力较好
        """
        task_type = subtask.task_type
        
        if task_type in self.symbolic_reasoners:
            reasoner = self.symbolic_reasoners[task_type]
            result = reasoner(context or {})
            # 符号推理成本中等
            return result, 0.01
        else:
            # 没有对应推理器，降级到 L4
            logger.warning(f"No symbolic reasoner for {task_type}, falling back to L4")
            return self._execute_l4(subtask, context)
    
    def _execute_l4(self, subtask: SubTask, 
                   context: Optional[Dict[str, Any]] = None) -> Tuple[Any, float]:
        """
        L4: 大模型执行
        
        特点：
        - 成本最高
        - 速度较慢
        - 可解释性差
        - 泛化能力最强
        
        注意：
        - 使用前必须检查预算
        - 需要记录成本
        - 需要控制调用频率
        """
        if not self._llm_client:
            raise RuntimeError("LLM client not set. Call set_llm_client() first.")
        
        # 构建 prompt
        prompt = self._build_prompt(subtask, context or {})
        
        # 调用 LLM
        response = self._llm_client.generate(prompt)
        
        # 解析结果
        result = self._parse_llm_response(subtask, response)
        
        # 估算成本（简化实现，实际应该根据 token 计算）
        cost = self._estimate_llm_cost(prompt, response)
        
        # 更新成本追踪
        self._update_cost(cost)
        
        return result, cost
    
    def _build_prompt(self, subtask: SubTask, 
                     context: Dict[str, Any]) -> str:
        """构建 LLM prompt"""
        # 简化实现，实际应该根据任务类型构建不同的 prompt
        return f"""
Task: {subtask.description}
Type: {subtask.task_type}

Context:
{context}

Please provide a detailed analysis.
"""
    
    def _parse_llm_response(self, subtask: SubTask, response: str) -> Any:
        """解析 LLM 响应"""
        # 简化实现，实际应该根据任务类型解析
        return response
    
    def _estimate_llm_cost(self, prompt: str, response: str) -> float:
        """估算 LLM 成本（简化实现）"""
        # 实际应该根据 token 数量和模型定价计算
        prompt_tokens = len(prompt) // 4
        response_tokens = len(response) // 4
        total_tokens = prompt_tokens + response_tokens
        
        # 假设每 1000 tokens 0.002 美元
        return total_tokens * 0.002 / 1000
    
    # =========================================================================
    # 核心方法 4: 质量评估
    # =========================================================================
    
    def _evaluate_result(self, subtask: SubTask, result: Any) -> float:
        """
        评估结果质量
        
        评估维度：
        1. 一致性 - 结果是否自洽
        2. 完整性 - 是否回答了所有问题
        3. 准确性 - 是否与已知事实一致
        4. 可解释性 - 是否有清晰的推理过程
        """
        scores = []
        
        # 1. 一致性
        if 'consistency' in self.quality_evaluators:
            score = self.quality_evaluators['consistency'](result, subtask)
            scores.append(score)
        
        # 2. 完整性
        if 'completeness' in self.quality_evaluators:
            score = self.quality_evaluators['completeness'](result, subtask)
            scores.append(score)
        
        # 3. 准确性
        if 'accuracy' in self.quality_evaluators:
            score = self.quality_evaluators['accuracy'](result, subtask)
            scores.append(score)
        
        if not scores:
            return 0.5  # 默认分数
        
        return sum(scores) / len(scores)
    
    def _eval_consistency(self, result: Any, subtask: SubTask) -> float:
        """评估一致性"""
        # 简化实现
        if result is None:
            return 0.0
        return 0.8  # 默认给较高分
    
    def _eval_completeness(self, result: Any, subtask: SubTask) -> float:
        """评估完整性"""
        # 简化实现
        if result is None:
            return 0.0
        return 0.8
    
    def _eval_accuracy(self, result: Any, subtask: SubTask) -> float:
        """评估准确性"""
        # 简化实现
        if result is None:
            return 0.0
        return 0.8
    
    # =========================================================================
    # L1: 规则引擎实现
    # =========================================================================
    
    def _rule_temporal_check(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        L1: 时序检查规则
        
        规则：
        1. 原因必须在结果之前
        2. 时间间隔不能太长（默认 100 年）
        3. 支持模糊时间处理
        """
        cause_event = context.get('cause_event')
        effect_event = context.get('effect_event')
        max_interval = context.get('max_interval_years', 100)
        
        if not cause_event or not effect_event:
            return {'valid': False, 'reason': 'Missing events'}
        
        cause_time = cause_event.get('timestamp')
        effect_time = effect_event.get('timestamp')
        
        if cause_time is None or effect_time is None:
            return {'valid': False, 'reason': 'Missing timestamps'}
        
        # 简化实现：假设时间是数字
        if isinstance(cause_time, (int, float)) and isinstance(effect_time, (int, float)):
            if cause_time <= effect_time:
                return {
                    'valid': True,
                    'interval': effect_time - cause_time,
                    'reason': 'Cause precedes effect'
                }
            else:
                return {
                    'valid': False,
                    'reason': 'Cause occurs after effect'
                }
        
        # 模糊时间处理（简化）
        return {'valid': True, 'reason': 'Fuzzy time, assumed valid'}
    
    def _rule_temporal_analysis(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        L1: 时序分析规则（temporal_analysis 任务使用）
        
        规则：
        1. 检查原因事件的时间
        2. 检查结果事件的时间
        3. 验证时序关系
        """
        return self._rule_temporal_check(context)
    
    def _rule_keyword_match(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """L1: 关键词匹配规则"""
        text = context.get('text', '')
        keywords = context.get('keywords', [])
        
        matches = []
        for keyword in keywords:
            if keyword.lower() in text.lower():
                matches.append(keyword)
        
        return {
            'matched': len(matches) > 0,
            'matches': matches,
            'match_rate': len(matches) / len(keywords) if keywords else 0
        }
    
    def _rule_pattern_match(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """L1: 模式匹配规则"""
        # 简化实现
        return {'matched': False, 'patterns': []}
    
    # =========================================================================
    # L2: 统计方法实现
    # =========================================================================
    
    def _stat_similarity(self, context: Dict[str, Any]) -> float:
        """L2: 相似度计算"""
        # 简化实现：余弦相似度
        vec1 = context.get('vector1', [])
        vec2 = context.get('vector2', [])
        
        if not vec1 or not vec2:
            return 0.0
        
        # 简化计算
        return 0.5
    
    def _stat_co_occurrence(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """L2: 共现分析"""
        events = context.get('events', [])
        window_size = context.get('window_size', 10)
        
        # 简化实现
        return {
            'co_occurrence_count': len(events) // 2,
            'co_occurrence_rate': 0.5
        }
    
    # =========================================================================
    # L3: 符号推理实现
    # =========================================================================
    
    def _symbolic_logic(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """L3: 逻辑推理"""
        # 简化实现
        return {
            'inference': 'valid',
            'confidence': 0.8
        }
    
    def _symbolic_causal_chain(self, context: Dict[str, Any]) -> List[str]:
        """L3: 因果链推理"""
        # 简化实现
        return ['event_a', 'event_b', 'event_c']
    
    # =========================================================================
    # 工具方法
    # =========================================================================
    
    def reset_daily_cost(self) -> None:
        """重置每日成本（应该在每天开始时调用）"""
        self._daily_cost = 0.0
        self._request_count = 0
        logger.info("Daily cost reset")
    
    def get_cost_stats(self) -> Dict[str, float]:
        """获取成本统计"""
        return {
            'daily_cost': self._daily_cost,
            'request_count': self._request_count,
            'remaining_budget': self.layer_config.l4_daily_budget - self._daily_cost
        }
    
    def register_rule(self, name: str, rule_func: Callable) -> None:
        """注册自定义规则"""
        self.rule_engines[name] = rule_func
        logger.info(f"Registered rule: {name}")
    
    def register_statistical_method(self, name: str, method_func: Callable) -> None:
        """注册自定义统计方法"""
        self.statistical_methods[name] = method_func
        logger.info(f"Registered statistical method: {name}")
    
    def register_symbolic_reasoner(self, name: str, reasoner_func: Callable) -> None:
        """注册自定义符号推理器"""
        self.symbolic_reasoners[name] = reasoner_func
        logger.info(f"Registered symbolic reasoner: {name}")
