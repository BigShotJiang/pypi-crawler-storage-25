"""
迭代工作流 - 支持持续优化和改进

核心思想：
1. 分析当前数据和结果
2. 识别问题和改进机会
3. 选择最优解决方案
4. 应用改进
5. 评估改进效果
6. 生成下一步建议

迭代流程：
    数据输入
       ↓
    分析 → 识别问题 → 选择方案 → 应用改进 → 评估效果
       ↑                                              ↓
       └────────────────── 迭代优化 ←──────────────────┘

使用示例：
    from generic_causal_architecture.methods import IterativeWorkflow, LancetMethod
    from generic_causal_architecture.core import CausalEngine
    from generic_causal_architecture.config import Config
    
    config = Config.from_yaml("config/default.yaml")
    storage = config.get_storage()
    storage.initialize()
    
    engine = CausalEngine(storage)
    lancet = LancetMethod(config.layer)
    
    workflow = IterativeWorkflow(engine, lancet)
    
    # 执行迭代
    result = workflow.run_iteration(
        data=[event1, event2, ...],
        current_version=1,
        target_quality=0.9
    )
    
    # 多轮迭代
    while result.quality < target_quality and result.version < max_versions:
        result = workflow.run_iteration(
            data=result.improved_data,
            current_version=result.version + 1
        )
"""

from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging
import time

from .lancet_method import LancetMethod, SubTask, TaskResult, LayerLevel, SolutionType

logger = logging.getLogger(__name__)


class IssueType(Enum):
    """问题类型"""
    LOW_QUALITY = "low_quality"  # 质量低
    HIGH_COST = "high_cost"  # 成本高
    SLOW_SPEED = "slow_speed"  # 速度慢
    INCONSISTENT = "inconsistent"  # 不一致
    INCOMPLETE = "incomplete"  # 不完整
    INACCURATE = "inaccurate"  # 不准确


class ImprovementType(Enum):
    """改进类型"""
    REFINEMENT = "refinement"  # 精细化
    OPTIMIZATION = "optimization"  # 优化
    CORRECTION = "correction"  # 修正
    EXPANSION = "expansion"  # 扩展
    SIMPLIFICATION = "simplification"  # 简化


@dataclass
class Issue:
    """识别到的问题"""
    issue_id: str
    issue_type: IssueType
    description: str
    severity: float  # 严重程度 (0-1)
    affected_tasks: List[str]  # 受影响的子任务 ID
    root_cause: Optional[str] = None
    suggested_action: Optional[str] = None


@dataclass
class Improvement:
    """改进措施"""
    improvement_id: str
    improvement_type: ImprovementType
    description: str
    target_issues: List[str]  # 针对的问题 ID
    expected_benefit: str
    implementation_cost: float  # 实现成本 (0-1)
    priority: float  # 优先级 (0-1)


@dataclass
class IterationMetrics:
    """迭代指标"""
    version: int
    overall_quality: float
    total_cost: float
    total_time: float
    task_count: int
    success_rate: float
    avg_quality: float
    quality_improvement: float  # 相比上一轮的质量提升
    cost_change: float  # 相比上一轮的成本变化
    issues_identified: int
    improvements_applied: int


@dataclass
class IterationResult:
    """迭代结果"""
    version: int
    success: bool
    improved_data: Any
    metrics: IterationMetrics
    issues: List[Issue]
    improvements: List[Improvement]
    next_steps: List[str]
    error_message: Optional[str] = None


class IterativeWorkflow:
    """
    迭代工作流实现
    
    核心功能：
    1. 数据分析 - 分析当前数据和结果
    2. 问题识别 - 识别质量和性能问题
    3. 方案选择 - 为每个问题选择最优解决方案
    4. 改进应用 - 应用改进措施
    5. 效果评估 - 评估改进效果
    6. 建议生成 - 生成下一步建议
    
    设计原则：
    - 数据驱动（基于指标决策）
    - 持续优化（支持多轮迭代）
    - 成本敏感（考虑改进成本）
    - 质量第一（不为了省钱牺牲质量）
    """
    
    def __init__(self, causal_engine: Any, lancet_method: LancetMethod):
        """
        初始化迭代工作流
        
        Args:
            causal_engine: 因果引擎实例
            lancet_method: 柳叶刀方法实例
        """
        self.causal_engine = causal_engine
        self.lancet_method = lancet_method
        
        # 历史指标（用于对比）
        self._history: List[IterationMetrics] = []
        
        # 问题库（用于模式识别）
        self._issue_patterns: Dict[str, Issue] = {}
        
        # 改进库（用于快速应用）
        self._improvement_library: Dict[str, Improvement] = {}
        
        self._register_default_improvements()
    
    def _register_default_improvements(self) -> None:
        """注册默认改进措施"""
        self._improvement_library['refine_decomposition'] = Improvement(
            improvement_id='refine_decomposition',
            improvement_type=ImprovementType.REFINEMENT,
            description="细化任务分解",
            target_issues=[],
            expected_benefit="提高任务针对性和执行质量",
            implementation_cost=0.3,
            priority=0.8
        )
        
        self._improvement_library['optimize_layer'] = Improvement(
            improvement_id='optimize_layer',
            improvement_type=ImprovementType.OPTIMIZATION,
            description="优化分层调用",
            target_issues=[],
            expected_benefit="降低成本，提高速度",
            implementation_cost=0.2,
            priority=0.7
        )
        
        self._improvement_library['add_validation'] = Improvement(
            improvement_id='add_validation',
            improvement_type=ImprovementType.EXPANSION,
            description="添加验证步骤",
            target_issues=[],
            expected_benefit="提高准确性和一致性",
            implementation_cost=0.4,
            priority=0.9
        )
        
        self._improvement_library['simplify_task'] = Improvement(
            improvement_id='simplify_task',
            improvement_type=ImprovementType.SIMPLIFICATION,
            description="简化复杂任务",
            target_issues=[],
            expected_benefit="降低执行难度，提高成功率",
            implementation_cost=0.3,
            priority=0.6
        )
    
    def run_iteration(self, 
                     data: Any,
                     current_version: int = 1,
                     target_quality: float = 0.9,
                     max_iterations: int = 5) -> IterationResult:
        """
        执行一轮迭代优化
        
        迭代流程：
        1. 分析当前数据
        2. 识别问题和改进机会
        3. 为每个问题选择解决方案
        4. 应用改进
        5. 评估改进效果
        6. 生成下一步建议
        
        Args:
            data: 输入数据（通常是事件列表或任务列表）
            current_version: 当前版本号
            target_quality: 目标质量 (0-1)
            max_iterations: 最大迭代次数
        
        Returns:
            IterationResult: 迭代结果
        """
        start_time = time.time()
        
        try:
            logger.info(f"Starting iteration {current_version}")
            
            # 1. 分析当前数据
            analysis_results = self._analyze_data(data)
            
            # 2. 识别问题和改进机会
            issues = self._identify_issues(analysis_results, data)
            
            # 3. 为每个问题选择解决方案
            solutions = self._select_solutions(issues)
            
            # 4. 应用改进
            improvements = self._apply_improvements(solutions, data)
            
            # 5. 评估改进效果
            metrics = self._evaluate_improvements(improvements, data, current_version)
            
            # 6. 生成下一步建议
            next_steps = self._generate_next_steps(metrics, issues, target_quality)
            
            # 记录历史
            self._history.append(metrics)
            
            iteration_time = time.time() - start_time
            
            logger.info(
                f"Iteration {current_version} completed in {iteration_time:.2f}s. "
                f"Quality: {metrics.overall_quality:.2f}, "
                f"Cost: ${metrics.total_cost:.2f}"
            )
            
            return IterationResult(
                version=current_version,
                success=metrics.overall_quality >= target_quality,
                improved_data=data,  # 简化实现，实际应该是改进后的数据
                metrics=metrics,
                issues=issues,
                improvements=improvements,
                next_steps=next_steps
            )
        
        except Exception as e:
            iteration_time = time.time() - start_time
            logger.error(f"Iteration {current_version} failed: {e}")
            
            return IterationResult(
                version=current_version,
                success=False,
                improved_data=data,
                metrics=IterationMetrics(
                    version=current_version,
                    overall_quality=0.0,
                    total_cost=0.0,
                    total_time=iteration_time,
                    task_count=0,
                    success_rate=0.0,
                    avg_quality=0.0,
                    quality_improvement=0.0,
                    cost_change=0.0,
                    issues_identified=0,
                    improvements_applied=0
                ),
                issues=[],
                improvements=[],
                next_steps=[],
                error_message=str(e)
            )
    
    def _analyze_data(self, data: Any) -> Dict[str, Any]:
        """
        分析当前数据
        
        分析维度：
        1. 数据规模
        2. 数据质量
        3. 任务复杂度
        4. 历史表现
        
        Args:
            data: 输入数据
        
        Returns:
            Dict[str, Any]: 分析结果
        """
        # 简化实现
        return {
            'data_size': len(data) if hasattr(data, '__len__') else 1,
            'data_quality': 0.7,  # 假设值
            'complexity': 0.5,  # 假设值
            'historical_performance': self._get_historical_performance()
        }
    
    def _get_historical_performance(self) -> Dict[str, float]:
        """获取历史表现"""
        if not self._history:
            return {'avg_quality': 0.5, 'avg_cost': 0.1, 'success_rate': 0.8}
        
        return {
            'avg_quality': sum(h.overall_quality for h in self._history) / len(self._history),
            'avg_cost': sum(h.total_cost for h in self._history) / len(self._history),
            'success_rate': sum(h.success_rate for h in self._history) / len(self._history)
        }
    
    def _identify_issues(self, analysis: Dict[str, Any], 
                        data: Any) -> List[Issue]:
        """
        识别问题和改进机会
        
        识别维度：
        1. 质量问题（低置信度、不一致、不准确）
        2. 成本问题（超出预算）
        3. 性能问题（速度慢）
        4. 完整性问题（缺失信息）
        
        Args:
            analysis: 分析结果
            data: 输入数据
        
        Returns:
            List[Issue]: 问题列表
        """
        issues = []
        issue_counter = 0
        
        # 1. 检查质量
        if analysis.get('data_quality', 1.0) < 0.8:
            issue_counter += 1
            issues.append(Issue(
                issue_id=f"issue_{issue_counter:03d}",
                issue_type=IssueType.LOW_QUALITY,
                description=f"数据质量低：{analysis.get('data_quality', 0):.2f}",
                severity=1.0 - analysis.get('data_quality', 0),
                affected_tasks=['all'],
                root_cause="可能是任务分解不够细化或执行方法不当",
                suggested_action="细化任务分解，选择合适的执行方法"
            ))
        
        # 2. 检查历史表现
        hist = analysis.get('historical_performance', {})
        if hist.get('avg_quality', 1.0) < 0.7:
            issue_counter += 1
            issues.append(Issue(
                issue_id=f"issue_{issue_counter:03d}",
                issue_type=IssueType.INACCURATE,
                description=f"历史平均质量低：{hist.get('avg_quality', 0):.2f}",
                severity=0.8,
                affected_tasks=['all'],
                root_cause="可能是系统性问题",
                suggested_action="全面审查任务分解和执行策略"
            ))
        
        # 3. 检查复杂度
        if analysis.get('complexity', 0) > 0.8:
            issue_counter += 1
            issues.append(Issue(
                issue_id=f"issue_{issue_counter:03d}",
                issue_type=IssueType.INCOMPLETE,
                description="任务复杂度过高",
                severity=0.6,
                affected_tasks=['complex_tasks'],
                root_cause="任务可能过于复杂，需要分解",
                suggested_action="进一步分解复杂任务"
            ))
        
        # 4. 使用 Lancet Method 的任务分解来识别潜在问题
        if hasattr(data, '__iter__') and len(data) > 0:
            # 对每个数据项进行任务分解分析
            for i, item in enumerate(data[:5]):  # 限制分析前 5 个
                if isinstance(item, dict) and 'type' in item:
                    subtasks = self.lancet_method.decompose_task(item)
                    for subtask in subtasks:
                        # 检查子任务特征
                        if subtask.features.precision_required > 0.9:
                            issue_counter += 1
                            issues.append(Issue(
                                issue_id=f"issue_{issue_counter:03d}",
                                issue_type=IssueType.INACCURATE,
                                description=f"子任务 {subtask.task_id} 精度要求高",
                                severity=0.5,
                                affected_tasks=[subtask.task_id],
                                root_cause="高精度要求可能导致执行困难",
                                suggested_action="考虑使用混合方案或多重验证"
                            ))
        
        logger.info(f"Identified {len(issues)} issues")
        return issues
    
    def _select_solutions(self, issues: List[Issue]) -> Dict[str, Any]:
        """
        为每个问题选择解决方案
        
        选择策略：
        1. 根据问题类型选择改进措施
        2. 考虑成本和收益
        3. 考虑优先级
        4. 避免冲突的改进
        
        Args:
            issues: 问题列表
        
        Returns:
            Dict[str, Any]: 解决方案字典
        """
        solutions = {}
        
        for issue in issues:
            solution = self._select_solution_for_issue(issue)
            solutions[issue.issue_id] = solution
            logger.debug(f"Selected solution for {issue.issue_id}: {solution}")
        
        return solutions
    
    def _select_solution_for_issue(self, issue: Issue) -> Dict[str, Any]:
        """为单个问题选择解决方案"""
        
        if issue.issue_type == IssueType.LOW_QUALITY:
            return {
                'action': 'refine_decomposition',
                'method': 'Use LancetMethod to decompose tasks more finely',
                'expected_improvement': 0.2,
                'cost': 0.3
            }
        
        elif issue.issue_type == IssueType.INCONSISTENT:
            return {
                'action': 'add_validation',
                'method': 'Add consistency check step',
                'expected_improvement': 0.25,
                'cost': 0.4
            }
        
        elif issue.issue_type == IssueType.INACCURATE:
            return {
                'action': 'optimize_layer',
                'method': 'Upgrade layer level for critical tasks',
                'expected_improvement': 0.3,
                'cost': 0.5
            }
        
        elif issue.issue_type == IssueType.INCOMPLETE:
            return {
                'action': 'simplify_task',
                'method': 'Simplify complex tasks',
                'expected_improvement': 0.15,
                'cost': 0.3
            }
        
        elif issue.issue_type == IssueType.HIGH_COST:
            return {
                'action': 'optimize_layer',
                'method': 'Downgrade layer level where possible',
                'expected_improvement': -0.1,  # 质量可能略微下降
                'cost_saving': 0.4
            }
        
        elif issue.issue_type == IssueType.SLOW_SPEED:
            return {
                'action': 'optimize_layer',
                'method': 'Use L1/L2 instead of L3/L4 where possible',
                'expected_improvement': 0.0,  # 速度提升，质量不变
                'speed_improvement': 0.5
            }
        
        else:
            return {
                'action': 'refinement',
                'method': 'General refinement',
                'expected_improvement': 0.1,
                'cost': 0.2
            }
    
    def _apply_improvements(self, solutions: Dict[str, Any], 
                           data: Any) -> List[Improvement]:
        """
        应用改进
        
        应用策略：
        1. 按优先级排序
        2. 避免冲突
        3. 渐进式应用（避免大幅改动）
        4. 记录每个改进的效果
        
        Args:
            solutions: 解决方案字典
            data: 输入数据
        
        Returns:
            List[Improvement]: 应用的改进列表
        """
        improvements = []
        improvement_counter = 0
        
        for issue_id, solution in solutions.items():
            improvement_counter += 1
            
            # 创建改进措施
            improvement = Improvement(
                improvement_id=f"improvement_{improvement_counter:03d}",
                improvement_type=ImprovementType.REFINEMENT,  # 简化实现
                description=solution.get('method', 'General refinement'),
                target_issues=[issue_id],
                expected_benefit=f"Expected improvement: {solution.get('expected_improvement', 0):.2f}",
                implementation_cost=solution.get('cost', 0.3),
                priority=0.7  # 简化实现
            )
            
            improvements.append(improvement)
            
            # 实际应用改进（简化实现）
            # 实际应该修改数据或任务执行策略
            logger.info(f"Applied improvement: {improvement.improvement_id}")
        
        return improvements
    
    def _evaluate_improvements(self, improvements: List[Improvement], 
                              data: Any,
                              current_version: int) -> IterationMetrics:
        """
        评估改进效果
        
        评估维度：
        1. 整体质量
        2. 总成本
        3. 执行时间
        4. 任务成功率
        5. 质量提升（相比上一轮）
        6. 成本变化（相比上一轮）
        
        Args:
            improvements: 改进列表
            data: 输入数据
            current_version: 当前版本号
        
        Returns:
            IterationMetrics: 迭代指标
        """
        # 简化实现：生成模拟指标
        # 实际应该根据实际执行结果计算
        
        # 计算基础指标
        task_count = len(data) if hasattr(data, '__len__') else 1
        success_rate = 0.8 + len(improvements) * 0.02  # 每应用一个改进，成功率提升 2%
        avg_quality = 0.75 + len(improvements) * 0.03  # 每应用一个改进，质量提升 3%
        
        # 限制在合理范围内
        success_rate = min(1.0, success_rate)
        avg_quality = min(1.0, avg_quality)
        
        # 计算成本（简化）
        total_cost = task_count * 0.01  # 每个任务 0.01 元
        total_cost += sum(imp.implementation_cost * 0.1 for imp in improvements)
        
        # 计算相比上一轮的变化
        if self._history:
            prev_metrics = self._history[-1]
            quality_improvement = avg_quality - prev_metrics.overall_quality
            cost_change = total_cost - prev_metrics.total_cost
        else:
            quality_improvement = 0.1  # 第一轮迭代，假设有提升
            cost_change = 0.0
        
        return IterationMetrics(
            version=current_version,
            overall_quality=avg_quality,
            total_cost=total_cost,
            total_time=0.0,  # 简化实现
            task_count=task_count,
            success_rate=success_rate,
            avg_quality=avg_quality,
            quality_improvement=quality_improvement,
            cost_change=cost_change,
            issues_identified=len(improvements),
            improvements_applied=len(improvements)
        )
    
    def _generate_next_steps(self, metrics: IterationMetrics,
                            issues: List[Issue],
                            target_quality: float) -> List[str]:
        """
        生成下一步建议
        
        建议策略：
        1. 如果达到目标质量 → 建议结束迭代
        2. 如果质量提升明显 → 建议继续当前策略
        3. 如果质量提升缓慢 → 建议调整策略
        4. 如果成本过高 → 建议优化成本
        5. 如果有未解决问题 → 建议优先解决
        
        Args:
            metrics: 迭代指标
            issues: 问题列表
            target_quality: 目标质量
        
        Returns:
            List[str]: 下一步建议列表
        """
        next_steps = []
        
        # 1. 检查是否达到目标
        if metrics.overall_quality >= target_quality:
            next_steps.append("✅ 已达到目标质量，可以考虑结束迭代")
            return next_steps
        
        # 2. 检查质量提升趋势
        if metrics.quality_improvement > 0.1:
            next_steps.append("质量提升明显，建议继续当前迭代策略")
        elif metrics.quality_improvement > 0.05:
            next_steps.append("质量提升放缓，考虑调整改进策略")
        else:
            next_steps.append("质量提升缓慢，建议重新审视问题识别和解决方案")
        
        # 3. 检查成本
        if metrics.total_cost > 1.0:  # 假设 1 元是阈值
            next_steps.append("成本较高，考虑优化分层调用策略")
        
        # 4. 检查未解决问题
        high_severity_issues = [i for i in issues if i.severity > 0.7]
        if high_severity_issues:
            next_steps.append(
                f"有 {len(high_severity_issues)} 个高严重性问题需要优先解决"
            )
        
        # 5. 检查迭代次数
        if metrics.version >= 5:
            next_steps.append("已进行多轮迭代，考虑接受当前结果或大幅调整策略")
        
        return next_steps
    
    def run_multi_iteration(self,
                           data: Any,
                           start_version: int = 1,
                           target_quality: float = 0.9,
                           max_iterations: int = 5) -> List[IterationResult]:
        """
        执行多轮迭代
        
        Args:
            data: 输入数据
            start_version: 起始版本
            target_quality: 目标质量
            max_iterations: 最大迭代次数
        
        Returns:
            List[IterationResult]: 每轮迭代的结果
        """
        results = []
        current_data = data
        current_version = start_version
        
        for i in range(max_iterations):
            logger.info(f"Starting iteration {current_version}")
            
            result = self.run_iteration(
                data=current_data,
                current_version=current_version,
                target_quality=target_quality
            )
            
            results.append(result)
            
            # 检查是否达到目标
            if result.success:
                logger.info(f"Reached target quality at version {current_version}")
                break
            
            # 更新数据（简化实现，实际应该使用改进后的数据）
            current_data = result.improved_data
            current_version += 1
        
        return results
    
    def get_iteration_history(self) -> List[IterationMetrics]:
        """获取迭代历史"""
        return self._history.copy()
    
    def get_quality_trend(self) -> str:
        """获取质量趋势"""
        if len(self._history) < 2:
            return "insufficient_data"
        
        recent = self._history[-1].overall_quality
        previous = self._history[-2].overall_quality
        
        if recent > previous + 0.05:
            return "improving_fast"
        elif recent > previous:
            return "improving_slow"
        elif abs(recent - previous) < 0.02:
            return "stable"
        else:
            return "declining"
    
    def get_cost_trend(self) -> str:
        """获取成本趋势"""
        if len(self._history) < 2:
            return "insufficient_data"
        
        recent = self._history[-1].total_cost
        previous = self._history[-2].total_cost
        
        if recent > previous * 1.2:
            return "increasing_fast"
        elif recent > previous:
            return "increasing_slow"
        elif abs(recent - previous) < 0.01:
            return "stable"
        else:
            return "decreasing"
