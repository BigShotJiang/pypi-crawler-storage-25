"""
领域适配器包 - 将通用架构适配到具体领域

当前包含：
1. HistoryAdapter - 历史领域适配器
2. 更多领域适配器待添加（经济、政治、军事、科技等）

使用示例：
    from generic_causal_architecture.adapters import HistoryAdapter
    adapter = HistoryAdapter()
"""

from .history_adapter import (
    HistoryAdapter,
    HistoricalEvent,
    HistoricalEntity,
    CausalAnalysisResult,
    HistoricalPeriod,
    EvidenceLevel,
    EventType,
)

__all__ = [
    'HistoryAdapter',
    'HistoricalEvent',
    'HistoricalEntity',
    'CausalAnalysisResult',
    'HistoricalPeriod',
    'EvidenceLevel',
    'EventType',
]
