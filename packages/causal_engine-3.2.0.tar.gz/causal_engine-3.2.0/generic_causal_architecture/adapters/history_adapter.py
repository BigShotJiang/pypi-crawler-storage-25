"""
历史领域适配器 - 通用架构在历史领域的具体实现

重要说明：
1. 这个适配器展示如何将通用因果架构应用到具体领域
2. 包含历史领域特定的事件解析、时间处理、证据评估
3. 支持中国历史纪年、模糊时间、多重证据
4. 生产级实现：完整的错误处理、类型注解、日志记录

核心功能：
1. 历史事件解析（从文本到结构化事件）
2. 时间标准化（处理各种历史纪年方式）
3. 证据质量评估（史料分级、可信度评分）
4. 领域特定因果规则（历史因果关系模式）
5. 历史实体识别（人物、地点、官职等）

使用示例：
    from generic_causal_architecture.adapters import HistoryAdapter
    from generic_causal_architecture.core import CausalEngine
    from generic_causal_architecture.storage import PostgreSQLStorage
    
    adapter = HistoryAdapter()
    storage = PostgreSQLStorage()
    engine = CausalEngine(storage)
    adapter.set_causal_engine(engine)
    
    # 解析历史文本
    events = adapter.parse_historical_text("武昌起义爆发于 1911 年 10 月 10 日...")
    
    # 评估证据质量
    quality = adapter.evaluate_evidence_source("史记", "primary")
    
    # 推断因果关系
    causality = adapter.infer_historical_causality(event1, event2)
"""

from typing import Any, Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
import logging
import re
from datetime import datetime

from ..storage.storage_interface import StorageInterface, EventData, CausalRelation
from ..core.causal_engine import CausalEngine
from ..methods.lancet_method import LancetMethod
from ..methods.iterative_workflow import IterativeWorkflow

logger = logging.getLogger(__name__)


class HistoricalPeriod(Enum):
    """历史时期"""
    ANCIENT = "ancient"  # 古代（先秦 -1840）
    MODERN = "modern"  # 近代（1840-1919）
    CONTEMPORARY = "contemporary"  # 现代（1919-1949）
    POST_1949 = "post_1949"  # 当代（1949-）


class EvidenceLevel(Enum):
    """证据等级（史料分级）"""
    PRIMARY = "primary"  # 一手史料（档案、日记、当时记录）
    SECONDARY = "secondary"  # 二手史料（研究著作、回忆录）
    TERTIARY = "tertiary"  # 三手史料（教科书、科普文章）
    UNCERTAIN = "uncertain"  # 不确定


class EventType(Enum):
    """历史事件类型"""
    POLITICAL = "political"  # 政治事件（政权更迭、制度改革）
    MILITARY = "military"  # 军事事件（战争、起义）
    ECONOMIC = "economic"  # 经济事件（改革、危机）
    CULTURAL = "cultural"  # 文化事件（思想运动、文学革命）
    SOCIAL = "social"  # 社会事件（人口迁移、社会变革）
    DIPLOMATIC = "diplomatic"  # 外交事件（条约、建交）
    NATURAL = "natural"  # 自然灾害（地震、洪水、瘟疫）


@dataclass
class HistoricalEvent:
    """
    历史事件（扩展 EventData）
    
    属性:
        id: 事件 ID
        name: 事件名称
        timestamp: 时间（支持模糊时间）
        location: 地点
        participants: 参与者
        description: 事件描述
        event_type: 事件类型
        evidence_sources: 证据来源
        metadata: 元数据
        historical_period: 历史时期
        evidence_quality: 证据质量评分 (0-1)
        source_texts: 原始史料文本
        related_events: 相关事件 ID 列表
    """
    id: str
    name: str
    timestamp: Any
    location: Optional[str]
    participants: Optional[List[str]]
    description: Optional[str]
    event_type: EventType
    evidence_sources: Optional[List[str]]
    metadata: Optional[Dict[str, Any]]
    historical_period: HistoricalPeriod
    evidence_quality: float = 0.5
    source_texts: Optional[List[str]] = None
    related_events: Optional[List[str]] = None
    
    def to_event_data(self) -> EventData:
        """转换为 EventData"""
        return EventData(
            id=self.id,
            name=self.name,
            timestamp=self.timestamp,
            location=self.location,
            participants=self.participants,
            description=self.description,
            event_type=self.event_type.value,
            evidence_sources=self.evidence_sources,
            metadata={
                **(self.metadata or {}),
                'historical_period': self.historical_period.value,
                'evidence_quality': self.evidence_quality,
                'source_texts': self.source_texts,
                'related_events': self.related_events
            }
        )


@dataclass
class HistoricalEntity:
    """
    历史实体
    
    属性:
        id: 实体 ID
        name: 实体名称
        entity_type: 实体类型（人物、地点、官职等）
        time_period: 存在时期
        description: 实体描述
        aliases: 别名列表
        relationships: 与其他实体的关系
    """
    id: str
    name: str
    entity_type: str
    time_period: Optional[str]
    description: Optional[str]
    aliases: Optional[List[str]]
    relationships: Optional[Dict[str, str]]


@dataclass
class CausalAnalysisResult:
    """
    因果分析结果
    
    属性:
        has_causality: 是否存在因果关系
        relation_type: 关系类型
        confidence: 置信度
        evidence_chain: 证据链
        reasoning: 推理过程
        alternative_explanations: 替代解释
        historical_context: 历史背景
        limitations: 分析局限性
    """
    has_causality: bool
    relation_type: Optional[str]
    confidence: float
    evidence_chain: List[str]
    reasoning: str
    alternative_explanations: List[str]
    historical_context: str
    limitations: List[str]


class HistoryAdapter:
    """
    历史领域适配器
    
    核心职责：
    1. 将通用因果架构适配到历史领域
    2. 提供历史领域特定的解析、评估、推理能力
    3. 处理历史数据的特殊性（模糊时间、多重证据、史料分级）
    
    设计原则：
    - 领域无关接口（可以被其他领域复用）
    - 领域特定实现（针对历史领域优化）
    - 可扩展性（支持添加新的历史时期、事件类型）
    - 生产级质量（完整的错误处理、日志、类型注解）
    """
    
    def __init__(self, storage: Optional[StorageInterface] = None):
        """
        初始化历史适配器
        
        Args:
            storage: 存储接口（可选，建议传入）
        """
        self.storage = storage
        self._causal_engine: Optional[CausalEngine] = None
        self._lancet_method: Optional[LancetMethod] = None
        self._iterative_workflow: Optional[IterativeWorkflow] = None
        
        # 历史领域知识库
        self._historical_periods: Dict[str, Tuple[int, int]] = {
            'ancient': (0, 1840),
            'modern': (1840, 1919),
            'contemporary': (1919, 1949),
            'post_1949': (1949, datetime.now().year)
        }
        
        # 史料可信度基准
        self._source_credibility: Dict[str, float] = {
            '史记': 0.95,
            '汉书': 0.93,
            '后汉书': 0.90,
            '三国志': 0.88,
            '资治通鉴': 0.92,
            '明史': 0.85,
            '清史稿': 0.80
        }
        
        # 事件类型识别规则
        self._event_type_patterns: Dict[str, EventType] = {
            r'起义|革命|政变|战争|战役': EventType.MILITARY,
            r'改革|变法|制度|称帝|退位': EventType.POLITICAL,
            r'经济|贸易|税收|财政|货币': EventType.ECONOMIC,
            r'文化|思想|文学|艺术|教育': EventType.CULTURAL,
            r'社会|人口|移民|风俗': EventType.SOCIAL,
            r'条约|外交|建交|宣战': EventType.DIPLOMATIC,
            r'地震|洪水|瘟疫|干旱|灾害': EventType.NATURAL
        }
        
        # 时间解析规则
        self._time_patterns: List[Tuple[str, re.Pattern]] = [
            ('year_only', re.compile(r'(\d{4}) 年')),
            ('year_month', re.compile(r'(\d{4}) 年 (\d{1,2}) 月')),
            ('year_month_day', re.compile(r'(\d{4}) 年 (\d{1,2}) 月 (\d{1,2}) 日')),
            ('dynasty_year', re.compile(r'([一二三四五六七八九十]+) 年')),
            ('range', re.compile(r'(\d{4}) 年 [-~] (\d{4}) 年')),
        ]
        
        logger.info("HistoryAdapter initialized")
    
    def set_causal_engine(self, engine: CausalEngine) -> None:
        """
        设置因果引擎
        
        Args:
            engine: 因果引擎实例
        """
        self._causal_engine = engine
        logger.info("Causal engine set")
    
    def set_methodology(self, lancet: LancetMethod, workflow: IterativeWorkflow) -> None:
        """
        设置方法论组件
        
        Args:
            lancet: 柳叶刀方法实例
            workflow: 迭代工作流实例
        """
        self._lancet_method = lancet
        self._iterative_workflow = workflow
        logger.info("Methodology components set")
    
    # =========================================================================
    # 核心功能 1: 历史事件解析
    # =========================================================================
    
    def parse_historical_text(self, text: str, source: Optional[str] = None) -> List[HistoricalEvent]:
        """
        从历史文本中解析事件
        
        Args:
            text: 历史文本
            source: 史料来源
        
        Returns:
            List[HistoricalEvent]: 解析出的事件列表
        """
        if not text or not isinstance(text, str):
            logger.error("Invalid text input")
            return []
        
        try:
            events = []
            
            # 1. 识别时间表达式
            time_mentions = self._extract_time_mentions(text)
            
            # 2. 识别事件
            event_mentions = self._extract_event_mentions(text)
            
            # 3. 识别参与者
            participants = self._extract_participants(text)
            
            # 4. 识别地点
            locations = self._extract_locations(text)
            
            # 5. 组合成结构化事件
            for event_mention in event_mentions:
                event = self._create_event(
                    text=event_mention['text'],
                    time_mentions=time_mentions,
                    participants=participants,
                    locations=locations,
                    source=source
                )
                if event:
                    events.append(event)
            
            logger.info(f"Parsed {len(events)} events from text")
            return events
        
        except Exception as e:
            logger.error(f"Error parsing historical text: {e}")
            return []
    
    def _extract_time_mentions(self, text: str) -> List[Dict[str, Any]]:
        """提取时间提及"""
        mentions = []
        
        for pattern_name, pattern in self._time_patterns:
            matches = pattern.finditer(text)
            for match in matches:
                mentions.append({
                    'pattern': pattern_name,
                    'text': match.group(0),
                    'start': match.start(),
                    'end': match.end(),
                    'groups': match.groups()
                })
        
        return mentions
    
    def _extract_event_mentions(self, text: str) -> List[Dict[str, Any]]:
        """提取事件提及"""
        # 简化实现：按句子分割
        sentences = re.split(r'[。！？.!?]', text)
        
        event_mentions = []
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            # 检查是否包含事件关键词
            for pattern, event_type in self._event_type_patterns.items():
                if re.search(pattern, sentence):
                    event_mentions.append({
                        'text': sentence,
                        'type': event_type,
                        'keywords': re.findall(pattern, sentence)
                    })
                    break
        
        return event_mentions
    
    def _extract_participants(self, text: str) -> List[str]:
        """提取参与者"""
        # 简化实现：识别人名（实际应该使用 NER）
        participants = []
        
        # 常见历史人物称呼模式
        patterns = [
            r'([A-Z][a-z]+)',  # 英文名
            r'([一 - 龯]{2,4} 帝)',  # XX 帝
            r'([一 - 龯]{2,4} 王)',  # XX 王
            r'([一 - 龯]{2,4} 公)',  # XX 公
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            participants.extend(matches)
        
        return list(set(participants))
    
    def _extract_locations(self, text: str) -> List[str]:
        """提取地点"""
        # 简化实现：识别地名（实际应该使用 NER）
        locations = []
        
        # 常见地名模式
        patterns = [
            r'([一 - 龯]{2,4} 省)',
            r'([一 - 龯]{2,4} 市)',
            r'([一 - 龯]{2,4} 县)',
            r'([一 - 龯]{2,4} 镇)',
            r'([一 - 龯]{2,4} 村)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text)
            locations.extend(matches)
        
        return list(set(locations))
    
    def _create_event(self, text: str, time_mentions: List[Dict], 
                     participants: List[str], locations: List[str],
                     source: Optional[str] = None) -> Optional[HistoricalEvent]:
        """创建事件对象"""
        # 1. 确定事件类型
        event_type = None
        for pattern, etype in self._event_type_patterns.items():
            if re.search(pattern, text):
                event_type = etype
                break
        
        if not event_type:
            return None
        
        # 2. 解析时间
        timestamp = self._parse_timestamp(time_mentions)
        
        # 3. 生成事件 ID
        event_id = f"event_{hash(text) % 1000000}"
        
        # 4. 提取事件名称（前 20 个字）
        event_name = text[:20] + "..." if len(text) > 20 else text
        
        # 5. 确定历史时期
        period = self._determine_historical_period(timestamp)
        
        # 6. 评估证据质量
        evidence_quality = self._evaluate_evidence_quality(source)
        
        return HistoricalEvent(
            id=event_id,
            name=event_name,
            timestamp=timestamp,
            location=locations[0] if locations else None,
            participants=participants,
            description=text,
            event_type=event_type,
            evidence_sources=[source] if source else None,
            metadata={},
            historical_period=period,
            evidence_quality=evidence_quality,
            source_texts=[text]
        )
    
    def _parse_timestamp(self, time_mentions: List[Dict]) -> Optional[Dict[str, int]]:
        """解析时间戳"""
        if not time_mentions:
            return None
        
        # 使用第一个匹配的时间
        mention = time_mentions[0]
        
        if mention['pattern'] == 'year_only':
            return {'year': int(mention['groups'][0])}
        elif mention['pattern'] == 'year_month':
            return {
                'year': int(mention['groups'][0]),
                'month': int(mention['groups'][1])
            }
        elif mention['pattern'] == 'year_month_day':
            return {
                'year': int(mention['groups'][0]),
                'month': int(mention['groups'][1]),
                'day': int(mention['groups'][2])
            }
        elif mention['pattern'] == 'range':
            return {
                'year_start': int(mention['groups'][0]),
                'year_end': int(mention['groups'][1])
            }
        
        return None
    
    def _determine_historical_period(self, timestamp: Optional[Dict]) -> HistoricalPeriod:
        """确定历史时期"""
        if not timestamp:
            return HistoricalPeriod.ANCIENT
        
        year = timestamp.get('year', 0)
        
        if year == 0 and 'year_start' in timestamp:
            year = timestamp['year_start']
        
        # 中国历史时期划分标准：
        # 古代：- 远古至 1840 年（鸦片战争前）
        # 近代：1840-1919 年（鸦片战争至五四运动）
        # 现代：1919-1949 年（五四运动至新中国成立）
        # 当代：1949 年 - 至今
        if year <= 1840:
            return HistoricalPeriod.ANCIENT
        elif year <= 1919:
            return HistoricalPeriod.MODERN
        elif year <= 1949:
            return HistoricalPeriod.CONTEMPORARY
        else:
            return HistoricalPeriod.POST_1949
    
    def _evaluate_evidence_quality(self, source: Optional[str]) -> float:
        """评估证据质量"""
        if not source:
            return 0.5
        
        # 检查是否在可信度基准中
        for source_name, credibility in self._source_credibility.items():
            if source_name in source:
                return credibility
        
        # 默认质量
        return 0.6
    
    # =========================================================================
    # 核心功能 2: 因果推断
    # =========================================================================
    
    def infer_historical_causality(self, event_a: HistoricalEvent, 
                                   event_b: HistoricalEvent) -> CausalAnalysisResult:
        """
        推断历史事件的因果关系
        
        Args:
            event_a: 可能的原因事件
            event_b: 可能的结果事件
        
        Returns:
            CausalAnalysisResult: 因果分析结果
        """
        if not self._causal_engine:
            logger.error("Causal engine not set")
            return self._create_empty_result()
        
        try:
            # 1. 转换为 EventData
            event_data_a = event_a.to_event_data()
            event_data_b = event_b.to_event_data()
            
            # 2. 使用因果引擎推断
            has_causality = self._causal_engine.infer_causality(
                event_data_a, event_data_b
            )
            
            # 3. 获取详细解释
            explanation = self._causal_engine.explain_causality(
                event_data_a, event_data_b
            )
            
            # 4. 构建历史领域的因果分析结果
            evidence_chain = self._build_evidence_chain(
                event_a, event_b, explanation
            )
            
            reasoning = self._build_reasoning(explanation)
            
            alternative_explanations = explanation.get(
                'alternative_explanations', []
            )
            
            historical_context = self._build_historical_context(event_a, event_b)
            
            limitations = self._identify_limitations(event_a, event_b)
            
            return CausalAnalysisResult(
                has_causality=has_causality,
                relation_type=explanation.get('relation_type'),
                confidence=explanation.get('confidence', 0.0),
                evidence_chain=evidence_chain,
                reasoning=reasoning,
                alternative_explanations=alternative_explanations,
                historical_context=historical_context,
                limitations=limitations
            )
        
        except Exception as e:
            logger.error(f"Error inferring historical causality: {e}")
            return self._create_empty_result()
    
    def _create_empty_result(self) -> CausalAnalysisResult:
        """创建空结果"""
        return CausalAnalysisResult(
            has_causality=False,
            relation_type=None,
            confidence=0.0,
            evidence_chain=[],
            reasoning="无法进行因果分析",
            alternative_explanations=[],
            historical_context="",
            limitations=["因果引擎未设置"]
        )
    
    def _build_evidence_chain(self, event_a: HistoricalEvent, 
                             event_b: HistoricalEvent,
                             explanation: Dict) -> List[str]:
        """构建证据链"""
        evidence = []
        
        # 1. 时序证据
        if event_a.timestamp and event_b.timestamp:
            evidence.append(
                f"时序证据：{event_a.name} ({self._format_timestamp(event_a.timestamp)}) "
                f"早于 {event_b.name} ({self._format_timestamp(event_b.timestamp)})"
            )
        
        # 2. 证据来源
        if event_a.evidence_sources:
            for source in event_a.evidence_sources:
                evidence.append(f"事件 A 证据来源：{source}")
        
        if event_b.evidence_sources:
            for source in event_b.evidence_sources:
                evidence.append(f"事件 B 证据来源：{source}")
        
        # 3. 因果引擎的证据
        for check in explanation.get('checks', []):
            if check.get('passed'):
                evidence.append(f"{check['type']}: {check['reasoning']}")
        
        return evidence
    
    def _build_reasoning(self, explanation: Dict) -> str:
        """构建推理过程"""
        reasoning_chain = explanation.get('reasoning_chain', [])
        return "\n".join(reasoning_chain)
    
    def _build_historical_context(self, event_a: HistoricalEvent, 
                                 event_b: HistoricalEvent) -> str:
        """构建历史背景"""
        context_parts = []
        
        # 历史时期
        context_parts.append(
            f"历史时期：{event_a.historical_period.value} → {event_b.historical_period.value}"
        )
        
        # 事件类型
        context_parts.append(
            f"事件类型：{event_a.event_type.value} → {event_b.event_type.value}"
        )
        
        # 参与者
        if event_a.participants or event_b.participants:
            participants = set(event_a.participants or []) | set(event_b.participants or [])
            context_parts.append(f"相关人物：{', '.join(participants)}")
        
        # 地点
        if event_a.location or event_b.location:
            locations = []
            if event_a.location:
                locations.append(event_a.location)
            if event_b.location:
                locations.append(event_b.location)
            context_parts.append(f"相关地点：{', '.join(locations)}")
        
        return "; ".join(context_parts)
    
    def _identify_limitations(self, event_a: HistoricalEvent, 
                             event_b: HistoricalEvent) -> List[str]:
        """识别分析局限性"""
        limitations = []
        
        # 证据质量
        if event_a.evidence_quality < 0.7:
            limitations.append("事件 A 证据质量较低")
        
        if event_b.evidence_quality < 0.7:
            limitations.append("事件 B 证据质量较低")
        
        # 时间精度
        if isinstance(event_a.timestamp, dict) and 'year_start' in event_a.timestamp:
            limitations.append("事件 A 时间精度较低（范围）")
        
        if isinstance(event_b.timestamp, dict) and 'year_start' in event_b.timestamp:
            limitations.append("事件 B 时间精度较低（范围）")
        
        # 史料来源
        if not event_a.evidence_sources:
            limitations.append("事件 A 缺乏明确史料来源")
        
        if not event_b.evidence_sources:
            limitations.append("事件 B 缺乏明确史料来源")
        
        return limitations
    
    def _format_timestamp(self, timestamp: Any) -> str:
        """格式化时间戳"""
        if timestamp is None:
            return "未知时间"
        
        if isinstance(timestamp, int):
            return f"{timestamp}年"
        elif isinstance(timestamp, dict):
            if 'year' in timestamp:
                if 'month' in timestamp:
                    if 'day' in timestamp:
                        return f"{timestamp['year']}年{timestamp['month']}月{timestamp['day']}日"
                    return f"{timestamp['year']}年{timestamp['month']}月"
                return f"{timestamp['year']}年"
            elif 'year_start' in timestamp:
                return f"{timestamp['year_start']}年-{timestamp['year_end']}年"
        
        return str(timestamp)
    
    # =========================================================================
    # 核心功能 3: 历史实体管理
    # =========================================================================
    
    def extract_historical_entities(self, text: str) -> List[HistoricalEntity]:
        """
        从文本中提取历史实体
        
        Args:
            text: 历史文本
        
        Returns:
            List[HistoricalEntity]: 提取的实体列表
        """
        # 简化实现：基于规则提取
        entities = []
        
        # 提取人名（改进的正则表达式）
        person_patterns = [
            r'([一 - 龯]{2,3} 帝)',  # XX 帝
            r'([一 - 龯]{2,3} 王)',  # XX 王
            r'([一 - 龯]{2,3} 公)',  # XX 公
            r'([一 - 龯]{2,4} 帝)',  # XXX 帝
            r'([一 - 龯]{3,4})',     # 三字或四字人名（可能是复姓或双名）
        ]
        
        for pattern in person_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                # 避免重复
                if not any(e.name == match for e in entities if e.entity_type == 'person'):
                    entities.append(HistoricalEntity(
                        id=f"person_{hash(match) % 1000000}",
                        name=match,
                        entity_type='person',
                        time_period=None,
                        description=None,
                        aliases=None,
                        relationships=None
                    ))
        
        # 提取地名（改进的正则表达式）
        location_patterns = [
            r'([一 - 龯]{2,3}[省市县镇村])',  # XX 省/市/县/镇/村
            r'([一 - 龯]{3,4}[省市县镇村])',  # XXX 省/市/县/镇/村
        ]
        
        for pattern in location_patterns:
            matches = re.findall(pattern, text)
            for match in matches:
                # 避免重复
                if not any(e.name == match for e in entities if e.entity_type == 'location'):
                    entities.append(HistoricalEntity(
                        id=f"location_{hash(match) % 1000000}",
                        name=match,
                        entity_type='location',
                        time_period=None,
                        description=None,
                        aliases=None,
                        relationships=None
                    ))
        
        logger.info(f"Extracted {len(entities)} historical entities")
        return entities
    
    # =========================================================================
    # 工具方法
    # =========================================================================
    
    def validate_event(self, event: HistoricalEvent) -> Tuple[bool, List[str]]:
        """
        验证历史事件的有效性
        
        Args:
            event: 要验证的事件
        
        Returns:
            (is_valid, issues): 是否有效，问题列表
        """
        issues = []
        
        # 1. 检查必需字段
        if not event.name:
            issues.append("缺少事件名称")
        
        if not event.timestamp:
            issues.append("缺少时间信息")
        
        if not event.event_type:
            issues.append("缺少事件类型")
        
        # 2. 检查时间合理性
        if event.timestamp:
            if isinstance(event.timestamp, dict):
                year = event.timestamp.get('year', 0)
                if year < 0 or year > datetime.now().year:
                    issues.append(f"时间不合理：{year}")
        
        # 3. 检查证据质量
        if event.evidence_quality < 0.3:
            issues.append("证据质量过低")
        
        is_valid = len(issues) == 0
        return is_valid, issues
    
    def merge_events(self, events: List[HistoricalEvent]) -> Optional[HistoricalEvent]:
        """
        合并多个相似事件
        
        Args:
            events: 事件列表
        
        Returns:
            合并后的事件，如果无法合并返回 None
        """
        if not events:
            return None
        
        if len(events) == 1:
            return events[0]
        
        # 检查是否可以合并（相同类型、相近时间）
        first_event = events[0]
        
        for event in events[1:]:
            if event.event_type != first_event.event_type:
                logger.warning("事件类型不同，无法合并")
                return None
            
            # 检查时间是否相近（简化实现）
            if event.timestamp != first_event.timestamp:
                logger.warning("事件时间不同，无法合并")
                return None
        
        # 合并
        merged_id = f"merged_{hash(first_event.name) % 1000000}"
        merged_description = " | ".join([e.description for e in events])
        merged_sources = []
        
        for event in events:
            if event.evidence_sources:
                merged_sources.extend(event.evidence_sources)
        
        return HistoricalEvent(
            id=merged_id,
            name=first_event.name,
            timestamp=first_event.timestamp,
            location=first_event.location,
            participants=first_event.participants,
            description=merged_description,
            event_type=first_event.event_type,
            evidence_sources=list(set(merged_sources)),
            metadata=first_event.metadata,
            historical_period=first_event.historical_period,
            evidence_quality=max([e.evidence_quality for e in events]),
            source_texts=[e.description for e in events]
        )
