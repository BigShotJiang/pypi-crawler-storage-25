"""
领域适配器基类 - 我们的创新点

使用抽象基类确保所有子类实现必要的接口。
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class DomainAdapter(ABC):
    """领域适配器基类
    
    所有领域适配器都必须继承这个基类并实现所有抽象方法。
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """初始化适配器
        
        Args:
            config: 配置字典，子类可以定义自己的配置项
        """
        self.config = config or {}
    
    @property
    @abstractmethod
    def domain_name(self) -> str:
        """获取领域名称
        
        Returns:
            str: 领域名称
        """
        pass
    
    @abstractmethod
    def preprocess(self, data: Any) -> Any:
        """预处理领域特定数据
        
        Args:
            data: 原始数据
            
        Returns:
            Any: 预处理后的数据
        """
        pass
    
    @abstractmethod
    def is_before(self, event_a: Any, event_b: Any) -> bool:
        """领域特定时序检查
        
        Args:
            event_a: 第一个事件
            event_b: 第二个事件
            
        Returns:
            bool: 如果 event_a 发生在 event_b 之前返回 True
        """
        pass
    
    @abstractmethod
    def is_possible_without(self, event_b: Any, event_a: Any) -> bool:
        """领域特定充分性检查
        
        Args:
            event_b: 结果事件
            event_a: 原因事件
            
        Returns:
            bool: 如果 event_b 可能在沒有 event_a 的情况下发生返回 True
        """
        pass
    
    @abstractmethod
    def has_intermediate_events(self, event_a: Any, event_b: Any, 
                                all_events: List[Any]) -> bool:
        """领域特定直接性检查
        
        Args:
            event_a: 起始事件
            event_b: 结束事件
            all_events: 所有事件的列表
            
        Returns:
            bool: 如果存在中间事件返回 True
        """
        pass
    
    def extract_event_features(self, event: Any) -> Dict[str, Any]:
        """提取事件特征（可选方法，有默认实现）
        
        Args:
            event: 事件对象
            
        Returns:
            Dict[str, Any]: 事件特征字典
        """
        return {'raw': event}
    
    def validate_event(self, event: Any) -> bool:
        """验证事件是否符合领域规范（可选方法，有默认实现）
        
        Args:
            event: 事件对象
            
        Returns:
            bool: 如果事件有效返回 True
        """
        return True
    
    def get_domain_specific_rules(self) -> List[Dict[str, Any]]:
        """获取领域特定规则（可选方法，有默认实现）
        
        Returns:
            List[Dict[str, Any]]: 领域特定规则列表
        """
        return []