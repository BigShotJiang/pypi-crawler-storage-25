"""
自然科学领域适配器示例

这个适配器展示了如何让因果引擎适应自然科学领域的特定需求。
"""

from typing import Any, Dict, List
from ..interfaces.domain_adapter_interface import IDomainAdapter


class NaturalScienceAdapter(IDomainAdapter):
    """自然科学领域适配器
    
    自然科学领域的特点：
    1. 实验可重复性
    2. 严格的因果关系
    3. 定量数据为主
    4. 时间顺序可能是实验顺序或逻辑顺序
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """初始化适配器
        
        Args:
            config: 配置字典，可包含：
                - 'strict_causality': 是否使用严格的因果判断（默认 True）
                - 'require_temporal_order': 是否要求时序（默认 True）
                - 'min_confidence': 最小置信度阈值（默认 0.8）
        """
        self.config = config or {}
        self._name = 'natural_science'
    
    @property
    def domain_name(self) -> str:
        """获取领域名称"""
        return self._name
    
    def preprocess(self, data: Any) -> Any:
        """预处理自然科学数据
        
        自然科学数据通常是实验数据、观测数据等。
        """
        if isinstance(data, list):
            # 标准化事件格式
            processed = []
            for item in data:
                if isinstance(item, dict):
                    # 确保有时间戳
                    if 'timestamp' not in item and 'time' in item:
                        item['timestamp'] = item['time']
                    # 确保有类型
                    if 'type' not in item:
                        item['type'] = 'observation'
                    processed.append(item)
                else:
                    # 转换为字典格式
                    processed.append({
                        'data': item,
                        'type': 'observation',
                        'timestamp': None
                    })
            return processed
        return data
    
    def is_before(self, event_a: Any, event_b: Any) -> bool:
        """自然科学领域的时序检查
        
        在自然科学中，时序可能是：
        1. 实验时间顺序
        2. 逻辑顺序（如反应物→产物）
        3. 因果关系顺序
        """
        # 如果有明确的时间戳
        if isinstance(event_a, dict) and isinstance(event_b, dict):
            time_a = event_a.get('timestamp') or event_a.get('time')
            time_b = event_b.get('timestamp') or event_b.get('time')
            
            if time_a is not None and time_b is not None:
                return time_a < time_b
        
        # 如果是实验步骤，检查步骤顺序
        if isinstance(event_a, dict) and isinstance(event_b, dict):
            step_a = event_a.get('step_number')
            step_b = event_b.get('step_number')
            
            if step_a is not None and step_b is not None:
                return step_a < step_b
        
        # 默认返回 False（无法判断）
        return False
    
    def is_possible_without(self, event_b: Any, event_a: Any) -> bool:
        """自然科学领域的充分性检查
        
        在自然科学中，这通常通过：
        1. 对照实验
        2. 理论推导
        3. 历史数据
        来判断。
        """
        # 如果有明确的对照实验数据
        if isinstance(event_b, dict):
            control_data = event_b.get('control_group')
            if control_data is not None:
                # 如果对照组也发生了，说明可能不需要 event_a
                return control_data.get('occurred', False)
        
        # 如果有理论规则
        if isinstance(event_a, dict) and isinstance(event_b, dict):
            # 检查是否有已知的替代原因
            alternative_causes = event_b.get('alternative_causes', [])
            if event_a.get('id') in alternative_causes:
                return True
        
        # 默认返回 False（保守判断）
        return False
    
    def has_intermediate_events(self, event_a: Any, event_b: Any, 
                                all_events: List[Any]) -> bool:
        """自然科学领域的直接性检查
        
        检查是否存在中间事件（如中间产物、中间步骤等）。
        """
        if not isinstance(event_a, dict) or not isinstance(event_b, dict):
            return False
        
        # 获取时间或步骤
        time_a = event_a.get('timestamp') or event_a.get('time') or event_a.get('step_number', 0)
        time_b = event_b.get('timestamp') or event_b.get('time') or event_b.get('step_number', float('inf'))
        
        # 检查中间事件
        for event in all_events:
            if event == event_a or event == event_b:
                continue
            
            time_event = event.get('timestamp') or event.get('time') or event.get('step_number', 0)
            
            if time_a < time_event < time_b:
                return True
        
        return False
    
    def extract_event_features(self, event: Any) -> Dict[str, Any]:
        """提取自然科学事件的特征"""
        if not isinstance(event, dict):
            return {'raw': event}
        
        features = {
            'type': event.get('type', 'unknown'),
            'timestamp': event.get('timestamp') or event.get('time'),
            'magnitude': event.get('magnitude'),  # 强度
            'confidence': event.get('confidence', 1.0),  # 置信度
            'reproducible': event.get('reproducible', True),  # 是否可重复
            'quantitative': event.get('quantitative', True),  # 是否定量
        }
        
        return features
    
    def validate_event(self, event: Any) -> bool:
        """验证自然科学事件
        
        自然科学事件应该：
        1. 有明确的类型
        2. 有可观测的数据
        3. 最好是可重复的
        """
        if not isinstance(event, dict):
            return False
        
        # 必须有类型或数据
        if 'type' not in event and 'data' not in event:
            return False
        
        # 如果有时间，必须是合理的
        if 'timestamp' in event:
            if not isinstance(event['timestamp'], (int, float)):
                return False
        
        return True
    
    def get_domain_specific_rules(self) -> List[Dict[str, Any]]:
        """获取自然科学领域的特定规则"""
        return [
            {
                'name': 'temporal_priority',
                'description': '原因必须发生在结果之前',
                'priority': 1,
                'enforce': self.config.get('require_temporal_order', True)
            },
            {
                'name': 'reproducibility',
                'description': '因果关系应该是可重复的',
                'priority': 2,
                'enforce': True
            },
            {
                'name': 'confidence_threshold',
                'description': '置信度必须超过阈值',
                'priority': 3,
                'threshold': self.config.get('min_confidence', 0.8)
            },
            {
                'name': 'alternative_explanation',
                'description': '必须排除替代解释',
                'priority': 4,
                'enforce': self.config.get('strict_causality', True)
            }
        ]
