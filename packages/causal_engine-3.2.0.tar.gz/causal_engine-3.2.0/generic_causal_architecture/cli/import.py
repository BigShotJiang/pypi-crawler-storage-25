"""
数据导入 CLI 工具

使用示例：
    # 导入 CSV
    python -m generic_causal_architecture.cli.import --source csv --file events.csv --domain history
    
    # 导入 JSON
    python -m generic_causal_architecture.cli.import --source json --file events.json
    
    # 从 shiji-kb 导入
    python -m generic_causal_architecture.cli.import --source shiji-kb --api-url http://localhost:8000/api
"""

import click
import logging
import sys
from pathlib import Path
from typing import Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


@click.command()
@click.option(
    '--source',
    type=click.Choice(['csv', 'json', 'shiji-kb']),
    required=True,
    help='数据源类型'
)
@click.option(
    '--file', '-f',
    type=click.Path(exists=True),
    help='输入文件路径（CSV 或 JSON）'
)
@click.option(
    '--domain', '-d',
    type=str,
    default=None,
    help='领域标签（可选）'
)
@click.option(
    '--config', '-c',
    type=click.Path(exists=True),
    default='config/production.yaml',
    help='配置文件路径（默认：config/production.yaml）'
)
@click.option(
    '--api-url',
    type=str,
    default=None,
    help='shiji-kb API URL（仅 shiji-kb 源需要）'
)
@click.option(
    '--api-key',
    type=str,
    default=None,
    help='shiji-kb API Key（仅 shiji-kb 源需要）'
)
@click.option(
    '--batch-size',
    type=int,
    default=100,
    help='批量导入数量（默认：100）'
)
@click.option(
    '--dry-run',
    is_flag=True,
    help='试运行（不实际导入，只显示结果）'
)
@click.option(
    '--verbose', '-v',
    is_flag=True,
    help='详细输出'
)
def import_command(
    source: str,
    file: Optional[str],
    domain: Optional[str],
    config: str,
    api_url: Optional[str],
    api_key: Optional[str],
    batch_size: int,
    dry_run: bool,
    verbose: bool
):
    """
    数据导入工具
    
    支持从 CSV、JSON 文件或 shiji-kb API 导入事件数据到知识库。
    """
    if verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # 验证参数
    if source in ['csv', 'json'] and not file:
        click.echo(click.style("错误：CSV/JSON 导入需要指定 --file 参数", fg='red'))
        sys.exit(1)
    
    if source == 'shiji-kb' and not api_url:
        click.echo(click.style("错误：shiji-kb 导入需要指定 --api-url 参数", fg='red'))
        sys.exit(1)
    
    # 加载配置
    try:
        from ..config import Config
        from ..storage import MemoryStorage
        
        # 尝试加载配置，如果失败就使用内存存储
        try:
            config_obj = Config(config)
            storage = config_obj.get_storage()
        except Exception as e:
            if verbose:
                logger.warning(f"加载配置失败，使用内存存储：{e}")
            storage = MemoryStorage()
        
        storage.initialize()
        storage_type = getattr(storage, '__class__', object).__name__
        click.echo(click.style(f"✓ 已连接到存储：{storage_type}", fg='green'))
        
    except Exception as e:
        click.echo(click.style(f"错误：连接存储失败：{e}", fg='red'))
        if verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)
    
    # 创建导入器
    try:
        from ..importers.base import get_importer
        
        if source == 'csv':
            importer = get_importer(source, file_path=file)
        elif source == 'json':
            importer = get_importer(source, file_path=file)
        elif source == 'shiji-kb':
            importer = get_importer(
                source,
                api_url=api_url,
                api_key=api_key
            )
        
        click.echo(click.style(f"✓ 已创建导入器：{source}", fg='green'))
    except Exception as e:
        click.echo(click.style(f"错误：创建导入器失败：{e}", fg='red'))
        sys.exit(1)
    
    # 导入数据
    click.echo(click.style(f"\n开始从 {source} 导入数据...", fg='cyan'))
    
    try:
        # 准备导入参数
        import_kwargs = {}
        if domain:
            import_kwargs['domain'] = domain
        
        # 执行导入
        events = importer.import_data(**import_kwargs)
        
        if not events:
            click.echo(click.style("\n⚠️  未找到可导入的数据", fg='yellow'))
            sys.exit(0)
        
        click.echo(click.style(f"\n✓ 成功导入 {len(events)} 个事件", fg='green'))
        
        # 显示前几个事件
        click.echo("\n前 5 个事件预览：")
        for i, event in enumerate(events[:5], 1):
            click.echo(f"  {i}. {event.name} (时间：{event.timestamp})")
        
        if len(events) > 5:
            click.echo(f"  ... 还有 {len(events) - 5} 个事件")
        
        # 试运行模式
        if dry_run:
            click.echo("\n" + click.style("⚠️  试运行模式，未实际导入", fg='yellow'))
            sys.exit(0)
        
        # 批量导入到存储
        click.echo(f"\n正在导入到存储（批量大小：{batch_size}）...")
        
        total_imported = 0
        for event in events:
            try:
                storage.add_event(event)
                total_imported += 1
                
                if total_imported % batch_size == 0:
                    click.echo(f"  ✓ 已导入 {total_imported}/{len(events)} 个事件")
            except Exception as e:
                click.echo(click.style(f"  ✗ 事件导入失败：{event.name} - {e}", fg='red'))
                continue
        
        # 最终统计
        click.echo("\n" + "=" * 60)
        click.echo(click.style(f"✅ 导入完成！", fg='green'))
        click.echo(f"  总事件数：{len(events)}")
        click.echo(f"  成功导入：{total_imported}")
        click.echo(f"  失败：{len(events) - total_imported}")
        click.echo("=" * 60)
        
    except Exception as e:
        click.echo(click.style(f"\n✗ 导入失败：{e}", fg='red'))
        if verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def main():
    """CLI 入口点"""
    import_command()


if __name__ == '__main__':
    main()
