"""
依赖注入容器 - 生产级依赖管理

重要说明：
1. 使用 dependency-injector 库
2. 所有组件通过容器管理
3. 支持单例模式
4. 支持配置注入

使用示例：
    from generic_causal_architecture.container import Container
    from generic_causal_architecture.config import Config
    
    config = Config.from_yaml("config/production.yaml")
    container = Container(config)
    
    # 获取组件
    storage = container.storage()
    engine = container.engine()
"""

from dependency_injector import containers, providers
from typing import Optional

from .config import Config
from .storage.postgresql_storage import PostgreSQLStorage
from .core.causal_engine import CausalEngine


class Container(containers.DeclarativeContainer):
    """
    依赖注入容器
    
    核心组件：
    - config: 配置对象
    - storage: 存储实例（单例）
    - engine: 因果引擎实例（单例）
    
    使用示例:
        container = Container(config)
        storage = container.storage()
        engine = container.engine()
    """
    
    # 配置
    config = providers.Configuration()
    
    # 存储（单例）
    storage = providers.Singleton(
        PostgreSQLStorage,
        database_url=config.storage.database_url,
        pool_size=config.storage.pool_size,
        echo=config.storage.echo
    )
    
    # 因果引擎（单例）
    engine = providers.Singleton(
        CausalEngine,
        storage=storage,
        causal_config=config.causal
    )
    
    @classmethod
    def from_config(cls, config: Config) -> 'Container':
        """
        从配置创建容器
        
        参数:
            config: Config 对象
        
        返回:
            Container 实例
        """
        container = cls()
        container.config.from_dict({
            'storage': {
                'database_url': config.storage.database_url,
                'pool_size': config.storage.pool_size,
                'echo': config.storage.echo,
            },
            'causal': {
                'temporal_threshold': config.causal.temporal_threshold,
                'confidence_threshold': config.causal.confidence_threshold,
                'max_path_length': config.causal.max_path_length,
                'enable_temporal_check': config.causal.enable_temporal_check,
                'enable_sufficiency_check': config.causal.enable_sufficiency_check,
                'enable_directness_check': config.causal.enable_directness_check,
            }
        })
        return container


# 全局容器实例（便于访问）
_container: Optional[Container] = None


def get_container() -> Container:
    """
    获取全局容器实例
    
    返回:
        Container 实例
    
    异常:
        RuntimeError: 如果容器未初始化
    """
    if _container is None:
        raise RuntimeError(
            "Container not initialized. Call init_container() first."
        )
    return _container


def init_container(config: Config) -> Container:
    """
    初始化全局容器
    
    参数:
        config: Config 对象
    
    返回:
        Container 实例
    """
    global _container
    _container = Container.from_config(config)
    return _container
