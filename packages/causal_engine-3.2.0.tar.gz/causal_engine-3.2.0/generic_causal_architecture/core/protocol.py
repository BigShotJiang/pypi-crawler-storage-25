"""
Unified protocol for engine-application communication.

Defines the standard data models, enums, and response formats that ALL
applications must use when interacting with the causal engine. This is
the single source of truth for input/output contracts.

Design principles:
  - One canonical model per concept (no duplicates)
  - Enum-based controlled vocabularies (no magic strings)
  - Every model has to_dict() for serialization
  - Backward-compatible with existing Action/CausalRelation models
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class RelationType(str, Enum):
    CAUSES = "causes"
    ENABLES = "enables"
    PREVENTS = "prevents"
    CORRELATES = "correlates"

    @classmethod
    def values(cls) -> List[str]:
        return [m.value for m in cls]


class RuleLevel(str, Enum):
    A = "A"
    B = "B"
    C = "C"

    def min_confidence(self) -> float:
        mapping = {"A": 0.8, "B": 0.5, "C": 0.3}
        return mapping.get(self.value, 0.3)


class ConflictType(str, Enum):
    CONTRADICTORY = "contradictory"
    DUPLICATE = "duplicate"
    PARTIAL_OVERLAP = "partial_overlap"


@dataclass
class Relation:
    source: str
    target: str
    relation_type: str = "causes"
    confidence: float = 0.8
    conditions: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        if self.relation_type not in RelationType.values():
            raise ValueError(
                f"Invalid relation_type '{self.relation_type}'. "
                f"Must be one of {RelationType.values()}"
            )
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(
                f"Confidence must be 0.0-1.0, got {self.confidence}"
            )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "relation_type": self.relation_type,
            "confidence": round(self.confidence, 3),
            "conditions": self.conditions,
        }

    def matches_conditions(self, world_state: Dict[str, Any]) -> bool:
        """
        Check if this relation's conditions are satisfied by the current world state.

        Conditions dict format:
          {
            "catalysts": ["cond1", "cond2"],  # at least one must be present in world_state
            "inhibitors": ["cond3"],          # none must be present in world_state
          }

        If conditions is empty, the relation always matches (unconditional).
        """
        if not self.conditions:
            return True

        catalysts = self.conditions.get("catalysts", [])
        inhibitors = self.conditions.get("inhibitors", [])

        if inhibitors:
            for inh in inhibitors:
                if inh in world_state:
                    return False

        if catalysts:
            has_catalyst = any(cat in world_state for cat in catalysts)
            if not has_catalyst:
                return False

        return True


@dataclass
class ActionRequest:
    action_name: str
    relations: List[Relation] = field(default_factory=list)
    actor: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    trace_depth: int = 4

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_name": self.action_name,
            "relations": [r.to_dict() for r in self.relations],
            "actor": self.actor,
            "metadata": self.metadata,
            "trace_depth": self.trace_depth,
        }


@dataclass
class ChainLink:
    source: str
    target: str
    relation_type: str
    confidence: float
    is_new: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "relation_type": self.relation_type,
            "confidence": round(self.confidence, 3),
            "is_new": self.is_new,
        }


@dataclass
class Chain:
    trigger: str
    steps: List[ChainLink] = field(default_factory=list)
    total_confidence: float = 0.0

    @property
    def length(self) -> int:
        return len(self.steps)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trigger": self.trigger,
            "steps": [s.to_dict() for s in self.steps],
            "total_confidence": round(self.total_confidence, 3),
            "length": self.length,
        }


@dataclass
class ActionResult:
    action_name: str
    entities_affected: List[str] = field(default_factory=list)
    relations_added: int = 0
    chains: List[Chain] = field(default_factory=list)
    immediate_effects: List[Dict[str, Any]] = field(default_factory=list)
    downstream_effects: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_name": self.action_name,
            "entities_affected": self.entities_affected,
            "relations_added": self.relations_added,
            "chains_found": len(self.chains),
            "immediate_effects": self.immediate_effects,
            "downstream_effects": self.downstream_effects,
            "chains": [c.to_dict() for c in self.chains],
        }


@dataclass
class CandidateRule:
    source: str
    target: str
    relation_type: str
    confidence: float
    reasoning: str = ""
    catalysts: List[str] = field(default_factory=list)
    inhibitors: List[str] = field(default_factory=list)
    level: str = "B"

    def __post_init__(self):
        if self.relation_type not in RelationType.values():
            raise ValueError(
                f"Invalid relation_type '{self.relation_type}'. "
                f"Must be one of {RelationType.values()}"
            )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "target": self.target,
            "relation_type": self.relation_type,
            "confidence": round(self.confidence, 3),
            "reasoning": self.reasoning,
            "catalysts": self.catalysts,
            "inhibitors": self.inhibitors,
            "level": self.level,
        }


@dataclass
class ValidationResult:
    is_valid: bool
    rule: CandidateRule
    conflicts: List[Dict[str, Any]] = field(default_factory=list)
    is_duplicate: bool = False
    recommended_level: str = "B"
    message: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_valid": self.is_valid,
            "rule": self.rule.to_dict(),
            "conflicts": self.conflicts,
            "is_duplicate": self.is_duplicate,
            "recommended_level": self.recommended_level,
            "message": self.message,
        }


@dataclass
class DiscoverRequest:
    context: str
    world_state: Dict[str, Any] = field(default_factory=dict)
    existing_rules_hint: List[str] = field(default_factory=list)
    max_candidates: int = 5

    def to_dict(self) -> Dict[str, Any]:
        return {
            "context": self.context,
            "world_state": self.world_state,
            "existing_rules_hint": self.existing_rules_hint,
            "max_candidates": self.max_candidates,
        }


@dataclass
class DiscoverResult:
    candidates: List[CandidateRule] = field(default_factory=list)
    validated: List[ValidationResult] = field(default_factory=list)
    committed: int = 0
    skipped_duplicates: int = 0
    conflicts_found: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "candidates_generated": len(self.candidates),
            "committed": self.committed,
            "skipped_duplicates": self.skipped_duplicates,
            "conflicts_found": self.conflicts_found,
            "candidates": [c.to_dict() for c in self.candidates],
            "validated": [v.to_dict() for v in self.validated],
        }


@dataclass
class FeedbackRequest:
    rule_source: str
    rule_target: str
    rule_relation_type: str
    predicted_outcome: str
    actual_outcome: str
    match: bool
    context: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "rule": f"{self.rule_source} → {self.rule_target}",
            "predicted": self.predicted_outcome,
            "actual": self.actual_outcome,
            "match": self.match,
        }


VALID_RELATION_TYPES = RelationType.values()
VALID_RULE_LEVELS = ["A", "B", "C"]
