"""
Meta-pattern module - abstract causal patterns as fallback reasoning.

When event-level rules don't match a query, the engine can fall back to
meta-patterns (abstract causal templates like "resource exhaustion → collapse")
to provide guidance.

Meta-patterns are:
  - Abstracted away from specific entities (no names, places, dynasties)
  - Cross-domain applicable (history, economics, biology...)
  - Stored with generality rating and confidence
  - Matched via keyword + LLM semantic similarity

This module provides:
  1. MetaPatternStore - in-memory registry of meta-patterns
  2. MetaPatternMatcher - find applicable patterns for a given situation
  3. Built-in seed patterns for common causal archetypes
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..llm.provider import LLMProvider

logger = logging.getLogger(__name__)


@dataclass
class MetaPattern:
    """
    An abstract causal pattern.

    Example:
        MetaPattern(
            name="资源耗尽崩溃",
            abstract_logic="过度消耗关键资源 → 系统崩溃",
            mechanism="资源存量低于阈值时，维持系统运转的成本急剧上升",
            generality="high",
            confidence=0.85,
            modern_analogy="企业现金流断裂导致破产",
            keywords=["资源", "耗尽", "崩溃", "枯竭"],
        )
    """
    name: str
    abstract_logic: str
    mechanism: str = ""
    generality: str = "medium"
    confidence: float = 0.7
    modern_analogy: str = ""
    keywords: List[str] = field(default_factory=list)
    cross_domain_value: str = ""
    source_patterns: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "abstract_logic": self.abstract_logic,
            "mechanism": self.mechanism,
            "generality": self.generality,
            "confidence": round(self.confidence, 3),
            "modern_analogy": self.modern_analogy,
            "keywords": self.keywords,
            "cross_domain_value": self.cross_domain_value,
        }

    def matches_keywords(self, text: str) -> float:
        """Return match score (0.0-1.0) based on keyword overlap with text."""
        if not self.keywords:
            return 0.0
        text_lower = text.lower()
        matched = sum(1 for kw in self.keywords if kw.lower() in text_lower)
        return matched / len(self.keywords)


class MetaPatternStore:
    """
    In-memory registry of meta-patterns.

    Patterns can be:
      - Loaded from built-in seeds
      - Added manually
      - Discovered via LLM from existing event rules
    """

    def __init__(self):
        self._patterns: Dict[str, MetaPattern] = {}
        self._load_seeds()

    def _load_seeds(self):
        seeds = [
            MetaPattern(
                name="资源耗尽崩溃",
                abstract_logic="过度消耗关键资源 → 资源枯竭 → 系统崩溃",
                mechanism="资源存量低于维持阈值，系统无法正常运转",
                generality="high",
                confidence=0.85,
                modern_analogy="企业现金流断裂导致破产",
                keywords=["资源", "耗尽", "枯竭", "崩溃", "消耗", "空虚"],
                cross_domain_value="适用于生态、经济、军事等任何依赖关键资源的系统",
            ),
            MetaPattern(
                name="压迫反抗循环",
                abstract_logic="过度压迫 → 民众不满 → 反抗/叛乱 → 政权更替",
                mechanism="压迫积累超过容忍阈值，群体情绪转化为集体行动",
                generality="high",
                confidence=0.80,
                modern_analogy="劳资纠纷升级为罢工潮",
                keywords=["压迫", "不满", "反抗", "叛乱", "起义", "暴动"],
                cross_domain_value="历史规律在劳资关系、民族冲突、殖民地独立中反复出现",
            ),
            MetaPattern(
                name="过度扩张反噬",
                abstract_logic="快速扩张 → 资源分散 → 核心力下降 → 衰退",
                mechanism="扩张速度超过资源补充速度，导致核心能力被稀释",
                generality="high",
                confidence=0.80,
                modern_analogy="互联网公司盲目扩张导致资金链断裂",
                keywords=["扩张", "分散", "衰退", "过度", "战线"],
                cross_domain_value="帝国扩张、企业并购、物种入侵都遵循此模式",
            ),
            MetaPattern(
                name="制度僵化锁定",
                abstract_logic="制度固化 → 创新受阻 → 竞争力下降 → 被淘汰",
                mechanism="既得利益者维护现有制度，阻碍适应性变革",
                generality="high",
                confidence=0.75,
                modern_analogy="诺基亚因塞班系统锁定错过智能手机浪潮",
                keywords=["制度", "僵化", "锁定", "创新", "守旧", "淘汰"],
                cross_domain_value="技术锁定、路径依赖、组织惰性的统一解释",
            ),
            MetaPattern(
                name="外部冲击催化",
                abstract_logic="外部冲击 + 内部隐患 → 系统崩溃（仅有内部隐患不会崩溃）",
                mechanism="外部冲击是催化剂，暴露并放大内部结构性问题",
                generality="high",
                confidence=0.80,
                modern_analogy="新冠疫情暴露医疗体系结构性问题",
                keywords=["外部", "冲击", "催化", "天灾", "入侵", "内忧外患"],
                cross_domain_value="金融危机、战争、自然灾害中反复出现",
            ),
            MetaPattern(
                name="技术扩散竞赛",
                abstract_logic="技术创新 → 竞争优势 → 模仿扩散 → 优势消失 → 新一轮创新",
                mechanism="技术领先带来暂时优势，但必然被模仿，推动持续创新循环",
                generality="medium",
                confidence=0.75,
                modern_analogy="AI大模型从GPT独家优势到开源追赶",
                keywords=["技术", "扩散", "模仿", "创新", "优势", "追赶"],
                cross_domain_value="军事技术、商业竞争、学术研究中均适用",
            ),
            MetaPattern(
                name="信任崩塌连锁",
                abstract_logic="信任危机 → 合作瓦解 → 资源流失 → 系统加速崩溃",
                mechanism="信任是协作基础，一旦崩塌会产生正反馈的连锁反应",
                generality="high",
                confidence=0.80,
                modern_analogy="银行挤兑：传言→恐慌→挤兑→真倒闭",
                keywords=["信任", "信用", "合作", "背叛", "猜疑", "瓦解"],
                cross_domain_value="金融市场、国际关系、人际关系通用",
            ),
            MetaPattern(
                name="补偿适得其反",
                abstract_logic="问题出现 → 短期补偿措施 → 掩盖根本原因 → 问题恶化",
                mechanism="治标不治本的措施延缓了必要的结构性改革",
                generality="medium",
                confidence=0.75,
                modern_analogy="印钞救市 → 通胀加剧 → 更严重危机",
                keywords=["补偿", "掩盖", "治标", "饮鸩止渴", "短期"],
                cross_domain_value="经济政策、医疗、工程中常见的错误决策模式",
            ),
        ]
        for pattern in seeds:
            self._patterns[pattern.name] = pattern

    def add_pattern(self, pattern: MetaPattern) -> bool:
        if pattern.name in self._patterns:
            return False
        self._patterns[pattern.name] = pattern
        return True

    def get_pattern(self, name: str) -> Optional[MetaPattern]:
        return self._patterns.get(name)

    def list_patterns(
        self, min_generality: str = "", sort_by: str = "confidence"
    ) -> List[MetaPattern]:
        patterns = list(self._patterns.values())
        if min_generality:
            generality_order = {"high": 3, "medium": 2, "low": 1}
            patterns = [
                p for p in patterns
                if generality_order.get(p.generality, 0)
                >= generality_order.get(min_generality, 0)
            ]
        if sort_by == "confidence":
            patterns.sort(key=lambda p: -p.confidence)
        elif sort_by == "generality":
            generality_order = {"high": 3, "medium": 2, "low": 1}
            patterns.sort(
                key=lambda p: -generality_order.get(p.generality, 0)
            )
        return patterns

    def count(self) -> int:
        return len(self._patterns)


class MetaPatternMatcher:
    """
    Match meta-patterns against a given situation description.

    Two modes:
    1. Keyword matching (fast, no LLM needed)
    2. LLM semantic matching (slower, more accurate)
    """

    def __init__(
        self,
        store: MetaPatternStore,
        llm_provider: Optional[LLMProvider] = None,
    ):
        self.store = store
        self.llm = llm_provider

    def match_by_keywords(
        self, text: str, top_k: int = 3, min_score: float = 0.1
    ) -> List[Dict[str, Any]]:
        """Fast keyword-based matching. No LLM needed."""
        scored = []
        for pattern in self.store.list_patterns():
            score = pattern.matches_keywords(text)
            if score >= min_score:
                scored.append({
                    "pattern": pattern.to_dict(),
                    "match_score": round(score, 3),
                    "match_method": "keyword",
                })
        scored.sort(key=lambda x: -x["match_score"])
        return scored[:top_k]

    async def match_by_llm(
        self, context: str, top_k: int = 3
    ) -> List[Dict[str, Any]]:
        """
        LLM-based semantic matching. More accurate but requires LLM.

        Asks LLM to select the most applicable meta-patterns for the context.
        """
        if not self.llm:
            logger.error("match_by_llm requires an LLM provider")
            return []

        all_patterns = self.store.list_patterns()
        if not all_patterns:
            return []

        patterns_text = "\n".join(
            f"{i+1}. 【{p.name}】{p.abstract_logic}\n"
            f"   机制: {p.mechanism}\n"
            f"   通用性: {p.generality}"
            for i, p in enumerate(all_patterns)
        )

        prompt = f"""以下是一些因果元模式（抽象因果规律）：

{patterns_text}

请分析以下情境，选出最适用的 {top_k} 个元模式：

情境：{context}

输出 JSON 数组：
[
  {{
    "pattern_index": 1,
    "applicability": 0.0-1.0,
    "reasoning": "为什么适用（1句话）",
    "prediction": "基于此模式对情境的预测"
  }}
]"""

        messages = [
            {"role": "system", "content": "你是因果分析专家，擅长识别情境中的因果模式。"},
            {"role": "user", "content": prompt},
        ]

        try:
            response = await self.llm.chat(messages)
        except Exception as e:
            logger.error(f"LLM call failed in meta-pattern matching: {e}")
            return []

        cleaned = response.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Failed to parse LLM response in meta-pattern matching")
            return []

        if not isinstance(data, list):
            return []

        results = []
        for item in data[:top_k]:
            idx = item.get("pattern_index", 0) - 1
            if 0 <= idx < len(all_patterns):
                pattern = all_patterns[idx]
                results.append({
                    "pattern": pattern.to_dict(),
                    "match_score": float(item.get("applicability", 0.5)),
                    "match_method": "llm_semantic",
                    "reasoning": item.get("reasoning", ""),
                    "prediction": item.get("prediction", ""),
                })

        results.sort(key=lambda x: -x["match_score"])
        return results
