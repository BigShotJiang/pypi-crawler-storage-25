"""
Rule Discovery Module - discover new causal rules from context.

Provides three capabilities:
1. discover_rules() - LLM generates candidate rules from context
2. validate_rule() - dedup + conflict detection against existing KG
3. adjust_confidence() - update rule confidence based on feedback

All input/output uses protocol.py models for consistency.
All storage operations go through StorageInterface (no SQL hardcoding).
"""

import json
import logging
from typing import Any, Dict, List, Optional

from .protocol import (
    CandidateRule,
    DiscoverRequest,
    DiscoverResult,
    FeedbackRequest,
    ValidationResult,
    VALID_RELATION_TYPES,
)
from ..llm.provider import LLMProvider

logger = logging.getLogger(__name__)

DISCOVERY_SYSTEM_PROMPT = """你是一个因果规则发现助手。你的任务是从给定的情境中推断可能的因果关系。

规则：
1. 只输出事件级的因果规则，不要包含具体人名、地名、朝代名
2. 每条规则必须是 source → target 的形式
3. relation_type 只能是：causes（导致）、enables（使能）、prevents（阻止）、correlates（相关）
4. confidence 表示这条规则的可靠性，范围 0.0-1.0
5. 如果有催化剂（使规则更容易成立的条件）或抑制剂（使规则更难成立的条件），请列出
6. 推理过程简要说明即可

输出格式为 JSON 数组，不要输出其他内容。"""

DISCOVERY_USER_TEMPLATE = """请分析以下情境，推断可能的因果规则。

【情境描述】
{context}

【当前世界状态】
{world_state}

【已有的相关规则（供参考，避免重复）】
{existing_rules}

请推断最多 {max_candidates} 条最可能的因果规则。

输出 JSON 数组：
[
  {{
    "source": "原因（事件级，如：提高税收）",
    "target": "结果（事件级，如：民众不满）",
    "relation_type": "causes/enables/prevents/correlates",
    "confidence": 0.0-1.0,
    "reasoning": "简要推理过程",
    "catalysts": ["催化剂1", "催化剂2"],
    "inhibitors": ["抑制剂1"]
  }}
]"""


class RuleDiscovery:
    """
    Rule discovery engine.

    Usage:
        discovery = RuleDiscovery(engine)
        # Or with LLM for generation:
        discovery = RuleDiscovery(engine, llm_provider=my_llm)

        result = await discovery.discover_rules(DiscoverRequest(
            context="皇帝提高南方三省税收三倍",
            world_state={"国库": "空虚", "民怨": "高"},
        ))
    """

    def __init__(self, engine, llm_provider: Optional[LLMProvider] = None):
        self.engine = engine
        self.llm = llm_provider

    async def discover_rules(self, request: DiscoverRequest) -> DiscoverResult:
        """
        Generate candidate rules from context using LLM.

        Steps:
        1. Fetch existing related rules from KG (for dedup reference)
        2. Call LLM to generate candidates
        3. Validate each candidate (dedup + conflict)
        4. Return results (committed count, skipped, conflicts)
        """
        if not self.llm:
            logger.error("discover_rules requires an LLM provider")
            return DiscoverResult()

        existing_rules = self._fetch_related_rules(request.existing_rules_hint)

        existing_text = "\n".join(
            f"  - {r['source']} --[{r['relation_type']}]--> {r['target']} (conf={r['confidence']})"
            for r in existing_rules[:20]
        ) or "（无）"

        world_state_text = json.dumps(
            request.world_state, ensure_ascii=False, indent=2
        ) if request.world_state else "（未提供）"

        prompt = DISCOVERY_USER_TEMPLATE.format(
            context=request.context,
            world_state=world_state_text,
            existing_rules=existing_text,
            max_candidates=request.max_candidates,
        )

        messages = [
            {"role": "system", "content": DISCOVERY_SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ]

        try:
            response = await self.llm.chat(messages)
        except Exception as e:
            logger.error(f"LLM call failed in discover_rules: {e}")
            return DiscoverResult()

        candidates = self._parse_candidates(response)
        if not candidates:
            return DiscoverResult()

        result = DiscoverResult(candidates=candidates)

        for candidate in candidates:
            validation = self.validate_rule(candidate)
            result.validated.append(validation)

            if validation.is_duplicate:
                result.skipped_duplicates += 1
                continue

            if validation.conflicts:
                result.conflicts_found += 1

            if validation.is_valid:
                committed = self._commit_rule(candidate, validation.recommended_level)
                if committed:
                    result.committed += 1

        logger.info(
            f"Rule discovery: {len(candidates)} candidates, "
            f"{result.committed} committed, "
            f"{result.skipped_duplicates} duplicates, "
            f"{result.conflicts_found} conflicts"
        )
        return result

    def validate_rule(self, rule: CandidateRule) -> ValidationResult:
        """
        Validate a candidate rule against the existing KG.

        Checks:
        1. Duplicate detection (same source+target+relation_type)
        2. Conflict detection (contradictory relations)
        3. Recommend rule level based on confidence and conflicts
        """
        is_dup = self._check_duplicate(rule.source, rule.target, rule.relation_type)
        if is_dup:
            return ValidationResult(
                is_valid=False,
                rule=rule,
                is_duplicate=True,
                recommended_level=rule.level,
                message="Duplicate of existing rule",
            )

        conflicts = self._check_conflicts(rule.source, rule.target, rule.relation_type)

        recommended_level = rule.level
        if rule.confidence >= 0.8 and not conflicts:
            recommended_level = "A"
        elif rule.confidence >= 0.5 and not conflicts:
            recommended_level = "B"
        elif conflicts:
            recommended_level = "C"
        else:
            recommended_level = "C"

        is_valid = recommended_level in ("A", "B") or (
            recommended_level == "C" and not conflicts
        )

        conflict_descriptions = [
            {
                "type": "contradictory",
                "existing": f"{rule.source} --[{c['relation_type']}]--> {rule.target}",
                "confidence": c["confidence"],
            }
            for c in conflicts
        ]

        message = ""
        if conflicts:
            message = f"Found {len(conflicts)} potential conflicts"
        elif is_valid:
            message = "Rule validated successfully"

        return ValidationResult(
            is_valid=is_valid,
            rule=rule,
            conflicts=conflict_descriptions,
            is_duplicate=False,
            recommended_level=recommended_level,
            message=message,
        )

    def adjust_confidence(
        self,
        source: str,
        target: str,
        relation_type: str,
        delta: float,
    ) -> bool:
        """
        Adjust the confidence of an existing rule.

        Typically called by the feedback loop:
        - prediction correct → delta = +0.05
        - prediction wrong → delta = -0.05
        """
        storage = self.engine.storage
        existing = storage.find_entity_relation(source, target, relation_type)
        if not existing:
            logger.warning(f"Rule not found: {source} → {target} ({relation_type})")
            return False

        old_conf = float(existing["confidence"])
        new_conf = max(0.1, min(1.0, old_conf + delta))

        updated = storage.update_relation_confidence(
            source, target, relation_type, new_conf
        )

        if updated:
            logger.info(
                f"Confidence adjusted: {source} → {target} "
                f"{old_conf:.3f} → {new_conf:.3f} (delta={delta:+.3f})"
            )
        return updated

    def process_feedback(self, feedback: FeedbackRequest) -> Dict[str, Any]:
        """
        Process runtime feedback from application layer.

        If prediction matched actual → increase confidence
        If prediction did not match → decrease confidence + optionally trigger discovery
        """
        if feedback.match:
            adjusted = self.adjust_confidence(
                feedback.rule_source,
                feedback.rule_target,
                feedback.rule_relation_type,
                delta=0.05,
            )
            return {
                "action": "confidence_increased",
                "adjusted": adjusted,
                "message": "Prediction matched, confidence increased",
            }
        else:
            adjusted = self.adjust_confidence(
                feedback.rule_source,
                feedback.rule_target,
                feedback.rule_relation_type,
                delta=-0.05,
            )
            return {
                "action": "confidence_decreased",
                "adjusted": adjusted,
                "message": "Prediction did not match, confidence decreased",
                "predicted": feedback.predicted_outcome,
                "actual": feedback.actual_outcome,
                "suggestion": "Consider triggering discover_rules to find missing rules",
            }

    def _fetch_related_rules(
        self, hints: List[str]
    ) -> List[Dict[str, Any]]:
        """Fetch existing rules from KG that match the given hints."""
        if not hints:
            return []

        rules = []
        for hint in hints[:5]:
            rows = self.engine.storage.search_entity_relations(hint, limit=5)
            rules.extend(rows)
        return rules

    def _check_duplicate(
        self, source: str, target: str, relation_type: str
    ) -> bool:
        """Check if exact same rule already exists in KG."""
        existing = self.engine.storage.find_entity_relation(
            source, target, relation_type
        )
        return existing is not None

    def _check_conflicts(
        self, source: str, target: str, relation_type: str
    ) -> List[Dict[str, Any]]:
        """
        Check for conflicting rules.

        A conflict is when the same source-target pair has a contradictory
        relation type (e.g., causes vs prevents for the same pair).
        """
        conflicts = self.engine.storage.find_conflicting_relations(
            source, target, relation_type
        )
        return [
            {
                "conflict_type": "contradictory",
                "source": source,
                "target": target,
                "relation_type": c["relation_type"],
                "confidence": float(c["confidence"]),
            }
            for c in conflicts
        ]

    def _commit_rule(self, rule: CandidateRule, level: str) -> bool:
        """Commit a validated rule to the KG via inject_action."""
        from .action_models import Action, ActionRelation

        action = Action(
            name=f"discovered_rule:{rule.source}→{rule.target}",
            relations=[
                ActionRelation(
                    source=rule.source,
                    target=rule.target,
                    relation_type=rule.relation_type,
                    confidence=rule.confidence,
                )
            ],
            metadata={
                "level": level,
                "source": "rule_discovery",
                "reasoning": rule.reasoning,
                "catalysts": rule.catalysts,
                "inhibitors": rule.inhibitors,
            },
        )

        try:
            result = self.engine.inject_action(action)
            logger.info(
                f"Rule committed: {rule.source} → {rule.target} "
                f"({rule.relation_type}, level={level})"
            )
            return result.relations_added > 0
        except Exception as e:
            logger.error(f"Failed to commit rule: {e}")
            return False

    def _parse_candidates(self, llm_response: str) -> List[CandidateRule]:
        """Parse LLM response into CandidateRule objects."""
        cleaned = llm_response.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError:
            logger.warning("Failed to parse LLM response as JSON")
            return []

        if not isinstance(data, list):
            return []

        candidates = []
        for item in data[:10]:
            try:
                rt = item.get("relation_type", "causes")
                if rt not in VALID_RELATION_TYPES:
                    rt = "causes"

                conf = float(item.get("confidence", 0.5))
                conf = max(0.1, min(1.0, conf))

                candidates.append(
                    CandidateRule(
                        source=item["source"],
                        target=item["target"],
                        relation_type=rt,
                        confidence=conf,
                        reasoning=item.get("reasoning", ""),
                        catalysts=item.get("catalysts", []),
                        inhibitors=item.get("inhibitors", []),
                        level="B",
                    )
                )
            except (KeyError, ValueError, TypeError) as e:
                logger.warning(f"Skipping invalid candidate: {e}")
                continue

        return candidates
