"""
Knowledge Graph Reasoner - entity-level causal chain reasoning.
"""
import json
import logging
from typing import Any, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass
from collections import defaultdict

from ..storage.postgresql_storage import PostgreSQLStorage

logger = logging.getLogger(__name__)

TRANSMITTABLE = {
    "causes": {"causes", "enables"},
    "enables": {"enables", "causes"},
    "correlates": set(),
    "prevents": {"prevents"},
}
MIN_CHAIN_CONF = 0.40
MAX_DEPTH = 6


@dataclass
class ChainLink:
    source_entity_id: str
    source_name: str
    target_entity_id: str
    target_name: str
    relation_type: str
    confidence: float
    is_inferred: bool = False


@dataclass
class CausalChain:
    start_name: str
    end_name: str
    links: List[ChainLink]
    total_confidence: float
    cross_text: bool = False

    @property
    def length(self) -> int:
        return len(self.links)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "start": self.start_name,
            "end": self.end_name,
            "length": self.length,
            "confidence": round(self.total_confidence, 3),
            "cross_text": self.cross_text,
            "chain": [
                {
                    "from": l.source_name,
                    "to": l.target_name,
                    "type": l.relation_type,
                    "conf": round(l.confidence, 3),
                    "inferred": l.is_inferred,
                }
                for l in self.links
            ],
        }


@dataclass
class InferredRelation:
    source_name: str
    target_name: str
    relation_type: str
    confidence: float
    chain_length: int
    evidence_chain: List[Dict[str, Any]]
    cross_text: bool


class KnowledgeGraphReasoner:
    """Reasoner over entity-level causal knowledge graph."""

    def __init__(self, storage: PostgreSQLStorage):
        self.storage = storage
        self._fwd: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._bwd: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self._names: Dict[str, str] = {}
        self._trads: Dict[str, Set[str]] = {}
        self._srcs: Dict[str, Set[str]] = {}
        self._loaded = False

    def load_graph(self) -> Tuple[int, int]:
        """Load all entity relations into memory."""
        logger.info("Loading entity relation graph...")

        entities = self.storage._execute_sql(
            "SELECT id, canonical_name, traditions, sources FROM public.unified_entities"
        )
        for e in entities:
            self._names[e["id"]] = e["canonical_name"]
            t = e.get("traditions")
            if isinstance(t, list):
                self._trads[e["id"]] = set(t)
            elif isinstance(t, str):
                try:
                    self._trads[e["id"]] = set(json.loads(t))
                except Exception:
                    self._trads[e["id"]] = set()
            s = e.get("sources")
            if isinstance(s, list):
                self._srcs[e["id"]] = set(s)
            elif isinstance(s, str):
                try:
                    self._srcs[e["id"]] = set(json.loads(s))
                except Exception:
                    self._srcs[e["id"]] = set()

        rels = self.storage._execute_sql("""
            SELECT source_entity_id, target_entity_id, relation_type, confidence
            FROM public.entity_relations
        """)
        for r in rels:
            self._fwd[r["source_entity_id"]].append({
                "target": r["target_entity_id"],
                "type": r["relation_type"],
                "confidence": float(r["confidence"]),
            })
            self._bwd[r["target_entity_id"]].append({
                "target": r["source_entity_id"],
                "type": r["relation_type"],
                "confidence": float(r["confidence"]),
            })

        self._loaded = True
        n_nodes = len(self._names)
        n_edges = len(rels)
        logger.info(f"Graph loaded: {n_nodes} nodes, {n_edges} edges")
        return n_nodes, n_edges

    def get_entity_id(self, name: str) -> Optional[str]:
        """Find entity ID by canonical name."""
        for eid, ename in self._names.items():
            if ename == name:
                return eid
        return None

    def trace_forward(self, entity_name: str, max_depth: int = MAX_DEPTH) -> List[CausalChain]:
        """Find all causal chains going FORWARD from this entity."""
        eid = self.get_entity_id(entity_name)
        if not eid:
            return []
        results: List[CausalChain] = []
        self._dfs(eid, [], set(), results, max_depth, self._fwd)
        results.sort(key=lambda c: c.total_confidence, reverse=True)
        return results

    def trace_backward(self, entity_name: str, max_depth: int = MAX_DEPTH) -> List[CausalChain]:
        """Find all causal chains going BACKWARD (causes of)."""
        eid = self.get_entity_id(entity_name)
        if not eid:
            return []
        results: List[CausalChain] = []
        self._dfs(eid, [], set(), results, max_depth, self._bwd)
        results.sort(key=lambda c: c.total_confidence, reverse=True)
        return results

    def trace_between(self, source_name: str, target_name: str,
                      max_depth: int = MAX_DEPTH) -> List[CausalChain]:
        """Find causal chains connecting two entities."""
        src = self.get_entity_id(source_name)
        tgt = self.get_entity_id(target_name)
        if not src or not tgt:
            return []
        all_fwd: List[CausalChain] = []
        self._dfs(src, [], set(), all_fwd, max_depth, self._fwd)
        chains = [c for c in all_fwd if c.links[-1].target_entity_id == tgt]
        chains.sort(key=lambda c: c.total_confidence, reverse=True)
        return chains

    def discover_transitive(self, min_confidence: float = 0.50,
                            max_length: int = 3) -> List[InferredRelation]:
        """Batch discover implicit transitive relations."""
        if not self._loaded:
            self.load_graph()

        discovered: List[InferredRelation] = []
        seen: Set[Tuple[str, str, str]] = set()

        for eid in list(self._fwd.keys()):
            chains: List[CausalChain] = []
            self._dfs(eid, [], set(), chains, max_length, self._fwd)

            for chain in chains:
                if chain.total_confidence < min_confidence or chain.length < 2:
                    continue

                src_id = chain.links[0].source_entity_id
                tgt_id = chain.links[-1].target_entity_id
                implied = self._implied_type([l.relation_type for l in chain.links])
                if not implied:
                    continue

                pair = (src_id, tgt_id, implied)
                if pair in seen or self._has_direct(src_id, tgt_id, implied):
                    continue

                seen.add(pair)
                discovered.append(InferredRelation(
                    source_name=self._names.get(src_id, "?"),
                    target_name=self._names.get(tgt_id, "?"),
                    relation_type=implied,
                    confidence=chain.total_confidence,
                    chain_length=chain.length,
                    evidence_chain=[
                        {"from": l.source_name, "to": l.target_name,
                         "type": l.relation_type, "conf": round(l.confidence, 3)}
                        for l in chain.links
                    ],
                    cross_text=self._is_cross(chain.links),
                ))

        discovered.sort(key=lambda d: d.confidence, reverse=True)
        return discovered

    def _dfs(self, current: str, path: List[ChainLink], visited: Set[str],
             results: List[CausalChain], max_depth: int,
             adj: Dict[str, List[Dict[str, Any]]]):
        if len(path) >= max_depth:
            return

        for neighbor in adj.get(current, []):
            nxt = neighbor["target"]
            if nxt in visited or nxt == current:
                continue

            if path:
                if not self._transmittable(path[-1].relation_type, neighbor["type"]):
                    continue

            link = ChainLink(
                source_entity_id=current,
                source_name=self._names.get(current, "?"),
                target_entity_id=nxt,
                target_name=self._names.get(nxt, "?"),
                relation_type=neighbor["type"],
                confidence=neighbor["confidence"],
            )

            new_path = path + [link]
            conf = self._chain_conf(new_path)
            if conf >= MIN_CHAIN_CONF:
                results.append(CausalChain(
                    start_name=new_path[0].source_name,
                    end_name=new_path[-1].target_name,
                    links=list(new_path),
                    total_confidence=conf,
                    cross_text=self._is_cross(new_path),
                ))

            self._dfs(nxt, new_path, visited | {current}, results, max_depth, adj)

    @staticmethod
    def _transmittable(from_type: str, to_type: str) -> bool:
        return to_type in TRANSMITTABLE.get(from_type, set())

    @staticmethod
    def _implied_type(types: List[str]) -> Optional[str]:
        if not types:
            return None
        if all(t == "causes" for t in types):
            return "causes"
        if "prevents" in types:
            n = sum(1 for t in types if t == "prevents")
            return "prevents" if n % 2 == 1 else "causes"
        return "causes"

    @staticmethod
    def _chain_conf(links: List[ChainLink]) -> float:
        if not links:
            return 0.0
        conf = 1.0
        for l in links:
            conf *= l.confidence
        penalty = 0.92 ** (len(links) - 1)
        return min(conf * penalty, 0.95)

    def _is_cross(self, links: List[ChainLink]) -> bool:
        if len(links) < 2:
            return False
        all_s: Set[str] = set()
        for l in links:
            srcs = self._srcs.get(l.source_entity_id)
            if srcs and len(srcs) > 0:
                all_s |= srcs
            else:
                all_s |= self._trads.get(l.source_entity_id, set())
            tgt_s = self._srcs.get(l.target_entity_id)
            if tgt_s and len(tgt_s) > 0:
                all_s |= tgt_s
            else:
                all_s |= self._trads.get(l.target_entity_id, set())
        return len(all_s) > 1

    def _has_direct(self, src: str, tgt: str, rel_type: str) -> bool:
        for n in self._fwd.get(src, []):
            if n["target"] == tgt and n["type"] == rel_type:
                return True
        return False

    def _ensure_inferred_column(self):
        """Add is_inferred column to entity_relations if not exists."""
        try:
            self.storage._execute_sql(
                "ALTER TABLE public.entity_relations ADD COLUMN IF NOT EXISTS "
                "is_inferred BOOLEAN DEFAULT FALSE",
                fetch=False, commit=True,
            )
            logger.info("entity_relations.is_inferred column ready")
        except Exception as e:
            logger.warning(f"Failed to ensure is_inferred column: {e}")

    def persist_discoveries(self, min_confidence: float = 0.50,
                            max_length: int = 3) -> Dict[str, Any]:
        """Discover and persist transitive relations to entity_relations.

        Returns stats dict with counts of inserted/skipped relations.
        """
        import uuid

        self._ensure_inferred_column()
        discovered = self.discover_transitive(min_confidence, max_length)

        inserted = 0
        skipped = 0

        for d in discovered:
            src_id = None
            for eid, ename in self._names.items():
                if ename == d.source_name:
                    src_id = eid
                    break
            tgt_id = None
            for eid, ename in self._names.items():
                if ename == d.target_name:
                    tgt_id = eid
                    break
            if not src_id or not tgt_id:
                skipped += 1
                continue

            existing = self.storage._execute_sql("""
                SELECT COUNT(*) as cnt FROM public.entity_relations
                WHERE source_entity_id = :src AND target_entity_id = :tgt
                  AND relation_type = :rtype AND is_inferred = TRUE
            """, {"src": src_id, "tgt": tgt_id, "rtype": d.relation_type})

            if existing and existing[0]["cnt"] > 0:
                skipped += 1
                continue

            ent_id = str(uuid.uuid4())
            self.storage._execute_sql("""
                INSERT INTO public.entity_relations
                    (id, source_entity_id, target_entity_id, relation_type,
                     confidence, is_inferred, evidence_descriptions,
                     source_names, target_names)
                VALUES (:id, :src, :tgt, :rtype, :conf, TRUE,
                        CAST(:evidence AS jsonb),
                        CAST(:snames AS jsonb), CAST(:tnames AS jsonb))
            """, {
                "id": ent_id, "src": src_id, "tgt": tgt_id,
                "rtype": d.relation_type, "conf": round(d.confidence, 3),
                "evidence": json.dumps(d.evidence_chain, ensure_ascii=False),
                "snames": json.dumps([d.source_name], ensure_ascii=False),
                "tnames": json.dumps([d.target_name], ensure_ascii=False),
            }, fetch=False, commit=True)
            inserted += 1

        logger.info(f"Persisted {inserted} inferred relations (skipped {skipped})")
        return {
            "discovered": len(discovered),
            "inserted": inserted,
            "skipped": skipped,
        }
