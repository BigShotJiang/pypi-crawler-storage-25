"""
Action injection models - event-driven causal reasoning.

Enables applications to inject actions into the engine, automatically
persist them as entities/relations, and return predicted consequences
by tracing causal chains through the knowledge graph.
"""

import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ActionRelation:
    """
    A single causal relation introduced by an action.

    Attributes:
        source: cause entity name
        target: effect entity name
        relation_type: causes / enables / prevents / correlates
        confidence: 0.0 - 1.0
    """
    source: str
    target: str
    relation_type: str = "causes"
    confidence: float = 0.8
    conditions: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Action:
    """
    An action to be injected into the causal engine.

    The engine will:
    1. Ensure entities exist in the knowledge graph
    2. Persist the declared relations
    3. Trace forward from the action's effects to predict consequences
    4. Return all predicted chains

    Attributes:
        name: human-readable action name (e.g. "increase taxes")
        actor: who performed the action (optional)
        relations: causal relations introduced by this action
        metadata: arbitrary application-specific data
    """
    name: str
    relations: List[ActionRelation] = field(default_factory=list)
    actor: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ChainStep:
    """
    One link in a predicted consequence chain.

    Attributes:
        source: entity name
        target: entity name
        relation_type: causes / enables / prevents / correlates
        confidence: confidence of this link
        is_new: whether this relation was just injected (vs existing)
    """
    source: str
    target: str
    relation_type: str
    confidence: float
    is_new: bool = False


@dataclass
class ConsequenceChain:
    """
    A complete predicted consequence chain.

    Attributes:
        trigger: the action relation that started this chain
        steps: ordered list of causal links
        total_confidence: decayed confidence across all steps
        length: number of links
    """
    trigger: str
    steps: List[ChainStep] = field(default_factory=list)
    total_confidence: float = 0.0
    length: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trigger": self.trigger,
            "steps": [
                {
                    "source": s.source,
                    "target": s.target,
                    "relation_type": s.relation_type,
                    "confidence": round(s.confidence, 3),
                    "is_new": s.is_new,
                }
                for s in self.steps
            ],
            "total_confidence": round(self.total_confidence, 3),
            "length": self.length,
        }


@dataclass
class ActionResult:
    """
    Complete result of an action injection.

    Attributes:
        action_name: the injected action name
        entities_affected: entity names touched by this action
        relations_added: number of new relations written to KG
        consequence_chains: predicted causal chains from this action
        immediate_effects: direct effects (1-step)
        downstream_effects: multi-step chain effects
    """
    action_name: str
    entities_affected: List[str] = field(default_factory=list)
    relations_added: int = 0
    consequence_chains: List[ConsequenceChain] = field(default_factory=list)
    immediate_effects: List[Dict[str, Any]] = field(default_factory=list)
    downstream_effects: List[Dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_name": self.action_name,
            "entities_affected": self.entities_affected,
            "relations_added": self.relations_added,
            "chains_found": len(self.consequence_chains),
            "immediate_effects": self.immediate_effects,
            "downstream_effects": self.downstream_effects,
            "chains": [c.to_dict() for c in self.consequence_chains],
        }
