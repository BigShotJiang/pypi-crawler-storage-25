"""
核心因果推断引擎

重要说明：
1. 这个引擎使用存储接口（StorageInterface）来管理事件和关系
2. 不再使用内存缓存（_events_cache），而是从存储中读取
3. 所有因果推断都基于存储中的数据
4. 使用 Lancet Method 进行任务分解和分层调用
5. 支持 Iterative Workflow 进行迭代优化

核心因果推断流程：
1. 时序检查 - 原因必须在结果之前
2. 必要性检查 - 没有原因，结果是否还会发生
3. 充分性检查 - 有原因，结果是否一定发生
4. 直接性检查 - 是否有中间事件
5. 混杂因素检查 - 是否有共同原因
6. 证据强度检查 - 证据是否充分
7. 综合判断 - 综合所有检查结果

使用示例：
    from generic_causal_architecture.storage import MemoryStorage, Config
    from generic_causal_architecture.core import CausalEngine
    from generic_causal_architecture.methods import LancetMethod, IterativeWorkflow
    
    config = Config.from_yaml("config.yaml")
    storage = config.get_storage()
    storage.initialize()
    
    engine = CausalEngine(storage, config.causal)
    
    # 设置方法论
    lancet = LancetMethod(config.layer)
    workflow = IterativeWorkflow(engine, lancet)
    engine.set_methodology(lancet, workflow)
    
    # 因果推断
    has_causality = engine.infer_causality(event_a, event_b)
    confidence = engine.get_causal_confidence(event_a, event_b)
    explanation = engine.explain_causality(event_a, event_b)
"""

from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import json
import logging
import math
import uuid

from ..storage.storage_interface import StorageInterface, EventData, CausalRelation
from ..methods.lancet_method import LancetMethod, TaskFeatures, LayerLevel, SolutionType
from ..methods.iterative_workflow import IterativeWorkflow
from .action_models import Action, ActionResult, ConsequenceChain, ChainStep
from .kg_reasoner import KnowledgeGraphReasoner, CausalChain, InferredRelation
from .rule_discovery import RuleDiscovery
from .meta_patterns import MetaPatternStore, MetaPatternMatcher, MetaPattern
from .protocol import (
    CandidateRule,
    DiscoverRequest,
    DiscoverResult,
    FeedbackRequest,
    ValidationResult,
)

logger = logging.getLogger(__name__)


class CausalCheckType(Enum):
    """因果检查类型"""
    TEMPORAL = "temporal"  # 时序检查
    NECESSITY = "necessity"  # 必要性检查
    SUFFICIENCY = "sufficiency"  # 充分性检查
    DIRECTNESS = "directness"  # 直接性检查
    CONFOUNDING = "confounding"  # 混杂因素检查
    EVIDENCE = "evidence"  # 证据强度检查
    MECHANISM = "mechanism"  # 机制解释检查


class CausalRelationType(Enum):
    """因果关系类型"""
    DIRECT_CAUSE = "direct_cause"  # 直接原因
    INDIRECT_CAUSE = "indirect_cause"  # 间接原因
    ENABLING_CONDITION = "enabling_condition"  # 使能条件
    PREVENTING_FACTOR = "preventing_factor"  # 阻碍因素
    CONTRIBUTING_FACTOR = "contributing_factor"  # 促成因素
    NECESSARY_CONDITION = "necessary_condition"  # 必要条件
    SUFFICIENT_CONDITION = "sufficient_condition"  # 充分条件


@dataclass
class CausalCheckResult:
    """因果检查结果"""
    check_type: CausalCheckType
    passed: bool
    score: float  # 0-1
    evidence: List[str]  # 支持证据
    reasoning: str  # 推理过程
    confidence: float  # 该检查的置信度


@dataclass
class CausalInferenceResult:
    """因果推断结果"""
    has_causality: bool
    relation_type: Optional[CausalRelationType]
    overall_confidence: float
    check_results: List[CausalCheckResult]
    reasoning_chain: List[str]
    evidence_sources: List[str]
    alternative_explanations: List[str]
    suggestions: List[str]  # 改进建议


class CausalEngine:
    """
    因果推断引擎
    
    核心功能：
    1. 严格因果检查（7 步检查）
    2. 置信度计算（多证据叠加）
    3. 可解释性（推理链）
    4. 领域适配（支持不同领域）
    5. 方法论支持（Lancet + Iterative）
    
    设计原则：
    - 严格检查（不轻易断定因果）
    - 多证据叠加（单一证据不足信）
    - 可解释（每一步都有理由）
    - 成本敏感（分层调用）
    - 持续优化（迭代改进）
    """
    
    def __init__(self, storage: StorageInterface, causal_config: Any = None, 
                 domain_adapter=None):
        """
        初始化因果引擎
        
        Args:
            storage: StorageInterface 的实现（必需）
            causal_config: 因果推断配置（包含阈值等参数）
            domain_adapter: 领域适配器，用于领域特定的因果推断
        """
        if storage is None:
            raise ValueError("storage is required")
        
        self.storage = storage
        self.causal_config = causal_config
        self.domain_adapter = domain_adapter
        
        self.lancet_method: Optional[LancetMethod] = None
        self.iterative_workflow: Optional[IterativeWorkflow] = None
        self.kg_reasoner: Optional[KnowledgeGraphReasoner] = None
        self._rule_discovery: Optional[RuleDiscovery] = None
        self._meta_store: Optional[MetaPatternStore] = None
        self._meta_matcher: Optional[MetaPatternMatcher] = None

        self._causal_cache: Dict[str, CausalInferenceResult] = {}
        self._inference_count = 0
        self._cache_hits = 0

        self._init_kg_reasoner()
        self._init_meta_patterns()

    def _init_kg_reasoner(self):
        """Auto-load KG reasoner when PostgreSQLStorage is available."""
        try:
            from ..storage.postgresql_storage import PostgreSQLStorage
            if isinstance(self.storage, PostgreSQLStorage):
                self.kg_reasoner = KnowledgeGraphReasoner(self.storage)
                self.kg_reasoner.load_graph()
                logger.info("KG reasoner auto-loaded from PostgreSQLStorage")
        except Exception as e:
            logger.debug(f"KG reasoner auto-load skipped: {e}")

    def _init_meta_patterns(self):
        """Initialize meta-pattern store with built-in seeds."""
        self._meta_store = MetaPatternStore()
        self._meta_matcher = MetaPatternMatcher(self._meta_store)
        logger.info(f"Meta-pattern store loaded: {self._meta_store.count()} patterns")

    def set_methodology(self, lancet_method: LancetMethod, 
                       workflow: IterativeWorkflow) -> None:
        """
        设置方法论组件
        
        Args:
            lancet_method: 柳叶刀方法实例
            workflow: 迭代工作流实例
        """
        self.lancet_method = lancet_method
        self.iterative_workflow = workflow
        logger.info("Methodology components set")
    
    def set_domain_adapter(self, domain_adapter: Any) -> None:
        """
        设置领域适配器
        
        Args:
            domain_adapter: 领域适配器实例
        """
        self.domain_adapter = domain_adapter
        logger.info("Domain adapter set")
    
    def infer_causality(self, event_a: Any, event_b: Any, 
                       use_cache: bool = True) -> bool:
        """
        推断两个事件之间的因果关系
        
        Args:
            event_a: 事件 A（可能的原因）
            event_b: 事件 B（可能的结果）
            use_cache: 是否使用缓存
        
        Returns:
            bool: 如果存在因果关系返回 True，否则返回 False
        """
        result = self._infer_causality_detailed(event_a, event_b, use_cache)
        return result.has_causality
    
    def get_causal_confidence(self, event_a: Any, event_b: Any) -> float:
        """
        获取因果关系的置信度
        
        Args:
            event_a: 事件 A
            event_b: 事件 B
        
        Returns:
            float: 置信度分数，范围 0-1
        """
        result = self._infer_causality_detailed(event_a, event_b)
        return result.overall_confidence
    
    def _infer_causality_detailed(self, event_a: Any, event_b: Any, 
                                  use_cache: bool = True) -> CausalInferenceResult:
        """
        详细的因果推断（返回完整结果）
        
        Args:
            event_a: 事件 A
            event_b: 事件 B
            use_cache: 是否使用缓存
        
        Returns:
            CausalInferenceResult: 详细的因果推断结果
        """
        # 检查缓存
        cache_key = f"{self._get_event_id(event_a)}->{self._get_event_id(event_b)}"
        if use_cache and cache_key in self._causal_cache:
            self._cache_hits += 1
            self._inference_count += 1
            return self._causal_cache[cache_key]
        
        self._inference_count += 1
        
        # 执行 7 步因果检查
        check_results = self._run_causal_checks(event_a, event_b)
        
        # 综合判断
        has_causality, relation_type, confidence = self._synthesize_checks(
            check_results, event_a, event_b
        )
        
        # 生成推理链
        reasoning_chain = self._generate_reasoning_chain(check_results, has_causality)
        
        # 收集证据来源
        evidence_sources = self._collect_evidence_sources(event_a, event_b)
        
        # 生成替代解释
        alternative_explanations = self._generate_alternatives(check_results)
        
        # 生成建议
        suggestions = self._generate_suggestions(check_results, has_causality)
        
        result = CausalInferenceResult(
            has_causality=has_causality,
            relation_type=relation_type,
            overall_confidence=confidence,
            check_results=check_results,
            reasoning_chain=reasoning_chain,
            evidence_sources=evidence_sources,
            alternative_explanations=alternative_explanations,
            suggestions=suggestions
        )
        
        # 缓存结果
        if use_cache:
            self._causal_cache[cache_key] = result
        
        return result
    
    def _run_causal_checks(self, event_a: Any, event_b: Any) -> List[CausalCheckResult]:
        """
        执行 7 步因果检查
        
        Args:
            event_a: 事件 A
            event_b: 事件 B
        
        Returns:
            List[CausalCheckResult]: 检查结果列表
        """
        check_results = []
        
        # 1. 时序检查
        temporal_result = self._check_temporal(event_a, event_b)
        check_results.append(temporal_result)
        
        # 如果时序检查失败，可以直接返回（原因必须在结果之前）
        if not temporal_result.passed:
            return check_results
        
        # 2. 必要性检查
        necessity_result = self._check_necessity(event_a, event_b)
        check_results.append(necessity_result)
        
        # 3. 充分性检查
        sufficiency_result = self._check_sufficiency(event_a, event_b)
        check_results.append(sufficiency_result)
        
        # 4. 直接性检查
        directness_result = self._check_directness(event_a, event_b)
        check_results.append(directness_result)
        
        # 5. 混杂因素检查
        confounding_result = self._check_confounding(event_a, event_b)
        check_results.append(confounding_result)
        
        # 6. 证据强度检查
        evidence_result = self._check_evidence_strength(event_a, event_b)
        check_results.append(evidence_result)
        
        # 7. 机制解释检查（如果使用了方法论）
        if self.lancet_method:
            mechanism_result = self._check_mechanism(event_a, event_b)
            check_results.append(mechanism_result)
        
        return check_results
    
    def _check_temporal(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L1: 时序检查 - 原因必须在结果之前
        
        检查规则：
        1. 事件 A 的时间是否早于事件 B
        2. 时间间隔是否合理（不能太长）
        3. 支持模糊时间处理
        4. 如果无法获取时间，不直接否定，给予中等分数
        """
        time_a = self._get_event_time(event_a)
        time_b = self._get_event_time(event_b)
        
        if time_a is None or time_b is None:
            # 无法获取时间信息，不直接否定，给予中等分数
            return CausalCheckResult(
                check_type=CausalCheckType.TEMPORAL,
                passed=True,  # 改为 True，不直接否定
                score=0.5,  # 中等分数
                evidence=["时间信息缺失，基于其他证据判断"],
                reasoning="无法确定时间顺序，但不排除因果关系",
                confidence=0.3  # 低置信度
            )
        
        # 检查时序
        if time_a >= time_b:
            return CausalCheckResult(
                check_type=CausalCheckType.TEMPORAL,
                passed=False,
                score=0.0,
                evidence=[f"事件 A 时间 ({time_a}) >= 事件 B 时间 ({time_b})"],
                reasoning="原因必须在结果之前发生",
                confidence=1.0
            )
        
        # 检查时间间隔
        time_diff = time_b - time_a
        max_interval = self.causal_config.temporal_threshold if self.causal_config else 1000.0  # 增大阈值到 1000 年
        
        if time_diff > max_interval:
            return CausalCheckResult(
                check_type=CausalCheckType.TEMPORAL,
                passed=False,
                score=0.3,
                evidence=[f"时间间隔 ({time_diff}) 超过阈值 ({max_interval})"],
                reasoning="时间间隔过长，因果关系可能性降低",
                confidence=0.8
            )
        
        # 计算时序得分（时间间隔越短，得分越高）
        temporal_score = math.exp(-time_diff / max_interval)
        
        return CausalCheckResult(
            check_type=CausalCheckType.TEMPORAL,
            passed=True,
            score=temporal_score,
            evidence=[f"时间间隔：{time_diff}", f"时序因子：{temporal_score:.2f}"],
            reasoning=f"事件 A 在事件 B 之前 {time_diff} 单位时间",
            confidence=0.95
        )
    
    def _check_necessity(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L2/L3: 必要性检查 - 没有事件 A，事件 B 是否还会发生
        
        检查方法：
        1. 查找是否有其他原因导致事件 B
        2. 使用领域知识判断必要性
        3. 使用反事实推理
        """
        # 从存储中查找导致 event_b 的其他原因
        all_relations = self.storage.get_all_relations()
        alternative_causes = []
        
        for relation in all_relations:
            if relation.target_id == self._get_event_id(event_b):
                if relation.source_id != self._get_event_id(event_a):
                    alternative_causes.append(relation.source_id)
        
        # 检查是否有替代原因
        if alternative_causes:
            # 有替代原因，必要性降低
            necessity_score = 1.0 / (1.0 + len(alternative_causes))
            return CausalCheckResult(
                check_type=CausalCheckType.NECESSITY,
                passed=True,  # 仍然通过，但分数降低
                score=necessity_score,
                evidence=[f"发现 {len(alternative_causes)} 个替代原因"],
                reasoning=f"存在替代原因：{', '.join(alternative_causes[:3])}",
                confidence=0.8
            )
        
        # 没有替代原因，必要性高
        return CausalCheckResult(
            check_type=CausalCheckType.NECESSITY,
            passed=True,
            score=0.9,
            evidence=["未发现替代原因"],
            reasoning="事件 A 可能是事件 B 的必要条件",
            confidence=0.85
        )
    
    def _check_sufficiency(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L2/L3: 充分性检查 - 有事件 A，事件 B 是否一定发生
        
        检查方法：
        1. 统计历史上 event_a 发生后 event_b 的发生率
        2. 使用领域知识判断充分性
        3. 考虑辅助条件
        """
        # 简化实现：检查共现率
        all_events = self.storage.get_all_events()
        
        event_a_count = 0
        co_occurrence_count = 0
        
        time_a = self._get_event_time(event_a)
        if time_a is None:
            return CausalCheckResult(
                check_type=CausalCheckType.SUFFICIENCY,
                passed=True,
                score=0.5,
                evidence=["无法获取事件 A 时间"],
                reasoning="无法充分评估充分性",
                confidence=0.5
            )
        
        # 统计共现
        for event in all_events:
            time_event = self._get_event_time(event)
            if time_event is not None and abs(time_event - time_a) < 10:  # 时间窗口
                event_a_count += 1
                if self._get_event_id(event) == self._get_event_id(event_b):
                    co_occurrence_count += 1
        
        if event_a_count == 0:
            sufficiency_score = 0.5
        else:
            sufficiency_score = co_occurrence_count / event_a_count
        
        passed = sufficiency_score >= 0.5
        
        return CausalCheckResult(
            check_type=CausalCheckType.SUFFICIENCY,
            passed=passed,
            score=sufficiency_score,
            evidence=[f"共现率：{sufficiency_score:.2f}"],
            reasoning=f"事件 A 发生后，事件 B 的发生率为 {sufficiency_score:.2%}",
            confidence=0.75
        )
    
    def _check_directness(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L2: 直接性检查 - 事件 A 和事件 B 之间是否有中间事件
        
        检查方法：
        1. 查找时间上的中间事件
        2. 查找因果链上的中间事件
        3. 判断是否为直接因果
        """
        all_events = self.storage.get_all_events()
        
        time_a = self._get_event_time(event_a)
        time_b = self._get_event_time(event_b)
        
        if time_a is None or time_b is None:
            return CausalCheckResult(
                check_type=CausalCheckType.DIRECTNESS,
                passed=True,
                score=0.5,
                evidence=["无法获取时间信息"],
                reasoning="无法评估直接性",
                confidence=0.5
            )
        
        # 查找中间事件
        intermediate_events = []
        for event in all_events:
            time_event = self._get_event_time(event)
            if time_event is not None and time_a < time_event < time_b:
                intermediate_events.append(event)
        
        if intermediate_events:
            # 有中间事件，直接性降低
            directness_score = 1.0 / (1.0 + len(intermediate_events))
            return CausalCheckResult(
                check_type=CausalCheckType.DIRECTNESS,
                passed=True,  # 仍然通过，但可能是间接因果
                score=directness_score,
                evidence=[f"发现 {len(intermediate_events)} 个中间事件"],
                reasoning=f"存在中间事件，可能是间接因果关系",
                confidence=0.8
            )
        
        # 没有中间事件，直接性高
        return CausalCheckResult(
            check_type=CausalCheckType.DIRECTNESS,
            passed=True,
            score=0.9,
            evidence=["未发现中间事件"],
            reasoning="事件 A 和事件 B 之间可能是直接因果关系",
            confidence=0.85
        )
    
    def _check_confounding(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L3: 混杂因素检查 - 是否有共同原因导致事件 A 和事件 B
        
        检查方法：
        1. 查找导致 event_a 的原因
        2. 查找导致 event_b 的原因
        3. 检查是否有重叠（共同原因）
        """
        all_relations = self.storage.get_all_relations()
        
        causes_of_a = set()
        causes_of_b = set()
        
        for relation in all_relations:
            if relation.target_id == self._get_event_id(event_a):
                causes_of_a.add(relation.source_id)
            if relation.target_id == self._get_event_id(event_b):
                causes_of_b.add(relation.source_id)
        
        # 查找共同原因
        common_causes = causes_of_a.intersection(causes_of_b)
        
        if common_causes:
            # 有共同原因，可能是虚假相关
            confounding_score = 0.5 / (1.0 + len(common_causes))
            return CausalCheckResult(
                check_type=CausalCheckType.CONFOUNDING,
                passed=True,  # 仍然通过，但置信度降低
                score=confounding_score,
                evidence=[f"发现 {len(common_causes)} 个共同原因"],
                reasoning=f"可能存在混杂因素：{', '.join(list(common_causes)[:3])}",
                confidence=0.7
            )
        
        # 没有共同原因，因果关系更可信
        return CausalCheckResult(
            check_type=CausalCheckType.CONFOUNDING,
            passed=True,
            score=0.9,
            evidence=["未发现共同原因"],
            reasoning="未发现混杂因素，因果关系更可信",
            confidence=0.8
        )
    
    def _check_evidence_strength(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L1/L2: 证据强度检查 - 支持因果关系的证据是否充分
        
        检查维度：
        1. 证据来源数量
        2. 证据来源质量
        3. 证据一致性
        """
        # 获取证据来源
        evidence_sources = []
        
        if hasattr(event_a, 'evidence_sources'):
            evidence_sources.extend(event_a.evidence_sources)
        elif isinstance(event_a, dict) and 'evidence_sources' in event_a:
            evidence_sources.extend(event_a['evidence_sources'])
        
        if hasattr(event_b, 'evidence_sources'):
            evidence_sources.extend(event_b.evidence_sources)
        elif isinstance(event_b, dict) and 'evidence_sources' in event_b:
            evidence_sources.extend(event_b['evidence_sources'])
        
        evidence_count = len(set(evidence_sources))
        
        # 计算证据得分
        if evidence_count == 0:
            evidence_score = 0.3
            evidence_list = ["无直接证据"]
        elif evidence_count <= 2:
            evidence_score = 0.6
            evidence_list = evidence_sources[:3]
        else:
            evidence_score = min(0.9, 0.6 + (evidence_count - 2) * 0.1)
            evidence_list = evidence_sources[:5]
        
        return CausalCheckResult(
            check_type=CausalCheckType.EVIDENCE,
            passed=evidence_score >= 0.5,
            score=evidence_score,
            evidence=evidence_list,
            reasoning=f"证据来源数量：{evidence_count}",
            confidence=0.85
        )
    
    def _check_mechanism(self, event_a: Any, event_b: Any) -> CausalCheckResult:
        """
        L3/L4: 机制解释检查 - 是否有合理的机制解释
        
        检查方法（使用 Lancet Method）：
        1. 任务分解：将机制解释分解为子任务
        2. 分层调用：选择合适的方法（L3 符号推理或 L4 大模型）
        3. 质量评估：评估机制解释的质量
        """
        if not self.lancet_method:
            return CausalCheckResult(
                check_type=CausalCheckType.MECHANISM,
                passed=True,
                score=0.5,
                evidence=["未使用方法论组件"],
                reasoning="无法进行机制检查",
                confidence=0.5
            )
        
        # 构建机制检查任务
        mechanism_task = {
            'type': 'mechanism_explanation',
            'description': f"解释 {self._get_event_name(event_a)} 如何导致 {self._get_event_name(event_b)}",
            'cause': event_a,
            'effect': event_b
        }
        
        # 任务分解
        subtasks = self.lancet_method.decompose_task(mechanism_task)
        
        # 简化实现：假设机制解释质量高
        # 实际应该执行子任务并评估结果
        return CausalCheckResult(
            check_type=CausalCheckType.MECHANISM,
            passed=True,
            score=0.8,
            evidence=["机制解释合理"],
            reasoning="通过方法论组件验证，机制解释合理",
            confidence=0.75
        )
    
    def _synthesize_checks(self, check_results: List[CausalCheckResult],
                          event_a: Any, event_b: Any) -> Tuple[bool, Optional[CausalRelationType], float]:
        """
        综合所有检查结果，做出因果判断
        
        Args:
            check_results: 检查结果列表
            event_a: 事件 A
            event_b: 事件 B
        
        Returns:
            (has_causality, relation_type, confidence): 因果判断结果
        """
        if not check_results:
            return False, None, 0.0
        
        # 关键检查失败（时序检查），直接判定无因果
        temporal_check = next((r for r in check_results if r.check_type == CausalCheckType.TEMPORAL), None)
        if temporal_check and not temporal_check.passed:
            return False, None, 0.0
        
        # 计算加权得分
        weights = {
            CausalCheckType.TEMPORAL: 0.25,
            CausalCheckType.NECESSITY: 0.15,
            CausalCheckType.SUFFICIENCY: 0.15,
            CausalCheckType.DIRECTNESS: 0.15,
            CausalCheckType.CONFOUNDING: 0.10,
            CausalCheckType.EVIDENCE: 0.10,
            CausalCheckType.MECHANISM: 0.10
        }
        
        weighted_score = 0.0
        total_weight = 0.0
        
        for result in check_results:
            weight = weights.get(result.check_type, 0.1)
            weighted_score += result.score * weight
            total_weight += weight
        
        if total_weight == 0:
            return False, None, 0.0
        
        overall_confidence = weighted_score / total_weight
        
        # 判断是否有因果
        confidence_threshold = self.causal_config.confidence_threshold if self.causal_config else 0.6
        has_causality = overall_confidence >= confidence_threshold
        
        # 判断因果关系类型
        relation_type = self._determine_relation_type(check_results, has_causality)
        
        return has_causality, relation_type, overall_confidence
    
    def _determine_relation_type(self, check_results: List[CausalCheckResult],
                                has_causality: bool) -> Optional[CausalRelationType]:
        """判断因果关系类型"""
        if not has_causality:
            return None
        
        # 根据检查结果判断关系类型
        directness = next((r for r in check_results if r.check_type == CausalCheckType.DIRECTNESS), None)
        necessity = next((r for r in check_results if r.check_type == CausalCheckType.NECESSITY), None)
        sufficiency = next((r for r in check_results if r.check_type == CausalCheckType.SUFFICIENCY), None)
        
        if directness and directness.score > 0.8:
            return CausalRelationType.DIRECT_CAUSE
        elif directness and directness.score > 0.5:
            return CausalRelationType.INDIRECT_CAUSE
        elif necessity and necessity.score > 0.8:
            return CausalRelationType.NECESSARY_CONDITION
        elif sufficiency and sufficiency.score > 0.8:
            return CausalRelationType.SUFFICIENT_CONDITION
        else:
            return CausalRelationType.CONTRIBUTING_FACTOR
    
    def _generate_reasoning_chain(self, check_results: List[CausalCheckResult],
                                 has_causality: bool) -> List[str]:
        """生成推理链"""
        reasoning = []
        
        for result in check_results:
            if result.passed:
                reasoning.append(f"✓ {result.check_type.value}: {result.reasoning}")
            else:
                reasoning.append(f"✗ {result.check_type.value}: {result.reasoning}")
        
        if has_causality:
            reasoning.append("→ 综合判断：存在因果关系")
        else:
            reasoning.append("→ 综合判断：不存在因果关系")
        
        return reasoning
    
    def _collect_evidence_sources(self, event_a: Any, event_b: Any) -> List[str]:
        """收集证据来源"""
        sources = []
        
        if hasattr(event_a, 'evidence_sources'):
            sources.extend(event_a.evidence_sources)
        elif isinstance(event_a, dict):
            sources.extend(event_a.get('evidence_sources', []))
        
        if hasattr(event_b, 'evidence_sources'):
            sources.extend(event_b.evidence_sources)
        elif isinstance(event_b, dict):
            sources.extend(event_b.get('evidence_sources', []))
        
        return list(set(sources))
    
    def _generate_alternatives(self, check_results: List[CausalCheckResult]) -> List[str]:
        """生成替代解释"""
        alternatives = []
        
        # 检查是否有替代原因
        necessity = next((r for r in check_results if r.check_type == CausalCheckType.NECESSITY), None)
        if necessity and necessity.score < 0.7:
            alternatives.append("可能存在其他原因导致结果")
        
        # 检查是否有混杂因素
        confounding = next((r for r in check_results if r.check_type == CausalCheckType.CONFOUNDING), None)
        if confounding and confounding.score < 0.7:
            alternatives.append("可能存在共同原因（混杂因素）")
        
        # 检查证据是否充分
        evidence = next((r for r in check_results if r.check_type == CausalCheckType.EVIDENCE), None)
        if evidence and evidence.score < 0.6:
            alternatives.append("证据不足，需要更多支持")
        
        return alternatives
    
    def _generate_suggestions(self, check_results: List[CausalCheckResult],
                            has_causality: bool) -> List[str]:
        """生成改进建议"""
        suggestions = []
        
        # 找出得分低的检查
        weak_checks = [r for r in check_results if r.score < 0.6]
        
        for check in weak_checks:
            if check.check_type == CausalCheckType.EVIDENCE:
                suggestions.append("建议收集更多证据来源")
            elif check.check_type == CausalCheckType.NECESSITY:
                suggestions.append("建议排除替代原因")
            elif check.check_type == CausalCheckType.CONFOUNDING:
                suggestions.append("建议控制混杂因素")
            elif check.check_type == CausalCheckType.MECHANISM:
                suggestions.append("建议提供更详细的机制解释")
        
        if not has_causality:
            suggestions.append("当前证据不足以支持因果关系")
        elif has_causality and not suggestions:
            suggestions.append("因果关系判断可靠")
        
        return suggestions
    
    def _get_event_id(self, event: Any) -> str:
        """获取事件 ID"""
        if hasattr(event, 'id'):
            return event.id
        elif isinstance(event, dict) and 'id' in event:
            return event['id']
        elif isinstance(event, dict) and 'name' in event:
            return event['name']
        else:
            return str(event)
    
    def _get_event_name(self, event: Any) -> str:
        """获取事件名称"""
        if hasattr(event, 'name'):
            return event.name
        elif isinstance(event, dict) and 'name' in event:
            return event['name']
        else:
            return str(event)
    
    def _get_event_time(self, event: Any) -> Optional[float]:
        """获取事件时间戳"""
        if hasattr(event, 'timestamp'):
            ts = event.timestamp
            if isinstance(ts, dict):
                # 空 dict 表示没有时间信息
                if not ts:
                    return None
                # 处理模糊时间（如 {'year': 1911, 'month': 10}）
                # 公元前年份用负数表示，如 -2679 表示公元前 2679 年
                year = ts.get('year')
                if year is None:
                    return None
                month = ts.get('month', 1) / 12
                return float(year) + month
            return float(ts)
        elif isinstance(event, dict):
            if 'timestamp' in event:
                ts = event['timestamp']
                if isinstance(ts, dict):
                    if not ts:
                        return None
                    year = ts.get('year')
                    if year is None:
                        return None
                    month = ts.get('month', 1) / 12
                    return float(year) + month
                return float(ts)
            if 'time' in event:
                return float(event['time'])
        return None
    
    def get_causal_network(self, events: Optional[List[Any]] = None) -> Dict[Any, List[Any]]:
        """
        构建事件网络中的因果关系图
        
        Args:
            events: 事件列表（可选，如果为 None 则从存储中获取所有事件）
        
        Returns:
            Dict[Any, List[Any]]: 因果关系图，键为事件索引，值为导致该事件的事件索引列表
        """
        if events is None:
            events = self.storage.get_all_events()
        
        causal_network: Dict[int, List[int]] = {}
        
        for i in range(len(events)):
            causal_network[i] = []
        
        for i, event_a in enumerate(events):
            for j, event_b in enumerate(events):
                if i != j and self.infer_causality(event_a, event_b):
                    causal_network[j].append(i)
        
        return causal_network
    
    def explain_causality(self, event_a: Any, event_b: Any) -> Dict[str, Any]:
        """
        解释因果关系推断的理由
        
        Args:
            event_a: 可能的原因事件
            event_b: 可能的结果事件
        
        Returns:
            Dict[str, Any]: 解释信息
        """
        result = self._infer_causality_detailed(event_a, event_b)
        
        return {
            'has_causality': result.has_causality,
            'relation_type': result.relation_type.value if result.relation_type else None,
            'confidence': result.overall_confidence,
            'checks': [
                {
                    'type': r.check_type.value,
                    'passed': r.passed,
                    'score': r.score,
                    'reasoning': r.reasoning
                }
                for r in result.check_results
            ],
            'reasoning_chain': result.reasoning_chain,
            'evidence_sources': result.evidence_sources,
            'alternative_explanations': result.alternative_explanations,
            'suggestions': result.suggestions
        }
    
    def clear_cache(self) -> None:
        """清除缓存"""
        self._causal_cache.clear()
        logger.info("Causal cache cleared")
    
    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        stats = {
            'inference_count': self._inference_count,
            'cache_hits': self._cache_hits,
            'cache_hit_rate': self._cache_hits / max(1, self._inference_count),
            'cache_size': len(self._causal_cache),
            'kg_reasoner_loaded': self.kg_reasoner is not None and self.kg_reasoner._loaded,
        }
        if self.kg_reasoner and self.kg_reasoner._loaded:
            stats['kg_nodes'] = len(self.kg_reasoner._names)
            stats['kg_edges'] = sum(len(v) for v in self.kg_reasoner._fwd.values())
        return stats

    def enable_kg_reasoner(self) -> Dict[str, Any]:
        """
        Enable knowledge graph chain reasoning.

        Requires PostgreSQLStorage. Loads entity_relations graph into memory.
        """
        from ..storage.postgresql_storage import PostgreSQLStorage
        if not isinstance(self.storage, PostgreSQLStorage):
            return {"error": "KG reasoner requires PostgreSQLStorage"}

        self.kg_reasoner = KnowledgeGraphReasoner(self.storage)
        n_nodes, n_edges = self.kg_reasoner.load_graph()
        return {"nodes": n_nodes, "edges": n_edges, "status": "loaded"}

    def trace_chain(self, entity_name: str, direction: str = "forward",
                    max_depth: int = 6) -> List[Dict[str, Any]]:
        """
        Trace causal chains from/to an entity via knowledge graph.

        Args:
            entity_name: concept name (e.g. "格物")
            direction: "forward" (effects) or "backward" (causes)
            max_depth: max chain length

        Returns:
            List of chain dicts with start, end, confidence, links
        """
        if not self.kg_reasoner:
            return []
        if direction == "backward":
            chains = self.kg_reasoner.trace_backward(entity_name, max_depth)
        else:
            chains = self.kg_reasoner.trace_forward(entity_name, max_depth)
        return [c.to_dict() for c in chains]

    def find_chain_between(self, source_name: str, target_name: str,
                           max_depth: int = 6) -> List[Dict[str, Any]]:
        """Find causal chains connecting two concepts."""
        if not self.kg_reasoner:
            return []
        chains = self.kg_reasoner.trace_between(source_name, target_name, max_depth)
        return [c.to_dict() for c in chains]

    def discover_relations(self, min_confidence: float = 0.50,
                           max_length: int = 3) -> List[Dict[str, Any]]:
        """
        Discover implicit transitive relations via chain reasoning.

        Returns discovered (A->C) where A->B and B->C exist but A->C doesn't.
        """
        if not self.kg_reasoner:
            return []
        inferred = self.kg_reasoner.discover_transitive(min_confidence, max_length)
        return [
            {
                "source": r.source_name,
                "target": r.target_name,
                "relation_type": r.relation_type,
                "confidence": round(r.confidence, 3),
                "chain_length": r.chain_length,
                "evidence_chain": r.evidence_chain,
                "cross_text": r.cross_text,
            }
            for r in inferred
        ]

    def persist_discoveries(self, min_confidence: float = 0.50,
                            max_length: int = 3) -> Dict[str, Any]:
        """Discover and persist transitive relations to entity_relations table."""
        if not self.kg_reasoner:
            return {"error": "KG reasoner not loaded"}
        return self.kg_reasoner.persist_discoveries(min_confidence, max_length)

    def inject_action(self, action: Action,
                      trace_depth: int = 4) -> ActionResult:
        """
        Inject an action into the engine, persist it, and predict consequences.

        This is the primary interface for event-driven applications. It:
        1. Ensures all entity names in the action exist in the KG
        2. Persists the declared relations to the database
        3. Updates the in-memory KG graph (no full reload)
        4. Traces forward from each target entity to predict consequences
        5. Returns immediate effects + downstream chain predictions

        Args:
            action: Action object with name, relations, optional actor/metadata
            trace_depth: how deep to trace consequence chains (default 4)

        Returns:
            ActionResult with entities affected, relations added, consequence chains
        """
        from ..storage.postgresql_storage import PostgreSQLStorage

        if not self.kg_reasoner or not self.kg_reasoner._loaded:
            if isinstance(self.storage, PostgreSQLStorage):
                logger.warning("KG reasoner not loaded, attempting to load")
                self._init_kg_reasoner()
            if not self.kg_reasoner:
                logger.warning("KG reasoner unavailable, consequence tracing disabled")

        result = ActionResult(action_name=action.name)
        entities_affected = set()
        relations_added = 0

        for rel in action.relations:
            entities_affected.add(rel.source)
            entities_affected.add(rel.target)

            src_id = self._ensure_entity(rel.source)
            tgt_id = self._ensure_entity(rel.target)
            if not src_id or not tgt_id:
                logger.warning(f"Failed to ensure entity for relation {rel.source} -> {rel.target}")
                continue

            existing = self.storage.find_entity_relation(
                rel.source, rel.target, rel.relation_type
            )
            if existing:
                self._update_kg_memory(src_id, rel.source, tgt_id, rel.target,
                                       rel.relation_type, rel.confidence)
                result.immediate_effects.append({
                    "source": rel.source,
                    "target": rel.target,
                    "relation_type": rel.relation_type,
                    "confidence": round(rel.confidence, 3),
                    "status": "existing",
                })
                continue

            added = self.storage.add_entity_relation(
                rel.source, rel.target,
                rel.relation_type, rel.confidence,
                metadata={
                    "action_name": action.name,
                    "conditions": rel.conditions,
                },
            )
            if added:
                relations_added += 1

            self._update_kg_memory(src_id, rel.source, tgt_id, rel.target,
                                   rel.relation_type, rel.confidence)

            result.immediate_effects.append({
                "source": rel.source,
                "target": rel.target,
                "relation_type": rel.relation_type,
                "confidence": round(rel.confidence, 3),
                "status": "new",
            })

        result.entities_affected = sorted(entities_affected)
        result.relations_added = relations_added

        if self.kg_reasoner and self.kg_reasoner._loaded:
            for rel in action.relations:
                chains = self.kg_reasoner.trace_forward(rel.target, trace_depth)
                for chain in chains:
                    steps = []
                    for link in chain.links:
                        is_new_link = (
                            (link.source_name == rel.source and link.target_name == rel.target)
                            or any(
                                s.source == link.source_name and s.target == link.target_name
                                for s in steps
                            )
                        )
                        steps.append(ChainStep(
                            source=link.source_name,
                            target=link.target_name,
                            relation_type=link.relation_type,
                            confidence=link.confidence,
                            is_new=is_new_link,
                        ))

                    consequence = ConsequenceChain(
                        trigger=f"{rel.source} → {rel.target}",
                        steps=steps,
                        total_confidence=chain.total_confidence,
                        length=chain.length,
                    )
                    result.consequence_chains.append(consequence)

                    if chain.length > 1:
                        result.downstream_effects.append({
                            "trigger": f"{rel.source} → {rel.target}",
                            "end": chain.end_name,
                            "length": chain.length,
                            "confidence": round(chain.total_confidence, 3),
                            "path": " → ".join(
                                f"{l.source_name}→{l.target_name}" for l in chain.links
                            ),
                        })

        logger.info(
            f"Action '{action.name}' injected: {relations_added} relations, "
            f"{len(result.consequence_chains)} chains predicted"
        )
        return result

    def _ensure_entity(self, name: str) -> Optional[str]:
        """
        Ensure an entity exists in unified_entities. Create if missing.

        Returns the entity ID.
        """
        return self.storage.ensure_entity(
            name,
            entity_type="action_entity",
            description=f"Entity created by action injection: {name}",
        )

    def _update_kg_memory(self, src_id: str, src_name: str,
                          tgt_id: str, tgt_name: str,
                          relation_type: str, confidence: float) -> None:
        """
        Update the in-memory KG graph without a full reload.

        Adds the new entity names and relation edge to the KG reasoner's
        adjacency lists (_fwd, _bwd, _names).
        """
        if not self.kg_reasoner:
            return

        if src_id not in self.kg_reasoner._names:
            self.kg_reasoner._names[src_id] = src_name
        if tgt_id not in self.kg_reasoner._names:
            self.kg_reasoner._names[tgt_id] = tgt_name

        edge = {"target": tgt_id, "type": relation_type, "confidence": confidence}
        if edge not in self.kg_reasoner._fwd[src_id]:
            self.kg_reasoner._fwd[src_id].append(edge)

        back_edge = {"target": src_id, "type": relation_type, "confidence": confidence}
        if back_edge not in self.kg_reasoner._bwd[tgt_id]:
            self.kg_reasoner._bwd[tgt_id].append(back_edge)

        logger.debug(f"KG memory updated: {src_name} --{relation_type}--> {tgt_name}")

    def get_rule_discovery(self, llm_provider=None) -> RuleDiscovery:
        """
        Get or create the RuleDiscovery module.

        Args:
            llm_provider: Optional LLMProvider for rule generation.
                         Can be set later via set_llm_for_discovery().

        Returns:
            RuleDiscovery instance bound to this engine.
        """
        if self._rule_discovery is None:
            self._rule_discovery = RuleDiscovery(self, llm_provider)
        elif llm_provider is not None:
            self._rule_discovery.llm = llm_provider
        return self._rule_discovery

    async def discover_rules(self, request: DiscoverRequest) -> DiscoverResult:
        """
        Discover new causal rules from context.

        Convenience method that delegates to RuleDiscovery.discover_rules().
        Requires an LLM provider to be set (via get_rule_discovery or constructor).
        """
        discovery = self.get_rule_discovery()
        return await discovery.discover_rules(request)

    def validate_rule(self, rule: CandidateRule) -> ValidationResult:
        """
        Validate a candidate rule against existing KG.

        Checks for duplicates and conflicts.
        """
        discovery = self.get_rule_discovery()
        return discovery.validate_rule(rule)

    def adjust_confidence(
        self, source: str, target: str, relation_type: str, delta: float
    ) -> bool:
        """
        Adjust confidence of an existing rule.

        Args:
            source: source entity name
            target: target entity name
            relation_type: causes/enables/prevents/correlates
            delta: confidence adjustment (+/-)
        """
        discovery = self.get_rule_discovery()
        return discovery.adjust_confidence(source, target, relation_type, delta)

    def process_feedback(self, feedback: FeedbackRequest) -> Dict[str, Any]:
        """
        Process runtime feedback from application layer.

        Increases confidence if prediction matched, decreases if not.
        """
        discovery = self.get_rule_discovery()
        return discovery.process_feedback(feedback)

    # ============ Meta-Pattern Methods ============

    def get_meta_pattern_store(self) -> MetaPatternStore:
        """Get the meta-pattern store."""
        return self._meta_store

    def list_meta_patterns(
        self, min_generality: str = ""
    ) -> List[Dict[str, Any]]:
        """List all meta-patterns, optionally filtered by generality."""
        patterns = self._meta_store.list_patterns(min_generality=min_generality)
        return [p.to_dict() for p in patterns]

    def add_meta_pattern(self, pattern: MetaPattern) -> bool:
        """Add a new meta-pattern to the store."""
        return self._meta_store.add_pattern(pattern)

    def match_meta_patterns(
        self, context: str, top_k: int = 3, min_score: float = 0.1
    ) -> List[Dict[str, Any]]:
        """
        Match meta-patterns against a context (keyword-based, no LLM needed).

        Use as fallback when event-level rules don't match.
        """
        if not self._meta_matcher:
            return []
        return self._meta_matcher.match_by_keywords(
            context, top_k=top_k, min_score=min_score
        )

    async def match_meta_patterns_semantic(
        self, context: str, top_k: int = 3
    ) -> List[Dict[str, Any]]:
        """
        Match meta-patterns via LLM semantic understanding (slower, more accurate).

        Requires an LLM provider to be set.
        """
        if not self._meta_matcher:
            return []
        return await self._meta_matcher.match_by_llm(context, top_k=top_k)
