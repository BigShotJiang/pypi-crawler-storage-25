"""
知识图谱接口 - 基于图结构的因果网络查询和推理

重要说明：
1. 这是通用架构的核心组件，提供图级别的因果推理能力
2. 基于 GitNexus 的原理（代码知识图谱），但通用化用于任何领域
3. 支持因果链查询、关系推理、模式识别
4. 生产级实现：完整的错误处理、类型注解、日志记录

核心功能：
1. 因果链查询（找出 A 到 B 的所有因果路径）
2. 关系推理（发现隐含的因果关系）
3. 模式识别（识别常见的因果模式）
4. 图遍历（多跳查询）
5. 子图提取（提取相关因果网络）

使用示例：
    from generic_causal_architecture.graph import CausalGraph
    
    graph = CausalGraph(storage)
    graph.initialize()
    
    # 查询因果链
    chains = graph.find_causal_chains("event_a", "event_b")
    
    # 查找共同原因
    common_causes = graph.find_common_causes("event_a", "event_b")
    
    # 识别因果模式
    patterns = graph.identify_causal_patterns("event_a")
"""

from typing import Any, Dict, List, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import logging

from ..storage.storage_interface import StorageInterface, EventData, CausalRelation

logger = logging.getLogger(__name__)


class CausalPattern(Enum):
    """因果模式类型"""
    DIRECT = "direct"  # 直接因果 A→B
    CHAIN = "chain"  # 因果链 A→B→C
    COMMON_CAUSE = "common_cause"  # 共同原因 C→A, C→B
    COMMON_EFFECT = "common_effect"  # 共同结果 A→C, B→C
    CONFOUNDER = "confounder"  # 混杂因素
    MEDIATOR = "mediator"  # 中介变量 A→M→B
    COLLIDER = "collider"  # 对撞结构 A→C←B
    FEEDBACK = "feedback"  # 反馈循环 A→B→A


class QueryType(Enum):
    """查询类型"""
    NEIGHBORS = "neighbors"  # 邻居节点
    ANCESTORS = "ancestors"  # 祖先节点（所有原因）
    DESCENDANTS = "descendants"  # 后代节点（所有结果）
    PATHS = "paths"  # 路径查询
    PATTERNS = "patterns"  # 模式识别


@dataclass
class CausalPath:
    """
    因果路径
    
    属性:
        source_id: 起始事件 ID
        target_id: 目标事件 ID
        relations: 路径中的关系列表
        length: 路径长度
        total_confidence: 总置信度（路径上所有关系的置信度乘积）
        description: 路径描述
    """
    source_id: str
    target_id: str
    relations: List[CausalRelation]
    length: int
    total_confidence: float
    description: str


@dataclass
class CausalPatternMatch:
    """
    因果模式匹配结果
    
    属性:
        pattern_type: 模式类型
        events: 涉及的事件 ID 列表
        relations: 涉及的关系列表
        confidence: 模式置信度
        description: 模式描述
    """
    pattern_type: CausalPattern
    events: List[str]
    relations: List[CausalRelation]
    confidence: float
    description: str


@dataclass
class GraphStatistics:
    """
    图统计信息
    
    属性:
        total_events: 事件总数
        total_relations: 关系总数
        avg_degree: 平均度数
        max_in_degree: 最大入度
        max_out_degree: 最大出度
        connected_components: 连通分量数
        density: 图密度
    """
    total_events: int
    total_relations: int
    avg_degree: float
    max_in_degree: int
    max_out_degree: int
    connected_components: int
    density: float


class CausalGraph:
    """
    因果图谱 - 基于图结构的因果网络查询和推理
    
    核心职责：
    1. 提供图级别的因果查询能力
    2. 发现隐含的因果关系
    3. 识别常见的因果模式
    4. 支持复杂的多跳查询
    
    设计原则：
    - 领域无关（可以被任何领域使用）
    - 基于存储接口（不依赖具体存储实现）
    - 生产级质量（完整的错误处理、日志、类型注解）
    """
    
    def __init__(self, storage: StorageInterface):
        """
        初始化因果图谱
        
        Args:
            storage: 存储接口
        """
        self.storage = storage
        self._initialized = False
        
        logger.info("CausalGraph initialized")
    
    def initialize(self) -> None:
        """
        初始化图结构
        
        确保存储已初始化，并验证图查询能力
        """
        if not self._initialized:
            try:
                # 确保存储已初始化
                if hasattr(self.storage, 'initialize'):
                    self.storage.initialize()
                
                self._initialized = True
                logger.info("CausalGraph initialized successfully")
            
            except Exception as e:
                logger.error(f"Error initializing CausalGraph: {e}")
                raise
    
    # =========================================================================
    # 核心功能 1: 因果链查询
    # =========================================================================
    
    def find_causal_chains(self, source_id: str, target_id: str, 
                          max_length: int = 5) -> List[CausalPath]:
        """
        查找两个事件之间的所有因果链
        
        Args:
            source_id: 起始事件 ID
            target_id: 目标事件 ID
            max_length: 最大路径长度
        
        Returns:
            List[CausalPath]: 因果链列表，按置信度排序
        """
        if not self._initialized:
            self.initialize()
        
        try:
            # 使用 BFS 查找所有路径
            paths = self._find_all_paths(source_id, target_id, max_length)
            
            # 转换为 CausalPath 对象
            causal_paths = []
            for path_relations in paths:
                if path_relations:
                    total_confidence = 1.0
                    for rel in path_relations:
                        total_confidence *= rel.confidence
                    
                    description = self._build_path_description(path_relations)
                    
                    causal_paths.append(CausalPath(
                        source_id=source_id,
                        target_id=target_id,
                        relations=path_relations,
                        length=len(path_relations),
                        total_confidence=total_confidence,
                        description=description
                    ))
            
            # 按置信度排序
            causal_paths.sort(key=lambda p: p.total_confidence, reverse=True)
            
            logger.info(f"Found {len(causal_paths)} causal chains from {source_id} to {target_id}")
            return causal_paths
        
        except Exception as e:
            logger.error(f"Error finding causal chains: {e}")
            return []
    
    def _find_all_paths(self, source_id: str, target_id: str, 
                       max_length: int, visited: Optional[Set[str]] = None) -> List[List[CausalRelation]]:
        """
        使用 BFS 查找所有路径（内部方法）
        """
        if visited is None:
            visited = set()
        
        if source_id == target_id:
            return [[]]
        
        if source_id in visited:
            return []
        
        visited.add(source_id)
        
        paths = []
        
        # 获取所有从 source_id 出发的关系
        outgoing_relations = self.storage.get_relations_by_source(source_id)
        
        for relation in outgoing_relations:
            if len(paths) >= max_length:
                break
            
            next_id = relation.target_id
            if next_id not in visited:
                sub_paths = self._find_all_paths(next_id, target_id, max_length, visited.copy())
                for sub_path in sub_paths:
                    paths.append([relation] + sub_path)
        
        return paths
    
    def _build_path_description(self, relations: List[CausalRelation]) -> str:
        """构建路径描述"""
        if not relations:
            return "空路径"
        
        event_chain = [relations[0].source_id]
        for rel in relations:
            event_chain.append(rel.target_id)
        
        return " → ".join(event_chain)
    
    # =========================================================================
    # 核心功能 2: 关系推理
    # =========================================================================
    
    def find_common_causes(self, event_id_1: str, event_id_2: str) -> List[str]:
        """
        查找两个事件的共同原因
        
        Args:
            event_id_1: 事件 1 ID
            event_id_2: 事件 2 ID
        
        Returns:
            List[str]: 共同原因 ID 列表
        """
        if not self._initialized:
            self.initialize()
        
        try:
            # 获取事件 1 的所有祖先（原因）
            ancestors_1 = self._get_ancestors(event_id_1)
            
            # 获取事件 2 的所有祖先（原因）
            ancestors_2 = self._get_ancestors(event_id_2)
            
            # 找交集
            common = list(ancestors_1 & ancestors_2)
            
            logger.info(f"Found {len(common)} common causes for {event_id_1} and {event_id_2}")
            return common
        
        except Exception as e:
            logger.error(f"Error finding common causes: {e}")
            return []
    
    def find_common_effects(self, event_id_1: str, event_id_2: str) -> List[str]:
        """
        查找两个事件的共同结果
        
        Args:
            event_id_1: 事件 1 ID
            event_id_2: 事件 2 ID
        
        Returns:
            List[str]: 共同结果 ID 列表
        """
        if not self._initialized:
            self.initialize()
        
        try:
            # 获取事件 1 的所有后代（结果）
            descendants_1 = self._get_descendants(event_id_1)
            
            # 获取事件 2 的所有后代（结果）
            descendants_2 = self._get_descendants(event_id_2)
            
            # 找交集
            common = list(descendants_1 & descendants_2)
            
            logger.info(f"Found {len(common)} common effects for {event_id_1} and {event_id_2}")
            return common
        
        except Exception as e:
            logger.error(f"Error finding common effects: {e}")
            return []
    
    def _get_ancestors(self, event_id: str, visited: Optional[Set[str]] = None) -> Set[str]:
        """获取所有祖先节点（原因）"""
        if visited is None:
            visited = set()
        
        ancestors = set()
        
        # 获取所有指向 event_id 的关系
        incoming_relations = self.storage.get_relations_by_target(event_id)
        
        for relation in incoming_relations:
            source_id = relation.source_id
            if source_id not in visited:
                visited.add(source_id)
                ancestors.add(source_id)
                # 递归获取祖先的祖先
                ancestors.update(self._get_ancestors(source_id, visited))
        
        return ancestors
    
    def _get_descendants(self, event_id: str, visited: Optional[Set[str]] = None) -> Set[str]:
        """获取所有后代节点（结果）"""
        if visited is None:
            visited = set()
        
        descendants = set()
        
        # 获取所有从 event_id 出发的关系
        outgoing_relations = self.storage.get_relations_by_source(event_id)
        
        for relation in outgoing_relations:
            target_id = relation.target_id
            if target_id not in visited:
                visited.add(target_id)
                descendants.add(target_id)
                # 递归获取后代的后代
                descendants.update(self._get_descendants(target_id, visited))
        
        return descendants
    
    def find_indirect_causal_relations(self, source_id: str, target_id: str, 
                                       max_intermediate: int = 2) -> List[CausalPath]:
        """
        查找间接因果关系（通过中间事件）
        
        Args:
            source_id: 原因事件 ID
            target_id: 结果事件 ID
            max_intermediate: 最大中间事件数量
        
        Returns:
            List[CausalPath]: 间接因果路径列表
        """
        # 间接因果就是长度 > 1 的因果链
        return self.find_causal_chains(source_id, target_id, max_intermediate + 1)
    
    # =========================================================================
    # 核心功能 3: 模式识别
    # =========================================================================
    
    def identify_causal_patterns(self, event_id: str) -> List[CausalPatternMatch]:
        """
        识别与事件相关的因果模式
        
        Args:
            event_id: 事件 ID
        
        Returns:
            List[CausalPatternMatch]: 识别到的模式列表
        """
        if not self._initialized:
            self.initialize()
        
        patterns = []
        
        try:
            # 1. 检查直接因果
            direct_patterns = self._identify_direct_patterns(event_id)
            patterns.extend(direct_patterns)
            
            # 2. 检查链式因果
            chain_patterns = self._identify_chain_patterns(event_id)
            patterns.extend(chain_patterns)
            
            # 3. 检查共同原因
            common_cause_patterns = self._identify_common_cause_patterns(event_id)
            patterns.extend(common_cause_patterns)
            
            # 4. 检查混杂因素
            confounder_patterns = self._identify_confounder_patterns(event_id)
            patterns.extend(confounder_patterns)
            
            # 5. 检查中介变量
            mediator_patterns = self._identify_mediator_patterns(event_id)
            patterns.extend(mediator_patterns)
            
            # 按置信度排序
            patterns.sort(key=lambda p: p.confidence, reverse=True)
            
            logger.info(f"Identified {len(patterns)} causal patterns for {event_id}")
            return patterns
        
        except Exception as e:
            logger.error(f"Error identifying causal patterns: {e}")
            return []
    
    def _identify_direct_patterns(self, event_id: str) -> List[CausalPatternMatch]:
        """识别直接因果模式"""
        patterns = []
        
        # 获取所有出边
        outgoing = self.storage.get_relations_by_source(event_id)
        for rel in outgoing:
            patterns.append(CausalPatternMatch(
                pattern_type=CausalPattern.DIRECT,
                events=[event_id, rel.target_id],
                relations=[rel],
                confidence=rel.confidence,
                description=f"直接因果：{event_id} → {rel.target_id}"
            ))
        
        return patterns
    
    def _identify_chain_patterns(self, event_id: str) -> List[CausalPatternMatch]:
        """识别链式因果模式"""
        patterns = []
        
        # 获取所有出边
        outgoing = self.storage.get_relations_by_source(event_id)
        
        for rel1 in outgoing:
            # 获取中间事件的出边
            intermediate_outgoing = self.storage.get_relations_by_source(rel1.target_id)
            
            for rel2 in intermediate_outgoing:
                patterns.append(CausalPatternMatch(
                    pattern_type=CausalPattern.CHAIN,
                    events=[event_id, rel1.target_id, rel2.target_id],
                    relations=[rel1, rel2],
                    confidence=rel1.confidence * rel2.confidence,
                    description=f"因果链：{event_id} → {rel1.target_id} → {rel2.target_id}"
                ))
        
        return patterns
    
    def _identify_common_cause_patterns(self, event_id: str) -> List[CausalPatternMatch]:
        """识别共同原因模式"""
        patterns = []
        
        # 获取所有入边（原因）
        incoming = self.storage.get_relations_by_target(event_id)
        
        # 检查每对原因是否有共同原因
        for i, rel1 in enumerate(incoming):
            for rel2 in incoming[i+1:]:
                # 检查 rel1.source_id 和 rel2.source_id 是否有共同原因
                common_causes = self.find_common_causes(rel1.source_id, rel2.source_id)
                
                if common_causes:
                    for cc_id in common_causes[:3]:  # 限制数量
                        patterns.append(CausalPatternMatch(
                            pattern_type=CausalPattern.COMMON_CAUSE,
                            events=[cc_id, rel1.source_id, rel2.source_id, event_id],
                            relations=[],  # 简化实现
                            confidence=0.7,
                            description=f"共同原因：{cc_id} → {rel1.source_id} 和 {cc_id} → {rel2.source_id}"
                        ))
        
        return patterns
    
    def _identify_confounder_patterns(self, event_id: str) -> List[CausalPatternMatch]:
        """识别混杂因素模式"""
        patterns = []
        
        # 混杂因素：C→A 且 C→B，且 A→B
        # 这里简化实现
        
        return patterns
    
    def _identify_mediator_patterns(self, event_id: str) -> List[CausalPatternMatch]:
        """识别中介变量模式"""
        patterns = []
        
        # 中介变量：A→M→B
        # 已经在链式模式中识别
        
        return patterns
    
    # =========================================================================
    # 核心功能 4: 图统计和可视化
    # =========================================================================
    
    def get_graph_statistics(self) -> GraphStatistics:
        """
        获取图统计信息
        
        Returns:
            GraphStatistics: 图统计信息
        """
        if not self._initialized:
            self.initialize()
        
        try:
            # 获取所有事件
            all_events = self.storage.get_all_events()
            total_events = len(all_events)
            
            # 获取所有关系
            all_relations = self.storage.get_all_relations()
            total_relations = len(all_relations)
            
            # 计算度数
            in_degrees = {}
            out_degrees = {}
            
            for event in all_events:
                in_degrees[event.id] = 0
                out_degrees[event.id] = 0
            
            for relation in all_relations:
                out_degrees[relation.source_id] = out_degrees.get(relation.source_id, 0) + 1
                in_degrees[relation.target_id] = in_degrees.get(relation.target_id, 0) + 1
            
            # 计算统计量
            avg_degree = total_relations / max(total_events, 1) * 2  # 平均度数
            max_in = max(in_degrees.values()) if in_degrees else 0
            max_out = max(out_degrees.values()) if out_degrees else 0
            
            # 密度 = 边数 / (节点数 * (节点数 -1))
            density = total_relations / max(total_events * (total_events - 1), 1)
            
            # 连通分量（简化实现，实际应该用图算法）
            connected_components = 1  # 简化
            
            return GraphStatistics(
                total_events=total_events,
                total_relations=total_relations,
                avg_degree=avg_degree,
                max_in_degree=max_in,
                max_out_degree=max_out,
                connected_components=connected_components,
                density=density
            )
        
        except Exception as e:
            logger.error(f"Error getting graph statistics: {e}")
            return GraphStatistics(
                total_events=0,
                total_relations=0,
                avg_degree=0.0,
                max_in_degree=0,
                max_out_degree=0,
                connected_components=0,
                density=0.0
            )
    
    def extract_subgraph(self, event_ids: List[str], 
                        max_hops: int = 2) -> Dict[str, Any]:
        """
        提取子图
        
        Args:
            event_ids: 核心事件 ID 列表
            max_hops: 最大跳数
        
        Returns:
            Dict: 子图数据（nodes 和 edges）
        """
        if not self._initialized:
            self.initialize()
        
        try:
            # 收集所有相关事件
            related_events = set(event_ids)
            
            # BFS 扩展
            for _ in range(max_hops):
                new_events = set()
                for event_id in related_events:
                    # 获取邻居
                    outgoing = self.storage.get_relations_by_source(event_id)
                    incoming = self.storage.get_relations_by_target(event_id)
                    
                    for rel in outgoing:
                        new_events.add(rel.target_id)
                    for rel in incoming:
                        new_events.add(rel.source_id)
                
                related_events.update(new_events)
            
            # 获取子图的关系
            subgraph_relations = []
            for event_id in related_events:
                outgoing = self.storage.get_relations_by_source(event_id)
                for rel in outgoing:
                    if rel.target_id in related_events:
                        subgraph_relations.append(rel)
            
            # 构建子图数据
            nodes = []
            for event_id in related_events:
                event = self.storage.get_event(event_id)
                if event:
                    nodes.append({
                        'id': event.id,
                        'name': event.name,
                        'type': 'event'
                    })
            
            edges = []
            for rel in subgraph_relations:
                edges.append({
                    'source': rel.source_id,
                    'target': rel.target_id,
                    'type': rel.relation_type,
                    'confidence': rel.confidence
                })
            
            logger.info(f"Extracted subgraph with {len(nodes)} nodes and {len(edges)} edges")
            
            return {
                'nodes': nodes,
                'edges': edges
            }
        
        except Exception as e:
            logger.error(f"Error extracting subgraph: {e}")
            return {'nodes': [], 'edges': []}
