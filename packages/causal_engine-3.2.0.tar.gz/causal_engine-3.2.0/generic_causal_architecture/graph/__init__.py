"""
因果图谱包 - 基于图结构的因果网络查询和推理

核心功能：
1. 因果链查询（找出 A 到 B 的所有因果路径）
2. 关系推理（发现隐含的因果关系）
3. 模式识别（识别常见的因果模式）
4. 图遍历（多跳查询）
5. 子图提取（提取相关因果网络）

使用示例：
    from generic_causal_architecture.graph import CausalGraph
    
    graph = CausalGraph(storage)
    graph.initialize()
    
    # 查询因果链
    chains = graph.find_causal_chains("event_a", "event_b")
    
    # 查找共同原因
    common_causes = graph.find_common_causes("event_a", "event_b")
"""

from .causal_graph import (
    CausalGraph,
    CausalPath,
    CausalPatternMatch,
    CausalPattern,
    QueryType,
    GraphStatistics,
)

__all__ = [
    'CausalGraph',
    'CausalPath',
    'CausalPatternMatch',
    'CausalPattern',
    'QueryType',
    'GraphStatistics',
]
