"""
Config module - 配置管理

使用示例：
    from generic_causal_architecture.config import Config
    
    config = Config.from_yaml("config/default.yaml")
    storage = config.get_storage()
"""

from .config import Config

__all__ = ['Config']
