"""
配置管理系统 - 所有配置集中管理

重要说明：
1. 所有配置都应该从配置文件加载，不应该硬编码
2. 支持 YAML 格式（人类可读）
3. 支持环境变量覆盖（便于部署）
4. 配置类应该是不可变的（防止运行时修改）

使用示例：
    config = Config.from_yaml("config/default.yaml")
    storage = config.get_storage()
    engine = CausalEngine(config)
"""

import os
import yaml
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from ..storage.storage_interface import StorageInterface


@dataclass(frozen=True)  # frozen=True 使配置不可变
class StorageConfig:
    """
    存储配置
    
    属性:
        storage_type: 存储类型 (memory/sqlite/postgresql)
        storage_path: 存储路径（数据库文件或数据目录）
        auto_save: 是否自动保存（仅内存存储）
        database_url: PostgreSQL 数据库 URL（可选）
        pool_size: 连接池大小（仅 PostgreSQL）
        echo: 是否打印 SQL（仅 PostgreSQL，调试用）
        max_overflow: 连接池最大溢出值（仅 PostgreSQL）
        pool_recycle: 连接回收时间（秒，仅 PostgreSQL）
        pool_pre_ping: 连接健康检查（仅 PostgreSQL）
    """
    storage_type: str = "postgresql"
    storage_path: str = "data/causal.db"
    auto_save: bool = False
    database_url: str = field(default_factory=lambda: os.getenv('DATABASE_URL', 'postgresql://postgres:causal_password@localhost:5432/causal_db'))
    pool_size: int = 5
    max_overflow: int = 10
    pool_recycle: int = 3600
    pool_pre_ping: bool = True
    echo: bool = False


@dataclass(frozen=True)
class CausalConfig:
    """
    因果推断配置
    
    属性:
        temporal_threshold: 时序阈值（年）
        confidence_threshold: 置信度阈值（0-1）
        max_path_length: 最大因果路径长度
        enable_temporal_check: 启用时序检查
        enable_sufficiency_check: 启用充分性检查
        enable_directness_check: 启用直接性检查
    """
    temporal_threshold: float = 100.0
    confidence_threshold: float = 0.6  # MVP 阶段降低阈值
    max_path_length: int = 15
    enable_temporal_check: bool = True
    enable_sufficiency_check: bool = True
    enable_directness_check: bool = True


@dataclass(frozen=True)
class LLMConfig:
    """
    大模型配置 - 支持多种 LLM 提供商
    
    支持的提供商：
    - openai: OpenAI GPT 系列
    - claude: Anthropic Claude 系列
    - ollama: 本地模型（Ollama）
    
    属性:
        provider: LLM 提供商 (openai/claude/ollama)
        api_key: API 密钥（建议从环境变量读取）
        model_id: 模型 ID
        model: 模型名称（兼容字段）
        base_url: API 基础 URL（用于兼容服务或本地部署）
        temperature: 温度（0-1）
        max_tokens: 最大 token 数
        timeout: 请求超时（秒）
    """
    provider: str = "openai"
    api_key: str = field(default_factory=lambda: os.getenv('LLM_API_KEY', ''))
    model_id: str = "gpt-4"
    model: str = "gpt-4"  # 兼容字段
    base_url: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 2000
    timeout: int = 60


@dataclass(frozen=True)
class LayerConfig:
    """
    分层调用配置（成本控制）
    
    属性:
        l1_enabled: 启用 L1（规则引擎）
        l2_enabled: 启用 L2（统计计算）
        l3_enabled: 启用 L3（符号推理）
        l4_enabled: 启用 L4（大模型）
        l4_budget_per_request: 单次请求最大花费（元）
        l4_daily_budget: 每日总预算（元）
        l4_cost_threshold: 单次调用成本阈值（美元）
    """
    l1_enabled: bool = True
    l2_enabled: bool = True
    l3_enabled: bool = True
    l4_enabled: bool = True
    l4_budget_per_request: float = 1.0
    l4_daily_budget: float = 100.0
    l4_cost_threshold: float = 0.5


@dataclass(frozen=True)
class LoggingConfig:
    """
    日志配置
    
    属性:
        level: 日志级别
        format: 日志格式
        file: 日志文件路径（None 表示输出到控制台）
        max_bytes: 单个日志文件最大字节数
        backup_count: 保留的备份文件数量
    """
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file: Optional[str] = None
    max_bytes: int = 10485760  # 10MB
    backup_count: int = 5


@dataclass(frozen=True)
class CacheConfig:
    """
    缓存配置
    
    属性:
        enabled: 是否启用缓存
        type: 缓存类型 (memory/redis)
        host: Redis 主机
        port: Redis 端口
        password: Redis 密码
        db: Redis 数据库编号
        ttl: 缓存过期时间（秒）
    """
    enabled: bool = False
    type: str = "memory"
    host: str = "localhost"
    port: int = 6379
    password: Optional[str] = None
    db: int = 0
    ttl: int = 3600


@dataclass(frozen=True)
class SecurityConfig:
    """
    安全配置
    
    属性:
        api_key_header: API 密钥请求头
        cors_origins: CORS 允许的源
        rate_limit_requests: 速率限制（每分钟请求数）
        rate_limit_burst: 速率限制突发值
    """
    api_key_header: str = "X-API-Key"
    cors_origins: list = field(default_factory=lambda: ["*"])
    rate_limit_requests: int = 100
    rate_limit_burst: int = 20


@dataclass(frozen=True)
class PerformanceConfig:
    """
    性能配置
    
    属性:
        batch_size: 批量操作大小
        async_enabled: 是否启用异步处理
        worker_count: 工作线程数
        query_timeout: 查询超时（秒）
        max_results: 最大返回结果数
    """
    batch_size: int = 100
    async_enabled: bool = True
    worker_count: int = 4
    query_timeout: int = 30
    max_results: int = 1000


@dataclass(frozen=True)
class Config:
    """
    总配置类 - 所有配置集中管理
    
    重要说明：
    1. 这个类是 frozen 的（不可变），防止运行时修改
    2. 所有配置都应该从 YAML 文件加载
    3. 环境变量可以覆盖配置文件中的值
    
    使用示例：
        config = Config.from_yaml("config/default.yaml")
        storage = config.get_storage()
        engine = CausalEngine(config)
    """
    # 存储配置
    storage: StorageConfig = field(default_factory=StorageConfig)
    
    # 因果推断配置
    causal: CausalConfig = field(default_factory=CausalConfig)
    
    # 大模型配置
    llm: LLMConfig = field(default_factory=LLMConfig)
    
    # 分层调用配置
    layer: LayerConfig = field(default_factory=LayerConfig)
    
    # 日志配置
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    
    # 缓存配置
    cache: CacheConfig = field(default_factory=CacheConfig)
    
    # 安全配置
    security: SecurityConfig = field(default_factory=SecurityConfig)
    
    # 性能配置
    performance: PerformanceConfig = field(default_factory=PerformanceConfig)
    
    # 其他配置
    debug: bool = False  # 调试模式
    log_level: str = "INFO"  # 日志级别（已废弃，使用 logging.level）
    data_dir: str = "data"  # 数据目录
    
    @classmethod
    def from_yaml(cls, filepath: str) -> 'Config':
        """
        从 YAML 文件加载配置
        
        参数:
            filepath: YAML 文件路径
        
        返回:
            Config 对象
        
        注意：
        - 如果文件不存在，返回默认配置
        - 环境变量会覆盖配置文件中的值
        """
        if not os.path.exists(filepath):
            print(f"Config file not found: {filepath}, using defaults")
            return cls()
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            
            # 解析嵌套配置
            storage_data = data.get('storage', {})
            causal_data = data.get('causal', {})
            llm_data = data.get('llm', {})
            layer_data = data.get('layer', {})
            logging_data = data.get('logging', {})
            cache_data = data.get('cache', {})
            security_data = data.get('security', {})
            performance_data = data.get('performance', {})
            
            # 创建配置对象
            return cls(
                storage=StorageConfig(**storage_data),
                causal=CausalConfig(**causal_data),
                llm=LLMConfig(**llm_data),
                layer=LayerConfig(**layer_data),
                logging=LoggingConfig(**logging_data),
                cache=CacheConfig(**cache_data),
                security=SecurityConfig(**security_data),
                performance=PerformanceConfig(**performance_data),
                debug=data.get('debug', False),
                data_dir=data.get('data_dir', 'data'),
            )
            
        except Exception as e:
            print(f"Error loading config: {e}")
            return cls()
    
    def to_yaml(self, filepath: str) -> None:
        """
        保存配置到 YAML 文件
        
        参数:
            filepath: YAML 文件路径
        """
        try:
            data = {
                'storage': {
                    'storage_type': self.storage.storage_type,
                    'storage_path': self.storage.storage_path,
                    'auto_save': self.storage.auto_save,
                },
                'causal': {
                    'temporal_threshold': self.causal.temporal_threshold,
                    'confidence_threshold': self.causal.confidence_threshold,
                    'max_path_length': self.causal.max_path_length,
                    'enable_temporal_check': self.causal.enable_temporal_check,
                    'enable_sufficiency_check': self.causal.enable_sufficiency_check,
                    'enable_directness_check': self.causal.enable_directness_check,
                },
                'llm': {
                    'model_id': self.llm.model_id,
                    'temperature': self.llm.temperature,
                    'max_tokens': self.llm.max_tokens,
                    'timeout': self.llm.timeout,
                    # 注意：api_key 不保存（安全）
                },
                'layer': {
                    'l1_enabled': self.layer.l1_enabled,
                    'l2_enabled': self.layer.l2_enabled,
                    'l3_enabled': self.layer.l3_enabled,
                    'l4_enabled': self.layer.l4_enabled,
                    'l4_budget_per_request': self.layer.l4_budget_per_request,
                    'l4_daily_budget': self.layer.l4_daily_budget,
                },
                'debug': self.debug,
                'log_level': self.log_level,
                'data_dir': self.data_dir,
            }
            
            # 确保目录存在
            os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                yaml.dump(data, f, default_flow_style=False, allow_unicode=True)
            
            print(f"Config saved to: {filepath}")
            
        except Exception as e:
            print(f"Error saving config: {e}")
            raise
    
    def get_storage(self) -> StorageInterface:
        """
        获取存储实例
        
        返回:
            StorageInterface 的实现（MemoryStorage/SQLiteStorage/PostgreSQLStorage）
        
        注意：
        - 根据 storage_type 返回不同的实现
        - 使用依赖注入模式
        """
        from ..storage.memory_storage import MemoryStorage
        from ..storage.sqlite_storage import SQLiteStorage
        from ..storage.postgresql_storage import PostgreSQLStorage
        
        if self.storage.storage_type == "memory":
            return MemoryStorage(
                auto_save=self.storage.auto_save,
                save_path=os.path.join(self.data_dir, "memory_storage.pkl")
            )
        
        elif self.storage.storage_type == "sqlite":
            return SQLiteStorage(
                db_path=self.storage.storage_path
            )
        
        elif self.storage.storage_type == "postgresql":
            return PostgreSQLStorage(
                database_url=self.storage.database_url,
                pool_size=self.storage.pool_size,
                echo=self.storage.echo
            )
        
        else:
            raise ValueError(f"Unknown storage type: {self.storage.storage_type}")
    
    def validate(self) -> bool:
        """
        验证配置是否有效
        
        返回:
            bool: 有效返回 True，否则抛出异常
        
        异常:
            ValueError: 配置无效
        """
        # 验证存储类型
        if self.storage.storage_type not in ["memory", "sqlite", "postgresql"]:
            raise ValueError(f"Invalid storage type: {self.storage.storage_type}")
        
        # 验证置信度阈值
        if not (0.0 <= self.causal.confidence_threshold <= 1.0):
            raise ValueError(f"Invalid confidence threshold: {self.causal.confidence_threshold}")
        
        # 验证 L4 预算
        if self.layer.l4_budget_per_request < 0:
            raise ValueError(f"Invalid L4 budget: {self.layer.l4_budget_per_request}")
        
        return True
