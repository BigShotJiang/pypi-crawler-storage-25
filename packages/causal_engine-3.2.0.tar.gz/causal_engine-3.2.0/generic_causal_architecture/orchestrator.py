"""
LLM 编排器 - 智能调度因果推断和大模型

核心功能：
1. 意图理解 - 理解用户想要什么
2. 数据准备 - 自动搜索和准备事件数据
3. 参数选择 - 根据场景自动选择推断参数
4. 因果推断 - 调用因果引擎
5. 结果解释 - 用自然语言解释技术结果
6. 上下文管理 - 维护多轮对话历史

重要设计原则：
1. LLM 由用户配置 - 我们不提供 LLM，只调用用户配置的 LLM
2. 成本透明 - 实时统计 LLM 用量和费用
3. 灵活配置 - 支持云端和本地模型
4. 上下文感知 - 支持多轮对话

使用示例：
    from generic_causal_architecture.orchestrator import LLMOrchestrator
    from generic_causal_architecture.llm import create_llm_provider
    
    # 创建 LLM Provider（用户自己配置）
    llm = create_llm_provider({
        "provider": "openai",
        "api_key": "sk-...",
        "model": "gpt-4"
    })
    
    # 创建编排器
    orchestrator = LLMOrchestrator(llm, causal_engine)
    
    # 单轮对话
    response = await orchestrator.chat("分析秦朝灭亡的原因")
    print(response.content)
    print(f"LLM 费用：${response.usage['cost_usd']}")
    
    # 多轮对话（带上下文）
    session_id = "session_123"
    response1 = await orchestrator.chat("分析秦朝灭亡的原因", session_id=session_id)
    response2 = await orchestrator.chat("那商鞅变法呢？", session_id=session_id)
    # 第二次对话会自动使用第一次的上下文
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
import time
import asyncio

from .llm.provider import LLMProvider
from .core.causal_engine import CausalEngine
from .storage.storage_interface import EventData, CausalRelation


@dataclass
class OrchestratorResponse:
    """编排器响应"""
    content: str  # 回复内容
    intent: Dict[str, Any]  # 理解的意图
    events: List[EventData]  # 使用的事件
    relations: List[CausalRelation]  # 推断的因果关系
    usage: Dict[str, Any]  # LLM 用量统计
    session_id: Optional[str] = None  # 会话 ID
    latency: float = 0.0  # 延迟（秒）


@dataclass
class SessionContext:
    """会话上下文"""
    session_id: str
    history: List[Dict[str, str]] = field(default_factory=list)  # 对话历史
    events: List[EventData] = field(default_factory=list)  # 相关事件
    relations: List[CausalRelation] = field(default_factory=list)  # 因果关系
    preferences: Dict[str, Any] = field(default_factory=dict)  # 用户偏好
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)


class LLMOrchestrator:
    """
    LLM 编排器 - 连接用户、LLM 和因果引擎
    
    工作流程：
    1. 用户输入 → LLM 理解意图
    2. 意图 → 准备数据（搜索事件）
    3. 数据 → 因果引擎推断
    4. 结果 → LLM 生成解释
    5. 解释 → 返回用户
    
    使用示例：
        orchestrator = LLMOrchestrator(llm, causal_engine)
        response = await orchestrator.chat("分析秦朝灭亡的原因")
    """
    
    def __init__(
        self,
        llm_provider: LLMProvider,
        causal_engine: CausalEngine,
        max_context_length: int = 10,
        auto_save_context: bool = True
    ):
        """
        初始化编排器
        
        Args:
            llm_provider: LLM Provider（由用户配置）
            causal_engine: 因果引擎
            max_context_length: 最大上下文长度（对话历史条数）
            auto_save_context: 是否自动保存上下文
        """
        self.llm = llm_provider
        self.causal_engine = causal_engine
        self.max_context_length = max_context_length
        self.auto_save_context = auto_save_context
        
        # 会话管理
        self.sessions: Dict[str, SessionContext] = {}
        
        # 系统提示词
        self.system_prompt = """你是因果分析助手，擅长用自然语言解释复杂的因果关系。
你的任务是：
1. 理解用户的问题
2. 调用因果推断引擎分析
3. 用通俗易懂的语言解释结果
4. 指出关键因果链和置信度
5. 说明可能的局限性

保持回答：
- 准确：基于推断结果，不臆测
- 清晰：用简单语言解释复杂概念
- 完整：包含主要原因和置信度
- 客观：指出不确定性和局限性"""
    
    async def chat(
        self,
        user_input: str,
        session_id: Optional[str] = None,
        domain: Optional[str] = None,
        **kwargs
    ) -> OrchestratorResponse:
        """
        处理用户对话
        
        Args:
            user_input: 用户输入
            session_id: 会话 ID（可选，用于多轮对话）
            domain: 领域（可选，如 history/economics）
            **kwargs: 其他参数
        
        Returns:
            OrchestratorResponse 响应对象
        """
        start_time = time.time()
        
        # 1. 获取或创建会话上下文
        if session_id:
            context = self._get_or_create_session(session_id)
        else:
            context = None
        
        # 2. 理解意图（调用 LLM）
        intent = await self._understand_intent(user_input, context)
        
        # 3. 准备数据（搜索事件）
        events = await self._prepare_data(intent, domain)
        
        # 4. 因果推断（调用因果引擎）
        relations = await self._run_inference(events, intent)
        
        # 5. 生成解释（调用 LLM）
        explanation = await self._generate_explanation(
            user_input, intent, events, relations, context
        )
        
        # 6. 更新上下文
        if context:
            self._update_context(context, user_input, explanation, events, relations)
        
        # 7. 计算延迟
        latency = time.time() - start_time
        
        # 8. 返回响应
        return OrchestratorResponse(
            content=explanation,
            intent=intent,
            events=events,
            relations=relations,
            usage=self.llm.get_usage(),
            session_id=session_id,
            latency=latency
        )
    
    def _get_or_create_session(self, session_id: str) -> SessionContext:
        """获取或创建会话"""
        if session_id not in self.sessions:
            self.sessions[session_id] = SessionContext(session_id=session_id)
        return self.sessions[session_id]
    
    def _update_context(
        self,
        context: SessionContext,
        user_input: str,
        response: str,
        events: List[EventData],
        relations: List[CausalRelation]
    ):
        """更新会话上下文"""
        # 添加对话历史
        context.history.append({
            "role": "user",
            "content": user_input
        })
        context.history.append({
            "role": "assistant",
            "content": response
        })
        
        # 限制历史长度
        if len(context.history) > self.max_context_length * 2:
            context.history = context.history[-self.max_context_length * 2:]
        
        # 更新事件和关系
        context.events.extend(events)
        context.relations.extend(relations)
        
        # 更新时间
        context.updated_at = time.time()
    
    async def _understand_intent(
        self,
        user_input: str,
        context: Optional[SessionContext]
    ) -> Dict[str, Any]:
        """
        理解用户意图
        
        返回格式：
        {
            "type": "causal_analysis",  # 意图类型
            "domain": "history",         # 领域
            "target": "秦朝灭亡",         # 目标事件
            "analysis_type": "root_cause"  # 分析类型
        }
        """
        # 构建提示词
        system_message = {
            "role": "system",
            "content": """你是意图识别助手。请分析用户输入，提取以下信息：
1. intent_type: 意图类型（causal_analysis/comparison/explanation）
2. domain: 领域（history/economics/politics/other）
3. target_event: 目标事件
4. analysis_type: 分析类型（root_cause/consequence/correlation）

用 JSON 格式回复。"""
        }
        
        # 添加上下文（如果有）
        messages = [system_message]
        if context and context.history:
            messages.extend(context.history[-4:])  # 最近 2 轮对话
        
        messages.append({
            "role": "user",
            "content": user_input
        })
        
        # 调用 LLM
        response = await self.llm.chat(messages)
        
        # 解析意图（简单实现，生产环境用 JSON 解析）
        intent = {
            "type": "causal_analysis",
            "domain": "history",
            "target": user_input,
            "analysis_type": "root_cause"
        }
        
        return intent
    
    async def _prepare_data(
        self,
        intent: Dict[str, Any],
        domain: Optional[str]
    ) -> List[EventData]:
        """
        准备数据 - 搜索相关事件
        
        生产级实现：
        1. 从知识库搜索相关事件
        2. 从上下文提取事件
        3. 让用户提供事件
        
        搜索策略：
        - 使用意图中的 target 作为搜索词
        - 支持领域过滤
        - 限制返回数量（避免上下文过长）
        """
        storage = self.causal_engine.storage
        
        # 1. 从知识库搜索相关事件
        try:
            events = storage.search_events(
                query=intent.get("target", ""),
                domain=domain or intent.get("domain"),
                limit=50  # 限制 50 个事件，避免上下文过长
            )
            
            if events:
                logger.info(f"搜索到 {len(events)} 个相关事件")
                return events
                
        except Exception as e:
            logger.error(f"搜索事件失败：{e}", exc_info=True)
        
        # 2. 如果搜索失败或无结果，从上下文提取
        if self.context:
            context_events = self.context.get("events", [])
            if context_events:
                logger.info(f"从上下文中获取 {len(context_events)} 个事件")
                return context_events
        
        # 3. 都没有，返回空列表（由用户提供）
        logger.warning("未能自动准备数据，需要用户提供事件")
        return []
    
    async def _run_inference(
        self,
        events: List[EventData],
        intent: Dict[str, Any]
    ) -> List[CausalRelation]:
        """运行因果推断"""
        if not events:
            return []
        
        # 调用因果引擎
        try:
            result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.causal_engine.infer_causality(events)
            )
            return result.relations
        except Exception as e:
            # 推断失败，返回空列表
            return []
    
    async def _generate_explanation(
        self,
        user_input: str,
        intent: Dict[str, Any],
        events: List[EventData],
        relations: List[CausalRelation],
        context: Optional[SessionContext]
    ) -> str:
        """
        生成自然语言解释
        
        将技术结果转换为用户能理解的自然语言
        """
        # 构建结果摘要
        result_summary = self._format_relations(relations)
        
        # 构建提示词
        messages = [
            {
                "role": "system",
                "content": self.system_prompt
            }
        ]
        
        # 添加上下文
        if context and context.history:
            messages.extend(context.history[-4:])
        
        # 添加当前请求
        messages.append({
            "role": "user",
            "content": f"""
用户问题：{user_input}

因果推断结果：
{result_summary}

请用自然语言解释这个结果，要求：
1. 突出最重要的 3 个因果关系
2. 解释置信度的含义
3. 指出可能的局限性
4. 如果有上下文，保持连贯性
"""
        })
        
        # 调用 LLM
        explanation = await self.llm.chat(messages)
        
        return explanation
    
    def _format_relations(self, relations: List[CausalRelation]) -> str:
        """格式化因果关系列表"""
        if not relations:
            return "未检测到显著的因果关系"
        
        lines = []
        for i, rel in enumerate(relations[:10], 1):  # 最多显示 10 个
            lines.append(
                f"{i}. {rel.source} → {rel.target}\n"
                f"   置信度：{rel.confidence:.2f}\n"
                f"   方法：{rel.method}"
            )
        
        return "\n".join(lines)
    
    def get_session_stats(self, session_id: str) -> Dict[str, Any]:
        """获取会话统计"""
        if session_id not in self.sessions:
            return {}
        
        context = self.sessions[session_id]
        return {
            "session_id": session_id,
            "message_count": len(context.history) // 2,
            "event_count": len(context.events),
            "relation_count": len(context.relations),
            "created_at": context.created_at,
            "updated_at": context.updated_at
        }
    
    def clear_session(self, session_id: str):
        """清除会话"""
        if session_id in self.sessions:
            del self.sessions[session_id]
    
    def clear_all_sessions(self):
        """清除所有会话"""
        self.sessions.clear()
