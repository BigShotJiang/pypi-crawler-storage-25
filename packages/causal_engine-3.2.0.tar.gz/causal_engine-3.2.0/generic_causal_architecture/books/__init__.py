"""
古籍文献管理模块 - 大规模文献知识库（生产级）

功能：
1. 书籍结构管理（Book → BookSection）
2. 全文搜索（PostgreSQL FTS）
3. 批量导入
4. 知识提取（与 KnowledgeExtractor 集成）
5. 与因果引擎共用 PostgreSQL 数据库

架构设计：
- 使用 PostgreSQL 数据库
- 通过 schema 隔离：causal（因果）、books（文献）、knowledge（知识）
- 支持跨 schema 查询
- 生产级性能和扩展性

使用示例:
```python
from generic_causal_architecture.books import BookManager, PostgreSQLBookStorage

# 初始化（与因果引擎共用同一个 PostgreSQL）
book_storage = PostgreSQLBookStorage(
    database_url="postgresql://user:pass@localhost:5432/causal_db",
    schema="books"
)
book_manager = BookManager(book_storage)

# 导入
book_id = book_manager.import_book("docs/示例_伤寒论结构化.json")

# 查询
book = book_manager.get_book(book_id)
sections = book_manager.get_sections(book_id)

# 搜索
books = book_manager.search_books("伤寒", category="医藏")
sections = book_manager.search_sections("太阳病")

# 跨 schema 查询（文献 + 知识）
cursor.execute('''
    SELECT b.title, k.name, k.content
    FROM books.books b
    JOIN causal.knowledge k ON b.id = k.source_id
    WHERE b.category = '医藏'
''')
```
"""

from .models import Book, BookSection, BookIndex
from .storage_interface import BookStorageInterface
from .postgresql_storage import PostgreSQLBookStorage
from .manager import BookManager

__all__ = [
    'Book',
    'BookSection',
    'BookIndex',
    'BookStorageInterface',
    'PostgreSQLBookStorage',
    'BookManager',
]
