"""PostgreSQL 书籍存储实现 - 生产级文献存储

使用 PostgreSQL 数据库，与因果引擎共用同一个数据库实例，
通过 schema 隔离文献数据和因果数据。

优势：
- 统一管理：所有数据在一个数据库
- 跨表查询：支持文献和知识的 JOIN 查询
- 生产级性能：支持高并发、大规模数据
- 事务支持：完整的 ACID 事务
- 扩展性强：支持分区、复制、集群

使用示例:
```python
from generic_causal_architecture.books import PostgreSQLBookStorage

# 与因果引擎共用同一个 PostgreSQL 实例
book_storage = PostgreSQLBookStorage(
    database_url="postgresql://user:pass@localhost:5432/causal_db",
    schema="books"  # 使用 books schema 隔离
)

# 导入书籍
book_storage.add_book(book)

# 查询
book = book_storage.get_book("book_shanghan")

# 跨 schema 查询（文献 + 知识）
cursor.execute("SELECT b.title, k.name, k.content FROM books.books b JOIN causal.knowledge k ON b.id = k.source_id WHERE b.category = '医藏'")
```
"""

import psycopg2
import psycopg2.extras
from psycopg2 import sql
import json
import logging
from typing import Dict, List, Any, Optional
from contextlib import contextmanager

from .models import Book, BookSection
from .storage_interface import BookStorageInterface

logger = logging.getLogger(__name__)


class PostgreSQLBookStorage(BookStorageInterface):
    """
    PostgreSQL 书籍存储实现 - 生产级
    
    数据库结构：
    - books.books 表：存储书籍基本信息
    - books.sections 表：存储章节信息
    - books.sections_fts 表：全文搜索索引
    
    使用同一个 PostgreSQL 实例，通过 schema 隔离：
    - causal schema：因果引擎数据
    - books schema：文献数据
    - knowledge schema：知识数据（可选）
    
    示例:
    ```python
    book_storage = PostgreSQLBookStorage(
        database_url="postgresql://user:pass@localhost:5432/causal_db",
        schema="books"
    )
    ```
    """
    
    def __init__(self, 
                 database_url: str,
                 schema: str = "books",
                 pool_size: int = 5,
                 echo: bool = False):
        """
        初始化 PostgreSQL 存储
        
        Args:
            database_url: PostgreSQL 数据库 URL
                格式：postgresql://user:password@host:port/database
            schema: 使用的 schema 名称（默认："books"）
            pool_size: 连接池大小（默认：5）
            echo: 是否打印 SQL（调试用，默认：False）
        """
        self.database_url = database_url
        self.schema = schema
        self.pool_size = pool_size
        self.echo = echo
        self._conn_pool = []
        self._initialized = False
        
        # 初始化 schema
        self._initialize_schema()
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接（上下文管理器）"""
        conn = None
        try:
            # 从连接池获取连接
            if self._conn_pool:
                conn = self._conn_pool.pop()
            else:
                conn = psycopg2.connect(self.database_url)
            
            yield conn
            
        finally:
            if conn:
                # 归还到连接池
                if len(self._conn_pool) < self.pool_size:
                    self._conn_pool.append(conn)
                else:
                    conn.close()
    
    def _initialize_schema(self):
        """初始化 schema 和表结构"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # 创建 schema（如果不存在）
            cursor.execute(sql.SQL("""
                CREATE SCHEMA IF NOT EXISTS {}
            """).format(sql.Identifier(self.schema)))
            
            # 创建 books 表
            cursor.execute(sql.SQL("""
                CREATE TABLE IF NOT EXISTS {}.books (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    author TEXT,
                    dynasty TEXT,
                    category TEXT,
                    file_path TEXT,
                    metadata JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """).format(sql.Identifier(self.schema)))
            
            # 创建 sections 表
            cursor.execute(sql.SQL("""
                CREATE TABLE IF NOT EXISTS {}.sections (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    content TEXT,
                    section_type TEXT,
                    parent_id TEXT,
                    book_id TEXT NOT NULL REFERENCES {}.books(id) ON DELETE CASCADE,
                    "order" INTEGER DEFAULT 0,
                    metadata JSONB,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """).format(
                sql.Identifier(self.schema),
                sql.Identifier(self.schema)
            ))
            
            # 创建索引
            cursor.execute(sql.SQL("""
                CREATE INDEX IF NOT EXISTS idx_books_category 
                ON {}.books(category)
            """).format(sql.Identifier(self.schema)))
            
            cursor.execute(sql.SQL("""
                CREATE INDEX IF NOT EXISTS idx_books_dynasty 
                ON {}.books(dynasty)
            """).format(sql.Identifier(self.schema)))
            
            cursor.execute(sql.SQL("""
                CREATE INDEX IF NOT EXISTS idx_books_title 
                ON {}.books(title)
            """).format(sql.Identifier(self.schema)))
            
            cursor.execute(sql.SQL("""
                CREATE INDEX IF NOT EXISTS idx_sections_book_id 
                ON {}.sections(book_id)
            """).format(sql.Identifier(self.schema)))
            
            cursor.execute(sql.SQL("""
                CREATE INDEX IF NOT EXISTS idx_sections_type 
                ON {}.sections(section_type)
            """).format(sql.Identifier(self.schema)))
            
            # 创建全文搜索索引（使用 GIN）
            cursor.execute(sql.SQL("""
                CREATE INDEX IF NOT EXISTS idx_sections_content_fts 
                ON {}.sections USING gin(to_tsvector('simple', content))
            """).format(sql.Identifier(self.schema)))
            
            # 创建全文搜索函数
            cursor.execute(sql.SQL("""
                CREATE OR REPLACE FUNCTION {}.search_sections(query TEXT, book_id_param TEXT DEFAULT NULL)
                RETURNS TABLE(id TEXT, title TEXT, content TEXT, section_type TEXT, book_id TEXT) AS $$
                BEGIN
                    RETURN QUERY
                    SELECT s.id, s.title, s.content, s.section_type, s.book_id
                    FROM {}.sections s
                    WHERE to_tsvector('simple', s.content) @@ plainto_tsquery('simple', query)
                    AND (book_id_param IS NULL OR s.book_id = book_id_param)
                    ORDER BY ts_rank(to_tsvector('simple', s.content), plainto_tsquery('simple', query)) DESC;
                END;
                $$ LANGUAGE plpgsql;
            """).format(sql.Identifier(self.schema), sql.Identifier(self.schema)))
            
            conn.commit()
            logger.info(f"Schema '{self.schema}' initialized successfully")
    
    def add_book(self, book: Book) -> bool:
        """添加书籍（支持 upsert）"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 插入或更新书籍
                cursor.execute(sql.SQL("""
                    INSERT INTO {}.books (id, title, author, dynasty, category, file_path, metadata, updated_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                    ON CONFLICT (id) DO UPDATE SET
                        title = EXCLUDED.title,
                        author = EXCLUDED.author,
                        dynasty = EXCLUDED.dynasty,
                        category = EXCLUDED.category,
                        file_path = EXCLUDED.file_path,
                        metadata = EXCLUDED.metadata,
                        updated_at = CURRENT_TIMESTAMP
                """).format(sql.Identifier(self.schema)), (
                    book.id,
                    book.title,
                    book.author,
                    book.dynasty,
                    book.category,
                    book.file_path,
                    json.dumps(book.metadata, ensure_ascii=False)
                ))
                
                # 删除旧章节（如果是更新）
                cursor.execute(sql.SQL("""
                    DELETE FROM {}.sections WHERE book_id = %s
                """).format(sql.Identifier(self.schema)), (book.id,))
                
                # 插入新章节
                for section in book.sections:
                    cursor.execute(sql.SQL("""
                        INSERT INTO {}.sections 
                        (id, title, content, section_type, parent_id, book_id, "order", metadata)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    """).format(sql.Identifier(self.schema)), (
                        section.id,
                        section.title,
                        section.content,
                        section.section_type,
                        section.parent_id,
                        book.id,
                        section.order,
                        json.dumps(section.metadata, ensure_ascii=False)
                    ))
                
                conn.commit()
                logger.info(f"Book added: {book.title} ({len(book.sections)} sections)")
                return True
                
        except Exception as e:
            logger.error(f"Failed to add book: {e}")
            return False
    
    def get_book(self, book_id: str) -> Optional[Book]:
        """获取书籍"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            # 查询书籍
            cursor.execute(sql.SQL("""
                SELECT * FROM {}.books WHERE id = %s
            """).format(sql.Identifier(self.schema)), (book_id,))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            book = Book(
                id=row["id"],
                title=row["title"],
                author=row["author"],
                dynasty=row["dynasty"],
                category=row["category"],
                file_path=row["file_path"],
                metadata=row["metadata"] if row["metadata"] else {}
            )
            
            # 查询章节
            cursor.execute(sql.SQL("""
                SELECT * FROM {}.sections 
                WHERE book_id = %s 
                ORDER BY "order" ASC
            """).format(sql.Identifier(self.schema)), (book_id,))
            
            for row in cursor.fetchall():
                section = BookSection(
                    id=row["id"],
                    title=row["title"],
                    content=row["content"],
                    section_type=row["section_type"],
                    parent_id=row["parent_id"],
                    book_id=row["book_id"],
                    order=row["order"],
                    metadata=row["metadata"] if row["metadata"] else {}
                )
                book.sections.append(section)
            
            return book
    
    def delete_book(self, book_id: str) -> bool:
        """删除书籍（级联删除章节）"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                # 外键会自动级联删除章节
                cursor.execute(sql.SQL("""
                    DELETE FROM {}.books WHERE id = %s
                """).format(sql.Identifier(self.schema)), (book_id,))
                
                conn.commit()
                logger.info(f"Book deleted: {book_id}")
                return True
                
        except Exception as e:
            logger.error(f"Failed to delete book: {e}")
            return False
    
    def search_books(self, keyword: str, category: Optional[str] = None,
                     dynasty: Optional[str] = None, author: Optional[str] = None,
                     limit: int = 50) -> List[Book]:
        """搜索书籍"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            # 构建查询
            query = sql.SQL("SELECT * FROM {}.books WHERE 1=1").format(
                sql.Identifier(self.schema)
            )
            params = []
            
            if keyword:
                query += sql.SQL(" AND (title ILIKE %s OR metadata::text ILIKE %s)")
                params.extend([f"%{keyword}%", f"%{keyword}%"])
            
            if category:
                query += sql.SQL(" AND category = %s")
                params.append(category)
            
            if dynasty:
                query += sql.SQL(" AND dynasty = %s")
                params.append(dynasty)
            
            if author:
                query += sql.SQL(" AND author ILIKE %s")
                params.append(f"%{author}%")
            
            query += sql.SQL(" LIMIT %s")
            params.append(limit)
            
            cursor.execute(query, params)
            
            books = []
            for row in cursor.fetchall():
                book = Book(
                    id=row["id"],
                    title=row["title"],
                    author=row["author"],
                    dynasty=row["dynasty"],
                    category=row["category"],
                    file_path=row["file_path"],
                    metadata=row["metadata"] if row["metadata"] else {}
                )
                books.append(book)
            
            return books
    
    def get_all_books(self, category: Optional[str] = None, limit: int = 100) -> List[Book]:
        """获取所有书籍"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            query = sql.SQL("SELECT * FROM {}.books WHERE 1=1").format(
                sql.Identifier(self.schema)
            )
            params = []
            
            if category:
                query += sql.SQL(" AND category = %s")
                params.append(category)
            
            query += sql.SQL(" LIMIT %s")
            params.append(limit)
            
            cursor.execute(query, params)
            
            books = []
            for row in cursor.fetchall():
                book = Book(
                    id=row["id"],
                    title=row["title"],
                    author=row["author"],
                    dynasty=row["dynasty"],
                    category=row["category"],
                    file_path=row["file_path"],
                    metadata=row["metadata"] if row["metadata"] else {}
                )
                books.append(book)
            
            return books
    
    def get_sections_by_book(self, book_id: str, 
                             section_type: Optional[str] = None) -> List[BookSection]:
        """获取书籍章节"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            query = sql.SQL("""
                SELECT * FROM {}.sections 
                WHERE book_id = %s
            """).format(sql.Identifier(self.schema))
            params = [book_id]
            
            if section_type:
                query += sql.SQL(" AND section_type = %s")
                params.append(section_type)
            
            query += sql.SQL(" ORDER BY \"order\" ASC")
            
            cursor.execute(query, params)
            
            sections = []
            for row in cursor.fetchall():
                section = BookSection(
                    id=row["id"],
                    title=row["title"],
                    content=row["content"],
                    section_type=row["section_type"],
                    parent_id=row["parent_id"],
                    book_id=row["book_id"],
                    order=row["order"],
                    metadata=row["metadata"] if row["metadata"] else {}
                )
                sections.append(section)
            
            return sections
    
    def get_section(self, section_id: str) -> Optional[BookSection]:
        """获取章节"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            cursor.execute(sql.SQL("""
                SELECT * FROM {}.sections WHERE id = %s
            """).format(sql.Identifier(self.schema)), (section_id,))
            
            row = cursor.fetchone()
            if not row:
                return None
            
            return BookSection(
                id=row["id"],
                title=row["title"],
                content=row["content"],
                section_type=row["section_type"],
                parent_id=row["parent_id"],
                book_id=row["book_id"],
                order=row["order"],
                metadata=row["metadata"] if row["metadata"] else {}
            )
    
    def update_section(self, section: BookSection) -> bool:
        """更新章节"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                
                cursor.execute(sql.SQL("""
                    UPDATE {}.sections 
                    SET title=%s, content=%s, section_type=%s, 
                        parent_id=%s, "order"=%s, metadata=%s,
                        updated_at=CURRENT_TIMESTAMP
                    WHERE id=%s
                """).format(sql.Identifier(self.schema)), (
                    section.title,
                    section.content,
                    section.section_type,
                    section.parent_id,
                    section.order,
                    json.dumps(section.metadata, ensure_ascii=False),
                    section.id
                ))
                
                conn.commit()
                return True
                
        except Exception as e:
            logger.error(f"Failed to update section: {e}")
            return False
    
    def search_sections(self, keyword: str, book_id: Optional[str] = None,
                       section_type: Optional[str] = None, limit: int = 100) -> List[BookSection]:
        """搜索章节（使用全文搜索）"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            # 使用全文搜索函数
            cursor.execute(sql.SQL("""
                SELECT * FROM {}.search_sections(%s, %s)
                LIMIT %s
            """).format(sql.Identifier(self.schema)), (keyword, book_id, limit))
            
            sections = []
            for row in cursor.fetchall():
                section = BookSection(
                    id=row["id"],
                    title=row["title"],
                    content=row["content"],
                    section_type=row["section_type"],
                    parent_id=row["parent_id"],
                    book_id=row["book_id"],
                    order=row["order"],
                    metadata={}
                )
                sections.append(section)
            
            return sections
    
    def get_statistics(self) -> Dict[str, Any]:
        """获取统计信息"""
        with self._get_connection() as conn:
            cursor = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            
            stats = {}
            
            # 书籍总数
            cursor.execute(sql.SQL("""
                SELECT COUNT(*) FROM {}.books
            """).format(sql.Identifier(self.schema)))
            stats["total_books"] = cursor.fetchone()["count"]
            
            # 章节总数
            cursor.execute(sql.SQL("""
                SELECT COUNT(*) FROM {}.sections
            """).format(sql.Identifier(self.schema)))
            stats["total_sections"] = cursor.fetchone()["count"]
            
            # 按分类统计
            cursor.execute(sql.SQL("""
                SELECT category, COUNT(*) as count 
                FROM {}.books 
                GROUP BY category
            """).format(sql.Identifier(self.schema)))
            stats["books_by_category"] = {
                row["category"]: row["count"] for row in cursor.fetchall()
            }
            
            # 按朝代统计
            cursor.execute(sql.SQL("""
                SELECT dynasty, COUNT(*) as count 
                FROM {}.books 
                GROUP BY dynasty
            """).format(sql.Identifier(self.schema)))
            stats["books_by_dynasty"] = {
                row["dynasty"]: row["count"] for row in cursor.fetchall()
            }
            
            return stats
    
    def batch_add_books(self, books: List[Book]) -> int:
        """批量添加书籍（使用事务）"""
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                success_count = 0
                
                for book in books:
                    try:
                        # 插入书籍
                        cursor.execute(sql.SQL("""
                            INSERT INTO {}.books 
                            (id, title, author, dynasty, category, file_path, metadata, updated_at)
                            VALUES (%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                            ON CONFLICT (id) DO UPDATE SET
                                title = EXCLUDED.title,
                                author = EXCLUDED.author,
                                dynasty = EXCLUDED.dynasty,
                                category = EXCLUDED.category,
                                file_path = EXCLUDED.file_path,
                                metadata = EXCLUDED.metadata,
                                updated_at = CURRENT_TIMESTAMP
                        """).format(sql.Identifier(self.schema)), (
                            book.id,
                            book.title,
                            book.author,
                            book.dynasty,
                            book.category,
                            book.file_path,
                            json.dumps(book.metadata, ensure_ascii=False)
                        ))
                        
                        # 插入章节
                        for section in book.sections:
                            cursor.execute(sql.SQL("""
                                INSERT INTO {}.sections 
                                (id, title, content, section_type, parent_id, book_id, "order", metadata)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                            """).format(sql.Identifier(self.schema)), (
                                section.id,
                                section.title,
                                section.content,
                                section.section_type,
                                section.parent_id,
                                book.id,
                                section.order,
                                json.dumps(section.metadata, ensure_ascii=False)
                            ))
                        
                        success_count += 1
                        
                    except Exception as e:
                        logger.error(f"Failed to add book {book.id}: {e}")
                        continue
                
                conn.commit()
                logger.info(f"Batch added {success_count}/{len(books)} books")
                return success_count
                
        except Exception as e:
            logger.error(f"Batch add failed: {e}")
            return 0
    
    def close(self):
        """关闭所有连接"""
        for conn in self._conn_pool:
            conn.close()
        self._conn_pool = []
        logger.info("All connections closed")
