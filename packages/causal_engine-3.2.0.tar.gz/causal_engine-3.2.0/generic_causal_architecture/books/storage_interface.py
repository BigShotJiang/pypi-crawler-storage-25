"""
书籍存储接口 - 所有书籍存储实现的基类

设计原则：
1. 极简主义 - 只包含必要方法
2. 依赖倒置 - 上层依赖接口，不依赖具体实现
3. 开闭原则 - 对扩展开放，对修改关闭
4. 轻量级 - 最小化接口复杂度

使用方式：
    from generic_causal_architecture.books import BookStorageInterface, SQLiteBookStorage
    
    storage: BookStorageInterface = SQLiteBookStorage("books.db")
    book = storage.get_book("book_shanghan")
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from .models import Book, BookSection


class BookStorageInterface(ABC):
    """
    书籍存储接口 - 所有存储实现必须遵循的规范
    
    职责：
    1. 存储书籍结构（Book + BookSection）
    2. 提供基础 CRUD 操作
    3. 提供简单查询功能
    
    不做：
    1. 不负责知识提取（交给 BookManager）
    2. 不负责业务逻辑（交给应用层）
    3. 不负责缓存（可选优化）
    
    示例:
    ```python
    storage = SQLiteBookStorage("books.db")
    
    # 添加书籍
    storage.add_book(book)
    
    # 查询书籍
    book = storage.get_book("book_shanghan")
    
    # 搜索书籍
    books = storage.search_books("伤寒", category="医藏")
    
    # 获取章节
    sections = storage.get_sections_by_book("book_shanghan")
    ```
    """
    
    @abstractmethod
    def add_book(self, book: Book) -> bool:
        """
        添加书籍
        
        参数:
            book: Book 对象
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意:
        - 如果书籍已存在，应该更新（upsert 语义）
        - 应该同时存储书籍的所有章节
        - 应该验证 book_id 不为空
        """
        pass
    
    @abstractmethod
    def get_book(self, book_id: str) -> Optional[Book]:
        """
        获取单个书籍
        
        参数:
            book_id: 书籍 ID
        
        返回:
            Book 对象，如果不存在返回 None
        
        注意:
        - 应该同时加载所有章节
        - 章节应该按 order 排序
        """
        pass
    
    @abstractmethod
    def delete_book(self, book_id: str) -> bool:
        """
        删除书籍
        
        参数:
            book_id: 书籍 ID
        
        返回:
            bool: 成功返回 True，失败返回 False
        
        注意:
        - 应该同时删除所有章节
        - 应该检查是否有外键依赖
        """
        pass
    
    @abstractmethod
    def search_books(self, keyword: str, category: Optional[str] = None, 
                     dynasty: Optional[str] = None, author: Optional[str] = None,
                     limit: int = 50) -> List[Book]:
        """
        搜索书籍
        
        参数:
            keyword: 搜索关键词（匹配 title 和 metadata）
            category: 分类过滤（如：医藏、儒藏）
            dynasty: 朝代过滤（如：东汉、唐）
            author: 作者过滤
            limit: 返回数量限制
        
        返回:
            Book 列表，按相关性排序
        
        注意:
        - 支持全文搜索（title + metadata）
        - 支持多条件过滤
        - 应该限制返回数量（防止大数据量）
        """
        pass
    
    @abstractmethod
    def get_all_books(self, category: Optional[str] = None, limit: int = 100) -> List[Book]:
        """
        获取所有书籍
        
        参数:
            category: 分类过滤（可选）
            limit: 返回数量限制
        
        返回:
            Book 列表
        
        注意:
        - 应该支持分页（通过 limit 和 offset）
        - 不应该一次性加载所有章节（只加载基本信息）
        """
        pass
    
    @abstractmethod
    def get_sections_by_book(self, book_id: str, 
                             section_type: Optional[str] = None) -> List[BookSection]:
        """
        获取书籍的所有章节
        
        参数:
            book_id: 书籍 ID
            section_type: 章节类型过滤（如：chapter, paragraph）
        
        返回:
            BookSection 列表，按 order 排序
        
        注意:
        - 应该按 order 字段排序
        - 支持按类型过滤
        - 如果书籍不存在，返回空列表
        """
        pass
    
    @abstractmethod
    def get_section(self, section_id: str) -> Optional[BookSection]:
        """
        获取单个章节
        
        参数:
            section_id: 章节 ID
        
        返回:
            BookSection 对象，如果不存在返回 None
        """
        pass
    
    @abstractmethod
    def update_section(self, section: BookSection) -> bool:
        """
        更新章节
        
        参数:
            section: BookSection 对象
        
        返回:
            bool: 成功返回 True，失败返回 False
        """
        pass
    
    @abstractmethod
    def search_sections(self, keyword: str, book_id: Optional[str] = None,
                       section_type: Optional[str] = None, limit: int = 100) -> List[BookSection]:
        """
        搜索章节
        
        参数:
            keyword: 搜索关键词（匹配 content）
            book_id: 书籍 ID 过滤（可选）
            section_type: 章节类型过滤（可选）
            limit: 返回数量限制
        
        返回:
            BookSection 列表，按相关性排序
        
        注意:
        - 支持全文搜索（content 字段）
        - 支持多条件过滤
        - 应该限制返回数量
        """
        pass
    
    @abstractmethod
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        返回:
            字典，包含：
            - total_books: 书籍总数
            - total_sections: 章节总数
            - books_by_category: 按分类统计的书籍数量
            - books_by_dynasty: 按朝代统计的书籍数量
        """
        pass
    
    @abstractmethod
    def batch_add_books(self, books: List[Book]) -> int:
        """
        批量添加书籍
        
        参数:
            books: Book 对象列表
        
        返回:
            int: 成功添加的书籍数量
        
        注意:
        - 应该使用事务保证原子性
        - 如果部分失败，应该回滚
        - 适合批量导入场景
        """
        pass
    
    @abstractmethod
    def close(self):
        """
        关闭存储连接
        
        注意:
        - 释放数据库连接
        - 清理资源
        """
        pass
