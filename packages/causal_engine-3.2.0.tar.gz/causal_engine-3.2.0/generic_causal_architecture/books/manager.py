"""
书籍管理器 - 连接文献和知识的桥梁

职责：
1. 导入书籍（JSON → Book）
2. 提取知识（Book → KnowledgeUnit）
3. 建立关联（Book ↔ Knowledge）

设计原则：
1. 轻量级 - 无状态，不缓存
2. 协调者 - 只协调，不存储
3. 异步支持 - 支持后台任务

使用示例:
```python
from generic_causal_architecture.books import BookManager, SQLiteBookStorage
from generic_causal_architecture.storage import SQLiteStorage

book_storage = SQLiteBookStorage("books.db")
knowledge_storage = SQLiteStorage("knowledge.db")
book_manager = BookManager(book_storage, knowledge_storage)

# 导入书籍
book_id = book_manager.import_book("docs/示例_伤寒论结构化.json")

# 查询
book = book_manager.get_book(book_id)
sections = book_manager.get_sections(book_id)

# 提取知识（异步）
book_manager.extract_knowledge_async(book_id)
```
"""

import json
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path

from .models import Book, BookSection
from .storage_interface import BookStorageInterface

logger = logging.getLogger(__name__)


class BookManager:
    """
    书籍管理器 - 连接文献和知识
    
    职责：
    1. 导入书籍（JSON → Book）
    2. 查询书籍和章节
    3. 提取知识（可选，异步）
    4. 建立书籍和知识的关联
    
    不做：
    1. 不存储数据（交给 Storage）
    2. 不处理业务逻辑（交给应用层）
    3. 不缓存数据（可选优化）
    
    示例:
    ```python
    book_manager = BookManager(book_storage, knowledge_storage)
    
    # 导入
    book_id = book_manager.import_book("伤寒论.json")
    
    # 查询
    book = book_manager.get_book(book_id)
    sections = book_manager.get_sections(book_id)
    
    # 搜索
    books = book_manager.search_books("伤寒", category="医藏")
    sections = book_manager.search_sections("太阳病")
    ```
    """
    
    def __init__(self, book_storage: BookStorageInterface, 
                 knowledge_storage: Optional[Any] = None):
        """
        初始化书籍管理器
        
        Args:
            book_storage: 书籍存储实现
            knowledge_storage: 知识存储实现（可选，用于知识提取）
        """
        self.book_storage = book_storage
        self.knowledge_storage = knowledge_storage
    
    def import_book(self, json_path: str) -> str:
        """
        导入一本书
        
        流程：
        1. 解析 JSON 文件
        2. 创建 Book 对象
        3. 存储到数据库
        4. （可选）提取知识
        
        Args:
            json_path: JSON 文件路径
        
        Returns:
            书籍 ID
        
        示例:
        ```python
        book_id = book_manager.import_book("docs/示例_伤寒论结构化.json")
        ```
        """
        # 1. 解析 JSON
        with open(json_path, 'r', encoding='utf-8') as f:
            book_data = json.load(f)
        
        logger.info(f"Parsing book: {book_data.get('title', 'Unknown')}")
        
        # 2. 创建 Book
        book = self._parse_book(book_data)
        
        # 3. 存储书籍
        self.book_storage.add_book(book)
        
        logger.info(f"Book imported: {book.title} (ID: {book.id}, {len(book.sections)} sections)")
        
        return book.id
    
    def _parse_book(self, book_data: Dict[str, Any]) -> Book:
        """
        解析 JSON 数据为 Book 对象
        
        Args:
            book_data: JSON 数据字典
        
        Returns:
            Book 对象
        """
        # 创建书籍
        book = Book(
            id=book_data.get('id', f"book_{book_data.get('title', 'unknown')}"),
            title=book_data.get('title', ''),
            author=book_data.get('author', ''),
            dynasty=book_data.get('dynasty', ''),
            category=book_data.get('category', ''),
            file_path=book_data.get('file_path', ''),
            metadata=book_data.get('metadata', {})
        )
        
        # 解析章节
        sections_data = book_data.get('sections', [])
        for section_data in sections_data:
            section = BookSection(
                id=section_data.get('id', f"section_{section_data.get('title', 'unknown')}"),
                title=section_data.get('title', ''),
                content=section_data.get('content', ''),
                section_type=section_data.get('type', 'chapter'),
                parent_id=None,  # 扁平结构，暂不支持嵌套
                book_id=book.id,
                order=len(book.sections),
                metadata=section_data.get('metadata', {})
            )
            book.sections.append(section)
        
        # 解析药方（如果有）
        prescriptions_data = book_data.get('prescriptions', [])
        for presc_data in prescriptions_data:
            section = BookSection(
                id=presc_data.get('id', f"prescription_{presc_data.get('name', 'unknown')}"),
                title=presc_data.get('name', ''),
                content=json.dumps(presc_data, ensure_ascii=False),
                section_type='prescription',
                parent_id=None,
                book_id=book.id,
                order=len(book.sections),
                metadata={
                    'indication': presc_data.get('indication', ''),
                    'ingredients': presc_data.get('ingredients', [])
                }
            )
            book.sections.append(section)
        
        return book
    
    def get_book(self, book_id: str) -> Optional[Book]:
        """
        获取书籍
        
        Args:
            book_id: 书籍 ID
        
        Returns:
            Book 对象，不存在返回 None
        """
        return self.book_storage.get_book(book_id)
    
    def get_sections(self, book_id: str, 
                     section_type: Optional[str] = None) -> List[BookSection]:
        """
        获取书籍章节
        
        Args:
            book_id: 书籍 ID
            section_type: 章节类型过滤（可选）
        
        Returns:
            BookSection 列表
        """
        return self.book_storage.get_sections_by_book(book_id, section_type)
    
    def get_section(self, section_id: str) -> Optional[BookSection]:
        """
        获取单个章节
        
        Args:
            section_id: 章节 ID
        
        Returns:
            BookSection 对象，不存在返回 None
        """
        return self.book_storage.get_section(section_id)
    
    def search_books(self, keyword: str, category: Optional[str] = None,
                     dynasty: Optional[str] = None, author: Optional[str] = None,
                     limit: int = 50) -> List[Book]:
        """
        搜索书籍
        
        Args:
            keyword: 搜索关键词
            category: 分类过滤
            dynasty: 朝代过滤
            author: 作者过滤
            limit: 返回数量限制
        
        Returns:
            Book 列表
        """
        return self.book_storage.search_books(keyword, category, dynasty, author, limit)
    
    def search_sections(self, keyword: str, book_id: Optional[str] = None,
                       section_type: Optional[str] = None, limit: int = 100) -> List[BookSection]:
        """
        搜索章节
        
        Args:
            keyword: 搜索关键词
            book_id: 书籍 ID 过滤
            section_type: 章节类型过滤
            limit: 返回数量限制
        
        Returns:
            BookSection 列表
        """
        return self.book_storage.search_sections(keyword, book_id, section_type, limit)
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        return self.book_storage.get_statistics()
    
    def extract_knowledge_async(self, book_id: str):
        """
        异步提取知识（后台任务）
        
        从书籍内容提取知识单元（Theory, Method, Concept 等）
        
        Args:
            book_id: 书籍 ID
        
        注意:
        - 这是异步操作，不阻塞
        - 需要 knowledge_storage 已初始化
        """
        if not self.knowledge_storage:
            logger.warning("Knowledge storage not initialized, skipping knowledge extraction")
            return
        
        logger.info(f"Starting knowledge extraction for book: {book_id}")
        
        # TODO: 实现知识提取逻辑
        # 使用 KnowledgeExtractor 从章节内容提取知识
        # 这部分可以交给后台任务处理
        
        logger.info(f"Knowledge extraction completed for book: {book_id}")
    
    def import_batch(self, json_paths: List[str]) -> int:
        """
        批量导入书籍
        
        Args:
            json_paths: JSON 文件路径列表
        
        Returns:
            成功导入的书籍数量
        """
        books = []
        for json_path in json_paths:
            try:
                with open(json_path, 'r', encoding='utf-8') as f:
                    book_data = json.load(f)
                book = self._parse_book(book_data)
                books.append(book)
            except Exception as e:
                logger.error(f"Failed to parse {json_path}: {e}")
        
        # 批量存储
        success_count = self.book_storage.batch_add_books(books)
        logger.info(f"Batch import completed: {success_count}/{len(books)} books")
        
        return success_count
