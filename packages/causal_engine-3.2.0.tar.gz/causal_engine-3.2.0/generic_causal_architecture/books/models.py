"""
书籍数据模型 - 古籍文献结构定义

用于管理大规模古籍文献库（佛藏、道藏、儒藏、医藏等）

设计原则：
1. 极简主义 - 只包含必要字段
2. 层次清晰 - Book → BookSection 树状结构
3. 灵活扩展 - metadata 支持任意扩展
4. 轻量级 - 最小化内存和存储开销

使用场景：
- 古籍文献管理（十藏：佛藏、道藏、儒藏、医藏等）
- 现代书籍管理
- 任何分层结构的文档管理

示例：
```python
from generic_causal_architecture.books import Book, BookSection

# 创建书籍
book = Book(
    id="book_shanghan",
    title="伤寒论",
    author="张仲景",
    dynasty="东汉",
    category="医藏"
)

# 创建章节
section = BookSection(
    id="section_001",
    title="辨太阳病脉证并治上",
    content="太阳之为病，脉浮、头项强痛而恶寒...",
    section_type="chapter",
    book_id="book_shanghan"
)

book.sections.append(section)
```
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
import uuid


@dataclass
class Book:
    """
    书籍 - 文献管理的基本单位
    
    属性:
        id: 书籍唯一标识符（建议使用前缀：book_xxx）
        title: 书籍标题
        author: 作者（可以是多人，用逗号分隔）
        dynasty: 朝代（如：东汉、唐、宋）
        category: 分类（如：医藏、儒藏、佛藏、道藏等）
        file_path: 原始文件路径（可选）
        sections: 章节列表
        metadata: 元数据（可扩展任意字段）
    
    示例:
    ```python
    book = Book(
        id="book_shanghan",
        title="伤寒论",
        author="张仲景",
        dynasty="东汉",
        category="医藏",
        metadata={
            "total_chapters": 22,
            "total_prescriptions": 113,
            "keywords": ["伤寒", "六经辨证", "中医"]
        }
    )
    ```
    """
    # 核心字段（必填）
    id: str = field(default_factory=lambda: f"book_{uuid.uuid4().hex[:8]}")
    title: str = ""
    author: str = ""
    dynasty: str = ""
    category: str = ""  # 佛藏、道藏、儒藏、医藏、诗藏、史藏、艺藏、易藏、子藏、集藏
    
    # 可选字段
    file_path: str = ""
    sections: List['BookSection'] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def add_section(self, section: 'BookSection'):
        """添加章节"""
        self.sections.append(section)
    
    def get_section_by_id(self, section_id: str) -> Optional['BookSection']:
        """根据 ID 获取章节"""
        for section in self.sections:
            if section.id == section_id:
                return section
        return None
    
    def get_sections_by_type(self, section_type: str) -> List['BookSection']:
        """根据类型获取章节"""
        return [s for s in self.sections if s.section_type == section_type]
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于序列化）"""
        return {
            "id": self.id,
            "title": self.title,
            "author": self.author,
            "dynasty": self.dynasty,
            "category": self.category,
            "file_path": self.file_path,
            "sections": [s.to_dict() for s in self.sections],
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Book":
        """从字典创建（用于反序列化）"""
        book = cls(
            id=data.get("id", f"book_{uuid.uuid4().hex[:8]}"),
            title=data.get("title", ""),
            author=data.get("author", ""),
            dynasty=data.get("dynasty", ""),
            category=data.get("category", ""),
            file_path=data.get("file_path", ""),
            metadata=data.get("metadata", {})
        )
        
        # 加载章节
        for section_data in data.get("sections", []):
            section = BookSection.from_dict(section_data)
            book.sections.append(section)
        
        return book


@dataclass
class BookSection:
    """
    书籍章节 - 支持多层嵌套结构
    
    层级关系：
    - volume（卷）→ chapter（章）→ section（节）→ paragraph（段）
    - 或者扁平结构：chapter（章）→ paragraph（段）
    
    属性:
        id: 章节唯一标识符（建议使用前缀：section_xxx）
        title: 章节标题
        content: 章节内容（全文）
        section_type: 章节类型（volume/chapter/section/paragraph）
        parent_id: 父章节 ID（用于多层嵌套）
        book_id: 所属书籍 ID
        order: 排序顺序（同级别章节的排序）
        metadata: 元数据（可扩展任意字段）
    
    示例:
    ```python
    # 卷
    volume = BookSection(
        id="volume_001",
        title="卷一",
        content="",
        section_type="volume",
        book_id="book_shanghan"
    )
    
    # 章
    chapter = BookSection(
        id="chapter_001",
        title="辨太阳病脉证并治上",
        content="太阳之为病，脉浮、头项强痛而恶寒...",
        section_type="chapter",
        parent_id="volume_001",
        book_id="book_shanghan",
        order=1
    )
    
    # 段（条文）
    paragraph = BookSection(
        id="paragraph_001",
        title="太阳病提纲",
        content="○太阳之为病，脉浮、头项强痛而恶寒。",
        section_type="paragraph",
        parent_id="chapter_001",
        book_id="book_shanghan",
        order=1
    )
    ```
    """
    # 核心字段（必填）
    id: str = field(default_factory=lambda: f"section_{uuid.uuid4().hex[:8]}")
    title: str = ""
    content: str = ""
    section_type: str = "chapter"  # volume, chapter, section, paragraph, treatise, poem, etc.
    book_id: str = ""
    
    # 可选字段
    parent_id: Optional[str] = None
    order: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（用于序列化）"""
        return {
            "id": self.id,
            "title": self.title,
            "content": self.content,
            "section_type": self.section_type,
            "parent_id": self.parent_id,
            "book_id": self.book_id,
            "order": self.order,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BookSection":
        """从字典创建（用于反序列化）"""
        return cls(
            id=data.get("id", f"section_{uuid.uuid4().hex[:8]}"),
            title=data.get("title", ""),
            content=data.get("content", ""),
            section_type=data.get("section_type", "chapter"),
            parent_id=data.get("parent_id"),
            book_id=data.get("book_id", ""),
            order=data.get("order", 0),
            metadata=data.get("metadata", {})
        )


@dataclass
class BookIndex:
    """
    书籍索引 - 用于快速检索
    
    为书籍内容建立倒排索引，支持全文搜索。
    
    属性:
        book_id: 书籍 ID
        word_to_sections: 词语到章节的映射（倒排索引）
        section_index: 章节索引（快速查找）
    """
    book_id: str
    word_to_sections: Dict[str, List[str]] = field(default_factory=dict)  # word -> [section_id]
    section_index: Dict[str, 'BookSection'] = field(default_factory=dict)  # section_id -> section
    
    def add_section(self, section: BookSection, keywords: List[str]):
        """
        添加章节到索引
        
        Args:
            section: 章节对象
            keywords: 从章节内容提取的关键词列表
        """
        self.section_index[section.id] = section
        
        for word in keywords:
            if word not in self.word_to_sections:
                self.word_to_sections[word] = []
            if section.id not in self.word_to_sections[word]:
                self.word_to_sections[word].append(section.id)
    
    def search(self, keyword: str) -> List[BookSection]:
        """
        搜索包含关键词的章节
        
        Args:
            keyword: 搜索关键词
        
        Returns:
            包含该关键词的章节列表
        """
        section_ids = self.word_to_sections.get(keyword, [])
        return [self.section_index[sid] for sid in section_ids if sid in self.section_index]
