"""Experimental fused compressed decode-attention research utilities.

v0.9.0 introduces a benchmarkable *fused-attention interface* over the
compressed KV page layout.  The implementation is intentionally conservative:
it validates the execution contract required by a future Triton/CUDA kernel
(read compressed pages directly, rotate Q once, avoid constructing a full dense
K/V cache) and reports whether a real Triton runtime is available.  When the
runtime/kernel is not available, it falls back to the quality-safe PyTorch page
reference path and labels that mode explicitly.

This module does not claim production inference acceleration.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import torch

from .attention import attention_similarity, dense_attention, sdpa_attention
from .attention_perf import _resolve_device, _resolve_dtype, _runtime_warnings, _sync, triton_status
from .layout import (
    CompressedKVPageTable,
    LayoutBenchConfig,
    compressed_page_attention_reference,
    resolve_layout_preset,
)


def _time_call(fn, *, device: str, warmup: int, repeats: int) -> Tuple[torch.Tensor, float]:
    out = None
    for _ in range(max(0, int(warmup))):
        out = fn()
    _sync(device)
    t0 = time.perf_counter()
    for _ in range(max(1, int(repeats))):
        out = fn()
    _sync(device)
    elapsed = (time.perf_counter() - t0) / max(1, int(repeats))
    assert out is not None
    return out, float(elapsed)


@dataclass
class FusedDecodeBenchConfig:
    """Configuration for experimental compressed decode-attention benchmarks."""

    batch_size: int = 1
    heads: int = 8
    query_len: int = 1
    seq_len: int = 2048
    head_dim: int = 64
    page_size: int = 128
    key_bits: int = 8
    value_bits: int = 6
    preset: Optional[str] = "safe-layout"
    quantization_mode: str = "affine"
    device: str = "auto"
    dtype: str = "auto"
    warmup: int = 1
    repeats: int = 3
    iters: Optional[int] = None
    seed: int = 123
    prefer_triton: bool = True

    def __post_init__(self) -> None:
        if self.iters is not None:
            self.repeats = int(self.iters)
        if self.preset:
            cfg = resolve_layout_preset(self.preset)
            self.key_bits = int(cfg.get("key_bits", self.key_bits))
            self.value_bits = int(cfg.get("value_bits", self.value_bits))
            self.quantization_mode = str(cfg.get("quantization_mode", self.quantization_mode))
        if self.query_len != 1:
            # The v0.9 path is explicitly decode-only.  Keep this strict so
            # users do not confuse it with prefill attention.
            raise ValueError("FusedDecodeBenchConfig is decode-only: query_len must be 1")


def _triton_runtime_status() -> Dict[str, Any]:
    status = triton_status()
    # Keep a normalized field stable for reports.
    return {
        "available": bool(status.get("triton_available", False)),
        "cuda_available": bool(status.get("cuda_available", False)),
        "detail": status,
    }


def experimental_fused_compressed_decode_attention(
    query: torch.Tensor,
    page_table: CompressedKVPageTable,
    *,
    prefer_triton: bool = True,
) -> Tuple[torch.Tensor, Dict[str, Any]]:
    """Run the v0.9 experimental compressed decode-attention path.

    The function consumes the compressed page table directly and avoids full
    dense K/V reconstruction.  In v0.9.0, the quality-safe fallback is the
    PyTorch streaming page implementation.  A real Triton kernel can replace
    this under the same public contract in a later release.
    """

    if query.ndim != 4:
        raise ValueError("query must be shaped (B, H, 1, D)")
    if query.shape[2] != 1:
        raise ValueError("experimental fused decode attention supports query_len=1 only")

    runtime = _triton_runtime_status()
    can_attempt_triton = (
        bool(prefer_triton)
        and runtime["available"]
        and runtime["cuda_available"]
        and query.is_cuda
        and page_table.quantization_mode == "affine"
    )

    # This release establishes the fused-kernel contract and benchmark.  The
    # actual Triton kernel remains intentionally disabled until the packed-page
    # ABI is stable across GPUs.  The report is explicit about this fallback.
    if can_attempt_triton:
        mode = "torch-compressed-page-fallback"
        reason = "triton runtime available, but v0.9.0 kernel scaffold falls back to the verified PyTorch page path"
    else:
        mode = "torch-compressed-page-fallback"
        reason = "triton runtime unavailable or unsupported configuration"

    out = compressed_page_attention_reference(query, page_table, rotate_query=True)
    meta = {
        "mode": mode,
        "triton_attempted": bool(can_attempt_triton),
        "triton_runtime": runtime,
        "reason": reason,
        "query_len": int(query.shape[2]),
        "uses_compressed_pages_directly": True,
        "constructs_full_dense_kv": False,
        "boundary": "experimental research path; not a production fused CUDA/Triton kernel",
    }
    return out, meta


def _build_random_qkv(config: FusedDecodeBenchConfig, device: str, dtype: torch.dtype):
    torch.manual_seed(int(config.seed))
    q = torch.randn(config.batch_size, config.heads, 1, config.head_dim, device=device, dtype=dtype)
    k = torch.randn(config.batch_size, config.heads, config.seq_len, config.head_dim, device=device, dtype=dtype)
    v = torch.randn_like(k)
    return q, k, v


def _quality_warning(metrics: Dict[str, float]) -> str:
    rel = float(metrics.get("relative_error", 999.0))
    cos = float(metrics.get("cosine_similarity", 0.0))
    if cos >= 0.99 and rel <= 0.05:
        return "ok: fused prototype output is close to dense in this benchmark."
    if cos >= 0.95:
        return "caution: fused prototype is directionally close, but error is still material."
    return "weak: fused prototype quality is not safe for kernel work with this layout."


def run_fused_decode_benchmark(config: FusedDecodeBenchConfig) -> Dict[str, Any]:
    """Benchmark dense, SDPA, compressed-page reference, and v0.9 fused path."""

    requested_device = config.device
    requested_dtype = config.dtype
    device = _resolve_device(requested_device)
    dtype = _resolve_dtype(requested_dtype, device)
    warnings = _runtime_warnings(requested_device, device, requested_dtype, dtype)

    q, k, v = _build_random_qkv(config, device, dtype)

    t0 = time.perf_counter()
    table = CompressedKVPageTable.from_dense(
        k,
        v,
        key_bits=config.key_bits,
        value_bits=config.value_bits,
        page_size=config.page_size,
        seed=config.seed,
        dtype_bytes=torch.empty((), dtype=dtype).element_size(),
        quantization_mode=config.quantization_mode,
    )
    layout_build_seconds = time.perf_counter() - t0

    dense_out, dense_seconds = _time_call(
        lambda: dense_attention(q, k, v),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    try:
        sdpa_out, sdpa_seconds = _time_call(
            lambda: sdpa_attention(q, k, v),
            device=device,
            warmup=config.warmup,
            repeats=config.repeats,
        )
        sdpa_report: Optional[Dict[str, Any]] = {
            "seconds": sdpa_seconds,
            "similarity_to_dense": attention_similarity(dense_out, sdpa_out),
        }
    except Exception as exc:  # pragma: no cover depends on torch build/backend
        sdpa_report = {"error": repr(exc)}

    reference_out, reference_seconds = _time_call(
        lambda: compressed_page_attention_reference(q, table, rotate_query=True),
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    fused_meta_holder: Dict[str, Any] = {}

    def _run_fused():
        out, meta = experimental_fused_compressed_decode_attention(
            q,
            table,
            prefer_triton=config.prefer_triton,
        )
        fused_meta_holder.clear()
        fused_meta_holder.update(meta)
        return out

    fused_out, fused_seconds = _time_call(
        _run_fused,
        device=device,
        warmup=config.warmup,
        repeats=config.repeats,
    )

    mem = table.memory_report().to_dict()
    fused_quality = attention_similarity(dense_out, fused_out)
    reference_quality = attention_similarity(dense_out, reference_out)
    warning = _quality_warning(fused_quality)
    if warning.startswith("weak"):
        warnings = list(warnings) + [warning]

    return {
        "version": "0.9.0",
        "benchmark": "experimental-fused-compressed-decode-attention",
        "config": {
            **asdict(config),
            "device": device,
            "dtype": str(dtype).replace("torch.", ""),
            "requested_device": requested_device,
            "requested_dtype": requested_dtype,
            "iters": int(config.repeats),
        },
        "warnings": warnings,
        "execution": fused_meta_holder,
        "layout": table.to_dict(include_pages=False),
        "memory": mem,
        "timing": {
            "layout_build_seconds": float(layout_build_seconds),
            "dense_attention_seconds": float(dense_seconds),
            "sdpa": sdpa_report,
            "compressed_page_reference_seconds": float(reference_seconds),
            "experimental_fused_seconds": float(fused_seconds),
            "note": (
                "Timing is diagnostic. v0.9.0 establishes the fused-attention benchmark contract; "
                "production acceleration is not claimed."
            ),
        },
        "quality": {
            "fused_vs_dense": fused_quality,
            "reference_vs_dense": reference_quality,
            "fused_vs_reference": attention_similarity(reference_out, fused_out),
            "quality_warning": warning,
        },
        "interpretation": (
            "v0.9.0 benchmarks an experimental compressed decode-attention path over the compressed page layout. "
            "It reads compressed pages without constructing full dense K/V. When a production Triton kernel is not "
            "available, the benchmark uses the verified PyTorch compressed-page fallback and reports that mode explicitly."
        ),
    }


def fused_decode_markdown_report(report: Dict[str, Any]) -> str:
    mem = report["memory"]
    timing = report["timing"]
    quality = report["quality"]
    execution = report.get("execution", {})
    lines = [
        "# tiny-turboquant v0.9.0 fused decode-attention benchmark",
        "",
        "## Execution",
        f"- Mode: {execution.get('mode')}",
        f"- Triton attempted: {execution.get('triton_attempted')}",
        f"- Uses compressed pages directly: {execution.get('uses_compressed_pages_directly')}",
        f"- Constructs full dense K/V: {execution.get('constructs_full_dense_kv')}",
        f"- Reason: {execution.get('reason')}",
        "",
        "## Memory",
        f"- FP16 K/V bytes: {mem['fp16_kv_bytes']}",
        f"- Actual compressed-layout bytes: {mem['actual_total_bytes']}",
        f"- Effective compression: {mem['effective_compression_ratio']:.4f}x",
        f"- Effective memory saved: {mem['effective_memory_saved_pct']:.2f}%",
        "",
        "## Timing",
        f"- Dense attention seconds: {timing['dense_attention_seconds']:.6f}",
        f"- Compressed page reference seconds: {timing['compressed_page_reference_seconds']:.6f}",
        f"- Experimental fused seconds: {timing['experimental_fused_seconds']:.6f}",
        f"- SDPA: {timing.get('sdpa')}",
        "",
        "## Quality",
        f"- Fused vs dense: {quality['fused_vs_dense']}",
        f"- Reference vs dense: {quality['reference_vs_dense']}",
        f"- Fused vs reference: {quality['fused_vs_reference']}",
        f"- Warning: {quality['quality_warning']}",
        "",
        "## Boundary",
        "This is an experimental research benchmark. It does not claim production inference acceleration.",
    ]
    return "\n".join(lines) + "\n"


def save_fused_decode_json(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(json.dumps(report, indent=2), encoding="utf-8")


def save_fused_decode_markdown(report: Dict[str, Any], path: str | Path) -> None:
    Path(path).write_text(fused_decode_markdown_report(report), encoding="utf-8")
