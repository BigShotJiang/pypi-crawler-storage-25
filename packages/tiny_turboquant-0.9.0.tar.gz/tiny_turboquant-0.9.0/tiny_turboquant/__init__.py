"""Tiny TurboQuant: low-bit vector and KV-cache compression research toolkit."""

from .attention import attention_similarity, dense_attention, sdpa_attention, streaming_paged_attention
from .bitpack import pack_indices, packed_num_bytes, tensor_nbytes, unpack_indices
from .outlier_split import OutlierSplitTurboQuant
from .quantizer import TurboQuantMSE, TurboQuantProd
from .rotation import RandomRotation
from .kv_bench import KVBenchConfig, first_divergence, markdown_report, run_kv_benchmark
from .kv_estimator import KVCacheMemoryEstimate, auto_outlier_count, estimate_kv_cache_memory
from .kv_presets import KV_CACHE_PRESETS, available_kv_presets, resolve_kv_cache_preset
from .attention_perf import (
    PageAttentionBenchConfig,
    make_kv_pages,
    page_attention_markdown_report,
    run_page_attention_benchmark,
    save_page_attention_json,
    save_page_attention_markdown,
    triton_status,
)
from .fused_attention import (
    FusedDecodeBenchConfig,
    experimental_fused_compressed_decode_attention,
    run_fused_decode_benchmark,
    fused_decode_markdown_report,
    save_fused_decode_json,
    save_fused_decode_markdown,
)
from .serving import (
    PagedKVCacheSpec,
    ServingEngineAdapter,
    TensorRTLLMExperimentAdapter,
    VLLMExperimentAdapter,
)


from .layout import (
    CompressedKVPage,
    CompressedKVPageTable,
    LayoutMemoryReport,
    RotatedCompressedKVCache,
    LayoutBenchConfig,
    compressed_page_attention_reference,
    rotate_q_attention_reference,
    run_rotate_q_check,
    run_layout_benchmark,
    layout_markdown_report,
    save_layout_json,
    save_layout_markdown,
    LAYOUT_PRESETS,
    available_layout_presets,
    resolve_layout_preset,
    LayoutSweepConfig,
    run_layout_quality_sweep,
    layout_sweep_markdown_report,
    save_layout_sweep_markdown,
)
from .serving_sim import (
    ServingSequence,
    PagedServingConfig,
    SequenceMemoryRecord,
    ServingMemoryReport,
    PagedKVServingSimulator,
    ServingCapacityEstimate,
    estimate_serving_capacity,
    DecodeGrowthPoint,
    simulate_decode_growth,
    serving_markdown_report,
    decode_growth_markdown_report,
    save_decode_growth_csv,
)
from .vector_index import CompressedVectorIndex, VectorSearchResult
from .metrics import recall_at_k, precision_at_k, mrr_at_k, ndcg_at_k, exact_overlap, label_match_ratio
from .rag import (
    DocumentChunk,
    RAGSearchResult,
    RAGCompressedIndex,
    chunk_text,
    make_chunks,
    load_texts_from_jsonl,
    load_texts_from_folder,
    compare_retrieval_ids,
)

__all__ = [
    "pack_indices",
    "unpack_indices",
    "packed_num_bytes",
    "tensor_nbytes",
    "TurboQuantKVCache",
    "HybridTurboQuantKVCache",
    "OutlierSplitTurboQuant",
    "TurboQuantMSE",
    "TurboQuantProd",
    "RandomRotation",
    "CompressedVectorIndex",
    "VectorSearchResult",
    "dense_attention",
    "streaming_paged_attention",
    "attention_similarity",
    "triton_status",
    "save_page_attention_markdown",
    "save_page_attention_json",
    "page_attention_markdown_report",
    "run_page_attention_benchmark",
    "make_kv_pages",
    "PageAttentionBenchConfig",
    "sdpa_attention",
    "PagedKVCacheSpec",
    "ServingEngineAdapter",
    "VLLMExperimentAdapter",
    "TensorRTLLMExperimentAdapter",
    "recall_at_k",
    "precision_at_k",
    "mrr_at_k",
    "ndcg_at_k",
    "exact_overlap",
    "label_match_ratio",
    "DocumentChunk",
    "RAGSearchResult",
    "RAGCompressedIndex",
    "chunk_text",
    "make_chunks",
    "load_texts_from_jsonl",
    "load_texts_from_folder",
    "compare_retrieval_ids",
    "KV_CACHE_PRESETS",
    "available_kv_presets",
    "resolve_kv_cache_preset",
    "KVCacheMemoryEstimate",
    "auto_outlier_count",
    "estimate_kv_cache_memory",
    "KVBenchConfig",
    "first_divergence",
    "run_kv_benchmark",
    "markdown_report",
    "ServingSequence",
    "PagedServingConfig",
    "SequenceMemoryRecord",
    "ServingMemoryReport",
    "PagedKVServingSimulator",
    "ServingCapacityEstimate",
    "estimate_serving_capacity",
    "DecodeGrowthPoint",
    "simulate_decode_growth",
    "serving_markdown_report",
    "decode_growth_markdown_report",
    "save_decode_growth_csv",
    "CompressedKVPage",
    "CompressedKVPageTable",
    "LayoutMemoryReport",
    "RotatedCompressedKVCache",
    "LayoutBenchConfig",
    "compressed_page_attention_reference",
    "rotate_q_attention_reference",
    "run_rotate_q_check",
    "run_layout_benchmark",
    "layout_markdown_report",
    "save_layout_json",
    "save_layout_markdown",
    "LAYOUT_PRESETS",
    "available_layout_presets",
    "resolve_layout_preset",
    "LayoutSweepConfig",
    "run_layout_quality_sweep",
    "layout_sweep_markdown_report",
    "save_layout_sweep_markdown",
    "FusedDecodeBenchConfig",
    "experimental_fused_compressed_decode_attention",
    "run_fused_decode_benchmark",
    "fused_decode_markdown_report",
    "save_fused_decode_json",
    "save_fused_decode_markdown",
]

__version__ = "0.9.0"


def __getattr__(name: str):
    if name in {"TurboQuantKVCache", "HybridTurboQuantKVCache"}:
        from .kv_cache import HybridTurboQuantKVCache, TurboQuantKVCache

        return {
            "TurboQuantKVCache": TurboQuantKVCache,
            "HybridTurboQuantKVCache": HybridTurboQuantKVCache,
        }[name]
    raise AttributeError(f"module 'tiny_turboquant' has no attribute {name!r}")
