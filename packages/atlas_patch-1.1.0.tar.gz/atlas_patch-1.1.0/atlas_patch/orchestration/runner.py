from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any, Iterable, Sequence

import h5py
from tqdm import tqdm

from atlas_patch.core.config import AppConfig
from atlas_patch.core.models import ExtractionResult, Slide
from atlas_patch.core.paths import find_existing_patch, patch_lock_path
from atlas_patch.core.wsi.iwsi import IWSI
from atlas_patch.orchestration.parallel import (
    ExtractionTask,
    InflightTracker,
    PatchExtractionExecutor,
)
from atlas_patch.services.interfaces import (
    ExtractionService,
    MPPResolver,
    SegmentationService,
    VisualizationService,
    WSILoader,
)
from atlas_patch.utils import missing_features
from atlas_patch.utils.params import get_wsi_files

logger = logging.getLogger("atlas_patch.runner")


def _chunked(items: Sequence[Slide], size: int) -> Iterable[Sequence[Slide]]:
    for i in range(0, len(items), size):
        yield items[i : i + size]


def build_existing_extraction_result(slide: Slide, h5_path: Path) -> ExtractionResult | None:
    """Create a lightweight ExtractionResult from an existing H5."""
    metadata: dict[str, Any] = {}
    num_patches: int | None = None
    patch_size_level0: int | None = None
    try:
        with h5py.File(h5_path, "r") as f:
            num_attr = f.attrs.get("num_patches")
            if num_attr is not None:
                num_patches = int(num_attr)
            elif "coords" in f:
                num_patches = int(f["coords"].shape[0])

            ps_level0_attr = f.attrs.get("patch_size_level0")
            if ps_level0_attr is not None:
                patch_size_level0 = int(ps_level0_attr)
    except Exception as e:  # noqa: BLE001
        logger.warning(
            "Failed to read existing output for %s; will reprocess. Error: %s",
            slide.path.name,
            e,
        )
        return None

    if num_patches is None or num_patches <= 0:
        return None

    return ExtractionResult(
        slide=slide,
        h5_path=h5_path,
        num_patches=int(num_patches),
        patch_size_level0=patch_size_level0,
        metadata=metadata,
    )


def classify_existing_slide_output(
    config: AppConfig,
    slide: Slide,
) -> tuple[str | None, ExtractionResult | None]:
    """Return how an existing patch H5 should be treated for this run.

    Returns one of:
    - (None, None): no reusable output; the slide needs full processing
    - ("skip", None): output is fully complete for this run
    - ("reuse", ExtractionResult): reuse patches/H5 and continue with downstream features
    """
    if not config.output.skip_existing:
        return None, None

    existing_path = find_existing_patch(slide, config.output, config.extraction)
    if existing_path is None:
        return None, None

    feat_cfg = config.features
    if feat_cfg is None or not feat_cfg.extractors:
        return "skip", None

    existing_result = build_existing_extraction_result(slide, existing_path)
    if existing_result is None:
        return None, None

    missing = missing_features(
        existing_path,
        feat_cfg.extractors,
        expected_total=existing_result.num_patches,
    )
    if not missing:
        return "skip", None
    return "reuse", existing_result


class ProcessingRunner:
    """High-level orchestration of WSI segmentation, patch extraction, and visualization."""

    def __init__(
        self,
        config: AppConfig,
        segmentation: SegmentationService,
        extractor: ExtractionService,
        visualizer: VisualizationService | None,
        mpp_resolver: MPPResolver,
        wsi_loader: WSILoader,
        *,
        show_progress: bool = False,
    ) -> None:
        self.config = config.validated()
        self.segmentation = segmentation
        self.extractor = extractor
        self.visualizer = visualizer
        self.mpp_resolver = mpp_resolver
        self.wsi_loader = wsi_loader
        self.show_progress = show_progress

    def discover_slides(self) -> list[Slide]:
        files = get_wsi_files(
            str(self.config.processing.input_path), recursive=self.config.processing.recursive
        )
        slides: list[Slide] = []
        for f in files:
            slide = Slide(path=Path(f))
            slides.append(slide)
        return slides

    def _handle_existing_slide(
        self,
        slide: Slide,
        results: list[ExtractionResult],
        progress,
    ) -> bool:
        """Handle skip/reuse logic for existing outputs.

        Returns True when the slide is fully handled (skip or reuse), False to continue processing.
        """
        decision, existing_result = classify_existing_slide_output(self.config, slide)
        if decision is None:
            return False
        if decision == "skip":
            logger.info("Skipping %s (already processed).", slide.path.name)
            if progress:
                progress.update(1)
            return True
        if existing_result is None:
            return False
        results.append(existing_result)
        missing = missing_features(
            existing_result.h5_path,
            self.config.features.extractors,
            expected_total=existing_result.num_patches,
        )
        logger.info(
            "Reusing existing patches for %s; missing features: %s",
            slide.path.name,
            ", ".join(missing),
        )
        if progress:
            progress.update(1)
        return True

    def _acquire_lock(self, slide: Slide) -> tuple[int | None, Path]:
        """Attempt to acquire a per-slide lock file. Returns (fd, path) or (None, path if held elsewhere)."""
        lock_path = patch_lock_path(slide, self.config.output, self.config.extraction)
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        payload = f"pid={os.getpid()},time={int(time.time())},slide={slide.path}"
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, payload.encode())
            os.fsync(fd)
            return fd, lock_path
        except FileExistsError:
            return None, lock_path
        except Exception as e:  # noqa: BLE001
            raise RuntimeError(f"Failed to create lock {lock_path}: {e}") from e

    @staticmethod
    def _release_lock(fd: int | None, path: Path) -> None:
        if fd is not None:
            try:
                os.close(fd)
            except Exception:
                pass
        try:
            path.unlink()
        except FileNotFoundError:
            pass
        except Exception:
            pass

    def _attach_mpp(self, slides: list[Slide]) -> list[Slide]:
        resolved: list[Slide] = []
        for s in slides:
            mpp_value = self.mpp_resolver.resolve(s)
            resolved.append(Slide(path=s.path, mpp=mpp_value, backend=s.backend))
        return resolved

    def _resolve_patch_workers(self) -> int:
        workers_cfg = self.config.extraction.workers
        if workers_cfg is not None:
            return max(1, int(workers_cfg))
        return max(1, int(os.cpu_count() or 4))

    def _resolve_max_open_slides(self, patch_workers: int, batch_size: int) -> int:
        cfg_val = self.config.extraction.max_open_slides
        if cfg_val is None:
            raise ValueError("max_open_slides must be defined")
        return max(1, int(cfg_val))

    def run(
        self,
        slides: list[Slide] | None = None,
    ) -> tuple[list[ExtractionResult], list[tuple[Slide, Exception | str]]]:
        if slides is None:
            slides = self.discover_slides()
        slides = self._attach_mpp(slides)

        if not slides:
            logger.warning("No slides found to process.")
            return [], []

        results: list[ExtractionResult] = []
        failures: list[tuple[Slide, Exception | str]] = []

        progress = tqdm(total=len(slides), disable=not self.show_progress, desc="Processing slides")
        progress_bar = progress if self.show_progress else None
        patch_workers = self._resolve_patch_workers()
        batch_size = max(1, self.config.segmentation.batch_size)
        max_open_slides = self._resolve_max_open_slides(patch_workers, batch_size=batch_size)
        with PatchExtractionExecutor(
            extractor=self.extractor,
            visualizer=self.visualizer,
            release_lock=self._release_lock,
            max_workers=patch_workers,
        ) as executor:
            tracker = InflightTracker(results=results, failures=failures, progress=progress_bar)

            for batch in _chunked(slides, batch_size):
                # Ensure capacity for new openings before starting next batch.
                allow_inflight = max(0, max_open_slides - batch_size)
                tracker.wait_until_at_most(limit=allow_inflight if allow_inflight > 0 else 0)

                opened: list[tuple[Slide, IWSI, int | None, Path]] = []

                # Skip/reuse check and open WSIs once with lock acquisition
                for slide in batch:
                    if self._handle_existing_slide(slide, results, progress_bar):
                        continue
                    fd, lock_path = self._acquire_lock(slide)
                    if fd is None:
                        logger.info("Skipping %s (locked by another process).", slide.path.name)
                        if progress_bar:
                            progress_bar.update(1)
                        continue
                    try:
                        opened.append((slide, self.wsi_loader.open(slide), fd, lock_path))
                    except Exception as e:  # noqa: BLE001
                        failures.append((slide, e))
                        logger.error("Failed to open %s: %s", slide.path.name, e)
                        self._release_lock(fd, lock_path)
                        if progress_bar:
                            progress_bar.update(1)

                if not opened:
                    continue

                submitted_wsis: set[IWSI] = set()
                masks = None
                try:
                    wsis_only = [w for _, w, _, _ in opened]
                    masks = (
                        self.segmentation.segment_batch(wsis_only)
                        if len(wsis_only) > 1
                        else [self.segmentation.segment_thumbnail(wsis_only[0])]
                    )
                except Exception as e:  # noqa: BLE001
                    for slide, wsi, fd, path in opened:
                        failures.append((slide, e))
                        logger.error("Segmentation failed for %s: %s", slide.path.name, e)
                        try:
                            wsi.cleanup()
                        except Exception:
                            pass
                        self._release_lock(fd, path)
                        if progress_bar:
                            progress_bar.update(1)
                else:
                    for (slide, wsi, lock_fd, lock_path), mask in zip(opened, masks):
                        task = ExtractionTask(
                            slide=slide,
                            wsi=wsi,
                            mask=mask.data,
                            lock_fd=lock_fd,
                            lock_path=lock_path,
                        )
                        fut = executor.submit(task)
                        tracker.add(fut, slide)
                        submitted_wsis.add(wsi)
                finally:
                    # Clean up WSIs that were not submitted (e.g., skipped or segmentation failed).
                    for _slide, wsi, lock_fd, lock_path in opened:
                        if wsi in submitted_wsis:
                            continue
                        try:
                            wsi.cleanup()
                        except Exception:
                            pass
                        self._release_lock(lock_fd, lock_path)

                # Respect global cap on open slides after submissions.
                tracker.wait_until_at_most(limit=max_open_slides)

            # Drain any remaining in-flight tasks.
            tracker.wait_until_at_most(limit=0)

        if self.show_progress:
            progress.close()
        return results, failures
