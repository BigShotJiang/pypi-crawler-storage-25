Creative Commons Attribution 4.0 International

Copyright (c) 2026 Tony Jurg

Documentation, notebooks, images, and other non-code repository materials are
licensed under the Creative Commons Attribution 4.0 International License.

You are free to:

- Share: copy and redistribute the material in any medium or format
- Adapt: remix, transform, and build upon the material for any purpose, even commercially

Under the following terms:

- Attribution: You must give appropriate credit, provide a link to the license,
  and indicate if changes were made. You may do so in any reasonable manner,
  but not in any way that suggests the licensor endorses you or your use.

License text:
https://creativecommons.org/licenses/by/4.0/
