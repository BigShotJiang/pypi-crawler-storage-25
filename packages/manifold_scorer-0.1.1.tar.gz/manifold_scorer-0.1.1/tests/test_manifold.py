import numpy as np
import pytest
from manifold import ManifoldScorer, rbf_kernel, median_sigma


def _make_bank(n=200, d=32, seed=0):
    rng = np.random.default_rng(seed)
    hist = rng.standard_normal((n, d)).astype(np.float32)
    resp = rng.standard_normal((n, d)).astype(np.float32)
    hist /= np.linalg.norm(hist, axis=1, keepdims=True)
    resp /= np.linalg.norm(resp, axis=1, keepdims=True)
    return hist, resp


def test_median_sigma_positive():
    X = np.random.randn(100, 32).astype(np.float32)
    assert median_sigma(X) > 0


def test_rbf_self_similarity():
    X = np.random.randn(10, 16).astype(np.float32)
    K = rbf_kernel(X, X[0], sigma=1.0)
    assert abs(K[0] - 1.0) < 1e-5


def test_fit_and_score():
    hist, resp = _make_bank()
    scorer = ManifoldScorer(k=20).fit(hist, resp)
    s = scorer.score(hist[0], resp[0])
    assert isinstance(s, float) and np.isfinite(s)


def test_score_batch():
    hist, resp = _make_bank()
    scorer = ManifoldScorer(k=20).fit(hist, resp)
    scores = scorer.score_batch(hist[:10], resp[:10])
    assert scores.shape == (10,) and np.all(np.isfinite(scores))


def test_make_pairs_shape():
    hist, resp = _make_bank()
    scorer = ManifoldScorer(k=20).fit(hist, resp)
    N, n_cands, d = 10, 4, 32
    rng = np.random.default_rng(1)
    cands = rng.standard_normal((N, n_cands, d)).astype(np.float32)
    cands /= np.linalg.norm(cands, axis=2, keepdims=True)
    pairs = scorer.make_pairs(hist[:N], cands, return_scores=True)
    assert pairs["chosen_emb"].shape == (N, d)
    assert pairs["rejected_emb"].shape == (N, d)
    assert pairs["margin"].shape == (N,)
    assert np.all(pairs["margin"] >= 0)
    assert pairs["scores"].shape == (N, n_cands)


def test_rank_candidates():
    hist, resp = _make_bank()
    scorer = ManifoldScorer(k=20).fit(hist, resp)
    cands = np.random.randn(5, 32).astype(np.float32)
    ranked = scorer.rank_candidates(hist[0], cands)
    assert list(sorted(ranked)) == list(range(5))


def test_save_load(tmp_path):
    hist, resp = _make_bank()
    scorer = ManifoldScorer(k=20).fit(hist, resp)
    path = str(tmp_path / "scorer.npz")
    scorer.save(path)
    loaded = ManifoldScorer.load(path)
    assert abs(scorer.score(hist[0], resp[0]) - loaded.score(hist[0], resp[0])) < 1e-6


def test_unfitted_raises():
    with pytest.raises(RuntimeError):
        ManifoldScorer().score(np.zeros(32), np.zeros(32))


def test_repr():
    hist, resp = _make_bank()
    scorer = ManifoldScorer(k=20).fit(hist, resp)
    assert "fitted" in repr(scorer)


def test_tune_k_unsupervised():
    from manifold import tune_k
    # Just unlabeled community data — no labels needed
    hist, resp = _make_bank(n=300, d=32, seed=42)
    result = tune_k(hist, resp, k_values=[10, 25, 50], n_probe=50, verbose=False)
    assert "best_k" in result
    assert result["best_k"] in [10, 25, 50]
    assert 0.0 <= result["best_score"] <= 1.0
    assert len(result["results"]) == 3
