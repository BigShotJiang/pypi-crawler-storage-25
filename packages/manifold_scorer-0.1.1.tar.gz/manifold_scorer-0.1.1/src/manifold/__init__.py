"""
manifold: local acceptance-manifold scoring for implicit RLHF preference pairs.

Based on Gerard & Volkova (2026) "Density-Guided Response Optimization."
The core idea: responses accepted by a community cluster in coherent,
high-density regions of embedding space. Local density (conditioned on
nearby context histories) reliably recovers human preference ordering —
and can substitute for explicit preference annotations.

Public API
----------
ManifoldScorer   – fit on accepted responses, score candidates, generate pairs
rbf_kernel       – RBF kernel (exposed for custom use)
median_sigma     – median heuristic bandwidth estimator
"""
from __future__ import annotations

import numpy as np
from sklearn.neighbors import NearestNeighbors


# ---------------------------------------------------------------------------
# Kernel helpers
# ---------------------------------------------------------------------------

def median_sigma(X: np.ndarray, max_points: int = 2000, seed: int = 0) -> float:
    """
    Estimate RBF bandwidth via the median heuristic over a response bank.

    Subsamples up to ``max_points`` rows, computes random pairwise distances,
    and returns the median. This is the bandwidth used in the paper.
    """
    rng = np.random.default_rng(seed)
    idx = rng.choice(len(X), size=min(len(X), max_points), replace=False)
    Z = X[idx]
    dists = []
    for i in range(len(Z)):
        j = rng.integers(0, len(Z), size=10)
        dists.extend(np.sqrt(np.sum((Z[i] - Z[j]) ** 2, axis=1)).tolist())
    return float(max(np.median(dists), 1e-6))


def rbf_kernel(X: np.ndarray, y: np.ndarray, sigma: float) -> np.ndarray:
    """RBF kernel between rows of X and a single vector y. Returns shape (n,)."""
    d2 = np.sum((X - y) ** 2, axis=1)
    return np.exp(-d2 / (2.0 * sigma * sigma))


# ---------------------------------------------------------------------------
# ManifoldScorer
# ---------------------------------------------------------------------------

class ManifoldScorer:
    """
    Score candidate responses by local acceptance density.

    Fit on a bank of (history, response) pairs representing community-accepted
    content. For a new (history, candidate_response) pair, the score is the
    log-KDE density of the candidate response in the neighborhood of the
    most similar training histories — i.e., how much the candidate looks like
    what this community accepts in similar conversations.

    Parameters
    ----------
    k : int
        Number of nearest history neighbors to condition on (default 150,
        as used in the paper; performance is robust across a wide range).
    sigma : float or None
        RBF bandwidth. None → estimated via median heuristic at fit time.
    nn_metric : str
        Distance metric for history kNN (default "cosine").

    Example
    -------
    >>> scorer = ManifoldScorer(k=150)
    >>> scorer.fit(history_embeddings, response_embeddings)
    >>> score = scorer.score(query_hist_emb, candidate_resp_emb)
    >>> pairs = scorer.make_pairs(query_hists, candidates_per_query)
    """

    def __init__(
        self,
        k: int = 150,
        sigma: float | None = None,
        nn_metric: str = "cosine",
    ):
        self.k = int(k)
        self.sigma = sigma
        self.nn_metric = nn_metric
        self._fitted = False

    # ------------------------------------------------------------------
    # Fitting
    # ------------------------------------------------------------------

    def fit(
        self,
        hist_embeddings: np.ndarray,
        resp_embeddings: np.ndarray,
        sigma_seed: int = 0,
    ) -> "ManifoldScorer":
        """
        Build the acceptance manifold from a bank of accepted (history, response) pairs.

        Parameters
        ----------
        hist_embeddings : np.ndarray, shape (N, d)
            Embeddings of the context/history for each accepted response.
        resp_embeddings : np.ndarray, shape (N, d)
            Embeddings of the accepted responses themselves.
        sigma_seed : int
            Seed for the median heuristic subsampling.

        Returns self for chaining.
        """
        if hist_embeddings.shape[0] != resp_embeddings.shape[0]:
            raise ValueError(
                f"hist and resp bank sizes must match: "
                f"{hist_embeddings.shape[0]} != {resp_embeddings.shape[0]}"
            )

        self._hist_bank = np.asarray(hist_embeddings, dtype=np.float32)
        self._resp_bank = np.asarray(resp_embeddings, dtype=np.float32)

        if self.sigma is None:
            self._sigma = median_sigma(self._resp_bank, seed=sigma_seed)
        else:
            self._sigma = float(self.sigma)

        n_neighbors = min(self.k, len(self._hist_bank))
        self._nn = NearestNeighbors(n_neighbors=n_neighbors, metric=self.nn_metric)
        self._nn.fit(self._hist_bank)

        self._fitted = True
        return self

    # ------------------------------------------------------------------
    # Scoring
    # ------------------------------------------------------------------

    def score(self, hist_emb: np.ndarray, resp_emb: np.ndarray) -> float:
        """
        Log acceptance density for a single (history, response) pair.

        Higher = more consistent with what this community accepts in
        similar conversations.

        Parameters
        ----------
        hist_emb : np.ndarray, shape (d,)
        resp_emb : np.ndarray, shape (d,)
        """
        self._check_fitted()
        idx = self._neighbors(hist_emb)
        neighborhood = self._resp_bank[idx]
        K = rbf_kernel(neighborhood, resp_emb, self._sigma)
        return float(np.log(np.mean(K) + 1e-12))

    def score_batch(
        self,
        hist_embs: np.ndarray,
        resp_embs: np.ndarray,
    ) -> np.ndarray:
        """
        Score a batch of (history, response) pairs.

        Parameters
        ----------
        hist_embs : np.ndarray, shape (N, d)
        resp_embs : np.ndarray, shape (N, d)

        Returns
        -------
        np.ndarray of shape (N,) — log-density score per pair.
        """
        self._check_fitted()
        return np.array([
            self.score(hist_embs[i], resp_embs[i]) for i in range(len(hist_embs))
        ])

    # ------------------------------------------------------------------
    # Pair generation  ← the main RLHF use case
    # ------------------------------------------------------------------

    def make_pairs(
        self,
        hist_embs: np.ndarray,
        candidate_resp_embs: np.ndarray,
        return_scores: bool = False,
    ) -> dict:
        """
        Generate implicit preference pairs from multiple candidates per query.

        For each query, ranks all candidate responses by local acceptance
        density and returns the highest-density response as ``chosen`` and
        the lowest-density response as ``rejected``. This is the core
        DGRO pair-construction procedure.

        Parameters
        ----------
        hist_embs : np.ndarray, shape (N, d)
            One history embedding per query.
        candidate_resp_embs : np.ndarray, shape (N, n_candidates, d)
            ``n_candidates`` response embeddings per query.
        return_scores : bool
            If True, also return the raw density scores per candidate.

        Returns
        -------
        dict with keys:
            "chosen_idx"   : np.ndarray (N,) — index of chosen candidate per query
            "rejected_idx" : np.ndarray (N,) — index of rejected candidate per query
            "chosen_emb"   : np.ndarray (N, d)
            "rejected_emb" : np.ndarray (N, d)
            "margin"       : np.ndarray (N,) — chosen_score − rejected_score
            "scores"       : np.ndarray (N, n_candidates), only if return_scores=True

        Example
        -------
        >>> # 100 queries, 4 candidates each
        >>> pairs = scorer.make_pairs(hist_embs, cand_embs)
        >>> # Feed pairs["chosen_emb"] / pairs["rejected_emb"] to your DPO trainer
        """
        self._check_fitted()
        N, n_cands, d = candidate_resp_embs.shape
        assert len(hist_embs) == N, "hist_embs and candidate_resp_embs must have same N"

        all_scores = np.zeros((N, n_cands), dtype=np.float64)
        for i in range(N):
            for j in range(n_cands):
                all_scores[i, j] = self.score(hist_embs[i], candidate_resp_embs[i, j])

        chosen_idx   = np.argmax(all_scores, axis=1)
        rejected_idx = np.argmin(all_scores, axis=1)

        chosen_emb   = candidate_resp_embs[np.arange(N), chosen_idx]
        rejected_emb = candidate_resp_embs[np.arange(N), rejected_idx]
        margin = all_scores[np.arange(N), chosen_idx] - all_scores[np.arange(N), rejected_idx]

        out = {
            "chosen_idx":   chosen_idx,
            "rejected_idx": rejected_idx,
            "chosen_emb":   chosen_emb,
            "rejected_emb": rejected_emb,
            "margin":       margin,
        }
        if return_scores:
            out["scores"] = all_scores
        return out

    def rank_candidates(
        self,
        hist_emb: np.ndarray,
        candidate_resp_embs: np.ndarray,
    ) -> np.ndarray:
        """
        Rank a list of candidate responses for a single query by density.

        Parameters
        ----------
        hist_emb : np.ndarray, shape (d,)
        candidate_resp_embs : np.ndarray, shape (n_candidates, d)

        Returns
        -------
        np.ndarray of indices sorted best → worst (highest density first).
        """
        self._check_fitted()
        scores = np.array([
            self.score(hist_emb, candidate_resp_embs[j])
            for j in range(len(candidate_resp_embs))
        ])
        return np.argsort(scores)[::-1]

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        """Save the fitted scorer to a .npz file."""
        self._check_fitted()
        np.savez_compressed(
            path,
            hist_bank=self._hist_bank,
            resp_bank=self._resp_bank,
            sigma=np.array([self._sigma]),
            k=np.array([self.k]),
            nn_metric=np.array([self.nn_metric]),
        )

    @classmethod
    def load(cls, path: str) -> "ManifoldScorer":
        """Load a previously saved scorer."""
        data = np.load(path, allow_pickle=True)
        scorer = cls(
            k=int(data["k"][0]),
            sigma=float(data["sigma"][0]),
            nn_metric=str(data["nn_metric"][0]),
        )
        scorer.fit(data["hist_bank"], data["resp_bank"])
        scorer._sigma = float(data["sigma"][0])  # use saved sigma, not recomputed
        return scorer

    # ------------------------------------------------------------------
    # Properties + internals
    # ------------------------------------------------------------------

    @property
    def sigma_(self) -> float:
        """The fitted RBF bandwidth."""
        self._check_fitted()
        return self._sigma

    @property
    def n_bank(self) -> int:
        """Number of (history, response) pairs in the acceptance bank."""
        self._check_fitted()
        return len(self._resp_bank)

    def _neighbors(self, hist_query: np.ndarray) -> np.ndarray:
        q = hist_query[None, :] if hist_query.ndim == 1 else hist_query
        _, idx = self._nn.kneighbors(q.astype(np.float32))
        return idx[0]

    def _check_fitted(self) -> None:
        if not self._fitted:
            raise RuntimeError("Call .fit(hist_embeddings, resp_embeddings) first.")

    def __repr__(self) -> str:
        status = f"fitted, n_bank={self.n_bank}, sigma={self._sigma:.4f}" if self._fitted else "not fitted"
        return f"ManifoldScorer(k={self.k}, metric={self.nn_metric!r}, {status})"


# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# K selection (fully unsupervised)
# ---------------------------------------------------------------------------

def tune_k(
    hist_bank: np.ndarray,
    resp_bank: np.ndarray,
    k_values: list[int] | None = None,
    sigma: float | None = None,
    nn_metric: str = "cosine",
    n_probe: int = 200,
    seed: int = 0,
    verbose: bool = True,
) -> dict:
    """
    Find a good k using only your unlabeled community data.

    No labels needed — this is the fully unsupervised path.

    The heuristic: a good k produces a *stable* density surface. We measure
    this via score consistency: for each probe response in the bank, we score
    it against its own history, then score it again after slightly perturbing
    the neighborhood (by dropping a random 20% of neighbors). A stable scorer
    gives similar scores both ways; an unstable one (k too small → noisy
    neighborhood, k too large → over-smoothed) gives inconsistent scores.
    We pick the k that maximizes mean score consistency (Spearman rho between
    original and perturbed scores).

    In practice this reliably lands in the 75–200 range that the paper
    identifies as robust, but tuned to your specific community size and
    embedding geometry.

    Parameters
    ----------
    hist_bank : np.ndarray, shape (N, d)
        History embeddings from your community data.
    resp_bank : np.ndarray, shape (N, d)
        Response embeddings from your community data (same posts).
    k_values : list[int] or None
        K values to sweep. Defaults to [25, 50, 75, 100, 150, 200, 300].
    sigma : float or None
        RBF bandwidth. None → estimated once via median heuristic and held
        fixed so k is the only variable.
    nn_metric : str
        Distance metric for kNN (default "cosine").
    n_probe : int
        Number of bank examples to use as probes. 200 is plenty.
    seed : int
        Random seed for probe subsampling and perturbation.
    verbose : bool
        Print summary table if True.

    Returns
    -------
    dict with keys:
        "best_k"        : int   — most stable k
        "best_score"    : float — consistency score at best_k
        "results"       : list of {"k": int, "consistency": float}

    Example
    -------
    >>> result = tune_k(hist_bank, resp_bank)
    >>> scorer = ManifoldScorer(k=result["best_k"]).fit(hist_bank, resp_bank)
    """
    from scipy.stats import spearmanr

    if k_values is None:
        k_values = [25, 50, 75, 100, 150, 200, 300]
    k_values = [k for k in sorted(k_values) if k < len(hist_bank)]

    if sigma is None:
        sigma = median_sigma(resp_bank)

    rng = np.random.default_rng(seed)
    probe_idx = rng.choice(len(hist_bank), size=min(n_probe, len(hist_bank)), replace=False)
    h_probe = hist_bank[probe_idx]
    r_probe = resp_bank[probe_idx]

    results = []
    for k in k_values:
        scorer = ManifoldScorer(k=k, sigma=sigma, nn_metric=nn_metric)
        scorer.fit(hist_bank, resp_bank)

        # Original scores
        base_scores = np.array([scorer.score(h_probe[i], r_probe[i]) for i in range(len(probe_idx))])

        # Perturbed scores: re-score after randomly masking 20% of each neighborhood
        perturbed_scores = []
        for i in range(len(probe_idx)):
            nb_idx = scorer._neighbors(h_probe[i])
            keep = rng.choice(len(nb_idx), size=max(1, int(0.8 * len(nb_idx))), replace=False)
            neighborhood = scorer._resp_bank[nb_idx[keep]]
            K = rbf_kernel(neighborhood, r_probe[i], scorer._sigma)
            perturbed_scores.append(float(np.log(np.mean(K) + 1e-12)))

        perturbed_scores = np.array(perturbed_scores)

        rho, _ = spearmanr(base_scores, perturbed_scores)
        results.append({"k": k, "consistency": float(rho)})

    best = max(results, key=lambda r: r["consistency"])

    if verbose:
        print(f"{'k':>6}  {'consistency (rho)':>18}")
        print("-" * 26)
        for r in results:
            marker = " ←" if r["k"] == best["k"] else ""
            print(f"{r['k']:>6}  {r['consistency']:>18.3f}{marker}")
        print(f"\nBest k={best['k']}  consistency={best['consistency']:.3f}")

    return {"best_k": best["k"], "best_score": best["consistency"], "results": results}
