"""Startup-only warnings and fail-closed guards for plugin app initialization."""

from __future__ import annotations

import importlib
import warnings
from functools import cache
from ipaddress import ip_address
from typing import TYPE_CHECKING, Any, cast
from urllib.parse import urlsplit

from litestar_auth._plugin.config import (
    _build_oauth_route_registration_contract,
    _describe_jwt_revocation_tradeoff,
    _uses_bundled_database_token_models,
)
from litestar_auth._plugin.middleware import get_cookie_transports
from litestar_auth._plugin.rate_limit import iter_rate_limit_endpoints
from litestar_auth.authentication.strategy.jwt import InMemoryJWTDenylistStore
from litestar_auth.exceptions import ConfigurationError
from litestar_auth.totp import InMemoryUsedTotpCodeStore, SecurityWarning

if TYPE_CHECKING:
    from litestar.config.app import AppConfig

    from litestar_auth._plugin.config import LitestarAuthConfig, OAuthConfig


@cache
def _load_bundled_token_orm_models() -> tuple[object, object]:
    """Load the canonical bundled DB-token ORM classes exactly once per process.

    Returns:
        The bundled access-token and refresh-token ORM classes.
    """
    models_module = importlib.import_module("litestar_auth.models")
    return cast("Any", models_module).import_token_orm_models()


def bootstrap_bundled_token_orm_models(config: LitestarAuthConfig[Any, Any]) -> None:
    """Load bundled token ORM models during plugin app init when runtime uses them."""
    if _uses_bundled_database_token_models(config):
        _load_bundled_token_orm_models()


def warn_insecure_plugin_startup_defaults(config: LitestarAuthConfig[Any, Any]) -> None:
    """Emit ``SecurityWarning`` for insecure production defaults.

    Suppressed when ``config.unsafe_testing`` is true. Call from
    ``LitestarAuth.on_app_init()`` before guards that may raise.
    """
    if config.unsafe_testing:
        return

    contract = _build_oauth_route_registration_contract(
        auth_path=config.auth_path,
        oauth_config=config.oauth_config,
    )
    oauth_config = config.oauth_config
    if oauth_config is not None and contract.has_configured_providers and not oauth_config.oauth_token_encryption_key:
        warnings.warn(
            "OAuth providers are configured but oauth_token_encryption_key is not set; "
            "OAuth access and refresh tokens may be stored in plaintext at rest. "
            "Configure a Fernet key via oauth_token_encryption_key for production.",
            SecurityWarning,
            stacklevel=2,
        )

    for backend in config.startup_backends():
        strategy = getattr(backend, "strategy", None)
        notice = _describe_jwt_revocation_tradeoff(getattr(strategy, "revocation_posture", None))
        warning_message = None if notice is None else notice.startup_warning
        if isinstance(warning_message, str):
            warnings.warn(
                warning_message,
                SecurityWarning,
                stacklevel=2,
            )
            break

    if _has_inmemory_rate_limit_backend(config):
        warnings.warn(
            "Auth rate limiting is configured with a process-local in-memory backend. "
            "Rate-limit state will not be shared across workers in multi-worker deployments. "
            "Use a Redis-backed rate limiter to enforce consistent limits across processes.",
            SecurityWarning,
            stacklevel=2,
        )

    totp_config = config.totp_config
    if totp_config is not None and isinstance(totp_config.totp_used_tokens_store, InMemoryUsedTotpCodeStore):
        warnings.warn(
            "TOTP replay protection uses InMemoryUsedTotpCodeStore; used-code state is not "
            "shared across workers. Use RedisUsedTotpCodeStore for production multi-worker deployments.",
            SecurityWarning,
            stacklevel=2,
        )
    if totp_config is not None and isinstance(totp_config.totp_pending_jti_store, InMemoryJWTDenylistStore):
        warnings.warn(
            "TOTP pending-token replay protection uses InMemoryJWTDenylistStore; pending JTI state is not "
            "shared across workers. Use RedisJWTDenylistStore for production multi-worker deployments.",
            SecurityWarning,
            stacklevel=2,
        )
    _warn_refresh_cookie_max_age_mismatch(config)


def require_oauth_token_encryption_for_configured_providers(
    *,
    config: LitestarAuthConfig[Any, Any],
    require_key: object,
) -> None:
    """Fail closed when configured OAuth providers would persist plaintext tokens."""
    contract = _build_oauth_route_registration_contract(
        auth_path=config.auth_path,
        oauth_config=config.oauth_config,
    )
    if not contract.has_configured_providers:
        return
    cast("Any", require_key)(context="OAuth providers are configured")


def has_configured_oauth_providers(config: LitestarAuthConfig[Any, Any]) -> bool:
    """Return whether this plugin config includes any OAuth provider integration."""
    return _build_oauth_route_registration_contract(
        auth_path=config.auth_path,
        oauth_config=config.oauth_config,
    ).has_configured_providers


def has_configured_oauth_providers_for(oauth_config: OAuthConfig) -> bool:
    """Return whether this OAuth config includes any provider integration."""
    return bool(oauth_config.oauth_providers)


def require_secure_oauth_redirect_in_production(
    *,
    config: LitestarAuthConfig[Any, Any],
    app_config: AppConfig,
) -> None:
    """Fail closed when plugin-owned OAuth redirects use insecure production origins.

    Raises:
        ConfigurationError: If plugin-owned OAuth routes use a non-HTTPS, loopback,
            or malformed redirect origin outside explicit debug or testing escape hatches.
    """
    if config.unsafe_testing or getattr(app_config, "debug", False):
        return

    contract = _build_oauth_route_registration_contract(
        auth_path=config.auth_path,
        oauth_config=config.oauth_config,
    )
    if not contract.has_plugin_owned_login_routes:
        return
    redirect_base_url = contract.redirect_base_url
    if redirect_base_url is None:  # pragma: no cover - validation guarantees this when providers exist
        return

    parsed_redirect_base_url = urlsplit(redirect_base_url)
    if parsed_redirect_base_url.scheme.lower() != "https":
        msg = (
            "Plugin-managed OAuth routes require oauth_redirect_base_url to use a public HTTPS origin in production. "
            f"Received {redirect_base_url!r}. Use AppConfig(debug=True) or unsafe_testing=True only for explicit "
            "local-development and test recipes."
        )
        raise ConfigurationError(msg)

    host = parsed_redirect_base_url.hostname
    if host is None or _is_loopback_host(host):
        msg = (
            "Plugin-managed OAuth routes require oauth_redirect_base_url to use a non-loopback public HTTPS origin "
            f"in production. Received {redirect_base_url!r}. Use AppConfig(debug=True) or unsafe_testing=True only "
            "for explicit local-development and test recipes."
        )
        raise ConfigurationError(msg)
    if (
        parsed_redirect_base_url.username is not None
        or parsed_redirect_base_url.password is not None
        or parsed_redirect_base_url.query
        or parsed_redirect_base_url.fragment
    ):
        msg = (
            "Plugin-managed OAuth routes require oauth_redirect_base_url to be a clean HTTPS callback base without "
            "userinfo, query, or fragment components in production. "
            f"Received {redirect_base_url!r}. Use AppConfig(debug=True) or unsafe_testing=True only for explicit "
            "local-development and test recipes."
        )
        raise ConfigurationError(msg)


def _is_loopback_host(host: str) -> bool:
    """Return whether ``host`` is a localhost or loopback IP literal."""
    if host == "localhost":
        return True
    try:
        return ip_address(host).is_loopback
    except ValueError:
        return False


def _has_inmemory_rate_limit_backend(config: LitestarAuthConfig[Any, Any]) -> bool:
    """Return whether any endpoint uses a process-local rate-limit backend."""
    rate_limit_config = config.rate_limit_config
    if rate_limit_config is None:
        return False
    for endpoint_limit in iter_rate_limit_endpoints(cast("Any", rate_limit_config)):
        if endpoint_limit is None:
            continue
        if not endpoint_limit.backend.is_shared_across_workers:
            return True
    return False


def _warn_refresh_cookie_max_age_mismatch(config: LitestarAuthConfig[Any, Any]) -> None:
    """Warn when a CookieTransport will silently inherit ``max_age`` for the refresh cookie.

    When ``enable_refresh`` is true and a ``CookieTransport`` has ``refresh_max_age is None``,
    the refresh cookie inherits the access-token ``max_age`` - which is typically much shorter
    than the strategy's refresh lifetime. The browser will delete the refresh cookie before it
    expires server-side, causing silent refresh failures.
    """
    if not config.enable_refresh:
        return

    cookie_transports = get_cookie_transports(config.startup_backends())
    for transport in cookie_transports:
        if transport.refresh_max_age is None:
            warnings.warn(
                "CookieTransport refresh_max_age is not set while enable_refresh=True. "
                "The refresh cookie will inherit the access-token max_age, which is typically "
                "much shorter than the strategy's refresh lifetime. Set refresh_max_age explicitly "
                "on CookieTransport to match your strategy's refresh token TTL.",
                SecurityWarning,
                stacklevel=3,
            )
            break
