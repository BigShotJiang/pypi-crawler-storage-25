import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import os
from ..logging_config import get_logger
logger = get_logger(__name__)

matplotlib.use("Agg")  # Для работы без графического интерфейса (на серверах)

categories = ["Department", "Culture", "Medium", "Classification", "Country"]
path = "data/MetObjects.csv"
results = "results/"

# ------------ чтение и обработка
def read_csv(path, chunk_size=10000):
    """Читает большой CSV-файл по частям (chunks), чтобы экономить память."""
    chunks = pd.read_csv(path, chunksize=chunk_size, low_memory=False)
    for chunk in chunks:
        yield chunk

def filtered_data(chunks):
    """Оставляем только Department и Object Begin Date."""
    for data in chunks:
        dept_col = None
        date_col = None

        for name in data.columns:
            if 'Department' in name:
                dept_col = name
            if 'Object Begin Date' in name:
                date_col = name

        if dept_col is None or date_col is None:
            continue

        yield data[[dept_col, date_col]].copy()

def clean_data(chunks):
    """Переименовываем колонки и очищаем даты."""
    for data in chunks:
        data.columns = ['Department', 'Date']
        data['Date'] = pd.to_numeric(data['Date'], errors='coerce') #errors='coerce' всё, что не число, превращается в NaN.
        data = data.dropna(subset=['Date'])
        data['Date'] = data['Date'].astype(int)
        yield data

# ------------ статистики
def calculate_statistics(chunks):
    """
    Вычисляет статистику по отделам: средний год, стандартное отклонение,
    доверительный интервал и размах.
    """
    dates_storage = pd.DataFrame(columns=["Department", "Date"])  # собираем все даты для построения графика временного ряда
    final_dept = None #будет хранить итоговую статистику по отделам df

    for data in chunks:
        data = data.copy()
        data["Date_Sq"] = data["Date"] ** 2

        # Собираем все даты для последующего анализа временного ряда
        temp_dates = data[["Department", "Date"]].copy()
        dates_storage = pd.concat([dates_storage, temp_dates], ignore_index=True)

        # Агрегация статистики по отделам
        group_stats = data.groupby("Department").agg(
            sum_date=("Date", "sum"),
            sum_sq=("Date_Sq", "sum"),
            count=("Date", "size")
        ) #df

        if final_dept is None:
            final_dept = group_stats
        else:
            final_dept = final_dept.add(group_stats, fill_value=0)

    # финальные метрики
    final_dept["mean"] = final_dept["sum_date"] / final_dept["count"]
    numerator = final_dept["sum_sq"] - (final_dept["sum_date"] ** 2 / final_dept["count"])
    final_dept["std"] = np.sqrt(numerator / (final_dept["count"] - 1))

    final_dept["ci_95"] = 1.96 * (final_dept["std"] / np.sqrt(final_dept["count"]))
    final_dept["spread_95"] = 1.96 * final_dept["std"]

    return final_dept, dates_storage


def get_max_spread_department(stats, dates_storage):
    """Находит отдел с самым большим стандартным отклонением (наибольшим разбросом дат)."""
    if stats.empty or dates_storage.empty:
        return None, pd.Series(dtype=int)

    target_dept = stats["std"].idxmax()
    dept_dates = dates_storage[dates_storage["Department"] == target_dept]["Date"] #Series дат для выбранного отдела

    dates = dept_dates.sort_values().reset_index(drop=True)
    return target_dept, dates


# ----------- графики

def draw_department_chart(stats, save_path):
    """Столбчатая диаграмма со средними годами и интервалами доверия."""
    plt.figure(figsize=(16, 9))
    bars = plt.bar(
        stats.index,
        stats["mean"],
        color="#2E86C1",
        alpha=0.85,
        edgecolor="white",
        linewidth=1.2,
        label="Средний год создания"
    )

    # Доверительный интервал
    plt.errorbar(
        stats.index,
        stats["mean"],
        yerr=stats["ci_95"],
        fmt="none",
        ecolor="#E74C3C",
        elinewidth=2.5,
        capsize=6,
        capthick=2,
        label="95% доверительный интервал"
    )

    # Размах (±1.96σ)
    for i, (_, row) in enumerate(stats.iterrows()):
        low = row["mean"] - row["spread_95"]
        high = row["mean"] + row["spread_95"]
        plt.hlines(
            [low, high],
            i - 0.35,
            i + 0.35,
            colors="#27AE60",
            linewidth=2.8,
            linestyles='--',
            label="±1.96σ (размах)" if i == 0 else ""
        )

    plt.xticks(rotation=45, ha="right", fontsize=11)
    plt.yticks(fontsize=11)
    plt.ylabel("Год создания", fontsize=13, labelpad=10)
    plt.title("Статистика по отделам Метрополитен-музея\n(средний год и разброс)")

    # Сетка
    plt.grid(axis='y', alpha=0.3, linestyle='--')

    # Легенда
    plt.legend(
        loc='upper right',
        fontsize=11,
        frameon=True,
        facecolor='white',
        edgecolor='gray'
    )

    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()

def draw_timeline(dates, dept_name, save_path):
    """Временной ряд количества объектов по годам с скользящим средним."""
    dates = pd.to_numeric(dates, errors='coerce').dropna()
    if dates.empty:
        return

    dates = dates[(dates >= 500) & (dates <= 2025)]
    if dates.empty:
        return

    counts = dates.value_counts().sort_index()
    window = max(5, len(counts) // 20)
    rolling = counts.rolling(window=window, center=True).mean()

    plt.figure(figsize=(12, 6))
    plt.plot(counts.index, counts.values, alpha=0.6, linewidth=1, label="Количество объектов")
    plt.plot(rolling.index, rolling.values, "r-", linewidth=2.5,
             label=f"Скользящее среднее (окно {window})")

    plt.xlabel("Год")
    plt.ylabel("Количество объектов")
    plt.title(f"{dept_name} — распределение объектов по годам")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


# ------------ Gini, Shannon, ENC
def read_csv_with_categories(path, chunk_size=10000):
    """Читает только категориальные колонки для анализа разнообразия."""
    reader = pd.read_csv(path, usecols=categories, chunksize=chunk_size)
    for part in reader:
        yield part.copy()

def sum_counts(chunks):
    """Подсчитывает частоту встречаемости значений в категориальных полях."""
    combined = None
    for part in chunks:
        current = None
        for field in categories:
            freq = part[field].value_counts().to_frame(name=field)
            current = freq if current is None else current.join(freq, how="outer")
        current = current.fillna(0)

        """
        .value_counts() возвращает Series (индекс, значения — частоты)
        .to_frame(name=field) превращает в DataFrame 
        """

        combined = current if combined is None else combined.add(current, fill_value=0)

    return combined.fillna(0) if combined is not None else pd.DataFrame()

def compute_metrics(total_counts):
    """Вычисляет коэффициенты разнообразия: Gini, Shannon, Effective Number of Categories."""
    output = pd.DataFrame(index=categories, columns=["gini", "shannon", "enc"])

    for field in categories:
        values = total_counts[field].dropna()
        values = values[values > 0]
        if values.shape[0] == 0:
            output.loc[field] = [np.nan, np.nan, np.nan]
            continue

        probs = values / values.sum()
        gini = 1 - (probs * probs).sum()
        shannon = -(probs * np.log(probs)).sum()
        enc = np.exp(shannon)

        output.loc[field] = [gini, shannon, enc]

    return output

def draw_heatmap(metrics_raw):
    """Тепловая карта нормализованных метрик разнообразия."""
    df = metrics_raw.copy()
    df.columns = ["Gini", "Shannon", "ENC"]
    df = df.apply(pd.to_numeric, errors="coerce")

    if df.shape[0] == 0 or df.isna().all().all():
        return

    # Нормализация
    for col in df.columns:
        max_val = df[col].max()
        if max_val != 0:
            df[col] = df[col] / max_val

    plt.figure(figsize=(8, 5))
    plt.imshow(df.values, aspect="auto", cmap="Reds", vmin=0, vmax=1)

    plt.xticks(range(len(df.columns)), df.columns)
    plt.yticks(range(len(df.index)), df.index)

    for i in range(df.shape[0]):
        for j in range(df.shape[1]):
            val = df.iloc[i, j]
            if pd.notna(val):
                plt.text(j, i, f"{val:.3f}", ha="center", va="center", color="black", fontsize=10)

    plt.colorbar(label="Нормализованное значение")
    plt.title("Разнообразие коллекции Метрополитен-музея")
    plt.tight_layout()
    plt.savefig(f"{results}3_heatmap.png", dpi=300, bbox_inches="tight")
    plt.close()


# ------------- main
def main():
    os.makedirs(results, exist_ok=True)

    # --- Чтение и очистка ---
    logger.info("1. Чтение и обработка данных...")
    raw_stream = read_csv(path)
    filtered_stream = filtered_data(raw_stream)
    clean_stream = clean_data(filtered_stream)

    # --- Статистика по отделам ---
    logger.info("2. Расчёт статистики по отделам...")
    stats, dates_storage = calculate_statistics(clean_stream)

    logger.info(f"   Проанализировано отделов: {len(stats)}")
    logger.info("\nПервые строки статистики:")
    #logger.info(stats.head())

    # --- Визуализация ---
    logger.info("3. Построение графиков...")
    draw_department_chart(stats, f"{results}1_departments_stats.png")
    logger.info(f"Сохранён: 1_departments_stats.png")

    target_dept, timeline_data = get_max_spread_department(stats, dates_storage)
    logger.info(f"Отдел с наибольшим разбросом дат: {target_dept}")
    draw_timeline(timeline_data, target_dept, f"{results}2_timeline.png")
    logger.info(f"Сохранён: 2_timeline.png")

    # --- Анализ разнообразия ---
    logger.info("4. Анализ разнообразия коллекции...")
    metrics_stream = read_csv_with_categories(path)
    total_counts = sum_counts(metrics_stream)
    metrics_results = compute_metrics(total_counts)

    draw_heatmap(metrics_results)
    logger.info(f"Сохранён: 3_heatmap.png")

    logger.info(f"Все результаты сохранены в папке: ./{results}")


if __name__ == "__main__":
    main()