from ch00_py.file_toolbox import create_path
from ch17_brick.brick_config import get_brick_config_dict
from ch18_etl_config.etl_config import (
    ALL_DIMEN_ABBV2,
    ALL_DIMEN_ABBV7,
    create_prime_table_sqlstr,
    create_prime_tablename,
    etl_brick_category_config_dict,
    etl_brick_category_config_path,
    etl_stage_types_config_path,
    get_all_dimen_columns_set,
    get_del_dimen_columns_set,
    get_dimen_abbv2,
    get_dimen_abbv7,
    get_etl_category_stages_dict,
    get_etl_stage_types_config_dict,
    get_ordered_stage_types,
    get_prime_columns,
    get_stage_abbv5,
    get_stages_order_general,
    remove_inx_columns,
    remove_otx_columns,
    remove_staging_columns,
)
from ch99_glossary.ch_keyword import Ch18Keywords as kw


def test_remove_otx_columns_ReturnsObj():
    # ESTABLISH / WHEN / THEN
    assert remove_otx_columns({"fizz", "buzz"}) == {"fizz", "buzz"}
    assert remove_otx_columns({"fizz", "buzz_otx"}) == {"fizz"}
    assert remove_otx_columns({"fizz_otx", "otx_buzz"}) == {"otx_buzz"}


def test_remove_inx_columns_ReturnsObj():
    # ESTABLISH / WHEN / THEN
    assert remove_inx_columns({"fizz", "buzz"}) == {"fizz", "buzz"}
    assert remove_inx_columns({"fizz", "buzz_inx"}) == {"fizz"}
    assert remove_inx_columns({"fizz_inx", "inx_buzz"}) == {"inx_buzz"}


def test_remove_staging_columns_ReturnsObj():
    # ESTABLISH / WHEN / THEN
    assert remove_staging_columns({"fizz", "buzz"}) == {"fizz", "buzz"}
    assert remove_staging_columns({"fizz", "inx_epoch_diff"}) == {"fizz"}
    assert remove_staging_columns({"context_plan_close", "inx_buzz"}) == {"inx_buzz"}


def test_ALL_DIMEN_ABBV7_has_all_dimens():
    # ESTABLISH
    brick_config_keys = set(get_brick_config_dict().keys())
    brick_config_keys.add("translate_core")

    # WHEN / THEN
    assert len(ALL_DIMEN_ABBV7) == len(brick_config_keys)


def test_get_dimen_abbv7_HasAll_dimens():
    # ESTABLISH / WHEN / THEN
    for brick_dimen in get_brick_config_dict().keys():
        assert get_dimen_abbv7(brick_dimen) in ALL_DIMEN_ABBV7


def test_get_dimen_abbv2_HasAll_dimens():
    # ESTABLISH / WHEN
    gen_abbv2_set = ALL_DIMEN_ABBV2

    # THEN
    expected_abbv2_set = set()
    brick_config_keys = set(get_brick_config_dict().keys())
    brick_config_keys.add("translate_core")
    for brick_dimen in brick_config_keys:
        abbv2 = get_dimen_abbv2(brick_dimen)
        print(f"{abbv2=}")
        assert abbv2
        expected_abbv2_set.add(abbv2)
        assert abbv2 in gen_abbv2_set

    assert gen_abbv2_set == expected_abbv2_set
    assert len(gen_abbv2_set) == len(ALL_DIMEN_ABBV7)


def test_get_stages_order_general_ReturnsObj():
    # ESTABLISH / WHEN
    stages_order_general = get_stages_order_general()
    # THEN
    assert stages_order_general
    assert stages_order_general == [
        kw.brixk_raw,
        kw.brixk_agg,
        kw.sound_raw,
        kw.sound_agg,
        kw.sound_vld,
        kw.heard_raw,
        kw.heard_agg,
        kw.heard_vld,
    ]


def test_get_stage_abbv5_ReturnsObj():
    # ESTABLISH / WHEN / THEN
    assert get_stage_abbv5(kw.brixk_raw) == kw.brixk_raw
    assert get_stage_abbv5(kw.brixk_agg) == kw.brixk_agg
    assert get_stage_abbv5(kw.sound_raw) == kw.s_raw
    assert get_stage_abbv5(kw.sound_agg) == kw.s_agg
    assert get_stage_abbv5(kw.sound_vld) == kw.s_vld
    assert get_stage_abbv5(kw.heard_raw) == kw.h_raw
    assert get_stage_abbv5(kw.heard_agg) == kw.h_agg
    assert get_stage_abbv5(kw.heard_vld) == kw.h_vld


def test_create_prime_tablename_ReturnsObj_Scenario0_ExpectedReturns():
    # ESTABLISH
    put_str = "put"
    del_str = "del"

    # WHEN
    prnunit_s_agg_table = create_prime_tablename(kw.prnunit, kw.s_agg, put_str)
    prncont_s_agg_table = create_prime_tablename(kw.prncont, kw.s_agg, put_str)
    prnmemb_s_agg_table = create_prime_tablename(kw.prnmemb, kw.s_agg, put_str)
    prnplan_s_agg_table = create_prime_tablename(kw.prnplan, kw.s_agg, put_str)
    prnawar_s_agg_table = create_prime_tablename(kw.prnawar, kw.s_agg, put_str)
    prnreas_s_agg_table = create_prime_tablename(kw.prnreas, kw.s_agg, put_str)
    prncase_s_agg_table = create_prime_tablename(kw.prncase, kw.s_agg, put_str)
    prnlabo_s_agg_table = create_prime_tablename(kw.prnlabo, kw.s_agg, put_str)
    prnheal_s_agg_table = create_prime_tablename(kw.prnheal, kw.s_agg, put_str)
    prnfact_s_agg_table = create_prime_tablename(kw.prnfact, kw.s_agg, put_str)
    prnfact_s_del_table = create_prime_tablename(kw.prnfact, kw.s_agg, del_str)
    mmtunit_s_agg_table = create_prime_tablename(kw.mmtunit, kw.s_agg)
    mmtpayy_s_agg_table = create_prime_tablename(kw.mmtpayy, kw.s_agg)
    mmtbudd_s_agg_table = create_prime_tablename(kw.mmtbudd, kw.s_agg)
    mmthour_s_agg_table = create_prime_tablename(kw.mmthour, kw.s_agg)
    mmtmont_s_agg_table = create_prime_tablename(kw.mmtmont, kw.s_agg)
    mmtweek_s_agg_table = create_prime_tablename(kw.mmtweek, kw.s_agg)
    mmtoffi_s_agg_table = create_prime_tablename(kw.mmtoffi, kw.s_agg)
    nabtime_s_agg_table = create_prime_tablename(kw.nabtime, kw.s_agg)
    trlname_s_agg_table = create_prime_tablename(kw.trlname, kw.s_agg)
    trllabe_s_agg_table = create_prime_tablename(kw.trllabe, kw.s_agg)
    trlrope_s_agg_table = create_prime_tablename(kw.trlrope, kw.s_agg)
    trltitl_s_agg_table = create_prime_tablename(kw.trltitl, kw.s_agg)
    trltitl_h_vld_table = create_prime_tablename(kw.trltitl, kw.h_vld)
    trltitl_s_raw_table = create_prime_tablename(kw.trltitl, kw.s_raw)
    trltitl_s_val_table = create_prime_tablename(kw.trltitl, kw.s_vld)
    trlcore_s_raw_table = create_prime_tablename(kw.trlcore, kw.s_raw)
    trlcore_s_agg_table = create_prime_tablename(kw.trlcore, kw.s_agg)
    prncont_job_table = create_prime_tablename(kw.prncont, kw.job, None)
    prngrou_job_table = create_prime_tablename(kw.prngrou, kw.job, None)

    # THEN
    assert prnunit_s_agg_table == f"{kw.personunit}_put_{kw.s_agg}"
    assert prncont_s_agg_table == f"{kw.person_contactunit}_put_{kw.s_agg}"
    assert prnmemb_s_agg_table == f"{kw.person_contact_membership}_put_{kw.s_agg}"
    assert prnplan_s_agg_table == f"{kw.person_planunit}_put_{kw.s_agg}"
    assert prnawar_s_agg_table == f"{kw.person_plan_awardunit}_put_{kw.s_agg}"
    assert prnreas_s_agg_table == f"{kw.person_plan_reasonunit}_put_{kw.s_agg}"
    assert prncase_s_agg_table == f"{kw.person_plan_reason_caseunit}_put_{kw.s_agg}"
    assert prnlabo_s_agg_table == f"{kw.person_plan_laborunit}_put_{kw.s_agg}"
    assert prnheal_s_agg_table == f"{kw.person_plan_healerunit}_put_{kw.s_agg}"
    assert prnfact_s_agg_table == f"{kw.person_plan_factunit}_put_{kw.s_agg}"
    assert prnfact_s_del_table == f"{kw.person_plan_factunit}_del_{kw.s_agg}"
    assert mmtunit_s_agg_table == f"{kw.momentunit}_{kw.s_agg}"
    assert mmtpayy_s_agg_table == f"{kw.moment_paybook}_{kw.s_agg}"
    assert mmtbudd_s_agg_table == f"{kw.moment_budunit}_{kw.s_agg}"
    assert mmthour_s_agg_table == f"{kw.moment_epoch_hour}_{kw.s_agg}"
    assert mmtmont_s_agg_table == f"{kw.moment_epoch_month}_{kw.s_agg}"
    assert mmtweek_s_agg_table == f"{kw.moment_epoch_weekday}_{kw.s_agg}"
    assert mmtoffi_s_agg_table == f"{kw.moment_timeoffi}_{kw.s_agg}"
    assert nabtime_s_agg_table == f"{kw.nabu_timenum}_{kw.s_agg}"
    assert trlname_s_agg_table == f"{kw.translate_name}_{kw.s_agg}"
    assert trllabe_s_agg_table == f"{kw.translate_label}_{kw.s_agg}"
    assert trlrope_s_agg_table == f"{kw.translate_rope}_{kw.s_agg}"
    assert trltitl_s_agg_table == f"{kw.translate_title}_{kw.s_agg}"
    assert trltitl_h_vld_table == f"{kw.translate_title}_{kw.h_vld}"
    assert trltitl_s_raw_table == f"{kw.translate_title}_{kw.s_raw}"
    assert trltitl_s_val_table == f"{kw.translate_title}_{kw.s_vld}"
    assert trlcore_s_raw_table == f"{kw.translate_core}_{kw.s_raw}"
    assert trlcore_s_agg_table == f"{kw.translate_core}_{kw.s_agg}"
    assert prncont_job_table == f"{kw.person_contactunit}_job"
    assert prngrou_job_table == f"{kw.person_groupunit}_job"


def test_get_all_dimen_columns_set_ReturnsObj_Scenario0_brick_config_Dimens():
    # ESTABLISH
    for x_dimen in get_brick_config_dict().keys():
        # WHEN
        dimen_columns = get_all_dimen_columns_set(x_dimen)

        # THEN
        dimen_brick_config = get_brick_config_dict().get(x_dimen)
        expected_columns = set(dimen_brick_config.get(kw.jkeys).keys())
        expected_columns.update(set(dimen_brick_config.get(kw.jvalues).keys()))
        assert dimen_columns == expected_columns


def test_get_all_dimen_columns_set_ReturnsObj_Scenario1_translate_core_Dimens():
    # ESTABLISH / WHEN
    translate_core_columns = get_all_dimen_columns_set(kw.translate_core)

    # THEN
    expected_columns = {kw.spark_face, kw.otx_knot, kw.inx_knot, kw.unknown_str}
    assert translate_core_columns == expected_columns


def test_etl_stage_types_config_path_ReturnsObj():
    # ESTABLISH
    chapter_dir = create_path("src", "ch18_etl_config")
    # WHEN / THEN
    assert etl_stage_types_config_path() == create_path(
        chapter_dir, "etl_stage_types_config.json"
    )


def test_get_etl_stage_types_config_dict_ReturnsObj_Scenario0_IsFullyPopulated():
    # ESTABLISH / WHEN
    etl_stage_types_config = get_etl_stage_types_config_dict()

    # THEN
    assert etl_stage_types_config
    etl_stage_types = set(etl_stage_types_config.keys())
    assert etl_stage_types == {
        kw.h_agg,
        kw.h_raw,
        kw.h_vld,
        kw.s_agg,
        kw.s_raw,
        kw.s_vld,
        kw.b_agg,
        kw.b_raw,
        kw.k_vld,
        kw.i_src,
        kw.i_dst,
        kw.b_src,
        kw.lego,
    }
    expected_abbv9_stage_types = {
        kw.heard_agg,
        kw.heard_raw,
        kw.heard_vld,
        kw.sound_agg,
        kw.sound_raw,
        kw.sound_vld,
        kw.brixk_agg,
        kw.brixk_raw,
        kw.brixk_vld,
        kw.ideax_dst,
        kw.ideax_src,
        kw.brixk_src,
        kw.legox_mst,
    }
    track_stage_type_orders = {}
    for stage_type, stage_type_dict in etl_stage_types_config.items():
        type_dict_keys = set(stage_type_dict.keys())
        assert "description" in type_dict_keys
        description_str = stage_type_dict.get("description")
        assert description_str, stage_type

        assert "abbv9" in type_dict_keys
        assert "stage_type_order" in type_dict_keys
        abbv9_str = stage_type_dict.get("abbv9")
        general_order_int = stage_type_dict.get("stage_type_order")
        assert abbv9_str in expected_abbv9_stage_types
        print(abbv9_str)
        assert len(abbv9_str) == 9
        assert abbv9_str[5:6] == "_"
        assert general_order_int > 0, stage_type
        track_stage_type_orders[general_order_int] = stage_type
        print(f"{stage_type=} {type_dict_keys=}")

    assert len(track_stage_type_orders) == len(etl_stage_types_config)


def test_get_ordered_stage_types_ReturnsObj():
    # ESTABLISH / WHEN
    ordered_stage_types = get_ordered_stage_types()
    # THEN
    assert ordered_stage_types
    print(ordered_stage_types)
    expected_ordered_stage_types = [
        kw.i_src,
        kw.b_src,
        kw.b_raw,
        kw.b_agg,
        kw.k_vld,
        kw.s_raw,
        kw.s_agg,
        kw.s_vld,
        kw.h_raw,
        kw.h_agg,
        kw.h_vld,
        kw.lego,
        kw.i_dst,
    ]
    print(expected_ordered_stage_types)
    assert ordered_stage_types == expected_ordered_stage_types


def test_etl_brick_category_config_path_ReturnsObj():
    # ESTABLISH / WHEN / THEN
    chapter_dir = create_path("src", "ch18_etl_config")
    assert etl_brick_category_config_path() == create_path(
        chapter_dir, "etl_brick_category_config.json"
    )


def test_get_etl_brick_category_config_dict_ReturnsObj_Scenario0_IsFullyPopulated():
    # ESTABLISH / WHEN
    etl_brick_category_config = etl_brick_category_config_dict()

    # THEN
    assert etl_brick_category_config
    etl_brick_category_config_dimens = set(etl_brick_category_config.keys())
    assert kw.moment in etl_brick_category_config_dimens
    assert kw.translate_core in etl_brick_category_config_dimens
    assert kw.translate in etl_brick_category_config_dimens
    assert kw.person in etl_brick_category_config_dimens
    assert kw.nabu in etl_brick_category_config_dimens
    assert len(etl_brick_category_config_dimens) == 5

    etl_stage_types = set(get_etl_stage_types_config_dict().keys())
    for brick_category, cat_dict in etl_brick_category_config.items():
        for stage_type, stage_dict in cat_dict.get("stages").items():
            assert stage_type in etl_stage_types
            print(f"{stage_type=}")


def test_get_etl_category_stages_dict_ReturnsObj():
    # sourcery skip: no-conditionals-in-tests
    # ESTABLISH / WHEN
    etl_category_stages_dict = get_etl_category_stages_dict()

    # THEN
    expected_dict = {}
    expected_count = 0
    etl_brick_category_config = etl_brick_category_config_dict()
    for brick_category, dimen_dict in etl_brick_category_config.items():
        for stage_type, stages_dict in dimen_dict.get("stages").items():
            expected_count += 1
            if set(stages_dict.keys()) == {"del", "put"}:
                stage_key_put = f"{brick_category}_{stage_type}_put"
                stage_key_del = f"{brick_category}_{stage_type}_del"
                # print(f"{expected_count} {stage_key_put=}")
                expected_count += 1
                expected_dict[stage_key_put] = {
                    kw.brick_category: brick_category,
                    "stage_type": stage_type,
                    "put_del": "put",
                }
                expected_dict[stage_key_del] = {
                    kw.brick_category: brick_category,
                    "stage_type": stage_type,
                    "put_del": "del",
                }
                # print(f"{expected_count} {stage_key_del=}")
            else:
                stage_key = f"{brick_category}_{stage_type}"
                expected_dict[stage_key] = {
                    kw.brick_category: brick_category,
                    "stage_type": stage_type,
                }
                # print(f"{expected_count} {stage_key=} ")
    # print(expected_dict)
    assert etl_category_stages_dict == expected_dict


def test_get_prime_columns_ReturnsObj_Scenario0_EmptyKeylist():
    # ESTABLISH
    x_dimen = kw.momentunit

    # WHEN / THEN
    assert get_prime_columns(x_dimen, [], None) == set()


def test_get_prime_columns_ReturnsObj_Scenario1_EmptyConfig():
    # ESTABLISH
    x_dimen = kw.momentunit
    table_keylist = [kw.h_agg]

    # WHEN / THEN
    assert get_prime_columns(x_dimen, table_keylist, {}) == set()


def test_get_prime_columns_ReturnsObj_Scenario2_moment_epoch_month():
    # ESTABLISH
    x_dimen = kw.moment_epoch_month
    table_keylist = [kw.h_agg]
    config_dict = get_brick_config_dict()

    # WHEN
    mmtunit_h_agg_columns = get_prime_columns(x_dimen, table_keylist, config_dict)

    # THEN
    print(f"{mmtunit_h_agg_columns}")
    assert mmtunit_h_agg_columns == {
        kw.spark_num,
        kw.moment_rope,
        kw.month_label,
        kw.spark_face,
        kw.cumulative_day,
        kw.knot,
    }


def test_get_prime_columns_ReturnsObj_Scenario3_h_raw_set_translateable_otx_inx_args():
    # ESTABLISH
    x_dimen = kw.moment_epoch_month
    table_keylist = [kw.h_raw]
    config_dict = etl_brick_category_config_dict()

    # WHEN
    mmtepoc_h_raw_columns = get_prime_columns(x_dimen, table_keylist, config_dict)

    # THEN
    print(f"{mmtepoc_h_raw_columns}")
    assert mmtepoc_h_raw_columns == {
        kw.spark_num,
        f"{kw.moment_rope}_otx",
        f"{kw.moment_rope}_inx",
        f"{kw.month_label}_otx",
        f"{kw.month_label}_inx",
        f"{kw.spark_face}_otx",
        f"{kw.spark_face}_inx",
        kw.cumulative_day,
        kw.error_message,
        kw.knot,
    }


def test_get_prime_columns_ReturnsObj_Scenario4_h_agg_set_nabuable_otx_inx_args():
    # ESTABLISH
    x_dimen = kw.moment_timeoffi
    table_keylist = [kw.h_agg]
    config_dict = etl_brick_category_config_dict()

    # WHEN
    mmtoffi_h_agg_columns = get_prime_columns(x_dimen, table_keylist, config_dict)

    # THEN
    print(f"{mmtoffi_h_agg_columns=}")
    assert mmtoffi_h_agg_columns == {
        kw.spark_face,
        kw.moment_rope,
        f"{kw.offi_time}_otx",
        f"{kw.offi_time}_inx",
        kw.spark_num,
        kw.knot,
    }


def test_get_prime_columns_ReturnsObj_Scenario5_h_agg_set_nabuable_otx_inx_args_ContextNabuableArgs():
    # ESTABLISH
    x_dimen = kw.person_plan_reason_caseunit
    table_keylist = [kw.h_agg, "put"]
    config_dict = etl_brick_category_config_dict()

    # WHEN
    prncase_h_agg_columns = get_prime_columns(x_dimen, table_keylist, config_dict)

    # THEN
    print(f"{prncase_h_agg_columns=}")
    assert prncase_h_agg_columns
    expected_added_columns = {
        f"context_plan_{kw.close}",
        f"context_plan_{kw.denom}",
        f"context_plan_{kw.morph}",
        kw.inx_epoch_diff,
    }
    assert expected_added_columns.issubset(prncase_h_agg_columns)
    assert prncase_h_agg_columns == {
        kw.person_name,
        f"context_plan_{kw.close}",
        f"context_plan_{kw.denom}",
        f"context_plan_{kw.morph}",
        kw.spark_face,
        kw.inx_epoch_diff,
        kw.plan_rope,
        kw.reason_context,
        kw.reason_state,
        kw.reason_divisor,
        f"{kw.reason_lower}_otx",
        f"{kw.reason_lower}_inx",
        f"{kw.reason_upper}_otx",
        f"{kw.reason_upper}_inx",
        kw.spark_num,
        kw.knot,
    }


def test_get_del_dimen_columns_set_ReturnsObj_Scenario0() -> list[str]:
    # ESTABLISH / WHEN
    del_dimen_columns_set = get_del_dimen_columns_set(kw.person_plan_laborunit)

    # THEN
    assert del_dimen_columns_set
    assert del_dimen_columns_set == {
        kw.plan_rope,
        kw.spark_num,
        kw.person_name,
        kw.spark_face,
        f"{kw.labor_title}_ERASE",
    }


def test_create_prime_table_sqlstr_ReturnsObj_Scenario0_CaseUnit():
    # ESTABLISH / WHEN
    table_sqlstr = create_prime_table_sqlstr(
        kw.person_plan_reason_caseunit, kw.s_raw, "put"
    )

    # THEN
    assert table_sqlstr
    print(table_sqlstr)
    expected_sqlstr = "CREATE TABLE IF NOT EXISTS person_plan_reason_caseunit_put_s_raw (brick_type TEXT, spark_num INTEGER, spark_face TEXT, person_name TEXT, plan_rope TEXT, reason_context TEXT, reason_state TEXT, reason_lower REAL, reason_upper REAL, reason_divisor INTEGER, knot TEXT, error_message TEXT)"
    assert table_sqlstr == expected_sqlstr
