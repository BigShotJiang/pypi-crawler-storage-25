import time

_MAX_SPIN_FRAC = 0.1  # spin at most 10% of total duration


def _calibrate_spin_tail(samples: int = 100) -> float:
    """Measure ``time.sleep`` overshoot on this system and return a spin tail
    that covers p99 jitter with a 2x safety margin, clamped to [100 µs, 2 ms].
    """
    overshoots: list[float] = []
    for _ in range(samples):
        target = 0.0005
        start = time.monotonic()
        time.sleep(target)
        overshoots.append(time.monotonic() - start - target)
    overshoots.sort()
    p99 = overshoots[int(len(overshoots) * 0.99)]
    return max(0.0001, min(p99 * 2, 0.002))


_SPIN_TAIL_S: float = _calibrate_spin_tail()


def precise_sleep(
    seconds: float = 0,
    milliseconds: float = 0,
    microseconds: float = 0,
) -> None:
    """High-precision hybrid sleep with auto-calibrated spin tail.

    At import time the module measures ``time.sleep`` jitter on the current
    system and picks a spin tail that covers p99 overshoot.  The tail is
    further capped at 10 % of the requested duration so that CPU usage
    stays bounded (~5 %) regardless of how short the sleep is.

    Parameters are additive.  At least one must be positive.

    Parameters
    ----------
    seconds : float
        Duration in seconds.
    milliseconds : float
        Duration in milliseconds.
    microseconds : float
        Duration in microseconds.
    """
    total = seconds + milliseconds / 1_000 + microseconds / 1_000_000
    if total <= 0:
        raise ValueError(
            "wait() requires a positive duration – "
            "provide at least one of seconds, milliseconds, or microseconds"
        )
    deadline = time.monotonic() + total
    tail = min(_SPIN_TAIL_S, total * _MAX_SPIN_FRAC)
    bulk = total - tail
    if bulk > 0:
        time.sleep(bulk)
    while time.monotonic() < deadline:
        pass
