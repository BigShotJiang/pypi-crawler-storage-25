from __future__ import annotations

from importlib import import_module
from typing import Any, Mapping

import nexuslog as logging
from walrasquant.constants import settings


use_nautilius = settings.get("USE_NAUTILIUS", False)

if use_nautilius:
    try:
        component = import_module("nautilus_trader.common.component")
        identifiers = import_module("nautilus_trader.model.identifiers")
        uuid_mod = import_module("nautilus_trader.core.uuid")
        nautilus_pyo3 = import_module("nautilus_trader.core.nautilus_pyo3")

        MessageBus = component.MessageBus
        LiveClock = component.LiveClock
        TimeEvent = component.TimeEvent
        TraderId = identifiers.TraderId
        UUID4 = uuid_mod.UUID4
        HttpClient = nautilus_pyo3.HttpClient
        HttpMethod = nautilus_pyo3.HttpMethod
        HttpResponse = nautilus_pyo3.HttpResponse
        WebSocketClient = nautilus_pyo3.WebSocketClient
        WebSocketClientError = nautilus_pyo3.WebSocketClientError
        WebSocketConfig = nautilus_pyo3.WebSocketConfig
        hmac_signature = nautilus_pyo3.hmac_signature
        rsa_signature = nautilus_pyo3.rsa_signature
        ed25519_signature = nautilus_pyo3.ed25519_signature
    except ImportError as e:
        raise ImportError(
            "Nautilus Trader is not installed. Please install run `pip install nautilus-trader` to use Nautilus features."
        ) from e
else:
    from nexuscore import (
        MessageBus,
        LiveClock,
        TimeEvent,
        TraderId,
        UUID4,
        hmac_signature,
        rsa_signature,
        ed25519_signature,
    )


def setup_nexus_core(
    trader_id: str,
    filename: str | None = None,
    level: str = "INFO",
    name_levels: Mapping[str | None, str] | None = None,
    unix_ts: bool = False,
    batch_size: int | None = None,
) -> tuple[Any, Any]:
    """
    Setup logging for the application using nexuslog and initialize MessageBus and Clock.

    Args:
        trader_id: Unique identifier for the trader
        filename: Optional file path for log output. If None, logs to stdout.
        level: Minimum log level to record (TRACE, DEBUG, INFO, WARNING, ERROR)
        unix_ts: If True, emit unix timestamps instead of formatted local time.

    Returns:
        tuple: (msgbus, clock) - MessageBus and LiveClock instances
    """
    clock = LiveClock()
    msgbus = MessageBus(
        trader_id=TraderId(trader_id),
        clock=clock,
    )

    # Map log levels from string to nexuslog levels
    level_map = {
        "TRACE": logging.TRACE,
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
    }

    log_level = level_map.get(level, logging.INFO)

    _name_levels = None
    if name_levels:
        _name_levels = {
            name: level_map.get(lvl_str, logging.INFO)
            for name, lvl_str in name_levels.items()
        }

    # Configure nexuslog using basicConfig
    logging.basicConfig(
        filename=filename,
        level=log_level,
        name_levels=_name_levels,
        unix_ts=unix_ts,
        batch_size=batch_size,
    )

    return msgbus, clock
