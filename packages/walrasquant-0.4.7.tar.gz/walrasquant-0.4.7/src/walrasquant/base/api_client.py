from abc import ABC
import aiohttp
import nexuslog as logging
from typing import Optional, Any, Dict
from walrasquant.core.nautilius_core import LiveClock
from walrasquant.constants import RateLimiter
from walrasquant.base.retry import RetryManager


class ApiClient(ABC):
    def __init__(
        self,
        clock: LiveClock,
        api_key: Optional[str] = None,
        secret: Optional[str] = None,
        timeout: int = 10,
        rate_limiter: Optional[RateLimiter] = None,
        retry_manager: Optional[RetryManager] = None,
    ):
        self._api_key = api_key
        self._secret = secret
        self._timeout = timeout
        self._log = logging.getLogger(name=type(self).__name__)
        self._session: Optional[aiohttp.ClientSession] = None
        self._clock = clock
        self._limiter = rate_limiter
        self._retry_manager: Optional[RetryManager] = retry_manager
        self._base_url: str | None = None

    async def _init_session(self, base_url: str | None = None):
        if self._session is None:
            kwargs: Dict[str, Any] = {
                "timeout": aiohttp.ClientTimeout(total=self._timeout),
            }
            if base_url:
                kwargs["base_url"] = base_url
            self._session = aiohttp.ClientSession(**kwargs)

    def _get_rate_limit_cost(self, cost: int = 1):
        return cost

    async def close_session(self):
        """Close the session"""
        if self._session:
            await self._session.close()
            self._session = None
