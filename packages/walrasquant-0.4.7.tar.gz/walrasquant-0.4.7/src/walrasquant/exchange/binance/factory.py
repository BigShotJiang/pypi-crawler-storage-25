"""
Binance exchange factory implementation.
"""

from typing import cast

from walrasquant.constants import ExchangeType, AccountType, ConfigType
from walrasquant.config import (
    PublicConnectorConfig,
    PrivateConnectorConfig,
    BasicConfig,
)
from walrasquant.exchange.base_factory import ExchangeFactory, BuildContext
from walrasquant.base import (
    ExchangeManager,
    PublicConnector,
    PrivateConnector,
    ExecutionManagementSystem,
)

from walrasquant.exchange.binance.exchange import BinanceExchangeManager
from walrasquant.exchange.binance.constants import BinanceAccountType
from walrasquant.exchange.binance.connector import (
    BinancePublicConnector,
    BinancePrivateConnector,
)
from walrasquant.exchange.binance.ems import BinanceExecutionManagementSystem
from walrasquant.exchange.binance.schema import BinanceMarket


class BinanceFactory(ExchangeFactory):
    """Factory for creating Binance exchange components."""

    @property
    def exchange_type(self) -> ExchangeType:
        return ExchangeType.BINANCE

    def create_manager(self, basic_config: BasicConfig) -> ExchangeManager:
        """Create BinanceExchangeManager."""
        ccxt_config: ConfigType = {
            "apiKey": basic_config.api_key or "",
            "secret": basic_config.secret or "",
            "exchange_id": "binance",
            "sandbox": basic_config.testnet,
        }
        if basic_config.passphrase:
            ccxt_config["password"] = basic_config.passphrase

        return BinanceExchangeManager(ccxt_config)

    def create_public_connector(
        self,
        config: PublicConnectorConfig,
        exchange: ExchangeManager,
        context: BuildContext,
    ) -> PublicConnector:
        """Create BinancePublicConnector."""
        if not isinstance(config.account_type, BinanceAccountType):
            raise TypeError("Binance public connector requires BinanceAccountType")
        return BinancePublicConnector(
            account_type=config.account_type,
            exchange=cast(BinanceExchangeManager, exchange),
            msgbus=context.msgbus,
            clock=context.clock,
            task_manager=context.task_manager,
            enable_rate_limit=config.enable_rate_limit,
            custom_url=config.custom_url,
            max_subscriptions_per_client=config.max_subscriptions_per_client,
            max_clients=config.max_clients,
        )

    def create_private_connector(
        self,
        config: PrivateConnectorConfig,
        exchange: ExchangeManager,
        context: BuildContext,
        account_type: AccountType | None = None,
    ) -> PrivateConnector:
        """Create BinancePrivateConnector."""
        # Use provided account_type or fall back to config
        final_account_type = account_type or config.account_type
        if not isinstance(final_account_type, BinanceAccountType):
            raise TypeError("Binance private connector requires BinanceAccountType")

        return BinancePrivateConnector(
            exchange=cast(BinanceExchangeManager, exchange),
            account_type=final_account_type,
            cache=context.cache,
            clock=context.clock,
            msgbus=context.msgbus,
            registry=context.registry,
            enable_rate_limit=config.enable_rate_limit,
            task_manager=context.task_manager,
            max_retries=config.max_retries,
            delay_initial_ms=config.delay_initial_ms,
            delay_max_ms=config.delay_max_ms,
            backoff_factor=config.backoff_factor,
            max_subscriptions_per_client=config.max_subscriptions_per_client,
            max_clients=config.max_clients,
        )

    def create_ems(
        self, exchange: ExchangeManager, context: BuildContext
    ) -> ExecutionManagementSystem:
        """Create BinanceExecutionManagementSystem."""
        return BinanceExecutionManagementSystem(
            market=cast(dict[str, BinanceMarket], exchange.market),
            cache=context.cache,
            msgbus=context.msgbus,
            clock=context.clock,
            task_manager=context.task_manager,
            registry=context.registry,
            queue_maxsize=context.queue_maxsize,
        )
