from decimal import Decimal
from typing import Dict, cast
from walrasquant.constants import AccountType
from walrasquant.schema import InstrumentId, BaseMarket
from walrasquant.core.cache import AsyncCache
from walrasquant.core.nautilius_core import MessageBus, LiveClock
from walrasquant.core.entity import TaskManager
from walrasquant.core.registry import OrderRegistry
from walrasquant.exchange.binance import BinanceAccountType
from walrasquant.exchange.binance.schema import BinanceMarket
from walrasquant.base import ExecutionManagementSystem
from walrasquant.base.ems import PriorityOrderQueue


class BinanceExecutionManagementSystem(ExecutionManagementSystem):
    _market: Dict[str, BinanceMarket]
    _BATCH_CHUNK_SIZE = 5

    BINANCE_SPOT_PRIORITY = [
        BinanceAccountType.ISOLATED_MARGIN,
        BinanceAccountType.MARGIN,
        BinanceAccountType.SPOT_TESTNET,
        BinanceAccountType.SPOT,
    ]

    def __init__(
        self,
        market: Dict[str, BinanceMarket],
        cache: AsyncCache,
        msgbus: MessageBus,
        clock: LiveClock,
        task_manager: TaskManager,
        registry: OrderRegistry,
        queue_maxsize: int = 100_000,
    ):
        super().__init__(
            market=market,
            cache=cache,
            msgbus=msgbus,
            clock=clock,
            task_manager=task_manager,
            registry=registry,
            queue_maxsize=queue_maxsize,
        )
        self._binance_spot_account_type: BinanceAccountType | None = None
        self._binance_linear_account_type: BinanceAccountType | None = None
        self._binance_inverse_account_type: BinanceAccountType | None = None
        self._binance_pm_account_type: BinanceAccountType | None = None

    def _set_account_type(self):
        account_types = self._private_connectors.keys()

        if BinanceAccountType.PORTFOLIO_MARGIN in account_types:
            self._binance_pm_account_type = BinanceAccountType.PORTFOLIO_MARGIN
            return

        for account_type in self.BINANCE_SPOT_PRIORITY:
            if account_type in account_types:
                self._binance_spot_account_type = account_type
                break

        self._binance_linear_account_type = (
            BinanceAccountType.USD_M_FUTURE_TESTNET
            if BinanceAccountType.USD_M_FUTURE_TESTNET in account_types
            else BinanceAccountType.USD_M_FUTURE
        )

        self._binance_inverse_account_type = (
            BinanceAccountType.COIN_M_FUTURE_TESTNET
            if BinanceAccountType.COIN_M_FUTURE_TESTNET in account_types
            else BinanceAccountType.COIN_M_FUTURE
        )

    def _instrument_id_to_account_type(
        self, instrument_id: InstrumentId
    ) -> AccountType:
        if self._binance_pm_account_type:
            return self._binance_pm_account_type

        if instrument_id.is_spot:
            account_type = self._binance_spot_account_type
        elif instrument_id.is_linear:
            account_type = self._binance_linear_account_type
        elif instrument_id.is_inverse:
            account_type = self._binance_inverse_account_type
        else:
            raise ValueError(f"Unsupported instrument type: {instrument_id.type}")

        if account_type is None:
            raise ValueError(f"No Binance account type configured for {instrument_id}")
        return account_type

    def _build_order_submit_queues(self):
        for account_type in self._private_connectors.keys():
            if isinstance(account_type, BinanceAccountType):
                self._order_submit_queues[account_type] = PriorityOrderQueue(
                    maxsize=self._queue_maxsize
                )

    def _get_min_order_amount(
        self, symbol: str, market: BaseMarket, px: float
    ) -> Decimal:
        binance_market = cast(BinanceMarket, market)
        # book = self._cache.bookl1(symbol)
        cost_limits = binance_market.limits.cost
        amount_limits = binance_market.limits.amount
        cost_min = cost_limits.min if cost_limits is not None else 0.0
        amount_min = amount_limits.min if amount_limits is not None else 0.0
        cost_min = cost_min or 0.0
        amount_min = amount_min or 0.0

        min_order_amount = max(cost_min * 1.01 / px, amount_min)
        min_order_amount = self._amount_to_precision(
            symbol, min_order_amount, mode="ceil"
        )
        return min_order_amount
