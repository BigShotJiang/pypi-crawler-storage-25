"""
Bybit exchange factory implementation.
"""

from typing import cast

from walrasquant.constants import ExchangeType, AccountType, ConfigType
from walrasquant.config import (
    PublicConnectorConfig,
    PrivateConnectorConfig,
    BasicConfig,
)
from walrasquant.exchange.base_factory import ExchangeFactory, BuildContext
from walrasquant.base import (
    ExchangeManager,
    PublicConnector,
    PrivateConnector,
    ExecutionManagementSystem,
)

from walrasquant.exchange.bybit.exchange import BybitExchangeManager
from walrasquant.exchange.bybit.connector import (
    BybitPublicConnector,
    BybitPrivateConnector,
)
from walrasquant.exchange.bybit.ems import BybitExecutionManagementSystem
from walrasquant.exchange.bybit.constants import BybitAccountType
from walrasquant.exchange.bybit.schema import BybitMarket


class BybitFactory(ExchangeFactory):
    """Factory for creating Bybit exchange components."""

    @property
    def exchange_type(self) -> ExchangeType:
        return ExchangeType.BYBIT

    def create_manager(self, basic_config: BasicConfig) -> ExchangeManager:
        """Create BybitExchangeManager."""
        ccxt_config: ConfigType = {
            "apiKey": basic_config.api_key or "",
            "secret": basic_config.secret or "",
            "exchange_id": "bybit",
            "sandbox": basic_config.testnet,
        }
        if basic_config.passphrase:
            ccxt_config["password"] = basic_config.passphrase

        return BybitExchangeManager(ccxt_config)

    def create_public_connector(
        self,
        config: PublicConnectorConfig,
        exchange: ExchangeManager,
        context: BuildContext,
    ) -> PublicConnector:
        """Create BybitPublicConnector."""
        if not isinstance(config.account_type, BybitAccountType):
            raise TypeError("Bybit public connector requires BybitAccountType")
        return BybitPublicConnector(
            account_type=config.account_type,
            exchange=cast(BybitExchangeManager, exchange),
            msgbus=context.msgbus,
            clock=context.clock,
            task_manager=context.task_manager,
            enable_rate_limit=config.enable_rate_limit,
            custom_url=config.custom_url,
            max_subscriptions_per_client=config.max_subscriptions_per_client,
            max_clients=config.max_clients,
        )

    def create_private_connector(
        self,
        config: PrivateConnectorConfig,
        exchange: ExchangeManager,
        context: BuildContext,
        account_type: AccountType | None = None,
    ) -> PrivateConnector:
        """Create BybitPrivateConnector."""
        # Use provided account_type or determine from exchange testnet status
        if account_type:
            final_account_type = account_type
        else:
            final_account_type = self.get_private_account_type(exchange, config)

        if not isinstance(final_account_type, BybitAccountType):
            raise TypeError("Bybit private connector requires BybitAccountType")
        return BybitPrivateConnector(
            exchange=cast(BybitExchangeManager, exchange),
            account_type=final_account_type,
            cache=context.cache,
            clock=context.clock,
            msgbus=context.msgbus,
            registry=context.registry,
            enable_rate_limit=config.enable_rate_limit,
            task_manager=context.task_manager,
            max_retries=config.max_retries,
            delay_initial_ms=config.delay_initial_ms,
            delay_max_ms=config.delay_max_ms,
            backoff_factor=config.backoff_factor,
            max_subscriptions_per_client=config.max_subscriptions_per_client,
            max_clients=config.max_clients,
        )

    def create_ems(
        self, exchange: ExchangeManager, context: BuildContext
    ) -> ExecutionManagementSystem:
        """Create BybitExecutionManagementSystem."""
        return BybitExecutionManagementSystem(
            market=cast(dict[str, BybitMarket], exchange.market),
            cache=context.cache,
            msgbus=context.msgbus,
            clock=context.clock,
            task_manager=context.task_manager,
            registry=context.registry,
            queue_maxsize=context.queue_maxsize,
        )

    def get_private_account_type(
        self, exchange: ExchangeManager, config: PrivateConnectorConfig
    ) -> AccountType:
        """Determine account type based on testnet status."""
        return (
            BybitAccountType.UNIFIED_TESTNET
            if exchange.is_testnet
            else BybitAccountType.UNIFIED
        )
