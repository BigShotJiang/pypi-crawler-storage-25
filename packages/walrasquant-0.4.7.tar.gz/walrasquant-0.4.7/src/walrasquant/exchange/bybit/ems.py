from typing import Dict, cast
from decimal import Decimal
from walrasquant.constants import AccountType
from walrasquant.schema import InstrumentId, BaseMarket
from walrasquant.core.cache import AsyncCache
from walrasquant.core.nautilius_core import MessageBus, LiveClock
from walrasquant.core.entity import TaskManager
from walrasquant.core.registry import OrderRegistry
from walrasquant.exchange.bybit import BybitAccountType
from walrasquant.exchange.bybit.schema import BybitMarket
from walrasquant.base import ExecutionManagementSystem
from walrasquant.base.ems import PriorityOrderQueue


class BybitExecutionManagementSystem(ExecutionManagementSystem):
    _market: Dict[str, BybitMarket]

    def __init__(
        self,
        market: Dict[str, BybitMarket],
        cache: AsyncCache,
        msgbus: MessageBus,
        clock: LiveClock,
        task_manager: TaskManager,
        registry: OrderRegistry,
        queue_maxsize: int = 100_000,
    ):
        super().__init__(
            market=market,
            cache=cache,
            msgbus=msgbus,
            clock=clock,
            task_manager=task_manager,
            registry=registry,
            queue_maxsize=queue_maxsize,
        )
        self._bybit_account_type: BybitAccountType | None = None

    def _build_order_submit_queues(self):
        # if not self._private_connectors:
        #     raise RuntimeError(
        #         "No private connectors found for building order submit queues."
        #     )
        for account_type in self._private_connectors.keys():
            if isinstance(account_type, BybitAccountType):
                self._order_submit_queues[account_type] = PriorityOrderQueue(
                    maxsize=self._queue_maxsize
                )

    def _set_account_type(self):
        # if not self._private_connectors:
        #     raise RuntimeError(
        #         "No private connectors found for setting account type."
        #     )
        account_types = self._private_connectors.keys()
        self._bybit_account_type = (
            BybitAccountType.UNIFIED_TESTNET
            if BybitAccountType.UNIFIED_TESTNET in account_types
            else BybitAccountType.UNIFIED
        )

    def _instrument_id_to_account_type(
        self, instrument_id: InstrumentId
    ) -> AccountType:
        if self._bybit_account_type is None:
            raise ValueError("No Bybit account type configured")
        return self._bybit_account_type

    def _get_min_order_amount(
        self, symbol: str, market: BaseMarket, px: float
    ) -> Decimal:
        bybit_market = cast(BybitMarket, market)
        lot_size_filter = bybit_market.info.lotSizeFilter
        if lot_size_filter is None:
            raise ValueError(f"Missing lotSizeFilter for {symbol}")
        min_order_qty = float(lot_size_filter.minOrderQty or "0")
        min_order_amt = float(
            lot_size_filter.minOrderAmt or lot_size_filter.minNotionalValue or "0"
        )
        min_order_amount = max(min_order_amt * 1.02 / px, min_order_qty)
        min_order_amount = self._amount_to_precision(
            symbol, min_order_amount, mode="ceil"
        )
        return min_order_amount
