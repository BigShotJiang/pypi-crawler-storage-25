from typing import Dict, cast
from decimal import Decimal
from typing import Literal
from decimal import ROUND_HALF_UP, ROUND_CEILING, ROUND_FLOOR

from walrasquant.constants import AccountType
from walrasquant.schema import (
    InstrumentId,
    CancelAllOrderSubmit,
    CancelOrderSubmit,
    BaseMarket,
)
from walrasquant.core.cache import AsyncCache
from walrasquant.core.nautilius_core import MessageBus, LiveClock
from walrasquant.core.entity import TaskManager
from walrasquant.core.registry import OrderRegistry
from walrasquant.exchange.bitget import BitgetAccountType
from walrasquant.exchange.bitget.schema import BitgetMarket
from walrasquant.base import ExecutionManagementSystem
from walrasquant.base.ems import PriorityOrderQueue


class BitgetExecutionManagementSystem(ExecutionManagementSystem):
    _market: Dict[str, BitgetMarket]

    def __init__(
        self,
        market: Dict[str, BitgetMarket],
        cache: AsyncCache,
        msgbus: MessageBus,
        clock: LiveClock,
        task_manager: TaskManager,
        registry: OrderRegistry,
        queue_maxsize: int = 100_000,
    ):
        super().__init__(
            market=market,
            cache=cache,
            msgbus=msgbus,
            clock=clock,
            task_manager=task_manager,
            registry=registry,
            queue_maxsize=queue_maxsize,
        )

        self._bitget_futures_account_type: BitgetAccountType | None = None
        self._bitget_spot_account_type: BitgetAccountType | None = None
        self._bitget_uta_account_type: BitgetAccountType | None = None

    def _build_order_submit_queues(self):
        for account_type in self._private_connectors.keys():
            if isinstance(account_type, BitgetAccountType):
                self._order_submit_queues[account_type] = PriorityOrderQueue(
                    maxsize=self._queue_maxsize
                )

    def _set_account_type(self):
        account_types = self._private_connectors.keys()

        if (
            BitgetAccountType.UTA_DEMO in account_types
            or BitgetAccountType.UTA in account_types
        ):
            self._bitget_uta_account_type = (
                BitgetAccountType.UTA_DEMO
                if BitgetAccountType.UTA_DEMO in account_types
                else BitgetAccountType.UTA
            )
            return

        self._bitget_futures_account_type = (
            BitgetAccountType.FUTURE_DEMO
            if BitgetAccountType.FUTURE_DEMO in account_types
            else BitgetAccountType.FUTURE
        )

        self._bitget_spot_account_type = (
            BitgetAccountType.SPOT_DEMO
            if BitgetAccountType.SPOT_DEMO in account_types
            else BitgetAccountType.SPOT
        )

    def _instrument_id_to_account_type(
        self, instrument_id: InstrumentId
    ) -> AccountType:
        if self._bitget_uta_account_type:
            return self._bitget_uta_account_type
        if instrument_id.is_spot:
            account_type = self._bitget_spot_account_type
        elif instrument_id.is_linear or instrument_id.is_inverse:
            account_type = self._bitget_futures_account_type
        else:
            raise ValueError(f"Unsupported instrument type: {instrument_id.type}")

        if account_type is None:
            raise ValueError(f"No Bitget account type configured for {instrument_id}")
        return account_type

    def _get_min_order_amount(
        self, symbol: str, market: BaseMarket, px: float
    ) -> Decimal:
        bitget_market = cast(BitgetMarket, market)
        if bitget_market.spot:
            min_trade_usdt = bitget_market.info.minTradeUSDT or "0"
            min_order_cost = float(min_trade_usdt)
            min_order_amount = min_order_cost * 1.01 / px
        else:
            min_trade_num = bitget_market.info.minTradeNum or "0"
            min_trade_usdt = bitget_market.info.minTradeUSDT or "0"
            min_order_amt = float(min_trade_num)
            min_order_cost = float(min_trade_usdt)
            min_order_amount = max(min_order_cost * 1.02 / px, min_order_amt)
        min_order_amount = self._amount_to_precision(
            symbol, min_order_amount, mode="ceil"
        )
        return min_order_amount

    def _amount_to_precision(
        self,
        symbol: str,
        amount: float,
        mode: Literal["round", "ceil", "floor"] = "round",
    ) -> Decimal:
        market = self._market[symbol]
        if market.spot:
            return super()._amount_to_precision(symbol, amount, mode)
        else:
            amount: Decimal = Decimal(str(amount))
            amount_multiplier = Decimal(market.info.sizeMultiplier or "1")
            multiplier_count = amount / amount_multiplier

            if mode == "round":
                amount = (
                    multiplier_count.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                ) * amount_multiplier
            elif mode == "ceil":
                amount = (
                    multiplier_count.quantize(Decimal("1"), rounding=ROUND_CEILING)
                ) * amount_multiplier
            elif mode == "floor":
                amount = (
                    multiplier_count.quantize(Decimal("1"), rounding=ROUND_FLOOR)
                ) * amount_multiplier
            return amount

    def _price_to_precision(
        self,
        symbol: str,
        price: float,
        mode: Literal["round", "ceil", "floor"] = "round",
    ) -> Decimal:
        market = self._market[symbol]
        if market.spot:
            return super()._price_to_precision(symbol, price, mode)
        else:
            price: Decimal = Decimal(str(price))
            price_multiplier = Decimal(market.info.priceEndStep or "1")
            multiplier_count = price / price_multiplier

            if mode == "round":
                price = (
                    multiplier_count.quantize(Decimal("1"), rounding=ROUND_HALF_UP)
                ) * price_multiplier
            elif mode == "ceil":
                price = (
                    multiplier_count.quantize(Decimal("1"), rounding=ROUND_CEILING)
                ) * price_multiplier
            elif mode == "floor":
                price = (
                    multiplier_count.quantize(Decimal("1"), rounding=ROUND_FLOOR)
                ) * price_multiplier
            return price

    async def _cancel_all_orders(
        self, order_submit: CancelAllOrderSubmit, account_type: AccountType
    ) -> None:
        # override the base method
        if isinstance(account_type, BitgetAccountType) and account_type.is_uta:
            await super()._cancel_all_orders(order_submit, account_type)
        else:
            symbol = order_submit.symbol
            await self._cache.wait_for_inflight_orders(symbol)
            oids = self._cache.get_open_orders(symbol)
            for oid in oids:
                cancel_submit = CancelOrderSubmit(
                    symbol=symbol,
                    instrument_id=InstrumentId.from_str(symbol),
                    oid=oid,
                )
                await self._cancel_order_ws(cancel_submit, account_type)
