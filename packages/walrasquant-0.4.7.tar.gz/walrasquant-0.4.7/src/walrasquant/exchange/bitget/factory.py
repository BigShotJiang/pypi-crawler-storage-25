"""
Bitget exchange factory implementation.
"""

from typing import cast

from walrasquant.constants import ExchangeType, AccountType, ConfigType
from walrasquant.config import (
    PublicConnectorConfig,
    PrivateConnectorConfig,
    BasicConfig,
)
from walrasquant.exchange.base_factory import ExchangeFactory, BuildContext
from walrasquant.base import (
    ExchangeManager,
    PublicConnector,
    PrivateConnector,
    ExecutionManagementSystem,
)

from walrasquant.exchange.bitget.exchange import BitgetExchangeManager
from walrasquant.exchange.bitget.constants import BitgetAccountType
from walrasquant.exchange.bitget.connector import (
    BitgetPublicConnector,
    BitgetPrivateConnector,
)
from walrasquant.exchange.bitget.ems import BitgetExecutionManagementSystem
from walrasquant.exchange.bitget.schema import BitgetMarket


class BitgetFactory(ExchangeFactory):
    """Factory for creating Bitget exchange components."""

    @property
    def exchange_type(self) -> ExchangeType:
        return ExchangeType.BITGET

    def create_manager(self, basic_config: BasicConfig) -> ExchangeManager:
        """Create BitgetExchangeManager."""
        ccxt_config: ConfigType = {
            "apiKey": basic_config.api_key or "",
            "secret": basic_config.secret or "",
            "exchange_id": "bitget",
            "sandbox": basic_config.testnet,
        }
        if basic_config.passphrase:
            ccxt_config["password"] = basic_config.passphrase

        return BitgetExchangeManager(ccxt_config)

    def create_public_connector(
        self,
        config: PublicConnectorConfig,
        exchange: ExchangeManager,
        context: BuildContext,
    ) -> PublicConnector:
        """Create BitgetPublicConnector."""
        if not isinstance(config.account_type, BitgetAccountType):
            raise TypeError("Bitget public connector requires BitgetAccountType")
        connector = BitgetPublicConnector(
            account_type=config.account_type,
            exchange=cast(BitgetExchangeManager, exchange),
            msgbus=context.msgbus,
            clock=context.clock,
            task_manager=context.task_manager,
            enable_rate_limit=config.enable_rate_limit,
            custom_url=config.custom_url,
            max_subscriptions_per_client=config.max_subscriptions_per_client,
            max_clients=config.max_clients,
        )

        # Bitget needs post-creation setup
        self.setup_public_connector(
            cast(BitgetExchangeManager, exchange), connector, config.account_type
        )
        return connector

    def create_private_connector(
        self,
        config: PrivateConnectorConfig,
        exchange: ExchangeManager,
        context: BuildContext,
        account_type: AccountType | None = None,
    ) -> PrivateConnector:
        """Create BitgetPrivateConnector."""
        # Use provided account_type or fall back to config
        final_account_type = account_type or config.account_type
        if not isinstance(final_account_type, BitgetAccountType):
            raise TypeError("Bitget private connector requires BitgetAccountType")

        return BitgetPrivateConnector(
            exchange=cast(BitgetExchangeManager, exchange),
            account_type=final_account_type,
            cache=context.cache,
            msgbus=context.msgbus,
            clock=context.clock,
            registry=context.registry,
            enable_rate_limit=config.enable_rate_limit,
            task_manager=context.task_manager,
            max_retries=config.max_retries,
            delay_initial_ms=config.delay_initial_ms,
            delay_max_ms=config.delay_max_ms,
            backoff_factor=config.backoff_factor,
            max_slippage=config.max_slippage,
            max_subscriptions_per_client=config.max_subscriptions_per_client,
            max_clients=config.max_clients,
        )

    def create_ems(
        self, exchange: ExchangeManager, context: BuildContext
    ) -> ExecutionManagementSystem:
        """Create BitgetExecutionManagementSystem."""
        return BitgetExecutionManagementSystem(
            market=cast(dict[str, BitgetMarket], exchange.market),
            cache=context.cache,
            msgbus=context.msgbus,
            clock=context.clock,
            task_manager=context.task_manager,
            registry=context.registry,
            queue_maxsize=context.queue_maxsize,
        )

    def setup_public_connector(
        self,
        exchange: ExchangeManager,
        connector: PublicConnector,
        account_type: AccountType,
    ) -> None:
        """Setup public connector account type."""
        if not isinstance(account_type, BitgetAccountType):
            raise TypeError("Bitget public connector requires BitgetAccountType")
        cast(BitgetExchangeManager, exchange).set_public_connector_account_type(
            account_type
        )
