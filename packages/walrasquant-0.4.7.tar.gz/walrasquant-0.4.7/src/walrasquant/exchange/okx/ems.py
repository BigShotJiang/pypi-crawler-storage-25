import asyncio
from decimal import Decimal
from typing import Dict, Literal, cast
from walrasquant.constants import AccountType
from walrasquant.schema import InstrumentId, BaseMarket
from walrasquant.core.cache import AsyncCache
from walrasquant.core.nautilius_core import MessageBus, LiveClock
from walrasquant.core.entity import TaskManager
from walrasquant.core.registry import OrderRegistry
from walrasquant.exchange.okx import OkxAccountType
from walrasquant.exchange.okx.schema import OkxMarket
from walrasquant.base import ExecutionManagementSystem
from walrasquant.base.ems import PriorityOrderQueue
from walrasquant.schema import CancelAllOrderSubmit, CancelOrderSubmit


class OkxExecutionManagementSystem(ExecutionManagementSystem):
    _market: Dict[str, OkxMarket]

    OKX_ACCOUNT_TYPE_PRIORITY = [
        OkxAccountType.DEMO,
        # OkxAccountType.AWS,
        OkxAccountType.LIVE,
    ]

    def __init__(
        self,
        market: Dict[str, OkxMarket],
        cache: AsyncCache,
        msgbus: MessageBus,
        clock: LiveClock,
        task_manager: TaskManager,
        registry: OrderRegistry,
        queue_maxsize: int = 100_000,
    ):
        super().__init__(
            market=market,
            cache=cache,
            msgbus=msgbus,
            clock=clock,
            task_manager=task_manager,
            registry=registry,
            queue_maxsize=queue_maxsize,
        )
        self._okx_account_type: OkxAccountType | None = None

    def _build_order_submit_queues(self):
        for account_type in self._private_connectors.keys():
            if isinstance(account_type, OkxAccountType):
                self._order_submit_queues[account_type] = PriorityOrderQueue(
                    maxsize=self._queue_maxsize
                )
                break

    def _set_account_type(self):
        account_types = self._private_connectors.keys()
        for account_type in self.OKX_ACCOUNT_TYPE_PRIORITY:
            if account_type in account_types:
                self._okx_account_type = account_type
                break

    def _instrument_id_to_account_type(
        self, instrument_id: InstrumentId
    ) -> AccountType:
        if self._okx_account_type is None:
            raise ValueError("No OKX account type configured")
        return self._okx_account_type

    def _get_min_order_amount(
        self, symbol: str, market: BaseMarket, px: float
    ) -> Decimal:
        okx_market = cast(OkxMarket, market)
        amount_limits = okx_market.limits.amount
        min_order_amount = amount_limits.min if amount_limits is not None else 0.0
        min_order_amount = min_order_amount or 0.0
        min_order_amount = super()._amount_to_precision(
            symbol, min_order_amount, mode="ceil"
        )

        if not okx_market.spot:
            # for linear and inverse, the min order amount is contract size and ctVal is base amount per contract
            min_order_amount *= Decimal(okx_market.info.ctVal or "1")

        return min_order_amount

    # override the base method
    def _amount_to_precision(
        self,
        symbol: str,
        amount: float,
        mode: Literal["round"] | Literal["ceil"] | Literal["floor"] = "round",
    ) -> Decimal:
        market = self._market[symbol]
        ctVal = Decimal("1")
        if not market.spot:
            ctVal = Decimal(market.info.ctVal or "1")
            adjusted_amount = float(Decimal(str(amount)) / ctVal)
            return super()._amount_to_precision(symbol, adjusted_amount, mode) * ctVal
        return super()._amount_to_precision(symbol, amount, mode)

    async def _cancel_all_orders(
        self, order_submit: CancelAllOrderSubmit, account_type: AccountType
    ):
        # override the base methods
        symbol = order_submit.symbol
        await self._cache.wait_for_inflight_orders(symbol)
        oids = self._cache.get_open_orders(symbol, include_canceling=True)
        if not oids:
            return
        cancel_submits = [
            CancelOrderSubmit(
                symbol=symbol,
                instrument_id=InstrumentId.from_str(symbol),
                oid=oid,
            )
            for oid in oids
        ]
        await self._cancel_batch_orders(cancel_submits, account_type)
