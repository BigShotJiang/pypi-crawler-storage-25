from typing import Dict, Set, List, Optional, Any

from walrasquant.backends.db import StorageBackend
from walrasquant.schema import Order, Position, Balance, AccountBalance
from walrasquant.constants import AccountType, ExchangeType


class MemoryBackend(StorageBackend):
    """No-op backend for testing — all state lives in AsyncCache's own dicts."""

    def __init__(self, **kwargs):
        # Accept and discard all kwargs (strategy_id, user_id, table_prefix, log, etc.)
        self._storage_initialized = False

    async def _init_conn(self) -> None:
        pass

    async def _init_table(self) -> None:
        pass

    async def close(self) -> None:
        pass

    async def sync_orders(self, mem_orders: Dict[str, Order]) -> None:
        pass

    async def sync_positions(self, mem_positions: Dict[str, Position]) -> None:
        pass

    async def sync_open_orders(
        self,
        mem_open_orders: Dict[ExchangeType, Set[str]],
        mem_orders: Dict[str, Order],
    ) -> None:
        pass

    async def sync_balances(
        self, mem_account_balance: Dict[AccountType, AccountBalance]
    ) -> None:
        pass

    async def sync_params(self, mem_params: Dict[str, Any]) -> None:
        pass

    def get_order(self, oid: str, mem_orders: Dict[str, Order]) -> Optional[Order]:
        return mem_orders.get(oid)

    def get_symbol_orders(self, symbol: str) -> Set[str]:
        return set()

    def get_all_positions(self, exchange_id: ExchangeType) -> Dict[str, Position]:
        return {}

    def get_all_balances(self, account_type: AccountType) -> List[Balance]:
        return []

    def get_param(self, key: str, default: Any = None) -> Any:
        return default

    def get_all_params(self) -> Dict[str, Any]:
        return {}
