from modelbest_robo_dataset.data_types import Episode, EnvMessage, MetaContent
from modelbest_robo_dataset.sstable_record import (
    decode_episode_record,
    deserialize_episode_record,
    serialize_episode_record,
)


def _build_episode() -> Episode:
    return Episode(
        episode_index=7,
        duration=1.5,
        messages=[
            EnvMessage(
                content=[
                    MetaContent(
                        dataset_name="dummy_ds",
                        dataset_type="simulation",
                        task="pick up block",
                        robot_type="franka",
                    )
                ]
            )
        ],
    )


def test_serialize_episode_record_roundtrip() -> None:
    episode = _build_episode()

    record = serialize_episode_record(
        episode,
        source_root="/tmp/robo",
        source_dataset_name="dummy_ds",
        source_skeleton_dir="/tmp/robo/skeleton_episode/dummy_ds",
    )
    envelope = decode_episode_record(record)

    assert envelope.episode == episode
    assert envelope.source_root == "/tmp/robo"
    assert envelope.source_dataset_name == "dummy_ds"
    assert envelope.source_skeleton_dir == "/tmp/robo/skeleton_episode/dummy_ds"


def test_deserialize_rejects_raw_json() -> None:
    """Raw Episode JSON (without Messages wrapper) must be rejected."""
    episode = _build_episode()
    raw_json = episode.model_dump_json().encode("utf-8")

    import struct
    import pytest

    with pytest.raises((struct.error, Exception)):
        deserialize_episode_record(raw_json)
