"""Smoke tests for LeRobotSource on a minimal v3 layout (droid-style tasks + fallbacks)."""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import pytest

from modelbest_robo_dataset.sources.lerobot import LeRobotSource


CAM_KEY = "observation.images.wrist"


def _write_minimal_v3_dataset(
    root: Path,
    *,
    droid_style_tasks: bool,
    include_tasks_parquet: bool,
    language_instruction: str | None = None,
) -> None:
    root.mkdir(parents=True, exist_ok=True)
    (root / "meta").mkdir(parents=True, exist_ok=True)
    (root / "meta" / "episodes" / "chunk-000").mkdir(parents=True, exist_ok=True)
    (root / "data" / "chunk-000").mkdir(parents=True, exist_ok=True)
    (root / "videos" / CAM_KEY / "chunk-000").mkdir(parents=True, exist_ok=True)

    info = {
        "codebase_version": "v3.0",
        "fps": 10.0,
        "total_episodes": 2,
        "robot_type": "stub",
        "video_path": "videos/{video_key}/chunk-{chunk_index:03d}/file-{file_index:03d}.mp4",
        "features": {
            "observation.state": {"dtype": "float32", "shape": [4]},
            "action": {"dtype": "float32", "shape": [4]},
            CAM_KEY: {"dtype": "video"},
        },
    }
    (root / "meta" / "info.json").write_text(json.dumps(info), encoding="utf-8")

    rows = []
    for ep_idx, n in enumerate((6, 5)):
        for _ in range(n):
            row = {
                "episode_index": ep_idx,
                "observation.state": [0.1, 0.2, 0.3, 0.4],
                "action": [0.01, 0.02, 0.03, 0.04],
            }
            if language_instruction is not None:
                row["language_instruction"] = language_instruction
            rows.append(row)
    pq.write_table(pa.Table.from_pandas(pd.DataFrame(rows)), root / "data" / "chunk-000" / "file-000.parquet")

    ep_meta = []
    for ep_idx in (0, 1):
        ep_meta.append(
            {
                "episode_index": ep_idx,
                "task_index": 1,
                "data/chunk_index": 0,
                "data/file_index": 0,
                f"videos/{CAM_KEY}/chunk_index": 0,
                f"videos/{CAM_KEY}/file_index": 0,
                f"videos/{CAM_KEY}/from_timestamp": 0.6 * ep_idx,
                f"videos/{CAM_KEY}/to_timestamp": 0.6 * ep_idx + (0.6 if ep_idx == 0 else 0.5),
            }
        )
    pq.write_table(
        pa.Table.from_pandas(pd.DataFrame(ep_meta)),
        root / "meta" / "episodes" / "chunk-000" / "file-000.parquet",
    )

    vid = root / "videos" / CAM_KEY / "chunk-000" / "file-000.mp4"
    vid.write_bytes(b"")

    if include_tasks_parquet:
        if droid_style_tasks:
            tdf = pd.DataFrame(
                {"task_index": [0, 1]},
                index=["task_from_index_A", "task_from_index_B"],
            )
            pq.write_table(pa.Table.from_pandas(tdf), root / "meta" / "tasks.parquet")
        else:
            tdf = pd.DataFrame({"task_index": [0, 1], "task": ["plain_A", "plain_B"]})
            pq.write_table(
                pa.Table.from_pandas(tdf, preserve_index=False),
                root / "meta" / "tasks.parquet",
            )


def test_lerobot_source_list_load_video_droid_tasks(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    root = tmp_path / "lerobot_stub"
    _write_minimal_v3_dataset(root, droid_style_tasks=True, include_tasks_parquet=True)
    decode_calls: list[tuple[str, float, float | None]] = []

    def fake_decode(self, video_path: Path, from_ts: float, to_ts: float | None):
        decode_calls.append((str(video_path), from_ts, to_ts))
        return [np.zeros((2, 3, 3), dtype=np.uint8) for _ in range(6)]

    monkeypatch.setattr(LeRobotSource, "_decode_video_range", fake_decode)

    src = LeRobotSource(
        root,
        state_type="joint_position",
        action_type="delta_joint",
        state_key="observation.state",
        action_key="action",
        camera_keys=[CAM_KEY],
        task_key="index",
    )
    assert src.list_episodes() == ["0", "1"]
    assert src.episode_frame_counts() == [6, 5]

    ep0 = src.load_episode("0")
    assert ep0.task == "task_from_index_B"
    assert ep0.video_frames
    assert any("wrist" in k for k in ep0.video_frames)
    assert decode_calls == [
        (str(root / "videos" / CAM_KEY / "chunk-000" / "file-000.mp4"), 0.0, 0.6)
    ]
    assert ep0.state is not None and ep0.state.shape == (6, 4)
    assert ep0.action is not None and ep0.action.shape == (6, 4)


def test_lerobot_source_language_instruction_fallback(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    root = tmp_path / "lerobot_li"
    _write_minimal_v3_dataset(
        root,
        droid_style_tasks=False,
        include_tasks_parquet=False,
        language_instruction="open the drawer",
    )
    monkeypatch.setattr(
        LeRobotSource,
        "_decode_video_range",
        lambda self, video_path, from_ts, to_ts: [np.zeros((2, 2, 3), dtype=np.uint8)],
    )

    src = LeRobotSource(
        root,
        state_type="joint_position",
        action_type="delta_joint",
        state_key="observation.state",
        action_key="action",
        camera_keys=[CAM_KEY],
        task_fallback_column="language_instruction",
    )
    ep0 = src.load_episode("0")
    assert ep0.task == "open the drawer"


def test_build_lerobot_sample_subset_filters_to_first_shard(tmp_path: Path) -> None:
    """Two data shards; subset script keeps only episodes present in the first shard."""
    src = tmp_path / "full_ds"
    src.mkdir(parents=True)
    (src / "meta").mkdir()
    (src / "meta" / "episodes" / "chunk-000").mkdir(parents=True)
    (src / "data" / "chunk-000").mkdir(parents=True)
    (src / "videos").mkdir()

    info = {
        "codebase_version": "v3.0",
        "fps": 5.0,
        "total_episodes": 3,
        "robot_type": "stub",
        "splits": {"train": "0:3"},
        "features": {
            "observation.state": {"dtype": "float32", "shape": [2]},
            "action": {"dtype": "float32", "shape": [2]},
        },
    }
    (src / "meta" / "info.json").write_text(json.dumps(info), encoding="utf-8")

    pq.write_table(
        pa.Table.from_pandas(pd.DataFrame({"episode_index": [0, 0, 1], "observation.state": [[0, 0]] * 3, "action": [[0, 0]] * 3})),
        src / "data" / "chunk-000" / "file-000.parquet",
    )
    pq.write_table(
        pa.Table.from_pandas(pd.DataFrame({"episode_index": [2, 2], "observation.state": [[0, 0]] * 2, "action": [[0, 0]] * 2})),
        src / "data" / "chunk-000" / "file-001.parquet",
    )

    meta_rows = [
        {"episode_index": 0, "data/chunk_index": 0, "data/file_index": 0},
        {"episode_index": 1, "data/chunk_index": 0, "data/file_index": 0},
        {"episode_index": 2, "data/chunk_index": 0, "data/file_index": 1},
    ]
    pq.write_table(pa.Table.from_pandas(pd.DataFrame(meta_rows)), src / "meta" / "episodes" / "chunk-000" / "file-000.parquet")

    out = tmp_path / "sample_out"
    script = (
        Path(__file__).resolve().parents[1]
        / "scripts"
        / "convertion"
        / "build_lerobot_sample_subset.py"
    )
    subprocess.run(
        [sys.executable, str(script), "--source", str(src), "--output", str(out), "--max-data-files", "1"],
        check=True,
    )

    subset_src = LeRobotSource(
        out,
        state_type="joint_position",
        action_type="delta_joint",
        state_key="observation.state",
        action_key="action",
    )
    assert subset_src.total_episodes == 2
    assert subset_src.list_episodes() == ["0", "1"]
