"""
SSTable record codec for robo episodes.

Canonical format:
- one SSTable row = one sdk `Messages` object (Thrift binary)
- business payload (`EpisodeSstableEnvelope`) is stored in `reserved_column`
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from modelbest_sdk.dataset.thrift_wrapper.messages import (
    Audio,
    Content,
    DocType,
    Messages,
    Metadata,
    Msg,
)

from .data_types import Episode


SSTABLE_RECORD_VERSION = "robo_episode_messages_v1"


class EpisodeSstableEnvelope(BaseModel):
    version: Literal["robo_episode_messages_v1"] = SSTABLE_RECORD_VERSION
    episode: Episode
    source_root: str = ""
    source_dataset_name: str = ""
    source_skeleton_dir: str = ""


def episode_to_messages(
    episode: Episode,
    *,
    source_root: str = "",
    source_dataset_name: str = "",
    source_skeleton_dir: str = "",
) -> Messages:
    envelope = EpisodeSstableEnvelope(
        episode=episode,
        source_root=source_root,
        source_dataset_name=source_dataset_name,
        source_skeleton_dir=source_skeleton_dir,
    )
    # Static-column style wrapper: real payload lives in reserved_column.
    msg = Msg(
        role="whole",
        content=[
            Content(
                dtype=DocType.AUDIO,
                value=Audio(wav=b"", text=None, tokens=[]),
            )
        ],
    )
    return Messages(
        messages=[msg],
        metadata=Metadata(wav_file_path=source_skeleton_dir),
        reserved_column=envelope.model_dump_json(),
    )


def serialize_episode_record(
    episode: Episode,
    *,
    source_root: str = "",
    source_dataset_name: str = "",
    source_skeleton_dir: str = "",
) -> bytes:
    return episode_to_messages(
        episode,
        source_root=source_root,
        source_dataset_name=source_dataset_name,
        source_skeleton_dir=source_skeleton_dir,
    ).serialize()


def decode_episode_record(record: bytes) -> EpisodeSstableEnvelope:
    messages = Messages.deserialize(record)
    reserved_column = messages.reserved_column
    if not reserved_column:
        raise ValueError("missing reserved_column in robo episode record")
    envelope = EpisodeSstableEnvelope.model_validate_json(reserved_column)
    if not envelope.source_skeleton_dir and messages.metadata.wav_file_path:
        envelope.source_skeleton_dir = messages.metadata.wav_file_path
    return envelope


def deserialize_episode_record(record: bytes) -> Episode:
    return decode_episode_record(record).episode
