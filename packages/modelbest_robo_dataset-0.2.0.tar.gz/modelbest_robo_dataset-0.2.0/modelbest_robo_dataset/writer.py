"""
EmbodiedWriter: RawEpisode → SSTable 骨架 + Parquet 时序表 + 视频或逐帧图像
======================================================================
输出结构:
  output_dir/
  ├── skeleton_episode/{dataset_name}/part-XXXXX  (SSTable partition)
  ├── data/{dataset_name}/{ts_name}/chunk-000/file-000.parquet
  ├── videos/{dataset_name}/{cam_name}/episode_{idx:06d}.mp4  (默认)
  │   或 episode_{idx:06d}.png (one_frame_per_episode=True)
  └── meta/{dataset_name}/info.json
"""

from __future__ import annotations

import json
import logging
import shutil
from pathlib import Path

import av
import numpy as np
import pyarrow as pa
import pyarrow.parquet as pq

from .data_types import (
    AiMessage,
    AudioContent,
    AudioRef,
    EnvMessage,
    Episode,
    MetaContent,
    TextContent,
    Timestamp,
    TimeseriesContent,
    TimeseriesRef,
    VideoContent,
    VideoRef,
)
from .sstable_record import serialize_episode_record
from .sources.base import RawEpisode
from .sstable_partition import write_mbtable_partition
from .validator import ActionValidator
from .dataset_config import (
    action_type_to_timeseries_name,
    normalize_action_type,
    normalize_state_type,
    state_type_to_timeseries_name,
)
from .norm_stats_io import compute_stats, write_norm_stats_files

logger = logging.getLogger(__name__)

PARQUET_CHUNK_SIZE = 1000

class ParquetAccumulator:
    """累积多个 episode 的 list 数据，按 chunk 写入 Parquet"""

    def __init__(self, base_dir: Path, name: str, chunk_size: int = PARQUET_CHUNK_SIZE):
        self.base_dir = base_dir / name
        self.name = name
        self.chunk_size = chunk_size
        self._buffer: list[dict] = []
        self._chunk_idx = 0
        self._file_idx = 0
        self._total_rows = 0

    def append(self, episode_index: int, data: np.ndarray | bytes, fps: float = 0.0):
        if isinstance(data, bytes):
            self._buffer.append({"episode_index": episode_index, "data": data})
        else:
            self._buffer.append({
                "episode_index": episode_index,
                "data": data.tolist(),
                "fps": fps,
            })
        self._total_rows += 1
        if len(self._buffer) >= self.chunk_size:
            self._flush()

    def _flush(self):
        if not self._buffer:
            return
        chunk_dir = self.base_dir / f"chunk-{self._chunk_idx:03d}"
        chunk_dir.mkdir(parents=True, exist_ok=True)
        path = chunk_dir / f"file-{self._file_idx:03d}.parquet"
        table = pa.Table.from_pylist(self._buffer)
        pq.write_table(table, str(path))
        logger.info(f"Wrote {len(self._buffer)} episodes to {path}")
        self._buffer.clear()
        self._file_idx += 1
        if self._file_idx >= PARQUET_CHUNK_SIZE:
            self._file_idx = 0
            self._chunk_idx += 1

    def finalize(self):
        self._flush()

    @property
    def total_rows(self) -> int:
        return self._total_rows

    @property
    def current_file_ref(self) -> str:
        return f"chunk-{self._chunk_idx:03d}/file-{self._file_idx:03d}.parquet"


class EmbodiedWriter:
    """
    通用写入器

    用法:
        writer = EmbodiedWriter(output_dir="/path/to/output", dataset_name="pusht")
        for raw_episode in source:
            writer.write_episode(raw_episode)
        writer.finalize()
    """

    def __init__(
        self,
        output_dir: str | Path,
        dataset_name: str,
        *,
        one_frame_per_episode: bool = False,
    ):
        self.output_dir = Path(output_dir)
        self.dataset_name = dataset_name
        self._one_frame_per_episode = one_frame_per_episode

        self.skeleton_dir = self.output_dir / "skeleton_episode" / dataset_name
        self.data_dir = self.output_dir / "data" / dataset_name
        self.video_dir = self.output_dir / "videos" / dataset_name
        self.meta_dir = self.output_dir / "meta" / dataset_name

        self.skeleton_dir.mkdir(parents=True, exist_ok=True)
        self.meta_dir.mkdir(parents=True, exist_ok=True)

        self._accumulators: dict[str, ParquetAccumulator] = {}
        self._skeleton_records: list[bytes] = []
        self._episode_count = 0
        self._total_frames = 0
        self._stats_accum: dict[str, list[np.ndarray]] = {}
        self._shuffle_perm: np.ndarray | None = None
        self._shuffle_pos = 0

    def set_shuffled_episode_indices(self, total_frames: int, seed: int) -> None:
        """
        在 one_frame_per_episode 模式下，为即将写入的每条帧级 episode 指定打乱的 episode_index。
        须在首次 write_episode 之前调用；各源 episode 展开后的总帧数须等于 total_frames。
        """
        if not self._one_frame_per_episode:
            raise ValueError("set_shuffled_episode_indices 仅在 one_frame_per_episode=True 时可用")
        rng = np.random.default_rng(seed)
        self._shuffle_perm = rng.permutation(total_frames).astype(np.int64, copy=False)
        self._shuffle_pos = 0

    def _get_accumulator(self, name: str) -> ParquetAccumulator:
        if name not in self._accumulators:
            self._accumulators[name] = ParquetAccumulator(self.data_dir, name)
        return self._accumulators[name]

    @staticmethod
    def _collect_observation_series(raw: RawEpisode) -> tuple[dict[str, np.ndarray], dict[str, list[str]]]:
        series = {
            name: data
            for name, data in raw.observation_series.items()
            if data is not None and getattr(data, "size", 0) > 0
        }
        dim_names = {
            name: list(names)
            for name, names in raw.observation_series_dim_names.items()
            if names
        }
        if raw.state is not None and raw.state.size > 0:
            ts_name = state_type_to_timeseries_name(raw.state_type)
            series.setdefault(ts_name, raw.state)
            if raw.state_dim_names:
                dim_names.setdefault(ts_name, list(raw.state_dim_names))
        if raw.gripper is not None and raw.gripper.size > 0:
            ts_name = "env.obs.gripper_position"
            series.setdefault(ts_name, raw.gripper)
        return series, dim_names

    @staticmethod
    def _collect_action_series(raw: RawEpisode) -> tuple[dict[str, np.ndarray], dict[str, list[str]]]:
        series = {
            name: data
            for name, data in raw.action_series.items()
            if data is not None and getattr(data, "size", 0) > 0
        }
        dim_names = {
            name: list(names)
            for name, names in raw.action_series_dim_names.items()
            if names
        }
        if raw.action is not None and raw.action.size > 0:
            ts_name = action_type_to_timeseries_name(raw.action_type)
            series.setdefault(ts_name, raw.action)
            if raw.action_dim_names:
                dim_names.setdefault(ts_name, list(raw.action_dim_names))
        return series, dim_names

    @staticmethod
    def _timeseries_duration(data: np.ndarray, fps: float, fallback: float) -> float:
        if len(data) == 0:
            return fallback
        return fallback or len(data) / max(fps, 1.0)

    def _append_timeseries(
        self,
        *,
        target_content: list,
        episode_index: int,
        timeseries_name: str,
        data: np.ndarray,
        fps: float,
        from_ts: float,
        to_ts: float,
    ) -> None:
        acc = self._get_accumulator(timeseries_name)
        acc.append(episode_index, data, fps)
        self._stats_accum.setdefault(timeseries_name, []).append(data)
        target_content.append(
            TimeseriesContent(
                name=timeseries_name,
                ref=TimeseriesRef(
                    file=f"data/{self.dataset_name}/{timeseries_name}/{acc.current_file_ref}",
                    row=acc.total_rows - 1,
                    from_ts=from_ts,
                    to_ts=to_ts,
                    fps=fps,
                ),
            )
        )

    def _consume_output_episode_index(self) -> int:
        if self._shuffle_perm is not None:
            if self._shuffle_pos >= len(self._shuffle_perm):
                raise ValueError(
                    "帧级 episode 写入条数超过了 set_shuffled_episode_indices(total_frames=...) 中的 total_frames"
                )
            out = int(self._shuffle_perm[self._shuffle_pos])
            self._shuffle_pos += 1
        else:
            out = self._episode_count
        self._episode_count += 1
        return out

    def _infer_frame_count(self, raw: RawEpisode) -> int:
        lengths: list[int] = []
        obs_series, _ = EmbodiedWriter._collect_observation_series(raw)
        act_series, _ = EmbodiedWriter._collect_action_series(raw)
        for data in obs_series.values():
            if data is not None and data.size:
                lengths.append(len(data))
        for data in act_series.values():
            if data is not None and data.size:
                lengths.append(len(data))
        for fr in raw.video_frames.values():
            if fr:
                lengths.append(len(fr))
        if (
            self._one_frame_per_episode
            and raw.video_files
            and not any(raw.video_frames.values())
        ):
            logger.warning(
                "one_frame_per_episode: episode_id=%s 仅有 video_files、无 video_frames，"
                "未逐帧解码 MP4，将仅按 state/action 长度展开（可能无图像）",
                raw.episode_id,
            )
        if not lengths:
            return 0
        m, M = min(lengths), max(lengths)
        if M != m:
            logger.warning(
                "episode_id=%s: 状态/动作/视频长度不一致 %s，按最短 %d 对齐",
                raw.episode_id,
                lengths,
                m,
            )
        return m

    def _write_episode_as_frames(self, raw: RawEpisode) -> None:
        state_type = normalize_state_type(raw.state_type)
        action_type = normalize_action_type(raw.action_type)
        observation_series, obs_dim_names = self._collect_observation_series(raw)
        action_series, act_dim_names = self._collect_action_series(raw)

        dim_names: dict[str, list[str]] = {}
        dim_names.update(obs_dim_names)
        dim_names.update(act_dim_names)

        meta = MetaContent(
            dataset_name=raw.dataset_name or self.dataset_name,
            dataset_type=raw.dataset_type,
            task=raw.task or raw.language_instruction,
            task_id=raw.task_id,
            robot_type=raw.robot_type,
            system_prompt=raw.system_prompt,
            urdf_path=raw.urdf_path,
            joint_names=raw.joint_names,
            camera_extrinsics=raw.camera_extrinsics,
            camera_intrinsics=raw.camera_intrinsics,
            dim_names=dim_names,
            quality_rating=raw.quality_rating,
            user_id=raw.user_id,
            scene_id=raw.scene_id,
            extra=raw.extra,
        )

        if raw.state is not None and raw.action is not None and action_type:
            if action_type in ActionValidator.ALL_TYPES:
                validator = ActionValidator(action_type)
                errors = validator.check(raw.state, raw.action)
                if errors:
                    for err in errors:
                        logger.error(f"Episode {raw.episode_id}: {err}")
                    raise ValueError(
                        f"Episode {raw.episode_id} 与 action_type={action_type} 不一致: "
                        + "; ".join(errors)
                    )

        t_n = self._infer_frame_count(raw)
        if t_n == 0:
            logger.warning("episode_id=%s 无可展开帧，跳过", raw.episode_id)
            return

        step_dur = 1.0 / max(raw.fps, 1.0)

        for t in range(t_n):
            ep_idx = self._consume_output_episode_index()
            env_content: list = [meta]
            ai_content: list = []

            for cam_name, frames in raw.video_frames.items():
                if not frames or t >= len(frames):
                    continue
                img_path = self._save_frame_png(cam_name, ep_idx, frames[t])
                rel_path = str(img_path.relative_to(self.output_dir))
                h, w = frames[t].shape[0], frames[t].shape[1]
                out_w, out_h = self._cap_resolution(w, h)
                env_content.append(VideoContent(ref=VideoRef(
                    file=rel_path,
                    from_ts=0.0,
                    to_ts=step_dur,
                    fps=raw.fps,
                    width=out_w,
                    height=out_h,
                )))

            for ts_name, data in observation_series.items():
                if t >= len(data):
                    continue
                row = data[t : t + 1]
                self._append_timeseries(
                    target_content=env_content,
                    episode_index=ep_idx,
                    timeseries_name=ts_name,
                    data=row,
                    fps=raw.fps,
                    from_ts=0.0,
                    to_ts=step_dur,
                )

            for ts_name, data in action_series.items():
                if t >= len(data):
                    continue
                row = data[t : t + 1]
                self._append_timeseries(
                    target_content=ai_content,
                    episode_index=ep_idx,
                    timeseries_name=ts_name,
                    data=row,
                    fps=raw.fps,
                    from_ts=0.0,
                    to_ts=step_dur,
                )

            if raw.force is not None and raw.force.size > 0 and t < len(raw.force):
                row = raw.force[t : t + 1]
                acc = self._get_accumulator("force")
                acc.append(ep_idx, row, raw.force_fps)
                env_content.append(TimeseriesContent(
                    name="env.obs.force_torque",
                    ref=TimeseriesRef(
                        file=f"data/{self.dataset_name}/force/{acc.current_file_ref}",
                        row=acc.total_rows - 1,
                        from_ts=0.0,
                        to_ts=1.0 / max(raw.force_fps, 1.0),
                        fps=raw.force_fps,
                    ),
                ))

            if raw.imu is not None and raw.imu.size > 0 and t < len(raw.imu):
                row = raw.imu[t : t + 1]
                acc = self._get_accumulator("imu")
                acc.append(ep_idx, row, raw.imu_fps)
                env_content.append(TimeseriesContent(
                    name="env.obs.imu",
                    ref=TimeseriesRef(
                        file=f"data/{self.dataset_name}/imu/{acc.current_file_ref}",
                        row=acc.total_rows - 1,
                        from_ts=0.0,
                        to_ts=1.0 / max(raw.imu_fps, 1.0),
                        fps=raw.imu_fps,
                    ),
                ))

            if raw.audio_env and t_n == 1:
                acc = self._get_accumulator("audio_env")
                acc.append(ep_idx, raw.audio_env)
                env_content.append(AudioContent(ref=AudioRef(
                    file=f"data/{self.dataset_name}/audio_env/{acc.current_file_ref}",
                    row=acc.total_rows - 1,
                    from_ts=0.0,
                    to_ts=raw.duration,
                    sample_rate=raw.audio_sample_rate,
                )))

            messages = [
                EnvMessage(
                    timestamp=Timestamp(start=0.0, end=step_dur),
                    content=env_content,
                ),
            ]
            if ai_content:
                messages.append(AiMessage(
                    timestamp=Timestamp(start=0.0, end=step_dur),
                    content=ai_content,
                ))

            episode = Episode(
                episode_index=ep_idx,
                duration=step_dur,
                messages=messages,
            )
            self._skeleton_records.append(
                serialize_episode_record(
                    episode,
                    source_root=str(self.output_dir),
                    source_dataset_name=self.dataset_name,
                    source_skeleton_dir=str(self.skeleton_dir),
                )
            )
            self._total_frames += 1

        if self._episode_count % 100 == 0:
            logger.info(f"Written {self._episode_count} frame-episodes for {self.dataset_name}")

    def write_episode(self, raw: RawEpisode) -> None:
        if self._one_frame_per_episode:
            self._write_episode_as_frames(raw)
            return

        ep_idx = self._episode_count
        env_content: list = []
        ai_content: list = []

        # ── TimeseriesName 映射 ──
        state_type = normalize_state_type(raw.state_type)
        action_type = normalize_action_type(raw.action_type)
        observation_series, obs_dim_names = self._collect_observation_series(raw)
        action_series, act_dim_names = self._collect_action_series(raw)

        # ── dim_names ──
        dim_names: dict[str, list[str]] = {}
        dim_names.update(obs_dim_names)
        dim_names.update(act_dim_names)

        # ── 1. MetaContent ──
        env_content.append(MetaContent(
            dataset_name=raw.dataset_name or self.dataset_name,
            dataset_type=raw.dataset_type,
            task=raw.task or raw.language_instruction,
            task_id=raw.task_id,
            robot_type=raw.robot_type,
            system_prompt=raw.system_prompt,
            urdf_path=raw.urdf_path,
            joint_names=raw.joint_names,
            camera_extrinsics=raw.camera_extrinsics,
            camera_intrinsics=raw.camera_intrinsics,
            dim_names=dim_names,
            quality_rating=raw.quality_rating,
            user_id=raw.user_id,
            scene_id=raw.scene_id,
            extra=raw.extra,
        ))

        # ── 1.5 校验 ──
        if raw.state is not None and raw.action is not None and action_type:
            if action_type in ActionValidator.ALL_TYPES:
                validator = ActionValidator(action_type)
                errors = validator.check(raw.state, raw.action)
                if errors:
                    for err in errors:
                        logger.error(f"Episode {raw.episode_id}: {err}")
                    raise ValueError(
                        f"Episode {raw.episode_id} 与 action_type={action_type} 不一致: "
                        + "; ".join(errors)
                    )

        # ── 2. 视频 ──
        for cam_name, frames in raw.video_frames.items():
            if not frames:
                continue
            video_path = self._encode_video(cam_name, ep_idx, frames, raw.fps)
            rel_path = str(video_path.relative_to(self.output_dir))
            env_content.append(VideoContent(ref=VideoRef(
                file=rel_path,
                from_ts=0.0,
                to_ts=raw.duration or len(frames) / max(raw.fps, 1),
                fps=raw.fps,
                width=frames[0].shape[1],
                height=frames[0].shape[0],
            )))

        for cam_name, src_path in raw.video_files.items():
            dst_dir = self.video_dir / cam_name
            dst_dir.mkdir(parents=True, exist_ok=True)
            dst_path = dst_dir / f"episode_{ep_idx:06d}.mp4"

            probe = _probe_video(src_path)
            src_w = probe.get("width", 0)
            src_h = probe.get("height", 0)
            out_w, out_h = self._cap_resolution(src_w, src_h)

            if src_w > self.MAX_WIDTH or src_h > self.MAX_HEIGHT:
                _reencode_video(src_path, dst_path, out_w, out_h)
            else:
                shutil.copy2(src_path, dst_path)

            rel_path = str(dst_path.relative_to(self.output_dir))
            env_content.append(VideoContent(ref=VideoRef(
                file=rel_path,
                from_ts=0.0,
                to_ts=probe.get("duration", raw.duration),
                fps=probe.get("fps", raw.fps),
                width=out_w,
                height=out_h,
            )))

        # ── 3. Observation timeseries ──
        for ts_name, data in observation_series.items():
            self._append_timeseries(
                target_content=env_content,
                episode_index=ep_idx,
                timeseries_name=ts_name,
                data=data,
                fps=raw.fps,
                from_ts=0.0,
                to_ts=self._timeseries_duration(data, raw.fps, raw.duration),
            )

        # ── 4. Action timeseries ──
        for ts_name, data in action_series.items():
            self._append_timeseries(
                target_content=ai_content,
                episode_index=ep_idx,
                timeseries_name=ts_name,
                data=data,
                fps=raw.fps,
                from_ts=0.0,
                to_ts=self._timeseries_duration(data, raw.fps, raw.duration),
            )

        # ── 5. Force ──
        if raw.force is not None and raw.force.size > 0:
            acc = self._get_accumulator("force")
            acc.append(ep_idx, raw.force, raw.force_fps)
            env_content.append(TimeseriesContent(
                name="env.obs.force_torque",
                ref=TimeseriesRef(
                    file=f"data/{self.dataset_name}/force/{acc.current_file_ref}",
                    row=acc.total_rows - 1,
                    from_ts=0.0,
                    to_ts=raw.duration or len(raw.force) / max(raw.force_fps, 1),
                    fps=raw.force_fps,
                ),
            ))

        # ── 6. IMU ──
        if raw.imu is not None and raw.imu.size > 0:
            acc = self._get_accumulator("imu")
            acc.append(ep_idx, raw.imu, raw.imu_fps)
            env_content.append(TimeseriesContent(
                name="env.obs.imu",
                ref=TimeseriesRef(
                    file=f"data/{self.dataset_name}/imu/{acc.current_file_ref}",
                    row=acc.total_rows - 1,
                    from_ts=0.0,
                    to_ts=raw.duration or len(raw.imu) / max(raw.imu_fps, 1),
                    fps=raw.imu_fps,
                ),
            ))

        self._total_frames += self._infer_frame_count(raw)

        # ── 7. Audio ──
        if raw.audio_env is not None and len(raw.audio_env) > 0:
            acc = self._get_accumulator("audio_env")
            acc.append(ep_idx, raw.audio_env)
            env_content.append(AudioContent(ref=AudioRef(
                file=f"data/{self.dataset_name}/audio_env/{acc.current_file_ref}",
                row=acc.total_rows - 1,
                from_ts=0.0,
                to_ts=raw.duration,
                sample_rate=raw.audio_sample_rate,
            )))

        # ── 8. 骨架 ──
        messages = [
            EnvMessage(
                timestamp=Timestamp(start=0.0, end=raw.duration),
                content=env_content,
            ),
        ]
        if ai_content:
            messages.append(AiMessage(
                timestamp=Timestamp(start=0.0, end=raw.duration),
                content=ai_content,
            ))

        episode = Episode(
            episode_index=ep_idx,
            duration=raw.duration,
            messages=messages,
        )

        self._skeleton_records.append(
            serialize_episode_record(
                episode,
                source_root=str(self.output_dir),
                source_dataset_name=self.dataset_name,
                source_skeleton_dir=str(self.skeleton_dir),
            )
        )
        self._episode_count += 1

        if self._episode_count % 100 == 0:
            logger.info(f"Written {self._episode_count} episodes for {self.dataset_name}")

    MAX_WIDTH = 1280
    MAX_HEIGHT = 720

    def _save_frame_png(self, cam_name: str, ep_idx: int, img: np.ndarray) -> Path:
        from PIL import Image

        h, w = img.shape[:2]
        out_w, out_h = self._cap_resolution(w, h)
        arr = np.clip(img, 0, 255).astype(np.uint8)
        pil = Image.fromarray(arr, mode="RGB")
        if (out_w, out_h) != (w, h):
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS")
            pil = pil.resize((out_w, out_h), resample)
        dst_dir = self.video_dir / cam_name
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst_path = dst_dir / f"episode_{ep_idx:06d}.png"
        pil.save(str(dst_path), format="PNG")
        return dst_path

    def _encode_video(
        self, cam_name: str, ep_idx: int, frames: list[np.ndarray], fps: float
    ) -> Path:
        dst_dir = self.video_dir / cam_name
        dst_dir.mkdir(parents=True, exist_ok=True)
        dst_path = dst_dir / f"episode_{ep_idx:06d}.mp4"

        h, w = frames[0].shape[:2]
        fps = max(fps, 1)

        out_w, out_h = self._cap_resolution(w, h)
        need_resize = (out_w != w or out_h != h)

        container = av.open(str(dst_path), "w")
        stream = container.add_stream("h264", int(fps))
        stream.pix_fmt = "yuv420p"
        stream.width = out_w
        stream.height = out_h
        stream.options = {"crf": "23", "g": "10"}

        for img in frames:
            frame = av.VideoFrame.from_ndarray(img, format="rgb24")
            if need_resize:
                frame = frame.reformat(width=out_w, height=out_h)
            for pkt in stream.encode(frame):
                container.mux(pkt)
        for pkt in stream.encode():
            container.mux(pkt)
        container.close()

        return dst_path

    @staticmethod
    def _cap_resolution(w: int, h: int) -> tuple[int, int]:
        if w <= EmbodiedWriter.MAX_WIDTH and h <= EmbodiedWriter.MAX_HEIGHT:
            return w, h
        scale = min(EmbodiedWriter.MAX_WIDTH / w, EmbodiedWriter.MAX_HEIGHT / h)
        return int(w * scale) // 2 * 2, int(h * scale) // 2 * 2

    def finalize(self) -> None:
        for acc in self._accumulators.values():
            acc.finalize()

        if self._shuffle_perm is not None and self._shuffle_pos != len(self._shuffle_perm):
            logger.warning(
                "shuffle 总帧数不匹配: 实际写入 %d 条，声明 total_frames=%d",
                self._shuffle_pos,
                len(self._shuffle_perm),
            )

        self._write_skeleton()
        self._write_meta()

        logger.info(
            f"Finalized {self.dataset_name}: "
            f"{self._episode_count} episodes, {self._total_frames} frames"
        )

    def _write_skeleton(self) -> None:
        """写入骨架为 SSTable partition (part-00000, part-00001, ...)"""
        num_parts, num_records = write_mbtable_partition(
            self.skeleton_dir, self._skeleton_records
        )
        logger.info(
            f"SSTable skeleton → {self.skeleton_dir} "
            f"({num_parts} parts, {num_records} records)"
        )

    def _write_meta(self) -> None:
        info = {
            "dataset_name": self.dataset_name,
            "total_episodes": self._episode_count,
            "total_frames": self._total_frames,
            "accumulators": {
                name: {"total_rows": acc.total_rows}
                for name, acc in self._accumulators.items()
            },
        }
        info_path = self.meta_dir / "info.json"
        with open(info_path, "w") as f:
            json.dump(info, f, indent=2, ensure_ascii=False)

        stats = {}
        for key, arrays in self._stats_accum.items():
            if not arrays:
                continue
            stats[key] = compute_stats(np.concatenate(arrays, axis=0))

        write_norm_stats_files(self.meta_dir, stats)

        logger.info(f"Meta → {info_path}")


def _reencode_video(src: str | Path, dst: Path, width: int, height: int) -> None:
    """重编码视频：缩放到指定分辨率，H264 CRF 23。"""
    in_c = av.open(str(src))
    stream_in = in_c.streams.video[0]
    fps = float(stream_in.average_rate) if stream_in.average_rate else 10

    out_c = av.open(str(dst), "w")
    stream_out = out_c.add_stream("h264", int(fps))
    stream_out.pix_fmt = "yuv420p"
    stream_out.width = width
    stream_out.height = height
    stream_out.options = {"crf": "23", "g": "10"}

    for frame in in_c.decode(video=0):
        frame = frame.reformat(width=width, height=height, format="yuv420p")
        for pkt in stream_out.encode(frame):
            out_c.mux(pkt)
    for pkt in stream_out.encode():
        out_c.mux(pkt)

    out_c.close()
    in_c.close()


def _probe_video(path: str | Path) -> dict:
    c = av.open(str(path))
    if not c.streams.video:
        c.close()
        return {}
    s = c.streams.video[0]
    result = {
        "width": s.width,
        "height": s.height,
        "fps": float(s.average_rate) if s.average_rate else 0,
        "duration": float(s.duration * s.time_base) if s.duration else 0,
        "frames": s.frames,
    }
    c.close()
    return result


