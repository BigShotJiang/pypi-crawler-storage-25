"""
modelbest_robo_dataset — 具身智能数据集工具库
============================================
提供统一的多模态机器人数据集读写、校验和格式转换。

核心设计:
  Episode 骨架 (SSTable partition) + Parquet 时序表 + per-episode MP4
  RawEpisode → Writer → 统一格式
  Reader → Episode → 训练采样
"""

from .data_types import (
    AudioContent,
    AudioRef,
    AiMessage,
    ContentType,
    EnvMessage,
    Episode,
    MessageType,
    MetaContent,
    TextContent,
    TextWithTime,
    TimeseriesContent,
    TimeseriesName,
    TimeseriesRef,
    Timestamp,
    UserMessage,
    VideoContent,
    VideoRef,
)
from .sources.base import EpisodeSource, RawEpisode
from .validator import ActionValidator
from .writer import EmbodiedWriter
from .reader import EmbodiedReader
from .embodied_dataset import EmbodiedDataset
from .sstable_record import (
    EpisodeSstableEnvelope,
    decode_episode_record,
    deserialize_episode_record,
    episode_to_messages,
    serialize_episode_record,
)

__all__ = [
    "AudioContent", "AudioRef", "AiMessage", "ContentType",
    "EnvMessage", "Episode", "MessageType", "MetaContent",
    "TextContent", "TextWithTime", "TimeseriesContent",
    "TimeseriesName", "TimeseriesRef", "Timestamp",
    "UserMessage", "VideoContent", "VideoRef",
    "EpisodeSource", "RawEpisode",
    "ActionValidator", "EmbodiedWriter", "EmbodiedReader", "EmbodiedDataset",
    "EpisodeSstableEnvelope", "decode_episode_record",
    "deserialize_episode_record",
    "episode_to_messages", "serialize_episode_record",
]
