"""
ActionValidator: 校验 state/action 数据与声明类型的一致性
"""

from __future__ import annotations

import numpy as np

from .stats import pearson_corr_1d

# 与文档 sop_state_action 一致：增量控制下 corr(diff(state), action) 可达 ~0.5+
_DELTA_ACTION_CORR_MIN = 0.32


class ActionValidator:
    """
    根据声明的 action_type 校验实际 state/action 数据。

    参数:
        action_type: "absolute_joint" | "absolute_ee" | "delta_joint" | "delta_ee"
    """

    ABSOLUTE_TYPES = ("absolute_joint", "absolute_ee")
    DELTA_TYPES = ("delta_joint", "delta_ee")
    ALL_TYPES = ABSOLUTE_TYPES + DELTA_TYPES

    def __init__(self, action_type: str):
        if action_type not in self.ALL_TYPES:
            raise ValueError(f"未知 action_type: {action_type}, 合法值: {self.ALL_TYPES}")
        self.action_type = action_type
        self.is_absolute = action_type in self.ABSOLUTE_TYPES

    def check(self, state: np.ndarray | None, action: np.ndarray | None) -> list[str]:
        """校验数据，返回错误列表。空列表 = 通过。"""
        if state is None or action is None:
            return []
        if len(state) < 2 or len(action) < 2:
            return []

        T = min(len(state), len(action))
        D = min(state.shape[1], action.shape[1])
        s = state[:T, :D].astype(float)
        a = action[:T, :D].astype(float)

        scale_ratio = self._scale_ratio(s, a)
        mean_corr = self._mean_correlation(s, a)
        mean_corr_delta = self._mean_correlation_state_delta_action(s, a)

        errors = []

        if self.is_absolute:
            incremental_evidence = mean_corr_delta >= _DELTA_ACTION_CORR_MIN
            if incremental_evidence:
                if scale_ratio > 10:
                    errors.append(
                        f"声明 {self.action_type} 但量级差异过大: "
                        f"action/state ratio={scale_ratio:.2f}"
                    )
            elif scale_ratio < 0.1 or scale_ratio > 10:
                errors.append(
                    f"声明 {self.action_type} 但量级差异过大: "
                    f"action/state ratio={scale_ratio:.2f}"
                )
            if mean_corr < 0.7 and mean_corr_delta < _DELTA_ACTION_CORR_MIN:
                errors.append(
                    f"声明 {self.action_type} 但 corr(state, action)={mean_corr:.3f}、"
                    f"corr(diff(state), action)={mean_corr_delta:.3f}；"
                    f"若为增量控制请使用 delta_joint / delta_ee"
                )
        else:
            if (
                scale_ratio > 0.8
                and mean_corr > 0.9
                and mean_corr_delta < 0.5
                and np.mean(np.abs(s)) > 0.01
            ):
                errors.append(
                    f"声明 {self.action_type} 但数据特征像绝对控制: "
                    f"ratio={scale_ratio:.2f}, corr(state,action)={mean_corr:.3f}"
                )

        return errors

    @staticmethod
    def _scale_ratio(s: np.ndarray, a: np.ndarray) -> float:
        s_scale = np.mean(np.abs(s))
        a_scale = np.mean(np.abs(a))
        return float(a_scale / (s_scale + 1e-10))

    @staticmethod
    def _mean_correlation(s: np.ndarray, a: np.ndarray) -> float:
        D = s.shape[1]
        corrs = []
        for d in range(D):
            c = pearson_corr_1d(s[:, d], a[:, d])
            if not np.isnan(c):
                corrs.append(c)
        return float(np.mean(corrs)) if corrs else 0.0

    @staticmethod
    def _mean_correlation_state_delta_action(s: np.ndarray, a: np.ndarray) -> float:
        """corr(state[t+1]-state[t], action[t])，用于识别增量/相对动作。"""
        if len(s) < 3 or len(a) < 3:
            return 0.0
        ds = s[1:] - s[:-1]
        aa = a[:-1]
        D = min(ds.shape[1], aa.shape[1])
        if D < 1:
            return 0.0
        corrs = []
        for d in range(D):
            c = pearson_corr_1d(ds[:, d], aa[:, d])
            if not np.isnan(c):
                corrs.append(c)
        return float(np.mean(corrs)) if corrs else 0.0
