"""
MbTable (SSTable) partition 读写。

默认使用 `modelbest_sdk` 的 MbTable 格式；若环境中缺少该依赖，则回退为
简单的 `part-xxxxx` 文本分片，每行一条 UTF-8 JSON 记录，便于轻量脚本在无完整
运行时依赖的环境中继续工作。
"""

from __future__ import annotations

from collections.abc import Iterable
from pathlib import Path


def write_mbtable_partition(
    out_dir: Path,
    records: Iterable[bytes],
    *,
    samples_per_sstable: int = 10000,
) -> tuple[int, int]:
    """
    将 UTF-8 JSON 等二进制记录写入 MbTable partition。

    Returns:
        (num_parts, num_records)；无记录时 num_parts 为 0。
    """
    try:
        from modelbest_sdk.file_format.mbtable_builder import MbTableBuilder
    except ModuleNotFoundError:
        out_dir.mkdir(parents=True, exist_ok=True)
        part_idx = 0
        count_in_file = 0
        total = 0
        fh = None

        for record in records:
            if count_in_file % samples_per_sstable == 0:
                if fh is not None:
                    fh.close()
                    part_idx += 1
                    count_in_file = 0
                part_path = out_dir / f"part-{part_idx:05d}"
                fh = open(part_path, "wb")

            data = record if isinstance(record, bytes) else record.encode("utf-8")
            fh.write(data.rstrip(b"\n") + b"\n")
            count_in_file += 1
            total += 1

        if fh is not None:
            fh.close()

        num_parts = (part_idx + 1) if total > 0 else 0
        return num_parts, total

    out_dir.mkdir(parents=True, exist_ok=True)
    part_idx = 0
    count_in_file = 0
    builder = None
    total = 0

    for record in records:
        if count_in_file % samples_per_sstable == 0:
            if builder is not None:
                builder.flush()
                part_idx += 1
                count_in_file = 0
            part_path = str(out_dir / f"part-{part_idx:05d}")
            builder = MbTableBuilder(part_path)

        data = record if isinstance(record, bytes) else record.encode("utf-8")
        builder.write(data)
        count_in_file += 1
        total += 1

    if builder is not None:
        builder.flush()

    num_parts = (part_idx + 1) if total > 0 else 0
    return num_parts, total


def iter_mbtable_partition_records(partition_dir: Path) -> Iterable[bytes]:
    try:
        from modelbest_sdk.file_format.mbtable_partition import (
            MbTablePartition,
            MbTablePartitionIterator,
        )
    except ModuleNotFoundError:
        for part_path in sorted(partition_dir.glob("part-*")):
            with open(part_path, "rb") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        yield line
        return

    partition = MbTablePartition(str(partition_dir))
    with MbTablePartitionIterator(partition) as it:
        for record in it:
            yield record
