"""Small numeric helpers shared across dataset code."""

from __future__ import annotations

import numpy as np


def pearson_corr_1d(x: np.ndarray, y: np.ndarray) -> float:
    """
    Pearson correlation between two 1-D sequences.

    Returns nan if correlation is undefined (too few samples, non-finite values,
    or either series is constant). Avoids calling np.corrcoef in those cases so
    NumPy does not emit divide-by-zero RuntimeWarnings.
    """
    xa = np.asarray(x, dtype=np.float64).ravel()
    ya = np.asarray(y, dtype=np.float64).ravel()
    n = min(xa.size, ya.size)
    if n < 2:
        return float("nan")
    xa, ya = xa[:n], ya[:n]
    if not (np.all(np.isfinite(xa)) and np.all(np.isfinite(ya))):
        return float("nan")
    if np.ptp(xa) == 0 or np.ptp(ya) == 0:
        return float("nan")
    return float(np.corrcoef(xa, ya)[0, 1])
