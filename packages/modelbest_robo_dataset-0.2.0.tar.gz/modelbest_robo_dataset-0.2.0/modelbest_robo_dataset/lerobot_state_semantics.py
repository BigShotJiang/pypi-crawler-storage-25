"""
Infer LeRobot observation.state / action space (joint vs EE) and action absolute vs delta from metadata + Parquet.

Pearson correlation helpers mirror ``stats.pearson_corr_1d`` so scripts can ``importlib``-load this file alone.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pyarrow.parquet as pq

# Align / extend with sources.lerobot.LeRobotSource._is_ee_state_key
_EE_KEY_FRAGMENTS = (
    "eef",
    "tcp",
    "cartesian",
    "pose",
    "world_pose",
    "ee_pose",
    "ee_",
)

_JOINT_NAME_SUBSTR = ("joint", "shoulder", "elbow", "wrist", "finger")

_ROT_NAME_SUBSTR = (
    "quat",
    "qx",
    "qw",
    "qy",
    "qz",
    "axis_angle",
    "euler",
    "rpy",
    "rotation",
    "orient",
)

_MOTOR_NAME_RE = re.compile(r"^motor_\d+$", re.IGNORECASE)


def pearson_corr_1d(x: np.ndarray, y: np.ndarray) -> float:
    """Same behavior as ``stats.pearson_corr_1d`` (for importlib-only script loads)."""
    xa = np.asarray(x, dtype=np.float64).ravel()
    ya = np.asarray(y, dtype=np.float64).ravel()
    n = min(xa.size, ya.size)
    if n < 2:
        return float("nan")
    xa, ya = xa[:n], ya[:n]
    if not (np.all(np.isfinite(xa)) and np.all(np.isfinite(ya))):
        return float("nan")
    if np.ptp(xa) == 0 or np.ptp(ya) == 0:
        return float("nan")
    return float(np.corrcoef(xa, ya)[0, 1])


def _mean_per_dim_corrcoef(x: np.ndarray, y: np.ndarray) -> float:
    t, d = min(len(x), len(y)), min(x.shape[1], y.shape[1])
    if t < 2 or d < 1:
        return 0.0
    corrs: list[float] = []
    for dim in range(d):
        c = pearson_corr_1d(x[:t, dim], y[:t, dim])
        if not np.isnan(c):
            corrs.append(c)
    return float(np.mean(corrs)) if corrs else 0.0


def _state_action_correlation_scores(
    state: np.ndarray, action: np.ndarray
) -> tuple[float, float]:
    """(corr(state, action), corr(diff(state), action[:-1])) — aligned with ``LeRobotSource``."""
    t = min(len(state), len(action))
    d = min(state.shape[1], action.shape[1])
    if t < 3 or d < 1:
        return 0.0, 0.0
    s = state[:t, :d].astype(np.float64)
    a = action[:t, :d].astype(np.float64)
    corr_sa = _mean_per_dim_corrcoef(s, a)
    ds = s[1:] - s[:-1]
    aa = a[:-1]
    corr_dsa = _mean_per_dim_corrcoef(ds, aa)
    return corr_sa, corr_dsa


@dataclass
class StateSemanticsResult:
    label: str  # joint_position | ee_pose | unknown
    confidence: float
    reasons: list[str] = field(default_factory=list)
    state_key: str | None = None
    shape: tuple[int, ...] | None = None
    sample_dim_names: list[str] = field(default_factory=list)

    def to_jsonable(self) -> dict[str, Any]:
        return {
            "label": self.label,
            "confidence": self.confidence,
            "reasons": self.reasons,
            "state_key": self.state_key,
            "shape": list(self.shape) if self.shape is not None else None,
            "sample_dim_names": self.sample_dim_names,
        }


@dataclass
class LeRobotSemanticsReport:
    """Unified JSON-serializable semantics report for a LeRobot dataset root."""

    observation_state: StateSemanticsResult
    action_space: StateSemanticsResult
    action_value_mode: dict[str, Any]
    state_value_mode: dict[str, Any]

    def to_jsonable(self) -> dict[str, Any]:
        return {
            "observation_state": self.observation_state.to_jsonable(),
            "action_space": self.action_space.to_jsonable(),
            "action_value_mode": dict(self.action_value_mode),
            "state_value_mode": dict(self.state_value_mode),
        }


def _find_state_key(features: dict[str, Any]) -> str | None:
    return next((k for k in features if k.startswith("observation.state")), None)


def _extract_dim_names(features: dict[str, Any], key: str | None) -> list[str]:
    if not key or key not in features:
        return []
    names_obj = features[key].get("names", {})
    if names_obj is None:
        names_obj = {}
    if isinstance(names_obj, dict):
        motors = names_obj.get("motors")
        if motors is not None:
            return list(motors)
        axes = names_obj.get("axes")
        if axes is not None:
            return list(axes)
        return []
    if isinstance(names_obj, list):
        return list(names_obj)
    return []


def _state_feature_shape(features: dict[str, Any], key: str | None) -> tuple[int, ...] | None:
    if not key or key not in features:
        return None
    sh = features[key].get("shape")
    if isinstance(sh, list) and all(isinstance(x, int) for x in sh):
        return tuple(sh)
    return None


def _key_suggests_ee(state_key: str) -> bool:
    sk = state_key.lower()
    return any(frag in sk for frag in _EE_KEY_FRAGMENTS)


def _has_xyz_dim_names(names: list[str]) -> bool:
    normalized = {str(n).lower().strip() for n in names}
    return {"x", "y", "z"}.issubset(normalized)


def _names_suggest_ee(names: list[str]) -> bool:
    if not names:
        return False
    if _has_xyz_dim_names(names):
        return True
    blob = " ".join(str(n).lower() for n in names)
    return any(sub in blob for sub in _ROT_NAME_SUBSTR)


def _names_suggest_joint(names: list[str]) -> bool:
    if not names:
        return False
    blob = " ".join(str(n).lower() for n in names)
    return any(sub in blob for sub in _JOINT_NAME_SUBSTR)


def _all_motor_style_names(names: list[str]) -> bool:
    if not names:
        return False
    return all(_MOTOR_NAME_RE.match(str(n).strip()) for n in names)


def _sample_feature_matrix(
    root: Path,
    feature_key: str,
    *,
    max_rows: int,
) -> np.ndarray | None:
    data_dir = root / "data"
    if not data_dir.is_dir():
        return None
    files = sorted(data_dir.rglob("*.parquet"))
    if not files:
        return None
    rows: list[list[float]] = []
    total = 0
    for path in files:
        try:
            pf = pq.ParquetFile(path)
        except Exception:
            continue
        if feature_key not in pf.schema.names:
            continue
        try:
            table = pq.read_table(path, columns=[feature_key])
        except Exception:
            continue
        col = table[feature_key]
        n_here = len(table)
        take = min(n_here, max_rows - total)
        if take <= 0:
            break
        chunk = col.slice(0, take)
        for i in range(take):
            v = chunk[i].as_py()
            if not isinstance(v, (list, tuple)):
                continue
            rows.append([float(x) for x in v])
            total += 1
            if total >= max_rows:
                break
        if total >= max_rows:
            break
    if not rows:
        return None
    try:
        return np.asarray(rows, dtype=np.float32)
    except Exception:
        return None


def _best_quaternion_block_mean_abs_norm_err(S: np.ndarray) -> tuple[float, str]:
    """Return (mean abs(|‖q‖-1|), block label) for the better of last-4 vs cols 3:7."""
    _, D = S.shape
    if D < 7:
        return 1.0, ""
    candidates: list[tuple[str, np.ndarray]] = [
        ("last_4_columns", S[:, -4:].astype(np.float64)),
        ("columns_3_to_6", S[:, 3:7].astype(np.float64)),
    ]
    best_err = 1.0
    best_lbl = ""
    for lbl, Q in candidates:
        norms = np.linalg.norm(Q, axis=1)
        err = np.abs(norms - 1.0)
        m = float(np.mean(err))
        if m < best_err:
            best_err = m
            best_lbl = lbl
    return best_err, best_lbl


def _sixd_ee_heuristic(S: np.ndarray) -> tuple[bool, str]:
    """Very weak signal: first 3 like meters, last 3 like radians."""
    if S.shape[1] != 6 or len(S) < 8:
        return False, ""
    x = S.astype(np.float64)
    a = np.median(np.abs(x[:, :3]))
    b = np.median(np.abs(x[:, 3:]))
    if a < 2.0 and b < 3.5 and np.median(np.abs(x[:, :3])) > 0.01:
        return True, f"6-D vector: median|pos|≈{a:.3f} m, median|rot|≈{b:.3f} rad (heuristic)"
    return False, ""


def _infer_feature_space_semantics(
    root: Path,
    features: dict[str, Any],
    feature_key: str,
    *,
    max_sample_rows: int,
    name_for_reasons: str,
) -> StateSemanticsResult:
    reasons: list[str] = []
    dim_names = _extract_dim_names(features, feature_key)
    shape = _state_feature_shape(features, feature_key)

    if _key_suggests_ee(feature_key):
        reasons.append(f"{name_for_reasons} feature key suggests EE semantics: {feature_key!r}")
        return StateSemanticsResult(
            label="ee_pose",
            confidence=0.95,
            reasons=reasons,
            state_key=feature_key,
            shape=shape,
            sample_dim_names=dim_names,
        )

    ee_n = _names_suggest_ee(dim_names)
    jn = _names_suggest_joint(dim_names)

    if ee_n and jn:
        reasons.append("names contain both EE-like signals (xyz/rotation) and joint-like substrings")
        if _has_xyz_dim_names(dim_names):
            reasons.append("xyz dimension names present → favour ee_pose")
            return StateSemanticsResult(
                label="ee_pose",
                confidence=0.72,
                reasons=reasons,
                state_key=feature_key,
                shape=shape,
                sample_dim_names=dim_names,
            )
    elif ee_n:
        reasons.append("dimension names suggest EE (xyz and/or rotation-related tokens)")
        return StateSemanticsResult(
            label="ee_pose",
            confidence=0.88,
            reasons=reasons,
            state_key=feature_key,
            shape=shape,
            sample_dim_names=dim_names,
        )
    elif jn:
        reasons.append("dimension names suggest joint space (joint/shoulder/elbow/wrist/finger)")
        return StateSemanticsResult(
            label="joint_position",
            confidence=0.88,
            reasons=reasons,
            state_key=feature_key,
            shape=shape,
            sample_dim_names=dim_names,
        )

    s_mat = _sample_feature_matrix(root, feature_key, max_rows=max_sample_rows)
    if s_mat is None:
        if _all_motor_style_names(dim_names):
            reasons.append("only motor_* names; no parquet sample → cannot run numeric check")
        elif not dim_names:
            reasons.append("no dimension names; no parquet sample for numeric heuristic")
        else:
            reasons.append("ambiguous names; no parquet sample for numeric heuristic")
        return StateSemanticsResult(
            label="unknown",
            confidence=0.35,
            reasons=reasons,
            state_key=feature_key,
            shape=shape,
            sample_dim_names=dim_names,
        )

    d_cols = s_mat.shape[1]
    q_err, q_block = _best_quaternion_block_mean_abs_norm_err(s_mat)
    if d_cols >= 7 and q_err < 0.05:
        reasons.append(
            f"numeric: {q_block} values look like unit quaternions "
            f"(mean abs(‖q‖-1)={q_err:.4f} over {len(s_mat)} rows)"
        )
        return StateSemanticsResult(
            label="ee_pose",
            confidence=0.74,
            reasons=reasons,
            state_key=feature_key,
            shape=shape,
            sample_dim_names=dim_names,
        )

    if d_cols == 6:
        ok, msg = _sixd_ee_heuristic(s_mat)
        if ok:
            reasons.append(f"numeric: {msg}")
            return StateSemanticsResult(
                label="ee_pose",
                confidence=0.55,
                reasons=reasons,
                state_key=feature_key,
                shape=shape,
                sample_dim_names=dim_names,
            )

    if _all_motor_style_names(dim_names) or not dim_names:
        reasons.append(
            "motor-style or empty names; sampled data does not match a unit-quaternion block → joint_position"
        )
        return StateSemanticsResult(
            label="joint_position",
            confidence=0.66 if _all_motor_style_names(dim_names) else 0.5,
            reasons=reasons,
            state_key=feature_key,
            shape=shape,
            sample_dim_names=dim_names,
        )

    reasons.append(
        f"could not classify ({len(s_mat)} sample rows, D={d_cols}); "
        "names are ambiguous and quaternion heuristic did not match"
    )
    return StateSemanticsResult(
        label="unknown",
        confidence=0.4,
        reasons=reasons,
        state_key=feature_key,
        shape=shape,
        sample_dim_names=dim_names,
    )


def infer_observation_state_semantics(
    root: Path | str,
    *,
    max_sample_rows: int = 5000,
) -> StateSemanticsResult:
    """
    Load ``meta/info.json`` under ``root``, optionally sample ``data/**/*.parquet`` (row cap ``max_sample_rows``).
    """
    root = Path(root)
    info_path = root / "meta" / "info.json"
    if not info_path.is_file():
        return StateSemanticsResult(
            label="unknown",
            confidence=0.0,
            reasons=[f"missing meta/info.json: {info_path}"],
        )
    with open(info_path, encoding="utf-8") as f:
        info = json.load(f)
    features = info.get("features", {})
    state_key = _find_state_key(features)
    if not state_key:
        return StateSemanticsResult(
            label="unknown",
            confidence=0.0,
            reasons=["no feature key starting with observation.state"],
        )
    return _infer_feature_space_semantics(
        root,
        features,
        state_key,
        max_sample_rows=max_sample_rows,
        name_for_reasons="State",
    )


def infer_action_space_semantics(
    root: Path | str,
    *,
    max_sample_rows: int = 5000,
) -> StateSemanticsResult:
    """Same heuristics as observation state, for the fixed LeRobot feature key ``action``."""
    root = Path(root)
    info_path = root / "meta" / "info.json"
    if not info_path.is_file():
        return StateSemanticsResult(
            label="unknown",
            confidence=0.0,
            reasons=[f"missing meta/info.json: {info_path}"],
        )
    with open(info_path, encoding="utf-8") as f:
        info = json.load(f)
    features = info.get("features", {})
    if "action" not in features:
        return StateSemanticsResult(
            label="unknown",
            confidence=0.0,
            reasons=["no feature key 'action' in meta/features"],
        )
    return _infer_feature_space_semantics(
        root,
        features,
        "action",
        max_sample_rows=max_sample_rows,
        name_for_reasons="Action",
    )


def _max_corr_state_action_over_episodes(
    root: Path,
    info: dict[str, Any],
    state_key: str | None,
    *,
    max_episodes: int,
    max_corr_scan_rows: int,
    max_rows_per_episode: int,
) -> tuple[float, float, list[str]]:
    """
    Per-episode Pearson scores (aligned with ``LeRobotSource._infer_dataset_action_type``),
    streaming Parquet under ``data/`` with row and per-episode caps.
    """
    reasons: list[str] = []
    features = info.get("features", {})
    if "action" not in features:
        return -1.0, -1.0, ["no action feature in meta; cannot correlate"]
    if not state_key:
        return -1.0, -1.0, ["no observation.state key; cannot correlate"]

    total_eps = int(info.get("total_episodes", 0) or 0)
    ep_cap = min(total_eps, max_episodes) if total_eps > 0 else max_episodes
    target_eps = set(range(ep_cap))
    if not target_eps:
        return -1.0, -1.0, ["total_episodes is zero; cannot correlate"]

    buffers: dict[int, list[tuple[list[float], list[float]]]] = {i: [] for i in target_eps}
    data_dir = root / "data"
    if not data_dir.is_dir():
        return -1.0, -1.0, ["no data/ directory; cannot correlate"]

    rows_scanned = 0
    for path in sorted(data_dir.rglob("*.parquet")):
        try:
            pf = pq.ParquetFile(path)
        except Exception:
            continue
        names = pf.schema.names
        if "episode_index" not in names or state_key not in names or "action" not in names:
            continue
        try:
            table = pq.read_table(path, columns=["episode_index", state_key, "action"])
        except Exception:
            continue
        n_here = len(table)
        ep_col = table["episode_index"]
        st_col = table[state_key]
        act_col = table["action"]
        for i in range(n_here):
            ep_raw = ep_col[i].as_py()
            try:
                ep_idx = int(ep_raw)
            except (TypeError, ValueError):
                continue
            if ep_idx not in target_eps:
                continue
            if len(buffers[ep_idx]) >= max_rows_per_episode:
                continue
            sv = st_col[i].as_py()
            av = act_col[i].as_py()
            if not isinstance(sv, (list, tuple)) or not isinstance(av, (list, tuple)):
                continue
            try:
                buffers[ep_idx].append(([float(x) for x in sv], [float(x) for x in av]))
            except (TypeError, ValueError):
                continue
        rows_scanned += n_here
        if rows_scanned >= max_corr_scan_rows:
            break

    def _accumulate(*, min_len: int) -> tuple[float, float]:
        max_sa = -1.0
        max_dsa = -1.0
        for ep_idx in sorted(target_eps):
            pairs = buffers[ep_idx]
            if len(pairs) < min_len:
                continue
            state = np.asarray([p[0] for p in pairs], dtype=np.float32)
            action = np.asarray([p[1] for p in pairs], dtype=np.float32)
            corr_sa, corr_dsa = _state_action_correlation_scores(state, action)
            max_sa = max(max_sa, corr_sa)
            max_dsa = max(max_dsa, corr_dsa)
        return max_sa, max_dsa

    max_sa, max_dsa = _accumulate(min_len=5)
    if max_sa < 0 and max_dsa < 0:
        max_sa, max_dsa = _accumulate(min_len=3)

    if max_sa < 0 and max_dsa < 0:
        reasons.append(
            f"no episode with enough rows (need ≥3) among episode_index in {sorted(target_eps)[:8]}… "
            f"after scanning ~{rows_scanned} parquet rows"
        )
    return max_sa, max_dsa, reasons


def _ee_suffix_for_action_mode(
    observation_state: StateSemanticsResult, action_space: StateSemanticsResult
) -> tuple[bool, list[str]]:
    """True → delta_ee / absolute_ee; False → delta_joint / absolute_joint (matches LeRobotSource priority)."""
    notes: list[str] = []
    if action_space.label == "ee_pose":
        if observation_state.label == "joint_position":
            notes.append(
                "action_space is ee_pose but observation_state is joint_position; "
                "EE vs joint suffix follows action_space"
            )
        return True, notes
    if action_space.label == "joint_position":
        if observation_state.label == "ee_pose":
            notes.append(
                "action_space is joint_position but observation_state is ee_pose; "
                "suffix follows action_space (joint)"
            )
        return False, notes
    if observation_state.label == "ee_pose":
        return True, notes
    if observation_state.label == "joint_position":
        return False, notes
    return False, notes


def _infer_action_value_mode_dict(
    root: Path,
    info: dict[str, Any],
    observation_state: StateSemanticsResult,
    action_space: StateSemanticsResult,
    *,
    max_episodes: int,
    max_corr_scan_rows: int,
    max_rows_per_episode: int,
) -> dict[str, Any]:
    state_key = observation_state.state_key
    is_ee, conflict_notes = _ee_suffix_for_action_mode(observation_state, action_space)
    abs_type = "absolute_ee" if is_ee else "absolute_joint"
    delta_type = "delta_ee" if is_ee else "delta_joint"

    max_sa, max_dsa, scan_reasons = _max_corr_state_action_over_episodes(
        root,
        info,
        state_key,
        max_episodes=max_episodes,
        max_corr_scan_rows=max_corr_scan_rows,
        max_rows_per_episode=max_rows_per_episode,
    )
    reasons = list(conflict_notes) + list(scan_reasons)

    prefer_delta = max_dsa >= 0.32 and max_dsa > max_sa + 0.02
    if max_sa < 0 and max_dsa < 0:
        label = "unknown"
        confidence = 0.0
        reasons.append("could not estimate correlations; defaulting to unknown (not absolute_joint)")
    else:
        label = delta_type if prefer_delta else abs_type
        gap = max_dsa - max_sa
        if prefer_delta:
            confidence = float(min(0.92, 0.38 + 0.45 * max_dsa + 0.35 * max(0.0, gap)))
            reasons.append(
                f"diff(state) aligns better with action than state (max corr(state,action)={max_sa:.4f}, "
                f"max corr(diff(state),action)={max_dsa:.4f}) → {label}"
            )
        else:
            confidence = float(min(0.92, 0.38 + 0.45 * max_sa + 0.35 * max(0.0, -gap)))
            reasons.append(
                f"state aligns at least as well as diff(state) with action (max corr(state,action)={max_sa:.4f}, "
                f"max corr(diff(state),action)={max_dsa:.4f}) → {label}"
            )

    return {
        "label": label,
        "confidence": confidence,
        "max_corr_state_action": None if max_sa < 0 else float(max_sa),
        "max_corr_diff_state_action": None if max_dsa < 0 else float(max_dsa),
        "reasons": reasons,
    }


def infer_lerobot_semantics(
    root: Path | str,
    *,
    max_sample_rows: int = 5000,
    max_action_corr_episodes: int = 24,
    max_corr_scan_rows: int = 500_000,
    max_rows_per_episode: int = 10_000,
) -> LeRobotSemanticsReport:
    """
    Full report: observation state, action space, action absolute/delta mode, and documented state value assumption.
    """
    root = Path(root)
    info_path = root / "meta" / "info.json"
    observation_state = infer_observation_state_semantics(root, max_sample_rows=max_sample_rows)
    action_space = infer_action_space_semantics(root, max_sample_rows=max_sample_rows)

    if not info_path.is_file():
        action_value_mode: dict[str, Any] = {
            "label": "unknown",
            "confidence": 0.0,
            "max_corr_state_action": None,
            "max_corr_diff_state_action": None,
            "reasons": [f"missing meta/info.json: {info_path}"],
        }
    else:
        with open(info_path, encoding="utf-8") as f:
            info = json.load(f)
        action_value_mode = _infer_action_value_mode_dict(
            root,
            info,
            observation_state,
            action_space,
            max_episodes=max_action_corr_episodes,
            max_corr_scan_rows=max_corr_scan_rows,
            max_rows_per_episode=max_rows_per_episode,
        )

    state_value_mode: dict[str, Any] = {
        "label": "absolute_assumed",
        "confidence": 0.28,
        "reasons": [
            "LeRobot proprioception (observation.state) is conventionally absolute; "
            "this report does not run a numeric absolute-vs-delta test on state."
        ],
    }

    return LeRobotSemanticsReport(
        observation_state=observation_state,
        action_space=action_space,
        action_value_mode=action_value_mode,
        state_value_mode=state_value_mode,
    )
