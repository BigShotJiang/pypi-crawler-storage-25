"""
EpisodeSource 接口 + RawEpisode 中间表示
=========================================
每种源格式 (LeRobot / RH20T / fuse / RoboMind) 实现 EpisodeSource 接口。
Writer 只接收 RawEpisode，完全不知道数据从哪来。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable

import numpy as np


@dataclass
class RawEpisode:
    """
    源数据中间表示：一个 episode 的所有原始数据。

    字段全部 Optional (除 episode_id)——有什么填什么，Writer 跳过 None。

    视频有两种提供方式 (二选一):
      video_frames: 帧列表 (numpy 数组)，Writer 编码成 MP4
      video_files:  已有 MP4 路径，Writer 直接 copy
    """
    episode_id: str
    duration: float = 0.0

    # 视频 (二选一)
    video_frames: dict[str, list[np.ndarray]] = field(default_factory=dict)
    video_files: dict[str, str] = field(default_factory=dict)

    # 时序数据
    state: np.ndarray | None = None
    action: np.ndarray | None = None
    observation_series: dict[str, np.ndarray] = field(default_factory=dict)
    action_series: dict[str, np.ndarray] = field(default_factory=dict)
    force: np.ndarray | None = None
    imu: np.ndarray | None = None
    gripper: np.ndarray | None = None

    # 音频
    audio_env: bytes | None = None
    audio_user: list[tuple[float, float, bytes]] | None = None
    audio_ai: list[tuple[float, float, bytes]] | None = None

    # 文本
    task: str = ""
    language_instruction: str = ""

    # 元信息
    robot_type: str = ""
    dataset_name: str = ""
    dataset_type: str = ""
    system_prompt: str = ""
    fps: float = 0.0
    extra: dict = field(default_factory=dict)

    # 各 timeseries 的频率
    force_fps: float = 0.0
    imu_fps: float = 0.0
    audio_sample_rate: int = 16000

    # State/Action 语义
    state_type: str = ""
    action_type: str = ""
    state_dim_names: list[str] = field(default_factory=list)
    action_dim_names: list[str] = field(default_factory=list)
    observation_series_dim_names: dict[str, list[str]] = field(default_factory=dict)
    action_series_dim_names: dict[str, list[str]] = field(default_factory=dict)

    # 结构化标注
    task_id: str = ""
    quality_rating: int = -1
    user_id: str = ""
    scene_id: str = ""

    # 机器人描述
    urdf_path: str = ""
    joint_names: list[str] = field(default_factory=list)
    camera_extrinsics: dict = field(default_factory=dict)
    camera_intrinsics: dict = field(default_factory=dict)


@runtime_checkable
class EpisodeSource(Protocol):
    """每种源格式实现这个接口"""

    @property
    def dataset_name(self) -> str: ...

    def list_episodes(self) -> list[str]: ...

    def load_episode(self, episode_id: str) -> RawEpisode: ...
