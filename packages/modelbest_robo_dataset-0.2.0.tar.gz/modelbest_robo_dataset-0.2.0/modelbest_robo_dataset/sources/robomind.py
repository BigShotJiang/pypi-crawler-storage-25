"""
RoboMindSource: 从 RoboMIND HDF5 格式读取数据
==============================================
支持三种机器人变体:

  puppet 变体 (franka 双臂遥操作):
    puppet/joint_position 或 puppet/arm_joint_position  → state
    master/joint_position 或 master/arm_joint_position  → action

  franka 变体 (仿真 franka):
    franka/joint_position  → state
    action = state[1:] + state[-1:]  (下一步即目标)

  tiangong 变体 (天工双臂):
    tiangong/left_arm_joint_pos_seq + right_arm_joint_pos_seq  → state
    action = state[1:] + state[-1:]

目录结构 (自动适配):
  成功数据:  h5_{robot}_{N}rgb/{task}/success_episodes/{split}/{ts}/data/trajectory.hdf5
  失败数据:  failure_data/{task_id}-{task_name}/{reason}/{ep_id}/data/trajectory.hdf5
  通用:      任意包含 trajectory.hdf5 的目录树
"""

from __future__ import annotations

import io
import logging
from pathlib import Path

import numpy as np

from .base import RawEpisode

logger = logging.getLogger(__name__)


class RoboMindSource:
    """
    RoboMIND 数据集源

    参数:
        root: 包含 trajectory.hdf5 的目录树根
        name: 数据集名称
        max_episodes: 最大 episode 数
    """

    def __init__(
        self,
        root: str | Path,
        name: str | None = None,
        splits: tuple[str, ...] = ("train",),
        max_episodes: int | None = None,
        urdf_path: str = "",
    ):
        self.root = Path(root)
        self._name = name or self.root.name
        self._splits = splits
        self._max_episodes = max_episodes
        self._urdf_path = urdf_path
        self._episode_paths = self._scan_episodes()
        logger.info(
            f"RoboMindSource: {self._name}, {len(self._episode_paths)} episodes"
        )

    def _scan_episodes(self) -> list[Path]:
        """递归扫描所有 trajectory.hdf5，按路径排序"""
        paths = sorted(self.root.rglob("trajectory.hdf5"))
        if self._max_episodes:
            paths = paths[: self._max_episodes]
        return paths

    @property
    def dataset_name(self) -> str:
        return self._name

    def list_episodes(self) -> list[str]:
        return [str(i) for i in range(len(self._episode_paths))]

    def load_episode(self, episode_id: str) -> RawEpisode:
        import h5py

        ep_idx = int(episode_id)
        h5_path = self._episode_paths[ep_idx]

        with h5py.File(h5_path, "r") as f:
            task = self._read_task(f)
            variant = self._detect_variant(f)
            state, action, joint_names = self._extract_state_action(f, variant)

            video_frames = {}
            rgb_group = f.get("observations/rgb_images")
            if rgb_group:
                for cam_name in sorted(rgb_group.keys()):
                    frames = self._decode_images(rgb_group[cam_name])
                    if frames:
                        video_frames[cam_name] = frames

        n_steps = len(state)
        fps = 10.0
        duration = n_steps / fps

        robot_type = self._infer_robot_type(variant, h5_path)
        task_id = self._infer_task_id(h5_path)
        is_failure = "failure" in str(h5_path)

        return RawEpisode(
            episode_id=episode_id,
            duration=duration,
            video_frames=video_frames,
            state=state,
            action=action,
            task=task,
            robot_type=robot_type,
            dataset_name=self._name,
            dataset_type="real_teleoperation",
            fps=fps,
            state_type="joint_position",
            action_type="absolute_joint",
            state_dim_names=joint_names,
            action_dim_names=joint_names,
            urdf_path=self._urdf_path,
            joint_names=joint_names,
            task_id=task_id,
            quality_rating=0 if is_failure else -1,
            extra={
                "h5_path": str(h5_path),
                "variant": variant,
                "is_failure": is_failure,
            },
        )

    # ── 变体检测 ──

    @staticmethod
    def _detect_variant(f) -> str:
        if "puppet/joint_position" in f or "puppet/arm_joint_position" in f:
            return "puppet"
        if "franka/joint_position" in f:
            return "franka"
        if "tiangong/left_arm_joint_pos_seq" in f:
            return "tiangong"
        return "unknown"

    @staticmethod
    def _extract_state_action(f, variant: str):
        """按变体提取 state/action，返回 (state, action, joint_names)"""
        if variant == "puppet":
            return RoboMindSource._extract_puppet(f)
        if variant == "franka":
            return RoboMindSource._extract_franka(f)
        if variant == "tiangong":
            return RoboMindSource._extract_tiangong(f)
        return RoboMindSource._extract_fallback(f)

    @staticmethod
    def _extract_puppet(f):
        if "puppet/joint_position" in f:
            state = np.array(f["puppet/joint_position"][:], dtype=np.float32)
            action = np.array(f["master/joint_position"][:], dtype=np.float32)
        else:
            arm_s = np.array(f["puppet/arm_joint_position"][:], dtype=np.float32)
            hand_s = np.array(f["puppet/hand_joint_position"][:], dtype=np.float32)
            state = np.concatenate([arm_s, hand_s], axis=1)
            arm_a = np.array(f["master/arm_joint_position"][:], dtype=np.float32)
            hand_a = np.array(f["master/hand_joint_position"][:], dtype=np.float32)
            action = np.concatenate([arm_a, hand_a], axis=1)

        n_j = state.shape[1]
        names = [f"joint{i}" for i in range(n_j - 1)] + ["gripper"]
        return state, action, names

    @staticmethod
    def _extract_franka(f):
        state = np.array(f["franka/joint_position"][:], dtype=np.float32)
        action = np.concatenate([state[1:], state[-1:]], axis=0)
        n_j = state.shape[1]
        names = [f"joint{i}" for i in range(n_j - 1)] + ["gripper"]
        return state, action, names

    @staticmethod
    def _extract_tiangong(f):
        left = np.array(f["tiangong/left_arm_joint_pos_seq"][:], dtype=np.float32)
        right = np.array(f["tiangong/right_arm_joint_pos_seq"][:], dtype=np.float32)
        min_len = min(len(left), len(right))
        state = np.concatenate([left[:min_len], right[:min_len]], axis=1)
        action = np.concatenate([state[1:], state[-1:]], axis=0)
        names = (
            [f"left_j{i}" for i in range(left.shape[1])]
            + [f"right_j{i}" for i in range(right.shape[1])]
        )
        return state, action, names

    @staticmethod
    def _extract_fallback(f):
        """未知变体：尝试找任何数值型 dataset 作为 state"""
        candidates = []
        def _collect(name, obj):
            import h5py as _h5
            if isinstance(obj, _h5.Dataset) and obj.ndim == 2 and obj.dtype.kind == "f":
                candidates.append((name, obj.shape))
        f.visititems(_collect)
        if not candidates:
            state = np.zeros((1, 1), dtype=np.float32)
            return state, state.copy(), ["dim0"]
        best = max(candidates, key=lambda x: x[1][0] * x[1][1])
        state = np.array(f[best[0]][:], dtype=np.float32)
        action = np.concatenate([state[1:], state[-1:]], axis=0)
        names = [f"dim{i}" for i in range(state.shape[1])]
        return state, action, names

    # ── 辅助 ──

    @staticmethod
    def _read_task(f) -> str:
        for key in ("language_raw", "language_instruction"):
            if key not in f:
                continue
            raw = f[key]
            if raw.ndim == 0:
                val = raw[()]
            else:
                val = raw[0]
            if isinstance(val, bytes):
                return val.decode("utf-8")
            return str(val)
        return ""

    @staticmethod
    def _infer_robot_type(variant: str, path: Path) -> str:
        name = str(path).lower()
        if "franka" in name:
            return "franka"
        if "agilex" in name:
            return "agilex"
        if "ur" in name and "ur_" in name:
            return "ur5e"
        if variant == "tiangong" or "tiangong" in name or "tienkung" in name:
            return "tiangong"
        return variant

    @staticmethod
    def _infer_task_id(path: Path) -> str:
        """从路径中提取 task_id

        '135-place_cup...' → 'task_135'
        'chopsticks_into_container' → 'chopsticks_into_container'
        """
        for part in path.parts:
            if "-" in part and part.split("-")[0].isdigit():
                return f"task_{part.split('-')[0]}"
        for part in reversed(path.parts):
            if part not in ("data", "train", "val", "success_episodes") and not part.endswith(".hdf5"):
                return part
        return ""

    @staticmethod
    def _decode_images(cam_dataset) -> list[np.ndarray]:
        from PIL import Image

        frames = []
        for i in range(len(cam_dataset)):
            img_bytes = cam_dataset[i]
            if isinstance(img_bytes, np.ndarray):
                img_bytes = img_bytes.tobytes()
            if not img_bytes or len(img_bytes) < 100:
                continue
            img = Image.open(io.BytesIO(img_bytes))
            frames.append(np.array(img))
        return frames
