"""
FuseSource: 从 fuse TFRecord/RLDS 格式读取数据
"""

from __future__ import annotations

import io
import logging
import wave
from pathlib import Path

import numpy as np

from .base import RawEpisode

logger = logging.getLogger(__name__)


class FuseSource:
    """
    Fuse (digit_dataset) TFRecord 数据源

    参数:
        root: TFRecord 所在目录
        name: 数据集名称
        split: "train" 或 "val"
        max_episodes: 最大 episode 数
    """

    def __init__(
        self,
        root: str | Path,
        name: str = "fuse",
        split: str = "train",
        max_episodes: int | None = None,
        urdf_path: str = "",
    ):
        self.root = Path(root)
        self._name = name
        self._split = split
        self._max_episodes = max_episodes
        self._urdf_path = urdf_path
        self._ds = None
        self._episode_count = 0
        self._load_dataset()

    def _load_dataset(self):
        import tensorflow_datasets as tfds
        import tensorflow as tf
        tf.config.set_visible_devices([], 'GPU')

        builder = tfds.builder_from_directory(str(self.root))
        self._episode_count = builder.info.splits[self._split].num_examples
        if self._max_episodes:
            self._episode_count = min(self._episode_count, self._max_episodes)

        self._ds = builder.as_dataset(split=self._split)
        if self._max_episodes:
            self._ds = self._ds.take(self._max_episodes)

        self._episode_iter = None
        self._episode_cache: dict[int, dict] = {}
        logger.info(f"FuseSource: {self._name}, {self._episode_count} episodes")

    @property
    def dataset_name(self) -> str:
        return self._name

    def list_episodes(self) -> list[str]:
        return [str(i) for i in range(self._episode_count)]

    def load_episode(self, episode_id: str) -> RawEpisode:
        ep_idx = int(episode_id)

        if ep_idx in self._episode_cache:
            episode = self._episode_cache.pop(ep_idx)
        else:
            if self._episode_iter is None:
                self._episode_iter = iter(self._ds)
                self._next_idx = 0
            while self._next_idx <= ep_idx:
                if self._next_idx >= self._episode_count:
                    raise IndexError(f"Episode {ep_idx} out of range (dataset has {self._episode_count} episodes)")
                ep = next(self._episode_iter)
                if self._next_idx == ep_idx:
                    self._episode_cache[self._next_idx] = ep
                self._next_idx += 1
            episode = self._episode_cache.pop(ep_idx, None)
            if episode is None:
                return RawEpisode(episode_id=episode_id, dataset_name=self._name)

        steps = list(episode["steps"])
        if not steps:
            return RawEpisode(episode_id=episode_id, dataset_name=self._name)

        images_0, images_1 = [], []
        states, actions, mic_chunks, imu_data = [], [], [], []
        language = ""

        for step in steps:
            obs = step["observation"]
            if "image_0" in obs:
                images_0.append(obs["image_0"].numpy())
            if "image_1" in obs:
                images_1.append(obs["image_1"].numpy())
            if "state" in obs:
                states.append(obs["state"].numpy())
            if "action" in step:
                actions.append(step["action"].numpy())

            if not language and "language_instruction" in step:
                lang = step["language_instruction"]
                raw = lang.numpy() if hasattr(lang, 'numpy') else lang
                language = raw.decode("utf-8") if isinstance(raw, bytes) else str(raw)

            if "mic" in obs:
                mic_chunks.append(obs["mic"].numpy())

            imu_step = []
            for k in ("imu_euler", "imu_acceleration", "imu_gyro"):
                if k in obs:
                    imu_step.append(obs[k].numpy())
            if imu_step:
                imu_data.append(np.concatenate(imu_step))

        n_steps = len(states) or len(images_0)
        fps = 10.0
        duration = n_steps / fps

        video_frames = {}
        if images_0:
            video_frames["image_0"] = images_0
        if images_1:
            video_frames["image_1"] = images_1

        audio_env = self._mic_to_wav(mic_chunks, 44100) if mic_chunks else None
        imu = np.array(imu_data, dtype=np.float32) if imu_data else None

        return RawEpisode(
            episode_id=episode_id,
            duration=duration,
            video_frames=video_frames,
            state=np.array(states, dtype=np.float32) if states else None,
            action=np.array(actions, dtype=np.float32) if actions else None,
            imu=imu,
            audio_env=audio_env,
            task=language,
            language_instruction=language,
            robot_type="digit_robot",
            dataset_name=self._name,
            dataset_type="real_teleoperation",
            fps=fps,
            imu_fps=fps,
            audio_sample_rate=44100,
            state_type="ee_pose",
            action_type="delta_ee",
            state_dim_names=["x", "y", "z", "rx", "ry", "rz", "gripper"],
            action_dim_names=["dx", "dy", "dz", "drx", "dry", "drz", "gripper"],
            urdf_path=self._urdf_path,
        )

    @staticmethod
    def _mic_to_wav(mic_chunks: list[np.ndarray], sample_rate: int = 44100) -> bytes:
        audio = np.concatenate(mic_chunks).astype(np.float32)
        audio_int16 = (audio * 32767).clip(-32768, 32767).astype(np.int16)
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(audio_int16.tobytes())
        return buf.getvalue()
