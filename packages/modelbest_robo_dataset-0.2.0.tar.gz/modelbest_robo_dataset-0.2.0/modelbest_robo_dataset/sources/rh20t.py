"""
RH20TSource: 从 RH20T 解压目录读取数据
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path

import numpy as np

from .base import RawEpisode

logger = logging.getLogger(__name__)

_DIR_PATTERN = re.compile(
    r"task_(?P<task>\d+)_user_(?P<user>\d+)_scene_(?P<scene>\d+)_cfg_(?P<cfg>\d+)"
)


class RH20TSource:
    """
    RH20T 数据集源

    参数:
        root: 解压后的 RH20T_cfgX 目录
        name: 数据集名称
        cam_ids: 相机 ID 列表 (None=自动检测)
        skip_human: 跳过 _human 后缀目录
    """

    def __init__(
        self,
        root: str | Path,
        name: str | None = None,
        cam_ids: list[str] | None = None,
        skip_human: bool = True,
        urdf_path: str = "",
    ):
        self.root = Path(root)
        self._name = name or self.root.name.lower()
        self._cam_ids = cam_ids
        self._skip_human = skip_human
        self._urdf_path = urdf_path
        self._episode_dirs = self._scan_episodes()
        logger.info(f"RH20TSource: {self._name}, {len(self._episode_dirs)} episodes")

    def _scan_episodes(self) -> list[Path]:
        dirs = []
        for d in sorted(self.root.iterdir()):
            if not d.is_dir() or d.name.startswith("."):
                continue
            if self._skip_human and d.name.endswith("_human"):
                continue
            if not (d / "metadata.json").exists():
                continue
            dirs.append(d)
        return dirs

    @property
    def dataset_name(self) -> str:
        return self._name

    def list_episodes(self) -> list[str]:
        return [d.name for d in self._episode_dirs]

    def load_episode(self, episode_id: str) -> RawEpisode:
        ep_dir = self.root / episode_id
        if not ep_dir.exists():
            ep_dir = next((d for d in self._episode_dirs if d.name == episode_id), None)
            if ep_dir is None:
                raise FileNotFoundError(f"Episode {episode_id} not found")

        with open(ep_dir / "metadata.json") as f:
            meta = json.load(f)

        cam_dirs = self._find_cameras(ep_dir)

        video_files = {}
        for cam_name, cam_dir in cam_dirs.items():
            mp4_path = cam_dir / "color.mp4"
            if mp4_path.exists():
                video_files[cam_name] = str(mp4_path)

        fps = 10.0
        state = self._load_state(ep_dir, cam_dirs)

        # action[t] = state[t+1]: 遥操作中下一帧就是当前目标
        action = None
        if state is not None and len(state) > 1:
            action = np.concatenate([state[1:], state[-1:]], axis=0)

        force = self._load_force(ep_dir, cam_dirs)
        audio_env = self._load_audio(ep_dir)

        duration = 0.0
        if state is not None and len(state) > 0:
            duration = len(state) / fps
        elif "finish_time" in meta:
            for cam_dir in cam_dirs.values():
                ts_path = cam_dir / "timestamps.npy"
                if ts_path.exists():
                    ts = np.load(ts_path, allow_pickle=True)
                    if hasattr(ts, '__len__') and len(ts) > 1:
                        duration = float(max(ts) - min(ts))
                        break
            else:
                duration = float(meta.get("finish_time", 0)) / fps

        task = meta.get("task_description", meta.get("task", ""))

        ee_dims = ["x", "y", "z", "qx", "qy", "qz", "qw"]
        if state is not None and state.shape[1] > 7:
            ee_dims.append("gripper_width")

        task_id, user_id, scene_id = self._parse_dir_ids(episode_id)
        rating = meta.get("rating", -1)
        quality_rating = int(rating) if isinstance(rating, (int, float)) and rating >= 0 else -1

        return RawEpisode(
            episode_id=episode_id,
            duration=duration,
            video_files=video_files,
            state=state,
            action=action,
            force=force,
            audio_env=audio_env,
            task=task,
            robot_type=self._detect_robot_type(),
            dataset_name=self._name,
            dataset_type="real_teleoperation",
            fps=fps,
            force_fps=100.0,
            state_type="ee_pose",
            action_type="absolute_ee",
            state_dim_names=ee_dims,
            action_dim_names=ee_dims,
            urdf_path=self._urdf_path,
            task_id=task_id,
            quality_rating=quality_rating,
            user_id=user_id,
            scene_id=scene_id,
            extra={"metadata": meta},
        )

    def _find_cameras(self, ep_dir: Path) -> dict[str, Path]:
        cams = {}
        for d in sorted(ep_dir.iterdir()):
            if not d.is_dir() or not d.name.startswith("cam_"):
                continue
            if self._cam_ids and d.name not in self._cam_ids:
                continue
            cams[d.name] = d
        return cams

    def _load_state(self, ep_dir: Path, cam_dirs: dict) -> np.ndarray | None:
        transformed = ep_dir / "transformed"
        tcp_path = transformed / "tcp.npy"
        if not tcp_path.exists():
            return None

        tcp_data = np.load(tcp_path, allow_pickle=True)
        tcp_array = self._resolve_per_cam_array(tcp_data, cam_dirs, "tcp")
        if tcp_array is None:
            return None

        gripper_path = transformed / "gripper.npy"
        if gripper_path.exists():
            gripper_data = np.load(gripper_path, allow_pickle=True)
            gripper_widths = self._resolve_gripper(gripper_data, cam_dirs)
            if gripper_widths is not None:
                if tcp_array.ndim == 1:
                    tcp_array = tcp_array.reshape(1, -1)
                min_len = min(len(tcp_array), len(gripper_widths))
                tcp_array = np.concatenate(
                    [tcp_array[:min_len], gripper_widths[:min_len]], axis=1
                )

        return tcp_array

    def _resolve_per_cam_array(
        self, data: np.ndarray, cam_dirs: dict, field_name: str
    ) -> np.ndarray | None:
        if data.dtype == object:
            obj = data.item()
            if isinstance(obj, dict):
                first_cam = next(iter(cam_dirs.keys()), None)
                if not first_cam:
                    return None
                cam_key = first_cam.replace("cam_", "")
                if cam_key not in obj:
                    return None
                entries = obj[cam_key]
                return np.array(
                    [e[field_name].astype(np.float32) for e in entries],
                    dtype=np.float32,
                )
            return data.astype(np.float32)
        return data.astype(np.float32)

    def _resolve_gripper(
        self, data: np.ndarray, cam_dirs: dict
    ) -> np.ndarray | None:
        if data.dtype != object:
            arr = data.astype(np.float32)
            return arr.reshape(-1, 1) / 1000.0 if arr.ndim == 1 else arr / 1000.0

        obj = data.item()
        if not isinstance(obj, dict):
            return None

        first_cam = next(iter(cam_dirs.keys()), None)
        cam_key = first_cam.replace("cam_", "") if first_cam else None
        if not cam_key or cam_key not in obj:
            return None

        inner = obj[cam_key]
        if isinstance(inner, dict):
            sorted_ts = sorted(inner.keys())
            return np.array(
                [inner[ts].get("gripper_info", inner[ts].get("gripper_command", [0]))[0]
                 for ts in sorted_ts],
                dtype=np.float32,
            ).reshape(-1, 1) / 1000.0
        if isinstance(inner, list):
            return np.array(
                [e.get("gripper_info", e.get("gripper_command", [0]))[0] for e in inner],
                dtype=np.float32,
            ).reshape(-1, 1) / 1000.0
        return None

    def _load_force(self, ep_dir: Path, cam_dirs: dict) -> np.ndarray | None:
        force_path = ep_dir / "transformed" / "force_torque.npy"
        if not force_path.exists():
            return None

        data = np.load(force_path, allow_pickle=True)
        if data.dtype == object:
            data = data.item()
        if not isinstance(data, dict):
            return None

        first_cam = next(iter(cam_dirs.keys()), None)
        cam_key = first_cam.replace("cam_", "") if first_cam else next(iter(data.keys()))
        if cam_key not in data:
            cam_key = next(iter(data.keys()))

        inner = data[cam_key]
        if isinstance(inner, list):
            force_array = np.array(
                [entry["zeroed"] for entry in inner if "zeroed" in entry],
                dtype=np.float32,
            )
            return force_array if len(force_array) > 0 else None
        return None

    def _load_audio(self, ep_dir: Path) -> bytes | None:
        audio_dir = ep_dir / "audio_mixed"
        if not audio_dir.exists():
            return None
        wav_files = sorted(audio_dir.glob("*.wav"))
        return wav_files[0].read_bytes() if wav_files else None

    @staticmethod
    def _parse_dir_ids(dirname: str) -> tuple[str, str, str]:
        """从 task_0001_user_0001_scene_0001_cfg_0001 解析出结构化 ID"""
        m = _DIR_PATTERN.match(dirname)
        if not m:
            return "", "", ""
        return (
            f"task_{m.group('task')}",
            f"user_{m.group('user')}",
            f"scene_{m.group('scene')}",
        )

    def _detect_robot_type(self) -> str:
        return f"rh20t_{self.root.name.lower()}"
