"""
LeRobotSource: 从 LeRobot v3.0 格式读取数据
"""

from __future__ import annotations

import json
import logging
from functools import lru_cache
from pathlib import Path

import av
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

from ..dataset_config import (
    SignalSpec,
    action_type_to_timeseries_name,
    state_type_to_timeseries_name,
    timeseries_name_to_action_type,
    timeseries_name_to_state_type,
)
from .base import RawEpisode

logger = logging.getLogger(__name__)


class LeRobotSource:
    """
    LeRobot v3.0 数据集源

    目录结构:
      root/
      ├── data/chunk-000/file-000.parquet
      ├── videos/observation.image/chunk-000/file-000.mp4
      └── meta/
          ├── info.json
          ├── episodes/chunk-000/file-000.parquet
          └── tasks.parquet

    所有数据集特定参数（state_key, action_key, camera_keys, task_key 等）
    由 configs/datasets/<name>.json 显式指定。
    """

    @staticmethod
    def _normalize_keys(key: str | list[str]) -> list[str]:
        """Normalize a key specification to a list of column names.

        Accepts a single string, a ``+``-separated string (legacy), or a
        list of strings.
        """
        if isinstance(key, list):
            return key
        return [k.strip() for k in key.split("+")]

    def __init__(
        self,
        root: str | Path,
        *,
        state_type: str = "",
        action_type: str = "",
        state_key: str | None = None,
        action_key: str | None = None,
        camera_keys: list[str] | None = None,
        observation_specs: list[SignalSpec] | None = None,
        action_specs: list[SignalSpec] | None = None,
        task_key: str | None = None,
        task_fallback_column: str | None = None,
        lazy: bool = False,
        name: str | None = None,
        urdf_path: str = "",
    ):
        self.root = Path(root)
        self._name = name or self.root.name
        self._state_type = state_type
        self._action_type = action_type
        self._urdf_path = urdf_path
        self._state_key = state_key
        self._action_key = action_key
        self._camera_keys = list(camera_keys) if camera_keys else []
        self._task_key = task_key
        self._task_fallback_column = task_fallback_column
        self._lazy = lazy

        with open(self.root / "meta" / "info.json") as f:
            self.info = json.load(f)

        self.fps = self.info["fps"]
        self.robot_type = self.info.get("robot_type", "unknown")
        self.total_episodes = self.info["total_episodes"]
        self._episodes_df = None
        self._has_episode_meta = False

        meta_dir = self.root / "meta" / "episodes"
        if meta_dir.is_dir():
            self._has_episode_meta = True
        if self._has_episode_meta and not self._lazy:
            ep_files = sorted(meta_dir.rglob("*.parquet"))
            self._episodes_df = self._read_parquet_dataset(ep_files, "meta/episodes")
            self._available_episode_ids = self._build_available_episode_ids()
        else:
            self._available_episode_ids = list(range(int(self.total_episodes)))
            if not self._has_episode_meta:
                logger.info(
                    "LeRobotSource: %s has no meta/episodes; fallback to total_episodes range",
                    self.root,
                )

        tasks_parquet = self.root / "meta" / "tasks.parquet"
        if tasks_parquet.exists():
            self._tasks_df = self._normalize_tasks_df(
                pq.read_table(str(tasks_parquet)).to_pandas(),
                task_key=self._task_key,
            )
        else:
            self._tasks_df = None

        features = self.info.get("features", {})
        if not self._camera_keys:
            self._camera_keys = self._infer_camera_keys(features)

        self._observation_specs = self._normalize_signal_specs(
            observation_specs,
            fallback_key=self._state_key,
            fallback_timeseries_name=state_type_to_timeseries_name(self._state_type),
        )
        self._action_specs = self._normalize_signal_specs(
            action_specs,
            fallback_key=self._action_key,
            fallback_timeseries_name=action_type_to_timeseries_name(self._action_type),
        )
        self._primary_observation_spec = self._pick_primary_spec(
            self._observation_specs,
            preferred=[
                "env.obs.joint_position",
                "env.obs.cartesian_position",
                "env.obs.gripper_position",
                "env.obs.joint_velocity",
                "env.obs.joint_effort",
            ],
        )
        self._primary_action_spec = self._pick_primary_spec(
            self._action_specs,
            preferred=[
                "ai.action.delta_joint_position",
                "ai.action.joint_position",
                "ai.action.delta_cartesian_position",
                "ai.action.cartesian_position",
                "ai.action.delta_gripper_position",
                "ai.action.gripper_position",
                "ai.action.joint_velocity",
                "ai.action.joint_effort",
            ],
        )
        if self._primary_observation_spec is not None:
            if not self._state_type:
                self._state_type = timeseries_name_to_state_type(
                    self._primary_observation_spec.timeseries_name
                )
            if not self._state_key and self._primary_observation_spec.keys:
                self._state_key = self._primary_observation_spec.keys[0]
        if self._primary_action_spec is not None:
            if not self._action_type:
                self._action_type = timeseries_name_to_action_type(
                    self._primary_action_spec.timeseries_name
                )
            if not self._action_key and self._primary_action_spec.keys:
                self._action_key = self._primary_action_spec.keys[0]

        lazy_tag = ", lazy=True" if self._lazy else ""
        state_desc = self._state_key
        action_desc = self._action_key
        logger.info(
            f"LeRobotSource: {self._name}, {self.total_episodes} eps, "
            f"{self.fps}fps, cameras={self._camera_keys}, "
            f"state={state_desc}, action={action_desc}, "
            f"state_type={self._state_type}, action_type={self._action_type}"
            f"{lazy_tag}"
        )

    @property
    def dataset_name(self) -> str:
        return self._name

    def list_episodes(self) -> list[str]:
        return [str(i) for i in self._available_episode_ids]

    def episode_frame_counts(self) -> list[int]:
        """每个源 episode 在 data 表中的行数。"""
        if self._episodes_df is not None and "length" in self._episodes_df.columns:
            length_map = dict(zip(
                self._episodes_df["episode_index"].astype(int),
                self._episodes_df["length"].astype(int),
            ))
            return [length_map.get(eid, 0) for eid in self._available_episode_ids]
        counts: list[int] = []
        for ep_idx in self._available_episode_ids:
            ep_data = self._get_episode_data(ep_idx)
            counts.append(len(ep_data) if ep_data is not None else 0)
        return counts

    # ── parquet I/O ──────────────────────────────────────────────────

    @staticmethod
    def _read_parquet_dataset(files: list[Path], label: str):
        if not files:
            raise FileNotFoundError(f"no parquet files found under {label}")
        file_strs = [str(f) for f in files]
        try:
            return pq.read_table(file_strs).to_pandas()
        except Exception as exc:
            logger.warning(
                "LeRobotSource: batch read failed for %s (%d files), fallback to per-file: %s",
                label, len(files), exc,
            )
        good_tables = []
        for fp in files:
            try:
                good_tables.append(pq.read_table(str(fp)))
            except Exception:
                logger.warning("LeRobotSource: skip broken %s file %s", label, fp)
        if not good_tables:
            raise RuntimeError(f"all parquet files under {label} are unreadable")
        return pa.concat_tables(good_tables).to_pandas()

    @staticmethod
    def _build_parquet_ep_index(base_dir: Path) -> dict[int, str]:
        """Map episode_index → parquet file path (reads only the episode_index column)."""
        index: dict[int, str] = {}
        if not base_dir.is_dir():
            return index
        for chunk_dir in sorted(base_dir.iterdir()):
            if not chunk_dir.is_dir():
                continue
            for fpath in sorted(chunk_dir.glob("*.parquet")):
                try:
                    col = pq.read_table(str(fpath), columns=["episode_index"])
                    for eid in col.column("episode_index").unique().to_pylist():
                        index[int(eid)] = str(fpath)
                except Exception:
                    continue
        return index

    @lru_cache(maxsize=8)
    def _read_shared_file(self, path: str) -> pd.DataFrame:
        return pq.read_table(path).to_pandas()

    # ── episode metadata ─────────────────────────────────────────────

    def _build_available_episode_ids(self) -> list[int]:
        if self._episodes_df is None:
            return []
        if "episode_index" in self._episodes_df.columns:
            return sorted(int(e) for e in self._episodes_df["episode_index"].dropna().unique())
        return list(range(len(self._episodes_df)))

    def _get_episode_meta(self, ep_idx: int):
        if not self._has_episode_meta:
            return {}
        if self._lazy:
            if not hasattr(self, "_ep_meta_file_index"):
                self._ep_meta_file_index = self._build_parquet_ep_index(
                    self.root / "meta" / "episodes"
                )
            fpath = self._ep_meta_file_index.get(ep_idx)
            if fpath is None:
                return {}
            df = self._read_shared_file(fpath)
            if "episode_index" in df.columns:
                matched = df[df["episode_index"] == ep_idx]
                if not matched.empty:
                    return matched.iloc[0]
            return {}

        matched = self._episodes_df[self._episodes_df["episode_index"] == ep_idx]
        if matched.empty:
            raise IndexError(f"episode {ep_idx} not found in meta/episodes")
        return matched.iloc[0]

    # ── episode data ─────────────────────────────────────────────────

    def _get_episode_data(self, ep_idx: int) -> pd.DataFrame | None:
        if not hasattr(self, "_ep_data_file_index"):
            self._ep_data_file_index = self._build_parquet_ep_index(self.root / "data")
            logger.info("LeRobotSource: data index — %d episodes across %d files",
                         len(self._ep_data_file_index), len(set(self._ep_data_file_index.values())))
        fpath = self._ep_data_file_index.get(ep_idx)
        if fpath is None:
            return None
        df = self._read_shared_file(fpath)
        if "episode_index" in df.columns:
            return df[df["episode_index"] == ep_idx]
        return None

    # ── task resolution ──────────────────────────────────────────────

    @staticmethod
    def _normalize_tasks_df(
        df: pd.DataFrame | None, *, task_key: str | None = None
    ) -> pd.DataFrame | None:
        """Ensure a ``task`` column exists.

        *task_key* (from config):
        - ``"index"`` — promote DataFrame index via ``reset_index``.
        - other string — rename that column to ``task``.
        - ``None`` — assume ``task`` column already exists.
        """
        if df is None or len(df) == 0:
            return df
        if task_key == "index":
            out = df.reset_index()
            rename_col = [c for c in out.columns if c not in df.columns]
            if rename_col:
                return out.rename(columns={rename_col[0]: "task"})
            return out
        if task_key and task_key != "task" and task_key in df.columns:
            return df.rename(columns={task_key: "task"})
        return df

    def _resolve_task(self, ep_meta, ep_data=None) -> str:
        """Resolve natural-language task string.

        Priority:
        1. Episode meta ``tasks`` list
        2. Episode meta ``task_index`` → tasks_df
        3. Data rows ``task_index`` → tasks_df
        4. tasks_df first row (single-task fallback)
        """
        raw = ep_meta.get("tasks", []) if hasattr(ep_meta, "get") else []
        tasks_list = raw if isinstance(raw, (list, np.ndarray)) else []
        if len(tasks_list) > 0:
            task_val = tasks_list[0]
            if isinstance(task_val, str) and task_val.strip():
                return task_val
            if isinstance(task_val, (int, np.integer)) and self._tasks_df is not None and "task" in self._tasks_df.columns:
                row = self._tasks_df[self._tasks_df["task_index"] == int(task_val)]
                if len(row) > 0:
                    t = str(row.iloc[0]["task"] or "")
                    if t.strip():
                        return t

        if self._tasks_df is None or len(self._tasks_df) == 0:
            return ""

        task_index = ep_meta.get("task_index") if hasattr(ep_meta, "get") else None
        if task_index is not None and not (isinstance(task_index, float) and pd.isna(task_index)):
            if "task" in self._tasks_df.columns:
                row = self._tasks_df[self._tasks_df["task_index"] == int(task_index)]
                if len(row) > 0:
                    t = str(row.iloc[0]["task"] or "")
                    if t.strip():
                        return t

        if ep_data is not None and "task_index" in ep_data.columns and "task" in self._tasks_df.columns:
            ti = ep_data["task_index"].dropna()
            if len(ti) > 0:
                ti_val = int(ti.iloc[0])
                row = self._tasks_df[self._tasks_df["task_index"] == ti_val]
                if len(row) > 0:
                    t = str(row.iloc[0]["task"] or "")
                    if t.strip():
                        return t

        if "task" in self._tasks_df.columns:
            return str(self._tasks_df.iloc[0]["task"] or "")
        return ""

    # ── video resolution ─────────────────────────────────────────────

    def _resolve_cam_video(
        self, cam_key: str, ep_meta
    ) -> tuple[Path | None, float, float | None]:
        if not hasattr(ep_meta, "get"):
            return None, 0.0, None
        video_col_prefix = f"videos/{cam_key}"
        chunk_idx = int(ep_meta.get(f"{video_col_prefix}/chunk_index", 0))
        file_idx = int(ep_meta.get(f"{video_col_prefix}/file_index", 0))
        from_ts = float(ep_meta.get(f"{video_col_prefix}/from_timestamp", 0.0) or 0.0)
        raw_to_ts = ep_meta.get(f"{video_col_prefix}/to_timestamp", None)
        to_ts = None
        if raw_to_ts is not None and not pd.isna(raw_to_ts):
            to_ts = float(raw_to_ts)
        tpl = self.info.get(
            "video_path",
            "videos/{video_key}/chunk-{chunk_index:03d}/file-{file_index:03d}.mp4",
        )
        video_path = self.root / tpl.format(
            video_key=cam_key, chunk_index=chunk_idx, file_index=file_idx,
        )
        if video_path.is_file():
            return video_path, from_ts, to_ts
        return None, from_ts, to_ts

    def _decode_video_range(
        self, video_path: Path, from_ts: float, to_ts: float | None
    ) -> list[np.ndarray]:
        frames: list[np.ndarray] = []
        container = av.open(str(video_path))
        try:
            # print(from_ts,to_ts)
            # if (from_ts == 497.40000000000003 and to_ts==503.85 ):
            #     return frames
            if not container.streams.video:
                return frames
            stream = container.streams.video[0]
            if from_ts > 0 and stream.time_base and stream.time_base > 0:
                container.seek(int(from_ts / stream.time_base), stream=stream)
            for frame in container.decode(video=0):
                pts = (
                    float(frame.time)
                    if frame.time is not None
                    else float(frame.pts * stream.time_base)
                    if frame.pts is not None and stream.time_base
                    else None
                )
                if pts is None:
                    continue
                if to_ts is not None and pts > to_ts + 0.01:
                    break
                if pts >= from_ts - 0.01:
                    frames.append(frame.to_ndarray(format="rgb24"))

        # except av.error.InvalidDataError:
        #     return frames
        finally:
            container.close()
        return frames

    @staticmethod
    def _infer_camera_keys(features: dict) -> list[str]:
        out: list[str] = []
        for key, meta in features.items():
            if isinstance(meta, dict) and meta.get("dtype") == "video":
                out.append(key)
        return sorted(out)

    @staticmethod
    def _normalize_signal_specs(
        specs: list[SignalSpec] | None,
        *,
        fallback_key: str | None,
        fallback_timeseries_name: str,
    ) -> list[SignalSpec]:
        normalized: list[SignalSpec] = []
        for spec in specs or []:
            keys = [str(k) for k in spec.keys if str(k).strip()]
            if not spec.timeseries_name or not keys:
                continue
            normalized.append(SignalSpec(timeseries_name=spec.timeseries_name, keys=keys))
        if not normalized and fallback_key:
            normalized.append(
                SignalSpec(timeseries_name=fallback_timeseries_name, keys=[fallback_key])
            )
        return normalized

    @staticmethod
    def _pick_primary_spec(
        specs: list[SignalSpec],
        *,
        preferred: list[str],
    ) -> SignalSpec | None:
        if not specs:
            return None
        for ts_name in preferred:
            for spec in specs:
                if spec.timeseries_name == ts_name:
                    return spec
        return specs[0]

    @staticmethod
    def _key_side_prefix(key: str) -> str:
        lower = key.lower()
        if lower.endswith("_left") or ".left" in lower:
            return "left"
        if lower.endswith("_right") or ".right" in lower:
            return "right"
        return ""

    def _series_dim_names_for_key(self, features: dict, key: str, width: int) -> list[str]:
        names = self._extract_dim_names(features, key)
        if not names:
            if width <= 0:
                return []
            names = [f"dim_{i}" for i in range(width)]
        prefix = self._key_side_prefix(key)
        if prefix:
            return [f"{prefix}_{name}" for name in names]
        return names

    def _load_series_from_specs(
        self,
        ep_data: pd.DataFrame,
        specs: list[SignalSpec],
        *,
        features: dict,
    ) -> tuple[dict[str, np.ndarray], dict[str, list[str]]]:
        series: dict[str, np.ndarray] = {}
        dim_names: dict[str, list[str]] = {}
        for spec in specs:
            arrays: list[np.ndarray] = []
            names: list[str] = []
            for key in spec.keys:
                if key not in ep_data.columns:
                    continue
                arr = np.array(ep_data[key].tolist(), dtype=np.float32)
                if arr.ndim == 1:
                    arr = arr[:, None]
                arrays.append(arr)
                names.extend(self._series_dim_names_for_key(features, key, arr.shape[1]))
            if not arrays:
                continue
            target_len = min(len(arr) for arr in arrays)
            if any(len(arr) != target_len for arr in arrays):
                logger.warning(
                    "LeRobotSource: series %s length mismatch for keys=%s; truncate to %d",
                    spec.timeseries_name,
                    spec.keys,
                    target_len,
                )
            trimmed = [arr[:target_len] for arr in arrays]
            merged = np.concatenate(trimmed, axis=1) if len(trimmed) > 1 else trimmed[0]
            series[spec.timeseries_name] = merged
            if names:
                dim_names[spec.timeseries_name] = names
        return series, dim_names

    @staticmethod
    def _read_concat_keys(df: pd.DataFrame, keys: list[str]) -> np.ndarray | None:
        """Read one or more columns and concatenate along the last axis.

        Given ``["colA", "colB"]``, reads both and produces shape
        ``(N, dim_A + dim_B)``.  A single-element list works as before.
        """
        parts = []
        for k in keys:
            if k not in df.columns:
                return None
            parts.append(np.array(df[k].tolist(), dtype=np.float32))
        if not parts:
            return None
        return np.concatenate(parts, axis=-1) if len(parts) > 1 else parts[0]

    # ── main entry point ─────────────────────────────────────────────

    def load_episode(self, episode_id: str) -> RawEpisode:
        ep_idx = int(episode_id)
        ep_meta = self._get_episode_meta(ep_idx)

        ep_data = self._get_episode_data(ep_idx)
        if ep_data is None:
            raise ValueError(f"episode {ep_idx} has no readable rows in data parquet files")
        n_frames = len(ep_data)
        duration = n_frames / self.fps if self.fps > 0 else 0
        features = self.info.get("features", {})

        observation_series, observation_dim_names = self._load_series_from_specs(
            ep_data,
            self._observation_specs,
            features=features,
        )
        action_series, action_dim_names = self._load_series_from_specs(
            ep_data,
            self._action_specs,
            features=features,
        )
        state = None
        state_dim_names: list[str] = []
        if self._primary_observation_spec is not None:
            state = observation_series.get(self._primary_observation_spec.timeseries_name)
            state_dim_names = observation_dim_names.get(
                self._primary_observation_spec.timeseries_name,
                [],
            )

        action = None
        action_dim_names_primary: list[str] = []
        if self._primary_action_spec is not None:
            action = action_series.get(self._primary_action_spec.timeseries_name)
            action_dim_names_primary = action_dim_names.get(
                self._primary_action_spec.timeseries_name,
                [],
            )

        video_frames: dict[str, list[np.ndarray]] = {}
        for cam_key in self._camera_keys:
            video_path, from_ts, to_ts = self._resolve_cam_video(cam_key, ep_meta)
            if video_path is not None:
                if to_ts is None or to_ts <= from_ts:
                    to_ts = from_ts + duration if duration > 0 else None
                frames = self._decode_video_range(video_path, from_ts, to_ts)
                if not frames:
                     raise ValueError(f"Video decode failed for camera {cam_key} in episode {episode_id}")
                cam_short = cam_key.replace("observation.", "").replace("images.", "")
                video_frames[cam_short] = frames

        task = self._resolve_task(ep_meta, ep_data)
        if not task or not str(task).strip():
            if self._task_fallback_column and self._task_fallback_column in ep_data.columns:
                li = ep_data[self._task_fallback_column].dropna().astype(str).str.strip()
                li = li[li != ""]
                if len(li) > 0:
                    task = str(li.iloc[0])

        kwargs: dict = dict(
            episode_id=episode_id,
            duration=duration,
            video_frames=video_frames,
            state=state,
            action=action,
            observation_series=observation_series,
            action_series=action_series,
            task=task,
            robot_type=self.robot_type,
            dataset_name=self._name,
            dataset_type="simulation" if "sim" in self._name.lower() else "real_teleoperation",
            fps=self.fps,
            state_type=self._state_type,
            action_type=self._action_type,
            state_dim_names=state_dim_names,
            action_dim_names=action_dim_names_primary,
            observation_series_dim_names=observation_dim_names,
            action_series_dim_names=action_dim_names,
        )
        if self._urdf_path and hasattr(RawEpisode, "__dataclass_fields__") and "urdf_path" in RawEpisode.__dataclass_fields__:
            kwargs["urdf_path"] = self._urdf_path
        return RawEpisode(**kwargs)

    # ── utilities ────────────────────────────────────────────────────

    @staticmethod
    def _extract_dim_names(features: dict, key: str | None) -> list[str]:
        if not key or key not in features:
            return []
        names_obj = features[key].get("names", {})
        if names_obj is None:
            return []
        if isinstance(names_obj, dict):
            return list(names_obj.get("motors") or names_obj.get("axes") or [])
        if isinstance(names_obj, list):
            if len(names_obj) == 1 and isinstance(names_obj[0], list):
                return list(names_obj[0])
            return list(names_obj)
        return []
