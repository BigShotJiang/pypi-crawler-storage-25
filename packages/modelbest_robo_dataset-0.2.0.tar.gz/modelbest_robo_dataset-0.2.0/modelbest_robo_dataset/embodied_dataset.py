"""
具身智能训练数据集封装
====================
将统一格式的骨架、Parquet 和 MP4 组合成 PyTorch Dataset，供训练阶段直接读取。
"""

from __future__ import annotations

from pathlib import Path

import av
import numpy as np
import torch
from torch.utils.data import Dataset

from .data_types import (
    AiMessage,
    EnvMessage,
    MetaContent,
    TextContent,
    TimeseriesContent,
    VideoContent,
)
from .reader import EmbodiedReader, _pad_action_chunk, _resolve_action_chunk_size


class EmbodiedDataset(Dataset):
    """
    训练用 PyTorch Dataset。

    SSTable 一行 = 一个样本，直接按骨架中 ref 的 from_ts/to_ts 定位数据。
    不论是 episode 级还是帧级骨架，读法完全一样。

    用法:
        # 默认读 skeleton_episode/
        dataset = EmbodiedDataset(root="/path/to/data", dataset_name="pusht")

        # 读 skeleton_single_frame/（帧级骨架，推荐训练用）
        dataset = EmbodiedDataset(
            root="/path/to/data",
            dataset_name="pusht",
            skeleton_dir="/path/to/data/skeleton_single_frame/pusht",
        )
        sample = dataset[0]
    """

    def __init__(
        self,
        root: str | Path,
        dataset_name: str,
        action_chunk_size: int | None = None,
        skeleton_dir: str | Path | None = None,
    ):
        self.root = Path(root)
        self.action_chunk_size = action_chunk_size
        self._reader = EmbodiedReader(root, dataset_name, skeleton_dir=skeleton_dir)

    def __len__(self) -> int:
        return len(self._reader)

    def __getitem__(self, idx: int) -> dict:
        ep = self._reader.get_episode(idx)

        item: dict = {
            "episode_index": ep.episode_index,
        }

        for msg in ep.messages:
            for content in msg.content:
                if isinstance(content, MetaContent):
                    item["task"] = content.task

                elif isinstance(content, VideoContent) and content.ref:
                    ref = content.ref
                    cam = Path(ref.file).parent.name
                    frame = self._decode_video_frame(ref.file, ref.to_ts)
                    if frame is not None:
                        item[f"video.{cam}"] = frame

                elif isinstance(content, TimeseriesContent) and content.ref:
                    ref = content.ref
                    raw = self._reader._load_parquet_row(ref.file, ref.row)
                    ep_data = (
                        np.stack(raw).astype(np.float32)
                        if hasattr(raw[0], "__len__")
                        else np.array(raw, dtype=np.float32)
                    )

                    if "action" in content.name:
                        start = int(ref.from_ts * ref.fps) if ref.fps > 0 else 0
                        start = min(start, len(ep_data) - 1)
                        chunk_size = _resolve_action_chunk_size(
                            ref,
                            self.action_chunk_size,
                            len(ep_data),
                            start,
                        )
                        end = min(start + chunk_size, len(ep_data))
                        chunk = ep_data[start:end]
                        if len(chunk) < chunk_size:
                            chunk = _pad_action_chunk(chunk, chunk_size, content.name)
                        item[content.name] = torch.from_numpy(chunk)
                    else:
                        frame_idx = int(ref.to_ts * ref.fps) if ref.fps > 0 else 0
                        frame_idx = min(frame_idx, len(ep_data) - 1)
                        item[content.name] = torch.from_numpy(ep_data[frame_idx])

                elif isinstance(content, TextContent) and content.text:
                    if isinstance(msg, EnvMessage):
                        item.setdefault("env.text", content.text)
                    elif isinstance(msg, AiMessage):
                        item.setdefault("ai.reasoning", content.text)

        return item

    def _decode_video_frame(self, file: str, abs_ts: float) -> torch.Tensor | None:
        path = self.root / file
        if not path.exists():
            return None

        with av.open(str(path)) as container:
            if not container.streams.video:
                return None
            stream = container.streams.video[0]
            if stream.time_base and stream.time_base > 0:
                container.seek(int(abs_ts / stream.time_base), stream=stream)
            for frame in container.decode(video=0):
                arr = frame.to_ndarray(format="rgb24")
                return torch.from_numpy(arr).permute(2, 0, 1)
        return None


__all__ = ["EmbodiedDataset"]
