"""
Per-dataset configuration registry.

Each JSON file in ``configs/datasets/<name>.json`` defines key mappings,
state/action types, and conversion options for a LeRobot dataset.

Usage::

    from modelbest_robo_dataset.dataset_config import load_dataset_config, list_dataset_configs

    cfg = load_dataset_config("libero")
    if cfg:
        src = LeRobotSource(root, state_type=cfg.state_type, action_type=cfg.action_type,
                            state_key=cfg.state_key, action_key=cfg.action_key,
                            camera_keys=cfg.camera_keys, task_key=cfg.task_key)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

_CONFIGS_DIR = Path(__file__).resolve().parent.parent / "configs" / "datasets"


@dataclass
class SignalSpec:
    timeseries_name: str
    keys: list[str] = field(default_factory=list)


@dataclass
class DatasetConfig:
    state_type: str = ""
    action_type: str = ""
    state_key: str | list[str] | None = None
    action_key: str | list[str] | None = None
    robot_type: str | None = None
    urdf_path: str = ""
    camera_keys: list[str] | None = None
    task_key: str | None = None
    task_fallback_column: str | None = None
    lazy: bool = False
    max_episodes: int | None = None
    one_frame_per_episode: bool = False
    shuffle_seed: int | None = None
    action_chunk: int = 50
    description: str = ""
    observation_specs: list[SignalSpec] = field(default_factory=list)
    action_specs: list[SignalSpec] = field(default_factory=list)


def normalize_state_type(value: str | None) -> str:
    """Normalize external state_type aliases to internal canonical names."""
    if not value:
        return ""

    normalized = value.strip().lower().replace("-", "_")
    aliases = {
        "joint": "joint_position",
        "joint_position": "joint_position",
        "cartesian": "ee_pose",
        "cartesian_position": "ee_pose",
        "ee": "ee_pose",
        "eef": "ee_pose",
        "ee_pose": "ee_pose",
        "gripper": "gripper_position",
        "gripper_position": "gripper_position",
        "joint_velocity": "joint_velocity",
        "joint_effort": "joint_effort",
    }
    return aliases.get(normalized, normalized)


def normalize_action_type(value: str | None) -> str:
    """Normalize external action_type aliases to internal canonical names."""
    if not value:
        return ""

    normalized = value.strip().lower().replace("-", "_")
    aliases = {
        "joint_position": "absolute_joint",
        "absolute_joint": "absolute_joint",
        "cartesian_position": "absolute_ee",
        "absolute_cartesian_position": "absolute_ee",
        "absolute_ee": "absolute_ee",
        "delta_joint_position": "delta_joint",
        "delta_joint": "delta_joint",
        "delta_cartesian_position": "delta_ee",
        "delta_cartesian": "delta_ee",
        "delta_eef": "delta_ee",
        "delta_ee": "delta_ee",
        "gripper_position": "absolute_gripper",
        "absolute_gripper_position": "absolute_gripper",
        "absolute_gripper": "absolute_gripper",
        "delta_gripper_position": "delta_gripper",
        "delta_gripper": "delta_gripper",
        "joint_velocity": "joint_velocity",
        "joint_effort": "joint_effort",
    }
    return aliases.get(normalized, normalized)


STATE_TYPE_TO_TIMESERIES_NAME = {
    "joint_position": "env.obs.joint_position",
    "ee_pose": "env.obs.cartesian_position",
    "gripper_position": "env.obs.gripper_position",
    "joint_velocity": "env.obs.joint_velocity",
    "joint_effort": "env.obs.joint_effort",
}

ACTION_TYPE_TO_TIMESERIES_NAME = {
    "absolute_joint": "ai.action.joint_position",
    "absolute_ee": "ai.action.cartesian_position",
    "delta_joint": "ai.action.delta_joint_position",
    "delta_ee": "ai.action.delta_cartesian_position",
    "absolute_gripper": "ai.action.gripper_position",
    "delta_gripper": "ai.action.delta_gripper_position",
    "joint_velocity": "ai.action.joint_velocity",
    "joint_effort": "ai.action.joint_effort",
}

TIMESERIES_NAME_TO_STATE_TYPE = {
    "env.obs.joint_position": "joint_position",
    "env.obs.cartesian_position": "ee_pose",
    "env.obs.gripper_position": "gripper_position",
    "env.obs.joint_velocity": "joint_velocity",
    "env.obs.joint_effort": "joint_effort",
}

TIMESERIES_NAME_TO_ACTION_TYPE = {
    "ai.action.joint_position": "absolute_joint",
    "ai.action.cartesian_position": "absolute_ee",
    "ai.action.delta_joint_position": "delta_joint",
    "ai.action.delta_cartesian_position": "delta_ee",
    "ai.action.gripper_position": "absolute_gripper",
    "ai.action.delta_gripper_position": "delta_gripper",
    "ai.action.joint_velocity": "joint_velocity",
    "ai.action.joint_effort": "joint_effort",
}


def state_type_to_timeseries_name(value: str | None) -> str:
    normalized = normalize_state_type(value)
    return STATE_TYPE_TO_TIMESERIES_NAME.get(normalized, "env.obs.joint_position")


def action_type_to_timeseries_name(value: str | None) -> str:
    normalized = normalize_action_type(value)
    return ACTION_TYPE_TO_TIMESERIES_NAME.get(normalized, "ai.action.joint_position")


def timeseries_name_to_state_type(name: str | None) -> str:
    if not name:
        return ""
    return TIMESERIES_NAME_TO_STATE_TYPE.get(name, "")


def timeseries_name_to_action_type(name: str | None) -> str:
    if not name:
        return ""
    return TIMESERIES_NAME_TO_ACTION_TYPE.get(name, "")


def _coerce_signal_specs(raw_specs: object) -> list[SignalSpec]:
    specs: list[SignalSpec] = []
    if not isinstance(raw_specs, list):
        return specs
    for item in raw_specs:
        if not isinstance(item, dict):
            continue
        ts_name = str(item.get("timeseries_name") or "").strip()
        if not ts_name:
            continue
        keys_obj = item.get("keys")
        if isinstance(keys_obj, str):
            keys = [keys_obj]
        elif isinstance(keys_obj, list):
            keys = [str(k) for k in keys_obj if str(k).strip()]
        else:
            key = str(item.get("key") or "").strip()
            keys = [key] if key else []
        specs.append(SignalSpec(timeseries_name=ts_name, keys=keys))
    return specs


def load_dataset_config(
    name: str, configs_dir: str | Path | None = None
) -> DatasetConfig | None:
    """Load ``configs/datasets/<name>.json`` and return a `DatasetConfig`.

    Returns ``None`` if the file does not exist.
    """
    base = Path(configs_dir) if configs_dir else _CONFIGS_DIR
    path = base / f"{name}.json"
    if not path.is_file():
        return None
    with open(path) as f:
        raw = json.load(f)
    known_fields = {f.name for f in DatasetConfig.__dataclass_fields__.values()}
    filtered = {k: v for k, v in raw.items() if k in known_fields}
    filtered["state_type"] = normalize_state_type(filtered.get("state_type"))
    filtered["action_type"] = normalize_action_type(filtered.get("action_type"))
    filtered["observation_specs"] = _coerce_signal_specs(filtered.get("observation_specs"))
    filtered["action_specs"] = _coerce_signal_specs(filtered.get("action_specs"))

    if not filtered["observation_specs"] and filtered.get("state_key"):
        filtered["observation_specs"] = [
            SignalSpec(
                timeseries_name=state_type_to_timeseries_name(filtered.get("state_type")),
                keys=[str(filtered["state_key"])],
            )
        ]
    if not filtered["action_specs"] and filtered.get("action_key"):
        filtered["action_specs"] = [
            SignalSpec(
                timeseries_name=action_type_to_timeseries_name(filtered.get("action_type")),
                keys=[str(filtered["action_key"])],
            )
        ]

    if not filtered.get("state_key") and filtered["observation_specs"]:
        first_obs = filtered["observation_specs"][0]
        filtered["state_key"] = first_obs.keys[0] if first_obs.keys else None
    if not filtered.get("action_key") and filtered["action_specs"]:
        first_act = filtered["action_specs"][0]
        filtered["action_key"] = first_act.keys[0] if first_act.keys else None
    if not filtered.get("state_type") and filtered["observation_specs"]:
        filtered["state_type"] = timeseries_name_to_state_type(
            filtered["observation_specs"][0].timeseries_name
        )
    if not filtered.get("action_type") and filtered["action_specs"]:
        filtered["action_type"] = timeseries_name_to_action_type(
            filtered["action_specs"][0].timeseries_name
        )
    return DatasetConfig(**filtered)


def list_dataset_configs(configs_dir: str | Path | None = None) -> list[str]:
    """Return sorted names of all available dataset configs (without ``.json``)."""
    base = Path(configs_dir) if configs_dir else _CONFIGS_DIR
    if not base.is_dir():
        return []
    return sorted(p.stem for p in base.glob("*.json"))
