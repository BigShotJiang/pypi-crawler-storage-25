"""
EmbodiedReader: 从统一格式读取和验证数据
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import av
import numpy as np
import pyarrow.parquet as pq

from .data_types import (
    AudioContent,
    EnvMessage,
    Episode,
    MetaContent,
    TextContent,
    TimeseriesContent,
    VideoContent,
)
from .sstable_record import decode_episode_record

logger = logging.getLogger(__name__)


def _resolve_action_chunk_size(ref, override: int | None, total_steps: int, start_idx: int) -> int:
    if override is not None:
        if override <= 0:
            raise ValueError("action_chunk_size must be greater than 0")
        return override

    if ref.fps > 0:
        inferred = int(round((ref.to_ts - ref.from_ts) * ref.fps))
        if inferred > 0:
            return inferred

    return max(1, total_steps - start_idx)


def _should_zero_pad_action(action_name: str) -> bool:
    normalized = action_name.strip().lower()
    return ".delta_" in normalized or normalized.startswith("delta_")


def _pad_action_chunk(
    chunk: np.ndarray,
    target_size: int,
    action_name: str,
) -> np.ndarray:
    if target_size <= len(chunk):
        return chunk
    if len(chunk) == 0:
        raise ValueError("cannot pad an empty action chunk")

    pad_size = target_size - len(chunk)
    if _should_zero_pad_action(action_name):
        pad_shape = (pad_size, *chunk.shape[1:])
        pad = np.zeros(pad_shape, dtype=chunk.dtype)
    else:
        pad = np.repeat(chunk[-1:], pad_size, axis=0)
    return np.concatenate([chunk, pad], axis=0)


class EmbodiedReader:
    """
    读取转换后的数据集。SSTable 每行是一个 sdk Messages Thrift 记录，
    Episode JSON 放在 reserved_column 中。
    不论是 episode 级还是帧级骨架，读法完全一样。

    参数:
        root: 数据根目录（parquet/video 的相对路径基准）
        dataset_name: 数据集名称
        skeleton_dir: 骨架 SSTable 目录，默认 root/skeleton_episode/{dataset_name}
    """

    def __init__(
        self,
        root: str | Path,
        dataset_name: str,
        skeleton_dir: str | Path | None = None,
    ):
        self.root = Path(root)
        self.dataset_name = dataset_name
        self._episodes: list[Episode] = []
        self._parquet_cache: dict[str, list] = {}
        self._parquet_group_files: dict[str, list[str]] = {}
        self._parquet_row_spans: dict[str, tuple[int, int]] = {}

        if skeleton_dir is not None:
            self._skeleton_dir = Path(skeleton_dir)
        else:
            self._skeleton_dir = self.root / "skeleton_episode" / dataset_name
        self._load_sstable_partition(self._skeleton_dir)

    def _load_sstable_partition(self, skeleton_dir: Path):
        from modelbest_sdk.file_format.mbtable_partition import (
            MbTablePartition,
            MbTablePartitionIterator,
        )
        partition = MbTablePartition(str(skeleton_dir))
        with MbTablePartitionIterator(partition) as it:
            for record in it:
                self._episodes.append(decode_episode_record(record).episode)
        logger.info(f"Loaded {len(self._episodes)} episodes from SSTable partition")

    def _load_parquet(self, file_path: str) -> list:
        if file_path not in self._parquet_cache:
            full_path = self.root / file_path
            if not full_path.exists():
                logger.warning(f"Parquet not found: {full_path}")
                return []
            table = pq.read_table(str(full_path))
            self._parquet_cache[file_path] = table.to_pandas()["data"].tolist()
        return self._parquet_cache[file_path]

    def _build_parquet_group_index(self, file_path: str) -> None:
        group_key = str(Path(file_path).parent)
        if group_key in self._parquet_group_files:
            return

        group_dir = self.root / group_key
        parquet_files = sorted(group_dir.rglob("*.parquet"))
        if not parquet_files:
            raise FileNotFoundError(f"no parquet files found under {group_dir}")

        rel_paths: list[str] = []
        global_row_start = 0
        for parquet_path in parquet_files:
            rel_path = str(parquet_path.relative_to(self.root))
            row_count = pq.read_metadata(str(parquet_path)).num_rows
            rel_paths.append(rel_path)
            self._parquet_row_spans[rel_path] = (
                global_row_start,
                global_row_start + row_count,
            )
            global_row_start += row_count
        self._parquet_group_files[group_key] = rel_paths

    def _resolve_parquet_row(self, file_path: str, row: int) -> tuple[str, int]:
        self._build_parquet_group_index(file_path)
        group_key = str(Path(file_path).parent)
        if file_path not in self._parquet_row_spans:
            raise FileNotFoundError(f"parquet file not indexed: {file_path}")

        start, end = self._parquet_row_spans[file_path]
        if start <= row < end:
            return file_path, row - start

        for candidate_path in self._parquet_group_files[group_key]:
            candidate_start, candidate_end = self._parquet_row_spans[candidate_path]
            if candidate_start <= row < candidate_end:
                return candidate_path, row - candidate_start

        raise IndexError(f"row {row} out of range for parquet group {group_key}")

    def _load_parquet_row(self, file_path: str, row: int):
        resolved_file_path, local_row = self._resolve_parquet_row(file_path, row)
        data = self._load_parquet(resolved_file_path)
        if local_row >= len(data):
            raise IndexError(
                f"resolved row {local_row} out of range for parquet file {resolved_file_path}"
            )
        return data[local_row]

    def __len__(self) -> int:
        return len(self._episodes)

    def get_episode(self, idx: int) -> Episode:
        return self._episodes[idx]

    def summary(self):
        if not self._episodes:
            print(f"No episodes for {self.dataset_name}")
            return

        print(f"\n{'='*60}")
        print(f"Dataset: {self.dataset_name}")
        print(f"Episodes: {len(self._episodes)}")

        total_duration = sum(ep.duration for ep in self._episodes)
        print(f"Total duration: {total_duration:.1f}s ({total_duration/60:.1f}min)")

        ep0 = self._episodes[0]
        meta = self._find_meta(ep0)
        if meta:
            print(f"Robot: {meta.robot_type}")
            print(f"Task: {meta.task}")
            print(f"Type: {meta.dataset_type}")

        content_types = set()
        for msg in ep0.messages:
            for c in msg.content:
                if isinstance(c, VideoContent) and c.ref:
                    content_types.add(f"video({c.ref.fps}fps {c.ref.width}x{c.ref.height})")
                elif isinstance(c, TimeseriesContent) and c.ref:
                    content_types.add(f"ts({c.name}@{c.ref.fps}Hz)")
                elif isinstance(c, AudioContent):
                    content_types.add("audio")
                elif isinstance(c, MetaContent):
                    content_types.add("meta")
                elif isinstance(c, TextContent):
                    content_types.add("text")
        print(f"Content: {', '.join(sorted(content_types))}")
        print(f"{'='*60}")

    def load_sample(
        self,
        episode_idx: int,
        timestamp: float | None = None,
        action_chunk_size: int | None = None,
    ) -> dict:
        ep = self._episodes[episode_idx]
        if timestamp is None:
            timestamp = 0.0

        item = {
            "episode_index": episode_idx,
            "timestamp": timestamp,
            "duration": ep.duration,
        }

        for msg in ep.messages:
            for content in msg.content:
                if isinstance(content, MetaContent):
                    item["task"] = content.task
                    item["robot_type"] = content.robot_type

                elif isinstance(content, VideoContent) and content.ref:
                    ref = content.ref
                    frame = self._decode_video_frame(ref, timestamp)
                    cam_name = Path(ref.file).parent.name
                    item[f"video.{cam_name}"] = frame

                elif isinstance(content, TimeseriesContent) and content.ref:
                    ref = content.ref
                    raw = self._load_parquet_row(ref.file, ref.row)
                    ep_data = (
                        np.stack(raw).astype(np.float32)
                        if hasattr(raw[0], '__len__')
                        else np.array(raw, dtype=np.float32)
                    )
                    frame_idx = int(timestamp * ref.fps) if ref.fps > 0 else 0
                    frame_idx = min(frame_idx, len(ep_data) - 1)

                    if "action" in content.name:
                        chunk_size = _resolve_action_chunk_size(
                            ref,
                            action_chunk_size,
                            len(ep_data),
                            frame_idx,
                        )
                        end_idx = min(frame_idx + chunk_size, len(ep_data))
                        chunk = ep_data[frame_idx:end_idx]
                        if len(chunk) < chunk_size:
                            chunk = _pad_action_chunk(chunk, chunk_size, content.name)
                        item[content.name] = chunk
                    else:
                        item[content.name] = ep_data[frame_idx]

                elif isinstance(content, AudioContent) and content.ref:
                    ref = content.ref
                    item["audio"] = self._load_parquet_row(ref.file, ref.row)

        return item

    def _decode_video_frame(self, ref, timestamp: float) -> np.ndarray | None:
        video_path = self.root / ref.file
        if not video_path.exists():
            return None

        abs_ts = ref.from_ts + timestamp
        container = av.open(str(video_path))
        if not container.streams.video:
            container.close()
            return None
        stream = container.streams.video[0]
        if stream.time_base and stream.time_base > 0:
            container.seek(int(abs_ts / stream.time_base), stream=stream)
        frame_arr = None
        for frame in container.decode(video=0):
            frame_arr = frame.to_ndarray(format="rgb24")
            break
        container.close()
        return frame_arr

    def _find_meta(self, ep: Episode) -> MetaContent | None:
        for msg in ep.messages:
            if isinstance(msg, EnvMessage):
                for c in msg.content:
                    if isinstance(c, MetaContent):
                        return c
        return None

    def verify(self, max_episodes: int = 5) -> bool:
        print(f"\nVerifying {self.dataset_name}...")
        ok = True

        for i in range(min(max_episodes, len(self._episodes))):
            ep = self._episodes[i]
            errors = []

            for msg in ep.messages:
                for c in msg.content:
                    if isinstance(c, VideoContent) and c.ref:
                        if not (self.root / c.ref.file).exists():
                            errors.append(f"Video missing: {c.ref.file}")
                    if isinstance(c, TimeseriesContent) and c.ref:
                        if not (self.root / c.ref.file).exists():
                            errors.append(f"Parquet missing: {c.ref.file}")

            verify_ts = min(0.5, ep.duration * 0.5) if ep.duration > 0 else 0.0
            sample = self.load_sample(i, timestamp=verify_ts)
            for key in sample:
                if isinstance(sample[key], np.ndarray) and sample[key].size == 0:
                    errors.append(f"Empty data: {key}")

            status = "OK" if not errors else f"ERRORS: {errors}"
            print(f"  Episode {i}: {status}")
            if errors:
                ok = False

        print(f"Verification: {'PASSED' if ok else 'FAILED'}")
        return ok
