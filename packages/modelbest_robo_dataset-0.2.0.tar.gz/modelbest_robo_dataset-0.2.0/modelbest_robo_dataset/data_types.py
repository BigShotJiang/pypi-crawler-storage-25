"""
具身智能数据集类型定义
====================
参考 modelbest_audio_dataset 的 env/user/ai 三轨道设计，
适配机器人场景的多模态数据存储。

层次结构:
  Episode                      骨架记录 (SSTable 一条)
  ├── EnvMessage               环境感知 (视频+音频+传感器+元信息)
  ├── UserMessage              人类实时干预 (语音纠正+文本+遥操作)
  └── AiMessage                机器人输出 (CoT+语音回复+动作)

存储引用:
  TimeseriesRef → Parquet 表 (row range 切片)
  VideoRef      → MP4 文件 (timestamp 定位)
  AudioRef      → Parquet binary 列 (行号定位)

序列化:
  sdk Messages.serialize()，Episode JSON 放在 reserved_column 中
"""

from __future__ import annotations

from typing import Annotated, Literal, Optional, Union

from pydantic import BaseModel, Field


# ── 基础引用类型 ──

class TimeseriesRef(BaseModel):
    """引用 Parquet 表中的一段时序数据。[from_ts, to_ts] 左闭右闭"""
    file: str
    row: int
    from_ts: float = 0.0
    to_ts: float = 0.0
    fps: float = 0.0


class VideoRef(BaseModel):
    """引用 MP4 文件中的一段视频。[from_ts, to_ts] 左闭右闭"""
    file: str
    from_ts: float = 0.0
    to_ts: float = 0.0
    fps: float = 0.0
    width: int = 0
    height: int = 0


class AudioRef(BaseModel):
    """引用 Parquet 表中的一段音频"""
    file: str
    row: int
    from_ts: float = 0.0
    to_ts: float = 0.0
    sample_rate: int = 16000


# ── 逐字时间戳 ──

class TextWithTime(BaseModel):
    """带逐字时间戳的文本片段（用于语音对齐）"""
    text: str
    start: float
    end: float
    prefix_punc: str = ""
    suffix_punc: str = ""

    def get_text(self) -> str:
        return f"{self.prefix_punc}{self.text}{self.suffix_punc}"


# ── Content 类型 (Literal type discriminator) ──

class TextContent(BaseModel):
    type: Literal["text"] = "text"
    text: str = ""
    twt: Optional[list[TextWithTime]] = None


class AudioContent(BaseModel):
    type: Literal["audio"] = "audio"
    ref: Optional[AudioRef] = None


class VideoContent(BaseModel):
    type: Literal["video"] = "video"
    ref: Optional[VideoRef] = None


TimeseriesName = Literal[
    # env.obs: 环境观测 (传感器读数, 始终是绝对值)
    "env.obs.joint_position",
    "env.obs.cartesian_position",
    "env.obs.gripper_position",
    "env.obs.joint_velocity",
    "env.obs.joint_effort",
    "env.obs.force_torque",
    "env.obs.imu",

    # ai.action: 绝对目标
    "ai.action.joint_position",
    "ai.action.cartesian_position",
    "ai.action.gripper_position",
    "ai.action.joint_velocity",
    "ai.action.joint_effort",

    # ai.action.delta: 增量指令
    "ai.action.delta_joint_position",
    "ai.action.delta_cartesian_position",
    "ai.action.delta_gripper_position",
]


class TimeseriesContent(BaseModel):
    type: Literal["timeseries"] = "timeseries"
    name: TimeseriesName
    ref: Optional[TimeseriesRef] = None


class MetaContent(BaseModel):
    """环境元数据"""
    type: Literal["meta"] = "meta"

    # dataset 级别
    dataset_name: str = ""
    dataset_type: Literal[
        "", "simulation", "real_teleoperation", "real_autonomous", "human_video",
    ] = ""
    robot_type: str = ""
    system_prompt: str = ""

    # 机器人描述
    urdf_path: str = ""
    joint_names: list[str] = Field(default_factory=list)
    camera_extrinsics: dict = Field(default_factory=dict)
    camera_intrinsics: dict = Field(default_factory=dict)

    # 维度名称: key=TimeseriesName, value=维度名列表
    # TimeseriesName 本身区分绝对/增量, 不需要单独的 state_type/action_type
    dim_names: dict[str, list[str]] = Field(default_factory=dict)

    # episode 级别
    task: str = ""
    task_id: str = ""
    scene: str = ""
    scene_id: str = ""
    user_id: str = ""
    quality_rating: int = -1  # 0=机器人失败, 1=任务失败, 2-9=完成质量, -1=未标注
    memory: str = ""

    # 扩展
    extra: dict = Field(default_factory=dict)


ContentType = Annotated[
    Union[TextContent, AudioContent, VideoContent, TimeseriesContent, MetaContent],
    Field(discriminator="type"),
]


# ── 时间戳 ──

class Timestamp(BaseModel):
    start: float
    end: float


# ── ENV / USER / AI 消息 ──

class EnvMessage(BaseModel):
    """环境消息: 机器人感知到的一切 (视频/音频/时序/元数据)"""
    role: Literal["env"] = "env"
    timestamp: Timestamp = Timestamp(start=0, end=0)
    content: list[ContentType] = Field(default_factory=list)


class UserMessage(BaseModel):
    """用户消息: 人类操作者的实时干预"""
    role: Literal["user"] = "user"
    timestamp: Timestamp = Timestamp(start=0, end=0)
    content: list[ContentType] = Field(default_factory=list)


class AiMessage(BaseModel):
    """AI 消息: 机器人的输出 (训练标签)"""
    role: Literal["assistant"] = "assistant"
    timestamp: Timestamp = Timestamp(start=0, end=0)
    content: list[ContentType] = Field(default_factory=list)


MessageType = Annotated[
    Union[EnvMessage, UserMessage, AiMessage],
    Field(discriminator="role"),
]


# ── Episode ──

class Episode(BaseModel):
    """一个完整的 episode，骨架表的一条记录"""
    episode_index: int
    duration: float
    messages: list[MessageType] = Field(default_factory=list)
    quality_score: float = 1.0
