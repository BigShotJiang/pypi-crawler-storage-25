"""Single source of truth for `stats.json` / `norm_stats.json` files.

All paths that produce per-dataset normalization statistics — the
``EmbodiedWriter`` conversion path and the standalone preprocessing
scripts under ``scripts/preprocess/`` — go through this module so that:

* the **formula** (min / max / q01 / q99 / mean / std + sample count)
  is computed in exactly one place; and
* the on-disk **layout** (``meta/stats.json`` and ``meta/norm_stats.json``)
  is written by exactly one function.

The on-disk JSON layout is::

    meta/stats.json           # bare dict
    {
        "<key>": {"min": [...], "max": [...], "q01": [...],
                   "q99": [...], "mean": [...], "std": [...], "count": N},
        ...
    }

    meta/norm_stats.json      # wrapped under "norm_stats"
    {"norm_stats": <same dict as above>}

Keys are always **SSTable timeseries names** (``env.obs.*``,
``ai.action.*``) so that the trainer's ``norm_stats_action_key`` /
``norm_stats_state_key`` lookup in
``libero_all_dataset_info.yaml`` works against the same file regardless
of which producer wrote it.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable, Mapping

import numpy as np

StatsDict = dict[str, list[float] | int]


def compute_stats(data: np.ndarray) -> StatsDict:
    """Compute per-dimension normalization stats over a (N, D) matrix.

    Includes ``count`` (number of rows) so consumers can audit how many
    samples backed the file. ``data`` is upcast to float64 for stable
    quantile computation.
    """
    arr = np.asarray(data, dtype=np.float64)
    if arr.ndim != 2 or arr.size == 0:
        raise ValueError(
            f"compute_stats expects a non-empty (N, D) matrix, got shape {arr.shape}"
        )
    return {
        "mean": arr.mean(axis=0).tolist(),
        "std": arr.std(axis=0).tolist(),
        "min": arr.min(axis=0).tolist(),
        "max": arr.max(axis=0).tolist(),
        "q01": np.quantile(arr, 0.01, axis=0).tolist(),
        "q99": np.quantile(arr, 0.99, axis=0).tolist(),
        "count": int(arr.shape[0]),
    }


def stats_from_chunks(chunks: Iterable[np.ndarray]) -> StatsDict:
    """Concatenate (N_i, D) chunks and compute stats from them."""
    materialized = [c for c in chunks if c is not None and c.size > 0]
    if not materialized:
        raise ValueError("stats_from_chunks: no non-empty chunks provided")
    return compute_stats(np.concatenate(materialized, axis=0))


def write_norm_stats_files(
    meta_dir: Path,
    stats_by_key: Mapping[str, StatsDict],
) -> tuple[Path, Path]:
    """Write ``meta/stats.json`` and ``meta/norm_stats.json`` atomically.

    Returns ``(stats_path, norm_stats_path)``. Skips writing (and returns
    paths that may not exist) if ``stats_by_key`` is empty, so callers can
    still use this helper without special-casing empty datasets.
    """
    meta_dir = Path(meta_dir)
    meta_dir.mkdir(parents=True, exist_ok=True)
    stats_path = meta_dir / "stats.json"
    norm_stats_path = meta_dir / "norm_stats.json"

    if not stats_by_key:
        return stats_path, norm_stats_path

    payload = dict(stats_by_key)
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)
    with open(norm_stats_path, "w", encoding="utf-8") as f:
        json.dump({"norm_stats": payload}, f, indent=2, ensure_ascii=False)

    return stats_path, norm_stats_path
