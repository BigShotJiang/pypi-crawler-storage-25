"""theory.py module

Implements the Theory class for theoretical prediction of the power
specrum and bispectrum.

"""

import camb
import math
from math import e, pi
import numpy as np
from numpy import arange, array, concatenate, einsum, exp, hstack, linspace, log, log10, logspace, newaxis, ones, sqrt, sum, vstack, zeros
from scipy.constants import speed_of_light
from scipy.fftpack import dst, idst
from scipy.interpolate import InterpolatedUnivariateSpline, interp1d, splev, splrep
from scipy.integrate import simpson as simps
from scipy.ndimage import gaussian_filter1d
from scipy.special import legendre, spherical_jn
import sys
from .fptplus import FASTPTPlus
from .tools import cosmology

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress TensorFlow warnings

try: import baccoemu
except: print("\033[1;31m[WARNING]: \033[00m"+"Bacco not installed")

lightspeed_kms = speed_of_light/1000

class Theory:
    """Class for theoretical predictions

    Implements methods to compute the building blocks of the power spectrum and
    bispectrum in real and redshift space, including all methods to compute the
    linear power spectrum, perform infra-red resummation and window convolution.
    Works as a standalone module to create theoretical predictions or to plug
    into other likelihood codes (e.g. see the integration with Cosmosis, Cobaya
    or https://github.com/cloe-org/cloelib).

    Attributes
    ----------
    mu : array_like,  default: np.linspace(-1,1,101)
        Cosine of the angle between the wavevector k and the line of sight
    kL : array_like, default: np.logspace(-4, log10(198), 1000)
        Array of wavenumbers
    fastpt : FASTPTPlus object
    linear : str, default: 'camb'
        Backend to compute the linear power spectrum

    Notes
    -----
    If the output power spectrum is used as input to FastPT to compute the
    loop integrals, it should be sampled on a `kL` grid that is sufficiently
    large and fine, and log-spaced. This module uses a default grid with
    1000 log-spaced points between 1e-4 and 198 h/Mpc.
    """
    def __init__(self, kmin=1.0001e-4, kmax=198., npoints=1000, kL=None, linear='camb'):
        """Class constructor

        Sets basic attributes of the class, if needed loads the linear emulator.

        Parameters
        ----------
        kmin : float, default: 1.0001e-4
            Minimum wavenumber
        kmax : float, default: 198
            Maximum wavenumber
        npoints : int, default: 1000
            Number of points in the k-grid
        kL : array_like, default: None
            Input k-grid
        linear : {'camb', 'bacco'}, default: 'camb'
            Backend to compute the linear power spectrum

        Notes
        -----
        The k-grid computed here is the one used by FASTPT to compute loop
        integrals. As such, it must be log-spaced and sufficiently wide and
        fine. The default implementation takes 1000 log-spaced points between
        1e-4 and 198 h/Mpc. The user can define their own grid by passing a `kL`
        array, this grid must still comply with the FASTPT requirements.
        """
        self.mu = linspace(-1, 1, 101).reshape(1, 101)
        # mu, self.weights = np.polynomial.legendre.leggauss(10)
        # self.mu = 0.5 * (mu + 1.0)
        self.kL=kL if kL is not None else logspace(log10(kmin),log10(kmax),npoints)
        self.fastpt = FASTPTPlus(self.kL, -2, param_mat=None, low_extrap=-6,
                                 high_extrap=5, n_pad=1000)
        self.linear=linear
        if self.linear ==  "bacco" and "baccoemu" in sys.modules:
            self.emulator = baccoemu.Matter_powerspectrum(
                linear=True,
                smeared_bao=False,
                nonlinear_boost=False,
                baryonic_boost=False,
                compute_sigma8=True,
                verbose=False
            )

#-------------------------------------------------------------------------------

    def linear_power_spectrum(self, cosmo, kL, linear='camb', redshift=0,
                              cold=True):
        """Computes the linear matter power spectrum using either CAMB or BACCO.

        Parameters
        ----------
        cosmo : dict
            Dictionary of cosmological parameters
        kL : array_like
            Input wavenumber array in units of h/Mpc
        linear : {'camb', 'bacco'}, default: 'camb'
            Backend used to compute the linear power spectrum
        redshift : float, optional
            Redshift at which to compute the power spectrum
        cold : bool, default=True
            If True, computes the cold (cdm + baryons) power spectrum,
            excluding neutrinos. If `False`, includes total matter

        Returns
        -------
        array_like
            `k, P`: Wavenumber array (same as kL) and linear matter power spectrum

        Notes
        -----
        If the output power spectrum is used as input to FastPT to compute the
        loop integrals, it should be sampled on a `kL` grid that is sufficiently
        large and fine, and log-spaced. This module uses a default grid with
        1000 log-spaced points between 1e-4 and 198 h/Mpc.

        The cosmology dictionary should have the following keys:
        `cosmo = {'ns', 'As', 'tau', 'h', 'Obh2', 'Och2', 'Mnu'}`

        See Also
        --------
        `call_bacco` : call to the BACCO emulator.
        `call_camb` : call to the CAMB Boltzmann solver.
        """
        if linear == 'camb':
            return self.call_camb(cosmo, kL, redshift, cold=cold)
        elif linear == 'bacco':
            return self.call_bacco(cosmo, kL, redshift, cold=cold)
        elif linear == 'cobaya':
            return self.cobaya_provider(cosmo, kL, redshift, cold=cold)
        

#-------------------------------------------------------------------------------

    def call_bacco(self, cosmo, kL, redshift, cold=True):
        """Computes the linear matter power spectrum using BACCO.

        Parameters
        ----------
        cosmo : dict
            Dictionary of cosmological parameters
        kL : array_like
            Input wavenumber array in units of h/Mpc
        redshift : float
            Redshift at which to compute the power spectrum
        cold : bool, default=True
            If True, computes the cold (cdm + baryons) power spectrum,
            excluding neutrinos. If `False`, includes total matter

        Returns
        -------
        array_like
            `k, P`: Wavenumber array (same as kL) and linear matter power spectrum

        Notes
        -----
        If the output power spectrum is used as input to FastPT to compute the
        loop integrals, it should be sampled on a `kL` grid that is sufficiently
        large and fine, and log-spaced. This module uses a default grid with
        1000 log-spaced points between 1e-4 and 198 h/Mpc.

        To account for the k-cut of BACCO (k_max = 50 h/Mpc), the power spectrum is
        linearly extrapolated in log(P(k)) - log(k)

        See Also
        --------
        `call_camb` : call to the CAMB Boltzmann solver
        `linear_power_spectrum` : wrapper for the linear power spectrum backends
        """
        params = {
            'ns'            : cosmo['ns'],
            'A_s'           : cosmo['As'],
            'tau'           : cosmo['tau'],
            'hubble'        : cosmo['h'],
            'omega_baryon'  : cosmo['Obh2']/cosmo['h']**2,
            'omega_cold'    : (cosmo['Och2']+cosmo['Obh2'])/cosmo['h']**2, #O_cb
            'neutrino_mass' : cosmo['Mnu'],
            'w0'            : -1,
            'wa'            : 0,
            'expfactor'     : 1/(1+redshift)
        }

        # The emulator only works up to k=50, so split the k vector
        kcut = kL[np.where(kL <= 50)]
        kext = kL[np.where(kL > 50)]
        _, PL = self.emulator.get_linear_pk(k=kcut, cold=cold, **params)

        # Extrapolation with power law
        m = math.log(PL[-1] / PL[-2]) / math.log(kcut[-1] / kcut[-2])
        PL_ext = PL[-1] / kcut[-1]**m * kext**m

        return kL, hstack((PL, PL_ext))
    
    def _get_sigma8_0_bacco(self, cosmo, kL, cold=True):
        """Computes the sigma8 at z=0 using bacco emulator.
        """
        # kL is dummy here, but I think keeping API consistency is probably good
        params = {
            'ns'            : cosmo['ns'],
            'A_s'           : cosmo['As'],
            'tau'           : cosmo['tau'],
            'hubble'        : cosmo['h'],
            'omega_baryon'  : cosmo['Obh2']/cosmo['h']**2,
            'omega_cold'    : (cosmo['Och2']+cosmo['Obh2'])/cosmo['h']**2, #O_cb
            'neutrino_mass' : cosmo['Mnu'],
            'w0'            : cosmo['w0'],
            'wa'            : cosmo['wa'],
            'expfactor'     : 1.0,
        }
        return self.emulator.get_sigma8(cold=cold, **params)

#-------------------------------------------------------------------------------

    def call_camb(self, cosmo, kL, redshift, cold=True):
        """Computes the linear matter power spectrum using CAMB.

        Parameters
        ----------
        cosmo : dict
            Dictionary of cosmological parameters
        kL : array_like
            Input wavenumber array in units of h/Mpc
        redshift : float
            Redshift at which to compute the power spectrum
        cold : bool, default=True
            If True, computes the cold (cdm + baryons) power spectrum,
            excluding neutrinos. If `False`, includes total matter

        Returns
        -------
        array_like
            `k, P`: Wavenumber array (same as kL) and linear matter power spectrum

        Notes
        -----
        If the output power spectrum is used as input to FastPT to compute the
        loop integrals, it should be sampled on a `kL` grid that is sufficiently
        large and fine, and log-spaced. This module uses a default grid with
        1000 log-spaced points between 1e-4 and 198 h/Mpc.

        Also sets the `camb_interpolator` class attribute

        See Also
        --------
        `call_bacco` : call to the CAMB Boltzmann solver
        `linear_power_spectrum` : wrapper for the linear power spectrum backends
        """
        nmassive = 1 if cosmo['Mnu'] != 0 else 0
        params = camb.model.CAMBparams()
        params.InitPower.set_params(ns=cosmo['ns'], As=cosmo['As'], r=0.)
        params.set_cosmology(H0 = 100.*cosmo['h'],
                             ombh2 = cosmo['Obh2'],
                             omch2 = cosmo['Och2'],
                             mnu   = cosmo['Mnu'],
                             nnu   = 3.046,
                             num_massive_neutrinos = nmassive,
                             neutrino_hierarchy = 'degenerate',
                             omk   = 0.,
                             tau   = cosmo['tau'])
        params.set_dark_energy(w=-1, wa=0, dark_energy_model='ppf')
        params.set_matter_power(redshifts = [redshift], kmax = kL[-1])
        results = camb.get_results(params)

        if cold:
            var=8
        else:
            var=7

        kcamb, zcamb, pkcamb = results.get_matter_power_spectrum(
            minkh = kL[0], maxkh = kL[-1], npoints = len(kL),
            var1 = var, var2 = var)

        pk_itp = camb.get_matter_power_interpolator(
            params, nonlinear=False, hubble_units=True, k_hunit=True,
            kmax=kL[-1], zmax=20.0, var1=var, var2=var)

        setattr(self, 'camb_interpolator', pk_itp.P)

        kL, PL = kcamb, pkcamb.ravel()
        return kL, PL
    
    def _get_sigma8_0_camb(self, cosmo, kL, cold=True):
        """Computes the sigma8 at z=0 using CAMB.
        """
        nmassive = 1 if cosmo['Mnu'] != 0 else 0
        params = camb.model.CAMBparams()
        params.InitPower.set_params(ns=cosmo['ns'], As=cosmo['As'], r=0.)
        params.set_cosmology(H0 = 100.*cosmo['h'],
                             ombh2 = cosmo['Obh2'],
                             omch2 = cosmo['Och2'],
                             mnu   = cosmo['Mnu'],
                             nnu   = 3.046,
                             num_massive_neutrinos = nmassive,
                             neutrino_hierarchy = 'degenerate',
                             omk   = 0.,
                             tau   = cosmo['tau'])
        params.set_dark_energy(w=-1, wa=0, dark_energy_model='ppf')
        # calculate matter transfer function at z=0
        params.set_matter_power(redshifts = [0.0,], kmax = kL[-1])
        results = camb.get_results(params)

        if cold:
            var=8
        else:
            var=7

        results.get_matter_power_spectrum(
            minkh = kL[0], maxkh = kL[-1], npoints = len(kL),
            var1 = var, var2 = var)
        return results.get_sigma8_0()
    
    def _get_sigma8_0(self, cosmo, kL, linear, cold=True):
        """Computes the sigma8 at z=0 using the linear power spectrum.
        """
        return getattr(self, f"_get_sigma8_0_{linear}")(cosmo, kL, cold=cold)
        

    def cobaya_provider(self, cosmo, kL, redshift, cold=True):
        """Computes the linear matter power spectrum using Cobaya's Pk_interpolator.
        """
        h    = cosmo['h'] if 'h' in cosmo else self.h #You should provide h for units conversion

        # Request only up to k=5, so split the k vector
        kcut = kL[np.where(kL <= 5)]
        kext = kL[np.where(kL > 5)]
        # Beware the Pk_interpolator function is bastard, its units are 1/Mpc and not h/Mpc
        PL = self.cobaya_Pk_interpolator.P(redshift, kcut*h) # The cobaya Pk interpolator is very similar to camb one
        PL *= h**3

        # Extrapolation with power law
        m = math.log(PL[-1] / PL[-2]) / math.log(kcut[-1] / kcut[-2])
        PL_ext = PL[-1] / kcut[-1]**m * kext**m
        return kL, hstack((PL, PL_ext))
#-------------------------------------------------------------------------------

    def CallEH_NW(self, plinear, cosmo, units='h/Mpc'):
        """Computes the smooth matter power spectrum following the
        prescription of Eisenstein & Hu 1998

        Parameters
        ----------
        plinear : array_like
            Linear power spectrum sampled on `self.kL`
        cosmo : dict
            Dictionary of cosmological parameters

        Returns
        -------
        array_like
            `kL, P_EH`: Wavenumber and smooth linear power spectrum

        Other Parameters
        ----------------
        units : {'h/Mpc', '1/Mpc'}, default: 'h/Mpc'
            Specifies the units of `plinear`

        Notes
        -----
        The cosmology dictionary should have the following keys:
        `cosmo = {'ns', 'Tcmb', 'h', 'Obh2', 'Och2', 'Mnu'}`

        See Also
        --------
        `pksmooth_dst` : dewiggled power spectrum with DST
        """
        Omh2 = cosmo['Obh2'] + cosmo['Och2'] + cosmo['Mnu']/93.14
        kL = self.kL
        if units=='h/Mpc':
            kL *= cosmo['h']

        s = 44.5 * log(9.83/Omh2) / sqrt(1.+10.*(cosmo['Obh2'])**0.75)
        Gamma = Omh2 / cosmo['h']
        AG = (1. - 0.328 * log(431.*Omh2) * cosmo['Obh2'] / Omh2 +
              0.38 * log(22.3 * Omh2) * (cosmo['Obh2'] / Omh2)**2)
        Gamma = Gamma * (AG + (1.-AG) / (1.+(0.43*kL*s)**4))
        Theta = cosmo['Tcmb'] / 2.7

        q  = kL * Theta**2 / Gamma / cosmo['h']
        L0 = log(2.*e + 1.8*q)
        C0 = 14.2 + 731. / (1. + 62.5 * q)
        T0 = L0 / (L0 + C0 * q * q)
        T0 /= T0[0]
        P_EH  = kL**cosmo['ns'] * T0**2
        P_EH *= plinear[0] / P_EH[0]

        if units=='h/Mpc':
            kL /= cosmo['h']

        return kL, P_EH

#-------------------------------------------------------------------------------

    def pksmooth_dst(self, plinear, redshift, kmin, cosmo, cold=True):
        """Returns the dewiggled power spectrum

        The de-wiggling is performed by identifying and removing the BAO bump
        in real space by means of a type-II dst transform, then transforming
        back to Fourier space. The dst transform requires sampling the linear
        power spectrum on 2^15 points, which is achieved by the method by
        internally calling one of the backends (camb or bacco)

        Parameters
        ----------
        plinear : array_like
            Linear power spectrum
        redshift : float
            Redshift at which to compute the power spectrum
        kmin : float
            Minimum wavenumber used to construct the 2^15 k-grid
        cosmo : dict
            Dictionary of cosmological parameters
        cold : bool, default=True
            If True, computes the cold (cdm + baryons) power spectrum,
            excluding neutrinos. If `False`, includes total matter.

        Returns
        -------
        array_like
            `kL, smooth_itp`: Wavenumber array and smooth linear power spectrum

        Notes
        -----
        See [1712.08067](https://arxiv.org/abs/1712.08067),
        [1906.02742](https://arxiv.org/abs/1906.02742). Adapted from the
        baccoemu implementation.

        The cosmology dictionary should have the following keys:
        `cosmo = {'ns', 'As', 'tau', 'h', 'Obh2', 'Och2', 'Mnu'}`

        See Also
        --------
        `CallEH_NW` : no-wiggle power spectrum from Eisenstein-Hu98
        """
        params = {
            'ns'            : cosmo['ns'],
            'A_s'           : cosmo['As'],
            'hubble'        : cosmo['h'],
            'omega_baryon'  : cosmo['Obh2']/cosmo['h']**2,
            'omega_cold'    : (cosmo['Och2']+cosmo['Obh2'])/cosmo['h']**2, #O_cb
            'neutrino_mass' : cosmo['Mnu'],
            'w0'            : -1.,
            'wa'            : 0.,
            'expfactor'     : 1/(1+redshift)
        }

        # Sample k, P(k) in 2^15 points
        nk = int(2**15)
        kmax = 10
        klin = linspace(kmin, kmax, nk)
        if self.linear == 'bacco':
            _, pklin = self.emulator.get_linear_pk(k=klin, cold=cold, **params)
        elif self.linear == 'camb':
            pklin = self.camb_interpolator(redshift, klin)

        # DST-II log(k *P(k))
        logkpk = log10(klin * pklin)
        dstpk = dst(logkpk, type=2)

        # Split in even and odd indices,
        even = dstpk[0::2] # array with even indexes
        odd  = dstpk[1::2] # array with odd indexes
        i_even = arange(len(even)).astype(int)
        i_odd  = arange(len(odd)).astype(int)
        even_cs = splrep(i_even, even, s=0)
        odd_cs  = splrep(i_odd, odd, s=0)

        # Compute second derivatives and interp separately with cubic splines
        even_2nd_der = splev(i_even, even_cs, der=2, ext=0)
        odd_2nd_der = splev(i_odd, odd_cs, der=2, ext=0)

        # Find i_min and i_max for the even and odd arrays
        # These are optimised for the considered krange [1e-4,10]
        imin_even = i_even[100:300][np.argmax(even_2nd_der[100:300])] - 30
        imax_even = i_even[100:300][np.argmin(even_2nd_der[100:300])] + 70
        imin_odd = i_odd[100:300][np.argmax(odd_2nd_der[100:300])] - 30
        imax_odd = i_odd[100:300][np.argmin(odd_2nd_der[100:300])] + 75

        # Cut out the BAOs
        # mask indices
        i_even_holed = np.concatenate((i_even[:imin_even], i_even[imax_even:]))
        i_odd_holed = np.concatenate((i_odd[:imin_odd], i_odd[imax_odd:]))
        # mask log(k*P(k))
        even_holed = np.concatenate((even[:imin_even], even[imax_even:]))
        odd_holed = np.concatenate((odd[:imin_odd], odd[imax_odd:]))
        # interp the arrays rescaled by a factor (i + 1)^2 using cubic splines
        even_holed_cs = splrep(i_even_holed,even_holed*(i_even_holed+1)**2, s=0)
        odd_holed_cs  = splrep(i_odd_holed, odd_holed *(i_odd_holed +1)**2, s=0)

        # Merge the two arrays without the bumps, and without the rescaling
        # factor of (i + 1)^2, and inversely FST
        even_smooth = splev(i_even, even_holed_cs, der=0, ext=0) / (i_even+1)**2
        odd_smooth = splev(i_odd, odd_holed_cs, der=0, ext=0) / (i_odd + 1)**2

        dstkpk_smooth = zeros(nk)
        dstkpk_smooth[0::2] = even_smooth
        dstkpk_smooth[1::2] = odd_smooth

        pksmooth = idst(dstkpk_smooth, type=2) / (2 * len(dstkpk_smooth))
        pksmooth = 10**(pksmooth) / klin

        high_k = self.kL[self.kL > 2]
        high_p = plinear[self.kL > 2]
        k_ext = concatenate((klin[klin<=2], high_k))
        p_ext = concatenate((pksmooth[klin<=2], high_p))

        pksmooth_tot = splrep(np.log(k_ext), np.log(p_ext), s=0)
        smooth_itp = np.exp(splev(np.log(self.kL), pksmooth_tot, der=0, ext=0))

        return self.kL, smooth_itp

#-------------------------------------------------------------------------------

    def _gaussian_filtering(self, lambda_width, plinear, cosmo, units='h/Mpc'):
        """Smooths the linear power spectrum using a Gaussian filter

        Parameters
        ----------
        lambda_width : float
            Width of the Gaussian filter in log10(k)
        plinear : array_like
            Linear matter power spectrum
        cosmo : dict
            Dictionary with cosmological parameters.

        Returns
        -------
        Psmooth : array_like
            Smoothed power spectrum

        Other Parameters
        ----------------
        units : {'h/Mpc', '1/Mpc'}, default: 'h/Mpc'
            Specifies the units of `plinear`

        See Also
        --------
        `CallEH_NW` : computes the smooth matter power spectrum with the
            Eisenstein-Hu method
        """
        def extrapolateX(x):
            logx = log10(x); xSize = x.size; dlogx = log10(x[1]/x[0])
            newlogx = linspace(logx[0]  - xSize * dlogx / 2.,
                               logx[-1] + xSize * dlogx / 2., 2*xSize)
            newx = 10.**newlogx
            return newx

        def extrapolateFx(x, Fx):
            newx   = extrapolateX(x)
            backB  = math.log(Fx[1] / Fx[0]) / math.log(x[1] / x[0])
            backA  = Fx[0] / x[0]**backB
            forwB  = math.log(Fx[-1] / Fx[-2]) / math.log(x[-1] / x[-2])
            forwA  = Fx[-1] / x[-1]**forwB
            backFx = backA * newx[:x.size//2]**backB
            forwFx = forwA * newx[3*x.size//2:]**forwB
            return hstack((backFx, Fx, forwFx))

        kNumber = len(self.kL)
        qlog  = log10(self.kL)
        dqlog = qlog[1]-qlog[0]
        qlog  = log10(extrapolateX(self.kL))
        Plin_extrap = extrapolateFx(self.kL, plinear)
        _, PEH = self.CallEH_NW(plinear, cosmo, units=units)

        PEH = extrapolateFx(self.kL, PEH)
        Psmooth = gaussian_filter1d(Plin_extrap/PEH, lambda_width/dqlog)*PEH

        return Psmooth[kNumber//2:kNumber//2+kNumber]

#-------------------------------------------------------------------------------

    def IRresum(self, redshift, kind, plinear, cosmo, kmin, lambda_width=0.25,
                kS=0.2, lOsc=102.707, cold=True, units='h/Mpc'):
        """Splits the linear power spectrum into a smooth and a wiggly part and
        computes the damping factors

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        kind : {'EH', 'DST'}, default: 'EH'
            Algorithm for IR-resummation, based on Eisenstein-Hu or DST
        plinear : array_like
            Linear matter power spectrum
        cosmo : dict
            Dictionary with cosmological parameters.
        cold : bool, default=True
            If True, computes the cold (cdm + baryons) power spectrum,
            excluding neutrinos. If False, includes total matter.

        Returns
        -------
        array_like
            `kL, Pnw, Pw`: Wavenumber, no-wiggle and wiggle power spectrum
        float
            `Sigma2`: Damping factor
        float
            `dSigma2`: Additional damping factor for redshift space

        Other Parameters
        ----------------
        kmin : float
            Minimum wavenumber used to construct the 2^15 k-grid
        lambda_width : float, default: 0.25
            Width of the Gaussian filter in log10(k)
        kS : float, default: 0.2
            Scale of separation between large and small scales
        lOsc : float, default: 102.707
            Scale of the BAO
        units : {'h/Mpc', '1/Mpc'}, default: 'h/Mpc'
            Specifies the units of `plinear`

        See Also
        --------
        `pksmooth_dst` : de-wiggled power spectrum with the DST method
        `CallEH_NW` : de-wiggled power spectrum with the Eisenstein-Hu method
        """
        if units=='1/Mpc':
            lOsc /= cosmo['h']
            kS *= cosmo['h']

        icut = (self.kL <= kS)
        kLcut = self.kL[icut]

        if kind == 'EH':
            Pnw = self._gaussian_filtering(lambda_width,plinear,cosmo,units=units)
        elif kind == 'DST':
            _, Pnw = self.pksmooth_dst(plinear,redshift,kmin,cosmo,cold=cold)
        Pw = plinear - Pnw

        Pnwcut = Pnw[icut]
        norm = 1./(6.*pi**2)
        Sigma2  = norm*simps(Pnwcut*(1.-spherical_jn(0,kLcut*lOsc)+
                                     2.*spherical_jn(2,kLcut*lOsc)), x=kLcut)
        dSigma2 = norm*simps(3.*Pnwcut*spherical_jn(2,kLcut*lOsc), x=kLcut)

        return self.kL, Pnw, Pw, Sigma2, dSigma2

#-------------------------------------------------------------------------------

    def _muxdamp(self, k, mu, Sigma2, dSigma2, f):
        r"""Computes the full damping factor for IR-resummation in redshift
        space and the $\mu^n~{\rm exponential damping}$

        Parameters
        ----------
        k : array_like
            Wavenumber array
        mu : array_like
            Cosine of the angle between the wavevector k and the line of sight
        Sigma2 : float
            Damping factor
        dSigma2 : float
            Additional damping factor for redshift space
        f : float
            Growth rate

        Returns
        -------
        array_like
            `Sig2mu, RSDdamp`: Damping factor and exponential damping

        Notes
        -----
        $${\rm RSDdamp} = \exp(-k^2~\Sigma^2(\mu))$$
        """
        Sig2mu = Sigma2 + f * mu**2 * (2. * Sigma2 + f *
                                       (Sigma2 + dSigma2 * (mu**2 - 1)))
        RSDdamp = exp(-k**2 * Sig2mu)
        return Sig2mu, RSDdamp

#-------------------------------------------------------------------------------

    def _get_growth_functions(self, redshift, cosmo, growth_model, karr=None, f=None,
                              D=None):
        """Returns the growth functions f, D

        If `f` and / or `D` are not specified, computes
        the growth functions from the `cosmology.eval_growth_functions` method.
        Model behaviour:
        - `fr`: scale-dependent growth, returns `f(k)` and `D(k)` arrays.
        - `dgp`: typically scale-independent in MGrowth, returned as arrays
          broadcast over `karr`.
        - other non-LCDM models (`wcdm`, `w0wacdm`, `darkscattering`, `ndgp`)
          use `evogrowthpy`.

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        cosmo : dict
            Dictionary with cosmological parameters
        growth_model : {'lcdm','wcdm','w0wacdm','darkscattering','ndgp','growthindex','fr','dgp'}
            Background model to compute the growth functions
        f, D : float or array_like, default: None
            Input values of the growth rate and normalised growth factor.
            For `fr`, these are expected to be arrays over `k`.

        Returns
        -------
        float or array_like
            `f, D`: Growth functions

        See Also
        --------
        `cosmology.eval_growth_functions` : evaluates the growth rate and growth factor
        """
        if karr is None:
            karr = self.kL

        if f is None or D is None:
            newf,newD=cosmology.eval_growth_functions(growth_model,redshift,karr=karr,**cosmo)
        if f is None:
            f = newf
        if D is None:
            D = newD
        return f, D

#-------------------------------------------------------------------------------

    def _set_fiducials_for_AP(self, redshift, cosmo):
        """Sets fiducial quantities for Alcock-Paczynski distortions

        Sets the following attributes: `Hubble_adim_fid`, `rd_fid`,
        `angular_diam_distance_fid`

        Parameters
        ----------
        redshift: float or list
            The redshift at which to compute the fiducials
        cosmo : dict
            Dictionary with cosmological parameters

        See Also
        --------
        `tools.cosmology.Hubble_adim` : adimensional Hubble factor
        `tools.cosmology.angular_diam_distance` : angular diameter distance
        `tools.cosmology.sound_horizon_drag` : sound horizon at baryon drag
        """

        self.Hubble_adim_fid = cosmology.Hubble_adim(redshift,
                                                     cosmo["Om"],
                                                     cosmo["w0"],
                                                     cosmo["wa"])
        self.rd_fid = cosmology.sound_horizon_drag(cosmo["Om"]*cosmo["h"]**2,
                                                   cosmo["Ob"]*cosmo["h"]**2,
                                                   cosmo["h"], Mnu=cosmo["Mnu"])

        if isinstance(redshift, (float, int)):
            self.angular_diam_distance_fid = \
                cosmology.angular_diam_distance(redshift,
                                                cosmo["Om"],
                                                cosmo["w0"],
                                                cosmo["wa"])
        else:
            self.angular_diam_distance_fid = \
                np.asarray([cosmology.angular_diam_distance(iz,
                                                            cosmo["Om"],
                                                            cosmo["w0"],
                                                            cosmo["wa"])
                for iz in redshift])

#-------------------------------------------------------------------------------

    def AP_factors(self, mu, z, cosmo, AP_as_nuisance, alpha_par, alpha_perp):
        r"""Computes quantities to apply Alcock-Paczynski distortions.

        Parameters
        ----------
        mu : array_like
            Cosine of the angle between the wavevector k and the line of sight
        z : float
            Redshift of the observed galaxy sample
        cosmo : dict
            Dictionary of cosmological parameters
        AP_as_nuisance : bool
            If True uses specified values for the alphas instead of computing
            them from the cosmology
        alpha_par, alpha_perp : float
            Values to use for the alphas. Only used if `AP_as_nuisance==True`

        Returns
        -------
        array_like
            `AP_factor`
        float
            `alpha_par, alpha_perp, AP_amplitude`

        Notes
        -----
        ${\rm AP\_factor} = \sqrt{\mu^2/\alpha_{\parallel}^2 + (1-\mu^2)/\alpha_{\perp}^2}$

        $\alpha_{\parallel} = E^{\rm fid}(z)/E(z)$

        $\alpha_{\perp} = D_A(z) / D_A^{\rm fid}(z)$

        ${\rm AP\_amplitude} =  1 / (\alpha_{\parallel}~\alpha_{\perp}^2)$

        See Also
        --------
        `tools.cosmology.Hubble_adim` : adimensional Hubble factor
        `tools.cosmology.angular_diam_distance` : angular diameter distance
        """
        #Om = (cosmo["Obh2"] + cosmo["Och2"] + cosmo["Mnu"]/93.14)/cosmo["h"]**2

        if not AP_as_nuisance:
            alpha_par =  self.Hubble_adim_fid / \
                cosmology.Hubble_adim(z, cosmo["Om"], cosmo["w0"], cosmo["wa"])
            alpha_perp = cosmology.angular_diam_distance(
                z,cosmo["Om"],cosmo["w0"],cosmo["wa"])/self.angular_diam_distance_fid

        AP_amplitude = 1 / (alpha_par * alpha_perp**2)
        AP_factor = sqrt((mu / alpha_par)**2 + (1. - mu**2)/alpha_perp**2)

        return alpha_par, alpha_perp, AP_factor, AP_amplitude

#-------------------------------------------------------------------------------

    def apply_AP_distortions(self, k, mu, redshift, cosmo, AP_as_nuisance,
                   alpha_par, alpha_perp):
        r"""Applies AP distortions to the input k, mu arrays

        Can be used with arbitrary values of the alphas by setting
        `AP_as_nuisance` to True and `alpha_par`, `alpha_perp` to the desired
        values.

        Parameters
        ----------
        k : array_like
            Input wavenumber array in units of h/Mpc.
        mu : array_like
            Cosine of the angle between the wavevector k and the line of sight
        cosmo : dict
            Dictionary of cosmological parameters
        AP_as_nuisance : bool
            If True uses specified values for the alphas instead of computing
            them from background cosmology
        alpha_par, alpha_perp : float
            Values to use for the alphas. Only used if `AP_as_nuisance=True`

        Returns
        -------
        array_like
            `q`, `nu`: Distorted (observed) $k$ and $\mu$
        float
            `AP_amplitude`: Rescaling factor for the power spectrum

        See Also
        --------
        `AP_factors` : computes quantities for AP distortions

        Notes
        -----
        $$q = k \left( \frac{\mu^2}{\alpha_{\parallel}^2} + \frac{1-\mu^2}{\alpha_{\perp}^2} \right)^{1/2}$$

        $$\nu = \frac{\mu}{\alpha_{\parallel}} \left( \frac{\mu^2}{\alpha_{\parallel}^2} + \frac{1-\mu^2}{\alpha_{\perp}^2} \right)^{-1/2}$$
        """
        alpha_par, alpha_perp, AP_factor, AP_amplitude = \
            self.AP_factors(mu,redshift,cosmo,AP_as_nuisance,alpha_par,alpha_perp)

        k_sub = k[:, newaxis]
        nu = mu / (alpha_par * AP_factor)
        q  = k_sub * AP_factor
        return q, nu, AP_amplitude

#-------------------------------------------------------------------------------

    def Kaiser(self, b1, f, mu):
        r"""Kaiser factor

        Parameters
        ----------
        b1, f : float
            Linear bias and growth rate
        mu : array_like
            Cosine of the angle between the wavevector k and the line of sight

        Returns
        -------
        array_like
            Kaiser factor $b_1 + f~\mu^2$.
        """
        return b1 + f * mu**2

#-------------------------------------------------------------------------------

    def PowerfuncIR_real(self, redshift, do_redshift_rescaling, plinear, cosmo,
                         growth_model='lcdm', D=None, IRres=True, kind='EH'):
        """Real space building blocks

        Computes the leading order power spectrum, the next-to-leading order
        corrections and the EFT counterterm contribution in real space. If
        `IRresum=False` contributions will not be IR-resummed.  If `D` is
        `None`, the growth rate will be computed internally by the method,
        using `cosmo` and `growth_model`.

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Weher to rescale quantities from z=0 using the linear growth factor
        plinear : array_like
            Linear matter power spectrum
        cosmo : dict
            Dictionary with cosmological parameters.
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        D : float, default: None
            Linear growth factor
        IRres : bool, default: True
            Whether to perform infrared resummation
        kind : {'EH', 'DST'}, default: 'EH'
            Algorithm for IR-resummation, based on Eisenstein-Hu or DST

        Returns
        -------
        array_like
            Arrays with the building blocks for the real space galaxy power
            spectrum in the following order:
            `PLO, PNLO, k^2*PLO, Pb1b2, Pb1g2, Pb2b2, Pb2g2, Pg2g2, Pb1g3, k^2`

        Notes
        -----
         Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.
        """
        if do_redshift_rescaling:
            _, D =  self._get_growth_functions(redshift, cosmo, growth_model, f=1, D=D)
            knw, Pnw, Pw, Sigma2, dSigma2 = self.IRresum(
                0, kind, plinear, cosmo, kmin=self.kL[0])
        else:
            D = 1
            knw, Pnw, Pw, Sigma2, dSigma2 = self.IRresum(
                redshift, kind, plinear, cosmo, kmin=self.kL[0])

        DZ2 = D**2
        Pnw     *= DZ2
        Pw      *= DZ2
        Sigma2  *= DZ2
        dSigma2 *= DZ2

        Sigma2 *= IRres
        PLO     = Pnw + exp(-self.kL*self.kL*Sigma2)*Pw

        P1l_IR, Pb1b2_IR, Pb1g2_IR, Pb2b2_IR, Pb2g2_IR, Pg2g2_IR, Pb1g3_IR = \
            self.fastpt.Pk_real_halo_full_one_loop(self.kL, PLO, C_window=.75)
        PNLO    = (Pnw + exp(- self.kL*self.kL * Sigma2) * Pw *
                   (1. + self.kL*self.kL * Sigma2) + P1l_IR)

        return (PLO, PNLO, self.kL**2*PLO, Pb1b2_IR, Pb1g2_IR, Pb2b2_IR,
                Pb2g2_IR, Pg2g2_IR, Pb1g3_IR, self.kL**2)

#-------------------------------------------------------------------------------

    def _Pgg_kmu_terms(self, plinear, cosmo, redshift=0, kind='EH',
                       do_AP=False, window_convolution=None, units='h/Mpc'):
        """Loop corrections for redshift space building blocks

        Computes the terms for the loop corrections at z=0, splits into wiggle
        and no-wiggle and stores them as attributes of the class. It also sets
        interpolators with extrapolation, to be used when `do_AP==True` or
        `window_convolution!=None`

        Parameters
        ---------
        plinear : array_like
            Linear matter power spectrum
        cosmo : dict
            Dictionary with cosmological parameters
        redshift : float, default: 0
            Redshift at which to compute the power spectrum
        kind : {'EH', 'DST'}, default: 'EH'
            Algorithm for IR-resummation, based on Eisenstein-Hu or DST

        Other Parameters
        ----------------
        do_AP : bool , default: False
            Whether to apply AP distortions
        window_convolution : bool , default: None
            Whether to convolve with the window function
        units: {'h/Mpc', '1/Mpc'}, default: 'h/Mpc'
            Specifies the units of `plinear`
        """
        _, self.Pnw, self.Pw, self.Sigma2, self.dSigma2 = \
            self.IRresum(redshift, kind, plinear, cosmo, kmin=self.kL[0], units=units)

        # Loops on P_L and Pnw
        loop22_L  = self.fastpt.Pkmu_22_one_loop_terms(self.kL, plinear,
                                                       C_window=.75)
        loop22_nw = self.fastpt.Pkmu_22_one_loop_terms(self.kL, self.Pnw,
                                                       C_window=.75)
        loop13_L = self.fastpt.Pkmu_13_one_loop_terms(self.kL, plinear)
        loop13_nw = self.fastpt.Pkmu_13_one_loop_terms(self.kL, self.Pnw)
        setattr(self, 'loop22_nw', array(loop22_nw))
        setattr(self, 'loop13_nw', array(loop13_nw))

        # Compute wiggle
        loop22_w = array([i - j for i, j in zip(loop22_L, loop22_nw)])
        loop13_w = array([i - j for i, j in zip(loop13_L, loop13_nw)])
        setattr(self, 'loop22_w', loop22_w)
        setattr(self, 'loop13_w', loop13_w)

        # Interpolators
        if (window_convolution is None) & (not do_AP):
            setattr(self, 'Pnw_int', interp1d(self.kL, self.Pnw))
            setattr(self, 'Pw_int', interp1d(self.kL, self.Pw))

            setattr(self, 'loop22_nw_int', interp1d(self.kL, self.loop22_nw))
            setattr(self, 'loop13_nw_int', interp1d(self.kL, self.loop13_nw))
            setattr(self, 'loop22_w_int', interp1d(self.kL, self.loop22_w))
            setattr(self, 'loop13_w_int', interp1d(self.kL, self.loop13_w))

        else:
            setattr(self, 'Pnw_int',
                    interp1d(self.kL, self.Pnw, fill_value='extrapolate'))
            setattr(self, 'Pw_int',
                    interp1d(self.kL, self.Pw, fill_value='extrapolate'))

            setattr(self, 'loop22_nw_int',
                    interp1d(self.kL, self.loop22_nw, fill_value='extrapolate'))
            setattr(self, 'loop13_nw_int',
                    interp1d(self.kL, self.loop13_nw, fill_value='extrapolate'))
            setattr(self, 'loop22_w_int',
                    interp1d(self.kL, self.loop22_w, fill_value='extrapolate'))
            setattr(self, 'loop13_w_int',
                    interp1d(self.kL, self.loop13_w, fill_value='extrapolate'))

#-------------------------------------------------------------------------------

    def PowerfuncIR_RSD(self, redshift, cosmo, do_redshift_rescaling, plinear,
                        IRres=True, kind = 'EH', growth_model = 'lcdm',
                        f = None, D = None):
        """Redshift space building blocks

        Computes the redshift space leading order and next-to-leading order
        corrections and EFT counterterms contributions of the galaxy power
        spectrum multipoles. If `IRresum==False` contributions will not be
        IR-resummed. If `f` or `D` are `None`, the growth functions will be
        computed internally by the method, using `cosmo` and `growth_model`.

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        cosmo : dict
            Dictionary with cosmological parameters.
        do_redshift_rescaling : bool
            Weher to rescale quantities from z=0 using the linear growth factor
        plinear : array_like
            Linear matter power spectrum
        IRres : bool, default: True
            Whether to perform infrared resummation
        kind : {'EH', 'DST'}, default: 'EH'
            Algorithm for IR-resummation, based on Eisenstein-Hu or DST
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        f, D : float, default: None
            Linear growth rate and growth factor

        Returns
        -------
        list
            `P_0`, `P_2`, `P_4` : Terms to build the multipoles

        Notes
        -----
         Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.
        """

        _, self.Pnw, self.Pw, self.Sigma2, self.dSigma2 = \
            self.IRresum(redshift, kind, plinear, cosmo, kmin=self.kL[0])

        if do_redshift_rescaling:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=self.kL, f=f, D=D)
        else:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=self.kL, f=f, D=1)

        mu = np.linspace(0, 1, 101).reshape(1, 101) # This is NOT self.mu
        D_arr = np.asarray(D, dtype=float)
        f_arr = np.asarray(f, dtype=float)
        DZ2 = D_arr * D_arr
        DZ4 = D_arr**4.

        Pnw = self.Pnw * DZ2
        Pw = self.Pw * DZ2
        Pnw_sub = Pnw[:, newaxis]
        Pw_sub = Pw[:, newaxis]
        ks_sub = self.kL[:, newaxis]
        D_sub = D_arr[:, newaxis] if D_arr.ndim > 0 else D_arr
        f_sub = f_arr[:, newaxis] if f_arr.ndim > 0 else f_arr

        # Rescaling of Sigma and dSigma2
        Sigma2 = self.Sigma2 * D_sub**2 * IRres
        dSigma2 = self.dSigma2 * D_sub**2 * IRres

        Sig2mu, RSDdamp = self._muxdamp(ks_sub, mu, Sigma2, dSigma2, f_sub)

        # Integrals of the mu dependent parts of different terms
        # columns -> (growing) power of mu, rows -> multipole
        I = [[1., 1./3, 1./5,   1./7,   1./9],
             [0., 2./3, 4./7,  10./21, 40./99],
             [0., 0.,   8./35, 24./77, 48./143]]

        # The 2* in J and K is to use the symmetry of the mu integral and
        # compute the integration only over 0,1
        J = 2. * array([[simps(mu**n * RSDdamp * legendre(l)(mu), x=mu, axis=1)
                    for n in [0,2,4,6,8]] for l in [0,2,4]])

        # Integral over the mu dependent part for P_NLO
        K = 2.*array([[simps(mu**n * RSDdamp * self.kL[:,newaxis]**2. * Sig2mu *
                             legendre(l)(mu), x=mu, axis=1) for n in [0,2,4]]
                      for l in [0,2,4]])

        # Function to perform IR resummation in redshift space
        def IRresum_z(loop_nw, loop_w, iloop, imu, il, NLO=False):
            # imu -> power of mu, il -> multipole
            P_IR = (loop_nw[iloop] * I[il][imu] +
                    loop_w[iloop]  * J[il][imu] * (2. * il + 0.5))

            if NLO:
                P_IR += (loop_w[iloop] * K[il][imu] * (2. * il + 0.5))
            return P_IR

        # P_LO,l also contains terms for P_ctr,l (up to mu^8)
        P_LO  = [[IRresum_z([Pnw],[Pw], 0, i, l) for i in range(5)]
                 for l in range(3)]
        P_NLO = [[IRresum_z([Pnw],[Pw], 0, i, l, NLO=True) for i in range(3)]
                 for l in range(3)]

        # Re-scales the loop correction terms
        loop22_nw_sub = self.loop22_nw * DZ4
        loop13_nw_sub = self.loop13_nw * DZ4
        loop22_w = self.loop22_w * DZ4
        loop13_w = self.loop13_w * DZ4

        # Lists that contain indexes of fastpt terms, split into powers of mu
        iloop_22 = [range(6),range(6,16),range(16,24),range(24,27),range(27,28)]
        iloop_13 = [range(3),range(3,6), range(6,7)]

        # Computation of multipoles: lists that contain all terms
        P_22 = array([[IRresum_z(loop22_nw_sub, loop22_w, j,i,l)
                       for i in range(5) for j in iloop_22[i]]
                      for l in range(3)])

        P_13 = array([[IRresum_z(loop13_nw_sub, loop13_w, j,i,l)
                       for i in range(3) for j in iloop_13[i]]
                      for l in range(3)])

        P_13mu = array([[IRresum_z(loop13_nw_sub, loop13_w, j,i+1,l)
                         for i in range(3) for j in iloop_13[i]]
                        for l in range(3)])

        P_ctrk2 = array([[self.kL**2*P_LO[l][i]
                          for i in range(3)] for l in range(3)])

        P_ctrk4 = array([[self.kL**4*P_LO[l][i]
                          for i in range(2,5)] for l in range(3)])

        P_l = [vstack([
            [P_NLO[l][i]   for i in range(len(P_NLO[l]))],    # P_NLO
            [P_22[l][i]    for i in range(len(P_22[l]))],     # P_22
            [P_13[l][i]    for i in range(len(P_13[l]))],     # P_13
            [P_13mu[l][i]  for i in range(len(P_13mu[l]))],
            [P_ctrk2[l][i] for i in range(len(P_ctrk2[l]))],  # counterterm k^2
            [P_ctrk4[l][i] for i in range(len(P_ctrk4[l]))]]) # counterterm k^4
               for l in range(3)]

        isum = [[0,3,31] , [1,1,9,34,38] , [2,26,41] , [4] , [5,33] ,
                [6] , [7] , [8] , [10] , [11,40] , [12,25] , [13,35] ,
                [14] , [15] , [16,24,36,37,42] , [17,22] , [18,23] ,
                [19,27,30] , [20,28,43,44] , [21,29] , [32] , [39],
                [45], [46], [47], [48], [49], [50]]

        P_l_short = [[sum([[P_l[l][idx] for idx in isum[i]]
                           for i in range(28)][j], axis=0)
                      for j in range(len(isum))]
                     for l in range(3)]

        return (P_l_short[0], P_l_short[1], P_l_short[2])

#-------------------------------------------------------------------------------

    def P_kaiser(self, redshift, do_redshift_rescaling, kgrid=None,
                 growth_model='lcdm', f=None, D=None, cosmo=None, IRres=True,
                 do_AP=False, AP_as_nuisance=False, alpha_par=1, alpha_perp=1,
                 b1=1, aP=0, Psn=0):
        """Kaiser power spectrum

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Weher to rescale quantities from z=0 using the linear growth factor
        kgrid: array_like, default: None
            Wavenumber grid on which the multipoles are evaluated
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions. Options:
            {'lcdm','wcdm','w0wacdm','darkscattering','ndgp','growthindex','fr','dgp'}
        f, D: float, default: None
            Linear growth rate and growth factor
        cosmo : dict, default: None
            Dictionary with cosmological parameters.
        IRres : bool, default: True
            Whether to perform infrared resummation
        do_AP : bool , default: False
            Whether to apply AP distortions
        AP_as_nuisance: bool, default: False
            Whether quantities for AP distortions should be computed from the
            cosmology or are passed as input
        alpha_par, alpha_perp: float, default: 1
            alphas for AP distortions
        b1: float, default: 1
            Linear bias
        aP, Psn: float, default: 0
            Constant deviation from Poisson shot noise and 1/nbar

        Returns
        -------
        array_like
            `P0`, `P2`, `P4` : The power spectrum multipoles
        """
        if do_redshift_rescaling:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=kgrid, f=f, D=D)
        else:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=kgrid, f=f, D=1)

        D_arr = np.asarray(D, dtype=float)
        f_arr = np.asarray(f, dtype=float)
        D_sub = D_arr[:, newaxis] if D_arr.ndim > 0 else D_arr
        f_sub = f_arr[:, newaxis] if f_arr.ndim > 0 else f_arr
        DZ2 = D_sub * D_sub

        q = kgrid[:, newaxis]
        nu = self.mu
        AP_ampl = 1.

        if do_AP:
            q, nu, AP_ampl = self.apply_AP_distortions(
                kgrid, self.mu, redshift, cosmo, AP_as_nuisance,
                alpha_par, alpha_perp)

        # Rescale wiggle and no-wiggle P(k), Sigma and Sigma2
        Pnw_sub = self.Pnw_int(q) * DZ2
        Pw_sub = self.Pw_int(q) * DZ2
        Sigma2 = self.Sigma2 * D_sub**2 * IRres
        dSigma2 = self.dSigma2 * D_sub**2 * IRres

        Sig2mu, RSDdamp = self._muxdamp(q, nu, Sigma2, dSigma2, f_sub)

        # Next-to-leading order, counterterm, noise
        PNLO = self.Kaiser(b1, f_sub, nu)**2 * (Pnw_sub + RSDdamp * Pw_sub *
                                       (1. + q**2 * Sig2mu)) + Psn * (1. + aP)

        Pell = cosmology.multipole_projection(self.mu, PNLO, [0,2,4])

        return Pell*AP_ampl

#-------------------------------------------------------------------------------

    def P_kmu_z(self, redshift, do_redshift_rescaling, kgrid=None,
                growth_model='lcdm', f=None, D=None, cosmo=None, cosmo_fid=None,
                IRres=True, do_analytic_marg=False, do_AP=False,
                AP_as_nuisance=False, alpha_par=1, alpha_perp=1, b1=1, b2=0,
                bG2=0, bG3=0, c0=0, c2=0, c4=0, ck4=0, aP=0, e0k2=0, e2k2=0,
                Psn=0, sigma_z=0, f_out=0, **kwargs):
        """Non-linear galaxy power spectrum multipoles in redshift space

        Computes the non-linear galaxy power spectrum in redshift space. Assumes
        the self._Pgg_kmu_terms function has already been called to set
        interpolators for the power spectra, starting from a linear power
        spectrum. If `IRresum == False` the output power spectrum is not
        IR-resummed.

        Parameters
        ----------
        redshift : float
            Redshift used to evaluate the growth functions and P_L
        do_redshift_rescaling : bool
            If True P_L is computed at z=0 and rescaled with the linear growth,
            if False P_L is computed at `redshift`
        kgrid : array_like, default: None
            Wavenumber grid on which the multipoles are evaluated
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        f, D : float, default: None
            Growth rate and growth factor. If None they are computed internally
        cosmo : dict, default: None
            Dictionary with cosmological parameters
        do_analytic_marg : bool, default: False
            Whether to perform analytic marginalisation (changes the output)
        do_AP : bool, default: False
            Whether to apply AP distortions
        alpha_par, alpha_perp, b1 : float, default: 1
            AP parameters and linear bias
        b2, bG2, bG3, c0, c2, c4, ck4, aP, e0k2, e2k2 : float, default: 0
            Bias, counterterm and shot-noise parameters
        Psn : float, default: 0
            Poisson shot-noise (1/nbar)

        Returns
        -------
        array_like
            If `do_analytic_marg==False`: `Pell`, contains the power spectrum
            multipoles ordered as P0,P2,P4; else: `Pell`, `Pml`, contains the
            non-marginalised part of the multipoles and the marginalised terms
            respectively

        Other Parameters
        ----------------
        AP_as_nuisance : bool, default: False
            If True, values for alpha_par and alpha_perp can be passed, else,
            they are computed from the Fiducialcosmology and cosmo dictionary
        IRres : bool, default: True
            Whether to perform infrared resummation
        cosmo_fid : dict, default: None
            Dictionary containing the fiducial cosmology, only used to compute
            sigma_r for redshift error
        sigma_z, f_out : float, default : 0
            Systematic parameters for redshift error and interloper fraction

        Notes
        -----
         Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.
        """
        if do_redshift_rescaling:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=kgrid, f=f, D=D)
        else:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=kgrid, f=f, D=1)

        D_arr = np.asarray(D, dtype=float)
        f_arr = np.asarray(f, dtype=float)
        D_sub = D_arr[:, newaxis] if D_arr.ndim > 0 else D_arr
        f_sub = f_arr[:, newaxis] if f_arr.ndim > 0 else f_arr


        DZ2 = D_sub * D_sub
        DZ4 = D_sub**4.

        q = kgrid[:, newaxis]
        nu = self.mu
        AP_ampl = 1.

        if cosmo_fid is not None:
            sigma_r = lightspeed_kms * sigma_z / \
                (100*cosmology.Hubble_adim(redshift, cosmo_fid["Om"],
                                           cosmo_fid["w0"], cosmo_fid["wa"]))
        else:
            sigma_r = 0.

        if do_AP:
            q, nu, AP_ampl = self.apply_AP_distortions(
                kgrid, self.mu, redshift, cosmo, AP_as_nuisance,
                alpha_par, alpha_perp)

        damping_syst = np.exp(-(q*nu*sigma_r)**2) * (1-f_out)**2

        # Rescale wiggle and no-wiggle P(k), Sigma and Sigma2
        Pnw_sub = self.Pnw_int(q) * DZ2
        Pw_sub = self.Pw_int(q) * DZ2
        Sigma2 = self.Sigma2 * DZ2 * IRres
        dSigma2 = self.dSigma2 * DZ2 * IRres

        # Rescaling loops
        loop22_nw_sub =  self.loop22_nw_int(q) * DZ4
        loop13_nw_sub =  self.loop13_nw_int(q) * DZ4
        loop22_w =  self.loop22_w_int(q) * DZ4
        loop13_w =  self.loop13_w_int(q) * DZ4

        Sig2mu, RSDdamp = self._muxdamp(q, nu, Sigma2, dSigma2, f_sub)

        # Next-to-leading order, counterterm, noise
        PNLO = self.Kaiser(b1, f_sub, nu)**2 * (Pnw_sub + RSDdamp * Pw_sub *
                                       (1. + q**2 * Sig2mu))

        # Biases
        one = np.ones_like(q * nu)
        f_grid = one * f_sub
        bias22 = array([b1**2 * one, b1 * b2 * one, b1 * bG2 * one,
                        b2**2 * one, b2 * bG2 * one, bG2**2 * one,
                        nu**2 * f_grid * b1, nu**2 * f_grid * b2, nu**2 * f_grid * bG2,
                        (nu * f_grid * b1)**2, (nu * b1)**2 * f_grid,
                        nu**2 * f_grid * b1 * b2, nu**2 * f_grid * b1 * bG2,
                        (nu * f_grid)**2 * b1, (nu * f_grid)**2 * b2,
                        (nu * f_grid)**2 * bG2, (nu * f_grid)**4, nu**4 * f_grid**3,
                        nu**4 * f_grid**3 * b1, nu**4 * f_grid**2 * b2,
                        nu**4 * f_grid**2 * bG2, nu**4 * f_grid**2 * b1,
                        nu**4 * f_grid**2 * b1**2, nu**4 * f_grid**2,
                        nu**6 * f_grid**4, nu**6 * f_grid**3, nu**6 * f_grid**3 * b1,
                        nu**8 * f_grid**4])
        bias13 = array([b1 * self.Kaiser(b1, f_grid, nu), bG3*self.Kaiser(b1, f_grid, nu),
                        bG2 * self.Kaiser(b1, f_grid, nu),
                        nu**2 * f_grid * self.Kaiser(b1, f_grid, nu),
                        nu**2 * f_grid * b1 * self.Kaiser(b1, f_grid, nu),
                        (nu * f_grid)**2 * self.Kaiser(b1, f_grid, nu),
                        nu**4 * f_grid**2 * self.Kaiser(b1, f_grid, nu)])

        Pkmu_22_nw = einsum('ijk,ijk->jk', bias22, loop22_nw_sub)
        Pkmu_22_w  = einsum('ijk,ijk->jk', bias22, loop22_w)
        Pkmu_13_nw = einsum('ijk,ijk->jk', bias13, loop13_nw_sub)
        Pkmu_13_w  = einsum('ijk,ijk->jk', bias13, loop13_w)

        Pkmu_22 = Pkmu_22_nw + RSDdamp * Pkmu_22_w
        Pkmu_13 = Pkmu_13_nw + RSDdamp * Pkmu_13_w

        if do_analytic_marg:
            Pm_bG3 = damping_syst * (self.Kaiser(b1, f_sub, nu) * loop13_nw_sub[1] +
                                       RSDdamp*self.Kaiser(b1,f_sub,nu)*loop13_w[1])
            Pm_ctr = damping_syst * (q**2 * (Pnw_sub + RSDdamp * Pw_sub))
            PG3ell = cosmology.multipole_projection(self.mu, Pm_bG3, [0,2,4])
            Pc0    = cosmology.multipole_projection(self.mu, -2.*Pm_ctr,[0,2,4])
            Pc2    = cosmology.multipole_projection(
                self.mu, -2.* f_sub * nu**2 * Pm_ctr, [0,2,4])
            Pc4    = cosmology.multipole_projection(
                self.mu, -2.* f_sub**2 * nu**4 * Pm_ctr, [0,2,4])
            Pck4   = cosmology.multipole_projection(
                self.mu, f_sub**4 * nu**4 * self.Kaiser(b1,f_sub,nu)**2 * q**2 * Pm_ctr,
                [0,2,4])

            Pa = cosmology.multipole_projection(self.mu, np.full(q.shape,Psn), [0,2,4])
            Pe0k2  = cosmology.multipole_projection(self.mu, Psn*q**2, [0,2,4])
            Pe2k2  = cosmology.multipole_projection(
                self.mu, Psn*q**2 * nu**2, [0,2,4])

            Pkmu    = damping_syst * (PNLO + Pkmu_22 + Pkmu_13)
            Pell = cosmology.multipole_projection(self.mu, Pkmu, [0,2,4])
            Pml = concatenate((PG3ell, Pc0, Pc2, Pc4, Pck4, Pa, Pe0k2, Pe2k2))
            return AP_ampl*Pell, AP_ampl*Pml

        else:
            Pkmu_ctr = (-2. * (c0 + c2 * f_sub * nu**2 + c4 * f_sub * f_sub * nu**4) *
                        q**2 + ck4 * f_sub**4 * nu**4 * self.Kaiser(b1, f_sub, nu)**2 *
                        q**4) * (Pnw_sub + RSDdamp * Pw_sub)
            Pkmu_noise = Psn * ((1. + aP) + (e0k2 + e2k2 * nu**2) * q**2)

            Pkmu    = damping_syst * (PNLO + Pkmu_22 + Pkmu_13 + Pkmu_ctr) + Pkmu_noise
            Pell = cosmology.multipole_projection(self.mu, Pkmu, [0,2,4])
            return AP_ampl*Pell

        return AP_ampl*Pell

#-------------------------------------------------------------------------------

    def P_kmu_2D(self, redshift, do_redshift_rescaling, kgrid=None, mu=None,
                growth_model='lcdm', f=None, D=None, cosmo=None, IRres=True,
                 b1=1, b2=0, bG2=0, bG3=0, c0=0, c2=0, c4=0, ck4=0, **kwargs):
        r"""Anisotropic non-linear galaxy power spectrum in redshift space

        Computes the anisotropic non-linear galaxy power spectrum in redshift
        space $P(k, \mu)$. Assumes the `self._Pgg_kmu_terms` method has already
        been called to set interpolators for the power spectra, starting from a
        linear power spectrum. If `IRresum == False`, the output is not
        IR-resummed.

        Parameters
        ----------
        redshift : float
            Redshift used to evaluate the growth functions and P_L
        do_redshift_rescaling : bool
            If True P_L is computed at z=0 and rescaled with the linear growth,
            if False P_L is computed at `redshift`
        kgrid, mu : array_like, default: None
            Wavenumber and cosine of angle grid on which P(k,mu) is evaluated
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        f, D : float, default: None
            Growth rate and growth factor. If None they are computed internally
        cosmo : dict, default: None
            Dictionary with cosmological parameters
        IRres : bool, default: True
            Whether to perform infrared resummation
        b1 : float, default: 1
            Linear bias
        b2, bG2, bG3, c0, c2, c4, ck4 : float, default: 0
            Bias and counterterm parameters

        Returns
        -------
        Pkmu_nonoise : array_like
            Anisotropic galaxy power spectrum

        Note
        ----
        The output of this method does not include the noise contribution,
        systematics and AP distortions. It was implemented to interface with
        the `cloe-lib` package.

        Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.
        """
        karr_growth = kgrid[:, 0] if np.asarray(kgrid).ndim > 1 else kgrid
        if do_redshift_rescaling:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=karr_growth, f=f, D=D)
        else:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=karr_growth, f=f, D=1)

        D_arr = np.asarray(D, dtype=float)
        f_arr = np.asarray(f, dtype=float)
        D_sub = D_arr[:, newaxis] if D_arr.ndim > 0 else D_arr
        f_sub = f_arr[:, newaxis] if f_arr.ndim > 0 else f_arr
        DZ2 = D_sub * D_sub
        DZ4 = D_sub**4.

        if kgrid.ndim == 1:
            q = kgrid[:, newaxis]
        else:
            q = kgrid
        if mu.ndim ==1:
            mu = mu.reshape(1, len(mu))

        # Rescale wiggle and no-wiggle P(k), Sigma and Sigma2
        Pnw_sub = self.Pnw_int(q) * DZ2
        Pw_sub = self.Pw_int(q) * DZ2
        Sigma2 = self.Sigma2 * D_sub**2 * IRres
        dSigma2 = self.dSigma2 * D_sub**2 * IRres

        # Rescaling loops
        loop22_nw_sub =  self.loop22_nw_int(q) * DZ4
        loop13_nw_sub =  self.loop13_nw_int(q) * DZ4
        loop22_w =  self.loop22_w_int(q) * DZ4
        loop13_w =  self.loop13_w_int(q) * DZ4

        Sig2mu, RSDdamp = self._muxdamp(q, mu, Sigma2, dSigma2, f_sub)

        # Next-to-leading order, counterterm
        PNLO = self.Kaiser(b1, f_sub, mu)**2 * (Pnw_sub + RSDdamp * Pw_sub *
                                       (1. + q**2 * Sig2mu))
        Pkmu_ctr = (-2. * (c0 + c2 * f_sub * mu**2 + c4 * f_sub * f_sub * mu**4) *
                    q**2 + ck4 * f_sub**4 * mu**4 * self.Kaiser(b1, f_sub, mu)**2 *
                    q**4) * (Pnw_sub + RSDdamp * Pw_sub)

        # Biases
        one = np.ones_like(q * mu)
        f_grid = one * f_sub
        bias22 = array([b1**2 * one, b1 * b2 * one, b1 * bG2 * one,
                        b2**2 * one, b2 * bG2 * one, bG2**2 * one,
                        mu**2 * f_grid * b1, mu**2 * f_grid * b2, mu**2 * f_grid * bG2,
                        (mu * f_grid * b1)**2, (mu * b1)**2 * f_grid,
                        mu**2 * f_grid * b1 * b2, mu**2 * f_grid * b1 * bG2,
                        (mu * f_grid)**2 * b1, (mu * f_grid)**2 * b2,
                        (mu * f_grid)**2 * bG2, (mu * f_grid)**4, mu**4 * f_grid**3,
                        mu**4 * f_grid**3 * b1, mu**4 * f_grid**2 * b2,
                        mu**4 * f_grid**2 * bG2, mu**4 * f_grid**2 * b1,
                        mu**4 * f_grid**2 * b1**2, mu**4 * f_grid**2,
                        mu**6 * f_grid**4, mu**6 * f_grid**3, mu**6 * f_grid**3 * b1,
                        mu**8 * f_grid**4])
        bias13 = array([b1 * self.Kaiser(b1, f_grid, mu), bG3*self.Kaiser(b1, f_grid, mu),
                        bG2 * self.Kaiser(b1, f_grid, mu),
                        mu**2 * f_grid * self.Kaiser(b1, f_grid, mu),
                        mu**2 * f_grid * b1 * self.Kaiser(b1, f_grid, mu),
                        (mu * f_grid)**2 * self.Kaiser(b1, f_grid, mu),
                        mu**4 * f_grid**2 * self.Kaiser(b1, f_grid, mu)])

        Pkmu_22_nw = einsum('ijk,ijk->jk', bias22, loop22_nw_sub)
        Pkmu_22_w  = einsum('ijk,ijk->jk', bias22, loop22_w)
        Pkmu_13_nw = einsum('ijk,ijk->jk', bias13, loop13_nw_sub)
        Pkmu_13_w  = einsum('ijk,ijk->jk', bias13, loop13_w)

        Pkmu_22 = Pkmu_22_nw + RSDdamp * Pkmu_22_w
        Pkmu_13 = Pkmu_13_nw + RSDdamp * Pkmu_13_w
        Pkmu_nonoise = PNLO + Pkmu_22 + Pkmu_13 + Pkmu_ctr

        return Pkmu_nonoise

#-------------------------------------------------------------------------------

    def P_kmu_2D_marg_dict(self, redshift, do_redshift_rescaling, kgrid=None,
                           mu=None, growth_model='lcdm', f=None, D=None,
                           cosmo=None, IRres=True, b1=1, **kwargs):
        """Terms for marginalised building blocks

        Computes contributions to the anisotropic power spectrum
        coming from linear parameters (noise excluded). Assumes the
        `self._Pgg_kmu_terms` method has already been called to set
        interpolators for the power spectra, starting from a linear
        power spectrum. If `IRresum == False`, the output is not
        IR-resummed.

        Parameters
        ----------
        redshift : float
            Redshift used to evaluate the growth functions and P_L
        do_redshift_rescaling : bool
            If True P_L is computed at z=0 and rescaled with the linear growth,
            if False P_L is computed at `redshift`
        kgrid, mu : array_like, default: None
            Wavenumber and cosine of angle grid on which P(k,mu) is evaluated
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        f, D : float, default: None
            Growth rate and growth factor. If None they are computed internally
        cosmo : dict, default: None
            Dictionary with cosmological parameters
        IRres : bool, default: True
            Whether to perform infrared resummation
        b1 : float, default: 1
            Linear bias

        Returns
        -------
        marg_dict : dict
            Dictionary containing the anisotropic power spectra for the terms
            corresponding to linear parameters `{'bG3', 'c0', 'c2', 'c4', 'ck4'}`

        Note
        ----
        The output of this method does not include the noise contribution,
        systematics and AP distortions. It was implemented to interface with
        the `cloe-lib` package.

        Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.

        """
        karr_growth = kgrid[:, 0] if np.asarray(kgrid).ndim > 1 else kgrid
        if do_redshift_rescaling:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=karr_growth, f=f, D=D)
        else:
            f, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=karr_growth, f=f, D=1)

        D_arr = np.asarray(D, dtype=float)
        f_arr = np.asarray(f, dtype=float)
        D_sub = D_arr[:, newaxis] if D_arr.ndim > 0 else D_arr
        f_sub = f_arr[:, newaxis] if f_arr.ndim > 0 else f_arr
        DZ2 = D_sub * D_sub
        DZ4 = D_sub**4.

        if kgrid.ndim == 1:
            q = kgrid[:, newaxis]
        else:
            q = kgrid
        if mu.ndim ==1:
            mu = mu.reshape(1, len(mu))

        # Rescale wiggle and no-wiggle P(k), Sigma and Sigma2
        Pnw_sub = self.Pnw_int(q) * DZ2
        Pw_sub = self.Pw_int(q) * DZ2
        Sigma2 = self.Sigma2 * D_sub**2 * IRres
        dSigma2 = self.dSigma2 * D_sub**2 * IRres

        Sig2mu, RSDdamp = self._muxdamp(q, mu, Sigma2, dSigma2, f_sub)

        # Rescaling loops
        loop13_nw_sub =  self.loop13_nw_int(q) * DZ4
        loop13_w =  self.loop13_w_int(q) * DZ4

        Pkmu_bG3 = self.Kaiser(b1, f_sub, mu) * loop13_nw_sub[1] +\
            RSDdamp*self.Kaiser(b1, f_sub, mu) * loop13_w[1]
        Pkmu_ctr = q**2 * (Pnw_sub + RSDdamp * Pw_sub)

        marg_dict = {'bG3': Pkmu_bG3,
                     'c0': -2.* Pkmu_ctr,
                     'c2': -2.* f_sub * mu**2 * Pkmu_ctr,
                     'c4': -2.* f_sub**2 * mu**4 * Pkmu_ctr,
                     'ck4': f_sub**4* mu**4* self.Kaiser(b1,f_sub,mu)**2* q**2* Pkmu_ctr
                     }
        return marg_dict

#-------------------------------------------------------------------------------

    def convolve_power_spectrum(self, func, window, redshift,
                                    do_redshift_rescaling, kpW, **kwargs):
        """Computes convolution with window function

        Convolves the output of `func` with the window function, works both for
        the marginalised and non-marginalised case.

        Parameters
        ---------
        func : function
            Function to convolve (must return arrays)
        window : dict
            Mixing matrix
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Weher to rescale quantities from z=0 using the linear growth factor
        **func_kwargs
            Additional keyword arguments of `func`

        Returns
        -------
        P_conv : array_like
            Convolved multipoles
        Pml_conv : array_like
            Convolved marginalised terms (if do_analytic_marg=True)

        See Also
        --------
        `P_kmu_z` : P(k) multipoles (pre-reconstruction)
        `Pgg_BAO_l` : P(k) multipoles (post-reconstruction)
        `Pgg_BAO_l_marg` : P(k) multipoles (post-rec) split in marg and non-marg
        """
        Pml_conv = None
        kgrid = kwargs.get("kgrid", None)

        if kwargs.get('do_analytic_marg', False):
            P_noconv, Pml_noconv = func(redshift, do_redshift_rescaling, **kwargs)

            Pml_conv_list = []
            for i in range(0, len(Pml_noconv), 3):
                Pml_noconv_block = np.block([
                    np.interp(kpW, kgrid, Pml_noconv[l+i]) for l in range(0,3)]).T
                Pml_conv_tmp = np.split(((window @ Pml_noconv_block).T), 3, axis=0)
                Pml_conv_list.append(Pml_conv_tmp)
            Pml_conv = np.concatenate(Pml_conv_list)

        else:
            P_noconv = func(redshift, do_redshift_rescaling, **kwargs)

        P_noconv_block = np.block([
            np.interp(kpW, kgrid, P_noconv[l]) for l in range(3)]).T
        P_conv = np.split(((window @ P_noconv_block).T),3, axis=0)

        return P_conv, Pml_conv

#-------------------------------------------------------------------------------

    def P_ell_conv_BAO_marg(self, window, kpW, redshift, do_redshift_rescaling,
                            kgrid=None, D=None, beta=0., alpha_par=1.,
                            alpha_perp=1., Sigma_par=0., Sigma_perp=0.,
                            Sigma_rec=0., Sigma_s=0., B=1., Psn=0., **kwargs):
        """Convolves the post-reconstruction power spectrum with the window
        function for the marginalised case

        Parameters
        ----------
        window : dict
            Mixing matrix
        kpW : list
            Mixing matrix wavenumbers k'
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Weher to rescale quantities from z=0 using the linear growth factor
        kgrid: array_like, default: None
            Wavenumber grid on which the multipoles are evaluated
        D : float, default: None
            Growth factor. If None it is computed internally
        alpha_par, alpha_perp, B : float, default: 1
            AP parameters and amplitude (includes rs_fid/rs)
        beta, Sigma_par, Sigma_perp, Sigma_rec, Sigma_s : float, default: 0
            Reconstruction parameters
        Psn : float, default: 0
            Poisson shot-noise (1/nbar)

        Returns
        -------
        array_like
            `P_conv`, `Pml_conv` : Convolved terms for the non-marginalised and
            marginalised multipoles

        Notes
        -----
        Only for the analytic marginalised case
        """
        P_noconv, bb_no_conv = self.Pgg_BAO_l_marg(
            redshift, do_redshift_rescaling, **kwargs)

        P_noconv_block = np.block([P_noconv[l] for l in range(3)]).T
        P_conv = (window @ P_noconv_block).T
        convolved = np.split(P_conv, 3, axis=0)

        BB_conv = []
        for i in range(0, len(bb_no_conv), 3):
            bb_noconv_block = np.block([bb_no_conv[l+i] for l in range(0,3)]).T
            bb_conv = (window @ bb_noconv_block).T
            bb = np.split(bb_conv, 3, axis=0)
            BB_conv.append(bb)
        Pml_conv = np.concatenate(BB_conv)

        return Pml_conv, Pml_conv

#-------------------------------------------------------------------------------

    def Pgg_BAO_l(self, redshift, do_redshift_rescaling, kgrid=None, D=None,
                  beta=0., alpha_par=1, alpha_perp=1, Sigma_par=0, Sigma_perp=0,
                  Sigma_rec=0, Sigma_s=0, B=1, Psn=0, growth_model='lcdm',
                  cosmo=None, **kwargs):
        r"""Galaxy power spectrum multipoles post-reconstruction

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Whether to rescale quantities from z=0 using the linear growth factor
        kgrid: array_like, default: None
            Wavenumber grid on which the multipoles are evaluated
        D : float, default: None
            Growth factor. If None it is computed internally
        alpha_par, alpha_perp, B : float, default: 1
            AP parameters and amplitude (includes rs_fid/rs)
        beta, Sigma_par, Sigma_perp, Sigma_rec, Sigma_s : float, default: 0
            Reconstruction parameters
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        Psn : float, default: 0
            Poisson shot-noise (1/nbar)
        cosmo : dict, default: None
            Dictionary with cosmological parameters.
        **kwargs

        Returns
        -------
        array_like
            $P^{BAO}_l+BB_l$ : Multipoles of the galaxy power spectrum

        Other Parameters
        ----------------
        a_li : float, default: 0
            Broad-band parameters for the l-th polynomial, l=(0,2,4), i=(0,1,2,3,4,5)

        Notes
        -----
        Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.

        $BB_l(k) = a_{l0}/k^3+a_{l1}/k^2+a_{l2}/k+a_{l3}+a_{l4}~k+a_{l5}~k^2$
        """
        if do_redshift_rescaling:
            _, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=kgrid, D=D)
        else:
            D = 1

        D_arr = np.asarray(D, dtype=float)
        beta_arr = np.asarray(beta, dtype=float)
        D_sub = D_arr[None, :] if D_arr.ndim > 0 else D_arr
        beta_sub = beta_arr[None, :] if beta_arr.ndim > 0 else beta_arr
        DZ2 = D_sub * D_sub

        elles = np.array([0,2,4])
        mus = np.linspace(-1,1,101)
        kref = 0.2
        norm = self.Pnw_int(kref) #43.42091852 # norm, value of Pk at k=rref

        # Setting up reconstruction template
        if Sigma_rec != 0:
            Sk = lambda k: np.exp(-k**2 * Sigma_rec**2/2.)
        else:
            Sk = lambda k: 0

        #--adding RSD
        sigma_v2 = lambda mu: (1.-mu**2) * Sigma_perp**2 + mu**2 * Sigma_par**2
        Kaiser   = lambda mu,k: (1. + mu**2 * beta_sub * (1. - Sk(k)))**2
        FoG      = lambda mu,k: 1./(1.+k**2 * mu**2 * Sigma_s**2/2.)

        P_mu_k = lambda mu,k: B**2 * Kaiser(mu,k) * FoG(mu,k) * DZ2 * (
            self.Pnw_int(k) + self.Pw_int(k)*np.exp(-k**2 * sigma_v2(mu) / 2.))

        # Adding AP (This part can be rewritten to use a common function,
        # here the binning is preserved)
        F = alpha_par/alpha_perp
        Alpha_resc = (alpha_perp**2 * alpha_par)

        q  = lambda mu,k : k/alpha_perp * (1 + mu**2 * (1/F**2-1))**(0.5)
        nu = lambda mu : mu/F * (1 + mu**2 * (1/F**2-1))**(-0.5)

        # NOTE: B reabsorbes the rescaling, no need to put the rs rescaling
        P_nu_q = lambda mu,k: P_mu_k(nu(mu), q(mu,k))

        P_nu_q_disc = P_nu_q(mus[:,None], kgrid[None,:])

        P_BAO_l = array([simps((2*l+1.)/2.*legendre(l)(mus)[:,None]*P_nu_q_disc,
                               mus, axis=0) for l in elles])

        P_BAO_l[0] += Psn

        P_BAO_l /= Alpha_resc

        #adding Broad-band
        bb_l = zeros((len(elles),len(kgrid)))
        for l in range(0,3):
            for i in range(-3,3):
                str_ali = 'a'+str(elles[l])+str(i+3)
                if str_ali in kwargs.keys():
                    bb_l[l] += kwargs[str_ali] * kgrid**i * norm * kref**(-i)

        return P_BAO_l + bb_l

#-------------------------------------------------------------------------------

    def Pgg_BAO_l_marg(self, redshift, do_redshift_rescaling, kgrid=None,
                       D=None, beta=0., alpha_par=1, alpha_perp=1, Sigma_par=0,
                       Sigma_perp=0, Sigma_rec=0, Sigma_s=0, B=1, Psn=0,
                       cosmo=None, growth_model='lcdm', **kwargs):
        """Galaxy power spectrum multipoles post-reconstruction (analytic
        marginalised case)

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Whether to rescale quantities from z=0 using the linear growth factor
        kgrid: array_like, default: None
            Wavenumber grid on which the multipoles are evaluated
        D : float, default: None
            Growth factor. If None it is computed internally
        alpha_par, alpha_perp, B : float, default: 1
            AP parameters and amplitude (includes rs_fid/rs)
        beta, Sigma_par, Sigma_perp, Sigma_rec, Sigma_s : float, default: 0
            Reconstruction parameters
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions.
        Psn : float, default: 0
            Poisson shot-noise (1/nbar)
        cosmo : dict, default: None
            Dictionary with cosmological parameters.
        **kwargs

        Returns
        -------
        array_like
            `P_BAO_l`, `P_bb_l`: Multipoles of the galaxy power spectrum,
            non-marg and marg respectively

        Notes
        -----
        Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.
        """
        if do_redshift_rescaling:
            _, D = self._get_growth_functions(
                redshift, cosmo, growth_model, karr=kgrid, D=D)
        else:
            D = 1

        D_arr = np.asarray(D, dtype=float)
        beta_arr = np.asarray(beta, dtype=float)
        D_sub = D_arr[None, :] if D_arr.ndim > 0 else D_arr
        beta_sub = beta_arr[None, :] if beta_arr.ndim > 0 else beta_arr
        DZ2 = D_sub * D_sub

        elles = np.array([0,2,4])
        mus = np.linspace(-1,1,101)
        kref = 0.2
        norm = self.Pnw_int(kref) #43.42091852 # norm, value of Pk at k=rref

        # Setting up reconstruction template
        if Sigma_rec != 0:
            Sk = lambda k: np.exp(-k**2 * Sigma_rec**2/2.)
        else:
            Sk = lambda k: 0

        #--adding RSD
        sigma_v2 = lambda mu: (1.-mu**2) * Sigma_perp**2 + mu**2 * Sigma_par**2
        Kaiser   = lambda mu,k: (1. + mu**2 * beta_sub * (1. - Sk(k)))**2
        FoG      = lambda mu,k: 1./(1.+k**2 * mu**2 * Sigma_s**2/2.)

        P_mu_k = lambda mu,k: B**2 * Kaiser(mu,k) * FoG(mu,k) * DZ2 * (
            self.Pnw_int(k) + self.Pw_int(k)*np.exp(-k**2 * sigma_v2(mu) / 2.))

        # Adding AP (This part can be rewritten to use a common function,
        # here the binning is preserved)
        F = alpha_par/alpha_perp
        Alpha_resc = (alpha_perp**2 * alpha_par)

        q  = lambda mu,k : k/alpha_perp * (1 + mu**2 * (1/F**2-1))**(0.5)
        nu = lambda mu : mu/F * (1 + mu**2 * (1/F**2-1))**(-0.5)

        # NOTE: B reabsorbes the rescaling, no need to put the rs rescaling
        P_nu_q = lambda mu,k: P_mu_k(nu(mu), q(mu,k))

        P_nu_q_disc = P_nu_q(mus[:,None], kgrid[None,:])

        P_BAO_l = array([simps((2*l+1.)/2.*legendre(l)(mus)[:,None]*P_nu_q_disc,
                               mus, axis=0) for l in elles])

        P_BAO_l[0] += Psn

        P_BAO_l /= Alpha_resc

        #adding Broad-band
        zero_array = np.zeros(len(kgrid))
        bb_ell = []
        for i in range(-3, 3):
            for l in range(3):
                arrays = [zero_array.copy(), zero_array.copy(), zero_array.copy()]
                arrays[l] = kgrid**i * norm * kref**(-i)
                bb_ell.append(arrays)

        P_bb_l = np.concatenate(bb_ell)

        return P_BAO_l, P_bb_l

#-------------------------------------------------------------------------------

    def _tns_model(self, redshift, do_redshift_rescaling, plinear, cosmo,
                  b1=1, sigma_v=0, growth_model='lcdm', f=None, D=None):
        r"""tns_model

        Returns the TNS model for the anisotropic galaxy power spectrum.
        The FoG damping is implemented with Lorentzian.

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Weher to rescale quantities from z=0 using the linear growth factor
        plinear : array_like
            Linear matter power spectrum
        cosmo : dict, default: None
            Dictionary with cosmological parameters.
        b1 : float, default: 1
            Linear bias
        sigma_v : float, default: 0
            Velocity dispersion
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions. Options:
            {'lcdm','wcdm','w0wacdm','darkscattering','ndgp','growthindex','fr','dgp'}
        f, D : float, default: None
            Growth rate and growth factor

        Returns
        -------
        ABsum*D_fog : array_like
            Anisotropic galaxy power spectrum.
        """
        if do_redshift_rescaling:
            f,D=self._get_growth_functions(redshift, cosmo, growth_model, f=f, D=D)
        else:
            f,D=self._get_growth_functions(redshift, cosmo, growth_model, f=f, D=1)

        DZ2 = D*D
        plinear *= DZ2
        A1, A3, A5, B0, B2, B4, B6, P_Ap1, P_Ap3, P_Ap5 = \
            self.fastpt.myRSD_components(plinear, f, b1, C_window=.75)
        # check b1 in P_Ap1,2,3

        ABsum_mu2 = (self.kL * f * (A1 + P_Ap1) + (f * self.kL)**2 * B0)
        ABsum_mu4 = (self.kL * f * (A3 + P_Ap3) + (f * self.kL)**2 * B2)
        ABsum_mu6 = (self.kL * f * (A5 + P_Ap5) + (f * self.kL)**2 * B4)
        ABsum_mu8 = (f * self.kL)**2 * B6

        mu = self.mu
        D_fog = 1 / (1. + (self.kL[:,newaxis] * self.mu * sigma_v)**2/2.)

        ABsum = ABsum_mu2[:,newaxis] * self.mu**2 + ABsum_mu4[:,newaxis] * self.mu**4 + \
            ABsum_mu6[:,newaxis] * self.mu**6 + ABsum_mu8[:,newaxis] * self.mu**8

        # Leading order, delta-delta, delta-theta, theta-theta
        PLO = self.Kaiser(b1, f, self.mu)**2 * plinear[:,newaxis]

        Pdd = mu**0 * self.fastpt.Pk_real_halo_full_one_loop(
            self.kL, plinear, C_window=.75)[0][:,newaxis]
        Pdt = mu**2*f*b1 * self.fastpt.Pkmu_tns_dt(
            self.kL, plinear, C_window=.75)[:,newaxis]
        Ptt = mu**4*f**2*self.fastpt.Pkmu_tns_tt(
            self.kL, plinear, C_window=.75)[:,newaxis]
        P_spt = PLO + Pdd + Pdt + Ptt

        return (ABsum + P_spt) * D_fog

#-------------------------------------------------------------------------------

    def Pgg_real(self, b1=1, b2=0, bG2=0, bG3=0, c0=0, aP=0, ek2=0, Psn=0,
                 loop=True):
        """**DEPRECATED** Galaxy power spectrum in real space

        If the bias parameters are not specified, the real space matter power
        spectrum is computed. Uses the specified bias, counterterm, and
        stochastic parameters.


        Parameters
        ----------
        b1 : float, default: 1
            Linear bias
        b2, bG2, bG3, c0, aP, ek2 : float, default: 0
            Bias, counterterm and noise parameters
        Psn : float, default: 0
            Poisson shot-noise (1/nbar)
        loop : bool, default: True
            If True, computes the 1-loop power spectrum. If False, computes the
            linear model. Defaults to True.

        Returns
        -------
        P_gg : array_like
            Galaxy power spectrum.
        """
        return ((1. - float(loop))*b1*b1*self.Pk['LO'] +
                float(loop) * (b1*b1*self.Pk['NLO'] + b1*b2*self.Pk['b1b2'] +
                               b1*bG2*self.Pk['b1bG2'] + b2*b2*self.Pk['b2b2'] +
                               b2*bG2*self.Pk['b2bG2'] +
                               bG2*bG2*self.Pk['bG2bG2'] +
                               b1*bG3*self.Pk['b1bG3'] + ek2*self.Pk['k2'] -
                               2.*c0*self.Pk['k2LO']) + (1.+aP)*Psn)

#-------------------------------------------------------------------------------

    def Pgm_real(self, b1=1, b2=0, bG2=0, bG3=0, c0=0, ek2=0, loop=True):
        """**DEPRECATED** Galaxy-matter power spectrum in real space

        Uses the specified bias, counterterm, and stochastic parameters

        Parameters
        ----------
        b1 : float, default: 1
            Linear bias
        b2, bG2, bG3, c0, ek2 : float, default: 0
            Bias, counterterm and noise parameters
        loop : bool, default: True
            If `True`, computes the 1-loop power spectrum, else computes the
            linear model.

        Returns
        -------
        P_gm : array_like
            Cross galaxy-matter power spectrum.
        """
        return ((1. - float(loop)) * b1 * self.Pk['LO'] +
                float(loop) * (b1 * self.Pk['NLO'] +
                               0.5 * (b2 * self.Pk['b1b2'] +
                                      bG2*self.Pk['b1bG2'] +
                                      b1*bG3*self.Pk['b1bG3']) +
                               ek2*self.Pk['k2'] - 2. * c0 * self.Pk['k2LO']))

#-------------------------------------------------------------------------------

    def Pmm_real(self, c0=0, loop=True):
        """**DEPRECATED** Computes the matter power spectrum in real space given
        the effective sound-speed.

        Parameters
        ----------
        c0 : float, default: 0
            Effective sound-speed
        loop : bool, default: True
            If `True`, computes the 1-loop power spectrum else, computes the
            linear model.

        Returns
        -------
        P_mm : array_like
            The real space matter power spectrum
        """
        return ((1. - float(loop)) * self.Pk['LO'] +
                float(loop) * (self.Pk['NLO'] - 2. * c0 * self.Pk['k2LO']))

#-------------------------------------------------------------------------------

    def Pgg_l(self, l, f=None, **kwargs):
        """**DEPRECATED** Galaxy power spectrum multipoles

        Computes the galaxy power spectrum multipoles given a set of bias
        counterterm, and stochastic parameters. By default, the growth rate is
        computed from the cosmology, but a different value can be specified.

        Parameters
        ----------
        l : int
            Multipole degree
        f : None or float
            Growth rate
        **kwargs

        Returns
        -------
        array_like
            Specified multipole of the galaxy power spectrum

        Additional Parameters
        ---------------------
        b1 : float, default: 1
            Linear bias
        b2, bG2, bG3, c0, c2, c4, ck4, aP, e0k2, e2k2 : float, default: 0
            Bias, counterterm and noise parameters
        Psn : float, default: self.Psn
            Poisson shot-noise
        """
        if f is None:
            f = self.f

        # Bias parameters
        b1 = kwargs['b1'] if 'b1' in kwargs.keys() else 1
        b2 = kwargs['b2'] if 'b2' in kwargs.keys() else 0
        bG2 = kwargs['bG2'] if 'bG2' in kwargs.keys() else 0
        bG3 = kwargs['bG3'] if 'bG3' in kwargs.keys() else 0
        c0 = kwargs['c0'] if 'c0' in kwargs.keys() else 0
        c2 = kwargs['c2'] if 'c2' in kwargs.keys() else 0
        c4 = kwargs['c4'] if 'c4' in kwargs.keys() else 0
        ck4 = kwargs['ck4'] if 'ck4' in kwargs.keys() else 0
        aP = kwargs['aP'] if 'aP' in kwargs.keys() else 0
        e0k2 = kwargs['e0k2'] if 'e0k2' in kwargs.keys() else 0
        e2k2 = kwargs['e2k2'] if 'e2k2' in kwargs.keys() else 0
        Psn = kwargs['Psn'] if 'Psn' in kwargs.keys() else self.Psn

        Plk = self.P_ell_k[l]
        Pdet = (b1*b1*Plk['b1b1'] + f*b1*Plk['fb1'] + f*f*Plk['f2'] +
                b1*b2*Plk['b1b2'] + b1*bG2*Plk['b1bG2'] +
                b2*b2*Plk['b2b2'] + b2*bG2*Plk['b2bG2'] +
                bG2*bG2*Plk['bG2bG2'] + f*b2*Plk['fb2'] +
                f*bG2*Plk['fbG2'] + f*f*b1*b1*Plk['f2b12'] +
                f*b1*b1*Plk['fb12'] + f*b1*b2*Plk['fb1b2'] +
                f*b1*bG2*Plk['fb1bG2'] + f*f*b1*Plk['f2b1'] +
                f*f*b2*Plk['f2b2'] + f*f*bG2*Plk['f2bG2'] +
                f*f*f*f*Plk['f4'] + f*f*f*Plk['f3'] +
                f*f*f*b1*Plk['f3b1'] + b1*bG3*Plk['b1bG3'] +
                f*bG3*Plk['fbG3'] - 2.*c0*Plk['c0'] -
                2.*f*c2*Plk['fc2'] - 2.*f*f*c4*Plk['f2c4'] +
                f**4*b1**2*ck4*Plk['f4b12ck4'] +
                2.*f**5*b1*ck4*Plk['f5b1ck4'] + f**6*ck4*Plk['f6ck4'])

        Pstoch = Psn * ((l*l/8. - 0.75*l+1) * ((1. + aP) + e0k2 * Plk['e0k2']) +
                        (l - 0.25*l*l) * e2k2 * Plk['e2k2'])

        return Pdet+Pstoch

#-------------------------------------------------------------------------------

    def Bg_real(self, k1, k2, k3, b1=1, b2=0, bG2=0, a1=0, a2=0, Psn=0):
        """Galaxy bispectrum at tree-level in real space given a set of bias and
        shot-noise parameters.

        Parameters
        ----------
        k1, k2, k3 : array_like
            Sides of Fourier triangles
        b1 : float, default: 1
            Linear bias
        b2, bG2, a1, a2 : float, default:0
            Bias and deviation from Poisson shot-noise
        Psn : float, default: 0
            Poisson shot-noise

        Returns
        -------
        array_like
            Real space galaxy bispectrum
        """
        mu12 = 0.5*(k3**2-k1**2-k2**2)/(k1*k2)
        mu23 = 0.5*(k1**2-k2**2-k3**2)/(k2*k3)
        mu31 = 0.5*(k2**2-k3**2-k1**2)/(k3*k1)

        F2_12 = 5./7 + 0.5*mu12*(k1/k2+k2/k1) + 2.*mu12**2/7
        F2_23 = 5./7 + 0.5*mu23*(k2/k3+k3/k2) + 2.*mu23**2/7
        F2_31 = 5./7 + 0.5*mu31*(k3/k1+k1/k3) + 2.*mu31**2/7

        S_12 = mu12**2 - 1.
        S_23 = mu23**2 - 1.
        S_31 = mu31**2 - 1.

        PkL = InterpolatedUnivariateSpline(self.kL, self.Pk['LO'], k=3)
        Pk1 = PkL(k1)
        Pk2 = PkL(k2)
        Pk3 = PkL(k3)

        return (2.*b1**2* ((b1*F2_12 + 0.5*b2 + bG2*S_12) * Pk1*Pk2 +
                           (b1*F2_23 + 0.5*b2 + bG2*S_23) * Pk2*Pk3 +
                           (b1*F2_31 + 0.5*b2 + bG2*S_31) * Pk3*Pk1) +
                b1**2 * (1. + a1)*(Pk1 + Pk2 + Pk3) * Psn + (1. + a2) * Psn**2)

#-------------------------------------------------------------------------------

    def Bispfunc_RSD(self, redshift, do_redshift_rescaling, plinear, k1, k2, k3,
                     Is0, Is2, Is4, cosmo, do_AP=False, growth_model='lcdm',
                     D=None, **kwargs):
        """Building blocks for the redshift-space bispectrum evaluated
        on the input momenta, as three lists for monopole, quadrupole and
        hexadecapole.

        Parameters
        ----------
        redshift : float
            Redshift at which to compute the power spectrum
        do_redshift_rescaling : bool
            Whether to rescale quantities from z=0 using the linear growth factor
        plinear : array_like
            Linear matter power spectrum
        k1, k2, k3 : array_like
            Sides of Fourier triangles
        Is0, Is2, Is4 : dict
            Dictionary of kernels evaluated on the triangles
        cosmo : dict
            Dictionary with cosmological parameters
        do_AP : bool, default: False
            Whether to apply AP distortions
        growth_model : str, default: 'lcdm'
            Background model to compute the growth functions
        D : float, default: None
            Growth factor. If `None` it is computed internally
        **kwargs

        Returns
        -------
        array_like
            `B0`, `B2`, `B4`: building blocks for each bispectrum multipole

        Notes
        -----
        Options for `growth_model`: `{'lcdm','wcdm','w0wacdm','darkscattering',
        'ndgp','growthindex','fr','dgp'}`.

        See Also
        --------
        `Bl_terms` : lower level building blocks without AP terms
        `Bl_terms_AP` : lower level building blocks with AP terms
        """
        if do_redshift_rescaling:
            _,D = self._get_growth_functions(redshift,cosmo,growth_model,f=0,D=D)
        else:
            D = 1

        PL = D**2 * plinear

        if do_AP:
            B0 = self.Bl_terms_AP(k1, k2, k3, PL, Is0, **kwargs)

            l2 = self.Bl_terms_AP(k1, k2, k3, PL, Is2, **kwargs)
            l4 = self.Bl_terms_AP(k1, k2, k3, PL, Is4, **kwargs)

        else:
            B0 = self.Bl_terms(0, k1, k2, k3, PL, **kwargs)

            l2 = self.Bl_terms(2, k1, k2, k3, PL, **kwargs)
            l4 = self.Bl_terms(4, k1, k2, k3, PL, **kwargs)

        B2 = 2.5 * (3. * l2 - B0) / (2.*pi)
        B4 = 1.125 * (35. * l4 - 30. * l2 + 3. * B0) / (2.*pi)

        B0 /= (2.*pi)
        B0 = np.insert(B0, len(B0), ones(len(k1)), axis=0)

        return B0, B2, B4

#-------------------------------------------------------------------------------

    def Bl_terms(self, a, k1, k2, k3, PL, K=None, **kwargs):
        r"""Lower level building blocks for the bispectrum multipoles

        Parameters
        ----------
        a : int
            Power of $\mu_1$
        k1, k2, k3 : array_like
            Sides of Fourier triangles
        PL : array_like
            Linear matter power spectrum
        K : dict, default: None
            Dictionary with kernels evaluated on the triangles
        **kwargs

        Returns
        -------
        array_like
            Array with the building blocks for the tree-level bispectrum
            multipoles

        Notes
        -----
        The output has the following order: `Bb13, Bb12b2, Bb12bG2, Bfb12,
        Bfb13, Bf2b12, Bfb1b2, Bfb1bG2, Bf2b1, Bf3b1, Bf2b2, Bf2bG2, Bf3, Bf4,
        Bb12a1, Bfb1a1, Bf2a1`

        See Also
        --------
        `Bispfunc_RSD` : building blocks for the bispectrum multipoles
        `Bl_terms_AP` : lower level building blocks with AP terms
        """
        PkL = InterpolatedUnivariateSpline(self.kL, PL, k=3)

        def muij(kk):
            ki, kj, kl = kk
            return 0.5*(kl**2 - ki**2 - kj**2)/(ki*kj)

        def Ia(bc, a, kk):
            k1, k2, k3 = kk
            if bc == '00':
                return 2.*pi*(1.+(-1)**a) / (1.+a)
            elif bc == '01':
                return 2.*pi*(-1.+(-1)**a)*(k1 + k2*muij(kk)) / ((2.+a)*k3)
            elif bc == '02':
                return ((2.*pi * (1.+(-1)**a) *
                         ((1.+a)*k1**2 + 2.*(1.+a)*k1*k2*muij(kk) +
                          k2**2*(1.+a*muij(kk)**2))) / ((1.+a)*(3.+a)*k3**2))
            elif bc == '03':
                return ((2.*pi * (-1.+(-1)**a) * (k1 +  k2*muij(kk)) *
                         ((2.+a)*k1**2 + 2.*(2.+a)*k1*k2*muij(kk) +
                          k2**2*(3.+(a-1.)*muij(kk)**2))) /
                        ((2.+a)*(4.+a)*k3**3))
            elif bc == '04':
                return ((2.*pi * (1.+(-1)**a) *
                         ((1.+a)*(3.+a)*k1**4 +
                          4*(1.+a)*(3.+a)*k1**3*k2*muij(kk) +
                          4*(1.+a)*k1*k2**3*muij(kk)*(3.+a*muij(kk)**2) +
                          6*k1**2*k2**2*(1.+a+(1.+a)*(2.+a)*muij(kk)**2) +
                          k2**4*(3.+6.*a*muij(kk)**2+(a-2.)*a*muij(kk)**4)))/
                        ((1.+a)*(3.+a)*(5.+a)*k3**4))

            elif bc == '10':
                return -((2.*pi * (-1.+(-1)**a) * muij(kk)) / (2.+a))
            elif bc == '11':
                return -((2.*pi * (1.+(-1)**a) *
                          (k2 + (1.+a)*k1*muij(kk) + a*k2*muij(kk)**2)) /
                         ((1.+a)*(3.+a)*k3))
            elif bc == '12':
                return -((2.*pi * (-1.+(-1)**a) *
                          ((2.+a)*k1**2*muij(kk) +
                           k2**2 * muij(kk) * (3.+(a-1.) * muij(kk)**2)+
                           2 * k1 * (k2 + (1.+a) * k2 * muij(kk)**2))) /
                         ((2.+a) * (4.+a) * k3**2))
            elif bc == '13':
                return -((2.*pi * (1.+(-1)**a) *
                          ((1.+a)*(3.+a)*k1**3*muij(kk) +
                           3.*(1.+a)*k1*k2**2*muij(kk)*(3.+a*muij(kk)**2)+
                           3.*k1**2*k2*(1.+a+(1.+a)*(2.+a)*muij(kk)**2) +
                           k2**3*(3.+6.*a*muij(kk)**2+(a-2.)*a*
                                  muij(kk)**4))) / ((1.+a)*(3.+a)*(5.+a)*k3**3))
            elif bc == '14':
                return -((2.*pi * (-1.+(-1)**a) *
                          ((2.+a)*(4.+a)*k1**4*muij(kk) +
                           6.*(2.+a)*k1**2*k2**2*muij(kk)*
                           (3.+(1.+a)*muij(kk)**2)+
                           4.*k1**3*k2*(2.+a+(2.+a)*(3.+a)*muij(kk)**2) +
                           4.*k1*k2**3*(3.+6.*(1.+a)*muij(kk)**2+
                                        (-1.+a**2)*muij(kk)**4) +
                           k2**4*muij(kk)*(15.+(-1.+a)*muij(kk)**2*
                                                 (10.+(-3.+a)*muij(kk)**2)))) /
                         ((2.+a)*(4.+a)*(6.+a)*k3**4))

            elif bc == '20':
                return ((2*pi*(1.+(-1)**a)*(1.+a*muij(kk)**2))/((1.+a)*(3.+a)))
            elif bc == '21':
                return ((2.*pi * (-1.+(-1)**a) *
                         (k1 + (1.+a)*k1*muij(kk)**2 +
                          k2*muij(kk)*(3.+(a-1.)*muij(kk)**2))) /
                        ((2.+a)*(4.+a)*k3))
            elif bc == '22':
                return ((2.*pi * (1.+(-1)**a) *
                         (2.*(1.+a)*k1*k2*muij(kk)*(3.+a*muij(kk)**2)+
                          k1**2*(1.+a+(1.+a)*(2.+a)*muij(kk)**2) +
                          k2**2*(3.+6.*a*muij(kk)**2+(-2.+a)*a*
                                 muij(kk)**4))) / ((1.+a)*(3.+a)*(5.+a)*k3**2))
            elif bc == '23':
                return ((2.*pi * (-1.+(-1)**a) *
                         (3.*(2.+a)*k1**2*k2*muij(kk)*
                          (3.+(1.+a)*muij(kk)**2) +
                          k1**3*(2.+a+(2.+a)*(3.+a)*muij(kk)**2) +
                          3.*k1*k2**2*(3.+6.*(1.+a)*muij(kk)**2 +
                                       (a**2-1.)*muij(kk)**4) +
                          k2**3*muij(kk)*(15.+(a-1.)*muij(kk)**2*
                                                (10.+(a-3.)*muij(kk)**2)))) /
                        ((2.+a)*(4.+a)*(6.+a)*k3**3))

            elif bc == '30':
                return -((2.*pi * (-1.+(-1)**a) *
                          muij(kk)*(3.+(a-1.) *
                                          muij(kk)**2))/((2.+a)*(4.+a)))
            elif bc == '31':
                return -((2.*pi * (1.+(-1)**a) *
                          ((1.+a) * k1 * muij(kk) * (3. + a * muij(kk)**2) +
                           k2 * (3. + 6. * a * muij(kk)**2 +
                                 (a-2.) * a * muij(kk)**4))) /
                         ((1.+a) * (3.+a) * (5.+a) * k3))
            elif bc == '32':
                return -((2.*pi * (-1.+(-1)**a) *
                          ((2.+a)*k1**2*muij(kk)*(3.+(1.+a)*muij(kk)**2) +
                           2.*k1*k2*(3.+6.*(1.+a)*muij(kk)**2+(a**2-1.)*
                                     muij(kk)**4) +
                           k2**2*muij(kk)*
                           (15.+(a-1.)*muij(kk)**2*
                            (10.+(a-3.)*muij(kk)**2)))) /
                         ((2.+a)*(4.+a)*(6.+a)*k3**2))
            elif bc == '34':
                return -((2.*pi * (-1.+(-1)**a) *
                          ((2.+a)*(4.+a)*k1**4*muij(kk)*
                           (3.+(3.+a)*muij(kk)**2) +
                           6.*(2.+a)*k1**2*k2**2*muij(kk)*
                           (15.+10.*(1.+a)*muij(kk)**2 + (a**2-1.)*
                            muij(kk)**4) +
                           4.*(2.+a)*k1**3*k2*(3.+(3.+a)*muij(kk)**2*
                                               (6.+(1.+a)*muij(kk)**2)) +
                           k2**4*muij(kk)*(105.+(a-1.)*muij(kk)**2*
                                                 (105.+(a-3.)*muij(kk)**2*
                                                  (21.+(a-5.)*muij(kk)**2))) +
                           4.*k1*k2**3*(15.+(1.+a)*muij(kk)**2*
                                        (45.+(a-1.)*muij(kk)**2*
                                         (15.+(a-3.)*muij(kk)**2))))) /
                         ((2.+a)*(4.+a)*(6.+a)*(8.+a)*k3**4))

            elif bc == '40':
                return ((2.*pi * (1.+(-1)**a) *
                         ((a-2.)*a*muij(kk)**4 + 6*a* muij(kk)**2 + 3))/
                        ((1.+a)*(3.+a)*(5.+a)))
            elif bc == '41':
                return ((2.*pi * (-1.+(-1)**a) *
                         (k1*(3.+6*(1.+a)*muij(kk)**2 + (-1.+a**2)*
                              muij(kk)**4) +
                          k2*muij(kk)*(15.+(-1.+a)*muij(kk)**2*
                                             (10.+(-3.+a)*muij(kk)**2)))) /
                        ((2.+a)*(4.+a)*(6.+a)*k3))
            elif bc == '43':
                return ((2.*pi * (-1.+(-1)**a) *
                         (3.*(2.+a)*k1**2*k2*muij(kk)*
                          (15.+10.*(1.+a)*muij(kk)**2 +
                           (a**2-1.)*muij(kk)**4) + (2.+a)*k1**3*
                          (3.+(3.+a)*muij(kk)**2*
                           (6.+(1.+a)*muij(kk)**2)) + k2**3*muij(kk)*
                          (105.+(a-1.)*muij(kk)**2*
                           (105.+(a-3.)*muij(kk)**2*
                            (21.+(a-5)*muij(kk)**2))) +
                          3.*k1*k2**2*(15.+(1.+a)*muij(kk)**2*
                                       (45.+(a-1.)*muij(kk)**2*
                                        (15.+(a-3.)*muij(kk)**2))))) /
                        ((2.+a)*(4.+a)*(6.+a)*(8.+a)*k3**3))

        P12 = PkL(k1) * PkL(k2)
        P23 = PkL(k2) * PkL(k3)
        P31 = PkL(k3) * PkL(k1)

        kk = [k1, k2, k3]

        x = [(x, y) for x in [0,1,2,3,4,5,6]
             for y in ['00', '01', '02', '03', '04',
                       '10', '11', '12', '13', '14',
                       '20', '21', '22', '23',
                       '30', '31', '32', '34',
                       '40', '41', '43']]

        # Unrequested combinations can be removed as:
        #x.remove((4, '43'))

        # These are ordered as 'bca', so I['123'] is b=1, c=2, a=3
        I = dict((x[1] + str(x[0]), Ia(x[1], a + x[0], kk)) for x in x)

        Bb13    = (K['F_12'] * P12 + K['F_31'] * P31 + K['F_23'] * P23)*I['000']

        Bb12b2  = 0.5 * (P12 + P23 + P31) * I['000']

        Bb12bG2 = (K['S_12'] * P12 + K['S_31'] * P31 + K['S_23'] * P23)*I['000']

        Bfb12   = (((I['002']+I['200']) * K['F_12']+I['020'] * K['G_12'])*P12+
                   ((I['002']+I['020']) * K['F_31']+I['200'] * K['G_31'])*P31+
                   ((I['200']+I['020']) * K['F_23']+I['002'] * K['G_23'])*P23)

        Bfb13   = -0.5 * (((k3/k1)*I['011'] + (k3/k2)*I['110']) * P12 +
                          ((k2/k1)*I['101'] + (k2/k3)*I['110']) * P31 +
                          ((k1/k2)*I['101'] + (k1/k3)*I['011']) * P23)

        # this needs a - sign
        Bf2b12  = -0.5 * (((k3/k1) * (I['013'] + 2. * I['211']) +
                           (k3/k2) * (I['310'] + 2. * I['112'])) * P12 +
                          ((k2/k1) * (I['103'] + 2. * I['121']) +
                           (k2/k3) * (I['130'] + 2. * I['112'])) * P31 +
                          ((k1/k2) * (I['301'] + 2. * I['121']) +
                           (k1/k3) * (I['031'] + 2. * I['211'])) * P23)

        Bfb1b2  = 0.5 * ((I['002'] + I['200']) * P12 +
                         (I['002'] + I['020']) * P31 +
                         (I['200'] + I['020']) * P23)

        Bfb1bG2 = ((I['002'] + I['200']) * K['S_12'] * P12 +
                   (I['002'] + I['020']) * K['S_31'] * P31 +
                   (I['200'] + I['020']) * K['S_23'] * P23)

        Bf2b1   = ((I['202'] * K['F_12']+(I['022']+I['220']) * K['G_12'])*P12+
                   (I['022'] * K['F_31']+(I['202']+I['220']) * K['G_31'])*P31+
                   (I['220'] * K['F_23']+(I['202']+I['022']) * K['G_23'])*P23)

        # This also needs a - sign
        Bf3b1   = -0.5*(((k3/k1) * (I['411'] + 2. * I['213']) +
                         (k3/k2) * (I['114'] + 2. * I['312'])) * P12 +
                        ((k2/k1) * (I['141'] + 2. * I['123']) +
                         (k2/k3) * (I['114'] + 2. * I['132'])) * P31 +
                        ((k1/k2) * (I['141'] + 2. * I['321']) +
                         (k1/k3) * (I['411'] + 2. * I['231'])) * P23)

        Bf2b2   = 0.5 * (I['202'] * P12 + I['022'] * P31 + I['220'] * P23)

        Bf2bG2  = (I['202'] * K['S_12'] * P12 +
                   I['022'] * K['S_31'] * P31 +
                   I['220'] * K['S_23'] * P23)

        Bf3     = (K['G_12']*P12+K['G_31']*P31+K['G_23']*P23)*I['222']

        # this also needs a - sign
        Bf4     = -0.5 * (((k3/k1) * I['413'] + (k3/k2) * I['314']) * P12 +
                          ((k2/k1) * I['143'] + (k2/k3) * I['134']) * P31 +
                          ((k1/k2) * I['341'] + (k1/k3) * I['431']) * P23)

        Bb12a1  = 0.5 * (PkL(k1) + PkL(k2) + PkL(k3)) * I['000']

        Bfb1a1  = (I['002'] * PkL(k1) + I['200'] * PkL(k2) + I['020'] * PkL(k3))

        Bf2a1   = 0.5 * (I['004'] * PkL(k1) +
                         I['400'] * PkL(k2) +
                         I['040'] * PkL(k3))

        return array((Bb13, Bb12b2, Bb12bG2, Bfb12, Bfb13, Bf2b12, Bfb1b2,
                      Bfb1bG2, Bf2b1, Bf3b1, Bf2b2, Bf2bG2, Bf3, Bf4, Bb12a1,
                      Bfb1a1, Bf2a1))

#-------------------------------------------------------------------------------

    def Bl_terms_AP(self, k1, k2, k3, PL, Is, K=None, F=None, G=None, S=None,
                    dF=None, dG=None, dS=None, KK=None, dKK=None):
        """Building blocks for the redshift space bispectrum multipoles including
        AP terms

        Parameters
        ----------
        k1, k2, k3 : array_like
            Sides of Fourier triangles
        PL : array_like
            Linear matter power spectrum
        Is: dict
            Dictionary of kernels evaluated on the triangles
        K, F, G, S, dF, dG, dS, KK, dKK : dict, default: None
            Dictionary with kernels evaluated on the triangles

        Returns
        -------
        array_like
            Array with the building blocks for the tree-level bispectrum
            multipoles

        Notes
        -----
        The output has the following order: `Bb13_0, Bb12b2_0, Bb12bG2_0,
        Bfb12_0, Bfb13_0, Bf2b12_0, Bfb1b2_0, Bfb1bG2_0, Bf2b1_0, Bf3b1_0,
        Bf2b2_0, Bf2bG2_0, Bf3_0, Bf4_0, Bb12a1_0, Bfb1a1_0, Bf2a1_0, Bb13_perp,
        Bb12b2_perp, Bb12bG2_perp, Bfb12_perp, Bfb13_perp, Bf2b12_perp,
        Bfb1b2_perp, Bfb1bG2_perp, Bf2b1_perp, Bf3b1_perp, Bf2b2_perp,
        Bf2bG2_perp, Bf3_perp, Bf4_perp, Bb12a1_perp, Bfb1a1_perp, Bf2a1_perp,
        Bb13_dif, Bb12b2_dif, Bb12bG2_dif, Bfb12_dif, Bfb13_dif, Bf2b12_dif,
        Bfb1b2_dif, Bfb1bG2_dif, Bf2b1_dif, Bf3b1_dif, Bf2b2_dif, Bf2bG2_dif,
        Bf3_dif, Bf4_dif, Bb12a1_dif, Bfb1a1_dif, Bf2a1_dif`

        See Also
        --------
        `Bispfunc_RSD` : building blocks for the bispectrum multipoles
        `Bl_terms` : lower level building blocks without AP terms
        """
        # Array of angle integrals from the corresponding dictionary
        I0, I0mu = Is['I0'], Is['I0mu']
        I2, I2mu, tI2 = Is['I2'], Is['I2mu'], Is['tI2']
        I11, I11mu, tI11 = Is['I11'], Is['I11mu'], Is['tI11']
        I13, I13mu, tI13 = Is['I13'], Is['I13mu'], Is['tI13']
        I112, I112mu, tI112 = Is['I112'], Is['I112mu'], Is['tI112']
        I22, I22mu, tI22 = Is['I22'], Is['I22mu'], Is['tI22']
        I114, I114mu, tI114 = Is['I114'], Is['I114mu'], Is['tI114']
        I123, I123mu, tI123 = Is['I123'], Is['I123mu'], Is['tI123']
        I222, I222mu, tI222 = Is['I222'], Is['I222mu'], Is['tI222']
        I134, I134mu, tI134 = Is['I134'], Is['I134mu'], Is['tI134']
        I4, I4mu, tI4 = Is['I4'], Is['I4mu'], Is['tI4']

        PkL = InterpolatedUnivariateSpline(self.kL, PL, k=3)
        P12 = PkL(k1) * PkL(k2)
        P23 = PkL(k2) * PkL(k3)
        P31 = PkL(k3) * PkL(k1)

        # Derivative of the power spectrum
        P1 = PkL(k1)
        P2 = PkL(k2)
        P3 = PkL(k3)
        dP1_dlnk1 = k1*PkL.derivative()(k1)
        dP2_dlnk2 = k2*PkL.derivative()(k2)
        dP3_dlnk3 = k3*PkL.derivative()(k3)

        P = [P1, P2, P3]
        dP = [dP1_dlnk1, dP2_dlnk2, dP3_dlnk3]
        PP = [P12, P31, P23]
        dPP = [(dP1_dlnk1*P2, P1*dP2_dlnk2, zeros(len(P1))),
               (dP1_dlnk1*P3, zeros(len(P1)), dP3_dlnk3*P1),
               (zeros(len(P1)), dP2_dlnk2*P3, dP3_dlnk3*P2)]
        FP = [K['F_12']*P12, K['F_31']*P31, K['F_23']*P23]
        GP = [K['G_12']*P12, K['G_31']*P31, K['G_23']*P23]
        SP = [K['S_12']*P12, K['S_31']*P31, K['S_23']*P23]

        Bb13_0 = zeros(len(P1))
        Bb13_perp = zeros(len(P1))
        Bb13_dif = zeros(len(P1))

        Bb12b2_0 = zeros(len(P1))
        Bb12b2_perp = zeros(len(P1))
        Bb12b2_dif = zeros(len(P1))

        Bb12bG2_0 = zeros(len(P1))
        Bb12bG2_perp = zeros(len(P1))
        Bb12bG2_dif = zeros(len(P1))

        Bfb12_0 = zeros(len(P1))
        Bfb12_perp = zeros(len(P1))
        Bfb12_dif = zeros(len(P1))
        permfb12 = [(0,1,2), (2,0,1), (1,2,0)]

        Bfb13_0 = zeros(len(P1))
        Bfb13_perp = zeros(len(P1))
        Bfb13_dif = zeros(len(P1))
        permfb13 = [(0, 1), (2, 1), (2,0)]

        Bf2b12_0 = zeros(len(P1))
        Bf2b12_perp = zeros(len(P1))
        Bf2b12_dif = zeros(len(P1))
        permf2b12 = [(0, 2, 5, 0), (2, 1, 3, 0), (4, 1, 1, 2)]

        Bfb1b2_0 = zeros(len(P1))
        Bfb1b2_perp = zeros(len(P1))
        Bfb1b2_dif = zeros(len(P1))
        permfb1b2 = [(0, 1), (0, 2), (2, 1)]

        Bfb1bG2_0 = zeros(len(P1))
        Bfb1bG2_perp = zeros(len(P1))
        Bfb1bG2_dif = zeros(len(P1))
        permfb1bG2 = [(0, 1), (0, 2), (2, 1)]

        Bf2b1_0  = zeros(len(P1))
        Bf2b1_perp = zeros(len(P1))
        Bf2b1_dif = zeros(len(P1))
        permf2b1 = [(0, 1, 2), (1, 0, 2), (2, 0, 1)]

        Bf3b1_0 = zeros(len(P1))
        Bf3b1_perp = zeros(len(P1))
        Bf3b1_dif = zeros(len(P1))
        permf3b1 = [(0, 2, 1, 4), (2, 0, 1, 1), (2, 5, 0, 3)]

        Bf2b2_0 = zeros(len(P1))
        Bf2b2_perp = zeros(len(P1))
        Bf2b2_dif = zeros(len(P1))

        Bf2bG2_0 = zeros(len(P1))
        Bf2bG2_perp = zeros(len(P1))
        Bf2bG2_dif = zeros(len(P1))

        Bf3_0 = zeros(len(P1))
        Bf3_perp = zeros(len(P1))
        Bf3_dif = zeros(len(P1))

        Bf4_0 = zeros(len(P1))
        Bf4_perp = zeros(len(P1))
        Bf4_dif = zeros(len(P1))
        permf4 = [(4, 2), (1, 0), (3, 5)]

        Bb12a1_0 = zeros(len(P1))
        Bb12a1_perp = zeros(len(P1))
        Bb12a1_dif = zeros(len(P1))

        Bfb1a1_0 = zeros(len(P1))
        Bfb1a1_perp = zeros(len(P1))
        Bfb1a1_dif = zeros(len(P1))

        Bf2a1_0 = zeros(len(P1))
        Bf2a1_perp = zeros(len(P1))
        Bf2a1_dif = zeros(len(P1))

        for i in range(3):
            Bb13_0 += FP[i]*I0[0]
            Bb13_perp += (sum(dF[i], axis=0)*PP[i]+\
                          F[i]*sum(dPP[i], axis=0))*I0[0]
            Bb12b2_0 += 0.5*PP[i]*I0[0]
            Bb12b2_perp += 0.5*sum(dPP[i], axis=0)*I0[0]
            Bb12bG2_0 += SP[i]*I0[0]
            Bb12bG2_perp += (sum(dS[i], axis=0)*PP[i]+\
                             S[i]*sum(dPP[i], axis=0))*I0[0]
            Bfb12_0 += (FP[i]*( I2[permfb12[i][0]]+I2[permfb12[i][1]] ) +
                        GP[i]* I2[permfb12[i][2]])
            Bfb12_perp += ((sum(dF[i], axis=0)*PP[i]+F[i]*sum(dPP[i], axis=0))*
                           (I2[permfb12[i][0]]+I2[permfb12[i][1]])+
                           (sum(dG[i], axis=0)*PP[i]+G[i]*sum(dPP[i], axis=0))*
                           I2[permfb12[i][2]])
            Bfb12_dif += (FP[i]*( tI2[permfb12[i][0]]+tI2[permfb12[i][1]]) +
                          GP[i]* tI2[permfb12[i][2]])
            Bfb13_0 += -0.5*((I11[permfb13[i][0]]*KK[int(2*i)]+\
                              I11[permfb13[i][1]]*KK[int(2*i+1)])*PP[i])
            Bfb13_perp += -0.5*((I11[permfb13[i][0]]*\
                                 (sum(dKK[int(2*i)], axis=0)*\
                                  PP[i]+KK[int(2*i)]*sum(dPP[i], axis=0))+\
                                 I11[permfb13[i][1]]*\
                                 (sum(dKK[int(2*i+1)], axis=0)*PP[i]+\
                                  KK[int(2*i+1)]*sum(dPP[i], axis=0))))
            Bfb13_dif += -0.5*((tI11[permfb13[i][0]]*KK[int(2*i)]+\
                                tI11[permfb13[i][1]]*KK[int(2*i+1)])*PP[i])
            Bf2b12_0 += -0.5*(((I13[permf2b12[i][0]]+2.*I112[permf2b12[i][1]])*\
                               KK[int(2*i)]+\
                               (I13[permf2b12[i][2]]+2.*I112[permf2b12[i][3]])*\
                               KK[int(2*i+1)])*PP[i])
            Bf2b12_perp += -0.5*(((I13[permf2b12[i][0]]+\
                                   2.*I112[permf2b12[i][1]])*\
                                  (sum(dKK[int(2*i)], axis=0)*\
                                   PP[i]+KK[int(2*i)]*sum(dPP[i], axis=0))+\
                                  (I13[permf2b12[i][2]]+\
                                   2.*I112[permf2b12[i][3]])*\
                                  (sum(dKK[int(2*i+1)], axis=0)*PP[i]+\
                                   KK[int(2*i+1)]*sum(dPP[i], axis=0))))
            Bf2b12_dif += -0.5*(((tI13[permf2b12[i][0]]+\
                                  2.*tI112[permf2b12[i][1]])*KK[int(2*i)]+\
                                 (tI13[permf2b12[i][2]]+\
                                  2.*tI112[permf2b12[i][3]])*KK[int(2*i+1)])*PP[i])
            Bfb1b2_0 += 0.5*(I2[permfb1b2[i][0]]+I2[permfb1b2[i][1]])*PP[i]
            Bfb1b2_perp += 0.5*((I2[permfb1b2[i][0]]+
                                 I2[permfb1b2[i][1]]))*sum(dPP[i], axis=0)
            Bfb1b2_dif += 0.5*(tI2[permfb1b2[i][0]]+tI2[permfb1b2[i][1]])*PP[i]
            Bfb1bG2_0 += (I2[permfb1bG2[i][0]]+I2[permfb1bG2[i][1]])*SP[i]
            Bfb1bG2_perp += ((I2[permfb1bG2[i][0]]+I2[permfb1bG2[i][1]]))*\
                (sum(dS[i], axis=0)*PP[i]+S[i]*sum(dPP[i], axis=0))
            Bfb1bG2_dif += (tI2[permfb1bG2[i][0]]+tI2[permfb1bG2[i][1]])*SP[i]
            Bf2b1_0 += (I22[permf2b1[i][0]]*FP[i] +
                        (I22[permf2b1[i][1]] + I22[permf2b1[i][2]]) * GP[i])
            Bf2b1_perp += (I22[permf2b1[i][0]]*\
                           (sum(dF[i], axis=0)*PP[i]+F[i]*sum(dPP[i], axis=0))+\
                           (I22[permf2b1[i][1]] + I22[permf2b1[i][2]])*
                           (sum(dG[i], axis=0)*PP[i]+G[i]*sum(dPP[i], axis=0)))
            Bf2b1_dif += (tI22[permf2b1[i][0]]*FP[i] +
                          (tI22[permf2b1[i][1]] + tI22[permf2b1[i][2]]) * GP[i])
            Bf3b1_0 += -0.5*((I114[permf3b1[i][0]]+\
                              2.*I123[permf3b1[i][1]])*KK[int(2*i)]+
                             (I114[permf3b1[i][2]]+2.*I123[permf3b1[i][3]])*\
                             KK[int(2*i)+1])*PP[i]
            Bf3b1_perp += -0.5*((I114[permf3b1[i][0]]+2.*I123[permf3b1[i][1]])*\
                                (sum(dKK[int(2*i)], axis=0)*PP[i] +
                                 KK[int(2*i)]*sum(dPP[i], axis=0)) +
                                (I114[permf3b1[i][2]]+2.*I123[permf3b1[i][3]])*\
                                (sum(dKK[int(2*i+1)], axis=0)*PP[i] +
                                 KK[int(2*i+1)]*sum(dPP[i], axis=0)))
            Bf3b1_dif += -0.5*((tI114[permf3b1[i][0]]+\
                                2.*tI123[permf3b1[i][1]])*KK[int(2*i)]+\
                               (tI114[permf3b1[i][2]]+\
                                2.*tI123[permf3b1[i][3]])*KK[int(2*i)+1])*PP[i]
            Bf2b2_0 += 0.5 * I22[i] * PP[i]
            Bf2b2_perp += 0.5 * I22[i] * sum(dPP[i], axis=0)
            Bf2b2_dif += 0.5 * tI22[i] * PP[i]
            Bf2bG2_0 += I22[i] * SP[i]
            Bf2bG2_perp += I22[i]*(sum(dS[i], axis=0)*PP[i]+\
                                   S[i]*sum(dPP[i], axis=0))
            Bf2bG2_dif += tI22[i] * SP[i]
            Bf3_0 += GP[i]*I222[0]
            Bf3_perp += (sum(dG[i], axis=0)*PP[i]+\
                         G[i]*sum(dPP[i], axis=0))*I222[0]
            Bf3_dif += GP[i]*tI222[0]
            Bf4_0 += -0.5*(I134[permf4[i][0]]*KK[int(2*i)] +\
                           I134[permf4[i][1]]*KK[int(2*i+1)]) * PP[i]
            Bf4_perp += -0.5*(I134[permf4[i][0]]*\
                              (sum(dKK[int(2*i)], axis=0)*PP[i]+\
                               KK[int(2*i)]*sum(dPP[i], axis=0))+
                              I134[permf4[i][1]]*\
                              (sum(dKK[int(2*i+1)], axis=0)*PP[i]+\
                               KK[int(2*i+1)]*sum(dPP[i], axis=0)))
            Bf4_dif += -0.5*(tI134[permf4[i][0]]*KK[int(2*i)]+
                             tI134[permf4[i][1]]*KK[int(2*i+1)])*PP[i]
            Bb12a1_0 += 0.5 * P[i]*I0[0]
            Bb12a1_perp += 0.5 * dP[i]*I0[0]
            Bb12a1_dif += 0.5 * I0mu[i] * dP[i]
            Bfb1a1_0 += I2[i] * P[i]
            Bfb1a1_perp += I2[i] * dP[i]
            Bfb1a1_dif += (I2mu[i][i] * dP[i] + tI2[i] * P[i])
            Bf2a1_0 += 0.5 * I4[i] * P[i]
            Bf2a1_perp += 0.5 * I4[i] * dP[i]
            Bf2a1_dif += 0.5 * (I4mu[i][i] * dP[i] + tI4[i] * P[i])

            for j in range(3):
                Bb13_dif += (dF[i][j]*PP[i]+F[i]*dPP[i][j])*I0mu[j]
                Bb12b2_dif += 0.5*dPP[i][j]*I0mu[j]
                Bb12bG2_dif += (dS[i][j]*PP[i]+S[i]*dPP[i][j])*I0mu[j]
                Bfb12_dif += ((dF[i][j]*PP[i]+F[i]*dPP[i][j])*\
                              (I2mu[permfb12[i][0]][j]+I2mu[permfb12[i][1]][j])+\
                              (dG[i][j]*PP[i]+G[i]*dPP[i][j])*\
                              I2mu[permfb12[i][2]][j])
                Bfb13_dif += -0.5*((I11mu[permfb13[i][0]][j]*\
                                    (dKK[int(2*i)][j]*PP[i]+KK[int(2*i)]*\
                                     dPP[i][j])+\
                                    I11mu[permfb13[i][1]][j]*\
                                    (dKK[int(2*i+1)][j]*PP[i]+\
                                     KK[int(2*i+1)]*dPP[i][j])))
                Bf2b12_dif += -0.5*(((I13mu[permf2b12[i][0]][j]+\
                                      2.*I112mu[permf2b12[i][1]][j])*\
                                     (dKK[int(2*i)][j]*PP[i]+KK[int(2*i)]*dPP[i][j])+\
                                     (I13mu[permf2b12[i][2]][j]+\
                                      2.*I112mu[permf2b12[i][3]][j])*\
                                     (dKK[int(2*i+1)][j]*PP[i]+\
                                      KK[int(2*i+1)]*dPP[i][j])))
                Bfb1b2_dif += 0.5*((I2mu[permfb1b2[i][0]][i]+
                                    I2mu[permfb1b2[i][1]][j]))*dPP[i][j]
                Bfb1bG2_dif += ((I2mu[permfb1bG2[i][0]][j]+
                                 I2mu[permfb1bG2[i][1]][j]))*\
                                 (dS[i][j]*PP[i]+S[i]*dPP[i][j])
                Bf2b1_dif += (I22mu[permf2b1[i][0]][j]*\
                              (dF[i][j]*PP[i]+F[i]*dPP[i][j])+\
                              (I22mu[permf2b1[i][1]][j]+I22mu[permf2b1[i][2]][j])*\
                              (dG[i][j]*PP[i]+G[i]*dPP[i][j]))
                Bf3b1_dif += -0.5*((I114mu[permf3b1[i][0]][j]+\
                                    2.*I123mu[permf3b1[i][1]][j])*\
                                   (dKK[int(2*i)][j]*PP[i] +\
                                    KK[int(2*i)]*dPP[i][j]) +\
                                   (I114mu[permf3b1[i][2]][j]+\
                                    2.*I123mu[permf3b1[i][3]][j])*\
                                   (dKK[int(2*i+1)][j]*PP[i]+\
                                    KK[int(2*i+1)]*dPP[i][j]))
                Bf2b2_dif += 0.5 * I22mu[i][j] * dPP[i][j]
                Bf2bG2_dif += I22mu[i][j]*(dS[i][j]*PP[i]+\
                                           S[i]*dPP[i][j])
                Bf3_dif += I222mu[j] * (dG[i][j]*PP[i]+G[i]*dPP[i][j])
                Bf4_dif += -0.5*(I134mu[permf4[i][0]][j]*
                                 (dKK[int(2*i)][j]*PP[i]+KK[int(2*i)]*dPP[i][j])+\
                                 I134mu[permf4[i][1]][j]*
                                 (dKK[int(2*i+1)][j]*PP[i]+KK[int(2*i+1)]*dPP[i][j]))

        return array((Bb13_0, Bb12b2_0, Bb12bG2_0, Bfb12_0, Bfb13_0, Bf2b12_0,
                      Bfb1b2_0, Bfb1bG2_0, Bf2b1_0, Bf3b1_0, Bf2b2_0, Bf2bG2_0,
                      Bf3_0, Bf4_0, Bb12a1_0, Bfb1a1_0, Bf2a1_0, Bb13_perp,
                      Bb12b2_perp, Bb12bG2_perp, Bfb12_perp, Bfb13_perp,
                      Bf2b12_perp, Bfb1b2_perp, Bfb1bG2_perp, Bf2b1_perp,
                      Bf3b1_perp, Bf2b2_perp, Bf2bG2_perp, Bf3_perp, Bf4_perp,
                      Bb12a1_perp, Bfb1a1_perp, Bf2a1_perp, Bb13_dif, Bb12b2_dif,
                      Bb12bG2_dif, Bfb12_dif, Bfb13_dif, Bf2b12_dif, Bfb1b2_dif,
                      Bfb1bG2_dif, Bf2b1_dif, Bf3b1_dif, Bf2b2_dif, Bf2bG2_dif,
                      Bf3_dif, Bf4_dif, Bb12a1_dif, Bfb1a1_dif, Bf2a1_dif))

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
