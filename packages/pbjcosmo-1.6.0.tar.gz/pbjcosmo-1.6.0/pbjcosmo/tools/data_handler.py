"""`data_handler.py` module

Handles loading of data

"""
import numpy as np
import pandas as pd
import pickle
from . import cosmology

def load_covariance(filename, observables, twopi3, n_bins_power, n_triangles, meansets,
                    covtype='covariance'):
    r"""Loads the covariance matrix

    Parameters
    ----------
    filename : str or list of str
        filename(s) of the covariance matrix
    observables : list of str
        list of observables to be loaded
    twopi3 : float
        constant to scale the data ($2\pi^3$)
    n_bins_power : int
        number of bins to consider for power spectrum observables
    n_triangles : int
        number of triangles to consider for bispectrum observables
    meansets : int
        number of independent sets
    covtype : str, default: 'covariance'
        type of covariance matrix: 'covariance', 'variance'

    Returns
    -------
    covariance : array_like or list of array_like
        the covariance matrix/matrices

    Notes
    -----
    See the documentation for info on the structure of the covariance files.
    """
    if filename is None or isinstance(filename, dict):
        raise NotImplementedError("Missing covariance file, automatic analytic cov not implemented")

    is_nested_obs = any(isinstance(i, list) for i in observables)

    if isinstance(filename, list):
        covariance_list = []
        for i, fname in enumerate(filename):
            cov_matrix = pd.read_csv(fname, sep=r"\s+", header=None).values

            if cov_matrix.ndim == 1 or (cov_matrix.ndim == 2 and (cov_matrix.shape[0] == 1 or cov_matrix.shape[1] == 1)):
                cov_matrix = np.diag(cov_matrix.flatten())
            elif cov_matrix.ndim == 2 and covtype == 'variance':
                cov_matrix = np.diag(np.diag(cov_matrix))

            current_obs = observables[i] if is_nested_obs else observables

            factor = []
            for o in current_obs:
                if o.startswith(('P', 'BAO')):
                    factor.extend([twopi3**1] * n_bins_power)
                elif o.startswith('B'):
                    factor.extend([twopi3**2] * n_triangles)
                else:
                    factor.append(1.)

            factor2 = np.outer(factor, factor)
            cov_matrix *= factor2 / meansets

            covariance_list.append(cov_matrix)

        return covariance_list

    else:
        covariance = pd.read_csv(filename, sep=r"\s+", header=None).values

        if covariance.ndim == 1 or (covariance.ndim == 2 and (covariance.shape[0] == 1 or covariance.shape[1] == 1)):
            covariance = np.diag(covariance.flatten())
        elif covariance.ndim == 2 and covtype == 'variance':
            covariance = np.diag(np.diag(covariance))

        flat_observables = observables
        if is_nested_obs:
            flat_observables = sorted(list(set(item for sublist in observables for item in sublist)))

        factor = []
        for o in flat_observables:
            if o.startswith(('P', 'BAO')):
                factor.extend([twopi3**1] * n_bins_power)
            elif o.startswith('B'):
                factor.extend([twopi3**2] * n_triangles)
            else:
                factor.append(1.)
        factor2 = np.outer(factor, factor)
        covariance *= factor2 / meansets

        return covariance

def load_data(datafiles, observables, twopi3, n_bins_power, nsets=None, meanbool=None):
    r"""Loads data files

    Loads datavectors from files and returns data dictionaries for each observable.

    Parameters
    ----------
    datafiles : dict
        dictionary with observables as keys and datafiles as values
    observables : list
        observables to be loaded
    twopi3 : float
        constant to scale the data ($2\pi^3$)
    n_bins_power : int
        number of bins to consider for power spectrum observables
    nsets : int, default: None
        number of independent sets
    meanbool : bool, default: None
        whether to compute the mean of the data

    Returns
    -------
    meansets : int
        number of independent sets
    nsets : int
        number of sets
    data_dict : dict
        dict with observables as keys and datavectors as values

    Notes
    -----
    See the documentation for info on the structure of the data files.
    """
    data_dict = {}
    meansets = 1

    is_nested = any(isinstance(i, list) for i in observables)

    # Get a flat, unique list of all observables to be loaded.
    flat_observables = sorted(list(set(item for sublist in observables for item in sublist))) if is_nested else observables

    for o in flat_observables:
        if o.startswith('alpha'):
            # This is a BAO observable. The logic needs to handle the nested case carefully.
            if o not in data_dict: # Ensure we process the whole BAO block only once
                bao_files = datafiles.get('alphas_bao')
                if bao_files is None:
                    continue

                bao_files_list = bao_files if isinstance(bao_files, list) else [bao_files]
                num_z_bins = len(bao_files_list)
                bao_npz_files = [np.load(f) for f in bao_files_list]

                # Pre-initialize all potential BAO observables for this run
                all_bao_in_run = [obs for obs in flat_observables if obs.startswith('alpha')]
                for bao_obs in all_bao_in_run:
                    data_dict[bao_obs] = np.full((num_z_bins, 1), np.nan)

                # Iterate through each z-bin (each file) and fill the data
                for i in range(num_z_bins):
                    for bao_obs in all_bao_in_run:
                        # NpzFile acts like a dict, get() is safe.
                        val = bao_npz_files[i].get(bao_obs)
                        if val is not None:
                            data_dict[bao_obs][i] = np.squeeze(val)
        else:
            # This is a non-BAO observable.
            files = datafiles[o]
            datum = np.array(
                [pd.read_csv(f, sep=r"\s+", header=None).values
                 for f in (files if isinstance(files, list) else [files])])

            if o.startswith('P'):
                datum = datum[..., :n_bins_power]

            if meanbool is not None and isinstance(files, str):
                meansets = datum.shape[0]
                datum = datum.mean(axis=0)

            datum = np.squeeze(datum)
            if datum.ndim == 1:
                datum = datum[np.newaxis, :]

            nsets = nsets or (datum.shape[0] if datum.ndim == 2 else datum.shape[1])

            factor = twopi3 if o.startswith(('P', 'BAO')) else twopi3**2
            data_dict[o] = datum * factor

    return meansets, nsets, data_dict


def load_window(filename):
    """Loads mixing matrix

    Loads the mixing matrix and returns dictionaries for each redshift bin.

    Parameters
    ----------
    filename : str or list of str
        filename(s) of the mixing matrix

    Returns
    -------
    `w_dict` : dict
        mixing matrix dictionary

    Notes
    -----
    The mixing matrix must be saved in a `pickle` file with a specific
    structure. See the documentation for more info.
    """

    if filename is None or isinstance(filename, dict):
        raise NotImplementedError("Missing mixing matrix file")

    if isinstance(filename, list):
        w_dict = {}
        for iz, iname in enumerate(filename):
            with open(iname, "rb") as infile:
                w_tmp = pickle.load(infile)
                # Convert list into arrays if needed
                for attr in w_tmp:
                    if isinstance(w_tmp[attr], list):
                    # if type(w_dict[attr]) == list:
                        w_tmp[attr] = np.array(w_tmp[attr])
                    elif isinstance(w_tmp[attr], dict):
                        for l in w_tmp[attr]:
                            if isinstance(w_tmp[attr][l], list):
                                w_tmp[attr][l] = np.array(w_tmp[attr][l])
            w_dict.update({"z_"+ "%01d" % (iz): {"wc": w_tmp["wc"].copy(),
                                                 "k1": np.copy(w_tmp["k1"])}})
        w_dict.update({"dtype": w_tmp["dtype"],
                       #"k1": np.copy(w_tmp["k1"]),
                       "k2": w_tmp["k2"].copy()})
        del w_tmp

    else:
        with open(filename, "rb") as infile:
            w_dict = pickle.load(infile)
            for attr in w_dict:
                if isinstance(w_dict[attr], list):
                    w_dict[attr] = np.array(w_dict[attr])
                elif isinstance(w_dict[attr], dict):
                    for l in w_dict[attr]:
                        if isinstance(w_dict[attr][l], list):
                            w_dict[attr][l] = np.array(w_dict[attr][l])

    return w_dict


def load_additional_bao(input_bao_dict):
    r"""Loads additional BAO

    Parameters
    ----------
    input_bao_dict : dict
        dictionary with additional BAO measurements

    Returns
    -------
    output_dict : dict
        dictionary with additional BAO measurements

    Notes
    -----
    See the documentation to details on how to ask the code to include
    additional BAO measurements in the analysis. The input dictionary must
    contain `redshift`, `fiducial_cosmology`, `data_files` and `covariance`

    The output dictionary contains the loaded datavectors, inverse covariance,
    redshift, fiducial Hubble, angular diameter distance and sound horizon at
    baryon drag, and list of observables ($\alpha_{\parallel}$, $\alpha_\perp$,
    $\alpha_{\rm ISO}$ and/or $\alpha_{\rm AP}$).
    """
    output_dict = {}

    for i, z in enumerate(input_bao_dict['redshift']):
        with np.load(input_bao_dict['data_files'][i]) as data:
            data_dict = {obs: data[obs].item() for obs in data.files}

        covariance = np.loadtxt(input_bao_dict['covariance'][i])
        inv_covariance = np.linalg.inv(np.atleast_2d(covariance))

        # Compute fiducial values
        Om = input_bao_dict['fiducial_cosmology'][i]['Om']
        h  = input_bao_dict['fiducial_cosmology'][i]['h']
        Ob = input_bao_dict['fiducial_cosmology'][i].get('Ob', 0.049) #!!! to be fixed
        w0 = input_bao_dict['fiducial_cosmology'][i].get('w0', -1.)
        wa = input_bao_dict['fiducial_cosmology'][i].get('wa',  0.)
        Mnu = input_bao_dict['fiducial_cosmology'][i].get('Mnu',  0.)

        hubble_adim_fid = cosmology.Hubble_adim(z, Om, w0, wa)
        angular_diam_distance_fid = cosmology.angular_diam_distance(z, Om, w0, wa)
        rd_fid = cosmology.sound_horizon_drag(Om*h**2, Ob*h**2, h, Mnu=Mnu)

        # Construct dictionary entry
        output_dict[i] = {
            'data': np.array(list(data_dict.values())),
            'observables': list(data_dict.keys()),
            'inv_cov': inv_covariance,
            'redshift': z,
            'fiducials': {'angular_diam_distance_fid': angular_diam_distance_fid,
                          'Hubble_adim_fid': hubble_adim_fid,
                          'rd_fid': rd_fid}
        }

    return output_dict


def load_optional_array(input_dict, key, unpack=False, default=None):
    """
    Safely load array from file path in dictionary.

    Parameters
    ----------
    input_dict : dict
        Dictionary containing file paths
    key : str
        Key to look up in input_dict
    unpack : bool
        If True, return unpacked tuple. If False, return single array
    default : array or None
        Default value to return if key not found

    Returns
    -------
    Loaded array or default value
    """
    if key not in input_dict:
        if unpack:
            return default if default is not None else (None, None, None)
        return default

    try:
        result = np.loadtxt(input_dict[key], unpack=unpack)
        return result
    except (FileNotFoundError, OSError, ValueError) as e:
        print(f"Warning: Could not load file '{input_dict[key]}' for key '{key}': {e}")
        if unpack:
            return default if default is not None else (None, None, None)
        return default
