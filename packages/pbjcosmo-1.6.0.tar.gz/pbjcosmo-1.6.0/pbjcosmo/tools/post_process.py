import numpy as np
import getdist
from .prior_handler import get_prior_distribution
import pbjcosmo.tools.param_handler as parhandler
from . import cosmology

def create_MCSample(chain_name, label, labels=None, ranges=None):
    """Loads chains for post-processing

    Produces getdist-compatible MCSamples

    Parameters
    ----------
    chain_name : str
        Name of the npz file containing posterior samples
    label : str
        Label used in the contourplot legend
    ranges : dict
        Contains the extrema for flat priors, defaults to None

    Returns
    -------
    sample : getdist.MCSamples object
        MCSamples object to be used for plotting with getdist
    """
    chain=np.load(chain_name)
    samples=chain['samples']
    weights=np.exp(chain['log_weights']) if 'log_weights' in chain.keys() else None
    loglike = chain['log_like']
    if labels is None:
        labels = chain['param_labels']
    sample=getdist.MCSamples(samples = samples,
                             loglikes = loglike,
                             ranges = ranges,
                             names = chain['param_names'],
                             weights = weights,
                             labels = labels,
                             label = label)
    return sample

def get_loglike(chain_name):
    """Returns the loglike from the npz chain

    Parameters
    ----------
    chain_name : str
        Name of the npz file containing posterior samples

    Returns
    -------
    loglike : array
        Array containing the loglike values
    """
    chain = np.load(chain_name)
    loglike = chain['log_like']

    return loglike

def get_logprior(chain_name, pbjobject):
    """Compute logprior from samples in the npz chain

    Parameters
    ----------
    chain_name : str
        Name of the npz file containing posterior samples
    pbjobject : Pbj object
        Fully initialised Pbj object

    Returns
    -------
    logprior : array
        Array with len = N samples containing the log_prior vals
    """
    unpacked_dict = _unpack_sample_params(chain_name, pbjobject)
    keys = list(unpacked_dict.keys())
    tmp_matrix = np.zeros((len(unpacked_dict[keys[0]]['samples']),
                           len(keys)))

    for i,name in enumerate(keys):
        distr = unpacked_dict[name]['distr']
        x = unpacked_dict[name]['samples']
        tmp_matrix[:,i] = [distr(ix) for ix in x]

    tmp_matrix[(tmp_matrix <= 0) | np.isnan(tmp_matrix)] = -np.inf

    logprior = np.sum(np.log(tmp_matrix), axis=1)
    return logprior

def _unpack_sample_params(chain_name, pbjobject):
    """Constructs a dictionary with unpacked parameters (for multiple
    redshift bins) and samples

    Parameters
    ----------
    chain_name : str
        Name of the npz file containing posterior samples
    pbjobject : Pbj object
        Fully initialised Pbj object

    Returns
    -------
    unpacked_dict : dict
        Unpacked dictionary

    """
    chain = np.load(chain_name)
    unpacked_dict = {}

    for par in pbjobject.varied_params:
        par_dict = pbjobject.prior_dictionary[par]
        if type(par_dict['init_value']) is list and len(par_dict['init_value']) > 1:
            for i in range(len(par_dict['init_value'])):
                unpacked_dict[f"{par}_z{i+1}"] = {
                    'init_value': par_dict['init_value'][i],
                    'prior' : par_dict['prior'],
                    'prior_params': {key: par_dict['prior_params'][key][i]
                                     for key in par_dict['prior_params'].keys()}
                                            }
        else:
            unpacked_dict[f"{par}"] = pbjobject.prior_dictionary[par]

    for j, par in enumerate(unpacked_dict.keys()):
        unpacked_dict[par]['distr'] = get_prior_distribution(unpacked_dict[par])
        unpacked_dict[par]['samples'] = chain['samples'][:,j]

    return unpacked_dict

def _compute_F1i(p_marg, invcov, delta_theorydata, prior_term_F1i):
    F1i = -np.einsum('ri, ij, kj -> r', p_marg, invcov, delta_theorydata) +\
        prior_term_F1i
    return F1i


def _compute_F2ij(p_marg, invcov, prior_invcov):
    F2ij = np.einsum('ri, ij, mj -> rm', p_marg, invcov, p_marg) +\
        prior_invcov
    return F2ij

def compute_bestfit_marg_params_singlez(pbjobject, bestfit_nonmarg):
    """Computes bestfit values and errorbars for the analytically
    marginalised parameters

    Parameters
    ----------
    pbjobject : Pbj object
        A Pbj object fully initialised and with `cut_data_vectors` called
    bestfit_nonmarg : dict
        Dictionary containing bestfit values for the non-marginalised parameters

    Returns
    -------
    bestfit_dict : dict
        Dict with bestfit values and sigma for the analytically marg params
    """
    pbjobject.full_param_dict.update(bestfit_nonmarg)
    pbjobject.compute_derived_parameters(
        pbjobject.prior_dictionary,
        pbjobject.full_param_dict,
        init=False
    )
    cosmology.update_omega_matter(pbjobject.full_param_dict)

    _, PL = pbjobject.theory_inst.linear_power_spectrum(
        pbjobject.full_param_dict, pbjobject.kL, linear=pbjobject.linear,
        redshift=0)

    if pbjobject.do_AP or hasattr(pbjobject, 'do_alphas_bao'):
        alpha_par =  pbjobject.Hubble_adim_fid / \
            cosmology.Hubble_adim(pbjobject.z, pbjobject.full_param_dict['Om'],
                                  pbjobject.full_param_dict['w0'],
                                  pbjobject.full_param_dict['wa'])
        alpha_perp = cosmology.angular_diam_distance(
            pbjobject.z, pbjobject.full_param_dict['Om'],
            pbjobject.full_param_dict['w0'],
            pbjobject.full_param_dict['wa'])/pbjobject.angular_diam_distance_fid
        pbjobject.full_param_dict['alpha_par']  = alpha_par
        pbjobject.full_param_dict['alpha_perp'] = alpha_perp

        rd_ratio = pbjobject.rd_fid/cosmology.sound_horizon_drag(
            pbjobject.full_param_dict['Omh2'],pbjobject.full_param_dict['Obh2'],
            pbjobject.full_param_dict['h'],Mnu=pbjobject.full_param_dict['Mnu'])

    if hasattr(pbjobject, 'do_pell' or 'do_bell'):
        f, D = pbjobject.theory_inst._get_growth_functions(
            pbjobject.z, pbjobject.full_param_dict,
            growth_model=pbjobject.growth_model)
        pbjobject.full_param_dict['f'] = f
        pbjobject.full_param_dict['D'] = D

    theory_dict = {}
    marg_dict   = {}

    if hasattr(pbjobject, 'do_pell'):
        pbjobject.theory_inst._Pgg_kmu_terms(
            PL,pbjobject.full_param_dict,redshift=0,kind=pbjobject.IRresum_kind,
            do_AP=pbjobject.do_AP,window_convolution=pbjobject.window_convolution)

        if pbjobject.window_convolution is not None:
            Pell,Pell_marg = pbjobject.theory_inst.convolve_power_spectrum(
                pbjobject.theory_inst.P_kmu_z, pbjobject.window,
                pbjobject.z, pbjobject.do_redshift_rescaling, pbjobject.kpW,
                kgrid=pbjobject.kL[pbjobject.kL <= pbjobject.kpmaxConv+1e-2],
                IRres=pbjobject.IRres, do_analytic_marg=True,
                do_AP=pbjobject.do_AP, AP_as_nuisance=True,
                cosmo=pbjobject.full_param_dict,
                cosmo_fid=pbjobject.FiducialCosmo, Psn=pbjobject.Psn,
                **pbjobject.full_param_dict)
        else:
            if pbjobject.kval_ext is not None:
                kgrid = pbjobject.kval_ext
            else:
                kgrid = pbjobject.kPE
            Pell, Pell_marg = pbjobject.theory_inst.P_kmu_z(
                pbjobject.z, pbjobject.do_redshift_rescaling, kgrid=kgrid,
                do_AP=pbjobject.do_AP, AP_as_nuisance=True,
                do_analytic_marg=True, cosmo=pbjobject.full_param_dict,
                cosmo_fid=pbjobject.FiducialCosmo, Psn=pbjobject.Psn,
                **pbjobject.full_param_dict)

        theory_dict.update(
            {f'P{i*2}': Pell[i][index] for i,index in
             zip(range(3),(pbjobject.IdxP, pbjobject.IdxP2, pbjobject.IdxP4))})

        marg_dict['P0'] = np.asarray([Pell_marg[0+3*j,pbjobject.IdxP]
                                      for j in pbjobject.index_marg_param])
        marg_dict['P2'] = np.asarray([Pell_marg[1+3*j,pbjobject.IdxP2]
                                      for j in pbjobject.index_marg_param])
        marg_dict['P4'] = np.asarray([Pell_marg[2+3*j,pbjobject.IdxP4]
                                      for j in pbjobject.index_marg_param])

    if hasattr(pbjobject, 'do_alphas_bao'):
        theory_dict['alpha_par'] = \
            np.atleast_1d(pbjobject.full_param_dict['alpha_par']*rd_ratio)
        theory_dict['alpha_perp'] = \
            np.atleast_1d(pbjobject.full_param_dict['alpha_perp']*rd_ratio)
        theory_dict['alpha_iso'] = np.atleast_1d((
            pbjobject.full_param_dict['alpha_par']*
            pbjobject.full_param_dict['alpha_perp']**2)**1/3)
        theory_dict['alpha_AP'] = np.atleast_1d(
            pbjobject.full_param_dict['alpha_par']/
            pbjobject.full_param_dict['alpha_perp'])
        marg_dict['alpha_par']  = np.zeros((len(pbjobject.index_marg_param),1))
        marg_dict['alpha_perp'] = np.zeros((len(pbjobject.index_marg_param),1))
        marg_dict['alpha_iso']  = np.zeros((len(pbjobject.index_marg_param),1))
        marg_dict['alpha_AP']   = np.zeros((len(pbjobject.index_marg_param),1))

    TheoryVec = np.concatenate([theory_dict[obs] for obs in pbjobject.Obs])
    MargVec   = np.hstack([marg_dict[obs] for obs in pbjobject.Obs])

    deltaTD = TheoryVec - np.concatenate(pbjobject.CutDataVecs, axis=1)

    F1i = _compute_F1i(MargVec, pbjobject.invCov, deltaTD,
                           pbjobject.prior_term_F1i)
    invF2ij = np.linalg.inv(_compute_F2ij(MargVec, pbjobject.invCov,
                                              pbjobject.prior_cov_inv))
    bestfits = np.einsum('i, ij -> j', F1i, invF2ij)
    sigmas = np.sqrt(np.linalg.diagonal(invF2ij))

    bestfit_dict = {par: {'bestfit': bestfits, 'sigma': sigmas}
                    for par in pbjobject.marg_params}

    return bestfit_dict

def compute_bestfit_marg_params_multiz(pbjobject, bestfit_nonmarg):
    """Computes bestfit values and errorbars for the analytically
    marginalised parameters

    Parameters
    ----------
    pbjobject : Pbj object
        A Pbj object fully initialised and with `cut_data_vectors` called
    bestfit_nonmarg : dict
        Dictionary containing bestfit values for the non-marginalised parameters

    Returns
    -------
    bestfit_dict : dict
        Dict with bestfit values and sigma for the analytically marg params
    """
    pbjobject.full_param_dict.update(bestfit_nonmarg)
    pbjobject.compute_derived_parameters(
        pbjobject.prior_dictionary,
        pbjobject.full_param_dict,
        init=False
    )
    cosmology.update_omega_matter(pbjobject.full_param_dict)

    _, PL = pbjobject.theory_inst.linear_power_spectrum(
        pbjobject.full_param_dict, pbjobject.kL, linear=pbjobject.linear,
        redshift=0)

    if pbjobject.do_AP or hasattr(pbjobject, 'do_alphas_bao'):
        alpha_par =  pbjobject.Hubble_adim_fid / \
            cosmology.Hubble_adim(
                pbjobject.z_bins, pbjobject.full_param_dict['Om'],
                pbjobject.full_param_dict['w0'],pbjobject.full_param_dict['wa'])
        alpha_perp = np.asarray(
            [cosmology.angular_diam_distance(
                iz, pbjobject.full_param_dict['Om'],
                pbjobject.full_param_dict['w0'],pbjobject.full_param_dict['wa'])
             for iz in pbjobject.z_bins]) / pbjobject.angular_diam_distance_fid
        pbjobject.full_param_dict['alpha_par']  = list(alpha_par)
        pbjobject.full_param_dict['alpha_perp'] = list(alpha_perp)

        rd_ratio = pbjobject.rd_fid/cosmology.sound_horizon_drag(
            pbjobject.full_param_dict['Omh2'],pbjobject.full_param_dict['Obh2'],
            pbjobject.full_param_dict['h'],Mnu=pbjobject.full_param_dict['Mnu'])

    if hasattr(pbjobject, 'do_pell' or 'do_bell'):
        f, D = pbjobject.theory_inst._get_growth_functions(
            pbjobject.z_bins, pbjobject.full_param_dict,
            growth_model=pbjobject.growth_model)
        pbjobject.full_param_dict['f'] = list(f)
        pbjobject.full_param_dict['D'] = list(D)

    if hasattr(pbjobject, 'do_pell'):
        pbjobject.theory_inst._Pgg_kmu_terms(
            PL,pbjobject.full_param_dict,redshift=0,kind=pbjobject.IRresum_kind,
            do_AP=pbjobject.do_AP,window_convolution=pbjobject.window_convolution)

    theory_dict = {k: {} for k,i in enumerate(pbjobject.z_bins)}
    marg_dict   = {k: {} for k,i in enumerate(pbjobject.z_bins)}
    bestfits=np.full((len(pbjobject.marg_params),len(pbjobject.z_bins)), np.nan)
    sigmas  =np.full((len(pbjobject.marg_params),len(pbjobject.z_bins)), np.nan)

    for ii, iz in enumerate(pbjobject.z_bins):
        zparams = {k: v[ii] if isinstance(v, list)
                   else v for k, v in pbjobject.full_param_dict.items()}

        if pbjobject.window_convolution is not None:
            Pell,Pell_marg = pbjobject.theory_inst.convolve_power_spectrum(
                pbjobject.theory_inst.P_kmu_z,
                pbjobject.window["z_"+ "%01d" % (ii)], iz, True, pbjobject.kpW,
                kgrid=pbjobject.kL[pbjobject.kL <= pbjobject.kpmaxConv+1e-2],
                IRres=pbjobject.IRres, do_analytic_marg=True,
                do_AP=pbjobject.do_AP, AP_as_nuisance=True,
                cosmo=pbjobject.full_param_dict, cosmo_fid=pbjobject.FiducialCosmo,
                Psn=pbjobject.Psn[ii], **zparams)
        else:
            if pbjobject.kval_ext is not None:
                kgrid = pbjobject.kval_ext
            else:
                kgrid = pbjobject.kPE
            Pell, Pell_marg = pbjobject.theory_inst.P_kmu_z(
                iz, True, kgrid=kgrid, do_AP=pbjobject.do_AP,
                IRres=pbjobject.IRres, AP_as_nuisance=True,
                do_analytic_marg=True, cosmo=pbjobject.full_param_dict,
                cosmo_fid=pbjobject.FiducialCosmo, Psn=pbjobject.Psn[ii],
                **zparams)

        theory_dict[ii]['P0'] = Pell[0][pbjobject.IdxP[ii]]
        theory_dict[ii]['P2'] = Pell[1][pbjobject.IdxP2[ii]]
        theory_dict[ii]['P4'] = Pell[2][pbjobject.IdxP4[ii]]

        marg_dict[ii]['P0'] = np.asarray([Pell_marg[0+3*j,pbjobject.IdxP[ii]]
                                          for j in pbjobject.index_marg_param])
        marg_dict[ii]['P2'] = np.asarray([Pell_marg[1+3*j,pbjobject.IdxP2[ii]]
                                          for j in pbjobject.index_marg_param])
        marg_dict[ii]['P4'] = np.asarray([Pell_marg[2+3*j,pbjobject.IdxP4[ii]]
                                          for j in pbjobject.index_marg_param])

        if hasattr(pbjobject, 'do_alphas_bao'):
            theory_dict[ii]['alpha_par'] = \
                np.atleast_1d(pbjobject.full_param_dict['alpha_par'][ii]*rd_ratio)
            theory_dict[ii]['alpha_perp'] = \
                np.atleast_1d(pbjobject.full_param_dict['alpha_perp'][ii]*rd_ratio)
            theory_dict[ii]['alpha_iso'] = np.atleast_1d((
                pbjobject.full_param_dict['alpha_par'][ii]*
                pbjobject.full_param_dict['alpha_perp'][ii]**2)**1/3)
            theory_dict[ii]['alpha_AP'] = np.atleast_1d(
                pbjobject.full_param_dict['alpha_par'][ii]/
                pbjobject.full_param_dict['alpha_perp'][ii])
            marg_dict[ii]['alpha_par']  = np.zeros((len(pbjobject.index_marg_param),1))
            marg_dict[ii]['alpha_perp'] = np.zeros((len(pbjobject.index_marg_param),1))
            marg_dict[ii]['alpha_iso']  = np.zeros((len(pbjobject.index_marg_param),1))
            marg_dict[ii]['alpha_AP']   = np.zeros((len(pbjobject.index_marg_param),1))

        TheoryVec = np.concatenate([theory_dict[ii][obs] for obs in pbjobject.Obs])
        MargVec   = np.hstack([marg_dict[ii][obs] for obs in pbjobject.Obs])

        deltaTD = np.atleast_2d(TheoryVec - np.concatenate(pbjobject.CutDataVecs[ii]))

        F1i = _compute_F1i(MargVec, pbjobject.invCov[ii], deltaTD,
                           pbjobject.prior_term_F1i[ii])
        invF2ij = np.linalg.inv(_compute_F2ij(MargVec, pbjobject.invCov[ii],
                                              pbjobject.prior_cov_inv[ii]))
        bestfits[:,ii] = np.einsum('i, ij -> j', F1i, invF2ij)
        sigmas[:,ii] = np.sqrt(np.linalg.diagonal(invF2ij))

    bestfit_dict = {par: {'bestfit': bestfits[j,:], 'sigma': sigmas[j,:]}
                    for j,par in enumerate(pbjobject.marg_params)}

    return bestfit_dict
