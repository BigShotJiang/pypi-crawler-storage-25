"""`param_handler.py` module

Handles creating and updating the parameters dictionary and constructing the
lists of nuisance parameters combinations to be used in the fixed cosmology case
and for the bispectrum multipoles.

"""

import yaml
import numpy as np
from . import cosmology
import re

def read_file(file_path):
    """Read from `yaml` file

    Parameters
    ----------
    file_path : str
        path of the `yaml` file to read
    """
    with open(file_path, 'r') as file:
        params = yaml.safe_load(file)

    return params

#-------------------------------------------------------------------------------

def parse_parameters(params, initial_params):
    """Parses the prior dictionary from file

    Constructs the initial param dictionary from the `prior.yaml` file
    Does not assign values to derived parameters

    Parameters
    ----------
    params: dict
        output of `read_file()` containing all info on priors

    Returns
    -------
    parsed_params: dict
        parameter dict with initial values
    """
    parsed_params = {key: {'value': val} for key,val in initial_params.items()}

    for key, value in params.items():

        if 'type' in value:
            param_type = value['type']

            if param_type not in ('varied', 'derived', 'fixed', 'marg', 'jeffreys'):
                raise KeyError(f"Only allowed parameter types are fixed, varied, marg, jeffreys. You set {param_type} for {key}")

            elif param_type == 'fixed':
                parsed_params[key] = {'value': value['value']}

            elif param_type == 'varied':
                parsed_params[key] = {
                    'value': value['init_value'],
                    'prior': value['prior'],
                    'prior_params': value.get('prior_params', {})}

            elif param_type in ('marg', 'jeffreys'):
                parsed_params[key] = {
                    'value': value['prior_params']['mean'],
                    'prior': value['prior'],
                    'prior_params': value.get('prior_params', {})}

    return parsed_params

#-------------------------------------------------------------------------------

def update_derived_parameters(params, parsed_params):
    """Updates derived parameters in dict

    Updates values of the derived parameters in `parsed_params` based on
    other parameters and their current values.

    Parameters
    ----------
    params: dict
        output of `read_file()`
    parsed_params: dict
        output of `parse_parameters(params)`

    Returns
    -------
    parsed_params: dict
        includes updated derived parameters
    """
    for key, value in params.items():
        if value['type'] == 'derived':
            try:
                param_value = eval(
                    params[key]['function'], {'np': np, 'cosmology': cosmology},
                    {p: np.array(parsed_params[p]) for p in params[key]['parameters']})
                if isinstance(param_value, np.ndarray):
                    param_value = list(param_value)
                parsed_params.update({key: param_value})
            except Exception as e:
                print(f"Error in computing derived parameter {key}: {e}")
    return parsed_params

#-------------------------------------------------------------------------------

APamp_string = "(1 / (parsed_params['alpha_par'] * parsed_params['alpha_perp']**2) if 'alpha_par' in parsed_params.keys() else cosmology.compute_AP_amplitude(zarr,parsed_params,self.Hubble_adim_fid,self.angular_diam_distance_fid))"

function_sub_pattern = {
    "APamp": APamp_string,
    # define higher level functions first, so lower level function strings can
    # be replaced later in iteration
    "Asztilde": "(Astilde * (DoverDLCDMz0)**2)",
    "sigma8z": "(sigma80 * DoverD0)",
    "sigma80": "(self.theory_inst._get_sigma8_0(parsed_params, self.theory_inst.kL, self.linear))",
    "Astilde": "(parsed_params['As'] * 1e9)",
    "DoverD0": "(DoverDLCDMz0 / D0overDLCDMz0)",
    # Devgr is always normalised to DLCDMz0
    "DoverDLCDMz0": "(parsed_params['D'] if 'D' in parsed_params.keys() else self.theory_inst._get_growth_functions(zarr,parsed_params,self.growth_model)[1])",
    "D0overDLCDMz0": "(self.theory_inst._get_growth_functions(0.0,parsed_params,self.growth_model)[1])",
}
# during init, initial param dict is used, so things like Astilde and
# zarr will have the shape of (n_z_bins) for multiz and a scalar for
# single z. During the run, for single z the full param dict is used
# and for multiz the zparams is used so all the functions should
# return scalars. Future additions to the sub pattern should be
# mindful of keeping this consistency.
def rewrite_derived_functions(string):
    """
    Try to parse and match the function string to replace
    the function name with the corresponding function
    that can be computed inside a :py:class:`pbjcosmo.PBJ.Pbj` object.
    It will substitute relevant parameters with `parsed_params`, which 
    should typically be the `self.full_param_dict` dictionary.
    See also :py:meth:`pbjcosmo.PBJ.Pbj.compute_derived_quantity`.
    
    For instance, if the function string has "APamp",
    it will be replace with the functino that computes the AP amplitude:
    
    .. code-block:: python
       
       >>> rewrite_derived_functions('Astilde')
       "parsed_params['As'] * 1e9"
       
    A list of supported functions can be found in `function_sub_pattern`.
    
    Parameters
    ----------
    string: str
        the function string to rewrite
        
    Returns
    -------
    string: str
        the rewritten function string
    """
    for func_name in function_sub_pattern.keys():
        regtex = r"\b" + re.escape(func_name) + r"\b"
        string = re.sub(regtex, function_sub_pattern[func_name], string)
    return string

#-------------------------------------------------------------------------------

def unpack_param_names_labels(prior_dict, varied_params):
    """Return a dictionary mapping parameter names to LaTeX labels

    Allows for unpacking of multi-z parameters

    Parameters
    ----------
    prior_dict: dict
        prior dictionary
    varied_params: list of strings
        names of the varied parameters

    Returns
    -------
    labels, names: list of strings
        unpack latex labels and names of parameters
    """
    labels = []
    names = []
    all_have_latex = all('latex' in prior_dict.get(p, {}) for p in varied_params)

    for param in varied_params:
        prior_info = prior_dict.get(param, {})
        init_value = prior_info.get('init_value')

        if isinstance(init_value, list) and len(init_value) > 1:
            for i in range(len(init_value)):
                if all_have_latex and 'latex' in prior_info:
                    param_name = f"{param}_z{i+1}"
                    latex_label = f"{prior_info['latex']}^{{z{i+1}}}"
                else:
                    param_name = f"{param}_z{i+1}"
                    latex_label = f"{param}_{{z{i+1}}}"
                names.append(param_name)
                labels.append(latex_label)
        else:
            if all_have_latex and 'latex' in prior_info:
                names.append(param)
                labels.append(prior_info['latex'])
            else:
                names.append(param)
                labels.append(param)

    return labels, names

#-------------------------------------------------------------------------------

def add_names_to_chain(prior_dict, varied_params, chain_dict):
    """Add parameter names and latex labels to the chain dictionary

    Parameters
    ----------
    prior_dict: dict
        prior dictionary
    varied_params: list of strings
        names of the varied parameters
    chain_dict: dict
        dictionary of the chain

    Returns
    -------
    chain_dict: dict
        updated with the parameter names and labels

    Notes
    -----
    If all varied parameters have a 'latex' key in prior_dict, use the latex
    parameter names; otherwise, use the parameter names strings.
    """
    labels, names = unpack_param_names_labels(prior_dict, varied_params)

    chain_dict.update({'param_names': names, 'param_labels': labels})

#-------------------------------------------------------------------------------

def construct_alphas_dict(do_AP):
    """Constructs dictionary with nuisance combinations

    Constructs a dictionary with all functions to compute the lists of nuisance
    parameters combinations, to be used for the fixed cosmology runs and the
    bispectrum multipoles

    Parameters
    ----------
    do_AP: bool
        whether to use AP parameters or not

    Returns
    -------
    out_dict: dict
        contains functions to compute the list of nuisance
    """
    out_dict = {
        'Pk': pk_alphas,
        'PX': px_alphas,
        'Bk': bk_alphas,
        'P0': p0_alphas,
        'P2': p2_alphas,
        'P4': p4_alphas,
    }
    if do_AP:
        out_dict.update({'B0': b0_alphas_AP, 'B2': b24_alphas_AP, 'B4': b24_alphas_AP})
    else:
        out_dict.update({'B0': b0_alphas, 'B2': b24_alphas, 'B4': b24_alphas})
    return out_dict

def pk_alphas(Psn, SNLeaking, b1=1, b2=0, bG2=0, bG3=0, c0=0, aP=0, ek2=0,
              **pars):
    return np.array([0, b1*b1, -2.*c0, b1*b2, b1*bG2, b2*b2, b2*bG2,
                     bG2*bG2, b1*bG3, ek2*Psn, (1.+aP)*Psn])

def px_alphas(Psn, SNLeaking, b1=1, cs2=0, bk2=0, b2=0, bG2=0, bG3=0, ek2X=0, aX=0,
              **pars):
    return np.array([0., b1, -2.*b1*cs2-bk2, 0.5*b2, 0.5*bG2, 0., 0., 0., 0.5*bG3,
                     ek2X*Psn, aX*Psn])

def bk_alphas(Psn, SNLeaking, b1=1, b2=0, bG2=0, a1=0, a2=0, **pars):
    return np.array([b1*b1*b1, b1*b1*b2, b1*b1*bG2,
                     b1*b1*(1.+a1)*Psn, (1.+a2)*Psn*Psn])

def pell_common(Psn, SNLeaking, b1=1, b2=0, bG2=0, bG3=0, c0=0, c2=0, c4=0, ck4=0, f=0,
                **pars):
    return np.array([b1*b1, b1*f, f*f, b1*b2, b1*bG2, b2*b2, b2*bG2,
                     bG2*bG2, b2*f, bG2*f, (b1*f)**2, b1*b1*f, b1*b2*f,
                     b1*bG2*f, b1*f*f, b2*f*f, bG2*f*f, f**4, f**3,
                     b1*f**3, b1*bG3, bG3*f,
                     -2.*c0, -2.*c2*f, -2.*c4*f*f,
                     ck4*f**4*b1**2, 2.*ck4*f**5*b1, ck4*f**6])

def p0_alphas(Psn, SNLeaking, aP=0, e0k2=0, e2k2=0, **pars):
    common = pell_common(Psn, SNLeaking, **pars)
    if SNLeaking:
        return np.concatenate((common,
                               np.array([e0k2*Psn, e2k2*Psn, (1. + aP)*Psn])))
    else:
        return np.concatenate((common,
                               np.array([e0k2*Psn, (1. + aP)*Psn])))

def p2_alphas(Psn, SNLeaking, aP=0, e0k2=0, e2k2=0, **pars):
    common = pell_common(Psn, SNLeaking, **pars)
    if SNLeaking:
        return np.concatenate((common,
                               np.array([e0k2*Psn, e2k2*Psn, (1. + aP)*Psn])))
    else:
        return np.concatenate((common, np.array([e2k2*Psn])))

def p4_alphas(Psn, SNLeaking, aP=0, e0k2=0, e2k2=0, **pars):
    common = pell_common(Psn, SNLeaking, **pars)
    if SNLeaking:
        return np.concatenate((common,
                               np.array([e0k2*Psn, e2k2*Psn, (1. + aP)*Psn])))
    else:
        return np.array(common)

def b0_alphas(Psn, SNLeaking, a2=0, **pars):
    common = b24_alphas(Psn, SNLeaking, **pars)
    return np.concatenate((common, [(1.+a2)*Psn*Psn]))

def b24_alphas(Psn, SNLeaking, b1=1, b2=0, bG2=0, a1=0, a3=-1, f=0, **pars):
    return np.array([b1*b1*b1, b1*b1*b2, b1*b1*bG2, f*b1*b1, f*b1*b1*b1,
                     f*f*b1*b1, f*b1*b2, f*b1*bG2, f*f*b1, f*f*f*b1, f*f*b2,
                     f*f*bG2, f*f*f, f*f*f*f, b1*b1*(1.+a1)*Psn,
                     0.5*f*b1*(2.+a1+a3)*Psn, f*f*(1.+a3)*Psn])

def b0_alphas_AP(Psn, SNLeaking, alpha_par=1, alpha_perp=1, a2=0, **pars):
    APamp = 1./alpha_par/alpha_perp**2

    coef_list = b24_alphas(Psn, SNLeaking, **pars)
    a_perp = (1. - alpha_perp)*coef_list
    a_dif = (alpha_perp - alpha_par)*coef_list
    return np.concatenate((coef_list*APamp**2, a_perp*APamp**2,
                           a_dif*APamp**2, [(1.+a2)*Psn*Psn*APamp**2]))

def b24_alphas_AP(Psn, SNLeaking, alpha_par=1, alpha_perp=1, **pars):
    APamp = 1./alpha_par/alpha_perp**2

    coef_list = b24_alphas(Psn, SNLeaking, **pars)
    a_perp = (1. - alpha_perp)*coef_list
    a_dif = (alpha_perp - alpha_par)*coef_list
    return np.concatenate((coef_list*APamp**2, a_perp*APamp**2,
                           a_dif*APamp**2))

#-------------------------------------------------------------------------------
