"""`cosmology.py` module

Handles computation of background cosmological quantities

"""
import math
import numpy as np
from scipy.integrate import quad, simpson
from scipy.special import hyp2f1, legendre

try: import evogrowthpy as evgr
except: print("\033[1;31m[WARNING]: \033[00m"+"evogrowth for non LCDM growth functions not installed")

# Add MGrowth for beyond-LCDM growth calculations
try: import MGrowth as mg
except:
    print("\033[1;31m[WARNING]: \033[00m"+"MGrowth for non LCDM growth functions not installed")
    mg = None


def Hubble_adim(z, Om, w0, wa):
    r"""Adimensional Hubble factor

    Computes the adimensional Hubble factor at a given redshift.

    Parameters
    ----------
    z : float or array_like
        redshift at which the adimensional Hubble factor is computed
    Om : float
        matter density parameter
    w0, wa : float
        dark energy parameters

    Returns
    -------
    float or array_like
        `E(z)`: value of the adimensional Hubble factor at input redshift

    Notes
    -----
    Assumes flatness, i.e. $\Omega_\Lambda = 1 - \Omega_m$

    $E(z) = \sqrt{\Omega_{m,0} (1+z)^3 + \Omega_{\Lambda} (1+z)^{3(1+w)}}$
    """
    DE_evolution = (1+z)**(3*(1+w0+wa)) * np.exp(-3. * wa * z / (1+z))
    return np.sqrt(Om * (1+z)**3 + (1-Om) * DE_evolution)

#-------------------------------------------------------------------------------

def angular_diam_distance(z, Om, w0, wa):
    r"""Angular diameter distance

    Computes the angular diameter distance at a given redshift.

    Parameters
    ----------
    z : float or array_like
        redshift at which theangular diameter distance is computed
    Om : float
        matter density parameter
    w0, wa : float
        dark energy parameters

    Returns
    -------
    float or array_like
        `D_A(z)`: value of the angular diameter distance at input redshift.

    Notes
    -----
    To speed up the calculation we are neglecting a $c/(100~h~(1+z))$ factor,
    multiply by this if you want the actual angular diameter distance in Mpc/h units.

    $D_A(z) = \int_0^z d z' \frac{1}{E(z)}$
    """
    z_arr = np.atleast_1d(z)

    def integrand(x):
        return 1.0 / Hubble_adim(x, Om, w0, wa)

    res = np.array([quad(integrand, 0.0, zi, epsrel=1e-6, epsabs=0)[0]
        for zi in z_arr])

    return res[0] if np.isscalar(z) else res

#-------------------------------------------------------------------------------

def sound_horizon_drag(Omh2, Obh2, h, Mnu=0.):
    r"""Sound horizon at drag epoch

    Computes the sound horizon at drag epoch using the fitting formula of
    [1411.1074](https://arxiv.org/abs/1411.1074)

    Parameters
    ----------
    Omh2 : float
        total matter density (including neutrinos)
    Obh2 : float
        baryon density
    h : float
        Hubble factor divided by 100
    Mnu : float, default:0
        total neutrino mass

    Notes
    -----
    $r_d = 55.154~\exp(-72.3~(M_\nu/93.14 + 0.0006)^2)/(\omega_b^{0.12807}~(\omega_b + \omega_c)^{0.25351})$
    """
    omega_nu = Mnu/93.14
    rs_d = 55.154*np.exp(-72.3*(omega_nu + 0.0006)**2)/\
        (Obh2**0.12807 * (Omh2 - omega_nu)**0.25351)
    return rs_d*h

#-------------------------------------------------------------------------------

def compute_AP_amplitude(z, cosmo, Hubble_adim_fid, angular_diam_distance_fid):
    r"""Compute AP amplitude

    Computs the $A_{AP}$ factor based on redshift, cosmology and fiducial values

    Parameters
    ----------
    z : float or array_like
        redshift
    cosmo : dict
        dictionary containing $\Omega_m$, $w_0$, $w_a$
    Hubble_adim_fid : float or array_like
        fiducial Hubble factor
    angular_diam_distance_fid : float or array_like
        fiducial angular diameter distance

    Return
    ------
    AP_amplitude : float or array_like
        rescaling amplitude for the power spectrum
    """
    alpha_par =  Hubble_adim_fid / \
        Hubble_adim(z, cosmo["Om"], cosmo["w0"], cosmo["wa"])
    alpha_perp = angular_diam_distance(
        z,cosmo["Om"], cosmo["w0"], cosmo["wa"])/angular_diam_distance_fid

    AP_amplitude = 1 / (alpha_par * alpha_perp**2)

    return AP_amplitude

#-------------------------------------------------------------------------------

def update_omega_matter(inputdict):
    r"""Update omega_matter

    Updates $\Omega_m$ and $\Omega_m~h^2$ in `inputdict` based on $\Omega_b~h^2$
    and $M_\nu$

    Parameters
    ----------
    inputdict : dict
        dictionary containing $h$, $\Omega_b~h^2$ and $M_\nu$
    """
    inputdict['Omh2'] = inputdict['Och2']+inputdict['Obh2']+inputdict['Mnu']/93.14
    inputdict['Om'] = inputdict['Omh2']/inputdict['h']**2

#-------------------------------------------------------------------------------

def growth_factor_lcdm(z, Om):
    """Growth factor

    Computes the growth factor D for the redshift specified in
    the cosmo dictionary using the hypergeometric function.
    Assumes flat LCDM.

    Parameters
    ----------
    z : float
        redshift
    Om : float
        omega_matter

    Returns
    -------
    Dz/D0 : float
        growth factor normalised to z=0
    D0 : float
        growth factor at z=0
    """
    a = 1 / (1 + z)
    Dz = a * hyp2f1(1./3, 1., 11./6, (Om - 1.) / Om * a**3)
    D0 = hyp2f1(1./3, 1., 11./6, (Om - 1.) / Om)
    return  Dz / D0, D0

#-------------------------------------------------------------------------------

def growth_rate_lcdm(z, Om):
    """Growth rate

    Computes the growth rate f for the redshift specified in
    the cosmo dictionary using the hypergeometric function.
    Assumes flat LCDM.

    Returns
    -------
    f : float
        growth rate
    """
    a = 1 / (1 + z)
    # Un-normalised growth factor:
    D, D0 = growth_factor_lcdm(z, Om)
    dhyp = hyp2f1(4./3, 2., 17./6, (Om - 1.) / Om * a**3)
    return 1. + (6./11) * a**4 / (D*D0) * (Om - 1.) / Om * dhyp

#-------------------------------------------------------------------------------

def growth_gamma(z, Om):
    pass

#-------------------------------------------------------------------------------

def growth_lcdm(z, Om=0.3, **kwargs):
    """Collects the output of `growth_rate_lcdm` and `growth_factor_lcdm`

    Parameters
    ----------
    z : float
        redshift
    Om : float, default: 0.3
        total matter density
    **kwargs

    Returns
    -------
    float
        `f`, `D` : growth rate and normalised growth factor

    Notes
    -----
    The growth factor is normalised to be 1 at z=0.
    """
    return growth_rate_lcdm(z, Om), growth_factor_lcdm(z, Om)[0]

#-------------------------------------------------------------------------------

def growth_evgr(z, Om=0.3, h=0.7, w0=-1, wa=0., xi=0., Omrc=0., **kwargs):
    r"""Growth functions from `evogrowthpy`

    Uses the `evogrowthpy` package to compute growth functions for wcdm,
    w0wacdm, nDGP and dark scattering cosmologies.

    Parameters
    ----------
    z : float
        redshift
    Om : float, default: 0.3
        total matter density
    h : float, default: 0.7
        hubble factor / 100
    w0 : float, default: -1
        dark energy parameter
    wa : float, default: 0
        dark energy parameter
    xi : float, default: 0
        strength of dark scattering interaction
    Omrc : float, default: 0
        $\Omega_{rc}$ parameter for nDGP
    **kwargs

    Returns
    -------
    float
        `f`, `D`: growth rate and normalised growth factor

    Notes
    -----
    The growth factor is normalised to be 1 in LCDM at z=0
    """
    Dnorm, _ = evgr.get_growth_wrap(Om, h, [0., -1, 0., 0., 0.])
    if isinstance(z, (list, np.ndarray)):
        Dz, fz = np.column_stack(
            [evgr.get_growth_wrap(Om, h, [iz, w0, wa, xi, Omrc]) for iz in z])
    else:
        Dz, fz = evgr.get_growth_wrap(Om, h, [z, w0, wa, xi, Omrc])
    return fz, Dz/Dnorm

#-------------------------------------------------------------------------------

def growth_mgrowth(z, cosmo_model, karr=None, Och2=None, Obh2=None, h=None,
    fR0=None, omegarc=None, **kwargs):
    """
    MGrowth-based growth evaluator returning (f, D) as 1D arrays.

    Parameters
    ----------
    z : float
        Redshift.
    cosmo_model : str
        Must be "fr" or "dgp" (case-insensitive).
    karr : array-like, optional
        Wavenumbers (required for "fr"; optional for "dgp" but used to set output length).
    cosmo : dict, optional
        Optional parameter dict that may contain Och2, Obh2, h, fR0, omegarc.
    Och2, Obh2, h : float, optional
        Background parameters (required if not provided in `cosmo`).
    fR0, omegarc : float, optional
        MG parameters for the chosen model.

    Returns
    -------
    f, D : np.ndarray
        Arrays of shape (len(karr),).
        For `fr`, growth is scale-dependent and values vary with `k`.
        For `dgp`, growth is typically scale-independent, values are broadcast.
    """
    if mg is None:
        raise ImportError("growth_mgrowth requires the `MGrowth` package")

    model = str(cosmo_model).lower()
    if model not in ("fr", "dgp"):
        raise ValueError(f"growth_mgrowth: cosmo_model must be 'fr' or 'dgp' (got {cosmo_model!r})")

    # karr handling: required for f(R), opt for DGP (controls output length)
    if karr is None:
        if model == "fr":
            raise ValueError("growth_mgrowth: karr must be provided for cosmo_model='fr'")
        karr = np.asarray([0.1], dtype=float)  # dummy to define output length
    else:
        karr = np.asarray(karr, dtype=float)

    Nk = karr.size

    def _broadcast(x):
        return np.full(Nk, float(x), dtype=float)

    # Allow either direct kwargs or values passed via **kwargs from a cosmology dict.
    Och2_ = Och2 if Och2 is not None else kwargs.get("Och2")
    Obh2_ = Obh2 if Obh2 is not None else kwargs.get("Obh2")
    h_ = h if h is not None else kwargs.get("h")
    fR0_ = fR0 if fR0 is not None else kwargs.get("fR0")
    omegarc_ = omegarc if omegarc is not None else kwargs.get("omegarc")

    if Och2_ is None or Obh2_ is None or h_ is None:
        raise ValueError("growth_mgrowth: need Och2, Obh2, h (via `cosmo` or as keyword args)")

    Ocb = (Och2_ + Obh2_) / (h_ * h_)
    a = 1.0 / (1.0 + float(z))

    background = {
        "Omega_m": Ocb,
        "h": h_,
        "w0": -1.0,
        "wa": 0.0,
        "a_arr": [a, 1.0],  # compute at a(z) and at a=1 for normalisation
    }
    # Input linear spectrum is LCDM at z=0, so normalise MG growth to LCDM D(z=0).
    _, D0_lcdm = growth_factor_lcdm(0.0, Ocb)

    # --------------------------
    # f(R): k-dependent growth
    # --------------------------
    if model == "fr":
        if fR0_ is None:
            raise ValueError("growth_mgrowth: fR0 must be provided for cosmo_model='fr'")
        cosmo_mg = mg.fR_HS(background)
        D_arr, f_arr = cosmo_mg.growth_parameters(karr, fR0=fR0_)

        D_arr = np.asarray(D_arr)
        f_arr = np.asarray(f_arr)

        # Normalise to LCDM D(z=0) to match P_LCDM(z=0) input.
        D = D_arr[:, 0] / D0_lcdm
        f = f_arr[:, 0]
        return f, D

    # --------------------------
    # DGP: typically scale-independent growth
    # --------------------------
    if omegarc_ is None:
        raise ValueError("growth_mgrowth: omegarc must be provided for cosmo_model='dgp'")

    cosmo_mg = mg.nDGP(background)
    D_raw, f_raw = cosmo_mg.growth_parameters(omegarc=omegarc_)

    D_raw = np.asarray(D_raw)
    f_raw = np.asarray(f_raw)

    # Normalise to LCDM D(z=0) to match P_LCDM(z=0) input.
    D_val = float(D_raw[0] / D0_lcdm)
    f_val = float(f_raw[0])

    return _broadcast(f_val), _broadcast(D_val)
#-------------------------------------------------------------------------------

def eval_growth_functions(cosmo_model, z, **kwargs):
    """Evaluates growth function

    Uses the method selected by `growth_model` to evaluate growth factor and
    growth rate.

    Parameters
    ----------
    cosmo_model : str
        background cosmology to compute the growth functions
    z : float
        redshift
    **kwargs
        Additional cosmology/model arguments.
        For `fr`, `karr` is required and the output is `f(k), D(k)`.
        For `dgp`, output is usually scale-independent and broadcast over `karr`.

    Returns
    -------
    float
        `f`, `D`: growth rate and growth factor evaluated with the selected model
    """
    cosmo_model = str(cosmo_model).lower()
    if cosmo_model == 'lcdm':
        return growth_lcdm(z, **kwargs)
    elif cosmo_model in ['wcdm', 'w0wacdm', 'darkscattering', 'ndgp']:
        return growth_evgr(z, **kwargs)
    elif cosmo_model in ['fr', 'dgp']:
        return growth_mgrowth(z, cosmo_model, **kwargs)
    elif cosmo_model == 'growthindex':
        return growth_gamma(z, **kwargs)

#-------------------------------------------------------------------------------

def multipole_projection(mu, pkmu, ell_list):
    r"""Projects $P(k,\mu)$ to multipoles

    Parameters
    ----------
    mu : array_like
        cosine of the angle between k and the line of sight
    pkmu : array_like
        anisotropic power spectrum
    ell_list : array_like
        list of multipoles to compute

    Returns
    -------
    array_like
        array with the multipoles ordered as `ell_list`

    Notes
    -----
    $P_\ell(k) = \frac{2\ell + 1}{2} \int_{-1}^1 {\rm d}\mu \mathcal{L}_\ell(\mu) ~ P(k, \mu)$
    """
    return np.array([simpson((2*l+1.)/2.*legendre(l)(mu)*pkmu, mu)
                     for l in ell_list])

#-------------------------------------------------------------------------------
