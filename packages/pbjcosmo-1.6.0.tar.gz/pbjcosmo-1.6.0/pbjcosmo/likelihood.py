"""likelihood.py module

Implements the Likelihood and Sampler classes.

"""
# This Python file uses the following encoding: utf-8
from emcee import EnsembleSampler, moves
import getdist.plots
import matplotlib.pyplot as plt
from multiprocess import Pool
from nautilus import Prior
from nautilus import Sampler as NautilusSampler
from numpy import inf, log, isfinite, array, hstack, ix_, einsum, sum, c_, empty, all, abs, savetxt, arange, zeros
import numpy as np
from numpy.linalg import inv
from numpy.random import randn
import os
from pandas import read_csv
from scipy.linalg import block_diag
import scipy.stats
from scipy.interpolate import InterpolatedUnivariateSpline
import sys
from typing import Optional, Union, List
from .tools import param_handler as parhandler
from .tools import prior_handler as priorhandler
from .tools import cosmology

try:
    import pocomc
except ImportError:
    print("\033[1;31m[WARNING]: \033[00m"+"pocomc not installed.")

try:
    import ultranest
except ImportError:
    print("\033[1;31m[WARNING]: \033[00m"+"ultranest not installed.")

plt.rc('text', usetex=True)
plt.rc('font', size=11)
plt.rc('xtick', direction='in')
plt.rc('ytick', direction='in')
os.environ["OMP_NUM_THREADS"] = '1'

class Likelihood:
    r"""Class for likelihood computation

    Implements several likelihood functions, to deal with different setups (e.g.
    fixed or varied cosmology, analytic marginalisation, pre-reconstruction
    power spectrum). Also implements prior functions, Hartlap and Sellentin
    corrections to the likelihood for noisy covariance matrices, support methods
    to compute the $\chi^2$ for analytic marginalisation and Jeffreys priors,
    methods to cut the datavectors and covariance.

    Attributes
    ----------
    full_param_dict : dict
        dictionary with initial values for all parameters

    Notes
    -----
    Not to be used directly, all methods are inherited by the `Pbj` class.
    """

    def __init__(self, initial_param_dict):
        """Class constructor

        Parameters
        ----------
        initial_param_dict : dict
            dictionary containing initial points in parameter space
        """
        self.full_param_dict = {key: initial_param_dict.get(key)['value']
                                for key in initial_param_dict.keys()}
        cosmology.update_omega_matter(self.full_param_dict)

#-------------------------------------------------------------------------------

    def _get_pell_kgrid(self):
        """Return the k-grid used to evaluate full-shape power multipoles."""
        if getattr(self, "kval_ext", None) is not None:
            return self.kval_ext
        return self.kPE

#-------------------------------------------------------------------------------

    def compute_derived_quantity(
        self,
        func_string,
        parsed_params=None,
        init=False,
    ):
        """
        Compute a derived quantity from a function string.
        """
        if parsed_params is None:
            if init:
                parsed_params = self.initial_param_dict.copy()
            else:
                parsed_params = self.full_param_dict.copy()
        if init:
            parsed_params = {p: np.array(parsed_params[p].get('value'))
                             for p in parsed_params.keys()}
        else:
            parsed_params = {p: np.array(parsed_params[p])
                             for p in parsed_params.keys()}

        local_context = {'parsed_params': parsed_params, 'self': self, **parsed_params}
        if hasattr(self, 'z_bins') and init:
            local_context['zarr'] = self.z_bins
        elif 'zarr' in local_context:
            pass
        else:
            local_context['zarr'] = self.z

        result = eval(
            func_string,
            {'np': np, 'cosmology': cosmology},
            local_context
        )
        return result

    def compute_function_array(self, func_string_array, parsed_params, init=False):
        """
        Compute an array of derived quantities from a list of function strings.
        """
        # avoid repeated calculations
        unique_funcs, unique_indices = np.unique(func_string_array, return_inverse=True)
        result = np.array([self.compute_derived_quantity(func, parsed_params, init)
                           for func in unique_funcs])
        return result[unique_indices]

    def compute_rescale_marg_vector(self, func_string_array, parsed_params, init=False):
        """
        Compute the rescale vector for the analytically marginalised parameters.
        """
        if not self.do_analytic_marg:
            return None
        # rescale vector is of shape (n_marg_params, n_z_bins) if multiz and during
        # initialisation, otherwise (n_marg_params) since zparams in
        # model_varied_cosmology_analytic_marg_multiz is used
        # per z bin
        if hasattr(self, 'z_bins') and init:
            vector = np.ones((len(self.marg_params), len(self.z_bins)))
        else:
            vector = np.ones(len(self.marg_params))
        if not self.do_reparam:
            return vector
        vector[self.index_rescaled_params] = self.compute_function_array(
            func_string_array,
            parsed_params,
            init=init
        )
        return vector

    def compute_derived_parameters(self, params, parsed_params, init=False):
        """Computes derived parameters based on other parameters

        To be called after `parse_parameters()` had been called and the
        `parsed_params` dictionary has been constructed, adds values for the derived
        parameters to the dictionary

        Parameters
        ----------
        params: dict
            output of `read_file()`
        parsed_params: dict
            output of `parse_parameters(params)`

        Returns
        -------
        parsed_params: dict
            dictionary including derived parameters
        """
        for key, value in params.items():
            if value['type'] == 'derived':
                try:
                    param_value = self.compute_derived_quantity(
                        params[key]['function'],
                        parsed_params,
                        init=init
                    )
                    if isinstance(param_value, np.ndarray):
                        param_value=list(param_value)
                    if init:
                        parsed_params[key] = {'value': param_value}
                    else:
                        parsed_params[key] = param_value
                except Exception as e:
                    print(f"Error in computing derived parameter {key}: {e}")
        return parsed_params

#-------------------------------------------------------------------------------

    def model_fixed_cosmology(self, params):
        r"""Likelihood function for fixed cosmology

        Can run on the following observables: `Pk`, `P0`, `P2`, `P4`, `Bk`,
        `B0`, `B2`, `B4` (no power spectrum pre-rec, no alphas from BAO)

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                    zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )

        # Create nuisance list with new values
        alpha = self.create_nuisance_list(**self.full_param_dict)

        return self.Chi2_fixCov_fixCosmo(alpha)


    def model_fixed_cosmology_AP(self, params):
        r"""Likelihood function for fixed cosmology with AP, AM, JP

        Allows for AP distortions, analytic marginalisation or Jeffreys priors.
        Can run on the following observables: `P0`, `P2`, `P4`, `B0`, `B2`, `B4`
        (no real space, no power spectrum pre-rec, no alphas from BAO)

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                    zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )
        theory_dict = {}
        marg_dict = {}
        if hasattr(self, 'do_pell'):
            if self.do_analytic_marg or self.do_jeffreys_priors:
                Pell, Pell_marg = self.theory_inst.P_kmu_z(
                    self.z, self.do_redshift_rescaling, kgrid=self.kPE,
                    do_AP=self.do_AP, AP_as_nuisance=True,
                    do_analytic_marg=True,
                    growth_model=self.growth_model,
                    cosmo = self.Inputcosmo, IRres=self.IRres, Psn=self.Psn,
                    **self.full_param_dict)

                theory_dict['P0'] = Pell[0][self.IdxP]
                theory_dict['P2'] = Pell[1][self.IdxP2]
                theory_dict['P4'] = Pell[2][self.IdxP4]

                marg_dict['P0'] = np.asarray([Pell_marg[0+3*j,self.IdxP]
                                              for j in self.index_marg_param])
                marg_dict['P2'] = np.asarray([Pell_marg[1+3*j,self.IdxP2]
                                              for j in self.index_marg_param])
                marg_dict['P4'] = np.asarray([Pell_marg[2+3*j,self.IdxP4]
                                              for j in self.index_marg_param])

            else:
                Pell_eff = self.theory_inst.P_kmu_z(
                    self.z, self.do_redshift_rescaling, kgrid=self.kPE,
                    do_analytic_marg=False,
                    growth_model=self.growth_model,
                    cosmo=self.Inputcosmo, IRres=self.IRres, do_AP=self.do_AP,
                    AP_as_nuisance=True, Psn=self.Psn, **self.full_param_dict)

                theory_dict['P0'] = Pell_eff[0][self.IdxP]
                theory_dict['P2'] = Pell_eff[1][self.IdxP2]
                theory_dict['P4'] = Pell_eff[2][self.IdxP4]

        if hasattr(self, 'do_bell'):
            bias_list = [self.alphas_dict[obs](self.Psn, self.SNLeaking,
                                               **self.full_param_dict)
                         for obs in ['B0','B2','B4']]
            bispfunc = self.theory_inst.Bispfunc_RSD(
                self.z, self.do_redshift_rescaling, self.PL,self.kB1E,self.kB2E,
                self.kB3E, self.Is0, self.Is2, self.Is4, cosmo=self.Inputcosmo,
                do_AP=self.do_AP,K=self.K,F=self.F,G=self.G,S=self.S,dF=self.dF,
                dG=self.dG, dS=self.dS, KK=self.KK, dKK=self.dKK, D=self.Dz)

            theory_dict['B0'] = einsum('i,ij->j',
                                       bias_list[0], bispfunc[0])[self.IdxB]

            if 'B2' in self.Obs:
                theory_dict['B2'] = einsum(
                    'i,ij->j', bias_list[1], bispfunc[1])[self.IdxB2]
            if 'B4' in self.Obs:
                theory_dict['B4'] = einsum(
                    'i,ij->j', bias_list[2], bispfunc[2])[self.IdxB4]

            if self.do_analytic_marg:
                for obs in set(('B0', 'B2', 'B4')).intersection(self.Obs):
                    marg_dict[obs] = np.zeros((len(self.index_marg_param),
                                               len(theory_dict[obs])))

        TheoryVec = np.concatenate([theory_dict[obs] for obs in self.Obs])

        if self.do_analytic_marg or self.do_jeffreys_priors:
            MargVec = np.hstack([marg_dict[obs] for obs in self.Obs])
            deltaTD = TheoryVec - np.concatenate(self.CutDataVecs, axis=1)

            if self.do_analytic_marg:
                chi2 = self.compute_chi2_marg(
                    deltaTD, MargVec, self.invCov, self.prior_term_F0,
                    self.prior_term_F1i, self.prior_cov_inv)
            elif self.do_jeffreys_priors:
                chi2 = self.compute_chi2_jeffreys(
                    deltaTD, MargVec, self.invCov, self.prior_term_F0,
                    self.prior_term_F1i, self.prior_cov_inv, self.prior_vector)
        else:
            chi2r_TD = einsum('rj,j->r', self.Mat_DCov, TheoryVec)
            chi2r_TT = einsum('i,ij,j', TheoryVec, self.invCov, TheoryVec)
            chi2 = chi2r_TT - 2.*chi2r_TD + self.Mat_DD

        return chi2


    def model_varied_cosmology(self, params):
        r"""Likelihood function for free cosmology

        Can run on the following observables: `Pk`, `P0`, `P2`, `P4`, `Bk`,
        `B0`, `B2`, `B4`, `alpha_par`, `alpha_perp`, `alpha_iso`, `alpha_AP`
        (no power spectrum pre-rec). Does not work with analytic marginalisation
        or Jeffreys priors.

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_varied_cosmology_analytic_marg` : free cosmology with analytic
            marginalisation or Jeffreys priors
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )
        cosmology.update_omega_matter(self.full_param_dict)

        if self.full_param_dict['w0']+self.full_param_dict['wa'] > 0.:
            return np.inf

        if self.do_redshift_rescaling:
            redshift=0
        else:
            redshift=self.z

        _, PL = self.theory_inst.linear_power_spectrum(
            self.full_param_dict, self.kL, linear=self.linear,redshift=redshift)

        if self.do_AP or hasattr(self, 'do_alphas_bao'):
            alpha_par =  self.Hubble_adim_fid / \
                cosmology.Hubble_adim(self.z, self.full_param_dict['Om'],
                                      self.full_param_dict['w0'],
                                      self.full_param_dict['wa'])
            alpha_perp = cosmology.angular_diam_distance(
                self.z,self.full_param_dict['Om'],
                self.full_param_dict['w0'],
                self.full_param_dict['wa'])/self.angular_diam_distance_fid
            self.full_param_dict['alpha_par'] = alpha_par
            self.full_param_dict['alpha_perp'] = alpha_perp

        if hasattr(self, 'do_preal') or hasattr(self, 'do_breal') or hasattr(self, 'do_bell'):
            f, D = self.theory_inst._get_growth_functions(
                self.z, self.full_param_dict, growth_model=self.growth_model,
                karr=self.kL)
            if np.ndim(f) == 0 and np.ndim(D) == 0:
                self.full_param_dict['f'] = f
                self.full_param_dict['D'] = D

        theory_dict = {}
        if hasattr(self, 'do_preal'):
            Funcs = self.theory_inst.PowerfuncIR_real(
                self.z, self.do_redshift_rescaling, PL, self.full_param_dict,
                growth_model=self.growth_model, D=D, IRres=self.IRres,
                kind = self.IRresum_kind)

            Ptempl = []
            for f in Funcs:
                iFk = InterpolatedUnivariateSpline(self.kL, f, k=3)
                Ptempl.append(
                    self.real_space_power_binner.bin_function(iFk, x_scale=self.kf))
            Ptempl.append(np.ones(self.nbinsP))

            alphas = parhandler.pk_alphas(self.Psn, 0, self.full_param_dict)
            Pgg = einsum('i,ij->j', alphas[1:], Ptempl[1:])
            theory_dict['Pk'] = Pgg[self.IdxP]

        if hasattr(self, 'do_pell'):
            self.theory_inst._Pgg_kmu_terms(
                PL, cosmo=self.full_param_dict, redshift=redshift,
                kind=self.IRresum_kind, do_AP=self.do_AP,
                window_convolution= self.window_convolution)

            if self.window_convolution is not None:
                Pell_eff = self.theory_inst.convolve_power_spectrum(
                    self.theory_inst.P_kmu_z, self.window, self.z,
                    self.do_redshift_rescaling, self.kpW,
                    kgrid=self.kL[self.kL <= self.kpmaxConv+1e-2],
                    do_analytic_marg=False,
                    do_AP=self.do_AP, AP_as_nuisance=True,
                    cosmo=self.full_param_dict, cosmo_fid=self.FiducialCosmo,
                    Psn=self.Psn, **self.full_param_dict)

            else:
                kgrid = self._get_pell_kgrid()
                Pell_eff = self.theory_inst.P_kmu_z(
                    self.z, self.do_redshift_rescaling, kgrid=kgrid,
                    do_analytic_marg=False,
                    cosmo=self.full_param_dict, cosmo_fid=self.FiducialCosmo,
                    do_AP=self.do_AP, AP_as_nuisance=True, Psn=self.Psn,
                    **self.full_param_dict)

            theory_dict['P0'] = Pell_eff[0][self.IdxP]
            theory_dict['P2'] = Pell_eff[1][self.IdxP2]
            theory_dict['P4'] = Pell_eff[2][self.IdxP4]
        # if 'Q0' in self.Obs:
        #     Qcut0 = self.get_Q0(Pell_eff[0], Pell_eff[1], Pell_eff[2])
        #     theory_dict['Q0'] = Qcut0[self.Idx['Q0']]

        if hasattr(self, 'do_breal'):
            alphas = parhandler.bk_alphas(self.Psn, 0, **self.full_param_dict)
            Btempl = self.Bggg_eff(PLO = PL)
            Bggg = einsum('i,ij->j', alphas, Btempl)
            theory_dict['Bk'] = Bggg[self.IdxB]

        if hasattr(self, 'do_bell'):
            # !!!Make this select which multipoles to compute for speed
            bias_list = [self.alphas_dict[obs](self.Psn,
                                               self.SNLeaking,
                                               **self.full_param_dict)
                         for obs in ['B0','B2','B4']]
            bispfunc = self.theory_inst.Bispfunc_RSD(
                self.z, self.do_redshift_rescaling, PL, self.kB1E, self.kB2E,
                self.kB3E,self.Is0,self.Is2,self.Is4,cosmo=self.full_param_dict,
                do_AP=self.do_AP,K=self.K,F=self.F,G=self.G,S=self.S,dF=self.dF,
                dG=self.dG, dS=self.dS, KK=self.KK, dKK=self.dKK, D=D)

            theory_dict['B0'] = einsum('i,ij->j',
                                       bias_list[0], bispfunc[0])[self.IdxB]

            if 'B2' in self.Obs:
                theory_dict['B2'] = einsum(
                    'i,ij->j', bias_list[1], bispfunc[1])[self.IdxB2]
            if 'B4' in self.Obs:
                theory_dict['B4'] = einsum(
                    'i,ij->j', bias_list[2], bispfunc[2])[self.IdxB4]

        if hasattr(self, 'do_alphas_bao'):
            rd_ratio = self.rd_fid/cosmology.sound_horizon_drag(
                self.full_param_dict['Omh2'], self.full_param_dict['Obh2'],
                self.full_param_dict['h'], Mnu=self.full_param_dict['Mnu'])
            theory_dict['alpha_par']=self.full_param_dict['alpha_par']*rd_ratio
            theory_dict['alpha_perp']=self.full_param_dict['alpha_perp']*rd_ratio
            theory_dict['alpha_iso'] = ((self.full_param_dict['alpha_par'] * \
                                         self.full_param_dict['alpha_perp']**2)**(1/3))*rd_ratio
            theory_dict['alpha_AP'] = (self.full_param_dict['alpha_par'] / \
                                        self.full_param_dict['alpha_perp'])

        TheoryVec = np.concatenate([theory_dict[obs] for obs in self.Obs])

        chi2r_TD = einsum('rj,j->r', self.Mat_DCov, TheoryVec)
        chi2r_TT = einsum('i,ij,j', TheoryVec, self.invCov, TheoryVec)

        chi2 = chi2r_TT - 2.*chi2r_TD + self.Mat_DD

        if hasattr(self, 'do_additional_bao'):
            chi2_additional_bao = self.chi2_additional_bao(self.full_param_dict,
                                                           self.additional_bao)
            chi2 += chi2_additional_bao

        return chi2


    def model_varied_cosmology_analytic_marg(self, params):
        r"""Likelihood function for free cosmology with AM or JP (single z- bin)

        Can run on the following observables: `P0`,`P2`,`P4`,`B0`,`B2`,`B4`,
        `alpha_par`, `alpha_perp`, `alpha_iso`, `alpha_AP` (no real space, no
        power spectrum pre-rec).

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_varied_cosmology_analytic_marg_multiz` : FS and joint FS+BAO for
            multiple redshift bins
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )
        cosmology.update_omega_matter(self.full_param_dict)

        if self.full_param_dict['w0']+self.full_param_dict['wa'] > 0.:
            return np.inf

        if self.do_redshift_rescaling:
            redshift=0
        else:
            redshift=self.z

        _,PL = self.theory_inst.linear_power_spectrum(
            self.full_param_dict, self.kL, linear=self.linear,redshift=redshift)

        if self.do_AP or hasattr(self, 'do_alphas_bao'):
            alpha_par =  self.Hubble_adim_fid / \
                cosmology.Hubble_adim(self.z, self.full_param_dict['Om'],
                                      self.full_param_dict['w0'],
                                      self.full_param_dict['wa'])
            alpha_perp = cosmology.angular_diam_distance(
                self.z, self.full_param_dict['Om'],
                self.full_param_dict['w0'],
                self.full_param_dict['wa']) / self.angular_diam_distance_fid
            self.full_param_dict['alpha_par'] = alpha_par
            self.full_param_dict['alpha_perp'] = alpha_perp

        if hasattr(self, 'do_pell') or hasattr(self, 'do_bell'):
            f, D = self.theory_inst._get_growth_functions(
                self.z, self.full_param_dict, growth_model=self.growth_model,
                karr=self.kL)
            if np.ndim(f) == 0 and np.ndim(D) == 0:
                self.full_param_dict['f'] = f
                self.full_param_dict['D'] = D

        theory_dict = {}
        marg_dict   = {}

        if hasattr(self, 'do_pell'):
            self.theory_inst._Pgg_kmu_terms(
                PL, cosmo=self.full_param_dict, redshift=redshift,
                kind=self.IRresum_kind, do_AP=self.do_AP,
                window_convolution= self.window_convolution)

            if self.window_convolution is not None:
                Pell, Pell_marg = self.theory_inst.convolve_power_spectrum(
                    self.theory_inst.P_kmu_z, self.window, self.z,
                    self.do_redshift_rescaling, self.kpW,
                    kgrid=self.kL[self.kL <= self.kpmaxConv+1e-2],
                    IRres=self.IRres, do_analytic_marg=True, do_AP=self.do_AP,
                    AP_as_nuisance=True, cosmo=self.full_param_dict,
                    cosmo_fid=self.FiducialCosmo, Psn=self.Psn,
                    **self.full_param_dict)
            else:
                kgrid = self._get_pell_kgrid()
                Pell, Pell_marg = self.theory_inst.P_kmu_z(
                    self.z, self.do_redshift_rescaling, kgrid=kgrid,
                    do_analytic_marg=True, do_AP=self.do_AP,AP_as_nuisance=True,
                    cosmo=self.full_param_dict, cosmo_fid=self.FiducialCosmo,
                    Psn=self.Psn, **self.full_param_dict)

            theory_dict['P0'] = Pell[0][self.IdxP]
            theory_dict['P2'] = Pell[1][self.IdxP2]
            theory_dict['P4'] = Pell[2][self.IdxP4]

            marg_dict['P0'] = np.asarray([Pell_marg[0+3*j,self.IdxP]
                                          for j in self.index_marg_param])
            marg_dict['P2'] = np.asarray([Pell_marg[1+3*j,self.IdxP2]
                                          for j in self.index_marg_param])
            marg_dict['P4'] = np.asarray([Pell_marg[2+3*j,self.IdxP4]
                                          for j in self.index_marg_param])

            # rescale the marginalised parameters
            if self.do_reparam:
                rescale_vector = self.compute_rescale_marg_vector(
                    self.rescaling_funcs_rewritten,
                    self.full_param_dict,
                    init=False
                )
                # Note parameter is multipled by the vector
                # so the power term is actually divided by the vector
                marg_dict['P0'] = marg_dict['P0'] / rescale_vector[:, None]
                marg_dict['P2'] = marg_dict['P2'] / rescale_vector[:, None]
                marg_dict['P4'] = marg_dict['P4'] / rescale_vector[:, None]

        if hasattr(self, 'do_bell'):
            # !!!Make this select which multipoles to compute for speed
            bias_list = [self.alphas_dict[obs](self.Psn,
                                               self.SNLeaking,
                                               **self.full_param_dict)
                         for obs in ['B0','B2','B4']]
            bispfunc = self.theory_inst.Bispfunc_RSD(
                self.z, self.do_redshift_rescaling, PL, self.kB1E, self.kB2E,
                self.kB3E,self.Is0,self.Is2,self.Is4,cosmo=self.full_param_dict,
                do_AP=self.do_AP,K=self.K,F=self.F,G=self.G,S=self.S,dF=self.dF,
                dG=self.dG, dS=self.dS, KK=self.KK, dKK=self.dKK, D=D)

            theory_dict['B0'] = einsum('i,ij->j',
                                       bias_list[0], bispfunc[0])[self.IdxB]
            marg_dict['B0'] = np.zeros((len(self.index_marg_param),
                                        len(theory_dict['B0'])))

            if 'B2' in self.Obs:
                theory_dict['B2'] = einsum(
                    'i,ij->j', bias_list[1], bispfunc[1])[self.IdxB2]
                marg_dict['B2'] = np.zeros((len(self.index_marg_param),
                                            len(theory_dict['B2'])))
            if 'B4' in self.Obs:
                theory_dict['B4'] = einsum(
                    'i,ij->j', bias_list[2], bispfunc[2])[self.IdxB4]
                marg_dict['B4'] = np.zeros((len(self.index_marg_param),
                                            len(theory_dict['B4'])))

        if hasattr(self, 'do_alphas_bao'):
            rd_ratio = self.rd_fid/cosmology.sound_horizon_drag(
                self.full_param_dict['Omh2'], self.full_param_dict['Obh2'],
                self.full_param_dict['h'], Mnu=self.full_param_dict['Mnu'])
            theory_dict['alpha_par']  = self.full_param_dict['alpha_par'] *rd_ratio
            theory_dict['alpha_perp'] = self.full_param_dict['alpha_perp']*rd_ratio
            theory_dict['alpha_iso']  = ((self.full_param_dict['alpha_par'] * \
                                          self.full_param_dict['alpha_perp']**2)**(1/3))*rd_ratio
            theory_dict['alpha_AP']   = (self.full_param_dict['alpha_par'] / \
                                         self.full_param_dict['alpha_perp'])

            marg_dict['alpha_par']  = np.zeros((len(self.index_marg_param),1))
            marg_dict['alpha_perp'] = np.zeros((len(self.index_marg_param),1))
            marg_dict['alpha_iso']  = np.zeros((len(self.index_marg_param),1))
            marg_dict['alpha_AP']   = np.zeros((len(self.index_marg_param),1))

        TheoryVec = np.concatenate([theory_dict[obs] for obs in self.Obs])
        MargVec = np.hstack([marg_dict[obs] for obs in self.Obs])

        deltaTD = TheoryVec - np.concatenate(self.CutDataVecs, axis=1)

        if self.do_analytic_marg:
            chi2 = self.compute_chi2_marg(
                deltaTD, MargVec, self.invCov, self.prior_term_F0,
                self.prior_term_F1i, self.prior_cov_inv)
        elif self.do_jeffreys_priors:
            chi2 = self.compute_chi2_jeffreys(
                deltaTD, MargVec, self.invCov, self.prior_term_F0,
                self.prior_term_F1i, self.prior_cov_inv, self.prior_vector)

        if hasattr(self, 'do_additional_bao'):
            chi2_additional_bao = self.chi2_additional_bao(self.full_param_dict,
                                                           self.additional_bao)
            chi2 += chi2_additional_bao

        return chi2


    def model_alphas_postrec(self, params):
        r"""Likelihood function for $\alpha_{\rm BAO}$ (single z-bin)

        Can run on the following observables: `alpha_par`, `alpha_perp`,
        `alpha_iso`, `alpha_AP`.

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_alphas_postrec_multiz` : analysis of the alphas for multiple
            redshift bins
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )
        cosmology.update_omega_matter(self.full_param_dict)

        if self.full_param_dict['w0']+self.full_param_dict['wa'] > 0.:
            return np.inf

        rd_ratio = self.rd_fid/cosmology.sound_horizon_drag(
            self.full_param_dict['Omh2'], self.full_param_dict['Obh2'],
            self.full_param_dict['h'], Mnu=self.full_param_dict['Mnu'])

        alpha_par =  self.Hubble_adim_fid / \
            cosmology.Hubble_adim(self.z, self.full_param_dict['Om'],
                                  self.full_param_dict['w0'],
                                  self.full_param_dict['wa'])*rd_ratio
        alpha_perp = cosmology.angular_diam_distance(
            self.z, self.full_param_dict['Om'],
            self.full_param_dict['w0'],
            self.full_param_dict['wa'])/self.angular_diam_distance_fid*rd_ratio
        theory_dict = {'alpha_par': alpha_par, 'alpha_perp': alpha_perp,
                       'alpha_iso': (alpha_par * alpha_perp**2)**(1/3),
                       'alpha_AP': alpha_par / alpha_perp}
        deltaTD = np.squeeze([theory_dict[obs]-self.DataDict[obs]
                              for obs in self.Obs])

        chi2 = np.einsum('i,ij,j->', deltaTD, self.invCov, deltaTD)

        if hasattr(self, 'do_additional_bao'):
            chi2_additional_bao = self.chi2_additional_bao(self.full_param_dict,
                                                           self.additional_bao)
            chi2 += chi2_additional_bao

        return chi2


    def model_alphas_postrec_multiz(self, params):
        r"""Likelihood function for $\alpha_{\rm BAO}$ (multi z-bin)

        Can run on the following observables: `alpha_par`, `alpha_perp`,
        `alpha_iso`, `alpha_AP`.

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_alphas_postrec` : analysis of the alphas for single redshift bin
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )
        cosmology.update_omega_matter(self.full_param_dict)

        if self.full_param_dict['w0']+self.full_param_dict['wa'] > 0.:
            return np.inf

        rd_ratio = self.rd_fid/cosmology.sound_horizon_drag(
            self.full_param_dict['Omh2'], self.full_param_dict['Obh2'],
            self.full_param_dict['h'], Mnu=self.full_param_dict['Mnu'])

        alpha_par =  self.Hubble_adim_fid / \
            cosmology.Hubble_adim(self.z_bins, self.full_param_dict['Om'],
                                  self.full_param_dict['w0'],
                                  self.full_param_dict['wa'])*rd_ratio
        alpha_perp = cosmology.angular_diam_distance(
            self.z_bins, self.full_param_dict['Om'],
            self.full_param_dict['w0'],
            self.full_param_dict['wa']) / \
            self.angular_diam_distance_fid*rd_ratio
        theory_dict = {'alpha_par': alpha_par, 'alpha_perp': alpha_perp,
                       'alpha_iso': (alpha_par * alpha_perp**2)**(1./3.),
                       'alpha_AP': alpha_par / alpha_perp}

        chi2 = 0
        is_nested = any(isinstance(i, list) for i in self.Obs)

        for i in range(len(self.z_bins)):
            current_obs = self.Obs[i] if is_nested else self.Obs
            if not current_obs: continue

            # np.squeeze is used here because DataDict values can have shape (N, 1)
            data_vec_i = np.array([np.squeeze(self.DataDict[obs])[i] for obs in current_obs])
            theory_vec_i = np.array([theory_dict[obs][i] for obs in current_obs])

            # Filter out NaN values that might have been introduced for missing data
            valid_indices = ~np.isnan(data_vec_i)
            if not np.all(valid_indices):
                data_vec_i = data_vec_i[valid_indices]
                theory_vec_i = theory_vec_i[valid_indices]
                # Also filter the covariance matrix for this bin
                invCov_i = self.invCov[i][np.ix_(valid_indices, valid_indices)]
            else:
                invCov_i = self.invCov[i]

            deltaTD_i = theory_vec_i - data_vec_i
            chi2 += np.einsum('i,ij,j', deltaTD_i, invCov_i, deltaTD_i)

        if hasattr(self, 'do_additional_bao'):
            chi2_additional_bao = self.chi2_additional_bao(self.full_param_dict,
                                                           self.additional_bao)
            chi2 += chi2_additional_bao

        return chi2


    def model_varied_cosmology_analytic_marg_multiz(self, params):
        r"""Likelihood function for free cosmology with AM or JP (multi z-bins)

        Can run on the following observables: `P0`,`P2`,`P4`,`B0`,`B2`,`B4`,
        `alpha_par`, `alpha_perp`, `alpha_iso`, `alpha_AP` (no real space, no
        power spectrum pre-rec). Also allows for additional BAO measurements
        that don't have a cross covariance with the other observables.

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_varied_cosmology_analytic_marg` : FS and joint FS+BAO for single
            redshift bin
        """
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )
        cosmology.update_omega_matter(self.full_param_dict)

        if self.full_param_dict['w0']+self.full_param_dict['wa'] > 0.:
            return np.inf

        _, PL = self.theory_inst.linear_power_spectrum(self.full_param_dict,
                                                       self.kL,
                                                       linear=self.linear,
                                                       redshift=0)

        if self.do_AP or hasattr(self, 'do_alphas_bao'):
            alpha_par =  self.Hubble_adim_fid / \
                cosmology.Hubble_adim(self.z_bins, self.full_param_dict['Om'],
                                      self.full_param_dict['w0'],
                                      self.full_param_dict['wa'])
            alpha_perp = cosmology.angular_diam_distance(
                self.z_bins, self.full_param_dict['Om'],
                self.full_param_dict['w0'],
                self.full_param_dict['wa']) / \
                self.angular_diam_distance_fid
            self.full_param_dict['alpha_par']  = list(alpha_par)
            self.full_param_dict['alpha_perp'] = list(alpha_perp)

        if hasattr(self, 'do_alphas_bao'):
            rd_ratio = self.rd_fid/cosmology.sound_horizon_drag(
                self.full_param_dict['Omh2'], self.full_param_dict['Obh2'],
                self.full_param_dict['h'], Mnu=self.full_param_dict['Mnu'])

        if hasattr(self, 'do_pell') or hasattr(self, 'do_bell'):
            f, D = self.theory_inst._get_growth_functions(
                self.z_bins, self.full_param_dict, growth_model=self.growth_model,
                karr=self.kL)
            if np.ndim(f) == 1 and np.ndim(D) == 1:
                self.full_param_dict['f'] = list(f)
                self.full_param_dict['D'] = list(D)

        theory_dict = {k: {} for k,i in enumerate(self.z_bins)}
        marg_dict   = {k: {} for k,i in enumerate(self.z_bins)}
        chi2 = 0

        if hasattr(self, 'do_pell'):
            self.theory_inst._Pgg_kmu_terms(
                PL, self.full_param_dict, redshift=0, kind=self.IRresum_kind,
                do_AP=self.do_AP, window_convolution=self.window_convolution)

        for ii, iz in enumerate(self.z_bins):
            zparams = {k: v[ii] if isinstance(v, list)
                       else v for k, v in self.full_param_dict.items()}
            zparams['zarr'] = iz

            if self.window_convolution is not None:
                Pell, Pell_marg = self.theory_inst.convolve_power_spectrum(
                    self.theory_inst.P_kmu_z,
                    self.window["z_"+ "%01d" % (ii)], iz, True, self.kpW,
                    kgrid=self.kL[self.kL <= self.kpmaxConv+1e-2],
                    IRres=self.IRres, do_analytic_marg=True, do_AP=self.do_AP,
                    AP_as_nuisance=True, cosmo=self.full_param_dict,
                    cosmo_fid=self.FiducialCosmo, Psn=self.Psn[ii], **zparams)
            else:
                kgrid = self._get_pell_kgrid()
                Pell, Pell_marg = self.theory_inst.P_kmu_z(
                    iz, True, kgrid=kgrid, do_AP=self.do_AP, IRres=self.IRres,
                    AP_as_nuisance=True, do_analytic_marg=True,
                    cosmo=self.full_param_dict, cosmo_fid=self.FiducialCosmo,
                    Psn=self.Psn[ii], **zparams)

            current_obs = self.Obs[ii] if isinstance(self.Obs[0], list) else self.Obs

            if 'P0' in current_obs:
                theory_dict[ii]['P0'] = Pell[0][self.IdxP[ii]]
                marg_dict[ii]['P0'] = np.asarray([Pell_marg[0+3*j,self.IdxP[ii]]
                                                  for j in self.index_marg_param])
            if 'P2' in current_obs:
                theory_dict[ii]['P2'] = Pell[1][self.IdxP2[ii]]
                marg_dict[ii]['P2'] = np.asarray([Pell_marg[1+3*j,self.IdxP2[ii]]
                                                  for j in self.index_marg_param])
            if 'P4' in current_obs:
                theory_dict[ii]['P4'] = Pell[2][self.IdxP4[ii]]
                marg_dict[ii]['P4'] = np.asarray([Pell_marg[2+3*j,self.IdxP4[ii]]
                                                  for j in self.index_marg_param])

            if self.do_reparam:
                rescale_vector = self.compute_rescale_marg_vector(
                    self.rescaling_funcs_rewritten,
                    zparams,
                    init=False,
                )
                if 'P0' in current_obs:
                    marg_dict[ii]['P0'] = marg_dict[ii]['P0'] / rescale_vector[:, None]
                if 'P2' in current_obs:
                    marg_dict[ii]['P2'] = marg_dict[ii]['P2'] / rescale_vector[:, None]
                if 'P4' in current_obs:
                    marg_dict[ii]['P4'] = marg_dict[ii]['P4'] / rescale_vector[:, None]


            if hasattr(self, 'do_alphas_bao'):
                if 'alpha_par' in current_obs:
                    theory_dict[ii]['alpha_par'] = \
                        np.atleast_1d(self.full_param_dict['alpha_par'][ii]*rd_ratio)
                    marg_dict[ii]['alpha_par']  = np.zeros((len(self.index_marg_param),1))
                if 'alpha_perp' in current_obs:
                    theory_dict[ii]['alpha_perp'] = \
                        np.atleast_1d(self.full_param_dict['alpha_perp'][ii]*rd_ratio)
                    marg_dict[ii]['alpha_perp'] = np.zeros((len(self.index_marg_param),1))
                if 'alpha_iso' in current_obs:
                    theory_dict[ii]['alpha_iso'] = np.atleast_1d(((
                        self.full_param_dict['alpha_par'][ii]*
                        self.full_param_dict['alpha_perp'][ii]**2)**(1./3.))*rd_ratio)
                    marg_dict[ii]['alpha_iso']  = np.zeros((len(self.index_marg_param),1))
                if 'alpha_AP' in current_obs:
                    theory_dict[ii]['alpha_AP'] = np.atleast_1d(
                        self.full_param_dict['alpha_par'][ii]/
                        self.full_param_dict['alpha_perp'][ii])
                    marg_dict[ii]['alpha_AP']   = np.zeros((len(self.index_marg_param),1))

            TheoryVec = np.concatenate([theory_dict[ii][obs] for obs in current_obs])
            MargVec   = np.hstack([marg_dict[ii][obs] for obs in current_obs])

            deltaTD = np.atleast_2d(TheoryVec - np.concatenate(self.CutDataVecs[ii]))

            if self.do_analytic_marg:
                chi2_iz = self.compute_chi2_marg(
                    deltaTD, MargVec, self.invCov[ii], self.prior_term_F0[ii],
                    self.prior_term_F1i[ii], self.prior_cov_inv[ii])
            elif self.do_jeffreys_priors:
                chi2_iz = self.compute_chi2_jeffreys(
                    deltaTD, MargVec, self.invCov[ii], self.prior_term_F0[ii],
                    self.prior_term_F1i[ii], self.prior_cov_inv[ii],
                    self.prior_vector[:,ii])
            chi2 += chi2_iz

        if hasattr(self, 'do_additional_bao'):
            chi2_additional_bao = self.chi2_additional_bao(self.full_param_dict,
                                                           self.additional_bao)
            chi2 += chi2_additional_bao

        return chi2


    def model_BAO(self, params):
        r"""Likelihood function for post-rec power spectrum

        Can run on the following observables: `P0_BAO`, `P2_BAO`, `P4_BAO`. Does
        not perform analytic marginalisation.

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_BAO_analytic_marg` : likelihood for post-rec power spectrum with
            analytic marg
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )

        if self.window_convolution is not None:
            Pell_eff = self.theory_inst.convolve_power_spectrum(
                self.Pgg_BAO_l, self.window, self.z, self.do_redshift_rescaling,
                self.kpW, kgrid=self.kL[self.kL <= self.kpmaxConv+1e-2],
                growth_model=self.growth_model, cosmo=self.full_param_dict,
                Psn=self.Psn, **self.full_param_dict)

        else:
            Pell_eff = self.theory_inst.Pgg_BAO_l(self.z, self.do_redshift_rescaling,
                                                  kgrid=self.kPE, Psn=self.Psn,
                                                  growth_model=self.growth_model,
                                                  cosmo=self.full_param_dict,
                                                  **self.full_param_dict)

        theory_dict = {'P0_BAO': Pell_eff[0][self.IdxP],
                       'P2_BAO': Pell_eff[1][self.IdxP],
                       'P4_BAO': Pell_eff[2][self.IdxP]}

        TheoryVec = np.concatenate([theory_dict[obs] for obs in self.Obs])

        chi2r_TD = einsum('rj,j->r', self.Mat_DCov, TheoryVec)
        chi2r_TT = einsum('i,ij,j', TheoryVec, self.invCov, TheoryVec)

        return chi2r_TT - 2.*chi2r_TD + self.Mat_DD


    def model_BAO_analytic_marg(self, params):
        r"""Likelihood function for post-rec power spectrum with AM or JP

        Can run on the following observables: `P0_BAO`, `P2_BAO`, `P4_BAO`.

        Parameters
        ----------
        params : array_like
            list of values for varied parameters

        Returns
        -------
        float
            $\chi^2$ value

        See Also
        --------
        `model_BAO` : likelihood for post-rec power spectrum without analytic marg
        """
        # Update full param dictionary with new param values
        self.full_param_dict.update({key: value for key, value in
                                     zip(self.varied_params, params)})
        # Update derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary,
            self.full_param_dict,
            init=False
        )

        if self.window_convolution is not None:
            Pell_eff, Pell_marg = self.theory_inst.P_ell_conv_BAO_marg(
                self.window, self.kpW, self.z, self.do_analytic_marg,
                kgrid=self.kL, growth_model=self.growth_model,
                cosmo=self.full_param_dict, Psn=self.Psn,
                **self.full_param_dict)
        else:
            Pell_eff, Pell_marg = self.theory_inst.Pgg_BAO_l_marg(
                self.z, self.do_redshift_rescaling, kgrid=self.kPE,
                growth_model=self.growth_model, cosmo=self.full_param_dict,
                Psn=self.Psn, **self.full_param_dict)

        theory_dict = {'P0_BAO': Pell_eff[0][self.IdxP],
                       'P2_BAO': Pell_eff[1][self.IdxP],
                       'P4_BAO': Pell_eff[2][self.IdxP]}
        marg_dict = {}
        marg_dict['P0_BAO'] = np.asarray([Pell_marg[0+3*j,self.IdxP]
                                          for j in self.index_marg_param])
        marg_dict['P2_BAO'] = np.asarray([Pell_marg[1+3*j,self.IdxP]
                                          for j in self.index_marg_param])
        marg_dict['P4_BAO'] = np.asarray([Pell_marg[2+3*j,self.IdxP]
                                          for j in self.index_marg_param])

        TheoryVec = np.concatenate([theory_dict[obs] for obs in self.Obs])
        MargVec = np.hstack([marg_dict[obs] for obs in self.Obs])

        deltaTD = TheoryVec - np.concatenate(self.CutDataVecs, axis=1)

        if self.do_analytic_marg:
            chi2 = self.compute_chi2_marg(
                deltaTD, MargVec, self.invCov, self.prior_term_F0,
                self.prior_term_F1i, self.prior_cov_inv)
        elif self.do_jeffreys_priors:
            chi2 = self.compute_chi2_jeffreys(
                deltaTD, MargVec, self.invCov, self.prior_term_F0,
                self.prior_term_F1i, self.prior_cov_inv, self.prior_vector)
        return chi2


    def chi2_additional_bao(self, param_dict, additional_bao_dict):
        r"""$\chi^2$ computation for additional BAO

        Computes the $\chi^2$ for (a set) of additional BAO measurements if
        provided in the parameter file. The $\chi^2$ is then added to the
        $\chi^2$ computed from the other observables in
        `model_varied_cosmology_analytic_marg_multiz`

        Parameters
        ----------
        param_dict : dict
            contains sampled parameters
        additional_bao_dict : dict
            contains fiducial cosmology and redshift for the additional BAO

        Returns
        -------
        float
            $\chi^2$ value
        """
        chi2 = 0
        for i in additional_bao_dict.keys():
            rd_ratio = additional_bao_dict[i]['fiducials']['rd_fid']/\
                cosmology.sound_horizon_drag(param_dict['Omh2'], param_dict['Obh2'],
                                             param_dict['h'], Mnu=param_dict['Mnu'])
            alpha_par =  additional_bao_dict[i]['fiducials']['Hubble_adim_fid'] / \
                cosmology.Hubble_adim(additional_bao_dict[i]['redshift'],
                                      param_dict['Om'],
                                      param_dict['w0'],
                                      param_dict['wa']) * rd_ratio
            alpha_perp = rd_ratio * cosmology.angular_diam_distance(
                additional_bao_dict[i]['redshift'], param_dict['Om'],
                param_dict['w0'], param_dict['wa']) / \
                additional_bao_dict[i]['fiducials']['angular_diam_distance_fid']
            alpha_iso = (alpha_par * alpha_perp**2)**(1/3)
            alpha_AP = (alpha_par / alpha_perp)

            theory_dict = {'alpha_par': alpha_par, 'alpha_perp': alpha_perp,
                           'alpha_iso': alpha_iso, 'alpha_AP': alpha_AP}
            theory = np.concatenate(np.atleast_2d(
                [theory_dict[obs] for obs in additional_bao_dict[i]['observables']]))
            deltaTD = theory - additional_bao_dict[i]['data']
            chi2 += np.einsum('i,ij,j->', deltaTD,
                              additional_bao_dict[i]['inv_cov'], deltaTD)
            return chi2

#-------------------------------------------------------------------------------

    def lnprior(self, params):
        """Log-prior

        Value of log-prior given particular values of the parameters

        Parameters
        ----------
        params : array_like
            list of varied parameters values
        """
        lp = 1.
        for pstr,pval in zip(self.varied_params, params):
            lp *= self.prior_dictionary[pstr]['distr'](pval)
        if lp: return log(lp)

        return -inf

#-------------------------------------------------------------------------------

    def prior_nested(self, quantile_cube: list) -> list:
        """Priors for nested sampling

        Constructs array of priors for nested sampling, transforming from the
        unit hypercube to non-unit uniform / Gaussian priors, as specified in
        the prior_dictionary

        Parameters
        ----------
        quantile_cube : array_like
            list of varied parameters

        Returns
        -------
        transformed_pars: array_like
            transformed parameters
        """
        transformed_pars = np.empty_like(quantile_cube)
        for i in range(len(self.varied_params)):
            transformed_pars[i] = priorhandler.prior_transform(
                self.prior_dictionary, self.varied_params[i], quantile_cube[i])

        return transformed_pars

#-------------------------------------------------------------------------------

    def lnprob(self, params: list) -> float:
        r"""Log-posterior

        Computes the log-posterior and the $\chi^2$ given particular values of
        the parameters for each dataset. If log-prior is infinite, returns
        $-\inf,\inf$.

        Parameters
        ----------
        params : array_like
            list of varied parameters

        Returns
        -------
        lp+lnLike, chi2 : float
            log-posterior (log-prior+log-likelihood), $\chi^2$.
        """
        lp = self.lnprior(params)
        if isfinite(lp):
            lnLike, chi2 = self.lnlike(params)
            return lp + lnLike, chi2

        return -inf, inf

#-------------------------------------------------------------------------------

    def lnprob_nested(self, cube):
        r"""Log-likelihood for nested sampling

        Computes the log-posterior and the $\chi^2$ given particular values of
        the parameters for each dataset. If log-priorp is infinite, returns
        $-\inf,\inf$.

        Parameters
        ----------
        cube : array_like
            list of varied parameters

        Returns
        -------
        lnLike : float
            log-likelihood
        """
        params = cube
        lnLike, chi2 = self.lnlike(params)

        return lnLike

#-------------------------------------------------------------------------------

    def lnlike_nautilus(self, param_dict):
        """Log-likelihood for the nautilus sampler

        Also handles the multi-z case where nuisance parameters' priors are
        defined with lists.

        Parameters
        ----------
        param_dict : dict
            dictionary of varied parameters (expanded)

        Returns
        -------
        lnLike : float
            log-likelihood
        """
        def compress_dict(expanded_dict):
            result = {}
            for key, value in expanded_dict.items():
                if '_z' in key:
                    main_key, sub_key = key.split('_z', 1)
                    if main_key not in result:
                        result[main_key] = []
                    result[main_key].append(value)
                else:
                    result[key] = value
            return result

        param_dict = compress_dict(param_dict)

        params = [param_dict[key] for key in self.varied_params]
        lnLike, chi2 = self.lnlike(params)
        return lnLike

#-------------------------------------------------------------------------------

    def lnlike_pocomc(self, params):
        """Log-likelihood for the pocomc sampler

        Parameters
        ----------
        params : array_like
            list of varied parameters

        Returns
        -------
        lnLike : float
            log-likelihood
        """
        lnLike, chi2 = self.lnlike(params)
        return lnLike

#-------------------------------------------------------------------------------

    def lnlike_gaussian(self, params):
        r"""Total log-likelihood (Gaussian)

        Computes the total log-likelihood and the total $\chi^2$ with a Gaussian
        likelihood function. If multiple datasets are provided (sets of
        simulations with the same parameters, to be fit simultaneously), sums
        the $\chi^2$ for the single dataset

        Parameters
        ----------
        params : array_like
            list of varied parameters

        Returns
        -------
        float
            `lnL`, `-2*lnL`: log-likelihood and $\chi^2$

        Notes
        -----
        $$\ln \mathcal{L} = - \sum_i \frac{\chi^2_i}{2}$$

        See Also
        --------
        `lnlike_harlap` : total log-likelihood with Hartlap correction
        `lnlike_sellentin` : total log-likelihood with Sellentin correction
        """
        chi2r = self.model_function(params)
        lnL = -0.5*einsum('i->', np.atleast_1d(chi2r))
        return lnL, -2.*lnL

#-------------------------------------------------------------------------------

    def lnlike_hartlap(self, params):
        r"""Total log-likelihood (Hartlap)

        Computes the total log-likelihood and the total $\chi^2$ with a Gaussian
        likelihood function corrected with the Hartlap correction of
        [0901.3269](https://arxiv.org/abs/0901.3269). If multiple datasets are
        provided (sets of simulations with the same parameters, to be fit
        simultaneously), sums the $\chi^2$ for the single datasets.

        Parameters
        ----------
        params : array_like
            list of varied parameters

        Returns
        -------
        float
            `lnL`, `chi2`: log-likelihood and $\chi^2$

        Notes
        -----
        $$\ln \mathcal{L} = - \frac{N_{\rm mocks} - N_{\rm pts} - 2}{N_{\rm mocks} - 1} \sum_i  \frac{\chi^2_i}{2}$$

        See Also
        --------
        `lnlike_gaussian` : total Gaussian log-likelihood
        `lnlike_sellentin` : total log-likelihood with Sellentin correction
        """
        chi2r = self.model_function(params)
        lnLr = -0.5 * ((self.Nmocks - self.Npts - 2.)/(self.Nmocks - 1.))*chi2r
        lnL = sum(lnLr)

        return lnL, sum(chi2r)

#-------------------------------------------------------------------------------

    def lnlike_sellentin(self, params):
        r"""Total log-likelihood (Sellentin)

        Computes the total log-likelihood and the total $\chi^2$ with a Gaussian
        likelihood function corrected with the Sellentin correction of
        [1511.05969](https://arxiv.org/abs/1511.05969). If multiple datasets are
        provided (sets of simulations with the same parameters, to be fit
        simultaneously), sums the $\chi^2$ for the single datasets.

        Parameters
        ----------
        params : array_like
            list of varied parameters

        Returns
        -------
        float
            `lnL`, `chi2`: log-likelihood and $\chi^2$

        Notes
        -----
        $$\ln \mathcal{L} = -\frac{N_{\rm mocks}}{2} \sum_i \ln \left( 1+\frac{\chi^2_i}{N_{\rm mocks}-1} \right)$$

        See Also
        --------
        `lnlike_gaussian` : total Gaussian log-likelihood
        `lnlike_hartlap` : total log-likelihood with Hartlap correction
        """
        chi2r = self.model_function(params)
        lnL = -0.5 * self.Nmocks * einsum('i->', log(1 + chi2r/(self.Nmocks-1)))

        return lnL, einsum('i->',chi2r)

#-------------------------------------------------------------------------------

    def compute_chi2_marg(self, delta_theorydata, p_marg, invcov,
                          prior_term_F0, prior_term_F1i, prior_invcov):
        r"""$\chi^2$ for the analytically marginalised case

        Parameters
        ----------
        delta_theorydata : array_like
            residual of data and non-marginalised part of the theory prediction
        p_marg : array_like
            list of arrays of the marginalised terms
        invcov : array_like
            inverse covariance matrix
        prior_term_F0 : float
            scalar contribution from priors of marginalised parameters
        prior_term_F1i : array_like
            vector contribution from priors of marginalised parameters
        prior_invcov : array_like
            inverse covariance matrix of the priors of marginalised parameters

        Returns
        -------
        chi2 : float
            marginalised $\chi^2$
        """
        F0 = np.einsum('ri, ij, rj -> r', delta_theorydata, invcov,
                       delta_theorydata) + prior_term_F0
        F1i = -np.einsum('ri, ij, kj -> r', p_marg, invcov, delta_theorydata) +\
            prior_term_F1i
        F2ij = np.einsum('ri, ij, mj -> rm', p_marg, invcov, p_marg) +\
            prior_invcov

        chi2 = F0 + np.log(np.linalg.det(F2ij)) - np.einsum(
            'i, ij, j ->', F1i, np.linalg.inv(F2ij), F1i)
        return chi2

#-------------------------------------------------------------------------------

    def compute_chi2_jeffreys(self, delta_theorydata, p_marg, invcov,
                              prior_term_F0, prior_term_F1i, prior_invcov,
                              prior_vec):
        r"""$\chi^2$ for the case with Jeffreys priors

        Parameters
        ----------
        delta_theorydata : array_like
            residual of data and non-marginalised part of the theory prediction
        p_marg : array_like
            list of arrays of the marginalised terms
        invcov : array_like
            inverse covariance matrix
        prior_term_F0 : float
            scalar contribution from priors of marginalised parameters
        prior_term_F1i : array_like
            vector contribution from priors of marginalised parameters
        prior_invcov : array_like
            inverse covariance matrix of the priors of marginalised parameters
        prior_vec : array_like
            array of means of the Gaussian priors of marginalised parameters

        Returns
        -------
        `chi2` : float
            $\chi^2$ value
        """
        F1i = -np.einsum('ri, ij, kj -> r', p_marg, invcov, delta_theorydata) +\
            prior_term_F1i
        F2ij = np.einsum('ri, ij, mj -> rm', p_marg, invcov, p_marg) +\
            prior_invcov
        nuis = np.einsum('i, ij -> j', F1i, np.linalg.inv(F2ij))
        chi2_prior = np.dot(nuis-prior_vec,np.dot(nuis-prior_vec,prior_invcov))
        delta_tot = delta_theorydata + np.einsum('r, ri -> i', nuis, p_marg)

        chi2 = np.einsum('ri, ij, rj -> ', delta_tot, invcov, delta_tot) +\
            chi2_prior

        return chi2

#-------------------------------------------------------------------------------

    def Chi2_fixCov_fixCosmo(self, alpha):
        r"""$\chi^2$ for fixed cosmology case

        Support function to compute the log-likelihood when cosmological
        parameters are fixed. Takes advantage of pre-computed arrays and matrices

        Parameters
        ----------
        alpha : array_like
            list of varied parameters

        Returns
        -------
        float
            $\chi^2$

        Notes
        -----
        $\chi^2 = \chi^2_{TT} - 2~\chi^2_{TD} + \chi^2_{DD}$ where $T=$theory,
        $D=$data.
        """
        chi2r_TD = einsum('i,ri', alpha, self.Mat_TD)
        chi2r_TT = einsum('i,j,ij', alpha, alpha, self.Mat_TT)

        return chi2r_TT - 2*chi2r_TD + self.Mat_DD

#-------------------------------------------------------------------------------

    def cut_data_vectors(self,
                         NmaxP: Union[float, List[float]] = 0,
                         NminP: Union[float, List[float]] = 0,
                         NmaxB: Union[float, List[float]] = 0,
                         NmaxP2: Optional[Union[float, List[float]]] = None,
                         NmaxB2: Optional[Union[float, List[float]]] = None,
                         NmaxP4: Optional[Union[float, List[float]]] = None,
                         NmaxB4: Optional[Union[float, List[float]]] = None):
        r"""Cuts the datavectors and covariance

        Given values of NmaxP and NmaxB, trims the datavectors, the theory
        templates and the covariance matrix, then calls the function to combine
        quantities together for a fast evaluation of the likelihood function.
        This method must be called after a `Pbj` object is initialised before
        starting the sampling (internally called by `Sampler._prepare_sampler`)

        Parameters
        ----------
        NmaxP : float or array_like, default: 0
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NminP : float or array_like, default: 0
            min value of $k_{P}$ in units of the fundamental frequency
        NmaxB : float or array_like, default: 0
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like, default: None
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like, default: None
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like, default: None
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like, default: None
            max value of $k_{\rm max,B_4} in units of the fundamental frequency

        Notes
        -----
        Sets the following attributes: `IdxP`, `IdxP2`, `IdxP4`, `IdxB`, `IdxB2`,
        `CutTheoryVecs`, `CutDataVecs`, `invCov`, `Npts`

        `NminP` is used when fitting the post-reconstruction power spectrum
        """
        def to_list(x, length=1):
            return [x] * length if isinstance(x, (int, float)) else x

        def create_bool_mask(k, Nmax, Nmin=None):
            if Nmin is not None:
                return [(k <= Nmax[i]) & (k >= Nmin[i]) for i in range(len(Nmax))]
            return [(k <= Nmax[i]) for i in range(len(Nmax))]


        scalar_inputs = isinstance(NmaxP, (int, float))

        if hasattr(self, 'z_bins'):
            num_bins = len(to_list(self.z_bins))
        else:
            num_bins = len(to_list(NmaxP))

        # Convert all inputs to lists
        NmaxP, NminP, NmaxB = map(lambda x: to_list(x,num_bins), [NmaxP,NminP,NmaxB])
        NmaxB2 = to_list(NmaxB2, num_bins) if NmaxB2 is not None else None
        NmaxP2 = to_list(NmaxP2, num_bins) if NmaxP2 is not None else None
        NmaxP4 = to_list(NmaxP4, num_bins) if NmaxP4 is not None else None
        NmaxB4 = to_list(NmaxB4, num_bins) if NmaxB4 is not None else None

        # Compute indices
        self.IdxP = create_bool_mask(self.kP, NmaxP, NminP)
        self.IdxB = create_bool_mask(self.kB1, NmaxB)
        self.IdxP2 = self.IdxP if NmaxP2 is None else create_bool_mask(
            self.kP, NmaxP2, NminP)
        self.IdxP4 = self.IdxP if NmaxP4 is None else create_bool_mask(
            self.kP, NmaxP4, NminP)
        self.IdxB2=self.IdxB if NmaxB2 is None else create_bool_mask(self.kB1,NmaxB2)
        self.IdxB4=self.IdxB if NmaxB4 is None else create_bool_mask(self.kB1,NmaxB4)
        for i in range(num_bins):
            self.IdxB4[i][4] = False

        idx_dict = {'Pk': self.IdxP,
                    'P0': self.IdxP, 'P2': self.IdxP2, 'P4': self.IdxP4,
                    'Bk': self.IdxB,
                    'B0': self.IdxB, 'B2': self.IdxB2, 'B4': self.IdxB4,
                    'P0_BAO':self.IdxP, 'P2_BAO':self.IdxP2, 'P4_BAO':self.IdxP4,
                    'alpha_par': [True for _ in range(num_bins)],
                    'alpha_perp': [True for _ in range(num_bins)],
                    'alpha_iso': [True for _ in range(num_bins)],
                    'alpha_AP': [True for _ in range(num_bins)]}

        def select_template(obs):
            if obs[0] == 'P' and len(obs) == 2:
                templ = self.P_ell_Templ[obs]
            elif obs[0] == 'B':
                templ = self.B_ell_Templ[obs]
            return templ

        flat_obs = self.Obs
        if any(isinstance(i, list) for i in self.Obs):
            flat_obs = sorted(list(set(item for sublist in self.Obs for item in sublist)))

        template_dict = {obs: array(list(select_template(obs).values()))
                 for obs in flat_obs if not obs.startswith('alpha') and 'BAO' not in obs}

        # Initialize vectors and masks
        self.CutDataVecs = [[] for _ in range(num_bins)]
        self.CutTheoryVecs = [[] for _ in range(num_bins)]
        IdxTot = [[] for _ in range(num_bins)]
        self.invCov = [[] for _ in range(num_bins)]

        if not scalar_inputs or (hasattr(self, 'z_bins') and isinstance(self.Obs[0], list)):
            for i in range(num_bins):
                current_obs = self.Obs[i] if isinstance(self.Obs[0], list) else self.Obs
                self.CutDataVecs[i] = [self.DataDict[obs][i][idx_dict[obs][i]]
                                       for obs in current_obs if not obs.startswith('alpha')]
                [self.CutDataVecs[i].extend([self.DataDict[obs][i]])
                 for obs in current_obs if obs.startswith('alpha')]
                IdxTot[i] = hstack([idx_dict[obs][i] for obs in current_obs])
                cut_cov = self.Cov[i][ix_(IdxTot[i].astype(bool),
                                          IdxTot[i].astype(bool))]
                self.invCov[i] = inv(cut_cov)

        else:
            self.CutDataVecs = [self.DataDict[obs][:,idx_dict[obs][0]]
                                for obs in self.Obs if not obs.startswith('alpha')]
            [self.CutDataVecs.extend([self.DataDict[obs][:,idx_dict[obs][0]]])
             for obs in self.Obs if obs.startswith('alpha')]
            self.CutTheoryVecs = [template_dict[obs][:,idx_dict[obs][0]]
                                  for obs in self.Obs if not obs.startswith('alpha')
                                  and 'BAO' not in obs]
            IdxTot = hstack([idx_dict[obs][0] for obs in self.Obs])
            cut_cov = self.Cov[ix_(IdxTot.astype(bool),
                                   IdxTot.astype(bool))]
            self.invCov = inv(cut_cov)
            self.IdxP = self.IdxP[0]
            self.IdxB = self.IdxB[0]
            self.IdxP2 = self.IdxP2[0]
            self.IdxP4 = self.IdxP4[0]
            self.IdxB2 = self.IdxB2[0]
            self.IdxB4 = self.IdxB4[0]

            if self.Inputcosmo is not None:
                self.combine_vectors()

        self.Npts = sum(np.concatenate(IdxTot))

#-------------------------------------------------------------------------------

    def combine_vectors(self):
        """Combines quantities together for a fast likelihood evaluation

        Notes
        -----
        Sets the following attributes: `Mat_DCov`, `Mat_DD`, `Mat_TD`, `Mat_TT`
        """
        data = hstack((self.CutDataVecs))
        self.Mat_DCov = einsum('ri,ij->rj', data, self.invCov)
        self.Mat_DD = einsum('ri,ij,rj->r', data, self.invCov, data)


        if self.CutTheoryVecs != []:
            theory = block_diag(*self.CutTheoryVecs)
            self.Mat_TD = einsum('ri,ij,tj->rt', data,   self.invCov, theory)
            self.Mat_TT = einsum('ti,ij,sj->ts', theory, self.invCov, theory)

#-------------------------------------------------------------------------------

    def create_nuisance_list(self, **pars):
        """Creates lists of nuisance combinations

        Creates lists of nuisance parameters combinations to be used in the
        fixed cosmology case and for the bispectrum multipoles.

        Parameters
        ----------
        **pars : dict
            full parameter dictionary (including fixed params)

        Returns
        -------
        flat_list : array_like
            list of (combined) nuisance parameters

        See Also
        --------
        `tools.param_handler.construct_alphas_dict`
        """
        flat_obs = self.Obs
        if any(isinstance(i, list) for i in self.Obs):
            flat_obs = sorted(list(set(item for sublist in self.Obs for item in sublist)))
        flat_list = np.concatenate([self.alphas_dict[obs](
            self.Psn, self.SNLeaking, **pars) for obs in flat_obs])
        return flat_list

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

class Sampler:
    """Class for samplers

    Implements several samplers of the posterior distribution

    Attributes
    ----------
    ndim : int
        dimensionality of the parameter space

    Notes
    -----
    Not to be used directly, all methods are inherited by the `Pbj` class.
    """

    def __init__(self):
        """Class constructor
        """
        self.ndim = len(self.varied_params)

#-------------------------------------------------------------------------------

    def run_sampler(self, **kwargs):
        """Samplers wrapper

        Wraps different samplers and returns the sampler method according to the
        `sampler` attribute

        Parameters
        ----------
        **kwargs
            keyword arguments specific for each sampler

        Returns
        -------
        function
            method implementing the selected sampler

        See Also
        --------
        `run_emcee` : affine invariant sampler from the `emcee` package
        `run_metropolis_hastings` : Metropolis-Hastings sampler from the `emcee` package
        `run_pocomc` : sampler from the `pocomc` package
        `run_nautilus` : sampler from the `nautilus` package
        `run_ultranest` : sampler from the `ultranest` package
        """
        print("\033[1;32m[info] \033[00m"+f"Sampling with {self.sampler}")
        if self.sampler == 'emcee':
            return self.run_emcee(**kwargs)
        elif self.sampler == 'Metropolis-Hastings':
            return self.run_metropolis_hastings(**kwargs)
        elif self.sampler == 'pocomc':
            return self.run_pocomc(**kwargs)
        elif self.sampler == 'nautilus':
            return self.run_nautilus(**kwargs)
        elif self.sampler == 'ultranest':
            return self.run_ultranest(**kwargs)
        else:
            print("\033[1;31m[WARNING]: \033[00m"+"Sampler not implemented")

#-------------------------------------------------------------------------------

    def _prepare_sampler(self, NmaxP, NminP, NmaxB, NmaxP2, NmaxB2, NmaxP4,
                         NmaxB4, savelog):
        r"""Support function for the initialization of samplers

        Sets nmax, the filenames, cuts the datavectors and inverts the covariance
        according to NmaxX for observable X in the `Obs` observables list.

        Parameters
        ----------
        NmaxP : float or array_like
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NminP : float or array_like
            min value of $k_{P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        savelog : bool
            whether to save info in the logfile
        """

        self._set_nmax(NmaxP, NmaxB, NmaxP2, NmaxB2, NmaxP4, NmaxB4)
        self.set_file_names()

        if savelog:
            logfile = os.path.join(self.outfolder, self.logfile)
            sys.stdout = open(logfile, 'w')
        self._print_nmax()

        self.cut_data_vectors(NmaxP=NmaxP, NminP=NminP, NmaxB=NmaxB,
                              NmaxP2=NmaxP2, NmaxB2=NmaxB2,
                              NmaxP4=NmaxP4, NmaxB4=NmaxB4)
        setattr(self, 'ndim', len(self.varied_params))

#-------------------------------------------------------------------------------

    def _set_nmax(self, NmaxP, NmaxB, NmaxP2, NmaxB2, NmaxP4, NmaxB4):
        r"""Sets attribute `nmax_dict` for observable X

        Parameters
        ----------
        NmaxP : float or array_like
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        """

        maxbins = {'P': ((arange(self.nbinsP)+0.5)*self.dk+self.cf),
                   'B': ((arange(self.nbinsB)+0.5)*self.dk+self.cf)}

        if not NmaxP4:
            NmaxP4 = NmaxP
        if not NmaxP2:
            NmaxP2 = NmaxP
        if not NmaxB2:
            NmaxB2 = NmaxB
        if not NmaxB4:
            NmaxB4 = NmaxB

        Nmax = {'Pk': NmaxP, 'P0': NmaxP, 'P2': NmaxP2, 'P4': NmaxP4,
                'P0_BAO': NmaxP, 'P2_BAO': NmaxP, 'P4_BAO': NmaxP4,
                'Bk': NmaxB, 'B0': NmaxB, 'B2': NmaxB2, 'B4': NmaxB4}

        self.nmax_dict = {}

        for o in Nmax.keys():
            if isinstance(Nmax[o], (float,int)):
                self.nmax_dict[o] = [maxbins[o[0]][abs(maxbins[o[0]]-Nmax[o]).argmin()]]
            elif isinstance(Nmax[o], list):
                self.nmax_dict[o] = [maxbins[o[0]][abs(maxbins[o[0]]-nmax).argmin()]
                                     for nmax in Nmax[o]]

#-------------------------------------------------------------------------------

    def _print_nmax(self):
        r"""Print $k_{\rm max}$ values to log / stdout
        """
        def format_string(nmax):
            if len(nmax)>1:
                formatted_values = ", ".join(["{0:.4f} h/Mpc".format(
                    inmax*self.kf) for inmax in nmax])
            else:
                formatted_values = "{0:.4f} h/Mpc".format(nmax[0] * self.kf)
            return formatted_values

        flat_obs = self.Obs
        if any(isinstance(i, list) for i in self.Obs):
            flat_obs = sorted(list(set(item for sublist in self.Obs for item in sublist)))

        for o in flat_obs:
            if not o.startswith('alpha') and o in self.nmax_dict and self.nmax_dict[o] is not None:
                print(f"Closest available kmax for {o}: {format_string(self.nmax_dict[o])}")

#-------------------------------------------------------------------------------

    def run_emcee(self, NmaxP=0, NmaxB=0, NmaxP2=None, NmaxB2=None, NmaxP4=None,
                 NmaxB4=None, NminP=0,
                 nwalker: Optional[int] = 100,
                 nsteps: Optional[int] = 50000,
                 progress: Optional[bool] = True,
                 slow: Optional[bool] = False,
                 savelog: Optional[bool] = True,
                 savetau: Optional[bool] = True):
        r"""Affine invariant sampler of emcee

        Parameters
        ----------
        NmaxP : float or array_like, default: 0
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like, default: None
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like, default: None
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like, default: None
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like, default: None
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        NminP : float or array_like, default: 0
            min value of $k_{P}$ in units of the fundamental frequency
        nwalker : int, default: 100
            number of walkers in the sampler
        nsteps : int, default: 50000
            max number of iterations in the MCMC
        progress : bool, default: True
            whether to show a progress bar
        savelog : bool, default: True
            whether to save the log to file
        savetau : bool, default: True
            whether to save the autocorrelation times for each parameter
        """
        self._prepare_sampler(NmaxP, NminP, NmaxB, NmaxP2, NmaxB2, NmaxP4,
                              NmaxB4, savelog)

        if not self.CheckConvergence:
            savetau = False

        start_point = [self.initial_param_dict[i]['value'] for i in self.varied_params]

        # Small ball
        pos = [start_point + 5.e-2 * (randn(self.ndim) - 0.5)
               for i in range(nwalker)]

        sampler = EnsembleSampler(nwalker, self.ndim, self.lnprob)

        if not slow:
            if self.CheckConvergence:
                idx = 0
                self.autocorr = empty((int(nsteps/1000)+1, self.ndim))
                old_tau = inf

                for sample in sampler.sample(pos,iterations=nsteps,progress=progress):
                    if sampler.iteration % 1000: continue
                    tau = sampler.get_autocorr_time(tol=0)
                    self.autocorr[idx] = tau
                    idx += 1

                    try:
                        converged = all(tau*100 < sampler.iteration) & all(abs(old_tau - tau)/tau < 0.01)
                    except:
                        converged = False
                    if converged or sampler.iteration == nsteps:
                        burnin = int(2 * max(tau))
                        thin = int(0.1 * min(tau))
                        break
                    old_tau =  tau
                print('\n'.join('\t'.join(str(cell) for cell in row)
                                for row in self.autocorr[:idx]))
            else:
                sampler.run_mcmc(pos, nsteps, progress=True)
                tau = sampler.get_autocorr_time(tol=0)
                burnin = int(2 * max(tau))
                thin = int(0.1 * min(tau))

            Storedchain   =sampler.get_chain(flat=True,discard=burnin,thin=thin)
            Storedlogprob =sampler.get_log_prob(flat=True,discard=burnin,thin=thin)
            Storedchi2tot =sampler.get_blobs(flat=True,discard=burnin,thin=thin)

            self.Chain = c_[Storedchain, Storedlogprob, Storedchi2tot]

            names = [self.prior_dictionary[p]['latex']
                                         for p in self.varied_params]
            chaindict = {'samples': self.Chain[:,:-2],
                         'logp': self.Chain[:,-2],
                         'chisquare': self.Chain[:,-1],
                         'observables': self.Obs}

            parhandler.add_names_to_chain(self.prior_dictionary, self.varied_params,
                                          chaindict)

            np.savez(os.path.join(self.outfolder, self.chainfile+".npz"), **chaindict)
            if savetau:
                savetxt(self.taufile, self.autocorr,header='\t'.join(self.varied_params))

        else:
            WalkerPos = zeros([nwalker,self.ndim+2])
            if self.Resume:
                chain = read_csv(self.chainfile)
                pos = chain[-1,:-2]
                lenchain = chain.shape[0]
            else:
                f = open(self.chainfile, "w")
                f.close()
                lenchain = 0
                chain = np.zeros([0,self.ndim+2])

            for sample in sampler.sample(pos, iterations=nsteps-lenchain,
                                         progress=progress):
                position, logprob, randomstate, blob = sample
                f = open(self.chainfile, "a")
                WalkerPos[:,:-2] = position
                WalkerPos[:,-2] = logprob
                WalkerPos[:,-1] = blob
                for j in range(nwalker):
                    mystring = '\t'.join(str(i) for i in WalkerPos[j])
                    f.write(mystring+"\n")
                f.close()
                chain = np.vstack((chain, WalkerPos))

#-------------------------------------------------------------------------------

    def run_metropolis_hastings(self, NmaxP=0, NminP=0, NmaxB=0, NmaxP2=None, NmaxB2=None,
                      NmaxP4=None, NmaxB4=None, nsteps: Optional[int] = 100000,
                      savelog: Optional[bool] = True):
        """Metropolis-Hastings sampler from emcee.

        Parameters
        ----------
        NmaxP : float or array_like, default: 0
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NminP : float or array_like, default: 0
            min value of $k_{P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like, default: None
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like, default: None
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like, default: None
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like, default: None
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        nsteps : int, default: 100000
            max number of iterations in the MCMC
        savelog : bool, default: True
            whether to save the log to file
        """
        nwalkers = 1

        self._prepare_sampler(NmaxP, NminP, NmaxB, NmaxP2, NmaxB2, NmaxP4, NmaxB4,
                              savelog)

        WalkerPos = [0. for i in range(self.ndim+2)]
        sampler = EnsembleSampler(nwalkers, self.ndim, self.lnprob,
                                  moves=moves.GaussianMove(self.ParCov))

        if self.Resume:
            chain = np.array(read_csv(self.chainfile, header=None, sep=r"\s+"))
            pos = chain[-1,:-2]
            lenchain = chain.shape[0]
        else:
            f = open(self.chainfile, "w")
            f.close()
            pos = [self.initial_param_dict[i]['value'] for i in self.varied_params]
            lenchain = 0
            chain = np.zeros([0,self.ndim+2])

        for sample in sampler.sample(pos, iterations=nsteps-lenchain,
                                     progress=True,skip_initial_state_check=True):
            position, logprob, randomstate, blob = sample
            f = open(self.chainfile, "a")
            for i in range(self.ndim): WalkerPos[i] = position[0,i]
            WalkerPos[-2] = logprob[0]
            WalkerPos[-1] = blob[0]
            String = '\t'.join(str(i) for i in WalkerPos)
            f.write(String+"\n")
            f.close()
            chain = np.vstack((chain, WalkerPos))

#-------------------------------------------------------------------------------

    def run_ultranest(self, NmaxP=0, NminP=0, NmaxB=0, NmaxP2=None, NmaxB2=None,
                     NmaxP4=None, NmaxB4=None, savelog: Optional[bool] = True,
                     dlogz: Optional[float] = 0.5,
                     frac_remain: Optional[float] = 0.01,
                     min_num_live_points: Optional[int] = 800,
                     print_results: Optional[bool] = False,
                     verbose: Optional[bool] = True):
        """ultranest sampler

        Parameters
        ----------
        NmaxP : float or array_like, default: 0
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NminP : float or array_like, default: 0
            min value of $k_{P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like, default: None
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like, default: None
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like, default: None
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like, default: None
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        savelog : bool, default: True
            whether to save the log to file
        dlogz : float, default: 0.5
            target evidence uncertainty
        frac_remain : float, default: 0.01
            fraction of the integral left in the remainder
        min_num_live_points : int, default: 800
            minimum number of live points
        print_results : bool, default: False
            whether to print a summary of marginal likelihood and params
        verbose : bool, default: True

        Note
        ----
        Based on the `Resume` attribute, can `'resume'` from previous run
        (if `self.Resume==True`), `'overwrite'` the previous run (if
        `self.Resume==False`), create a `'subfolder'`, or `'resume-similar'`
        """

        self._prepare_sampler(NmaxP, NminP, NmaxB, NmaxP2, NmaxB2, NmaxP4,
                              NmaxB4, savelog)
        if not self.Resume:
            resume='overwrite'
        elif self.Resume:
            resume='resume'
        else:
            resume=self.Resume

        sampler = ultranest.ReactiveNestedSampler(self.varied_params,
                                                  self.lnprob_nested,
                                                  self.prior_nested,
                                                  log_dir=self.outfolder,
                                                  resume=resume,
                                                  vectorized=False)
        self.result = sampler.run(dlogz=dlogz, frac_remain = frac_remain,
                                  min_num_live_points=min_num_live_points,
                                  show_status=verbose)
        if print_results:
            sampler.print_results()

#-------------------------------------------------------------------------------

    def run_pocomc(self, NmaxP=0, NminP=0, NmaxB=0, NmaxP2=None, NmaxB2=None,
                   NmaxP4=None, NmaxB4=None,
                   n_effective: Optional[int] = 1024,
                   n_active: Optional[int] = 512,
                   pool: Optional[int] = 1,
                   n_prior: Optional[int] = 2000,
                   n_total: Optional[int] = 10000,
                   n_evidence: Optional[int] = 4096,
                   progress: Optional[bool] = False,
                   save_every: Optional = None,
                   savelog: Optional[bool] = True):
        r"""
        pocomc sampler

        Parameters
        ----------
        NmaxP : float or array_like, default: 0
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NminP : float or array_like, default: 0
            min value of $k_{P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like, default: None
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like, default: None
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like, default: None
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like, default: None
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        n_effective : int, default: 1024
            number of effective particles
        n_active : int, default: 512
            number of active particles
        pool : int, default: 1
            number of parallel processes
        n_prior : int, default: 2000
            number of prior samples to draw
        n_total : int, default: 10000
            number of independent samples to be collected
        n_evidence : int, default: 4096
            number of samples generated to di INS estimate of the evidence
        progress : bool, default: False
            print progress bar
        save_every : int, default: None
            saves status every N steps
        savelog : bool, default: True
            whether to save the log to file

        Note
        ----
        If self.Resume==True, tries to resume from the .state file of a previous run
        """
        self._prepare_sampler(NmaxP, NminP, NmaxB, NmaxP2, NmaxB2, NmaxP4,
                              NmaxB4, savelog)

        prior_list = [0]*self.ndim
        for i in range(self.ndim):
            v = self.prior_dictionary[self.varied_params[i]]

            if v['prior'] == 'uniform':
                prior_list[i] = scipy.stats.uniform(
                    loc=v['prior_params']['min'],
                    scale=v['prior_params']['max']-v['prior_params']['min'])

            elif v['prior'] == 'gaussian':
                prior_list[i] = scipy.stats.norm(
                    loc=v['prior_params']['mean'], scale=v['prior_params']['sigma'])

            elif v['prior'] == 'log-normal':
                prior_list[i] = scipy.stats.lognormal(loc=v['prior_params']['mean'],
                                                      scale=v['prior_params']['sigma'])

            elif v['prior'] == 'log-uniform':
                prior_list[i] = scipy.stats.loguniform(
                    loc=v['prior_params']['min'],
                    scale=v['prior_params']['max']-v['prior_params']['min'])
            else:
                raise ValueError('Prior distribution not allowed for',
                                 self.varied_params[i])

        prior = pocomc.Prior(prior_list)

        if self.Resume:
            resume_state_path = os.path.join(self.outfolder,self.chainfile+".state")
        else:
            resume_state_path = None

        sampler = pocomc.Sampler(prior  = prior,
                                 likelihood = self.lnlike_pocomc,
                                 n_dim = self.ndim,
                                 n_effective = n_effective,
                                 n_active = n_active,
                                 pool = pool,
                                 n_prior = n_prior,
                                 output_dir = self.outfolder,
                                 output_label = self.chainfile)
        sampler.run(n_total = n_total,
                    n_evidence = n_evidence,
                    progress = progress,
                    resume_state_path = resume_state_path,
                    save_every = save_every)

        logZ, logZerr = sampler.evidence()
        sampler.results['logZ'] = logZ
        sampler.results['logZerr'] = logZerr

        parhandler.add_names_to_chain(self.prior_dictionary, self.varied_params,
                                      sampler.results)
        sampler.results.update('observables', self.Obs)

        np.savez(os.path.join(self.outfolder, self.chainfile+".npz"), **sampler.results)

        self.Chain = {'samples': sampler.results['x'],
                      'log_weights': sampler.results['logw'],
                      'log_posterior': sampler.results['logl']+sampler.results['logp'],
                      'log_like' : sampler.results['logl']}

#-------------------------------------------------------------------------------

    def run_nautilus(self, NmaxP=0, NminP=0, NmaxB=0, NmaxP2=None, NmaxB2=None,
                    NmaxP4=None, NmaxB4=None, n_live: Optional[int] = 2000,
                    f_live: Optional[float] = 0.01,
                    pool: Optional[int] = 1,
                    savelog: Optional[bool] = True,
                    resume: Optional[bool] = False,
                    checkpointing: Optional[bool] = True,
                    verbose: Optional[bool] = False,
                    n_eff: Optional[int] = 10000):
        r"""nautilus sampler

        Parameters
        ----------
        NmaxP : float or array_like, default: 0
            max value of $k_{\rm max,P}$ in units of the fundamental frequency
        NminP : float or array_like, default: 0
            min value of $k_{P}$ in units of the fundamental frequency
        NmaxB : float or array_like
            max value of $k_{\rm max,B}$ in units of the fundamental frequency
        NmaxP2 : float or array_like, default: None
            max value of $k_{\rm max,P_2}$ in units of the fundamental frequency
        NmaxB2 : float or array_like, default: None
            max value of $k_{\rm max,B_2}$ in units of the fundamental frequency
        NmaxP4 : float or array_like, default: None
            max value of $k_{\rm max,P_4}$ in units of the fundamental frequency
        NmaxB4 : float or array_like, default: None
            max value of $k_{\rm max,B_4} in units of the fundamental frequency
        n_live : int, default: 2000
            number of live points
        f_live : float, default:0.01
            fraction of the evidence contained in the live set
        pool : int, default: 1
            pool used for parallelization of likelihood calls
        savelog : bool, default: True
            whether to save the log to file
        resume : bool, default: True
            whether to resume from a previous run or over-write
        checkpointing : bool, default: True
            whether to save progress file to restart from previous run
        verbose : bool, default: False
            prints more info while running
        n_eff : int, default: 10000
            minimum effective sample size
        """
        self._prepare_sampler(NmaxP, NminP, NmaxB, NmaxP2, NmaxB2, NmaxP4,
                              NmaxB4, savelog)

        # Priors
        def myadd_parameter(priorsamples, p, dist, loc, scale):
            if dist == scipy.stats.uniform:
                scale = np.array(scale)-np.array(loc)
            if isinstance(loc, list):
                [priorsamples.add_parameter(p+'_z'+str(i), dist=dist(loc[i],
                                                                     scale[i]))
                 for i in range(len(loc))]
            else:
                priorsamples.add_parameter(p, dist=dist(loc, scale))

        prior_samples = Prior()

        for p in self.varied_params:
            v = self.prior_dictionary[p]

            if v['prior'] == 'uniform':
                myadd_parameter(prior_samples, p, scipy.stats.uniform,
                                v['prior_params']['min'], v['prior_params']['max'])

            elif v['prior'] == 'gaussian':
                myadd_parameter(prior_samples, p, scipy.stats.norm,
                                v['prior_params']['mean'], v['prior_params']['sigma'])

            elif v['prior'] == 'log-normal':
                myadd_parameter(prior_samples, p, np.random.lognormal,
                                v['prior_params']['mean'], v['prior_params']['sigma'])

            elif v['prior'] == 'log-uniform':
                myadd_parameter(prior_samples, p, scipy.reciprocal.rvs,
                                v['prior_params']['min'], v['prior_params']['max'])
            else:
                raise ValueError('Prior distribution not allowed for', p)

        if checkpointing:
            filepath = os.path.join(self.outfolder, self.chainfile+"_checkpoint.hdf5")
        else:
            filepath = None

        sampler = NautilusSampler(prior_samples,
                                  self.lnlike_nautilus,
                                  filepath=filepath,
                                  resume=resume,
                                  pool=pool,
                                  n_live=n_live)
        sampler.run(f_live=f_live, n_eff=n_eff, verbose=verbose,
                    discard_exploration=True)
        log_z = sampler.evidence()

        samples, log_w, log_l = sampler.posterior(return_blobs=False)

        self.Chain = {'samples': samples, 'log_weights': log_w,
                      'log_like': log_l, 'log_z': log_z, 'observables': self.Obs}

        parhandler.add_names_to_chain(self.prior_dictionary, self.varied_params,
                                      self.Chain)

        np.savez(os.path.join(self.outfolder, self.chainfile+".npz"), **self.Chain)

#-------------------------------------------------------------------------------

    def chain_statistics(self):
        r"""Computes basic statistics from the run

        Computes means and std of the parameters, MAP, mean $\chi^2$, 95% cl for
        the $\chi^2$, deviance information criterion (DIC) and effective number
        of parameters (pV), and prints them to the logfile or stdout

        Notes
        -----
        To be called after `sampler` method has finished a run.
        """
        if self.sampler == 'emcee':
            params_mean = self.Chain.mean(axis=0)
            params_std  = self.Chain.std(axis=0)
            chi2_mean = params_mean[-1]
            imaxlike = np.argmin(self.Chain[:,-1])
            params_mean = params_mean[:-2]

        elif self.sampler in ('nautilus', 'pocomc'):
            params_mean = np.average(self.Chain['samples'], axis=0,
                                     weights=np.exp(self.Chain['log_weights']))
            params_std = np.sqrt(np.average(
                (self.Chain['samples'] - params_mean)**2, axis=0,
                weights=np.exp(self.Chain['log_weights'])))
            chi2_mean = -2*np.average(self.Chain['log_like'],
                                      weights=np.exp(self.Chain['log_weights']))
            imaxlike = np.argmax(np.exp(self.Chain['log_like']))

        elif self.sampler == 'ultranest':
            params_mean = self.result['posterior']['mean']
            params_std = self.result['posterior']['stdev']
            chi2_mean = -2*self.result['weighted_samples']['logl'].mean()

        else:
            print("\033[1;31m[WARNING]: \033[00m"+\
                  f"Chain stats not implemented for sampler {self.sampler}")

        print("\n# Parameter constraints (means and standard deviations)")
        for i,p in enumerate(params_mean):
            if len(params_mean) == self.ndim:
                print(f"{self.varied_params[i]} = {params_mean[i]:.4f} ± {params_std[i]:.4f}")
            else:
                print(f"Parameter {i} = {params_mean[i]:.4f} ± {params_std[i]:.4f}")

        print("\n# MAP")
        for i,p in enumerate(params_mean):
            if self.sampler == 'ultranest':
                print(f"# {self.varied_params[i]} = {self.result['maximum_likelihood']['point'][i]:.4f}")
            elif self.sampler == 'nautilus':
                if len(params_mean) == self.ndim:
                    print(f"{self.varied_params[i]} = {self.Chain['samples'][imaxlike,i]:.4f}")
                else:
                    print(f"Parameter {i} = {self.Chain['samples'][imaxlike,i]:.4f}")
            else:
                print(f"{self.varied_params[i]} = {self.Chain[imaxlike,i]:.4f}")

        dof = int(self.Npts * self.NSets - len(params_mean))
        print("\n# Average Chi-square")
        print(f"# chisq/dof = {chi2_mean:.2f}/{dof} = {chi2_mean/dof:.5f}")
        print(f"# 95% reference value: chisq = {scipy.stats.chi2.isf(0.05,dof):.2f}")

        if self.sampler == "emcee":
            print("\n# Deviance Information Criterion")
            Dev = -2. * self.Chain[:,-2]
            pV  = 0.5 * Dev.var()
            DIC = Dev.mean() + pV
            print(f"# pV = {pV:.2f}, Npars = {self.ndim}")
            print(f"# DIC = {DIC:.2f}")

#-------------------------------------------------------------------------------

    def set_file_names(self):
        """Generates filenames

        Generates the filenames for different output files and sets
        them as attributes.

        Notes
        -----
        Must be called after `_set_nmax` that sets the `Nmax[OBS]` attributes

        """
        flat_obs = self.Obs
        if any(isinstance(i, list) for i in self.Obs):
            flat_obs = sorted(list(set(item for sublist in self.Obs for item in sublist)))

        obs = '-'.join(flat_obs)
        if self.kmax_string:
            Nmax = "kmax-"+self.kmax_string+"_"
        else:
            nmax_parts=[]
            for oo in flat_obs:
                if not oo.startswith('alpha'):
                    nmax_values = [f"{float(x):.1f}" for x in self.nmax_dict[oo]]
                    nmax_str = "-".join(nmax_values)
                    kmax_part = f"Nmax{oo}_{nmax_str}"
                    nmax_parts.append(kmax_part)
            Nmax = "_".join(nmax_parts)

        commonstr = f"{obs}_dk{self.dk:.1f}_{Nmax}{self.comment}"
        self.chainfile = commonstr
        self.logfile   = commonstr+".log"
        self.plotfile  = commonstr+".pdf"

        if self.sampler == "emcee":
            self.taufile = commonstr+".tau"

#-------------------------------------------------------------------------------

    def plot_contours(self, fiducial_dict: Optional[dict] = None):
        """Plots marginalised posterior

        Automatically generate and save a plot of the 2D marginalised posterior
        using `getdist`. Uses bounds of the flat priors as `ranges`, `'latex'`
        entries in the prior.yaml for the axes labels, samples (and weights, if
        needed) from the chain. A `fiducial_dict` can be specified with fiducial
        values of the parameters (that must have the same names as those in
        `varied_params`), to plot fiducial lines in the contourplot.

        Parameters
        ----------
        fiducial_dict : dict, default: None
            dictionary with fiducial values of the parameters to plot

        Notes
        -----
        To be called after `sampler` method has finished a run.
        """
        ranges = {
            p: [self.prior_dictionary[p]['prior_params']['min'],
                self.prior_dictionary[p]['prior_params']['max']]
            for p in self.varied_params
            if self.prior_dictionary[p]['prior'] == 'uniform'
        }

        names = [p for p in self.varied_params]
        labels = [self.prior_dictionary[p]['latex'] for p in self.varied_params]

        if self.sampler == 'ultranest':
            samples = self.result['samples']
            weights = self.result['weights']
        elif self.sampler in ('nautilus', 'pocomc'):
            samples = self.Chain['samples']
            weights = np.exp(self.Chain['log_weights'])
        elif self.sampler == 'emcee':
            samples = self.Chain[:, :self.ndim]
            weights = None

        Sample = getdist.MCSamples(
            samples = samples, names = names, weights=weights,
            labels = labels, label=r'Chain', ranges=ranges)

        g = getdist.plots.getSubplotPlotter(subplot_size=1.3)
        g.settings.axes_fontsize = 22
        g.settings.lab_fontsize = 22
        g.triangle_plot(Sample, filled=True)

        if fiducial_dict is not None:
            for i in range(self.ndim):
                for j in range(i+1):
                    ax = g.subplots[i,j]
                    if i != j and self.varied_params[i] in fiducial_dict:
                        ax.axhline(fiducial_dict[self.varied_params[i]],
                                   lw=1.,color='tab:gray')
                    if self.varied_params[j] in fiducial_dict:
                        ax.axvline(fiducial_dict[self.varied_params[j]],
                                   lw=1.,color='tab:gray')

        plot_dir = os.path.join(self.outfolder, "plots")
        os.makedirs(plot_dir, exist_ok=True)
        plt.savefig(os.path.join(plot_dir, self.plotfile), bbox_inches='tight')
        plt.close()
