"""
PBJ.py module

Implements the `Pbj` class that wraps theory, templates, likelihood and sampler

"""

from pandas import read_csv
import numpy as np
from .theory import Theory
from .templates import Templates
from .likelihood import Likelihood, Sampler
from .binning import *
from collections import OrderedDict
from scipy.interpolate import InterpolatedUnivariateSpline
import sys
from .tools import bispectrum_functions as bispfunc
from .tools import param_handler as parhandler
from .tools import prior_handler as priorhandler
from .tools import data_handler as datahandler
from .tools import cosmology

import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # Suppress TensorFlow warnings

class Pbj(Templates, Likelihood, Sampler):
    """Main class to run cosmological inference

    Minimal initialization requires the definition of a dictionary including
    only the cosmological parameters and the redshift.

    Parameters
    ----------
    input_dict : dict
        dictionary read from the input param.yaml file

    Attributes
    ----------
    linear : {'camb', 'bacco'}, default: 'camb'
        backend to compute the linear power spectrum
    IRres : bool, default: True
        whether to perform infrared resummation
    IRresum_kind : {'EH', 'DST'}, default: 'EH'
        algorithm to perform infrared resummation
    do_redshift_rescaling : bool, default: True
        whether to rescale quantities from z=0 using the linear growth factor
    do_AP : bool, default: False
        whether to apply Alcock-Paczynski distortions
    w_dict : dict
        dictionary loaded from mixing matrix file
    window_convolution : bool, default: None
        whether to perform window convolution
    Inputcosmo : dict
        input cosmology
    z : float
        redshift, extracted from `Inputcosmology`
    inputfile : str, default: None
        file with input linear power spectrum and k values
    theory_inst : object
        instance of the `pbjcosmo.Theory` class
    z_bins : array_like
        redshift bins (to run on multiple bins)
    growth_model : str, default: 'lcdm'
        background cosmological model, used to compute growth functions
    f, Dz: float or array_like
        growth rate and growth factor. For scale-dependent MG models
        (e.g. `fr`), these can be arrays over `k`.
    AP_as_nuisance : bool, default: False
        whether to vary the AP parameters as free (not computed from cosmology)
    FiducialCosmo : dict, default: `Inputcosmo`
        dictionary with fiducial cosmology (for AP)
    Hubble_adim_fid : float or array_like
        fiducial values of adimensional Hubble $E(z)$
    angular_diam_distance_fid : float or array_like
        fiducial valued of the angular diameter distance $D_A(z)$
    rd_fid : float
        fiducial value of the sound horizon at baryon drag
    kval_ext : array_like, default: None
        external wavenumbers (if they don't follow a binning scheme)

    Notes
    -----
    Additional attributes are set by the other methods in this class.

    Some parameters in `Inputcosmology` take default values if not
    specified: `{'Mnu': 0., 'w0': -1., 'wa': 0., 'tau': 0.0952, 'Tcmb': 2.7255}`
    """
    def __init__(self, input_dict):
        """Class constructor

        Parameters
        ----------
        input_dict : dict
            dictionary loaded from param.yaml
        """
        # Starting with minimal initialization
        self.input_dict = input_dict

        # theory
        self.linear = input_dict.get('theory', {}).get('linear', 'camb')
        print("\033[1;32m[info] \033[00m"+\
              f"The linear power spectrum will be computed with {self.linear}")

        self.IRres = input_dict.get('theory', {}).get('IRresum', True)
        self.IRresum_kind = input_dict.get('theory', {}).get('IRresum_kind', 'EH')
        print("\033[1;32m[info] \033[00m"+\
              f"Infrared resummation: {self.IRres}, kind: {self.IRresum_kind}")

        self.do_redshift_rescaling = input_dict.get('theory', {}).get('do_redshift_rescaling', True)

        # AP
        self.do_AP = input_dict.get('AP', {}).get('do_AP', False)
        print("\033[1;32m[info] \033[00m"+\
              f"Alcock-Paczynski distortions: {self.do_AP}")

        self.flat = input_dict.get('FlatCosmology', True)

        # Convolution
        self.window_convolution = input_dict.get('window', {}).get('convolve', None)
        if self.window_convolution:
            print("\033[1;32m[info] \033[00m"+\
                  f"Window convolution: {self.window_convolution}")
            self.w_dict = datahandler.load_window(self.input_dict["window"]["file"])
        else:
            print("\033[1;32m[info] \033[00m"+"No window convolution")


        # Input cosmology dictionary
        self.Inputcosmo = input_dict['input_cosmology']
        # Add default values for some params, if not specified
        for key,val in zip(['Mnu','w0','wa','tau','Tcmb'],
                           [0., -1., 0., 0.0952, 2.7255]):
            self.Inputcosmo.setdefault(key, val)

        cosmology.update_omega_matter(self.Inputcosmo)

        self.z = self.Inputcosmo.pop('z')
        self.inputfile = self.Inputcosmo.pop('inputfile', None)

        if self.Inputcosmo:
            for entry in self.Inputcosmo.keys():
                setattr(self, entry, self.Inputcosmo[entry])

            if self.flat:
                self.Ok = 0
                self.OL = 1. - self.Om
            else:
                self.Ok = 1. - self.Om - self.OL

            if self.inputfile:
                Pinput = np.loadtxt(self.inputfile)
                print("\033[1;32m[info] \033[00m"+\
                      f"Linear power spectrum loaded from: {self.inputfile}")
                kL, PL = np.array(Pinput).T
                self.theory_inst = Theory(kL=kL, linear=self.linear)
            else:
                self.theory_inst = Theory(linear=self.linear)
                if self.do_redshift_rescaling:
                    kL, PL = self.theory_inst.linear_power_spectrum(
                        self.Inputcosmo, self.theory_inst.kL,
                        redshift=0) # Just for the initialization use CAMB
                else:
                    kL, PL = self.theory_inst.linear_power_spectrum(
                        self.Inputcosmo, self.theory_inst.kL,
                        redshift=self.z) # Just for the initialization use CAMB

            self.kL = kL
            self.PL = PL

            if 'redshift_bins' in input_dict:
                self.z_bins = np.asarray(input_dict['redshift_bins'])

            # Set growth
            self.growth_model = input_dict['theory'].get('growth', 'lcdm')
            self.f, self.Dz = cosmology.eval_growth_functions(
                self.growth_model, self.z, karr=self.kL, **self.Inputcosmo)

            self.Pktags = ['LO', 'NLO', 'k2LO', 'b1b2', 'b1bG2', 'b2b2',
                           'b2bG2', 'bG2bG2', 'b1bG3', 'k2']

            self.Bktags = ['b13', 'b12b2', 'b12bG2', 'b12a1']

            self.Pltags = ['b1b1', 'fb1', 'f2', 'b1b2', 'b1bG2', 'b2b2',
                           'b2bG2', 'bG2bG2', 'fb2', 'fbG2', 'f2b12', 'fb12',
                           'fb1b2', 'fb1bG2', 'f2b1', 'f2b2', 'f2bG2', 'f4',
                           'f3', 'f3b1', 'b1bG3', 'fbG3', 'c0', 'fc2', 'f2c4',
                           'f4b12ck4','f5b1ck4','f6ck4','e0k2', 'e2k2', 'aP']

            if self.do_AP:
                self.Bltags = ['Bb13_0', 'Bb12b2_0', 'Bb12bG2_0', 'Bfb12_0',
                               'Bfb13_0', 'Bf2b12_0', 'Bfb1b2_0', 'Bfb1bG2_0',
                               'Bf2b1_0', 'Bf3b1_0', 'Bf2b2_0', 'Bf2bG2_0',
                               'Bf3_0', 'Bf4_0', 'Bb12a1_0', 'Bfb1a1_0', 'Bf2a1_0',
                               'Bb13_perp', 'Bb12b2_perp', 'Bb12bG2_perp',
                               'Bfb12_perp', 'Bfb13_perp', 'Bf2b12_perp',
                               'Bfb1b2_perp', 'Bfb1bG2_perp', 'Bf2b1_perp',
                               'Bf3b1_perp', 'Bf2b2_perp', 'Bf2bG2_perp',
                               'Bf3_perp', 'Bf4_perp', 'Bb12a1_perp', 'Bfb1a1_perp',
                               'Bf2a1_perp', 'Bb13_dif', 'Bb12b2_dif', 'Bb12bG2_dif',
                               'Bfb12_dif', 'Bfb13_dif', 'Bf2b12_dif', 'Bfb1b2_dif',
                               'Bfb1bG2_dif', 'Bf2b1_dif', 'Bf3b1_dif', 'Bf2b2_dif',
                               'Bf2bG2_dif', 'Bf3_dif', 'Bf4_dif', 'Bb12a1_dif',
                               'Bfb1a1_dif', 'Bf2a1_dif']
            else:
                self.Bltags = ['b13', 'b12b2', 'b12bG2', 'fb12', 'fb13', 'f2b12',
                               'fb1b2', 'fb1bG2', 'f2b1', 'f3b1', 'f2b2', 'f2bG2',
                               'f3', 'f4', 'b12a1', 'fb1a1', 'f2a1']


            P_REAL = self.theory_inst.PowerfuncIR_real(
                self.z, self.do_redshift_rescaling, self.PL, self.Inputcosmo,
                growth_model=self.growth_model, IRres=self.IRres,
                kind=self.IRresum_kind)
            self.Pk = OrderedDict(zip(self.Pktags,P_REAL))

            if self.do_redshift_rescaling:
                self.theory_inst._Pgg_kmu_terms(
                    self.PL, self.Inputcosmo, redshift=0,
                    kind=self.IRresum_kind, do_AP=self.do_AP,
                    window_convolution=self.window_convolution)
            else:
                self.theory_inst._Pgg_kmu_terms(
                    self.PL, self.Inputcosmo, redshift=self.z,
                    kind=self.IRresum_kind, do_AP=self.do_AP,
                    window_convolution=self.window_convolution)


            P0_RSD, P2_RSD, P4_RSD = self.theory_inst.PowerfuncIR_RSD(
                self.z, self.Inputcosmo, self.do_redshift_rescaling, self.PL,
                growth_model=self.growth_model, IRres=self.IRres, kind=self.IRresum_kind)
            P0k = OrderedDict(zip(self.Pltags, P0_RSD))
            P2k = OrderedDict(zip(self.Pltags, P2_RSD))
            P4k = OrderedDict(zip(self.Pltags, P4_RSD))

            self.P_ell_k = {0: P0k, 2: P2k, 4: P4k}

        else:
            raise KeyError("No InputCosmology specified")

        if self.do_AP:
            self.AP_as_nuisance = input_dict.get('AP', {}).get('AP_as_nuisance', False)

            if not self.AP_as_nuisance:
                try:
                    self.FiducialCosmo = input_dict['AP']['fiducial_cosmology']
                    for key,val in zip(
                            ['Mnu','w0','wa','Ob'],
                            [0.,-1.,0.,self.Inputcosmo['Obh2']/self.FiducialCosmo['h']**2]):
                        self.FiducialCosmo.setdefault(key, val)
                except:
                    raise KeyError("do_AP = True, but FiducialCosmo dictionary not specified in parameter file")

                if hasattr(self, 'z_bins'):
                    self.theory_inst._set_fiducials_for_AP(
                        self.z_bins, self.FiducialCosmo)
                else:
                    self.theory_inst._set_fiducials_for_AP(
                        self.z, self.FiducialCosmo)
                self.Hubble_adim_fid = self.theory_inst.Hubble_adim_fid
                self.angular_diam_distance_fid = \
                    self.theory_inst.angular_diam_distance_fid
                self.rd_fid = self.theory_inst.rd_fid
        else:
            self.FiducialCosmo = self.Inputcosmo

        # Load optional k_values and triangle files
        self.kval_ext = datahandler.load_optional_array(input_dict, 'kvalues')
        self.k1_ext, self.k2_ext, self.k3_ext = datahandler.load_optional_array(
            input_dict, 'ktriangles', unpack=True)

#-------------------------------------------------------------------------------

    def initialise_grid(self):
        """Box and grid properties

        Initialises box and grid properties, then prepares for binning and
        computes templates for all correlation functions with the chosen binning
        scheme.
        """

        self.box_size  = self.input_dict['boxsize']
        # binning
        for entry in self.input_dict['binning']['grid']:
            setattr(self, entry, self.input_dict['binning']['grid'][entry])

        self.InputTheory = self.input_dict.get('input_theory_templates', {'Pk': None})
        self.SNLeaking = self.input_dict.get('binning', {}).get('SNLeaking', False)

        self.kf = 2.*np.pi/self.box_size
        print("\033[1;32m[info] \033[00m"+\
              f"Box size: {self.box_size}, grid properties: {self.input_dict['binning']['grid']}")

        self.binning = self.input_dict.get('binning', {}).get('type', 'Effective')
        if self.window_convolution:
            print("\033[1;32m[info] \033[00m"+"Using binning from window.")
        else:
            print("\033[1;32m[info] \033[00m"+f"Using {self.binning} binning.")

        NPmax = (self.nbinsP-0.5)*self.dk + self.cf
        if NPmax > 512.5:
            self.nbinsP = int((NPmax - self.cf)/self.dk + 0.5)
            self.NPmax = (self.nbinsP-0.5)*self.dk + self.cf
            print("\033[1;31m[WARNING] \033[00m"+\
                  f"Power spectrum exceeding maximum grid size.\nSetting nbinsP={self.nbinsP}")
        else: self.NPmax = NPmax

        # Convolution
        if self.window_convolution:
            # Check the k' of the P window mixing matrix work fine
            if self.input_dict["window"]["grid"]["epsilonkpConv"] is not None:

                self.input_dict["window"]["grid"]["kpmaxConv"] = (
                    self.NPmax*self.kf + self.input_dict["window"]["grid"]["epsilonkpConv"])

            elif self.input_dict["window"]["grid"]["kpmaxConv"] < self.NPmax*self.kf:
                raise ValueError(f"Maximum convolution k' must be larger than NPmax = {self.NPmax}.")
            self.kpmaxConv = self.input_dict["window"]["grid"]["kpmaxConv"]
            print("\033[1;32m[info] \033[00m"+\
                  f"k'_max for convolution: {np.round(self.kpmaxConv,3)} h/Mpc.")

            # Trim window mixing matrix to k'_max
            kpW_multipoles = list()
            for lp in self.w_dict['k2']:
                if self.w_dict['k2'][lp][0] <= 1e-4:
                    print("\033[1;31m[WARNING] \033[00m"+\
                          f"Array of k' of the mixing matrix for multipole {lp} cut at k'=1e-4 h/Mc")
                mask = (self.w_dict['k2'][lp]<self.kpmaxConv) & (self.w_dict['k2'][lp]>=1e-4)
                kpW_multipoles.append(self.w_dict['k2'][lp][mask])

            check_kpW = list(kpW_multipoles)
            assert all(np.array_equal(v, check_kpW[0]) for v in check_kpW), (
                "\033[1;31m[WARNING] \033[00m" +\
                "Different window k' for the different multipoles!")
            self.kpW = check_kpW[0]

            if hasattr(self, 'z_bins'):
                self.window = {}
                for iz in range(len(self.z_bins)):
                    for lp in self.w_dict['k2']:
                        for l in (0, 2, 4):
                            self.w_dict["z_"+ "%01d" % (iz)]['wc'][l, lp] = \
                                self.w_dict["z_"+ "%01d" % (iz)]['wc'][l, lp][:, mask]
                    self.window["z_"+ "%01d" % (iz)] = np.block(
                        [[self.w_dict["z_"+ "%01d" % (iz)]['wc'][l, lp]
                          for lp in self.w_dict['k2'].keys()] for l in (0, 2, 4)])
            else:
                for lp in self.w_dict['k2']:
                    for l in (0, 2, 4):
                        self.w_dict['wc'][l, lp] = self.w_dict['wc'][l, lp][:, mask]
                # Matilde: need to change this
                # Stack mixing matrix
                self.window = np.block(
                    [[self.w_dict['wc'][l, lp] for lp in self.w_dict['k2'].keys()]
                     for l in (0, 2, 4)])
            print("\033[1;32m[info] \033[00m"+"Loaded window mixing matrix.")

        NBmax = (self.nbinsB-0.5)*self.dk + self.cf
        if NBmax > 64.5:
            self.nbinsB = int((NBmax -self.cf)/self.dk + 0.5)
            self.NBmax = (self.nbinsB-0.5)*self.dk + self.cf
            print("\033[1;31m[WARNING] \033[00m"+\
                  f"Bispectrum exceeding maximum grid size.\nSetting nbinsB = {self.nbinsB}")
        else: self.NBmax = NBmax

        power_binning_scheme = BinningScheme(self.cf, self.dk, self.nbinsP,
                                             right_open=True)
        bisp_binning_scheme  = BinningScheme(self.cf, self.dk, self.nbinsB,
                                             right_open=True)

        power_linear_bins = Bins.linear_bins(power_binning_scheme)

        self.kP = np.array(power_linear_bins.centers())

        self.real_space_power_binner = PowerBinner.new(
            power_linear_bins, self.binning, "real", None)
        self.redshift_space_power_binner = PowerBinner.new(
            power_linear_bins, self.binning, "redshift", multipoles=[0, 2, 4])
        self.bispectrum_binner = BispectrumBinner.new(bisp_binning_scheme,
                                                      open_triangles=True)

        self.Ptemplates = []
        for pk in self.Pk.values():
            F = InterpolatedUnivariateSpline(self.kL, pk, k=3)
            self.Ptemplates.append(
                self.real_space_power_binner.bin_function(F, x_scale=self.kf))
        self.Ptemplates.append(np.ones(self.nbinsP))

        self.P0templates = []
        self.P2templates = []
        self.P4templates = []

        if self.window_convolution and self.input_dict["likelihood"]["cosmology"] == "fixed":
            self.P0templates, self.P2templates, self.P4templates = (
                self.theory_inst.P_ell_conv_fixed_cosmo(
                    self.window, self.kpW, self.z, self.Inputcosmo,
                    self.do_redshift_rescaling, self.PL, kgrid=self.kL,
                    growth_model=self.growth_model, IRres=self.IRres,
                    kind=self.IRresum_kind))
        else:
            for F0, F2, F4 in zip(self.P_ell_k[0].values(),
                                  self.P_ell_k[2].values(),
                                  self.P_ell_k[4].values()):
                iF0k = InterpolatedUnivariateSpline(self.kL, F0, k=3)
                iF2k = InterpolatedUnivariateSpline(self.kL, F2, k=3)
                iF4k = InterpolatedUnivariateSpline(self.kL, F4, k=3)

                iFkmu = lambda q, mu: iF0k(q)+(1.5*mu**2-0.5)*iF2k(q)+(35*mu**4-30*mu**2+3)/8.*iF4k(q)

                ieff0, ieff2, ieff4 = self.redshift_space_power_binner.bin_function(
                    iFkmu, x_scale=self.kf)
                self.P0templates.append(ieff0)
                self.P2templates.append(ieff2)
                self.P4templates.append(ieff4)

        self.N_T = len(self.bispectrum_binner.bins.bins)
        self.kB1E = np.array([t.sup for t in
                              self.bispectrum_binner.effective_triangles])*self.kf
        self.kB2E = np.array([t.med for t in
                              self.bispectrum_binner.effective_triangles])*self.kf
        self.kB3E = np.array([t.inf for t in
                              self.bispectrum_binner.effective_triangles])*self.kf
        self.NTk = self.bispectrum_binner.counts

        tri_bins = np.array([[b.bin1.center(), b.bin2.center(), b.bin3.center()]
                             for b in self.bispectrum_binner.bins.bins]).T
        self.kB1, self.kB2, self.kB3 = tri_bins

        real_avg_binner = PowerBinner.new(power_linear_bins, "average", "real")
        self.kPE = real_avg_binner.bin_function(lambda q: q, x_scale=self.kf)
        self.kPE2 = real_avg_binner.bin_function(lambda q: q**2, x_scale=self.kf)

        k2_0, k2_2, k2_4 = self.redshift_space_power_binner.bin_function(
            lambda q, mu: q**2, x_scale=self.kf)
        mu2k2_0, mu2k2_2, mu2k2_4 = self.redshift_space_power_binner.bin_function(
            lambda q, mu: q**2*mu**2, x_scale=self.kf)
        sn_0, sn_2, sn_4 = self.redshift_space_power_binner.bin_function(
            lambda q, mu: 1.+q*mu*0, x_scale=self.kf)

        if self.SNLeaking:
            self.sn_rsd_p0 = [k2_0, mu2k2_0, sn_0]
            self.sn_rsd_p2 = [k2_2, mu2k2_2, sn_2]
            self.sn_rsd_p4 = [k2_4, mu2k2_4, sn_4]
        else:
            self.sn_rsd_p0 = [k2_0, sn_0]
            self.sn_rsd_p2 = [mu2k2_2]
            self.sn_rsd_p4 = []

        for sn in self.sn_rsd_p0: self.P0templates.append(sn)
        for sn in self.sn_rsd_p2: self.P2templates.append(sn)
        for sn in self.sn_rsd_p4: self.P4templates.append(sn)

        if self.k1_ext is not None:
            self.K, self.F, self.G, self.S, self.dF, self.dG, self.dS, self.KK, self.dKK = \
                bispfunc.Bl_templates_k(self.k1_ext, self.k2_ext, self.k3_ext)
            self.Is0 = bispfunc.Bl_templates_angles(0, self.k1_ext, self.k2_ext, self.k3_ext)
            self.Is2 = bispfunc.Bl_templates_angles(2, self.k1_ext, self.k2_ext, self.k3_ext)
            self.Is4 = bispfunc.Bl_templates_angles(4, self.k1_ext, self.k2_ext, self.k3_ext)
        else:
            self.K, self.F, self.G, self.S, self.dF, self.dG, self.dS, self.KK, self.dKK = \
                bispfunc.Bl_templates_k(self.kB1E, self.kB2E, self.kB3E)
            self.Is0 = bispfunc.Bl_templates_angles(0, self.kB1E, self.kB2E, self.kB3E)
            self.Is2 = bispfunc.Bl_templates_angles(2, self.kB1E, self.kB2E, self.kB3E)
            self.Is4 = bispfunc.Bl_templates_angles(4, self.kB1E, self.kB2E, self.kB3E)

        if self.binning == 'Effective':
            self.Btemplates = self.Bggg_eff()
            if self.k1_ext is not None:
                self.B0templates, self.B2templates, self.B4templates = self.Blgg_eff(
                    self.z, self.do_redshift_rescaling, self.PL, self.k1_ext, self.k2_ext,
                    self.k3_ext, self.Is0, self.Is2, self.Is4, self.Inputcosmo,
                    K=self.K, F=self.F, G=self.G, S=self.S, dF=self.dF, dG=self.dG,
                    dS=self.dS, KK=self.KK, dKK=self.dKK, do_AP=self.do_AP, D=self.Dz)
            else:
                self.B0templates, self.B2templates, self.B4templates = self.Blgg_eff(
                    self.z, self.do_redshift_rescaling, self.PL, self.kB1E, self.kB2E,
                    self.kB3E, self.Is0, self.Is2, self.Is4, self.Inputcosmo,
                    K=self.K, F=self.F, G=self.G, S=self.S, dF=self.dF, dG=self.dG,
                    dS=self.dS, KK=self.KK, dKK=self.dKK, do_AP=self.do_AP, D=self.Dz)

        elif self.binning == 'Expansion':
            print("\033[1;31m[WARNING] \033[00m"+"Expansion binning implemented only for power spectrum. Bispectrum will be evaluated with the Effective method, or will be uploaded from input theory files.")
            self.Btemplates = self.Bggg_eff()
            if self.k1_ext is not None:
                self.B0templates, self.B2templates, self.B4templates = self.Blgg_eff(
                    self.z, self.do_redshift_rescaling, self.PL, self.k1_ext, self.k2_ext,
                    self.k3_ext, self.Is0, self.Is2, self.Is4, self.Inputcosmo,
                    K=self.K, F=self.F, G=self.G, S=self.S, dF=self.dF, dG=self.dG,
                    dS=self.dS, KK=self.KK, dKK=self.dKK, do_AP=self.do_AP, D=self.Dz)
            else:
                self.B0templates, self.B2templates, self.B4templates = self.Blgg_eff(
                    self.z, self.do_redshift_rescaling, self.PL, self.kB1E, self.kB2E,
                    self.kB3E, self.Is0, self.Is2, self.Is4, self.Inputcosmo,
                    K=self.K, F=self.F, G=self.G, S=self.S, dF=self.dF, dG=self.dG,
                    dS=self.dS, KK=self.KK, dKK=self.dKK, do_AP=self.do_AP, D=self.Dz)

        elif self.binning == 'Average':
            print("\033[1;31m[WARNING] \033[00m"+"Full bin-average implemented only for power spectrum. All others will be evaluated with the Effective method, or will be uploaded from input theory files.")
            self.Btemplates = self.Bggg_eff()
            if self.k1_ext is not None:
                self.B0templates, self.B2templates, self.B4templates = self.Blgg_eff(
                    self.z, self.do_redshift_rescaling, self.PL, self.k1_ext, self.k2_ext,
                    self.k3_ext, self.Is0, self.Is2, self.Is4, self.Inputcosmo,
                    K=self.K, F=self.F, G=self.G, S=self.S, dF=self.dF, dG=self.dG,
                    dS=self.dS, KK=self.KK, dKK=self.dKK, do_AP=self.do_AP, D=self.Dz)
            else:
                self.B0templates, self.B2templates, self.B4templates = self.Blgg_eff(
                    self.z, self.do_redshift_rescaling, self.PL, self.kB1E, self.kB2E,
                    self.kB3E, self.Is0, self.Is2, self.Is4, self.Inputcosmo,
                    K=self.K, F=self.F, G=self.G, S=self.S, dF=self.dF, dG=self.dG,
                    dS=self.dS, KK=self.KK, dKK=self.dKK, do_AP=self.do_AP, D=self.Dz)

        for k in self.InputTheory:
            if (self.InputTheory[k] is not None) & (self.binning == 'Average'):
                if k[0] == 'P':
                    ONES = np.ones((self.nbinsP,1))
                elif k[0] == 'B' and k[1] != 'A':
                    ONES = np.ones((self.N_T,1))

                if k == 'Pk':
                    self.Ptemplates  = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'Bk':
                    self.Btemplates  = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'P0':
                    self.P0templates = (np.array(read_csv(
                        self.InputTheory[k], sep=r"\s+", header=None))).T
                elif k == 'P2':
                    self.P2templates = (np.array(read_csv(
                        self.InputTheory[k], sep=r"\s+", header=None))).T
                elif k == 'P4':
                    self.P4templates = (np.array(read_csv(
                        self.InputTheory[k], sep=r"\s+", header=None))).T
                elif k == 'B0':
                    self.B0templates = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'B2':
                    self.B2templates = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'B4':
                    self.B4templates = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T

                print("\033[1;32m[info] \033[00m"+f"Theory files for {k} loaded")

            elif (self.InputTheory[k] is not None) & (self.binning == 'Expansion'):
                if k[0] == 'B' and k[1] != 'A':
                    ONES = np.ones((self.N_T,1))

                if k == 'Bk':
                    self.Btemplates  = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'B0':
                    self.B0templates = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'B2':
                    self.B2templates = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                elif k == 'B4':
                    self.B4templates = np.hstack((np.array(
                        read_csv(self.InputTheory[k], sep=r"\s+",
                                 header=None)),ONES)).T
                print("\033[1;32m[info] \033[00m"+f"Theory files for {k} loaded")

        PkTempl = OrderedDict(zip(self.Pktags+['1'], self.Ptemplates))
        P0Templ = OrderedDict(zip(self.Pltags,       self.P0templates))
        P2Templ = OrderedDict(zip(self.Pltags,       self.P2templates))
        P4Templ = OrderedDict(zip(self.Pltags,       self.P4templates))

        BkTempl = OrderedDict(zip(self.Bktags+['1'], self.Btemplates))
        B0Templ = OrderedDict(zip(self.Bltags+['1'], self.B0templates))
        B2Templ = OrderedDict(zip(self.Bltags,       self.B2templates))
        B4Templ = OrderedDict(zip(self.Bltags,       self.B4templates))

        self.P_ell_Templ = {'Pk': PkTempl, 'P0': P0Templ, 'P2': P2Templ,
                            'P4': P4Templ, 'PX': PkTempl, 'Pm': PkTempl}
        self.B_ell_Templ = {'Bk': BkTempl, 'B0': B0Templ, 'B2': B2Templ,
                            'B4': B4Templ}

#-------------------------------------------------------------------------------
# Try to upload data vectors and the covariance matrix

    def initialise_data(self):
        """Loads the data files and covariance

        Loads datafiles and covariance, and sets todo list for likelihood based
        on `input_dict['likelihood']['observables']`

        Notes
        -----
        This method does not cut the datafiles and covariance with k_max, to
        allow running different scale cuts without having to re-initialise the
        `Pbj` object.
        """
        self.Obs = self.input_dict['likelihood']['observables']
        print("\033[1;32m[info] \033[00m"+f"Observables: {self.Obs}")

        flat_obs = {v for sub in self.Obs
                    for v in (sub if isinstance(sub, (list, tuple, set)) else [sub])}
        if 'Pk' in flat_obs:
            self.do_preal = True
        if 'Bk' in flat_obs:
            self.do_breal = True
        if any(map(lambda v: v in flat_obs, ['P0', 'P2', 'P4', 'Q0'])):
            self.do_pell = True
        if any(map(lambda v: v in flat_obs, ['P0_BAO', 'P2_BAO', 'P4_BAO'])):
            self.do_pell_bao = True
        if any(map(lambda v: v in flat_obs, ['B0', 'B2', 'B4'])):
            self.do_bell = True
        if any(map(lambda v: v in flat_obs, ['alpha_par', 'alpha_perp',
                                             'alpha_iso', 'alpha_AP'])):
            self.do_alphas_bao = True
        if 'additional_bao' in self.input_dict:
            self.do_additional_bao = True

        self.covtype    = self.input_dict['covariance']['type']
        self.covfile    = self.input_dict['covariance']['file']
        if isinstance(self.covfile, list) and len(self.covfile)==1:
            self.covfile = self.covfile[0]

        print("\033[1;32m[info] \033[00m"+f"Using {self.covtype}")

        self.SN = self.input_dict['SN']
        if isinstance(self.SN, list) and len(self.SN)==1:
            self.SN = self.SN[0]

        if self.input_dict.get('PiConvention') == 'LSS':
            self.Twopi3 = (2.*np.pi)**3
        else:
            self.Twopi3 = 1.

        self.datafiles  = self.input_dict['data_files']
        self.NSets = self.input_dict['NSets'] if 'Nsets' in self.input_dict else 1
        self.MeanBool = self.input_dict['Mean'] if 'Mean' in self.input_dict else None

        # data
        MeanSets, self.NSets, self.DataDict = datahandler.load_data(
            self.datafiles, self.Obs, self.Twopi3, self.nbinsP, self.NSets, self.MeanBool)

        # Shot noise
        if isinstance(self.SN, float):
            self.Psn  = self.SN
            self.Psn2 = self.SN**2
            self.Psnarr  = np.full(self.NSets, self.Psn)
            self.Psn2arr = np.full(self.NSets, self.Psn2)

        elif isinstance(self.SN, list):
            if len(self.SN) != len(self.z_bins):
                raise ValueError("Number of redshift bins and SN values must match")
            self.Psn  = np.asarray(self.SN)
            self.Psn2 = np.asarray(self.SN)**2
            self.Psnarr  = np.repeat(self.Psn, self.NSets).reshape(len(self.Psn),
                                                                   self.NSets)
            self.Psn2arr = np.repeat(self.Psn2, self.NSets).reshape(len(self.Psn),
                                                                    self.NSets)

        elif isinstance(self.SN, str):
            SN = np.array(read_csv(self.SN, sep=r"\s+", header=None))
            SN2 = SN*SN
            self.Psn  = SN.mean()
            self.Psn2 = SN2.mean()
            self.Psnarr  = np.squeeze(SN)
            self.Psn2arr = np.squeeze(SN2)

        else:
            self.Psn  = 0
            self.Psn2 = 0
            self.Psnarr  = np.zeros(self.NSets)
            self.Psn2arr = np.zeros(self.NSets)

        self.Psn     *= self.Twopi3
        self.Psn2    *= self.Twopi3**2
        self.Psnarr  *= self.Twopi3
        self.Psn2arr *= self.Twopi3**2

        # covariance
        if isinstance(self.covfile, list):
            if len(self.covfile) != len(self.z_bins):
                raise ValueError("Number of redshift bins and covariance files must match")

        self.Cov = datahandler.load_covariance(self.covfile, self.Obs,
                                               self.Twopi3, self.nbinsP,
                                               self.N_T, MeanSets,
                                               covtype = self.covtype)
        if hasattr(self, 'do_additional_bao') and self.do_additional_bao:
            self.additional_bao = datahandler.load_additional_bao(
                self.input_dict['additional_bao'])
            # !!! split load data and update fiducials dict?

#-------------------------------------------------------------------------------
# Initialise likelihood

    def initialise_likelihood(self):
        """Initialise likelihood

        Initialises likelihood and priors (read from the `priors.yaml` file),
        and constructs a parameter dictionary with initial values. Also computes
        quantities for analytic marginalisation / Jeffreys priors
        """
        # Parameters
        if 'priors' in self.input_dict['likelihood']:
            self.prior_dictionary = parhandler.read_file(
                self.input_dict['likelihood']['priors'])
        else:
            self.prior_dictionary = parhandler.read_file("config_default/priors.yaml")

        # Create parameter dictionary and set initial points
        self.initial_param_dict = parhandler.parse_parameters(self.prior_dictionary,
                                                              self.Inputcosmo)

        # Update initial_param_dict with derived parameters
        self.compute_derived_parameters(
            self.prior_dictionary, 
            self.initial_param_dict,
            init=True
        )

        # Extract list of strings for varied parameters
        self.varied_params = [key for key, value in self.prior_dictionary.items()
                              if value.get('type') == 'varied']

        Likelihood.__init__(self, self.initial_param_dict)

        # Update prior_dictionary to include functions for the prior distributions
        priorhandler.add_prior_distribution_to_dict(self.varied_params,
                                                    self.prior_dictionary)

        self.alphas_dict = parhandler.construct_alphas_dict(self.do_AP)

        # Analytic marginalisation
        self.do_analytic_marg = self.input_dict['likelihood'].get('do_analytic_marg', False)
        self.do_jeffreys_priors = self.input_dict['likelihood'].get('do_jeffreys_priors', False)
        self.do_reparam = self.input_dict['likelihood'].get('do_reparam', False)

        if self.do_analytic_marg and self.do_jeffreys_priors:
            raise ValueError(f"Cannot do analytic marginalisation and Jeffreys priors at the same time!")

        if self.do_analytic_marg or self.do_jeffreys_priors:
            # Check which params are included, and priors were set correctly
            if self.input_dict['likelihood']['model'] == 'model_BAO_analytic_marg':
                marg_params_all = ['a00', 'a01', 'a02', 'a03', 'a04', 'a05',
                                   'a20', 'a21', 'a22', 'a23', 'a24', 'a25',
                                   'a40', 'a41', 'a42', 'a43', 'a44', 'a45']
            else:
                marg_params_all = ['bG3', 'c0', 'c2', 'c4', 'ck4', 'aP', 'e0k2', 'e2k2']
            
            self.index_marg_param = []
            for key in marg_params_all:
                # # This takes care of params in the list that are set to 0
                if key in self.initial_param_dict.keys() and self.prior_dictionary[key]['type'] in ('marg', 'jeffreys'):
                    self.index_marg_param.append(marg_params_all.index(key))

                    # This checks Gaussian priors have been imposed
                    if self.initial_param_dict[key]['prior'] != 'gaussian':
                        raise ValueError(f"Analytic marginalisation requires priors for '{marg_params_all}' to be 'gaussian'. Found: '{self.initial_param_dict[key]['prior']}'")

            self.marg_params = [marg_params_all[i] for i in self.index_marg_param]
            
            self.do_reparam = self.input_dict['likelihood'].get('do_reparam', False)
            if self.do_reparam:
                self.index_rescaled_params = []
                for key in self.marg_params:
                    if key in self.do_reparam['params']:
                        self.index_rescaled_params.append(self.marg_params.index(key))

                self.rescaled_params = [self.marg_params[i]
                                        for i in self.index_rescaled_params]
                if isinstance(self.do_reparam['funcs'], str):
                    self.rescaling_funcs = [self.do_reparam['funcs']]*len(self.rescaled_params)
                elif isinstance(self.do_reparam['funcs'], list):
                    if len(self.do_reparam['funcs']) != len(self.rescaled_params):
                        raise ValueError(
                            f"Reparameterisation length mismatch: "
                            f"{len(self.do_reparam['funcs'])} functions "
                            f"provided for {len(self.rescaled_params)} parameters")
                    self.rescaling_funcs=[]
                    for key in self.rescaled_params:
                        self.rescaling_funcs.append(
                            self.do_reparam['funcs'][self.do_reparam['params'].index(key)])
                self.rescaling_funcs_rewritten = [
                    parhandler.rewrite_derived_functions(func)
                    for func in self.rescaling_funcs
                ]
                
                # check if the priors are set in original values or already reparameterised
                if self.do_reparam['priors'] == 'original':
                    self.rescale_priors = True
                elif self.do_reparam['priors'] == 'reparam':
                    self.rescale_priors = False
                else:
                    raise ValueError(f"Invalid value for 'priors' in do_reparam: {self.do_reparam['priors']}")


            # Then compute quantities to be added to the chi2
            self.prior_vector = np.array(
                [self.initial_param_dict[key]['prior_params']['mean']
                 for key in self.marg_params])
            
            # compute the rescale vector to be multiplied to the prior_vector
            if hasattr(self, 'z_bins'):
                rescale_prior_vector = np.ones((len(self.marg_params), len(self.z_bins)))
            else:
                rescale_prior_vector = np.ones(len(self.marg_params))
            
            if self.do_reparam:
                if self.rescale_priors:
                    rescale_prior_vector = self.compute_rescale_marg_vector(
                        self.rescaling_funcs_rewritten,
                        self.initial_param_dict,
                        init=True,
                    )
            if self.do_reparam or self.do_analytic_marg or self.do_jeffreys_priors:
                self.prior_vector = self.prior_vector * rescale_prior_vector

                if self.prior_vector.ndim == 1:
                    prior_cov_mat = np.diag([
                        self.initial_param_dict[key]['prior_params']['sigma']**2
                        for key in self.marg_params]
                                            ) * rescale_prior_vector[:, None] * rescale_prior_vector[None, :]

                    self.prior_cov_inv = np.linalg.inv(prior_cov_mat)

                    self.prior_term_F0 = np.einsum(
                        'i,ij,j->', self.prior_vector, self.prior_cov_inv, self.prior_vector)
                    self.prior_term_F1i = np.einsum('ij,j->i',
                                                    self.prior_cov_inv, self.prior_vector)
                elif self.prior_vector.ndim == 2:
                    prior_cov_mat = [np.diag([
                        self.initial_param_dict[key]['prior_params']['sigma'][i]**2
                        for key in self.marg_params]
                                             ) * rescale_prior_vector[:, i, None] * rescale_prior_vector[None, :, i]
                                     for i in range(self.prior_vector.shape[1])]

                    self.prior_cov_inv = np.linalg.inv(prior_cov_mat)

                    self.prior_term_F0 = np.einsum('ik,kij,jk->k', self.prior_vector,
                                                   self.prior_cov_inv, self.prior_vector)
                    self.prior_term_F1i = np.einsum('kij,jk->ki',
                                                    self.prior_cov_inv, self.prior_vector)

        # Sampler
        self.sampler = self.input_dict['likelihood']['sampler']

        if self.sampler == 'emcee':
            self.CheckConvergence = self.input_dict['likelihood'].get(
                'check_convergence', False)

        # Likelihood function
        self.likeF    = self.input_dict['likelihood']['type']
        print("\033[1;32m[info] \033[00m"+f"Using {self.likeF} likelihood.")

        if self.likeF != 'Gaussian':
            self.Nmocks = self.input_dict['covariance']['NMocks']

        if self.likeF == 'Gaussian':
            self.lnlike = self.lnlike_gaussian
        elif self.likeF == 'Hartlap':
            self.lnlike = self.lnlike_hartlap
        elif self.likeF == 'Sellentin':
            self.lnlike = self.lnlike_sellentin
        else:
            raise NotImplementedError(f"Likelihood type {self.likeF} not supported.")


        # Automatic model likelihood setting - not implemented for pre-rec BAO
        if 'model' in self.input_dict['likelihood'] and isinstance(self.input_dict['likelihood']['model'], str):
            try:
                self.model_function = getattr(self,
                                              self.input_dict['likelihood']['model'], None)
            except:
                raise NotImplementedError(r"Likelihood model function not implemented.")
        else:
            if self.input_dict['likelihood']['cosmology'] == 'fixed':
                if self.do_AP or self.do_analytic_marg or self.do_jeffreys_priors:
                    self.model_function = self.model_fixed_cosmology_AP
                else:
                    self.model_function = self.model_fixed_cosmology

            elif self.input_dict['likelihood']['cosmology'] == 'varied':
                if self.do_analytic_marg or self.do_jeffreys_priors:
                    self.model_function = self.model_varied_cosmology_analytic_marg
                else:
                    self.model_function = self.model_varied_cosmology

            if hasattr(self, 'z_bins'):
                self.model_function = self.model_varied_cosmology_analytic_marg_multiz

        print("\033[1;32m[info] \033[00m"+\
              f"Using {self.model_function.__name__} as likelihood model function")


        self.Resume = self.input_dict['likelihood'].get('resume', False)

        if self.sampler == 'Metropolis':
            try:
                self.ParameterCov = self.input_dict['ParameterCov']
                self.ParCov = np.loadtxt(self.ParameterCov)
            except:
                self.ParCov = np.eye(len(self.varied_params))

        # Output files
        self.comment = self.input_dict.get('output', {}).get('comment', '')
        self.kmax_string = self.input_dict.get('output', {}).get('kmax_string', False)
        self.outfolder = self.input_dict.get('output', {}).get('folder', './')

        if not os.path.exists(self.outfolder):
            # The folder does not exist, so create it
            os.makedirs(self.outfolder)
            print(f"Folder '{self.outfolder}' was created.")

#-------------------------------------------------------------------------------

    def initialise_full(self):
        """Full initialization routine

        Calls three methods of the `Pbj` class: `initialise_grid`,
        `initialise_data`, `initialise_likelihood`.
        
        Further check consistency of the input configuration.
        """
        self.initialise_grid()
        self.initialise_data()
        self.initialise_likelihood()
        self.cross_check_consistency()
    
#-------------------------------------------------------------------------------

    def cross_check_consistency(self):
        """
        Cross check consistency of the input configuration.
        """
        if hasattr(self, "z_bins"):
            if self.model_function.__name__ not in ["model_varied_cosmology_analytic_marg_multiz", "model_alphas_postrec_multiz"]:
                raise ValueError(f"z_bins is not supported for {self.model_function.__name__}")
        if (self.do_analytic_marg or self.do_jeffreys_priors) and not "analytic_marg" in self.model_function.__name__:
            raise ValueError(f"do_analytic_marg or do_jeffreys_priors is turned on yet model function is {self.model_function.__name__}")
        if not (self.do_analytic_marg or self.do_jeffreys_priors) and "analytic_marg" in self.model_function.__name__:
            raise ValueError(f"do_analytic_marg or do_jeffreys_priors is turned off yet model function is {self.model_function.__name__}")
        if self.do_reparam and not self.do_analytic_marg:
            raise ValueError("do_reparam is only supported for analytic marginalisation")
        if ("w0" in self.varied_params or "wa" in self.varied_params) and not self.do_redshift_rescaling:
            raise ValueError("w0wa growth functions are computed wrt z=0, so do_redshift_rescaling must be true")
        flag = False
        for key in self.varied_params:
            if key in ["w0", "wa", "xi", "Omrc", "gamma", "fR0", "omegarc"]:
                flag = True
        if flag and self.growth_model == "lcdm":
            raise ValueError("lcdm model is used yet beyond LCDM parameters are varied")
        if self.growth_model in ["fr", "dgp"] and (self.do_bell or self.do_breal):
            raise ValueError(
                "Bispectrum likelihoods are not supported for growth_model "
                f"'{self.growth_model}' because modified growth can be scale dependent"
            )
