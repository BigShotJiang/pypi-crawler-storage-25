from .theory import Theory

__email__ = "chiara.moretti1989@gmail.com"
__version__ = "1.6.0"

