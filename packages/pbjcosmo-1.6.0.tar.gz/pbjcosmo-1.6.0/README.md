# 🪐 PBJcosmo: Power spectrum & Bispectrum Joint analysis
<!-- [![Pipeline](https://img.shields.io/gitlab/pipeline/chiaramorett/pbj/main?logo=gitlab&label=CI)](https://gitlab.com/chiaramoretti/pbj/pipelines)
[![Release](https://img.shields.io/gitlab/v/release/chiaramoretti/pbj?logo=gitlab)](https://gitlab.com/chiaramoretti/pbj/-/releases)-->

[![Release](https://img.shields.io/badge/version-v1.6.0-forestgreen?logo=gitlab)](https://gitlab.com/your-project/-/tags) <!--
--> [![Documentation](https://img.shields.io/badge/docs-mkdocs-blue?logo=markdown)](https://chiaramoretti.gitlab.io/pbj/) <!--
--> [![Contributors](https://img.shields.io/badge/contributors-19-purple?logo=gitlab)](https://chiaramoretti.gitlab.io/pbj/#contributors-)<!--
--> [![Coverage](https://img.shields.io/badge/coverage-33%-orange?logo=gitlab)](https://gitlab.com/chiaramoretti/pbj/-/pipelines)<!--
-->[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20053950.svg)](https://doi.org/10.5281/zenodo.20053950)


**`pbjcosmo`** is a Python package for the joint analysis of the galaxy
  power spectrum and bispectrum from spectroscopic galaxy clustering.

*Authors*: Chiara Moretti, Andrea Oddo

📄 [*Full documentation here*](https://chiaramoretti.gitlab.io/pbj/)

🆕 [*What's new?*](https://gitlab.com/chiaramoretti/pbj/-/blob/main/CHANGELOG.md?ref_type=heads)

## Installation and quickstart 🚀

You can install from PyPI: run

```pip install pbjcosmo[theory,likelihood]```

for the full installation, or, if you want a minimal installation that only covers
theoretical predictions for the power spectrum:

```pip install pbjcosmo```

See the [Installation
Guide](https://chiaramoretti.gitlab.io/pbj/install) for full
instructions on how to install, and the [Inference
quickstart](https://chiaramoretti.gitlab.io/pbj/inference_quickstart/)
for a brief introduction on how to run chains. More detailed examples
coming soon!

## Citing 📚

If you use `pbjcosmo` in your work, please cite the following paper:

- [Moretti, C. et al.,
  JCAP12(2023)025](https://iopscience.iop.org/article/10.1088/1475-7516/2023/12/025),
  *Modified gravity and massive neutrinos: constraints from the full
  shape analysis of BOSS galaxies and forecasts for Stage IV surveys*

For the original implementation and modelling for the real space bispectrum:

- [Oddo et al., 2020,
  JCAP03(2020)056](https://ui.adsabs.harvard.edu/abs/2020JCAP...03..056O/abstract),
  *Toward a robust inference method for the galaxy bispectrum:
  likelihood function and model selection*

For the real space power spectrum and bispectrum:

- [Oddo et al., 2021,
  JCAP11(2021)038](https://ui.adsabs.harvard.edu/abs/2021JCAP...11..038O/abstract),
  *Cosmological parameters from the likelihood analysis of the galaxy
  power spectrum and bispectrum in real space*

For the redshift space bispectrum:

- [Rizzo et al.,
  2022, JCAP01(2023)031](https://ui.adsabs.harvard.edu/abs/2022arXiv220413628R/abstract
  )*The halo bispectrum multipoles in redshift space*

The code has been validated and used to analyse both simulated and
real data already in a number of papers, a full list can be found in
[this ADS
library](https://ui.adsabs.harvard.edu/public-libraries/xQaO7O9EQ3uyqNileyLpLw)


## Contributing & Contact 🤝

Feel free to open an issue or a fork and then a pull request. For
questions, reach out to [Chiara
Moretti](mailto:chiara.moretti1989@gmail.com).

## Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/chiaramoretti"><img src="https://gitlab.com/uploads/-/system/user/avatar/5682313/avatar.png?s=100" width="100px;" alt="Chiara Moretti"/><br /><sub><b>Chiara Moretti</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Documentation">📖</a> <a href="#example-chiaramoretti" title="Examples">💡</a> <a href="#ideas-chiaramoretti" title="Ideas, Planning, & Feedback">🤔</a> <a href="#infra-chiaramoretti" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="#maintenance-chiaramoretti" title="Maintenance">🚧</a> <a href="#mentoring-chiaramoretti" title="Mentoring">🧑‍🏫</a> <a href="#platform-chiaramoretti" title="Packaging/porting to new platform">📦</a> <a href="#projectManagement-chiaramoretti" title="Project Management">📆</a> <a href="#promotion-chiaramoretti" title="Promotion">📣</a> <a href="#research-chiaramoretti" title="Research">🔬</a> <a href="https://gitlab.com/Chiara Moretti/pbj/merge_requests?scope=all&state=all&approver_usernames[]=chiaramoretti" title="Reviewed Pull Requests">👀</a> <a href="#talk-chiaramoretti" title="Talks">📢</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/ceoliveri"><img src="https://gitlab.com/uploads/-/system/user/avatar/22042797/avatar.png?s=100" width="100px;" alt="Cecilia Oliveri"/><br /><sub><b>Cecilia Oliveri</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-ceoliveri" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-ceoliveri" title="Promotion">📣</a> <a href="#research-ceoliveri" title="Research">🔬</a> <a href="#talk-ceoliveri" title="Talks">📢</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=ceoliveri" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/esarpa"><img src="https://secure.gravatar.com/avatar/190ccd9d88fdf6327008a86a6173ad7243def2898c9c24c21ffd641897f5950a?s=80&d=identicon?s=100" width="100px;" alt="Elena Sarpa"/><br /><sub><b>Elena Sarpa</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-esarpa" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-esarpa" title="Promotion">📣</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/esefusat"><img src="https://secure.gravatar.com/avatar/741dd8b559710c92545f90095c3e4829a616366658ce616a7422b8e341b624ed?s=80&d=identicon?s=100" width="100px;" alt="Emiliano Sefusatti"/><br /><sub><b>Emiliano Sefusatti</b></sub></a><br /><a href="#ideas-esefusat" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-esefusat" title="Promotion">📣</a> <a href="#talk-esefusat" title="Talks">📢</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/emilio.bellini"><img src="https://secure.gravatar.com/avatar/8804e25cfbd9aebfd279c1ceee12d8edb5497c0ab129adbb5f79919c3dca4709?s=80&d=identicon?s=100" width="100px;" alt="Emilio Bellini"/><br /><sub><b>Emilio Bellini</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-emilio.bellini" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-emilio.bellini" title="Promotion">📣</a> <a href="#research-emilio.bellini" title="Research">🔬</a> <a href="#talk-emilio.bellini" title="Talks">📢</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=emilio.bellini" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/fverd"><img src="https://secure.gravatar.com/avatar/b74a6987e8e2d58c9d691050189f5164ece896a1f956a703c66c4838ede68024?s=80&d=identicon?s=100" width="100px;" alt="Francesco Verdiani"/><br /><sub><b>Francesco Verdiani</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-fverd" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-fverd" title="Promotion">📣</a> <a href="#research-fverd" title="Research">🔬</a> <a href="#talk-fverd" title="Talks">📢</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/federico.montano"><img src="https://secure.gravatar.com/avatar/14776bad0325cfdc5bd36722f9296bf22cea6e4731a8cd2a9dfd14cd46c7d875?s=80&d=identicon?s=100" width="100px;" alt="Federico Montano"/><br /><sub><b>Federico Montano</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-federico.montano" title="Ideas, Planning, & Feedback">🤔</a> <a href="#research-federico.montano" title="Research">🔬</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/federico.rizzo"><img src="https://secure.gravatar.com/avatar/14d5b035cd7a67d3aee2a36b77d9a75d351cfcb809e2935e82813edc3a1096d6?s=80&d=identicon?s=100" width="100px;" alt="Federico Rizzo"/><br /><sub><b>Federico Rizzo</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#promotion-federico.rizzo" title="Promotion">📣</a> <a href="#research-federico.rizzo" title="Research">🔬</a> <a href="#data-federico.rizzo" title="Data">🔣</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/GiosueGambardella1998"><img src="https://secure.gravatar.com/avatar/430db604f62dfcc585e1ecb5bc1e14b656cb83a938e6b2bb0201534b33eb630c?s=80&d=identicon?s=100" width="100px;" alt="Giosuè Gambardella"/><br /><sub><b>Giosuè Gambardella</b></sub></a><br /><a href="#promotion-GiosueGambardella1998" title="Promotion">📣</a> <a href="#research-GiosueGambardella1998" title="Research">🔬</a> <a href="#talk-GiosueGambardella1998" title="Talks">📢</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/jacoposalvalaggio"><img src="https://gitlab.com/uploads/-/system/user/avatar/10623230/avatar.png?s=100" width="100px;" alt="Jacopo Salvalaggio"/><br /><sub><b>Jacopo Salvalaggio</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=jacoposalvalaggio" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/kpardede96"><img src="https://secure.gravatar.com/avatar/d75c82a35157e745fd56898314e01919bd8ee5eca676b63173fedf5f1ae0ddf3?s=80&d=identicon?s=100" width="100px;" alt="Kevin Pardede"/><br /><sub><b>Kevin Pardede</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-kpardede96" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-kpardede96" title="Promotion">📣</a> <a href="#research-kpardede96" title="Research">🔬</a> <a href="#talk-kpardede96" title="Talks">📢</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/MariaTsedrik"><img src="https://secure.gravatar.com/avatar/562b3d91f195b526cf5f5469e2c14299fadc5cb921b9c62a57d634c46293119e?s=80&d=identicon?s=100" width="100px;" alt="Maria Tsedrik"/><br /><sub><b>Maria Tsedrik</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-MariaTsedrik" title="Ideas, Planning, & Feedback">🤔</a> <a href="#mentoring-MariaTsedrik" title="Mentoring">🧑‍🏫</a> <a href="#promotion-MariaTsedrik" title="Promotion">📣</a> <a href="#research-MariaTsedrik" title="Research">🔬</a> <a href="#talk-MariaTsedrik" title="Talks">📢</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=MariaTsedrik" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/Yousryyy"><img src="https://secure.gravatar.com/avatar/dccaa6cd7c59457196b164ec4d8ca03913dbcede343ccb41873bba1994198adf?s=80&d=identicon?s=100" width="100px;" alt="Mohamed Elkhashab"/><br /><sub><b>Mohamed Elkhashab</b></sub></a><br /><a href="#ideas-Yousryyy" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-Yousryyy" title="Promotion">📣</a> <a href="#research-Yousryyy" title="Research">🔬</a> <a href="#talk-Yousryyy" title="Talks">📢</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/pcarrilho"><img src="https://secure.gravatar.com/avatar/74eb286948240a5d6849bf609248eb0f38ae9df76ab23b178929f8042bb5249a?s=80&d=identicon?s=100" width="100px;" alt="Pedro Carrilho"/><br /><sub><b>Pedro Carrilho</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-pcarrilho" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-pcarrilho" title="Promotion">📣</a> <a href="#research-pcarrilho" title="Research">🔬</a> <a href="#talk-pcarrilho" title="Talks">📢</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=pcarrilho" title="Bug reports">🐛</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/sujeong-lee"><img src="https://secure.gravatar.com/avatar/502ccd6e96ebc2b8d625b627f1c150bb186279a031e7fdb54be7936016f32658?s=80&d=identicon?s=100" width="100px;" alt="Sujeong Lee"/><br /><sub><b>Sujeong Lee</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-sujeong-lee" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-sujeong-lee" title="Promotion">📣</a> <a href="#research-sujeong-lee" title="Research">🔬</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=sujeong-lee" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/matildebs"><img src="https://secure.gravatar.com/avatar/76e01baf26278aa27b97eab2bd250cbed58d786eac879b372b7cb8f708d4a0b9?s=80&d=identicon?s=100" width="100px;" alt="matildebs"/><br /><sub><b>matildebs</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="#ideas-matildebs" title="Ideas, Planning, & Feedback">🤔</a> <a href="#promotion-matildebs" title="Promotion">📣</a> <a href="#research-matildebs" title="Research">🔬</a> <a href="#talk-matildebs" title="Talks">📢</a> <a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=matildebs" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/ztchenustc"><img src="https://secure.gravatar.com/avatar/f7a4e34ddee1a5b45ab8d13dcb04fee77c6b520a1320fc3d09de7c40e02cdc31?s=80&d=identicon?s=100" width="100px;" alt="Zhaoting Chen"/><br /><sub><b>Zhaoting Chen</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Documentation">📖</a> <a href="#research-ztchenustc" title="Research">🔬</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/Asser_Elhegawy"><img src="https://gitlab.com/uploads/-/system/user/avatar/31076008/avatar.png?s=100" width="100px;" alt="Asser Elhegawy"/><br /><sub><b>Asser Elhegawy</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/issues?author_username=Asser_Elhegawy" title="Bug reports">🐛</a></td>
      <td align="center" valign="top" width="14.28%"><a href="https://gitlab.com/nebblub"><img src="https://secure.gravatar.com/avatar/5bf6784c13b20208d30248fb733e68a5cfba061cebfd9267ff21faca34a2fe3b?s=80&d=identicon?s=100" width="100px;" alt="nebblu"/><br /><sub><b>nebblu</b></sub></a><br /><a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Code">💻</a> <a href="https://gitlab.com/Chiara Moretti/pbj/commits/master" title="Documentation">📖</a> <a href="#research-nebblub" title="Research">🔬</a></td>
    </tr>
  </tbody>
  <tfoot>
    <tr>
      <td align="center" size="13px" colspan="7">
        <img src="https://raw.githubusercontent.com/all-contributors/all-contributors-cli/1b8533af435da9854653492b1327a23a4dbd0a10/assets/logo-small.svg">
          <a href="https://all-contributors.js.org/docs/en/bot/usage">Add your contributions</a>
        </img>
      </td>
    </tr>
  </tfoot>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!
