"""
simplemcp/kit_manager.py — Kit install, remove, and metadata parsing
"""

import ast
import json
import shutil
import subprocess
import sys
from pathlib import Path


# ── Metadata parsing ──────────────────────────────────────────────────────────

def parse_kit_metadata(kit_path: Path) -> dict:
    """
    Parse a kit file's AST and extract module-level metadata:
      kit_name        = "Human Readable Name"
      kit_description = "What this kit does."
      requirements    = ["package-a", "package-b"]
      config          = {"VAR": "default_value", ...}

    Falls back to filename-derived defaults for any missing fields.
    """
    stem = kit_path.stem
    meta = {
        "kit_name": stem,
        "kit_description": "",
        "requirements": [],
        "config": {},
    }

    try:
        tree = ast.parse(kit_path.read_text(encoding="utf-8"))
    except Exception:
        return meta

    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue
            key = target.id
            if key == "kit_name" and isinstance(node.value, ast.Constant):
                meta["kit_name"] = node.value.value
            elif key == "kit_description" and isinstance(node.value, ast.Constant):
                meta["kit_description"] = node.value.value
            elif key == "requirements" and isinstance(node.value, ast.List):
                meta["requirements"] = [
                    elt.value
                    for elt in node.value.elts
                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                ]
            elif key == "config" and isinstance(node.value, ast.Dict):
                # Extract {str: constant} pairs as the default config schema
                parsed_config = {}
                for k, v in zip(node.value.keys, node.value.values):
                    if isinstance(k, ast.Constant) and isinstance(v, ast.Constant):
                        parsed_config[k.value] = v.value
                meta["config"] = parsed_config

    return meta


# ── Install / remove ──────────────────────────────────────────────────────────

def install_kit(kit_path_str: str, config: dict, kits_dir: Path) -> str:
    """
    Copy a kit file into the managed kits directory and register it in config.
    Returns the kit's registered name (stem of the filename).
    If the running container exists, installs any new requirements into it.
    """
    from simplemcp import config as cfg_module

    kit_path = Path(kit_path_str).resolve()
    if not kit_path.exists():
        print(f"[simplemcp] File not found: {kit_path}")
        sys.exit(1)
    if not kit_path.suffix == ".py":
        print(f"[simplemcp] Kit must be a .py file: {kit_path}")
        sys.exit(1)

    meta = parse_kit_metadata(kit_path)
    kit_stem = kit_path.stem

    dest = kits_dir / kit_path.name
    shutil.copy2(kit_path, dest)

    config["kits"][kit_stem] = {
        "kit_name": meta["kit_name"],
        "kit_description": meta["kit_description"],
        "enabled": True,
    }

    # Write config defaults — only set keys not already saved (preserve user values)
    if meta["config"]:
        existing = cfg_module.load_kit_config(kit_stem)
        merged = {**meta["config"], **existing}  # defaults under, user values on top
        cfg_module.save_kit_config(kit_stem, merged)
        print(f"[simplemcp] Config written: {list(meta['config'].keys())}")

    print(f"[simplemcp] Installed kit '{meta['kit_name']}' ({kit_stem})")

    # If a container is running, install requirements into it immediately
    if meta["requirements"] and config.get("container_id"):
        _install_requirements_in_container(config["container_id"], meta["requirements"])

    # Hot-reload the kit into the running server so tools are live immediately
    if config.get("container_id"):
        _reload_kit_in_server(kit_stem)

    return kit_stem


def remove_kit(kit_name: str, config: dict, kits_dir: Path):
    """Remove a kit from the managed kits directory and config."""
    from simplemcp import config as cfg_module

    kit_file = kits_dir / f"{kit_name}.py"
    if not kit_file.exists():
        print(f"[simplemcp] Kit '{kit_name}' not found.")
        sys.exit(1)

    kit_file.unlink()
    config["kits"].pop(kit_name, None)
    config["ports"].pop(kit_name, None)

    # Remove kit config directory
    kit_cfg_path = cfg_module.kit_config_path(kit_name).parent
    if kit_cfg_path.exists():
        shutil.rmtree(kit_cfg_path, ignore_errors=True)

    print(f"[simplemcp] Removed kit '{kit_name}'.")


# ── Runtime dependency install ────────────────────────────────────────────────

def _install_requirements_in_container(container_id: str, requirements: list[str]):
    """Install packages into a running container via uv pip."""
    import docker as docker_sdk
    client = docker_sdk.from_env()
    try:
        container = client.containers.get(container_id)
        pkgs = " ".join(requirements)
        print(f"[simplemcp] Installing kit dependencies: {pkgs}")
        exit_code, output = container.exec_run(
            f"uv pip install --system {pkgs}",
            stream=True,
        )
        for chunk in output:
            print(chunk.decode(), end="", flush=True)
    except Exception as e:
        print(f"[simplemcp] Warning: could not install dependencies into container: {e}")


def _reload_kit_in_server(kit_stem: str):
    """
    Tell the running SimpleMCP server to hot-reload a kit module so its
    @tool decorators fire immediately — no restart needed.
    """
    import urllib.request
    import urllib.error

    from .docker_manager import BASE_PORT

    url = f"http://localhost:{BASE_PORT}/reload_kit"
    body = json.dumps({"kit_stem": kit_stem}).encode()
    req = urllib.request.Request(
        url, data=body, headers={"Content-Type": "application/json"}, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        registered = data.get("tools_registered", [])
        print(f"[simplemcp] Hot-reloaded '{kit_stem}': {len(registered)} tool(s) registered "
              f"({', '.join(registered) or 'none'})")
    except urllib.error.URLError as e:
        print(f"[simplemcp] Warning: could not hot-reload kit (server may need a restart): {e}")
