import ast
import sys
import json
import asyncio
import os
import importlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from utils import get_tools, get_tools_for_kit, extract_parameters, build_tool_schema, TOOLS

_executor = ThreadPoolExecutor()

KIT_CONFIGS_DIR = Path("/app/kit_configs")

# Auto-discover all kits
import kits  # noqa: F401

# Mutate each kit module's `config` dict with saved values from the mounted volume.
# This replaces the need for os.getenv() in kit code entirely.
def _apply_kit_configs():
    import sys as _sys
    for mod_name, mod in list(_sys.modules.items()):
        if not mod_name.startswith("kits."):
            continue
        kit_stem = mod_name.split(".", 1)[1]
        if not hasattr(mod, "config") or not isinstance(mod.config, dict):
            continue
        config_path = KIT_CONFIGS_DIR / kit_stem / "config.json"
        if not config_path.exists():
            continue
        try:
            saved = json.loads(config_path.read_text(encoding="utf-8"))
            mod.config.update(saved)
        except Exception as e:
            print(f"[server] Warning: could not load config for '{kit_stem}': {e}", flush=True)

_apply_kit_configs()

app = FastAPI(title="SimpleMCP Server")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

KITS_DIR = Path("/app/kits")


# ── Kit metadata helpers ──────────────────────────────────────────────────────

def _parse_kit_meta(kit_path: Path) -> dict:
    meta = {
        "kit_name": kit_path.stem,
        "kit_description": "",
        "filename": kit_path.name,
        "enabled": True,
    }
    try:
        tree = ast.parse(kit_path.read_text(encoding="utf-8"))
    except Exception:
        return meta

    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if not isinstance(target, ast.Name):
                continue
            if target.id == "kit_name" and isinstance(node.value, ast.Constant):
                meta["kit_name"] = node.value.value
            elif target.id == "kit_description" and isinstance(node.value, ast.Constant):
                meta["kit_description"] = node.value.value

    return meta


def _all_kit_metas() -> list[dict]:
    metas = []
    if not KITS_DIR.exists():
        return metas
    for kit_file in sorted(KITS_DIR.glob("*.py")):
        if kit_file.name.startswith("_"):
            continue
        metas.append(_parse_kit_meta(kit_file))
    return metas


def _kit_stem_for_name(kit_name: str) -> str | None:
    if not KITS_DIR.exists():
        return None
    for kit_file in KITS_DIR.glob("*.py"):
        if kit_file.name.startswith("_"):
            continue
        meta = _parse_kit_meta(kit_file)
        if meta["kit_name"] == kit_name:
            return kit_file.stem
    return None


# ── SimpleMCP protocol endpoints ──────────────────────────────────────────────

@app.get("/list_kits")
def list_kits():
    """
    Return the list of installed kit_name strings.

    Response: { "kits": ["Gotify", "Web Kit V2", ...] }
    """
    return {"kits": [m["kit_name"] for m in _all_kit_metas()]}


@app.post("/inspect_kit")
def inspect_kit(req: dict):
    """
    Return metadata for a single kit by kit_name.

    Request:  { "kit": "Gotify" }
    Response: { "kit_name", "kit_description", "filename", "enabled" }
    """
    kit_name = req.get("kit")
    if not kit_name:
        return JSONResponse({"error": "Missing 'kit' field"}, status_code=400)

    for meta in _all_kit_metas():
        if meta["kit_name"] == kit_name:
            return meta

    return JSONResponse({"error": f"Kit '{kit_name}' not found"}, status_code=404)


@app.post("/list_tools_in_kit")
def list_tools_in_kit(req: dict):
    """
    Return the full tool schema list for a kit.

    Request:  { "kit": "Gotify" }
    Response: { "kit": "Gotify", "tools": [ { name, description, parameters }, ... ] }
    """
    kit_name = req.get("kit")
    if not kit_name:
        return JSONResponse({"error": "Missing 'kit' field"}, status_code=400)

    stem = _kit_stem_for_name(kit_name)
    if stem is None:
        return JSONResponse({"error": f"Kit '{kit_name}' not found"}, status_code=404)

    kit_tools = get_tools_for_kit(stem)
    return {
        "kit": kit_name,
        "tools": [build_tool_schema(name, func) for name, func in kit_tools.items()],
    }


@app.post("/reload_kit")
def reload_kit(req: dict):
    """
    Dynamically import (or re-import) a kit module so its @tool decorators
    fire and register tools without restarting the server.

    Request:  { "kit_stem": "gotify_kit" }
              OR { "kit": "Gotify" }
    Response: { "kit_stem": "gotify_kit", "tools_registered": ["gotify_send", ...] }
    """
    stem = req.get("kit_stem")
    if not stem:
        kit_name = req.get("kit")
        if kit_name:
            stem = _kit_stem_for_name(kit_name)
    if not stem:
        return JSONResponse({"error": "Provide 'kit_stem' or 'kit' field"}, status_code=400)

    module_name = f"kits.{stem}"

    stale = [name for name, func in list(TOOLS.items())
             if getattr(func, "_kit", None) == stem]
    for name in stale:
        TOOLS.pop(name, None)

    try:
        if module_name in sys.modules:
            mod = sys.modules[module_name]
            importlib.reload(mod)
        else:
            importlib.import_module(module_name)
    except Exception as exc:
        return JSONResponse({"error": f"Failed to import {module_name}: {exc}"}, status_code=500)

    # Re-apply saved config values to the freshly reloaded module
    _apply_kit_configs()

    registered = list(get_tools_for_kit(stem).keys())
    return {"kit_stem": stem, "tools_registered": registered}


@app.post("/inspect_tool")
def inspect_tool(req: dict):
    """
    Return the schema for a single tool by name.

    Request:  { "tool": "gotify_send" }
    Response: { name, description, parameters, kit }
    """
    tool_name = req.get("tool")
    if not tool_name:
        return JSONResponse({"error": "Missing 'tool' field"}, status_code=400)

    tools = get_tools()
    if tool_name not in tools:
        return JSONResponse({"error": f"Tool '{tool_name}' not found"}, status_code=404)

    func = tools[tool_name]
    schema = build_tool_schema(tool_name, func)
    schema["kit"] = getattr(func, "_kit", None)
    return schema


@app.post("/run_tool")
async def run_tool(req: dict):
    """
    Execute a tool by name with JSON arguments.

    Request:  { "tool": "gotify_send", "arguments": {...} }
    Response: { "result": ... } or { "error": ... }
    """
    name = req.get("tool")
    args = req.get("arguments", {})

    tools = get_tools()
    if name not in tools:
        return {"error": f"Tool '{name}' not found"}

    func = tools[name]
    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(_executor, lambda: func(**args))
        return {"result": result}
    except Exception as e:
        return {"error": f"{type(e).__name__}: {e}"}


# ── MCP HTTP endpoint (always active) ────────────────────────────────────────

def _mcp_tool_schema(name: str, func) -> dict:
    return {
        "name": name,
        "description": func.__doc__ or "",
        "inputSchema": extract_parameters(func),
    }


def _sse_message(obj: dict) -> str:
    return f"data: {json.dumps(obj)}\n\n"


@app.get("/mcp")
async def mcp_sse_stream(request: Request):
    """SSE keepalive stream for MCP clients."""
    async def event_stream():
        while True:
            if await request.is_disconnected():
                break
            yield ": keepalive\n\n"
            await asyncio.sleep(15)
    return StreamingResponse(event_stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})


@app.post("/mcp")
async def mcp_jsonrpc(request: Request):
    """
    MCP JSON-RPC 2.0 dispatch. Accepts initialize, tools/list, tools/call.
    Responds as SSE or JSON depending on client Accept header.

    Optionally scope to a single kit via X-SimpleMCP-Kit header (kit stem).
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(
            {"jsonrpc": "2.0", "id": None,
             "error": {"code": -32700, "message": "Parse error"}},
            status_code=400,
        )

    req_id = body.get("id")
    method = body.get("method", "")
    params = body.get("params") or {}
    accept = request.headers.get("accept", "")
    wants_sse = "text/event-stream" in accept

    # Scope to a single kit — prefer SIMPLEMCP_KIT env var (set when this
    # process was spawned per-kit), fall back to X-SimpleMCP-Kit header
    # (used by the stdio shim when talking to the main server on 8467).
    _env_kit = os.environ.get("SIMPLEMCP_KIT")
    kit_stem = _env_kit or request.headers.get("X-SimpleMCP-Kit")

    def _tools() -> dict:
        if kit_stem:
            return get_tools_for_kit(kit_stem)
        return get_tools()

    def make_response(result: dict):
        payload = {"jsonrpc": "2.0", "id": req_id, "result": result}
        if wants_sse:
            return StreamingResponse(iter([_sse_message(payload)]),
                                     media_type="text/event-stream",
                                     headers={"Cache-Control": "no-cache",
                                              "X-Accel-Buffering": "no"})
        return JSONResponse(payload)

    def make_error(code: int, message: str):
        payload = {"jsonrpc": "2.0", "id": req_id,
                   "error": {"code": code, "message": message}}
        if wants_sse:
            return StreamingResponse(iter([_sse_message(payload)]),
                                     media_type="text/event-stream",
                                     headers={"Cache-Control": "no-cache",
                                              "X-Accel-Buffering": "no"})
        return JSONResponse(payload)

    if method.startswith("notifications/"):
        return JSONResponse(status_code=202, content=None)

    if method == "initialize":
        return make_response({
            "protocolVersion": "2025-03-26",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "SimpleMCP", "version": "2.0.0"},
        })

    elif method == "tools/list":
        tools = _tools()
        return make_response({
            "tools": [_mcp_tool_schema(n, f) for n, f in tools.items()]
        })

    elif method == "tools/call":
        tool_name = params.get("name")
        arguments = params.get("arguments") or {}
        tools = _tools()

        if tool_name not in tools:
            return make_error(-32601, f"Tool '{tool_name}' not found")

        try:
            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                _executor, lambda: tools[tool_name](**arguments)
            )
            if not isinstance(result, str):
                result = json.dumps(result, ensure_ascii=False)
            return make_response({
                "content": [{"type": "text", "text": result}],
                "isError": False,
            })
        except Exception as e:
            return make_response({
                "content": [{"type": "text", "text": f"{type(e).__name__}: {e}"}],
                "isError": True,
            })

    else:
        return make_error(-32601, f"Method not found: {method}")
