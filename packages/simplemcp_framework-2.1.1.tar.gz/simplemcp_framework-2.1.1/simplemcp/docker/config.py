# Retained for import compatibility — no configuration needed.
# The server now always exposes both SimpleMCP and MCP protocols.
