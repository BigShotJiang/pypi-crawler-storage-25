"""
bootstrap.py — SimpleMCP V2 container startup script

Runs before the server on every container start. Scans all kits in /app/kits
for a module-level `requirements = [...]` assignment, then installs any
declared packages that aren't already importable via uv pip.

Execs the real server process when done so it becomes PID 1.
"""

import ast
import importlib.util
import os
import subprocess
import sys
from pathlib import Path

KITS_DIR = Path("/app/kits")
LIB_DIR = Path("/app/lib")


def parse_kit_requirements(kit_path: Path) -> list[str]:
    """
    Parse a kit file's AST and extract the module-level `requirements` list.
    Returns an empty list if absent or unparseable.
    """
    try:
        tree = ast.parse(kit_path.read_text(encoding="utf-8"))
    except Exception:
        return []

    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Assign)
            and any(
                isinstance(t, ast.Name) and t.id == "requirements"
                for t in node.targets
            )
            and isinstance(node.value, ast.List)
        ):
            return [
                elt.value
                for elt in node.value.elts
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
            ]
    return []


def is_importable(package: str) -> bool:
    """Check if a package is already importable inside the container."""
    # Strip version specifiers (e.g. "requests>=2.0" → "requests")
    name = package.split(">=")[0].split("<=")[0].split("==")[0].split("!=")[0].strip()
    # Normalize: PyPI uses hyphens, import names use underscores
    name = name.replace("-", "_")
    return importlib.util.find_spec(name) is not None


def install_packages(packages: list[str]):
    """Install packages via uv pip into /app/lib. Exits on failure."""
    LIB_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[bootstrap] Installing: {', '.join(packages)}", flush=True)
    result = subprocess.run(
        ["uv", "pip", "install", "--system", "--target", str(LIB_DIR)] + packages,
    )
    if result.returncode != 0:
        print(f"[bootstrap] ERROR: Failed to install {', '.join(packages)}. Aborting.", flush=True)
        sys.exit(1)
    print("[bootstrap] Done.", flush=True)


def main():
    if not KITS_DIR.exists():
        print("[bootstrap] No kits directory found, skipping dependency check.", flush=True)
    else:
        to_install = []
        for kit_file in sorted(KITS_DIR.glob("*.py")):
            if kit_file.name.startswith("_"):
                continue
            for pkg in parse_kit_requirements(kit_file):
                if not is_importable(pkg) and pkg not in to_install:
                    to_install.append(pkg)

        if to_install:
            install_packages(to_install)
        else:
            print("[bootstrap] All kit dependencies satisfied.", flush=True)

    # Start socat CDP proxy: forwards localhost:9222 → host.docker.internal:9222
    # This allows the Playwright kit to connect to Chrome on the host via
    # localhost:9222 inside the container, bypassing Chrome's host header
    # validation (which rejects non-localhost hostnames).
    _start_cdp_proxy()

    # Exec the server process passed as arguments so it becomes PID 1.
    if len(sys.argv) > 1:
        os.execvp(sys.argv[1], sys.argv[1:])
    else:
        print("[bootstrap] No server command provided.", file=sys.stderr)
        sys.exit(1)


def _start_cdp_proxy():
    """
    Launch a background socat process that forwards TCP localhost:9222
    to host.docker.internal:9222 so the Playwright kit can reach the host
    Chrome CDP endpoint without triggering Chrome's host header check.

    Silently skips if socat is not installed or host.docker.internal is not
    resolvable — the kit will surface a clear error on first use if Chrome
    is not reachable.
    """
    import shutil

    if not shutil.which("socat"):
        print("[bootstrap] socat not found — CDP proxy skipped.", flush=True)
        return

    try:
        subprocess.Popen(
            [
                "socat",
                "TCP-LISTEN:9222,fork,reuseaddr,nodelay",
                "TCP:host.docker.internal:9222,nodelay",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        print("[bootstrap] CDP proxy started (localhost:9222 → host.docker.internal:9222).", flush=True)
    except Exception as e:
        print(f"[bootstrap] CDP proxy failed to start: {e}", flush=True)


if __name__ == "__main__":
    main()
