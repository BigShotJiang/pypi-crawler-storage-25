import inspect

# Global tool registry: {name: function}
TOOLS = {}


def tool(func):
    """
    Decorator to register a function as a callable tool.
    Stamps func._kit with the module stem (e.g. "web_kit") so the
    server can group tools by kit without parsing filenames at runtime.
    """
    # func.__module__ is e.g. "kits.web_kit" — take the last segment
    func._kit = func.__module__.split(".")[-1]
    TOOLS[func.__name__] = func
    return func


def get_tools() -> dict:
    """Return the raw registry dict (name -> function)."""
    return TOOLS


def get_tools_for_kit(kit_stem: str) -> dict:
    """Return only tools belonging to the named kit stem."""
    return {name: func for name, func in TOOLS.items()
            if getattr(func, "_kit", None) == kit_stem}


def extract_parameters(func) -> dict:
    """
    Turn Python type hints into JSON Schema.
    Handles str, int, float, bool; everything else treated as string.
    """
    sig = inspect.signature(func)
    properties = {}
    required = []

    for name, param in sig.parameters.items():
        annotation = param.annotation

        if annotation == str:
            properties[name] = {"type": "string"}
        elif annotation == int:
            properties[name] = {"type": "integer"}
        elif annotation == float:
            properties[name] = {"type": "number"}
        elif annotation == bool:
            properties[name] = {"type": "boolean"}
        else:
            properties[name] = {"type": "string"}

        if param.default is inspect._empty:
            required.append(name)

    return {
        "type": "object",
        "properties": properties,
        "required": required,
    }


def build_tool_schema(name: str, func) -> dict:
    """Return the full schema dict for a single tool."""
    return {
        "name": name,
        "description": func.__doc__ or "",
        "parameters": extract_parameters(func),
    }
