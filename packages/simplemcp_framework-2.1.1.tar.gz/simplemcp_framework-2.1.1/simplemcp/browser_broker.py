"""
simplemcp/browser_broker.py -- Chrome CDP broker

Minimal HTTP server on the host (port 9223). The SimpleMCP container calls
GET /start to launch Chrome if it isn't already running. The broker fires
Chrome and returns immediately -- it does not wait for Chrome to be ready.
The kit is responsible for polling until CDP is reachable.

Flow:
  kit (container) -> GET http://host.docker.internal:9223/start
  -> broker: socket check (1ms)
  -> if not running: Popen Chrome, return immediately
  -> {"ok": true}
  kit polls localhost:9222/json/version until Chrome responds (~1-3s)
"""

import json
import shutil
import socket
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

BROKER_PORT = 9223
CDP_PORT    = 9222


def _cdp_running() -> bool:
    """Direct socket check -- no subprocess, no CLI, ~1ms."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex(("localhost", CDP_PORT)) == 0


def _find_chrome() -> str | None:
    if sys.platform == "win32":
        import os
        candidates = [
            Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Google" / "Chrome" / "Application" / "chrome.exe",
            Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")) / "Google" / "Chrome" / "Application" / "chrome.exe",
            Path(os.environ.get("LOCALAPPDATA", "")) / "Google" / "Chrome" / "Application" / "chrome.exe",
        ]
        for c in candidates:
            if c.exists():
                return str(c)
    elif sys.platform == "darwin":
        for c in [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]:
            if Path(c).exists():
                return c
    else:
        for name in ("google-chrome", "google-chrome-stable", "chromium-browser", "chromium"):
            path = shutil.which(name)
            if path:
                return path
    return None


def _launch_chrome():
    """Popen Chrome with CDP enabled. Returns immediately -- no polling."""
    chrome = _find_chrome()
    if not chrome:
        print("[browser-broker] Could not find Chrome.", flush=True)
        return

    user_data_dir = str(Path.home() / ".simplemcp" / "chrome-profile")
    print(f"[browser-broker] Launching Chrome on port {CDP_PORT}...", flush=True)
    subprocess.Popen(
        [
            chrome,
            f"--remote-debugging-port={CDP_PORT}",
            "--remote-debugging-address=0.0.0.0",
            "--remote-allow-origins=*",
            f"--user-data-dir={user_data_dir}",
            "--no-first-run",
            "--no-default-browser-check",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


class BrokerHandler(BaseHTTPRequestHandler):

    def log_message(self, format, *args):
        pass  # Silence default HTTP logging

    def do_GET(self):
        if self.path == "/start":
            if not _cdp_running():
                _launch_chrome()
            self._respond(200, {"ok": True})

        elif self.path == "/status":
            self._respond(200, {"running": _cdp_running()})

        else:
            self._respond(404, {"error": "Not found"})

    def _respond(self, status: int, body: dict):
        payload = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)


def run(port: int = BROKER_PORT):
    server = HTTPServer(("0.0.0.0", port), BrokerHandler)
    print(f"[browser-broker] Listening on port {port}", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    run()
