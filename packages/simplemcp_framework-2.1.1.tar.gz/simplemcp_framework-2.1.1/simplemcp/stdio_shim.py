"""
simplemcp/stdio_shim.py — stdio ↔ SimpleMCP HTTP bridge

Translates MCP JSON-RPC messages from stdin to the already-running
SimpleMCP container's HTTP API, and writes responses to stdout.

No Docker involvement — the container must already be running via
`simplemcp start`. The shim is a thin stateless bridge; all tool
execution and kit management stays in the container.

stdout is the JSON-RPC channel. All diagnostic output goes to stderr.
"""

import json
import os
import sys
import threading
import urllib.request
import urllib.error


def _http_get(url: str) -> dict:
    with urllib.request.urlopen(url, timeout=30) as resp:
        return json.loads(resp.read())


def _http_post(url: str, payload: dict, headers: dict | None = None) -> dict:
    data = json.dumps(payload).encode()
    h = {"Content-Type": "application/json"}
    if headers:
        h.update(headers)
    req = urllib.request.Request(url, data=data, headers=h)
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())


def run_shim(port: int, kit_stem: str | None = None):
    """
    Bridge JSON-RPC from stdin to the SimpleMCP HTTP server on the given port.
    Blocks until stdin closes.

    kit_stem: if set, scopes tools to a single kit via X-SimpleMCP-Kit header.
    """
    # Grab real stdout before redirecting — it's the JSON-RPC channel.
    _stdout = os.fdopen(os.dup(sys.stdout.fileno()), "w", buffering=1)
    sys.stdout = sys.stderr  # all print() goes to stderr from here on

    base_url = f"http://localhost:{port}"

    # Extra headers to pass on every /mcp POST — scopes tools to one kit if set.
    _kit_headers = {"X-SimpleMCP-Kit": kit_stem} if kit_stem else {}

    def _write(obj: dict):
        _stdout.write(json.dumps(obj) + "\n")
        _stdout.flush()

    def _check_server(retries: int = 5, delay: float = 1.0) -> bool:
        """Verify the server is reachable before accepting messages. Retries on failure."""
        import time
        for attempt in range(1, retries + 1):
            try:
                _http_get(f"{base_url}/list_kits")
                return True
            except Exception as e:
                print(f"[simplemcp] Server not ready (attempt {attempt}/{retries}): {e}", file=sys.stderr)
                if attempt < retries:
                    time.sleep(delay)
        print(f"[simplemcp] Cannot reach server at {base_url} after {retries} attempts.", file=sys.stderr)
        return False

    if not _check_server():
        sys.exit(1)

    def forward(line: str):
        try:
            req = json.loads(line)
        except json.JSONDecodeError as e:
            _write({"jsonrpc": "2.0", "id": None,
                    "error": {"code": -32700, "message": str(e)}})
            return

        method = req.get("method", "")
        req_id = req.get("id")

        try:
            if method == "initialize":
                _write({
                    "jsonrpc": "2.0", "id": req_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "SimpleMCP", "version": "2.0.0"},
                    },
                })

            elif method == "tools/list":
                # Forward directly to /mcp on the container, scoped by kit if set.
                resp = _http_post(
                    f"{base_url}/mcp",
                    {"jsonrpc": "2.0", "id": req_id, "method": "tools/list", "params": {}},
                    headers=_kit_headers,
                )
                _write({"jsonrpc": "2.0", "id": req_id,
                        "result": resp.get("result", {"tools": []})})

            elif method == "tools/call":
                params = req.get("params", {})
                resp = _http_post(
                    f"{base_url}/mcp",
                    {"jsonrpc": "2.0", "id": req_id, "method": "tools/call", "params": params},
                    headers=_kit_headers,
                )
                _write({"jsonrpc": "2.0", "id": req_id,
                        "result": resp.get("result", {})})

            elif method == "ping":
                # Keep-alive — respond with empty result
                _write({"jsonrpc": "2.0", "id": req_id, "result": {}})

            elif method == "resources/list":
                _write({"jsonrpc": "2.0", "id": req_id, "result": {"resources": []}})

            elif method == "prompts/list":
                _write({"jsonrpc": "2.0", "id": req_id, "result": {"prompts": []}})

            elif method.startswith("notifications/"):
                pass  # fire-and-forget, no response needed

            else:
                # Only send error if this is a request (has an id), not a notification
                if req_id is not None:
                    _write({"jsonrpc": "2.0", "id": req_id,
                            "error": {"code": -32601,
                                      "message": f"Method not found: {method}"}})
                else:
                    print(f"[simplemcp] Ignoring unknown notification: {method}", file=sys.stderr)

        except Exception as e:
            _write({"jsonrpc": "2.0", "id": req_id,
                    "error": {"code": -32603, "message": str(e)}})

    threads = []
    for raw in sys.stdin:
        line = raw.strip()
        if line:
            t = threading.Thread(target=forward, args=(line,), daemon=True)
            t.start()
            threads.append(t)

    # Wait for any in-flight requests to complete before exiting
    for t in threads:
        t.join(timeout=5.0)
