"""
simplemcp/docker_manager.py — Docker image build and container lifecycle

Handles:
  - Auto-installing Docker if missing
  - Building the simplemcp image from the bundled Dockerfile
  - Starting/stopping containers per mode
  - Port conflict detection and reassignment
  - Host env var forwarding with container env taking precedence
"""

import os
import shutil
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

import docker as docker_sdk

IMAGE_NAME = "simplemcp"
CONTAINER_NAME = "simplemcp"
PACKAGES_DIR = Path.home() / ".simplemcp" / "packages"
KIT_CONFIGS_DIR = Path.home() / ".simplemcp" / "kit_configs"
BASE_PORT = 8467
MCP_PORT_START = 8468

# Path to the bundled Dockerfile (ships with the package) — used for local builds only
DOCKERFILE_DIR = Path(__file__).parent / "docker"


def _extra_hosts() -> dict:
    """
    On Linux, Docker requires an explicit host-gateway mapping so containers
    can reach host services via host.docker.internal.
    On Windows and macOS, Docker Desktop provides this automatically and
    rejects the host-gateway value with a 400 error.
    """
    if sys.platform.startswith("linux"):
        return {"host.docker.internal": "host-gateway"}
    return {}


# ── Docker availability ───────────────────────────────────────────────────────

def ensure_docker():
    """Check Docker is installed; attempt auto-install on Linux if not."""
    if shutil.which("docker"):
        return
    print("[simplemcp] Docker not found. Attempting to install...")
    if sys.platform.startswith("linux"):
        result = subprocess.run(
            ["bash", "-c", "curl -fsSL https://get.docker.com | sh"],
            check=False,
        )
        if result.returncode != 0 or not shutil.which("docker"):
            print("[simplemcp] Auto-install failed. Please install Docker manually: https://docs.docker.com/get-docker/")
            sys.exit(1)
        print("[simplemcp] Docker installed successfully.")
    else:
        print("[simplemcp] Please install Docker manually: https://docs.docker.com/get-docker/")
        sys.exit(1)


def _fix_docker_permissions():
    """
    On Linux, if the Docker socket isn't accessible, add the current user to
    the docker group and re-exec the current command so it takes effect
    immediately — no logout required.
    """
    if not sys.platform.startswith("linux"):
        return
    import grp
    import os
    import pwd

    user = pwd.getpwuid(os.getuid()).pw_name
    try:
        docker_gid = grp.getgrnam("docker").gr_gid
    except KeyError:
        return  # no docker group — Docker probably not installed yet

    # Check if already in the group (in current process's supplementary groups)
    if docker_gid in os.getgroups():
        return

    print(f"[simplemcp] Your user '{user}' is not in the 'docker' group.")
    print("[simplemcp] Fixing this now (requires sudo once)...")
    result = subprocess.run(
        ["sudo", "usermod", "-aG", "docker", user],
        check=False,
    )
    if result.returncode != 0:
        print("[simplemcp] Could not add user to docker group. Try: sudo usermod -aG docker $USER")
        sys.exit(1)

    print("[simplemcp] Done. Re-launching with docker group active...")
    # Re-exec the current command under `newgrp docker` so the group is live
    # without requiring a full logout/login.
    os.execvp("sudo", ["sudo", "-u", user, "sg", "docker", "-c",
                       " ".join(sys.argv)])


def get_client() -> docker_sdk.DockerClient:
    ensure_docker()
    PACKAGES_DIR.mkdir(parents=True, exist_ok=True)
    try:
        return docker_sdk.from_env()
    except Exception:
        _fix_docker_permissions()
        # If _fix_docker_permissions re-execs, we never reach here.
        # If it returns (e.g. already in group but still failing), bail out.
        print("[simplemcp] Could not connect to Docker daemon. Is Docker running?")
        sys.exit(1)


# ── Image ─────────────────────────────────────────────────────────────────────

GHCR_IMAGE = "ghcr.io/dwhite-sys/simplemcp"


def image_exists(client: docker_sdk.DockerClient) -> bool:
    try:
        client.images.get(IMAGE_NAME)
        return True
    except docker_sdk.errors.ImageNotFound:
        return False


def build_image(client: docker_sdk.DockerClient):
    """Build the simplemcp Docker image locally from the bundled Dockerfile."""
    print(f"[simplemcp] Building Docker image '{IMAGE_NAME}' locally...")
    _, logs = client.images.build(path=str(DOCKERFILE_DIR), tag=IMAGE_NAME, rm=True)
    for chunk in logs:
        if "stream" in chunk:
            print(chunk["stream"], end="", flush=True)
    print(f"[simplemcp] Image '{IMAGE_NAME}' built successfully.")


def pull_image(client: docker_sdk.DockerClient, tag: str = "latest") -> bool:
    """
    Pull the precompiled image from ghcr.io and tag it as IMAGE_NAME.
    Returns True on success, False on failure.
    """
    remote = f"{GHCR_IMAGE}:{tag}"
    print(f"[simplemcp] Pulling image '{remote}'...", flush=True)
    try:
        for line in client.api.pull(remote, stream=True, decode=True):
            status = line.get("status", "")
            progress = line.get("progress", "")
            if status and ("Pull" in status or "Download" in status or "Extract" in status):
                print(f"\r  {status} {progress}    ", end="", flush=True)
        print()
        pulled = client.images.get(remote)
        pulled.tag(IMAGE_NAME)
        print(f"[simplemcp] Image pulled and tagged as '{IMAGE_NAME}'.")
        return True
    except Exception as e:
        print(f"\n[simplemcp] Pull failed: {e}", file=sys.stderr)
        return False


def ensure_image(client: docker_sdk.DockerClient):
    """
    Ensure the simplemcp image is available locally.
    Tries to pull from ghcr.io first; falls back to local build if pull fails.
    """
    if image_exists(client):
        return
    print("[simplemcp] Image not found locally — pulling from ghcr.io...")
    if not pull_image(client):
        print("[simplemcp] Falling back to local build...")
        build_image(client)


# ── Ports ─────────────────────────────────────────────────────────────────────

def port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0


def assign_kit_port(config: dict, kit_stem: str) -> int:
    """
    Return the saved port for a kit if it's free, otherwise find a new one
    starting from MCP_PORT_START and persist the new assignment.
    """
    saved = config.get("ports", {}).get(kit_stem)
    if saved and not port_in_use(saved):
        return saved

    used = set(config.get("ports", {}).values())
    port = MCP_PORT_START
    while port_in_use(port) or port in used:
        port += 1

    config.setdefault("ports", {})[kit_stem] = port
    return port


def build_env(container_env: dict) -> dict:
    """
    Build the environment dict for a container run.
    Starts with host environment vars, then overlays container_env so
    explicit container values always take precedence.

    Any env var that references 'localhost' or '127.0.0.1' is rewritten to
    use 'host.docker.internal' so kit code can reach host services from
    inside the container (e.g. a local SearXNG instance on port 8081).

    OS-specific host vars (PATH, PATHEXT, etc.) are excluded so they don't
    overwrite the container's own Linux environment.
    """
    # These are host-OS-specific and must not bleed into the Linux container.
    _HOST_ONLY = {
        "PATH", "PATHEXT", "COMSPEC", "SYSTEMROOT", "SYSTEMDRIVE",
        "WINDIR", "PROGRAMFILES", "PROGRAMFILES(X86)", "PROGRAMDATA",
        "USERPROFILE", "APPDATA", "LOCALAPPDATA", "TEMP", "TMP",
        "HOMEDRIVE", "HOMEPATH", "LOGONSERVER", "USERDOMAIN",
        "COMPUTERNAME", "OS", "PROCESSOR_ARCHITECTURE",
    }

    env = {
        k: v for k, v in os.environ.items()
        if k.upper() not in _HOST_ONLY
    }

    # Rewrite localhost refs so container can reach host services.
    for key, value in env.items():
        if isinstance(value, str):
            value = value.replace("http://localhost:", "http://host.docker.internal:")
            value = value.replace("http://127.0.0.1:", "http://host.docker.internal:")
            env[key] = value

    env.update(container_env)
    return env


# ── Container lifecycle ───────────────────────────────────────────────────────

def get_container(client: docker_sdk.DockerClient, name: str = CONTAINER_NAME):
    try:
        return client.containers.get(name)
    except docker_sdk.errors.NotFound:
        pass
    except Exception:
        pass

    # Fallback: try by saved container_id — catches cases where the container
    # exists but Docker Desktop on Windows lost track of the name mapping
    try:
        from simplemcp import config as _cfg
        saved_id = _cfg.load().get("container_id")
        if saved_id:
            return client.containers.get(saved_id)
    except Exception:
        pass

    return None



def _force_remove(name: str):
    """
    Last-resort removal via subprocess `docker rm -f`.
    Bypasses SDK state issues on Docker Desktop for Windows where
    .stop()/.remove() can hang or fail on unresponsive containers.
    """
    subprocess.run(
        ["docker", "rm", "-f", name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        timeout=15,
    )


def stop_container(client: docker_sdk.DockerClient, name: str = CONTAINER_NAME):
    container = get_container(client, name)
    if not container:
        # Fallback: try lookup by saved container_id in case name lookup failed
        try:
            from simplemcp import config as _cfg
            saved_id = _cfg.load().get("container_id")
            if saved_id:
                container = client.containers.get(saved_id)
        except Exception:
            pass

    if container:
        print(f"[simplemcp] Stopping container '{name}'...")
        try:
            container.stop(timeout=10)
            container.remove()
        except docker_sdk.errors.APIError as e:
            print(f"[simplemcp] Clean stop failed ({e}), force-removing...", file=sys.stderr)
            _force_remove(name)
        except Exception as e:
            print(f"[simplemcp] Stop error ({e}), force-removing...", file=sys.stderr)
            _force_remove(name)
    else:
        # Nothing found by name or ID — still attempt force-remove in case
        # the container exists in a state the Docker SDK can't enumerate (Windows quirk)
        _force_remove(name)


def stop_all(client: docker_sdk.DockerClient) -> dict:
    """Stop the simplemcp container. Returns {"stopped": bool}."""
    container = get_container(client)
    if container:
        print("[simplemcp] Stopping container...")
        try:
            container.stop(timeout=10)
            container.remove()
        except docker_sdk.errors.APIError as e:
            print(f"[simplemcp] Clean stop failed ({e}), force-removing...", file=sys.stderr)
            _force_remove(CONTAINER_NAME)
        except Exception as e:
            print(f"[simplemcp] Stop error ({e}), force-removing...", file=sys.stderr)
            _force_remove(CONTAINER_NAME)
        return {"stopped": True}
    else:
        # Blind force-remove catches containers in states the SDK can't enumerate
        _force_remove(CONTAINER_NAME)
        return {"stopped": False}



def wait_healthy(client: docker_sdk.DockerClient, name: str, timeout: int = 180,
                 verbose: bool = False):
    """
    Block until the container healthcheck reports healthy.
    verbose=True streams container logs live.
    verbose=False shows an animated loading bar instead.
    """
    import itertools
    import sys as _sys

    deadline = time.time() + timeout

    if verbose:
        print("[simplemcp] Waiting for container to be ready...", flush=True)

        def _stream_logs():
            try:
                container = get_container(client, name)
                if container:
                    for chunk in container.logs(stream=True, follow=True):
                        print(f"  {chunk.decode()}", end="", flush=True)
            except Exception:
                pass

        threading.Thread(target=_stream_logs, daemon=True).start()

        while time.time() < deadline:
            container = get_container(client, name)
            if container:
                container.reload()
                health = container.attrs.get("State", {}).get("Health", {}).get("Status")
                if health == "healthy":
                    print("[simplemcp] Ready.", flush=True)
                    return
            time.sleep(2)
        print("\n[simplemcp] Warning: container did not become healthy within timeout.")

    else:
        # Animated loading bar — no log noise
        bar_width = 32
        spinner = itertools.cycle(["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"])
        elapsed = 0.0
        tick = 0.1

        while time.time() < deadline:
            container = get_container(client, name)
            if container:
                container.reload()
                health = container.attrs.get("State", {}).get("Health", {}).get("Status")
                if health == "healthy":
                    # Clear the loading bar line and move up so the
                    # caller's next print overwrites it cleanly.
                    _sys.stdout.write(f"\r\033[2K\033[A")
                    _sys.stdout.flush()
                    return

            elapsed = time.time() - (deadline - timeout)
            progress = min(elapsed / timeout, 0.95)  # never hit 100% until actually done
            filled = int(bar_width * progress)
            bar = "█" * filled + "░" * (bar_width - filled)
            spin = next(spinner)
            _sys.stdout.write(f"\r  {spin} [{bar}] {elapsed:.0f}s elapsed")
            _sys.stdout.flush()
            time.sleep(tick)

        _sys.stdout.write(f"\n[simplemcp] Warning: container did not become healthy within timeout.\n")
        _sys.stdout.flush()


def start_simplemcp(config: dict, kits_dir: Path, verbose: bool = False):
    """Start a SimpleMCP protocol mode container with per-kit MCP ports."""
    client = get_client()
    ensure_image(client)
    stop_container(client)

    port = BASE_PORT
    while port_in_use(port):
        port += 1

    installed_kits = list(config.get("kits", {}).keys())
    if installed_kits:
        print(f"[simplemcp] Installed kits: {', '.join(installed_kits)}")
        print("[simplemcp] Note: kit dependencies will be installed on first start — this may take a moment.")

    # Assign a host port to each kit and build the port binding map
    kit_ports = {}
    for kit_stem in installed_kits:
        kit_ports[kit_stem] = assign_kit_port(config, kit_stem)

    port_bindings = {"8000/tcp": port}
    for kit_port in kit_ports.values():
        port_bindings[f"{kit_port}/tcp"] = kit_port

    print(f"[simplemcp] Starting SimpleMCP server on port {port}...", flush=True)

    def _run_container(bindings):
        KIT_CONFIGS_DIR.mkdir(parents=True, exist_ok=True)
        return client.containers.run(
            IMAGE_NAME,
            name=CONTAINER_NAME,
            detach=True,
            ports=bindings,
            volumes={
                str(kits_dir): {"bind": "/app/kits", "mode": "rw"},
                str(PACKAGES_DIR): {"bind": "/app/lib", "mode": "rw"},
                str(KIT_CONFIGS_DIR): {"bind": "/app/kit_configs", "mode": "ro"},
            },
            environment=build_env({}),
            extra_hosts=_extra_hosts(),
        )

    try:
        container = _run_container(port_bindings)
    except docker_sdk.errors.APIError as e:
        if "409" in str(e) or "Conflict" in str(e) or "name" in str(e).lower():
            print(f"[simplemcp] Name conflict on '{CONTAINER_NAME}', force-removing and retrying...", file=sys.stderr)
            _force_remove(CONTAINER_NAME)
            time.sleep(1)
            container = _run_container(port_bindings)
        else:
            raise

    config["container_id"] = container.id
    config["ports"] = kit_ports
    wait_healthy(client, CONTAINER_NAME, verbose=verbose)

    # Spawn a scoped uvicorn process per kit inside the running container
    for kit_stem, kit_port in kit_ports.items():
        print(f"[simplemcp] Starting MCP server for kit '{kit_stem}' on port {kit_port}...", flush=True)
        container.exec_run(
            ["uvicorn", "server:app", "--host", "0.0.0.0", "--port", str(kit_port)],
            environment={"SIMPLEMCP_KIT": kit_stem},
            detach=True,
        )

    # Auto-start the CDP broker so Playwright kit can launch Chrome on demand.
    # Only starts if the broker is not already running -- safe to call every time.
    _ensure_cdp_broker()

    return port


def _ensure_cdp_broker():
    """
    Start the CDP broker (port 9223) in the background if it is not already running.
    The broker allows the Playwright kit to launch Chrome on the host on demand,
    without requiring the user to run 'simplemcp browser start' manually.
    """
    BROKER_PORT = 9223
    BROKER_PID_FILE = Path.home() / ".simplemcp" / "browser_broker.pid"

    # Check if already running
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        if s.connect_ex(("localhost", BROKER_PORT)) == 0:
            return  # Already up

    print("[simplemcp] Starting CDP broker on port 9223...", flush=True)
    proc = subprocess.Popen(
        [sys.executable, "-m", "simplemcp.browser_broker"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    BROKER_PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    BROKER_PID_FILE.write_text(str(proc.pid))

    # Wait up to 3s for it to be ready
    for _ in range(6):
        time.sleep(0.5)
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            if s.connect_ex(("localhost", BROKER_PORT)) == 0:
                print("[simplemcp] CDP broker ready.", flush=True)
                return

    print("[simplemcp] Warning: CDP broker did not start in time.", file=sys.stderr)

