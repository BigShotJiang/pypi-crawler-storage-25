"""State management utilities for agentic-memory."""

from __future__ import annotations

import datetime as _dt
import fcntl
import json
import os
import re
import sys
import tempfile
import time
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal, cast

from agentic_memory.core import sections, signals
from agentic_memory.core.index_timestamps import (
    INDEXED_AT_TOLERANCE_SECONDS,
    parse_indexed_at,
)

resolve_short_key = sections.resolve_short_key
get_cap = sections.get_cap
STATE_SHORT_KEYS = sections.STATE_SHORT_KEYS
STATE_CAPS = sections.STATE_CAPS
STATE_SECTION_ALIASES = sections.STATE_SECTION_ALIASES
get_section = sections.get_section

SECTION_ORDER = list(sections.STATE_SHORT_KEYS.values())

_LIST_WITH_DATE_RE = re.compile(r"^\-\s*\[(\d{4}-\d{2}-\d{2}(?:\s+\d{2}:\d{2})?)\]\s*(.*)$")
_LIST_RE = re.compile(r"^\-\s*(.*)$")
_DATE_PREFIX_RE = re.compile(r"^\[(\d{4}-\d{2}-\d{2}(?:\s+\d{2}:\d{2})?)\]\s*(.*)$")
_HEADING_RE = re.compile(r"^##\s+(.*)\s*$")
_SPACE_RE = re.compile(r"\s+")
_NONE_SKILL_RE = re.compile(r"^\s*(?:skill|skil)\s*:\s*none\s*$", flags=re.IGNORECASE)
_PLACEHOLDER_TEXTS = {"", "(empty)", "なし"}
TASK_ID_EXTRACT_PATTERN = re.compile(r"\b((?:TASK|GOAL)-\d{3,})\b")
_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9_-]+$")
_AGENT_STATE_FILE_RE = re.compile(
    r"^_state\.(?P<agent_id>[A-Za-z0-9_-]+)(?:\.[A-Za-z0-9_-]+)?\.md$"
)
_IMPROVEMENT_ITEM_RE = re.compile(
    r"^\[severity:(?P<severity>[^\]]+)\]"
    r"(?:\[(?P<trigger_type>[^\]]+)\])?\s+"
    r"(?P<skill>.+?)(?:\s+\(score=\d+\))?\s+—\s+"
)
_TIME_PREFIX_RE = re.compile(r"^(?P<start>\d{2}:\d{2})(?:\s*-\s*.*)?$")
_FILENAME_TIME_PREFIX_RE = re.compile(r"^(?P<hour>\d{2})(?P<minute>\d{2})(?:_|$)")
_PERIODIC_REVIEW_COOLDOWN_DAYS = 14
_LEGACY_IMPROVEMENT_RESOLVED_BASENAME = "_improvement_backlog_resolved.json"
_SIGFB_RESOLVED_BASENAME = "_sigfb_resolved.json"
_BACKLOG_CONTRIBUTORS_BASENAME = "_backlog_contributors.json"
_TRIGGER_COOLDOWN_BASENAME = "_trigger_cooldown.json"
_STATE_FRONTMATTER_BOUNDARY = "---"
_DISTILLATION_FRONTMATTER_KEYS = (
    "last_knowledge_distilled_at",
    "last_values_distilled_at",
    "last_knowledge_evaluated_at",
    "last_values_evaluated_at",
)
AutoImproveMode = Literal["detect", "add", "skip"]
NOTE_NOT_FOUND_PREFIX = "Note not found"
FAILED_TO_READ_NOTE_PREFIX = "Failed to read note"


def now_stamp() -> str:
    """現在時刻を 'YYYY-MM-DD HH:MM' 形式で返す"""
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M")


def _parse_datetime(date_str: str) -> _dt.datetime | None:
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return _dt.datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    return None


def _is_placeholder(text: str) -> bool:
    norm = text.strip().lower()
    return norm in _PLACEHOLDER_TEXTS


def _atomic_write_text(path: Path, content: str) -> None:
    """Write content to path atomically via temp file + os.replace."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(content)
        os.replace(tmp, str(path))
    except BaseException:
        with suppress(OSError):
            os.unlink(tmp)
        raise


def _parse_improvement_item(text: str) -> dict[str, str | None]:
    match = _IMPROVEMENT_ITEM_RE.match(text.strip())
    if not match:
        return {"severity": None, "trigger_type": None, "skill": None}
    return {
        "severity": match.group("severity"),
        "trigger_type": match.group("trigger_type"),
        "skill": match.group("skill").strip(),
    }


def _serialize_state_item(item: StateItem) -> dict[str, str]:
    return {"date": item.date, "text": item.text}


def _serialize_improvement_candidate(item: StateItem) -> dict[str, str]:
    payload = _serialize_state_item(item)
    parsed = _parse_improvement_item(item.text)
    for key, value in parsed.items():
        if value is not None:
            payload[key] = value
    return payload


def _serialize_state_change(section: str, item: StateItem) -> dict[str, str]:
    payload = _serialize_state_item(item)
    payload["section"] = section
    return payload


def _empty_legacy_migration_summary() -> dict[str, Any]:
    return {
        "legacy_file_present": False,
        "legacy_entries_found": 0,
        "migrated_entries": 0,
        "migrated_signal_ids": 0,
        "migrated_trigger_cooldowns": 0,
        "remaining_legacy_entries": 0,
        "needs_reindex": False,
        "unresolved_reason_counts": {},
    }


def _increment_unresolved_reason(summary: dict[str, Any], reason: str) -> None:
    counts = cast(dict[str, int], summary["unresolved_reason_counts"])
    counts[reason] = counts.get(reason, 0) + 1


def _resolve_auto_improve_mode(auto_improve_mode: AutoImproveMode | None) -> AutoImproveMode:
    resolved = auto_improve_mode or "detect"
    if resolved not in {"detect", "add", "skip"}:
        raise ValueError(
            f"Invalid auto_improve_mode: {auto_improve_mode!r}. Use one of: detect, add, skip."
        )
    return resolved


# --- legacy _improvement_backlog_resolved.json sidecar ---


def _legacy_improvement_resolved_path(state_path: Path) -> Path:
    return state_path.parent / _LEGACY_IMPROVEMENT_RESOLVED_BASENAME


def _load_legacy_improvement_resolved(state_path: Path) -> list[dict[str, Any]]:
    path = _legacy_improvement_resolved_path(state_path)
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []
    if not isinstance(payload, list):
        return []
    return [item for item in payload if isinstance(item, dict)]


def _save_legacy_improvement_resolved(state_path: Path, data: list[dict[str, Any]]) -> None:
    path = _legacy_improvement_resolved_path(state_path)
    if not data:
        with suppress(FileNotFoundError):
            path.unlink()
        return
    _atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


# --- _sigfb_resolved.json sidecar ---


def _sigfb_resolved_path(state_path: Path) -> Path:
    return state_path.parent / _SIGFB_RESOLVED_BASENAME


def _load_sigfb_resolved(state_path: Path) -> dict[str, dict]:
    path = _sigfb_resolved_path(state_path)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return payload


def _save_sigfb_resolved(state_path: Path, data: dict[str, dict]) -> None:
    path = _sigfb_resolved_path(state_path)
    if not data:
        with suppress(FileNotFoundError):
            path.unlink()
        return
    _atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def _resolved_signal_id_set(state_path: Path) -> set[str]:
    return set(_load_sigfb_resolved(state_path).keys())


def _mark_signals_resolved(
    state_path: Path,
    signal_ids: list[str],
    *,
    resolved_at: str | None = None,
) -> None:
    if not signal_ids:
        return
    data = _load_sigfb_resolved(state_path)
    stamp = resolved_at or now_stamp()
    for sid in signal_ids:
        data.setdefault(sid, {"resolved_at": stamp})
    _save_sigfb_resolved(state_path, data)


# --- _backlog_contributors.json sidecar ---


def _contributor_snapshot_path(state_path: Path) -> Path:
    return state_path.parent / _BACKLOG_CONTRIBUTORS_BASENAME


def _load_contributor_snapshot(state_path: Path) -> dict[str, list[str]]:
    path = _contributor_snapshot_path(state_path)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return payload


def _save_contributor_snapshot(state_path: Path, data: dict[str, list[str]]) -> None:
    path = _contributor_snapshot_path(state_path)
    if not data:
        with suppress(FileNotFoundError):
            path.unlink()
        return
    _atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


# --- _trigger_cooldown.json sidecar ---


def _trigger_cooldown_path(state_path: Path) -> Path:
    return state_path.parent / _TRIGGER_COOLDOWN_BASENAME


def _load_trigger_cooldown(state_path: Path) -> dict[str, str]:
    path = _trigger_cooldown_path(state_path)
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return payload


def _save_trigger_cooldown(state_path: Path, data: dict[str, str]) -> None:
    path = _trigger_cooldown_path(state_path)
    if not data:
        with suppress(FileNotFoundError):
            path.unlink()
        return
    _atomic_write_text(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def _set_trigger_cooldown(state_path: Path, trigger_type: str, stamp: str) -> None:
    data = _load_trigger_cooldown(state_path)
    current = data.get(trigger_type)
    current_dt = _parse_datetime(current) if isinstance(current, str) else None
    next_dt = _parse_datetime(stamp)
    if current_dt is not None and next_dt is not None and current_dt >= next_dt:
        return
    data[trigger_type] = stamp
    _save_trigger_cooldown(state_path, data)


def _record_trigger_cooldown(state_path: Path, trigger_type: str) -> None:
    _set_trigger_cooldown(state_path, trigger_type, now_stamp())


def _has_recent_trigger_cooldown(state_path: Path, trigger_type: str, days: int) -> bool:
    data = _load_trigger_cooldown(state_path)
    stamp = data.get(trigger_type)
    if not isinstance(stamp, str):
        return False
    dt = _parse_datetime(stamp)
    if dt is None:
        return False
    now = _dt.date.today()
    return (now - dt.date()).days < days


# --- Backlog signal resolution ---


def _resolve_backlog_signals(state_path: Path, removed_items: list[StateItem]) -> None:
    snapshot = _load_contributor_snapshot(state_path)
    all_signal_ids: list[str] = []
    for item in removed_items:
        key = item.normalize_key()
        contributor_ids = snapshot.pop(key, [])
        all_signal_ids.extend(contributor_ids)
        meta = _parse_improvement_item(item.text)
        if meta.get("trigger_type") == "periodic_review":
            _record_trigger_cooldown(state_path, "periodic_review")
    if all_signal_ids:
        _mark_signals_resolved(state_path, all_signal_ids)
    _save_contributor_snapshot(state_path, snapshot)


def _entry_start_datetime(entry: dict[str, Any]) -> _dt.datetime | None:
    raw_date = entry.get("date")
    if not isinstance(raw_date, str) or not raw_date.strip():
        return None

    raw_time = entry.get("time")
    if isinstance(raw_time, str):
        match = _TIME_PREFIX_RE.match(raw_time.strip())
        if match is not None:
            entry_dt = _parse_datetime(f"{raw_date} {match.group('start')}")
            if entry_dt is not None:
                return entry_dt

    raw_path = entry.get("path")
    if isinstance(raw_path, str):
        match = _FILENAME_TIME_PREFIX_RE.match(Path(raw_path).name)
        if match is not None:
            entry_dt = _parse_datetime(f"{raw_date} {match.group('hour')}:{match.group('minute')}")
            if entry_dt is not None:
                return entry_dt

    return None


def _entry_happened_before_resolution(entry: dict[str, Any], resolved_at: _dt.datetime) -> bool:
    raw_date = entry.get("date")
    if not isinstance(raw_date, str) or not raw_date.strip():
        return False
    entry_date = _parse_datetime(raw_date)
    if entry_date is None:
        return False
    if entry_date.date() < resolved_at.date():
        return True
    if entry_date.date() > resolved_at.date():
        return False

    entry_dt = _entry_start_datetime(entry)
    if entry_dt is None:
        return False
    return entry_dt <= resolved_at


def _legacy_snapshot_for_resolution(
    entries: list[dict[str, Any]],
    resolved_at: _dt.datetime,
    *,
    threshold: int,
) -> tuple[list[dict[str, Any]], dict[str, list[str]], list[dict[str, Any]]]:
    prior_entries = [
        entry for entry in entries if _entry_happened_before_resolution(entry, resolved_at)
    ]
    aggregated = signals.aggregate_signals(prior_entries)
    candidates = signals.analyze_signals(aggregated, threshold=threshold)
    skill_contributors = {
        str(cand.get("skill", "")): [
            sid for sid in cand.get("contributor_ids", []) if isinstance(sid, str) and sid
        ]
        for cand in candidates
    }
    triggers = signals.check_improvement_triggers(prior_entries, candidates, [])
    return candidates, skill_contributors, triggers


def _migrate_legacy_improvement_resolutions(
    state_path: Path,
    entries: list[dict[str, Any]],
    *,
    threshold: int,
) -> dict[str, Any]:
    legacy_entries = _load_legacy_improvement_resolved(state_path)
    summary = _empty_legacy_migration_summary()
    summary["legacy_file_present"] = _legacy_improvement_resolved_path(state_path).exists()
    summary["legacy_entries_found"] = len(legacy_entries)
    if not legacy_entries:
        return summary

    snapshot_cache: dict[
        str,
        tuple[list[dict[str, Any]], dict[str, list[str]], list[dict[str, Any]]],
    ] = {}
    remaining: list[dict[str, Any]] = []
    resolved_data = _load_sigfb_resolved(state_path)
    trigger_cooldown = _load_trigger_cooldown(state_path)
    resolved_changed = False
    cooldown_changed = False

    def snapshot_for(
        stamp: str,
    ) -> tuple[list[dict[str, Any]], dict[str, list[str]], list[dict[str, Any]]]:
        cached = snapshot_cache.get(stamp)
        if cached is not None:
            return cached
        resolved_at = _parse_datetime(stamp)
        if resolved_at is None:
            empty: tuple[list[dict[str, Any]], dict[str, list[str]], list[dict[str, Any]]] = (
                [],
                {},
                [],
            )
            snapshot_cache[stamp] = empty
            return empty
        built = _legacy_snapshot_for_resolution(entries, resolved_at, threshold=threshold)
        snapshot_cache[stamp] = built
        return built

    sorted_entries = sorted(
        legacy_entries,
        key=lambda item: str(item.get("resolved_at", "")),
    )
    for legacy in sorted_entries:
        resolved_at = legacy.get("resolved_at")
        if not isinstance(resolved_at, str) or _parse_datetime(resolved_at) is None:
            _increment_unresolved_reason(summary, "invalid_resolved_at")
            remaining.append(legacy)
            continue

        trigger_type = legacy.get("trigger_type")
        skill = legacy.get("skill")
        if trigger_type == "periodic_review":
            current = trigger_cooldown.get("periodic_review")
            current_dt = _parse_datetime(current) if isinstance(current, str) else None
            next_dt = _parse_datetime(resolved_at)
            if current_dt is None or (next_dt is not None and next_dt > current_dt):
                trigger_cooldown["periodic_review"] = resolved_at
                cooldown_changed = True
            summary["migrated_entries"] += 1
            summary["migrated_trigger_cooldowns"] += 1
            continue

        if not isinstance(skill, str) or not skill.strip():
            _increment_unresolved_reason(summary, "missing_skill")
            remaining.append(legacy)
            continue
        skill = skill.strip()

        candidates, skill_contributors, triggers = snapshot_for(resolved_at)
        signal_ids: list[str] = []
        missing_reason: str | None = None
        if trigger_type in {"pattern_escalation", "gap_expansion"}:
            trigger_exists = any(
                trig.get("type") == trigger_type and trig.get("skill") == skill for trig in triggers
            )
            if trigger_exists:
                signal_ids = skill_contributors.get(skill, [])
                if not signal_ids:
                    missing_reason = "missing_signal_ids"
            else:
                missing_reason = "no_matching_trigger"
        else:
            matched = next(
                (
                    cand
                    for cand in candidates
                    if cand.get("skill") == skill and cand.get("severity") == "high"
                ),
                None,
            )
            if matched is not None:
                signal_ids = [
                    sid
                    for sid in matched.get("contributor_ids", [])
                    if isinstance(sid, str) and sid
                ]
                if not signal_ids:
                    missing_reason = "missing_signal_ids"
            else:
                missing_reason = "no_matching_candidate"

        if not signal_ids:
            if missing_reason is not None:
                _increment_unresolved_reason(summary, missing_reason)
            summary["needs_reindex"] = True
            remaining.append(legacy)
            continue

        summary["migrated_entries"] += 1
        for sid in signal_ids:
            if sid not in resolved_data:
                resolved_data[sid] = {"resolved_at": resolved_at}
                resolved_changed = True
            summary["migrated_signal_ids"] += 1

    if resolved_changed:
        _save_sigfb_resolved(state_path, resolved_data)
    if cooldown_changed:
        _save_trigger_cooldown(state_path, trigger_cooldown)
    if resolved_changed or cooldown_changed or len(remaining) != len(legacy_entries):
        _save_legacy_improvement_resolved(state_path, remaining)
    summary["remaining_legacy_entries"] = len(remaining)
    return summary


@dataclass
class StateItem:
    date: str
    text: str

    def render(self) -> str:
        """'- [2026-02-22 19:30] text' 形式で返す"""
        return f"- [{self.date}] {self.text.strip()}"

    def normalize_key(self) -> str:
        """重複検出用キー。テキストを正規化（空白圧縮・小文字化）して返す"""
        return _SPACE_RE.sub(" ", self.text.strip()).lower()

    @classmethod
    def parse(cls, line: str) -> StateItem | None:
        """行をパースして StateItem を返す。
        - '- [YYYY-MM-DD HH:MM] text' 形式の場合はそのまま
        - '- text'（日付なし）の場合は今日の日付で補完
        - プレースホルダー（'- (empty)', '- なし', '- ')は None を返す
        - 空行やリスト項目でない行は None を返す
        """
        s = line.strip()
        if not s:
            return None

        m = _LIST_WITH_DATE_RE.match(s)
        if m:
            date = m.group(1).strip()
            text = m.group(2).strip()
            if _is_placeholder(text):
                return None
            return cls(date=date, text=text)

        m = _LIST_RE.match(s)
        if not m:
            return None
        text = m.group(1).strip()
        if _is_placeholder(text):
            return None
        return cls(date=now_stamp(), text=text)

    @classmethod
    def from_text(cls, text: str, date: str | None = None) -> StateItem:
        """テキストから StateItem を作成。日付未指定時は今日の日付。
        テキストが既に [YYYY-MM-DD HH:MM] で始まっている場合はそこから日付を抽出する。
        """
        raw = text.strip()
        if not raw:
            raise ValueError("item text is empty")

        if raw.startswith("-"):
            parsed = cls.parse(raw)
            if parsed is None:
                raise ValueError("invalid item text")
            return parsed

        m = _DATE_PREFIX_RE.match(raw)
        if m:
            d = m.group(1).strip()
            body = m.group(2).strip()
            if _is_placeholder(body):
                raise ValueError("item text is empty")
            return cls(date=d, text=body)

        if _is_placeholder(raw):
            raise ValueError("item text is empty")
        return cls(date=(date or now_stamp()), text=raw)


@dataclass(frozen=True, slots=True)
class AgentStateFile:
    path: Path
    agent_id: str
    mtime: float


def parse_sections(md: str) -> dict[str, list[str]]:
    """Markdown を ## 見出しごとにパースして {見出し名: [行リスト]} を返す"""
    sections: dict[str, list[str]] = {}
    cur = None
    for line in md.splitlines():
        m = _HEADING_RE.match(line)
        if m:
            cur = m.group(1).strip()
            sections.setdefault(cur, [])
            continue
        if cur is not None:
            sections[cur].append(line.rstrip())
    return sections


def load_state(path: Path) -> dict[str, list[StateItem]]:
    """ステートファイルを読み込み、セクションごとの StateItem リストを返す。
    ファイルが存在しない場合は空のセクション辞書を返す。
    SECTION_ORDER に定義された全セクションが含まれるよう保証する。
    """
    out: dict[str, list[StateItem]] = {sec: [] for sec in SECTION_ORDER}
    if not path.exists():
        return out

    _frontmatter, md = _parse_state_document(path.read_text(encoding="utf-8", errors="ignore"))
    secs = parse_sections(md)
    for sec in SECTION_ORDER:
        parsed: list[StateItem] = []
        for line in get_section(secs, sec):
            item = StateItem.parse(line)
            if item is not None:
                parsed.append(item)
        out[sec] = parsed
    return out


def _empty_sections() -> dict[str, list[StateItem]]:
    return {sec: [] for sec in SECTION_ORDER}


def _default_distillation_frontmatter() -> dict[str, str | None]:
    return {key: None for key in _DISTILLATION_FRONTMATTER_KEYS}


def _parse_frontmatter_value(raw: str) -> Any:
    if not raw:
        return None
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        lowered = raw.lower()
        if lowered in {"null", "~"}:
            return None
        return raw.strip().strip('"').strip("'")


def _parse_state_document(text: str) -> tuple[dict[str, Any], str]:
    lines = text.splitlines()
    if not lines or lines[0].strip() != _STATE_FRONTMATTER_BOUNDARY:
        return {}, text

    end_index = None
    for index, line in enumerate(lines[1:], start=1):
        if line.strip() == _STATE_FRONTMATTER_BOUNDARY:
            end_index = index
            break
    if end_index is None:
        return {}, text

    frontmatter: dict[str, Any] = {}
    for line in lines[1:end_index]:
        if not line.strip():
            continue
        key, separator, value = line.partition(":")
        if not separator:
            continue
        frontmatter[key.strip()] = _parse_frontmatter_value(value.strip())
    body = "\n".join(lines[end_index + 1 :]).lstrip("\n")
    if text.endswith("\n") and body and not body.endswith("\n"):
        body += "\n"
    return frontmatter, body


def _serialize_frontmatter(frontmatter: dict[str, Any] | None) -> list[str]:
    if not frontmatter:
        return []

    items = [(key, value) for key, value in frontmatter.items() if value is not None]
    if not items:
        return []

    lines = [_STATE_FRONTMATTER_BOUNDARY]
    for key, value in items:
        lines.append(f"{key}: {json.dumps(value, ensure_ascii=False)}")
    lines.append(_STATE_FRONTMATTER_BOUNDARY)
    return lines


def load_state_frontmatter(path: Path) -> dict[str, str | None]:
    payload = _default_distillation_frontmatter()
    if not path.exists():
        return payload

    frontmatter, _body = _parse_state_document(path.read_text(encoding="utf-8", errors="ignore"))
    for key in _DISTILLATION_FRONTMATTER_KEYS:
        value = frontmatter.get(key)
        payload[key] = None if value is None else str(value)
    return payload


def update_distillation_frontmatter(
    path: Path,
    **updates: str,
) -> dict[str, str | None]:
    unknown = sorted(set(updates) - set(_DISTILLATION_FRONTMATTER_KEYS))
    if unknown:
        raise ValueError(f"Unknown distillation frontmatter field(s): {', '.join(unknown)}")

    ensure_state_file(path)
    existing_frontmatter, _body = _parse_state_document(path.read_text(encoding="utf-8"))
    merged_frontmatter = dict(existing_frontmatter)
    for key, value in updates.items():
        merged_frontmatter[key] = str(value)
    save_state(path, load_state(path), frontmatter=merged_frontmatter)
    return load_state_frontmatter(path)


def ensure_state_file(path: Path) -> Path:
    if path.exists():
        return path
    save_state(path, _empty_sections())
    return path


def _normalize_identifier(name: str, value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{name} is required")
    if not _IDENTIFIER_RE.fullmatch(normalized):
        raise ValueError(
            f"Invalid {name}: {value!r} (allowed characters: letters, digits, '_' and '-')"
        )
    return normalized


def resolve_agent_state_path(
    memory_dir: Path,
    agent_id: str,
    relay_session_id: str | None = None,
    *,
    for_write: bool = False,
) -> Path:
    normalized_agent_id = _normalize_identifier("agent_id", agent_id)
    if relay_session_id is None:
        return memory_dir / f"_state.{normalized_agent_id}.md"

    normalized_session = _normalize_identifier("relay_session_id", relay_session_id)
    session_specific = memory_dir / f"_state.{normalized_agent_id}.{normalized_session}.md"
    if for_write:
        return session_specific

    if session_specific.exists():
        return session_specific

    shared = memory_dir / f"_state.{normalized_agent_id}.md"
    if shared.exists():
        return shared
    return session_specific


def state_sections_to_payload(
    sections_data: dict[str, list[StateItem]],
    *,
    section: str | None = None,
    stale_days: int = 0,
) -> dict[str, list[dict[str, object]]]:
    targets = _target_sections(section)
    payload: dict[str, list[dict[str, object]]] = {}
    for sec in targets:
        rows: list[dict[str, object]] = []
        for item in sections_data.get(sec, []):
            stale = bool(stale_days and is_stale(item, stale_days))
            rows.append({"date": item.date, "text": item.text, "stale": stale})
        payload[sec] = rows
    return payload


def state_sections_to_rendered(
    sections_data: dict[str, list[StateItem]],
) -> dict[str, list[str]]:
    rendered: dict[str, list[str]] = {}
    for short_key, section_name in STATE_SHORT_KEYS.items():
        rendered[short_key] = [item.render() for item in sections_data.get(section_name, [])]
    return rendered


def _count_rendered_lines(rendered: dict[str, list[str]] | None) -> int:
    if rendered is None:
        return 0
    return sum(len(lines) for lines in rendered.values())


def _truncate_rendered_sections(
    rendered: dict[str, list[str]] | None,
    max_lines: int,
) -> tuple[dict[str, list[str]] | None, int, bool]:
    if rendered is None:
        return None, 0, False

    remaining = max(max_lines, 0)
    used = 0
    truncated = False
    trimmed: dict[str, list[str]] = {}

    for key, lines in rendered.items():
        if remaining <= 0:
            trimmed[key] = []
            truncated = truncated or bool(lines)
            continue

        kept = lines[:remaining]
        trimmed[key] = kept
        used += len(kept)
        remaining -= len(kept)
        if len(kept) < len(lines):
            truncated = True

    return trimmed, used, truncated


def _count_text_lines(text: str) -> int:
    if not text:
        return 0
    return len(text.splitlines())


def _truncate_text_lines(text: str, max_lines: int) -> tuple[str, int, bool]:
    safe_max = max(max_lines, 0)
    lines = text.splitlines()
    kept = lines[:safe_max]
    truncated = len(kept) < len(lines)

    if not kept:
        return "", 0, truncated

    truncated_text = "\n".join(kept)
    if text.endswith("\n"):
        truncated_text += "\n"
    return truncated_text, len(kept), truncated


def _apply_restore_line_budget(
    *,
    project_state: dict[str, list[str]] | None,
    agent_state: dict[str, list[str]] | None,
    active_tasks: list[dict[str, object]],
    max_total_lines: int,
) -> tuple[
    dict[str, list[str]] | None,
    dict[str, list[str]] | None,
    list[dict[str, object]],
    list[str],
]:
    remaining = max(max_total_lines, 0)
    truncated_parts: list[str] = []

    project_state, used, project_truncated = _truncate_rendered_sections(project_state, remaining)
    remaining -= used
    if project_truncated:
        truncated_parts.append("project_state")

    agent_state, used, agent_truncated = _truncate_rendered_sections(agent_state, remaining)
    remaining -= used
    if agent_truncated:
        truncated_parts.append("agent_state")

    trimmed_tasks: list[dict[str, object]] = []
    evidence_truncated = False
    for task in active_tasks:
        trimmed_task = dict(task)
        evidence_pack = trimmed_task.get("evidence_pack", "")
        if isinstance(evidence_pack, str):
            trimmed_pack, used, was_truncated = _truncate_text_lines(evidence_pack, remaining)
            trimmed_task["evidence_pack"] = trimmed_pack
            remaining -= used
            evidence_truncated = evidence_truncated or was_truncated
        trimmed_tasks.append(trimmed_task)

    if evidence_truncated:
        truncated_parts.append("evidence_packs")

    return project_state, agent_state, trimmed_tasks, truncated_parts


def extract_task_ids_from_focus(sections_data: dict[str, list[StateItem]]) -> list[str]:
    focus_section = STATE_SHORT_KEYS["focus"]
    task_ids: list[str] = []
    seen: set[str] = set()
    for item in sections_data.get(focus_section, []):
        for match in TASK_ID_EXTRACT_PATTERN.finditer(item.text):
            task_id = match.group(1).upper()
            if task_id in seen:
                continue
            seen.add(task_id)
            task_ids.append(task_id)
    return task_ids


def _resolve_note_path_for_evidence(raw_path: str, memory_dir: Path) -> Path:
    candidate = Path(raw_path)
    if candidate.is_absolute():
        return candidate

    memory_prefixed = memory_dir.parent / candidate
    if memory_prefixed.exists():
        return memory_prefixed

    direct = memory_dir / candidate
    if direct.exists():
        return direct

    return memory_prefixed


def save_state(
    path: Path,
    sections: dict[str, list[StateItem]],
    *,
    frontmatter: dict[str, Any] | None = None,
) -> None:
    """セクション辞書をステートファイルに書き込む。
    ヘッダー: '# 作業状態（ローリング）\n\nLast updated: {now_stamp()}'
    各セクション: '## {見出し名}\n\n' + アイテムのrender()結果（空なら見出しのみ）
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = Path(f"{path}.lock")
    with open(lock_path, "w") as lock_file:
        try:
            fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                try:
                    fcntl.flock(lock_file, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    time.sleep(0.1)
            else:
                raise TimeoutError("Could not acquire state lock within 5s")
        try:
            existing_frontmatter: dict[str, Any] = {}
            if frontmatter is None and path.exists():
                existing_frontmatter, _body = _parse_state_document(
                    path.read_text(encoding="utf-8", errors="ignore")
                )
            lines: list[str] = []
            lines.extend(_serialize_frontmatter(frontmatter or existing_frontmatter))
            if lines:
                lines.append("")
            lines.append("# 作業状態（ローリング）")
            lines.append("")
            lines.append(f"Last updated: {now_stamp()}")
            lines.append("")
            for sec in SECTION_ORDER:
                lines.append(f"## {sec}")
                lines.append("")
                for item in sections.get(sec, []):
                    lines.append(item.render())
                lines.append("")
            _atomic_write_text(path, "\n".join(lines).rstrip() + "\n")
        finally:
            fcntl.flock(lock_file, fcntl.LOCK_UN)


def _is_newer(lhs: StateItem, rhs: StateItem) -> bool:
    ld = _parse_datetime(lhs.date)
    rd = _parse_datetime(rhs.date)
    if ld is None and rd is None:
        return False
    if ld is None:
        return False
    if rd is None:
        return True
    return ld > rd


def deduplicate(items: list[StateItem]) -> list[StateItem]:
    """重複排除。normalize_key() で比較し、同一テキストは新しい日付のものを残す。
    順序は入力順を維持する。"""
    out: list[StateItem] = []
    index: dict[str, int] = {}
    for item in items:
        key = item.normalize_key()
        if not key:
            continue
        if key in index:
            pos = index[key]
            if _is_newer(item, out[pos]):
                out[pos] = item
            continue
        subsumed = False
        for existing_key, pos in list(index.items()):
            if key in existing_key:
                if _is_newer(item, out[pos]):
                    out[pos] = StateItem(date=item.date, text=out[pos].text)
                subsumed = True
                break
            if existing_key in key:
                index[key] = pos
                del index[existing_key]
                out[pos] = item
                subsumed = True
                break
        if not subsumed:
            index[key] = len(out)
            out.append(item)
    return out


def enforce_cap(items: list[StateItem], cap: int) -> tuple[list[StateItem], list[StateItem]]:
    """cap を超過する場合は末尾（最古=リスト末尾）を切り捨て。

    Returns:
        (kept, dropped) tuple.
    """
    safe_cap = max(cap, 0)
    if len(items) > safe_cap:
        return items[:safe_cap], items[safe_cap:]
    return items, []


def is_stale(item: StateItem, stale_days: int) -> bool:
    """アイテムの日付が today - stale_days 以前なら True。
    日付が不正な場合も stale 扱い（True）"""
    dt = _parse_datetime(item.date)
    if dt is None:
        return True
    cutoff = _dt.datetime.now() - _dt.timedelta(days=stale_days)
    return dt <= cutoff


def bullets(lines: list[str]) -> list[str]:
    """行リストからリスト項目のテキスト部分を抽出する。

    `- ` を除去し、空行やリスト項目でない行はスキップする。
    """
    out: list[str] = []
    for ln in lines:
        s = ln.strip()
        if not s:
            continue
        if s.startswith("-"):
            out.append(s.lstrip("-").strip())
    return out


def _resolve_section_or_raise(key: str) -> str:
    return resolve_short_key(key)


def _target_sections(section_arg: str | None) -> list[str]:
    if section_arg is None:
        return list(SECTION_ORDER)
    return [_resolve_section_or_raise(section_arg)]


def _parse_items_or_raise(texts: list[str]) -> list[StateItem]:
    items: list[StateItem] = []
    for text in texts:
        items.append(StateItem.from_text(text))
    return items


def _is_none_skill(text: str) -> bool:
    norm = _SPACE_RE.sub(" ", text.strip()).lower()
    if norm == "none":
        return True
    return _NONE_SKILL_RE.match(norm) is not None


def _validate_non_negative(name: str, value: int) -> None:
    if value < 0:
        raise ValueError(f"{name} must be >= 0")


def cmd_show(
    state_path: Path,
    section: str | None = None,
    stale_days: int = 0,
    as_json: bool = False,
) -> int:
    try:
        _validate_non_negative("stale-days", stale_days)
        targets = _target_sections(section)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    sections_data = load_state(state_path)
    frontmatter = load_state_frontmatter(state_path)

    if as_json:
        payload: dict[str, Any] = {
            "sections": state_sections_to_payload(
                sections_data,
                section=section,
                stale_days=stale_days,
            ),
            "frontmatter": frontmatter,
        }
        print(json.dumps(payload, ensure_ascii=False))
        return 0

    print("## 蒸留メタデータ")
    for key, value in frontmatter.items():
        print(f"- {key}: {'null' if value is None else value}")
    print("")

    for sec in targets:
        cap = get_cap(sec)
        items = sections_data.get(sec, [])
        print(f"## {sec} ({len(items)}/{cap})")
        if not items:
            print("- (empty)")
            print("")
            continue
        for item in items:
            stale_mark = " [STALE]" if stale_days and is_stale(item, stale_days) else ""
            print(f"{item.render()}{stale_mark}")
        print("")
    return 0


def cmd_set(state_path: Path, section: str, items: list[str]) -> int:
    try:
        section_name = _resolve_section_or_raise(section)
        new_items = _parse_items_or_raise(items)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    sections = load_state(state_path)
    before_count = len(sections.get(section_name, []))
    sections[section_name], _ = enforce_cap(deduplicate(new_items), get_cap(section_name))
    after_count = len(sections[section_name])
    save_state(state_path, sections)
    summary = json.dumps(
        {
            "path": str(state_path),
            "section": section_name,
            "set": len(new_items),
            "before": before_count,
            "after": after_count,
        },
        ensure_ascii=False,
    )
    print(summary)
    return 0


def cmd_add(
    state_path: Path,
    section: str,
    items: list[str],
    replace: list[str] | str | None = None,
) -> int:
    try:
        section_name = _resolve_section_or_raise(section)
        new_items = _parse_items_or_raise(items)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    sections = load_state(state_path)
    existing = sections.get(section_name, [])
    before_count = len(existing)
    removed_count = 0
    replace_patterns = [replace] if isinstance(replace, str) else replace
    if replace_patterns:
        filtered = [
            item
            for item in existing
            if not any(p.lower() in item.text.lower() for p in replace_patterns)
        ]
        removed_count = before_count - len(filtered)
        existing = filtered
    merged = deduplicate(new_items + existing)
    sections[section_name], _ = enforce_cap(merged, get_cap(section_name))
    after_count = len(sections[section_name])
    save_state(state_path, sections)
    summary = json.dumps(
        {
            "path": str(state_path),
            "section": section_name,
            "added": len(new_items),
            "removed": removed_count,
            "before": before_count,
            "after": after_count,
        },
        ensure_ascii=False,
    )
    print(summary)
    return 0


def cmd_remove(state_path: Path, section: str, pattern: str, regex: bool = False) -> int:
    try:
        section_name = _resolve_section_or_raise(section)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    matcher = None
    if regex:
        try:
            matcher = re.compile(pattern)
        except re.error as exc:
            print(f"Invalid regex: {exc}", file=sys.stderr)
            return 2

    sections = load_state(state_path)
    kept: list[StateItem] = []
    removed_items: list[str] = []
    removed_state_items: list[StateItem] = []
    for item in sections.get(section_name, []):
        matched = (
            bool(matcher.search(item.text))
            if matcher is not None
            else pattern.lower() in item.text.lower()
        )
        if matched:
            removed_items.append(f"[{item.date}] {item.text}")
            removed_state_items.append(item)
        else:
            kept.append(item)

    removed_count = len(removed_items)
    if removed_count > 0:
        sections[section_name] = kept
        save_state(state_path, sections)
        if section_name == STATE_SHORT_KEYS["improvements"]:
            _resolve_backlog_signals(state_path, removed_state_items)
    summary = json.dumps(
        {
            "path": str(state_path),
            "section": section_name,
            "removed": removed_count,
            "items": removed_items,
        },
        ensure_ascii=False,
    )
    print(summary)
    return 0


def cmd_prune(
    state_path: Path,
    stale_days: int = 7,
    section: str | None = None,
    dry_run: bool = False,
) -> int:
    try:
        _validate_non_negative("stale-days", stale_days)
        targets = _target_sections(section)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    sections = load_state(state_path)
    removed = 0

    for sec in targets:
        kept: list[StateItem] = []
        for item in sections.get(sec, []):
            if is_stale(item, stale_days):
                removed += 1
                print(f"Prune target: [{item.date}] {item.text}", file=sys.stderr)
            else:
                kept.append(item)
        if not dry_run:
            sections[sec] = kept

    if not dry_run and removed > 0:
        save_state(state_path, sections)
    print(str(removed))
    return 0


def expire_stale_items(
    state_path: Path,
    stale_days: int = 30,
    archive_path: Path | None = None,
) -> dict[str, Any]:
    if stale_days < 1:
        raise ValueError("stale_days must be >= 1 (use 1 for items older than 1 day)")

    sections = load_state(state_path)
    expired_items: list[dict[str, str]] = []
    archive_sections = load_state(archive_path) if archive_path is not None else None
    focus_section = STATE_SHORT_KEYS["focus"]

    for sec in SECTION_ORDER:
        if sec == focus_section:
            continue

        kept: list[StateItem] = []
        expired_in_section: list[StateItem] = []
        for item in sections.get(sec, []):
            if is_stale(item, stale_days):
                expired_items.append({"section": sec, "text": item.text, "date": item.date})
                expired_in_section.append(item)
            else:
                kept.append(item)

        if archive_path is not None:
            sections[sec] = kept
            if archive_sections is not None and expired_in_section:
                archive_sections[sec] = archive_sections.get(sec, []) + expired_in_section

    expired_count = len(expired_items)
    archived = archive_path is not None and expired_count > 0

    if archived and archive_sections is not None:
        assert archive_path is not None
        save_state(archive_path, archive_sections)
        save_state(state_path, sections)

    return {
        "expired_items": expired_items,
        "count": expired_count,
        "archived": archived,
        "archive_path": str(archive_path) if archive_path is not None else None,
    }


def _collect_agent_state_files(memory_dir: Path) -> list[AgentStateFile]:
    files: list[AgentStateFile] = []
    for path in memory_dir.glob("_state.*.md"):
        match = _AGENT_STATE_FILE_RE.fullmatch(path.name)
        if match is None:
            continue
        try:
            mtime = path.stat().st_mtime
        except FileNotFoundError:
            continue
        files.append(
            AgentStateFile(
                path=path,
                agent_id=match.group("agent_id"),
                mtime=mtime,
            )
        )
    return files


def _plan_cleanup_targets(
    files: list[AgentStateFile],
    *,
    state_ttl_days: int,
    state_max_generations: int,
) -> list[tuple[AgentStateFile, tuple[str, ...]]]:
    reasons_by_path: dict[Path, set[str]] = {}

    ttl_cutoff = time.time() - (state_ttl_days * 24 * 60 * 60)
    stale_paths: set[Path] = set()
    for info in files:
        if info.mtime <= ttl_cutoff:
            stale_paths.add(info.path)
            reasons_by_path.setdefault(info.path, set()).add("ttl")

    grouped: dict[str, list[AgentStateFile]] = {}
    for info in files:
        if info.path in stale_paths:
            continue
        grouped.setdefault(info.agent_id, []).append(info)

    for grouped_files in grouped.values():
        newest_first = sorted(
            grouped_files,
            key=lambda row: (row.mtime, row.path.name),
            reverse=True,
        )
        overflow = newest_first[state_max_generations:]
        for info in overflow:
            reasons_by_path.setdefault(info.path, set()).add("generation")

    oldest_first = sorted(files, key=lambda row: (row.mtime, str(row.path)))
    return [
        (info, tuple(sorted(reasons_by_path[info.path])))
        for info in oldest_first
        if info.path in reasons_by_path
    ]


def cmd_cleanup(
    memory_dir: Path,
    state_ttl_days: int = 7,
    state_max_generations: int = 20,
    dry_run: bool = False,
) -> int:
    try:
        _validate_non_negative("state-ttl-days", state_ttl_days)
        _validate_non_negative("state-max-generations", state_max_generations)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    files = _collect_agent_state_files(memory_dir)
    targets = _plan_cleanup_targets(
        files,
        state_ttl_days=state_ttl_days,
        state_max_generations=state_max_generations,
    )

    removed = 0
    for info, reasons in targets:
        reason_text = "+".join(reasons)
        if dry_run:
            print(f"Cleanup target ({reason_text}): {info.path}", file=sys.stderr)
            continue
        try:
            info.path.unlink()
        except FileNotFoundError:
            continue
        except OSError as exc:
            print(
                f"Failed to remove ({reason_text}): {info.path} ({exc})",
                file=sys.stderr,
            )
            return 1
        removed += 1
        print(f"Removed ({reason_text}): {info.path}", file=sys.stderr)

    print(str(len(targets) if dry_run else removed))
    return 0


def _auto_prune(
    sections: dict[str, list[StateItem]],
    max_entries: int = 20,
) -> list[tuple[str, StateItem]]:
    """Trim each rolling section to max_entries by dropping the oldest timestamps.

    Returns list of dropped items.
    """
    safe_max = max(max_entries, 0)
    all_dropped: list[tuple[str, StateItem]] = []
    for sec in SECTION_ORDER:
        items = sections.get(sec, [])
        if len(items) <= safe_max:
            continue
        ranked = sorted(
            enumerate(items),
            key=lambda pair: (_parse_datetime(pair[1].date) or _dt.datetime.min, -pair[0]),
            reverse=True,
        )
        keep_indices = {idx for idx, _ in ranked[:safe_max]}
        dropped = [item for idx, item in enumerate(items) if idx not in keep_indices]
        all_dropped.extend((sec, item) for item in dropped)
        sections[sec] = [item for idx, item in enumerate(items) if idx in keep_indices]
    return all_dropped


def _extract_from_note(note_text: str) -> dict[str, list[str]]:
    secs = parse_sections(note_text)
    goal = bullets(get_section(secs, "目標"))
    nxt = bullets(get_section(secs, "次のアクション"))
    decisions = bullets(get_section(secs, "判断"))
    pitfalls = (
        bullets(get_section(secs, "注意点・残課題"))
        or bullets(get_section(secs, "注意点"))
        or bullets(get_section(secs, "Pitfalls"))
    )
    skills = [s for s in bullets(get_section(secs, "スキル候補")) if not _is_none_skill(s)]
    focus = goal[:3]

    return {
        STATE_SHORT_KEYS["focus"]: focus,
        STATE_SHORT_KEYS["open"]: nxt,
        STATE_SHORT_KEYS["decisions"]: decisions,
        STATE_SHORT_KEYS["pitfalls"]: pitfalls,
        STATE_SHORT_KEYS["skills"]: skills,
    }


def _normalize_note_path_for_index(note_path: Path, dailynote_dir: Path) -> str:
    try:
        return str(note_path.resolve().relative_to(dailynote_dir.resolve().parent))
    except ValueError:
        return str(note_path)


def _index_entry_is_stale(
    entry: dict[str, Any],
    note_path: Path,
    tolerance_seconds: float = INDEXED_AT_TOLERANCE_SECONDS,
) -> bool:
    indexed_at = parse_indexed_at(entry.get("indexed_at"))
    if indexed_at is None:
        return True
    try:
        note_mtime = note_path.stat().st_mtime
    except OSError:
        return False
    return (note_mtime - indexed_at.timestamp()) > tolerance_seconds


def _ensure_note_index_entry(
    entries: list[dict],
    note_path: Path | None,
    index_path: Path,
    max_summary_chars: int = 280,
) -> list[dict]:
    if note_path is None:
        return entries
    expected_path = _normalize_note_path_for_index(note_path, index_path.parent)
    matched_index: int | None = None
    matched_entry: dict[str, Any] | None = None
    for idx, entry in enumerate(entries):
        if isinstance(entry, dict) and str(entry.get("path", "")) == expected_path:
            matched_index = idx
            matched_entry = entry
            if not _index_entry_is_stale(entry, note_path):
                return entries
            break
    try:
        from agentic_memory.core import index

        refreshed_entry = index.index_note(
            note_path=note_path,
            index_path=index_path,
            dailynote_dir=index_path.parent,
            task_id=cast(str | None, matched_entry.get("task_id")) if matched_entry else None,
            agent_id=cast(str | None, matched_entry.get("agent_id")) if matched_entry else None,
            relay_session_id=(
                cast(str | None, matched_entry.get("relay_session_id")) if matched_entry else None
            ),
            max_summary_chars=max_summary_chars,
            no_dense=True,
        )
    except (OSError, ValueError):
        return entries
    if matched_index is None:
        return entries + [refreshed_entry]
    updated_entries = list(entries)
    updated_entries[matched_index] = refreshed_entry
    return updated_entries


def _auto_improve_from_signals(
    state_path: Path,
    index_path: Path,
    sections: dict[str, list[StateItem]],
    threshold: int = 3,
    note_path: Path | None = None,
    max_summary_chars: int = 280,
) -> tuple[list[StateItem], dict[str, Any]]:
    """Analyze skill signals and return improvement candidates as StateItems.

    Processes both high-severity candidates from analyze_signals() and
    additional triggers from check_improvement_triggers().
    Fail-safe: returns empty list on any error (missing index, parse error, etc.).
    """
    migration_summary = _empty_legacy_migration_summary()
    migration_summary["legacy_file_present"] = _legacy_improvement_resolved_path(
        state_path
    ).exists()
    try:
        entries: list[dict] = []
        if index_path.exists():
            entries = signals.load_index(index_path)
        entries = _ensure_note_index_entry(
            entries,
            note_path=note_path,
            index_path=index_path,
            max_summary_chars=max_summary_chars,
        )
        migration_summary = _migrate_legacy_improvement_resolutions(
            state_path,
            entries,
            threshold=threshold,
        )
        resolved_ids = _resolved_signal_id_set(state_path)
        aggregated = signals.aggregate_signals(entries, resolved_ids=resolved_ids)
        candidates = signals.analyze_signals(aggregated, threshold=threshold)
    except (OSError, ValueError, TypeError, KeyError):
        return [], migration_summary

    existing_keys = {
        item.normalize_key() for item in sections.get(STATE_SHORT_KEYS["improvements"], [])
    }

    new_items: list[StateItem] = []
    snapshot = _load_contributor_snapshot(state_path)

    # skill -> contributor_ids mapping (for triggers)
    skill_contributors: dict[str, list[str]] = {
        cand["skill"]: cand.get("contributor_ids", []) for cand in candidates
    }

    # High-severity candidates from analyze_signals
    for cand in candidates:
        if cand.get("severity") != "high":
            continue
        skill = cand.get("skill", "")
        score = cand.get("weighted_score", 0)
        suggestion = cand.get("suggestion", "")
        text = f"[severity:high] {skill} (score={score}) — {suggestion}"
        item = StateItem.from_text(text)
        if item.normalize_key() not in existing_keys:
            new_items.append(item)
            existing_keys.add(item.normalize_key())
            snapshot[item.normalize_key()] = cand.get("contributor_ids", [])

    # Additional triggers (periodic_review, pattern_escalation, gap_expansion)
    existing_backlog_texts = [
        item.text.lower() for item in sections.get(STATE_SHORT_KEYS["improvements"], [])
    ]
    triggers = signals.check_improvement_triggers(entries, candidates, existing_backlog_texts)
    for trig in triggers:
        ttype = trig.get("type", "")
        skill = trig.get("skill", "")
        detail = trig.get("detail", "")
        severity = trig.get("severity", "medium")
        text = f"[severity:{severity}][{ttype}] {skill} — {detail}"
        item = StateItem.from_text(text)
        if ttype == "periodic_review" and _has_recent_trigger_cooldown(
            state_path, "periodic_review", _PERIODIC_REVIEW_COOLDOWN_DAYS
        ):
            continue
        if item.normalize_key() not in existing_keys:
            new_items.append(item)
            existing_keys.add(item.normalize_key())
            # periodic_review 以外の trigger は candidate の contributor_ids を継承
            if ttype != "periodic_review" and skill in skill_contributors:
                snapshot[item.normalize_key()] = skill_contributors[skill]

    if new_items:
        _save_contributor_snapshot(state_path, snapshot)
    return new_items, migration_summary


_FROM_NOTE_CAP_BY_SECTION = {
    STATE_SHORT_KEYS["focus"]: 3,
    STATE_SHORT_KEYS["open"]: 8,
    STATE_SHORT_KEYS["decisions"]: 8,
    STATE_SHORT_KEYS["pitfalls"]: 8,
    STATE_SHORT_KEYS["skills"]: 8,
    STATE_SHORT_KEYS["improvements"]: 8,
}

_FROM_NOTE_MERGE_TARGETS = (
    STATE_SHORT_KEYS["focus"],
    STATE_SHORT_KEYS["open"],
    STATE_SHORT_KEYS["decisions"],
    STATE_SHORT_KEYS["pitfalls"],
    STATE_SHORT_KEYS["skills"],
)


def _resolve_index_path_for_note(note_path: Path, state_path: Path) -> Path:
    note_index_path = note_path.parent.parent / "_index.jsonl"
    if note_index_path.exists():
        return note_index_path
    return state_path.resolve().parent / "_index.jsonl"


def _merge_from_note(
    state_path: Path,
    note_path: Path,
    auto_improve_mode: AutoImproveMode | None = None,
    max_entries: int = 20,
) -> tuple[dict[str, list[StateItem]], list[str], int, dict[str, Any], dict[str, Any]]:
    """Merge note contents into rolling state.

    Returns:
        (sections, updated_sections, stale_count, diagnostics, auto_improve_summary) tuple.
    """
    note_text = note_path.read_text(encoding="utf-8", errors="ignore")
    sections = load_state(state_path)
    extracted = _extract_from_note(note_text)
    diagnostics: dict[str, Any] = {
        "cap_exceeded": [],
        "auto_pruned": [],
    }
    resolved_mode = _resolve_auto_improve_mode(auto_improve_mode)
    auto_improve_summary: dict[str, Any] = {
        "mode": resolved_mode,
        "candidate_count": 0,
        "added_count": 0,
    }

    for sec in _FROM_NOTE_MERGE_TARGETS:
        new_items: list[StateItem] = []
        for text in extracted.get(sec, []):
            try:
                new_items.append(StateItem.from_text(text))
            except ValueError:
                continue
        merged = deduplicate(new_items + sections.get(sec, []))
        sections[sec], dropped = enforce_cap(merged, _FROM_NOTE_CAP_BY_SECTION[sec])
        for item in dropped:
            diagnostics["cap_exceeded"].append(_serialize_state_change(sec, item))

    sections[STATE_SHORT_KEYS["improvements"]], dropped = enforce_cap(
        deduplicate(sections.get(STATE_SHORT_KEYS["improvements"], [])),
        _FROM_NOTE_CAP_BY_SECTION[STATE_SHORT_KEYS["improvements"]],
    )
    for item in dropped:
        diagnostics["cap_exceeded"].append(
            _serialize_state_change(STATE_SHORT_KEYS["improvements"], item)
        )

    # Auto-improve: analyze signals
    if resolved_mode != "skip":
        index_path = _resolve_index_path_for_note(note_path, state_path)
        auto_items, migration_summary = _auto_improve_from_signals(
            state_path,
            index_path,
            sections,
            note_path=note_path,
        )
        auto_improve_summary["candidate_count"] = len(auto_items)
        if auto_items:
            auto_improve_summary["candidates"] = [
                _serialize_improvement_candidate(item) for item in auto_items
            ]
        if migration_summary["legacy_entries_found"] > 0:
            auto_improve_summary["legacy_migration"] = migration_summary
        if auto_items and resolved_mode == "add":
            # Explicitly requested: add to backlog
            merged = deduplicate(auto_items + sections.get(STATE_SHORT_KEYS["improvements"], []))
            sections[STATE_SHORT_KEYS["improvements"]], dropped = enforce_cap(
                merged, _FROM_NOTE_CAP_BY_SECTION[STATE_SHORT_KEYS["improvements"]]
            )
            for item in dropped:
                diagnostics["cap_exceeded"].append(
                    _serialize_state_change(STATE_SHORT_KEYS["improvements"], item)
                )
            auto_improve_summary["added_count"] = len(auto_items)

    pruned = _auto_prune(sections, max_entries=max_entries)
    for section_name, item in pruned:
        diagnostics["auto_pruned"].append(_serialize_state_change(section_name, item))

    save_state(state_path, sections)

    stale_count = sum(
        1 for sec in SECTION_ORDER for item in sections.get(sec, []) if is_stale(item, 7)
    )
    updated_sections = list(extracted.keys())
    if STATE_SHORT_KEYS["improvements"] not in updated_sections:
        updated_sections.append(STATE_SHORT_KEYS["improvements"])
    if not diagnostics["cap_exceeded"]:
        diagnostics.pop("cap_exceeded")
    if not diagnostics["auto_pruned"]:
        diagnostics.pop("auto_pruned")
    return sections, updated_sections, stale_count, diagnostics, auto_improve_summary


def cmd_from_note(
    state_path: Path,
    note_path: Path,
    auto_improve_mode: AutoImproveMode | None = None,
    max_entries: int = 20,
) -> int:
    if not note_path.exists():
        print(f"{NOTE_NOT_FOUND_PREFIX}: {note_path}", file=sys.stderr)
        return 2

    try:
        _validate_non_negative("max-entries", max_entries)
        sections_data, updated_sections, stale_count, diagnostics, auto_improve_summary = (
            _merge_from_note(
                state_path=state_path,
                note_path=note_path,
                auto_improve_mode=auto_improve_mode,
                max_entries=max_entries,
            )
        )
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"{FAILED_TO_READ_NOTE_PREFIX}: {exc}", file=sys.stderr)
        return 2

    result: dict[str, Any] = {
        "path": str(state_path),
        "note": str(note_path),
        "updated_sections": updated_sections,
        "stale_count": stale_count,
        "section_counts": {sec: len(sections_data.get(sec, [])) for sec in SECTION_ORDER},
        "auto_improve": auto_improve_summary,
    }
    result.update(diagnostics)
    summary = json.dumps(result, ensure_ascii=False)
    print(summary)
    return 0


def auto_restore(
    *,
    memory_dir: Path,
    agent_id: str | None = None,
    relay_session_id: str | None = None,
    max_evidence_notes: int = 3,
    max_lines: int = 6,
    max_total_lines: int = 200,
    include_project_state: bool = True,
    include_agent_state: bool = True,
) -> dict[str, Any]:
    from agentic_memory.core import evidence, search
    from agentic_memory.core.scorer import IndexEntry

    project_state_path = memory_dir / "_state.md"
    project_sections = load_state(project_state_path)

    warnings: list[str] = []
    agent_sections: dict[str, list[StateItem]] | None = None
    resolved_agent_state_path: Path | None = None

    if include_agent_state and agent_id is None:
        include_agent_state = False

    if include_agent_state:
        assert agent_id is not None  # guaranteed by the guard above
        resolved_agent_state_path = resolve_agent_state_path(
            memory_dir,
            agent_id,
            relay_session_id,
            for_write=False,
        )
        ensure_state_file(resolved_agent_state_path)
        agent_sections = load_state(resolved_agent_state_path)

    if max_total_lines < 0:
        warnings.append("max_total_lines must be >= 0; using 0.")

    task_ids = extract_task_ids_from_focus(project_sections)
    if agent_sections is not None:
        for task_id in extract_task_ids_from_focus(agent_sections):
            if task_id not in task_ids:
                task_ids.append(task_id)

    active_tasks: list[dict[str, object]] = []
    referenced_paths: set[str] = set()

    for task_id in task_ids:
        try:
            search_result = search.search(
                query=task_id,
                memory_dir=memory_dir,
                task_id=task_id,
                agent_id=agent_id,
                relay_session_id=relay_session_id,
                top=max_evidence_notes,
                engine="auto",
            )
        except Exception as exc:
            warnings.append(f"{task_id}: search failed ({exc})")
            continue

        rows = search_result.get("results", [])
        resolved_paths: list[Path] = []
        related_notes: list[str] = []

        if isinstance(rows, list):
            for row in rows:
                if not isinstance(row, tuple) or len(row) < 2:
                    continue
                maybe_entry = row[1]
                if not isinstance(maybe_entry, IndexEntry):
                    continue
                note_path = _resolve_note_path_for_evidence(maybe_entry.path, memory_dir)
                if note_path in resolved_paths:
                    continue
                resolved_paths.append(note_path)
                related_notes.append(maybe_entry.path)
                referenced_paths.add(maybe_entry.path)
                if len(resolved_paths) >= max_evidence_notes:
                    break

        if not resolved_paths:
            warnings.append(f"{task_id}: no related notes found.")
            continue

        evidence_pack = ""
        try:
            evidence_pack = evidence.generate_evidence_pack(
                query=task_id,
                paths=resolved_paths,
                max_lines=max_lines,
            )
        except Exception as exc:
            warnings.append(f"{task_id}: evidence generation failed ({exc})")

        active_tasks.append(
            {
                "task_id": task_id,
                "related_notes": related_notes,
                "evidence_pack": evidence_pack,
            }
        )

    project_state = state_sections_to_rendered(project_sections) if include_project_state else None
    agent_state = (
        state_sections_to_rendered(agent_sections)
        if (include_agent_state and agent_sections is not None)
        else None
    )
    project_state, agent_state, active_tasks, truncated_parts = _apply_restore_line_budget(
        project_state=project_state,
        agent_state=agent_state,
        active_tasks=active_tasks,
        max_total_lines=max_total_lines,
    )

    result: dict[str, Any] = {
        "agent_id": agent_id,
        "relay_session_id": relay_session_id,
        "project_state": project_state,
        "agent_state": agent_state,
        "agent_state_path": str(resolved_agent_state_path) if resolved_agent_state_path else None,
        "active_tasks": active_tasks,
        "restored_task_count": len(active_tasks),
        "total_notes_referenced": len(referenced_paths),
        "warnings": warnings,
        "restored_at": _dt.datetime.now().isoformat(timespec="seconds"),
    }
    if truncated_parts:
        result["truncated"] = True
        result["truncated_reason"] = (
            f"restore output exceeded max_total_lines={max(max_total_lines, 0)}; "
            f"truncated {', '.join(truncated_parts)}."
        )
    return result
