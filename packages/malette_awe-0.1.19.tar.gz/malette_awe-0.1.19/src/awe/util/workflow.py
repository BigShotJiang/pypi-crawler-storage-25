from awe.util.logging import logger
from awe.util.tongyi import translate as tongyi_translate
from awe.util.workflow_assets import (
  MEDIA_INPUT_KEYS,
  append_image_path,
  build_comfyui_upload_url,
  build_image_node,
  build_remote_image_url,
  handle_image_result,
  handle_workflow_inputs,
  limit_input_value,
  resolve_remote_asset_url,
)
from awe.util import workflow_builder as _workflow_builder
from awe.util.workflow_builder import (
  NUMBER_PARAM_TYPES,
  TEXT_PARAM_TYPES,
  get_remote_workflow_from_oss,
  get_workflow_data,
)
from awe.util.workflow_response import (
  build_result,
  convert_to_old_data,
  convert_to_old_result,
  format_workflow_resp,
)

_builder_build_workflow = _workflow_builder.build_workflow
_builder_build_workflow_node = _workflow_builder.build_workflow_node


def contains_chinese(check_str):
  return _workflow_builder.contains_chinese(check_str)


def translate(text):
  logger.info(f"translate text: {text}")
  if contains_chinese(text):
    logger.info(f"contains chinese, use tongyi translate: {text}")
    return tongyi_translate(text)
  logger.info(f"not contains chinese, use origin text: {text}")
  return text


def build_workflow_node(key, param_node, params, node, node_id):
  _workflow_builder.translate = translate
  return _builder_build_workflow_node(key, param_node, params, node, node_id)


def build_workflow(workflow_data, params=None):
  _workflow_builder.translate = translate
  _workflow_builder.build_workflow_node = build_workflow_node
  return _builder_build_workflow(workflow_data, params)

__all__ = [
  "MEDIA_INPUT_KEYS",
  "NUMBER_PARAM_TYPES",
  "TEXT_PARAM_TYPES",
  "append_image_path",
  "build_comfyui_upload_url",
  "build_image_node",
  "build_remote_image_url",
  "build_result",
  "build_workflow",
  "build_workflow_node",
  "contains_chinese",
  "convert_to_old_data",
  "convert_to_old_result",
  "format_workflow_resp",
  "get_remote_workflow_from_oss",
  "get_workflow_data",
  "handle_image_result",
  "handle_workflow_inputs",
  "limit_input_value",
  "resolve_remote_asset_url",
  "tongyi_translate",
  "translate",
]
