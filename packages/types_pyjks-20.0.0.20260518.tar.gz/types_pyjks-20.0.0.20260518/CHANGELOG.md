## 20.0.0.20260518 (2026-05-18)

Upgrade black to 26.5.0 ([#15801](https://github.com/python/typeshed/pull/15801))

## 20.0.0.20260508 (2026-05-08)

Import some items from typing instead of typing_extensions ([#15711](https://github.com/python/typeshed/pull/15711))

Part of #13782

## 20.0.0.20260408 (2026-04-08)

Use dashes instead of underscores for METADATA.toml field names ([#15614](https://github.com/python/typeshed/pull/15614))

## 20.0.0.20260402 (2026-04-02)

Rename `requires` to `dependencies` in METADATA files ([#15594](https://github.com/python/typeshed/pull/15594))

Update mypy to 1.20.0 ([#15588](https://github.com/python/typeshed/pull/15588))

## 20.0.0.20240310 (2024-03-10)

Bump mypy to 1.9, add to json.encoder, small fixups ([#11549](https://github.com/python/typeshed/pull/11549))

Co-authored-by: Alex Waygood <Alex.Waygood@Gmail.com>

## 20.0.0.20240106 (2024-01-06)

Update typing_extensions imports in third-party stubs ([#11245](https://github.com/python/typeshed/pull/11245))

## 20.0.0.1 (2023-10-06)

[pyjks] Fill in jks.bks and other modules, improved constructors ([#10815](https://github.com/python/typeshed/pull/10815))

## 20.0.0.0 (2023-10-01)

Add stubs for `pyjks` ([#10797](https://github.com/python/typeshed/pull/10797))

Co-authored-by: Alex Waygood <Alex.Waygood@Gmail.com>

