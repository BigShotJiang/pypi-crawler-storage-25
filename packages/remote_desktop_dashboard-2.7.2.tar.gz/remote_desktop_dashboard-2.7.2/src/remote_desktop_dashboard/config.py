"""Application configuration."""

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


def _config_dir() -> Path:
    """Data folder without reading .env (uses RDD_DATA_DIR env or %LOCALAPPDATA%)."""
    import os

    configured = (os.environ.get("RDD_DATA_DIR") or "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    local = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA")
    if local:
        return (Path(local) / "RemoteDesktopDashboard").resolve()
    return (Path.home() / "RemoteDesktopDashboard").resolve()


def resolve_env_files() -> tuple[str, ...]:
    """User .env then admin.env (admin values override)."""
    root = _config_dir()
    files: list[str] = []
    for name in (".env", "admin.env"):
        path = root / name
        if path.is_file():
            files.append(str(path))
    return tuple(files)


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_prefix="RDD_",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    database_url: str = "sqlite:///remote_desktop_dashboard.db"
    data_dir: str = ""
    host: str = "0.0.0.0"
    port: int = 8080
    reload: bool = False
    offline_threshold_seconds: int = 90
    reachability_check: bool = True
    reachability_on_api: bool = False
    reachability_background: bool = True
    reachability_cache_seconds: int = 30
    reachability_timeout_seconds: float = 1.5
    reachability_max_workers: int = 8
    agent_api_key: str = ""
    static_dir: Path | None = None
    open_browser: bool = True
    auto_seed: bool = True

    lock_timeout_seconds: int = 120
    lock_heartbeat_grace_seconds: int = 90

    rdp_port: int = 3389
    rdp_default_domain: str = ""
    local_launcher_enabled: bool = True
    local_launcher_port: int = 9876
    preferred_rdp_client: str = "windows_app"
    msrdc_path: str = ""
    rdp_prompt_credentials: bool = True

    poller_enabled: bool = True
    poll_interval_seconds: int = 60
    poll_startup_delay_seconds: int = 2
    poll_max_workers: int = 4
    poll_timeout_seconds: float = 30.0
    poll_session_timeout_seconds: float = 15.0
    poll_ping_timeout_seconds: float = 3.0
    poll_skip_unreachable: bool = True
    settings_test_timeout_seconds: float = 65.0
    poll_prefer_ip: bool = True
    poll_users_timeout_seconds: float = 8.0
    rdp_guard_enabled: bool = True
    rdp_guard_timeout_seconds: float = 8.0
    rdp_guard_extra_ips: str = ""

    monitor_username: str = ""
    monitor_password: str = ""
    monitor_domain: str = ""
    settings_secret_key: str = ""
    admin_pin: str = ""

    # admin.env — operator permissions
    users_can_connect: bool = True
    users_can_release_own_lock: bool = True
    users_can_manage_machines: bool = False

    @property
    def resolved_static_dir(self) -> Path:
        if self.static_dir:
            return self.static_dir
        return Path(__file__).parent / "static"

    @property
    def admin_pin_required(self) -> bool:
        return bool((self.admin_pin or "").strip())

    @property
    def config_directory(self) -> Path:
        if (self.data_dir or "").strip():
            return Path(self.data_dir).expanduser().resolve()
        return _config_dir()


def permissions_dict() -> dict:
    s = get_settings()
    return {
        "users_can_connect": s.users_can_connect,
        "users_can_release_own_lock": s.users_can_release_own_lock,
        "users_can_manage_machines": s.users_can_manage_machines,
    }


@lru_cache
def get_settings() -> Settings:
    env_files = resolve_env_files()
    if env_files:
        return Settings(_env_file=env_files)
    return Settings()
