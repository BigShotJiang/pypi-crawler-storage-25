"""Pydantic schemas for machines."""

import json
from datetime import datetime

from pydantic import BaseModel, Field, field_validator


def _parse_json_list(value: str | list[str]) -> list[str]:
    if isinstance(value, list):
        return value
    if not value:
        return []
    try:
        parsed = json.loads(value)
        return parsed if isinstance(parsed, list) else []
    except json.JSONDecodeError:
        return []


class MachineBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=32, examples=["ATC1"])
    hostname: str = Field(..., max_length=255)
    ip_address: str = Field(..., max_length=45)


class MachineCreate(MachineBase):
    pass


class MachineUpdate(BaseModel):
    hostname: str | None = None
    ip_address: str | None = None


class MachineStatusReport(BaseModel):
    """Payload sent by the Windows monitoring agent."""

    machine_name: str
    local_user: str | None = None
    rdp_users: list[str] = Field(default_factory=list)
    windows_app_users: list[str] = Field(default_factory=list)
    mobaxterm_user: str | None = None
    com_port_user: str | None = None
    etgui_user: str | None = None
    camera_user: str | None = None
    camera_tools: list[str] = Field(default_factory=list)
    agent_version: str | None = "1.0.0"
    raw_report: dict | None = None


class MachineRead(MachineBase):
    id: int
    is_online: bool
    last_seen: datetime | None
    local_user: str | None
    rdp_users: list[str]
    windows_app_users: list[str]
    mobaxterm_user: str | None
    com_port_user: str | None
    etgui_user: str | None
    camera_user: str | None
    camera_tools: list[str]
    locked_by: str | None = None
    locked_at: datetime | None = None
    lock_heartbeat_at: datetime | None = None
    lock_rdp_username: str | None = None
    agent_version: str | None
    updated_at: datetime

    model_config = {"from_attributes": True}

    @field_validator("rdp_users", "windows_app_users", "camera_tools", mode="before")
    @classmethod
    def coerce_json_lists(cls, value: str | list[str]) -> list[str]:
        return _parse_json_list(value)


class ConnectRequest(BaseModel):
    """Start a remote session via Windows App / RDP protocol (no file download)."""

    operator: str = Field(..., min_length=1, max_length=128, description="Your display name")
    rdp_username: str | None = Field(
        default=None,
        max_length=256,
        description="Windows login (DOMAIN\\user or user). Password entered in Windows App.",
    )
    use_hostname: bool = Field(
        default=True,
        description="Connect using hostname (False = use IP address)",
    )


class LockHeartbeatRequest(BaseModel):
    operator: str = Field(..., min_length=1, max_length=128)
    admin_pin: str | None = Field(
        default=None,
        description="Required to release when RDD_USERS_CAN_RELEASE_OWN_LOCK=false",
    )


class AdminReleaseRequest(BaseModel):
    admin_pin: str | None = None


class ConnectResponse(BaseModel):
    machine_name: str
    locked_by: str
    launch_uri: str
    fallback_uri: str
    windows_app_uri: str
    rdp_uri: str
    mstsc_command: str
    powershell_command: str
    local_launch_url: str | None = None
    rdp_download_url: str | None = None
    client: str
    target_host: str
    message: str
    machine: dict | None = None


class DashboardMachine(MachineRead):
    """Machine row enriched for the dashboard UI."""

    status_label: str = "unknown"
    status_display: str = "Unknown"
    is_reachable: bool = False
    logged_in_users: list[str] = Field(default_factory=list)
    has_user_data: bool = False
    last_seen_relative: str | None = None
    is_locked: bool = False
    lock_available: bool = True
    poll_error: str | None = None
