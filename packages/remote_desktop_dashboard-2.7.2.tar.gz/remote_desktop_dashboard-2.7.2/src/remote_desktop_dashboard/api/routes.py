"""REST API routes."""

import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import Response
from sqlalchemy.orm import Session

from remote_desktop_dashboard.api.deps import verify_agent_key
from remote_desktop_dashboard.crud.lock import (
    LockError,
    acquire_lock,
    admin_force_release,
    heartbeat_lock,
    is_locked_by_other,
    refresh_expired_locks,
    release_lock,
)
from remote_desktop_dashboard.crud.machine import (
    apply_status_report,
    create_machine,
    delete_machine,
    get_machine,
    get_machine_by_name,
    list_machines,
    refresh_online_flags,
    update_machine,
)
from remote_desktop_dashboard.database import get_db
from remote_desktop_dashboard.agent.monitor import MonitorSnapshot
from remote_desktop_dashboard.schemas.machine import (
    AdminReleaseRequest,
    ConnectRequest,
    ConnectResponse,
    LockHeartbeatRequest,
    MachineCreate,
    MachineRead,
    MachineStatusReport,
    MachineUpdate,
)
from remote_desktop_dashboard.schemas.settings import (
    MonitorSettingsRead,
    MonitorSettingsTest,
    MonitorSettingsWrite,
)
from remote_desktop_dashboard.services.connection_manager import manager
from remote_desktop_dashboard.services.dashboard import (
    bench_host,
    machines_payload,
    to_dashboard_machine,
)
from remote_desktop_dashboard.services.rdp_guard import (
    schedule_apply_rdp_guard,
    schedule_clear_rdp_guard,
)

logger = logging.getLogger(__name__)
from remote_desktop_dashboard.services.rdp_launch import (
    build_launch_uris,
    build_rdp_file_content,
    local_launch_url,
)
from remote_desktop_dashboard.config import get_settings, permissions_dict
from remote_desktop_dashboard.services.reachability_cache import get_cached_reachability

router = APIRouter(prefix="/api/v1")


def _machine_or_404(db: Session, machine_name: str):
    machine = get_machine_by_name(db, machine_name)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return machine


def _is_loopback(ip: str) -> bool:
    ip = (ip or "").strip().lower()
    return ip in ("127.0.0.1", "::1", "localhost") or ip.startswith("127.")


def _client_ip(request: Request) -> str:
    """Client IP for RDP firewall allow rules (must match the PC running Windows App)."""
    for header in ("X-Forwarded-For", "X-Real-IP", "CF-Connecting-IP"):
        raw = request.headers.get(header)
        if raw:
            ip = raw.split(",")[0].strip()
            if ip and not _is_loopback(ip):
                return ip
    if request.client and request.client.host:
        host = request.client.host.strip()
        return host
    return ""


def _prepare_machines(
    db: Session, *, check_reachability: bool = False, refresh_locks: bool = True
):
    refresh_online_flags(db)
    if refresh_locks:
        refresh_expired_locks(db, remote_firewall=False)
    machines = list_machines(db)
    settings = get_settings()
    do_check = check_reachability and settings.reachability_check
    if do_check and settings.reachability_check:
        reachability = get_cached_reachability(machines, allow_refresh=True)
    else:
        reachability = get_cached_reachability(machines, allow_refresh=False)
    return machines, reachability


@router.get("/machines", response_model=list[MachineRead])
def api_list_machines(db: Session = Depends(get_db)) -> list[MachineRead]:
    machines, _ = _prepare_machines(db)
    return [MachineRead.model_validate(m) for m in machines]


@router.get("/machines/{machine_id}", response_model=MachineRead)
def api_get_machine(machine_id: int, db: Session = Depends(get_db)) -> MachineRead:
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    return MachineRead.model_validate(machine)


@router.post("/machines", response_model=MachineRead, status_code=status.HTTP_201_CREATED)
async def api_create_machine(
    data: MachineCreate,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> MachineRead:
    _require_manage_machines(admin_pin)
    existing = get_machine_by_name(db, data.name)
    if existing:
        raise HTTPException(status_code=409, detail="Machine name already exists")
    machine = create_machine(db, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.patch("/machines/{machine_id}", response_model=MachineRead)
async def api_update_machine(
    machine_id: int,
    data: MachineUpdate,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> MachineRead:
    _require_manage_machines(admin_pin)
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    machine = update_machine(db, machine, data)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.delete("/machines/{machine_id}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine(
    machine_id: int,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> None:
    _require_manage_machines(admin_pin)
    machine = get_machine(db, machine_id)
    if machine is None:
        raise HTTPException(status_code=404, detail="Machine not found")
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.delete("/machines/by-name/{machine_name}", status_code=status.HTTP_204_NO_CONTENT)
async def api_delete_machine_by_name(
    machine_name: str,
    admin_pin: str | None = Query(None),
    db: Session = Depends(get_db),
) -> None:
    _require_manage_machines(admin_pin)
    machine = _machine_or_404(db, machine_name)
    delete_machine(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))


@router.post(
    "/machines/{machine_name}/status",
    response_model=MachineRead,
    dependencies=[Depends(verify_agent_key)],
)
async def api_post_status(
    machine_name: str,
    report: MachineStatusReport,
    db: Session = Depends(get_db),
) -> MachineRead:
    report.machine_name = machine_name.upper()
    try:
        machine = apply_status_report(db, report)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.get("/dashboard/fast")
def api_dashboard_fast(
    operator: str | None = None,
    db: Session = Depends(get_db),
) -> dict:
    """Dashboard with cached online/offline (never blocks on TCP refresh)."""
    refresh_online_flags(db)
    refresh_expired_locks(db, remote_firewall=False)
    machines = list_machines(db)
    reach = get_cached_reachability(machines, allow_refresh=False)
    return {
        **_dashboard_meta(),
        "machines": [
            to_dashboard_machine(m, operator, reach.get(m.name, False)).model_dump(mode="json")
            for m in machines
        ],
    }


def _verify_admin_pin(pin: str | None) -> None:
    required = (get_settings().admin_pin or "").strip()
    if not required:
        return
    if not pin or pin.strip() != required:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid admin PIN",
        )


def _require_users_can_connect() -> None:
    if not get_settings().users_can_connect:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Connecting is disabled in admin.env (RDD_USERS_CAN_CONNECT=false).",
        )


def _require_manage_machines(admin_pin: str | None = None) -> None:
    if get_settings().users_can_manage_machines:
        return
    _verify_admin_pin(admin_pin)
    if not (get_settings().admin_pin or "").strip():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Machine management requires admin.env (RDD_USERS_CAN_MANAGE_MACHINES or RDD_ADMIN_PIN).",
        )


def _dashboard_meta() -> dict:
    from remote_desktop_dashboard.services.monitor_credentials import (
        credentials_hint,
        monitor_credentials_source,
        resolve_monitor_credentials,
    )

    settings = get_settings()
    creds = resolve_monitor_credentials()
    data_dir = settings.config_directory
    return {
        "monitor_configured": creds is not None,
        "monitor_hint": None if creds else credentials_hint(),
        "monitor_source": monitor_credentials_source(),
        "poller_enabled": settings.poller_enabled,
        "admin_pin_required": settings.admin_pin_required,
        "config_dir": str(data_dir),
        "user_env_file": str(data_dir / ".env"),
        "admin_env_file": str(data_dir / "admin.env"),
        **permissions_dict(),
    }


@router.get("/dashboard")
def api_dashboard(
    operator: str | None = None,
    db: Session = Depends(get_db),
) -> dict:
    machines, reachability = _prepare_machines(db, check_reachability=False)
    return {
        **_dashboard_meta(),
        "machines": [
            to_dashboard_machine(m, operator, reachability.get(m.name, False)).model_dump(
                mode="json"
            )
            for m in machines
        ],
    }


@router.post("/machines/{machine_name}/connect", response_model=ConnectResponse)
async def api_connect(
    machine_name: str,
    body: ConnectRequest,
    request: Request,
    db: Session = Depends(get_db),
) -> ConnectResponse:
    _require_users_can_connect()
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if is_locked_by_other(machine, body.operator):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Machine is in use by {machine.locked_by}. "
                "They must release it, or an admin can force release."
            ),
        )
    client_ip = _client_ip(request)
    try:
        acquire_lock(
            db,
            machine,
            body.operator,
            body.rdp_username,
            client_ip=client_ip or None,
            skip_expired_refresh=True,
        )
    except LockError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    settings = get_settings()
    guard_host = bench_host(machine, prefer_ip=settings.poll_prefer_ip)
    allow_ips = [client_ip] if client_ip else []
    if machine.lock_client_ip and machine.lock_client_ip not in allow_ips:
        allow_ips.append(machine.lock_client_ip)
    if settings.rdp_guard_enabled and allow_ips:
        schedule_apply_rdp_guard(guard_host, allow_ips)
    elif settings.rdp_guard_enabled and _is_loopback(client_ip):
        logger.warning(
            "RDP guard: client IP is loopback (%s). Set RDD_RDP_GUARD_EXTRA_IPS in admin.env "
            "to your PC's LAN address.",
            client_ip,
        )

    target = machine.hostname if body.use_hostname else machine.ip_address
    domain = None
    username = body.rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")

    uris = build_launch_uris(target, username=username, domain=domain)
    launch_url = local_launch_url(target, username=username, domain=domain)

    db.refresh(machine)
    reachability = get_cached_reachability([machine], allow_refresh=False)
    row = to_dashboard_machine(
        machine, body.operator, reachability.get(machine.name, False)
    )
    machines, reach_all = _prepare_machines(db, check_reachability=False)
    asyncio.create_task(
        manager.broadcast(
            machines_payload(machines, body.operator, reachability=reach_all)
        )
    )

    client = uris["client"]
    if client in ("windows_app", "windows365", "msrdc"):
        msg = f"Connecting directly to {target} via Windows App (msrdc)…"
    elif not uris["msrdc_found"]:
        msg = (
            "Windows App not found on this PC — use Download .rdp below, "
            "or set RDD_MSRDC_PATH on the server."
        )
    else:
        msg = "Opening remote session — sign in when prompted."

    if settings.rdp_guard_enabled and not allow_ips:
        msg += (
            " Direct RDP blocking needs your PC's IP in admin.env "
            "(RDD_RDP_GUARD_EXTRA_IPS) when the dashboard is opened on localhost."
        )
    elif settings.rdp_guard_enabled:
        msg += " Direct RDP from other PCs is being blocked on the bench (may take a few seconds)."

    rdp_dl = f"/api/v1/machines/{machine.name}/session.rdp"
    if body.rdp_username:
        rdp_dl += f"?operator={body.operator}"

    return ConnectResponse(
        machine_name=machine.name,
        locked_by=body.operator,
        launch_uri=uris["primary_uri"],
        fallback_uri=uris["fallback_uri"],
        windows_app_uri=uris["rdp_uri"],
        rdp_uri=uris["rdp_uri"],
        mstsc_command=uris["mstsc_command"],
        powershell_command=uris["powershell_command"],
        local_launch_url=launch_url,
        rdp_download_url=rdp_dl,
        client=client,
        target_host=target,
        message=msg,
        machine=row.model_dump(mode="json"),
    )


@router.get("/machines/{machine_name}/session.rdp")
def download_session_rdp(
    machine_name: str,
    operator: str | None = Query(None),
    use_hostname: bool = Query(True),
    rdp_username: str | None = Query(None),
    db: Session = Depends(get_db),
) -> Response:
    """Download .rdp file — works from any PC (uses that PC's default RDP client)."""
    machine = _machine_or_404(db, machine_name)
    refresh_expired_locks(db, remote_firewall=False)
    db.refresh(machine)
    if operator and is_locked_by_other(machine, operator):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Machine is reserved by {machine.locked_by}. Connect through the dashboard.",
        )
    target = machine.hostname if use_hostname else machine.ip_address
    domain = None
    username = rdp_username or machine.lock_rdp_username
    if username and "\\" in username:
        domain, _, username = username.partition("\\")
    content = build_rdp_file_content(target, username=username, domain=domain)
    filename = f"{machine.name}.rdp"
    return Response(
        content=content,
        media_type="application/rdp",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/machines/{machine_name}/poll-now")
async def api_poll_now(
    machine_name: str,
    operator: str | None = Query(None),
    db: Session = Depends(get_db),
) -> dict:
    """Poll one machine in the background (does not block the HTTP worker)."""
    machine = _machine_or_404(db, machine_name)
    if not get_settings().poller_enabled:
        raise HTTPException(
            status_code=400,
            detail="Poller is disabled. Start server without --no-poller.",
        )
    if sys.platform != "win32":
        raise HTTPException(status_code=400, detail="Polling requires a Windows server.")

    from remote_desktop_dashboard.services.monitor_credentials import resolve_monitor_credentials
    from remote_desktop_dashboard.services.poller import poll_single_machine

    if resolve_monitor_credentials() is None:
        raise HTTPException(
            status_code=400,
            detail=(
                "Server monitor credentials not set. Open Server settings and save "
                "domain, username, and password."
            ),
        )

    limit = get_settings().poll_timeout_seconds + 10.0
    try:
        ok, err = await asyncio.wait_for(
            asyncio.to_thread(poll_single_machine, machine.name),
            timeout=limit,
        )
    except asyncio.TimeoutError:
        raise HTTPException(
            status_code=504,
            detail=f"Poll timed out after {int(limit)}s — bench may be slow or unreachable.",
        ) from None

    db.refresh(machine)
    machines, reachability = _prepare_machines(db, check_reachability=False)
    row = to_dashboard_machine(
        machine, operator, reachability.get(machine.name, False)
    )
    await manager.broadcast(machines_payload(machines, operator, reachability))
    return {
        "ok": ok,
        "status": "done",
        "error": err,
        "machine": row.model_dump(mode="json"),
    }


@router.post("/machines/{machine_name}/lock/heartbeat", response_model=MachineRead)
async def api_lock_heartbeat(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    try:
        machine = heartbeat_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, body.operator, reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/release", response_model=MachineRead)
async def api_lock_release(
    machine_name: str,
    body: LockHeartbeatRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    machine = _machine_or_404(db, machine_name)
    settings = get_settings()
    if not settings.users_can_release_own_lock:
        _verify_admin_pin(body.admin_pin)
    allow: list[str] = []
    if machine.lock_client_ip:
        allow.append(machine.lock_client_ip)
    try:
        machine = release_lock(db, machine, body.operator)
    except LockError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    schedule_clear_rdp_guard(bench_host(machine, prefer_ip=settings.poll_prefer_ip), allow)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.post("/machines/{machine_name}/lock/admin-release", response_model=MachineRead)
async def api_admin_release(
    machine_name: str,
    body: AdminReleaseRequest,
    db: Session = Depends(get_db),
) -> MachineRead:
    """Admin: clear lock and RDP firewall rules without being the lock owner."""
    _verify_admin_pin(body.admin_pin)
    machine = _machine_or_404(db, machine_name)
    settings = get_settings()
    allow: list[str] = []
    if machine.lock_client_ip:
        allow.append(machine.lock_client_ip)
    schedule_clear_rdp_guard(bench_host(machine, prefer_ip=settings.poll_prefer_ip), allow)
    machine = admin_force_release(db, machine)
    machines, reachability = _prepare_machines(db)
    await manager.broadcast(machines_payload(machines, reachability=reachability))
    return MachineRead.model_validate(machine)


@router.get("/settings/monitor", response_model=MonitorSettingsRead)
def api_get_monitor_settings(db: Session = Depends(get_db)) -> MonitorSettingsRead:
    from remote_desktop_dashboard.services.monitor_credentials import (
        monitor_credentials_source,
    )
    from remote_desktop_dashboard.services.settings_store import get_monitor_credentials_dict

    source = monitor_credentials_source()
    if source == "database":
        data = get_monitor_credentials_dict(db) or {}
        return MonitorSettingsRead(
            configured=True,
            domain=data.get("domain", ""),
            username=data.get("username", ""),
            password_set=True,
            source=source,
        )
    if source == "environment":
        s = get_settings()
        return MonitorSettingsRead(
            configured=True,
            domain=s.monitor_domain,
            username=s.monitor_username,
            password_set=bool(s.monitor_password),
            source=source,
        )
    return MonitorSettingsRead(configured=False, source="none")


@router.put("/settings/monitor", response_model=MonitorSettingsRead)
def api_save_monitor_settings(
    body: MonitorSettingsWrite,
    db: Session = Depends(get_db),
) -> MonitorSettingsRead:
    from remote_desktop_dashboard.services.settings_store import save_monitor_credentials

    _verify_admin_pin(body.admin_pin)
    try:
        save_monitor_credentials(
            db,
            domain=body.domain,
            username=body.username,
            password=body.password,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return api_get_monitor_settings(db)


@router.post("/settings/monitor/test")
async def api_test_monitor_settings(body: MonitorSettingsTest) -> dict:
    from remote_desktop_dashboard.services.monitor_credentials import (
        resolve_monitor_credentials,
    )
    from remote_desktop_dashboard.services.remote_users import probe_logged_in_users

    _verify_admin_pin(body.admin_pin)
    if resolve_monitor_credentials() is None:
        raise HTTPException(
            status_code=400,
            detail="Save monitor credentials first (Server settings).",
        )
    host = body.host.strip()
    limit = get_settings().settings_test_timeout_seconds + 3.0

    def _run() -> MonitorSnapshot:
        snap = probe_logged_in_users(host)
        return MonitorSnapshot(
            local_user=snap.local_user,
            rdp_users=snap.rdp_users,
            raw=snap.raw,
        )

    try:
        snap = await asyncio.wait_for(asyncio.to_thread(_run), timeout=limit)
    except asyncio.TimeoutError:
        return {
            "ok": False,
            "message": (
                f"Timed out after {int(limit)}s. Check IP, firewall, and that the service "
                "account can run remote tasklist on that bench."
            ),
        }
    except Exception as exc:
        return {"ok": False, "message": str(exc)}
    proc_n = snap.raw.get("process_count", 0) if isinstance(snap.raw, dict) else 0
    session_err = snap.raw.get("session_error") if isinstance(snap.raw, dict) else None
    return {
        "ok": True,
        "message": (
            f"OK — {proc_n} processes, local_user={snap.local_user!r}, "
            f"rdp_users={snap.rdp_users!r}, windows_app={snap.windows_app_users!r}, "
            f"mobaxterm={snap.mobaxterm_user!r}"
        ),
        "local_user": snap.local_user,
        "rdp_users": snap.rdp_users,
        "windows_app_users": snap.windows_app_users,
        "mobaxterm_user": snap.mobaxterm_user,
        "session_error": session_err,
    }
