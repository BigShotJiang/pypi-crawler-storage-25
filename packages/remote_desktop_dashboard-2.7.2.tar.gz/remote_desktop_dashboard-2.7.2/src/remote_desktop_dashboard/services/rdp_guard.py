"""Block direct RDP to a bench while the dashboard holds a lock (Windows Firewall via remote netsh)."""

from __future__ import annotations

import logging
import re
import sys
import threading

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.monitor_credentials import (
    MonitorCredentials,
    resolve_monitor_credentials,
)
from remote_desktop_dashboard.services.windows_cmd import run_cmd, system32_exe

logger = logging.getLogger(__name__)

RULE_BLOCK = "RDD-Guard-Block-RDP"
RULE_ALLOW_PREFIX = "RDD-Guard-Allow-"


def _sanitize_rule_suffix(ip: str) -> str:
    return re.sub(r"[^0-9A-Za-z]", "-", ip)


def _netsh_remote(
    host: str,
    creds: MonitorCredentials,
    subcommand: list[str],
    timeout: float,
) -> None:
    netsh = system32_exe("netsh.exe")
    args = [
        netsh,
        "-r",
        host.strip().strip("\\"),
        "-u",
        creds.tasklist_user_arg(),
        "-p",
        creds.password,
        *subcommand,
    ]
    run_cmd(args, timeout)


def _delete_rule(host: str, creds: MonitorCredentials, name: str, timeout: float) -> None:
    try:
        _netsh_remote(
            host,
            creds,
            ["advfirewall", "firewall", "delete", "rule", f"name={name}"],
            timeout,
        )
    except Exception as exc:
        logger.debug("Delete firewall rule %s on %s: %s", name, host, exc)


def _collect_allow_ips(allow_ips: list[str] | None) -> list[str]:
    settings = get_settings()
    ips: list[str] = []
    for ip in allow_ips or []:
        s = (ip or "").strip()
        if s and s not in ips:
            ips.append(s)
    for ip in settings.rdp_guard_extra_ips.split(","):
        s = ip.strip()
        if s and s not in ips:
            ips.append(s)
    return ips


def clear_rdp_guard(host: str, allow_ips: list[str] | None = None) -> None:
    """Remove dashboard RDP firewall rules from the bench."""
    if sys.platform != "win32":
        return
    settings = get_settings()
    if not settings.rdp_guard_enabled:
        return

    creds = resolve_monitor_credentials()
    if creds is None:
        return

    target = host.strip().strip("\\")
    timeout = settings.rdp_guard_timeout_seconds
    _delete_rule(target, creds, RULE_BLOCK, timeout)
    for ip in _collect_allow_ips(allow_ips):
        _delete_rule(
            target,
            creds,
            f"{RULE_ALLOW_PREFIX}{_sanitize_rule_suffix(ip)}",
            timeout,
        )
    logger.info("RDP guard cleared on %s", target)


def apply_rdp_guard(host: str, allow_ips: list[str]) -> bool:
    """
    On the bench: block inbound RDP except from allow_ips.
    Allow rules are added before the block rule (Windows evaluates allows first).
    Returns True if rules were applied (False if disabled or failed).
    """
    if sys.platform != "win32":
        return False
    settings = get_settings()
    if not settings.rdp_guard_enabled:
        return False

    creds = resolve_monitor_credentials()
    if creds is None:
        logger.warning("RDP guard skipped — no monitor credentials")
        return False

    ips = _collect_allow_ips(allow_ips)
    if not ips:
        logger.warning("RDP guard skipped — no client IP to allow")
        return False

    target = host.strip().strip("\\")
    timeout = settings.rdp_guard_timeout_seconds
    port = settings.rdp_port

    clear_rdp_guard(target, ips)

    try:
        for ip in ips:
            allow_name = f"{RULE_ALLOW_PREFIX}{_sanitize_rule_suffix(ip)}"
            _netsh_remote(
                target,
                creds,
                [
                    "advfirewall",
                    "firewall",
                    "add",
                    "rule",
                    f"name={allow_name}",
                    "dir=in",
                    "action=allow",
                    "protocol=TCP",
                    f"localport={port}",
                    f"remoteip={ip}",
                    "profile=any",
                    "enable=yes",
                ],
                timeout,
            )
        _netsh_remote(
            target,
            creds,
            [
                "advfirewall",
                "firewall",
                "add",
                "rule",
                f"name={RULE_BLOCK}",
                "dir=in",
                "action=block",
                "protocol=TCP",
                f"localport={port}",
                "profile=any",
                "enable=yes",
            ],
            timeout,
        )
        logger.info("RDP guard enabled on %s (allow: %s)", target, ", ".join(ips))
        return True
    except Exception as exc:
        logger.warning("Could not enable RDP guard on %s: %s", target, exc)
        return False


def schedule_apply_rdp_guard(host: str, allow_ips: list[str]) -> None:
    """Apply firewall rules without blocking the HTTP connect response."""
    ips = list(allow_ips)

    def _run() -> None:
        try:
            apply_rdp_guard(host, ips)
        except Exception as exc:
            logger.warning("Background RDP guard failed on %s: %s", host, exc)

    threading.Thread(
        target=_run,
        name=f"rdd-guard-apply-{host}",
        daemon=True,
    ).start()


def schedule_clear_rdp_guard(host: str, allow_ips: list[str] | None = None) -> None:
    """Remove firewall rules in the background (release / expiry)."""
    ips = list(allow_ips or [])

    def _run() -> None:
        try:
            clear_rdp_guard(host, ips)
        except Exception as exc:
            logger.debug("Background RDP guard clear on %s: %s", host, exc)

    threading.Thread(
        target=_run,
        name=f"rdd-guard-clear-{host}",
        daemon=True,
    ).start()
