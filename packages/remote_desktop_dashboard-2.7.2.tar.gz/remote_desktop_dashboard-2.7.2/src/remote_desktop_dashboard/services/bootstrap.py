"""First-run layout: user .env, admin.env, and SQLite schema upgrades."""

from __future__ import annotations

import logging
import shutil
from pathlib import Path

from sqlalchemy import inspect, text

logger = logging.getLogger(__name__)

_PKG_DATA = Path(__file__).resolve().parent.parent / "data"

# column_name -> SQL type for SQLite ALTER (migrations 002 + 003)
_MACHINE_COLUMNS: dict[str, str] = {
    "locked_by": "VARCHAR(128)",
    "locked_at": "DATETIME",
    "lock_heartbeat_at": "DATETIME",
    "lock_rdp_username": "VARCHAR(256)",
    "lock_client_ip": "VARCHAR(45)",
}


def bundled_env_template(name: str) -> Path:
    path = _PKG_DATA / name
    if not path.is_file():
        raise FileNotFoundError(f"Missing bundled config template: {path}")
    return path


def ensure_config_files(data_dir: Path) -> tuple[Path, Path]:
    """Create .env and admin.env in the per-user data folder if missing."""
    data_dir.mkdir(parents=True, exist_ok=True)
    user_env = data_dir / ".env"
    admin_env = data_dir / "admin.env"

    if not user_env.is_file():
        shutil.copy2(bundled_env_template("default.env"), user_env)
        logger.info("Created user config: %s", user_env)
    if not admin_env.is_file():
        shutil.copy2(bundled_env_template("admin.env"), admin_env)
        logger.info("Created admin config: %s", admin_env)

    return user_env, admin_env


def upgrade_database_schema(engine) -> None:
    """Add any missing columns on existing SQLite DBs (pip install without alembic CLI)."""
    inspector = inspect(engine)
    if "machines" not in inspector.get_table_names():
        return
    existing = {col["name"] for col in inspector.get_columns("machines")}
    with engine.begin() as conn:
        for name, sql_type in _MACHINE_COLUMNS.items():
            if name in existing:
                continue
            conn.execute(text(f"ALTER TABLE machines ADD COLUMN {name} {sql_type}"))
            logger.info("Added machines.%s", name)


def bootstrap_install_layout() -> Path:
    """
    Call before loading settings / starting the server.
    Ensures %LOCALAPPDATA%\\RemoteDesktopDashboard\\.env and admin.env exist.
    """
    from remote_desktop_dashboard.paths import resolve_data_dir

    data_dir = resolve_data_dir()
    ensure_config_files(data_dir)

    from remote_desktop_dashboard.database import engine
    from remote_desktop_dashboard.database import init_db as _init_tables

    upgrade_database_schema(engine)
    _init_tables()

    return data_dir
