"""Fast remote query: who is logged on (console + RDP) — no tasklist / WMI process scan."""

from __future__ import annotations

import logging
import sys
from dataclasses import dataclass

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.services.monitor_credentials import (
    MonitorCredentials,
    credentials_hint,
    resolve_monitor_credentials,
)
from remote_desktop_dashboard.services.process_catalog import normalize_user
from remote_desktop_dashboard.services.reachability import check_host_reachable
from remote_desktop_dashboard.services.remote_probe import (
    _remote_auth,
    _remote_query_session,
    _remote_query_user,
    _session_user_map,
    _wmi_console_user,
)

logger = logging.getLogger(__name__)


@dataclass
class LoggedInSnapshot:
    local_user: str | None
    rdp_users: list[str]
    raw: dict

    @property
    def all_users(self) -> list[str]:
        seen: set[str] = set()
        ordered: list[str] = []
        for name in [self.local_user, *self.rdp_users]:
            if not name or name in seen:
                continue
            seen.add(name)
            ordered.append(name)
        return ordered


def _classify_sessions(
    sessions: list[dict[str, str]], session_types: dict[str, str]
) -> tuple[str | None, list[str]]:
    local_user: str | None = None
    rdp_users: list[str] = []

    for s in sessions:
        user = s.get("username")
        if not user:
            continue
        sess = (s.get("session") or "").lower()
        stype = session_types.get(user, session_types.get(s.get("session", ""), ""))
        if "console" in sess or sess in ("0", "1"):
            if not local_user:
                local_user = user
        elif "rdp" in sess or "rdp-tcp" in sess or stype in ("10", "rdp", "remote"):
            if user not in rdp_users:
                rdp_users.append(user)
        elif not local_user:
            local_user = user

    return local_user, rdp_users


def probe_logged_in_users(host: str) -> LoggedInSnapshot:
    """Query quser/qwinsta only (typically a few seconds per bench)."""
    if sys.platform != "win32":
        raise OSError("Remote user probe requires the dashboard server to run on Windows")

    settings = get_settings()
    target = host.strip().strip("\\")
    creds = resolve_monitor_credentials()
    if creds is None:
        raise RuntimeError(
            "Monitor credentials not configured on the dashboard server. "
            f"{credentials_hint()}"
        )

    if not check_host_reachable(target, settings.rdp_port, settings.poll_ping_timeout_seconds):
        raise RuntimeError(f"Host {target} is not reachable on port {settings.rdp_port}.")

    timeout = min(settings.poll_users_timeout_seconds, settings.poll_timeout_seconds)
    session_timeout = min(settings.poll_session_timeout_seconds, timeout)
    auth_timeout = min(8.0, timeout)

    sessions: list[dict[str, str]] = []
    session_types: dict[str, str] = {}
    session_error: str | None = None

    try:
        with _remote_auth(target, auth_timeout, creds):
            sessions = _remote_query_user(target, session_timeout)
            session_types = _remote_query_session(target, session_timeout)
    except Exception as exc:
        session_error = str(exc)
        logger.info("Session query failed for %s: %s", target, exc)

    local_user, rdp_users = _classify_sessions(sessions, session_types)

    if not local_user and not rdp_users:
        wmi_user = _wmi_console_user(target, creds, min(6.0, timeout))
        if wmi_user:
            local_user = wmi_user
        elif sessions:
            users = sorted(
                {s["username"] for s in sessions if s.get("username")},
                key=str.lower,
            )
            if users:
                local_user = users[0]
                rdp_users = [u for u in users[1:] if u != local_user]

    if session_error and not local_user and not rdp_users:
        raise RuntimeError(session_error)

    return LoggedInSnapshot(
        local_user=local_user,
        rdp_users=rdp_users,
        raw={
            "source": "remote_users",
            "target": target,
            "sessions": sessions,
            "session_count": len(sessions),
            "session_error": session_error,
        },
    )
