"""Resolve Windows system utilities with full paths (works when System32 is not on PATH)."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def system32_dir() -> Path:
    root = os.environ.get("SystemRoot") or os.environ.get("WINDIR") or r"C:\Windows"
    return Path(root) / "System32"


def system32_exe(*candidates: str) -> str:
    """Return the first existing executable under System32."""
    folder = system32_dir()
    for name in candidates:
        path = folder / name
        if path.is_file():
            return str(path)
    tried = ", ".join(candidates)
    raise FileNotFoundError(
        f"None of [{tried}] found in {folder}. "
        "Remote polling needs quser.exe/qwinsta.exe or query.exe, or falls back to tasklist only."
    )


def redact_cmd_args(args: list[str]) -> str:
    """Safe command string for logs/errors (hide password after /P or net use IPC$)."""
    redacted: list[str] = []
    i = 0
    while i < len(args):
        arg = args[i]
        redacted.append(arg)
        if arg.upper() == "/P" and i + 1 < len(args):
            redacted.append("***")
            i += 2
            continue
        if "IPC$" in arg and i + 1 < len(args) and not args[i + 1].startswith("/"):
            redacted.append("***")
            i += 2
            continue
        i += 1
    return " ".join(redacted)


def run_cmd(args: list[str], timeout: float) -> str:
    """Run a command; return stdout. Raises on total failure."""
    result = subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
        creationflags=CREATE_NO_WINDOW,
        shell=False,
    )
    out = (result.stdout or "").strip()
    err = (result.stderr or "").strip()
    if result.returncode != 0 and not out:
        safe = redact_cmd_args(args)
        raise RuntimeError(
            err or f"Command failed (exit {result.returncode}): {safe}"
        )
    return result.stdout
