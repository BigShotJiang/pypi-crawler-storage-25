"""Encrypted server settings (monitor credentials) stored in SQLite."""

from __future__ import annotations

import json
import logging
from pathlib import Path

from sqlalchemy.orm import Session

from sqlalchemy.orm import Session

from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.models.app_setting import AppSetting

logger = logging.getLogger(__name__)

MONITOR_KEY = "monitor_credentials"
_FERNET = None
_FERNET_KEY_PATH: Path | None = None


def _secret_key_path() -> Path:
    from remote_desktop_dashboard.paths import secret_key_file

    return secret_key_file()


def reset_settings_crypto() -> None:
    """Clear cached Fernet (e.g. when RDD_DATA_DIR changes in tests)."""
    global _FERNET, _FERNET_KEY_PATH
    _FERNET = None
    _FERNET_KEY_PATH = None


def _session_local():
    """Always use the current SessionLocal (tests may rebind database.SessionLocal)."""
    from remote_desktop_dashboard.database import SessionLocal

    return SessionLocal()


def _get_fernet():
    global _FERNET, _FERNET_KEY_PATH
    key_path = _secret_key_path()
    if _FERNET is not None and _FERNET_KEY_PATH == key_path:
        return _FERNET

    from cryptography.fernet import Fernet

    settings = get_settings()
    raw = (settings.settings_secret_key or "").strip()
    if not raw:
        if key_path.is_file():
            raw = key_path.read_text(encoding="utf-8").strip()
        else:
            raw = Fernet.generate_key().decode("ascii")
            key_path.parent.mkdir(parents=True, exist_ok=True)
            key_path.write_text(raw, encoding="utf-8")
            logger.info("Generated settings encryption key at %s", key_path)
    _FERNET = Fernet(raw.encode("ascii") if isinstance(raw, str) else raw)
    _FERNET_KEY_PATH = key_path
    return _FERNET


def _encrypt(plain: str) -> str:
    return _get_fernet().encrypt(plain.encode("utf-8")).decode("ascii")


def _decrypt(token: str) -> str:
    return _get_fernet().decrypt(token.encode("ascii")).decode("utf-8")


def get_setting(db: Session, key: str) -> str | None:
    row = db.get(AppSetting, key)
    if row is None:
        return None
    return _decrypt(row.value_encrypted)


def set_setting(db: Session, key: str, plain: str) -> None:
    token = _encrypt(plain)
    row = db.get(AppSetting, key)
    if row is None:
        db.add(AppSetting(key=key, value_encrypted=token))
    else:
        row.value_encrypted = token
    db.commit()


def delete_setting(db: Session, key: str) -> None:
    row = db.get(AppSetting, key)
    if row is not None:
        db.delete(row)
        db.commit()


def _monitor_credentials_from_session(db: Session) -> dict[str, str] | None:
    try:
        raw = get_setting(db, MONITOR_KEY)
    except Exception as exc:
        logger.debug("Could not read monitor settings from DB: %s", exc)
        return None
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    user = (data.get("username") or "").strip()
    password = data.get("password") or ""
    if not user or not password:
        return None
    return {
        "domain": (data.get("domain") or "").strip(),
        "username": user,
        "password": password,
    }


def get_monitor_credentials_dict(db: Session | None = None) -> dict[str, str] | None:
    if db is not None:
        return _monitor_credentials_from_session(db)
    db = _session_local()
    try:
        return _monitor_credentials_from_session(db)
    finally:
        db.close()
def save_monitor_credentials(
    db: Session,
    *,
    domain: str,
    username: str,
    password: str | None,
) -> None:
    existing = get_monitor_credentials_dict(db)
    pwd = password if password else (existing or {}).get("password", "")
    if not username.strip() or not pwd:
        raise ValueError("Username and password are required")
    payload = json.dumps(
        {
            "domain": domain.strip(),
            "username": username.strip(),
            "password": pwd,
        }
    )
    set_setting(db, MONITOR_KEY, payload)
    get_settings.cache_clear()
    reset_settings_crypto()


def clear_monitor_credentials(db: Session) -> None:
    delete_setting(db, MONITOR_KEY)
    get_settings.cache_clear()
