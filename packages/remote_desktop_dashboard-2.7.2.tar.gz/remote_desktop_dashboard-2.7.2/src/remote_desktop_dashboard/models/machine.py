"""Machine ORM model."""

from datetime import datetime

from sqlalchemy import Boolean, DateTime, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from remote_desktop_dashboard.database import Base


class Machine(Base):
    __tablename__ = "machines"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(32), unique=True, index=True)
    hostname: Mapped[str] = mapped_column(String(255))
    ip_address: Mapped[str] = mapped_column(String(45))

    is_online: Mapped[bool] = mapped_column(Boolean, default=False)
    last_seen: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    local_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    rdp_users: Mapped[str] = mapped_column(Text, default="[]")
    windows_app_users: Mapped[str] = mapped_column(Text, default="[]")

    mobaxterm_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    com_port_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    etgui_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    camera_user: Mapped[str | None] = mapped_column(String(128), nullable=True)
    camera_tools: Mapped[str] = mapped_column(Text, default="[]")

    # Dashboard session lock (who is remoting in via this dashboard)
    locked_by: Mapped[str | None] = mapped_column(String(128), nullable=True, index=True)
    locked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    lock_heartbeat_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    lock_rdp_username: Mapped[str | None] = mapped_column(String(256), nullable=True)
    lock_client_ip: Mapped[str | None] = mapped_column(String(45), nullable=True)

    agent_version: Mapped[str | None] = mapped_column(String(32), nullable=True)
    raw_report: Mapped[str | None] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
