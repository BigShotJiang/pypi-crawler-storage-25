(function () {
  "use strict";

  const STORAGE_OPERATOR = "rdd_operator";
  const STORAGE_RDP_USER = "rdd_rdp_username";
  const HEARTBEAT_MS = 30000;

  const wsStatus = document.getElementById("ws-status");
  const lastUpdate = document.getElementById("last-update");
  const summary = document.getElementById("summary");
  const grid = document.getElementById("machine-grid");
  const machineCount = document.getElementById("machine-count");
  const operatorInput = document.getElementById("operator-name");
  const rdpUserInput = document.getElementById("rdp-username");
  const toastEl = document.getElementById("toast");
  const serverBanner = document.getElementById("server-banner");

  let machines = [];
  let serverMeta = {
    monitor_configured: true,
    users_can_connect: true,
    users_can_manage_machines: false,
    users_can_release_own_lock: true,
  };
  let heartbeatTimers = {};
  const pollingMachines = new Set();

  operatorInput.value = localStorage.getItem(STORAGE_OPERATOR) || "";
  rdpUserInput.value = localStorage.getItem(STORAGE_RDP_USER) || "";
  operatorInput.addEventListener("change", savePrefs);
  operatorInput.addEventListener("input", function () {
    savePrefs();
    if (machines.length) render(machines);
  });
  rdpUserInput.addEventListener("change", savePrefs);

  function savePrefs() {
    localStorage.setItem(STORAGE_OPERATOR, operatorInput.value.trim());
    localStorage.setItem(STORAGE_RDP_USER, rdpUserInput.value.trim());
  }

  function getOperator() {
    return operatorInput.value.trim();
  }

  function normalizeOp(name) {
    return (name || "").trim().toLowerCase();
  }

  function operatorsMatch(a, b) {
    const x = normalizeOp(a);
    const y = normalizeOp(b);
    return x !== "" && x === y;
  }

  function enrichMachine(m) {
    const op = normalizeOp(getOperator());
    const locked = !!(m.is_locked && m.locked_by);
    const lockedBy = locked ? normalizeOp(m.locked_by) : "";
    const mine = locked && op && lockedBy === op;
    m._mine = mine;
    m.lock_available = !locked || mine;
    return m;
  }

  function getRdpUsername() {
    const v = rdpUserInput.value.trim();
    return v || null;
  }

  function wsUrl() {
    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    return proto + "//" + location.host + "/ws/dashboard";
  }

  function showToast(msg, isError) {
    toastEl.textContent = msg;
    toastEl.className = "toast" + (isError ? " toast-error" : "");
    setTimeout(function () {
      toastEl.className = "toast hidden";
    }, 5000);
  }

  const launchModal = document.getElementById("launch-modal");
  const launchTarget = document.getElementById("launch-target");
  const launchHint = document.getElementById("launch-hint");
  const launchCopyRdp = document.getElementById("launch-copy-rdp");
  const launchTryLocal = document.getElementById("launch-try-local");
  const launchCopyMstsc = document.getElementById("launch-copy-mstsc");
  const launchDownloadRdp = document.getElementById("launch-download-rdp");
  const launchClose = document.getElementById("launch-close");
  const launchBackdrop = document.getElementById("launch-backdrop");
  const useIpCheckbox = document.getElementById("use-ip");

  let lastLaunchData = null;

  function hideLaunchModal() {
    launchModal.className = "modal hidden";
    lastLaunchData = null;
  }

  function showLaunchModal(data) {
    lastLaunchData = data;
    launchTarget.textContent = data.machine_name + " (" + data.target_host + ")";
    launchHint.textContent =
      data.message ||
      "Launch on this PC, or download .rdp (uses each PC's own Windows App / msrdc).";
    if (launchCopyRdp) {
      launchCopyRdp.dataset.uri = data.launch_uri || data.rdp_uri || "";
    }
    if (launchDownloadRdp && data.rdp_download_url) {
      launchDownloadRdp.href = data.rdp_download_url;
      launchDownloadRdp.classList.remove("hidden");
    } else if (launchDownloadRdp) {
      launchDownloadRdp.classList.add("hidden");
    }
    launchModal.className = "modal";
  }

  function mergeMachineUpdate(updated) {
    if (!updated || !updated.name) return;
    const idx = machines.findIndex(function (m) {
      return m.name === updated.name;
    });
    if (idx >= 0) {
      machines[idx] = updated;
    } else {
      machines.push(updated);
    }
    render(machines);
  }

  async function tryLocalLaunch(url, timeoutMs) {
    if (!url) return null;
    const ms = timeoutMs || 3000;
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, ms);
    try {
      const r = await fetch(url, { method: "GET", mode: "cors", signal: ctrl.signal });
      clearTimeout(timer);
      if (!r.ok) return null;
      return r.json().catch(function () {
        return { ok: true, client: "unknown" };
      });
    } catch (e) {
      clearTimeout(timer);
      return null;
    }
  }

  function launchToast(client, target) {
    const dest = target ? " to " + target : "";
    if (client === "windows_app" || client === "windows365" || client === "msrdc") {
      showToast("Connecting directly" + dest + " via Windows App…", false);
    } else if (client === "mstsc") {
      showToast("Opening legacy Remote Desktop (mstsc). Install Windows App or set RDD_MSRDC_PATH.", true);
    } else {
      showToast("Opening remote session…", false);
    }
  }

  async function launchRemoteSession(data) {
    showLaunchModal(data);
    showToast(
      "Click Launch Windows App or Download .rdp — RDP password is entered in Windows.",
      false
    );
    return false;
  }

  function applyPermissionsUi() {
    if (toggleManage) {
      toggleManage.style.display = serverMeta.users_can_manage_machines
        ? ""
        : "none";
    }
    if (manageBox && !serverMeta.users_can_manage_machines) {
      manageBox.classList.add("hidden");
    }
  }

  function updateServerBanner(meta) {
    if (!serverBanner) return;
    if (!meta || meta.monitor_configured !== false) {
      serverBanner.className = "server-banner hidden";
      serverBanner.textContent = "";
      return;
    }
    serverBanner.className = "server-banner";
    serverBanner.innerHTML =
      "<strong>Bench monitoring is not configured.</strong> " +
      "Open <strong>Settings</strong> and save the service account (admin.env is on the server).";
  }

  function on(el, event, fn) {
    if (el) el.addEventListener(event, fn);
  }

  on(launchTryLocal, "click", async function () {
    if (!lastLaunchData) return;
    if (lastLaunchData.local_launch_url) {
      const result = await tryLocalLaunch(lastLaunchData.local_launch_url);
      if (result && result.ok !== false) {
        launchToast(result.client || lastLaunchData.client, lastLaunchData.target_host);
        hideLaunchModal();
        return;
      }
    }
    showToast(
      "Could not launch Windows App on this PC. Install Microsoft Windows App or use Download .rdp.",
      true
    );
  });

  on(launchCopyRdp, "click", function () {
    if (!lastLaunchData) return;
    const uri = launchCopyRdp.dataset.uri || lastLaunchData.launch_uri || lastLaunchData.rdp_uri;
    if (!uri) return;
    navigator.clipboard.writeText(uri).then(function () {
      showToast("Copied RDP link", false);
    });
  });

  on(launchCopyMstsc, "click", function () {
    if (!lastLaunchData || !lastLaunchData.mstsc_command) return;
    navigator.clipboard.writeText(lastLaunchData.mstsc_command).then(function () {
      showToast("Copied: " + lastLaunchData.mstsc_command, false);
    });
  });

  on(launchClose, "click", hideLaunchModal);
  on(launchBackdrop, "click", hideLaunchModal);

  function fmt(value, fallback) {
    if (value === null || value === undefined || value === "") {
      return fallback || "\u2014";
    }
    if (Array.isArray(value)) {
      return value.length ? value.join(", ") : fallback || "\u2014";
    }
    return String(value);
  }

  function escapeHtml(s) {
    const d = document.createElement("div");
    d.textContent = s;
    return d.innerHTML;
  }

  function renderSummary(list) {
    const online = list.filter(function (m) {
      return m.is_online;
    }).length;
    const locked = list.filter(function (m) {
      return m.is_locked;
    }).length;
    summary.innerHTML = [
      statCard(online, "Online"),
      statCard(list.length - online, "Offline"),
      statCard(locked, "In use"),
      statCard(list.length, "Total"),
    ].join("");
    machineCount.textContent = list.length + " machine(s)";
  }

  function statCard(value, label) {
    return (
      '<div class="stat-card"><div class="value">' +
      value +
      '</div><div class="label">' +
      label +
      "</div></div>"
    );
  }

  function rowOptional(label, value) {
    if (value === null || value === undefined || value === "") return "";
    if (Array.isArray(value) && !value.length) return "";
    return row(label, value, true);
  }

  function row(label, value, active) {
    const display = fmt(value, "\u2014");
    const cls =
      "row-value" + (display === "\u2014" ? " empty" : active ? " active" : "");
    return (
      '<div class="row"><span class="row-label">' +
      escapeHtml(label) +
      '</span><span class="' +
      cls +
      '">' +
      escapeHtml(display) +
      "</span></div>"
    );
  }

  function lockBadge(m) {
    if (!m.is_locked || !m.locked_by) return "";
    const mine = m._mine || operatorsMatch(m.locked_by, getOperator());
    return (
      '<div class="lock-badge' +
      (mine ? " lock-mine" : "") +
      '">In use: <strong>' +
      escapeHtml(m.locked_by) +
      "</strong></div>"
    );
  }

  function actionButtons(m) {
    const op = getOperator();
    const mine = !!m._mine;
    const lockedByOther = m.is_locked && m.locked_by && !mine;
    const canConnect = op && !lockedByOther && (!m.is_locked || mine);

    let html = '<div class="card-actions">';
    if (mine) {
      html +=
        '<button type="button" class="btn btn-primary" data-action="connect" data-name="' +
        escapeHtml(m.name) +
        '">Reconnect</button>';
      html +=
        '<button type="button" class="btn btn-secondary" data-action="release" data-name="' +
        escapeHtml(m.name) +
        '">Release</button>';
    } else if (canConnect) {
      html +=
        '<button type="button" class="btn btn-primary" data-action="connect" data-name="' +
        escapeHtml(m.name) +
        '">Connect</button>';
    } else if (lockedByOther) {
      html +=
        '<button type="button" class="btn btn-disabled" disabled title="In use by ' +
        escapeHtml(m.locked_by) +
        '">In use</button>';
    } else if (m.is_locked) {
      html += '<button type="button" class="btn btn-disabled" disabled>Locked</button>';
    } else {
      html +=
        '<button type="button" class="btn btn-disabled" disabled title="Enter your name above">Connect</button>';
    }
    html += "</div>";
    return html;
  }

  function statusDotClass(label) {
    if (label === "in_use") return "in_use";
    if (label === "online" || label === "reachable") return "online";
    if (label === "unknown") return "unknown";
    return "offline";
  }

  function renderMachine(m) {
    const label = m.status_label || (m.is_online ? "online" : "offline");
    const display = m.status_display || (m.is_online ? "Online" : "Offline");
    const up =
      m.is_online ||
      label === "online" ||
      label === "reachable" ||
      label === "in_use";
    const isPolling = pollingMachines.has(m.name);
    const cardClass =
      "machine-card" +
      (up ? "" : " offline") +
      (m.is_locked ? " locked in-use" : "") +
      (label === "in_use" ? " in-use" : "") +
      (isPolling ? " polling" : "");

    const users = m.logged_in_users || [];
    let loggedInLine = "";
    if (isPolling) {
      loggedInLine = '<div class="logged-in muted">Checking who is logged in…</div>';
    } else if (users.length) {
      loggedInLine =
        '<div class="logged-in"><span class="logged-in-label">Logged in</span> ' +
        escapeHtml(users.join(", ")) +
        "</div>";
    } else if (m.is_reachable || m.is_online) {
      loggedInLine = '<div class="logged-in muted">No active logons detected</div>';
    }

    let lockNote = "";
    if (m.is_locked && m.locked_by) {
      const mine = m._mine;
      lockNote =
        '<div class="lock-note' +
        (mine ? " lock-mine" : "") +
        '">' +
        (mine
          ? "You have this machine — direct RDP from other PCs is blocked."
          : "Reserved by <strong>" +
            escapeHtml(m.locked_by) +
            "</strong> — connect only through this dashboard.") +
        "</div>";
    }

    let adminBtn = "";
    if (m.is_locked && !m._mine) {
      adminBtn =
        '<button type="button" class="btn btn-secondary btn-sm" data-action="admin-release" data-name="' +
        escapeHtml(m.name) +
        '">Admin release</button>';
    }

    return (
      '<article class="' +
      cardClass +
      '" data-name="' +
      escapeHtml(m.name) +
      '">' +
      '<div class="card-header">' +
      "<div>" +
      '<div class="machine-name">' +
      escapeHtml(m.name) +
      "</div>" +
      lockBadge(m) +
      '<div class="machine-host">' +
      escapeHtml(m.hostname) +
      " \u00b7 " +
      escapeHtml(m.ip_address) +
      "</div>" +
      loggedInLine +
      lockNote +
      "</div>" +
      "<div>" +
      '<span class="status-dot ' +
      statusDotClass(label) +
      '"></span>' +
      '<span class="status-label' +
      (label === "in_use" ? " in-use" : "") +
      '">' +
      escapeHtml(display) +
      "</span>" +
      (m.last_seen_relative
        ? '<div class="muted small">' +
          escapeHtml(m.last_seen_relative) +
          "</div>"
        : "") +
      "</div></div>" +
      actionButtons(m) +
      '<div class="card-admin">' +
      '<button type="button" class="btn btn-secondary btn-sm" data-action="edit" data-id="' +
      m.id +
      '" data-name="' +
      escapeHtml(m.name) +
      '">Edit</button>' +
      '<button type="button" class="btn btn-secondary btn-sm" data-action="delete" data-name="' +
      escapeHtml(m.name) +
      '">Delete</button>' +
      "</div>" +
      adminBtn +
      "</article>"
    );
  }

  function render(list) {
    machines = list.map(enrichMachine);
    machines.sort(function (a, b) {
      return a.name.localeCompare(b.name, undefined, { numeric: true });
    });
    renderSummary(machines);
    grid.innerHTML = machines.map(renderMachine).join("");
    lastUpdate.textContent = "Updated " + new Date().toLocaleTimeString();
  }

  function setWsStatus(state, text) {
    if (!wsStatus) return;
    wsStatus.className = "status-pill status-" + state;
    wsStatus.textContent = text;
  }

  function sendHeartbeat(name) {
    const op = getOperator();
    if (!op) return;
    fetch("/api/v1/machines/" + encodeURIComponent(name) + "/lock/heartbeat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ operator: op }),
    }).catch(function () {});
  }

  function startHeartbeat(name) {
    stopHeartbeat(name);
    sendHeartbeat(name);
    heartbeatTimers[name] = setInterval(function () {
      sendHeartbeat(name);
    }, HEARTBEAT_MS);
  }

  function stopHeartbeat(name) {
    if (heartbeatTimers[name]) {
      clearInterval(heartbeatTimers[name]);
      delete heartbeatTimers[name];
    }
  }

  function stopAllHeartbeats() {
    Object.keys(heartbeatTimers).forEach(stopHeartbeat);
  }

  function setConnectBusy(name, busy) {
    const btn = grid.querySelector(
      '[data-action="connect"][data-name="' + name + '"]'
    );
    if (!btn) return;
    if (busy) {
      btn.disabled = true;
      btn.dataset.prevLabel = btn.textContent;
      btn.textContent = "Connecting…";
    } else {
      btn.disabled = false;
      if (btn.dataset.prevLabel) {
        btn.textContent = btn.dataset.prevLabel;
        delete btn.dataset.prevLabel;
      }
    }
  }

  async function connectMachine(name) {
    const op = getOperator();
    if (!op) {
      showToast("Enter your name before connecting.", true);
      operatorInput.focus();
      return;
    }
    const existing = machines.find(function (x) {
      return x.name === name;
    });
    if (existing && existing.is_locked && existing.locked_by && !existing._mine) {
      showToast(
        "In use by " + existing.locked_by + ". They must click Release first.",
        true
      );
      return;
    }
    savePrefs();
    setConnectBusy(name, true);
    showToast("Connecting to " + name + "…", false);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/connect",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            operator: op,
            rdp_username: getRdpUsername(),
            use_hostname: !useIpCheckbox || !useIpCheckbox.checked,
          }),
        }
      );
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Cannot connect", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      else loadDashboard();
      startHeartbeat(name);
      if (data.local_launch_url) {
        tryLocalLaunch(data.local_launch_url, 2500).then(function (result) {
          if (result && result.ok !== false) {
            launchToast(result.client || data.client, data.target_host);
            hideLaunchModal();
          }
        });
      }
      await launchRemoteSession(data);
    } catch (e) {
      showToast("Connection failed: " + e.message, true);
    } finally {
      setConnectBusy(name, false);
    }
  }

  function setMachinePolling(name, active) {
    if (active) {
      pollingMachines.add(name);
    } else {
      pollingMachines.delete(name);
    }
    if (machines.length) {
      render(machines);
    }
  }

  async function pollMachine(name) {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    setMachinePolling(name, true);
    showToast("Refreshing session for " + name + "…", false);
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 90000);
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/poll-now" + q,
        { method: "POST", signal: ctrl.signal }
      );
      clearTimeout(timer);
      const data = await res.json();
      if (!res.ok) {
        showToast(data.detail || "Poll failed", true);
        return;
      }
      if (data.machine) mergeMachineUpdate(data.machine);
      if (data.ok) {
        showToast("Session updated for " + name, false);
      } else {
        showToast(data.error || "Poll failed — check Server settings credentials", true);
      }
      loadDashboard();
    } catch (e) {
      clearTimeout(timer);
      if (e.name === "AbortError") {
        showToast("Poll still running — live update when ready", false);
      } else {
        showToast("Poll failed: " + e.message, true);
      }
    } finally {
      setMachinePolling(name, false);
    }
  }


  async function adminReleaseMachine(name) {
    const pin = window.prompt("Admin PIN required to force-release " + name + ":");
    if (!pin) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/admin-release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ admin_pin: pin }),
        }
      );
      const data = await res.json().catch(function () { return {}; });
      if (!res.ok) {
        showToast(data.detail || "Admin release failed", true);
        return;
      }
      showToast("Lock released on " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Admin release failed", true);
    }
  }

  async function releaseMachine(name) {
    const op = getOperator();
    if (!op) return;
    try {
      const res = await fetch(
        "/api/v1/machines/" + encodeURIComponent(name) + "/lock/release",
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ operator: op }),
        }
      );
      if (!res.ok) {
        const data = await res.json();
        showToast(data.detail || "Release failed", true);
        return;
      }
      stopHeartbeat(name);
      showToast("Released " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Release failed", true);
    }
  }

  function loadDashboard() {
    const op = getOperator();
    const q = op ? "?operator=" + encodeURIComponent(op) : "";
    const ctrl = new AbortController();
    const timer = setTimeout(function () {
      ctrl.abort();
    }, 20000);
    return fetch("/api/v1/dashboard/fast" + q, { signal: ctrl.signal })
      .then(function (r) {
        clearTimeout(timer);
        if (!r.ok) throw new Error("HTTP " + r.status);
        return r.json();
      })
      .then(function (data) {
        if (data.monitor_configured !== undefined) {
          serverMeta.monitor_configured = data.monitor_configured;
          serverMeta.monitor_hint = data.monitor_hint;
          serverMeta.admin_pin_required = data.admin_pin_required;
          if (data.users_can_connect !== undefined) {
            serverMeta.users_can_connect = data.users_can_connect;
          }
          if (data.users_can_manage_machines !== undefined) {
            serverMeta.users_can_manage_machines = data.users_can_manage_machines;
          }
          updateServerBanner(serverMeta);
          applyPermissionsUi();
        }
        if (data.machines) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      })
      .catch(function (err) {
        clearTimeout(timer);
        if (err.name === "AbortError") {
          setWsStatus("err", "Slow");
          grid.innerHTML =
            '<p class="empty-state">The server is taking too long to respond. Try refreshing the page.</p>';
        } else {
          setWsStatus("err", "Offline");
          grid.innerHTML =
            '<p class="empty-state">Cannot reach the dashboard server. Check that it is running.</p>';
        }
      });
  }

  const toggleManage = document.getElementById("toggle-manage");
  const toggleSettings = document.getElementById("toggle-settings");
  const settingsBox = document.getElementById("settings-box");
  const settingsForm = document.getElementById("settings-form");
  const setDomain = document.getElementById("set-domain");
  const setUsername = document.getElementById("set-username");
  const setPassword = document.getElementById("set-password");
  const setTestHost = document.getElementById("set-test-host");
  const setAdminPin = document.getElementById("set-admin-pin");
  const setTestBtn = document.getElementById("set-test-btn");
  const settingsStatus = document.getElementById("settings-status");
  const setPinRow = document.getElementById("set-pin-row");
  const manageBox = document.getElementById("manage-box");
  const machineForm = document.getElementById("machine-form");
  const editMachineId = document.getElementById("edit-machine-id");
  const mfName = document.getElementById("mf-name");
  const mfHostname = document.getElementById("mf-hostname");
  const mfIp = document.getElementById("mf-ip");
  const mfCancel = document.getElementById("mf-cancel");

  toggleManage.addEventListener("click", function () {
    manageBox.classList.toggle("hidden");
  });

  if (toggleSettings && settingsBox) {
    toggleSettings.addEventListener("click", function () {
      settingsBox.classList.toggle("hidden");
      if (!settingsBox.classList.contains("hidden")) loadMonitorSettings();
    });
  }

  function loadMonitorSettings() {
    fetch("/api/v1/settings/monitor")
      .then(function (r) {
        return r.json();
      })
      .then(function (data) {
        if (setDomain) setDomain.value = data.domain || "";
        if (setUsername) setUsername.value = data.username || "";
        if (setPassword) setPassword.value = "";
        if (setPinRow) {
          setPinRow.classList.toggle("hidden", !serverMeta.admin_pin_required);
        }
        if (settingsStatus) {
          settingsStatus.textContent = data.configured
            ? "Monitoring account is configured."
            : "Save the service account below to enable session details.";
        }
        if (data.monitor_configured !== undefined) {
          serverMeta.monitor_configured = data.configured;
          updateServerBanner(serverMeta);
        }
      })
      .catch(function () {});
  }

  if (settingsForm) {
    settingsForm.addEventListener("submit", async function (ev) {
      ev.preventDefault();
      const body = {
        domain: setDomain ? setDomain.value.trim() : "",
        username: setUsername ? setUsername.value.trim() : "",
        password: setPassword && setPassword.value ? setPassword.value : null,
        admin_pin: setAdminPin && setAdminPin.value ? setAdminPin.value : null,
      };
      try {
        const res = await fetch("/api/v1/settings/monitor", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        const data = await res.json().catch(function () {
          return {};
        });
        if (!res.ok) {
          showToast(data.detail || "Save failed", true);
          return;
        }
        serverMeta.monitor_configured = true;
        updateServerBanner(serverMeta);
        if (setPassword) setPassword.value = "";
        if (settingsStatus) settingsStatus.textContent = "Saved (encrypted on server).";
        showToast("Server credentials saved", false);
        loadDashboard();
      } catch (e) {
        showToast("Save failed", true);
      }
    });
  }

  if (setTestBtn) {
    setTestBtn.addEventListener("click", async function () {
      const host = setTestHost ? setTestHost.value.trim() : "";
      if (!host) {
        showToast("Enter a bench IP or hostname to test", true);
        return;
      }
      setTestBtn.disabled = true;
      if (settingsStatus) settingsStatus.textContent = "Testing (up to 60s)…";
      const ctrl = new AbortController();
      const timer = setTimeout(function () {
        ctrl.abort();
      }, 70000);
      try {
        const res = await fetch("/api/v1/settings/monitor/test", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: ctrl.signal,
          body: JSON.stringify({
            host: host,
            admin_pin: setAdminPin && setAdminPin.value ? setAdminPin.value : null,
          }),
        });
        clearTimeout(timer);
        const data = await res.json();
        if (!res.ok) {
          showToast(data.detail || "Test failed", true);
          return;
        }
        if (settingsStatus) settingsStatus.textContent = data.message || "";
        showToast(data.ok ? "Test OK" : data.message || "Test failed", !data.ok);
      } catch (e) {
        clearTimeout(timer);
        if (e.name === "AbortError") {
          showToast("Test timed out — server may still be busy; wait and retry", true);
        } else {
          showToast("Test failed: " + e.message, true);
        }
      } finally {
        setTestBtn.disabled = false;
      }
    });
  }

  function resetMachineForm() {
    editMachineId.value = "";
    mfName.value = "";
    mfName.disabled = false;
    mfHostname.value = "";
    mfIp.value = "";
  }

  function fillMachineForm(m) {
    editMachineId.value = String(m.id);
    mfName.value = m.name;
    mfName.disabled = true;
    mfHostname.value = m.hostname;
    mfIp.value = m.ip_address;
    manageBox.classList.remove("hidden");
    mfHostname.focus();
  }

  mfCancel.addEventListener("click", resetMachineForm);

  machineForm.addEventListener("submit", async function (ev) {
    ev.preventDefault();
    const payload = {
      name: mfName.value.trim().toUpperCase(),
      hostname: mfHostname.value.trim(),
      ip_address: mfIp.value.trim(),
    };
    const id = editMachineId.value;
    try {
      let res;
      if (id) {
        res = await fetch("/api/v1/machines/" + id, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ hostname: payload.hostname, ip_address: payload.ip_address }),
        });
      } else {
        res = await fetch("/api/v1/machines", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      const data = await res.json().catch(function () {
        return {};
      });
      if (!res.ok) {
        showToast(data.detail || "Save failed", true);
        return;
      }
      showToast(id ? "Updated " + payload.name : "Created " + payload.name, false);
      resetMachineForm();
      loadDashboard();
    } catch (e) {
      showToast("Save failed", true);
    }
  });

  async function deleteMachineByName(name) {
    if (!confirm("Delete machine " + name + " from the dashboard?")) return;
    try {
      const res = await fetch(
        "/api/v1/machines/by-name/" + encodeURIComponent(name),
        { method: "DELETE" }
      );
      if (!res.ok) {
        const data = await res.json().catch(function () {
          return {};
        });
        showToast(data.detail || "Delete failed", true);
        return;
      }
      showToast("Deleted " + name, false);
      loadDashboard();
    } catch (e) {
      showToast("Delete failed", true);
    }
  }

  grid.addEventListener("click", function (ev) {
    const btn = ev.target.closest("button[data-action]");
    if (!btn) return;
    const name = btn.getAttribute("data-name");
    const action = btn.getAttribute("data-action");
    if (action === "connect") connectMachine(name);
    if (action === "release") releaseMachine(name);
    if (action === "admin-release") adminReleaseMachine(name);
    if (action === "delete") deleteMachineByName(name);
    if (action === "edit") {
      const m = machines.find(function (x) {
        return x.name === name;
      });
      if (m) fillMachineForm(m);
    }
  });

  window.addEventListener("beforeunload", function () {
    const op = getOperator();
    machines.forEach(function (m) {
      if (m._mine || operatorsMatch(m.locked_by, op)) {
        navigator.sendBeacon(
          "/api/v1/machines/" +
            encodeURIComponent(m.name) +
            "/lock/release",
          new Blob([JSON.stringify({ operator: op })], {
            type: "application/json",
          })
        );
      }
    });
    stopAllHeartbeats();
  });

  function connect() {
    const socket = new WebSocket(wsUrl());
    socket.onopen = function () {
      setWsStatus("ok", "Live");
    };
    socket.onmessage = function (event) {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "machines_update" && Array.isArray(data.machines)) {
          render(data.machines);
          setWsStatus("ok", "Live");
        }
      } catch (e) {
        /* ignore malformed websocket payloads */
      }
    };
    socket.onclose = function () {
      setWsStatus("warn", "Reconnecting…");
      setTimeout(connect, 3000);
    };
    socket.onerror = function () {
      setWsStatus("warn", "Reconnecting…");
    };
    setInterval(function () {
      if (socket.readyState === WebSocket.OPEN) socket.send("ping");
    }, 25000);
  }

  function refreshIntervalMs() {
    const op = getOperator();
    const mine = machines.some(function (m) {
      return m.is_locked && m.locked_by === op;
    });
    return mine ? 8000 : 20000;
  }

  let refreshTimer = null;
  function scheduleRefresh() {
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(function () {
      loadDashboard();
      scheduleRefresh();
    }, refreshIntervalMs());
  }

  function loadHealth() {
    const verEl = document.getElementById("app-version");
    fetch("/health")
      .then(function (r) {
        return r.json();
      })
      .then(function (h) {
        if (verEl && h.version) verEl.textContent = "v" + h.version;
        if (h.monitor_configured !== undefined) {
          serverMeta.monitor_configured = h.monitor_configured;
          serverMeta.monitor_hint = h.monitor_hint;
          serverMeta.admin_pin_required = h.admin_pin_required;
        }
        if (h.users_can_connect !== undefined) {
          serverMeta.users_can_connect = h.users_can_connect;
        }
        if (h.users_can_manage_machines !== undefined) {
          serverMeta.users_can_manage_machines = h.users_can_manage_machines;
        }
        updateServerBanner(serverMeta);
        applyPermissionsUi();
      })
      .catch(function () {});
  }

  function releaseMyLocksBeacon() {
    const op = getOperator();
    if (!op) return;
    machines.forEach(function (m) {
      if (!m.is_locked || !m.locked_by) return;
      if (!m._mine && !operatorsMatch(m.locked_by, op)) return;
      const url =
        "/api/v1/machines/" + encodeURIComponent(m.name) + "/lock/release";
      const body = JSON.stringify({ operator: op });
      if (navigator.sendBeacon) {
        navigator.sendBeacon(url, new Blob([body], { type: "application/json" }));
      }
    });
  }

  window.addEventListener("pagehide", releaseMyLocksBeacon);
  window.addEventListener("beforeunload", releaseMyLocksBeacon);

  grid.innerHTML = '<p class="empty-state">Loading machines…</p>';
  setWsStatus("warn", "Connecting…");
  loadHealth();
  loadDashboard().finally(function () {
    setTimeout(connect, 1500);
    scheduleRefresh();
  });
})();
