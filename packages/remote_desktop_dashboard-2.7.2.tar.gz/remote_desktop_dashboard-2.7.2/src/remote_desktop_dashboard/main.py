"""FastAPI application factory."""

import asyncio
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from remote_desktop_dashboard import __version__
from remote_desktop_dashboard.api.routes import router as api_router
from remote_desktop_dashboard.api.websocket import router as ws_router
from remote_desktop_dashboard.config import get_settings
from remote_desktop_dashboard.database import init_db
from remote_desktop_dashboard.services.local_launcher import start_local_launcher, stop_local_launcher
from remote_desktop_dashboard.services.poller import set_event_loop, start_poller, stop_poller
from remote_desktop_dashboard.services.reachability_cache import (
    start_reachability_refresher,
    stop_reachability_refresher,
)


@asynccontextmanager
async def lifespan(_app: FastAPI):
    from remote_desktop_dashboard.config import get_settings
    from remote_desktop_dashboard.services.bootstrap import bootstrap_install_layout

    bootstrap_install_layout()
    get_settings.cache_clear()
    init_db()
    set_event_loop(asyncio.get_running_loop())
    start_local_launcher()
    start_reachability_refresher()
    start_poller()
    yield
    stop_poller()
    stop_reachability_refresher()
    stop_local_launcher()


def create_app() -> FastAPI:
    settings = get_settings()
    static_dir = settings.resolved_static_dir

    app = FastAPI(
        title="Remote Desktop Dashboard",
        description=(
            "Agentless bench monitoring from one Windows server — "
            "no per-machine agents required"
        ),
        version=__version__,
        lifespan=lifespan,
    )

    app.include_router(api_router)
    app.include_router(ws_router)

    if static_dir.is_dir():
        app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

        @app.get("/")
        async def index() -> FileResponse:
            return FileResponse(static_dir / "index.html")

    @app.get("/health")
    async def health() -> dict:
        from remote_desktop_dashboard.services.poller import get_poller_stats

        s = get_settings()
        from remote_desktop_dashboard.services.rdp_launch import find_msrdc_exe

        from remote_desktop_dashboard.services.monitor_credentials import (
            credentials_hint,
            resolve_monitor_credentials,
        )

        msrdc = find_msrdc_exe()
        creds = resolve_monitor_credentials()
        from remote_desktop_dashboard.paths import resolve_database_file, resolve_data_dir

        from remote_desktop_dashboard.config import permissions_dict

        data_dir = s.config_directory
        return {
            "status": "ok",
            "version": __version__,
            "data_dir": str(resolve_data_dir()),
            "config_dir": str(data_dir),
            "user_env_file": str(data_dir / ".env"),
            "admin_env_file": str(data_dir / "admin.env"),
            "database_file": str(resolve_database_file()),
            "poller": get_poller_stats(),
            "poller_enabled": s.poller_enabled,
            "reachability_check": s.reachability_check,
            "monitor_configured": creds is not None,
            "monitor_hint": None if creds else credentials_hint(),
            "local_launcher_enabled": s.local_launcher_enabled,
            "local_launcher_port": s.local_launcher_port,
            "msrdc_on_server": str(msrdc) if msrdc else None,
            "agentless": True,
            **permissions_dict(),
        }

    return app


app = create_app()
