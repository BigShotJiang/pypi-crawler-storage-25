# manmankan · 文档索引

| 文档 | 用途 |
|---|---|
| [`roadmap.md`](roadmap.md) | 路线图 / 已知技术债 / 三源一致性 / 跨板块交易单位备忘 |
| [`compliance.md`](compliance.md) | 合规红线 / 关键词黑名单 / 强制文案 |
| [`publish-template.md`](publish-template.md) | PyPI 发版标准流程（Trusted Publisher OIDC） |
| [`reviews/`](reviews/) | 历史版本回顾（工程史归档） |
| [`archive/`](archive/) | 已废弃 / 已实施的设计稿 |

主仓根目录另有：[README.md](../README.md) · [CHANGELOG.md](../CHANGELOG.md) · [CONTRIBUTING.md](../CONTRIBUTING.md) · [SECURITY.md](../SECURITY.md) · [CODE_OF_CONDUCT.md](../CODE_OF_CONDUCT.md) · [LICENSE](../LICENSE) · [AUTHORS.md](../AUTHORS.md)
