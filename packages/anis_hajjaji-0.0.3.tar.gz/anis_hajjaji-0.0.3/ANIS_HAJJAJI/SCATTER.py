import pandas as pd
import matplotlib.pyplot as plt
from collections import defaultdict
from ANIS_HAJJAJI import *
from matplotlib.offsetbox import OffsetImage, AnnotationBbox
from PIL import Image
import matplotlib.font_manager as fm

def SCATTER (dataset):

    # ضع المسار المحلي للخط بعد تنزيله
    Path = r"D:\\NEW fONTS\\Almarai-Regular.ttf"
    font_italic = fm.FontProperties(fname=Path)
    
    #─────0. تحديد القيم────────────────────────────────────────────────────────────────────
    #────────────────────────────────────────────────────────────────────────────────────────
    
    # لون كل جزء 1
    color_1 = "#066B06"                 # لون الجهة الأعلى من اليمين
    color_2 = "#4D4D4D"                 # لون الجهة السفلى من اليمين
    color_3 = "#C51C1C"                 # لون الجهة السفلى من اليسار
    color_4 = "#4D4D4D"                 # لون الجهة الأعلى من اليسار
    fontstyle = font_italic
    
    # خاص بالصور 2
    img_size = 25                       # تحديد حجم الصورة
    
    # خاص بمحور الفواصل 3
    Title_x_size = 9                    # حجم عنوان محور الفواصل
    Title_x_color = "#FF0000"         # لون عنوان محور الفواصل
    Title_x_bold = "bold"               # سمك عنوان محور الفواصل ولإزالة السمك غيرها إلى Title_x_bold = None
    linewidth_x = 0.85                  # سمك خط المتوسط لمحور الفواصل
    x_axis_size = 6                     # حجم قيم محور الفواصل
    x_axis_color = "black"              # لون خط قيم محور الفواصل
    
    # خاص بمحور التراتيب 4
    Title_y_size = 9                    # حجم عنوان محور التراتيب
    Title_y_bold = "bold"               # سمك عنوان محور التراتيب ولإزالة السمك أكتب None
    Title_y_color = "#0004FF"         # لون عنوان محور التراتيب
    linewidth_y = 0.85                  # سمك خط المتوسط لمحور التراتيب
    y_axis_size = 6                     # حجم قيم محور التراتيب
    y_axis_color = "black"              # لون خط قيم محور التراتيب
    
    # خاص بالكتابة الموجودة في البيان والنقاط 5
    text_marker_size = 15                           # حجم النص المكتوب أسماء اللاعبين الفرق
    marker = None                                   # في الوقت الحالي لا تظهر العلامات ولإظهارها غيرها إلى marker = "o"
    marker_size = 8                                 # حجم العلامة
    
    # خاص بالشكل 6
    edgecolor = "lightgray"                         # لون الإطار
    linewidth = 1.2                                 # سمك الإطار
    alpha = 0.7                                     # شفافية الإطار
    H_left = 0.075                                  # الهامش على اليسار القيم محصورة بين (1-0)
    H_right = 0.95                                  # الهامش على اليمين القيم محصورة بين (1-0)
    H_top = 0.95                                    # الهامش من الأعلى القيم محصورة بين (1-0)
    H_bottom = 0.075                                # الهامش من الأسفل القيم محصورة بين (1-0)
    Length = 8                                      # طول إطار الشكل
    Width  = 8                                      # عرض إطار الشكل
    
    #─────1. تجميع البيانات─────────────────────────────────────────────────────────────────
    #────────────────────────────────────────────────────────────────────────────────────────
    
    # العمود الأول للأسماء
    names = dataset.iloc[:, 0].tolist()
    
    # العمود الثاني x
    x = dataset.iloc[:, 1].astype(float).tolist()
    
    # العمود الثالث y
    y = dataset.iloc[:, 2].astype(float).tolist()
    
    # الحصول على أسماء الأعمدة
    column_names = dataset.columns.tolist()
    
    # التحقق من النسب المئوية
    if "%" in column_names[1]:
        x = [i * 100 for i in x]          # ← تحويل x إلى نسبة مئوية
    if "%" in column_names[2]:
        y = [i * 100 for i in y]          # ← تحويل y إلى نسبة مئوية
    
    # حساب المتوسطات
    a = sum(x) / len(x)                   # ← متوسط محور الفواصل
    b = sum(y) / len(y)                   # ← متوسط محور التراتيب
    
    #─────2. تصميم الشكل────────────────────────────────────────────────────────────────────
    #────────────────────────────────────────────────────────────────────────────────────────
    
    fig, ax = plt.subplots(figsize=(Width, Length))
    
    # ضبط هوامش الشكل
    plt.subplots_adjust(
        left=H_left,       # ← هامش من اليسار
        right=H_right,     # ← هامش من اليمين
        top=H_top,         # ← هامش من الأعلى
        bottom=H_bottom    # ← هامش من الأسفل
    )
    
    # ضبط إطار الشكل
    for spine in plt.gca().spines.values():
        spine.set_edgecolor(edgecolor)    # ← لون الإطار
        spine.set_linewidth(linewidth)    # ← سمك الإطار
        spine.set_alpha(alpha)            # ← شفافية الإطار
    
    # ضبط قيم محور الفواصل
    ax.tick_params(axis='x', labelsize=x_axis_size, colors=x_axis_color)
    
    # ضبط قيم محور التراتيب
    ax.tick_params(axis='y', labelsize=y_axis_size, colors=y_axis_color)
    
    # رسم خط عمودي عند متوسط x
    plt.axvline(
        x=a,                        # ← موضع الخط العمودي
        linestyle='--',             # ← نوع الخط
        color=Title_x_color,        # ← لون الخط
        linewidth=linewidth_x       # ← سُمك الخط
    )
    
    # رسم خط أفقي عند متوسط y
    plt.axhline(
        y=b,                        # ← موضع الخط الأفقي
        linestyle='--',             # ← نوع الخط
        color=Title_y_color,        # ← لون الخط
        linewidth=linewidth_y       # ← سُمك الخط
    )
    
    # كتابة اسم محور الفواصل
    ax.set_xlabel(
        column_names[1],            # ← نص العنوان
        fontsize=Title_x_size,      # ← حجم الخط
        fontweight=Title_x_bold,    # ← سُمك الخط
        color=Title_x_color,        # ← لون النص
        fontproperties=fontstyle    # ← نوع الخط
    )
    
    # كتابة اسم محور التراتيب
    ax.set_ylabel(
        column_names[2],            # ← نص العنوان
        fontsize=Title_y_size,      # ← حجم الخط
        fontweight=Title_y_bold,    # ← سُمك الخط
        color=Title_y_color,        # ← لون النص
        fontproperties=fontstyle    # ← نوع الخط
    )
    
    #─────3. كتابة الأسماء أو وضع الصور─────────────────────────────────────────────────────
    #────────────────────────────────────────────────────────────────────────────────────────
    
    # تجميع النقاط حسب الإحداثيات
    points = defaultdict(list)
    for xi, yi, label in zip(x, y, names):
        points[(xi, yi)].append(label)
    
    # رسم النقاط إما بكتابة الأسماء أو وضع الصور
    for (xi, yi), lbls in points.items():
    
        # تعليم إحداثيات النقطة
        ax.plot(xi, yi, marker=marker, markersize=marker_size)
    
        # تخزين موقع الصورة أو الاسم
        path = lbls[0]
    
        # في حالة ما إذا كانت صورة
        if ("/" in path or "\\" in path):
    
            # إحضار الصورة ووضعها في إحداثياتها
            img = Image.open(path).convert("RGBA")
            imagebox = OffsetImage(img, zoom=get_zoom(img, img_size), interpolation="bicubic")
            ab1 = AnnotationBbox(
                imagebox,                                          # ← الصورة
                (xi, yi),                                          # ← موضع الصورة
                frameon=False,                                     # ← إخفاء الإطار
                bboxprops=dict(edgecolor="gray", linewidth=0)      # ← خصائص الإطار
            )
            ax.add_artist(ab1)                                     # ← إضافة الصورة للمخطط
    
        # في حالة ما إذا كانت أسماء لاعبين
        else:
    
            # تحديد لون النص بناءً على موضع النقطة
            if xi >= a and yi >= b:
                color = color_1                # ← الجهة الأعلى من اليمين
            elif xi > a and yi <= b:
                color = color_2                # ← الجهة السفلى من اليمين
            elif xi < a and yi <= b:
                color = color_3                # ← الجهة السفلى من اليسار
            else:
                color = color_4                # ← الجهة الأعلى من اليسار
    
            # رسم العلامة وكتابة الاسم
            ax.plot(xi, yi, marker=marker, color=color, markersize=marker_size)
            text = ", ".join(lbls)
            ax.text(
                xi, yi,                        # ← موضع النص
                text,                          # ← النص المعروض
                fontsize=text_marker_size,     # ← حجم الخط
                color=color,                   # ← لون النص
                va='bottom',                    # ← النص فوق النقطة عمودياً
                ha='center',                 # ← مركز النص أفقياً على النقطة
                fontproperties=fontstyle       # ← نوع الخط
            )
    
    #─────4. إظهار الرسم────────────────────────────────────────────────────────────────────
    #────────────────────────────────────────────────────────────────────────────────────────
    
    plt.show()  # ← عرض الرسم النهائي
