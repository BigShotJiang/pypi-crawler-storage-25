"""Simple local search engine for file discovery."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
import re

from stoat.core.intent_schema import FileFilters


@dataclass(frozen=True, slots=True)
class SearchMatch:
    """Ranked file search match."""

    path: Path
    score: int


class SearchEngine:
    """Find files by glob or case-insensitive name matching."""

    def __init__(self, index_hidden_files: bool = False, max_results: int = 50) -> None:
        self._index_hidden_files = index_hidden_files
        self._max_results = max_results

    def search(
        self, base_dir: Path, query: str, filters: FileFilters | None = None
    ) -> list[SearchMatch]:
        return self.search_many([base_dir], query, filters)

    def search_many(
        self,
        base_dirs: list[Path],
        query: str,
        filters: FileFilters | None = None,
    ) -> list[SearchMatch]:
        matches_by_path: dict[Path, SearchMatch] = {}
        total_roots = len(base_dirs)
        for index, base_dir in enumerate(base_dirs):
            root_bonus = max(0, (total_roots - index) * 5)
            if not base_dir.exists():
                continue
            for match in self._search_in_root(base_dir, query, filters):
                boosted = SearchMatch(path=match.path, score=match.score + root_bonus)
                current = matches_by_path.get(match.path)
                if current is None or boosted.score > current.score:
                    matches_by_path[match.path] = boosted

        matches = list(matches_by_path.values())
        self._sort_matches(matches, filters)
        limit = filters.limit if filters and filters.limit is not None else self._max_results
        return matches[:limit]

    def _search_in_root(
        self,
        base_dir: Path,
        query: str,
        filters: FileFilters | None = None,
    ) -> list[SearchMatch]:
        if not base_dir.exists():
            return []

        if self._looks_like_glob(query):
            matches = self._search_by_glob(base_dir, query, filters)
        else:
            matches = self._search_by_score(base_dir, query, filters)
        return matches

    def _sort_matches(self, matches: list[SearchMatch], filters: FileFilters | None) -> None:
        if filters and filters.sort_by == "modified":
            matches.sort(
                key=lambda match: (
                    (
                        -int(match.path.stat().st_mtime)
                        if filters.descending
                        else int(match.path.stat().st_mtime)
                    ),
                    -match.score,
                    len(match.path.parts),
                )
            )
        else:
            matches.sort(
                key=lambda match: (-match.score, len(match.path.parts), match.path.name.lower())
            )

    def _search_by_glob(
        self,
        base_dir: Path,
        query: str,
        filters: FileFilters | None,
    ) -> list[SearchMatch]:
        matches: list[SearchMatch] = []
        for path in base_dir.rglob(query):
            if self._is_candidate(path, filters):
                matches.append(SearchMatch(path=path, score=90))
        return matches

    def _search_by_score(
        self,
        base_dir: Path,
        query: str,
        filters: FileFilters | None,
    ) -> list[SearchMatch]:
        matches: list[SearchMatch] = []
        needle = query.lower()
        if self._looks_like_glob(query):
            return self._search_by_glob(base_dir, query, filters)
        for path in base_dir.rglob("*"):
            if not self._is_candidate(path, filters):
                continue
            score = self._score_match(path, needle)
            if score > 0:
                matches.append(SearchMatch(path=path, score=score))
        return matches

    def _looks_like_glob(self, query: str) -> bool:
        return any(token in query for token in "*?[]")

    def _is_candidate(self, path: Path, filters: FileFilters | None) -> bool:
        if not path.is_file():
            return False
        if not self._is_visible(path):
            return False
        if filters is None:
            return True
        allowed_extensions = set()
        if filters.extension:
            allowed_extensions.add(filters.extension.lower())
        if filters.extensions:
            allowed_extensions.update(extension.lower() for extension in filters.extensions)
        if allowed_extensions and path.suffix.lower() not in allowed_extensions:
            return False
        if filters.name_contains and filters.name_contains.lower() not in path.name.lower():
            return False
        if filters.modified_within_days is not None:
            cutoff = datetime.now(UTC) - timedelta(days=filters.modified_within_days)
            modified_at = datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
            if modified_at < cutoff:
                return False
        return True

    def _is_visible(self, path: Path) -> bool:
        if self._index_hidden_files:
            return True
        return not any(part.startswith(".") for part in path.relative_to(path.anchor or "/").parts)

    def _score_match(self, path: Path, needle: str) -> int:
        if not needle or needle == "*":
            return 60
        name = path.name.lower()
        stem = path.stem.lower()
        full_path = str(path).lower()
        normalized_needle = self._normalize_token(needle)
        normalized_name = self._normalize_token(name)
        normalized_stem = self._normalize_token(stem)

        if name == needle:
            return 120
        if stem == needle:
            return 110
        if normalized_name == normalized_needle:
            return 108
        if normalized_stem == normalized_needle:
            return 104
        if name.startswith(needle):
            return 95
        if stem.startswith(needle):
            return 90
        if normalized_name.startswith(normalized_needle):
            return 88
        if normalized_stem.startswith(normalized_needle):
            return 84
        if needle in name:
            return 80
        if needle in stem:
            return 75
        if normalized_needle in normalized_name:
            return 72
        if normalized_needle in normalized_stem:
            return 68
        if needle in full_path:
            return 50
        return 0

    def _normalize_token(self, value: str) -> str:
        return re.sub(r"[^a-z0-9]+", "", value.lower())
