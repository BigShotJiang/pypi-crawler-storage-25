import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import {
  Cpu,
  Search,
  Circle,
  Zap,
  Cloud,
  GitCompareArrows,
  Plus,
  Star,
} from "lucide-react";
import { api, type Model } from "@/lib/api";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { FavoriteButton } from "@/components/favorite-button";
import { ExportDropdown } from "@/components/export-dropdown";
import { useFavorites } from "@/hooks/use-favorites";
import { useSortable } from "@/hooks/use-sortable";
import { SortableColumnHeader } from "@/components/ui/sortable-header";
import { SkeletonTableRows } from "@/components/ui/skeleton-table";
import { EmptyState } from "@/components/ui/empty-state";
import { ColumnToggle, type ColumnDefinition } from "@/components/ui/column-toggle";

const PROVIDER_COLORS: Record<string, string> = {
  anthropic: "bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20",
  openai: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20",
  google: "bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/20",
  meta: "bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/20",
  mistral: "bg-violet-500/10 text-violet-600 dark:text-violet-400 border-violet-500/20",
  cohere: "bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20",
  ollama: "bg-gray-500/10 text-gray-600 dark:text-gray-400 border-gray-500/20",
};

const SOURCE_ICONS: Record<string, typeof Zap> = {
  litellm: Cloud,
  manual: Zap,
};

const PROVIDER_TABS = ["All", "OpenAI", "Anthropic", "Google", "Ollama"] as const;

const MODEL_COLUMNS: ColumnDefinition[] = [
  { key: "name", label: "Model", locked: true },
  { key: "provider", label: "Provider" },
  { key: "context_window", label: "Context" },
  { key: "price", label: "Price" },
  { key: "source", label: "Source" },
];

const DEFAULT_MODEL_COLUMNS = new Set(MODEL_COLUMNS.map((c) => c.key));

/** Format a token count compactly: 128000 -> "128K", 1000000 -> "1M" */
function formatContextWindow(tokens: number | null): string {
  if (tokens === null || tokens === undefined) return "--";
  if (tokens >= 1_000_000) return `${(tokens / 1_000_000).toFixed(tokens % 1_000_000 === 0 ? 0 : 1)}M`;
  if (tokens >= 1_000) return `${(tokens / 1_000).toFixed(tokens % 1_000 === 0 ? 0 : 1)}K`;
  return String(tokens);
}

/** Format price per million tokens as currency. */
function formatPrice(price: number | null): string {
  if (price === null || price === undefined) return "--";
  if (price === 0) return "Free";
  if (price < 0.01) return `$${price.toFixed(4)}`;
  return `$${price.toFixed(2)}`;
}

function ModelRow({
  model,
  isSelected,
  onToggleSelect,
  onClick,
  visibleColumns,
}: {
  model: Model;
  isSelected: boolean;
  onToggleSelect: () => void;
  onClick: () => void;
  visibleColumns: Set<string>;
}) {
  const isActive = model.status === "active";
  return (
    <div className="flex items-center gap-4 border-b border-border/50 px-5 py-3 transition-colors last:border-0 hover:bg-muted/20">
      <input
        type="checkbox"
        checked={isSelected}
        onChange={(e) => {
          e.stopPropagation();
          onToggleSelect();
        }}
        className="size-3.5 shrink-0 rounded border-border accent-foreground"
      />

      <FavoriteButton id={model.id} />

      <div
        className="flex min-w-0 flex-1 cursor-pointer items-center gap-4"
        onClick={onClick}
      >
        <Circle
          className={cn(
            "size-1.5 shrink-0 fill-current",
            isActive ? "text-emerald-500" : "text-muted-foreground"
          )}
        />

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="font-mono text-sm">{model.name}</span>
          </div>
          {model.description && (
            <p className="mt-0.5 truncate text-xs text-muted-foreground">
              {model.description}
            </p>
          )}
        </div>

        {visibleColumns.has("provider") && (
          <Badge
            variant="outline"
            className={cn(
              "text-[10px] font-medium",
              PROVIDER_COLORS[model.provider.toLowerCase()] ??
                "bg-muted text-muted-foreground border-border"
            )}
          >
            {model.provider}
          </Badge>
        )}

        {visibleColumns.has("context_window") && (
          <div className="w-16 text-right font-mono text-xs text-muted-foreground">
            {formatContextWindow(model.context_window)}
          </div>
        )}

        {visibleColumns.has("price") && (
          <div className="w-28 text-right">
            <span className="font-mono text-[10px] text-muted-foreground">
              {formatPrice(model.input_price_per_million)}
              {" / "}
              {formatPrice(model.output_price_per_million)}
            </span>
          </div>
        )}

        {visibleColumns.has("source") && (
          <div className="flex w-20 items-center justify-end gap-1.5 text-xs text-muted-foreground">
            {(() => {
              const Icon = SOURCE_ICONS[model.source] ?? Zap;
              return <Icon className="size-3" />;
            })()}
            <span>{model.source}</span>
          </div>
        )}
      </div>
    </div>
  );
}

function CreateModelDialog() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [provider, setProvider] = useState("");
  const [description, setDescription] = useState("");
  const [contextWindow, setContextWindow] = useState("");
  const [inputPrice, setInputPrice] = useState("");
  const [outputPrice, setOutputPrice] = useState("");

  const resetForm = () => {
    setName("");
    setProvider("");
    setDescription("");
    setContextWindow("");
    setInputPrice("");
    setOutputPrice("");
  };

  const canSubmit = name.trim() && provider.trim();

  const handleCreate = () => {
    setOpen(false);
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={(val) => { setOpen(val); if (!val) resetForm(); }}>
      <DialogTrigger
        render={<Button size="sm" />}
      >
        <Plus className="size-3" data-icon="inline-start" />
        Add Model
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Model</DialogTitle>
          <DialogDescription>
            Register a new model in the organization registry.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium">Model Name</label>
              <Input
                placeholder="e.g. claude-sonnet-4"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="h-8 text-xs"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium">Provider</label>
              <select
                value={provider}
                onChange={(e) => setProvider(e.target.value)}
                className="h-8 w-full rounded-md border border-input bg-background px-2 text-xs outline-none"
              >
                <option value="">Select provider</option>
                <option value="anthropic">Anthropic</option>
                <option value="openai">OpenAI</option>
                <option value="google">Google</option>
                <option value="meta">Meta</option>
                <option value="mistral">Mistral</option>
                <option value="cohere">Cohere</option>
                <option value="ollama">Ollama</option>
              </select>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs font-medium">Description</label>
            <Input
              placeholder="Optional description..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="h-8 text-xs"
            />
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium">Context Window</label>
              <Input
                placeholder="e.g. 128000"
                value={contextWindow}
                onChange={(e) => setContextWindow(e.target.value)}
                className="h-8 text-xs"
                type="number"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium">Input $/M tokens</label>
              <Input
                placeholder="e.g. 3.00"
                value={inputPrice}
                onChange={(e) => setInputPrice(e.target.value)}
                className="h-8 text-xs"
                type="number"
                step="0.01"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium">Output $/M tokens</label>
              <Input
                placeholder="e.g. 15.00"
                value={outputPrice}
                onChange={(e) => setOutputPrice(e.target.value)}
                className="h-8 text-xs"
                type="number"
                step="0.01"
              />
            </div>
          </div>
        </div>

        <DialogFooter>
          <DialogClose render={<Button variant="outline" size="sm" />}>
            Cancel
          </DialogClose>
          <Button
            size="sm"
            onClick={handleCreate}
            disabled={!canSubmit}
          >
            Add Model
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ModelsPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [providerFilter, setProviderFilter] = useState("");
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [visibleColumns, setVisibleColumns] = useState<Set<string>>(DEFAULT_MODEL_COLUMNS);
  const { showOnlyFavorites, favorites } = useFavorites();

  const { data, isLoading, error } = useQuery({
    queryKey: ["models", { providerFilter }],
    queryFn: () =>
      api.models.list({ provider: providerFilter || undefined }),
    staleTime: 10_000,
  });

  const models = data?.data ?? [];
  const total = data?.meta.total ?? 0;

  let filtered = search
    ? models.filter(
        (m) =>
          m.name.toLowerCase().includes(search.toLowerCase()) ||
          m.description.toLowerCase().includes(search.toLowerCase()) ||
          m.provider.toLowerCase().includes(search.toLowerCase())
      )
    : models;

  if (showFavoritesOnly) {
    filtered = showOnlyFavorites(filtered);
  }

  // Sortable
  const { sortedData, sortKey, sortDirection, toggleSort } = useSortable(
    filtered as unknown as Record<string, unknown>[],
    "name",
    "asc"
  );
  const sortedModels = sortedData as unknown as Model[];

  function toggleSelect(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        if (next.size >= 3) return prev;
        next.add(id);
      }
      return next;
    });
  }

  function handleCompare() {
    const ids = Array.from(selectedIds).join(",");
    navigate(`/models/compare?ids=${ids}`);
  }

  const canCompare = selectedIds.size >= 2 && selectedIds.size <= 3;
  const hasFilter = !!(search || providerFilter || showFavoritesOnly);

  return (
    <div className="mx-auto max-w-5xl p-6">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-lg font-semibold tracking-tight">Models</h1>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {total} model{total !== 1 ? "s" : ""} in registry
          </p>
        </div>
        <div className="flex items-center gap-2">
          {selectedIds.size > 0 && (
            <button
              onClick={handleCompare}
              disabled={!canCompare}
              className={cn(
                "inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors",
                canCompare
                  ? "bg-foreground text-background hover:bg-foreground/90"
                  : "bg-muted text-muted-foreground cursor-not-allowed"
              )}
            >
              <GitCompareArrows className="size-3" />
              Compare ({selectedIds.size})
            </button>
          )}
          <ColumnToggle
            columns={MODEL_COLUMNS}
            visibleKeys={visibleColumns}
            onChange={setVisibleColumns}
          />
          <ExportDropdown
            data={filtered as unknown as Record<string, unknown>[]}
            filename="models"
          />
          <CreateModelDialog />
        </div>
      </div>

      {/* Provider filter tabs */}
      <div className="mb-3 flex items-center gap-1.5">
        {PROVIDER_TABS.map((tab) => {
          const value = tab === "All" ? "" : tab.toLowerCase();
          const isActive = providerFilter === value;
          return (
            <button
              key={tab}
              onClick={() => setProviderFilter(value)}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium transition-colors",
                isActive
                  ? "bg-foreground text-background"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              {tab}
            </button>
          );
        })}
      </div>

      {/* Search + favorites filter */}
      <div className="mb-4 flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 size-3.5 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Filter models..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-8 pl-9 text-xs"
          />
        </div>
        <button
          onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
          className={cn(
            "inline-flex items-center gap-1.5 rounded-md border border-input px-2.5 py-1.5 text-xs font-medium transition-colors",
            showFavoritesOnly
              ? "border-amber-400/50 bg-amber-500/10 text-amber-600 dark:text-amber-400"
              : "text-muted-foreground hover:bg-muted"
          )}
        >
          <Star className={cn("size-3", showFavoritesOnly && "fill-amber-400")} />
          Favorites
          {favorites.size > 0 && (
            <span className="text-[10px]">({favorites.size})</span>
          )}
        </button>
      </div>

      {/* Table */}
      <div className="overflow-hidden rounded-lg border border-border">
        <div className="flex items-center gap-4 border-b border-border bg-muted/30 px-5 py-2 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
          <span className="w-3.5" />
          <span className="w-3.5" />
          <span className="w-1.5" />
          <span className="flex-1">
            <SortableColumnHeader
              sortKey="name"
              currentSortKey={sortKey}
              currentDirection={sortDirection}
              onSort={toggleSort}
            >
              Model
            </SortableColumnHeader>
          </span>
          {visibleColumns.has("provider") && (
            <span className="w-24 text-center">
              <SortableColumnHeader
                sortKey="provider"
                currentSortKey={sortKey}
                currentDirection={sortDirection}
                onSort={toggleSort}
              >
                Provider
              </SortableColumnHeader>
            </span>
          )}
          {visibleColumns.has("context_window") && (
            <span className="w-16 text-right">
              <SortableColumnHeader
                sortKey="context_window"
                currentSortKey={sortKey}
                currentDirection={sortDirection}
                onSort={toggleSort}
              >
                Context
              </SortableColumnHeader>
            </span>
          )}
          {visibleColumns.has("price") && (
            <span className="w-28 text-right">
              <SortableColumnHeader
                sortKey="input_price_per_million"
                currentSortKey={sortKey}
                currentDirection={sortDirection}
                onSort={toggleSort}
              >
                Price (in/out)
              </SortableColumnHeader>
            </span>
          )}
          {visibleColumns.has("source") && (
            <span className="w-20 text-right">
              <SortableColumnHeader
                sortKey="source"
                currentSortKey={sortKey}
                currentDirection={sortDirection}
                onSort={toggleSort}
              >
                Source
              </SortableColumnHeader>
            </span>
          )}
        </div>

        {isLoading ? (
          <SkeletonTableRows rows={5} columns={4} />
        ) : error ? (
          <div className="px-6 py-12 text-center text-sm text-destructive">
            Failed to load models: {(error as Error).message}
          </div>
        ) : sortedModels.length === 0 ? (
          <EmptyState
            icon={Cpu}
            title={hasFilter ? "No models match your filters" : "No models registered"}
            description={
              hasFilter
                ? "Try adjusting your search or filters."
                : "Connect a LiteLLM gateway or register models manually to see them here."
            }
          />
        ) : (
          sortedModels.map((model) => (
            <ModelRow
              key={model.id}
              model={model}
              isSelected={selectedIds.has(model.id)}
              onToggleSelect={() => toggleSelect(model.id)}
              onClick={() => navigate(`/models/${model.id}`)}
              visibleColumns={visibleColumns}
            />
          ))
        )}
      </div>
    </div>
  );
}
