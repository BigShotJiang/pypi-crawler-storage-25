# NeoSWE

Next-generation software engineering benchmark. Coming soon.

## Install

```bash
pip install neoswe
```
