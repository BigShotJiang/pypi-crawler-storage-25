import asyncio
import hashlib
import json
import shlex
import uuid
from collections import deque
from os import getenv, environ
from typing import Any, Callable, Dict, List, Optional

from loguru import logger
from toon import encode as toon_encode
from xpander_sdk import Configuration
from xpander_sdk.consts.api_routes import APIRoute
from xpander_sdk.core.context_optimizer.context_optimizer import (
    XPanderContextOptimizer,
    unwrap_tool_result_content,
)
from xpander_sdk.core.context_optimizer.encryption import (
    decrypt,
    derive_key,
    is_context_optimization_file,
)
from xpander_sdk.core.xpander_api_client import APIClient
from xpander_sdk.models.generic import LLMCredentials
from xpander_sdk.models.shared import OutputFormat, ThinkMode
from xpander_sdk.modules.agents.agents_module import Agents
from xpander_sdk.modules.agents.models.agent import (
    AgentGraphItemType,
    LLMReasoningEffort,
)
from xpander_sdk.modules.agents.sub_modules.agent import Agent
from xpander_sdk.modules.backend.utils.mcp_oauth import authenticate_mcp_server
from xpander_sdk.modules.backend.utils.tool_call_events import (
    extract_reasoning,
    is_reasoning_tool,
    report_reasoning_event,
    report_tool_call_request,
    report_tool_call_result,
    should_skip_tool_report,
)
from xpander_sdk.modules.tasks.sub_modules.task import Task
from xpander_sdk.modules.tools_repository.models.mcp import (
    MCPOAuthGetTokenGenericResponse,
    MCPOAuthGetTokenResponse,
    MCPOAuthResponseType,
    MCPServerAuthType,
    MCPServerDetails,
    MCPServerTransport,
    MCPServerType,
)
from xpander_sdk.modules.tools_repository.models.tool_invocation_result import (
    ToolInvocationResult,
)
from xpander_sdk.modules.tools_repository.sub_modules.tool import Tool
from xpander_sdk.modules.tools_repository.utils.schemas import build_model_from_schema
from agno.agent import Agent as AgnoAgent
from agno.team import Team as AgnoTeam
from agno.memory import MemoryManager
from agno.guardrails import PIIDetectionGuardrail
from agno.guardrails import PromptInjectionGuardrail
from agno.guardrails import OpenAIModerationGuardrail
from agno.models.base import Model

from xpander_sdk.utils.event_loop import run_sync

# Feature flags
USE_TOON: bool = False


# Context optimization system prompt guidance — always injected (Layer 1 always runs)
CONTEXT_OPTIMIZATION_INSTRUCTIONS = """
<context_optimization>
Some tool call results may be truncated to save context space. When you see a message containing
"[TRUNCATED OUTPUT]" with a workspace file path under `CONTEXT_OPTIMIZATION/<uuid>.xp`, the full
result has been saved (encrypted) to the agent's workspace.

If after a session compaction you see a `<session_backup>` pointer to
`CONTEXT_OPTIMIZATION/session_backup_<task_id>.xp`, that file holds the full pre-compaction
transcript (encrypted) — use it only when the summary lacks a specific detail.

To retrieve any of these files, ALWAYS call `xpworkspace-file-read` with the provided path.
The file-read tool decrypts the content transparently. Do NOT use bash `cat`,
`xpworkspace-bash`, or any other reader — they return base64 ciphertext, not plaintext.

Do NOT guess or hallucinate truncated content — always fetch it if you need it.
</context_optimization>
"""

# Workspace output guidance — only injected when the agent has workspace tools
WORKSPACE_OUTPUT_INSTRUCTIONS = """
<large_output_strategy>
If your output would exceed roughly 4,000 words, write it to a file in the workspace instead of
responding inline — otherwise you will hit the output token limit and lose content.
- Use xpworkspace-file-write as the primary method for creating files.
- For incremental builds or when you also need to run commands, use xpworkspace-bash.
  Avoid bash heredoc (cat << 'EOF') for large content — delimiter typos cause content leaks.
- NEVER start file paths with '/' — always use relative paths from the workspace root
  (e.g. 'output/report.html' not '/output/report.html' or '/tmp/report.html').
- /tmp/ is ephemeral and cleared between sessions — never use it for output files.
- After the file is complete, use xpworkspace-file-share to get a shareable link.

<chunked_writes>
For large output (long docs, many-section files, big code), NEVER emit the whole
payload in one xpworkspace-file-write call — output token limit truncates silently
mid-write. Split into ordered chunks:

1. Plan chunks FIRST. Outline N sections in one short message, number them 1/N..N/N.
   Target ≤3,000 words per chunk to leave headroom.
2. Chunk 1: `xpworkspace-file-write` with `append=false` — writes header + section 1.
3. Chunks 2..N: `xpworkspace-file-write` with `append=true` — each adds ONE section.
   (Bash `cat >>` heredoc works but fragile; prefer append=true.)
4. Final verify: `xpworkspace-bash` `wc -l <path>` and `tail -n 20 <path>` to confirm
   size matches plan and last chunk ended cleanly. Then xpworkspace-file-share.

Concatenation rules (prevent broken joins + duplication):
- Each chunk content MUST start exactly where previous ended — no repeated headings,
  no re-stating section already written, no "as I mentioned above" bridging text.
- Include the trailing `\\n` on every non-final chunk so next chunk starts on new line.
- Do NOT wrap chunks in markdown code fences unless the whole file is code — fences
  from multiple chunks will nest and break rendering.
- If content is code: close every block/function WITHIN its chunk — never split a
  function/class across two writes. Pick chunk boundaries at top-level declarations.
- If content is structured (JSON/YAML/XML): write it as ONE chunk if possible, else
  split only at array/list element boundaries and hand-assemble opening/closing brackets.
- After each append, do NOT re-read the file to "check progress" — wastes tokens.
  Trust the tool result; only read at the end if verification fails.
- If you lose track of chunk index, run `tail -n 30 <path>` once to see where you
  left off — do NOT regenerate earlier chunks.

Token-optimization:
- Do NOT echo the chunk content back in assistant prose before/after the write.
- Do NOT restate the chunk plan between writes — one outline at the start is enough.
- Keep inter-write assistant messages ≤1 sentence ("writing chunk 3/7").
</chunked_writes>
</large_output_strategy>
"""

# Compact tool guidance — only injected when xpcompact_context is registered
COMPACT_TOOL_INSTRUCTIONS = """
<compact_tool>
You have access to `xpcompact_context` for manual context compression. This is a heavyweight
operation — use it only when there is evidence of context pressure, not preemptively.
Trigger conditions (at least one must be true):
- Multiple tool results in the current session show [TRUNCATED OUTPUT] markers
- You just finished a distinct work phase (e.g., completed a feature, resolved a bug) AND
  are about to pivot to substantially different work
- The session has already been auto-compacted (you see a continuation summary message at the
  start of the conversation), meaning you are in a long session with limited remaining space
Do NOT call this tool:
- In the middle of an active task or investigation
- Just because the conversation is long — length alone is not a reason
- More than once per task phase — one compaction per major transition is sufficient
When calling, pass a `focus` parameter describing what the summary MUST preserve.
Example: xpcompact_context(focus="preserve the API endpoint signatures, test results, and the migration plan")
</compact_tool>
"""


def _classify_tool_error(error: Exception) -> str:
    """Classify a tool error as transient, auth, or client.

    Returns:
        str: One of 'transient', 'auth', 'client', or 'unknown'.
    """
    error_str = str(error).lower()

    # Check for HTTP status codes in error messages
    if any(
        code in error_str
        for code in ["timeout", "timed out", "connection reset", "connection refused"]
    ):
        return "transient"
    if any(
        code in error_str
        for code in ["429", "rate limit", "too many requests", "quota exceeded"]
    ):
        return "transient"
    if any(
        code in error_str
        for code in [
            "500",
            "502",
            "503",
            "504",
            "internal server error",
            "bad gateway",
            "service unavailable",
        ]
    ):
        return "transient"
    if any(
        code in error_str
        for code in [
            "401",
            "403",
            "unauthorized",
            "forbidden",
            "authentication",
            "permission denied",
        ]
    ):
        return "auth"
    if any(
        code in error_str
        for code in [
            "400",
            "422",
            "bad request",
            "unprocessable",
            "validation error",
            "invalid",
        ]
    ):
        return "client"

    return "unknown"


async def _invoke_with_transient_retry(
    function_name: str,
    function_call: Callable,
    arguments: Dict[str, Any],
    max_retries: int = 2,
) -> Any:
    """Invoke a tool function with automatic retry for transient errors.

    - Transient errors (timeout, 5xx, rate limit): Retry up to max_retries times with backoff.
    - Auth errors (401, 403): Raise immediately.
    - Client errors (400, 422): Raise immediately.

    Args:
        function_name: Name of the tool function.
        function_call: The callable to invoke.
        arguments: Arguments to pass to the function.
        max_retries: Maximum number of retries for transient errors.

    Returns:
        The result from the function call.
    """
    last_error = None

    for attempt in range(max_retries + 1):
        try:
            if asyncio.iscoroutinefunction(function_call):
                return await function_call(**arguments)
            else:
                return function_call(**arguments)
        except Exception as e:
            last_error = e
            error_type = _classify_tool_error(e)

            if error_type == "transient" and attempt < max_retries:
                backoff = (attempt + 1) * 1.5  # 1.5s, 3s
                logger.warning(
                    f"Transient error on tool '{function_name}' (attempt {attempt + 1}/{max_retries + 1}): {e}. "
                    f"Retrying in {backoff}s..."
                )
                await asyncio.sleep(backoff)
                continue

            # Non-transient or exhausted retries — raise
            raise

    # Should never reach here, but just in case
    raise last_error


async def build_agent_args(
    xpander_agent: Agent,
    task: Optional[Task] = None,
    override: Optional[Dict[str, Any]] = None,
    tools: Optional[List[Callable]] = None,
    is_async: Optional[bool] = True,
    auth_events_callback: Optional[Callable] = None,
) -> Dict[str, Any]:
    model = _load_llm_model(agent=xpander_agent, override=override, task=task)
    args: Dict[str, Any] = {"id": xpander_agent.id, "store_events": True}

    _configure_output(args=args, agent=xpander_agent, task=task)
    _configure_session_storage(args=args, agent=xpander_agent, task=task)
    _configure_agentic_memory(args=args, agent=xpander_agent, task=task)
    _configure_context_optimizer(args=args, agent=xpander_agent, task=task, model=model)
    await _attach_async_dependencies(
        args=args, agent=xpander_agent, task=task, model=model, is_async=is_async
    )
    _configure_knowledge_bases(args=args, agent=xpander_agent)
    _configure_additional_context(args=args, agent=xpander_agent, task=task)
    # Configure pre-hooks (guardrails, etc.)
    _configure_pre_hooks(args=args, agent=xpander_agent, model=model)

    args["tools"] = await _resolve_agent_tools(
        agent=xpander_agent, task=task, auth_events_callback=auth_events_callback
    )

    if tools and len(tools) != 0:
        args["tools"].extend(tools)

    should_use_reasoning_tools = (
        True if xpander_agent.agno_settings.reasoning_tools_enabled else False
    )

    if not xpander_agent.is_a_team and should_use_reasoning_tools:
        from agno.tools.reasoning import ReasoningTools

        args["tools"].append(
            ReasoningTools(
                enable_think=True,
                enable_analyze=True,
                add_instructions=True,
                add_few_shot=True,
                instructions="use 'think' and 'analyze' ONLY when its not a simple task of 'hi', 'what can you do' and such low complexity tasks",
            )
        )

    # team
    if xpander_agent.is_a_team:
        sub_agents = xpander_agent.graph.sub_agents

        # load sub agents
        sub_agents = await asyncio.gather(
            *[
                Agents(
                    configuration=Configuration(
                        api_key=xpander_agent.configuration.api_key,
                        organization_id=xpander_agent.configuration.organization_id,
                        base_url=xpander_agent.configuration.base_url,
                    )
                ).aget(agent_id=sub_agent_id)
                for sub_agent_id in sub_agents
            ]
        )
        if sub_agents and len(sub_agents):
            base_state = xpander_agent.configuration.state.model_copy()
            for sub_agent in sub_agents:
                sub_agent.configuration.state.task = base_state.task
        # convert to members
        members = await asyncio.gather(
            *[
                build_agent_args(
                    xpander_agent=sub_agent,
                    override=override,
                    task=task,
                    is_async=is_async,
                    auth_events_callback=auth_events_callback,
                )
                for sub_agent in sub_agents
            ]
        )

        # set members to use parent agent model
        if members and len(members) != 0:
            for member in members:
                member["model"] = model

        args.update(
            {
                "members": [
                    (
                        AgnoAgent(**member)
                        if "members" not in member
                        else AgnoTeam(**member)
                    )
                    for member in members
                ],
                "add_member_tools_to_context": True,
                "share_member_interactions": True,
                "show_members_responses": True,
            }
        )

    args.update(
        {
            "name": xpander_agent.name,
            "model": model,
            "description": xpander_agent.instructions.description,
            "instructions": (
                task.instructions_override
                if task.instructions_override
                else xpander_agent.instructions.instructions
            ),
            "expected_output": (
                task.expected_output
                if task and task.expected_output
                else xpander_agent.expected_output
            ),
            "add_datetime_to_context": True,
        }
    )

    if (
        xpander_agent.is_a_team
        and xpander_agent.expected_output
        and len(xpander_agent.expected_output) != 0
    ):
        args[
            "instructions"
        ] += f"""\n
            <expected_output>
            {xpander_agent.expected_output}
            </expected_output>
        """

    if override:
        args.update(override)

    # Append context optimization guidance (must be after all instruction overrides)
    if "instructions" not in args or not args["instructions"]:
        args["instructions"] = ""
    args["instructions"] += CONTEXT_OPTIMIZATION_INSTRUCTIONS

    # Conditionally inject workspace output guidance (only when workspace tools are present)
    _has_workspace_tools = any(
        getattr(t, "__name__", getattr(t, "name", "")).startswith("xpworkspace-")
        for t in args.get("tools", [])
    )
    if _has_workspace_tools:
        args["instructions"] += WORKSPACE_OUTPUT_INSTRUCTIONS

    # Register xpcompact_context tool and inject its guidance (fix #1: after tools are set)
    from agno.tools.function import Function

    compact_tool = Function(
        name="xpcompact_context",
        description=(
            "Compress conversation history to free context space. "
            "ONLY call this when you observe concrete signs of context pressure: "
            "(1) you are seeing many [TRUNCATED OUTPUT] markers in recent tool results, "
            "(2) you just completed a major task phase and are about to start unrelated work, or "
            "(3) the system has already auto-compacted this session once (meaning context is tight). "
            "Do NOT call speculatively or 'just in case'. "
            "Pass an optional focus string to guide what the summary preserves."
        ),
        parameters={
            "type": "object",
            "properties": {
                "focus": {
                    "type": "string",
                    "description": "What the compaction summary should focus on preserving. E.g. 'preserve the API signatures, test results, and migration plan'.",
                },
                "headers": {
                    "type": "object",
                    "properties": {
                        "toolcallreasoningtitle": {
                            "type": "string",
                            "description": 'Action-oriented title (max 5 words) describing the purpose. Example: "Compact context for next phase".',
                        },
                        "toolcallreasoningdescription": {
                            "type": "string",
                            "description": 'One-sentence markdown summary of the action and goal (max 100 characters). Example: "Free context space after completing research phase."',
                        },
                    },
                    "required": [
                        "toolcallreasoningtitle",
                        "toolcallreasoningdescription",
                    ],
                },
            },
            "required": ["headers"],
        },
        entrypoint=lambda focus="", headers=None: f"Compaction scheduled with focus: {focus}",
    )
    args["tools"].append(compact_tool)
    args["instructions"] += COMPACT_TOOL_INSTRUCTIONS

    # Stuck detection: track recent tool call signatures to detect loops
    _tool_call_history: deque = deque(maxlen=10)
    _STUCK_THRESHOLD = 3  # consecutive identical calls to trigger warning

    # append tools hooks
    async def on_tool_call_hook(
        function_name: str, function_call: Callable, arguments: Dict[str, Any]
    ):
        # preflight and monitoring + metrics
        try:
            matched_tool = (
                (
                    xpander_agent.tools.get_tool_by_id(tool_id=function_name)
                    or xpander_agent.tools.get_tool_by_name(tool_name=function_name)
                )
                if xpander_agent.tools and len(xpander_agent.tools.list) != 0
                else None
            )
        except Exception:
            pass

        # Stuck detection: compute signature and check for repeated calls
        stuck_warning = None
        try:
            # Skip stuck detection for plan management tools (they're expected to repeat)
            if not function_name.startswith("xp"):
                args_hash = hashlib.md5(
                    json.dumps(arguments, sort_keys=True, default=str).encode()
                ).hexdigest()[:12]
                call_signature = f"{function_name}:{args_hash}"
                _tool_call_history.append(call_signature)

                # Check for consecutive identical calls
                if len(_tool_call_history) >= _STUCK_THRESHOLD:
                    recent = list(_tool_call_history)[-_STUCK_THRESHOLD:]
                    if len(set(recent)) == 1:
                        stuck_warning = (
                            f"⚠️ STUCK DETECTION: You have called '{function_name}' with identical arguments "
                            f"{_STUCK_THRESHOLD} times in a row. This suggests you are in a loop. "
                            f"Try a different approach, use different parameters, or mark the current task as blocked."
                        )
                        logger.warning(
                            f"Stuck detection triggered for agent {xpander_agent.id}: {call_signature} repeated {_STUCK_THRESHOLD}x"
                        )
        except Exception:
            pass

        # Generate a fresh request_id for this tool invocation so multiple
        # calls to the same tool remain distinct in the activity thread.
        # Deep-planning tools are excluded from activity reporting.
        # Reasoning tools (think/analyze) are reported via a separate
        # Think/Analyze event, not as a regular tool call.
        activity_request_id: Optional[str] = None
        if task and getattr(task, "id", None) and is_reasoning_tool(function_name):
            try:
                asyncio.create_task(
                    report_reasoning_event(
                        task=task,
                        tool_name=function_name,
                        arguments=arguments if isinstance(arguments, dict) else None,
                    )
                )
            except Exception:
                pass
        elif (
            task
            and getattr(task, "id", None)
            and not should_skip_tool_report(function_name)
        ):
            activity_request_id = str(uuid.uuid4())
            # Fire-and-forget: reports every other tool type (local, remote,
            # MCP, knowledge-base, workspace, xpcompact_context).
            try:
                asyncio.create_task(
                    report_tool_call_request(
                        task=task,
                        request_id=activity_request_id,
                        operation_id=function_name,
                        tool_name=function_name,
                        payload=arguments,
                        reasoning=extract_reasoning(
                            arguments if isinstance(arguments, dict) else None
                        ),
                    )
                )
            except Exception:
                pass

        error = None
        result = None
        try:
            # Call the function with auto-retry for transient errors
            result = await _invoke_with_transient_retry(
                function_name=function_name,
                function_call=function_call,
                arguments=arguments,
                max_retries=2,
            )

        except Exception as e:
            error = str(e)
            # Emit ToolCallResult with is_error=True before re-raising.
            if activity_request_id and task:
                try:
                    asyncio.create_task(
                        report_tool_call_result(
                            task=task,
                            request_id=activity_request_id,
                            operation_id=function_name,
                            tool_name=function_name,
                            payload=arguments,
                            result=error,
                            is_error=True,
                        )
                    )
                except Exception:
                    pass
            raise
        finally:
            try:
                if not matched_tool and task:  # agent / mcp tool
                    tool_instance = Tool(
                        configuration=xpander_agent.configuration,
                        id=function_name,
                        name=function_name,
                        method="GET",
                        path=f"/tools/{function_name}",
                        should_add_to_graph=False,
                        is_local=True,
                        is_synced=True,
                        description=function_name,
                    )
                    parsed_result = None
                    try:
                        parsed_result = dict(result)
                    except Exception:
                        parsed_result = result

                    await tool_instance.agraph_preflight_check(
                        agent_id=xpander_agent.id,
                        configuration=tool_instance.configuration,
                        task_id=task.id,
                        payload=(
                            {"input": arguments, "output": error or parsed_result}
                            if isinstance(arguments, dict)
                            else None
                        ),
                    )
            except Exception:
                pass

        # Helper used at every success return point to emit the ToolCallResult event.
        def _emit_success_result(
            final_result: Any,
            is_error: bool = False,
            skip_truncation: bool = False,
            inline_preview: Optional[str] = None,
        ) -> None:
            if not activity_request_id or not task:
                return
            try:
                if inline_preview is not None:
                    # The hook already applied the workspace preview + pointer;
                    # report that verbatim so the activity log matches what
                    # the LLM sees on context.
                    payload_for_activity = inline_preview
                    activity_skip_truncation = True
                else:
                    payload_for_activity = final_result
                    if hasattr(final_result, "result"):
                        payload_for_activity = final_result.result
                    elif hasattr(final_result, "content"):
                        payload_for_activity = final_result.content
                    activity_skip_truncation = skip_truncation
                # For CONTEXT_OPTIMIZATION file reads the agent explicitly asked for
                # the FULL offloaded content; report it verbatim rather than
                # truncating it again for activity. For every other tool the
                # default Layer-1-aligned truncation is applied inside
                # report_tool_call_result, so the activity log mirrors what the
                # LLM sees in context.
                asyncio.create_task(
                    report_tool_call_result(
                        task=task,
                        request_id=activity_request_id,
                        operation_id=function_name,
                        tool_name=function_name,
                        payload=arguments,
                        result=payload_for_activity,
                        is_error=is_error,
                        skip_truncation=activity_skip_truncation,
                    )
                )
            except Exception:
                pass

        # Layer 3: detect xpcompact_context tool call and set flag on optimizer
        if function_name == "xpcompact_context":
            try:
                focus = ""
                if isinstance(arguments, dict):
                    payload = arguments.get("payload", {})
                    body = (
                        payload.get("body_params", {})
                        if isinstance(payload, dict)
                        else {}
                    )
                    focus = body.get("focus", "") or arguments.get("focus", "")
                optimizer = args.get("compression_manager")
                if isinstance(optimizer, XPanderContextOptimizer):
                    optimizer.compact_requested = True
                    optimizer.compact_focus = focus
                    logger.info(
                        f"[context-optimizer] layer 3: compact requested (focus={focus!r})"
                    )
                scheduled_message = "Context compaction scheduled. It will execute after this turn's tool calls complete."
                _emit_success_result(scheduled_message)
                return scheduled_message
            except Exception as e:
                logger.warning(
                    f"[context-optimizer] layer 3: failed to schedule compact: {e}"
                )
                failure_message = f"Failed to schedule compaction: {e}"
                _emit_success_result(failure_message, is_error=True)
                return failure_message

        # Decrypt context optimization files read from workspace
        # Also tracks whether this specific tool call retrieved an offloaded
        # CONTEXT_OPTIMIZATION file so the activity result is NOT re-truncated
        # (the agent asked for the full content on purpose).
        is_context_optimization_read = False
        if function_name == "xpworkspace-file-read":
            try:
                read_path = (
                    arguments.get("payload", {}).get("body_params", {}).get("path", "")
                )
                if is_context_optimization_file(read_path):
                    is_context_optimization_read = True
                    key = derive_key(
                        org_id=xpander_agent.configuration.organization_id,
                        agent_id=xpander_agent.id,
                        task_id=task.id if task else "",
                    )
                    if isinstance(result, ToolInvocationResult) and result.result:
                        content = (
                            result.result.get("content", "")
                            if isinstance(result.result, dict)
                            else result.result
                        )
                        result.result = (
                            decrypt(content, key)
                            if isinstance(result.result, dict)
                            else decrypt(result.result, key)
                        )
                    elif hasattr(result, "content") and isinstance(result.content, str):
                        result.content = decrypt(result.content, key)
                    elif isinstance(result, dict) and "content" in result:
                        result["content"] = decrypt(result["content"], key)
            except Exception as e:
                logger.warning(
                    f"[context-optimizer] failed to decrypt context optimization file: {e}"
                )

        # Pre-layer 0: toon-encode JSON tool results to reduce verbosity
        # Runs before context optimizer sees the content, reducing what needs to be compressed.
        if USE_TOON and not function_name.startswith("xp"):
            try:
                if isinstance(result, ToolInvocationResult):
                    json_result = (
                        json.loads(result.result)
                        if isinstance(result.result, str)
                        else result.result
                    )
                    result.result = toon_encode(json_result)
                elif hasattr(result, "content"):
                    json_result = json.loads(result.content)
                    result.content = toon_encode(json_result)
            except Exception:
                pass

        # Append stuck warning to tool result so the LLM sees it
        if stuck_warning:
            try:
                if isinstance(result, ToolInvocationResult):
                    result.result = (
                        f"{result.result}\n\n{stuck_warning}"
                        if result.result
                        else stuck_warning
                    )
                elif hasattr(result, "content") and isinstance(result.content, str):
                    result.content = f"{result.content}\n\n{stuck_warning}"
            except Exception:
                pass

        # Inline Layer 1 microcompaction: offload large results to the workspace
        # RIGHT NOW (same turn) so the LLM immediately sees the preview +
        # retrieval pointer instead of waiting for the next compress() cycle.
        # Skipped for CONTEXT_OPTIMIZATION reads (agent asked for full content).
        inline_preview_for_activity: Optional[str] = None
        if not is_context_optimization_read:
            try:
                optimizer = args.get("compression_manager")
                if isinstance(optimizer, XPanderContextOptimizer):
                    # Derive the LLM-facing content string. Mirrors what Layer 1
                    # would see in msg.content after agno serializes our result.
                    llm_content: Any = None
                    if isinstance(result, ToolInvocationResult):
                        llm_content = result.result
                    elif hasattr(result, "content"):
                        llm_content = result.content
                    else:
                        llm_content = result
                    clean_content = unwrap_tool_result_content(llm_content)
                    replacement, workspace_path = await optimizer.maybe_offload_content(
                        content=clean_content,
                        tool_name=function_name,
                    )
                    if replacement is not None:
                        # Overwrite the tool output so agno stores the preview
                        # + workspace pointer as msg.content.
                        if isinstance(result, ToolInvocationResult):
                            result.result = replacement
                        elif hasattr(result, "content"):
                            try:
                                result.content = replacement
                            except Exception:
                                pass
                        else:
                            result = replacement
                        inline_preview_for_activity = replacement
                        # Prevent the fallback loop from re-offloading.
                        tc_id = None
                        if isinstance(arguments, dict):
                            tc_id = arguments.get("tool_call_id")
                        if not tc_id and activity_request_id:
                            tc_id = activity_request_id
                        if tc_id:
                            optimizer._inline_offloaded_tool_call_ids.add(tc_id)
            except Exception as exc:
                logger.warning(
                    f"[context-optimizer] inline layer 1 offload failed: {exc}"
                )

        # Emit ToolCallResult (success) using the final post-processed value
        # so the activity-log report matches what the LLM actually sees,
        # including the Layer 1 preview + workspace pointer for large outputs.
        # For CONTEXT_OPTIMIZATION workspace reads we emit the full decrypted
        # content verbatim rather than re-truncating.
        _emit_success_result(
            result,
            skip_truncation=is_context_optimization_read,
            inline_preview=inline_preview_for_activity,
        )

        # Return the result
        return result

    if not "tool_hooks" in args:
        args["tool_hooks"] = []

    # disable hooks for NeMo due to issue with tool_hooks and NeMo
    if xpander_agent.using_nemo == False:
        args["tool_hooks"].append(on_tool_call_hook)

    # fix gpt-5 temp
    if args["model"] and args["model"].id and args["model"].id.startswith("gpt-5"):
        del args["model"].temperature

    # configure deep planning guidance
    _configure_deep_planning_guidance(args=args, agent=xpander_agent, task=task)
    return args


def _configure_deep_planning_guidance(
    args: Dict[str, Any], agent: Agent, task: Optional[Task]
) -> None:
    if (
        args
        and agent
        and task
        and agent.deep_planning
        and task.deep_planning.enabled == True
    ):
        task.reload()  # reload the task - get latest version
        # add instructions guidance
        if not "instructions" in args:
            args["instructions"] = ""

        args[
            "instructions"
        ] += """\n
            <important_planning_instructions>
            ## **Deep Planning Tools - Essential for Multi-Step Tasks**

            **ABSOLUTE RULE - READ THIS FIRST**:
            
            IF YOU ARE ABOUT TO WRITE A QUESTION TO THE USER, STOP AND CHECK:
            - Did I call xpstart_execution_plan? 
              - YES → Use xpask_for_information tool (DO NOT write the question in your response)
              - NO → You can ask directly
            
            SIMPLE RULE:
            - BEFORE calling xpstart_execution_plan: You CAN ask questions directly in your response
            - AFTER calling xpstart_execution_plan: You are FORBIDDEN from writing questions - use xpask_for_information tool
            
            Once execution has started, writing things like "Before I proceed, I need to know..." or "I need clarification on..."
            or "Please choose one of the following..." in your response text is STRICTLY PROHIBITED and will cause execution failures.
            
            MANDATORY CHECK BEFORE ASKING: Have I started the plan? YES = use tool | NO = can ask directly

            When handling complex tasks with multiple steps, use these planning tools to track progress systematically.

            ### **Core Workflow**
            1. **CREATE** plan at the start (`xpcreate_agent_plan`)
            2. **START** plan execution (`xpstart_execution_plan`) - MANDATORY to enable enforcement
            3. **CHECK** plan before each action (`xpget_agent_plan`) - note the FULL UUID of the task you'll work on
            4. **DO THE WORK** for one task
            5. **COMPLETE** task IMMEDIATELY - call `xpcomplete_agent_plan_items` with the FULL UUID RIGHT AFTER finishing work (DO NOT DELAY!)
            6. **VERIFY** progress by calling `xpget_agent_plan` again to confirm the task was marked complete and see what's next
            7. **ASK** user for info if needed (`xpask_for_information`) - MANDATORY if you need input or want to pause
            8. Repeat steps 3-7 until all tasks are done
            
            **STAY ORIENTED**: Call `xpget_agent_plan` frequently — at minimum before starting each new task AND after marking one complete. This keeps you oriented on overall progress and prevents losing track of the plan.
            
            **UUID REQUIREMENT**: All task IDs are full UUIDs (e.g., '35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92'). You MUST use the exact complete UUID string from the plan when marking tasks complete.
            
            **CRITICAL RULES - ABSOLUTE REQUIREMENTS**: 
            - Mark each task complete THE MOMENT you finish it - not later, not at the end, RIGHT AWAY!
            - **CHECK BEFORE ASKING**: Did you call xpstart_execution_plan?
              - If YES: Use xpask_for_information tool ONLY (never write questions in response)
              - If NO: Can ask directly
            - **AFTER plan starts: Writing questions in your response is FORBIDDEN** - violates execution protocol
            - If you called xpstart_execution_plan and then write "I need clarification" or "Before I proceed" or "Please choose", you are VIOLATING THE PROTOCOL
            - AFTER xpstart_execution_plan: The ONLY way to ask users questions is through `xpask_for_information` tool - ZERO EXCEPTIONS!

            ---

            ### **Tool Reference**

            #### **1. xpcreate_agent_plan** - Create Initial Plan
            **When to use**: At the very start of any multi-step task, ONLY if no plan exists yet
            **Note**: After creating a plan, you MUST call `xpstart_execution_plan` to begin enforcement

            **How to use**:
            - Pass an array of task objects (NOT strings)
            - Each task must have a `title` field with short, explanatory description
            - Example format:
            ```json
            {
            "body_params": {
                "tasks": [
                {"title": "Research API requirements"},
                {"title": "Design data schema"},
                {"title": "Implement endpoints"},
                {"title": "Write tests"},
                {"title": "Deploy to staging"}
                ]
            }
            }
            ```
            **Important**: 
            - Include ALL steps needed from start to finish
            - Each title should be clear and actionable (3-6 words)
            - Do NOT pass plain strings like `["Task 1", "Task 2"]` - must be objects!

            ---

            #### **2. xpget_agent_plan** - View Current Plan
            **When to use**: Before deciding what to do next; to check progress

            **Returns**: 
            - All tasks with their IDs, titles, and completion status
            - Use this to know what's done and what remains

            **No parameters needed** - just call the tool

            ---

            #### **3. xpcomplete_agent_plan_items** - Mark Task(s) Complete
            **When to use**: **IMMEDIATELY** after finishing one or more tasks (NOT before, NOT later, RIGHT NOW!)

            **How to use**:
            ```json
            // Single task
            {
            "body_params": {
                "ids": ["35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92"]
            }
            }
            
            // Multiple tasks (when finishing related tasks together)
            {
            "body_params": {
                "ids": ["35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92", "8a3c4f12-9b7e-4d2a-b5c8-1f6e9a0d3b4c", "f2b9d1c7-3e8a-4b6f-9d2c-5a7e1f4b8c3d"]
            }
            }
            ```
            **🚨 CRITICAL - NON-NEGOTIABLE RULES**: 
            - IDs must be the FULL UUID strings (e.g., '35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92') from the plan's 'id' field
            - Get these exact UUID strings from xpget_agent_plan before calling this tool
            - Call THIS TOOL the INSTANT you finish task(s)
            - Can mark single or multiple tasks complete in one call
            - Use multiple FULL UUIDs when finishing related tasks at the same time
            - DO NOT use shortened IDs, abbreviations, or partial UUIDs - must be complete UUID strings
            - DO NOT postpone marking completion
            - DO NOT be lazy - mark it complete RIGHT AFTER the work is done
            - This is MANDATORY for progress tracking and continuation
            - If you finish a task and don't mark it complete immediately, you are doing it WRONG
            
            **Pattern**: Finish work → Get task UUID from plan → IMMEDIATELY call xpcomplete_agent_plan_items with FULL UUID → Move to next task

            ---

            #### **4. xpadd_new_agent_plan_item** - Add Discovered Task
            **When to use**: When you discover additional work needed during execution

            **How to use**:
            ```json
            {
            "body_params": {
                "title": "Validate input schemas",
                "completed": false
            }
            }
            ```
            ---

            #### **5. xpupdate_agent_plan_item** - Modify Existing Task
            **When to use**: When task details change or need clarification

            **How to use**:
            ```json
            {
            "body_params": {
                "id": "task-uuid",
                "title": "Updated description",
                "completed": true
            }
            }
            ```
            (All fields optional except `id`)

            ---

            #### **6. xpdelete_agent_plan_item** - Remove Task
            **When to use**: When a task becomes unnecessary or redundant

            **How to use**:
            ```json
            {
            "body_params": {
                "id": "task-uuid"
            }
            }
            ```
            ---

            #### **7. xpstart_execution_plan** - Start Plan Execution
            **When to use**: Immediately after creating a plan with `xpcreate_agent_plan`
            **CRITICAL**: Must be called to enable enforcement mode before executing tasks

            **How to use**:
            ```json
            {
            "body_params": {}
            }
            ```
            **No parameters needed** - just call after plan creation

            **What it does**:
            - Marks plan as "started" 
            - Enables enforcement mode if `enforce` flag is true
            - Allows plan execution to proceed

            ---

            #### **8. xpask_for_information** - Ask User a Question
            **When to use**: **MANDATORY AFTER PLAN STARTS** when you need ANY of the following:
            - Information from the user
            - Clarification on requirements
            - Approval before proceeding
            - To pause execution for user input
            
            **PREREQUISITE**: Plan must be started (running) first
            
            **CRITICAL RULE**: Once the plan has started, if you need user input or want to pause, you MUST use this tool.
            DO NOT just respond with questions in your regular output after plan starts - that breaks execution flow!
            
            **NOTE**: BEFORE starting the plan (before xpstart_execution_plan), you CAN ask questions directly if needed.

            **How to use**:
            ```json
            {
            "body_params": {
                "question": "What is the customer email address?"
            }
            }
            ```

            **What it does**:
            - Properly pauses plan enforcement and sets `question_raised` flag
            - Delivers question to the user through the correct channel
            - Manages execution state for proper continuation
            - Allows resuming execution after user responds
            
            **Why this matters**: Using this tool ensures execution can be properly continued with full context.
            Just responding with a question will NOT pause execution correctly!

            ---

            ### **Best Practices**

            ✅ **DO:**
            - Create comprehensive plans with ALL necessary steps
            - **START** the plan with `xpstart_execution_plan` after creating it
            - Use descriptive, actionable task titles
            - Check plan before each action to stay oriented
            - **Always use FULL UUID strings when marking tasks complete** (e.g., '35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92')
            - **Get the exact UUID from xpget_agent_plan** - copy the full 'id' field value
            - **Mark tasks complete THE INSTANT you finish them - NO DELAYS, NO EXCEPTIONS**
            - **Can mark multiple tasks at once if finished together** (e.g., related tasks done simultaneously)
            - **ALWAYS use `xpask_for_information` when you need user input or want to pause**
            - Call plan tools **sequentially** (one at a time, never in parallel)
            - Follow the pattern: DO WORK → GET UUID → MARK COMPLETE WITH FULL UUID → NEXT TASK

            ❌ **DON'T - THESE ARE FORBIDDEN:**
            - Mark tasks complete before they're actually done
            - **Use shortened, partial, or abbreviated task IDs** - MUST use complete UUID strings!
            - **Use made-up or guessed UUIDs** - MUST get exact UUID from xpget_agent_plan!
            - **Be lazy and wait to mark tasks complete later** (FORBIDDEN!)
            - **Postpone marking completion to batch at the end** (WRONG! Mark immediately when done!)
            - **AFTER plan starts: NEVER write questions in your response text** ("Before I proceed...", "I need clarification...", etc.)
            - **AFTER plan starts: NEVER respond with questions - ONLY use xpask_for_information tool** (ABSOLUTE RULE!)
            - Pass plain string arrays - must be objects with `title` field
            - Call plan tools in parallel with each other
            - Skip checking the plan between major steps
            - Postpone marking completion "until later" - there is no later, only NOW
            
            **REMEMBER**: Once execution started, any text like "I need to know", "Before I proceed", "I need clarification" means you MUST call xpask_for_information instead!
            **EXCEPTION**: Before starting the plan, you CAN ask questions directly if needed for planning.

            ---

            ### **Example Complete Workflow**

            ```
            1. User: "Build a REST API for user management"

            2. Call: xpcreate_agent_plan
            tasks: [
                {"title": "Design user schema"},
                {"title": "Create database migration"},
                {"title": "Implement CRUD endpoints"},
                {"title": "Add authentication"},
                {"title": "Write integration tests"}
            ]

            3. Call: xpstart_execution_plan
            → Plan now started, enforcement enabled (if enforce=true)

            4. Call: xpget_agent_plan
            → See: Task 1 (ID: 35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92) - Design user schema - Not complete

            5. [Realize need user input] Call: xpask_for_information
            question: "Which database should we use - PostgreSQL or MySQL?"
            → question_raised=true, waiting for response

            6. [After user responds, DO THE WORK: Design schema]

            7. ⚠️ IMMEDIATELY Call: xpcomplete_agent_plan_items
            ids: ["35f56b8e-1427-4a5e-a1c0-57a4f7ec8e92"]
            → MARKED COMPLETE RIGHT AFTER FINISHING - NOT DELAYED! Used FULL UUID from plan!

            8. Call: xpget_agent_plan
            → See: Task 1 ✓ complete, Task 2 (ID: 8a3c4f12-9b7e-4d2a-b5c8-1f6e9a0d3b4c) - Create database migration - Not complete

            9. [DO THE WORK: Create migration file]

            10. ⚠️ IMMEDIATELY Call: xpcomplete_agent_plan_items
            ids: ["8a3c4f12-9b7e-4d2a-b5c8-1f6e9a0d3b4c"]
            → MARKED COMPLETE RIGHT AWAY! Used FULL UUID from plan!
            
            // Alternative: If tasks 3 and 4 are done together, can batch complete:
            11a. [DO THE WORK: Implement endpoints AND add auth together]
            11b. ⚠️ IMMEDIATELY Call: xpcomplete_agent_plan_items
            ids: ["f2b9d1c7-3e8a-4b6f-9d2c-5a7e1f4b8c3d", "a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d"]
            → Both marked complete at once! Used FULL UUIDs from plan!

            12. [Continue this pattern: GET PLAN → DO WORK → MARK COMPLETE IMMEDIATELY → REPEAT]
            ```
            
            ### **WRONG WAY - ANTI-PATTERN (DO NOT DO THIS)**
            
            ```
            ❌ WRONG:
            1. Call: xpcreate_agent_plan
            2. Call: xpstart_execution_plan  ← PLAN IS NOW STARTED!
            3. Respond: "Before I proceed, I need clarification on..."  ← WRONG! FORBIDDEN!
            
            ✅ CORRECT:
            1. Call: xpcreate_agent_plan
            2. Call: xpstart_execution_plan  ← PLAN IS NOW STARTED!
            3. Call: xpask_for_information with question  ← CORRECT! Use the tool!
            ```
            
            **KEY POINT**: Once you call `xpstart_execution_plan`, the execution mode changes.
            You CANNOT write questions in your response anymore. You MUST use the tool.
            
            **Golden Rule**: FINISH TASK → MARK COMPLETE INSTANTLY → MOVE TO NEXT TASK. No delays, no batching, no "I'll do it later"!
            </important_planning_instructions>
        """

        # add the expected output guidance
        if not "expected_output" in args:
            args["expected_output"] = ""
        args["expected_output"] += "\nAll planned tasks completed and marked as done."

        # add the plan to additional_context
        if not "additional_context" in args:
            args["additional_context"] = ""

        plan_str = (
            task.deep_planning.model_dump_json()
            if task.deep_planning
            and task.deep_planning.enabled
            and len(task.deep_planning.tasks) != 0
            else "No execution plan, please generate"
        )
        args["additional_context"] += f" \n Current execution plan: {plan_str}"


def _load_llm_model(
    agent: Agent, override: Optional[Dict[str, Any]] = {}, task: Optional[Task] = None
) -> Any:
    """
    Load and configure the appropriate LLM model based on the agent's provider configuration.

    This function supports multiple LLM providers including OpenAI, NVIDIA NIM, and Anthropic.
    It handles API key resolution with proper precedence based on the deployment environment
    (xpander.ai Cloud vs local deployment).

    Args:
        agent (Agent): The agent instance containing model configuration.
        override (Optional[Dict[str, Any]]): Optional override parameters that can
            include a pre-configured "model" to bypass the loading logic.

    Returns:
        Any: A configured LLM model instance (OpenAIChat, Nvidia, or Claude).

    Raises:
        NotImplementedError: If the specified provider is not supported.

    Supported Providers:
        - "openai": Uses OpenAIChat with fallback API key resolution
        - "nim": Uses NVIDIA NIM models via Nvidia class
        - "anthropic": Uses Claude models via Anthropic integration

    API Key Resolution Logic:
        - xpander.ai Cloud: Custom credentials take precedence, fallback to environment
        - Local deployment: Environment variables take precedence, fallback to custom
    """
    if override and "model" in override:
        return override["model"]

    llm_usage_identifier = json.dumps(
        {
            "organization_id": agent.organization_id,
            "agent_id": agent.id,
            "user_id": (
                task.input.user.id
                if task and task.input and task.input.user and task.input.user.id
                else None
            ),
        }
    )

    provider = agent.model_provider.lower()
    if agent.llm_credentials and isinstance(agent.llm_credentials, dict):
        agent.llm_credentials = LLMCredentials(**agent.llm_credentials)

    is_xpander_cloud = getenv("IS_XPANDER_CLOUD", "false") == "true"
    has_custom_llm_key = (
        True if agent.llm_credentials and agent.llm_credentials.value else False
    )

    oidc_llm_token = None

    # OIDC pre-auth token claim by audience
    if (
        agent
        and agent.pre_auth_audiences
        and agent.use_oidc_pre_auth_token_for_llm
        and agent.oidc_pre_auth_token_llm_audience
        and task
        and task.user_tokens
        and isinstance(task.user_tokens, dict)
        and "oidc_tokens" in task.user_tokens
        and isinstance(task.user_tokens["oidc_tokens"], dict)
    ):
        oidc_llm_token = task.user_tokens["oidc_tokens"].get(
            agent.oidc_pre_auth_token_llm_audience, None
        )

    def get_llm_key(env_var_name: str) -> Optional[str]:
        """
        Resolve API key based on deployment environment and availability.

        Args:
            env_var_name (str): Name of the environment variable containing the API key.

        Returns:
            Optional[str]: The resolved API key or None if not available.
        """

        # return oidc claimed api key
        if oidc_llm_token:
            return oidc_llm_token

        env_llm_key = getenv(env_var_name)

        # If no custom key available, use environment variable
        if not has_custom_llm_key:
            return env_llm_key

        # xpander.ai Cloud: prioritize custom credentials, fallback to environment
        if is_xpander_cloud:
            return agent.llm_credentials.value or env_llm_key
        else:
            # Local deployment: prioritize environment, fallback to custom
            return env_llm_key or agent.llm_credentials.value

    llm_args = {}

    llm_extra_headers = {}

    if oidc_llm_token:
        llm_extra_headers["x-oidc-token"] = oidc_llm_token

    # Get organization default LLM extra headers
    api_client = APIClient(configuration=agent.configuration)
    org_default_llm_headers = run_sync(
        api_client.make_request(
            path=APIRoute.GetOrgDefaultLLMExtraHeaders,
        )
    )

    # set default headers
    if org_default_llm_headers:
        llm_extra_headers = {**llm_extra_headers, **org_default_llm_headers}

    # set override by agnet
    if agent.llm_extra_headers and isinstance(agent.llm_extra_headers, dict):
        llm_extra_headers = {**llm_extra_headers, **agent.llm_extra_headers}

    llm_args["extra_headers"] = llm_extra_headers

    if (
        agent.llm_reasoning_effort
        and agent.llm_reasoning_effort != LLMReasoningEffort.Medium
        and agent.model_name
        and "gpt-5" in agent.model_name.lower()
    ):
        llm_args = {"reasoning_effort": agent.llm_reasoning_effort.value}

    if agent.llm_api_base and len(agent.llm_api_base) != 0:
        llm_args["base_url"] = agent.llm_api_base

    # OpenAI Provider - supports GPT models with dual API key fallback
    if provider == "openai":
        from agno.models.openai import OpenAIChat

        return OpenAIChat(
            id=agent.model_name,
            # Try xpander.ai-specific key first, fallback to standard OpenAI key
            api_key=get_llm_key("AGENTS_OPENAI_API_KEY")
            or get_llm_key("OPENAI_API_KEY"),
            temperature=0.0,
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # ByteDance
    elif provider == "bytedance":
        from agno.models.openai.like import OpenAILike

        return OpenAILike(
            id=agent.model_name,
            # Try xpander.ai-specific key first
            api_key=get_llm_key("BYTEDANCE_API_KEY"),
            base_url="https://ark.ap-southeast.bytepluses.com/api/v3",
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # Tzafon LightCone
    elif provider == "tzafon_lightcone":
        from agno.models.openai.like import OpenAILike

        return OpenAILike(
            id=agent.model_name,
            # Try xpander.ai-specific key first
            api_key=get_llm_key("TZAFON_LIGHTCONE_API_KEY"),
            base_url="https://api.tzafon.ai/v1",
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # Helicone
    elif provider == "helicone":
        from agno.models.openai.like import OpenAILike

        return OpenAILike(
            id=agent.model_name,
            # Try xpander.ai-specific key first, fallback to standard OpenAI key
            api_key=get_llm_key("HELICONE_API_KEY"),
            base_url="https://ai-gateway.helicone.ai/v1",
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # Nebius
    elif provider == "nebius":
        from agno.models.nebius import Nebius

        return Nebius(
            id=agent.model_name,
            # Try xpander.ai-specific key first, fallback to standard OpenAI key
            api_key=get_llm_key("NEBIUS_API_KEY"),
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # OpenRouter
    elif provider == "open_router":
        from agno.models.openrouter import OpenRouter

        return OpenRouter(
            id=agent.model_name,
            # Try xpander.ai-specific key first, fallback to standard OpenAI key
            api_key=get_llm_key("OPENROUTER_API_KEY"),
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # Google AI Studio - supports gemini models
    elif provider == "google_ai_studio":
        from agno.models.google import Gemini

        del llm_args["extra_headers"]
        return Gemini(
            id=agent.model_name,
            # Try xpander.ai-specific key first, fallback to standard OpenAI key
            api_key=get_llm_key("GOOGLE_API_KEY"),
            retries=3,
            exponential_backoff=True,
            **llm_args,
        )
    # Fireworks AI Provider
    elif provider == "fireworks":
        from agno.models.fireworks import Fireworks

        return Fireworks(
            id=agent.model_name,
            # Try xpander.ai-specific key first, fallback to standard OpenAI key
            api_key=get_llm_key("FIREWORKS_API_KEY"),
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # NVIDIA NIM Provider - supports NVIDIA's inference microservices
    elif provider == "nim":
        from agno.models.nvidia import Nvidia

        return Nvidia(
            id=agent.model_name,
            api_key=get_llm_key("NVIDIA_API_KEY"),
            temperature=0.0,
            retries=3,
            exponential_backoff=True,
            user=llm_usage_identifier,
            **llm_args,
        )
    # Amazon Bedrock Provider
    elif provider == "amazon_bedrock":
        from agno.models.aws.bedrock import AwsBedrock

        environ["AWS_BEARER_TOKEN_BEDROCK"] = get_llm_key(
            "AWS_BEARER_TOKEN_BEDROCK"
        )  # set to env
        del llm_args["extra_headers"]
        return AwsBedrock(
            id=agent.model_name,
            temperature=0.0,
            retries=3,
            exponential_backoff=True,
            **llm_args,
        )

    # Anthropic Provider - supports Claude models
    elif provider == "anthropic":
        from agno.models.anthropic import Claude

        llm_args["default_headers"] = llm_args["extra_headers"]
        llm_args["default_headers"]["anthropic-beta"] = "context-1m-2025-08-07"
        llm_args["default_headers"]["User-Agent"] = llm_usage_identifier
        del llm_args["extra_headers"]
        llm = Claude(
            id=agent.model_name,
            api_key=get_llm_key("ANTHROPIC_API_KEY"),
            temperature=0.0,
            cache_system_prompt=True,
            retries=3,
            exponential_backoff=True,
            **llm_args,
        )
        llm._supports_structured_outputs = lambda: True  # override agno filter
        return llm
    # Azure AI Foundary
    elif provider == "azure_ai_foundary":
        # Azure AI Foundary
        from agno.models.azure import AzureAIFoundry

        api_key: str = (
            llm_args.get("extra_headers", {}).get("Authorization", None)
            or llm_args.get("extra_headers", {}).get("authorization", None)
            or get_llm_key("AZURE_API_KEY")
        )
        if not api_key:
            raise ValueError(
                "Azure AI Foundary requires an API Key. via headers (Authorization) or LLM Keys."
            )

        if not "base_url" in llm_args:
            raise ValueError("Azure AI Foundary requires a Base URL.")

        # remove bearer prefix
        api_key = api_key.replace("Bearer ", "").replace("bearer ", "")

        del llm_args["extra_headers"]

        llm_args["azure_endpoint"] = llm_args["base_url"]
        del llm_args["base_url"]

        return AzureAIFoundry(
            azure_endpoint=llm_args["azure_endpoint"],
            id=agent.model_name,
            api_key=api_key,
            temperature=0.0,
            retries=3,
            exponential_backoff=True,
        )
    # Cloudflare AI Gateway
    elif provider == "cloudflare_ai_gw":
        from agno.models.openai.like import OpenAILike

        return OpenAILike(
            id=agent.model_name,
            api_key=get_llm_key("CLOUDFLARE_AI_GW_API_KEY"),
            retries=3,
            exponential_backoff=True,
            **llm_args,
        )

    raise NotImplementedError(
        f"Provider '{provider}' is not supported for agno agents."
    )


def _configure_output(args: Dict[str, Any], agent: Agent, task: Optional[Task]) -> None:
    if agent.output_format == OutputFormat.Voice:
        args["use_json_mode"] = False
        args["markdown"] = False
        return
    if agent.output.use_json_mode:
        args["use_json_mode"] = True
        args["output_schema"] = agent.output.output_schema
    elif agent.output.is_markdown:
        args["markdown"] = True

    if task and task.output_format != agent.output_format:
        if task.output_format == OutputFormat.Json:
            args["use_json_mode"] = True
            args["markdown"] = False
            args["output_schema"] = build_model_from_schema(
                "StructuredOutput", task.output_schema
            )
        elif task.output_format == OutputFormat.Markdown:
            args["markdown"] = True
        else:
            args["markdown"] = False


def _configure_session_storage(
    args: Dict[str, Any], agent: Agent, task: Optional[Task]
) -> None:
    if not agent.agno_settings.session_storage:
        return

    args["add_history_to_context"] = True
    args["session_id"] = task.id if task else None
    args["user_id"] = (
        task.input.user.id if task and task.input and task.input.user else None
    )

    if agent.agno_settings.session_summaries:
        args["enable_session_summaries"] = True
    if agent.agno_settings.num_history_runs:
        args["num_history_runs"] = agent.agno_settings.num_history_runs
    if (
        agent.agno_settings.max_tool_calls_from_history
        and agent.agno_settings.max_tool_calls_from_history >= 1
    ):
        args["max_tool_calls_from_history"] = (
            agent.agno_settings.max_tool_calls_from_history
        )


def _configure_agentic_memory(
    args: Dict[str, Any], agent: Agent, task: Optional[Task]
) -> None:
    learning_enabled = True if agent.agno_settings.learning else False
    user = task.input.user if task and task.input and task.input.user else None
    user_memories_enabled = (
        True if agent.agno_settings.user_memories and user and user.id else False
    )
    agent_memories_enabled = True if agent.agno_settings.agent_memories else False

    if learning_enabled:
        args["learning"] = True

    if user_memories_enabled:
        args["enable_user_memories"] = True
        args["memory_manager"] = MemoryManager(
            delete_memories=True, clear_memories=True
        )

    if (user_memories_enabled or agent_memories_enabled) and not agent.is_a_team:
        args["enable_agentic_memory"] = True

    if agent_memories_enabled and not agent.is_a_team:
        args["add_culture_to_context"] = True

        if agent.agno_settings.agentic_culture:
            args["enable_agentic_culture"] = True
        else:
            args["update_cultural_knowledge"] = True

    if user:  # add user details to the agent
        args["additional_context"] = f"User details: {user.model_dump_json()}"


async def _attach_async_dependencies(
    args: Dict[str, Any],
    agent: Agent,
    task: Optional[Task],
    model: Any,
    is_async: Optional[bool] = True,
) -> None:
    user = task.input.user if task and task.input and task.input.user else None
    should_use_db = (
        True
        if (agent.agno_settings.user_memories and user and user.id)
        or agent.agno_settings.agent_memories
        else False
    )
    if agent.agno_settings.session_storage or should_use_db:
        args["db"] = await agent.aget_db(async_db=is_async)


def _configure_knowledge_bases(args: Dict[str, Any], agent: Agent) -> None:
    if agent.knowledge_bases:
        args["knowledge_retriever"] = agent.knowledge_bases_retriever()
        args["search_knowledge"] = True


def _configure_additional_context(
    args: Dict[str, Any], agent: Agent, task: Optional[Task]
) -> None:
    if task and task.additional_context:
        existing = args.get("additional_context", "")
        args["additional_context"] = (
            f"{existing}\n{task.additional_context}"
            if existing
            else task.additional_context
        )

    if agent.agno_settings.tool_call_limit:
        args["tool_call_limit"] = agent.agno_settings.tool_call_limit


def _configure_pre_hooks(args: Dict[str, Any], agent: Agent, model: Any) -> None:
    """
    Configure pre-hooks (guardrails) for the agent based on settings.

    Pre-hooks are executed before the agent processes input. This includes
    guardrails like PII detection, prompt injection detection, and content
    moderation that validate or transform input.

    Args:
        args (Dict[str, Any]): Agent configuration arguments to be updated.
        agent (Agent): The agent instance containing pre-hook settings.
    """
    # Add PII detection guardrail with optional masking
    if agent.agno_settings.pii_detection_enabled:
        if "pre_hooks" not in args:
            args["pre_hooks"] = []

        pii_guardrail = PIIDetectionGuardrail(
            mask_pii=agent.agno_settings.pii_detection_mask
        )
        args["pre_hooks"].append(pii_guardrail)

    # Add prompt injection detection guardrail
    if agent.agno_settings.prompt_injection_detection_enabled:
        if "pre_hooks" not in args:
            args["pre_hooks"] = []

        prompt_injection_guardrail = PromptInjectionGuardrail()
        args["pre_hooks"].append(prompt_injection_guardrail)

    # Add OpenAI moderation guardrail
    if agent.agno_settings.openai_moderation_enabled:
        if "pre_hooks" not in args:
            args["pre_hooks"] = []

        moderation_kwargs = {}
        try:
            if model and model.provider == "OpenAI":
                moderation_kwargs["api_key"] = model.api_key
        except:
            pass

        if agent.agno_settings.openai_moderation_categories:
            moderation_kwargs["raise_for_categories"] = (
                agent.agno_settings.openai_moderation_categories
            )

        openai_moderation_guardrail = OpenAIModerationGuardrail(**moderation_kwargs)
        args["pre_hooks"].append(openai_moderation_guardrail)


async def _resolve_agent_tools(
    agent: Agent,
    task: Optional[Task] = None,
    auth_events_callback: Optional[Callable] = None,
) -> List[Any]:
    mcp_servers = agent.mcp_servers

    # combine task mcps and agent mcps
    if task and task.mcp_servers:
        mcp_servers.extend(task.mcp_servers)

    if not mcp_servers:
        return agent.tools.functions

    # fix pydantic issue if needed
    mcp_servers = [
        MCPServerDetails(**mcp) if isinstance(mcp, dict) else mcp for mcp in mcp_servers
    ]

    # Import MCP only if mcp_servers is present
    from agno.tools.mcp import (
        MCPTools,
        SSEClientParams,
        StreamableHTTPClientParams,
    )
    from mcp import StdioServerParameters

    mcp_tools: List[MCPTools] = []
    is_xpander_cloud = getenv("IS_XPANDER_CLOUD", "false") == "true"

    for mcp in mcp_servers:
        transport = mcp.transport.value.lower()
        if mcp.type == MCPServerType.Local:

            # protection for serverless xpander
            is_aws_mcp = (
                True if mcp.command and "aws-api-mcp-server" in mcp.command else False
            )
            if is_aws_mcp and is_xpander_cloud:
                logger.warning(
                    f"skipping aws mcp on agent {agent.id} due to xpander serverless"
                )
                continue

            command_parts = shlex.split(mcp.command)
            mcp_tools.append(
                MCPTools(
                    transport=transport,
                    server_params=StdioServerParameters(
                        command=command_parts[0],
                        args=command_parts[1:],
                        env=mcp.env_vars,
                    ),
                    include_tools=mcp.allowed_tools or None,
                    timeout_seconds=120,
                    tool_name_prefix="mcp_tool",
                )
            )
        elif mcp.url:
            params_cls = (
                SSEClientParams
                if mcp.transport == MCPServerTransport.SSE
                else StreamableHTTPClientParams
            )

            if not mcp.headers:
                mcp.headers = {}

            oidc_mcp_token = None
            # OIDC pre-auth token claim by audience
            if (
                agent
                and agent.pre_auth_audiences
                and agent.oidc_pre_auth_token_mcp_audience
                and task
                and task.user_tokens
                and isinstance(task.user_tokens, dict)
                and "oidc_tokens" in task.user_tokens
                and isinstance(task.user_tokens["oidc_tokens"], dict)
            ):
                oidc_mcp_token = task.user_tokens["oidc_tokens"].get(
                    agent.oidc_pre_auth_token_mcp_audience, None
                )
                if oidc_mcp_token and oidc_mcp_token != "__none__":
                    mcp.api_key = oidc_mcp_token

            if not oidc_mcp_token:
                # handle mcp auth
                if mcp.auth_type == MCPServerAuthType.OAuth2:
                    if not task:
                        raise ValueError(
                            "MCP server with OAuth authentication detected but task not sent"
                        )

                    # check if we have user tokens for this mcp
                    graph_item = next(
                        (
                            gi
                            for gi in agent.graph.items
                            if gi.type == AgentGraphItemType.MCP
                            and gi.settings
                            and gi.settings.mcp_settings
                            and gi.settings.mcp_settings.url
                            and gi.settings.mcp_settings.url == mcp.url
                        ),
                        None,
                    )
                    if (
                        graph_item
                        and task.user_tokens
                        and isinstance(task.user_tokens, dict)
                        and graph_item.id in task.user_tokens
                    ):
                        if isinstance(task.user_tokens[graph_item.id], dict):
                            graph_item_headers = task.user_tokens[graph_item.id]
                            mcp.headers = graph_item_headers
                            mcp.api_key = "__bypass__"
                        else:
                            mcp.api_key = task.user_tokens[graph_item.id]

                    if not mcp.api_key:
                        if not task.input.user or not task.input.user.id:
                            raise ValueError(
                                "MCP server with OAuth authentication detected but user id not set on the task (task.input.user.id)"
                            )

                        auth_result: MCPOAuthGetTokenResponse = (
                            await authenticate_mcp_server(
                                mcp_server=mcp,
                                task=task,
                                user_id=task.input.user.id,
                                auth_events_callback=auth_events_callback,
                            )
                        )
                        if (
                            auth_result
                            and auth_result.data
                            and isinstance(
                                auth_result.data, MCPOAuthGetTokenGenericResponse
                            )
                            and auth_result.data.message
                        ):
                            raise ValueError(
                                f"MCP authentication failed: {auth_result.data.message}"
                            )
                        if not auth_result:
                            raise ValueError("MCP Server authentication failed")
                        if auth_result.type != MCPOAuthResponseType.TOKEN_READY:
                            raise ValueError("MCP Server authentication timeout")
                        mcp.api_key = auth_result.data.access_token

            # check if we have user tokens for this mcp
            graph_item = next(
                (
                    gi
                    for gi in agent.graph.items
                    if gi.type == AgentGraphItemType.MCP
                    and gi.settings
                    and gi.settings.mcp_settings
                    and gi.settings.mcp_settings.url
                    and gi.settings.mcp_settings.url == mcp.url
                ),
                None,
            )
            if (
                graph_item
                and task.user_tokens
                and isinstance(task.user_tokens, dict)
                and graph_item.id in task.user_tokens
            ):
                if isinstance(task.user_tokens[graph_item.id], dict):
                    graph_item_headers = task.user_tokens[graph_item.id]
                    mcp.headers = graph_item_headers
                elif not mcp.api_key:
                    mcp.api_key = task.user_tokens[graph_item.id]

            if mcp.api_key and mcp.api_key != "__bypass__":
                mcp.headers["Authorization"] = f"Bearer {mcp.api_key}"

            mcp_tools.append(
                MCPTools(
                    transport=transport,
                    server_params=params_cls(
                        url=mcp.url,
                        headers=mcp.headers,
                        sse_read_timeout=1200,
                        timeout=1200,
                    ),
                    include_tools=mcp.allowed_tools or None,
                    timeout_seconds=120,
                    tool_name_prefix="mcp_tool",
                )
            )

    return agent.tools.functions + mcp_tools


# Model-id → context window (in tokens). Used to size the L2 trigger so it
# fires before the provider hard-limits the request. Default fallback is 200K
# (Anthropic / xAI). Match is substring + lowercase to tolerate provider/model
# prefixes (e.g. "anthropic/claude-sonnet-4-5", "openai/gpt-4o-mini").
_MODEL_CONTEXT_WINDOWS: List[tuple] = [
    # 1M context
    ("claude-sonnet-4-5-1m", 1_000_000),
    ("[1m]", 1_000_000),
    ("gpt-4.1", 1_047_576),
    # 200K
    ("claude", 200_000),
    ("grok-4", 256_000),
    # 128K
    ("gpt-4o", 128_000),
    ("gpt-4-turbo", 128_000),
    ("o1", 128_000),
    ("o3", 200_000),
    ("o4", 200_000),
    ("gpt-5", 200_000),
    ("llama-3.1", 128_000),
    ("llama-3.3", 128_000),
    # 1M
    ("gemini-2", 1_000_000),
    ("gemini-1.5", 1_000_000),
]


def _detect_context_window(model: Model) -> int:
    """Return the model's max input context in tokens. Defaults to 200K."""
    model_id = (getattr(model, "id", "") or "").lower()
    if not model_id:
        return 200_000
    for prefix, window in _MODEL_CONTEXT_WINDOWS:
        if prefix in model_id:
            return window
    return 200_000


def _configure_context_optimizer(
    args: Dict[str, Any], agent: Agent, task: Optional[Task], model: Model
) -> None:
    context_window = _detect_context_window(model)
    # Reserve more headroom for smaller windows so output isn't starved.
    reserved_for_output = min(20_000, max(4_000, int(context_window * 0.10)))
    buffer_tokens = min(13_000, max(2_000, int(context_window * 0.05)))
    logger.info(
        f"[context-optimizer] configured for model={getattr(model, 'id', '?')} "
        f"context_window={context_window:,} reserved_for_output={reserved_for_output:,} "
        f"buffer_tokens={buffer_tokens:,}"
    )
    args["compression_manager"] = XPanderContextOptimizer(
        model=model,
        agent=agent,
        task=task,
        context_window=context_window,
        reserved_for_output=reserved_for_output,
        buffer_tokens=buffer_tokens,
    )
