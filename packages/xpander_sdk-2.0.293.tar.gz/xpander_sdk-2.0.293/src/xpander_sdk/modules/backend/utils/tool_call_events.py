"""
Tool call activity reporting utility.

Shared helper used by both the agno framework hook and direct SDK tool
invocations (e.g. OpenClaw) to emit ToolCallRequest / ToolCallResult
events to the task activity queue.

All pushes are fire-and-forget: failures are logged as warnings and
never raise. There is NO skip/filter logic here — every caller decides
whether to report and this module simply does the reporting.
"""

from __future__ import annotations

import ast
import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, Optional, TYPE_CHECKING

from loguru import logger

from xpander_sdk.consts.api_routes import APIRoute
from xpander_sdk.core.xpander_api_client import APIClient
from xpander_sdk.models.events import (
    TaskUpdateEventType,
    ToolCallRequest,
    ToolCallRequestReasoning,
    ToolCallResult,
)

if TYPE_CHECKING:
    from xpander_sdk.modules.tasks.sub_modules.task import Task


# Defaults mirror Layer 1 microcompaction so the activity log view aligns
# with what the LLM actually sees for large tool outputs.
DEFAULT_MAX_CONTENT_LENGTH = 8_000
DEFAULT_PREVIEW_LENGTH = 2_000

TRUNCATION_MARKER_TEMPLATE = (
    "\n\n[TRUNCATED OUTPUT - {total:,} chars total, showing first {preview:,}]"
)

TOOL_CALL_REASONING_TITLE = "toolcallreasoningtitle"
TOOL_CALL_REASONING_DESCRIPTION = "toolcallreasoningdescription"

# Deep-planning tool ids. These manage plan lifecycle (create/get/update/
# complete/ask/start) and are considered internal orchestration — they
# should NOT produce tool-call activity entries.
PLANNING_TOOLS = frozenset(
    [
        "xpcreate_agent_plan",
        "xpget_agent_plan",
        "xpadd_new_agent_plan_item",
        "xpupdate_agent_plan_item",
        "xpdelete_agent_plan_item",
        "xpcomplete_agent_plan_items",
        "xpask_for_information",
        "xpstart_execution_plan",
    ]
)

# Agno reasoning tool names. These are handled as a separate reasoning
# activity entry (via Think / Analyze event types), NOT as regular tool
# calls. The activity consumer renders them as AgentActivityThreadReasoning.
THINK_TOOL = "think"
ANALYZE_TOOL = "analyze"
REASONING_TOOLS = frozenset([THINK_TOOL, ANALYZE_TOOL])


def should_skip_tool_report(tool_name: Optional[str]) -> bool:
    """Return True when the tool's activity should NOT be reported as a
    regular tool call.

    This covers both the deep-planning tools (fully hidden from activity)
    and the reasoning tools (reported via the separate Think / Analyze
    helper below). Callers should short-circuit tool-call emission when
    this returns True.
    """
    if not tool_name:
        return False
    return tool_name in PLANNING_TOOLS or tool_name in REASONING_TOOLS


def is_reasoning_tool(tool_name: Optional[str]) -> bool:
    """Return True when the tool is agno's think/analyze reasoning tool."""
    if not tool_name:
        return False
    return tool_name in REASONING_TOOLS


async def report_reasoning_event(
    task: "Task",
    tool_name: str,
    arguments: Optional[Dict[str, Any]],
    request_id: Optional[str] = None,
) -> None:
    """Push a Think / Analyze activity event for the given reasoning tool.

    The mono activity consumer builds an ``AgentActivityThreadReasoning``
    entry from this event by spreading ``tool_call.payload["input"]`` into
    the reasoning model (which expects ``title``, ``confidence``, and
    optionally ``thought`` / ``action`` / ``result`` / ``analysis``).
    This helper therefore wraps the caller's ``arguments`` dict in
    ``{"input": arguments}`` to match that contract.

    Fire-and-forget: failures are logged but never raised.
    """
    try:
        tool_name = (tool_name or "").lower()
        if tool_name not in REASONING_TOOLS:
            return
        event_type = (
            TaskUpdateEventType.Think
            if tool_name == THINK_TOOL
            else TaskUpdateEventType.Analyze
        )
        # Normalize the reasoning payload to the shape mono's activity
        # consumer expects: payload["input"] carries title/confidence/etc.
        input_dict: Dict[str, Any] = {}
        coerced_arguments = coerce_json_like(arguments) if arguments is not None else None
        if isinstance(coerced_arguments, dict):
            # Agno passes reasoning fields as top-level keyword arguments.
            # Tolerate both shapes: direct fields, or an already-wrapped
            # {"input": {...}} form.
            if isinstance(coerced_arguments.get("input"), dict):
                input_dict = dict(coerced_arguments["input"])
            else:
                input_dict = {k: v for k, v in coerced_arguments.items() if k != "headers"}
        data = ToolCallRequest(
            request_id=request_id or str(uuid.uuid4()),
            operation_id=tool_name,
            tool_name=tool_name,
            payload={"input": input_dict},
        )
        await _push_event(task=task, event_type=event_type, data=data)
    except Exception as exc:
        logger.warning(f"[tool-call-events] failed to build reasoning event: {exc}")


def _to_string(value: Any) -> str:
    """Best-effort conversion of an arbitrary result to a string for truncation sizing."""
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str, ensure_ascii=False)
    except Exception:
        try:
            return str(value)
        except Exception:
            return ""


def coerce_json_like(value: Any) -> Any:
    """If *value* is a string that looks like JSON or a Python literal
    describing a dict/list, parse it into the structured form so the
    activity log carries proper JSON instead of an embedded string blob.

    Recurses into dicts and lists so nested fields (e.g. ``result``,
    ``content``, ``output``) are also normalized. Non-string primitives
    are returned as-is. Parse failures fall back to the original value.
    """
    # Primitives / None pass through.
    if value is None or isinstance(value, (int, float, bool)):
        return value

    if isinstance(value, str):
        stripped = value.strip()
        # Only attempt parsing for strings that plausibly represent a
        # structured value. Skip obvious plain text to avoid false
        # positives (json.loads accepts lone numbers/booleans too).
        if stripped.startswith(("{", "[")) and stripped.endswith(("}", "]")):
            # Try JSON first (strict, fast).
            try:
                parsed = json.loads(stripped)
                if isinstance(parsed, (dict, list)):
                    return coerce_json_like(parsed)
            except Exception:
                pass
            # Fallback: Python literal (single quotes, tuples, etc.).
            try:
                parsed = ast.literal_eval(stripped)
                if isinstance(parsed, (dict, list, tuple)):
                    if isinstance(parsed, tuple):
                        parsed = list(parsed)
                    return coerce_json_like(parsed)
            except Exception:
                pass
        return value

    if isinstance(value, dict):
        return {k: coerce_json_like(v) for k, v in value.items()}

    if isinstance(value, (list, tuple)):
        return [coerce_json_like(v) for v in value]

    # Unknown types (pydantic models, custom objects, etc.) — leave
    # them alone; the downstream Pydantic model_dump_safe handles them.
    return value


def shape_result_for_activity(
    result: Any,
    max_content_length: int = DEFAULT_MAX_CONTENT_LENGTH,
    preview_length: int = DEFAULT_PREVIEW_LENGTH,
    skip_truncation: bool = False,
) -> Any:
    """Return *result* as-is unless it is too large, in which case return a
    preview + truncation marker mirroring Layer 1 microcompaction.

    When ``skip_truncation`` is True the result is returned verbatim
    regardless of size. Use this for cases where the agent explicitly
    asked for the full content (e.g. reading back an offloaded
    CONTEXT_OPTIMIZATION file from the workspace).

    Non-string results that exceed the threshold are serialized to JSON for
    the preview. Small results are returned verbatim so typed values
    (dicts/lists) continue to render correctly downstream.
    """
    if skip_truncation:
        return result
    try:
        as_str = _to_string(result)
        if len(as_str) <= max_content_length:
            return result
        preview = as_str[:preview_length]
        marker = TRUNCATION_MARKER_TEMPLATE.format(
            total=len(as_str), preview=preview_length
        )
        return preview + marker
    except Exception:
        # Never fail the caller because of shaping logic.
        return result


def extract_reasoning(
    arguments: Optional[Dict[str, Any]],
) -> Optional[ToolCallRequestReasoning]:
    """Extract reasoning metadata from a tool-call payload.

    Looks for ``toolcallreasoningtitle`` / ``toolcallreasoningdescription``
    in the common shapes:
      * ``arguments["headers"]``
      * ``arguments["payload"]["headers"]``
      * ``arguments["payload"]["body_params"]["headers"]``
      * top-level ``arguments``
    Returns ``None`` when no reasoning keys are present.
    """
    if not arguments or not isinstance(arguments, dict):
        return None

    candidates = []
    candidates.append(arguments)
    headers = arguments.get("headers")
    if isinstance(headers, dict):
        candidates.append(headers)
    payload = arguments.get("payload")
    if isinstance(payload, dict):
        candidates.append(payload)
        if isinstance(payload.get("headers"), dict):
            candidates.append(payload["headers"])
        body_params = payload.get("body_params")
        if isinstance(body_params, dict):
            candidates.append(body_params)
            if isinstance(body_params.get("headers"), dict):
                candidates.append(body_params["headers"])

    for source in candidates:
        title = source.get(TOOL_CALL_REASONING_TITLE)
        description = source.get(TOOL_CALL_REASONING_DESCRIPTION)
        if title or description:
            return ToolCallRequestReasoning(
                title=title,
                description=description,
            )

    return None


async def _push_event(task: "Task", event_type: TaskUpdateEventType, data: Any) -> None:
    """POST a task-update event to the activity queue. Fire-and-forget."""
    if not task or not getattr(task, "id", None):
        return
    try:
        from xpander_sdk.modules.tasks.sub_modules.task import TaskUpdateEvent

        evt = TaskUpdateEvent(
            task_id=task.id,
            organization_id=task.organization_id,
            time=datetime.now(timezone.utc).isoformat(),
            type=event_type,
            data=data,
        )
        client = APIClient(configuration=task.configuration)
        await client.make_request(
            path=APIRoute.PushExecutionEventToQueue.format(task_id=task.id),
            method="POST",
            payload=[evt.model_dump_safe()],
        )
    except Exception as exc:
        logger.warning(
            f"[tool-call-events] failed to push {event_type} for task "
            f"{getattr(task, 'id', '?')}: {exc}"
        )


async def report_tool_call_request(
    task: "Task",
    request_id: str,
    operation_id: str,
    tool_name: Optional[str] = None,
    payload: Any = None,
    reasoning: Optional[ToolCallRequestReasoning] = None,
    graph_node_id: Optional[str] = None,
    tool_call_id: Optional[str] = None,
) -> None:
    """Push a ``ToolCallRequest`` event for the given task. Fire-and-forget.

    String payloads that look like JSON/Python-literal dicts or lists are
    coerced into structured form so the activity log carries proper JSON
    rather than an embedded blob.
    """
    try:
        data = ToolCallRequest(
            request_id=request_id,
            operation_id=operation_id,
            tool_call_id=tool_call_id,
            graph_node_id=graph_node_id,
            tool_name=tool_name or operation_id,
            payload=coerce_json_like(payload),
            reasoning=reasoning,
        )
        await _push_event(task=task, event_type=TaskUpdateEventType.ToolCallRequest, data=data)
    except Exception as exc:
        logger.warning(f"[tool-call-events] failed to build ToolCallRequest: {exc}")


async def report_tool_call_result(
    task: "Task",
    request_id: str,
    operation_id: str,
    result: Any,
    is_error: bool = False,
    tool_name: Optional[str] = None,
    payload: Any = None,
    graph_node_id: Optional[str] = None,
    tool_call_id: Optional[str] = None,
    max_content_length: int = DEFAULT_MAX_CONTENT_LENGTH,
    preview_length: int = DEFAULT_PREVIEW_LENGTH,
    skip_truncation: bool = False,
) -> None:
    """Push a ``ToolCallResult`` event for the given task. Fire-and-forget.

    The result payload is shaped via ``shape_result_for_activity`` so
    oversized outputs render the same truncated preview the LLM sees.

    Pass ``skip_truncation=True`` when the activity log must carry the
    full content verbatim (e.g. reading back an offloaded
    CONTEXT_OPTIMIZATION file from the workspace).
    """
    try:
        # Coerce first so truncation operates on the already-structured value
        # (improves the JSON-stringified length check + preview quality).
        normalized_result = coerce_json_like(result)
        shaped = shape_result_for_activity(
            result=normalized_result,
            max_content_length=max_content_length,
            preview_length=preview_length,
            skip_truncation=skip_truncation,
        )
        data = ToolCallResult(
            request_id=request_id,
            operation_id=operation_id,
            tool_call_id=tool_call_id,
            graph_node_id=graph_node_id,
            tool_name=tool_name or operation_id,
            payload=coerce_json_like(payload),
            result=shaped,
            is_error=is_error,
        )
        await _push_event(task=task, event_type=TaskUpdateEventType.ToolCallResult, data=data)
    except Exception as exc:
        logger.warning(f"[tool-call-events] failed to build ToolCallResult: {exc}")
