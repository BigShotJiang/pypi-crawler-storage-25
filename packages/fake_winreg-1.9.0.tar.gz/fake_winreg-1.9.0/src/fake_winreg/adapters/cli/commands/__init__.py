"""CLI command implementations.

Collects all subcommand functions and re-exports them for registration
with the root CLI group.

Contents:
    * Info commands from :mod:`.info`
    * Config commands from :mod:`.config`
    * Logging commands from :mod:`.logging`
"""

from __future__ import annotations

from .config import cli_config, cli_config_deploy, cli_config_generate_examples
from .convert import cli_convert
from .demo_registries import cli_export_demo_registries
from .info import cli_info
from .logging import cli_logdemo
from .reg import cli_reg

__all__ = [
    "cli_config",
    "cli_config_deploy",
    "cli_config_generate_examples",
    "cli_convert",
    "cli_export_demo_registries",
    "cli_info",
    "cli_logdemo",
    "cli_reg",
]
