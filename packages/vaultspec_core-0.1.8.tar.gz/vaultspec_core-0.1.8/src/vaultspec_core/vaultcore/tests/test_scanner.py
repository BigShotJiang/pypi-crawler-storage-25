"""Tests for vault scanning and document type classification.

Covers :func:`~vaultspec_core.vaultcore.scanner.scan_vault` (file discovery,
``.obsidian`` exclusion) and :func:`~vaultspec_core.vaultcore.scanner.get_doc_type`
(directory-based classification) against the bundled test-project fixture.
"""

from pathlib import Path

import pytest

from ...config import reset_config
from .. import DocType, get_doc_type, scan_vault

_REPO_ROOT = Path(__file__).resolve().parents[4]
TEST_PROJECT = _REPO_ROOT / "test-project"

pytestmark = [pytest.mark.unit]


@pytest.fixture(autouse=True)
def _reset_cfg():
    reset_config()
    yield
    reset_config()


class TestScanVault:
    def test_yields_many_markdown_files(self):
        paths = list(scan_vault(TEST_PROJECT))
        assert len(paths) > 80

    def test_all_files_are_markdown(self):
        for p in scan_vault(TEST_PROJECT):
            assert p.suffix == ".md"

    def test_skips_obsidian(self):
        for p in scan_vault(TEST_PROJECT):
            assert ".obsidian" not in p.parts

    def test_includes_known_adr(self):
        names = {p.name for p in scan_vault(TEST_PROJECT)}
        assert "2026-02-05-editor-demo-architecture-adr.md" in names

    def test_includes_known_plan(self):
        names = {p.name for p in scan_vault(TEST_PROJECT)}
        assert "2026-02-05-editor-demo-phase1-plan.md" in names


class TestGetDocType:
    def test_adr_dir(self):
        path = (
            TEST_PROJECT
            / ".vault"
            / "adr"
            / "2026-02-05-editor-demo-architecture-adr.md"
        )
        assert get_doc_type(path, TEST_PROJECT) == DocType.ADR

    def test_plan_dir(self):
        path = (
            TEST_PROJECT / ".vault" / "plan" / "2026-02-05-editor-demo-phase1-plan.md"
        )
        assert get_doc_type(path, TEST_PROJECT) == DocType.PLAN

    def test_research_dir(self):
        path = (
            TEST_PROJECT / ".vault" / "research" / "2026-02-05-editor-demo-research.md"
        )
        assert get_doc_type(path, TEST_PROJECT) == DocType.RESEARCH

    def test_reference_dir(self):
        path = (
            TEST_PROJECT
            / ".vault"
            / "reference"
            / "2026-02-05-editor-demo-core-reference.md"
        )
        assert get_doc_type(path, TEST_PROJECT) == DocType.REFERENCE

    def test_audit_dir_returns_audit(self):
        # audit/ is now a valid DocType directory
        audit_files = list((TEST_PROJECT / ".vault" / "audit").glob("*.md"))
        if audit_files:
            assert get_doc_type(audit_files[0], TEST_PROJECT) == DocType.AUDIT
