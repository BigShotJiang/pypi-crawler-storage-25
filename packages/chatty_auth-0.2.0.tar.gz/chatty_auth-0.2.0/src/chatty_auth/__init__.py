"""Chatty Auth — shared authentication for the Chatty platform."""

from chatty_auth.models import AuthResult, AuthType, TokenPayload
from chatty_auth.jwt_auth import verify_jwt, generate_jwt
from chatty_auth.api_key_auth import verify_api_key_env, verify_api_key_db, hash_api_key, generate_api_key
from chatty_auth.decorators.lambda_auth import require_jwt, require_api_key, require_any_auth

__all__ = [
    "AuthResult",
    "AuthType",
    "TokenPayload",
    "verify_jwt",
    "generate_jwt",
    "verify_api_key_env",
    "verify_api_key_db",
    "hash_api_key",
    "generate_api_key",
    "require_jwt",
    "require_api_key",
    "require_any_auth",
]
