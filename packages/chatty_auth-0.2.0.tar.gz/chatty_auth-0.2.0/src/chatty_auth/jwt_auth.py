"""JWT authentication — verify and generate tokens.

Supports two modes:
1. HS256 (symmetric) — internal Chatty JWTs signed with JWT_SECRET_KEY
2. RS256 (asymmetric) — Auth0 JWTs verified via JWKS endpoint
"""
import os
import time
from typing import Optional

import jwt
from jwt.api_jwk import PyJWK

from chatty_auth.exceptions import InvalidTokenError
from chatty_auth.models import AuthResult, AuthType, TokenPayload

# Cache JWKS to avoid fetching on every request
_jwks_cache: dict[str, dict] = {}


def _get_jwks(auth0_domain: str) -> dict:
    """Fetch and cache JWKS from Auth0."""
    if auth0_domain in _jwks_cache:
        return _jwks_cache[auth0_domain]
    import requests
    url = f"https://{auth0_domain}/.well-known/jwks.json"
    response = requests.get(url, timeout=5)
    response.raise_for_status()
    jwks = response.json()
    _jwks_cache[auth0_domain] = jwks
    return jwks


def _verify_auth0_token(token: str, auth0_domain: str, audience: str | tuple[str, ...] | None = None) -> dict:
    """Verify an RS256 Auth0 token using JWKS."""
    try:
        jwks = _get_jwks(auth0_domain)
        unverified_header = jwt.get_unverified_header(token)

        public_key = None
        for key in jwks.get("keys", []):
            if key["kid"] == unverified_header.get("kid"):
                jwk_obj = PyJWK.from_dict(key)
                public_key = jwk_obj.key
                break

        if not public_key:
            raise InvalidTokenError("Unable to find matching signing key")

        decode_options = {
            "algorithms": ["RS256"],
            "issuer": f"https://{auth0_domain}/",
        }
        if audience:
            decode_options["audience"] = audience

        return jwt.decode(token, public_key, **decode_options)
    except jwt.ExpiredSignatureError:
        raise InvalidTokenError("Token expired")
    except jwt.InvalidAudienceError:
        raise InvalidTokenError("Invalid audience")
    except jwt.InvalidIssuerError:
        raise InvalidTokenError("Invalid issuer")
    except InvalidTokenError:
        raise
    except Exception as e:
        raise InvalidTokenError(f"Auth0 token validation failed: {e}")


def verify_jwt(
    token: str,
    secret: str | None = None,
    algorithms: list[str] | None = None,
) -> AuthResult:
    """Verify a JWT token and return an AuthResult.

    Automatically detects token type:
    - If AUTH0_DOMAIN is set and token header has alg=RS256 → Auth0 JWKS validation
    - Otherwise → HS256 validation with JWT_SECRET_KEY

    Args:
        token: The raw JWT string (without "Bearer " prefix).
        secret: The signing secret (for HS256). Defaults to JWT_SECRET_KEY env var.
        algorithms: Allowed algorithms. Defaults to auto-detect.

    Returns:
        AuthResult with auth_type=JWT, company_id, user_id, payload.

    Raises:
        InvalidTokenError: If the token is invalid, expired, or missing company_id.
    """
    auth0_domain = os.getenv("AUTH0_DOMAIN")
    auth0_audience = os.getenv("AUTH0_API_AUDIENCE")

    # Auto-detect: check token header for RS256
    try:
        unverified_header = jwt.get_unverified_header(token)
        token_alg = unverified_header.get("alg", "")
    except Exception:
        token_alg = ""

    if token_alg == "RS256" and auth0_domain:
        # Auth0 RS256 path
        decoded = _verify_auth0_token(token, auth0_domain, audience=auth0_audience)
    else:
        # HS256 path (internal Chatty JWT)
        secret = secret or os.getenv("JWT_SECRET_KEY")
        if not secret:
            raise InvalidTokenError("JWT_SECRET_KEY not configured", status_code=500)
        algorithms = algorithms or ["HS256"]
        try:
            decoded = jwt.decode(token, secret, algorithms=algorithms)
        except jwt.ExpiredSignatureError:
            raise InvalidTokenError("Token expired")
        except jwt.InvalidTokenError as e:
            raise InvalidTokenError(f"Invalid token: {e}")

    # Extract company_id — check both direct field and Auth0 custom claim
    company_id = (
        decoded.get("company_id")
        or decoded.get("https://letschatty.com/company_id")
    )

    # Extract user_id / email
    user_id = (
        decoded.get("user_id")
        or decoded.get("sub", "")
    )
    email = decoded.get("https://letschatty.com/email")

    if not company_id:
        # Auth0 tokens might not have company_id — that's OK for some flows
        # The frontend will need to select a company after login
        company_id = ""

    payload = TokenPayload(
        company_id=company_id,
        user_id=user_id,
        exp=decoded.get("exp"),
        is_mega_admin=decoded.get("is_mega_admin", False),
        roles=decoded.get("roles", []),
        permissions=decoded.get("permissions", []),
    )

    return AuthResult(
        auth_type=AuthType.JWT,
        company_id=company_id,
        user_id=user_id,
        payload=payload,
        raw=decoded,
    )


def generate_jwt(
    company_id: str,
    user_id: str,
    secret: str | None = None,
    expires_hours: int = 24,
    is_mega_admin: bool = False,
    roles: list[str] | None = None,
    permissions: list | None = None,
) -> str:
    """Generate an HS256 JWT token (internal Chatty token)."""
    secret = secret or os.getenv("JWT_SECRET_KEY")
    if not secret:
        raise InvalidTokenError("JWT_SECRET_KEY not configured", status_code=500)

    payload = {
        "company_id": company_id,
        "user_id": user_id,
        "exp": int(time.time() + (expires_hours * 3600)),
        "is_mega_admin": is_mega_admin,
        "roles": roles or [],
        "permissions": permissions or [],
    }
    return jwt.encode(payload, secret, algorithm="HS256")
