"""Auth data models — framework-agnostic."""
from enum import StrEnum
from typing import Optional

from pydantic import BaseModel, Field


class AuthType(StrEnum):
    JWT = "jwt"
    API_KEY = "api_key"


class TokenPayload(BaseModel):
    """JWT token payload. Compatible with the existing Chatty TokenPayload."""

    company_id: str
    user_id: str
    exp: Optional[int] = None
    is_mega_admin: bool = False
    roles: list[str] = Field(default_factory=list)
    permissions: list = Field(default_factory=list)


class AuthResult(BaseModel):
    """Result of authentication — returned by all verify functions."""

    auth_type: AuthType
    company_id: str
    user_id: Optional[str] = None
    payload: Optional[TokenPayload] = None  # populated for JWT, None for env-var API key
    raw: Optional[dict] = None  # full decoded JWT or user dict from DB lookup
