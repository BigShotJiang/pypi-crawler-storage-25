"""Request extraction helpers — framework-agnostic."""
import json


def extract_bearer_token(headers: dict) -> str | None:
    """Extract Bearer token from Authorization header (case-insensitive)."""
    auth = headers.get("Authorization") or headers.get("authorization")
    if auth and auth.startswith("Bearer "):
        return auth[7:].strip()
    return None


def extract_api_key(headers: dict) -> str | None:
    """Extract API key from X-Api-Key header (case-insensitive)."""
    return headers.get("X-Api-Key") or headers.get("x-api-key")


def extract_company_id_from_request(event: dict) -> str | None:
    """Extract company_id from Lambda event query params or body."""
    params = event.get("queryStringParameters") or {}
    if params.get("company_id"):
        return params["company_id"]
    try:
        body = json.loads(event.get("body") or "{}")
        return body.get("company_id")
    except (json.JSONDecodeError, AttributeError):
        return None
