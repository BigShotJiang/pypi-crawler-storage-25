"""API key authentication — env-var mode and DB-backed mode."""
import hashlib
import os
import secrets
from typing import Callable, Optional

from chatty_auth.exceptions import InvalidApiKeyError
from chatty_auth.models import AuthResult, AuthType


def hash_api_key(api_key: str) -> str:
    """Hash an API key with SHA256. Same algorithm as api-chatty."""
    return hashlib.sha256(api_key.encode()).hexdigest()


def generate_api_key(user_id: str) -> str:
    """Generate an API key in format {user_id}.{random_hex}. Same format as api-chatty."""
    random_part = secrets.token_hex(32)
    return f"{user_id}.{random_part}"


def verify_api_key_env(
    api_key: str,
    env_var: str = "API_KEY",
    company_id: str | None = None,
) -> AuthResult:
    """Verify an API key against an environment variable (simple mode).

    Used for service-to-service auth where keys are static env vars.

    Args:
        api_key: The key from the request header.
        env_var: Name of the env var holding the expected key.
        company_id: The company_id from the request (query param or body).

    Returns:
        AuthResult with auth_type=API_KEY.

    Raises:
        InvalidApiKeyError: If the key doesn't match or env var is missing.
    """
    expected = os.getenv(env_var)
    if not expected:
        raise InvalidApiKeyError(f"{env_var} not configured", status_code=500)

    if api_key != expected:
        raise InvalidApiKeyError("Invalid API key")

    return AuthResult(
        auth_type=AuthType.API_KEY,
        company_id=company_id or "",
        user_id=None,
        payload=None,
    )


def verify_api_key_db(
    api_key: str,
    user_lookup: Callable[[str], Optional[dict]],
) -> AuthResult:
    """Verify an API key against the database (Chatty user keys).

    Keys are in format {user_id}.{random_hex}. The user's api_key_hash
    (SHA256) is checked in the database.

    Args:
        api_key: The key from the request header (format: {user_id}.{random}).
        user_lookup: Function that takes a user_id and returns a user dict
                     with at least {api_key_hash, company_id, id} or None.

    Returns:
        AuthResult with auth_type=API_KEY, company_id and user_id from the user.

    Raises:
        InvalidApiKeyError: If format is wrong, user not found, or hash mismatch.
    """
    try:
        user_id, _ = api_key.split(".", 1)
    except ValueError:
        raise InvalidApiKeyError("Invalid API key format")

    user = user_lookup(user_id)
    if not user:
        raise InvalidApiKeyError("User not found")

    expected_hash = user.get("api_key_hash")
    if not expected_hash or expected_hash != hash_api_key(api_key):
        raise InvalidApiKeyError("Invalid API key")

    # Check expiration if present
    api_key_expires_at = user.get("api_key_expires_at")
    if api_key_expires_at:
        from datetime import datetime, timezone

        if isinstance(api_key_expires_at, datetime):
            if api_key_expires_at < datetime.now(timezone.utc):
                raise InvalidApiKeyError("API key expired")

    return AuthResult(
        auth_type=AuthType.API_KEY,
        company_id=user.get("company_id", ""),
        user_id=user.get("id") or user.get("_id") or user_id,
        raw=user,
    )
