"""Auth decorator for Flask-RESTx endpoints.

Usage:
    from chatty_auth.decorators.flask_auth import flask_auth_required

    @auth_required
    def post(self, company_id):
        # Access via flask.g.auth_result (AuthResult)
        ...

To use DB-backed API keys, set CHATTY_AUTH_USER_LOOKUP before importing:
    from chatty_auth.decorators import flask_auth
    flask_auth.user_lookup_fn = lambda user_id: Assets().users.get_by_id_as_dict(user_id)
"""
from functools import wraps
from typing import Any, Callable, Optional

from chatty_auth.exceptions import AuthError, MissingAuthError
from chatty_auth.helpers import extract_api_key, extract_bearer_token
from chatty_auth.jwt_auth import verify_jwt
from chatty_auth.api_key_auth import verify_api_key_db, verify_api_key_env
from chatty_auth.models import AuthResult, TokenPayload

# Set this to a callable(user_id) -> dict to enable DB-backed API key auth.
# If None, falls back to env-var based API key auth.
user_lookup_fn: Optional[Callable[[str], Optional[dict]]] = None


def flask_auth_required(func: Callable) -> Callable:
    """Flask-RESTx auth decorator. Stores AuthResult in flask.g.auth_result.

    Also sets g.token_payload for backwards compat with existing api-chatty code.
    """

    @wraps(func)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        from flask import request, g

        headers = dict(request.headers)
        token = extract_bearer_token(headers)
        key = extract_api_key(headers)

        request_company_id = kwargs.get("company_id")

        if token:
            try:
                result = verify_jwt(token)
            except AuthError as e:
                return {"message": e.message}, e.status_code

            # Mega admin can access any company
            if result.payload and result.payload.is_mega_admin and request_company_id:
                result.company_id = request_company_id
            elif request_company_id and result.company_id != request_company_id:
                return {"message": "Company ID mismatch"}, 403

            g.auth_result = result
            g.auth_type = "jwt"
            g.token_payload = result.payload
            return func(self, *args, **kwargs)

        if key:
            try:
                if user_lookup_fn:
                    result = verify_api_key_db(key, user_lookup_fn)
                else:
                    company_id = request_company_id or ""
                    result = verify_api_key_env(key, company_id=company_id)
            except AuthError as e:
                return {"message": e.message}, e.status_code

            # If DB-backed, check copilot/mega_admin overrides
            if result.raw:
                user = result.raw
                if user.get("is_copilot") or user.get("is_mega_admin"):
                    result.company_id = request_company_id or result.company_id

            g.auth_result = result
            g.auth_type = "api_key"
            g.token_payload = TokenPayload(
                company_id=result.company_id,
                user_id=result.user_id or "",
                is_mega_admin=bool(result.raw and result.raw.get("is_mega_admin")),
            )
            return func(self, *args, **kwargs)

        return {"message": "No authentication credentials provided"}, 401

    return wrapper
