"""Auth decorators for different frameworks."""
