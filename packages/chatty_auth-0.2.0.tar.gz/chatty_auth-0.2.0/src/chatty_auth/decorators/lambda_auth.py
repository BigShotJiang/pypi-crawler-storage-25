"""Auth decorators for AWS Lambda handlers.

Usage:
    from chatty_auth import require_jwt, require_api_key, require_any_auth

    @require_jwt
    def handle_cobros(event, company_id, jwt_payload):
        ...

    @require_api_key("PAYMENTS_API_KEY")
    def handle_internal(event):
        ...

    @require_any_auth("PAYMENTS_API_KEY")
    def handle_both(event, company_id, jwt_payload):
        # jwt_payload is None when authenticated via API key
        ...
"""
import json
from functools import wraps
from typing import Any, Callable, Dict

from chatty_auth.exceptions import AuthError, MissingAuthError, MissingCompanyIdError
from chatty_auth.helpers import extract_api_key, extract_bearer_token, extract_company_id_from_request
from chatty_auth.jwt_auth import verify_jwt
from chatty_auth.api_key_auth import verify_api_key_env


def _error_response(status_code: int, message: str) -> dict:
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps({"error": message}),
    }


def require_jwt(handler: Callable) -> Callable:
    """Decorator: requires JWT Bearer token. Injects company_id and jwt_payload.

    Handler signature: def handler(event, company_id: str, jwt_payload: dict)
    """

    @wraps(handler)
    def wrapper(event: Dict[str, Any]) -> Dict[str, Any]:
        headers = event.get("headers", {}) or {}
        token = extract_bearer_token(headers)
        if not token:
            return _error_response(401, "Missing Authorization header")
        try:
            result = verify_jwt(token)
        except AuthError as e:
            return _error_response(e.status_code, e.message)
        company_id = result.company_id or extract_company_id_from_request(event)
        if not company_id:
            return _error_response(400, "Missing company_id — provide in token, query params, or request body")
        return handler(event, company_id=company_id, jwt_payload=result.raw)

    return wrapper


def require_api_key(env_var: str = "API_KEY"):
    """Decorator factory: requires X-Api-Key header matching an env var.

    Handler signature: def handler(event)
    """

    def decorator(handler: Callable) -> Callable:
        @wraps(handler)
        def wrapper(event: Dict[str, Any]) -> Dict[str, Any]:
            headers = event.get("headers", {}) or {}
            key = extract_api_key(headers)
            if not key:
                return _error_response(401, "Missing X-Api-Key header")
            try:
                verify_api_key_env(key, env_var=env_var)
            except AuthError as e:
                return _error_response(e.status_code, e.message)
            return handler(event)

        return wrapper

    return decorator


def require_any_auth(api_key_env_var: str = "API_KEY"):
    """Decorator factory: accepts JWT Bearer token OR X-Api-Key.

    JWT: company_id from token, jwt_payload populated.
    API Key: company_id from query/body, jwt_payload is None.

    Handler signature: def handler(event, company_id: str, jwt_payload: dict | None)
    """

    def decorator(handler: Callable) -> Callable:
        @wraps(handler)
        def wrapper(event: Dict[str, Any]) -> Dict[str, Any]:
            headers = event.get("headers", {}) or {}
            token = extract_bearer_token(headers)
            key = extract_api_key(headers)

            # Try JWT first
            if token:
                try:
                    result = verify_jwt(token)
                except AuthError as e:
                    return _error_response(e.status_code, e.message)
                # Auth0 tokens may not have company_id — fall back to query/body
                company_id = result.company_id or extract_company_id_from_request(event)
                if not company_id:
                    return _error_response(400, "Missing company_id — provide in token, query params, or request body")
                return handler(event, company_id=company_id, jwt_payload=result.raw)

            # Try API key
            if key:
                try:
                    verify_api_key_env(key, env_var=api_key_env_var)
                except AuthError as e:
                    return _error_response(e.status_code, e.message)
                company_id = extract_company_id_from_request(event)
                if not company_id:
                    return _error_response(400, "Missing company_id (required with API key auth)")
                return handler(event, company_id=company_id, jwt_payload=None)

            return _error_response(401, "Missing authentication — provide Authorization Bearer token or X-Api-Key header")

        return wrapper

    return decorator
