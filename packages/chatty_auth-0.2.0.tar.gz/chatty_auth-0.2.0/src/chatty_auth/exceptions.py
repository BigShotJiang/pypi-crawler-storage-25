"""Auth exceptions."""


class AuthError(Exception):
    """Base auth error."""

    def __init__(self, message: str, status_code: int = 401):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class InvalidTokenError(AuthError):
    """JWT token is invalid or expired."""
    pass


class InvalidApiKeyError(AuthError):
    """API key is invalid, expired, or not found."""
    pass


class MissingAuthError(AuthError):
    """No authentication credentials provided."""

    def __init__(self, message: str = "No authentication credentials provided"):
        super().__init__(message, 401)


class MissingCompanyIdError(AuthError):
    """company_id required but not found in token or request."""

    def __init__(self):
        super().__init__("Missing company_id", 400)
