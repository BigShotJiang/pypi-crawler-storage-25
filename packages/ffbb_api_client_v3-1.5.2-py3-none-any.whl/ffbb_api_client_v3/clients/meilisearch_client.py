from __future__ import annotations

from collections.abc import Sequence

from httpx import Client

from ..config import (
    DEFAULT_USER_AGENT,
    MEILISEARCH_BASE_URL,
    MEILISEARCH_ENDPOINT_MULTI_SEARCH,
)
from ..helpers.http_requests_helper import catch_result
from ..helpers.http_requests_utils import (
    http_post_json,
    http_post_json_async,
)
from ..models.multi_search_query import MultiSearchQuery
from ..models.multi_search_results_class import MultiSearchResults
from ..utils.cache_manager import CacheManager
from ..utils.retry_utils import (
    RetryConfig,
    TimeoutConfig,
    get_default_retry_config,
    get_default_timeout_config,
)
from ..utils.secure_logging import get_secure_logger, mask_token

logger = get_secure_logger(__name__)


class MeilisearchClient:
    bearer_token: str = ""
    url: str = ""
    debug: bool = False
    cached_session: Client | None = None
    async_cached_session: httpx.AsyncClient | None = None
    retry_config: RetryConfig | None = None
    timeout_config: TimeoutConfig | None = None

    def __init__(
        self,
        bearer_token: str,
        url: str = MEILISEARCH_BASE_URL,
        debug: bool = False,
        cached_session: Client | None = None,
        *,
        async_cached_session: httpx.AsyncClient | None = None,
        retry_config: RetryConfig | None = None,
        timeout_config: TimeoutConfig | None = None,
    ):
        """
        Initializes an instance of the MeilisearchClient class.

        Args:
            bearer_token (str): The bearer token used for authentication.
            url (str, optional): The base URL.
                Defaults to "https://meilisearch-prod.ffbb.app/".
            debug (bool, optional): Whether to enable debug mode. Defaults to False.
            cached_session (Client, optional): The cached session to use.
            retry_config (RetryConfig, optional): Retry configuration. Defaults to None.
            timeout_config (TimeoutConfig, optional): Timeout configuration.
                Defaults to None.
        """
        if not bearer_token or not bearer_token.strip():
            raise ValueError("bearer_token cannot be None, empty, or whitespace-only")

        # Store token securely (private attribute)
        self._bearer_token = bearer_token
        self.url = url
        self.debug = debug
        self.cached_session = (
            cached_session if cached_session else CacheManager().session
        )
        self.async_cached_session = (
            async_cached_session if async_cached_session else CacheManager().async_session
        )
        self.headers = {
            "Authorization": f"Bearer {self._bearer_token}",
            "Content-Type": "application/json",
            "user-agent": DEFAULT_USER_AGENT,
        }

        # Configure retry and timeout settings
        self.retry_config = retry_config or get_default_retry_config()
        self.timeout_config = timeout_config or get_default_timeout_config()

        # Initialize secure logger
        self.logger = get_secure_logger(f"{self.__class__.__name__}")

        # Log initialization with masked token
        masked_token = mask_token(self._bearer_token)
        if self.debug:
            self.logger.info(
                f"MeilisearchClient initialized with token: {masked_token}"
            )
            self.logger.info(
                f"Retry config: {self.retry_config.max_attempts} attempts, "
                f"timeout: {self.timeout_config.total_timeout}s"
            )
        else:
            self.logger.info("MeilisearchClient initialized successfully")

    @property
    def bearer_token(self) -> str:
        """Get the bearer token."""
        return self._bearer_token

    def multi_search(
        self,
        queries: Sequence[MultiSearchQuery] | None = None,
        cached_session: Client | None = None,
    ) -> MultiSearchResults | None:
        url = f"{self.url}{MEILISEARCH_ENDPOINT_MULTI_SEARCH}"
        params = {"queries": [query.to_dict() for query in queries] if queries else []}
        raw_data = catch_result(
            lambda: http_post_json(
                url,
                self.headers,
                params,
                debug=self.debug,
                cached_session=cached_session or self.cached_session,
                retry_config=self.retry_config,
                timeout_config=self.timeout_config,
            )
        )
        if raw_data:
            return MultiSearchResults.from_dict(raw_data)
        return None

    async def multi_search_async(
        self,
        queries: Sequence[MultiSearchQuery] | None = None,
        cached_session: httpx.AsyncClient | None = None,
    ) -> MultiSearchResults | None:
        url = f"{self.url}{MEILISEARCH_ENDPOINT_MULTI_SEARCH}"
        params = {"queries": [query.to_dict() for query in queries] if queries else []}
        try:
            raw_data = await http_post_json_async(
                url,
                self.headers,
                params,
                debug=self.debug,
                cached_session=cached_session or self.async_cached_session,
                retry_config=self.retry_config,
                timeout_config=self.timeout_config,
            )
            if raw_data:
                return MultiSearchResults.from_dict(raw_data)
        except Exception:
            pass
        return None
