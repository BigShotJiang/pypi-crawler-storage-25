from malt_mcp_server.cli import main

if __name__ == "__main__":
    main()
