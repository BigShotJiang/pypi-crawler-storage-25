# SOVEREIGN EDGE

**Governed autonomous swarm C2 with TAK integration and pseudospectral certification.**

Blackridge Autonomy LLC

---

## What It Does

SOVEREIGN EDGE is a swarm governance platform that enables autonomous UAS formations to execute missions when communications are denied, GNSS is spoofed, and the electromagnetic spectrum is contested.

It provides **mathematically proven** governance resilience — including the only known formal demonstration that standard health-monitoring architectures contain a fundamental blind spot that adversaries can exploit.

## Install

```bash
pip install sovereign-edge          # base (CoT adapter + gateway)
pip install sovereign-edge[psc]     # + pseudospectral certification
pip install sovereign-edge[all]     # everything
```

## CLI

```bash
sovereign-edge version              # system info
sovereign-edge demo --scenario doomsday   # run doomsday scenario
sovereign-edge gateway --web        # governance engine + live dashboard
sovereign-edge certify              # PSC pseudospectral certification
sovereign-edge test                 # run test suite
```

## What's Inside

| Component | Description |
|---|---|
| **CoT Adapter** | Converts WHACO governance state to MIL-STD-2525C Cursor-on-Target XML |
| **Gateway** | Real governance engine (SwarmGovernor + ResilienceController + NodeSwitchController + PredictiveEstimator) with CoT output |
| **PSC Integration** | Pseudospectral certification — certify governance operators, monitor drift in real-time |
| **ATAK Plugin** | Android plugin scaffold for TAK ecosystem integration |
| **Web Dashboard** | Real-time swarm visualization with Leaflet.js |

## Architecture

```
sovereign-edge gateway
├── WHACO Governance Loop (50 Hz)
│   ├── PredictiveEstimator (wind KF, fuel forecast, threat prediction)
│   ├── SwarmGovernor (Byzantine-tolerant consensus, posture quorum)
│   ├── NodeSwitchController (heartbeat monitor, 5-phase handoff)
│   └── ResilienceController (ASDP survival protocol, SCORCH denial)
├── PSC Certification (certify on startup, drift check every 50 ticks)
├── CoT Adapter (WHACO state → MIL-STD-2525C XML)
└── Transport (UDP multicast / TCP TAK Server / file)
```

## Key Results

| Metric | Value |
|---|---|
| Contested survival | 82.5% under compound faults |
| Mission success improvement | +9.8 pp (Cohen's d=1.30) |
| Packet loss tolerance | 60% before mission impact |
| Per-agent latency | 6.2 μs |
| Runtime invariants | 67 (machine-verified) |
| Byzantine classes defeated | 5 of 5 |
| Governance operators with fragility >2× | 62% (PSC empirical study) |

## Links

- **Live Dashboard**: [blackridgeautonomy.com/sovereign-edge](https://blackridgeautonomy.com/sovereign-edge/)
- **Product Page**: [blackridgeautonomy.com/sovereign-edge.html](https://blackridgeautonomy.com/sovereign-edge.html)
- **Public SDK**: [pypi.org/project/blackridge-whaco](https://pypi.org/project/blackridge-whaco/)
- **Company**: [blackridgeautonomy.com](https://blackridgeautonomy.com)

## License

Proprietary — Blackridge Autonomy LLC. All rights reserved.
