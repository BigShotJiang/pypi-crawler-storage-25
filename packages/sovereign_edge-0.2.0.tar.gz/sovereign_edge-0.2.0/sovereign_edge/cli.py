"""
sovereign-edge CLI — unified entry point for SOVEREIGN EDGE platform.

Commands:
    sovereign-edge gateway     Run governance engine + CoT adapter + web dashboard
    sovereign-edge certify     PSC pseudospectral certification of a governance operator
    sovereign-edge demo        Quick demo (golden scenario with CoT output)
    sovereign-edge version     Print version and system info
    sovereign-edge test        Run the test suite

The gateway command is the primary service — it runs the WHACO governance
loop, generates CoT events, and optionally serves the web dashboard,
all in a single process.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path


def cmd_gateway(args: argparse.Namespace) -> int:
    """Run the SOVEREIGN EDGE gateway service."""
    from sovereign_edge.gateway import run_demo
    from sovereign_edge.cot_adapter.config import SovereignEdgeConfig
    from sovereign_edge.cot_adapter.cot_server import ServerConfig
    from sovereign_edge.cot_adapter.whaco_to_cot import BridgeConfig, GeoOrigin

    server_cfg = ServerConfig(
        transport=args.transport,
        output_file=args.output_file,
    )
    if args.tak_server:
        parts = args.tak_server.split(":")
        server_cfg.tak_server_host = parts[0]
        server_cfg.tak_server_port = int(parts[1]) if len(parts) > 1 else 8087

    config = SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(lat=args.origin_lat, lon=args.origin_lon, alt_msl=args.origin_alt),
            callsign_prefix=args.callsign,
        ),
        server=server_cfg,
    )

    if args.web:
        _run_gateway_with_web(config, args)
    else:
        run_demo(config, n_ticks=args.ticks, realtime=not args.fast, scenario=args.mode)
    return 0


def _run_gateway_with_web(config, args):
    """Run gateway + web viewer in a single process."""
    import threading
    import time
    from sovereign_edge.gateway import run_demo
    from sovereign_edge.web_viewer import run_viewer

    cot_file = args.output_file or "/tmp/sovereign_edge_cot.xml"

    # Clear the CoT file
    open(cot_file, "w").close()

    # Override config to write to file
    config.server.transport = "file"
    config.server.output_file = cot_file

    # Start gateway in background thread
    def _gateway():
        run_demo(config, n_ticks=args.ticks, realtime=not args.fast, scenario=args.mode)

    gw_thread = threading.Thread(target=_gateway, daemon=True, name="gateway")
    gw_thread.start()

    # Run web viewer in main thread (blocking)
    port = getattr(args, "web_port", 8080)
    run_viewer(port=port, cot_file=cot_file, run_demo="")


def cmd_certify(args: argparse.Namespace) -> int:
    """Run PSC certification on a governance operator."""
    import json
    import numpy as np

    try:
        from sovereign_edge.psc_integration import GovernanceCertifier
    except ImportError:
        print("ERROR: PSC requires scipy. Install with: pip install sovereign-edge[psc]")
        return 1

    if args.operator_file:
        A = np.load(args.operator_file)
        certifier = GovernanceCertifier(
            n_agents=A.shape[0],
            adversary_budget=args.epsilon,
        )
        # Direct operator certification
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "psc"))
        from psc_certificates import certify as psc_certify
        from psc_adversaries import AdversaryClass
        cert = psc_certify(
            operator=A,
            adversary=AdversaryClass(norm="2", bound=args.epsilon),
            operator_id=args.operator_id or args.operator_file,
            stability_threshold=args.threshold,
        )
    else:
        # Generate a demo governance operator
        rng = np.random.default_rng(args.seed)
        N = args.n_agents
        adj = np.zeros((N, N))
        for i in range(N):
            for j in range(i + 1, N):
                if rng.random() < args.connectivity:
                    adj[i, j] = adj[j, i] = 1.0

        weights = {i: 1.0 for i in range(N)}
        if N > 0:
            weights[0] = 3.0  # commander
        if N > 4:
            weights[4] = 2.0  # section lead

        certifier = GovernanceCertifier(
            n_agents=N,
            adversary_budget=args.epsilon,
        )
        cert = certifier.certify_governance(
            adj, weights,
            authority_asymmetry=args.asymmetry,
            operator_id=args.operator_id or f"WHACO-N{N}-demo",
        )

    # Output
    print()
    print(f"  Verdict:       {cert.verdict}")
    print(f"  α(A):          {cert.spectral_abscissa:.4f}")
    print(f"  α_ε(A):        {cert.pseudospectral_abscissa:.4f}")
    print(f"  Fragility:     {cert.fragility_ratio:.2f}×")
    print(f"  ε*:            {cert.epsilon_critical:.4f}")
    print()

    if args.output:
        with open(args.output, "w") as f:
            f.write(cert.to_json())
        print(f"  Certificate written to: {args.output}")

    # Exit code follows PSC convention
    if cert.verdict == "CERTIFIED":
        return 0
    elif cert.verdict == "AT_RISK":
        return 1
    else:  # FALSE_VIABILITY
        return 2


def cmd_demo(args: argparse.Namespace) -> int:
    """Run a quick demo."""
    from sovereign_edge.gateway import run_demo
    from sovereign_edge.cot_adapter.config import SovereignEdgeConfig
    from sovereign_edge.cot_adapter.cot_server import ServerConfig
    from sovereign_edge.cot_adapter.whaco_to_cot import BridgeConfig, GeoOrigin

    scenario = args.scenario or "doomsday"
    ticks = args.ticks or 500
    output = args.output or "/tmp/sovereign_edge_cot.xml"

    config = SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(lat=35.0, lon=-79.0, alt_msl=100.0),
            callsign_prefix="WHACO",
        ),
        server=ServerConfig(
            transport="file",
            output_file=output,
        ),
    )

    result = run_demo(config, n_ticks=ticks, realtime=False, scenario=scenario)

    print(f"\n  CoT output: {output} ({result['cot_events_sent']} events)")
    print(f"  Result:     {result['final_alive']}/20 survive, "
          f"degradation={result['degradation']}, "
          f"posture={result['posture']}")

    if args.web:
        print(f"\n  Starting web viewer on port {args.web_port}...")
        from sovereign_edge.web_viewer import run_viewer
        run_viewer(port=args.web_port, cot_file=output)

    return 0


def cmd_version(args: argparse.Namespace) -> int:
    """Print version and system info."""
    from sovereign_edge import __version__

    print(f"sovereign-edge {__version__}")
    print(f"  Python:  {sys.version.split()[0]}")

    try:
        import numpy
        print(f"  numpy:   {numpy.__version__}")
    except ImportError:
        print("  numpy:   NOT INSTALLED")

    try:
        import scipy
        print(f"  scipy:   {scipy.__version__} (PSC available)")
    except ImportError:
        print("  scipy:   NOT INSTALLED (PSC unavailable)")

    # Check WHACO
    try:
        from blackridge_governor.governor import Governor
        print("  WHACO:   available")
    except ImportError:
        print("  WHACO:   NOT FOUND")

    # Check PSC
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "psc"))
        from psc_core import spectral_abscissa
        print("  PSC:     available")
    except ImportError:
        print("  PSC:     NOT FOUND")

    return 0


def cmd_test(args: argparse.Namespace) -> int:
    """Run the test suite."""
    import subprocess
    results = []

    # CoT adapter tests
    print("── CoT Adapter Tests ──")
    r = subprocess.run(
        [sys.executable, "-m", "sovereign_edge.test_cot_adapter"],
        capture_output=True, text=True,
        cwd=str(Path(__file__).resolve().parent.parent),
    )
    print(r.stdout.split("\n")[-3] if r.stdout else "FAILED")
    results.append(r.returncode)

    # PSC tests
    psc_dir = Path(__file__).resolve().parent.parent / "psc"
    if psc_dir.exists():
        print("\n── PSC Tests ──")
        r = subprocess.run(
            [sys.executable, "-m", "pytest", "test_core.py", "test_certificates.py", "-q"],
            capture_output=True, text=True, cwd=str(psc_dir),
        )
        print(r.stdout.strip().split("\n")[-1] if r.stdout else "FAILED")
        results.append(r.returncode)

    return max(results) if results else 1


def main():
    parser = argparse.ArgumentParser(
        prog="sovereign-edge",
        description="SOVEREIGN EDGE — Governed Autonomous Swarm C2 Platform",
    )
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARN", "ERROR"])
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # ── gateway ──
    gw = sub.add_parser("gateway", help="Run governance engine + CoT + web dashboard")
    gw.add_argument("--mode", default="doomsday", choices=["demo", "doomsday", "live"])
    gw.add_argument("--ticks", type=int, default=500)
    gw.add_argument("--fast", action="store_true", help="No real-time pacing")
    gw.add_argument("--transport", default="file", choices=["udp", "tcp", "file", "all"])
    gw.add_argument("--output-file", default="/tmp/sovereign_edge_cot.xml")
    gw.add_argument("--origin-lat", type=float, default=35.0)
    gw.add_argument("--origin-lon", type=float, default=-79.0)
    gw.add_argument("--origin-alt", type=float, default=100.0)
    gw.add_argument("--callsign", default="WHACO")
    gw.add_argument("--tak-server", default="")
    gw.add_argument("--web", action="store_true", help="Enable embedded web dashboard")
    gw.add_argument("--web-port", type=int, default=8080)
    gw.add_argument("--config", default="")

    # ── certify ──
    cert = sub.add_parser("certify", help="PSC pseudospectral certification")
    cert.add_argument("--operator-file", default="", help="Path to .npy operator matrix")
    cert.add_argument("--operator-id", default="")
    cert.add_argument("--epsilon", type=float, default=0.10, help="Adversary budget")
    cert.add_argument("--threshold", type=float, default=0.0, help="Stability threshold")
    cert.add_argument("--n-agents", type=int, default=16)
    cert.add_argument("--connectivity", type=float, default=0.4)
    cert.add_argument("--asymmetry", type=float, default=0.3)
    cert.add_argument("--seed", type=int, default=42)
    cert.add_argument("--output", "-o", default="", help="Write certificate JSON")

    # ── demo ──
    demo = sub.add_parser("demo", help="Quick demo run")
    demo.add_argument("--scenario", default="doomsday", choices=["demo", "doomsday"])
    demo.add_argument("--ticks", type=int, default=500)
    demo.add_argument("--output", default="/tmp/sovereign_edge_cot.xml")
    demo.add_argument("--web", action="store_true", help="Open web viewer after demo")
    demo.add_argument("--web-port", type=int, default=8080)

    # ── version ──
    sub.add_parser("version", help="Print version and system info")

    # ── test ──
    sub.add_parser("test", help="Run test suite")

    args = parser.parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    if args.command is None:
        parser.print_help()
        return 0

    commands = {
        "gateway": cmd_gateway,
        "certify": cmd_certify,
        "demo": cmd_demo,
        "version": cmd_version,
        "test": cmd_test,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())
