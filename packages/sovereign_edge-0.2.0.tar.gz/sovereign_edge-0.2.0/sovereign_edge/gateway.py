"""
SOVEREIGN EDGE Gateway — Main Entry Point

Runs the REAL WHACO v2.0 governance stack (SwarmGovernor, ResilienceController,
NodeSwitchController, PredictiveEstimator) and outputs Cursor-on-Target events
for TAK ecosystem consumption.

This is NOT a stub. Every tick runs the actual governance loop:
  Predictor → SwarmGovernor → NodeSwitchController → ResilienceController → CoT

Usage:
    python3 -m sovereign_edge.gateway --mode demo --transport file --output-file /tmp/cot.xml
    python3 -m sovereign_edge.gateway --mode doomsday --transport udp
    python3 -m sovereign_edge.gateway --mode demo --transport all --tak-server 10.0.0.5:8087

Modes:
    demo     — 20-agent golden scenario with real governance (500 ticks)
    doomsday — Full doomsday scenario: commander kills, cluster kill,
               double succession, attrition cascade — all through real modules
    live     — Connect to PX4 via MAVLink (requires PX4 SITL or hardware)
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

# WHACO governance stack
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from blackridge_governor.predictor import PredictiveEstimator
from blackridge_governor.swarm_governance import SwarmGovernor
from blackridge_governor.node_switching import NodeSwitchController
from blackridge_governor.resilience import ResilienceController, DegradationLevel
from blackridge_governor.governor import Governor

from sovereign_edge.cot_adapter.config import SovereignEdgeConfig
from sovereign_edge.cot_adapter.cot_server import CoTMulticastServer, ServerConfig
from sovereign_edge.cot_adapter.whaco_to_cot import BridgeConfig, GeoOrigin, WHACOCoTBridge

logger = logging.getLogger("sovereign_edge.gateway")


# ═══════════════════════════════════════════════════════════════════════════
# Adjacency computation
# ═══════════════════════════════════════════════════════════════════════════

def build_adjacency(agents: List[Dict], active: List[bool],
                    comm_range: float = 500.0) -> np.ndarray:
    """Build NxN adjacency matrix from agent positions and comm range."""
    n = len(agents)
    adj = np.zeros((n, n))
    for i in range(n):
        if not active[i]:
            continue
        for j in range(i + 1, n):
            if not active[j]:
                continue
            d = np.linalg.norm(
                np.asarray(agents[i]["pos"][:2]) -
                np.asarray(agents[j]["pos"][:2])
            )
            if d < comm_range:
                adj[i, j] = adj[j, i] = 1.0
    return adj


# ═══════════════════════════════════════════════════════════════════════════
# State extraction — real WHACO modules → CoT bridge input
# ═══════════════════════════════════════════════════════════════════════════

GOVERNOR_MODES = {
    0: "RIDE", 1: "SPRINT", 2: "CRUISE", 3: "CONSERVE",
    4: "PUNCH", 5: "BOOST", 6: "BRAKE", 7: "STABILIZE",
    8: "CLOAK", 9: "GHOST", 10: "SCUTTLE",
}

GOVERNOR_THRUST = {
    "RIDE": 0.20, "SPRINT": 0.85, "CRUISE": 0.55, "CONSERVE": 0.30,
    "PUNCH": 1.00, "BOOST": 0.75, "BRAKE": 0.40, "STABILIZE": 0.55,
    "CLOAK": 0.25, "GHOST": 0.95, "SCUTTLE": 0.15,
}


def determine_governor_mode(agent: Dict, hier_role: str, survival_ratio: float,
                            wind_speed: float, fuel_pressure: float) -> tuple:
    """Determine governor mode based on agent state and governance context.

    Returns (mode_name, mode_id, thrust_frac).
    """
    # Fuel critical → CONSERVE
    if fuel_pressure > 0.7:
        return "CONSERVE", 3, 0.30

    # Low survival → defensive modes
    if survival_ratio < 0.30:
        return "BRAKE", 6, 0.40

    # Commander gets slight boost
    if hier_role == "COMMANDER" and wind_speed > 4.0:
        return "SPRINT", 1, 0.85

    # Strong headwind
    if wind_speed > 4.0 and fuel_pressure < 0.5:
        return "SPRINT", 1, 0.85

    # Tailwind
    if wind_speed < -3.0:
        return "RIDE", 0, 0.20

    return "CRUISE", 2, 0.55


def extract_cot_agents(agents: List[Dict], active: List[bool],
                       governors: List[Governor],
                       hier, res: Dict,
                       fuel_budget: float) -> List[Dict]:
    """Convert internal agent state to CoT bridge format."""
    cot_agents = []
    for i, agent in enumerate(agents):
        if not active[i]:
            continue

        pos = agent["pos"]
        vel = agent.get("vel", np.zeros(2))
        fuel = agent["fuel"]
        fp = agent.get("fuel_pressure", 0.0)

        # Get hierarchy role
        role = hier.roles.get(i, "OPERATOR") if hier else "OPERATOR"

        # Governor state
        mode_name = agent.get("_mode", "CRUISE")
        mode_id = agent.get("_mode_id", 2)
        thrust = agent.get("_thrust", 0.55)

        # ASDP
        asdp = res.get("asdp_assessment", None) if res else None
        asdp_mode = asdp.mode if asdp else "NOMINAL"

        cot_agents.append({
            "agent_id": i,
            "pos": np.array([pos[0], pos[1], -50.0]),  # NED
            "vel": np.array([vel[0], vel[1], 0.0]),
            "fuel_remaining": fuel,
            "fuel_budget": fuel_budget,
            "fuel_pressure": fp,
            "governor_mode": mode_name,
            "governor_mode_id": mode_id,
            "thrust_frac": thrust,
            "groundspeed": float(np.linalg.norm(vel[:2])),
            "active": True,
            "heading": float(np.arctan2(vel[1], vel[0])) if np.linalg.norm(vel[:2]) > 0.1 else 0.0,
            "tactical_role": "STANDARD",
            "compromise_level": "CLEAN",
            "link_state": "NORMAL",
        })

    return cot_agents


def extract_cot_hierarchy(hier) -> Dict:
    """Convert HierarchyState to CoT bridge format."""
    if hier is None:
        return {}
    return {
        "roles": dict(hier.roles),
        "commander_idx": hier.commander_idx,
        "section_leads": list(hier.section_leads),
        "sections": {k: list(v) for k, v in hier.sections.items()},
        "posture": hier.posture,
        "election_epoch": hier.election_epoch,
    }


def extract_cot_resilience(res: Optional[Dict]) -> Dict:
    """Convert resilience output to CoT bridge format."""
    if res is None:
        return {}
    asdp = res.get("asdp_assessment", None)
    return {
        "asdp_mode": asdp.mode if asdp else "NOMINAL",
        "svi": asdp.svi if asdp else 1.0,
        "degradation_level": res.get("degradation_level", DegradationLevel.L0_FULL).value,
        "scorch_active": res.get("scorch_assessment", None) is not None
                         and getattr(res.get("scorch_assessment"), "should_trigger", False),
        "cdo_active": False,
        "mean_lambda2": 0.0,
    }


def extract_cot_threats(threats: List[Dict]) -> List[Dict]:
    """Convert threat dicts to CoT bridge format."""
    cot_threats = []
    for th in threats:
        pos = th.get("pos", np.zeros(2))
        vel = th.get("vel", np.zeros(2))
        cot_threats.append({
            "threat_id": str(th.get("id", "UNK")),
            "pos": np.array([pos[0], pos[1], -100.0]),
            "vel": np.array([vel[0], vel[1], 0.0]),
            "classification": "RF_ACTIVE",
            "confidence": 0.75,
            "radar_dbm": -55.0,
            "intent": "patrol",
        })
    return cot_threats


# ═══════════════════════════════════════════════════════════════════════════
# Real governance demo — golden scenario through CoT
# ═══════════════════════════════════════════════════════════════════════════

def run_demo(config: SovereignEdgeConfig, n_ticks: int = 500,
             realtime: bool = True, scenario: str = "demo") -> Dict:
    """Run the REAL WHACO governance stack with CoT output.

    This is the golden scenario (or doomsday variant) running through
    actual SwarmGovernor, ResilienceController, NodeSwitchController,
    and PredictiveEstimator — NOT hardcoded state transitions.
    """
    SEED = 42
    N = 20
    DT = 0.5
    FUEL_BUDGET = 60.0

    rng = np.random.default_rng(SEED)

    # ── Initialize agents ──
    agents = [
        {"id": i, "fuel": FUEL_BUDGET, "fuel_pressure": 0.15,
         "pos": rng.uniform(-300, 300, size=2),
         "vel": rng.uniform(-2, 2, size=2),
         "health": 1.0, "workload": 0,
         "_mode": "CRUISE", "_mode_id": 2, "_thrust": 0.55}
        for i in range(N)
    ]
    # Give some agents extra fuel for commander election weight
    agents[10]["fuel"] = 90.0
    agents[11]["fuel"] = 88.0
    active = [True] * N

    # ── Initialize threats ──
    threats = [
        {"id": 0, "pos": np.array([400.0, 200.0]), "vel": np.array([-3.0, 1.0])},
        {"id": 1, "pos": np.array([-300.0, 400.0]), "vel": np.array([2.0, -2.0])},
        {"id": 2, "pos": np.array([200.0, -300.0]), "vel": np.array([-1.0, 3.0])},
    ]

    # ── Initialize REAL governance modules ──
    estimators = [PredictiveEstimator(dt=DT) for _ in range(N)]
    gov = SwarmGovernor(n_sections=3, election_interval=100)
    node_ctrl = NodeSwitchController(dead_timeout=8, checkpoint_interval=10,
                                     standby_update_interval=5)
    resilience_ctrl = ResilienceController(n_initial=N, intercept_radius=150.0)

    # ── Initialize PSC certification (if scipy available) ──
    psc_certifier = None
    try:
        from sovereign_edge.psc_integration import GovernanceCertifier
        psc_certifier = GovernanceCertifier(
            n_agents=N, adversary_budget=0.10,
            warn_at_fraction=0.75, crit_at_fraction=0.95,
        )
        logger.info("PSC engine loaded — will certify governance on first tick")
    except ImportError:
        logger.info("PSC not available (scipy missing) — running without certification")

    # ── Initialize CoT pipeline ──
    bridge = WHACOCoTBridge(config.bridge)
    server = CoTMulticastServer(config.server)

    sent_count = 0
    event_log = []

    def on_send(event):
        nonlocal sent_count
        sent_count += 1

    server.set_callback(on_send)
    server.start()

    wind_wx, wind_wy = -2.0, 0.5

    is_doomsday = (scenario == "doomsday")

    logger.info("╔══════════════════════════════════════════════════╗")
    logger.info("║  SOVEREIGN EDGE — %s Demo (REAL GOVERNANCE)  ║",
                "Doomsday" if is_doomsday else "Golden ")
    logger.info("║  Agents: %d | Ticks: %d | Transport: %-10s  ║",
                N, n_ticks, config.server.transport)
    logger.info("╚══════════════════════════════════════════════════╝")

    t0 = time.perf_counter()

    try:
        for tick in range(n_ticks):
            # ── Scripted adversarial events ──
            if is_doomsday:
                # Abrupt headwind at tick 100
                if tick == 100:
                    wind_wx = -8.0
                    event_log.append({
                        "tick": tick, "event_type": "WIND_SHIFT",
                        "severity": "WARN", "agent_id": -1,
                        "reason": "abrupt headwind wx=-8.0"
                    })
                    logger.warning("t=%6.1fs  WIND_SHIFT  abrupt headwind wx=-8.0",
                                   tick * DT)

                # Commander kill at tick 200
                if tick == 200:
                    cmd = gov.hierarchy.commander_idx
                    if cmd >= 0 and active[cmd]:
                        active[cmd] = False
                        event_log.append({
                            "tick": tick, "event_type": "COMMANDER_KILLED",
                            "severity": "CRIT", "agent_id": cmd,
                            "reason": f"agent {cmd} eliminated"
                        })
                        logger.critical("t=%6.1fs  COMMANDER_KILLED  agent %d",
                                        tick * DT, cmd)

                # Cluster kill at tick 300
                if tick == 300:
                    cluster_center = np.array([50.0, 50.0])
                    killed = []
                    for i in range(N):
                        if active[i] and len(killed) < 3:
                            d = np.linalg.norm(agents[i]["pos"][:2] - cluster_center)
                            if d < 300:
                                active[i] = False
                                resilience_ctrl.circuit_breaker.report_loss(
                                    i, agents[i]["pos"], tick)
                                killed.append(i)
                    if killed:
                        event_log.append({
                            "tick": tick, "event_type": "CLUSTER_KILL",
                            "severity": "CRIT", "agent_id": -1,
                            "reason": f"killed {len(killed)} agents: {killed}"
                        })
                        logger.critical("t=%6.1fs  CLUSTER_KILL  %d agents: %s",
                                        tick * DT, len(killed), killed)

                # Double succession at tick 400
                if tick == 400:
                    cmd = gov.hierarchy.commander_idx
                    if cmd >= 0 and active[cmd]:
                        active[cmd] = False
                        event_log.append({
                            "tick": tick, "event_type": "COMMANDER_KILLED_2",
                            "severity": "CRIT", "agent_id": cmd,
                            "reason": f"double succession: agent {cmd} eliminated"
                        })
                        logger.critical(
                            "t=%6.1fs  COMMANDER_KILLED_2  agent %d (double succession)",
                            tick * DT, cmd)

                # Attrition cascade (ticks 450-480)
                if 450 <= tick <= 480 and tick % 5 == 0:
                    alive = [i for i in range(N) if active[i]]
                    survival = len(alive) / N
                    if survival > 0.40 and alive:
                        victim = int(rng.choice(alive))
                        active[victim] = False
                        event_log.append({
                            "tick": tick, "event_type": "ATTRITION",
                            "severity": "WARN", "agent_id": victim,
                            "reason": f"survival={survival:.0%}"
                        })

                # Terminal attrition (ticks 485-495)
                if 485 <= tick < 495 and tick % 2 == 0:
                    alive = [i for i in range(N) if active[i]]
                    if len(alive) > 3:
                        victim = int(rng.choice(alive))
                        active[victim] = False
                        agents[victim]["fuel_pressure"] = 0.95

            # ── Physics ──
            for i in range(N):
                if not active[i]:
                    continue
                agents[i]["pos"] = agents[i]["pos"] + agents[i]["vel"] * DT
                agents[i]["vel"] = agents[i]["vel"] * 0.99
                fuel_burn = 0.008 * (agents[i]["_thrust"] ** 2) * DT
                agents[i]["fuel"] = max(0, agents[i]["fuel"] - fuel_burn)
                agents[i]["fuel_pressure"] = max(0, min(1,
                    1 - agents[i]["fuel"] / max(FUEL_BUDGET, 1)))
                if agents[i]["fuel"] <= 0.01:
                    active[i] = False

            for th in threats:
                th["pos"] = th["pos"] + th["vel"] * DT

            # ── REAL governance modules ──
            adj = build_adjacency(agents, active)
            n_active = sum(active)
            survival_ratio = n_active / N

            # Predictor (run on first 5 agents for perf)
            for i in range(min(5, N)):
                if active[i]:
                    estimators[i].estimate(
                        wind_x=wind_wx + rng.normal(0, 0.3),
                        wind_y=wind_wy + rng.normal(0, 0.3),
                        fuel_remaining=agents[i]["fuel"],
                        throttle_frac=agents[i]["_thrust"],
                        fuel_budget=FUEL_BUDGET,
                        pos=agents[i]["pos"],
                        threats=threats,
                    )

            # SwarmGovernor — real election, posture, task allocation
            hier = gov.update(agents, active, adj,
                              current_time=tick * DT, phase=0, rng=rng)

            # NodeSwitchController — real heartbeat monitoring, handoff
            node_ctrl.tick(agents, active, adj, hier, phase=0)

            # ResilienceController — real ASDP, cascade detection, SCORCH assessment
            res = resilience_ctrl.tick(
                agents, active, adj, threats=threats,
                cdo_active=(survival_ratio < 0.70),
                mission_objectives_remaining=1 if n_active > 3 else 0,
                section_leads=hier.section_leads,
            )

            # Cascade detection events
            if res["cascade"] is not None and res["cascade"].contained:
                event_log.append({
                    "tick": tick, "event_type": "CASCADE_CONTAINED",
                    "severity": "WARN", "agent_id": -1,
                    "reason": f"agents lost: {res['cascade'].agents_lost}"
                })
                logger.warning("t=%6.1fs  CASCADE_CONTAINED  agents=%s",
                               tick * DT, res["cascade"].agents_lost)

            # ── PSC: certify on first tick, drift check every 50 ticks ──
            if psc_certifier is not None:
                hier_weights = {
                    i: (3.0 if hier.roles.get(i) == "COMMANDER"
                        else 2.0 if hier.roles.get(i) == "SECTION_LEAD"
                        else 1.0)
                    for i in range(N) if active[i]
                }
                if tick == 0:
                    try:
                        psc_cert = psc_certifier.certify_governance(
                            adj, hier_weights, authority_asymmetry=0.3,
                            operator_id=f"WHACO-{scenario}-N{N}",
                        )
                        event_log.append({
                            "tick": tick, "event_type": "PSC_CERTIFIED",
                            "severity": "INFO", "agent_id": -1,
                            "reason": f"verdict={psc_cert.verdict} "
                                      f"fragility={psc_cert.fragility_ratio:.2f}x "
                                      f"eps*={psc_cert.epsilon_critical:.4f}"
                        })
                    except Exception as e:
                        logger.warning("PSC certification failed: %s", e)
                elif tick % 50 == 0 and psc_certifier.is_certified:
                    try:
                        drift = psc_certifier.check_drift(adj, hier_weights, 0.3)
                        if drift.severity != "OK":
                            event_log.append({
                                "tick": tick, "event_type": "PSC_DRIFT",
                                "severity": "CRIT" if drift.severity == "CRIT" else "WARN",
                                "agent_id": -1,
                                "reason": drift.message,
                            })
                            logger.warning("t=%6.1fs  PSC_DRIFT  %s",
                                           tick * DT, drift.message)
                    except Exception:
                        pass

            # Update agent governor modes based on governance output
            wind_speed = abs(wind_wx)
            for i in range(N):
                if not active[i]:
                    continue
                role = hier.roles.get(i, "OPERATOR")
                fp = agents[i]["fuel_pressure"]
                mode_name, mode_id, thrust = determine_governor_mode(
                    agents[i], role, survival_ratio, wind_speed, fp)

                # Apply resilience thrust caps
                if i in res.get("containment_agents", set()):
                    thrust = min(thrust, 0.30)
                    mode_name = "CONSERVE"
                    mode_id = 3

                # Apply ASDP thrust caps
                asdp = res.get("asdp_assessment", None)
                if asdp and hasattr(asdp, "mode") and asdp.mode != "ASDP_NOMINAL":
                    cap = {"ASDP_RECOVER": 0.70, "ASDP_ISOLATE": 0.30,
                           "ASDP_ASSIST": 0.85, "ASDP_DENY_LOGICAL": 0.00,
                           "ASDP_DISPERSE": 0.95}.get(asdp.mode, 1.0)
                    thrust = min(thrust, cap)

                agents[i]["_mode"] = mode_name
                agents[i]["_mode_id"] = mode_id
                agents[i]["_thrust"] = thrust

            # ── Generate and send CoT events ──
            cot_agents = extract_cot_agents(
                agents, active, [], hier, res, FUEL_BUDGET)
            cot_hier = extract_cot_hierarchy(hier)
            cot_res = extract_cot_resilience(res)
            cot_threats = extract_cot_threats(threats)

            events = bridge.generate_events(
                agents=cot_agents,
                hierarchy=cot_hier,
                resilience=cot_res,
                threats=cot_threats,
                event_log=event_log[-10:],
            )
            server.send_batch(events)

            # Status reporting
            if tick > 0 and tick % 100 == 0:
                deg = res.get("degradation_level", DegradationLevel.L0_FULL)
                asdp = res.get("asdp_assessment", None)
                asdp_mode = asdp.mode if asdp else "NOMINAL"
                logger.info(
                    "t=%6.1fs  STATUS  alive=%d/%d deg=%s cmd=%d "
                    "posture=%s asdp=%s events_sent=%d",
                    tick * DT, n_active, N, deg.name,
                    hier.commander_idx, hier.posture, asdp_mode, sent_count,
                )

            # Real-time pacing (skip in fast mode)
            if realtime:
                time.sleep(DT)

    except KeyboardInterrupt:
        logger.info("Demo interrupted by user")
    finally:
        server.stop()

    elapsed = time.perf_counter() - t0
    final_alive = sum(active)
    final_survival = final_alive / N

    logger.info("═" * 60)
    logger.info("  FINAL STATE")
    logger.info("    Survival:     %d/%d (%.0f%%)", final_alive, N, final_survival * 100)
    logger.info("    Degradation:  %s", resilience_ctrl.degrader.level.name)
    logger.info("    Commander:    %d", hier.commander_idx)
    logger.info("    Posture:      %s", hier.posture)
    logger.info("    Handoffs:     %d", node_ctrl.total_handoffs)
    logger.info("    Checkpoints:  %d", node_ctrl.preserver.checkpoint_count)
    logger.info("    CoT events:   %d sent", sent_count)
    logger.info("    Runtime:      %.1fs (%.1fx realtime)",
                elapsed, (n_ticks * DT) / max(elapsed, 0.001))
    logger.info("═" * 60)

    return {
        "final_alive": final_alive,
        "final_survival": final_survival,
        "commander": hier.commander_idx,
        "posture": hier.posture,
        "degradation": resilience_ctrl.degrader.level.name,
        "handoffs": node_ctrl.total_handoffs,
        "cot_events_sent": sent_count,
        "elapsed_s": round(elapsed, 3),
        "event_log": event_log,
    }


# ═══════════════════════════════════════════════════════════════════════════
# CLI
# ═══════════════════════════════════════════════════════════════════════════

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="SOVEREIGN EDGE — Sensor Gateway (Real WHACO Governance)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--config", type=str, default="",
                        help="Path to JSON config file")
    parser.add_argument("--origin-lat", type=float, default=35.0,
                        help="WGS-84 origin latitude")
    parser.add_argument("--origin-lon", type=float, default=-79.0,
                        help="WGS-84 origin longitude")
    parser.add_argument("--origin-alt", type=float, default=100.0,
                        help="Origin altitude MSL (meters)")
    parser.add_argument("--callsign", type=str, default="WHACO",
                        help="Callsign prefix")
    parser.add_argument("--transport", type=str, default="file",
                        choices=["udp", "tcp", "file", "all"],
                        help="CoT transport mode")
    parser.add_argument("--tak-server", type=str, default="",
                        help="TAK Server host:port")
    parser.add_argument("--output-file", type=str,
                        default="/tmp/sovereign_edge_cot.xml",
                        help="CoT output file (for file/all transport)")
    parser.add_argument("--log-level", type=str, default="INFO",
                        choices=["DEBUG", "INFO", "WARN", "ERROR"],
                        help="Log level")
    parser.add_argument("--mode", type=str, default="demo",
                        choices=["demo", "doomsday", "live"],
                        help="Scenario mode")
    parser.add_argument("--ticks", type=int, default=500,
                        help="Number of simulation ticks")
    parser.add_argument("--fast", action="store_true",
                        help="Run without real-time pacing (fast as possible)")
    parser.add_argument("--web", action="store_true",
                        help="Start web viewer on port 8080")
    return parser.parse_args()


def build_config(args: argparse.Namespace) -> SovereignEdgeConfig:
    """Build configuration from args or config file."""
    if args.config and Path(args.config).exists():
        return SovereignEdgeConfig.from_json(args.config)

    server_cfg = ServerConfig(
        transport=args.transport,
        output_file=args.output_file,
    )

    if args.tak_server:
        parts = args.tak_server.split(":")
        server_cfg.tak_server_host = parts[0]
        server_cfg.tak_server_port = int(parts[1]) if len(parts) > 1 else 8087

    return SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(
                lat=args.origin_lat,
                lon=args.origin_lon,
                alt_msl=args.origin_alt,
            ),
            callsign_prefix=args.callsign,
        ),
        server=server_cfg,
    )


def main() -> None:
    args = parse_args()

    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    config = build_config(args)

    if args.mode in ("demo", "doomsday"):
        result = run_demo(
            config,
            n_ticks=args.ticks,
            realtime=not args.fast,
            scenario=args.mode,
        )

        # Write result summary
        out_path = "/tmp/sovereign_edge_result.json"
        with open(out_path, "w") as f:
            def _ser(o):
                if isinstance(o, np.ndarray): return o.tolist()
                if isinstance(o, (np.integer,)): return int(o)
                if isinstance(o, (np.floating,)): return float(o)
                raise TypeError(f"Not serializable: {type(o)}")
            json.dump(result, f, indent=2, default=_ser)
        logger.info("Result written to %s", out_path)

    elif args.mode == "live":
        logger.error("Live mode requires MAVLink connection — use with PX4 SITL")
        sys.exit(1)


if __name__ == "__main__":
    main()
