"""
SOVEREIGN EDGE — Governed Autonomous Swarm C2 Platform
======================================================

Bridges WHACO governance to TAK/ATAK via Cursor-on-Target protocol,
with pseudospectral certification (PSC) for formal robustness verification.

Install:
    pip install .                          # from sovereign_edge/ directory
    pip install .[psc]                     # with PSC (scipy)
    pip install .[all]                     # everything

CLI:
    sovereign-edge gateway --web           # governance + CoT + dashboard
    sovereign-edge certify                 # PSC certification
    sovereign-edge demo                    # quick demo
    sovereign-edge version                 # system info
    sovereign-edge test                    # run tests

Python:
    from sovereign_edge.cot_adapter import WHACOCoTBridge, CoTMulticastServer
    from sovereign_edge.psc_integration import GovernanceCertifier
    from sovereign_edge.gateway import run_demo

Blackridge Autonomy LLC — UNCLASSIFIED // REL TO USA, FVEY
"""

__version__ = "0.2.0"
__author__ = "Blackridge Autonomy LLC"
