"""
CoT Multicast Server — broadcasts CoT events to TAK ecosystem.

Supports three transport modes:
  1. UDP Multicast (default) — standard TAK SA multicast (239.2.3.1:6969)
  2. TCP (TAK Server) — persistent connection to TAK Server input port
  3. File — write CoT events to a file for replay/debug

The server handles:
  - Rate limiting (configurable Hz)
  - Event batching for bandwidth efficiency on mesh radios
  - Heartbeat injection (TAK requires periodic updates to keep tracks alive)
  - Thread-safe event queue for async operation
"""

from __future__ import annotations

import logging
import queue
import socket
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, List, Optional

from sovereign_edge.cot_adapter.cot_types import CoTEvent

logger = logging.getLogger(__name__)


@dataclass
class ServerConfig:
    """CoT server configuration."""
    # UDP Multicast (default TAK SA channel)
    multicast_addr: str = "239.2.3.1"
    multicast_port: int = 6969
    multicast_iface: str = "0.0.0.0"
    multicast_ttl: int = 32

    # TCP (TAK Server)
    tak_server_host: str = ""
    tak_server_port: int = 8087

    # Transport mode
    transport: str = "udp"             # "udp", "tcp", "file", "all"

    # Rate control
    max_rate_hz: float = 5.0
    batch_size: int = 20               # max events per transmission
    heartbeat_interval_s: float = 15.0 # re-send all tracks periodically

    # File output (for debug/replay)
    output_file: str = ""

    # TLS for TAK Server connections
    tls_cert: str = ""
    tls_key: str = ""
    tls_ca: str = ""


class CoTMulticastServer:
    """Broadcasts CoT events via UDP multicast and/or TCP to TAK Server.

    Usage:
        server = CoTMulticastServer(config)
        server.start()

        # From your WHACO tick loop:
        events = bridge.generate_events(...)
        server.send_batch(events)

        # Cleanup:
        server.stop()
    """

    def __init__(self, config: Optional[ServerConfig] = None):
        self.config = config or ServerConfig()
        self._queue: queue.Queue[CoTEvent] = queue.Queue(maxsize=1000)
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._udp_sock: Optional[socket.socket] = None
        self._tcp_sock: Optional[socket.socket] = None
        self._file_handle = None
        self._last_events: List[CoTEvent] = []
        self._last_heartbeat = 0.0
        self._stats = {"sent": 0, "dropped": 0, "errors": 0}
        self._on_send: Optional[Callable[[CoTEvent], None]] = None

    @property
    def stats(self) -> dict:
        return dict(self._stats)

    def start(self) -> None:
        """Initialize transports and start the sender thread."""
        if self._running:
            return

        transport = self.config.transport

        if transport in ("udp", "all"):
            self._init_udp()

        if transport in ("tcp", "all") and self.config.tak_server_host:
            self._init_tcp()

        if transport in ("file", "all") and self.config.output_file:
            self._file_handle = open(self.config.output_file, "a")

        self._running = True
        self._thread = threading.Thread(
            target=self._sender_loop, daemon=True, name="cot-sender"
        )
        self._thread.start()
        logger.info(
            "CoT server started: transport=%s addr=%s:%d",
            transport, self.config.multicast_addr, self.config.multicast_port,
        )

    def stop(self) -> None:
        """Stop the sender thread and close transports."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5.0)
        if self._udp_sock:
            self._udp_sock.close()
        if self._tcp_sock:
            self._tcp_sock.close()
        if self._file_handle:
            self._file_handle.close()
        logger.info("CoT server stopped. Stats: %s", self._stats)

    def send(self, event: CoTEvent) -> None:
        """Queue a single CoT event for transmission."""
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            self._stats["dropped"] += 1

    def send_batch(self, events: List[CoTEvent]) -> None:
        """Queue a batch of CoT events for transmission."""
        self._last_events = events  # Cache for heartbeat replay
        for event in events:
            self.send(event)

    def set_callback(self, callback: Callable[[CoTEvent], None]) -> None:
        """Set a callback invoked for each sent event (for testing/monitoring)."""
        self._on_send = callback

    def _init_udp(self) -> None:
        """Initialize UDP multicast socket."""
        self._udp_sock = socket.socket(
            socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP
        )
        self._udp_sock.setsockopt(
            socket.IPPROTO_IP, socket.IP_MULTICAST_TTL,
            struct.pack("b", self.config.multicast_ttl),
        )
        # Bind to specific interface if configured
        if self.config.multicast_iface != "0.0.0.0":
            self._udp_sock.setsockopt(
                socket.IPPROTO_IP, socket.IP_MULTICAST_IF,
                socket.inet_aton(self.config.multicast_iface),
            )
        logger.info(
            "UDP multicast initialized: %s:%d TTL=%d",
            self.config.multicast_addr, self.config.multicast_port,
            self.config.multicast_ttl,
        )

    def _init_tcp(self) -> None:
        """Initialize TCP connection to TAK Server."""
        try:
            self._tcp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            if self.config.tls_cert:
                import ssl
                ctx = ssl.create_default_context()
                ctx.load_cert_chain(self.config.tls_cert, self.config.tls_key)
                if self.config.tls_ca:
                    ctx.load_verify_locations(self.config.tls_ca)
                self._tcp_sock = ctx.wrap_socket(
                    self._tcp_sock,
                    server_hostname=self.config.tak_server_host,
                )
            self._tcp_sock.connect(
                (self.config.tak_server_host, self.config.tak_server_port)
            )
            logger.info(
                "TCP connected to TAK Server: %s:%d",
                self.config.tak_server_host, self.config.tak_server_port,
            )
        except Exception as e:
            logger.error("TCP connection failed: %s", e)
            self._tcp_sock = None

    def _sender_loop(self) -> None:
        """Main sender loop — drains queue and transmits at rate limit."""
        min_interval = 1.0 / max(self.config.max_rate_hz, 0.1)

        while self._running:
            batch: List[CoTEvent] = []
            try:
                # Drain up to batch_size events
                for _ in range(self.config.batch_size):
                    try:
                        event = self._queue.get_nowait()
                        batch.append(event)
                    except queue.Empty:
                        break

                # Send heartbeat (re-transmit cached tracks) if interval elapsed
                now = time.monotonic()
                if (
                    not batch
                    and self._last_events
                    and now - self._last_heartbeat > self.config.heartbeat_interval_s
                ):
                    batch = self._last_events
                    self._last_heartbeat = now

                # Transmit
                for event in batch:
                    self._transmit(event)

                # Rate limit
                if not batch:
                    time.sleep(min_interval)

            except Exception as e:
                logger.error("Sender loop error: %s", e)
                self._stats["errors"] += 1
                time.sleep(1.0)

    def _transmit(self, event: CoTEvent) -> None:
        """Send a single CoT event via all active transports."""
        xml_bytes = event.to_xml_bytes()

        if self._udp_sock:
            try:
                self._udp_sock.sendto(
                    xml_bytes,
                    (self.config.multicast_addr, self.config.multicast_port),
                )
            except Exception as e:
                logger.debug("UDP send error: %s", e)
                self._stats["errors"] += 1

        if self._tcp_sock:
            try:
                self._tcp_sock.sendall(xml_bytes)
            except Exception as e:
                logger.debug("TCP send error: %s", e)
                self._stats["errors"] += 1
                self._tcp_sock = None  # Will reconnect on next init

        if self._file_handle:
            try:
                self._file_handle.write(event.to_xml_string() + "\n")
                self._file_handle.flush()
            except Exception as e:
                logger.debug("File write error: %s", e)

        self._stats["sent"] += 1

        if self._on_send:
            self._on_send(event)
