"""
Sovereign Edge CoT Adapter configuration.

Provides sensible defaults for common deployment scenarios:
  - LAB: file output, no network (CI/testing)
  - FIELD: UDP multicast on standard TAK SA channel
  - TAK_SERVER: TCP to TAK Server with optional TLS
  - GATEWAY: Full stack on Jetson AGX Orin edge compute

All coordinates use WGS-84. Set the origin to your launch point.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Optional

from sovereign_edge.cot_adapter.cot_server import ServerConfig
from sovereign_edge.cot_adapter.whaco_to_cot import BridgeConfig, GeoOrigin


@dataclass
class SovereignEdgeConfig:
    """Top-level configuration for the Sovereign Edge CoT pipeline."""
    bridge: BridgeConfig
    server: ServerConfig
    # NATO classification marking
    classification: str = "UNCLASSIFIED"
    releasability: str = "REL TO USA, FVEY"
    # Operational
    mission_id: str = ""
    callsign_prefix: str = "WHACO"

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2)

    @classmethod
    def from_json(cls, path: str) -> "SovereignEdgeConfig":
        with open(path) as f:
            data = json.load(f)
        bridge_data = data.pop("bridge", {})
        server_data = data.pop("server", {})
        origin_data = bridge_data.pop("origin", {})
        return cls(
            bridge=BridgeConfig(
                origin=GeoOrigin(**origin_data),
                **bridge_data,
            ),
            server=ServerConfig(**server_data),
            **data,
        )


# ── Preset Configurations ──

def lab_config(
    output_file: str = "/tmp/whaco_cot_output.xml",
    origin_lat: float = 35.0,
    origin_lon: float = -79.0,
) -> SovereignEdgeConfig:
    """Lab/CI configuration — file output only, no network."""
    return SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(lat=origin_lat, lon=origin_lon, alt_msl=100.0),
            callsign_prefix="WHACO-LAB",
            update_rate_hz=2.0,
        ),
        server=ServerConfig(
            transport="file",
            output_file=output_file,
        ),
        classification="UNCLASSIFIED",
        mission_id="LAB-TEST",
    )


def field_config(
    origin_lat: float = 35.0,
    origin_lon: float = -79.0,
    origin_alt: float = 100.0,
    multicast_iface: str = "0.0.0.0",
) -> SovereignEdgeConfig:
    """Field deployment — UDP multicast on standard TAK SA channel."""
    return SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(lat=origin_lat, lon=origin_lon, alt_msl=origin_alt),
            callsign_prefix="WHACO",
            update_rate_hz=2.0,
            stale_seconds=30.0,
        ),
        server=ServerConfig(
            transport="udp",
            multicast_addr="239.2.3.1",
            multicast_port=6969,
            multicast_iface=multicast_iface,
            multicast_ttl=32,
            heartbeat_interval_s=15.0,
        ),
        classification="UNCLASSIFIED",
        releasability="REL TO USA, FVEY",
    )


def tak_server_config(
    host: str,
    port: int = 8087,
    tls_cert: str = "",
    tls_key: str = "",
    tls_ca: str = "",
    origin_lat: float = 35.0,
    origin_lon: float = -79.0,
) -> SovereignEdgeConfig:
    """TAK Server connection — TCP with optional TLS."""
    return SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(lat=origin_lat, lon=origin_lon, alt_msl=100.0),
            callsign_prefix="WHACO",
            update_rate_hz=2.0,
        ),
        server=ServerConfig(
            transport="tcp",
            tak_server_host=host,
            tak_server_port=port,
            tls_cert=tls_cert,
            tls_key=tls_key,
            tls_ca=tls_ca,
        ),
    )


def gateway_config(
    origin_lat: float = 35.0,
    origin_lon: float = -79.0,
    origin_alt: float = 100.0,
    tak_server_host: str = "",
    tak_server_port: int = 8087,
) -> SovereignEdgeConfig:
    """Sensor gateway (Jetson AGX Orin) — full stack, all transports."""
    server_cfg = ServerConfig(
        transport="all",
        multicast_addr="239.2.3.1",
        multicast_port=6969,
        multicast_ttl=32,
        max_rate_hz=5.0,
        heartbeat_interval_s=10.0,
        output_file="/var/log/whaco/cot_events.xml",
    )
    if tak_server_host:
        server_cfg.tak_server_host = tak_server_host
        server_cfg.tak_server_port = tak_server_port

    return SovereignEdgeConfig(
        bridge=BridgeConfig(
            origin=GeoOrigin(lat=origin_lat, lon=origin_lon, alt_msl=origin_alt),
            callsign_prefix="WHACO",
            update_rate_hz=5.0,
            stale_seconds=20.0,
            threat_stale_seconds=10.0,
        ),
        server=server_cfg,
        classification="UNCLASSIFIED",
        releasability="REL TO USA, FVEY",
    )
