"""
Cursor-on-Target (CoT) data types for MIL-STD-2525C compliant messaging.

CoT is the lingua franca of TAK ecosystem (ATAK, WinTAK, TAK Server).
Each event is a self-describing XML stanza with:
  - UID: unique track identifier
  - Type: 2525C-derived atom (e.g., a-f-A-M-F-Q = friendly UAV rotary)
  - Point: WGS-84 lat/lon/hae with circular/linear error
  - Detail: extensible payload block

References:
  - CoT Schema: https://www.mitre.org/sites/default/files/pdf/09_4937.pdf
  - MIL-STD-2525C symbol taxonomy
  - TAK Server Integration Guide
"""

from __future__ import annotations

import uuid
import xml.etree.ElementTree as ET
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


# ── MIL-STD-2525C Type Codes for WHACO entities ──

COT_TYPE_UAV_ROTARY = "a-f-A-M-F-Q"       # friendly, air, military, UAV, rotary
COT_TYPE_UAV_FIXED  = "a-f-A-M-F-F"       # friendly, air, military, UAV, fixed-wing
COT_TYPE_THREAT_AIR = "a-h-A"              # hostile, air
COT_TYPE_THREAT_GND = "a-h-G"              # hostile, ground
COT_TYPE_THREAT_EW  = "a-h-X-i"           # hostile, other, signal/EW emitter
COT_TYPE_SENSOR     = "a-f-G-E-S"         # friendly, ground, equipment, sensor
COT_TYPE_C2_NODE    = "a-f-G-U-C-I"       # friendly, ground, unit, C2
COT_TYPE_BOUNDARY   = "u-d-f"             # drawing, freeform (containment zones)

# WHACO-specific detail namespace
WHACO_NS = "com.blackridge.whaco"

# Default CoT stale time (seconds) — how long a track persists without update
DEFAULT_STALE_SECONDS = 30


@dataclass
class CoTPoint:
    """WGS-84 position with error estimates."""
    lat: float                          # decimal degrees
    lon: float                          # decimal degrees
    hae: float = 0.0                    # height above ellipsoid (meters)
    ce: float = 9999999.0              # circular error (meters), 9999999 = unknown
    le: float = 9999999.0              # linear error (meters), 9999999 = unknown

    def to_xml(self) -> ET.Element:
        el = ET.Element("point")
        el.set("lat", f"{self.lat:.7f}")
        el.set("lon", f"{self.lon:.7f}")
        el.set("hae", f"{self.hae:.1f}")
        el.set("ce", f"{self.ce:.1f}")
        el.set("le", f"{self.le:.1f}")
        return el


@dataclass
class CoTDetail:
    """Extensible detail block for CoT events.

    Standard sub-elements:
      - contact: callsign
      - __group: team color + role
      - status: battery/readiness
      - track: course + speed
      - remarks: freetext

    WHACO extensions (under __whaco namespace):
      - governor: mode, thrust, fuel state
      - governance: role, posture, hierarchy
      - threat: SCORCH/EW threat assessment
      - resilience: ASDP level, SVI, degradation
    """
    callsign: str = ""
    team_color: str = "Cyan"
    team_role: str = "Team Member"
    course: float = 0.0                # degrees true
    speed: float = 0.0                 # m/s
    battery: int = 100                 # percent
    remarks: str = ""

    # WHACO extensions
    governor_mode: str = ""
    governor_mode_id: int = -1
    thrust_frac: float = 0.0
    fuel_remaining: float = 0.0
    fuel_pressure: float = 0.0

    hierarchy_role: str = ""           # COMMANDER / SECTION_LEAD / OPERATOR
    tactical_role: str = ""            # SCOUT / SHIELD / DECOY / etc.
    posture: str = ""                  # NORMAL / DEFENSIVE / RETREAT
    section_id: int = -1
    asdp_mode: str = ""                # NOMINAL / RECOVER / ISOLATE / etc.
    svi: float = 1.0                   # Survival Viability Index
    degradation_level: int = 0         # L0-L4

    ew_active: bool = False
    ew_role: str = "passive"
    radar_dbm: float = -120.0
    scorch_active: bool = False
    cdo_active: bool = False

    compromise_level: str = "CLEAN"
    link_state: str = "NORMAL"

    def to_xml(self) -> ET.Element:
        detail = ET.Element("detail")

        # Standard CoT sub-elements
        if self.callsign:
            contact = ET.SubElement(detail, "contact")
            contact.set("callsign", self.callsign)

        group = ET.SubElement(detail, "__group")
        group.set("name", self.team_color)
        group.set("role", self.team_role)

        track_el = ET.SubElement(detail, "track")
        track_el.set("course", f"{self.course:.1f}")
        track_el.set("speed", f"{self.speed:.2f}")

        status = ET.SubElement(detail, "status")
        status.set("battery", str(self.battery))
        status.set("readiness", "true")

        if self.remarks:
            remarks_el = ET.SubElement(detail, "remarks")
            remarks_el.text = self.remarks

        # ── WHACO Governor Extension ──
        gov = ET.SubElement(detail, f"__{WHACO_NS}.governor")
        gov.set("mode", self.governor_mode)
        gov.set("modeId", str(self.governor_mode_id))
        gov.set("thrust", f"{self.thrust_frac:.3f}")
        gov.set("fuelRemaining", f"{self.fuel_remaining:.3f}")
        gov.set("fuelPressure", f"{self.fuel_pressure:.3f}")

        # ── WHACO Governance Extension ──
        governance = ET.SubElement(detail, f"__{WHACO_NS}.governance")
        governance.set("hierarchyRole", self.hierarchy_role)
        governance.set("tacticalRole", self.tactical_role)
        governance.set("posture", self.posture)
        governance.set("sectionId", str(self.section_id))

        # ── WHACO Resilience Extension ──
        resilience = ET.SubElement(detail, f"__{WHACO_NS}.resilience")
        resilience.set("asdpMode", self.asdp_mode)
        resilience.set("svi", f"{self.svi:.3f}")
        resilience.set("degradationLevel", str(self.degradation_level))

        # ── WHACO EW Extension ──
        ew = ET.SubElement(detail, f"__{WHACO_NS}.ew")
        ew.set("active", str(self.ew_active).lower())
        ew.set("role", self.ew_role)
        ew.set("radarDbm", f"{self.radar_dbm:.1f}")
        ew.set("scorchActive", str(self.scorch_active).lower())
        ew.set("cdoActive", str(self.cdo_active).lower())

        # ── WHACO Comms Extension ──
        comms = ET.SubElement(detail, f"__{WHACO_NS}.comms")
        comms.set("compromiseLevel", self.compromise_level)
        comms.set("linkState", self.link_state)

        return detail


@dataclass
class CoTEvent:
    """A complete Cursor-on-Target event message.

    This is the atomic unit of TAK communication. Each event describes
    a single entity (drone, threat, zone) at a point in time.
    """
    uid: str = field(default_factory=lambda: str(uuid.uuid4()))
    type: str = COT_TYPE_UAV_ROTARY
    how: str = "m-g"                   # machine-generated
    point: CoTPoint = field(default_factory=CoTPoint)
    detail: CoTDetail = field(default_factory=CoTDetail)

    time: Optional[datetime] = None
    start: Optional[datetime] = None
    stale: Optional[datetime] = None
    stale_seconds: float = DEFAULT_STALE_SECONDS

    def to_xml(self) -> ET.Element:
        now = self.time or datetime.now(timezone.utc)
        start = self.start or now
        stale = self.stale or datetime.fromtimestamp(
            now.timestamp() + self.stale_seconds, tz=timezone.utc
        )

        event = ET.Element("event")
        event.set("version", "2.0")
        event.set("uid", self.uid)
        event.set("type", self.type)
        event.set("how", self.how)
        event.set("time", _iso8601(now))
        event.set("start", _iso8601(start))
        event.set("stale", _iso8601(stale))

        event.append(self.point.to_xml())
        event.append(self.detail.to_xml())

        return event

    def to_xml_string(self) -> str:
        return ET.tostring(self.to_xml(), encoding="unicode", xml_declaration=False)

    def to_xml_bytes(self) -> bytes:
        return b'<?xml version="1.0" encoding="UTF-8"?>' + ET.tostring(
            self.to_xml(), encoding="unicode"
        ).encode("utf-8")


def _iso8601(dt: datetime) -> str:
    """Format datetime as CoT-compatible ISO 8601 with Z suffix."""
    return dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


# ── Swarm-level CoT events ──

@dataclass
class CoTSwarmStatus:
    """Aggregate swarm status as a CoT event attached to the commander's track."""
    total_agents: int = 0
    active_agents: int = 0
    posture: str = "NORMAL"
    asdp_mode: str = "NOMINAL"
    svi: float = 1.0
    mean_fuel: float = 0.0
    mean_lambda2: float = 0.0          # algebraic connectivity
    commander_uid: str = ""
    scorch_active: bool = False
    cdo_active: bool = False
    election_epoch: int = 0

    def to_xml(self) -> ET.Element:
        el = ET.Element(f"__{WHACO_NS}.swarm")
        el.set("totalAgents", str(self.total_agents))
        el.set("activeAgents", str(self.active_agents))
        el.set("posture", self.posture)
        el.set("asdpMode", self.asdp_mode)
        el.set("svi", f"{self.svi:.3f}")
        el.set("meanFuel", f"{self.mean_fuel:.3f}")
        el.set("meanLambda2", f"{self.mean_lambda2:.4f}")
        el.set("commanderUid", self.commander_uid)
        el.set("scorchActive", str(self.scorch_active).lower())
        el.set("cdoActive", str(self.cdo_active).lower())
        el.set("electionEpoch", str(self.election_epoch))
        return el


@dataclass
class CoTThreatTrack:
    """SCORCH threat feed as a CoT hostile track."""
    threat_id: str = ""
    threat_type: str = COT_TYPE_THREAT_EW
    lat: float = 0.0
    lon: float = 0.0
    hae: float = 0.0
    course: float = 0.0
    speed: float = 0.0
    classification: str = "UNKNOWN"    # RF_ACTIVE / IR_HEAT / DUAL_MODE / EW_EMITTER
    confidence: float = 0.0
    radar_dbm: float = -120.0
    intent: str = "unknown"            # patrol / pursuit / converging

    def to_cot_event(self) -> CoTEvent:
        return CoTEvent(
            uid=f"WHACO-THREAT-{self.threat_id}",
            type=self.threat_type,
            how="m-g",
            point=CoTPoint(lat=self.lat, lon=self.lon, hae=self.hae),
            detail=CoTDetail(
                callsign=f"THREAT-{self.threat_id}",
                team_color="Red",
                team_role="HQ",
                course=self.course,
                speed=self.speed,
                remarks=f"class={self.classification} conf={self.confidence:.2f} "
                        f"intent={self.intent} pwr={self.radar_dbm:.0f}dBm",
            ),
            stale_seconds=15.0,        # threats go stale faster
        )
