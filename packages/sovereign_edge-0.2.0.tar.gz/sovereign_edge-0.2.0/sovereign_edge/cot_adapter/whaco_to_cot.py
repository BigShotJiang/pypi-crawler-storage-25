"""
WHACO → Cursor-on-Target Bridge

Converts WHACO governor state, EW coordinator output, swarm governance,
and event log into CoT XML messages for TAK ecosystem consumption.

Architecture:
  WHACO Modules ──→ WHACOCoTBridge ──→ CoTEvent[] ──→ CoTMulticastServer ──→ TAK

The bridge runs at configurable rate (default 2 Hz — TAK tracks update
comfortably at 1-5 Hz; faster wastes bandwidth on mesh radios).

Coordinate transform:
  WHACO uses NED (North-East-Down) meters relative to a launch origin.
  CoT requires WGS-84 lat/lon/hae. The bridge applies a flat-earth
  approximation from a configurable origin point. For operational use,
  replace with proper geodetic transform (pyproj/GeographicLib).
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from sovereign_edge.cot_adapter.cot_types import (
    COT_TYPE_THREAT_AIR,
    COT_TYPE_THREAT_EW,
    COT_TYPE_THREAT_GND,
    COT_TYPE_UAV_ROTARY,
    CoTDetail,
    CoTEvent,
    CoTPoint,
    CoTSwarmStatus,
    CoTThreatTrack,
)


# Flat-earth conversion constants
METERS_PER_DEG_LAT = 111_320.0
METERS_PER_DEG_LON_AT_EQUATOR = 111_320.0


@dataclass
class GeoOrigin:
    """WGS-84 origin for NED → lat/lon conversion."""
    lat: float = 0.0                   # degrees
    lon: float = 0.0                   # degrees
    alt_msl: float = 0.0              # meters MSL

    def ned_to_wgs84(self, n: float, e: float, d: float) -> Tuple[float, float, float]:
        """Convert NED offset (meters) to WGS-84 (lat, lon, hae)."""
        lat = self.lat + n / METERS_PER_DEG_LAT
        lon_scale = METERS_PER_DEG_LON_AT_EQUATOR * math.cos(math.radians(self.lat))
        lon = self.lon + (e / lon_scale if lon_scale > 0 else 0.0)
        hae = self.alt_msl - d         # NED z-down → HAE z-up
        return lat, lon, hae


@dataclass
class BridgeConfig:
    """Configuration for the WHACO-to-CoT bridge."""
    origin: GeoOrigin = field(default_factory=GeoOrigin)
    callsign_prefix: str = "WHACO"
    update_rate_hz: float = 2.0
    stale_seconds: float = 30.0
    threat_stale_seconds: float = 15.0
    team_color: str = "Cyan"
    emit_swarm_status: bool = True
    emit_threats: bool = True
    emit_events: bool = True
    # NATO marking
    classification: str = "UNCLASSIFIED"
    releasability: str = "REL TO USA, FVEY"


class WHACOCoTBridge:
    """Converts WHACO swarm state into Cursor-on-Target events.

    Usage:
        bridge = WHACOCoTBridge(config)
        events = bridge.generate_events(
            agents=agent_states,
            hierarchy=hierarchy_state,
            ew_threats=ew_coordinator_output,
            resilience=resilience_state,
            event_log=recent_events,
        )
        for event in events:
            server.send(event)
    """

    def __init__(self, config: Optional[BridgeConfig] = None):
        self.config = config or BridgeConfig()
        self._agent_uids: Dict[int, str] = {}
        self._threat_uids: Dict[str, str] = {}
        self._seq = 0

    def _get_agent_uid(self, agent_id: int) -> str:
        if agent_id not in self._agent_uids:
            self._agent_uids[agent_id] = (
                f"{self.config.callsign_prefix}-{agent_id:03d}"
            )
        return self._agent_uids[agent_id]

    def _get_threat_uid(self, threat_id: str) -> str:
        if threat_id not in self._threat_uids:
            self._threat_uids[threat_id] = f"WHACO-THREAT-{threat_id}"
        return self._threat_uids[threat_id]

    def generate_events(
        self,
        agents: List[Dict[str, Any]],
        hierarchy: Optional[Dict[str, Any]] = None,
        ew_threats: Optional[Dict[int, Any]] = None,
        resilience: Optional[Dict[str, Any]] = None,
        threats: Optional[List[Dict[str, Any]]] = None,
        event_log: Optional[List[Dict[str, Any]]] = None,
    ) -> List[CoTEvent]:
        """Generate CoT events from current WHACO state.

        Args:
            agents: List of per-agent state dicts with keys:
                agent_id, pos (NED array), vel, fuel_remaining, fuel_pressure,
                governor_mode, governor_mode_id, thrust_frac, groundspeed,
                active, heading
            hierarchy: Swarm hierarchy dict with keys:
                roles, commander_idx, section_leads, sections, posture,
                election_epoch
            ew_threats: Dict of agent_id → EWThreat from EWCoordinator
            resilience: Resilience state dict with keys:
                asdp_mode, svi, degradation_level, scorch_active, cdo_active
            threats: List of detected threat dicts with keys:
                threat_id, pos, vel, classification, confidence, radar_dbm,
                intent
            event_log: Recent governance events for remarks injection

        Returns:
            List of CoTEvent objects ready for serialization and transmission.
        """
        self._seq += 1
        events: List[CoTEvent] = []
        hierarchy = hierarchy or {}
        resilience = resilience or {}
        ew_threats = ew_threats or {}

        # ── Per-agent tracks ──
        for agent in agents:
            aid = agent.get("agent_id", 0)
            pos = agent.get("pos", np.zeros(3))
            vel = agent.get("vel", np.zeros(3))

            lat, lon, hae = self.config.origin.ned_to_wgs84(
                pos[0], pos[1], pos[2]
            )

            # Compute course from velocity
            speed = float(np.linalg.norm(vel[:2]))
            course = float(np.degrees(np.arctan2(vel[1], vel[0]))) % 360.0

            # Fuel → battery percentage for standard TAK display
            fuel_rem = agent.get("fuel_remaining", 0.0)
            fuel_budget = agent.get("fuel_budget", 4.0)
            battery_pct = max(0, min(100, int(100 * fuel_rem / max(fuel_budget, 0.01))))

            # Hierarchy info
            roles = hierarchy.get("roles", {})
            sections = hierarchy.get("sections", {})
            hierarchy_role = roles.get(aid, "OPERATOR")
            section_id = -1
            for sid, members in sections.items():
                if aid in members or aid == sid:
                    section_id = sid
                    break

            # Tactical role (from doctrine if available)
            tactical_role = agent.get("tactical_role", "STANDARD")

            # EW state for this agent
            ew = ew_threats.get(aid)
            ew_active = getattr(ew, "ew_active", False) if ew else False
            ew_role = getattr(ew, "ew_role", "passive") if ew else "passive"
            radar_dbm = getattr(ew, "radar_dbm", -120.0) if ew else -120.0

            # Team role mapping for ATAK group display
            if hierarchy_role == "COMMANDER":
                team_role = "Team Lead"
            elif hierarchy_role == "SECTION_LEAD":
                team_role = "HQ"
            else:
                team_role = "Team Member"

            # Callsign
            callsign = f"{self.config.callsign_prefix}-{aid:02d}"
            if hierarchy_role == "COMMANDER":
                callsign += "-CMD"

            event = CoTEvent(
                uid=self._get_agent_uid(aid),
                type=COT_TYPE_UAV_ROTARY,
                how="m-g",
                point=CoTPoint(lat=lat, lon=lon, hae=hae, ce=5.0, le=10.0),
                detail=CoTDetail(
                    callsign=callsign,
                    team_color=self._posture_color(
                        hierarchy.get("posture", "NORMAL")
                    ),
                    team_role=team_role,
                    course=course,
                    speed=speed,
                    battery=battery_pct,
                    governor_mode=agent.get("governor_mode", "CRUISE"),
                    governor_mode_id=agent.get("governor_mode_id", 2),
                    thrust_frac=agent.get("thrust_frac", 0.55),
                    fuel_remaining=fuel_rem,
                    fuel_pressure=agent.get("fuel_pressure", 0.0),
                    hierarchy_role=hierarchy_role,
                    tactical_role=tactical_role,
                    posture=hierarchy.get("posture", "NORMAL"),
                    section_id=section_id,
                    asdp_mode=resilience.get("asdp_mode", "NOMINAL"),
                    svi=resilience.get("svi", 1.0),
                    degradation_level=resilience.get("degradation_level", 0),
                    ew_active=ew_active,
                    ew_role=ew_role,
                    radar_dbm=radar_dbm,
                    scorch_active=resilience.get("scorch_active", False),
                    cdo_active=resilience.get("cdo_active", False),
                    compromise_level=agent.get("compromise_level", "CLEAN"),
                    link_state=agent.get("link_state", "NORMAL"),
                ),
                stale_seconds=self.config.stale_seconds,
            )
            events.append(event)

        # ── Swarm status (attached to commander track) ──
        if self.config.emit_swarm_status and agents:
            commander_idx = hierarchy.get("commander_idx", 0)
            active_count = sum(1 for a in agents if a.get("active", True))
            mean_fuel = np.mean([a.get("fuel_remaining", 0) for a in agents])

            swarm_status = CoTSwarmStatus(
                total_agents=len(agents),
                active_agents=active_count,
                posture=hierarchy.get("posture", "NORMAL"),
                asdp_mode=resilience.get("asdp_mode", "NOMINAL"),
                svi=resilience.get("svi", 1.0),
                mean_fuel=float(mean_fuel),
                mean_lambda2=resilience.get("mean_lambda2", 0.0),
                commander_uid=self._get_agent_uid(commander_idx),
                scorch_active=resilience.get("scorch_active", False),
                cdo_active=resilience.get("cdo_active", False),
                election_epoch=hierarchy.get("election_epoch", 0),
            )
            # Inject swarm status into commander's detail block
            for ev in events:
                if ev.uid == self._get_agent_uid(commander_idx):
                    ev.detail.remarks = (
                        f"[SWARM] {active_count}/{len(agents)} active "
                        f"| {hierarchy.get('posture', 'NORMAL')} "
                        f"| SVI={resilience.get('svi', 1.0):.2f} "
                        f"| ASDP={resilience.get('asdp_mode', 'NOMINAL')}"
                    )
                    break

        # ── Threat tracks ──
        if self.config.emit_threats and threats:
            for threat in threats:
                tid = str(threat.get("threat_id", "UNK"))
                tpos = threat.get("pos", np.zeros(3))
                tvel = threat.get("vel", np.zeros(3))

                tlat, tlon, thae = self.config.origin.ned_to_wgs84(
                    tpos[0], tpos[1], tpos[2] if len(tpos) > 2 else 0.0
                )

                classification = threat.get("classification", "UNKNOWN")
                # Map classification to CoT type
                if classification in ("RF_ACTIVE", "EW_EMITTER"):
                    cot_type = COT_TYPE_THREAT_EW
                elif classification in ("IR_HEAT", "DUAL_MODE"):
                    cot_type = COT_TYPE_THREAT_AIR
                else:
                    cot_type = COT_TYPE_THREAT_AIR

                tspeed = float(np.linalg.norm(tvel[:2]))
                tcourse = float(np.degrees(np.arctan2(tvel[1], tvel[0]))) % 360.0

                threat_event = CoTEvent(
                    uid=self._get_threat_uid(tid),
                    type=cot_type,
                    how="m-g",
                    point=CoTPoint(lat=tlat, lon=tlon, hae=thae, ce=50.0, le=50.0),
                    detail=CoTDetail(
                        callsign=f"THREAT-{tid}",
                        team_color="Red",
                        team_role="HQ",
                        course=tcourse,
                        speed=tspeed,
                        remarks=(
                            f"class={classification} "
                            f"conf={threat.get('confidence', 0):.2f} "
                            f"intent={threat.get('intent', 'unknown')} "
                            f"pwr={threat.get('radar_dbm', -120):.0f}dBm"
                        ),
                    ),
                    stale_seconds=self.config.threat_stale_seconds,
                )
                events.append(threat_event)

        # ── Governance event annotations ──
        if self.config.emit_events and event_log:
            for ev in event_log[-10:]:  # Last 10 events max
                severity = ev.get("severity", "INFO")
                if severity in ("CRIT", "FATAL"):
                    agent_id = ev.get("agent_id", -1)
                    if agent_id >= 0:
                        uid = self._get_agent_uid(agent_id)
                        for cot_ev in events:
                            if cot_ev.uid == uid:
                                existing = cot_ev.detail.remarks
                                new_remark = (
                                    f"[{severity}] {ev.get('event_type', '')}: "
                                    f"{ev.get('reason', '')}"
                                )
                                cot_ev.detail.remarks = (
                                    f"{existing} | {new_remark}" if existing
                                    else new_remark
                                )
                                break

        return events

    def _posture_color(self, posture: str) -> str:
        """Map WHACO posture to ATAK team color for visual status."""
        return {
            "NORMAL": "Cyan",
            "DEFENSIVE": "Yellow",
            "SAFE_WITHDRAW": "Orange",
            "RETREAT": "Red",
        }.get(posture, "Cyan")

    def generate_containment_zone(
        self,
        center_ned: np.ndarray,
        radius_m: float,
        zone_type: str = "CASCADE",
    ) -> CoTEvent:
        """Generate a CoT drawing event for a containment/exclusion zone."""
        lat, lon, hae = self.config.origin.ned_to_wgs84(
            center_ned[0], center_ned[1],
            center_ned[2] if len(center_ned) > 2 else 0.0,
        )
        return CoTEvent(
            uid=f"WHACO-ZONE-{zone_type}-{self._seq}",
            type="u-d-c-c",  # drawing, circle
            how="m-g",
            point=CoTPoint(lat=lat, lon=lon, hae=hae),
            detail=CoTDetail(
                callsign=f"{zone_type} Zone",
                team_color="Red" if zone_type == "SCORCH" else "Orange",
                remarks=f"WHACO {zone_type} containment radius={radius_m:.0f}m",
            ),
            stale_seconds=60.0,
        )
