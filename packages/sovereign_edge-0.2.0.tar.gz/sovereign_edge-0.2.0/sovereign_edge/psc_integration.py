"""
SOVEREIGN EDGE × PSC Integration
=================================

Bridges the Pseudospectral Certification Engine (PSC) into the
SOVEREIGN EDGE governance loop. Provides:

1. Pre-mission certification — verify the governance operator's true
   robustness margin before launch (catches false viability)
2. Runtime drift monitoring — detect when the live governance operator
   has drifted toward the certified ε* boundary
3. CoT annotation — inject PSC verdicts into CoT events so operators
   see certification status on ATAK

The key insight: WHACO's 22-module authority stack produces a governance
operator (the authority matrix) at each tick. PSC certifies that this
operator's pseudospectral abscissa is below the stability threshold
even under adversarial perturbation. If spectral analysis says "stable"
but PSC says "false viability," the spectral analysis is wrong.

Usage:
    from sovereign_edge.psc_integration import GovernanceCertifier

    certifier = GovernanceCertifier(n_agents=20, adversary_budget=0.10)
    cert = certifier.certify_governance(adj_matrix)
    print(cert.verdict)  # CERTIFIED | AT_RISK | FALSE_VIABILITY

    # Runtime monitoring
    drift = certifier.check_drift(current_adj)
    if drift.severity == "CRIT":
        logger.critical("Governance drift at %.0f%% of ε*", drift.fraction * 100)
"""

from __future__ import annotations

import logging
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
from scipy import linalg

# PSC imports
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "psc"))
from psc_core import (
    spectral_abscissa,
    pseudospectral_abscissa,
    fragility_ratio,
    critical_eps,
    worst_case_perturbation,
    operator_hash,
)
from psc_adversaries import AdversaryClass
from psc_certificates import certify, Certificate

logger = logging.getLogger("sovereign_edge.psc")


@dataclass
class DriftReport:
    """Result of checking governance operator drift against certificate."""
    drift_norm: float = 0.0            # ‖A_current − A_certified‖₂
    epsilon_critical: float = 1.0      # ε* from certificate
    fraction: float = 0.0             # drift_norm / ε*
    severity: str = "OK"              # OK | WARN | CRIT
    spectral_abscissa: float = 0.0    # current α(A)
    message: str = ""

    def to_cot_remark(self) -> str:
        """Format as a CoT remarks string."""
        if self.severity == "OK":
            return f"[PSC] OK drift={self.fraction:.0%} of ε*"
        elif self.severity == "WARN":
            return f"[PSC] WARN drift={self.fraction:.0%} of ε* ({self.drift_norm:.4f})"
        else:
            return (f"[PSC] CRIT drift={self.fraction:.0%} of ε* — "
                    f"governance operator near destabilization boundary")


class GovernanceCertifier:
    """Certifies and monitors WHACO governance operators via PSC.

    Extracts the effective governance operator from the swarm's adjacency
    matrix and authority weights, then certifies its pseudospectral
    robustness against a specified adversary class.

    The governance operator A is constructed from:
      - Adjacency matrix (NxN, symmetric for comms connectivity)
      - Authority weights (diagonal, from hierarchy roles)
      - Inter-layer coupling (asymmetric, from module authority tiers)

    For the AT27 submission, the key result is:
      - Spectral analysis says: margin = |α(A)|
      - PSC says: true margin = ε* (often 30-60% less)
      - The difference is the "false viability gap"
    """

    def __init__(
        self,
        n_agents: int = 20,
        adversary_budget: float = 0.10,
        adversary_norm: str = "2",
        stability_threshold: float = 0.0,
        warn_at_fraction: float = 0.75,
        crit_at_fraction: float = 0.95,
    ):
        self.n_agents = n_agents
        self.adversary = AdversaryClass(
            norm=adversary_norm,
            bound=adversary_budget,
        )
        self.stability_threshold = stability_threshold
        self.warn_fraction = warn_at_fraction
        self.crit_fraction = crit_at_fraction

        self._certified_operator: Optional[np.ndarray] = None
        self._certificate: Optional[Certificate] = None
        self._epsilon_critical: float = 1.0

    @property
    def certificate(self) -> Optional[Certificate]:
        return self._certificate

    @property
    def is_certified(self) -> bool:
        return self._certificate is not None

    def build_governance_operator(
        self,
        adjacency: np.ndarray,
        hierarchy_weights: Optional[Dict[int, float]] = None,
        authority_asymmetry: float = 0.3,
    ) -> np.ndarray:
        """Build the effective governance operator from swarm state.

        The governance operator captures how information and authority
        flow through the swarm. Non-Hermitian structure arises naturally
        from asymmetric authority relationships (commander → operator
        has more weight than operator → commander).

        Args:
            adjacency: NxN symmetric connectivity matrix
            hierarchy_weights: agent_id → authority weight (higher = more authority)
            authority_asymmetry: α parameter controlling non-Hermiticity
                0.0 = symmetric (Hermitian, no false viability possible)
                1.0 = maximally asymmetric (worst-case false viability)

        Returns:
            NxN governance operator (generally non-Hermitian)
        """
        N = adjacency.shape[0]

        # Start with Laplacian (symmetric)
        degree = np.sum(adjacency, axis=1)
        laplacian = np.diag(degree) - adjacency

        # Apply authority asymmetry — higher-authority agents
        # have stronger influence on lower-authority agents
        if hierarchy_weights:
            for i in range(N):
                for j in range(N):
                    if adjacency[i, j] > 0:
                        wi = hierarchy_weights.get(i, 1.0)
                        wj = hierarchy_weights.get(j, 1.0)
                        # Asymmetric coupling: authority flows downhill
                        if wi > wj:
                            laplacian[i, j] *= (1 + authority_asymmetry)
                            laplacian[j, i] *= (1 - authority_asymmetry)

        # Stabilizing shift — put spectrum in left half-plane
        alpha = spectral_abscissa(-laplacian)
        shift = alpha + 1.0  # ensure margin of at least 1.0
        A = -laplacian - shift * np.eye(N)

        return A

    def certify_governance(
        self,
        adjacency: np.ndarray,
        hierarchy_weights: Optional[Dict[int, float]] = None,
        authority_asymmetry: float = 0.3,
        operator_id: str = "WHACO-GOV",
    ) -> Certificate:
        """Certify the current governance operator.

        This is the pre-mission gate. Run before launch to verify
        that the governance operator's true robustness margin
        (pseudospectral, not spectral) exceeds the adversary budget.

        Returns a signed Certificate with verdict.
        """
        A = self.build_governance_operator(
            adjacency, hierarchy_weights, authority_asymmetry
        )

        t0 = time.perf_counter()

        cert = certify(
            operator=A,
            adversary=self.adversary,
            operator_id=operator_id,
            stability_threshold=self.stability_threshold,
        )

        elapsed = time.perf_counter() - t0

        # Cache for drift monitoring
        self._certified_operator = A.copy()
        self._certificate = cert
        self._epsilon_critical = cert.epsilon_critical

        logger.info(
            "PSC Certification complete in %.2fs: verdict=%s "
            "α(A)=%.4f α_ε(A)=%.4f fragility=%.2f× ε*=%.4f",
            elapsed, cert.verdict,
            cert.spectral_abscissa, cert.pseudospectral_abscissa,
            cert.fragility_ratio, cert.epsilon_critical,
        )

        if cert.verdict == "FALSE_VIABILITY":
            logger.critical(
                "PSC FALSE VIABILITY: governance operator has fragility %.1f× — "
                "spectral analysis is catastrophically wrong. "
                "True robustness margin is %.0f%% of spectral prediction.",
                cert.fragility_ratio,
                cert.epsilon_critical / max(abs(cert.spectral_abscissa), 1e-10) * 100,
            )

        return cert

    def check_drift(
        self,
        adjacency: np.ndarray,
        hierarchy_weights: Optional[Dict[int, float]] = None,
        authority_asymmetry: float = 0.3,
    ) -> DriftReport:
        """Check if the current governance operator has drifted from certified state.

        Called every tick (or every N ticks for performance) to detect
        when the live operator approaches the ε* boundary.
        """
        if self._certified_operator is None:
            return DriftReport(severity="OK", message="Not yet certified")

        A_current = self.build_governance_operator(
            adjacency, hierarchy_weights, authority_asymmetry
        )

        drift_norm = float(linalg.norm(A_current - self._certified_operator, 2))
        fraction = drift_norm / max(self._epsilon_critical, 1e-10)
        alpha_current = float(spectral_abscissa(A_current))

        if fraction >= self.crit_fraction:
            severity = "CRIT"
            message = (
                f"Governance operator drift at {fraction:.0%} of ε* — "
                f"approaching destabilization boundary"
            )
        elif fraction >= self.warn_fraction:
            severity = "WARN"
            message = f"Governance drift at {fraction:.0%} of ε*"
        else:
            severity = "OK"
            message = f"Governance drift nominal at {fraction:.0%} of ε*"

        return DriftReport(
            drift_norm=drift_norm,
            epsilon_critical=self._epsilon_critical,
            fraction=fraction,
            severity=severity,
            spectral_abscissa=alpha_current,
            message=message,
        )

    def get_cot_annotation(self) -> Dict[str, Any]:
        """Get PSC state as a dict suitable for CoT detail injection."""
        if self._certificate is None:
            return {"psc_status": "uncertified"}

        return {
            "psc_status": self._certificate.verdict,
            "psc_fragility": round(self._certificate.fragility_ratio, 2),
            "psc_epsilon_critical": round(self._epsilon_critical, 4),
            "psc_spectral_abscissa": round(self._certificate.spectral_abscissa, 4),
            "psc_pseudospectral_abscissa": round(
                self._certificate.pseudospectral_abscissa, 4
            ),
        }
