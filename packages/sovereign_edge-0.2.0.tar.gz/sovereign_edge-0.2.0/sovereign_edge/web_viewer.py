#!/usr/bin/env python3
"""
SOVEREIGN EDGE — Web-Based CoT Track Viewer

Lightweight map viewer that displays WHACO swarm tracks in real-time.
Serves a Leaflet.js map and streams CoT events via Server-Sent Events (SSE).

No installation required — evaluators just open a browser.

Usage:
    # Terminal 1: Start the viewer
    python3 -m sovereign_edge.web_viewer --port 8080

    # Terminal 2: Run the demo (with web viewer integration)
    python3 -m sovereign_edge.gateway --mode doomsday --fast --transport file \\
        --output-file /tmp/sovereign_edge_cot.xml

    # Or combined: run demo with built-in web viewer
    python3 -m sovereign_edge.web_viewer --port 8080 --run-demo doomsday

Architecture:
    web_viewer.py starts an HTTP server that:
    1. Serves the Leaflet.js map page at /
    2. Tails the CoT XML file and streams parsed events via SSE at /events
    3. Provides a JSON API at /state for the current swarm state snapshot
"""

from __future__ import annotations

import argparse
import http.server
import json
import logging
import os
import re
import sys
import threading
import time
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

logger = logging.getLogger("sovereign_edge.web_viewer")

# ── Current swarm state (updated by file tailer) ──
_state_lock = threading.Lock()
_current_state: Dict[str, dict] = {}  # uid → parsed agent state
_event_queue: List[str] = []          # SSE events waiting to be sent
_stats = {"events_parsed": 0, "last_update": 0.0}


def parse_cot_event(xml_str: str) -> Optional[dict]:
    """Parse a CoT XML event string into a dict for the web viewer."""
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return None

    uid = root.get("uid", "")
    cot_type = root.get("type", "")

    point = root.find("point")
    if point is None:
        return None

    lat = float(point.get("lat", "0"))
    lon = float(point.get("lon", "0"))
    hae = float(point.get("hae", "0"))

    detail = root.find("detail")
    if detail is None:
        return {"uid": uid, "type": cot_type, "lat": lat, "lon": lon, "hae": hae}

    # Standard fields
    contact = detail.find("contact")
    callsign = contact.get("callsign", uid) if contact is not None else uid

    group = detail.find("__group")
    team_color = group.get("name", "Cyan") if group is not None else "Cyan"

    track = detail.find("track")
    course = float(track.get("course", "0")) if track is not None else 0
    speed = float(track.get("speed", "0")) if track is not None else 0

    status = detail.find("status")
    battery = int(status.get("battery", "100")) if status is not None else 100

    remarks_el = detail.find("remarks")
    remarks = remarks_el.text if remarks_el is not None and remarks_el.text else ""

    # WHACO extensions
    gov = detail.find("__com.blackridge.whaco.governor")
    governance = detail.find("__com.blackridge.whaco.governance")
    resilience = detail.find("__com.blackridge.whaco.resilience")
    ew = detail.find("__com.blackridge.whaco.ew")

    result = {
        "uid": uid,
        "type": cot_type,
        "lat": lat,
        "lon": lon,
        "hae": hae,
        "callsign": callsign,
        "teamColor": team_color,
        "course": course,
        "speed": speed,
        "battery": battery,
        "remarks": remarks,
        "hostile": cot_type.startswith("a-h"),
        "timestamp": root.get("time", ""),
    }

    if gov is not None:
        result["governorMode"] = gov.get("mode", "")
        result["thrust"] = float(gov.get("thrust", "0"))
        result["fuelRemaining"] = float(gov.get("fuelRemaining", "0"))
        result["fuelPressure"] = float(gov.get("fuelPressure", "0"))

    if governance is not None:
        result["hierarchyRole"] = governance.get("hierarchyRole", "")
        result["tacticalRole"] = governance.get("tacticalRole", "")
        result["posture"] = governance.get("posture", "")
        result["sectionId"] = governance.get("sectionId", "-1")

    if resilience is not None:
        result["asdpMode"] = resilience.get("asdpMode", "")
        result["svi"] = float(resilience.get("svi", "1"))
        result["degradationLevel"] = resilience.get("degradationLevel", "0")

    if ew is not None:
        result["ewActive"] = ew.get("active", "false") == "true"
        result["scorchActive"] = ew.get("scorchActive", "false") == "true"

    return result


def tail_cot_file(filepath: str, stop_event: threading.Event):
    """Tail a CoT XML file and update the global state."""
    logger.info("Tailing CoT file: %s", filepath)
    last_pos = 0
    buffer = ""

    while not stop_event.is_set():
        try:
            if not os.path.exists(filepath):
                time.sleep(0.5)
                continue

            with open(filepath, "r") as f:
                f.seek(last_pos)
                new_data = f.read()
                last_pos = f.tell()

            if not new_data:
                time.sleep(0.2)
                continue

            buffer += new_data

            # Extract complete <event>...</event> blocks
            pattern = r'<event\s[^>]*>.*?</event>'
            for match in re.finditer(pattern, buffer, re.DOTALL):
                xml_str = match.group(0)
                parsed = parse_cot_event(xml_str)
                if parsed:
                    with _state_lock:
                        _current_state[parsed["uid"]] = parsed
                        _event_queue.append(json.dumps(parsed))
                        _stats["events_parsed"] += 1
                        _stats["last_update"] = time.time()

            # Keep unmatched tail in buffer
            last_match_end = 0
            for match in re.finditer(pattern, buffer, re.DOTALL):
                last_match_end = match.end()
            buffer = buffer[last_match_end:]

        except Exception as e:
            logger.error("Tail error: %s", e)
            time.sleep(1.0)


# ── HTML page ──

MAP_HTML = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SOVEREIGN EDGE — Command Dashboard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
<style>
:root {
  --bg-primary: #0b0e14;
  --bg-panel: rgba(13,17,23,0.92);
  --bg-card: rgba(22,27,34,0.85);
  --border: rgba(48,54,61,0.6);
  --border-hl: rgba(0,200,220,0.35);
  --text-primary: #e6edf3;
  --text-secondary: #8b949e;
  --text-dim: #484f58;
  --accent: #00c8dc;
  --accent-glow: rgba(0,200,220,0.15);
  --green: #3fb950;
  --yellow: #d29922;
  --orange: #db6d28;
  --red: #f85149;
  --purple: #a371f7;
  --blue: #58a6ff;
  --font-mono: 'SF Mono','Cascadia Code','JetBrains Mono','Fira Code',monospace;
  --font-ui: -apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;
  --radius: 8px;
}
*{margin:0;padding:0;box-sizing:border-box;}
html,body{height:100%;overflow:hidden;background:var(--bg-primary);color:var(--text-primary);}

/* ── LAYOUT GRID ── */
.app{display:grid;height:100vh;
  grid-template-columns:320px 1fr;
  grid-template-rows:48px 1fr 44px;
  grid-template-areas:"hdr hdr" "side map" "bar bar";
}

/* ── TOP BAR ── */
.topbar{grid-area:hdr;background:var(--bg-panel);border-bottom:1px solid var(--border);
  display:flex;align-items:center;justify-content:space-between;padding:0 20px;
  backdrop-filter:blur(12px);z-index:100;}
.topbar-brand{display:flex;align-items:center;gap:12px;}
.topbar-logo{width:28px;height:28px;border-radius:6px;background:linear-gradient(135deg,var(--accent),#0066cc);
  display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;color:#fff;
  font-family:var(--font-ui);box-shadow:0 0 12px var(--accent-glow);}
.topbar-title{font-family:var(--font-ui);font-size:15px;font-weight:700;letter-spacing:1.5px;
  background:linear-gradient(90deg,var(--accent),#fff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;}
.topbar-sub{font-family:var(--font-ui);font-size:11px;color:var(--text-secondary);font-weight:500;letter-spacing:0.5px;}
.topbar-right{display:flex;align-items:center;gap:16px;}
.topbar-class{font-family:var(--font-mono);font-size:10px;color:var(--green);letter-spacing:1px;
  padding:3px 10px;border:1px solid rgba(63,185,80,0.3);border-radius:4px;background:rgba(63,185,80,0.08);}
.topbar-status{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text-secondary);font-family:var(--font-mono);}
.pulse{width:8px;height:8px;border-radius:50%;background:var(--green);
  animation:pulse 2s infinite;box-shadow:0 0 6px var(--green);}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1);}50%{opacity:.6;transform:scale(1.3);}}

/* ── LEFT PANEL ── */
.sidebar{grid-area:side;background:var(--bg-panel);border-right:1px solid var(--border);
  overflow-y:auto;backdrop-filter:blur(12px);display:flex;flex-direction:column;}
.sidebar::-webkit-scrollbar{width:4px;}
.sidebar::-webkit-scrollbar-thumb{background:var(--border);border-radius:2px;}

.panel-section{padding:12px 16px;border-bottom:1px solid var(--border);}
.panel-label{font-family:var(--font-ui);font-size:10px;font-weight:600;color:var(--text-dim);
  letter-spacing:1.5px;text-transform:uppercase;margin-bottom:8px;}
.metric-grid{display:grid;grid-template-columns:1fr 1fr;gap:6px;}
.metric{background:var(--bg-card);border-radius:var(--radius);padding:10px 12px;border:1px solid var(--border);
  transition:border-color 0.3s;}
.metric:hover{border-color:var(--border-hl);}
.metric-val{font-family:var(--font-mono);font-size:20px;font-weight:700;line-height:1.1;}
.metric-lbl{font-family:var(--font-ui);font-size:10px;color:var(--text-secondary);margin-top:2px;letter-spacing:0.5px;}
.metric-val.green{color:var(--green);}
.metric-val.yellow{color:var(--yellow);}
.metric-val.orange{color:var(--orange);}
.metric-val.red{color:var(--red);}
.metric-val.accent{color:var(--accent);}

/* SVI gauge */
.gauge-track{height:6px;background:rgba(255,255,255,0.06);border-radius:3px;margin-top:6px;overflow:hidden;}
.gauge-fill{height:100%;border-radius:3px;transition:width 0.5s ease,background 0.5s ease;}

/* Agent list */
.agent-list{flex:1;overflow-y:auto;padding:0;}
.agent-row{display:grid;grid-template-columns:28px 1fr 50px 50px;align-items:center;gap:8px;
  padding:8px 16px;border-bottom:1px solid rgba(48,54,61,0.3);cursor:pointer;
  transition:background 0.15s;}
.agent-row:hover{background:rgba(0,200,220,0.06);}
.agent-row.dead{opacity:0.3;}
.agent-dot{width:10px;height:10px;border-radius:50%;border:2px solid rgba(255,255,255,0.3);
  box-shadow:0 0 6px currentColor;transition:all 0.3s;}
.agent-name{font-family:var(--font-mono);font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;}
.agent-role{font-size:9px;color:var(--text-secondary);font-family:var(--font-ui);}
.agent-mode{font-family:var(--font-mono);font-size:10px;text-align:right;}
.agent-fuel-bar{height:3px;background:rgba(255,255,255,0.06);border-radius:2px;margin-top:2px;}
.agent-fuel-fill{height:100%;border-radius:2px;transition:width 0.3s;}

/* ── MAP ── */
.map-container{grid-area:map;position:relative;}
#map{width:100%;height:100%;}
.leaflet-container{background:var(--bg-primary)!important;}

/* ── BOTTOM BAR ── */
.bottombar{grid-area:bar;background:var(--bg-panel);border-top:1px solid var(--border);
  display:flex;align-items:center;padding:0 16px;gap:8px;overflow-x:auto;
  backdrop-filter:blur(12px);}
.event-chip{font-family:var(--font-mono);font-size:10px;padding:4px 10px;border-radius:4px;
  white-space:nowrap;flex-shrink:0;border:1px solid var(--border);background:var(--bg-card);
  transition:all 0.3s;}
.event-chip.info{color:var(--text-secondary);}
.event-chip.warn{color:var(--yellow);border-color:rgba(210,153,34,0.3);background:rgba(210,153,34,0.06);}
.event-chip.crit{color:var(--red);border-color:rgba(248,81,73,0.3);background:rgba(248,81,73,0.08);
  animation:chipPulse 1.5s ease infinite;}
@keyframes chipPulse{0%,100%{opacity:1;}50%{opacity:.7;}}

/* ── MAP OVERLAY PANELS ── */
.map-overlay{position:absolute;top:12px;right:12px;z-index:1000;display:flex;flex-direction:column;gap:8px;}
.overlay-card{background:var(--bg-panel);border:1px solid var(--border);border-radius:var(--radius);
  padding:12px 16px;backdrop-filter:blur(16px);min-width:200px;}
.overlay-title{font-family:var(--font-ui);font-size:10px;font-weight:600;color:var(--text-dim);
  letter-spacing:1.5px;text-transform:uppercase;margin-bottom:6px;}
.overlay-row{display:flex;justify-content:space-between;align-items:center;padding:2px 0;}
.overlay-lbl{font-family:var(--font-ui);font-size:11px;color:var(--text-secondary);}
.overlay-val{font-family:var(--font-mono);font-size:12px;font-weight:600;}

/* Threat indicator */
.threat-badge{position:absolute;top:12px;left:340px;z-index:1000;display:none;
  background:rgba(248,81,73,0.12);border:1px solid rgba(248,81,73,0.4);border-radius:var(--radius);
  padding:8px 16px;backdrop-filter:blur(16px);color:var(--red);
  font-family:var(--font-mono);font-size:12px;animation:chipPulse 1s ease infinite;}

/* Agent detail flyout */
.detail-panel{position:absolute;bottom:52px;right:12px;z-index:1000;
  background:var(--bg-panel);border:1px solid var(--border-hl);border-radius:var(--radius);
  padding:16px 20px;backdrop-filter:blur(16px);width:280px;display:none;}
.detail-panel.show{display:block;}
.detail-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;}
.detail-name{font-family:var(--font-mono);font-size:16px;font-weight:700;color:var(--accent);}
.detail-close{cursor:pointer;color:var(--text-dim);font-size:18px;}
.detail-row{display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(48,54,61,0.2);}
.detail-lbl{font-family:var(--font-ui);font-size:11px;color:var(--text-secondary);}
.detail-val{font-family:var(--font-mono);font-size:12px;font-weight:600;}

/* Leaflet popup override */
.leaflet-popup-content-wrapper{background:var(--bg-panel)!important;color:var(--text-primary)!important;
  border:1px solid var(--border-hl)!important;border-radius:var(--radius)!important;
  backdrop-filter:blur(12px);box-shadow:0 8px 32px rgba(0,0,0,0.5)!important;}
.leaflet-popup-tip{background:var(--bg-panel)!important;border:1px solid var(--border)!important;}
.leaflet-popup-close-button{color:var(--text-dim)!important;}
</style>
</head>
<body>
<div class="app">
  <!-- TOP BAR -->
  <header class="topbar">
    <div class="topbar-brand">
      <div class="topbar-logo">SE</div>
      <div>
        <div class="topbar-title">SOVEREIGN EDGE</div>
        <div class="topbar-sub">Blackridge Autonomy — Command Dashboard</div>
      </div>
    </div>
    <div class="topbar-right">
      <div class="topbar-status"><div class="pulse" id="pulse-dot"></div><span id="conn-status">CONNECTED</span></div>
      <div class="topbar-class">UNCLASSIFIED // REL TO USA, FVEY</div>
    </div>
  </header>

  <!-- LEFT PANEL -->
  <aside class="sidebar">
    <div class="panel-section">
      <div class="panel-label">Swarm Status</div>
      <div class="metric-grid">
        <div class="metric"><div class="metric-val accent" id="m-agents">—</div><div class="metric-lbl">Agents Active</div></div>
        <div class="metric"><div class="metric-val" id="m-posture">—</div><div class="metric-lbl">Posture</div></div>
        <div class="metric"><div class="metric-val" id="m-cmd">—</div><div class="metric-lbl">Commander</div></div>
        <div class="metric"><div class="metric-val" id="m-deg">—</div><div class="metric-lbl">Degradation</div></div>
      </div>
    </div>
    <div class="panel-section">
      <div class="panel-label">Survival Viability Index</div>
      <div style="display:flex;justify-content:space-between;align-items:baseline;">
        <div class="metric-val accent" id="m-svi" style="font-size:28px;">—</div>
        <div id="m-asdp" style="font-family:var(--font-mono);font-size:12px;color:var(--green);">NOMINAL</div>
      </div>
      <div class="gauge-track"><div class="gauge-fill" id="svi-gauge" style="width:100%;background:var(--green);"></div></div>
    </div>
    <div class="panel-section" style="padding-bottom:6px;">
      <div class="panel-label">Formation</div>
    </div>
    <div class="agent-list" id="agent-list"></div>
  </aside>

  <!-- MAP -->
  <div class="map-container">
    <div id="map"></div>
    <div class="map-overlay">
      <div class="overlay-card" id="psc-card" style="display:none;">
        <div class="overlay-title">PSC Certification</div>
        <div class="overlay-row"><span class="overlay-lbl">Verdict</span><span class="overlay-val" id="psc-verdict">—</span></div>
        <div class="overlay-row"><span class="overlay-lbl">Fragility</span><span class="overlay-val" id="psc-frag">—</span></div>
        <div class="overlay-row"><span class="overlay-lbl">Critical &epsilon;</span><span class="overlay-val" id="psc-eps">—</span></div>
      </div>
      <div class="overlay-card">
        <div class="overlay-title">Threats</div>
        <div id="threat-count" style="font-family:var(--font-mono);font-size:14px;font-weight:600;">0 tracked</div>
      </div>
    </div>
    <div class="threat-badge" id="threat-badge">THREAT CONTACT</div>
    <div class="detail-panel" id="detail-panel">
      <div class="detail-header">
        <div class="detail-name" id="det-name">—</div>
        <div class="detail-close" onclick="document.getElementById('detail-panel').classList.remove('show');">&times;</div>
      </div>
      <div id="det-body"></div>
    </div>
  </div>

  <!-- BOTTOM BAR -->
  <footer class="bottombar" id="event-bar"></footer>
</div>

<script>
const map=L.map('map',{zoomControl:false,attributionControl:false}).setView([35.0,-79.0],16);
L.control.zoom({position:'bottomright'}).addTo(map);
L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',{maxZoom:20}).addTo(map);

const markers={},trails={};
let eventCount=0,fitted=false,selectedUid=null;
const MC={RIDE:'#00c8c8',SPRINT:'#ff8c00',CRUISE:'#00ddee',CONSERVE:'#d29922',PUNCH:'#f85149',
  BOOST:'#db6d28',BRAKE:'#6e7681',STABILIZE:'#58a6ff',CLOAK:'#a371f7',GHOST:'#f778ba',SCUTTLE:'#484f58','':'#8b949e'};
const AC={ASDP_NOMINAL:'#3fb950',ASDP_RECOVER:'#d29922',ASDP_ISOLATE:'#db6d28',
  ASDP_ASSIST:'#db6d28',ASDP_DENY_LOGICAL:'#f85149',ASDP_DISPERSE:'#f85149',NOMINAL:'#3fb950','':'#3fb950'};

function mkIcon(d){
  const c=d.hostile?'#f85149':(MC[d.governorMode]||'#00ddee');
  const sz=d.hostile?10:(d.hierarchyRole==='COMMANDER'?14:d.hierarchyRole==='SECTION_LEAD'?11:8);
  const ring=d.hierarchyRole==='COMMANDER'?'box-shadow:0 0 0 3px rgba(0,200,220,0.4),0 0 16px '+c:
    d.hierarchyRole==='SECTION_LEAD'?'box-shadow:0 0 0 2px rgba(163,113,247,0.3),0 0 10px '+c:
    'box-shadow:0 0 8px '+c;
  const badge=d.hierarchyRole==='COMMANDER'?'&#9733;':d.hierarchyRole==='SECTION_LEAD'?'&#9670;':'';
  return L.divIcon({className:'',iconSize:[sz+8,sz+20],iconAnchor:[(sz+8)/2,(sz+20)/2],
    html:`<div style="width:${sz}px;height:${sz}px;border-radius:50%;background:${c};
      border:2px solid rgba(255,255,255,${d.hostile?.5:.25});${ring};
      opacity:${d.scorchActive?.4:1};transition:all .3s;"></div>
      ${badge?`<div style="color:${d.hostile?'#f85149':'#fff'};font-size:9px;text-align:center;
        margin-top:-1px;text-shadow:0 1px 4px #000;font-weight:700;">${badge}</div>`:''}`});
}

function mkPopup(d){
  const r=(l,v,c)=>`<div style="display:flex;justify-content:space-between;padding:3px 0;
    border-bottom:1px solid rgba(48,54,61,0.2);"><span style="font-size:11px;color:var(--text-secondary);
    font-family:var(--font-ui);">${l}</span><span style="font-size:12px;font-weight:600;
    font-family:var(--font-mono);color:${c||'#e6edf3'};">${v}</span></div>`;
  const mc=MC[d.governorMode]||'#8b949e';
  return `<div style="font-family:var(--font-ui);min-width:200px;">
    <div style="font-size:15px;font-weight:700;color:var(--accent);margin-bottom:8px;
      font-family:var(--font-mono);">${d.callsign}</div>
    ${r('Governor',d.governorMode||'—',mc)}
    ${r('Thrust',((d.thrust||0)*100).toFixed(0)+'%')}
    ${r('Fuel',d.fuelRemaining?.toFixed(1)||'—')}
    ${r('Pressure',((d.fuelPressure||0)*100).toFixed(0)+'%',d.fuelPressure>.7?'#f85149':d.fuelPressure>.4?'#d29922':'')}
    ${r('Role',d.hierarchyRole||'—')}
    ${r('Tactical',d.tacticalRole||'—')}
    ${r('ASDP',(d.asdpMode||'').replace('ASDP_',''),AC[d.asdpMode]||'')}
    ${r('SVI',(d.svi||1).toFixed(2))}
    ${d.remarks?`<div style="margin-top:6px;padding:6px 8px;background:rgba(0,200,220,0.06);
      border-radius:4px;font-size:10px;font-family:var(--font-mono);color:var(--text-secondary);
      border-left:2px solid var(--accent);">${d.remarks}</div>`:''}</div>`;
}

function updAgent(d){
  const uid=d.uid,ll=[d.lat,d.lon];
  if(markers[uid]){markers[uid].setLatLng(ll);markers[uid].setIcon(mkIcon(d));markers[uid].setPopupContent(mkPopup(d));}
  else{const m=L.marker(ll,{icon:mkIcon(d)}).addTo(map);m.bindPopup(mkPopup(d),{maxWidth:260});
    m.on('click',()=>showDetail(d));markers[uid]=m;}
  if(!trails[uid])trails[uid]=L.polyline([],{color:d.hostile?'rgba(248,81,73,0.25)':'rgba(0,200,220,0.15)',weight:1.5,
    dashArray:d.hostile?'4,4':null}).addTo(map);
  const pts=trails[uid].getLatLngs();pts.push(ll);if(pts.length>120)pts.shift();trails[uid].setLatLngs(pts);
}

function showDetail(d){
  const p=document.getElementById('detail-panel'),b=document.getElementById('det-body');
  document.getElementById('det-name').textContent=d.callsign;
  const r=(l,v)=>`<div class="detail-row"><span class="detail-lbl">${l}</span><span class="detail-val">${v}</span></div>`;
  b.innerHTML=r('Mode',d.governorMode||'—')+r('Thrust',((d.thrust||0)*100).toFixed(0)+'%')+
    r('Fuel',d.fuelRemaining?.toFixed(2)||'—')+r('Fuel Pressure',((d.fuelPressure||0)*100).toFixed(0)+'%')+
    r('Hierarchy',d.hierarchyRole||'—')+r('Tactical',d.tacticalRole||'—')+
    r('Section',d.sectionId||'—')+r('ASDP',(d.asdpMode||'').replace('ASDP_',''))+
    r('SVI',(d.svi||1).toFixed(3))+r('Speed',d.speed?.toFixed(1)+' m/s'||'—')+
    r('Course',d.course?.toFixed(0)+'°'||'—');
  p.classList.add('show');selectedUid=d.uid;
}

function updSidebar(agents){
  const list=document.getElementById('agent-list');
  const friendly=Object.values(agents).filter(a=>!a.hostile).sort((a,b)=>{
    const ro={COMMANDER:0,SECTION_LEAD:1,OPERATOR:2};return(ro[a.hierarchyRole]||9)-(ro[b.hierarchyRole]||9);});
  const hostile=Object.values(agents).filter(a=>a.hostile);

  let html='';
  friendly.forEach(d=>{
    const c=MC[d.governorMode]||'#8b949e';
    const badge=d.hierarchyRole==='COMMANDER'?'<span style="color:var(--accent);margin-left:4px;">&#9733;</span>':
      d.hierarchyRole==='SECTION_LEAD'?'<span style="color:var(--purple);margin-left:4px;">&#9670;</span>':'';
    const fp=d.fuelPressure||0;const fc=fp>.7?'var(--red)':fp>.4?'var(--yellow)':'var(--green)';
    html+=`<div class="agent-row" onclick="map.setView([${d.lat},${d.lon}],17);">
      <div class="agent-dot" style="color:${c};background:${c};"></div>
      <div><div class="agent-name">${d.callsign}${badge}</div>
        <div class="agent-role">${d.hierarchyRole||'OPERATOR'} &middot; ${d.tacticalRole||'STD'}</div></div>
      <div class="agent-mode" style="color:${c};">${(d.governorMode||'—').substr(0,5)}</div>
      <div><div style="font-family:var(--font-mono);font-size:10px;text-align:right;color:${fc};">
        ${((1-(d.fuelPressure||0))*100).toFixed(0)}%</div>
        <div class="agent-fuel-bar"><div class="agent-fuel-fill" style="width:${(1-fp)*100}%;background:${fc};"></div></div></div>
    </div>`;
  });
  if(hostile.length){
    html+=`<div style="padding:8px 16px;border-bottom:1px solid var(--border);"><div class="panel-label" style="margin:0;color:var(--red);">Threats (${hostile.length})</div></div>`;
    hostile.forEach(d=>{
      html+=`<div class="agent-row" onclick="map.setView([${d.lat},${d.lon}],17);">
        <div class="agent-dot" style="color:var(--red);background:var(--red);"></div>
        <div><div class="agent-name" style="color:var(--red);">${d.callsign}</div>
          <div class="agent-role">${d.remarks?.substr(0,40)||'HOSTILE'}</div></div>
        <div></div><div></div></div>`;
    });
  }
  list.innerHTML=html;
}

function updMetrics(agents){
  const fr=Object.values(agents).filter(a=>!a.hostile);
  const ht=Object.values(agents).filter(a=>a.hostile);
  const n=fr.length,total=20;
  const cmd=fr.find(a=>a.hierarchyRole==='COMMANDER');
  const p=fr[0]?.posture||'—',asdp=fr[0]?.asdpMode||'',svi=fr[0]?.svi||1;
  const deg=fr[0]?.degradationLevel||'0';

  const mA=document.getElementById('m-agents');
  mA.textContent=n+'/'+total;
  mA.className='metric-val '+(n<total*.5?'red':n<total*.8?'orange':'accent');

  const mP=document.getElementById('m-posture');
  mP.textContent=p;mP.className='metric-val '+(p==='RETREAT'?'red':p!=='NORMAL'?'yellow':'green');

  document.getElementById('m-cmd').textContent=cmd?cmd.callsign.replace('WHACO-',''):'—';
  const mD=document.getElementById('m-deg');
  mD.textContent='L'+deg;mD.className='metric-val '+(+deg>=3?'red':+deg>=1?'yellow':'green');

  document.getElementById('m-svi').textContent=svi.toFixed(2);
  const asdpClean=(asdp||'NOMINAL').replace('ASDP_','');
  const mAs=document.getElementById('m-asdp');
  mAs.textContent=asdpClean;mAs.style.color=AC[asdp]||'var(--green)';

  const g=document.getElementById('svi-gauge');
  g.style.width=(svi*100)+'%';
  g.style.background=svi>.7?'var(--green)':svi>.5?'var(--yellow)':svi>.3?'var(--orange)':'var(--red)';

  const tc=document.getElementById('threat-count');
  tc.textContent=ht.length+' tracked';tc.style.color=ht.length?'var(--red)':'var(--text-secondary)';
  document.getElementById('threat-badge').style.display=ht.length?'block':'none';
}

function addEvent(type,msg,sev){
  const bar=document.getElementById('event-bar');
  const chip=document.createElement('div');
  chip.className='event-chip '+(sev||'info');
  const t=new Date().toLocaleTimeString('en-US',{hour12:false});
  chip.textContent=t+' '+type+' '+msg;
  bar.insertBefore(chip,bar.firstChild);
  if(bar.children.length>30)bar.removeChild(bar.lastChild);
}

let prevState={};
async function poll(){
  try{
    const r=await fetch('state');if(!r.ok)throw 0;
    const agents=await r.json();
    document.getElementById('pulse-dot').style.background='var(--green)';
    document.getElementById('conn-status').textContent='LIVE';

    for(const[uid,d]of Object.entries(agents)){updAgent(d);eventCount++;}
    updMetrics(agents);updSidebar(agents);

    // Detect state changes for event bar
    for(const[uid,d]of Object.entries(agents)){
      const prev=prevState[uid];
      if(prev&&prev.governorMode!==d.governorMode&&!d.hostile)
        addEvent('MODE',d.callsign+' → '+d.governorMode,'info');
      if(prev&&prev.hierarchyRole!==d.hierarchyRole&&d.hierarchyRole==='COMMANDER')
        addEvent('ELECT',d.callsign+' elected COMMANDER','warn');
      if(prev&&prev.posture!==d.posture&&!d.hostile)
        addEvent('POSTURE',d.posture,'warn');
    }
    // Detect agent loss
    for(const uid of Object.keys(prevState)){
      if(!agents[uid]&&!prevState[uid].hostile)addEvent('LOSS',prevState[uid].callsign+' LOST','crit');
    }
    prevState=JSON.parse(JSON.stringify(agents));

    if(!fitted&&Object.keys(agents).length>0){
      const bounds=Object.values(agents).map(a=>[a.lat,a.lon]);
      if(bounds.length>1){map.fitBounds(bounds,{padding:[60,60]});fitted=true;}
    }

    // Update detail panel if open
    if(selectedUid&&agents[selectedUid])showDetail(agents[selectedUid]);

    // PSC card (check for PSC data in remarks)
    const cmdAgent=Object.values(agents).find(a=>a.hierarchyRole==='COMMANDER');
    if(cmdAgent&&cmdAgent.remarks&&cmdAgent.remarks.includes('[PSC]')){
      document.getElementById('psc-card').style.display='block';
      document.getElementById('psc-verdict').textContent='CERTIFIED';
      document.getElementById('psc-verdict').style.color='var(--green)';
    }
  }catch(e){
    document.getElementById('pulse-dot').style.background='var(--red)';
    document.getElementById('conn-status').textContent='DISCONNECTED';
  }
}
setInterval(poll,500);
</script>
</body>
</html>"""


class ViewerHandler(http.server.BaseHTTPRequestHandler):
    """HTTP handler for the web viewer."""

    def do_GET(self):
        if self.path == "/" or self.path == "/index.html":
            self._send_html(MAP_HTML)
        elif self.path == "/state":
            self._send_json()
        elif self.path == "/health":
            self._send_text(json.dumps({
                "status": "healthy",
                "events_parsed": _stats["events_parsed"],
                "agents_tracked": len(_current_state),
            }))
        else:
            self.send_error(404)

    def _send_html(self, content):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(content.encode("utf-8"))

    def _send_json(self):
        with _state_lock:
            data = dict(_current_state)
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(json.dumps(data).encode("utf-8"))

    def _send_text(self, text):
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(text.encode("utf-8"))

    def log_message(self, fmt, *args):
        pass  # Suppress request logging


def run_viewer(port: int, cot_file: str, run_demo: str = ""):
    """Start the web viewer server and CoT file tailer."""
    stop_event = threading.Event()

    # Start file tailer
    tailer = threading.Thread(
        target=tail_cot_file, args=(cot_file, stop_event),
        daemon=True, name="cot-tailer",
    )
    tailer.start()

    # Optionally start the demo in a background thread
    if run_demo:
        def _run_demo():
            import subprocess
            cmd = [
                sys.executable, "-m", "sovereign_edge.gateway",
                "--mode", run_demo,
                "--fast",
                "--transport", "file",
                "--output-file", cot_file,
                "--log-level", "INFO",
            ]
            logger.info("Starting demo: %s", " ".join(cmd))
            subprocess.run(cmd, cwd=str(Path(__file__).resolve().parent.parent))

        demo_thread = threading.Thread(target=_run_demo, daemon=True, name="demo")
        demo_thread.start()

    # Start HTTP server
    server = http.server.HTTPServer(("0.0.0.0", port), ViewerHandler)
    logger.info("Web viewer: http://0.0.0.0:%d", port)
    logger.info("Tailing: %s", cot_file)
    if run_demo:
        logger.info("Running %s demo in background", run_demo)

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        stop_event.set()
        server.server_close()
        logger.info("Web viewer stopped")


def main():
    parser = argparse.ArgumentParser(
        description="SOVEREIGN EDGE — Web-Based CoT Track Viewer")
    parser.add_argument("--port", type=int, default=8080,
                        help="HTTP server port")
    parser.add_argument("--cot-file", type=str,
                        default="/tmp/sovereign_edge_cot.xml",
                        help="Path to CoT XML file to tail")
    parser.add_argument("--run-demo", type=str, default="",
                        choices=["", "demo", "doomsday"],
                        help="Auto-start a demo scenario")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    run_viewer(args.port, args.cot_file, args.run_demo)


if __name__ == "__main__":
    main()
