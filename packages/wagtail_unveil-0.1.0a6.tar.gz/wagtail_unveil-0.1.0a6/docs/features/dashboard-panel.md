# Dashboard Panel

wagtail-unveil adds a panel to the Wagtail admin home page with quick links to the main reports and settings.

## Access

The panel is visible on the Wagtail admin home page to superusers when `DEBUG=True`, or when `WAGTAIL_UNVEIL_ENABLE_PRODUCTION_REPORTS=True`.

![Dashboard Panel](https://raw.githubusercontent.com/nm-packages/wagtail-unveil/main/docs/features/wagtail_admin.jpg)

## What It Links To

- [Backend URLs Report](backend-urls-report.md) — admin URL discovery report
- [Frontend URLs Report](frontend-urls-report.md) — frontend URL discovery report
- [Platform Report](platform-report.md) — runtime versions and Python dependency inventory
- [Settings Page](settings-page.md) — settings diagnostic page

## Related

- [Features Index](index.md) — Back to section overview
- [Getting Started](../getting-started/installation.md) — Set up the package to see the panel
