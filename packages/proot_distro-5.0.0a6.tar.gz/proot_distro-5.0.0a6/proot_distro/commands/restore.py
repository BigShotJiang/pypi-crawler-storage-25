"""
Proot-Distro - manage proot containers on Termux.

Created by Sylirre <sylirre@termux.dev> for Termux project.
Development assisted by Claude Code (https://claude.ai/code).

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
"""
import os
import shutil
import stat
import sys
import tarfile

from proot_distro.constants import DISTRO_CONFIGS_DIR, INSTALLED_ROOTFS_DIR
from proot_distro.colors import C, msg


# Magic-byte signatures used to identify compressed streams.
_MAGIC_COMPRESS = (
    (b'\x1f\x8b',      'gz'),   # gzip
    (b'BZh',           'bz2'),  # bzip2
    (b'\xfd7zXZ\x00',  'xz'),   # xz
    (b'\x5d\x00',      'xz'),   # lzma (legacy format; lzma.open handles both xz and lzma)
)


def _detect_compression(header: bytes) -> str:
    """Return the tarfile compression mode inferred from *header* magic bytes.

    Returns the mode string ('gz', 'bz2', 'xz') on a match, or '' if the
    header does not match any known compressed format (plain tar or unknown).
    """
    for magic, mode in _MAGIC_COMPRESS:
        if header.startswith(magic):
            return mode
    return ''


def _remove_existing(dest: str, member: tarfile.TarInfo) -> None:
    """Remove any existing filesystem entry at *dest* before extraction."""
    try:
        if os.path.islink(dest) or os.path.isfile(dest):
            os.remove(dest)
        elif os.path.isdir(dest) and not member.isdir():
            shutil.rmtree(dest)
    except OSError:
        pass


def _route(member: tarfile.TarInfo,
           configs_parent: str, configs_base: str,
           rootfs_parent: str, rootfs_base: str):
    """Return *(dest_root, dest)* for *member*, or *(None, None)* to skip."""
    name = member.name.lstrip('/')
    if name.startswith(configs_base + '/') or name == configs_base:
        dest_root = configs_parent
    elif name.startswith(rootfs_base + '/') or name == rootfs_base:
        dest_root = rootfs_parent
    else:
        return None, None
    return dest_root, os.path.join(dest_root, name)


def command_restore(args, configs: dict) -> None:
    tarball = getattr(args, "tarball", None)

    if tarball:
        if not os.path.exists(tarball):
            msg()
            msg(f"{C['BRED']}Error: file '{C['YELLOW']}{tarball}{C['BRED']}' does not exist.{C['RST']}")
            msg()
            sys.exit(1)
        if os.path.isdir(tarball):
            msg()
            msg(f"{C['BRED']}Error: path '{C['YELLOW']}{tarball}{C['BRED']}' is a directory.{C['RST']}")
            msg()
            sys.exit(1)
    else:
        if sys.stdin.isatty():
            from proot_distro.commands.help import _HELP_COMMANDS
            msg()
            msg(f"{C['BRED']}Error: tarball file path is not specified and it looks like nothing is being piped via stdin either.{C['RST']}")
            _HELP_COMMANDS["restore"]()
            sys.exit(1)

    configs_parent = os.path.dirname(DISTRO_CONFIGS_DIR)
    configs_base   = os.path.basename(DISTRO_CONFIGS_DIR)
    rootfs_parent  = os.path.dirname(INSTALLED_ROOTFS_DIR)
    rootfs_base    = os.path.basename(INSTALLED_ROOTFS_DIR)

    os.makedirs(DISTRO_CONFIGS_DIR, exist_ok=True)
    os.makedirs(INSTALLED_ROOTFS_DIR, exist_ok=True)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Extracting distribution plug-in and rootfs from the tarball...{C['RST']}")

    use_tty = sys.stderr.isatty()
    done = 0
    cleared_rootfs: set = set()  # distro names whose old rootfs has been pre-cleared

    def _on_entry(total: int) -> None:
        nonlocal done
        done += 1
        if not use_tty:
            return
        pfx = f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}"
        if total:
            pct = done * 100 // total
            bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
            sys.stderr.write(f"\r{pfx}[{bar}] {pct:3d}%  {done} / {total} files{C['RST']}")
        else:
            # Streaming mode: no total known up front — show a counter.
            sys.stderr.write(f"\r{pfx}{done} files extracted...{C['RST']}")
        sys.stderr.flush()

    try:
        if tarball:
            # Detect compression from the first few bytes of the file.
            with open(tarball, 'rb') as fh:
                header = fh.read(6)
            comp = _detect_compression(header)
            # Use the detected mode; fall back to tarfile auto-detection when
            # the header is not recognised (covers plain tar and exotic formats).
            tar_mode = f'r:{comp}' if comp else 'r:*'
            open_kwargs = dict(name=tarball, mode=tar_mode)
        else:
            # Peek at the first bytes of stdin without consuming them.
            # BufferedReader.peek() fills the internal buffer and returns up to
            # n bytes without advancing the read position.
            header = sys.stdin.buffer.peek(6)[:6]
            comp = _detect_compression(header)
            tar_mode = f'r|{comp}'   # 'r|gz', 'r|bz2', 'r|xz', or 'r|'
            open_kwargs = dict(fileobj=sys.stdin.buffer, mode=tar_mode)

        with tarfile.open(**open_kwargs) as tf:
            if tarball:
                # Seekable: pre-collect members for an accurate total count.
                if use_tty:
                    sys.stderr.write(
                        f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] "
                        f"{C['CYAN']}Estimating progress...{C['RST']}")
                    sys.stderr.flush()
                all_members = [m for m in tf.getmembers()
                               if not (m.isblk() or m.ischr() or m.isfifo())]
                total = len(all_members)
                if use_tty:
                    sys.stderr.write("\r\033[K")
                    sys.stderr.flush()
            else:
                all_members = tf   # lazy iterator
                total = 0

            for member in all_members:
                if not tarball and (member.isblk() or member.ischr() or member.isfifo()):
                    continue

                dest_root, dest = _route(member,
                                         configs_parent, configs_base,
                                         rootfs_parent, rootfs_base)
                if dest is None:
                    continue

                # On the first entry for a given distro's rootfs, clear the
                # existing rootfs directory entirely so that files absent from
                # the archive are not left behind (recursive-unlink semantics).
                if dest_root == rootfs_parent:
                    rel = os.path.relpath(dest, INSTALLED_ROOTFS_DIR)
                    parts = rel.split(os.sep)
                    if parts and parts[0] not in ('', '..') \
                            and parts[0] not in cleared_rootfs:
                        old_dir = os.path.join(INSTALLED_ROOTFS_DIR, parts[0])
                        if os.path.isdir(old_dir):
                            pfx = f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}"
                            count = 0
                            if use_tty:
                                sys.stderr.write("\r\033[K")
                                sys.stderr.flush()
                            for dp, dns, fns in os.walk(old_dir, topdown=False,
                                                        followlinks=False):
                                for fname in fns:
                                    try:
                                        os.unlink(os.path.join(dp, fname))
                                    except OSError:
                                        pass
                                    count += 1
                                    if use_tty:
                                        sys.stderr.write(
                                            f"\r{pfx}Removing old rootfs..."
                                            f" {count} files{C['RST']}")
                                        sys.stderr.flush()
                                for dname in dns:
                                    try:
                                        os.rmdir(os.path.join(dp, dname))
                                    except OSError:
                                        pass
                            shutil.rmtree(old_dir, ignore_errors=True)
                            if use_tty:
                                sys.stderr.write("\r\033[K")
                                sys.stderr.flush()
                        cleared_rootfs.add(parts[0])

                _remove_existing(dest, member)

                if member.isdir():
                    os.makedirs(dest, exist_ok=True)
                    try:
                        os.chmod(dest, stat.S_IMODE(member.mode))
                    except OSError:
                        pass

                elif member.issym():
                    parent = os.path.dirname(dest)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    os.symlink(member.linkname, dest)

                elif member.islnk():
                    link_src = os.path.join(dest_root, member.linkname.lstrip('/'))
                    parent = os.path.dirname(dest)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    try:
                        os.link(link_src, dest)
                    except OSError:
                        pass

                elif member.isreg():
                    fobj = tf.extractfile(member)
                    if fobj is None:
                        continue
                    parent = os.path.dirname(dest)
                    if parent:
                        os.makedirs(parent, exist_ok=True)
                    try:
                        with open(dest, 'wb') as out:
                            while True:
                                chunk = fobj.read(1 << 17)  # 128 KiB
                                if not chunk:
                                    break
                                out.write(chunk)
                        try:
                            os.chmod(dest, stat.S_IMODE(member.mode))
                        except OSError:
                            pass
                    finally:
                        fobj.close()

                else:
                    # Skip device files, FIFOs, sockets, etc.
                    continue

                _on_entry(total)

        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")

    except KeyboardInterrupt:
        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Aborted by user.{C['RST']}")
        sys.exit(1)
    except (EOFError, OSError, tarfile.TarError) as exc:
        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Failed to restore distribution: {exc}{C['RST']}")
        msg()
        msg(f"{C['BRED']}The tarball may be corrupted or was not created by PRoot-Distro.{C['RST']}")
        msg()
        sys.exit(1)
