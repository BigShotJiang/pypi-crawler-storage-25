# Internal Tooling & Object Patterns

## Priority: HIGH

## Rule

Always use the project's existing internal objects, patterns, and tooling rather than creating custom alternatives. Read existing code before writing new code to understand established conventions.

## About This Repo

`geek-cafe-saas-sdk` is an **open-source SaaS SDK** published to PyPI. It provides generic, reusable SaaS building blocks (tenancy, subscriptions, users, workflows, file system, payments, voting, etc.). It depends on `boto3-assist` for DynamoDB model infrastructure and is consumed by downstream application projects.

**Do NOT put application-specific business logic in this repo.** Only generic SaaS concepts belong here. Domain-specific models, proprietary plan code mappings, and application-specific business rules belong in the consuming projects that depend on this SDK — never in this repo.

Examples of what does NOT belong here:
- A mapping of plan codes to company-specific pricing tiers
- Business rules tied to a specific product's workflow
- Models that only make sense in one consuming application

## DynamoDB Model Patterns

All models in this SDK inherit from `DynamoDBModelBase` (provided by `boto3-assist`). Follow these patterns consistently.

### Use `.map()` for Object Conversion

`.map(item)` populates a model instance from a dictionary or another model object.

```python
# CORRECT — use .map() to create/populate model instances
subscription = Subscription().map(dynamo_item)
user = User().map(user_dict)
tenant = Tenant().map(tenant_data)
```

```python
# WRONG — don't create custom factory methods
user = User.from_dict(data)       # Don't do this
user = User.from_response(resp)   # Don't do this
```

### Use `.prep_for_save()` Before Saving

Always call `prep_for_save()` before saving a model. This recomputes GSI keys and sets timestamps.

```python
# CORRECT — prepare model before saving
sub = Subscription()
sub.tenant_id = "tenant-123"
sub.plan_code = "pro"
sub.status = "active"
sub.prep_for_save()
```

### Use `.to_resource_dictionary()` for Serialization

Use the built-in serialization method rather than manually building dicts.

```python
# CORRECT — use built-in serialization
resource_dict = subscription.to_resource_dictionary()
resource_dict_no_none = subscription.to_resource_dictionary(include_none=False)
resource_dict_no_indexes = subscription.to_resource_dictionary(include_indexes=False)
```

```python
# WRONG — don't manually build dicts
sub_dict = {
    "id": subscription.id,
    "tenant_id": subscription.tenant_id,
    "status": subscription.status,
}
```

### Use `.merge()` for Partial Updates

Use `.merge()` to populate only specific fields from a dictionary or another model instance.

```python
# CORRECT — use merge() to update specific fields
existing = Subscription().map(db_response)
existing.merge({"status": "cancelled", "cancel_reason": "user_request"})
```

## ServiceResult Pattern

All service methods return `ServiceResult[T]`. Use the class methods to create results.

```python
from geek_cafe_saas_sdk.core.service_result import ServiceResult

# Success
return ServiceResult.success_result(data)
return ServiceResult.created_result(data)   # HTTP 201
return ServiceResult.updated_result(data)   # HTTP 200

# Errors
return ServiceResult.error_result("Something went wrong", error_code="VALIDATION_ERROR")
return ServiceResult.exception_result(exception, context="SubscriptionService.create")
```

## Testing Patterns

### Use moto for In-Memory AWS Testing

All tests should use `moto` for in-memory AWS simulation (DynamoDB, S3, Cognito). This provides real AWS-like behavior without external dependencies.

```python
# CORRECT — use moto via the shared conftest fixtures
def test_subscription_create(db, test_context):
    """db fixture provides a moto-backed DynamoDB with test table."""
    service = SubscriptionService(
        dynamodb=db,
        table_name="test-geek-cafe-table",
        request_context=test_context,
    )
    result = service.create(...)
    assert result.success
```

### Use conftest.py Fixtures

The repo has a comprehensive `tests/conftest.py` with shared fixtures. Use them instead of creating ad-hoc setup:

- `db` — moto-backed `DynamoDB` instance with test table (recommended for most service tests)
- `test_context` — lightweight `RequestContext` via `AnonymousContextFactory`
- `test_context_strict` — strict access control context
- `provisioning_context` — system-level context for tenant creation
- `platform_admin_context` — bypasses tenant isolation for test setup
- `dynamodb_resource` / `dynamodb_client` — raw moto-backed boto3 resources
- `test_table` — creates the standard test table with all GSIs
- `cognito_user_pool` / `cognito_utility` — moto-backed Cognito
- `test_user_data` — bootstraps tenant, subscription, and user records

### NO Magic Mocks for DynamoDB

Do NOT use `MagicMock` or `unittest.mock.patch` for DynamoDB operations. Use moto instead.

```python
# WRONG — don't mock DynamoDB
from unittest.mock import MagicMock
mock_db = MagicMock()
service = MyService(dynamodb=mock_db, ...)

# CORRECT — use moto via conftest fixtures
def test_my_service(db, test_context):
    service = MyService(dynamodb=db, table_name="test-geek-cafe-table", request_context=test_context)
```

**Exception:** Property-based tests (in `tests/properties/`) may use `MagicMock` to capture TransactWrite operations for structural assertions. This is acceptable when the test is verifying the shape of DynamoDB operations rather than end-to-end behavior.

### Property-Based Tests with Hypothesis

Property-based tests live in `tests/properties/`. Use Hypothesis for correctness properties.

```python
from hypothesis import given, settings, assume
from hypothesis.strategies import text, integers, sampled_from

@given(tenant_id=text(min_size=1, max_size=36, alphabet=string.ascii_lowercase + string.digits + "-"))
@settings(max_examples=100)
def test_my_property(self, tenant_id: str):
    # Use assume() to filter out invalid/reserved inputs
    assume(tenant_id != "active")  # Reserved key value
    ...
```

### Test Organization

```
tests/
├── conftest.py              # Shared fixtures (moto, contexts, factories)
├── common/                  # Reusable test helpers
│   ├── db_test_helpers.py   # Table creation helpers
│   ├── service_test_helpers.py
│   └── jwt_test_helpers.py
├── unit/                    # Unit tests
├── integration/             # Integration tests (marked, excluded by default)
├── properties/              # Property-based tests (Hypothesis)
├── modules/                 # Module-specific tests
└── test_*.py                # Top-level test files
```

## Code Organization Patterns

### Module Structure

Each domain module follows a consistent structure:

```
modules/<domain>/
├── __init__.py
├── handlers/    # Lambda handler entry points
├── models/      # DynamoDB models
└── services/    # Business logic services
```

### Single Source of Truth

Keep canonical implementations in one place. Don't duplicate logic across modules.

### Reuse Existing Utilities

Check `geek_cafe_saas_sdk/utilities/` and `geek_cafe_saas_sdk/core/` before writing new helpers:

- `case_conversion.py` — snake_case / camelCase conversion
- `datetime_utility.py` — timestamp helpers
- `cognito_utility.py` — Cognito operations
- `response.py` — Lambda response formatting
- `core/service_result.py` — standard result wrapper
- `core/request_context.py` — authentication/authorization context
- `core/anonymous_context.py` — test context factory

### Consistent Error Handling

Use `ServiceResult` for all service-level error handling. Use `exception_result` for unexpected errors to capture full stack traces.

```python
try:
    # business logic
    return ServiceResult.success_result(data)
except ValueError as e:
    return ServiceResult.error_result(str(e), error_code="VALIDATION_ERROR")
except Exception as e:
    return ServiceResult.exception_result(e, context="MyService.my_method")
```

## Development Workflow

### Read Existing Code First

Before writing new code:
1. Look for similar functionality in the codebase
2. Study how it's implemented
3. Follow the same patterns and conventions

### Type Hints

Always include type hints:

```python
def create_subscription(
    self,
    tenant_id: str,
    plan_code: str,
    price_cents: int,
    user_id: Optional[str] = None,
) -> ServiceResult[Subscription]:
    ...
```

### Docstrings

Include docstrings with Args, Returns, and Examples:

```python
def renew_subscription(self, subscription_id: str) -> ServiceResult[Subscription]:
    """
    Renew an active subscription for the next billing period.

    Args:
        subscription_id: The ID of the subscription to renew.

    Returns:
        ServiceResult containing the new subscription on success.

    Examples:
        >>> result = service.renew_subscription("sub-123")
        >>> assert result.success
        >>> assert result.data.status == "active"
    """
    ...
```

### Source Repo Rules

All code changes go to `geek-cafe-saas-sdk/src/`. Never modify files inside `.venv/` — those are installed copies managed by pip. The project uses editable installs (`pip install -e`) so source changes are picked up automatically.
