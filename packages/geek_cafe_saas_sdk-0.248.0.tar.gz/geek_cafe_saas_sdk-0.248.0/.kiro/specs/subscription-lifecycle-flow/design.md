# Subscription Lifecycle Flow Bugfix Design

## Overview

The subscription lifecycle flow (Create → Edit → Activate) is broken due to three interrelated issues in `SubscriptionService`:

1. **update() over-rejects**: The status guard rejects the entire request when the payload contains a `status` field — even if the value hasn't changed — because the UI sends the full subscription object.
2. **No activate-by-ID method**: There is no way to transition an existing "pending" subscription to "active" without re-creating it from a payload. The activate handler calls `bind_subscription()` which conflates "create-and-activate" with "activate existing record."
3. **Non-standard default status**: The initial status "ready" is non-standard; "pending" is the industry-standard term for "exists but not yet active."

The fix is minimal and targeted: relax the status guard for no-op values, add an `activate(subscription_id)` method, rename `bind_subscription` → `provision_subscription` (keeping a deprecated alias), and change the default status to "pending" with backward-compatible mapping.

## Glossary

- **Bug_Condition (C)**: The conditions that trigger the three bugs — (1) status field present but unchanged in update payload, (2) caller wants to activate an existing pending subscription by ID, (3) model returns "ready" instead of "pending"
- **Property (P)**: The desired correct behavior — (1) update succeeds with no-op status stripped, (2) activate transitions pending → active atomically, (3) model getter returns "pending" for legacy "ready" values
- **Preservation**: Existing behaviors that must remain unchanged — status-change rejection for actual changes, provision_subscription for new subscriptions, other lifecycle methods
- **SubscriptionService**: The service class in `modules/tenancy/services/subscription_service.py` that manages subscription CRUD and lifecycle
- **Subscription model**: The DynamoDB model in `modules/tenancy/models/subscription.py` with GSI2 keyed on status
- **Active pointer**: A DynamoDB item (PK=`tenant#<id>`, SK=`subscription#active`) that provides O(1) lookup of the current active subscription
- **TransactWrite**: DynamoDB atomic multi-item write used for activate + supersede + pointer update

## Bug Details

### Bug Condition

The bug manifests in three scenarios:

**Bug 1 — update() rejection**: When the UI sends the full subscription object (including the unchanged `status` field) to `update()`, the status guard unconditionally rejects the request before checking whether the status value actually differs from the current value.

**Bug 2 — no activate method**: When a caller wants to activate an existing "pending" subscription by ID, they must call `bind_subscription()` with a full payload, which creates a new in-memory Subscription via `Subscription().map(payload)` and overwrites the DynamoDB record — losing any fields set on the original but not included in the payload.

**Bug 3 — status naming**: When `create()` is called, the subscription defaults to status "ready" which is non-standard. The model's status getter returns "ready" as-is rather than mapping it to the canonical "pending".

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type ServiceRequest
  OUTPUT: boolean
  
  // Bug 1: update with no-op status
  IF input.method = "update" THEN
    current_status ← fetch_subscription(input.subscription_id).status
    RETURN "status" IN input.updates AND input.updates["status"] = current_status
  END IF
  
  // Bug 2: activate existing pending subscription
  IF input.method = "activate" THEN
    sub ← fetch_subscription(input.subscription_id)
    RETURN sub IS NOT NULL AND sub.status IN ("pending", "ready")
  END IF
  
  // Bug 3: model status mapping
  IF input.method = "get_status" THEN
    RETURN input.raw_status = "ready"
  END IF
  
  RETURN FALSE
END FUNCTION
```

### Examples

- **Bug 1**: UI calls `update("sub-123", {"seat_count": 10, "status": "active"})` on a subscription that is already "active" → rejected with "Cannot change subscription status via update()" instead of updating seat_count
- **Bug 2**: Handler calls `activate("sub-456")` where sub-456 has status "pending" → no such method exists; must use `bind_subscription(full_payload)` which overwrites the record
- **Bug 3**: `create({"plan_code": "pro", "price_cents": 2999})` → subscription.status returns "ready" instead of "pending"
- **Edge case**: `update("sub-789", {"seat_count": 5, "status": "canceled"})` on an "active" subscription → should STILL be rejected (actual status change)

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- `update()` with a payload containing a `status` field whose value DIFFERS from the current status must continue to reject with "Cannot change subscription status via update()"
- `update()` with a payload that does NOT contain a `status` field must continue to apply field updates normally
- `provision_subscription()` (formerly `bind_subscription()`) must continue to create a new subscription, supersede the prior active, and update the pointer
- `cancel_subscription()`, `mark_past_due()`, `record_payment()`, `reactivate()` must continue to work unchanged
- The status setter must accept both "ready" and "pending" as valid values
- All existing callers of `bind_subscription()` must continue to work via the deprecated alias
- `_bind_subscription_no_auth()` internal method continues to work (renamed to `_provision_subscription_no_auth()`)

**Scope:**
All inputs that do NOT involve the three bug conditions should be completely unaffected by this fix. This includes:
- Updates without a status field
- Updates with a genuinely different status value
- Direct calls to provision_subscription with new subscription payloads
- All other lifecycle methods (cancel, mark_past_due, record_payment, reactivate, renew)
- Subscriptions with status values other than "ready" (their getter returns the raw value unchanged)

## Hypothesized Root Cause

Based on the bug description and code analysis, the root causes are:

1. **Unconditional status guard in update()** (line ~815 of subscription_service.py): The guard checks `if "status" in updates` without comparing the value to the current subscription's status. It should only reject when the value is actually changing.

2. **Missing activate-by-ID method**: The `activate_subscription()` method (line ~290) accepts a full payload and creates a new Subscription from it. There is no method that takes just a subscription_id, fetches the existing record, and transitions it. The handler at `handlers/subscriptions/activate/app.py` always calls `bind_subscription(payload)`.

3. **Hardcoded default in model `__init__`** (line ~56 of subscription.py): `self._status: str = "ready"` should be `"pending"`. The status property getter returns `self._status` directly without mapping "ready" → "pending".

4. **Naming confusion**: `bind_subscription` doesn't clearly communicate that it creates AND activates. Renaming to `provision_subscription` makes the intent explicit.

## Correctness Properties

Property 1: Bug Condition - Update Strips No-Op Status

_For any_ update request where the payload contains a `status` field whose value equals the subscription's current status, the fixed `update()` method SHALL strip the status field from the updates and successfully apply all remaining field changes, returning a successful ServiceResult with the updated subscription.

**Validates: Requirements 2.1**

Property 2: Bug Condition - Activate Transitions Pending to Active

_For any_ subscription in "pending" (or legacy "ready") status, calling the fixed `activate(subscription_id)` method SHALL fetch the existing record, transition its status to "active", supersede any prior active subscription, update the active pointer, update the tenant's plan_tier, and return the same subscription record (same ID) with status "active".

**Validates: Requirements 2.2**

Property 3: Bug Condition - Model Maps Ready to Pending

_For any_ subscription loaded from DynamoDB with raw status value "ready", the model's `status` property getter SHALL return "pending".

**Validates: Requirements 2.3, 2.4**

Property 4: Preservation - Update Rejects Actual Status Changes

_For any_ update request where the payload contains a `status` field whose value DIFFERS from the subscription's current status, the fixed `update()` method SHALL reject the request with error code "STATUS_CHANGE_NOT_ALLOWED", producing the same behavior as the original function.

**Validates: Requirements 3.1**

Property 5: Preservation - Provision Subscription Works for New Subscriptions

_For any_ valid new subscription payload, calling `provision_subscription()` SHALL create a new subscription record with status "active", supersede any prior active subscription, update the pointer, and update tenant plan_tier — identical behavior to the original `bind_subscription()`.

**Validates: Requirements 3.2**

Property 6: Preservation - Update Without Status Field Works Normally

_For any_ update request where the payload does NOT contain a `status` key, the fixed `update()` method SHALL apply the field updates and save normally, producing the same result as the original function.

**Validates: Requirements 3.3**

## Fix Implementation

### Changes Required

Assuming our root cause analysis is correct:

**File**: `src/geek_cafe_saas_sdk/modules/tenancy/models/subscription.py`

**Changes**:
1. **Change default status**: In `__init__`, change `self._status: str = "ready"` to `self._status: str = "pending"`
2. **Add "pending" to valid statuses**: Update the status setter's `valid_statuses` list to include "pending"
3. **Map "ready" → "pending" in getter**: The status property getter should return "pending" when `self._status == "ready"`
4. **Update `is_ready()` helper**: Should check for both "ready" and "pending"

**File**: `src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`

**Function**: `update()`

**Changes**:
1. **Relax status guard**: Move the status check AFTER fetching the subscription. Compare `updates["status"]` to `subscription.status`. If they match, strip the key and continue. If they differ, reject as before.

**Function**: New `activate(subscription_id)` method

**Changes**:
2. **Add activate method**: New `@service_method("activate")` method that:
   - Takes `subscription_id` as parameter
   - Fetches the existing subscription via `get_by_id()`
   - Validates status is "pending" (or "ready" for backward compat)
   - Sets status to "active"
   - Calls `prep_for_save()` (recomputes GSI2 key with new status)
   - Gets current active subscription (if any) and marks it "superseded"
   - Builds TransactWrite: put updated subscription + supersede old + update pointer
   - Updates tenant plan_tier (non-critical, outside transaction)

**Function**: `bind_subscription()` → `provision_subscription()`

**Changes**:
3. **Rename method**: Rename `bind_subscription` to `provision_subscription`
4. **Add deprecated alias**: Keep `bind_subscription` as a method that delegates to `provision_subscription()`
5. **Rename internal**: Rename `_bind_subscription_no_auth` to `_provision_subscription_no_auth` with deprecated alias

**File**: `src/geek_cafe_saas_sdk/modules/tenancy/handlers/subscriptions/activate/app.py`

**Changes**:
6. **Update handler**: When a `subscription_id` is available (from path parameters), call `service.activate(subscription_id)`. When only a payload is provided (no ID in path), fall back to `service.provision_subscription(payload)` for backward compatibility.

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the bug on unfixed code, then verify the fix works correctly and preserves existing behavior.

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug BEFORE implementing the fix. Confirm or refute the root cause analysis. If we refute, we will need to re-hypothesize.

**Test Plan**: Write tests that exercise the three bug conditions against the UNFIXED code to observe failures and confirm root causes.

**Test Cases**:
1. **Update with no-op status**: Call `update("sub-1", {"seat_count": 10, "status": "active"})` on an active subscription (will fail on unfixed code — rejected)
2. **Activate existing pending**: Attempt to activate a subscription by ID that has status "ready" (will fail on unfixed code — no method exists)
3. **Status default check**: Call `create(payload)` and check `result.data.status` (will return "ready" on unfixed code)
4. **Model getter check**: Load a subscription with `_status = "ready"` and check `.status` property (will return "ready" on unfixed code)

**Expected Counterexamples**:
- `update()` returns `success=False` with error code "STATUS_CHANGE_NOT_ALLOWED" even when status hasn't changed
- No `activate(subscription_id)` method exists on the service
- `Subscription().__init__` sets `_status = "ready"` instead of "pending"

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces the expected behavior.

**Pseudocode:**
```
// Bug 1: update with no-op status
FOR ALL (subscription_id, updates) WHERE isBugCondition_Update(subscription_id, updates) DO
  result := update'(subscription_id, updates)
  ASSERT result.success = TRUE
  ASSERT all non-status fields in updates are applied to the subscription
END FOR

// Bug 2: activate existing pending
FOR ALL subscription_id WHERE isBugCondition_Activate(subscription_id) DO
  result := activate'(subscription_id)
  ASSERT result.success = TRUE
  ASSERT result.data.id = subscription_id
  ASSERT result.data.status = "active"
END FOR

// Bug 3: status mapping
FOR ALL subscription WHERE subscription._status = "ready" DO
  ASSERT subscription.status = "pending"
END FOR
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function.

**Pseudocode:**
```
// Preservation: update rejects actual status changes
FOR ALL (subscription_id, updates) WHERE NOT isBugCondition_Update(subscription_id, updates)
    AND "status" IN updates DO
  ASSERT update'(subscription_id, updates).success = FALSE
  ASSERT update'(subscription_id, updates).error_code = "STATUS_CHANGE_NOT_ALLOWED"
END FOR

// Preservation: update without status works normally
FOR ALL (subscription_id, updates) WHERE "status" NOT IN updates DO
  ASSERT update'(subscription_id, updates) = update(subscription_id, updates)
END FOR

// Preservation: provision_subscription works for new subscriptions
FOR ALL payload WHERE payload represents a new subscription DO
  ASSERT provision_subscription'(payload) = bind_subscription(payload)
END FOR

// Preservation: non-"ready" status values unchanged
FOR ALL subscription WHERE subscription._status != "ready" DO
  ASSERT subscription.status = subscription._status
END FOR
```

**Testing Approach**: Property-based testing (Hypothesis) is recommended for preservation checking because:
- It generates many test cases automatically across the input domain
- It catches edge cases that manual unit tests might miss (e.g., status values at boundaries of the valid set)
- It provides strong guarantees that behavior is unchanged for all non-buggy inputs

**Test Plan**: Observe behavior on UNFIXED code first for non-bug-condition inputs, then write property-based tests capturing that behavior.

**Test Cases**:
1. **Status rejection preservation**: Generate random subscriptions and updates where status differs → verify rejection continues
2. **No-status update preservation**: Generate random updates without status key → verify they succeed as before
3. **Provision preservation**: Generate random valid payloads → verify provision_subscription produces same results as bind_subscription
4. **Status getter preservation**: Generate subscriptions with various non-"ready" statuses → verify getter returns raw value

### Unit Tests

- Test `update()` with no-op status field (seat_count change + same status) → succeeds
- Test `update()` with actual status change → rejected
- Test `update()` without status field → succeeds
- Test `activate(subscription_id)` on pending subscription → transitions to active
- Test `activate(subscription_id)` on non-pending subscription → rejected
- Test `activate(subscription_id)` supersedes prior active subscription
- Test `activate(subscription_id)` updates active pointer
- Test `activate(subscription_id)` updates tenant plan_tier
- Test `Subscription()` default status is "pending"
- Test status getter maps "ready" → "pending"
- Test status setter accepts both "ready" and "pending"
- Test `provision_subscription()` works identically to old `bind_subscription()`
- Test `bind_subscription()` deprecated alias delegates to `provision_subscription()`

### Property-Based Tests

- Generate random subscription states and update payloads with matching status → verify update succeeds and fields are applied (fix checking)
- Generate random subscription states and update payloads with differing status → verify rejection (preservation)
- Generate random valid plan_code/price_cents payloads → verify provision_subscription creates active subscription with pointer (preservation)
- Generate random status values from valid set → verify getter returns "pending" only for "ready", raw value for all others (fix + preservation)
- Generate random pending subscriptions → verify activate transitions to active and returns same ID (fix checking)

### Integration Tests

- Test full lifecycle: create (status=pending) → update (with no-op status) → activate (pending→active)
- Test activate with existing active subscription: creates pending, activates → old active becomes superseded
- Test handler routing: activate handler with subscription_id in path calls `activate()`, without ID calls `provision_subscription()`
- Test backward compatibility: `bind_subscription()` alias still works end-to-end
