# Implementation Plan

- [x] 1. Write bug condition exploration test
  - **Property 1: Bug Condition** - Subscription Lifecycle Flow Bugs
  - **CRITICAL**: This test MUST FAIL on unfixed code - failure confirms the bugs exist
  - **DO NOT attempt to fix the test or the code when it fails**
  - **NOTE**: This test encodes the expected behavior - it will validate the fix when it passes after implementation
  - **GOAL**: Surface counterexamples that demonstrate the three bugs exist
  - **Scoped PBT Approach**: Scope properties to concrete failing cases for each bug:
    - Bug 1 (update rejection): Generate subscriptions with status "active", call `update(sub_id, {"seat_count": N, "status": "active"})` — assert `result.success = True` and seat_count is updated
    - Bug 2 (no activate-by-ID): Verify that `SubscriptionService` has no `activate(subscription_id)` method that fetches an existing pending subscription and transitions it to active without a full payload
    - Bug 3 (status naming): Create a new subscription via `create()` — assert `subscription.status == "pending"` (not "ready"); also test that a Subscription model with `_status = "ready"` returns "pending" from the `.status` property getter
  - Use Hypothesis to generate random seat_count, plan_code, price_cents values for Bug 1
  - Run test on UNFIXED code — expect FAILURE (this confirms the bugs exist)
  - Document counterexamples found (e.g., "update with same status rejected", "no activate method", "status returns 'ready' instead of 'pending'")
  - Test file: `tests/properties/test_subscription_lifecycle_bug_condition.py`
  - _Requirements: 1.1, 1.2, 1.3, 1.4_

- [x] 2. Write preservation property tests (BEFORE implementing fix)
  - **Property 2: Preservation** - Subscription Lifecycle Unchanged Behaviors
  - **IMPORTANT**: Follow observation-first methodology
  - Observe on UNFIXED code:
    - `update(sub_id, {"seat_count": 10, "status": "canceled"})` on an "active" subscription → rejected with error_code "STATUS_CHANGE_NOT_ALLOWED"
    - `update(sub_id, {"seat_count": 10})` (no status key) on an active subscription → succeeds, seat_count updated
    - `bind_subscription(payload)` with valid new subscription payload → creates active subscription, supersedes prior, updates pointer
    - Subscription model with `_status = "active"` → `.status` returns "active" (non-"ready" values unchanged)
    - `cancel_subscription()`, `record_payment()`, `mark_past_due()` continue to work
  - Write property-based tests capturing observed behavior patterns:
    - Property: For all (subscription_id, updates) where "status" IN updates AND updates["status"] != current_status → `update()` returns `success=False`, `error_code="STATUS_CHANGE_NOT_ALLOWED"`
    - Property: For all (subscription_id, updates) where "status" NOT IN updates → `update()` returns `success=True` and fields are applied
    - Property: For all valid new subscription payloads → `bind_subscription(payload)` creates active subscription with pointer
    - Property: For all status values in valid_statuses where status != "ready" → model `.status` getter returns the raw value unchanged
  - Verify tests PASS on UNFIXED code
  - Test file: `tests/properties/test_subscription_lifecycle_preservation.py`
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 3. Fix subscription lifecycle flow

  - [x] 3.1 Update Subscription model default status and getter
    - In `modules/tenancy/models/subscription.py`:
    - Change `self._status: str = "ready"` to `self._status: str = "pending"` in `__init__`
    - Add "pending" to `valid_statuses` list in the status setter
    - Update status property getter to return "pending" when `self._status == "ready"` (backward-compat mapping)
    - Update `is_ready()` to check `self._status in ("ready", "pending")`
    - _Bug_Condition: isBugCondition_StatusName(X) where X._status = "ready" → getter returns "ready" instead of "pending"_
    - _Expected_Behavior: status getter returns "pending" for legacy "ready" values; new subscriptions default to "pending"_
    - _Preservation: Non-"ready" status values are returned unchanged; setter accepts both "ready" and "pending"_
    - _Requirements: 2.3, 2.4, 3.5_

  - [x] 3.2 Fix update() status guard in SubscriptionService
    - In `modules/tenancy/services/subscription_service.py`, method `update()`:
    - Move the status guard check AFTER fetching the subscription via `get_by_id()`
    - Compare `updates["status"]` to `subscription.status` (the fetched current value)
    - If values match (no-op): strip "status" from updates dict and continue with remaining fields
    - If values differ (actual change): reject with existing error message and "STATUS_CHANGE_NOT_ALLOWED" code
    - _Bug_Condition: isBugCondition_Update(X) where "status" IN X.updates AND X.updates["status"] = current_status_
    - _Expected_Behavior: update succeeds with no-op status stripped, remaining fields applied_
    - _Preservation: Actual status changes still rejected; updates without status field work normally_
    - _Requirements: 2.1, 3.1, 3.3_

  - [x] 3.3 Add activate(subscription_id) method to SubscriptionService
    - In `modules/tenancy/services/subscription_service.py`:
    - Add new `@service_method("activate")` method: `activate(self, subscription_id: str) -> ServiceResult[Subscription]`
    - Requires authentication
    - Fetches existing subscription via `get_by_id(subscription_id)`
    - Validates status is "pending" or "ready" (backward compat) — reject otherwise
    - Sets status to "active"
    - Calls `prep_for_save()` to recompute GSI keys
    - Gets current active subscription (if any) via `get_bound_subscription()`
    - If old active exists and is different ID, marks it "superseded"
    - Builds TransactWrite: put updated subscription + supersede old + update pointer
    - Updates tenant plan_tier (non-critical, outside transaction)
    - Returns `ServiceResult.success_result(subscription)` with same ID
    - _Bug_Condition: isBugCondition_Activate(X) where sub exists with status "pending"/"ready"_
    - _Expected_Behavior: activate transitions pending → active atomically, same record ID preserved_
    - _Preservation: provision_subscription() continues to work for new subscriptions_
    - _Requirements: 2.2_

  - [x] 3.4 Rename bind_subscription → provision_subscription with deprecated alias
    - In `modules/tenancy/services/subscription_service.py`:
    - Rename `bind_subscription()` method to `provision_subscription()`
    - Add deprecated `bind_subscription()` method that delegates to `provision_subscription()`
    - Rename `_bind_subscription_no_auth()` to `_provision_subscription_no_auth()`
    - Add deprecated `_bind_subscription_no_auth()` that delegates to `_provision_subscription_no_auth()`
    - _Preservation: All existing callers of bind_subscription() continue to work via deprecated alias_
    - _Requirements: 2.5, 3.2_

  - [x] 3.5 Update activate handler routing
    - In `modules/tenancy/handlers/subscriptions/activate/app.py`:
    - When `subscription_id` is available from path parameters, call `service.activate(subscription_id)`
    - When no ID in path (only payload), fall back to `service.provision_subscription(payload)`
    - _Requirements: 2.2, 2.5_

  - [x] 3.6 Verify bug condition exploration test now passes
    - **Property 1: Expected Behavior** - Subscription Lifecycle Flow Bugs Fixed
    - **IMPORTANT**: Re-run the SAME test from task 1 - do NOT write a new test
    - The test from task 1 encodes the expected behavior
    - When this test passes, it confirms the expected behavior is satisfied
    - Run: `python -m pytest tests/properties/test_subscription_lifecycle_bug_condition.py -v`
    - **EXPECTED OUTCOME**: Test PASSES (confirms bugs are fixed)
    - _Requirements: 2.1, 2.2, 2.3, 2.4_

  - [x] 3.7 Verify preservation tests still pass
    - **Property 2: Preservation** - Subscription Lifecycle Unchanged Behaviors
    - **IMPORTANT**: Re-run the SAME tests from task 2 - do NOT write new tests
    - Run: `python -m pytest tests/properties/test_subscription_lifecycle_preservation.py -v`
    - **EXPECTED OUTCOME**: Tests PASS (confirms no regressions)
    - Confirm all preservation tests still pass after fix (no regressions)

- [x] 4. Checkpoint - Ensure all tests pass
  - Run full test suite: `python -m pytest tests/properties/test_subscription_lifecycle_bug_condition.py tests/properties/test_subscription_lifecycle_preservation.py -v`
  - Ensure all property-based tests pass
  - Ensure no regressions in existing subscription tests: `python -m pytest tests/test_subscription_service.py -v`
  - Ask the user if questions arise
