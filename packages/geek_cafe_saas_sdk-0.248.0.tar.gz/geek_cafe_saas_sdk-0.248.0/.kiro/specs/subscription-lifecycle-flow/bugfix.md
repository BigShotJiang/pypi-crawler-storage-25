# Bugfix Requirements Document

## Introduction

The subscription lifecycle flow (Create → Edit → Activate) is broken due to multiple issues in `SubscriptionService`. The `update()` method rejects the entire request when the payload contains a `status` field — even if the status value hasn't changed — because the UI sends the full subscription object. The `bind_subscription()` method overwrites the existing record from a fresh payload rather than fetching and transitioning the existing subscription. Additionally, the initial status "ready" is non-standard and should be renamed to "pending" for clarity. A proper `activate(subscription_id)` method is needed that takes just an ID, transitions the subscription from "pending" to "active", supersedes any prior active subscription, and updates the pointer.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN the UI calls `update()` with a payload that includes the current `status` field (unchanged value) alongside other editable fields (seat_count, plan_code, dates, etc.) THEN the system rejects the entire update request with error "Cannot change subscription status via update()"

1.2 WHEN the UI calls `bind_subscription()` with a payload containing an existing subscription ID THEN the system builds a new in-memory Subscription from the payload via `Subscription().map(payload)` and overwrites the DynamoDB record, losing any fields that were set on the original but not included in the payload. It does NOT fetch the existing record first.

1.3 WHEN `create()` is called THEN the subscription defaults to status "ready" which is non-standard terminology. The industry-standard term is "pending" (meaning: exists but not yet active, waiting for activation).

1.4 There is no `activate(subscription_id)` method that simply takes an ID and transitions an existing "pending" subscription to "active". The activate handler calls `bind_subscription()` which conflates "create-and-activate" with "activate existing record."

### Expected Behavior (Correct)

2.1 WHEN the UI calls `update()` with a payload that includes the `status` field but the status value matches the subscription's current status THEN the system SHALL strip the status field from the updates and proceed to save the remaining field changes normally

2.2 WHEN `activate(subscription_id)` is called with an existing subscription ID that has status "pending" THEN the system SHALL:
  - Fetch the existing subscription record from the database
  - Transition its status from "pending" to "active"
  - If a currently active subscription exists (via pointer), mark it as "superseded"
  - Update the active subscription pointer to the newly activated subscription
  - Update the tenant's plan_tier
  - Save the record (same record, no overwrite from payload)

2.3 WHEN `create()` is called THEN the subscription SHALL default to status "pending" (not "ready")

2.4 WHEN a subscription with status "ready" is loaded from DynamoDB through the model's `.map()` method THEN the status property getter SHALL return "pending" (transparent alias for backward compatibility). Direct DynamoDB reads that bypass the model are acceptable to return "ready" as-is.

2.5 `bind_subscription()` SHALL be renamed to `provision_subscription()` to clearly communicate its purpose: "create a new subscription and immediately make it active in one step." The method behavior remains the same — it creates a new subscription record with status "active", supersedes any prior active subscription, and sets the pointer. The old `bind_subscription()` name SHALL be kept as a deprecated alias that delegates to `provision_subscription()` for backward compatibility.

### Unchanged Behavior (Regression Prevention)

3.1 WHEN the UI calls `update()` with a payload that contains a `status` field whose value differs from the subscription's current status THEN the system SHALL CONTINUE TO reject the request with the existing error message directing callers to use lifecycle methods

3.2 WHEN `provision_subscription()` is called with a payload for a new subscription THEN the system SHALL CONTINUE TO create a new subscription record, supersede the previously bound subscription (if any), and update the tenant's plan_tier

3.3 WHEN `update()` is called with a payload that does NOT contain a `status` field THEN the system SHALL CONTINUE TO apply the field updates and save normally

3.4 WHEN `cancel_subscription()`, `mark_past_due()`, `record_payment()`, or `reactivate()` are called THEN they SHALL CONTINUE TO work as before — these are existing lifecycle methods that are not affected by this change

3.5 The valid status values list SHALL include both "ready" (for backward compat with existing DB records) and "pending" (new default). The status setter SHALL accept both values.

---

## Subscription Lifecycle (Corrected)

### Status Values
- `pending` — newly created, waiting for activation (replaces "ready")
- `ready` — legacy alias, accepted on input, mapped to "pending" on output through model
- `active` — currently active subscription for the tenant
- `trial` — in trial period
- `past_due` — payment failed
- `canceled` — canceled by user/admin
- `expired` — billing period ended without renewal
- `disabled` — administratively disabled
- `restricted` — limited access
- `superseded` — replaced by a newer subscription (terminal)

### State Transitions
```
create()           → pending
activate(id)       → pending → active (supersedes prior active)
cancel(id)         → active → canceled
mark_past_due(id)  → active → past_due
record_payment(id) → past_due → active
reactivate(id)     → canceled → active
```

### API Methods
- `create(payload)` — creates subscription with status "pending"
- `update(subscription_id, updates)` — edits fields, strips no-op status
- `activate(subscription_id)` — NEW: transitions pending → active, sets pointer
- `provision_subscription(payload)` — create-and-activate in one shot (renamed from bind_subscription)
- `cancel_subscription(id)` — active → canceled
- `mark_past_due(id)` — active → past_due
- `record_payment(id, amount)` — past_due → active
- `reactivate(id)` — canceled → active

---

## Bug Condition

### Bug Condition Function — Bug 1 (update rejection)

```pascal
FUNCTION isBugCondition_Update(X)
  INPUT: X of type UpdateRequest (subscription_id, updates dict)
  OUTPUT: boolean

  // Bug triggers when "status" key is present in updates dict
  // but the value equals the subscription's current status
  current_status ← fetch_subscription(X.subscription_id).status
  RETURN "status" IN X.updates AND X.updates["status"] = current_status
END FUNCTION
```

### Property Specification — Bug 1

```pascal
// Property: Fix Checking — update() allows non-changing status field
FOR ALL X WHERE isBugCondition_Update(X) DO
  result ← update'(X.subscription_id, X.updates)
  ASSERT result.success = TRUE
  ASSERT updated_subscription has all non-status fields from X.updates applied
END FOR
```

### Bug Condition Function — Bug 2 (no activate method)

```pascal
FUNCTION isBugCondition_Activate(X)
  INPUT: X of type ActivateRequest (subscription_id)
  OUTPUT: boolean

  // Bug triggers when caller wants to activate an existing pending subscription
  // but no such method exists — they must use bind_subscription with full payload
  sub ← fetch_subscription(X.subscription_id)
  RETURN sub IS NOT NULL AND sub.status IN ("pending", "ready")
END FUNCTION
```

### Property Specification — Bug 2

```pascal
// Property: Fix Checking — activate() transitions existing pending record
FOR ALL X WHERE isBugCondition_Activate(X) DO
  result ← activate'(X.subscription_id)
  ASSERT result.success = TRUE
  ASSERT result.data.id = X.subscription_id  // Same record
  ASSERT result.data.status = "active"
  // If prior active existed, it is now superseded
END FOR
```

### Bug Condition Function — Bug 3 (status naming)

```pascal
FUNCTION isBugCondition_StatusName(X)
  INPUT: X of type Subscription loaded via model .map()
  OUTPUT: boolean

  // Bug triggers when a subscription has "ready" in DB but model returns "ready"
  // instead of the canonical "pending"
  RETURN X._raw_status = "ready"
END FUNCTION
```

### Property Specification — Bug 3

```pascal
// Property: Fix Checking — model maps "ready" to "pending" on output
FOR ALL X WHERE isBugCondition_StatusName(X) DO
  ASSERT X.status = "pending"  // Property getter returns "pending"
END FOR
```

### Preservation Goal

```pascal
// Property: Preservation Checking — Bug 1
FOR ALL X WHERE NOT isBugCondition_Update(X) DO
  ASSERT update(X) = update'(X)
END FOR

// Property: Preservation Checking — Bug 2
// provision_subscription() continues to work unchanged for new subscriptions
FOR ALL payload WHERE "id" NOT IN payload OR fetch(payload["id"]) IS NULL DO
  ASSERT provision_subscription(payload) = provision_subscription'(payload)
END FOR

// Property: Preservation Checking — Bug 3
// Subscriptions with non-"ready" status are unaffected
FOR ALL X WHERE X._raw_status != "ready" DO
  ASSERT X.status = X._raw_status
END FOR
```
