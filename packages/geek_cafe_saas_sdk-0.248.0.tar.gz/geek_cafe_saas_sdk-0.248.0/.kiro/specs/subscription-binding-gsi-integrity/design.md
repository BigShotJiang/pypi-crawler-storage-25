# Subscription Binding GSI Integrity Bugfix Design

## Overview

The `SubscriptionService` uses raw DynamoDB `Update` expressions to change subscription status during supersession (bind/activate) and expiration (renew) operations. Because the `status` field is embedded in GSI2's partition key (`subscription_status#<status>`), these raw updates leave the GSI2 key stale — the item remains indexed under its original status partition. The fix replaces raw `Update` operations with full model `Put` operations (load → mutate → `prep_for_save()` → Put) so that GSI keys are recomputed atomically within the existing `TransactWrite`. Additionally, the `update()` method must reject `status` field changes to prevent callers from bypassing lifecycle methods.

## Glossary

- **Bug_Condition (C)**: A status-changing operation that uses a raw DynamoDB `Update` expression instead of the model's `prep_for_save()` pipeline, leaving GSI2 keys stale
- **Property (P)**: After any status transition, the subscription item's `gsi2_pk` attribute equals `subscription_status#<new_status>`, ensuring correct GSI2 indexing
- **Preservation**: All operations that do NOT involve raw status updates (create, cancel, record_payment, update without status, bind with no existing subscription) must produce identical results before and after the fix
- **`prep_for_save()`**: Model method that recomputes all GSI key attributes (gsi1_pk, gsi1_sk, gsi2_pk, gsi2_sk, gsi3_pk, gsi3_sk) based on current model field values
- **`to_resource_dictionary()`**: Model method that serializes the full model including computed GSI key attributes into a DynamoDB-compatible dict
- **TransactWrite**: DynamoDB atomic transaction containing multiple Put/Update/Delete/ConditionCheck operations — all succeed or all fail
- **Bound Pointer**: A special DynamoDB item (PK=`tenant#<id>`, SK=`subscription#active`) that provides O(1) lookup of the current active subscription

## Bug Details

### Bug Condition

The bug manifests when a status-changing operation uses a raw DynamoDB `Update` expression that modifies the `status` attribute without recomputing the `gsi2_pk` attribute. Since GSI2's partition key is derived from `status` via `DynamoDBKey.build_key(("subscription_status", self.status))`, the raw Update leaves the item indexed under its original status partition.

**Formal Specification:**
```
FUNCTION isBugCondition(input)
  INPUT: input of type SubscriptionOperation
  OUTPUT: boolean
  
  RETURN (input.operation IN {bind_subscription, activate_subscription, _bind_subscription_no_auth, renew_subscription}
          AND input.has_existing_bound_subscription = true
          AND input.existing_subscription_id != input.new_subscription_id)
         OR
         (input.operation = update AND "status" IN input.update_fields)
END FUNCTION
```

### Examples

- **Bind supersession**: Tenant binds new subscription `sub-B`. Old subscription `sub-A` (status=active, gsi2_pk=`subscription_status#active`) is marked superseded via raw Update. After the Update, `sub-A.status` = "superseded" but `sub-A.gsi2_pk` remains `subscription_status#active`. Querying GSI2 for active subscriptions still returns `sub-A`; querying for superseded subscriptions misses it.
- **Renewal expiration**: Subscription `sub-A` is renewed. Old subscription is expired via raw Update. `sub-A.status` = "expired" but `sub-A.gsi2_pk` remains `subscription_status#active`. Billing jobs querying active subscriptions see a phantom expired subscription.
- **Update with status field**: Caller passes `{"status": "canceled"}` to `update()`. The `_save_model()` path correctly recomputes GSI keys, but no pointer update or supersession logic runs, leaving the bound pointer stale if the subscription was the active one.
- **Edge case — same subscription re-bind**: When `old_sub.id == new_sub.id`, the supersession is correctly skipped (no raw Update issued), so no GSI staleness occurs. This behavior must be preserved.

## Expected Behavior

### Preservation Requirements

**Unchanged Behaviors:**
- `bind_subscription()` with no existing bound subscription continues to create the new subscription and pointer atomically without any supersession operation
- `bind_subscription()` where old subscription ID equals new subscription ID continues to skip supersession to avoid TransactWrite conflicts
- `update()` with fields that do NOT include `status` continues to update normally via `_save_model()`
- `cancel_subscription()` continues to use the model save path (which already correctly recomputes GSI keys)
- `record_payment()` continues to use the model save path when changing status from "past_due" to "active"
- `get_bound_subscription()` continues to return the subscription pointed to by the pointer item
- `list_subscriptions_by_status()` continues to query GSI2 by status partition key
- `create()` continues to create subscription records without binding
- `_build_active_pointer_operation()` and `_update_bound_pointer_operation()` continue to produce correct pointer Put operations

**Scope:**
All inputs that do NOT involve (a) supersession of an existing subscription or (b) status field changes via `update()` should be completely unaffected by this fix. This includes:
- All read operations (get_by_id, get_bound_subscription, list_subscription_history, list_subscriptions_by_status)
- Create operations without binding
- Cancellation, payment recording, and mark_past_due (already use model save path)
- Renewal eligibility checks and period calculations

## Hypothesized Root Cause

Based on the bug description and code analysis, the root causes are:

1. **Raw Update in `bind_subscription()` supersession block** (lines ~155-170): The code builds an `Update` operation that sets `#status = :superseded` and `modified_utc_ts = :now` directly on the DynamoDB item. This changes the `status` attribute but does NOT update `gsi2_pk`, `gsi2_sk`, or any other GSI key attributes. The model's `_setup_indexes()` defines `gsi2_pk` as `subscription_status#<self.status>`, so only `prep_for_save()` can recompute it.

2. **Raw Update in `activate_subscription()` supersession block** (lines ~290-305): Identical pattern to `bind_subscription()` — raw Update sets status to "superseded" without GSI key recomputation.

3. **Raw Update in `_bind_subscription_no_auth()` supersession block** (lines ~230-245): Same pattern — raw Update for supersession without model pipeline.

4. **Raw Update in `renew_subscription()` expiration block** (lines ~1180-1190): The code builds an `Update` operation that sets `#status = :expired` and `modified_utc_ts = :now`. Same GSI staleness issue — `gsi2_pk` remains `subscription_status#active` instead of becoming `subscription_status#expired`.

5. **Unguarded `update()` method** (lines ~810-840): The method accepts arbitrary field updates via `subscription.map(updates)`. If `updates` contains `"status"`, the model save path correctly recomputes GSI keys, but no lifecycle side effects (pointer updates, supersession) are triggered. This allows the bound pointer to become stale.

## Correctness Properties

Property 1: Bug Condition - GSI2 Key Integrity After Status Transition

_For any_ subscription operation where the bug condition holds (supersession in bind/activate/_bind_no_auth, or expiration in renew), the old subscription's serialized item in the TransactWrite SHALL have `gsi2_pk` equal to `subscription_status#<new_status>` (i.e., `subscription_status#superseded` for bind/activate, `subscription_status#expired` for renew), confirming that `prep_for_save()` was called after the status change.

**Validates: Requirements 2.1, 2.2, 2.3, 2.4**

Property 2: Bug Condition - Status Field Rejection in update()

_For any_ call to `update()` where the `updates` dictionary contains the key `"status"`, the method SHALL return a failed `ServiceResult` with `error_code = "STATUS_CHANGE_NOT_ALLOWED"` and SHALL NOT modify the subscription in the database.

**Validates: Requirements 2.5**

Property 3: Preservation - Non-Status Updates Pass Through

_For any_ call to `update()` where the `updates` dictionary does NOT contain the key `"status"`, the method SHALL continue to update the subscription normally via `_save_model()`, producing the same result as the original (unfixed) code.

**Validates: Requirements 3.3**

Property 4: Preservation - No-Existing-Subscription Bind Unchanged

_For any_ `bind_subscription()` or `activate_subscription()` call where no existing bound subscription exists, the TransactWrite SHALL contain exactly 2 operations (Put subscription + Put pointer) with no supersession operation, identical to the original behavior.

**Validates: Requirements 3.1**

Property 5: Preservation - Same-ID Re-bind Skip Unchanged

_For any_ `bind_subscription()` or `activate_subscription()` call where the existing bound subscription has the same ID as the new subscription, the supersession operation SHALL be skipped (no Update or Put for the old subscription), identical to the original behavior.

**Validates: Requirements 3.2**

## Fix Implementation

### Changes Required

Assuming our root cause analysis is correct:

**File**: `geek-cafe-saas-sdk/src/geek_cafe_saas_sdk/modules/tenancy/services/subscription_service.py`

**Change 1: Replace raw Update with full model Put in `bind_subscription()` supersession**

Replace the `Update` operation block (when `old_sub is not None and old_sub.id != subscription.id`) with:
1. The `old_sub` is already loaded from `get_bound_subscription()` — use it directly
2. Set `old_sub.status = "superseded"`
3. Set `old_sub.notes = f"Superseded by: {subscription.id}"`
4. Set `old_sub.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()`
5. Call `old_sub.prep_for_save()` to recompute all GSI keys
6. Replace the `Update` dict with a `Put` dict using `old_sub.to_resource_dictionary()`

**Change 2: Replace raw Update with full model Put in `activate_subscription()` supersession**

Same pattern as Change 1 — the `old_sub` is already loaded from `get_bound_subscription()`.

**Change 3: Replace raw Update with full model Put in `_bind_subscription_no_auth()` supersession**

This method reads the pointer directly and gets the old subscription ID, but does NOT load the full model. The fix must:
1. Load the old subscription model using `_fetch_model_raw()` (create a temp `Subscription` with `id = old_sub_id`, call `_fetch_model_raw`)
2. If found, set status to "superseded", set notes, set modified_utc_ts
3. Call `prep_for_save()` and use `to_resource_dictionary()` in a Put operation
4. If not found (orphaned pointer), skip the supersession Put (same as current behavior where the Update would fail silently)

**Change 4: Replace raw Update with full model Put in `renew_subscription()` expiration**

The `old_sub` is already loaded from `get_by_id()`. The fix:
1. Set `old_sub.status = "expired"`
2. Set `old_sub.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()`
3. Call `old_sub.prep_for_save()` to recompute GSI keys
4. Replace the `Update` dict with a `Put` dict using `old_sub.to_resource_dictionary()`

**Change 5: Add status field guard to `update()` method**

Before the `subscription.map(updates)` call, check if `"status"` is in the `updates` dict. If so, return a validation error:
```python
if "status" in updates:
    raise ValidationError(
        "Cannot change subscription status via update(). "
        "Use the appropriate lifecycle method: bind_subscription(), "
        "activate_subscription(), cancel_subscription(), etc."
    )
```

### Atomicity Considerations

All changes maintain the existing `TransactWrite` atomicity guarantees:
- Replacing an `Update` with a `Put` in the same operations list preserves the all-or-nothing semantics
- DynamoDB `Put` within a transaction is a full item replacement — it writes all attributes including recomputed GSI keys
- The transaction size remains within DynamoDB's 100-operation limit (typically 2-3 operations per bind/renew)
- No additional network calls are needed for bind/activate/renew since the old subscription model is already loaded

For `_bind_subscription_no_auth()`, one additional `get_item` call is needed to load the old subscription model (the current code only reads the pointer). This is acceptable because:
- It only occurs when an existing bound subscription exists (not the common first-bind case)
- It's a single point read (by primary key), which is fast and cheap
- The alternative (keeping a raw Update) leaves GSI2 permanently corrupted

## Testing Strategy

### Validation Approach

The testing strategy follows a two-phase approach: first, surface counterexamples that demonstrate the bug on unfixed code, then verify the fix works correctly and preserves existing behavior.

### Exploratory Bug Condition Checking

**Goal**: Surface counterexamples that demonstrate the bug BEFORE implementing the fix. Confirm or refute the root cause analysis. If we refute, we will need to re-hypothesize.

**Test Plan**: Write property-based tests that exercise `bind_subscription`, `activate_subscription`, `_bind_subscription_no_auth`, and `renew_subscription` with an existing bound subscription, then inspect the TransactWrite operations to verify whether the supersession/expiration operation includes correct `gsi2_pk` values. Run these tests on the UNFIXED code to observe failures.

**Test Cases**:
1. **Bind Supersession GSI2 Test**: For any tenant with an existing active subscription, call `bind_subscription()` with a new subscription and assert the old subscription's Put item has `gsi2_pk = "subscription_status#superseded"` (will fail on unfixed code — raw Update has no gsi2_pk)
2. **Activate Supersession GSI2 Test**: Same as above but via `activate_subscription()` (will fail on unfixed code)
3. **No-Auth Bind Supersession GSI2 Test**: Same via `_bind_subscription_no_auth()` (will fail on unfixed code)
4. **Renewal Expiration GSI2 Test**: For any renewable subscription, call `renew_subscription()` and assert the old subscription's Put item has `gsi2_pk = "subscription_status#expired"` (will fail on unfixed code — raw Update has no gsi2_pk)
5. **Update Status Rejection Test**: Call `update()` with `{"status": "canceled"}` and assert it returns an error (will fail on unfixed code — status change is accepted)

**Expected Counterexamples**:
- On unfixed code, the TransactWrite operations list contains `Update` dicts (not `Put` dicts) for the old subscription, which have no `gsi2_pk` attribute
- On unfixed code, `update()` with status field succeeds instead of returning a validation error

### Fix Checking

**Goal**: Verify that for all inputs where the bug condition holds, the fixed function produces the expected behavior.

**Pseudocode:**
```
FOR ALL input WHERE isBugCondition(input) DO
  IF input.operation IN {bind, activate, _bind_no_auth} THEN
    ops := capture_transact_write(fixedFunction(input))
    old_sub_put := find_put_for_old_subscription(ops)
    ASSERT old_sub_put["Item"]["gsi2_pk"] = "subscription_status#superseded"
    ASSERT old_sub_put["Item"]["status"] = "superseded"
  END IF
  
  IF input.operation = renew THEN
    ops := capture_transact_write(fixedFunction(input))
    old_sub_put := find_put_for_old_subscription(ops)
    ASSERT old_sub_put["Item"]["gsi2_pk"] = "subscription_status#expired"
    ASSERT old_sub_put["Item"]["status"] = "expired"
  END IF
  
  IF input.operation = update AND "status" IN input.fields THEN
    result := fixedFunction(input)
    ASSERT result.success = false
    ASSERT result.error_code = "STATUS_CHANGE_NOT_ALLOWED"
  END IF
END FOR
```

### Preservation Checking

**Goal**: Verify that for all inputs where the bug condition does NOT hold, the fixed function produces the same result as the original function.

**Pseudocode:**
```
FOR ALL input WHERE NOT isBugCondition(input) DO
  ASSERT originalFunction(input) = fixedFunction(input)
END FOR
```

**Testing Approach**: Property-based testing is recommended for preservation checking because:
- It generates many random tenant IDs, subscription IDs, and field combinations to verify non-status updates work identically
- It catches edge cases like empty update dicts, updates with only non-status fields, and bind operations with no existing subscription
- It provides strong guarantees that the fix is minimal and doesn't introduce regressions

**Test Plan**: Observe behavior on UNFIXED code first for non-buggy operations, then write property-based tests capturing that behavior.

**Test Cases**:
1. **Non-Status Update Preservation**: For any `update()` call with fields NOT including "status", verify the operation succeeds and produces a `_save_model()` call with the updated fields — identical before and after fix
2. **No-Existing-Sub Bind Preservation**: For any `bind_subscription()` call where no existing bound subscription exists, verify the TransactWrite contains exactly 2 operations (Put sub + Put pointer) — identical before and after fix
3. **Same-ID Re-bind Preservation**: For any `bind_subscription()` call where old_sub.id == new_sub.id, verify no supersession operation is included — identical before and after fix
4. **Cancel/Payment/PastDue Preservation**: Verify that `cancel_subscription()`, `record_payment()`, and `mark_past_due()` continue to use `_save_model()` path unchanged

### Unit Tests

- Test that `bind_subscription()` with existing subscription produces a Put (not Update) for the old subscription with correct gsi2_pk
- Test that `activate_subscription()` with existing subscription produces a Put for the old subscription with correct gsi2_pk
- Test that `_bind_subscription_no_auth()` with existing pointer produces a Put for the old subscription with correct gsi2_pk
- Test that `renew_subscription()` produces a Put (not Update) for the old subscription with gsi2_pk = `subscription_status#expired`
- Test that `update()` with `{"status": "active"}` returns error with code "STATUS_CHANGE_NOT_ALLOWED"
- Test that `update()` with `{"plan_code": "enterprise"}` succeeds normally
- Test edge case: `_bind_subscription_no_auth()` with orphaned pointer (old sub not found) skips supersession gracefully

### Property-Based Tests

- Generate random tenant IDs, subscription IDs, and plan codes to verify GSI2 key integrity after supersession across many inputs
- Generate random non-status field combinations for `update()` to verify preservation of normal update behavior
- Generate random subscription states to verify renewal expiration produces correct gsi2_pk across billing intervals and plan types
- Generate random scenarios where no existing subscription exists to verify bind atomicity is preserved

### Integration Tests

- End-to-end test with moto: bind subscription A, then bind subscription B, then query GSI2 for "active" — only B should appear; query for "superseded" — A should appear
- End-to-end test with moto: create active subscription, renew it, query GSI2 for "active" — only new sub appears; query for "expired" — old sub appears
- End-to-end test with moto: attempt `update()` with status field, verify error returned and subscription unchanged in database
- End-to-end test with moto: verify `list_subscriptions_by_status("active")` returns correct results after multiple bind/renew cycles
