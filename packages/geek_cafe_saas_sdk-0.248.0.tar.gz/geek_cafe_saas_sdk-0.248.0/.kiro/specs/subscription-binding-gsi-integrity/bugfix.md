# Bugfix Requirements Document

## Introduction

The `SubscriptionService` uses raw DynamoDB `Update` expressions to mark old subscriptions as "superseded" during binding and activation operations. Because the `status` field is embedded in GSI2's partition key (`subscription_status#<status>`), these raw updates leave the GSI2 key stale — the old subscription remains indexed under its original status and never appears under `subscription_status#superseded`. This is silent data corruption that causes GSI2 queries (used by billing jobs) to return phantom active subscriptions and miss superseded ones.

Additionally, the `renew_subscription()` method has the same pattern when expiring old subscriptions, and the `update()` method allows arbitrary status changes without handling the subscription lifecycle side effects (pointer updates, supersession).

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN `bind_subscription()` supersedes an old subscription THEN the system uses a raw DynamoDB `Update` expression that changes the `status` attribute to "superseded" without recomputing the `gsi2_pk` attribute, leaving the old subscription indexed under `subscription_status#active` in GSI2

1.2 WHEN `activate_subscription()` supersedes an old subscription THEN the system uses a raw DynamoDB `Update` expression that changes the `status` attribute to "superseded" without recomputing the `gsi2_pk` attribute, leaving the old subscription indexed under `subscription_status#active` in GSI2

1.3 WHEN `_bind_subscription_no_auth()` supersedes an old subscription THEN the system uses a raw DynamoDB `Update` expression that changes the `status` attribute to "superseded" without recomputing the `gsi2_pk` attribute, leaving the old subscription indexed under `subscription_status#active` in GSI2

1.4 WHEN `renew_subscription()` expires an old subscription THEN the system uses a raw DynamoDB `Update` expression that changes the `status` attribute to "expired" without recomputing the `gsi2_pk` attribute, leaving the old subscription indexed under `subscription_status#active` in GSI2

1.5 WHEN `update()` is called with a `status` field change THEN the system saves the subscription via `_save_model()` (which correctly recomputes GSI keys) but does NOT update the bound subscription pointer or supersede the currently-bound subscription, allowing the pointer to become stale

### Expected Behavior (Correct)

2.1 WHEN `bind_subscription()` supersedes an old subscription THEN the system SHALL load the old subscription model, set its status to "superseded", call `prep_for_save()` to recompute all GSI keys (including `gsi2_pk` = `subscription_status#superseded`), and include the full item Put in the transaction

2.2 WHEN `activate_subscription()` supersedes an old subscription THEN the system SHALL load the old subscription model, set its status to "superseded", call `prep_for_save()` to recompute all GSI keys (including `gsi2_pk` = `subscription_status#superseded`), and include the full item Put in the transaction

2.3 WHEN `_bind_subscription_no_auth()` supersedes an old subscription THEN the system SHALL load the old subscription model, set its status to "superseded", call `prep_for_save()` to recompute all GSI keys (including `gsi2_pk` = `subscription_status#superseded`), and include the full item Put in the transaction

2.4 WHEN `renew_subscription()` expires an old subscription THEN the system SHALL load the old subscription model, set its status to "expired", call `prep_for_save()` to recompute all GSI keys (including `gsi2_pk` = `subscription_status#expired`), and include the full item Put in the transaction

2.5 WHEN `update()` is called with a `status` field change THEN the system SHALL reject the status change and return a validation error directing callers to use the appropriate lifecycle method (`bind_subscription`, `activate_subscription`, `cancel_subscription`, etc.)

### Unchanged Behavior (Regression Prevention)

3.1 WHEN `bind_subscription()` is called with no existing bound subscription THEN the system SHALL CONTINUE TO create the new subscription and pointer atomically without any supersession operation

3.2 WHEN `bind_subscription()` is called and the existing bound subscription has the same ID as the new subscription THEN the system SHALL CONTINUE TO skip the supersession operation to avoid TransactWrite conflicts on the same item

3.3 WHEN `update()` is called with fields that do NOT include `status` THEN the system SHALL CONTINUE TO update those fields normally via `_save_model()` without any lifecycle validation

3.4 WHEN `cancel_subscription()` changes a subscription's status THEN the system SHALL CONTINUE TO use the model save path (which already correctly recomputes GSI keys)

3.5 WHEN `record_payment()` changes a subscription's status from "past_due" to "active" THEN the system SHALL CONTINUE TO use the model save path (which already correctly recomputes GSI keys)

3.6 WHEN `get_bound_subscription()` is called THEN the system SHALL CONTINUE TO return the subscription pointed to by the `tenant#<id>` / `subscription#active` pointer item

3.7 WHEN `list_subscriptions_by_status("active")` is called THEN the system SHALL CONTINUE TO return only subscriptions whose GSI2 partition key is `subscription_status#active` (and after the fix, superseded subscriptions will no longer appear here)

---

## Bug Condition (Formal)

```pascal
FUNCTION isBugCondition(X)
  INPUT: X of type SubscriptionOperation
  OUTPUT: boolean
  
  // Returns true when a status-changing operation uses raw DynamoDB Update
  // instead of the model's prep_for_save() pipeline
  RETURN (X.operation IN {bind_subscription, activate_subscription, _bind_subscription_no_auth, renew_subscription}
          AND X.has_existing_bound_subscription = true
          AND X.existing_subscription_id != X.new_subscription_id)
         OR
         (X.operation = update AND "status" IN X.update_fields)
END FUNCTION
```

## Property: Fix Checking

```pascal
// Property: GSI2 Key Integrity After Status Transition
FOR ALL X WHERE isBugCondition(X) DO
  old_sub ← fetch_subscription(X.old_subscription_id)
  
  // After the fix, the old subscription's GSI2 pk must reflect its new status
  IF X.operation IN {bind_subscription, activate_subscription, _bind_subscription_no_auth} THEN
    ASSERT old_sub.gsi2_pk = "subscription_status#superseded"
  END IF
  
  IF X.operation = renew_subscription THEN
    ASSERT old_sub.gsi2_pk = "subscription_status#expired"
  END IF
  
  IF X.operation = update AND "status" IN X.update_fields THEN
    ASSERT result.success = false
    ASSERT result.error_code = "STATUS_CHANGE_NOT_ALLOWED"
  END IF
END FOR
```

## Property: Preservation Checking

```pascal
// Property: Non-buggy operations behave identically before and after the fix
FOR ALL X WHERE NOT isBugCondition(X) DO
  ASSERT F(X) = F'(X)
END FOR
```

This ensures that operations which do not involve raw status updates (e.g., `create`, `cancel_subscription`, `record_payment`, `update` without status field, `bind_subscription` with no existing subscription) produce identical results before and after the fix.
