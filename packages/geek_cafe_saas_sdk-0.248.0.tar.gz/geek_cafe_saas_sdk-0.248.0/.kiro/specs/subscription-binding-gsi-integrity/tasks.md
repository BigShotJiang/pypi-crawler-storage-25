# Implementation Plan

- [x] 1. Write bug condition exploration test
  - **Property 1: Bug Condition** - GSI2 Key Integrity After Status Transition
  - **CRITICAL**: This test MUST FAIL on unfixed code - failure confirms the bug exists
  - **DO NOT attempt to fix the test or the code when it fails**
  - **NOTE**: This test encodes the expected behavior - it will validate the fix when it passes after implementation
  - **GOAL**: Surface counterexamples that demonstrate the bug exists in `bind_subscription()`, `activate_subscription()`, `_bind_subscription_no_auth()`, `renew_subscription()`, and `update()` with status field
  - **Scoped PBT Approach**: For each buggy method, scope the property to concrete supersession/expiration scenarios where an existing bound subscription is present and a different subscription is being bound/renewed
  - **Test file**: `tests/properties/test_subscription_gsi_integrity_bug_condition.py`
  - **Test strategy**: Use `unittest.mock.patch` on `_execute_transact_write` to capture the operations list, then assert structural properties of the captured operations:
    - For bind/activate/_bind_no_auth supersession: assert the old subscription operation is a `Put` (not `Update`) with `gsi2_pk = "subscription_status#superseded"` in the Item
    - For renew expiration: assert the old subscription operation is a `Put` (not `Update`) with `gsi2_pk = "subscription_status#expired"` in the Item
    - For update with status field: assert the method returns `ServiceResult(success=False, error_code="STATUS_CHANGE_NOT_ALLOWED")`
  - Use Hypothesis with strategies for tenant_id, subscription_id, plan_code to generate varied inputs
  - Use `assume()` to filter: `old_sub_id != new_sub_id` (required for supersession to trigger)
  - Run test on UNFIXED code
  - **EXPECTED OUTCOME**: Test FAILS (this is correct - it proves the bug exists because raw Update operations have no `gsi2_pk` attribute and `update()` accepts status changes)
  - Document counterexamples found to understand root cause
  - Mark task complete when test is written, run, and failure is documented
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2, 2.3, 2.4, 2.5_

- [x] 2. Write preservation property tests (BEFORE implementing fix)
  - **Property 2: Preservation** - Non-Buggy Operations Unchanged
  - **IMPORTANT**: Follow observation-first methodology
  - **Test file**: `tests/properties/test_subscription_gsi_integrity_preservation.py`
  - **Observation phase**: Run UNFIXED code with non-buggy inputs and record behavior:
    - Observe: `bind_subscription()` with no existing bound subscription produces exactly 2 operations (Put sub + Put pointer)
    - Observe: `bind_subscription()` where old_sub.id == new_sub.id skips supersession (no Update/Put for old sub)
    - Observe: `update()` with non-status fields (e.g., `plan_code`, `seat_count`, `notes`) succeeds via `_save_model()`
    - Observe: `cancel_subscription()`, `record_payment()`, `mark_past_due()` use model save path unchanged
  - **Property tests** (using Hypothesis):
    - Property 2a: For any `bind_subscription()` with no existing bound subscription, TransactWrite contains exactly 2 operations (Put subscription + Put pointer) — no supersession operation
    - Property 2b: For any `bind_subscription()` where old_sub.id == new_sub.id, no supersession operation is included in the TransactWrite
    - Property 2c: For any `update()` with fields NOT including "status", the method succeeds and calls `_save_model()` with the updated subscription
    - Property 2d: `cancel_subscription()`, `record_payment()`, `mark_past_due()` continue to use `_save_model()` path
  - Use `unittest.mock.patch` on `_execute_transact_write` and `_save_model` to capture operations for structural assertions
  - Verify tests PASS on UNFIXED code
  - **EXPECTED OUTCOME**: Tests PASS (this confirms baseline behavior to preserve)
  - Mark task complete when tests are written, run, and passing on unfixed code
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 3. Fix for GSI2 key integrity in subscription status transitions

  - [x] 3.1 Replace raw Update with full model Put in `bind_subscription()` supersession block
    - Load old subscription (already available from `get_bound_subscription()`)
    - Set `old_sub.status = "superseded"`
    - Set `old_sub.notes = f"Superseded by: {subscription.id}"`
    - Set `old_sub.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()`
    - Call `old_sub.prep_for_save()` to recompute all GSI keys
    - Replace the `Update` dict with a `Put` dict using `old_sub.to_resource_dictionary()`
    - _Bug_Condition: isBugCondition(input) where input.operation = bind_subscription AND input.has_existing_bound_subscription = true AND input.existing_subscription_id != input.new_subscription_id_
    - _Expected_Behavior: old_sub.gsi2_pk = "subscription_status#superseded" after prep_for_save()_
    - _Preservation: bind_subscription with no existing sub or same-ID re-bind unchanged_
    - _Requirements: 2.1, 3.1, 3.2_

  - [x] 3.2 Replace raw Update with full model Put in `activate_subscription()` supersession block
    - Load old subscription (already available from `get_bound_subscription()`)
    - Set `old_sub.status = "superseded"`
    - Set `old_sub.notes = f"Superseded by: {subscription.id}"`
    - Set `old_sub.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()`
    - Call `old_sub.prep_for_save()` to recompute all GSI keys
    - Replace the `Update` dict with a `Put` dict using `old_sub.to_resource_dictionary()`
    - _Bug_Condition: isBugCondition(input) where input.operation = activate_subscription AND input.has_existing_bound_subscription = true AND input.existing_subscription_id != input.new_subscription_id_
    - _Expected_Behavior: old_sub.gsi2_pk = "subscription_status#superseded" after prep_for_save()_
    - _Preservation: activate_subscription with no existing sub or same-ID re-bind unchanged_
    - _Requirements: 2.2, 3.1, 3.2_

  - [x] 3.3 Replace raw Update with full model Put in `_bind_subscription_no_auth()` supersession block
    - This method only reads the pointer directly (no full model load) — must add a model fetch
    - After reading old_sub_id from pointer, load the full subscription model using `_fetch_model_raw()` (create temp `Subscription` with `id = old_sub_id`)
    - If found: set status to "superseded", set notes, set modified_utc_ts, call `prep_for_save()`, use `to_resource_dictionary()` in a Put operation
    - If not found (orphaned pointer): skip the supersession Put (graceful handling)
    - _Bug_Condition: isBugCondition(input) where input.operation = _bind_subscription_no_auth AND input.has_existing_bound_subscription = true_
    - _Expected_Behavior: old_sub.gsi2_pk = "subscription_status#superseded" after prep_for_save()_
    - _Preservation: _bind_subscription_no_auth with no existing pointer unchanged_
    - _Requirements: 2.3_

  - [x] 3.4 Replace raw Update with full model Put in `renew_subscription()` expiration block
    - Old subscription is already loaded from `get_by_id()` — use it directly
    - Set `old_sub.status = "expired"`
    - Set `old_sub.modified_utc_ts = dt.datetime.now(dt.UTC).timestamp()`
    - Call `old_sub.prep_for_save()` to recompute all GSI keys
    - Replace the `Update` dict with a `Put` dict using `old_sub.to_resource_dictionary()`
    - _Bug_Condition: isBugCondition(input) where input.operation = renew_subscription AND input.has_existing_bound_subscription = true_
    - _Expected_Behavior: old_sub.gsi2_pk = "subscription_status#expired" after prep_for_save()_
    - _Preservation: Renewal eligibility checks and period calculations unchanged_
    - _Requirements: 2.4_

  - [x] 3.5 Add status field guard to `update()` method
    - Before `subscription.map(updates)`, check if `"status"` is in the `updates` dict
    - If so, return `ServiceResult(success=False, message="Cannot change subscription status via update(). Use the appropriate lifecycle method: bind_subscription(), activate_subscription(), cancel_subscription(), etc.", error_code="STATUS_CHANGE_NOT_ALLOWED")`
    - _Bug_Condition: isBugCondition(input) where input.operation = update AND "status" IN input.update_fields_
    - _Expected_Behavior: result.success = false AND result.error_code = "STATUS_CHANGE_NOT_ALLOWED"_
    - _Preservation: update() with non-status fields continues to work normally via _save_model()_
    - _Requirements: 2.5, 3.3_

  - [x] 3.6 Verify bug condition exploration test now passes
    - **Property 1: Expected Behavior** - GSI2 Key Integrity After Status Transition
    - **IMPORTANT**: Re-run the SAME test from task 1 - do NOT write a new test
    - The test from task 1 encodes the expected behavior
    - When this test passes, it confirms the expected behavior is satisfied
    - Run: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest tests/properties/test_subscription_gsi_integrity_bug_condition.py -v`
    - **EXPECTED OUTCOME**: Test PASSES (confirms bug is fixed — all supersession/expiration operations now use Put with correct gsi2_pk, and update() rejects status changes)
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

  - [x] 3.7 Verify preservation tests still pass
    - **Property 2: Preservation** - Non-Buggy Operations Unchanged
    - **IMPORTANT**: Re-run the SAME tests from task 2 - do NOT write new tests
    - Run: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest tests/properties/test_subscription_gsi_integrity_preservation.py -v`
    - **EXPECTED OUTCOME**: Tests PASS (confirms no regressions — non-buggy operations produce identical results)
    - Confirm all preservation tests still pass after fix

- [x] 4. Checkpoint - Ensure all tests pass
  - Run full property test suite: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest tests/properties/test_subscription_gsi_integrity_bug_condition.py tests/properties/test_subscription_gsi_integrity_preservation.py -v`
  - Ensure all tests pass, ask the user if questions arise
  - Verify no regressions in existing subscription service tests: `source geek-cafe-saas-sdk/.venv/bin/activate && python -m pytest tests/test_subscription_service.py -v`
