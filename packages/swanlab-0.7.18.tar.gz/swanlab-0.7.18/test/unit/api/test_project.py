from unittest.mock import patch, MagicMock

from swanlab.api.projects import Projects
from swanlab.core_python import Client
from swanlab.package import get_host_web
from utils import create_project_data


def test_projects():
    """测试能否分页获取所有项目"""
    with patch('swanlab.api.projects.get_workspace_projects') as mock_get_projects:
        total = 80
        page_size = 20

        def side_effect(*args, **kwargs):
            return create_project_data(page=kwargs.get("page", 1), total=total)

        mock_get_projects.side_effect = side_effect

        mock_projects = Projects(
            MagicMock(spec=Client),
            web_host=get_host_web(),
            path='test_user',
        )
        projects = list(mock_projects)
        assert len(projects) == total
        assert mock_get_projects.call_count == (total + page_size - 1) // page_size
