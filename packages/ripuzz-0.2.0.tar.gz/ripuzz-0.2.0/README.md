# ripuzz

Generator for 3D interlocking puzzles. Given a rectangular block, ripuzz splits it into K pieces that come apart (and go back together) only in one specific order, one piece at a time — the piece you remove first is the "key", and nothing else moves until the key is out. It outputs one STEP file per piece, ready to slice and 3D-print, plus a looping GIF of the assembly sequence.

<kbd><img src="assembly.gif" alt="assembly animation" /></kbd>

## Install

```bash
pip install ripuzz
```

Or from a local checkout (editable):

```bash
pip install -e .
```

## Usage

```bash
# 4x4x4 cube, 8 pieces, default 10mm voxels (40mm cube)
ripuzz --size 4 --pieces 8 --out ./out

# 3x4x5 rectangular prism, 20mm voxels, 5 pieces
ripuzz --size 3 4 5 --voxel-size 20 --pieces 5 --out ./out

# STEP input (file must be a rectangular prism)
ripuzz --step prism.step --voxel-size 5 --pieces 12 --out ./out

# Custom clearance (gap between touching piece faces) + seed
ripuzz --size 4 --voxel-size 10 --pieces 8 --out ./out --kerf 0.2 --seed 42

# Custom edge chamfer: 0.5 mm (absolute) or 10% of voxel size
ripuzz --size 4 --pieces 8 --out ./out --chamfer 0.5
ripuzz --size 4 --pieces 8 --out ./out --chamfer 10%

# Keep searching for alternate configurations until the timeout elapses,
# writing each to ./out/1, ./out/2, ...
ripuzz --size 4 --pieces 6 --out ./out --nostop --timeout 30

# Use the more permissive 'experimental' algorithm (handles more input sizes)
ripuzz --size 3 --pieces 4 --out ./out --algorithm experimental

# Regenerate outputs from an existing manifest.json (skips generation).
# Handy while iterating on rendering or geometry code.
ripuzz --manifest ./out/manifest.json --out ./out2
```

Flags:

| Flag | Required | Default | Description |
| --- | --- | --- | --- |
| `--size N` or `--size W H D` | one of | — | Input prism: one value (cube) or three (W×H×D) in voxel units. |
| `--step FILE` | one of | — | STEP file of a prism; its bounding box is voxelized. |
| `--manifest FILE` | one of | — | Regenerate outputs from a previously-written `manifest.json`, skipping the generator. Mainly a development flag for rebuilding STEP/GIF files after changes to rendering or geometry code. Generator-related flags (`--pieces`, `--seed`, `--kerf`, `--chamfer`, `--voxel-size`, `--algorithm`, `--nostop`) are ignored; `--out` is still required. |
| `--pieces K` | yes | — | Number of puzzle pieces to generate (≥ 3). |
| `--out DIR` | yes | — | Output directory (created if absent). |
| `--voxel-size MM` | no | `10` | Physical size of one voxel edge, in millimeters (default 10 = 1 cm). |
| `--kerf MM` | no | `0.2` | Gap between touching piece faces, in millimeters (`0` disables). Without this, 3D-printed pieces jam together — real printers don't land exactly on nominal dimensions. The gap is taken from each piece, so the overall puzzle shrinks by `kerf` along X, Y, Z (e.g. a 40 mm cube becomes 39.8 mm with `--kerf 0.2`). |
| `--chamfer VALUE` | no | `3%` | Chamfer (bevel) on every edge of every piece. Helps pieces slide into place during assembly and prevents the first printed layer from bulging out (a common 3D-printing artifact that otherwise makes the base interfere with the mating surface). Accepts millimeters (`0.5`) or a percentage of `--voxel-size` (`3%`). `0` disables. All edges are chamfered identically so the chamfer pattern itself doesn't reveal where pieces meet. |
| `--seed N` | no | random | RNG seed. Running with the same seed and inputs reproduces the same puzzle layout (same voxel assignments, same pull-out directions, identical `manifest.json`). The STEP files themselves differ byte-for-byte across runs because the underlying CAD kernel writes a timestamp into each file's header, but the geometry they describe is identical. |
| `--nostop` | no | — | Keep searching for more valid puzzle layouts (by trying different seeds) until `--timeout` elapses. Each layout is written to a numbered subdirectory `DIR/1`, `DIR/2`, ... Incompatible with `--max-retries` and `--seed`. |
| `--timeout SECS` | no | `15.0` | Wall-clock time budget for retrying generation when the first seed fails (also the search budget when `--nostop` is set). Ignored if `--max-retries` is given. |
| `--max-retries N` | no | — | Fixed number of generation attempts before giving up; overrides `--timeout`. |
| `--algorithm {Song2012,experimental}` | no | `Song2012` | Which generator to run. `Song2012` follows the reference paper step-for-step. `experimental` is a looser variant that retries more aggressively when the paper-literal version gets stuck, and handles a wider range of block sizes and piece counts. |

## Algorithms

Two generators are bundled side-by-side; switch via `--algorithm`:

- **`Song2012`** (default) — a direct translation of the reference paper. Every step from the paper is preserved; places the paper is silent or ambiguous are flagged with `# ASSUMPTION:` comments in `src/ripuzz/algorithms/song2012.py`. Useful for studying or reproducing the original method.
- **`experimental`** — a looser variant in `src/ripuzz/algorithms/experimental.py` that retries more aggressively (backtracks across candidate pieces, relaxes some constraints on fallback) and therefore succeeds on a wider range of block sizes and piece counts than the paper-literal version.

Both share the same core (movement analysis, connectivity, path-finding, I/O) and the same CLI.

## Known limitations

- **3×3×3 cubes with 4 or more pieces** do not converge in either generator. The reference paper shows this tight case working, but via tuning that isn't fully spelled out. Use `--size 4` or larger for small piece counts.
- **STEP input must be a rectangular block.** Arbitrary-shape STEP input (voxelizing the interior of a non-prism solid) is not yet supported.

## Output

```
out/
  piece_01.step       # the "key" — last piece inserted when assembling,
                      # first piece that comes out when solving
  piece_02.step       # next piece out during disassembly
  ...
  piece_NN.step       # the "anchor" — largest remaining block, placed
                      # first during assembly; everything else attaches
                      # to this one. NN is the number of pieces.
  assembly.gif        # seamlessly looping animation: puzzle starts
                      # exploded around the anchor, pieces slide in one
                      # by one ending with the key, holds on the assembled
                      # puzzle, then disassembles back to the starting
                      # layout (first and last frames match for a clean loop).
  printable.step      # all pieces laid out on the print bed as separate
                      # solids, each oriented to minimise overhangs. Slice
                      # this one file to print the whole puzzle in one go.
  manifest.json       # schema version, piece order, pull-out directions,
                      # seed, kerf, chamfer — enough to regenerate this
                      # puzzle via `ripuzz --manifest ...`.
```

Each piece in `printable.step` is oriented with one of its six axis-aligned
faces down on the bed, picked to minimise the number of voxels that would
print unsupported (hanging in mid-air). Pieces that come out support-free are
listed as "no supports"; pieces that still need supports are called out in
the CLI output.

## References

Song, Fu & Cohen-Or. *Recursive Interlocking Puzzles.* ACM Trans. Graph. 31(6), Article 128 (SIGGRAPH Asia 2012). [doi:10.1145/2366145.2366147](https://dl.acm.org/doi/10.1145/2366145.2366147)

## License

GPL-3.0-only. See [LICENSE](LICENSE).
