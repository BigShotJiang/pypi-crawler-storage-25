"""Integration test: brute-force verify recursive interlocking on a small puzzle."""

from ripuzz.io_input import from_dims
from ripuzz.mobility import movable_directions
from ripuzz.puzzle import generate


def _all_non_empty_subsets(items: list):
    n = len(items)
    for mask in range(1, 1 << n):
        yield [items[i] for i in range(n) if mask & (1 << i)]


def _is_interlocking(pieces_vox: list[set]) -> bool:
    """Exactly one piece (or exact complement) is movable; all other subsets are immobile.

    Per paper's Lemma 2, if a subset S1 is movable in +d, its complement S2 can also
    be considered movable in -d (same motion, opposite frame of reference). So we
    consider S1 and its complement equivalent and expect exactly one "class" movable.
    """
    all_voxels: set = set()
    for p in pieces_vox:
        all_voxels |= p

    movable_subsets = 0
    for subset in _all_non_empty_subsets(pieces_vox):
        union_subset: set = set()
        for p in subset:
            union_subset |= p
        if len(union_subset) == len(all_voxels):
            continue  # whole puzzle moves trivially
        context = all_voxels
        if movable_directions(union_subset, context):
            movable_subsets += 1

    # Movable subsets come in complementary pairs (Lemma 2), each representing one
    # actual degree of freedom. Interlocking = exactly 2 movable subsets = one key
    # piece and its complement.
    return movable_subsets == 2


def test_4cube_4pieces_is_recursive_interlocking():
    grid = from_dims(4, 4, 4, voxel_size=1.0)
    result = generate(grid, K=4, seed=0, kerf=0.0, max_retries=40)
    pieces = [p.voxels for p in result.pieces]
    assert len(pieces) == 4

    # Union = whole cube
    union: set = set()
    for p in pieces:
        union |= p
    assert union == set(grid.voxels())

    # Pieces are disjoint
    total = sum(len(p) for p in pieces)
    assert total == len(grid)

    # Recursive interlocking: every postfix [Pi, ..., Pn] is interlocking.
    for i in range(len(pieces) - 1):  # exclude single-piece case
        postfix = pieces[i:]
        assert _is_interlocking(postfix), (
            f"postfix starting at piece {i+1} is not interlocking"
        )
