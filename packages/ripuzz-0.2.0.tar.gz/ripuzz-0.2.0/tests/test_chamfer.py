"""Chamfer behaviour tests.

Some tests require build123d (they go through the real STEP writer). If
build123d is not installed, those tests are skipped.
"""

import json
from pathlib import Path

import pytest

from ripuzz.cli import _parse_chamfer


def test_parse_chamfer_mm():
    assert _parse_chamfer("0.5", 10.0) == pytest.approx(0.5)
    assert _parse_chamfer("0", 10.0) == 0.0


def test_parse_chamfer_percent():
    assert _parse_chamfer("5%", 10.0) == pytest.approx(0.5)
    assert _parse_chamfer("10%", 8.0) == pytest.approx(0.8)
    assert _parse_chamfer("0%", 10.0) == 0.0


def test_parse_chamfer_negative_rejected():
    with pytest.raises(ValueError):
        _parse_chamfer("-0.1", 10.0)
    with pytest.raises(ValueError):
        _parse_chamfer("-1%", 10.0)


def test_parse_chamfer_whitespace_tolerated():
    assert _parse_chamfer("  5% ", 10.0) == pytest.approx(0.5)
    assert _parse_chamfer(" 0.5 ", 10.0) == pytest.approx(0.5)


# ---- STEP-level tests below require build123d ----

pytest.importorskip("build123d")

from ripuzz.io_input import from_dims
from ripuzz.io_output import write_all
from ripuzz.puzzle import Piece, PuzzleResult


def _make_result(grid, pieces, kerf, chamfer):
    ps = [Piece(index=i + 1, voxels=p, removal_dir=(0, 0, 1)) for i, p in enumerate(pieces)]
    return PuzzleResult(
        pieces=ps, grid=grid, seed=0, kerf=kerf, algorithm="Song2012", chamfer=chamfer
    )


def test_chamfer_reduces_volume_preserves_bbox(tmp_path: Path):
    from build123d import import_step

    grid = from_dims(1, 1, 1, voxel_size=10.0)
    piece = {(0, 0, 0)}
    flat = _make_result(grid, [piece], kerf=0.0, chamfer=0.0)
    chamfered = _make_result(grid, [piece], kerf=0.0, chamfer=0.5)

    out_flat = tmp_path / "flat"
    out_cham = tmp_path / "cham"
    write_all(flat, out_flat)
    write_all(chamfered, out_cham)

    f = import_step(str(out_flat / "piece_01.step"))
    c = import_step(str(out_cham / "piece_01.step"))

    # Bounding box unchanged — chamfers cut into the cube, not out of it.
    assert f.bounding_box().size.X == pytest.approx(c.bounding_box().size.X, abs=1e-6)
    assert f.bounding_box().size.Y == pytest.approx(c.bounding_box().size.Y, abs=1e-6)
    assert f.bounding_box().size.Z == pytest.approx(c.bounding_box().size.Z, abs=1e-6)
    # Chamfered part has strictly less volume.
    assert c.volume < f.volume


def test_chamfer_zero_matches_no_chamfer(tmp_path: Path):
    from build123d import import_step

    grid = from_dims(1, 1, 1, voxel_size=10.0)
    piece = {(0, 0, 0)}
    r = _make_result(grid, [piece], kerf=0.0, chamfer=0.0)
    out = tmp_path / "out"
    write_all(r, out)
    obj = import_step(str(out / "piece_01.step"))
    # Plain 10 mm cube volume.
    assert obj.volume == pytest.approx(1000.0, rel=1e-4)


def test_chamfer_recorded_in_manifest(tmp_path: Path):
    grid = from_dims(1, 1, 1, voxel_size=10.0)
    piece = {(0, 0, 0)}
    r = _make_result(grid, [piece], kerf=0.0, chamfer=0.5)
    out = tmp_path / "out"
    write_all(r, out)
    data = json.loads((out / "manifest.json").read_text())
    assert data["chamfer"] == pytest.approx(0.5)
