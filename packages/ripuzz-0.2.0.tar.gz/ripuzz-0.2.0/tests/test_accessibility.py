from ripuzz.accessibility import accessibility


def test_empty_input():
    assert accessibility(set()) == {}


def test_interior_higher_than_corner():
    # 5x5x5 cube
    S = {(x, y, z) for x in range(5) for y in range(5) for z in range(5)}
    a = accessibility(S)
    corner = a[(0, 0, 0)]
    interior = a[(2, 2, 2)]
    edge = a[(0, 0, 2)]
    assert interior > edge > corner


def test_isolated_voxel_has_zero():
    a = accessibility({(0, 0, 0)})
    assert a[(0, 0, 0)] == 0.0
