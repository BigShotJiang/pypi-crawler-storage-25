"""Kerf inset behaviour tests.

These tests require build123d (they go through the real STEP writer). If
build123d is not installed, the tests are skipped.
"""

import pytest

pytest.importorskip("build123d")

from pathlib import Path

from ripuzz.io_input import from_dims
from ripuzz.io_output import write_all
from ripuzz.puzzle import Piece, PuzzleResult


def _make_result(grid, pieces, kerf):
    # Build PuzzleResult directly, bypassing generate() — easier for kerf testing.
    ps = [Piece(index=i + 1, voxels=p, removal_dir=(0, 0, 1)) for i, p in enumerate(pieces)]
    return PuzzleResult(pieces=ps, grid=grid, seed=0, kerf=kerf, algorithm="Song2012")


def test_same_piece_neighbours_fuse_without_gap(tmp_path: Path):
    from build123d import import_step

    grid = from_dims(2, 1, 1, voxel_size=10.0)
    piece_a = {(0, 0, 0), (1, 0, 0)}
    # Single piece covering both voxels — their shared kerf seam should collapse
    # under clean(); outer dimensions retreat by half_kerf on every exterior face.
    result = _make_result(grid, [piece_a], kerf=0.2)
    out = tmp_path / "out"
    write_all(result, out)
    obj = import_step(str(out / "piece_01.step"))
    bbox = obj.bounding_box()
    # 20 x 10 x 10 nominal, shrunk by 0.1 on every face -> 19.8 x 9.8 x 9.8
    assert bbox.size.X == pytest.approx(19.8, abs=1e-4)
    assert bbox.size.Y == pytest.approx(9.8, abs=1e-4)
    assert bbox.size.Z == pytest.approx(9.8, abs=1e-4)
    # And no internal split: volume equals one solid block of those dims.
    assert obj.volume == pytest.approx(19.8 * 9.8 * 9.8, rel=1e-4)


def test_mating_face_has_half_kerf_inset(tmp_path: Path):
    from build123d import import_step

    grid = from_dims(2, 1, 1, voxel_size=10.0)
    piece_a = {(0, 0, 0)}
    piece_b = {(1, 0, 0)}
    result = _make_result(grid, [piece_a, piece_b], kerf=0.2)
    out = tmp_path / "out"
    write_all(result, out)
    a = import_step(str(out / "piece_01.step")).bounding_box()
    b = import_step(str(out / "piece_02.step")).bounding_box()
    # Uniform shrink: every face retreats by half_kerf = 0.1
    # piece A: [0.1, 9.9]; piece B: [10.1, 19.9]
    assert a.min.X == pytest.approx(0.1, abs=1e-4)
    assert a.max.X == pytest.approx(9.9, abs=1e-4)
    assert b.min.X == pytest.approx(10.1, abs=1e-4)
    assert b.max.X == pytest.approx(19.9, abs=1e-4)
    # Gap between mating faces = 0.2 = full kerf
    assert (b.min.X - a.max.X) == pytest.approx(0.2, abs=1e-4)


def test_kerf_zero_has_no_inset(tmp_path: Path):
    from build123d import import_step

    grid = from_dims(2, 1, 1, voxel_size=10.0)
    piece_a = {(0, 0, 0)}
    piece_b = {(1, 0, 0)}
    result = _make_result(grid, [piece_a, piece_b], kerf=0.0)
    out = tmp_path / "out"
    write_all(result, out)
    a = import_step(str(out / "piece_01.step")).bounding_box()
    b = import_step(str(out / "piece_02.step")).bounding_box()
    assert a.max.X == pytest.approx(10.0, abs=1e-4)
    assert b.min.X == pytest.approx(10.0, abs=1e-4)
