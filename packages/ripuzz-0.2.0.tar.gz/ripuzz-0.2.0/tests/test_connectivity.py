from ripuzz.connectivity import connected_components, simply_connected


def test_single_voxel_is_connected():
    assert simply_connected({(0, 0, 0)})


def test_empty_is_not_connected():
    assert not simply_connected(set())


def test_l_shape_is_connected():
    assert simply_connected({(0, 0, 0), (1, 0, 0), (1, 1, 0)})


def test_two_disjoint_voxels():
    assert not simply_connected({(0, 0, 0), (2, 0, 0)})


def test_edge_adjacent_is_not_face_connected():
    # (0,0,0) and (1,1,0) share an edge, not a face
    assert not simply_connected({(0, 0, 0), (1, 1, 0)})


def test_connected_components_count():
    comps = connected_components({(0, 0, 0), (1, 0, 0), (5, 5, 5)})
    assert len(comps) == 2
