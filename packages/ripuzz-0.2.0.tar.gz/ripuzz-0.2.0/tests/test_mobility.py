from ripuzz.grid import DIRS, UP
from ripuzz.mobility import blocked, can_co_move, movable_directions


def test_single_voxel_mobile_in_all_directions_when_alone():
    p = {(0, 0, 0)}
    # context == piece => no others
    assert movable_directions(p, p) == list(DIRS)


def test_piece_blocked_by_neighbour():
    p = {(0, 0, 0)}
    ctx = {(0, 0, 0), (1, 0, 0)}  # neighbour to +X
    assert blocked(p, ctx, (1, 0, 0))
    assert not blocked(p, ctx, (-1, 0, 0))


def test_key_only_up_mobile():
    # 3x3x3 solid cube; piece is the top-center column (1,1,1) + (1,1,2).
    # Floor voxel (1,1,0) stays in context → blocks -Z. Sides blocked. Top is exterior → free.
    context = set()
    for x in range(3):
        for y in range(3):
            for z in range(3):
                context.add((x, y, z))
    piece = {(1, 1, 1), (1, 1, 2)}
    dirs = movable_directions(piece, context)
    assert dirs == [UP]


def test_co_move_blocked_by_rest():
    A = {(0, 0, 0)}
    B = {(1, 0, 0)}
    rest = {(2, 0, 0)}
    assert not can_co_move(A, B, rest, (1, 0, 0))  # B would collide with rest
    assert can_co_move(A, B, rest, (0, 1, 0))  # neither A nor B has something at +Y
