import random

from ripuzz.grid import UP
from ripuzz.io_input import from_dims
from ripuzz.algorithms.experimental import iter_key_pieces as _iter_experimental
from ripuzz.algorithms.song2012 import iter_key_pieces as _iter_song2012


def extract_key_piece(grid, rng, m_target):
    # Prefer the paper-literal implementation; fall back to experimental if it yields nothing.
    for result in _iter_song2012(grid, rng, m_target):
        return result
    for result in _iter_experimental(grid, rng, m_target):
        return result
    return None
from ripuzz.mobility import movable_directions


def test_key_only_removable_up_in_3cube():
    grid = from_dims(3, 3, 3, voxel_size=1.0)
    rng = random.Random(0)
    # m_target large enough to hold anchor-guided path + columns-above.
    result = extract_key_piece(grid, rng, m_target=8)
    assert result is not None
    piece, d = result
    assert d == UP
    S = set(grid.voxels())
    R = S - piece
    assert movable_directions(piece, piece | R) == [UP]


def test_key_is_simply_connected():
    from ripuzz.connectivity import simply_connected

    grid = from_dims(4, 4, 4, voxel_size=1.0)
    rng = random.Random(42)
    result = extract_key_piece(grid, rng, m_target=8)
    assert result is not None
    piece, _ = result
    assert simply_connected(piece)
