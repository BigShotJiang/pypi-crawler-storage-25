from __future__ import annotations

import math
import random
import time
from collections.abc import Iterator
from dataclasses import dataclass

from .algorithms import ALGORITHMS
from .grid import VoxelGrid, Vox


@dataclass
class Piece:
    index: int
    voxels: set[Vox]
    removal_dir: tuple[int, int, int]

    @property
    def is_key(self) -> bool:
        return self.index == 1


@dataclass
class PuzzleResult:
    pieces: list[Piece]
    grid: VoxelGrid
    seed: int
    kerf: float
    algorithm: str
    chamfer: float = 0.0


def generate(
    grid: VoxelGrid,
    K: int,
    seed: int | None = None,
    kerf: float = 0.2,
    chamfer: float = 0.0,
    max_retries: int | None = None,
    timeout: float | None = 15.0,
    algorithm: str = "Song2012",
) -> PuzzleResult:
    """Generate a recursive interlocking puzzle of K pieces.

    Budget: if ``max_retries`` is given, run exactly that many DFS attempts.
    Otherwise retry until ``timeout`` seconds elapse (default 15.0). At least
    one attempt always runs. Pass ``timeout=None`` with ``max_retries=None``
    to retry forever.

    algorithm: "Song2012" (paper-literal) or "experimental" (pragmatic with DFS
    backtracking and anchor-free retry). See ripuzz.algorithms.
    """
    if algorithm not in ALGORITHMS:
        raise ValueError(
            f"unknown algorithm '{algorithm}'. Valid: {sorted(ALGORITHMS.keys())}"
        )
    if K < 3:
        raise ValueError("K must be >= 3 (paper requires at least 3 pieces)")
    N = len(grid)
    if N < K:
        raise ValueError(f"grid has only {N} voxels; cannot produce {K} pieces")
    if max_retries is not None and max_retries < 1:
        raise ValueError("max_retries must be >= 1")
    if timeout is not None and timeout <= 0:
        raise ValueError("timeout must be > 0")
    if chamfer < 0:
        raise ValueError("chamfer must be >= 0")

    base_seed = seed if seed is not None else random.randrange(2**31)
    last_err: str | None = None
    algo = ALGORITHMS[algorithm]

    use_retries = max_retries is not None
    start = time.monotonic()
    attempt = 0
    while True:
        rng = random.Random(base_seed + attempt * 7919)
        try:
            pieces = _search(grid, K, rng, algo)
            return PuzzleResult(
                pieces=pieces,
                grid=grid,
                seed=base_seed,
                kerf=kerf,
                algorithm=algorithm,
                chamfer=chamfer,
            )
        except RuntimeError as e:
            last_err = str(e)
        attempt += 1
        if use_retries:
            if attempt >= max_retries:
                break
        elif timeout is not None and (time.monotonic() - start) >= timeout:
            break

    if use_retries:
        raise RuntimeError(
            f"failed to generate puzzle in {max_retries} attempts "
            f"(algorithm={algorithm}): {last_err}"
        )
    raise RuntimeError(
        f"failed to generate puzzle within {timeout:.1f}s "
        f"({attempt} attempts, algorithm={algorithm}): {last_err}"
    )


def generate_many(
    grid: VoxelGrid,
    K: int,
    seed: int | None = None,
    kerf: float = 0.2,
    chamfer: float = 0.0,
    timeout: float = 60.0,
    algorithm: str = "Song2012",
) -> Iterator[PuzzleResult]:
    """Yield PuzzleResults with different seeds until ``timeout`` elapses.

    Each yielded result carries the concrete seed that produced it (not the
    base seed), so any variant can be reproduced with ``generate(seed=...)``.
    Failed attempts are silently skipped. Always tries at least one seed.
    """
    if algorithm not in ALGORITHMS:
        raise ValueError(
            f"unknown algorithm '{algorithm}'. Valid: {sorted(ALGORITHMS.keys())}"
        )
    if K < 3:
        raise ValueError("K must be >= 3 (paper requires at least 3 pieces)")
    N = len(grid)
    if N < K:
        raise ValueError(f"grid has only {N} voxels; cannot produce {K} pieces")
    if timeout <= 0:
        raise ValueError("timeout must be > 0")
    if chamfer < 0:
        raise ValueError("chamfer must be >= 0")

    base_seed = seed if seed is not None else random.randrange(2**31)
    algo = ALGORITHMS[algorithm]
    start = time.monotonic()
    attempt = 0
    seen: set[tuple[tuple[frozenset[Vox], tuple[int, int, int]], ...]] = set()
    while True:
        current_seed = base_seed + attempt * 7919
        rng = random.Random(current_seed)
        try:
            pieces = _search(grid, K, rng, algo)
            sig = tuple((frozenset(p.voxels), p.removal_dir) for p in pieces)
            if sig not in seen:
                seen.add(sig)
                yield PuzzleResult(
                    pieces=pieces,
                    grid=grid,
                    seed=current_seed,
                    kerf=kerf,
                    algorithm=algorithm,
                    chamfer=chamfer,
                )
        except RuntimeError:
            pass
        attempt += 1
        if (time.monotonic() - start) >= timeout:
            return


def _search(grid: VoxelGrid, K: int, rng: random.Random, algo) -> list[Piece]:
    """DFS over piece candidates; raises RuntimeError if exhausted."""
    S = set(grid.voxels())
    N = len(S)

    def recurse(
        pieces: list[Piece],
        prev_piece: set[Vox] | None,
        prev_dir: tuple[int, int, int] | None,
        R: set[Vox],
        i: int,
    ) -> list[Piece] | None:
        if i > K:
            if R:
                return None
            return pieces
        is_last = (i == K)
        m_current = max(1, math.ceil(len(R) / (K - i + 1)))

        if i == 1:
            gen = algo.iter_key_pieces(grid, rng, m_current)
        else:
            gen = algo.iter_next_pieces(
                grid, rng, prev_piece, prev_dir, R, m_current, is_last
            )

        tried = 0
        cap = 1 if is_last else (20 if i == 1 else 5)
        for piece_voxels, direction in gen:
            tried += 1
            if tried > cap:
                break
            new_pieces = pieces + [Piece(index=i, voxels=piece_voxels, removal_dir=direction)]
            result = recurse(new_pieces, piece_voxels, direction, R - piece_voxels, i + 1)
            if result is not None:
                return result
        return None

    result = recurse([], None, None, S, 1)
    if result is None:
        raise RuntimeError(f"DFS exhausted without finding a valid partition (N={N}, K={K})")
    return result
