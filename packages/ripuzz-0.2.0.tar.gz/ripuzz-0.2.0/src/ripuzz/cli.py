from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .io_input import from_dims, from_step, load_manifest
from .io_output import write_all
from .puzzle import generate, generate_many


def _parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="ripuzz",
        description="Recursive interlocking puzzle generator",
    )
    p.add_argument("--version", action="version", version=f"ripuzz {__version__}")

    src = p.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--size",
        nargs="+",
        type=int,
        metavar="N",
        help="Input as a filled W x H x D prism of voxels. "
        "Pass one value (cube) or three (rectangular prism). "
        "Examples: --size 4  ⇒  4x4x4;  --size 3 4 5  ⇒  3x4x5.",
    )
    src.add_argument(
        "--step",
        type=Path,
        metavar="FILE",
        help="Input as a STEP file (assumed to be a prism).",
    )
    src.add_argument(
        "--manifest",
        type=Path,
        metavar="FILE",
        help="Regenerate outputs from a previously-written manifest.json, "
        "skipping the generator entirely. Mainly a development flag for "
        "rebuilding STEP/GIF files after changes to rendering or geometry "
        "code. Generator-related flags (--pieces, --seed, --kerf, --chamfer, "
        "--voxel-size, --algorithm, --nostop) are ignored; --out is still "
        "required.",
    )

    p.add_argument(
        "--voxel-size",
        type=float,
        default=10.0,
        metavar="MM",
        help="Physical size of one voxel edge, in millimeters (default 10 = 1 cm).",
    )
    p.add_argument(
        "--pieces",
        "-K",
        type=int,
        default=None,
        metavar="K",
        help="Number of puzzle pieces (>= 3). Required unless --manifest is used.",
    )
    p.add_argument(
        "--out",
        type=Path,
        required=True,
        metavar="DIR",
        help="Output directory (will be created if absent).",
    )
    p.add_argument(
        "--kerf",
        type=float,
        default=0.2,
        metavar="MM",
        help="Total clearance per mating face pair, in millimeters (default 0.2). "
        "Use 0 to disable.",
    )
    p.add_argument(
        "--chamfer",
        type=str,
        default="3%",
        metavar="VALUE",
        help="Chamfer applied to all edges of every piece. Covers assembly "
        "lead-in and FDM elephant-foot. Accepts millimeters (e.g. '0.5') "
        "or a percentage of --voxel-size (e.g. '3%%'). Default '3%%'. "
        "Use '0' to disable.",
    )
    p.add_argument(
        "--seed",
        type=int,
        default=None,
        metavar="N",
        help="RNG seed for deterministic output.",
    )
    p.add_argument(
        "--nostop",
        action="store_true",
        help="Keep searching for additional valid configurations (varying the seed) "
        "until --timeout elapses. Each result is written to a numbered subdirectory "
        "DIR/1, DIR/2, ... under --out. Incompatible with --max-retries and --seed.",
    )
    budget = p.add_mutually_exclusive_group()
    budget.add_argument(
        "--timeout",
        type=float,
        default=15.0,
        metavar="SECS",
        help="Wall-clock budget for generation retries (default 15.0). "
        "Ignored if --max-retries is given.",
    )
    budget.add_argument(
        "--max-retries",
        type=int,
        default=None,
        metavar="N",
        help="Fixed number of DFS attempts before giving up. "
        "Overrides --timeout when set.",
    )
    p.add_argument(
        "--algorithm",
        choices=["Song2012", "experimental"],
        default="Song2012",
        help="Which implementation to use. 'Song2012' follows Song/Fu/Cohen-Or 2012 "
        "literally with assumption comments where the paper is ambiguous. "
        "'experimental' is looser with DFS back-tracking and anchor-free retry. "
        "Default: Song2012.",
    )
    return p


def _parse_chamfer(s: str, voxel_size: float) -> float:
    """Resolve --chamfer value: '0.5' is millimeters, '5%' is percent of voxel_size."""
    t = s.strip()
    if t.endswith("%"):
        pct = float(t[:-1])
        if pct < 0:
            raise ValueError(f"--chamfer percent must be >= 0 (got {pct}%)")
        return voxel_size * pct / 100.0
    val = float(t)
    if val < 0:
        raise ValueError(f"--chamfer must be >= 0 (got {val} mm)")
    return val


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)

    if args.manifest is not None:
        ignored = []
        if args.pieces is not None:    ignored.append("--pieces")
        if args.seed is not None:      ignored.append("--seed")
        if args.max_retries is not None: ignored.append("--max-retries")
        if args.nostop:                ignored.append("--nostop")
        # defaults: voxel-size=10.0, kerf=0.2, chamfer='3%', timeout=15.0, algorithm='Song2012'
        if args.voxel_size != 10.0:    ignored.append("--voxel-size")
        if args.kerf != 0.2:           ignored.append("--kerf")
        if args.chamfer != "3%":       ignored.append("--chamfer")
        if args.algorithm != "Song2012": ignored.append("--algorithm")
        if ignored:
            print(
                f"warning: --manifest ignores generator flags: {', '.join(ignored)}",
                file=sys.stderr,
            )
        try:
            result = load_manifest(args.manifest)
        except (FileNotFoundError, KeyError, ValueError) as e:
            print(f"error: could not load '{args.manifest}': {e}", file=sys.stderr)
            return 2
        print(
            f"manifest: loaded {len(result.pieces)} pieces from {args.manifest} "
            f"(seed={result.seed}, grid={result.grid.shape}, "
            f"voxel={result.grid.voxel_size}mm, kerf={result.kerf}, "
            f"chamfer={result.chamfer:.3f}mm)"
        )
        print(f"writing output to {args.out}...")
        report = write_all(result, args.out)
        print(
            f"wrote {len(result.pieces)} piece STEP files, "
            f"printable.step, assembly.gif, manifest.json"
        )
        _print_printability(report)
        return 0

    if args.pieces is None:
        print("error: --pieces is required (unless --manifest is used)", file=sys.stderr)
        return 2
    if args.voxel_size <= 0:
        print("error: --voxel-size must be > 0", file=sys.stderr)
        return 2
    if args.pieces < 3:
        print("error: --pieces must be >= 3", file=sys.stderr)
        return 2
    if args.kerf < 0:
        print("error: --kerf must be >= 0", file=sys.stderr)
        return 2
    try:
        chamfer_mm = _parse_chamfer(args.chamfer, args.voxel_size)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    if args.max_retries is not None and args.max_retries < 1:
        print("error: --max-retries must be >= 1", file=sys.stderr)
        return 2
    if args.timeout <= 0:
        print("error: --timeout must be > 0", file=sys.stderr)
        return 2
    if args.nostop and args.max_retries is not None:
        print("error: --nostop is incompatible with --max-retries", file=sys.stderr)
        return 2
    if args.nostop and args.seed is not None:
        print("error: --nostop cannot be combined with --seed", file=sys.stderr)
        return 2

    if args.size is not None:
        if len(args.size) == 1:
            nx = ny = nz = args.size[0]
        elif len(args.size) == 3:
            nx, ny, nz = args.size
        else:
            print("error: --size takes either 1 value (cube) or 3 values (WxHxD)", file=sys.stderr)
            return 2
        grid = from_dims(nx, ny, nz, args.voxel_size)
        print(f"input: {nx}x{ny}x{nz} filled prism, voxel={args.voxel_size}mm")
    else:
        grid = from_step(args.step, args.voxel_size)
        nx, ny, nz = grid.shape
        print(f"input: STEP '{args.step}' -> {nx}x{ny}x{nz} filled prism, voxel={args.voxel_size}mm")

    print(
        f"generating {args.pieces} pieces "
        f"(algorithm={args.algorithm}, seed={args.seed}, kerf={args.kerf}, "
        f"chamfer={chamfer_mm:.3f}mm)..."
    )

    if args.nostop:
        print(f"--nostop: searching for variants for up to {args.timeout:.1f}s...")
        count = 0
        for result in generate_many(
            grid,
            K=args.pieces,
            seed=args.seed,
            kerf=args.kerf,
            chamfer=chamfer_mm,
            timeout=args.timeout,
            algorithm=args.algorithm,
        ):
            count += 1
            sub = args.out / str(count)
            print(
                f"[{count}] seed={result.seed}, piece voxel counts: "
                f"{[len(p.voxels) for p in result.pieces]} -> {sub}"
            )
            report = write_all(result, sub)
            _print_printability(report)
        if count == 0:
            print("error: no valid configuration found within timeout", file=sys.stderr)
            return 1
        print(f"done. wrote {count} configuration(s) to {args.out}/1..{count}.")
        return 0

    result = generate(
        grid,
        K=args.pieces,
        seed=args.seed,
        kerf=args.kerf,
        chamfer=chamfer_mm,
        max_retries=args.max_retries,
        timeout=args.timeout,
        algorithm=args.algorithm,
    )
    print(f"done. seed={result.seed}. piece voxel counts: "
          f"{[len(p.voxels) for p in result.pieces]}")

    print(f"writing output to {args.out}...")
    report = write_all(result, args.out)
    print(
        f"wrote {len(result.pieces)} piece STEP files, "
        f"printable.step, assembly.gif, manifest.json"
    )
    _print_printability(report)

    return 0


def _print_printability(report: list[tuple[int, str, int]]) -> None:
    total_overhangs = sum(n for _, _, n in report)
    if total_overhangs == 0:
        print("printable.step: all pieces oriented with zero overhangs (no supports needed).")
    else:
        print("printable.step: per-piece orientation and overhanging voxels:")
        for idx, name, n in report:
            flag = "" if n == 0 else f"  <- needs supports ({n} overhang voxels)"
            print(f"  piece {idx}: {name}{flag}")


if __name__ == "__main__":
    raise SystemExit(main())
