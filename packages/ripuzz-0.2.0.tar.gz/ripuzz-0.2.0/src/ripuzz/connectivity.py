from __future__ import annotations

from collections import deque
from typing import Iterable

from .grid import DIRS, Vox, add


def simply_connected(voxels: Iterable[Vox]) -> bool:
    """True iff the voxel set forms a single face-connected component. Empty -> False."""
    s = set(voxels)
    if not s:
        return False
    start = next(iter(s))
    visited: set[Vox] = {start}
    q: deque[Vox] = deque([start])
    while q:
        v = q.popleft()
        for d in DIRS:
            n = add(v, d)
            if n in s and n not in visited:
                visited.add(n)
                q.append(n)
    return len(visited) == len(s)


def connected_components(voxels: Iterable[Vox]) -> list[set[Vox]]:
    remaining = set(voxels)
    comps: list[set[Vox]] = []
    while remaining:
        start = next(iter(remaining))
        comp: set[Vox] = {start}
        q: deque[Vox] = deque([start])
        remaining.discard(start)
        while q:
            v = q.popleft()
            for d in DIRS:
                n = add(v, d)
                if n in remaining:
                    remaining.discard(n)
                    comp.add(n)
                    q.append(n)
        comps.append(comp)
    return comps
