"""Puzzle-generation algorithms.

Two implementations are provided:

- **Song2012** — a paper-literal translation of Song, Fu & Cohen-Or 2012 with
  assumption comments wherever the paper is silent or ambiguous. Use this to
  study / verify the original algorithm.
- **experimental** — a looser implementation with DFS back-tracking, anchor-free
  retry fallback, and column-below-anchor forbidding. Works on a wider range of
  grid/K combinations but diverges from the paper in specific details.

Both modules expose the same two generators:

    iter_key_pieces(grid, rng, m_target, ...) -> Iterator[(set[Vox], Dir)]
    iter_next_pieces(grid, rng, prev_piece, prev_dir, R_i, m_target, is_last, ...)
        -> Iterator[(set[Vox], Dir)]

so `puzzle.py` can dispatch on the `algorithm` parameter.
"""

from . import experimental, song2012

ALGORITHMS = {"Song2012": song2012, "experimental": experimental}
