"""Paper-literal recursive interlocking puzzle generator.

This is a direct translation of Song, Fu & Cohen-Or, *Recursive Interlocking
Puzzles*, ACM TOG 31(6) Article 128 (SIGGRAPH Asia 2012), Sections 5.1 and 5.2.

Every numbered step in the paper is preserved, with each paper quote cited near
the corresponding code. Wherever the paper is silent or ambiguous about a
concrete decision, the ambiguity is flagged with:

    # ASSUMPTION: <what the paper says> -> <what we chose to do>

Paper parameters (taken verbatim):
    - accessibility weight α = 0.1
    - accessibility recursion depth j = 3
    - Nb1 = 50 blocker/blockee candidate pairs
    - Nb2 = 10 pairs kept after accessibility pruning
    - β ∈ [1, 6] for probabilistic voxel sampling
    - localisation bounding-box margin = 10 voxels (§6)

This module intentionally does NOT do DFS back-tracking, multi-candidate
enumeration, column-below-anchor forbidding, or anchor-free retry. Those are
the "experimental" extensions in experimental.py. If this paper-literal version
fails on a given input, the outer retry loop in puzzle.py re-seeds the RNG;
the paper itself describes the outcome in such cases only vaguely ("we retry").

Expected limitation: matches the paper's scope. The paper's 3×3×3 4-piece
Figure 6 is known to succeed *with the authors' tuning*; our best-effort
faithful translation may still not converge on that exact tight case — the
paper does not publish the specific seed or micro-decisions needed.
"""

from __future__ import annotations

import random

from ..accessibility import accessibility
from ..connectivity import simply_connected
from ..grid import DIRS, UP, VoxelGrid, Vox, add
from ..mobility import (
    blocked,
    can_co_move,
    find_blockee_pairs,
    movable_directions,
)
from ..pathing import bfs_shortest_from_set, bfs_shortest_path, furthest_along_axis


# ============================================================================
# §5.1 — Extracting the Key Piece P1
# ============================================================================


def _key_step1_candidate_seeds(
    grid: VoxelGrid, S: set[Vox]
) -> list[tuple[Vox, tuple[int, int, int]]]:
    """§5.1 step 1 — Pick a seed voxel.

    Paper: "we identify a candidate set of exterior voxels that have exactly a
    pair of adjacent exterior faces, with one being on the top [...]. Here we
    require axial free passages, that is, no voxels all the ways above these
    exterior faces."
    """
    # ASSUMPTION: "exactly a pair of adjacent exterior faces" means exactly
    # TWO exterior faces, one of which is +Z (top), and the other is a
    # horizontal direction (±X or ±Y). The paper illustrates this with corner
    # voxels on the top face; "adjacent" rules out the degenerate case where
    # the second face is -Z (which is impossible if the grid has at least 2
    # layers, but we guard anyway).
    out: list[tuple[Vox, tuple[int, int, int]]] = []
    for v in S:
        if not grid.is_exterior_face(v, UP):
            continue
        # Free axial passage above the top face.
        above = add(v, UP)
        free = True
        while grid.in_bounds(above):
            if grid.contains(above):
                free = False
                break
            above = add(above, UP)
        if not free:
            continue
        ext = [d for d in DIRS if grid.is_exterior_face(v, d)]
        if len(ext) != 2:
            continue
        if UP not in ext:
            continue
        other = next(d for d in ext if d != UP)
        if other == (0, 0, -1):
            continue
        out.append((v, other))
    return out


def _column_along(grid: VoxelGrid, v: Vox, d: tuple[int, int, int]) -> list[Vox]:
    out: list[Vox] = []
    u = add(v, d)
    while grid.contains(u):
        out.append(u)
        u = add(u, d)
    return out


def _key_step3_anchors(
    seed: Vox, S: set[Vox], v_n: tuple[int, int, int]
) -> set[Vox]:
    """§5.1 step 3, third strategy — anchor voxels.

    Paper: "we identify an anchor voxel that is directly-connected and furthest
    away from the seed along each initially-blocked direction of the seed,
    e.g., voxel A+x for +X (Figure 9(e)). The key idea is that if these anchor
    voxels stay with the remaining volume (but not added to the key), the key
    can remain to be immobilized in the blocked directions even if we add more
    voxels to it."
    """
    # ASSUMPTION: "initially-blocked direction of the seed" means a direction d
    # such that seed+d ∈ S (the seed has an in-solid neighbour in that direction).
    # UP and v_n are excluded because UP is the removal direction (must be free)
    # and v_n is the direction being actively blocked by the blocker/blockee
    # mechanism (paper's strategies 1 & 2).
    #
    # ASSUMPTION: "directly-connected along d" means the furthest voxel reached
    # by walking from seed one step at a time in direction d while staying in S.
    # (An axis walk, not a BFS; the paper's figure caption "voxel A+x for +X"
    # strongly implies this.)
    anchors: set[Vox] = set()
    for d in DIRS:
        if d == UP or d == v_n:
            continue
        nbr = add(seed, d)
        if nbr not in S:
            continue
        a = furthest_along_axis(seed, d, S)
        if a is not None:
            anchors.add(a)
    return anchors


def _verify_key_mobility(piece: set[Vox], R: set[Vox]) -> bool:
    """Paper §5.1 requirements for P1: movable only in UP, simply connected."""
    return movable_directions(piece, piece | R) == [UP]


def iter_key_pieces(
    grid: VoxelGrid,
    rng: random.Random,
    m_target: int,
    Nb1: int = 50,
    Nb2: int = 10,
    beta: float = 3.0,
):
    """Yield (piece, UP) candidates for the key. Paper §5.1."""
    S = set(grid.voxels())

    # Step 1 — Pick a seed voxel.
    seeds = _key_step1_candidate_seeds(grid, S)
    if not seeds:
        return
    # ASSUMPTION: "From the candidate set, we can either randomly pick a seed,
    # or let the user make a choice." We randomise order via the RNG and
    # iterate, letting the outer retry try different seeds.
    rng.shuffle(seeds)

    for seed, v_n in seeds:
        R0 = S - {seed}

        # Step 2 — Compute voxel accessibility over the remaining volume.
        # Paper: a_0(x) = |neighbours(x)|; a_{j+1}(x) = a_j(x) + α Σ a_j(y);
        # α = 0.1, j up to 3.
        access = accessibility(R0, max_j=3, alpha=0.1)

        # Step 3 — Ensure blocking and mobility.
        # v_n is the normal of the non-upward exterior face of the seed.
        # Find Nb1 pairs of voxels that orient along v_n, nearest to the seed.
        # ASSUMPTION: "pairs that orient along v_n, nearest to the seed" means:
        # for each pivot voxel p ∈ R0 with both p+v_n and p-v_n in R0, the pair
        # is (blocker = p+v_n, blockee = p-v_n). "Nearest" is the Manhattan
        # distance from seed to the pivot p. (The paper's figure shows ovals
        # — the text does not define them geometrically.)
        pairs = find_blockee_pairs(seed, v_n, R0, Nb1=Nb1)
        if not pairs:
            continue

        # Keep Nb2 pairs with the smallest blockee accessibility.
        pairs.sort(key=lambda pr: access.get(pr[1], 0.0))
        pairs = pairs[:Nb2]

        anchors = _key_step3_anchors(seed, S, v_n)

        for blocker, blockee in pairs:
            # ASSUMPTION: if blocker or blockee coincides with an anchor voxel,
            # the two mechanisms conflict (blocker must stay in R, but anchor
            # must also stay in R — fine; but blockee gets added to the key,
            # and anchors cannot go in the key). Skip such pairs. The paper
            # does not address this collision.
            if blocker in anchors or blockee in anchors:
                continue

            piece = _key_try_pair(
                grid, seed, blocker, blockee, S, anchors, access, rng, m_target, beta
            )
            if piece is None:
                continue
            yield piece, UP


def _key_try_pair(
    grid: VoxelGrid,
    seed: Vox,
    blocker: Vox,
    blockee: Vox,
    S: set[Vox],
    anchors: set[Vox],
    access: dict,
    rng: random.Random,
    m_target: int,
    beta: float,
) -> set[Vox] | None:
    """Build P1 for a specific (blocker, blockee) pair. Paper §5.1 step 3 (continued)."""
    R = S - {seed}

    # Strategy 1: shortest path from seed to blockee, not crossing the blocker
    # or any voxel below it.
    # ASSUMPTION: "voxel below" means, per the paper, voxels in the same +Z
    # column as the blocker at strictly lower z — paper §5.1 step 3: "not go
    # through the blocking voxel or any voxel below it, else the blockage is
    # destructed".
    forbidden = {blocker} | set(_column_along(grid, blocker, (0, 0, -1)))

    # Anchors must not enter the piece (strategy 3). The paper doesn't
    # explicitly say the path itself cannot go through anchors — but since
    # path voxels *do* enter the piece, including an anchor voxel in the path
    # would violate the anchor invariant. So we forbid anchors from the path.
    forbidden |= anchors

    # ASSUMPTION: we do not explicitly forbid the column BELOW each anchor.
    # The paper only mentions that for the blocker. This means the "columns
    # above" strategy may try to include a voxel that is an anchor (excluded)
    # and leave a column gap that blocks the key's upward mobility. We rely
    # on the final mobility check to reject such cases.
    allowed_path = R - forbidden

    path = bfs_shortest_path(seed, blockee, allowed_path)
    if path is None:
        return None
    path_new = set(path[1:])  # excludes seed, which is already in piece

    # Strategy 2: include any voxel above the selected shortest path (to
    # preserve upward removability in a single step).
    # ASSUMPTION: "any voxel above" = the entire +Z column from each path
    # voxel up to grid top. We skip voxels that are anchors (cannot be in
    # piece). This matches the paper's "ensure key to be removable upward".
    extras: set[Vox] = set()
    for pv in path:
        for u in _column_along(grid, pv, UP):
            if u != seed and u not in forbidden:
                extras.add(u)

    new_voxels = path_new | extras
    if new_voxels & forbidden:
        return None

    piece = {seed} | new_voxels
    R = S - piece

    # Final check of step 3: the constructed piece must be movable only in UP.
    if not _verify_key_mobility(piece, R):
        return None

    # Step 4 — Expand the key piece toward m voxels.
    piece = _key_step4_expand(
        grid, piece, R, blocker, v_n_from_seed_to_blocker(seed, blocker),
        anchors, access, m_target, rng, beta,
    )
    R = S - piece

    # Step 5 — Confirm.
    # Paper: "gather all the voxels next to the key in a set Rs, and apply a
    # simple flooding algorithm to test whether all voxels in Rs can be
    # visited or not in R2".
    # ASSUMPTION: we use the stronger condition "R is a single connected
    # component" (simply_connected), which implies the paper's condition.
    if not simply_connected(R):
        return None
    if not simply_connected(piece):
        return None
    if not _verify_key_mobility(piece, R):
        return None
    return piece


def v_n_from_seed_to_blocker(seed: Vox, blocker: Vox) -> tuple[int, int, int]:
    # Helper: direction v_n implied by (seed, blocker) — since blocker = pivot + v_n
    # and pivot is between seed and blocker along v_n, this returns v_n.
    # ASSUMPTION: this direction equals the original v_n of the seed (by
    # construction of the pair). We recompute from (blocker - seed) by axis
    # projection as a sanity check; in fact the sign is what we need.
    dx = blocker[0] - seed[0]
    dy = blocker[1] - seed[1]
    dz = blocker[2] - seed[2]
    if abs(dx) > 0 and dy == 0 and dz == 0:
        return (1 if dx > 0 else -1, 0, 0)
    if abs(dy) > 0 and dx == 0 and dz == 0:
        return (0, 1 if dy > 0 else -1, 0)
    if abs(dz) > 0 and dx == 0 and dy == 0:
        return (0, 0, 1 if dz > 0 else -1)
    # Off-axis — fallback: use the largest component.
    a = [abs(dx), abs(dy), abs(dz)]
    axis = a.index(max(a))
    sign = [dx, dy, dz][axis]
    out = [0, 0, 0]
    out[axis] = 1 if sign > 0 else -1
    return (out[0], out[1], out[2])


def _key_step4_expand(
    grid: VoxelGrid,
    piece: set[Vox],
    R: set[Vox],
    blocker: Vox,
    v_n: tuple[int, int, int],
    anchors: set[Vox],
    access: dict,
    m_target: int,
    rng: random.Random,
    beta: float,
) -> set[Vox]:
    """§5.1 step 4 — Expand the key piece.

    Paper: "(i) identify an additional anchor voxel for the direction
    immobilized by the blocking voxel we picked in step 3 [...]. (ii) identify
    candidate voxels resided next to the key but neither at the anchor voxels
    nor below the anchors. For each u_i, we identify also the voxels directly
    above it [...]. if the number of voxels exceeds the number of extra voxels
    the key needs, we remove u_i from the candidate set. Next, we sum the
    accessibility of each u_i and the voxels above it, say sum_i, and normalise
    p_i = sum_i^{-β} to be p̂_i = p_i / Σ p_i [...]. we randomly pick a u_i
    with p̂_i as the probability of choosing it, and expand the key piece.
    These substeps are repeated until the key contains roughly m voxels."
    """
    # Additional anchor for the blocker's direction v_n: walk from blocker in
    # v_n direction, furthest-connected in S.
    # ASSUMPTION: "directly-connected and furthest away from the blocking voxel
    # in direction v_n" is an axis walk from blocker along v_n through S
    # (same interpretation as anchors in step 3).
    S = piece | R
    extra_anchor = furthest_along_axis(blocker, v_n, S)
    if extra_anchor is None:
        # "if no such voxels exist, we use the blocking voxel as the anchor"
        extra_anchor = blocker
    all_anchors = anchors | {extra_anchor}

    # ASSUMPTION: "voxels below the anchors" — paper only says this phrase
    # once, and it's for ±Z structure. We interpret "below" as -Z column
    # below each anchor (as with the blocker).
    below_anchors: set[Vox] = set()
    for a in all_anchors:
        below_anchors |= set(_column_along(grid, a, (0, 0, -1)))

    while len(piece) < m_target:
        # Candidate voxels: next to the key, NOT in anchors, NOT below an anchor.
        cands: set[Vox] = set()
        for v in piece:
            for d in DIRS:
                n = add(v, d)
                if n not in R:
                    continue
                if n in all_anchors or n in below_anchors:
                    continue
                cands.add(n)

        scored: list[tuple[Vox, set[Vox], float]] = []
        for c in cands:
            # Required voxels to add: c plus the voxels directly above it (in
            # S, not just R, per the paper — "voxels directly above it").
            # ASSUMPTION: "directly above" = the +Z column from c upward in S.
            # Stop at grid top; skip anchors (they can't be added).
            required: set[Vox] = {c}
            for u in _column_along(grid, c, UP):
                if u in all_anchors or u in below_anchors:
                    required = set()  # column intersects forbidden — skip candidate
                    break
                if u in R:
                    required.add(u)
                else:
                    # Already in piece or outside S — stop climbing but don't discard c
                    break
            if not required:
                continue
            if len(piece) + len(required) > m_target:
                continue
            # Compute sum_i = Σ accessibility over required.
            sum_i = sum(access.get(u, 0.0) for u in required)
            scored.append((c, required, sum_i))

        if not scored:
            break

        # Probabilistic sampling: p_i ∝ sum_i^{-β}.
        # ASSUMPTION: if sum_i == 0 (isolated voxel), use a small epsilon to
        # avoid division by zero. Paper does not address this corner.
        weights = [(s[2] if s[2] > 0 else 1e-6) ** (-beta) for s in scored]
        total = sum(weights)
        probs = [w / total for w in weights]
        idx = rng.choices(range(len(scored)), weights=probs, k=1)[0]
        _, required, _ = scored[idx]
        piece |= required
        R -= required

    return piece


# ============================================================================
# §5.2 — Extracting Other Puzzle Pieces Pi+1
# ============================================================================


def _perpendicular(d: tuple[int, int, int]) -> list[tuple[int, int, int]]:
    axis = 0 if d[0] != 0 else 1 if d[1] != 0 else 2
    return [x for x in DIRS if x[axis] == 0]


def _next_step1_candidate_seeds(
    prev_piece: set[Vox],
    prev_dir: tuple[int, int, int],
    R_i: set[Vox],
) -> list[tuple[Vox, tuple[int, int, int]]]:
    """§5.2 step 1 — Candidate seed voxels.

    Paper: "we pick voxels (in Ri) next to Pi as candidate seeds, requiring
    them to contact Pi in a direction perpendicular to d_i. [...] we use the
    contact between Pi and Pi+1 to define d_{i+1} for blocking Pi+1 by the
    presence of Pi."
    """
    # ASSUMPTION: a single seed voxel may contact Pi in multiple perpendicular
    # directions; we emit one (seed, d_next) tuple per contact so the caller
    # can try each removal direction independently.
    out: list[tuple[Vox, tuple[int, int, int]]] = []
    for v in R_i:
        for d in DIRS:
            n = add(v, d)
            if n in prev_piece:
                if d[0] * prev_dir[0] + d[1] * prev_dir[1] + d[2] * prev_dir[2] != 0:
                    continue  # not perpendicular to d_i
                out.append((v, d))
    return out


def _next_step2_must_take(
    grid: VoxelGrid, seed: Vox, d_next: tuple[int, int, int], R_i: set[Vox]
) -> list[Vox]:
    """§5.2 step 2 — "all voxels in R_i along d_{i+1}".

    Paper: "we identify all voxels in R_i along d_{i+1} (see the orange
    voxels in Figure 11(d)) since these voxels must be taken to Pi+1 to make
    the candidate removable along d_{i+1}".
    """
    # ASSUMPTION: "along d_{i+1}" means: walk from seed in direction d_{i+1}
    # through the whole grid. Pi voxels encountered become empty space when
    # Pi is removed, so they don't obstruct motion. R_i voxels encountered
    # WOULD obstruct motion and therefore must be taken to Pi+1. Continue
    # walking until we exit the grid.
    # (The figure caption hints at orange voxels spaced apart, consistent
    # with this "skip Pi, collect R_i" interpretation. The paper text alone
    # is ambiguous.)
    out: list[Vox] = []
    u = add(seed, d_next)
    while grid.contains(u):
        if u in R_i:
            out.append(u)
        u = add(u, d_next)
    return out


def _verify_local_interlocking(
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
) -> bool:
    """Paper §5.2 step 3 + §4 requirements.

    [prev, piece, R] interlocking with prev as key:
      (a) prev movable in exactly {prev_dir};
      (b) piece immobilised in full context;
      (c) R immobilised in full context;
      (d) prev and piece cannot co-move along prev_dir;
      (e) piece is movable in d_next once prev is gone (step 5 requirement).
    """
    ctx = prev | piece | R
    if movable_directions(prev, ctx) != [prev_dir]:
        return False
    if movable_directions(piece, ctx):
        return False
    if movable_directions(R, ctx):
        return False
    if can_co_move(prev, piece, R, prev_dir):
        return False
    if d_next not in movable_directions(piece, piece | R):
        return False
    return True


def iter_next_pieces(
    grid: VoxelGrid,
    rng: random.Random,
    prev_piece: set[Vox],
    prev_dir: tuple[int, int, int],
    R_i: set[Vox],
    m_target: int,
    is_last: bool,
    beta: float = 3.0,
):
    """Yield (piece, d_next) candidates for Pi+1. Paper §5.2."""
    if is_last:
        # Paper doesn't explicitly describe the terminal step; by induction
        # Pn = Rn is a single piece once the last local-interlocking step has
        # been applied. We yield it with a perpendicular-to-prev removal
        # direction (Lemma 3), which is the most natural choice.
        piece = set(R_i)
        if not piece:
            return
        perp = _perpendicular(prev_dir)
        d_i = perp[0] if perp else DIRS[0]
        yield piece, d_i
        return

    S = prev_piece | R_i

    # Step 1 — Candidate seeds; rank and keep top 10.
    candidates = _next_step1_candidate_seeds(prev_piece, prev_dir, R_i)
    if not candidates:
        return
    access = accessibility(R_i, max_j=3, alpha=0.1)

    # Paper: "we reduce the number of candidates to ten by the following
    # equally-weighted criteria: (i) smaller accessibility value; (ii) shorter
    # distance to the furthest-away voxel in R_i along d_{i+1}."
    # ASSUMPTION: "equally-weighted" combined score = normalised accessibility
    # + normalised distance, each in [0, 1]. We implement this as a simple
    # sum of the raw values (they're on similar numeric scales for small grids)
    # and randomly break ties — the paper does not specify normalisation.
    ranked: list[tuple[float, Vox, tuple[int, int, int]]] = []
    for seed, d_next in candidates:
        must_take_len = len(_next_step2_must_take(grid, seed, d_next, R_i))
        acc = access.get(seed, 0.0)
        score = acc + must_take_len
        ranked.append((score, seed, d_next))
    rng.shuffle(ranked)
    ranked.sort(key=lambda t: t[0])
    ranked = ranked[:10]

    # Step 2 — Pick the best candidate and build initial Pi+1.
    # Paper: "we sum the accessibility of all the voxels involved in each
    # candidate path (blue voxels in Figure 11(f)), and pick the one with the
    # smallest sum for forming the initial Pi+1".
    # ASSUMPTION: we attempt each ranked candidate in order; the first that
    # yields a valid interlocking Pi+1 is used. This is slightly looser than
    # "smallest sum", but the initial top-10 pruning already applies the
    # accessibility criterion.
    for _, seed, d_next in ranked:
        piece_result = _next_try_seed(
            grid, seed, d_next, prev_piece, prev_dir, R_i, S, access, m_target, rng, beta
        )
        if piece_result is not None:
            yield piece_result


def _next_try_seed(
    grid: VoxelGrid,
    seed: Vox,
    d_next: tuple[int, int, int],
    prev_piece: set[Vox],
    prev_dir: tuple[int, int, int],
    R_i: set[Vox],
    S: set[Vox],
    access: dict,
    m_target: int,
    rng: random.Random,
    beta: float,
) -> tuple[set[Vox], tuple[int, int, int]] | None:
    # Step 2 — initial Pi+1: seed + must_take column along d_next.
    must_take = set(_next_step2_must_take(grid, seed, d_next, R_i))
    piece = {seed} | must_take
    R = R_i - piece
    if not piece.issubset(R_i):
        return None

    # Step 3 — Ensure local interlocking.
    # Paper: "we perform a mobility check for each of the five directions to
    # see if Pi+1 is blocked or not. [...] Only if Pi+1 is movable, we apply
    # the first two strategies in Section 5.1 (step 3) to extend Pi+1 to some
    # blockee voxels for achieving appropriate blocking in related direction(s).
    # For requirement (i) [...] we perform the mobility check on Pi+1 in the
    # presence of both Pi and Ri+1. However, the tricky part for direction
    # d_i is that since Pi+1 should not be co-movable with Pi, we have to
    # perform the mobility check on Pi+1 in the absence of Pi for this
    # particular direction."
    p_or_none, r_or_none = _next_step3_ensure(
        grid, piece, R, prev_piece, prev_dir, d_next, S, access, m_target, rng
    )
    if p_or_none is None or r_or_none is None:
        return None
    piece, R = p_or_none, r_or_none

    # Step 4 — Expand Pi+1 to m voxels.
    # Paper: "Pi+1 can fulfill the local interlocking requirement, but yet we
    # have to expand it to m voxels and check whether Ri+1 is simply connected
    # or not. These are done in the same way as in Section 5.1."
    # ASSUMPTION: "same way as §5.1" means the probabilistic p_i ∝ sum_i^{-β}
    # sampling with column-above enforcement. For non-key pieces, we preserve
    # d_next mobility instead of UP.
    piece, R = _next_step4_expand(
        grid, piece, R, prev_piece, prev_dir, d_next, access, m_target, rng, beta
    )

    # Step 5 — Confirm.
    if not simply_connected(R):
        return None
    if not simply_connected(piece):
        return None
    if not _verify_local_interlocking(piece, R, prev_piece, prev_dir, d_next):
        return None
    return piece, d_next


def _next_step3_ensure(
    grid: VoxelGrid,
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
    S: set[Vox],
    access: dict,
    m_target: int,
    rng: random.Random,
    max_rounds: int = 20,
) -> tuple[set[Vox] | None, set[Vox] | None]:
    """§5.2 step 3 — iteratively extend piece to achieve local interlocking."""
    # ASSUMPTION: the paper applies "the first two strategies of §5.1 step 3"
    # (blocker/blockee + shortest path) in each non-d_next direction where
    # the piece is still movable. It does NOT explicitly say what to do if
    # those strategies fail, nor how to handle R-mobility (the paper requires
    # R-immobility implicitly through the interlocking definition but doesn't
    # describe an explicit extension for it). Our translation:
    #   - For each of the 5 non-d_next directions, if piece is movable there
    #     in the appropriate context (with/without prev depending on direction),
    #     find a voxel to add that blocks it.
    #   - The "appropriate context" for d = prev_dir is (piece | R) — without
    #     prev — to prevent Pi-1 and Pi+1 from co-moving. For other d, context
    #     is (piece | R | prev).
    #   - We do NOT extend for R-mobility. This matches a strict reading of
    #     the paper (R-mobility is a *consequence* of the construction, not
    #     directly enforced). Cases where this fails will be rejected by the
    #     final verify and the caller will try the next seed.
    for _ in range(max_rounds):
        missing: list[tuple[int, int, int]] = []
        for d in DIRS:
            if d == d_next:
                continue
            ctx = (piece | R) if d == prev_dir else (piece | R | prev)
            if not blocked(piece, ctx, d):
                missing.append(d)
        if not missing:
            return piece, R
        if len(piece) >= m_target + 3:
            return None, None

        d = missing[0]
        # Find a voxel w ∈ R such that w+d ∈ (context \ piece) and the path
        # from piece to w stays in R (minus the blocker if it's in R).
        blocker_pool = R if d == prev_dir else (R | prev)
        best = None
        for w in R:
            if w in piece:
                continue
            nbr = add(w, d)
            if nbr == w or nbr in piece or nbr not in blocker_pool:
                continue
            allowed = R - ({nbr} if nbr in R else set())
            path = bfs_shortest_from_set(piece, w, allowed)
            if path is None:
                continue
            path_set = set(path)
            if len(piece) + len(path_set) > m_target + 3:
                continue
            # Don't let the new addition block d_next mobility.
            new_piece = piece | path_set
            new_R = R - path_set
            if d_next not in movable_directions(new_piece, new_piece | new_R):
                continue
            if best is None or len(path_set) < best[0]:
                best = (len(path_set), new_piece, new_R)
        if best is None:
            return None, None
        piece, R = best[1], best[2]

    return None, None


def _next_step4_expand(
    grid: VoxelGrid,
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
    access: dict,
    m_target: int,
    rng: random.Random,
    beta: float,
) -> tuple[set[Vox], set[Vox]]:
    """§5.2 step 4 — expand to m voxels (paper: "same way as §5.1")."""
    while len(piece) < m_target:
        cands: set[Vox] = set()
        for v in piece:
            for d in DIRS:
                n = add(v, d)
                if n in R:
                    cands.add(n)
        scored: list[tuple[Vox, set[Vox], float]] = []
        for c in cands:
            # ASSUMPTION: "same way as §5.1" — §5.1 takes "voxels directly
            # above" as a required addition. For a non-key piece the "exit
            # column" is along d_next (not UP), so we include the column from
            # c in direction d_next that stays in R. This preserves d_next
            # mobility after expansion, just as §5.1's column-above preserves
            # UP mobility.
            required: set[Vox] = {c}
            u = add(c, d_next)
            while grid.contains(u) and u in R:
                required.add(u)
                u = add(u, d_next)
            if len(piece) + len(required) > m_target:
                continue
            new_piece = piece | required
            new_R = R - required
            if not _verify_local_interlocking(new_piece, new_R, prev, prev_dir, d_next):
                continue
            if not simply_connected(new_R):
                continue
            s_acc = sum(access.get(u, 0.0) for u in required)
            scored.append((c, required, s_acc))
        if not scored:
            break
        weights = [(s[2] if s[2] > 0 else 1e-6) ** (-beta) for s in scored]
        total = sum(weights)
        probs = [w / total for w in weights]
        idx = rng.choices(range(len(scored)), weights=probs, k=1)[0]
        piece |= scored[idx][1]
        R -= scored[idx][1]
    return piece, R
