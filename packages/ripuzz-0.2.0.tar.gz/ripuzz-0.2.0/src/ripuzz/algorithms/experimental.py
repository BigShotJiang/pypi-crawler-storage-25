"""Experimental (pragmatic) recursive interlocking puzzle generator.

This is the "what works" implementation — it follows Song, Fu & Cohen-Or 2012
in spirit but diverges in several places that were needed to make the algorithm
robust across a wide range of (grid, K) combinations:

  - Anchor voxels are applied for the KEY piece but with an added "column-below"
    forbid so the "include columns above" strategy never tries to swallow an
    anchor and break upward mobility.
  - For Pi+1 we try the anchor strategy first, then *retry without anchors* if
    strict anchors make the search infeasible — the paper notes anchors are
    "optional" for non-key pieces (§5.2 step 3), so this is consistent.
  - A reactive "extend-to-block" loop closes any remaining mobility gaps after
    the initial construction, for both piece and R.
  - The caller (puzzle.py) does DFS back-tracking across candidate pieces, so
    each generator here can yield multiple results per (seed, pair).

Works on 4×4×4 and larger for K=3..8; 3×3×3 K≥4 is a known gap (see the
song2012 module for the textual algorithm).
"""

from __future__ import annotations

import random

from ..accessibility import accessibility
from ..connectivity import simply_connected
from ..grid import DIRS, UP, VoxelGrid, Vox, add
from ..mobility import blocked, can_co_move, find_blockee_pairs, movable_directions
from ..pathing import bfs_shortest_from_set, bfs_shortest_path, furthest_along_axis


# ---------------------------------------------------------------------------
# Key piece (P1) — §5.1
# ---------------------------------------------------------------------------


def _key_candidate_seeds(grid: VoxelGrid, S: set[Vox]) -> list[tuple[Vox, tuple[int, int, int]]]:
    out: list[tuple[Vox, tuple[int, int, int]]] = []
    for v in S:
        if not grid.is_exterior_face(v, UP):
            continue
        above = add(v, UP)
        free = True
        while grid.in_bounds(above):
            if grid.contains(above):
                free = False
                break
            above = add(above, UP)
        if not free:
            continue
        ext = [d for d in DIRS if grid.is_exterior_face(v, d)]
        if len(ext) != 2:
            continue
        if UP not in ext:
            continue
        other = next(d for d in ext if d != UP)
        if other == (0, 0, -1):
            continue
        out.append((v, other))
    return out


def _key_anchor_set(seed: Vox, S: set[Vox], v_n: tuple[int, int, int]) -> set[Vox]:
    anchors: set[Vox] = set()
    for d in DIRS:
        if d == UP or d == v_n:
            continue
        nbr = add(seed, d)
        if nbr not in S:
            continue
        a = furthest_along_axis(seed, d, S)
        if a is not None:
            anchors.add(a)
    return anchors


def _column_above_S(grid: VoxelGrid, v: Vox) -> list[Vox]:
    out: list[Vox] = []
    u = add(v, UP)
    while grid.contains(u):
        out.append(u)
        u = add(u, UP)
    return out


def _column_below_S(grid: VoxelGrid, v: Vox) -> list[Vox]:
    out: list[Vox] = []
    u = add(v, (0, 0, -1))
    while grid.contains(u):
        out.append(u)
        u = add(u, (0, 0, -1))
    return out


def _verify_key(piece: set[Vox], R: set[Vox]) -> bool:
    return movable_directions(piece, piece | R) == [UP]


def _try_key_pair(
    grid: VoxelGrid,
    seed: Vox,
    blocker: Vox,
    blockee: Vox,
    S: set[Vox],
    anchors: set[Vox],
    rng: random.Random,
    m_target: int,
    beta: float,
) -> set[Vox] | None:
    forbidden = {blocker} | set(_column_below_S(grid, blocker)) | anchors
    for a in anchors:
        forbidden |= set(_column_below_S(grid, a))
    R = S - {seed}
    allowed_path = R - forbidden
    path = bfs_shortest_path(seed, blockee, allowed_path)
    if path is None:
        return None
    path_new = set(path[1:])
    if path_new & forbidden:
        return None
    extras: set[Vox] = set()
    for pv in path:
        for u in _column_above_S(grid, pv):
            if u != seed and u not in forbidden:
                extras.add(u)
    new_voxels = path_new | extras
    if new_voxels & forbidden:
        return None
    piece = {seed} | new_voxels
    m_upper = m_target + 3
    if len(piece) > m_upper:
        return None
    R = S - piece
    if not _verify_key(piece, R):
        return None
    piece = _expand_key(grid, piece, R, forbidden, m_target, rng, beta)
    R = S - piece
    if not simply_connected(R):
        return None
    if not simply_connected(piece):
        return None
    if not _verify_key(piece, R):
        return None
    return piece


def _expand_key(
    grid: VoxelGrid,
    piece: set[Vox],
    R: set[Vox],
    forbidden: set[Vox],
    m_target: int,
    rng: random.Random,
    beta: float,
) -> set[Vox]:
    while len(piece) < m_target:
        access = accessibility(R)
        cands: set[Vox] = set()
        for v in piece:
            for d in DIRS:
                n = add(v, d)
                if n in R and n not in forbidden:
                    cands.add(n)
        scored: list[tuple[Vox, set[Vox], float]] = []
        for c in cands:
            required: set[Vox] = {c}
            for u in _column_above_S(grid, c):
                if u in R and u not in forbidden:
                    required.add(u)
                elif u in forbidden:
                    required = set()
                    break
                else:
                    break
            if not required:
                continue
            if required & forbidden:
                continue
            if len(piece) + len(required) > m_target:
                continue
            new_piece = piece | required
            new_R = R - required
            if not _verify_key(new_piece, new_R):
                continue
            if not simply_connected(new_R):
                continue
            s_acc = sum(access.get(v, 0.0) for v in required)
            scored.append((c, required, s_acc))
        if not scored:
            break
        weights = [(s[2] if s[2] > 0 else 1e-6) ** (-beta) for s in scored]
        total = sum(weights)
        probs = [w / total for w in weights]
        idx = rng.choices(range(len(scored)), weights=probs, k=1)[0]
        piece |= scored[idx][1]
        R -= scored[idx][1]
    return piece


def iter_key_pieces(
    grid: VoxelGrid,
    rng: random.Random,
    m_target: int,
    Nb1: int = 50,
    Nb2: int = 10,
    beta: float = 3.0,
):
    S = set(grid.voxels())
    seeds = _key_candidate_seeds(grid, S)
    if not seeds:
        return
    rng.shuffle(seeds)

    for seed, v_n in seeds:
        anchors = _key_anchor_set(seed, S, v_n)
        R0 = S - {seed}
        pairs = find_blockee_pairs(seed, v_n, R0, Nb1=Nb1)
        if not pairs:
            continue
        access = accessibility(R0)
        pairs.sort(key=lambda pr: access.get(pr[1], 0.0))
        pairs = pairs[:Nb2]

        for blocker, blockee in pairs:
            if blocker in anchors or blockee in anchors:
                continue
            piece = _try_key_pair(grid, seed, blocker, blockee, S, anchors, rng, m_target, beta)
            if piece is not None:
                yield piece, UP


# ---------------------------------------------------------------------------
# Subsequent pieces (Pi+1) — §5.2
# ---------------------------------------------------------------------------


def _perpendicular(d: tuple[int, int, int]) -> list[tuple[int, int, int]]:
    axis = 0 if d[0] != 0 else 1 if d[1] != 0 else 2
    return [x for x in DIRS if x[axis] == 0]


def _voxels_along_R(grid: VoxelGrid, start: Vox, d: tuple[int, int, int], R: set[Vox]) -> list[Vox]:
    out: list[Vox] = []
    u = add(start, d)
    while grid.contains(u):
        if u in R:
            out.append(u)
            u = add(u, d)
        else:
            break
    return out


def _next_candidate_seeds(
    prev_piece: set[Vox],
    prev_dir: tuple[int, int, int],
    R_i: set[Vox],
) -> list[tuple[Vox, tuple[int, int, int]]]:
    out: list[tuple[Vox, tuple[int, int, int]]] = []
    for v in R_i:
        for d in DIRS:
            n = add(v, d)
            if n in prev_piece:
                if (d[0] * prev_dir[0] + d[1] * prev_dir[1] + d[2] * prev_dir[2]) != 0:
                    continue
                out.append((v, d))
    return out


def _next_anchor_set(seed: Vox, S: set[Vox], d_next: tuple[int, int, int]) -> set[Vox]:
    anchors: set[Vox] = set()
    for d in DIRS:
        if d == d_next:
            continue
        nbr = add(seed, d)
        if nbr not in S:
            continue
        a = furthest_along_axis(seed, d, S)
        if a is not None:
            anchors.add(a)
    return anchors


def _needed_piece_directions(
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
) -> list[tuple[int, int, int]]:
    missing: list[tuple[int, int, int]] = []
    for d in DIRS:
        if d == d_next:
            continue
        ctx = (piece | R) if d == prev_dir else (piece | R | prev)
        if not blocked(piece, ctx, d):
            missing.append(d)
    return missing


def _needed_R_directions(
    piece: set[Vox], R: set[Vox], prev: set[Vox]
) -> list[tuple[int, int, int]]:
    ctx = piece | R | prev
    return [d for d in DIRS if not blocked(R, ctx, d)]


def _preserves_d_next(piece: set[Vox], R: set[Vox], d_next: tuple[int, int, int]) -> bool:
    return d_next in movable_directions(piece, piece | R)


def _extend_to_block_piece(
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    d: tuple[int, int, int],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
    forbidden: set[Vox],
    m_upper: int,
) -> tuple[set[Vox], set[Vox]] | None:
    blocker_pool = R if d == prev_dir else (R | prev)
    best: tuple[int, set[Vox], set[Vox]] | None = None
    for w in R:
        if w in piece or w in forbidden:
            continue
        nbr = add(w, d)
        if nbr == w or nbr in piece:
            continue
        if nbr not in blocker_pool:
            continue
        keep_in_R = {nbr} if nbr in R else set()
        allowed = R - keep_in_R - forbidden
        path = bfs_shortest_from_set(piece, w, allowed)
        if path is None:
            continue
        path_set = set(path)
        if path_set & forbidden:
            continue
        if len(piece) + len(path_set) > m_upper:
            continue
        new_piece = piece | path_set
        new_R = R - path_set
        if not _preserves_d_next(new_piece, new_R, d_next):
            continue
        if best is None or len(path_set) < best[0]:
            best = (len(path_set), new_piece, new_R)
    if best is None:
        return None
    return best[1], best[2]


def _extend_to_block_R(
    piece: set[Vox],
    R: set[Vox],
    d: tuple[int, int, int],
    d_next: tuple[int, int, int],
    forbidden: set[Vox],
    m_upper: int,
) -> tuple[set[Vox], set[Vox]] | None:
    best: tuple[int, set[Vox], set[Vox]] | None = None
    for v in R:
        u = add(v, d)
        if u not in R or u == v or u in piece or u in forbidden:
            continue
        allowed = R - {v} - forbidden
        path = bfs_shortest_from_set(piece, u, allowed)
        if path is None:
            continue
        path_set = set(path)
        if path_set & forbidden:
            continue
        if len(piece) + len(path_set) > m_upper:
            continue
        new_piece = piece | path_set
        new_R = R - path_set
        if not _preserves_d_next(new_piece, new_R, d_next):
            continue
        if best is None or len(path_set) < best[0]:
            best = (len(path_set), new_piece, new_R)
    if best is None:
        return None
    return best[1], best[2]


def _ensure_local_interlocking(
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
    forbidden: set[Vox],
    m_upper: int,
    max_rounds: int = 40,
) -> tuple[set[Vox], set[Vox]] | None:
    for _ in range(max_rounds):
        mp = _needed_piece_directions(piece, R, prev, prev_dir, d_next)
        mr = _needed_R_directions(piece, R, prev)
        if not mp and not mr:
            return piece, R
        if mp:
            result = _extend_to_block_piece(
                piece, R, prev, mp[0], prev_dir, d_next, forbidden, m_upper
            )
        else:
            result = _extend_to_block_R(piece, R, mr[0], d_next, forbidden, m_upper)
        if result is None:
            return None
        piece, R = result
    return None


def _verify_local_interlocking(
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
) -> bool:
    ctx = prev | piece | R
    if movable_directions(prev, ctx) != [prev_dir]:
        return False
    if movable_directions(piece, ctx):
        return False
    if movable_directions(R, ctx):
        return False
    if can_co_move(prev, piece, R, prev_dir):
        return False
    ctx2 = piece | R
    if movable_directions(piece, ctx2) != [d_next]:
        return False
    return True


def _expand_next(
    grid: VoxelGrid,
    piece: set[Vox],
    R: set[Vox],
    prev: set[Vox],
    prev_dir: tuple[int, int, int],
    d_next: tuple[int, int, int],
    forbidden: set[Vox],
    m_target: int,
    rng: random.Random,
    beta: float,
) -> tuple[set[Vox], set[Vox]]:
    while len(piece) < m_target:
        access = accessibility(R)
        cands: set[Vox] = set()
        for v in piece:
            for d in DIRS:
                n = add(v, d)
                if n in R and n not in forbidden:
                    cands.add(n)
        scored: list[tuple[Vox, set[Vox], float]] = []
        for c in cands:
            required: set[Vox] = {c}
            u = add(c, d_next)
            while grid.contains(u) and u in R and u not in forbidden:
                required.add(u)
                u = add(u, d_next)
            if required & forbidden:
                continue
            if len(piece) + len(required) > m_target:
                continue
            new_piece = piece | required
            new_R = R - required
            if not _verify_local_interlocking(new_piece, new_R, prev, prev_dir, d_next):
                continue
            if not simply_connected(new_R):
                continue
            s_acc = sum(access.get(v, 0.0) for v in required)
            scored.append((c, required, s_acc))
        if not scored:
            break
        weights = [(s[2] if s[2] > 0 else 1e-6) ** (-beta) for s in scored]
        total = sum(weights)
        probs = [w / total for w in weights]
        idx = rng.choices(range(len(scored)), weights=probs, k=1)[0]
        piece |= scored[idx][1]
        R -= scored[idx][1]
    return piece, R


def _try_next_seed(
    grid: VoxelGrid,
    seed: Vox,
    d_next: tuple[int, int, int],
    prev_piece: set[Vox],
    prev_dir: tuple[int, int, int],
    R_i: set[Vox],
    S: set[Vox],
    m_target: int,
    m_upper: int,
    rng: random.Random,
    beta: float,
) -> tuple[set[Vox], tuple[int, int, int]] | None:
    must_take = set(_voxels_along_R(grid, seed, d_next, R_i))
    initial = {seed} | must_take
    if not initial.issubset(R_i):
        return None
    if len(initial) > m_upper:
        return None

    ctx_with_prev = initial | (R_i - initial) | prev_piece
    ctx_without_prev = initial | (R_i - initial)
    if not blocked(initial, ctx_with_prev, d_next):
        return None
    if blocked(initial, ctx_without_prev, d_next):
        return None

    anchors = _next_anchor_set(seed, S, d_next)
    forbidden_strict = {a for a in anchors if a in R_i} - initial

    res = _ensure_local_interlocking(
        initial, R_i - initial, prev_piece, prev_dir, d_next, forbidden_strict, m_upper
    )
    if res is None:
        res = _ensure_local_interlocking(
            initial, R_i - initial, prev_piece, prev_dir, d_next, set(), m_upper
        )
        if res is None:
            return None
    piece, R = res
    forbidden: set[Vox] = set()
    if not simply_connected(piece):
        return None
    if not simply_connected(R):
        return None
    if not _verify_local_interlocking(piece, R, prev_piece, prev_dir, d_next):
        return None

    target_for_expand = max(m_target, len(piece))
    piece, R = _expand_next(
        grid, piece, R, prev_piece, prev_dir, d_next, forbidden, target_for_expand, rng, beta
    )
    if not simply_connected(R):
        return None
    if not _verify_local_interlocking(piece, R, prev_piece, prev_dir, d_next):
        return None
    return piece, d_next


def iter_next_pieces(
    grid: VoxelGrid,
    rng: random.Random,
    prev_piece: set[Vox],
    prev_dir: tuple[int, int, int],
    R_i: set[Vox],
    m_target: int,
    is_last: bool,
    beta: float = 3.0,
):
    if is_last:
        piece = set(R_i)
        if not piece:
            return
        perp = _perpendicular(prev_dir)
        d_i = perp[0] if perp else DIRS[0]
        yield piece, d_i
        return

    candidates = _next_candidate_seeds(prev_piece, prev_dir, R_i)
    if not candidates:
        return
    access = accessibility(R_i)
    ranked: list[tuple[float, Vox, tuple[int, int, int]]] = []
    for seed, d_next in candidates:
        dist = len(_voxels_along_R(grid, seed, d_next, R_i))
        acc = access.get(seed, 0.0)
        score = acc + 0.5 * dist
        ranked.append((score, seed, d_next))
    rng.shuffle(ranked)
    ranked.sort(key=lambda t: t[0])
    ranked = ranked[:30]

    m_upper = m_target + 3
    S = prev_piece | R_i

    for _, seed, d_next in ranked:
        result = _try_next_seed(
            grid, seed, d_next, prev_piece, prev_dir, R_i, S, m_target, m_upper, rng, beta
        )
        if result is not None:
            yield result
