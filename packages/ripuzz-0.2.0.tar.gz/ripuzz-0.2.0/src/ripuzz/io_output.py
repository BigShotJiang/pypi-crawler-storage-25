from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Callable

from .grid import VoxelGrid, Vox
from .puzzle import Piece, PuzzleResult

if TYPE_CHECKING:
    from build123d import Part


def _nominal_voxel_box(v: Vox, grid: VoxelGrid):
    from build123d import Align, Box, Pos

    s = grid.voxel_size
    ox, oy, oz = grid.origin
    i, j, k = v
    return Pos(ox + i * s, oy + j * s, oz + k * s) * Box(
        s, s, s, align=(Align.MIN, Align.MIN, Align.MIN)
    )


def _piece_solid(
    piece: Piece,
    grid: VoxelGrid,
    kerf: float,
    chamfer: float = 0.0,
) -> "Part":
    """Build a piece STEP body as: fuse nominal voxel boxes → clean same-piece
    seams → uniformly erode the whole piece inward by half_kerf (piece-level
    shrink) → chamfer all edges.

    Piece-level shrink (rather than per-voxel face insets) guarantees a clean
    outer surface with no thin step ledges even at concave corners, which is
    what makes the chamfer step succeed. Clearance between mating pieces is
    still `kerf` because each piece retreats by half_kerf on every face.
    """
    half_kerf = kerf / 2.0
    boxes = [_nominal_voxel_box(v, grid) for v in piece.voxels]
    if not boxes:
        raise ValueError(f"piece {piece.index} has no voxels")
    solid = boxes[0] if len(boxes) == 1 else boxes[0].fuse(*boxes[1:])
    try:
        solid = solid.clean()
    except Exception:
        pass
    if half_kerf > 0.0:
        from build123d import offset as _offset
        try:
            solid = _offset(solid, amount=-half_kerf)
        except Exception as e:
            raise ValueError(
                f"kerf {kerf} mm shrink failed for piece {piece.index}: {e}"
            ) from e
        try:
            solid = solid.clean()
        except Exception:
            pass
    if chamfer > 0.0:
        from build123d import chamfer as _chamfer_op
        try:
            solid = _chamfer_op(solid.edges(), length=chamfer)
        except Exception as e:
            raise ValueError(
                f"chamfer {chamfer} mm is too large for piece {piece.index} "
                f"(reduce --chamfer): {e}"
            ) from e
    return solid


def write_piece_step(piece: Piece, result: PuzzleResult, path: str | Path) -> None:
    from build123d import export_step

    solid = _piece_solid(piece, result.grid, result.kerf, result.chamfer)
    export_step(solid, str(path))


# 6 axis-aligned orientations: pick which piece-face points to -Z (print bed).
# Each entry is (name, voxel_map, rotate_axis, rotate_angle_deg). The voxel_map
# must match the build123d rotation so overhang counting in voxel space reflects
# the printed orientation. rotate_axis=None means no rotation.
_PRINT_ORIENTATIONS: tuple[tuple[str, Callable[[Vox], Vox], str | None, float], ...] = (
    ("-Z_down", lambda v: (v[0],  v[1],  v[2]), None, 0.0),
    ("+Z_down", lambda v: (v[0], -v[1], -v[2]), "X", 180.0),
    ("+X_down", lambda v: (v[2],  v[1], -v[0]), "Y",  90.0),
    ("-X_down", lambda v: (-v[2], v[1],  v[0]), "Y", -90.0),
    ("+Y_down", lambda v: (v[0],  v[2], -v[1]), "X", -90.0),
    ("-Y_down", lambda v: (v[0], -v[2],  v[1]), "X",  90.0),
)


def _count_overhangs(voxels: set[Vox]) -> int:
    xs = [v[0] for v in voxels]
    ys = [v[1] for v in voxels]
    zs = [v[2] for v in voxels]
    ox, oy, oz = min(xs), min(ys), min(zs)
    norm = {(v[0] - ox, v[1] - oy, v[2] - oz) for v in voxels}
    return sum(1 for (i, j, k) in norm if k > 0 and (i, j, k - 1) not in norm)


def _choose_print_orientation(voxels: set[Vox]) -> tuple[str, str | None, float, int]:
    """Pick the axis-aligned orientation with the fewest overhanging voxels.
    Returns (name, rotate_axis, rotate_angle_deg, overhang_count)."""
    best: tuple[str, str | None, float, int] | None = None
    for name, vfn, axis, angle in _PRINT_ORIENTATIONS:
        rotated = {vfn(v) for v in voxels}
        n = _count_overhangs(rotated)
        if best is None or n < best[3]:
            best = (name, axis, angle, n)
    assert best is not None
    return best


def write_combined_step(
    result: PuzzleResult,
    path: str | Path,
    gap: float | None = None,
) -> list[tuple[int, str, int]]:
    """Write all pieces as a single STEP, laid out side by side on the XY plane
    (z_min=0), each oriented to minimize overhangs (resting on an axis-aligned
    face). Intended for one-shot 3D printing.

    Returns a list of (piece_index, orientation_name, overhang_voxel_count) so
    callers can report per-piece support needs.
    """
    from build123d import Axis, Compound, export_step

    grid = result.grid
    s = grid.voxel_size
    g = s if gap is None else gap

    prepared: list[tuple["Part", float, float]] = []
    report: list[tuple[int, str, int]] = []
    for piece in result.pieces:
        solid = _piece_solid(piece, grid, result.kerf, result.chamfer)
        name, axis, angle, overhangs = _choose_print_orientation(piece.voxels)
        report.append((piece.index, name, overhangs))
        if axis == "X":
            solid = solid.rotate(Axis.X, angle)
        elif axis == "Y":
            solid = solid.rotate(Axis.Y, angle)
        bb = solid.bounding_box()
        solid = solid.translate((-bb.min.X, -bb.min.Y, -bb.min.Z))
        w = bb.max.X - bb.min.X
        h = bb.max.Y - bb.min.Y
        prepared.append((solid, w, h))

    # Shelf packing, aim for roughly square overall footprint.
    total_area = sum(w * h for _, w, h in prepared)
    row_width = (total_area ** 0.5) * 1.3 if total_area > 0 else 0.0

    placed = []
    x = 0.0
    y = 0.0
    row_height = 0.0
    for solid, w, h in prepared:
        if x > 0 and x + w > row_width:
            y += row_height + g
            x = 0.0
            row_height = 0.0
        placed.append(solid.translate((x, y, 0.0)))
        x += w + g
        row_height = max(row_height, h)

    compound = Compound(placed)
    export_step(compound, str(path))
    return report


MANIFEST_VERSION = 1


def write_manifest(result: PuzzleResult, path: str | Path) -> None:
    data = {
        "version": MANIFEST_VERSION,
        "seed": result.seed,
        "kerf": result.kerf,
        "chamfer": result.chamfer,
        "voxel_size": result.grid.voxel_size,
        "grid_shape": list(result.grid.shape),
        "origin": list(result.grid.origin),
        "pieces": [
            {
                "index": p.index,
                "removal_direction": list(p.removal_dir),
                "voxel_count": len(p.voxels),
                "voxels": sorted(list(p.voxels)),
            }
            for p in result.pieces
        ],
    }
    Path(path).write_text(json.dumps(data, indent=2))


def write_all(result: PuzzleResult, out_dir: str | Path) -> list[tuple[int, str, int]]:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    width = max(2, len(str(len(result.pieces))))
    for piece in result.pieces:
        fname = out / f"piece_{piece.index:0{width}d}.step"
        write_piece_step(piece, result, fname)
    report = write_combined_step(result, out / "printable.step")
    write_manifest(result, out / "manifest.json")
    try:
        from .viz import render_assembly_gif
        render_assembly_gif(result, out / "assembly.gif")
    except Exception as e:
        import sys
        print(f"warning: could not render assembly.gif: {e}", file=sys.stderr)
    return report
