from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Iterator

import numpy as np

Vox = tuple[int, int, int]
Dir = tuple[int, int, int]

DIRS: tuple[Dir, ...] = (
    (1, 0, 0), (-1, 0, 0),
    (0, 1, 0), (0, -1, 0),
    (0, 0, 1), (0, 0, -1),
)
UP: Dir = (0, 0, 1)


def add(v: Vox, d: Dir) -> Vox:
    return (v[0] + d[0], v[1] + d[1], v[2] + d[2])


def neg(d: Dir) -> Dir:
    return (-d[0], -d[1], -d[2])


def manhattan(a: Vox, b: Vox) -> int:
    return abs(a[0] - b[0]) + abs(a[1] - b[1]) + abs(a[2] - b[2])


@dataclass(frozen=True)
class VoxelGrid:
    occupancy: np.ndarray  # shape (nx, ny, nz), dtype bool
    voxel_size: float
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0)

    @property
    def shape(self) -> tuple[int, int, int]:
        return tuple(int(s) for s in self.occupancy.shape)  # type: ignore[return-value]

    def in_bounds(self, v: Vox) -> bool:
        nx, ny, nz = self.shape
        return 0 <= v[0] < nx and 0 <= v[1] < ny and 0 <= v[2] < nz

    def contains(self, v: Vox) -> bool:
        return self.in_bounds(v) and bool(self.occupancy[v])

    def voxels(self) -> list[Vox]:
        idx = np.argwhere(self.occupancy)
        return [tuple(int(x) for x in row) for row in idx]  # type: ignore[misc]

    def neighbours(self, v: Vox, within: Iterable[Vox] | None = None) -> list[Vox]:
        within_set = set(within) if within is not None else None
        out: list[Vox] = []
        for d in DIRS:
            n = add(v, d)
            if within_set is not None:
                if n in within_set:
                    out.append(n)
            elif self.contains(n):
                out.append(n)
        return out

    def is_exterior_face(self, v: Vox, d: Dir) -> bool:
        """True iff voxel v has no in-solid neighbour in direction d (face is on the outside of S)."""
        if not self.contains(v):
            return False
        n = add(v, d)
        return not self.contains(n)

    def world_center(self, v: Vox) -> tuple[float, float, float]:
        s = self.voxel_size
        ox, oy, oz = self.origin
        return (ox + (v[0] + 0.5) * s, oy + (v[1] + 0.5) * s, oz + (v[2] + 0.5) * s)

    def world_corner(self, v: Vox) -> tuple[float, float, float]:
        s = self.voxel_size
        ox, oy, oz = self.origin
        return (ox + v[0] * s, oy + v[1] * s, oz + v[2] * s)

    def __iter__(self) -> Iterator[Vox]:
        return iter(self.voxels())

    def __len__(self) -> int:
        return int(self.occupancy.sum())
