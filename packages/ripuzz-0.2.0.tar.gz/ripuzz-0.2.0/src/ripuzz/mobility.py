from __future__ import annotations

from typing import Iterable

from .grid import DIRS, Dir, Vox, add, manhattan


def blocked(piece: Iterable[Vox], context: Iterable[Vox], d: Dir) -> bool:
    r"""True iff translating `piece` by one step in direction `d` collides with context\piece.

    `context` is the set of all currently-present voxels (including `piece` itself).
    A collision occurs when the translated image of any voxel in `piece` lands on a
    voxel that is in `context` but not in `piece`.
    """
    p = piece if isinstance(piece, (set, frozenset)) else set(piece)
    c = context if isinstance(context, (set, frozenset)) else set(context)
    others = c - p
    for v in p:
        n = add(v, d)
        if n in others:
            return True
    return False


def movable_directions(piece: Iterable[Vox], context: Iterable[Vox]) -> list[Dir]:
    p = set(piece)
    c = set(context)
    return [d for d in DIRS if not blocked(p, c, d)]


def can_co_move(a: Iterable[Vox], b: Iterable[Vox], rest: Iterable[Vox], d: Dir) -> bool:
    """True iff A and B translated together by d do not collide with rest."""
    union = set(a) | set(b)
    r = set(rest)
    for v in union:
        n = add(v, d)
        if n in r:
            return False
    return True


def find_blockee_pairs(
    seed: Vox,
    v_n: Dir,
    remainder: Iterable[Vox],
    Nb1: int = 50,
) -> list[tuple[Vox, Vox]]:
    """Find up to Nb1 (blocker, blockee) pairs aligned along ±v_n, nearest to the seed.

    A pair is defined around a pivot voxel p in `remainder`: blocker = p + v_n,
    blockee = p - v_n. Both must be in `remainder`. Pairs are ordered by the
    Manhattan distance of the pivot to the seed.

    The key piece will include the blockee (plus shortest path from seed), so
    moving the key toward +v_n would push blockee into blocker (which stays in R).
    """
    R = remainder if isinstance(remainder, (set, frozenset)) else set(remainder)
    pos = v_n
    neg_v = (-v_n[0], -v_n[1], -v_n[2])
    pairs: list[tuple[int, tuple[Vox, Vox]]] = []
    for p in R:
        blocker = add(p, pos)
        blockee = add(p, neg_v)
        if blocker in R and blockee in R:
            pairs.append((manhattan(seed, p), (blocker, blockee)))
    pairs.sort(key=lambda t: t[0])
    return [pr for _, pr in pairs[:Nb1]]
