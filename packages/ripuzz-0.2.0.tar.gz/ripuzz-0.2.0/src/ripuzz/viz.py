from __future__ import annotations

from pathlib import Path

from .grid import VoxelGrid
from .puzzle import Piece, PuzzleResult

# 8 perceptually-distinct, pleasant colors. For K > 8 the palette cycles.
_PALETTE = [
    "#ef4444",  # red
    "#f97316",  # orange
    "#f59e0b",  # amber
    "#10b981",  # emerald
    "#0ea5e9",  # sky
    "#6366f1",  # indigo
    "#a855f7",  # purple
    "#ec4899",  # pink
]


def _piece_color(index: int) -> str:
    return _PALETTE[(index - 1) % len(_PALETTE)]


def _piece_mesh(piece: Piece, grid: VoxelGrid, offset: tuple[float, float, float] = (0, 0, 0)):
    import pyvista as pv

    s = grid.voxel_size
    ox, oy, oz = grid.origin
    ox += offset[0]
    oy += offset[1]
    oz += offset[2]
    meshes = []
    for v in piece.voxels:
        i, j, k = v
        cx = ox + (i + 0.5) * s
        cy = oy + (j + 0.5) * s
        cz = oz + (k + 0.5) * s
        meshes.append(pv.Cube(center=(cx, cy, cz), x_length=s, y_length=s, z_length=s))
    merged = meshes[0]
    for m in meshes[1:]:
        merged = merged.merge(m)
    return merged


def _piece_extent_along(piece: Piece, direction: tuple[int, int, int]) -> int:
    """Piece's voxel-count extent along an axis-aligned unit direction."""
    axis = 0 if direction[0] else (1 if direction[1] else 2)
    coords = [v[axis] for v in piece.voxels]
    return max(coords) - min(coords) + 1


# Shared layout constants for exploded / animated views.
_EXPLODE_ARROW_LENGTH = 4.0   # multiples of voxel_size
_EXPLODE_CUSHION = 0.4        # multiples of voxel_size (each side of arrow)


def _compute_exploded_offsets(
    result: PuzzleResult,
) -> tuple[int, dict[int, tuple[float, float, float]]]:
    """Compute per-piece offsets for the exploded layout.

    Returns (anchor_idx, offsets). The anchor piece (piece K) sits at origin.
    Other pieces are placed along their removal_dir, stacked outward when
    several share one direction, with enough gap to fit a thin arrow.
    """
    from collections import defaultdict

    s = result.grid.voxel_size
    K = len(result.pieces)
    arrow_length = _EXPLODE_ARROW_LENGTH * s
    cushion = _EXPLODE_CUSHION * s
    slot_gap = arrow_length + 2.0 * cushion

    anchor_idx = K
    anchor_piece = result.pieces[anchor_idx - 1]

    by_dir: dict[tuple[int, int, int], list[Piece]] = defaultdict(list)
    for p in result.pieces:
        if p.index == anchor_idx:
            continue
        by_dir[p.removal_dir].append(p)
    for group in by_dir.values():
        group.sort(key=lambda p: -p.index)

    offsets: dict[int, tuple[float, float, float]] = {anchor_idx: (0.0, 0.0, 0.0)}
    for direction, group in by_dir.items():
        dx, dy, dz = direction
        cursor = _piece_extent_along(anchor_piece, direction) * s / 2.0 + slot_gap
        for piece in group:
            half_extent = _piece_extent_along(piece, direction) * s / 2.0
            cursor += half_extent
            offsets[piece.index] = (dx * cursor, dy * cursor, dz * cursor)
            cursor += half_extent + slot_gap
    return anchor_idx, offsets


def render_assembly_gif(
    result: PuzzleResult,
    path: str | Path,
    size: tuple[int, int] = (800, 800),
    fps: int = 15,
    frames_per_piece: int = 20,
) -> None:
    """Render a seamlessly looping GIF of the assembly sequence. Starts with
    all pieces in their exploded positions (anchor piece K at centre, others
    placed along their removal directions with stacking when several share
    one axis). Pieces slide into place in reverse removal order (piece K-1,
    K-2, ..., piece 1 = key last). Holds on the assembled puzzle for a
    second, then disassembles in removal order (piece 1 out first, ...,
    piece K-1 last) so the final frame matches the first for a clean loop.

    Requires pyvista with imageio (pyvista's default GIF backend). Raises on
    failure — the caller decides whether to swallow.
    """
    import pyvista as pv

    grid = result.grid
    K = len(result.pieces)
    anchor_idx, offsets = _compute_exploded_offsets(result)

    plotter = pv.Plotter(off_screen=True, window_size=size)
    plotter.set_background("white")

    actors: dict[int, object] = {}
    for piece in result.pieces:
        # Build each piece at its assembled position; animate by translating
        # the actor from its exploded offset back to (0, 0, 0).
        mesh = _piece_mesh(piece, grid, offset=(0.0, 0.0, 0.0))
        actor = plotter.add_mesh(
            mesh,
            color=_piece_color(piece.index),
            show_edges=True,
            edge_color="black",
            line_width=0.5,
            opacity=1.0,
        )
        actor.position = offsets[piece.index]  # start fully exploded
        actors[piece.index] = actor

    plotter.view_isometric()
    # Frame the camera around the full exploded scene so nothing clips.
    plotter.reset_camera()

    plotter.open_gif(str(path), fps=fps)

    # Initial hold on the exploded view.
    for _ in range(max(1, fps // 3)):
        plotter.write_frame()

    # Smoothstep so pieces ease in/out instead of moving at constant velocity.
    def smoothstep(t: float) -> float:
        return t * t * (3.0 - 2.0 * t)

    # Animate piece K-1, K-2, ..., 1 — each from its exploded offset to origin.
    # Piece K (anchor) is already at origin so it needs no motion.
    for idx in range(K - 1, 0, -1):
        ox, oy, oz = offsets[idx]
        for f in range(1, frames_per_piece + 1):
            t = smoothstep(f / frames_per_piece)
            actors[idx].position = (
                ox * (1.0 - t),
                oy * (1.0 - t),
                oz * (1.0 - t),
            )
            plotter.write_frame()

    # Hold on the fully assembled puzzle.
    for _ in range(fps):
        plotter.write_frame()

    # Disassemble in removal order: piece 1 out first, then 2, ..., K-1.
    # Ending frame lands back at the fully-exploded state, matching frame 1
    # so the GIF loop is seamless.
    for idx in range(1, K):
        ox, oy, oz = offsets[idx]
        for f in range(1, frames_per_piece + 1):
            t = smoothstep(f / frames_per_piece)
            actors[idx].position = (ox * t, oy * t, oz * t)
            plotter.write_frame()

    plotter.close()
