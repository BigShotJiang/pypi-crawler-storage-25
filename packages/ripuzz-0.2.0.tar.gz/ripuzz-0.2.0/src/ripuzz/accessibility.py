from __future__ import annotations

from typing import Iterable

import numpy as np

from .grid import DIRS, Vox


def accessibility(
    voxels: Iterable[Vox],
    max_j: int = 3,
    alpha: float = 0.1,
) -> dict[Vox, float]:
    """Recursive accessibility per paper (Section 5.1 step 2).

    a0(x)   = number of in-set neighbours of x
    a_{j+1}(x) = a_j(x) + alpha * sum_{y in neighbours(x) in set} a_j(y)

    Higher value = more "interior"; lower value = more peripheral, likely to be
    fragmented. The paper uses max_j=3, alpha=0.1.
    """
    S = set(voxels)
    if not S:
        return {}

    # Work in a local bbox for speed.
    xs = [v[0] for v in S]
    ys = [v[1] for v in S]
    zs = [v[2] for v in S]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    minz, maxz = min(zs), max(zs)
    nx, ny, nz = maxx - minx + 1, maxy - miny + 1, maxz - minz + 1

    def idx(v: Vox) -> tuple[int, int, int]:
        return v[0] - minx, v[1] - miny, v[2] - minz

    mask = np.zeros((nx, ny, nz), dtype=bool)
    for v in S:
        mask[idx(v)] = True

    # a0: count in-set neighbours.
    a = np.zeros((nx, ny, nz), dtype=np.float64)
    for dx, dy, dz in DIRS:
        shifted = np.roll(mask, shift=(dx, dy, dz), axis=(0, 1, 2))
        # zero out wrap-around on each axis
        if dx == 1:
            shifted[0, :, :] = False
        elif dx == -1:
            shifted[-1, :, :] = False
        if dy == 1:
            shifted[:, 0, :] = False
        elif dy == -1:
            shifted[:, -1, :] = False
        if dz == 1:
            shifted[:, :, 0] = False
        elif dz == -1:
            shifted[:, :, -1] = False
        a += shifted.astype(np.float64)
    a *= mask  # restrict to in-set voxels

    # Iterate j=1..max_j: a <- a + alpha * sum of a over in-set neighbours.
    for _ in range(max_j):
        nb_sum = np.zeros_like(a)
        for dx, dy, dz in DIRS:
            shifted_a = np.roll(a, shift=(dx, dy, dz), axis=(0, 1, 2))
            shifted_m = np.roll(mask, shift=(dx, dy, dz), axis=(0, 1, 2))
            if dx == 1:
                shifted_a[0, :, :] = 0.0
                shifted_m[0, :, :] = False
            elif dx == -1:
                shifted_a[-1, :, :] = 0.0
                shifted_m[-1, :, :] = False
            if dy == 1:
                shifted_a[:, 0, :] = 0.0
                shifted_m[:, 0, :] = False
            elif dy == -1:
                shifted_a[:, -1, :] = 0.0
                shifted_m[:, -1, :] = False
            if dz == 1:
                shifted_a[:, :, 0] = 0.0
                shifted_m[:, :, 0] = False
            elif dz == -1:
                shifted_a[:, :, -1] = 0.0
                shifted_m[:, :, -1] = False
            nb_sum += shifted_a * shifted_m.astype(np.float64)
        a = a + alpha * nb_sum
        a *= mask

    out: dict[Vox, float] = {}
    for v in S:
        i, j, k = idx(v)
        out[v] = float(a[i, j, k])
    return out
