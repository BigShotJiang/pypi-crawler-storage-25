from __future__ import annotations

from collections import deque
from typing import Iterable

from .grid import DIRS, Vox, add


def furthest_along_axis(
    start: Vox,
    d: tuple[int, int, int],
    allowed: set[Vox],
) -> Vox | None:
    """Walk from start+d along direction d through `allowed`. Return the last voxel reached.

    This is the "anchor voxel" computation from the paper (§5.1 step 3, third strategy):
    the furthest voxel directly-connected to `start` along the `d` axis that lies in
    `allowed`. Returns None if start+d is not in `allowed`.
    """
    u = add(start, d)
    if u not in allowed:
        return None
    last = u
    while True:
        nxt = add(last, d)
        if nxt not in allowed:
            break
        last = nxt
    return last


def bfs_shortest_from_set(
    sources: set[Vox],
    dst: Vox,
    allowed: set[Vox],
) -> list[Vox] | None:
    """Shortest path from any voxel in `sources` to `dst`, stepping through `allowed`.

    The path is returned INCLUDING dst but EXCLUDING the source (voxels already
    in the piece). If no path exists, return None.
    """
    if dst in sources:
        return []  # already reached
    prev: dict[Vox, Vox] = {}
    visited: set[Vox] = set(sources)
    q: deque[Vox] = deque()
    for s in sources:
        for d in DIRS:
            n = add(s, d)
            if n == dst:
                return [dst]
            if n in allowed and n not in visited:
                visited.add(n)
                prev[n] = s
                q.append(n)
    while q:
        v = q.popleft()
        for d in DIRS:
            n = add(v, d)
            if n in visited:
                continue
            if n == dst:
                path = [dst, v]
                cur = v
                while cur in prev:
                    cur = prev[cur]
                    if cur in sources:
                        break
                    path.append(cur)
                path.reverse()
                return path
            if n in allowed:
                visited.add(n)
                prev[n] = v
                q.append(n)
    return None


def bfs_shortest_path(
    src: Vox,
    dst: Vox,
    allowed: set[Vox],
    forbidden: set[Vox] | None = None,
) -> list[Vox] | None:
    """Shortest voxel path from src to dst moving through `allowed` only.

    Returned path includes src and dst. Neither src nor dst need to be in `allowed`;
    the search expands from src through `allowed` and stops when a neighbour equals
    dst. If dst is not reachable, returns None.
    `forbidden` voxels may not appear on the path (takes precedence).
    """
    forb = forbidden or set()
    if src == dst:
        return [src]
    prev: dict[Vox, Vox] = {}
    visited: set[Vox] = {src}
    q: deque[Vox] = deque([src])
    while q:
        v = q.popleft()
        for d in DIRS:
            n = add(v, d)
            if n in forb or n in visited:
                continue
            if n != dst and n not in allowed:
                continue
            prev[n] = v
            if n == dst:
                path = [dst]
                cur = v
                while cur != src:
                    path.append(cur)
                    cur = prev[cur]
                path.append(src)
                path.reverse()
                return path
            visited.add(n)
            q.append(n)
    return None


def furthest_connected(
    anchor_src: Vox,
    direction,
    allowed: Iterable[Vox],
) -> Vox | None:
    """Return the voxel in `allowed` reachable from anchor_src (via `allowed`)
    that lies along the positive direction axis and is furthest away along that
    axis. If none, return None.

    Used for 'anchor voxel' identification in the paper (Section 5.1, step 3).
    """
    A = set(allowed)
    if anchor_src not in A:
        return None
    visited: set[Vox] = {anchor_src}
    q: deque[Vox] = deque([anchor_src])
    furthest = anchor_src
    axis = 0 if direction[0] != 0 else 1 if direction[1] != 0 else 2
    sign = direction[axis]
    while q:
        v = q.popleft()
        # prefer voxels along the axis line from anchor_src
        if all(v[i] == anchor_src[i] for i in range(3) if i != axis):
            if (v[axis] - anchor_src[axis]) * sign > (furthest[axis] - anchor_src[axis]) * sign:
                furthest = v
        for d in DIRS:
            n = add(v, d)
            if n in A and n not in visited:
                visited.add(n)
                q.append(n)
    if furthest == anchor_src:
        return None
    return furthest
