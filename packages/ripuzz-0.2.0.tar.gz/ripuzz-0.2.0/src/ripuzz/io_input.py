from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .grid import VoxelGrid
from .puzzle import Piece, PuzzleResult


def from_dims(
    nx: int,
    ny: int,
    nz: int,
    voxel_size: float,
    origin: tuple[float, float, float] = (0.0, 0.0, 0.0),
) -> VoxelGrid:
    """Filled rectangular prism of nx*ny*nz unit voxels."""
    if nx < 1 or ny < 1 or nz < 1:
        raise ValueError("dimensions must be >= 1")
    occ = np.ones((nx, ny, nz), dtype=bool)
    return VoxelGrid(occupancy=occ, voxel_size=voxel_size, origin=origin)


def from_step(path: str | Path, voxel_size: float) -> VoxelGrid:
    """Voxelize a STEP file (assumes the file contains a single prism).

    Takes the axis-aligned bounding box and fills it. The bbox dimensions must be
    integer multiples of `voxel_size` (within tolerance `voxel_size/100`).
    """
    from build123d import import_step

    obj = import_step(str(path))
    bbox = obj.bounding_box()
    dx = bbox.size.X
    dy = bbox.size.Y
    dz = bbox.size.Z
    tol = voxel_size / 100.0

    def _to_int_dim(d: float, name: str) -> int:
        n = round(d / voxel_size)
        if abs(n * voxel_size - d) > tol:
            raise ValueError(
                f"STEP bounding box {name}-extent {d} is not an integer multiple of "
                f"voxel_size {voxel_size} (tolerance {tol})"
            )
        return int(n)

    nx = _to_int_dim(dx, "X")
    ny = _to_int_dim(dy, "Y")
    nz = _to_int_dim(dz, "Z")
    if nx < 1 or ny < 1 or nz < 1:
        raise ValueError(f"bounding box has zero extent in some axis: {dx},{dy},{dz}")
    origin = (float(bbox.min.X), float(bbox.min.Y), float(bbox.min.Z))
    return from_dims(nx, ny, nz, voxel_size, origin=origin)


def load_manifest(manifest_path: str | Path) -> PuzzleResult:
    """Reconstruct a PuzzleResult from a previously-written manifest.json.

    Used by `--manifest` to regenerate the STEP/GIF outputs without running
    the puzzle generator again. All fields (piece assignments, removal
    directions, voxel size, kerf, chamfer, seed, algorithm) are read back
    from the manifest.
    """
    path = Path(manifest_path)
    if not path.is_file():
        raise FileNotFoundError(f"no such file: {path}")
    data = json.loads(path.read_text())

    # Missing "version" = pre-versioning manifest; treat as version 1.
    manifest_version = int(data.get("version", 1))
    if manifest_version != 1:
        raise ValueError(
            f"unsupported manifest version {manifest_version}; this ripuzz "
            "only understands manifest version 1"
        )

    nx, ny, nz = data["grid_shape"]
    ox, oy, oz = data["origin"]
    grid = from_dims(
        int(nx),
        int(ny),
        int(nz),
        float(data["voxel_size"]),
        origin=(float(ox), float(oy), float(oz)),
    )

    pieces: list[Piece] = []
    for p in data["pieces"]:
        voxels = {tuple(int(c) for c in v) for v in p["voxels"]}
        direction = tuple(int(c) for c in p["removal_direction"])
        pieces.append(
            Piece(index=int(p["index"]), voxels=voxels, removal_dir=direction)
        )
    pieces.sort(key=lambda p: p.index)

    return PuzzleResult(
        pieces=pieces,
        grid=grid,
        seed=int(data["seed"]),
        kerf=float(data["kerf"]),
        algorithm=str(data.get("algorithm", "")),
        chamfer=float(data.get("chamfer", 0.0)),
    )
