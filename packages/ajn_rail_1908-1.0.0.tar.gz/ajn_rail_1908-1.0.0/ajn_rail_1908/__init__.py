"""Curated Src Span"""
__version__ = "1.0.0"
