# topsyde-llm-wiki-mcp

MCP server exposing `llm-wiki` second-brain queries to AI agents.

## Environment

- `LLM_WIKI_ROOT` - absolute path to the `llm-wiki` repository
- `LLM_WIKI_PROJECT` - optional default project key
- `MODEL` - optional backend selector passed through to the query engine

## Commands

```bash
uv sync
uv run llm_wiki_mcp.py
uvx topsyde-llm-wiki-mcp
```

## Deployment

See `DEPLOYMENT.md` for the PyPI release flow and the runtime `LLM_WIKI_ROOT` requirement.
