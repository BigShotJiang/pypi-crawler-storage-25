# SPDX-FileCopyrightText: 2026-present Clef Knightfury <clef@knightfury.org>
#
# SPDX-License-Identifier: MIT
__version__ = "0.2.0"
