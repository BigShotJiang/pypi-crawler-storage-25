# Roadmap

This Document is simply for planning purposes.  There is no associated timeline, or order.

Some items may be large future features, intent to make a minor change in a future coding session, or notes putting something on hold while consider how I want to handle something.

## Planned
> [!NOTE]
> Essentials for 1.0 release - any changes before 1.0 are not guaranteed to not be breaking changes.
> Breaking changes will have major version bump after 1.0 release.  Detamap standards are in flux and may change at any time before that.

- ~~Move \__init__ operations to separate callable method, instead of auto-running conversion upon object consideration.~~
- ~~Move Fields key in detamap to required sub-key in Output.~~
- ~~Add default processing~~
- Add operations
    - ~~All python string methods (if operation matches a string method, it will be used)~~
    - ~~Slice operation.  Argument list should be [start, stop[, step]].  Uses python's slice object.~~
        - ~~Arguments should be integers, but the string "None" can be passed in cases where the default (omitting) the value is desired, and will be converted to None value.~~
    - ~~convert value mapping operation~~
    - format date / time / timestamp
    - merge / split fields operation with delimiter options
    - ~~filter operation exclude / include~~
        - add regex
    - math operations
        - binary between two fields
        - binary between a field and a detamap provided value (such as multiply decimal "Percent" field by 100)
    - ~~cast operation to type cast a field~~
        - ~~example: cast values to int or float before using an include or exclude filter for values < or > a given value.~~
    - ~~create new field operation~~
        - ~~Defaults section typically preferred, but create operation can be used to create fields needed for a users sequence of operations.~~
    - add internationalization to detamaps
- Add detaplexing
- Add detapipes
- Add TOML support for detamaps
- Add handling for non-CSV files

## Wishlist
> [!NOTE]
> Big WISHLIST down the line, may not actually do, as not essential to current needs.
> Would like to minimize third party library uage for security purposes.  May not incorporate some of these features due to security or technical reasons.

- Add excel file support
- Add PDF reading
- Add PDF field completion for output