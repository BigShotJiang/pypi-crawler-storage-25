"""Async client for one round-trip to ``/api/v3/runInferenceTranscript``.

Library entry point — :class:`NotionAgentClient`. Loads the credential
file, builds the chat-panel-equivalent payload, POSTs it, streams the
NDJSON response, returns a :class:`~notion_agent_cli.types.ChatResponse`.

Scope (MVP):
- new thread per call by default; continuation via ``thread_id=`` +
  per-thread state under ``~/.notionagents/threads/``
- ``asPatchResponse=true`` (precise chat-panel mirror)
- Jarvis-style custom-agent binding via account file (recommended)
- text + token usage + thinking (thinking captured but not surfaced)
- optional ``on_text_delta`` callback for streaming consumers

Out of scope (see docs/ROADMAP.md):
- per-day / per-agent rolling thread strategy (rotating threads
  automatically; current API forces the caller to track thread ids)
- file attachments / image generation
- token_v2 auto-refresh (it's a long-lived JWT; on 401 we raise and
  the operator re-bootstraps the account file)
"""
from __future__ import annotations

import logging
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import httpx

from notion_agent_cli.account import (
    NotionAccount,
    build_cookie_header,
    load_notion_account,
)
from notion_agent_cli.exceptions import ErrorCode, NotionAgentError
from notion_agent_cli.models import load_user_model_map, resolve_model
from notion_agent_cli.ndjson import NDJSONStreamParser
from notion_agent_cli.thread_state import (
    ThreadState,
    load_thread_state,
    save_thread_state,
)
from notion_agent_cli.transcript import (
    _now_iso,
    build_full_transcript,
    build_inference_request,
    build_partial_transcript,
    new_uuid,
)
from notion_agent_cli.types import ChatResponse, TokenUsage

log = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://www.notion.so/api/v3"
DEFAULT_TIMEOUT = httpx.Timeout(connect=10.0, read=300.0, write=30.0, pool=10.0)


@dataclass(slots=True)
class _PreparedCall:
    """Internal — output of :meth:`NotionAgentClient._prepare_call`.

    Carries the URL/body/headers ready to POST, plus a ``save_state``
    closure that persists thread continuation state on success.
    """
    url: str
    body: dict[str, Any]
    headers: dict[str, str]
    active_thread_id: str
    notion_model: str
    save_state: Callable[[], None]


def build_headers(
    acc: NotionAccount,
    *,
    accept: str = "application/x-ndjson",
) -> dict[str, str]:
    """Headers mirroring captured chat-panel traffic.

    Notion-specific headers (``x-notion-active-user-header`` /
    ``x-notion-space-id`` / ``notion-client-version``) are the ones the
    server actually validates; ``sec-ch-ua`` / ``sec-fetch-*`` are
    fingerprint hygiene to stay indistinguishable from a real browser.

    ``accept`` defaults to ``application/x-ndjson`` (the inference
    endpoint) — pass ``application/json`` for ancillary endpoints like
    ``/getAvailableModels`` that return a single JSON document.
    """
    return {
        "accept":                      accept,
        "accept-language":             "en-US,en;q=0.9",
        "content-type":                "application/json",
        "notion-audit-log-platform":   "web",
        "notion-client-version":       acc.client_version,
        "origin":                      "https://www.notion.so",
        "referer":                     "https://www.notion.so/ai",
        "user-agent":                  acc.user_agent,
        "x-notion-active-user-header": acc.user_id,
        "x-notion-space-id":           acc.space_id,
        "sec-ch-ua":          '"Not-A.Brand";v="24", "Chromium";v="146"',
        "sec-ch-ua-mobile":   "?0",
        "sec-ch-ua-platform": '"macOS"',
        "sec-fetch-dest":     "empty",
        "sec-fetch-mode":     "cors",
        "sec-fetch-site":     "same-origin",
        "cookie":             build_cookie_header(acc),
    }


class NotionAgentClient:
    """Direct caller for Notion's ✦ AI chat inference endpoint."""

    def __init__(
        self,
        account_path: Path | str,
        *,
        base_url: str | None = None,
        http_client: httpx.AsyncClient | None = None,
        as_patch_response: bool = True,
        generate_title: bool = True,
        model_map_path: Path | str | None = None,
        thread_state_dir: Path | str | None = None,
    ):
        self.account_path = Path(account_path).expanduser()
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.as_patch_response = as_patch_response
        self.generate_title = generate_title
        # None → resolve_model loads the default `~/.notionagents/models.json`
        # lazily; explicit Path lets tests inject a fixture file.
        self.model_map_path = (
            Path(model_map_path).expanduser() if model_map_path else None
        )
        # None → thread_state defaults to `~/.notionagents/threads/`; tests
        # point at tmp_path to avoid touching the user's home directory.
        self.thread_state_dir = (
            Path(thread_state_dir).expanduser() if thread_state_dir else None
        )

        self._account: NotionAccount | None = None
        self._client: httpx.AsyncClient | None = http_client
        # Tests inject a client → we shouldn't close it on aclose().
        self._owns_client = http_client is None
        self._user_map_cache: dict[str, str] | None = None

    # ----------------------------- account ---------------------------- #

    def load_account(self) -> NotionAccount:
        if self._account is None:
            self._account = load_notion_account(self.account_path)
        return self._account

    def _get_user_model_map(self) -> dict[str, str]:
        if self._user_map_cache is None:
            self._user_map_cache = load_user_model_map(self.model_map_path)
        return self._user_map_cache

    # ----------------------------- http ------------------------------- #

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=DEFAULT_TIMEOUT, http2=False)
        return self._client

    async def aclose(self) -> None:
        if self._owns_client and self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> NotionAgentClient:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    # ----------------------------- prep ------------------------------- #

    def _prepare_call(
        self,
        *,
        prompt: str,
        system: str | None,
        model: str | None,
        web_search: bool,
        workspace_search: bool,
        ask_mode: bool,
        thread_id: str | None,
    ) -> _PreparedCall:
        """Build URL/body/headers + a state-save closure.

        Shared by :meth:`complete` and :meth:`stream_lines` so the
        request-building logic doesn't drift between them. The
        ``save_state`` closure persists the thread state for the next
        ``--thread-id`` continuation — call it only after the HTTP call
        completes successfully.
        """
        acc = self.load_account()

        joined = f"{system}\n\n{prompt}" if system else prompt
        if not joined.strip():
            raise NotionAgentError(
                "empty prompt (system and user are both blank)",
                code=ErrorCode.EMPTY_PROMPT,
            )

        if thread_id is not None:
            prior_state = load_thread_state(thread_id, self.thread_state_dir)
            notion_model = prior_state.notion_model
            new_updated_config_ids = [*prior_state.updated_config_ids, new_uuid()]
            transcript = build_partial_transcript(
                acc,
                new_user_text=joined,
                notion_model=notion_model,
                config_id=prior_state.config_id,
                context_id=prior_state.context_id,
                updated_config_ids=new_updated_config_ids,
                use_web_search=web_search,
                use_workspace_search=workspace_search,
                use_read_only_mode=ask_mode,
                original_datetime=prior_state.original_datetime,
            )
            active_thread_id = thread_id
            create_thread = False
            is_partial = True
            req_generate_title = False

            def save_state() -> None:
                prior_state.updated_config_ids = new_updated_config_ids
                prior_state.last_activity_iso = _now_iso(acc.timezone)
                save_thread_state(prior_state, self.thread_state_dir)
        else:
            notion_model = resolve_model(
                model or acc.default_model,
                user_map=self._get_user_model_map(),
            )
            first_turn_config_id = new_uuid()
            first_turn_context_id = new_uuid()
            first_turn_datetime = _now_iso(acc.timezone)
            transcript = build_full_transcript(
                acc,
                user_text=joined,
                notion_model=notion_model,
                use_web_search=web_search,
                use_workspace_search=workspace_search,
                use_read_only_mode=ask_mode,
                config_id=first_turn_config_id,
                context_id=first_turn_context_id,
                now=first_turn_datetime,
            )
            active_thread_id = new_uuid()
            create_thread = True
            is_partial = False
            req_generate_title = self.generate_title

            def save_state() -> None:
                save_thread_state(
                    ThreadState(
                        thread_id=active_thread_id,
                        config_id=first_turn_config_id,
                        context_id=first_turn_context_id,
                        original_datetime=first_turn_datetime,
                        notion_model=notion_model,
                        updated_config_ids=[],
                        last_activity_iso=_now_iso(acc.timezone),
                    ),
                    self.thread_state_dir,
                )

        body = build_inference_request(
            acc,
            transcript=transcript,
            thread_id=active_thread_id,
            create_thread=create_thread,
            is_partial_transcript=is_partial,
            as_patch_response=self.as_patch_response,
            generate_title=req_generate_title,
        )
        headers = build_headers(acc)
        url = f"{self.base_url}/runInferenceTranscript"

        log.debug(
            "POST %s thread=%s model=%s jarvis=%s partial=%s",
            url, active_thread_id, notion_model,
            acc.has_jarvis_binding, is_partial,
        )

        return _PreparedCall(
            url=url,
            body=body,
            headers=headers,
            active_thread_id=active_thread_id,
            notion_model=notion_model,
            save_state=save_state,
        )

    async def _raise_for_http(self, resp: httpx.Response) -> None:
        """Translate non-200 inference responses to NotionAgentError."""
        raw = await resp.aread()
        snippet = raw[:500].decode("utf-8", errors="replace") if raw else ""
        if resp.status_code in (401, 403):
            raise NotionAgentError(
                f"notion auth failed ({resp.status_code}): token_v2 expired "
                f"or rejected. Re-run `notion-agent init` with a fresh "
                f"cookie. body={snippet!r}",
                code=ErrorCode.AUTH_INVALID,
            )
        raise NotionAgentError(
            f"notion API {resp.status_code}: {snippet!r}",
            code=ErrorCode.HTTP_ERROR,
        )

    # ----------------------------- complete --------------------------- #

    async def complete(
        self,
        *,
        prompt: str,
        system: str | None = None,
        model: str | None = None,
        web_search: bool = True,
        workspace_search: bool = True,
        ask_mode: bool = False,
        on_text_delta: Callable[[str], None] | None = None,
        on_text_delta_async: Callable[[str], Awaitable[None]] | None = None,
        thread_id: str | None = None,
    ) -> ChatResponse:
        """Send one user message, return the assistant reply.

        Parameters
        ----------
        prompt
            The user-side text. If ``system`` is also set, both are
            stitched together (Notion has no first-class system role —
            agent instructions live on the bound context_page_id).
        model
            Friendly alias (``opus-4.7``), Anthropic id
            (``claude-opus-4-7``), or Notion internal id
            (``apricot-sorbet-high``). Defaults to ``account.default_model``.
            Ignored when ``thread_id`` is set — continuation locks the
            model to whatever turn-1 chose.
        web_search / workspace_search
            Toggles the corresponding config flags.
        ask_mode
            Sets ``useReadOnlyMode=True`` — the model answers but skips
            page edits.
        on_text_delta
            Optional sync callback fired with each new text chunk as it
            streams in. Use this to print to stdout in real time.
        on_text_delta_async
            Optional async variant — coroutine awaited per chunk. Use
            this from async consumers (FastAPI SSE, etc.) where ``await``
            is needed to push the chunk through (e.g. ``await
            queue.put(chunk)``). Set at most one of
            ``on_text_delta`` / ``on_text_delta_async``.
        thread_id
            Continue a prior thread (the ``thread_id`` from a previous
            response). The CLI loads
            ``~/.notionagents/threads/<thread_id>.json`` for the
            config_id / context_id / original datetime needed to make
            Notion accept the partial transcript. Missing state →
            :class:`NotionAgentError` with code
            ``THREAD_STATE_MISSING``.
        """
        if on_text_delta is not None and on_text_delta_async is not None:
            raise NotionAgentError(
                "set on_text_delta OR on_text_delta_async, not both",
                code=ErrorCode.INVALID_CALLBACK,
            )

        prep = self._prepare_call(
            prompt=prompt,
            system=system,
            model=model,
            web_search=web_search,
            workspace_search=workspace_search,
            ask_mode=ask_mode,
            thread_id=thread_id,
        )

        parser = NDJSONStreamParser()
        last_text_len = 0
        client = self._get_client()
        try:
            async with client.stream(
                "POST", prep.url, json=prep.body, headers=prep.headers,
            ) as resp:
                if resp.status_code != 200:
                    await self._raise_for_http(resp)

                async for line in resp.aiter_lines():
                    parser.feed_line(line)
                    if len(parser.text) > last_text_len:
                        chunk = parser.text[last_text_len:]
                        last_text_len = len(parser.text)
                        if on_text_delta_async is not None:
                            await on_text_delta_async(chunk)
                        elif on_text_delta is not None:
                            on_text_delta(chunk)
        except httpx.HTTPError as e:
            raise NotionAgentError(
                f"notion transport error: {e}",
                code=ErrorCode.TRANSPORT,
            ) from e

        result = parser.finalize()
        if not result.text:
            raise NotionAgentError(
                f"notion returned empty text (events={result.event_type_counts}, "
                f"lines={result.line_count}); account or thread may be in a bad state",
                code=ErrorCode.EMPTY_TEXT,
            )

        # Persist state so the next `chat --thread-id <id>` finds what
        # it needs. Cheap (small JSON file) even when the operator never
        # continues — and the alternative ("save only when asked") would
        # need the caller to predict re-use before sending.
        prep.save_state()

        return ChatResponse(
            text=result.text,
            model=result.notion_model or prep.notion_model,
            thread_id=prep.active_thread_id,
            thinking=result.thinking,
            usage=TokenUsage(
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens,
                cache_read=result.cache_read_tokens,
                cache_creation=result.cache_creation_tokens,
            ),
            raw={
                "notion_model":      result.notion_model or prep.notion_model,
                "event_type_counts": result.event_type_counts,
                "line_count":        result.line_count,
            },
        )

    # ----------------------------- stream_lines ----------------------- #

    async def stream_lines(
        self,
        *,
        prompt: str,
        system: str | None = None,
        model: str | None = None,
        web_search: bool = True,
        workspace_search: bool = True,
        ask_mode: bool = False,
        thread_id: str | None = None,
    ) -> AsyncIterator[str]:
        """Stream raw NDJSON lines from the inference endpoint.

        Like :meth:`complete` but without parsing. Each yielded value
        is one non-empty NDJSON line (no trailing newline). Use this
        for programmatic consumers that want the full event stream
        (CLI ``chat --ndjson``, the FastAPI ``/chat`` SSE branch, etc.).

        Thread state is persisted as in :meth:`complete` after the
        stream is fully consumed without error, so continuation via
        ``--thread-id`` keeps working for raw consumers too.

        Raises :class:`NotionAgentError` on HTTP / transport failures.
        Terminal events embedded in the stream (``error`` /
        ``premium-feature-unavailable``) are NOT translated — the raw
        consumer is responsible for inspecting them.
        """
        prep = self._prepare_call(
            prompt=prompt,
            system=system,
            model=model,
            web_search=web_search,
            workspace_search=workspace_search,
            ask_mode=ask_mode,
            thread_id=thread_id,
        )
        client = self._get_client()
        try:
            async with client.stream(
                "POST", prep.url, json=prep.body, headers=prep.headers,
            ) as resp:
                if resp.status_code != 200:
                    await self._raise_for_http(resp)
                async for line in resp.aiter_lines():
                    if line.strip():
                        yield line
        except httpx.HTTPError as e:
            raise NotionAgentError(
                f"notion transport error: {e}",
                code=ErrorCode.TRANSPORT,
            ) from e
        prep.save_state()

    # ----------------------------- ancillary -------------------------- #

    async def _post_json(self, path: str, body: dict[str, object]) -> dict[str, object]:
        """Shared helper for non-streaming JSON endpoints.

        Reuses the same auth headers and error-code mapping as the chat
        path so ancillary calls (``/getAvailableModels`` /
        ``/getCustomAgents``) speak the same dialect of failures.
        """
        acc = self.load_account()
        url = f"{self.base_url}/{path}"
        headers = build_headers(acc, accept="application/json")
        client = self._get_client()
        try:
            resp = await client.post(url, json=body, headers=headers)
        except httpx.HTTPError as e:
            raise NotionAgentError(
                f"notion transport error: {e}",
                code=ErrorCode.TRANSPORT,
            ) from e
        if resp.status_code != 200:
            snippet = resp.text[:400] if resp.text else ""
            if resp.status_code in (401, 403):
                raise NotionAgentError(
                    f"notion auth failed ({resp.status_code}): token_v2 "
                    f"expired or rejected. body={snippet!r}",
                    code=ErrorCode.AUTH_INVALID,
                )
            raise NotionAgentError(
                f"{path} failed: HTTP {resp.status_code} body={snippet!r}",
                code=ErrorCode.HTTP_ERROR,
            )
        return resp.json()

    async def fetch_available_models(self) -> dict[str, object]:
        """Call ``/api/v3/getAvailableModels`` and return the parsed JSON.

        Used by ``notion-agent models refresh`` to refresh the local
        ``~/.notionagents/models.json`` map without a code release.
        Raises :class:`NotionAgentError` on non-200.
        """
        return await self._post_json(
            "getAvailableModels",
            {"spaceId": self.load_account().space_id},
        )

    async def fetch_custom_agents(self) -> dict[str, object]:
        """Call ``/api/v3/getCustomAgents`` and return the parsed JSON.

        Used by ``notion-agent agents list`` / ``notion-agent threads list``
        — the response carries ``agentIds`` + ``mostRecentTranscripts`` +
        ``activityScores`` for the bound workspace. Raises
        :class:`NotionAgentError` on non-200.
        """
        return await self._post_json(
            "getCustomAgents",
            {"spaceId": self.load_account().space_id},
        )

    async def fetch_block_records(
        self, block_ids: list[str],
    ) -> dict[str, object]:
        """Batch-fetch Notion block records by id via ``syncRecordValuesMain``.

        Each request pointer is ``{table: "block", id, spaceId}`` — Notion
        requires the spaceId on every pointer in this endpoint (unlike
        the older ``syncRecordValues``). Returns the raw response so
        callers can apply their own unwrapping; use
        :func:`notion_agent_cli.agents.parse_block_records` to flatten.
        Used by ``notion-agent agents list`` to resolve agent
        page-title → name.
        """
        if not block_ids:
            return {"recordMap": {"block": {}}}
        space_id = self.load_account().space_id
        body = {
            "requests": [
                {
                    "pointer": {"table": "block", "id": bid, "spaceId": space_id},
                    "version": -1,
                }
                for bid in block_ids
            ],
        }
        return await self._post_json("syncRecordValuesMain", body)
