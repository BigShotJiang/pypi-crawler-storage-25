# Next-session handoff — openclaw/Jarvis onboarding feedback

> Written 2026-05-16 evening, right after shipping `v0.1.2` (the
> `--token-v2`-alone init UX). Goal of next session: absorb the
> feedback the operator will paste from a fresh openclaw + Jarvis
> trial run, prioritize, fix, ship as `v0.1.3`. Should be a 1-2 hour
> session if the feedback is small; could spiral to ~half a day if
> openclaw uncovers a real bug. The repo is in good shape — keep it
> that way.

## TL;DR — what you're walking into

The operator is going to run **openclaw** (a non-Claude-Code agent
runtime, see `docs/AGENTS.md` for the prompt they paste into it) and
ask their bound **Jarvis** Custom Agent to test the onboarding
experience for `notion-agent-cli`. They will paste back whatever
openclaw says about the experience — likely a mix of:

- **Friction in the install/init flow** (e.g. "DevTools steps unclear",
  "I didn't know which value to copy", "the error message after a bad
  token was confusing")
- **Help text or doc gaps** (e.g. "I expected `--help` to mention X",
  "the AGENTS.md prompt doesn't say how to recover from Y")
- **Actual bugs surfaced by an outsider** (rare but possible — fresh
  agents are good at hitting edge cases)
- **Polish requests** (e.g. shorter command names, sensible defaults,
  better progress output)

Your job is to triage that feedback list and ship the high-signal
items as `v0.1.3`. Low-signal stuff goes in ROADMAP.

## Startup checks (~30s)

```bash
source .venv/bin/activate
.venv/bin/pytest -q | tail -3          # expect 184 pass
.venv/bin/ruff check src tests | tail  # expect "All checks passed!"
git log --oneline -5                   # confirm decf47f / 819ab28 / 63a71e8 are on main
git status -s                          # expect clean
notion-agent --version                 # 0.1.2 (from editable install)
```

`docs/RELEASING.md` has the cut-a-release SOP — you'll use this verbatim
when shipping `v0.1.3`.

## Current state — what's been shipped and verified

- **v0.1.0** tagged 2026-05-16. First PyPI release didn't happen
  (workflow didn't exist yet).
- **v0.1.1** 2026-05-16. First PyPI release. Wired up
  `.github/workflows/release.yml` (Trusted Publishing, OIDC) +
  `test.yml`. `pipx install notion-agent-cli` works.
- **v0.1.2** 2026-05-16. **The new onboarding flow this session is
  testing.** `notion-agent init --token-v2 <value>` now works without
  `--user-id` — bootstrap derives it from `/loadUserContent`. Removed
  the false "you need the full document.cookie" framing in docs.
  See commit `819ab28` for the full surgery.
- **PyPI Trusted Publisher** is configured and self-promoted; no
  human steps needed for future releases beyond `git tag vX.Y.Z`.
- **GitHub Actions** were just bumped to Node-24-compatible
  majors (`checkout@v6`, `setup-python@v6`, `upload-artifact@v7`,
  `download-artifact@v7`). First post-bump release run will tell
  us if v7 of upload/download play nicely together; if not, pin
  back to v5 (last known-good).
- **Live-validated surfaces** (don't break these): every CLI
  subcommand, the FastAPI `serve` wrapper, the B1 thread
  continuation, `chat --ndjson`, profile switching, all 8 init
  flag combinations. See `docs/STATUS.md` for the full ledger.
- **184 unit tests** in this repo + **NotionAgents 147 tests**
  green against the editable install.

## Triage rubric for the openclaw feedback

When the operator pastes back the openclaw/Jarvis report, sort each
item into one of these buckets:

| Bucket | What it looks like | Action |
|---|---|---|
| **Bug** | Reproducible failure, wrong output, crash, security issue | Fix + test + ship in v0.1.3 |
| **UX wart** | Confusing error message, awkward help text, weird default | Fix in v0.1.3 if cheap (< 30 min), else ROADMAP |
| **Doc gap** | README or AGENTS.md didn't cover the case | Doc-only patch, fold into v0.1.3 release |
| **Polish** | Wishlist that doesn't block | ROADMAP entry, no release |
| **Out of scope** | "Could it also send Slack messages?" | Decline politely, ROADMAP if interesting |

Ask the operator before shipping if anything is ambiguous — don't guess
their priority.

## Hot paths (where the changes will land)

Onboarding feedback maps to specific files about 90% of the time:

| Feedback theme | Where to look first |
|---|---|
| Install confusion | `README.md` install section + `docs/AGENTS.md` "Install" section |
| `notion-agent init` flow | `src/notion_agent_cli/cli/__main__.py:_cmd_init` + `_add_init_parser`; `src/notion_agent_cli/bootstrap.py` |
| Error message text | `src/notion_agent_cli/exceptions.py` (codes) + raise sites in `provider.py` / `bootstrap.py` / `account.py` |
| `doctor` output | `src/notion_agent_cli/cli/__main__.py::_render_doctor` |
| Agent prompt phrasing | `docs/AGENTS.md` (the paste-ready snippet near the bottom) |
| Custom Agent (Jarvis) binding | `--agent-name` / `--agent-page-id` flags on init |

## How to ship v0.1.3

Verbatim from `docs/RELEASING.md`:

```bash
# After your changes are in and tested
sed -i '' 's/version = "0.1.2"/version = "0.1.3"/' pyproject.toml
git commit -am "Bump version to 0.1.3"
git push origin main
git tag v0.1.3 && git push origin v0.1.3

# Watch the release
gh run watch $(gh run list --workflow=Release --limit 1 --json databaseId --jq '.[0].databaseId') --exit-status

# Verify on PyPI
curl -s https://pypi.org/simple/notion-agent-cli/ | grep -oE 'notion[_-]agent[_-]cli-0\.1\.3'
```

If the feedback round only needs **docs** changes, you can still cut a
patch release — agent-runtime users read `docs/AGENTS.md` through the
README link, which gets bundled into the wheel's METADATA. A doc-only
v0.1.3 is fine.

## What NOT to touch (would cost real engineering)

- **`provider.py`'s transcript-building paths** unless you have new live
  capture evidence — the field shape is reverse-engineered from real
  chat-panel traffic and divergence shows up as 400 errors that take
  hours to chase. See `docs/01-notion-chat-protocol.md` for the spec.
- **`thread_state.py` schema** — changing it without a migration would
  silently break every user's `~/.notionagents/threads/` files.
- **`account.py`'s required-fields list** — adding a new required field
  breaks every existing `notion_account.json` until users re-init.
  If you need new fields, make them optional with sensible defaults.
- **The `pypi` GitHub environment** — it's the Trusted Publisher gate
  to PyPI. Deleting it would require re-registering on PyPI.

## Non-obvious context (read once)

- **The `--cookie -` stdin path still works** even though `--token-v2`
  is now the recommended flow. It auto-extracts `notion_user_id` from
  the cookie string, which becomes the explicit-user_id mode rather
  than the derive-from-response mode. Both paths converge in
  `bootstrap_account`.
- **`account.full_cookie` field** in `NotionAccount` is currently
  unused — historical artifact from when bootstrap parsed the cookie
  for every request. Safe to remove in a future cleanup if it shows up
  in openclaw's feedback as confusing JSON output.
- **Two PyPI versions live** — 0.1.1 (with the old init UX) and 0.1.2
  (with the new). Users on 0.1.1 should `pipx upgrade notion-agent-cli`
  to get the new flow. If openclaw is on 0.1.1, the operator's
  feedback may include items already fixed in 0.1.2 — clarify version
  before triaging.
- **NotionAgents (`~/Documents/NotionAgents`)** depends on this repo
  via editable install. After any public-API change here, run
  `cd ~/Documents/NotionAgents && .venv/bin/pytest -q` to catch
  regressions. **You probably won't touch public API in this feedback
  round** — most onboarding feedback hits CLI / docs only.
- **`.omc/` is session state for oh-my-claudecode** — don't `git add`
  it. Not in `.gitignore` for historical reasons but treated as such.
- **Conversation context** with the operator: the previous session
  shipped Phase 2 + the release pipeline + the v0.1.2 onboarding fix.
  The operator is happy with progress; the current task is just polish
  based on real-world agent testing.

## Done state for this session

You're done when:

1. Every feedback item from openclaw has a bucket assigned and an
   action (fix / doc / ROADMAP / decline).
2. All "fix" items are committed + tested.
3. v0.1.3 is tagged and on PyPI (or no version bump is needed if the
   feedback was all "doc gap" with no code change — but even then,
   ship a patch so the README on PyPI updates).
4. The operator has been told what was shipped and what was deferred.
5. `docs/NEXT-SESSION.md` is updated for whatever's next (or deleted
   if there's no next thing in flight).
