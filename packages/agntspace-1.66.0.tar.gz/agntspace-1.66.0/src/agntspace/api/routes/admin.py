"""Admin endpoints — observability layer configuration + health.

Surfaces the knobs that power the accountability layer so a user can
monitor and tune them without editing code. Meant for the /admin page:

    GET  /api/admin/overview          — one-shot snapshot: decisions health,
                                         rate-limit snapshot, retention config
    GET  /api/admin/rate-limits       — status of every configured rate-limit scope
    POST /api/admin/rate-limits/reset — clear tracked buckets for a scope
    GET  /api/admin/cache-stats       — hit/miss counters from the P4.4
                                        conversation-prefetch cache + the
                                        P4.6 per-chunk extraction cache.
                                        Without this, the caches are
                                        invisible — operator can't tell
                                        whether they're hitting or saving
                                        cost.

These are read-mostly. Mutating rate-limit policies at runtime is
deliberately NOT supported — the policies live in code so a user can't
accidentally raise their own limit on a sensitive endpoint from the UI.
If you need a new policy, ship it in ``rate_limit.get_limiter()``.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from pydantic import BaseModel

from agntspace.infra.rate_limit import get_limiter

log = logging.getLogger(__name__)

router = APIRouter(prefix="/admin", tags=["admin"])


class _ResetRequest(BaseModel):
    scope: str
    caller: str | None = None


@router.get("/overview")
async def admin_overview(request: Request) -> dict:
    """One-shot snapshot combining decision health + rate-limit state + retention."""
    decisions = getattr(request.app.state, "decisions", None)
    evolution = getattr(request.app.state, "evolution", None)
    limiter = get_limiter()

    health = decisions.health() if decisions is not None else {"status": "unavailable"}
    evolution_health = (
        evolution.health() if evolution is not None and hasattr(evolution, "health")
        else {"initialized": False, "status": "unavailable"}
    )

    rate_limits: list[dict] = []
    for scope in ("privacy_forget", "privacy_export", "decisions_prune"):
        rate_limits.append(limiter.snapshot(scope))

    return {
        "decision_health": health,
        "evolution_health": evolution_health,
        "rate_limits": rate_limits,
    }


@router.get("/rate-limits")
async def rate_limit_status(request: Request) -> dict:
    """Return the configured rate-limit policies + active bucket counts."""
    limiter = get_limiter()
    scopes = sorted(limiter._policies.keys())  # noqa: SLF001
    return {
        "scopes": [limiter.snapshot(s) for s in scopes],
    }


@router.post("/rate-limits/reset")
async def rate_limit_reset(request: Request, body: _ResetRequest) -> dict:
    """Clear tracked buckets for a scope (and optionally a single caller).

    Use case: the user got themselves locked out during a misconfigured
    script test and wants to reset without restarting the server.
    """
    limiter = get_limiter()
    limiter.reset(scope=body.scope, caller=body.caller)
    return {"ok": True, "scope": body.scope, "caller": body.caller or "all"}


@router.get("/cache-stats")
async def cache_stats(request: Request) -> dict:
    """Hit/miss observability for the perf caches shipped this session.

    Returns:
        {
          "conversation_prefetch": {<P4.4 stats dict> | null},
          "chunk_extraction": {
            "available": bool,
            "config": {"enabled": bool, "max_entries_per_kb": int, "prompt_version": str},
            "per_kb": [
              {"kb": "<slug>", "stats": <P4.6 cache.stats() dict>},
              ...
            ],
            "totals": {
              "hits": int, "misses": int, "writes": int,
              "invalidations": int, "evictions": int,
              "load_failures": int, "save_failures": int,
              "hit_rate": float,
              "kb_count": int,
            }
          }
        }

    Fail-soft: missing caches / broken stats → empty/null payload. The
    /admin UI handles both cases gracefully (renders "not wired" placeholder).
    No mutation, pure read.
    """
    prefetch = getattr(request.app.state, "prefetch_cache", None)
    prefetch_stats: dict | None = None
    if prefetch is not None:
        try:
            prefetch_stats = prefetch.stats()
        except Exception:
            log.debug("prefetch_cache.stats() raised", exc_info=True)
            prefetch_stats = None

    kb_service = getattr(request.app.state, "kb_service", None)
    chunk_payload: dict = {"available": False, "config": None, "per_kb": [], "totals": None}
    if kb_service is not None:
        try:
            cfg = getattr(kb_service, "_chunk_cache_config", None)
            caches = getattr(kb_service, "_chunk_caches", None) or {}
            cfg_dict: dict | None = None
            if cfg is not None:
                cfg_dict = {
                    "enabled": bool(getattr(cfg, "enabled", False)),
                    "max_entries_per_kb": int(getattr(cfg, "max_entries_per_kb", 0)),
                    "prompt_version": str(getattr(cfg, "prompt_version", "")),
                }
            per_kb: list[dict] = []
            totals = {
                "hits": 0, "misses": 0, "writes": 0,
                "invalidations": 0, "evictions": 0,
                "load_failures": 0, "save_failures": 0,
                "kb_count": 0,
            }
            for slug in sorted(caches.keys()):
                try:
                    s = caches[slug].stats()
                except Exception:
                    log.debug("chunk_cache[%s].stats() raised", slug, exc_info=True)
                    continue
                per_kb.append({"kb": slug, "stats": s})
                for key in ("hits", "misses", "writes", "invalidations", "evictions", "load_failures", "save_failures"):
                    totals[key] += int(s.get(key, 0))
                totals["kb_count"] += 1
            total_lookups = totals["hits"] + totals["misses"]
            totals["hit_rate"] = round(totals["hits"] / total_lookups, 4) if total_lookups > 0 else 0.0
            chunk_payload = {
                "available": cfg_dict is not None,
                "config": cfg_dict,
                "per_kb": per_kb,
                "totals": totals,
            }
        except Exception:
            log.debug("chunk_extraction stats assembly failed", exc_info=True)

    return {
        "conversation_prefetch": prefetch_stats,
        "chunk_extraction": chunk_payload,
    }
