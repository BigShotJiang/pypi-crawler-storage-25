"""Prototype: Contrastive LCA (Lowest Common Ancestor) scoring for code hierarchies.

Adapted from the Nairobi Protocol GDE project's contrast_lca.py algorithm.
Tests whether "geometric resonance" produces intuitive similarity scores when
applied to the mcp-vector-search code hierarchy (module → file → class → method).

Formula
-------
    penalty = |left_depth - lca_depth| + |right_depth - lca_depth|
              + 0.5 * |left_depth - right_depth|
    geometric_resonance = 1.0 - (penalty / baseline)

Where baseline = max possible penalty for the tree (2 * max_depth).

Usage
-----
    python scripts/test_lca_scoring.py
"""

from __future__ import annotations

import sys
from dataclasses import dataclass
from typing import Any

try:
    import networkx as nx
except ImportError:
    print("ERROR: networkx is required for this prototype.")
    print("Install it with:  pip install networkx")
    sys.exit(1)


# ---------------------------------------------------------------------------
# Data model mirroring mcp-vector-search KG entity types
# ---------------------------------------------------------------------------

ENTITY_TYPE_DEPTH: dict[str, int] = {
    "root": 0,
    "module": 1,
    "file": 2,
    "class": 3,
    "method": 4,
    "function": 4,
}


@dataclass(frozen=True)
class CodeNode:
    """Mirrors CodeEntity in knowledge_graph.py."""

    id: str
    name: str
    entity_type: str  # root | module | file | class | method | function

    def __str__(self) -> str:
        return f"{self.entity_type}:{self.name}"


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------


def build_synthetic_hierarchy() -> tuple[nx.DiGraph, dict[str, CodeNode]]:
    """Build a small synthetic code hierarchy using CONTAINS edges.

    Structure (mirrors mcp-vector-search's own package layout):

        ROOT
        ├── module: core
        │   ├── file: knowledge_graph.py
        │   │   ├── class: KnowledgeGraph
        │   │   │   ├── method: initialize
        │   │   │   ├── method: add_entity
        │   │   │   └── method: query
        │   │   └── class: CodeEntity
        │   │       ├── method: __init__
        │   │       └── method: to_dict
        │   └── file: kg_builder.py
        │       └── class: KGBuilder
        │           ├── method: build
        │           └── method: _extract_entities
        └── module: parsers
            ├── file: python.py
            │   └── class: PythonParser
            │       ├── method: parse
            │       └── method: extract_functions
            └── file: base.py
                └── class: BaseParser
                    ├── method: parse
                    └── method: validate
    """
    G: nx.DiGraph = nx.DiGraph()
    nodes: dict[str, CodeNode] = {}

    def add(node: CodeNode, parent_id: str | None = None) -> CodeNode:
        nodes[node.id] = node
        G.add_node(node.id, **{"name": node.name, "entity_type": node.entity_type})
        if parent_id is not None:
            G.add_edge(parent_id, node.id, rel="CONTAINS")
        return node

    # Root (virtual root — not a KG node, just anchors the tree)
    root = add(CodeNode("root", "root", "root"))

    # --- module: core ---
    core = add(CodeNode("module:core", "core", "module"), root.id)

    kg_file = add(CodeNode("file:knowledge_graph", "knowledge_graph.py", "file"), core.id)
    kg_class = add(CodeNode("class:KnowledgeGraph", "KnowledgeGraph", "class"), kg_file.id)
    add(CodeNode("method:KG.initialize", "initialize", "method"), kg_class.id)
    add(CodeNode("method:KG.add_entity", "add_entity", "method"), kg_class.id)
    add(CodeNode("method:KG.query", "query", "method"), kg_class.id)

    ce_class = add(CodeNode("class:CodeEntity", "CodeEntity", "class"), kg_file.id)
    add(CodeNode("method:CE.__init__", "__init__", "method"), ce_class.id)
    add(CodeNode("method:CE.to_dict", "to_dict", "method"), ce_class.id)

    builder_file = add(CodeNode("file:kg_builder", "kg_builder.py", "file"), core.id)
    builder_class = add(CodeNode("class:KGBuilder", "KGBuilder", "class"), builder_file.id)
    add(CodeNode("method:KGB.build", "build", "method"), builder_class.id)
    add(CodeNode("method:KGB._extract_entities", "_extract_entities", "method"), builder_class.id)

    # --- module: parsers ---
    parsers = add(CodeNode("module:parsers", "parsers", "module"), root.id)

    py_file = add(CodeNode("file:python_parser", "python.py", "file"), parsers.id)
    py_class = add(CodeNode("class:PythonParser", "PythonParser", "class"), py_file.id)
    add(CodeNode("method:PP.parse", "parse", "method"), py_class.id)
    add(CodeNode("method:PP.extract_functions", "extract_functions", "method"), py_class.id)

    base_file = add(CodeNode("file:base_parser", "base.py", "file"), parsers.id)
    base_class = add(CodeNode("class:BaseParser", "BaseParser", "class"), base_file.id)
    add(CodeNode("method:BP.parse", "parse", "method"), base_class.id)
    add(CodeNode("method:BP.validate", "validate", "method"), base_class.id)

    return G, nodes


# ---------------------------------------------------------------------------
# LCA algorithm
# ---------------------------------------------------------------------------


def find_lca(G: nx.DiGraph, node_a: str, node_b: str, root: str = "root") -> str | None:
    """Find the Lowest Common Ancestor of two nodes in a directed tree.

    Uses the undirected tree's ancestor sets: the LCA is the deepest node
    that is an ancestor of both node_a and node_b.

    Args:
        G: Directed graph with edges parent → child (CONTAINS direction).
        node_a: First node ID.
        node_b: Second node ID.
        root: Root node ID.

    Returns:
        LCA node ID, or None if no common ancestor exists.
    """
    # ancestors_of(n) = all nodes on the path from root to n (inclusive)
    def ancestors_with_self(n: str) -> list[str]:
        # Walk up via predecessors (reverse CONTAINS direction)
        path: list[str] = []
        current = n
        visited: set[str] = set()
        while True:
            if current in visited:
                break
            visited.add(current)
            path.append(current)
            preds = list(G.predecessors(current))
            if not preds:
                break
            current = preds[0]  # Tree: at most one parent
        return list(reversed(path))  # root-first order

    path_a = ancestors_with_self(node_a)
    path_b = ancestors_with_self(node_b)

    # Walk both paths in root-first order; the last common node is the LCA
    lca: str | None = None
    for a, b in zip(path_a, path_b):
        if a == b:
            lca = a
        else:
            break
    return lca


def node_depth(G: nx.DiGraph, node_id: str, root: str = "root") -> int:
    """Return the depth of node_id from the root (root = depth 0)."""
    try:
        return int(nx.shortest_path_length(G, source=root, target=node_id))
    except nx.NetworkXNoPath:
        return 0


# ---------------------------------------------------------------------------
# Contrastive LCA scoring
# ---------------------------------------------------------------------------


def contrastive_lca_score(
    G: nx.DiGraph,
    node_a: str,
    node_b: str,
    root: str = "root",
    baseline: float | None = None,
) -> dict[str, Any]:
    """Compute Contrastive LCA geometric resonance score.

    Adapted from Nairobi Protocol GDE contrast_lca.py.

    Formula:
        penalty = |depth_a - lca_depth| + |depth_b - lca_depth|
                  + 0.5 * |depth_a - depth_b|
        geometric_resonance = max(0.0, 1.0 - penalty / baseline)

    The 0.5 * |depth_a - depth_b| term is the "contrastive" component:
    it penalizes pairs at very different depths, even when their LCA is
    relatively shallow. Two leaf nodes vs. a leaf + its parent would score
    differently despite the same LCA.

    Args:
        G: Directed tree (parent → child).
        node_a: First node ID.
        node_b: Second node ID.
        root: Root node ID.
        baseline: Normalization factor. Defaults to 2 * max_tree_depth.

    Returns:
        Dict with lca, depths, penalty, baseline, and geometric_resonance.
    """
    if node_a == node_b:
        return {
            "node_a": node_a,
            "node_b": node_b,
            "lca": node_a,
            "depth_a": node_depth(G, node_a, root),
            "depth_b": node_depth(G, node_b, root),
            "lca_depth": node_depth(G, node_a, root),
            "penalty": 0.0,
            "baseline": baseline or 1.0,
            "geometric_resonance": 1.0,
        }

    lca = find_lca(G, node_a, node_b, root)
    if lca is None:
        return {
            "node_a": node_a,
            "node_b": node_b,
            "lca": None,
            "depth_a": node_depth(G, node_a, root),
            "depth_b": node_depth(G, node_b, root),
            "lca_depth": 0,
            "penalty": float("inf"),
            "baseline": baseline or 1.0,
            "geometric_resonance": 0.0,
        }

    depth_a = node_depth(G, node_a, root)
    depth_b = node_depth(G, node_b, root)
    lca_depth = node_depth(G, lca, root)

    # Nairobi Protocol formula
    penalty = (
        abs(depth_a - lca_depth)
        + abs(depth_b - lca_depth)
        + 0.5 * abs(depth_a - depth_b)
    )

    if baseline is None:
        # 2 * max_depth covers the worst case: two leaf nodes whose LCA is root
        max_depth = max(depth_a for _, depth_a in nx.single_source_shortest_path_length(G, root).items())
        baseline = 2.0 * max_depth

    resonance = max(0.0, 1.0 - penalty / baseline)

    return {
        "node_a": node_a,
        "node_b": node_b,
        "lca": lca,
        "depth_a": depth_a,
        "depth_b": depth_b,
        "lca_depth": lca_depth,
        "penalty": penalty,
        "baseline": baseline,
        "geometric_resonance": resonance,
    }


# ---------------------------------------------------------------------------
# Test scenarios
# ---------------------------------------------------------------------------


def run_test_scenarios(G: nx.DiGraph, nodes: dict[str, CodeNode]) -> None:
    """Run representative test pairs and print structured output."""
    # Precompute baseline once (consistent across all comparisons)
    max_depth = max(
        nx.shortest_path_length(G, source="root", target=n) for n in G.nodes
    )
    baseline = 2.0 * max_depth

    print("=" * 70)
    print("Contrastive LCA Scoring — Synthetic Code Hierarchy")
    print(f"Tree max depth: {max_depth}  |  Baseline: {baseline}")
    print("=" * 70)

    scenarios: list[tuple[str, str, str]] = [
        # (label, node_a_id, node_b_id)

        # --- SAME CLASS (expected: HIGH) ---
        (
            "Sibling methods in same class (KnowledgeGraph)",
            "method:KG.initialize",
            "method:KG.add_entity",
        ),
        (
            "Sibling methods in same class (KnowledgeGraph) — another pair",
            "method:KG.add_entity",
            "method:KG.query",
        ),

        # --- SAME FILE, DIFFERENT CLASS (expected: MEDIUM-HIGH) ---
        (
            "Methods in different classes, same file (knowledge_graph.py)",
            "method:KG.initialize",
            "method:CE.to_dict",
        ),

        # --- SAME MODULE, DIFFERENT FILE (expected: MEDIUM) ---
        (
            "Methods in different files, same module (core)",
            "method:KG.query",
            "method:KGB.build",
        ),
        (
            "Classes in different files, same module (core)",
            "class:KnowledgeGraph",
            "class:KGBuilder",
        ),

        # --- DIFFERENT MODULES (expected: LOW) ---
        (
            "Methods in completely different modules (core vs parsers)",
            "method:KG.initialize",
            "method:PP.parse",
        ),
        (
            "Methods in completely different modules — deepest leaves",
            "method:KGB._extract_entities",
            "method:BP.validate",
        ),
        (
            "Classes across modules",
            "class:KnowledgeGraph",
            "class:PythonParser",
        ),

        # --- EDGE CASES ---
        (
            "Same node (self-comparison) — expect 1.0",
            "method:KG.initialize",
            "method:KG.initialize",
        ),
        (
            "Module vs leaf method (very different depths)",
            "module:core",
            "method:KG.query",
        ),
        (
            "Sibling parsers across files in same module",
            "method:PP.parse",
            "method:BP.parse",
        ),
    ]

    for label, id_a, id_b in scenarios:
        result = contrastive_lca_score(G, id_a, id_b, root="root", baseline=baseline)
        node_a = nodes.get(id_a)
        node_b = nodes.get(id_b)
        lca_node = nodes.get(result["lca"] or "")

        print(f"\n  {label}")
        print(f"    Node A  : {node_a} (depth {result['depth_a']})")
        print(f"    Node B  : {node_b} (depth {result['depth_b']})")
        lca_display = str(lca_node) if lca_node else str(result["lca"])
        print(f"    LCA     : {lca_display} (depth {result['lca_depth']})")
        print(f"    Penalty : {result['penalty']:.2f}  (baseline {result['baseline']:.1f})")
        print(f"    Score   : {result['geometric_resonance']:.4f}  {'<<< HIGH' if result['geometric_resonance'] >= 0.75 else '--- MED' if result['geometric_resonance'] >= 0.45 else '... LOW'}")

    print()


def print_score_summary(G: nx.DiGraph, nodes: dict[str, CodeNode]) -> None:
    """Print a compact ranking of all tested pairs by resonance score."""
    max_depth = max(
        nx.shortest_path_length(G, source="root", target=n) for n in G.nodes
    )
    baseline = 2.0 * max_depth

    pairs = [
        ("siblings/same-class", "method:KG.initialize", "method:KG.add_entity"),
        ("siblings/same-class-2", "method:KG.add_entity", "method:KG.query"),
        ("diff-class/same-file", "method:KG.initialize", "method:CE.to_dict"),
        ("diff-file/same-module", "method:KG.query", "method:KGB.build"),
        ("class/diff-file-same-mod", "class:KnowledgeGraph", "class:KGBuilder"),
        ("diff-module-leaf", "method:KG.initialize", "method:PP.parse"),
        ("diff-module-deep", "method:KGB._extract_entities", "method:BP.validate"),
        ("class/diff-module", "class:KnowledgeGraph", "class:PythonParser"),
        ("same-node", "method:KG.initialize", "method:KG.initialize"),
        ("module-vs-leaf", "module:core", "method:KG.query"),
        ("sibling-parsers/diff-file", "method:PP.parse", "method:BP.parse"),
    ]

    results = []
    for label, id_a, id_b in pairs:
        r = contrastive_lca_score(G, id_a, id_b, root="root", baseline=baseline)
        results.append((r["geometric_resonance"], label, id_a, id_b))

    results.sort(key=lambda x: x[0], reverse=True)

    print("=" * 70)
    print("Score Ranking (high → low)")
    print("=" * 70)
    for score, label, id_a, id_b in results:
        bar = "#" * int(score * 30)
        print(f"  {score:.4f}  [{bar:<30}]  {label}")
    print()


def print_tree(G: nx.DiGraph, nodes: dict[str, CodeNode]) -> None:
    """Pretty-print the synthetic hierarchy."""
    print("=" * 70)
    print("Synthetic Code Hierarchy")
    print("=" * 70)

    def _print_subtree(node_id: str, prefix: str = "", is_last: bool = True) -> None:
        node = nodes.get(node_id)
        connector = "└── " if is_last else "├── "
        label = f"{node.entity_type}:{node.name}" if node else node_id
        depth = nx.shortest_path_length(G, source="root", target=node_id)
        print(f"  {prefix}{connector}{label}  [depth={depth}]")
        children = list(G.successors(node_id))
        for i, child in enumerate(children):
            extension = "    " if is_last else "│   "
            _print_subtree(child, prefix + extension, i == len(children) - 1)

    root_children = list(G.successors("root"))
    for i, child in enumerate(root_children):
        _print_subtree(child, "", i == len(root_children) - 1)
    print()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    G, nodes = build_synthetic_hierarchy()

    print_tree(G, nodes)
    run_test_scenarios(G, nodes)
    print_score_summary(G, nodes)

    # Structural validation
    assert nx.is_directed_acyclic_graph(G), "Hierarchy must be a DAG"
    assert nx.is_weakly_connected(G), "All nodes must be reachable from root"
    node_count = G.number_of_nodes()
    edge_count = G.number_of_edges()
    print(f"Graph validation: {node_count} nodes, {edge_count} edges, DAG=True")
    print()

    # Fitness assessment
    print("=" * 70)
    print("Fitness Assessment for mcp-vector-search Integration")
    print("=" * 70)
    max_depth = max(
        nx.shortest_path_length(G, source="root", target=n) for n in G.nodes
    )
    baseline = 2.0 * max_depth
    sibling_score = contrastive_lca_score(
        G, "method:KG.initialize", "method:KG.add_entity", baseline=baseline
    )["geometric_resonance"]
    same_module_score = contrastive_lca_score(
        G, "method:KG.query", "method:KGB.build", baseline=baseline
    )["geometric_resonance"]
    cross_module_score = contrastive_lca_score(
        G, "method:KG.initialize", "method:PP.parse", baseline=baseline
    )["geometric_resonance"]

    ordering_correct = sibling_score > same_module_score > cross_module_score
    print(f"  Sibling methods score     : {sibling_score:.4f}")
    print(f"  Same-module methods score : {same_module_score:.4f}")
    print(f"  Cross-module methods score: {cross_module_score:.4f}")
    print(f"  Score ordering (HIGH > MED > LOW): {'PASS' if ordering_correct else 'FAIL'}")
    print()
    print("  Integration notes:")
    print("  - KG uses Kuzu (not networkx); full integration would need a")
    print("    networkx shadow-graph built from CONTAINS edges via Kuzu queries.")
    print("  - Baseline should be derived from max CONTAINS-path depth per repo.")
    print("  - The 0.5 * |depth_a - depth_b| contrastive term prevents false")
    print("    high scores between nodes at very different abstraction levels.")
    print("  - Consider caching LCA paths; the hierarchy is static between builds.")


if __name__ == "__main__":
    main()
