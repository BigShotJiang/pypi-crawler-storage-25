#!/usr/bin/env python3
"""Generate Held-Suarez benchmark visualizations.

Runs a Held-Suarez integration and produces the standard diagnostic plots:

1. Zonal-mean zonal wind U(lat, sigma)
2. Zonal-mean temperature T(lat, sigma)
3. Zonal-mean eddy kinetic energy EKE(lat, sigma)
4. Global-mean temperature time series (spinup diagnostic)
5. Instantaneous surface pressure map (Mollweide projection)

Usage
-----
    uv run python examples/plot_held_suarez.py                    # T21, 300 days (quick)
    uv run python examples/plot_held_suarez.py --truncation 42 --days 600  # T42, 600 days
"""

from __future__ import annotations

import argparse
import logging

import cartopy.crs as ccrs
import jax
import matplotlib.pyplot as plt
import numpy as np


jax.config.update("jax_enable_x64", True)

from notus import (
    EARTH,
    GaussianGrid,
    HeldSuarez,
    PrimitiveEquationState,
    SigmaLevels,
    SpectralTransform,
    ZonalMeanState,
    build_pe_stepper,
    compute_zonal_mean_state,
    exponential_filter,
    held_suarez_initial_state,
    plot_map,
    plot_zonal_mean,
    run_simulation,
    state_to_dataset,
    uniform_sigma_levels,
    zonal_mean_to_dataset,
)


logging.basicConfig(level=logging.INFO, format="%(message)s")


# ---------------------------------------------------------------------------
# Integration
# ---------------------------------------------------------------------------


def run_integration(
    truncation: int,
    n_levels: int,
    dt: float,
    n_days: int,
    spinup_days: int,
) -> tuple[
    ZonalMeanState,
    PrimitiveEquationState,
    list[float],
    SpectralTransform,
    GaussianGrid,
    SigmaLevels,
]:
    """Run a Held-Suarez integration and return diagnostics for plotting.

    Returns
    -------
    mean_zm : ZonalMeanState
        Time-averaged zonal-mean fields (after spinup).
    final_state : PrimitiveEquationState
        Final spectral state (for snapshot plots).
    daily_mean_t : list[float]
        Daily global-mean temperature [K] (full timeseries).
    transform : SpectralTransform
    grid : GaussianGrid
    levels : SigmaLevels
    """
    print(
        f"Running T{truncation} L{n_levels}, dt={dt:.0f}s, {n_days} days "
        f"({spinup_days} spinup + {n_days - spinup_days} averaging)"
    )

    grid = GaussianGrid(truncation=truncation)
    transform = SpectralTransform(grid, EARTH.radius)
    levels = uniform_sigma_levels(n_levels)

    state, ref_temps, surface_phi = held_suarez_initial_state(
        transform,
        EARTH,
        levels,
        perturbation_amplitude=1.0,
        seed=42,
    )

    forcing = HeldSuarez(transform, EARTH, levels)
    filt = exponential_filter(transform.arrays, dt)
    init_fn, step_fn = build_pe_stepper(
        transform=transform,
        planet=EARTH,
        levels=levels,
        reference_temperature=ref_temps,
        surface_geopotential=surface_phi,
        dt=dt,
        spectral_filter=filt,
        forcing=forcing,
    )

    # --- Diagnostic callback ---
    n_samples = 0
    accum: ZonalMeanState | None = None
    daily_mean_t: list[float] = []
    weights = np.asarray(grid.lat_weights)
    w_sum = float(np.sum(weights))
    blew_up = False

    def on_day(day: int, curr: PrimitiveEquationState, _diags: object) -> None:
        nonlocal n_samples, accum, blew_up

        # Global-mean temperature (all days, for timeseries)
        t_grid = np.asarray(jax.vmap(transform.spectral_to_grid)(curr.temperature))
        if not np.all(np.isfinite(t_grid)):
            print("ERROR: Integration has blown up!")
            blew_up = True
            return

        t_global = float(np.sum(np.mean(t_grid, axis=(0, -1)) * weights) / w_sum)
        daily_mean_t.append(t_global)

        # Accumulate zonal means after spinup
        if day > spinup_days:
            zm = compute_zonal_mean_state(curr, transform)
            n_samples += 1
            accum = zm if accum is None else jax.tree.map(np.add, accum, zm)

        if day <= 10 or day % 50 == 0 or day == n_days:
            print(f"  Day {day:5d}: T_mean={t_global:.1f} K")

    # --- Run ---
    result = run_simulation(
        init_fn=init_fn,
        step_fn=step_fn,
        initial_state=state,
        dt=dt,
        n_days=n_days,
        on_day=on_day,
        verbose=False,
    )

    if blew_up:
        msg = "Integration blew up"
        raise RuntimeError(msg)

    print(f"Done in {result.wall_time:.0f}s. Averaged {n_samples} samples.")

    if accum is None:
        msg = "No averaging samples collected"
        raise RuntimeError(msg)
    mean_zm = jax.tree.map(lambda x: x / n_samples, accum)

    return mean_zm, result.state, daily_mean_t, transform, grid, levels


# ---------------------------------------------------------------------------
# Plotting helpers (timeseries only — zonal/map plots use notus.viz)
# ---------------------------------------------------------------------------


def plot_temperature_timeseries(
    daily_mean_t: list[float],
    spinup_days: int,
    ax: plt.Axes,
) -> None:
    """Global-mean temperature vs time."""
    days = np.arange(1, len(daily_mean_t) + 1)
    ax.plot(days, daily_mean_t, "k-", linewidth=0.8)
    ax.axvline(spinup_days, color="r", linestyle="--", linewidth=0.8, label="End of spinup")
    ax.set_xlabel("Day")
    ax.set_ylabel("Global-Mean Temperature [K]")
    ax.set_title("Spinup: Global-Mean Temperature")
    ax.legend()
    ax.grid(True, alpha=0.3)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(description="Held-Suarez visualizations")
    parser.add_argument("--days", type=int, default=300, help="Total days")
    parser.add_argument("--spinup", type=int, default=100, help="Spinup days")
    parser.add_argument("--truncation", type=int, default=21, help="Spectral truncation")
    parser.add_argument("--levels", type=int, default=20, help="Vertical levels")
    parser.add_argument("--dt", type=float, default=1200.0, help="Timestep [s]")
    parser.add_argument("--output", type=str, default="held_suarez.png", help="Output filename")
    parser.add_argument("--dpi", type=int, default=200, help="Output DPI")
    args = parser.parse_args()

    # Run integration
    mean_zm, final_state, daily_mean_t, transform, grid, levels = run_integration(
        truncation=args.truncation,
        n_levels=args.levels,
        dt=args.dt,
        n_days=args.days,
        spinup_days=args.spinup,
    )

    # Create figure
    fig = plt.figure(figsize=(16, 14))
    fig.suptitle(
        f"Held-Suarez Benchmark  |  T{args.truncation} L{args.levels}  |  "
        f"Days {args.spinup + 1}-{args.days} average",
        fontsize=14,
        fontweight="bold",
    )

    # Panel layout: 3 rows x 2 cols
    # Row 1: zonal-mean U, zonal-mean T
    # Row 2: zonal-mean EKE, temperature timeseries
    # Row 3: surface pressure snapshot (wide)
    # Convert to xarray for viz module
    lat_deg = np.asarray(grid.latitudes_deg)
    sigma = np.asarray(levels.sigma_full)
    zm_ds = zonal_mean_to_dataset(mean_zm, lat_deg, sigma)
    ds = state_to_dataset(final_state, transform, EARTH, levels)

    ax1 = fig.add_subplot(3, 2, 1)
    ax2 = fig.add_subplot(3, 2, 2)
    ax3 = fig.add_subplot(3, 2, 3)
    ax4 = fig.add_subplot(3, 2, 4)
    ax5 = fig.add_subplot(3, 1, 3, projection=ccrs.Mollweide())

    plot_zonal_mean(zm_ds["u"], ax=ax1)
    plot_zonal_mean(zm_ds["temperature"], ax=ax2, contour_labels=True)
    plot_zonal_mean(zm_ds["eke"], ax=ax3)
    plot_temperature_timeseries(daily_mean_t, args.spinup, ax4)
    plot_map(ds["surface_pressure"], ax=ax5)

    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(args.output, dpi=args.dpi, bbox_inches="tight")
    print(f"\nSaved to {args.output}")


if __name__ == "__main__":
    main()
