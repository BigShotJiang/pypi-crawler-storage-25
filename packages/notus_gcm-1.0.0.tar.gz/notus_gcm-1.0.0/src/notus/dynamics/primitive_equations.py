"""Primitive equation explicit tendencies on the sphere.

Computes the explicit part of the hydrostatic primitive equations in
vorticity-divergence form on sigma levels, extending the shallow water
formulation with vertical advection, adiabatic heating, and surface
pressure coupling.

The equations (explicit tendencies only):

    dζ/dt = -curl(F) + diffusion
    dδ/dt = -div(F) - ∇²E - ∇²(g·z_s) + diffusion
    dT/dt = -v⃗·∇T + vertical_advection + κ·T·(ω/p) + diffusion
    d(ln ps)/dt = -Σ (v⃗·∇ln ps)·Δσ

where F = (ζ+f)(k̂×v) + σ̇·∂v/∂σ + R·T'·∇ln(ps), the combined momentum
flux including absolute vorticity, vertical advection of momentum, and
the explicit part of the pressure gradient.

The implicit terms (-∇²(Φ + R·T_ref·ln ps), -H·δ, -Σ δ·Δσ) are NOT
included here; they are handled by the semi-implicit time stepper.
"""

from __future__ import annotations

from collections.abc import Callable

import jax
import jax.numpy as jnp
import numpy as np

from notus.constants import PlanetaryConstants
from notus.operators import (
    hyperdiffusion_scaling,
    laplacian,
    meridional_derivative,
    spectral_curl,
    spectral_divergence,
    uv_from_vordiv,
    zonal_derivative,
)
from notus.operators.arrays import OperatorArrays
from notus.state import PrimitiveEquationState
from notus.transforms import SpectralTransform
from notus.vertical import (
    omega_over_pressure,
    sigma_dot,
    surface_pressure_tendency,
    vertical_advection,
)
from notus.vertical.sigma import SigmaLevels


def primitive_equation_tendencies(
    transform: SpectralTransform,
    planet: PlanetaryConstants,
    levels: SigmaLevels,
    reference_temperature: np.ndarray,
    surface_geopotential: jnp.ndarray,
    diffusion_order: int = 4,
    diffusion_timescale: float = 2.0 * 3600.0,
    reference_virtual_temperature: np.ndarray | None = None,
) -> Callable[[PrimitiveEquationState], PrimitiveEquationState]:
    """Build a JIT-compiled explicit tendency function for the primitive equations.

    Parameters
    ----------
    transform : SpectralTransform
        Pre-computed spectral transform.
    planet : PlanetaryConstants
        Planetary constants (captured by closure).
    levels : SigmaLevels
        Sigma vertical coordinate.
    reference_temperature : jnp.ndarray
        Reference temperature profile T_ref, shape ``(n_levels,)``.
        Used to split T = T_ref + T' for the semi-implicit scheme.
    surface_geopotential : jnp.ndarray
        Surface geopotential g·z_s in spectral space, shape ``(n_spectral,)``.
    diffusion_order : int
        Order of hyperdiffusion (4 = del-8). Set to 0 to disable.
    diffusion_timescale : float
        E-folding damping time for the smallest resolved scale [s].
    reference_virtual_temperature : np.ndarray or None
        Virtual reference temperature T_v_ref = T_ref·(1 + ε_v·q_ref),
        shape ``(n_levels,)``.  When provided, the explicit pressure
        gradient uses ``T_v - T_v_ref`` instead of ``T_v - T_ref``,
        matching the implicit solver's virtual temperature linearization.
        None uses T_ref (dry dynamics or backward-compatible behavior).

    Returns
    -------
    Callable[[PrimitiveEquationState], PrimitiveEquationState]
        JIT-compiled function mapping state to explicit tendencies.
    """
    arrays = transform.arrays
    rotation_rate = planet.rotation_rate
    gas_constant = planet.gas_constant
    kappa = planet.kappa
    epsilon_v = 1.0 / planet.epsilon_moisture - 1.0  # R_v/R_d - 1 ≈ 0.608
    sin_lat = transform.grid.sin_lat
    cos_lat = transform.grid.cos_lat

    # Pre-compute the orography tendency (constant in time)
    orography_tend = -laplacian(surface_geopotential, arrays)

    # Reference temperature for broadcasting
    t_ref_grid = jnp.asarray(reference_temperature)

    # Virtual reference temperature for the explicit pressure gradient residual
    tv_ref_grid: jnp.ndarray | None = None
    if reference_virtual_temperature is not None:
        tv_ref_grid = jnp.asarray(reference_virtual_temperature)

    # Pre-compute hyperdiffusion scaling array (constant for fixed order/timescale)
    diff_scaling: jnp.ndarray | None = None
    if diffusion_order > 0:
        diff_scaling = hyperdiffusion_scaling(arrays, diffusion_order, diffusion_timescale)

    @jax.jit
    def tendency(state: PrimitiveEquationState) -> PrimitiveEquationState:
        return _tendency_impl(
            state,
            transform,
            levels,
            arrays,
            rotation_rate,
            gas_constant,
            kappa,
            epsilon_v,
            sin_lat,
            cos_lat,
            t_ref_grid,
            orography_tend,
            diff_scaling,
            tv_ref_grid,
        )

    return tendency


def _tendency_impl(
    state: PrimitiveEquationState,
    transform: SpectralTransform,
    levels: SigmaLevels,
    arrays: OperatorArrays,
    rotation_rate: float,
    gas_constant: float,
    kappa: float,
    epsilon_v: float,
    sin_lat: jnp.ndarray,
    cos_lat: jnp.ndarray,
    t_ref: jnp.ndarray,
    orography_tend: jnp.ndarray,
    diff_scaling: jnp.ndarray | None,
    tv_ref: jnp.ndarray | None = None,
) -> PrimitiveEquationState:
    """Core PE explicit tendency computation."""
    n_levels = state.n_levels

    # Step 1: Reconstruct winds at each level (spectral)
    def _uv_at_level(vort_div: jnp.ndarray) -> jnp.ndarray:
        vort, div = vort_div[0], vort_div[1]
        u, v = uv_from_vordiv(vort, div, arrays)
        return jnp.stack([u, v])

    # Shape: (n_levels, 2, n_spectral) — vmap maps over the level axis
    vort_div_stacked = jnp.stack([state.vorticity, state.divergence], axis=1)
    uv_spec = jax.vmap(_uv_at_level)(vort_div_stacked)
    u_cos_spec = uv_spec[:, 0, :]
    v_cos_spec = uv_spec[:, 1, :]

    # Step 2: Surface pressure gradient in spectral space
    inv_a = 1.0 / arrays.radius
    dlnps_dlam_spec = zonal_derivative(state.log_surface_pressure, arrays) * inv_a
    cosphi_dlnps_dphi_spec = meridional_derivative(state.log_surface_pressure, arrays) * inv_a

    # Step 3: Transform to grid (batched)
    has_humidity = state.has_humidity
    spec_fields: list[jnp.ndarray] = [
        state.vorticity,
        state.divergence,
        u_cos_spec,
        v_cos_spec,
        state.temperature,
        jnp.stack([dlnps_dlam_spec, cosphi_dlnps_dphi_spec]),
    ]
    if has_humidity and state.humidity is not None:
        spec_fields.append(state.humidity)
    all_spec = jnp.concatenate(spec_fields, axis=0)
    all_grid = jax.vmap(transform.spectral_to_grid)(all_spec)

    vort_grid = all_grid[:n_levels]
    div_grid = all_grid[n_levels : 2 * n_levels]
    u_cos_grid = all_grid[2 * n_levels : 3 * n_levels]
    v_cos_grid = all_grid[3 * n_levels : 4 * n_levels]
    t_grid = all_grid[4 * n_levels : 5 * n_levels]
    dlnps_dlam_grid = all_grid[5 * n_levels]
    cosphi_dlnps_dphi_grid = all_grid[5 * n_levels + 1]
    q_grid = all_grid[5 * n_levels + 2 :] if has_humidity else None

    # Steps 4-6: Grid-point and vertical computations
    products_grid, lnps_tend_grid, q_products_grid = _grid_point_tendencies(
        vort_grid,
        div_grid,
        u_cos_grid,
        v_cos_grid,
        t_grid,
        dlnps_dlam_grid,
        cosphi_dlnps_dphi_grid,
        levels,
        t_ref,
        rotation_rate,
        gas_constant,
        kappa,
        epsilon_v,
        sin_lat,
        cos_lat,
        q_grid,
        tv_ref,
    )

    # Step 7: Transform all products to spectral (batched)
    products_list: list[jnp.ndarray] = [products_grid, lnps_tend_grid[None, :, :]]
    if has_humidity and q_products_grid is not None:
        products_list.append(q_products_grid)
    all_products = jnp.concatenate(products_list, axis=0)
    all_products_spec = jax.vmap(transform.grid_to_spectral)(all_products)

    # Unpack: 6*n_levels dynamical products, 1 lnps tendency, then humidity
    n_dyn = 6 * n_levels
    products_spec = all_products_spec[:n_dyn]
    lnps_tend_spec = all_products_spec[n_dyn]
    q_products_spec = all_products_spec[n_dyn + 1 :] if has_humidity else None

    # Step 8: Assemble spectral tendencies per level
    return _assemble_spectral_tendencies(
        products_spec,
        state,
        lnps_tend_spec,
        orography_tend,
        n_levels,
        arrays,
        diff_scaling,
        q_products_spec,
    )


def _grid_point_tendencies(
    vort_grid: jnp.ndarray,
    div_grid: jnp.ndarray,
    u_cos_grid: jnp.ndarray,
    v_cos_grid: jnp.ndarray,
    t_grid: jnp.ndarray,
    dlnps_dlam_grid: jnp.ndarray,
    cosphi_dlnps_dphi_grid: jnp.ndarray,
    levels: SigmaLevels,
    t_ref: jnp.ndarray,
    rotation_rate: float,
    gas_constant: float,
    kappa: float,
    epsilon_v: float,
    sin_lat: jnp.ndarray,
    cos_lat: jnp.ndarray,
    q_grid: jnp.ndarray | None = None,
    tv_ref: jnp.ndarray | None = None,
) -> tuple[jnp.ndarray, jnp.ndarray, jnp.ndarray | None]:
    """Compute grid-point products and vertical tendency terms.

    Returns (products_grid, lnps_tend_grid, q_products_grid) where
    products_grid has shape (6*n_levels, n_lat, n_lon) containing
    combined_u, combined_v, KE, T_flux_a, T_flux_b, nodal_temp_tend
    stacked along axis 0.  q_products_grid has shape
    (3*n_levels, n_lat, n_lon) if humidity is present, else None.
    """
    f_coriolis = 2.0 * rotation_rate * sin_lat[None, :, None]
    cos2_inv = 1.0 / (cos_lat[None, :, None] ** 2)
    zeta_a = vort_grid + f_coriolis

    t_ref_bc = t_ref[:, None, None]
    t_prime_grid = t_grid - t_ref_bc

    dlnps_dlam_bc = dlnps_dlam_grid[None, :, :]
    cosphi_dlnps_dphi_bc = cosphi_dlnps_dphi_grid[None, :, :]

    # v⃗·∇ln(ps)
    v_dot_grad_lnps = (u_cos_grid * dlnps_dlam_bc + v_cos_grid * cosphi_dlnps_dphi_bc) * cos2_inv

    # Horizontal products
    flux_a = zeta_a * u_cos_grid * cos2_inv
    flux_b = zeta_a * v_cos_grid * cos2_inv
    kinetic_energy = 0.5 * (u_cos_grid**2 + v_cos_grid**2) * cos2_inv
    t_flux_a = t_prime_grid * u_cos_grid * cos2_inv
    t_flux_b = t_prime_grid * v_cos_grid * cos2_inv

    # Vertical operations
    column_div = div_grid + v_dot_grad_lnps
    sd = sigma_dot(column_div, levels)

    # Vertical advection of temperature, split for semi-implicit scheme:
    # - T' part uses full σ̇ (D-dependent): fully explicit
    # - T_ref part uses σ̇_explicit (D-free): the D-dependent part is implicit
    #   (captured by the K terms in the temperature implicit weights matrix H)
    sd_explicit = sigma_dot(v_dot_grad_lnps, levels)
    t_ref_field = jnp.broadcast_to(t_ref_bc, t_prime_grid.shape)
    vert_adv_temp = vertical_advection(sd, t_prime_grid, levels) + vertical_advection(
        sd_explicit, t_ref_field, levels
    )

    # Adiabatic heating κ·T·(ω/p), split for semi-implicit scheme:
    # - T_ref part uses g_term = v⃗·∇ln(ps) only (D-dependent part is implicit)
    # - T' part uses g_term = D + v⃗·∇ln(ps) (full explicit contribution)
    omega_p_explicit = omega_over_pressure(v_dot_grad_lnps, v_dot_grad_lnps, levels)
    omega_p_full = omega_over_pressure(column_div, v_dot_grad_lnps, levels)
    adiabatic = kappa * (t_ref_bc * omega_p_explicit + t_prime_grid * omega_p_full)

    vert_mom_u = -vertical_advection(sd, u_cos_grid, levels)
    vert_mom_v = -vertical_advection(sd, v_cos_grid, levels)

    # Virtual temperature correction for pressure gradient (Phase 6b).
    # When tv_ref (T_v_ref) is provided, the implicit solver linearizes
    # around the virtual reference, so the explicit residual is the smaller
    # T_v - T_v_ref instead of T_v - T_ref.
    # When humidity is absent, tv_prime = T' (dry dynamics unchanged).
    if q_grid is not None and tv_ref is not None:
        tv_prime = t_grid * (1.0 + epsilon_v * q_grid) - tv_ref[:, None, None]
    elif q_grid is not None:
        tv_prime = t_prime_grid + epsilon_v * q_grid * t_grid
    else:
        tv_prime = t_prime_grid

    rt_grad_u = gas_constant * tv_prime * dlnps_dlam_bc
    rt_grad_v = gas_constant * tv_prime * cosphi_dlnps_dphi_bc

    # Combined momentum flux (Dinosaur convention for curl/div)
    combined_u = -flux_b + (vert_mom_u + rt_grad_u) * cos2_inv
    combined_v = flux_a + (vert_mom_v + rt_grad_v) * cos2_inv

    lnps_tend_grid = surface_pressure_tendency(v_dot_grad_lnps, levels)

    # Advective-form correction: the spectral temperature tendency uses the
    # flux divergence -∇·(T'v), but the semi-implicit splitting assumes the
    # advective form -v·∇T'.  These differ by T'·δ, which must be added as
    # a nodal term so the total equals -v·∇T' = -∇·(T'v) + T'·δ.
    advective_correction = t_prime_grid * div_grid
    nodal_temp_tend = vert_adv_temp + adiabatic + advective_correction

    products_grid = jnp.concatenate(
        [
            combined_u,
            combined_v,
            kinetic_energy,
            t_flux_a,
            t_flux_b,
            nodal_temp_tend,
        ],
        axis=0,
    )

    # Moisture transport: same advective-form treatment as temperature
    q_products_grid = None
    if q_grid is not None:
        q_flux_a = q_grid * u_cos_grid * cos2_inv
        q_flux_b = q_grid * v_cos_grid * cos2_inv
        vert_adv_q = vertical_advection(sd, q_grid, levels)
        advective_correction_q = q_grid * div_grid
        nodal_q_tend = vert_adv_q + advective_correction_q
        q_products_grid = jnp.concatenate(
            [q_flux_a, q_flux_b, nodal_q_tend],
            axis=0,
        )

    return products_grid, lnps_tend_grid, q_products_grid


def _assemble_spectral_tendencies(
    products_spec: jnp.ndarray,
    state: PrimitiveEquationState,
    lnps_tend_spec: jnp.ndarray,
    orography_tend: jnp.ndarray,
    n_levels: int,
    arrays: OperatorArrays,
    diff_scaling: jnp.ndarray | None,
    q_products_spec: jnp.ndarray | None = None,
) -> PrimitiveEquationState:
    """Assemble spectral tendencies from transformed grid products."""
    combined_u_spec = products_spec[:n_levels]
    combined_v_spec = products_spec[n_levels : 2 * n_levels]
    ke_spec = products_spec[2 * n_levels : 3 * n_levels]
    t_flux_a_spec = products_spec[3 * n_levels : 4 * n_levels]
    t_flux_b_spec = products_spec[4 * n_levels : 5 * n_levels]
    nodal_temp_tend_spec = products_spec[5 * n_levels : 6 * n_levels]

    def _assemble_level(args: jnp.ndarray) -> jnp.ndarray:
        cu, cv, ke, tfa, tfb, nodal_t, vort_k, div_k, temp_k = (
            args[0],
            args[1],
            args[2],
            args[3],
            args[4],
            args[5],
            args[6],
            args[7],
            args[8],
        )
        vort_tend = spectral_curl(cu, cv, arrays)
        div_tend = -spectral_divergence(cu, cv, arrays) - laplacian(ke, arrays) + orography_tend
        temp_tend = -spectral_divergence(tfa, tfb, arrays) + nodal_t

        if diff_scaling is not None:
            vort_tend += diff_scaling * vort_k
            div_tend += diff_scaling * div_k
            temp_tend += diff_scaling * temp_k

        return jnp.stack([vort_tend, div_tend, temp_tend])

    level_args = jnp.stack(
        [
            combined_u_spec,
            combined_v_spec,
            ke_spec,
            t_flux_a_spec,
            t_flux_b_spec,
            nodal_temp_tend_spec,
            state.vorticity,
            state.divergence,
            state.temperature,
        ],
        axis=1,
    )

    level_tendencies = jax.vmap(_assemble_level)(level_args)

    # Humidity tendencies (if present)
    humidity_tend = None
    if q_products_spec is not None and state.humidity is not None:
        q_flux_a_spec = q_products_spec[:n_levels]
        q_flux_b_spec = q_products_spec[n_levels : 2 * n_levels]
        nodal_q_tend_spec = q_products_spec[2 * n_levels : 3 * n_levels]

        def _assemble_q_level(args: jnp.ndarray) -> jnp.ndarray:
            qfa, qfb, nodal_q, q_k = args[0], args[1], args[2], args[3]
            q_tend = -spectral_divergence(qfa, qfb, arrays) + nodal_q
            if diff_scaling is not None:
                q_tend += diff_scaling * q_k
            return q_tend

        q_level_args = jnp.stack(
            [q_flux_a_spec, q_flux_b_spec, nodal_q_tend_spec, state.humidity],
            axis=1,
        )
        humidity_tend = jax.vmap(_assemble_q_level)(q_level_args)

    return PrimitiveEquationState(
        vorticity=level_tendencies[:, 0, :],
        divergence=level_tendencies[:, 1, :],
        temperature=level_tendencies[:, 2, :],
        log_surface_pressure=lnps_tend_spec,
        humidity=humidity_tend,
    )
