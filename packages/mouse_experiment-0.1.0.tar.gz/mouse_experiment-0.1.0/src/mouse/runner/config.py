"""Configuration loading utilities for SAL/SVL training.

Loads a single YAML config file. At the top level, set `default: base.yaml` (filename
only): resolve in order (1) same directory as the current YAML, (2) ``configs/<filename>``
at the repo configs root, (3) otherwise a **unique** match anywhere under ``configs/``
(recursive). If the root file exists, step (3) is skipped. Multiple matches under
subfolders raise ``ValueError``. Then merge the current config over the default (current
overrides). Supports chaining.

Essential keys depend on train_interval and eval:
- train_interval>0: load_train_dataset.name required
- train_interval=0 with loop.test_interval>0: test_envs with num_steps per env required
- train_interval=0 with loop.eval_interval>0: eval datasets required; use loop.test_interval: 0 to skip test rollouts

train_interval is inferred from load_train_dataset (->1), test_envs (->0), or eval datasets (->0) if not set.

When loop.eval_interval>0, provide either load_eval_dataset (single) or load_eval_datasets (list)
with independent ``name``/``split``/``fraction``/``exclude_envs`` per entry; metrics log as
eval/{tag}/... (default ``tag`` is ``{repo_slug}_{split}``). Dataset eval runs with or without training.

loop.sequence_length is required when training or when loop.eval_interval>0; test rollouts use
test_cache_start_length (or default 512 in experiment) instead.
"""

import math
import os
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal, cast

from omegaconf import ListConfig, OmegaConf

from mouse.data.augment import (
    AugmentMaskProbConfig,
    AugmentScalarSpec,
    AugmentTokensConfig,
    _augment_scalar_active,
)
from mouse.envs.envs import EnvConfig, is_ns_gym_env, resolve_q_star_source_for_env
from mouse.losses.dqn import DqnLossConfig
from mouse.losses.sp import SpLossConfig
from mouse.losses.sv import SvLossConfig
from mouse.losses.vec_dqn import VecDqnLossConfig


def _parse_policy_schedule_step(
    s_val: Any,
    env_yaml_path: str,
    list_label: str,
    index: int,
) -> int | float:
    """Parse a schedule step value.

    Accepts:
    - Non-negative integers (absolute step index).
    - Percentage strings like ``"0%"`` / ``"50%"`` / ``"100%"``, stored as a
      float fraction in ``[0.0, 1.0]`` and resolved at runtime relative to the
      total number of steps.
    """
    if isinstance(s_val, str) and s_val.strip().endswith("%"):
        raw = s_val.strip()[:-1]
        try:
            pct = float(raw)
        except ValueError as e:
            raise ValueError(
                f"{env_yaml_path}.action_source.{list_label}[{index}].step percentage "
                f"must be a number followed by '%', got {s_val!r}."
            ) from e
        if not (0.0 <= pct <= 100.0):
            raise ValueError(
                f"{env_yaml_path}.action_source.{list_label}[{index}].step percentage "
                f"must be between 0% and 100%, got {s_val!r}."
            )
        return pct / 100.0
    try:
        s_i = int(s_val)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"{env_yaml_path}.action_source.{list_label}[{index}].step must be a non-negative int or "
            f"a percentage string like '50%', got {s_val!r}."
        ) from e
    if s_i < 0:
        raise ValueError(
            f"{env_yaml_path}.action_source.{list_label}[{index}].step must be >= 0 or a percentage "
            f"like '50%', got {s_i!r}."
        )
    return s_i


def _check_schedule_increasing(pts: list[tuple[int | float, float]], *, env_yaml_path: str, list_label: str) -> None:
    """Check for duplicate step values; order validation is deferred to runtime resolution."""
    if len(pts) < 2:
        return
    seen: set = set()
    for s, _ in pts:
        key = float(s)
        if key in seen:
            raise ValueError(
                f"{env_yaml_path}.action_source.{list_label} has duplicate step {s!r}."
            )
        seen.add(key)


def _parse_augment_scalar(
    yaml_cfg: Any,
    key: str,
    default_mean: float,
    default_std: float,
) -> AugmentScalarSpec:
    """Parse ``{ mean, std }``, ``{ low, high }``, or a plain number (mean, std=0) from YAML."""
    raw = OmegaConf.select(yaml_cfg, key, default=None)
    if raw is None:
        return AugmentScalarSpec(default_mean, default_std)
    container = OmegaConf.to_container(raw, resolve=True)
    if isinstance(container, dict):
        if "low" in container and "high" in container:
            return AugmentScalarSpec(
                float(container.get("mean", default_mean)),
                float(container.get("std", default_std)),
                low=float(container["low"]),
                high=float(container["high"]),
            )
        return AugmentScalarSpec(
            float(container.get("mean", default_mean)),
            float(container.get("std", default_std)),
        )
    if isinstance(container, (int, float, str)):
        return AugmentScalarSpec(float(container), 0.0)
    raise ValueError(
        f"{key} must be a number or dict spec, got {type(container).__name__}."
    )


def _augment_mask_prob(yaml_cfg: Any) -> AugmentMaskProbConfig:
    """Parse ``augment_tokens.mask_prob.*``; omitted keys default to 0."""
    base = "augment_tokens.mask_prob"

    def g(key: str) -> float:
        return float(_get(cfg=yaml_cfg, key=f"{base}.{key}", default=0.0))

    return AugmentMaskProbConfig(
        action=g("action"),
        reward=g("reward"),
        done=g("done"),
        obs_continuous=g("obs_continuous"),
        obs_discrete=g("obs_discrete"),
        obs_image=g("obs_image"),
        time=g("time"),
    )


def _parse_sp_loss_type(raw: Any) -> Literal["ce", "ce-soft-fwd", "ce-soft-bwd", "js", "kl-fwd", "kl-bwd"]:
    s = str(raw).strip().lower()
    if s == "ce":
        return "ce"
    if s == "ce-soft-fwd":
        return "ce-soft-fwd"
    if s == "ce-soft-bwd":
        return "ce-soft-bwd"
    if s == "js":
        return "js"
    if s == "kl-fwd":
        return "kl-fwd"
    if s == "kl-bwd":
        return "kl-bwd"
    raise ValueError(
        "loop.sp.loss_type must be one of: 'ce', 'ce-soft-fwd', 'ce-soft-bwd', 'js', 'kl-fwd', 'kl-bwd', "
        f"got {raw!r}."
    )


def _parse_sv_loss_type(raw: Any) -> Literal["mse", "mae"]:
    s = str(raw).strip().lower()
    if s == "mse":
        return "mse"
    if s == "mae":
        return "mae"
    raise ValueError(
        "loop.sv.loss_type must be one of: 'mse', 'mae', "
        f"got {raw!r}."
    )


@dataclass
class EvalDatasetConfig:
    """One eval split to load; metrics log under ``eval/{tag}/``."""

    name: str  # HF repo id or local path
    split: str
    fraction: float | None  # (0, 1]; None = full split
    exclude_envs: list[str]  # optional env_name values to drop from this split
    tag: str  # unique key for W&B (default: ``{repo_slug}_{split}``)


@dataclass
class Config:
    max_steps: int
    train_batch_size: int
    training_enabled: bool
    train_interval: int  # 0 = rollout only; >0 = train every N steps (1 = every step)
    train_start_step: int  # first step at which to run training (0 = from start)
    eval_start_step: int  # first step at which to run eval (0 = from start)
    test_start_step: int  # first step at which to run test rollout (0 = from start)
    start_step: int  # from loop.start_step; step offset for max_steps (e.g. resume); distinct from train_start_step
    num_steps_total: int
    max_epochs: int
    max_num_actions: int  # action head output dim; max action index in dataset must be < max_num_actions; defaults to 1000
    sequence_length: int  # supervised train/eval batch window; 0 when neither (test rollouts use test_cache_* / defaults)
    backbone: str | None  # "llama" | "qwen3" | "none" — which backbone to use; None when no model needed
    # None backbone kwargs (from model.backbone.* when backbone.type = none)
    none_hidden_dim: int  # embedding / head dimension; embeddings pass directly to heads
    # Llama backbone kwargs (from model.llama.backbone.*)
    llama_hidden_dim: int
    llama_num_layers: int
    llama_num_heads: int
    llama_num_key_value_heads: int | None  # GQA; None = num_heads (no grouping)
    llama_max_position_embeddings: int
    llama_expand: int  # FFN intermediate size = hidden_dim * expand
    llama_rope_scaling: dict  # RoPE params (rope_theta, rope_type, factor, etc.); need not match pretrained
    llama_rms_norm_eps: float  # RMSNorm epsilon (Llama-3.2-1B: 1e-5)
    llama_attention_bias: bool  # attention bias (Llama-3.2-1B: false)
    # Qwen3 backbone kwargs (from model.qwen3.backbone.*)
    qwen3_hidden_dim: int
    qwen3_num_layers: int
    qwen3_num_heads: int
    qwen3_num_key_value_heads: int | None  # GQA; None = num_heads (no grouping)
    qwen3_head_dim: int | None  # explicit head dim; None = hidden_dim // num_heads
    qwen3_max_position_embeddings: int
    qwen3_expand: int  # FFN intermediate_size = hidden_dim * expand
    qwen3_rope_parameters: dict  # rope_theta, rope_type, etc.
    qwen3_rms_norm_eps: float
    qwen3_attention_bias: bool
    lr: float
    lr_groups: dict[str, float]  # per-module LR overrides keyed by named_parameters prefix (e.g. "embedder", "backbone"); falls back to lr for unmatched params
    weight_decay: float
    adam_betas: tuple[float, float]  # (beta1, beta2) for AdamW
    adam_eps: float  # epsilon for AdamW denominator
    grad_accum_steps: int  # microbatches per optimizer step (1 = disabled)
    lr_schedule: str  # "constant" (no decay) or "cosine"
    lr_warmup_steps: int  # linear warmup from 0 → lr; applied before schedule
    lr_min: float  # cosine floor; ignored when lr_schedule="constant"
    max_grad_norm: float | None  # global L2 grad clip; None disables clipping
    wandb_project: str | None  # None disables W&B logging
    wandb_run_name: str
    trackio_project: str | None  # trackio.project; None disables trackio logging
    trackio_space_id: str | None  # optional HF Space to sync trackio dashboard to (e.g. "user/my-space")
    load_dataset: bool  # True when train_dataset_name is set
    save_dataset: bool
    train_dataset_name: str | None  # load_train_dataset.name (required for train)
    train_dataset_split: str  # load_train_dataset.split
    train_dataset_exclude_envs: list[str]  # optional env_name values to exclude from train dataset
    train_dataset_fraction: float | None  # load_train_dataset.fraction in (0,1]; None = all rows

    eval_datasets: tuple[EvalDatasetConfig, ...]  # from load_eval_datasets or legacy load_eval_dataset

    save_dataset_name: str | None  # from save_dataset.name (for rollout/train save)
    num_steps: int | None
    action_source_prob: float
    save_model_name: str | None
    load_model_name: str | None
    load_backbone_name: str | None
    run_id: str
    seed: int  # for training RNG; rollout uses per-env seeds
    env_id: str | None  # optional; for model save metadata when training (e.g. env name)
    # Dataset eval: run every eval_interval steps; 0 = disabled (works with or without training)
    eval_interval: int
    eval_batch_size: int  # number of batches to run for eval loss
    train_sampling: str  # "batch" = epoch order (shuffled); "random" = random; "sequential" = natural order
    eval_sampling: str  # same options as train_sampling (sequential not meaningful for eval)
    train_num_workers: int  # background prefetch threads for training dataloader; 0 = synchronous (no threads)
    train_prefetch: int  # number of batches to keep ready in the prefetch queue for training
    eval_num_workers: int  # same as train_num_workers but for eval
    eval_prefetch: int  # same as train_prefetch but for eval
    # Periodic online test rollout (train mode)
    test_interval: int  # run test rollout every N train steps; 0 = disabled
    test_cache_start_length: int  # test rollout: initial KV prefill length (0 = default 512 in experiment)
    test_cache_max_length: int  # max cached steps before re-prefill (0 = no caching, full context each step)
    test_batch_size: int  # envs per model forward during test rollout (0 = all envs at once)
    test_envs: dict[str, EnvConfig]  # test environments; each must set num_steps
    max_num_obs_continuous: int
    max_num_obs_discrete: int
    max_num_obs_image: int
    embedding_kwargs: dict  # model.embedding.* kwargs passed directly to StepEmbedder
    sp_head_kwargs: dict    # model.sp_head.* kwargs passed directly to MLPHead
    dqn_head_kwargs: dict   # model.dqn_head.*
    sv_head_kwargs: dict    # model.sv_head.*
    vec_dqn_head_kwargs: dict  # model.vec_dqn_head.*
    embedding_frozen: bool  # model.embedding.frozen
    backbone_frozen: bool   # model.backbone.frozen
    sp_head_frozen: bool    # model.sp_head.frozen
    dqn_head_frozen: bool   # model.dqn_head.frozen
    sv_head_frozen: bool    # model.sv_head.frozen
    sp: SpLossConfig  # supervised policy loss at PREDICTION (train + eval; see ``sp_loss``)
    sv: SvLossConfig  # supervised value loss over q_star
    dqn: DqnLossConfig  # TD loss hyperparameters (used when training with ``dqn_loss``)
    vec_dqn: VecDqnLossConfig  # vector-DQN cosine-similarity loss hyperparameters (used when training with ``vec_dqn_loss``)
    augment_tokens: AugmentTokensConfig  # training-time token augmentations (train batches only)
    checkpoint_interval: int  # save checkpoint every N steps and upload to wandb; 0 = disabled
    checkpoint_keep: int  # number of most-recent local checkpoints to retain; older ones are removed


def _get(cfg, key: str, default):
    """Get nested key from OmegaConf/dict; return default if any part missing."""
    try:
        val = OmegaConf.select(cfg, key, default=None)
        return val if val is not None else default
    except Exception:
        return default


def _get_required(cfg, key: str):
    """Get nested key; raise ValueError if missing or None."""
    val = _get(cfg=cfg, key=key, default=None)
    if val is None:
        raise ValueError(f"{key} is required but was not set in the config.")
    return val


def _get_required_float(cfg, key: str) -> float:
    """Get nested key as float; raise ValueError if missing or None."""
    return float(_get_required(cfg=cfg, key=key))


def _parse_head_kwargs(yaml_cfg, head_name: str, *, include_bias_scale: bool = False) -> dict:
    """Parse model.<head_name>.* fields.

    When the section is present all specified fields are used as-is.
    When absent the head still needs defaults so the model can be built;
    those defaults live here rather than spread across call sites.

    ``bias_scale`` is only included when ``include_bias_scale=True`` because only
    ``VecDQNHead`` accepts it; passing it to ``DQNHead`` or other heads raises TypeError.
    """
    _h = lambda k, d: _get(cfg=yaml_cfg, key=f"model.{head_name}.{k}", default=d)
    result: dict = {
        "scale": float(_h("scale", 1.0)),
        "num_layers": int(_h("num_layers", 0)),
        "hidden_dim": int(_h("hidden_dim", 0)),
        "use_norm": bool(_h("use_norm", True)),
    }
    if include_bias_scale:
        _bias_scale_raw = _h("bias_scale", None)
        result["bias_scale"] = float(_bias_scale_raw) if _bias_scale_raw is not None else None
    return result


def _parse_embedding_kwargs(yaml_cfg) -> dict:
    """Parse model.embedding fields from yaml_cfg.

    When the model.embedding section is present all fields are required — no
    silent defaults.  When the section is absent entirely (e.g. play/data-
    collection configs that never build a model) sensible defaults are
    returned so those configs still parse cleanly.

    ``max_num_actions``, ``max_num_obs_*``, and ``max_num_time_steps`` are NOT
    parsed here; they live at ``model.*`` and are injected into the returned dict
    by the caller.
    """
    _emb = lambda k, d: _get(cfg=yaml_cfg, key=f"model.embedding.{k}", default=d)
    has_section = _get(cfg=yaml_cfg, key="model.embedding", default=None) is not None

    def _req(k, d):
        if has_section:
            return _get_required(cfg=yaml_cfg, key=f"model.embedding.{k}")
        return _emb(k, d)

    return {
        "include_type_token": bool(_emb("include_type_token", True)),
        "include_action_token": bool(_req("include_action_token", True)),
        "include_reward_token": bool(_req("include_reward_token", True)),
        "include_done_token": bool(_req("include_done_token", True)),
        "include_obs_continuous": bool(_req("include_obs_continuous", False)),
        "include_obs_discrete": bool(_req("include_obs_discrete", False)),
        "include_obs_image": bool(_req("include_obs_image", False)),
        "include_time_token": bool(_req("include_time_token", False)),
        "token_data_len": int(_req("token_data_len", 1)),
        "fourier_in_min": float(_req("fourier_in_min", 1e-2)),
        "fourier_in_max": float(_req("fourier_in_max", 1e2)),
        "std": float(_req("std", 0.02)),
    }


def _nonempty_name(val) -> str | None:
    """Return value as non-empty string or None (empty/whitespace → do not load/save)."""
    if val is None:
        return None
    s = (val if isinstance(val, str) else str(val)).strip()
    return s if s else None


def _parse_name_list(cfg, key: str) -> list[str]:
    """Parse optional string/list value into a list of non-empty strings."""
    raw = _get(cfg=cfg, key=key, default=None)
    if raw is None:
        return []
    if isinstance(raw, str):
        s = raw.strip()
        return [s] if s else []
    items = list(raw)
    out: list[str] = []
    for item in items:
        s = str(item).strip()
        if s:
            out.append(s)
    return out


def _parse_optional_dataset_fraction(cfg: Any, key: str) -> float | None:
    """Parse ``load_*_dataset.fraction``: optional (0, 1]; ``None`` = use full split."""
    raw = _get(cfg=cfg, key=key, default=None)
    return _parse_optional_dataset_fraction_raw(raw, key=key)


def _parse_optional_dataset_fraction_raw(raw: Any, *, key: str = "fraction") -> float | None:
    """Parse a fraction value from raw (same rules as ``_parse_optional_dataset_fraction``)."""
    if raw is None:
        return None
    f = float(raw)
    if not math.isfinite(f):
        raise ValueError(f"{key} must be a finite float.")
    if f <= 0 or f > 1:
        raise ValueError(f"{key} must be in (0, 1], got {f}.")
    return f


def _name_list_from_value(raw: Any) -> list[str]:
    """Parse optional string/list into non-empty strings (same rules as ``_parse_name_list``)."""
    if raw is None:
        return []
    if isinstance(raw, str):
        s = raw.strip()
        return [s] if s else []
    items = list(raw)
    out: list[str] = []
    for item in items:
        s = str(item).strip()
        if s:
            out.append(s)
    return out


def _eval_dataset_default_tag(name: str, split: str) -> str:
    """Stable default W&B sub-key under ``eval/`` from HF id and split."""
    slug = str(name).replace("/", "_").replace(":", "_").strip() or "dataset"
    return f"{slug}_{split}"


def _ensure_unique_eval_tag(tag: str, used: set[str]) -> str:
    if tag not in used:
        used.add(tag)
        return tag
    k = 1
    while True:
        candidate = f"{tag}_{k}"
        if candidate not in used:
            used.add(candidate)
            return candidate
        k += 1


def _parse_eval_datasets(yaml_cfg: Any) -> tuple[EvalDatasetConfig, ...]:
    """Parse ``load_eval_datasets`` (list) or legacy ``load_eval_dataset`` (single block)."""
    raw_multi = _get(cfg=yaml_cfg, key="load_eval_datasets", default=None)
    if raw_multi is not None:
        if isinstance(raw_multi, (str, bytes)) or not isinstance(
            raw_multi, (list, tuple, ListConfig)
        ):
            raise ValueError("load_eval_datasets must be a list of dataset specs (mappings).")
        entries: list[dict[str, Any]] = []
        for i, item in enumerate(raw_multi):
            if item is None:
                raise ValueError(f"load_eval_datasets[{i}] is null.")
            if OmegaConf.is_dict(item):
                d = cast(dict[str, Any], OmegaConf.to_container(item, resolve=True))
            elif isinstance(item, dict):
                d = dict(item)
            else:
                raise ValueError(f"load_eval_datasets[{i}] must be a mapping, got {type(item).__name__}.")
            entries.append(d)
    else:
        name = _nonempty_name(_get(cfg=yaml_cfg, key="load_eval_dataset.name", default=None))
        if name is None:
            return ()
        split = str(_get(cfg=yaml_cfg, key="load_eval_dataset.split", default="eval")).strip() or "eval"
        frac = _parse_optional_dataset_fraction(cfg=yaml_cfg, key="load_eval_dataset.fraction")
        excl = _parse_name_list(cfg=yaml_cfg, key="load_eval_dataset.exclude_envs")
        entries = [{"name": name, "split": split, "fraction": frac, "exclude_envs": excl}]

    specs: list[EvalDatasetConfig] = []
    used_tags: set[str] = set()
    for i, d in enumerate(entries):
        name = _nonempty_name(d.get("name"))
        if not name:
            raise ValueError(f"load_eval_datasets[{i}].name is required when eval is enabled.")
        split = str(d.get("split", "eval")).strip() or "eval"
        frac_key = f"load_eval_datasets[{i}].fraction"
        raw_frac = d.get("fraction", None)
        fraction = _parse_optional_dataset_fraction_raw(raw_frac, key=frac_key)
        exclude_envs = _name_list_from_value(d.get("exclude_envs"))
        tag_raw = d.get("tag", None)
        if tag_raw is not None:
            tag = str(tag_raw).strip()
            if not tag:
                raise ValueError(f"load_eval_datasets[{i}].tag must be non-empty when set.")
        else:
            tag = _eval_dataset_default_tag(name=name, split=split)
        tag = _ensure_unique_eval_tag(tag=tag, used=used_tags)
        specs.append(
            EvalDatasetConfig(
                name=name,
                split=split,
                fraction=fraction,
                exclude_envs=exclude_envs,
                tag=tag,
            )
        )
    return tuple(specs)


def _parse_env_config(
    env_key: str,
    env_cfg: Any,
    used_seeds: set[int],
    env_path_prefix: str = "test_envs",
) -> EnvConfig:
    """Parse a single env config from YAML into EnvConfig."""
    env_key_str = str(env_key)
    env_yaml_path = f"{env_path_prefix}.{env_key_str}"
    if not OmegaConf.is_dict(env_cfg):
        raise ValueError(f"{env_yaml_path} must be a dict of env options.")

    ec = dict(env_cfg)
    resolved_env_id = str(ec.get("id", env_key_str))
    kwargs_val = ec.get("kwargs", None)
    kwargs_norm = dict(kwargs_val) if kwargs_val is not None else None
    render = bool(ec.get("render", False))
    num_envs = int(ec.get("num_envs", 1))
    if render and num_envs != 1:
        raise ValueError(
            f"{env_yaml_path}.render=true requires {env_yaml_path}.num_envs: 1"
        )

    non_stationary_val = ec.get("non_stationary_params", None)
    if non_stationary_val is None:
        non_stationary_norm = None
    else:
        non_stationary_norm = OmegaConf.to_container(
            non_stationary_val, resolve=True
        )
        if not isinstance(non_stationary_norm, dict):
            raise ValueError(
                f"{env_yaml_path}.non_stationary_params must be a dict, got {type(non_stationary_norm).__name__}."
            )

    # Rollout-only fields (optional at parse-time; validated when train_interval=0)
    num_steps_env = ec.get("num_steps", None)
    if num_steps_env is not None:
        num_steps_env = int(num_steps_env)
    q_star_source_val = ec.get("q_star_source", None)
    q_star_source_norm: dict[str, Any] | None = None
    if q_star_source_val is not None:
        if isinstance(q_star_source_val, str):
            q_star_source_norm = {"name": q_star_source_val}
        else:
            q_star_source_norm = OmegaConf.to_container(q_star_source_val, resolve=True)
            if not isinstance(q_star_source_norm, dict):
                raise ValueError(
                    f"{env_yaml_path}.q_star_source must be a string or dict when provided, got {type(q_star_source_norm).__name__}."
                )


    action_source_val = ec.get("action_source", None)
    if action_source_val is None:
        raise ValueError(
            f"{env_yaml_path}.action_source is required and must be a mapping "
            "with keys: name, temperature. "
            "name must be one of: random, expert, learned_sp, learned_dqn, learned_sv, learned_vec_dqn. "
            "Optional: loop_prob_schedule — list of {step, prob} (unique steps; "
            "``step`` may be a non-negative int or a percentage string like '50%' / '100%', "
            "resolved relative to the total loop steps at runtime; "
            "``prob`` is a decimal in [0, 1]); "
            "prefix before the first knot defaults to 1.0; after the last knot the last prob is held. "
            "Optional episode-relative (test rollout): episode_prob_schedule with the same format."
        )
    action_source_temperature: float
    if OmegaConf.is_dict(action_source_val) or isinstance(action_source_val, dict):
        action_source_cfg = (
            OmegaConf.to_container(action_source_val, resolve=True)
            if OmegaConf.is_dict(action_source_val)
            else dict(action_source_val)
        )
        if not isinstance(action_source_cfg, dict):
            raise ValueError(
                f"{env_yaml_path}.action_source must be a mapping with name/temperature."
            )
        source_name_val = action_source_cfg.get("name", None)
        if source_name_val is None:
            raise ValueError(
                f"{env_yaml_path}.action_source.name is required when action_source is a mapping."
            )
        action_source_norm = str(source_name_val).strip().lower()
        if "temperature" not in action_source_cfg:
            raise ValueError(
                f"{env_yaml_path}.action_source.temperature is required when action_source is a mapping."
            )
        action_source_temperature = float(action_source_cfg["temperature"])
    else:
        raise ValueError(
            f"{env_yaml_path}.action_source must be a mapping with name/temperature."
        )
    prob_sched_raw = action_source_cfg.get("loop_prob_schedule", None)
    action_source_loop_prob_schedule: tuple[tuple[int | float, float], ...] | None = None
    if prob_sched_raw is not None:
        if not isinstance(prob_sched_raw, (list, tuple)):
            raise ValueError(
                f"{env_yaml_path}.action_source.loop_prob_schedule must be a list of "
                f"{{step, prob}}, got {type(prob_sched_raw).__name__}."
            )
        if len(prob_sched_raw) == 0:
            raise ValueError(
                f"{env_yaml_path}.action_source.loop_prob_schedule must be non-empty when set."
            )
        pts: list[tuple[int | float, float]] = []
        for i, item in enumerate(prob_sched_raw):
            if not isinstance(item, dict):
                raise ValueError(
                    f"{env_yaml_path}.action_source.loop_prob_schedule[{i}] must be a mapping with "
                    f"'step' and 'prob', got {type(item).__name__}."
                )
            s_val = item.get("step", None)
            p_val = item.get("prob", None)
            if s_val is None or p_val is None:
                raise ValueError(
                    f"{env_yaml_path}.action_source.loop_prob_schedule[{i}] must include "
                    f"'step' and 'prob'."
                )
            s_i = _parse_policy_schedule_step(
                s_val=s_val, env_yaml_path=env_yaml_path, list_label="loop_prob_schedule", index=i
            )
            p_i = float(p_val)
            if not (0 <= p_i <= 1):
                raise ValueError(
                    f"{env_yaml_path}.action_source.loop_prob_schedule[{i}].prob must be in [0, 1], got {p_i!r}."
                )
            pts.append((s_i, p_i))
        _check_schedule_increasing(pts, env_yaml_path=env_yaml_path, list_label="loop_prob_schedule")
        action_source_loop_prob_schedule = tuple(pts)
    ep_sched_raw = action_source_cfg.get("episode_prob_schedule", None)
    action_source_episode_prob_schedule: tuple[tuple[int | float, float], ...] | None = None
    if ep_sched_raw is not None:
        if not isinstance(ep_sched_raw, (list, tuple)):
            raise ValueError(
                f"{env_yaml_path}.action_source.episode_prob_schedule must be a list of "
                f"{{step, prob}}, got {type(ep_sched_raw).__name__}."
            )
        if len(ep_sched_raw) == 0:
            raise ValueError(
                f"{env_yaml_path}.action_source.episode_prob_schedule must be non-empty when set."
            )
        ep_pts: list[tuple[int | float, float]] = []
        for i, item in enumerate(ep_sched_raw):
            if not isinstance(item, dict):
                raise ValueError(
                    f"{env_yaml_path}.action_source.episode_prob_schedule[{i}] must be a mapping with "
                    f"'step' and 'prob', got {type(item).__name__}."
                )
            s_val = item.get("step", None)
            p_val = item.get("prob", None)
            if s_val is None or p_val is None:
                raise ValueError(
                    f"{env_yaml_path}.action_source.episode_prob_schedule[{i}] must include "
                    f"'step' and 'prob'."
                )
            s_i = _parse_policy_schedule_step(
                s_val=s_val, env_yaml_path=env_yaml_path, list_label="episode_prob_schedule", index=i
            )
            p_i = float(p_val)
            if not (0 <= p_i <= 1):
                raise ValueError(
                    f"{env_yaml_path}.action_source.episode_prob_schedule[{i}].prob must be in [0, 1], got {p_i!r}."
                )
            ep_pts.append((s_i, p_i))
        _check_schedule_increasing(ep_pts, env_yaml_path=env_yaml_path, list_label="episode_prob_schedule")
        action_source_episode_prob_schedule = tuple(ep_pts)
    _action_source_allowed = frozenset({"random", "q_star", "learned_sp", "learned_dqn", "learned_sv", "learned_vec_dqn"})
    if action_source_norm not in _action_source_allowed:
        raise ValueError(
            f"{env_yaml_path}.action_source.name must be one of "
            f"random, q_star, learned_sp, learned_dqn, learned_sv, learned_vec_dqn; got {action_source_norm!r}."
        )
    if action_source_temperature < 0.0:
        raise ValueError(
            f"{env_yaml_path}.action_source.temperature must be >= 0, got {action_source_temperature!r}."
        )
    if action_source_norm == "q_star":
        if resolve_q_star_source_for_env(resolved_env_id, q_star_source_norm) is None:
            raise ValueError(
                f"{env_yaml_path}.action_source.name='q_star' requires {env_yaml_path}.q_star_source "
                f"(or a built-in default for env id {resolved_env_id!r})."
            )
    split_env = ec.get("split", None)
    if split_env is not None:
        split_env = str(split_env)
    else:
        split_env = "train"

    env_type_val = ec.get("env_type", None)
    env_type_norm = None if env_type_val is None else (str(env_type_val).strip() or None)
    atari_preprocessing_val = ec.get("atari_preprocessing", None)
    atari_preprocessing = bool(atari_preprocessing_val) if atari_preprocessing_val is not None else None
    atari_preprocessing_kwargs_val = ec.get("atari_preprocessing_kwargs", None)
    atari_preprocessing_kwargs = (
        dict(atari_preprocessing_kwargs_val) if atari_preprocessing_kwargs_val is not None else None
    )
    observation_indices_val = ec.get("observation_indices", None)
    observation_indices = None
    if observation_indices_val is not None:
        observation_indices = [int(x) for x in list(observation_indices_val)]
        if not observation_indices:
            raise ValueError(
                f"{env_yaml_path}.observation_indices must be non-empty."
            )
    reward_scale = float(ec.get("reward_scale", 1.0))
    reward_shift = float(ec.get("reward_shift", 0.0))
    # Omitted key defaults to False; YAML null also becomes False.
    clear_history_raw = ec.get("clear_history", False)
    clear_history = False if clear_history_raw is None else bool(clear_history_raw)
    if ec.get("atari_obs_size") is not None:
        raise ValueError(
            f"{env_yaml_path}.atari_obs_size is not supported; Atari always uses full ravel. Remove it."
        )

    seed_val = ec.get("seed", None)
    if seed_val is None or str(seed_val).lower() == "none":
        # Assign a unique seed so all envs with seed: None get different seeds.
        base = random.randint(0, 2**31 - 1)
        while base in used_seeds:
            base = random.randint(0, 2**31 - 1)
        used_seeds.add(base)
        seed_val = base
    else:
        seed_val = int(seed_val)

    return EnvConfig(
        env_id=resolved_env_id,
        seed=int(seed_val),
        num_envs=num_envs,
        max_episode_steps=ec.get("max_episode_steps", None),
        kwargs=kwargs_norm,
        render=render,
        non_stationary_params=non_stationary_norm,
        num_steps=num_steps_env,
        action_source_loop_prob_schedule=action_source_loop_prob_schedule,
        action_source_episode_prob_schedule=action_source_episode_prob_schedule,
        q_star_source=q_star_source_norm,
        action_source=action_source_norm,
        action_source_temperature=action_source_temperature,
        split=split_env,
        env_type=env_type_norm,
        atari_preprocessing=atari_preprocessing,
        atari_preprocessing_kwargs=atari_preprocessing_kwargs,
        observation_indices=observation_indices,
        reward_scale=reward_scale,
        reward_shift=reward_shift,
        clear_history=clear_history,
    )


def _configs_dir(config_path: str) -> str:
    """Return the configs directory by walking up from the config file until we find a dir named 'configs'."""
    current = os.path.dirname(os.path.abspath(config_path))
    while current:
        if os.path.basename(current) == "configs":
            return current
        parent = os.path.dirname(current)
        if not parent or parent == current:
            break
        current = parent
    return os.path.dirname(os.path.abspath(config_path))


def _resolve_default_config_file(default_path: str, config_path: str) -> str:
    """Resolve ``default: <path-or-filename>`` to an absolute path.

    Order: sibling of ``config_path``, then ``configs_dir/default_path``, then any subdirectory
    of ``configs_dir`` containing exactly one file with that basename. Multiple matches
    raise ``ValueError``.
    """
    configs_dir = os.path.abspath(_configs_dir(config_path))
    config_dir = os.path.dirname(os.path.abspath(config_path))
    sibling = os.path.normpath(os.path.join(config_dir, default_path))
    if os.path.isfile(sibling):
        return sibling
    root_candidate = os.path.normpath(os.path.join(configs_dir, default_path))
    if os.path.isfile(root_candidate):
        return root_candidate
    matches: list[str] = []
    root = Path(configs_dir)
    if root.is_dir():
        for p in root.rglob(Path(default_path).name):
            if p.is_file():
                matches.append(os.path.normpath(str(p)))
    matches = sorted(set(matches))
    if len(matches) == 1:
        return matches[0]
    if len(matches) == 0:
        raise FileNotFoundError(
            f"Default config not found under {configs_dir}: {default_path!r} "
            f"(from default: {default_path!r})"
        )
    raise ValueError(
        f"Ambiguous default: multiple files named {Path(default_path).name!r} under {configs_dir}: {matches}"
    )


def _load_yaml_with_defaults(config_path: str, visited: set[str] | None = None) -> Any:
    """Load YAML and merge with default file if specified.

    If the YAML has a top-level 'default' key (filename/path of another YAML), that file
    is resolved via :func:`_resolve_default_config_file`, then the current config is
    merged over it.
    Supports chaining (default can have its own default). Detects circular references.
    """
    def _to_plain_dict(cfg: Any) -> dict[str, Any]:
        container = OmegaConf.to_container(cfg, resolve=True)
        if container is None:
            return {}
        if not isinstance(container, dict):
            raise ValueError(
                f"Config root must be a mapping, got {type(container).__name__}."
            )
        return cast(dict[str, Any], container)

    def _merge_value_by_value(base: dict[str, Any], override: dict[str, Any]) -> dict[str, Any]:
        """Recursively merge nested dicts key-by-key.

        Non-dict values (including lists) are replaced by override values.
        """
        out: dict[str, Any] = {k: v for k, v in base.items()}
        for key, override_val in override.items():
            base_val = out.get(key, None)
            if isinstance(base_val, dict) and isinstance(override_val, dict):
                out[key] = _merge_value_by_value(base_val, override_val)
            else:
                out[key] = override_val
        return out

    config_path = os.path.abspath(config_path)
    if visited is None:
        visited = set()
    if config_path in visited:
        raise ValueError(f"Circular default chain detected: {config_path}")
    visited.add(config_path)

    yaml_cfg = OmegaConf.load(config_path)
    yaml_dict = _to_plain_dict(yaml_cfg)
    default_path = _nonempty_name(yaml_dict.get("default", None))
    if default_path is None:
        yaml_dict.pop("default", None)
        return OmegaConf.create(yaml_dict)

    resolved = _resolve_default_config_file(default_path=default_path, config_path=config_path)

    base_cfg = _load_yaml_with_defaults(config_path=resolved, visited=visited)
    base_dict = _to_plain_dict(base_cfg)
    merged_dict = _merge_value_by_value(base_dict, yaml_dict)
    merged_dict.pop("default", None)  # remove chain key from merged result
    return OmegaConf.create(merged_dict)


def _hydrate_backbone_stage_load_config(yaml_cfg: Any) -> Any:
    """Populate backbone defaults from ``model.backbone.load_config`` when present.

    Values from the loaded model config are applied only for missing keys, so explicit
    YAML values still win value-by-value.
    """
    def _path_has_value(path: str) -> bool:
        return OmegaConf.select(yaml_cfg, path, default=None) is not None

    def _set_if_missing(path: str, value: Any) -> None:
        if value is None or _path_has_value(path):
            return
        OmegaConf.update(yaml_cfg, path, value, merge=True)

    def _load_model_cfg(source: str) -> Any:
        source = str(source).strip()
        if not source:
            raise ValueError("load_config must be a non-empty string.")
        if os.path.isfile(source) and source.lower().endswith((".yaml", ".yml")):
            loaded = OmegaConf.to_container(OmegaConf.load(source), resolve=True)
            if not isinstance(loaded, dict):
                raise ValueError(
                    f"load_config file {source!r} must contain a mapping at root."
                )
            return loaded
        from transformers import AutoConfig
        return AutoConfig.from_pretrained(source)

    def _cfg_get(cfg_obj: Any, key: str, default: Any = None) -> Any:
        if isinstance(cfg_obj, dict):
            return cfg_obj.get(key, default)
        return getattr(cfg_obj, key, default)

    backbone_type = str(
        OmegaConf.select(yaml_cfg, "model.backbone.type", default="") or ""
    ).lower().strip()

    if backbone_type not in ("llama", "qwen3"):
        return yaml_cfg

    rope_key = "rope_scaling" if backbone_type == "llama" else "rope_parameters"
    include_head_dim = backbone_type == "qwen3"

    load_cfg_path = "model.backbone.load_config"
    source = _nonempty_name(OmegaConf.select(yaml_cfg, load_cfg_path, default=None))
    if source is None:
        return yaml_cfg

    model_cfg = _load_model_cfg(source)

    model_type = str(_cfg_get(model_cfg, "model_type", "")).strip().lower()
    if model_type and model_type != backbone_type:
        raise ValueError(
            f"{load_cfg_path}={source!r} has model_type={model_type!r}, expected {backbone_type!r}."
        )

    hidden = _cfg_get(model_cfg, "hidden_size", None)
    inter = _cfg_get(model_cfg, "intermediate_size", None)
    expand = None
    if hidden is not None and inter is not None:
        hidden_i = int(hidden)
        inter_i = int(inter)
        if inter_i % hidden_i != 0:
            raise ValueError(
                f"{load_cfg_path}={source!r} has intermediate_size={inter_i} not divisible by hidden_size={hidden_i}."
            )
        expand = inter_i // hidden_i

    prefix = "model.backbone"
    _set_if_missing(f"{prefix}.hidden_dim", hidden)
    _set_if_missing(f"{prefix}.num_layers", _cfg_get(model_cfg, "num_hidden_layers", None))
    _set_if_missing(f"{prefix}.num_heads", _cfg_get(model_cfg, "num_attention_heads", None))
    _set_if_missing(f"{prefix}.num_key_value_heads", _cfg_get(model_cfg, "num_key_value_heads", None))
    if include_head_dim:
        _set_if_missing(f"{prefix}.head_dim", _cfg_get(model_cfg, "head_dim", None))
    _set_if_missing(f"{prefix}.max_position_embeddings", _cfg_get(model_cfg, "max_position_embeddings", None))
    _set_if_missing(f"{prefix}.expand", expand)
    rope_val = _cfg_get(model_cfg, rope_key, None) or _cfg_get(model_cfg, "rope_scaling", None)
    _set_if_missing(f"{prefix}.{rope_key}", rope_val)
    _set_if_missing(f"{prefix}.rms_norm_eps", _cfg_get(model_cfg, "rms_norm_eps", None))
    _set_if_missing(f"{prefix}.attention_bias", _cfg_get(model_cfg, "attention_bias", None))

    return yaml_cfg


def load_config_yaml(config_path: str) -> Any:
    """Load the fully resolved YAML (following ``default`` chain)."""
    if not (config_path and config_path.strip()):
        raise ValueError("Config file path is required. Usage: run <config.yaml>")
    config_path = config_path.strip()
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")
    yaml_cfg = _load_yaml_with_defaults(config_path)
    return _hydrate_backbone_stage_load_config(yaml_cfg)


def load_config(config_path: str) -> tuple[Config, Any]:
    """Load configuration from a YAML file.

    If the YAML has a top-level 'default' key, that file is loaded first and
    the current config is merged over it (current overrides default).

    Returns ``(cfg, resolved_yaml)``. The YAML object is the same one produced by
    :func:`load_config_yaml` (fully merged and hydrated); pass it to model setup
    so the file is not read a second time.

    Essential keys depend on train_interval and eval:
    - train_interval=0: test_envs with num_steps per env required when loop.test_interval > 0
    - train_interval>0: load_train_dataset.name required
    - loop.sequence_length required when training (train_interval > 0) or when loop.eval_interval > 0;
      omit when only test rollouts (no train/eval datasets) — test context uses test_cache_start_length or 512

    train_interval defaults: 1 if load_train_dataset set, else 0 if test_envs or eval datasets set.

    Raises:
        ValueError: If config_path is empty or an essential key is missing.
        FileNotFoundError: If the config file does not exist.
    """
    if not (config_path and config_path.strip()):
        raise ValueError("Config file path is required. Usage: run <config.yaml>")

    config_path = config_path.strip()
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")

    yaml_cfg = load_config_yaml(config_path)

    # --- train_interval (0 = test rollouts only; >0 = train every N steps) ---
    _train_interval_raw = _get(cfg=yaml_cfg, key="loop.train_interval", default=None)
    _has_load_train = _nonempty_name(_get(cfg=yaml_cfg, key="load_train_dataset.name", default=None)) is not None
    _has_test_envs = OmegaConf.is_dict(yaml_cfg.get("test_envs"))

    _has_eval_dataset = (
        _nonempty_name(_get(cfg=yaml_cfg, key="load_eval_dataset.name", default=None)) is not None
    )
    _eval_datasets_raw = _get(cfg=yaml_cfg, key="load_eval_datasets", default=None)
    _has_eval_list = OmegaConf.is_list(_eval_datasets_raw) and len(_eval_datasets_raw) > 0

    if _train_interval_raw is not None:
        _train_interval = int(_train_interval_raw)
    else:
        if _has_load_train:
            _train_interval = 1
        elif _has_test_envs:
            _train_interval = 0
        elif _has_eval_dataset or _has_eval_list:
            _train_interval = 0
        else:
            raise ValueError(
                "Config must define load_train_dataset.name (training), test_envs (test rollouts), "
                "or load_eval_dataset / load_eval_datasets (with loop.eval_interval > 0). "
                "Or set loop.train_interval explicitly."
            )

    used_seeds: set[int] = set()

    # test_envs
    test_envs_raw = yaml_cfg.get("test_envs")
    test_envs_parsed: dict[str, EnvConfig] = {}
    if test_envs_raw is not None and OmegaConf.is_dict(test_envs_raw):
        for ek, ev in dict(test_envs_raw).items():
            test_envs_parsed[str(ek)] = _parse_env_config(
                env_key=str(ek),
                env_cfg=ev,
                used_seeds=used_seeds,
                env_path_prefix="test_envs",
            )

    _eval_interval_yaml = int(_get(cfg=yaml_cfg, key="loop.eval_interval", default=0))
    _test_interval_raw = _get(cfg=yaml_cfg, key="loop.test_interval", default=None)
    _test_interval_early = (
        int(_test_interval_raw)
        if _test_interval_raw is not None
        else (1 if _train_interval == 0 else 0)
    )

    if _train_interval == 0:
        if not test_envs_parsed and _test_interval_early > 0:
            raise ValueError(
                "Config must define test_envs when train_interval=0 and loop.test_interval > 0."
            )
        if not test_envs_parsed and _eval_interval_yaml <= 0:
            raise ValueError(
                "When train_interval=0, set test_envs for online test rollouts, "
                "or loop.eval_interval > 0 with eval datasets (and use loop.test_interval: 0 if you do not want test rollouts)."
            )
        if test_envs_parsed and _test_interval_early > 0:
            for ek, ev in test_envs_parsed.items():
                if ev.num_steps is None:
                    raise ValueError(
                        f"test_envs.{ek}.num_steps is required when train_interval=0 and loop.test_interval > 0."
                    )

    # --- training_enabled: True when train_interval > 0 ---
    training_enabled = _train_interval > 0
    _llama_rope_default = {
        "rope_theta": 500000.0,
        "rope_type": "llama3",
        "factor": 32.0,
        "high_freq_factor": 4.0,
        "low_freq_factor": 1.0,
        "original_max_position_embeddings": 8192,
    }
    _qwen3_rope_default = {
        "rope_theta": 1000000.0,
        "rope_type": "default",
    }
    _backbone_get = lambda k, d=None: _get(cfg=yaml_cfg, key=f"model.backbone.{k}", default=d)
    _backbone_get_required = lambda k: _get_required(cfg=yaml_cfg, key=f"model.backbone.{k}")
    _llama_backbone_hidden_dim = int(_backbone_get("hidden_dim", 2048))
    _qwen3_backbone_hidden_dim = _llama_backbone_hidden_dim
    _dqn_tau = float(_get(cfg=yaml_cfg, key="loop.dqn.tau", default=0.01))
    _embedding_kwargs = _parse_embedding_kwargs(yaml_cfg)
    _has_model = _get(cfg=yaml_cfg, key="model", default=None) is not None
    _model_get = lambda k, d: (
        _get_required(cfg=yaml_cfg, key=f"model.{k}") if _has_model else d
    )
    _embedding_kwargs["max_num_actions"] = int(_model_get("max_num_actions", 1))
    _embedding_kwargs["max_num_obs_continuous"] = int(_model_get("max_num_obs_continuous", 0))
    _embedding_kwargs["max_num_obs_discrete"] = int(_model_get("max_num_obs_discrete", 0))
    _embedding_kwargs["max_num_obs_image"] = int(_model_get("max_num_obs_image", 0))
    _embedding_kwargs["max_num_time_steps"] = int(_model_get("max_num_time_steps", 0))
    _backbone = (
        str(_get_required(cfg=yaml_cfg, key="model.backbone.type")).lower().strip()
        if _get(cfg=yaml_cfg, key="model.backbone", default=None) is not None
        else None
    )

    def _loop(k, d=None):
        return _get(cfg=yaml_cfg, key=f"loop.{k}", default=d)

    def _loop_required(k):
        return _get_required(cfg=yaml_cfg, key=f"loop.{k}")

    def _loop_required_when_training(k):
        if training_enabled:
            return _get_required(cfg=yaml_cfg, key=f"loop.{k}")
        return _get(cfg=yaml_cfg, key=f"loop.{k}", default=None)

    _needs_sequence_length = training_enabled or (_eval_interval_yaml > 0)
    if _needs_sequence_length:
        _sequence_length = int(_loop_required("sequence_length"))
    else:
        _sequence_length = 0
    if _needs_sequence_length and _sequence_length <= 0:
        raise ValueError(
            "loop.sequence_length must be > 0 when loop.train_interval > 0 or loop.eval_interval > 0."
        )

    cfg_dict = {
        "training_enabled": training_enabled,
        "train_interval": _train_interval,
        "train_start_step": int(_loop("train_start_step", 0)),
        "eval_start_step": int(_loop("eval_start_step", 0)),
        "test_start_step": int(_loop("test_start_step", 0)),
        "start_step": int(_loop("start_step", 0)) if (training_enabled or _eval_interval_yaml > 0) else 0,
        "num_steps_total": int(_loop_required("num_steps")),
        "max_epochs": int(_loop("max_epochs", 0)) if training_enabled else 0,
        "train_batch_size": int(_loop_required_when_training("train_batch_size") or 0),
        "sequence_length": _sequence_length,
        "backbone": _backbone,
        # None: settings from model.backbone.* (when backbone.type = none)
        "none_hidden_dim": _llama_backbone_hidden_dim,
        # Llama: settings from model.backbone.* (when backbone.type = llama)
        "llama_hidden_dim": _llama_backbone_hidden_dim,
        "llama_num_layers": int(_backbone_get("num_layers", 16)),
        "llama_num_heads": int(_backbone_get("num_heads", 32)),
        "llama_num_key_value_heads": (
            int(nkv) if (nkv := _backbone_get("num_key_value_heads")) is not None else None
        ),
        "llama_max_position_embeddings": int(_backbone_get("max_position_embeddings", 131072)),
        "llama_expand": int(_backbone_get("expand", 4)),
        "llama_rope_scaling": _backbone_get("rope_scaling", _llama_rope_default),
        "llama_rms_norm_eps": float(_backbone_get("rms_norm_eps", 1e-5)),
        "llama_attention_bias": bool(_backbone_get("attention_bias", False)),
        # Qwen3: settings from model.backbone.* (when backbone.type = qwen3)
        "qwen3_hidden_dim": _qwen3_backbone_hidden_dim,
        "qwen3_num_layers": int(_backbone_get("num_layers", 16)),
        "qwen3_num_heads": int(_backbone_get("num_heads", 16)),
        "qwen3_num_key_value_heads": (
            int(nkv) if (nkv := _backbone_get("num_key_value_heads")) is not None else None
        ),
        "qwen3_head_dim": (
            int(hd) if (hd := _backbone_get("head_dim")) is not None else None
        ),
        "qwen3_max_position_embeddings": int(_backbone_get("max_position_embeddings", 32768)),
        "qwen3_expand": int(_backbone_get("expand", 3)),
        "qwen3_rope_parameters": _backbone_get("rope_parameters", _qwen3_rope_default),
        "qwen3_rms_norm_eps": float(_backbone_get("rms_norm_eps", 1e-6)),
        "qwen3_attention_bias": bool(_backbone_get("attention_bias", False)),
        "lr": float(_loop_required_when_training("lr") or 0.0),
        "lr_groups": (
            {k: float(v) for k, v in _loop("lr_groups", {}).items()}
            if training_enabled else {}
        ),
        "weight_decay": float(_loop_required_when_training("weight_decay") or 0.0),
        "adam_betas": (
            tuple(float(x) for x in _loop_required_when_training("adam_betas"))
            if training_enabled else (0.9, 0.999)
        ),
        "adam_eps": float(_loop_required_when_training("adam_eps") or 1e-8),
        "grad_accum_steps": int(_loop_required_when_training("grad_accum_steps") or 1),
        "lr_schedule": str(_loop_required_when_training("lr_schedule") or "constant").lower().strip(),
        "lr_warmup_steps": int(_loop("lr_warmup_steps", 0)) if training_enabled else 0,
        "lr_min": float(_loop("lr_min", 0.0)) if training_enabled else 0.0,
        "max_grad_norm": (
            (lambda v: float(v) if v is not None else None)(_loop("max_grad_norm"))
            if training_enabled else None
        ),
        "save_model_name": _nonempty_name(_get(cfg=yaml_cfg, key="model.save_model_name", default=None)),
        "load_model_name": _nonempty_name(_get(cfg=yaml_cfg, key="model.load_model_name", default=None)),
        "load_backbone_name": _nonempty_name(_backbone_get("load_pretrained_name")),
        "eval_interval": _eval_interval_yaml,
        "eval_batch_size": int(_loop("eval_batch_size", 0)) if (training_enabled or _eval_interval_yaml > 0) else 0,
        "train_sampling": str(_loop_required_when_training("train_sampling") or "batch").lower(),
        "eval_sampling": str(_loop("eval_sampling", "batch")).lower(),
        "train_num_workers": int(_loop("train_num_workers", 1)),
        "train_prefetch": int(_loop("train_prefetch", 4)),
        "eval_num_workers": int(_loop("eval_num_workers", 1)),
        "eval_prefetch": int(_loop("eval_prefetch", 4)),
        "test_interval": (
            int(_loop("test_interval", 1)) if _train_interval == 0
            else int(_loop("test_interval", 0)) if training_enabled else 0
        ),
        "test_cache_start_length": int(_loop("test_cache_start_length", 0)) if (_train_interval == 0 or training_enabled) else 0,
        "test_cache_max_length": int(_loop("test_cache_max_length", 0)) if (_train_interval == 0 or training_enabled) else 0,
        "test_batch_size": int(_loop("test_batch_size", 0)) if (_train_interval == 0 or training_enabled) else 0,
        "test_envs": test_envs_parsed,
        "embedding_kwargs": _embedding_kwargs,
        "max_num_actions": int(_embedding_kwargs["max_num_actions"]),
        "max_num_obs_continuous": int(_embedding_kwargs["max_num_obs_continuous"]),
        "max_num_obs_discrete": int(_embedding_kwargs["max_num_obs_discrete"]),
        "max_num_obs_image": int(_embedding_kwargs["max_num_obs_image"]),
        "sp_head_kwargs": _parse_head_kwargs(yaml_cfg=yaml_cfg, head_name="sp_head"),
        "dqn_head_kwargs": _parse_head_kwargs(yaml_cfg=yaml_cfg, head_name="dqn_head"),
        "sv_head_kwargs": _parse_head_kwargs(yaml_cfg=yaml_cfg, head_name="sv_head"),
        "vec_dqn_head_kwargs": {
            **_parse_head_kwargs(yaml_cfg=yaml_cfg, head_name="vec_dqn_head", include_bias_scale=True),
            "vec_dim": int(_get(cfg=yaml_cfg, key="model.vec_dqn_head.vec_dim", default=64)),
        },
        "embedding_frozen": bool(_get(cfg=yaml_cfg, key="model.embedding.frozen", default=False)),
        "backbone_frozen": bool(_get(cfg=yaml_cfg, key="model.backbone.frozen", default=False)),
        "sp_head_frozen": bool(_get(cfg=yaml_cfg, key="model.sp_head.frozen", default=False)),
        "dqn_head_frozen": bool(_get(cfg=yaml_cfg, key="model.dqn_head.frozen", default=False)),
        "sv_head_frozen": bool(_get(cfg=yaml_cfg, key="model.sv_head.frozen", default=False)),
        "sp": SpLossConfig(
            weight=float(_loop("sp.weight", 0.0)),
            label_smoothing=float(_loop("sp.label_smoothing", 0.0)),
            loss_type=_parse_sp_loss_type(_loop("sp.loss_type", "ce")),
            temperature=float(_loop("sp.temperature", 1.0)),
        ),
        "sv": SvLossConfig(
            weight=float(_loop("sv.weight", 0.0)),
            loss_type=_parse_sv_loss_type(_loop("sv.loss_type", "mse")),
        ),
        "dqn": DqnLossConfig(
            weight=float(_loop("dqn.weight", 0.0)),
            gamma=float(_loop("dqn.gamma", 0.99)),
            gamma_terminal=float(_loop("dqn.gamma_terminal", 0.0)),
            gamma_truncated=float(_loop("dqn.gamma_truncated", 0.0)),
            tau=_dqn_tau,
            normalize_reward_mean=bool(_loop("dqn.normalize_reward_mean", False)),
            normalize_reward_std=bool(_loop("dqn.normalize_reward_std", False)),
            normalize_reward_eps=float(_loop("dqn.normalize_reward_eps", 1e-8)),
            normalize_reward_std_target=float(_loop("dqn.normalize_reward_std_target", 1.0)),
            use_xformed_reward=bool(_loop("dqn.use_xformed_reward", False)),
            cql_weight=float(_loop("dqn.cql_weight", 0.0)),
            cql_scale_q_eps=float(_loop("dqn.cql_scale_q_eps", 1.0)),
            reward_scale=float(_loop("dqn.reward_scale", 1.0)),
            reward_shift=float(_loop("dqn.reward_shift", 0.0)),
        ),
        "vec_dqn": VecDqnLossConfig(
            weight=float(_loop("vec_dqn.weight", 0.0)),
            tau=float(_loop("vec_dqn.tau", 0.01)),
            reward_scale=float(_loop("vec_dqn.reward_scale", 1.0)),
            reward_shift=float(_loop("vec_dqn.reward_shift", 0.0)),
            normalize_reward_mean=bool(_loop("vec_dqn.normalize_reward_mean", False)),
            normalize_reward_std=bool(_loop("vec_dqn.normalize_reward_std", False)),
            normalize_reward_eps=float(_loop("vec_dqn.normalize_reward_eps", 1e-8)),
            normalize_reward_std_target=float(_loop("vec_dqn.normalize_reward_std_target", 1.0)),
            use_xformed_reward=bool(_loop("vec_dqn.use_xformed_reward", False)),
        ),
        "augment_tokens": AugmentTokensConfig(
            enabled=bool(_get(cfg=yaml_cfg, key="augment_tokens.enabled", default=False)),
            permute_tokens=bool(_get(cfg=yaml_cfg, key="augment_tokens.permute_tokens", default=False)),
            scale_reward=_parse_augment_scalar(yaml_cfg=yaml_cfg, key="augment_tokens.scale_reward", default_mean=1.0, default_std=0.0),
            shift_reward=_parse_augment_scalar(yaml_cfg=yaml_cfg, key="augment_tokens.shift_reward", default_mean=0.0, default_std=0.0),
            scale_obs=_parse_augment_scalar(yaml_cfg=yaml_cfg, key="augment_tokens.scale_obs_continuous", default_mean=1.0, default_std=0.0),
            shift_obs=_parse_augment_scalar(yaml_cfg=yaml_cfg, key="augment_tokens.shift_obs_continuous", default_mean=0.0, default_std=0.0),
            scale_obs_image=_parse_augment_scalar(yaml_cfg=yaml_cfg, key="augment_tokens.scale_obs_image", default_mean=1.0, default_std=0.0),
            shift_obs_image=_parse_augment_scalar(yaml_cfg=yaml_cfg, key="augment_tokens.shift_obs_image", default_mean=0.0, default_std=0.0),
            permute_obs_discrete=bool(_get(cfg=yaml_cfg, key="augment_tokens.permute_obs_discrete", default=False)),
            permute_action=_get(cfg=yaml_cfg, key="augment_tokens.permute_action", default=False),
            permute_done=bool(_get(cfg=yaml_cfg, key="augment_tokens.permute_done", default=False)),
            mask_prob=_augment_mask_prob(yaml_cfg),
        ),
        "wandb_project": _nonempty_name(_get(cfg=yaml_cfg, key="wandb.project", default=None)),
        "wandb_run_name": _nonempty_name(_get(cfg=yaml_cfg, key="wandb.run_name", default=None)),
        "trackio_project": _nonempty_name(_get(cfg=yaml_cfg, key="trackio.project", default=None)),
        "trackio_space_id": _nonempty_name(_get(cfg=yaml_cfg, key="trackio.space_id", default=None)),
        "train_dataset_name": _nonempty_name(_get(cfg=yaml_cfg, key="load_train_dataset.name", default=None)),
        "train_dataset_split": str(_get(cfg=yaml_cfg, key="load_train_dataset.split", default="train")).strip() or "train",
        "train_dataset_exclude_envs": _parse_name_list(cfg=yaml_cfg, key="load_train_dataset.exclude_envs"),
        "train_dataset_fraction": _parse_optional_dataset_fraction(
            cfg=yaml_cfg, key="load_train_dataset.fraction"
        ),

        "eval_datasets": _parse_eval_datasets(yaml_cfg),

        "save_dataset_name": _nonempty_name(_get(cfg=yaml_cfg, key="save_dataset.name", default=None)),
        "load_dataset": _nonempty_name(_get(cfg=yaml_cfg, key="load_train_dataset.name", default=None)) is not None,
        "save_dataset": _nonempty_name(_get(cfg=yaml_cfg, key="save_dataset.name", default=None)) is not None,
        "num_steps": None,
        "action_source_prob": 0.0,
        "run_id": str(random.randint(10000000, 99999999)),
        "seed": int(_get_required(cfg=yaml_cfg, key="seed")),
        "env_id": _get(cfg=yaml_cfg, key="env_id", default=None),
        "checkpoint_interval": int(_loop("checkpoint_interval", 0) or 0),
        "checkpoint_keep": int(_loop("checkpoint_keep", 1) or 1),
    }

    cfg_dict["max_steps"] = cfg_dict["start_step"] + cfg_dict["num_steps_total"]

    if not cfg_dict.get("wandb_run_name"):
        cfg_dict["wandb_run_name"] = Path(config_path).stem

    if _train_interval > 0 and not cfg_dict.get("train_dataset_name"):
        raise ValueError(
            "Config must define load_train_dataset.name when train_interval>0. "
            "Example: load_train_dataset: { name: 'user/dataset', split: 'train' }"
        )


    if cfg_dict["test_interval"] > 0:
        if not test_envs_parsed:
            raise ValueError(
                "Config must define test_envs when test_interval > 0."
            )
        for ek, ev in test_envs_parsed.items():
            if ev.num_steps is None:
                raise ValueError(
                    f"test_envs.{ek}.num_steps is required. Set num_steps per env."
                )
    if cfg_dict["test_batch_size"] < 0:
        raise ValueError("loop.test_batch_size must be >= 0.")

    # Model architecture only needed when training, loading a saved model, or using learned policy.
    _needs_model = (
        training_enabled
        or int(cfg_dict.get("eval_interval", 0) or 0) > 0
        or cfg_dict["load_model_name"] is not None
        or any(ev.action_source in {"learned_sp", "learned_dqn", "learned_sv"} for ev in test_envs_parsed.values())
    )
    if _needs_model and cfg_dict["backbone"] is None:
        raise ValueError(
            "model.backbone.type is required when training or loading a model. "
            "Set model.backbone.type to 'llama', 'qwen3', or 'none'."
        )
    if cfg_dict["backbone"] is not None and cfg_dict["backbone"] not in ("llama", "qwen3", "none"):
        raise ValueError(
            f"model.backbone.type must be 'llama', 'qwen3', or 'none', got {cfg_dict['backbone']!r}."
        )
    if _needs_model:
        model_cfg = yaml_cfg.get("model", {})
        backbone_cfg = model_cfg.get("backbone", {}) if OmegaConf.is_dict(model_cfg) else {}
        if not OmegaConf.is_dict(backbone_cfg):
            raise ValueError(
                "model.backbone must be a dict with at least 'type' and backbone architecture settings."
            )
        if cfg_dict["backbone"] == "llama":
            if cfg_dict["llama_num_layers"] < 1:
                raise ValueError(
                    f"model.backbone.num_layers must be >= 1, got {cfg_dict['llama_num_layers']}."
                )
            if cfg_dict["llama_num_heads"] <= 0:
                raise ValueError("model.backbone.num_heads must be >= 1.")
        if cfg_dict["backbone"] == "qwen3":
            if cfg_dict["qwen3_num_layers"] < 1:
                raise ValueError(
                    f"model.backbone.num_layers must be >= 1, got {cfg_dict['qwen3_num_layers']}."
                )
            if cfg_dict["qwen3_num_heads"] <= 0:
                raise ValueError("model.backbone.num_heads must be >= 1.")
    if training_enabled and cfg_dict["max_epochs"] < 0:
        raise ValueError("loop.max_epochs must be >= 0.")

    for key in ("train_sampling", "eval_sampling"):
        val = cfg_dict.get(key, "batch")
        if val not in ("batch", "random", "sequential"):
            raise ValueError(f"loop.{key} must be 'batch', 'random', or 'sequential', got {val!r}.")
    if cfg_dict.get("train_num_workers", 1) < 0:
        raise ValueError("loop.train_num_workers must be >= 0 (0 = synchronous).")
    if cfg_dict.get("train_prefetch", 4) < 1:
        raise ValueError("loop.train_prefetch must be >= 1.")
    if cfg_dict.get("eval_num_workers", 1) < 0:
        raise ValueError("loop.eval_num_workers must be >= 0 (0 = synchronous).")
    if cfg_dict.get("eval_prefetch", 4) < 1:
        raise ValueError("loop.eval_prefetch must be >= 1.")
    if cfg_dict["sp"].weight < 0:
        raise ValueError("loop.sp.weight must be >= 0.")
    if cfg_dict["sv"].weight < 0:
        raise ValueError("loop.sv.weight must be >= 0.")
    if cfg_dict["dqn"].weight < 0:
        raise ValueError("loop.dqn.weight must be >= 0.")
    if (
        training_enabled
        and int(cfg_dict.get("train_interval", 0) or 0) > 0
        and cfg_dict["sp"].weight <= 0
        and cfg_dict["sv"].weight <= 0
        and cfg_dict["dqn"].weight <= 0
        and cfg_dict["vec_dqn"].weight <= 0
    ):
        raise ValueError(
            "At least one of loop.sp.weight, loop.sv.weight, loop.dqn.weight, or loop.vec_dqn.weight must be > 0 when train_interval > 0."
        )
    if cfg_dict.get("grad_accum_steps", 1) < 1:
        raise ValueError("loop.grad_accum_steps must be >= 1.")
    label_smoothing = cfg_dict["sp"].label_smoothing
    if not (0.0 <= label_smoothing < 1.0):
        raise ValueError(f"loop.sp.label_smoothing must be in [0, 1), got {label_smoothing!r}.")
    _sp = cfg_dict["sp"]
    if _sp.loss_type not in ("ce",) and not (_sp.temperature > 0.0):
        raise ValueError(
            "loop.sp.temperature must be > 0 when loop.sp.loss_type is one of "
            f"('ce-soft-fwd', 'ce-soft-bwd', 'js', 'kl-fwd', 'kl-bwd'), got {_sp.temperature!r}."
        )
    dqn_gamma = cfg_dict["dqn"].gamma
    if not (0.0 < dqn_gamma):
        raise ValueError(f"loop.dqn.gamma must be > 0, got {dqn_gamma!r}.")
    if cfg_dict["dqn"].gamma_terminal < 0.0:
        raise ValueError(f"loop.dqn.gamma_terminal must be >= 0, got {cfg_dict['dqn'].gamma_terminal!r}.")
    if cfg_dict["dqn"].gamma_truncated < 0.0:
        raise ValueError(f"loop.dqn.gamma_truncated must be >= 0, got {cfg_dict['dqn'].gamma_truncated!r}.")
    dqn_tau = cfg_dict["dqn"].tau
    if not (0.0 <= dqn_tau <= 1.0):
        raise ValueError(f"loop.dqn.tau must be in [0, 1], got {dqn_tau!r}.")
    dqn_norm_eps = cfg_dict["dqn"].normalize_reward_eps
    if dqn_norm_eps <= 0.0:
        raise ValueError(
            f"loop.dqn.normalize_reward_eps must be > 0, got {dqn_norm_eps!r}."
        )
    dqn_std_target = cfg_dict["dqn"].normalize_reward_std_target
    if dqn_std_target <= 0.0:
        raise ValueError(
            f"loop.dqn.normalize_reward_std_target must be > 0, got {dqn_std_target!r}."
        )
    if cfg_dict["dqn"].cql_weight < 0.0:
        raise ValueError(f"loop.dqn.cql_weight must be >= 0, got {cfg_dict['dqn'].cql_weight!r}.")
    vec_dqn_tau = cfg_dict["vec_dqn"].tau
    if not (0.0 <= vec_dqn_tau <= 1.0):
        raise ValueError(f"loop.vec_dqn.tau must be in [0, 1], got {vec_dqn_tau!r}.")
    vec_dqn_norm_eps = cfg_dict["vec_dqn"].normalize_reward_eps
    if vec_dqn_norm_eps <= 0.0:
        raise ValueError(
            f"loop.vec_dqn.normalize_reward_eps must be > 0, got {vec_dqn_norm_eps!r}."
        )
    vec_dqn_std_target = cfg_dict["vec_dqn"].normalize_reward_std_target
    if vec_dqn_std_target <= 0.0:
        raise ValueError(
            f"loop.vec_dqn.normalize_reward_std_target must be > 0, got {vec_dqn_std_target!r}."
        )
    _vec_dqn_h = cfg_dict["vec_dqn_head_kwargs"]
    if _vec_dqn_h["num_layers"] > 0:
        _vec_dim = _vec_dqn_h["vec_dim"]
        if _vec_dim <= 0 or _vec_dim % 2 != 0:
            raise ValueError(
                f"model.vec_dqn_head.vec_dim must be a positive even integer, got {_vec_dim!r}."
            )
    for _hname in ("sp_head", "dqn_head", "sv_head"):
        _h = cfg_dict[f"{_hname}_kwargs"]
        if _h["scale"] <= 0.0:
            raise ValueError(f"model.{_hname}.scale must be > 0, got {_h['scale']!r}.")
        if _h["num_layers"] < 0:
            raise ValueError(f"model.{_hname}.num_layers must be >= 0 (0 = disabled), got {_h['num_layers']!r}.")

    _mp = cfg_dict["augment_tokens"].mask_prob
    for _name, _p in (
        ("action", _mp.action),
        ("reward", _mp.reward),
        ("done", _mp.done),
        ("obs_continuous", _mp.obs_continuous),
        ("obs_discrete", _mp.obs_discrete),
        ("obs_image", _mp.obs_image),
        ("time", _mp.time),
    ):
        if not (0.0 <= _p <= 1.0):
            raise ValueError(f"augment_tokens.mask_prob.{_name} must be in [0, 1], got {_p!r}.")
    lr_schedule = cfg_dict.get("lr_schedule", "constant")
    if lr_schedule not in ("constant", "cosine"):
        raise ValueError(f"loop.lr_schedule must be 'constant' or 'cosine', got {lr_schedule!r}.")
    if cfg_dict.get("lr_warmup_steps", 0) < 0:
        raise ValueError("loop.lr_warmup_steps must be >= 0.")
    lr_min = cfg_dict.get("lr_min", 0.0)
    if not (0.0 <= lr_min <= cfg_dict.get("lr", 1.0)):
        raise ValueError(f"loop.lr_min must be in [0, lr], got {lr_min!r}.")


    max_grad_norm = cfg_dict.get("max_grad_norm")
    if max_grad_norm is not None and max_grad_norm <= 0:
        raise ValueError(f"loop.max_grad_norm must be > 0, got {max_grad_norm!r}.")
    if cfg_dict.get("checkpoint_interval", 0) < 0:
        raise ValueError("loop.checkpoint_interval must be >= 0 (0 = disabled).")
    if cfg_dict.get("checkpoint_keep", 1) < 1:
        raise ValueError("loop.checkpoint_keep must be >= 1.")
    _emb = cfg_dict["embedding_kwargs"]
    if _emb["fourier_in_min"] <= 0:
        raise ValueError("model.embedding.fourier_in_min must be > 0.")
    if _emb["fourier_in_max"] <= 0:
        raise ValueError("model.embedding.fourier_in_max must be > 0.")
    if _emb["fourier_in_min"] >= _emb["fourier_in_max"]:
        raise ValueError("model.embedding.fourier_in_min must be < model.embedding.fourier_in_max.")
    if cfg_dict.get("eval_interval", 0) > 0 and not cfg_dict.get("eval_datasets"):
        raise ValueError(
            "loop.eval_interval > 0 requires at least one eval dataset: "
            "set load_eval_dataset.name or a non-empty load_eval_datasets list."
        )
    if cfg_dict.get("eval_interval", 0) > 0 and int(cfg_dict.get("eval_batch_size", 0) or 0) <= 0:
        raise ValueError("loop.eval_batch_size must be > 0 when loop.eval_interval > 0.")

    return Config(**cfg_dict), yaml_cfg
