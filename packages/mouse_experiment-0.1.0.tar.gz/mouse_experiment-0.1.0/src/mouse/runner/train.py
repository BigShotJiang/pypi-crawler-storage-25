from __future__ import annotations

import torch
from torch.nn.utils import clip_grad_norm_

from mouse.losses.dqn import DqnLossConfig, dqn_loss
from mouse.losses.sp import SpLossConfig, sp_loss
from mouse.losses.sv import SvLossConfig, sv_loss
from mouse.losses.vec_dqn import VecDqnLossConfig, vec_dqn_loss
from mouse.data.batch import PrefetchBatchifier
from mouse.data.augment import TokenAugmenter
from mouse.data.dataset_store import DatasetStore
from mouse.models.base import Model
from tensordict import TensorDict


class RunnerTrain:
    """Runner for offline training on ground-truth actions."""

    def __init__(
        self,
        store: DatasetStore,
        sequence_length: int,
        batch_size: int,
        sampling: str = "batch",
        prefetch: int = 4,
        num_workers: int = 1,
        token_augmenter: TokenAugmenter | None = None,
        grad_accum_steps: int = 1,
        device: torch.device | None = None,
    ):
        pin_memory = device is not None and device.type == "cuda"
        self._batchifier = PrefetchBatchifier(
            store=store,
            sequence_length=sequence_length,
            batch_size=batch_size,
            sampling=sampling,
            prefetch=prefetch,
            num_workers=num_workers,
            pin_memory=pin_memory,
        )
        self._token_augmenter = token_augmenter
        self._grad_accum_steps = grad_accum_steps
        self._accum_progress = 0
        self._device = device
        # Dedicated CUDA stream for H2D transfers so they run concurrently with
        # compute on the default stream (opt + polyak) rather than after them.
        self._h2d_stream: torch.cuda.Stream | None = (
            torch.cuda.Stream() if device is not None and device.type == "cuda" else None
        )
        # Batch pre-transferred to device during the previous step's GPU compute.
        # None on the first step; thereafter next_batch() returns this instantly.
        self._staged: TensorDict | None = None
        # Pinned CPU source tensor kept alive until the DMA is CPU-side complete.
        self._staged_host: TensorDict | None = None
        # CUDA event recorded on _h2d_stream right after the async DMA is issued.
        # We synchronize on it before releasing _staged_host so that the CPU-side
        # pinned buffer is only freed once the DMA engine has finished reading it.
        # (wait_stream gives GPU-side ordering only; the Python GC runs on the CPU
        # timeline independently, so a CPU-side guarantee is also required.)
        self._h2d_done: torch.cuda.Event | None = None

    @property
    def total_batches(self) -> int:
        return self._batchifier.total_batches

    def next_batch(self) -> TensorDict:
        """Return the current batch (already on device) and immediately stage the next one.

        If a pre-staged batch is available it is returned instantly and the
        side-stream wait ensures the default stream sees the completed transfer
        before the first forward kernel.  On the first call (no staged batch)
        a synchronous blocking transfer is used as fallback.

        Staging the next batch here means H2D runs on the copy engine while the
        caller does forward → backward → opt → polyak on the compute engine.
        """
        if self._staged is not None:
            td = self._staged
            self._staged = None
            if self._h2d_stream is not None:
                torch.cuda.current_stream().wait_stream(self._h2d_stream)
                # CPU-side: block until DMA engine has released the pinned source.
                if self._h2d_done is not None:
                    self._h2d_done.synchronize()
                    self._h2d_done = None
                self._staged_host = None
                # Cross-stream GPU memory safety: the tensors in `td` were allocated
                # on _h2d_stream but will be consumed on the default stream.
                # record_stream() tells the caching allocator not to return their
                # GPU memory to _h2d_stream's pool until the default stream has
                # finished using them (i.e. until after backward + optimizer).
                # Without this the allocator can recycle `td`'s GPU pages for the
                # next H2D copy while backward is still reading them.
                cs = torch.cuda.current_stream()
                td.apply(lambda t: t.record_stream(cs) or t)
        else:
            # Fallback (first step): keep cpu_td alive across the synchronize so
            # the pinned source buffer is not freed before the DMA completes.
            cpu_td = self._batchifier.next_batch()
            if self._device is not None and self._device.type == "cuda":
                td = cpu_td.to(self._device, non_blocking=True)
                torch.cuda.synchronize()
            else:
                td = cpu_td

        # Immediately kick off H2D for the next batch on the side stream.
        if self._h2d_stream is not None:
            next_td = self._batchifier.next_batch()
            event = torch.cuda.Event()
            # Make _h2d_stream wait for all current default-stream work before
            # issuing the DMA.  This prevents the DMA allocator from reusing GPU
            # pages that the ongoing backward/optimizer still hold references to.
            self._h2d_stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(self._h2d_stream):
                self._staged = next_td.to(self._device, non_blocking=True)
                event.record()
            self._staged_host = next_td
            self._h2d_done = event

        return td

    def close(self) -> None:
        if self._h2d_stream is not None and self._staged_host is not None:
            self._h2d_stream.synchronize()
        self._staged = None
        self._staged_host = None
        self._h2d_done = None
        self._batchifier.close()

    def train(
        self,
        model: Model,
        optimizer: torch.optim.Optimizer,
        device: torch.device,
        sp: SpLossConfig,
        sv: SvLossConfig,
        dqn: DqnLossConfig,
        vec_dqn: VecDqnLossConfig,
        max_grad_norm: float | None,
        scheduler: torch.optim.lr_scheduler.LRScheduler | None = None,
    ) -> dict[str, float]:
        """Sample one batch and run one training step; steps the optimizer every grad_accum_steps calls."""
        step_stream = self.next_batch()
        with torch.no_grad():
            if self._token_augmenter is not None:
                self._token_augmenter.update_augmentations(step_stream)
                step_stream = self._token_augmenter(step_stream)

        w_sp = float(sp.weight)
        w_sv = float(sv.weight)
        w_dqn = float(dqn.weight)
        w_vec_dqn = float(vec_dqn.weight)
        if w_sp <= 0.0 and w_dqn <= 0.0 and w_sv <= 0.0 and w_vec_dqn <= 0.0:
            raise ValueError(
                "At least one of sp_weight, dqn_weight, sv_weight, or vec_dqn_weight must be > 0."
            )

        model.train()
        metrics: dict[str, float] = {}
        if self._accum_progress == 0:
            optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=device.type == "cuda"):
            out, _ = model(step_stream)
            total_loss: torch.Tensor = torch.tensor(0.0, device=device, dtype=torch.float32)
            if w_sp > 0.0:
                loss_sp, sp_metrics = sp_loss(
                    step_stream=step_stream,
                    logits=out["sp"],
                    cfg=sp,
                )
                total_loss += w_sp * loss_sp
                metrics.update(sp_metrics)
            if w_dqn > 0.0:
                loss_dqn, dqn_metrics = dqn_loss(
                    step_stream=step_stream,
                    q=out["dqn"],
                    q_target=out["dqn_target"],
                    cfg=dqn,
                )
                total_loss += w_dqn * loss_dqn
                metrics.update(dqn_metrics)
            if w_vec_dqn > 0.0:
                loss_vec_dqn, vec_dqn_metrics = vec_dqn_loss(
                    step_stream=step_stream,
                    online_vecs=out["vec_dqn"],
                    target_vecs=out["vec_dqn_target"],
                    cfg=vec_dqn,
                )
                total_loss += w_vec_dqn * loss_vec_dqn
                metrics.update(vec_dqn_metrics)
            if w_sv > 0.0:
                loss_sv, sv_metrics = sv_loss(
                    step_stream=step_stream,
                    logits=out["sv"],
                    cfg=sv,
                )
                total_loss += w_sv * loss_sv
                metrics.update(sv_metrics)

        (total_loss / self._grad_accum_steps).backward()

        self._accum_progress += 1
        if self._accum_progress >= self._grad_accum_steps:
            self._accum_progress = 0
            if max_grad_norm is not None:
                grad_norm = float(clip_grad_norm_(model.parameters(), max_grad_norm))
                metrics["grad_norm"] = grad_norm
            optimizer.step()
            with torch.no_grad():
                model.polyak_update(dqn_tau=dqn.tau, vec_dqn_tau=vec_dqn.tau)
            if scheduler is not None:
                scheduler.step()
            metrics["lr"] = optimizer.param_groups[0]["lr"]

        return metrics
