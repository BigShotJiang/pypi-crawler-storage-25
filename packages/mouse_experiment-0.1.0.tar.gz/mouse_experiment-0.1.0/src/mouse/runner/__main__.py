import os
import sys
from pathlib import Path


def main() -> None:
    from mouse.runner.experiment import main as run_main

    config_path = ""
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        if not os.path.isabs(arg) and "/" not in arg and "\\" not in arg:
            arg = str(Path.cwd() / "configs" / arg)
        config_path = arg

    run_main(config_path)


if __name__ == "__main__":
    main()
