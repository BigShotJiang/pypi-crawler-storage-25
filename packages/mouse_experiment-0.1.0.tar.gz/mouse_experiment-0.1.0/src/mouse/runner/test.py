from __future__ import annotations

import math
from typing import Any

import numpy as np
import torch
import torch.nn.functional as F

from mouse.envs.envs import EnvConfig, make_vector_env, resolve_q_star_source_for_env
from mouse.data.dataset_store import DatasetStore
from mouse.data.batch import to_tensor_dict
from mouse.models.base import Model
from tensordict import TensorDict


def _update_episode_stats(
    data: dict[str, Any],
    metrics: dict[str, np.ndarray],
    episode_returns: list[float],
    lengths: list[float],
) -> None:
    is_done = np.asarray(data["done"]) > 0
    if np.any(is_done):
        episode_returns.extend(np.asarray(metrics["episode_cum_reward"])[is_done].tolist())
        lengths.extend(np.asarray(metrics["episode_length"])[is_done].tolist())


class _EnvGroup:
    """All state and operations for one batch of parallel environments.

    Holds the vector env, store slice, global env indices (for ``env_idx`` metadata),
    the last step data (for expert policy), and the shared inference config needed by
    ``infer_learned_actions`` and ``get_context``.
    """

    __slots__ = (
        "env_runner", "env_indices", "stores", "last_data",
        "action_dim", "start_length", "max_length", "device", "action_source_temperature",
        "learned_head",
        "episode_step_start",
        "_store_index",
    )

    def __init__(
        self,
        env_runner: Any,
        env_indices: np.ndarray,
        stores: list[DatasetStore],
        action_dim: int,
        start_length: int,
        max_length: int,
        device: torch.device,
        action_source_temperature: float,
        learned_head: str | None,
    ) -> None:
        self.env_runner = env_runner
        self.env_indices: np.ndarray = env_indices
        self.stores: list[DatasetStore] = stores
        self.last_data: dict[str, Any] | None = None
        self.action_dim = action_dim
        self.start_length = start_length
        self.max_length = max_length
        self.device = device
        self.action_source_temperature = float(action_source_temperature)
        self.learned_head = learned_head
        self.episode_step_start = np.zeros(len(stores), dtype=np.int64)
        self._store_index = {s: i for i, s in enumerate(self.stores)}

    def clear_history(self) -> None:
        """Start model context at the current stream length (steps from this ``run()`` only)."""
        for local_idx, st in enumerate(self.stores):
            self.episode_step_start[local_idx] = len(st)

    def save_experience(self, experience: dict[str, Any]) -> None:
        group_size = len(self.stores)

        def _select(v: Any, local_idx: int) -> Any:
            if isinstance(v, np.ndarray):
                return v[local_idx] if v.ndim >= 1 and v.shape[0] == group_size else v
            if isinstance(v, (list, tuple)):
                return v[local_idx] if len(v) == group_size else v
            return v

        for local_idx, (global_env_idx, store) in enumerate(
            zip(self.env_indices.tolist(), self.stores)
        ):
            data = {k: _select(v, local_idx) for k, v in experience.items()}
            data["env_idx"] = int(global_env_idx)
            store.append(data)

    def get_context(
        self,
        stores: list[DatasetStore],
        from_step: int | None = None,
    ) -> TensorDict:
        """Return batched step streams for the given stores.

        *stores* must be drawn from this group's ``self.stores`` (same ``DatasetStore``
        instances) so per-env ``episode_step_start`` (step offset) can be resolved.

        If *from_step* is None (prefill): up to ``start_length`` most-recent steps
        (may be shorter when history is short). If *from_step* is set: steps from
        that index to end (incremental). No PAD prefix: sequence length is the slice
        length.

        All stores must yield the same slice length so batching does not require padding.
        """
        per_env_streams: list[TensorDict] = []
        for store in stores:
            j = self._store_index[store]
            end_idx = len(store)
            ep_start = int(self.episode_step_start[j])
            if from_step is None:
                start_idx = max(ep_start, end_idx - self.start_length)
            else:
                start_idx = max(int(from_step), ep_start)
            if start_idx >= end_idx:
                raise ValueError(f"Empty context: start={start_idx} end={end_idx}")
            step_raw = store[np.arange(start_idx, end_idx)]
            per_env_streams.append(to_tensor_dict(step_raw))

        lengths = [int(td.batch_size[0]) for td in per_env_streams]
        if len(set(lengths)) != 1:
            raise ValueError(
                "Test runner requires equal context length for all envs in a batch, "
                f"got lengths {lengths}. Parallel envs must have the same number of steps in context."
            )
        return TensorDict.maybe_dense_stack(per_env_streams, dim=0).to(device=self.device)


    def infer_learned_actions(
        self,
        model: Model,
        cache: Any,
        cache_start: int,
        cache_end: int,
        global_read_cursor: int,
    ) -> tuple[np.ndarray, Any, int, int, int | None, int]:
        """Infer actions for this group, threading cache state across steps within a run.

        The cache is owned and passed in by ``RunnerTest.run()``; it is never stored on
        ``self`` and is discarded when ``run()`` returns. Envs with no steps yet in the
        current context window (including immediately after ``clear_history`` at ``run()``
        start) get random actions.

        *cache_start* and *cache_end* are **run-relative** coordinates (length of the logical
        stream since ``episode_step_start``), so they stay small after ``clear_history`` even
        when the underlying ``DatasetStore`` still holds older steps. *global_read_cursor* is
        the exclusive end index into each store for incremental ``get_context(from_step=...)``
        and must stay absolute.

        Returns ``(actions, cache, cache_start, cache_end, context_len, global_read_cursor)`` where
        *context_len* is the effective step context: prefill uses the step tensor length only;
        incremental decode (only possible when ``max_length > 0``) uses
        ``(cache_end - cache_start) + stream_len`` before *cache_end* is advanced. ``None`` when
        no forward ran.
        """
        group_size = len(self.stores)
        valid_mask = np.array(
            [
                len(s) > int(self.episode_step_start[i])
                for i, s in enumerate(self.stores)
            ],
            dtype=np.bool_,
        )
        next_actions = np.random.randint(0, self.action_dim, size=(group_size,), dtype=np.int64)
        if not np.any(valid_mask):
            return next_actions, cache, cache_start, cache_end, None, global_read_cursor

        valid_indices = np.flatnonzero(valid_mask).astype(np.int64, copy=False)
        valid_stores = [self.stores[int(i)] for i in valid_indices]
        buffer_length = len(valid_stores[0])
        rel_ep = int(self.episode_step_start[valid_indices[0]])
        effective_len = buffer_length - rel_ep

        use_cache = self.max_length > 0
        need_prefill = (
            not use_cache or cache is None or (cache_end - cache_start) >= self.max_length
        )

        autocast = torch.autocast(
            device_type=self.device.type,
            dtype=torch.bfloat16,
            enabled=self.device.type == "cuda",
        )
        if need_prefill:
            streams = self.get_context(valid_stores, from_step=None)
            stream_len = int(streams.batch_size[-1])  # number of steps in the context window
            context_len = stream_len
            with autocast:
                out, cache = model(streams, cache=None, use_cache=use_cache)
            if use_cache:
                cache_start = max(0, effective_len - self.start_length)
                cache_end = effective_len
                global_read_cursor = buffer_length
        else:
            streams = self.get_context(valid_stores, from_step=global_read_cursor)
            stream_len = int(streams.batch_size[-1])
            # need_prefill is False ⇒ use_cache (else we'd always prefill); add cached prefix + new steps.
            context_len = (cache_end - cache_start) + stream_len
            with autocast:
                out, cache = model(streams, cache=cache, use_cache=True)
            cache_end = buffer_length - rel_ep
            global_read_cursor = buffer_length

        next_actions[valid_mask] = model.get_action(
            out=out,
            head=self.learned_head,
            temperature=float(self.action_source_temperature),
            num_actions=self.action_dim,
        ).cpu().numpy()
        return next_actions, cache, cache_start, cache_end, context_len, global_read_cursor


class RunnerTest:
    """Persistent test rollout runner that continues env state across intervals.

    Envs are split into groups of size ``test_batch_size``. Each call to ``run``
    advances ``next_batch_index`` to the next group (cycling round-robin), runs
    ``num_steps`` steps for that group, and infers actions with the model.
    """

    def __init__(
        self,
        test_env: EnvConfig,
        env_name: str,
        sequence_length: int,
        start_length: int,
        max_length: int,
        device: torch.device,
        stores: list[DatasetStore],
        test_batch_size: int = 0,
    ):
        if test_env.num_steps is None or test_env.num_steps <= 0:
            raise ValueError("test_env.num_steps must be > 0.")
        if sequence_length <= 0:
            raise ValueError("sequence_length must be > 0.")
        if max_length < 0:
            raise ValueError("max_length must be >= 0.")

        self.env_name = env_name
        self.env_cfg = test_env
        self.num_steps = test_env.num_steps
        self.sequence_length = sequence_length
        self.device = device
        self.num_envs = int(test_env.num_envs)
        if test_batch_size < 0:
            raise ValueError("test_batch_size must be >= 0.")
        self.test_batch_size = (
            self.num_envs
            if test_batch_size <= 0
            else min(int(test_batch_size), self.num_envs)
        )
        if len(stores) != self.num_envs:
            raise ValueError(
                f"Expected one store per env ({self.num_envs}), got {len(stores)}."
            )
        self.stores = stores  # flat list kept for experiment.py dataset saving

        from mouse.utils import ProbSchedule
        self._loop_prob_schedule = ProbSchedule(test_env.action_source_loop_prob_schedule)
        self._episode_prob_schedule = ProbSchedule(test_env.action_source_episode_prob_schedule)
        self.action_source_prob = 1.0
        self.action_source_temperature = float(test_env.action_source_temperature)
        if self.action_source_temperature < 0.0:
            raise ValueError(
                "action_source.temperature must be >= 0 "
                f"(got {self.action_source_temperature})."
            )

        resolved_start_length = start_length if start_length > 0 else sequence_length
        all_env_indices = np.arange(self.num_envs, dtype=np.int64)
        num_groups = max(1, math.ceil(self.num_envs / self.test_batch_size))
        self.groups: list[_EnvGroup] = []
        offset = 0
        for group_idx, group_env_indices in enumerate(
            grp for grp in np.array_split(all_env_indices, num_groups) if len(grp) > 0
        ):
            group_env_indices = group_env_indices.astype(np.int64, copy=False)
            group_size = len(group_env_indices)
            env_runner = make_vector_env(
                env_id=test_env.env_id,
                seed=int(test_env.seed) + group_idx,
                num_envs=group_size,
                max_steps_per_episode=test_env.max_episode_steps,
                env_kwargs=test_env.kwargs,
                render=test_env.render,
                env_name=env_name,
                non_stationary_params=test_env.non_stationary_params,
                env_type=test_env.env_type,
                atari_preprocessing=test_env.atari_preprocessing or False,
                atari_preprocessing_kwargs=test_env.atari_preprocessing_kwargs,
                observation_indices=test_env.observation_indices,
                reward_scale=test_env.reward_scale,
                reward_shift=test_env.reward_shift,
                q_star_source=test_env.q_star_source,
            )
            self.groups.append(_EnvGroup(
                env_runner=env_runner,
                env_indices=group_env_indices,
                stores=stores[offset:offset + group_size],
                action_dim=env_runner.action_dim,
                start_length=resolved_start_length,
                max_length=max_length,
                device=device,
                action_source_temperature=self.action_source_temperature,
                learned_head={"learned_sp": "sp", "learned_dqn": "dqn", "learned_sv": "sv", "learned_vec_dqn": "vec_dqn"}.get(test_env.action_source),
            ))
            offset += group_size

        action_dims = [g.env_runner.action_dim for g in self.groups]
        if len(set(action_dims)) != 1:
            raise ValueError(
                f"All env groups must have the same action_dim, got {action_dims}."
            )

        self.next_batch_index: int = 0
        self.action_source = self._resolve_action_source(test_env.action_source)
        self.clear_history = bool(test_env.clear_history)
        self._uses_episode_policy_prob = bool(self._episode_prob_schedule)
        self._max_ep_len_episode = (
            self._episode_prob_schedule.horizon(test_env.max_episode_steps)
            if self._uses_episode_policy_prob
            else 1
        )
        if self.action_source == "q_star":
            if resolve_q_star_source_for_env(test_env.env_id, test_env.q_star_source) is None:
                raise ValueError(
                    f"test_env {env_name!r}: action_source='q_star' requires q_star_source in YAML "
                    f"or a built-in default for env id {test_env.env_id!r} "
                    "(labels come from the vector env as metadata_q_star)."
                )

    def _sample_actions_from_q_star(self, q_values: Any) -> np.ndarray:
        """Sample expert actions from q-values with finite-value masking and temperature."""
        q_arr = np.asarray(q_values, dtype=np.float64)
        if q_arr.ndim == 1:
            q_arr = q_arr.reshape(1, -1)
        if q_arr.ndim != 2:
            raise ValueError(
                f"Expected metadata_q_star with shape [N, A], got {q_arr.shape} "
                f"(q_star_source metadata_q_star / env_q_star)."
            )
        temperature = float(self.action_source_temperature)
        sampled = np.empty((q_arr.shape[0],), dtype=np.int64)
        for i in range(q_arr.shape[0]):
            q_row = q_arr[i]
            finite_idx = np.flatnonzero(np.isfinite(q_row))
            if finite_idx.size == 0:
                raise ValueError(
                    f"metadata_q_star row {i} has no finite q-values for expert sampling "
                    f"(q_star_source metadata_q_star / env_q_star)."
                )
            if finite_idx.size == 1:
                sampled[i] = int(finite_idx[0])
                continue
            finite_q = q_row[finite_idx]
            if temperature == 0.0:
                sampled[i] = int(finite_idx[int(np.argmax(finite_q))])
                continue
            logits = finite_q / temperature
            logits = logits - float(np.max(logits))
            probs = np.exp(logits)
            probs_sum = float(np.sum(probs))
            if not np.isfinite(probs_sum) or probs_sum <= 0.0:
                sampled[i] = int(finite_idx[int(np.argmax(finite_q))])
                continue
            probs = probs / probs_sum
            sampled[i] = int(np.random.choice(finite_idx, p=probs))
        return sampled

    def _expert_actions_from_last_transition(self, group: _EnvGroup) -> np.ndarray:
        """Expert actions using labels supplied by the env on ``last_data`` only."""
        data = group.last_data
        if data is None:
            raise ValueError(
                "action_source='q_star' needs a prior vector-env transition (after reset or a "
                "previous step in this runner)."
            )
        q_star = data.get("metadata_q_star")
        if q_star is None:
            raise ValueError(
                "action_source='q_star' requires metadata_q_star on the prior transition "
                "(vector env supplies expert targets only as q_star, including one-hot from discrete experts)."
            )
        return self._sample_actions_from_q_star(q_star)

    def _resolve_action_source(self, action_source: str) -> str:
        source = str(action_source).strip().lower()
        _allowed = frozenset({"random", "q_star", "learned_sp", "learned_dqn", "learned_sv", "learned_vec_dqn"})
        if source not in _allowed:
            raise ValueError(
                f"test_env.action_source must be one of random, q_star, learned_sp, learned_dqn, "
                f"learned_sv, learned_vec_dqn; got {source!r}."
            )
        return "learned" if source in {"learned_sp", "learned_dqn", "learned_sv", "learned_vec_dqn"} else source

    def _resolve_action_source_prob(self, action_source_prob: float | None) -> float:
        resolved = self.action_source_prob if action_source_prob is None else float(action_source_prob)
        if not (0 <= resolved <= 1):
            raise ValueError(f"action_source_prob must be in [0, 1], got {resolved}.")
        return resolved

    def _episode_time_indices(self, group: _EnvGroup) -> np.ndarray:
        n = len(group.stores)
        if group.last_data is None:
            return np.zeros(n, dtype=np.int64)
        return np.asarray(group.last_data["episode_step"], dtype=np.int64)

    def _episode_p_ep(self, ep_idx: np.ndarray) -> np.ndarray:
        h = int(self._max_ep_len_episode)
        t = np.clip(np.asarray(ep_idx, dtype=np.int64), 0, max(0, h - 1))
        out = np.empty(t.shape, dtype=np.float64)
        o_flat = out.ravel()
        for i, v in enumerate(t.ravel()):
            o_flat[i] = self._episode_prob_schedule(int(v), h)
        return out

    def run(
        self,
        model: Model | None = None,
        action_source_prob: float | None = None,
    ) -> dict[str, float | None]:
        """Run num_steps steps for the next env group, then advance next_batch_index.

        Groups cycle in round-robin order via ``next_batch_index``, analogous to how
        ``Batchifier.next_batch`` advances through data batches — except the batch
        dimension here is envs, not data windows.

        If *model* is None, actions are sampled uniformly at random.
        Otherwise, each step uses policy-source actions with probability ``action_source_prob``
        (runtime override), or the scheduled prob from ``action_source.start_prob`` / optional ``mid_prob``
        (+ optional ``mid_step``) / ``end_prob`` when override is ``None``. When
        ``action_source.episode_*`` is configured, the per-step probability is
        ``P_loop * P_episode(t)`` where ``P_loop`` is the value above and ``P_episode`` is
        from ``episode_start_prob`` / ``episode_prob_schedule`` / etc. with ``t`` the
        env's ``episode_step`` on the last transition; this can differ per env in a batch.
        When max_length > 0, uses backbone cache: prefill up to start_length steps on the
        first step, then decode incrementally until the cache fills to max_length steps, then
        re-prefill. The cache lives only for the duration of this call.
        If ``clear_history`` is set on the test env, the learned-policy context window
        is reset at the start of this call (not on episode boundaries). Steps still
        **accumulate within** this ``run()`` loop, so the effective context per forward
        generally **grows** until it hits the prefill width (``test_cache_start_length``)
        and/or the KV cache window; re-prefill when the cache fills can make per-step
        ``context_len`` dip. ``clear_history`` does **not** keep ``avg_context_length`` flat.

        Returns:
            Dict with avg_episode_reward, avg_episode_length, avg_context_length,
            min_context_length, max_context_length.
            Episode metrics (avg_episode_reward, avg_episode_length) are None if no completed
            episodes in the window. avg_context_length is the mean effective step context per
            learned-policy forward (including steps carried in backbone cache on incremental
            steps), or None if there were none. Episode stats come from the vector env ``step``
            metrics (``episode_cum_reward``, ``episode_length`` at terminal steps; scaled
            raw return).
        """
        if model is not None:
            model.eval()
        group = self.groups[self.next_batch_index]
        self.next_batch_index = (self.next_batch_index + 1) % len(self.groups)

        if self.clear_history:
            group.clear_history()

        with torch.no_grad():
            lengths: list[float] = []
            episode_returns: list[float] = []
            context_lengths: list[int] = []
            cache: Any = None
            cache_start = 0
            cache_end = 0
            global_read_cursor = 0

            effective_action_source_prob = self._resolve_action_source_prob(action_source_prob)
            for _ in range(self.num_steps):
                p_loop = float(effective_action_source_prob)
                use_per_env = (
                    self._uses_episode_policy_prob
                    and not group.env_runner.init
                    and self.action_source != "random"
                )
                if use_per_env:
                    ep_t = self._episode_time_indices(group)
                    p = np.clip(p_loop * self._episode_p_ep(ep_t), 0.0, 1.0)
                    take_policy = np.random.random(len(group.stores)) < p
                    if not np.any(take_policy):
                        next_actions = None
                    elif self.action_source == "q_star":
                        ex = self._expert_actions_from_last_transition(group)
                        if np.all(take_policy):
                            next_actions = ex
                        else:
                            ra = group.env_runner.sample_random_actions()
                            next_actions = np.where(take_policy, ex, ra)
                    elif self.action_source == "learned":
                        assert model is not None, "Learned policy source requires model"
                        learned, cache, cache_start, cache_end, ctx_len, global_read_cursor = (
                            group.infer_learned_actions(
                                model=model,
                                cache=cache,
                                cache_start=cache_start,
                                cache_end=cache_end,
                                global_read_cursor=global_read_cursor,
                            )
                        )
                        if ctx_len is not None:
                            context_lengths.append(ctx_len)
                        if np.all(take_policy):
                            next_actions = learned
                        else:
                            ra = group.env_runner.sample_random_actions()
                            next_actions = np.where(take_policy, learned, ra)
                    else:
                        raise ValueError(f"Invalid policy source: {self.action_source}")
                elif group.env_runner.init or (
                    p_loop < 1.0
                    and np.random.random() >= p_loop
                ):
                    next_actions = None  # random action from env_runner
                elif self.action_source == "q_star":
                    next_actions = self._expert_actions_from_last_transition(group)
                elif self.action_source == "learned":
                    assert model is not None, "Learned policy source requires model"
                    next_actions, cache, cache_start, cache_end, ctx_len, global_read_cursor = (
                        group.infer_learned_actions(
                            model=model,
                            cache=cache,
                            cache_start=cache_start,
                            cache_end=cache_end,
                            global_read_cursor=global_read_cursor,
                        )
                    )
                    if ctx_len is not None:
                        context_lengths.append(ctx_len)
                elif self.action_source == "random":
                    next_actions = None
                else:
                    raise ValueError(f"Invalid policy source: {self.action_source}")

                data, metrics = group.env_runner.step(next_actions)
                _update_episode_stats(data=data, metrics=metrics, episode_returns=episode_returns, lengths=lengths)
                group.last_data = data
                group.save_experience(data)

        avg_episode_reward = sum(episode_returns) / len(episode_returns) if episode_returns else None
        avg_episode_length = sum(lengths) / len(lengths) if lengths else None
        avg_context_length = (
            float(sum(context_lengths) / len(context_lengths)) if context_lengths else None
        )
        min_context_length = (
            float(min(context_lengths)) if context_lengths else None
        )
        max_context_length = (
            float(max(context_lengths)) if context_lengths else None
        )
        return {
            "avg_episode_reward": avg_episode_reward,
            "avg_episode_length": avg_episode_length,
            "avg_context_length": avg_context_length,
            "min_context_length": min_context_length,
            "max_context_length": max_context_length,
            "action_source_prob": effective_action_source_prob,
        }
