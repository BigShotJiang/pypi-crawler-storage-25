"""Main entry point: train (optional), eval (optional), test rollouts, save."""
import dataclasses
import gc
import math
import random
import sys
from pathlib import Path
from typing import Any

import numpy as np
import torch
import torch.optim as optim
from tqdm import tqdm
from datasets import Dataset, load_dataset
from huggingface_hub import HfApi
from omegaconf import OmegaConf

from mouse.runner.config import Config, load_config
from mouse.runner.hub import save_test_rollout_dataset_to_hub
from mouse.runner.eval import RunnerEval
from mouse.runner.test import RunnerTest
from mouse.runner.train import RunnerTrain
from mouse.runner.auth import mirror_hf_token_env, setup_huggingface, setup_trackio, setup_wandb
from mouse.envs.envs import EnvConfig
from mouse.data.augment import TokenAugmenter
from mouse.data.dataset_store import DatasetStore
from mouse.models.backbone import _disable_cudnn_sdp_attention_backend
from mouse.models.base import Model
from mouse.models.llama import ModelLlama
from mouse.models.none import ModelNone
from mouse.models.qwen3 import ModelQwen3

def _empty_cache(device: torch.device) -> None:
    if device.type == "cuda":
        gc.collect()
        torch.cuda.empty_cache()
    else:
        gc.collect()


def _test_rollout_context_length(cfg: Config) -> int:
    """KV / history window for online test rollouts (independent of ``cfg.sequence_length``)."""
    if cfg.test_cache_start_length > 0:
        return cfg.test_cache_start_length
    return 512


def _make_token_augmenter(cfg: Config, device: torch.device) -> TokenAugmenter:
    """New augmenter from config (training batches only; eval does not augment)."""
    return TokenAugmenter(augment=cfg.augment_tokens, max_num_actions=cfg.max_num_actions, max_num_obs_discrete=cfg.max_num_obs_discrete, device=device)


_SORT_COLS = ("env_name", "env_idx", "global_step")


def _require_sort_cols(ds, dataset_name: str) -> None:
    missing = [c for c in _SORT_COLS if c not in ds.column_names]
    if missing:
        raise ValueError(
            f"Dataset {dataset_name!r} is missing columns required for historical ordering: "
            f"{missing}. Expected columns: {list(_SORT_COLS)}."
        )


def _apply_dataset_fraction(
    ds: Dataset,
    fraction: float | None,
    dataset_name: str,
    split: str,
) -> Dataset:
    """Keep the first ``ceil(fraction * n)`` rows after canonical sort (reproducible prefix)."""
    if fraction is None or fraction >= 1.0:
        return ds
    n = len(ds)
    if n == 0:
        return ds
    k = max(1, min(n, math.ceil(n * fraction)))
    if k >= n:
        return ds
    out = ds.select(range(k))
    print(f"  fraction {fraction:g}: using {k}/{n} rows from {dataset_name} ({split})")
    return out


def _exclude_envs(ds, dataset_name: str, split: str, exclude_envs: list[str]):
    """Exclude rows whose env_name is listed in exclude_envs."""
    if not exclude_envs:
        return ds
    exclude_set = set(exclude_envs)
    kept = ds.filter(
        lambda batch: [str(v) not in exclude_set for v in batch["env_name"]],
        batched=True,
        desc=None,
    )
    removed = len(ds) - len(kept)
    print(f"  excluded {removed} rows from {dataset_name} ({split})  env_name in {sorted(exclude_set)}")
    return kept


def _load_dataset(name: str, split: str, cache_dir: str | None = None):
    """Load dataset; always ``force_redownload`` (no reuse of HF prepared cache).

    Hugging Face repos whose README lists splits with no matching files (e.g. ``eval``
    glob with no shards) make ``load_dataset(repo_id, ...)`` fail during format
    inference. For remote ``org/repo`` ids we load only the requested split's parquet
    shards under ``data/{split}-*`` via the parquet builder.

    Default datasets verification (``BASIC_CHECKS``) is kept so prepare-time checks still run.
    """
    download_kw: dict[str, Any] = {"download_mode": "force_redownload"}
    if cache_dir is not None:
        download_kw["cache_dir"] = cache_dir

    local = Path(name).expanduser()
    if local.exists():
        return load_dataset(str(local), split=split, **download_kw)

    # Remote HF dataset id (not a local path): parquet shards only.
    # hf:// URLs require the full owner/repo format; unscoped names (e.g. "play_ns_cartpole")
    # are resolved to the logged-in user's namespace.
    hf_name = name
    if "/" not in name:
        hf_name = f"{HfApi().whoami()['name']}/{name}"
    return load_dataset(
        "parquet",
        data_files={split: f"hf://datasets/{hf_name}/data/{split}-*"},
        split=split,
        **download_kw,
    )


def _set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def _get_device() -> torch.device:
    if torch.cuda.is_available():
        _disable_cudnn_sdp_attention_backend()
        print(f"  device:  cuda  ({torch.cuda.get_device_name(0)})")
        return torch.device("cuda")
    print("  device:  cpu  ⚠️  CUDA not available")
    return torch.device("cpu")


def _setup_train_runner(
    cfg: Config,
    token_augmenter: TokenAugmenter,
    run_dir: Path,
    device: torch.device,
) -> RunnerTrain | None:
    """Load train dataset and create RunnerTrain. None when train_interval=0."""
    if cfg.train_interval <= 0:
        return None

    assert cfg.train_dataset_name is not None
    print(f"  📥 train dataset: {cfg.train_dataset_name}  split={cfg.train_dataset_split!r}")
    store = DatasetStore(
        max_action_dim=cfg.max_num_actions,
        max_obs_continuous_dim=cfg.max_num_obs_continuous,
        max_obs_discrete_dim=cfg.max_num_obs_discrete,
        max_obs_image_pixels=cfg.max_num_obs_image,
    )
    ds = _load_dataset(name=cfg.train_dataset_name, split=cfg.train_dataset_split, cache_dir=str(run_dir / "datasets"))
    _require_sort_cols(ds=ds, dataset_name=cfg.train_dataset_name)
    ds = _exclude_envs(
        ds=ds,
        dataset_name=cfg.train_dataset_name,
        split=cfg.train_dataset_split,
        exclude_envs=cfg.train_dataset_exclude_envs,
    )
    ds = ds.sort(list(_SORT_COLS))
    ds = _apply_dataset_fraction(
        ds=ds,
        fraction=cfg.train_dataset_fraction,
        dataset_name=cfg.train_dataset_name,
        split=cfg.train_dataset_split,
    )
    store.from_dataset(ds)
    runner = RunnerTrain(
        store=store,
        sequence_length=cfg.sequence_length,
        batch_size=cfg.train_batch_size,
        sampling=cfg.train_sampling,
        token_augmenter=token_augmenter,
        num_workers=cfg.train_num_workers,
        prefetch=cfg.train_prefetch,
        grad_accum_steps=cfg.grad_accum_steps,
        device=device,
    )
    print(
        f"  ✓ train ready: {len(store)} steps"
        f"   batch={cfg.train_batch_size}   seq_len={cfg.sequence_length}"
    )
    return runner


def _setup_eval_runners(
    cfg: Config,
    run_dir: Path,
    device: torch.device | None = None,
) -> list[tuple[str, RunnerEval]]:
    """Load each eval dataset into its own ``RunnerEval``. Empty when eval_interval=0.

    Metrics are logged under ``eval/{tag}/``.
    """
    if cfg.eval_interval <= 0:
        return []
    if not cfg.eval_datasets:
        raise ValueError("load_eval_dataset.name or load_eval_datasets is required when eval_interval > 0.")
    out: list[tuple[str, RunnerEval]] = []
    for spec in cfg.eval_datasets:
        print(f"  📥 eval  dataset [{spec.tag}]: {spec.name}  split={spec.split!r}")
        store = DatasetStore(
            max_action_dim=cfg.max_num_actions,
            max_obs_continuous_dim=cfg.max_num_obs_continuous,
            max_obs_discrete_dim=cfg.max_num_obs_discrete,
            max_obs_image_pixels=cfg.max_num_obs_image,
        )
        ds = _load_dataset(name=spec.name, split=spec.split, cache_dir=str(run_dir / "datasets"))
        _require_sort_cols(ds=ds, dataset_name=spec.name)
        ds = _exclude_envs(
            ds=ds,
            dataset_name=spec.name,
            split=spec.split,
            exclude_envs=spec.exclude_envs,
        )
        ds = ds.sort(list(_SORT_COLS))
        ds = _apply_dataset_fraction(
            ds=ds,
            fraction=spec.fraction,
            dataset_name=spec.name,
            split=spec.split,
        )
        store.from_dataset(ds)
        runner = RunnerEval(
            store=store,
            sequence_length=cfg.sequence_length,
            batch_size=cfg.eval_batch_size,
            sampling=cfg.eval_sampling,
            num_workers=cfg.eval_num_workers,
            prefetch=cfg.eval_prefetch,
            device=device,
        )
        print(
            f"  ✓ eval  ready  [{spec.tag}]: {len(store)} steps"
            f"   batch={cfg.eval_batch_size}   seq_len={cfg.sequence_length}"
        )
        out.append((spec.tag, runner))
    return out


def _setup_test_runners(
    cfg: Config,
    device: torch.device,
    run_dir: Path,
) -> list[RunnerTest]:
    """Create one RunnerTest per test_env. Empty list when test_interval=0 or no test_envs."""
    if cfg.test_interval <= 0 or not cfg.test_envs:
        return []

    runners: list[RunnerTest] = []
    for env_key, env_cfg in cfg.test_envs.items():
        stores = [
            DatasetStore(
                max_action_dim=cfg.max_num_actions,
                max_obs_continuous_dim=cfg.max_num_obs_continuous,
                max_obs_discrete_dim=cfg.max_num_obs_discrete,
                max_obs_image_pixels=cfg.max_num_obs_image,
            )
            for env_idx in range(int(env_cfg.num_envs))
        ]
        runner = RunnerTest(
            test_env=env_cfg,
            env_name=env_key,
            sequence_length=_test_rollout_context_length(cfg),
            start_length=cfg.test_cache_start_length,
            max_length=cfg.test_cache_max_length,
            device=device,
            stores=stores,
            test_batch_size=cfg.test_batch_size,
        )
        runners.append(runner)

    env_names = ", ".join(cfg.test_envs.keys())
    step_counts = [ec.num_steps for ec in cfg.test_envs.values()]
    print(
        f"  🧪 test rollouts every {cfg.test_interval} steps"
        f"   envs: {env_names}   episode_steps: {step_counts}"
    )
    return runners


def _llama_kwargs(cfg: Config, resolved_yaml: Any | None = None) -> dict:
    """Kwargs for ModelLlama from config."""
    backbone: dict = dict(
        num_layers=cfg.llama_num_layers,
        num_heads=cfg.llama_num_heads,
        num_key_value_heads=cfg.llama_num_key_value_heads,
        max_position_embeddings=cfg.llama_max_position_embeddings,
        expand=cfg.llama_expand,
        rope_parameters=dict(cfg.llama_rope_scaling),
        rms_norm_eps=cfg.llama_rms_norm_eps,
        attention_bias=cfg.llama_attention_bias,
    )
    kwargs = dict(
        hidden_dim=cfg.llama_hidden_dim,
        backbone_kwargs=backbone,
        embedding_kwargs=cfg.embedding_kwargs,
        sp_head_kwargs=cfg.sp_head_kwargs,
        dqn_head_kwargs=cfg.dqn_head_kwargs,
        sv_head_kwargs=cfg.sv_head_kwargs,
        vec_dqn_head_kwargs=cfg.vec_dqn_head_kwargs,
    )
    source = cfg.load_backbone_name
    if source is None or resolved_yaml is None:
        return kwargs

    from transformers import AutoConfig

    pretrained_cfg = AutoConfig.from_pretrained(source)
    model_type = str(getattr(pretrained_cfg, "model_type", "")).lower().strip()
    if model_type != "llama":
        raise ValueError(
            f"Expected Llama pretrained config for {source!r}, got model_type={model_type!r}."
        )
    raw_yaml = resolved_yaml
    hidden = int(getattr(pretrained_cfg, "hidden_size"))
    inter = int(getattr(pretrained_cfg, "intermediate_size"))
    if inter % hidden != 0:
        raise ValueError(
            f"Unsupported llama intermediate_size={inter} for hidden_size={hidden}: must be divisible to infer expand."
        )
    rope = getattr(pretrained_cfg, "rope_scaling", None)

    def has(path: str) -> bool:
        return OmegaConf.select(raw_yaml, path, default=None) is not None

    if not has("model.backbone.hidden_dim"):
        kwargs["hidden_dim"] = hidden
    if not has("model.backbone.num_heads"):
        backbone["num_heads"] = int(getattr(pretrained_cfg, "num_attention_heads"))
    if not has("model.backbone.num_key_value_heads"):
        backbone["num_key_value_heads"] = int(getattr(pretrained_cfg, "num_key_value_heads"))
    if not has("model.backbone.max_position_embeddings"):
        backbone["max_position_embeddings"] = int(getattr(pretrained_cfg, "max_position_embeddings"))
    if not has("model.backbone.expand"):
        backbone["expand"] = int(inter // hidden)
    if rope is not None and not has("model.backbone.rope_scaling"):
        backbone["rope_parameters"] = dict(rope)
    if not has("model.backbone.rms_norm_eps"):
        backbone["rms_norm_eps"] = float(getattr(pretrained_cfg, "rms_norm_eps"))
    if not has("model.backbone.attention_bias"):
        backbone["attention_bias"] = bool(getattr(pretrained_cfg, "attention_bias"))
    return kwargs


def _qwen3_kwargs(cfg: Config, resolved_yaml: Any | None = None) -> dict:
    """Kwargs for ModelQwen3 from config."""
    backbone: dict = dict(
        num_layers=cfg.qwen3_num_layers,
        num_heads=cfg.qwen3_num_heads,
        num_key_value_heads=cfg.qwen3_num_key_value_heads,
        head_dim=cfg.qwen3_head_dim,
        max_position_embeddings=cfg.qwen3_max_position_embeddings,
        expand=cfg.qwen3_expand,
        rope_parameters=dict(cfg.qwen3_rope_parameters),
        rms_norm_eps=cfg.qwen3_rms_norm_eps,
        attention_bias=cfg.qwen3_attention_bias,
    )
    kwargs = dict(
        hidden_dim=cfg.qwen3_hidden_dim,
        backbone_kwargs=backbone,
        embedding_kwargs=cfg.embedding_kwargs,
        sp_head_kwargs=cfg.sp_head_kwargs,
        dqn_head_kwargs=cfg.dqn_head_kwargs,
        sv_head_kwargs=cfg.sv_head_kwargs,
        vec_dqn_head_kwargs=cfg.vec_dqn_head_kwargs,
    )
    source = cfg.load_backbone_name
    if source is None or resolved_yaml is None:
        return kwargs

    from transformers import AutoConfig

    pretrained_cfg = AutoConfig.from_pretrained(source)
    model_type = str(getattr(pretrained_cfg, "model_type", "")).lower().strip()
    if model_type != "qwen3":
        raise ValueError(
            f"Expected Qwen3 pretrained config for {source!r}, got model_type={model_type!r}."
        )
    raw_yaml = resolved_yaml
    rope = getattr(pretrained_cfg, "rope_parameters", None) or getattr(pretrained_cfg, "rope_scaling", None)
    hidden = int(getattr(pretrained_cfg, "hidden_size"))
    inter = int(getattr(pretrained_cfg, "intermediate_size"))
    if inter % hidden != 0:
        raise ValueError(
            f"Unsupported qwen3 intermediate_size={inter} for hidden_size={hidden}: must be divisible to infer expand."
        )

    def has(path: str) -> bool:
        return OmegaConf.select(raw_yaml, path, default=None) is not None

    if not has("model.backbone.hidden_dim"):
        kwargs["hidden_dim"] = hidden
    # Keep resolved config layer counts authoritative; do not silently expand depth from pretrained defaults.
    if not has("model.backbone.num_heads"):
        backbone["num_heads"] = int(getattr(pretrained_cfg, "num_attention_heads"))
    if not has("model.backbone.num_key_value_heads"):
        backbone["num_key_value_heads"] = int(getattr(pretrained_cfg, "num_key_value_heads"))
    if not has("model.backbone.head_dim"):
        backbone["head_dim"] = int(getattr(pretrained_cfg, "head_dim"))
    if not has("model.backbone.max_position_embeddings"):
        backbone["max_position_embeddings"] = int(getattr(pretrained_cfg, "max_position_embeddings"))
    if not has("model.backbone.expand"):
        backbone["expand"] = int(inter // hidden)
    if rope is not None and not has("model.backbone.rope_parameters"):
        backbone["rope_parameters"] = dict(rope)
    if not has("model.backbone.rms_norm_eps"):
        backbone["rms_norm_eps"] = float(getattr(pretrained_cfg, "rms_norm_eps"))
    if not has("model.backbone.attention_bias"):
        backbone["attention_bias"] = bool(getattr(pretrained_cfg, "attention_bias"))
    return kwargs


def _none_kwargs(cfg: Config) -> dict:
    """Kwargs for ModelNone from config."""
    return dict(
        hidden_dim=cfg.none_hidden_dim,
        backbone_kwargs={},
        embedding_kwargs=cfg.embedding_kwargs,
        sp_head_kwargs=cfg.sp_head_kwargs,
        dqn_head_kwargs=cfg.dqn_head_kwargs,
        sv_head_kwargs=cfg.sv_head_kwargs,
        vec_dqn_head_kwargs=cfg.vec_dqn_head_kwargs,
    )


def _build_model(cfg: Config, resolved_yaml: Any | None = None) -> Model:
    if cfg.backbone == "llama":
        return ModelLlama(**_llama_kwargs(cfg, resolved_yaml=resolved_yaml))
    if cfg.backbone == "qwen3":
        return ModelQwen3(**_qwen3_kwargs(cfg, resolved_yaml=resolved_yaml))
    if cfg.backbone == "none":
        return ModelNone(**_none_kwargs(cfg))
    raise ValueError(f"Invalid model.backbone.type: {cfg.backbone!r}. Must be 'llama', 'qwen3', or 'none'.")


def _warn_config_mismatch(
    target_config: object,
    pretrained_config: object,
    exclude_keys: list[str],
) -> None:
    """Warn if any config keys (except those in exclude_keys) differ between target and pretrained."""
    exclude = set(exclude_keys)
    target_keys = {k for k in dir(target_config) if not k.startswith("_") and k not in exclude}
    mismatches: list[str] = []
    for key in target_keys:
        if not hasattr(pretrained_config, key):
            continue
        t = getattr(target_config, key)
        p = getattr(pretrained_config, key)
        if callable(t) or callable(p):
            continue
        if t != p:
            mismatches.append(f"{key}: target={t!r} vs pretrained={p!r}")
    if mismatches:
        print("  ⚠ config mismatch — weights may not load correctly:")
        for m in mismatches:
            print(f"    {m}")


_IGNORE_KEYS = [
    "vocab_size", "pad_token_id", "bos_token_id", "eos_token_id", "tie_word_embeddings", "model_type",
    "dtype", "architectures", "torch_dtype", "transformers_version", "name_or_path", "num_hidden_layers",
    "rope_scaling", "rope_parameters",
]


def _load_pretrained_backbone_into(
    cfg: Config,
    model: Model,
    device: torch.device,
) -> None:
    """Load pretrained weights into the backbone from an HF repo / local path.

    Uses strict=False so embedding/head key mismatches are silently skipped.
    """
    from transformers import LlamaModel, Qwen3Model

    def _apply(module: torch.nn.Module, sd: dict, label: str) -> None:
        missing, unexpected = module.load_state_dict(sd, strict=False)
        if missing or unexpected:
            print(f"  {label}: {len(missing)} missing keys, {len(unexpected)} unexpected (embed/head may differ).")

    def _hf_sd(pretrained_model):
        sd = pretrained_model.state_dict()
        for key in ("embed_tokens.weight", "embed_tokens.bias", "lm_head.weight", "lm_head.bias"):
            sd.pop(key, None)
        return sd, pretrained_model.config

    if cfg.backbone == "llama":
        assert isinstance(model, ModelLlama)
        if cfg.load_backbone_name:
            print(f"  loading backbone: {cfg.load_backbone_name}")
            sd, pretrained_cfg = _hf_sd(LlamaModel.from_pretrained(cfg.load_backbone_name, dtype=torch.float32))
            _warn_config_mismatch(target_config=model.backbone.config, pretrained_config=pretrained_cfg, exclude_keys=_IGNORE_KEYS)
            _apply(model.backbone, sd, "Backbone")
    elif cfg.backbone == "qwen3":
        assert isinstance(model, ModelQwen3)
        if cfg.load_backbone_name:
            print(f"  loading backbone: {cfg.load_backbone_name}")
            sd, pretrained_cfg = _hf_sd(Qwen3Model.from_pretrained(cfg.load_backbone_name, dtype=torch.float32))
            _warn_config_mismatch(target_config=model.backbone.config, pretrained_config=pretrained_cfg, exclude_keys=_IGNORE_KEYS)
            _apply(model.backbone, sd, "Backbone")
    elif cfg.backbone == "none":
        if cfg.load_backbone_name:
            raise ValueError("load_pretrained_name is not supported for backbone 'none'.")
        return
    else:
        raise ValueError(
            f"load_backbone_name only supported for backbone 'llama', 'qwen3', or 'none', got {cfg.backbone!r}."
        )
    print("  ✓ backbone loaded.")


def _save_checkpoint(
    model: Model,
    step_idx: int,
    run_dir: Path,
    run_name: str,
    wandb_run: Any | None,
    keep: int = 1,
) -> None:
    """Save model checkpoint to a step-numbered directory, then prune old ones.

    Saves before pruning so there is always at least one valid checkpoint on disk
    even if the process is interrupted mid-cleanup.
    """
    import shutil
    ckpts_root = run_dir / "checkpoints"
    ckpt_dir = ckpts_root / f"step_{step_idx}"
    ckpt_dir.mkdir(parents=True, exist_ok=True)
    model.save_pretrained(str(ckpt_dir))
    if wandb_run is not None:
        import wandb  # type: ignore[import-untyped]
        artifact = wandb.Artifact(
            name=f"{run_name}-checkpoint",
            type="model",
            metadata={"step": step_idx},
        )
        artifact.add_dir(str(ckpt_dir))
        wandb_run.log_artifact(artifact, aliases=[f"step_{step_idx}", "latest"])
    print(f"💾 checkpoint  step={step_idx}  → {ckpt_dir}  (W&B + Trackio logged)")

    existing = sorted(
        (d for d in ckpts_root.iterdir() if d.is_dir()),
        key=lambda d: int(d.name.split("_")[1]) if d.name.startswith("step_") else -1,
    )
    for old in existing[:-keep]:
        shutil.rmtree(old)


def _build_optimizer(cfg: Config, model: Model) -> optim.Optimizer:
    """AdamW over trainable model parameters (respects requires_grad=False).

    When cfg.lr_groups is non-empty each key is matched as a named_parameters
    prefix (e.g. "embedder", "backbone", "vec_dqn_head").  Parameters whose
    name starts with "<key>." (or equals the key) use that group's LR; all
    remaining trainable parameters fall back to cfg.lr.
    """
    shared_kwargs = dict(
        weight_decay=float(cfg.weight_decay),
        betas=cfg.adam_betas,
        eps=float(cfg.adam_eps),
    )

    if not cfg.lr_groups:
        return optim.AdamW(
            params=[p for p in model.parameters() if p.requires_grad],
            lr=float(cfg.lr),
            **shared_kwargs,
        )

    group_params: dict[str, list] = {name: [] for name in cfg.lr_groups}
    default_params: list = []

    for param_name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        matched = False
        for group_name in cfg.lr_groups:
            if param_name == group_name or param_name.startswith(group_name + "."):
                group_params[group_name].append(p)
                matched = True
                break
        if not matched:
            default_params.append(p)

    param_groups: list[dict] = [
        {"params": params, "lr": float(cfg.lr_groups[name])}
        for name, params in group_params.items()
        if params
    ]
    if default_params:
        param_groups.append({"params": default_params, "lr": float(cfg.lr)})

    if not param_groups:
        raise ValueError("_build_optimizer: no trainable parameters found.")

    return optim.AdamW(params=param_groups, **shared_kwargs)


def _build_scheduler(
    cfg: Config,
    optimizer: optim.Optimizer,
    total_train_steps: int,
) -> optim.lr_scheduler.LRScheduler | None:
    """LambdaLR with optional linear warmup and cosine decay.

    ``total_train_steps`` is the expected number of times the optimizer will step
    (used to compute the cosine period). Returns None when schedule is constant and
    warmup is 0 (no-op; saves a scheduler.step() call each iteration).
    """
    warmup = cfg.lr_warmup_steps
    if cfg.lr_schedule == "constant" and warmup == 0:
        return None

    min_ratio = cfg.lr_min / cfg.lr if cfg.lr > 0 else 0.0
    cosine_steps = max(1, total_train_steps - warmup)

    def lr_lambda(step: int) -> float:
        if step < warmup:
            return step / max(1, warmup)
        if cfg.lr_schedule == "constant":
            return 1.0
        progress = min(1.0, (step - warmup) / cosine_steps)
        return min_ratio + (1.0 - min_ratio) * 0.5 * (1.0 + math.cos(math.pi * progress))

    return optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def _setup_model(
    cfg: Config,
    device: torch.device,
    resolved_yaml: Any | None = None,
) -> tuple[Model | None, optim.Optimizer | None]:
    """Build or load the model and optimizer.

    Returns ``(model, optimizer)``. Optimizer is built only when ``train_interval > 0``.
    With ``train_interval == 0``, returns ``(model, None)`` for eval and/or checkpoint
    test rollouts, or ``(None, None)`` when no model is configured.
    """
    if cfg.train_interval <= 0 and cfg.eval_interval <= 0 and not cfg.load_model_name:
        return None, None

    if cfg.load_model_name:
        load_name = cfg.load_model_name
        if "/" not in load_name and not Path(load_name).exists():
            load_name = f"{HfApi().whoami()['name']}/{load_name}"
        print(f"  loading pretrained: {load_name}")
        if cfg.backbone == "llama":
            model = ModelLlama.from_pretrained(load_name, map_location=str(device)).to(device)
        elif cfg.backbone == "qwen3":
            model = ModelQwen3.from_pretrained(load_name, map_location=str(device)).to(device)
        elif cfg.backbone == "none":
            model = ModelNone.from_pretrained(load_name, map_location=str(device)).to(device)
        else:
            raise ValueError(f"Invalid model.backbone.type: {cfg.backbone!r}. Must be 'llama', 'qwen3', or 'none'.")
        print("  ✓ loaded.")
    else:
        print("  building from scratch...")
        model = _build_model(cfg, resolved_yaml=resolved_yaml).to(device)
        if cfg.load_backbone_name:
            _load_pretrained_backbone_into(cfg=cfg, model=model, device=device)
        print("  ✓ built.")

    if cfg.backbone == "llama":
        assert isinstance(model, ModelLlama)
        model.backbone.to(torch.float32)
        print("  backbone: llama (fp32)")
    elif cfg.backbone == "qwen3":
        assert isinstance(model, ModelQwen3)
        model.backbone.to(torch.float32)
        print("  backbone: qwen3 (fp32)")

    n_params = sum(p.numel() for p in model.parameters())
    print(f"  params:   {n_params / 1e6:.1f}M  ({n_params / 1e9:.3f}B)")

    frozen = []
    if cfg.embedding_frozen:
        model.embedder.requires_grad_(False)
        frozen.append("embedder")
    if cfg.backbone_frozen and hasattr(model, "backbone"):
        model.backbone.requires_grad_(False)
        frozen.append("backbone")
    if cfg.sp_head_frozen and model.sp_head is not None:
        model.sp_head.requires_grad_(False)
        frozen.append("sp_head")
    if cfg.dqn_head_frozen and model.dqn_head is not None:
        model.dqn_head.requires_grad_(False)
        frozen.append("dqn_head")
    if cfg.sv_head_frozen and model.sv_head is not None:
        model.sv_head.requires_grad_(False)
        frozen.append("sv_head")
    if frozen:
        print(f"  frozen:   {', '.join(frozen)}")

    if cfg.train_interval <= 0:
        return model, None

    optimizer = _build_optimizer(cfg=cfg, model=model)
    return model, optimizer


_LINE_WIDTH = 70


def _hr(title: str = "") -> None:
    """Print a titled section rule or a plain horizontal rule."""
    if title:
        print(f"\n─── {title} {'─' * max(0, _LINE_WIDTH - len(title) - 5)}")
    else:
        print("─" * _LINE_WIDTH)


def _print_config(resolved_yaml: Any, config_path: str) -> None:
    """Dump the fully-resolved config YAML at run start."""
    _hr("Config")
    print(f"  file: {config_path}")
    print()
    for line in OmegaConf.to_yaml(resolved_yaml).splitlines():
        print(f"  {line}")


def main(config_path: str = "") -> None:
    mirror_hf_token_env()
    cfg, resolved_yaml = load_config(config_path)
    _print_config(resolved_yaml, config_path)

    run_name = f"{cfg.wandb_run_name}_{cfg.run_id}"
    run_dir = Path(".tmp") / run_name
    (run_dir / "datasets").mkdir(parents=True, exist_ok=True)
    (run_dir / "wandb").mkdir(parents=True, exist_ok=True)

    _hr("Setup")
    print(f"  run dir: {run_dir}")
    if cfg.wandb_project:
        print("  wandb:   authenticating...")
        setup_wandb()
    print("  hf:      authenticating...")
    setup_huggingface()
    _set_seed(cfg.seed)
    device = _get_device()
    trackio_run = None

    _hr("Data")
    train_token_augmenter = _make_token_augmenter(cfg=cfg, device=device)
    train_runner = _setup_train_runner(cfg=cfg, token_augmenter=train_token_augmenter, run_dir=run_dir, device=device)
    eval_runners = _setup_eval_runners(cfg=cfg, run_dir=run_dir, device=device)
    test_runners = _setup_test_runners(cfg=cfg, device=device, run_dir=run_dir)

    _hr("Model")
    model, optimizer = _setup_model(cfg=cfg, device=device, resolved_yaml=resolved_yaml)

    # Apply max_epochs cap before computing scheduler step count so cosine decay
    # matches the actual number of optimizer steps that will occur.
    max_steps = cfg.max_steps
    if train_runner is not None and cfg.max_epochs > 0:
        max_steps = min(max_steps, cfg.max_epochs * train_runner.total_batches)

    total_train_iterations = (
        max(1, (max_steps - cfg.train_start_step + cfg.train_interval - 1) // cfg.train_interval)
        if cfg.train_interval > 0 else 0
    )
    total_optimizer_steps = (
        (total_train_iterations + cfg.grad_accum_steps - 1) // cfg.grad_accum_steps
        if total_train_iterations > 0
        else 0
    )
    scheduler = _build_scheduler(cfg=cfg, optimizer=optimizer, total_train_steps=total_optimizer_steps) if optimizer is not None else None

    wandb_run = None
    if cfg.wandb_project:
        import wandb  # type: ignore[import-untyped]
        wandb_run = wandb.init(
            project=cfg.wandb_project,
            name=run_name,
            config=dataclasses.asdict(cfg),
            dir=str(run_dir / "wandb"),
        )
        print(f"  W&B: project={cfg.wandb_project!r}   run={wandb_run.name!r}")

    if cfg.trackio_project:
        print(f"  trackio: project={cfg.trackio_project!r}  space_id={cfg.trackio_space_id!r}")
        trackio_run = setup_trackio(
            project=cfg.trackio_project,
            run_name=run_name,
            config=dataclasses.asdict(cfg),
            space_id=cfg.trackio_space_id,
        )

    _hr("Run")
    delays = cfg.train_start_step or cfg.eval_start_step or cfg.test_start_step
    print(
        f"  steps={max_steps}   train_interval={cfg.train_interval}"
        f"   eval_interval={cfg.eval_interval}"
        f"   test_interval={cfg.test_interval}"
        f"   max_epochs={cfg.max_epochs}"
    )
    if delays:
        print(
            f"  delays: train_start={cfg.train_start_step}"
            f"   eval_start={cfg.eval_start_step}"
            f"   test_start={cfg.test_start_step}"
        )
    print()

    step_idx = 0
    train_metrics: dict[str, float] = {}
    eval_metrics: dict[str, float] = {}
    pbar = tqdm(total=max_steps, desc="Steps", unit="step")

    while step_idx < max_steps:
        status_tags: list[str] = []
        step_log: dict = {}

        if (
            test_runners
            and cfg.test_interval > 0
            and step_idx >= cfg.test_start_step
            and (step_idx - cfg.test_start_step) % cfg.test_interval == 0
        ):
            status_tags.append("test")
            #_empty_cache(device)
            for runner in test_runners:
                runner_action_source_prob = runner._loop_prob_schedule(step_idx, max_steps)
                test_metrics = runner.run(
                    model=model,
                    action_source_prob=runner_action_source_prob,
                )
                for k, v in test_metrics.items():
                    step_log[f"test/{runner.env_name}/{k}"] = v
            step_log["test/step_idx"] = step_idx
            #_empty_cache(device)

        if (
            eval_runners
            and model is not None
            and cfg.eval_interval > 0
            and step_idx >= cfg.eval_start_step
            and (step_idx - cfg.eval_start_step) % cfg.eval_interval == 0
        ):
            status_tags.append("eval")
            for eval_tag, eval_runner in eval_runners:
                eval_metrics = eval_runner.eval(
                    model=model,
                    device=device,
                    sp=cfg.sp,
                    sv=cfg.sv,
                    dqn=cfg.dqn,
                    vec_dqn=cfg.vec_dqn,
                )
                for k, v in eval_metrics.items():
                    step_log[f"eval/{eval_tag}/{k}"] = v
            step_log["eval/step_idx"] = step_idx

        if (
            cfg.train_interval > 0
            and train_runner is not None
            and model is not None
            and optimizer is not None
            and step_idx >= cfg.train_start_step
            and (step_idx - cfg.train_start_step) % cfg.train_interval == 0
        ):
            status_tags.append("train")
            train_metrics = train_runner.train(
                model=model,
                optimizer=optimizer,
                device=device,
                sp=cfg.sp,
                sv=cfg.sv,
                dqn=cfg.dqn,
                vec_dqn=cfg.vec_dqn,
                max_grad_norm=cfg.max_grad_norm,
                scheduler=scheduler,
            )
            for k, v in train_metrics.items():
                step_log[f"train/{k}"] = v
            step_log["train/step_idx"] = step_idx

        if wandb_run is not None:
            wandb_run.log(step_log, step=step_idx)
        if trackio_run is not None and step_log:
            trackio_run.log({**step_log, "step": step_idx})

        pbar.set_postfix_str("|".join(status_tags) or "-")
        step_idx += 1
        pbar.update(1)

        if (
            cfg.checkpoint_interval > 0
            and model is not None
            and step_idx % cfg.checkpoint_interval == 0
        ):
            _save_checkpoint(
                model=model,
                step_idx=step_idx,
                run_dir=run_dir,
                run_name=run_name,
                wandb_run=wandb_run,
                keep=cfg.checkpoint_keep,
            )

    pbar.close()
    _empty_cache(device)

    if train_runner is not None:
        train_runner.close()
    for _, eval_runner in eval_runners:
        eval_runner.close()

    if test_runners and cfg.save_dataset:
        save_name = cfg.save_dataset_name or Path(config_path).stem
        if not cfg.save_dataset_name:
            print(f"📤 Save dataset: {save_name!r} (HF will use logged-in user as namespace)")
        save_test_rollout_dataset_to_hub(test_runners=test_runners, repo_id=save_name)

    if model is not None:
        model_dir = run_dir / "model"
        print(f"💾 saving model → {model_dir}")
        model.save_pretrained(str(model_dir))
        print("   ✓ saved locally.")

    if cfg.save_model_name and model is not None:
        save_model_name = cfg.save_model_name
        if "/" not in save_model_name:
            save_model_name = f"{HfApi().whoami()['name']}/{save_model_name}"
            print(f"💾 save model: {save_model_name!r}  (resolved from logged-in user namespace)")
        print(f"💾 pushing model → {save_model_name}")
        model.push_to_hub(save_model_name, model_card_kwargs={"model_id": save_model_name, "sequence_length": cfg.sequence_length, "embedding_kwargs": cfg.embedding_kwargs, "sp_head_kwargs": cfg.sp_head_kwargs, "dqn_head_kwargs": cfg.dqn_head_kwargs, "sv_head_kwargs": cfg.sv_head_kwargs})
        print("   ✓ pushed.")

    if wandb_run is not None:
        wandb_run.finish()
    if trackio_run is not None:
        trackio_run.finish()
    print("\n✅ run complete.")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "")
