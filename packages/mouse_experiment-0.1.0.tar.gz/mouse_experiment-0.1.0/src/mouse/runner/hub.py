"""Hugging Face Hub dataset upload: wipe stale shards then push fresh parquet."""
import re
from typing import Any

import numpy as np
from datasets import Dataset, DatasetDict, Features, Value, concatenate_datasets
from datasets import config as datasets_config
from datasets.naming import _split_re
from huggingface_hub import HfApi
from huggingface_hub.errors import HfHubHTTPError, RepositoryNotFoundError
from huggingface_hub.hf_api import CommitOperationDelete

from mouse.runner.test import RunnerTest
from mouse.data.dataset_store import DatasetStore


def _placeholder_column_like(ref_ds: Dataset, col: str, n_rows: int) -> list[Any]:
    """Build ``n_rows`` placeholder values matching the shape/dtype of ``ref_ds[col][0]``."""
    sample0 = ref_ds[col][0]
    if isinstance(sample0, str):
        return [""] * n_rows
    if isinstance(sample0, (float, np.floating)):
        return [float("nan")] * n_rows
    if isinstance(sample0, (bool, np.bool_)):
        return [False] * n_rows
    if isinstance(sample0, (int, np.integer)):
        return [0] * n_rows
    if isinstance(sample0, list):
        a = np.asarray(sample0)
        if a.dtype == object or a.size == 0:
            return [[] for _ in range(n_rows)]
        if a.dtype.kind == "f":
            fill = np.full_like(a, np.nan, dtype=a.dtype)
        elif a.dtype.kind in ("i", "u"):
            fill = np.zeros_like(a)
        elif a.dtype.kind == "b":
            fill = np.zeros_like(a, dtype=bool)
        else:
            fill = np.zeros_like(a)
        row = fill.tolist()
        return [list(row) for _ in range(n_rows)]
    a = np.asarray(sample0)
    if a.dtype == object:
        return [None] * n_rows
    if a.size == 0:
        return [a.copy() for _ in range(n_rows)]
    if a.dtype.kind == "f":
        fill = np.full_like(a, np.nan)
    elif a.dtype.kind in ("i", "u"):
        fill = np.zeros_like(a)
    elif a.dtype.kind == "b":
        fill = np.zeros_like(a, dtype=bool)
    else:
        fill = np.zeros_like(a)
    return [fill.copy() for _ in range(n_rows)]


def _validate_hf_split_name(split: str) -> None:
    """Split names must match Hugging Face ``datasets`` push_to_hub rules (see ``datasets.naming``)."""
    if not re.match(_split_re, split):
        raise ValueError(
            f"Invalid split name {split!r} for Hugging Face Hub. "
            f"Must match pattern {_split_re!r} (word characters and optional dotted segments). "
            "Use e.g. id_eval or ood_eval, not id-eval. "
            "See https://huggingface.co/docs/hub/datasets-file-names-and-splits"
        )


_HUB_PARQUET_SHARD_RE = re.compile(r"^data/([^/]+)-\d{5}-of-\d{5}\.parquet$")


def _wipe_hub_repo_data(api: HfApi, repo_id: str) -> None:
    """Delete all parquet shards and the README so ``push_to_hub`` starts completely fresh.

    ``DatasetDict.push_to_hub`` merges ``data_files`` from an existing README, so stale split
    names survive across uploads. Wiping both the parquet files and the README before pushing
    lets the library generate a correct card from scratch with no stale entries.
    """
    try:
        files = list(api.list_repo_files(repo_id=repo_id, repo_type="dataset"))
    except RepositoryNotFoundError:
        return
    stale = datasets_config.DATASETDICT_INFOS_FILENAME
    to_delete = [
        f for f in files
        if _HUB_PARQUET_SHARD_RE.match(f)
        or f in (datasets_config.REPOCARD_FILENAME, stale)
    ]
    if to_delete:
        api.create_commit(
            repo_id=repo_id,
            repo_type="dataset",
            operations=[CommitOperationDelete(path_in_repo=f) for f in to_delete],
            commit_message="chore: wipe stale shards before fresh push",
        )


def _is_null_typed(feature) -> bool:
    return isinstance(feature, Value) and feature.dtype == "null"


def _align_rollout_splits_for_hub(splits: dict[str, Dataset]) -> dict[str, Dataset]:
    """Ensure every split has identical columns, types, and order so :class:`DatasetDict` can be pushed.

    Three cases are handled:
    - A column is entirely absent from a split (different NS params across envs).
    - A column exists but is typed ``Value('null')`` in one split because that env never
      reported values for it, while another split has a proper dtype (e.g. ``float64``).
    - Column order differs between splits (DatasetDict requires identical Features objects).

    Strategy: build a canonical ``Features`` schema (non-null types preferred) then
    fill any missing columns with placeholders and ``Dataset.cast`` everything to it.
    ``cast`` uses PyArrow under the hood and correctly handles ``null → float64`` etc.
    """
    if len(splits) <= 1:
        return splits

    # Canonical column order: union of all columns in insertion order across splits.
    canonical_cols: list[str] = []
    seen: set[str] = set()
    for ds in splits.values():
        for col in ds.column_names:
            if col not in seen:
                canonical_cols.append(col)
                seen.add(col)

    # For each column prefer a split that carries a non-null type as the schema reference.
    best_feature: dict[str, Any] = {}
    for col in canonical_cols:
        for ds in splits.values():
            if col in ds.column_names and not _is_null_typed(ds.features[col]):
                best_feature[col] = ds.features[col]
                break
        if col not in best_feature:
            for ds in splits.values():
                if col in ds.column_names:
                    best_feature[col] = ds.features[col]
                    break

    canonical_features = Features(best_feature)

    out: dict[str, Dataset] = {}
    for name, ds in splits.items():
        cur = ds
        # Add any columns absent from this split before casting.
        for col in canonical_cols:
            if col not in cur.column_names:
                ref_ds = next(d for d in splits.values() if col in d.column_names)
                cur = cur.add_column(
                    col,
                    _placeholder_column_like(ref_ds=ref_ds, col=col, n_rows=len(cur)),
                )
        # Reorder to canonical order then cast to canonical types in one shot.
        cur = cur.select_columns(canonical_cols).cast(canonical_features)
        out[name] = cur
    return out


def save_test_rollout_dataset_to_hub(test_runners: list[RunnerTest], repo_id: str) -> None:
    """Concatenate rollout data by split and push to Hugging Face (parquet under ``data/``)."""
    print(f"📤 Hugging Face dataset upload: {repo_id!r}")
    by_split: dict[str, list[Dataset]] = {}
    for runner in test_runners:
        ds = DatasetStore.merge_stores_to_dataset(runner.stores)
        split_key = (runner.env_cfg.split or "train").lower()
        _validate_hf_split_name(split_key)
        by_split.setdefault(split_key, []).append(ds)

    splits_to_push = {k: concatenate_datasets(v) for k, v in by_split.items() if v}
    if not splits_to_push:
        return

    splits_to_push = _align_rollout_splits_for_hub(splits_to_push)
    dataset_dict = DatasetDict(list(splits_to_push.items()))

    try:
        api = HfApi()
        # Unscoped names (e.g. ``play_ib_frozenlake``) are assigned to the logged-in user, but ``repo_info`` and
        # ``upload_file`` expect ``user/dataset``. ``HfApi.create_repo`` returns a ``RepoUrl`` whose ``repo_id`` is
        # parsed from the Hub response URL—do not resolve via ``repo_info(short_name)``, which can 404.
        repo_url = api.create_repo(repo_id, repo_type="dataset", private=False, exist_ok=True)
        hub_repo_id = repo_url.repo_id
        _wipe_hub_repo_data(api=api, repo_id=hub_repo_id)
        dataset_dict.push_to_hub(
            repo_id=hub_repo_id,
            private=False,
            commit_message="New rollout data",
            data_dir="data",
            config_name="default",
        )
    except HfHubHTTPError as e:
        code = getattr(getattr(e, "response", None), "status_code", None)
        if code == 403:
            raise RuntimeError(
                "Hugging Face returned 403 when creating or pushing the dataset. "
                f"save_dataset.name is {repo_id!r}: you need write access to that namespace "
                "(use a short repo name to push under your logged-in user, e.g. "
                "`play_ib_frozenlake`, or `youruser/your-dataset` / an org you belong to). "
                "Check token role at https://huggingface.co/settings/tokens"
            ) from e
        raise
    parts = ", ".join(f"{k}: {len(v)}" for k, v in splits_to_push.items())
    print(f"Saved: {hub_repo_id} ({parts})")
