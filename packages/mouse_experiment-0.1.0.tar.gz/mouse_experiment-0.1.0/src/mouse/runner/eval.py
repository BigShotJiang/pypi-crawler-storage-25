from __future__ import annotations

import torch

from mouse.losses.dqn import DqnLossConfig, dqn_loss
from mouse.losses.sp import SpLossConfig, sp_loss
from mouse.losses.sv import SvLossConfig, sv_loss
from mouse.losses.vec_dqn import VecDqnLossConfig, vec_dqn_loss
from mouse.data.batch import PrefetchBatchifier
from mouse.data.dataset_store import DatasetStore
from mouse.models.base import Model
from tensordict import TensorDict


class RunnerEval:
    """Runner for offline supervised evaluation (no grad, no weight update)."""

    def __init__(
        self,
        store: DatasetStore,
        sequence_length: int,
        batch_size: int,
        sampling: str = "batch",
        prefetch: int = 4,
        num_workers: int = 1,
        device: torch.device | None = None,
    ):
        pin_memory = device is not None and device.type == "cuda"
        self._batchifier = PrefetchBatchifier(
            store=store,
            sequence_length=sequence_length,
            batch_size=batch_size,
            sampling=sampling,
            prefetch=prefetch,
            num_workers=num_workers,
            pin_memory=pin_memory,
        )
        self._device = device
        self._h2d_stream: torch.cuda.Stream | None = (
            torch.cuda.Stream() if device is not None and device.type == "cuda" else None
        )
        self._staged: TensorDict | None = None

    @property
    def total_batches(self) -> int:
        return self._batchifier.total_batches

    def next_batch(self) -> TensorDict:
        """Return the current batch (already on device) and immediately stage the next one."""
        if self._staged is not None:
            td = self._staged
            self._staged = None
            if self._h2d_stream is not None:
                torch.cuda.current_stream().wait_stream(self._h2d_stream)
        else:
            td = self._batchifier.next_batch()
            if self._device is not None and self._device.type == "cuda":
                td = td.to(self._device, non_blocking=True)
                torch.cuda.synchronize()

        if self._h2d_stream is not None:
            next_td = self._batchifier.next_batch()
            with torch.cuda.stream(self._h2d_stream):
                self._staged = next_td.to(self._device, non_blocking=True)

        return td

    def close(self) -> None:
        self._staged = None
        self._batchifier.close()

    def eval(
        self,
        model: Model,
        device: torch.device,
        sp: SpLossConfig,
        sv: SvLossConfig,
        dqn: DqnLossConfig,
        vec_dqn: VecDqnLossConfig,
    ) -> dict[str, float]:
        """Sample one batch and compute eval metrics (no grad, no weight update)."""
        step_stream = self.next_batch()

        w_sp = float(sp.weight)
        w_sv = float(sv.weight)
        w_dqn = float(dqn.weight)
        w_vec_dqn = float(vec_dqn.weight)
        if w_sp <= 0.0 and w_dqn <= 0.0 and w_sv <= 0.0 and w_vec_dqn <= 0.0:
            raise ValueError(
                "At least one of sp_weight, dqn_weight, sv_weight, or vec_dqn_weight must be > 0."
            )

        model.eval()
        metrics: dict[str, float] = {}
        with torch.no_grad():
            with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=device.type == "cuda"):
                out, _ = model(step_stream)
                if w_sp > 0.0:
                    _, sp_metrics = sp_loss(
                        step_stream=step_stream,
                        logits=out["sp"],
                        cfg=sp,
                    )
                    metrics.update(sp_metrics)
                if w_dqn > 0.0:
                    _, dqn_metrics = dqn_loss(
                        step_stream=step_stream,
                        q=out["dqn"],
                        q_target=out["dqn_target"],
                        cfg=dqn,
                    )
                    metrics.update(dqn_metrics)
                if w_vec_dqn > 0.0:
                    _, vec_dqn_metrics = vec_dqn_loss(
                        step_stream=step_stream,
                        online_vecs=out["vec_dqn"],
                        target_vecs=out["vec_dqn_target"],
                        cfg=vec_dqn,
                    )
                    metrics.update(vec_dqn_metrics)
                if w_sv > 0.0:
                    _, sv_metrics = sv_loss(
                        step_stream=step_stream,
                        logits=out["sv"],
                        cfg=sv,
                    )
                    metrics.update(sv_metrics)

        return metrics
