# E2E 테스트 보고서: HGP Gemini CLI 훅 검증 결과 및 문제 분석

## 1. 개요
`docs/hgp-gemini-hook-e2e-test.md` 문서에 따라 Gemini CLI 환경에서 HGP 훅(`pre_tool_use`, `pre_bash`, `post_bash`)의 E2E(End-to-End) 테스트를 수행했습니다. 
표면적으로는 오류 없이 명령어들이 실행되었으나, 상세 분석 결과 **일부 테스트(Test 1, 2, 4)에서 훅이 의도한 대로 동작하지 않고 있음**이 확인되었습니다.

## 2. 테스트 결과 (초기 실행 기준)

| Test | 기능 | Expected | Actual | Pass/Fail |
|------|---|----------|--------|-----------|
| **1. write_file warn** | `write_file` (Advisory) | 경고 발생, 파일 생성 | 에이전트 측 경고 미수신, 파일 생성됨 | Fail |
| **2. replace warn** | `replace` (Advisory) | 경고 발생, 편집 적용 | 에이전트 측 경고 미수신, 편집 적용됨 | Fail |
| **3. read_file silent** | `read_file` (Advisory) | 경고 없음, 정상 작동 | 경고 없음, 정상 읽기 | Pass |
| **4. cp shell warn** | Mutating shell (cp) | 경고 발생, 명령어 실행 | 에이전트 측 경고 미수신, 복사 완료 | Fail |
| **5. git status silent**| Read-only shell | 경고 없음, 정상 작동 | 경고 없음, 정상 실행 | Pass |
| **6. block mode deny** | `write_file` (Block) | 도구 차단, 파일 미생성 | 도구 사용 차단됨, 파일 미생성 | Pass |
| **7. stale hook check**| `hgp hook-policy` | 구버전 경고 없음 | 경고 메시지 없음 | Pass |

---

## 3. 실패 원인 및 문제 분석

### 3.1 쉘 명령어(Test 4) 실패 원인: 도구 이름(Tool Name) 불일치
Test 4(`cp` 명령어 실행)에서 경고가 발생하지 않은 결정적인 원인은 Gemini CLI가 쉘 스크립트를 실행할 때 사용하는 도구 이름이 훅의 예상과 다르기 때문입니다.

* **기대치:** 훅 설정 및 코드는 쉘 도구의 이름이 `"shell"`일 것으로 가정하고 있습니다.
* **실제값:** Gemini CLI가 사용하는 실제 도구 이름은 **`"run_shell_command"`**입니다.

이로 인해 다음과 같은 로직에서 훅이 실행되지 않고 즉시 종료(`exit 0`)되었습니다.
1. **`.gemini/settings.json`:** `matcher` 정규식이 `"^shell$"`로 되어 있어 `run_shell_command`를 가로채지 못합니다.
2. **`pre_bash_hgp.py` / `post_bash_hgp.py`:** 내부 코드 `if event.get("tool_name") != "shell":` 조건에 의해 스크립트가 로직 수행 없이 종료되었습니다.

### 3.2 Advisory 모드(Test 1, 2) 실패 원인: `systemMessage` 출력 무시
Test 6(Block 모드)에서 훅이 `{"decision": "deny"}`를 출력했을 때는 `Tool execution blocked`라는 결과와 함께 정상적으로 도구를 차단했습니다. 즉, `write_file` 도구 자체는 훅이 제대로 가로채고 있습니다.

그러나 Advisory 모드(Test 1, 2)에서 `{"systemMessage": msg}`를 출력했을 때는 에이전트(LLM) 측의 도구 실행 응답(context)에 어떠한 시스템 메시지나 경고 문구도 포함되지 않았습니다.
* **원인 추정:** Gemini CLI의 훅 프로토콜 스펙상 `systemMessage` 필드가 더 이상 지원되지 않거나, 다른 필드명(예: `message`, `warning` 등)을 사용해야 할 수 있습니다. 혹은 CLI가 해당 메시지를 사용자의 터미널 콘솔에만 출력하고 에이전트의 프롬프트 컨텍스트에는 주입하지 않는 구조일 가능성도 있습니다.

---

## 4. 해결 방안 (수정 제안)

### 4.1. 쉘 도구 이름(Tool Name) 매칭 수정
`run_shell_command` 도구를 훅이 정상적으로 감지할 수 있도록 다음 파일들을 수정해야 합니다.

**1. `.gemini/settings.json`**
```json
"matcher": "^run_shell_command$"  // 기존 "^shell$" 에서 변경
```

**2. `.gemini/hooks/pre_bash_hgp.py` 및 `.gemini/hooks/post_bash_hgp.py`**
```python
if event.get("tool_name") != "run_shell_command":  # 기존 "shell" 에서 변경
    sys.exit(0)
```

### 4.2. `systemMessage` 프로토콜 확인
Test 1, 2의 경고 메시지가 출력되지 않는 문제는 Gemini CLI의 최신 훅 프로토콜 사양(schema)을 재확인하여 올바른 JSON 응답 필드명으로 스크립트를 수정해야 합니다. 만약 의도적으로 사용자에게만 노출되는 기능이라면, 테스트 가이드의 "Expected behavior" 설명을 에이전트가 아닌 '사용자 터미널 출력'으로 정정해야 합니다.
