"""
supero.setup — Reusable setup helpers for Supero-generated apps.

Consolidates all the boilerplate that every generated app duplicates:
  - Connection helpers (_host_port, _base, _session)
  - Response parsing (_ok, _extract_uuid, _extract_error)
  - UUID lookups (_fetch_project_uuid, _fetch_tenant_uuid)
  - Progress reporting (_step, _ok_msg, _warn_msg, _fail_msg)
  - SDK build + install (build_and_install_sdk)
  - Service import + config check (ensure_services)
  - Access policy creation (ensure_access_policies)
  - Generic seed helpers (create_with_children)

Usage in generated setup.py (shrinks from ~400 lines to ~50):

    from supero.setup import AppSetup
    from config import MyAppConfig
    from schemas import ALL_SCHEMAS

    setup = AppSetup(MyAppConfig(), ALL_SCHEMAS)
    setup.run()                      # Full bootstrap + services + policies
    setup.seed(my_seed_function)     # App-specific seed data

Or granular:

    setup = AppSetup(config, schemas)
    result = setup.bootstrap()       # Phase 1: domain, schemas, tenants, users
    setup.build_sdk()                # Phase 2: SDK
    setup.import_services()          # Phase 3: services
    setup.create_policies()          # Phase 4: access policies
    setup.create_workflows()         # Phase 5: workflows (if defined)
    setup.seed(my_seed_fn)           # Phase 6: app-specific data

Install: pip install supero>=1.2.0
"""

import sys
import os
import time
import argparse
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

__version__ = '1.1.0'


# ─────────────────────────────────────────────────────────
# Connection Helpers
# ─────────────────────────────────────────────────────────

def parse_host_port(url: str = None) -> tuple:
    """Parse SUPERO_URL into (host, port)."""
    url = (url or os.getenv("SUPERO_URL", "https://api.supero.dev")).strip().rstrip("/")
    scheme, rest = (url.split("://", 1) if "://" in url else ("https", url))
    if ":" in rest:
        host, port_str = rest.rsplit(":", 1)
        try:
            return host, int(port_str)
        except ValueError:
            pass
    return rest, 443 if scheme == "https" else 8083


def build_base_url(url: str = None) -> str:
    """Build base URL from SUPERO_URL env var."""
    host, port = parse_host_port(url)
    proto = "https" if port == 443 else "http"
    return f"{proto}://{host}:{port}"


def create_session(token: str = None, api_key: str = None, app_name: str = "Supero-App") -> requests.Session:
    """Create authenticated requests.Session."""
    s = requests.Session()
    s.verify = False
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    if api_key:
        s.headers["X-API-Key"] = api_key
    s.headers["Content-Type"] = "application/json"
    s.headers["User-Agent"] = f"{app_name}/1.0"
    return s


# ─────────────────────────────────────────────────────────
# Response Parsing
# ─────────────────────────────────────────────────────────

def is_ok(r) -> bool:
    """Check if response is successful (200 or 201)."""
    return r.status_code in (200, 201)


def _classify_sdk_generate_response(http_status, body, p):
    """
    Classify a POST /sdks/generate response and report progress via p.

    Returns:
        (request_id, is_terminal_error)
          request_id: str | None  — set when the build is queued or completed
          is_terminal_error: bool — True only when the caller should abort
                                    (cooldown is NOT a terminal error)

    Server contract (from sdk_routes.generate_sdk):
        HTTP 200 + status='completed'  → done (possibly cached)
        HTTP 202 + status='queued'     → accepted, build in progress
        HTTP 429 + status='cooldown'   → rate-limited, retry later (soft skip)
        HTTP 400/500                   → real error
    """
    body = body if isinstance(body, dict) else {}
    server_status = body.get('status')
    request_id = (
        body.get('request_id')
        or body.get('build_request_uuid')
        or body.get('uuid')
    )

    # Happy path 1: completed synchronously (cached or fast build)
    if http_status == 200 and server_status == 'completed':
        cached = ' (cached)' if body.get('cached') else ''
        p.ok(f"SDK build completed{cached}")
        return request_id, False

    # Happy path 2: queued for background build — 202 is correct, not an error
    if http_status == 202 or server_status == 'queued':
        already = body.get('already_building', False)
        note = 'already in progress' if already else 'queued'
        rid_short = (request_id or '?')[:12]
        p.info(f"SDK build {note} (request={rid_short}...) — polling")
        return request_id, False

    # Soft skip: server is rate-limiting us
    if http_status == 429 or server_status == 'cooldown':
        retry = body.get('retry_after_seconds', '?')
        p.warn(f"SDK build on cooldown (retry after {retry}s) — skipping")
        return None, False

    # Anything else is a genuine error
    err = body.get('error') or body.get('message') or f"HTTP {http_status}"
    p.fail(f"REST generate: {err}")
    return None, True


def extract_uuid(r) -> Optional[str]:
    """Extract UUID from CRUD create response.

    Handles all platform response shapes:
      {'uuid': '...'}                                      ← v3.6 mirrored
      {'data': {'uuid': '...'}}
      {'success': true, 'data': {'property': {'uuid': '...'}}}  ← type-wrapped
    """
    try:
        body = r.json() if r.text else {}
    except Exception:
        return None

    # v3.6: Top-level mirror (most reliable)
    if body.get("uuid"):
        return body["uuid"]

    # Under 'data'
    data = body.get("data", {})
    if isinstance(data, dict):
        if data.get("uuid"):
            return data["uuid"]
        # Type-wrapped: data.{type_name}.uuid
        for val in data.values():
            if isinstance(val, dict) and val.get("uuid"):
                return val["uuid"]

    return None


def extract_error(r) -> str:
    """Extract error message from failed API response."""
    try:
        body = r.json() if r.text else {}
        return body.get("error") or body.get("message") or f"HTTP {r.status_code}"
    except Exception:
        return f"HTTP {r.status_code}"


# ──────────────────────────────────────────────────────────
# Schema name normalization (canonical, vendored at build time)
# ──────────────────────────────────────────────────────────
# normalize_schema_name handles all edge cases (IoT, OAuth, acronyms,
# version patterns, idempotency). It comes from platform/utils/
# schema_naming.py which is synced into supero/schema_naming.py at
# build time by build.sh. Failing to import here means schema_naming.py
# is missing from the source tree — run build.sh once to sync it in.
#
# to_url_name is a one-line alias kept for call-site clarity:
#   entity=to_url_name("FamilyMember")  reads better than
#   entity=normalize_schema_name("FamilyMember")  in seed/policy code.

from .schema_naming import normalize_schema_name

#: Alias for normalize_schema_name. Both names export the same function.
#: Use to_url_name in seed/policy/workflow code where the call site
#: benefits from naming the *purpose* (URL form) rather than the *action*.
to_url_name = normalize_schema_name


_DISPLAY_FIELD_PRIORITY = (
    "full_name", "display_name", "title",
    "chore_name", "meal_name", "item_name", "vendor_name",
    "event_title", "product_name", "project_name",
    "customer_name", "company_name", "venue_name",
    "recipe_name", "course_name", "caption",
)


def _slugify(value) -> str:
    """Convert 'Alice Johnson!' to 'alice-johnson'."""
    import re as _re
    s = str(value).lower()
    s = _re.sub(r"[^a-z0-9\s\-_]", "", s)
    s = _re.sub(r"[\s_]+", "-", s)
    s = _re.sub(r"-+", "-", s)
    return s.strip("-") or "record"


def _seed_record_extract_uuid(response_body):
    """Extract UUID from a create response. Handles v3.6 top-level
    mirrored uuid and nested data.{type}.uuid shapes."""
    if not isinstance(response_body, dict):
        return None
    # v3.6 mirrored top-level uuid (LLM tolerance)
    if response_body.get("uuid"):
        return response_body["uuid"]
    # Classic nested shape: {"data": {"member": {"uuid": "..."}}}
    data = response_body.get("data")
    if isinstance(data, dict):
        if data.get("uuid"):
            return data["uuid"]
        for v in data.values():
            if isinstance(v, dict) and v.get("uuid"):
                return v["uuid"]
    return None


def _seed_record_is_already_exists(response):
    """Check if a create response indicates the record already exists.
    Uses v3.6 structured error_code in addition to HTTP 409."""
    if response.status_code == 409:
        return True
    try:
        body = response.json()
        if isinstance(body, dict):
            if body.get("error_code") == "ALREADY_EXISTS":
                return True
            # Fallback: check error message for "exist"
            err = (body.get("error") or body.get("message") or "").lower()
            if "already exist" in err or "duplicate" in err:
                return True
    except Exception:
        pass
    return False


def seed_record(
    s,
    base,
    domain,
    schema_name,
    data,
    progress=None,
    tenant_name=None,
    parent_type="tenant",
    namespace=None,
):
    """Create a record using platform v3.4 fq_name auto-construction.

    This is the canonical seed helper. LLMs should prefer this over raw
    s.post() calls because it handles every system-level field
    automatically — without requiring a tenant UUID lookup.

    The platform automatically builds fq_name from [domain, project,
    tenant, name] using the authenticated session's context. This
    helper just needs to ensure `name`, `display_name`, and
    `parent_type` are set; the platform does the rest.

    Args:
        s: requests Session (authenticated)
        base: base URL (e.g., "https://api.supero.dev")
        domain: domain name
        schema_name: PascalCase schema name matching ALL_SCHEMAS
                     (e.g., "FamilyMember", "Chore")
        data: dict of semantic attributes. The helper auto-derives
              `name` and `display_name` from the first display field
              it finds (full_name, title, chore_name, meal_name,
              caption, etc.) if they're not already set.
        progress: optional Progress instance for logging
        tenant_name: optional target tenant NAME (not UUID). When
                     provided, sets parent_context.tenant so records
                     land in the named tenant even if the session
                     default differs. When None, the platform uses
                     the JWT session's tenant.
        parent_type: defaults to "tenant". Override for records whose
                     parent is not the tenant (rare).

    Returns:
        UUID of the created (or existing) record, or None on failure.

    Example:
        >>> uuid = seed_record(s, base, domain, "FamilyMember", {
        ...     "full_name": "Alice Johnson",
        ...     "role": "parent",
        ...     "description": "Mom",
        ... }, progress, tenant_name="the-smith-family")
        # Posts to /api/v1/crud/{domain}/family_member with:
        #   name="alice-johnson"
        #   display_name="Alice Johnson"
        #   full_name="Alice Johnson" (preserved)
        #   role="parent"
        #   description="Mom"
        #   parent_type="tenant"
        #   parent_context={"tenant": "the-smith-family"}
        # Platform auto-constructs fq_name and resolves the parent.
    """
    url_name = to_url_name(schema_name)
    # When a namespace is provided, use the colon-qualified form so the
    # platform routes to the app's schema instead of a same-named system
    # schema (e.g. _sys_:project vs constructflow:project). Mandatory for
    # any schema whose name collides with a reserved/system type.
    url_type = f"{namespace}:{url_name}" if namespace else url_name
    payload = dict(data)  # copy so caller's dict isn't mutated

    # Find the display source field
    display_source = None
    for field in _DISPLAY_FIELD_PRIORITY:
        if field in payload and payload[field]:
            display_source = payload[field]
            break

    # Derive name if missing — REQUIRED (platform returns 400 without it)
    if "name" not in payload or not payload["name"]:
        if display_source:
            payload["name"] = _slugify(display_source)
        else:
            import uuid as _uuid
            payload["name"] = f"{url_name}-{_uuid.uuid4().hex[:8]}"

    # Derive display_name if missing (optional, improves UI labels)
    if "display_name" not in payload or not payload["display_name"]:
        if display_source:
            payload["display_name"] = str(display_source)
        else:
            payload["display_name"] = (
                payload["name"].replace("-", " ").replace("_", " ").title()
            )

    # Set parent_type if not already set
    if "parent_type" not in payload:
        payload["parent_type"] = parent_type

    # Set parent_context.tenant if tenant_name provided and caller
    # hasn't already set an explicit parent_uuid or fq_name
    if (tenant_name
            and "parent_uuid" not in payload
            and "fq_name" not in payload):
        existing_ctx = payload.get("parent_context") or {}
        if not isinstance(existing_ctx, dict):
            existing_ctx = {}
        if "tenant" not in existing_ctx:
            payload["parent_context"] = {**existing_ctx, "tenant": tenant_name}

    # NOTE: We do NOT set parent_uuid or fq_name. The platform's
    # v3.4 auto-construction in create_object() builds fq_name from
    # [domain, project, tenant, name] using the auth context +
    # parent_context override. This matches what LLMs naturally write
    # and avoids a tenant UUID lookup in the seed caller.

    crud_base = f"{base}/api/v1/crud/{domain}/{url_type}"

    try:
        r = s.post(crud_base, json=payload, timeout=30)
    except Exception as e:
        if progress:
            progress.warn(
                f"Seed {schema_name} {payload.get('display_name', '?')}: "
                f"request error -- {e}"
            )
        return None

    if r.ok or _seed_record_is_already_exists(r):
        try:
            body = r.json()
        except Exception:
            body = {}
        uuid = _seed_record_extract_uuid(body)

        if not uuid:
            # Lookup by name as fallback
            try:
                lookup = s.get(f"{crud_base}/{payload['name']}", timeout=15)
                if lookup.ok:
                    uuid = _seed_record_extract_uuid(lookup.json())
            except Exception:
                pass

        if uuid:
            if progress:
                progress.ok(f"Seeded {schema_name}: {payload['display_name']}")
            return uuid

        if progress:
            progress.warn(
                f"Seeded {schema_name} but no UUID returned: "
                f"{payload['display_name']}"
            )
        return None

    if progress:
        progress.warn(
            f"Failed to seed {schema_name} {payload.get('display_name', '?')}: "
            f"HTTP {r.status_code} -- {r.text[:200]}"
        )
    return None


def is_already_exists(r) -> bool:
    """Check if error is a duplicate/conflict (safe to skip)."""
    if r.status_code == 409:
        return True
    try:
        body = r.json() if r.text else {}
        code = body.get("error_code", "")
        if code == "ALREADY_EXISTS":
            return True
        msg = (body.get("error") or body.get("message") or "").lower()
        return "already exist" in msg
    except Exception:
        return False


# ─────────────────────────────────────────────────────────
# UUID Lookups
# ─────────────────────────────────────────────────────────

def fetch_project_uuid(s, base: str, domain: str, project_name: str) -> Optional[str]:
    """Fetch project UUID by name."""
    r = s.get(f"{base}/api/v1/crud/{domain}/project", timeout=15)
    if is_ok(r):
        for p in r.json().get("results", []):
            if p.get("name") == project_name:
                return p["uuid"]
    return None


def fetch_tenant_uuid(s, base: str, domain: str, tenant_name: str) -> Optional[str]:
    """Fetch tenant UUID by name."""
    r = s.get(f"{base}/api/v1/crud/{domain}/tenant", timeout=15)
    if is_ok(r):
        for t in r.json().get("results", []):
            if t.get("name") == tenant_name:
                return t["uuid"]
    return None


# ─────────────────────────────────────────────────────────
# Progress Reporting
# ─────────────────────────────────────────────────────────

# Import smart progress bar (falls back to simple mode if not available)
try:
    from supero.cli.progress import Progress
except ImportError:
    pass  # Use fallback below


class _ProgressFallback:
    """Simple step-by-step progress (fallback if supero.progress unavailable)."""

    def __init__(self, total_steps: int = 12, domain: str = "", verbose: bool = False):
        self.total = total_steps

    def step(self, num: int, msg: str):
        print(f"  [{num:>2}/{self.total}] {msg}")
        sys.stdout.flush()

    @staticmethod
    def ok(msg: str):
        print(f"         ✅ {msg}")
        sys.stdout.flush()

    @staticmethod
    def warn(msg: str):
        print(f"         ⚠️  {msg}")
        sys.stdout.flush()

    @staticmethod
    def info(msg: str):
        print(f"         ⚠️  {msg}")
        sys.stdout.flush()

    @staticmethod
    def fail(msg: str):
        print(f"         ❌ {msg}")
        sys.stdout.flush()

# Use smart Progress if available, otherwise fallback
if Progress is None:
    Progress = _ProgressFallback

# ─────────────────────────────────────────────────────────
# SDK Build + Install
# ─────────────────────────────────────────────────────────

def _detect_tenant_sdks(domain: str) -> list:
    """Return list of installed tenant SDK packages for this domain.

    Scans pkg_resources for packages whose project name starts with
    'pymodel' and matches the given domain (or any pymodel package if
    domain is empty).  Each entry is a dict with 'name' and 'version'.
    """
    try:
        import pkg_resources
        domain_slug = domain.replace("-", "_").lower() if domain else ""
        result = []
        for pkg in pkg_resources.working_set:
            name = pkg.project_name.lower()
            if name.startswith("pymodel"):
                # Match domain-specific packages (e.g. pymodel_mani0100)
                # or any pymodel package when domain is empty
                if not domain_slug or domain_slug in name:
                    result.append({"name": pkg.project_name, "version": pkg.version})
        return result
    except Exception:
        return []


def build_and_install_sdk(org, domain: str, progress: Progress = None,
                          session: 'requests.Session' = None,
                          base_url: str = None,
                          interactive: bool = True,
                          force_rebuild: bool = False):
    """Build and install the domain SDK.

    Supports two modes:
      1. Full SDK mode: org.generate_sdk() when org has that method
      2. REST fallback: POST /api/v1/sdks/generate via session when org
         is an HTTP-only session (e.g. generated apps without pymodel)

    Before building, checks if tenant SDK is already installed and reports
    the version. In interactive mode, asks user before rebuilding.

    Args:
        org: Supero org instance (may or may not have generate_sdk)
        domain: Domain name
        progress: Progress reporter
        session: requests.Session for REST fallback
        base_url: Base URL for REST fallback
        interactive: If True, prompt user before rebuilding existing SDK
        force_rebuild: If True, always rebuild (--reset flag)
    """
    p = progress or Progress()

    # ── Check for existing tenant SDK ──
    existing = _detect_tenant_sdks(domain)
    if existing and not force_rebuild:
        for sdk in existing:
            p.ok(f"Already installed: {sdk['name']} v{sdk['version']}")

        if interactive:
            print()
            print(f"         Tenant SDK is already installed.")
            print(f"         Schemas may have changed without a version bump.")
            print()
            try:
                choice = input("         Rebuild SDK? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                choice = "n"

            if choice not in ("y", "yes"):
                p.ok("Skipped rebuild (existing SDK kept)")
                return
            print()
        else:
            # Non-interactive: always rebuild (schemas may have changed)
            p.info("Non-interactive mode — rebuilding SDK (schemas may have changed)")

    # ── Try full SDK method first ──
    if org and hasattr(org, 'generate_sdk'):
        try:
            gen_result = org.generate_sdk(language="python", output_format="wheel", domain_name=domain)
            request_id = (
                gen_result.get("request_id")
                or gen_result.get("build_request_uuid")
                or gen_result.get("uuid")
                or gen_result.get("sdk_uuid")
            )
            sdk_status = gen_result.get("status", "unknown")

            if not request_id:
                p.fail(f"No request_id in response: {str(gen_result)[:150]}")
                return
            p.ok(f"Build triggered (request={request_id[:12]}...)")

            # Poll and install via org
            sdk_uuid = _poll_and_get_sdk_uuid(org, request_id, sdk_status, gen_result, p)
            if sdk_uuid:
                _install_sdk(org, sdk_uuid, p)
            return
        except AttributeError:
            # org doesn't have generate_sdk — fall through to REST
            pass
        except Exception as e:
            p.fail(f"Generate failed: {e}")
            return

    # ── REST fallback: use session + base_url ──
    if not session or not base_url:
        # Try to build session from org if possible
        if org and hasattr(org, '_session'):
            session = org._session
            base_url = base_url or build_base_url()
        elif org and hasattr(org, 'get'):
            # org is an HTTP-only session wrapper — use it for REST calls
            p.info("SDK org has no generate_sdk — using REST endpoint...")
            try:
                gen_result = org.post("/sdks/generate", json={
                    "language": "python",
                    "output_format": "wheel",
                })
                # org.post returns the parsed body dict on success; if we got a
                # dict back, the HTTP-level call succeeded. Absence of a dict
                # is a transport-level failure.
                if not isinstance(gen_result, dict):
                    p.fail(f"REST generate: unexpected response: {str(gen_result)[:150]}")
                    return
                # org wrapper hides the HTTP status; pass http_status=0 so
                # classification falls through to server_status in the body.
                request_id, is_err = _classify_sdk_generate_response(
                    http_status=0,
                    body=gen_result,
                    p=p,
                )
                if is_err:
                    return
                if request_id:
                    sdk_uuid = _poll_sdk_via_org(org, request_id, gen_result, p)
                    if sdk_uuid:
                        _install_sdk_via_org(org, sdk_uuid, p)
                return
            except Exception as e:
                p.fail(f"REST generate failed: {e}")
                return
        else:
            p.warn("Skipped — no org instance or session available")
            return

    # Direct REST via requests.Session
    p.info("Using REST endpoint for SDK generation...")
    try:
        r = session.post(f"{base_url}/api/v1/sdks/generate", json={
            "language": "python",
            "output_format": "wheel",
            "domain": domain,
        }, timeout=30)
        try:
            body = r.json()
        except ValueError:
            body = {}
        request_id, is_err = _classify_sdk_generate_response(
            http_status=r.status_code,
            body=body,
            p=p,
        )
        if is_err:
            return
        if not request_id:
            # Cooldown or completed-cached without a request_id —
            # nothing further to poll.
            return
        # Poll via REST
        sdk_uuid = _poll_sdk_via_rest(session, base_url, request_id, body, p)
        if sdk_uuid:
            _install_sdk_via_rest(session, base_url, sdk_uuid, p)
    except Exception as e:
        p.fail(f"REST SDK build failed: {e}")


def _poll_and_get_sdk_uuid(org, request_id, sdk_status, gen_result, p):
    """Poll SDK build status via org and return sdk_uuid when complete."""
    if sdk_status == "completed":
        p.ok("Already built (cached)")
        return _extract_sdk_uuid_from_status(gen_result)

    timeout_sec, poll_interval = 300, 5
    deadline = time.time() + timeout_sec
    last_msg = ""
    while time.time() < deadline:
        try:
            resp = org.get(f"/sdks/status/{request_id}")
            sdk_status = resp.get("status", "unknown")
            progress_pct = resp.get("progress_percentage", 0)
            step_name = resp.get("current_step", "")

            if sdk_status == "completed":
                p.ok("Build complete")
                return _extract_sdk_uuid_from_status(resp)
            elif sdk_status == "failed":
                p.fail(f"Build failed: {resp.get('error_details', 'unknown')}")
                return None
            else:
                msg = f"{progress_pct}% {step_name}" if progress_pct else sdk_status
                if msg != last_msg:
                    print(f"         ⏳ {msg}")
                    sys.stdout.flush()
                    last_msg = msg
        except Exception as e:
            p.warn(f"Poll error: {e}")
        time.sleep(poll_interval)

    p.fail(f"Timed out ({timeout_sec}s)")
    return None


def _poll_sdk_via_org(org, request_id, gen_result, p):
    """Poll SDK status using org.get() wrapper."""
    status = gen_result.get("status", "unknown")
    if status == "completed":
        p.ok("Already built (cached)")
        return _extract_sdk_uuid_from_status(gen_result)

    timeout_sec, poll_interval = 300, 5
    deadline = time.time() + timeout_sec
    last_msg = ""
    while time.time() < deadline:
        try:
            resp = org.get(f"/sdks/status/{request_id}")
            if isinstance(resp, dict):
                sdk_status = resp.get("status", "unknown")
                if sdk_status == "completed":
                    p.ok("Build complete")
                    return _extract_sdk_uuid_from_status(resp)
                elif sdk_status == "failed":
                    p.fail(f"Build failed: {resp.get('error_details', 'unknown')}")
                    return None
                pct = resp.get("progress_percentage", 0)
                step_name = resp.get("current_step", "")
                msg = f"{pct}% {step_name}" if pct else sdk_status
                if msg != last_msg:
                    print(f"         ⏳ {msg}")
                    sys.stdout.flush()
                    last_msg = msg
        except Exception as e:
            p.warn(f"Poll error: {e}")
        time.sleep(poll_interval)

    p.fail(f"Timed out ({timeout_sec}s)")
    return None


def _poll_sdk_via_rest(session, base_url, request_id, gen_result, p):
    """Poll SDK status using direct REST calls."""
    status = gen_result.get("status", "unknown")
    if status == "completed":
        p.ok("Already built (cached)")
        return _extract_sdk_uuid_from_status(gen_result)

    timeout_sec, poll_interval = 300, 5
    deadline = time.time() + timeout_sec
    last_msg = ""
    while time.time() < deadline:
        try:
            r = session.get(f"{base_url}/api/v1/sdks/status/{request_id}", timeout=15)
            if is_ok(r):
                resp = r.json()
                sdk_status = resp.get("status", "unknown")
                if sdk_status == "completed":
                    p.ok("Build complete")
                    return _extract_sdk_uuid_from_status(resp)
                elif sdk_status == "failed":
                    p.fail(f"Build failed: {resp.get('error_details', 'unknown')}")
                    return None
                pct = resp.get("progress_percentage", 0)
                step_name = resp.get("current_step", "")
                msg = f"{pct}% {step_name}" if pct else sdk_status
                if msg != last_msg:
                    print(f"         ⏳ {msg}")
                    sys.stdout.flush()
                    last_msg = msg
        except Exception as e:
            p.warn(f"Poll error: {e}")
        time.sleep(poll_interval)

    p.fail(f"Timed out ({timeout_sec}s)")
    return None


def _install_sdk(org, sdk_uuid, p):
    """Install SDK via org.sdks.install_python_sdk() or REST fallback."""
    try:
        # Full Supero instance with .sdks manager
        if hasattr(org, 'sdks') and hasattr(org.sdks, 'install_python_sdk'):
            installed = org.sdks.install_python_sdk(sdk_uuid=sdk_uuid)
            if installed:
                ver = _get_installed_sdk_version()
                p.ok(f"Installed{' ' + ver if ver else ''} ({sdk_uuid[:12]}...)")
            else:
                p.fail("Install returned False")
        # HTTP-only session — download wheel via REST and pip install
        elif hasattr(org, 'get'):
            resp = org.get(f"/sdks/{sdk_uuid}/download")
            if isinstance(resp, dict):
                download_url = resp.get("download_url") or resp.get("url")
                if download_url:
                    import subprocess
                    result = subprocess.run(
                        [sys.executable, "-m", "pip", "install",
                         download_url, "--break-system-packages", "-q"],
                        capture_output=True, text=True,
                    )
                    if result.returncode == 0:
                        ver = _get_installed_sdk_version()
                        p.ok(f"Installed via pip{' ' + ver if ver else ''} ({sdk_uuid[:12]}...)")
                    else:
                        p.fail(f"pip install failed: {result.stderr[:200]}")
                else:
                    p.warn(f"No download URL in response (sdk={sdk_uuid[:12]}...)")
            else:
                p.warn(f"Unexpected download response type (sdk={sdk_uuid[:12]}...)")
        else:
            p.warn(f"Cannot install — no .sdks manager or .get method")
    except Exception as e:
        p.fail(f"Install failed: {e}")


def _install_sdk_via_org(org, sdk_uuid, p):
    """Install SDK via org REST wrapper."""
    try:
        if hasattr(org, 'sdks') and hasattr(org.sdks, 'install_python_sdk'):
            installed = org.sdks.install_python_sdk(sdk_uuid=sdk_uuid)
            if installed:
                p.ok(f"Installed ({sdk_uuid[:12]}...)")
            else:
                p.fail("Install returned False")
        else:
            # Download wheel via REST and pip install
            resp = org.get(f"/sdks/{sdk_uuid}/download")
            if isinstance(resp, dict) and resp.get("download_url"):
                import subprocess
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     resp["download_url"], "--break-system-packages", "-q"],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    p.ok(f"Installed via pip ({sdk_uuid[:12]}...)")
                else:
                    p.fail(f"pip install failed: {result.stderr[:200]}")
            else:
                p.warn(f"Cannot install — no download URL (sdk={sdk_uuid[:12]}...)")
    except Exception as e:
        p.fail(f"Install failed: {e}")


def _install_sdk_via_rest(session, base_url, sdk_uuid, p):
    """Install SDK via direct REST download + pip install."""
    try:
        r = session.get(f"{base_url}/api/v1/sdks/{sdk_uuid}/download", timeout=30)
        if is_ok(r):
            resp = r.json()
            download_url = resp.get("download_url") or resp.get("url")
            if download_url:
                import subprocess
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     download_url, "--break-system-packages", "-q"],
                    capture_output=True, text=True,
                )
                if result.returncode == 0:
                    p.ok(f"Installed via pip ({sdk_uuid[:12]}...)")
                else:
                    p.fail(f"pip install failed: {result.stderr[:200]}")
            else:
                p.warn(f"No download URL for sdk {sdk_uuid[:12]}...")
        else:
            p.fail(f"Download failed: {extract_error(r)}")
    except Exception as e:
        p.fail(f"Install failed: {e}")



def _get_installed_sdk_version(domain: str = "") -> str:
    """Get installed SDK package version for logging."""
    import subprocess as _sp
    pkg_name = f"pymodel-{domain.replace('-', '_')}" if domain else "pymodel"
    try:
        r = _sp.run(
            [sys.executable, "-m", "pip", "show", pkg_name],
            capture_output=True, text=True, timeout=10,
        )
        if r.returncode == 0:
            for line in r.stdout.splitlines():
                if line.startswith("Version:"):
                    return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return ""


def _extract_sdk_uuid_from_status(resp: dict) -> Optional[str]:
    sdks = resp.get("sdks", [])
    if sdks:
        u = sdks[0].get("sdk_uuid")
        if u:
            return u
    uuids = resp.get("generated_sdk_uuids", [])
    return uuids[0] if uuids else None


# ─────────────────────────────────────────────────────────
# Service Import
# ─────────────────────────────────────────────────────────

DEFAULT_SERVICE_HINTS = {
    "email": "SendGrid API key",
    "sms": "Twilio Account SID + Auth Token",
    "stripe_checkout": "Stripe API key (sk_live_...)",
    "google_calendar": "Google Service Account JSON",
    "amazon_s3": "AWS Access Key + Secret + Bucket",
    "slack": "Slack Bot Token (xoxb-...)",
    "ai": "OpenAI and/or Anthropic API key",
    "quickbooks": "QuickBooks OAuth Client ID + Secret + Refresh Token",
    "billing": "Stripe API key",
    "push_notification": "FCM Service Account JSON",
    "whatsapp": "Twilio Account SID + Auth Token + WhatsApp number",
    "salesforce": "Salesforce Client ID + Secret + Username",
    "github": "GitHub Personal Access Token",
    "mcp_server": "No config needed (auto-generates from schemas)",
    "mcp_client": "MCP server URLs to connect to",
    "google_oauth": "Google OAuth Client ID + Secret + Redirect URI",
    "google_ads": "Google Ads Customer ID + Developer Token + OAuth credentials",
    "google_reviews": "Google My Business Account ID + OAuth credentials",
    "email_smtp": "SMTP host, port, username, password",
}


def ensure_services(
    s, base: str, domain: str, project_uuid: str,
    services: List[str], progress: Progress = None,
    service_hints: Dict[str, str] = None,
    project_name: str = None,
):
    """Import services and show config status summary."""
    p = progress or Progress()
    hints = {**DEFAULT_SERVICE_HINTS, **(service_hints or {})}

    if not services:
        p.ok("None requested")
        return
    if not project_uuid:
        p.fail("No project_uuid — skipping")
        return

    ok = skip = fail = 0
    failed_services = []

    for svc_id in services:
        try:
            _import_body = {
                "service_id": svc_id,
                "domain": domain,
                "project_uuid": project_uuid,
            }
            # Matches frontend: tenantServicesApi.importService always sends
            # project_name. Platform-core can otherwise fall back to the
            # user's project_name (from auth context), which may be wrong
            # when API key is scoped to a different project than the target.
            if project_name:
                _import_body["project_name"] = project_name
            r = s.post(f"{base}/api/v1/services/import", json=_import_body, timeout=30)
            body = r.json() if r.text else {}
            if is_ok(r) and body.get("success"):
                if body.get("details", {}).get("already_imported"):
                    skip += 1
                else:
                    ok += 1
            elif is_already_exists(r):
                skip += 1
            else:
                fail += 1
                failed_services.append(svc_id)
                err_msg = extract_error(r)
                # Detect auth issues and give a clearer message
                if r.status_code == 401 or "auth" in err_msg.lower() or "token" in err_msg.lower():
                    p.fail(f"'{svc_id}': Unexpected error: {err_msg}")
                else:
                    p.fail(f"'{svc_id}': {err_msg}")
        except Exception as e:
            fail += 1
            failed_services.append(svc_id)
            p.fail(f"'{svc_id}': {e}")

    p.ok(f"{ok} imported, {skip} existing, {fail} failed")

    # Config status check
    needs_config = []
    configured = []
    for svc_id in services:
        if svc_id in failed_services:
            continue
        try:
            cr = s.get(f"{base}/api/v1/services/{svc_id}/config", timeout=10)
            if is_ok(cr):
                cb = cr.json() if cr.text else {}
                status = cb.get("config_status") or cb.get("status", "")
                if status in ("active", "configured"):
                    configured.append(svc_id)
                else:
                    needs_config.append(svc_id)
            else:
                needs_config.append(svc_id)
        except Exception:
            needs_config.append(svc_id)

    # Summary
    print()
    print("  ┌─ Service Status ──────────────────────────────────────┐")
    for svc_id in services:
        hint = hints.get(svc_id, "API credentials")
        if svc_id in failed_services:
            print(f"  │  ❌ {svc_id:<20s} Import failed")
        elif svc_id in configured:
            print(f"  │  ✅ {svc_id:<20s} Ready")
        elif svc_id in needs_config:
            print(f"  │  ⚠️  {svc_id:<20s} Needs: {hint}")
        else:
            print(f"  │  ✅ {svc_id:<20s} Imported")
    if needs_config:
        print("  │")
        print(f"  │  Configure: Supero Admin → {domain} → Services")
    print("  └──────────────────────────────────────────────────────┘")
    print()


# ─────────────────────────────────────────────────────────
# Access Policies
# ─────────────────────────────────────────────────────────

@dataclass
class PolicyRule:
    entity: str
    can_create: bool = False
    can_read: bool = True
    can_update: bool = False
    can_delete: bool = False


@dataclass
class PolicyDef:
    role: str
    default_access: str = "none"
    description: str = ""
    rules: List[PolicyRule] = field(default_factory=list)


def ensure_access_policies(
    s, base: str, domain: str, project_uuid: str,
    policies: List[PolicyDef], progress: Progress = None,
):
    """Create access policies and rules from config."""
    p = progress or Progress()

    if not project_uuid:
        p.fail("No project_uuid — skipping")
        return

    r = s.get(f"{base}/api/v1/crud/{domain}/access-policy", timeout=15)
    if not is_ok(r):
        p.fail(f"List failed: {extract_error(r)}")
        return

    existing_roles = {
        pol.get("role") for pol in r.json().get("results", [])
        if pol.get("parent_uuid") == project_uuid
    }

    created = skipped = 0
    for policy in policies:
        if policy.role in existing_roles:
            skipped += 1
            continue
        if not policy.rules and policy.default_access == "full":
            skipped += 1  # full access roles don't need explicit rules
            continue

        pr = s.post(f"{base}/api/v1/crud/{domain}/access-policy", json={
            "name": f"{policy.role}-policy",
            "parent_type": "project",
            "parent_uuid": project_uuid,
            "role": policy.role,
            "default_access": policy.default_access,
            "description": policy.description,
            "is_active": True,
            "priority": 0,
        }, timeout=30)

        if not is_ok(pr):
            if is_already_exists(pr):
                skipped += 1
                continue
            p.fail(f"Policy '{policy.role}': {extract_error(pr)}")
            continue

        policy_uuid = extract_uuid(pr)
        if not policy_uuid:
            p.fail(f"Policy '{policy.role}' — no UUID")
            continue

        for rule in policy.rules:
            rr = s.post(f"{base}/api/v1/crud/{domain}/access-rule", json={
                "name": f"{policy.role}-{rule.entity}-rule",
                "parent_type": "access-policy",
                "parent_uuid": policy_uuid,
                "entity": rule.entity,
                "can_create": rule.can_create,
                "can_read": rule.can_read,
                "can_update": rule.can_update,
                "can_delete": rule.can_delete,
            }, timeout=30)
            if not is_ok(rr) and not is_already_exists(rr):
                p.fail(f"Rule '{policy.role}/{rule.entity}': {extract_error(rr)}")

        created += 1

    p.ok(f"{created} created, {skipped} existing")


# ─────────────────────────────────────────────────────────
# Workflow Definitions
# ─────────────────────────────────────────────────────────



# ─────────────────────────────────────────────────────────
# Workflow namespace qualifier
# ─────────────────────────────────────────────────────────

_WORKFLOW_SYSTEM_TYPES = {
    "project", "tenant", "user_account", "api_key", "domain",
    "access_policy", "access_rule", "schema", "role", "permission",
}


def _qualify_workflow_object_types(workflows, namespace):
    """Recursively qualify object_type in crud_operation steps.

    Walks every step (including nested then_steps/else_steps) and
    rewrites bare object_type values like 'donation' to qualified
    'ma559:donation' form. Already-qualified types and system types
    pass through unchanged.

    Mutates the workflows list in place AND returns it for chaining.

    Args:
        workflows: list of workflow definition dicts
        namespace: app namespace (will be normalized lowercase + _-_)

    Returns:
        the same workflows list (mutated)
    """
    if not workflows or not namespace:
        return workflows
    _ns = namespace.strip().lower().replace("-", "_")
    if not _ns:
        return workflows

    def _walk(steps):
        for step in (steps or []):
            if not isinstance(step, dict):
                continue
            if step.get("type") == "crud_operation":
                ot = (step.get("object_type") or "").strip()
                if ot and ":" not in ot and ot.lower() not in _WORKFLOW_SYSTEM_TYPES:
                    step["object_type"] = f"{_ns}:{ot}"
            for branch_key in ("then_steps", "else_steps", "steps"):
                if branch_key in step and isinstance(step[branch_key], list):
                    _walk(step[branch_key])

    for wf in workflows:
        if isinstance(wf, dict):
            _walk(wf.get("steps", []))
    return workflows


def ensure_workflows(
    s, base: str, domain: str, project_uuid: str,
    workflow_definitions: List[Dict], progress: Progress = None,
    namespace: str = None,
):
    """Create workflow definitions as CRUD records. Idempotent.

    If namespace is provided (or derivable from domain), bare object_type
    values in crud_operation steps are auto-qualified to {ns}:{type} to
    avoid 409 ambiguity errors when same-named types exist in multiple
    namespaces (e.g. app's 'campaign' vs email service's 'campaign').
    """
    p = progress or Progress()

    if not workflow_definitions:
        p.ok("No workflows defined")
        return

    # Auto-qualify object_type in crud_operation steps. Falls back to
    # domain as the namespace (matches typical APP_NAMESPACE pattern).
    _ns = (namespace or domain or "").strip().lower().replace("-", "_")
    if _ns:
        _qualify_workflow_object_types(workflow_definitions, _ns)
    if not project_uuid:
        p.fail("No project_uuid — skipping workflows")
        return

    # Check existing
    r = s.get(f"{base}/api/v1/crud/{domain}/wf:workflow_definition", timeout=15)
    existing_ids = set()
    if is_ok(r):
        for wf in r.json().get("results", []):
            existing_ids.add(wf.get("workflow_id"))

    created = skipped = failed = 0
    for wf_def in workflow_definitions:
        wf_id = wf_def.get("workflow_id", "")
        if wf_id in existing_ids:
            skipped += 1
            continue
        payload = {"name": wf_id, "parent_type": "tenant", **wf_def}
        try:
            r = s.post(f"{base}/api/v1/crud/{domain}/wf:workflow_definition",
                       json=payload, timeout=30)
            if is_ok(r):
                created += 1
            elif is_already_exists(r):
                skipped += 1
            else:
                failed += 1
                p.fail(f"Workflow '{wf_id}': {extract_error(r)}")
        except Exception as e:
            failed += 1
            p.fail(f"Workflow '{wf_id}': {e}")

    p.ok(f"{created} created, {skipped} existing, {failed} failed")


def ensure_event_bindings(
    s, base: str, domain: str,
    event_bindings: List[Dict], progress: Progress = None,
):
    """Register EVENT_BINDINGS with the workflows service config. Idempotent.

    EVENT_BINDINGS enable auto-firing of workflows on CRUD events:
        @create:<schema>, @update:<schema>, @delete:<schema>, @signup

    Without bindings, service_lib.trigger() logs "no binding" and the
    workflow sits idle — records get created but nothing fires.

    Each binding has the form:
        {
            "event":       "@create:subject",
            "workflow_id": "subject_enrolled",   # must match WORKFLOW_DEFINITIONS
            "input_map":   {"subject_uuid": "uuid", ...},
        }

    The input_map values are dotted paths resolved against the CRUD
    record payload (the record's own fields are at the top level, so
    "uuid" refers to the record's UUID, not a nested field).

    Fetches current config first so we don't clobber base_url etc.
    PUT replaces the event_bindings list (source of truth).
    """
    p = progress or Progress()

    if not event_bindings:
        p.ok("No event_bindings defined")
        return

    # Validate bindings before touching remote state
    for i, b in enumerate(event_bindings):
        if not isinstance(b, dict):
            p.fail(f"event_bindings[{i}] is not a dict")
            return
        missing = [k for k in ("event", "workflow_id") if not b.get(k)]
        if missing:
            p.fail(f"event_bindings[{i}] missing required fields: {missing}")
            return

    # Fetch current workflows service config
    config_url = f"{base}/api/v1/services/workflows/config"
    try:
        r = s.get(config_url, timeout=15)
    except Exception as e:
        p.fail(f"event_bindings: fetch config failed: {e}")
        return

    if r.status_code == 404:
        p.fail(
            "event_bindings: workflows service not imported yet. "
            "Ensure 'workflows' is in config.py services list AND last, "
            "and that ensure_event_bindings() is called AFTER imports."
        )
        return

    if not is_ok(r):
        p.fail(f"event_bindings: fetch failed: {extract_error(r)}")
        return

    try:
        current = r.json()
    except Exception as e:
        p.fail(f"event_bindings: config not JSON: {e}")
        return

    config_data = current.get("config_data") or {}
    if not isinstance(config_data, dict):
        config_data = {}

    # Idempotent short-circuit: skip PUT if bindings already match
    existing = config_data.get("event_bindings") or []
    if _bindings_equivalent(existing, event_bindings):
        p.ok(f"event_bindings: already in sync ({len(event_bindings)} bindings)")
        return

    # PUT updated config
    config_data["event_bindings"] = event_bindings
    payload = {"config_data": config_data}

    try:
        pr = s.put(config_url, json=payload, timeout=15)
    except Exception as e:
        p.fail(f"event_bindings: PUT failed: {e}")
        return

    if not is_ok(pr):
        p.fail(f"event_bindings: PUT failed: {extract_error(pr)}")
        return

    events = [b["event"] for b in event_bindings]
    p.ok(f"event_bindings registered: {len(event_bindings)} ({', '.join(events)})")


def _bindings_equivalent(existing: List[Dict], desired: List[Dict]) -> bool:
    """Compare two binding lists as sets (order-insensitive).

    Bindings are evaluated first-match-by-event, so order doesn't affect
    runtime behavior. Used for idempotent short-circuit.
    """
    if len(existing) != len(desired):
        return False

    def _canonical(b):
        im = b.get("input_map") or {}
        sorted_im = tuple(sorted(im.items())) if isinstance(im, dict) else ()
        return (b.get("event"), b.get("workflow_id"), sorted_im)

    return {_canonical(b) for b in existing} == {_canonical(b) for b in desired}


# ─────────────────────────────────────────────────────────
# Platform-provided billing bundle (v1.7.0)
#
# Auto-merged into workflow_definitions and event_bindings when "billing"
# is present in config.services. Apps opt in via the services list; no
# workflow JSON lives in app code.
#
# Override semantics: apps can override by declaring a workflow with the
# same workflow_id, or a binding with the same (event, workflow_id) pair.
# App declarations win; library default is dropped from the merge.
#
# Design reference: Billing-App-Integration.md §3.1
# ─────────────────────────────────────────────────────────

BILLING_WORKFLOWS = [
    {
        "workflow_id": "billing_invoice_created",
        "display_name": "Invoice created — generate Stripe checkout & notify customer",
        "description": (
            "On billing_invoice create: create Stripe checkout session, "
            "email Pay Now link, store checkout URL on invoice."
        ),
        "version": "1.0.0",
        "enabled": True,
        "status": "Active",
        "on_error": "continue",
        "input_schema": {
            "invoice_uuid":    {"type": "string",   "required": True},
            "invoice_number":  {"type": "string",   "required": True},
            "customer_email":  {"type": "string",   "required": True},
            "customer_name":   {"type": "string",   "required": False},
            "total_amount":    {"type": "float",    "required": True},
            # due_date matches billing_invoice schema type. The template
            # substitution in success_url / email body stringifies it
            # regardless, but declaring the right type here prevents
            # strict workflow-input validation from rejecting the event.
            "due_date":        {"type": "datetime", "required": True},
            "description":     {"type": "string",   "required": False},
        },
        "steps": [
            {
                "id": "create_stripe_checkout",
                "type": "service_call",
                "service": "stripe_checkout",
                "operation": "create_checkout_session",
                "input_map": {
                    "amount": "{{input.total_amount}}",
                    "product_name": "Invoice {{input.invoice_number}}",
                    "success_url": (
                        "{{context.app_url}}/?payment=success"
                        "&session_id={CHECKOUT_SESSION_ID}"
                        "&invoice={{input.invoice_uuid}}"
                    ),
                    "cancel_url": "{{context.app_url}}/?payment=cancelled",
                    "customer_email": "{{input.customer_email}}",
                    # client_reference_id is load-bearing: /api/checkout/finalize
                    # verifies session.client_reference_id == invoice_uuid before
                    # marking the invoice paid. Removing this breaks Phase 1
                    # security (Billing-App-Integration.md §5.3).
                    "client_reference_id": "{{input.invoice_uuid}}",
                },
                # Financial step — abort workflow if Stripe unreachable.
                # Without this, the email step would still run and send
                # the customer a broken Pay Now link. Invoice stays at
                # status: draft; admin can retry manually when Stripe
                # is back up.
                "on_error": "stop",
            },
            {
                "id": "send_invoice_email",
                "type": "service_call",
                "service": "email",
                "operation": "send_email",
                "input_map": {
                    "to_email": "{{input.customer_email}}",
                    "subject": "Invoice {{input.invoice_number}} — due {{input.due_date}}",
                    "body_html": (
                        "<p>Hi {{input.customer_name}},</p>"
                        "<p>Your invoice <strong>{{input.invoice_number}}</strong> "
                        "for <strong>${{input.total_amount}}</strong> is due "
                        "{{input.due_date}}.</p>"
                        "<p>{{input.description}}</p>"
                        "<p><a href='{{steps.create_stripe_checkout.output.checkout_url}}'>"
                        "Pay Now</a></p>"
                    ),
                },
                "on_error": "continue",
            },
            {
                "id": "store_checkout_url",
                "type": "crud_operation",
                "operation": "update",
                "object_type": "billing_invoice",
                "record_uuid": "{{input.invoice_uuid}}",
                "data": {
                    "stripe_checkout_url": "{{steps.create_stripe_checkout.output.checkout_url}}",
                    "status": "sent",
                    "workflow_status": "invoice_sent",
                    "processed_at": "{{context.timestamp}}",
                },
            },
        ],
    },
    {
        "workflow_id": "billing_payment_received",
        "display_name": "Payment received — send receipt, mark invoice paid",
        "description": (
            "On billing_payment create: email receipt to customer, "
            "update linked billing_invoice status to paid."
        ),
        "version": "1.0.0",
        "enabled": True,
        "status": "Active",
        "on_error": "continue",
        "input_schema": {
            "payment_uuid":           {"type": "string", "required": True},
            "invoice_uuid":           {"type": "string", "required": True},
            "customer_email":         {"type": "string", "required": False},
            "customer_name":          {"type": "string", "required": False},
            "amount":                 {"type": "float",  "required": True},
            "payment_method":         {"type": "string", "required": True},
            "transaction_reference":  {"type": "string", "required": False},
        },
        "steps": [
            {
                "id": "send_receipt_email",
                "type": "service_call",
                "service": "email",
                "operation": "send_email",
                "input_map": {
                    "to_email": "{{input.customer_email}}",
                    "subject": "Payment received — ${{input.amount}}",
                    "body_html": (
                        "<p>Hi {{input.customer_name}},</p>"
                        "<p>We've received your payment of "
                        "<strong>${{input.amount}}</strong> via "
                        "<strong>{{input.payment_method}}</strong>.</p>"
                        "<p>Transaction ref: {{input.transaction_reference}}</p>"
                        "<p>Thank you.</p>"
                    ),
                },
                "on_error": "continue",
            },
            {
                "id": "mark_invoice_paid",
                "type": "crud_operation",
                "operation": "update",
                "object_type": "billing_invoice",
                "record_uuid": "{{input.invoice_uuid}}",
                "data": {
                    "status": "paid",
                    "paid_at": "{{context.timestamp}}",
                    "workflow_status": "payment_received",
                },
            },
            {
                "id": "mark_payment_processed",
                "type": "crud_operation",
                "operation": "update",
                "object_type": "billing_payment",
                "record_uuid": "{{input.payment_uuid}}",
                "data": {
                    "workflow_status": "processed",
                    "processed_at": "{{context.timestamp}}",
                },
            },
        ],
    },
]


BILLING_EVENT_BINDINGS = [
    {
        "event": "@create:billing_invoice",
        "workflow_id": "billing_invoice_created",
        # Default input_map assumes customer_email and customer_name are flat
        # fields on billing_invoice. Apps that reference a customer record
        # instead should override this binding with e.g. "customer.email".
        "input_map": {
            "invoice_uuid":    "uuid",
            "invoice_number": "invoice_number",
            "customer_email": "customer_email",
            "customer_name":  "customer_name",
            "total_amount":   "total_amount",
            "due_date":       "due_date",
            "description":    "description",
        },
    },
    {
        "event": "@create:billing_payment",
        "workflow_id": "billing_payment_received",
        "input_map": {
            "payment_uuid":          "uuid",
            "invoice_uuid":          "invoice_uuid",
            "customer_email":        "customer_email",
            "customer_name":         "customer_name",
            "amount":                "amount",
            "payment_method":        "payment_method",
            "transaction_reference": "transaction_reference",
        },
    },
]


def _merge_billing_workflows(app_workflows, services):
    """Merge BILLING_WORKFLOWS into app workflow list if billing is enabled.

    No-op if services list doesn't contain "billing". App overrides win:
    if an app declares a workflow with the same workflow_id as a library
    default, the app's version is kept and the library's is dropped.

    Returns a NEW list; does not mutate inputs.
    """
    app_workflows = app_workflows or []
    if not services or "billing" not in services:
        return list(app_workflows)

    app_ids = {w.get("workflow_id") for w in app_workflows if isinstance(w, dict)}
    merged = [wf for wf in BILLING_WORKFLOWS if wf["workflow_id"] not in app_ids]
    merged.extend(app_workflows)
    return merged


def _merge_billing_event_bindings(app_bindings, services):
    """Merge BILLING_EVENT_BINDINGS into app binding list if billing is enabled.

    No-op if services list doesn't contain "billing". App overrides win
    per (event, workflow_id) pair: an app-declared binding with the same
    key replaces the library default.

    Returns a NEW list; does not mutate inputs.
    """
    app_bindings = app_bindings or []
    if not services or "billing" not in services:
        return list(app_bindings)

    def _key(b):
        if not isinstance(b, dict):
            return (None, None)
        return (b.get("event"), b.get("workflow_id"))

    app_keys = {_key(b) for b in app_bindings}
    merged = [b for b in BILLING_EVENT_BINDINGS if _key(b) not in app_keys]
    merged.extend(app_bindings)
    return merged


# ─────────────────────────────────────────────────────────
# Generic Seed Helpers
# ─────────────────────────────────────────────────────────

def create_with_children(
    s, base: str, domain: str,
    parent_schema: str, parent_data: dict, parent_uuid_override: str = None,
    child_schema: str = None, children: List[dict] = None,
    progress: Progress = None, namespace: str = None,
) -> Optional[str]:
    """Create a parent record and optionally its children. Returns parent UUID."""
    p = progress or Progress()
    # Namespace-qualify schema names if provided (avoids ambiguous bare-name
    # CRUD when the same type exists in multiple namespaces, e.g. app's
    # 'campaign' vs email service's 'campaign').
    _ns_norm = (namespace or "").strip().lower().replace("-", "_")
    def _q(t):
        if not t or ":" in t or not _ns_norm:
            return t
        return f"{_ns_norm}:{t}"
    parent_schema_q = _q(parent_schema)
    child_schema_q = _q(child_schema)

    # Create parent
    if parent_uuid_override:
        parent_uuid = parent_uuid_override
    else:
        r = s.post(f"{base}/api/v1/crud/{domain}/{parent_schema_q}",
                   json=parent_data, timeout=30)
        if not is_ok(r):
            if is_already_exists(r):
                # Try to find existing
                lr = s.get(f"{base}/api/v1/crud/{domain}/{parent_schema_q}", timeout=15)
                if is_ok(lr):
                    for item in lr.json().get("results", []):
                        if item.get("name") == parent_data.get("name"):
                            return item.get("uuid")
                return None
            p.fail(f"{parent_schema}: {extract_error(r)}")
            return None
        parent_uuid = extract_uuid(r)
        if not parent_uuid:
            p.fail(f"{parent_schema} created but no UUID")
            return None

    # Create children
    if child_schema and children:
        ok = 0
        for child in children:
            child["parent_type"] = parent_schema
            child["parent_uuid"] = parent_uuid
            cr = s.post(f"{base}/api/v1/crud/{domain}/{child_schema_q}",
                       json=child, timeout=30)
            if is_ok(cr):
                ok += 1
            elif not is_already_exists(cr):
                p.fail(f"{child_schema} '{child.get('name', '?')}': {extract_error(cr)}")
        p.ok(f"{parent_schema} + {ok}/{len(children)} {child_schema}s")

    return parent_uuid


# ─────────────────────────────────────────────────────────
# AppSetup — Orchestrator
# ─────────────────────────────────────────────────────────

class AppSetup:
    """
    Main orchestrator for Supero app setup.

    Generated setup.py becomes:
        from supero.setup import AppSetup
        setup = AppSetup(config, schemas)
        setup.run()
    """

    def __init__(self, config, schemas: list, public_schemas: list = None):
        """
        Args:
            config: Dataclass with domain_name, admin_email, admin_password,
                    project_name, tenants, users, services
            schemas: ALL_SCHEMAS list
            public_schemas: PUBLIC_SCHEMAS list (for landing page)
        """
        self.config = config
        self.schemas = schemas
        self.public_schemas = public_schemas or []
        # Use smart progress bar if available, fallback to simple
        try:
            self.progress = Progress(
                total_steps=12,
                domain=config.domain_name,
                verbose=bool(os.getenv("SUPERO_VERBOSE", "")),
            )
        except TypeError:
            # Old Progress class doesn't accept domain/verbose
            self.progress = Progress(total_steps=12)
        self.base = build_base_url()
        self.host, self.port = parse_host_port()

        # Set after bootstrap
        self.result = None
        self.session = None
        self.domain = config.domain_name
        self.project_uuid = None
        self.tenant_uuid = None

    def run(self, seed_fn: Callable = None, policies: List[PolicyDef] = None,
            workflow_definitions: List[Dict] = None,
            event_bindings: List[Dict] = None):
        """Full setup: bootstrap → SDK → services → policies → workflows → seed.

        In preview mode (SUPERO_PREVIEW=true), skips services, workflows, and
        seed because:
          - Services need JWT auth and SMTP/OAuth credentials not present in preview
          - Workflows need triggers not relevant in a short-lived preview
          - Seed data may pollute the user's real domain
        The domain is bootstrapped (schemas, tenants, users, policies) so the
        app loads cleanly and shows existing data.
        """
        _preview_mode = os.environ.get("SUPERO_PREVIEW", "").lower() in ("true", "1", "yes")

        self.bootstrap()
        self.build_sdk(force_rebuild=getattr(self, '_force_rebuild', False))

        if _preview_mode:
            self.progress.ok("Preview mode: skipping external services (email/slack/stripe)")
        else:
            self.import_services()

        if policies:
            self.create_policies(policies)

        # ── Library-first billing: auto-merge BILLING_WORKFLOWS and
        # BILLING_EVENT_BINDINGS when "billing" is in config.services.
        # App-declared workflow_ids and (event, workflow_id) pairs win.
        # Design ref: Billing-App-Integration.md §3.1
        _cfg_services = getattr(self.config, "services", None) or []
        workflow_definitions = _merge_billing_workflows(workflow_definitions, _cfg_services)
        event_bindings = _merge_billing_event_bindings(event_bindings, _cfg_services)

        if workflow_definitions:
            self.create_workflows(workflow_definitions)
        if event_bindings:
            self.create_event_bindings(event_bindings)

        if seed_fn:
            self.seed(seed_fn)

        self._print_summary()

    def _persist_env_var(self, key, value):
        """Idempotently write KEY="VALUE" to .env."""
        import os as _os
        import re as _re
        if not value:
            return
        env_path = _os.path.join(_os.getcwd(), ".env")
        if not _os.path.exists(env_path):
            return
        try:
            with open(env_path) as f:
                content = f.read()
        except IOError:
            return
        quoted = f'{key}="{value}"'
        unquoted = f"{key}={value}"
        if quoted in content or unquoted in content:
            _os.environ[key] = value
            return
        pattern = _re.compile(rf"^{_re.escape(key)}=.*$", _re.MULTILINE)
        if pattern.search(content):
            content = pattern.sub(quoted, content, count=1)
        else:
            if content and not content.endswith("\n"):
                content += "\n"
            content += quoted + "\n"
        try:
            with open(env_path, "w") as f:
                f.write(content)
            _os.environ[key] = value
        except IOError:
            pass

    def bootstrap(self):
        """Phase 1: Register domain, upload schemas, create tenants/users."""
        from supero import bootstrap as supero_bootstrap

        cfg = self.config
        p = self.progress

        print()
        print(f"  🏗️  {cfg.domain_name} Setup")
        print(f"  ─────────────────────────────────────────────")
        print(f"  Backend: {self.base}")
        print()

        p.step(1, f"Registering domain '{cfg.domain_name}'...")

        self.result = supero_bootstrap(
            domain_name=cfg.domain_name,
            admin_email=cfg.admin_email,
            admin_password=cfg.admin_password,
            project_name=cfg.project_name,
            schemas=self.schemas,
            tenants=cfg.tenants,
            users=cfg.users,
            idempotent=True,
            fail_fast=False,
            platform_core_host=self.host,
            platform_core_port=self.port,
        )

        result = self.result
        # API-key mode: empty domain_uuid is non-fatal because the working
        # API key proves the domain exists. The supero_bootstrap() fast path
        # may fail to lookup the UUID due to a response shape mismatch, but
        # that doesn't mean registration failed — we never tried to register.
        _api_key_mode = bool(os.environ.get("SUPERO_API_KEY", "").startswith("ak_"))

        if result.domain_uuid:
            p.ok(f"Domain ready ({result.domain_uuid[:12]}...)")
        elif _api_key_mode:
            p.ok(f"Domain '{cfg.domain_name}' assumed ready (API-key mode, UUID lookup skipped)")
        else:
            p.fail("Domain registration failed")
            for e in result.errors:
                p.fail(f"  {e}")
            sys.exit(1)

        # API-key mode: org may be None from bootstrap (login skipped).
        # But many platform endpoints (/services/import, /services/execute)
        # proxy to tenant-service and REQUIRE a JWT pass-through. API key
        # alone isn't enough. So if we have credentials, attempt login
        # NOW so self.session ends up with both JWT and API key headers.
        if _api_key_mode:
            # Try to login anyway — even in API-key mode — to populate JWT
            # for tenant-service proxy endpoints. Falls back to API-key-only
            # if login fails or credentials are missing.
            if cfg.admin_email and cfg.admin_password:
                p.step(2, f"Login as '{cfg.admin_email}' (for JWT pass-through)...")
                try:
                    import requests as _req
                    _project = getattr(cfg, "project_name", "default-project") or "default-project"
                    _r = _req.post(
                        f"{self.base}/api/v1/auth/login",
                        json={
                            "username": cfg.admin_email,
                            "password": cfg.admin_password,
                            "domain": self.domain,
                            "project": _project,
                        },
                        headers={"Content-Type": "application/json"},
                        timeout=15, verify=False,
                    )
                    if _r.status_code in (200, 201):
                        _auth = _r.json().get("auth", {})
                        _jwt = _auth.get("access_token")
                        if _jwt:
                            # Stash JWT on a lightweight org-like object so
                            # the existing session-build code at line 1445
                            # (getattr(org, '_jwt_token', None)) picks it up.
                            class _OrgShim:
                                pass
                            _shim = _OrgShim()
                            _shim._jwt_token = _jwt
                            result.org = _shim
                            p.ok(f"Authenticated (JWT + API key for maximum compatibility)")
                        else:
                            p.warn("Login OK but no access_token in response — continuing with API key only")
                            p.warn("  Service import/execute endpoints may fail (they require JWT)")
                    else:
                        p.warn(f"Login returned HTTP {_r.status_code} — continuing with API key only")
                        p.warn("  Service import/execute endpoints may fail (they require JWT)")
                except Exception as _e:
                    p.warn(f"Login attempt failed: {_e} — continuing with API key only")
                    p.warn("  Service import/execute endpoints may fail (they require JWT)")
            else:
                p.step(2, "Skipping login (API-key mode, no password in config)")
                p.warn("Using SUPERO_API_KEY only")
                p.warn("  Service import/execute endpoints may fail (they require JWT)")
        else:
            p.step(2, f"Login as '{cfg.admin_email}'...")
            if result.org:
                p.ok("Authenticated")
            else:
                p.fail("Login failed")
                sys.exit(1)

        p.step(3, "Retrieving API key...")
        api_key = result.api_key

        # ── Validate the API key looks correct ──
        # Real API keys start with "ak_". If we got something else,
        # try to extract from the org session or re-fetch.
        if api_key and not api_key.startswith("ak_"):
            p.warn(f"Suspicious API key ('{api_key[:20]}...') — does not start with 'ak_'")
            # Try to get the real key from the org session
            real_key = _try_extract_api_key_from_org(result.org)
            if real_key and real_key.startswith("ak_"):
                p.ok(f"Recovered real API key: ...{real_key[-4:]}")
                api_key = real_key
            else:
                # Try REST endpoint to fetch the key
                real_key = _try_fetch_api_key_via_rest(
                    result.org, self.base, cfg.domain_name,
                    cfg.project_name, "default-tenant"
                )
                if real_key and real_key.startswith("ak_"):
                    p.ok(f"Fetched API key via REST: ...{real_key[-4:]}")
                    api_key = real_key
                else:
                    p.warn("Could not recover valid API key — auth may fail for later steps")

        if api_key and api_key.startswith("ak_"):
            _update_env("SUPERO_API_KEY", api_key)
            os.environ["SUPERO_API_KEY"] = api_key
            p.ok(f"API key: ...{api_key[-4:]}")
        else:
            p.warn("No API key returned — using JWT auth")
            api_key = ""

        p.step(4, f"Project '{cfg.project_name}'...")
        if result.project_uuid:
            p.ok(f"Project ready ({result.project_uuid[:12]}...)")
        else:
            p.warn("Project UUID not available")

        p.step(5, f"Uploading {len(self.schemas)} schemas...")
        if result.schemas_failed > 0:
            p.warn(f"{result.schemas_uploaded} uploaded, {result.schemas_skipped} skipped, {result.schemas_failed} FAILED")
        else:
            p.ok(f"{result.schemas_uploaded} uploaded, {result.schemas_updated} updated, {result.schemas_skipped} skipped")

        p.step(7, "Creating tenants...")
        if result.tenants_failed > 0:
            p.fail(f"{result.tenants_failed} FAILED")
        else:
            p.ok(f"{result.tenants_created} created, {result.tenants_skipped} skipped")

        p.step(8, "Creating users...")
        if result.users_failed > 0:
            p.fail(f"{result.users_failed} FAILED")
        else:
            p.ok(f"{result.users_created} created, {result.users_skipped} skipped")

        # ── Setup session for remaining steps ──
        org = result.org
        jwt = getattr(org, '_jwt_token', None) if org else None

        # Build session with both JWT and API key for maximum compatibility
        self.session = create_session(
            token=jwt, api_key=api_key, app_name=cfg.domain_name
        )
        self.project_uuid = result.project_uuid or fetch_project_uuid(
            self.session, self.base, self.domain, cfg.project_name)
        # Persist project_uuid to .env so service_lib.trigger() can include
        # it in /services/execute body (tenant-service requires it).
        self._persist_env_var("SUPERO_PROJECT_UUID", self.project_uuid)
        tenant_name = cfg.tenants[0]["name"] if cfg.tenants else "default-tenant"
        self.tenant_uuid = fetch_tenant_uuid(self.session, self.base, self.domain, tenant_name)

    def build_sdk(self, force_rebuild: bool = False):
        """Phase 2: Build and install domain SDK."""
        self.progress.step(6, "Building domain SDK (may take 30-60s)...")
        build_and_install_sdk(
            self.result.org if self.result else None,
            self.domain,
            self.progress,
            session=self.session,
            base_url=self.base,
            interactive=not os.getenv("SUPERO_NO_INTERACTIVE", ""),
            force_rebuild=force_rebuild or bool(os.getenv("SUPERO_RESET", "")),
        )

    def import_services(self):
        """Phase 3: Import tenant services."""
        self.progress.step(9, "Importing services...")
        ensure_services(
            self.session, self.base, self.domain, self.project_uuid,
            self.config.services, self.progress,
            project_name=getattr(self.config, "project_name", None),
        )

    def create_policies(self, policies: List[PolicyDef]):
        """Phase 4: Create access policies."""
        self.progress.step(10, "Setting up access policies...")
        ensure_access_policies(
            self.session, self.base, self.domain, self.project_uuid,
            policies, self.progress,
        )

    def create_workflows(self, workflow_definitions: List[Dict]):
        """Phase 5: Create workflow definitions.

        Workflow object_type values are auto-qualified with the app
        namespace (defaults to domain) before posting, so workflows
        can use bare type names without hitting cross-namespace
        ambiguity at trigger time.
        """
        self.progress.step(11, "Creating workflow definitions...")
        ensure_workflows(
            self.session, self.base, self.domain, self.project_uuid,
            workflow_definitions, self.progress,
            namespace=self.domain,
        )

    def create_event_bindings(self, event_bindings: List[Dict]):
        """Register EVENT_BINDINGS for CRUD->workflow auto-triggering."""
        ensure_event_bindings(
            self.session, self.base, self.domain,
            event_bindings,
            progress=self.progress,
        )

    def seed(self, seed_fn: Callable):
        """Phase 6: Run app-specific seed function."""
        self.progress.step(12, "Seeding data...")
        seed_session = self._make_tenant_session()
        seed_fn(
            seed_session, self.base, self.domain,
            self.tenant_uuid,
            self.progress,
        )

    def _make_tenant_session(self):
        """Return a JWT-only session with tenant-scoped access for CRUD ops.

        When a session carries X-API-Key the platform uses API-key auth
        (domain-level) and ignores the Bearer token, causing 403 on
        tenant-scoped endpoints.  A fresh login with the project context
        yields a token that includes the tenant_admin role.
        """
        cfg = self.config
        project = getattr(cfg, "project_name", "default-project") or "default-project"
        try:
            import requests as _req
            r = _req.post(
                f"{self.base}/api/v1/auth/login",
                json={
                    "username": cfg.admin_email,
                    "password": cfg.admin_password,
                    "domain": self.domain,
                    "project": project,
                },
                headers={"Content-Type": "application/json"},
                timeout=15, verify=False,
            )
            if r.status_code in (200, 201):
                auth = r.json().get("auth", {})
                token = auth.get("access_token") or auth.get("session_id")
                if token:
                    return create_session(token=token, app_name=self.domain)
        except Exception:
            pass
        # Fallback: strip API key from current session by using org JWT alone
        org = self.result.org if self.result else None
        jwt = getattr(org, "_jwt_token", None) if org else None
        return create_session(token=jwt, app_name=self.domain) if jwt else self.session

    def _print_summary(self):
        cfg = self.config
        # Finish progress bar if active
        if hasattr(self.progress, 'complete'):
            self.progress.complete()
        print()
        print(f"  ✅ {cfg.domain_name} ready!")
        print(f"  ─────────────────────────────────────────────")
        print(f"  Admin: {cfg.admin_email}")
        print()


# ─────────────────────────────────────────────────────────
# API Key Recovery Helpers
# ─────────────────────────────────────────────────────────

def _try_extract_api_key_from_org(org) -> Optional[str]:
    """Try to extract the API key from various org session attributes."""
    if not org:
        return None
    # Check common attribute names
    for attr in ('_api_key', 'api_key', '_cached_api_key'):
        val = getattr(org, attr, None)
        if val and isinstance(val, str) and val.startswith("ak_"):
            return val
    # Check if org has a session with X-API-Key header
    sess = getattr(org, '_session', None) or getattr(org, 'session', None)
    if sess and hasattr(sess, 'headers'):
        key = sess.headers.get("X-API-Key", "")
        if key and key.startswith("ak_"):
            return key
    return None


def _try_fetch_api_key_via_rest(org, base_url: str, domain: str,
                                 project: str, tenant: str) -> Optional[str]:
    """Try to fetch API key via REST endpoint using JWT auth.
    
    Filters by project — returns the api-key scoped to the requested project,
    not the first ak_-prefixed key (which is usually the domain admin's
    default-project key).
    """
    if not org:
        return None
    jwt = getattr(org, '_jwt_token', None)
    if not jwt:
        return None
    try:
        s = create_session(token=jwt, app_name=domain)
        r = s.get(f"{base_url}/api/v1/crud/{domain}/api-key", timeout=15)
        if not is_ok(r):
            return None
        results = r.json().get("results", [])
        # Pass 1: exact project match (preferred)
        for key_obj in results:
            key_val = key_obj.get("api_key_value") or key_obj.get("key") or ""
            if not key_val.startswith("ak_"):
                continue
            # Match by fq_name (most reliable) or by api-key string content
            fq = key_obj.get("fq_name", [])
            if isinstance(fq, list) and project in fq:
                return key_val
            # Fallback: parse project from ak_ key string format
            # ak_<domain>_<project>_<tenant>_<env>_...
            parts = key_val.split("_")
            if len(parts) >= 4 and parts[2] == project:
                return key_val
        # Pass 2: any ak_-prefixed key (last resort, original behavior)
        for key_obj in results:
            key_val = key_obj.get("api_key_value") or key_obj.get("key") or ""
            if key_val.startswith("ak_"):
                return key_val
    except Exception:
        pass
    return None


# ─────────────────────────────────────────────────────────
# Env file helper
# ─────────────────────────────────────────────────────────

def _update_env(key: str, value: str):
    """Update or add a key in .env file.

    Searches for .env starting from CWD (where user runs the app),
    walking up max 3 levels.
    """
    env_path = os.path.join(os.getcwd(), ".env")
    # Walk up to find .env
    for _ in range(3):
        if os.path.exists(env_path):
            break
        env_path = os.path.join(os.path.dirname(os.path.dirname(env_path)), ".env")

    # If no .env found, create in CWD (not in SDK install dir)
    if not os.path.exists(env_path):
        env_path = os.path.join(os.getcwd(), ".env")

    lines = open(env_path).readlines() if os.path.exists(env_path) else []
    found = False
    for i, line in enumerate(lines):
        if line.startswith(f"{key}="):
            lines[i] = f"{key}={value}\n"
            found = True
            break
    if not found:
        # Ensure previous last line has a trailing newline
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        lines.append(f"{key}={value}\n")
    with open(env_path, "w") as f:
        f.writelines(lines)


# ─────────────────────────────────────────────────────────
# Namespace-aware helpers (added by patch_namespace.sh)
# ─────────────────────────────────────────────────────────

def make_seed_record(namespace):
    """Return a seed_record function bound to a specific namespace.

    The namespace is normalized the same way schema_naming.py normalizes
    it during schema registration (hyphens → underscores, lowercase).
    This ensures seed_record URLs match the stored schema namespace.

    Usage in generated setup.py:
        from supero.app_setup import make_seed_record
        from schemas import APP_NAMESPACE
        seed_record = make_seed_record(APP_NAMESPACE)
        # seed_record calls now use the NORMALIZED form (e.g. s10_corp:pet)
        # regardless of what APP_NAMESPACE contains (e.g. "s10-corp").
    """
    # Normalize to match schema_naming.py line 505/517/526
    normalized = (namespace or "").strip().lower().replace("-", "_")

    def _bound(s, base, domain, schema_name, data,
               progress=None, tenant_name=None, parent_type="tenant", **kw):
        return seed_record(
            s, base, domain, schema_name, data,
            progress=progress, tenant_name=tenant_name,
            parent_type=parent_type, namespace=normalized, **kw,
        )
    _bound.__name__ = "seed_record"
    _bound.__doc__ = f"seed_record bound to namespace={normalized!r} (from {namespace!r})"
    return _bound


def ref_link(
    s, base, domain, namespace,
    src_type, src_uuid, tgt_type, tgt_uuid,
    operation="ADD", progress=None,
):
    """Create a reference link between two records using ref-update-multi.

    Handles namespace qualification on both src and tgt types so seed
    code doesn't hand-roll URLs. Wraps request in try/except so a single
    failed ref never crashes the whole seed.

    Args:
        s: authenticated requests.Session
        base: base URL
        domain: domain name
        namespace: app namespace (e.g. APP_NAMESPACE from schemas.py)
        src_type: PascalCase name of the source schema (e.g. "Bid")
        src_uuid: UUID of the source record
        tgt_type: PascalCase name of the target schema (e.g. "Project")
        tgt_uuid: UUID of the target record
        operation: "ADD" (default) or "DELETE"
        progress: optional Progress instance for logging

    Example:
        ref_link(s, base, domain, APP_NAMESPACE,
                 "Bid", bid_uuid, "Project", proj_uuid, progress=progress)
    """
    # Normalize namespace same way schema_naming.py does during registration
    _ns = (namespace or "").strip().lower().replace("-", "_")
    src = f"{_ns}:{to_url_name(src_type)}"
    tgt = f"{_ns}:{to_url_name(tgt_type)}"
    try:
        r = s.put(
            f"{base}/api/v1/crud/{domain}/ref-update-multi",
            json={"updates": [{
                "type": src, "uuid": src_uuid,
                "ref-type": tgt, "ref-uuid": tgt_uuid,
                "operation": operation,
            }]},
            timeout=30,
        )
        if not is_ok(r):
            if progress:
                progress.warn(
                    f"ref-link {src}->{tgt} failed: {extract_error(r)}"
                )
            return False
        if progress:
            progress.ok(f"Linked {src_type} -> {tgt_type}")
        return True
    except Exception as e:
        if progress:
            progress.warn(f"ref-link {src}->{tgt} error: {e}")
        return False
