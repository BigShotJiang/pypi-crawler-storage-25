"""
supero.transactional — Client-side library for the 17 platform transactional services.

Companion to service_lib.py. Where service_lib provides accessors for
messaging/integration services (email, slack, stripe, ...), this module
provides accessors for the transactional services shipped with the
platform: task, ticket, comment, attachment, feedback, membership,
notification, payment, cart, order, booking, appointment, recurring_plan,
approval, inventory, loyalty_points, document_signature.

Source of truth: Supero Transactional Services — Client Integration Guide v1.2.

Goals:
  - One-line operation calls: sl.task.start(task_uuid)
  - Schema-extension registry so apps don't repeat namespace strings
  - Typed responses with `reason` exposed (idempotent-retry signal)
  - Typed exceptions mapping to the four-class error taxonomy
  - Built-in retry policy honoring the three idempotency categories
  - No platform-state coupling; thin wrapper around /api/v1/services/execute

Usage:
    from supero.service_lib import default
    sl = default()

    # Register your app's extension schemas once (recommended)
    sl.transactional.register_extensions({
        "task":            "myapp:project_task",
        "ticket":          "myapp:support_ticket",
        "cart":            ("myapp:user_cart", "myapp:user_cart_item"),
        "order":           ("myapp:user_order", "myapp:user_order_item"),
        "payment":         "myapp:order_payment",
        "approval":        ("myapp:purchase_approval", "myapp:purchase_step"),
        "inventory":       ("myapp:product_inventory", "myapp:stock_reservation"),
        "loyalty_points":  ("myapp:customer_account", "myapp:points_txn"),
        "document_signature": ("myapp:contract_doc", "myapp:contract_sig"),
    })

    # Then call operations naturally:
    sl.task.start(task_uuid)
    sl.task.complete(task_uuid)
    sl.cart.checkout(cart_uuid)
    sl.payment.refund(payment_uuid, refund_amount=30.00)

    # Per-call override is always available:
    sl.task.start(task_uuid, extending_schema="myapp:other_task_kind")

    # Errors are typed:
    try:
        sl.task.start(task_uuid)
    except StateConflictError as e:
        # Task is already in_progress, completed, etc.
        pass
    except NotFoundError:
        # task_uuid doesn't exist
        pass
    except PlatformError:
        # Transient — built-in retry already attempted up to 3x for Cat 1/2
        pass
"""
from __future__ import annotations

import random
import threading
import time
from typing import Any, Dict, List, Optional, Tuple, Union


# ═══════════════════════════════════════════════════════════════════
# Idempotency categories (from Integration Guide §6)
#
# Cat 1 — state-level idempotent (returns `reason` on retry, safe to retry)
# Cat 2 — conditionally idempotent (no `reason`, but same end state)
# Cat 3 — NOT idempotent (cumulative/counter/pointer; do not auto-retry)
#
# Format: frozenset of (service_id, operation) tuples.
# ═══════════════════════════════════════════════════════════════════

_CATEGORY_1 = frozenset({
    # task
    ("task", "start_task"), ("task", "complete_task"), ("task", "cancel_task"),
    # ticket
    ("ticket", "resolve_ticket"), ("ticket", "reopen_ticket"),
    ("ticket", "close_ticket"),
    # comment
    ("comment", "hide_comment"), ("comment", "show_comment"),
    ("comment", "soft_delete_comment"),
    # attachment
    ("attachment", "mark_uploaded"), ("attachment", "archive_attachment"),
    ("attachment", "soft_delete_attachment"),
    # feedback
    ("feedback", "publish_feedback"), ("feedback", "hide_feedback"),
    ("feedback", "show_feedback"),
    # membership
    ("membership", "enroll_member"), ("membership", "suspend_member"),
    ("membership", "reinstate_member"), ("membership", "expel_member"),
    ("membership", "transfer_member"),
    # notification
    ("notification", "send_notification"), ("notification", "mark_seen"),
    ("notification", "dismiss_notification"),
    ("notification", "archive_notification"),
    # payment
    ("payment", "authorize_payment"), ("payment", "capture_payment"),
    ("payment", "void_payment"), ("payment", "fail_payment"),
    # cart
    ("cart", "checkout_cart"), ("cart", "abandon_cart"),
    ("cart", "expire_cart"),
    # order
    ("order", "place_order"), ("order", "fulfill_order"),
    ("order", "cancel_order"),
    # booking
    ("booking", "book_slot"), ("booking", "cancel_booking"),
    ("booking", "complete_booking"),
    # appointment
    ("appointment", "schedule_appointment"),
    ("appointment", "cancel_appointment"),
    ("appointment", "complete_appointment"),
    ("appointment", "mark_no_show"),
    # recurring_plan
    ("recurring_plan", "start_plan"), ("recurring_plan", "pause_plan"),
    ("recurring_plan", "resume_plan"), ("recurring_plan", "cancel_plan"),
    # approval
    ("approval", "submit_approval"), ("approval", "withdraw_approval"),
    # inventory
    ("inventory", "reserve_stock"), ("inventory", "commit_reservation"),
    ("inventory", "release_reservation"),
    # loyalty_points
    ("loyalty_points", "accrue_points"), ("loyalty_points", "redeem_points"),
    ("loyalty_points", "expire_points"), ("loyalty_points", "reverse_txn"),
    # document_signature
    ("document_signature", "request_signatures"),
    ("document_signature", "sign_document"),
    ("document_signature", "decline_signature"),
    ("document_signature", "void_document"),
})

_CATEGORY_2 = frozenset({
    ("task", "block_task"), ("task", "unblock_task"),
    ("ticket", "assign_ticket"), ("ticket", "set_priority"),
    ("booking", "reschedule_booking"),
    ("appointment", "reschedule_appointment"),
    ("cart", "recompute_totals"),
    ("order", "recompute_order_totals"),
})

_CATEGORY_3 = frozenset({
    ("payment", "refund_payment"),
    ("feedback", "mark_helpful"),
    ("comment", "edit_comment"), ("comment", "flag_comment"),
    ("comment", "pin_comment"),
    ("feedback", "flag_feedback"),
    ("recurring_plan", "renew_period"),
    ("inventory", "adjust_quantity"),
    ("approval", "approve_step"), ("approval", "reject_step"),
    ("approval", "delegate_step"),
    ("notification", "mark_all_seen"),
    ("attachment", "mark_scanned"), ("attachment", "fail_upload"),
})

# Query-only operations (no state mutation, no idempotency category).
_QUERY_ONLY = frozenset({
    ("booking", "check_availability"),
    ("appointment", "check_provider_availability"),
})


def _category(service_id: str, operation: str) -> int:
    """Return 1, 2, 3, or 0 (query-only / unknown)."""
    key = (service_id, operation)
    if key in _CATEGORY_1:
        return 1
    if key in _CATEGORY_2:
        return 2
    if key in _CATEGORY_3:
        return 3
    return 0


# ═══════════════════════════════════════════════════════════════════
# Typed exceptions — one per error class in Integration Guide §4
# ═══════════════════════════════════════════════════════════════════

class ServiceError(Exception):
    """Base class for all transactional service errors."""

    status_code: int = 0

    def __init__(self, message: str = "", *,
                 service_id: str = "", operation: str = "",
                 raw: Any = None):
        super().__init__(message)
        self.message = message
        self.service_id = service_id
        self.operation = operation
        self.raw = raw

    def __str__(self) -> str:
        prefix = ""
        if self.service_id and self.operation:
            prefix = f"[{self.service_id}.{self.operation}] "
        return f"{prefix}{self.message}"


class BadRequestError(ServiceError):
    """HTTP 400 — required input missing or invalid. Do not retry."""
    status_code = 400


class NotFoundError(ServiceError):
    """HTTP 404 — target record does not exist. Do not retry."""
    status_code = 404


class StateConflictError(ServiceError):
    """HTTP 409 — current state machine does not permit this transition."""
    status_code = 409


class PlatformError(ServiceError):
    """HTTP 502 — handler's call to platform-core failed.

    Retryable for Cat 1/2 ops; the SDK retries automatically up to
    `max_retries` times before raising. For Cat 3 ops, raised on first
    failure with no auto-retry.
    """
    status_code = 502


class SoftFailureError(ServiceError):
    """HTTP 200 with {"success": false, "output": {"error": ...}}.

    The platform engine caught a downstream condition before reaching the
    handler. Treat as logically failed; do not auto-retry.
    """
    status_code = 200


def _classify_error(http_status: int, error_message: str,
                    service_id: str, operation: str,
                    raw: Any = None) -> ServiceError:
    """Map HTTP status to a typed exception. Never raises, always returns."""
    cls = {
        400: BadRequestError,
        404: NotFoundError,
        409: StateConflictError,
        502: PlatformError,
    }.get(http_status, ServiceError)
    err = cls(error_message or f"HTTP {http_status}",
              service_id=service_id, operation=operation, raw=raw)
    err.status_code = http_status or err.status_code
    return err


# ═══════════════════════════════════════════════════════════════════
# Result wrapper
#
# Lightweight: subclasses dict so callers can use mapping-style access
# (`result["status"]`) but also expose attribute access for the most
# common fields. No pydantic dependency.
# ═══════════════════════════════════════════════════════════════════

class ServiceResult(dict):
    """Successful response from a transactional operation.

    Exposes the platform's `output` object as a dict, plus convenience
    attributes for common fields. The full `output` envelope is preserved
    so callers can read service-specific extras (e.g. `confirmation_code`,
    `items_created`, `balance`).

    Common attributes:
      - record_uuid: the uuid of the affected record
      - status:      new state of the record (None for query-only or bulk ops)
      - reason:      non-null only on idempotent retry (Cat 1)
      - provider:    handler provider id (e.g. "task_internal")
      - request_id:  echoed for trace correlation

    Helpers:
      - is_idempotent_noop: True iff `reason` is set (any non-null value)
      - service_id, operation: the call that produced this result
    """

    def __init__(self, output: Optional[Dict[str, Any]],
                 service_id: str, operation: str):
        super().__init__(output or {})
        self.service_id = service_id
        self.operation = operation

    @property
    def record_uuid(self) -> Optional[str]:
        return self.get("record_uuid")

    @property
    def status(self) -> Optional[str]:
        return self.get("status")

    @property
    def reason(self) -> Optional[str]:
        return self.get("reason")

    @property
    def provider(self) -> Optional[str]:
        return self.get("provider")

    @property
    def request_id(self) -> Optional[str]:
        return self.get("request_id")

    @property
    def is_idempotent_noop(self) -> bool:
        """True if this response was returned for an already-applied op.

        Treat any non-null `reason` as an idempotent retry signal — do
        not parse the value (it's not canonical across operations).
        """
        return self.get("reason") is not None


# ═══════════════════════════════════════════════════════════════════
# Schema-extension registry
#
# Apps register their extending-schema mappings once, so per-call code
# stays terse. Stored at the TransactionalClient level; per-call override
# always wins.
# ═══════════════════════════════════════════════════════════════════

# Services that require a SECOND extending schema. The tuple slots map
# to the kwarg names the platform's handler expects.
#
# IMPORTANT: tuples below use the user-natural ordering "(header, child)".
# Slot 0 is the parent schema, slot 1 is the child schema. The slot names
# are the platform-kwarg-name those schemas should be sent under for the
# SERVICE'S MOST COMMON OPERATION (e.g. cart's checkout uses
# extending_schema=cart_schema, cart_item_extending_schema=cart_item_schema).
#
# Two services break this pattern because their ops are anchored on the
# CHILD record, not the header:
#
#   - inventory: reserve/commit/release operate on RESERVATION records, so
#     extending_schema=reservation. adjust_quantity operates on the
#     INVENTORY record, so extending_schema=inventory. Stored using
#     internal keys `_inventory_schema` / `_reservation_schema` and
#     resolved per-op in _Inventory.
#
#   - loyalty_points: accrue/redeem/expire/reverse operate on TXN records,
#     and the platform expects txn_extending_schema + account_extending_schema
#     side-by-side (no overloaded "extending_schema"). Stored under those
#     names directly.
_TWO_SCHEMA_SERVICES = {
    "cart":               ("extending_schema", "cart_item_extending_schema"),
    "order":              ("extending_schema", "order_item_extending_schema"),
    "approval":           ("extending_schema", "step_extending_schema"),
    # inventory: registered as (inventory, reservation); ops resolve
    # the right kwarg per-op.
    "inventory":          ("_inventory_schema", "_reservation_schema"),
    # loyalty_points: registered as (account, txn). Both kwargs travel
    # together on every loyalty op, so we use platform-native names.
    "loyalty_points":     ("account_extending_schema", "txn_extending_schema"),
    "document_signature": ("extending_schema", "signature_extending_schema"),
}


class _ExtensionRegistry:
    """Holds the app's mapping from service_id → extending schema name(s).

    Values may be:
      - str:                         single-schema service (task, ticket, ...)
      - (str, str) tuple:            two-schema service (cart, order, ...)
      - dict with explicit keys:     advanced override

    Thread-safe: reads return defensive copies under a lock. Writes
    happen under the same lock. Typical usage registers once at startup
    and reads many times, so contention is negligible.
    """

    def __init__(self):
        # Internal storage normalized to dicts of kwarg → schema_name
        self._map: Dict[str, Dict[str, str]] = {}
        self._lock = threading.Lock()

    def set(self, service_id: str,
            value: Union[str, Tuple[str, ...], Dict[str, str], None]) -> None:
        # Validate/normalize OUTSIDE the lock so a ValueError doesn't
        # leave the registry partially mutated.
        normalized = self._normalize(service_id, value)
        with self._lock:
            if normalized is None:
                self._map.pop(service_id, None)
            else:
                self._map[service_id] = normalized

    @staticmethod
    def _normalize(service_id, value):
        if value is None:
            return None
        if isinstance(value, str):
            return {"extending_schema": value}
        if isinstance(value, dict):
            return dict(value)
        if isinstance(value, (tuple, list)):
            slots = _TWO_SCHEMA_SERVICES.get(service_id)
            if not slots:
                raise ValueError(
                    f"Service '{service_id}' is single-schema; pass a string, "
                    f"not a tuple"
                )
            if len(value) != len(slots):
                raise ValueError(
                    f"Service '{service_id}' expects {len(slots)} schemas, "
                    f"got {len(value)}"
                )
            return dict(zip(slots, value))
        raise TypeError(
            f"Extension value must be str, tuple, or dict; got {type(value)}"
        )

    def get(self, service_id: str) -> Dict[str, str]:
        with self._lock:
            return dict(self._map.get(service_id, {}))

    def update(self, mapping: Dict[str, Any]) -> None:
        # Validate every entry first so a single bad key doesn't leave a
        # partially-applied update.
        normalized = {}
        for k, v in mapping.items():
            n = self._normalize(k, v)
            if n is not None:
                normalized[k] = n
            else:
                normalized[k] = None  # explicit clear
        with self._lock:
            for k, n in normalized.items():
                if n is None:
                    self._map.pop(k, None)
                else:
                    self._map[k] = n

    def view(self) -> Dict[str, Dict[str, str]]:
        with self._lock:
            return {k: dict(v) for k, v in self._map.items()}


# ═══════════════════════════════════════════════════════════════════
# TransactionalClient — the engine all service accessors share
# ═══════════════════════════════════════════════════════════════════

class TransactionalClient:
    """Engine that executes transactional service operations.

    Held by ServiceLib as `sl.transactional`. Each per-service accessor
    (sl.task, sl.cart, ...) holds a back-reference to this client and
    calls .execute() to run operations.
    """

    # Default retry config for Cat 1 / Cat 2 ops on PlatformError.
    DEFAULT_MAX_RETRIES = 3
    DEFAULT_BACKOFF_BASE = 0.1   # seconds
    DEFAULT_BACKOFF_FACTOR = 3.0

    def __init__(self, service_lib):
        self._sl = service_lib
        self._registry = _ExtensionRegistry()

    # ── Public registry surface ────────────────────────────────

    def register_extensions(self, mapping: Dict[str, Any]) -> None:
        """Register extending schemas for one or many services at once.

        Accepts any mix of:
          - "task": "myapp:project_task"                     (single-schema)
          - "cart": ("myapp:user_cart", "myapp:user_item")   (two-schema tuple)
          - "approval": {"extending_schema": "...",
                         "step_extending_schema": "..."}     (explicit kwargs)

        See module docstring for a full example.
        """
        self._registry.update(mapping)

    def register_extension(self, service_id: str,
                           value: Union[str, Tuple[str, ...],
                                        Dict[str, str], None]) -> None:
        """Register (or clear, if value is None) a single service."""
        self._registry.set(service_id, value)

    def registered_extensions(self) -> Dict[str, Dict[str, str]]:
        """Return a copy of the current registry (for debugging)."""
        return self._registry.view()

    # ── Catalog ─────────────────────────────────────────────────────────

    def describe(self, *, force_refresh: bool = False) -> Dict[str, Any]:
        """Fetch the platform's transactional service catalog.

        Returns the canonical JSON describing all transactional services:
        their operations, idempotency categories, state machines, allowed
        transitions, and per-op input field lists. The catalog is the
        same JSON every app receives.

        Cached on the TransactionalClient after the first call. Pass
        `force_refresh=True` to bust the cache (useful if the platform
        rolled out a new operation mid-session — rare).

        Returns:
            dict with shape {"version": "...", "services": {...}}.
            On failure, returns {"version": "0.0.0", "services": {}} so
            the UI can still render (just without action buttons).

        This method is what server.py BFF handlers call. UI fetches from
        /api/transactional/describe; server.py proxies through this method.
        """
        if not force_refresh and getattr(self, "_catalog_cache", None) is not None:
            return self._catalog_cache

        sl = self._sl
        http = sl._get_http()
        if http is None:
            sl._logger("warning",
                "transactional.describe: PlatformClient unavailable")
            empty = {"version": "0.0.0", "services": {}}
            self._catalog_cache = empty
            return empty

        try:
            resp = http.get("/api/v1/services/transactional-catalog")
            if not isinstance(resp, dict):
                raise ValueError(
                    f"Unexpected response type: {type(resp).__name__}")
            if "services" not in resp:
                raise ValueError("Catalog response missing 'services' key")
            self._catalog_cache = resp
            return resp
        except Exception as e:
            sl._logger("warning", f"transactional.describe failed: {e}")
            empty = {"version": "0.0.0", "services": {}}
            self._catalog_cache = empty
            return empty

    # ── Core execute path ──────────────────────────────────────

    def execute(self, service_id: str, operation: str,
                input_data: Dict[str, Any], *,
                max_retries: Optional[int] = None,
                safe: bool = False) -> Optional[ServiceResult]:
        """Invoke a transactional operation with retry-by-category.

        Args:
          service_id, operation: identify the op (e.g. "task", "start_task")
          input_data: the per-op fields. extending_schema(s) may be supplied
                      explicitly; if missing, looked up from the registry.
                      `op` is auto-injected to mirror `operation`.
          max_retries: override the default retry count for Cat 1/2 ops.
                       Cat 3 ops never auto-retry regardless of this value.
          safe: if True, swallow exceptions and return None (mirrors the
                fire-and-forget contract of ServiceLib.exec / .trigger).
                Default False — exceptions propagate.

        Returns:
          ServiceResult on success.
          None if safe=True and the call failed.

        Raises (when safe=False):
          BadRequestError, NotFoundError, StateConflictError,
          PlatformError, SoftFailureError.
        """
        # Inject defaults from registry
        merged_input = self._inject_extensions(service_id, operation,
                                                dict(input_data))

        # Echo `op` inside `input` for the handler's _infer_operation
        # fallback (and for clarity on the wire). The top-level
        # `operation` is what platform-core dispatches on; the inner
        # `op` is what the handler reads.
        merged_input.setdefault("op", operation)

        cat = _category(service_id, operation)
        retries = (max_retries
                   if max_retries is not None
                   else self.DEFAULT_MAX_RETRIES)

        attempt = 0
        last_exc: Optional[ServiceError] = None
        while True:
            try:
                return self._execute_once(service_id, operation, merged_input)
            except PlatformError as e:
                last_exc = e
                # Cat 3 (and unknown ops) never auto-retry.
                if cat == 3 or cat == 0:
                    break
                attempt += 1
                if attempt >= retries:
                    break
                self._sleep_backoff(attempt)
                continue
            except ServiceError as e:
                # 4xx errors are persistent — never retry.
                last_exc = e
                break
            except Exception as e:
                # Network or unknown — wrap as PlatformError-equivalent
                # so callers see one exception hierarchy.
                last_exc = PlatformError(
                    f"Unexpected transport error: {e}",
                    service_id=service_id, operation=operation,
                )
                if cat == 3 or cat == 0:
                    break
                attempt += 1
                if attempt >= retries:
                    break
                self._sleep_backoff(attempt)
                continue

        if safe:
            self._sl._logger("warning",
                f"transactional.{service_id}.{operation} failed: {last_exc}")
            return None
        if last_exc is not None:
            raise last_exc
        # Defensive — should be unreachable.
        return None

    # ── Helpers ───────────────────────────────────────────────

    def _inject_extensions(self, service_id: str, operation: str,
                            input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fill missing extending_schema kwargs from the registry.

        Keys starting with `_` are internal markers (e.g. inventory's
        `_inventory_schema` / `_reservation_schema`) — these are NOT
        platform kwargs and are handled by per-service logic below.
        """
        defaults = self._registry.get(service_id)
        if not defaults:
            return input_data

        # Generic injection: only platform-real kwargs (no leading `_`).
        for kwarg, schema_name in defaults.items():
            if kwarg.startswith("_"):
                continue
            input_data.setdefault(kwarg, schema_name)

        # ── Service-specific injection ─────────────────────────────

        # cart.checkout_cart needs order schemas from the order registry
        if service_id == "cart" and operation == "checkout_cart":
            order_defaults = self._registry.get("order")
            kwarg_map = {
                "extending_schema":      "order_extending_schema",
                "order_item_extending_schema": "order_item_extending_schema",
            }
            for src_kwarg, target_kwarg in kwarg_map.items():
                if src_kwarg in order_defaults and target_kwarg not in input_data:
                    input_data[target_kwarg] = order_defaults[src_kwarg]

        # inventory: map internal markers to per-op platform kwargs
        if service_id == "inventory":
            inv_schema = defaults.get("_inventory_schema")
            res_schema = defaults.get("_reservation_schema")
            if operation in ("reserve_stock", "commit_reservation",
                             "release_reservation"):
                # Reservation-anchored ops:
                #   extending_schema = reservation
                #   inventory_extending_schema = inventory
                if res_schema:
                    input_data.setdefault("extending_schema", res_schema)
                if inv_schema:
                    input_data.setdefault("inventory_extending_schema",
                                           inv_schema)
            elif operation == "adjust_quantity":
                # Inventory-anchored op:
                #   extending_schema = inventory
                if inv_schema:
                    input_data.setdefault("extending_schema", inv_schema)

        return input_data

    # ── Service lifecycle helpers ─────────────────────────────
    #
    # Before any op call works against a fresh project, the service must
    # be imported into the project AND its plugin webhook configured.
    # Apps building from scratch hit "no handler registered" errors
    # without these. The e2e test (test_33_app_service_integration.py)
    # demonstrates the canonical sequence:
    #   1. POST /api/v1/services/import {service_id, domain, project_uuid}
    #   2. PUT  /api/v1/services/{svc}/config {config_data: {base_url}}
    # See run_transactional_e2e.py for the bare-shell version.

    def import_service(self, service_id: str, *,
                       safe: bool = True) -> bool:
        """Import a transactional service into the current project.

        Idempotent: returns True if the service was newly imported OR
        was already imported. Returns False (or raises if safe=False)
        on unrecoverable failures.

        Mirrors the sequence in test_33_app_service_integration.py.
        """
        sl = self._sl
        try:
            self._require_config()
        except BadRequestError:
            if safe:
                return False
            raise

        http = sl._get_http()
        if http is None:
            if safe:
                return False
            raise PlatformError("PlatformClient unavailable")

        payload = {
            "service_id": service_id,
            "domain": sl.domain,
        }
        if sl.project_uuid:
            payload["project_uuid"] = sl.project_uuid

        try:
            resp = http.post("/api/v1/services/import", json=payload)
        except Exception as e:
            # 409 Conflict almost always means "already imported" — that's
            # success for this idempotent operation. Any other failure
            # bubbles up (or returns False under safe=True).
            mapped = self._map_transport_exception(e, "_lifecycle", "import_service")
            if isinstance(mapped, StateConflictError):
                return True
            if isinstance(mapped, ServiceError):
                msg = (mapped.message or "").lower()
                if "already" in msg:
                    return True
            if safe:
                self._sl._logger("warning",
                    f"transactional.import_service({service_id}) failed: {e}")
                return False
            if isinstance(mapped, ServiceError):
                raise mapped
            raise PlatformError(f"Transport error: {e}",
                                service_id=service_id, operation="import_service")

        if isinstance(resp, dict):
            if resp.get("success"):
                return True
            details = resp.get("details") or {}
            if details.get("already_imported"):
                return True
        return bool(resp)

    def configure_service(self, service_id: str, *,
                          base_url: str = "http://tenant-service:8092",
                          extra_config: Optional[Dict[str, Any]] = None,
                          safe: bool = True) -> bool:
        """Configure the service's plugin webhook.

        After import_service, the service still routes to an unconfigured
        plugin until this is called. The default `base_url` matches the
        in-cluster tenant-service hostname; override for sidecar/external
        deployments.

        Returns True iff the platform reports the configuration as active.
        """
        sl = self._sl
        try:
            self._require_config()
        except BadRequestError:
            if safe:
                return False
            raise

        http = sl._get_http()
        if http is None:
            if safe:
                return False
            raise PlatformError("PlatformClient unavailable")

        config_data = {"base_url": base_url}
        if extra_config:
            config_data.update(extra_config)

        try:
            resp = http.put(
                f"/api/v1/services/{service_id}/config",
                json={"config_data": config_data},
            )
        except Exception as e:
            mapped = self._map_transport_exception(e, "_lifecycle",
                                                    "configure_service")
            if safe:
                self._sl._logger("warning",
                    f"transactional.configure_service({service_id}) failed: {e}")
                return False
            if isinstance(mapped, ServiceError):
                raise mapped
            raise PlatformError(f"Transport error: {e}",
                                service_id=service_id,
                                operation="configure_service")

        if not isinstance(resp, dict):
            return False
        if resp.get("config_status") == "active":
            return True
        # Some platform versions just return success=true without
        # config_status; treat success!=False as good.
        return resp.get("success") is not False

    def setup(self, service_ids: Tuple[str, ...], *,
              base_url: str = "http://tenant-service:8092",
              safe: bool = True) -> Dict[str, bool]:
        """One-shot import + configure for many services at once.

        Returns a {service_id: ok} map so the caller can branch on
        partial setup. Doesn't raise on individual failures by default
        (safe=True); pass safe=False to surface the first error.
        """
        results: Dict[str, bool] = {}
        for svc in service_ids:
            ok = self.import_service(svc, safe=safe)
            if ok:
                ok = self.configure_service(svc, base_url=base_url, safe=safe)
            results[svc] = ok
        return results

    def _require_config(self) -> None:
        """Shared config check used by lifecycle + refs (in addition to
        execute()'s own check). Raises BadRequestError on missing config.
        """
        sl = self._sl
        if not sl.api_key:
            raise BadRequestError("SUPERO_API_KEY not set")
        if not sl.domain:
            raise BadRequestError("SUPERO_DOMAIN not set")

    def _execute_once(self, service_id: str, operation: str,
                      input_data: Dict[str, Any]) -> ServiceResult:
        """Single attempt; raises typed exceptions on any failure path."""
        sl = self._sl
        if not sl.api_key:
            raise BadRequestError(
                "SUPERO_API_KEY not set",
                service_id=service_id, operation=operation,
            )
        if not sl.domain:
            raise BadRequestError(
                "SUPERO_DOMAIN not set",
                service_id=service_id, operation=operation,
            )

        payload = {
            "service_id": service_id,
            "operation": operation,
            "input": input_data,
            "domain": sl.domain,
        }
        if sl.project_uuid:
            payload["project_uuid"] = sl.project_uuid

        http = sl._get_http()
        if http is None:
            raise PlatformError(
                "PlatformClient unavailable",
                service_id=service_id, operation=operation,
            )

        # PlatformClient.post raises on non-2xx by default. We need access
        # to the body for both shapes of error, so we call through a
        # try/except that maps the underlying client's exception family
        # to ours. Different SDK versions raise different things; we
        # introspect to pull HTTP status + body where possible.
        try:
            raw_response = http.post("/api/v1/services/execute", json=payload)
        except Exception as e:
            mapped = self._map_transport_exception(e, service_id, operation)
            if mapped is not None:
                raise mapped
            # Fallthrough — wrap as PlatformError so retry policy applies.
            raise PlatformError(
                f"Transport error: {e}",
                service_id=service_id, operation=operation,
            )

        # PlatformClient typically returns parsed JSON dict for 2xx.
        # We still defensively handle the soft-failure shape (200 + success=false).
        if not isinstance(raw_response, dict):
            raise PlatformError(
                f"Unexpected response type: {type(raw_response).__name__}",
                service_id=service_id, operation=operation, raw=raw_response,
            )

        if raw_response.get("success") is False:
            err_msg = self._extract_error(raw_response)
            raise SoftFailureError(
                err_msg, service_id=service_id, operation=operation,
                raw=raw_response,
            )

        output = raw_response.get("output")
        if output is None:
            # Some envelopes may omit the wrapper for query-only ops.
            # Treat the whole response as output if it doesn't look like
            # a standard envelope.
            if "success" not in raw_response:
                output = raw_response
            else:
                output = {}

        return ServiceResult(output, service_id, operation)

    def _map_transport_exception(self, exc: Exception,
                                  service_id: str,
                                  operation: str) -> Optional[ServiceError]:
        """Try to extract HTTP status + body from a transport exception.

        PlatformClient (and httpx/urllib under the hood) raise different
        exception types for non-2xx responses. We check for common shapes
        without taking a hard import dependency.
        """
        # Common attrs across libs: .response.status_code, .status_code,
        # .response.text, .response.json()
        status: Optional[int] = None
        body_text: str = ""
        body_json: Any = None

        resp = getattr(exc, "response", None)
        if resp is not None:
            status = getattr(resp, "status_code", None) or getattr(resp, "status", None)
            try:
                body_text = resp.text if hasattr(resp, "text") else ""
            except Exception:
                body_text = ""
            try:
                if hasattr(resp, "json"):
                    body_json = resp.json()
            except Exception:
                body_json = None
        else:
            status = getattr(exc, "status_code", None) or getattr(exc, "code", None)
            body = getattr(exc, "body", None) or getattr(exc, "response_body", None)
            if isinstance(body, (bytes, bytearray)):
                try:
                    body_text = body.decode("utf-8", errors="replace")
                except Exception:
                    body_text = ""
            elif isinstance(body, str):
                body_text = body
            elif isinstance(body, dict):
                body_json = body

        if body_json is None and body_text:
            try:
                import json as _json
                body_json = _json.loads(body_text)
            except Exception:
                body_json = None

        if status is None:
            return None  # caller will wrap as PlatformError

        # Soft failure on 200
        if status == 200 and isinstance(body_json, dict) \
                and body_json.get("success") is False:
            return SoftFailureError(
                self._extract_error(body_json),
                service_id=service_id, operation=operation,
                raw=body_json,
            )

        err_msg = ""
        if isinstance(body_json, dict):
            err_msg = body_json.get("error") or ""
        if not err_msg:
            err_msg = body_text or f"HTTP {status}"

        return _classify_error(status, err_msg, service_id, operation,
                               raw=body_json or body_text)

    @staticmethod
    def _extract_error(body: Dict[str, Any]) -> str:
        """Pull the error string from either error envelope shape."""
        if not isinstance(body, dict):
            return ""
        out = body.get("output")
        if isinstance(out, dict) and out.get("error"):
            return str(out["error"])
        if body.get("error"):
            return str(body["error"])
        return "Unknown error"

    def _sleep_backoff(self, attempt: int) -> None:
        """Jittered exponential backoff for retries.

        attempt is 1-based. Sleep ranges roughly: ~100ms, ~300ms, ~900ms.
        """
        base = self.DEFAULT_BACKOFF_BASE * (
            self.DEFAULT_BACKOFF_FACTOR ** (attempt - 1)
        )
        jittered = base * (0.7 + 0.6 * random.random())  # ±30%
        time.sleep(jittered)


# ═══════════════════════════════════════════════════════════════════
# RefClient — record-level reference operations
#
# References are first-class platform primitives, separate from inline
# attribute fields. This client wraps the canonical endpoints so apps
# don't have to construct raw HTTP for the common cases.
#
#   PUT /api/v1/crud/{domain}/ref-update
#       {type, uuid, ref-type, ref-uuid, operation: "ADD"|"DELETE"}
#
#   PUT /api/v1/crud/{domain}/ref-update-multi
#       {updates: [{type, uuid, ref-type, ref-uuid, operation}, ...]}
#
# Reads return refs as `<ref_name>_refs` keys on the record body. The
# exact key may have a namespace prefix or case variation, so the
# `find_refs` helper does a fuzzy `_refs`-suffix match.
#
# Apps using transactional services often need refs to attach catalog
# records (customer, address, product) to records under extending
# schemas. test_33_app_service_integration.py demonstrates the pattern.
#
# IMPORTANT BEHAVIORAL NOTES locked in by the e2e tests:
#  - cart.checkout_cart does NOT auto-forward references from cart to
#    the new order. Apps must re-attach refs on the order after checkout
#    via a second ref-update call. Use the `re_attach_after_checkout`
#    helper for the common case.
#  - Service ops writing base fields do NOT erase attached refs (test
#    test_op_preserves_attached_refs).
# ═══════════════════════════════════════════════════════════════════

class RefClient:
    """Client for record-level reference operations.

    Held by ServiceLib as `sl.refs`. Stateless — every call carries the
    full (source, ref_name, target) tuple.

    Methods
    -------
    add(source_type, source_uuid, ref_name, target_uuid)
        Attach a single reference. Returns the platform response dict.
    remove(source_type, source_uuid, ref_name, target_uuid)
        Detach a single reference.
    add_many(updates)
        Batch ADD via ref-update-multi.
    update_many(updates)
        Batch mixed ADD/DELETE via ref-update-multi.
    list(record, ref_name)
        Pull the refs list off a record body using fuzzy `_refs`-suffix
        match. Returns [] if not present.
    has_ref(record, ref_name, target_uuid)
        Convenience: True iff target_uuid appears in the matching refs.
    re_attach_after_checkout(cart_record, order_uuid, order_type, ref_names)
        Apply the canonical post-checkout pattern: for each ref_name
        that exists on the cart, attach the same target(s) on the new
        order.
    """

    DEFAULT_MAX_RETRIES = 3
    DEFAULT_BACKOFF_BASE = 0.1
    DEFAULT_BACKOFF_FACTOR = 3.0

    def __init__(self, service_lib):
        self._sl = service_lib

    # ── Single-reference operations ──────────────────────────────

    def add(self, source_type: str, source_uuid: str,
            ref_name: str, target_uuid: str, *,
            max_retries: Optional[int] = None,
            safe: bool = False) -> Optional[Dict[str, Any]]:
        """Attach `target_uuid` under `source.ref_name_refs`.

        ADD is idempotent: re-adding the same target is a no-op
        server-side. Retries on 502 like Cat 2 ops; never retries on 4xx.
        """
        return self._send(
            source_type, source_uuid, ref_name, target_uuid,
            "ADD", max_retries=max_retries, safe=safe,
        )

    def remove(self, source_type: str, source_uuid: str,
               ref_name: str, target_uuid: str, *,
               max_retries: Optional[int] = None,
               safe: bool = False) -> Optional[Dict[str, Any]]:
        """Detach `target_uuid` from `source.ref_name_refs`.

        DELETE is idempotent: removing an absent ref is a no-op.
        """
        return self._send(
            source_type, source_uuid, ref_name, target_uuid,
            "DELETE", max_retries=max_retries, safe=safe,
        )

    # ── Batch operations ─────────────────────────────────────────

    def add_many(self, updates: List[Dict[str, str]], *,
                 max_retries: Optional[int] = None,
                 safe: bool = False) -> Optional[Dict[str, Any]]:
        """Attach many refs in one call.

        Each update is a dict with keys: source_type, source_uuid,
        ref_name, target_uuid. The operation field is forced to "ADD".
        """
        normalized = [
            self._normalize_update(u, default_op="ADD") for u in updates
        ]
        return self._send_multi(normalized, max_retries=max_retries, safe=safe)

    def update_many(self, updates: List[Dict[str, str]], *,
                    max_retries: Optional[int] = None,
                    safe: bool = False) -> Optional[Dict[str, Any]]:
        """Mixed ADD/DELETE batch.

        Each update dict may include `operation` set to "ADD" or "DELETE";
        defaults to "ADD" if omitted.
        """
        normalized = [
            self._normalize_update(u, default_op="ADD") for u in updates
        ]
        return self._send_multi(normalized, max_retries=max_retries, safe=safe)

    # ── Read-side helpers ────────────────────────────────────────

    @staticmethod
    def list(record: Dict[str, Any], ref_name: str) -> List[Dict[str, Any]]:
        """Find a record's references by fuzzy `_refs`-suffix match.

        The platform stores references under a key like `<ref_name>_refs`
        (e.g. `customer_refs`). The exact key may have a namespace prefix
        or case variation; this matches any key ending in `_refs` whose
        name contains `ref_name` (case-insensitive). Mirrors the
        `_find_refs` helper in the e2e suite.

        Returns [] if no matching key is found.
        """
        if not isinstance(record, dict):
            return []
        fragment_low = ref_name.lower()
        # Strip namespace prefix from ref_name if present, since record
        # keys typically use the bare name (e.g. "customer_refs", not
        # "ext_app:customer_refs")
        if ":" in fragment_low:
            fragment_low = fragment_low.split(":", 1)[1]
        for key, val in record.items():
            if not isinstance(key, str):
                continue
            if key.endswith("_refs") and fragment_low in key.lower():
                if isinstance(val, list):
                    return val
        return []

    @classmethod
    def has_ref(cls, record: Dict[str, Any], ref_name: str,
                target_uuid: str) -> bool:
        """True iff `target_uuid` appears in `<ref_name>_refs` on the record."""
        return any(
            r.get("uuid") == target_uuid
            for r in cls.list(record, ref_name)
            if isinstance(r, dict)
        )

    # ── Cart→order checkout-pattern helper ───────────────────────

    def re_attach_after_checkout(self, cart_record: Dict[str, Any],
                                  order_uuid: str, order_type: str,
                                  ref_names: Tuple[str, ...], *,
                                  safe: bool = True) -> Dict[str, int]:
        """Re-attach refs on a freshly-checked-out order.

        cart.checkout_cart does NOT auto-forward references from cart to
        the new order — see test_checkout_does_NOT_auto_forward_references.
        This helper applies the canonical re-attach pattern:

          for each ref_name in ref_names:
              for each target in cart's <ref_name>_refs:
                  refs.add(order_type, order_uuid, ref_name, target.uuid)

        Returns a {ref_name: attached_count} map for verification.
        """
        results: Dict[str, int] = {}
        for ref_name in ref_names:
            targets = self.list(cart_record, ref_name)
            n = 0
            for tgt in targets:
                if not isinstance(tgt, dict):
                    continue
                tgt_uuid = tgt.get("uuid")
                if not tgt_uuid:
                    continue
                resp = self.add(order_type, order_uuid, ref_name, tgt_uuid,
                                safe=safe)
                if resp is not None:
                    n += 1
            results[ref_name] = n
        return results

    # ── Internals ────────────────────────────────────────────────

    @staticmethod
    def _normalize_update(u: Dict[str, str], *,
                          default_op: str = "ADD") -> Dict[str, str]:
        """Convert app-friendly keys to wire keys.

        App-side: source_type, source_uuid, ref_name, target_uuid, operation
        Wire:     type, uuid, ref-type, ref-uuid, operation
        """
        # Allow either form on input.
        op = u.get("operation", default_op).upper()
        if op not in ("ADD", "DELETE"):
            raise ValueError(
                f"operation must be 'ADD' or 'DELETE', got {op!r}"
            )
        src_type = u.get("type") or u.get("source_type")
        src_uuid = u.get("uuid") or u.get("source_uuid")
        ref_type = u.get("ref-type") or u.get("ref_name")
        ref_uuid = u.get("ref-uuid") or u.get("target_uuid")
        if not all([src_type, src_uuid, ref_type, ref_uuid]):
            raise ValueError(
                "ref update requires source_type, source_uuid, "
                "ref_name, target_uuid"
            )
        return {
            "type": src_type,
            "uuid": src_uuid,
            "ref-type": ref_type,
            "ref-uuid": ref_uuid,
            "operation": op,
        }

    def _send(self, source_type: str, source_uuid: str,
              ref_name: str, target_uuid: str, operation: str, *,
              max_retries: Optional[int],
              safe: bool) -> Optional[Dict[str, Any]]:
        body = {
            "type": source_type,
            "uuid": source_uuid,
            "ref-type": ref_name,
            "ref-uuid": target_uuid,
            "operation": operation,
        }
        op_label = f"ref.{operation.lower()}"
        return self._do_put(
            f"/api/v1/crud/{self._sl.domain}/ref-update",
            body, op_label,
            max_retries=max_retries, safe=safe,
        )

    def _send_multi(self, updates: List[Dict[str, str]], *,
                    max_retries: Optional[int],
                    safe: bool) -> Optional[Dict[str, Any]]:
        if not updates:
            return {"success": True, "updated": 0}
        return self._do_put(
            f"/api/v1/crud/{self._sl.domain}/ref-update-multi",
            {"updates": updates}, "ref.update_many",
            max_retries=max_retries, safe=safe,
        )

    def _do_put(self, path: str, body: Dict[str, Any], op_label: str, *,
                max_retries: Optional[int],
                safe: bool) -> Optional[Dict[str, Any]]:
        """Execute a PUT with retry-on-502 + typed-error mapping."""
        sl = self._sl
        if not sl.api_key:
            if safe:
                return None
            raise BadRequestError("SUPERO_API_KEY not set",
                                   service_id="refs", operation=op_label)
        if not sl.domain:
            if safe:
                return None
            raise BadRequestError("SUPERO_DOMAIN not set",
                                   service_id="refs", operation=op_label)

        http = sl._get_http()
        if http is None:
            if safe:
                return None
            raise PlatformError("PlatformClient unavailable",
                                 service_id="refs", operation=op_label)

        retries = (max_retries
                   if max_retries is not None
                   else self.DEFAULT_MAX_RETRIES)
        attempt = 0
        last_exc: Optional[ServiceError] = None
        while True:
            try:
                resp = http.put(path, json=body)
                if not isinstance(resp, dict):
                    return {"success": True}  # tolerate empty 200
                return resp
            except Exception as e:
                # Reuse the engine's transport-mapping logic via a
                # synthetic TransactionalClient. We don't have a tx here,
                # so mirror the introspection inline.
                mapped = _map_transport_exception_static(e, "refs", op_label)
                if mapped is None:
                    last_exc = PlatformError(
                        f"Transport error: {e}",
                        service_id="refs", operation=op_label,
                    )
                else:
                    last_exc = mapped
                # Retry only on PlatformError (502) — never on 4xx
                if not isinstance(last_exc, PlatformError):
                    break
                attempt += 1
                if attempt >= retries:
                    break
                self._sleep_backoff(attempt)
                continue

        if safe:
            sl._logger("warning", f"refs.{op_label} failed: {last_exc}")
            return None
        if last_exc is not None:
            raise last_exc
        return None

    def _sleep_backoff(self, attempt: int) -> None:
        base = self.DEFAULT_BACKOFF_BASE * (
            self.DEFAULT_BACKOFF_FACTOR ** (attempt - 1)
        )
        jittered = base * (0.7 + 0.6 * random.random())
        time.sleep(jittered)


def _map_transport_exception_static(exc: Exception,
                                     service_id: str,
                                     operation: str) -> Optional[ServiceError]:
    """Standalone version of TransactionalClient._map_transport_exception
    so RefClient can share the same exception-mapping behavior without
    needing a TransactionalClient instance.
    """
    status: Optional[int] = None
    body_text: str = ""
    body_json: Any = None

    resp = getattr(exc, "response", None)
    if resp is not None:
        status = (getattr(resp, "status_code", None)
                  or getattr(resp, "status", None))
        try:
            body_text = resp.text if hasattr(resp, "text") else ""
        except Exception:
            body_text = ""
        try:
            if hasattr(resp, "json"):
                body_json = resp.json()
        except Exception:
            body_json = None
    else:
        status = (getattr(exc, "status_code", None)
                  or getattr(exc, "code", None))
        body = (getattr(exc, "body", None)
                or getattr(exc, "response_body", None))
        if isinstance(body, (bytes, bytearray)):
            try:
                body_text = body.decode("utf-8", errors="replace")
            except Exception:
                body_text = ""
        elif isinstance(body, str):
            body_text = body
        elif isinstance(body, dict):
            body_json = body

    if body_json is None and body_text:
        try:
            import json as _json
            body_json = _json.loads(body_text)
        except Exception:
            body_json = None

    if status is None:
        return None

    if status == 200 and isinstance(body_json, dict) \
            and body_json.get("success") is False:
        out = body_json.get("output") or {}
        msg = (out.get("error") if isinstance(out, dict) else None) \
              or body_json.get("error") or "Unknown error"
        return SoftFailureError(str(msg),
                                 service_id=service_id, operation=operation,
                                 raw=body_json)

    err_msg = ""
    if isinstance(body_json, dict):
        err_msg = body_json.get("error") or ""
    if not err_msg:
        err_msg = body_text or f"HTTP {status}"

    return _classify_error(status, err_msg, service_id, operation,
                           raw=body_json or body_text)


# ═══════════════════════════════════════════════════════════════════
# Per-service accessors
#
# Each accessor is a thin facade: it knows the service_id, the per-op
# kwarg shape, and any service-specific quirks (e.g. cart.checkout_cart
# pulling from the order registry). It does NOT implement state-machine
# logic — that's the platform's job.
# ═══════════════════════════════════════════════════════════════════

class _BaseAccessor:
    """Base for per-service accessors. Holds the engine + service_id.

    Every per-op method on subclasses accepts these control kwargs in
    addition to the operation's own inputs:

      safe=True
        Swallow exceptions and return None instead of raising. Mirrors
        the fire-and-forget contract of ServiceLib.exec / .trigger.
        Default False (exceptions propagate).

      max_retries=N
        Override the engine's default retry count for Cat 1/2 ops on
        502/transport errors. Cat 3 ops never auto-retry regardless.

    All other kwargs are operation inputs — typos will surface as
    `_exec() got an unexpected keyword argument` errors.
    """

    SERVICE_ID = ""

    def __init__(self, transactional: TransactionalClient):
        self._tx = transactional

    def _exec(self, operation: str, input_data: Dict[str, Any], *,
              max_retries: Optional[int] = None,
              safe: bool = False) -> Optional[ServiceResult]:
        return self._tx.execute(
            self.SERVICE_ID, operation, input_data,
            max_retries=max_retries, safe=safe,
        )

    @staticmethod
    def _drop_none(d: Dict[str, Any]) -> Dict[str, Any]:
        """Strip None values so the wire doesn't carry empty optionals."""
        return {k: v for k, v in d.items() if v is not None}


# ──────── task ────────

class _Task(_BaseAccessor):
    SERVICE_ID = "task"

    def start(self, task_uuid: str, *,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("start_task", self._drop_none({
            "task_uuid": task_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def complete(self, task_uuid: str, *,
                 extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        return self._exec("complete_task", self._drop_none({
            "task_uuid": task_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def block(self, task_uuid: str, blocked_reason: str, *,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("block_task", self._drop_none({
            "task_uuid": task_uuid,
            "extending_schema": extending_schema,
            "blocked_reason": blocked_reason,
        }), **kwargs)

    def unblock(self, task_uuid: str, *,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("unblock_task", self._drop_none({
            "task_uuid": task_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def cancel(self, task_uuid: str, *,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("cancel_task", self._drop_none({
            "task_uuid": task_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)


# ──────── ticket ────────

class _Ticket(_BaseAccessor):
    SERVICE_ID = "ticket"

    def assign(self, ticket_uuid: str, assignee_uuid: str, *,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("assign_ticket", self._drop_none({
            "ticket_uuid": ticket_uuid,
            "extending_schema": extending_schema,
            "assignee_uuid": assignee_uuid,
        }), **kwargs)

    def resolve(self, ticket_uuid: str, *,
                resolution_notes: Optional[str] = None,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("resolve_ticket", self._drop_none({
            "ticket_uuid": ticket_uuid,
            "extending_schema": extending_schema,
            "resolution_notes": resolution_notes,
        }), **kwargs)

    def reopen(self, ticket_uuid: str, *,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("reopen_ticket", self._drop_none({
            "ticket_uuid": ticket_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def close(self, ticket_uuid: str, *,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("close_ticket", self._drop_none({
            "ticket_uuid": ticket_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def set_priority(self, ticket_uuid: str, priority: str, *,
                     extending_schema: Optional[str] = None,
                     **kwargs) -> ServiceResult:
        # Platform lowercases server-side; we don't pre-validate the value.
        return self._exec("set_priority", self._drop_none({
            "ticket_uuid": ticket_uuid,
            "extending_schema": extending_schema,
            "priority": priority,
        }), **kwargs)


# ──────── comment ────────

class _Comment(_BaseAccessor):
    SERVICE_ID = "comment"

    def edit(self, comment_uuid: str, body: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        # Cat 3 — auto-retry suppressed by engine
        return self._exec("edit_comment", self._drop_none({
            "comment_uuid": comment_uuid,
            "extending_schema": extending_schema,
            "body": body,
        }), **kwargs)

    def hide(self, comment_uuid: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("hide_comment", self._drop_none({
            "comment_uuid": comment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def show(self, comment_uuid: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("show_comment", self._drop_none({
            "comment_uuid": comment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def flag(self, comment_uuid: str, flag_reason: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        # Cat 3
        return self._exec("flag_comment", self._drop_none({
            "comment_uuid": comment_uuid,
            "extending_schema": extending_schema,
            "flag_reason": flag_reason,
        }), **kwargs)

    def soft_delete(self, comment_uuid: str, *,
                    extending_schema: Optional[str] = None,
                    **kwargs) -> ServiceResult:
        return self._exec("soft_delete_comment", self._drop_none({
            "comment_uuid": comment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def pin(self, comment_uuid: str, pinned: bool, *,
            extending_schema: Optional[str] = None,
            **kwargs) -> ServiceResult:
        # Cat 3 (no idempotency guard server-side)
        return self._exec("pin_comment", self._drop_none({
            "comment_uuid": comment_uuid,
            "extending_schema": extending_schema,
            "pinned": pinned,
        }), **kwargs)


# ──────── attachment ────────

class _Attachment(_BaseAccessor):
    SERVICE_ID = "attachment"

    def mark_uploaded(self, attachment_uuid: str, *,
                      size_bytes: Optional[int] = None,
                      checksum: Optional[str] = None,
                      extending_schema: Optional[str] = None,
                      **kwargs) -> ServiceResult:
        return self._exec("mark_uploaded", self._drop_none({
            "attachment_uuid": attachment_uuid,
            "extending_schema": extending_schema,
            "size_bytes": size_bytes,
            "checksum": checksum,
        }), **kwargs)

    def mark_scanned(self, attachment_uuid: str, scan_result: str, *,
                     extending_schema: Optional[str] = None,
                     **kwargs) -> ServiceResult:
        # Cat 3 — second call from `scanned` returns 409
        return self._exec("mark_scanned", self._drop_none({
            "attachment_uuid": attachment_uuid,
            "extending_schema": extending_schema,
            "scan_result": scan_result,
        }), **kwargs)

    def archive(self, attachment_uuid: str, *,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("archive_attachment", self._drop_none({
            "attachment_uuid": attachment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def soft_delete(self, attachment_uuid: str, *,
                    extending_schema: Optional[str] = None,
                    **kwargs) -> ServiceResult:
        return self._exec("soft_delete_attachment", self._drop_none({
            "attachment_uuid": attachment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def fail_upload(self, attachment_uuid: str, failure_reason: str, *,
                    extending_schema: Optional[str] = None,
                    **kwargs) -> ServiceResult:
        # Cat 3 — only from pending_upload; second call returns 409
        return self._exec("fail_upload", self._drop_none({
            "attachment_uuid": attachment_uuid,
            "extending_schema": extending_schema,
            "failure_reason": failure_reason,
        }), **kwargs)


# ──────── feedback ────────

class _Feedback(_BaseAccessor):
    SERVICE_ID = "feedback"

    def publish(self, feedback_uuid: str, *,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("publish_feedback", self._drop_none({
            "feedback_uuid": feedback_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def hide(self, feedback_uuid: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("hide_feedback", self._drop_none({
            "feedback_uuid": feedback_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def show(self, feedback_uuid: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("show_feedback", self._drop_none({
            "feedback_uuid": feedback_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def flag(self, feedback_uuid: str, flag_reason: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        # Cat 3
        return self._exec("flag_feedback", self._drop_none({
            "feedback_uuid": feedback_uuid,
            "extending_schema": extending_schema,
            "flag_reason": flag_reason,
        }), **kwargs)

    def mark_helpful(self, feedback_uuid: str, *,
                     extending_schema: Optional[str] = None,
                     **kwargs) -> ServiceResult:
        """Increment `helpful_count` by 1.

        ⚠️  Idempotency: Cat 3 — counter increment. Each call adds 1.
        Apps that want one-vote-per-user must dedupe externally
        (track voter UUIDs and only call once per voter). The engine
        never auto-retries this op.
        """
        return self._exec("mark_helpful", self._drop_none({
            "feedback_uuid": feedback_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)


# ──────── membership ────────

class _Membership(_BaseAccessor):
    SERVICE_ID = "membership"

    def enroll(self, membership_uuid: str, *,
               role: Optional[str] = None,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("enroll_member", self._drop_none({
            "membership_uuid": membership_uuid,
            "extending_schema": extending_schema,
            "role": role,
        }), **kwargs)

    def suspend(self, membership_uuid: str, *,
                suspension_reason: Optional[str] = None,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("suspend_member", self._drop_none({
            "membership_uuid": membership_uuid,
            "extending_schema": extending_schema,
            "suspension_reason": suspension_reason,
        }), **kwargs)

    def reinstate(self, membership_uuid: str, *,
                  extending_schema: Optional[str] = None,
                  **kwargs) -> ServiceResult:
        return self._exec("reinstate_member", self._drop_none({
            "membership_uuid": membership_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def expel(self, membership_uuid: str, *,
              expulsion_reason: Optional[str] = None,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("expel_member", self._drop_none({
            "membership_uuid": membership_uuid,
            "extending_schema": extending_schema,
            "expulsion_reason": expulsion_reason,
        }), **kwargs)

    def transfer(self, membership_uuid: str,
                 transfer_target_uuid: str, *,
                 extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        return self._exec("transfer_member", self._drop_none({
            "membership_uuid": membership_uuid,
            "extending_schema": extending_schema,
            "transfer_target_uuid": transfer_target_uuid,
        }), **kwargs)


# ──────── notification ────────

class _Notification(_BaseAccessor):
    SERVICE_ID = "notification"

    def send(self, notification_uuid: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("send_notification", self._drop_none({
            "notification_uuid": notification_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def mark_seen(self, notification_uuid: str, *,
                  extending_schema: Optional[str] = None,
                  **kwargs) -> ServiceResult:
        return self._exec("mark_seen", self._drop_none({
            "notification_uuid": notification_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def dismiss(self, notification_uuid: str, *,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("dismiss_notification", self._drop_none({
            "notification_uuid": notification_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def archive(self, notification_uuid: str, *,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("archive_notification", self._drop_none({
            "notification_uuid": notification_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def mark_all_seen(self, recipient_uuid: str, recipient_field: str, *,
                      extending_schema: Optional[str] = None,
                      **kwargs) -> ServiceResult:
        # Cat 3 (bulk)
        return self._exec("mark_all_seen", self._drop_none({
            "extending_schema": extending_schema,
            "recipient_field": recipient_field,
            "recipient_uuid": recipient_uuid,
        }), **kwargs)


# ──────── payment ────────

class _Payment(_BaseAccessor):
    SERVICE_ID = "payment"

    def authorize(self, payment_uuid: str, *,
                  external_payment_id: Optional[str] = None,
                  extending_schema: Optional[str] = None,
                  **kwargs) -> ServiceResult:
        return self._exec("authorize_payment", self._drop_none({
            "payment_uuid": payment_uuid,
            "extending_schema": extending_schema,
            "external_payment_id": external_payment_id,
        }), **kwargs)

    def capture(self, payment_uuid: str, *,
                external_charge_id: Optional[str] = None,
                capture_amount: Optional[float] = None,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("capture_payment", self._drop_none({
            "payment_uuid": payment_uuid,
            "extending_schema": extending_schema,
            "external_charge_id": external_charge_id,
            "capture_amount": capture_amount,
        }), **kwargs)

    def refund(self, payment_uuid: str, *,
               refund_amount: Optional[float] = None,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        """Refund a captured payment, full or partial.

        ⚠️  Idempotency: Cat 3 — CUMULATIVE. Each call adds `refund_amount`
        (or the remaining balance) to the cumulative refunded total.
        Two calls with `refund_amount=30` yield $60 refunded, not $30.
        The engine refuses to auto-retry this op on 502; if a 502 occurs,
        check the gateway/record before retrying.
        """
        return self._exec("refund_payment", self._drop_none({
            "payment_uuid": payment_uuid,
            "extending_schema": extending_schema,
            "refund_amount": refund_amount,
        }), **kwargs)

    def void(self, payment_uuid: str, *,
             reason: Optional[str] = None,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("void_payment", self._drop_none({
            "payment_uuid": payment_uuid,
            "extending_schema": extending_schema,
            "reason": reason,
        }), **kwargs)

    def fail(self, payment_uuid: str, failure_reason: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("fail_payment", self._drop_none({
            "payment_uuid": payment_uuid,
            "extending_schema": extending_schema,
            "failure_reason": failure_reason,
        }), **kwargs)


# ──────── cart ────────

class _Cart(_BaseAccessor):
    SERVICE_ID = "cart"

    def checkout(self, cart_uuid: str, *,
                 extending_schema: Optional[str] = None,
                 cart_item_extending_schema: Optional[str] = None,
                 order_extending_schema: Optional[str] = None,
                 order_item_extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        # The order_*_extending_schema kwargs auto-fill from the order
        # registry via _inject_extensions when missing.
        return self._exec("checkout_cart", self._drop_none({
            "cart_uuid": cart_uuid,
            "extending_schema": extending_schema,
            "cart_item_extending_schema": cart_item_extending_schema,
            "order_extending_schema": order_extending_schema,
            "order_item_extending_schema": order_item_extending_schema,
        }), **kwargs)

    def abandon(self, cart_uuid: str, *,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("abandon_cart", self._drop_none({
            "cart_uuid": cart_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def expire(self, cart_uuid: str, *,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("expire_cart", self._drop_none({
            "cart_uuid": cart_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def recompute_totals(self, cart_uuid: str, *,
                         extending_schema: Optional[str] = None,
                         cart_item_extending_schema: Optional[str] = None,
                         **kwargs) -> ServiceResult:
        return self._exec("recompute_totals", self._drop_none({
            "cart_uuid": cart_uuid,
            "extending_schema": extending_schema,
            "cart_item_extending_schema": cart_item_extending_schema,
        }), **kwargs)


# ──────── order ────────

class _Order(_BaseAccessor):
    SERVICE_ID = "order"

    def place(self, order_uuid: str, *,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("place_order", self._drop_none({
            "order_uuid": order_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def fulfill(self, order_uuid: str, *,
                fulfillment_notes: Optional[str] = None,
                extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("fulfill_order", self._drop_none({
            "order_uuid": order_uuid,
            "extending_schema": extending_schema,
            "fulfillment_notes": fulfillment_notes,
        }), **kwargs)

    def cancel(self, order_uuid: str, *,
               cancellation_reason: Optional[str] = None,
               extending_schema: Optional[str] = None,
               order_item_extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("cancel_order", self._drop_none({
            "order_uuid": order_uuid,
            "extending_schema": extending_schema,
            "order_item_extending_schema": order_item_extending_schema,
            "cancellation_reason": cancellation_reason,
        }), **kwargs)

    def recompute_totals(self, order_uuid: str, *,
                         extending_schema: Optional[str] = None,
                         order_item_extending_schema: Optional[str] = None,
                         **kwargs) -> ServiceResult:
        return self._exec("recompute_order_totals", self._drop_none({
            "order_uuid": order_uuid,
            "extending_schema": extending_schema,
            "order_item_extending_schema": order_item_extending_schema,
        }), **kwargs)


# ──────── booking ────────

class _Booking(_BaseAccessor):
    SERVICE_ID = "booking"

    def book(self, booking_uuid: str, *,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("book_slot", self._drop_none({
            "booking_uuid": booking_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def cancel(self, booking_uuid: str, *,
               cancellation_reason: Optional[str] = None,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("cancel_booking", self._drop_none({
            "booking_uuid": booking_uuid,
            "extending_schema": extending_schema,
            "cancellation_reason": cancellation_reason,
        }), **kwargs)

    def reschedule(self, booking_uuid: str, start_time: str, end_time: str, *,
                   extending_schema: Optional[str] = None,
                   **kwargs) -> ServiceResult:
        return self._exec("reschedule_booking", self._drop_none({
            "booking_uuid": booking_uuid,
            "extending_schema": extending_schema,
            "start_time": start_time,
            "end_time": end_time,
        }), **kwargs)

    def complete(self, booking_uuid: str, *,
                 extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        return self._exec("complete_booking", self._drop_none({
            "booking_uuid": booking_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def check_availability(self, resource_uuid: str, resource_field: str,
                           start_time: str, end_time: str, *,
                           exclude_booking_uuid: Optional[str] = None,
                           extending_schema: Optional[str] = None,
                           **kwargs) -> ServiceResult:
        # Query-only — no idempotency category, no state mutation.
        return self._exec("check_availability", self._drop_none({
            "extending_schema": extending_schema,
            "resource_field": resource_field,
            "resource_uuid": resource_uuid,
            "start_time": start_time,
            "end_time": end_time,
            "exclude_booking_uuid": exclude_booking_uuid,
        }), **kwargs)


# ──────── appointment ────────

class _Appointment(_BaseAccessor):
    SERVICE_ID = "appointment"

    def schedule(self, appointment_uuid: str, *,
                 extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        return self._exec("schedule_appointment", self._drop_none({
            "appointment_uuid": appointment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def cancel(self, appointment_uuid: str, *,
               cancellation_reason: Optional[str] = None,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("cancel_appointment", self._drop_none({
            "appointment_uuid": appointment_uuid,
            "extending_schema": extending_schema,
            "cancellation_reason": cancellation_reason,
        }), **kwargs)

    def reschedule(self, appointment_uuid: str,
                   start_time: str, end_time: str, *,
                   extending_schema: Optional[str] = None,
                   **kwargs) -> ServiceResult:
        return self._exec("reschedule_appointment", self._drop_none({
            "appointment_uuid": appointment_uuid,
            "extending_schema": extending_schema,
            "start_time": start_time,
            "end_time": end_time,
        }), **kwargs)

    def complete(self, appointment_uuid: str, *,
                 notes: Optional[str] = None,
                 extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        return self._exec("complete_appointment", self._drop_none({
            "appointment_uuid": appointment_uuid,
            "extending_schema": extending_schema,
            "notes": notes,
        }), **kwargs)

    def mark_no_show(self, appointment_uuid: str, *,
                     extending_schema: Optional[str] = None,
                     **kwargs) -> ServiceResult:
        return self._exec("mark_no_show", self._drop_none({
            "appointment_uuid": appointment_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def check_provider_availability(self, resource_uuid: str,
                                    resource_field: str,
                                    start_time: str, end_time: str, *,
                                    exclude_appointment_uuid: Optional[str] = None,
                                    extending_schema: Optional[str] = None,
                                    **kwargs) -> ServiceResult:
        return self._exec("check_provider_availability", self._drop_none({
            "extending_schema": extending_schema,
            "resource_field": resource_field,
            "resource_uuid": resource_uuid,
            "start_time": start_time,
            "end_time": end_time,
            "exclude_appointment_uuid": exclude_appointment_uuid,
        }), **kwargs)


# ──────── recurring_plan ────────

class _RecurringPlan(_BaseAccessor):
    SERVICE_ID = "recurring_plan"

    def start(self, plan_uuid: str, *,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("start_plan", self._drop_none({
            "plan_uuid": plan_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def pause(self, plan_uuid: str, *,
              extending_schema: Optional[str] = None,
              **kwargs) -> ServiceResult:
        return self._exec("pause_plan", self._drop_none({
            "plan_uuid": plan_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def resume(self, plan_uuid: str, *,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("resume_plan", self._drop_none({
            "plan_uuid": plan_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)

    def cancel(self, plan_uuid: str, *,
               cancellation_reason: Optional[str] = None,
               immediate: bool = False,
               extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("cancel_plan", self._drop_none({
            "plan_uuid": plan_uuid,
            "extending_schema": extending_schema,
            "cancellation_reason": cancellation_reason,
            "immediate": immediate,
        }), **kwargs)

    def renew_period(self, plan_uuid: str, *,
                     extending_schema: Optional[str] = None,
                     **kwargs) -> ServiceResult:
        """Roll the billing period forward by one interval.

        ⚠️  Idempotency: Cat 3 — HIGHLY DANGEROUS to retry. Each successful
        call advances `current_period_start`/`end` by one interval.
        Two retries advance billing by 2 intervals — the customer would
        be billed one period less than they should be. The engine never
        auto-retries this op. If the response was lost, read the plan
        record's period boundaries to determine whether renewal occurred.

        Special case: if `cancel_plan(immediate=False)` was previously
        called, this op transitions the plan to `cancelled` instead of
        rolling forward (returns reason="cancellation_took_effect").
        """
        return self._exec("renew_period", self._drop_none({
            "plan_uuid": plan_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)


# ──────── approval ────────

class _Approval(_BaseAccessor):
    SERVICE_ID = "approval"

    def submit(self, approval_uuid: str, *,
               extending_schema: Optional[str] = None,
               step_extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("submit_approval", self._drop_none({
            "approval_uuid": approval_uuid,
            "extending_schema": extending_schema,
            "step_extending_schema": step_extending_schema,
        }), **kwargs)

    def approve_step(self, approval_uuid: str, *,
                     decision_notes: Optional[str] = None,
                     extending_schema: Optional[str] = None,
                     step_extending_schema: Optional[str] = None,
                     **kwargs) -> ServiceResult:
        """Approve the current step (1-based pointer).

        ⚠️  Idempotency: Cat 3 — advances `current_step` by 1. A retry
        after a successful (but lost-response) call may approve the
        next step too, with empty notes. The engine never auto-retries.
        If the response was lost, read the approval and step records
        before retrying.
        """
        return self._exec("approve_step", self._drop_none({
            "approval_uuid": approval_uuid,
            "extending_schema": extending_schema,
            "step_extending_schema": step_extending_schema,
            "decision_notes": decision_notes,
        }), **kwargs)

    def reject_step(self, approval_uuid: str, *,
                    decision_notes: Optional[str] = None,
                    extending_schema: Optional[str] = None,
                    step_extending_schema: Optional[str] = None,
                    **kwargs) -> ServiceResult:
        # Cat 3
        return self._exec("reject_step", self._drop_none({
            "approval_uuid": approval_uuid,
            "extending_schema": extending_schema,
            "step_extending_schema": step_extending_schema,
            "decision_notes": decision_notes,
        }), **kwargs)

    def delegate_step(self, approval_uuid: str,
                      delegated_to_uuid: str, *,
                      extending_schema: Optional[str] = None,
                      step_extending_schema: Optional[str] = None,
                      **kwargs) -> ServiceResult:
        # Cat 3 — overwrites delegated_to_uuid.
        return self._exec("delegate_step", self._drop_none({
            "approval_uuid": approval_uuid,
            "extending_schema": extending_schema,
            "step_extending_schema": step_extending_schema,
            "delegated_to_uuid": delegated_to_uuid,
        }), **kwargs)

    def withdraw(self, approval_uuid: str, *,
                 extending_schema: Optional[str] = None,
                 **kwargs) -> ServiceResult:
        return self._exec("withdraw_approval", self._drop_none({
            "approval_uuid": approval_uuid,
            "extending_schema": extending_schema,
        }), **kwargs)


# ──────── inventory ────────

class _Inventory(_BaseAccessor):
    SERVICE_ID = "inventory"

    def reserve(self, reservation_uuid: str, *,
                extending_schema: Optional[str] = None,
                inventory_extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        """Hold inventory for a reservation. `extending_schema` is the
        RESERVATION schema; `inventory_extending_schema` is the inventory
        schema. Both auto-fill from the registry if registered."""
        return self._exec("reserve_stock", self._drop_none({
            "reservation_uuid": reservation_uuid,
            "extending_schema": extending_schema,
            "inventory_extending_schema": inventory_extending_schema,
        }), **kwargs)

    def commit(self, reservation_uuid: str, *,
               extending_schema: Optional[str] = None,
               inventory_extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        """Commit (ship) a held reservation, decrementing total stock."""
        return self._exec("commit_reservation", self._drop_none({
            "reservation_uuid": reservation_uuid,
            "extending_schema": extending_schema,
            "inventory_extending_schema": inventory_extending_schema,
        }), **kwargs)

    def release(self, reservation_uuid: str, *,
                extending_schema: Optional[str] = None,
                inventory_extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        """Release a held reservation back to available stock."""
        return self._exec("release_reservation", self._drop_none({
            "reservation_uuid": reservation_uuid,
            "extending_schema": extending_schema,
            "inventory_extending_schema": inventory_extending_schema,
        }), **kwargs)

    def adjust_quantity(self, inventory_uuid: str, delta: int, *,
                        extending_schema: Optional[str] = None,
                        **kwargs) -> ServiceResult:
        """Restock (positive delta) or write off (negative delta).

        Cat 3 — DELTA-BASED, never auto-retried by the engine.
        `extending_schema` is the INVENTORY schema (not reservation).
        """
        return self._exec("adjust_quantity", self._drop_none({
            "inventory_uuid": inventory_uuid,
            "extending_schema": extending_schema,
            "delta": delta,
        }), **kwargs)


# ──────── loyalty_points ────────

class _LoyaltyPoints(_BaseAccessor):
    SERVICE_ID = "loyalty_points"

    def accrue(self, txn_uuid: str, *,
               txn_extending_schema: Optional[str] = None,
               account_extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("accrue_points", self._drop_none({
            "txn_uuid": txn_uuid,
            "txn_extending_schema": txn_extending_schema,
            "account_extending_schema": account_extending_schema,
        }), **kwargs)

    def redeem(self, txn_uuid: str, *,
               txn_extending_schema: Optional[str] = None,
               account_extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("redeem_points", self._drop_none({
            "txn_uuid": txn_uuid,
            "txn_extending_schema": txn_extending_schema,
            "account_extending_schema": account_extending_schema,
        }), **kwargs)

    def expire(self, txn_uuid: str, *,
               txn_extending_schema: Optional[str] = None,
               account_extending_schema: Optional[str] = None,
               **kwargs) -> ServiceResult:
        return self._exec("expire_points", self._drop_none({
            "txn_uuid": txn_uuid,
            "txn_extending_schema": txn_extending_schema,
            "account_extending_schema": account_extending_schema,
        }), **kwargs)

    def reverse(self, txn_uuid: str, *,
                txn_extending_schema: Optional[str] = None,
                account_extending_schema: Optional[str] = None,
                **kwargs) -> ServiceResult:
        return self._exec("reverse_txn", self._drop_none({
            "txn_uuid": txn_uuid,
            "txn_extending_schema": txn_extending_schema,
            "account_extending_schema": account_extending_schema,
        }), **kwargs)


# ──────── document_signature ────────

class _DocumentSignature(_BaseAccessor):
    SERVICE_ID = "document_signature"

    def request_signatures(self, document_uuid: str, *,
                           extending_schema: Optional[str] = None,
                           signature_extending_schema: Optional[str] = None,
                           **kwargs) -> ServiceResult:
        return self._exec("request_signatures", self._drop_none({
            "document_uuid": document_uuid,
            "extending_schema": extending_schema,
            "signature_extending_schema": signature_extending_schema,
        }), **kwargs)

    def sign(self, signature_uuid: str, *,
             signature_data: Optional[str] = None,
             ip_address: Optional[str] = None,
             extending_schema: Optional[str] = None,
             signature_extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("sign_document", self._drop_none({
            "signature_uuid": signature_uuid,
            "extending_schema": extending_schema,
            "signature_extending_schema": signature_extending_schema,
            "signature_data": signature_data,
            "ip_address": ip_address,
        }), **kwargs)

    def decline_signature(self, signature_uuid: str, *,
                          decline_reason: Optional[str] = None,
                          extending_schema: Optional[str] = None,
                          signature_extending_schema: Optional[str] = None,
                          **kwargs) -> ServiceResult:
        return self._exec("decline_signature", self._drop_none({
            "signature_uuid": signature_uuid,
            "extending_schema": extending_schema,
            "signature_extending_schema": signature_extending_schema,
            "decline_reason": decline_reason,
        }), **kwargs)

    def void(self, document_uuid: str, *,
             void_reason: Optional[str] = None,
             extending_schema: Optional[str] = None,
             **kwargs) -> ServiceResult:
        return self._exec("void_document", self._drop_none({
            "document_uuid": document_uuid,
            "extending_schema": extending_schema,
            "void_reason": void_reason,
        }), **kwargs)


# ═══════════════════════════════════════════════════════════════════
# Public bindings — what ServiceLib hangs on itself
# ═══════════════════════════════════════════════════════════════════

# Map of (attr_name, accessor_class). ServiceLib uses this to lazy-bind
# all transactional accessors in one go.
TRANSACTIONAL_ACCESSORS = (
    ("task",                _Task),
    ("ticket",              _Ticket),
    ("comment",             _Comment),
    ("attachment",          _Attachment),
    ("feedback",            _Feedback),
    ("membership",          _Membership),
    ("notification",        _Notification),
    ("payment",             _Payment),
    ("cart",                _Cart),
    ("order",               _Order),
    ("booking",             _Booking),
    ("appointment",         _Appointment),
    ("recurring_plan",      _RecurringPlan),
    ("approval",            _Approval),
    ("inventory",           _Inventory),
    ("loyalty_points",      _LoyaltyPoints),
    ("document_signature",  _DocumentSignature),
)


__all__ = [
    "TransactionalClient",
    "RefClient",
    "ServiceResult",
    "ServiceError",
    "BadRequestError",
    "NotFoundError",
    "StateConflictError",
    "PlatformError",
    "SoftFailureError",
    "TRANSACTIONAL_ACCESSORS",
]
