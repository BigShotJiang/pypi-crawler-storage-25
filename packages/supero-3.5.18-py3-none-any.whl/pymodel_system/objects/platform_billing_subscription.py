# File: pymodel_system/objects/platform_billing_subscription.py
"""
This file was generated from the PlatformBillingSubscription.json schema.
ENHANCED: Proper datetime handling with automatic string<->datetime conversion.
ENHANCED: Supero fluent API support with smart reference management.
"""

from typing import List, Dict, Any, Optional, TYPE_CHECKING
import importlib
import uuid
import inflection
from pymodel_system.enums.billing_plan_types import BillingPlanTypes
from datetime import datetime

if TYPE_CHECKING:
    from pymodel_system.objects.billing_contract import BillingContract

from ..serialization_errors import ObjectDeserializationError, InvalidParentError
from datetime import datetime
import re

class PlatformBillingSubscription:
    """
    Represents a PlatformBillingSubscription instance.
    
    This class is auto-generated and includes:
    - Standard CRUD operations
    - Fluent API methods (when used with Supero)
    - Smart reference management with link data support
    - Parent-child hierarchy navigation
    """
    
    _OBJ_TYPE = "platform_billing_subscription"
    _PARENT_TYPE = "domain"
    _NAMESPACE = None

    # Type metadata for deserialization
    _type_metadata = {
    'name': {
        'type': 'str',
        'is_list': False,
        'json_name': 'name',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'uuid': {
        'type': 'str',
        'is_list': False,
        'json_name': 'uuid',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'fq_name': {
        'type': 'str',
        'is_list': True,
        'json_name': 'fq_name',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'parent_type': {
        'type': 'str',
        'is_list': False,
        'json_name': 'parent_type',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': True,
    },
    'parent_uuid': {
        'type': 'str',
        'is_list': False,
        'json_name': 'parent_uuid',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'obj_type': {
        'type': 'str',
        'is_list': False,
        'json_name': 'obj_type',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': True,
    },
    'display_name': {
        'type': 'str',
        'is_list': False,
        'json_name': 'display_name',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'description': {
        'type': 'str',
        'is_list': False,
        'json_name': 'description',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'created_by': {
        'type': 'str',
        'is_list': False,
        'json_name': 'created_by',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'created_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'created_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'updated_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'updated_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'plan_code': {
        'type': 'BillingPlanTypes',
        'is_list': False,
        'json_name': 'plan_code',
        'original_type': 'BillingPlanTypes',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'plan_version': {
        'type': 'int',
        'is_list': False,
        'json_name': 'plan_version',
        'original_type': 'integer',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'status': {
        'type': 'str',
        'is_list': False,
        'json_name': 'status',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'subscription_type': {
        'type': 'str',
        'is_list': False,
        'json_name': 'subscription_type',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'billing_cycle': {
        'type': 'str',
        'is_list': False,
        'json_name': 'billing_cycle',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'pricing_currency': {
        'type': 'str',
        'is_list': False,
        'json_name': 'pricing_currency',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'current_period_start': {
        'type': 'str',
        'is_list': False,
        'json_name': 'current_period_start',
        'original_type': 'datetime',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'current_period_end': {
        'type': 'str',
        'is_list': False,
        'json_name': 'current_period_end',
        'original_type': 'datetime',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'trial_start': {
        'type': 'str',
        'is_list': False,
        'json_name': 'trial_start',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'trial_end': {
        'type': 'str',
        'is_list': False,
        'json_name': 'trial_end',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'activated_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'activated_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'canceled_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'canceled_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'cancel_at_period_end': {
        'type': 'bool',
        'is_list': False,
        'json_name': 'cancel_at_period_end',
        'original_type': 'bool',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'cancel_reason': {
        'type': 'str',
        'is_list': False,
        'json_name': 'cancel_reason',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'cancel_feedback': {
        'type': 'str',
        'is_list': False,
        'json_name': 'cancel_feedback',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'quantity': {
        'type': 'int',
        'is_list': False,
        'json_name': 'quantity',
        'original_type': 'integer',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'discount_percent': {
        'type': 'float',
        'is_list': False,
        'json_name': 'discount_percent',
        'original_type': 'float',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'discount_code': {
        'type': 'str',
        'is_list': False,
        'json_name': 'discount_code',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'discount_expires_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'discount_expires_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'overage_handling_override': {
        'type': 'str',
        'is_list': False,
        'json_name': 'overage_handling_override',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'limit_overrides': {
        'type': 'dict',
        'is_list': False,
        'json_name': 'limit_overrides',
        'original_type': 'json',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'grandfathered_limits': {
        'type': 'dict',
        'is_list': False,
        'json_name': 'grandfathered_limits',
        'original_type': 'json',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'stripe_customer_id': {
        'type': 'str',
        'is_list': False,
        'json_name': 'stripe_customer_id',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'stripe_subscription_id': {
        'type': 'str',
        'is_list': False,
        'json_name': 'stripe_subscription_id',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'stripe_price_id': {
        'type': 'str',
        'is_list': False,
        'json_name': 'stripe_price_id',
        'original_type': 'string',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'payment_provider': {
        'type': 'str',
        'is_list': False,
        'json_name': 'payment_provider',
        'original_type': 'string',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'auto_renew': {
        'type': 'bool',
        'is_list': False,
        'json_name': 'auto_renew',
        'original_type': 'bool',
        'mandatory': True,
        'derived': False,
        'static': False,
    },
    'payment_failed_count': {
        'type': 'int',
        'is_list': False,
        'json_name': 'payment_failed_count',
        'original_type': 'integer',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'grace_period_end': {
        'type': 'str',
        'is_list': False,
        'json_name': 'grace_period_end',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'last_invoice_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'last_invoice_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'next_invoice_at': {
        'type': 'str',
        'is_list': False,
        'json_name': 'next_invoice_at',
        'original_type': 'datetime',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'lifetime_value_cents': {
        'type': 'int',
        'is_list': False,
        'json_name': 'lifetime_value_cents',
        'original_type': 'integer',
        'mandatory': False,
        'derived': False,
        'static': False,
    },
    'metadata': {
        'type': 'dict',
        'is_list': False,
        'json_name': 'metadata',
        'original_type': 'json',
        'mandatory': False,
        'derived': False,
        'static': False,
    }
}
    
    # Infrastructure end_points metadata
    _end_points = []
    
    # Index definitions
    _indexes = {}

    _CONSTRAINTS = {
        'plan_version': {
            'min-value': 1,
            'type': 'integer',
        },
        'quantity': {
            'min-value': 1,
            'type': 'integer',
        },
        'discount_percent': {
            'min-value': 0,
            'max-value': 100,
            'type': 'float',
        },
        'payment_failed_count': {
            'min-value': 0,
            'type': 'integer',
        }
    }

    # v3.7: schema-declared derive config — { py_attr: {from: [...], separator: ':'} }
    # Empty dict if no attribute declares derivation. The SDK uses this to fill in
    # missing values (like `name`) before serialization, mirroring the server's
    # compute_name precedence so downstream consumers always see a complete dict.
    _DERIVE_CONFIG = {}

    # Supero context (set by Supero wrapper)
    _supero_context = None

    @staticmethod
    def _normalize_name(name: str) -> str:
        """ 
        Normalize object/domain name to lowercase with preserved special characters.
        
        SPECIAL CASES (preserved as-is, only lowercased):
        - Email addresses (valid format: user@domain)
        - Phone numbers (start with + or are digit-heavy)
        
        For regular names:
        - Converts to lowercase
        - Allows: alphanumeric, hyphen (-), dot (.), underscore (_)
        - Replaces spaces and other chars with hyphen
        - Collapses multiple separators
        
        Args:
            name: Raw name (e.g., "Acme Corporation", "user@example.com", "+1-555-1234")
        
        Returns:
            Normalized name or preserved special format
            
        Examples:
            >>> normalize_name("Acme Corporation")
            'acme-corporation'
            >>> normalize_name("My_Project.Name")
            'my-project.name'
            >>> normalize_name("user@example.com")
            'user@example.com'
            >>> normalize_name("+1-555-1234")
            '+1-555-1234'
            >>> normalize_name("platform-admin@system.com")
            'platform-admin@system.com'
            >>> normalize_name("@@@")
            ''
        """
        if not name or not isinstance(name, str):
            return name
        
        # Strip whitespace
        name = name.strip()
        
        # SPECIAL CASE 1: Email addresses (valid format)
        # Must have: one @, something before @, something after @
        if '@' in name:
            parts = name.split('@')
            # Valid email: exactly one @, non-empty local and domain parts
            if len(parts) == 2 and parts[0] and parts[1]:
                # Additional check: domain should have at least one char
                # (could be "localhost" or "example.com")
                return name.lower()
            # Invalid email format - fall through to normal normalization
        
        # SPECIAL CASE 2: Phone numbers (starts with + or is digit-heavy)
        # Preserve as-is (including formatting)
        if name.startswith('+'):
            return name
        
        # Check if digit-heavy (>50% digits) - likely a phone number
        if len(name) > 0:
            digit_ratio = sum(c.isdigit() for c in name) / len(name)
            if digit_ratio > 0.5:
                return name
        
        # REGULAR NAME: Apply normalization
        # Convert to lowercase
        name = name.lower()
        
        # Allow: alphanumeric, hyphen, dot, underscore
        # Replace spaces and other special chars with hyphen
        name = re.sub(r'[^a-z0-9._:-]+', '-', name)
        
        # Collapse multiple consecutive separators to single hyphen
        name = re.sub(r'[-_.]{2,}', '-', name)
        
        # Strip leading/trailing separators
        name = name.strip('-._')
        
        return name

    def __init__(
        self,
        name: str,
        uuid: Optional[str] = None,
        fq_name: Optional[List[str]] = None,
        parent_uuid: Optional[str] = None,
        display_name: Optional[str] = None,
        description: Optional[str] = None,
        created_by: Optional[str] = None,
        created_at: Optional[str] = None,
        updated_at: Optional[str] = None,
        plan_code: Optional[BillingPlanTypes] = None,
        plan_version: Optional[int] = None,
        status: Optional[str] = None,
        subscription_type: Optional[str] = None,
        billing_cycle: Optional[str] = None,
        pricing_currency: Optional[str] = None,
        current_period_start: Optional[str] = None,
        current_period_end: Optional[str] = None,
        trial_start: Optional[str] = None,
        trial_end: Optional[str] = None,
        activated_at: Optional[str] = None,
        canceled_at: Optional[str] = None,
        cancel_at_period_end: Optional[bool] = None,
        cancel_reason: Optional[str] = None,
        cancel_feedback: Optional[str] = None,
        quantity: Optional[int] = None,
        discount_percent: Optional[float] = None,
        discount_code: Optional[str] = None,
        discount_expires_at: Optional[str] = None,
        overage_handling_override: Optional[str] = None,
        limit_overrides: Optional[dict] = None,
        grandfathered_limits: Optional[dict] = None,
        stripe_customer_id: Optional[str] = None,
        stripe_subscription_id: Optional[str] = None,
        stripe_price_id: Optional[str] = None,
        payment_provider: Optional[str] = None,
        auto_renew: Optional[bool] = None,
        payment_failed_count: Optional[int] = None,
        grace_period_end: Optional[str] = None,
        last_invoice_at: Optional[str] = None,
        next_invoice_at: Optional[str] = None,
        lifetime_value_cents: Optional[int] = None,
        metadata: Optional[dict] = None,
        billing_contract_refs: List[Dict[str, Any]] = None
    ):
        # Set initialization flag to prevent tracking during __init__
        self._initializing = True
        
        self.obj_type = "platform_billing_subscription"
        self.parent_type = "domain"
        self._py_to_json_map = {
    'name': 'name',
    'uuid': 'uuid',
    'fq_name': 'fq_name',
    'parent_type': 'parent_type',
    'parent_uuid': 'parent_uuid',
    'obj_type': 'obj_type',
    'display_name': 'display_name',
    'description': 'description',
    'created_by': 'created_by',
    'created_at': 'created_at',
    'updated_at': 'updated_at',
    'plan_code': 'plan_code',
    'plan_version': 'plan_version',
    'status': 'status',
    'subscription_type': 'subscription_type',
    'billing_cycle': 'billing_cycle',
    'pricing_currency': 'pricing_currency',
    'current_period_start': 'current_period_start',
    'current_period_end': 'current_period_end',
    'trial_start': 'trial_start',
    'trial_end': 'trial_end',
    'activated_at': 'activated_at',
    'canceled_at': 'canceled_at',
    'cancel_at_period_end': 'cancel_at_period_end',
    'cancel_reason': 'cancel_reason',
    'cancel_feedback': 'cancel_feedback',
    'quantity': 'quantity',
    'discount_percent': 'discount_percent',
    'discount_code': 'discount_code',
    'discount_expires_at': 'discount_expires_at',
    'overage_handling_override': 'overage_handling_override',
    'limit_overrides': 'limit_overrides',
    'grandfathered_limits': 'grandfathered_limits',
    'stripe_customer_id': 'stripe_customer_id',
    'stripe_subscription_id': 'stripe_subscription_id',
    'stripe_price_id': 'stripe_price_id',
    'payment_provider': 'payment_provider',
    'auto_renew': 'auto_renew',
    'payment_failed_count': 'payment_failed_count',
    'grace_period_end': 'grace_period_end',
    'last_invoice_at': 'last_invoice_at',
    'next_invoice_at': 'next_invoice_at',
    'lifetime_value_cents': 'lifetime_value_cents',
    'metadata': 'metadata',
    'billing_contract_refs': 'billing_contract_refs'
}
        self._json_to_py_map = {
    'name': 'name',
    'uuid': 'uuid',
    'fq_name': 'fq_name',
    'parent_type': 'parent_type',
    'parent_uuid': 'parent_uuid',
    'obj_type': 'obj_type',
    'display_name': 'display_name',
    'description': 'description',
    'created_by': 'created_by',
    'created_at': 'created_at',
    'updated_at': 'updated_at',
    'plan_code': 'plan_code',
    'plan_version': 'plan_version',
    'status': 'status',
    'subscription_type': 'subscription_type',
    'billing_cycle': 'billing_cycle',
    'pricing_currency': 'pricing_currency',
    'current_period_start': 'current_period_start',
    'current_period_end': 'current_period_end',
    'trial_start': 'trial_start',
    'trial_end': 'trial_end',
    'activated_at': 'activated_at',
    'canceled_at': 'canceled_at',
    'cancel_at_period_end': 'cancel_at_period_end',
    'cancel_reason': 'cancel_reason',
    'cancel_feedback': 'cancel_feedback',
    'quantity': 'quantity',
    'discount_percent': 'discount_percent',
    'discount_code': 'discount_code',
    'discount_expires_at': 'discount_expires_at',
    'overage_handling_override': 'overage_handling_override',
    'limit_overrides': 'limit_overrides',
    'grandfathered_limits': 'grandfathered_limits',
    'stripe_customer_id': 'stripe_customer_id',
    'stripe_subscription_id': 'stripe_subscription_id',
    'stripe_price_id': 'stripe_price_id',
    'payment_provider': 'payment_provider',
    'auto_renew': 'auto_renew',
    'payment_failed_count': 'payment_failed_count',
    'grace_period_end': 'grace_period_end',
    'last_invoice_at': 'last_invoice_at',
    'next_invoice_at': 'next_invoice_at',
    'lifetime_value_cents': 'lifetime_value_cents',
    'metadata': 'metadata',
    'billing_contract_refs': 'billing_contract_refs'
}
        self._pending_field_updates = set()

        # ========================================================================
        # CRITICAL: Handle 'name' and 'display_name' BEFORE other attributes
        # This ensures we capture the original name before normalization
        # ========================================================================
        
        # Step 1: Store the original user-provided name (before normalization)
        _original_name = name
        
        # Step 2: Normalize the name for database consistency
        self.name = self._normalize_name(name) if name else name
        
        # Step 3: Set display_name
        if display_name is not None:
            self.display_name = display_name
        elif _original_name is not None:
            self.display_name = _original_name  # ✅ Preserve original formatting!
        else:
            self.display_name = None
        
        # Step 4: Set all other attributes (excluding name and display_name)
        
        self.uuid = uuid
        self.fq_name = fq_name if fq_name is not None else []
        self.parent_uuid = parent_uuid
        self.description = description
        self.created_by = created_by
        self.created_at = created_at
        self.updated_at = updated_at
        self.plan_code = plan_code
        self.plan_version = plan_version
        self.status = status
        self.subscription_type = subscription_type
        self.billing_cycle = billing_cycle
        self.pricing_currency = pricing_currency
        self.current_period_start = current_period_start
        self.current_period_end = current_period_end
        self.trial_start = trial_start
        self.trial_end = trial_end
        self.activated_at = activated_at
        self.canceled_at = canceled_at
        self.cancel_at_period_end = cancel_at_period_end
        self.cancel_reason = cancel_reason
        self.cancel_feedback = cancel_feedback
        self.quantity = quantity
        self.discount_percent = discount_percent
        self.discount_code = discount_code
        self.discount_expires_at = discount_expires_at
        self.overage_handling_override = overage_handling_override
        self.limit_overrides = limit_overrides
        self.grandfathered_limits = grandfathered_limits
        self.stripe_customer_id = stripe_customer_id
        self.stripe_subscription_id = stripe_subscription_id
        self.stripe_price_id = stripe_price_id
        self.payment_provider = payment_provider
        self.auto_renew = auto_renew
        self.payment_failed_count = payment_failed_count
        self.grace_period_end = grace_period_end
        self.last_invoice_at = last_invoice_at
        self.next_invoice_at = next_invoice_at
        self.lifetime_value_cents = lifetime_value_cents
        self.metadata = metadata


        self.billing_contract_refs = billing_contract_refs if billing_contract_refs is not None else []
        self._pending_field_updates.add('name')
        if uuid is not None:
            self._pending_field_updates.add('uuid')
        self._pending_field_updates.add('fq_name')
        self._pending_field_updates.add('parent_uuid')
        if display_name is not None:
            self._pending_field_updates.add('display_name')
        if description is not None:
            self._pending_field_updates.add('description')
        if created_by is not None:
            self._pending_field_updates.add('created_by')
        if created_at is not None:
            self._pending_field_updates.add('created_at')
        if updated_at is not None:
            self._pending_field_updates.add('updated_at')
        self._pending_field_updates.add('plan_code')
        self._pending_field_updates.add('plan_version')
        self._pending_field_updates.add('status')
        self._pending_field_updates.add('subscription_type')
        self._pending_field_updates.add('billing_cycle')
        self._pending_field_updates.add('pricing_currency')
        self._pending_field_updates.add('current_period_start')
        self._pending_field_updates.add('current_period_end')
        if trial_start is not None:
            self._pending_field_updates.add('trial_start')
        if trial_end is not None:
            self._pending_field_updates.add('trial_end')
        if activated_at is not None:
            self._pending_field_updates.add('activated_at')
        if canceled_at is not None:
            self._pending_field_updates.add('canceled_at')
        self._pending_field_updates.add('cancel_at_period_end')
        if cancel_reason is not None:
            self._pending_field_updates.add('cancel_reason')
        if cancel_feedback is not None:
            self._pending_field_updates.add('cancel_feedback')
        self._pending_field_updates.add('quantity')
        if discount_percent is not None:
            self._pending_field_updates.add('discount_percent')
        if discount_code is not None:
            self._pending_field_updates.add('discount_code')
        if discount_expires_at is not None:
            self._pending_field_updates.add('discount_expires_at')
        if overage_handling_override is not None:
            self._pending_field_updates.add('overage_handling_override')
        if limit_overrides is not None:
            self._pending_field_updates.add('limit_overrides')
        if grandfathered_limits is not None:
            self._pending_field_updates.add('grandfathered_limits')
        if stripe_customer_id is not None:
            self._pending_field_updates.add('stripe_customer_id')
        if stripe_subscription_id is not None:
            self._pending_field_updates.add('stripe_subscription_id')
        if stripe_price_id is not None:
            self._pending_field_updates.add('stripe_price_id')
        self._pending_field_updates.add('payment_provider')
        self._pending_field_updates.add('auto_renew')
        if payment_failed_count != 0:
            self._pending_field_updates.add('payment_failed_count')
        if grace_period_end is not None:
            self._pending_field_updates.add('grace_period_end')
        if last_invoice_at is not None:
            self._pending_field_updates.add('last_invoice_at')
        if next_invoice_at is not None:
            self._pending_field_updates.add('next_invoice_at')
        if lifetime_value_cents != 0:
            self._pending_field_updates.add('lifetime_value_cents')
        if metadata is not None:
            self._pending_field_updates.add('metadata')
        if billing_contract_refs is not None:
            self._pending_field_updates.add('billing_contract_refs')
        
        # Initialize reference link data storage
        self._ref_link_data = {}
        
        # Mark initialization as complete
        self._initializing = False
        self.set_default_parent()

    def set_parent(self, parent):
        """
        Set the parent of this object and automatically construct fq_name and parent_uuid.
        Args:
            parent: Parent object instance
        Raises:
            AttributeError: If obj_type is missing
            InvalidParentError: If parent type doesn't match expected parent_type
        Example:
            domain = Domain.create(name="engineering")
            project = Project.create(name="backend")
            project.set_parent(domain)
        """
        # Validate parent matches expected type
        if parent.obj_type != self.parent_type:
            raise InvalidParentError(
                f"Invalid parent object. Expected parent_type '{self.parent_type}', "
                f"but got '{parent.obj_type}'"
            )
        
        # Set parent relationships
        self.parent_fq_name = parent.fq_name
        if self.name:
            # Ensure fq_name contains normalized name
            normalized_name = self._normalize_name(self.name)
            self.fq_name = self.parent_fq_name + [normalized_name]

        if hasattr(parent, 'uuid') and parent.uuid:
            self.parent_uuid = parent.uuid

    def set_default_parent(self):
        """Set default parent for root-level objects if not already set."""
        if not hasattr(self, 'obj_type'):
            return
    
        # Only set defaults if parent info wasn't explicitly provided
        if self.parent_type == "config_root":
            # Only set parent_fq_name if it's not already set
            if getattr(self, 'parent_fq_name', None) is None:
                self.parent_fq_name = ["config_root"]
        
            # Only construct fq_name if it's not already set and we have a name
            if not getattr(self, 'fq_name', None) and self.name:
                normalized_name = self._normalize_name(self.name)
                self.fq_name = self.parent_fq_name + [normalized_name]

    def __setattr__(self, name: str, value):
        """
        Override setattr to:
        1. Preserve original name as display_name if not explicitly set
        2. Automatically normalize 'name' attribute
        3. Track pending field updates
        """
        # ========================================================================
        # CRITICAL: When setting 'name', preserve original as display_name first
        # ========================================================================
        
        # ========================================================================
        # CRITICAL: When setting 'name', preserve original as display_name first
        # ========================================================================
        if name == 'name' and value is not None and isinstance(value, str):
            if (not getattr(self, '_initializing', True) and 
                hasattr(self, 'display_name') and 
                (self.display_name is None or self.display_name == '')):
                
                super().__setattr__('display_name', value)
                
                if (hasattr(self, '_pending_field_updates') and 
                    isinstance(self._pending_field_updates, set)):
                    self._pending_field_updates.add('display_name')
            
            value = self._normalize_name(value)
        
        
        # Always set the attribute (with normalized value if it was 'name')
        super().__setattr__(name, value)
        
        # Track pending field updates for partial updates
        try:
            # Only track if all conditions are met:
            if (hasattr(self, '_pending_field_updates') and 
                hasattr(self, '_py_to_json_map') and 
                name in self._py_to_json_map and
                name not in ['obj_type', 'parent_type', '_pending_field_updates', 
                           '_py_to_json_map', '_json_to_py_map', '_initializing', 
                           '_tracking_disabled', '_ref_link_data', '_supero_context'] and
                not getattr(self, '_initializing', False) and
                not getattr(self, '_tracking_disabled', False)):
                
                # Extra safety check - make sure _pending_field_updates is actually a set
                if isinstance(self._pending_field_updates, set):
                    self._pending_field_updates.add(name)
        except Exception:
            # If anything goes wrong with tracking, don't fail the attribute assignment
            # Just skip the tracking - the attribute was already set above
            pass

    # ========================================================================
    # SUPERO FLUENT API METHODS
    # ========================================================================

    @classmethod
    def create(cls, name: str, parent=None, **kwargs):
        """
        Fluent API: Create and optionally save object in one call.
        
        Args:
            name: Object name (required)
            parent: Optional parent object
            **kwargs: Additional attributes to set
            
        Returns:
            Created object instance (saved if Supero context is set)
            
        Example:
            # With Supero context:
            org = Supero.quickstart("acme")
            Project = org.get_schema("Project")
            project = Project.create(name="Alpha", status="active")
            
            # Or via parent:
            project = org.domain.create_project("Alpha", status="active")
        """
        obj = cls(name=name, **kwargs)
        if parent:
            obj.set_parent(parent)
        
        # Auto-save if _supero_context is set
        if hasattr(cls, '_supero_context') and cls._supero_context:
            saved_obj = cls._supero_context.save(obj)
            # Note: save() now handles method injection
            return saved_obj
        
        return obj

    @classmethod
    def find(cls, **filters):
        """
        Fluent API: Query objects with filters.
        
        Args:
            **filters: Filter conditions (supports Django-style lookups)
            
        Returns:
            QueryBuilder instance for chaining, or list if simple query
            
        Example:
            # Simple query:
            projects = Project.find(status="active")
            
            # Advanced query:
            projects = Project.find(status="active").limit(10).all()
            
            # Django-style lookups:
            projects = Project.find(priority__gte=5)
            projects = Project.find(name__contains="Alpha")
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(
                f"No Supero context set for {cls.__name__}. "
                f"Use: org = Supero.quickstart('name') then Project = org.get_schema('Project')"
            )
        
        if not filters:
            return cls.query()
        return cls.query().filter(**filters).all()

    @classmethod
    def find_one(cls, **filters):
        """
        Fluent API: Find single object matching filters.
        
        Args:
            **filters: Filter conditions
            
        Returns:
            First matching object or None
            
        Example:
            project = Project.find_one(name="Alpha")
            lead = User.find_one(role="lead")
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        return cls.query().filter(**filters).first()

    @classmethod
    def query(cls):
        """
        Start a query builder for advanced queries.
        
        Returns:
            QueryBuilder instance
            
        Example:
            projects = (Project.query()
                .filter(status="active")
                .filter(priority__gte=5)
                .order_by("-created_at")
                .limit(10)
                .all())
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        from supero.query import QueryBuilder
        return QueryBuilder(cls, cls._supero_context)

    @classmethod
    def bulk_load(cls, uuids):
        """
        Load multiple objects by UUID in single request.
        
        Args:
            uuids: List of UUIDs to load
            
        Returns:
            List of objects
            
        Example:
            projects = Project.bulk_load(["uuid1", "uuid2", "uuid3"])
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        import inflection
        obj_type = inflection.underscore(cls.__name__).replace('_', '-')
        return cls._supero_context.api_lib.list_bulk(
            obj_type,
            uuids=uuids,
            detail=True
        )

    @classmethod
    def bulk_create(cls, objects_data):
        """
        Create multiple objects in batch.
        
        Args:
            objects_data: List of dicts with object attributes
            
        Returns:
            List of created objects
            
        Example:
            projects = Project.bulk_create([
                {"name": "A", "status": "active"},
                {"name": "B", "status": "pending"}
            ])
        """
        if not hasattr(cls, '_supero_context') or not cls._supero_context:
            raise RuntimeError(f"No Supero context set for {cls.__name__}")
        
        created = []
        for data in objects_data:
            obj = cls.create(**data)
            created.append(obj)
        
        return created

    @classmethod
    def bulk_update(cls, objects, updates):
        """
        Update multiple objects with same changes.
        
        Args:
            objects: List of objects to update
            updates: Dict of attributes to update
            
        Example:
            projects = Project.find(status="pending")
            Project.bulk_update(projects, {"status": "active"})
        """
        for obj in objects:
            for key, value in updates.items():
                setattr(obj, key, value)
            obj.save()
        
        return objects

    @classmethod
    def bulk_save(cls, objects):
        """
        Save multiple objects.
        
        Args:
            objects: List of objects to save
            
        Example:
            for project in projects:
                project.status = "completed"
            Project.bulk_save(projects)
        """
        for obj in objects:
            obj.save()
        
        return objects

    @classmethod
    def bulk_delete(cls, objects=None, uuids=None):
        """
        Delete multiple objects.
        
        Args:
            objects: List of objects to delete
            uuids: List of UUIDs to delete
            
        Example:
            Project.bulk_delete(old_projects)
            Project.bulk_delete(uuids=["uuid1", "uuid2"])
        """
        if objects:
            for obj in objects:
                obj.delete()
        elif uuids:
            import inflection
            obj_type = inflection.underscore(cls.__name__).replace('_', '-')
            for uuid in uuids:
                cls._supero_context.api_lib._object_delete(obj_type, id=uuid)

    def save(self):
        """
        Fluent API: Save this object (create or update).
        
        Returns:
            Saved object with updated fields
            
        Example:
            project.status = "completed"
            project.save()
        """
        if not hasattr(self.__class__, '_supero_context') or not self.__class__._supero_context:
            raise RuntimeError(f"No Supero context set for {self.__class__.__name__}")
        
        return self.__class__._supero_context.save(self)

    def delete(self):
        """
        Fluent API: Delete this object.
        
        Returns:
            True if successful
            
        Example:
            old_project.delete()
        """
        if not hasattr(self.__class__, '_supero_context') or not self.__class__._supero_context:
            raise RuntimeError(f"No Supero context set for {self.__class__.__name__}")
        
        return self.__class__._supero_context.delete(self)

    def refresh(self):
        """
        Fluent API: Reload this object from server.
        
        Returns:
            Refreshed object
            
        Example:
            project.refresh()
        """
        if not hasattr(self.__class__, '_supero_context') or not self.__class__._supero_context:
            raise RuntimeError(f"No Supero context set for {self.__class__.__name__}")
        
        return self.__class__._supero_context.refresh(self)

    def update(self):
        """
        Context manager for batch updates.
        
        Returns:
            Self for use as context manager
            
        Example:
            with project.update() as p:
                p.status = "active"
                p.priority = 1
                # Auto-saves on exit
        """
        return self

    def __enter__(self):
        """Enter context manager."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit context manager and auto-save."""
        if exc_type is None:
            self.save()

    def _validate_field_constraint(self, field_name: str, value: Any):
        """Validate a field value against its constraints."""
        if field_name not in self._CONSTRAINTS:
            return

        constraints = self._CONSTRAINTS[field_name]
        field_type = constraints.get('type')

        # String constraints
        if field_type == 'string' and isinstance(value, str):
            min_len = constraints.get('min-length')
            max_len = constraints.get('max-length')
            pattern = constraints.get('pattern')

            if min_len and len(value) < min_len:
                raise ValueError(
                    f"Field '{field_name}': value too short (min {min_len} chars, got {len(value)})"
                )

            if max_len and len(value) > max_len:
                raise ValueError(
                    f"Field '{field_name}': value too long (max {max_len} chars, got {len(value)})"
                )

            if pattern:
                import re
                if not re.match(pattern, value):
                    raise ValueError(
                        f"Field '{field_name}': value doesn't match pattern {pattern}"
                    )

        # Numeric constraints
        elif field_type in ['int', 'float'] and isinstance(value, (int, float)):
            min_val = constraints.get('min-value')
            max_val = constraints.get('max-value')
            range_val = constraints.get('range')

            if min_val is not None and value < min_val:
                raise ValueError(f"Field '{field_name}': value {value} below minimum {min_val}")

            if max_val is not None and value > max_val:
                raise ValueError(f"Field '{field_name}': value {value} above maximum {max_val}")

            if range_val:
                # Parse range like "[1-5]"
                import re
                match = re.match(r'^\[(\d+)-(\d+)\]$', range_val)
                if match:
                    range_min, range_max = int(match.group(1)), int(match.group(2))
                    if not (range_min <= value <= range_max):
                        raise ValueError(
                            f"Field '{field_name}': value {value} outside range {range_val}"
                        )


    def get_name(self) -> str:
        """Get the value of name."""
        return self.name

    def set_name(self, value: str):
        """Set the value of name. AUTOMATICALLY NORMALIZES THE NAME."""
        if not self.display_name:
            self.display_name = value
        self.name = self._normalize_name(value) if value else value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('name')

    def is_set_name(self) -> bool:
        """Check if name was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'name' in self._pending_field_updates)

    def get_uuid(self) -> str:
        """Get the value of uuid."""
        return self.uuid

    def set_uuid(self, value: str):
        """Set the value of uuid."""
        self.uuid = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('uuid')

    def is_set_uuid(self) -> bool:
        """Check if uuid was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'uuid' in self._pending_field_updates)

    def get_fq_name(self) -> List[str]:
        """Get the value of fq_name."""
        return self.fq_name

    def set_fq_name(self, value: List[str]):
        """Set the value of fq_name."""
        self.fq_name = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('fq_name')

    def add_fq_name(self, item: str):
        """Add an item to fq_name."""
        if self.fq_name is None:
            self.fq_name = []
        self.fq_name.append(item)
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('fq_name')

    def del_fq_name(self, item: str):
        """Remove an item from fq_name."""
        if self.fq_name and item in self.fq_name:
            self.fq_name.remove(item)
            if hasattr(self, '_pending_field_updates'):
                self._pending_field_updates.add('fq_name')

    def del_fq_name_by_index(self, index: int):
        """Remove an item from fq_name by index."""
        if self.fq_name and 0 <= index < len(self.fq_name):
            del self.fq_name[index]
            if hasattr(self, '_pending_field_updates'):
                self._pending_field_updates.add('fq_name')

    def is_set_fq_name(self) -> bool:
        """Check if fq_name was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'fq_name' in self._pending_field_updates)

    def get_parent_type(self) -> str:
        """Get the value of parent_type."""
        return self.parent_type

    def set_parent_type(self, value: str):
        """Set the value of parent_type."""
        self.parent_type = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('parent_type')

    def is_set_parent_type(self) -> bool:
        """Check if parent_type was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'parent_type' in self._pending_field_updates)

    def get_parent_uuid(self) -> str:
        """Get the value of parent_uuid."""
        return self.parent_uuid

    def set_parent_uuid(self, value: str):
        """Set the value of parent_uuid."""
        self.parent_uuid = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('parent_uuid')

    def is_set_parent_uuid(self) -> bool:
        """Check if parent_uuid was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'parent_uuid' in self._pending_field_updates)

    def get_obj_type(self) -> str:
        """Get the value of obj_type."""
        return self.obj_type

    def set_obj_type(self, value: str):
        """Set the value of obj_type."""
        self.obj_type = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('obj_type')

    def is_set_obj_type(self) -> bool:
        """Check if obj_type was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'obj_type' in self._pending_field_updates)

    def get_display_name(self) -> str:
        """Get the value of display_name."""
        return self.display_name

    def set_display_name(self, value: str):
        """Set the value of display_name."""
        self.display_name = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('display_name')

    def is_set_display_name(self) -> bool:
        """Check if display_name was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'display_name' in self._pending_field_updates)

    def get_description(self) -> str:
        """Get the value of description."""
        return self.description

    def set_description(self, value: str):
        """Set the value of description."""
        self.description = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('description')

    def is_set_description(self) -> bool:
        """Check if description was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'description' in self._pending_field_updates)

    def get_created_by(self) -> str:
        """Get the value of created_by."""
        return self.created_by

    def set_created_by(self, value: str):
        """Set the value of created_by."""
        self.created_by = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('created_by')

    def is_set_created_by(self) -> bool:
        """Check if created_by was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'created_by' in self._pending_field_updates)

    def get_created_at(self) -> str:
        """Get the value of created_at."""
        return self.created_at

    def set_created_at(self, value: str):
        """Set the value of created_at."""
        self.created_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('created_at')

    def is_set_created_at(self) -> bool:
        """Check if created_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'created_at' in self._pending_field_updates)

    def get_updated_at(self) -> str:
        """Get the value of updated_at."""
        return self.updated_at

    def set_updated_at(self, value: str):
        """Set the value of updated_at."""
        self.updated_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('updated_at')

    def is_set_updated_at(self) -> bool:
        """Check if updated_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'updated_at' in self._pending_field_updates)

    def get_plan_code(self) -> str:
        """Get the value of plan_code as base type value."""
        return self.plan_code.value if hasattr(self.plan_code, 'value') else self.plan_code

    def set_plan_code(self, value: str):
        """Set the value of plan_code (accepts base type value)."""
        if value is None:
            self.plan_code = None
        elif hasattr(value, 'value'):
            self.plan_code = value
        else:
            try:
                import importlib
                package_base = self.__module__.split('.')[0]
                module_name = f'{package_base}.enums.billing_plan_types'
                enum_module = importlib.import_module(module_name)
                enum_class = getattr(enum_module, 'BillingPlanTypes')
                self.plan_code = enum_class(value)
            except Exception as e:
                raise ValueError(f'Cannot convert {value} to BillingPlanTypes enum: {e}')
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('plan_code')

    def is_set_plan_code(self) -> bool:
        """Check if plan_code was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'plan_code' in self._pending_field_updates)

    def get_plan_version(self) -> int:
        """Get the value of plan_version."""
        return self.plan_version

    def set_plan_version(self, value: int):
        """Set the value of plan_version."""
        self.plan_version = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('plan_version')

    def is_set_plan_version(self) -> bool:
        """Check if plan_version was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'plan_version' in self._pending_field_updates)

    def get_status(self) -> str:
        """Get the value of status."""
        return self.status

    def set_status(self, value: str):
        """Set the value of status."""
        self.status = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('status')

    def is_set_status(self) -> bool:
        """Check if status was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'status' in self._pending_field_updates)

    def get_subscription_type(self) -> str:
        """Get the value of subscription_type."""
        return self.subscription_type

    def set_subscription_type(self, value: str):
        """Set the value of subscription_type."""
        self.subscription_type = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('subscription_type')

    def is_set_subscription_type(self) -> bool:
        """Check if subscription_type was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'subscription_type' in self._pending_field_updates)

    def get_billing_cycle(self) -> str:
        """Get the value of billing_cycle."""
        return self.billing_cycle

    def set_billing_cycle(self, value: str):
        """Set the value of billing_cycle."""
        self.billing_cycle = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('billing_cycle')

    def is_set_billing_cycle(self) -> bool:
        """Check if billing_cycle was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'billing_cycle' in self._pending_field_updates)

    def get_pricing_currency(self) -> str:
        """Get the value of pricing_currency."""
        return self.pricing_currency

    def set_pricing_currency(self, value: str):
        """Set the value of pricing_currency."""
        self.pricing_currency = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('pricing_currency')

    def is_set_pricing_currency(self) -> bool:
        """Check if pricing_currency was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'pricing_currency' in self._pending_field_updates)

    def get_current_period_start(self) -> str:
        """Get the value of current_period_start."""
        return self.current_period_start

    def set_current_period_start(self, value: str):
        """Set the value of current_period_start."""
        self.current_period_start = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('current_period_start')

    def is_set_current_period_start(self) -> bool:
        """Check if current_period_start was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'current_period_start' in self._pending_field_updates)

    def get_current_period_end(self) -> str:
        """Get the value of current_period_end."""
        return self.current_period_end

    def set_current_period_end(self, value: str):
        """Set the value of current_period_end."""
        self.current_period_end = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('current_period_end')

    def is_set_current_period_end(self) -> bool:
        """Check if current_period_end was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'current_period_end' in self._pending_field_updates)

    def get_trial_start(self) -> str:
        """Get the value of trial_start."""
        return self.trial_start

    def set_trial_start(self, value: str):
        """Set the value of trial_start."""
        self.trial_start = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('trial_start')

    def is_set_trial_start(self) -> bool:
        """Check if trial_start was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'trial_start' in self._pending_field_updates)

    def get_trial_end(self) -> str:
        """Get the value of trial_end."""
        return self.trial_end

    def set_trial_end(self, value: str):
        """Set the value of trial_end."""
        self.trial_end = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('trial_end')

    def is_set_trial_end(self) -> bool:
        """Check if trial_end was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'trial_end' in self._pending_field_updates)

    def get_activated_at(self) -> str:
        """Get the value of activated_at."""
        return self.activated_at

    def set_activated_at(self, value: str):
        """Set the value of activated_at."""
        self.activated_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('activated_at')

    def is_set_activated_at(self) -> bool:
        """Check if activated_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'activated_at' in self._pending_field_updates)

    def get_canceled_at(self) -> str:
        """Get the value of canceled_at."""
        return self.canceled_at

    def set_canceled_at(self, value: str):
        """Set the value of canceled_at."""
        self.canceled_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('canceled_at')

    def is_set_canceled_at(self) -> bool:
        """Check if canceled_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'canceled_at' in self._pending_field_updates)

    def get_cancel_at_period_end(self) -> bool:
        """Get the value of cancel_at_period_end."""
        return self.cancel_at_period_end

    def set_cancel_at_period_end(self, value: bool):
        """Set the value of cancel_at_period_end."""
        self.cancel_at_period_end = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('cancel_at_period_end')

    def is_set_cancel_at_period_end(self) -> bool:
        """Check if cancel_at_period_end was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'cancel_at_period_end' in self._pending_field_updates)

    def get_cancel_reason(self) -> str:
        """Get the value of cancel_reason."""
        return self.cancel_reason

    def set_cancel_reason(self, value: str):
        """Set the value of cancel_reason."""
        self.cancel_reason = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('cancel_reason')

    def is_set_cancel_reason(self) -> bool:
        """Check if cancel_reason was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'cancel_reason' in self._pending_field_updates)

    def get_cancel_feedback(self) -> str:
        """Get the value of cancel_feedback."""
        return self.cancel_feedback

    def set_cancel_feedback(self, value: str):
        """Set the value of cancel_feedback."""
        self.cancel_feedback = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('cancel_feedback')

    def is_set_cancel_feedback(self) -> bool:
        """Check if cancel_feedback was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'cancel_feedback' in self._pending_field_updates)

    def get_quantity(self) -> int:
        """Get the value of quantity."""
        return self.quantity

    def set_quantity(self, value: int):
        """Set the value of quantity."""
        self.quantity = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('quantity')

    def is_set_quantity(self) -> bool:
        """Check if quantity was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'quantity' in self._pending_field_updates)

    def get_discount_percent(self) -> float:
        """Get the value of discount_percent."""
        return self.discount_percent

    def set_discount_percent(self, value: float):
        """Set the value of discount_percent."""
        self.discount_percent = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('discount_percent')

    def is_set_discount_percent(self) -> bool:
        """Check if discount_percent was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'discount_percent' in self._pending_field_updates)

    def get_discount_code(self) -> str:
        """Get the value of discount_code."""
        return self.discount_code

    def set_discount_code(self, value: str):
        """Set the value of discount_code."""
        self.discount_code = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('discount_code')

    def is_set_discount_code(self) -> bool:
        """Check if discount_code was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'discount_code' in self._pending_field_updates)

    def get_discount_expires_at(self) -> str:
        """Get the value of discount_expires_at."""
        return self.discount_expires_at

    def set_discount_expires_at(self, value: str):
        """Set the value of discount_expires_at."""
        self.discount_expires_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('discount_expires_at')

    def is_set_discount_expires_at(self) -> bool:
        """Check if discount_expires_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'discount_expires_at' in self._pending_field_updates)

    def get_overage_handling_override(self) -> str:
        """Get the value of overage_handling_override."""
        return self.overage_handling_override

    def set_overage_handling_override(self, value: str):
        """Set the value of overage_handling_override."""
        self.overage_handling_override = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('overage_handling_override')

    def is_set_overage_handling_override(self) -> bool:
        """Check if overage_handling_override was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'overage_handling_override' in self._pending_field_updates)

    def get_limit_overrides(self) -> dict:
        """Get the value of limit_overrides."""
        return self.limit_overrides

    def set_limit_overrides(self, value: dict):
        """Set the value of limit_overrides."""
        self.limit_overrides = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('limit_overrides')

    def is_set_limit_overrides(self) -> bool:
        """Check if limit_overrides was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'limit_overrides' in self._pending_field_updates)

    def get_grandfathered_limits(self) -> dict:
        """Get the value of grandfathered_limits."""
        return self.grandfathered_limits

    def set_grandfathered_limits(self, value: dict):
        """Set the value of grandfathered_limits."""
        self.grandfathered_limits = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('grandfathered_limits')

    def is_set_grandfathered_limits(self) -> bool:
        """Check if grandfathered_limits was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'grandfathered_limits' in self._pending_field_updates)

    def get_stripe_customer_id(self) -> str:
        """Get the value of stripe_customer_id."""
        return self.stripe_customer_id

    def set_stripe_customer_id(self, value: str):
        """Set the value of stripe_customer_id."""
        self.stripe_customer_id = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('stripe_customer_id')

    def is_set_stripe_customer_id(self) -> bool:
        """Check if stripe_customer_id was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'stripe_customer_id' in self._pending_field_updates)

    def get_stripe_subscription_id(self) -> str:
        """Get the value of stripe_subscription_id."""
        return self.stripe_subscription_id

    def set_stripe_subscription_id(self, value: str):
        """Set the value of stripe_subscription_id."""
        self.stripe_subscription_id = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('stripe_subscription_id')

    def is_set_stripe_subscription_id(self) -> bool:
        """Check if stripe_subscription_id was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'stripe_subscription_id' in self._pending_field_updates)

    def get_stripe_price_id(self) -> str:
        """Get the value of stripe_price_id."""
        return self.stripe_price_id

    def set_stripe_price_id(self, value: str):
        """Set the value of stripe_price_id."""
        self.stripe_price_id = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('stripe_price_id')

    def is_set_stripe_price_id(self) -> bool:
        """Check if stripe_price_id was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'stripe_price_id' in self._pending_field_updates)

    def get_payment_provider(self) -> str:
        """Get the value of payment_provider."""
        return self.payment_provider

    def set_payment_provider(self, value: str):
        """Set the value of payment_provider."""
        self.payment_provider = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('payment_provider')

    def is_set_payment_provider(self) -> bool:
        """Check if payment_provider was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'payment_provider' in self._pending_field_updates)

    def get_auto_renew(self) -> bool:
        """Get the value of auto_renew."""
        return self.auto_renew

    def set_auto_renew(self, value: bool):
        """Set the value of auto_renew."""
        self.auto_renew = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('auto_renew')

    def is_set_auto_renew(self) -> bool:
        """Check if auto_renew was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'auto_renew' in self._pending_field_updates)

    def get_payment_failed_count(self) -> int:
        """Get the value of payment_failed_count."""
        return self.payment_failed_count

    def set_payment_failed_count(self, value: int):
        """Set the value of payment_failed_count."""
        self.payment_failed_count = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('payment_failed_count')

    def is_set_payment_failed_count(self) -> bool:
        """Check if payment_failed_count was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'payment_failed_count' in self._pending_field_updates)

    def get_grace_period_end(self) -> str:
        """Get the value of grace_period_end."""
        return self.grace_period_end

    def set_grace_period_end(self, value: str):
        """Set the value of grace_period_end."""
        self.grace_period_end = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('grace_period_end')

    def is_set_grace_period_end(self) -> bool:
        """Check if grace_period_end was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'grace_period_end' in self._pending_field_updates)

    def get_last_invoice_at(self) -> str:
        """Get the value of last_invoice_at."""
        return self.last_invoice_at

    def set_last_invoice_at(self, value: str):
        """Set the value of last_invoice_at."""
        self.last_invoice_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('last_invoice_at')

    def is_set_last_invoice_at(self) -> bool:
        """Check if last_invoice_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'last_invoice_at' in self._pending_field_updates)

    def get_next_invoice_at(self) -> str:
        """Get the value of next_invoice_at."""
        return self.next_invoice_at

    def set_next_invoice_at(self, value: str):
        """Set the value of next_invoice_at."""
        self.next_invoice_at = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('next_invoice_at')

    def is_set_next_invoice_at(self) -> bool:
        """Check if next_invoice_at was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'next_invoice_at' in self._pending_field_updates)

    def get_lifetime_value_cents(self) -> int:
        """Get the value of lifetime_value_cents."""
        return self.lifetime_value_cents

    def set_lifetime_value_cents(self, value: int):
        """Set the value of lifetime_value_cents."""
        self.lifetime_value_cents = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('lifetime_value_cents')

    def is_set_lifetime_value_cents(self) -> bool:
        """Check if lifetime_value_cents was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'lifetime_value_cents' in self._pending_field_updates)

    def get_metadata(self) -> dict:
        """Get the value of metadata."""
        return self.metadata

    def set_metadata(self, value: dict):
        """Set the value of metadata."""
        self.metadata = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('metadata')

    def is_set_metadata(self) -> bool:
        """Check if metadata was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'metadata' in self._pending_field_updates)

    @classmethod
    def getBillingPlanTypesStrings(cls):
        """Legacy method for BillingPlanTypes backward compatibility."""
        try:
            import importlib
            package_base = cls.__module__.split('.')[0] if hasattr(cls, '__module__') else 'pymodel'
            enum_snake_name = normalize_name_consistent('BillingPlanTypes')
            module_name = f'{package_base}.enums.{enum_snake_name}'
            enum_module = importlib.import_module(module_name)
            enum_class = getattr(enum_module, 'BillingPlanTypes')
            return enum_class.get_all_values()
        except Exception:
            return []

    def get_billing_contract_refs(self) -> List[Dict[str, Any]]:
        """Get the references to PlatformBillingContract."""
        return self.billing_contract_refs

    def set_billing_contract_refs(self, value: List[Dict[str, Any]]):
        """Set the references to PlatformBillingContract."""
        self.billing_contract_refs = value
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('billing_contract_refs')

    def add_billing_contract_ref(self, uuid: str = None, fq_name: List[str] = None,
                                 ref_or_target=None, link_data: Dict[str, Any] = None):
        """
        Add a reference to a PlatformBillingContract.
        
        Args:
            uuid: UUID of target (if not using ref_or_target)
            fq_name: FQ name of target (if not using ref_or_target)
            ref_or_target: Target object instance
            link_data: Optional dict with relationship metadata (role, allocation, etc.)
        
        Examples:
            # Method 1: Direct uuid/fq_name with link_data
            obj.add_billing_contract_ref(
                uuid='user-123',
                fq_name=['users', 'alice'],
                link_data={'role': 'lead', 'allocation': 1.0}
            )
            
            # Method 2: Pass target object with link_data
            target = PlatformBillingContract.find_one(name='alice')
            obj.add_billing_contract_ref(
                ref_or_target=target,
                link_data={'role': 'lead', 'allocation': 1.0}
            )
        """
        # Handle target object
        if ref_or_target is not None:
            uuid = getattr(ref_or_target, 'uuid', uuid)
            fq_name = getattr(ref_or_target, 'fq_name', fq_name)
        
        # Create reference dict
        ref_dict = {
            'uuid': uuid,
            'fq_name': fq_name,
        }
        
        # Add to refs list if not duplicate
        if not any(r['uuid'] == uuid for r in self.billing_contract_refs):
            self.billing_contract_refs.append(ref_dict)
            
            # Store link_data separately if provided
            if link_data:
                if not hasattr(self, '_ref_link_data'):
                    self._ref_link_data = {}
                self._ref_link_data[uuid] = link_data
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('billing_contract_refs')

    def del_billing_contract_ref(self, uuid: str):
        """Delete a reference to a PlatformBillingContract object by UUID."""
        self.billing_contract_refs = [r for r in self.billing_contract_refs if r['uuid'] != uuid]
        # Clean up link_data
        if hasattr(self, '_ref_link_data') and uuid in self._ref_link_data:
            del self._ref_link_data[uuid]
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.add('billing_contract_refs')

    def get_billing_contract_objects(self) -> 'List[PlatformBillingContract]':
        """
        Get actual PlatformBillingContract objects from references.
        
        Returns:
            List of PlatformBillingContract objects
        
        Note:
            Access link_data separately via obj._ref_link_data[uuid]
        
        Examples:
            # Get objects and access link_data
            for target in obj.get_billing_contract_objects():
                link_data = obj._ref_link_data.get(target.uuid, {})
                print(target.name, link_data.get('role'))
        """
        from typing import TYPE_CHECKING
        if TYPE_CHECKING:
            from . import platform_billing_contract
        import importlib
        
        module_name = f'{self.__module__.rsplit(".", 1)[0]}.platform_billing_contract'
        try:
            module = importlib.import_module(module_name)
            PlatformBillingContract = getattr(module, 'PlatformBillingContract')
            
            result = []
            for ref_dict in self.billing_contract_refs:
                # Create object from dict
                target = PlatformBillingContract.from_dict(ref_dict)
                if target:
                    result.append(target)
            
            return result
        except (ImportError, AttributeError):
            return []

    def is_set_billing_contract_refs(self) -> bool:
        """Check if billing_contract was explicitly set."""
        return (hasattr(self, '_pending_field_updates') and 
                'billing_contract_refs' in self._pending_field_updates)



    # ========================================================================
    # END-POINTS QUERY METHODS
    # ========================================================================

    @classmethod
    def get_end_points(cls):
        """Get all configured end_points for this object type."""
        return [ep.copy() for ep in cls._end_points]

    @classmethod
    def get_end_point(cls, type=None, name=None, cloud=None, operation=None, enabled_only=True):
        """
        Query specific end-point by criteria.
        
        Args:
            type: End-point type (database, streaming, cache, search, blob-storage, vector-db)
            name: Technology name (mongo, kafka, redis, pinecone, etc.)
            cloud: Cloud environment (private, platform, public, hybrid)
            operation: Operation name (create, read, update, delete, search, similarity_search)
            enabled_only: Only return enabled end_points
        
        Returns:
            Matching end-point dict or None
        """
        for ep in cls._end_points:
            if enabled_only and not ep.get('enabled', True):
                continue
            if type and ep.get('type') != type:
                continue
            if name and ep.get('name') != name:
                continue
            if cloud and cloud not in ep.get('cloud', []):
                continue
            if operation and operation not in ep.get('operations', []):
                continue
            return ep.copy()
        return None

    @classmethod
    def get_end_points_by_type(cls, ep_type, enabled_only=True):
        """Get all end_points of a specific type."""
        return [
            ep.copy() for ep in cls._end_points 
            if ep.get('type') == ep_type and (not enabled_only or ep.get('enabled', True))
        ]

    @classmethod
    def get_end_points_by_cloud(cls, cloud, enabled_only=True):
        """Get all end_points available in a specific cloud."""
        return [
            ep.copy() for ep in cls._end_points 
            if cloud in ep.get('cloud', []) and (not enabled_only or ep.get('enabled', True))
        ]

    @classmethod
    def supports_operation(cls, operation, ep_type=None):
        """Check if this object type supports an operation."""
        for ep in cls._end_points:
            if not ep.get('enabled', True):
                continue
            if ep_type and ep.get('type') != ep_type:
                continue
            if operation in ep.get('operations', []):
                return True
        return False

    @classmethod
    def get_primary_end_point(cls, ep_type=None):
        """Get the primary (highest priority) end-point of a type."""
        candidates = cls._end_points
        if ep_type:
            candidates = [ep for ep in candidates if ep.get('type') == ep_type]
        
        candidates = [ep for ep in candidates if ep.get('enabled', True)]
        
        if not candidates:
            return None
        
        # Sort by priority (lower number = higher priority)
        candidates.sort(key=lambda x: x.get('priority', 999))
        return candidates[0].copy()

    @classmethod
    def supports_vector_search(cls):
        """Check if this object type has vector database support."""
        return cls.get_end_point(type="vector-db") is not None

    @classmethod
    def get_vector_config(cls):
        """Get vector database configuration."""
        vector_ep = cls.get_end_point(type="vector-db")
        return vector_ep.get('config', {}) if vector_ep else {}

    # ========================================================================
    # INDEX QUERY METHODS
    # ========================================================================

    @classmethod
    def get_indexes(cls):
        """Get all index definitions for this object type."""
        return {k: v.copy() for k, v in cls._indexes.items()}

    @classmethod
    def get_index(cls, name):
        """Get specific index definition by name."""
        idx = cls._indexes.get(name)
        return idx.copy() if idx else None

    @classmethod
    def get_index_names(cls):
        """Get all index names."""
        return list(cls._indexes.keys())

    @classmethod
    def get_indexes_for_attribute(cls, attr_name):
        """Get all indexes that include a specific attribute."""
        result = []
        for idx_name, idx_def in cls._indexes.items():
            fields = idx_def.get('fields', [])
            if any(f.get('name') == attr_name for f in fields):
                result.append(idx_name)
        return result

    @classmethod
    def get_compound_indexes(cls):
        """Get all compound indexes (indexes with multiple fields)."""
        return {
            k: v.copy() for k, v in cls._indexes.items()
            if v.get('type') == 'compound'
        }

    @classmethod
    def get_simple_indexes(cls):
        """Get all simple indexes (single field)."""
        return {
            k: v.copy() for k, v in cls._indexes.items()
            if v.get('type') == 'simple'
        }

    # ========================================================================
    # INSTANCE ROUTING METHODS
    # ========================================================================

    def get_routing_info(self):
        """
        Get routing information for this instance.
        Useful for sharding, partitioning, cloud selection.
        """
        return {
            'object_type': getattr(self, 'obj_type', self.__class__.__name__),
            'uuid': getattr(self, 'uuid', None),
            'cloud': self._determine_cloud(),
            'partition_key': self._get_partition_key(),
            'endpoints': self.get_end_points()
        }

    def _determine_cloud(self):
        """Determine cloud environment based on instance data."""
        if hasattr(self, 'country'):
            country = getattr(self, 'country')
            if country in ['US', 'Canada']:
                return 'private'
        return 'platform'

    def _get_partition_key(self):
        """Get partition key value for this instance."""
        for ep in self._end_points:
            partition_key_name = ep.get('config', {}).get('partition_key')
            if partition_key_name:
                return getattr(self, partition_key_name, getattr(self, 'uuid', ''))
        return getattr(self, 'uuid', '')

    # ========================================================================
    # PENDING FIELD TRACKING METHODS
    # ========================================================================

    def disable_pending_tracking(self):
        """Temporarily disable pending field tracking."""
        self._tracking_disabled = True
    
    def enable_pending_tracking(self):
        """Re-enable pending field tracking."""
        self._tracking_disabled = False
    
    def is_pending_tracking_enabled(self):
        """Check if pending field tracking is currently enabled."""
        return (hasattr(self, '_pending_field_updates') and 
                not getattr(self, '_initializing', False) and
                not getattr(self, '_tracking_disabled', False))

    def clear_pending_updates(self):
        """Clear the pending field updates set."""
        if hasattr(self, '_pending_field_updates'):
            self._pending_field_updates.clear()
    
    def get_pending_updates(self):
        """Get the set of pending field updates."""
        return getattr(self, '_pending_field_updates', set()).copy()
    
    def has_pending_updates(self):
        """Check if there are any pending updates."""
        return bool(getattr(self, '_pending_field_updates', set()))

    # ========================================================================
    # SERIALIZATION METHODS
    # ========================================================================

    @staticmethod
    def _parse_datetime(value):
        """Parse a datetime string or return datetime object as-is."""
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        if isinstance(value, str):
            try:
                return datetime.fromisoformat(value.replace('Z', '+00:00'))
            except:
                try:
                    return datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
                except:
                    return value
        return value

    @staticmethod
    def _format_datetime(value):
        """Format a datetime object to ISO string."""
        if value is None:
            return None
        if isinstance(value, datetime):
            return value.isoformat()
        return str(value)

    def to_dict(self, include_all_fields=True, validate=False):
        """
        Converts the object to a dictionary, including nested objects.
        ENHANCED: Automatically converts datetime objects to ISO strings.
        
        Args:
            include_all_fields: If True, include all non-None fields. 
                              If False, only include pending field updates + mandatory system fields
        """
        data = {}
        
        if include_all_fields or not hasattr(self, '_pending_field_updates'):
            for py_key, json_key in self._py_to_json_map.items():
                value = getattr(self, py_key, None)
                if value is not None:
                    if hasattr(value, 'to_dict'):
                        data[json_key] = value.to_dict()
                    elif isinstance(value, datetime):
                        data[json_key] = self._format_datetime(value)
                    elif isinstance(value, list):
                        converted_list = []
                        for item in value:
                            if hasattr(item, 'to_dict'):
                                converted_list.append(item.to_dict())
                            elif isinstance(item, datetime):
                                converted_list.append(self._format_datetime(item))
                            else:
                                converted_list.append(item)
                        data[json_key] = converted_list
                    else:
                        data[json_key] = value
        else:
            fields_to_include = set(self._pending_field_updates)
            mandatory_for_updates = {'uuid', 'name', 'fq_name', 'parent_uuid', 'obj_type', 'parent_type'}
            
            for field in mandatory_for_updates:
                if field in self._py_to_json_map:
                    value = getattr(self, field, None)
                    if value is not None:
                        if field == 'parent_uuid' or (value and value != ''):
                            fields_to_include.add(field)
            
            for py_key in fields_to_include:
                if py_key in self._py_to_json_map:
                    json_key = self._py_to_json_map[py_key]
                    value = getattr(self, py_key, None)
                    
                    if hasattr(value, 'to_dict'):
                        data[json_key] = value.to_dict()
                    elif isinstance(value, datetime):
                        data[json_key] = self._format_datetime(value)
                    elif isinstance(value, list):
                        converted_list = []
                        for item in value:
                            if hasattr(item, 'to_dict'):
                                converted_list.append(item.to_dict())
                            elif isinstance(item, datetime):
                                converted_list.append(self._format_datetime(item))
                            else:
                                converted_list.append(item)
                        data[json_key] = converted_list
                    else:
                        data[json_key] = value
        
        # NEW: Embed link_data into references before returning
        if hasattr(self, '_ref_link_data') and self._ref_link_data:
            for py_key, json_key in self._py_to_json_map.items():
                if py_key.endswith('_refs') and json_key in data:
                    # Get the refs list from data
                    refs = data[json_key]
                    if isinstance(refs, list):
                        # Embed link_data into each reference
                        refs_with_link_data = []
                        for ref in refs:
                            if isinstance(ref, dict):
                                ref_copy = ref.copy()
                                uuid = ref_copy.get('uuid')
                                if uuid and uuid in self._ref_link_data:
                                    ref_copy['link_data'] = self._ref_link_data[uuid]
                                refs_with_link_data.append(ref_copy)
                            else:
                                refs_with_link_data.append(ref)
                        data[json_key] = refs_with_link_data
        
        if validate:
            # v3.7: Before validating, fill in any missing derived fields so
            # downstream consumers of the dict never see a half-populated
            # record. This mirrors the platform's compute_name precedence.
            self._fill_derived_fields_into(data)
            self._validate_mandatory_fields()
        
        return data 

    def to_dict_for_update(self):
        """Converts only the modified fields + mandatory system fields to a dictionary for partial updates."""
        return self.to_dict(include_all_fields=False)

    def _compute_name_from_derive(self, field_name="name"):
        """
        Client-side mirror of the platform's compute_name precedence (v3.7).

        Precedence:
          1. Current value of `self.<field_name>`        — explicit value wins
          2. self.fq_name[-1] (only when field == 'name') — extract from fq_name tail
          3. _DERIVE_CONFIG[field_name].from values      — join with separator

        Returns the computed value, or None if no derivation path applies.

        This is a courtesy implementation so `to_dict(validate=True)` can emit
        a complete dict for downstream consumers (file writers, message queues,
        non-platform-core APIs). The platform-core CRUD layer remains the
        authoritative trust boundary — it re-derives server-side regardless.
        """
        # 1. Explicit value already on the instance
        current = getattr(self, field_name, None)
        if current:
            return current

        # 2. fq_name tail (only meaningful for the `name` field)
        if field_name == "name":
            fq = getattr(self, "fq_name", None)
            if isinstance(fq, list) and fq:
                tail = fq[-1]
                if tail:
                    return tail

        # 3. Schema-declared derivation
        cfg = (self._DERIVE_CONFIG or {}).get(field_name)
        if not isinstance(cfg, dict):
            return None
        sources = cfg.get("from") or []
        if not sources:
            return None
        separator = cfg.get("separator", ":")

        # Source names in _DERIVE_CONFIG are JSON-side names (schema
        # attribute names). Translate to Python-side names to read off self.
        values = []
        for src_json_name in sources:
            py_name = (self._json_to_py_map or {}).get(src_json_name, src_json_name)
            v = getattr(self, py_name, None)
            if v is None or v == "":
                # Cannot derive — at least one source is missing.
                return None
            values.append(str(v))

        if len(values) == 1:
            return values[0]
        return separator.join(values)

    def _fill_derived_fields_into(self, data):
        """
        For every field listed in _DERIVE_CONFIG, if it's missing from
        `data` (the outgoing dict) AND we can compute it, fill it in on
        BOTH the dict and the instance. Keeping the two in sync avoids
        a class of bugs where a later .save() sees one value and an
        already-emitted dict has another.

        v3.7 — courtesy local derivation. Server still owns derivation
        for persisted records.
        """
        cfg = self._DERIVE_CONFIG or {}
        if not cfg:
            return
        for py_field in list(cfg.keys()):
            json_field = (self._py_to_json_map or {}).get(py_field, py_field)
            current_in_data = data.get(json_field)
            if current_in_data:
                continue  # already populated, nothing to do
            computed = self._compute_name_from_derive(py_field)
            if computed is None:
                continue  # cannot derive (source missing) — let validation report it
            data[json_field] = computed
            # Mirror onto the instance so subsequent reads agree.
            # IMPORTANT: bypass __setattr__ — its name-normalization path would
            # diverge from the server's compute_name (server does no
            # normalization on derived values). object.__setattr__ skips the
            # override entirely so client and server agree on the value.
            try:
                object.__setattr__(self, py_field, computed)
                # Still mark the field as a pending update so partial-update
                # to_dict_for_update() includes it.
                if hasattr(self, '_pending_field_updates') and isinstance(
                    self._pending_field_updates, set
                ):
                    self._pending_field_updates.add(py_field)
            except Exception:
                # Setting attributes can fire normalization paths; if any
                # of those raise, we still leave `data` populated so the
                # outgoing record is consistent.
                pass

    def _validate_mandatory_fields(self):
        """
        Validate that all mandatory fields are set with non-None values.
        
        Called by to_dict(validate=True) before CREATE operations.
        
        Raises:
            ValueError: If any mandatory fields are missing or None
        """
        missing = []
        
        # Check each field in type metadata
        if hasattr(self, '_type_metadata'):
            for field_name, metadata in self._type_metadata.items():
                if metadata.get('mandatory'):
                    value = getattr(self, field_name, None)

                    # v3.7: derived fields can be empty IFF derivation can fill
                    # them in (server will do so authoritatively). We only
                    # soft-pass when client-side derivation actually succeeds —
                    # otherwise the user still gets a clear error here, before
                    # ever hitting the wire.
                    is_empty = (
                        value is None
                        or (isinstance(value, str) and not value.strip())
                    )
                    if is_empty and metadata.get('derived'):
                        if self._compute_name_from_derive(field_name) is not None:
                            continue  # would-be filled — let it pass

                    # Check if value is None or empty
                    if value is None:
                        missing.append(field_name)
                    # For strings, check if empty
                    elif isinstance(value, str) and not value.strip():
                        missing.append(field_name)
        
        # Raise error if any mandatory fields are missing
        if missing:
            raise ValueError(
                f"Cannot serialize {self.__class__.__name__}: "
                f"Missing mandatory fields: {', '.join(missing)}. "
                f"Please set these fields before calling to_dict(validate=True)."
            )

    @classmethod
    def _get_type_for_attribute(cls, py_key):
        """Get the type class for a given attribute."""
        type_info = cls._type_metadata.get(py_key)
        if not type_info:
            return None, False, False
            
        type_name = type_info.get('type')
        is_list = type_info.get('is_list', False)
        
        if not type_name:
            return None, False, False
            
        builtin_types = {
            'string': str, 'str': str, 'int': int, 'integer': int,
            'float': float, 'bool': bool, 'boolean': bool,
            'list': list, 'dict': dict, 'uuid': str, 'date': str, 'datetime': str
        }
        
        if type_name.lower() in builtin_types:
            return builtin_types[type_name.lower()], is_list, False
            
        try:
            import inflection
            import importlib
            snake_type_name = inflection.underscore(type_name)
            
            # PATCH_resolver_package_prefix_v1
            # Derive the package root from cls.__module__ so the resolver
            # works for ALL generated packages (pymodel_system,
            # pymodel_<tenant>, etc.), not just the literal 'pymodel'.
            #
            # cls.__module__ is e.g. 'pymodel_system.objects.domain'.
            # We strip the '.objects.<modname>' tail to get the package
            # root ('pymodel_system'). The split is anchored on
            # '.objects.' because every generated class lives there.
            #
            # As a safety net we also try the legacy 'pymodel.*' paths
            # last, so anything still importing the old layout keeps
            # working during a transition.
            _pkg_root = cls.__module__.rsplit('.objects.', 1)[0]
            import_paths = [
                f'{_pkg_root}.enums.{snake_type_name}',
                f'{_pkg_root}.types.{snake_type_name}',
                f'{_pkg_root}.objects.{snake_type_name}',
                # Legacy fallback — keep last so it only fires when the
                # package-root paths above all miss.
                f'pymodel.enums.{snake_type_name}',
                f'pymodel.types.{snake_type_name}',
                f'pymodel.objects.{snake_type_name}',
            ]
            
            for i, import_path in enumerate(import_paths):
                try:
                    module = importlib.import_module(import_path)
                    type_class = getattr(module, type_name, None)
                    if type_class:
                        # Detect enum by inspecting which sub-path matched,
                        # not by index — the import_paths list is now
                        # mixed (package_root + legacy fallback).
                        is_enum = '.enums.' in import_path
                        return type_class, is_list, is_enum
                except (ImportError, AttributeError):
                    continue
                    
        except Exception:
            pass
            
        return None, is_list, False

    @classmethod
    def _deserialize_value(cls, value, target_type, is_list=False, is_enum=False, field_name="unknown", type_name="unknown"):
        """Deserialize a value to the target type with STRICT type checking and datetime support."""
        if value is None:
            return [] if is_list else None
        
        if type_name.lower() in ['datetime', 'date']:
            if is_list:
                if not isinstance(value, list):
                    raise ObjectDeserializationError(
                        f"Expected list for datetime field '{field_name}', got {type(value).__name__}",
                        obj_type=cls.__name__, attribute=field_name, value=value
                    )
                return [cls._parse_datetime(item) for item in value]
            else:
                return cls._parse_datetime(value)
            
        builtin_types = {str, int, float, bool, list, dict}
        
        if is_list:
            if not isinstance(value, list):
                raise ObjectDeserializationError(
                    f"Expected list for field '{field_name}', got {type(value).__name__}",
                    obj_type=cls.__name__, attribute=field_name, value=value
                )
                
            if not value:
                return []
                
            if target_type is None:
                import inflection
                raise ObjectDeserializationError(
                    f"CRITICAL: Cannot deserialize list field '{field_name}' - type '{type_name}' not found. "
                    f"Check if {cls.__module__.rsplit('.objects.', 1)[0]}.types.{inflection.underscore(type_name)}.py exists with class {type_name}.",
                    obj_type=cls.__name__, attribute=field_name, value=f"List with {len(value)} items"
                )
            
            if target_type in builtin_types:
                # Auto-coerce JSON strings to dict for json/map/dict list items
                if target_type == dict:
                    import json
                    coerced = []
                    for item in value:
                        if isinstance(item, str):
                            try:
                                parsed = json.loads(item)
                                coerced.append(parsed if isinstance(parsed, dict) else item)
                            except (json.JSONDecodeError, TypeError):
                                coerced.append(item)
                        else:
                            coerced.append(item)
                    return coerced
                return value
            elif hasattr(target_type, 'from_dict'):
                deserialized_items = []
                for i, item in enumerate(value):
                    try:
                        if is_enum:
                            if isinstance(item, str):
                                deserialized_items.append(target_type(item))
                            else:
                                raise ObjectDeserializationError(
                                    f"Expected string for enum list item {i} in field '{field_name}', got {type(item).__name__}",
                                    obj_type=cls.__name__, attribute=f"{field_name}[{i}]", value=item
                                )
                        else:
                            if isinstance(item, dict):
                                deserialized_items.append(target_type.from_dict(item))
                            else:
                                raise ObjectDeserializationError(
                                    f"Expected dict for custom type list item {i} in field '{field_name}', got {type(item).__name__}",
                                    obj_type=cls.__name__, attribute=f"{field_name}[{i}]", value=item
                                )
                    except Exception as e:
                        raise ObjectDeserializationError(
                            f"Failed to deserialize list item {i} in field '{field_name}' to {target_type.__name__}: {str(e)}",
                            obj_type=cls.__name__, attribute=f"{field_name}[{i}]", value=item, original_error=e
                        )
                return deserialized_items
            else:
                raise ObjectDeserializationError(
                    f"CRITICAL: Type '{type_name}' found for field '{field_name}' but has no from_dict() method.",
                    obj_type=cls.__name__, attribute=field_name, value=f"Type: {target_type}"
                )
        else:
            if target_type is None:
                if type_name not in ['string', 'int', 'bool', 'float']:
                    try:
                        import logging
                        logging.getLogger(__name__).warning(
                            f"Could not find type '{type_name}' for field '{field_name}' in {cls.__name__}."
                        )
                    except:
                        pass
                return value

            if target_type in builtin_types:
                # Auto-coerce JSON string to dict for json/map/dict fields
                if target_type == dict and isinstance(value, str):
                    try:
                        import json
                        parsed = json.loads(value)
                        if isinstance(parsed, dict):
                            return parsed
                    except (json.JSONDecodeError, TypeError):
                        pass
                return value   
            elif hasattr(target_type, 'from_dict'):
                try:
                    if is_enum:
                        if isinstance(value, str):
                            return target_type(value)
                        else:
                            raise ObjectDeserializationError(
                                f"Expected string for enum field '{field_name}', got {type(value).__name__}",
                                obj_type=cls.__name__, attribute=field_name, value=value
                            )
                    else:
                        if isinstance(value, dict):
                            return target_type.from_dict(value)
                        else:
                            raise ObjectDeserializationError(
                                f"Expected dict for custom type field '{field_name}', got {type(value).__name__}",
                                obj_type=cls.__name__, attribute=field_name, value=value
                            )
                except Exception as e:
                    raise ObjectDeserializationError(
                        f"Failed to deserialize field '{field_name}' to {target_type.__name__}: {str(e)}",
                        obj_type=cls.__name__, attribute=field_name, value=value, original_error=e
                    )
            else:
                return value

    @classmethod
    def _find_field_value(cls, py_key, data):
        """Find a field value in data using multiple naming conventions."""
        import inflection
        field_variations = [
            py_key,
            py_key.replace('_', '-'),
            inflection.dasherize(py_key),
            inflection.underscore(py_key),
        ]
        
        field_variations = list(dict.fromkeys(field_variations))
        
        for variation in field_variations:
            if variation in data:
                return variation, data[variation]
        
        return None, None

    @classmethod
    def from_dict(cls, data):
        """
        Creates an instance from a dictionary, handling nested objects.
        ENHANCED: Automatically converts datetime strings to datetime objects.
        ENHANCED: Derives name from fq_name if missing, validates if both present.
        FLEXIBLE MODE: Accepts multiple field naming conventions.
        """
        if data is None:
            return cls.from_empty()
            
        if not isinstance(data, dict):
            raise ObjectDeserializationError(
                f"Expected dict or None for {cls.__name__} deserialization, got {type(data).__name__}",
                obj_type=cls.__name__, value=data
            )

        if not data:
            return cls.from_empty()

        # NEW: Auto-derive name from fq_name if missing, or validate if both present
        if 'fq_name' in data:
            fq_name = data.get('fq_name')
            if fq_name and isinstance(fq_name, list) and len(fq_name) > 0:
                expected_name = fq_name[-1]
                
                if 'name' in data:
                    # Both present - validate they match
                    provided_name = data['name']
                    if provided_name != expected_name:
                        raise ObjectDeserializationError(
                            f"Name mismatch in {cls.__name__}: 'name' field is '{provided_name}' but "
                            f"fq_name[-1] is '{expected_name}'. They must match.",
                            obj_type=cls.__name__, value=data
                        )
                else:
                    # Only fq_name present - auto-derive name
                    data = data.copy()  # Don't modify original
                    data['name'] = expected_name

        temp_instance = cls.from_empty()
        init_args = {}
        back_refs = {}
        ref_link_data = {}  # NEW: Store extracted link_data
        
        processed_fields = set()
        deserialization_failures = []
        
        for json_key, value in data.items():
            try:
                # NEW: Extract link_data from references
                if json_key.endswith('_refs') or json_key.endswith('-refs'):
                    if isinstance(value, list):
                        # Check each reference for link_data
                        clean_refs = []
                        for ref in value:
                            if isinstance(ref, dict):
                                ref_copy = ref.copy()
                                # Extract and store link_data
                                if 'link_data' in ref_copy:
                                    uuid = ref_copy.get('uuid')
                                    if uuid:
                                        ref_link_data[uuid] = ref_copy.pop('link_data')
                                clean_refs.append(ref_copy)
                            else:
                                clean_refs.append(ref)
                        value = clean_refs
                
                if (json_key.endswith('_back_refs') or json_key.endswith('_refs') or '_back_refs' in json_key):
                    back_refs[json_key] = value
                    continue
                    
                py_key = None
                py_key = temp_instance._json_to_py_map.get(json_key)
                
                if not py_key:
                    import inflection
                    potential_py_key = inflection.underscore(json_key)
                    if potential_py_key in cls._type_metadata:
                        py_key = potential_py_key
                
                if not py_key and json_key in cls._type_metadata:
                    py_key = json_key
                
                if not py_key:
                    for metadata_py_key in cls._type_metadata.keys():
                        field_name_found, _ = cls._find_field_value(metadata_py_key, {json_key: value})
                        if field_name_found:
                            py_key = metadata_py_key
                            break
                
                if py_key in ['parent_type', 'obj_type']:
                    continue
                
                if py_key in processed_fields:
                    continue
                    
                if py_key:
                    processed_fields.add(py_key)
                    
                    type_info = cls._get_type_for_attribute(py_key)
                    if type_info:
                        target_type, is_list, is_enum = type_info
                        original_type_name = cls._type_metadata.get(py_key, {}).get('type', 'unknown')
                        try:
                            deserialized_value = cls._deserialize_value(
                                value, target_type, is_list, is_enum,
                                field_name=json_key, type_name=original_type_name
                            )
                            init_args[py_key] = deserialized_value
                        except Exception as e:
                            deserialization_failures.append(f"Field '{json_key}' (Python: '{py_key}'): {str(e)}")
                    else:
                        init_args[py_key] = value
                    
            except Exception:
                pass

        if deserialization_failures:
            detailed_error = (
                f"DESERIALIZATION FAILED for {cls.__name__}: Field conversion errors: "
                f"{'; '.join(deserialization_failures)}."
            )
            raise ObjectDeserializationError(
                detailed_error, obj_type=cls.__name__,
                attribute=deserialization_failures[0].split("'")[1] if deserialization_failures else None,
                value=data, original_error=Exception("Field conversion failures")
            )

        try:
            instance = cls(**init_args)
        except TypeError as e:
            detailed_error = (
                f"OBJECT CONSTRUCTION FAILED for {cls.__name__}: Constructor rejected arguments. "
                f"Provided args: {list(init_args.keys())}. Error: {str(e)}."
            )
            raise ObjectDeserializationError(
                detailed_error, obj_type=cls.__name__, value=init_args, original_error=e
            )
        except Exception as e:
            detailed_error = f"OBJECT CONSTRUCTION FAILED for {cls.__name__}: {str(e)}"
            raise ObjectDeserializationError(
                detailed_error, obj_type=cls.__name__, value=init_args, original_error=e
            )
        
        # NEW: Attach extracted link_data to instance
        if ref_link_data:
            instance._ref_link_data = ref_link_data
        
        for ref_name, ref_value in back_refs.items():
            try:
                setattr(instance, ref_name, ref_value)
            except Exception:
                pass


        # Update pending field updates for all fields present in the data
        for json_key, value in data.items():
            py_key = instance._json_to_py_map.get(json_key)
            if py_key and py_key not in ['parent_type', 'obj_type']:
                instance._pending_field_updates.add(py_key)

        return instance

    @classmethod
    def from_mandatory(cls, name: str):
        """Creates an instance with only mandatory fields."""
        mandatory_args = {k: v for k, v in locals().items() if k != 'cls'}
        return cls(**mandatory_args)

    @classmethod
    def from_empty(cls):
        """Creates an empty instance with no fields set, providing defaults for mandatory fields."""
        return cls(name="", uuid=None, fq_name=None, parent_uuid=None, display_name=None, description=None, created_by=None, created_at=None, updated_at=None, plan_code=None, plan_version=None, status=None, subscription_type=None, billing_cycle=None, pricing_currency=None, current_period_start=None, current_period_end=None, trial_start=None, trial_end=None, activated_at=None, canceled_at=None, cancel_at_period_end=None, cancel_reason=None, cancel_feedback=None, quantity=None, discount_percent=None, discount_code=None, discount_expires_at=None, overage_handling_override=None, limit_overrides=None, grandfathered_limits=None, stripe_customer_id=None, stripe_subscription_id=None, stripe_price_id=None, payment_provider=None, auto_renew=None, payment_failed_count=None, grace_period_end=None, last_invoice_at=None, next_invoice_at=None, lifetime_value_cents=None, metadata=None)

PlatformBillingSubscription=PlatformBillingSubscription
PlatformBillingSubscription=PlatformBillingSubscription
PlatformBillingSubscription=PlatformBillingSubscription
platform_billing_subscription=PlatformBillingSubscription
