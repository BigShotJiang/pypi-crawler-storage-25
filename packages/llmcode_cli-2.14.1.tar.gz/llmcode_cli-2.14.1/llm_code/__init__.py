"""llm-code: CLI coding agent for local LLMs."""
__version__ = "2.14.1"
