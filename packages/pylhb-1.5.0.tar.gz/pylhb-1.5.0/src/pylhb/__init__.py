import argparse
import platform
# Mr.Lee's Module
from .myini import MyINI
from .myjson import MyJSON
from .mylog import MyLog
from .mymssql import MyMSSQL
from .mysqlite import MySQLite
from .mycipher import MyAsymClipher,MyXORCipher,MyFernetCipher,MyBlowfishCipher
from .mysnowflake import MySnowflake
from .mydevice import MyDevice
from .myemail import MyEmail
from .myfile import MyFile
from .mydownload import MyDownload
# 导出列表
__all__ = []
if platform.system()=="Windows":
    from .mysubscribe import MySubscribe
    from .myiis import MyIIS
    from .myreg import MyReg
    __all__.extend(["MySubscribe", "MyIIS", "MyReg"])

# 跨平台通用接口
__all__.append([
    "MyINI",
    "MyJSON",
    "MyLog",
    "MyMSSQL",
    "MySQLite",
    "MyAsymClipher",
    "MyXORCipher",
    "MyFernetCipher",
    "MyBlowfishCipher",
    "MySnowflake",
    "MyDevice",
    "MySubscribe",
    "MyIIS",
    "MyReg",
    "MyEmail",
    "MyFile",
    "MyDownload"
])

def main() -> None:
    parser = argparse.ArgumentParser(description="Mr.Lee's Helpers")
    parser.add_argument('--version', action='store_true', help='show version')
    parser.add_argument('--deviceinfos', action='store_true', help='show device infomations')
    args = parser.parse_args()

    # show version
    if args.version:
        try:
            from importlib.metadata import version, PackageNotFoundError
            # 直接从包元数据获取版本号
            ver = version("pylhb")
            print(f"pylhb {ver}")
        except PackageNotFoundError:
            print("Package not found.")
        except ImportError:
            print("Package not found.")
        except:
            print("Package not found.")
        return
        
    # show device infomations
    if args.deviceinfos:
        d=MyDevice()
        print(f"系统: {platform.system()} {platform.release()}")
        print(f"系统版本: {platform.version()}")
        print(f"架构: {platform.machine()}")
        print(f"处理器: {platform.processor()}")
        print(f"主机名: {platform.node()}")
        print(f"IP地址: {d.getLocalIP()}")
        print(f"设备ID: {d.getDeviceID()}")
        print(f"Python版本: {platform.python_version()}")
        return

if __name__ == '__main__':
    main()