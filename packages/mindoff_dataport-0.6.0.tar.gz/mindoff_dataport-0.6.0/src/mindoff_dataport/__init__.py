﻿from __future__ import annotations

from types import SimpleNamespace
from typing import Any, Literal

from .bundle import (
    ReportBundle,
    compile_report_bundle as _compile_report_bundle_impl,
)
from .extractor import extract_template as _extract_template_impl
from .repeat import RepeatRecords, repeat_records
from .schema import WorkbookSchema
from .template_contract import get_template_inputs as _get_template_inputs_impl
from .xlsx_renderer import export_report_bundle as _export_report_bundle_impl

__all__ = [
    "ReportBundle",
    "RepeatRecords",
    "extract_template",
    "get_template_inputs",
    "compile_report_bundle",
    "export_report_bundle",
    "repeat_records",
    "extract",
    "inputs",
    "compile",
    "export",
    "mo_dataport",
]

# §1. Constants & Exceptions

# §2. Classes and Sub Classes

# §3. Private Helper Functions

# §4. Public Functions


def extract_template(path: str) -> WorkbookSchema:
    return _extract_template_impl(path)


def get_template_inputs(template: WorkbookSchema) -> dict[str, Any]:
    return _get_template_inputs_impl(template)


def compile_report_bundle(
    template: WorkbookSchema,
    data: dict[str, Any],
    bundle_path: str | None = None,
    dataframe_options: dict[str, Any] | None = None,
    dataframe_shift: Literal["both", "horizontal", "vertical", "none"] = "both",
) -> ReportBundle:
    return _compile_report_bundle_impl(
        template,
        data,
        bundle_path=bundle_path,
        dataframe_options=dataframe_options,
        dataframe_shift=dataframe_shift,
    )


def export_report_bundle(
    bundle_or_path: ReportBundle | str,
    output_path: str,
    format: Literal["xlsx", "pdf", "image"] = "xlsx",
    **options: Any,
) -> None | list[str]:
    return _export_report_bundle_impl(
        bundle_or_path,
        output_path,
        format=format,
        **options,
    )


extract = extract_template
inputs = get_template_inputs
compile = compile_report_bundle
export = export_report_bundle

mo_dataport = SimpleNamespace(
    extract=extract_template,
    inputs=get_template_inputs,
    compile=compile_report_bundle,
    export=export_report_bundle,
    repeat_records=repeat_records,
)


# §5. Entrypoints
