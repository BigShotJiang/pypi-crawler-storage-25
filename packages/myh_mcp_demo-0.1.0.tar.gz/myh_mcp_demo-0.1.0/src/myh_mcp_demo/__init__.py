from mcp.server.fastmcp import FastMCP

mcp = FastMCP(name="myh-mcp-demo")

@mcp.tool
def hello(name: str) -> str:
    return f"Hello, {name}!"

@mcp.tool
def goodbye(name: str) -> str:
    return f"Goodbye, {name}!"

def main() -> None:
    mcp.run(transport="stdio")
