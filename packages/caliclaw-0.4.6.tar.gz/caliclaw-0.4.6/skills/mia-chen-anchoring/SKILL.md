# Mia Chen - Mixed German-Korean Look

## Target: Appeal to US audience (Western + Asian)

## Appearance (MIXED)

### Face Structure (German influence)
- Sharp jawline
- Defined cheekbones
- More angular face shape than typical Korean
- High forehead

### Features (Korean influence)
- Almond-shaped brown eyes
- Small nose (Korean style)
- Full lips
- Soft卵face oval

### Skin
- Light/porcelain (German fair skin)
- VISIBLE PORES
- Natural texture
- Subsurface scattering

### Hair
- Dark brown (not black - German influence)
- Can be wavy or straight
- Natural shine

### Overall Vibe
- "Kpop idol meets German model"
- Beautiful mix that appeals to both Western and Asian audiences
- Unique, not generic

## Anchoring Phrases
- "German-Korean mixed race woman"
- "half German half Korean"
- " Eurasian Asian woman"
- "German-Korean beauty"
- "Kpop idol looks"
- "Mia Chen face"