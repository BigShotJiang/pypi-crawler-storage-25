# CHECKER Vision Skill - With Reference Training

## Trigger
- "анализ", "посмотри", "check", "оцени", "checker", "анализируй"
- Image file path or URL provided

## Reference Photos (REALISM STANDARD)
These are the reference photos to compare against - they represent MAXIMUM REALISM:

1. **file_45** - Blonde woman with flowers, professional portrait
2. **file_46** - Dark hair, studio lighting
3. **file_47** - Close-up portrait, realistic skin
4. **file_48** - Various poses
5. **file_49** - Different lighting
6. **file_50** - Portrait style
7. **file_51** - Studio shot
8. **file_52** - Close-up
9. **file_53** - Various

## Reference Characteristics (What Makes Photos Real)
From analyzing the reference photos:
- **Skin**: Real pores visible, natural texture, subsurface scattering, micro-variations in tone
- **Eyes**: Real veins, detailed iris, natural catchlights (not synthetic)
- **Hair**: Real strand separation, natural shine, individual strands visible
- **Lighting**: Natural shadows, rim light, not flat/soft
- **Imperfections**: Freckles, moles, slight asymmetries - authentic
- **No artifacts**: No waxy skin, no plastic sheen, no duplicated features

## Description
CHECKER analyzes AI images against the REAL PHOTO standard. If AI image doesn't match reference realism - REJECT.

## How it works
1. User sends image or path
2. Compare against reference characteristics above
3. Score based on how close to REAL photo quality
4. Key question: "Would this pass as a real photo like the references?"

## Scoring Guide
- **9-10/10**: Indistinguishable from real photo ✅ APPROVE
- **7-8/10**: Close, minor issues (can fix with better prompts)
- **5-6/10**: AI artifacts visible (waxy skin, plastic look)
- **<5/10**: Clear AI generation, major issues ❌ REJECT

## Common AI Issues (Compare to References)
- Smooth/poreless skin (references have pores)
- Plastic/waxy sheen (references have natural texture)
- Flat lighting (references have rim light, shadows)
- Synthetic eyes (references have detailed iris, veins)
- Perfect symmetry (references have natural asymmetries)
- No imperfections (references have freckles, moles)

## Usage
```
Анализируй это изображение
Check quality: /path/to/image.jpg
```

## Output Format
```
Skin: [realistic/poreless/waxy]
Eyes: [realistic/synthetic]
Face: [symmetrical/duplicated]
Realism Score: X/10
Verdict: APPROVE/REJECT
```
