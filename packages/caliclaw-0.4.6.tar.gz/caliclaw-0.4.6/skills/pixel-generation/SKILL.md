# PIXEL Generation Skill - Realistic Portrait Expert

## Mission
Generate hyper-realistic AI images that match REAL PHOTO quality (like reference photos user provided).

## Reference Photos (REALISM STANDARD)
User sent 9 real photos that represent MAXIMUM REALISM:
- file_45-53: Real DSLR portraits with authentic skin, eyes, hair, lighting

## What Makes Photos Real (Use These in Prompts)
Based on reference analysis:

### Skin (CRITICAL)
- VISIBLE PORES - not smooth/poreless
- Natural texture - not airbrushed/waxy
- Subsurface scattering - light penetrates skin
- Micro-variations in tone
- Freckles, moles, slight imperfections
- Natural oil sheen

### Eyes
- Real veins in iris
- Detailed iris pattern (not just circles)
- Natural catchlights (not synthetic)
- Not too perfect/shiny

### Hair
- Real strand separation
- Individual strands visible
- Natural shine (not plastic)
- Random imperfections

### Lighting
- Rim light (backlight on hair/shoulders)
- Natural shadows (not flat)
- Three-dimensional depth
- Not soft/dreamy

### Face
- Natural asymmetries (not perfect symmetry)
- Slight imperfections
- Realistic proportions

## PROMPT TEMPLATE for Realistic Portraits
```
[CHARACTER], professional portrait photo, [DETAILED SKIN], VISIBLE PORES, natural skin texture, subsurface scattering, [REALISTIC EYES], detailed iris, natural catchlights, [NATURAL HAIR], strand detail, [DYNAMIC LIGHTING], rim light, natural shadows, depth, 8k, DSLR quality, [REFERENCE QUALITY]
```

## Key Phrases to ADD
- "visible pores"
- "skin texture"
- "subsurface scattering"
- "realistic iris detail"
- "natural catchlights"
- "rim lighting"
- "film grain"
- "DSLR camera"
- "natural imperfections"

## Key Phrases to AVOID
- "smooth skin"
- "poreless"
- "perfect"
- "beautiful lighting"
- "soft focus"
- "bokeh dreamy"
- "airbrushed"
- "plastic"

## Character: Mia Chen
- Asian woman, 20s
- Dark brown hair
- Brown eyes
- Porcelain/light skin tone

## Generation Settings (CivitAI)

### Primary Models (in priority order):
1. **Beautiful Realistic Asians** (ID: 25494) - BEST for Asian faces
   - 492K downloads
   - Base: SD 1.5
   - Use for: Asian women portraits

2. **Realistic Vision V6.0** (ID: 4201) - Current default
   - 2.1M downloads  
   - Base: SD 1.5 Hyper
   - Use for: General realism

### LoRAs (if API supports):
- **Detail Tweaker** (ID: 58390) - enhances skin details
- **Add More Details** (ID: 82098) - more realistic texture
