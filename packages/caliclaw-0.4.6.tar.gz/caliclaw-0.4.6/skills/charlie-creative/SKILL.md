# CHARLIE Creative Skill - Realistic Portrait Prompts

## Mission
Create beautiful, hyper-realistic prompts that match REAL PHOTO quality.

## Reference Photos
User sent 9 REAL photos (DSLR quality). These are the STANDARD to match:
- Professional portraits with visible pores
- Natural skin texture
- Realistic eyes with iris detail
- Real strand hair
- Rim lighting, natural shadows

## Reference Characteristics (Your Knowledge Base)

### Skin - THE MOST IMPORTANT
- REAL pores visible (not smooth!)
- Natural texture with micro-variations
- Subsurface scattering effect
- Freckles, moles, imperfections OK
- Natural oil/glow (not plastic)
- NOT airbrushed, NOT poreless

### Eyes
- Detailed iris with real pattern
- Natural catchlights (not synthetic circles)
- Real veins visible
- Not too shiny/perfect

### Hair  
- Individual strand separation
- Natural shine
- Random flyaways OK
- NOT plastic-looking

### Lighting
- Rim light on hair/shoulders
- Natural shadows (not flat)
- Three-dimensional depth
- NOT soft/dreamy/bokeh-heavy

### Face
- Natural slight asymmetries
- Realistic proportions
- NOT perfect symmetry

## Prompt Structure for Realism

**Positive (must include):**
- "visible pores"
- "skin texture" 
- "subsurface scattering"
- "realistic iris"
- "natural catchlights"
- "rim light"
- "natural shadows"
- "DSLR quality"
- "film grain"
- "hyper-detailed"

**Negative (must include):**
- "smooth skin"
- "poreless"
- "plastic skin"
- "airbrushed"
- "perfect skin"
- "anime"
- "cartoon"
- "3d render"
- "watermark"

## Character Template
**Mia Chen:**
- Asian woman, 20s
- Dark brown hair
- Brown eyes  
- Light/porcelain skin
- Natural beauty

## Example Prompts (GOOD)

**Style 1 - Natural:**
"Portrait of Mia Chen, Asian woman 20s, visible pores on skin, natural skin texture, subsurface scattering, detailed brown eyes with realistic iris, natural catchlights, dark brown hair with strand detail, rim lighting, natural shadows, DSLR, film grain, hyper-realistic, 8k"

**Style 2 - Studio:**
"Professional portrait photo of Mia Chen, highly detailed skin with visible pores, realistic texture, no airbrushing, brown eyes with depth and veins, natural lighting setup, rim light, soft shadows, Canon 85mm, studio portrait, photo-realistic"

## Output Format
Return ONLY the prompt (no explanations). Make it detailed but focused on REALISM.
