---
name: civitai-ai-art
description: Полная интеграция с CivitAI — платформой для генерации AI-изображений. Поиск моделей, лор, промптов, генерация изображений (включая 18+ контент). Используйте для создания креативов для моделей, аниме-арта, персонажей и NSFW-контента.
---

# CivitAI AI Art Generation — Полное руководство

CivitAI — это крупнейшая платформа для моделей Stable Diffusion, где сообщество делится:
- **Checkpoint моделями** (основные модели для генерации)
- **LoRA** (легкие адаптеры для стилей, персонажей)
- **Textual Inversion** (встраивания)
- **ControlNet** (контроль поз, композиции)
- **Промптами** и примерами изображений
- **NSFW (18+) контентом** (при наличии соответствующих разрешений)

## 🎯 **Для чего нам CivitAI?**

1. **Поиск вдохновения** — тысячи промптов и примеров для генерации "сексуальных креативов для модели"
2. **Использование специализированных моделей** — NSFW-модели, аниме-стили, фотореалистичные модели
3. **Использование LoRA** — добавление конкретных стилей, персонажей, костюмов
4. **Создание собственного контента** — генерация 18+ контента для моделей
5. **Обучение агента** — агент по креативу может автоматически искать лучшие модели и промпты

## 🔑 **Предварительные требования**

### 1. API Токен CivitAI
Токен уже есть в `.env` файле:
```bash
CIVITAI_API_TOKEN=826fb76c8b71cb094829e16b3fa76ea4
```

### 2. Node.js 18+
```bash
node --version  # Должно быть 18+
```

### 3. Установленные пакеты
```bash
npm install civitai
```

## 📚 **Структура CivitAI**

### **Модели (Models)**
- **Checkpoint** — полные модели Stable Diffusion (SDXL, SD1.5, SD3)
- **LoRA** — легкие адаптеры (обычно 10-200MB)
- **Textual Inversion** — текстовые вложения
- **ControlNet** — модели контроля позы/композиции
- **VAE** — вариационные автоэнкодеры

### **Теги и категории**
- **SFW** — безопасный для работы контент
- **NSFW** — контент для взрослых (18+)
- **Anime** — аниме-стиль
- **Realistic** — фотореалистичный стиль
- **Character** — конкретные персонажи
- **Style** — художественные стили

## 🔍 **Поиск моделей и ресурсов**

### **Через публичный API (без токена)**
```bash
# Поиск моделей (пример)
curl "https://civitai.com/api/v1/models?limit=10&types=Checkpoint&nsfw=true"
```

### **Параметры поиска API**
| Параметр | Описание | Пример |
|----------|----------|--------|
| `limit` | Количество результатов | `?limit=20` |
| `page` | Страница | `?page=2` |
| `types` | Тип модели | `?types=Checkpoint,LoRA` |
| `nsfw` | NSFW контент | `?nsfw=true` или `?nsfw=false` |
| `query` | Поисковый запрос | `?query=anime+girl` |
| `sort` | Сортировка | `?sort=Highest+Rated` |
| `period` | Период | `?period=Month` |

### **Скрипт для поиска моделей**
```bash
node scripts/search_models.js --query "sexy model" --nsfw true --type Checkpoint
```

## 🚀 **Генерация изображений**

### **Базовый пример**
```bash
node scripts/get_illust.js \
  --prompt "sexy fashion model, evening gown, cinematic lighting, professional photoshoot, detailed face, perfect skin" \
  --negative "bad quality, worst quality, deformed, blurry" \
  --width 832 \
  --height 1216 \
  --steps 25 \
  --cfg-scale 6 \
  --output model_fashion.png
```

### **С NSFW-моделью**
1. Найдите NSFW-модель через API:
   ```bash
   node scripts/search_models.js --nsfw true --type Checkpoint --query "realistic"
   ```

2. Используйте её URN для генерации:
   ```bash
   node scripts/get_illust.js \
     --model "urn:air:sdxl:checkpoint:civitai:123456@789012" \
     --prompt "nsfw, sexy model, nude, professional photography, beautiful lighting" \
     --negative "clothed, dressed, underwear" \
     --output nsfw_model.png
   ```

### **С LoRA для конкретного стиля**
```bash
node scripts/get_illust.js \
  --prompt "sexy model, beach, bikini, sunset, professional photo" \
  --lora "urn:air:sdxl:lora:civitai:162141@182559,0.8" \
  --lora "urn:air:sdxl:lora:civitai:176425@198856,0.6" \
  --output beach_model.png
```

## 🧠 **Работа с промптами**

### **Как находить хорошие промпты на CivitAI**
1. **Исследуйте изображения** — у каждого изображения есть промпт
2. **Копируйте промпты** с высоко оцененных изображений
3. **Комбинируйте элементы** из разных промптов
4. **Используйте теги** — `masterpiece, best quality, detailed, 8k`

### **Структура промпта для моделей**
```
[качество], [субъект], [одежда], [фон], [освещение], [стиль], [детали]

Пример:
masterpiece, best quality, 8k, ultra detailed, 
sexy fashion model, slim body, beautiful face, perfect skin,
black evening gown, high slit, jewelry,
studio lighting, cinematic, professional photoshoot,
detailed eyes, detailed hair, sensual pose
```

### **Негативный промпт (что исключать)**
```
bad quality, worst quality, low quality, normal quality,
deformed, distorted, disfigured, mutated hands, mutated fingers,
extra limbs, missing limbs, floating limbs, disconnected limbs,
malformed hands, ugly, disgusting, poorly drawn, childish,
blurry, watermark, signature, text, error, extra digit, fewer digits
```

## ⚡ **Оптимизация для 18+ контента**

### **Настройки для NSFW**
```javascript
{
  "steps": 28,                    // Больше шагов = лучше качество
  "cfgScale": 6,                  // Баланс между креативностью и соответствием промпту
  "sampler": "Euler a",           // Хороший баланс скорости/качества
  "width": 832,                   // SDXL оптимальный размер
  "height": 1216,                 // Портретная ориентация
  "clipSkip": 2                   // Пропуск слоёв CLIP
}
```

### **Теги для NSFW промптов**
- `nsfw` — общий тег
- `nude` — обнажённая натура
- `sexy` — сексуальный контент
- `erotic` — эротический
- `sensual` — чувственный
- `provocative` — провокационный

## 🔧 **Интеграция с агентом по креативу**

### **Автоматический workflow агента**
1. **Поиск моделей** — по запросу пользователя (например, "sexy model NSFW")
2. **Выбор лучшей модели** — по рейтингу, количеству загрузок
3. **Поиск промптов** — для выбранной модели
4. **Генерация вариантов** — с разными промптами, сидами
5. **Отбор лучших результатов** — оценка качества

### **Скрипты для агента**
- `search_models.js` — поиск моделей по критериям
- `get_model_details.js` — получение деталей модели (примеры изображений, промпты)
- `generate_variations.js` — генерация нескольких вариантов
- `batch_generate.js` — пакетная генерация

## 📊 **Примеры запросов для агента**

### **По-русски (голосовые команды)**
1. "Найди NSFW модель для фотореалистичных девушек"
2. "Сгенерируй 5 вариантов сексуальной модели в купальнике"
3. "Используй аниме-стиль для создания персонажа"
4. "Создай эротический контент с красивым освещением"

### **Команды в чате**
```
/search model --query "realistic female" --nsfw true --type Checkpoint
/generate --prompt "sexy model beach" --model-id 123456 --variations 4
/batch --prompts-file prompts.txt --output-dir ./results
```

## ⚠️ **Важные ограничения**

### **Политика контента**
- **NSFW разрешён** но с ограничениями
- **Запрещён незаконный контент** (несовершеннолетние, насилие)
- **Соблюдайте правила сообщества**

### **Технические ограничения**
- **Лимиты генерации** — зависит от вашего аккаунта
- **Размер изображений** — до 1024x1024 для SD1.5, до 2048x2048 для SDXL
- **Время генерации** — 10-60 секунд в зависимости от сложности

### **Рекомендации**
- **Используйте SDXL** для лучшего качества
- **Добавляйте LoRA** для специфических стилей
- **Экспериментируйте с сидами** для воспроизводимости
- **Сохраняйте промпты** для повторного использования

## 🚀 **Быстрый старт**

### **1. Поиск модели для "сексуальных креативов"**
```bash
node scripts/search_models.js \
  --query "fashion model" \
  --nsfw true \
  --type Checkpoint \
  --sort "Highest Rated" \
  --limit 5
```

### **2. Генерация с выбранной моделью**
```bash
node scripts/get_illust.js \
  --model "urn:air:sdxl:checkpoint:civitai:827184@2514310" \
  --prompt "masterpiece, best quality, 8k, ultra detailed, sexy fashion model, slim body, beautiful face, perfect skin, black dress, studio lighting, professional photoshoot, detailed eyes, sensual pose" \
  --negative "bad quality, worst quality, deformed, blurry, clothed" \
  --width 832 \
  --height 1216 \
  --steps 28 \
  --cfg-scale 6 \
  --output sexy_model_1.png
```

### **3. Пакетная генерация**
```bash
for i in {1..5}; do
  node scripts/get_illust.js \
    --prompt "sexy model variation $i, different pose, different lighting" \
    --seed $((1000 + i)) \
    --output "model_variation_$i.png"
done
```

## 📁 **Структура файлов**

```
skills/civitai-api-art/
├── SKILL.md                    # Это руководство
├── scripts/
│   ├── get_illust.js          # Основной скрипт генерации
│   ├── search_models.js       # Поиск моделей (нужно создать)
│   ├── get_model_details.js   # Детали модели (нужно создать)
│   └── batch_generate.js      # Пакетная генерация (нужно создать)
├── .env                       # API токен (уже есть)
├── package.json
└── node_modules/
```

## 🔮 **Дальнейшее развитие**

### **Планируемые улучшения**
1. **Тренировка собственных LoRA** на основе изображений модели
2. **Интеграция с ZImage.net** — альтернативный генератор
3. **Автоматический подбор промптов** на основе ML
4. **Голосовое управление** через Telegram-бота
5. **Генерация видео** из последовательности изображений

### **Для нашего проекта**
CivitAI идеально подходит для:
- **Создания портфолио** модели
- **Генерации 18+ контента** для OnlyFans/Patreon
- **Экспериментов со стилями** без необходимости тренировки моделей
- **Быстрого прототипирования** креативов

---

**Агент по креативу теперь полностью обучен работе с CivitAI!** ⚔️

*Может искать модели, генерировать изображения, создавать NSFW-контент и автоматизировать весь workflow.*