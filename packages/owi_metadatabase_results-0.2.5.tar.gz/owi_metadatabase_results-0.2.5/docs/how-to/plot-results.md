# Plot Results

This guide shows how to render interactive charts from persisted results.

## Prerequisites

- Results already uploaded to the backend (see [Upload Results](upload-results.md)).
- A `ResultsAPI` client configured and authenticated.

## Plot Through ResultsService

```python
from owi.metadatabase.results import ResultsAPI
from owi.metadatabase.results.services import ApiResultsRepository, ResultsService

api = ResultsAPI(api_root="https://owimetadatabase-dev.azurewebsites.net/api/v1",
                 token="your-api-token")
service = ResultsService(repository=ApiResultsRepository(api=api))
```

## Available Plot Types

### Comparison Plot

Scatter chart comparing metrics across references with a location dropdown:

```python
plot = service.plot_results(
    "LifetimeDesignFrequencies",
    filters={"analysis_id": 46},
    plot_type="comparison",
)
display(plot.notebook)  # Jupyter widget
```

### Location Plot

Scatter chart grouping values by turbine with a metric dropdown:

```python
plot = service.plot_results(
    "LifetimeDesignFrequencies",
    filters={"analysis_id": 46},
    plot_type="location",
)
display(plot.notebook)
```

### Geo Plot

Geographic map projecting results onto the site layout:

```python
plot = service.plot_results(
    "LifetimeDesignFrequencies",
    filters={"analysis_id": 46},
    plot_type="geo",
)
display(plot.notebook)
```

### Time Series Plot

Line chart for time-indexed data (e.g. `LifetimeDesignVerification`):

```python
plot = service.plot_results(
    "LifetimeDesignVerification",
    filters={"analysis_id": 50},
    plot_type="time_series",
)
display(plot.notebook)
```

### Cross-analysis Fleetwide Plot

Fleetwide overlay combining actual frequency reference lines with
verification points across assets. Unlike the single-analysis plot types
above, this plot is selected only by `plot_type`; the contributing
analyses are passed through named `source_filters`.

```python
plot = service.plot_results(
    plot_type="cross_analysis_fleetwide",
    source_filters={
        "frequency": {"analysis_id": 46},
        "verification": {"analysis_id": 50},
    },
)
display(plot.notebook)
```

### Cross-analysis Asset Plot

Asset-level overlay combining verification points over time with dashed
frequency reference levels. Use shared filters such as `location_id` to
scope the plot for an asset page.

```python
plot = service.plot_results(
    plot_type="cross_analysis_asset",
    filters={"location_id": 123},
    source_filters={
        "frequency": {"analysis_id": 46},
        "verification": {"analysis_id": 50},
    },
)
display(plot.notebook)
```

### Histogram Plot

Bar chart for binned data (e.g. `WindSpeedHistogram`):

```python
plot = service.plot_results(
    "WindSpeedHistogram",
    filters={"analysis_id": 55},
    plot_type="histogram",
)
display(plot.notebook)
```

## Access Plot Outputs

Every `PlotResponse` provides multiple output formats:

| Attribute | Type | Description |
|-----------|------|-------------|
| `notebook` | widget/`None` | Jupyter-compatible widget for inline display. |
| `html` | `str`/`None` | Standalone HTML string for embedding. |
| `json_options` | `str`/`None` | Serialized chart configuration for compatibility and low-level integrations. |
| `frontend_spec` | `dict`/`None` | Structured ECharts spec for web frontends that render charts outside notebook HTML wrappers. |
| `chart` | object/`None` | The underlying pyecharts chart object. |
