
from apminsight import context
from apminsight.logger import agentlogger

def set_greenlet_thread_local():
    try:
        from greenlet import getcurrent
        from weakref import WeakKeyDictionary
        
        class GreenletLocal:
            def __init__(self):
                object.__setattr__(self, '_local_data', WeakKeyDictionary())
            
            def _get_local_dict(self):
                greenlet = getcurrent()
                local_data = object.__getattribute__(self, '_local_data')
                if greenlet not in local_data:
                    local_data[greenlet] = {}
                return local_data[greenlet]
            
            def __getattr__(self, name):
                local_dict = self._get_local_dict()
                if name in local_dict:
                    return local_dict[name]
                raise AttributeError(name)
            
            def __setattr__(self, name, value):
                self._get_local_dict()[name] = value
            
            def __delattr__(self, name):
                local_dict = self._get_local_dict()
                if name in local_dict:
                    del local_dict[name]
                else:
                    raise AttributeError(name)
        
        agentlogger.info("Greenlet module found. Setting up greenlet local context.")
        context.thread_local = GreenletLocal()
        agentlogger.info("Greenlet local context setup complete.")
    except ImportError:
        pass


