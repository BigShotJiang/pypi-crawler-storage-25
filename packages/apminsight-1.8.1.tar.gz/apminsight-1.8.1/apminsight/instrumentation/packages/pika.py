from apminsight import constants
from apminsight.instrumentation.wrapper import default_wrapper, background_wrapper
from apminsight.logger import agentlogger

def instance_info(channel):
    host, port = None, 5672
    try:
        connection = channel.connection
        if not hasattr(connection, "params") and hasattr(connection, "_impl"):
            connection = connection._impl

        host = connection.params.host
        port = connection.params.port
    except Exception:
        host = None

    return host,port

def extract_info(tracker, args=(), kwargs={}, return_value=None, error=None):
    host, port = instance_info(args[0])
    tracker.set_info({constants.host_str: host, constants.port_str: port})


def bind_args(instance, queue, on_message_callback, **kwargs):
    return instance, queue, on_message_callback, kwargs

def channel_consume_wrapper(original, module_name, method_info):
    def wrapper(*args, **kwargs):
        instance, queue, on_message_callback, bkwargs = bind_args(*args, **kwargs)
        wraped_message_callback = wrap_on_message_callback(on_message_callback, queue, module_name, method_info) 
        return original(instance, queue, wraped_message_callback, **bkwargs)
    return wrapper

def wrap_on_message_callback(original, queue_name="DefaultQueue", module_name=None, method_info=None):
    def wrapper(*args, **kwargs):
        try:
            # channel = args[0]
            # host, port = instance_info(channel)
            properties = args[2] if len(args) > 2 else None
            correlation_id = getattr(properties, 'correlation_id', None) if properties else None
            # headers = getattr(properties, 'headers', None) if properties else None
            method = args[1] if len(args) > 1 else None
            exchange = getattr(method, 'exchange', 'Default') if method else 'Default'
            routing_key = getattr(method, 'routing_key', 'Default') if method else 'Default'

            bgtxn_name = f"MQ/consume/{queue_name}/{exchange}/{routing_key}/{correlation_id}"
            return background_wrapper(original, bgtxn_name, module_name, method_info)(*args, **kwargs)
        except Exception as e:
            agentlogger.error(f"Error in on_message_callback wrapper: {e}\n")
        
        return original(*args, **kwargs)
    return wrapper


module_info = {
    "pika.channel": [{
            constants.class_str : "Channel",
            constants.method_str: "basic_publish",
            constants.component_str: constants.rabbitmq_comp,
            constants.wrapper_str: default_wrapper,
            constants.extract_info_str: extract_info
        },{
            constants.class_str : "Channel",
            constants.method_str: "basic_get",
            constants.component_str: constants.rabbitmq_comp,
            constants.wrapper_str: default_wrapper,
            constants.extract_info_str: extract_info
        },{
            constants.class_str : "Channel",
            constants.method_str: "basic_consume",
            constants.component_str: constants.rabbitmq_comp,
            constants.wrapper_str: channel_consume_wrapper,
        }
    ],
    "pika.adapters.blocking_connection": [{
            constants.class_str : "BlockingChannel",
            constants.method_str: "basic_publish",
            constants.component_str: constants.rabbitmq_comp,
            constants.wrapper_str: default_wrapper,
        },{
            constants.class_str : "BlockingChannel",
            constants.method_str: "basic_consume",
            constants.component_str: constants.rabbitmq_comp,
            constants.wrapper_str: channel_consume_wrapper,
        },{
            constants.class_str : "BlockingChannel",
            constants.method_str: "consume",
            constants.component_str: constants.rabbitmq_comp,
            constants.wrapper_str: default_wrapper,
            constants.extract_info_str: extract_info
        }
    ]
            
}
