import copy
from apminsight import constants
from apminsight.util import is_non_empty_string
from apminsight.metric.tracker import Tracker
from apminsight.context import get_cur_tracker, is_no_active_txn, set_cur_tracker
from apminsight.logger import agentlogger
from apminsight.agentfactory import get_agent
from apminsight.instrumentation.wrapper import handle_tracker_end
from apminsight.instrumentation.util import create_tracker_info


def extract_info(tracker, args):
    if not isinstance(tracker, Tracker):
        return

    if tracker.get_component() != constants.redis_comp:
        return

    if isinstance(args, (list, tuple)) and len(args) > 1:
        if is_non_empty_string(args[1]):
            tracker.set_info({constants.OPERATION: args[1]})

        if hasattr(args[0], constants.host_str) and hasattr(args[0], constants.port_str):
            host = getattr(args[0], constants.host_str)
            port = getattr(args[0], constants.port_str)
            tracker.set_info({constants.host_str: host, constants.port_str: port})


def wrap_send_command(actual, module, method_info):
    def redis_wrapper(*args, **kwargs):
        if is_no_active_txn():
            return actual(*args, **kwargs)
        try:
            tracker = get_cur_tracker()
            extract_info(tracker, args)
        except:
            agentlogger.exception("While extracting Redis call info")
        finally:
            return actual(*args, **kwargs)

    return redis_wrapper

def _extract_connection_info(instance):
    """Extract host and port from a Redis client or connection instance."""
    host, port = "unknown", "unknown"
    try:
        # For Redis client instances — connection info is on the pool
        if hasattr(instance, "connection_pool"):
            pool = instance.connection_pool
            kwargs = pool.connection_kwargs
            host = kwargs.get("host", "unknown")
            port = kwargs.get("port", "unknown")
        # For raw Connection instances
        elif hasattr(instance, "host") and hasattr(instance, "port"):
            host = instance.host
            port = instance.port
    except Exception:
        pass
    return host, port


def _extract_operation(args):
    """Extract the Redis command name from args (first positional arg)."""
    if isinstance(args, (list, tuple)) and len(args) > 1:
        op = args[1]
        if isinstance(op, str):
            return op.upper()
        if isinstance(op, (bytes, bytearray)):
            return op.decode("utf-8").split()[0].upper()
    return "UNKNOWN"


def wrap_execute_async(original, module, method_info):
    async def wrapper (*args, **kwargs):
        res = err = None
        agent = get_agent()
        parent_tracker = get_cur_tracker()
        tracker_info = create_tracker_info(module, method_info, parent_tracker=parent_tracker)
        cur_tracker = agent.check_and_create_tracker(tracker_info)
        try:
            host, port = _extract_connection_info(args[0])
            operation = _extract_operation(args)
            if cur_tracker:
                cur_tracker.set_info({constants.OPERATION: operation, constants.host_str: host, constants.port_str: port})
        except:
            agentlogger.exception("while extracting details of redis call")
        
        try:
            res = await original(*args, **kwargs)
        except Exception as exc:
            err = exc
            raise exc
        finally:
            if cur_tracker:
                handle_tracker_end(cur_tracker, method_info, args, kwargs, res, err)
                set_cur_tracker(parent_tracker)
        return res 
    
    wrapper.__name__ = original.__name__
    return wrapper


def wrap_execute_command(original, module, method_info):
    def wrapper(*args, **kwargs):
        if is_no_active_txn():
            return original(*args, **kwargs)

        res = err = None
        agent = get_agent()

        parent_tracker = get_cur_tracker()
        tracker_info = create_tracker_info(module, method_info, parent_tracker)
        cur_tracker = agent.check_and_create_tracker(tracker_info)
        try:
            res = original(*args, **kwargs)
        except Exception as exc:
            err = exc
            raise exc
        finally:
            if not cur_tracker:
                return res
            host, port = _extract_connection_info(args[0])
            if host and port:
                cur_tracker.set_info({ constants.host_str: host, constants.port_str: port})
            handle_tracker_end(cur_tracker, method_info, args, kwargs, res, err)
            set_cur_tracker(parent_tracker)

        return res

    # special handling for flask route decorator
    wrapper.__name__ = original.__name__
    return wrapper


module_info = {
    "redis.client": [
        {
            constants.class_str: "Redis",
            constants.method_str: "execute_command",
            constants.component_str: constants.redis_comp,
            constants.wrapper_str: wrap_execute_command,
        }
    ],
    "redis.connection": [
        {
            constants.class_str: "Connection",
            constants.method_str: "send_command",
            constants.wrapper_str: wrap_send_command,
        }
    ],
    "redis.asyncio.client": [
        {
            constants.class_str: "Redis",
            constants.method_str: "execute_command",
            constants.component_str: constants.redis_comp,
            constants.wrapper_str: wrap_execute_async,
        }
    ],
}
