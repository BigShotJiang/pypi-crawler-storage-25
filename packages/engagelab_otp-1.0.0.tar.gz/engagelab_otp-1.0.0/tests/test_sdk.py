"""Smoke tests for engagelab_otp. No network. Run: python tests/test_sdk.py"""
import hashlib
import hmac
import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from engagelab_otp import (
    OTPClient,
    WebhookVerifier,
    WebhookSignatureError,
    MessageStatusEvent,
    NotificationEvent,
    UplinkEvent,
    SystemEvent,
    TERMINAL_STATUSES,
)


def test(name, fn):
    try:
        fn()
        print(f"  ✓ {name}")
    except AssertionError as e:
        print(f"  ✗ {name}: {e}")
        raise


print("Running tests...")


# 1. Constructor guards
def t1():
    try:
        OTPClient("", "")
        raise AssertionError("should reject empty credentials")
    except ValueError:
        pass
    try:
        WebhookVerifier("", "")
        raise AssertionError("should reject empty credentials")
    except ValueError:
        pass
test("constructor guards", t1)


# 2. Signature happy path
username = "tester"
secret   = "shhh"
verifier = WebhookVerifier(username, secret, tolerance_seconds=600)

def t2():
    ts = int(time.time())
    nonce = "abc123"
    sig = hmac.new(secret.encode(), f"{ts}{nonce}{username}".encode(), hashlib.sha256).hexdigest()
    header = f"timestamp={ts};nonce={nonce};username={username};signature={sig}"
    assert verifier.verify(header) is True
test("valid signature passes", t2)


# 3. Tampered signature
def t3():
    ts = int(time.time())
    nonce = "abc123"
    sig = hmac.new(secret.encode(), f"{ts}{nonce}{username}".encode(), hashlib.sha256).hexdigest()
    header = f"timestamp={ts};nonce={nonce};username={username};signature={sig[:-2]}00"
    try:
        verifier.verify(header)
        raise AssertionError("tampered signature should fail")
    except WebhookSignatureError:
        pass
test("tampered signature rejected", t3)


# 4. Stale timestamp
def t4():
    ts = int(time.time()) - 9999
    nonce = "abc123"
    sig = hmac.new(secret.encode(), f"{ts}{nonce}{username}".encode(), hashlib.sha256).hexdigest()
    header = f"timestamp={ts};nonce={nonce};username={username};signature={sig}"
    try:
        verifier.verify(header)
        raise AssertionError("stale timestamp should fail")
    except WebhookSignatureError:
        pass
test("stale timestamp rejected", t4)


# 5. Username mismatch
def t5():
    ts = int(time.time())
    nonce = "abc123"
    sig = hmac.new(secret.encode(), f"{ts}{nonce}other".encode(), hashlib.sha256).hexdigest()
    header = f"timestamp={ts};nonce={nonce};username=other;signature={sig}"
    try:
        verifier.verify(header)
        raise AssertionError("username mismatch should fail")
    except WebhookSignatureError:
        pass
test("username mismatch rejected", t5)


# 6. Message status event parsing
def t6():
    sample = {
        "total": 1,
        "rows": [{
            "message_id": "123",
            "to": "+6598765432",
            "server": "sms",
            "channel": "sms",
            "itime": 1701234567,
            "custom_args": {"user_id": "u1"},
            "status": {
                "message_status": "delivered",
                "status_data": {"current_send_channel": "whatsapp", "business_id": "biz"},
                "error_code": 0,
            },
        }],
    }
    events = verifier.parse_events(sample)
    assert len(events) == 1
    assert isinstance(events[0], MessageStatusEvent)
    assert events[0].is_terminal is True
    assert events[0].current_send_channel == "whatsapp"
    assert events[0].error_code == 0
test("message_status event parsed", t6)


# 7. Notification event parsing
def t7():
    sample = {
        "total": 1,
        "rows": [{
            "server": "otp",
            "itime": 1712458844,
            "notification": {
                "event": "insufficient_balance",
                "notification_data": {"remain_balance": -0.005, "balance_threshold": 2},
            },
        }],
    }
    events = verifier.parse_events(sample)
    assert isinstance(events[0], NotificationEvent)
    assert events[0].event == "insufficient_balance"
test("notification event parsed", t7)


# 8. Uplink event parsing
def t8():
    sample = {
        "total": 1,
        "rows": [{
            "server": "otp",
            "itime": 1741083306,
            "message_id": "0",
            "business_id": "0",
            "response": {
                "event": "uplink_message",
                "response_data": {
                    "message_sid": "SM1",
                    "account_sid": "AC1",
                    "from": "+1",
                    "to": "+2",
                    "body": "STOP",
                },
            },
        }],
    }
    events = verifier.parse_events(sample)
    assert isinstance(events[0], UplinkEvent)
    assert events[0].data["body"] == "STOP"
test("uplink event parsed", t8)


# 9. System event parsing
def t9():
    sample = {
        "total": 1,
        "rows": [{
            "server": "otp",
            "itime": 1694012345,
            "system_event": {
                "event": "account_login",
                "data": {"business_id": "123", "operator": {"email": "x@y.com"}},
            },
        }],
    }
    events = verifier.parse_events(sample)
    assert isinstance(events[0], SystemEvent)
    assert events[0].event == "account_login"
test("system_event parsed", t9)


# 10. is_terminal correctness
def t10():
    def status_event(s):
        return verifier.parse_events({"rows": [{"status": {"message_status": s}}]})[0]
    assert status_event("plan").is_terminal is False
    assert status_event("sent").is_terminal is False
    assert status_event("delivered").is_terminal is True
    assert status_event("delivered_failed").is_terminal is True
    assert status_event("verified_timeout").is_terminal is True
test("is_terminal derivation", t10)


print("\nAll tests passed.")
