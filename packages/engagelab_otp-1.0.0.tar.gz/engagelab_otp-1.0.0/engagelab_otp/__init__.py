"""
engagelab-otp — Official Python SDK for EngageLab OTP.

Public API:
  OTPClient
    .send(to, template_id, params=None, language="default")  # platform-generated code
    .send_custom(to, template_id, params=None)               # caller-generated code
    .verify(message_id, code)                                # verify user input

  WebhookVerifier
    .verify(header_value)              # HMAC-SHA256 signature check
    .parse_events(body)                # → typed events
    .flask_view(handler)               # one-line Flask integration

Source webhook IPs to whitelist: 119.8.170.74, 114.119.180.30
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence, Union

__version__ = "1.0.0"
__all__ = [
    "OTPClient",
    "WebhookVerifier",
    "EngagelabError",
    "WebhookSignatureError",
    "MessageStatusEvent",
    "NotificationEvent",
    "UplinkEvent",
    "SystemEvent",
    "CallbackEvent",
    "TERMINAL_STATUSES",
]

# ─── Errors ───────────────────────────────────────────────────────────────────

_RETRYABLE_API_CODES = {1000, 5001, 5016}
_RETRYABLE_HTTP      = {429, 500, 502, 503, 504}


class EngagelabError(Exception):
    """Raised for API-level failures."""

    def __init__(self, message: str, code: int = 0, http_status: int = 0) -> None:
        super().__init__(message)
        self.code        = code
        self.http_status = http_status
        self.retryable   = code in _RETRYABLE_API_CODES or http_status in _RETRYABLE_HTTP

    def __repr__(self) -> str:
        return (
            f"EngagelabError(message={str(self)!r}, code={self.code}, "
            f"http_status={self.http_status}, retryable={self.retryable})"
        )


class WebhookSignatureError(Exception):
    """Raised when a webhook signature is missing, malformed, stale, or wrong."""


# ─── Event types ──────────────────────────────────────────────────────────────

TERMINAL_STATUSES = frozenset({
    "delivered",
    "delivered_failed",
    "sent_failed",
    "sent_fail",
    "verified",
    "verified_failed",
    "verified_timeout",
    "target_invalid",
})


@dataclass
class MessageStatusEvent:
    message_id: str
    to: str
    server: str
    channel: str
    timestamp: int
    status: str
    is_terminal: bool
    custom_args: Dict[str, Any] = field(default_factory=dict)
    current_send_channel: Optional[str] = None
    template_key: Optional[str] = None
    business_id: Optional[str]  = None
    msg_time: Optional[int]     = None
    billing: Optional[Dict[str, Any]] = None
    error_code: int = 0
    error_message: Optional[str] = None
    raw: Any = None
    kind: str = "message_status"


@dataclass
class NotificationEvent:
    server: str
    timestamp: int
    event: str
    data: Dict[str, Any]
    raw: Any = None
    kind: str = "notification"


@dataclass
class UplinkEvent:
    server: str
    timestamp: int
    message_id: str
    business_id: str
    event: str
    data: Dict[str, Any]
    raw: Any = None
    kind: str = "uplink"


@dataclass
class SystemEvent:
    server: str
    timestamp: int
    event: str
    data: Dict[str, Any]
    raw: Any = None
    kind: str = "system_event"


CallbackEvent = Union[MessageStatusEvent, NotificationEvent, UplinkEvent, SystemEvent]


# ─── HTTP ─────────────────────────────────────────────────────────────────────

def _post(url: str, auth: str, body: dict, timeout: float) -> dict:
    payload = json.dumps(body).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        method="POST",
        headers={
            "Content-Type":  "application/json",
            "Authorization": auth,
            "User-Agent":    f"engagelab-otp-python/{__version__}",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        raw = exc.read()
        try:
            data = json.loads(raw)
        except Exception:
            data = {"message": raw.decode(errors="replace")}
        raise EngagelabError(
            data.get("message", "Unknown error"),
            code=data.get("code", 0),
            http_status=exc.code,
        ) from exc


# ─── OTPClient ────────────────────────────────────────────────────────────────

class OTPClient:
    """Client for the EngageLab OTP send + verify API."""

    BASE_URL = "https://otp.api.engagelab.cc/v1"

    def __init__(self, dev_key: str, dev_secret: str, *, timeout: float = 10.0) -> None:
        if not dev_key or not dev_secret:
            raise ValueError("dev_key and dev_secret are required")
        token = base64.b64encode(f"{dev_key}:{dev_secret}".encode()).decode()
        self._auth = f"Basic {token}"
        self._timeout = timeout

    def _post(self, path: str, body: dict) -> dict:
        return _post(self.BASE_URL + path, self._auth, body, self._timeout)

    # --- Platform-generated code ---------------------------------------------

    def send(
        self,
        to: str,
        template_id: str,
        params: Optional[Dict[str, str]] = None,
        language: str = "default",
    ) -> dict:
        """
        Send an OTP — EngageLab generates the code.
        Endpoint: POST /v1/messages

        Returns: { "message_id": str, "send_channel": str }
        """
        if not to:
            raise ValueError("to is required")
        if not template_id:
            raise ValueError("template_id is required")
        return self._post("/messages", {
            "to": to,
            "template": {"id": template_id, "language": language, "params": params or {}},
        })

    # --- Caller-generated code -----------------------------------------------

    def send_custom(
        self,
        to: Union[str, Sequence[str]],
        template_id: str,
        params: Optional[Dict[str, str]] = None,
    ) -> dict:
        """
        Send a custom message — caller supplies all template variables (including `code`).
        Endpoint: POST /v1/custom-messages

        Returns: { "message_id": str, "send_channel": str }
        """
        if not to:
            raise ValueError("to is required")
        if not template_id:
            raise ValueError("template_id is required")
        return self._post("/custom-messages", {
            "to": list(to) if not isinstance(to, str) else to,
            "template": {"id": template_id, "params": params or {}},
        })

    # --- Verify --------------------------------------------------------------

    def verify(self, message_id: str, code: str) -> dict:
        """
        Verify a code the user entered.
        Endpoint: POST /v1/verifications

        Returns: { "message_id": str, "verify_code": str, "verified": bool }
        """
        if not message_id:
            raise ValueError("message_id is required")
        if not code:
            raise ValueError("code is required")
        return self._post("/verifications", {
            "message_id":  message_id,
            "verify_code": str(code),
        })


# ─── WebhookVerifier ──────────────────────────────────────────────────────────

class WebhookVerifier:
    """
    Verifies and parses EngageLab OTP webhook callbacks.

    EngageLab signs each callback with X-CALLBACK-ID:
        timestamp={ts};nonce={n};username={u};signature={sig}
    where signature = HMAC-SHA256(secret, f"{ts}{nonce}{username}").hexdigest()
    """

    def __init__(
        self,
        username: str,
        secret: str,
        *,
        tolerance_seconds: int = 300,
    ) -> None:
        if not username or not secret:
            raise ValueError("username and secret are required")
        self._username = username
        self._secret   = secret.encode()
        self._tol      = tolerance_seconds

    def verify(self, header_value: str, now: Optional[int] = None) -> bool:
        """Verify X-CALLBACK-ID. Raises WebhookSignatureError on failure."""
        if not header_value:
            raise WebhookSignatureError("missing X-CALLBACK-ID header")

        parts: Dict[str, str] = {}
        for seg in header_value.split(";"):
            if "=" in seg:
                k, _, v = seg.partition("=")
                parts[k.strip()] = v.strip()

        for key in ("timestamp", "nonce", "username", "signature"):
            if key not in parts:
                raise WebhookSignatureError("malformed X-CALLBACK-ID header")

        if parts["username"] != self._username:
            raise WebhookSignatureError("username mismatch")

        try:
            ts = int(parts["timestamp"])
        except ValueError as exc:
            raise WebhookSignatureError("invalid timestamp") from exc

        current = int(time.time()) if now is None else int(now)
        if abs(current - ts) > self._tol:
            raise WebhookSignatureError("timestamp outside tolerance window")

        expected = hmac.new(
            key=self._secret,
            msg=f"{parts['timestamp']}{parts['nonce']}{self._username}".encode(),
            digestmod=hashlib.sha256,
        ).hexdigest()

        if not hmac.compare_digest(expected, parts["signature"]):
            raise WebhookSignatureError("signature mismatch")

        return True

    def parse_events(self, body: Union[str, bytes, dict]) -> List[CallbackEvent]:
        """Parse a callback body into typed events. Unknown row shapes are skipped."""
        if isinstance(body, (str, bytes)):
            obj = json.loads(body)
        else:
            obj = body
        events: List[CallbackEvent] = []
        for row in obj.get("rows", []):
            evt = _parse_row(row)
            if evt is not None:
                events.append(evt)
        return events

    def flask_view(self, handler: Callable[[List[CallbackEvent]], None]):
        """
        Build a Flask view function. Returns 200 on success, 401 on bad signature.

        Usage:
            app.add_url_rule(
                "/webhook",
                "engagelab_webhook",
                verifier.flask_view(my_handler),
                methods=["POST"],
            )
        """
        def view():
            from flask import request   # local import keeps Flask optional
            try:
                self.verify(request.headers.get("X-CALLBACK-ID", ""))
            except WebhookSignatureError:
                return ("", 401)
            try:
                events = self.parse_events(request.get_data(as_text=True))
                handler(events)
            except Exception:
                # Always 200 on internal errors so EngageLab does not retry.
                pass
            return ("", 200)
        return view


# ─── Internal: row → typed event ──────────────────────────────────────────────

def _parse_row(row: dict) -> Optional[CallbackEvent]:
    if not isinstance(row, dict):
        return None

    status = row.get("status")
    if isinstance(status, dict) and "message_status" in status:
        sd = status.get("status_data") or {}
        ed = status.get("error_detail") or {}
        ms = status["message_status"]
        return MessageStatusEvent(
            message_id   = row.get("message_id", ""),
            to           = row.get("to", ""),
            server       = row.get("server", ""),
            channel      = row.get("channel", ""),
            timestamp    = row.get("itime", 0),
            custom_args  = row.get("custom_args") or {},
            status       = ms,
            is_terminal  = ms in TERMINAL_STATUSES,
            current_send_channel = sd.get("current_send_channel"),
            template_key = sd.get("template_key"),
            business_id  = sd.get("business_id"),
            msg_time     = sd.get("msg_time"),
            billing      = status.get("billing"),
            error_code   = status.get("error_code") or 0,
            error_message = ed.get("message"),
            raw          = row,
        )

    if "notification" in row:
        n = row["notification"]
        return NotificationEvent(
            server    = row.get("server", ""),
            timestamp = row.get("itime", 0),
            event     = n.get("event", ""),
            data      = n.get("notification_data") or {},
            raw       = row,
        )

    if "response" in row:
        r = row["response"]
        return UplinkEvent(
            server      = row.get("server", ""),
            timestamp   = row.get("itime", 0),
            message_id  = row.get("message_id", ""),
            business_id = row.get("business_id", ""),
            event       = r.get("event", ""),
            data        = r.get("response_data") or {},
            raw         = row,
        )

    if "system_event" in row:
        s = row["system_event"]
        return SystemEvent(
            server    = row.get("server", ""),
            timestamp = row.get("itime", 0),
            event     = s.get("event", ""),
            data      = s.get("data") or {},
            raw       = row,
        )

    return None
