from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from minimal_harness.adapters import ConfigProvider, RegistryProvider, SecretResolver
from minimal_harness.auth import PermissionChecker, TokenVerifier

from mh_orchestration_service.api.router import router
from mh_orchestration_service.config import Settings, settings
from mh_orchestration_service.config_mapping import ConfigMapping
from mh_orchestration_service.services.auth_client import _DefaultAuthProvider
from mh_orchestration_service.services.registry_client import RegistryClient


class AppState:
    """Holder for adapter instances, attached to app.state."""

    def __init__(
        self,
        token_verifier: TokenVerifier,
        permission_checker: PermissionChecker,
        registry_provider: RegistryProvider,
        secret_resolver: SecretResolver | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self.token_verifier = token_verifier
        self.permission_checker = permission_checker
        self.registry_provider = registry_provider
        self.secret_resolver = secret_resolver
        self.logger = logger


def create_app(
    *,
    token_verifier: TokenVerifier | None = None,
    permission_checker: PermissionChecker | None = None,
    registry_provider: RegistryProvider | None = None,
    config_provider: ConfigProvider | None = None,
    secret_resolver: SecretResolver | None = None,
    config_mapping: ConfigMapping | None = None,
    logger: logging.Logger | None = None,
) -> FastAPI:
    """Create a configured FastAPI app for the orchestration service.

    Customers: pass your own implementations of the adapter protocols to
    integrate with your existing SSO, permission, registry, config, and
    secret management systems.  When an adapter is omitted, the built-in
    default is used (env-var-based config, local auth-service etc.).

    Pass *logger* to inject a custom logger; the ``orchestration.*``
    loggers will inherit its handlers and level.
    """
    if (
        config_provider is not None
        or secret_resolver is not None
        or config_mapping is not None
    ):
        resolved = Settings.from_providers(
            config_provider, secret_resolver, config_mapping
        )
        for field in settings.model_fields:
            setattr(settings, field, getattr(resolved, field))

    if token_verifier is None and permission_checker is None:
        _default_auth = _DefaultAuthProvider()
        token_verifier = _default_auth
        permission_checker = _default_auth
    else:
        if token_verifier is None:
            token_verifier = _DefaultAuthProvider()
        if permission_checker is None:
            permission_checker = _DefaultAuthProvider()
    if registry_provider is None:
        registry_provider = RegistryClient()

    if logger is not None:
        orch_logger = logging.getLogger("orchestration")
        orch_logger.handlers = logger.handlers
        orch_logger.setLevel(logger.level)
        orch_logger.propagate = logger.propagate

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        from mh_orchestration_service.services.database import init_db

        await init_db(settings.database_url, auto_schema=settings.db_auto_schema)
        yield
        _adapters = _ensure_app_state(app)
        if isinstance(_adapters.token_verifier, _DefaultAuthProvider):
            await _adapters.token_verifier.close()
        if (
            isinstance(_adapters.permission_checker, _DefaultAuthProvider)
            and _adapters.permission_checker is not _adapters.token_verifier
        ):
            await _adapters.permission_checker.close()
        if isinstance(_adapters.registry_provider, RegistryClient):
            await _adapters.registry_provider.close()
        from mh_orchestration_service.services.database import get_db

        await get_db().close()

    app = FastAPI(title="Orchestration Service", version="0.1.0", lifespan=lifespan)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.state.adapters = AppState(
        token_verifier=token_verifier,
        permission_checker=permission_checker,
        registry_provider=registry_provider,
        secret_resolver=secret_resolver,
        logger=logger,
    )
    app.include_router(router)
    return app


def _ensure_app_state(app: FastAPI) -> AppState:
    state: Any = app.state
    if not hasattr(state, "adapters") or state.adapters is None:
        raise RuntimeError("create_app() must be called before accessing adapters")
    return state.adapters
