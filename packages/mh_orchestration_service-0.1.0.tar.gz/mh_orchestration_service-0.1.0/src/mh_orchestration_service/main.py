from mh_orchestration_service.app import create_app

app = create_app()
