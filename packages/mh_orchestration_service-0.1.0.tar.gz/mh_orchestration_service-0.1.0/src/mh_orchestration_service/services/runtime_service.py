from __future__ import annotations

import asyncio
import json

from fastapi import Request
from minimal_harness.agent.registry import AgentRegistry
from minimal_harness.agent.runtime import AgentRuntime
from minimal_harness.memory_store import SessionStoreProtocol
from minimal_harness.tool.registry import ToolRegistry
from minimal_harness.types import (
    AgentMetadata,
    RemoteAgentBinding,
    RemoteToolBinding,
    ToolMetadata,
)

from mh_orchestration_service.api.locale import parse_locale_json
from mh_orchestration_service.services.audit_middleware import AuditMiddleware
from mh_orchestration_service.services.database import get_session_store
from mh_orchestration_service.services.perm_middleware import PermissionMiddleware


# ── Per-session concurrency lock ──────────────────────────────────────────────

_SESSION_LOCKS: dict[str, asyncio.Lock] = {}
_SESSION_LOCKS_MUTEX = asyncio.Lock()


async def acquire_session_lock(session_id: str) -> asyncio.Lock:
    """Get (or create) and acquire a per-session lock.

    This serialises writes to the same ``session_id`` so that concurrent
    chat requests cannot race on ``save_memory``.
    """
    async with _SESSION_LOCKS_MUTEX:
        if session_id not in _SESSION_LOCKS:
            _SESSION_LOCKS[session_id] = asyncio.Lock()
        lock = _SESSION_LOCKS[session_id]
    await lock.acquire()
    return lock


async def release_session_lock(session_id: str, lock: asyncio.Lock) -> None:
    """Release a per-session lock and prune it from the dictionary."""
    lock.release()
    async with _SESSION_LOCKS_MUTEX:
        _SESSION_LOCKS.pop(session_id, None)


async def create_runtime(
    request: Request,
    user_id: str,
    agent_name: str,
    tool_names: list[str],
    session_store: SessionStoreProtocol | None = None,
    session_id: str = "",
) -> tuple[AgentRuntime, AgentRegistry, ToolRegistry, SessionStoreProtocol]:
    adapters = request.app.state.adapters
    agent_meta = await adapters.registry_provider.get_agent(agent_name)
    if agent_meta is None:
        raise ValueError(f"Agent '{agent_name}' not found in registry")

    agent_registry = AgentRegistry()

    await agent_registry.register(
        AgentMetadata(
            name=agent_meta["name"],
            display_name=agent_meta["display_name"],
            display_name_locale=parse_locale_json(
                agent_meta.get("display_name_locale")
            ),
            description=agent_meta["description"],
            description_locale=parse_locale_json(agent_meta.get("description_locale")),
            system_prompt=agent_meta["system_prompt"],
            metadata_id=agent_meta["name"],
            binding=RemoteAgentBinding(url=agent_meta["endpoint_url"]),
        )
    )

    tool_registry = ToolRegistry()
    for tname in tool_names:
        tool_meta = await adapters.registry_provider.get_tool(tname)
        if tool_meta is None:
            continue
        try:
            params = json.loads(tool_meta["parameters_schema"])
        except (json.JSONDecodeError, KeyError):
            params = {"type": "object", "properties": {}}
        await tool_registry.register(
            ToolMetadata(
                name=tool_meta["name"],
                display_name=tool_meta["display_name"],
                display_name_locale=parse_locale_json(
                    tool_meta.get("display_name_locale")
                ),
                description=tool_meta["description"],
                description_locale=parse_locale_json(
                    tool_meta.get("description_locale")
                ),
                parameters=params,
                binding=RemoteToolBinding(url=tool_meta["endpoint_url"]),
            )
        )

    if session_store is None:
        session_store = await get_session_store()
    middleware = [
        PermissionMiddleware(user_id, adapters.permission_checker),
        AuditMiddleware(user_id=user_id, session_id=session_id),
    ]

    runtime = AgentRuntime(
        agent_registry=agent_registry,
        session_store=session_store,
        tool_registry=tool_registry,
        middleware=middleware,
    )

    return runtime, agent_registry, tool_registry, session_store
