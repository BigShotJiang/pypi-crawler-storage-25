from __future__ import annotations

from typing import Any

import httpx
from minimal_harness.adapters import RegistryProvider

from mh_orchestration_service.config import settings


class RegistryClient(RegistryProvider):
    """Default implementation that calls the built-in registry-service.

    Customer deployment: replace this with an implementation that queries
    the customer's own Agent/Tool/Scenario Registry.
    """

    def __init__(self) -> None:
        self._client = httpx.AsyncClient(
            base_url=settings.registry_service_url, timeout=10, trust_env=False
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def get_agent(self, name: str) -> dict[str, Any] | None:
        r = await self._client.get(f"/api/v1/agents/name/{name}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    async def list_agents(self) -> list[dict[str, Any]]:
        r = await self._client.get("/api/v1/agents")
        r.raise_for_status()
        return r.json()

    async def get_tool(self, name: str) -> dict[str, Any] | None:
        r = await self._client.get(f"/api/v1/tools/name/{name}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    async def list_tools(self) -> list[dict[str, Any]]:
        r = await self._client.get("/api/v1/tools")
        r.raise_for_status()
        return r.json()

    async def get_scenario(self, scenario_id: str) -> dict[str, Any] | None:
        r = await self._client.get(f"/api/v1/scenarios/{scenario_id}")
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()

    async def list_scenarios(self) -> list[dict[str, Any]]:
        r = await self._client.get("/api/v1/scenarios")
        r.raise_for_status()
        return r.json()


registry_client = RegistryClient()
