from __future__ import annotations

import base64
import json
import logging
from typing import Any

import httpx
from minimal_harness.auth import PermissionChecker, TokenVerifier, UserIdentity

from mh_orchestration_service.config import settings

logger = logging.getLogger("orchestration.auth_client")


def _decode_jwt_payload(token: str) -> dict[str, Any] | None:
    """Decode the payload segment of a JWT **without** verifying the signature.

    This is a development convenience: it reads the ``sub`` claim from
    the JWT without needing the HMAC secret.  **No signature validation
    is performed** — do NOT use this in production.
    """
    try:
        payload_b64 = token.split(".")[1]
        padding = 4 - len(payload_b64) % 4
        if padding != 4:
            payload_b64 += "=" * padding
        return json.loads(base64.urlsafe_b64decode(payload_b64))
    except (IndexError, ValueError, json.JSONDecodeError):
        return None


class _DefaultAuthProvider(TokenVerifier, PermissionChecker):
    """Built-in default that ships with the product for development.

    Implements both ``TokenVerifier`` and ``PermissionChecker``.

    **Customers**: do NOT reference this class.  Pass your own
    ``TokenVerifier`` / ``PermissionChecker`` implementations to
    ``create_app()`` to integrate with your SSO / permission system.
    """

    def __init__(self) -> None:
        self._base_url = settings.auth_service_url
        self._client = httpx.AsyncClient(
            base_url=self._base_url, timeout=10, trust_env=False
        )

    async def close(self) -> None:
        await self._client.aclose()

    async def verify(self, request: Any) -> UserIdentity | None:
        auth = request.headers.get("authorization", "")
        if not auth.startswith("Bearer "):
            return None
        token = auth[len("Bearer ") :]
        if not token:
            return None
        # Decode the JWT payload WITHOUT verifying the signature.
        # This lets us extract the real ``sub`` (user ID) from the
        # token for development, without needing an HMAC secret.
        # Customers replace this class with their own TokenVerifier.
        payload = _decode_jwt_payload(token)
        if payload is None:
            return None
        uid = str(payload.get("sub", ""))
        if not uid:
            return None
        return UserIdentity(user_id=uid, username=payload.get("username", ""))

    async def get_permissions(self, user_id: str) -> list[str]:
        try:
            r = await self._client.get(f"/api/v1/users/{user_id}/permissions")
            if r.status_code == 404:
                return []
            r.raise_for_status()
            return r.json()
        except httpx.RequestError as e:
            logger.error("Auth service %s unreachable: %s", self._base_url, e)
            raise RuntimeError(f"Auth service unreachable: {e}") from e

    async def check(self, user_id: str, permission: str) -> bool:
        perms = await self.get_permissions(user_id)
        from minimal_harness.auth.protocols import match_permission

        return match_permission(perms, permission)
