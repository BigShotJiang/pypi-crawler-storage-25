from __future__ import annotations

from minimal_harness.database import DatabaseBackend, DatabaseProtocol
from minimal_harness.memory_store import SessionStoreProtocol

from mh_orchestration_service.config import settings

_db: DatabaseProtocol | None = None


def _create_db() -> DatabaseProtocol:
    backend_cls = DatabaseBackend.get(settings.db_type)
    return backend_cls()  # type: ignore[return-value]


def get_db() -> DatabaseProtocol:
    global _db
    if _db is None:
        _db = _create_db()
    return _db


def set_db(provider: DatabaseProtocol) -> None:
    global _db
    _db = provider


async def init_db(dsn: str, auto_schema: bool = True) -> None:
    d = get_db()
    await d.init(dsn)
    if auto_schema:
        await d.init_schema()


async def get_session_store() -> SessionStoreProtocol:
    return await get_db().create_session_store()
