from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, Request
from pydantic import BaseModel

from mh_orchestration_service.api.auth import get_user_id
from mh_orchestration_service.services.database import get_session_store

router = APIRouter(prefix="/api/v1/sessions", tags=["sessions"])


class SessionCreateRequest(BaseModel):
    agent_name: str
    scenario_id: str | None = None


@router.get("")
async def list_sessions(
    request: Request,
    scenario_id: str | None = Query(None),
):
    user_id = await get_user_id(request)
    store = await get_session_store()
    sessions = await store.list_user_sessions(user_id, scenario_id)
    return [
        {
            "memory_id": s["session_id"],
            "title": s.get("title") or "Untitled",
            "created_at": s["created_at"],
            "message_count": s["message_count"],
            "agent_name": s["agent_name"],
            "user_id": s["user_id"],
            "scenario_id": s["scenario_id"],
        }
        for s in sessions
    ]


@router.post("")
async def create_session(
    request: Request,
    body: SessionCreateRequest,
):
    user_id = await get_user_id(request)
    store = await get_session_store()
    session = await store.create_session(
        agent_name=body.agent_name,
        user_id=user_id,
        scenario_id=body.scenario_id,
    )
    return {
        "memory_id": session.session_id,
        "title": session.title or "New Chat",
        "created_at": session.created_at,
        "message_count": 0,
        "agent_name": session.agent_name,
        "user_id": session.user_id,
        "scenario_id": session.scenario_id,
    }


@router.get("/{memory_id}")
async def get_session(
    request: Request,
    memory_id: str,
):
    user_id = await get_user_id(request)
    store = await get_session_store()
    session = await store.get_session(memory_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.user_id != user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    return {
        "memory_id": session.session_id,
        "title": session.title or "Untitled",
        "created_at": session.created_at,
        "message_count": len(session.get_all_messages()),
        "agent_name": session.agent_name,
        "user_id": session.user_id,
        "scenario_id": session.scenario_id,
    }


@router.get("/{memory_id}/messages")
async def get_session_messages(
    request: Request,
    memory_id: str,
):
    user_id = await get_user_id(request)
    store = await get_session_store()
    session = await store.get_session(memory_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.user_id != user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    messages = store.get_messages_as_items(session)
    return messages


@router.delete("/{memory_id}", status_code=200)
async def delete_session(
    request: Request,
    memory_id: str,
):
    user_id = await get_user_id(request)
    store = await get_session_store()
    session = await store.get_session(memory_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if session.user_id != user_id:
        raise HTTPException(status_code=403, detail="Access denied")
    await store.delete_session(memory_id)
    return {"ok": True}
