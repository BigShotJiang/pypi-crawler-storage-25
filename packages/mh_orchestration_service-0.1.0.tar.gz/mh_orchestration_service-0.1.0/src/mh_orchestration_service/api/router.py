from fastapi import APIRouter

from mh_orchestration_service.api.agents import router as agents_router
from mh_orchestration_service.api.chat import router as chat_router
from mh_orchestration_service.api.guide import router as guide_router
from mh_orchestration_service.api.scenarios import router as scenarios_router
from mh_orchestration_service.api.sessions import router as sessions_router
from mh_orchestration_service.api.tools import router as tools_router

router = APIRouter()
router.include_router(chat_router)
router.include_router(scenarios_router)
router.include_router(sessions_router)
router.include_router(guide_router)
router.include_router(agents_router)
router.include_router(tools_router)
