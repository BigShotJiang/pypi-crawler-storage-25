from __future__ import annotations

from fastapi import HTTPException, Request


async def get_user_id(request: Request) -> str:
    """Extract the authenticated user ID from *request*.

    Delegates to the configured ``TokenVerifier`` which receives the full
    ``Request`` object and may inspect headers, cookies, or call external
    auth services to determine the caller's identity.

    Raises ``401`` if the request is not authenticated.
    """
    adapters = request.app.state.adapters
    identity = await adapters.token_verifier.verify(request)
    if identity is None:
        raise HTTPException(status_code=401, detail="Authentication required")
    if not identity.user_id:
        raise HTTPException(status_code=401, detail="Invalid token payload")
    return identity.user_id


async def get_raw_auth_data(request: Request) -> str:
    """Extract the raw authentication material from *request*.

    Returns the ``Authorization: Bearer <token>`` value when present,
    or the value of the first recognized cookie as a fallback.

    Customer deployments using a custom ``TokenVerifier`` may override
    this function if downstream services need the raw credential.
    """
    auth = request.headers.get("authorization", "")
    if auth.startswith("Bearer "):
        return auth[len("Bearer ") :]
    for key in ("sessionid", "sid", "token"):
        if key in request.cookies:
            return request.cookies[key]
    return ""
