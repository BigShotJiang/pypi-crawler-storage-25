from __future__ import annotations

from fastapi import APIRouter, Header, Query, Request

from minimal_harness.auth import match_permission

from mh_orchestration_service.api.auth import get_user_id
from mh_orchestration_service.api.locale import (
    parse_locale,
    resolve_description,
    resolve_display_name,
)

router = APIRouter(prefix="/api/v1/agents", tags=["agents"])


@router.get("")
async def list_agents(
    request: Request,
    scenario: str | None = Query(None),
    accept_language: str | None = Header(None, alias="Accept-Language"),
):
    adapters = request.app.state.adapters
    user_id = await get_user_id(request)
    user_perms = await adapters.permission_checker.get_permissions(user_id)
    locale = parse_locale(accept_language)
    agents = await adapters.registry_provider.list_agents()

    if scenario:
        from mh_orchestration_service.api.scenarios import (
            _enrich_agents_for_scenario,
            _get_scenario,
        )

        s = await _get_scenario(request, scenario)
        if s is None:
            return []
        return await _enrich_agents_for_scenario(request, s, user_perms, locale)

    result = []
    for a in agents:
        if not match_permission(user_perms, f"execute:agent:{a['name']}"):
            continue
        result.append(
            {
                "name": a["name"],
                "display_name": resolve_display_name(
                    a.get("display_name", a["name"]),
                    a.get("display_name_locale"),
                    locale,
                ),
                "description": resolve_description(
                    a.get("description", ""),
                    a.get("description_locale"),
                    locale,
                ),
                "tool_names": [],
                "tools": [],
            }
        )
    return result
