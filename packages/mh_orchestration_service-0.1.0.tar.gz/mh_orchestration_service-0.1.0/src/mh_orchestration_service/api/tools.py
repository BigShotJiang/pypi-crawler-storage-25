from __future__ import annotations

from fastapi import APIRouter, Header, Request

from minimal_harness.auth import match_permission

from mh_orchestration_service.api.auth import get_user_id
from mh_orchestration_service.api.locale import (
    parse_locale,
    resolve_description,
    resolve_display_name,
)

router = APIRouter(prefix="/api/v1/tools", tags=["tools"])


@router.get("")
async def list_tools(
    request: Request,
    accept_language: str | None = Header(None, alias="Accept-Language"),
):
    adapters = request.app.state.adapters
    user_id = await get_user_id(request)
    user_perms = await adapters.permission_checker.get_permissions(user_id)
    locale = parse_locale(accept_language)
    tools = await adapters.registry_provider.list_tools()
    result = []
    for t in tools:
        if not match_permission(user_perms, f"use:tool:{t['name']}"):
            continue
        result.append(
            {
                "name": t["name"],
                "display_name": resolve_display_name(
                    t.get("display_name", t["name"]),
                    t.get("display_name_locale"),
                    locale,
                ),
                "description": resolve_description(
                    t.get("description", ""),
                    t.get("description_locale"),
                    locale,
                ),
            }
        )
    return result
