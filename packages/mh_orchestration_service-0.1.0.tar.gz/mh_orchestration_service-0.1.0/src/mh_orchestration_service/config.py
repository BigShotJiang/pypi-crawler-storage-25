from __future__ import annotations

import asyncio
from typing import Any

from minimal_harness.adapters import ConfigProvider, EnvConfigProvider, SecretResolver
from pydantic_settings import BaseSettings

from mh_orchestration_service.config_mapping import ConfigMapping


class Settings(BaseSettings):
    model_config = {"env_prefix": "ORCH_"}

    auth_service_url: str = "http://localhost:8000"
    registry_service_url: str = "http://localhost:8001"
    # Set via ORCH_CORS_ORIGINS as JSON array, e.g.: ["http://example.com"]
    cors_origins: list[str] = ["http://localhost:5173"]

    # --- Database ---
    db_type: str = "sqlite"  # "sqlite" | "opengauss"
    db_path: str = "./orchestration.db"
    db_host: str = "127.0.0.1"
    db_port: int = 5432
    db_name: str = "orchestration"
    db_user: str = "orchestration"
    db_password: str = ""
    db_auto_schema: bool = True

    @property
    def database_url(self) -> str:
        if self.db_type == "sqlite":
            return self.db_path
        return f"postgresql://{self.db_user}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}"

    @classmethod
    def from_providers(
        cls,
        config_provider: ConfigProvider | None = None,
        secret_resolver: SecretResolver | None = None,
        mapping: ConfigMapping | None = None,
    ) -> Settings:
        _config = config_provider or EnvConfigProvider()
        _secret = secret_resolver or EnvConfigProvider()
        _mapping = mapping or ConfigMapping()

        async def _resolve() -> dict[str, Any]:
            kwargs: dict[str, Any] = {}
            for field_name in cls.model_fields:
                external_key = _mapping.key_mapping.get(field_name, field_name)
                if field_name in _mapping.sensitive_keys:
                    value = await _secret.get(external_key)
                else:
                    value = await _config.get(external_key)

                if value is not None:
                    kwargs[field_name] = value
            return kwargs

        kwargs = asyncio.run(_resolve())
        return cls(**kwargs)


settings = Settings()
