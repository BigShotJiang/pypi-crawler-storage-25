# Copyright 2025 Flower Labs GmbH. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""ClientAppIo API servicer."""


from logging import DEBUG, ERROR
from typing import cast

import grpc

from flwr.common import Context
from flwr.common.logger import log
from flwr.common.serde import (
    context_from_proto,
    context_to_proto,
    fab_to_proto,
    message_from_proto,
    message_to_proto,
    run_to_proto,
)
from flwr.common.typing import Run

# pylint: disable=E0611
from flwr.proto import clientappio_pb2_grpc
from flwr.proto.appio_pb2 import (
    CreateTaskRequest,
    CreateTaskResponse,
    PullAppInputsRequest,
    PullAppInputsResponse,
    PullAppMessagesRequest,
    PullAppMessagesResponse,
    PushAppMessagesRequest,
    PushAppMessagesResponse,
    PushAppOutputsRequest,
    PushAppOutputsResponse,
)
from flwr.proto.message_pb2 import (
    ConfirmMessageReceivedRequest,
    ConfirmMessageReceivedResponse,
    PullObjectRequest,
    PullObjectResponse,
    PushObjectRequest,
    PushObjectResponse,
)
from flwr.proto.run_pb2 import GetRunRequest, GetRunResponse
from flwr.supercore.inflatable.inflatable_object import UnexpectedObjectContentError
from flwr.supercore.interceptors import get_authenticated_task
from flwr.supercore.object_store import NoObjectInStoreError, ObjectStoreFactory
from flwr.supercore.servicers import AppIoServicer
from flwr.supernode.nodestate import NodeState, NodeStateFactory


# pylint: disable=C0103,W0613,W0201
class ClientAppIoServicer(AppIoServicer, clientappio_pb2_grpc.ClientAppIoServicer):
    """ClientAppIo API servicer."""

    def __init__(
        self,
        state_factory: NodeStateFactory,
        objectstore_factory: ObjectStoreFactory,
    ) -> None:
        self.state_factory = state_factory
        self.objectstore_factory = objectstore_factory

    def state(self) -> NodeState:
        """Return the NodeState instance."""
        return self.state_factory.state()

    def GetRun(
        self, request: GetRunRequest, context: grpc.ServicerContext
    ) -> GetRunResponse:
        """Get run information."""
        log(DEBUG, "ClientAppIo.GetRun")

        # Initialize state connection
        state = self.state_factory.state()

        # Retrieve run information
        run = state.get_run(request.run_id)

        if run is None:
            return GetRunResponse()

        return GetRunResponse(run=run_to_proto(run))

    def PullAppInputs(
        self, request: PullAppInputsRequest, context: grpc.ServicerContext
    ) -> PullAppInputsResponse:
        """Pull Message, Context, and Run."""
        log(DEBUG, "ClientAppIo.PullAppInputs")

        # Get the authenticated task and associated run ID
        task = get_authenticated_task()
        run_id = task.run_id

        # Initialize state connection
        state = self.state_factory.state()

        # Retrieve context, run and fab for this run
        serverapp_context = cast(Context, state.get_context(run_id))
        run = cast(Run, state.get_run(run_id))

        # Retrieve FAB from NodeState
        if fab := state.get_fab(run.fab_hash):
            log(
                DEBUG,
                "Retrieved FAB: hash=%s, content_len=%d, verifications=%s",
                run.fab_hash,
                len(fab.content),
                fab.verifications,
            )
        else:
            context.abort(
                grpc.StatusCode.NOT_FOUND,
                f"FAB with hash {run.fab_hash} not found in NodeState.",
            )
            raise RuntimeError("This line should never be reached.")

        # Activate task
        if state.activate_task(task_id=task.task_id):
            log(DEBUG, "Started task %d of run %s", task.task_id, run_id)
            return PullAppInputsResponse(
                context=context_to_proto(serverapp_context),
                run=run_to_proto(run),
                fab=fab_to_proto(fab),
            )

        log(ERROR, "Failed to start task %d of run %s", task.task_id, run_id)
        context.abort(grpc.StatusCode.FAILED_PRECONDITION, "Failed to start task.")
        raise RuntimeError("Unreachable code")  # for mypy

    def PushAppOutputs(
        self, request: PushAppOutputsRequest, context: grpc.ServicerContext
    ) -> PushAppOutputsResponse:
        """Push Message and Context."""
        log(DEBUG, "ClientAppIo.PushAppOutputs")

        # Get the authenticated task and associated run ID
        task = get_authenticated_task()
        run_id = task.run_id

        # Initialize state connection
        state = self.state_factory.state()

        # Flag task as finished
        if state.finish_task(
            task_id=task.task_id,
            sub_status=request.sub_status,
            details=request.details,
        ):
            log(DEBUG, "Finished task %d of run %s", task.task_id, run_id)
            # Save the context to the state
            state.store_context(context_from_proto(request.context))
        else:
            log(ERROR, "Failed to finish task %d of run %s", task.task_id, run_id)

        return PushAppOutputsResponse()

    def PullMessage(
        self, request: PullAppMessagesRequest, context: grpc.ServicerContext
    ) -> PullAppMessagesResponse:
        """Pull one Message."""
        log(DEBUG, "ClientAppIo.PullMessage")

        # Get the authenticated task and associated run ID
        task = get_authenticated_task()
        run_id = task.run_id

        # Initialize state and store connection
        state = self.state_factory.state()
        store = self.objectstore_factory.store()

        # Retrieve message for this run
        message = state.get_messages(run_ids=[run_id], is_reply=False)[0]

        # Record message processing start time
        state.record_message_processing_start(message_id=message.metadata.message_id)

        # Retrieve the object tree for the message
        object_tree = store.get_object_tree(message.metadata.message_id)

        return PullAppMessagesResponse(
            messages_list=[message_to_proto(message)],
            message_object_trees=[object_tree],
        )

    def PushMessage(
        self, request: PushAppMessagesRequest, context: grpc.ServicerContext
    ) -> PushAppMessagesResponse:
        """Push one Message."""
        log(DEBUG, "ClientAppIo.PushMessage")

        # Get the authenticated task and associated run ID
        task = get_authenticated_task()
        run_id = task.run_id

        # Initialize state and store connection
        state = self.state_factory.state()
        store = self.objectstore_factory.store()

        # Record message processing end time
        state.record_message_processing_end(
            message_id=request.messages_list[0].metadata.reply_to_message_id
        )

        # Store Message object to descendants mapping and preregister objects
        objects_to_push: set[str] = set()
        for object_tree in request.message_object_trees:
            objects_to_push |= set(store.preregister(run_id, object_tree))

        # Save the message to the state
        state.store_message(message_from_proto(request.messages_list[0]))
        return PushAppMessagesResponse(objects_to_push=objects_to_push)

    def PushObject(
        self, request: PushObjectRequest, context: grpc.ServicerContext
    ) -> PushObjectResponse:
        """Push an object to the ObjectStore."""
        log(DEBUG, "ClientAppIoServicer.PushObject")

        # Init state and store
        store = self.objectstore_factory.store()

        # Insert in store
        stored = False
        try:
            store.put(request.object_id, request.object_content)
            stored = True
        except (NoObjectInStoreError, ValueError) as e:
            log(ERROR, str(e))
        except UnexpectedObjectContentError as e:
            # Object content is not valid
            context.abort(grpc.StatusCode.FAILED_PRECONDITION, str(e))

        return PushObjectResponse(stored=stored)

    def PullObject(
        self, request: PullObjectRequest, context: grpc.ServicerContext
    ) -> PullObjectResponse:
        """Pull an object from the ObjectStore."""
        log(DEBUG, "ClientAppIoServicer.PullObject")

        # Init state and store
        store = self.objectstore_factory.store()

        # Fetch from store
        content = store.get(request.object_id)
        if content is not None:
            object_available = content != b""
            return PullObjectResponse(
                object_found=True,
                object_available=object_available,
                object_content=content,
            )
        return PullObjectResponse(object_found=False, object_available=False)

    def ConfirmMessageReceived(
        self, request: ConfirmMessageReceivedRequest, context: grpc.ServicerContext
    ) -> ConfirmMessageReceivedResponse:
        """Confirm message received."""
        log(DEBUG, "ClientAppIoServicer.ConfirmMessageReceived")

        # Init state and store
        store = self.objectstore_factory.store()

        # Delete the message object
        store.delete(request.message_object_id)

        return ConfirmMessageReceivedResponse()

    def CreateTask(
        self, request: CreateTaskRequest, context: grpc.ServicerContext
    ) -> CreateTaskResponse:
        """Create a task for the given run ID."""
        log(DEBUG, "ClientAppIoServicer.CreateTask")

        raise NotImplementedError()
