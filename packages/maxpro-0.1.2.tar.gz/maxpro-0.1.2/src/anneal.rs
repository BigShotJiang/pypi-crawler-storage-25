#[cfg(feature = "pyo3-bindings")]
use crate::maximin_utils::maximin_criterion;
#[cfg(feature = "pyo3-bindings")]
use crate::maxpro_utils::maxpro_criterion;
#[cfg(feature = "pyo3-bindings")]
use pyo3::PyResult;
#[cfg(feature = "pyo3-bindings")]
use pyo3::exceptions::PyValueError;
#[cfg(feature = "pyo3-bindings")]
use pyo3::prelude::*;
use rand::Rng;
use rand::SeedableRng;
use rand::rngs::StdRng;

/// Perform a coordinate swap of two rows in a column
///
/// Arguments:
///     lhd (&Vec<Vec<f64>>): Initial design
///     rng (&mut StdRung): RNG for generating random indices
///
/// Returns:
///     Vec<Vec<f64>>: lhd with a coordinate swap
fn swap_rows(lhd: &mut Vec<Vec<f64>>, rng: &mut StdRng) {
    // Identify row and columns to switch
    let n_rows = lhd.len();
    let n_cols = lhd[0].len();

    // Iterate to find different values
    let swap_idx_1_row = rng.random_range(0..n_rows);
    let swap_idx_2_row = rng.random_range(0..n_rows);
    let swap_idx_col = rng.random_range(0..n_cols);

    // Get swap values
    let swap_value_1 = lhd[swap_idx_1_row][swap_idx_col];
    let swap_value_2 = lhd[swap_idx_2_row][swap_idx_col];

    // Swap values
    lhd[swap_idx_1_row][swap_idx_col] = swap_value_2;
    lhd[swap_idx_2_row][swap_idx_col] = swap_value_1;
}

/// Simulated annealing for improving (maximizing or minimizing) a given metric.
///
/// Arguments:
///     design (&Vec<Vec<f64>>): Initial design of points
///     n_iterations (u64): Number of iterations for annealing
///     initial_temp (f64): Initial temperature, used to control the metropolis algorithm acceptance
///     cooling rate (f64): Cooling rate, used to simulate annealing by reducing the metropolis algorithm acceptance
///     metric (F): A callable function that maps &Vec<Vec<f64>> to f64, used to minimize or maximize
///     minimize (bool): Whether to minimize or maximize the metric
///     seed (u64): Random number seed
///     swap (bool): Whether to use swapping or random jitter to find a more optimal design
///
/// Returns:
///     Vec<Vec<f64>>: A metric-optimized collection of points, not necessarily a latin hypercube.
pub fn anneal_lhd<F>(
    design: &Vec<Vec<f64>>,
    n_iterations: u64,
    initial_temp: f64,
    cooling_rate: f64,
    metric: F,
    minimize: bool,
    seed: u64,
    swap: bool,
) -> Vec<Vec<f64>>
where
    F: Fn(&Vec<Vec<f64>>) -> f64,
{
    if design.is_empty() {
        return design.to_vec();
    }
    assert!(
        n_iterations > 0,
        "n_iterations must be positive and nonzero"
    );
    assert!(
        initial_temp > 0.0,
        "initial_temp must be positive and nonzero"
    );

    let mut temp = initial_temp;
    let mut rng: StdRng = SeedableRng::seed_from_u64(seed);

    // Set max step size as +/- 1% of the size of the design interval
    // for jitter annealing
    let n_samples: usize = design.len();
    let step_size: f64 = 0.01 / n_samples as f64;

    let mut best_design = design.clone();
    let mut best_metric = metric(design);

    // Retain global best so annealing can never make a result worse
    let mut global_best_design = design.clone();
    let mut global_best_metric = best_metric;

    for _it in 0..n_iterations {
        let mut annealed_design = best_design.clone();
        if swap {
            // Swap rows
            swap_rows(&mut annealed_design, &mut rng);
        } else {
            for row in annealed_design.iter_mut() {
                for elem in row.iter_mut() {
                    // Dereference to update elem in place
                    *elem = (*elem + rng.random_range(-step_size..step_size)).clamp(0.0, 1.0)
                }
            }
        }
        // Calculate new metric
        let new_metric = metric(&annealed_design);
        let mut metric_diff = new_metric - best_metric;
        if !minimize {
            // Invert for maximization
            metric_diff *= -1.0
        }

        // Metropolis probability of acceptance
        let p_acceptance: f64 = if metric_diff < 0.0 {
            1.0
        } else {
            (-metric_diff / temp).exp()
        };

        // Metropolis acceptance
        if rng.random_range(0.0..1.0) < p_acceptance {
            best_design = annealed_design;
            best_metric = new_metric;
        }

        // Ensure the global best is returned
        if (minimize && best_metric < global_best_metric)
            || (!minimize && best_metric > global_best_metric)
        {
            global_best_design = best_design.clone();
            global_best_metric = best_metric;
        }

        // Cool for the next iteration
        temp *= cooling_rate;
    }

    global_best_design
}

#[cfg(feature = "pyo3-bindings")]
/// Anneal a latin hypercube to optimize its metric value.
/// Available metrics are "maxpro" and "maximin".
///
/// Args:
///     design (list[list[float]]): Input latin hypercube design
///     n_iterations (int): Number of optimizations to search for a better candidate
///     initial_temp (float): Initial temperature for annealing
///     cooling_rate (float): Cooling rate for annealing
///     metric_name (str): metric name; options are "maxpro" and "maximin"
///     minimize (bool): Whether to minimize the metric
///     swap (bool): Whether to use coordinate swap annealing
///     seed (int, optional): Seed for the random number generator.
///
/// Returns:
///     list[list[float]]: Optimized latin hypercube design
#[pyfunction(name = "anneal_lhd")]
pub fn py_anneal_lhd(
    design: Vec<Vec<f64>>,
    n_iterations: u64,
    initial_temp: f64,
    cooling_rate: f64,
    metric_name: String,
    minimize: bool,
    swap: bool,
    seed: Option<u64>,
) -> PyResult<Vec<Vec<f64>>> {
    if n_iterations == 0 {
        return Err(PyValueError::new_err(
            "n_iterations must be positive and nonzero",
        ));
    }
    if initial_temp <= 0.0 {
        return Err(PyValueError::new_err("initial_temp must be positive"));
    }
    let metric = match metric_name.to_lowercase().as_str() {
        "maxpro" => maxpro_criterion,
        "maximin" => maximin_criterion,
        _ => {
            return Err(PyValueError::new_err(format!(
                "Unknown metric: '{}'. Available metrics are 'maxpro' and 'maximin'.",
                metric_name
            )));
        }
    };
    let rng_seed = match seed {
        Some(x) => x,
        None => rand::random::<u64>(),
    };
    Ok(anneal_lhd(
        &design,
        n_iterations,
        initial_temp,
        cooling_rate,
        metric,
        minimize,
        rng_seed,
        swap,
    ))
}
