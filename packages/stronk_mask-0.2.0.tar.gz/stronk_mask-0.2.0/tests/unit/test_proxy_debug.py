from __future__ import annotations

from datetime import UTC, datetime

from stronk_mask.proxy import debug as debug_module
from stronk_mask.proxy.debug import UnsafeDebugTraceRecord, UnsafeDebugTraceStore
from stronk_mask.proxy.debug import cap_debug_value


def _record(request_id: str) -> UnsafeDebugTraceRecord:
    return UnsafeDebugTraceRecord(
        request_id=request_id,
        created_at=datetime.now(UTC).isoformat(),
        provider="openai",
        endpoint="/openai/v1/responses",
        model="gpt-test",
        stream=False,
        outcome="masked",
        status_code=200,
        request_original={"id": request_id},
        request_masked={"id": f"masked-{request_id}"},
        response_upstream=None,
        response_rehydrated=None,
    )


def test_unsafe_debug_trace_store_prunes_by_capacity_and_ttl(monkeypatch) -> None:
    clock = {"value": 100.0}

    def monotonic() -> float:
        return clock["value"]

    monkeypatch.setattr(debug_module.time, "monotonic", monotonic)

    store = UnsafeDebugTraceStore(max_entries=2, ttl_seconds=30)

    store.record(_record("req-1"))
    clock["value"] = 110.0
    store.record(_record("req-2"))
    clock["value"] = 120.0
    store.record(_record("req-3"))

    assert store.get("req-1") is None
    assert [item.request_id for item in store.list(limit=5)] == ["req-3", "req-2"]

    clock["value"] = 149.0
    assert store.get("req-2") is None
    assert [item.request_id for item in store.list(limit=5)] == ["req-3"]


def test_cap_debug_value_truncates_oversized_json_to_marker_string() -> None:
    capped = cap_debug_value({"text": "x" * 512}, limit_bytes=64)

    assert isinstance(capped, str)
    assert capped.startswith("[truncated ")
    assert "xxxx" in capped
