from __future__ import annotations

import tomllib
from pathlib import Path

import pytest

from stronk_mask.config import Settings
from stronk_mask.policy.engine import PolicyEngine
from stronk_mask.redaction.models import DetectorType, PolicyAction


def test_settings_defaults_are_privacy_preserving() -> None:
    settings = Settings()

    assert settings.allow_insecure_upstreams is False
    assert settings.enable_debug_mask_endpoint is False
    assert settings.enable_unsafe_debug_view is False
    assert settings.api_key_action == "block"
    assert settings.email_action == "mask"
    assert settings.business_id_action == "mask"
    assert settings.presidio_enabled is True
    assert settings.presidio_language_list == ("en", "zh")
    assert settings.admin_access_mode == "loopback"
    assert settings.admin_http_bind == "127.0.0.1"
    assert settings.admin_session_absolute_ttl_seconds == 43_200
    assert settings.admin_login_attempt_limit == 5
    assert settings.admin_login_attempt_window_seconds == 900


def test_policy_engine_respects_route_local_override() -> None:
    settings = Settings(phone_action="route_local")
    policy = PolicyEngine.from_settings(settings)

    assert policy.decide(DetectorType.PHONE, "/messages/0/content") is PolicyAction.ROUTE_LOCAL


def test_policy_engine_supports_business_id_action() -> None:
    settings = Settings(business_id_action="block")
    policy = PolicyEngine.from_settings(settings)

    assert policy.decide(DetectorType.BUSINESS_ID, "/message") is PolicyAction.BLOCK


def test_local_route_requires_base_url() -> None:
    with pytest.raises(ValueError):
        Settings(local_route_enabled=True)


def test_keepalive_connections_cannot_exceed_total_upstream_connections() -> None:
    with pytest.raises(ValueError):
        Settings(
            upstream_max_connections=8,
            upstream_max_keepalive_connections=9,
        )


def test_admin_api_requires_audit_storage() -> None:
    with pytest.raises(ValueError):
        Settings(enable_admin_api=True, audit_db_path="/tmp/stronk-mask.sqlite3")


def test_admin_ui_requires_admin_api() -> None:
    with pytest.raises(ValueError):
        Settings(
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-mask.sqlite3",
            enable_admin_ui=True,
        )


def test_admin_api_requires_bootstrap_credentials_in_session_mode() -> None:
    with pytest.raises(ValueError):
        Settings(
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-mask.sqlite3",
            enable_admin_api=True,
        )


def test_admin_api_requires_proxy_secret_in_trusted_header_mode() -> None:
    with pytest.raises(ValueError):
        Settings(
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-mask.sqlite3",
            enable_admin_api=True,
            admin_auth_mode="trusted_headers",
        )


def test_unsafe_debug_view_requires_audit_storage() -> None:
    with pytest.raises(ValueError):
        Settings(
            enable_unsafe_debug_view=True,
            admin_bootstrap_user="operator",
            admin_bootstrap_password_hash="hash",
            unsafe_debug_gateway_secret="gateway-secret",
        )


def test_unsafe_debug_view_requires_gateway_secret() -> None:
    with pytest.raises(ValueError):
        Settings(
            enable_unsafe_debug_view=True,
            audit_storage_enabled=True,
            audit_db_path="/tmp/stronk-mask.sqlite3",
            admin_bootstrap_user="operator",
            admin_bootstrap_password_hash="hash",
        )


def test_invalid_admin_auth_mode_is_rejected() -> None:
    with pytest.raises(ValueError):
        Settings(admin_auth_mode="nope")


def test_invalid_admin_access_mode_is_rejected() -> None:
    with pytest.raises(ValueError):
        Settings(admin_access_mode="nope")


def test_admin_http_bind_must_remain_loopback_bound() -> None:
    with pytest.raises(ValueError):
        Settings(admin_http_bind="0.0.0.0")


def test_trusted_proxy_mode_is_rejected_outside_tailscale_serve() -> None:
    with pytest.raises(ValueError):
        Settings(admin_trusted_proxy_mode="tailscale")


def test_enrollment_requirement_is_rejected_outside_tailscale_serve() -> None:
    with pytest.raises(ValueError):
        Settings(admin_enrollment_required=True)


def test_tailscale_serve_requires_origins_trusted_proxy_enrollment_and_secure_cookies() -> None:
    with pytest.raises(ValueError):
        Settings(admin_access_mode="tailscale-serve")

    with pytest.raises(ValueError):
        Settings(
            admin_access_mode="tailscale-serve",
            admin_allowed_origins="https://admin.example.ts.net",
        )

    with pytest.raises(ValueError):
        Settings(
            admin_access_mode="tailscale-serve",
            admin_allowed_origins="https://admin.example.ts.net",
            admin_trusted_proxy_mode="tailscale",
        )

    with pytest.raises(ValueError):
        Settings(
            admin_access_mode="tailscale-serve",
            admin_allowed_origins="https://admin.example.ts.net",
            admin_trusted_proxy_mode="tailscale",
            admin_enrollment_required=True,
        )


def test_tailscale_serve_accepts_the_locked_phase_two_contract() -> None:
    settings = Settings(
        audit_storage_enabled=True,
        audit_db_path="/tmp/stronk-mask.sqlite3",
        enable_admin_api=True,
        admin_bootstrap_user="operator",
        admin_bootstrap_password_hash="hash",
        admin_access_mode="tailscale-serve",
        admin_allowed_origins="https://admin.example.ts.net",
        admin_trusted_proxy_mode="tailscale",
        admin_enrollment_required=True,
        admin_session_secure_cookies=True,
    )

    assert settings.admin_access_mode == "tailscale-serve"
    assert settings.admin_allowed_origin_set == frozenset({"https://admin.example.ts.net"})


def test_runtime_dependencies_include_websocket_backend() -> None:
    pyproject_path = Path(__file__).resolve().parents[2] / "pyproject.toml"
    data = tomllib.loads(pyproject_path.read_text(encoding="utf-8"))
    dependencies = data["project"]["dependencies"]

    assert any(
        dependency.startswith("websockets")
        or dependency.startswith("wsproto")
        or dependency.startswith("uvicorn[standard]")
        for dependency in dependencies
    )


def test_compose_proxy_includes_debug_admin_and_gateway_secrets() -> None:
    compose_path = Path(__file__).resolve().parents[2] / "compose" / "docker-compose.yml"
    compose_text = compose_path.read_text(encoding="utf-8")

    assert "STRONK_MASK_ADMIN_BOOTSTRAP_PASSWORD_HASH" in compose_text
    assert "STRONK_MASK_UNSAFE_DEBUG_GATEWAY_SECRET" in compose_text
