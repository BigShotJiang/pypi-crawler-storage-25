from __future__ import annotations

import asyncio
import inspect
import json
import re
import time
from collections.abc import Awaitable, Callable
from contextlib import contextmanager
from typing import Any, TypeVar

import httpx
from fastapi.testclient import TestClient

from stronk_mask.app import build_runtime_apps, create_full_app
from stronk_mask.config import Settings

PLACEHOLDER_REGEX = re.compile(r"\[\[[A-Z_]+_\d+\]\]")
T = TypeVar("T")


class StaticAsyncByteStream(httpx.AsyncByteStream):
    def __init__(self, chunks: list[bytes]) -> None:
        self.chunks = chunks

    async def __aiter__(self):  # type: ignore[override]
        for chunk in self.chunks:
            yield chunk

    async def aclose(self) -> None:
        return None


Handler = Callable[[httpx.Request, bytes], httpx.Response | Awaitable[httpx.Response]]


class RecordingTransport(httpx.AsyncBaseTransport):
    def __init__(self, handler: Handler) -> None:
        self.handler = handler
        self.requests: list[dict[str, Any]] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        body = await request.aread()
        self.requests.append(
            {
                "method": request.method,
                "url": str(request.url),
                "headers": dict(request.headers),
                "body": body,
                "json": json.loads(body) if body else None,
            }
        )
        response = self.handler(request, body)
        if inspect.isawaitable(response):
            return await response
        return response


def build_test_client(
    handler: Handler,
    **overrides: Any,
) -> tuple[TestClient, RecordingTransport]:
    transport = RecordingTransport(handler)
    settings = Settings(
        openai_upstream_base_url="http://openai.test",
        anthropic_upstream_base_url="http://anthropic.test",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
        admin_auth_mode="trusted_headers",
        **overrides,
    )
    client = TestClient(create_full_app(settings=settings, upstream_transport=transport))
    return client, transport


@contextmanager
def build_runtime_clients(
    handler: Handler,
    **overrides: Any,
):
    transport = RecordingTransport(handler)
    settings = Settings(
        openai_upstream_base_url="http://openai.test",
        anthropic_upstream_base_url="http://anthropic.test",
        allow_insecure_upstreams=True,
        allow_nonstandard_upstream_hosts=True,
        admin_auth_mode="trusted_headers",
        **overrides,
    )
    runtime = build_runtime_apps(settings=settings, upstream_transport=transport)
    asyncio.run(runtime.proxy_service.startup())
    try:
        with TestClient(runtime.public_app) as public_client, TestClient(runtime.debug_app) as debug_client:
            yield public_client, debug_client, transport
    finally:
        asyncio.run(runtime.proxy_service.shutdown())


def contains_placeholder(text: str) -> bool:
    return bool(PLACEHOLDER_REGEX.search(text))


def eventually(
    operation: Callable[[], T],
    *,
    predicate: Callable[[T], bool],
    timeout_seconds: float = 1.0,
    interval_seconds: float = 0.01,
) -> T:
    deadline = time.monotonic() + timeout_seconds
    result = operation()
    while not predicate(result):
        if time.monotonic() >= deadline:
            break
        time.sleep(interval_seconds)
        result = operation()
    return result
