from __future__ import annotations

import json
import re

import httpx

from tests.helpers import StaticAsyncByteStream, build_test_client, contains_placeholder

OPAQUE_REQUEST_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")


def test_openai_chat_completions_masks_upstream_and_rehydrates_response() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        response_payload = {
            "id": "chatcmpl-1",
            "object": "chat.completion",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": f"Echo: {masked_text}",
                        "tool_calls": [
                            {
                                "id": "call_1",
                                "type": "function",
                                "function": {
                                    "name": "lookup",
                                    "arguments": json.dumps(
                                        {"contact": masked_text},
                                        ensure_ascii=False,
                                    ),
                                },
                            }
                        ],
                    },
                    "finish_reason": "stop",
                }
            ],
        }
        return httpx.Response(
            200,
            json=response_payload,
            headers={"content-type": "application/json", "x-request-id": "req-1"},
        )

    client, transport = build_test_client(handler)
    original = "please contact Alice Johnson at alice@example.com"

    response = client.post(
        "/openai/v1/chat/completions",
        json={"model": "gpt-4.1", "messages": [{"role": "user", "content": original}]},
        headers={"Authorization": "Bearer upstream-token", "Cookie": "session=1"},
    )

    assert response.status_code == 200
    body = transport.requests[0]["body"].decode("utf-8")
    assert "Alice Johnson" not in body
    assert "alice@example.com" not in body
    assert contains_placeholder(body)
    assert "cookie" not in {key.lower() for key in transport.requests[0]["headers"]}

    payload = response.json()
    assert payload["choices"][0]["message"]["content"] == f"Echo: {original}"
    arguments = payload["choices"][0]["message"]["tool_calls"][0]["function"]["arguments"]
    assert original not in arguments
    assert contains_placeholder(arguments)


def test_shared_upstream_client_does_not_persist_upstream_cookies_between_requests() -> None:
    observed_cookie_headers: list[str | None] = []

    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        observed_cookie_headers.append(request.headers.get("cookie"))
        masked_text = json.loads(body)["messages"][0]["content"]
        headers = {"content-type": "application/json"}
        if len(observed_cookie_headers) == 1:
            headers["set-cookie"] = "upstream_session=abc123; Path=/; HttpOnly"
        return httpx.Response(
            200,
            json={
                "id": "chatcmpl-cookie-test",
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": f"Echo: {masked_text}"},
                        "finish_reason": "stop",
                    }
                ],
            },
            headers=headers,
        )

    client, _ = build_test_client(handler)

    for suffix in ("first", "second"):
        response = client.post(
            "/openai/v1/chat/completions",
            json={
                "model": "gpt-4.1",
                "messages": [{"role": "user", "content": f"Alice Johnson alice@example.com {suffix}"}],
            },
            headers={"Authorization": "Bearer upstream-token"},
        )
        assert response.status_code == 200

    assert observed_cookie_headers == [None, None]


def test_openai_responses_endpoint_is_not_a_gap_and_supports_streaming() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        if payload.get("stream") is True:
            masked_text = payload["input"][0]["content"][0]["text"]
            half = len(masked_text) // 2
            chunks = [
                (
                    "data: "
                    + json.dumps(
                        {"type": "response.output_text.delta", "delta": f"{masked_text[:half]}"},
                        ensure_ascii=False,
                    )
                    + "\n\n"
                ).encode("utf-8"),
                (
                    "data: "
                    + json.dumps(
                        {
                            "type": "response.output_text.delta",
                            "delta": f"{masked_text[half:]} done",
                        },
                        ensure_ascii=False,
                    )
                    + "\n\n"
                ).encode("utf-8"),
                b"data: [DONE]\n\n",
            ]
            return httpx.Response(
                200,
                headers={"content-type": "text/event-stream"},
                stream=StaticAsyncByteStream(chunks),
            )

        masked_text = payload["input"][0]["content"][0]["text"]
        return httpx.Response(
            200,
            json={
                "id": "resp_1",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": masked_text,
                            }
                        ],
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)
    original = "请联系张三，邮箱是 zhangsan@example.com"

    response = client.post(
        "/openai/v1/responses",
        json={
            "model": "gpt-4.1",
            "input": [{"role": "user", "content": [{"type": "input_text", "text": original}]}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 200
    body = transport.requests[0]["body"].decode("utf-8")
    assert "张三" not in body
    assert "zhangsan@example.com" not in body
    assert response.json()["output"][0]["content"][0]["text"] == original

    stream_response = client.post(
        "/openai/v1/responses",
        json={
            "model": "gpt-4.1",
            "stream": True,
            "input": [{"role": "user", "content": [{"type": "input_text", "text": original}]}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    delta_text = "".join(
        json.loads(line.removeprefix("data: "))["delta"]
        for line in stream_response.iter_lines()
        if line.startswith("data: {")
    )
    assert delta_text == f"{original} done"
    assert not contains_placeholder(delta_text)


def test_openai_responses_rejects_sensitive_top_level_tools_before_upstream() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        raise AssertionError("sensitive top-level tools must be rejected before upstream")

    client, transport = build_test_client(handler)
    original = "Please contact Alice Johnson at alice@example.com."
    tool_description = (
        "Example email debug@example.com, page id "
        "a1b2c3d4-e5f6-7890-abcd-ef1234567890."
    )

    response = client.post(
        "/openai/v1/responses",
        json={
            "model": "gpt-4.1",
            "tools": [
                {
                    "type": "function",
                    "name": "notion_search",
                    "description": tool_description,
                }
            ],
            "input": [{"role": "user", "content": [{"type": "input_text", "text": original}]}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 422
    assert transport.requests == []
    assert "debug@example.com" not in response.text
    assert "alice@example.com" not in response.text


def test_openai_responses_masks_instructions_and_developer_system_messages() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        instructions = payload["instructions"]
        developer_text = payload["input"][0]["content"][0]["text"]
        system_text = payload["input"][1]["content"][0]["text"]
        user_text = payload["input"][2]["content"][0]["text"]
        return httpx.Response(
            200,
            json={
                "id": "resp_3",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": user_text,
                            }
                        ],
                    }
                ],
                "debug": {
                    "instructions": instructions,
                    "developer": developer_text,
                    "system": system_text,
                },
            },
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)
    instructions_text = "Instructions mention instr@example.com"
    developer_text = "Developer dev@example.com"
    system_text = "System sys@example.com"
    user_text = "Please email user@example.com today."

    response = client.post(
        "/openai/v1/responses",
        json={
            "model": "gpt-4.1",
            "instructions": instructions_text,
            "input": [
                {"role": "developer", "content": [{"type": "input_text", "text": developer_text}]},
                {"role": "system", "content": [{"type": "input_text", "text": system_text}]},
                {"role": "user", "content": [{"type": "input_text", "text": user_text}]},
            ],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 200
    upstream_payload = transport.requests[0]["json"]
    assert upstream_payload["instructions"] != instructions_text
    assert "instr@example.com" not in json.dumps(upstream_payload["instructions"], ensure_ascii=False)
    assert upstream_payload["input"][0]["content"][0]["text"] != developer_text
    assert upstream_payload["input"][1]["content"][0]["text"] != system_text
    assert upstream_payload["input"][2]["content"][0]["text"] != user_text
    assert "dev@example.com" not in json.dumps(upstream_payload["input"][0], ensure_ascii=False)
    assert "sys@example.com" not in json.dumps(upstream_payload["input"][1], ensure_ascii=False)
    assert "user@example.com" not in json.dumps(upstream_payload["input"][2], ensure_ascii=False)
    assert response.json()["output"][0]["content"][0]["text"] == user_text


def test_openai_responses_strips_private_headers_and_normalizes_invalid_request_id() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        return httpx.Response(
            200,
            json={"id": "resp_5", "output": payload.get("input", [])},
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)

    response = client.post(
        "/openai/v1/responses",
        json={
            "model": "gpt-4.1",
            "input": [{"role": "user", "content": [{"type": "input_text", "text": "hello"}]}],
        },
        headers={
            "Authorization": "Bearer upstream-token",
            "X-Codex-Turn-Metadata": "operator=alice@example.com",
            "X-Codex-Turn-State": "caller-turn-state",
            "X-Request-Id": "Alice Johnson alice@example.com",
        },
    )

    assert response.status_code == 200
    upstream_headers = {key.lower(): value for key, value in transport.requests[0]["headers"].items()}
    assert upstream_headers["authorization"] == "Bearer upstream-token"
    assert "x-codex-turn-metadata" not in upstream_headers
    assert "x-codex-turn-state" not in upstream_headers
    assert upstream_headers["x-request-id"] != "Alice Johnson alice@example.com"
    assert OPAQUE_REQUEST_ID_RE.fullmatch(upstream_headers["x-request-id"])


def test_openai_responses_preserves_path_like_filenames_while_masking_other_values() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["input"][0]["content"][0]["text"]
        return httpx.Response(
            200,
            json={
                "id": "resp_4",
                "output": [
                    {
                        "type": "message",
                        "content": [
                            {
                                "type": "output_text",
                                "text": masked_text,
                            }
                        ],
                    }
                ],
            },
            headers={"content-type": "application/json"},
        )

    client, transport = build_test_client(handler)
    original = (
        "Open /Users/eyy/Downloads/李琳-重点项目进度12月份.xlsx and email alice@example.com "
        "to EYYCHEEV GAMES INC."
    )

    response = client.post(
        "/openai/v1/responses",
        json={
            "model": "gpt-4.1",
            "input": [{"role": "user", "content": [{"type": "input_text", "text": original}]}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    assert response.status_code == 200
    upstream_payload = transport.requests[0]["json"]
    upstream_text = upstream_payload["input"][0]["content"][0]["text"]
    assert "/Users/eyy/Downloads/李琳-重点项目进度12月份.xlsx" in upstream_text
    assert "alice@example.com" not in upstream_text
    assert "EYYCHEEV GAMES INC." not in upstream_text
    assert response.json()["output"][0]["content"][0]["text"] == original


def test_openai_chat_streaming_rehydrates_split_placeholders() -> None:
    def handler(request: httpx.Request, body: bytes) -> httpx.Response:
        payload = json.loads(body)
        masked_text = payload["messages"][0]["content"]
        half = len(masked_text) // 2
        chunks = [
            (
                "data: "
                + json.dumps(
                    {"choices": [{"delta": {"content": masked_text[:half]}}]},
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            (
                "data: "
                + json.dumps(
                    {"choices": [{"delta": {"content": f"{masked_text[half:]} done"}}]},
                    ensure_ascii=False,
                )
                + "\n\n"
            ).encode("utf-8"),
            b"data: [DONE]\n\n",
        ]
        return httpx.Response(
            200,
            headers={"content-type": "text/event-stream"},
            stream=StaticAsyncByteStream(chunks),
        )

    client, _ = build_test_client(handler)
    original = "please contact Alice Johnson at alice@example.com"

    response = client.post(
        "/openai/v1/chat/completions",
        json={
            "model": "gpt-4.1",
            "stream": True,
            "messages": [{"role": "user", "content": original}],
        },
        headers={"Authorization": "Bearer upstream-token"},
    )

    delta_text = "".join(
        json.loads(line.removeprefix("data: "))["choices"][0]["delta"]["content"]
        for line in response.iter_lines()
        if line.startswith("data: {")
    )
    assert delta_text == f"{original} done"
    assert not contains_placeholder(delta_text)
