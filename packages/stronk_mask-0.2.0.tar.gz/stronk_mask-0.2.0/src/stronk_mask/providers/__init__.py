from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ProviderSpec:
    name: str
    public_path: str
    upstream_path: str
    request_headers: frozenset[str]
    error_shape: str


OPENAI_REQUEST_HEADERS = frozenset(
    {
        "accept",
        "authorization",
        "content-type",
        "openai-beta",
        "openai-organization",
        "openai-project",
        "x-request-id",
        "x-responsesapi-include-timing-metrics",
    }
)
ANTHROPIC_REQUEST_HEADERS = frozenset(
    {
        "accept",
        "anthropic-beta",
        "anthropic-version",
        "content-type",
        "x-api-key",
        "x-request-id",
    }
)

OPENAI_CHAT_COMPLETIONS = ProviderSpec(
    name="openai",
    public_path="/openai/v1/chat/completions",
    upstream_path="/v1/chat/completions",
    request_headers=OPENAI_REQUEST_HEADERS,
    error_shape="openai",
)
OPENAI_RESPONSES = ProviderSpec(
    name="openai",
    public_path="/openai/v1/responses",
    upstream_path="/v1/responses",
    request_headers=OPENAI_REQUEST_HEADERS,
    error_shape="openai",
)
ANTHROPIC_MESSAGES = ProviderSpec(
    name="anthropic",
    public_path="/anthropic/v1/messages",
    upstream_path="/v1/messages",
    request_headers=ANTHROPIC_REQUEST_HEADERS,
    error_shape="anthropic",
)

__all__ = [
    "ANTHROPIC_MESSAGES",
    "OPENAI_CHAT_COMPLETIONS",
    "OPENAI_RESPONSES",
    "ProviderSpec",
]
