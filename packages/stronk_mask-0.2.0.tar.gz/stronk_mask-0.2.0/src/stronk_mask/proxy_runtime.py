from __future__ import annotations

import asyncio
import os
import signal
from collections.abc import Sequence

import uvicorn

from stronk_mask.app import build_runtime_apps
from stronk_mask.config import get_settings

PUBLIC_PROXY_PORT = 8787
DEBUG_BRIDGE_PORT = 8789


def main() -> None:
    asyncio.run(_serve())


async def _serve() -> None:
    settings = get_settings()
    runtime = build_runtime_apps(settings=settings)
    public_server = _build_server(
        runtime.public_app,
        host="0.0.0.0",
        port=int(os.getenv("STRONK_MASK_PROXY_PUBLIC_PORT", str(PUBLIC_PROXY_PORT))),
        log_level=settings.log_level,
    )
    debug_server = _build_server(
        runtime.debug_app,
        host="0.0.0.0",
        port=int(os.getenv("STRONK_MASK_PROXY_DEBUG_PORT", str(DEBUG_BRIDGE_PORT))),
        log_level=settings.log_level,
    )
    stop_event = asyncio.Event()
    stop_task = asyncio.create_task(stop_event.wait())
    _install_signal_handlers(stop_event)
    await runtime.proxy_service.startup()
    public_task = asyncio.create_task(public_server.serve())
    debug_task = asyncio.create_task(debug_server.serve())
    try:
        done, pending = await asyncio.wait(
            {public_task, debug_task, stop_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if stop_task not in done:
            stop_event.set()
        public_server.should_exit = True
        debug_server.should_exit = True
        await asyncio.gather(public_task, debug_task, return_exceptions=True)
        _raise_task_error(public_task)
        _raise_task_error(debug_task)
    finally:
        stop_task.cancel()
        await runtime.proxy_service.shutdown()


def _build_server(app, *, host: str, port: int, log_level: str) -> uvicorn.Server:
    config = uvicorn.Config(
        app,
        host=host,
        port=port,
        log_level=log_level.lower(),
        lifespan="off",
    )
    server = uvicorn.Server(config)
    server.install_signal_handlers = lambda: None
    return server


def _install_signal_handlers(stop_event: asyncio.Event) -> None:
    loop = asyncio.get_running_loop()
    for signum in _supported_signals():
        try:
            loop.add_signal_handler(signum, stop_event.set)
        except NotImplementedError:
            return


def _supported_signals() -> Sequence[signal.Signals]:
    return (signal.SIGINT, signal.SIGTERM)


def _raise_task_error(task: asyncio.Task[bool]) -> None:
    if task.cancelled():
        return
    exception = task.exception()
    if exception is not None:
        raise exception


if __name__ == "__main__":
    main()
