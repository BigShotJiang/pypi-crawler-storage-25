from __future__ import annotations

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime settings for the proxy."""

    app_name: str = "stronk-mask"
    app_env: str = "development"
    log_level: str = "INFO"
    openai_upstream_base_url: str = Field(
        default="https://api.openai.com",
        description="Upstream OpenAI-compatible base URL.",
    )
    anthropic_upstream_base_url: str = Field(
        default="https://api.anthropic.com",
        description="Upstream Anthropic-compatible base URL.",
    )
    request_timeout_seconds: float = Field(default=30.0, gt=0.0, le=120.0)
    upstream_max_connections: int = Field(default=128, ge=1, le=2_048)
    upstream_max_keepalive_connections: int = Field(default=32, ge=0, le=2_048)
    max_request_body_bytes: int = Field(default=1_048_576, gt=0)
    websocket_frame_byte_cap: int = Field(default=65_536, ge=1_024, le=2_097_152)
    websocket_idle_timeout_seconds: float = Field(default=30.0, gt=0.0, le=600.0)
    websocket_message_limit: int = Field(default=64, ge=1, le=10_000)
    websocket_consecutive_error_limit: int = Field(default=8, ge=1, le=100)
    websocket_turn_state_max_length: int = Field(default=128, ge=16, le=512)
    websocket_active_session_cap: int = Field(default=512, ge=1, le=10_000)
    allow_insecure_upstreams: bool = False
    allow_nonstandard_upstream_hosts: bool = False
    enable_debug_mask_endpoint: bool = False
    local_route_enabled: bool = False
    local_route_base_url: str | None = None
    audit_storage_enabled: bool = False
    audit_db_path: str | None = None
    audit_max_events: int = Field(default=2_000, ge=100, le=100_000)
    audit_prune_interval: int = Field(default=64, ge=1, le=4_096)
    audit_queue_maxsize: int = Field(default=2_048, ge=1, le=100_000)
    enable_admin_api: bool = False
    enable_admin_ui: bool = False
    admin_auth_mode: str = "session"
    admin_bootstrap_user: str | None = None
    admin_bootstrap_password_hash: str | None = None
    admin_bootstrap_roles: str = "admin,operator"
    admin_trace_allowed_roles: str = "admin,operator"
    admin_access_mode: str = "loopback"
    admin_http_bind: str = "127.0.0.1"
    admin_http_port: int = Field(default=8788, ge=1, le=65_535)
    admin_allowed_origins: str = ""
    admin_trusted_proxy_mode: str = "off"
    admin_enrollment_required: bool = False
    admin_session_cookie_name: str = "stronk_admin_session"
    admin_session_idle_ttl_seconds: int = Field(default=1_800, ge=60, le=86_400)
    admin_session_absolute_ttl_seconds: int = Field(default=43_200, ge=300, le=604_800)
    admin_session_secure_cookies: bool = False
    admin_login_attempt_limit: int = Field(default=5, ge=1, le=100)
    admin_login_attempt_window_seconds: int = Field(default=900, ge=30, le=86_400)
    admin_tailscale_socket_path: str = "/var/run/tailscale/tailscaled.sock"
    enable_unsafe_debug_view: bool = False
    unsafe_debug_max_entries: int = Field(default=25, ge=1, le=500)
    unsafe_debug_ttl_seconds: int = Field(default=900, ge=30, le=86_400)
    unsafe_debug_stream_tail_bytes: int = Field(default=16_384, ge=256, le=1_048_576)
    unsafe_debug_body_capture_bytes: int = Field(default=16_384, ge=256, le=1_048_576)
    unsafe_debug_gateway_secret: str | None = None
    admin_debug_bridge_base_url: str = "http://stronk-mask:8789"
    admin_user_header: str = "X-Stronk-Admin-User"
    admin_roles_header: str = "X-Stronk-Admin-Roles"
    admin_allowed_roles: str = "admin,operator,auditor"
    admin_proxy_secret_header: str = "X-Stronk-Admin-Proxy-Secret"
    admin_proxy_secret: str | None = None
    admin_access_log_max_entries: int = Field(default=500, ge=50, le=100_000)
    admin_ui_dir: str | None = None

    presidio_enabled: bool = True
    presidio_supported_languages: str = "en,zh"
    presidio_score_threshold: float = Field(default=0.7, ge=0.0, le=1.0)
    presidio_english_model: str = "en_core_web_sm"
    presidio_chinese_model: str = "zh_core_web_sm"

    email_action: str = "mask"
    phone_action: str = "mask"
    business_id_action: str = "mask"
    person_name_action: str = "mask"
    organization_action: str = "mask"
    address_action: str = "mask"
    api_key_action: str = "block"
    bearer_token_action: str = "block"
    jwt_action: str = "block"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_prefix="STRONK_MASK_",
        extra="ignore",
    )

    @model_validator(mode="after")
    def validate_local_route(self) -> Settings:
        allowed_auth_modes = {"session", "trusted_headers", "hybrid"}
        allowed_access_modes = {"loopback", "ssh-forward", "tailscale-serve"}
        allowed_trusted_proxy_modes = {"off", "tailscale"}
        if self.admin_auth_mode not in allowed_auth_modes:
            raise ValueError(
                "STRONK_MASK_ADMIN_AUTH_MODE must be one of: session, trusted_headers, hybrid."
            )
        if self.admin_access_mode not in allowed_access_modes:
            raise ValueError(
                "STRONK_MASK_ADMIN_ACCESS_MODE must be one of: loopback, ssh-forward, tailscale-serve."
            )
        if self.admin_trusted_proxy_mode not in allowed_trusted_proxy_modes:
            raise ValueError(
                "STRONK_MASK_ADMIN_TRUSTED_PROXY_MODE must be one of: off, tailscale."
            )
        if self.upstream_max_keepalive_connections > self.upstream_max_connections:
            raise ValueError(
                "STRONK_MASK_UPSTREAM_MAX_KEEPALIVE_CONNECTIONS must be less than or equal to "
                "STRONK_MASK_UPSTREAM_MAX_CONNECTIONS."
            )
        if self.local_route_enabled and not self.local_route_base_url:
            raise ValueError(
                "STRONK_MASK_LOCAL_ROUTE_BASE_URL is required when local routing is enabled."
            )
        if (self.audit_storage_enabled or self.enable_admin_api or self.enable_admin_ui) and (
            not self.audit_db_path
        ):
            raise ValueError(
                "STRONK_MASK_AUDIT_DB_PATH is required when audit storage "
                "or admin surfaces are enabled."
            )
        if self.enable_admin_api and not self.audit_storage_enabled:
            raise ValueError(
                "STRONK_MASK_AUDIT_STORAGE_ENABLED must be true when admin API is enabled."
            )
        if self.enable_admin_ui and not self.enable_admin_api:
            raise ValueError("STRONK_MASK_ENABLE_ADMIN_API must be true when admin UI is enabled.")
        if self.enable_admin_api and self.admin_auth_mode in {"session", "hybrid"}:
            if not self.admin_bootstrap_user:
                raise ValueError(
                    "STRONK_MASK_ADMIN_BOOTSTRAP_USER is required when session-based admin auth is enabled."
                )
            if not self.admin_bootstrap_password_hash:
                raise ValueError(
                    "STRONK_MASK_ADMIN_BOOTSTRAP_PASSWORD_HASH is required when session-based admin auth is enabled."
                )
        if self.enable_admin_api and self.admin_auth_mode in {"trusted_headers", "hybrid"}:
            if not self.admin_proxy_secret:
                raise ValueError(
                    "STRONK_MASK_ADMIN_PROXY_SECRET is required when trusted-header admin auth is enabled."
                )
        if self.admin_trusted_proxy_mode != "off" and self.admin_access_mode != "tailscale-serve":
            raise ValueError(
                "STRONK_MASK_ADMIN_TRUSTED_PROXY_MODE may only be enabled for tailscale-serve access."
            )
        if self.admin_http_bind not in {"127.0.0.1", "::1", "localhost"}:
            raise ValueError(
                "STRONK_MASK_ADMIN_HTTP_BIND must remain loopback-bound for supported admin access modes."
            )
        if self.admin_enrollment_required and self.admin_access_mode != "tailscale-serve":
            raise ValueError(
                "STRONK_MASK_ADMIN_ENROLLMENT_REQUIRED may only be enabled for tailscale-serve access."
            )
        if self.admin_access_mode == "tailscale-serve":
            if not self.admin_allowed_origin_set:
                raise ValueError(
                    "STRONK_MASK_ADMIN_ALLOWED_ORIGINS is required when tailscale-serve access is enabled."
                )
            if self.admin_trusted_proxy_mode != "tailscale":
                raise ValueError(
                    "STRONK_MASK_ADMIN_TRUSTED_PROXY_MODE must be tailscale when tailscale-serve access is enabled."
                )
            if not self.admin_enrollment_required:
                raise ValueError(
                    "STRONK_MASK_ADMIN_ENROLLMENT_REQUIRED must be true when tailscale-serve access is enabled."
                )
            if not self.admin_session_secure_cookies:
                raise ValueError(
                    "STRONK_MASK_ADMIN_SESSION_SECURE_COOKIES must be true when tailscale-serve access is enabled."
                )
        if self.enable_unsafe_debug_view:
            if not self.audit_storage_enabled:
                raise ValueError(
                    "STRONK_MASK_AUDIT_STORAGE_ENABLED must be true when unsafe debug "
                    "view is enabled."
                )
            if not self.unsafe_debug_gateway_secret:
                raise ValueError(
                    "STRONK_MASK_UNSAFE_DEBUG_GATEWAY_SECRET is required when unsafe debug "
                    "view is enabled."
                )
            if self.admin_auth_mode in {"trusted_headers", "hybrid"} and not self.admin_proxy_secret:
                raise ValueError(
                    "STRONK_MASK_ADMIN_PROXY_SECRET is required when unsafe debug view uses trusted-header admin auth."
                )
        return self

    @property
    def admin_allowed_role_set(self) -> frozenset[str]:
        return frozenset(
            role.strip().lower()
            for role in self.admin_allowed_roles.split(",")
            if role.strip()
        )

    @property
    def admin_bootstrap_role_set(self) -> frozenset[str]:
        return frozenset(
            role.strip().lower()
            for role in self.admin_bootstrap_roles.split(",")
            if role.strip()
        )

    @property
    def admin_trace_allowed_role_set(self) -> frozenset[str]:
        return frozenset(
            role.strip().lower()
            for role in self.admin_trace_allowed_roles.split(",")
            if role.strip()
        )

    @property
    def admin_allowed_origin_set(self) -> frozenset[str]:
        return frozenset(
            origin.strip().rstrip("/")
            for origin in self.admin_allowed_origins.split(",")
            if origin.strip()
        )

    @property
    def presidio_language_list(self) -> tuple[str, ...]:
        return tuple(
            language.strip().lower()
            for language in self.presidio_supported_languages.split(",")
            if language.strip()
        )


def get_settings() -> Settings:
    return Settings()
