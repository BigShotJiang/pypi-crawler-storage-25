import { AnimatePresence, LayoutGroup, motion } from "framer-motion";
import { FormEvent, useEffect, useMemo, useState } from "react";

import {
  ApiError,
  fetchConfig,
  fetchDebugTrace,
  fetchEvent,
  fetchEvents,
  fetchOverview,
  fetchSession,
  loginSession,
  logoutSession,
} from "./api";
import { DebugDiffDeck } from "./debug-diff";
import type { AuditEvent, ConfigSummary, DebugTrace, Overview, SessionSummary } from "./types";

type ThemeMode = "light" | "dark";

const THEME_KEY = "stronk-mask-theme";
const REFRESH_MS = 8000;

export default function App() {
  const [theme, setTheme] = useState<ThemeMode>(() => {
    const stored = window.localStorage.getItem(THEME_KEY);
    if (stored === "light" || stored === "dark") {
      return stored;
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  });
  const [session, setSession] = useState<SessionSummary | null>(null);
  const [authResolved, setAuthResolved] = useState(false);
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [overview, setOverview] = useState<Overview | null>(null);
  const [config, setConfig] = useState<ConfigSummary | null>(null);
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedEvent, setSelectedEvent] = useState<AuditEvent | null>(null);
  const [selectedDebugTrace, setSelectedDebugTrace] = useState<DebugTrace | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    window.localStorage.setItem(THEME_KEY, theme);
  }, [theme]);

  useEffect(() => {
    let active = true;
    void fetchSession()
      .then((payload) => {
        if (!active) {
          return;
        }
        setSession(payload);
        setAuthResolved(true);
      })
      .catch((loadError) => {
        if (!active) {
          return;
        }
        setLoginError(loadError instanceof Error ? loadError.message : "Failed to resolve the admin session.");
        setAuthResolved(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!session) {
      setOverview(null);
      setConfig(null);
      setEvents([]);
      setSelectedId(null);
      setSelectedEvent(null);
      setSelectedDebugTrace(null);
      setError(null);
      return;
    }

    let active = true;

    async function load() {
      try {
        const [overviewPayload, configPayload, eventsPayload] = await Promise.all([
          fetchOverview(),
          fetchConfig(),
          fetchEvents(),
        ]);
        if (!active) {
          return;
        }
        setOverview(overviewPayload);
        setConfig(configPayload);
        setEvents(eventsPayload.items);
        setSelectedId((current) => current ?? eventsPayload.items[0]?.request_id ?? null);
        setError(null);
      } catch (loadError) {
        if (!active) {
          return;
        }
        if (loadError instanceof ApiError && loadError.status === 401) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setError(loadError instanceof Error ? loadError.message : "Failed to load control plane data.");
      }
    }

    void load();
    const timer = window.setInterval(() => {
      void load();
    }, REFRESH_MS);
    return () => {
      active = false;
      window.clearInterval(timer);
    };
  }, [session]);

  useEffect(() => {
    if (!session || !selectedId) {
      setSelectedEvent(null);
      setSelectedDebugTrace(null);
      return;
    }

    let active = true;
    const contentTraceEnabled = config?.control_plane.content_trace_enabled ?? session.content_trace_enabled;
    const traceAccess = config?.auth.trace_access ?? session.trace_access;

    void Promise.all([
      fetchEvent(selectedId),
      contentTraceEnabled && traceAccess ? fetchDebugTrace(selectedId) : Promise.resolve(null),
    ])
      .then(([eventPayload, debugTracePayload]) => {
        if (!active) {
          return;
        }
        setSelectedEvent(eventPayload);
        setSelectedDebugTrace(debugTracePayload);
      })
      .catch((loadError) => {
        if (!active) {
          return;
        }
        if (loadError instanceof ApiError && loadError.status === 401) {
          setSession(null);
          setLoginError("Your admin session expired. Sign in again to continue.");
          return;
        }
        setError(loadError instanceof Error ? loadError.message : "Failed to load selected event.");
      });

    return () => {
      active = false;
    };
  }, [
    config?.auth.trace_access,
    config?.control_plane.content_trace_enabled,
    selectedId,
    session,
  ]);

  const providerBreakdown = useMemo(
    () => buildKeyValueRows(overview?.provider_counts ?? {}),
    [overview?.provider_counts],
  );
  const detectorBreakdown = useMemo(
    () => buildKeyValueRows(overview?.detector_counts ?? {}),
    [overview?.detector_counts],
  );
  const actionBreakdown = useMemo(
    () => buildKeyValueRows(overview?.action_counts ?? {}),
    [overview?.action_counts],
  );

  async function handleLogin(username: string, password: string) {
    setLoginBusy(true);
    setLoginError(null);
    try {
      const nextSession = await loginSession(username, password);
      setSession(nextSession);
    } catch (loginFailure) {
      if (loginFailure instanceof ApiError && loginFailure.status === 401) {
        setLoginError("Invalid username or password.");
        return;
      }
      setLoginError(
        loginFailure instanceof Error ? loginFailure.message : "Failed to sign in.",
      );
    } finally {
      setLoginBusy(false);
    }
  }

  async function handleLogout() {
    try {
      await logoutSession();
    } finally {
      setSession(null);
      setLoginError(null);
    }
  }

  if (!authResolved) {
    return (
      <LoadingShell
        theme={theme}
        onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
    );
  }

  if (!session) {
    return (
      <LoginShell
        theme={theme}
        loginBusy={loginBusy}
        error={loginError}
        onSubmit={handleLogin}
        onToggleTheme={() => setTheme(theme === "dark" ? "light" : "dark")}
      />
    );
  }

  const viewer = config?.auth.viewer ?? session.viewer;
  const traceAccess = config?.auth.trace_access ?? session.trace_access;
  const contentTraceEnabled = config?.control_plane.content_trace_enabled ?? session.content_trace_enabled;

  return (
    <div className="shell">
      <motion.aside
        className="rail"
        initial={{ opacity: 0, x: -24 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, ease: [0.2, 1, 0.3, 1] }}
      >
        <div className="brand-block">
          <span className="eyebrow">control plane</span>
          <h1>stronk-mask</h1>
          <p>Inspect live masking and rehydration content from authenticated operator sessions.</p>
        </div>

        <div className="rail-section">
          <span className="section-label">Content session</span>
          <div className="identity-line">
            <strong>{viewer.user}</strong>
            <span>{viewer.roles.join(" · ")}</span>
          </div>
          <p className="microcopy">
            {traceAccess
              ? "Authenticated content session active. Recent traces stay inside stronk-mask and expire on local retention limits."
              : "Authenticated session active. Raw content trace access is not available to this role."}
          </p>
        </div>

        <div className="rail-section">
          <span className="section-label">Selected KPIs</span>
          <div className="rail-metric">
            <span>Total requests</span>
            <strong>{overview?.total_requests ?? "0"}</strong>
          </div>
          <div className="rail-metric">
            <span>Masked requests</span>
            <strong>{overview?.masked_requests ?? "0"}</strong>
          </div>
          <div className="rail-metric">
            <span>Blocked requests</span>
            <strong>{overview?.blocked_requests ?? "0"}</strong>
          </div>
        </div>

        <div className="rail-section rail-actions">
          <button
            className="theme-button"
            type="button"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            Switch to {theme === "dark" ? "light" : "dark"} mode
          </button>
          <button className="ghost-button" type="button" onClick={() => void handleLogout()}>
            Sign out
          </button>
        </div>
      </motion.aside>

      <main className="workspace">
        <motion.section
          className="signal-strip"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.05, ease: [0.2, 1, 0.3, 1] }}
        >
          <div>
            <span className="section-label">Traffic posture</span>
            <h2>Privacy activity</h2>
          </div>
          <div className="signal-grid">
            <Metric value={overview?.rehydrated_responses ?? 0} label="Rehydrated returns" tone="accent" />
            <Metric value={overview?.route_local_requests ?? 0} label="route_local hits" tone="warning" />
            <Metric value={overview?.error_requests ?? 0} label="Error responses" tone="danger" />
            <Metric
              value={overview?.last_event_at ? formatRelativeTime(overview.last_event_at) : "No traffic"}
              label="Last event"
              tone="neutral"
            />
          </div>
        </motion.section>

        {error ? <div className="error-banner">{error}</div> : null}

        <LayoutGroup>
          <div className="workspace-grid">
            <motion.section
              className="river"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1, ease: [0.2, 1, 0.3, 1] }}
            >
              <div className="section-header">
                <div>
                  <span className="section-label">Event river</span>
                  <h3>Recent requests</h3>
                </div>
                <span className="microcopy">{events.length} visible</span>
              </div>

              <div className="river-list">
                {events.length === 0 ? (
                  <div className="empty-state">
                    <h4>No recent traffic yet</h4>
                    <p>Send requests through the proxy, then the river will populate with traceable masking outcomes.</p>
                  </div>
                ) : (
                  events.map((event) => {
                    const active = event.request_id === selectedId;
                    return (
                      <motion.button
                        layout
                        key={event.request_id}
                        type="button"
                        className={`river-row${active ? " is-active" : ""}`}
                        onClick={() => setSelectedId(event.request_id)}
                        whileHover={{ x: 4 }}
                        transition={{ type: "spring", stiffness: 320, damping: 28 }}
                      >
                        <div className="river-row-meta">
                          <span className={`pill tone-${toneForOutcome(event.outcome)}`}>{event.outcome}</span>
                          <span>{event.provider}</span>
                          <span>{event.stream ? "stream" : "json"}</span>
                        </div>
                        <div className="river-row-main">
                          <strong>{event.model ?? "model pending"}</strong>
                          <span>{event.endpoint}</span>
                        </div>
                        <div className="river-row-stats">
                          <span>{event.detection_count} detections</span>
                          <span>{event.latency_ms} ms</span>
                        </div>
                      </motion.button>
                    );
                  })
                )}
              </div>
            </motion.section>

            <AnimatePresence mode="wait">
              <motion.section
                key={selectedEvent?.request_id ?? "empty"}
                className="inspector"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -16 }}
                transition={{ duration: 0.45, ease: [0.2, 1, 0.3, 1] }}
              >
                <div className="section-header">
                  <div>
                    <span className="section-label">Request inspector</span>
                    <h3>{selectedEvent ? selectedEvent.request_id : "Choose an event"}</h3>
                  </div>
                  <span className="microcopy">
                    {selectedEvent ? formatTimestamp(selectedEvent.created_at) : "No selection"}
                  </span>
                </div>

                {selectedEvent ? (
                  <div className="inspector-content">
                    <div className="flow-line">
                      <span>incoming</span>
                      <span>masked upstream</span>
                      <span>provider reply</span>
                      <span>rehydrated return</span>
                    </div>

                    {contentTraceEnabled && traceAccess ? (
                      <div className="unsafe-debug-panel">
                        {selectedDebugTrace ? (
                          <DebugDiffDeck trace={selectedDebugTrace} event={selectedEvent} />
                        ) : (
                          <p className="microcopy">
                            Content trace not available for this request. It may have expired under the local retention window.
                          </p>
                        )}
                      </div>
                    ) : (
                      <div className="empty-state compact-empty">
                        <h4>Content trace unavailable</h4>
                        <p>
                          {traceAccess
                            ? "Content trace capture is disabled in the current control-plane configuration."
                            : "Your current role can inspect sanitized summaries, but not raw content traces."}
                        </p>
                      </div>
                    )}

                    <div className="inspector-metrics">
                      <Metric value={selectedEvent.status_code} label="Status" tone="neutral" />
                      <Metric value={selectedEvent.placeholder_count} label="Placeholders" tone="accent" />
                      <Metric value={selectedEvent.rehydration_count} label="Rehydration count" tone="accent" />
                      <Metric value={selectedEvent.masked_paths.length} label="Touched paths" tone="warning" />
                    </div>

                    <DataLine title="Detector mix" rows={buildKeyValueRows(selectedEvent.detection_types)} />
                    <DataLine title="Action mix" rows={buildKeyValueRows(selectedEvent.actions)} />
                    <DataLine title="Touched paths" rows={selectedEvent.masked_paths.map((path) => [path, ""])} mono />
                  </div>
                ) : (
                  <div className="empty-state">
                    <h4>Inspector waiting</h4>
                    <p>Select a request from the river to inspect its masking and rehydration trace.</p>
                  </div>
                )}
              </motion.section>
            </AnimatePresence>

            <motion.section
              className="readiness"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, delay: 0.14, ease: [0.2, 1, 0.3, 1] }}
            >
              <div className="section-header">
                <div>
                  <span className="section-label">Setup posture</span>
                  <h3>Control plane state</h3>
                </div>
                <span className="microcopy">{config?.app_env ?? "loading"}</span>
              </div>

              <DataLine title="Provider split" rows={providerBreakdown} />
              <DataLine title="Top detectors" rows={detectorBreakdown} />
              <DataLine title="Policy actions" rows={actionBreakdown} />

              <div className="readiness-block">
                <span className="section-label">Warnings</span>
                {config?.warnings.length ? (
                  <ul className="warning-list">
                    {config.warnings.map((warning) => (
                      <li key={warning}>{warning}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="microcopy">No active configuration warnings in the current snapshot.</p>
                )}
              </div>

              <div className="readiness-block">
                <span className="section-label">Recent admin access</span>
                <div className="access-list">
                  {config?.recent_access.length ? (
                    config.recent_access.map((entry) => (
                      <div key={`${entry.created_at}-${entry.path}`} className="access-row">
                        <strong>{entry.actor}</strong>
                        <span>{entry.method}</span>
                        <span>{entry.path}</span>
                      </div>
                    ))
                  ) : (
                    <p className="microcopy">Access logs will appear here after authenticated control-plane activity.</p>
                  )}
                </div>
              </div>
            </motion.section>
          </div>
        </LayoutGroup>
      </main>
    </div>
  );
}

function LoadingShell({
  theme,
  onToggleTheme,
}: {
  theme: ThemeMode;
  onToggleTheme: () => void;
}) {
  return (
    <div className="auth-shell">
      <div className="auth-card">
        <span className="eyebrow">control plane</span>
        <h1>stronk-mask</h1>
        <p className="auth-copy">Resolving your admin session and content-trace posture.</p>
        <button className="theme-button" type="button" onClick={onToggleTheme}>
          Switch to {theme === "dark" ? "light" : "dark"} mode
        </button>
      </div>
    </div>
  );
}

function LoginShell({
  theme,
  loginBusy,
  error,
  onSubmit,
  onToggleTheme,
}: {
  theme: ThemeMode;
  loginBusy: boolean;
  error: string | null;
  onSubmit: (username: string, password: string) => Promise<void>;
  onToggleTheme: () => void;
}) {
  const [username, setUsername] = useState("operator");
  const [password, setPassword] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await onSubmit(username, password);
  }

  return (
    <div className="auth-shell">
      <motion.form
        className="auth-card"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.2, 1, 0.3, 1] }}
        onSubmit={(event) => void handleSubmit(event)}
      >
        <span className="eyebrow">control plane</span>
        <h1>stronk-mask</h1>
        <p className="auth-copy">
          Sign in to inspect live masking and rehydration traces. Sensitive content remains inside authenticated admin sessions and recent traces expire on local retention limits.
        </p>

        <label className="auth-field">
          <span className="section-label">Username</span>
          <input value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" />
        </label>

        <label className="auth-field">
          <span className="section-label">Password</span>
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete="current-password"
          />
        </label>

        {error ? <div className="error-banner">{error}</div> : null}

        <div className="auth-actions">
          <button className="theme-button" type="submit" disabled={loginBusy}>
            {loginBusy ? "Signing in..." : "Open content session"}
          </button>
          <button className="ghost-button" type="button" onClick={onToggleTheme}>
            Switch to {theme === "dark" ? "light" : "dark"} mode
          </button>
        </div>
      </motion.form>
    </div>
  );
}

function Metric({
  value,
  label,
  tone,
}: {
  value: number | string;
  label: string;
  tone: "accent" | "warning" | "danger" | "neutral";
}) {
  return (
    <div className={`metric metric-${tone}`}>
      <strong>{value}</strong>
      <span>{label}</span>
    </div>
  );
}

function DataLine({
  title,
  rows,
  mono = false,
}: {
  title: string;
  rows: Array<[string, string | number]>;
  mono?: boolean;
}) {
  return (
    <div className="data-line">
      <span className="section-label">{title}</span>
      <div className="data-line-list">
        {rows.length ? (
          rows.map(([name, value]) => (
            <div key={`${title}-${name}`} className={`data-row${mono ? " is-mono" : ""}`}>
              <span>{name}</span>
              <strong>{value}</strong>
            </div>
          ))
        ) : (
          <p className="microcopy">No data in the current snapshot.</p>
        )}
      </div>
    </div>
  );
}

function buildKeyValueRows(values: Record<string, number>): Array<[string, number]> {
  return Object.entries(values).sort((left, right) => right[1] - left[1]);
}

function toneForOutcome(outcome: string): "accent" | "warning" | "danger" | "neutral" {
  if (outcome === "masked") {
    return "accent";
  }
  if (outcome === "blocked" || outcome === "upstream_error") {
    return "danger";
  }
  if (outcome === "route_local" || outcome === "proxy_error" || outcome === "upstream_rejection") {
    return "warning";
  }
  return "neutral";
}

function formatRelativeTime(value: string): string {
  const timestamp = new Date(value).getTime();
  const deltaSeconds = Math.max(Math.round((Date.now() - timestamp) / 1000), 0);
  if (deltaSeconds < 60) {
    return `${deltaSeconds}s ago`;
  }
  if (deltaSeconds < 3600) {
    return `${Math.floor(deltaSeconds / 60)}m ago`;
  }
  return `${Math.floor(deltaSeconds / 3600)}h ago`;
}

function formatTimestamp(value: string): string {
  return new Date(value).toLocaleString();
}
