export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

export type AuditEvent = {
  request_id: string;
  created_at: string;
  provider: string;
  endpoint: string;
  model: string | null;
  stream: boolean;
  outcome: string;
  status_code: number;
  latency_ms: number;
  detection_count: number;
  detection_types: Record<string, number>;
  actions: Record<string, number>;
  placeholder_count: number;
  rehydration_count: number;
  masked_paths: string[];
  blocked: boolean;
  route_local: boolean;
};

export type Overview = {
  total_requests: number;
  masked_requests: number;
  blocked_requests: number;
  route_local_requests: number;
  rehydrated_responses: number;
  error_requests: number;
  provider_counts: Record<string, number>;
  detector_counts: Record<string, number>;
  action_counts: Record<string, number>;
  last_event_at: string | null;
};

export type ConfigSummary = {
  app_name: string;
  app_env: string;
  proxy_surfaces: string[];
  control_plane: {
    admin_api_enabled: boolean;
    admin_ui_enabled: boolean;
    audit_storage_enabled: boolean;
    ui_built: boolean;
    content_trace_enabled: boolean;
    content_trace_ttl_seconds: number;
  };
  upstreams: {
    openai_host: string;
    anthropic_host: string;
    allow_insecure_upstreams: boolean;
    allow_nonstandard_upstream_hosts: boolean;
  };
  policy_actions: Record<string, string>;
  auth: {
    auth_mode: string;
    allowed_roles: string[];
    trace_allowed_roles: string[];
    session_cookie_name: string;
    viewer: {
      user: string;
      roles: string[];
    };
    trace_access: boolean;
  };
  warnings: string[];
  recent_access: Array<{
    created_at: string;
    actor: string;
    roles: string[];
    path: string;
    method: string;
    status_code: number;
    source_ip: string | null;
  }>;
};

export type DebugTraceSummary = {
  request_id: string;
  created_at: string;
  provider: string;
  endpoint: string;
  model: string | null;
  stream: boolean;
  outcome: string;
  status_code: number;
};

export type DebugTrace = DebugTraceSummary & {
  request_original: JsonValue;
  request_masked: JsonValue;
  response_upstream: JsonValue;
  response_rehydrated: JsonValue;
};

export type SessionSummary = {
  viewer: {
    user: string;
    roles: string[];
  };
  auth_mode: string;
  trace_access: boolean;
  trace_allowed_roles: string[];
  content_trace_enabled: boolean;
};
