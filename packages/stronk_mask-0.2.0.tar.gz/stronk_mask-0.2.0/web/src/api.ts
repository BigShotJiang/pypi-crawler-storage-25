import type { AuditEvent, ConfigSummary, DebugTrace, Overview, SessionSummary } from "./types";

export class ApiError extends Error {
  status: number;

  constructor(path: string, status: number, message?: string) {
    super(message ?? `Request failed for ${path}: ${status}`);
    this.name = "ApiError";
    this.status = status;
  }
}

async function requestJson<T>(
  path: string,
  options: {
    method?: string;
    payload?: Record<string, unknown>;
    allowUnauthorized?: boolean;
  } = {},
): Promise<T | null> {
  const response = await fetch(path, {
    method: options.method ?? "GET",
    cache: "no-store",
    credentials: "include",
    headers: {
      Accept: "application/json",
      ...(options.payload ? { "Content-Type": "application/json" } : {}),
    },
    body: options.payload ? JSON.stringify(options.payload) : undefined,
  });
  if (options.allowUnauthorized && response.status === 401) {
    return null;
  }
  if (!response.ok) {
    throw new ApiError(path, response.status);
  }
  if (response.status === 204) {
    return null;
  }
  return (await response.json()) as T;
}

export async function fetchSession(): Promise<SessionSummary | null> {
  return requestJson<SessionSummary>("/api/session", { allowUnauthorized: true });
}

export async function loginSession(username: string, password: string): Promise<SessionSummary> {
  const payload = await requestJson<SessionSummary>("/api/session/login", {
    method: "POST",
    payload: { username, password },
  });
  if (payload === null) {
    throw new ApiError("/api/session/login", 500, "Login unexpectedly returned no payload.");
  }
  return payload;
}

export async function logoutSession(): Promise<void> {
  await requestJson<null>("/api/session/logout", { method: "POST" });
}

export async function fetchOverview(): Promise<Overview> {
  const payload = await requestJson<Overview>("/api/overview");
  if (payload === null) {
    throw new ApiError("/api/overview", 500, "Overview unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchEvents(): Promise<{ items: AuditEvent[] }> {
  const payload = await requestJson<{ items: AuditEvent[] }>("/api/events?limit=40");
  if (payload === null) {
    throw new ApiError("/api/events", 500, "Events unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchEvent(requestId: string): Promise<AuditEvent> {
  const payload = await requestJson<AuditEvent>(`/api/events/${requestId}`);
  if (payload === null) {
    throw new ApiError(`/api/events/${requestId}`, 500, "Event unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchConfig(): Promise<ConfigSummary> {
  const payload = await requestJson<ConfigSummary>("/api/config");
  if (payload === null) {
    throw new ApiError("/api/config", 500, "Config unexpectedly returned no payload.");
  }
  return payload;
}

export async function fetchDebugTrace(requestId: string): Promise<DebugTrace | null> {
  const response = await fetch(`/api/debug/traces/${requestId}`, {
    cache: "no-store",
    credentials: "include",
    headers: {
      Accept: "application/json",
    },
  });
  if (response.status === 404) {
    return null;
  }
  if (!response.ok) {
    throw new ApiError(`/api/debug/traces/${requestId}`, response.status);
  }
  return (await response.json()) as DebugTrace;
}
