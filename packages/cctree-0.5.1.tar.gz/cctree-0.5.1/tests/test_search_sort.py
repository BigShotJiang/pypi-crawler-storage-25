"""Tests for clickable column header sorting in search results."""
from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path
from typing import NamedTuple

import pytest


# ─── Unit tests for _x_to_column ─────────────────────────────────────────────


class TestXToColumn:
    """Map x-coordinate to sortable column name."""

    def test_type_start(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(0) == "type"

    def test_type_end(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(6) == "type"

    def test_separator_after_type(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(7) is None
        assert _x_to_column(8) is None

    def test_name_start(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(9) == "name"

    def test_name_end(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(20) == "name"

    def test_started(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(23) == "started"
        assert _x_to_column(31) == "started"

    def test_active(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(34) == "active"
        assert _x_to_column(42) == "active"

    def test_msgs(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(45) == "msgs"
        assert _x_to_column(48) == "msgs"

    def test_size(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(51) == "size"
        assert _x_to_column(55) == "size"

    def test_context_not_sortable(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(58) is None
        assert _x_to_column(100) is None

    def test_separator_between_name_and_started(self):
        from cctree.tui.modals import _x_to_column

        assert _x_to_column(21) is None
        assert _x_to_column(22) is None


# ─── Unit tests for _build_header with sort indicators ───────────────────────


class TestBuildHeaderSort:
    """Header rendering with sort column indicators."""

    def test_no_sort_no_indicators(self):
        from cctree.tui.modals import _build_header

        header = _build_header()
        assert "\u25b2" not in header
        assert "\u25bc" not in header

    def test_type_descending(self):
        from cctree.tui.modals import _build_header

        header = _build_header(sort_column="type", sort_ascending=False)
        assert "TYPE\u25bc" in header
        assert "\u25b2" not in header

    def test_type_ascending(self):
        from cctree.tui.modals import _build_header

        header = _build_header(sort_column="type", sort_ascending=True)
        assert "TYPE\u25b2" in header
        assert "\u25bc" not in header

    def test_msgs_descending(self):
        from cctree.tui.modals import _build_header

        header = _build_header(sort_column="msgs", sort_ascending=False)
        assert "MSGS\u25bc" in header or "\u25bcMSGS" in header

    def test_started_ascending(self):
        from cctree.tui.modals import _build_header

        header = _build_header(sort_column="started", sort_ascending=True)
        assert "\u25b2" in header

    def test_only_active_column_has_indicator(self):
        from cctree.tui.modals import _build_header
        from rich.text import Text

        header = _build_header(sort_column="name", sort_ascending=False)
        plain = Text.from_markup(header).plain
        assert plain.count("\u25bc") == 1
        assert plain.count("\u25b2") == 0

    def test_still_bold(self):
        from cctree.tui.modals import _build_header

        header = _build_header(sort_column="type", sort_ascending=False)
        assert header.startswith("[bold]")
        assert header.endswith("[/bold]")

    def test_all_column_names_present(self):
        from cctree.tui.modals import _build_header
        from rich.text import Text

        header = _build_header(sort_column="size", sort_ascending=True)
        plain = Text.from_markup(header).plain
        for col in ["TYPE", "NAME", "STARTED", "ACTIVE", "MSGS", "SIZE", "CONTEXT"]:
            assert col in plain


# ─── Unit tests for _sort_key ────────────────────────────────────────────────


class TestSortKey:
    """Sort key extraction from SearchMatch objects."""

    @pytest.fixture
    def make_match(self):
        from cctree.tui.modals import SearchMatch

        def _make(
            type_str="slug",
            display_name="test",
            started_at=None,
            last_activity_at=None,
            message_count=0,
            file_size=0,
        ):
            return SearchMatch(
                type_str=type_str,
                display_name=display_name,
                started_at=started_at,
                last_activity_at=last_activity_at,
                message_count=message_count,
                file_size=file_size,
                context_markup="ctx",
                session_uuid="u1",
                msg_uuid="",
            )

        return _make

    def test_sort_by_type(self, make_match):
        from cctree.tui.modals import _sort_key

        m1 = make_match(type_str="content")
        m2 = make_match(type_str="uuid")
        assert _sort_key(m1, "type") < _sort_key(m2, "type")

    def test_sort_by_name_case_insensitive(self, make_match):
        from cctree.tui.modals import _sort_key

        m1 = make_match(display_name="Alpha")
        m2 = make_match(display_name="beta")
        assert _sort_key(m1, "name") < _sort_key(m2, "name")

    def test_sort_by_started(self, make_match):
        from cctree.tui.modals import _sort_key

        m1 = make_match(started_at=datetime(2026, 1, 1))
        m2 = make_match(started_at=datetime(2026, 6, 1))
        assert _sort_key(m1, "started") < _sort_key(m2, "started")

    def test_sort_by_started_none_sorts_last(self, make_match):
        from cctree.tui.modals import _sort_key

        m_none = make_match(started_at=None)
        m_date = make_match(started_at=datetime(2026, 1, 1))
        # None should sort after any real date
        assert _sort_key(m_date, "started") < _sort_key(m_none, "started")

    def test_sort_by_active_none_sorts_last(self, make_match):
        from cctree.tui.modals import _sort_key

        m_none = make_match(last_activity_at=None)
        m_date = make_match(last_activity_at=datetime(2026, 1, 1))
        assert _sort_key(m_date, "active") < _sort_key(m_none, "active")

    def test_sort_by_msgs(self, make_match):
        from cctree.tui.modals import _sort_key

        m1 = make_match(message_count=5)
        m2 = make_match(message_count=20)
        assert _sort_key(m1, "msgs") < _sort_key(m2, "msgs")

    def test_sort_by_size(self, make_match):
        from cctree.tui.modals import _sort_key

        m1 = make_match(file_size=100)
        m2 = make_match(file_size=5000)
        assert _sort_key(m1, "size") < _sort_key(m2, "size")

    def test_sort_by_size_negative_sorts_last(self, make_match):
        from cctree.tui.modals import _sort_key

        m_err = make_match(file_size=-1)
        m_ok = make_match(file_size=100)
        assert _sort_key(m_ok, "size") < _sort_key(m_err, "size")


# ─── Unit tests for _format_match_label ──────────────────────────────────────


class TestFormatMatchLabel:
    """Label formatting from SearchMatch."""

    def test_produces_columnar_output(self):
        from cctree.tui.modals import SearchMatch, _format_match_label
        from rich.text import Text

        match = SearchMatch(
            type_str="slug",
            display_name="my-session",
            started_at=datetime(2026, 4, 1, 14, 0),
            last_activity_at=datetime(2026, 4, 1, 15, 0),
            message_count=5,
            file_size=2048,
            context_markup="my-session",
            session_uuid="u1",
            msg_uuid="",
        )
        label = _format_match_label(match)
        plain = Text.from_markup(label).plain
        assert plain.startswith("slug")
        assert "my-session" in plain
        assert "04/01 14h" in plain
        assert "   5" in plain

    def test_truncates_long_names(self):
        from cctree.tui.modals import SearchMatch, _format_match_label, _COL_NAME
        from rich.text import Text

        match = SearchMatch(
            type_str="slug",
            display_name="very-long-session-name-here",
            started_at=None,
            last_activity_at=None,
            message_count=0,
            file_size=0,
            context_markup="ctx",
            session_uuid="u1",
            msg_uuid="",
        )
        label = _format_match_label(match)
        plain = Text.from_markup(label).plain
        # Name column should be truncated
        assert "\u2026" in plain


# ─── Unit tests for _format_file_size_from_bytes ─────────────────────────────


class TestFormatFileSizeFromBytes:
    """File size formatting from raw byte count."""

    def test_bytes(self):
        from cctree.tui.modals import _format_file_size_from_bytes

        assert _format_file_size_from_bytes(500) == "500B"

    def test_kilobytes(self):
        from cctree.tui.modals import _format_file_size_from_bytes

        assert _format_file_size_from_bytes(5120) == "5K"

    def test_megabytes(self):
        from cctree.tui.modals import _format_file_size_from_bytes

        assert _format_file_size_from_bytes(2 * 1024 * 1024) == "2.0M"

    def test_negative_returns_dash(self):
        from cctree.tui.modals import _format_file_size_from_bytes

        assert _format_file_size_from_bytes(-1) == "-"


# ─── Tests for three-state sort cycle logic ──────────────────────────────────


class TestSortCycleLogic:
    """Three-state cycle: descending → ascending → unsorted."""

    def _apply_click(self, sort_column, sort_ascending, clicked_col):
        """Simulate one header click and return (new_column, new_ascending)."""
        if clicked_col == sort_column:
            if sort_ascending:
                return (None, False)
            else:
                return (clicked_col, True)
        else:
            return (clicked_col, False)

    def test_first_click_sets_descending(self):
        col, asc = self._apply_click(None, False, "name")
        assert col == "name"
        assert asc is False

    def test_second_click_toggles_ascending(self):
        col, asc = self._apply_click("name", False, "name")
        assert col == "name"
        assert asc is True

    def test_third_click_clears_sort(self):
        col, asc = self._apply_click("name", True, "name")
        assert col is None

    def test_different_column_resets_descending(self):
        col, asc = self._apply_click("name", True, "size")
        assert col == "size"
        assert asc is False


# ─── Tests for S key column cycling ──────────────────────────────────────────


class TestSKeyCycle:
    """S key cycles: unsorted → type → name → ... → size → unsorted."""

    _SORTABLE = ["type", "name", "started", "active", "msgs", "size"]

    def _apply_s_key(self, sort_column):
        """Simulate one S key press and return new sort column."""
        if sort_column is None:
            return self._SORTABLE[0]
        idx = self._SORTABLE.index(sort_column)
        if idx + 1 < len(self._SORTABLE):
            return self._SORTABLE[idx + 1]
        return None

    def test_unsorted_to_type(self):
        assert self._apply_s_key(None) == "type"

    def test_type_to_name(self):
        assert self._apply_s_key("type") == "name"

    def test_name_to_started(self):
        assert self._apply_s_key("name") == "started"

    def test_started_to_active(self):
        assert self._apply_s_key("started") == "active"

    def test_active_to_msgs(self):
        assert self._apply_s_key("active") == "msgs"

    def test_msgs_to_size(self):
        assert self._apply_s_key("msgs") == "size"

    def test_size_to_unsorted(self):
        assert self._apply_s_key("size") is None

    def test_full_cycle(self):
        col = None
        for expected in self._SORTABLE:
            col = self._apply_s_key(col)
            assert col == expected
        col = self._apply_s_key(col)
        assert col is None


# ─── Integration: sorting with real store ────────────────────────────────────


class TestSortIntegration:
    """Sorting search matches with real SessionStore data."""

    @pytest.fixture
    def store_with_sessions(self, tmp_path):
        """Create a store with multiple sessions for sort testing."""
        from cctree.core.store import SessionStore

        sessions_data = [
            {
                "id": "aaaa0000-0000-0000-0000-000000000000",
                "slug": "alpha-project",
                "timestamp_start": "2026-01-10T10:00:00Z",
                "timestamp_active": "2026-04-01T14:00:00Z",
                "msg_count": 20,
                "content": "tell me about alpha deployment",
            },
            {
                "id": "aaaa1111-0000-0000-0000-000000000000",
                "slug": "alpha-runner",
                "timestamp_start": "2026-03-05T08:00:00Z",
                "timestamp_active": "2026-03-20T10:00:00Z",
                "msg_count": 3,
                "content": "run alpha tests please",
            },
            {
                "id": "aaaa2222-0000-0000-0000-000000000000",
                "slug": "alpha-builder",
                "timestamp_start": "2026-02-15T12:00:00Z",
                "timestamp_active": "2026-04-10T09:00:00Z",
                "msg_count": 50,
                "content": "build alpha pipeline",
            },
        ]
        for s in sessions_data:
            lines = [
                json.dumps({
                    "type": "user", "uuid": f"u-{s['id'][:4]}", "parentUuid": None,
                    "message": {"role": "user", "content": s["content"]},
                    "sessionId": s["id"], "slug": s["slug"],
                    "timestamp": s["timestamp_start"],
                }),
                json.dumps({
                    "type": "assistant", "uuid": f"a-{s['id'][:4]}", "parentUuid": f"u-{s['id'][:4]}",
                    "message": {"role": "assistant", "content": [
                        {"type": "text", "text": f"Response about {s['slug']}"}
                    ]},
                    "sessionId": s["id"], "slug": s["slug"],
                    "timestamp": s["timestamp_active"],
                }),
            ]
            # Add extra messages to match msg_count (pairs of user+assistant)
            for i in range(1, s["msg_count"] // 2):
                lines.append(json.dumps({
                    "type": "user", "uuid": f"u{i}-{s['id'][:4]}", "parentUuid": f"a-{s['id'][:4]}",
                    "message": {"role": "user", "content": f"follow-up {i}"},
                    "sessionId": s["id"], "slug": s["slug"],
                    "timestamp": s["timestamp_active"],
                }))
                lines.append(json.dumps({
                    "type": "assistant", "uuid": f"a{i}-{s['id'][:4]}",
                    "parentUuid": f"u{i}-{s['id'][:4]}",
                    "message": {"role": "assistant", "content": [
                        {"type": "text", "text": f"reply {i}"}
                    ]},
                    "sessionId": s["id"], "slug": s["slug"],
                    "timestamp": s["timestamp_active"],
                }))
            f = tmp_path / f"{s['id']}.jsonl"
            f.write_text("\n".join(lines) + "\n")
            # Set different file sizes
            if s["slug"] == "alpha-project":
                f.write_text(f.read_text() + "x" * 500)
            elif s["slug"] == "alpha-builder":
                f.write_text(f.read_text() + "x" * 5000)

        store = SessionStore(project_dir=tmp_path)
        _ = store.sessions
        return store

    def test_build_matches_returns_search_match(self, store_with_sessions):
        from cctree.tui.modals import SearchScreen, SearchMatch

        screen = SearchScreen(store_with_sessions)
        matches = screen._collect_matches("alpha")
        assert len(matches) >= 2
        assert all(isinstance(m, SearchMatch) for m in matches)

    def test_sort_by_msgs_descending(self, store_with_sessions):
        from cctree.tui.modals import SearchScreen, _sort_key

        screen = SearchScreen(store_with_sessions)
        matches = screen._collect_matches("alpha")
        sorted_matches = sorted(matches, key=lambda m: _sort_key(m, "msgs"), reverse=True)
        counts = [m.message_count for m in sorted_matches]
        assert counts == sorted(counts, reverse=True)

    def test_sort_by_name_ascending(self, store_with_sessions):
        from cctree.tui.modals import SearchScreen, _sort_key

        screen = SearchScreen(store_with_sessions)
        matches = screen._collect_matches("alpha")
        sorted_matches = sorted(matches, key=lambda m: _sort_key(m, "name"))
        names = [m.display_name.lower() for m in sorted_matches]
        assert names == sorted(names)

    def test_sort_by_started_ascending(self, store_with_sessions):
        from cctree.tui.modals import SearchScreen, _sort_key

        screen = SearchScreen(store_with_sessions)
        matches = screen._collect_matches("alpha")
        sorted_matches = sorted(matches, key=lambda m: _sort_key(m, "started"))
        dates = [m.started_at for m in sorted_matches]
        # All have dates, so should be in chronological order
        for i in range(len(dates) - 1):
            assert dates[i] <= dates[i + 1]

    def test_unsort_restores_original_order(self, store_with_sessions):
        from cctree.tui.modals import SearchScreen, _sort_key

        screen = SearchScreen(store_with_sessions)
        matches = screen._collect_matches("alpha")
        original_uuids = [m.session_uuid for m in matches]

        sorted_matches = sorted(matches, key=lambda m: _sort_key(m, "msgs"), reverse=True)
        sorted_uuids = [m.session_uuid for m in sorted_matches]

        # Original order may differ from sorted
        # Restoring from original list should give back original order
        assert original_uuids == [m.session_uuid for m in matches]


# ─── Default sort by activity & uppercase S binding ──────────────────────────


class TestDefaultSortByActivity:
    """Search results default to activity descending."""

    def test_initial_sort_column_is_active(self):
        from unittest.mock import MagicMock

        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(MagicMock())
        assert screen._sort_column == "active"

    def test_initial_sort_ascending_is_false(self):
        from unittest.mock import MagicMock

        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(MagicMock())
        assert screen._sort_ascending is False

    def test_uppercase_s_in_bindings(self):
        from cctree.tui.modals import SearchScreen

        keys = [(b.key, b.action) for b in SearchScreen.BINDINGS]
        assert ("S", "cycle_sort") in keys
