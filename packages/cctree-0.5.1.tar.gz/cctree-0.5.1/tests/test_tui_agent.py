"""TUI tests for agent node rendering in the session tree.

Covers:
  - Agent nodes show feedback when no progress-event link exists
  - Agent tool_result content is displayed (Bug 2 — future task)
  - Empty subagent transcripts show feedback (Bug 3 — future task)
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest

from cctree.core.model import Session, SessionEvent


def _walk_labels(node) -> list[str]:
    """Flatten the tree into a list of stringified labels."""
    out: list[str] = []
    out.append(str(node.label))
    for child in node.children:
        out.extend(_walk_labels(child))
    return out


def _write_session(path: Path, events: list[dict]) -> None:
    with open(path, "w") as f:
        for evt in events:
            f.write(json.dumps(evt) + "\n")
    old_time = time.time() - 300
    os.utime(path, (old_time, old_time))


class TestAgentNoLinkFeedback:
    """Bug 1: When agent_links has no mapping for a tool_use_id,
    the agent node must show a feedback leaf instead of being empty.

    Root cause: find_agent_links() returns {} when no progress events
    exist with matching parentToolUseID. The flat and wrapped rendering
    paths both have an `if agent_id:` branch with no `else`, leaving
    the agent node expandable but with zero children.
    """

    @pytest.fixture
    def agent_no_link_project(self, tmp_path):
        """Session with Agent tool_use but NO progress events.

        Because there are no progress events, find_agent_links() returns {},
        and agent_links.get(block.id) returns None for the Agent tool_use.
        """
        session_id = "sess-agent-nolink-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"

        events = [
            {"type": "user", "uuid": "u1", "parentUuid": None,
             "sessionId": session_id, "slug": "agent-nolink-test",
             "timestamp": "2026-04-01T10:00:00Z", "version": "2.1.77",
             "message": {"role": "user", "content": "research this topic"}},
            # Assistant with Agent tool_use — no matching progress events exist
            {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:05Z",
             "message": {"role": "assistant", "content": [
                 {"type": "text", "text": "I'll research this."},
                 {"type": "tool_use", "id": "toolu_agent001", "name": "Agent",
                  "input": {"description": "Research the topic",
                            "subagent_type": "Explore"}},
             ]}},
            # Final assistant text (no progress events in between)
            {"type": "assistant", "uuid": "a2", "parentUuid": "a1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:15Z",
             "message": {"role": "assistant",
                         "content": "Here are the findings."}},
        ]
        _write_session(sess_path, events)
        return tmp_path, session_id

    @pytest.mark.asyncio
    async def test_flat_path_shows_feedback_when_no_agent_link(
        self, agent_no_link_project,
    ):
        """Flat rendering (main session view): agent node with no progress-event
        link must contain a feedback leaf, not be empty."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_no_link_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)

            # The agent node label should be present
            assert "Research the topic" in joined, (
                f"Agent label not found in tree. Labels:\n{joined}"
            )
            # The feedback leaf should exist as a child of the agent node
            assert "no agent link" in joined.lower(), (
                f"Expected feedback leaf with 'no agent link' text "
                f"but not found. Labels:\n{joined}"
            )

    @pytest.mark.asyncio
    async def test_wrapped_path_shows_feedback_when_no_agent_link(
        self, agent_no_link_project,
    ):
        """Wrapped rendering (_add_assistant_node): agent node with empty
        agent_links and a non-None session must show feedback."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_no_link_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            tree = app.query_one("#session-tree", Tree)

            # Build a minimal Session so the `if session is not None` branch fires
            fake_session = Session(
                uuid="test-wrapped", project_slug="test",
                path=str(tmp_path / "nonexistent.jsonl"),
                events=[],
            )

            # Build an assistant event with an Agent tool_use
            evt = SessionEvent.model_validate({
                "type": "assistant", "uuid": "wa1",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_wrapped001",
                     "name": "Agent",
                     "input": {"description": "Wrapped path test",
                               "subagent_type": "Explore"}},
                ]},
            })

            # Call _add_assistant_node directly with empty agent_links
            app._add_assistant_node(
                tree.root, evt, agent_links={}, session=fake_session,
            )
            await pilot.pause()

            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)

            assert "Wrapped path test" in joined, (
                f"Agent label not found. Labels:\n{joined}"
            )
            assert "no agent link" in joined.lower(), (
                f"Expected feedback leaf with 'no agent link' text "
                f"but not found. Labels:\n{joined}"
            )


class TestAgentInputDisplay:
    """Agent input (including prompt) should be rendered as wrapped JSON
    content under the agent node, consistent with how standard tools
    show their input."""

    @pytest.fixture
    def agent_with_prompt_project(self, tmp_path):
        session_id = "sess-agent-input-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"

        events = [
            {"type": "user", "uuid": "u1", "parentUuid": None,
             "sessionId": session_id, "slug": "agent-input-test",
             "timestamp": "2026-04-01T10:00:00Z", "version": "2.1.77",
             "message": {"role": "user", "content": "investigate"}},
            {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:05Z",
             "message": {"role": "assistant", "content": [
                 {"type": "tool_use", "id": "toolu_inp001", "name": "Agent",
                  "input": {"description": "Investigate the bug",
                            "prompt": "Look at the code and find the root cause.",
                            "subagent_type": "Explore",
                            "run_in_background": True}},
             ]}},
        ]
        _write_session(sess_path, events)
        return tmp_path, session_id

    @pytest.mark.asyncio
    async def test_agent_input_shown_as_json(self, agent_with_prompt_project):
        """Agent node should render its input dict (including prompt)
        as wrapped JSON content, like standard tools."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_with_prompt_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            agent_node = None
            for node in tree.root.children[0].children:
                if node.data and node.data.get("type") == "agent":
                    agent_node = node
                    break
            assert agent_node is not None

            labels = _walk_labels(agent_node)
            joined = " | ".join(labels)

            # The prompt text should appear (may be word-wrapped across lines)
            assert "root cause" in joined, (
                f"Agent prompt not found in tree. Labels:\n{joined}"
            )
            # Should be formatted as input JSON
            assert "input:" in joined.lower(), (
                f"Expected 'input:' prefix like standard tools. Labels:\n{joined}"
            )
            # run_in_background should also be visible
            assert "run_in_background" in joined, (
                f"run_in_background field not found. Labels:\n{joined}"
            )


class TestAgentToolResultDisplay:
    """Bug 2: Agent tool_result text should appear under the agent node,
    not as a generic '→ result' under the user node.

    Tool_results for agents come in user events (separate from the assistant
    event containing the Agent tool_use). Currently they're rendered as
    generic results under user_node. They should be matched to the specific
    agent tree node by tool_use_id.
    """

    @pytest.fixture
    def agent_with_result_project(self, tmp_path):
        """Session with Agent tool_use + user event containing the agent's
        tool_result with meaningful content."""
        session_id = "sess-agent-result-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"

        events = [
            {"type": "user", "uuid": "u1", "parentUuid": None,
             "sessionId": session_id, "slug": "agent-result-test",
             "timestamp": "2026-04-01T10:00:00Z", "version": "2.1.77",
             "message": {"role": "user", "content": "research this topic"}},
            # Assistant launches agent
            {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:05Z",
             "message": {"role": "assistant", "content": [
                 {"type": "text", "text": "I'll research this."},
                 {"type": "tool_use", "id": "toolu_result001", "name": "Agent",
                  "input": {"description": "Research the topic",
                            "subagent_type": "Explore"}},
             ]}},
            # User event with tool_result for the agent
            {"type": "user", "uuid": "u2", "parentUuid": "a1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:10Z",
             "message": {"role": "user", "content": [
                 {"type": "tool_result", "tool_use_id": "toolu_result001",
                  "content": "Found 5 relevant papers on the topic."},
             ]}},
            # Final assistant response
            {"type": "assistant", "uuid": "a2", "parentUuid": "u2",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:15Z",
             "message": {"role": "assistant",
                         "content": "Based on the research, here are findings."}},
        ]
        _write_session(sess_path, events)

        # Create subagent files so the agent node gets a placeholder
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)
        (sub / "agent-reshash001.meta.json").write_text(
            json.dumps({"agentType": "Explore",
                         "description": "Research the topic"})
        )
        (sub / "agent-reshash001.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "su1",
                         "timestamp": "2026-04-01T10:00:05Z",
                         "message": {"role": "user", "content": "go"}}) + "\n"
        )
        return tmp_path, session_id

    @pytest.mark.asyncio
    async def test_agent_result_attached_to_agent_node(
        self, agent_with_result_project,
    ):
        """Tool_result text should appear as a child of the agent node."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_with_result_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)

            # Find the agent node
            agent_node = None
            for node in tree.root.children[0].children:  # user_node.children
                if node.data and node.data.get("type") == "agent":
                    agent_node = node
                    break
            assert agent_node is not None, "Agent node not found in tree"

            # The agent node should have the result as a child
            agent_labels = _walk_labels(agent_node)
            agent_joined = " | ".join(agent_labels)
            assert "Found 5 relevant papers" in agent_joined, (
                f"Agent tool_result not found under agent node. "
                f"Agent children: {agent_joined}"
            )

    @pytest.mark.asyncio
    async def test_agent_result_not_generic_under_user(
        self, agent_with_result_project,
    ):
        """Tool_result matched to an agent should NOT appear as generic
        '→ result' under the user node."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_with_result_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            # Walk only direct user_node children that are tool_result type
            user_node = tree.root.children[0]
            for child in user_node.children:
                if child.data and child.data.get("type") == "tool_result":
                    label = str(child.label)
                    assert "Found 5 relevant papers" not in label, (
                        f"Agent result should not appear as generic result. "
                        f"Found: {label}"
                    )


class TestEmptyTranscriptFeedback:
    """Bug 3: When a subagent JSONL file exists but contains no user/assistant
    events (only system events), expanding the agent node should show
    '(empty transcript)' instead of leaving the node silently empty."""

    @pytest.fixture
    def agent_empty_transcript_project(self, tmp_path):
        """Session with Agent tool_use + progress link + subagent JSONL
        that contains only a file-history-snapshot (no user/assistant events)."""
        session_id = "sess-empty-trans-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"

        events = [
            {"type": "user", "uuid": "u1", "parentUuid": None,
             "sessionId": session_id, "slug": "empty-transcript-test",
             "timestamp": "2026-04-01T10:00:00Z", "version": "2.1.77",
             "message": {"role": "user", "content": "research this"}},
            {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:05Z",
             "message": {"role": "assistant", "content": [
                 {"type": "tool_use", "id": "toolu_empty001", "name": "Agent",
                  "input": {"description": "Investigate the bug",
                            "subagent_type": "Explore"}},
             ]}},
            # Progress event linking the agent
            {"type": "progress", "uuid": "p1", "parentUuid": "a1",
             "data": {"agentId": "emptyhash001", "type": "agent_progress"},
             "parentToolUseID": "toolu_empty001", "toolUseID": "agent_msg1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:06Z"},
        ]
        _write_session(sess_path, events)

        # Subagent file with ONLY a file-history-snapshot — no user/assistant
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)
        (sub / "agent-emptyhash001.jsonl").write_text(
            json.dumps({
                "type": "file-history-snapshot",
                "messageId": "fhs1",
                "snapshot": {"messageId": "fhs1", "trackedFileBackups": {},
                             "timestamp": "2026-04-01T10:00:06Z"},
                "isSnapshotUpdate": False,
            }) + "\n"
        )
        return tmp_path, session_id

    @pytest.mark.asyncio
    async def test_empty_transcript_shows_feedback(
        self, agent_empty_transcript_project,
    ):
        """After expanding an agent with an empty transcript, a feedback
        leaf should appear instead of the node being silently empty."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_empty_transcript_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)

            # Find the agent node
            agent_node = None
            for node in tree.root.children[0].children:
                if node.data and node.data.get("type") == "agent":
                    agent_node = node
                    break
            assert agent_node is not None, "Agent node not found"

            # Expand the agent node to trigger lazy loading
            agent_node.expand()
            await pilot.pause()

            labels = _walk_labels(agent_node)
            joined = " | ".join(labels)

            assert "empty transcript" in joined.lower(), (
                f"Expected '(empty transcript)' feedback after expanding "
                f"agent with no content events. Labels: {joined}"
            )


class TestMetaDiscovery:
    """Task 5: When progress events are missing but meta.json files exist
    in the subagents/ directory, agent nodes should get a placeholder for
    lazy-loading instead of the 'no agent link' warning."""

    @pytest.fixture
    def agent_meta_project(self, tmp_path):
        """Session with Agent tool_use, NO progress events, but meta.json
        + subagent JSONL files exist on disk."""
        session_id = "sess-meta-disc-0000-0000-000000000001"
        sess_path = tmp_path / f"{session_id}.jsonl"

        events = [
            {"type": "user", "uuid": "u1", "parentUuid": None,
             "sessionId": session_id, "slug": "meta-disc-test",
             "timestamp": "2026-04-01T10:00:00Z", "version": "2.1.77",
             "message": {"role": "user", "content": "research this topic"}},
            # Assistant with Agent tool_use — NO progress events
            {"type": "assistant", "uuid": "a1", "parentUuid": "u1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:05Z",
             "message": {"role": "assistant", "content": [
                 {"type": "text", "text": "I'll research this."},
                 {"type": "tool_use", "id": "toolu_meta001", "name": "Agent",
                  "input": {"description": "Research the topic",
                            "subagent_type": "Explore"}},
             ]}},
            {"type": "assistant", "uuid": "a2", "parentUuid": "a1",
             "sessionId": session_id,
             "timestamp": "2026-04-01T10:00:15Z",
             "message": {"role": "assistant",
                         "content": "Here are the findings."}},
        ]
        _write_session(sess_path, events)

        # Create subagents/ with meta.json + JSONL (no progress events needed)
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)
        (sub / "agent-metahash001.meta.json").write_text(
            json.dumps({"agentType": "Explore",
                         "description": "Research the topic"})
        )
        (sub / "agent-metahash001.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "su1",
                         "agentId": "metahash001",
                         "timestamp": "2026-04-01T10:00:05Z",
                         "sessionId": session_id,
                         "message": {"role": "user",
                                     "content": "research prompt"}}) + "\n"
            + json.dumps({"type": "assistant", "uuid": "sa1",
                          "parentUuid": "su1",
                          "timestamp": "2026-04-01T10:00:10Z",
                          "message": {"role": "assistant",
                                      "content": "Found results."}}) + "\n"
        )
        return tmp_path, session_id

    @pytest.mark.asyncio
    async def test_meta_discovery_provides_placeholder(self, agent_meta_project):
        """Agent node should get a lazy-load placeholder (not 'no agent link')
        when meta.json matches the description."""
        from textual.widgets import Tree

        from cctree.tui.app import CctreeApp

        tmp_path, session_id = agent_meta_project
        app = CctreeApp(project_dir=str(tmp_path))
        async with app.run_test() as pilot:
            session = app.store.get(session_id)
            app.load_session(session)
            await pilot.pause()

            tree = app.query_one("#session-tree", Tree)
            labels = _walk_labels(tree.root)
            joined = " | ".join(labels)

            # Agent node should be present
            assert "Research the topic" in joined, (
                f"Agent label not found. Labels:\n{joined}"
            )
            # Should NOT show the "no agent link" warning
            assert "no agent link" not in joined.lower(), (
                f"Meta discovery should have resolved the link, "
                f"but 'no agent link' warning still showing. Labels:\n{joined}"
            )
            # Should show the placeholder for lazy loading
            assert "expand to load transcript" in joined.lower(), (
                f"Expected lazy-load placeholder but not found. Labels:\n{joined}"
            )
