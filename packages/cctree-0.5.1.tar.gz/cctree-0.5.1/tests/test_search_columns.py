"""Tests for columnar search result formatting."""
from __future__ import annotations

import json
import os
import time
from datetime import datetime
from pathlib import Path

import pytest

FIXTURES = Path(__file__).parent / "fixtures"


# ─── Unit tests for column helpers ───────────────────────────────────────────


class TestFormatDate:
    """Tests for _format_date helper."""

    def test_renders_mm_dd_hh(self):
        from cctree.tui.modals import _format_date

        dt = datetime(2026, 4, 1, 14, 30, 0)
        assert _format_date(dt) == "04/01 14h"

    def test_none_returns_dash(self):
        from cctree.tui.modals import _format_date

        assert _format_date(None) == "-"

    def test_midnight(self):
        from cctree.tui.modals import _format_date

        dt = datetime(2026, 1, 5, 0, 0, 0)
        assert _format_date(dt) == "01/05 00h"

    def test_single_digit_month_and_day(self):
        from cctree.tui.modals import _format_date

        dt = datetime(2026, 3, 7, 9, 0, 0)
        assert _format_date(dt) == "03/07 09h"


class TestFormatFileSize:
    """Tests for _format_file_size helper."""

    def test_bytes(self, tmp_path):
        from cctree.tui.modals import _format_file_size

        f = tmp_path / "small.jsonl"
        f.write_text("x" * 500)
        assert _format_file_size(str(f)) == "500B"

    def test_kilobytes(self, tmp_path):
        from cctree.tui.modals import _format_file_size

        f = tmp_path / "medium.jsonl"
        f.write_text("x" * 5120)
        assert _format_file_size(str(f)) == "5K"

    def test_megabytes(self, tmp_path):
        from cctree.tui.modals import _format_file_size

        f = tmp_path / "large.jsonl"
        f.write_bytes(b"x" * (2 * 1024 * 1024))
        assert _format_file_size(str(f)) == "2.0M"

    def test_missing_file(self):
        from cctree.tui.modals import _format_file_size

        assert _format_file_size("/nonexistent/file.jsonl") == "-"


class TestTruncate:
    """Tests for _truncate helper."""

    def test_short_text_unchanged(self):
        from cctree.tui.modals import _truncate

        assert _truncate("short", 12) == "short"

    def test_exact_width_unchanged(self):
        from cctree.tui.modals import _truncate

        assert _truncate("exactly12chr", 12) == "exactly12chr"

    def test_long_text_adds_ellipsis(self):
        from cctree.tui.modals import _truncate

        result = _truncate("this-is-a-very-long-name", 12)
        assert result == "this-is-a-v\u2026"
        assert len(result) == 12

    def test_width_1(self):
        from cctree.tui.modals import _truncate

        assert _truncate("hello", 1) == "\u2026"


# ─── Tests for header and columnar formatting ───────────────────────────────


class TestBuildHeader:
    """Tests for _build_header."""

    def test_contains_all_column_names(self):
        from cctree.tui.modals import _build_header

        header = _build_header()
        for col in ["TYPE", "NAME", "STARTED", "ACTIVE", "MSGS", "SIZE", "CONTEXT"]:
            assert col in header

    def test_is_bold(self):
        from cctree.tui.modals import _build_header

        header = _build_header()
        assert header.startswith("[bold]")
        assert header.endswith("[/bold]")


class TestColumnarFormat:
    """Verify columnar alignment of search result rows."""

    @pytest.fixture
    def store_with_sessions(self, tmp_path):
        """Create a SessionStore with sessions for testing."""
        from cctree.core.store import SessionStore

        session_id = "aaaa-bbbb-cccc-dddd-eeeeeeeeeeee"
        lines = [
            json.dumps({
                "type": "user", "uuid": "u1", "parentUuid": None,
                "message": {"role": "user", "content": "tell me about the migration script"},
                "sessionId": session_id, "slug": "elegant-seeking-corbato",
                "timestamp": "2026-04-01T10:00:00Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a1", "parentUuid": "u1",
                "message": {"role": "assistant", "content": [
                    {"type": "text", "text": "The migration handles schema changes."}]},
                "sessionId": session_id, "slug": "elegant-seeking-corbato",
                "timestamp": "2026-04-01T10:05:00Z",
            }),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))

        store = SessionStore(project_dir=tmp_path)
        _ = store.sessions
        return store

    def test_type_column_starts_at_position_0(self, store_with_sessions):
        """TYPE column should start at column 0."""
        from cctree.tui.modals import SearchScreen
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        assert plain.startswith("slug")

    def test_name_column_aligned_with_header(self, store_with_sessions):
        """NAME column position in results should match header."""
        from cctree.tui.modals import SearchScreen, _build_header, _COL_TYPE, _SEP
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1

        header_plain = Text.from_markup(_build_header()).plain
        result_plain = Text.from_markup(matches[0][0]).plain

        name_start = _COL_TYPE + len(_SEP)
        assert header_plain[name_start:name_start + 4] == "NAME"
        # Result name starts at the same position
        assert result_plain[name_start] != " " or result_plain[name_start:].strip()

    def test_name_column_truncated(self, store_with_sessions):
        """Long session names should be truncated in the NAME column."""
        from cctree.tui.modals import SearchScreen, _COL_TYPE, _COL_NAME, _SEP
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        # Extract the NAME column by position
        name_start = _COL_TYPE + len(_SEP)
        name_end = name_start + _COL_NAME
        name_col = plain[name_start:name_end]
        # Should be truncated with ellipsis, not the full 23-char slug
        assert len(name_col.rstrip()) <= _COL_NAME
        assert "\u2026" in name_col

    def test_date_columns_present(self, store_with_sessions):
        """Results should include formatted date values."""
        from cctree.tui.modals import SearchScreen
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        assert "04/01" in plain

    def test_message_count_present(self, store_with_sessions):
        """Results should include the message count."""
        from cctree.tui.modals import SearchScreen
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        # Session has 2 messages
        assert "   2" in plain or "2" in plain

    def test_file_size_present(self, store_with_sessions):
        """Results should include a file size column."""
        from cctree.tui.modals import SearchScreen
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("elegant")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        # File size should end with B, K, or M
        assert any(c in plain for c in ["B", "K", "M"])

    def test_content_match_has_excerpt(self, store_with_sessions):
        """Content matches should show an excerpt in the CONTEXT column."""
        from cctree.tui.modals import SearchScreen

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("migration")
        assert len(matches) >= 1
        label = matches[0][0]
        assert "migration" in label.lower()
        assert "..." in label

    def test_uuid_match_type_column(self, store_with_sessions):
        """UUID matches should show 'uuid' in the TYPE column."""
        from cctree.tui.modals import SearchScreen
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("aaaa")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        assert plain.startswith("uuid")

    def test_content_match_type_column(self, store_with_sessions):
        """Content matches should show 'content' in the TYPE column."""
        from cctree.tui.modals import SearchScreen
        from rich.text import Text

        screen = SearchScreen(store_with_sessions)
        matches = screen._build_matches("migration")
        assert len(matches) >= 1
        plain = Text.from_markup(matches[0][0]).plain
        assert plain.startswith("content")

    def test_all_results_have_same_column_positions(self, tmp_path):
        """All result rows should have columns at identical positions."""
        from cctree.core.store import SessionStore
        from cctree.tui.modals import SearchScreen, _COL_TYPE, _COL_NAME, _SEP
        from rich.text import Text

        # Create two sessions so we get multiple results
        for i, slug in enumerate(["alpha-project", "alpha-runner"]):
            sid = f"alpha{i:04d}-0000-0000-0000-000000000000"
            lines = [json.dumps({
                "type": "user", "uuid": f"u{i}", "parentUuid": None,
                "message": {"role": "user", "content": f"msg {i}"},
                "sessionId": sid, "slug": slug,
                "timestamp": f"2026-04-0{i + 1}T10:00:00Z",
            })]
            (tmp_path / f"{sid}.jsonl").write_text("\n".join(lines) + "\n")

        store = SessionStore(project_dir=tmp_path)
        _ = store.sessions
        screen = SearchScreen(store)
        matches = screen._build_matches("alpha")
        assert len(matches) >= 2

        # All rows should have the name column starting at the same position
        name_start = _COL_TYPE + len(_SEP)
        for label, _, _ in matches:
            plain = Text.from_markup(label).plain
            # Check that position after TYPE+SEP is consistent
            assert len(plain) >= name_start
