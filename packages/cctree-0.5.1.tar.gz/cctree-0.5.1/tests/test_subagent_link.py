"""Tests for subagent linkage — mapping parent tool_use to subagent JSONL files.

The linkage chain is:
  Agent tool_use (tool_use_id) → progress event (parentToolUseID → data.agentId) → agent-{agentId}.jsonl
"""
from __future__ import annotations

from pathlib import Path

import pytest

from cctree.core.parser import parse_jsonl
from cctree.core.model import Session

FIXTURES = Path(__file__).parent / "fixtures"


class TestSubagentLinkDiscovery:
    """Test that we can discover the agentId for each Agent tool_use in a session."""

    def test_finds_agent_id_from_progress_events(self):
        events = parse_jsonl(FIXTURES / "with_subagent.jsonl")
        session = Session(uuid="sess0006", project_slug="test", path="x", events=events)

        # Import the function we're about to write
        from cctree.core.subagent_link import find_agent_links

        links = find_agent_links(session.events)
        # Should find one link: toolu_agent001 → abc123def456
        assert len(links) == 1
        assert links["toolu_agent001"] == "abc123def456"

    def test_returns_empty_for_session_without_agents(self):
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        session = Session(uuid="sess0001", project_slug="test", path="x", events=events)

        from cctree.core.subagent_link import find_agent_links

        links = find_agent_links(session.events)
        assert links == {}

    def test_multiple_agents_each_linked(self):
        """A session with multiple Agent tool_use calls should map each to its agentId."""
        from cctree.core.subagent_link import find_agent_links

        # Construct events with two Agent calls
        from cctree.core.model import SessionEvent
        events = [
            # Agent tool_use 1
            SessionEvent(
                type="assistant",
                uuid="a1",
                message={"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_first", "name": "Agent",
                     "input": {"description": "first agent", "subagent_type": "Explore"}},
                ]},
            ),
            # Progress linking first agent
            SessionEvent(type="progress", uuid="p1", **{
                "data": {"agentId": "hash_first", "type": "agent_progress"},
                "parentToolUseID": "toolu_first",
            }),
            # Agent tool_use 2
            SessionEvent(
                type="assistant",
                uuid="a2",
                parentUuid="a1",
                message={"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_second", "name": "Agent",
                     "input": {"description": "second agent", "subagent_type": "general-purpose"}},
                ]},
            ),
            # Progress linking second agent
            SessionEvent(type="progress", uuid="p2", **{
                "data": {"agentId": "hash_second", "type": "agent_progress"},
                "parentToolUseID": "toolu_second",
            }),
        ]

        links = find_agent_links(events)
        assert len(links) == 2
        assert links["toolu_first"] == "hash_first"
        assert links["toolu_second"] == "hash_second"


class TestSubagentFileResolution:
    """Test resolving an agentId to its JSONL file path."""

    def test_resolves_existing_file(self, tmp_path):
        # Create a fake subagents dir
        subagents_dir = tmp_path / "sess0006" / "subagents"
        subagents_dir.mkdir(parents=True)
        (subagents_dir / "agent-abc123def456.jsonl").write_text('{"type":"user"}\n')

        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path("abc123def456", str(tmp_path / "sess0006.jsonl"))
        assert path is not None
        assert path.name == "agent-abc123def456.jsonl"

    def test_returns_none_for_missing_file(self, tmp_path):
        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path("nonexistent", str(tmp_path / "sess0006.jsonl"))
        assert path is None

    def test_returns_none_for_no_subagents_dir(self, tmp_path):
        # JSONL exists but no subagents/ dir
        (tmp_path / "sess0006.jsonl").write_text("{}\n")

        from cctree.core.subagent_link import resolve_subagent_path

        path = resolve_subagent_path("abc123", str(tmp_path / "sess0006.jsonl"))
        assert path is None

class TestFindTeammateReferences:
    """Discover teammate names mentioned in <teammate-message> tags across events."""

    def test_finds_teammate_names_in_user_content(self):
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import find_teammate_references

        events = [
            SessionEvent(
                type="user",
                uuid="u1",
                message={
                    "role": "user",
                    "content": (
                        '<teammate-message teammate_id="researcher" color="blue">\n'
                        "hi\n</teammate-message>\n"
                        '<teammate-message teammate_id="writer" color="green">\n'
                        "ok\n</teammate-message>"
                    ),
                },
            ),
            SessionEvent(
                type="user",
                uuid="u2",
                message={
                    "role": "user",
                    "content": '<teammate-message teammate_id="researcher">repeat</teammate-message>',
                },
            ),
        ]
        refs = find_teammate_references(events)
        assert refs == {"researcher", "writer"}

    def test_empty_on_non_team_session(self):
        from cctree.core.parser import parse_jsonl
        from cctree.core.subagent_link import find_teammate_references
        from pathlib import Path

        FIXTURES = Path(__file__).parent / "fixtures"
        events = parse_jsonl(FIXTURES / "simple_session.jsonl")
        assert find_teammate_references(events) == set()

    def test_ignores_content_arrays(self):
        """Content may be a list of ContentBlocks (normal Claude messages).
        Teammate-message tags only appear in string content."""
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import find_teammate_references

        events = [
            SessionEvent(
                type="assistant",
                uuid="a1",
                message={
                    "role": "assistant",
                    "content": [{"type": "text", "text": "no tags here"}],
                },
            ),
        ]
        assert find_teammate_references(events) == set()


class TestResolveTeammatePaths:
    def test_returns_all_files_for_teammate(self, tmp_path):
        import json
        import time
        from cctree.core.subagent_link import resolve_teammate_paths

        sub = tmp_path / "sess" / "subagents"
        sub.mkdir(parents=True)
        for h in ("a1", "a2"):
            (sub / f"agent-{h}.meta.json").write_text(json.dumps({"agentType": "r"}))
            (sub / f"agent-{h}.jsonl").write_text("{}\n")
            time.sleep(0.005)
        # Unrelated teammate
        (sub / "agent-b1.meta.json").write_text(json.dumps({"agentType": "w"}))
        (sub / "agent-b1.jsonl").write_text("{}\n")

        paths = resolve_teammate_paths("r", str(tmp_path / "sess.jsonl"))
        assert len(paths) == 2
        assert all(p.name.startswith("agent-a") for p in paths)

    def test_empty_when_no_subagents(self, tmp_path):
        from cctree.core.subagent_link import resolve_teammate_paths

        assert resolve_teammate_paths("r", str(tmp_path / "sess.jsonl")) == []

    def test_teammate_not_found(self, tmp_path):
        from cctree.core.subagent_link import resolve_teammate_paths

        paths = resolve_teammate_paths(
            "r",
            str(tmp_path / "sess.jsonl"),
        )
        assert paths == []


class TestBuildMetaIndex:
    """Unit tests for build_meta_index(): scan subagents/*.meta.json files
    and return {(description, agentType): [(agentId, timestamp), ...]}."""

    def test_basic_single_agent(self, tmp_path):
        """Single meta.json + JSONL produces a one-entry index."""
        import json
        from cctree.core.subagent_link import build_meta_index

        sub = tmp_path / "subagents"
        sub.mkdir()
        (sub / "agent-abc123.meta.json").write_text(
            json.dumps({"agentType": "Explore", "description": "Research topic"})
        )
        (sub / "agent-abc123.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "u1",
                         "timestamp": "2026-04-01T10:00:00Z",
                         "message": {"role": "user", "content": "go"}}) + "\n"
        )

        index = build_meta_index(sub)
        key = ("Research topic", "Explore")
        assert key in index
        assert len(index[key]) == 1
        agent_id, ts = index[key][0]
        assert agent_id == "abc123"
        assert ts == "2026-04-01T10:00:00Z"

    def test_multiple_agents_different_descriptions(self, tmp_path):
        """Multiple meta.json files with distinct descriptions."""
        import json
        from cctree.core.subagent_link import build_meta_index

        sub = tmp_path / "subagents"
        sub.mkdir()
        for aid, desc, atype, ts in [
            ("aaa", "Fix tests", "general-purpose", "2026-04-01T10:00:00Z"),
            ("bbb", "Research bug", "Explore", "2026-04-01T10:01:00Z"),
        ]:
            (sub / f"agent-{aid}.meta.json").write_text(
                json.dumps({"agentType": atype, "description": desc})
            )
            (sub / f"agent-{aid}.jsonl").write_text(
                json.dumps({"type": "user", "uuid": "u1",
                             "timestamp": ts,
                             "message": {"role": "user", "content": "go"}}) + "\n"
            )

        index = build_meta_index(sub)
        assert ("Fix tests", "general-purpose") in index
        assert ("Research bug", "Explore") in index
        assert len(index) == 2

    def test_skips_meta_without_description(self, tmp_path):
        """Meta files with empty or missing description are excluded."""
        import json
        from cctree.core.subagent_link import build_meta_index

        sub = tmp_path / "subagents"
        sub.mkdir()
        # No description
        (sub / "agent-nodesc.meta.json").write_text(
            json.dumps({"agentType": "Explore"})
        )
        (sub / "agent-nodesc.jsonl").write_text('{"type":"user"}\n')
        # Empty description
        (sub / "agent-empty.meta.json").write_text(
            json.dumps({"agentType": "Explore", "description": ""})
        )
        (sub / "agent-empty.jsonl").write_text('{"type":"user"}\n')

        index = build_meta_index(sub)
        assert index == {}

    def test_duplicate_descriptions_grouped_and_sorted_by_timestamp(self, tmp_path):
        """Two agents with same (desc, type) are grouped together, sorted by timestamp."""
        import json
        from cctree.core.subagent_link import build_meta_index

        sub = tmp_path / "subagents"
        sub.mkdir()
        for aid, ts in [("late", "2026-04-01T10:05:00Z"), ("early", "2026-04-01T10:00:00Z")]:
            (sub / f"agent-{aid}.meta.json").write_text(
                json.dumps({"agentType": "general-purpose", "description": "run tests"})
            )
            (sub / f"agent-{aid}.jsonl").write_text(
                json.dumps({"type": "user", "uuid": "u1",
                             "timestamp": ts,
                             "message": {"role": "user", "content": "go"}}) + "\n"
            )

        index = build_meta_index(sub)
        key = ("run tests", "general-purpose")
        assert len(index[key]) == 2
        # Should be sorted: early first, late second
        assert index[key][0][0] == "early"
        assert index[key][1][0] == "late"

    def test_empty_directory(self, tmp_path):
        """Empty subagents dir returns empty index."""
        from cctree.core.subagent_link import build_meta_index

        sub = tmp_path / "subagents"
        sub.mkdir()
        assert build_meta_index(sub) == {}


class TestDiscoverUnlinkedAgents:
    """Unit tests for discover_unlinked_agents(): fill in agent_links gaps
    from meta.json when progress events are missing."""

    def test_discovers_agent_from_meta(self, tmp_path):
        """Agent tool_use with no progress event gets linked via meta.json."""
        import json
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import discover_unlinked_agents

        # Set up subagents dir with meta + JSONL
        session_id = "sess-meta-test"
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)
        (sub / "agent-found123.meta.json").write_text(
            json.dumps({"agentType": "Explore", "description": "Research topic"})
        )
        (sub / "agent-found123.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "su1",
                         "timestamp": "2026-04-01T10:00:05Z",
                         "message": {"role": "user", "content": "go"}}) + "\n"
        )

        events = [
            SessionEvent.model_validate({
                "type": "assistant", "uuid": "a1",
                "timestamp": "2026-04-01T10:00:05Z",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_test001", "name": "Agent",
                     "input": {"description": "Research topic",
                               "subagent_type": "Explore"}},
                ]},
            }),
        ]

        new_links = discover_unlinked_agents(
            events, linked={}, session_jsonl_path=str(tmp_path / f"{session_id}.jsonl"),
        )
        assert new_links == {"toolu_test001": "found123"}

    def test_skips_already_linked_agents(self, tmp_path):
        """Agents already in `linked` are not re-discovered from meta."""
        import json
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import discover_unlinked_agents

        session_id = "sess-skip-test"
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)
        (sub / "agent-already.meta.json").write_text(
            json.dumps({"agentType": "Explore", "description": "Already linked"})
        )
        (sub / "agent-already.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "su1",
                         "timestamp": "2026-04-01T10:00:00Z",
                         "message": {"role": "user", "content": "go"}}) + "\n"
        )

        events = [
            SessionEvent.model_validate({
                "type": "assistant", "uuid": "a1",
                "timestamp": "2026-04-01T10:00:00Z",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_existing", "name": "Agent",
                     "input": {"description": "Already linked",
                               "subagent_type": "Explore"}},
                ]},
            }),
        ]

        # This agent is already linked via progress events
        new_links = discover_unlinked_agents(
            events,
            linked={"toolu_existing": "already"},
            session_jsonl_path=str(tmp_path / f"{session_id}.jsonl"),
        )
        assert new_links == {}

    def test_disambiguates_duplicates_by_timestamp(self, tmp_path):
        """Two agents with same (desc, type) are matched by closest timestamp."""
        import json
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import discover_unlinked_agents

        session_id = "sess-dup-test"
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)

        # Two agents with same description, different timestamps
        for aid, ts in [("first", "2026-04-01T10:00:00Z"),
                        ("second", "2026-04-01T10:01:00Z")]:
            (sub / f"agent-{aid}.meta.json").write_text(
                json.dumps({"agentType": "general-purpose",
                             "description": "run tests"})
            )
            (sub / f"agent-{aid}.jsonl").write_text(
                json.dumps({"type": "user", "uuid": "su1",
                             "timestamp": ts,
                             "message": {"role": "user", "content": "go"}}) + "\n"
            )

        events = [
            SessionEvent.model_validate({
                "type": "assistant", "uuid": "a1",
                "timestamp": "2026-04-01T10:00:00Z",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_first", "name": "Agent",
                     "input": {"description": "run tests",
                               "subagent_type": "general-purpose"}},
                ]},
            }),
            SessionEvent.model_validate({
                "type": "assistant", "uuid": "a2",
                "timestamp": "2026-04-01T10:01:00Z",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_second", "name": "Agent",
                     "input": {"description": "run tests",
                               "subagent_type": "general-purpose"}},
                ]},
            }),
        ]

        new_links = discover_unlinked_agents(
            events, linked={},
            session_jsonl_path=str(tmp_path / f"{session_id}.jsonl"),
        )
        assert new_links["toolu_first"] == "first"
        assert new_links["toolu_second"] == "second"

    def test_matches_when_subagent_type_empty(self, tmp_path):
        """When the Agent tool_use omits subagent_type (empty string), it should
        still match meta.json entries by description alone."""
        import json
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import discover_unlinked_agents

        session_id = "sess-empty-type"
        sub = tmp_path / session_id / "subagents"
        sub.mkdir(parents=True)
        (sub / "agent-found456.meta.json").write_text(
            json.dumps({"agentType": "general-purpose",
                         "description": "Deep bug hunt"})
        )
        (sub / "agent-found456.jsonl").write_text(
            json.dumps({"type": "user", "uuid": "su1",
                         "timestamp": "2026-04-01T10:00:05Z",
                         "message": {"role": "user", "content": "go"}}) + "\n"
        )

        events = [
            SessionEvent.model_validate({
                "type": "assistant", "uuid": "a1",
                "timestamp": "2026-04-01T10:00:05Z",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_notype", "name": "Agent",
                     "input": {"description": "Deep bug hunt"}},
                    # NOTE: no subagent_type field at all
                ]},
            }),
        ]

        new_links = discover_unlinked_agents(
            events, linked={},
            session_jsonl_path=str(tmp_path / f"{session_id}.jsonl"),
        )
        assert new_links == {"toolu_notype": "found456"}

    def test_returns_empty_when_no_subagents_dir(self, tmp_path):
        """No subagents/ directory → empty result, no crash."""
        from cctree.core.model import SessionEvent
        from cctree.core.subagent_link import discover_unlinked_agents

        events = [
            SessionEvent.model_validate({
                "type": "assistant", "uuid": "a1",
                "message": {"role": "assistant", "content": [
                    {"type": "tool_use", "id": "toolu_x", "name": "Agent",
                     "input": {"description": "some task",
                               "subagent_type": "Explore"}},
                ]},
            }),
        ]

        new_links = discover_unlinked_agents(
            events, linked={},
            session_jsonl_path=str(tmp_path / "nonexistent.jsonl"),
        )
        assert new_links == {}
