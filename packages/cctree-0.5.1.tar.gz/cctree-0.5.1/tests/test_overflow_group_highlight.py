"""Tests for overflow node group-highlight bubble-up behavior."""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pytest


FIXTURES = Path(__file__).parent / "fixtures"


async def _load_session_into_tree(pilot, app):
    """Navigate past template items, auto-load the session, focus the tree."""
    from textual.widgets import ListView
    lv = app.query_one("#sessions-pane", ListView)
    for _ in range(10):
        await pilot.press("down")
        await pilot.pause()
        idx = lv.index if lv.index is not None else 0
        items = list(lv.children)
        if 0 <= idx < len(items):
            name = getattr(items[idx], "name", "")
            if name and not name.startswith("__"):
                break
    assert app.current_session is not None, "Session should be auto-loaded"
    await pilot.press("right")
    await pilot.pause()


def _find_overflow(node):
    """Recursively find the first overflow node under *node*."""
    if node.data and node.data.get("type") == "overflow":
        return node
    for child in node.children:
        found = _find_overflow(child)
        if found:
            return found
    return None


class TestOverflowGroupHighlight:
    """Selecting an overflow node should highlight the entire parent message."""

    @pytest.fixture
    def project_dir(self, tmp_path):
        session_id = "sess-ovhl-0000-0000-000000000000"
        # 200 words guarantees wrapping + overflow at 80-col width
        long_text = " ".join(["word"] * 200)
        lines = [
            json.dumps({
                "type": "user", "uuid": "u1", "parentUuid": None,
                "message": {"role": "user", "content": long_text},
                "sessionId": session_id, "slug": "overflow-hl",
                "timestamp": "2026-04-01T10:00:00Z",
            }),
            json.dumps({
                "type": "assistant", "uuid": "a1", "parentUuid": "u1",
                "message": {"role": "assistant", "content": "Short reply."},
                "sessionId": session_id,
                "timestamp": "2026-04-01T10:00:01Z",
            }),
            json.dumps({
                "type": "user", "uuid": "u2", "parentUuid": "a1",
                "message": {"role": "user", "content": "Second question"},
                "sessionId": session_id,
                "timestamp": "2026-04-01T10:00:02Z",
            }),
        ]
        (tmp_path / f"{session_id}.jsonl").write_text("\n".join(lines) + "\n")
        old_time = time.time() - 300
        os.utime(tmp_path / f"{session_id}.jsonl", (old_time, old_time))
        return tmp_path

    def _navigate_to_overflow(self, tree):
        """Select the overflow node directly via tree.select_node."""
        user_node = tree.root.children[0]
        overflow = _find_overflow(user_node)
        assert overflow is not None, (
            f"No overflow node. Children types: "
            f"{[c.data.get('type') if c.data else None for c in user_node.children]}"
        )
        tree.select_node(overflow)
        return overflow, user_node

    @pytest.mark.asyncio
    async def test_overflow_selected_highlights_parent_label(self, project_dir):
        """When overflow is selected, the parent message node should be group-highlighted."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)
            overflow, user_node = self._navigate_to_overflow(tree)
            await pilot.pause()

            highlighted_nodes = [n for n, _ in app._group_highlight_children]
            assert user_node in highlighted_nodes, (
                "Parent message node should be in group highlight list"
            )

    @pytest.mark.asyncio
    async def test_overflow_selected_highlights_siblings(self, project_dir):
        """When overflow is selected, sibling continuation leaves should be highlighted."""
        from cctree.tui.app import CctreeApp, _GROUP_HIGHLIGHT_TYPES
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)
            overflow, user_node = self._navigate_to_overflow(tree)
            await pilot.pause()

            highlighted_nodes = {id(n) for n, _ in app._group_highlight_children}
            siblings = [
                c for c in user_node.children
                if c is not overflow
                and c.data and c.data.get("type") in _GROUP_HIGHLIGHT_TYPES
            ]
            assert len(siblings) > 0, "Expected sibling continuation leaves"
            for sib in siblings:
                assert id(sib) in highlighted_nodes, (
                    f"Sibling of type '{sib.data.get('type')}' should be highlighted"
                )

    @pytest.mark.asyncio
    async def test_overflow_selected_highlights_own_children(self, project_dir):
        """When overflow is selected, its own children should be highlighted."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)
            overflow, _ = self._navigate_to_overflow(tree)
            await pilot.pause()

            assert len(overflow.children) > 0, "Overflow should have children"
            highlighted_nodes = {id(n) for n, _ in app._group_highlight_children}
            for child in overflow.children:
                assert id(child) in highlighted_nodes, (
                    "Each overflow child should be highlighted"
                )

    @pytest.mark.asyncio
    async def test_overflow_highlight_cleared_on_move(self, project_dir):
        """Group highlights should clear when cursor moves away from overflow."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)
            overflow, user_node = self._navigate_to_overflow(tree)
            await pilot.pause()

            # Should have highlights now
            assert len(app._group_highlight_children) > 0

            # Move to user node (parent) — highlights should refresh
            tree.select_node(user_node)
            await pilot.pause()

            # The overflow node itself should NOT be the cursor anymore;
            # group_highlight_children should be repopulated for user_node context
            highlighted_nodes = {id(n) for n, _ in app._group_highlight_children}
            # The overflow node is NOT the cursor, so it shouldn't have
            # stale bubble-up highlights — it should be in the parent's
            # group highlight list instead
            assert id(user_node) not in highlighted_nodes, (
                "Parent node is now the cursor — it should not be in its own group highlight"
            )

    @pytest.mark.asyncio
    async def test_parent_selected_highlights_overflow_children(self, project_dir):
        """When parent is selected and overflow is expanded, grandchildren are highlighted."""
        from cctree.tui.app import CctreeApp
        from textual.widgets import Tree

        app = CctreeApp(project_dir=str(project_dir))
        async with app.run_test(size=(80, 24)) as pilot:
            await app.workers.wait_for_complete()
            await _load_session_into_tree(pilot, app)

            tree = app.query_one("#session-tree", Tree)
            user_node = tree.root.children[0]
            overflow = _find_overflow(user_node)
            assert overflow is not None

            # Expand the overflow node so its children are visible
            overflow.expand()
            await pilot.pause()

            # Select the parent message node
            tree.select_node(user_node)
            await pilot.pause()

            highlighted_nodes = {id(n) for n, _ in app._group_highlight_children}
            # Overflow's children (grandchildren of user_node) should be highlighted
            for child in overflow.children:
                assert id(child) in highlighted_nodes, (
                    "Overflow grandchild should be highlighted when parent is selected"
                )
