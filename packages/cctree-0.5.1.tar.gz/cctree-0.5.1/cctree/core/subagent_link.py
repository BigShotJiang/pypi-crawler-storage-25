"""Subagent linkage: map parent Agent tool_use blocks to subagent JSONL files.

The linkage chain discovered from real Claude Code sessions:
  1. Parent session has an Assistant message with a tool_use block (name="Agent")
     → tool_use_id = "toolu_XXXXX"
  2. Subsequent progress events in the parent session have:
     → parentToolUseID = "toolu_XXXXX"  (links back to the Agent tool_use)
     → data.agentId = "abc123def456"    (the subagent's ID)
  3. The subagent's transcript lives at:
     → <project-dir>/<session-uuid>/subagents/agent-<agentId>.jsonl

When progress events are missing (Claude Code sometimes omits them), a secondary
discovery path uses the meta.json sidecar files in the subagents/ directory:
  - Each agent-{hash}.meta.json contains {"agentType": "...", "description": "..."}
  - These match the Agent tool_use input fields (subagent_type, description)
  - Timestamp disambiguation handles duplicate descriptions

Team teammates use a different discovery path: their names appear inside
<teammate-message teammate_id="NAME"> tags within user-message content, and
their transcripts are classified by meta.json shape (see teammate_sessions.py).
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from .model import EventType, SessionEvent
from .teammate import contains_teammate_message, parse_teammate_messages
from .teammate_sessions import find_teammate_sessions


def find_agent_links(events: list[SessionEvent]) -> dict[str, str]:
    """Discover tool_use_id → agentId mappings from progress events.

    Returns a dict mapping Agent tool_use IDs to their subagent file hashes.
    """
    links: dict[str, str] = {}

    for evt in events:
        if evt.type != "progress":
            continue

        # Progress events store the link in model_extra (since data, parentToolUseID,
        # toolUseID aren't declared fields on SessionEvent)
        data = evt.model_extra.get("data") if evt.model_extra else None
        if not isinstance(data, dict):
            continue

        agent_id = data.get("agentId")
        if not agent_id:
            continue

        parent_tool_use_id = evt.model_extra.get("parentToolUseID")
        if not parent_tool_use_id:
            continue

        # First occurrence wins (subsequent progress events for the same agent
        # will have the same mapping)
        if parent_tool_use_id not in links:
            links[parent_tool_use_id] = agent_id

    return links


def build_meta_index(
    subagents_dir: Path,
) -> dict[tuple[str, str], list[tuple[str, str]]]:
    """Build an index from subagents/*.meta.json for description-based discovery.

    Returns {(description, agentType): [(agentId, timestamp), ...]} sorted by
    timestamp within each group.  The timestamp comes from the first event in
    the companion JSONL file (the agent's creation instant).
    """
    index: dict[tuple[str, str], list[tuple[str, str]]] = {}

    for meta_path in subagents_dir.glob("agent-*.meta.json"):
        try:
            meta = json.loads(meta_path.read_text())
        except (json.JSONDecodeError, OSError):
            continue

        desc = meta.get("description", "")
        agent_type = meta.get("agentType", "")
        if not desc:
            continue

        # Extract agentId from filename: agent-{agentId}.meta.json
        agent_id = meta_path.name.removeprefix("agent-").removesuffix(".meta.json")

        # Read first line of companion JSONL for creation timestamp
        jsonl_path = meta_path.parent / f"agent-{agent_id}.jsonl"
        timestamp = ""
        if jsonl_path.exists():
            try:
                with open(jsonl_path) as f:
                    first_line = f.readline()
                    if first_line.strip():
                        first_evt = json.loads(first_line)
                        timestamp = first_evt.get("timestamp", "")
            except (json.JSONDecodeError, OSError):
                pass

        key = (desc, agent_type)
        if key not in index:
            index[key] = []
        index[key].append((agent_id, timestamp))

    # Sort each group by timestamp so positional matching works
    for key in index:
        index[key].sort(key=lambda x: x[1])

    return index


def discover_unlinked_agents(
    events: list[SessionEvent],
    linked: dict[str, str],
    session_jsonl_path: str,
) -> dict[str, str]:
    """Find agentId mappings for Agent tool_use blocks not in ``linked``.

    Scans meta.json files in the session's subagents/ directory and matches
    by (description, agentType).  When multiple agents share the same
    (description, agentType), disambiguation uses the closest timestamp
    between the tool_use event and the subagent's first JSONL event.

    Returns a dict of newly discovered tool_use_id → agentId mappings.
    """
    session_path = Path(session_jsonl_path)
    subagents_dir = session_path.parent / session_path.stem / "subagents"
    if not subagents_dir.is_dir():
        return {}

    meta_index = build_meta_index(subagents_dir)
    if not meta_index:
        return {}

    # Collect unlinked Agent tool_use blocks with their descriptions + timestamps
    unlinked: list[tuple[str, str, str, str]] = []  # (tool_use_id, desc, type, ts)
    for evt in events:
        if evt.type != EventType.ASSISTANT or not evt.message:
            continue
        content = evt.message.content
        if not isinstance(content, list):
            continue
        for block in content:
            if not hasattr(block, "type") or block.type != "tool_use":
                continue
            if not hasattr(block, "name") or block.name != "Agent":
                continue
            if not block.id or block.id in linked:
                continue
            inp = block.input or {}
            desc = inp.get("description", "")
            agent_type = inp.get("subagent_type", "")
            unlinked.append((block.id, desc, agent_type, evt.timestamp or ""))

    # Match each unlinked agent to the meta index
    new_links: dict[str, str] = {}
    for tool_use_id, desc, agent_type, event_ts in unlinked:
        key = (desc, agent_type)
        candidates = meta_index.get(key)
        # When subagent_type is empty (Claude Code omits it), try matching
        # by description alone across all agentTypes in the index.
        if not candidates and not agent_type:
            for (idx_desc, idx_type), idx_candidates in meta_index.items():
                if idx_desc == desc and idx_candidates:
                    candidates = idx_candidates
                    break
        if not candidates:
            continue
        if len(candidates) == 1:
            agent_id, _ = candidates.pop(0)
            new_links[tool_use_id] = agent_id
        else:
            # Disambiguate by closest timestamp
            best_idx = _closest_timestamp_idx(candidates, event_ts)
            agent_id, _ = candidates.pop(best_idx)
            new_links[tool_use_id] = agent_id

    return new_links


def _closest_timestamp_idx(
    candidates: list[tuple[str, str]], event_ts: str,
) -> int:
    """Return the index of the candidate whose timestamp is closest to event_ts."""
    if not event_ts:
        return 0
    try:
        target = datetime.fromisoformat(event_ts.replace("Z", "+00:00"))
    except ValueError:
        return 0
    best_idx = 0
    best_diff = float("inf")
    for i, (_, ts) in enumerate(candidates):
        if not ts:
            continue
        try:
            candidate_dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            diff = abs((candidate_dt - target).total_seconds())
            if diff < best_diff:
                best_diff = diff
                best_idx = i
        except ValueError:
            continue
    return best_idx


def resolve_subagent_path(
    agent_id: str,
    session_jsonl_path: str,
) -> Path | None:
    """Resolve an agentId to its subagent JSONL file path.

    Args:
        agent_id: The agentId hash (e.g., "abc123def456")
        session_jsonl_path: Path to the primary session's JSONL file

    Returns:
        Path to the subagent JSONL if found, None otherwise.
    """
    session_path = Path(session_jsonl_path)
    session_uuid = session_path.stem
    project_dir = session_path.parent

    subagent_file = project_dir / session_uuid / "subagents" / f"agent-{agent_id}.jsonl"
    if subagent_file.exists():
        return subagent_file

    return None


def find_teammate_references(events: list[SessionEvent]) -> set[str]:
    """Distinct teammate_ids referenced in <teammate-message> tags across events.

    Only scans user-message events whose `content` is a string (teammate
    messages never appear in content-array form).
    """
    names: set[str] = set()
    for evt in events:
        if evt.type != EventType.USER:
            continue
        if evt.message is None:
            continue
        content = evt.message.content
        if not isinstance(content, str):
            continue
        if not contains_teammate_message(content):
            continue
        for block in parse_teammate_messages(content):
            names.add(block.teammate_id)
    return names


def resolve_teammate_paths(
    teammate_name: str,
    session_jsonl_path: str,
) -> list[Path]:
    """List of teammate JSONL turn files for the given teammate name.

    Searches the session's subagents/ dir for teammate files.
    Returned paths are sorted by mtime (oldest first).
    """
    session_path = Path(session_jsonl_path)
    session_uuid = session_path.stem
    project_dir = session_path.parent
    parent_session_dir = project_dir / session_uuid

    grouped = find_teammate_sessions(parent_session_dir)
    if teammate_name in grouped:
        return grouped[teammate_name]

    return []
