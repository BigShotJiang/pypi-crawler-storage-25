"""Per-turn active agent tracking — subagents, teammates, tasks.

Scans the event stream and tracks which agents/tasks were active at each
turn by following tool_use → tool_result spans.

Data flow:

    events → build_active_agents_map → dict[event.uuid, ActiveAgentsSnapshot]
                                              │
                                              ▼
    TreeNode (rendering) → lookup by uuid → ActiveAgentsSnapshot | None
                                              │
                                              ├─ format column text → "🤖sub1 +2"
                                              │
                                              └─ snap.task_ids → collect_task_events()
                                                                        │
                                                                        ▼
                                                    dict[task_id, TaskEventInfo]
                                                                        │
                                                                        ▼
                                                                 TasksScreen modal

    ActiveTaskRef: frozen value object preserving task identity (id + subject).
    TaskEventInfo: full resolved task data (creation input, status history,
                   turn context, agent model) for the tasks modal detail pane.

Span tracking:
  - Agent tool_use (block.id) → opens a span (agent becomes "active")
  - Agent tool_result (block.tool_use_id) → closes the span
  - Open spans (no matching result — session interrupted) stay active
    through the end of the session (correct semantic)
  - TaskCreate/TaskUpdate/SendMessage/TeamCreate tool_use blocks are
    noted per-event (point events, not spans)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field

from .model import EventType, SessionEvent

logger = logging.getLogger("cctree.active_agents")


@dataclass(frozen=True)
class ActiveTaskRef:
    """Identity-preserving reference to an active task.

    Stored in ActiveAgentsSnapshot.tasks so downstream consumers
    (status line, badge, tasks modal) can resolve task IDs back to
    their creation events without a lossy list[str] projection.
    """

    id: str
    subject: str


@dataclass
class ActiveAgentsSnapshot:
    """What agents/tasks/teams were active at a given turn."""

    subagents: list[str] = field(default_factory=list)
    teammates: list[str] = field(default_factory=list)
    tasks: list[ActiveTaskRef] = field(default_factory=list)
    pending_questions: list[str] = field(default_factory=list)

    @property
    def is_empty(self) -> bool:
        return (not self.subagents and not self.teammates
                and not self.tasks and not self.pending_questions)

    @property
    def task_ids(self) -> list[str]:
        return [t.id for t in self.tasks]

    @property
    def task_subjects(self) -> list[str]:
        return [t.subject for t in self.tasks]


def build_active_agents_map(
    events: list[SessionEvent],
) -> dict[str, ActiveAgentsSnapshot]:
    """Build UUID→ActiveAgentsSnapshot for a session's event stream.

    Tracks Agent tool_use→tool_result spans to determine which subagents
    were running at each turn. Also notes TaskCreate/TaskUpdate and
    SendMessage/TeamCreate as point events.
    """
    # Active Agent spans: tool_use_id → description
    open_agents: dict[str, str] = {}
    # Active tasks: task_id → ActiveTaskRef
    task_map: dict[str, ActiveTaskRef] = {}
    # Open AskUserQuestion spans: tool_use_id → question text
    open_questions: dict[str, str] = {}
    ctx_map: dict[str, ActiveAgentsSnapshot] = {}

    for evt in events:
        if evt.type not in (EventType.USER, EventType.ASSISTANT):
            continue
        if evt.message is None or not isinstance(evt.message.content, list):
            # User events or events with no structured content — snapshot current state
            if evt.uuid and (open_agents or task_map or open_questions):
                ctx_map[evt.uuid] = ActiveAgentsSnapshot(
                    subagents=list(open_agents.values()),
                    tasks=list(task_map.values()),
                    pending_questions=list(open_questions.values()),
                )
            continue

        turn_teammates: list[str] = []

        for block in evt.message.content:
            if not hasattr(block, "type"):
                continue

            if block.type == "tool_use" and block.name == "Agent":
                # Open a new agent span
                if block.id:
                    desc = (block.input or {}).get("description", "")[:30]
                    open_agents[block.id] = desc

            elif block.type == "tool_use" and block.name == "SendMessage":
                to = (block.input or {}).get("to", "")[:20]
                if to:
                    turn_teammates.append(to)

            elif block.type == "tool_use" and block.name == "TaskCreate":
                subj = (block.input or {}).get("subject", "")[:20]
                explicit_id = (block.input or {}).get("id", "")
                key = explicit_id or block.id or ""
                if key:
                    task_map[key] = ActiveTaskRef(id=key, subject=subj or "task")

            elif block.type == "tool_use" and block.name == "TaskUpdate":
                tid = (block.input or {}).get("taskId", "")
                status = (block.input or {}).get("status", "")
                if tid and status in ("deleted", "completed"):
                    task_map.pop(tid, None)

            elif block.type == "tool_use" and block.name == "AskUserQuestion":
                if block.id:
                    q = (block.input or {}).get("question", "")[:30]
                    open_questions[block.id] = q or "question"

            elif block.type == "tool_use" and block.name in (
                "TeamCreate", "TeamDelete",
            ):
                team = (block.input or {}).get("team_name", "")[:20]
                if team:
                    turn_teammates.append(team)

            elif block.type == "tool_result" and block.tool_use_id:
                if block.tool_use_id in open_agents:
                    del open_agents[block.tool_use_id]
                if block.tool_use_id in open_questions:
                    del open_questions[block.tool_use_id]

        # Snapshot active state for this event
        if evt.uuid:
            snap = ActiveAgentsSnapshot(
                subagents=list(open_agents.values()),
                teammates=turn_teammates,
                tasks=list(task_map.values()),
                pending_questions=list(open_questions.values()),
            )
            if not snap.is_empty:
                ctx_map[evt.uuid] = snap

    return ctx_map


@dataclass
class TaskStatusChange:
    """A single status transition for a task."""

    old_status: str
    new_status: str
    turn_text: str  # user message text at the turn where this happened


@dataclass
class TaskEventInfo:
    """Full resolved data for a single task, collected from the event stream.

    Data flow:
        session events → collect_task_events() → dict[task_id, TaskEventInfo]
                                                        │
                                                        ▼
                                                 TasksScreen detail pane
    """

    task_id: str
    subject: str
    description: str | None = None
    status: str = "pending"  # final status after all updates
    blocks: list[str] = field(default_factory=list)
    blocked_by: list[str] = field(default_factory=list)
    create_input: dict | None = None  # full TaskCreate tool_use input
    create_block_id: str | None = None  # tool_use block ID for jump-to-source
    create_turn_text: str | None = None  # user message that triggered creation
    agent_model: str | None = None  # model ID from assistant message
    status_changes: list[TaskStatusChange] = field(default_factory=list)


def collect_task_events(
    events: list[SessionEvent],
    task_ids: set[str],
) -> dict[str, TaskEventInfo]:
    """Walk events and collect full data for specified tasks.

    Returns task_id → TaskEventInfo for each task found in the stream.
    Tasks not found (e.g. created before compaction) are omitted.
    """
    result: dict[str, TaskEventInfo] = {}
    # Track the most recent user message text for turn context
    last_user_text: str = ""
    # Track current status per task for computing transitions
    current_status: dict[str, str] = {}

    for evt in events:
        if evt.type not in (EventType.USER, EventType.ASSISTANT):
            continue

        # Track user turn text
        if evt.type == EventType.USER:
            if evt.message and isinstance(evt.message.content, str):
                last_user_text = evt.message.content[:80]
            elif evt.message and isinstance(evt.message.content, list):
                for block in evt.message.content:
                    if hasattr(block, "type") and block.type == "text" and block.text:
                        last_user_text = block.text[:80]
                        break
            continue

        if evt.message is None or not isinstance(evt.message.content, list):
            continue

        agent_model = getattr(evt.message, "model", None)

        for block in evt.message.content:
            if not hasattr(block, "type") or block.type != "tool_use":
                continue

            if block.name == "TaskCreate":
                inp = block.input or {}
                explicit_id = inp.get("id", "")
                key = explicit_id or block.id or ""
                if key and key in task_ids:
                    subj = inp.get("subject", "")
                    desc = inp.get("description")
                    blocks = inp.get("blocks", [])
                    blocked_by = inp.get("blockedBy", [])
                    result[key] = TaskEventInfo(
                        task_id=key,
                        subject=subj,
                        description=desc,
                        status="pending",
                        blocks=blocks if isinstance(blocks, list) else [],
                        blocked_by=blocked_by if isinstance(blocked_by, list) else [],
                        create_input=inp,
                        create_block_id=block.id,
                        create_turn_text=last_user_text,
                        agent_model=agent_model,
                    )
                    current_status[key] = "pending"

            elif block.name == "TaskUpdate":
                inp = block.input or {}
                tid = inp.get("taskId", "")
                new_status = inp.get("status", "")
                if tid and tid in result and new_status:
                    old = current_status.get(tid, "pending")
                    result[tid].status_changes.append(
                        TaskStatusChange(
                            old_status=old,
                            new_status=new_status,
                            turn_text=last_user_text,
                        )
                    )
                    result[tid].status = new_status
                    current_status[tid] = new_status

    return result


def format_agents_status_line(snap: ActiveAgentsSnapshot | None) -> str:
    """Format agent snapshot for status bar drill-down.

    Returns a Rich-markup line like '📋 3 tasks: Fix auth, Add tests, Refactor DB · 🤖 research code'
    or '' if no annotations.
    """
    if snap is None or snap.is_empty:
        return ""
    parts: list[str] = []
    if snap.tasks:
        task_list = ", ".join(snap.task_subjects[:5])
        suffix = f" +{len(snap.tasks) - 5}" if len(snap.tasks) > 5 else ""
        parts.append(f"📋 {len(snap.tasks)} tasks: {task_list}{suffix}")
    if snap.subagents:
        agent_list = ", ".join(snap.subagents[:3])
        suffix = f" +{len(snap.subagents) - 3}" if len(snap.subagents) > 3 else ""
        parts.append(f"🤖 {agent_list}{suffix}")
    if snap.teammates:
        tm_list = ", ".join(snap.teammates[:3])
        parts.append(f"👥 {tm_list}")
    if snap.pending_questions:
        parts.append(f"❓ {len(snap.pending_questions)} pending")
    return " · ".join(parts)
