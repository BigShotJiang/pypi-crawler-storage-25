"""cctree - Claude Code session browser, history navigator, and fork tool."""

__version__ = "0.5.1"
