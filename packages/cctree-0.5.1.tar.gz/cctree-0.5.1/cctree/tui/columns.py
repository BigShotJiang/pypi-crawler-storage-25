"""Column rendering helpers for annotated tree labels."""
from __future__ import annotations

import re

from rich.cells import cell_len as _cell_len
def _escape_markup(text: str) -> str:
    """Escape ALL ``[`` for Textual's Content.from_markup().

    ``rich.markup.escape()`` only escapes lowercase-tag-like sequences
    (``[bold]``, ``[/]``, etc.) but Textual's parser is stricter — it
    treats *any* ``[...]`` as a potential tag.  A simple replacement
    of every ``[`` is both correct and sufficient.
    """
    return text.replace("[", "\\[")

from ..core.active_agents import ActiveAgentsSnapshot
from ..core.model import ContentBlock, EventType, SessionEvent

# ─── Key-arg extraction keys (shared by tool labels + summary) ─────────────
_KEY_ARG_KEYS = (
    "to", "team_name", "file_path", "command", "pattern",
    "query", "prompt", "description", "skill",
)


def _tool_preview(block: ContentBlock) -> str:
    """Format a tool_use block as 'ToolName(key_arg)' for summaries.

    Returns e.g. 'Read(main.py)', 'Agent("fix tests")', 'Bash'.
    Shared by tool node labels and the collapsed-node tool summary.
    """
    name = block.name or "?"
    if name == "Agent":
        desc = (block.input or {}).get("description", "")[:25]
        return f"Agent(\"{desc}\")" if desc else "Agent"
    if block.input:
        for k in _KEY_ARG_KEYS:
            if k in block.input:
                val = str(block.input[k])[:20]
                return f"{name}({val})"
    return name


def _collect_turn_tools(events: list[SessionEvent]) -> list[str]:
    """Collect tool preview strings from assistant events in a turn (bubble-up)."""
    tools: list[str] = []
    for evt in events:
        if evt.type != EventType.ASSISTANT:
            continue
        if evt.message is None or not isinstance(evt.message.content, list):
            continue
        for block in evt.message.content:
            if hasattr(block, "type") and block.type == "tool_use":
                tools.append(_tool_preview(block))
    return tools


def _format_tool_summary(tools: list[str], max_shown: int = 3) -> str:
    """Format tool previews as comma-separated summary with truncation.

    Returns e.g. 'Read,Edit,Bash' or 'Read,Edit +4'.
    """
    if not tools:
        return ""
    if len(tools) <= max_shown:
        return ",".join(tools)
    shown = ",".join(tools[:max_shown - 1])
    return f"{shown} +{len(tools) - max_shown + 1}"


def _format_badge(icon: str, count: int) -> str:
    """Format an icon+count badge for annotation columns.

    Returns e.g. '📷3' or '' (empty when count is 0).
    """
    if count == 0:
        return ""
    return f"{icon}{count}"


def _format_tool_count(tools: list[str]) -> str:
    """Format tool count badge. Thin wrapper over _format_badge."""
    return _format_badge("🔧", len(tools))


def _format_image_col(count: int) -> str:
    """Format image count badge. Thin wrapper over _format_badge."""
    return _format_badge("📷", count)


def _highlight_term(
    text: str,
    term: str,
    markup: str = "reverse",
) -> str:
    """Wrap all case-insensitive occurrences of *term* in Rich markup.

    Returns *text* unchanged if *term* is empty or not found.
    Uses ``re.escape`` on *term* so regex special chars are safe.
    """
    if not term or not text:
        return text
    pattern = re.escape(term)
    return re.sub(f"({pattern})", rf"[{markup}]\1[/{markup}]", text, flags=re.IGNORECASE)


def _strip_markup(markup: str) -> str:
    """Strip Rich markup tags, correctly handling ``\\[`` escape sequences.

    Rich uses ``\\[`` to represent a literal ``[`` in markup strings.
    This function removes actual tags like ``[bold]`` while preserving
    escaped brackets as visible ``[`` characters.
    """
    # Temporarily replace Rich's \[ escape with a placeholder
    replaced = markup.replace("\\[", "\x00")
    # Strip actual markup tags
    stripped = re.sub(r"\[/?[^\]]*\]", "", replaced)
    # Restore escaped brackets as literal [
    return stripped.replace("\x00", "[")


def _visual_len(markup: str) -> int:
    """Visible terminal column count after stripping Rich markup tags.

    Uses Rich's cell_len to correctly handle double-width characters
    (emojis, CJK) that occupy 2 terminal columns per codepoint.
    """
    return _cell_len(_strip_markup(markup))


def _label_width_for_depth(tree_width: int, depth: int) -> int:
    """Available columns for an annotated label at a given tree depth.

    The Textual Tree widget indents each level by 4 characters plus a
    4-character guide/connector prefix.  Callers must use this to avoid
    laying out labels wider than the visible area.
    """
    indent = depth * 4 + 4
    return max(1, tree_width - indent)


_IMAGE_COL_BUDGET = 5       # fixed width for image badge column
_TOOL_COL_BUDGET = 6        # fixed width for tool badge column
_TASKS_COL_BUDGET = 5       # fixed width for tasks badge column
_SUBAGENTS_COL_BUDGET = 5   # fixed width for subagents badge column
_QUESTIONS_COL_BUDGET = 4   # fixed width for questions badge column


def _pad_to_budget(text: str, budget: int) -> str:
    """Pad a column string to a fixed visual width."""
    vis = _visual_len(text)
    pad = max(0, budget - vis)
    return text + " " * pad


def _fit_to_budget(text: str, budget: int) -> str:
    """Truncate-and-pad to enforce a hard visual width limit.

    If *text* fits within *budget* terminal columns it is right-padded.
    If it overflows, characters are removed from the right and replaced
    with ``…`` so the result is exactly *budget* columns wide.
    """
    vis = _visual_len(text)
    if vis <= budget:
        pad = budget - vis
        return text + " " * pad
    # Truncate: walk codepoints, accumulating cell width
    stripped = _strip_markup(text)
    result: list[str] = []
    width = 0
    for ch in stripped:
        cw = _cell_len(ch)
        if width + cw > budget - 1:  # reserve 1 col for …
            break
        result.append(ch)
        width += cw
    # Pad to exact budget (… is 1 cell wide)
    return "".join(result) + "…" + " " * (budget - width - 1)


_HIGHLIGHT_RE = re.compile(r"\[reverse\](.*?)\[/reverse\]", re.DOTALL)


def _truncate_preserving_highlights(content: str, content_max: int) -> str:
    """Truncate *content* to *content_max* visual cells, preserving [reverse] spans.

    Splits on ``[reverse]...[/reverse]`` boundaries so that highlighted
    segments survive truncation.  Non-highlighted portions are
    ``_escape_markup``'d; highlighted portions are re-wrapped.
    ``[dim]`` outer wrappers are preserved.
    """
    dim_wrap = content.startswith("[dim]")
    inner = content[5:-6] if dim_wrap else content  # strip [dim]...[/dim]

    # Split into alternating (non-highlighted, highlighted) segments
    parts = _HIGHLIGHT_RE.split(inner)
    # parts layout: [before, hl_1, between, hl_2, ..., after]

    budget = content_max - 1  # reserve 1 col for …
    segments: list[tuple[str, bool]] = []
    w = 0
    done = False

    for i, part in enumerate(parts):
        if done:
            break
        is_hl = i % 2 == 1
        plain = _strip_markup(part) if not is_hl else part
        chars: list[str] = []
        for ch in plain:
            cw = _cell_len(ch)
            if w + cw > budget:
                done = True
                break
            chars.append(ch)
            w += cw
        if chars:
            segments.append(("".join(chars), is_hl))

    # Rebuild with escaping + highlight tags
    out_parts: list[str] = []
    for text, is_hl in segments:
        escaped = _escape_markup(text)
        if is_hl:
            out_parts.append(f"[reverse]{escaped}[/reverse]")
        else:
            out_parts.append(escaped)

    truncated = "".join(out_parts) + "…"
    if dim_wrap:
        return f"[dim]{truncated}[/dim]"
    return truncated


def _compose_annotated_label(
    content: str,
    tool_summary: str,
    ctx_bar: str,
    total_width: int,
    *,
    image_col: str = "",
    tasks_col: str = "",
    subagents_col: str = "",
    questions_col: str = "",
    highlight_col: str | None = None,
) -> str:
    """Build a tree label with right-aligned annotation columns.

    Each column reserves a fixed visual budget so columns align
    vertically across all tree rows at the same depth, regardless
    of whether individual cells are shorter than their budget.

    Column order: 📷 🔧 📋 🤖 ❓ ████
    Responsive: hide columns as width shrinks.

    ``highlight_col`` wraps the named column in [reverse] for Tab-cycling.

    All user-controlled strings must be _escape_markup'd before passing in.
    """

    def _maybe_highlight(text: str, col_id: str) -> str:
        if highlight_col == col_id:
            return f"[reverse]{text}[/reverse]"
        return text

    # Independent columns: only shown when non-empty
    indep_cols = [
        (image_col,      _IMAGE_COL_BUDGET,      "image",    40, False),
        (tool_summary,   _TOOL_COL_BUDGET,        "tool",     40, True),
    ]
    # Grouped agent columns: if ANY is present, ALL reserve space
    agent_cols = [
        (tasks_col,      _TASKS_COL_BUDGET,        "task",     False),
        (subagents_col,  _SUBAGENTS_COL_BUDGET,    "subagent", False),
        (questions_col,  _QUESTIONS_COL_BUDGET,    "question", False),
    ]
    any_agent = total_width >= 80 and any(
        t for t, _, _, _ in agent_cols
    )

    cols: list[str] = []
    for col_text, budget, col_id, min_w, dim in indep_cols:
        if total_width >= min_w and col_text:
            fitted = _fit_to_budget(col_text, budget)
            if dim:
                fitted = f"[dim]{fitted}[/dim]"
            cols.append(_maybe_highlight(fitted, col_id))
    if any_agent:
        for col_text, budget, col_id, dim in agent_cols:
            if col_text:
                fitted = _fit_to_budget(col_text, budget)
            else:
                fitted = " " * budget
            if dim:
                fitted = f"[dim]{fitted}[/dim]"
            cols.append(_maybe_highlight(fitted, col_id))
    if total_width >= 60 and ctx_bar:
        cols.append(_maybe_highlight(ctx_bar, "context"))

    if not cols:
        return content

    right = "  ".join(cols)
    right_vis = _visual_len(right)

    # Max content width: total minus columns minus at least 1 gap char
    content_max = max(1, total_width - right_vis - 1)
    content_vis_len = _visual_len(content)

    if content_vis_len > content_max:
        content = _truncate_preserving_highlights(content, content_max)

    # Unified gap: right-align columns at fixed position from right edge
    gap = max(1, total_width - _visual_len(content) - right_vis)

    return f"{content}{' ' * gap}{right}"
