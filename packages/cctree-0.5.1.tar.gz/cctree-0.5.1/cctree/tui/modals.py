"""Modal screen widgets (search overlay, input prompt, tasks detail)."""
from __future__ import annotations

import json
import os
from datetime import datetime
from typing import NamedTuple

from .columns import _escape_markup
from textual.app import ComposeResult
from textual.binding import Binding
from textual.events import Click
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Input, Label, ListItem, ListView, Static
from textual.containers import Horizontal, Vertical, VerticalScroll

from ..core.active_agents import TaskEventInfo
from ..core.store import SessionStore
from .columns import _highlight_term


# ─── Column layout constants ────────────────────────────────────────────────

_COL_TYPE = 7
_COL_NAME = 12
_COL_STARTED = 9
_COL_ACTIVE = 9
_COL_MSGS = 4
_COL_SIZE = 5
_SEP = "  "

_SORTABLE_COLUMNS = ["type", "name", "started", "active", "msgs", "size"]

# Column definitions: (id, width, align)
_COLUMNS = [
    ("type", _COL_TYPE, "<"),
    ("name", _COL_NAME, "<"),
    ("started", _COL_STARTED, "<"),
    ("active", _COL_ACTIVE, "<"),
    ("msgs", _COL_MSGS, ">"),
    ("size", _COL_SIZE, ">"),
]


class SearchMatch(NamedTuple):
    """Raw search result data for sorting and display."""

    type_str: str
    display_name: str
    started_at: datetime | None
    last_activity_at: datetime | None
    message_count: int
    file_size: int  # raw bytes, -1 on error
    context_markup: str
    session_uuid: str
    msg_uuid: str


def _format_date(dt):
    """Format datetime as 'MM/DD HHh' in local time. Returns '-' if None."""
    if dt is None:
        return "-"
    if dt.tzinfo is not None:
        dt = dt.astimezone()
    return dt.strftime("%m/%d %Hh")


def _format_file_size_from_bytes(size: int) -> str:
    """Format byte count as human-readable, e.g. '1.2M', '340K'."""
    if size < 0:
        return "-"
    if size < 1024:
        return f"{size}B"
    elif size < 1024 * 1024:
        return f"{size // 1024}K"
    else:
        mb = size / (1024 * 1024)
        if mb >= 100:
            return f"{int(mb)}M"
        return f"{mb:.1f}M"


def _format_file_size(path: str) -> str:
    """Format file size as human-readable, e.g. '1.2M', '340K'."""
    try:
        size = os.path.getsize(path)
    except OSError:
        return "-"
    return _format_file_size_from_bytes(size)


def _truncate(text: str, width: int) -> str:
    """Truncate text to width with trailing ellipsis."""
    if len(text) <= width:
        return text
    if width <= 1:
        return "\u2026"
    return text[: width - 1] + "\u2026"


def _x_to_column(x: int) -> str | None:
    """Map an x-coordinate to a sortable column name, or None."""
    pos = 0
    for col_id, col_width, _ in _COLUMNS:
        if pos <= x < pos + col_width:
            return col_id
        pos += col_width + len(_SEP)
    return None


def _sort_key(match: SearchMatch, column: str):
    """Return a sortable key for the given column. None datetimes sort last."""
    if column == "type":
        return match.type_str
    elif column == "name":
        return match.display_name.lower()
    elif column == "started":
        return (match.started_at is None, match.started_at or datetime.min)
    elif column == "active":
        return (match.last_activity_at is None, match.last_activity_at or datetime.min)
    elif column == "msgs":
        return match.message_count
    elif column == "size":
        return (match.file_size < 0, match.file_size)
    return 0


def _format_match_label(match: SearchMatch) -> str:
    """Format a SearchMatch into a fixed-width columnar label string."""
    name_padded = f"{_truncate(match.display_name, _COL_NAME):<{_COL_NAME}}"
    return (
        f"{match.type_str:<{_COL_TYPE}}{_SEP}"
        f"{_escape_markup(name_padded)}{_SEP}"
        f"{_format_date(match.started_at):<{_COL_STARTED}}{_SEP}"
        f"{_format_date(match.last_activity_at):<{_COL_ACTIVE}}{_SEP}"
        f"{match.message_count:>{_COL_MSGS}}{_SEP}"
        f"{_format_file_size_from_bytes(match.file_size):>{_COL_SIZE}}{_SEP}"
        f"{match.context_markup}"
    )


def _build_header(sort_column: str | None = None, sort_ascending: bool = False) -> str:
    """Build the bold header row, with ▲/▼ on the active sort column."""
    _LABELS = {"type": "TYPE", "name": "NAME", "started": "STARTED",
               "active": "ACTIVE", "msgs": "MSGS", "size": "SIZE"}
    parts = []
    for col_id, col_width, align in _COLUMNS:
        label = _LABELS[col_id]
        if sort_column == col_id:
            indicator = "\u25b2" if sort_ascending else "\u25bc"
            label = label + indicator
        if align == ">":
            parts.append(f"{label:>{col_width}}")
        else:
            parts.append(f"{label:<{col_width}}")
    row = _SEP.join(parts) + f"{_SEP}CONTEXT"
    return f"[bold]{row}[/bold]"


class SortableHeader(Static):
    """Clickable column header that emits sort requests."""

    class ColumnClicked(Message):
        """Posted when a sortable column header is clicked."""

        def __init__(self, column: str) -> None:
            super().__init__()
            self.column = column

    def on_click(self, event: Click) -> None:
        # Adjust for 2-char left padding on #search-header
        adjusted_x = event.x - 2
        col = _x_to_column(adjusted_x)
        if col is not None:
            self.post_message(self.ColumnClicked(col))
        event.stop()


class SearchScreen(ModalScreen[str | None]):
    """Search overlay — type a query, see matching sessions + messages."""

    BINDINGS = [
        Binding("escape", "dismiss(None)", "Close"),
        Binding("s", "cycle_sort", "Sort", show=False),
        Binding("S", "cycle_sort", "Sort"),
    ]

    def __init__(self, store: SessionStore) -> None:
        super().__init__()
        self.store = store
        self._search_timer = None
        self._last_query: str = ""
        self._sort_column: str | None = "active"
        self._sort_ascending: bool = False
        self._cached_matches: list[SearchMatch] = []
        self._original_matches: list[SearchMatch] = []

    def compose(self) -> ComposeResult:
        yield Vertical(
            Input(placeholder="Search sessions (text, slug, UUID)...", id="search-input"),
            Static("", id="search-status", markup=True),
            SortableHeader("", id="search-header", markup=True),
            ListView(id="search-results"),
            id="search-container",
        )

    def on_mount(self) -> None:
        self.query_one("#search-input", Input).focus()
        self.query_one("#search-status", Static).display = False
        self.query_one("#search-header", SortableHeader).display = False

    def on_click(self, event: Click) -> None:
        """Disable mouse click selection in search overlay."""
        event.prevent_default()
        event.stop()

    def on_key(self, event) -> None:
        """Down arrow from input → results. Up arrow from results → input."""
        search_input = self.query_one("#search-input", Input)
        results = self.query_one("#search-results", ListView)

        if event.key == "down" and search_input.has_focus:
            if len(results.children) > 0:
                results.focus()
                results.index = 0
                event.prevent_default()
        elif event.key == "up" and results.has_focus:
            if results.index == 0 or results.index is None:
                search_input.focus()
                event.prevent_default()

    def on_input_changed(self, event: Input.Changed) -> None:
        """Debounce search — wait 300ms after last keystroke before searching."""
        if self._search_timer is not None:
            self._search_timer.stop()
        query = event.value.strip()
        results = self.query_one("#search-results", ListView)
        header = self.query_one("#search-header", SortableHeader)
        results.clear()
        header.display = False
        self._cached_matches = []
        self._original_matches = []

        if len(query) < 2:
            self._last_query = ""
            self._set_search_status(None)
            return
        self._last_query = query
        self._set_search_status(f"[dim]Searching for '{_escape_markup(query)}'...[/dim]")
        self._search_timer = self.set_timer(0.3, lambda: self._do_search(query))

    def _set_search_status(self, message: str | None) -> None:
        """Show or hide the one-line status for the current search."""
        status = self.query_one("#search-status", Static)
        if message is None:
            status.update("")
            status.display = False
            return
        status.update(message)
        status.display = True

    def _build_matches(self, query: str) -> list[tuple[str, str, str]]:
        """Build the list of (label, session_uuid, msg_uuid) matches.

        Each label is a fixed-width columnar row:
        TYPE  NAME  STARTED  ACTIVE  MSGS  SIZE  CONTEXT
        """
        return [
            (_format_match_label(m), m.session_uuid, m.msg_uuid)
            for m in self._collect_matches(query)
        ]

    def _collect_matches(self, query: str) -> list[SearchMatch]:
        """Build the list of SearchMatch results for sorting and display."""
        query_lower = query.lower()
        escaped_query = _escape_markup(query)
        matches: list[SearchMatch] = []

        for session in self.store.sessions.values():
            type_str = ""
            context = ""
            msg_uuid = ""

            if session.uuid.lower().startswith(query_lower):
                type_str = "uuid"
                ctx = _highlight_term(
                    _escape_markup(session.uuid[:12]), escaped_query, markup="reverse",
                )
                context = ctx
            elif session.slug and query_lower in session.slug.lower():
                type_str = "slug"
                ctx = _highlight_term(
                    _escape_markup(session.slug), escaped_query, markup="reverse",
                )
                context = ctx
            elif session.custom_title and query_lower in session.custom_title.lower():
                type_str = "title"
                ctx = _highlight_term(
                    _escape_markup(session.custom_title), escaped_query, markup="reverse",
                )
                context = ctx
            else:
                for evt in session.events:
                    if evt.is_message:
                        text = evt.text_content.lower()
                        idx = text.find(query_lower)
                        if idx >= 0:
                            start = max(0, idx - 60)
                            end = min(len(text), idx + len(query_lower) + 60)
                            excerpt = evt.text_content[start:end].replace("\n", " ")
                            safe_excerpt = _escape_markup(excerpt)
                            highlighted = _highlight_term(
                                safe_excerpt, escaped_query, markup="reverse",
                            )
                            type_str = "content"
                            context = f"...{highlighted}..."
                            msg_uuid = evt.uuid or ""
                            break

            if not type_str:
                continue

            try:
                file_size = os.path.getsize(session.path)
            except OSError:
                file_size = -1

            matches.append(SearchMatch(
                type_str=type_str,
                display_name=session.display_name,
                started_at=session.started_at,
                last_activity_at=session.last_activity_at,
                message_count=session.message_count,
                file_size=file_size,
                context_markup=context,
                session_uuid=session.uuid,
                msg_uuid=msg_uuid,
            ))

            if len(matches) >= 50:
                break

        return matches

    def _apply_sort_and_render(self) -> None:
        """Sort cached matches and repopulate the ListView."""
        results = self.query_one("#search-results", ListView)
        header = self.query_one("#search-header", SortableHeader)
        results.clear()

        if self._sort_column is not None:
            col = self._sort_column
            self._cached_matches = sorted(
                self._original_matches,
                key=lambda m: _sort_key(m, col),
                reverse=not self._sort_ascending,
            )
        else:
            self._cached_matches = list(self._original_matches)

        if self._cached_matches:
            header.update(_build_header(self._sort_column, self._sort_ascending))
            header.display = True
        else:
            header.display = False

        for match in self._cached_matches:
            label = _format_match_label(match)
            results.append(ListItem(
                Label(label, markup=True),
                name=f"{match.session_uuid}|{match.msg_uuid}",
            ))

    def _do_search(self, query: str) -> None:
        """Execute the actual search — called after debounce delay."""
        self._last_query = query
        self._cached_matches = self._collect_matches(query)
        self._original_matches = list(self._cached_matches)
        self._apply_sort_and_render()
        safe_query = _escape_markup(query)
        if self._cached_matches:
            count = len(self._cached_matches)
            noun = "match" if count == 1 else "matches"
            self._set_search_status(
                f"[dim]Showing {count} {noun} for '{safe_query}'[/dim]"
            )
        else:
            self._set_search_status(f"[yellow]No matches for '{safe_query}'[/yellow]")

    def on_sortable_header_column_clicked(self, event: SortableHeader.ColumnClicked) -> None:
        """Handle click on a sortable column header."""
        col = event.column
        if col == self._sort_column:
            if self._sort_ascending:
                self._sort_column = None
                self._sort_ascending = False
            else:
                self._sort_ascending = True
        else:
            self._sort_column = col
            self._sort_ascending = False
        self._apply_sort_and_render()

    def action_cycle_sort(self) -> None:
        """Cycle sort column: type → name → started → active → msgs → size → unsorted."""
        if not self._cached_matches:
            return
        if self._sort_column is None:
            self._sort_column = _SORTABLE_COLUMNS[0]
            self._sort_ascending = False
        else:
            idx = _SORTABLE_COLUMNS.index(self._sort_column)
            if idx + 1 < len(_SORTABLE_COLUMNS):
                self._sort_column = _SORTABLE_COLUMNS[idx + 1]
                self._sort_ascending = False
            else:
                self._sort_column = None
                self._sort_ascending = False
        self._apply_sort_and_render()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        name = event.item.name or ""
        # Append the search query as third field
        self.dismiss(f"{name}|{self._last_query}")


class InputModal(ModalScreen[str | None]):
    """Generic input modal — prompts for a string and returns it."""

    BINDINGS = [Binding("escape", "dismiss(None)", "Close")]

    def __init__(self, title: str, placeholder: str, default: str = "") -> None:
        super().__init__()
        self._title = title
        self._placeholder = placeholder
        self._default = default

    def compose(self) -> ComposeResult:
        yield Vertical(
            Label(self._title, id="input-modal-title"),
            Input(placeholder=self._placeholder, value=self._default, id="input-modal-field"),
            id="input-modal-container",
        )

    def on_mount(self) -> None:
        self.query_one("#input-modal-field", Input).focus()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        value = event.value.strip()
        self.dismiss(value if value else None)


# ─── Status indicators ──────────────────────────────────────────────────

_STATUS_DISPLAY = {
    "pending": ("○", "dim"),
    "in_progress": ("●", "yellow"),
    "completed": ("✓", "green"),
    "deleted": ("✗", "red"),
}


def _status_markup(status: str) -> str:
    """Format a task status with symbol + color."""
    symbol, color = _STATUS_DISPLAY.get(status, ("?", "dim"))
    return f"[{color}]{symbol} {status}[/{color}]"


def _format_task_detail(info: TaskEventInfo) -> str:
    """Build Rich markup for the task detail pane."""
    lines: list[str] = []

    # Subject + Status
    safe_subj = _escape_markup(info.subject or "(no subject)")
    lines.append(f"[bold]{safe_subj}[/bold]")
    if info.create_input is None and not info.status_changes:
        # Stub — no creation event found in transcript
        lines.append("Status: [dim]? (unknown)[/dim]")
    else:
        lines.append(f"Status: {_status_markup(info.status)}")

    # Description
    if info.description:
        lines.append("")
        lines.append(_escape_markup(info.description))

    # Blocks / Blocked by (only if present)
    if info.blocks:
        lines.append(f"Blocks: {', '.join(_escape_markup(b) for b in info.blocks)}")
    if info.blocked_by:
        lines.append(f"Blocked by: {', '.join(_escape_markup(b) for b in info.blocked_by)}")

    # Creation section
    lines.append("")
    lines.append("[dim]── Created ──────────────────────────[/dim]")
    if info.create_turn_text:
        safe_turn = _escape_markup(info.create_turn_text)
        lines.append(f'Turn: "{safe_turn}"')
    if info.agent_model:
        lines.append(f"Agent: {_escape_markup(info.agent_model)}")
    if info.create_input:
        inp = json.dumps(info.create_input, indent=2, ensure_ascii=False)
        lines.append(f"Input: {_escape_markup(inp)}")

    # Status changes
    if info.status_changes:
        lines.append("")
        lines.append("[dim]── Status Changes ───────────────────[/dim]")
        for change in info.status_changes:
            safe_turn = _escape_markup(change.turn_text) if change.turn_text else ""
            turn_ctx = f'  at "{safe_turn}"' if safe_turn else ""
            lines.append(
                f"{_status_markup(change.old_status)} → "
                f"{_status_markup(change.new_status)}{turn_ctx}"
            )
    elif not info.create_input:
        # No creation event found — show warning
        lines.append("")
        lines.append(
            "[dim]Creation event not found in transcript.\n"
            "May be before compaction boundary.[/dim]"
        )

    return "\n".join(lines)


class TasksScreen(ModalScreen[str | None]):
    """Tasks detail modal — split pane with task list + detail view.

    Layout:
        ┌──────────────────────────────────────────────────┐
        │ 📋 N tasks at: "turn text"            ESC:close  │
        ├──────────────┬───────────────────────────────────┤
        │ TASKS (30%)  │ DETAIL (70%)                      │
        │ ► ● Fix auth │ Subject: Fix auth middleware      │
        │   ○ Add test │ Status: ● in_progress             │
        │              │ ...                                │
        ├──────────────┴───────────────────────────────────┤
        │ ↑↓:select  ENTER:jump to source  ESC:close       │
        └──────────────────────────────────────────────────┘

    Returns the tool_use block ID of the selected task on ENTER (for
    jump-to-source), or None on ESC.
    """

    BINDINGS = [
        Binding("escape", "dismiss(None)", "Close"),
        Binding("tab", "focus_next_pane", "Switch pane", priority=True),
    ]

    def __init__(
        self,
        task_infos: dict[str, TaskEventInfo],
        turn_label: str,
    ) -> None:
        super().__init__()
        self._task_infos = task_infos
        self._turn_label = turn_label
        # Ordered list of task IDs for stable iteration
        self._task_ids = list(task_infos.keys())

    def compose(self) -> ComposeResult:
        count = len(self._task_infos)
        safe_turn = _escape_markup(_truncate(self._turn_label, 50))
        header_text = f'📋 {count} task{"s" if count != 1 else ""} at: "{safe_turn}"'

        yield Vertical(
            Label(f"[bold]{header_text}[/bold]", id="tasks-header", markup=True),
            Horizontal(
                ListView(id="tasks-list"),
                VerticalScroll(
                    Static("", id="tasks-detail", markup=True),
                    id="tasks-detail-scroll",
                ),
                id="tasks-panes",
            ),
            Label(
                "[dim]↑↓:select  TAB:switch pane  ENTER:jump to source  ESC:close[/dim]",
                id="tasks-footer",
                markup=True,
            ),
            id="tasks-container",
        )

    def on_mount(self) -> None:
        # Populate task list
        task_list = self.query_one("#tasks-list", ListView)
        for tid in self._task_ids:
            info = self._task_infos[tid]
            symbol, color = _STATUS_DISPLAY.get(info.status, ("?", "dim"))
            safe_subj = _escape_markup(_truncate(info.subject or "(no subject)", 30))
            label = f"[{color}]{symbol}[/{color}] {safe_subj}"
            task_list.append(ListItem(
                Label(label, markup=True),
                name=tid,
            ))
        # Auto-select first task and ensure keyboard focus
        task_list.focus()
        if self._task_ids:
            task_list.index = 0
            self._show_detail(self._task_ids[0])

    def action_focus_next_pane(self) -> None:
        """Toggle focus between task list and detail pane."""
        task_list = self.query_one("#tasks-list", ListView)
        detail_scroll = self.query_one("#tasks-detail-scroll", VerticalScroll)
        if task_list.has_focus:
            detail_scroll.focus()
        else:
            task_list.focus()

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        if event.control.id != "tasks-list":
            return
        if event.item and event.item.name:
            self._show_detail(event.item.name)

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        """ENTER on a task → dismiss with block ID for jump-to-source."""
        if event.item and event.item.name:
            tid = event.item.name
            info = self._task_infos.get(tid)
            if info and info.create_block_id:
                self.dismiss(info.create_block_id)
            else:
                self.dismiss(None)

    def _show_detail(self, task_id: str) -> None:
        info = self._task_infos.get(task_id)
        detail = self.query_one("#tasks-detail", Static)
        if info:
            detail.update(_format_task_detail(info))
        else:
            detail.update("[dim]Task data not available.[/dim]")
