"""Standalone TUI widgets."""
from __future__ import annotations

from rich.text import Text
from textual.events import MouseDown, MouseMove, MouseUp
from textual.widgets import Static, Tree
from textual.widgets._tree import TreeNode, TOGGLE_STYLE


class AlignedTree(Tree):
    """Tree subclass that aligns leaf labels with expandable siblings.

    Textual's render_label() prepends ICON_NODE ('▶ ', 2 chars) for expandable
    nodes but '' for leaves, shifting leaf labels left.  This override pads
    leaf labels with 2 spaces so labels start at the same column.
    """

    def render_label(self, node: TreeNode, base_style, style) -> Text:
        node_label = node._label.copy()
        node_label.stylize(style)
        if node._allow_expand:
            prefix = (
                self.ICON_NODE_EXPANDED if node.is_expanded else self.ICON_NODE,
                base_style + TOGGLE_STYLE,
            )
        else:
            prefix = ("  ", base_style)  # 2-space pad matching toggle width
        return Text.assemble(prefix, node_label)


class DragHandle(Static):
    """Vertical drag handle for resizing the sessions/detail split."""

    DEFAULT_CSS = """
    DragHandle {
        width: 1;
        height: 100%;
        background: $primary-background;
    }
    DragHandle:hover {
        background: $accent;
    }
    """

    def __init__(self) -> None:
        super().__init__("┃", id="drag-handle")
        self._dragging = False

    def on_mouse_down(self, event: MouseDown) -> None:
        self._dragging = True
        self.capture_mouse()
        event.stop()

    def on_mouse_move(self, event: MouseMove) -> None:
        if self._dragging:
            self.app._resize_sessions_pane(event.screen_x)
            event.stop()

    def on_mouse_up(self, event: MouseUp) -> None:
        if self._dragging:
            self._dragging = False
            self.release_mouse()
            event.stop()
