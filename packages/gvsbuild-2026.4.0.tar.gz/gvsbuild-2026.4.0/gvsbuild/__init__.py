"""Build projects & tools lists."""
