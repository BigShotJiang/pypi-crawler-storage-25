//! orderpulse
//!
//! Ultra-fast market data parser and order book engine for Python.
//!
//! This module exposes Python classes for reading binary exchange feed files,
//! filtering order/trade messages, and building top-of-book snapshots.
//!
//! Main Python classes:
//!
//! - `ReadMsgFromBinary`: Parse binary files and query messages.
//! - `BinaryLoader`: Store parsed messages once and fetch next message.
//! - `OrderBookBuilder`: Build orderbook snapshots.
//!
//! Example:
//!
//! ```python
//! from orderpulse import ReadMsgFromBinary, BinaryLoader, OrderBookBuilder
//!
//! reader = ReadMsgFromBinary("market_data.bin", token=26000)
//! reader.summary()
//!
//! loader = BinaryLoader(reader)
//!
//! while True:
//!     msg = loader.get_next_message()
//!     if msg == "END":
//!         break
//!     print(msg)
//!
//! ob = OrderBookBuilder()
//! rows = ob.create_orderbook(reader)
//! print(rows)
//! ```

use pyo3::prelude::*;
use std::sync::Arc;

mod orderbook;
pub mod orderbook_processing;
mod read_trd_ord_only;
mod structure;
mod tsc;

use orderbook::OrderBookManager;
use read_trd_ord_only::read_messages;
use structure::Message;

fn format_message(msg: &Message) -> String {
    match msg {
        Message::Order(order_packet) => {
            let seq_no = order_packet.hdr.seq_no;
            let msg_len = order_packet.hdr.msg_len;
            let msg_type = order_packet.ord.msg_type as char;
            let exch_ts = order_packet.ord.exch_ts;
            let local_ts = order_packet.local_ts;
            let order_id = order_packet.ord.order_id;
            let token = order_packet.ord.token;
            let order_type = order_packet.ord.order_type as char;
            let price = order_packet.ord.price;
            let quantity = order_packet.ord.quantity;
            let missed = if order_packet.flags { 1 } else { 0 };

            format!(
                "Order Message: SeqNo{}, msg_len{}, Msg_Type'{}', Exch_ts{}, local_ts{}, order_id{}, Token{}, order_Type'{}', Price{}, Quantity{}, missed{}",
                seq_no,
                msg_len,
                msg_type,
                exch_ts,
                local_ts,
                order_id,
                token,
                order_type,
                price,
                quantity,
                missed
            )
        }

        Message::Trade(trade_packet) => {
            let seq_no = trade_packet.hdr.seq_no;
            let msg_len = trade_packet.hdr.msg_len;
            let msg_type = trade_packet.trd.msg_type as char;
            let exch_ts = trade_packet.trd.exch_ts;
            let local_ts = trade_packet.local_ts;
            let buy_order_id = trade_packet.trd.buy_order_id;
            let sell_order_id = trade_packet.trd.sell_order_id;
            let token = trade_packet.trd.token;
            let price = trade_packet.trd.trade_price;
            let quantity = trade_packet.trd.trade_quantity;
            let missed = if trade_packet.flags { 1 } else { 0 };

            format!(
                "Trade Message: SeqNo{}, msg_len{}, Msg_Type'{}', Exch_ts{}, local_ts{}, order_id_buy{}, order_id_sell{}, Token{}, Price{}, Quantity{}, missed{}",
                seq_no,
                msg_len,
                msg_type,
                exch_ts,
                local_ts,
                buy_order_id,
                sell_order_id,
                token,
                price,
                quantity,
                missed
            )
        }
    }
}

/// Read and query exchange messages from a binary capture file.
///
/// This class loads the full binary file once and then exposes helper methods
/// for counting, filtering, and selecting order/trade messages.
///
/// Example:
///
/// ```python
/// from orderpulse import ReadMsgFromBinary
///
/// reader = ReadMsgFromBinary("market_data.bin")
/// reader.summary()
///
/// first_10 = reader.get_all_messages(limit=10)
/// ```
///
/// Token-filtered example:
///
/// ```python
/// reader = ReadMsgFromBinary("market_data.bin", token=26000)
/// ```
#[pyclass]
pub struct ReadMsgFromBinary {

    // STORED ONLY ONE TIME
    messages: Arc<Vec<Message>>,

    current_index: usize,
}

#[pymethods]
impl ReadMsgFromBinary {

    /// Create a binary message reader.
    ///
    /// Args:
    ///     path:
    ///         Path to the binary market data file.
    ///     token:
    ///         Optional instrument token.
    ///
    /// Returns:
    ///     ReadMsgFromBinary
    ///
    /// Example:
    ///
    /// ```python
    /// reader = ReadMsgFromBinary("market_data.bin")
    /// ```
    #[new]
    #[pyo3(signature = (path, token=None), text_signature = "(path, token=None)")]
    fn new(path: String, token: Option<u32>) -> PyResult<Self> {

        // FILE READ ONLY ONE TIME
        let messages = read_messages(&path)
            .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))?;

        let messages = if let Some(filter_token) = token {

            messages
                .into_iter()
                .filter(|msg| match msg {

                    Message::Order(o) => o.ord.token == filter_token,

                    Message::Trade(t) => t.trd.token as u32 == filter_token,
                })
                .collect()

        } else {
            messages
        };

        Ok(Self {

            messages: Arc::new(messages),

            current_index: 0,
        })
    }

    /// Return total number of parsed messages.
    #[pyo3(text_signature = "($self)")]
    fn total_messages(&self) -> usize {
        self.messages.len()
    }

    /// Return total order messages.
    #[pyo3(text_signature = "($self)")]
    fn total_orders(&self) -> usize {

        self.messages
            .iter()
            .filter(|msg| matches!(msg, Message::Order(_)))
            .count()
    }

    /// Return total trade messages.
    #[pyo3(text_signature = "($self)")]
    fn total_trades(&self) -> usize {

        self.messages
            .iter()
            .filter(|msg| matches!(msg, Message::Trade(_)))
            .count()
    }

    /// Print summary.
    #[pyo3(text_signature = "($self)")]
    fn summary(&self) {

        println!("Total Messages: {}", self.total_messages());

        println!("Total Orders: {}", self.total_orders());

        println!("Total Trades: {}", self.total_trades());
    }

    /// Reset cursor.
    #[pyo3(text_signature = "($self)")]
    fn reset_cursor(&mut self) {

        self.current_index = 0;
    }

    /// Return all messages.
    #[pyo3(signature = (limit=None), text_signature = "($self, limit=None)")]
    fn get_all_messages(&self, limit: Option<usize>) -> Vec<String> {

        self.messages
            .iter()
            .take(limit.unwrap_or(usize::MAX))
            .map(format_message)
            .collect()
    }

    /// Return only order messages.
    #[pyo3(signature = (limit=None), text_signature = "($self, limit=None)")]
    fn get_order_messages(&self, limit: Option<usize>) -> Vec<String> {

        self.messages
            .iter()
            .filter(|msg| matches!(msg, Message::Order(_)))
            .take(limit.unwrap_or(usize::MAX))
            .map(format_message)
            .collect()
    }

    /// Return only trade messages.
    #[pyo3(signature = (limit=None), text_signature = "($self, limit=None)")]
    fn get_trade_messages(&self, limit: Option<usize>) -> Vec<String> {

        self.messages
            .iter()
            .filter(|msg| matches!(msg, Message::Trade(_)))
            .take(limit.unwrap_or(usize::MAX))
            .map(format_message)
            .collect()
    }
}

/// Store parsed binary messages once and provide sequential fetching.
///
/// BinaryLoader NEVER rereads binary file.
/// It only uses stored RAM messages.
///
/// Example:
///
/// ```python
/// reader = ReadMsgFromBinary("market_data.bin")
///
/// loader = BinaryLoader(reader)
///
/// while True:
///     msg = loader.get_next_message()
///
///     if msg == "END":
///         break
///
///     print(msg)
/// ```
#[pyclass]
pub struct BinaryLoader {

    // SHARED MEMORY
    messages: Arc<Vec<Message>>,

    current_index: usize,
}

#[pymethods]
impl BinaryLoader {

    /// Create BinaryLoader from ReadMsgFromBinary.
    ///
    /// No file reread happens here.
    #[new]
    fn new(reader: PyRef<ReadMsgFromBinary>) -> Self {

        Self {

            // SHARE MEMORY
            messages: Arc::clone(&reader.messages),

            current_index: 0,
        }
    }

    /// Reset cursor to beginning.
    #[pyo3(text_signature = "($self)")]
    fn reset_cursor(&mut self) {

        self.current_index = 0;
    }

    /// Return next message.
    ///
    /// Returns:
    ///     str
    ///
    /// Returns "END" when complete.
    #[pyo3(text_signature = "($self)")]
    fn get_next_message(&mut self) -> String {

        // NO FILE READ HERE

        if self.current_index >= self.messages.len() {

            return "END".to_string();
        }

        let msg = &self.messages[self.current_index];

        self.current_index += 1;

        format_message(msg)
    }
}

/// Build top-of-book snapshots.
#[pyclass]
pub struct OrderBookGenerator;

#[pymethods]
impl OrderBookGenerator {

    /// Create new orderbook generator.
    #[new]
    #[pyo3(text_signature = "()")]
    fn new() -> Self {

        Self
    }

    /// Create orderbook from reader messages.
    ///
    /// Example:
    ///
    /// ```python
    /// reader = ReadMsgFromBinary("market.bin")
    ///
    /// ob = OrderBookGenerator()
    ///
    /// rows = ob.create_orderbook(reader)
    /// ```
    #[pyo3(text_signature = "($self, reader)")]
    fn create_orderbook(&self, reader: PyRef<ReadMsgFromBinary>) -> usize {

        Self::build_orderbook_from_messages(reader.messages.as_ref())
    }
}

impl OrderBookGenerator {

    fn build_orderbook_from_messages(messages: &[Message]) -> usize {

        let mut ob = OrderBookManager::new();

        let mut rows = 0usize;

        for msg in messages {

            match msg {

                Message::Order(order_packet) => {

                    ob.process_order_message(order_packet);

                    let token = order_packet.ord.token;

                    let local_ts = order_packet.local_ts;

                    let exch_ts = order_packet.ord.exch_ts;

                    if let Some((mid_price, bids, asks)) =
                        ob.get_top_levels(token, 5)
                    {

                        if bids.len() < 5 || asks.len() < 5 {
                            continue;
                        }

                        println!(
                            "local_ts{},exch_ts{},mid_price{},\
bid_price_0{},bid_qty_0{},ask_price_0{},ask_qty_0{},\
bid_price_1{},bid_qty_1{},ask_price_1{},ask_qty_1{},\
bid_price_2{},bid_qty_2{},ask_price_2{},ask_qty_2{},\
bid_price_3{},bid_qty_3{},ask_price_3{},ask_qty_3{},\
bid_price_4{},bid_qty_4{},ask_price_4{},ask_qty_4{}",
                            local_ts,
                            exch_ts,
                            mid_price,
                            bids[0].0,
                            bids[0].1,
                            asks[0].0,
                            asks[0].1,
                            bids[1].0,
                            bids[1].1,
                            asks[1].0,
                            asks[1].1,
                            bids[2].0,
                            bids[2].1,
                            asks[2].0,
                            asks[2].1,
                            bids[3].0,
                            bids[3].1,
                            asks[3].0,
                            asks[3].1,
                            bids[4].0,
                            bids[4].1,
                            asks[4].0,
                            asks[4].1,
                        );

                        rows += 1;
                    }
                }

                Message::Trade(trade_packet) => {

                    ob.process_trade_message(trade_packet);

                    let token = trade_packet.trd.token as u32;

                    let local_ts = trade_packet.local_ts;

                    let exch_ts = trade_packet.trd.exch_ts;

                    if let Some((mid_price, bids, asks)) =
                        ob.get_top_levels(token, 5)
                    {

                        if bids.len() < 5 || asks.len() < 5 {
                            continue;
                        }

                        println!(
                            "local_ts{},exch_ts{},mid_price{},\
bid_price_0{},bid_qty_0{},ask_price_0{},ask_qty_0{},\
bid_price_1{},bid_qty_1{},ask_price_1{},ask_qty_1{},\
bid_price_2{},bid_qty_2{},ask_price_2{},ask_qty_2{},\
bid_price_3{},bid_qty_3{},ask_price_3{},ask_qty_3{},\
bid_price_4{},bid_qty_4{},ask_price_4{},ask_qty_4{}",
                            local_ts,
                            exch_ts,
                            mid_price,
                            bids[0].0,
                            bids[0].1,
                            asks[0].0,
                            asks[0].1,
                            bids[1].0,
                            bids[1].1,
                            asks[1].0,
                            asks[1].1,
                            bids[2].0,
                            bids[2].1,
                            asks[2].0,
                            asks[2].1,
                            bids[3].0,
                            bids[3].1,
                            asks[3].0,
                            asks[3].1,
                            bids[4].0,
                            bids[4].1,
                            asks[4].0,
                            asks[4].1,
                        );

                        rows += 1;
                    }
                }
            }
        }

        rows
    }
}

/// Python module bindings.
#[pymodule]
fn fastreader(_py: Python, m: &Bound<PyModule>) -> PyResult<()> {

    m.add_class::<ReadMsgFromBinary>()?;

    m.add_class::<BinaryLoader>()?;

    m.add_class::<OrderBookGenerator>()?;

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::mem::size_of;
    use std::path::PathBuf;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn order_message(
        seq_no: u32,
        msg_type: u8,
        token: u32,
        order_id: u64,
        order_type: u8,
        price: u32,
        quantity: u32,
    ) -> Message {
        Message::Order(structure::OrderPacket {
            hdr: structure::StreamHeader {
                msg_len: size_of::<structure::OrderPacket>() as u16,
                stream_id: 1,
                seq_no,
            },
            ord: structure::OrderMessage {
                msg_type,
                exch_ts: 1_000 + seq_no as u64,
                order_id,
                token,
                order_type,
                price,
                quantity,
            },
            local_ts: 2_000 + seq_no as u64,
            flags: false,
        })
    }

    fn trade_message(
        seq_no: u32,
        token: i32,
        buy_order_id: u64,
        sell_order_id: u64,
        trade_price: i32,
        trade_quantity: i32,
    ) -> Message {
        Message::Trade(structure::TradePacket {
            hdr: structure::StreamHeader {
                msg_len: size_of::<structure::TradePacket>() as u16,
                stream_id: 1,
                seq_no,
            },
            trd: structure::TradeMessage {
                msg_type: b'T',
                exch_ts: 3_000 + seq_no as u64,
                buy_order_id,
                sell_order_id,
                token,
                trade_price,
                trade_quantity,
            },
            local_ts: 4_000 + seq_no as u64,
            flags: false,
        })
    }

    fn encode_order_packet(
        seq_no: u32,
        token: u32,
        order_id: u64,
        order_type: u8,
        price: u32,
        quantity: u32,
    ) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(size_of::<structure::OrderPacket>());
        bytes.extend_from_slice(&(size_of::<structure::OrderPacket>() as u16).to_le_bytes());
        bytes.extend_from_slice(&1u16.to_le_bytes());
        bytes.extend_from_slice(&seq_no.to_le_bytes());
        bytes.push(b'N');
        bytes.extend_from_slice(&(1_000 + seq_no as u64).to_le_bytes());
        bytes.extend_from_slice(&order_id.to_le_bytes());
        bytes.extend_from_slice(&token.to_le_bytes());
        bytes.push(order_type);
        bytes.extend_from_slice(&price.to_le_bytes());
        bytes.extend_from_slice(&quantity.to_le_bytes());
        bytes.extend_from_slice(&(2_000 + seq_no as u64).to_le_bytes());
        bytes.push(0);
        bytes
    }

    fn encode_trade_packet(
        seq_no: u32,
        token: i32,
        buy_order_id: u64,
        sell_order_id: u64,
        trade_price: i32,
        trade_quantity: i32,
    ) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(size_of::<structure::TradePacket>());
        bytes.extend_from_slice(&(size_of::<structure::TradePacket>() as u16).to_le_bytes());
        bytes.extend_from_slice(&1u16.to_le_bytes());
        bytes.extend_from_slice(&seq_no.to_le_bytes());
        bytes.push(b'T');
        bytes.extend_from_slice(&(3_000 + seq_no as u64).to_le_bytes());
        bytes.extend_from_slice(&buy_order_id.to_le_bytes());
        bytes.extend_from_slice(&sell_order_id.to_le_bytes());
        bytes.extend_from_slice(&token.to_le_bytes());
        bytes.extend_from_slice(&trade_price.to_le_bytes());
        bytes.extend_from_slice(&trade_quantity.to_le_bytes());
        bytes.extend_from_slice(&(4_000 + seq_no as u64).to_le_bytes());
        bytes.push(0);
        bytes
    }

    fn write_test_feed(bytes: &[u8]) -> PathBuf {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let path = std::env::temp_dir().join(format!(
            "orderpulse-lib-test-{}-{}.bin",
            std::process::id(),
            unique
        ));
        fs::write(&path, bytes).unwrap();
        path
    }

    #[test]
    fn reader_methods_count_and_filter_messages() {
        let mut bytes = Vec::new();
        bytes.extend_from_slice(&encode_order_packet(1, 42, 1_001, b'B', 100, 10));
        bytes.extend_from_slice(&encode_trade_packet(2, 42, 1_001, 2_001, 101, 5));
        bytes.extend_from_slice(&encode_order_packet(3, 7, 3_001, b'S', 102, 20));

        let path = write_test_feed(&bytes);

        let reader = ReadMsgFromBinary::new(path.to_string_lossy().into_owned(), None).unwrap();
        assert_eq!(reader.total_messages(), 3);
        assert_eq!(reader.total_orders(), 2);
        assert_eq!(reader.total_trades(), 1);

        let all_messages = reader.get_all_messages(Some(2));
        assert_eq!(all_messages.len(), 2);
        assert!(all_messages[0].contains("Order Message"));
        assert!(all_messages[1].contains("Trade Message"));

        let order_messages = reader.get_order_messages(None);
        assert_eq!(order_messages.len(), 2);
        assert!(order_messages.iter().all(|msg| msg.contains("Order Message")));

        let trade_messages = reader.get_trade_messages(None);
        assert_eq!(trade_messages.len(), 1);
        assert!(trade_messages[0].contains("Trade Message"));

        let filtered = ReadMsgFromBinary::new(path.to_string_lossy().into_owned(), Some(42)).unwrap();
        assert_eq!(filtered.total_messages(), 2);
        assert_eq!(filtered.total_orders(), 1);
        assert_eq!(filtered.total_trades(), 1);

        filtered.summary();

        fs::remove_file(path).unwrap();
    }

    #[test]
    fn reader_reset_cursor_resets_internal_position() {
        let mut reader = ReadMsgFromBinary {
            messages: Arc::new(vec![order_message(1, b'N', 42, 1_001, b'B', 100, 10)]),
            current_index: 3,
        };

        reader.reset_cursor();

        assert_eq!(reader.current_index, 0);
    }

    #[test]
    fn binary_loader_reads_messages_in_sequence() {
        Python::with_gil(|py| {
            let reader = Py::new(
                py,
                ReadMsgFromBinary {
                    messages: Arc::new(vec![
                        order_message(1, b'N', 42, 1_001, b'B', 100, 10),
                        trade_message(2, 42, 1_001, 2_001, 101, 5),
                    ]),
                    current_index: 0,
                },
            )
            .unwrap();

            let mut loader = BinaryLoader::new(reader.bind(py).borrow());

            let first = loader.get_next_message();
            let second = loader.get_next_message();
            let end = loader.get_next_message();

            assert!(first.contains("Order Message"));
            assert!(second.contains("Trade Message"));
            assert_eq!(end, "END");

            loader.reset_cursor();
            assert!(loader.get_next_message().contains("Order Message"));
        });
    }

    #[test]
    fn orderbook_generator_returns_rows_after_full_depth_exists() {
        Python::with_gil(|py| {
            let mut messages = vec![
                order_message(1, b'N', 99, 11, b'B', 100, 10),
                order_message(2, b'N', 99, 12, b'B', 99, 10),
                order_message(3, b'N', 99, 13, b'B', 98, 10),
                order_message(4, b'N', 99, 14, b'B', 97, 10),
                order_message(5, b'N', 99, 15, b'B', 96, 10),
                order_message(6, b'N', 99, 21, b'S', 101, 10),
                order_message(7, b'N', 99, 22, b'S', 102, 10),
                order_message(8, b'N', 99, 23, b'S', 103, 10),
                order_message(9, b'N', 99, 24, b'S', 104, 10),
                order_message(10, b'N', 99, 25, b'S', 105, 10),
            ];

            messages.push(trade_message(11, 99, 999, 888, 101, 1));

            let reader = Py::new(
                py,
                ReadMsgFromBinary {
                    messages: Arc::new(messages),
                    current_index: 0,
                },
            )
            .unwrap();

            let generator = OrderBookGenerator::new();
            let rows = generator.create_orderbook(reader.bind(py).borrow());

            assert_eq!(rows, 2);
        });
    }
}