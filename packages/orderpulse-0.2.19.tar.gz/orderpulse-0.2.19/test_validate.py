import struct
import os
from orderpulse import ReadMsgFromBinary, BinaryLoader, OrderBookGenerator

def create_packet(msg_type, seq_no, token, price=100, quantity=10, order_id=1, side=1):
    # StreamHeader: msg_len (u16), stream_id (u16), seq_no (u32)
    # OrderMessage: msg_type (u8), exch_ts (u64), order_id (u64), token (u32), order_type (u8), price (u32), quantity (u32)
    # TradeMessage: msg_type (u8), exch_ts (u64), buy_order_id (u64), sell_order_id (u64), token (i32), trade_price (i32), trade_quantity (i32)
    # OrderPacket: hdr, ord, local_ts (u64), flags (bool/u8)
    # TradePacket: hdr, trd, local_ts (u64), flags (bool/u8)

    if msg_type == 1: # Order
        msg_len = 8 + 1 + 8 + 8 + 4 + 1 + 4 + 4 + 8 + 1 # 47
        hdr = struct.pack("<HHI", msg_len, 1, seq_no)
        ord_msg = struct.pack("<BQQIBII", 1, 123456789, order_id, token, side, price, quantity)
        packet = hdr + ord_msg + struct.pack("<QB", 987654321, 0)
        return packet
    elif msg_type == 2: # Trade
        msg_len = 8 + 1 + 8 + 8 + 8 + 4 + 4 + 4 + 8 + 1 # 54
        hdr = struct.pack("<HHI", msg_len, 1, seq_no)
        trd_msg = struct.pack("<BQQQiii", 2, 123456789, order_id, order_id+1, token, price, quantity)
        packet = hdr + trd_msg + struct.pack("<QB", 987654321, 0)
        return packet

def run_test():
    path = "test_feed.bin"
    # 2 orders and 1 trade
    # Order 1: token 42, Order 2: token 100, Trade 1: token 42
    with open(path, "wb") as f:
        f.write(create_packet(1, 1, 42)) # Order
        f.write(create_packet(1, 2, 100)) # Order
        f.write(create_packet(2, 3, 42)) # Trade

    print("--- Check 1-4: ReadMsgFromBinary ---")
    try:
        reader = ReadMsgFromBinary(path)
        print(f"Total messages: {reader.total_messages}")
        print(f"Total orders: {reader.total_orders}")
        print(f"Total trades: {reader.total_trades}")
        
        # Checking filtered
        filtered = ReadMsgFromBinary(path, token=42)
        print(f"Filtered messages (token 42): {filtered.total_messages}")
        
        # summary()
        print("Calling summary()...")
        reader.summary()
        print("summary() called successfully")
    except Exception as e:
        print(f"Error in Check 1-4: {e}")

    print("\n--- Check 5: BinaryLoader ---")
    try:
        loader = BinaryLoader(reader)
        count = 0
        for msg in loader:
            if msg == "END":
                print("Received END")
                break
            count += 1
        print(f"Loader yielded {count} messages")
    except Exception as e:
        print(f"Error in Check 5: {e}")

    print("\n--- Check 6: OrderBookGenerator ---")
    path2 = "test_feed_ob.bin"
    with open(path2, "wb") as f:
        # 5 bid orders (side=1) and 5 ask orders (side=2) for token 1
        for i in range(5):
            f.write(create_packet(1, i, 1, price=100+i, side=1, order_id=i))
        for i in range(5, 10):
            f.write(create_packet(1, i, 1, price=110+i, side=2, order_id=i))
    
    try:
        reader2 = ReadMsgFromBinary(path2, token=1)
        gen = OrderBookGenerator()
        rows = gen.create_orderbook(reader2)
        print(f"OrderBookGenerator returned row count: {rows}")
    except Exception as e:
        print(f"Error in Check 6: {e}")

    # Cleanup
    if os.path.exists(path): os.remove(path)
    if os.path.exists(path2): os.remove(path2)

if __name__ == "__main__":
    run_test()
