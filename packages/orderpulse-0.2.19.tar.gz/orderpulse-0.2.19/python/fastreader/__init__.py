from .fastreader import *
from . import fastreader as _fastreader

__doc__ = _fastreader.__doc__
if hasattr(_fastreader, "__all__"):
    __all__ = _fastreader.__all__
