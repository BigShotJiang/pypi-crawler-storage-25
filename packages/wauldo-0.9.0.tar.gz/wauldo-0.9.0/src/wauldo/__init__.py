"""
Wauldo Python SDK

Two client interfaces:
- AgentClient / AsyncAgentClient — MCP server (stdio JSON-RPC) for reasoning, planning, tools
- HttpClient — REST API (OpenAI-compatible) for chat, embeddings, RAG, orchestrator
- AgentsClient — deployed Wauldo Agents (create/run/poll/stream)
"""

from .agents import AgentsClient
from .agents_types import (
    Agent,
    AgentList,
    AgentPagination,
    AgentRunResponse,
    StateTransition,
    Task,
    TaskClaim,
    TaskStatus,
    TaskVerification,
    Verdict,
)
from .client import AgentClient, AsyncAgentClient
from .conversation import Conversation
from .exceptions import (
    AgentConnectionError,
    AgentTimeoutError,
    ServerError,
    ToolNotFoundError,
    ValidationError,
    WauldoError,
)
from .http_client import HttpClient
from .http_types import (
    ChatMessage as HttpChatMessage,
)
from .http_types import (
    ChatRequest,
    ChatResponse,
    EmbeddingResponse,
    GuardClaim,
    GuardResponse,
    ModelList,
    OrchestratorResponse,
    RagAuditInfo,
    RagQueryResponse,
    RagSource,
    RagUploadResponse,
)
from .mock_client import MockHttpClient
from .models import (
    Chunk,
    ChunkResult,
    Concept,
    ConceptResult,
    GraphNode,
    KnowledgeGraphResult,
    PlanResult,
    PlanStep,
    ReasoningResult,
    RetrievalResult,
    ToolDefinition,
    ToolsListResult,
)

__version__ = "0.9.0"
__all__ = [
    # MCP Clients
    "AgentClient",
    "AsyncAgentClient",
    # HTTP Client
    "HttpClient",
    "MockHttpClient",
    "Conversation",
    "ChatRequest",
    "ChatResponse",
    "HttpChatMessage",
    "EmbeddingResponse",
    "ModelList",
    "OrchestratorResponse",
    "RagAuditInfo",
    "RagQueryResponse",
    "RagSource",
    "RagUploadResponse",
    # Guard
    "GuardResponse",
    "GuardClaim",
    # Agents + Tasks
    "AgentsClient",
    "Agent",
    "AgentList",
    "AgentPagination",
    "AgentRunResponse",
    "Task",
    "TaskClaim",
    "TaskVerification",
    "TaskStatus",
    "StateTransition",
    "Verdict",
    # Exceptions
    "WauldoError",
    "AgentConnectionError",
    "AgentTimeoutError",
    "ServerError",
    "ToolNotFoundError",
    "ValidationError",
    # MCP Models
    "ReasoningResult",
    "ConceptResult",
    "Concept",
    "ChunkResult",
    "Chunk",
    "RetrievalResult",
    "KnowledgeGraphResult",
    "PlanResult",
    "PlanStep",
    "GraphNode",
    "ToolDefinition",
    "ToolsListResult",
]
