# Changelog

All notable changes to the Wauldo Python SDK.

## [0.9.0] - 2026-04-15

### Added
- Typed dataclasses for the Agents + Tasks API: `Agent`, `AgentList`,
  `AgentPagination`, `AgentRunResponse`, `Task`, `TaskClaim`,
  `TaskVerification`, `StateTransition`, plus `Verdict` and `TaskStatus`
  string enums. All exposed from the top-level `wauldo` package.
- `AgentsClient.get_task(task_id) -> Task` — fetch current task state.
- `AgentsClient.cancel_task(task_id) -> None` — cancel a queued/running task.
- `AgentsClient.wait_for_task(task_id, timeout_sec, poll_interval_sec) -> Task`
  — blocking poll helper that returns when the task reaches a terminal
  status, or raises `TimeoutError`.
- `AgentsClient.stream_task(task_id) -> Iterator[StateTransition]` —
  subscribe to `GET /v1/tasks/:id/stream` and yield typed events as each
  workflow state completes. Works with stdlib `urllib` only, no extra deps.
- `Task.is_done` convenience property (`completed|failed|cancelled`).
- `TaskVerification.message` optional field — human-readable context for
  non-SAFE verdicts (e.g. "No source documents uploaded" when verdict
  is `UNVERIFIED` and verification_source is `prompt_only`).

### Changed
- **BREAKING** `AgentsClient.create/list/get/update/run` now return typed
  objects (`Agent`, `AgentList`, `AgentRunResponse`) instead of raw
  `dict`. Migration: `agent["id"]` → `agent.id`. Backwards-compatible
  attribute access works out of the box; dict-style access does not.
  `a2a_invoke` still returns `dict` (less common API).
- Unknown fields from the server are preserved in `_extra` on each
  dataclass so older SDK versions don't break when the server adds new
  fields.

## [0.1.0] - 2026-03-16

### Added
- `HttpClient` — REST API client (OpenAI-compatible)
  - `chat()`, `chat_simple()`, `chat_stream()`, `list_models()`, `embeddings()`
  - `rag_upload()`, `rag_query()`, `rag_ask()`
  - `orchestrate()`, `orchestrate_parallel()`
- `AgentClient` / `AsyncAgentClient` — MCP client (sync + async)
  - `reason()`, `extract_concepts()`, `plan_task()`
  - `chunk_document()`, `retrieve_context()`, `summarize()`
  - `search_knowledge()`, `add_to_knowledge()`
- `Conversation` — automatic chat history management
- `MockHttpClient` — offline testing without server
- Retry with exponential backoff (429/503/network errors)
- Structured logging via `logging.getLogger("wauldo")`
- Pydantic v2 response validation on all endpoints
- Full type hints + py.typed (PEP 561)
- Per-request `timeout_ms` override on `chat()`, `chat_simple()`, `rag_upload()`
- Event hooks: `on_request`, `on_response`, `on_error` callbacks
