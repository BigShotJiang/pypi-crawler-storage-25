#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import re
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup, Tag


BASE_URL = "https://race-results-online.com/"
EVENTS_URL = "https://race-results-online.com/sorcs_race_event.php"

HEADERS = {
    "User-Agent": "sorcs-results-scraper/0.3"
}


@dataclass
class RaceEvent:
    event_name: str
    event_pid: str


@dataclass
class RaceClass:
    event_name: str
    class_name: str
    class_pid: str
    url: str


def clean_text(text: str) -> str:
    return " ".join(text.split())


def safe_filename(text: str) -> str:
    text = clean_text(text)
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", text)
    text = text.strip("_")
    return text[:180] or "event"


def get_soup(session: requests.Session, url: str) -> BeautifulSoup:
    response = session.get(url, headers=HEADERS, timeout=30)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def post_soup(
    session: requests.Session,
    url: str,
    data: dict[str, str],
) -> BeautifulSoup:
    response = session.post(url, data=data, headers=HEADERS, timeout=30)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def scrape_events(session: requests.Session) -> list[RaceEvent]:
    """
    The main SORCS page uses buttons like:

        onclick="view_class(925)"

    Browser tools show that clicking one submits:

        POST /class_raced.php
        pid2=925
    """
    soup = get_soup(session, EVENTS_URL)

    events: list[RaceEvent] = []

    for element in soup.select("[onclick]"):
        onclick = element.get("onclick", "")

        match = re.search(r"view_class\((\d+)\)", onclick)
        if not match:
            continue

        event_pid = match.group(1)
        event_name = clean_text(element.get_text(" ", strip=True))

        if not event_name:
            event_name = f"event_{event_pid}"

        events.append(
            RaceEvent(
                event_name=event_name,
                event_pid=event_pid,
            )
        )

    return events


def fetch_event_page(
    session: requests.Session,
    event: RaceEvent,
) -> BeautifulSoup:
    """
    Fetch the class-list page for one event by submitting the same form data
    the browser submits.
    """
    return post_soup(
        session=session,
        url=urljoin(BASE_URL, "class_raced.php"),
        data={"pid2": event.event_pid},
    )


def scrape_classes_for_event(
    session: requests.Session,
    event: RaceEvent,
) -> list[RaceClass]:
    soup = fetch_event_page(session, event)

    classes: list[RaceClass] = []

    for element in soup.select("[onclick]"):
        onclick = element.get("onclick", "")

        match = re.search(r"view_class\((\d+)\)", onclick)
        if not match:
            continue

        class_pid = match.group(1)
        class_name = clean_text(element.get_text(" ", strip=True))

        if not class_name:
            class_name = f"class_{class_pid}"

        classes.append(
            RaceClass(
                event_name=event.event_name,
                class_name=class_name,
                class_pid=class_pid,
                url=urljoin(BASE_URL, "race_results.php"),
            )
        )

    return classes


def normalize_header(header: str) -> str:
    header = header.strip().lower()
    header = header.replace("#", "number")
    header = re.sub(r"[^a-z0-9]+", "_", header)
    header = header.strip("_")
    return header or "column"


def dedupe_headers(headers: list[str]) -> list[str]:
    seen: dict[str, int] = {}
    output: list[str] = []

    for header in headers:
        base = normalize_header(header)
        count = seen.get(base, 0)

        if count == 0:
            output.append(base)
        else:
            output.append(f"{base}_{count + 1}")

        seen[base] = count + 1

    return output


def table_to_grid(table: Tag) -> list[list[str]]:
    grid: list[list[str]] = []

    for tr in table.find_all("tr"):
        cells = [
            clean_text(cell.get_text(" ", strip=True))
            for cell in tr.find_all(["th", "td"], recursive=False)
        ]

        if not cells:
            cells = [
                clean_text(cell.get_text(" ", strip=True))
                for cell in tr.find_all(["th", "td"])
            ]

        cells = [cell for cell in cells if cell]

        if cells:
            grid.append(cells)

    return grid


def looks_like_header_row(row: list[str]) -> bool:
    normalized = {normalize_header(cell) for cell in row}

    keywords = {
        "pos",
        "position",
        "place",
        "pl",
        "number",
        "no",
        "num",
        "rider",
        "name",
        "first_name",
        "last_name",
        "bike",
        "brand",
        "laps",
        "lap",
        "time",
        "elapsed",
        "total",
        "points",
        "pts",
        "city",
        "hometown",
    }

    return len(row) >= 3 and len(normalized & keywords) >= 2


def looks_like_data_row(row: list[str]) -> bool:
    if len(row) < 3:
        return False

    first = row[0].strip().lower()

    if first.isdigit():
        return True

    if first in {"dnf", "dns", "dq", "dsq"}:
        return True

    if len(row) > 1 and row[1].strip().isdigit():
        return True

    return False


def generated_headers(width: int) -> list[str]:
    return [f"column_{i}" for i in range(1, width + 1)]


def parse_result_rows_from_grid(grid: list[list[str]]) -> list[dict[str, str]]:
    if not grid:
        return []

    # Preferred path: find a header row, then parse result rows below it.
    for header_index, row in enumerate(grid):
        if not looks_like_header_row(row):
            continue

        headers = dedupe_headers(row)
        expected_width = len(headers)
        parsed_rows: list[dict[str, str]] = []

        for candidate in grid[header_index + 1 :]:
            if looks_like_header_row(candidate):
                break

            if not looks_like_data_row(candidate):
                continue

            cells = candidate[:]

            if len(cells) < expected_width:
                cells.extend([""] * (expected_width - len(cells)))

            if len(cells) > expected_width:
                cells = cells[:expected_width]

            parsed_rows.append(dict(zip(headers, cells)))

        if parsed_rows:
            return parsed_rows

    # Fallback path: no clear header row, but data-like rows exist.
    data_rows = [row for row in grid if looks_like_data_row(row)]

    if not data_rows:
        return []

    width = max(len(row) for row in data_rows)
    headers = generated_headers(width)

    parsed_rows = []

    for row in data_rows:
        cells = row[:]

        if len(cells) < width:
            cells.extend([""] * (width - len(cells)))

        if len(cells) > width:
            cells = cells[:width]

        parsed_rows.append(dict(zip(headers, cells)))

    return parsed_rows


def parse_results_page(
    soup: BeautifulSoup,
    debug: bool = False,
) -> list[dict[str, str]]:
    all_rows: list[dict[str, str]] = []

    tables = soup.find_all("table")

    for table_index, table in enumerate(tables, start=1):
        grid = table_to_grid(table)

        if debug:
            print(f"\n--- table {table_index}, {len(grid)} rows ---")
            for i, row in enumerate(grid[:80]):
                print(f"{i:02d}: {row}")

        rows = parse_result_rows_from_grid(grid)

        for row in rows:
            row["_table_index"] = str(table_index)

        all_rows.extend(rows)

    return all_rows


def fetch_results_page(
    session: requests.Session,
    race_class: RaceClass,
) -> BeautifulSoup:
    return post_soup(
        session=session,
        url=urljoin(BASE_URL, "race_results.php"),
        data={"pid2": race_class.class_pid},
    )


def scrape_results_for_class(
    session: requests.Session,
    race_class: RaceClass,
    debug: bool = False,
    debug_dir: Path | None = None,
) -> list[dict[str, str]]:
    soup = fetch_results_page(session, race_class)

    if debug and debug_dir is not None:
        debug_dir.mkdir(parents=True, exist_ok=True)
        debug_path = debug_dir / f"{safe_filename(race_class.class_name)}_{race_class.class_pid}.html"
        debug_path.write_text(str(soup), encoding="utf-8")
        print(f"    Debug HTML written to {debug_path}")

    result_rows = parse_results_page(soup, debug=debug)

    enriched_rows: list[dict[str, str]] = []

    for row in result_rows:
        enriched_rows.append(
            {
                "name": row.get("name", ""),
                "event_name": race_class.event_name,
                "class_name": race_class.class_name,
                **row,
            }
        )

    return enriched_rows


def write_event_csv(path: Path, rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    if not rows:
        print(f"No rows for {path}; skipping")
        return

    preferred_fields = [
        "name",
        "event_name",
        "class_name",
        "finish",
        "nbr",
        "class",
        "brand",
        "laps_completed",
        "finish_time",
    ]

    ignored_fields = {
        "class_pid",
        "source_url",
        "_table_index",
    }

    discovered_fields = sorted(
        {
            key
            for row in rows
            for key in row.keys()
            if key not in ignored_fields
        }
    )

    fieldnames = preferred_fields + [
        field
        for field in discovered_fields
        if field not in preferred_fields
    ]

    def finish_sort_value(value: str) -> tuple[int, int | str]:
        value = value.strip().upper()

        if value.isdigit():
            return (0, int(value))

        status_order = {
            "DNF": 1,
            "DNS": 2,
            "DQ": 3,
            "DSQ": 3,
        }

        return (status_order.get(value, 99), value)

    rows = sorted(
        rows,
        key=lambda row: (
            row.get("class_name", ""),
            finish_sort_value(row.get("finish", "")),
        ),
    )

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows to {path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-dir",
        default="output",
        help="Directory where per-event CSV files will be written.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Print table previews and save result HTML files.",
    )
    parser.add_argument(
        "--limit-events",
        type=int,
        default=None,
        help="Only scrape the first N events.",
    )
    parser.add_argument(
        "--limit-classes",
        type=int,
        default=None,
        help="Only scrape the first N classes per event.",
    )
    parser.add_argument(
        "--sleep",
        type=float,
        default=0.25,
        help="Delay between page requests.",
    )

    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    debug_dir = output_dir / "_debug_html"

    with requests.Session() as session:
        print("Scraping event list...")
        events = scrape_events(session)
        print(f"Found {len(events)} events")

        if args.limit_events is not None:
            events = events[: args.limit_events]
            print(f"Limited to {len(events)} events")

        for event in events:
            print(f"\nEvent: {event.event_name}")
            print(f"Event PID: {event.event_pid}")

            try:
                classes = scrape_classes_for_event(session, event)
            except Exception as e:
                print(f"  ERROR scraping classes: {e}")
                continue

            print(f"Found {len(classes)} classes")

            if args.limit_classes is not None:
                classes = classes[: args.limit_classes]
                print(f"Limited to {len(classes)} classes")

            event_rows: list[dict[str, str]] = []

            for race_class in classes:
                print(f"  Scraping class: {race_class.class_name}")
                print(f"    URL: {race_class.url}")

                try:
                    rows = scrape_results_for_class(
                        session=session,
                        race_class=race_class,
                        debug=args.debug,
                        debug_dir=debug_dir if args.debug else None,
                    )
                except Exception as e:
                    print(f"    ERROR scraping results: {e}")
                    continue

                print(f"    Parsed {len(rows)} rows")
                event_rows.extend(rows)

                time.sleep(args.sleep)

            output_path = output_dir / f"{safe_filename(event.event_name)}.csv"
            write_event_csv(output_path, event_rows)


if __name__ == "__main__":
    main()
