# insightme

Local-only analytics for **iMessage** and **Call History** on **macOS**. Data never leaves your machine.

## Requirements

- **macOS** with Messages / Phone data
- **Python 3.11+**
- **Full Disk Access** for the app that runs the tool (Terminal):  
  **System Settings → Privacy & Security → Full Disk Access** → add your terminal app

## Install

### From PyPI (after publishing)

```bash
pip install insightme
insightme
```

### From a clone (editable, for development)

```bash
git clone https://github.com/YOUR_ORG/insightme.git
cd insightme
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -e .
insightme
```

### From Git without cloning manually

```bash
pip install "git+https://github.com/YOUR_ORG/insightme.git"
insightme
```

The `insightme` command starts the **Streamlit** UI. Open the URL shown in the terminal (usually `http://localhost:8501`).

## Verify the data layer

```bash
python3 test_data_layer.py
```

## Publishing to PyPI (maintainers)

```bash
pip install -e ".[dev]"   # or: pip install build twine
python -m build
twine upload dist/*
```

If `python -m build` errors with `No module named build.__main__`, install the **`build`** package (`pip install build`). If `pip` is missing in the venv, run `python -m ensurepip --upgrade` first.

Use [TestPyPI](https://test.pypi.org/) first if you want a dry run.

## Troubleshooting

### Cursor terminal vs Terminal.app

**Full Disk Access** is per application. If it works in **Terminal** but not in **Cursor’s integrated terminal**, add **Cursor** (and/or **Cursor Helper** / the binary that runs your shell) under **Full Disk Access** in System Settings, or run `insightme` from Terminal instead.

### Accidental `pip install e`

If you see pip installing a tiny package named **`e`** from PyPI, you ran `pip install e` by mistake. Remove it: `pip uninstall e`. A normal install is **`pip install -e .`** (editable, from the project directory).

## License

See the repository for license terms.
