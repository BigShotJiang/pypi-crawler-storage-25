############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import importlib.util
from pathlib import Path


class Config:
    def __init__(self, app_name="bwt-uploader"):
        self.config_dir = Path.home() / f".{app_name}"
        self.config_file = self.config_dir / "config.py"

        self.config = {}
        self.bbcode_template = ""
        self.details_bbcode_template = ""

    def load(self):
       
        if not self.config_file.exists():
            raise FileNotFoundError(
                "Config file not Installed"
            )

        spec = importlib.util.spec_from_file_location(
            "user_config",
            self.config_file
        )

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        self.config = getattr(module, "config", {})
        self.bbcode_template = getattr(module, "BBCODE_TEMPLATE", "")
        self.details_bbcode_template = getattr(module, "DETAILED_BBCODE_TEMPLATE", "")
        
        return self.config

    def get(self, key, default=None):
        """Shortcut to get config values"""
        return self.config.get(key, default)

    def get_nested(self, *keys, default=None):
        """Access nested values safely"""
        value = self.config
        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
            else:
                return default

            if value is None:
                return default

        return value


#####################################
#     Created by -= DE3PM =-        #
#####################################
