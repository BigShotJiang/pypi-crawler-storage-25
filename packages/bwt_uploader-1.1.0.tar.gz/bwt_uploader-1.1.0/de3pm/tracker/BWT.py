
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

################################################
# BWT-Uploader v1.1.0 - Created by -= DE3PM =- #
################################################


import os
import re
import asyncio
import requests
from pathlib import Path
import cloudscraper
from datetime import datetime

from ..core import console
from ..core import GetCatCode
from ..core import Confirm
from ..core import error_exit
from rich.prompt import Prompt


class BWTUploader:

    def __init__(self, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg

        self.base_url = self.cfg.get_nested("BWTorrents", "base_url")
        self.username = self.cfg.get_nested("BWTorrents", "username")
        self.password = self.cfg.get_nested("BWTorrents", "password")

        self.bwt_dir = Path.home() / ".bwt-uploader"
        self.bwt_dir.mkdir(parents=True, exist_ok=True)

        self.cookies_dir = self.bwt_dir / "cookies"
        self.cookies_dir.mkdir(parents=True, exist_ok=True)

        self.cookies_file = self.cookies_dir / "BWT.txt"
        self.min_size_gb = 10

        self.category = GetCatCode()
        self.session = cloudscraper.create_scraper(
            browser={
                "browser": "chrome",
                "platform": "windows",
                "mobile": False
            }
        )

        self.session.headers.update({
            "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"
        })

    async def setup(self, meta):

        self.metadata = meta
        self.filepath = meta.get("filepath")
        self.video_media = meta.get("video_media", False)
        self.raw_bluray = meta.get("raw_bluray", False)
        self.audio_music = meta.get("audio_music", False)

        self.torrent_path = meta.get("torrent_path")
        self.upload_folder = meta.get("upload_folder")
        self.filename = meta.get("filename_noext")

    async def _confirm(self, question: str) -> bool:
        try:
            return bool(await Confirm(question=question))
        except TypeError:
            return bool(await Confirm(None, question))
            
    async def safe_request(self, method, url, **kwargs):

        def request():
            try:
                r = self.session.request(method, url, timeout=30, **kwargs)
                r.raise_for_status()
                return r
            except requests.exceptions.Timeout:
                console.print("[bold red]Request timed out[/bold red]")
            except requests.exceptions.ConnectionError:
                console.print("[bold red]Connection error[/bold red]")
            except requests.exceptions.HTTPError as e:
                console.print(f"[bold red]HTTP error:[/bold red] {e}")
            return None

        return await asyncio.to_thread(request)
    

    def _read_file(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return f.read().strip()

    
    async def load_metadata(self, meta):

        bbcode_path = os.path.join(self.upload_folder, "[BBCode]Torrent_Description.txt")

        if not os.path.exists(bbcode_path):
            console.print("[bold red]Description file missing![/bold red]")
            error_exit()

        try:
            description = await asyncio.to_thread(self._read_file, bbcode_path)
        except Exception as e:
            console.print(f"[bold red]Description read error:[/bold red] {e}")
            error_exit()

        
        imdb_meta = meta.get("imdb") or {}
        trailer_meta = meta.get("trailer") or {}
        tmdb_meta = meta.get("tmdb") or {}

        imdb_link = imdb_meta.get("link", "")
        youtube_link = trailer_meta.get("url", "")
        poster = tmdb_meta.get("poster") or imdb_meta.get("poster", "")

        category_id = meta.get("category_id")

        if category_id is None:
            category_id = await self.category.get_category(meta)

        if category_id is not None:
            name = await self.category.get_category_name(category_id)
            console.print(f"\n[bold green]::[/bold green] [bold yellow]Category:[/bold yellow] {name}")

            confirmation = await self._confirm("[bold magenta]::[/bold magenta] Is this correct?")
            
            if not confirmation:
                category_id = await self.category.select_category(self.audio_music)

        if category_id is None:
            category_id = await self.category.select_category(self.audio_music)

        request = meta.get("request")
        double_upload = meta.get("doubleupload")
        force_freeleech = meta.get("force_freeleech")
        recomanded = meta.get("recomanded")
        
        return {
            "imdb_link": imdb_link,
            "youtube_link": youtube_link,
            "name": self.filename,
            "poster": poster,
            "category_id": category_id,
            "request": request,
            "double_upload": double_upload,
            "force_freeleech": force_freeleech,
            "recomanded": recomanded,
            "description": description
        }


    async def get_folder_size(self, path):

        total = 0
        loop = asyncio.get_running_loop()

        for root, _, files in os.walk(path):
            tasks = []

            for f in files:
                fp = os.path.join(root, f)
                tasks.append(loop.run_in_executor(None, os.path.getsize, fp))

            sizes = await asyncio.gather(*tasks, return_exceptions=True)

            for s in sizes:
                if isinstance(s, int):
                    total += s

        return total

    
    async def freeleech_check(self, meta, path):

        if meta.get("force_freeleech"):
            console.print()
            console.print("[bold green]Freeleech Status:[/bold green] True (Forced)")
            return "1"

        if not os.path.exists(path):
            console.print("[bold red]Path not found[/bold red]")
            return "0"

        if os.path.isfile(path):
            size = os.path.getsize(path)
        else:
            size = await self.get_folder_size(path)

        total_size_gb = size / (1024 ** 3)

        if total_size_gb >= self.min_size_gb:
            console.print()
            console.print(
                f"[bold green]Freeleech Status:[/bold green] True "
                f"(Size: {total_size_gb:.2f} GB)"
            )
            
            return "1"
            

        # Freeleech False Return 
        return "0"

    def parse_cookie_file(self, cookiefile=None):
        cookiefile = cookiefile or self.cookies_file

        if not os.path.exists(cookiefile):
            console.print("[bold red]Cookie file missing[/bold red]")
            error_exit()

        cookies = {}

        with open(cookiefile, "r", encoding="utf-8") as f:

            for line in f:

                if line.startswith("#") or not line.strip():
                    continue

                parts = line.split()

                if len(parts) >= 7:
                    cookies[parts[5]] = parts[6]

        return cookies

    async def login(self, cookiefile=None):
        cookiefile = cookiefile or self.cookies_file

        console.print()
        console.print(f"[cyan]:: Logging into [/cyan] {self.base_url}...")

        await self.safe_request("GET", f"{self.base_url}/login.php")

        data = {
            "username": self.username,
            "password": self.password
        }

        await self.safe_request(
            "POST",
            f"{self.base_url}/takelogin.php",
            data=data
        )

        resp = await self.safe_request("GET", f"{self.base_url}/index.php")

        if resp and re.search(r"logout", resp.text, re.I):

            console.print("[green]:: Login successful[/green]")

            os.makedirs(os.path.dirname(cookiefile), exist_ok=True)

            with open(cookiefile, "w", encoding="utf-8") as f:

                f.write("# Netscape HTTP Cookie File\n")
                f.write("# This file was generated by DE3PM's BWT-Uploader\n")
                f.write("# http://curl.haxx.se/rfc/cookie_spec.html\n")
                f.write("# This is a generated file!  Do not edit.\n\n")
                

                for c in self.session.cookies:
                    f.write(f"{c.domain}\tTRUE\t/\tFALSE\t0\t{c.name}\t{c.value}\n")

        else:
            console.print("[bold red]Login failed[/bold red]")
            error_exit()

    async def validate_credentials(self, cookiefile=None):
        cookiefile = cookiefile or self.cookies_file

        if not os.path.exists(cookiefile):
            await self.login(cookiefile)

        cookies = self.parse_cookie_file(cookiefile)

        self.session.cookies.update(cookies)

        resp = await self.safe_request("GET", f"{self.base_url}/index.php")

        if resp and re.search(r"logout", resp.text, re.I):
            return True

        console.print("[yellow]Session expired — re-logging[/yellow]")

        os.remove(cookiefile)

        await self.login(cookiefile)

        return True

    def ask_bwt_name(self):
        console.print()
        return Prompt.ask("[bold yellow]Enter BWT Name[/bold yellow]")

    
    def save_error(self, content):
        try:
            file_path = Path(self.upload_folder) / "upload_errors.txt"
            with open(file_path, "a", encoding="utf-8") as f:
                f.write("\n" + "=" * 60 + "\n")
                f.write(f"{datetime.now()}\n")
                f.write(content + "\n")
        except Exception as e:
            console.print(f"[red]Failed to write error log:[/red] {e}")
            
    async def upload(self, meta):

        if not os.path.exists(self.torrent_path):
            console.print("[bold red]Torrent file missing[/bold red]")
            error_exit()

        await self.validate_credentials()

        meta = await self.load_metadata(meta)

        freeleech = await self.freeleech_check(meta, self.filepath)

        cookies = self.parse_cookie_file()
        self.session.cookies.update(cookies)

        bwt_name = meta["name"]

        while True:
            console.print()
            console.print(f"[bold cyan]BWT Name :[/bold cyan] {bwt_name}")
            
            confirmation = await self._confirm("[bold magenta]::[/bold magenta] Correct?")
            if confirmation:
                break
            else:
                bwt_name = self.ask_bwt_name()

        data = {
            "name": bwt_name,
            "descr": meta["description"],
            "type": meta["category_id"]
        }

        #if meta.get("imdb_link"):
            #data["imdb_link"] = meta["imdb_link"]

        if meta.get('poster'):
            data['poster'] = meta['poster']
            
        if meta.get('youtube_link'):
            data['tube'] = meta['youtube_link']
            
        if meta.get('request'):
            data['request'] = 'yes'  
        else:
            data['request'] = 'no'
            
        if meta.get('double_upload'):
            data['double_upload'] = '1'
            
        if meta.get('force_freeleech'):
            data['free'] = '1'
            
        if freeleech == "1":
            data["free"] = "1"
            
        if meta.get('recomanded'):
            data['recomanded'] = '1'
            
        console.print()

        confirm = await self._confirm("[bold]Continue to Upload This?")
        if not confirm:
            error_exit()

        try:
            with open(self.torrent_path, "rb") as f:
                files = {"file": f}

                resp = await self.safe_request(
                    "POST",
                    f"{self.base_url}/takeupload.php",
                    files=files,
                    data=data
                )

        except Exception as e:
            msg = f"Request error: {e}"
            console.print(f"[bold red]{msg}[/bold red]")
            self.save_error(msg)
            return

        if not resp:
            msg = "Upload failed: No response received"
            console.print(f"[bold red]{msg}[/bold red]")
            self.save_error(msg)
            return

        console.print()

        if resp.status_code != 200:
            msg = f"HTTP {resp.status_code}\n{resp.text}"
            console.print("[bold red]Upload failed: Server returned error[/bold red]")
            self.save_error(msg)
            return
            
        if "login" in resp.text.lower():
            msg = resp.text
            console.print("[bold red]Upload failed: Not logged in[/bold red]")
            self.save_error(msg)
            return

        if "already uploaded" in resp.text.lower():
            console.print("[bold yellow]Upload skipped: Torrent already exists[/bold yellow]")
            
            existing = re.search(r"details\.php\?id=(\d+)&filelist", resp.text)
            if existing:
                tid = existing.group(1)
                url = f"{self.base_url}/details.php?id={tid}"
                console.print(f"[cyan]Existing URL:[/cyan] {url}")
            
            self.save_error(resp.text)
            return
            
        elif "upload failed" in resp.text.lower():
            msg = resp.text
            console.print("[bold red]Upload failed (server-side)[/bold red]")
            title_match = re.search(r"<title>(.*?)</title>", resp.text, re.IGNORECASE)
            if title_match:
                console.print(f"[red]{title_match.group(1)}[/red]")
           
            self.save_error(msg)
            return

        match = re.search(r"details\.php\?id=(\d+)&filelist", resp.text)

        if match:
            tid = match.group(1)
            url = f"{self.base_url}/details.php?id={tid}"

            console.print("\n[bold green]Torrent Uploaded Successfully[/bold green]\n")
            console.print(f"Name : {bwt_name}")
            console.print(f"ID   : {tid}")
            console.print(f"URL  : {url}")

        else:
            msg = f"Parse failed\n{resp.text}"
            console.print("[bold red]Upload failed: Could not parse response[/bold red]")
            console.print(f"[red]Response snippet:[/red]\n{resp.text[:500]}")
            self.save_error(msg)
    
#####################################
#     Created by -= DE3PM =-        #
#####################################
