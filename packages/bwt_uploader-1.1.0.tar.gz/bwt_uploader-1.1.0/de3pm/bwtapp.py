
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

################################################
# BWT-Uploader v1.1.0 - Created by -= DE3PM =- #
################################################

import os
import traceback
import asyncio
from .data import Config
from .core import *
from .tracker import BWTUploader


class BWTApp:

    def __init__(self):
        self.cfg = Config()
        self.cfg.load()
        self.meta = {}
        self.meta_args = {}
        self.movie_poster_url = None


    def cr_scr(self):
        os.system("cls" if os.name == "nt" else "clear")
        

    async def ck_up(self):
        try:
            checker = CheckUp(cfg=self.cfg)
            await checker.che_f_ups()
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")
            error_exit()


    async def load_arguments(self):
        args = Args()
        self.meta_args = args.metadata

        if not self.meta_args or not self.meta_args.get("filepath"):
            console.print("[bold red]Error: Filepath is required.[/bold red]")
            error_exit()


    async def process_file(self):
        self.file_info = FilePathInfo(self.meta_args, cfg=self.cfg)
        self.meta = await self.file_info.process()

        console.print(
            f"[bold cyan]File Name:[/bold cyan] {self.meta.get('filename')}\n"
        )


    async def fetch_metadata(self):
        if self.meta.get("type") == "video":
            while True:
                dbmeta = MetaDB(cfg=self.cfg)
                metadb = await dbmeta.process(self.meta)
                self.meta.update(metadb)

            
                printer = MediaPrinter(self.meta)
                override_ids = await printer.run()

                if not override_ids:
                    break

                self.meta.update(override_ids)

        elif self.meta.get("audio_music"):

            printer = MediaPrinter(self.meta)
            await printer.run()


    async def gen_mi(self):
        
        if self.meta.get("raw_bluray"):
            bdinfo = BDInfo()
            await bdinfo.scan(self.meta)
        
        elif self.meta.get("raw_dvd"):
            dvd = DVDInfo()
            await dvd.init(self.meta)
            await dvd.extract()
        
        elif self.meta.get("video_media"):
            mi = MediaINFO()
            await mi.init(self.meta)
            await mi.export()
        
        else:
            raise ValueError("Error: MediaInfo extract error")

        mi_meta = MediaInfoEx()
        await mi_meta.init(self.meta)
        media_meta = await mi_meta.get_media_meta()
        self.meta.update(media_meta)
        
    async def cr_tot(self):

        torrent = Torrent(cfg=self.cfg)
        await torrent.create(self.meta)


    async def handle_ss_and_ps(self):

        if self.meta.get("type") != "video": 
            return

        screens = Screens(cfg=self.cfg)
        await screens.init(self.meta)
        await screens.gen_scr()
        await screens.up_ims()


    async def gen_descr(self):

        descr = Descr(cfg=self.cfg)
        await descr.generate(self.meta)

    async def upload(self):
        
        uploader = BWTUploader(cfg=self.cfg)
        
        if self.meta.get("type") == "video":
            await uploader.setup(self.meta)
            await uploader.upload(self.meta)

    async def save_meta_safe(self):
        if not isinstance(self.meta, dict):
            return

        if not self.meta.get("upload_folder"):
            return

        try:
            await Meta().save_meta(self.meta)
            
        except Exception as e:
            console.print(f"[bold yellow]Warning: failed to save meta.json: {e}[/bold yellow]")

    # Run Application
    async def run(self):

        try:

            self.cr_scr()
            await header(app_version)
            
            await self.load_arguments()
            
            await self.ck_up()
            await self.process_file()

            await self.fetch_metadata()

            await self.gen_mi()

            await self.cr_tot()

            await self.handle_ss_and_ps()

            await self.gen_descr()

            await self.upload()

        except KeyboardInterrupt:

            console.print("\n[red]Process cancelled by user.[/red]")
            error_exit()

        except Exception as e:

            console.print("\n[bold red]Unexpected Error Occurred![/bold red]\n")
            console.print(f"[ERROR] {e}")
            self.meta["upload_success"] = False
            self.meta["upload_error"] = str(e)
            traceback.print_exc()
            console.print("Please reach out to @DE3PM for help.")
            error_exit()
        else:
            self.meta["upload_success"] = True
        finally:
            await self.save_meta_safe()


async def run_cli():

    app = BWTApp()

    await app.run()
    

def main():
    try:
        asyncio.run(run_cli())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
    
##############
# -= DE3PM=- #
##############
