############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import asyncio
import json
import os
from pathlib import Path
from pymediainfo import MediaInfo
from .ia import console


class MediaINFO:

    def __init__(self):
        self.filepath = None
        self.video_path = None
        self.upload_folder = None
        self.video_file_name = None

        self.mi_text_path = None
        self.mi_json_path = None

    async def init(self, meta):
        self.filepath = meta.get("filepath")
        self.video_path = meta.get("videopath")
        self.upload_folder = meta.get("upload_folder")
        self.video_file_name = meta.get("video_filename")

        self.mi_text_path = str(Path(self.upload_folder) / "Media_Info.txt")
        self.mi_json_path = str(Path(self.upload_folder) / "MediaInfo.json")

    async def save_mi_text(self, filepath, media_info: str):
        """
        Save formatted MediaInfo text.
        """
        def write_file():
            lines = media_info.splitlines()
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"{self.video_file_name}\n\n")
                for line in lines:
                    if line.startswith("Complete name"):
                        f.write(
                            f"Complete name                            : {self.video_file_name}\n"
                        )
                    else:
                        f.write(line + "\n")

        await asyncio.to_thread(write_file)


    async def export(self):
        """
        Export MediaInfo as Text + JSON
        """
        console.print()
        console.print("[bold yellow]➤ Exporting MediaInfo...[/bold yellow]")

        try:
            if not os.path.isfile(self.video_path):
                raise FileNotFoundError(f"Video file not found: {self.video_path}")

            try:
                media_info_text = await asyncio.to_thread(
                    MediaInfo.parse,
                    self.video_path,
                    output="STRING",
                    full=False,
                    mediainfo_options={
                        "inform_version": "1",
                        "inform_timestamp": "1",
                    },
                )
            except Exception as e:
                raise RuntimeError(f"[ERROR] MediaInfo parse failed: {e}")
            
            try:
                await self.save_mi_text(self.mi_text_path, media_info_text)
            except Exception as e:
                raise IOError(f"[ERROR] Mediainfo Saving text file failed: {e}")

            try:
                media_info = await asyncio.to_thread(MediaInfo.parse, self.video_path)
            except Exception as e:
                raise RuntimeError(f"[ERROR] MediaInfo parse failed: {e}")

            try:
                data = json.loads(media_info.to_json())
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON from MediaInfo: {e}")

            tracks = data.get("tracks") or data.get("media", {}).get("track")

            if not tracks:
                raise ValueError("No tracks found in MediaInfo output.")

            def write_json():
                with open(self.mi_json_path, "w", encoding="utf-8") as f:
                    json.dump({"tracks": tracks}, f, indent=2)

            try:
                await asyncio.to_thread(write_json)
            except Exception as e:
                raise IOError(f"Saving JSON file failed: {e}")

            console.print("[green]✔ MediaInfo exported successfully[/green]")

        except FileNotFoundError as e:
            console.print(f"[bold red]File Error:[/bold red] {e}")
            raise

        except ValueError as e:
            console.print(f"[bold red]Data Error:[/bold red] {e}")
            raise

        except IOError as e:
            console.print(f"[bold red]IO Error:[/bold red] {e}")
            raise

        except RuntimeError as e:
            console.print(f"[bold red]Runtime Error:[/bold red] {e}")
            raise

        except Exception as e:
            console.print(f"[bold red]Unexpected Error:[/bold red] {e}")
            raise


#####################################
#     Created by -= DE3PM =-        #
#####################################
