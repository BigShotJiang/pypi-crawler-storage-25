############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import asyncio
import importlib
import importlib.util
from typing import Optional, List, Dict

import httpx


class IMDb:
    def __init__(self):
        self.imdb_api = "https://api.graphql.imdb.com/"
        self.imdb_api2 = "https://api.imdbapi.dev"

        self.headers = {
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0",
            "Origin": "https://www.imdb.com",
            "Referer": "https://www.imdb.com/",
        }
        self.client = httpx.AsyncClient(timeout=10)

    def _load_imdbinfo(self):
        if importlib.util.find_spec("imdbinfo") is None:
            return None
        return importlib.import_module("imdbinfo")

    @staticmethod
    def _clean_names(items):
        if not items:
            return []

        names = []
        for item in items:
            if isinstance(item, str):
                names.append(item.split(" (")[0])
            elif hasattr(item, "name"):
                names.append(item.name)
            elif isinstance(item, dict):
                value = item.get("displayName") or item.get("name")
                if value:
                    names.append(value)
            else:
                names.append(str(item))

        return names

    @staticmethod
    def _format_runtime_from_minutes(runtime):
        if not isinstance(runtime, int) or runtime <= 0:
            return ""
        return f"{runtime // 60}h {runtime % 60}m"

    @staticmethod
    def _format_runtime_from_seconds(runtime):
        if not isinstance(runtime, int) or runtime <= 0:
            return ""

        hours = runtime // 3600
        minutes = (runtime % 3600) // 60
        seconds = runtime % 60

        if hours:
            return f"{hours}h {minutes}min" + (f" {seconds}s" if seconds else "")
        return f"{minutes}min" + (f" {seconds}s" if seconds else "")


    async def _fetch_imdb(self, title: str, year: Optional[int]):
        constraints = [f'titleTextConstraint: {{searchTerm: "{title}"}}']

        if year:
            constraints.append(
                f"""
                releaseDateConstraint: {{
                    releaseDateRange: {{
                        start: "{year-1}-01-01",
                        end: "{year+1}-12-31"
                    }}
                }}
                """
            )

        query = {
            "query": f"""
            {{
                advancedTitleSearch(
                    first: 10,
                    constraints: {{{", ".join(constraints)}}}
                ) {{
                    edges {{
                        node {{
                            title {{
                                id
                                titleText {{ text }}
                                titleType {{ text }}
                                releaseYear {{ year }}
                            }}
                        }}
                    }}
                }}
            }}
            """
        }

        for attempt in range(3):
            try:
                r = await self.client.post(
                    self.imdb_api,
                    json=query,
                    headers=self.headers
                )
                r.raise_for_status()
                data = r.json()

                if "errors" not in data:
                    return data

            except Exception:
                await asyncio.sleep(1)

        return None

    async def _fetch_imdb2(self, title: str, year: Optional[int]):
        query = title if not year else f"{title} {year}"

        apisr_url = f"{self.imdb_api2}/search/titles"
        try:
            r = await self.client.get(
                apisr_url,
                params={"query": query}
            )
            r.raise_for_status()
            return r.json()

        except Exception:
            return None

    def _parse_imdb(self, data) -> List[Dict]:
        if not isinstance(data, dict):
            return []

        edges = data.get("data", {}).get("advancedTitleSearch", {}).get("edges", [])
        results = []

        for item in edges:
            if not isinstance(item, dict):
                continue

            title = item.get("node", {}).get("title", {})
            if not isinstance(title, dict):
                title = {}

            results.append({
                "id": title.get("id"),
                "title": (title.get("titleText") or {}).get("text"),
                "year": (title.get("releaseYear") or {}).get("year"),
                "type": ((title.get("titleType") or {}).get("text") or "").lower(),
            })

        return results
        
    def _parse_imdb2(self, data) -> List[Dict]:
        if not isinstance(data, dict):
            return []

        results = data.get("titles") or []

        parsed = []
        for item in results:
            if not isinstance(item, dict):
                continue
            parsed.append({
                "id": item.get("id"),
                "title": item.get("primary_title"),
                "year": item.get("start_year"),
                "type": (item.get("type") or "").lower(),
            })

        return parsed

    def _filter(self, results, file_type: str, year: Optional[int]):
        filtered = []

        for r in results:
            if not isinstance(r, dict):
                continue

            t = (r.get("type") or "").lower()

            if file_type == "movie":
                if "movie" not in t:
                    continue

            elif file_type == "episode":
                if not any(x in t for x in ["tv", "series"]):
                    continue

            filtered.append(r)

        if year:
            exact = [r for r in filtered if r.get("year") == year]
            if exact:
                return exact

        return filtered or results

    def _best_match(self, results, name: str, year: Optional[int]):
        if not results:
            return None

        name = name.lower()

        def score(r):
            s = 0

            title = r.get("title")
            if title:
                t = title.lower()

                if t == name:
                    s += 100
                elif name in t:
                    s += 50

            if year and r.get("year") == year:
                s += 30

            return s

        results.sort(key=score, reverse=True)
        return results[0]

    async def search(
        self,
        name: str,
        year: Optional[int | str],
        file_type: str
    ) -> Optional[str]:
        results = []

        try:
            year = int(year) if year else None
        except (TypeError, ValueError):
            year = None

        data = await self._fetch_imdb2(name, year)

        if data:
            results = self._parse_imdb2(data)
        else:
            data = await self._fetch_imdb(name, year)

            if data:
                results = self._parse_imdb(data)
            
        if not results:
            return None

        results = self._filter(results, file_type, year)
        best = self._best_match(results, name, year)

        return best.get("id") if best else None


    async def get_details(self, imdbID: str) -> dict | None:
        """
        Fetch IMDb details asynchronously using IMDb ID.
        """

        if not imdbID:
            return None

        url = f"{self.imdb_api2}/titles/{imdbID}"

        movie = None
        try:
            r = await self.client.get(url)
            r.raise_for_status()
            movie = r.json()
        except (httpx.TimeoutException, httpx.RequestError, ValueError):
            movie = None

        if not isinstance(movie, dict):
            return await self._get_details_fallback(imdbID)
            
        runtime_hms = self._format_runtime_from_seconds(movie.get("runtimeSeconds"))

        # Rating
        rating_data = movie.get("rating") if isinstance(movie.get("rating"), dict) else {}
        rating = rating_data.get("aggregateRating", "")
        votes = rating_data.get("voteCount", "")

        # Lists
        origin = movie.get("originCountries") if isinstance(movie.get("originCountries"), list) else []
        languages = movie.get("spokenLanguages") if isinstance(movie.get("spokenLanguages"), list) else []
        directors = movie.get("directors") if isinstance(movie.get("directors"), list) else []
        writers_data = movie.get("writers") if isinstance(movie.get("writers"), list) else []
        stars_data = movie.get("stars") if isinstance(movie.get("stars"), list) else []

        # Extract helpers
        country = (
            origin[0].get("name")
            if origin and isinstance(origin[0], dict)
            else ""
        )
        language = (
            languages[0].get("code")
            if languages and isinstance(languages[0], dict)
            else ""
        )

        director_names = self._clean_names(directors)
        writers = self._clean_names(writers_data)
        stars = self._clean_names(stars_data[:8])

        poster = (
            movie.get("primaryImage", {}).get("url")
            if isinstance(movie.get("primaryImage"), dict)
            else ""
        )

        return {
            "id": movie.get("id", imdbID),
            "title": movie.get("primaryTitle", ""),
            "year": movie.get("startYear", ""),
            "runtime_hms": runtime_hms,
            "genres": movie.get("genres") or [],
            "rating": rating,
            "votes": votes,
            "plot": movie.get("plot", ""),
            "poster": poster or "",
            "country": country,
            "language": language,
            "directors": director_names or "",
            "stars": stars or "",
            "writers": writers or "",
            "link": f"https://www.imdb.com/title/{imdbID}/",
            "type": (movie.get("type") or "").upper(),
        }

    async def _get_details_fallback(self, imdbID: str) -> dict | None:
        imdbinfo = self._load_imdbinfo()
        if imdbinfo is None:
            return None

        try:
            movie = await asyncio.to_thread(imdbinfo.get_movie, imdbID)
            data = movie.__dict__ if hasattr(movie, "__dict__") else {}
            if not isinstance(data, dict):
                return None
        except Exception:
            return None

        runtime_hms = self._format_runtime_from_minutes(data.get("duration"))

        return {
            "id": data.get("imdbId", imdbID),
            "title": data.get("title", ""),
            "year": data.get("year", ""),
            "runtime_hms": runtime_hms,
            "genres": data.get("genres") or [],
            "rating": data.get("rating"),
            "votes": data.get("votes"),
            "plot": data.get("plot", ""),
            "poster": data.get("cover_url", ""),
            "country": data.get("countries", []),
            "language": data.get("languages_text", []),
            "directors": self._clean_names(data.get("directors")),
            "stars": self._clean_names(data.get("stars")),
            "writers": self._clean_names((data.get("categories") or {}).get("writer")),
            "link": data.get("url", f"https://www.imdb.com/title/{imdbID}/"),
            "type": (data.get("kind") or "").upper(),
        }

    async def close(self):
        if self.client:
            await self.client.aclose()


#####################################
#     Created by -= DE3PM =-        #
#####################################
