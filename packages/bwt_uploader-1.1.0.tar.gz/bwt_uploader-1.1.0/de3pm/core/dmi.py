############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import asyncio
import json
import os
import re
from pathlib import Path
from pymediainfo import MediaInfo
from .mi import MediaInfoEx
from .ia import console
from rich.prompt import Prompt


class DescMI:
    def __init__(self, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg
        self.upload_folder = None
        self.filepath = None
        self.mi_json_path = None

    async def init(self, meta):
        self.upload_folder = meta.get('upload_folder')
        self.filepath = meta.get('filepath')
        self.mi_json_path = os.path.join(self.upload_folder, "MediaInfo.json")
        self.bd_report_path = Path(self.upload_folder) / "BDINFO_QUICK_SUMMARY.txt"
        self.mi = MediaInfoEx()
        await self.mi.init(meta)

    def _g(self, t, k, d=''):
        return t.get(k, d) if t else d

    def _get_list(self, t, k, i, d=''):
        return t.get(k, [''])[i] if t and len(t.get(k, [''])) > i else d

    async def gen_video_info(self):
        g = self._g
        get_list = self._get_list

        data = await self.mi.load_mediainfo_json()
        general_info, video_info, audio_info, text_info, chapters_info = [], [], [], [], []

        general = next((t for t in data['tracks'] if t.get('track_type') == 'General'), None)
        if general:
            general_info.append(f"File Name.............: {g(general, 'file_name_extension')}")
            general_info.append(f"Format................: {g(general, 'format')} ({g(general, 'format_version')})")
            general_info.append(f"Duration..............: {get_list(general, 'other_duration', 1)}")
            general_info.append(f"Overall Bitrate.......: {get_list(general, 'other_overall_bit_rate', 0)} {g(general, 'overall_bit_rate_mode')}")
            general_info.append(f"File Size.............: {get_list(general, 'other_file_size', 3)}")
        general_info = '\n'.join(general_info)

        video = next((t for t in data['tracks'] if t.get('track_type') == 'Video'), None)
        if video:
            if g(video, 'title'):
                video_info.append(f"Title ................: {g(video, 'title')}")
                
            video_info.append(f"Format................: {g(video, 'format')} ({g(video, 'bit_depth')} bits)")
            video_info.append(f"Format Profile........: {g(video, 'format_profile')}")
            video_info.append(f"Resolution............: {g(video, 'width')} x {g(video, 'height')}")
            video_info.append(f"Aspect Ratio..........: {get_list(video, 'other_display_aspect_ratio', 0, g(video, 'display_aspect_ratio'))}")
            
            if get_list(video, 'other_bit_rate', 0):
                video_info.append(f"Bit Rate..............: {get_list(video, 'other_bit_rate', 0)} {g(video, 'bit_rate_mode')}")
            else:
                video_info.append(f"Bit Rate..............: {g(video, 'other_bit_rate_mode')}")
            
            if g(video, 'frame_rate_mode'):
                video_info.append(f"Frame Rate............: {get_list(video, 'other_frame_rate', 0)} ({g(video, 'frame_rate_mode')})")
            else:
                video_info.append(f"Frame Rate............: {get_list(video, 'other_frame_rate', 0)}")
                
            if g(video, 'color_primaries'):
                video_info.append(f"Color Primaries.......: {g(video, 'color_primaries')}")
                
            if get_list(video, 'other_writing_library', 0):
                video_info.append(f"Encoding Library......: {get_list(video, 'other_writing_library', 0)}")
                
        video_info = '\n'.join(video_info) if video_info else ''

        audios = [t for t in data['tracks'] if t.get('track_type') == 'Audio']
        if audios:
            for i, t in enumerate(audios):
                audio_info.append(f"Track {i+1:02d}:")
                if g(t, 'title'):
                    audio_info.append(f"Title ................: {g(t, 'title')}")
                audio_info.append(f"Language..............: {get_list(t, 'other_language', 0)}")
                audio_info.append(f"Format................: {g(t, 'commercial_name', g(t, 'format'))} ({get_list(t, 'other_format', 0)})")
                
                if get_list(t, 'other_bit_rate', 0):
                    audio_info.append(f"Bitrate...............: {get_list(t, 'other_bit_rate', 0)} ({g(t, 'bit_rate_mode')}) : {get_list(t, 'other_sampling_rate', 0)}")
                else:
                    audio_info.append(f"Sampling Rate.........: {get_list(t, 'other_sampling_rate', 0)}")
                    
                audio_info.append(f"Channels..............: {g(t, 'channel_s')} channels ({g(t, 'channel_positions')})")
                
                if i < len(audios) - 1:
                    audio_info.append("")
        audio_info = '\n'.join(audio_info) if audio_info else ''

        texts = [t for t in data['tracks'] if t.get('track_type') == 'Text']
        if texts:
            for i, t in enumerate(texts):
                title = f"{g(t, 'title')} - " if g(t, 'title') else ''
                text_info.append(f"Language .............: {title}{get_list(t, 'other_language', 0)} ({g(t, 'commercial_name', g(t, 'format'))})")
                if i < len(texts) - 1:
                    text_info.append("")
        text_info = '\n'.join(text_info) if text_info else ''

        menu = next((t for t in data['tracks'] if t.get('track_type') == 'Menu'), None)
        if menu and any(k for k in menu if re.match(r'\d{2}_\d{2}_\d{5}', k)):
            chapter_keys = sorted([k for k in menu if re.match(r'\d{2}_\d{2}_\d{5}', k)])
            for i, key in enumerate(chapter_keys, 1):
                timestamp = key.replace('_', ':')[:8]
                raw_title = menu.get(key, f"Chapter {i:02d}")
                title = re.sub(r'^(?:\w{2}:|:)\s*', '', raw_title)
                chapters_info.append(f"Chapter {i:02d}...........: {timestamp} - {title}")
        chapters_info = '\n'.join(chapters_info) if chapters_info else ''

        media_info_txt = f"{self.cfg.get_nested('bbcode', 'sections', 'general')}\n[font=Courier New]\n{general_info}\n[/font]\n\n"
        media_info_txt += f"{self.cfg.get_nested('bbcode', 'sections', 'video')}\n[font=Courier New]\n{video_info}\n[/font]\n\n"
        media_info_txt += f"{self.cfg.get_nested('bbcode', 'sections', 'audio')}\n[font=Courier New]\n{audio_info}\n[/font]"
        if text_info:
            media_info_txt += f"\n\n{self.cfg.get_nested('bbcode', 'sections', 'subtitle')}\n[font=Courier New]\n{text_info}\n[/font]"
        if chapters_info:
            media_info_txt += f"\n\n{self.cfg.get_nested('bbcode', 'sections', 'chapters')}\n[font=Courier New]\n{chapters_info}\n[/font]"

        return media_info_txt

    async def gen_audio_info(self):
        
        folder = Path(self.filepath).resolve()
        if not folder.exists() or not folder.is_dir():
            console.print(f"[red]Folder not found: {folder}[/red]")
            return

        audio_exts = {'.mp3', '.flac', '.m4a', '.aac', '.ogg', '.wav', '.ac3', '.eac3'}
        audio_files = sorted([f for f in folder.iterdir() if f.suffix.lower() in audio_exts])

        if not audio_files:
            console.print("[yellow]No audio files found in this folder.[/yellow]")
            return

        lines = []
        console.print()
        confirm = Prompt.ask("[bold]You want to add audio album poster link on description?", choices=["y", "N"], case_sensitive=False)
        audio_music_album_url = ""
        
        if confirm.lower() != "n":
            audio_music_album_url = Prompt.ask("[bold] Enter your audio album poster URL:")

        if audio_music_album_url:
            lines.append(f"[center][img]{audio_music_album_url}[/img][/center]\n")

        lines.append(f"[center][b][color=red][size=4]{folder.name}[/size][/color][/b][/center]\n\n")
        lines.append("[color=YellowGreen][size=3][b]Tracks List[/b][/size][/color]\n[font=Courier New][color=Red][b]-----------[/b][/color][/font]\n")
        
        media_info_dict = {}

        for index, file in enumerate(audio_files, 1):
            media_info = await asyncio.to_thread(MediaInfo.parse, file)
            media_info_dict = json.loads(media_info.to_json())
            audio = next((t for t in media_info.tracks if t.track_type == "Audio"), None)
            general = next((t for t in media_info.tracks if t.track_type == "General"), None)

            if not audio:
                continue

            size_mb = file.stat().st_size / (1024 * 1024)
            file_size = f"{size_mb:.1f} MB"

            format_name = audio.commercial_name or audio.format or "?"
            if audio.other_format:
                format_name += f" ({audio.other_format[0]})"

            bitrate = audio.other_bit_rate[0] if audio.other_bit_rate else "?"
            bitrate_mode = audio.bit_rate_mode or ""
            bitrate_full = f"{bitrate} ({bitrate_mode})" if bitrate_mode else bitrate

            sampling_rate = (
                audio.other_sampling_rate[0] if audio.other_sampling_rate
                else f"{audio.sampling_rate / 1000:.1f} kHz" if audio.sampling_rate
                else "?"
            )

            channels = f"{audio.other_channel_s[0]}" if audio.other_channel_s else "?"
            if audio.channel_positions:
                channels += f" ({audio.channel_positions})"

            duration = general.other_duration[0] if general and general.other_duration else "?"
            title = getattr(general, "title", None) or file.stem

            lines.append(f"[b][color=yellow]{file.name} ({file_size})[/color][/b]")
            lines.append("[font=Courier New]")
            lines.append(f"Title          : {title}")
            lines.append(f"Duration       : {duration}")
            lines.append(f"Format         : {format_name}")
            lines.append(f"Bitrate        : {bitrate_full}")
            lines.append(f"Sampling Rate  : {sampling_rate}")
            lines.append(f"Channels       : {channels}")
            lines.append("------------------------------------------------------------")
            lines.append("[/font]")

        audio_des_code = "\n".join(lines)

        # Save JSON asynchronously
        await asyncio.to_thread(
            Path(self.mi_json_path).write_text,
            json.dumps(media_info_dict, indent=2),
            encoding="utf-8"
        )

        return audio_des_code

    async def gen_raw_dvd_info(self, meta):
        g = self._g
        get_list = self._get_list

        data = await self.mi.load_mediainfo_json()
        general_info, video_info, audio_info, text_info, chapters_info = [], [], [], [], []

        general = next((t for t in data['tracks'] if t.get('track_type') == 'General'), None)
        video = next((t for t in data['tracks'] if t.get('track_type') == 'Video'), None)
        
        if general:
            general_info.append(f"File Name.............: {meta.get('filename')}")
            general_info.append(f"Format................: {g(general, 'format')}")
            general_info.append(f"Duration..............: {get_list(general, 'other_duration', 1)}")
            
            if video and get_list(video, 'other_bit_rate', 0):
                general_info.append(f"Overall Bitrate.......: {get_list(general, 'other_overall_bit_rate', 0)} {g(general, 'overall_bit_rate_mode')}")
                
            general_info.append(f"File Size.............: {meta.get('dvd_size')}")
            
        general_info = '\n'.join(general_info)

        if video:
            if g(video, 'title'):
                video_info.append(f"Title ................: {g(video, 'title')}")
                
            if g(video, 'bit_depth'):
                video_info.append(f"Format................: {g(video, 'format')} ({g(video, 'bit_depth')} bits)")
            else:
                video_info.append(f"Format................: {g(video, 'format')}")
                
            if g(video, 'format_profile'):
                video_info.append(f"Format Profile........: {g(video, 'format_profile')}")
                
            video_info.append(f"Resolution............: {g(video, 'width')} x {g(video, 'height')}")
            
            video_info.append(f"Aspect Ratio..........: {get_list(video, 'other_display_aspect_ratio', 0, g(video, 'display_aspect_ratio'))}")
            
            if get_list(video, 'other_bit_rate', 0):
                video_info.append(f"Bit Rate..............: {get_list(video, 'other_bit_rate', 0)} {g(video, 'bit_rate_mode')}")
            else:
                video_info.append(f"Bit Rate..............: {g(video, 'other_bit_rate_mode', 0)}")
                
            if g(video, 'frame_rate_mode'):
                video_info.append(f"Frame Rate............: {get_list(video, 'other_frame_rate', 0)} ({g(video, 'frame_rate_mode')})")
            else:
                video_info.append(f"Frame Rate............: {get_list(video, 'other_frame_rate', 0)}")
                
            if g(video, 'color_primaries'):
                video_info.append(f"Color Primaries.......: {g(video, 'color_primaries')}")
                
            if get_list(video, 'other_writing_library', 0):
                video_info.append(f"Encoding Library......: {get_list(video, 'other_writing_library', 0)}")
                
        video_info = '\n'.join(video_info) if video_info else ''

        audios = [t for t in data['tracks'] if t.get('track_type') == 'Audio']
        if audios:
            for i, t in enumerate(audios):
                audio_info.append(f"Track {i+1:02d}:")
                if g(t, 'title'):
                    audio_info.append(f"Title ................: {g(t, 'title')}")
                if get_list(t, 'other_language', 0):
                    audio_info.append(f"Language..............: {get_list(t, 'other_language', 0)}")
                else:
                    audio_info.append(f"Language..............: Hindi")
                
                audio_info.append(f"Format................: {g(t, 'commercial_name', g(t, 'format'))} ({get_list(t, 'other_format', 0)})")
                
                if get_list(t, 'other_bit_rate', 0):
                    audio_info.append(f"Bitrate...............: {get_list(t, 'other_bit_rate', 0)} ({g(t, 'bit_rate_mode')}) : {get_list(t, 'other_sampling_rate', 0)}")
                else:
                    audio_info.append(f"Sampling Rate.........: {get_list(t, 'other_sampling_rate', 0)}")

                if g(t, 'channel_positions'):
                    audio_info.append(f"Channels..............: {g(t, 'channel_s')} channels ({g(t, 'channel_positions')})")
                else:
                    audio_info.append(f"Channels..............: {g(t, 'channel_s')} channels")
                    
                if i < len(audios) - 1:
                    audio_info.append("")
        audio_info = '\n'.join(audio_info) if audio_info else ''

        texts = [t for t in data['tracks'] if t.get('track_type') == 'Text']
        if texts:
            for i, t in enumerate(texts):
                title = f"{g(t, 'title')} - " if g(t, 'title') else ''
                text_info.append(f"Language .............: {title}{get_list(t, 'other_language', 0)} ({g(t, 'commercial_name', g(t, 'format'))})")
                if i < len(texts) - 1:
                    text_info.append("")
        text_info = '\n'.join(text_info) if text_info else ''

        menu = next((t for t in data['tracks'] if t.get('track_type') == 'Menu'), None)
        if menu and any(k for k in menu if re.match(r'\d{2}_\d{2}_\d{5}', k)):
            chapter_keys = sorted([k for k in menu if re.match(r'\d{2}_\d{2}_\d{5}', k)])
            for i, key in enumerate(chapter_keys, 1):
                timestamp = key.replace('_', ':')[:8]
                raw_title = menu.get(key, f"Chapter {i:02d}")
                title = re.sub(r'^(?:\w{2}:|:)\s*', '', raw_title)
                chapters_info.append(f"Chapter {i:02d}...........: {timestamp} - {title}")
        chapters_info = '\n'.join(chapters_info) if chapters_info else ''

        media_info_txt = f"{self.cfg.get_nested('bbcode', 'sections', 'general')}\n[font=Courier New]\n{general_info}\n[/font]\n\n"
        media_info_txt += f"{self.cfg.get_nested('bbcode', 'sections', 'video')}\n[font=Courier New]\n{video_info}\n[/font]\n\n"
        media_info_txt += f"{self.cfg.get_nested('bbcode', 'sections', 'audio')}\n[font=Courier New]\n{audio_info}\n[/font]"
        if text_info:
            media_info_txt += f"\n\n{self.cfg.get_nested('bbcode', 'sections', 'subtitle')}\n[font=Courier New]\n{text_info}\n[/font]"
        if chapters_info:
            media_info_txt += f"\n\n{self.cfg.get_nested('bbcode', 'sections', 'chapters')}\n[font=Courier New]\n{chapters_info}\n[/font]"

        return media_info_txt

    async def gen_raw_bluray_info(self, meta):
        """
        Generate BDInfo output for Blu-ray sources
        """
        try:
            if not self.bd_report_path.exists():
                console.print("[bold red]BDInfo output file not created.[/bold red]")
                return None

            bdinfo_txt = self.bd_report_path.read_text(encoding="utf-8", errors="ignore")

            if not bdinfo_txt.strip():
                console.print("[red]BDInfo output is empty.[/red]")
                return None

            bdinfo_des_code = (
                f"[font=pre]\n{bdinfo_txt}\n[/font]"
            )

            return bdinfo_des_code

        except Exception as e:
            console.print(f"[red]BDInfo failed: {e}[/red]")
            return None

    async def process(self, meta):
        try:
            await self.init(meta)
        except Exception:
            console.print("[red]Metadata loading failed.[/red]")
            return None

        if meta.get("raw_dvd"):
            return await self.gen_raw_dvd_info(meta)
            
        elif meta.get("raw_bluray"):
            return await self.gen_raw_bluray_info(meta)
            
        elif meta.get("video_media"):
            return await self.gen_video_info()
            
        elif meta.get("type") == "music":
            return await self.gen_audio_info()
        else:
            console.print("[red]No valid media type found in metadata.[/red]")
            return None            

#####################################
#     Created by -= DE3PM =-        #
#####################################
