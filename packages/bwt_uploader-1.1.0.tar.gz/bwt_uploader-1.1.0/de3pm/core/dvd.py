############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import os
import json
import asyncio
from pathlib import Path
from collections import OrderedDict
from pymediainfo import MediaInfo

from .ia import console


class DVDInfo:

    def __init__(self):
        self.dvd_path = None
        self.output_folder = None

        self.dvd_txt = None
        self.vob_txt = None
        self.dvd_json = None
        self.vob_json = None

        self.data = None


    async def init(self, meta):
        """
        Initialize from meta dict
        """
        self.dvd_path = meta.get("dvd_path")
        self.output_folder = meta.get("upload_folder")

        if not self.dvd_path or not os.path.isdir(self.dvd_path):
            raise FileNotFoundError(f"Invalid DVD path: {self.dvd_path}")

        self.output_folder = Path(self.output_folder)
        self.output_folder.mkdir(parents=True, exist_ok=True)

        self.dvd_txt = self.output_folder / "DVDInfo.txt"
        self.vob_txt = self.output_folder / "VOBInfo.txt"
        self.dvd_json = self.output_folder / "DVDInfo.json"
        self.vob_json = self.output_folder / "VOBInfo.json"


    async def _parse_json(self, file):
        def run():
            mi = MediaInfo.parse(file)
            return json.loads(mi.to_json())

        return await asyncio.to_thread(run)


    async def _parse_text(self, file):
        return await asyncio.to_thread(
            MediaInfo.parse,
            file,
            output="STRING",
            full=False,
            mediainfo_options={
                "inform_version": "1",
                "inform_timestamp": "1",
            },
        )


    async def scan_titles(self):
        """
        Group VOB files into title sets
        """
        files = sorted(Path(self.dvd_path).glob("VTS_*.VOB"))

        if not files:
            raise FileNotFoundError("No VOB files found in DVD path")

        groups = OrderedDict()

        for f in files:
            key = f.name[4:6]
            groups.setdefault(key, []).append(f)

        return groups


    async def find_main_title(self, groups):
        main_key = None
        main_duration = 0
        
        for key, vob_set in groups.items():
            ifo = Path(self.dvd_path) / f"VTS_{key}_0.IFO"
            
            if not ifo.exists():
                continue
            try:
                data = await self._parse_json(str(ifo))
                tracks = data.get("tracks", [])
                
                for t in tracks:
                    if t.get("track_type") == "General" and "duration" in t:
                        duration = float(t["duration"])            
                    else:
                        continue
            
            except Exception as e:
                print(f"[WARN] {ifo} failed: {e}")
                continue
                
            # Same logic as your original code
            if (duration * 1.00) > (main_duration * 1.10) or main_key is None:
                main_key = key
                main_duration = duration
        
        if main_key is None:
            raise RuntimeError("Failed to determine main title")
        
        return main_key

    async def get_dvd_size(self):
        total = sum(
            f.stat().st_size
            for f in Path(self.dvd_path).glob("*")
            if f.is_file()
        )

        size_gb = total / (1 << 30)

        if size_gb <= 4.37:
            return "DVD5"
        elif size_gb <= 7.95:
            return "DVD9"
        else:
            return "DVD"


    async def extract(self):
        """
        Extract DVD + VOB info
        """
        console.print()
        console.print("[bold yellow]➤ Exporting DVDInfo...")
        groups = await self.scan_titles()
        main_key = await self.find_main_title(groups)

        vob = Path(self.dvd_path) / f"VTS_{main_key}_1.VOB"
        ifo = Path(self.dvd_path) / f"VTS_{main_key}_0.IFO"

        # --- TEXT ---
        vob_text = await self._parse_text(str(vob))
        ifo_text = await self._parse_text(str(ifo))

        # --- JSON ---
        vob_json = await self._parse_json(str(vob))
        ifo_json = await self._parse_json(str(ifo))

        # --- SAVE TEXT ---
        def write_text():
            with open(self.vob_txt, "w", encoding="utf-8") as f:
                f.write(vob_text)

            with open(self.dvd_txt, "w", encoding="utf-8") as f:
                f.write(ifo_text)

        await asyncio.to_thread(write_text)

        # --- SAVE JSON ---
        def write_json():
            with open(self.vob_json, "w", encoding="utf-8") as f:
                json.dump(vob_json, f, indent=2)

            with open(self.dvd_json, "w", encoding="utf-8") as f:
                json.dump(ifo_json, f, indent=2)

        await asyncio.to_thread(write_json)
        
        console.print("[bold green]✔ DVDInfo exported successfully...")


#####################################
#     Created by -= DE3PM =-        #
#####################################
