############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import aiofiles
import asyncio
from pathlib import Path
from rich.prompt import Prompt

from .ia import console
from .dmi import DescMI
from .st import Signature


class Descr:

    def __init__(self, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg

        self.template = None
        self.details_bbcode_template = None
        self.upload_folder = None
        self.filename = None

        self.info_banner = None
        self.description_bbcode_path = None
        self.screenshot_links = None
        
    async def setup(self, meta):
        self.template = self.cfg.bbcode_template
        self.details_bbcode_template = self.cfg.details_bbcode_template

        self.mediainfo_banner = self.cfg.get_nested('bbcode', 'mediainfo_banner')
        self.bdinfo_banner = self.cfg.get_nested('bbcode', 'bdinfo_banner')
        self.dvdinfo_banner = self.cfg.get_nested('bbcode', 'dvdinfo_banner')

        self.imdb_and_tmdb_info = self.cfg.get_nested("imdb_and_tmdb_info")

        self.filename = meta.get("filename")
        self.upload_folder = Path(meta.get("upload_folder"))

        self.description_bbcode_path = self.upload_folder / "[BBCode]Torrent_Description.txt"
        self.screenshot_links = self.upload_folder / "screenshots/uploaddata/bbcode_medium.txt"

        # --- Validate templates early ---
        if not self.template:
            raise ValueError("BBCode template not loaded")

        if not self.details_bbcode_template:
            console.print("[yellow]⚠ Details template missing, fallback will be used[/yellow]")

    async def generate(self, meta):
        await self.setup(meta)

        if not self.upload_folder or not self.upload_folder.exists():
            console.print("[bold red]⚠ Upload folder not found.[/bold red]")
            return

        mi = DescMI(self.cfg)

        # ---------------- DETERMINE TYPE ----------------
        media_type = meta.get("type")

        # ---------------- SET BANNER ----------------
        if meta.get("raw_bluray"):
            self.info_banner = self.bdinfo_banner

        elif meta.get("raw_dvd"):
            self.info_banner = self.dvdinfo_banner

        elif meta.get("video_media"):
            self.info_banner = self.mediainfo_banner

        # ---------------- VIDEO ----------------
        if media_type == "video":

            meta = meta if isinstance(meta, dict) else {}
            tmdb_data = meta.get("tmdb") or {}
            imdb_data = meta.get("imdb") or {}

            has_tmdb = bool(tmdb_data and tmdb_data.get("title"))
            has_imdb = bool(imdb_data and imdb_data.get("title"))

            movie_poster_url = None

            # --- Poster selection ---
            if has_tmdb:
                movie_poster_url = tmdb_data.get("poster")
            elif has_imdb:
                movie_poster_url = imdb_data.get("poster")

            # --- Optional fallback prompt ---
            if not movie_poster_url:
                console.print("[yellow]⚠ No poster found in TMDB/IMDB[/yellow]")
                try:
                    movie_poster_url = await asyncio.to_thread(
                        Prompt.ask,
                        "[bold]Enter poster URL (or leave blank):[/bold]",
                        default=""
                    )
                except Exception:
                    movie_poster_url = ""

            # --- Header generation ---
            if (has_tmdb or has_imdb) and self.imdb_and_tmdb_info:
                header_bbcode = await self.desc_itf(meta)
            else:
                header_bbcode = f"[center][img]{movie_poster_url}[/img][/center]" if movie_poster_url else ""

            # --- Screenshot validation ---
            if not self.screenshot_links.exists() or self.screenshot_links.stat().st_size == 0:
                console.print(f"[bold red]⚠ Screenshot file missing or empty:[/bold red] {self.screenshot_links}")
                return

            # --- Read screenshots ---
            async with aiofiles.open(self.screenshot_links, "r", encoding="utf-8") as f:
                screenshot_bbcode = (await f.read()).strip()

            # --- MediaInfo ---
            media_bbcode = await mi.process(meta)

            # --- Final content ---
            content = self.template.strip().format(
                detailed_info=header_bbcode,
                file_name=self.filename,
                info_banner=self.info_banner or "",
                media_info=media_bbcode,
                screenshot_bbcode=screenshot_bbcode,
            )

            await self._write_description(content)
            return

        # ---------------- AUDIO ----------------
        if media_type == "music":
            audio_bbcode = await mi.process(meta)
            await self._write_description(audio_bbcode)
            return

        console.print("[bold yellow]⚠ Nothing matched for description generation.[/bold yellow]")

    async def _write_description(self, content: str):
        try:
            async with aiofiles.open(self.description_bbcode_path, "w", encoding="utf-8") as f:
                await f.write(content)
                await f.write(str(Signature))
        except Exception as e:
            console.print(f"[bold red]⚠ Write failed:[/bold red] {e}")

    def _color_rating(self, r):
        try:
            r_float = float(r)
            if r_float >= 7:
                return f"[color=#90EE90]{r_float}[/color]"
            elif r_float >= 5:
                return f"[color=#FFD580]{r_float}[/color]"
            else:
                return f"[color=red]{r_float}[/color]"
        except (ValueError, TypeError):
            return r

    async def desc_itf(self, meta):
        
        if not meta:
            return "[b]Error: Database details extract error.[/b]"
            
        if not self.details_bbcode_template:
            return "[b]Error: No detailed template available[/b]"

        category_type = meta.get("category_type")
        tmdb = meta.get("tmdb") or {}
        imdb = meta.get("imdb") or {}

        title = tmdb.get("title") or imdb.get("title") or "N/A"
        year = tmdb.get("year") or imdb.get("year") or "N/A"
        overview = tmdb.get("overview") or imdb.get("plot") or "N/A"
        genres = ", ".join(tmdb.get("genres") or imdb.get("genres") or []) or "N/A"
        category = imdb.get("type", "N/A")

        release_date = tmdb.get("release_date") or imdb.get("year") or "N/A"

        imdb_rating = self._color_rating(imdb.get("rating")) or "N/A"
        imdb_votes = imdb.get("votes")
        imdb_link = imdb.get("link", "#")

        tmdb_rating = self._color_rating(tmdb.get("rating")) or "N/A"
        tmdb_votes = tmdb.get("votes")
        tmdb_link = tmdb.get("tmdb_link", "#")
        tvdb_id = meta.get("tvdbID") or tmdb.get("tvdb_id")
        tvdb_link = f"https://www.thetvdb.com/?id={tvdb_id}&tab=series" if tvdb_id else "#"

        if category_type == "tv":
            runtime = "N/A"
        else:
            runtime = tmdb.get("runtime_hms") or imdb.get("runtime_hms") or "N/A"

        imdb_votes = f"({imdb_votes:,} votes)" if isinstance(imdb_votes, int) else ""
        tmdb_votes = f"({tmdb_votes:,} votes)" if isinstance(tmdb_votes, int) else ""

        tmdb_cast = [a.get("name") for a in tmdb.get("stars", []) if a.get("name")]
        cast = ", ".join(tmdb_cast[:8]) or ", ".join(imdb.get("stars", [])) or "N/A"

        director = ", ".join(tmdb.get("directors", []) or imdb.get("directors", []) or []) or "N/A"
        writers = ", ".join(tmdb.get("writers", []) or imdb.get("writers", []) or []) or "N/A"

        poster = tmdb.get("poster") or imdb.get("poster") or \
                 "https://upload.wikimedia.org/wikipedia/commons/1/14/No_Image_Available.jpg"

        imdb_btn = f"[url={imdb_link}][img]https://i.ibb.co/YTy9tvMn/IMDb.png[/img][/url]" if imdb_link != "#" else ""
        tmdb_btn = f"[url={tmdb_link}][img]https://i.ibb.co/0ymgXFSz/TMDb.png[/img][/url]" if tmdb_link != "#" else ""
        tvdb_btn = f"[url={tvdb_link}][img]https://i.ibb.co/PzMrvxgF/TVDb.png[/img][/url]" if tvdb_link != "#" else ""
        dblink_button = "       ".join([btn for btn in [imdb_btn, tmdb_btn, tvdb_btn] if btn]).strip()

        return self.details_bbcode_template.strip().format(
            title=title,
            year=year,
            poster=poster,
            dblinks=dblink_button,
            genres=genres,
            release_date=release_date,
            runtime=runtime,
            category=category,
            cast=cast,
            director=director,
            writers=writers,
            imdb_rating=imdb_rating,
            imdb_votes=imdb_votes,
            tmdb_rating=tmdb_rating,
            tmdb_votes=tmdb_votes,
            overview=overview
        )
        

#####################################
#     Created by -= DE3PM =-        #
#####################################
