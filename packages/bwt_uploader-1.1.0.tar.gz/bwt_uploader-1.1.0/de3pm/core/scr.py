############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


from .gsr import ScreenshotGenerator
from .usr import ScreenshotUploader


class Screens:
    def __init__(self, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg

        self.generator = ScreenshotGenerator(self.cfg)
        self.uploader = ScreenshotUploader(self.cfg)

    async def init(self, meta):
        await self.generator.init(meta)
        await self.uploader.init(meta)

    async def gen_scr(self):
        await self.generator.gen_scr()

    async def up_ims(self):
        await self.uploader.up_ims()


#####################################
#     Created by -= DE3PM =-        #
#####################################
