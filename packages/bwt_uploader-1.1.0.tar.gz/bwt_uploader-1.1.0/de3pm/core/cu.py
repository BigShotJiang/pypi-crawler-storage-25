
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import sys
import aiohttp
import base64
import json
import time
from packaging import version
from datetime import datetime

from .ia import console
from .gt import gtoken
from .vs import app_version


class CheckUp:
    def __init__(
        self,
        cfg=None,
        repo="xDE3PM/bwt-api-key",
        path="version.json",
        branch="main",
        token=gtoken,
        timeout=5,
        cache_ttl=500
    ):
        self.repo = repo
        self.path = path
        self.branch = branch
        self.token = token
        self.timeout = timeout

        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg
        self.username = self.cfg.get_nested("BWTorrents", "username")

        self._cache_data = None
        self._cache_time = 0
        self.cache_ttl = cache_ttl

    def get_local_version(self):
        return app_version

    async def get_json(self, force_refresh=False):
        if (
            not force_refresh and
            self._cache_data and
            (time.time() - self._cache_time < self.cache_ttl)
        ):
            return self._cache_data

        api_url = f"https://api.github.com/repos/{self.repo}/contents/{self.path}"

        headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "BWT-Updater"
        }

        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        try:
            timeout = aiohttp.ClientTimeout(total=self.timeout)

            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(
                    api_url,
                    headers=headers,
                    params={"ref": self.branch}
                ) as r:

                    if r.status != 200:
                        console.print("[bold red]Failed to fetch remote version data.[/bold red]")
                        return None

                    data = await r.json()
                    content = data.get("content")

                    if not content:
                        raise Exception("No content found in GitHub response")

                    decoded = base64.b64decode(content).decode("utf-8")
                    parsed = json.loads(decoded)

                    self._cache_data = parsed
                    self._cache_time = time.time()

                    return parsed

        except Exception as e:
            console.print(f"[bold red]{e}[/bold red]")
            return None

    async def che_f_ups(self):
        data = await self.get_json()
        if not data:
            console.print("[bold red]Error: Unexpected Error Occurred! \nContact @DE3PM for support.[/bold red]")
            sys.exit(1)

        local_version = self.get_local_version()
        remote_version = data.get("latest")

        if not local_version:
            console.print("[bold red]Could not determine local version.[/bold red]")
            return False

        if not remote_version:
            console.print("[bold yellow]Could not check for updates.[/bold yellow]")
            return False

        # Access check
        access_ok = await self.check_access(data, self.username)
        if not access_ok:
            console.print(f"[yellow]Hi {self.username},[/yellow]")
            console.print("[bold red]Error (Access): Unexpected Error Occurred! \nContact @DE3PM for support.[/bold red]")
            sys.exit(1)

        # Update check
        if version.parse(remote_version) > version.parse(local_version):
            console.print(
                f"[red][NOTICE] [green]Update available: v[/green][yellow]{remote_version}"
            )
            console.print(
                f"[red][NOTICE] [green]Current version: v[/green][yellow]{local_version}\n"
            )
            
            if data.get("forceUpdate"):
                console.print("[bold red]Update required. Please update to continue.[/bold red]")
                sys.exit(1)
                
            return True

        return False

    async def check_access(self, data, username):
        
        versions = data.get("versions", [])
        users = data.get("users", [])

        for v in versions:
            if v.get("version") == app_version:
                access = v.get("access", {})

                # If no restriction → allow
                if not access.get("required", False):
                    return True

                # Check user in global list
                for user in users:
                    if user.get("username") == username and user.get("key"):

                        # Expiry check
                        if "expires" in user:
                            exp = datetime.strptime(user["expires"], "%Y-%m-%d")
                            if datetime.now() > exp:
                                console.print("[bold red]Error (Access): Your access has expired.[/bold red]")
                                return False

                        return True

                # User not found
                return False

        # Version not found
        return False
        
###############
# -= DE3PM =- #
###############
