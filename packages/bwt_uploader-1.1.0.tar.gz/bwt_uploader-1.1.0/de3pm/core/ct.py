
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import subprocess
import shutil
from pathlib import Path

from .ia import console
from .ex import error_exit
from ..bin import MkBrrInstaller


class Torrent:

    def __init__(self, binary: str | None = None, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg

        self.tracker = self.cfg.get_nested("BWTorrents", "announce_url")

        self.mkbrr_binary = binary
        self._installer = MkBrrInstaller()
      
        self.fmeta = None
        self.input_filepath = None
        self.output_torrent = None
        self.piece_size_length = None


    async def _load_file_info(self, meta):

        self.input_filepath = Path(meta.get("filepath"))
        self.output_torrent = Path(meta.get("torrent_path"))
        self.piece_size_length = meta.get("piece_length")


    async def _ensure_binary(self):

        if self.mkbrr_binary and Path(self.mkbrr_binary).exists():
            return
        
        path_binary = shutil.which("mkbrr")
        if path_binary:
            self.mkbrr_binary = path_binary
            return
        
        self.mkbrr_binary = await self._installer.install()
        
        if not self.mkbrr_binary or not Path(self.mkbrr_binary).exists():
            raise RuntimeError("mkbrr binary not found after installation")

    def _validate_paths(self):

        if not self.input_filepath.exists():
            console.print("[bold red]✘ Input file/folder not found")
            error_exit()

        if self.output_torrent.exists():
            console.print("[bold green]✔ Torrent already exists — skipping")
            return False

        return True


    async def create(self, meta):

        await self._load_file_info(meta)
        await self._ensure_binary()

        if not self._validate_paths():
            return

        console.print("[bold yellow]➤ Creating torrent...")

        try:
            cmd = [
                self.mkbrr_binary,
                "create",
                str(self.input_filepath),
                "--private",
                "-t", self.tracker,
                "-o", str(self.output_torrent),
            ]

            if self.piece_size_length:
                if 16 <= self.piece_size_length <= 27:
                    console.print(f"[bold]➤ Piece Size Length : {self.piece_size_length}")
                    cmd.extend(["--piece-length", str(self.piece_size_length)])
                else:
                    console.print("[bold yellow]⚠ Invalid piece length — using mkbrr default")

            # Create Torrent 
            subprocess.run(cmd, check=True)

        except Exception as e:
            console.print(f"[bold red]✘ Execution error : {e}")
            error_exit()

        if not self.output_torrent.exists():
            console.print("[bold red]✘ Torrent file not created")
            error_exit()

        try:
            await self._installer.myto(str(self.output_torrent))
        except Exception:
            pass

        console.print("[bold green]✔ Torrent created successfully")
        
#####################################
#     Created by -= DE3PM =-        #
#####################################
