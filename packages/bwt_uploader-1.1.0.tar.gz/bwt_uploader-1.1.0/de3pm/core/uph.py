############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import os
import sys
import asyncio
import shlex
from typing import Dict, Any
from rich.table import Table
from rich.panel import Panel
from rich import box
from rich.prompt import Prompt
from .ia import console
from .ex import error_exit


class MetadataError(Exception):
    """Custom metadata exception."""
    pass


class MediaPrinter:
    """
    Metadata Display System
    Handles video and music upload confirmation
    """

    def __init__(self, meta: Dict[str, Any]):
        if not isinstance(meta, dict):
            raise MetadataError("Metadata must be a dictionary.")

        self.meta = meta
        self.video_media = meta.get("video_media", False)
        self.raw_bluray = meta.get("raw_bluray", False)
        self.audio_music = meta.get("audio_music", False)

    @staticmethod
    def safe_exit(code: int = 1, message: str = "Process terminated."):
        console.print(f"[bold red]{message}[/bold red]")
        sys.exit(code)

    async def confirm(self, question: str) -> bool:
        """Async confirmation prompt"""
        answer = await asyncio.to_thread(
            Prompt.ask,
            f"[bold]{question}",
            choices=["y", "N"],
            case_sensitive=False,
        )
        return answer.lower() == "y"

    async def _print_video_info(self) -> None:
        imdb = self.meta.get("imdb") or {}
        tmdb = self.meta.get("tmdb") or {}

        if not imdb and not tmdb:
            console.print("[bold red]No TMDb or IMDb data found.[/bold red]")
            if not await self.confirm("Continue to upload without database info?"):
                error_exit()
            return

        title = tmdb.get("title") or imdb.get("title") or "N/A"
        year = tmdb.get("year") or imdb.get("year") or "N/A"
        overview = tmdb.get("overview") or imdb.get("plot") or "N/A"
        genres = ", ".join(tmdb.get("genres") or imdb.get("genres") or []) or "N/A"
        category = imdb.get("type", "N/A")
        imdb_rating = imdb.get("rating", "N/A")
        imdb_link = imdb.get("link", "N/A")
        tmdb_rating = tmdb.get("rating", "N/A")
        tmdb_link = tmdb.get("tmdb_link", "N/A")

        content = (
            f"[bold yellow]Title:[/bold yellow] {title} ({year})\n\n"
            f"[bold green]Overview:[/bold green] {overview}\n\n"
            f"[bold magenta]Genre:[/bold magenta] {genres}\n\n"
            f"[bold blue]Category:[/bold blue] {category}\n\n"
            f"[bold yellow]IMDb Rating:[/bold yellow] {imdb_rating}/10\n"
            f"[bold yellow]IMDb Link:[/bold yellow] {imdb_link}\n\n"
            f"[bold green]TMDb Rating:[/bold green] {tmdb_rating}/10\n"
            f"[bold green]TMDb Link:[/bold green] {tmdb_link}"
        )

        console.print()
        console.print(
            Panel(
                content,
                title="Database Information",
                border_style="cyan",
                padding=(1, 2),
                expand=True
            )
        )

        console.print()
        if not await self.confirm("Is this Database Information correct?"):
            return await self._ask_database_override()

        return None

    async def _ask_database_override(self):
        console.print("[bold yellow]Use --imdb/-i <id> or --tmdb/-t <id>[/bold yellow]")
        
        while True:
            raw = await asyncio.to_thread(Prompt.ask, "[bold]>[/bold]")
            tokens = shlex.split((raw or "").strip())

            if len(tokens) != 2 or tokens[0] not in {"--imdb", "-i", "--tmdb", "-t"}:
                console.print("[bold red]Invalid format. Example: --imdb tt1234567 or --tmdb 12345[/bold red]")
                continue

            key, value = tokens

            if key in {"--imdb", "-i"}:
                imdb_id = value if value.startswith("tt") else f"tt{value}"
                return {"imdbID": imdb_id, "tmdbID": None, "tvdbID": None}

            try:
                tmdb_id = int(value)
            except ValueError:
                console.print("[bold red]TMDb id must be numeric.[/bold red]")
                continue

            return {"tmdbID": tmdb_id, "imdbID": None, "tvdbID": None}

    def _scan_audio_files(self, folder: str, max_files: int):
        """Runs file scanning in thread"""
        files_data = []
        file_count = 0
        total_size = 0.0

        for root, _, files in os.walk(folder):
            for file in sorted(files):
                if file_count >= max_files:
                    break

                path = os.path.join(root, file)

                try:
                    size_mb = os.path.getsize(path) / (1024 * 1024)
                except OSError:
                    size_mb = 0.0

                total_size += size_mb
                file_count += 1

                files_data.append((file_count, file, size_mb))

            if file_count >= max_files:
                break

        return files_data, file_count, total_size

    async def _print_audio_info(self, max_files: int = 50) -> None:
        folder = self.meta.get("filepath")

        if not folder:
            raise MetadataError("Audio folder path missing in metadata.")

        if not os.path.exists(folder):
            raise MetadataError("Audio folder does not exist.")

        files_data, file_count, total_size = await asyncio.to_thread(
            self._scan_audio_files, folder, max_files
        )

        table = Table(
            title="Audio Track List",
            box=box.ROUNDED,
            show_lines=False
        )

        table.add_column("No.", style="cyan", justify="right")
        table.add_column("File Name", style="yellow")
        table.add_column("Size (MiB)", style="green", justify="right")

        for num, name, size in files_data:
            table.add_row(str(num), name, f"{size:.2f}")

        console.print()
        console.print(table)
        console.print(
            f"\n[bold]Total Tracks:[/bold] {file_count} | "
            f"[bold]Total Size:[/bold] {total_size:.2f} MiB\n"
        )

        if not await self.confirm("Do you want to upload this music album?"):
            error_exit()

    async def run(self):
        try:
            if self.meta.get("type") == "video":
                return await self._print_video_info()

            elif self.audio_music:
                await self._print_audio_info()
                return None

            else:
                raise MetadataError("No valid media type detected.")

        except MetadataError as e:
            self.safe_exit(message=str(e))

        except Exception as e:
            self.safe_exit(message=f"Unexpected error: {str(e)}")


#####################################
#     Created by -= DE3PM =-        #
#####################################
