
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import os
import re
import json
import asyncio
from pathlib import Path

class MediaInfoEx:

    def __init__(self):
        self.upload_folder = None
        self.mi_json_path = None
        self.meta_json_path = None
        self.raw_bluray = False

        self.data = None
        self._tracks = None


    async def init(self, meta):
        self.upload_folder = meta.get("upload_folder")
        self.raw_bluray = bool(meta.get("raw_bluray"))
        json_file = "DVDInfo.json" if meta.get("raw_dvd") else "MediaInfo.json"
        self.mi_json_path = str(Path(self.upload_folder) / json_file)
        self.meta_json_path = str(Path(self.upload_folder) / "meta.json")
        self.report_path = Path(self.upload_folder) / "BDINFO_QUICK_SUMMARY.txt"
        

    async def parse_quick_summary(self):
        
        if not self.report_path.exists():
            return None

        text = await asyncio.to_thread(
            self.report_path.read_text, encoding="utf-8", errors="ignore"
        )

        resolution_match = re.search(r'(\d{3,4})p', text)
        langs = re.findall(r'Audio:\s*([A-Za-z]+)\s*/', text)

        # HDR detection
        hdr_match = re.search(
            r'\b(HDR10\+?|HDR|Dolby\s*Vision|DV)\b',
            text,
            re.IGNORECASE
        )

        media = {}

        if resolution_match:
            media["resolution"] = resolution_match.group(1)

        if hdr_match:
            media["hdr"] = True

        if langs:
            media["fast_audio"] = langs[0].strip().lower()

            if any(lang.lower() == "hindi" for lang in langs):
                media["hindi_audio"] = True

        return {"media": media} if media else None
        
    async def load_json(self):
        """
        Loads mediainfo JSON safely
        """

        if not os.path.exists(self.mi_json_path):
            raise FileNotFoundError(f"MediaInfo JSON not found: {self.mi_json_path}")

        def read_json():
            with open(self.mi_json_path, "r", encoding="utf-8") as f:
                return json.load(f)

        try:
            return await asyncio.to_thread(read_json)

        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in {self.mi_json_path}: {e}")

        except Exception as e:
            raise RuntimeError(f"Failed to read MediaInfo JSON: {e}")

    async def load_mediainfo_json(self):
        """
        Backward-compatible alias used across the project.
        """
        return await self.load_json()


    async def mi_tracks(self):
        """
        Returns normalized track list
        """
        if self._tracks is not None:
            return self._tracks

        self.data = await self.load_json()

        tracks = (
            self.data.get("tracks")
            or self.data.get("media", {}).get("track")
            or self.data.get("MediaInfo", {}).get("media", {}).get("track")
        )

        if not tracks:
            raise ValueError("No track data found in MediaInfo JSON.")

        self._tracks = tracks
        return self._tracks


    async def get_track(self, track_type: str):
        tracks = await self.mi_tracks()

        return next(
            (
                t
                for t in tracks
                if t.get("track_type") == track_type
                or t.get("@type") == track_type
            ),
            {},
        )


    async def get_tracks(self, track_type: str):
        tracks = await self.mi_tracks()

        return [
            t
            for t in tracks
            if t.get("track_type") == track_type
            or t.get("@type") == track_type
        ]


    async def fast_lang_code(self, track_type: str = "Audio"):
        tracks = await self.get_tracks(track_type)

        if not tracks:
            return None

        t = tracks[0]

        lang = (
            t.get("language")
            or t.get("Language")
            or (t.get("other_language") or [None])[0]
        )

        if not lang:
            return None

        return str(lang).strip().lower()


    async def has_hindi_audio(self):
        hindi_codes = {"hi", "hin", "hindi"}

        lang = await self.fast_lang_code("Audio")

        if not lang:
            return False

        return lang in hindi_codes

    async def is_hdr_video(self):
        """
        Detect HDR video from MediaInfo video track fields.
        """
        video = await self.get_track("Video")
        if not video:
            return False

        hdr_candidates = [
            video.get("hdr_format"),
            video.get("HDR_Format"),
            video.get("hdr_format_version"),
            video.get("HDR_Format_Version"),
            video.get("hdr_format_compatibility"),
            video.get("HDR_Format_Compatibility"),
            video.get("transfer_characteristics"),
            video.get("Transfer_Characteristics"),
            video.get("colour_description_present"),
            video.get("ColorSpace"),
            video.get("colour_primaries"),
            video.get("color_primaries"),
        ]

        hdr_text = " ".join(str(v).lower() for v in hdr_candidates if v)

        hdr_tokens = (
            "hdr",
            "pq",
            "hlg",
            "smpte st 2084",
            "st 2084",
            "hdr10",
            "hdr10+",
            "dolby vision",
            "bt.2020",
            "bt2020",
            "rec.2020",
            "rec2020",
        )

        return any(token in hdr_text for token in hdr_tokens)


    async def get_resolution(self):

        video = await self.get_track("Video")

        if not video:
            return "UNKNOWN"

        width = video.get("width") or video.get("sampled_width")

        height = video.get("height") or video.get("sampled_height")

        if not width:
            return "UNKNOWN"

        try:
            width = int(str(width).split()[0])
        except (TypeError, ValueError):
            return "UNKNOWN"

        scan_type = video.get("scan_type") or video.get("ScanType") or "Progressive"

        scan_flag = "i" if str(scan_type).lower().startswith("inter") else "p"

        if width >= 7680:
            res = "4320"
        elif width >= 3840:
            res = "2160"
        elif width >= 2560:
            res = "1440"
        elif width >= 1920:
            res = "1080"
        elif width >= 1280:
            res = "720"
        elif width >= 1024:
            res = "576"
        elif width >= 720:
            res = "480"
        else:
            res = height

        return f"{res}{scan_flag}"
        
    async def get_media_meta(self):
        if self.raw_bluray:
            summary = await self.parse_quick_summary()
            if summary:
                return summary

        media = {}
        
        resolution = await self.get_resolution()
        if resolution:
            media["resolution"] = resolution
        
        hdr = await self.is_hdr_video()
        if hdr:
            media["hdr"] = hdr
        
        hindi_audio = await self.has_hindi_audio()
        if hindi_audio:
            media["hindi_audio"] = hindi_audio
        
        fast_audio = await self.fast_lang_code("Audio")        
        if fast_audio:
            media["fast_audio"] = fast_audio
            
        return {"media": media}
    
        
###############
# -= DE3PM =- #
###############
