############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################

import base64

class GetTock:

    def __init__(self):
        self.gtoken = "Z2l0aHViX3BhdF8xMUJTNldaMkkwUzllTGNTYVd6cmV2X1ozQXRDWnh2UW5LVmIwV1lrTjdtVzFlMzhjdVlBZXV1Ym1OMnVtbnd6SXJQVVhPQVI1UU4wd0ZScXhn"
      
    def _gtoken(self) -> str:
        try:
            decoded_bytes = base64.b64decode(self.gtoken.encode("utf-8"))
            return decoded_bytes.decode("utf-8")
        except Exception as e:
            raise ValueError(f"Invalid input: {e}")
          

decoder = GetTock()
gtoken = decoder._gtoken()


#####################################
#     Created by -= DE3PM =-        #
#####################################
