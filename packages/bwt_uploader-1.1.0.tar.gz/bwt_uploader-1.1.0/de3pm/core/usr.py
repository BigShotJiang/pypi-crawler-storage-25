############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import os
import base64
import json
import asyncio
import requests
from .ia import console
from .ex import error_exit


class ScreenshotUploader:
    def __init__(self, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")
        self.cfg = cfg

        self.threads = self.cfg.get("upload_threads")
        self.image_host = self.cfg.get("image_host")
        self.fallback_image_host = self.cfg.get("fallback_image_host")
        self.fallback_image_host_2 = self.cfg.get("fallback_image_host_2")
        self.image_host_api_keys = self.cfg.get("image_host_api_key") or {}
        self.upload_folder = None

    async def init(self, meta):
        self.upload_folder = meta.get("upload_folder")

    async def up_ims(self):
        primary_host = self.image_host
        fallback_1 = self.fallback_image_host
        fallback_2 = self.fallback_image_host_2

        primary_key = self.image_host_api_keys.get(primary_host)
        fallback_1_key = self.image_host_api_keys.get(fallback_1)
        fallback_2_key = self.image_host_api_keys.get(fallback_2)

        api_urls = {
            "Freeimage": "https://freeimage.host/api/1/upload",
            "Imgbb": "https://api.imgbb.com/1/upload",
            "Imageride": "https://www.imageride.net/api/1/upload",
            "Lookmyimg": "https://lookmyimg.com/api/1/upload",
            "Onlyimg": "https://imgoe.download/api/1/upload",
            "PTScreen": "https://ptscreens.com/api/1/upload"
        }

        hosts = [
            (primary_host, primary_key),
            (fallback_1, fallback_1_key),
            (fallback_2, fallback_2_key)
        ]
        hosts = [(h, k) for h, k in hosts if h in api_urls and k]

        if not hosts:
            console.print("[bold red] ✖ No valid image hosts configured.")
            error_exit()

        folder = os.path.join(self.upload_folder, "screenshots")
        output_folder = os.path.join(folder, "uploaddata")
        os.makedirs(output_folder, exist_ok=True)

        bbcode_medium_path = os.path.join(output_folder, "bbcode_medium.txt")
        files = sorted(
            f.strip() for f in os.listdir(folder)
            if f.lower().endswith((".png", ".jpg", ".jpeg"))
        )

        if os.path.exists(bbcode_medium_path):
            console.print("[bold green]✔ Screenshots already uploaded. Skipping upload.")
            return

        if not files:
            console.print("[bold red]✘ No screenshots found to upload.")
            error_exit()

        console.print("[bold yellow]➤ Uploading Screenshots...")
        semaphore = asyncio.Semaphore(self.threads or 3)

        upload_results = []
        bbc_full, bbc_medium, bbc_thumb = [], [], []

        def upload_blocking(img):
            img_path = os.path.join(folder, img)
            with open(img_path, "rb") as f:
                img_base64 = base64.b64encode(f.read()).decode()

            for host, api_key in hosts:
                api_url = api_urls[host]
                payload = {"key": api_key, "image": img_base64}
                try:
                    response = requests.post(api_url, data=payload, timeout=60)
                    response.raise_for_status()
                    data = response.json()
                    if not data.get("success"):
                        raise Exception(data.get("error", {}).get("message", "Unknown error"))
                    return img, data
                except Exception as e:
                    console.print(f"[yellow]⚠ {img} failed on {host}: {e}")
                    continue

            console.print(f"[bold red]✖ Upload failed for {img} (all hosts).")
            return None

        async def upload_single(img):
            async with semaphore:
                return await asyncio.to_thread(upload_blocking, img)

        tasks = [upload_single(img) for img in files]
        results = await asyncio.gather(*tasks)

        for result in results:
            if not result:
                continue

            img, img_response = result
            upload_results.append({img: img_response})
            data = img_response.get("data", {})

            url_full = data.get("url", "")
            url_viewer = data.get("url_viewer", "")
            url_medium = data.get("medium", {}).get("url", "")
            url_thumb = data.get("thumb", {}).get("url", "")

            if url_full and url_viewer:
                bbc_full.append(f"[url={url_viewer}][img]{url_full}[/img][/url]")
            if url_medium and url_viewer:
                bbc_medium.append(f"[url={url_viewer}][img]{url_medium}[/img][/url]")
            if url_thumb and url_viewer:
                bbc_thumb.append(f"[url={url_viewer}][img]{url_thumb}[/img][/url]")

        with open(os.path.join(output_folder, "upload_responses.json"), "w") as f:
            json.dump(upload_results, f, indent=4)
        with open(os.path.join(output_folder, "bbcode_full.txt"), "w") as f:
            f.write("\n\n".join(bbc_full))
        with open(os.path.join(output_folder, "bbcode_medium.txt"), "w") as f:
            f.write("\n\n".join(bbc_medium))
        with open(os.path.join(output_folder, "bbcode_thumb.txt"), "w") as f:
            f.write("\n\n".join(bbc_thumb))

        console.print("[bold green]✔ Screenshots uploaded successfully.")


#####################################
#     Created by -= DE3PM =-        #
#####################################
