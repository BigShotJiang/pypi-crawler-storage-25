from.vs import app_version 

Signature = (
    "\n\n[center][font=Arial][size=2][b]"
    "[url=https://discord.gg/C6h9uXACZ9]"
    f"[color=orenge]Created by [/color][color=#FF0000]BWT-Uploader[/color][color=orange] v{app_version}[/color]"
    "[/url][/b][/size][/font][/center]\n"
)


