
############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import argparse
import sys
import shutil
from pathlib import Path
from .vs import app_version


class ShortHelpFormatter(argparse.HelpFormatter):
    def __init__(self, *args, **kwargs):
        kwargs["max_help_position"] = 40
        kwargs["width"] = 100
        super().__init__(*args, **kwargs)


class CustomArgumentParser(argparse.ArgumentParser):
    def error(self, message):
        self.print_help(sys.stderr)
        self.exit(2, f"\nError: {message}\n")


class Args:
    def __init__(self):
        self.parser = CustomArgumentParser(
            prog="bwt-uploader",
            description="BWT-Uploader: Torrent Upload Assistant for BWTorrents.Tv",
            formatter_class=ShortHelpFormatter,
        )

        self.add_arguments()
        self.args = self.parser.parse_args()
        self.metadata = self.process()

    def add_arguments(self):
        
        self.parser.add_argument(
            "filepath",
            nargs="?",
            help="Path to file or directory",
        )

        self.parser.add_argument(
            "--config", "-C",
            help="Install config file",
        )

        self.parser.add_argument(
            "--force-config", "-F",
            action="store_true",
            help="Overwrite existing config",
        )

        self.parser.add_argument(
            "--version", "-v",
            action="version",
            version=f"BWT-Uploader v{app_version}",
            help="Show version and exit",
        )

        self.parser.add_argument("--imdb", "-i", help="IMDb ID (e.g., 1234567)")
        self.parser.add_argument("--tmdb", "-t", help="TMDb ID (e.g., 123456)")

        self.parser.add_argument(
            "--category", "-c",
            type=int,
            help="Category ID (e.g., 119, 145)",
        )

        self.parser.add_argument(
            "--freeleech", "-f",
            action="store_true",
            help="Enable freeleech",
        )

        self.parser.add_argument(
            "--request", "-r",
            action="store_true",
            help="Mark as request fulfillment",
        )

        self.parser.add_argument(
            "--recomanded", "-R",
            action="store_true",
            help="Mark as recomanded upload",
        )

        self.parser.add_argument(
            "--double-upload", "-d",
            action="store_true",
            help="Enable double upload mode",
        )

        self.parser.add_argument(
            "--no-tmdb", "-T",
            action="store_true",
            help="Skip TMDb metadata",
        )

        self.parser.add_argument(
            "--no-imdb-tmdb", "-IT",
            action="store_true",
            help="Skip IMDb and TMDb metadata",
        )

        self.parser.add_argument(
            "--no-youtube", "-Y",
            action="store_true",
            help="Skip YouTube trailer",
        )

        self.parser.add_argument(
            "--piece-length", "-p",
            type=int,
            help="Piece length as 2^n (16–27)",
        )

    def install_config(self, config_path: str):
        src = Path(config_path)

        if not src.exists():
            self.parser.print_help(sys.stderr)
            sys.exit(f"\nError: config file '{config_path}' does not exist\n")

        dest_dir = Path.home() / ".bwt-uploader"
        dest_dir.mkdir(parents=True, exist_ok=True)

        dest_file = dest_dir / "config.py"

        # Overwrite protection
        if dest_file.exists() and not self.args.force_config:
            choice = input(
                "\nConfig already exists. Overwrite? (y/N): "
            ).strip().lower()

            if choice != "y":
                sys.exit(0)

        try:
            shutil.copy(src, dest_file)
            print("Config installed successfully.")
        except Exception as e:
            sys.exit(f"\nError copying config file: {e}\n")

        sys.exit(0)

    def process(self):
        if self.args.config:
            print("Installing Config...")
            self.install_config(self.args.config)

        # Upload mode
        if not self.args.filepath:
            self.parser.print_help(sys.stderr)
            sys.exit("\nError: filepath is required (or use --config)\n")

        path = Path(self.args.filepath)

        if not path.exists():
            self.parser.print_help(sys.stderr)
            sys.exit(f"\nError: filepath '{path}' does not exist\n")

        data = {
            "filepath": str(path)
        }

        if self.args.imdb:
            data["imdbID"] = self.args.imdb

        if self.args.tmdb:
            data["tmdbID"] = self.args.tmdb

        if self.args.no_tmdb:
            data["skip_tmdb"] = self.args.no_tmdb

        if self.args.no_imdb_tmdb:
            data["skip_imdb_tmdb"] = self.args.no_imdb_tmdb

        if self.args.request:
            data["request"] = self.args.request

        if self.args.freeleech:
            data["force_freeleech"] = self.args.freeleech

        if self.args.recomanded:
            data["recomanded"] = self.args.recomanded

        if self.args.double_upload:
            data["doubleupload"] = self.args.double_upload

        if self.args.category:
            data["category_id"] = self.args.category

        if self.args.no_youtube:
            data["skip_youtube"] = self.args.no_youtube

        if self.args.piece_length:
            data["piece_length"] = self.args.piece_length

        return data

    def get_args(self):
        return self.args

###############
# -= DE3PM =- #
###############
