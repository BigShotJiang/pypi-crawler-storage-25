############################################################
#                                                          #
#   ██████╗ ██╗    ██╗████████╗        ██╗   ██╗      #
#   ██╔══██╗██║    ██║╚══██╔══╝        ██║   ██║      #
#   ██████╔╝██║ █╗ ██║   ██║           ██║   ██║       #
#   ██╔══██╗██║███╗██║   ██║           ██║   ██║       #
#   ██████╔╝╚███╔███╔╝   ██║           ╚██████╔╝      #
#   ╚═════╝  ╚══╝╚══╝    ╚═╝            ╚═════╝        #
#                                                          #
#        BWT-Uploader v1.1.0  |  Created by -=DE3PM=-      #
#                                                          #
############################################################

#####################################
#     Created by -= DE3PM =-        #
#####################################


import os
import random
import asyncio
import ffmpeg
from .ia import console
from .ex import error_exit
from .mi import MediaInfoEx


class ScreenshotGenerator:
    def __init__(self, cfg=None):
        if cfg is None:
            raise ValueError("Config is required")

        self.cfg = cfg
        self.screenshots_num = self.cfg.get("screenshots_number", 6)
        self.tonemap_hdr = self.cfg.get("tonemap_hdr", self.cfg.get("hdr_tonemap", True))
        self.hdr_method = self.cfg.get("hdr_method", "reinhard:desat=0")
        self.keyframes_only = self.cfg.get("keyframes_only", False)
        self.compression_level = str(self.cfg.get("compression_level", 6))

        self.video_path = None
        self.video_filename = None
        self.upload_folder = None
        self.mi = MediaInfoEx()
        self.is_hdr = False

    async def init(self, meta):
        try:
            self.video_path = meta.get("videopath")
            self.video_filename = meta.get("video_filename")
            self.upload_folder = meta.get("upload_folder")
            await self.mi.init(meta)

            if not self.video_path or not os.path.exists(self.video_path):
                console.print("[bold red]✖ Video file not found.")
                error_exit()

        except Exception as e:
            console.print(f"[bold red]✖ Metadata error: {e}")
            error_exit()

    async def _get_duration(self):
        try:
            probe = await asyncio.to_thread(ffmpeg.probe, self.video_path)
            duration = float(probe["format"]["duration"])

            if duration <= 0:
                raise ValueError("Invalid video duration")

            return duration

        except ffmpeg.Error as e:
            console.print("[bold red]✖ FFmpeg probe failed.")
            console.print(f"[dim]{e.stderr.decode() if e.stderr else e}")
            error_exit()

        except Exception as e:
            console.print(f"[bold red]✖ Unable to read video duration: {e}")
            error_exit()

    def _generate_timestamps(self, duration):
        start = duration * 0.1
        end = duration * 0.9
        count = self.screenshots_num

        interval = (end - start) / count

        timestamps = [
            start + i * interval + random.uniform(-interval * 0.3, interval * 0.3)
            for i in range(count)
        ]

        return sorted(round(t, 2) for t in timestamps)

    def _screenshot_exists(self, directory):
        if not os.path.exists(directory):
            return False

        return any(f.lower().endswith((".png", ".jpg")) for f in os.listdir(directory))

    async def _capture_frame(self, timestamp, output_path):
        try:
            vf_filters = []

            # --- Deinterlace ---
            if self.cfg.get("deinterlace", False):
                vf_filters.append("yadif")

            # --- HDR → SDR ---
            if self.tonemap_hdr and self.is_hdr:
                vf_filters.extend([
                    "zscale=t=linear:npl=100",
                    "format=gbrpf32le",
                    "zscale=p=709",
                    f"tonemap={self.hdr_method}",
                    "zscale=t=bt709:m=bt709:r=full",
                    "format=rgb24",
                ])
            else:
                vf_filters.append("format=rgb24")

            vf = ",".join(vf_filters)

            cmd = [
                "ffmpeg",
                "-y",
                "-ss", str(timestamp),
                "-i", self.video_path,
                "-frames:v", "1",
                "-vf", vf,
                "-compression_level", self.compression_level,
                "-pred", "mixed",
                output_path,
            ]

            # --- Keyframe Mode ---
            if self.keyframes_only:
                cmd.insert(1, "-skip_frame")
                cmd.insert(2, "nokey")

            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.PIPE,
            )

            _, stderr = await process.communicate()

            if process.returncode != 0:
                console.print(f"[red]✖ FFmpeg failed at {timestamp}s")
                console.print(stderr.decode(errors="ignore"))
                return False

            return os.path.exists(output_path)

        except Exception as e:
            console.print(f"[red]✖ Error at {timestamp}s: {e}")
            return False

    async def gen_scr(self):
        output_directory = os.path.join(self.upload_folder, "screenshots")
        os.makedirs(output_directory, exist_ok=True)

        if self._screenshot_exists(output_directory):
            console.print("[bold green]✔ Screenshots already exist — skipping.")
            return

        duration = await self._get_duration()
        timestamps = self._generate_timestamps(duration)

        try:
            self.is_hdr = await self.mi.is_hdr_video()
        except Exception:
            self.is_hdr = False

        console.print(f"[bold yellow]➤ Generating {self.screenshots_num} screenshots...")

        tasks = []
        for i, t in enumerate(timestamps, start=1):
            output_path = os.path.join(
                output_directory,
                f"{self.video_filename}_screenshot_{i:02d}.png",
            )
            tasks.append(self._capture_frame(t, output_path))

        results = await asyncio.gather(*tasks)

        success = sum(results)
        failed = len(results) - success

        if success:
            console.print(f"[bold green]✔ Screenshots completed: {success}/{self.screenshots_num}")
        if failed:
            console.print(f"[bold yellow]⚠ Failed: {failed}")
        if success == 0:
            console.print("[bold red]✖ No screenshots generated.")
            error_exit()


#####################################
#     Created by -= DE3PM =-        #
#####################################
