# Backlog

Local planning notes. Review when starting implementation.

---

## Package Structure

```
sbom_sentinel/
    cli.py       # click entry points — one command per stage + orchestrator
    target.py    # intelligent target resolution (dir / image / git URL)
    sbom.py      # Stage 1: Syft wrapper
    scan.py      # Stage 2: Grype wrapper
    kev.py       # CISA KEV catalog download and cache
    report.py    # Stage 3: markdown report generation + KEV enrichment
    log.py       # structured logging helpers
tests/
    test_target.py
    test_kev.py
    test_report.py
    test_scan.py
    test_sbom.py
    test_cli.py
pyproject.toml
```

CLI usage:
```bash
sbom-sentinel sbom   --target ./myapp --name MyApp_1.0
sbom-sentinel scan   --sbom sbom_output/MyApp_1.0.spdx.json --name MyApp_1.0
sbom-sentinel report --scan results/json/MyApp_1.0.json --name MyApp_1.0
sbom-sentinel run    --sbom sbom_output/MyApp_1.0.spdx.json --name MyApp_1.0
```

`run` chains Stage 2 + 3 only. Stage 1 is intentionally a separate command — the SBOM
reflects what is in the software and only changes per release. Vulnerability data changes
daily. These two things must not be coupled.

---

## Known Issues to Track Before Building

### CycloneDX 1.6 Read Bug (Grype v0.79.1+)
Grype writes CycloneDX 1.6 output but cannot parse it back in. A Syft → CycloneDX 1.6 → Grype
pipeline silently fails. Tracked upstream: https://github.com/anchore/grype/issues/1951

**Decision:** Pin SBOM intermediate format to `spdx-json`. All code must treat this as a
constraint, not a preference. Revisit only when the upstream bug is confirmed fixed.

### Grype JSON v1.0 Redesign (In Progress)
Grype is restructuring its JSON output schema for v1.0. Active discussion:
https://github.com/anchore/grype/issues/3144

**Decision:** Parse Grype JSON defensively — use `.get()` everywhere, validate keys before
access. When v1.0 ships, `scan.py` and `report.py` will need updating. Document the minimum
supported Grype version in the prerequisites check.

---

## Stage 1 — SBOM Generation

**Module:** `sbom_sentinel/sbom.py`
**CLI:** `sbom-sentinel sbom --target <target> --name <name>`
**Input:** Any target (local dir, container image, remote git URL)
**Output:** `sbom_output/<name>_<timestamp>.spdx.json`

### Tasks

- [x] `sbom_sentinel/target.py` — `resolve(target: str) -> tuple[str, str]`
- [x] `sbom_sentinel/sbom.py` — `generate(target, name, output_dir) -> Path`
- [x] Prerequisites check in `sbom.py` (syft, git)

---

## Stage 2 — Vulnerability Scan

**Module:** `sbom_sentinel/scan.py`
**CLI:** `sbom-sentinel scan --sbom <path> --name <name> [--fail-on critical|high|medium|low]`
**Input:** SPDX JSON SBOM
**Output:** `results/json/<name>_<timestamp>.json`

### Tasks

- [x] `sbom_sentinel/scan.py` — `run(sbom_file, name, output_dir, fail_on, fmt, vex) -> Path`
- [x] Prerequisites check in `scan.py` (grype)
- [x] `--fail-on` maps to Grype's `--fail-on` flag
- [x] `--format sarif` support
- [x] `--vex` passthrough to Grype

---

## Stage 3 — Report Generation

**Module:** `sbom_sentinel/report.py`
**CLI:** `sbom-sentinel report --scan <path> --name <name> [--no-kev]`
**Input:** Grype JSON results file
**Output:** `results/reports/<name>_<timestamp>.md`

### Tasks

- [x] `sbom_sentinel/kev.py` — `load(cache_dir) -> set[str]` with date-stamped cache
- [x] `sbom_sentinel/report.py` — `generate(scan_file, name, output_dir, kev, vex) -> Path`
- [x] Severity grouping: Critical → High → Medium → Low → Negligible
- [x] `[KEV]` marker + KEV-Flagged count in summary table
- [x] SARIF input guard — raises `ValueError` with clear message instead of silent empty report
- [x] VEX+KEV conflict warning — flags CVEs suppressed by VEX that are in KEV

---

## Orchestrator

**CLI:** `sbom-sentinel run --sbom <path> --name <name> [--fail-on ...] [--no-kev]`

### Tasks

- [x] `sbom_sentinel/log.py` — `get_logger(name) -> logging.Logger`
- [x] `run` command — chains Stage 2 + 3; Stage 1 excluded by design
- [x] `--vex` passed to both scan and report stages

---

## Future — CI Integration

- [x] Code quality CI (`.github/workflows/ci.yml`)
      Runs ruff, mypy, and pytest on push/PR.

- [x] Dependabot (`.github/dependabot.yml`)
      Auto-updates GitHub Actions and Python dependencies weekly.

- [x] Removed `sbom-scan.yml` — Dependabot covers dependency security
      for a project this size. Running sbom-sentinel on itself was
      circular and added CI noise without real value.

---

## Future — Enhanced Analysis

- [x] VEX document ingestion (passthrough implemented)
      `--vex <path>` flag on `sbom-sentinel scan` and `sbom-sentinel run`.
      Grype supports OpenVEX and CSAF (merged Aug 2025). Passed as `--vex` to Grype.
      Suppresses findings where VEX status is `not_affected`.

- [ ] VEX workflow — investigate further
      The passthrough exists but there is no tooling yet to help a user *author* VEX documents.
      Questions to resolve:
        - Should we ship a `sbom-sentinel vex init` command that scaffolds a starter .vex.json
          from the current scan results (pre-populated with `under_investigation` status)?
        - The `vexctl` CLI (OpenVEX project) can generate and merge VEX docs — worth evaluating
          as a dependency vs. reimplementing.
        - VEX docs should ideally be committed alongside the SBOM in version control.
          Convention to establish: `vex/` directory at repo root, named by date or ticket ID.
        - Consider how VEX interacts with KEV: a KEV-flagged CVE suppressed by VEX is a
          high-risk decision that should be flagged prominently in the report.
      Resources:
        - OpenVEX spec: https://github.com/openvex/spec
        - vexctl: https://github.com/openvex/vexctl
        - Grype VEX docs: https://github.com/anchore/grype#vex-support
