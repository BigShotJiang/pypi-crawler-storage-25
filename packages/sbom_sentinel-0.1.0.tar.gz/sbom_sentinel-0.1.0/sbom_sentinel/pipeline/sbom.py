import shutil
import subprocess
import tempfile
from datetime import UTC, datetime
from pathlib import Path

from sbom_sentinel.support import target as target_mod
from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

# Conservative timeouts for external tools. Large images or repos can be slow.
_GIT_CLONE_TIMEOUT = 120   # seconds — shallow clone should complete well within this
_SYFT_TIMEOUT = 600        # seconds — large container images can take several minutes


def _check_prereqs(target_type: str) -> None:
    if shutil.which("syft") is None:
        raise OSError(
            "syft not found in PATH. "
            "Install from: https://github.com/anchore/syft#installation"
        )
    if target_type == "git" and shutil.which("git") is None:
        raise OSError(
            "git not found in PATH. "
            "Required for remote git URL targets. Install from: https://git-scm.com"
        )


def generate(target: str, name: str, output_dir: Path) -> Path:
    """
    Run Syft on target and write SBOM to output_dir/<name>_<timestamp>.spdx.json.

    Git targets are cloned to a temporary directory first (Syft has no native remote
    git URL support). The clone is removed in a finally block regardless of outcome.

    Returns the path to the written SBOM file.
    """
    target_type, resolved = target_mod.resolve(target)
    _check_prereqs(target_type)

    output_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
    output_path = output_dir / f"{name}_{ts}.spdx.json"

    if target_type == "git":
        _generate_from_git(resolved, output_path)
    else:
        _run_syft(resolved, output_path)

    log.info(f"SBOM written to {output_path}")
    return output_path


def _generate_from_git(url: str, output_path: Path) -> None:
    tmp_dir = tempfile.mkdtemp(prefix="sbom_sentinel_git_")
    try:
        log.info(f"Cloning {url} ...")
        cmd = ["git", "clone", "--depth", "1", url, tmp_dir]
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=_GIT_CLONE_TIMEOUT,
        )
        if result.returncode != 0:
            if result.stderr:
                log.error(result.stderr.strip())
            raise subprocess.CalledProcessError(result.returncode, cmd)
        _run_syft(tmp_dir, output_path)
    finally:
        shutil.rmtree(tmp_dir, ignore_errors=True)


def _run_syft(source: str, output_path: Path) -> None:
    log.info(f"Running syft on {source} ...")
    cmd = ["syft", source, "-o", f"spdx-json={output_path}", "-q"]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=_SYFT_TIMEOUT)
    if result.returncode != 0:
        if result.stderr:
            log.error(result.stderr.strip())
        raise subprocess.CalledProcessError(result.returncode, cmd)
