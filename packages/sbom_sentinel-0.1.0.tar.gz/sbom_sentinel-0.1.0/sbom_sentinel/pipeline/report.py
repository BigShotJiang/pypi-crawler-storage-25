import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

_SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Negligible"]
_DESCRIPTION_MAX = 200
_CVE_RE = re.compile(r"CVE-\d{4}-\d+", re.IGNORECASE)


def _parse_vex_suppressions(vex_file: Path) -> set[str]:
    """
    Read a VEX document (OpenVEX or CSAF) and return the set of CVE IDs whose
    status is 'not_affected'. These are the findings Grype silently dropped.

    Extracts CVE IDs from the vulnerability @id field — handles both bare IDs
    ("CVE-2025-1234") and full URLs ("https://www.cve.org/CVERecord?id=CVE-2025-1234").
    Returns empty set on any parse error so the report still generates.
    """
    try:
        doc = json.loads(vex_file.read_text(encoding="utf-8"))
    except Exception as exc:
        log.warning(f"Could not parse VEX document {vex_file}: {exc}")
        return set()

    suppressed: set[str] = set()
    for stmt in doc.get("statements", []):
        if (stmt.get("status") or "").lower() != "not_affected":
            continue
        vuln_id = (stmt.get("vulnerability") or {}).get("@id", "")
        match = _CVE_RE.search(vuln_id)
        if match:
            suppressed.add(match.group(0).upper())

    return suppressed


def generate(
    scan_file: Path,
    name: str,
    output_dir: Path,
    kev: set[str],
    vex: Path | None = None,
) -> Path:
    """
    Parse Grype JSON results and write a markdown report to output_dir/<name>_<timestamp>.md.

    Parsing is defensive throughout (.get() on all fields) because Grype's JSON schema
    is being redesigned for v1.0 (https://github.com/anchore/grype/issues/3144).

    vex: optional path to the VEX document used during the scan. If provided, the report
    warns about any CVE that was suppressed by VEX AND appears in the CISA KEV catalog —
    suppressing an actively exploited vulnerability is a high-risk decision that must be
    visible to reviewers.

    Returns the path to the written report.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    now = datetime.now(tz=UTC)
    output_path = output_dir / f"{name}_{now.strftime('%Y%m%d_%H%M%S')}.md"

    raw: dict[str, Any] = json.loads(scan_file.read_text(encoding="utf-8"))

    if "runs" in raw or "$schema" in raw:
        raise ValueError(
            f"{scan_file.name} appears to be a SARIF file. "
            "The report command requires Grype JSON output (--format json). "
            "Re-run the scan without --format sarif."
        )

    matches: list[dict[str, Any]] = raw.get("matches", [])

    by_severity: dict[str, list[dict[str, Any]]] = {s: [] for s in _SEVERITY_ORDER}
    for match in matches:
        vuln: dict[str, Any] = match.get("vulnerability") or {}
        severity = (vuln.get("severity") or "Unknown").capitalize()
        if severity not in by_severity:
            cve_id = vuln.get("id") or "UNKNOWN"
            log.warning(f"Unknown severity '{severity}' for {cve_id}, bucketing as Negligible")
            severity = "Negligible"
        by_severity[severity].append(match)

    suppressed_kev: set[str] = set()
    if vex and kev:
        suppressed = _parse_vex_suppressions(vex)
        suppressed_kev = suppressed & kev
        if suppressed_kev:
            log.warning(
                f"{len(suppressed_kev)} VEX-suppressed finding(s) are in the CISA KEV catalog: "
                + ", ".join(sorted(suppressed_kev))
            )

    lines = _build_report(name, scan_file, now, by_severity, kev, suppressed_kev)
    output_path.write_text("\n".join(lines), encoding="utf-8")
    log.info(f"Report written to {output_path}")
    return output_path


def _build_report(
    name: str,
    scan_file: Path,
    now: datetime,
    by_severity: dict[str, list[dict[str, Any]]],
    kev: set[str],
    suppressed_kev: set[str],
) -> list[str]:
    now_str = now.strftime("%Y-%m-%d %H:%M:%S")
    total = sum(len(v) for v in by_severity.values())
    kev_count = sum(
        1
        for matches in by_severity.values()
        for m in matches
        if (m.get("vulnerability") or {}).get("id", "") in kev
    )

    lines: list[str] = []
    lines.append(f"# Vulnerability Report: {name}")
    lines.append("")
    lines.append(f"**Generated:** {now_str}  ")
    lines.append(f"**Scan file:** {scan_file}")
    lines.append("")

    if suppressed_kev:
        lines.append("## [!] VEX Suppressions Conflict with CISA KEV")
        lines.append("")
        lines.append(
            "The following CVEs were marked `not_affected` in the VEX document and are "
            "therefore absent from the findings below. However, they appear in the "
            "**CISA Known Exploited Vulnerabilities catalog** — meaning they are being "
            "actively exploited in the wild. "
            "Review the VEX justification before accepting this suppression."
        )
        lines.append("")
        for cve_id in sorted(suppressed_kev):
            lines.append(f"- `{cve_id}` [KEV] — suppressed by VEX (`not_affected`)")
        lines.append("")

    lines.append("## Summary")
    lines.append("")
    lines.append("| Severity | Count |")
    lines.append("|---|---|")
    for severity in _SEVERITY_ORDER:
        lines.append(f"| {severity} | {len(by_severity[severity])} |")
    lines.append(f"| **Total** | **{total}** |")
    lines.append(f"| KEV-Flagged | {kev_count} |")
    if suppressed_kev:
        lines.append(f"| VEX-Suppressed KEV | {len(suppressed_kev)} |")
    lines.append("")

    for severity in _SEVERITY_ORDER:
        matches = by_severity[severity]
        if not matches:
            continue
        lines.append("---")
        lines.append("")
        lines.append(f"## {severity} ({len(matches)})")
        lines.append("")
        for match in matches:
            lines.extend(_format_match(match, kev))

    return lines


def _format_match(match: dict[str, Any], kev: set[str]) -> list[str]:
    vuln: dict[str, Any] = match.get("vulnerability") or {}
    artifact: dict[str, Any] = match.get("artifact") or {}

    cve_id = vuln.get("id") or "UNKNOWN"
    severity = vuln.get("severity") or "Unknown"
    description = vuln.get("description") or "No description available."
    if len(description) > _DESCRIPTION_MAX:
        description = description[:_DESCRIPTION_MAX].rstrip() + "..."

    pkg_name = artifact.get("name") or "unknown"
    pkg_version = artifact.get("version") or "unknown"

    fix_info: dict[str, Any] = vuln.get("fix") or {}
    fix_versions: list[str] = fix_info.get("versions") or []
    fix_str = fix_versions[0] if fix_versions else "not available"

    kev_marker = " [KEV]" if cve_id in kev else ""

    lines: list[str] = []
    lines.append(f"### {cve_id}{kev_marker}")
    lines.append("")
    lines.append(f"- **Package:** {pkg_name} {pkg_version}")
    lines.append(f"- **Fix:** {fix_str}")
    lines.append(f"- **Severity:** {severity}")
    lines.append(f"- **Description:** {description}")
    lines.append("")
    return lines
