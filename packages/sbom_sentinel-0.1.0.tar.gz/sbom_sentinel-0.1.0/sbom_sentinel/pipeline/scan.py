import shutil
import subprocess
from datetime import UTC, datetime
from pathlib import Path

from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

# Grype JSON v1.0 schema redesign is in progress:
# https://github.com/anchore/grype/issues/3144
# Minimum tested version: v0.79.x (spdx-json input, pre-v1.0 output schema).

_VALID_SEVERITIES = {"critical", "high", "medium", "low", "negligible"}


def _check_prereqs() -> None:
    if shutil.which("grype") is None:
        raise OSError(
            "grype not found in PATH. "
            "Install from: https://github.com/anchore/grype#installation"
        )


_VALID_FORMATS = {"json", "sarif"}

# Grype can be slow on large SBOMs. 5 minutes is generous for typical use.
_GRYPE_TIMEOUT = 300  # seconds


def run(
    sbom_file: Path,
    name: str,
    output_dir: Path,
    fail_on: str | None,
    fmt: str = "json",
    vex: Path | None = None,
) -> Path:
    """
    Run Grype against sbom_file and write results to output_dir/<name>_<timestamp>.<ext>.

    fmt: "json" (default) or "sarif". SARIF enables GitHub Code Scanning integration.

    vex: optional path to an OpenVEX or CSAF document. Passed to Grype via --vex.
    Grype will suppress any finding where the VEX statement status is "not_affected".

    --fail-on maps directly to Grype's --fail-on flag. When the severity threshold is
    met, Grype exits non-zero. This function writes the scan output first, then raises
    subprocess.CalledProcessError so the CLI layer can exit with code 1 while the
    results file is preserved for the report stage.

    Returns the path to the written results file.
    """
    _check_prereqs()

    if fmt not in _VALID_FORMATS:
        raise ValueError(f"Invalid format '{fmt}'. Valid values: {', '.join(_VALID_FORMATS)}")

    if fail_on is not None and fail_on.lower() not in _VALID_SEVERITIES:
        raise ValueError(
            f"Invalid --fail-on severity '{fail_on}'. "
            f"Valid values: {', '.join(sorted(_VALID_SEVERITIES))}"
        )

    output_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
    ext = "sarif" if fmt == "sarif" else "json"
    output_path = output_dir / f"{name}_{ts}.{ext}"

    cmd = ["grype", f"sbom:{sbom_file}", "--by-cve", "-o", fmt]
    if fail_on:
        cmd += ["--fail-on", fail_on.lower()]
    if vex:
        cmd += ["--vex", str(vex)]

    log.info(f"Running grype on {sbom_file} ...")
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=_GRYPE_TIMEOUT)

    if result.stdout:
        output_path.write_text(result.stdout, encoding="utf-8")
        log.info(f"Scan results written to {output_path}")

    if result.returncode != 0:
        if result.stderr:
            log.error(result.stderr.strip())
        raise subprocess.CalledProcessError(result.returncode, cmd)

    if not output_path.exists():
        raise OSError("grype produced no output on stdout; scan results not written")

    return output_path
