import json
import logging
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console

from sbom_sentinel.pipeline import report, sbom, scan
from sbom_sentinel.support import kev

console = Console(stderr=True)


@click.group()
@click.option("-v", "--verbose", is_flag=True, default=False, help="Enable verbose output.")
def cli(verbose: bool) -> None:
    """SBOM generation and vulnerability intelligence pipeline."""
    logging.getLogger("sbom_sentinel").setLevel(logging.DEBUG if verbose else logging.WARNING)


@cli.command("sbom")
@click.option("--target", required=True, help="Target: local dir, container image, or git URL.")
@click.option("--name", required=True, help="Name used to label output files.")
@click.option(
    "--output-dir",
    default="sbom_output",
    show_default=True,
    help="Directory for SBOM output.",
)
def sbom_cmd(target: str, name: str, output_dir: str) -> None:
    """Stage 1: Generate an SBOM from a target using Syft."""
    try:
        path = sbom.generate(target, name, Path(output_dir))
        console.print(f"[green][+][/green] SBOM: {path}")
    except (OSError, ValueError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except subprocess.CalledProcessError:
        console.print("[yellow][!][/yellow] Syft exited with a non-zero status.")
        sys.exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red][-][/red] SBOM generation timed out.")
        sys.exit(1)


@cli.command("scan")
@click.option(
    "--sbom", "sbom_file", required=True, type=click.Path(exists=True, path_type=Path)
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option(
    "--fail-on",
    type=click.Choice(
        ["critical", "high", "medium", "low", "negligible"], case_sensitive=False
    ),
    default=None,
    help="Exit with code 1 if vulnerabilities at this severity or above are found.",
)
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["json", "sarif"], case_sensitive=False),
    default="json",
    show_default=True,
    help="Output format. 'sarif' enables GitHub Code Scanning integration.",
)
@click.option(
    "--output-dir",
    default="results/json",
    show_default=True,
    help="Directory for scan result output.",
)
@click.option(
    "--vex",
    "vex_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="OpenVEX or CSAF document. Suppresses findings marked not_affected.",
)
def scan_cmd(
    sbom_file: Path,
    name: str,
    fail_on: str | None,
    fmt: str,
    output_dir: str,
    vex_file: Path | None,
) -> None:
    """Stage 2: Scan an SBOM for vulnerabilities using Grype."""
    try:
        path = scan.run(sbom_file, name, Path(output_dir), fail_on, fmt=fmt, vex=vex_file)
        console.print(f"[green][+][/green] Scan results: {path}")
    except OSError as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except subprocess.CalledProcessError:
        console.print(
            "[yellow][!][/yellow] Grype exited with a non-zero status "
            "(--fail-on threshold met or scan error)."
        )
        sys.exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red][-][/red] Scan timed out.")
        sys.exit(1)


@cli.command("report")
@click.option(
    "--scan", "scan_file", required=True, type=click.Path(exists=True, path_type=Path)
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option("--no-kev", is_flag=True, default=False, help="Skip CISA KEV enrichment.")
@click.option(
    "--cache-dir",
    default="cache",
    show_default=True,
    help="Directory for KEV cache.",
)
@click.option(
    "--output-dir",
    default="results/reports",
    show_default=True,
    help="Directory for report output.",
)
@click.option(
    "--vex",
    "vex_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="VEX document used during scan. Flags any suppressed findings that are in CISA KEV.",
)
def report_cmd(
    scan_file: Path,
    name: str,
    no_kev: bool,
    cache_dir: str,
    output_dir: str,
    vex_file: Path | None,
) -> None:
    """Stage 3: Generate a markdown vulnerability report from scan results."""
    kev_set: set[str] = set()
    if not no_kev:
        kev_set = kev.load(Path(cache_dir))

    try:
        path = report.generate(scan_file, name, Path(output_dir), kev_set, vex=vex_file)
        console.print(f"[green][+][/green] Report: {path}")
    except (ValueError, json.JSONDecodeError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)


@cli.command("run")
@click.option(
    "--sbom", "sbom_file", required=True, type=click.Path(exists=True, path_type=Path)
)
@click.option("--name", required=True, help="Name used to label output files.")
@click.option(
    "--fail-on",
    type=click.Choice(
        ["critical", "high", "medium", "low", "negligible"], case_sensitive=False
    ),
    default=None,
    help="Exit with code 1 if vulnerabilities at this severity or above are found.",
)
@click.option("--no-kev", is_flag=True, default=False, help="Skip CISA KEV enrichment.")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["json", "sarif"], case_sensitive=False),
    default="json",
    show_default=True,
    help="Scan output format. 'sarif' enables GitHub Code Scanning integration.",
)
@click.option(
    "--scan-dir",
    default="results/json",
    show_default=True,
    help="Directory for scan result output.",
)
@click.option(
    "--report-dir",
    default="results/reports",
    show_default=True,
    help="Directory for report output.",
)
@click.option(
    "--cache-dir",
    default="cache",
    show_default=True,
    help="Directory for KEV cache.",
)
@click.option(
    "--vex",
    "vex_file",
    default=None,
    type=click.Path(exists=True, path_type=Path),
    help="OpenVEX or CSAF document. Passed to Grype; suppressed KEV findings flagged in report.",
)
def run_cmd(
    sbom_file: Path,
    name: str,
    fail_on: str | None,
    no_kev: bool,
    fmt: str,
    scan_dir: str,
    report_dir: str,
    cache_dir: str,
    vex_file: Path | None,
) -> None:
    """Orchestrator: run Stage 2 (scan) then Stage 3 (report). Stage 1 excluded by design."""
    # Stage 2: scan
    try:
        scan_path = scan.run(
            sbom_file, name, Path(scan_dir), fail_on, fmt=fmt, vex=vex_file
        )
        console.print(f"[green][+][/green] Scan results: {scan_path}")
    except OSError as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)
    except subprocess.CalledProcessError:
        console.print(
            "[yellow][!][/yellow] Grype exited with a non-zero status "
            "(--fail-on threshold met or scan error)."
        )
        sys.exit(1)
    except subprocess.TimeoutExpired:
        console.print("[red][-][/red] Scan timed out.")
        sys.exit(1)

    # Stage 3: report
    kev_set: set[str] = set()
    if not no_kev:
        kev_set = kev.load(Path(cache_dir))

    try:
        report_path = report.generate(
            scan_path, name, Path(report_dir), kev_set, vex=vex_file
        )
        console.print(f"[green][+][/green] Report: {report_path}")
    except (ValueError, json.JSONDecodeError) as exc:
        console.print(f"[red][-][/red] {exc}")
        sys.exit(1)


if __name__ == "__main__":
    cli()
