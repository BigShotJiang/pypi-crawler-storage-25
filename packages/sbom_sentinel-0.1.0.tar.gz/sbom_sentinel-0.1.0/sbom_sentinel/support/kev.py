import json
from datetime import date
from pathlib import Path
from typing import Any

import requests

from sbom_sentinel.support.log import get_logger

log = get_logger(__name__)

_KEV_URL = (
    "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
)


def load(cache_dir: Path) -> set[str]:
    """
    Return the set of CVE IDs currently in the CISA KEV catalog.

    Uses a date-stamped local cache (cache/kev_YYYYMMDD.json). Downloads if today's
    cache is absent. On download failure with no usable cache, logs a warning and
    returns an empty set so downstream operations continue without KEV enrichment.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / f"kev_{date.today().strftime('%Y%m%d')}.json"

    if cache_file.exists():
        log.info(f"Loading KEV catalog from cache: {cache_file}")
        return _parse_cache(cache_file)

    return _download(cache_file)


def _download(cache_file: Path) -> set[str]:
    log.info("Downloading CISA KEV catalog ...")
    try:
        response = requests.get(_KEV_URL, timeout=30)
        response.raise_for_status()
        data: dict[str, Any] = response.json()
        cache_file.write_text(response.text, encoding="utf-8")
        _cleanup_stale_caches(cache_file)
        return _extract_cves(data)
    except Exception as exc:
        log.warning(f"KEV download failed ({exc}). Continuing without KEV enrichment.")
        return set()


def _cleanup_stale_caches(current: Path) -> None:
    """Remove old kev_*.json files, keeping only the current one."""
    for f in current.parent.glob("kev_*.json"):
        if f != current:
            f.unlink(missing_ok=True)
            log.info(f"Removed stale KEV cache: {f.name}")


def _parse_cache(cache_file: Path) -> set[str]:
    try:
        data: dict[str, Any] = json.loads(cache_file.read_text(encoding="utf-8"))
        return _extract_cves(data)
    except Exception as exc:
        log.warning(f"Failed to parse KEV cache ({exc}). Re-downloading ...")
        cache_file.unlink(missing_ok=True)
        return _download(cache_file)


def _extract_cves(data: dict[str, Any]) -> set[str]:
    return {
        v.get("cveID", "")
        for v in data.get("vulnerabilities", [])
        if v.get("cveID")
    }
