import logging

_LEVEL_PREFIXES = {
    logging.DEBUG: "[i]",
    logging.INFO: "[+]",
    logging.WARNING: "[!]",
    logging.ERROR: "[-]",
    logging.CRITICAL: "[-]",
}


class _PrefixFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        prefix = _LEVEL_PREFIXES.get(record.levelno, "[?]")
        return f"{prefix} {record.name}: {record.getMessage()}"


def get_logger(name: str) -> logging.Logger:
    """Return a logger with consistent [+]/[!]/[-]/[i] prefixes."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(_PrefixFormatter())
        logger.addHandler(handler)
        logger.propagate = False
    return logger
