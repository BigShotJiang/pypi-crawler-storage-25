import subprocess
from collections.abc import Iterator
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from sbom_sentinel.pipeline.scan import run


def _make_result(stdout: str = "{}", returncode: int = 0, stderr: str = "") -> MagicMock:
    r = MagicMock()
    r.stdout = stdout
    r.returncode = returncode
    r.stderr = stderr
    return r


@pytest.fixture
def grype_found() -> Iterator[None]:
    with patch("sbom_sentinel.pipeline.scan.shutil.which", return_value="/usr/bin/grype"):
        yield



# sbom_file fixture comes from conftest.py


def test_run_writes_output(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result('{"matches":[]}')):
        result = run(sbom_file, "app", tmp_path / "out", None)
    assert result.exists()
    assert result.suffix == ".json"
    assert "app" in result.name


def test_run_calls_grype_with_sbom_arg(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None)
    cmd = mock_run.call_args[0][0]
    assert cmd[0] == "grype"
    assert f"sbom:{sbom_file}" in cmd
    assert "--by-cve" in cmd


def test_run_fail_on_added_to_cmd(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", "high")
    cmd = mock_run.call_args[0][0]
    assert "--fail-on" in cmd
    assert "high" in cmd


def test_run_no_fail_on_flag_when_none(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None)
    cmd = mock_run.call_args[0][0]
    assert "--fail-on" not in cmd


def test_run_vex_added_to_cmd(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    vex = tmp_path / "statements.vex.json"
    vex.write_text("{}", encoding="utf-8")
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None, vex=vex)
    cmd = mock_run.call_args[0][0]
    assert "--vex" in cmd
    assert str(vex) in cmd


def test_run_no_vex_flag_when_none(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result()) as mock_run:
        run(sbom_file, "app", tmp_path / "out", None)
    cmd = mock_run.call_args[0][0]
    assert "--vex" not in cmd


def test_run_sarif_format(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result("<sarif/>")) as mock_run:
        result = run(sbom_file, "app", tmp_path / "out", None, fmt="sarif")
    assert result.suffix == ".sarif"
    cmd = mock_run.call_args[0][0]
    assert "-o" in cmd
    assert "sarif" in cmd


def test_run_raises_on_nonzero_exit(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with patch("subprocess.run", return_value=_make_result(returncode=1)):
        with pytest.raises(subprocess.CalledProcessError):
            run(sbom_file, "app", tmp_path / "out", "high")


def test_run_output_written_before_raising(
    grype_found: None, sbom_file: Path, tmp_path: Path
) -> None:
    # Results file must exist so the report stage can still run after a --fail-on exit.
    out_dir = tmp_path / "out"
    with patch("subprocess.run", return_value=_make_result('{"matches":[]}', returncode=1)):
        with pytest.raises(subprocess.CalledProcessError):
            run(sbom_file, "app", out_dir, "high")
    files = list(out_dir.glob("*.json"))
    assert len(files) == 1


def test_run_grype_not_found(sbom_file: Path, tmp_path: Path) -> None:
    with patch("sbom_sentinel.pipeline.scan.shutil.which", return_value=None):
        with pytest.raises(OSError, match="grype not found"):
            run(sbom_file, "app", tmp_path / "out", None)


def test_run_invalid_format(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Invalid format"):
        run(sbom_file, "app", tmp_path / "out", None, fmt="xml")


def test_run_invalid_fail_on(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="Invalid --fail-on"):
        run(sbom_file, "app", tmp_path / "out", "extreme")


def test_run_logs_stderr_on_failure(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    # Covers the stderr logging branch inside the non-zero exit handler.
    with patch("subprocess.run", return_value=_make_result(returncode=1, stderr="db error")):
        with pytest.raises(subprocess.CalledProcessError):
            run(sbom_file, "app", tmp_path / "out", None)


def test_run_no_stdout_raises(grype_found: None, sbom_file: Path, tmp_path: Path) -> None:
    # grype exits zero but emits nothing — returning a non-existent path would
    # cause a FileNotFoundError in the report stage; raise early with a clear message.
    with patch("subprocess.run", return_value=_make_result(stdout="")):
        with pytest.raises(OSError, match="no output on stdout"):
            run(sbom_file, "app", tmp_path / "out", None)
