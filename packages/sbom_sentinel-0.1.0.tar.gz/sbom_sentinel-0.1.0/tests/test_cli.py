import json
import logging
import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from sbom_sentinel.cli import cli

# runner, sbom_file, vex_file fixtures come from conftest.py


@pytest.fixture
def scan_file(tmp_path: Path) -> Path:
    f = tmp_path / "app_scan.json"
    f.write_text('{"matches":[]}', encoding="utf-8")
    return f


# ---------------------------------------------------------------------------
# --verbose flag
# ---------------------------------------------------------------------------


def test_verbose_sets_debug_level(runner: CliRunner, tmp_path: Path) -> None:
    with patch("sbom_sentinel.cli.sbom.generate", return_value=tmp_path / "out.spdx.json"):
        runner.invoke(cli, ["-v", "sbom", "--target", "docker:nginx", "--name", "nginx"])
    assert logging.getLogger("sbom_sentinel").level == logging.DEBUG


def test_default_log_level_is_warning(runner: CliRunner, tmp_path: Path) -> None:
    with patch("sbom_sentinel.cli.sbom.generate", return_value=tmp_path / "out.spdx.json"):
        runner.invoke(cli, ["sbom", "--target", "docker:nginx", "--name", "nginx"])
    assert logging.getLogger("sbom_sentinel").level == logging.WARNING


# ---------------------------------------------------------------------------
# sbom command
# ---------------------------------------------------------------------------


def test_sbom_cmd_calls_generate(runner: CliRunner, tmp_path: Path) -> None:
    with patch("sbom_sentinel.cli.sbom.generate", return_value=tmp_path / "out.spdx.json") as mock:
        result = runner.invoke(cli, ["sbom", "--target", "docker:nginx", "--name", "nginx"])
    mock.assert_called_once()
    assert result.exit_code == 0


def test_sbom_cmd_passes_output_dir(runner: CliRunner, tmp_path: Path) -> None:
    with patch(
        "sbom_sentinel.cli.sbom.generate", return_value=tmp_path / "out.spdx.json"
    ) as mock:
        runner.invoke(
            cli,
            ["sbom", "--target", "docker:nginx", "--name", "nginx",
             "--output-dir", str(tmp_path / "sboms")],
        )
    assert str(mock.call_args[0][2]) == str(tmp_path / "sboms")


def test_sbom_cmd_oserror_exits_1(runner: CliRunner) -> None:
    with patch("sbom_sentinel.cli.sbom.generate", side_effect=OSError("syft not found")):
        result = runner.invoke(cli, ["sbom", "--target", "docker:nginx", "--name", "nginx"])
    assert result.exit_code == 1


def test_sbom_cmd_valueerror_exits_1(runner: CliRunner) -> None:
    with patch("sbom_sentinel.cli.sbom.generate", side_effect=ValueError("bad target")):
        result = runner.invoke(cli, ["sbom", "--target", "docker:nginx", "--name", "nginx"])
    assert result.exit_code == 1


def test_sbom_cmd_called_process_error_exits_1(runner: CliRunner) -> None:
    with patch("sbom_sentinel.cli.sbom.generate",
               side_effect=subprocess.CalledProcessError(1, "syft")):
        result = runner.invoke(cli, ["sbom", "--target", "docker:nginx", "--name", "nginx"])
    assert result.exit_code == 1


def test_sbom_cmd_timeout_exits_1(runner: CliRunner) -> None:
    with patch("sbom_sentinel.cli.sbom.generate",
               side_effect=subprocess.TimeoutExpired("syft", 600)):
        result = runner.invoke(cli, ["sbom", "--target", "docker:nginx", "--name", "nginx"])
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# scan command
# ---------------------------------------------------------------------------


def test_scan_cmd_calls_run(runner: CliRunner, sbom_file: Path, tmp_path: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run", return_value=tmp_path / "scan.json") as mock:
        result = runner.invoke(cli, ["scan", "--sbom", str(sbom_file), "--name", "app"])
    mock.assert_called_once()
    assert result.exit_code == 0


def test_scan_cmd_passes_fail_on(runner: CliRunner, sbom_file: Path, tmp_path: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run", return_value=tmp_path / "scan.json") as mock:
        runner.invoke(cli, ["scan", "--sbom", str(sbom_file), "--name", "app",
                            "--fail-on", "high"])
    # fail_on is passed positionally (4th arg: sbom_file, name, output_dir, fail_on)
    assert mock.call_args[0][3] == "high"


def test_scan_cmd_passes_fmt(runner: CliRunner, sbom_file: Path, tmp_path: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run", return_value=tmp_path / "scan.sarif") as mock:
        runner.invoke(cli, ["scan", "--sbom", str(sbom_file), "--name", "app",
                            "--format", "sarif"])
    assert mock.call_args.kwargs["fmt"] == "sarif"


def test_scan_cmd_passes_vex(
    runner: CliRunner, sbom_file: Path, vex_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.scan.run", return_value=tmp_path / "scan.json") as mock:
        runner.invoke(cli, ["scan", "--sbom", str(sbom_file), "--name", "app",
                            "--vex", str(vex_file)])
    assert mock.call_args.kwargs["vex"] == vex_file


def test_scan_cmd_oserror_exits_1(runner: CliRunner, sbom_file: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run", side_effect=OSError("grype not found")):
        result = runner.invoke(cli, ["scan", "--sbom", str(sbom_file), "--name", "app"])
    assert result.exit_code == 1


def test_scan_cmd_called_process_error_exits_1(runner: CliRunner, sbom_file: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run",
               side_effect=subprocess.CalledProcessError(1, "grype")):
        result = runner.invoke(
            cli, ["scan", "--sbom", str(sbom_file), "--name", "app", "--fail-on", "high"]
        )
    assert result.exit_code == 1


def test_scan_cmd_timeout_exits_1(runner: CliRunner, sbom_file: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run",
               side_effect=subprocess.TimeoutExpired("grype", 300)):
        result = runner.invoke(cli, ["scan", "--sbom", str(sbom_file), "--name", "app"])
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# report command
# ---------------------------------------------------------------------------


def test_report_cmd_calls_generate(
    runner: CliRunner, scan_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.kev.load", return_value=set()):
        with patch(
            "sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"
        ) as mock:
            result = runner.invoke(cli, ["report", "--scan", str(scan_file), "--name", "app"])
    mock.assert_called_once()
    assert result.exit_code == 0


def test_report_cmd_loads_kev_by_default(
    runner: CliRunner, scan_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.kev.load", return_value={"CVE-2021-44228"}) as mock_kev:
        with patch("sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"):
            runner.invoke(cli, ["report", "--scan", str(scan_file), "--name", "app"])
    mock_kev.assert_called_once()


def test_report_cmd_no_kev_skips_load(
    runner: CliRunner, scan_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.kev.load") as mock_kev:
        with patch("sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"):
            runner.invoke(cli, ["report", "--scan", str(scan_file), "--name", "app",
                                "--no-kev"])
    mock_kev.assert_not_called()


def test_report_cmd_no_kev_passes_empty_set(
    runner: CliRunner, scan_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.kev.load"):
        with patch(
            "sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"
        ) as mock:
            runner.invoke(cli, ["report", "--scan", str(scan_file), "--name", "app",
                                "--no-kev"])
    assert mock.call_args[0][3] == set()


def test_report_cmd_passes_vex(
    runner: CliRunner, scan_file: Path, vex_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.kev.load", return_value=set()):
        with patch(
            "sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"
        ) as mock:
            runner.invoke(cli, ["report", "--scan", str(scan_file), "--name", "app",
                                "--vex", str(vex_file)])
    assert mock.call_args.kwargs["vex"] == vex_file


def test_report_cmd_valueerror_exits_1(runner: CliRunner, scan_file: Path) -> None:
    # Covers the SARIF-input guard and any other ValueError from report.generate.
    with patch("sbom_sentinel.cli.kev.load", return_value=set()):
        with patch("sbom_sentinel.cli.report.generate",
                   side_effect=ValueError("SARIF file")):
            result = runner.invoke(
                cli, ["report", "--scan", str(scan_file), "--name", "app"]
            )
    assert result.exit_code == 1


def test_report_cmd_json_decode_error_exits_1(runner: CliRunner, scan_file: Path) -> None:
    with patch("sbom_sentinel.cli.kev.load", return_value=set()):
        with patch("sbom_sentinel.cli.report.generate",
                   side_effect=json.JSONDecodeError("bad json", "", 0)):
            result = runner.invoke(
                cli, ["report", "--scan", str(scan_file), "--name", "app"]
            )
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# run command (orchestrator)
# ---------------------------------------------------------------------------


def test_run_cmd_chains_scan_then_report(
    runner: CliRunner, sbom_file: Path, tmp_path: Path
) -> None:
    scan_out = tmp_path / "scan.json"
    with patch("sbom_sentinel.cli.scan.run", return_value=scan_out) as mock_scan:
        with patch("sbom_sentinel.cli.kev.load", return_value=set()):
            with patch(
                "sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"
            ) as mock_report:
                result = runner.invoke(
                    cli, ["run", "--sbom", str(sbom_file), "--name", "app"]
                )
    mock_scan.assert_called_once()
    mock_report.assert_called_once()
    assert mock_report.call_args[0][0] == scan_out
    assert result.exit_code == 0


def test_run_cmd_scan_oserror_exits_1(runner: CliRunner, sbom_file: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run", side_effect=OSError("grype not found")):
        result = runner.invoke(cli, ["run", "--sbom", str(sbom_file), "--name", "app"])
    assert result.exit_code == 1


def test_run_cmd_scan_fail_on_exits_1(runner: CliRunner, sbom_file: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run",
               side_effect=subprocess.CalledProcessError(1, "grype")):
        result = runner.invoke(
            cli, ["run", "--sbom", str(sbom_file), "--name", "app", "--fail-on", "critical"]
        )
    assert result.exit_code == 1


def test_run_cmd_scan_timeout_exits_1(runner: CliRunner, sbom_file: Path) -> None:
    with patch("sbom_sentinel.cli.scan.run",
               side_effect=subprocess.TimeoutExpired("grype", 300)):
        result = runner.invoke(cli, ["run", "--sbom", str(sbom_file), "--name", "app"])
    assert result.exit_code == 1


def test_run_cmd_no_kev_skips_load(
    runner: CliRunner, sbom_file: Path, tmp_path: Path
) -> None:
    with patch("sbom_sentinel.cli.scan.run", return_value=tmp_path / "scan.json"):
        with patch("sbom_sentinel.cli.kev.load") as mock_kev:
            with patch("sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"):
                runner.invoke(
                    cli, ["run", "--sbom", str(sbom_file), "--name", "app", "--no-kev"]
                )
    mock_kev.assert_not_called()


def test_run_cmd_passes_vex_to_both_stages(
    runner: CliRunner, sbom_file: Path, vex_file: Path, tmp_path: Path
) -> None:
    scan_out = tmp_path / "scan.json"
    with patch("sbom_sentinel.cli.scan.run", return_value=scan_out) as mock_scan:
        with patch("sbom_sentinel.cli.kev.load", return_value=set()):
            with patch(
                "sbom_sentinel.cli.report.generate", return_value=tmp_path / "report.md"
            ) as mock_report:
                runner.invoke(cli, ["run", "--sbom", str(sbom_file), "--name", "app",
                                    "--vex", str(vex_file)])
    assert mock_scan.call_args.kwargs["vex"] == vex_file
    assert mock_report.call_args.kwargs["vex"] == vex_file


def test_run_cmd_report_error_exits_1(
    runner: CliRunner, sbom_file: Path, tmp_path: Path
) -> None:
    # Scan succeeds but report.generate raises — run_cmd must still exit 1.
    with patch("sbom_sentinel.cli.scan.run", return_value=tmp_path / "scan.json"):
        with patch("sbom_sentinel.cli.kev.load", return_value=set()):
            with patch("sbom_sentinel.cli.report.generate",
                       side_effect=ValueError("SARIF file")):
                result = runner.invoke(
                    cli, ["run", "--sbom", str(sbom_file), "--name", "app"]
                )
    assert result.exit_code == 1
