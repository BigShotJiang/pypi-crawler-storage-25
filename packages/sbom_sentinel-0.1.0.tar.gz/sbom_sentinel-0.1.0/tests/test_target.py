from pathlib import Path

import pytest

from sbom_sentinel.support.target import resolve


@pytest.mark.parametrize("target,expected_type,expected_value", [
    ("docker:ubuntu:22.04", "image", "docker:ubuntu:22.04"),
    ("docker:nginx",        "image", "docker:nginx"),
    ("https://github.com/user/repo", "git", "https://github.com/user/repo"),
    ("git@github.com:user/repo.git", "git", "git@github.com:user/repo.git"),
    ("ghcr.io/user/image:latest",    "image", "ghcr.io/user/image:latest"),
    ("library/ubuntu",               "image", "library/ubuntu"),
    ("namespace/app:1.2.3",          "image", "namespace/app:1.2.3"),
])
def test_resolve_known_patterns(target: str, expected_type: str, expected_value: str) -> None:
    t, v = resolve(target)
    assert t == expected_type
    assert v == expected_value


def test_resolve_local_dir(tmp_path: Path) -> None:
    t, v = resolve(str(tmp_path))
    assert t == "dir"
    assert Path(v) == tmp_path


def test_resolve_local_file(tmp_path: Path) -> None:
    f = tmp_path / "sbom.spdx.json"
    f.write_text("{}")
    t, v = resolve(str(f))
    assert t == "file"
    assert Path(v) == f


def test_resolve_absolute_nonexistent_raises() -> None:
    with pytest.raises(ValueError, match="Cannot resolve target"):
        resolve("/nonexistent/path/that/definitely/does/not/exist")


def test_resolve_relative_nonexistent_raises() -> None:
    with pytest.raises(ValueError):
        resolve("this_path_does_not_exist_anywhere")
