# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0
"""Tests for AWS Transform Agent Builder SDK module."""


def test_agent_builder_sdk_importable():
    """Test agent_builder_sdk is importable."""
    import agent_builder_sdk  # noqa: F401
