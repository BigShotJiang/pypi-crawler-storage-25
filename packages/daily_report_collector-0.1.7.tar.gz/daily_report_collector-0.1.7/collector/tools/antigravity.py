"""Antigravity tool definition — watches ~/.antigravity/ and ~/.gemini/antigravity/."""

from __future__ import annotations

from pathlib import Path

import os
import platform

from ..config import TOOL_PATHS, HOME
from ..parsers.antigravity_vscdb import extract_antigravity_conversations, format_as_markdown
from .base import (
    BaseTool, Category, ContentType, FileClassification, SyncStrategy, WatchPath,
)

# Antigravity stores conversations and brain data in ~/.gemini/ (Unix) or %APPDATA%/.gemini (Windows)
if platform.system() == "Windows":
    _appdata = Path(os.environ.get("APPDATA", str(HOME / "AppData" / "Roaming")))
    GEMINI_ROOT = _appdata / ".gemini" if (_appdata / ".gemini").exists() else HOME / ".gemini"
else:
    GEMINI_ROOT = HOME / ".gemini"


class AntigravityTool(BaseTool):

    @property
    def name(self) -> str:
        return "antigravity"

    @property
    def display_name(self) -> str:
        return "Antigravity"

    @property
    def root_path(self) -> Path:
        return TOOL_PATHS["antigravity"]

    @property
    def _gemini_path(self) -> Path:
        return GEMINI_ROOT / "antigravity"

    def is_available(self) -> bool:
        return self.root_path.exists() or self._gemini_path.exists()

    def get_watch_paths(self) -> list[WatchPath]:
        root = self.root_path
        gemini = self._gemini_path
        paths = [
            # VS Code config
            WatchPath(
                path=root,
                pattern="argv.json",
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                description="VS Code argv configuration",
            ),
            WatchPath(
                path=root / "extensions",
                pattern="extensions.json",
                category=Category.EXTENSION,
                content_type=ContentType.JSON,
                description="Installed extension registry",
            ),
        ]

        # Gemini brain — task plans, walkthroughs, implementation plans
        if gemini.exists():
            paths.extend([
                # Brain: task markdown (the AI's thinking/plan per session)
                WatchPath(
                    path=gemini / "brain",
                    pattern="**/*.md",
                    category=Category.PLAN,
                    content_type=ContentType.MARKDOWN,
                    recursive=True,
                    description="AI task plans, walkthroughs, implementation plans",
                ),
                # Brain: resolved versions (iteration history)
                WatchPath(
                    path=gemini / "brain",
                    pattern="**/*.resolved*",
                    category=Category.PLAN,
                    content_type=ContentType.MARKDOWN,
                    recursive=True,
                    description="Resolved plan versions (iteration history)",
                ),
                # Brain: metadata
                WatchPath(
                    path=gemini / "brain",
                    pattern="**/*.metadata.json",
                    category=Category.PLAN,
                    content_type=ContentType.JSON,
                    recursive=True,
                    description="Task metadata (summary, timestamps)",
                ),
                # GEMINI.md (user rules)
                WatchPath(
                    path=GEMINI_ROOT,
                    pattern="GEMINI.md",
                    category=Category.IDENTITY,
                    content_type=ContentType.MARKDOWN,
                    description="Gemini user rules file",
                ),
                # Code tracker — AI-modified source code snapshots
                WatchPath(
                    path=gemini / "code_tracker" / "active",
                    pattern="**/*",
                    category=Category.FILE_HISTORY,
                    content_type=ContentType.TEXT,
                    recursive=True,
                    description="AI-modified code file snapshots",
                ),
            ])

        return paths

    def extract_vscdb_conversations(self) -> str | None:
        """Extract conversation fragments from vscdb and return as markdown."""
        conversations = extract_antigravity_conversations()
        if not conversations:
            return None
        return format_as_markdown(conversations)

    def classify_file(self, abs_path: Path) -> FileClassification | None:
        # Try ~/.antigravity/ first
        try:
            rel = abs_path.relative_to(self.root_path)
            rel_str = str(rel).replace("\\", "/")

            if rel_str == "argv.json":
                return FileClassification(
                    tool_name=self.name, category=Category.CONFIG,
                    content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )
            if rel_str == "extensions/extensions.json":
                return FileClassification(
                    tool_name=self.name, category=Category.EXTENSION,
                    content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )
            return None
        except ValueError:
            pass

        # Try ~/.gemini/
        try:
            rel = abs_path.relative_to(GEMINI_ROOT)
            rel_str = str(rel).replace("\\", "/")
            parts = rel.parts
        except ValueError:
            return None

        # GEMINI.md
        if rel_str == "GEMINI.md":
            return FileClassification(
                tool_name=self.name, category=Category.IDENTITY,
                content_type=ContentType.MARKDOWN, sync_strategy=SyncStrategy.FULL,
                relative_path=f"gemini/{rel_str}",
            )

        # Skip non-antigravity dirs under .gemini
        if not parts or parts[0] != "antigravity":
            return None

        # Brain markdown files
        if len(parts) >= 3 and parts[1] == "brain":
            session_id = parts[2]

            # Skip images/screenshots
            if abs_path.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".gif"):
                return None

            # Task/plan markdown
            if abs_path.suffix == ".md" or ".resolved" in abs_path.name:
                doc_type = abs_path.stem.split(".")[0]  # task, walkthrough, implementation_plan
                return FileClassification(
                    tool_name=self.name, category=Category.PLAN,
                    content_type=ContentType.MARKDOWN, sync_strategy=SyncStrategy.FULL,
                    relative_path=f"gemini/{rel_str}",
                    metadata={"session_id": session_id, "doc_type": doc_type},
                )

            # Metadata JSON
            if abs_path.suffix == ".json":
                return FileClassification(
                    tool_name=self.name, category=Category.PLAN,
                    content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                    relative_path=f"gemini/{rel_str}",
                    metadata={"session_id": session_id},
                )

            return None

        # Code tracker — AI-modified source code snapshots
        if len(parts) >= 3 and parts[1] == "code_tracker":
            # Skip binary files
            if abs_path.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".ico", ".woff", ".woff2", ".ttf"):
                return None
            # Extract project name from directory
            project_dir = parts[3] if len(parts) >= 4 else ""
            project_name = project_dir.rsplit("_", 1)[0] if "_" in project_dir else project_dir
            return FileClassification(
                tool_name=self.name, category=Category.FILE_HISTORY,
                content_type=ContentType.TEXT, sync_strategy=SyncStrategy.FULL,
                relative_path=f"gemini/{rel_str}",
                metadata={"project_name": project_name, "original_file": abs_path.name},
            )

        return None

    @property
    def excluded_paths(self) -> list[str]:
        root = str(self.root_path)
        gemini = str(GEMINI_ROOT)
        return [
            f"{root}/extensions/*/dist/**",
            f"{root}/extensions/*/bundled/**",
            f"{root}/extensions/*/node_modules/**",
            # Skip encrypted conversation .pb files
            f"{gemini}/antigravity/conversations/**",
            f"{gemini}/antigravity/implicit/**",
            # Skip browser profile
            f"{gemini}/antigravity-browser-profile/**",
            # Skip screenshots in brain (keep .md and .json only)
            f"{gemini}/antigravity/brain/**/*.png",
            f"{gemini}/antigravity/brain/**/*.webp",
            f"{gemini}/antigravity/brain/**/*.jpg",
        ]
