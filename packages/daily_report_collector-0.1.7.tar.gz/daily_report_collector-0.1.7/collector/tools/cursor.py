"""Cursor tool definition — watches ~/.cursor/ for conversations, skills, config."""

from __future__ import annotations

from pathlib import Path

from ..config import TOOL_PATHS
from .base import (
    BaseTool, Category, ContentType, FileClassification, SyncStrategy, WatchPath,
)


class CursorTool(BaseTool):

    @property
    def name(self) -> str:
        return "cursor"

    @property
    def display_name(self) -> str:
        return "Cursor"

    @property
    def root_path(self) -> Path:
        return TOOL_PATHS["cursor"]

    def get_watch_paths(self) -> list[WatchPath]:
        if not self.is_available():
            return []
        root = self.root_path
        return [
            # Config
            WatchPath(
                path=root,
                pattern="argv.json",
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                description="Cursor argv configuration",
            ),
            # Extensions
            WatchPath(
                path=root / "extensions",
                pattern="extensions.json",
                category=Category.EXTENSION,
                content_type=ContentType.JSON,
                description="Installed extensions",
            ),
            # Agent transcripts (conversations) — same format as Claude Code
            WatchPath(
                path=root / "projects",
                pattern="**/*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                recursive=True,
                description="Agent conversation transcripts",
            ),
            # Project MCP instructions
            WatchPath(
                path=root / "projects",
                pattern="**/*.md",
                category=Category.MEMORY,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="MCP instructions and project rules",
            ),
            # Project metadata
            WatchPath(
                path=root / "projects",
                pattern="**/*.json",
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                recursive=True,
                description="Project and MCP metadata",
            ),
            # Skills
            WatchPath(
                path=root / "skills-cursor",
                pattern="**/*.md",
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="Cursor built-in skills",
            ),
            # AI tracking database
            WatchPath(
                path=root / "ai-tracking",
                pattern="*.db",
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="AI code tracking database",
            ),
        ]

    def classify_file(self, abs_path: Path) -> FileClassification | None:
        if not self.is_available():
            return None
        try:
            rel = abs_path.relative_to(self.root_path)
        except ValueError:
            return None

        rel_str = str(rel).replace("\\", "/")
        parts = rel.parts

        # Skip cache, crashpad, etc.
        skip = {".gitignore"}
        if abs_path.name in skip:
            return None

        # argv.json
        if rel_str == "argv.json":
            return FileClassification(
                tool_name=self.name, category=Category.CONFIG,
                content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # extensions
        if rel_str == "extensions/extensions.json":
            return FileClassification(
                tool_name=self.name, category=Category.EXTENSION,
                content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # projects/ — agent transcripts
        if parts and parts[0] == "projects":
            if abs_path.suffix == ".jsonl":
                # Conversation transcripts
                project_hash = parts[1] if len(parts) >= 2 else ""
                is_subagent = "subagents" in parts
                return FileClassification(
                    tool_name=self.name, category=Category.CONVERSATION,
                    content_type=ContentType.JSONL, sync_strategy=SyncStrategy.DELTA,
                    relative_path=rel_str,
                    metadata={
                        "project_hash": project_hash,
                        "session_id": abs_path.stem,
                        "is_subagent": is_subagent,
                    },
                )
            if abs_path.suffix == ".md":
                return FileClassification(
                    tool_name=self.name, category=Category.MEMORY,
                    content_type=ContentType.MARKDOWN, sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )
            if abs_path.suffix == ".json":
                return FileClassification(
                    tool_name=self.name, category=Category.CONFIG,
                    content_type=ContentType.JSON, sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )

        # skills-cursor/
        if parts and parts[0] == "skills-cursor" and abs_path.suffix == ".md":
            return FileClassification(
                tool_name=self.name, category=Category.SKILL,
                content_type=ContentType.MARKDOWN, sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # ai-tracking
        if parts and parts[0] == "ai-tracking" and abs_path.suffix == ".db":
            return FileClassification(
                tool_name=self.name, category=Category.STATE,
                content_type=ContentType.SQLITE, sync_strategy=SyncStrategy.POLL,
                relative_path=rel_str,
            )

        return None
