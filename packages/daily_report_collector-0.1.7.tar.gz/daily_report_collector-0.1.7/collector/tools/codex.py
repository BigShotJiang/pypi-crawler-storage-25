"""Codex tool definition — watches ~/.codex/ for sessions, history, config."""

from __future__ import annotations

from pathlib import Path

from ..config import TOOL_PATHS
from .base import (
    BaseTool, Category, ContentType, FileClassification, SyncStrategy, WatchPath,
)


class CodexTool(BaseTool):

    @property
    def name(self) -> str:
        return "codex"

    @property
    def display_name(self) -> str:
        return "Codex"

    @property
    def root_path(self) -> Path:
        return TOOL_PATHS["codex"]

    def get_watch_paths(self) -> list[WatchPath]:
        root = self.root_path
        return [
            # Config
            WatchPath(
                path=root,
                pattern="config.toml",
                category=Category.CONFIG,
                content_type=ContentType.TOML,
                description="Main config: model, reasoning level, personality",
            ),
            # AGENTS.md
            WatchPath(
                path=root,
                pattern="AGENTS.md",
                category=Category.IDENTITY,
                content_type=ContentType.MARKDOWN,
                description="Agent instructions",
            ),
            # History
            WatchPath(
                path=root,
                pattern="history.jsonl",
                category=Category.HISTORY,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                description="Session command history",
            ),
            # Active sessions
            WatchPath(
                path=root / "sessions",
                pattern="**/*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                recursive=True,
                description="Conversation session transcripts",
            ),
            # Archived sessions
            WatchPath(
                path=root / "archived_sessions",
                pattern="*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                description="Archived conversation sessions",
            ),
            # SQLite logs (polled)
            WatchPath(
                path=root,
                pattern="logs_1.sqlite",
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="Structured log database",
            ),
            # SQLite state (polled)
            WatchPath(
                path=root,
                pattern="state_5.sqlite",
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="Threads and jobs state database",
            ),
            # Skills
            WatchPath(
                path=root / "vendor_imports",
                pattern="**/*.md",
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="Curated vendor skills (44+)",
            ),
        ]

    def classify_file(self, abs_path: Path) -> FileClassification | None:
        try:
            rel = abs_path.relative_to(self.root_path)
        except ValueError:
            return None

        rel_str = str(rel).replace("\\", "/")
        parts = rel.parts

        # Exclude auth, cache, tmp, log, shell snapshots
        skip_dirs = {"cache", "tmp", ".tmp", "log", "shell_snapshots"}
        if parts and parts[0] in skip_dirs:
            return None

        # Exclude auth.json entirely
        if rel_str == "auth.json":
            return None

        # config.toml
        if rel_str == "config.toml":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.TOML,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # AGENTS.md
        if rel_str == "AGENTS.md":
            return FileClassification(
                tool_name=self.name,
                category=Category.IDENTITY,
                content_type=ContentType.MARKDOWN,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # history.jsonl
        if rel_str == "history.jsonl":
            return FileClassification(
                tool_name=self.name,
                category=Category.HISTORY,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
            )

        # Active sessions
        if parts[0] == "sessions" and abs_path.suffix == ".jsonl":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
                metadata={"session_name": abs_path.stem},
            )

        # Archived sessions
        if parts[0] == "archived_sessions" and abs_path.suffix == ".jsonl":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
                metadata={"session_name": abs_path.stem, "archived": True},
            )

        # version.json
        if rel_str == "version.json":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # SQLite databases
        if abs_path.name in ("logs_1.sqlite", "state_5.sqlite"):
            return FileClassification(
                tool_name=self.name,
                category=Category.STATE,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                relative_path=rel_str,
            )

        # Skills / vendor imports
        if parts[0] == "vendor_imports" and abs_path.suffix == ".md":
            return FileClassification(
                tool_name=self.name,
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # models_cache.json — useful for tracking model availability
        if rel_str == "models_cache.json":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        return None

    @property
    def excluded_paths(self) -> list[str]:
        root = str(self.root_path)
        return [
            f"{root}/auth.json",
            f"{root}/cache/**",
            f"{root}/tmp/**",
            f"{root}/.tmp/**",
            f"{root}/log/**",
            f"{root}/shell_snapshots/**",
        ]
