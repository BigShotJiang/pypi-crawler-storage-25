"""OpenClaw tool definition — watches ~/.openclaw/ for memory, identity, learnings."""

from __future__ import annotations

from pathlib import Path

from ..config import TOOL_PATHS
from .base import (
    BaseTool, Category, ContentType, FileClassification, SyncStrategy, WatchPath,
)

# Core workspace markdown files
CORE_IDENTITY_FILES = {
    "AGENTS.md", "SOUL.md", "MEMORY.md", "IDENTITY.md",
    "USER.md", "HEARTBEAT.md", "TOOLS.md",
}


class OpenClawTool(BaseTool):

    @property
    def name(self) -> str:
        return "openclaw"

    @property
    def display_name(self) -> str:
        return "OpenClaw"

    @property
    def root_path(self) -> Path:
        return TOOL_PATHS["openclaw"]

    def get_watch_paths(self) -> list[WatchPath]:
        root = self.root_path
        ws = root / "workspace"
        return [
            # Config
            WatchPath(
                path=root,
                pattern="openclaw.json",
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                description="Main OpenClaw configuration",
            ),
            # Core identity files
            WatchPath(
                path=ws,
                pattern="*.md",
                category=Category.IDENTITY,
                content_type=ContentType.MARKDOWN,
                description="Core identity: AGENTS, SOUL, MEMORY, IDENTITY, USER, HEARTBEAT, TOOLS",
            ),
            # Daily memory
            WatchPath(
                path=ws / "memory",
                pattern="*.md",
                category=Category.MEMORY,
                content_type=ContentType.MARKDOWN,
                description="Dated daily memory files (YYYY-MM-DD.md)",
            ),
            # Learning system
            WatchPath(
                path=ws / ".learnings",
                pattern="*.md",
                category=Category.LEARNING,
                content_type=ContentType.MARKDOWN,
                description="ERRORS.md, LEARNINGS.md, FEATURE_REQUESTS.md",
            ),
            # Skills
            WatchPath(
                path=ws / "skills",
                pattern="**/*.md",
                category=Category.SKILL,
                content_type=ContentType.MARKDOWN,
                recursive=True,
                description="Self-improving agent skills",
            ),
            # Session conversations
            WatchPath(
                path=root / "agents" / "main" / "sessions",
                pattern="*.jsonl",
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                description="Chat session transcripts",
            ),
            # Subagent runs
            WatchPath(
                path=root / "subagents",
                pattern="*.json",
                category=Category.CONVERSATION,
                content_type=ContentType.JSON,
                description="Subagent run metadata",
            ),
            # Gateway logs (useful for debugging)
            WatchPath(
                path=root / "logs",
                pattern="config-audit.jsonl",
                category=Category.HISTORY,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                description="Config audit log",
            ),
            # SQLite vector memory (polled)
            WatchPath(
                path=root / "memory",
                pattern="main.sqlite",
                category=Category.MEMORY,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                description="Vector memory database",
            ),
        ]

    def classify_file(self, abs_path: Path) -> FileClassification | None:
        try:
            rel = abs_path.relative_to(self.root_path)
        except ValueError:
            return None

        rel_str = str(rel).replace("\\", "/")
        parts = rel.parts

        # Exclude credentials, media, canvas, identity dirs
        skip_dirs = {"credentials", "media", "canvas", "identity"}
        if parts and parts[0] in skip_dirs:
            return None

        # Handle agents/main/sessions/*.jsonl — conversation sessions
        if len(parts) >= 4 and parts[:3] == ("agents", "main", "sessions") and abs_path.suffix == ".jsonl":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONVERSATION,
                content_type=ContentType.JSONL,
                sync_strategy=SyncStrategy.DELTA,
                relative_path=rel_str,
                metadata={"session_id": abs_path.stem},
            )

        # Skip other files under agents/, hooks/, logs/ (except config-audit)
        if parts and parts[0] in ("agents", "hooks"):
            return None
        if parts and parts[0] == "logs" and abs_path.name != "config-audit.jsonl":
            return None

        # Skip backup config files
        if abs_path.name.startswith("openclaw.json.bak"):
            return None

        # openclaw.json
        if rel_str == "openclaw.json":
            return FileClassification(
                tool_name=self.name,
                category=Category.CONFIG,
                content_type=ContentType.JSON,
                sync_strategy=SyncStrategy.FULL,
                relative_path=rel_str,
            )

        # workspace/ files
        if parts[0] == "workspace":
            # Core identity files in workspace root
            if len(parts) == 2 and abs_path.name in CORE_IDENTITY_FILES:
                return FileClassification(
                    tool_name=self.name,
                    category=Category.IDENTITY,
                    content_type=ContentType.MARKDOWN,
                    sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                    metadata={"identity_type": abs_path.stem},
                )

            # Daily memory: workspace/memory/*.md
            if len(parts) >= 3 and parts[1] == "memory" and abs_path.suffix == ".md":
                return FileClassification(
                    tool_name=self.name,
                    category=Category.MEMORY,
                    content_type=ContentType.MARKDOWN,
                    sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                    metadata={"date_hint": abs_path.stem},
                )

            # Learnings: workspace/.learnings/*.md
            if len(parts) >= 3 and parts[1] == ".learnings" and abs_path.suffix == ".md":
                return FileClassification(
                    tool_name=self.name,
                    category=Category.LEARNING,
                    content_type=ContentType.MARKDOWN,
                    sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                    metadata={"learning_type": abs_path.stem},
                )

            # Skills: workspace/skills/**/*.md
            if "skills" in parts and abs_path.suffix == ".md":
                return FileClassification(
                    tool_name=self.name,
                    category=Category.SKILL,
                    content_type=ContentType.MARKDOWN,
                    sync_strategy=SyncStrategy.FULL,
                    relative_path=rel_str,
                )

        # SQLite vector memory
        if rel_str == "memory/main.sqlite":
            return FileClassification(
                tool_name=self.name,
                category=Category.MEMORY,
                content_type=ContentType.SQLITE,
                sync_strategy=SyncStrategy.POLL,
                relative_path=rel_str,
            )

        return None

    @property
    def excluded_paths(self) -> list[str]:
        root = str(self.root_path)
        return [
            f"{root}/credentials/**",
            f"{root}/logs/**",
            f"{root}/hooks/**",
            f"{root}/media/**",
            f"{root}/canvas/**",
        ]

    @property
    def sensitive_json_keys(self) -> list[str]:
        return ["auth", "botToken", "token"]
