"""Earn commands: fere earn (info, deposit, withdraw, positions)."""

from __future__ import annotations

import click
from rich.console import Console

from ..async_util import async_command, get_client, is_tty
from ..output import print_error, print_success

console = Console()


@click.group()
def earn():
    """Manage yield earning (deposit, withdraw, view APY)."""
    pass


@earn.command()
@click.pass_context
@async_command
async def info(ctx):
    """Show current APY and vault details."""
    try:
        client = await get_client(ctx)
        data = await client.get_earn_info()
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@earn.command()
@click.option(
    "--amount",
    required=True,
    type=float,
    help="USDC amount to deposit.",
)
@click.option(
    "--position-id",
    default=None,
    help="Existing position ID to add to.",
)
@click.option(
    "--timeout", default=120, type=int, help="Wait timeout (seconds)."
)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@async_command
async def deposit(ctx, amount, position_id, timeout, yes):
    """Deposit USDC to earn yield."""
    if not yes and is_tty():
        click.echo(f"Deposit {amount} USDC into Fere Earn")
        if not click.confirm("Proceed?"):
            raise SystemExit(0)

    try:
        client = await get_client(ctx)

        with console.status("Processing deposit..."):
            result = await client.deposit(
                amount_usdc=amount,
                position_id=position_id,
                timeout=timeout,
            )

        await client.close()
        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@earn.command()
@click.option(
    "--position-id",
    required=True,
    help="Position ID to withdraw from.",
)
@click.option(
    "--amount",
    required=True,
    type=float,
    help="USDC amount to withdraw.",
)
@click.option(
    "--timeout", default=120, type=int, help="Wait timeout (seconds)."
)
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation.")
@click.pass_context
@async_command
async def withdraw(ctx, position_id, amount, timeout, yes):
    """Withdraw USDC from a yield position."""
    if not yes and is_tty():
        click.echo(
            f"Withdraw {amount} USDC from position {position_id}"
        )
        if not click.confirm("Proceed?"):
            raise SystemExit(0)

    try:
        client = await get_client(ctx)

        with console.status("Processing withdrawal..."):
            result = await client.withdraw(
                position_id=position_id,
                amount_usdc=amount,
                timeout=timeout,
            )

        await client.close()
        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@earn.command()
@click.pass_context
@async_command
async def positions(ctx):
    """Show active yield positions."""
    try:
        client = await get_client(ctx)
        data = await client.get_positions()
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
