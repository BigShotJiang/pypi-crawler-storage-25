"""Utility commands: fere chains, fere status, fere config."""

from __future__ import annotations

import click
import httpx

from ..async_util import async_command, get_client
from ..config import load_config, set_config_value
from ..output import print_error, print_success


@click.command()
@click.pass_context
@async_command
async def chains(ctx):
    """List supported blockchains with chain IDs."""
    try:
        client = await get_client(ctx)
        data = await client.get_chains()
        await client.close()

        print_success(data)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)


@click.command()
@click.pass_context
@async_command
async def status(ctx):
    """Check gateway service connectivity."""
    cfg = load_config()
    base_url = ctx.obj.get("base_url_override") or cfg.get("base_url")

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            resp = await client.get(f"{base_url}/health")
            resp.raise_for_status()
            data = resp.json()

        print_success(
            {"status": "ok", "base_url": base_url, **data},
            quiet_value="ok",
        )
    except Exception as e:
        print_error(f"Cannot reach {base_url}: {e}")
        raise SystemExit(1)


@click.group(invoke_without_command=True)
@click.pass_context
def config(ctx):
    """Show or modify CLI configuration."""
    if ctx.invoked_subcommand is None:
        cfg = load_config()
        print_success(cfg)


@config.command(name="set")
@click.argument("key")
@click.argument("value")
def config_set(key, value):
    """Set a config value. Example: fere config set agent_name my-bot"""
    set_config_value(key, value)
    print_success(
        {"key": key, "value": value},
        quiet_value=value,
    )


@config.command(name="get")
@click.argument("key")
def config_get(key):
    """Get a config value."""
    cfg = load_config()
    value = cfg.get(key)
    if value is None:
        print_error(f"Unknown config key: {key}")
        raise SystemExit(1)
    print_success(
        {"key": key, "value": value},
        quiet_value=str(value),
    )
