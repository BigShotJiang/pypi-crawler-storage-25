"""Swap command: fere swap."""

from __future__ import annotations

import click
from rich.console import Console

from ..async_util import async_command, get_client, is_tty
from ..output import print_error, print_success

console = Console()


@click.command()
@click.option(
    "--chain-in",
    required=True,
    type=int,
    help="Source chain ID.",
)
@click.option(
    "--chain-out",
    required=True,
    type=int,
    help="Destination chain ID.",
)
@click.option(
    "--token-in",
    required=True,
    help="Source token contract address.",
)
@click.option(
    "--token-out",
    required=True,
    help="Destination token contract address.",
)
@click.option(
    "--amount",
    required=True,
    help="Amount in smallest unit (wei/lamports).",
)
@click.option(
    "--slippage-bps",
    default=50,
    type=int,
    help="Slippage tolerance in basis points (default: 50).",
)
@click.option(
    "--dryrun",
    is_flag=True,
    default=False,
    help="Simulate without executing.",
)
@click.option(
    "--timeout",
    default=120,
    type=int,
    help="Max seconds to wait for completion (default: 120).",
)
@click.option(
    "-y",
    "--yes",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt.",
)
@click.pass_context
@async_command
async def swap(
    ctx,
    chain_in,
    chain_out,
    token_in,
    token_out,
    amount,
    slippage_bps,
    dryrun,
    timeout,
    yes,
):
    """Execute a token swap on any supported blockchain."""
    # Confirmation prompt (TTY only)
    if not yes and is_tty() and not dryrun:
        click.echo(
            f"Swap {amount} units\n"
            f"  From: {token_in} (chain {chain_in})\n"
            f"  To:   {token_out} (chain {chain_out})\n"
            f"  Slippage: {slippage_bps} bps"
        )
        if not click.confirm("Proceed?"):
            raise SystemExit(0)

    try:
        client = await get_client(ctx)

        with console.status("Executing swap..."):
            result = await client.swap(
                chain_id_in=chain_in,
                chain_id_out=chain_out,
                token_in=token_in,
                token_out=token_out,
                amount=amount,
                slippage_bps=slippage_bps,
                timeout=timeout,
                dryrun=dryrun,
            )

        await client.close()
        print_success(result)
    except click.ClickException:
        raise
    except Exception as e:
        print_error(str(e))
        raise SystemExit(1)
