"""Output formatting utilities.

Supports three modes:
- **human** (default): Rich tables, panels, colored text
- **json** (``--json``): Machine-readable JSON to stdout
- **quiet** (``--quiet``): Minimal output
"""

from __future__ import annotations

import json as json_lib
import sys
from typing import Any

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()
err_console = Console(stderr=True)


def _ctx_obj() -> dict:
    ctx = click.get_current_context(silent=True)
    return ctx.obj if ctx and ctx.obj else {}


def is_json_mode() -> bool:
    return _ctx_obj().get("output_json", False)


def is_quiet_mode() -> bool:
    return _ctx_obj().get("quiet", False)


def print_success(data: Any, quiet_value: str | None = None) -> None:
    """Print a successful result in the appropriate format."""
    if is_json_mode():
        print_json({"ok": True, "data": data})
    elif is_quiet_mode() and quiet_value is not None:
        click.echo(quiet_value)
    else:
        if isinstance(data, dict):
            print_dict(data)
        elif isinstance(data, list):
            if data and isinstance(data[0], dict):
                print_table_from_dicts(data)
            else:
                for item in data:
                    click.echo(item)
        else:
            click.echo(data)


def print_error(message: str, details: Any = None) -> None:
    """Print an error in the appropriate format."""
    if is_json_mode():
        err = {"ok": False, "error": message}
        if details:
            err["details"] = details
        print_json(err)
    else:
        err_console.print(f"[red]Error:[/red] {message}")
        if details:
            err_console.print(details)


def print_json(data: Any) -> None:
    """Print JSON to stdout."""
    click.echo(json_lib.dumps(data, indent=2, default=str))


def print_dict(data: dict, title: str | None = None) -> None:
    """Print a dict as a Rich panel with key-value pairs.

    None values are omitted from human output.
    """
    lines = []
    for k, v in data.items():
        if v is None:
            continue
        if isinstance(v, dict):
            v = json_lib.dumps(
                {k2: v2 for k2, v2 in v.items() if v2 is not None},
                indent=2,
                default=str,
            )
        elif isinstance(v, list):
            v = json_lib.dumps(v, indent=2, default=str)
        lines.append(f"[bold]{k}:[/bold] {v}")
    content = "\n".join(lines)
    if title:
        console.print(Panel(content, title=title))
    else:
        console.print(content)


def print_table(
    rows: list[list[str]],
    columns: list[str],
    title: str | None = None,
) -> None:
    """Print a Rich table from raw rows."""
    table = Table(title=title, show_header=True)
    for col in columns:
        table.add_column(col)
    for row in rows:
        table.add_row(*[str(c) for c in row])
    console.print(table)


def print_table_from_dicts(
    data: list[dict],
    title: str | None = None,
    columns: list[str] | None = None,
) -> None:
    """Print a Rich table from a list of dicts."""
    if not data:
        console.print("[dim]No results.[/dim]")
        return
    cols = columns or list(data[0].keys())
    table = Table(title=title, show_header=True)
    for col in cols:
        table.add_column(col)
    for row in data:
        table.add_row(*[str(row.get(c, "")) for c in cols])
    console.print(table)


def print_streaming_text(text: str) -> None:
    """Print streaming text chunk without newline."""
    sys.stdout.write(text)
    sys.stdout.flush()
