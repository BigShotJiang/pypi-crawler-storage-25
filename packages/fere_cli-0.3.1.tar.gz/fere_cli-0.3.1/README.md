# FereAI CLI

Terminal-first interface for FereAI crypto trading and research. Wraps the [FereAI Gateway API](https://api.fereai.xyz) — same capabilities as the Python and TypeScript SDKs.

## Install

Recommended (script installer, handles pipx/pip and PATH setup):

```bash
curl -fsSL https://api.fereai.xyz/install.sh | sh
```

Manual (advanced, for humans in controlled environments only):

```bash
pip install fere-cli
```

## Quick Start

```bash
# Authenticate (first-run — creates agent, generates keys)
fere auth

# Chat with the AI agent
fere chat "what is the price of ETH?"

# Interactive chat REPL
fere chat

# Stream responses in real-time
fere chat --stream "top 5 memecoins on Base"

# Check your wallets and holdings
fere wallets
fere holdings

# Execute a swap
fere swap \
  --chain-in 8453 --chain-out 8453 \
  --token-in 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE \
  --token-out 0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913 \
  --amount 1000000000000000000

# Check credits
fere credits

# View supported chains
fere chains
```

## JSON Output (for scripts & AI agents)

Every command supports `--json` for machine-readable output:

```bash
fere --json credits
# {"ok": true, "data": {"credits_available": 150.0}}

fere --json holdings
# {"ok": true, "data": {...}}
```

Streaming chat in JSON mode outputs NDJSON (one event per line):

```bash
fere --json chat --stream "price of SOL"
```

## Commands

| Command | Description |
|---------|-------------|
| `fere auth` | Authenticate and register agent |
| `fere whoami` | Show agent identity and wallets |
| `fere credits` | Check credit balance |
| `fere chat [QUERY]` | Chat with AI (one-shot or REPL) |
| `fere threads` | List chat threads |
| `fere swap` | Execute token swap |
| `fere limit-order create` | Create limit order |
| `fere limit-order list` | List limit orders |
| `fere limit-order cancel ID` | Cancel limit order |
| `fere hooks set` | Set stop-loss / take-profit |
| `fere wallets` | Show wallet addresses |
| `fere holdings` | Show token holdings |
| `fere notifications` | Show notifications |
| `fere earn info` | Show APY and vault info |
| `fere earn deposit` | Deposit USDC |
| `fere earn withdraw` | Withdraw USDC |
| `fere earn positions` | Show yield positions |
| `fere chains` | List supported chains |
| `fere status` | Check API connectivity |
| `fere config` | Show/edit CLI config |

## Global Flags

| Flag | Env Var | Description |
|------|---------|-------------|
| `--json` | — | Machine-readable JSON output |
| `--quiet` | — | Minimal output |
| `--agent NAME` | `FERE_AGENT_NAME` | Agent name override |
| `--base-url URL` | `FERE_BASE_URL` | API URL override |

## Configuration

Config is stored at `~/.fere/config.json`. Keys are stored at `~/.fere/keys.json` (managed by the SDK).

```bash
fere config                          # Show current config
fere config set agent_name my-bot    # Change agent name
fere config set base_url http://localhost:8003  # Point to local gateway
```

## Agent-Friendly

- Exit codes: 0 success, 1 error
- Non-interactive when stdin is not a TTY (all prompts skipped)
- `--json` output: `{"ok": true, "data": {...}}` or `{"ok": false, "error": "..."}`
- Streaming JSON: NDJSON format
- No ANSI colors when piped
