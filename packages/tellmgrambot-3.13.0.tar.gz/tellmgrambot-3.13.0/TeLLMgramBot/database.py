"""
SQLite-backed conversation storage for TeLLMgramBot.

Provides async helpers for persisting and loading messages, managing per-user private mode,
searching message history, and retrieving conversation context. The schema includes a messages
table (indexed by chat_id and user_id, with is_private flag), a users table (profile data
and private_mode flag), and a chats table for speaker/chat resolution in search results.
"""
import json
import os
from typing import Optional

import aiosqlite
from .utils import execution_dir, now_iso

# Allows tests to override the DB path without touching env vars
_DB_PATH: Optional[str] = None

# Per-bot DB filename (e.g. 'MyBot_conversations.db'). Set via set_db_filename() during
# init_structure() after config is loaded. Falls back to 'conversations.db' if unset.
_DB_FILENAME: Optional[str] = None

# Maximum bound parameters per SQLite statement (SQLite default limit is 999).
# Defined at module level so tests can patch it to force batching with small inputs.
_SQLITE_MAX_PARAMS = 999

_DDL = """
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS messages (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_message_id  INTEGER,
    chat_id        INTEGER NOT NULL,
    user_id        INTEGER NOT NULL,
    role           TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
    content        TEXT NOT NULL,
    is_private     INTEGER NOT NULL DEFAULT 0,
    reply_to_id    INTEGER,
    created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_messages_chat_id ON messages(chat_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_user_id ON messages(user_id, created_at);

CREATE TABLE IF NOT EXISTS users (
    user_id        INTEGER PRIMARY KEY,
    username       TEXT,
    first_name     TEXT,
    last_name      TEXT,
    private_mode   INTEGER NOT NULL DEFAULT 0,
    previous_names TEXT,
    updated_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS chats (
    chat_id         INTEGER PRIMARY KEY,
    chat_type       TEXT,
    chat_title      TEXT,
    previous_titles TEXT,
    updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS summary_archive (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id      INTEGER NOT NULL,
    user_id      INTEGER,
    participants TEXT,
    tier         INTEGER NOT NULL DEFAULT 1,
    content      TEXT NOT NULL,
    covers_from  TEXT NOT NULL,
    covers_to    TEXT NOT NULL,
    archived_at  TEXT,
    created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_summary_archive_chat ON summary_archive(chat_id, covers_from);
CREATE INDEX IF NOT EXISTS idx_summary_archive_user ON summary_archive(user_id, covers_from);
CREATE INDEX IF NOT EXISTS idx_summary_archive_chat_to ON summary_archive(chat_id, archived_at, covers_to);
CREATE INDEX IF NOT EXISTS idx_summary_archive_user_to ON summary_archive(user_id, archived_at, covers_to);
"""


def set_db_filename(filename: str) -> None:
    """
    Set the DB filename used by get_db_path(). Appends '.db' if absent.

    Args:
        filename: Plain basename (e.g. 'MyBot.db'). Path separators are rejected.

    Raises:
        ValueError: If filename contains path components or is absolute.
    """
    if os.path.isabs(filename) or os.path.basename(filename) != filename:
        raise ValueError(f"DB filename must be a plain basename, not a path: {filename!r}")
    global _DB_FILENAME
    _DB_FILENAME = filename if filename.endswith('.db') else f"{filename}.db"


def get_db_path() -> str:
    """
    Return the SQLite DB file path.

    TELLMGRAMBOT_DATA_PATH env var sets the directory; falls back to data/ next to the package.
    _DB_PATH overrides everything (used by tests).
    """
    if _DB_PATH:
        return _DB_PATH
    data_dir = os.environ.get('TELLMGRAMBOT_DATA_PATH', os.path.join(execution_dir(), 'data'))
    filename = _DB_FILENAME or 'conversations.db'
    return os.path.join(data_dir, filename)


async def init_db() -> None:
    """
    Create all tables if they do not exist. Safe to call repeatedly (IF NOT EXISTS / WAL).

    Migrations applied to existing databases:
      messages         - adds reply_to_id, tg_message_id, archived_at; drops username, is_foreign_bot.
      chats            - adds chat_type, previous_titles.
      users            - adds private_mode, previous_names; merges and drops legacy private_mode table.
      summary_archive  - created (tier 1 and 2 conversation summaries).
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.executescript(_DDL)
        existing = {row[1] async for row in await db.execute("PRAGMA table_info(messages)")}
        # Migration: add reply_to_id to existing databases that predate this column.
        if 'reply_to_id' not in existing:
            await db.execute("ALTER TABLE messages ADD COLUMN reply_to_id INTEGER")
        # Migration: add tg_message_id to existing databases that predate this column.
        if 'tg_message_id' not in existing:
            await db.execute("ALTER TABLE messages ADD COLUMN tg_message_id INTEGER")
        # Index on tg_message_id is created here (not in DDL) because the column may not
        # exist in the initial executescript pass on legacy databases.
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_messages_tg_message_id ON messages(chat_id, tg_message_id)"
        )
        # Migration: drop is_foreign_bot column. Delete legacy rows first (referential
        # dependency), then drop. Foreign bot capture was removed in v3.10.2.
        if 'is_foreign_bot' in existing:
            await db.execute("DELETE FROM messages WHERE is_foreign_bot = 1")
            await db.execute("ALTER TABLE messages DROP COLUMN is_foreign_bot")
        # Migration: drop username column now stored in the normalized users table.
        if 'username' in existing:
            await db.execute("ALTER TABLE messages DROP COLUMN username")
        # Migration: add archived_at column to support conversation archive skip flag.
        if 'archived_at' not in existing:
            await db.execute("ALTER TABLE messages ADD COLUMN archived_at TEXT")
        # Migration: add chat_type and previous_titles to chats table if absent.
        chats_cols = {row[1] async for row in await db.execute("PRAGMA table_info(chats)")}
        if 'chat_type' not in chats_cols:
            await db.execute("ALTER TABLE chats ADD COLUMN chat_type TEXT")
        if 'previous_titles' not in chats_cols:
            await db.execute("ALTER TABLE chats ADD COLUMN previous_titles TEXT")
        # Migration: merge private_mode table into users.private_mode and drop the old table.
        # Also add previous_names column for name history tracking.
        users_cols = {row[1] async for row in await db.execute("PRAGMA table_info(users)")}
        if 'private_mode' not in users_cols:
            await db.execute("ALTER TABLE users ADD COLUMN private_mode INTEGER NOT NULL DEFAULT 0")
        if 'previous_names' not in users_cols:
            await db.execute("ALTER TABLE users ADD COLUMN previous_names TEXT")
        tables = {row[0] async for row in await db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'private_mode' in tables:
            await db.execute(
                "INSERT OR IGNORE INTO users (user_id, private_mode) "
                "SELECT user_id, enabled FROM private_mode"
            )
            await db.execute(
                "UPDATE users SET private_mode = 1 "
                "WHERE user_id IN (SELECT user_id FROM private_mode WHERE enabled = 1)"
            )
            await db.execute("DROP TABLE private_mode")
        await db.commit()


async def insert_message(
    chat_id: int,
    user_id: int,
    role: str,
    content: str,
    is_private: bool = False,
    reply_to_id: Optional[int] = None,
    tg_message_id: Optional[int] = None,
) -> int:
    """
    Persist a single message row and return its database id.

    Args:
        chat_id: Telegram chat ID (negative for groups, positive for private).
        user_id: Telegram user ID of the sender.
        role: 'user', 'assistant', or 'system'.
        content: Message text.
        is_private: If True, excluded from all context loading.
        reply_to_id: DB id of the replied-to message, or None.
        tg_message_id: Telegram message ID; enables cross-session reply-to dedup.

    Returns:
        Inserted row id.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        cursor = await db.execute(
            "INSERT INTO messages "
            "(chat_id, user_id, role, content, is_private, reply_to_id, tg_message_id) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (chat_id, user_id, role, content, int(is_private), reply_to_id, tg_message_id),
        )
        await db.commit()
        return cursor.lastrowid


async def update_message_tg_id(db_id: int, tg_message_id: int) -> None:
    """
    Store the Telegram message ID on an assistant row after send.

    Enables cross-session reply-to dedup: future sessions can find the bot's message
    by tg_message_id even if it falls outside the loaded token window.

    Args:
        db_id: DB primary key of the assistant message row.
        tg_message_id: Telegram message ID returned by the send call.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "UPDATE messages SET tg_message_id = ? WHERE id = ?",
            (tg_message_id, db_id),
        )
        await db.commit()


async def load_messages_for_chat(
    chat_id: int,
    exclude_private: bool = False,
) -> list[dict]:
    """
    Load all messages for a chat in chronological order.

    Args:
        chat_id: Telegram chat ID to query.
        exclude_private: If True, is_private=1 rows are excluded.

    Returns:
        List of {"role", "content"} dicts.
    """
    query = "SELECT role, content FROM messages WHERE chat_id = ?"
    params: tuple = (chat_id,)
    if exclude_private:
        query += " AND is_private = 0"
    query += " ORDER BY created_at ASC, id ASC"
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
    return [{"role": row[0], "content": row[1]} for row in rows]


async def load_messages_for_user(
    user_id: int,
    exclude_private: bool = False,
) -> list[dict]:
    """
    Load all messages from a user's private chat (chat_id == user_id) in chronological order.

    Args:
        user_id: Telegram user ID; doubles as the private chat_id.
        exclude_private: If True, is_private=1 rows are excluded.

    Returns:
        List of {"role", "content"} dicts.
    """
    query = "SELECT role, content FROM messages WHERE chat_id = ?"
    params: tuple = (user_id,)
    if exclude_private:
        query += " AND is_private = 0"
    query += " ORDER BY created_at ASC, id ASC"
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
    return [{"role": row[0], "content": row[1]} for row in rows]


def _build_speaker_prefix(
    role: str,
    chat_id: int,
    current_chat_id: int,
    first_name: Optional[str],
    last_name: Optional[str],
    username: Optional[str],
    chat_title: Optional[str],
    created_at: Optional[str] = None,
) -> str:
    """
    Build a speaker attribution prefix for a context message.

    Returns '' for assistant/system messages or when no identity is resolvable.
    Same-chat produces "[Name, YYYY-MM-DD HH:MM UTC]: ";
    cross-chat produces "[Name (ChatTitle), YYYY-MM-DD HH:MM UTC]: ".

    Args:
        role: Message role ('user', 'assistant', 'system').
        chat_id: Chat ID where the message originated.
        current_chat_id: Chat ID of the current conversation; pass 0 to force cross-chat
                         prefix on all rows (sentinel used by load_shared_group_context).
        first_name: User's first name, may be None.
        last_name: User's last name, may be None.
        username: Telegram @handle without @, may be None.
        chat_title: Group/channel display name, or None for private chats.
        created_at: ISO timestamp; date portion included in prefix if present.

    Returns:
        Speaker prefix string, or '' for assistant/system/unknown-identity messages.
    """
    if role != 'user':
        return ''
    name_parts = [p for p in [first_name, last_name] if p]
    name = ' '.join(name_parts) if name_parts else username
    if not name:
        return ''
    date = (created_at[:16].replace('T', ' ') + ' UTC') if created_at else None
    if chat_id != current_chat_id:
        if chat_title:
            label = chat_title
        elif chat_id > 0:
            label = 'private chat'
        else:
            label = f'group {chat_id}'
        suffix = f', {date}' if date else ''
        return f'[{name} ({label}){suffix}]: '
    suffix = f', {date}' if date else ''
    return f'[{name}{suffix}]: '


async def load_full_user_context(
    user_id: int,
    current_chat_id: int,
    exclude_private: bool = False,
) -> list[dict]:
    """
    Load bidirectional context for a user across all chats, merged chronologically.

    Three-arm query:
      Arm 1 - all messages in current chat (all participants).
      Arm 2 - full private chat history when current chat is a group (both sides,
               to preserve role alternation).
      Arm 3 - user's own rows from other groups (not bot replies).
    Archive rows follow the same three-arm pattern and are interleaved.

    User messages receive a speaker prefix (assistant messages do not) built by _build_speaker_prefix:
      "[Name, YYYY-MM-DD HH:MM UTC]: " for same-chat messages.
      "[Name (ChatTitle), YYYY-MM-DD HH:MM UTC]: " for cross-chat.

    The exclude_private flag is controlled by the caller and applies regardless of chat type.
    Conversation.get_past_interaction always passes exclude_private=True so that is_private=1
    rows are never rehydrated into any session context.

    Args:
        user_id: Telegram user ID of the requesting user.
        current_chat_id: Chat ID of the current conversation.
        exclude_private: If True, is_private=1 rows are excluded from all arms.

    Returns:
        List of {"role", "content", "_tg_id"} dicts, oldest first.
    """
    raw_query = (
        "SELECT m.role, m.content, m.user_id, m.chat_id, "
        "u.first_name, u.last_name, u.username, c.chat_title, m.created_at, m.tg_message_id "
        "FROM messages m "
        "LEFT JOIN users u ON m.user_id = u.user_id "
        "LEFT JOIN chats c ON m.chat_id = c.chat_id "
        "WHERE (m.chat_id = ? "
        "OR (m.chat_id = ? AND m.chat_id != ?) "
        "OR (m.user_id = ? AND m.chat_id != ? AND m.chat_id != ?)) "
        "AND m.archived_at IS NULL"
    )
    raw_params: tuple = (current_chat_id, user_id, current_chat_id, user_id, current_chat_id, user_id)
    if exclude_private:
        raw_query += " AND m.is_private = 0"
    raw_query += " ORDER BY m.created_at ASC, m.id ASC"

    # Archive rows use the same three-arm access pattern.
    # Arm 3 matches via user_id (single-user rows) or participants containing user_id.
    archive_query = (
        "SELECT sa.tier, sa.content, sa.covers_from, sa.covers_to, sa.chat_id, c.chat_title "
        "FROM summary_archive sa "
        "LEFT JOIN chats c ON sa.chat_id = c.chat_id "
        "WHERE (sa.chat_id = ? "
        "OR (sa.chat_id = ? AND sa.chat_id != ?) "
        "OR ((sa.user_id = ? OR (sa.participants IS NOT NULL AND json_valid(sa.participants) "
        "AND EXISTS (SELECT 1 FROM json_each(sa.participants) WHERE json_each.value = ?))) "
        "AND sa.chat_id != ? AND sa.chat_id != ?)) "
        "AND sa.archived_at IS NULL "
        "ORDER BY sa.covers_from ASC, sa.id ASC"
    )
    archive_params: tuple = (
        current_chat_id, user_id, current_chat_id,
        user_id, user_id, current_chat_id, user_id,
    )

    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(raw_query, raw_params) as cursor:
            raw_rows = await cursor.fetchall()
        async with db.execute(archive_query, archive_params) as cursor:
            archive_rows = await cursor.fetchall()

    raw_msgs = [
        {
            "role": row[0],
            "content": _build_speaker_prefix(
                row[0], row[3], current_chat_id, row[4], row[5], row[6], row[7], row[8]
            ) + row[1],
            "_tg_id": row[9],
            "_sort_key": row[8],
        }
        for row in raw_rows
    ]

    archive_msgs = []
    for row in archive_rows:
        # row: (tier, content, covers_from, covers_to, chat_id, chat_title)
        tier, content, covers_from, covers_to, arc_chat_id, chat_title = row
        date_from = covers_from[:10]
        date_to = covers_to[:10]
        tier_label = f"Tier {tier} archive summary"
        if arc_chat_id == current_chat_id:
            label = f"[{tier_label} covering {date_from} to {date_to}]"
        else:
            title = chat_title or ("private chat" if arc_chat_id > 0 else f"group {arc_chat_id}")
            label = f"[{tier_label} from {title}, covering {date_from} to {date_to}]"
        archive_msgs.append({
            "role": "user",
            "content": f"{label}: {content}",
            "_tg_id": None,
            "_sort_key": covers_from,
        })

    merged = sorted(raw_msgs + archive_msgs, key=lambda m: m["_sort_key"])
    for m in merged:
        del m["_sort_key"]
    return merged


async def get_max_cross_chat_message_id(
    user_id: int,
    current_chat_id: int,
    exclude_private: bool = False,
) -> int:
    """
    Return MAX(id) across the three-arm cross-chat context for this user.

    Used to establish a cursor for mid-session refresh detection.

    Returns:
        Maximum message id, or 0 if no rows exist.
    """
    query = (
        "SELECT MAX(id) FROM messages "
        "WHERE (chat_id = ? "
        "OR (chat_id = ? AND chat_id != ?) "
        "OR (user_id = ? AND chat_id != ? AND chat_id != ?))"
    )
    params: tuple = (current_chat_id, user_id, current_chat_id, user_id, current_chat_id, user_id)
    if exclude_private:
        query += " AND is_private = 0"
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(query, params) as cursor:
            row = await cursor.fetchone()
    return row[0] if row and row[0] is not None else 0


async def load_new_cross_chat_context(
    user_id: int,
    current_chat_id: int,
    since_id: int,
    exclude_private: bool = False,
) -> list[dict]:
    """
    Load the delta of cross-chat context since a given cursor (same three-arm query
    as load_full_user_context, restricted to id > since_id). User message content is prefixed
    with "[Name, YYYY-MM-DD HH:MM UTC]: " or "[Name (ChatTitle), YYYY-MM-DD HH:MM UTC]: "
    when user identity is available.

    Args:
        user_id: Requesting user's Telegram ID.
        current_chat_id: Chat ID of the current conversation.
        since_id: Exclusive lower bound; only rows with id > since_id are returned.
        exclude_private: If True, is_private=1 rows are excluded.

    Returns:
        List of {"role", "content", "_tg_id"} dicts, oldest first.
    """
    query = (
        "SELECT m.role, m.content, m.user_id, m.chat_id, "
        "u.first_name, u.last_name, u.username, c.chat_title, m.created_at, m.tg_message_id "
        "FROM messages m "
        "LEFT JOIN users u ON m.user_id = u.user_id "
        "LEFT JOIN chats c ON m.chat_id = c.chat_id "
        "WHERE (m.chat_id = ? "
        "OR (m.chat_id = ? AND m.chat_id != ?) "
        "OR (m.user_id = ? AND m.chat_id != ? AND m.chat_id != ?)) "
        "AND m.id > ? AND m.archived_at IS NULL"
    )
    params: tuple = (current_chat_id, user_id, current_chat_id, user_id, current_chat_id, user_id, since_id)
    if exclude_private:
        query += " AND m.is_private = 0"
    query += " ORDER BY m.created_at ASC, m.id ASC"
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
    return [
        {
            "role": row[0],
            "content": _build_speaker_prefix(
                row[0], row[3], current_chat_id, row[4], row[5], row[6], row[7], row[8]
            ) + row[1],
            "_tg_id": row[9],
        }
        for row in rows
    ]


async def get_shared_group_chat_ids(user_id: int, bot_id: int) -> list[int]:
    """
    Return chat_ids of groups where both the user and the bot have sent messages.

    Requiring bot presence prevents surfacing history from groups the bot was removed
    from or never properly joined.

    Args:
        user_id: Requesting user's Telegram ID.
        bot_id: Bot's Telegram user ID.

    Returns:
        List of negative chat_ids (group IDs).
    """
    query = """
        SELECT DISTINCT chat_id
        FROM messages
        WHERE user_id = ? AND chat_id < 0
        AND EXISTS (
            SELECT 1 FROM messages m2
            WHERE m2.chat_id = messages.chat_id AND m2.user_id = ?
        )
    """
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(query, (user_id, bot_id)) as cursor:
            rows = await cursor.fetchall()
    return [row[0] for row in rows]


async def load_shared_group_context(
    group_chat_ids: list[int],
    exclude_private: bool = True,
) -> list[dict]:
    """
    Load all messages from multiple group chats, merged chronologically.

    Used to fill remaining token budget in a private chat with shared-group context.
    Batches queries to stay within SQLite's 999-parameter limit. All rows are treated
    as cross-chat so every user message gets a "[Name (ChatTitle), date]: " prefix.

    Args:
        group_chat_ids: List of negative group chat_ids to include.
        exclude_private: If True, is_private=1 rows are excluded.

    Returns:
        List of {"role", "content", "_tg_id"} dicts, oldest first. Empty if group_chat_ids is empty.
    """
    if not group_chat_ids:
        return []
    # SQLite has a max of 999 bound parameters per statement. Batch group_chat_ids to
    # avoid exceeding this limit for users who share many groups with the bot.
    all_rows: list[tuple] = []
    async with aiosqlite.connect(get_db_path()) as db:
        for i in range(0, len(group_chat_ids), _SQLITE_MAX_PARAMS):
            chunk = group_chat_ids[i:i + _SQLITE_MAX_PARAMS]
            placeholders = ','.join('?' * len(chunk))
            query = (
                f"SELECT m.role, m.content, m.created_at, m.id, "
                f"m.chat_id, u.first_name, u.last_name, u.username, c.chat_title, m.tg_message_id "
                f"FROM messages m "
                f"LEFT JOIN users u ON m.user_id = u.user_id "
                f"LEFT JOIN chats c ON m.chat_id = c.chat_id "
                f"WHERE m.chat_id IN ({placeholders}) AND m.archived_at IS NULL"
            )
            if exclude_private:
                query += " AND m.is_private = 0"
            async with db.execute(query, tuple(chunk)) as cursor:
                all_rows.extend(await cursor.fetchall())
    all_rows.sort(key=lambda r: (r[2], r[3]))
    # current_chat_id=0 is a sentinel (never a real Telegram ID) so all rows are treated
    # as cross-chat, ensuring every user message receives a "[Name (ChatTitle), date]: " prefix.
    return [
        {
            "role": row[0],
            "content": _build_speaker_prefix(
                row[0], row[4], 0, row[5], row[6], row[7], row[8], row[2]
            ) + row[1],
            "_tg_id": row[9],
        }
        for row in all_rows
    ]


async def upsert_user(
    user_id: int,
    username: Optional[str],
    first_name: Optional[str],
    last_name: Optional[str],
) -> None:
    """
    Insert or update a user record. Called on every interaction to capture name changes.

    When the display name changes, the old name is appended to previous_names (JSON array,
    deduplicated) so search can resolve users by historical identities.

    Args:
        user_id: Telegram user ID.
        username: @handle without @, may be None.
        first_name: Telegram first name, may be None.
        last_name: Telegram last name, may be None.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(
            "SELECT first_name, last_name, previous_names FROM users WHERE user_id = ?",
            (user_id,),
        ) as cur:
            existing = await cur.fetchone()

        updated_prev = None
        if existing is not None:
            old_first, old_last, prev = existing
            old_display = f"{old_first or ''} {old_last or ''}".strip()
            new_display = f"{first_name or ''} {last_name or ''}".strip()
            if old_display and old_display != new_display:
                if prev:
                    try:
                        seen = json.loads(prev)
                        if not isinstance(seen, list):
                            seen = [seen] if seen else []
                    except json.JSONDecodeError:
                        seen = [n.strip() for n in prev.split(",") if n.strip()]
                else:
                    seen = []
                if old_display not in seen:
                    seen.append(old_display)
                updated_prev = json.dumps(seen)
            else:
                updated_prev = prev

        await db.execute(
            "INSERT INTO users (user_id, username, first_name, last_name, previous_names) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET "
            "username = excluded.username, first_name = excluded.first_name, "
            "last_name = excluded.last_name, previous_names = excluded.previous_names, "
            "updated_at = ?",
            (user_id, username, first_name, last_name, updated_prev, now_iso()),
        )
        await db.commit()


async def upsert_chat(
    chat_id: int,
    chat_type: str,
    chat_title: Optional[str],
) -> None:
    """
    Insert or update a chat record. Called on every interaction to capture title changes.

    When the title changes, the old title is appended to previous_titles (JSON array,
    deduplicated) so search can resolve chats by historical names.

    Args:
        chat_id: Telegram chat ID.
        chat_type: 'private', 'group', 'supergroup', or 'channel'.
        chat_title: Group/channel display name, or None for private chats.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(
            "SELECT chat_title, previous_titles FROM chats WHERE chat_id = ?",
            (chat_id,),
        ) as cur:
            existing = await cur.fetchone()

        updated_prev = None
        if existing is not None:
            old_title, prev = existing
            if old_title and old_title != chat_title:
                if prev:
                    try:
                        seen = json.loads(prev)
                        if not isinstance(seen, list):
                            seen = [seen] if seen else []
                    except json.JSONDecodeError:
                        seen = [t.strip() for t in prev.split(",") if t.strip()]
                else:
                    seen = []
                if old_title not in seen:
                    seen.append(old_title)
                updated_prev = json.dumps(seen)
            else:
                updated_prev = prev

        await db.execute(
            "INSERT INTO chats (chat_id, chat_type, chat_title, previous_titles) VALUES (?, ?, ?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET "
            "chat_type = excluded.chat_type, chat_title = excluded.chat_title, "
            "previous_titles = excluded.previous_titles, "
            "updated_at = ?",
            (chat_id, chat_type, chat_title, updated_prev, now_iso()),
        )
        await db.commit()


async def get_chat_type(chat_id: int) -> Optional[str]:
    """
    Return the chat_type for a chat_id, or None if not yet upserted.

    Returns:
        'private', 'group', 'supergroup', 'channel', or None.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(
            "SELECT chat_type FROM chats WHERE chat_id = ?", (chat_id,)
        ) as cursor:
            row = await cursor.fetchone()
    return row[0] if row else None


async def search_messages(
    accessible_chat_ids: list[int],
    content_query: Optional[str] = None,
    speaker_query: Optional[str] = None,
    chat_query: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    limit: int = 30,
    ascending: bool = False,
) -> list[dict] | dict:
    """
    Search message history across accessible chats with optional filters, querying both
    raw messages and summary_archive. All filters are optional AND-combined.

    Speaker and chat resolution uses exact-match-first, then LIKE (including previous_names /
    previous_titles). Leading '@' is stripped from speaker_query. Zero global chat matches
    fall back to all accessible chats; zero global speaker matches return empty.
    Multiple matches for either return an ambiguity sentinel instead of results.

    Args:
        accessible_chat_ids: Chat IDs the caller may search (enforces access control).
        content_query: LIKE match against message content.
        speaker_query: Name or @handle resolved to user_ids; exact match first, then LIKE.
        chat_query: Chat title resolved to chat_ids; exact match first, then LIKE.
        date_from: Inclusive range start as YYYY-MM-DDTHH:MM.
        date_to: Inclusive range end as YYYY-MM-DDTHH:MM.
        limit: Max results returned (default 30).
        ascending: If True, oldest-first order (default: most-recent-first).

    Returns:
        Normal: list of {"speaker", "chat", "chat_id", "content", "timestamp", "source"} dicts,
                sorted by (timestamp DESC, tier ASC) when ascending=False, or by
                (timestamp ASC, tier ASC) when ascending=True; raw=tier 0, Tier 1=1, Tier 2=2.
        Ambiguous: {"_ambiguous": True, "chat_matches": [...], "speaker_matches": [...], "message": str}.
    """
    if not accessible_chat_ids:
        return []

    accessible_set = set(accessible_chat_ids)

    async with aiosqlite.connect(get_db_path()) as db:
        # Resolve speaker_query -> user_ids (exact match first, then LIKE)
        # Scoped to users who have at least one message in accessible_chat_ids (s3kp).
        # Batched over accessible_chat_ids to stay within SQLite's 999-parameter limit;
        # each batch leaves 5 slots for name-matching params (exact: 3, partial: 5).
        speaker_ids: Optional[list[int]] = None
        speaker_amb: Optional[dict] = None
        if speaker_query:
            q = speaker_query.lstrip('@')
            exact_seen: dict[int, tuple] = {}
            for i in range(0, len(accessible_chat_ids), _SQLITE_MAX_PARAMS - 3):
                chunk = accessible_chat_ids[i:i + _SQLITE_MAX_PARAMS - 3]
                chunk_ph = ','.join('?' * len(chunk))
                async with db.execute(
                    f"SELECT DISTINCT u.user_id, "
                    f"COALESCE(u.first_name || ' ' || u.last_name, u.first_name, u.username, 'Unknown') AS label, "
                    f"u.username "
                    f"FROM users u JOIN messages m ON m.user_id = u.user_id "
                    f"WHERE m.chat_id IN ({chunk_ph}) "
                    f"AND (LOWER(u.username) = LOWER(?) "
                    f"OR LOWER(u.first_name) = LOWER(?) "
                    f"OR LOWER(u.first_name || ' ' || u.last_name) = LOWER(?))",
                    (*chunk, q, q, q),
                ) as cur:
                    for row in await cur.fetchall():
                        exact_seen.setdefault(row[0], row)
            exact_rows = list(exact_seen.values())
            if len(exact_rows) == 1:
                speaker_ids = [exact_rows[0][0]]
            elif len(exact_rows) > 1:
                speaker_amb = {'rows': exact_rows}
            else:
                like = f"%{q}%"
                partial_seen: dict[int, tuple] = {}
                for i in range(0, len(accessible_chat_ids), _SQLITE_MAX_PARAMS - 5):
                    chunk = accessible_chat_ids[i:i + _SQLITE_MAX_PARAMS - 5]
                    chunk_ph = ','.join('?' * len(chunk))
                    async with db.execute(
                        f"SELECT DISTINCT u.user_id, "
                        f"COALESCE(u.first_name || ' ' || u.last_name, u.first_name, u.username, 'Unknown') AS label, "
                        f"u.username "
                        f"FROM users u JOIN messages m ON m.user_id = u.user_id "
                        f"WHERE m.chat_id IN ({chunk_ph}) "
                        f"AND (u.username LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? "
                        f"OR (u.first_name || ' ' || u.last_name) LIKE ? OR u.previous_names LIKE ?)",
                        (*chunk, like, like, like, like, like),
                    ) as cur:
                        for row in await cur.fetchall():
                            partial_seen.setdefault(row[0], row)
                partial_rows = list(partial_seen.values())
                if len(partial_rows) == 0:
                    return []
                elif len(partial_rows) == 1:
                    speaker_ids = [partial_rows[0][0]]
                else:
                    speaker_amb = {'rows': partial_rows}

        # Resolve chat_query -> chat_ids (exact match first, then LIKE)
        resolved_chat_ids: Optional[list[int]] = None
        chat_amb: Optional[dict] = None
        if chat_query:
            async with db.execute(
                "SELECT chat_id, chat_title FROM chats WHERE LOWER(chat_title) = LOWER(?)",
                (chat_query,),
            ) as cur:
                exact_rows = await cur.fetchall()
            exact_accessible = [r for r in exact_rows if r[0] in accessible_set]
            if len(exact_accessible) == 1:
                resolved_chat_ids = [exact_accessible[0][0]]
            elif len(exact_accessible) > 1:
                chat_amb = {'rows': exact_accessible}
            elif exact_rows and not exact_accessible:
                # Exact global match found but not accessible - access control
                return []
            else:
                # No exact match - partial LIKE
                like = f"%{chat_query}%"
                # Check for any global match first to distinguish colloquial fallback
                # (zero global matches) from access-control rejection (global match, not accessible).
                async with db.execute(
                    "SELECT 1 FROM chats WHERE chat_title LIKE ? OR previous_titles LIKE ? LIMIT 1",
                    (like, like),
                ) as cur:
                    has_global = await cur.fetchone() is not None
                if not has_global:
                    pass  # Zero global matches: colloquial fallback (resolved_chat_ids stays None)
                else:
                    # Batch accessible_chat_ids to stay within SQLite's 999-parameter limit;
                    # reserve 2 slots for the LIKE parameters (chat_title + previous_titles).
                    partial_accessible_seen: dict[int, tuple] = {}
                    for i in range(0, len(accessible_chat_ids), _SQLITE_MAX_PARAMS - 2):
                        chunk = accessible_chat_ids[i:i + _SQLITE_MAX_PARAMS - 2]
                        chunk_ph = ','.join('?' * len(chunk))
                        async with db.execute(
                            f"SELECT chat_id, chat_title FROM chats "
                            f"WHERE (chat_title LIKE ? OR previous_titles LIKE ?) AND chat_id IN ({chunk_ph})",
                            (like, like, *chunk),
                        ) as cur:
                            for row in await cur.fetchall():
                                partial_accessible_seen.setdefault(row[0], row)
                    partial_accessible = list(partial_accessible_seen.values())
                    if not partial_accessible:
                        # Found globally but none accessible - access control
                        return []
                    elif len(partial_accessible) == 1:
                        resolved_chat_ids = [partial_accessible[0][0]]
                    else:
                        chat_amb = {'rows': partial_accessible}

        # Return ambiguity sentinel if either query matched multiple entities
        if speaker_amb or chat_amb:
            sentinel: dict = {'_ambiguous': True}
            msgs = []
            if chat_amb:
                sentinel['chat_matches'] = [
                    {'title': r[1], 'chat_id': r[0]} for r in chat_amb['rows']
                ]
                msgs.append(f"Multiple chats match '{chat_query}'. Please be more specific.")
            if speaker_amb:
                sentinel['speaker_matches'] = [
                    {'label': r[1], 'username': r[2]} for r in speaker_amb['rows']
                ]
                msgs.append(f"Multiple users match '{speaker_query}'. Please be more specific.")
            sentinel['message'] = ' '.join(msgs)
            return sentinel

        search_chat_ids = resolved_chat_ids if resolved_chat_ids is not None else accessible_chat_ids

        # --- Raw message query ---
        chat_placeholders = ','.join('?' * len(search_chat_ids))
        raw_conditions = [f"m.chat_id IN ({chat_placeholders})", "m.is_private = 0"]
        raw_params: list = list(search_chat_ids)

        if content_query:
            raw_conditions.append("m.content LIKE ?")
            raw_params.append(f"%{content_query}%")
        if speaker_ids:
            id_placeholders = ','.join('?' * len(speaker_ids))
            raw_conditions.append(f"m.user_id IN ({id_placeholders})")
            raw_params.extend(speaker_ids)
        if date_from:
            raw_conditions.append("m.created_at >= ?")
            raw_params.append(date_from + ":00.000Z")
        if date_to:
            raw_conditions.append("m.created_at <= ?")
            raw_params.append(date_to + ":59Z")

        raw_where = " AND ".join(raw_conditions)
        raw_order = "ASC" if ascending else "DESC"
        raw_query = f"""
            SELECT u.first_name, u.last_name, u.username,
                   c.chat_title, m.chat_id, m.content, m.created_at
            FROM messages m
            LEFT JOIN users u ON u.user_id = m.user_id
            LEFT JOIN chats c ON c.chat_id = m.chat_id
            WHERE {raw_where}
            ORDER BY m.created_at {raw_order}, m.id {raw_order}
            LIMIT ?
        """
        raw_params.append(limit)

        # --- Archive query ---
        arc_placeholders = ','.join('?' * len(search_chat_ids))
        arc_conditions = [f"sa.chat_id IN ({arc_placeholders})", "sa.archived_at IS NULL"]
        arc_params: list = list(search_chat_ids)

        if content_query:
            arc_conditions.append("sa.content LIKE ?")
            arc_params.append(f"%{content_query}%")
        if date_from:
            arc_conditions.append("sa.covers_to >= ?")
            arc_params.append(date_from + ":00.000Z")
        if date_to:
            arc_conditions.append("sa.covers_from <= ?")
            arc_params.append(date_to + ":59Z")

        arc_where = " AND ".join(arc_conditions)
        arc_ts_col = "sa.covers_from" if ascending else "sa.covers_to"
        arc_order = "ASC" if ascending else "DESC"
        arc_query = f"""
            SELECT sa.tier, sa.user_id, sa.participants,
                   c.chat_title, sa.chat_id, sa.content, sa.covers_from, sa.covers_to,
                   u.first_name, u.username
            FROM summary_archive sa
            LEFT JOIN chats c ON c.chat_id = sa.chat_id
            LEFT JOIN users u ON u.user_id = sa.user_id
            WHERE {arc_where}
            ORDER BY {arc_ts_col} {arc_order}, sa.id {arc_order}
            LIMIT ?
        """
        arc_params.append(limit * 3 if speaker_ids is not None else limit)

        async with db.execute(raw_query, raw_params) as cur:
            raw_rows = await cur.fetchall()
        async with db.execute(arc_query, arc_params) as cur:
            arc_rows = await cur.fetchall()

    # Build raw results with sort key (timestamp string, tier=0)
    all_results = []
    for first_name, last_name, username, chat_title, chat_id, content, created_at in raw_rows:
        if first_name and last_name:
            speaker_label = f"{first_name} {last_name}"
        elif first_name:
            speaker_label = first_name
        elif username:
            speaker_label = f"@{username}"
        else:
            speaker_label = "Unknown"
        if username and f"@{username}" not in speaker_label:
            speaker_label += f" (@{username})"
        all_results.append({
            "speaker": speaker_label,
            "chat": chat_title or "Private Chat",
            "chat_id": chat_id,
            "content": content,
            "timestamp": created_at,
            "source": "raw",
            "_sort_ts": created_at,
            "_tier": 0,
        })

    # Build archive results; apply speaker filter in Python (participants check)
    for tier, arc_user_id, participants_json, chat_title, chat_id, content, covers_from, covers_to, first_name, username in arc_rows:
        if speaker_ids is not None:
            # Check user_id match or participants membership
            matched = arc_user_id in speaker_ids
            if not matched and participants_json:
                try:
                    part_ids = json.loads(participants_json)
                    matched = any(uid in speaker_ids for uid in part_ids)
                except (json.JSONDecodeError, TypeError):
                    pass
            if not matched:
                continue

        if arc_user_id is None:
            speaker_label = "Multiple speakers"
        elif first_name:
            speaker_label = first_name + (f" (@{username})" if username else "")
        elif username:
            speaker_label = f"@{username}"
        else:
            speaker_label = "Archived speaker"

        arc_ts = covers_from if ascending else covers_to
        date_from_label = covers_from[:10]
        date_to_label = covers_to[:10]
        all_results.append({
            "speaker": speaker_label,
            "chat": chat_title or "Private Chat",
            "chat_id": chat_id,
            "content": f"[Covers {date_from_label} to {date_to_label}]: {content}",
            "timestamp": arc_ts,
            "source": f"archive (tier {tier})",
            "_sort_ts": arc_ts,
            "_tier": tier,
        })

    # Merge and sort: recency primary, tier tiebreaker (lower tier = more precise).
    # Two-pass stable sort: tier ascending first, then timestamp in desired direction.
    # Stable sort preserves tier order for equal timestamps.
    all_results.sort(key=lambda r: r["_tier"])
    all_results.sort(key=lambda r: r["_sort_ts"], reverse=not ascending)
    for r in all_results:
        del r["_sort_ts"]
        del r["_tier"]

    return all_results[:limit]


async def message_id_exists(chat_id: int, tg_message_id: int) -> bool:
    """
    Return True if a message with the given Telegram ID exists for the chat.

    DB-tier fallback for reply-to dedup: confirms a message is stored but outside
    the current token window when not found in _loaded_message_ids.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(
            "SELECT 1 FROM messages WHERE chat_id = ? AND tg_message_id = ? LIMIT 1",
            (chat_id, tg_message_id),
        ) as cursor:
            return await cursor.fetchone() is not None


async def delete_bot_replies_for_user(user_id: int) -> None:
    """
    Delete assistant rows whose reply_to_id references a message from this user.

    Must be called before delete_messages_for_user - the subquery depends on the
    user's rows still existing. Rows with reply_to_id = NULL are unaffected.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "DELETE FROM messages WHERE role = 'assistant' "
            "AND reply_to_id IN (SELECT id FROM messages WHERE user_id = ?)",
            (user_id,),
        )
        await db.commit()


async def delete_messages_for_user(user_id: int) -> None:
    """
    Delete all message rows for a given user_id across all chats.
    Used by /forget - call delete_bot_replies_for_user first to clean up linked bot replies.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute("DELETE FROM messages WHERE user_id = ?", (user_id,))
        await db.commit()


async def delete_messages_for_chat(chat_id: int) -> None:
    """
    Delete all message rows for a given chat_id, including all participants and bot replies.
    Used by /forget in private chats to fully clear the conversation.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute("DELETE FROM messages WHERE chat_id = ?", (chat_id,))
        await db.commit()


async def delete_private_messages_for_user(user_id: int) -> None:
    """
    Delete all is_private=1 rows for a user's private chat (chat_id == user_id).

    Covers both the user's own messages and bot replies in the same chat. Called on
    /private off so private-mode messages don't resurface on the next session load.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "DELETE FROM messages WHERE chat_id = ? AND is_private = 1",
            (user_id,)
        )
        await db.commit()


async def delete_archive_for_user(user_id: int) -> None:
    """
    Delete summary_archive rows attributed to a user.

    Removes single-user rows (user_id match) and multi-speaker rows where the user
    appears in participants - a merged summary cannot be surgically edited. Called
    by /forget before raw message deletion.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "DELETE FROM summary_archive WHERE user_id = ?",
            (user_id,),
        )
        await db.execute(
            "DELETE FROM summary_archive WHERE user_id IS NULL "
            "AND participants IS NOT NULL AND json_valid(participants) "
            "AND EXISTS ("
            "    SELECT 1 FROM json_each(summary_archive.participants) "
            "    WHERE json_each.value = ?"
            ")",
            (user_id,),
        )
        await db.commit()


async def delete_archive_for_chat(chat_id: int) -> None:
    """Delete all summary_archive rows for a chat. Used by /forget in private chats."""
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute("DELETE FROM summary_archive WHERE chat_id = ?", (chat_id,))
        await db.commit()


async def wipe_all_data() -> None:
    """
    Delete all rows from the messages, users, chats, and summary_archive tables.

    Irreversible. Used by the /wipe admin command to reset the bot's
    conversation database entirely. Schema and indexes are preserved.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute("DELETE FROM messages")
        await db.execute("DELETE FROM users")
        await db.execute("DELETE FROM chats")
        await db.execute("DELETE FROM summary_archive")
        await db.commit()


async def get_private_mode(user_id: int) -> bool:
    """Return True if private mode is enabled for this user; False if not or no row exists."""
    async with aiosqlite.connect(get_db_path()) as db:
        async with db.execute(
            "SELECT private_mode FROM users WHERE user_id = ?", (user_id,)
        ) as cursor:
            row = await cursor.fetchone()
    return bool(row[0]) if row else False


async def set_private_mode(user_id: int, enabled: bool) -> None:
    """
    Enable or disable private mode for a user.

    Uses upsert semantics to handle the rare case where no users row exists yet.
    """
    async with aiosqlite.connect(get_db_path()) as db:
        await db.execute(
            "INSERT INTO users (user_id, private_mode) VALUES (?, ?) "
            "ON CONFLICT(user_id) DO UPDATE SET private_mode = excluded.private_mode, "
            "updated_at = ?",
            (user_id, int(enabled), now_iso()),
        )
        await db.commit()
