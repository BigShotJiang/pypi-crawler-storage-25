"""
This module contains utility functions
that can be reused.
"""

import copy
import json
import locale
import os
import re
import ast
import pandas as pd
from dataclasses import fields
from datetime import datetime
from typing import Callable, List, Optional, Union
from uuid import UUID

from cdisc_rules_engine.enums.execution_status import ExecutionStatus
from cdisc_rules_engine.interfaces import ConditionInterface
from cdisc_rules_engine.models.base_validation_entity import BaseValidationEntity
from cdisc_rules_engine.check_operators.helpers import is_valid_date
from cdisc_rules_engine.constants.adam_products import ADAM_PRODUCTS


def convert_dataclass_to_superclass[T](instance: object, superclass: type[T]) -> T:
    """
    Convert a dataclass subclass instance to its superclass by copying all fields.

    Args:
        instance: The subclass instance to convert
        superclass: The target superclass type

    Returns:
        A new instance of the superclass with fields copied from the subclass instance
    """
    return superclass(
        **{field.name: getattr(instance, field.name) for field in fields(superclass)}
    )


def convert_file_size(size_in_bytes: int, desired_unit: str) -> float:
    """
    Converts file size from bytes to any of the following units:
    KB, MB, GB
    """
    unit_to_denominator_map: dict = {
        "KB": 1024,
        "MB": 1024**2,
        "GB": 1024**3,
    }
    return size_in_bytes / unit_to_denominator_map[desired_unit]


def get_execution_status(results):
    """
    If any result has an execution error, return execution error
    Else if any result has an issue reported, return issue reported
    Else if any result is successful, return issue successful
    Else, result should have all skips, return issue skipped
    """
    if len(results) == 0:
        return ExecutionStatus.SUCCESS.value
    status = (
        {
            ExecutionStatus.SUCCESS: [],
            ExecutionStatus.EXECUTION_ERROR: [],
            ExecutionStatus.ISSUE_REPORTED: results,
            ExecutionStatus.SKIPPED: [],
        }
        if isinstance(results[0], BaseValidationEntity)
        else {
            ExecutionStatus.SUCCESS: [
                result
                for result in results
                if result.get("executionStatus") == ExecutionStatus.SUCCESS.value
            ],
            ExecutionStatus.EXECUTION_ERROR: [
                result
                for result in results
                if result.get("executionStatus")
                == ExecutionStatus.EXECUTION_ERROR.value
            ],
            ExecutionStatus.ISSUE_REPORTED: [
                result
                for result in results
                if result.get("executionStatus") == ExecutionStatus.ISSUE_REPORTED.value
            ],
            ExecutionStatus.SKIPPED: [
                result
                for result in results
                if result.get("executionStatus") == ExecutionStatus.SKIPPED.value
            ],
        }
    )
    if len(results) != (
        len(status[ExecutionStatus.SUCCESS])
        + len(status[ExecutionStatus.EXECUTION_ERROR])
        + len(status[ExecutionStatus.ISSUE_REPORTED])
        + len(status[ExecutionStatus.SKIPPED])
    ):
        return ExecutionStatus.UNKNOWN_STATUS.value
    elif status[ExecutionStatus.EXECUTION_ERROR]:
        return ExecutionStatus.EXECUTION_ERROR.value
    elif status[ExecutionStatus.ISSUE_REPORTED]:
        return ExecutionStatus.ISSUE_REPORTED.value
    elif status[ExecutionStatus.SUCCESS]:
        return ExecutionStatus.SUCCESS.value
    elif status[ExecutionStatus.SKIPPED]:
        return ExecutionStatus.SKIPPED.value
    else:
        return ExecutionStatus.UNKNOWN_STATUS.value


def get_standard_codelist_cache_key(standard: str, version: str) -> str:
    standard, version = normalize_adam_input(standard, version)
    return f"{standard.lower()}-{version.replace('.', '-')}-codelists"


def is_valid_iso_date(date_to_validate: str) -> bool:
    """
    Validates a given date against an ISO Format.
    Valid date example: 2022-02-04T15:29:20.173854
    """
    is_valid = True
    try:
        datetime.fromisoformat(date_to_validate)
    except ValueError:
        is_valid = False
    return is_valid


DATASET_CACHE_KEY_TEMPLATE: str = "{dataset_path}_{dataset_type}"


def get_dataset_cache_key_from_path(dataset_path: str, dataset_type: str) -> str:
    return DATASET_CACHE_KEY_TEMPLATE.format(
        dataset_path=dataset_path, dataset_type=dataset_type
    )


def get_library_variables_metadata_cache_key(
    standard_type: str, standard_version: str, standard_substandard: str
) -> str:
    if not standard_substandard:
        standard_type, standard_version = normalize_adam_input(
            standard_type, standard_version
        )
        return f"library_variables_metadata/{standard_type}/{standard_version}"
    else:
        return f"library_variables_metadata/{standard_type}/{standard_version}/{standard_substandard}"


def get_standard_details_cache_key(
    standard_type: str, standard_version: str, standard_substandard: str = None
) -> str:
    standard_type, standard_version = normalize_adam_input(
        standard_type, standard_version
    )
    if not standard_substandard:
        return f"standards/{standard_type}/{standard_version}"
    else:
        return f"standards/{standard_type}/{standard_version}/{standard_substandard.lower()}"


def normalize_adam_input(standard: str, version: str) -> tuple:
    """
    Normalizes ADAM user input to the expected internal format.
    Args:
        standard: User input like 'adamig', 'adam-adae'
        version: User input like '1-0'
    Returns:
        Tuple of (normalized_standard, normalized_version)
        Examples:
        - ('adamig', '1-0') -> ('adam', 'adamig-1-0')
        - ('adam-adae', '1-0') -> ('adam', 'adam-adae-1-0')
        - ('sdtm', '3-4') -> ('sdtm', '3-4')
    """
    if standard:
        standard_lower = standard.lower()
        if standard_lower in ADAM_PRODUCTS:
            return "adam", f"{standard_lower}-{version}"
    # Non-ADAM standard - keep as is
    return standard, version


def get_model_details_cache_key(standard: str, model_version: str) -> str:
    return f"models/{standard}/{model_version.replace('.', '-')}"


def get_model_details_cache_key_from_ig(standard_metadata: dict) -> str:
    model_link = standard_metadata.get("_links", {}).get("model", {}).get("href", "")
    model_link_parts = model_link.split("/")
    standard = model_link_parts[2]
    full_version = model_link_parts[3]
    # for ADaM, there is an extra adam prefix in the version
    if full_version.startswith(f"{standard}-"):
        version = full_version[len(standard) + 1 :]
    else:
        version = full_version
    return get_model_details_cache_key(standard=standard, model_version=version)


def replace_pattern_in_list_of_strings(
    list_of_strings: List[str], pattern: str, value: str
) -> List[str]:
    return [string.replace(pattern, value or "") for string in list_of_strings]


def get_operations_cache_key(
    core_id: str,
    operation_id: str,
    domain: str = None,
    operation_name: str = None,
    evaluation_dataset_name: str = None,
    grouping: str = None,
    target_variable: str = None,
) -> str:
    """
    Creates the cache key for operations.
    """
    key = f"operations/{core_id}/{operation_id}"
    optional_items = [
        domain,
        operation_name,
        evaluation_dataset_name,
        grouping,
        target_variable,
    ]
    for item in optional_items:
        if item:
            key = f"{key}/{item}"
    return key


def serialize_rule(rule: dict) -> dict:
    """
    Converts rule "conditions" to dict.
    TODO create a Rule class and move this function there
    """
    serialized_rule: dict = copy.deepcopy(rule)
    conditions: ConditionInterface = serialized_rule["conditions"]
    serialized_rule["conditions"] = conditions.to_dict()
    return serialized_rule


def get_cache_last_updated_key() -> str:
    return "CACHE_LAST_UPDATED"


def remove_none_keys_from_dict(dict_to_remove: dict):
    """
    Removes dict keys whose value is None.
    Changes the dict by reference.
    """
    # dict can't change its size during iteration
    dict_copy: dict = copy.deepcopy(dict_to_remove)
    for key, value in dict_copy.items():
        if value is None:
            dict_to_remove.pop(key)


def list_contains_duplicates(list_to_check: list) -> bool:
    """
    Checks if a list contains duplicated items.
    """
    return bool(len(list_to_check) > len(set(list_to_check)))


def generate_report_filename(generation_time: str) -> str:
    timestamp = (
        datetime.fromisoformat(generation_time)
        .replace(microsecond=0)
        .isoformat()
        .replace(":", "-")
    )
    return f"CORE-Report-{timestamp}"


def get_rules_cache_key(standard: str, version: str, substandard: str = None) -> str:
    if substandard:
        key = f"{standard.lower()}/{version}/{substandard.lower()}"
    else:
        key = f"{standard.lower()}/{version}"
    return key


def get_metadata_cache_key(metadata_key: str):
    return f"library/metadata{metadata_key}"


def get_variable_codelist_map_cache_key(standard: str, version: str, subversion) -> str:
    if subversion:
        return f"{standard}-{version}-{subversion}-codelists"
    else:
        standard, version = normalize_adam_input(standard, version)
        return f"{standard}-{version}-codelists"


def get_meddra_code_term_pairs_cache_key(meddra_path: str) -> str:
    return f"meddra_valid_code_term_pairs_{meddra_path}"


def get_item_index_by_condition[
    T
](list_of_dicts: List[T], condition: Callable[[T], bool]) -> Optional[int]:
    """
    Uses linear search to return index of element
    in unsorted list which applies to the condition.
    """
    for index, dictionary in enumerate(list_of_dicts):
        if condition(dictionary):
            return index


def search_in_list[
    T
](list_of_dicts: List[T], condition: Callable[[T], bool]) -> Optional[T]:
    """
    Returns an element of unsorted list that applies to the condition.
    """
    index = get_item_index_by_condition(list_of_dicts, condition)
    if index is not None:
        return list_of_dicts[index]


def is_valid_uuid(string_to_validate: str) -> bool:
    """
    Checks if a given string is a valid UUID.
    """
    try:
        UUID(string_to_validate)
    except ValueError:
        return False
    return True


def get_dictionary_path(directory_path: str, file_name: str) -> str:
    """
    Creates a path to dictionary directory or file.
    """
    return os.path.join(directory_path, file_name)


def decode_line(line: bytes) -> str:
    return line.decode("utf-8").replace("\n", "").replace("\r", "")


def get_sided_match_keys(match_keys: List[Union[str, dict]], side: str) -> List[str]:
    return [
        match_key if isinstance(match_key, str) else match_key[side]
        for match_key in match_keys
    ]


def parse_date(date_str):
    if not isinstance(date_str, str) or not is_valid_date(date_str):
        return 0, 0
    if "--" in date_str:
        date_str = date_str.split("--", 1)[0]
    parts = re.split(r"[-T:]", date_str)
    precision = len([part for part in parts if part])
    return date_str, precision


def dates_overlap(date1_str, precision1, date2_str, precision2):
    if precision1 == precision2:
        return date1_str == date2_str, None

    less_precise = date1_str if precision1 < precision2 else date2_str
    more_precise = date2_str if precision1 < precision2 else date1_str

    return more_precise.startswith(less_precise), less_precise


def replace_nan_values_in_df(df, columns):
    for col in columns:
        if col in df.columns:
            mask = pd.isna(df[col])
            if mask.any():
                df.loc[mask, col] = None
    return df


def validate_dataset_files_exist(dataset_path: tuple[str], logger, ctx):
    non_existing_files: list[str] = [
        path for path in dataset_path if not os.path.exists(path)
    ]
    if non_existing_files:
        logger.error(f'Files {", ".join(non_existing_files)} are not found')
        ctx.exit(2)


def set_max_errors_per_rule(args):
    env_value = (
        (os.getenv("MAX_ERRORS_PER_RULE")) if os.getenv("MAX_ERRORS_PER_RULE") else None
    )

    if env_value:
        parsed_tuple = ast.literal_eval(env_value)
        env_max_errors = parsed_tuple[0]
        env_per_dataset = parsed_tuple[1]
    else:
        env_max_errors = None
        env_per_dataset = None
    cli_limit, cli_per_dataset = args.max_errors_per_rule
    if env_max_errors is not None and cli_limit > 0:
        max_errors_per_rule = max(env_max_errors, cli_limit)
    elif env_max_errors is not None:
        max_errors_per_rule = env_max_errors
    elif cli_limit and cli_limit > 0:
        max_errors_per_rule = cli_limit
    else:
        max_errors_per_rule = None

    if max_errors_per_rule is not None and max_errors_per_rule <= 0:
        max_errors_per_rule = None

    per_dataset = bool(env_per_dataset or cli_per_dataset)
    return max_errors_per_rule, per_dataset


def load_json_with_optional_encoding(path: str, encoding: str | None = None) -> dict:
    tried = []
    if encoding:
        # If the file contains only ASCII characters, incorrect encodings may still succeed
        try:
            with open(path, "r", encoding=encoding) as f:
                return json.load(f)
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            tried.append((encoding, e))

    fallback_encodings = [
        "utf-8-sig",  # UTF-8 + BOM
        "utf-8",
        locale.getpreferredencoding(False),
    ]

    for enc in fallback_encodings:
        if enc == encoding:
            continue

        try:
            with open(path, "r", encoding=enc) as f:
                return json.load(f)
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            tried.append((enc, e))

    tried_msg = ", ".join(enc for enc, _ in tried)

    raise ValueError(f"Unable to load JSON file '{path}'. Tried encodings: {tried_msg}")


def custom_str_conversion(x):
    """used to normalize numeric representations i.e. treat 200.00 as 200 for comparisons"""
    if pd.notna(x):
        if isinstance(x, str):
            try:
                float_val = float(x)
                if float_val.is_integer():
                    return str(int(float_val)).strip()
                else:
                    return str(float_val).strip()
            except (ValueError, TypeError):
                return x.strip()
        elif isinstance(x, int):
            return str(x).strip()
        elif isinstance(x, float):
            return f"{x:.0f}" if x.is_integer() else str(x).strip()
    return x
