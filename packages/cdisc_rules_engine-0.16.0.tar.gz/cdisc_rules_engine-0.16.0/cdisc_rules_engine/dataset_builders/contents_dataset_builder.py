from cdisc_rules_engine.dataset_builders.base_dataset_builder import BaseDatasetBuilder
from cdisc_rules_engine.utilities.sdtm_utilities import (
    get_corresponding_datasets,
)


class ContentsDatasetBuilder(BaseDatasetBuilder):
    def build(self, **kwargs):
        """
        Returns the contents of a file as a dataframe for evaluation.
        """
        return self.data_service.get_dataset(dataset_name=self.dataset_metadata.name)

    def build_split_datasets(self, dataset_name, **kwargs):
        """
        Returns the contents of a file as a dataframe for evaluation.
        """
        return self.data_service.get_dataset(dataset_name=dataset_name)

    def get_dataset(self):
        dataset = super().get_dataset()
        length = sum(
            [
                dataset.record_count
                for dataset in get_corresponding_datasets(
                    self.data_service.get_datasets(), self.dataset_metadata
                )
            ]
        )
        dataset.length = length
        return dataset
