from typing import Type

from cdisc_rules_engine.dataset_builders.contents_library_variables_dataset_builder import (
    ContentsLibraryVariablesDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.json_schema_check_dataset_builder import (
    JsonSchemaCheckDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.jsonata_dataset_builder import (
    JSONataDatasetBuilder,
)
from cdisc_rules_engine.interfaces import FactoryInterface
from cdisc_rules_engine.dataset_builders.contents_dataset_builder import (
    ContentsDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.contents_define_dataset_builder import (
    ContentsDefineDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.content_metadata_dataset_builder import (
    ContentMetadataDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.variables_metadata_dataset_builder import (
    VariablesMetadataDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.domain_list_dataset_builder import (
    DomainListDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.variables_metadata_with_define_dataset_builder import (
    VariablesMetadataWithDefineDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.contents_define_variables_dataset_builder import (
    ContentsDefineVariablesDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.dataset_metadata_define_dataset_builder import (
    DatasetMetadataDefineDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.contents_define_vlm_dataset_builder import (
    ContentsDefineVLMDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.variables_metadata_with_library_metadata import (
    VariablesMetadataWithLibraryMetadataDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.define_variables_with_library_metadata import (
    DefineVariablesWithLibraryMetadataDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.variables_metadata_with_define_and_library_dataset_builder import (
    VariablesMetadataWithDefineAndLibraryDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.dataset_metadata_values_builder import (
    ValueCheckDatasetMetadataDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.variables_metadata_values_dataset_builder import (
    ValueCheckVariableMetadataDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.domain_list_with_define_builder import (
    DomainListWithDefineDatasetBuilder,
)
from cdisc_rules_engine.dataset_builders.base_dataset_builder import BaseDatasetBuilder
from cdisc_rules_engine.enums.rule_types import RuleTypes


class DatasetBuilderFactory(FactoryInterface):
    _builders_map = {
        RuleTypes.RECORD_CHECK.value: ContentsDatasetBuilder,
        RuleTypes.DATASET_CONTENTS_CHECK_AGAINST_DEFINE.value: ContentsDefineDatasetBuilder,
        RuleTypes.DATASET_METADATA_CHECK.value: ContentMetadataDatasetBuilder,
        RuleTypes.DATASET_METADATA_CHECK_AGAINST_DEFINE.value: DatasetMetadataDefineDatasetBuilder,
        RuleTypes.VARIABLE_METADATA_CHECK.value: VariablesMetadataDatasetBuilder,
        RuleTypes.DOMAIN_PRESENCE_CHECK.value: DomainListDatasetBuilder,
        RuleTypes.DOMAIN_PRESENCE_CHECK_AGAINST_DEFINE.value: DomainListWithDefineDatasetBuilder,
        RuleTypes.VARIABLE_METADATA_CHECK_AGAINST_DEFINE.value: VariablesMetadataWithDefineDatasetBuilder,
        RuleTypes.VALUE_CHECK_AGAINST_DEFINE_XML_VARIABLE.value: ContentsDefineVariablesDatasetBuilder,
        RuleTypes.VALUE_CHECK_AGAINST_DEFINE_XML_VLM.value: ContentsDefineVLMDatasetBuilder,
        RuleTypes.VARIABLE_METADATA_CHECK_AGAINST_LIBRARY.value: VariablesMetadataWithLibraryMetadataDatasetBuilder,
        RuleTypes.DEFINE_ITEM_METADATA_CHECK_AGAINST_LIBRARY.value: DefineVariablesWithLibraryMetadataDatasetBuilder,
        RuleTypes.VARIABLE_METADATA_CHECK_AGAINST_DEFINE_XML_AND_LIBRARY.value: VariablesMetadataWithDefineAndLibraryDatasetBuilder,
        RuleTypes.VALUE_CHECK_WITH_DATASET_METADATA.value: ValueCheckDatasetMetadataDatasetBuilder,
        RuleTypes.VALUE_CHECK_WITH_VARIABLE_METADATA.value: ValueCheckVariableMetadataDatasetBuilder,
        RuleTypes.JSONATA.value: JSONataDatasetBuilder,
        RuleTypes.JSON_SCHEMA_CHECK.value: JsonSchemaCheckDatasetBuilder,
        RuleTypes.VALUE_CHECK_AGAINST_LIBRARY.value: ContentsLibraryVariablesDatasetBuilder,
    }

    @classmethod
    def register_service(cls, name: str, builder: Type[BaseDatasetBuilder]) -> None:
        """
        Save mapping of operation name and it's implementation
        """
        if not name:
            raise ValueError("Builder name must not be empty!")
        if not issubclass(builder, BaseDatasetBuilder):
            raise TypeError("Implementation of BaseDatasetBuilder required!")
        cls._operations_map[name] = builder

    def get_service(
        self,
        name,
        **kwargs,
    ) -> BaseDatasetBuilder:
        """
        Get instance of dataset builder by name.
        """
        builder_class = self._builders_map.get(name)
        if builder_class is None:
            raise ValueError(f"Invalid Rule Type Entered: '{name}'")

        return builder_class(
            kwargs.get("rule"),
            kwargs.get("data_service"),
            kwargs.get("cache_service"),
            kwargs.get("rule_processor"),
            kwargs.get("data_processor"),
            kwargs.get("dataset_metadata", ""),
            kwargs.get("define_xml_path"),
            kwargs.get("standard"),
            kwargs.get("standard_version"),
            kwargs.get("standard_substandard", None),
            kwargs.get("library_metadata"),
        )
