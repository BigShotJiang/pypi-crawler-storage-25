from cdisc_rules_engine.dataset_builders.base_dataset_builder import BaseDatasetBuilder
from cdisc_rules_engine.models.dataset import DatasetInterface


class VariablesMetadataWithLibraryMetadataDatasetBuilder(BaseDatasetBuilder):
    def build(self):
        """
        Returns the variable metadata from a given file.
        Returns a dataframe with the following columns:
        variable_name
        variable_order_number
        variable_label
        variable_size
        variable_data_type
        variable_has_empty_values
        variable_is_empty
        library_variable_name,
        library_variable_label,
        library_variable_data_type,
        library_variable_role,
        library_variable_core,
        library_variable_ccode,
        library_variable_has_codelist
        library_variable_order_number
        """
        # get dataset metadata and execute the rule
        content_variables_metadata: DatasetInterface = (
            self.data_service.get_variables_metadata(
                dataset_name=self.dataset_metadata.name
            )
        )
        dataset_contents = self.get_dataset_contents()
        library_variables_metadata = self.get_library_variables_metadata()
        column_name_mapping = {
            "library_variable_ordinal": "library_variable_order_number",
            "library_variable_simpleDatatype": "library_variable_data_type",
        }
        if hasattr(library_variables_metadata, "data"):
            library_data = library_variables_metadata.data
        else:
            library_data = library_variables_metadata._data
        library_data = library_data.rename(columns=column_name_mapping)
        data = content_variables_metadata.merge(
            library_data[
                [
                    "library_variable_name",
                    "library_variable_label",
                    "library_variable_data_type",
                    "library_variable_role",
                    "library_variable_core",
                    "library_variable_ccode",
                    "library_variable_has_codelist",
                    "library_variable_order_number",
                ]
            ],
            how="left",
            left_on="variable_name",
            right_on="library_variable_name",
        ).fillna("")

        data[["variable_has_empty_values", "variable_is_empty"]] = data.apply(
            lambda row: self.get_variable_null_stats(
                row["variable_name"], dataset_contents
            ),
            axis=1,
            result_type="expand",
        )

        return data

    def get_variable_null_stats(
        self, variable: str, content: DatasetInterface
    ) -> tuple[bool, bool]:
        if variable not in content:
            return True, True
        series = content[variable].mask(content[variable] == "")
        return series.isnull().any(), series.isnull().all()
