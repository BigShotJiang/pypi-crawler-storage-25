class EngineError(Exception):
    """All custom API Exceptions"""

    def __init__(self, message=None):
        self.message = message


class DatasetNotFoundError(EngineError):
    code = 404
    description = "Dataset not found"


class ReferentialIntegrityError(EngineError):
    description = "This action violates referential integrity"


class MissingDataError(EngineError):
    description = "Necessary data missing"


class RuleExecutionError(EngineError):
    code = 500
    description = "Issue executing rule"


class RuleFormatError(EngineError):
    code = 400
    description = "Improperly formatted rule"


class InvalidMatchKeyError(EngineError):
    code = 400
    description = "Invalid match key provided"


class VariableMetadataNotFoundError(EngineError):
    code = 400
    description = (
        "Variable metadata is not found in CDISC Library for the provided standard"
    )


class LibraryMetadataNotFoundError(EngineError):
    code = 400
    description = (
        "Library metadata not found for the provided standard and version combination."
    )


class DomainNotFoundError(EngineError):
    """Raised when a required domain is not found in the dataset"""

    code = 404
    description = "Domain Not Found"


class DomainNotFoundInDefineXMLError(EngineError):
    code = 400
    description = "Domain is not found in Define XML file"


class InvalidDatasetFormat(EngineError):
    code = 400
    description = "Dataset data is malformed."


class InvalidJSONFormat(EngineError):
    code = 400
    description = "JSON data is malformed."


class ExcelTestDataError(EngineError):
    code = 400
    description = (
        "Excel test data file is missing required sheets or column headers. "
        "Sheet and column names are case-sensitive."
    )


class CTPackageNotFoundError(EngineError):
    code = 400
    description = "Controlled terminology package(s) not found"


class InvalidCSVFile(EngineError):
    code = 400
    description = "CSV data is malformed."


class NumberOfAttemptsExceeded(EngineError):
    pass


class InvalidDictionaryVariable(EngineError):
    description = (
        "Provided dictionary variable does not correspond to a dictionary term type"
    )


class UnsupportedDictionaryType(EngineError):
    description = "Specified dictionary type is not supported by the rules engine."


class FailedSchemaValidation(EngineError):
    description = "Error Occured in Schema Validation"


class SchemaNotFoundError(EngineError):
    code = 404
    description = "XSD file could not be found"


class InvalidSchemaProvidedError(EngineError):
    code = 400
    description = "Failed to parse XMLSchema"


class PreprocessingError(EngineError):
    description = "Error occurred during dataset preprocessing"


class OperationError(EngineError):
    description = "Error occurred during operation execution"


class DatasetBuilderError(EngineError):
    description = "Error occurred during dataset building"


class DateTimeParserError(EngineError):
    code = 400
    description = "Failure to parse a datetime string"


class UnsupportedXptFormatError(EngineError):
    code = 400
    description = (
        "Unsupported XPT (SAS Transport) format. Only Transport v5 is supported."
    )
