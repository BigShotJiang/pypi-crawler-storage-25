import os
from os.path import basename
from io import IOBase
from typing import Iterable, List, Optional, Tuple

from cdisc_rules_engine.interfaces import CacheServiceInterface, ConfigInterface
from cdisc_rules_engine.models.sdtm_dataset_metadata import SDTMDatasetMetadata
from cdisc_rules_engine.models.dataset_types import DatasetTypes
from cdisc_rules_engine.models.variable_metadata_container import (
    VariableMetadataContainer,
)
from cdisc_rules_engine.services.data_readers.data_reader_factory import (
    DataReaderFactory,
)
from cdisc_rules_engine.services.datasetxpt_metadata_reader import (
    DatasetXPTMetadataReader,
)
from cdisc_rules_engine.services.datasetjson_metadata_reader import (
    DatasetJSONMetadataReader,
)
from cdisc_rules_engine.services.datasetndjson_metadata_reader import (
    DatasetNDJSONMetadataReader,
)
from cdisc_rules_engine.services.csv_metadata_reader import DatasetCSVMetadataReader
from cdisc_rules_engine.utilities.utils import (
    convert_file_size,
)
from cdisc_rules_engine.exceptions.custom_exceptions import InvalidDatasetFormat
from .base_data_service import BaseDataService, cached_dataset
from cdisc_rules_engine.enums.dataformat_types import DataFormatTypes
from cdisc_rules_engine.models.dataset.dataset_interface import DatasetInterface
from cdisc_rules_engine.models.dataset import PandasDataset
import re


class LocalDataService(BaseDataService):
    _instance = None

    def __init__(
        self,
        cache_service: CacheServiceInterface,
        reader_factory: DataReaderFactory,
        config: ConfigInterface,
        **kwargs,
    ):
        self.encoding: str = kwargs.get("encoding")
        self.variables_csv_path: str = kwargs.get("variables_csv_path")
        self.datasets_csv_path: str = kwargs.get("datasets_csv_path")
        self.dataset_paths: Iterable[str] = kwargs.get("dataset_paths") or []
        super(LocalDataService, self).__init__(
            cache_service, reader_factory, config, **kwargs
        )

    def _initialize_datasets_metadata(self, **kwargs) -> dict[str, SDTMDatasetMetadata]:
        """
        Initialize the dataset metadata by reading metadata for all dataset paths.

        Args:
            **kwargs: Keyword arguments including dataset_paths

        Returns:
            Dictionary mapping dataset name to SDTMDatasetMetadata
        """
        result = {}
        for dataset_path in self.dataset_paths:
            try:
                file_metadata, contents_metadata = self.__get_dataset_metadata(
                    dataset_path
                )
                metadata = SDTMDatasetMetadata(
                    name=contents_metadata["dataset_name"],
                    first_record=contents_metadata["first_record"],
                    label=contents_metadata["dataset_label"],
                    modification_date=contents_metadata["dataset_modification_date"],
                    filename=file_metadata["name"],
                    full_path=file_metadata["path"],
                    file_size=file_metadata["file_size"],
                    record_count=contents_metadata["dataset_length"],
                )
                result[metadata.name] = metadata
            except InvalidDatasetFormat:
                raise
            except Exception as e:
                raise InvalidDatasetFormat(
                    f"Your data file could not be read: {dataset_path}."
                ) from e
        return result

    @classmethod
    def get_instance(
        cls,
        cache_service: CacheServiceInterface,
        config: ConfigInterface = None,
        **kwargs,
    ):
        """
        Return the singleton instance. Reset the instance when encoding is
        explicitly requested and differs from the cached one (e.g., validation
        runs multiple times with different encodings in the same process).
        """
        encoding = kwargs.get("encoding")
        dataset_paths = kwargs.get("dataset_paths")
        if (
            cls._instance is None
            or (encoding is not None and cls._instance.encoding != encoding)
            or (
                dataset_paths is not None
                and cls._instance.dataset_paths != dataset_paths
            )
        ):
            service = cls(
                cache_service=cache_service,
                reader_factory=DataReaderFactory(
                    dataset_implementation=kwargs.get(
                        "dataset_implementation", PandasDataset
                    ),
                    encoding=encoding,
                ),
                config=config,
                **kwargs,
            )
            cls._instance = service
        return cls._instance

    def has_all_files(self, prefix: str, file_names: List[str]) -> bool:
        files = [
            f.lower()
            for f in os.listdir(prefix)
            if os.path.isfile(os.path.join(prefix, f))
        ]
        return all(item.lower() in files for item in file_names)

    def get_file_matching_pattern(self, prefix: str, pattern: str) -> str:
        """
        Returns the path to the file if one matches the pattern given, otherwise
        return None.
        """
        for f in os.listdir(prefix):
            if os.path.isfile(os.path.join(prefix, f)) and re.match(pattern, f):
                return f
        return None

    @cached_dataset(DatasetTypes.CONTENTS.value)
    def get_dataset(self, dataset_name: str, **params) -> DatasetInterface:
        full_path = self._datasets_metadata[dataset_name].full_path
        reader = self._reader_factory.get_service(
            basename(full_path).split(".")[1].upper()
        )
        df = reader.from_file(full_path)
        return df

    @cached_dataset(DatasetTypes.VARIABLES_METADATA.value)
    def get_variables_metadata(self, dataset_name: str) -> DatasetInterface:
        """
        Gets dataset from blob storage and returns metadata of a certain variable.
        """
        metadata: dict = self.__read_metadata(
            self._datasets_metadata[dataset_name].full_path
        )
        contents_metadata: dict = metadata["contents_metadata"]
        metadata_to_return: VariableMetadataContainer = VariableMetadataContainer(
            contents_metadata
        )
        return self.dataset_implementation.from_dict(
            metadata_to_return.to_representation()
        )

    @cached_dataset(DatasetTypes.CONTENTS.value)
    def get_define_xml_contents(self, dataset_name: str) -> bytes:
        """
        Reads local define xml file as bytes
        """
        with open(dataset_name, "rb") as f:
            return f.read()

    def get_dataset_by_type(
        self, dataset_name: str, dataset_type: str, **params
    ) -> DatasetInterface:
        """
        Generic function to return dataset based on the type.
        dataset_type param can be: contents, metadata, variables_metadata.
        """
        dataset_type_to_function_map: dict = {
            DatasetTypes.CONTENTS.value: self.get_dataset,
            DatasetTypes.METADATA.value: self.get_dataset_metadata,
            DatasetTypes.VARIABLES_METADATA.value: self.get_variables_metadata,
        }
        return dataset_type_to_function_map[dataset_type](
            dataset_name=dataset_name, **params
        )

    def __read_metadata(
        self,
        dataset_path: str,
    ) -> dict:
        file_size = os.path.getsize(dataset_path)
        file_name = basename(dataset_path)
        file_metadata = {
            "path": dataset_path,
            "name": file_name,
            "file_size": file_size,
        }
        if file_name.endswith(".parquet") and self.get_datasets():
            for obj in self.get_datasets():
                if obj.full_path == dataset_path:
                    file_metadata = {
                        "path": obj.original_path,
                        "name": basename(obj.original_path),
                        "file_size": os.path.getsize(obj.original_path),
                    }
                    file_name = obj.filename
                    break
            # If we reach this line a parquet dataset was provided without a
            # corresponding xpt or json file. This should not happen
            # TODO: Implement a DatasetParquetMetadataReader so we don't have to
            # perform this check.

        _metadata_reader_map = {
            DataFormatTypes.XPT.value: DatasetXPTMetadataReader,
            DataFormatTypes.JSON.value: DatasetJSONMetadataReader,
            DataFormatTypes.NDJSON.value: DatasetNDJSONMetadataReader,
            DataFormatTypes.CSV.value: DatasetCSVMetadataReader,
        }

        file_extension = file_name.split(".")[1].upper()
        if file_extension not in _metadata_reader_map:
            supported_formats = ", ".join(_metadata_reader_map.keys())
            raise ValueError(
                f"Unsupported file format '{file_extension}' in file '{file_name}'.\n"
                f"Supported formats: {supported_formats}\n"
                f"Please provide dataset files in SAS V5 XPT, "
                f"Dataset-JSON (JSON or NDJSON), CSV, or Excel (XLSX) format."
            )

        contents_metadata = _metadata_reader_map[file_extension](
            file_metadata["path"],
            file_name,
            encoding=self.encoding,
            variables_csv_path=self.variables_csv_path,
            datasets_csv_path=self.datasets_csv_path,
        ).read()
        return {
            "file_metadata": file_metadata,
            "contents_metadata": contents_metadata,
        }

    def read_data(self, file_path: str) -> IOBase:
        return open(file_path, "rb")

    def __get_dataset_metadata(self, dataset_path: str, **kwargs) -> Tuple[dict, dict]:
        """
        Internal method that gets dataset metadata
        and converts file size if needed.
        """
        metadata: dict = self.__read_metadata(dataset_path)
        file_metadata: dict = metadata["file_metadata"]
        size_unit: Optional[str] = kwargs.get("size_unit")
        if size_unit:  # convert file size from bytes to desired unit if needed
            file_metadata["file_size"] = convert_file_size(
                file_metadata["file_size"], size_unit
            )
        return file_metadata, metadata["contents_metadata"]

    def to_parquet(self, file_path: str) -> str:
        reader = self._reader_factory.get_service(
            basename(file_path).split(".")[1].upper()
        )
        return reader.to_parquet(file_path)

    @staticmethod
    def is_valid_data(dataset_paths: List[str]) -> bool:
        for dataset_path in dataset_paths:
            if not os.path.exists(dataset_path):
                return False
        return len(dataset_paths) > 0
