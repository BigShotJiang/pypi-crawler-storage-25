from cdisc_rules_engine.enums.base_enum import BaseEnum


class RuleTypes(BaseEnum):
    RECORD_CHECK = "Record Data"
    DATASET_CONTENTS_CHECK_AGAINST_DEFINE = "Dataset Contents Check against Define XML"
    DATASET_METADATA_CHECK = "Dataset Metadata Check"
    DATASET_METADATA_CHECK_AGAINST_DEFINE = "Dataset Metadata Check against Define XML"
    DOMAIN_PRESENCE_CHECK = "Domain Presence Check"
    DOMAIN_PRESENCE_CHECK_AGAINST_DEFINE = "Domain Presence Check against Define XML"
    JSONATA = "JSONata"
    VARIABLE_METADATA_CHECK = "Variable Metadata Check"
    VARIABLE_METADATA_CHECK_AGAINST_DEFINE = (
        "Variable Metadata Check against Define XML"
    )
    VARIABLE_METADATA_CHECK_AGAINST_DEFINE_XML_AND_LIBRARY = (
        "Variable Metadata Check against Define XML and Library Metadata"
    )
    VARIABLE_METADATA_CHECK_AGAINST_LIBRARY = (
        "Variable Metadata Check against Library Metadata"
    )
    VALUE_CHECK_AGAINST_DEFINE_XML_VARIABLE = "Value Check against Define XML Variable"
    VALUE_CHECK_AGAINST_LIBRARY = "Value Check against Library Metadata"
    VALUE_CHECK_AGAINST_DEFINE_XML_VLM = "Value Check against Define XML VLM"
    DEFINE_ITEM_METADATA_CHECK_AGAINST_LIBRARY = (
        "Define Item Metadata Check against Library Metadata"
    )
    VALUE_CHECK_WITH_DATASET_METADATA = "Value Check with Dataset Metadata"
    VALUE_CHECK_WITH_VARIABLE_METADATA = "Value Check with Variable Metadata"
    JSON_SCHEMA_CHECK = "JSON Schema Check"
