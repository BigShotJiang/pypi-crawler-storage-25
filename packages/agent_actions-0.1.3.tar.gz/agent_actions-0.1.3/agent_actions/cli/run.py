"""Run command for the Agent Actions CLI."""

import asyncio
import logging
import traceback
from pathlib import Path
from typing import Literal, cast

import click

from agent_actions.cli.cli_decorators import handles_user_errors, requires_project
from agent_actions.config.project_paths import ProjectPathsFactory, find_config_file
from agent_actions.logging import LoggerFactory
from agent_actions.prompt.renderer import ConfigRenderingService
from agent_actions.tooling.docs.run_tracker import RunTracker
from agent_actions.validation.prompt_validator import PromptValidator
from agent_actions.workflow.coordinator import AgentWorkflow, WorkflowPaths, WorkflowRuntimeConfig

logger = logging.getLogger(__name__)
from agent_actions.validation.run_validator import RunCommandArgs


class RunCommand:
    def __init__(self, args: RunCommandArgs):
        self.args = args
        self.agent_name = Path(args.agent).stem

    def _determine_execution_mode(self, workflow: AgentWorkflow) -> bool:
        mode = getattr(self.args, "execution_mode", "auto")

        if mode == "parallel":
            click.echo("🔀 Using parallel execution (--execution-mode parallel)...")
            return True
        if mode == "sequential":
            click.echo("Using sequential execution (--execution-mode sequential)...")
            return False
        # mode == 'auto': let the workflow decide
        if workflow.services.core.action_level_orchestrator.should_use_parallel_execution():
            click.echo("🔀 Using parallel execution (auto-detected)...")
            return True

        click.echo("Using sequential execution...")
        return False

    def _run_workflow_execution(self, workflow: AgentWorkflow, use_parallel: bool) -> None:
        if use_parallel:
            asyncio.run(workflow.async_run(concurrency_limit=self.args.concurrency_limit))
        else:
            workflow.run()

    def execute(self, project_root: Path | None = None) -> None:
        click.echo(f"Starting agent run for: {self.args.agent}")

        if project_root is not None:
            from agent_actions.config.paths import PathManager
            from agent_actions.utils.path_utils import set_path_manager

            set_path_manager(PathManager(project_root=project_root))

        click.echo("Setting up project paths...")
        paths = ProjectPathsFactory.create_project_paths(
            self.agent_name, self.args.agent, project_root=project_root
        )
        PromptValidator().validate(paths.prompt_dir)
        filename = f"{self.agent_name}.yml"
        full_path = find_config_file(
            self.agent_name,
            paths.agent_config_dir,
            filename,
            check_alternatives=True,
            project_root=project_root,
        )
        click.echo("Rendering and loading configuration...")
        ConfigRenderingService().render_and_load_config(
            self.agent_name,
            full_path,
            paths.template_dir,
            paths.rendered_workflows_dir,
            project_root=project_root,
        )
        click.echo("Initializing agent workflow...")
        workflow = AgentWorkflow(
            WorkflowRuntimeConfig(
                paths=WorkflowPaths(
                    constructor_path=str(full_path),
                    user_code_path=str(self.args.user_code) if self.args.user_code else None,
                    default_path=str(paths.default_config_path),
                ),
                use_tools=self.args.use_tools,
                run_upstream=self.args.upstream,
                run_downstream=self.args.downstream,
                project_root=project_root,
            )
        )

        tracker = RunTracker(project_root=project_root)
        run_id = tracker.start_workflow_run(
            workflow_id=self.agent_name,
            workflow_name=self.agent_name,
            actions_total=len(workflow.execution_order),
        )

        workflow.services.core.action_executor.run_tracker = tracker
        workflow.services.core.action_executor.run_id = run_id

        agent_folder = workflow.services.core.action_runner.get_action_folder(self.agent_name)
        LoggerFactory.initialize(
            output_dir=agent_folder,
            workflow_name=self.agent_name,
            invocation_id=run_id,
            force=True,
        )

        click.echo("Starting workflow execution...")

        status = "FAILED"
        error_message = None

        try:
            use_parallel = self._determine_execution_mode(workflow)
            self._run_workflow_execution(workflow, use_parallel)

            if workflow.services.core.state_manager.is_workflow_complete():
                status = "SUCCESS"
                click.echo(f"Successfully completed agent run for: {self.args.agent}")
            else:
                status = "PAUSED"
                click.echo(
                    "Workflow paused - batch job(s) submitted. "
                    "Run again to check status and continue."
                )

        except Exception:
            status = "FAILED"
            error_message = traceback.format_exc()
            raise

        finally:
            try:
                tracker.finalize_workflow_run(
                    run_id=run_id, status=status, error_message=error_message
                )
            except Exception as track_error:
                logger.warning(
                    "Could not finalize workflow run tracking: %s",
                    track_error,
                    exc_info=True,
                )
                click.echo(
                    f"Warning: Could not finalize workflow run tracking: {track_error}", err=True
                )

            try:
                LoggerFactory.flush()
            except Exception as e:
                logger.debug("Failed to flush event handlers: %s", e, exc_info=True)


@click.command()
@click.option(
    "-a", "--agent", required=True, help="Agent configuration file name without path or extension"
)
@click.option(
    "-u",
    "--user-code",
    required=False,
    type=click.Path(exists=True, file_okay=False, dir_okay=True),
    help="Path to the user's code folder containing UDFs",
)
@click.option("--use-tools", is_flag=True, help="Enable tool usage for actions")
@click.option(
    "--execution-mode",
    "-e",
    type=click.Choice(["auto", "parallel", "sequential"], case_sensitive=False),
    default="auto",
    help="Execution mode: 'auto' (detect based on workflow), 'parallel', or 'sequential'",
)
@click.option(
    "--concurrency-limit",
    type=click.IntRange(min=1, max=50),
    default=5,
    help="Maximum number of actions to run concurrently (default: 5, range: 1-50)",
)
@click.option("--upstream", is_flag=True, help="Recursively execute upstream dependent workflows")
@click.option(
    "--downstream",
    is_flag=True,
    help="Execute all downstream workflows that depend on this workflow",
)
@handles_user_errors("run")
@requires_project
def run(
    agent: str,
    user_code: str | None,
    use_tools: bool,
    execution_mode: str = "auto",
    concurrency_limit: int = 5,
    upstream: bool = False,
    downstream: bool = False,
    project_root: Path | None = None,
) -> None:
    """
    Run agents with a specified agent configuration.

    The run command executes agent workflows based on the specified configuration.
    It handles the entire lifecycle from loading configuration to executing
    the workflow and processing results.

    Examples:
        agac run -a my_agent
        agac run -a my_agent --upstream
        agac run -a my_agent --downstream
        agac run -a my_agent --execution-mode parallel
    """
    args = RunCommandArgs(
        agent=agent,
        user_code=Path(user_code) if user_code else None,
        use_tools=use_tools,
        execution_mode=cast(Literal["auto", "parallel", "sequential"], execution_mode),
        concurrency_limit=concurrency_limit,
        upstream=upstream,
        downstream=downstream,
    )
    command = RunCommand(args)
    command.execute(project_root=project_root)
