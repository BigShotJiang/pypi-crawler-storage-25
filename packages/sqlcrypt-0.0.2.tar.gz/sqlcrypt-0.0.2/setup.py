import pathlib
from setuptools import setup

# python setup.py sdist bdist_wheel && twine upload dist/*

README = (pathlib.Path(__file__).parent / "README.md").read_text()

setup(
    name="SQLCrypt",
    version="0.0.2",
    description="Protect your SQLite database with AES !",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/Mr7F/sqlcrypt",
    author="Mr7F",
    author_email="git@sep.tf",
    license="MIT",
    py_modules=["sqlcrypt"],
    install_requires=["apsw", "pycryptodome"],
)
