"""Single-match SPADL loader.

Required columns: type_name, team_id, period_id, time_seconds,
start_x, start_y, end_x, end_y.

Player names: provide either a `player_name` column in the main CSV
or a `player_id` column + a separate `players_csv` (cols: player_id,
player_name) that tmviz joins in.

Optional / auto-used: result_name, is_goal, xG (sizes shot circles),
xT_added (auto-computed via the bundled Karun Singh grid if absent).

The loader also normalizes coordinate orientation: SPADL canon is
"each team attacks low-x to high-x". If the input uses absolute
coordinates (one fixed home-attacks-right system), tmviz detects it
from per-team mean shot start_x and flips the away team accordingly.
"""
from __future__ import annotations
from pathlib import Path

import numpy as np
import pandas as pd

ALWAYS_REQUIRED = [
    "type_name", "team_id",
    "period_id", "time_seconds",
    "start_x", "start_y", "end_x", "end_y",
]
# Kept for back-compat with anything that used to import it
REQUIRED_COLS = ALWAYS_REQUIRED + ["player_name", "xT_added"]


class SchemaError(ValueError):
    """Raised when the input CSV is missing required columns and the
    user hasn't supplied the lookup CSV(s) needed to fill them in."""


def _load_csv(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path, encoding="utf-8", encoding_errors="replace", low_memory=False)


def load_match(
    csv_path: str | Path,
    players_csv: str | Path | None = None,
    teams_csv:   str | Path | None = None,
) -> pd.DataFrame:
    """Load a single-match SPADL CSV. Optionally merge in player and
    team name lookups if the main CSV uses ids only.

    Resolution order (logged via SchemaError if anything is missing):

      1. If main CSV has `player_name` -> use as-is.
         Otherwise: require `player_id` + a players_csv to merge.

      2. If main CSV has `team_name` -> use as-is.
         Else if teams_csv is provided -> merge in team_name.
         Else team_name stays absent (the report still works because
         home/away names are supplied via flags / wizard / config).
    """
    df = _load_csv(csv_path)

    missing = [c for c in ALWAYS_REQUIRED if c not in df.columns]
    if missing:
        raise SchemaError(
            f"\nSPADL CSV at {csv_path} is missing required columns: {missing}\n"
            f"  Always-required: {ALWAYS_REQUIRED}\n"
            f"  See README for the full schema."
        )

    # --- Player names ------------------------------------------------------
    if "player_name" not in df.columns:
        if "player_id" not in df.columns:
            raise SchemaError(
                "\nMain CSV has neither `player_name` nor `player_id`.\n"
                "  Add a player_name column to the main CSV, OR\n"
                "  add a player_id column and pass --players-csv pointing at\n"
                "    a CSV with columns: player_id, player_name"
            )
        if players_csv is None:
            raise SchemaError(
                "\nMain CSV has player_id but no player_name.\n"
                "  Either:\n"
                "    (a) add a player_name column to the main CSV, OR\n"
                "    (b) pass --players-csv path/to/players.csv\n"
                "        (must have columns: player_id, player_name)"
            )
        pl = _load_csv(players_csv)
        need = {"player_id", "player_name"}
        miss = need - set(pl.columns)
        if miss:
            raise SchemaError(
                f"\nplayers_csv at {players_csv} is missing columns: {sorted(miss)}\n"
                f"  Required columns: player_id, player_name"
            )
        df = df.merge(pl[["player_id", "player_name"]], on="player_id", how="left")
        if df["player_name"].isna().any():
            n = int(df["player_name"].isna().sum())
            print(f"  Warning: {n} actions had no player_name match in players_csv (filled as 'Unknown')")
            df["player_name"] = df["player_name"].fillna("Unknown")

    # --- Team names (optional) ---------------------------------------------
    if "team_name" not in df.columns and teams_csv is not None:
        tm = _load_csv(teams_csv)
        need = {"team_id", "team_name"}
        miss = need - set(tm.columns)
        if miss:
            raise SchemaError(
                f"\nteams_csv at {teams_csv} is missing columns: {sorted(miss)}\n"
                f"  Required columns: team_id, team_name"
            )
        df = df.merge(tm[["team_id", "team_name"]], on="team_id", how="left")

    # --- Defaults / coercions ---------------------------------------------
    if "result_name" not in df.columns:
        df["result_name"] = "success"
    if "is_goal" not in df.columns:
        df["is_goal"] = False
    df["type_name"]   = df["type_name"].astype(str)
    df["result_name"] = df["result_name"].astype(str)
    df["is_goal"]     = df["is_goal"].astype(bool)
    df = df.sort_values(["period_id", "time_seconds"]).reset_index(drop=True)

    df, flipped = _normalize_attack_direction(df)

    if "xT_added" not in df.columns:
        from .xt_grid import compute_xt
        df["xT_added"] = compute_xt(df)
        print("  Note: no xT_added column -- auto-computed using bundled Karun Singh xT grid.")
    else:
        df["xT_added"] = df["xT_added"].fillna(0.0)

    if flipped is not None:
        print(f"  Note: detected absolute coords -- flipped team_id {flipped} so both teams attack right.")

    return df


def _normalize_attack_direction(df: pd.DataFrame) -> tuple[pd.DataFrame, int | None]:
    """Detect the input coordinate convention and standardise to
    'each team attacks low-x to high-x' (SPADL canonical).

    Returns (df, flipped_team_id_or_None).
    """
    teams = df["team_id"].unique()
    if len(teams) != 2:
        return df, None
    # Use shot start_x per team as the orientation signal -- shots cluster
    # near the opp goal, so a team attacking right has high mean shot x,
    # attacking left has low mean shot x.
    shots = df[df["type_name"].astype(str).str.startswith("shot")]
    if len(shots) < 2:
        # Not enough shots to tell -- assume already canonical
        return df, None
    means = shots.groupby("team_id")["start_x"].mean()
    if len(means) < 2:
        return df, None
    high = means.idxmax()
    low  = means.idxmin()
    if means[high] > 60 and means[low] > 60:
        # Both teams' shots are at high x -> already team-perspective (SPADL)
        return df, None
    if means[high] > 60 and means[low] < 40:
        # Absolute mode -- `low` team is attacking right-to-left.
        # Flip its events so it attacks low-x to high-x like SPADL canon.
        mask = df["team_id"] == low
        df = df.copy()
        df.loc[mask, "start_x"] = 100 - df.loc[mask, "start_x"]
        df.loc[mask, "end_x"]   = 100 - df.loc[mask, "end_x"]
        df.loc[mask, "start_y"] = 100 - df.loc[mask, "start_y"]
        df.loc[mask, "end_y"]   = 100 - df.loc[mask, "end_y"]
        return df, int(low)
    # Ambiguous -- leave it alone but warn
    return df, None


def detect_teams(df: pd.DataFrame) -> list[tuple[int, int]]:
    """Return [(team_id, action_count), ...] sorted by count desc.
    Helps the wizard prompt 'team A is X, team B is Y'."""
    counts = df["team_id"].value_counts().sort_values(ascending=False)
    return list(counts.items())


def detect_goals(df: pd.DataFrame) -> list[dict]:
    """Return one dict per goal in chronological order. Useful for the
    wizard's own-goal confirmation step."""
    g = df[df["is_goal"] == True].copy()
    out = []
    for _, r in g.iterrows():
        out.append({
            "minute":       int((r["period_id"] - 1) * 45 + r["time_seconds"] / 60),
            "period":       int(r["period_id"]),
            "time_seconds": float(r["time_seconds"]),
            "scorer":       str(r["player_name"]),
            "team_id":      int(r["team_id"]),
            "type_name":    str(r["type_name"]),
        })
    return out


# ----- Derived metrics ----------------------------------------------------

def _gain_metres(start_x, start_y, end_x, end_y):
    sx_m = (100 - start_x) * 1.05
    sy_m = (50 - start_y) * 0.68
    ex_m = (100 - end_x) * 1.05
    ey_m = (50 - end_y) * 0.68
    return np.sqrt(sx_m * sx_m + sy_m * sy_m) - np.sqrt(ex_m * ex_m + ey_m * ey_m)


def _is_progressive(start_x, end_x, gain_m):
    if start_x < 50 and end_x < 50: return gain_m >= 30
    if start_x < 50 and end_x >= 50: return gain_m >= 15
    if start_x >= 50 and end_x >= 50: return gain_m >= 10
    return False


def derive_metrics(df: pd.DataFrame) -> pd.DataFrame:
    """Add derived columns:
        gain_m            metres of forward progress
        pass_length_m     Euclidean length on real pitch
        is_progressive    progressive PASS (or cross)
        is_carry_prog     progressive CARRY (dribble)
        ball_into_box     successful pass that ends inside opp 18 yard box
                          and started outside it
    """
    df = df.copy()
    gain = _gain_metres(df["start_x"], df["start_y"], df["end_x"], df["end_y"])
    df["gain_m"] = gain
    dx_m = (df["end_x"] - df["start_x"]) * 1.05
    dy_m = (df["end_y"] - df["start_y"]) * 0.68
    df["pass_length_m"] = np.sqrt(dx_m * dx_m + dy_m * dy_m)

    is_pass = df["type_name"].isin(["pass", "cross"])
    is_succ = df["result_name"] == "success"
    df["is_progressive"] = False
    mask = is_pass & is_succ
    if mask.any():
        sub = df.loc[mask]
        df.loc[mask, "is_progressive"] = [
            _is_progressive(sx, ex, g) for sx, ex, g in
            zip(sub["start_x"], sub["end_x"], sub["gain_m"])
        ]

    is_carry = df["type_name"] == "dribble"
    df["is_carry_prog"] = False
    if is_carry.any():
        sub = df.loc[is_carry]
        df.loc[is_carry, "is_carry_prog"] = [
            _is_progressive(sx, ex, g) for sx, ex, g in
            zip(sub["start_x"], sub["end_x"], sub["gain_m"])
        ]

    # Filter SPADL dribble artifacts (huge end coords from next event)
    bad_dribble = is_carry & (df["pass_length_m"] > 50)
    if bad_dribble.any():
        df.loc[bad_dribble, "end_x"] = df.loc[bad_dribble, "start_x"]
        df.loc[bad_dribble, "end_y"] = df.loc[bad_dribble, "start_y"]
        df.loc[bad_dribble, "pass_length_m"] = 0.0
        df.loc[bad_dribble, "is_carry_prog"] = False

    # Ball into box (pass)
    df["ball_into_box"] = (
        is_pass & is_succ
        & (df["end_x"] >= 83.0) & (df["end_y"].between(20, 80))
        & ~((df["start_x"] >= 83.0) & (df["start_y"].between(20, 80)))
    )
    return df
