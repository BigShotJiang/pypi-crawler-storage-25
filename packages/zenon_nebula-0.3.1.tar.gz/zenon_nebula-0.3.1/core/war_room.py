# SPDX-License-Identifier: MIT
"""
War Room -- Unified daily battle plan for the Nebula.

**Agent pattern:** *prompt chaining* with parallel sectioning
(Anthropic "Building Effective Agents" taxonomy). Step 1 gathers a
``WarRoomContribution`` from every registered domain in parallel
(sectioning). Step 2 aggregates them into a unified state briefing.
Step 3 chains the briefing into a strategic synthesis LLM call that
returns a structured battle plan. Each step's output becomes the next
step's input -- that's the chain.

Collects WarRoomContribution from each registered domain, aggregates into
a unified state briefing, calls ``core.llm_provider.call_llm`` for
strategic synthesis, and produces a structured battle plan.

Output keys:
  - situation_assessment
  - whats_working
  - whats_failing
  - battle_plan_24h
  - resource_allocation
  - domain_status (per-domain health)

Persists battle plans to the battle_plans table and as JSON file.
"""

import json
import logging
import sqlite3
from collections.abc import Callable
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect


def _get_strategic_model() -> str:
    """Get the best available model for strategic reasoning. No hardcoded models."""
    try:
        from core.model_router import get_model

        return get_model("strategic_synthesis")
    except Exception as exc:
        logger.debug("Model router unavailable, using fallback: %s", exc)
        return "grok-4.20-0309-reasoning"  # Last resort fallback


logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
BATTLE_PLAN_FILE = ENGINE_ROOT / "data" / "battle_plan.json"

BATTLE_PLANS_SCHEMA = """
-- battle_plans table is created by core/persist_to_db.ensure_schema().
-- This is a no-op fallback for standalone WarRoom usage.
CREATE TABLE IF NOT EXISTS battle_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    situation_assessment TEXT,
    whats_working TEXT DEFAULT '[]',
    whats_failing TEXT DEFAULT '[]',
    battle_plan_24h TEXT DEFAULT '{}',
    resource_allocation TEXT DEFAULT '{}',
    domain_status TEXT DEFAULT '{}',
    raw_plan TEXT DEFAULT '{}',
    context_size_chars INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_battle_plans_ts
    ON battle_plans(timestamp);
"""

STRATEGIST_SYSTEM_PROMPT = (
    "You are the chief strategist for the Nebula -- a multi-domain "
    "autonomous system covering intelligence, development, security, quality, "
    "and contribution tracking for the Zenon Network ecosystem.\n\n"
    "You have access to ALL data about each domain: evidence counts, "
    "hypothesis confidence, engine activity, collision detections, "
    "actions log, and war room contributions from each domain.\n\n"
    "Your job: produce the most actionable daily battle plan possible. "
    "Be specific, not generic. Every recommendation must reference actual "
    "data from the briefing.\n\n"
    "Output a JSON object with these exact keys:\n"
    "  situation_assessment: 2-3 paragraphs on overall system state\n"
    "  whats_working: list of {domain, tactic, evidence}\n"
    "  whats_failing: list of {domain, tactic, recommendation}\n"
    "  battle_plan_24h: {focus, actions: list of specific actions}\n"
    "  resource_allocation: {domain_name: allocation_pct for each domain}\n"
    "  cross_domain_opportunities: list of {domains, opportunity, priority}\n\n"
    "Return ONLY the JSON object."
)


class WarRoom:
    """Unified daily battle plan for all domains.

    Collects contributions from each domain, aggregates system state,
    and produces a strategic synthesis via Claude Opus.
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        llm_call: Callable | None = None,
    ):
        self.db_path = db_path
        self._llm_call = llm_call  # injectable for testing
        self._ensure_schema()

    def _get_conn(self) -> sqlite3.Connection:
        conn = connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        conn = self._get_conn()
        try:
            conn.executescript(BATTLE_PLANS_SCHEMA)
            conn.commit()
        finally:
            conn.close()

    # ------------------------------------------------------------------
    # Context builder
    # ------------------------------------------------------------------

    def build_context(self, registry=None) -> str:
        """Aggregate ALL system data into a context string for the LLM."""
        parts = self._build_db_context()
        self._append_domain_contributions(parts, registry)
        self._append_previous_plan(parts)
        return "\n\n---\n\n".join(parts)

    def _build_db_context(self) -> list[str]:
        """Query database tables and build context sections."""
        parts: list[str] = []
        conn = self._get_conn()
        try:
            self._ctx_evidence(conn, parts)
            self._ctx_hypotheses(conn, parts)
            self._ctx_collisions(conn, parts)
            self._ctx_actions(conn, parts)
            self._ctx_feedback(conn, parts)
        finally:
            conn.close()
        return parts

    def _ctx_evidence(self, conn, parts: list[str]) -> None:
        """Append evidence summary to context parts."""
        try:
            rows = conn.execute(
                "SELECT domain, count(*) as cnt, "
                "avg(confidence) as avg_conf, "
                "max(timestamp) as last_activity "
                "FROM evidence GROUP BY domain"
            ).fetchall()
            evidence_text = "\n".join(
                f"  {r['domain']}: {r['cnt']} findings, "
                f"avg_conf={r['avg_conf'] or 0:.3f}, "
                f"last={r['last_activity']}"
                for r in rows
            )
            total = sum(r["cnt"] for r in rows)
            parts.append(f"EVIDENCE ({total} total findings):\n{evidence_text}")
        except sqlite3.OperationalError:
            parts.append("EVIDENCE: [no data]")

    def _ctx_hypotheses(self, conn, parts: list[str]) -> None:
        """Append hypothesis summary to context parts."""
        try:
            hyps = conn.execute(
                "SELECT id, domain, title, confidence, status "
                "FROM hypotheses ORDER BY confidence DESC"
            ).fetchall()
            if hyps:
                hyps_text = "\n".join(
                    f"  [{r['domain']}] {r['id']} ({r['confidence'] * 100:.0f}%): {r['title'][:80]}"
                    for r in hyps
                )
                parts.append(f"HYPOTHESES ({len(hyps)}):\n{hyps_text}")
        except sqlite3.OperationalError:
            pass

    def _ctx_collisions(self, conn, parts: list[str]) -> None:
        """Append active collisions to context parts."""
        try:
            collisions = conn.execute(
                "SELECT * FROM collisions WHERE resolved = 0 ORDER BY confidence DESC LIMIT 10"
            ).fetchall()
            if collisions:
                col_text = "\n".join(
                    f"  [{r['collision_type']}] {r['title']} "
                    f"conf={r['confidence']:.2f} "
                    f"engines={r['engine_count']}"
                    for r in collisions
                )
                parts.append(f"ACTIVE COLLISIONS ({len(collisions)}):\n{col_text}")
        except sqlite3.OperationalError:
            pass

    def _ctx_actions(self, conn, parts: list[str]) -> None:
        """Append recent actions to context parts."""
        try:
            actions = conn.execute(
                "SELECT domain, module, action, result, cost_usd "
                "FROM actions_log ORDER BY id DESC LIMIT 20"
            ).fetchall()
            if actions:
                act_text = "\n".join(
                    f"  [{r['domain']}:{r['module']}] {r['action']}: "
                    f"{(r['result'] or '')[:80]} "
                    f"(${r['cost_usd'] or 0:.4f})"
                    for r in actions
                )
                total_cost = (
                    conn.execute("SELECT sum(cost_usd) FROM actions_log").fetchone()[0] or 0
                )
                parts.append(f"RECENT ACTIONS (total spend: ${total_cost:.2f}):\n{act_text}")
        except sqlite3.OperationalError:
            pass

    def _ctx_feedback(self, conn, parts: list[str]) -> None:
        """Append pending feedback bus messages to context parts."""
        try:
            pending = conn.execute(
                "SELECT type, count(*) as cnt FROM feedback_bus "
                "WHERE acknowledged = 0 GROUP BY type"
            ).fetchall()
            if pending:
                bus_text = "\n".join(f"  {r['type']}: {r['cnt']} pending" for r in pending)
                parts.append(f"FEEDBACK BUS:\n{bus_text}")
        except sqlite3.OperationalError:
            pass

    @staticmethod
    def _append_domain_contributions(parts: list[str], registry) -> None:
        """Append domain-specific war room contributions to context."""
        if not registry:
            return
        contributions = registry.get_all_war_room_contributions()
        if contributions:
            contrib_text = "\n".join(
                f"  [{c.domain}] {c.section_title}: metrics={c.metrics}" for c in contributions
            )
            parts.append(f"DOMAIN CONTRIBUTIONS:\n{contrib_text}")

    @staticmethod
    def _append_previous_plan(parts: list[str]) -> None:
        """Append previous battle plan summary to context."""
        if not BATTLE_PLAN_FILE.exists():
            return
        try:
            prev = json.loads(BATTLE_PLAN_FILE.read_text())
            prev_date = prev.get("generated_at", "unknown")
            prev_focus = prev.get("battle_plan_24h", {}).get("focus", "unknown")
            parts.append(f"PREVIOUS BATTLE PLAN (from {prev_date}):\n  Focus was: {prev_focus}")
        except (json.JSONDecodeError, OSError):
            pass

    # ------------------------------------------------------------------
    # Strategic assessment
    # ------------------------------------------------------------------

    def run_assessment(
        self,
        registry=None,
        dry_run: bool = False,
    ) -> dict:
        """Full strategic assessment using Claude Opus.

        Args:
            registry: DomainRegistry for domain contributions.
            dry_run: If True, generate plan but do not save.

        Returns:
            The complete battle plan dict.
        """
        logger.info("=== WAR ROOM: Building context ===")
        context = self.build_context(registry)
        logger.info("Context: %d chars", len(context))

        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        prompt = (
            f"Today is {now}.\n\n"
            f"Here is the COMPLETE state of the Nebula:\n\n"
            f"{context}\n\n"
            f"Produce a comprehensive battle plan. Be specific."
        )

        if self._llm_call:
            plan = self._llm_call(STRATEGIST_SYSTEM_PROMPT, prompt)
            if isinstance(plan, str):
                plan = self._extract_json(plan)
        else:
            from core.llm_provider import call_llm

            llm_result = call_llm(
                prompt=prompt,
                system=STRATEGIST_SYSTEM_PROMPT,
                model=_get_strategic_model(),
                max_tokens=16000,
            )

            if isinstance(llm_result, dict):
                response_text = llm_result.get("text", "")
                cost = llm_result.get("cost_usd", 0)
                input_tok = llm_result.get("input_tokens", 0)
                output_tok = llm_result.get("output_tokens", 0)
                model_used = llm_result.get("model", "unknown")
                logger.info(
                    "War Room LLM cost: $%.4f (%d in, %d out, model=%s)",
                    cost,
                    input_tok,
                    output_tok,
                    model_used,
                )
            else:
                response_text = str(llm_result) if llm_result else ""

            plan = self._extract_json(response_text)

        if not plan:
            plan = {
                "situation_assessment": "Failed to generate assessment.",
                "error": "JSON parse failure",
            }

        # Metadata
        plan["generated_at"] = datetime.now(timezone.utc).isoformat()
        plan["context_size_chars"] = len(context)

        if not dry_run:
            self._save_plan(plan)

        # Persist action
        from core.persist_to_db import persist_action

        persist_action(
            db_path=self.db_path,
            domain="system",
            module="war_room",
            action="strategic_assessment",
            result=json.dumps(
                {
                    "focus": plan.get("battle_plan_24h", {}).get("focus", "unknown"),
                    "working": len(plan.get("whats_working", [])),
                    "failing": len(plan.get("whats_failing", [])),
                },
                default=str,
            ),
        )

        logger.info("=== WAR ROOM: Assessment complete ===")
        return plan

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _save_plan(self, plan: dict) -> None:
        """Save battle plan to file and database."""
        # File
        BATTLE_PLAN_FILE.parent.mkdir(parents=True, exist_ok=True)
        BATTLE_PLAN_FILE.write_text(json.dumps(plan, indent=2, default=str))

        # Database
        conn = self._get_conn()
        try:
            conn.execute(
                "INSERT INTO battle_plans "
                "(situation_assessment, whats_working, whats_failing, "
                "battle_plan_24h, resource_allocation, raw_plan, "
                "context_size_chars) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    plan.get("situation_assessment", ""),
                    json.dumps(plan.get("whats_working", []), default=str),
                    json.dumps(plan.get("whats_failing", []), default=str),
                    json.dumps(plan.get("battle_plan_24h", {}), default=str),
                    json.dumps(plan.get("resource_allocation", {}), default=str),
                    json.dumps(plan, default=str),
                    plan.get("context_size_chars", 0),
                ),
            )
            conn.commit()
        finally:
            conn.close()

        logger.info("Battle plan saved to %s", BATTLE_PLAN_FILE)

    def get_current_plan(self) -> dict | None:
        """Load the most recent battle plan."""
        if BATTLE_PLAN_FILE.exists():
            try:
                return json.loads(BATTLE_PLAN_FILE.read_text())
            except (json.JSONDecodeError, OSError):
                return None
        return None

    @staticmethod
    def _extract_json(text: str) -> dict:
        """Best-effort extraction of a JSON object from LLM output."""
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            try:
                return json.loads(text[start:end])
            except json.JSONDecodeError:
                pass
        return {}
