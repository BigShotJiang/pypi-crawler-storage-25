# SPDX-License-Identifier: MIT
"""
Trust Model — Prevent poisoning attacks on Nebula's intelligence.

Attack vectors:
  1. Malicious repo in workspace → Nebula learns wrong "facts"
  2. Poisoned commons findings → bad evidence imported
  3. Fake specs → Development domain tracks phantom work
  4. Social engineering via evidence → manipulate Director priorities

Defenses:
  1. Trust tiers — not all repos are equal
  2. Source verification — evidence must trace to trusted source
  3. Community reputation — track which contributors produce accurate findings
  4. Contradiction detection — flag findings that contradict established evidence
  5. Quarantine — new/untrusted evidence is quarantined until corroborated
"""

import hashlib
import json
import logging
import sqlite3
from pathlib import Path

from core.config import get_config
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"

# Trust tiers for repos — higher tier = more trusted.
# Sourced from config/trust.json via get_config(). TRUSTED_ORGS and
# DEFAULT_TRUST remain importable for backward compatibility with any
# callers that grabbed them directly.
TRUSTED_ORGS = get_config().trusted_orgs
DEFAULT_TRUST = get_config().default_trust


def get_nebula_version_hash() -> str:
    """Hash of security-critical Nebula modules.

    If anyone modifies trust.py, opsec.py, commons.py, or other
    security modules, the hash changes. Other participants can
    detect tampered instances by comparing version hashes.
    """
    critical_files = [
        "core/trust.py",
        "core/opsec.py",
        "core/commons.py",
        "core/resilience.py",
        "core/persist_to_db.py",
        "core/evidence_vault.py",
    ]
    hasher = hashlib.sha256()
    for f in sorted(critical_files):
        path = ENGINE_ROOT / f
        if path.exists():
            hasher.update(path.read_bytes())
    return hasher.hexdigest()[:16]


def sign_finding(finding: dict) -> dict:
    """Add version hash and integrity signature to a finding.

    Every exported finding carries proof of which Nebula version produced it.
    """
    finding["nebula_version_hash"] = get_nebula_version_hash()
    finding["integrity_hash"] = hashlib.sha256(
        json.dumps(finding, sort_keys=True, default=str).encode()
    ).hexdigest()
    return finding


def verify_finding_signature(finding: dict) -> dict:
    """Verify a finding's integrity and version hash.

    Returns: {valid: bool, version_match: bool, issues: []}
    """
    issues = []

    # Check integrity hash
    stored_hash = finding.pop("integrity_hash", None)
    stored_version = finding.get("nebula_version_hash", "")

    if stored_hash:
        computed = hashlib.sha256(
            json.dumps(finding, sort_keys=True, default=str).encode()
        ).hexdigest()
        if computed != stored_hash:
            issues.append("Integrity hash mismatch — finding was modified after signing")
        finding["integrity_hash"] = stored_hash  # Restore

    # Check version hash
    my_version = get_nebula_version_hash()
    version_match = stored_version == my_version

    if not version_match and stored_version:
        issues.append(
            f"Version hash mismatch — produced by different Nebula build ({stored_version} vs {my_version})"
        )

    return {
        "valid": len(issues) == 0,
        "version_match": version_match,
        "issues": issues,
    }


def get_repo_trust(repo_path: str) -> float:
    """Get trust level for a repo based on its origin.

    Reads git remote to determine the upstream org.
    Unknown repos get low trust by default.
    """
    import subprocess

    try:
        result = subprocess.run(
            ["git", "remote", "get-url", "upstream"],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["git", "remote", "get-url", "origin"],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=5,
            )
        url = result.stdout.strip()

        # Extract org from GitHub URL
        for org, trust in TRUSTED_ORGS.items():
            if f"github.com/{org}/" in url or f"github.com/{org}." in url:
                return trust

    except Exception as exc:
        logger.debug("Trust lookup failed for %s: %s", repo_path, exc)

    return DEFAULT_TRUST


def cap_confidence_by_trust(confidence: float, repo_path: str) -> float:
    """Cap finding confidence based on repo trust level.

    A finding from an untrusted repo can never have >30% confidence.
    A finding from zenon-network can have up to 100%.
    """
    trust = get_repo_trust(repo_path)
    return min(confidence, trust)


def should_quarantine(finding: dict) -> bool:
    """Check if a finding should be quarantined before trusting it.

    Quarantine if:
    - From unknown/low-trust source
    - Contradicts existing high-confidence evidence
    - Confidence seems artificially high for the source type
    """
    confidence = finding.get("confidence", 0)
    domain = finding.get("domain", "")
    engine = finding.get("engine", "")

    # Peer-contributed findings always quarantined until corroborated
    if "peer:" in engine or "community" in engine:
        if confidence > 0.8:
            logger.warning(
                "Quarantine: peer finding with suspiciously high confidence (%.2f)", confidence
            )
            return True

    # Ask the domain plugin whether it trusts the engine attribution.
    # Core stays domain-agnostic — each domain enforces its own allow-list
    # via DomainPlugin.trusts_engine().
    if domain:
        try:
            from core.domain_registry import DomainRegistry

            plugin = DomainRegistry.instance().get_domain(domain)
            if plugin is not None and not plugin.trusts_engine(engine):
                return True
        except Exception as exc:
            logger.debug("Trust lookup via domain plugin failed: %s", exc)

    return False


def check_contradiction(finding_text: str, db_path: str = str(DB_PATH)) -> dict | None:
    """Check if a new finding contradicts existing high-confidence evidence.

    Returns the contradicting evidence if found.
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    # Simple heuristic: check if the same domain+engine produced opposite findings
    # A more sophisticated version would use LLM for semantic comparison
    try:
        existing = conn.execute("""
            SELECT finding, confidence FROM evidence
            WHERE confidence >= 0.8
            ORDER BY confidence DESC
            LIMIT 100
        """).fetchall()

        for row in existing:
            existing_text = row["finding"] or ""
            # Very crude contradiction detection — look for negation patterns
            if _texts_contradict(finding_text, existing_text):
                return {
                    "contradicts": existing_text[:200],
                    "existing_confidence": row["confidence"],
                    "action": "quarantine_new_finding",
                }

    finally:
        conn.close()

    return None


def _texts_contradict(text_a: str, text_b: str) -> bool:
    """Simple heuristic: do two findings contradict each other?

    This is intentionally conservative — only flags obvious contradictions.
    False positives are expensive (quarantine good evidence).
    False negatives are cheaper (let possibly-bad evidence through for now).
    """
    a = text_a.lower()
    b = text_b.lower()

    # Same topic but opposite conclusion
    contradiction_pairs = [
        ("is safe", "is vulnerable"),
        ("is secure", "is insecure"),
        ("passes", "fails"),
        ("implemented", "not implemented"),
        ("matches", "mismatch"),
        ("correct", "incorrect"),
        ("no issues", "critical issue"),
    ]

    for pos, neg in contradiction_pairs:
        if (pos in a and neg in b) or (neg in a and pos in b):
            # Check they're about the same subject (crude: first 50 chars overlap)
            if _topic_overlap(a, b):
                return True

    return False


def _topic_overlap(a: str, b: str) -> bool:
    """Check if two texts are about the same topic."""
    words_a = set(a.split()[:20])
    words_b = set(b.split()[:20])
    overlap = words_a & words_b
    # If more than 30% of words overlap, probably same topic
    min_len = min(len(words_a), len(words_b))
    return len(overlap) / max(min_len, 1) > 0.3
