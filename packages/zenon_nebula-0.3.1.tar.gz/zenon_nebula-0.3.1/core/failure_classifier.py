# SPDX-License-Identifier: MIT
"""Failure Classifier -- categorize engine errors for intelligent retry.

Adapted from Room33's failure_classifier for blockchain intelligence.

Classifies engine errors from the actions_log into:
  - infrastructure: missing module, import error, network timeout -> retry later
  - data: no data available, API 404, empty response -> skip until data appears
  - bug: TypeError, AttributeError, KeyError -> needs code fix
  - rate_limit: 429, rate limit, too many requests -> backoff

Pure regex classification, no LLM.
"""

from __future__ import annotations

import logging
import re
from enum import Enum

logger = logging.getLogger(__name__)


class FailureType(str, Enum):
    """Category of an engine failure."""

    INFRASTRUCTURE = "infrastructure"
    DATA = "data"
    BUG = "bug"
    RATE_LIMIT = "rate_limit"


# -- Pattern tables --

_BUG_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"TypeError"), "TypeError"),
    (re.compile(r"AttributeError"), "AttributeError"),
    (re.compile(r"KeyError"), "KeyError"),
    (re.compile(r"ValueError"), "ValueError"),
    (re.compile(r"IndexError"), "IndexError"),
    (re.compile(r"NameError"), "NameError"),
    (re.compile(r"SyntaxError"), "SyntaxError"),
    (re.compile(r"IndentationError"), "IndentationError"),
    (re.compile(r"RecursionError"), "RecursionError"),
    (re.compile(r"OverflowError"), "OverflowError"),
    (re.compile(r"ZeroDivisionError"), "ZeroDivisionError"),
    (re.compile(r"AssertionError"), "AssertionError"),
    (re.compile(r"NotImplementedError"), "NotImplementedError"),
    (re.compile(r"UnicodeError|UnicodeDecodeError|UnicodeEncodeError"), "UnicodeError"),
    (re.compile(r"json\.JSONDecodeError|JSONDecodeError"), "JSONDecodeError"),
    (re.compile(r"Unexpected.*response.*format", re.IGNORECASE), "bad response format"),
]

_INFRASTRUCTURE_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"ModuleNotFoundError"), "ModuleNotFoundError"),
    (re.compile(r"ImportError"), "ImportError"),
    (re.compile(r"FileNotFoundError"), "FileNotFoundError"),
    (re.compile(r"PermissionError"), "PermissionError"),
    (re.compile(r"ConnectionError"), "ConnectionError"),
    (re.compile(r"ConnectionResetError"), "ConnectionResetError"),
    (re.compile(r"TimeoutError"), "TimeoutError"),
    (re.compile(r"SSLError"), "SSLError"),
    (re.compile(r"OSError"), "OSError"),
    (re.compile(r"ECONNREFUSED|ECONNRESET"), "connection refused/reset"),
    (re.compile(r"gaierror|Name or service not known", re.IGNORECASE), "DNS failure"),
    (re.compile(r"getaddrinfo failed", re.IGNORECASE), "DNS failure"),
    (re.compile(r"RemoteDisconnected|IncompleteRead", re.IGNORECASE), "connection dropped"),
    (re.compile(r"ProxyError", re.IGNORECASE), "proxy error"),
    (re.compile(r"BadGateway|Bad Gateway", re.IGNORECASE), "bad gateway"),
    (re.compile(r"Service Unavailable", re.IGNORECASE), "service unavailable"),
    (re.compile(r"HTTP[/\s]?\s*\d*\s*(502|503|504)"), "server error"),
]

_RATE_LIMIT_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"HTTP[/\s]?\s*\d*\s*(429)"), "HTTP 429"),
    (re.compile(r"status[_\s]?code[=:\s]*(429)"), "HTTP 429"),
    (re.compile(r"Too Many Requests", re.IGNORECASE), "rate limit"),
    (re.compile(r"rate[_\s]?limit", re.IGNORECASE), "rate limit"),
    (re.compile(r"throttl", re.IGNORECASE), "throttled"),
    (re.compile(r"quota[_\s]?exceeded", re.IGNORECASE), "quota exceeded"),
    (re.compile(r"overloaded", re.IGNORECASE), "API overloaded"),
]

_DATA_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"HTTP[/\s]?\s*\d*\s*(404)"), "HTTP 404"),
    (re.compile(r"status[_\s]?code[=:\s]*(404)"), "HTTP 404"),
    (re.compile(r"No data", re.IGNORECASE), "no data"),
    (re.compile(r"Not Found", re.IGNORECASE), "not found"),
    (re.compile(r"empty response", re.IGNORECASE), "empty response"),
    (re.compile(r"0 results", re.IGNORECASE), "zero results"),
    (re.compile(r"no (records|entries|rows) found", re.IGNORECASE), "no records"),
    (re.compile(r"returned empty", re.IGNORECASE), "empty return"),
    (re.compile(r"no (commits|PRs|issues|repos) found", re.IGNORECASE), "no items found"),
    (re.compile(r"repository.*not.*found", re.IGNORECASE), "repo not found"),
    (re.compile(r"branch.*not.*found", re.IGNORECASE), "branch not found"),
]

# Retry strategies per failure type
RETRY_STRATEGIES: dict[str, dict] = {
    FailureType.INFRASTRUCTURE: {
        "retry": True,
        "backoff": "exponential",
        "max_retries": 3,
        "base_delay_sec": 5.0,
    },
    FailureType.DATA: {
        "retry": False,
        "skip_until_data": True,
    },
    FailureType.BUG: {
        "retry": False,
        "needs_fix": True,
    },
    FailureType.RATE_LIMIT: {
        "retry": True,
        "backoff": "exponential",
        "max_retries": 5,
        "base_delay_sec": 10.0,
    },
}


def classify_failure(error_message: str) -> tuple[FailureType, str]:
    """Classify an engine error message into a failure category.

    Args:
        error_message: The error text (stderr, exception message, etc.)

    Returns:
        Tuple of (FailureType, human-readable reason).
    """
    if not error_message:
        return FailureType.BUG, "empty error message (assumed bug)"

    # Check rate limits first -- most time-sensitive
    for pat, reason in _RATE_LIMIT_PATTERNS:
        if pat.search(error_message):
            return FailureType.RATE_LIMIT, reason

    # Check data issues -- common and not actionable
    for pat, reason in _DATA_PATTERNS:
        if pat.search(error_message):
            return FailureType.DATA, reason

    # Check infrastructure -- network/env issues
    for pat, reason in _INFRASTRUCTURE_PATTERNS:
        if pat.search(error_message):
            return FailureType.INFRASTRUCTURE, reason

    # Check bugs -- code errors
    for pat, reason in _BUG_PATTERNS:
        if pat.search(error_message):
            return FailureType.BUG, reason

    # Default: assume bug (unknown errors need investigation)
    return FailureType.BUG, "unknown failure (assumed bug)"


def get_retry_strategy(failure_type: FailureType) -> dict:
    """Get the recommended retry strategy for a failure type."""
    return RETRY_STRATEGIES.get(failure_type, RETRY_STRATEGIES[FailureType.BUG])


def classify_from_actions_log(db_path: str, limit: int = 50) -> list[dict]:
    """Classify recent errors from the actions_log table.

    Returns list of dicts with action info + classification.
    """
    import sqlite3

    from core.persistence import connect

    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute(
            """SELECT id, timestamp, module, action, target, error
               FROM actions_log
               WHERE error IS NOT NULL AND error != ''
               ORDER BY timestamp DESC LIMIT ?""",
            (limit,),
        ).fetchall()
    finally:
        conn.close()

    results = []
    for row in rows:
        ftype, reason = classify_failure(row["error"])
        results.append(
            {
                "action_id": row["id"],
                "timestamp": row["timestamp"],
                "module": row["module"],
                "action": row["action"],
                "target": row["target"],
                "error": row["error"],
                "failure_type": ftype.value,
                "reason": reason,
                "retry_strategy": get_retry_strategy(ftype),
            }
        )

    return results
