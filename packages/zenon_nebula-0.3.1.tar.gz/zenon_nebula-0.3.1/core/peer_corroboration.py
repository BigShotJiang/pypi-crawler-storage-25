# SPDX-License-Identifier: MIT
"""
Peer Corroboration — Multi-source evidence strengthening.

When multiple independent sources (local engines, peer instances) find
similar issues, the combined confidence should be HIGHER than any single
source. This is the core value proposition of decentralized intelligence.

Algorithm:
  1. Group findings by semantic similarity (fuzzy text matching)
  2. For each cluster of similar findings:
     - Count independent sources (different engines/peers)
     - Apply Bayesian update: P(real) increases with each independent confirmation
     - Create a corroboration record linking them
  3. Feed corroboration data to Collision Engine and War Room

The key insight: if Alice's scanner and Bob's scanner independently find
the same Portal reentrancy risk, that's MUCH stronger evidence than either
alone — because it's unlikely two independent analyses would hallucinate
the same false positive.
"""

import json
import logging
import sqlite3
from difflib import SequenceMatcher

from core.persistence import connect

logger = logging.getLogger(__name__)

# Minimum similarity ratio to consider two findings as "about the same thing"
# 0.4 catches findings about the same issue described differently
SIMILARITY_THRESHOLD = 0.4

# Maximum findings to compare per run (O(n^2) so cap it)
MAX_FINDINGS_TO_COMPARE = 500


def _similarity(a: str, b: str) -> float:
    """Similarity score combining sequence matching and keyword overlap."""
    if not a or not b:
        return 0.0

    # Extract key terms (skip WHAT/SO WHAT/NOW WHAT boilerplate)
    def extract_key(text):
        """Extract the key content from a finding, stripping boilerplate."""
        what_end = text.find("SO WHAT:")
        if what_end > 0:
            return text[:what_end].replace("WHAT:", "").strip().lower()
        return text[:200].lower()

    key_a = extract_key(a)
    key_b = extract_key(b)

    # Method 1: Sequence similarity
    seq_sim = SequenceMatcher(None, key_a, key_b).ratio()

    # Method 2: Keyword overlap (Jaccard on significant words)
    # Strip folder-specific terms that differ between installations
    stop_words = {
        "the",
        "a",
        "an",
        "is",
        "are",
        "was",
        "in",
        "of",
        "to",
        "for",
        "and",
        "or",
        "that",
        "this",
        "with",
        "has",
        "have",
        "not",
        "from",
        "found",
        "detected",
        "missing",
        "could",
        "should",
        "would",
        "can",
    }
    words_a = {w for w in key_a.split() if len(w) > 2 and w not in stop_words}
    words_b = {w for w in key_b.split() if len(w) > 2 and w not in stop_words}

    if words_a and words_b:
        intersection = words_a & words_b
        union = words_a | words_b
        keyword_sim = len(intersection) / len(union) if union else 0.0
    else:
        keyword_sim = 0.0

    # Take the higher of the two methods
    return max(seq_sim, keyword_sim)


def _bayesian_combine(confidences: list[float]) -> float:
    """Combine multiple independent confidence estimates using Bayesian update.

    If two independent sources both say P(real) = 0.8, the combined
    probability is higher than 0.8 because it's unlikely both are wrong.

    Formula: P(real | multiple sources) using odds form:
      odds_combined = product(odds_i)
      where odds_i = P_i / (1 - P_i)
    """
    if not confidences:
        return 0.0
    if len(confidences) == 1:
        return confidences[0]

    # Clamp to avoid division by zero
    clamped = [max(0.01, min(0.99, c)) for c in confidences]

    # Convert to odds, multiply, convert back
    combined_odds = 1.0
    for c in clamped:
        combined_odds *= c / (1.0 - c)

    combined = combined_odds / (1.0 + combined_odds)
    return min(combined, 0.99)  # cap at 99%


def find_corroborations(db_path: str, domain: str = "") -> list[dict]:
    """Find groups of similar findings from independent sources.

    Returns list of corroboration records:
    {
        "finding_ids": [1, 5, 23],
        "sources": ["vuln_scanner", "peer:alice/alice_scanner", "peer:bob/bob_scan"],
        "individual_confidences": [0.85, 0.90, 0.75],
        "combined_confidence": 0.97,
        "representative_finding": "...",
        "source_count": 3,
    }
    """
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row

    try:
        query = """SELECT id, engine, finding, confidence, domain
                   FROM evidence
                   WHERE confidence > 0
                   ORDER BY timestamp DESC
                   LIMIT ?"""
        params = [MAX_FINDINGS_TO_COMPARE]

        if domain:
            query = """SELECT id, engine, finding, confidence, domain
                       FROM evidence
                       WHERE confidence > 0 AND domain = ?
                       ORDER BY timestamp DESC
                       LIMIT ?"""
            params = [domain, MAX_FINDINGS_TO_COMPARE]

        rows = conn.execute(query, params).fetchall()
    finally:
        conn.close()

    if len(rows) < 2:
        return []

    # Group by similarity
    clusters = []  # each cluster is a list of row dicts
    clustered = set()

    for i, row_a in enumerate(rows):
        if row_a["id"] in clustered:
            continue

        cluster = [dict(row_a)]
        clustered.add(row_a["id"])

        for j, row_b in enumerate(rows):
            if i == j or row_b["id"] in clustered:
                continue
            # Skip same engine (not independent)
            if row_a["engine"] == row_b["engine"]:
                continue

            sim = _similarity(row_a["finding"] or "", row_b["finding"] or "")
            if sim >= SIMILARITY_THRESHOLD:
                cluster.append(dict(row_b))
                clustered.add(row_b["id"])

        if len(cluster) >= 2:
            clusters.append(cluster)

    # Build corroboration records
    corroborations = []
    for cluster in clusters:
        sources = list({r["engine"] for r in cluster})
        confidences = [r["confidence"] for r in cluster]
        combined = _bayesian_combine(confidences)

        corroborations.append(
            {
                "finding_ids": [r["id"] for r in cluster],
                "sources": sources,
                "individual_confidences": confidences,
                "combined_confidence": round(combined, 4),
                "representative_finding": cluster[0]["finding"][:200],
                "source_count": len(sources),
                "domain": cluster[0]["domain"],
            }
        )

    # Sort by source count (most corroborated first)
    corroborations.sort(key=lambda c: (-c["source_count"], -c["combined_confidence"]))

    return corroborations


def apply_corroborations(db_path: str) -> int:
    """Find corroborations and update finding confidences + related_findings.

    For each corroboration cluster:
    - Update all findings in the cluster to the combined confidence
    - Link them via related_findings
    - Log the corroboration

    Returns count of findings updated.
    """
    corroborations = find_corroborations(db_path)
    if not corroborations:
        return 0

    conn = connect(db_path)
    updated = 0

    try:
        for corr in corroborations:
            ids = corr["finding_ids"]
            combined = corr["combined_confidence"]
            related = json.dumps(ids)

            for fid in ids:
                # Only boost confidence (never lower it)
                conn.execute(
                    """UPDATE evidence
                       SET confidence = MAX(confidence, ?),
                           related_findings = ?
                       WHERE id = ?""",
                    (combined, related, fid),
                )
                updated += 1

        conn.commit()
    finally:
        conn.close()

    if updated:
        logger.info(
            "Corroboration: %d clusters, %d findings updated (max combined conf: %.2f)",
            len(corroborations),
            updated,
            max(c["combined_confidence"] for c in corroborations),
        )

    return updated
