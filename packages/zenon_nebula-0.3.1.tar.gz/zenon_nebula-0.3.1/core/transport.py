# SPDX-License-Identifier: MIT
"""
Evidence Transport — Share findings between Nebula instances.

Three modes (set via NEBULA_TRANSPORT env var):
  - "local": No sharing. Findings stay on your machine. (default)
  - "shared": File-based sharing via a shared directory. All instances
    on the same machine (or shared filesystem) exchange findings.
  - "nexus": Real-time sharing via SpacetimeDB/Nexus. Requires Probe.

Usage:
    from core.transport import get_transport

    transport = get_transport(db_path="data/engine.db")
    transport.publish()   # share our findings
    transport.pull()      # get others' findings
"""

import hashlib
import json
import logging
import os
import secrets
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from core.persistence import connect
from core.trust import cap_confidence_by_trust, should_quarantine
from core.version import PROTOCOL_VERSION, get_version, is_compatible

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SHARED_DIR = ENGINE_ROOT / "data" / "shared_evidence"

# Private domains never shared
PRIVATE_DOMAINS = frozenset({"marketing", "investigation"})

# Min confidence to publish
MIN_PUBLISH_CONFIDENCE = 0.5


def get_transport(db_path: str, transport_type: str = "") -> "BaseTransport":
    """Factory: return the right transport based on env config."""
    mode = transport_type or os.environ.get("NEBULA_TRANSPORT", "local")

    if mode == "shared":
        shared_dir = os.environ.get("NEBULA_SHARED_DIR", str(DEFAULT_SHARED_DIR))
        participant = os.environ.get("NEBULA_PARTICIPANT_ID", "anonymous")
        return SharedDirTransport(db_path, shared_dir, participant)
    elif mode == "nexus":
        return NexusTransport(db_path)
    else:
        return LocalTransport(db_path)


_FINDING_HASH_CACHE: dict[str, bool] = {}


def _has_finding_hash_column(conn: sqlite3.Connection) -> bool:
    """Return True if the evidence table has a finding_hash column.

    Cached per-connection database so we don't re-run PRAGMA on every
    import row. The migration that adds finding_hash runs in
    core/persistence/schema.py::ensure_schema; if an operator is on a
    fresh install this returns True, on legacy installs False and we
    fall back to whole-text comparison.
    """
    try:
        cache_key = str(conn)
    except Exception:
        cache_key = ""
    if cache_key in _FINDING_HASH_CACHE:
        return _FINDING_HASH_CACHE[cache_key]
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(evidence)").fetchall()]
        present = "finding_hash" in cols
    except sqlite3.OperationalError:
        present = False
    _FINDING_HASH_CACHE[cache_key] = present
    return present


class BaseTransport:
    """Abstract base for evidence transport."""

    def __init__(self, db_path: str):
        self.db_path = db_path

    def publish(self) -> dict:
        """Publish local findings to the network. Returns stats."""
        return {"published": 0}

    def pull(self) -> dict:
        """Pull remote findings into local DB. Returns stats."""
        return {"imported": 0}

    def sync(self) -> dict:
        """Publish + pull in one call."""
        pub = self.publish()
        pull = self.pull()
        return {"publish": pub, "pull": pull}


class LocalTransport(BaseTransport):
    """No-op transport. Findings stay local."""

    pass


class SharedDirTransport(BaseTransport):
    """File-based transport for instances on the same machine.

    Each instance writes findings to a shared directory as JSON files.
    Other instances read and import findings they don't have yet.
    Deduplicates by (engine, finding_hash).
    """

    def __init__(self, db_path: str, shared_dir: str, participant_id: str = "anonymous"):
        super().__init__(db_path)
        self.shared_dir = Path(shared_dir)
        self.participant_id = participant_id
        self.shared_dir.mkdir(parents=True, exist_ok=True)

        # Per-instance nonce so two operators running with the default
        # participant_id="anonymous" don't shadow each other's files.
        # Without this, both instances would skip files starting with
        # "anonymous_" and silently fail to exchange findings. Persisted
        # under data/transport_instance_nonce so a restart preserves
        # identity.
        nonce_file = Path(db_path).parent / "transport_instance_nonce"
        try:
            if nonce_file.exists():
                self._instance_nonce = nonce_file.read_text(encoding="utf-8").strip()
            else:
                self._instance_nonce = secrets.token_hex(4)
                nonce_file.write_text(self._instance_nonce, encoding="utf-8")
        except OSError:
            self._instance_nonce = secrets.token_hex(4)
        self._file_prefix = f"{self.participant_id}_{self._instance_nonce}_"

    def publish(self) -> dict:
        """Write unpublished high-confidence findings to shared dir."""
        conn = connect(self.db_path)
        conn.row_factory = sqlite3.Row
        published = 0

        try:
            rows = conn.execute(
                """SELECT id, domain, engine, evidence_type, finding, confidence,
                          supports_hypothesis, contradicts_hypothesis, timestamp
                   FROM evidence
                   WHERE COALESCE(published, 0) = 0
                     AND confidence >= ?
                     AND domain NOT IN ({})
                   ORDER BY confidence DESC
                   LIMIT 100""".format(",".join(f"'{d}'" for d in PRIVATE_DOMAINS)),
                (MIN_PUBLISH_CONFIDENCE,),
            ).fetchall()

            if not rows:
                return {"published": 0}

            # OPSEC: every finding that leaves the local DB for a shared
            # directory MUST be run through sanitize_for_sharing. This
            # mirrors the snapshot export path (core/sync.py::_scrub_row)
            # and closes the same class of bug: a published row
            # containing a local /Users/ path or an identity reference
            # would be readable by every other participant on the shared
            # filesystem. Pre-v0.2.14, the SharedDirTransport path wrote
            # raw row["finding"] straight to disk. Snapshot export was
            # sanitized in v0.2.7; this is the parallel fix for transport.
            # If sanitize fails we REFUSE to publish rather than leak.
            from core.opsec import OPSECGuard

            batch = []
            ids_published = []
            nebula_version = get_version()
            for row in rows:
                try:
                    safe_finding = OPSECGuard.sanitize_for_sharing(
                        row["finding"] or "",
                        participant_id=self.participant_id,
                    )
                except Exception as exc:
                    logger.error(
                        "CRITICAL: transport sanitize_for_sharing failed "
                        "for evidence id=%s (%s). Skipping row.",
                        row["id"],
                        exc,
                    )
                    continue
                batch.append(
                    {
                        "source": self.participant_id,
                        "evidence_id": row["id"],
                        "domain": row["domain"],
                        "engine": row["engine"],
                        "evidence_type": row["evidence_type"],
                        "finding": safe_finding,
                        "confidence": row["confidence"],
                        "supports_hypothesis": row["supports_hypothesis"],
                        "contradicts_hypothesis": row["contradicts_hypothesis"],
                        "timestamp": row["timestamp"],
                        "published_at": datetime.now(timezone.utc).isoformat(),
                        # Version metadata so receivers can refuse payloads
                        # from incompatible protocol versions.
                        "protocol_version": PROTOCOL_VERSION,
                        "nebula_version": nebula_version,
                    }
                )
                ids_published.append(row["id"])

            # Write to shared dir with participant + nonce + timestamp
            # filename. The nonce disambiguates instances sharing the
            # same participant_id (e.g. the default "anonymous").
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f")
            outfile = self.shared_dir / f"{self._file_prefix}{ts}.json"
            outfile.write_text(json.dumps(batch, indent=2, default=str))

            # Mark as published
            for eid in ids_published:
                conn.execute("UPDATE evidence SET published = 1 WHERE id = ?", (eid,))
            conn.commit()
            published = len(ids_published)

        except Exception as exc:
            logger.warning("SharedDir publish failed: %s", exc)
        finally:
            conn.close()

        if published:
            logger.info("Published %d findings to shared dir", published)
        return {"published": published}

    def pull(self) -> dict:
        """Import findings from other participants in shared dir."""
        conn = connect(self.db_path)
        imported = 0
        duplicates = 0

        try:
            for f in sorted(self.shared_dir.glob("*.json")):
                # Skip our own files. Matching on the (participant+nonce)
                # prefix so two "anonymous" operators don't shadow
                # each other.
                if f.name.startswith(self._file_prefix):
                    continue

                try:
                    entries = json.loads(f.read_text())
                except (json.JSONDecodeError, OSError):
                    continue

                for entry in entries:
                    source = entry.get("source", "unknown")
                    finding_text = entry.get("finding", "")
                    if not finding_text:
                        continue

                    # Protocol compatibility check. Entries without
                    # version metadata are treated as legacy and accepted
                    # to preserve backward compatibility with pre-0.1.0
                    # snapshots. Entries with an explicit
                    # protocol_version must match ours exactly.
                    entry_proto = entry.get("protocol_version")
                    if entry_proto is not None and entry_proto != PROTOCOL_VERSION:
                        logger.debug(
                            "Skipping finding from %s: protocol %s != %s",
                            source,
                            entry_proto,
                            PROTOCOL_VERSION,
                        )
                        continue
                    entry_version = entry.get("nebula_version")
                    if entry_version and not is_compatible(entry_version):
                        logger.debug(
                            "Skipping finding from %s: version %s incompatible",
                            source,
                            entry_version,
                        )
                        continue

                    # Dedup: we import the finding if we don't already
                    # have an IDENTICAL copy. Near-matches are intentionally
                    # left alone so that apply_corroborations() can later
                    # cluster them and apply a Bayesian boost — that's the
                    # whole point of peer corroboration. Text-hash key
                    # (not SELECT ... WHERE finding = ?) so the dedup is
                    # stable even on very long findings.
                    finding_hash = hashlib.sha256((finding_text or "").encode("utf-8")).hexdigest()
                    existing = conn.execute(
                        "SELECT COUNT(*) FROM evidence WHERE finding_hash = ?"
                        if _has_finding_hash_column(conn)
                        else "SELECT COUNT(*) FROM evidence WHERE finding = ?",
                        (finding_hash if _has_finding_hash_column(conn) else finding_text,),
                    ).fetchone()[0]

                    if existing > 0:
                        duplicates += 1
                        continue

                    # Apply trust model — cap confidence for external sources
                    raw_conf = entry.get("confidence", 0.5)
                    capped_conf = cap_confidence_by_trust(raw_conf, f"peer:{source}")

                    # Quarantine check
                    if should_quarantine({"provenance": f"peer:{source}", "confidence": raw_conf}):
                        logger.debug("Quarantined finding from %s (conf=%.2f)", source, raw_conf)
                        continue

                    # Import
                    conn.execute(
                        """INSERT INTO evidence
                           (domain, engine, evidence_type, finding, confidence,
                            supports_hypothesis, contradicts_hypothesis,
                            provenance, published)
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)""",
                        (
                            entry.get("domain", "system"),
                            f"peer:{source}/{entry.get('engine', 'unknown')}",
                            entry.get("evidence_type", "external"),
                            finding_text,
                            capped_conf,
                            entry.get("supports_hypothesis", ""),
                            entry.get("contradicts_hypothesis", ""),
                            f"peer:{source}",
                        ),
                    )
                    imported += 1

            conn.commit()
        except Exception as exc:
            logger.warning("SharedDir pull failed: %s", exc)
        finally:
            conn.close()

        if imported:
            logger.info("Imported %d peer findings (%d duplicates)", imported, duplicates)
        return {"imported": imported, "duplicates": duplicates}


class NexusTransport(BaseTransport):
    """SpacetimeDB/Nexus transport for real-time cross-network sharing."""

    def __init__(self, db_path: str):
        super().__init__(db_path)
        self._bridge = None

    @property
    def bridge(self):
        """Lazy-loaded NexusEvidenceBridge instance."""
        if self._bridge is None:
            from core.integrations.nexus_evidence import NexusEvidenceBridge

            self._bridge = NexusEvidenceBridge(db_path=self.db_path)
        return self._bridge

    def publish(self) -> dict:
        """Publish verified evidence to Nexus and return count."""
        try:
            result = self.bridge.publish_verified_evidence()
            return {"published": result.get("published_count", 0)}
        except Exception as exc:
            logger.warning("Nexus publish failed: %s", exc)
            return {"published": 0, "error": str(exc)}

    def pull(self) -> dict:
        """Pull remote evidence from Nexus and return import count."""
        try:
            result = self.bridge.pull_remote_evidence()
            return {"imported": result.get("imported_count", 0)}
        except Exception as exc:
            logger.warning("Nexus pull failed: %s", exc)
            return {"imported": 0, "error": str(exc)}
