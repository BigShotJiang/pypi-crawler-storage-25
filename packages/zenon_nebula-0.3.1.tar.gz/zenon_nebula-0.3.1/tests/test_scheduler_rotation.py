# SPDX-License-Identifier: MIT
"""Pin the v0.3.1 multi-engine rotation in the scheduler.

Before v0.3.1 each domain could fire at most one engine per cycle. The
registry-level `decide_next_action(context, exclude)` was passing
`exclude` to its own wrapper loop but NOT threading it into the domain's
own `decide_next_action`, so every call to a domain returned the same
first-branch action and the registry just skipped it. Engines like
`spec_audit` and `curiosity_scanner` were registered in `get_engines()`
but never invoked by the autonomous loop.

The fix in `core/domain_registry.py` introspects each domain's
`decide_next_action` signature and passes `exclude` only to domains that
opt in. These tests pin both shapes:

- `DevelopmentDomain` now rotates through all 7 of its engines by
  draining the candidate list as the scheduler calls again with a
  growing exclude set.
- `InvestigationDomain` now rotates through all 4 of its engines
  (architecture_analyzer, vision_tracker, protocol_family_classifier,
  curiosity_scanner).
- Backward-compat: a mock domain whose `decide_next_action` does NOT
  accept `exclude` still works without error — the registry detects
  the narrower signature and calls it the old way.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainPlugin, DomainRegistry, EngineDefinition
from domains.development.domain import DevelopmentDomain
from domains.investigation.domain import InvestigationDomain


class _LegacyDomain(DomainPlugin):
    """A minimal domain whose decide_next_action does NOT accept exclude.

    Used by the backward-compat test to confirm the registry doesn't
    crash when a subclass still has the old signature. This is the
    shape every v0.2.x domain uses and we must not break those.
    """

    def name(self) -> str:
        return "legacy"

    def get_engines(self) -> list[EngineDefinition]:
        return [
            EngineDefinition(
                name="legacy_engine",
                description="legacy",
                module_path="domains.legacy.engines.legacy_engine",
            )
        ]

    def get_hypothesis_types(self) -> list:
        return []

    def get_aspiration_types(self) -> list:
        return []

    def get_collision_signals(self) -> list:
        return []

    def get_war_room_contributions(self) -> list:
        return []

    def get_self_improvement_metrics(self) -> dict[str, float]:
        return {}

    def get_db_schema_sql(self) -> str:
        return ""

    def decide_next_action(self, context: dict) -> dict | None:
        """Old signature — no exclude parameter."""
        return {
            "action": "legacy_action",
            "reason": "legacy",
            "priority": 1,
            "engine": "legacy_engine",
        }


@pytest.fixture(autouse=True)
def reset_registry():
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


class TestDevelopmentDomainRotation:
    """v0.3.1 DevelopmentDomain rotates through all its engines."""

    def test_first_call_returns_first_candidate(self):
        dom = DevelopmentDomain()
        action = dom.decide_next_action(
            {"trigger_level": "routine", "stale_data": []},
            exclude=set(),
        )
        assert action is not None
        assert action["engine"] == "dependency_chain"

    def test_rotation_drains_all_engines(self):
        """Calling with a growing exclude set yields every engine in turn.

        The exact order doesn't matter as long as every engine the
        domain registers eventually shows up. This is what unlocks
        spec_audit in the autonomous loop.
        """
        dom = DevelopmentDomain()
        exclude: set[str] = set()
        context = {"trigger_level": "routine", "stale_data": []}
        seen_engines: set[str] = set()

        while True:
            action = dom.decide_next_action(context, exclude=exclude)
            if action is None:
                break
            seen_engines.add(action["engine"])
            exclude.add(f"development:{action['action']}")

        assert "dependency_chain" in seen_engines
        assert "spec_audit" in seen_engines
        assert "spec_drift" in seen_engines
        assert "upstream_monitor" in seen_engines
        assert "impl_coverage" in seen_engines
        assert "spec_tracker" in seen_engines
        assert "btc_spec_tracker" in seen_engines

    def test_urgent_trigger_still_wins(self):
        """Urgent branch remains first in the candidate list."""
        dom = DevelopmentDomain()
        action = dom.decide_next_action(
            {"trigger_level": "urgent", "stale_data": []},
            exclude=set(),
        )
        assert action is not None
        assert action["engine"] == "upstream_monitor"
        assert action["action"] == "check_upstream_impacts"


class TestInvestigationDomainRotation:
    """v0.3.1 InvestigationDomain rotates and includes curiosity_scanner."""

    def test_first_call_returns_architecture_analyzer(self):
        dom = InvestigationDomain()
        action = dom.decide_next_action({}, exclude=set())
        assert action is not None
        assert action["engine"] == "architecture_analyzer"

    def test_rotation_yields_curiosity_scanner(self):
        """curiosity_scanner was dead pre-v0.3.1 — pin that it now fires."""
        dom = InvestigationDomain()
        exclude: set[str] = set()
        seen_engines: set[str] = set()

        while True:
            action = dom.decide_next_action({}, exclude=exclude)
            if action is None:
                break
            seen_engines.add(action["engine"])
            exclude.add(f"investigation:{action['action']}")

        assert seen_engines == {
            "architecture_analyzer",
            "vision_tracker",
            "protocol_family_classifier",
            "curiosity_scanner",
        }


class TestRegistryBackwardCompat:
    """Domains with the old single-parameter signature still work."""

    def test_legacy_domain_without_exclude_param_survives(self):
        registry = DomainRegistry.instance()
        registry.register(_LegacyDomain())

        action = registry.decide_next_action({}, exclude=set())
        assert action is not None
        assert action["domain"] == "legacy"
        assert action["engine"] == "legacy_engine"

    def test_legacy_domain_second_call_returns_none(self):
        """After one action, the exclude set filters the legacy domain out.

        This mirrors the pre-v0.3.1 behavior for domains that haven't
        opted into rotation — they get one turn per cycle.
        """
        registry = DomainRegistry.instance()
        registry.register(_LegacyDomain())

        exclude = {"legacy:legacy_action"}
        action = registry.decide_next_action({}, exclude=exclude)
        assert action is None
