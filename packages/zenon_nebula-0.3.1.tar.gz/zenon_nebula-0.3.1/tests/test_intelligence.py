# SPDX-License-Identifier: MIT
"""Tests for the Intelligence domain plugin and its engines."""

import json
import os
import sqlite3

# Ensure engine root is on sys.path
import sys
import tempfile
from pathlib import Path

import pytest

ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

from core.domain_registry import DomainRegistry
from core.feedback_bus import FeedbackBus
from domains.intelligence.domain import IntelligenceDomain
from domains.intelligence.engines.ecosystem_health import (
    _count_go_zenon_definitions,
    _count_specs,
    _count_wiki_pages,
    collect_metrics_from_local,
    get_health_summary,
)
from domains.intelligence.engines.signal_detector import (
    classify_signal,
    get_unprocessed_signals,
)
from domains.intelligence.engines.signal_router import (
    get_routing_table,
    route_all,
    route_signal,
)
from domains.intelligence.engines.upstream_watcher import (
    classify_commit,
    get_new_commits,
    scan_repo,
)

# -- Fixtures --


@pytest.fixture(autouse=True)
def reset_registry():
    """Reset the DomainRegistry singleton between tests."""
    DomainRegistry.reset()
    yield
    DomainRegistry.reset()


@pytest.fixture
def tmp_db():
    """Create a temporary database with required schemas."""
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name

    conn = sqlite3.connect(db_path)
    domain = IntelligenceDomain()
    conn.executescript(domain.get_db_schema_sql())

    # Also create feedback_bus table
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS feedback_bus (
            id TEXT PRIMARY KEY,
            sender TEXT NOT NULL,
            recipient TEXT NOT NULL,
            domain TEXT NOT NULL DEFAULT 'system',
            type TEXT NOT NULL,
            data TEXT NOT NULL DEFAULT '{}',
            timestamp TEXT NOT NULL,
            acknowledged BOOLEAN NOT NULL DEFAULT 0,
            acknowledged_at TEXT,
            acknowledged_by TEXT
        );
    """)
    conn.commit()
    conn.close()

    yield db_path

    os.unlink(db_path)


# -- Domain registration tests --


class TestIntelligenceDomainRegistration:
    """Test that IntelligenceDomain registers correctly."""

    def test_domain_name(self):
        domain = IntelligenceDomain()
        assert domain.name() == "intelligence"

    def test_domain_registers_with_registry(self):
        registry = DomainRegistry.instance()
        domain = IntelligenceDomain()
        registry.register(domain)

        assert "intelligence" in registry.get_domain_names()
        retrieved = registry.get_domain("intelligence")
        assert retrieved is domain

    def test_domain_engines_count(self):
        domain = IntelligenceDomain()
        engines = domain.get_engines()
        assert len(engines) == 5
        names = {e.name for e in engines}
        assert "upstream_watcher" in names
        assert "signal_detector" in names
        assert "signal_router" in names
        assert "ecosystem_health" in names
        assert "repo_relationship_mapper" in names

    def test_domain_hypothesis_types(self):
        domain = IntelligenceDomain()
        types = domain.get_hypothesis_types()
        assert len(types) >= 2
        type_ids = {t.type_id for t in types}
        assert "ecosystem_trend" in type_ids
        assert "breaking_change_impact" in type_ids

    def test_domain_db_schema(self):
        domain = IntelligenceDomain()
        sql = domain.get_db_schema_sql()
        assert "intelligence_signals" in sql
        assert "ecosystem_metrics" in sql

    def test_domain_priority(self):
        domain = IntelligenceDomain()
        assert domain.get_priority() == 2  # Critical

    def test_decide_next_action_urgent(self):
        domain = IntelligenceDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "urgent",
                "stale_data": ["upstream_commits"],
            }
        )
        assert action is not None
        assert action["engine"] == "upstream_watcher"

    def test_decide_next_action_routine(self):
        domain = IntelligenceDomain()
        action = domain.decide_next_action(
            {
                "trigger_level": "routine",
                "stale_data": [],
            }
        )
        assert action is not None
        assert action["engine"] == "signal_detector"

    def test_duplicate_registration_raises(self):
        registry = DomainRegistry.instance()
        registry.register(IntelligenceDomain())
        with pytest.raises(ValueError):
            registry.register(IntelligenceDomain())


# -- Upstream watcher tests --


class TestUpstreamWatcher:
    """Test the upstream watcher engine."""

    def test_classify_commit_feature(self):
        tags = classify_commit("feat: add new embedded contract")
        assert "new_feature" in tags

    def test_classify_commit_bugfix(self):
        tags = classify_commit("fix: correct plasma calculation")
        assert "bug_fix" in tags

    def test_classify_commit_spec(self):
        tags = classify_commit("update specification for PTLC")
        assert "spec_change" in tags

    def test_classify_commit_breaking(self):
        tags = classify_commit("breaking: remove deprecated API")
        assert "breaking_change" in tags

    def test_classify_commit_security(self):
        tags = classify_commit("fix vulnerability in bridge signing")
        assert "security_relevant" in tags

    def test_classify_commit_general(self):
        tags = classify_commit("update CI pipeline")
        assert "general_change" in tags

    def test_classify_commit_multiple_tags(self):
        tags = classify_commit(
            "fix security vulnerability in spec implementation",
        )
        assert "security_relevant" in tags
        assert "bug_fix" in tags

    def test_get_new_commits_on_real_repo(self):
        """Test get_new_commits on an actual Zenon repo."""
        repo = Path(ENGINE_ROOT).parents[1] / "core" / "go-zenon"
        if not repo.is_dir():
            pytest.skip("go-zenon not found at expected path")

        commits = get_new_commits(str(repo), max_commits=5)
        assert isinstance(commits, list)
        if commits:
            assert "hash" in commits[0]
            assert "message" in commits[0]
            assert "author" in commits[0]

    def test_scan_repo_persists_signals(self, tmp_db):
        """Test that scan_repo persists signals to the DB."""
        repo = Path(ENGINE_ROOT).parents[1] / "core" / "go-zenon"
        if not repo.is_dir():
            pytest.skip("go-zenon not found at expected path")

        signals = scan_repo("go-zenon", str(repo), db_path=tmp_db)
        # Should produce signals (repo has commits)
        assert isinstance(signals, list)

        # Check that signals were persisted
        conn = sqlite3.connect(tmp_db)
        count = conn.execute("SELECT COUNT(*) FROM intelligence_signals").fetchone()[0]
        conn.close()
        # count >= 0 is always true, but if we got signals they should be persisted
        if signals:
            assert count > 0


# -- Signal detector tests --


class TestSignalDetector:
    """Test the signal detector engine."""

    def test_classify_signal_spec_change(self):
        signal = {
            "id": 1,
            "source": "go-zenon:/path",
            "signal_type": "spec_change",
            "details": json.dumps(
                {
                    "message": "update ptlc spec",
                    "files_changed": ["vm/embedded/definition/ptlc.go"],
                    "tags": ["spec_change"],
                }
            ),
        }
        result = classify_signal(signal)
        assert "spec_change" in result["classifications"]
        assert "development" in result["domains"]

    def test_classify_signal_security(self):
        signal = {
            "id": 2,
            "source": "go-zenon:/path",
            "signal_type": "security_relevant",
            "details": json.dumps(
                {
                    "message": "fix crypto signing",
                    "files_changed": ["crypto/sign.go"],
                    "tags": ["security_relevant"],
                }
            ),
        }
        result = classify_signal(signal)
        assert "security_relevant" in result["classifications"]
        assert result["primary_domain"] == "security"

    def test_classify_signal_governance(self):
        signal = {
            "id": 3,
            "source": "go-zenon:/path",
            "signal_type": "new_feature",
            "details": json.dumps(
                {
                    "message": "add governance voting",
                    "files_changed": ["vm/embedded/implementation/governance.go"],
                    "tags": ["new_feature"],
                }
            ),
        }
        result = classify_signal(signal)
        assert "governance_related" in result["classifications"]
        assert "governance" in result["domains"]

    def test_get_unprocessed_signals_empty(self, tmp_db):
        signals = get_unprocessed_signals(tmp_db)
        assert signals == []


# -- Signal router tests --


class TestSignalRouter:
    """Test the signal router engine."""

    def test_routing_table_has_all_types(self):
        table = get_routing_table()
        assert "spec_change" in table
        assert "breaking_change" in table
        assert "new_feature" in table
        assert "security_relevant" in table

    def test_route_signal_to_development(self, tmp_db):
        bus = FeedbackBus(tmp_db)
        signal = {
            "signal_id": 1,
            "classifications": ["spec_change"],
            "primary_domain": "development",
            "domains": ["development", "standards"],
            "details": {
                "repo": "go-zenon",
                "commit_hash": "abc123",
                "message": "update spec",
            },
        }
        msg_ids = route_signal(signal, bus)
        assert len(msg_ids) >= 2  # development + standards at minimum

        # Check messages on the bus
        dev_msgs = bus.read("domain.development")
        assert len(dev_msgs) >= 1
        assert dev_msgs[0]["data"]["source_repo"] == "go-zenon"

    def test_route_signal_to_security(self, tmp_db):
        bus = FeedbackBus(tmp_db)
        signal = {
            "signal_id": 2,
            "classifications": ["security_relevant", "breaking_change"],
            "primary_domain": "security",
            "domains": ["security", "development"],
            "details": {
                "repo": "go-zenon",
                "commit_hash": "def456",
                "message": "fix bridge vulnerability",
            },
        }
        msg_ids = route_signal(signal, bus)
        assert len(msg_ids) >= 2

        sec_msgs = bus.read("domain.security")
        assert len(sec_msgs) >= 1

    def test_route_all_aggregates_counts(self, tmp_db):
        signals = [
            {
                "signal_id": 1,
                "classifications": ["spec_change"],
                "domains": ["development"],
                "details": {"repo": "go-zenon"},
            },
            {
                "signal_id": 2,
                "classifications": ["new_feature"],
                "domains": ["development", "marketing"],
                "details": {"repo": "syrius"},
            },
        ]
        counts = route_all(signals, db_path=tmp_db)
        assert "development" in counts
        assert counts["development"] >= 2


# -- Ecosystem health tests --


class TestEcosystemHealth:
    """Test the ecosystem health engine."""

    def test_count_specs(self):
        """Verify spec counting finds real specs."""
        count = _count_specs()
        # We know there are at least several spec directories
        assert count >= 5, f"Expected at least 5 specs, found {count}"

    def test_count_go_zenon_definitions(self):
        """Verify go-zenon definition counting."""
        count = _count_go_zenon_definitions()
        # core/go-zenon has many definition files
        assert count >= 10, f"Expected at least 10 definitions, found {count}"

    def test_count_wiki_pages(self):
        """Verify wiki page counting."""
        count = _count_wiki_pages()
        assert count >= 5, f"Expected at least 5 wiki pages, found {count}"

    def test_collect_local_metrics(self, tmp_db):
        """Test local metric collection persists to DB."""
        metrics = collect_metrics_from_local(tmp_db)
        assert "total_repos" in metrics
        assert "spec_count" in metrics
        assert "embedded_contracts" in metrics
        assert metrics["spec_count"] >= 5

        # Verify persistence
        summary = get_health_summary(tmp_db)
        assert "spec_count" in summary
        assert summary["spec_count"]["value"] >= 5

    def test_health_summary_empty_db(self, tmp_db):
        """Health summary should return empty dict on fresh DB."""
        summary = get_health_summary(tmp_db)
        assert isinstance(summary, dict)
