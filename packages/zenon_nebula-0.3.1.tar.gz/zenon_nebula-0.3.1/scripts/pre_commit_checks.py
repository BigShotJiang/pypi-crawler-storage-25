#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Nebula pre-commit checks — catches AI-hallucination failure modes.

Runs a battery of fast, deterministic checks over the Python source tree
and exits non-zero on any failure. Safe to run standalone:

    python3 scripts/pre_commit_checks.py

Also invoked by .pre-commit-config.yaml when users install the pre-commit
package. No external dependencies — stdlib only — so it works on a fresh
clone before `pip install` has even run.

Checks (each is a separate function so the report is legible):

    1. No absolute local paths (/Users/, /home/, /root/, /private/var/)
    2. No placeholder text (pass # TODO, raise NotImplementedError, etc.)
    3. No hardcoded secrets (sk-, xai-, ghp_, gho_, AKIA, ...)
    4. No datetime.utcnow() (deprecated in Python 3.12+)
    5. No bare except: or silent `except Exception: pass`
    6. All imports resolve to real modules
    7. All .py files compile (py_compile)

The goal is to fail fast and loud on the mistakes that AI-generated code
tends to make, so they never reach `main`.
"""

from __future__ import annotations

import ast
import importlib.util
import os
import py_compile
import re
import sys
from collections.abc import Iterable
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).resolve().parent.parent

# The checker script itself contains every pattern it searches for (regexes,
# examples in the docstring). It must be skipped from content-based checks
# or it will always flag itself. Compile and import checks still run.
SELF_PATH = Path(__file__).resolve()

# Directories we never scan. Tests are scanned with relaxed rules; see below.
EXCLUDE_DIRS = {
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "env",
    "node_modules",
    "site",  # mkdocs build output
    "data",  # runtime databases
    "logs",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
}

# Files where test fixtures may legitimately contain local paths,
# placeholder strings, etc. They still get compile + import checks.
TEST_DIR_NAMES = {"tests", "test"}

LOCAL_PATH_PATTERNS = [
    re.compile(r"/Users/[A-Za-z0-9_.-]+"),
    re.compile(r"/home/[A-Za-z0-9_.-]+"),
    re.compile(r"/root/"),
    re.compile(r"/private/var/"),
]

SECRET_PATTERNS = [
    # API keys — only match strings that actually look like real secrets.
    re.compile(r"\bsk-[A-Za-z0-9]{20,}"),
    re.compile(r"\bxai-[A-Za-z0-9]{20,}"),
    re.compile(r"\bghp_[A-Za-z0-9]{20,}"),
    re.compile(r"\bgho_[A-Za-z0-9]{20,}"),
    re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
]

PLACEHOLDER_PATTERNS = [
    re.compile(r"^\s*pass\s*#\s*TODO", re.IGNORECASE),
    re.compile(r"raise\s+NotImplementedError"),
    re.compile(r"#\s*implement\s+later", re.IGNORECASE),
    re.compile(r"#\s*FIXME\s*:?\s*later", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------


def iter_python_files(root: Path) -> Iterable[Path]:
    """Yield every .py file under root, skipping EXCLUDE_DIRS."""
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for name in filenames:
            if name.endswith(".py"):
                yield Path(dirpath) / name


def is_test_file(path: Path) -> bool:
    parts = set(path.parts)
    if parts & TEST_DIR_NAMES:
        return True
    return path.name.startswith("test_") or path.name.endswith("_test.py")


def is_self(path: Path) -> bool:
    """True for the checker script itself. It legitimately contains every
    pattern it searches for, so content-based checks must skip it."""
    try:
        return path.resolve() == SELF_PATH
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Individual checks. Each returns a list of (path, line, message) failures.
# ---------------------------------------------------------------------------

Failure = tuple[Path, int, str]


def check_local_paths(files: list[Path]) -> list[Failure]:
    failures: list[Failure] = []
    for path in files:
        if is_test_file(path) or is_self(path):
            continue  # tests may reference local path fixtures; self defines patterns
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for lineno, line in enumerate(text.splitlines(), start=1):
            for pat in LOCAL_PATH_PATTERNS:
                if pat.search(line):
                    failures.append((path, lineno, f"local path leak: {line.strip()[:120]}"))
                    break
    return failures


def check_placeholders(files: list[Path]) -> list[Failure]:
    failures: list[Failure] = []
    for path in files:
        if is_test_file(path) or is_self(path):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for lineno, line in enumerate(text.splitlines(), start=1):
            for pat in PLACEHOLDER_PATTERNS:
                if pat.search(line):
                    failures.append((path, lineno, f"placeholder: {line.strip()[:120]}"))
                    break
    return failures


def check_secrets(files: list[Path]) -> list[Failure]:
    failures: list[Failure] = []
    for path in files:
        # Tests legitimately contain fake credentials as OPSEC fixtures.
        # The checker script itself contains the match patterns.
        if is_test_file(path) or is_self(path):
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for lineno, line in enumerate(text.splitlines(), start=1):
            for pat in SECRET_PATTERNS:
                if pat.search(line):
                    failures.append((path, lineno, "possible hardcoded secret"))
                    break
    return failures


def check_utcnow(files: list[Path]) -> list[Failure]:
    """Flag real `datetime.utcnow()` *calls*, not mere string mentions.

    Uses AST so that rule descriptions and regex patterns that contain the
    word `utcnow` in docstrings or string literals don't trip the check.
    """
    failures: list[Failure] = []
    for path in files:
        if is_self(path):
            continue  # this file defines the pattern
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        except (SyntaxError, OSError):
            continue  # compile check will catch this
        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            func = node.func
            name = None
            if isinstance(func, ast.Attribute):
                name = func.attr
            elif isinstance(func, ast.Name):
                name = func.id
            if name == "utcnow":
                failures.append(
                    (
                        path,
                        node.lineno,
                        "utcnow() is deprecated; use datetime.now(timezone.utc)",
                    )
                )
    return failures


def check_bare_excepts(files: list[Path]) -> list[Failure]:
    """Flag `except:` and `except Exception: pass` in production code."""
    failures: list[Failure] = []
    for path in files:
        if is_test_file(path):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        except (SyntaxError, OSError):
            continue  # compile check will catch this
        for node in ast.walk(tree):
            if not isinstance(node, ast.ExceptHandler):
                continue
            # Bare except: no type at all.
            if node.type is None:
                failures.append((path, node.lineno, "bare `except:` — name the exception"))
                continue
            # except Exception: pass (single pass statement, no handling)
            if (
                isinstance(node.type, ast.Name)
                and node.type.id in {"Exception", "BaseException"}
                and len(node.body) == 1
                and isinstance(node.body[0], ast.Pass)
            ):
                failures.append(
                    (
                        path,
                        node.lineno,
                        f"silent `except {node.type.id}: pass` — log or re-raise",
                    )
                )
    return failures


def check_imports(files: list[Path]) -> list[Failure]:
    """
    For every `import X` / `from X import …` in production code, verify
    that `X` is resolvable. We only fail for imports that look like they
    point at local packages (no dots in the name → stdlib or local, which
    we can check via importlib). External packages listed in requirements
    may not be installed in the checker environment, so we skip any name
    whose top-level package is not in stdlib and not in the repo.
    """
    failures: list[Failure] = []
    stdlib = set(sys.stdlib_module_names)
    # Discover local top-level packages by walking the repo.
    local_pkgs: set[str] = set()
    for entry in REPO_ROOT.iterdir():
        if entry.is_dir() and (entry / "__init__.py").exists():
            local_pkgs.add(entry.name)
        if entry.is_file() and entry.suffix == ".py":
            local_pkgs.add(entry.stem)

    for path in files:
        if is_test_file(path):
            continue
        try:
            tree = ast.parse(path.read_text(encoding="utf-8", errors="replace"))
        except (SyntaxError, OSError):
            continue
        for node in ast.walk(tree):
            names: list[tuple[str, int]] = []
            if isinstance(node, ast.Import):
                for alias in node.names:
                    names.append((alias.name, node.lineno))
            elif isinstance(node, ast.ImportFrom):
                if node.level and node.level > 0:
                    continue  # relative imports — assume correct
                if node.module:
                    names.append((node.module, node.lineno))
            for name, lineno in names:
                top = name.split(".", 1)[0]
                if top in stdlib:
                    continue
                if top in local_pkgs:
                    # Do a deeper check for the full dotted path.
                    spec = None
                    try:
                        spec = importlib.util.find_spec(name)
                    except (ModuleNotFoundError, ValueError, ImportError):
                        spec = None
                    if spec is None:
                        # The top-level package exists locally but the
                        # specific submodule does not resolve. Only flag
                        # if the submodule does not exist on disk either.
                        dotted_path = REPO_ROOT / Path(*name.split("."))
                        if not (
                            dotted_path.with_suffix(".py").exists()
                            or (dotted_path / "__init__.py").exists()
                        ):
                            failures.append(
                                (
                                    path,
                                    lineno,
                                    f"import of nonexistent local module: {name}",
                                )
                            )
                    continue
                # Third-party package: skip — we can't verify without
                # installing the full requirements set.
    return failures


def check_compiles(files: list[Path]) -> list[Failure]:
    failures: list[Failure] = []
    for path in files:
        try:
            py_compile.compile(str(path), doraise=True)
        except py_compile.PyCompileError as exc:
            failures.append((path, 0, f"does not compile: {exc.msg.strip()}"))
        except OSError as exc:
            failures.append((path, 0, f"cannot read: {exc}"))
    return failures


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


CHECKS = [
    ("no local paths", check_local_paths),
    ("no placeholders", check_placeholders),
    ("no hardcoded secrets", check_secrets),
    ("no utcnow()", check_utcnow),
    ("no bare excepts", check_bare_excepts),
    ("imports resolve", check_imports),
    ("all files compile", check_compiles),
]


def format_failure(f: Failure) -> str:
    path, lineno, msg = f
    rel = path.relative_to(REPO_ROOT) if path.is_absolute() else path
    loc = f"{rel}:{lineno}" if lineno else str(rel)
    return f"  {loc}: {msg}"


def main() -> int:
    files = list(iter_python_files(REPO_ROOT))
    if not files:
        print("no Python files found — nothing to check", file=sys.stderr)
        return 0

    print(f"nebula pre-commit: scanning {len(files)} Python files")

    total_failures = 0
    for name, check in CHECKS:
        failures = check(files)
        if failures:
            total_failures += len(failures)
            print(f"\nFAIL [{name}] — {len(failures)} issue(s):")
            for f in failures[:50]:
                print(format_failure(f))
            if len(failures) > 50:
                print(f"  ... and {len(failures) - 50} more")
        else:
            print(f"  ok   [{name}]")

    if total_failures:
        print(f"\n{total_failures} total issue(s) — commit blocked.")
        return 1

    print("\nall pre-commit checks passed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
