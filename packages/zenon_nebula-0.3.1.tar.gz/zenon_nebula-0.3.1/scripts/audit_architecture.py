#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Architecture audit — enforces structural rules across the Nebula codebase.

Run as ``python3 scripts/audit_architecture.py`` from the repo root or
any subdirectory. Exits 0 when the codebase is clean, 1 when any rule
is violated. Intended to be wired into CI so regressions are blocked
at push time.

Enforced rules:
    R1. No imports from ``domains.*`` inside ``core/*.py`` (core is
        the framework; domains are plugins).
    R2. No engine-to-engine imports inside a single domain
        (``domains.X.engines.Y`` must not import from
        ``domains.X.engines.Z``; extract shared code to
        ``domains.X.shared``).
    R3. No hardcoded ``/Users/`` or ``/home/`` absolute paths in
        production code (tests and docs are exempt).
    R4. No bare ``except:`` and no ``except Exception: pass`` inside
        ``core/*.py`` or ``domains/*/engines/*.py`` (errors must be
        logged or re-raised).
    R5. No ``datetime.utcnow()`` anywhere — use
        ``datetime.now(timezone.utc)``.
    R6. Every file in ``core/`` has a module docstring.
    R7. Every public (non-underscore) function in ``core/`` has a
        docstring.

The audit parses each file with ``ast`` so it is robust against
comments and string literals that would confuse a plain regex sweep.
"""

from __future__ import annotations

import ast
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path

NEBULA_ROOT = Path(__file__).resolve().parents[1]
CORE_DIR = NEBULA_ROOT / "core"
DOMAINS_DIR = NEBULA_ROOT / "domains"
SCRIPTS_DIR = NEBULA_ROOT / "scripts"
TESTS_DIR = NEBULA_ROOT / "tests"

RULE_LABELS = {
    "R1": "No core -> domains imports",
    "R2": "No engine-to-engine imports inside a domain",
    "R3": "No hardcoded /Users/ or /home/ paths in production code",
    "R4": "No bare `except:` or `except Exception: pass`",
    "R5": "No datetime.utcnow() usage",
    "R6": "Every core/ file has a module docstring",
    "R7": "Every public function in core/ has a docstring",
    "R8": "No bare sqlite3.connect() outside core/persistence (use core.persistence.connect)",
}


@dataclass
class Finding:
    """Single architecture-audit violation."""

    rule: str
    path: Path
    line: int
    message: str


@dataclass
class AuditReport:
    """Accumulator for audit findings."""

    findings: list[Finding] = field(default_factory=list)
    files_checked: int = 0

    def add(self, rule: str, path: Path, line: int, message: str) -> None:
        """Record a single finding."""
        self.findings.append(Finding(rule, path, line, message))

    @property
    def ok(self) -> bool:
        """Return True when no violations were found."""
        return not self.findings


# -------------------------------------------------------------------------
# File discovery
# -------------------------------------------------------------------------


def _iter_py_files(root: Path) -> list[Path]:
    """Yield every .py file under root, skipping caches and vendored dirs."""
    skip_parts = {"__pycache__", ".venv", "venv", "site", ".git"}
    out = []
    for p in root.rglob("*.py"):
        if any(part in skip_parts for part in p.parts):
            continue
        out.append(p)
    return sorted(out)


def _rel(path: Path) -> Path:
    """Return path relative to NEBULA_ROOT for tidy reporting."""
    try:
        return path.relative_to(NEBULA_ROOT)
    except ValueError:
        return path


# -------------------------------------------------------------------------
# AST-based rule checks
# -------------------------------------------------------------------------


def _parse(path: Path) -> tuple[ast.Module | None, str]:
    """Return (ast, source_text) — None if the file cannot be parsed."""
    try:
        source = path.read_text(encoding="utf-8")
    except OSError:
        return None, ""
    try:
        return ast.parse(source, filename=str(path)), source
    except SyntaxError:
        return None, source


def _module_name_from_import(node: ast.AST) -> list[str]:
    """Return the module names referenced by an Import/ImportFrom node."""
    if isinstance(node, ast.Import):
        return [alias.name for alias in node.names]
    if isinstance(node, ast.ImportFrom) and node.module:
        return [node.module]
    return []


def _check_r1_core_to_domains(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R1: core modules may not import from domains.*."""
    if CORE_DIR not in path.parents and path != CORE_DIR:
        return
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for module in _module_name_from_import(node):
                if module == "domains" or module.startswith("domains."):
                    report.add(
                        "R1",
                        path,
                        node.lineno,
                        f"core module imports from {module!r}",
                    )


def _check_r2_engine_to_engine(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R2: an engine file cannot import from a peer engine in the same domain."""
    parts = path.relative_to(NEBULA_ROOT).parts
    if len(parts) < 4 or parts[0] != "domains" or parts[2] != "engines":
        return
    domain_name = parts[1]
    own_module = path.stem
    engines_prefix = f"domains.{domain_name}.engines."
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for module in _module_name_from_import(node):
                if not module.startswith(engines_prefix):
                    continue
                peer = module[len(engines_prefix) :].split(".", 1)[0]
                if peer and peer != own_module:
                    report.add(
                        "R2",
                        path,
                        node.lineno,
                        (
                            f"engine {own_module!r} imports from peer engine "
                            f"{peer!r} — extract shared code to "
                            f"domains/{domain_name}/shared.py"
                        ),
                    )


_BAD_PATH_RE = re.compile(r'["\'](/Users/|/home/)[^"\']*["\']')

# Files that legitimately embed /Users/ or /home/ as regex patterns —
# they EXIST to detect and scrub hardcoded paths, and must keep the
# literals. Audit these at the point of origin instead.
_R3_EXEMPT = {
    Path("core/commons.py"),
    Path("core/opsec.py"),
    Path("domains/contribution/engines/pr_readiness.py"),
    Path("scripts/pre_commit_checks.py"),
    Path("scripts/audit_architecture.py"),
}


def _check_r3_hardcoded_paths(report: AuditReport, path: Path, source: str) -> None:
    """R3: no hardcoded /Users/ or /home/ paths in production code."""
    if TESTS_DIR in path.parents or path == TESTS_DIR:
        return
    rel = _rel(path)
    if rel in _R3_EXEMPT:
        return
    for lineno, line in enumerate(source.splitlines(), start=1):
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        if _BAD_PATH_RE.search(line):
            report.add(
                "R3",
                path,
                lineno,
                f"hardcoded absolute path: {line.strip()[:80]}",
            )


def _check_r4_bare_except(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R4: no bare except or ``except Exception: pass`` in core/engines."""
    # Only enforce inside core/ and inside engine files.
    in_scope = (CORE_DIR in path.parents) or (
        DOMAINS_DIR in path.parents and "engines" in path.parts
    )
    if not in_scope:
        return
    for node in ast.walk(tree):
        if not isinstance(node, ast.ExceptHandler):
            continue
        # Bare `except:`
        if node.type is None:
            report.add(
                "R4",
                path,
                node.lineno,
                "bare `except:` — catch a specific exception or log",
            )
            continue
        # `except Exception: pass` (or the equivalent with only `pass`)
        is_exception_catchall = isinstance(node.type, ast.Name) and node.type.id == "Exception"
        only_pass = len(node.body) == 1 and isinstance(node.body[0], ast.Pass)
        if is_exception_catchall and only_pass:
            report.add(
                "R4",
                path,
                node.lineno,
                "`except Exception: pass` silently swallows errors — log or re-raise",
            )


def _check_r5_utcnow(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R5: datetime.utcnow() is banned anywhere in the tree.

    Checks AST call nodes so docstrings, comments, and regex patterns
    that merely mention ``utcnow`` do not trigger false positives.
    """
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        # Matches ``datetime.utcnow()`` where ``datetime`` is either the
        # module or the class. Either attribute chain is banned.
        if isinstance(func, ast.Attribute) and func.attr == "utcnow":
            report.add(
                "R5",
                path,
                node.lineno,
                "datetime.utcnow() — use datetime.now(timezone.utc) instead",
            )


def _check_r6_module_docstring(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R6: every core/ file has a module docstring."""
    if CORE_DIR not in path.parents:
        return
    if path.name == "__init__.py":
        return
    if ast.get_docstring(tree):
        return
    report.add("R6", path, 1, "missing module docstring")


def _check_r7_public_function_docstrings(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R7: every public function in core/ has a docstring."""
    if CORE_DIR not in path.parents:
        return
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name.startswith("_"):
            continue
        # Methods inside private classes stay exempt.
        if ast.get_docstring(node):
            continue
        report.add(
            "R7",
            path,
            node.lineno,
            f"public function {node.name!r} missing docstring",
        )


# Files allowed to call sqlite3.connect directly. The persistence module
# OWNS the connection lifecycle and is the canonical place for the helper.
# Tests get a pass too — they often build synthetic databases by hand.
_R8_ALLOWED = {
    "core/persistence/schema.py",
    "core/persistence/findings.py",
    "core/persistence/hypotheses.py",
    "core/persistence/metrics.py",
    "core/persistence/__init__.py",
    "scripts/inspect_db.py",  # operator script — read-only by design
}


def _check_r8_no_raw_sqlite_connect(report: AuditReport, path: Path, tree: ast.Module) -> None:
    """R8: no bare ``sqlite3.connect()`` outside core/persistence.

    Bare ``sqlite3.connect`` misses the WAL / busy_timeout / cache_size /
    synchronous pragmas that ``core.persistence.connect`` applies. Under
    the 16-worker parallel runner that means random ``database is
    locked`` errors. Use ``from core.persistence import connect`` instead.

    Allowed exceptions are listed in ``_R8_ALLOWED`` (the persistence
    module itself, plus a few read-only operator scripts).
    """
    rel = str(_rel(path))
    if rel in _R8_ALLOWED:
        return
    if "tests/" in rel:
        return  # tests can build synthetic DBs
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        func = node.func
        # Match sqlite3.connect(...)
        if not (
            isinstance(func, ast.Attribute)
            and func.attr == "connect"
            and isinstance(func.value, ast.Name)
            and func.value.id == "sqlite3"
        ):
            continue
        # Skip explicit read-only URI connections — they're fine without
        # the WAL / busy_timeout pragmas because SQLite WAL allows
        # unlimited concurrent readers. Pattern:
        #     sqlite3.connect(f"file:.../?mode=ro", uri=True)
        is_readonly_uri = False
        for kw in node.keywords:
            if kw.arg == "uri" and isinstance(kw.value, ast.Constant) and kw.value.value:
                # First positional arg should contain "mode=ro"
                if node.args:
                    first = node.args[0]
                    if isinstance(first, ast.JoinedStr):
                        # f-string — scan its parts for "mode=ro"
                        for part in first.values:
                            if (
                                isinstance(part, ast.Constant)
                                and isinstance(part.value, str)
                                and "mode=ro" in part.value
                            ):
                                is_readonly_uri = True
                                break
                    elif isinstance(first, ast.Constant) and isinstance(first.value, str):
                        if "mode=ro" in first.value:
                            is_readonly_uri = True
        if is_readonly_uri:
            continue
        report.add(
            "R8",
            path,
            node.lineno,
            "bare sqlite3.connect — use core.persistence.connect instead",
        )


# -------------------------------------------------------------------------
# Runner
# -------------------------------------------------------------------------


def audit() -> AuditReport:
    """Run every rule over the codebase and return the accumulated report."""
    report = AuditReport()
    # core/ + domains/ are the code under audit. Scripts and tests are
    # scanned for R3 (paths) and R5 (utcnow) only via a general sweep.
    targets = _iter_py_files(CORE_DIR) + _iter_py_files(DOMAINS_DIR)
    extras = _iter_py_files(SCRIPTS_DIR) + _iter_py_files(TESTS_DIR)

    for path in targets:
        report.files_checked += 1
        tree, source = _parse(path)
        if tree is None:
            continue
        _check_r1_core_to_domains(report, path, tree)
        _check_r2_engine_to_engine(report, path, tree)
        _check_r3_hardcoded_paths(report, path, source)
        _check_r4_bare_except(report, path, tree)
        _check_r5_utcnow(report, path, tree)
        _check_r6_module_docstring(report, path, tree)
        _check_r7_public_function_docstrings(report, path, tree)
        _check_r8_no_raw_sqlite_connect(report, path, tree)

    # Extras: only R3/R5 apply (paths + utcnow are global).
    for path in extras:
        report.files_checked += 1
        tree, source = _parse(path)
        if tree is None:
            continue
        _check_r3_hardcoded_paths(report, path, source)
        _check_r5_utcnow(report, path, tree)

    return report


def print_report(report: AuditReport) -> None:
    """Print findings grouped by rule, followed by a summary line."""
    by_rule: dict[str, list[Finding]] = {}
    for f in report.findings:
        by_rule.setdefault(f.rule, []).append(f)

    print("=" * 72)
    print(f"Nebula Architecture Audit  ({report.files_checked} files scanned)")
    print("=" * 72)

    if not report.findings:
        print("Clean. No violations found.")
        return

    for rule_id in sorted(RULE_LABELS):
        items = by_rule.get(rule_id, [])
        label = RULE_LABELS[rule_id]
        print(f"\n[{rule_id}] {label}  ({len(items)} finding{'s' if len(items) != 1 else ''})")
        if not items:
            continue
        for f in items[:50]:
            print(f"    {_rel(f.path)}:{f.line}  {f.message}")
        if len(items) > 50:
            print(f"    ... and {len(items) - 50} more")

    print()
    print(f"Total violations: {len(report.findings)}")


def main() -> int:
    """Entry point: run the audit and exit 1 if anything failed."""
    report = audit()
    print_report(report)
    return 0 if report.ok else 1


if __name__ == "__main__":
    sys.exit(main())
