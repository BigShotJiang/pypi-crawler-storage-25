#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Devnet integration test runner for Zenon embedded contracts.

Orchestrates the full test lifecycle:
1. Start a fresh devnet node
2. Wait for the node to begin producing momentums
3. Run all contract integration tests
4. Report results
5. Tear down the devnet

Exit codes:
    0 = all tests passed
    1 = one or more tests failed
    2 = devnet setup/teardown error

Usage:
    # Set the znnd binary path
    export ZENON_BINARY=/path/to/go-zenon/build/znnd

    # Optionally set genesis directory (auto-detected if not set)
    export ZENON_GENESIS_DIR=/path/to/full-devnet

    # Run all tests
    python3 test_runner.py

    # Run with custom ports (useful if default ports are in use)
    python3 test_runner.py --http-port 36997 --ws-port 36998

    # Skip full lifecycle tests (only run query/infrastructure tests)
    python3 test_runner.py --skip-lifecycle

    # Keep devnet running after tests (for debugging)
    python3 test_runner.py --keep-alive
"""

import argparse
import os
import sys
import time
from pathlib import Path

# Ensure the engines directory is on the Python path
ENGINES_DIR = Path(__file__).resolve().parent
if str(ENGINES_DIR) not in sys.path:
    sys.path.insert(0, str(ENGINES_DIR))

from domains.devops.infrastructure import (
    DevnetError,
    DevnetManager,
    ZenonRpcClient,
)
from domains.devops.test_suites import (
    FullLifecycleTests,
    get_all_test_classes,
    run_all_tests,
)


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Run Zenon devnet integration tests",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "--znnd-binary",
        default=None,
        help="Path to znnd binary (overrides ZENON_BINARY env var)",
    )
    parser.add_argument(
        "--genesis-dir",
        default=None,
        help="Path to devnet genesis directory (overrides ZENON_GENESIS_DIR)",
    )
    parser.add_argument(
        "--http-port",
        type=int,
        default=35997,
        help="HTTP RPC port (default: 35997)",
    )
    parser.add_argument(
        "--ws-port",
        type=int,
        default=35998,
        help="WebSocket RPC port (default: 35998)",
    )
    parser.add_argument(
        "--p2p-port",
        type=int,
        default=35995,
        help="P2P port (default: 35995)",
    )
    parser.add_argument(
        "--startup-timeout",
        type=float,
        default=30.0,
        help="Seconds to wait for devnet to start (default: 30)",
    )
    parser.add_argument(
        "--skip-lifecycle",
        action="store_true",
        help="Skip full lifecycle tests (requires tx signing)",
    )
    parser.add_argument(
        "--keep-alive",
        action="store_true",
        help="Keep devnet running after tests for debugging",
    )
    parser.add_argument(
        "--data-dir",
        default=None,
        help="Use a specific data directory (default: temp dir)",
    )
    return parser.parse_args()


def print_banner() -> None:
    """Print the test runner banner."""
    print()
    print("=" * 70)
    print("  ZENON DEVNET INTEGRATION TEST RUNNER")
    print("=" * 70)
    print()


def print_summary(suites: list) -> int:
    """Print test summary and return exit code."""
    print()
    print("=" * 70)
    print("  TEST RESULTS SUMMARY")
    print("=" * 70)
    print()

    total_passed = 0
    total_failed = 0

    for suite in suites:
        status = "PASS" if suite.all_passed else "FAIL"
        print(f"  [{status}] {suite.name}: {suite.passed}/{suite.total} passed")

        for result in suite.results:
            if not result.passed:
                print(f"         FAIL: {result.name}")
                # Print first line of error message
                if result.message:
                    first_line = result.message.split("\n")[0]
                    print(f"               {first_line}")

        total_passed += suite.passed
        total_failed += suite.failed

    print()
    print(
        f"  Total: {total_passed + total_failed} tests, "
        f"{total_passed} passed, {total_failed} failed"
    )
    print("=" * 70)

    return 0 if total_failed == 0 else 1


def check_prerequisites(args: argparse.Namespace) -> None:
    """Check that all prerequisites are met before starting tests."""
    binary = args.znnd_binary or os.environ.get("ZENON_BINARY")
    if not binary:
        print("ERROR: znnd binary not specified.")
        print("  Set ZENON_BINARY environment variable or use --znnd-binary flag.")
        print()
        print("  Example:")
        print("    export ZENON_BINARY=/path/to/go-zenon/build/znnd")
        print("    python3 test_runner.py")
        sys.exit(2)

    if not os.path.isfile(binary):
        print(f"ERROR: znnd binary not found at: {binary}")
        print("  Build it with: cd go-zenon && make znnd")
        sys.exit(2)

    # Check for requests library
    try:
        import requests
    except ImportError:
        print("ERROR: 'requests' library required. Install with: pip3 install requests")
        sys.exit(2)

    # Check for optional websocket library
    try:
        import websocket

        print("WebSocket library available (will use WS transport)")
    except ImportError:
        print("WebSocket library not found (will use HTTP transport)")
        print("  Install for better performance: pip3 install websocket-client")

    print()


def main() -> int:
    """Entry point for the test runner."""
    args = parse_args()
    print_banner()
    check_prerequisites(args)

    devnet = None
    rpc = None

    try:
        # ------------------------------------------------------------------
        # Phase 1: Start devnet
        # ------------------------------------------------------------------
        print("Phase 1: Starting devnet...")
        print()

        devnet = DevnetManager(
            znnd_binary=args.znnd_binary,
            genesis_dir=args.genesis_dir,
            http_port=args.http_port,
            ws_port=args.ws_port,
            p2p_port=args.p2p_port,
            data_dir=args.data_dir,
        )
        devnet.start_devnet(timeout=args.startup_timeout)

        # Wait for a few momentums to ensure the chain is advancing
        print("Waiting for initial momentums...")
        devnet.wait_for_momentum(3, timeout=30)
        status = devnet.get_status()
        print(f"Devnet ready at height {status['height']}")
        print()

        # ------------------------------------------------------------------
        # Phase 2: Run tests
        # ------------------------------------------------------------------
        print("Phase 2: Running integration tests...")

        rpc = ZenonRpcClient(
            ws_url=devnet.ws_url,
            http_url=devnet.http_url,
        )

        if args.skip_lifecycle:
            # Run only infrastructure and per-contract query tests
            suites = []
            for cls in get_all_test_classes():
                if cls is FullLifecycleTests:
                    continue
                test = cls(rpc, devnet)
                suites.append(test.run_all())
        else:
            suites = run_all_tests(rpc, devnet)

        # ------------------------------------------------------------------
        # Phase 3: Report results
        # ------------------------------------------------------------------
        exit_code = print_summary(suites)

        # ------------------------------------------------------------------
        # Phase 4: Teardown
        # ------------------------------------------------------------------
        if args.keep_alive:
            print()
            print("Devnet still running (--keep-alive):")
            print(f"  HTTP: {devnet.http_url}")
            print(f"  WS:   {devnet.ws_url}")
            print(f"  Data: {devnet.data_dir}")
            print(f"  PID:  {devnet._process.pid if devnet._process else 'unknown'}")
            print()
            print("Press Ctrl+C to stop the devnet and exit.")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\nShutting down...")
        else:
            print()
            print("Phase 4: Tearing down devnet...")

        return exit_code

    except DevnetError as e:
        print(f"\nDEVNET ERROR: {e}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
        return 2
    except Exception as e:
        print(f"\nUNEXPECTED ERROR: {e}", file=sys.stderr)
        import traceback

        traceback.print_exc()
        return 2
    finally:
        if rpc:
            rpc.close()
        if devnet and devnet.is_running and not args.keep_alive:
            devnet.stop_devnet()


if __name__ == "__main__":
    sys.exit(main())
