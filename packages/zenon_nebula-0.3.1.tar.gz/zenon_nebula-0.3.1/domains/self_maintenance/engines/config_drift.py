# SPDX-License-Identifier: MIT
"""Config Drift Detector — Ensures Nebula's docs match reality.

Checks: domain count in README vs actual, engine count in domains.json vs actual,
test file count, Python file count. If reality drifts from documentation,
flags it for correction.
"""

import json
from pathlib import Path


def detect_drift(repo_root: str) -> dict:
    """Compare documented claims against filesystem reality.

    Returns dict with mismatches found.
    """
    root = Path(repo_root)
    findings = []

    # Count actual domains (dirs with domain.py)
    actual_domains = []
    domains_dir = root / "domains"
    if domains_dir.exists():
        for d in sorted(domains_dir.iterdir()):
            if d.is_dir() and (d / "domain.py").exists():
                actual_domains.append(d.name)

    # Count actual core modules
    core_dir = root / "core"
    actual_core = []
    if core_dir.exists():
        actual_core = [f.stem for f in sorted(core_dir.glob("*.py")) if f.name != "__init__.py"]

    # Count actual test files
    tests_dir = root / "tests"
    actual_tests = []
    if tests_dir.exists():
        actual_tests = [f.name for f in sorted(tests_dir.glob("test_*.py"))]

    # Count total Python files
    actual_py_files = list(root.rglob("*.py"))
    actual_py_files = [f for f in actual_py_files if ".git" not in str(f)]

    # Check README claims
    readme = root / "README.md"
    if readme.exists():
        content = readme.read_text()

        # Check domain count claim
        if "13-domain" in content and len(actual_domains) != 13:
            findings.append(
                {
                    "type": "domain_count_drift",
                    "claimed": 13,
                    "actual": len(actual_domains),
                    "actual_domains": actual_domains,
                    "file": "README.md",
                    "description": (
                        f"WHAT: README.md claims 13-domain but {len(actual_domains)} domains exist on disk. "
                        f"SO WHAT: Stale docs mislead contributors and tools that parse README for architecture info. "
                        f"NOW WHAT: Update README.md to say '{len(actual_domains)}-domain'."
                    ),
                }
            )
        elif "16-domain" in content and len(actual_domains) != 16:
            findings.append(
                {
                    "type": "domain_count_drift",
                    "claimed": 16,
                    "actual": len(actual_domains),
                    "file": "README.md",
                    "description": (
                        f"WHAT: README.md claims 16-domain but {len(actual_domains)} domains exist on disk. "
                        f"SO WHAT: Stale docs mislead contributors and tools that parse README for architecture info. "
                        f"NOW WHAT: Update README.md to say '{len(actual_domains)}-domain'."
                    ),
                }
            )

    # Check domains.json
    domains_json = root / "config" / "domains.json"
    if domains_json.exists():
        try:
            config = json.loads(domains_json.read_text())
            config_domains = list(config.get("domains", {}).keys())
            missing_in_config = set(actual_domains) - set(config_domains)
            missing_on_disk = set(config_domains) - set(actual_domains)

            if missing_in_config:
                missing_list = ", ".join(sorted(missing_in_config))
                findings.append(
                    {
                        "type": "domain_missing_from_config",
                        "domains": list(missing_in_config),
                        "description": (
                            f"WHAT: {len(missing_in_config)} domain(s) exist on disk but not in config/domains.json: {missing_list}. "
                            f"SO WHAT: These domains will not be discovered or run by the autonomous runner. "
                            f"NOW WHAT: Add entries for [{missing_list}] to config/domains.json."
                        ),
                    }
                )
            if missing_on_disk:
                missing_list = ", ".join(sorted(missing_on_disk))
                findings.append(
                    {
                        "type": "domain_missing_from_disk",
                        "domains": list(missing_on_disk),
                        "description": (
                            f"WHAT: {len(missing_on_disk)} domain(s) in config/domains.json have no domain.py on disk: {missing_list}. "
                            f"SO WHAT: The runner will fail or skip these domains, causing incomplete engine coverage. "
                            f"NOW WHAT: Create domain.py for [{missing_list}] or remove them from config/domains.json."
                        ),
                    }
                )
        except (json.JSONDecodeError, KeyError):
            findings.append(
                {
                    "type": "config_parse_error",
                    "file": "config/domains.json",
                    "description": (
                        "WHAT: config/domains.json failed to parse (invalid JSON or missing 'domains' key). "
                        "SO WHAT: Domain auto-discovery is broken; no engines will run. "
                        "NOW WHAT: Fix JSON syntax in config/domains.json and ensure it has a top-level 'domains' object."
                    ),
                }
            )

    return {
        "findings": findings,
        "drift_detected": len(findings) > 0,
        "actual_state": {
            "domains": len(actual_domains),
            "domain_names": actual_domains,
            "core_modules": len(actual_core),
            "test_files": len(actual_tests),
            "total_python_files": len(actual_py_files),
        },
    }
