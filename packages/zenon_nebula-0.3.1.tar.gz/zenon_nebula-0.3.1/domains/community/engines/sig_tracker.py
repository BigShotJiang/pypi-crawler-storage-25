# SPDX-License-Identifier: MIT
"""
SIGTracker -- Track Special Interest Groups and governance docs.

Reads hypercore-one SIG repos (sig-community, sig-op, sig-sdlc, sig-syrius)
for governance documents, incubator projects, and newsletter content.
Tracks community governance structure and communication patterns.
"""

import logging
import os
import subprocess
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# SIG repositories to monitor
SIG_REPOS = {
    "sig-community": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "sig-community",
        ],
        "focus": "community governance and engagement",
    },
    "sig-op": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "sig-op",
        ],
        "focus": "operations and infrastructure",
    },
    "sig-sdlc": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "sig-sdlc",
        ],
        "focus": "software development lifecycle",
    },
    "sig-syrius": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "sig-syrius",
        ],
        "focus": "Syrius wallet development",
    },
}

# Incubator and newsletter repos
INCUBATOR_PATHS = [
    ZENON_WORKSPACE / "hypercore-one",
]

NEWSLETTER_REPOS = {
    "hypercore-one-newsletter": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "hypercore-one",
        ],
    },
}


def _read_file(filepath: Path, max_bytes: int = 200_000) -> str:
    """Read file text, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _run_git(repo_path: str, *args: str, timeout: int = 30) -> tuple[int, str]:
    """Run a git command. Returns (returncode, stdout)."""
    cmd = ["git", "-C", repo_path, *list(args)]
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return result.returncode, result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return 1, ""


def _find_repo(paths: list[Path]) -> Path | None:
    """Find the first existing path from a list of candidates."""
    for p in paths:
        if p.is_dir():
            return p
    return None


def scan_sig_repo(sig_name: str, sig_config: dict) -> dict:
    """Scan a single SIG repo for governance documents and activity.

    Returns dict with exists, documents, proposals, last_commit, members.
    """
    result = {
        "sig_name": sig_name,
        "exists": False,
        "path": None,
        "focus": sig_config["focus"],
        "documents": [],
        "proposals": [],
        "meetings": [],
        "last_commit": None,
        "contributors": [],
        "total_docs": 0,
    }

    repo_path = _find_repo(sig_config["paths"])
    if not repo_path:
        return result

    result["exists"] = True
    result["path"] = str(repo_path.relative_to(ZENON_WORKSPACE))

    # Get last commit
    code, output = _run_git(
        str(repo_path),
        "log",
        "-1",
        "--format=%H|%aI|%s",
    )
    if code == 0 and output:
        parts = output.split("|", 2)
        if len(parts) >= 3:
            result["last_commit"] = {
                "hash": parts[0][:12],
                "date": parts[1],
                "message": parts[2],
            }

    # Get unique contributors
    code, output = _run_git(
        str(repo_path),
        "log",
        "--format=%an",
        "--since=1 year ago",
    )
    if code == 0 and output:
        contributors = sorted(set(output.strip().split("\n")))
        result["contributors"] = contributors[:20]

    # Scan for governance documents
    for md_file in repo_path.rglob("*.md"):
        rel = str(md_file.relative_to(repo_path))
        if ".git" in rel:
            continue

        content_preview = _read_file(md_file)[:500].lower()
        doc_type = "document"

        if any(
            kw in rel.lower() or kw in content_preview for kw in ["proposal", "zip", "hqip", "rfc"]
        ):
            doc_type = "proposal"
            result["proposals"].append(rel)
        elif any(
            kw in rel.lower() or kw in content_preview
            for kw in ["meeting", "minutes", "agenda", "notes"]
        ):
            doc_type = "meeting"
            result["meetings"].append(rel)

        result["documents"].append(
            {
                "path": rel,
                "type": doc_type,
            }
        )

    result["total_docs"] = len(result["documents"])
    return result


def scan_incubator_projects() -> list[dict]:
    """Scan hypercore-one for incubator projects.

    Returns list of project dicts with name, path, status, languages.
    """
    projects = []

    for incubator_root in INCUBATOR_PATHS:
        if not incubator_root.is_dir():
            continue

        for item in incubator_root.iterdir():
            if not item.is_dir() or item.name.startswith("."):
                continue
            # Skip known non-incubator repos
            if item.name.startswith("sig-") or item.name in (
                "go-zenon",
                "syrius",
                "znn_sdk_dart",
                "znn_cli_dart",
                "nomctl",
            ):
                continue

            git_dir = item / ".git"
            if not git_dir.exists():
                continue

            # Detect languages
            languages = set()
            for ext, lang in [
                (".go", "go"),
                (".dart", "dart"),
                (".ts", "typescript"),
                (".py", "python"),
                (".rs", "rust"),
                (".sol", "solidity"),
            ]:
                if list(item.rglob(f"*{ext}"))[:1]:
                    languages.add(lang)

            # Get last commit date
            code, output = _run_git(str(item), "log", "-1", "--format=%aI")
            last_activity = output if code == 0 else "unknown"

            has_readme = (item / "README.md").exists() or (item / "readme.md").exists()

            projects.append(
                {
                    "name": item.name,
                    "path": str(item.relative_to(ZENON_WORKSPACE)),
                    "languages": sorted(languages),
                    "last_activity": last_activity,
                    "has_readme": has_readme,
                }
            )

    return projects


def scan_newsletters() -> list[dict]:
    """Scan for newsletter content in known locations.

    Returns list of newsletter entries.
    """
    newsletters = []

    for name, config in NEWSLETTER_REPOS.items():
        repo_path = _find_repo(config["paths"])
        if not repo_path:
            continue

        for md_file in repo_path.rglob("*.md"):
            rel = str(md_file.relative_to(repo_path))
            if ".git" in rel:
                continue
            content = _read_file(md_file)[:500].lower()
            if any(
                kw in rel.lower() or kw in content
                for kw in ["newsletter", "update", "digest", "weekly", "monthly"]
            ):
                newsletters.append(
                    {
                        "source": name,
                        "path": rel,
                        "preview": content[:200],
                    }
                )

    return newsletters


def generate_report() -> dict:
    """Generate a full SIG tracking report."""
    sig_results = {}
    for sig_name, sig_config in SIG_REPOS.items():
        sig_results[sig_name] = scan_sig_repo(sig_name, sig_config)

    incubator = scan_incubator_projects()
    newsletters = scan_newsletters()

    # Summary
    active_sigs = sum(1 for s in sig_results.values() if s["exists"])
    total_proposals = sum(len(s.get("proposals", [])) for s in sig_results.values())
    total_meetings = sum(len(s.get("meetings", [])) for s in sig_results.values())
    all_contributors: set[str] = set()
    for s in sig_results.values():
        all_contributors.update(s.get("contributors", []))

    return {
        "sigs": sig_results,
        "incubator_projects": incubator,
        "newsletters": newsletters,
        "summary": {
            "active_sigs": active_sigs,
            "total_sigs": len(SIG_REPOS),
            "total_proposals": total_proposals,
            "total_meetings": total_meetings,
            "unique_contributors": len(all_contributors),
            "incubator_count": len(incubator),
            "newsletter_count": len(newsletters),
        },
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run SIG analysis and persist findings.

    Returns number of findings persisted.
    """
    ensure_schema(db_path)
    report = generate_report()
    count = 0

    summary = report["summary"]
    inactive_sigs = summary["total_sigs"] - summary["active_sigs"]

    if inactive_sigs > 0:
        sig_impact = f"{inactive_sigs} SIG(s) inactive -- governance gaps in those areas may slow decision-making."
        sig_action = (
            "Identify why inactive SIGs stalled; recruit new leads or merge into active SIGs."
        )
    elif summary["total_meetings"] == 0:
        sig_impact = "All SIGs exist but no meeting records found -- governance may be informal or undocumented."
        sig_action = "Encourage SIGs to publish meeting notes for transparency and accountability."
    else:
        sig_impact = "SIG governance structure is active and documented."
        sig_action = "Continue monitoring contributor engagement and proposal throughput."

    persist_finding(
        db_path=db_path,
        domain="community",
        engine="sig_tracker",
        evidence_type="sig_governance_overall",
        finding=(
            f"WHAT: {summary['active_sigs']}/{summary['total_sigs']} SIGs active, "
            f"{summary['total_proposals']} proposals, {summary['total_meetings']} meetings, "
            f"{summary['unique_contributors']} contributors, {summary['incubator_count']} incubator projects. "
            f"SO WHAT: {sig_impact} "
            f"NOW WHAT: {sig_action}"
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="hypercore-one",
    )
    count += 1

    # Per-SIG findings
    for sig_name, sig_data in report["sigs"].items():
        if sig_data["exists"]:
            n_contributors = len(sig_data.get("contributors", []))
            n_proposals = len(sig_data.get("proposals", []))
            n_meetings = len(sig_data.get("meetings", []))

            if n_contributors == 0:
                per_sig_action = "No contributors in past year -- SIG may be defunct. Consider archiving or recruiting."
            elif n_meetings == 0 and n_proposals == 0:
                per_sig_action = "Has contributors but no proposals or meetings -- encourage structured governance output."
            else:
                per_sig_action = "Active and producing output. Monitor for contributor churn."

            persist_finding(
                db_path=db_path,
                domain="community",
                engine="sig_tracker",
                evidence_type="sig_status",
                finding=(
                    f"WHAT: {sig_name} ({sig_data['focus']}): {sig_data['total_docs']} docs, "
                    f"{n_proposals} proposals, {n_meetings} meetings, {n_contributors} contributors. "
                    f"SO WHAT: {'Active' if n_contributors > 0 else 'Inactive'} SIG covering {sig_data['focus']}. "
                    f"NOW WHAT: {per_sig_action}"
                ),
                confidence=0.80,
                raw_data=sig_data,
                source_repo=f"hypercore-one/{sig_name}",
            )
            count += 1
        else:
            persist_finding(
                db_path=db_path,
                domain="community",
                engine="sig_tracker",
                evidence_type="sig_missing",
                finding=(
                    f"WHAT: {sig_name} repo not found locally. "
                    f"SO WHAT: Cannot track governance activity for {sig_data['focus']} -- blind spot in monitoring. "
                    f"NOW WHAT: Clone hypercore-one/{sig_name} into workspace to enable tracking."
                ),
                confidence=0.70,
                raw_data={"sig_name": sig_name, "focus": sig_data["focus"]},
                source_repo=f"hypercore-one/{sig_name}",
            )
            count += 1

    # Incubator findings
    for project in report["incubator_projects"]:
        last_active = (
            project["last_activity"][:10] if project["last_activity"] != "unknown" else "unknown"
        )
        langs = ", ".join(project["languages"]) or "unknown"

        persist_finding(
            db_path=db_path,
            domain="community",
            engine="sig_tracker",
            evidence_type="incubator_project",
            finding=(
                f"WHAT: Incubator project '{project['name']}' ({langs}), last active {last_active}. "
                f"SO WHAT: {'Project may be stalled if no recent activity' if last_active == 'unknown' else 'Tracked for ecosystem growth'}. "
                f"NOW WHAT: {'Check project status and maintainer availability' if not project.get('has_readme') else 'Monitor for continued development'}."
            ),
            confidence=0.70,
            raw_data=project,
            source_repo=project.get("path"),
        )
        count += 1

    logger.info("SIGTracker: persisted %d findings", count)
    return count
