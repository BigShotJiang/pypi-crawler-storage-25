# SPDX-License-Identifier: MIT
"""
Community Scanner — Reads EVERYTHING from community repos, PRs, issues, comments.

Not just code. The discussions, review feedback, feature requests, bug reports,
and debates are where the real intelligence lives. A PR comment saying "this
approach won't scale" is as valuable as the code itself.

Sources:
    - GitHub repos: code, commits, branches
    - GitHub PRs: descriptions, reviews, review comments, status
    - GitHub Issues: bug reports, feature requests, discussions
    - GitHub Discussions: if enabled on repos
    - Commit messages: intent and reasoning
    - Code review feedback: what core devs care about

Uses GitHub API via `gh` CLI (respects rate limits, uses authenticated token).
"""

import json
import logging
import sqlite3
import subprocess
from datetime import datetime, timedelta, timezone
from pathlib import Path

from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DB_PATH = ENGINE_ROOT / "data" / "engine.db"

# GitHub orgs and key repos to watch
DEFAULT_WATCHED_ORGS = [
    "zenon-network",
    "hypercore-one",
    "HyperCore-Team",
    "zenon-red",
    "zenonhub-io",
    "ZenonOrg",
]

DEFAULT_WATCHED_USERS = [
    "sol-znn",
    "digitalSloth",
    "georgezgeorgez",
    "MoonBaZZe",
    "DexterLabZ",
    "KingGorrin",
    "millerships",
    "TminusZ",
    "vilkris",
    "alienc0der",
    "drblazer21",
    "sumamu",
    "cryptofish",
]


def ensure_tables(db_path: str = str(DB_PATH)) -> None:
    """Create required database tables if they do not exist."""
    conn = connect(db_path)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS community_activity (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            source_type TEXT NOT NULL,
            repo TEXT NOT NULL,
            author TEXT,
            title TEXT,
            body TEXT,
            url TEXT,
            labels TEXT,
            state TEXT,
            created_at TEXT,
            updated_at TEXT,
            sentiment TEXT,
            relevance_score REAL DEFAULT 0.0,
            processed BOOLEAN DEFAULT FALSE
        );

        CREATE INDEX IF NOT EXISTS idx_community_source ON community_activity(source_type);
        CREATE INDEX IF NOT EXISTS idx_community_repo ON community_activity(repo);
        CREATE INDEX IF NOT EXISTS idx_community_author ON community_activity(author);
    """)
    conn.commit()
    conn.close()


def scan_org_activity(org: str, since_days: int = 7, db_path: str = str(DB_PATH)) -> dict:
    """Scan a GitHub org for recent PRs, issues, and commits.

    Uses `gh` CLI for authenticated access. Respects rate limits.
    """
    ensure_tables(db_path)
    stats = {"prs": 0, "issues": 0, "comments": 0, "repos_scanned": 0}

    # Get org repos
    try:
        result = subprocess.run(
            [
                "gh",
                "repo",
                "list",
                org,
                "--limit",
                "100",
                "--json",
                "name,updatedAt",
                "--jq",
                f'[.[] | select(.updatedAt > "{_days_ago(since_days)}")]',
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            logger.warning("Failed to list repos for %s: %s", org, result.stderr[:200])
            return stats

        repos = json.loads(result.stdout) if result.stdout.strip() else []
    except Exception as e:
        logger.warning("Error listing repos for %s: %s", org, e)
        return stats

    conn = connect(db_path)

    for repo_info in repos:
        repo_name = f"{org}/{repo_info['name']}"
        stats["repos_scanned"] += 1

        # Scan PRs
        prs = _gh_query(
            f"repos/{repo_name}/pulls",
            {"state": "all", "per_page": 20, "sort": "updated", "direction": "desc"},
        )
        for pr in prs:
            if _is_recent(pr.get("updated_at"), since_days):
                _persist_activity(conn, "pull_request", repo_name, pr)
                stats["prs"] += 1

                # Get PR review comments (the gold — this is where devs express opinions)
                comments = _gh_query(
                    f"repos/{repo_name}/pulls/{pr['number']}/comments", {"per_page": 50}
                )
                for comment in comments:
                    if _is_recent(comment.get("updated_at"), since_days):
                        _persist_activity(
                            conn,
                            "review_comment",
                            repo_name,
                            comment,
                            parent_title=pr.get("title", ""),
                        )
                        stats["comments"] += 1

                # Get PR reviews (approve/reject/comment)
                reviews = _gh_query(
                    f"repos/{repo_name}/pulls/{pr['number']}/reviews", {"per_page": 20}
                )
                for review in reviews:
                    if review.get("body"):
                        _persist_activity(
                            conn, "review", repo_name, review, parent_title=pr.get("title", "")
                        )
                        stats["comments"] += 1

        # Scan issues
        issues = _gh_query(
            f"repos/{repo_name}/issues",
            {"state": "all", "per_page": 20, "sort": "updated", "direction": "desc"},
        )
        for issue in issues:
            if _is_recent(issue.get("updated_at"), since_days) and "pull_request" not in issue:
                _persist_activity(conn, "issue", repo_name, issue)
                stats["issues"] += 1

                # Get issue comments
                issue_comments = _gh_query(
                    f"repos/{repo_name}/issues/{issue['number']}/comments", {"per_page": 30}
                )
                for comment in issue_comments:
                    if _is_recent(comment.get("updated_at"), since_days):
                        _persist_activity(
                            conn,
                            "issue_comment",
                            repo_name,
                            comment,
                            parent_title=issue.get("title", ""),
                        )
                        stats["comments"] += 1

    conn.commit()
    conn.close()

    logger.info(
        "Scanned %s: %d repos, %d PRs, %d issues, %d comments",
        org,
        stats["repos_scanned"],
        stats["prs"],
        stats["issues"],
        stats["comments"],
    )
    return stats


def scan_user_activity(username: str, since_days: int = 30, db_path: str = str(DB_PATH)) -> dict:
    """Scan a GitHub user's recent public activity.

    Tracks: commits, PRs opened, issues filed, comments made.
    This builds a contributor profile over time.
    """
    ensure_tables(db_path)
    stats = {"events": 0}

    events = _gh_query(f"users/{username}/events/public", {"per_page": 100})
    conn = connect(db_path)

    for event in events:
        if not _is_recent(event.get("created_at"), since_days):
            continue

        event_type = event.get("type", "")
        repo = event.get("repo", {}).get("name", "")
        payload = event.get("payload", {})

        if event_type == "PushEvent":
            for commit in payload.get("commits", []):
                _persist_activity(
                    conn,
                    "commit",
                    repo,
                    {
                        "user": {"login": username},
                        "title": commit.get("message", "")[:200],
                        "body": commit.get("message", ""),
                        "html_url": "",
                        "created_at": event.get("created_at"),
                        "updated_at": event.get("created_at"),
                        "labels": [],
                        "state": "pushed",
                    },
                )
                stats["events"] += 1

        elif event_type in ("PullRequestEvent", "IssuesEvent", "IssueCommentEvent"):
            item = payload.get("pull_request") or payload.get("issue") or payload.get("comment", {})
            source = {
                "PullRequestEvent": "pull_request",
                "IssuesEvent": "issue",
                "IssueCommentEvent": "issue_comment",
            }.get(event_type, "unknown")
            _persist_activity(conn, source, repo, item)
            stats["events"] += 1

    conn.commit()
    conn.close()

    logger.info("Scanned user %s: %d events", username, stats["events"])
    return stats


def scan_all(since_days: int = 7, db_path: str = str(DB_PATH)) -> dict:
    """Scan everything — all orgs and key users."""
    total = {"orgs": 0, "users": 0, "prs": 0, "issues": 0, "comments": 0, "events": 0}

    for org in DEFAULT_WATCHED_ORGS:
        stats = scan_org_activity(org, since_days, db_path)
        total["orgs"] += 1
        total["prs"] += stats.get("prs", 0)
        total["issues"] += stats.get("issues", 0)
        total["comments"] += stats.get("comments", 0)

    for user in DEFAULT_WATCHED_USERS:
        stats = scan_user_activity(user, since_days * 4, db_path)  # Wider window for users
        total["users"] += 1
        total["events"] += stats.get("events", 0)

    return total


def get_recent_insights(db_path: str = str(DB_PATH), limit: int = 20) -> list:
    """Get most recent community activity, prioritized by relevance."""
    conn = connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute(
        """
        SELECT source_type, repo, author, title, body, url, state, created_at
        FROM community_activity
        WHERE processed = 0
        ORDER BY created_at DESC
        LIMIT ?
    """,
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def _gh_query(endpoint: str, params: dict) -> list:
    """Query GitHub API via gh cli."""
    try:
        param_str = "&".join(f"{k}={v}" for k, v in params.items())
        result = subprocess.run(
            ["gh", "api", f"{endpoint}?{param_str}"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout)
            return data if isinstance(data, list) else []
    except Exception as e:
        logger.debug("GitHub API error for %s: %s", endpoint, e)
    return []


def _persist_activity(
    conn, source_type: str, repo: str, item: dict, parent_title: str = ""
) -> None:
    """Persist a community activity item."""
    author = (item.get("user") or {}).get("login", "unknown")
    title = item.get("title", parent_title)[:500]
    body = (item.get("body") or "")[:5000]
    url = item.get("html_url", "")
    labels = json.dumps([l.get("name", "") for l in (item.get("labels") or [])])
    state = item.get("state", "")
    created = item.get("created_at", "")
    updated = item.get("updated_at", "")

    # Dedup
    existing = conn.execute(
        "SELECT id FROM community_activity WHERE url = ? AND source_type = ?",
        (url, source_type),
    ).fetchone()
    if existing:
        return

    conn.execute(
        """INSERT INTO community_activity
           (source_type, repo, author, title, body, url, labels, state, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (source_type, repo, author, title, body, url, labels, state, created, updated),
    )


def _days_ago(days: int) -> str:
    return (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ")


def _is_recent(date_str: str | None, days: int) -> bool:
    if not date_str:
        return False
    try:
        dt = datetime.fromisoformat(date_str.replace("Z", "+00:00"))
        return dt > datetime.now(dt.tzinfo) - timedelta(days=days)
    except (ValueError, TypeError):
        return False
