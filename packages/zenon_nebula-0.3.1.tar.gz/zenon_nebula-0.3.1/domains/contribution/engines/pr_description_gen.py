# SPDX-License-Identifier: MIT
"""
PRDescriptionGen -- Generates PR descriptions from commit history.

Reads commit history on a branch, links to spec references, lists
changes, testing evidence, cross-repo dependencies, and formats
using a PR template.
"""

import logging
import re
import subprocess
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

PR_TEMPLATE = """## Summary

{summary}

## Spec Reference

{spec_reference}

## Changes

{changes}

## Testing Evidence

{testing_evidence}

## Cross-repo Dependencies

{cross_repo_deps}

## Checklist

- [ ] Compiles on clean checkout
- [ ] All tests pass
- [ ] OPSEC clean (no secrets, no local paths)
- [ ] ABI identical to go-zenon
- [ ] Addresses match across repos
- [ ] No dead code or debug artifacts
"""


def _run_git(command: str, cwd: Path) -> str | None:
    """Run a git command and return stdout."""
    try:
        result = subprocess.run(
            f"git {command}",
            shell=True,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return None


def get_branch_name(repo_path: Path) -> str | None:
    """Get the current branch name."""
    return _run_git("rev-parse --abbrev-ref HEAD", repo_path)


def get_base_branch(repo_path: Path) -> str:
    """Determine the base branch (main or master)."""
    for branch in ("main", "master"):
        result = _run_git(f"rev-parse --verify {branch}", repo_path)
        if result:
            return branch
    return "main"


def get_commits(repo_path: Path, base_branch: str | None = None) -> list[dict]:
    """Get commits on the current branch since diverging from base.

    Returns list of dicts with hash, message, author, date.
    """
    if base_branch is None:
        base_branch = get_base_branch(repo_path)

    log_output = _run_git(
        f"log {base_branch}..HEAD --format=%H||%s||%an||%ai",
        repo_path,
    )
    if not log_output:
        # Fall back to last 10 commits
        log_output = _run_git(
            "log -10 --format=%H||%s||%an||%ai",
            repo_path,
        )

    if not log_output:
        return []

    commits = []
    for line in log_output.strip().split("\n"):
        parts = line.split("||")
        if len(parts) >= 4:
            commits.append(
                {
                    "hash": parts[0][:8],
                    "message": parts[1],
                    "author": parts[2],
                    "date": parts[3],
                }
            )
    return commits


def get_changed_files(repo_path: Path, base_branch: str | None = None) -> list[str]:
    """Get list of files changed on the current branch."""
    if base_branch is None:
        base_branch = get_base_branch(repo_path)

    output = _run_git(f"diff --name-only {base_branch}..HEAD", repo_path)
    if not output:
        output = _run_git("diff --name-only HEAD~1", repo_path)

    if not output:
        return []
    return output.strip().split("\n")


def _detect_spec_reference(commits: list[dict], files: list[str]) -> str:
    """Detect which spec(s) this PR relates to."""
    spec_hints = set()

    # Check commit messages for spec references
    spec_re = re.compile(
        r"(?:spec|contract|embedded)[/:\s]+(\w+)",
        re.IGNORECASE,
    )
    for c in commits:
        for match in spec_re.finditer(c["message"]):
            spec_hints.add(match.group(1).lower())

    # Check file paths for contract names
    contract_re = re.compile(
        r"(?:definition|implementation|embedded)/(\w+)\.(?:go|dart)",
    )
    for f in files:
        for match in contract_re.finditer(f):
            spec_hints.add(match.group(1).lower())

    if spec_hints:
        return ", ".join(sorted(spec_hints))
    return "No spec reference detected"


def _detect_cross_repo_deps(files: list[str]) -> str:
    """Detect cross-repo dependencies from changed files."""
    deps = set()
    for f in files:
        if "definition" in f:
            deps.add("SDK update needed (ABI definition changed)")
        if "abi" in f.lower():
            deps.add("SDK ABI sync required")
        if "embedded" in f:
            deps.add("go-zenon embedded contract changed")

    if deps:
        return "\n".join(f"- {d}" for d in sorted(deps))
    return "No cross-repo dependencies detected"


def generate_description(
    repo_path: Path,
    *,
    base_branch: str | None = None,
    extra_context: str | None = None,
) -> str:
    """Generate a PR description for the current branch.

    Args:
        repo_path: Path to the repository.
        base_branch: Base branch to compare against.
        extra_context: Additional context to include.

    Returns:
        Formatted PR description string.
    """
    get_branch_name(repo_path) or "unknown"
    commits = get_commits(repo_path, base_branch)
    files = get_changed_files(repo_path, base_branch)

    # Build summary from commit messages
    if commits:
        summary_lines = [f"- {c['message']} ({c['hash']})" for c in commits[:10]]
        summary = "\n".join(summary_lines)
    else:
        summary = "No commits found on this branch."

    # Build changes list
    if files:
        changes = "\n".join(f"- `{f}`" for f in files[:30])
    else:
        changes = "No file changes detected."

    # Detect spec reference
    spec_reference = _detect_spec_reference(commits, files)

    # Testing evidence placeholder
    testing_evidence = "- [ ] Unit tests pass\n- [ ] Integration tests pass"

    # Cross-repo deps
    cross_repo_deps = _detect_cross_repo_deps(files)

    description = PR_TEMPLATE.format(
        summary=summary,
        spec_reference=spec_reference,
        changes=changes,
        testing_evidence=testing_evidence,
        cross_repo_deps=cross_repo_deps,
    )

    if extra_context:
        description += f"\n## Additional Context\n\n{extra_context}\n"

    return description
