# SPDX-License-Identifier: MIT
"""
SecurityDomain -- DomainPlugin for contract security analysis and vulnerability detection.

Provides engines for adversarial LLM-driven contract review, pattern-based
vulnerability scanning, static analysis of Go source, and security report
generation for PR descriptions.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class SecurityDomain(DomainPlugin):
    """Security domain plugin -- fund safety and contract auditing."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "security"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Contract security analysis: adversarial LLM review, "
            "pattern-based vulnerability scanning, static analysis, "
            "bridge exploit pattern matching, dependency CVE monitoring, "
            "economic attack simulation, and security report generation."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 1  # Highest priority -- fund safety

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="adversarial_reviewer",
                description=(
                    "LLM-driven contract analysis that reads Go "
                    "implementations and identifies fund theft paths, "
                    "fund lock paths, DoS vectors, access control bypasses, "
                    "integer overflow, and reentrancy."
                ),
                module_path="domains.security.engines.adversarial_reviewer",
                priority=1,
                tier=5,
                required_apis=["xai"],
                max_runtime_seconds=600,
            ),
            EngineDefinition(
                name="vuln_scanner",
                description=(
                    "Pattern-based scanning of contract source files "
                    "for known vulnerability patterns: unchecked errors, "
                    "missing access control, hardcoded values, unsafe arithmetic."
                ),
                module_path="domains.security.engines.vuln_scanner",
                priority=2,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="static_analyzer",
                description=(
                    "AST-level Go analysis: error return handling, "
                    "no bare _ on error, ValidateSendBlock repacks data, "
                    "ReceiveBlock calls ValidateSendBlock first."
                ),
                module_path="domains.security.engines.static_analyzer",
                priority=3,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=180,
            ),
            EngineDefinition(
                name="report_generator",
                description=(
                    "Generates security report sections for PR descriptions "
                    "from accumulated findings and severity ratings."
                ),
                module_path="domains.security.engines.report_generator",
                priority=4,
                tier=1,
                required_apis=[],
                max_runtime_seconds=30,
            ),
            EngineDefinition(
                name="exploit_scanner",
                description=(
                    "Checks Zenon bridge/portal code against the top 10 "
                    "real-world bridge exploit patterns (Wormhole, Ronin, "
                    "Harmony, Nomad, Poly Network, BNB Bridge, Multichain, "
                    "Qubit, Meter, Li.Finance). Pure pattern matching."
                ),
                module_path="domains.security.engines.exploit_scanner",
                priority=2,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="cve_monitor",
                description=(
                    "Scans workspace repo dependencies (Go, Node, Python) "
                    "against a database of 20 known critical CVEs affecting "
                    "crypto libraries (secp256k1, btcd, libp2p, etc.)."
                ),
                module_path="domains.security.engines.cve_monitor",
                priority=3,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="attack_simulator",
                description=(
                    "Models economic attacks against Zenon: governance "
                    "takeover, delegation concentration, bridge compromise, "
                    "treasury drain, and spam attacks. Uses zenonhub API "
                    "for live network stats."
                ),
                module_path="domains.security.engines.attack_simulator",
                priority=4,
                tier=2,
                required_apis=[],
                max_runtime_seconds=60,
            ),
            EngineDefinition(
                name="cross_chain_cve_monitor",
                description=(
                    "Pattern-matches consensus-critical primitives "
                    "(merkle proofs, SPV headers, signature verification) "
                    "across a workspace reference blockchain and the "
                    "Zenon fork. Activates only when a reference chain "
                    "(Bitcoin Core, geth, cosmos-sdk, etc.) is present."
                ),
                module_path="domains.security.engines.cross_chain_cve_monitor",
                priority=5,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="fund_theft_vector",
                label="Fund theft vector identified",
                description=(
                    "A code path exists that could allow unauthorized "
                    "withdrawal or transfer of funds."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.90,
            ),
            HypothesisType(
                type_id="fund_lock_vector",
                label="Fund lock vector identified",
                description=(
                    "A code path exists that could permanently lock funds "
                    "with no recovery mechanism."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.85,
            ),
            HypothesisType(
                type_id="dos_vector",
                label="Denial-of-service vector",
                description=(
                    "A code path exists that could halt contract execution "
                    "or degrade network performance."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="access_control_bypass",
                label="Access control bypass",
                description=("A code path exists that bypasses intended access control checks."),
                initial_confidence=0.3,
                publishable_threshold=0.85,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_contract_audit",
                label="Full contract audit coverage",
                description=(
                    "Every embedded contract has been reviewed by the "
                    "adversarial reviewer with no critical findings."
                ),
                priority=1,
            ),
            AspirationType(
                type_id="zero_critical_vulns",
                label="Zero critical vulnerabilities",
                description=(
                    "No critical or high severity vulnerabilities remain "
                    "unresolved across all contracts."
                ),
                priority=1,
                deadline_days=14,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="security_spec_mismatch",
                label="Security-spec mismatch",
                description=(
                    "A security finding contradicts the spec definition, "
                    "indicating either a spec gap or an implementation bug."
                ),
                source_domains=["security", "development"],
                convergence_threshold=0.5,
            ),
            CollisionSignal(
                signal_id="security_breaking_overlap",
                label="Security + breaking change overlap",
                description=(
                    "A security-relevant change is also a breaking change, "
                    "requiring coordinated response across domains."
                ),
                source_domains=["security", "intelligence"],
                convergence_threshold=0.5,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="security",
                section_title="Security Posture",
                metrics=[
                    "contracts_reviewed",
                    "critical_findings",
                    "high_findings",
                    "unresolved_findings",
                    "audit_coverage_pct",
                ],
                recommendations_prompt=(
                    "Based on current security findings, what contracts "
                    "need immediate attention and what is the overall "
                    "security posture?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "contracts_reviewed": 0.0,
            "findings_per_contract": 0.0,
            "false_positive_rate": 0.0,
            "audit_coverage_pct": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Decide the highest-value next action given current state."""
        trigger = context.get("trigger_level", "routine")
        stale = context.get("stale_data", [])

        if trigger in ("urgent", "critical"):
            return {
                "action": "adversarial_review",
                "reason": "Urgent trigger -- run adversarial review on changed contracts.",
                "priority": 1,
                "engine": "adversarial_reviewer",
            }

        if "security_scan" in stale:
            return {
                "action": "vuln_scan",
                "reason": "Vulnerability scan data is stale.",
                "priority": 2,
                "engine": "vuln_scanner",
            }

        if "exploit_scan" in stale:
            return {
                "action": "exploit_scan",
                "reason": "Bridge exploit pattern scan data is stale.",
                "priority": 2,
                "engine": "exploit_scanner",
            }

        if "cve_scan" in stale:
            return {
                "action": "cve_scan",
                "reason": "Dependency CVE scan data is stale.",
                "priority": 3,
                "engine": "cve_monitor",
            }

        if "attack_simulation" in stale:
            return {
                "action": "attack_simulation",
                "reason": "Attack simulation data is stale -- re-run with current network stats.",
                "priority": 4,
                "engine": "attack_simulator",
            }

        if "security_report" in stale:
            return {
                "action": "generate_report",
                "reason": "Security report needs regeneration.",
                "priority": 5,
                "engine": "report_generator",
            }

        return {
            "action": "static_analysis",
            "reason": "Routine static analysis of contract code.",
            "priority": 6,
            "engine": "static_analyzer",
        }

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return """
CREATE TABLE IF NOT EXISTS security_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    contract_name TEXT NOT NULL,
    engine TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'info',
    category TEXT,
    title TEXT NOT NULL,
    description TEXT,
    file_path TEXT,
    line_number INTEGER,
    confidence REAL DEFAULT 0.0,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at DATETIME,
    resolved_by TEXT
);

CREATE TABLE IF NOT EXISTS vuln_patterns (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_name TEXT NOT NULL,
    pattern_regex TEXT NOT NULL,
    severity TEXT NOT NULL DEFAULT 'medium',
    category TEXT NOT NULL,
    description TEXT,
    enabled BOOLEAN DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_reviews_contract
    ON security_reviews(contract_name);
CREATE INDEX IF NOT EXISTS idx_reviews_severity
    ON security_reviews(severity);
CREATE INDEX IF NOT EXISTS idx_reviews_resolved
    ON security_reviews(resolved);
CREATE INDEX IF NOT EXISTS idx_vuln_patterns_category
    ON vuln_patterns(category);
"""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Security domain registered with %d engines.",
            len(self.get_engines()),
        )

    # Engines authorized to publish findings attributed to the
    # security domain. Any other engine name claiming the security
    # domain will be quarantined by core.trust.should_quarantine().
    _TRUSTED_ENGINES = frozenset(
        {
            "adversarial_reviewer",
            "vuln_scanner",
            "static_analyzer",
            "report_generator",
            "attack_simulator",
            "bridge_scanner",
            "cve_monitor",
            "exploit_scanner",
            "cross_chain_cve_monitor",
        }
    )

    def trusts_engine(self, engine: str) -> bool:
        """Return True only for engines that actually belong to this domain.

        Prevents poisoning attacks where malicious peer findings claim
        the security domain but originate from arbitrary engines.
        """
        return engine in self._TRUSTED_ENGINES
