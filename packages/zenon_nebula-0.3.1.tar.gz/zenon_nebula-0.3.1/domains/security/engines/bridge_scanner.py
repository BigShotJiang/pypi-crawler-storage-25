# SPDX-License-Identifier: MIT
"""
BridgeScanner -- Static security analysis for bridge contracts and orchestrator.

Scans HyperCore-Team repos for common smart contract vulnerabilities using
regex-based pattern matching (no LLM, no AST — pure structural analysis):

Solidity (evm-bridge-contracts):
    - Reentrancy patterns (external calls before state changes)
    - Unchecked external calls (low-level .call without success check)
    - Access control gaps (missing onlyOwner / onlyRole modifiers)
    - Token approval issues (unsafe approve patterns, missing zero-first)
    - Uninitialized proxy storage (delegatecall without initializer guard)

Go (orchestrator):
    - Signing key management (hardcoded keys, unsafe key storage)
    - Relay security (missing signature verification, replay vectors)
    - Stuck transaction handling (missing timeout/retry, unbounded queues)
"""

import logging
import os
import re
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

EVM_BRIDGE_DIR = ZENON_WORKSPACE / "HyperCore-Team" / "evm-bridge-contracts"
ORCHESTRATOR_DIR = ZENON_WORKSPACE / "HyperCore-Team" / "orchestrator"

# ---------------------------------------------------------------------------
# Solidity vulnerability patterns
# ---------------------------------------------------------------------------

# Reentrancy: external call (.call, .transfer, .send) before state change
EXTERNAL_CALL_RE = re.compile(
    r"\.(call|delegatecall|staticcall|transfer|send)\s*[\({]",
)
STATE_CHANGE_AFTER_CALL_RE = re.compile(
    r"(balances?\[|_balances?\[|totalSupply|mapping\s*\(|\.balance\s*[+\-=])",
)

# Unchecked low-level call: (bool success, ) = addr.call{...}(...) without
# require(success)
UNCHECKED_CALL_RE = re.compile(
    r"\.\s*call\s*\{[^}]*\}\s*\([^)]*\)\s*;",
)
SUCCESS_CHECK_RE = re.compile(
    r"require\s*\(\s*success",
)

# Missing access control: public/external function with no modifier
PUBLIC_FUNC_RE = re.compile(
    r"function\s+(\w+)\s*\([^)]*\)\s+(external|public)\b([^{]*)\{",
)
ACCESS_MODIFIERS = re.compile(
    r"(onlyOwner|onlyRole|onlyAdmin|onlyMinter|onlyGuardian|whenNotPaused|"
    r"onlyGovernor|onlyRelayer|onlyOperator|nonReentrant|initializer)",
)

# Unsafe approve: approve without setting to 0 first
UNSAFE_APPROVE_RE = re.compile(
    r"\.approve\s*\(\s*\w+\s*,\s*(?!0\b)",
)

# tx.origin used for auth (phishing vector)
TX_ORIGIN_RE = re.compile(r"\btx\.origin\b")

# selfdestruct (dangerous)
SELFDESTRUCT_RE = re.compile(r"\bselfdestruct\b")

# ---------------------------------------------------------------------------
# Go (orchestrator) vulnerability patterns
# ---------------------------------------------------------------------------

# Hardcoded private keys
HARDCODED_KEY_RE = re.compile(
    r'(privateKey|privKey|secret|signingKey)\s*[:=]\s*["\']([0-9a-fA-F]{64})["\']',
    re.IGNORECASE,
)

# Unsafe key from environment without validation
UNSAFE_KEY_ENV_RE = re.compile(
    r'os\.Getenv\s*\(\s*["\'].*(?:KEY|SECRET|PRIVATE).*["\']\s*\)',
    re.IGNORECASE,
)

# Missing signature verification in message handlers
MSG_HANDLER_RE = re.compile(
    r"func\s+\(\w+\s+\*?\w+\)\s+(Handle|Process|On)\w+\s*\(",
)
SIG_VERIFY_RE = re.compile(
    r"(Verify|VerifySignature|VerifySig|ecrecover|crypto\.Verify|"
    r"ed25519\.Verify|ecdsa\.Verify)",
)

# Unbounded queue / channel without cap
UNBOUNDED_CHAN_RE = re.compile(r"make\s*\(\s*chan\s+[^,)]+\)")  # chan without buffer size
UNBOUNDED_APPEND_RE = re.compile(
    r"append\s*\(\s*\w+\s*,",  # append without cap check nearby
)

# Missing timeout on HTTP/RPC calls
HTTP_NO_TIMEOUT_RE = re.compile(
    r"http\.(Get|Post|Do)\s*\(",
)
CLIENT_TIMEOUT_RE = re.compile(
    r"Timeout\s*:\s*\d+",
)

# Replay protection: nonce or sequence check
REPLAY_KEYWORDS = re.compile(
    r"(nonce|sequence|replay|idempoten)",
    re.IGNORECASE,
)


class BridgeFinding:
    """A bridge security finding."""

    def __init__(
        self,
        check: str,
        severity: str,
        title: str,
        description: str,
        file_path: str,
        line_number: int,
        source_repo: str,
    ):
        self.check = check
        self.severity = severity
        self.title = title
        self.description = description
        self.file_path = file_path
        self.line_number = line_number
        self.source_repo = source_repo

    def to_dict(self) -> dict:
        """Serialize finding to dict."""
        return {
            "check": self.check,
            "severity": self.severity,
            "title": self.title,
            "description": self.description,
            "file_path": self.file_path,
            "line_number": self.line_number,
            "source_repo": self.source_repo,
        }


# ---------------------------------------------------------------------------
# Solidity scanners
# ---------------------------------------------------------------------------


def _read_file(filepath: Path, max_bytes: int = 500_000) -> str:
    """Read file text, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def scan_sol_reentrancy(file_path: Path, lines: list[str], source_repo: str) -> list[BridgeFinding]:
    """Detect potential reentrancy: external call before state update."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))

    in_function = False
    func_name = ""
    func_start = 0
    saw_external_call = False
    external_call_line = 0

    for i, line in enumerate(lines, start=1):
        # Track function boundaries (simplified)
        func_match = PUBLIC_FUNC_RE.search(line)
        if func_match:
            in_function = True
            func_name = func_match.group(1)
            func_start = i
            saw_external_call = False
            external_call_line = 0

        if in_function:
            if EXTERNAL_CALL_RE.search(line):
                saw_external_call = True
                external_call_line = i

            if saw_external_call and STATE_CHANGE_AFTER_CALL_RE.search(line):
                # Check if nonReentrant modifier is present
                func_header = " ".join(lines[max(0, func_start - 1) : func_start + 3])
                if not ACCESS_MODIFIERS.search(func_header) or "nonReentrant" not in func_header:
                    findings.append(
                        BridgeFinding(
                            check="reentrancy",
                            severity="critical",
                            title=f"Potential reentrancy in {func_name}()",
                            description=(
                                f"External call at line {external_call_line} followed "
                                f"by state change at line {i}. No nonReentrant guard "
                                f"detected."
                            ),
                            file_path=rel,
                            line_number=external_call_line,
                            source_repo=source_repo,
                        )
                    )

    return findings


def scan_sol_unchecked_calls(
    file_path: Path, lines: list[str], source_repo: str
) -> list[BridgeFinding]:
    """Detect unchecked low-level .call returns."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))

    for i, line in enumerate(lines, start=1):
        if ".call{" in line or ".call(" in line:
            # Look in a 5-line window for success check
            window = "\n".join(lines[max(0, i - 1) : min(len(lines), i + 5)])
            if not SUCCESS_CHECK_RE.search(window) and "success" not in window.lower():
                findings.append(
                    BridgeFinding(
                        check="unchecked_call",
                        severity="high",
                        title="Unchecked low-level call return value",
                        description=(
                            f"Low-level .call at line {i} without apparent "
                            f"success check in nearby code."
                        ),
                        file_path=rel,
                        line_number=i,
                        source_repo=source_repo,
                    )
                )

    return findings


def scan_sol_access_control(
    file_path: Path, lines: list[str], source_repo: str
) -> list[BridgeFinding]:
    """Detect public/external functions missing access control modifiers."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))
    content = "\n".join(lines)

    for match in PUBLIC_FUNC_RE.finditer(content):
        func_name = match.group(1)
        modifiers_section = match.group(3)

        # Skip view/pure functions (read-only)
        if re.search(r"\b(view|pure)\b", modifiers_section):
            continue
        # Skip constructor, fallback, receive
        if func_name in ("constructor", "fallback", "receive", "_fallback"):
            continue

        if not ACCESS_MODIFIERS.search(modifiers_section):
            line_num = content[: match.start()].count("\n") + 1
            findings.append(
                BridgeFinding(
                    check="missing_access_control",
                    severity="high",
                    title=f"No access modifier on {func_name}()",
                    description=(
                        f"Public/external function {func_name}() has no access "
                        f"control modifier (onlyOwner, onlyRole, etc.)."
                    ),
                    file_path=rel,
                    line_number=line_num,
                    source_repo=source_repo,
                )
            )

    return findings


def scan_sol_token_approval(
    file_path: Path, lines: list[str], source_repo: str
) -> list[BridgeFinding]:
    """Detect unsafe token approval patterns."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))

    for i, line in enumerate(lines, start=1):
        if UNSAFE_APPROVE_RE.search(line):
            findings.append(
                BridgeFinding(
                    check="unsafe_approve",
                    severity="medium",
                    title="Token approve without zero-first pattern",
                    description=(
                        f"approve() called at line {i} without first setting "
                        f"allowance to 0. This can be front-run on some ERC20 "
                        f"implementations."
                    ),
                    file_path=rel,
                    line_number=i,
                    source_repo=source_repo,
                )
            )

        if TX_ORIGIN_RE.search(line):
            findings.append(
                BridgeFinding(
                    check="tx_origin_auth",
                    severity="high",
                    title="tx.origin used (phishing vector)",
                    description=(
                        f"tx.origin at line {i} can be exploited via phishing "
                        f"contracts. Use msg.sender instead."
                    ),
                    file_path=rel,
                    line_number=i,
                    source_repo=source_repo,
                )
            )

        if SELFDESTRUCT_RE.search(line):
            findings.append(
                BridgeFinding(
                    check="selfdestruct",
                    severity="critical",
                    title="selfdestruct present in contract",
                    description=(
                        f"selfdestruct at line {i} allows contract destruction "
                        f"and fund sweeping. Verify access control."
                    ),
                    file_path=rel,
                    line_number=i,
                    source_repo=source_repo,
                )
            )

    return findings


def scan_solidity_file(file_path: Path, source_repo: str) -> list[BridgeFinding]:
    """Run all Solidity security checks on a single file."""
    text = _read_file(file_path)
    if not text:
        return []

    lines = text.split("\n")
    findings = []
    findings.extend(scan_sol_reentrancy(file_path, lines, source_repo))
    findings.extend(scan_sol_unchecked_calls(file_path, lines, source_repo))
    findings.extend(scan_sol_access_control(file_path, lines, source_repo))
    findings.extend(scan_sol_token_approval(file_path, lines, source_repo))
    return findings


# ---------------------------------------------------------------------------
# Go (orchestrator) scanners
# ---------------------------------------------------------------------------


def scan_go_key_management(
    file_path: Path, lines: list[str], source_repo: str
) -> list[BridgeFinding]:
    """Detect hardcoded keys and unsafe key handling."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))

    for i, line in enumerate(lines, start=1):
        if HARDCODED_KEY_RE.search(line):
            findings.append(
                BridgeFinding(
                    check="hardcoded_key",
                    severity="critical",
                    title="Hardcoded private key detected",
                    description=(
                        f"Private key appears hardcoded at line {i}. Keys must "
                        f"be loaded from secure storage, never embedded in source."
                    ),
                    file_path=rel,
                    line_number=i,
                    source_repo=source_repo,
                )
            )

        if UNSAFE_KEY_ENV_RE.search(line):
            # Check if there is validation nearby
            window = "\n".join(lines[max(0, i - 1) : min(len(lines), i + 5)])
            if "len(" not in window and '!= ""' not in window and '== ""' not in window:
                findings.append(
                    BridgeFinding(
                        check="unvalidated_key_env",
                        severity="medium",
                        title="Environment key loaded without validation",
                        description=(
                            f"Key loaded from environment at line {i} without "
                            f"apparent length or emptiness validation."
                        ),
                        file_path=rel,
                        line_number=i,
                        source_repo=source_repo,
                    )
                )

    return findings


def scan_go_relay_security(
    file_path: Path, lines: list[str], source_repo: str
) -> list[BridgeFinding]:
    """Detect missing signature verification in message handlers."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))
    content = "\n".join(lines)

    for match in MSG_HANDLER_RE.finditer(content):
        match.group(1) + match.group(0).split(match.group(1))[1].split("(")[0]
        func_start = content[: match.start()].count("\n") + 1

        # Get the function body (next 50 lines or until next func)
        func_body = "\n".join(lines[func_start - 1 : min(len(lines), func_start + 50)])

        if not SIG_VERIFY_RE.search(func_body):
            findings.append(
                BridgeFinding(
                    check="missing_sig_verify",
                    severity="high",
                    title="No signature verification in handler",
                    description=(
                        f"Message handler at line {func_start} does not appear "
                        f"to verify signatures. Relay messages must be authenticated."
                    ),
                    file_path=rel,
                    line_number=func_start,
                    source_repo=source_repo,
                )
            )

    return findings


def scan_go_stuck_transactions(
    file_path: Path, lines: list[str], source_repo: str
) -> list[BridgeFinding]:
    """Detect patterns that could lead to stuck transactions."""
    findings = []
    rel = str(file_path.relative_to(ZENON_WORKSPACE))

    for i, line in enumerate(lines, start=1):
        # Unbounded channel
        if UNBOUNDED_CHAN_RE.search(line) and "," not in line.split("chan")[1].split(")")[0]:
            findings.append(
                BridgeFinding(
                    check="unbounded_channel",
                    severity="medium",
                    title="Unbounded channel (potential memory leak)",
                    description=(
                        f"Channel at line {i} appears unbuffered or unbounded. "
                        f"Under load this can block goroutines or exhaust memory."
                    ),
                    file_path=rel,
                    line_number=i,
                    source_repo=source_repo,
                )
            )

        # HTTP call without timeout
        if HTTP_NO_TIMEOUT_RE.search(line):
            window = "\n".join(lines[max(0, i - 10) : i])
            if not CLIENT_TIMEOUT_RE.search(window):
                findings.append(
                    BridgeFinding(
                        check="http_no_timeout",
                        severity="medium",
                        title="HTTP call without explicit timeout",
                        description=(
                            f"HTTP call at line {i} with no timeout visible in "
                            f"the client setup. Can block indefinitely."
                        ),
                        file_path=rel,
                        line_number=i,
                        source_repo=source_repo,
                    )
                )

    # File-level check: does this file handle transactions but lack retry logic?
    content_lower = "\n".join(lines).lower()
    if "transaction" in content_lower or "sendtx" in content_lower:
        if not re.search(r"(retry|backoff|attempt|max.?retries)", content_lower):
            findings.append(
                BridgeFinding(
                    check="no_retry_logic",
                    severity="low",
                    title="Transaction handling without retry logic",
                    description=(
                        "File handles transactions but has no apparent retry "
                        "or backoff logic. Failed transactions may be lost."
                    ),
                    file_path=rel,
                    line_number=1,
                    source_repo=source_repo,
                )
            )

    # File-level: does this file lack replay protection?
    if "message" in content_lower or "event" in content_lower:
        if not REPLAY_KEYWORDS.search("\n".join(lines)):
            findings.append(
                BridgeFinding(
                    check="no_replay_protection",
                    severity="medium",
                    title="Message/event handling without replay protection",
                    description=(
                        "File handles messages/events but has no apparent "
                        "nonce, sequence, or replay protection."
                    ),
                    file_path=rel,
                    line_number=1,
                    source_repo=source_repo,
                )
            )

    return findings


def scan_go_file(file_path: Path, source_repo: str) -> list[BridgeFinding]:
    """Run all Go security checks on a single file."""
    text = _read_file(file_path)
    if not text:
        return []

    lines = text.split("\n")
    findings = []
    findings.extend(scan_go_key_management(file_path, lines, source_repo))
    findings.extend(scan_go_relay_security(file_path, lines, source_repo))
    findings.extend(scan_go_stuck_transactions(file_path, lines, source_repo))
    return findings


# ---------------------------------------------------------------------------
# Top-level scanners
# ---------------------------------------------------------------------------


def scan_evm_bridge_contracts() -> list[dict]:
    """Scan all Solidity files in evm-bridge-contracts.

    Returns list of finding dicts.
    """
    if not EVM_BRIDGE_DIR.is_dir():
        logger.info("BridgeScanner: evm-bridge-contracts not found at %s", EVM_BRIDGE_DIR)
        return []

    all_findings = []
    for sol_file in EVM_BRIDGE_DIR.rglob("*.sol"):
        rel = str(sol_file.relative_to(ZENON_WORKSPACE))
        # Skip test files and node_modules
        if "node_modules" in rel or "test" in rel.lower() or "mock" in rel.lower():
            continue
        findings = scan_solidity_file(sol_file, "HyperCore-Team/evm-bridge-contracts")
        all_findings.extend(findings)

    logger.info(
        "BridgeScanner: scanned evm-bridge-contracts, %d findings",
        len(all_findings),
    )
    return [f.to_dict() for f in all_findings]


def scan_orchestrator() -> list[dict]:
    """Scan all Go files in orchestrator.

    Returns list of finding dicts.
    """
    if not ORCHESTRATOR_DIR.is_dir():
        logger.info("BridgeScanner: orchestrator not found at %s", ORCHESTRATOR_DIR)
        return []

    all_findings = []
    for go_file in ORCHESTRATOR_DIR.rglob("*.go"):
        rel = str(go_file.relative_to(ZENON_WORKSPACE))
        # Skip test files and vendor
        if "vendor" in rel or "_test.go" in rel:
            continue
        findings = scan_go_file(go_file, "HyperCore-Team/orchestrator")
        all_findings.extend(findings)

    logger.info(
        "BridgeScanner: scanned orchestrator, %d findings",
        len(all_findings),
    )
    return [f.to_dict() for f in all_findings]


def scan_all() -> dict:
    """Run full bridge security scan across all repos.

    Returns dict with evm_findings, orchestrator_findings, and summary.
    """
    evm_findings = scan_evm_bridge_contracts()
    orchestrator_findings = scan_orchestrator()

    # Categorize by severity
    all_findings = evm_findings + orchestrator_findings
    severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for f in all_findings:
        sev = f.get("severity", "low")
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    return {
        "evm_findings": evm_findings,
        "orchestrator_findings": orchestrator_findings,
        "total_findings": len(all_findings),
        "severity_counts": severity_counts,
        "evm_bridge_exists": EVM_BRIDGE_DIR.is_dir(),
        "orchestrator_exists": ORCHESTRATOR_DIR.is_dir(),
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run full bridge scan and persist all findings.

    Returns the number of findings persisted.
    """
    ensure_schema(db_path)
    report = scan_all()
    count = 0

    # Summary finding
    crit = report["severity_counts"].get("critical", 0)
    high = report["severity_counts"].get("high", 0)
    total = report["total_findings"]
    evm_present = report["evm_bridge_exists"]
    orch_present = report["orchestrator_exists"]
    persist_finding(
        db_path=db_path,
        domain="security",
        engine="bridge_scanner",
        evidence_type="bridge_security_scan",
        finding=(
            f"WHAT: Bridge security scan found {total} issues "
            f"({crit} critical, {high} high). "
            f"EVM bridge: {'present' if evm_present else 'NOT FOUND'}. "
            f"Orchestrator: {'present' if orch_present else 'NOT FOUND'}. "
            f"SO WHAT: {'Critical/high findings indicate exploitable bridge vulnerabilities that risk user funds. ' if crit or high else ''}"
            f"{'Missing repos mean bridge code cannot be audited. ' if not evm_present or not orch_present else ''}"
            f"{'No critical or high issues found in scanned bridge code. ' if not crit and not high and evm_present and orch_present else ''}"
            f"NOW WHAT: {f'Fix {crit + high} critical/high findings before any bridge deployment. ' if crit or high else ''}"
            f"{'Clone missing bridge repos into HyperCore-Team/. ' if not evm_present or not orch_present else ''}"
            f"{'Review medium/low findings for defense-in-depth improvements.' if not crit and not high else ''}"
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Individual findings
    for finding_dict in report["evm_findings"] + report["orchestrator_findings"]:
        sev = finding_dict["severity"].upper()
        title = finding_dict["title"]
        fpath = finding_dict["file_path"]
        line = finding_dict["line_number"]
        desc = finding_dict.get("description", "")
        check = finding_dict["check"]

        # Derive actionable NOW WHAT from check type
        remediation = {
            "reentrancy": "Add nonReentrant modifier or move state changes before external calls.",
            "unchecked_call": "Check the return value with require(success) after the .call.",
            "missing_access_control": "Add an access control modifier (onlyOwner, onlyRole, etc.).",
            "unsafe_approve": "Set allowance to 0 before approving a new amount.",
            "tx_origin_auth": "Replace tx.origin with msg.sender for authorization.",
            "selfdestruct": "Remove selfdestruct or verify it is behind strict access control.",
            "hardcoded_key": "Move private key to secure storage (env var, vault, keystore).",
            "unvalidated_key_env": "Add length/emptiness validation after reading the key from env.",
            "missing_sig_verify": "Add signature verification before processing the message.",
            "unbounded_channel": "Add a buffer size to the channel: make(chan T, bufSize).",
            "http_no_timeout": "Set an explicit Timeout on the HTTP client.",
            "no_retry_logic": "Add retry with exponential backoff for transaction submissions.",
            "no_replay_protection": "Add nonce or sequence-based replay protection.",
        }.get(check, f"Review and fix the {check} issue.")

        persist_finding(
            db_path=db_path,
            domain="security",
            engine="bridge_scanner",
            evidence_type=f"bridge_{check}",
            finding=(
                f"WHAT: [{sev}] {title} at {fpath}:{line}. SO WHAT: {desc} NOW WHAT: {remediation}"
            ),
            confidence=0.75 if finding_dict["severity"] in ("critical", "high") else 0.60,
            raw_data=finding_dict,
            source_repo=finding_dict.get("source_repo"),
            source_file=finding_dict.get("file_path"),
        )
        count += 1

    logger.info("BridgeScanner: persisted %d findings", count)
    return count
