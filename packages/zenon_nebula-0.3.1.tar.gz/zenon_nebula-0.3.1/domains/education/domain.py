# SPDX-License-Identifier: MIT
"""
EducationDomain -- DomainPlugin for documentation quality and developer onboarding.

Provides engines for checking documentation completeness across specs,
SDKs, and CLIs, and for evaluating the developer onboarding experience.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class EducationDomain(DomainPlugin):
    """Education domain plugin -- documentation and onboarding analysis."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "education"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Documentation quality assessment, wiki coverage tracking, "
            "SDK API doc completeness, and developer onboarding experience."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 5

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="doc_quality",
                description=(
                    "Checks documentation completeness: spec-to-wiki coverage, "
                    "SDK API doc comments, CLI help descriptions."
                ),
                module_path="domains.education.engines.doc_quality",
                priority=4,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=90,
            ),
            EngineDefinition(
                name="onboarding_tracker",
                description=(
                    "Evaluates developer onboarding: README presence, build "
                    "instructions, CI status, code examples, setup steps."
                ),
                module_path="domains.education.engines.onboarding_tracker",
                priority=3,
                tier=2,
                required_apis=["filesystem", "github_api"],
                max_runtime_seconds=120,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="docs_complete",
                label="Documentation is complete for all contracts",
                description=(
                    "Every implemented contract has a wiki page, API reference, and code examples."
                ),
                initial_confidence=0.2,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="onboarding_smooth",
                label="Developer onboarding is smooth",
                description=(
                    "A new developer can go from git clone to running node with minimal friction."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="zero_undocumented",
                label="Zero undocumented contracts",
                description=(
                    "Every spec with an implementation should have a "
                    "corresponding wiki page and SDK API documentation."
                ),
                priority=4,
                deadline_days=120,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="undocumented_contract",
                label="Undocumented contract detected",
                description=(
                    "Development domain shows a contract is implemented but "
                    "Education domain shows no documentation exists."
                ),
                source_domains=["education", "development"],
                convergence_threshold=0.6,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="education",
                section_title="Documentation Coverage",
                metrics=[
                    "doc_quality_grade",
                    "wiki_coverage_pct",
                    "sdk_doc_pct",
                    "undocumented_specs",
                ],
                recommendations_prompt=(
                    "Based on documentation gaps, which specs or contracts "
                    "most urgently need documentation?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "doc_coverage_pct": 0.0,
            "onboarding_score": 0.0,
            "wiki_coverage_pct": 0.0,
        }

    def decide_next_action(self, context: dict) -> dict | None:
        """Decide the highest-value next action given current state."""
        stale = context.get("stale_data", [])
        if "docs" in stale:
            return {
                "action": "refresh_doc_quality",
                "reason": "Documentation quality data is stale.",
                "priority": 6,
                "engine": "doc_quality",
            }
        if "onboarding" in stale:
            return {
                "action": "refresh_onboarding",
                "reason": "Onboarding assessment is stale.",
                "priority": 6,
                "engine": "onboarding_tracker",
            }
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return ""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Education domain registered with %d engines.",
            len(self.get_engines()),
        )
