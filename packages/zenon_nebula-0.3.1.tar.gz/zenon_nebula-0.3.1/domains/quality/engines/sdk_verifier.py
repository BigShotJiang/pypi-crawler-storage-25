# SPDX-License-Identifier: MIT
"""
SDKVerifier -- Multi-SDK build verification and ABI consistency check.

Covers SDKs beyond the primary Dart SDK:
    - C# (znn_sdk_csharp)    : dotnet build
    - Rust (znn_sdk_rust)     : cargo build
    - Java (znn_sdk_java)     : mvn compile / gradle build
    - PHP (znn-php)           : php -l per file

For each SDK:
    1. Locate the repo via workspace_discovery
    2. Detect which build tool is available
    3. Attempt a build (or syntax check)
    4. Scan for ABI method name constants and compare against go-zenon
    5. Persist pass/fail and any ABI mismatches
"""

import logging
import os
import re
import subprocess
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# SDK configurations: name -> possible repo paths (relative to workspace)
SDK_CONFIGS = {
    "znn_sdk_csharp": {
        "paths": [
            "community-sdks/znn_sdk_csharp",
            "zenon-network/znn_sdk_csharp",
            "hypercore-one/znn_sdk_csharp",
        ],
        "language": "csharp",
        "build_commands": [
            ("dotnet build", "build"),
            ("dotnet restore", "restore"),
        ],
        "file_glob": "**/*.cs",
        "abi_pattern": re.compile(
            r'(?:MethodName|method|Method)\s*[:=]\s*["\'](\w+)["\']',
        ),
    },
    "znn_sdk_rust": {
        "paths": [
            "community-sdks/znn_sdk_rust",
            "zenon-network/znn_sdk_rust",
        ],
        "language": "rust",
        "build_commands": [
            ("cargo check", "check"),
            ("cargo build", "build"),
        ],
        "file_glob": "**/*.rs",
        "abi_pattern": re.compile(
            r'(?:method_name|METHOD|method)\s*[:=]\s*"(\w+)"',
        ),
    },
    "znn_sdk_java": {
        "paths": [
            "community-sdks/znn_sdk_java",
            "zenon-network/znn_sdk_java",
        ],
        "language": "java",
        "build_commands": [
            ("mvn compile -q", "maven"),
            ("gradle build -q", "gradle"),
        ],
        "file_glob": "**/*.java",
        "abi_pattern": re.compile(
            r'(?:METHOD_NAME|methodName|method)\s*[:=]\s*"(\w+)"',
        ),
    },
    "znn-php": {
        "paths": [
            "community-sdks/znn-php",
            "digitalSloth/znn-php",
        ],
        "language": "php",
        "build_commands": [],  # PHP uses per-file lint
        "file_glob": "**/*.php",
        "abi_pattern": re.compile(
            r"['\"](\w+)['\"]\s*=>\s*.*(?:method|abi|function)",
            re.IGNORECASE,
        ),
    },
}

# ABI method names from go-zenon embedded contracts (ground truth)
GO_ZENON_DEFINITION_DIR_CANDIDATES = [
    ZENON_WORKSPACE / "core" / "go-zenon" / "vm" / "embedded" / "definition",
    ZENON_WORKSPACE / "zenon-network" / "go-zenon" / "vm" / "embedded" / "definition",
    ZENON_WORKSPACE / "hypercore-one" / "go-zenon" / "vm" / "embedded" / "definition",
]


def _read_file(filepath: Path, max_bytes: int = 500_000) -> str:
    """Read file text, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _run_command(command: str, cwd: Path, timeout: int = 120) -> dict:
    """Run a shell command, return result dict."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return {
            "command": command,
            "success": result.returncode == 0,
            "output": (result.stdout + result.stderr)[:5000],
            "returncode": result.returncode,
        }
    except subprocess.TimeoutExpired:
        return {
            "command": command,
            "success": False,
            "output": f"Timed out after {timeout}s",
            "returncode": -1,
        }
    except FileNotFoundError:
        return {
            "command": command,
            "success": False,
            "output": f"Command not found: {command.split()[0]}",
            "returncode": -1,
        }


def _find_sdk_path(sdk_name: str) -> Path | None:
    """Find the local path for an SDK, checking all candidate locations."""
    config = SDK_CONFIGS.get(sdk_name)
    if not config:
        return None

    for rel_path in config["paths"]:
        full_path = ZENON_WORKSPACE / rel_path
        if full_path.is_dir():
            return full_path

    return None


def _extract_go_zenon_abi_methods() -> dict[str, set[str]]:
    """Extract ABI method names from go-zenon definition files.

    Returns dict mapping contract_name -> set of method names.
    """
    methods: dict[str, set[str]] = {}

    definition_dir = None
    for candidate in GO_ZENON_DEFINITION_DIR_CANDIDATES:
        if candidate.is_dir():
            definition_dir = candidate
            break

    if not definition_dir:
        logger.warning("SDKVerifier: go-zenon definition dir not found")
        return methods

    # Pattern: ABIContractName, _ = abi.JSONToABIContract(... "MethodName" ...)
    method_re = re.compile(r'"Name"\s*:\s*"(\w+)"')

    for go_file in definition_dir.glob("*.go"):
        contract = go_file.stem
        text = _read_file(go_file)
        found = set(method_re.findall(text))
        if found:
            methods[contract] = found

    return methods


def _extract_sdk_abi_methods(sdk_path: Path, sdk_name: str) -> set[str]:
    """Extract ABI method name references from an SDK's source files."""
    config = SDK_CONFIGS.get(sdk_name)
    if not config:
        return set()

    found_methods: set[str] = set()
    abi_pattern = config["abi_pattern"]
    file_glob = config["file_glob"]

    for source_file in sdk_path.glob(file_glob):
        rel = str(source_file.relative_to(sdk_path))
        if any(skip in rel for skip in ["vendor", "node_modules", "test", ".git", "build"]):
            continue
        text = _read_file(source_file)
        matches = abi_pattern.findall(text)
        found_methods.update(matches)

    return found_methods


def check_php_files(sdk_path: Path) -> list[dict]:
    """Lint all PHP files individually."""
    results = []
    for php_file in sdk_path.rglob("*.php"):
        rel = str(php_file.relative_to(sdk_path))
        if "vendor" in rel or ".git" in rel:
            continue
        result = _run_command(f"php -l {php_file}", cwd=sdk_path, timeout=10)
        result["file"] = rel
        results.append(result)
    return results


def verify_sdk(sdk_name: str) -> dict:
    """Verify a single SDK: find it, build it, check ABI consistency.

    Returns a result dict with build_status, abi_comparison, and issues.
    """
    result = {
        "sdk_name": sdk_name,
        "found": False,
        "path": None,
        "language": SDK_CONFIGS[sdk_name]["language"],
        "build_results": [],
        "abi_methods_found": [],
        "abi_mismatches": [],
        "issues": [],
    }

    sdk_path = _find_sdk_path(sdk_name)
    if not sdk_path:
        result["issues"].append("SDK repo not found in workspace")
        return result

    result["found"] = True
    result["path"] = str(sdk_path.relative_to(ZENON_WORKSPACE))

    config = SDK_CONFIGS[sdk_name]

    # Build check
    if config["language"] == "php":
        php_results = check_php_files(sdk_path)
        failures = [r for r in php_results if not r["success"]]
        result["build_results"] = [
            {
                "command": "php -l (per file)",
                "success": len(failures) == 0,
                "files_checked": len(php_results),
                "files_failed": len(failures),
                "failures": [r.get("file", "unknown") for r in failures[:10]],
            }
        ]
        if failures:
            result["issues"].append(f"PHP syntax errors in {len(failures)} files")
    else:
        for cmd, cmd_type in config["build_commands"]:
            build_result = _run_command(cmd, cwd=sdk_path)
            build_result["command_type"] = cmd_type
            result["build_results"].append(build_result)
            if build_result["success"]:
                break  # First successful build is enough
        else:
            if config["build_commands"]:
                result["issues"].append(f"All build commands failed for {sdk_name}")

    # ABI method comparison
    go_methods = _extract_go_zenon_abi_methods()
    sdk_methods = _extract_sdk_abi_methods(sdk_path, sdk_name)
    result["abi_methods_found"] = sorted(sdk_methods)

    if go_methods and sdk_methods:
        # Flatten go_methods to a single set for comparison
        all_go_methods: set[str] = set()
        for contract_methods in go_methods.values():
            all_go_methods.update(contract_methods)

        # Methods in go-zenon but not in SDK
        missing_in_sdk = all_go_methods - sdk_methods
        # Only flag well-known contract methods, not internal ones
        significant_missing = {m for m in missing_in_sdk if not m.startswith("_") and len(m) > 3}

        if significant_missing:
            result["abi_mismatches"] = sorted(significant_missing)
            result["issues"].append(
                f"{len(significant_missing)} go-zenon ABI methods not "
                f"found in {sdk_name}: {', '.join(sorted(significant_missing)[:10])}"
            )

    return result


def verify_all_sdks() -> dict:
    """Verify all configured SDKs.

    Returns dict mapping sdk_name to verification result.
    """
    results = {}
    for sdk_name in SDK_CONFIGS:
        results[sdk_name] = verify_sdk(sdk_name)
    return results


def generate_report() -> dict:
    """Generate a full SDK verification report with summary."""
    sdk_results = verify_all_sdks()

    found_count = sum(1 for r in sdk_results.values() if r["found"])
    build_pass_count = sum(
        1
        for r in sdk_results.values()
        if r["found"] and any(br.get("success") for br in r.get("build_results", []))
    )
    total_issues = sum(len(r.get("issues", [])) for r in sdk_results.values())

    return {
        "sdks": sdk_results,
        "summary": {
            "total_sdks": len(SDK_CONFIGS),
            "found": found_count,
            "build_passing": build_pass_count,
            "total_issues": total_issues,
        },
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run full SDK verification and persist findings.

    Returns number of findings persisted.
    """
    ensure_schema(db_path)
    report = generate_report()
    count = 0

    summary = report["summary"]
    missing_count = summary["total_sdks"] - summary["found"]
    failing_count = summary["found"] - summary["build_passing"]
    persist_finding(
        db_path=db_path,
        domain="quality",
        engine="sdk_verifier",
        evidence_type="sdk_verification_overall",
        finding=(
            f"WHAT: {summary['found']}/{summary['total_sdks']} SDKs found, "
            f"{summary['build_passing']}/{summary['found']} build passing, "
            f"{summary['total_issues']} issues. "
            f"SO WHAT: {'Missing SDKs cannot be verified for ABI drift. ' if missing_count else ''}"
            f"{'Failing builds block cross-SDK consistency checks. ' if failing_count else ''}"
            f"{'All found SDKs build clean. ' if not failing_count and not missing_count else ''}"
            f"NOW WHAT: {'Clone missing SDK repos into workspace. ' if missing_count else ''}"
            f"{'Fix build failures before checking ABI consistency. ' if failing_count else ''}"
            f"{'Run ABI consistency checks across all SDKs.' if not failing_count else ''}"
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    for sdk_name, sdk_result in report["sdks"].items():
        # Per-SDK finding
        if sdk_result["found"]:
            build_ok = any(br.get("success") for br in sdk_result.get("build_results", []))
            mismatch_count = len(sdk_result.get("abi_mismatches", []))
            abi_count = len(sdk_result.get("abi_methods_found", []))
            persist_finding(
                db_path=db_path,
                domain="quality",
                engine="sdk_verifier",
                evidence_type="sdk_build_status",
                finding=(
                    f"WHAT: {sdk_name} ({sdk_result['language']}) build "
                    f"{'PASS' if build_ok else 'FAIL'}, {abi_count} ABI methods found, "
                    f"{mismatch_count} mismatches. "
                    f"SO WHAT: {'Build failure blocks all further verification. ' if not build_ok else ''}"
                    f"{'ABI mismatches mean SDK clients will send malformed transactions. ' if mismatch_count else ''}"
                    f"{'SDK is consistent with go-zenon ABI. ' if build_ok and not mismatch_count else ''}"
                    f"NOW WHAT: {f'Fix build errors in {sdk_name} first. ' if not build_ok else ''}"
                    f"{'Add missing ABI methods to {sdk_name}: {mismatches}. '.format(sdk_name=sdk_name, mismatches=', '.join(sdk_result.get('abi_mismatches', [])[:5])) if mismatch_count else ''}"
                    f"{'No action needed.' if build_ok and not mismatch_count else ''}"
                ),
                confidence=0.80,
                raw_data=sdk_result,
                source_repo=sdk_result.get("path", sdk_name),
            )
            count += 1

        # Persist each issue separately
        for issue in sdk_result.get("issues", []):
            is_build = "build" in issue.lower() or "syntax" in issue.lower()
            is_abi = "abi" in issue.lower() or "method" in issue.lower()
            persist_finding(
                db_path=db_path,
                domain="quality",
                engine="sdk_verifier",
                evidence_type="sdk_issue",
                finding=(
                    f"WHAT: [{sdk_name}] {issue}. "
                    f"SO WHAT: {'SDK cannot be used until build is fixed. ' if is_build else ''}"
                    f"{'Clients using this SDK will fail on affected contract calls. ' if is_abi else ''}"
                    f"{'This blocks SDK release readiness. ' if not is_build and not is_abi else ''}"
                    f"NOW WHAT: {f'Fix syntax/build errors in {sdk_name}. ' if is_build else ''}"
                    f"{f'Add missing ABI methods from go-zenon definitions to {sdk_name}. ' if is_abi else ''}"
                    f"{f'Investigate and resolve the issue in {sdk_name}. ' if not is_build and not is_abi else ''}"
                ),
                confidence=0.75,
                raw_data={"sdk": sdk_name, "issue": issue},
                source_repo=sdk_result.get("path", sdk_name),
            )
            count += 1

    logger.info("SDKVerifier: persisted %d findings", count)
    return count
