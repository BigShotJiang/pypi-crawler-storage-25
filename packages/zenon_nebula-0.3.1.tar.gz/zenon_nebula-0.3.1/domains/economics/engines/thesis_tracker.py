# SPDX-License-Identifier: MIT
"""
ThesisTracker - Grade the ZNN price-appreciation thesis on-chain.

The thesis has three mechanical levers:

    1. Pillar supply contraction  - new pillar registrations burn QSR
       and lock ZNN, shrinking liquid supply.
    2. Orbital/Plasma fusion      - QSR locked for plasma is removed
       from circulation.
    3. Sentinel commitment        - sentinel registrations lock ZNN
       and burn QSR, same direction.

The engine samples each lever every cycle, stores a snapshot, and
produces a WHAT/SO WHAT/NOW WHAT finding that tells the marketing
domain whether the supply-contraction narrative is accelerating or
decelerating. No LLM calls. No market-price extrapolation. Pure
on-chain mechanics.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from core.persistence import connect
from core.zenon_data import EMBEDDED_ADDRESSES, TOKEN_DECIMALS, get_zenon_data

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Trend comparison window (in prior snapshots).
TREND_WINDOW = 4

# Schema registry: declared here so the schema_registry picks it up.
SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS thesis_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    pillar_count INTEGER NOT NULL,
    sentinel_count INTEGER NOT NULL,
    pillar_znn_locked REAL NOT NULL,
    sentinel_znn_locked REAL NOT NULL,
    stake_znn_locked REAL NOT NULL,
    plasma_qsr_locked REAL NOT NULL,
    az_treasury_znn REAL NOT NULL,
    az_treasury_qsr REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_thesis_ts ON thesis_snapshots(timestamp);
"""


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------


def ensure_schema(db_path: str = DEFAULT_DB) -> None:
    """Create the ``thesis_snapshots`` table if missing."""
    conn = connect(db_path)
    try:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS thesis_snapshots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
                pillar_count INTEGER NOT NULL,
                sentinel_count INTEGER NOT NULL,
                pillar_znn_locked REAL NOT NULL,
                sentinel_znn_locked REAL NOT NULL,
                stake_znn_locked REAL NOT NULL,
                plasma_qsr_locked REAL NOT NULL,
                az_treasury_znn REAL NOT NULL,
                az_treasury_qsr REAL NOT NULL
            )
            """
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Data capture
# ---------------------------------------------------------------------------


@dataclass
class ThesisSnapshot:
    """Normalized on-chain snapshot of the thesis levers."""

    pillar_count: int
    sentinel_count: int
    pillar_znn_locked: float
    sentinel_znn_locked: float
    stake_znn_locked: float
    plasma_qsr_locked: float
    az_treasury_znn: float
    az_treasury_qsr: float

    @property
    def total_znn_locked(self) -> float:
        """Sum of ZNN removed from liquid circulation across all levers."""
        return self.pillar_znn_locked + self.sentinel_znn_locked + self.stake_znn_locked


def capture_snapshot() -> ThesisSnapshot | None:
    """Capture a fresh snapshot from the Zenon node.

    Returns ``None`` when the node is unreachable so callers can
    short-circuit without fabricating data.
    """
    rpc = get_zenon_data()
    if not rpc.is_reachable():
        return None

    pillar_count = rpc.get_pillar_count() or 0
    sentinel_count = rpc.get_sentinel_count() or 0

    pillar_balance = rpc.get_balance(EMBEDDED_ADDRESSES["pillar"])
    sentinel_balance = rpc.get_balance(EMBEDDED_ADDRESSES["sentinel"])
    stake_balance = rpc.get_balance(EMBEDDED_ADDRESSES["stake"])
    plasma_balance = rpc.get_balance(EMBEDDED_ADDRESSES["plasma"])
    az_balance = rpc.get_az_balance()

    return ThesisSnapshot(
        pillar_count=int(pillar_count),
        sentinel_count=int(sentinel_count),
        pillar_znn_locked=pillar_balance["znn"] / TOKEN_DECIMALS,
        sentinel_znn_locked=sentinel_balance["znn"] / TOKEN_DECIMALS,
        stake_znn_locked=stake_balance["znn"] / TOKEN_DECIMALS,
        plasma_qsr_locked=plasma_balance["qsr"] / TOKEN_DECIMALS,
        az_treasury_znn=az_balance["znn"] / TOKEN_DECIMALS,
        az_treasury_qsr=az_balance["qsr"] / TOKEN_DECIMALS,
    )


def persist_snapshot(
    snapshot: ThesisSnapshot,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Persist a snapshot and return its row id."""
    ensure_schema(db_path)
    from core.persist_to_db import persist_metric

    return persist_metric(
        db_path=db_path,
        table="thesis_snapshots",
        data={
            "pillar_count": snapshot.pillar_count,
            "sentinel_count": snapshot.sentinel_count,
            "pillar_znn_locked": snapshot.pillar_znn_locked,
            "sentinel_znn_locked": snapshot.sentinel_znn_locked,
            "stake_znn_locked": snapshot.stake_znn_locked,
            "plasma_qsr_locked": snapshot.plasma_qsr_locked,
            "az_treasury_znn": snapshot.az_treasury_znn,
            "az_treasury_qsr": snapshot.az_treasury_qsr,
        },
    )


# ---------------------------------------------------------------------------
# Trend analysis
# ---------------------------------------------------------------------------


@dataclass
class ThesisTrend:
    """Change between the latest snapshot and the previous window."""

    pillar_count_delta: int
    sentinel_count_delta: int
    znn_locked_delta: float
    qsr_locked_delta: float
    window: int

    @property
    def direction(self) -> str:
        """Return ``acceleration``/``deceleration``/``flat``."""
        contraction = self.znn_locked_delta + (self.qsr_locked_delta / 10.0)
        if contraction > 1000:
            return "acceleration"
        if contraction < -1000:
            return "deceleration"
        return "flat"


def compute_trend(
    current: ThesisSnapshot,
    *,
    db_path: str = DEFAULT_DB,
    window: int = TREND_WINDOW,
) -> ThesisTrend | None:
    """Compare ``current`` against the previous ``window`` snapshots."""
    ensure_schema(db_path)
    from core.persist_to_db import query_table

    rows = query_table(
        db_path=db_path,
        table="thesis_snapshots",
        order_by="timestamp DESC",
        limit=window + 1,
    )
    if len(rows) < 2:
        return None
    previous = rows[-1]
    prev_znn = (
        float(previous["pillar_znn_locked"] or 0)
        + float(previous["sentinel_znn_locked"] or 0)
        + float(previous["stake_znn_locked"] or 0)
    )
    return ThesisTrend(
        pillar_count_delta=current.pillar_count - int(previous["pillar_count"] or 0),
        sentinel_count_delta=current.sentinel_count - int(previous["sentinel_count"] or 0),
        znn_locked_delta=round(current.total_znn_locked - prev_znn, 2),
        qsr_locked_delta=round(
            current.plasma_qsr_locked - float(previous["plasma_qsr_locked"] or 0),
            2,
        ),
        window=min(len(rows) - 1, window),
    )


# ---------------------------------------------------------------------------
# Finding builder
# ---------------------------------------------------------------------------


def _build_finding(
    snapshot: ThesisSnapshot,
    trend: ThesisTrend | None,
) -> str:
    """Return the WHAT/SO WHAT/NOW WHAT finding text."""
    what = (
        f"Thesis snapshot: {snapshot.pillar_count} pillars locking "
        f"{snapshot.pillar_znn_locked:,.0f} ZNN, "
        f"{snapshot.sentinel_count} sentinels locking "
        f"{snapshot.sentinel_znn_locked:,.0f} ZNN, "
        f"stake contract holds {snapshot.stake_znn_locked:,.0f} ZNN, "
        f"plasma contract holds {snapshot.plasma_qsr_locked:,.0f} QSR. "
        f"Total ZNN locked: {snapshot.total_znn_locked:,.0f}."
    )
    if trend is None:
        so_what = (
            "First thesis snapshot this deployment. Future cycles will "
            "compare against this baseline to detect acceleration or "
            "deceleration of the supply-contraction thesis."
        )
        now_what = (
            "Action: no immediate action. Capture another snapshot next "
            "cycle to begin trend analysis."
        )
    else:
        direction = trend.direction
        so_what_parts = [
            f"Over the last {trend.window} snapshots, pillar count "
            f"changed by {trend.pillar_count_delta:+d}, sentinel count "
            f"by {trend.sentinel_count_delta:+d}, ZNN locked by "
            f"{trend.znn_locked_delta:+,.0f}, plasma QSR locked by "
            f"{trend.qsr_locked_delta:+,.0f}."
        ]
        if direction == "acceleration":
            so_what_parts.append(
                "Supply contraction is ACCELERATING - more tokens are "
                "being removed from liquid circulation than in previous "
                "windows. This is a tailwind for ZNN price."
            )
            now_what = (
                "Action: marketing should amplify the supply-contraction "
                "narrative with a dated post. Flag to War Room as "
                "high-alignment with the adoption_growth and "
                "narrative_dominance pillars."
            )
        elif direction == "deceleration":
            so_what_parts.append(
                "Supply contraction is DECELERATING - tokens are being "
                "released back into circulation. Investigate whether "
                "registrations are expiring or delegators are unwinding."
            )
            now_what = (
                "Action: cross-reference with pillar_monitor to find "
                "operators leaving; adjust messaging from 'contraction' "
                "to 'retention campaign' if needed."
            )
        else:
            so_what_parts.append(
                "Supply contraction is flat - no material change in liquid float. Steady state."
            )
            now_what = "Action: continue monitoring; no campaign pivot needed."
        so_what = " ".join(so_what_parts)
    return f"WHAT: {what} SO WHAT: {so_what} NOW WHAT: {now_what}"


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


def run_thesis_tracker(*, db_path: str = DEFAULT_DB) -> dict:
    """Run one thesis-tracking cycle end to end.

    Returns a status dict with the snapshot values, trend info, and
    the persisted finding id. Safe to call on every cycle.
    """
    from core.persist_to_db import ensure_schema as ensure_core_schema
    from core.persist_to_db import persist_finding

    ensure_core_schema(db_path)
    ensure_schema(db_path)

    snapshot = capture_snapshot()
    if snapshot is None:
        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="thesis_tracker",
            evidence_type="thesis_error",
            finding=(
                "WHAT: Failed to capture thesis snapshot from Zenon RPC. "
                "SO WHAT: Cannot measure supply contraction levers this "
                "cycle. "
                "NOW WHAT: Check ZENON_PUBLIC_RPC connectivity. Retry "
                "next cycle."
            ),
            confidence=0.50,
            source_repo="zenon_rpc",
        )
        return {"success": False, "error": "node_unreachable"}

    snapshot_id = persist_snapshot(snapshot, db_path=db_path)
    trend = compute_trend(snapshot, db_path=db_path)
    finding_text = _build_finding(snapshot, trend)

    persist_finding(
        db_path=db_path,
        domain="economics",
        engine="thesis_tracker",
        evidence_type="thesis_snapshot",
        finding=finding_text,
        confidence=0.80,
        raw_data={
            "snapshot": {
                "pillar_count": snapshot.pillar_count,
                "sentinel_count": snapshot.sentinel_count,
                "pillar_znn_locked": snapshot.pillar_znn_locked,
                "sentinel_znn_locked": snapshot.sentinel_znn_locked,
                "stake_znn_locked": snapshot.stake_znn_locked,
                "plasma_qsr_locked": snapshot.plasma_qsr_locked,
                "total_znn_locked": snapshot.total_znn_locked,
                "az_treasury_znn": snapshot.az_treasury_znn,
                "az_treasury_qsr": snapshot.az_treasury_qsr,
            },
            "trend": None
            if trend is None
            else {
                "direction": trend.direction,
                "window": trend.window,
                "pillar_count_delta": trend.pillar_count_delta,
                "sentinel_count_delta": trend.sentinel_count_delta,
                "znn_locked_delta": trend.znn_locked_delta,
                "qsr_locked_delta": trend.qsr_locked_delta,
            },
        },
        source_repo="zenon_rpc",
    )
    return {
        "success": True,
        "snapshot_id": snapshot_id,
        "trend": None if trend is None else trend.direction,
        "total_znn_locked": snapshot.total_znn_locked,
    }


__all__ = [
    "ThesisSnapshot",
    "ThesisTrend",
    "capture_snapshot",
    "compute_trend",
    "ensure_schema",
    "persist_snapshot",
    "run_thesis_tracker",
]
