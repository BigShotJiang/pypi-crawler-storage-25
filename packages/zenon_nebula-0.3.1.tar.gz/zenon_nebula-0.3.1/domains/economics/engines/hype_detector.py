# SPDX-License-Identifier: MIT
"""
HypeDetector -- Market hype cycle detection for Zenon.

Generalized from marketing's hype_engine.py. Detects hype cycles, FOMO
patterns, and narrative shifts by combining:

- DexScreener volume/price data (via market_data API template)
- Web search for social mention changes (via web_search API template)
- LLM classification of the current market cycle phase

Cycle phases (Wallstreet Cheat Sheet model):
    STEALTH -> AWARENESS -> MANIA -> BLOWOFF -> DESPAIR -> ACCUMULATION

All findings are persisted to the evidence table in the economics domain.
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from core.api_fingerprint import FingerprintedSession
from core.api_templates.market_data import (
    DEXSCREENER_BASE,
)
from core.api_templates.web_search import search as web_search
from core.llm_provider import call_llm
from core.market_data import (
    get_dexscreener_data,
)
from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# wZNN/ETH pair on Uniswap (primary liquidity)
WZNN_TOKEN = "0xb2e96a63479C2Edd2FD62b382c89D5CA79f572d3"

# Hype cycle phases
PHASES = [
    "STEALTH",
    "AWARENESS",
    "MANIA",
    "BLOWOFF",
    "DESPAIR",
    "ACCUMULATION",
]

# Thresholds for hype signal detection
VOLUME_SPIKE_MULTIPLIER = 3.0  # 3x normal = spike
PRICE_MOVE_THRESHOLD = 10.0  # 10% move = significant
MENTION_SPIKE_MULTIPLIER = 2.0  # 2x normal = notable


def detect_hype_signals(
    *,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Check for hype signals: volume spikes, social mentions, price moves.

    Returns dict with detected signals and their intensities.
    """
    if session is None:
        session = FingerprintedSession(engine_name="hype_detector")

    signals: list[dict] = []
    market_data: dict = {}
    social_data: dict = {}

    # 1. Market data from DexScreener
    try:
        dex_data = _fetch_dex_data(session)
        market_data = dex_data
        if dex_data.get("success"):
            signals.extend(_analyze_market_signals(dex_data))
    except Exception as exc:
        logger.warning("Market data fetch failed: %s", exc)

    # 2. Social mention scan via web search
    try:
        mentions = _fetch_social_mentions(session)
        social_data = mentions
        if mentions.get("results"):
            signals.extend(_analyze_social_signals(mentions))
    except Exception as exc:
        logger.warning("Social mention scan failed: %s", exc)

    # Aggregate
    intensity = sum(s.get("intensity", 0) for s in signals)
    has_hype = intensity > 1.0

    result = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "signals": signals,
        "signal_count": len(signals),
        "total_intensity": round(intensity, 2),
        "has_hype": has_hype,
        "market_data": market_data,
        "social_data": social_data,
    }

    # Persist if any signals detected
    if signals:
        try:
            ensure_schema(db_path)
            signal_names = ", ".join(s["name"] for s in signals)
            signal_details = "; ".join(s.get("detail", s["name"]) for s in signals[:3])
            persist_finding(
                db_path=db_path,
                domain="economics",
                engine="hype_detector",
                evidence_type="hype_signals",
                finding=(
                    f"WHAT: {len(signals)} hype signal(s) detected: {signal_names} "
                    f"(total intensity {intensity:.2f}). {signal_details}. "
                    f"SO WHAT: {'High' if intensity > 2.0 else 'Moderate'} hype activity "
                    f"{'may indicate FOMO-driven price action -- elevated risk of reversal' if intensity > 2.0 else 'suggests growing interest but not yet overheated'}. "
                    f"NOW WHAT: {'Avoid large buys at peak hype; monitor for blow-off signals' if intensity > 2.0 else 'Track signal persistence over next 24-48h to confirm trend'}."
                ),
                confidence=min(0.90, 0.50 + intensity * 0.10),
                raw_data=result,
                source_repo="coingecko_api",
            )
        except Exception as exc:
            logger.debug("Hype signal persistence failed: %s", exc)

    return result


def classify_cycle_phase(
    *,
    signals: dict | None = None,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Classify the current market hype cycle phase using LLM reasoning.

    Args:
        signals: Pre-computed signal data from detect_hype_signals().
        session: FingerprintedSession for API calls.
        db_path: Database path for persistence.

    Returns:
        Dict with: phase, confidence, reasoning, indicators.
    """
    if signals is None:
        signals = detect_hype_signals(session=session, db_path=db_path)

    market = signals.get("market_data", {})
    social = signals.get("social_data", {})
    signal_list = signals.get("signals", [])

    # Build context for LLM classification
    context_parts = []

    if market.get("price_usd"):
        context_parts.append(f"Current price: ${market['price_usd']:.4f}")
    if market.get("price_change_24h"):
        context_parts.append(f"24h price change: {market['price_change_24h']:.1f}%")
    if market.get("volume_24h"):
        context_parts.append(f"24h volume: ${market['volume_24h']:,.0f}")
    if market.get("liquidity_usd"):
        context_parts.append(f"Liquidity: ${market['liquidity_usd']:,.0f}")

    if signal_list:
        context_parts.append(
            "Active hype signals: "
            + ", ".join(f"{s['name']} (intensity={s['intensity']:.1f})" for s in signal_list)
        )
    else:
        context_parts.append("No active hype signals detected.")

    if social.get("total_results", 0) > 0:
        context_parts.append(f"Social mentions found: {social['total_results']}")

    context = "\n".join(context_parts) if context_parts else "No market data available."

    prompt = (
        f"Based on the following market indicators for Zenon (ZNN), classify the current "
        f"hype cycle phase.\n\n{context}\n\n"
        f"Respond ONLY with valid JSON:\n"
        f'{{"phase": "STEALTH|AWARENESS|MANIA|BLOWOFF|DESPAIR|ACCUMULATION", '
        f'"confidence": 0.0-1.0, '
        f'"reasoning": "2-3 sentences explaining the classification", '
        f'"indicators": ["list of key indicators that informed the decision"]}}'
    )

    try:
        llm_result = call_llm(
            prompt=prompt,
            system=(
                "You are a market cycle analyst. Classify crypto market phases "
                "using the Wallstreet Cheat Sheet model. Be conservative -- most "
                "of the time, small-cap tokens are in STEALTH or ACCUMULATION. "
                "Only classify as MANIA or BLOWOFF with strong volume evidence."
            ),
            model="auto",
            max_tokens=512,
            temperature=0.3,
        )

        if llm_result and llm_result.get("text"):
            parsed = _parse_json(llm_result["text"])
            phase = parsed.get("phase", "STEALTH")
            if phase not in PHASES:
                phase = "STEALTH"
        else:
            parsed = {}
            phase = "STEALTH"

    except Exception as exc:
        logger.warning("Cycle phase classification failed: %s", exc)
        parsed = {}
        phase = "STEALTH"

    result = {
        "phase": phase,
        "confidence": parsed.get("confidence", 0.5),
        "reasoning": parsed.get("reasoning", "Classification unavailable."),
        "indicators": parsed.get("indicators", []),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "signal_summary": {
            "count": len(signal_list),
            "intensity": signals.get("total_intensity", 0),
        },
    }

    # Persist
    try:
        ensure_schema(db_path)
        phase_actions = {
            "STEALTH": "Accumulation opportunity; build positions quietly before awareness spreads.",
            "AWARENESS": "Growing recognition phase; prepare content and outreach to capture momentum.",
            "MANIA": "Elevated risk of blow-off; avoid chasing, consider taking partial profits.",
            "BLOWOFF": "Peak euphoria likely passing; reduce exposure, wait for capitulation.",
            "DESPAIR": "Maximum pessimism; historically the best long-term entry point.",
            "ACCUMULATION": "Smart money re-entering; begin building positions incrementally.",
        }
        persist_finding(
            db_path=db_path,
            domain="economics",
            engine="hype_detector",
            evidence_type="cycle_phase_classification",
            finding=(
                f"WHAT: Market cycle classified as {phase} "
                f"(confidence {result['confidence']:.2f}). "
                f"SO WHAT: {result['reasoning']} "
                f"NOW WHAT: {phase_actions.get(phase, 'Continue monitoring market indicators.')}"
            ),
            confidence=result["confidence"],
            raw_data=result,
            source_repo="coingecko_api",
        )
    except Exception as exc:
        logger.debug("Cycle phase persistence failed: %s", exc)

    return result


def detect_narrative_shift(
    *,
    session: FingerprintedSession | None = None,
    db_path: str = DEFAULT_DB,
) -> dict:
    """Detect if the dominant narrative around Zenon is changing.

    Searches for recent Zenon mentions and uses LLM to classify the
    dominant narrative angle.

    Returns dict with: dominant_narrative, emerging_narratives,
    shift_detected, confidence.
    """
    if session is None:
        session = FingerprintedSession(engine_name="hype_detector")

    # Search for recent Zenon mentions
    queries = [
        "Zenon Network ZNN crypto",
        "Zenon ZNN bridge Bitcoin",
        "wZNN Uniswap DeFi",
    ]

    all_results: list[dict] = []
    for query in queries:
        try:
            results = web_search(query, session=session, max_results=5)
            if results:
                all_results.extend(results)
        except Exception as exc:
            logger.debug("Narrative search failed for '%s': %s", query, exc)

    if not all_results:
        return {
            "dominant_narrative": "unknown",
            "emerging_narratives": [],
            "shift_detected": False,
            "confidence": 0.0,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "search_results_count": 0,
        }

    # Summarize search results for LLM analysis
    snippets = []
    for r in all_results[:10]:
        title = r.get("title", "")
        snippet = r.get("snippet", r.get("description", ""))
        if title or snippet:
            snippets.append(f"- {title}: {snippet[:200]}")

    snippet_text = "\n".join(snippets) if snippets else "No snippets available."

    prompt = (
        f"Based on these recent web results about Zenon Network, identify the "
        f"dominant narrative and any emerging narrative shifts.\n\n"
        f"Recent mentions:\n{snippet_text}\n\n"
        f"Known narratives: BTC bridge, feeless transactions, dual-ledger architecture, "
        f"fair launch, DeFi hub, privacy, AI integration, institutional adoption.\n\n"
        f"Respond ONLY with valid JSON:\n"
        f'{{"dominant_narrative": "short description", '
        f'"emerging_narratives": ["list of new angles appearing"], '
        f'"shift_detected": true/false, '
        f'"confidence": 0.0-1.0, '
        f'"reasoning": "2-3 sentences"}}'
    )

    try:
        llm_result = call_llm(
            prompt=prompt,
            system=(
                "You are a crypto narrative analyst. Identify which storylines "
                "dominate discussion about a project. Be specific about the "
                "angle (not just 'positive' or 'negative')."
            ),
            model="auto",
            max_tokens=512,
            temperature=0.3,
        )

        if llm_result and llm_result.get("text"):
            parsed = _parse_json(llm_result["text"])
        else:
            parsed = {}

    except Exception as exc:
        logger.warning("Narrative shift detection failed: %s", exc)
        parsed = {}

    result = {
        "dominant_narrative": parsed.get("dominant_narrative", "unknown"),
        "emerging_narratives": parsed.get("emerging_narratives", []),
        "shift_detected": parsed.get("shift_detected", False),
        "confidence": parsed.get("confidence", 0.0),
        "reasoning": parsed.get("reasoning", "Analysis unavailable."),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "search_results_count": len(all_results),
    }

    # Persist if shift detected or meaningful data gathered
    if result["shift_detected"] or result["confidence"] > 0.5:
        try:
            ensure_schema(db_path)
            emerging_text = ", ".join(result["emerging_narratives"][:3]) or "none"
            persist_finding(
                db_path=db_path,
                domain="economics",
                engine="hype_detector",
                evidence_type="narrative_shift",
                finding=(
                    f"WHAT: Dominant narrative is '{result['dominant_narrative']}'. "
                    f"{'Narrative SHIFT detected' if result['shift_detected'] else 'No shift detected'}. "
                    f"Emerging angles: {emerging_text}. "
                    f"SO WHAT: {'Narrative shifts precede price moves -- new framing may attract different investor segments' if result['shift_detected'] else 'Stable narrative indicates no major sentiment change'}. "
                    f"NOW WHAT: {'Align marketing content with emerging narratives; update messaging to capture new audience' if result['shift_detected'] else 'Continue reinforcing current narrative; monitor for early signs of shift'}."
                ),
                confidence=result["confidence"],
                raw_data=result,
                source_repo="web_search",
            )
        except Exception as exc:
            logger.debug("Narrative shift persistence failed: %s", exc)

    return result


# -- Internal helpers --


def _fetch_dex_data(session: FingerprintedSession) -> dict:
    """Fetch wZNN market data from DexScreener via core.market_data.

    Uses get_dexscreener_data() for the primary data source. Falls back
    to the FingerprintedSession API template if that fails.
    """
    try:
        data = get_dexscreener_data()
        if data is not None:
            return {
                "success": True,
                "price_usd": data.get("price_usd", 0),
                "volume_24h": data.get("volume_24h", 0),
                "volume_6h": 0,  # not available from core.market_data
                "volume_1h": 0,  # not available from core.market_data
                "liquidity_usd": data.get("liquidity_usd", 0),
                "price_change_24h": data.get("price_change_24h", 0),
                "price_change_6h": 0,
                "price_change_1h": data.get("price_change_1h", 0),
                "pair_address": data.get("pair_address", ""),
                "dex": data.get("dex", "unknown"),
            }
    except Exception as exc:
        logger.debug("core.market_data.get_dexscreener_data() failed, trying API template: %s", exc)

    # Fallback: use the FingerprintedSession API template
    try:
        url = f"{DEXSCREENER_BASE}/tokens/{WZNN_TOKEN}"
        resp = session.get(url, timeout=15)
        if resp.status_code != 200:
            return {"success": False, "error": f"HTTP {resp.status_code}"}

        raw = resp.json()
        pairs = raw.get("pairs", [])
        if not pairs:
            return {"success": False, "error": "No pairs found"}

        pairs.sort(
            key=lambda p: float(p.get("liquidity", {}).get("usd", 0) or 0),
            reverse=True,
        )
        top = pairs[0]

        volume = top.get("volume", {})
        price_change = top.get("priceChange", {})
        liquidity = top.get("liquidity", {})

        return {
            "success": True,
            "price_usd": float(top.get("priceUsd", 0) or 0),
            "volume_24h": float(volume.get("h24", 0) or 0),
            "volume_6h": float(volume.get("h6", 0) or 0),
            "volume_1h": float(volume.get("h1", 0) or 0),
            "liquidity_usd": float(liquidity.get("usd", 0) or 0),
            "price_change_24h": float(price_change.get("h24", 0) or 0),
            "price_change_6h": float(price_change.get("h6", 0) or 0),
            "price_change_1h": float(price_change.get("h1", 0) or 0),
            "pair_address": top.get("pairAddress", ""),
            "dex": top.get("dexId", "unknown"),
        }
    except Exception as exc:
        logger.warning("DexScreener fetch failed: %s", exc)
        return {"success": False, "error": str(exc)}


def _fetch_social_mentions(session: FingerprintedSession) -> dict:
    """Search for recent Zenon social mentions."""
    queries = ["Zenon ZNN crypto", "wZNN Uniswap"]
    all_results: list[dict] = []

    for query in queries:
        try:
            results = web_search(query, session=session, max_results=5)
            if results:
                all_results.extend(results)
        except Exception as exc:
            logger.debug("Social search query failed: %s", exc)
            continue

    return {
        "results": all_results,
        "total_results": len(all_results),
        "queries_run": len(queries),
    }


def _analyze_market_signals(dex_data: dict) -> list[dict]:
    """Extract hype signals from market data."""
    signals: list[dict] = []

    # Volume spike detection
    vol_24h = dex_data.get("volume_24h", 0)
    vol_6h = dex_data.get("volume_6h", 0)
    liq = dex_data.get("liquidity_usd", 0)

    if liq > 0 and vol_24h > 0:
        vol_to_liq = vol_24h / liq
        if vol_to_liq > VOLUME_SPIKE_MULTIPLIER:
            signals.append(
                {
                    "name": "volume_spike",
                    "category": "market",
                    "intensity": min(vol_to_liq / VOLUME_SPIKE_MULTIPLIER, 3.0),
                    "detail": (
                        f"24h volume (${vol_24h:,.0f}) is {vol_to_liq:.1f}x liquidity (${liq:,.0f})"
                    ),
                }
            )

    # Price move detection
    price_change_24h = abs(dex_data.get("price_change_24h", 0))
    if price_change_24h > PRICE_MOVE_THRESHOLD:
        signals.append(
            {
                "name": "significant_price_move",
                "category": "market",
                "intensity": min(price_change_24h / PRICE_MOVE_THRESHOLD, 3.0),
                "detail": f"24h price change: {dex_data.get('price_change_24h', 0):+.1f}%",
            }
        )

    # Short-term acceleration: 1h volume high relative to 6h
    if vol_6h > 0 and dex_data.get("volume_1h", 0) > 0:
        hourly_rate = dex_data["volume_1h"]
        six_hour_rate = vol_6h / 6
        if six_hour_rate > 0 and hourly_rate > six_hour_rate * 2:
            signals.append(
                {
                    "name": "volume_acceleration",
                    "category": "market",
                    "intensity": min(hourly_rate / six_hour_rate, 3.0),
                    "detail": (
                        f"1h volume rate (${hourly_rate:,.0f}/h) is "
                        f"{hourly_rate / six_hour_rate:.1f}x the 6h average"
                    ),
                }
            )

    return signals


def _analyze_social_signals(mentions: dict) -> list[dict]:
    """Extract hype signals from social mention data."""
    signals: list[dict] = []
    total = mentions.get("total_results", 0)

    # More than expected results indicates heightened discussion
    if total > 10:
        signals.append(
            {
                "name": "elevated_social_mentions",
                "category": "social",
                "intensity": min(total / 10.0, 2.0),
                "detail": f"{total} recent mentions found across web search",
            }
        )

    return signals


def _parse_json(text: str) -> dict:
    """Best-effort JSON extraction from LLM response."""
    if text.startswith("```"):
        lines = text.split("\n")
        text = "\n".join(line for line in lines if not line.strip().startswith("```"))

    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return parsed
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            parsed = json.loads(text[start:end])
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

    return {}
