# SPDX-License-Identifier: MIT
"""
InvestigationDomain -- DomainPlugin for technical architecture analysis and vision tracking.

Provides engines for understanding Zenon's technical architecture from
source code and tracking core dev technical direction from commit history
and spec progression.
"""

import logging

from core.domain_registry import (
    AspirationType,
    CollisionSignal,
    DomainPlugin,
    EngineDefinition,
    HypothesisType,
    WarRoomContribution,
)

logger = logging.getLogger(__name__)


class InvestigationDomain(DomainPlugin):
    """Investigation domain plugin -- architecture and vision analysis."""

    def name(self) -> str:
        """Return the domain name identifier."""
        return "investigation"

    def get_description(self) -> str:
        """Return a human-readable description of this domain."""
        return (
            "Technical architecture analysis of go-zenon embedded contracts, "
            "contract dependency mapping, core dev vision tracking from "
            "commit history and spec progression."
        )

    def get_priority(self) -> int:
        """Return the scheduling priority for this domain."""
        return 5

    def get_engines(self) -> list[EngineDefinition]:
        """Return the list of engines this domain provides."""
        return [
            EngineDefinition(
                name="architecture_analyzer",
                description=(
                    "Reads go-zenon source to extract embedded contracts, "
                    "dependency chains, architectural patterns (spork gates, "
                    "dual-coin model, plasma)."
                ),
                module_path="domains.investigation.engines.architecture_analyzer",
                priority=4,
                tier=1,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="vision_tracker",
                description=(
                    "Tracks core dev technical vision from commit themes, "
                    "spec progression, and development focus areas."
                ),
                module_path="domains.investigation.engines.vision_tracker",
                priority=5,
                tier=2,
                required_apis=["filesystem", "git"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="protocol_family_classifier",
                description=(
                    "Classifies every workspace repo into a protocol "
                    "family (UTXO chain, account chain, rollup, bridge, "
                    "SDK consumer, tooling) via signatures + optional "
                    "LLM fallback. Activates when a reference chain is "
                    "present in the workspace."
                ),
                module_path="domains.investigation.engines.protocol_family_classifier",
                priority=6,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=120,
            ),
            EngineDefinition(
                name="curiosity_scanner",
                description=(
                    "Random-samples stale repos and greps for the curated "
                    "`INTERESTING_PATTERNS` keyword list (core Zenon "
                    "primitives, cryptographic building blocks, "
                    "experimental/TODO/HACK markers, BIP-adjacent terms). "
                    "Persists hits as WHAT/SO WHAT/NOW WHAT findings with "
                    "clickable GitHub permalinks. This is the load-bearing "
                    "engine for the clue-dropping channel: a researcher "
                    "dropping a suggestive comment into any workspace repo "
                    "will have it surfaced here without anyone asking."
                ),
                module_path="domains.investigation.engines.curiosity_scanner",
                priority=7,
                tier=2,
                required_apis=["filesystem"],
                max_runtime_seconds=60,
            ),
        ]

    def get_hypothesis_types(self) -> list[HypothesisType]:
        """Return hypothesis types this domain can generate."""
        return [
            HypothesisType(
                type_id="architecture_insight",
                label="Architecture insight identified",
                description=(
                    "A significant pattern or dependency in Zenon's embedded "
                    "contract architecture has been identified."
                ),
                initial_confidence=0.4,
                publishable_threshold=0.80,
            ),
            HypothesisType(
                type_id="vision_direction",
                label="Development direction identified",
                description=(
                    "Core dev commit patterns and spec progression suggest "
                    "a clear development trajectory."
                ),
                initial_confidence=0.3,
                publishable_threshold=0.75,
            ),
        ]

    def get_aspiration_types(self) -> list[AspirationType]:
        """Return aspiration types this domain can pursue."""
        return [
            AspirationType(
                type_id="full_architecture_map",
                label="Complete architecture map of go-zenon",
                description=(
                    "Every embedded contract documented with its methods, "
                    "dependencies, spork gates, and security properties."
                ),
                priority=4,
            ),
        ]

    def get_collision_signals(self) -> list[CollisionSignal]:
        """Return signals that trigger cross-domain collisions."""
        return [
            CollisionSignal(
                signal_id="investigation_intelligence_overlap",
                label="Investigation-intelligence overlap",
                description=(
                    "Architecture analysis finding intersects with upstream "
                    "intelligence signals about code changes."
                ),
                source_domains=["investigation", "intelligence"],
                convergence_threshold=0.6,
            ),
        ]

    def get_war_room_contributions(self) -> list[WarRoomContribution]:
        """Return this domain's war room briefing sections."""
        return [
            WarRoomContribution(
                domain="investigation",
                section_title="Architecture & Vision",
                metrics=[
                    "contracts_analyzed",
                    "dependency_chains",
                    "core_dev_focus_areas",
                    "predicted_next_phase",
                ],
                recommendations_prompt=(
                    "Based on architecture analysis and core dev focus, "
                    "what technical direction should we align with?"
                ),
            ),
        ]

    def get_self_improvement_metrics(self) -> dict[str, float]:
        """Return current performance metrics for self-improvement."""
        return {
            "contracts_analyzed": 0.0,
            "vision_confidence": 0.0,
        }

    def decide_next_action(self, context: dict, exclude: set[str] | None = None) -> dict | None:
        """Rotate through all investigation engines, honoring exclude.

        Accepts ``exclude`` so the autonomous scheduler can ask the
        domain for a DIFFERENT action once the first-choice engine has
        already been selected this cycle. Without this, curiosity_scanner
        and protocol_family_classifier would never fire because
        architecture_analyzer or vision_tracker would always win the
        first branch and be the only engine the domain ever yielded.
        """
        exclude = exclude or set()

        candidates: list[dict] = [
            {
                "action": "analyze_architecture",
                "reason": "Routine architecture scan.",
                "priority": 5,
                "engine": "architecture_analyzer",
            },
            {
                "action": "track_vision",
                "reason": "Routine vision tracking.",
                "priority": 6,
                "engine": "vision_tracker",
            },
            {
                "action": "classify_protocol_families",
                "reason": "Routine protocol-family classification.",
                "priority": 6,
                "engine": "protocol_family_classifier",
            },
            {
                "action": "run_curiosity_scan",
                "reason": "Routine random-sample exploration for clues.",
                "priority": 7,
                "engine": "curiosity_scanner",
            },
        ]

        for candidate in candidates:
            key = f"investigation:{candidate['action']}"
            if key not in exclude:
                return candidate
        return None

    def get_db_schema_sql(self) -> str:
        """Return domain-specific SQL DDL for additional tables."""
        return ""

    def on_register(self) -> None:
        """Initialize domain-specific resources after registration."""
        logger.info(
            "Investigation domain registered with %d engines.",
            len(self.get_engines()),
        )

    def is_private(self) -> bool:
        """Investigation is entirely private.

        Architectural archaeology, vision tracking and identity-adjacent
        analysis are all sensitive. No investigation findings leave the
        local instance. This matches transport.PRIVATE_DOMAINS.
        """
        return True
