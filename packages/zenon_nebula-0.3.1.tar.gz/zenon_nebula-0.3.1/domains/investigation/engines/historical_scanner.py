# SPDX-License-Identifier: MIT
"""
HistoricalScanner -- Mine project history from archived sources.

Reads twitter archives, investigation folders, and proof-of-concept repos
to extract communication patterns, themes, timelines, and decision history.
All analysis is regex-based (no LLM) — we extract structure, not opinions.

Sources:
    - zenon-network/twitter, sol-znn/twitter, georgezgeorgez/twitter
    - investigation/ folder for existing research data
    - Zenon-PoCs for proof of concept patterns
"""

import json
import logging
import os
import re
from collections import Counter
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Twitter archive repos
TWITTER_ARCHIVES = {
    "zenon-network": [
        ZENON_WORKSPACE / "zenon-network" / "twitter",
    ],
    "sol-znn": [
        ZENON_WORKSPACE / "sol-znn" / "twitter",
    ],
    "georgezgeorgez": [
        ZENON_WORKSPACE / "georgezgeorgez" / "twitter",
    ],
}

# Investigation data
INVESTIGATION_DIRS = [
    ZENON_WORKSPACE / "investigation",
]

# Proof of concept repos
POC_DIRS = [
    ZENON_WORKSPACE / "zenon-network" / "Zenon-PoCs",
    ZENON_WORKSPACE / "hypercore-one" / "Zenon-PoCs",
]

# Theme detection keywords
THEME_KEYWORDS = {
    "bitcoin_alignment": [
        "bitcoin",
        "btc",
        "satoshi",
        "taproot",
        "lightning",
        "segwit",
        "schnorr",
        "trustless bridge",
    ],
    "privacy": [
        "privacy",
        "private",
        "anonymous",
        "stealth",
        "confidential",
        "zero knowledge",
        "zk",
    ],
    "governance": [
        "governance",
        "pillar",
        "vote",
        "proposal",
        "az",
        "accelerator",
        "decentralized governance",
    ],
    "bridge_interop": [
        "bridge",
        "cross-chain",
        "interop",
        "wrap",
        "unwrap",
        "multichain",
        "evm",
        "bsc",
    ],
    "scalability": [
        "scale",
        "throughput",
        "tps",
        "plasma",
        "momentum",
        "block lattice",
        "dag",
    ],
    "defi": [
        "defi",
        "liquidity",
        "swap",
        "dex",
        "amm",
        "yield",
        "staking",
        "farming",
    ],
    "community": [
        "community",
        "builder",
        "contributor",
        "developer",
        "pillar",
        "sentinel",
        "delegat",
    ],
    "mystery": [
        "alien",
        "zenon",
        "mystery",
        "puzzle",
        "secret",
        "hidden",
        "cipher",
        "code",
    ],
}


def _read_file(filepath: Path, max_bytes: int = 500_000) -> str:
    """Read file text, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _find_repo(paths: list[Path]) -> Path | None:
    """Find the first existing path from a list of candidates."""
    for p in paths:
        if p.is_dir():
            return p
    return None


def scan_twitter_archive(archive_name: str, paths: list[Path]) -> dict:
    """Scan a twitter archive directory for tweet data.

    Supports common archive formats: JSON, CSV, JSONL, and plain text.
    Extracts themes, timeline, and communication patterns.
    """
    result = {
        "archive_name": archive_name,
        "exists": False,
        "tweet_count": 0,
        "date_range": {"earliest": None, "latest": None},
        "themes": {},
        "top_hashtags": [],
        "top_mentions": [],
        "files_scanned": 0,
    }

    archive_path = _find_repo(paths)
    if not archive_path:
        return result

    result["exists"] = True
    all_text = []
    dates = []
    hashtags: Counter = Counter()
    mentions: Counter = Counter()
    tweet_count = 0

    # Scan all text-like files in the archive
    for ext in ("*.json", "*.jsonl", "*.csv", "*.txt", "*.md"):
        for f in archive_path.rglob(ext):
            if ".git" in str(f):
                continue
            result["files_scanned"] += 1
            content = _read_file(f)
            if not content:
                continue

            # Try to parse as JSON (Twitter archive format)
            if f.suffix in (".json", ".jsonl"):
                for line in content.split("\n"):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        if isinstance(data, list):
                            for item in data:
                                if isinstance(item, dict):
                                    text = item.get("full_text", item.get("text", ""))
                                    all_text.append(text)
                                    tweet_count += 1
                                    date_str = item.get("created_at", "")
                                    if date_str:
                                        dates.append(date_str)
                        elif isinstance(data, dict):
                            text = data.get("full_text", data.get("text", ""))
                            if text:
                                all_text.append(text)
                                tweet_count += 1
                            # Handle nested tweet array
                            if "tweet" in data:
                                tweet_data = data["tweet"]
                                if isinstance(tweet_data, dict):
                                    text = tweet_data.get("full_text", "")
                                    if text:
                                        all_text.append(text)
                                        tweet_count += 1
                    except json.JSONDecodeError:
                        # Treat as plain text
                        all_text.append(line)
            else:
                all_text.append(content)

    result["tweet_count"] = tweet_count

    # Extract hashtags and mentions from all text
    combined_text = " ".join(all_text)
    for tag in re.findall(r"#(\w+)", combined_text):
        hashtags[tag.lower()] += 1
    for mention in re.findall(r"@(\w+)", combined_text):
        mentions[mention.lower()] += 1

    result["top_hashtags"] = [
        {"tag": tag, "count": count} for tag, count in hashtags.most_common(20)
    ]
    result["top_mentions"] = [
        {"mention": m, "count": count} for m, count in mentions.most_common(20)
    ]

    # Theme analysis
    combined_lower = combined_text.lower()
    for theme, keywords in THEME_KEYWORDS.items():
        theme_count = sum(combined_lower.count(kw) for kw in keywords)
        if theme_count > 0:
            result["themes"][theme] = theme_count

    # Sort themes by frequency
    result["themes"] = dict(sorted(result["themes"].items(), key=lambda x: -x[1]))

    return result


def scan_investigation_data() -> dict:
    """Scan investigation/ folder for research data.

    Returns dict with file inventory, topics, and research themes.
    """
    result = {
        "exists": False,
        "total_files": 0,
        "file_types": {},
        "topics": [],
        "themes": {},
    }

    for inv_dir in INVESTIGATION_DIRS:
        if not inv_dir.is_dir():
            continue
        result["exists"] = True

        file_types: Counter = Counter()
        all_text = []

        for f in inv_dir.rglob("*"):
            if f.is_file() and ".git" not in str(f):
                result["total_files"] += 1
                file_types[f.suffix or "no_ext"] += 1

                if f.suffix in (".md", ".txt", ".json", ".csv"):
                    content = _read_file(f)
                    if content:
                        all_text.append(content[:5000])

                # Track subdirectories as topics
                relative = f.relative_to(inv_dir)
                if len(relative.parts) > 1:
                    topic = relative.parts[0]
                    if topic not in result["topics"]:
                        result["topics"].append(topic)

        result["file_types"] = dict(file_types.most_common(20))

        # Theme analysis on investigation content
        combined_lower = " ".join(all_text).lower()
        for theme, keywords in THEME_KEYWORDS.items():
            theme_count = sum(combined_lower.count(kw) for kw in keywords)
            if theme_count > 0:
                result["themes"][theme] = theme_count

    return result


def scan_pocs() -> list[dict]:
    """Scan Zenon-PoCs repos for proof of concept patterns.

    Returns list of PoC summaries.
    """
    pocs = []

    for poc_dir in POC_DIRS:
        if not poc_dir.is_dir():
            continue

        for item in poc_dir.iterdir():
            if not item.is_dir() or item.name.startswith("."):
                continue

            # Detect language
            languages = set()
            for ext, lang in [
                (".go", "go"),
                (".py", "python"),
                (".js", "javascript"),
                (".ts", "typescript"),
                (".dart", "dart"),
                (".rs", "rust"),
                (".sol", "solidity"),
            ]:
                if list(item.rglob(f"*{ext}"))[:1]:
                    languages.add(lang)

            # Read README for description
            readme = ""
            for readme_name in ["README.md", "readme.md", "README.txt"]:
                readme_path = item / readme_name
                if readme_path.is_file():
                    readme = _read_file(readme_path)[:500]
                    break

            pocs.append(
                {
                    "name": item.name,
                    "path": str(item.relative_to(ZENON_WORKSPACE)),
                    "languages": sorted(languages),
                    "has_readme": bool(readme),
                    "description": readme[:200] if readme else "",
                }
            )

    return pocs


def generate_report() -> dict:
    """Generate a full historical analysis report."""
    twitter_results = {}
    for archive_name, paths in TWITTER_ARCHIVES.items():
        twitter_results[archive_name] = scan_twitter_archive(archive_name, paths)

    investigation = scan_investigation_data()
    pocs = scan_pocs()

    # Aggregate themes across all sources
    global_themes: Counter = Counter()
    for archive in twitter_results.values():
        for theme, count in archive.get("themes", {}).items():
            global_themes[theme] += count
    for theme, count in investigation.get("themes", {}).items():
        global_themes[theme] += count

    total_tweets = sum(a.get("tweet_count", 0) for a in twitter_results.values())
    archives_found = sum(1 for a in twitter_results.values() if a["exists"])

    return {
        "twitter_archives": twitter_results,
        "investigation": investigation,
        "pocs": pocs,
        "global_themes": dict(global_themes.most_common(15)),
        "summary": {
            "archives_found": archives_found,
            "total_archives": len(TWITTER_ARCHIVES),
            "total_tweets": total_tweets,
            "investigation_exists": investigation["exists"],
            "investigation_files": investigation["total_files"],
            "poc_count": len(pocs),
            "dominant_theme": (global_themes.most_common(1)[0][0] if global_themes else "none"),
        },
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run historical analysis and persist findings.

    Returns number of findings persisted.
    """
    ensure_schema(db_path)
    report = generate_report()
    count = 0

    summary = report["summary"]
    missing_archives = summary["total_archives"] - summary["archives_found"]
    dominant = summary["dominant_theme"]
    if missing_archives == 0:
        so_what = "All archives accounted for."
        now_what = "Mine dominant theme for marketing content angles."
    else:
        so_what = f"{missing_archives} archives missing — incomplete historical picture."
        now_what = f"Locate missing archives to complete the historical record; mine {dominant} theme for content."
    persist_finding(
        db_path=db_path,
        domain="investigation",
        engine="historical_scanner",
        evidence_type="historical_overview",
        finding=(
            f"WHAT: Scanned {summary['archives_found']}/{summary['total_archives']} "
            f"twitter archives ({summary['total_tweets']} tweets), "
            f"{'found' if summary['investigation_exists'] else 'no'} investigation data "
            f"({summary['investigation_files']} files), {summary['poc_count']} PoCs. "
            f"Dominant theme: {dominant}. "
            f"SO WHAT: {so_what} "
            f"The dominant theme reveals the project narrative the community sees. "
            f"NOW WHAT: {now_what}"
        ),
        confidence=0.80,
        raw_data=report,
        source_repo="investigation",
    )
    count += 1

    # Per-archive findings
    for archive_name, archive_data in report["twitter_archives"].items():
        if archive_data["exists"]:
            top_themes = list(archive_data.get("themes", {}).keys())[:5]
            theme_str = ", ".join(top_themes) or "none detected"
            tweet_count = archive_data["tweet_count"]
            persist_finding(
                db_path=db_path,
                domain="investigation",
                engine="historical_scanner",
                evidence_type="twitter_archive",
                finding=(
                    f"WHAT: Twitter archive '{archive_name}' contains "
                    f"{tweet_count} tweets across {archive_data['files_scanned']} files. "
                    f"Top themes: {theme_str}. "
                    f"SO WHAT: {'Rich content source for understanding this account narrative.' if tweet_count > 50 else 'Sparse archive — limited historical signal.'} "
                    f"NOW WHAT: Cross-reference top themes with current dev focus "
                    f"to identify narrative continuity or shifts."
                ),
                confidence=0.75,
                raw_data=archive_data,
                source_repo=f"{archive_name}/twitter",
            )
            count += 1

    # Global theme findings
    for theme, frequency in report.get("global_themes", {}).items():
        if frequency >= 5:  # Only persist significant themes
            strength = (
                "dominant" if frequency >= 50 else "moderate" if frequency >= 20 else "emerging"
            )
            persist_finding(
                db_path=db_path,
                domain="investigation",
                engine="historical_scanner",
                evidence_type="historical_theme",
                finding=(
                    f"WHAT: Theme '{theme}' appears {frequency} times across "
                    f"all archived sources ({strength} signal). "
                    f"SO WHAT: {'Core narrative pillar — should be central to positioning.' if strength == 'dominant' else 'Supporting narrative — useful for content variety.' if strength == 'moderate' else 'Emerging signal — monitor for growth.'} "
                    f"NOW WHAT: {'Build marketing content around this theme.' if strength == 'dominant' else 'Track frequency over time to detect trend shifts.'}"
                ),
                confidence=0.65,
                raw_data={"theme": theme, "frequency": frequency},
                source_repo="investigation",
            )
            count += 1

    # PoC findings
    for poc in report["pocs"]:
        langs = ", ".join(poc["languages"]) or "unknown"
        desc = poc["description"][:100] if poc["description"] else "No description"
        persist_finding(
            db_path=db_path,
            domain="investigation",
            engine="historical_scanner",
            evidence_type="poc_entry",
            finding=(
                f"WHAT: PoC '{poc['name']}' exists ({langs}). {desc}. "
                f"SO WHAT: PoCs reveal what core devs prototyped — these are "
                f"leading indicators of future protocol features. "
                f"NOW WHAT: Check if this PoC evolved into a spec in "
                f"developer-commons; if so, track implementation status."
            ),
            confidence=0.70,
            raw_data=poc,
            source_repo=poc.get("path"),
        )
        count += 1

    logger.info("HistoricalScanner: persisted %d findings", count)
    return count
