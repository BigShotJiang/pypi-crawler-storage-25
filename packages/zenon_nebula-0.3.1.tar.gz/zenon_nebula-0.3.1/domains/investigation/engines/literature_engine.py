# SPDX-License-Identifier: MIT
"""
LiteratureEngine -- Search for academic papers related to Zenon's technology.

Uses web_search API template to find papers on topics central to Zenon's
technical stack: PTLC, atomic swaps, Bitcoin SPV, DAG consensus, dual-coin
economics, feeless transactions, and plasma-based fee models.

Summarizes relevant findings and persists them to the evidence table
with source URLs for reproducibility. Degrades gracefully when search
is unavailable (returns cached or empty results instead of failing).
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from core.config import get_config
from core.persist_to_db import persist_metric, query_table
from core.persistence import connect

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Research topics mapped to search queries.
# Each entry: (topic_key, search_query, description)
RESEARCH_TOPICS = [
    (
        "ptlc",
        "point time locked contracts cryptography atomic swap",
        "Cryptographic point-lock mechanisms for conditional payments",
    ),
    (
        "atomic_swap",
        "cross-chain atomic swap protocol Bitcoin altcoin",
        "Trustless cross-chain asset exchange protocols",
    ),
    (
        "bitcoin_spv",
        "Bitcoin simplified payment verification SPV relay sidechain",
        "Lightweight Bitcoin transaction verification for bridges",
    ),
    (
        "dag_consensus",
        "directed acyclic graph DAG consensus blockchain scalability",
        "DAG-based consensus mechanisms for high throughput",
    ),
    (
        "dual_coin",
        "dual token economics blockchain fee model staking",
        "Dual-coin economic models separating utility from governance",
    ),
    (
        "feeless",
        "feeless transaction blockchain proof of work anti-spam",
        "Transaction models that eliminate explicit fees",
    ),
    (
        "plasma_fee",
        "proof of work fee model blockchain spam prevention plasma",
        "PoW-based anti-spam mechanisms as fee alternatives",
    ),
    (
        "adaptor_signature",
        "adaptor signature scriptless script atomic swap privacy",
        "Adaptor signatures for private cross-chain operations",
    ),
    (
        "hash_time_lock",
        "hash time locked contract HTLC payment channel lightning",
        "Hash time-locked contracts for payment channels",
    ),
    (
        "decentralized_identity",
        "decentralized identifier DID self-sovereign identity blockchain",
        "On-chain decentralized identity and credential systems",
    ),
]

# Sourced from config/engine_defaults.json with safe fallbacks.
_lit_cfg = get_config().engine("literature_engine")
# Maximum papers to persist per topic per run
MAX_PAPERS_PER_TOPIC = _lit_cfg.get("max_papers_per_topic", 5)
# Minimum snippet length to consider a result potentially relevant
MIN_SNIPPET_LENGTH = _lit_cfg.get("min_snippet_length", 40)


def _init_db(db_path: str) -> None:
    """Ensure the evidence table exists."""
    conn = connect(db_path)
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                domain TEXT NOT NULL,
                engine TEXT NOT NULL,
                evidence_type TEXT NOT NULL,
                finding TEXT NOT NULL,
                confidence REAL DEFAULT 0.0,
                created_at TEXT DEFAULT (datetime('now')),
                raw_data TEXT,
                verification_url TEXT,
                source_repo TEXT,
                source_file TEXT
            )
        """)
        conn.commit()
    finally:
        conn.close()


def _persist_paper(
    db_path: str,
    topic: str,
    title: str,
    url: str,
    snippet: str,
    confidence: float,
) -> int | None:
    """Persist a paper finding to the evidence table.

    Returns the row ID if persisted, None on failure.
    """
    _init_db(db_path)
    finding = (
        f"WHAT: [{topic}] Paper '{title}' found. {snippet[:200]} "
        f"SO WHAT: Validates Zenon's technical approach with academic precedent "
        f"— useful for credibility in dev updates and upstream PR justifications. "
        f"NOW WHAT: Review paper at URL; cite in relevant spec discussions if applicable."
    )
    raw_data = json.dumps(
        {
            "topic": topic,
            "title": title,
            "url": url,
            "snippet": snippet,
            "discovered_at": datetime.now(timezone.utc).isoformat(),
        }
    )
    row_id = persist_metric(
        db_path=db_path,
        table="evidence",
        data={
            "domain": "investigation",
            "engine": "literature_engine",
            "evidence_type": f"academic_paper_{topic}",
            "finding": finding,
            "confidence": confidence,
            "raw_data": raw_data,
            "verification_url": url,
        },
    )
    return row_id if row_id > 0 else None


def _is_academic_indicator(title: str, snippet: str) -> bool:
    """Heuristic check whether a search result looks like an academic paper.

    Looks for common indicators: arxiv, IEEE, ACM, 'et al', 'abstract',
    conference/journal names, doi references.
    """
    combined = (title + " " + snippet).lower()
    indicators = [
        "arxiv",
        "ieee",
        "acm",
        "springer",
        "eprint",
        "iacr",
        "et al",
        "abstract",
        "doi:",
        "proceedings",
        "conference",
        "journal",
        "cryptology",
        "protocol",
        "theorem",
        "proof",
        "peer-reviewed",
    ]
    return any(ind in combined for ind in indicators)


def _estimate_relevance(topic: str, title: str, snippet: str) -> float:
    """Estimate how relevant a paper is to the topic.

    Returns a confidence score between 0.0 and 1.0.
    """
    combined = (title + " " + snippet).lower()
    topic_parts = topic.replace("_", " ").split()

    # Count how many topic words appear in the result
    matches = sum(1 for part in topic_parts if part in combined)
    word_score = min(matches / max(len(topic_parts), 1), 1.0)

    # Bonus for academic indicators
    academic_bonus = 0.15 if _is_academic_indicator(title, snippet) else 0.0

    # Bonus for blockchain/crypto context
    crypto_keywords = [
        "blockchain",
        "bitcoin",
        "cryptocurrency",
        "ledger",
        "smart contract",
        "consensus",
        "decentralized",
    ]
    crypto_bonus = 0.1 if any(kw in combined for kw in crypto_keywords) else 0.0

    return min(word_score * 0.7 + academic_bonus + crypto_bonus, 1.0)


def search_topic(
    topic_key: str,
    query: str,
    max_results: int = MAX_PAPERS_PER_TOPIC,
    db_path: str = DEFAULT_DB,
) -> list[dict]:
    """Search for academic papers on a single topic.

    Attempts to use the web_search API template. Falls back gracefully
    if search is unavailable.

    Args:
        topic_key:    Short identifier for the topic.
        query:        Full search query string.
        max_results:  Maximum papers to return.
        db_path:      Path to the evidence database.

    Returns:
        List of paper dicts with: title, url, snippet, confidence, persisted_id.
    """
    try:
        from core.api_templates.web_search import search as web_search
    except ImportError:
        logger.info(
            "web_search module not available; returning empty results for %s",
            topic_key,
        )
        return []

    # Prefix query to bias toward academic content
    academic_query = f"academic paper research {query}"

    try:
        response = web_search(query=academic_query, max_results=max_results * 2)
    except Exception as exc:
        logger.warning("Search failed for topic %s: %s", topic_key, exc)
        return []

    if response.get("status") != "success":
        logger.info(
            "Search returned non-success for %s: %s",
            topic_key,
            response.get("status"),
        )
        return []

    papers = []
    for result in response.get("results", []):
        title = result.get("title", "")
        url = result.get("url", "")
        snippet = result.get("snippet", "")

        if len(snippet) < MIN_SNIPPET_LENGTH:
            continue

        confidence = _estimate_relevance(topic_key, title, snippet)
        if confidence < 0.2:
            continue

        persisted_id = _persist_paper(
            db_path=db_path,
            topic=topic_key,
            title=title,
            url=url,
            snippet=snippet,
            confidence=confidence,
        )

        papers.append(
            {
                "topic": topic_key,
                "title": title,
                "url": url,
                "snippet": snippet,
                "confidence": round(confidence, 3),
                "persisted_id": persisted_id,
            }
        )

        if len(papers) >= max_results:
            break

    return papers


def search_all_topics(
    db_path: str = DEFAULT_DB,
    max_per_topic: int = MAX_PAPERS_PER_TOPIC,
) -> dict:
    """Search for academic papers across all Zenon-relevant topics.

    Returns a summary dict with results grouped by topic.
    """
    all_results: dict[str, list[dict]] = {}
    total_found = 0
    total_persisted = 0

    for topic_key, query, _description in RESEARCH_TOPICS:
        logger.info("Searching literature for topic: %s", topic_key)
        papers = search_topic(
            topic_key=topic_key,
            query=query,
            max_results=max_per_topic,
            db_path=db_path,
        )
        if papers:
            all_results[topic_key] = papers
            total_found += len(papers)
            total_persisted += sum(1 for p in papers if p.get("persisted_id") is not None)

    return {
        "status": "success",
        "topics_searched": len(RESEARCH_TOPICS),
        "topics_with_results": len(all_results),
        "total_papers_found": total_found,
        "total_persisted": total_persisted,
        "results": all_results,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def get_cached_papers(
    db_path: str = DEFAULT_DB,
    topic: str | None = None,
    limit: int = 50,
) -> list[dict]:
    """Retrieve previously discovered papers from the evidence database.

    Args:
        db_path:  Path to the evidence database.
        topic:    Optional topic filter (e.g. "ptlc", "atomic_swap").
        limit:    Maximum number of results.

    Returns:
        List of paper dicts from the database.
    """
    _init_db(db_path)
    if topic:
        return query_table(
            db_path=db_path,
            table="evidence",
            where="engine = 'literature_engine' AND evidence_type = ?",
            params=(f"academic_paper_{topic}",),
            order_by="confidence DESC, created_at DESC",
            limit=limit,
        )
    return query_table(
        db_path=db_path,
        table="evidence",
        where="engine = 'literature_engine'",
        order_by="confidence DESC, created_at DESC",
        limit=limit,
    )


def summarize_findings(
    results: dict | None = None,
    db_path: str = DEFAULT_DB,
) -> str:
    """Generate a human-readable summary of literature findings.

    If results are not provided, reads from the cached database.
    """
    if results is None:
        papers = get_cached_papers(db_path=db_path, limit=100)
        if not papers:
            return "No academic papers found yet. Run search_all_topics() first."

        # Group by topic
        by_topic: dict[str, list] = {}
        for paper in papers:
            etype = paper.get("evidence_type", "")
            topic = etype.replace("academic_paper_", "") if etype else "unknown"
            by_topic.setdefault(topic, []).append(paper)

        lines = [f"Literature Review: {len(papers)} papers across {len(by_topic)} topics\n"]
        for topic, topic_papers in sorted(by_topic.items()):
            lines.append(f"  {topic}: {len(topic_papers)} papers")
            for p in topic_papers[:3]:
                lines.append(f"    - {p.get('finding', '')[:120]}")
        return "\n".join(lines)

    # Summarize from fresh search results
    topic_results = results.get("results", {})
    if not topic_results:
        return "No papers found in the latest search."

    lines = [
        f"Literature Search Complete: {results['total_papers_found']} papers "
        f"across {results['topics_with_results']}/{results['topics_searched']} topics\n",
    ]
    for topic_key, papers in sorted(topic_results.items()):
        desc = next(
            (d for k, _, d in RESEARCH_TOPICS if k == topic_key),
            topic_key,
        )
        lines.append(f"  {topic_key} ({len(papers)} papers) -- {desc}")
        for p in papers[:3]:
            conf = p.get("confidence", 0)
            lines.append(f"    [{conf:.0%}] {p['title'][:80]}")
            if p.get("url"):
                lines.append(f"         {p['url']}")

    return "\n".join(lines)
