# SPDX-License-Identifier: MIT
"""
ProductSurface -- Map the user-facing product surface of Zenon.

Scans bridge dApps, explorers, wallets, and marketing sites to understand
what products exist, their quality signals, and what is missing compared
to a competitive L1 ecosystem.

Sources:
    - DexterLabZ/bridge-dapp, sol-znn/bridge-dapp  (bridge UI)
    - zenonhub-io repos (explorer)
    - syriuswallet.com content (wallet marketing)
    - zenon.org / zenon.network website repos
"""

import logging
import os
from pathlib import Path

from core.persist_to_db import ensure_schema, persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

ZENON_WORKSPACE = Path(os.environ.get("ZENON_WORKSPACE_ROOT", str(ENGINE_ROOT.parents[1])))

# Product repos to scan
PRODUCT_REPOS = {
    "bridge-dapp (DexterLabZ)": {
        "paths": [
            ZENON_WORKSPACE / "DexterLabZ" / "bridge-dapp",
        ],
        "category": "bridge_ui",
        "description": "Bridge dApp for wrapping/unwrapping between Zenon and EVM chains",
    },
    "bridge-dapp (sol-znn)": {
        "paths": [
            ZENON_WORKSPACE / "sol-znn" / "bridge-dapp",
        ],
        "category": "bridge_ui",
        "description": "Alternative bridge dApp fork",
    },
    "zenonhub": {
        "paths": [
            ZENON_WORKSPACE / "zenonhub-io" / "zenonhub",
            ZENON_WORKSPACE / "infrastructure" / "zenonhub",
        ],
        "category": "explorer",
        "description": "Primary block explorer and analytics platform",
    },
    "zenonhub-explorer": {
        "paths": [
            ZENON_WORKSPACE / "zenonhub-io" / "explorer",
        ],
        "category": "explorer",
        "description": "Explorer frontend",
    },
    "syrius": {
        "paths": [
            ZENON_WORKSPACE / "core" / "syrius",
            ZENON_WORKSPACE / "zenon-network" / "syrius",
            ZENON_WORKSPACE / "hypercore-one" / "syrius",
        ],
        "category": "wallet",
        "description": "Official desktop/mobile wallet",
    },
    "zenon.network-website": {
        "paths": [
            ZENON_WORKSPACE / "zenon-network" / "zenon.network",
            ZENON_WORKSPACE / "infrastructure" / "zenon.network",
        ],
        "category": "website",
        "description": "Main project website",
    },
    "syriuswallet.com": {
        "paths": [
            ZENON_WORKSPACE / "zenon-network" / "syriuswallet.com",
            ZENON_WORKSPACE / "infrastructure" / "syriuswallet.com",
        ],
        "category": "website",
        "description": "Wallet download/marketing site",
    },
    "blockscout": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "blockscout",
        ],
        "category": "explorer",
        "description": "EVM-compatible block explorer fork for extension chains",
    },
    "wallet-connect-demo": {
        "paths": [
            ZENON_WORKSPACE / "hypercore-one" / "wallet-connect",
            ZENON_WORKSPACE / "DexterLabZ" / "wallet-connect",
        ],
        "category": "integration",
        "description": "WalletConnect integration demo",
    },
}

# What a competitive L1 ecosystem should have
COMPETITIVE_SURFACE = {
    "wallet": "Desktop + mobile wallet with staking, delegation, token management",
    "explorer": "Block explorer with transaction search, account pages, token tracking",
    "bridge_ui": "User-friendly bridge dApp for cross-chain transfers",
    "dex": "Decentralized exchange for token trading",
    "nft_marketplace": "NFT minting and trading platform",
    "lending": "Lending/borrowing protocol",
    "governance_ui": "Governance portal for proposal viewing and voting",
    "developer_docs": "Developer documentation portal with API reference",
    "faucet": "Testnet faucet for developers",
    "sdk_playground": "Interactive SDK playground or code examples",
    "website": "Marketing website with clear value proposition",
    "analytics": "Network analytics dashboard (TVL, volume, users)",
}


def _read_file(filepath: Path, max_bytes: int = 300_000) -> str:
    """Read file text, returning empty string on failure."""
    try:
        return filepath.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _find_repo(paths: list[Path]) -> Path | None:
    """Find the first existing path from a list of candidates."""
    for p in paths:
        if p.is_dir():
            return p
    return None


def _assess_quality(repo_path: Path) -> dict:
    """Assess basic quality signals for a product repo.

    Checks for: README, tests, CI, dependencies, recent activity.
    """
    signals = {
        "has_readme": False,
        "has_tests": False,
        "has_ci": False,
        "has_license": False,
        "has_package_manager": False,
        "estimated_size": "unknown",
        "languages": [],
        "quality_score": 0,
    }

    # README
    for name in ["README.md", "readme.md", "README.rst", "README.txt"]:
        if (repo_path / name).exists():
            signals["has_readme"] = True
            break

    # Tests
    test_indicators = [
        "test",
        "tests",
        "spec",
        "specs",
        "__tests__",
    ]
    for indicator in test_indicators:
        if (repo_path / indicator).is_dir():
            signals["has_tests"] = True
            break
    if not signals["has_tests"]:
        # Check for test files
        for pattern in ["**/*_test.*", "**/*.test.*", "**/*.spec.*", "**/test_*.*"]:
            if list(repo_path.glob(pattern))[:1]:
                signals["has_tests"] = True
                break

    # CI
    signals["has_ci"] = (repo_path / ".github" / "workflows").is_dir()

    # License
    for name in ["LICENSE", "LICENSE.md", "LICENSE.txt", "COPYING"]:
        if (repo_path / name).exists():
            signals["has_license"] = True
            break

    # Package manager
    pm_files = [
        "package.json",
        "pubspec.yaml",
        "go.mod",
        "Cargo.toml",
        "requirements.txt",
        "pyproject.toml",
        "composer.json",
    ]
    for pm in pm_files:
        if (repo_path / pm).exists():
            signals["has_package_manager"] = True
            break

    # Languages
    lang_map = {
        ".ts": "TypeScript",
        ".tsx": "TypeScript",
        ".js": "JavaScript",
        ".dart": "Dart",
        ".go": "Go",
        ".py": "Python",
        ".rs": "Rust",
        ".php": "PHP",
        ".sol": "Solidity",
        ".vue": "Vue",
        ".svelte": "Svelte",
        ".jsx": "React",
    }
    detected = set()
    for f in repo_path.rglob("*"):
        if ".git" in str(f) or "node_modules" in str(f) or "vendor" in str(f):
            continue
        if f.is_file() and f.suffix in lang_map:
            detected.add(lang_map[f.suffix])
        if len(detected) >= 5:
            break
    signals["languages"] = sorted(detected)

    # Simple quality score
    score = 0
    if signals["has_readme"]:
        score += 20
    if signals["has_tests"]:
        score += 25
    if signals["has_ci"]:
        score += 20
    if signals["has_license"]:
        score += 10
    if signals["has_package_manager"]:
        score += 10
    if signals["languages"]:
        score += 15
    signals["quality_score"] = score

    return signals


def scan_product(product_name: str, config: dict) -> dict:
    """Scan a single product repo.

    Returns dict with exists, quality, category, and description.
    """
    result = {
        "product": product_name,
        "category": config["category"],
        "description": config["description"],
        "exists": False,
        "path": None,
        "quality": {},
    }

    repo_path = _find_repo(config["paths"])
    if not repo_path:
        return result

    result["exists"] = True
    result["path"] = str(repo_path.relative_to(ZENON_WORKSPACE))
    result["quality"] = _assess_quality(repo_path)

    return result


def generate_report() -> dict:
    """Generate a full product surface report."""
    products = {}
    for name, config in PRODUCT_REPOS.items():
        products[name] = scan_product(name, config)

    # Coverage analysis: what categories exist vs competitive baseline
    found_categories = set()
    for p in products.values():
        if p["exists"]:
            found_categories.add(p["category"])

    missing_categories = set(COMPETITIVE_SURFACE.keys()) - found_categories
    coverage_pct = (
        len(found_categories) / len(COMPETITIVE_SURFACE) * 100 if COMPETITIVE_SURFACE else 0
    )

    # Quality summary
    found_products = [p for p in products.values() if p["exists"]]
    avg_quality = (
        sum(p["quality"].get("quality_score", 0) for p in found_products) / len(found_products)
        if found_products
        else 0
    )

    return {
        "products": products,
        "coverage": {
            "found_categories": sorted(found_categories),
            "missing_categories": sorted(missing_categories),
            "coverage_pct": round(coverage_pct, 1),
            "competitive_baseline": COMPETITIVE_SURFACE,
        },
        "summary": {
            "total_scanned": len(PRODUCT_REPOS),
            "found": len(found_products),
            "avg_quality_score": round(avg_quality, 1),
            "coverage_pct": round(coverage_pct, 1),
            "missing_categories": sorted(missing_categories),
        },
    }


def persist_findings(db_path: str = DEFAULT_DB) -> int:
    """Run product surface analysis and persist findings.

    Returns number of findings persisted.
    """
    ensure_schema(db_path)
    report = generate_report()
    count = 0

    summary = report["summary"]
    missing = ", ".join(summary["missing_categories"]) or "none"
    persist_finding(
        db_path=db_path,
        domain="product_market_fit",
        engine="product_surface",
        evidence_type="product_surface_overall",
        finding=(
            f"WHAT: Product surface covers {summary['coverage_pct']}% of competitive baseline "
            f"({summary['found']}/{summary['total_scanned']} products found, "
            f"avg quality {summary['avg_quality_score']}/100). "
            f"SO WHAT: Missing categories ({missing}) mean users cannot access "
            f"standard L1 ecosystem features, hurting adoption vs competitors. "
            f"NOW WHAT: Prioritize building or sourcing products for: {missing}. "
            f"For existing products below 50/100 quality, add tests and CI."
        ),
        confidence=0.85,
        raw_data=report,
        source_repo="workspace",
    )
    count += 1

    # Per-product findings
    for name, product in report["products"].items():
        if product["exists"]:
            q = product["quality"]
            score = q.get("quality_score", 0)
            gaps = []
            if not q.get("has_tests"):
                gaps.append("tests")
            if not q.get("has_ci"):
                gaps.append("CI")
            gap_text = ", ".join(gaps) if gaps else "none"
            persist_finding(
                db_path=db_path,
                domain="product_market_fit",
                engine="product_surface",
                evidence_type="product_assessment",
                finding=(
                    f"WHAT: {name} ({product['category']}) scores {score}/100 "
                    f"(missing: {gap_text}). "
                    f"SO WHAT: {'Low quality score reduces user trust and maintainability.' if score < 50 else 'Acceptable quality but gaps remain.'} "
                    f"NOW WHAT: {'Add ' + gap_text + ' to bring score above 50.' if gaps else 'Maintain current quality level.'}"
                ),
                confidence=0.80,
                raw_data=product,
                source_repo=product.get("path"),
            )
        else:
            persist_finding(
                db_path=db_path,
                domain="product_market_fit",
                engine="product_surface",
                evidence_type="product_missing",
                finding=(
                    f"WHAT: {name} ({product['category']}) not found locally. "
                    f"SO WHAT: This product ({product['description']}) is expected "
                    f"but missing, leaving a gap in the ecosystem. "
                    f"NOW WHAT: Clone or create this repo, or confirm it has been "
                    f"deprecated and remove from tracking."
                ),
                confidence=0.70,
                raw_data=product,
                source_repo="workspace",
            )
        count += 1

    # Gap findings for missing competitive categories
    for category in report["coverage"]["missing_categories"]:
        baseline = COMPETITIVE_SURFACE.get(category, "N/A")
        persist_finding(
            db_path=db_path,
            domain="product_market_fit",
            engine="product_surface",
            evidence_type="product_gap",
            finding=(
                f"WHAT: No '{category}' product exists in the Zenon ecosystem. "
                f"SO WHAT: Competing L1s offer {baseline} — without this, "
                f"Zenon loses users who expect it as table stakes. "
                f"NOW WHAT: Identify community teams who could build a {category} product, "
                f"or submit an Accelerator-Z proposal to fund development."
            ),
            confidence=0.75,
            raw_data={"category": category, "baseline": baseline},
            source_repo="workspace",
        )
        count += 1

    logger.info("ProductSurface: persisted %d findings", count)
    return count
