# SPDX-License-Identifier: MIT
"""
ComparativeEngine -- Compare Zenon against ecosystem benchmarks.

Compares Zenon's architecture, launch, community, and development patterns
against reference projects (Bitcoin, Monero, Grin, and configurable
competitors). Produces relative positioning findings.

Generalized from marketing's comparative_engine.py. Uses Nebula's standard
evidence persistence and FingerprintedSession for API provenance.

Reads:  GitHub API (commit counts, stars, contributors)
Writes: evidence table (comparison findings)
"""

import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


# ---------------------------------------------------------------------------
# Reference project facts (used as comparison baselines)
# ---------------------------------------------------------------------------

REFERENCE_PROJECTS: dict[str, dict] = {
    "bitcoin": {
        "name": "Bitcoin",
        "genesis_date": "2009-01-03",
        "launch_mechanism": "Fair mining -- no premine, no ICO",
        "founder_pseudonym": "Satoshi Nakamoto",
        "founder_departure_years_after_genesis": 2.3,
        "team_anonymity": "founder_anonymous",
        "governance": "community_governed",
        "architecture": "UTXO chain",
        "language": "C++",
        "cypherpunk_values": True,
        "github_repo": "bitcoin/bitcoin",
    },
    "monero": {
        "name": "Monero",
        "genesis_date": "2014-04-18",
        "launch_mechanism": "Fair mining -- no premine, no ICO",
        "founder_pseudonym": "thankful_for_today",
        "founder_departure_years_after_genesis": 0.1,
        "team_anonymity": "fully_anonymous",
        "governance": "community_governed",
        "architecture": "CryptoNote chain",
        "language": "C++",
        "cypherpunk_values": True,
        "github_repo": "monero-project/monero",
    },
    "grin": {
        "name": "Grin",
        "genesis_date": "2019-01-15",
        "launch_mechanism": "Fair mining -- no premine, no founders reward",
        "founder_pseudonym": "Ignotus Peverell",
        "founder_departure_years_after_genesis": 1.8,
        "team_anonymity": "founder_anonymous",
        "governance": "community_governed",
        "architecture": "MimbleWimble",
        "language": "Rust",
        "cypherpunk_values": True,
        "github_repo": "mimblewimble/grin",
    },
    "zenon": {
        "name": "Zenon Network",
        "genesis_date": "2021-11-24",
        "launch_mechanism": "xStakes -- returned value to early participants",
        "founder_pseudonym": "Professor Z / Kaine",
        "founder_departure_years_after_genesis": 1.7,
        "team_anonymity": "fully_anonymous",
        "governance": "community_governed",
        "architecture": "block-lattice (dual ledger)",
        "language": "Go",
        "cypherpunk_values": True,
        "github_repo": "zenon-network/go-zenon",
    },
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class ComparisonDimension:
    """A single dimension of comparison between projects."""

    dimension: str
    values: dict[str, str]
    parallel: str
    strength: float = 0.0


@dataclass
class ComparisonResult:
    """Result of a full project comparison."""

    target_project: str
    reference_project: str
    dimensions: list[ComparisonDimension]
    github_metrics: dict = field(default_factory=dict)
    summary: str = ""
    confidence: float = 0.0


# ---------------------------------------------------------------------------
# ComparativeEngine
# ---------------------------------------------------------------------------


class ComparativeEngine:
    """Cross-project pattern matching for ecosystem positioning.

    Usage::

        engine = ComparativeEngine()
        result = engine.compare("zenon", "bitcoin")
        for dim in result.dimensions:
            print(f"{dim.dimension}: {dim.parallel} (strength: {dim.strength})")

        # Or compare GitHub metrics
        metrics = engine.compare_github_metrics(
            ["zenon-network/go-zenon", "bitcoin/bitcoin", "monero-project/monero"]
        )
    """

    def __init__(self, db_path: str = DEFAULT_DB) -> None:
        self.db_path = db_path
        self._session = None

    @property
    def session(self):
        """Lazy-init HTTP session."""
        if self._session is None:
            try:
                from core.api_fingerprint import FingerprintedSession

                self._session = FingerprintedSession(engine_name="comparative_engine")
            except ImportError:
                import requests

                self._session = requests.Session()
        return self._session

    # ------------------------------------------------------------------
    # Structural comparison
    # ------------------------------------------------------------------

    def compare(
        self,
        target: str = "zenon",
        reference: str = "bitcoin",
    ) -> ComparisonResult:
        """Structural comparison between two projects.

        Args:
            target:    Project key from REFERENCE_PROJECTS.
            reference: Project key to compare against.

        Returns:
            ComparisonResult with dimension-by-dimension analysis.
        """
        target_facts = REFERENCE_PROJECTS.get(target, {})
        ref_facts = REFERENCE_PROJECTS.get(reference, {})

        if not target_facts or not ref_facts:
            raise ValueError(
                f"Unknown project: target={target}, reference={reference}. "
                f"Known projects: {list(REFERENCE_PROJECTS.keys())}"
            )

        dimensions: list[ComparisonDimension] = []

        # Genesis comparison
        dimensions.append(
            ComparisonDimension(
                dimension="genesis",
                values={
                    target: target_facts["genesis_date"],
                    reference: ref_facts["genesis_date"],
                },
                parallel="Both projects have significant genesis block content",
                strength=0.7,
            )
        )

        # Launch mechanism
        dimensions.append(
            ComparisonDimension(
                dimension="launch_mechanism",
                values={
                    target: target_facts["launch_mechanism"],
                    reference: ref_facts["launch_mechanism"],
                },
                parallel=(
                    "Both used fair-launch mechanisms that returned value to "
                    "participants rather than extracting it"
                ),
                strength=0.75 if "fair" in ref_facts["launch_mechanism"].lower() else 0.4,
            )
        )

        # Founder disappearance
        t_departure = target_facts.get("founder_departure_years_after_genesis", 0)
        r_departure = ref_facts.get("founder_departure_years_after_genesis", 0)
        departure_similarity = 1.0 - min(1.0, abs(t_departure - r_departure) / 3.0)
        dimensions.append(
            ComparisonDimension(
                dimension="founder_departure",
                values={
                    target: f"{target_facts.get('founder_pseudonym', '?')} departed ~{t_departure}y after genesis",
                    reference: f"{ref_facts.get('founder_pseudonym', '?')} departed ~{r_departure}y after genesis",
                },
                parallel="Both founders departed after establishing the project",
                strength=round(departure_similarity, 2),
            )
        )

        # Governance
        same_governance = target_facts.get("governance") == ref_facts.get("governance")
        dimensions.append(
            ComparisonDimension(
                dimension="governance",
                values={
                    target: target_facts.get("governance", "unknown"),
                    reference: ref_facts.get("governance", "unknown"),
                },
                parallel="Both are community-governed"
                if same_governance
                else "Different governance models",
                strength=0.8 if same_governance else 0.2,
            )
        )

        # Cypherpunk values
        both_cypherpunk = target_facts.get("cypherpunk_values") and ref_facts.get(
            "cypherpunk_values"
        )
        dimensions.append(
            ComparisonDimension(
                dimension="cypherpunk_values",
                values={
                    target: str(target_facts.get("cypherpunk_values", False)),
                    reference: str(ref_facts.get("cypherpunk_values", False)),
                },
                parallel="Both embody cypherpunk values"
                if both_cypherpunk
                else "Different value orientation",
                strength=0.85 if both_cypherpunk else 0.1,
            )
        )

        # Compute overall confidence
        avg_strength = sum(d.strength for d in dimensions) / len(dimensions) if dimensions else 0.0

        strong_dims = [d for d in dimensions if d.strength >= 0.5]
        weak_dims = [d for d in dimensions if d.strength < 0.5]
        strong_names = ", ".join(d.dimension for d in strong_dims) if strong_dims else "none"
        weak_names = ", ".join(d.dimension for d in weak_dims) if weak_dims else "none"

        result = ComparisonResult(
            target_project=target,
            reference_project=reference,
            dimensions=dimensions,
            summary=(
                f"WHAT: {len(strong_dims)}/{len(dimensions)} dimensions show strong parallels "
                f"between {target_facts['name']} and {ref_facts['name']} (strong: {strong_names}). "
                f"SO WHAT: These parallels inform positioning — strong dimensions are messaging assets, "
                f"weak dimensions ({weak_names}) are differentiation gaps. "
                f"NOW WHAT: Lead marketing with {strong_names} parallels; "
                f"investigate why {weak_names} scored low and whether to close or embrace the gap."
            ),
            confidence=round(avg_strength, 3),
        )

        # Persist finding
        self._persist_comparison(result)

        return result

    def compare_all(self, target: str = "zenon") -> list[ComparisonResult]:
        """Compare target against all other reference projects."""
        results = []
        for ref_key in REFERENCE_PROJECTS:
            if ref_key == target:
                continue
            try:
                result = self.compare(target, ref_key)
                results.append(result)
            except Exception as exc:
                logger.error("Comparison failed for %s vs %s: %s", target, ref_key, exc)
        return results

    # ------------------------------------------------------------------
    # GitHub metrics comparison
    # ------------------------------------------------------------------

    def compare_github_metrics(self, repos: list[str]) -> dict[str, dict]:
        """Compare GitHub metrics (stars, forks, contributors) across repos.

        Args:
            repos: List of "owner/repo" strings.

        Returns:
            Dict mapping repo name to metrics dict.
        """
        gh_token = os.getenv("GITHUB_TOKEN", "")
        headers: dict[str, str] = {}
        if gh_token:
            headers["Authorization"] = f"token {gh_token}"

        metrics: dict[str, dict] = {}

        for repo in repos:
            try:
                resp = self.session.get(
                    f"https://api.github.com/repos/{repo}",
                    headers=headers,
                    timeout=15,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    metrics[repo] = {
                        "stars": data.get("stargazers_count", 0),
                        "forks": data.get("forks_count", 0),
                        "open_issues": data.get("open_issues_count", 0),
                        "language": data.get("language"),
                        "last_push": data.get("pushed_at"),
                        "created_at": data.get("created_at"),
                        "size_kb": data.get("size", 0),
                    }

                    # Get contributor count
                    contrib_resp = self.session.get(
                        f"https://api.github.com/repos/{repo}/contributors",
                        params={"per_page": 1, "anon": "true"},
                        headers=headers,
                        timeout=10,
                    )
                    if contrib_resp.status_code == 200:
                        # Parse Link header for total count
                        link = contrib_resp.headers.get("Link", "")
                        if "last" in link:
                            import re

                            match = re.search(r'page=(\d+)>; rel="last"', link)
                            if match:
                                metrics[repo]["contributors"] = int(match.group(1))
                            else:
                                metrics[repo]["contributors"] = len(contrib_resp.json())
                        else:
                            metrics[repo]["contributors"] = len(contrib_resp.json())

                else:
                    metrics[repo] = {"error": f"HTTP {resp.status_code}"}

            except Exception as exc:
                metrics[repo] = {"error": str(exc)}
                logger.debug("GitHub metrics failed for %s: %s", repo, exc)

        logger.info("GitHub metrics collected for %d repos", len(metrics))
        return metrics

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def _persist_comparison(self, result: ComparisonResult) -> None:
        """Store a comparison result as evidence."""
        try:
            from core.persist_to_db import persist_finding

            persist_finding(
                db_path=self.db_path,
                engine="comparative_engine",
                evidence_type="cross_project_comparison",
                finding=result.summary,
                confidence=result.confidence,
                raw_data={
                    "target": result.target_project,
                    "reference": result.reference_project,
                    "dimensions": [
                        {
                            "dimension": d.dimension,
                            "parallel": d.parallel,
                            "strength": d.strength,
                        }
                        for d in result.dimensions
                    ],
                },
                source_repo="workspace",
                domain="product_market_fit",
            )
        except Exception as exc:
            logger.debug("Could not persist comparison: %s", exc)
