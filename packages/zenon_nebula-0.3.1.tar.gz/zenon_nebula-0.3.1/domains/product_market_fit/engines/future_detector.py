# SPDX-License-Identifier: MIT
"""
FutureDetector -- Scan for signals of future changes affecting Zenon.

Tracks:
- New BIPs that could affect Zenon's Bitcoin interop (via web search)
- Competitor commit velocity (imminent launches)
- GitHub trending repos in blockchain/crypto
- Ecosystem shifts (new narratives, regulatory changes)

Synthesizes signals into predictions with confidence, recommended
actions, and optimal timing.

Generalized from marketing's future_detector.py. Uses Nebula's standard
FingerprintedSession and model_router for LLM selection.

Reads:  GitHub API, web search results
Writes: evidence table (high-confidence predictions)
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# GitHub search API
GITHUB_SEARCH_URL = "https://api.github.com/search/repositories"

# Default competitor repos to watch for velocity changes
DEFAULT_COMPETITOR_REPOS = [
    "celestiaorg/celestia-node",
    "ethereum/go-ethereum",
    "solana-labs/solana",
    "cosmos/cosmos-sdk",
    "AztecProtocol/aztec-packages",
    "starkware-libs/cairo",
    "MystenLabs/sui",
    "aptos-labs/aptos-core",
]

# Default search queries for trending signal detection
DEFAULT_SEARCH_QUERIES = [
    "Bitcoin BIP proposal",
    "bitcoin-dev mailing list new proposal",
    "Bitcoin scripting covenant",
]


class FutureDetector:
    """Scan for weak signals of future ecosystem changes.

    Usage::

        detector = FutureDetector()
        result = detector.predict()
        for pred in result.get("predictions", []):
            print(f"{pred['trend']} (confidence: {pred['confidence']})")
    """

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        competitor_repos: list[str] | None = None,
        search_queries: list[str] | None = None,
    ) -> None:
        self.db_path = db_path
        self.competitor_repos = competitor_repos or DEFAULT_COMPETITOR_REPOS
        self.search_queries = search_queries or DEFAULT_SEARCH_QUERIES
        self._session = None

    @property
    def session(self):
        """Lazy-init FingerprintedSession."""
        if self._session is None:
            try:
                from core.api_fingerprint import FingerprintedSession

                self._session = FingerprintedSession(engine_name="future_detector")
            except ImportError:
                logger.debug("FingerprintedSession not available")
                import requests

                self._session = requests.Session()
        return self._session

    # ------------------------------------------------------------------
    # Signal collectors
    # ------------------------------------------------------------------

    def scan_github_trending(self) -> list[dict]:
        """Track trending blockchain/crypto repositories on GitHub."""
        signals: list[dict] = []
        queries = [
            "blockchain language:rust stars:>50",
            "bitcoin language:python stars:>20",
            "zero-knowledge proof language:rust stars:>30",
            "layer2 bitcoin stars:>10",
        ]

        gh_token = os.getenv("GITHUB_TOKEN", "")
        headers: dict[str, str] = {}
        if gh_token:
            headers["Authorization"] = f"token {gh_token}"

        for query in queries:
            try:
                resp = self.session.get(
                    GITHUB_SEARCH_URL,
                    params={
                        "q": query,
                        "sort": "stars",
                        "order": "desc",
                        "per_page": 5,
                    },
                    headers=headers,
                    timeout=15,
                )
                if resp.status_code == 200:
                    data = resp.json()
                    for repo in data.get("items", [])[:5]:
                        signals.append(
                            {
                                "source": "github_trending",
                                "repo": repo.get("full_name"),
                                "description": (repo.get("description") or "")[:200],
                                "stars": repo.get("stargazers_count", 0),
                                "language": repo.get("language"),
                                "url": repo.get("html_url"),
                            }
                        )
            except Exception as exc:
                logger.debug("GitHub trending scan failed for '%s': %s", query, exc)

        logger.info("GitHub trending found %d signals", len(signals))
        return signals

    def scan_competitor_velocity(self) -> list[dict]:
        """Track competitor commit velocity -- detect imminent launches."""
        signals: list[dict] = []
        gh_token = os.getenv("GITHUB_TOKEN", "")
        headers: dict[str, str] = {}
        if gh_token:
            headers["Authorization"] = f"token {gh_token}"

        launch_keywords = [
            "release",
            "launch",
            "mainnet",
            "v1.",
            "v2.",
            "breaking change",
            "migration",
            "upgrade",
            "production",
            "deploy",
            "genesis",
        ]

        for repo in self.competitor_repos:
            try:
                resp = self.session.get(
                    f"https://api.github.com/repos/{repo}/commits",
                    params={"per_page": 30},
                    headers=headers,
                    timeout=15,
                )
                if resp.status_code != 200:
                    continue

                commits = resp.json()
                if not commits:
                    continue

                commit_messages = [
                    c.get("commit", {}).get("message", "")[:200] for c in commits[:30]
                ]

                launch_signals = sum(
                    1 for msg in commit_messages if any(kw in msg.lower() for kw in launch_keywords)
                )

                signals.append(
                    {
                        "source": "competitor_velocity",
                        "repo": repo,
                        "commits_recent": len(commits),
                        "launch_signal_count": launch_signals,
                        "velocity": (
                            "high"
                            if len(commits) > 20
                            else "medium"
                            if len(commits) > 10
                            else "low"
                        ),
                        "potential_launch": launch_signals >= 3,
                    }
                )

            except Exception as exc:
                logger.debug("Competitor scan failed for %s: %s", repo, exc)

        logger.info("Competitor velocity scan: %d repos analyzed", len(signals))
        return signals

    def scan_web_signals(self) -> list[dict]:
        """Scan web for relevant signals using SETI or fallback search."""
        signals: list[dict] = []

        try:
            from core.api_templates.web_search import search as web_search

            for query in self.search_queries:
                try:
                    results = web_search(query, max_results=3)
                    for r in results:
                        signals.append(
                            {
                                "source": "web_search",
                                "query": query,
                                "title": r.get("title", ""),
                                "url": r.get("url", ""),
                                "snippet": r.get("snippet", "")[:300],
                            }
                        )
                except Exception as exc:
                    logger.debug("Web search failed for '%s': %s", query, exc)
        except ImportError:
            logger.debug("web_search not available -- skipping web signals")

        logger.info("Web signal scan found %d signals", len(signals))
        return signals

    # ------------------------------------------------------------------
    # Synthesis
    # ------------------------------------------------------------------

    def _synthesize(
        self,
        github_signals: list[dict],
        competitor_signals: list[dict],
        web_signals: list[dict],
    ) -> dict:
        """Synthesize all signals into trend predictions via LLM."""
        signal_context = json.dumps(
            {
                "github_trending": github_signals[:15],
                "competitor_velocity": competitor_signals,
                "web_signals": web_signals[:10],
                "current_date": datetime.now(timezone.utc).isoformat(),
            },
            indent=2,
            default=str,
        )

        prompt = (
            "Analyze these signals and predict what the crypto/blockchain "
            "ecosystem will focus on in 1-2 weeks. For each prediction, explain "
            "how the Zenon Network might be affected or positioned.\n\n"
            "Return JSON:\n"
            "{\n"
            '  "predictions": [\n'
            '    {"trend": "...", "confidence": 0.0-1.0, '
            '"timeframe_days": 7-21, "zenon_relevance": "...", '
            '"category": "bitcoin_dev|defi|infrastructure|narrative"}\n'
            "  ],\n"
            '  "meta_narrative": "overarching story across signals",\n'
            '  "urgency": "high|medium|low"\n'
            "}"
        )

        try:
            from core.llm_provider import call_llm
            from core.model_router import get_model
            from core.prompt_builder import build_system_prompt

            model = get_model("strategic_synthesis")
            system = build_system_prompt("product_market_fit")

            result = call_llm(
                prompt=f"{prompt}\n\nSignals:\n{signal_context}",
                system=system,
                model=model,
                max_tokens=2000,
            )

            text = result.get("text", "") if isinstance(result, dict) else str(result or "")
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                import re

                match = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text)
                if match:
                    return json.loads(match.group(1))
                return {"predictions": [], "raw_analysis": text[:1000]}

        except Exception as exc:
            logger.warning("Synthesis LLM call failed: %s", exc)
            return {
                "predictions": [],
                "raw_signals": {
                    "github": len(github_signals),
                    "competitor": len(competitor_signals),
                    "web": len(web_signals),
                },
            }

    # ------------------------------------------------------------------
    # Main entry
    # ------------------------------------------------------------------

    def predict(self) -> dict:
        """Run full prediction pipeline: collect signals, synthesize, persist.

        Returns:
            Dict with keys: ``signals_collected``, ``predictions``,
            ``meta_narrative``, ``urgency``, ``timestamp``.
        """
        logger.info("FutureDetector: starting prediction run")

        # Collect signals
        github_signals = self.scan_github_trending()
        competitor_signals = self.scan_competitor_velocity()
        web_signals = self.scan_web_signals()

        total = len(github_signals) + len(competitor_signals) + len(web_signals)
        logger.info(
            "Collected %d signals: %d GitHub, %d competitor, %d web",
            total,
            len(github_signals),
            len(competitor_signals),
            len(web_signals),
        )

        # Synthesize
        synthesis = self._synthesize(github_signals, competitor_signals, web_signals)

        predictions = synthesis.get("predictions", [])

        result = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "signals_collected": {
                "github_trending": len(github_signals),
                "competitor_velocity": len(competitor_signals),
                "web_signals": len(web_signals),
                "total": total,
            },
            "predictions": predictions,
            "meta_narrative": synthesis.get("meta_narrative", ""),
            "urgency": synthesis.get("urgency", "unknown"),
        }

        # Persist high-confidence predictions
        for pred in predictions:
            conf = pred.get("confidence", 0)
            if conf >= 0.6:
                try:
                    from core.persist_to_db import persist_finding

                    trend = pred.get("trend", "unknown")
                    relevance = pred.get("zenon_relevance", "none")
                    timeframe = pred.get("timeframe_days", "?")
                    category = pred.get("category", "unknown")
                    persist_finding(
                        db_path=self.db_path,
                        engine="future_detector",
                        evidence_type="trend_prediction",
                        finding=(
                            f"WHAT: Predicted trend ({conf:.0%}): {trend} (category: {category}, "
                            f"timeframe: {timeframe} days). "
                            f"SO WHAT: {relevance}. "
                            f"NOW WHAT: Monitor this trend; if confidence rises above 80%, "
                            f"prepare positioning content around Zenon's relevance to {category}."
                        ),
                        confidence=conf,
                        raw_data=pred,
                        domain="product_market_fit",
                        source_repo="web_search",
                    )
                except Exception as exc:
                    logger.debug("Could not persist prediction: %s", exc)

        logger.info("FutureDetector complete: %d predictions", len(predictions))
        return result
