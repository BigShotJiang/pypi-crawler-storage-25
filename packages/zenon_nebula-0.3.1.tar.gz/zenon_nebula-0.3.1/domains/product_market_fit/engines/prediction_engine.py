# SPDX-License-Identifier: MIT
"""
PredictionEngine -- Predict Zenon's next phase based on evidence and signals.

Loads all evidence and hypotheses from the DB, then uses an LLM to reason
about trajectory: spec progression, commit patterns, community signals,
competitive landscape. Produces strategic predictions with confidence levels.

Generalized from marketing's zenon_prediction_engine.py. Uses the standard
Nebula evidence table and model_router for LLM selection.

Reads:  evidence table, hypotheses table
Writes: evidence table (persists prediction as a finding)
"""

import json
import logging
from datetime import datetime, timezone
from pathlib import Path

from core.persist_to_db import query_table

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")


# ---------------------------------------------------------------------------
# Evidence and hypothesis loading
# ---------------------------------------------------------------------------


def _load_evidence(db_path: str, limit: int = 200) -> list[dict]:
    """Load recent evidence from the DB, ordered by confidence."""
    return query_table(
        db_path=db_path,
        table="evidence",
        order_by="confidence DESC",
        limit=limit,
    )


def _load_hypotheses(db_path: str) -> list[dict]:
    """Load all hypotheses from the DB."""
    return query_table(
        db_path=db_path,
        table="hypotheses",
        order_by="confidence DESC",
        limit=0,
    )


# ---------------------------------------------------------------------------
# PredictionEngine
# ---------------------------------------------------------------------------


class PredictionEngine:
    """Strategic trajectory predictor for the Zenon ecosystem.

    Synthesizes evidence, hypotheses, and external signals into
    forward-looking predictions about the ecosystem's next phase.

    Usage::

        engine = PredictionEngine()
        result = engine.predict()
        # result has: predictions, confidence, reasoning, timestamp
    """

    def __init__(self, db_path: str = DEFAULT_DB) -> None:
        self.db_path = db_path

    def predict(
        self,
        custom_prompt: str | None = None,
        evidence_limit: int = 200,
    ) -> dict:
        """Run a full prediction cycle.

        Args:
            custom_prompt:   Optional override for the analysis prompt.
            evidence_limit:  Max evidence rows to load.

        Returns:
            Dict with keys: ``predictions``, ``evidence_count``,
            ``hypothesis_count``, ``timestamp``, ``raw_analysis``.
        """
        evidence = _load_evidence(self.db_path, limit=evidence_limit)
        hypotheses = _load_hypotheses(self.db_path)

        logger.info(
            "PredictionEngine: loaded %d evidence, %d hypotheses",
            len(evidence),
            len(hypotheses),
        )

        # Build evidence summary (truncate for prompt size)
        evidence_summary = [
            {
                "id": e.get("id"),
                "engine": e.get("engine"),
                "type": e.get("evidence_type"),
                "finding": (e.get("finding") or "")[:300],
                "confidence": e.get("confidence"),
                "supports": e.get("supports_hypothesis"),
                "contradicts": e.get("contradicts_hypothesis"),
            }
            for e in evidence[:100]
        ]

        hypotheses_summary = [
            {
                "id": h.get("id"),
                "title": h.get("title"),
                "confidence": h.get("confidence"),
            }
            for h in hypotheses
        ]

        prompt = custom_prompt or self._build_default_prompt(
            evidence_summary,
            hypotheses_summary,
        )

        # Call LLM for analysis
        analysis = self._llm_analyze(prompt)

        result = {
            "predictions": self._extract_predictions(analysis),
            "evidence_count": len(evidence),
            "hypothesis_count": len(hypotheses),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "raw_analysis": analysis,
        }

        # Persist prediction as evidence
        self._persist_prediction(result)

        return result

    def _build_default_prompt(
        self,
        evidence_summary: list[dict],
        hypotheses_summary: list[dict],
    ) -> str:
        """Build the default analysis prompt."""
        return (
            "You are a strategic prediction engine for the Zenon Network ecosystem.\n\n"
            f"## EVIDENCE DATABASE ({len(evidence_summary)} findings)\n"
            f"{json.dumps(evidence_summary, indent=2)[:10000]}\n\n"
            f"## HYPOTHESES ({len(hypotheses_summary)} active)\n"
            f"{json.dumps(hypotheses_summary, indent=2)[:3000]}\n\n"
            "## YOUR TASK\n"
            "Analyze this evidence and predict Zenon's trajectory:\n\n"
            "1. What is the current development phase? (evidence-based assessment)\n"
            "2. What comes next? (based on spec progression and commit patterns)\n"
            "3. What are the most likely catalysts for the next phase?\n"
            "4. Timeline prediction with confidence ranges.\n"
            "5. Strategic recommendations for positioning.\n\n"
            "Return JSON:\n"
            "{\n"
            '  "current_phase": "...",\n'
            '  "predictions": [\n'
            '    {"event": "...", "confidence": 0.0-1.0, "timeframe": "...", "reasoning": "..."}\n'
            "  ],\n"
            '  "catalysts": ["..."],\n'
            '  "recommendations": ["..."]\n'
            "}"
        )

    def _llm_analyze(self, prompt: str) -> str:
        """Send the prompt to an LLM for analysis."""
        try:
            from core.model_router import get_model
            from core.prompt_builder import build_system_prompt, build_user_prompt

            system = build_system_prompt(
                "product_market_fit",
                include_critical_rules=True,
            )
            user_prompt = build_user_prompt(prompt)

            model = get_model("strategic_synthesis")

            try:
                from core.llm_provider import call_llm

                result = call_llm(
                    prompt=user_prompt,
                    system=system,
                    model=model,
                    max_tokens=4000,
                )
                if isinstance(result, dict):
                    return result.get("text", "")
                return str(result) if result else ""
            except Exception as exc:
                logger.warning("LLM call failed: %s", exc)
                return json.dumps(
                    {
                        "error": str(exc),
                        "current_phase": "unknown",
                        "predictions": [],
                        "catalysts": [],
                        "recommendations": [],
                    }
                )

        except ImportError:
            logger.warning("model_router or prompt_builder not available")
            return json.dumps(
                {
                    "error": "LLM infrastructure not available",
                    "predictions": [],
                }
            )

    @staticmethod
    def _extract_predictions(analysis: str) -> list[dict]:
        """Extract structured predictions from LLM output."""
        try:
            data = json.loads(analysis)
            return data.get("predictions", [])
        except json.JSONDecodeError:
            pass

        # Try to find JSON in markdown code blocks
        import re

        match = re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", analysis)
        if match:
            try:
                data = json.loads(match.group(1))
                return data.get("predictions", [])
            except json.JSONDecodeError:
                pass

        return []

    def _persist_prediction(self, result: dict) -> None:
        """Store prediction as evidence."""
        try:
            from core.persist_to_db import persist_finding

            predictions = result.get("predictions", [])
            pred_count = len(predictions)
            top_events = (
                ", ".join(p.get("event", "?")[:60] for p in predictions[:3])
                if predictions
                else "none"
            )
            high_conf = [p for p in predictions if p.get("confidence", 0) >= 0.7]
            persist_finding(
                db_path=self.db_path,
                engine="prediction_engine",
                evidence_type="strategic_trajectory_prediction",
                finding=(
                    f"WHAT: {pred_count} trajectory predictions generated; "
                    f"top events: {top_events}. "
                    f"SO WHAT: {len(high_conf)} predictions have high confidence (>=70%) "
                    f"and should inform near-term strategy and resource allocation. "
                    f"NOW WHAT: Review high-confidence predictions in raw_data; "
                    f"align development priorities with predicted catalysts; "
                    f"re-run after new evidence is collected to track confidence drift."
                ),
                confidence=0.5,
                raw_data=result,
                domain="product_market_fit",
                source_repo="workspace",
            )
        except Exception as exc:
            logger.debug("Could not persist prediction: %s", exc)
