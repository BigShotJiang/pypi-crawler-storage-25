"""Fabric module tests."""
