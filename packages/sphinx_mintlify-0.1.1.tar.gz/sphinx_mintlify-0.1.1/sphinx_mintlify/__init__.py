"""
Sphinx extension to generate organized markdown files for classes.
Creates a folder per class with individual method documentation files.
"""

import os
import inspect
from typing import List, Dict, Any, Optional, Union
from pathlib import Path

from sphinx.application import Sphinx
from sphinx.util import logging

from .generator import ClassMarkdownGenerator
from .config import setup_config
from .builder import MintlifyBuilder

logger = logging.getLogger(__name__)

def setup(app: Sphinx) -> Dict[str, Any]:
    """Set up the Sphinx extension.
    
    Args:
        app: The Sphinx application instance
        
    Returns:
        Dict containing extension metadata
    """
    # Register configuration values
    app.add_config_value('classmd_output_dir', None, 'env')
    app.add_config_value('classmd_classes', [], 'env')
    app.add_config_value('classmd_method_options', {
        'include_source': True,
        'include_examples': True,
        'group_by_type': True
    }, 'env')
    app.add_config_value('classmd_method_order', [
        '__init__',
        'public_methods',
        'private_methods',
        'static_methods',
        'class_methods'
    ], 'env')
    app.add_config_value('classmd_metadata', {
        'api_version': '1.0.0',
        'api_status': 'stable',
        'sidebar_label': 'API Reference',
        'sidebar_position': 2
    }, 'env')

    # Register the MDX builder
    app.add_builder(MintlifyBuilder)

    # Connect to Sphinx events
    app.connect('config-inited', setup_config)

    return {
        # This is the Sphinx extension API version (not the PyPI package version).
        # It indicates compatibility with Sphinx's extension interface.
        'version': '1.0.0',
        'parallel_read_safe': True,
        'parallel_write_safe': True,
    }