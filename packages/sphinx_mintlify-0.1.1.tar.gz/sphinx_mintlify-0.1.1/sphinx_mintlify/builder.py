"""Sphinx builder for Mintlify MDX documentation."""

from typing import Dict, Any, Set, Optional, AbstractSet
from os import path
from collections.abc import Iterator

from docutils import nodes
from sphinx.builders import Builder
from sphinx.util import logging
from sphinx.util.console import bold
from sphinx.environment import BuildEnvironment

from .generator import ClassMarkdownGenerator

logger = logging.getLogger(__name__)

class MintlifyBuilder(Builder):
    """Builder that generates Mintlify-compatible MDX documentation."""
    
    name = 'mdx'
    format = 'mdx'
    file_suffix = '.mdx'
    link_suffix = '.mdx'
    
    def __init__(self, app, env: Optional[BuildEnvironment] = None):
        super().__init__(app, env)
        self.generator = None
    
    def init(self) -> None:
        """Initialize the builder."""
        self.generator = ClassMarkdownGenerator(self.app)
    
    def get_outdated_docs(self) -> Iterator[str]:
        """Return an iterator of outdated docnames."""
        return iter([])
    
    def get_target_uri(self, docname: str, typ: Optional[str] = None) -> str:
        """Return the target URI for a document name."""
        return docname + self.link_suffix
    
    def prepare_writing(self, docnames: AbstractSet[str]) -> None:
        """Prepare for writing MDX files."""
        pass
    
    def write_doc(self, docname: str, doctree: nodes.document) -> None:
        """Generate MDX files for the configured classes."""
        if self.generator is None:
            self.init()
        pass
    
    def finish(self) -> None:
        """Generate all MDX documentation."""
        logger.info(bold('generating MDX documentation... '), nonl=True)
        
        if self.generator is None:
            self.init()
            
        if self.generator:  # Type guard to satisfy the linter
            self.generator.generate_all()
        
        logger.info('done') 