"""Generator module for creating Mintlify documentation."""

import os
import inspect
from typing import Dict, Any, List, Union, Optional, Set, Tuple
from pathlib import Path
import re
import typing
from datetime import datetime

from sphinx.application import Sphinx
from sphinx.util import logging
from typing_extensions import NotRequired, Required, get_origin, get_args, ForwardRef

logger = logging.getLogger(__name__)

def get_mdx_path_from_class_name(class_name: str, folder: str = "misc") -> str:
    name = class_name.lower()
    if "[" in name:
        name = name.split("[")[0]
    return f"/sdk-reference/{folder}/{name}"

class ClassMarkdownGenerator:
    """Generates markdown documentation for classes and their methods."""
    
    def __init__(self, app: Sphinx):
        """Initialize the generator.
        
        Args:
            app: The Sphinx application instance
        """
        self.app = app
        self.output_dir = app.config.classmd_output_dir
        self.classes = app.config.classmd_classes
        self.method_options = app.config.classmd_method_options
        self.method_order = app.config.classmd_method_order
        self.templates = app.config.classmd_templates
        self.metadata = app.config.classmd_metadata
        self.encountered_classes: Set[type] = set()  # Track encountered classes
        
    def generate_all(self) -> None:
        """Generate markdown files for all configured classes."""
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
            
        # Create misc directory for referenced classes
        misc_dir = Path(self.output_dir) / 'misc'
        misc_dir.mkdir(parents=True, exist_ok=True)
            
        for class_config in self.classes:
            if isinstance(class_config, str):
                class_path = class_config
                class_name = class_path.split('.')[-1]
            elif isinstance(class_config, dict):
                class_path = class_config['path']
                class_name = class_config.get('name', class_path.split('.')[-1])
            else:
                logger.warning(f"Invalid class config: {class_config}")
                continue
                
            try:
                cls = self._import_class(class_path)
                self._generate_class_docs(cls, class_name)
            except Exception as e:
                logger.error(f"Failed to generate docs for {class_path}: {e}")
                
        # Generate documentation for encountered classes in misc folder
        if self.encountered_classes:
            # Create a copy of encountered_classes to avoid modification during iteration
            classes_to_document = set(self.encountered_classes)
            documented_classes = set()
            
            while classes_to_document:
                # Get the next batch of classes to document
                current_batch = classes_to_document - documented_classes
                if not current_batch:
                    break
                    
                for cls in current_batch:
                    try:
                        class_name = cls.__name__
                        self._generate_misc_class_doc(cls, misc_dir)
                        documented_classes.add(cls)
                    except Exception as e:
                        logger.error(f"Failed to generate docs for encountered class {cls.__name__}: {e}")
                        documented_classes.add(cls)  # Mark as documented even if failed to avoid infinite loops
                
                # Update classes_to_document with any new classes that were discovered
                classes_to_document = self.encountered_classes - documented_classes

    def _import_class(self, class_path: str) -> type:
        """Import a class from its dotted path.
        
        Args:
            class_path: Fully qualified class path (e.g. 'package.module.Class')
            
        Returns:
            The imported class
            
        Raises:
            ImportError: If the class cannot be imported
        """
        try:
            module_path, class_name = class_path.rsplit('.', 1)
            module = __import__(module_path, fromlist=[class_name])
            return getattr(module, class_name)
        except Exception as e:
            raise ImportError(f"Failed to import {class_path}: {e}")
    
    def _generate_class_docs(self, cls: type, class_name: str, base_dir: Optional[Path] = None) -> None:
        """Generate documentation for a single class.
        
        Args:
            cls: The class to document
            class_name: Name to use for the class in documentation
            base_dir: Optional base directory to use instead of output_dir/class_name
        """
        if base_dir is None:
            class_dir = Path(self.output_dir) / class_name.lower()
        else:
            class_dir = base_dir / class_name.lower()
            
        class_dir.mkdir(parents=True, exist_ok=True)
        
        # Generate class overview file
        self._generate_class_overview(cls, class_name, class_dir)
        
        # Get and sort methods according to configuration
        methods = self._get_class_methods(cls)
        sorted_methods = self._sort_methods(methods)
        
        # Generate method files
        for method_name, method in sorted_methods.items():
            self._generate_method_doc(cls, method_name, method, class_dir)
    
    def _generate_class_overview(self, cls: type, class_name: str, class_dir: Path) -> None:
        """Generate an overview file for the class.
        
        Args:
            cls: The class to document
            class_name: Name of the class
            class_dir: Directory to write the overview file to
        """
        filename = "index.mdx"
        filepath = class_dir / filename
        
        methods = self._get_class_methods(cls)
        sorted_methods = self._sort_methods(methods)
        
        content = self._generate_mdx_overview(cls, class_name, sorted_methods)
        
        filepath.write_text(content.rstrip() + '\n', encoding='utf-8')
    
    def _generate_mdx_overview(self, cls: type, class_name: str, methods: Dict[str, Any]) -> str:
        """Generate MDX format overview (Mintlify compatible).
        
        Args:
            cls: The class to document
            class_name: Name of the class
            methods: Dictionary of method names to method objects
            
        Returns:
            MDX formatted content
        """
        class_doc = inspect.getdoc(cls) or "No description available."
        
        content = f"""---
title: "{class_name}"
description: "{class_doc.split('.')[0] if '.' in class_doc else class_doc}"
---

# {class_name}

{class_doc}

## Methods

<CardGroup cols={{2}}>
"""
        
        for method_name, method in methods.items():
            method_doc = inspect.getdoc(method) or "No description available."
            short_desc = method_doc.split('.')[0] if '.' in method_doc else method_doc
            
            content += f"""  <Card
    title="{method_name}"
    icon="function"
    href="{get_mdx_path_from_class_name(method_name, folder=class_name.lower())}"
  >
    {short_desc}
  </Card>
"""
        
        content += """</CardGroup>

## Class Information

<Info>
**Module:** `{}`
**Inheritance:** {}
</Info>
""".format(cls.__module__, ' → '.join([c.__name__ for c in cls.__mro__[:-1]]))
        
        return content
    

    
    def _generate_method_doc(self, cls: type, method_name: str, method: Any, class_dir: Path) -> None:
        """Generate documentation for a single method.
        
        Args:
            cls: The class containing the method
            method_name: Name of the method
            method: The method object
            class_dir: Directory to write the method file to
        """
        filename = f"{method_name}.mdx"
        filepath = class_dir / filename
        
        content = self._generate_mdx_method(cls, method_name, method)
        
        filepath.write_text(content.rstrip() + '\n', encoding='utf-8')
    
    def _generate_mdx_method(self, cls: type, method_name: str, method: Any) -> str:
        """Generate MDX format method documentation.
        
        Args:
            cls: The class containing the method
            method_name: Name of the method
            method: The method object
            
        Returns:
            MDX formatted content
        """
        method_doc = inspect.getdoc(method) or "No description available."
        # signature = self._get_method_signature(method)
        
        # Parse docstring sections
        sections = {}
        current_section = 'description'
        current_content = []
        
        for line in method_doc.split('\n'):
            bkp_line = line
            line = line.strip()
            if line.lower().startswith('args:'):
                current_section = 'args'
                current_content = []
            elif line.lower().startswith('returns:'):
                current_section = 'returns'
                current_content = []
            elif line.lower().startswith('raises:'):
                current_section = 'raises'
                current_content = []
            else:
                current_content.append(bkp_line)
            
            if current_content:
                sections[current_section] = current_content
        
        # Extract first sentence for description
        description = sections.get('description', ['No description available.'])[0]
        if '.' in description:
            description = description.split('.')[0]
            
        # Get full docstring content and remove first sentence
        full_doc = '\n'.join(sections.get('description', ['']))
        remaining_doc = full_doc[len(description):].strip(' .')
        
        content = f"""---
title: "{method_name}"
description: "{description}"
---

{remaining_doc if remaining_doc else ''}


"""
        
        # Add parameter information if available
        try:
            sig = inspect.signature(method)
            if len(sig.parameters) > 1:  # More than just 'self'
                content += "## Parameters\n\n"
                args_content = sections.get('args', [])
                args_dict = {}
                
                # Parse args section
                current_arg = None
                current_desc = []
                for line in args_content:
                    if ':' in line and not line.strip().endswith(':'):
                        if current_arg and current_desc:
                            desc_text = ' '.join(current_desc).strip()
                            if desc_text:
                                args_dict[current_arg] = desc_text
                        current_arg = line.split(':')[0].strip()
                        current_desc = [line.split(':', 1)[1].strip()]
                    else:
                        if current_arg:
                            current_desc.append(line)
                if current_arg and current_desc:
                    desc_text = ' '.join(current_desc).strip()
                    if desc_text:
                        args_dict[current_arg] = desc_text
                
                for param_name, param in sig.parameters.items():
                    if param_name == 'self':
                        continue
                    
                    if param_name.startswith('_'):
                        continue
                    
                    param_type = param.annotation if param.annotation != inspect.Parameter.empty else "Any"
                    
                    # Try to get actual type hints which might resolve forward references
                    try:
                        from typing import get_type_hints
                        actual_hints = get_type_hints(method)
                        if param_name in actual_hints:
                            param_type = actual_hints[param_name]
                    except Exception:
                        # Fall back to annotation if get_type_hints fails
                        pass

                    # Handle Unpack[TypedDict] case
                    is_unpack = False
                    typeddict_cls = None
                    
                    # Check for Unpack in different formats
                    param_type_str = str(param_type)
                    
                    # First try to get the module where the method is defined
                    module = inspect.getmodule(method)
                    imported_names = {}
                    if module:
                        # Get all imported names in the module
                        for name, value in module.__dict__.items():
                            if inspect.isclass(value) or hasattr(value, '__annotations__'):
                                imported_names[name] = value
                                
                    # Try to extract TypedDict name from various formats
                    typeddict_name = None
                    class_path = None
                    
                    if not isinstance(param_type, str):
                        if hasattr(param_type, '__origin__') and str(param_type.__origin__) == 'Unpack':
                            if hasattr(param_type, '__args__') and param_type.__args__:
                                typeddict_cls = param_type.__args__[0]
                                is_unpack = True
                                
                    if not typeddict_cls:
                        if 'Unpack[' in param_type_str:
                            # Extract name from Unpack[...]
                            typeddict_name = param_type_str.split('Unpack[')[-1].rstrip(']')
                            # Clean up any typing. prefix
                            typeddict_name = typeddict_name.replace('typing.', '')
                            is_unpack = True
                        elif param_type_str.startswith('*<class '):
                            # Handle *<class 'module.TypeDict'> format
                            class_path = param_type_str.split("'")[1]
                            typeddict_name = class_path.split('.')[-1]
                            is_unpack = True
                        
                    # Try to find the TypedDict class
                    if typeddict_name and not typeddict_cls:
                        # First try direct module attribute
                        if typeddict_name in imported_names:
                            typeddict_cls = imported_names[typeddict_name]
                        # Then try to import it from the full path if available
                        elif class_path and '.' in class_path:
                            try:
                                module_path, class_name = class_path.rsplit('.', 1)
                                imported_module = __import__(module_path, fromlist=[class_name])
                                typeddict_cls = getattr(imported_module, class_name)
                            except Exception:
                                pass
                    
                    if is_unpack and typeddict_cls and hasattr(typeddict_cls, '__annotations__'):
                        # Get TypedDict docstring for field descriptions, including from parent classes
                        field_descriptions = {}
                        
                        def get_typeddict_docstring(cls):
                            """Get the docstring for a TypedDict class, including its Args section."""
                            doc = inspect.getdoc(cls) or ""
                            if not doc:
                                return {}
                            
                            descriptions = {}
                            lines = doc.split('\n')
                            in_args_section = False
                            current_field = None
                            current_desc = []
                            
                            for line in lines:
                                line = line.strip()
                                
                                # Check for Args section
                                if line.lower() == 'args:' or (line.lower().startswith('args:') and len(line) == 5):
                                    in_args_section = True
                                    continue
                                
                                if not line and in_args_section and current_field:
                                    # Empty line in args section - save current field if we have content
                                    if current_desc:
                                        desc = ' '.join(current_desc).strip()
                                        descriptions[current_field] = desc
                                    current_field = None
                                    current_desc = []
                                    continue
                                
                                if in_args_section and line:
                                    # Check if this line starts a new field
                                    if ':' in line and not line.endswith(':'):
                                        # Save previous field if we have one
                                        if current_field and current_desc:
                                            desc = ' '.join(current_desc).strip()
                                            descriptions[current_field] = desc
                                        
                                        # Start new field
                                        parts = line.split(':', 1)
                                        current_field = parts[0].strip()
                                        current_desc = [parts[1].strip()]
                                    elif current_field and line:
                                        # This is a continuation of the current field description
                                        current_desc.append(line)
                                elif in_args_section and not line:
                                    # Empty line - if we're not in the middle of a field, end args section
                                    if not current_field:
                                        in_args_section = False
                            
                            # Save last field if we have one
                            if current_field and current_desc:
                                desc = ' '.join(current_desc).strip()
                                descriptions[current_field] = desc
                            
                            return descriptions
                        
                        # Get all TypedDict classes in MRO order (including the class itself)
                        typeddict_classes = []
                        
                        # First try to get the original bases if available (typing_extensions case)
                        if hasattr(typeddict_cls, '__orig_bases__'):
                            bases = typeddict_cls.__orig_bases__
                            # Add the class itself first (most specific)
                            typeddict_classes.append(typeddict_cls)
                            # Then add all TypedDict bases
                            for base in bases:
                                if hasattr(base, '__annotations__'):
                                    typeddict_classes.append(base)
                        else:
                            # Fallback to MRO for typing.TypedDict case
                            for cls in typeddict_cls.__mro__:
                                if (hasattr(cls, '__annotations__') and 
                                    hasattr(cls, '__total__')):
                                    typeddict_classes.append(cls)
                        
                        # Collect all annotations and descriptions
                        all_annotations = {}
                        all_descriptions = {}
                        # Get the total value for the most-derived TypedDict class
                        total = getattr(typeddict_cls, '__total__', True)
                        # Process classes in MRO order (most specific to least specific)
                        for cls in typeddict_classes:
                            # Get annotations
                            if hasattr(cls, '__annotations__'):
                                all_annotations.update(cls.__annotations__)
                            # Get docstring descriptions and update only non-empty ones
                            docstring = get_typeddict_docstring(cls)
                            if docstring:
                                for field_name, description in docstring.items():
                                    # Only update if description is not empty AND there isn't already a description
                                    if description:
                                        all_descriptions[field_name] = description
                        # Separate required and optional fields
                        required_fields = []
                        optional_fields = []
                        def _get_type_name(field_type):
                            # Unwrap ForwardRef
                            if isinstance(field_type, ForwardRef):
                                return field_type.__forward_arg__
                            # Unwrap NotRequired/Required recursively
                            origin = get_origin(field_type)
                            if origin in (NotRequired, Required):
                                inner = get_args(field_type)[0]
                                return _get_type_name(inner)
                            # If it's a class, return its name
                            if isinstance(field_type, type):
                                return field_type.__name__
                            # If it looks like <class 'str'>, extract the name
                            s = str(field_type)
                            if s.startswith("<class '"):
                                return s.split("'")[1].split('.')[-1]
                            return s
                        for field_name, field_type in all_annotations.items():
                            origin = get_origin(field_type)
                            if origin is NotRequired:
                                is_required = False
                                inner_type = get_args(field_type)[0]
                            elif origin is Required:
                                is_required = True
                                inner_type = get_args(field_type)[0]
                            else:
                                is_required = total  # Use total for default requiredness
                                inner_type = field_type
                            type_str = _get_type_name(inner_type)
                            field_info = {
                                'name': field_name,
                                'type': type_str,
                                'description': all_descriptions.get(field_name, ""),
                                'is_required': is_required
                            }
                            if is_required:
                                required_fields.append(field_info)
                            else:
                                optional_fields.append(field_info)
                        # Add parameters section header only if we haven't already
                        if '## Parameters' not in content:
                            content += "## Parameters\n\n"
                        # Add required fields first
                        for field in required_fields:
                            if inspect.isclass(field['type']):
                                self._track_class(field['type'])
                            # skip names that start with _
                            if field['name'].startswith('_'):
                                continue
                            required_str = " required" if field['is_required'] else ""
                            # Use ParamField-specific formatting (no backticks)
                            type_str = self._format_type_for_param_field(field['type'], inspect.getmodule(cls))
                            
                            # Handle default value attribute (required fields shouldn't have defaults)
                            default_attr = ""
                            
                            content += f"<ParamField path=\"{field['name']}\" type=\"{type_str}\"{required_str}{default_attr}>\n"
                            if field['description'] and field['description'].strip():
                                content += f"  {field['description']}\n"
                            content += "</ParamField>\n\n"
                        # Add optional fields
                        for field in optional_fields:
                            if inspect.isclass(field['type']):
                                self._track_class(field['type'])
                            if field['name'].startswith('_'):
                                continue
                            required_str = ""  # Optional fields should not have required attribute
                            # Use ParamField-specific formatting (no backticks)
                            type_str = self._format_type_for_param_field(field['type'], inspect.getmodule(cls))
                            
                            # Handle default value attribute for optional fields
                            default_attr = ""
                            if 'default' in field and field['default'] is not None:
                                try:
                                    # Handle different types of default values
                                    default_value = field['default']
                                    if isinstance(default_value, str):
                                        # Escape quotes for HTML attribute
                                        escaped_default = default_value.replace('"', '&quot;').replace("'", "&#x27;")
                                        default_attr = f' default="{escaped_default}"'
                                    elif isinstance(default_value, (int, float, bool)):
                                        default_attr = f' default="{default_value}"'
                                    elif hasattr(default_value, '__name__'):  # Function or class
                                        default_attr = f' default="{default_value.__name__}"'
                                    else:
                                        # Convert to string and escape
                                        str_default = str(default_value).replace('"', '&quot;').replace("'", "&#x27;")
                                        default_attr = f' default="{str_default}"'
                                except Exception:
                                    # Fallback to string representation with escaping
                                    try:
                                        str_default = str(field['default']).replace('"', '&quot;').replace("'", "&#x27;")
                                        default_attr = f' default="{str_default}"'
                                    except Exception:
                                        default_attr = ""
                            
                            content += f"<ParamField path=\"{field['name']}\" type=\"{type_str}\"{required_str}{default_attr}>\n"
                            if field['description'] and field['description'].strip():
                                content += f"  {field['description']}\n"
                            content += "</ParamField>\n\n"
                                
                        continue  # Skip adding the original parameter
                    
                    # If not an Unpack or couldn't resolve TypedDict, handle as normal parameter
                    # Use the new comprehensive type formatting for ParamFields (no backticks)
                    type_str = self._format_type_for_param_field(param_type, module)
                    
                    # Determine if parameter is required and handle default values
                    is_required = param.default == inspect.Parameter.empty
                    required_str = " required" if is_required else ""
                    
                    # Format default value for ParamField attribute
                    default_attr = ""
                    if not is_required and param.default != inspect.Parameter.empty:
                        try:
                            # Handle different types of default values
                            if isinstance(param.default, str):
                                # Escape quotes for HTML attribute
                                escaped_default = param.default.replace('"', '&quot;').replace("'", "&#x27;")
                                default_attr = f' default="{escaped_default}"'
                            elif isinstance(param.default, (int, float, bool)):
                                default_attr = f' default="{param.default}"'
                            elif hasattr(param.default, '__name__'):  # Function or class
                                default_attr = f' default="{param.default.__name__}"'
                            else:
                                # Convert to string and escape
                                str_default = str(param.default).replace('"', '&quot;').replace("'", "&#x27;")
                                default_attr = f' default="{str_default}"'
                        except Exception:
                            # Fallback to string representation with escaping
                            try:
                                str_default = str(param.default).replace('"', '&quot;').replace("'", "&#x27;")
                                default_attr = f' default="{str_default}"'
                            except Exception:
                                default_attr = ""
                    
                    description = args_dict.get(param_name, "")
                    
                    content += f"<ParamField path=\"{param_name}\" type=\"{type_str}\"{required_str}{default_attr}>\n"
                    if description and description.strip():
                        content += f"  {description}\n"
                    content += "</ParamField>\n\n"
        except Exception:
            pass
        
        # Add return information if available
        try:
            sig = inspect.signature(method)
            if sig.return_annotation != inspect.Signature.empty:
                content += "## Returns\n\n"
                returns_content = ' '.join(sections.get('returns', ['']))
                if ':' in returns_content:
                    returns_content = returns_content.split(':', 1)[1].strip()
                
                return_type = sig.return_annotation
                return_type_str = str(return_type)
                
                # Get imported names from the module
                module = inspect.getmodule(method)
                imported_names = {}
                if module:
                    for name, value in module.__dict__.items():
                        if inspect.isclass(value) or hasattr(value, '__annotations__'):
                            imported_names[name] = value
                
                # Use the new comprehensive type formatting
                type_str = self._format_type_with_links(return_type, module)
                content += type_str
                
                if returns_content:
                    content += f": {returns_content.rstrip()}"
                content += "\n\n"
        except Exception:
            pass
        
        # Add raises information if available
        if 'raises' in sections:
            content += "## Raises\n\n"
            for line in sections['raises']:
                if ':' in line:
                    error_type, error_desc = line.split(':', 1)
                    error_type = error_type.strip()
                    try:
                        error_class = eval(error_type)
                        if inspect.isclass(error_class) and issubclass(error_class, Exception):
                            self._track_class(error_class)  # Track exception classes
                    except:
                        pass
                    content += f"- `{error_type}`: {error_desc.strip()}\n"
        
        return content
    

    
    def _get_method_signature(self, method: Any) -> str:
        """Get the method signature as a string.
        
        Args:
            method: The method object
            
        Returns:
            String representation of the method signature
        """
        try:
            return f"def {method.__name__}{inspect.signature(method)}"
        except Exception:
            return f"def {method.__name__}(...)"
    
    def _get_class_methods(self, cls: type) -> Dict[str, Any]:
        """Get all methods of a class.
        
        Args:
            cls: The class to get methods from
            
        Returns:
            Dictionary mapping method names to method objects
        """
        methods = {}
        
        # Get bound methods
        for name, method in inspect.getmembers(cls, inspect.ismethod):
            if not name.startswith('_') or name in ('__init__', '__call__'):
                methods[name] = method
        
        # Get unbound methods (functions)
        for name, method in inspect.getmembers(cls, inspect.isfunction):
            if not name.startswith('_') or name in ('__init__', '__call__'):
                methods[name] = method
                
        return methods
    
    def _sort_methods(self, methods: Dict[str, Any]) -> Dict[str, Any]:
        """Sort methods according to configuration.
        
        Args:
            methods: Dictionary of method names to method objects
            
        Returns:
            Sorted dictionary of methods
        """
        if not self.method_order:
            return dict(sorted(methods.items()))
        
        sorted_methods = {}
        remaining_methods = methods.copy()
        
        # First add methods in the specified order
        for category in self.method_order:
            if category == '__init__' and '__init__' in remaining_methods:
                sorted_methods['__init__'] = remaining_methods.pop('__init__')
            elif category == 'public_methods':
                public = {k: v for k, v in remaining_methods.items() 
                         if not k.startswith('_')}
                sorted_methods.update(sorted(public.items()))
                remaining_methods = {k: v for k, v in remaining_methods.items() 
                                  if k.startswith('_')}
            elif category == 'private_methods':
                private = {k: v for k, v in remaining_methods.items() 
                         if k.startswith('_') and not k.startswith('__')}
                sorted_methods.update(sorted(private.items()))
                remaining_methods = {k: v for k, v in remaining_methods.items() 
                                  if not k.startswith('_') or k.startswith('__')}
            elif category == 'static_methods':
                static = {k: v for k, v in remaining_methods.items() 
                         if isinstance(v, staticmethod)}
                sorted_methods.update(sorted(static.items()))
                remaining_methods = {k: v for k, v in remaining_methods.items() 
                                  if not isinstance(v, staticmethod)}
            elif category == 'class_methods':
                class_methods = {k: v for k, v in remaining_methods.items() 
                               if isinstance(v, classmethod)}
                sorted_methods.update(sorted(class_methods.items()))
                remaining_methods = {k: v for k, v in remaining_methods.items() 
                                  if not isinstance(v, classmethod)}
        
        # Add any remaining methods
        sorted_methods.update(sorted(remaining_methods.items()))
        
        return sorted_methods 
    
    def _track_class(self, cls: 'type | str') -> None:
        """Track an encountered class for later documentation.
        
        Args:
            cls: The class to track (can be a type or a string)
        """
        import re
        import types
        # If it's a string (e.g., from a forward reference or failed import), try to import it
        if isinstance(cls, str):
            class_name = re.sub(r"[^a-zA-Z0-9_]", "", cls)
            # Try to import from known modules or leave as stub
            try:
                # Try to import from globals or builtins
                imported = globals().get(class_name) or getattr(__import__('builtins'), class_name, None)
                if imported and inspect.isclass(imported):
                    cls = imported
                else:
                    # Generate stub doc for missing class
                    self._generate_misc_class_stub(class_name)
                    return
            except Exception:
                self._generate_misc_class_stub(class_name)
                return
        # Only track actual classes, not built-in types or primitives
        if (inspect.isclass(cls) and 
            not cls.__module__.startswith('builtins') and
            cls not in self.encountered_classes and
            cls.__name__ not in [c.__name__ for c in self.encountered_classes]):
            self.encountered_classes.add(cls)
            # Generate documentation for the class immediately
            misc_dir = Path(self.output_dir) / 'misc'
            misc_dir.mkdir(parents=True, exist_ok=True)
            self._generate_misc_class_doc(cls, misc_dir)

    def _generate_misc_class_stub(self, class_name: str) -> None:
        """Generate a stub documentation file for a class name that could not be imported."""
        misc_dir = Path(self.output_dir) / 'misc'
        misc_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{class_name.lower()}.mdx"
        filepath = misc_dir / filename
        content = f"""---\ntitle: \"{class_name}\"\ndescription: \"No documentation available.\"\n---\n\n*This is a placeholder for `{class_name}`. The class could not be imported or was only referenced as a type hint.*\n\n"""
        filepath.write_text(content.rstrip() + '\n', encoding='utf-8')

    def _generate_misc_class_doc(self, cls: type, misc_dir: Path) -> None:
        """Generate a simple documentation file for an encountered class.
        
        Args:
            cls: The class to document
            misc_dir: Directory to write the file to
        """
        # Extract the base class name for the filename
        if isinstance(cls, str):
            base_name = cls.split('[')[0] if '[' in cls else cls
        else:
            base_name = cls.__name__.split('[')[0] if '[' in cls.__name__ else cls.__name__
        filename = f"{base_name.lower()}.mdx"
        filepath = misc_dir / filename
        
        # Get class documentation and clean it up
        class_doc = inspect.getdoc(cls) or "No description available."
        # Remove the abstract section if present
        if "!!! abstract" in class_doc:
            class_doc = class_doc.split("!!! abstract")[0].strip()
        
        # Parse docstring sections
        sections = {}
        current_section = 'description'
        current_content: list[str] = []
        
        for line in class_doc.split('\n'):
            bkp_line = line
            line = line.strip()
            if line.lower().startswith('args:'):
                current_section = 'args'
                current_content = []
            elif line.lower().startswith('returns:'):
                current_section = 'returns'
                current_content = []
            elif line.lower().startswith('raises:'):
                current_section = 'raises'
                current_content = []
            else:
                current_content.append(bkp_line)
            
            if current_content:
                sections[current_section] = current_content
        
        # Extract first sentence for description
        description_content = sections.get('description', ['No description available.'])
        description = description_content[0] if description_content else "No description available."
        if '.' in description:
            description = description.split('.')[0]
        
        # Get full description content and remove first sentence
        full_desc = '\n'.join(description_content)
        remaining_desc = full_desc[len(description):].strip(' .')
        
        content = f"""---
title: "{base_name}"
description: "{description}"
---

{remaining_desc if remaining_desc else ''}

"""
        
        # Add parameters section if Args is available
        args_content = sections.get('args', [])
        if args_content:
            content += "## Parameters\n\n"
            args_dict = {}
            
            # Parse args section
            current_arg = None
            current_desc = []
            for line in args_content:
                if ':' in line and not line.strip().endswith(':'):
                    if current_arg and current_desc:
                        desc_text = ' '.join(current_desc).strip()
                        if desc_text:
                            args_dict[current_arg] = desc_text
                    current_arg = line.split(':')[0].strip()
                    current_desc = [line.split(':', 1)[1].strip()]
                else:
                    if current_arg:
                        current_desc.append(line)
            if current_arg and current_desc:
                desc_text = ' '.join(current_desc).strip()
                if desc_text:
                    args_dict[current_arg] = desc_text
            
            # Add parameters using ParamField format
            for param_name, param_desc in args_dict.items():
                if param_name.startswith('_'):
                    continue
                content += f"<ParamField path=\"{param_name}\" type=\"Any\">\n"
                if param_desc and param_desc.strip():
                    content += f"  {param_desc}\n"
                content += "</ParamField>\n\n"
        
        # Add returns section if available
        returns_content = sections.get('returns', [])
        if returns_content:
            content += "## Returns\n\n"
            returns_text = ' '.join(returns_content)
            if ':' in returns_text:
                returns_text = returns_text.split(':', 1)[1].strip()
            content += f"{returns_text.rstrip()}\n\n"
        
        # Add raises section if available
        raises_content = sections.get('raises', [])
        if raises_content:
            content += "## Raises\n\n"
            for line in raises_content:
                if ':' in line:
                    error_type, error_desc = line.split(':', 1)
                    error_type = error_type.strip()
                    try:
                        error_class = eval(error_type)
                        if inspect.isclass(error_class) and issubclass(error_class, Exception):
                            self._track_class(error_class)  # Track exception classes
                    except:
                        pass
                    content += f"- `{error_type}`: {error_desc.strip()}\n"
            content += "\n"
        
        # Special handling for Pydantic BaseModel
        if inspect.isclass(cls) and hasattr(cls, '__fields__') and not isinstance(cls, str):  # Pydantic model detection
            content += "## Fields\n\n"
            try:
                for field_name, field in cls.__fields__.items():
                    # Skip double underscore fields
                    if field_name.startswith('__'):
                        continue
                    # Get field type
                    field_type = field.annotation
                    if str(field_type).startswith('typing.'):
                        field_type = str(field_type).replace('typing.', '')
                    
                    # Get default value and description based on Pydantic version
                    try:
                        default = field.default
                        description = field.description if hasattr(field, 'description') else ""
                    except AttributeError:
                        try:
                            default = field.default
                            description = field.field_info.description if hasattr(field.field_info, 'description') else ""
                        except AttributeError:
                            default = getattr(field, 'default', None)
                            description = ""

                    # Try to resolve the type if it's a string
                    if isinstance(field_type, str):
                        try:
                            field_type = self._resolve_string_annotation(field_type, cls)
                        except Exception as e:
                            logger.error(f"Error resolving string type: {e}")

                    # Use the new comprehensive type formatting for ParamFields (no backticks)
                    type_str = self._format_type_for_param_field(field_type, inspect.getmodule(cls))

                    # Add required attribute if field is required
                    # In Pydantic, a field is required if it has no default value
                    required_str = ""
                    # Check if field is required by looking at default value
                    # Field is required if default is a special Pydantic sentinel value
                    is_required = False
                    try:
                        # Try to import Pydantic's PydanticUndefined if available
                        from pydantic.fields import PydanticUndefined
                        is_required = default is PydanticUndefined
                    except ImportError:
                        try:
                            # Fallback for different Pydantic versions
                            from pydantic import PydanticUndefined
                            is_required = default is PydanticUndefined
                        except ImportError:
                            # Final fallback - check for common sentinel values and patterns
                            # PydanticUndefined is typically represented as a special object
                            default_str = str(default)
                            is_required = (
                                default is ... or  # Ellipsis
                                'PydanticUndefined' in default_str or
                                'Undefined' in default_str or
                                default_str == 'Ellipsis'
                            )
                    
                    if is_required:
                        required_str = " required"
                    
                    # Format default value for ParamField attribute
                    default_attr = ""
                    if not is_required and default is not None:
                        # Format the default value for the default attribute
                        try:
                            # Handle different types of default values
                            if isinstance(default, str):
                                # Escape quotes for HTML attribute
                                escaped_default = default.replace('"', '&quot;').replace("'", "&#x27;")
                                default_attr = f' default="{escaped_default}"'
                            elif isinstance(default, (int, float, bool)):
                                default_attr = f' default="{default}"'
                            elif hasattr(default, '__name__'):  # Function or class
                                default_attr = f' default="{default.__name__}"'
                            else:
                                # Convert to string and escape
                                str_default = str(default).replace('"', '&quot;').replace("'", "&#x27;")
                                default_attr = f' default="{str_default}"'
                        except Exception:
                            # Fallback to string representation with escaping
                            try:
                                str_default = str(default).replace('"', '&quot;').replace("'", "&#x27;")
                                default_attr = f' default="{str_default}"'
                            except Exception:
                                default_attr = ""
                    
                    # Format using ParamField with proper default attribute
                    content += f"<ParamField path=\"{field_name}\" type=\"{type_str}\"{required_str}{default_attr}>\n"
                    if description:
                        content += f"  {description}\n"
                    content += "</ParamField>\n\n"
            except Exception as e:
                logger.error(f"Error generating fields for {base_name}: {e}")
        else:
            # For regular classes, show method summary
            methods = self._get_class_methods(cls)
            if methods:
                content += "## Methods\n\n"
                for name, method in methods.items():
                    # Skip double underscore methods
                    if name.startswith('__'):
                        continue
                    method_doc = inspect.getdoc(method) or ""
                    summary = method_doc.split('.')[0] if method_doc and '.' in method_doc else method_doc
                    # Get method signature and return type
                    try:
                        sig = inspect.signature(method)
                        return_type = sig.return_annotation if sig.return_annotation != inspect.Signature.empty else None
                        # Format parameters
                        params = []
                        for param_name, param in sig.parameters.items():
                            if param_name == 'self':
                                continue
                            param_str = param_name
                            if param.annotation != inspect.Parameter.empty:
                                param_str += f": {param.annotation}"
                            if param.default != inspect.Parameter.empty:
                                param_str += f" = {param.default}"
                            params.append(param_str)
                        # Add method signature with parameters
                        content += f"### {name}\n\n"
                        content += f"```python\n{name}({', '.join(params)})"
                        if return_type:
                            content += f" -> {return_type}"
                        content += "\n```\n\n"
                        if summary:
                            content += f"{summary}\n\n"
                        # Parse docstring sections
                        sections = {}
                        current_section = 'description'
                        current_content = []
                        for line in method_doc.split('\n'):
                            line = line.strip()
                            if line.lower().startswith('args:'):
                                current_section = 'args'
                                current_content = []
                            elif line.lower().startswith('returns:'):
                                current_section = 'returns'
                                current_content = []
                            elif line.lower().startswith('raises:'):
                                current_section = 'raises'
                                current_content = []
                            elif line:
                                current_content.append(line)
                            if current_content:
                                sections[current_section] = current_content
                        # Add parameters section if we have args documentation
                        if 'args' in sections:
                            content += "**Parameters:**\n\n"
                            for line in sections['args']:
                                if ':' in line:
                                    param, desc = line.split(':', 1)
                                    content += f"- `{param.strip()}`: {desc.strip()}\n"
                            content += "\n"
                        # Add return type information
                        if return_type and str(return_type) != 'None':
                            content += "**Returns:**\n\n"
                            if 'returns' in sections:
                                returns_content = ' '.join(sections['returns'])
                                if ':' in returns_content:
                                    returns_content = returns_content.split(':', 1)[1].strip()
                                content += f"{returns_content}\n\n"
                            else:
                                # If no returns documentation but we have a return type
                                type_str = self._format_type_with_links(return_type, inspect.getmodule(cls))
                                content += f"{type_str}\n\n"
                        # Add raises section if present
                        if 'raises' in sections:
                            content += "**Raises:**\n\n"
                            for line in sections['raises']:
                                if ':' in line:
                                    error_type, error_desc = line.split(':', 1)
                                    error_type = error_type.strip()
                                    try:
                                        error_class = eval(error_type)
                                        if inspect.isclass(error_class) and issubclass(error_class, Exception):
                                            self._track_class(error_class)
                                    except:
                                        pass
                                    content += f"- `{error_type}`: {error_desc.strip()}\n"
                            content += "\n"
                        
                        # Add separator between methods (except for the last one)
                        content += "---\n\n"
                    except Exception as e:
                        # Fallback to simple method documentation if signature parsing fails
                        if summary:
                            content += f"- `{name}()` - {summary}\n"
                        else:
                            content += f"- `{name}()`\n"
                content += "\n"
            # Show inheritance if relevant
            if cls.__bases__ and cls.__bases__ != (object,):
                bases = [base.__name__ for base in cls.__bases__ if base != object]
                if bases:
                    content += "## Inheritance\n\n"
                    content += f"Inherits from: {', '.join(bases)}\n\n"
        # Add module information
        content += f"\n## Module\n\n`{cls.__module__}`\n"
        filepath.write_text(content.rstrip() + '\n', encoding='utf-8')

    def _resolve_string_annotation(self, annotation_str: str, cls: type):
        """Resolve a string type annotation to an actual type object.

        Handles complex annotations like Literal['a', 'b'], Union[X, Y],
        Optional[X], Callable[[bytes], Any], etc. by evaluating them in the
        namespace of the module where the class is defined.

        Args:
            annotation_str: The string representation of the type annotation
            cls: The class that owns this annotation (used for module context)

        Returns:
            The resolved type object, or the original string if resolution fails
        """
        import sys

        # Build a namespace with typing constructs + the module's own globals
        namespace: dict[str, Any] = {}
        namespace.update(vars(typing))

        # Add typing_extensions exports (Literal may come from there on older Python)
        try:
            import typing_extensions
            namespace.update(vars(typing_extensions))
        except ImportError:
            pass

        # Add the module's globals for resolving custom types
        module = inspect.getmodule(cls)
        if module:
            namespace.update(vars(module))

        # Add common builtins and NoneType
        import builtins
        namespace.update(vars(builtins))
        namespace['NoneType'] = type(None)

        # Resolve fully-qualified names (e.g. pydantic.main.BaseModel) by importing
        # the referenced objects and adding them to the namespace under a mangled key.
        # We replace dotted names in the annotation string with the mangled key so eval works.
        resolved_str = annotation_str
        # Find all dotted names like "pydantic.main.BaseModel"
        dotted_names = re.findall(r'[a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*)+', annotation_str)
        for dotted_name in dotted_names:
            parts = dotted_name.split('.')
            obj = None
            # Try progressively longer module paths (check sys.modules first, then import)
            for i in range(len(parts) - 1, 0, -1):
                mod_path = '.'.join(parts[:i])
                attr_path = parts[i:]
                # Try to get the module from sys.modules or import it
                mod = sys.modules.get(mod_path)
                if mod is None:
                    try:
                        mod = __import__(mod_path, fromlist=[attr_path[0]])
                    except (ImportError, ModuleNotFoundError):
                        continue
                try:
                    obj = mod
                    for attr in attr_path:
                        obj = getattr(obj, attr)
                    break
                except AttributeError:
                    obj = None
                    continue
            if obj is not None:
                mangled = dotted_name.replace('.', '_')
                namespace[mangled] = obj
                resolved_str = resolved_str.replace(dotted_name, mangled)

        try:
            resolved = eval(resolved_str, namespace)  # noqa: S307
            return resolved
        except Exception:
            # If eval fails, fall back to simple attribute lookups
            if module:
                try:
                    return getattr(module, annotation_str)
                except AttributeError:
                    pass
            try:
                return getattr(typing, annotation_str)
            except AttributeError:
                pass
            logger.warning(f"Could not resolve string type: {annotation_str}")
            return annotation_str

    def _resolve_type(self, type_or_str, module=None):
        """Try to resolve a type or string to an actual class object, using the module context if available."""
        import re
        import sys
        import builtins
        if inspect.isclass(type_or_str):
            return type_or_str
        if isinstance(type_or_str, str):
            # Handle generic types like AgentStatusResponse[AgentStepResponse]
            if '[' in type_or_str and ']' in type_or_str:
                base_name = type_or_str[:type_or_str.find('[')]
                inner_name = type_or_str[type_or_str.find('[')+1:type_or_str.find(']')]
                base_class = self._resolve_type(base_name, module)
                inner_class = self._resolve_type(inner_name, module)
                if inspect.isclass(base_class) and inspect.isclass(inner_class):
                    self._track_class(inner_class)
                    return base_class
                return base_name
            class_name = re.sub(r"[^a-zA-Z0-9_]", "", type_or_str)
            # Try module context first
            if module and hasattr(module, class_name):
                value = getattr(module, class_name)
                if inspect.isclass(value):
                    return value
            # Try builtins
            if hasattr(builtins, class_name):
                value = getattr(builtins, class_name)
                if inspect.isclass(value):
                    return value
            # Try globals
            if class_name in globals():
                value = globals()[class_name]
                if inspect.isclass(value):
                    return value
            # Try sys.modules
            for mod in sys.modules.values():
                if hasattr(mod, class_name):
                    value = getattr(mod, class_name)
                    if inspect.isclass(value):
                        return value
            # Could not resolve
            return class_name
        return type_or_str 

    def _format_type_with_links(self, type_annotation, module=None) -> str:
        """Format a type annotation with proper links for class types.
        
        Args:
            type_annotation: The type annotation to format
            module: Optional module context for type resolution
            
        Returns:
            Formatted type string with links where appropriate
        """
        if type_annotation is None or type_annotation == type(None):
            return "`None`"
            
        # Handle string annotations (forward references)
        if isinstance(type_annotation, str):
            # Try to resolve the string to a class
            resolved = self._resolve_type(type_annotation, module)
            if inspect.isclass(resolved):
                if self._should_link_class(resolved):
                    self._track_class(resolved)
                    return f"[`{resolved.__name__}`]({get_mdx_path_from_class_name(resolved.__name__)})"
                else:
                    return f"`{resolved.__name__}`"
            else:
                return f"`{type_annotation}`"
        
        # Handle ForwardRef
        if isinstance(type_annotation, ForwardRef):
            forward_arg = type_annotation.__forward_arg__
            resolved = self._resolve_type(forward_arg, module)
            if inspect.isclass(resolved):
                if self._should_link_class(resolved):
                    self._track_class(resolved)
                    return f"[`{resolved.__name__}`]({get_mdx_path_from_class_name(resolved.__name__)})"
                else:
                    return f"`{resolved.__name__}`"
            else:
                return f"`{forward_arg}`"
        
        # Handle direct class types
        if inspect.isclass(type_annotation):
            if self._should_link_class(type_annotation):
                self._track_class(type_annotation)
                return f"[`{type_annotation.__name__}`]({get_mdx_path_from_class_name(type_annotation.__name__)})"
            else:
                return f"`{type_annotation.__name__}`"
        
        # Handle generic types using get_origin and get_args
        origin = get_origin(type_annotation)
        args = get_args(type_annotation)
        
        if origin is not None:
            # Handle Union types (including Optional)
            if origin is Union:
                formatted_args = []
                for arg in args:
                    formatted_args.append(self._format_type_with_links(arg, module))
                return ' | '.join(formatted_args)
            
            # Handle List, Set, Tuple, etc.
            elif origin in (list, List, set, typing.Set, tuple, Tuple):
                origin_name = origin.__name__ if hasattr(origin, '__name__') else str(origin).split('.')[-1]
                if args:
                    formatted_args = []
                    for arg in args:
                        formatted_args.append(self._format_type_with_links(arg, module))
                    return f"`{origin_name}`[{', '.join(formatted_args)}]"
                else:
                    return f"`{origin_name}`"
            
            # Handle Dict
            elif origin in (dict, Dict):
                if args:
                    key_type = self._format_type_with_links(args[0], module)
                    value_type = self._format_type_with_links(args[1], module) if len(args) > 1 else "`Any`"
                    return f"`Dict`[{key_type}, {value_type}]"
                else:
                    return "`Dict`"
            
            # Handle Literal types — preserve quoted string values
            elif origin is typing.Literal:
                if args:
                    formatted_args = []
                    for arg in args:
                        if isinstance(arg, str):
                            formatted_args.append(f"'{arg}'")
                        else:
                            formatted_args.append(str(arg))
                    return f"`Literal`[{', '.join(formatted_args)}]"
                else:
                    return "`Literal`"

            # Handle other generic types
            else:
                origin_name = getattr(origin, '__name__', str(origin))
                if args:
                    formatted_args = []
                    for arg in args:
                        formatted_args.append(self._format_type_with_links(arg, module))
                    return f"`{origin_name}`[{', '.join(formatted_args)}]"
                else:
                    return f"`{origin_name}`"

        # Handle string representations of complex types
        type_str = str(type_annotation)

        # Handle typing.Optional, typing.List, etc.
        if type_str.startswith('typing.'):
            # Use get_origin and get_args if available
            try:
                origin = get_origin(type_annotation)
                args = get_args(type_annotation)
                if origin and args:
                    return self._format_type_with_links(type_annotation, module)
            except:
                pass
            
            # Fallback parsing for typing strings
            if '[' in type_str and ']' in type_str:
                typing_name = type_str[7:type_str.find('[')]  # Remove 'typing.'
                inner_content = type_str[type_str.find('[')+1:type_str.rfind(']')]
                
                # Handle nested generics
                formatted_inner = self._parse_and_format_inner_types(inner_content, module)
                return f"`{typing_name}`[{formatted_inner}]"
            else:
                typing_name = type_str[7:]  # Remove 'typing.'
                return f"`{typing_name}`"
        
        # Handle module.Class patterns
        if '.' in type_str and not type_str.startswith('<'):
            try:
                module_path, class_name = type_str.rsplit('.', 1)
                # Try to import and track the class
                try:
                    imported_module = __import__(module_path, fromlist=[class_name])
                    imported_class = getattr(imported_module, class_name)
                    if inspect.isclass(imported_class):
                        if self._should_link_class(imported_class):
                            self._track_class(imported_class)
                            return f"[`{class_name}`]{get_mdx_path_from_class_name(class_name)}"
                        else:
                            return f"`{class_name}`"
                except Exception:
                    pass
                # If import fails, still create a link if it looks like a class and isn't a built-in
                if class_name[0].isupper() and not self._is_builtin_module(module_path):
                    return f"[`{class_name}`]{get_mdx_path_from_class_name(class_name)}"
                else:
                    return f"`{class_name}`"
            except ValueError:
                pass
        
        # Handle <class 'module.Class'> format
        if type_str.startswith('<class '):
            try:
                class_path = type_str.split("'")[1]
                if '.' in class_path:
                    module_path, class_name = class_path.rsplit('.', 1)
                    try:
                        imported_module = __import__(module_path, fromlist=[class_name])
                        imported_class = getattr(imported_module, class_name)
                        if inspect.isclass(imported_class):
                            if self._should_link_class(imported_class):
                                self._track_class(imported_class)
                            return f"[`{class_name}`]{get_mdx_path_from_class_name(class_name)}"
                    except Exception:
                        pass
                    # Only link if not a built-in module
                    if not self._is_builtin_module(module_path):
                        return f"[`{class_name}`]{get_mdx_path_from_class_name(class_name)}"
                    else:
                        return f"`{class_name}`"
                else:
                    return f"`{class_path}`"
            except (IndexError, ValueError):
                pass
        
        # Default case - wrap in backticks
        return f"`{type_str}`"
    
    def _should_link_class(self, cls: type) -> bool:
        """Determine if a class should be linked to documentation.
        
        Args:
            cls: The class to check
            
        Returns:
            True if the class should be linked, False otherwise
        """
        if not inspect.isclass(cls):
            return False
            
        # Don't link built-in types
        if cls.__module__ == 'builtins':
            return False
            
        # Don't link standard library types that are commonly used as type hints
        builtin_modules = {
            'datetime', 'pathlib', 'typing', 'collections', 'collections.abc',
            'decimal', 'fractions', 'uuid', 'enum', 'io', 'os', 're',
            'json', 'pickle', 'logging', 'threading', 'asyncio'
        }
        
        if cls.__module__ in builtin_modules:
            return False
            
        # Don't link if it starts with standard library prefixes
        if cls.__module__.startswith(('typing.', 'collections.', 'asyncio.', 'logging.')):
            return False
            
        return True
    
    def _is_builtin_module(self, module_path: str) -> bool:
        """Check if a module path refers to built-in/standard library modules.
        
        Args:
            module_path: The module path to check
            
        Returns:
            True if it's a built-in module that shouldn't be linked
        """
        builtin_modules = {
            'datetime', 'pathlib', 'typing', 'collections', 'collections.abc',
            'decimal', 'fractions', 'uuid', 'enum', 'io', 'os', 're',
            'json', 'pickle', 'logging', 'threading', 'asyncio', 'builtins'
        }
        
        return (module_path in builtin_modules or 
                module_path.startswith(('typing.', 'collections.', 'asyncio.', 'logging.')))

    def _parse_and_format_inner_types(self, inner_content: str, module=None) -> str:
        """Parse and format inner types from generic type strings.
        
        Args:
            inner_content: The inner content of a generic type (e.g., "List[Type], None")
            module: Optional module context
            
        Returns:
            Formatted inner types string
        """
        # Handle comma-separated types (like in Union[Type1, Type2])
        parts = []
        bracket_level = 0
        current_part = ""
        
        for char in inner_content:
            if char == '[':
                bracket_level += 1
                current_part += char
            elif char == ']':
                bracket_level -= 1
                current_part += char
            elif char == ',' and bracket_level == 0:
                parts.append(current_part.strip())
                current_part = ""
            else:
                current_part += char
        
        if current_part.strip():
            parts.append(current_part.strip())
        
        formatted_parts = []
        for part in parts:
            part = part.strip()
            
            # Handle nested generics like List[Type]
            if '[' in part and ']' in part:
                base_type = part[:part.find('[')]
                nested_content = part[part.find('[')+1:part.rfind(']')]
                formatted_nested = self._parse_and_format_inner_types(nested_content, module)
                
                # Try to resolve the base type
                if '.' in base_type:
                    class_name = base_type.split('.')[-1]
                    formatted_parts.append(f"`{class_name}`[{formatted_nested}]")
                else:
                    formatted_parts.append(f"`{base_type}`[{formatted_nested}]")
            else:
                # Handle simple types
                if '.' in part:
                    try:
                        module_path, class_name = part.rsplit('.', 1)
                        try:
                            imported_module = __import__(module_path, fromlist=[class_name])
                            imported_class = getattr(imported_module, class_name)
                            if inspect.isclass(imported_class):
                                if self._should_link_class(imported_class):
                                    self._track_class(imported_class)
                                    formatted_parts.append(f"[`{class_name}`]{get_mdx_path_from_class_name(class_name)}")
                                else:
                                    formatted_parts.append(f"`{class_name}`")
                                continue
                        except Exception:
                            pass
                        # If import fails, still create a link if it looks like a class and isn't built-in
                        if class_name[0].isupper() and not self._is_builtin_module(module_path):
                            formatted_parts.append(f"[`{class_name}`]{get_mdx_path_from_class_name(class_name)}")
                        else:
                            formatted_parts.append(f"`{class_name}`")
                    except ValueError:
                        formatted_parts.append(f"`{part}`")
                else:
                    # Handle simple type names
                    if part == 'None' or part == 'NoneType':
                        formatted_parts.append('`None`')
                    elif module and part in module.__dict__:
                        value = module.__dict__[part]
                        if inspect.isclass(value):
                            if self._should_link_class(value):
                                self._track_class(value)
                                formatted_parts.append(f"[`{part}`]{get_mdx_path_from_class_name(part)}")
                            else:
                                formatted_parts.append(f"`{part}`")
                        else:
                            formatted_parts.append(f"`{part}`")
                    else:
                        formatted_parts.append(f"`{part}`")
        
        return ', '.join(formatted_parts)

    def _format_type_for_param_field(self, type_annotation, module=None) -> str:
        """Format a type annotation for use in ParamField type attribute (plain text only).
        
        Args:
            type_annotation: The type annotation to format
            module: Optional module context for type resolution
            
        Returns:
            Plain text type string without backticks or links for ParamField usage
        """
        if type_annotation is None or type_annotation == type(None):
            return "None"
            
        # Handle string annotations (forward references)
        if isinstance(type_annotation, str):
            resolved = self._resolve_type(type_annotation, module)
            if inspect.isclass(resolved):
                if self._should_link_class(resolved):
                    self._track_class(resolved)
                return resolved.__name__
            else:
                return type_annotation
        
        # Handle ForwardRef
        if isinstance(type_annotation, ForwardRef):
            forward_arg = type_annotation.__forward_arg__
            resolved = self._resolve_type(forward_arg, module)
            if inspect.isclass(resolved):
                if self._should_link_class(resolved):
                    self._track_class(resolved)
                return resolved.__name__
            else:
                return forward_arg
        
        # Handle direct class types
        if inspect.isclass(type_annotation):
            if self._should_link_class(type_annotation):
                self._track_class(type_annotation)
            return type_annotation.__name__
        
        # Handle generic types using get_origin and get_args
        origin = get_origin(type_annotation)
        args = get_args(type_annotation)
        
        if origin is not None:
            # Handle Union types (including Optional)
            if origin is Union:
                formatted_args = []
                for arg in args:
                    formatted_args.append(self._format_type_for_param_field(arg, module))
                return ' | '.join(formatted_args)
            
            # Handle List, Set, Tuple, etc.
            elif origin in (list, List, set, typing.Set, tuple, Tuple):
                origin_name = origin.__name__ if hasattr(origin, '__name__') else str(origin).split('.')[-1]
                if args:
                    formatted_args = []
                    for arg in args:
                        formatted_args.append(self._format_type_for_param_field(arg, module))
                    return f"{origin_name}[{', '.join(formatted_args)}]"
                else:
                    return origin_name
            
            # Handle Dict
            elif origin in (dict, Dict):
                if args:
                    key_type = self._format_type_for_param_field(args[0], module)
                    value_type = self._format_type_for_param_field(args[1], module) if len(args) > 1 else "Any"
                    return f"Dict[{key_type}, {value_type}]"
                else:
                    return "Dict"
            
            # Handle Literal types — preserve quoted string values
            elif origin is typing.Literal:
                if args:
                    formatted_args = []
                    for arg in args:
                        if isinstance(arg, str):
                            formatted_args.append(f"'{arg}'")
                        else:
                            formatted_args.append(str(arg))
                    return f"Literal[{', '.join(formatted_args)}]"
                else:
                    return "Literal"

            # Handle Callable types — format parameter list and return type
            elif origin is typing.Callable or (hasattr(origin, '__name__') and origin.__name__ == 'Callable'):
                import collections.abc
                if origin is collections.abc.Callable and args and len(args) == 2:
                    param_types, return_type = args
                    formatted_return = self._format_type_for_param_field(return_type, module)
                    if param_types is Ellipsis:
                        return f"Callable[..., {formatted_return}]"
                    elif isinstance(param_types, list):
                        formatted_params = [self._format_type_for_param_field(p, module) for p in param_types]
                        return f"Callable[[{', '.join(formatted_params)}], {formatted_return}]"
                return "Callable"

            # Handle other generic types
            else:
                origin_name = getattr(origin, '__name__', str(origin))
                if args:
                    formatted_args = []
                    for arg in args:
                        formatted_args.append(self._format_type_for_param_field(arg, module))
                    return f"{origin_name}[{', '.join(formatted_args)}]"
                else:
                    return origin_name
        
        # Handle string representations of complex types
        type_str = str(type_annotation)
        
        # Handle typing.Optional, typing.List, etc.
        if type_str.startswith('typing.'):
            if '[' in type_str and ']' in type_str:
                typing_name = type_str[7:type_str.find('[')]  # Remove 'typing.'
                inner_content = type_str[type_str.find('[')+1:type_str.rfind(']')]
                formatted_inner = self._parse_and_format_inner_types_plain(inner_content, module)
                return f"{typing_name}[{formatted_inner}]"
            else:
                typing_name = type_str[7:]  # Remove 'typing.'
                return typing_name
        
        # Handle module.Class patterns
        if '.' in type_str and not type_str.startswith('<'):
            try:
                module_path, class_name = type_str.rsplit('.', 1)
                try:
                    imported_module = __import__(module_path, fromlist=[class_name])
                    imported_class = getattr(imported_module, class_name)
                    if inspect.isclass(imported_class) and self._should_link_class(imported_class):
                        self._track_class(imported_class)
                except Exception:
                    pass
                return class_name
            except ValueError:
                pass
        
        # Handle <class 'module.Class'> format
        if type_str.startswith('<class '):
            try:
                class_path = type_str.split("'")[1]
                if '.' in class_path:
                    module_path, class_name = class_path.rsplit('.', 1)
                    try:
                        imported_module = __import__(module_path, fromlist=[class_name])
                        imported_class = getattr(imported_module, class_name)
                        if inspect.isclass(imported_class) and self._should_link_class(imported_class):
                            self._track_class(imported_class)
                    except Exception:
                        pass
                    return class_name
                else:
                    return class_path
            except (IndexError, ValueError):
                pass
        
        # Default case - return plain text
        return str(type_annotation)
    
    def _parse_and_format_inner_types_plain(self, inner_content: str, module=None) -> str:
        """Parse and format inner types as plain text (for ParamField usage)."""
        parts = []
        bracket_level = 0
        current_part = ""
        
        for char in inner_content:
            if char == '[':
                bracket_level += 1
                current_part += char
            elif char == ']':
                bracket_level -= 1
                current_part += char
            elif char == ',' and bracket_level == 0:
                parts.append(current_part.strip())
                current_part = ""
            else:
                current_part += char
        
        if current_part.strip():
            parts.append(current_part.strip())
        
        formatted_parts = []
        for part in parts:
            part = part.strip()
            
            if '[' in part and ']' in part:
                base_type = part[:part.find('[')]
                nested_content = part[part.find('[')+1:part.rfind(']')]
                formatted_nested = self._parse_and_format_inner_types_plain(nested_content, module)
                
                if '.' in base_type:
                    class_name = base_type.split('.')[-1]
                    formatted_parts.append(f"{class_name}[{formatted_nested}]")
                else:
                    formatted_parts.append(f"{base_type}[{formatted_nested}]")
            else:
                if '.' in part:
                    try:
                        module_path, class_name = part.rsplit('.', 1)
                        try:
                            imported_module = __import__(module_path, fromlist=[class_name])
                            imported_class = getattr(imported_module, class_name)
                            if inspect.isclass(imported_class) and self._should_link_class(imported_class):
                                self._track_class(imported_class)
                        except Exception:
                            pass
                        formatted_parts.append(class_name)
                    except ValueError:
                        formatted_parts.append(part)
                else:
                    if part in ('None', 'NoneType'):
                        formatted_parts.append('None')
                    elif module and part in module.__dict__:
                        value = module.__dict__[part]
                        if inspect.isclass(value) and self._should_link_class(value):
                            self._track_class(value)
                        formatted_parts.append(part)
                    else:
                        formatted_parts.append(part)
        
        return ', '.join(formatted_parts)