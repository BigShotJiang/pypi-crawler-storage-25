"""Configuration module for the Sphinx Mintlify extension."""

from typing import Dict, Any
from pathlib import Path

from sphinx.application import Sphinx
from sphinx.config import Config
from sphinx.util import logging

logger = logging.getLogger(__name__)

def setup_config(app: Sphinx, config: Config) -> None:
    """Set up and validate the extension configuration.
    
    Args:
        app: The Sphinx application instance
        config: The Sphinx configuration object
    """
    # Validate and normalize output directory
    if not config.classmd_output_dir:
        logger.warning("No output directory specified, using 'docs/api'")
        config.classmd_output_dir = 'docs/api'
    config.classmd_output_dir = str(Path(config.classmd_output_dir).resolve())
    
    # Force format to MDX (no longer supporting MD)
    config.classmd_format = 'mdx'
    
    # Validate class list
    if not config.classmd_classes:
        logger.warning("No classes specified for documentation")
        config.classmd_classes = []
    
    # Set default method options if not provided
    if not hasattr(config, 'classmd_method_options'):
        config.classmd_method_options = {}
    
    default_method_options = {
        'include_source': True,
        'include_examples': True,
        'group_by_type': True
    }
    
    for key, value in default_method_options.items():
        if key not in config.classmd_method_options:
            config.classmd_method_options[key] = value
    
    # Set default method order if not provided
    if not hasattr(config, 'classmd_method_order'):
        config.classmd_method_order = [
            '__init__',
            'public_methods',
            'private_methods',
            'static_methods',
            'class_methods'
        ]
    
    # Set default templates if not provided
    if not hasattr(config, 'classmd_templates'):
        config.classmd_templates = {
            'class_index': None,
            'method': None
        }
    
    # Validate and load custom templates
    for template_type, template_path in config.classmd_templates.items():
        if template_path:
            template_file = Path(template_path)
            if not template_file.exists():
                logger.warning(
                    f"Template file not found: {template_path}"
                )
                config.classmd_templates[template_type] = None
    
    # Set default metadata if not provided
    if not hasattr(config, 'classmd_metadata'):
        config.classmd_metadata = {}
    
    default_metadata = {
        'api_version': '1.0.0',
        'api_status': 'stable',
        'sidebar_label': 'API Reference',
        'sidebar_position': 2
    }
    
    for key, value in default_metadata.items():
        if key not in config.classmd_metadata:
            config.classmd_metadata[key] = value 