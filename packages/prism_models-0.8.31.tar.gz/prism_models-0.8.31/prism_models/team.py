"""Team models for team-based access control."""

from datetime import datetime
from enum import StrEnum

from sqlalchemy import DateTime, Enum, ForeignKey, Integer, String, UniqueConstraint, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from prism_models.base import BaseModel
from prism_models.chat import ContactRole


class AppName(StrEnum):
    """Application names available for team-based access control."""

    POA = "POA"
    RFP = "RFP"
    PSAP = "PSAP"
    MED_VETTING = "MED_VETTING"
    OPS_HEAT_MAP = "OPS_HEAT_MAP"
    EP_APPLICATION = "EP_APPLICATION"


class Team(BaseModel):
    """Team entity for grouping contacts with shared access permissions."""

    __tablename__ = "team"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(200), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String(1000), nullable=True)
    role: Mapped[str] = mapped_column(Enum(ContactRole, name="contactrole", create_type=False), nullable=False)
    created_by_contact_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("contact.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now(), nullable=False)
    deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    members: Mapped[list["ContactTeam"]] = relationship("ContactTeam", back_populates="team", lazy="selectin")
    apps: Mapped[list["TeamApp"]] = relationship("TeamApp", back_populates="team", lazy="selectin", cascade="all, delete-orphan")
    profiles: Mapped[list["TeamProfile"]] = relationship("TeamProfile", back_populates="team", lazy="selectin", cascade="all, delete-orphan")


class ContactTeam(BaseModel):
    """Junction table linking contacts to teams."""

    __tablename__ = "contact_team"
    __table_args__ = (UniqueConstraint("contact_id", "team_id", name="uq_contact_team"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    contact_id: Mapped[int] = mapped_column(Integer, ForeignKey("contact.id"), nullable=False)
    team_id: Mapped[int] = mapped_column(Integer, ForeignKey("team.id"), nullable=False)
    assigned_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    assigned_by_contact_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("contact.id"), nullable=True)

    # Relationships
    team: Mapped["Team"] = relationship("Team", back_populates="members")


class TeamApp(BaseModel):
    """Junction table linking teams to applications."""

    __tablename__ = "team_app"
    __table_args__ = (UniqueConstraint("team_id", "app_name", name="uq_team_app"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    team_id: Mapped[int] = mapped_column(Integer, ForeignKey("team.id"), nullable=False)
    app_name: Mapped[str] = mapped_column(Enum(AppName, name="appname", create_type=True), nullable=False)

    # Relationships
    team: Mapped["Team"] = relationship("Team", back_populates="apps")


class TeamProfile(BaseModel):
    """Junction table linking teams to profiles."""

    __tablename__ = "team_profile"
    __table_args__ = (UniqueConstraint("team_id", "profile_id", name="uq_team_profile"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    team_id: Mapped[int] = mapped_column(Integer, ForeignKey("team.id"), nullable=False)
    profile_id: Mapped[int] = mapped_column(Integer, ForeignKey("profile.id"), nullable=False)

    # Relationships
    team: Mapped["Team"] = relationship("Team", back_populates="profiles")
