"""add team tables for team-based access control

Revision ID: a1b2c3d4e5f8
Revises: 7c8d9e0f1a2b
Create Date: 2026-04-17 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = 'a1b2c3d4e5f8'
down_revision: Union[str, Sequence[str], None] = '7c8d9e0f1a2b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    # Create appname enum type
    op.execute("""
        DO $$ BEGIN
            CREATE TYPE appname AS ENUM ('POA', 'RFP', 'PSAP', 'MED_VETTING', 'OPS_HEAT_MAP', 'EP_APPLICATION');
        EXCEPTION
            WHEN duplicate_object THEN NULL;
        END $$;
    """)

    # Create team table
    op.create_table(
        'team',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('name', sa.String(length=200), nullable=False),
        sa.Column('description', sa.String(length=1000), nullable=True),
        sa.Column('role', postgresql.ENUM('ADMIN', 'MANAGER', 'USER', name='contactrole', create_type=False), nullable=False),
        sa.Column('created_by_contact_id', sa.Integer(), sa.ForeignKey('contact.id'), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True),
        sa.PrimaryKeyConstraint('id', name=op.f('team_pkey')),
        sa.UniqueConstraint('name'),
    )
    op.create_index('ix_team_name', 'team', ['name'], unique=False)
    op.create_index('ix_team_deleted_at', 'team', ['deleted_at'], unique=False)

    # Create contact_team junction table
    op.create_table(
        'contact_team',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('contact_id', sa.Integer(), sa.ForeignKey('contact.id'), nullable=False),
        sa.Column('team_id', sa.Integer(), sa.ForeignKey('team.id'), nullable=False),
        sa.Column('assigned_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('assigned_by_contact_id', sa.Integer(), sa.ForeignKey('contact.id'), nullable=True),
        sa.PrimaryKeyConstraint('id', name=op.f('contact_team_pkey')),
        sa.UniqueConstraint('contact_id', 'team_id', name='uq_contact_team'),
    )
    op.create_index('ix_contact_team_contact_id', 'contact_team', ['contact_id'], unique=False)
    op.create_index('ix_contact_team_team_id', 'contact_team', ['team_id'], unique=False)

    # Create team_app junction table
    op.create_table(
        'team_app',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('team_id', sa.Integer(), sa.ForeignKey('team.id'), nullable=False),
        sa.Column('app_name', postgresql.ENUM('POA', 'RFP', 'PSAP', 'MED_VETTING', 'OPS_HEAT_MAP', 'EP_APPLICATION', name='appname', create_type=False), nullable=False),
        sa.PrimaryKeyConstraint('id', name=op.f('team_app_pkey')),
        sa.UniqueConstraint('team_id', 'app_name', name='uq_team_app'),
    )
    op.create_index('ix_team_app_team_id', 'team_app', ['team_id'], unique=False)
    op.create_index('ix_team_app_app_name', 'team_app', ['app_name'], unique=False)

    # Create team_profile junction table
    op.create_table(
        'team_profile',
        sa.Column('id', sa.Integer(), autoincrement=True, nullable=False),
        sa.Column('team_id', sa.Integer(), sa.ForeignKey('team.id'), nullable=False),
        sa.Column('profile_id', sa.Integer(), sa.ForeignKey('profile.id'), nullable=False),
        sa.PrimaryKeyConstraint('id', name=op.f('team_profile_pkey')),
        sa.UniqueConstraint('team_id', 'profile_id', name='uq_team_profile'),
    )
    op.create_index('ix_team_profile_team_id', 'team_profile', ['team_id'], unique=False)
    op.create_index('ix_team_profile_profile_id', 'team_profile', ['profile_id'], unique=False)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index('ix_team_profile_profile_id', table_name='team_profile')
    op.drop_index('ix_team_profile_team_id', table_name='team_profile')
    op.drop_table('team_profile')

    op.drop_index('ix_team_app_app_name', table_name='team_app')
    op.drop_index('ix_team_app_team_id', table_name='team_app')
    op.drop_table('team_app')

    op.drop_index('ix_contact_team_team_id', table_name='contact_team')
    op.drop_index('ix_contact_team_contact_id', table_name='contact_team')
    op.drop_table('contact_team')

    op.drop_index('ix_team_deleted_at', table_name='team')
    op.drop_index('ix_team_name', table_name='team')
    op.drop_table('team')

    op.execute("DROP TYPE IF EXISTS appname")
