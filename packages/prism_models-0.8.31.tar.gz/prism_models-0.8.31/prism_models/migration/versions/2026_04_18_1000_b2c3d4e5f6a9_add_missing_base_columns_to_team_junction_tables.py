"""add missing base columns to team junction tables

Revision ID: b2c3d4e5f6a9
Revises: a1b2c3d4e5f8
Create Date: 2026-04-18 10:00:00.000000

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b2c3d4e5f6a9'
down_revision: Union[str, Sequence[str], None] = 'a1b2c3d4e5f8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Add created_at, updated_at, deleted_at columns to contact_team, team_app, and team_profile tables."""
    for table in ('contact_team', 'team_app', 'team_profile'):
        op.add_column(table, sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False))
        op.add_column(table, sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False))
        op.add_column(table, sa.Column('deleted_at', sa.DateTime(timezone=True), nullable=True))


def downgrade() -> None:
    """Remove created_at, updated_at, deleted_at columns from contact_team, team_app, and team_profile tables."""
    for table in ('contact_team', 'team_app', 'team_profile'):
        op.drop_column(table, 'deleted_at')
        op.drop_column(table, 'updated_at')
        op.drop_column(table, 'created_at')
