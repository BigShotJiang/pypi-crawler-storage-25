# MD-DOCX Converter — Design Spec
*Date: 2026-03-11*

## Overview

A Python CLI tool for bidirectional conversion between GitHub Flavored Markdown (`.md`) and Microsoft Word (`.docx`). Primary use case: moving content between Word documents and AI tools with minimal friction.

---

## Decisions

| Question | Decision |
|---|---|
| Markdown dialect | GitHub Flavored Markdown (GFM) |
| Conversion engine | `markdown-it-py` (MD parsing) + `python-docx` (DOCX read/write) |
| Lossy element handling | Best-effort, silent drop — no warnings, no comment markers |
| Table conversion | Always attempt; merged cells unmerged, no-header tables get blank header row |
| Image handling | Extract to `{name}_images/` subfolder; re-embed on MD→DOCX |
| Unsupported Word formatting | Underline, highlight, small caps, font size changes → bold; font colour → stripped |
| CLI interface | Simple prompt loop; desktop shortcut via `.pyw` launcher |

---

## Architecture

```
md_docx_converter/
├── converter.py       # CLI entry point — input, validation, orchestration
├── md_to_docx.py      # MD → DOCX: walks markdown-it-py AST, builds python-docx document
├── docx_to_md.py      # DOCX → MD: reads python-docx document, emits GFM text
├── heading_mapper.py  # Pre-scan logic for Title/Heading 1 context rule (both directions)
├── image_handler.py   # Image extraction (DOCX→MD) and re-embedding (MD→DOCX)
└── launch.pyw         # Windowless Python launcher for the desktop shortcut
```

---

## CLI Flow

1. Prompt: `Enter file path:`  (strip surrounding quotes)
2. Validate: must be `.md` or `.docx` — warn and re-prompt if not
3. Compute output path: same directory, swapped extension
4. If output exists: `{filename} already exists. Overwrite? [y/N]` — default No
5. Run conversion
6. Print `✓ Saved: {output_path}` or plain error message
7. `Press Enter to close...` — keeps console window open

---

## Heading Hierarchy Rule

Requires a full document pre-scan before conversion begins (handled by `heading_mapper.py`).

**MD → DOCX:**
- Exactly one `#` in the document → map to Word **Title** style; `##`→H1, `###`→H2, etc.
- Multiple `#` lines → all map to Word **Heading 1**; `##`→H2, `###`→H3, etc.

**DOCX → MD:**
- Title style present → Title=`#`, H1=`##`, H2=`###`, etc.
- No Title style → H1=`#`, H2=`##`, H3=`###`, etc.

---

## Conversion Mapping

### MD → DOCX

| Markdown (GFM) | Word Output |
|---|---|
| Single `#` at top | Title style |
| Multiple `#` | Heading 1 style |
| `##`–`######` | Heading 2–6 (shifted if Title present) |
| `**text**`, `__text__` | Bold run |
| `*text*`, `_text_` | Italic run |
| `~~text~~` | Strikethrough run |
| `` `code` `` | Monospaced (Courier New) run |
| Fenced code block | Code paragraph style |
| `- [ ]` / `- [x]` | Bullet list + `☐` / `☑` |
| Unordered list | List Bullet style |
| Ordered list | List Number style |
| Nested list | List Bullet 2 / List Number 2 |
| `>` blockquote | Quote paragraph style |
| `---` thematic break | Horizontal rule |
| `[text](url)` | Hyperlink |
| `![alt](path)` | Inline image (re-embedded) |
| Table | Word table (first row = header) |

### DOCX → MD

| Word Element | Markdown Output |
|---|---|
| Title style | `#` |
| Heading 1–6 (no Title) | `#`–`######` |
| Heading 1–6 (Title present) | `##`–`######` |
| Bold | `**text**` |
| Italic | `*text*` |
| Strikethrough | `~~text~~` |
| Underline | `**text**` |
| Highlight | `**text**` |
| Small caps | `**text**` |
| Font size change | `**text**` |
| Font colour | stripped (text kept) |
| Monospaced font run | `` `text` `` |
| Code paragraph style | Fenced code block |
| List Bullet | `- item` |
| List Number | `1. item` |
| List Bullet 2 / Number 2 | `  - item` / `  1. item` |
| Quote style | `> text` |
| Horizontal rule | `---` |
| Hyperlink | `[text](url)` |
| Embedded image | `![alt]({name}_images/image1.png)` |
| Table | GFM pipe table |
| Table (no header) | GFM pipe table with blank header row |

---

## Image Handling

**DOCX → MD:**
- Extract to `{document_name}_images/` in same directory as output `.md`
- Named `image1.png`, `image2.png`, etc. in document order
- Alt text from Word image description field, blank if absent
- Formats preserved as-is (PNG, JPEG, GIF, BMP, TIFF)

**MD → DOCX:**
- Relative paths resolved from `.md` file directory
- File found → embedded in `.docx`
- File not found → `[image not found: path]` placeholder text
- Absolute paths and URLs → placeholder text (not fetched)

---

## MarkdownSyntax.md

The original JetBrains Hub Markdown reference has been replaced with a tool-specific GFM reference documenting exactly what this converter supports, approximates, and drops. See `MarkdownSyntax.md`.

---

## Out of Scope (v1)

- LaTeX / math equations
- Footnotes and endnotes
- HTML passthrough
- Definition lists
- Word tracked changes
- `.doc` format (Word 2003 and earlier)
- Nested tables
- Absolute URL image fetching
