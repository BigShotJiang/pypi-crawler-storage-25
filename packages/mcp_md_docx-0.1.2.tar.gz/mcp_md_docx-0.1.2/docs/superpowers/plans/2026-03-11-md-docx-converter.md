# MD-DOCX Converter Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a Python CLI tool that converts `.md` ↔ `.docx` bidirectionally using GFM Markdown and the user's Word Normal template.

**Architecture:** A CLI entry point (`converter.py`) orchestrates two one-way conversion modules (`md_to_docx.py`, `docx_to_md.py`). A shared `heading_mapper.py` pre-scans documents to resolve the Title/Heading ambiguity before conversion. Image extraction and re-embedding is isolated in `image_handler.py`. A `.pyw` launcher provides the desktop shortcut entry point.

**Tech Stack:** Python 3.11, `markdown-it-py` 3.0.0 (GFM parser), `python-docx` 1.1.0 (Word read/write), standard library only for everything else.

---

## File Map

| File | Responsibility |
|---|---|
| `md_docx_converter/converter.py` | CLI loop: prompt, validate, overwrite check, dispatch conversion, print result |
| `md_docx_converter/heading_mapper.py` | Pre-scan MD or DOCX to determine Title/Heading shift for both directions |
| `md_docx_converter/image_handler.py` | Extract images from DOCX to folder; resolve and embed images from MD |
| `md_docx_converter/md_to_docx.py` | Walk `markdown-it-py` token stream, write `python-docx` document |
| `md_docx_converter/docx_to_md.py` | Walk `python-docx` paragraphs/tables, emit GFM text |
| `md_docx_converter/launch.pyw` | Windowless launcher that runs `converter.py` in a console window |
| `tests/test_heading_mapper.py` | Unit tests for heading pre-scan logic |
| `tests/test_md_to_docx.py` | Unit tests for MD→DOCX conversion |
| `tests/test_docx_to_md.py` | Unit tests for DOCX→MD conversion |
| `tests/test_image_handler.py` | Unit tests for image extraction and embedding |
| `tests/test_converter.py` | Integration tests for CLI flow |
| `tests/fixtures/` | Sample `.md` and `.docx` files used by tests |

---

## Chunk 1: Project Scaffold + Heading Mapper

### Task 1: Create project structure and install check

**Files:**
- Create: `md_docx_converter/__init__.py`
- Create: `tests/__init__.py`
- Create: `tests/fixtures/` (directory)

- [ ] **Step 1: Create folder structure**

```bash
mkdir -p md_docx_converter tests/fixtures
touch md_docx_converter/__init__.py tests/__init__.py
```

- [ ] **Step 2: Verify libraries are available**

```bash
python -c "import markdown_it; import docx; print('OK')"
```

Expected output: `OK`

- [ ] **Step 3: Commit**

```bash
git init
git add md_docx_converter/__init__.py tests/__init__.py
git commit -m "chore: initialise project structure"
```

---

### Task 2: Heading mapper — MD direction

**Files:**
- Create: `md_docx_converter/heading_mapper.py`
- Create: `tests/test_heading_mapper.py`

**What it does:** Reads the raw Markdown text and returns the integer offset to apply to heading levels. If there is exactly one `#` heading, offset is 1 (so `#`→Title, `##`→H1, etc.). If there are zero or multiple `#` headings, offset is 0 (no Title, `#`→H1).

- [ ] **Step 1: Write the failing tests**

Create `tests/test_heading_mapper.py`:

```python
from md_docx_converter.heading_mapper import md_heading_offset, docx_heading_offset

def test_single_h1_gives_offset_1():
    md = "# My Title\n\n## Section\n\nSome text."
    assert md_heading_offset(md) == 1

def test_multiple_h1_gives_offset_0():
    md = "# First\n\n# Second\n\n## Sub"
    assert md_heading_offset(md) == 0

def test_no_h1_gives_offset_0():
    md = "## Section\n\nSome text."
    assert md_heading_offset(md) == 0

def test_h1_only_no_other_headings_gives_offset_1():
    md = "# Just a title\n\nSome body text."
    assert md_heading_offset(md) == 1
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_heading_mapper.py -v
```

Expected: `ModuleNotFoundError` or `ImportError`

- [ ] **Step 3: Implement `heading_mapper.py` MD function**

Create `md_docx_converter/heading_mapper.py`:

```python
import re
from pathlib import Path


def md_heading_offset(md_text: str) -> int:
    """Return 1 if there is exactly one # heading (use Title style), else 0."""
    h1_lines = re.findall(r'^#(?!#)', md_text, re.MULTILINE)
    return 1 if len(h1_lines) == 1 else 0
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_heading_mapper.py::test_single_h1_gives_offset_1 tests/test_heading_mapper.py::test_multiple_h1_gives_offset_0 tests/test_heading_mapper.py::test_no_h1_gives_offset_0 tests/test_heading_mapper.py::test_h1_only_no_other_headings_gives_offset_1 -v
```

Expected: 4 PASSED

- [ ] **Step 5: Commit**

```bash
git add md_docx_converter/heading_mapper.py tests/test_heading_mapper.py
git commit -m "feat: add MD heading offset pre-scan"
```

---

### Task 3: Heading mapper — DOCX direction

**Files:**
- Modify: `md_docx_converter/heading_mapper.py`
- Modify: `tests/test_heading_mapper.py`

**What it does:** Opens a `.docx` file using `python-docx` and checks whether any paragraph uses the `Title` style. Returns offset 1 if Title is present (all headings shift up), 0 if not.

- [ ] **Step 1: Create a fixture generator script and run it**

Create `tests/fixtures/make_fixtures.py`:

```python
"""Run once to create test fixture DOCX files. Re-run after adding new sections."""
from docx import Document
import os

fixtures = os.path.dirname(os.path.abspath(__file__))

# with_title.docx — has Title + Heading 1
doc = Document()
doc.add_paragraph("My Document Title", style="Title")
doc.add_paragraph("Section One", style="Heading 1")
doc.add_paragraph("Body text here.")
doc.save(os.path.join(fixtures, "with_title.docx"))

# no_title.docx — only Heading 1, no Title
doc2 = Document()
doc2.add_paragraph("Section One", style="Heading 1")
doc2.add_paragraph("Section Two", style="Heading 1")
doc2.add_paragraph("Body text here.")
doc2.save(os.path.join(fixtures, "no_title.docx"))

print("Fixtures created.")
```

```bash
python tests/fixtures/make_fixtures.py
```

Expected: `Fixtures created.` and two `.docx` files in `tests/fixtures/`

- [ ] **Step 2: Write the failing tests**

Append to `tests/test_heading_mapper.py`:

```python
from pathlib import Path

FIXTURES = Path(__file__).parent / "fixtures"

def test_docx_with_title_gives_offset_1():
    assert docx_heading_offset(FIXTURES / "with_title.docx") == 1

def test_docx_without_title_gives_offset_0():
    assert docx_heading_offset(FIXTURES / "no_title.docx") == 0
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
python -m pytest tests/test_heading_mapper.py::test_docx_with_title_gives_offset_1 tests/test_heading_mapper.py::test_docx_without_title_gives_offset_0 -v
```

Expected: `ImportError` (function not yet defined)

- [ ] **Step 4: Implement `docx_heading_offset` — append to `heading_mapper.py`**

Add the following at the top of `heading_mapper.py` (with the other imports), then append the function:

```python
from docx import Document as DocxDocument


def docx_heading_offset(docx_path: Path) -> int:
    """Return 1 if the DOCX contains a Title-style paragraph, else 0."""
    doc = DocxDocument(str(docx_path))
    for para in doc.paragraphs:
        if para.style.name == "Title":
            return 1
    return 0
```

- [ ] **Step 5: Run all heading mapper tests**

```bash
python -m pytest tests/test_heading_mapper.py -v
```

Expected: 6 PASSED

- [ ] **Step 6: Commit**

```bash
git add md_docx_converter/heading_mapper.py tests/test_heading_mapper.py tests/fixtures/
git commit -m "feat: add DOCX heading offset pre-scan"
```

---

## Chunk 2: MD → DOCX Conversion

### Task 4: Image handler — path resolver and DOCX embedder

**Files:**
- Create: `md_docx_converter/image_handler.py`
- Create: `tests/test_image_handler.py`

**What it does:** `resolve_image_path` takes an image `src` string and the source `.md` file's directory, and returns an absolute `Path` if the image file exists locally, or `None` for URLs, absolute paths, and missing files. `embed_image` takes a resolved path and a `python-docx` paragraph and adds the image as an inline picture run.

- [ ] **Step 1: Create a small test image fixture**

```bash
python -c "
from pathlib import Path
import struct, zlib
def make_png():
    def chunk(name, data):
        c = struct.pack('>I', len(data)) + name + data
        return c + struct.pack('>I', zlib.crc32(c[4:]) & 0xffffffff)
    sig = b'\x89PNG\r\n\x1a\n'
    ihdr = chunk(b'IHDR', struct.pack('>IIBBBBB', 1, 1, 8, 2, 0, 0, 0))
    raw = b'\x00\xff\xff\xff'
    idat = chunk(b'IDAT', zlib.compress(raw))
    iend = chunk(b'IEND', b'')
    return sig + ihdr + idat + iend
Path('tests/fixtures/sample.png').write_bytes(make_png())
print('done')
"
```

Expected: `done` and `tests/fixtures/sample.png` created.

- [ ] **Step 2: Write the failing tests**

Create `tests/test_image_handler.py`:

```python
from pathlib import Path
import pytest
from md_docx_converter.image_handler import resolve_image_path

FIXTURES = Path(__file__).parent / "fixtures"

def test_relative_path_found():
    result = resolve_image_path("sample.png", FIXTURES)
    assert result == (FIXTURES / "sample.png").resolve()

def test_relative_path_not_found():
    result = resolve_image_path("missing.png", FIXTURES)
    assert result is None

def test_absolute_path_returns_none():
    result = resolve_image_path("/absolute/path/image.png", FIXTURES)
    assert result is None

def test_url_returns_none():
    result = resolve_image_path("https://example.com/img.png", FIXTURES)
    assert result is None
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
python -m pytest tests/test_image_handler.py -v
```

Expected: `ImportError`

- [ ] **Step 4: Implement `image_handler.py`**

Create `md_docx_converter/image_handler.py`:

```python
import zipfile
from pathlib import Path
from docx.shared import Inches


def resolve_image_path(src: str, md_dir: Path) -> Path | None:
    """
    Resolve a Markdown image src to an absolute Path, or None if unresolvable.
    URLs and absolute paths are never fetched — return None.
    """
    if src.startswith(("http://", "https://", "ftp://")):
        return None
    candidate = Path(src)
    if candidate.is_absolute():
        return None
    resolved = (md_dir / candidate).resolve()
    return resolved if resolved.exists() else None


def embed_image(para, image_path: Path) -> None:
    """Add an inline image to an existing paragraph as a picture run."""
    run = para.add_run()
    run.add_picture(str(image_path), width=Inches(4))


def extract_docx_images(docx_path: Path, out_md_path: Path) -> dict[str, Path]:
    """
    Extract all images from a DOCX file into {stem}_images/ next to out_md_path.
    Returns a dict mapping ZIP internal name (e.g. 'word/media/image1.png')
    to the extracted file Path.
    """
    stem = out_md_path.stem
    images_dir = out_md_path.parent / f"{stem}_images"
    images_dir.mkdir(exist_ok=True)

    image_map: dict[str, Path] = {}
    counter = 1

    with zipfile.ZipFile(str(docx_path), "r") as zf:
        for name in zf.namelist():
            if name.startswith("word/media/"):
                suffix = Path(name).suffix or ".png"
                out_name = f"image{counter}{suffix}"
                out_path = images_dir / out_name
                out_path.write_bytes(zf.read(name))
                image_map[name] = out_path
                counter += 1

    return image_map
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
python -m pytest tests/test_image_handler.py -v
```

Expected: 4 PASSED

- [ ] **Step 6: Commit**

```bash
git add md_docx_converter/image_handler.py tests/test_image_handler.py tests/fixtures/sample.png
git commit -m "feat: add image path resolver, embedder, and extractor"
```

---

### Task 5: MD → DOCX core conversion

**Files:**
- Create: `md_docx_converter/md_to_docx.py`
- Create: `tests/test_md_to_docx.py`
- Create: `tests/fixtures/simple.md`

**What it does:** Parses GFM Markdown with `markdown-it-py`, walks the token stream, and writes a `python-docx` `Document` using the user's Normal template. Returns the saved `.docx` path.

`markdown-it-py` 3.x produces a flat token stream (not a tree). Tokens come in pairs: an opening token (e.g. `heading_open`) and a closing token (`heading_close`), with inline content tokens between them. The converter uses a simple state machine: track the current open block token, accumulate inline tokens, then write when the close token arrives.

**Note on hyperlinks:** `markdown-it-py` emits `link_open` tokens inside inline children with the URL in `tok.attrs["href"]`. We collect this URL and wrap the link text run(s) as `[text](url)` plain text in the paragraph — Word hyperlink XML injection requires complex relationship management and is deferred to a future enhancement. The link text and URL are preserved in the output.

- [ ] **Step 1: Create the simple fixture MD file**

Create `tests/fixtures/simple.md`:

```markdown
# My Title

## Section One

This is a **bold** word and an *italic* word and ~~strikethrough~~.

- Item one
- Item two
  - Nested item

1. First
2. Second

> A blockquote here.

---

[A link](https://example.com)

| Col A | Col B |
| ----- | ----- |
| One   | Two   |
```

- [ ] **Step 2: Write the failing tests**

Create `tests/test_md_to_docx.py`:

```python
from pathlib import Path
import pytest
from docx import Document
from md_docx_converter.md_to_docx import convert_md_to_docx

FIXTURES = Path(__file__).parent / "fixtures"
TEMPLATE = Path(r"C:\Users\Chris\AppData\Roaming\Microsoft\Templates\Normal.dotm")

if not TEMPLATE.exists():
    pytest.skip("Word Normal template not found — skipping DOCX tests", allow_module_level=True)


def _convert(md_file):
    out = FIXTURES / (md_file.stem + "_out.docx")
    convert_md_to_docx(md_file, out, TEMPLATE)
    return Document(str(out))


def test_single_h1_becomes_title():
    doc = _convert(FIXTURES / "simple.md")
    styles = [p.style.name for p in doc.paragraphs if p.text.strip()]
    assert styles[0] == "Title"


def test_h2_becomes_heading1_when_title_present():
    doc = _convert(FIXTURES / "simple.md")
    styles = [p.style.name for p in doc.paragraphs if p.text.strip()]
    assert "Heading 1" in styles


def test_bold_run_is_bold():
    doc = _convert(FIXTURES / "simple.md")
    for para in doc.paragraphs:
        for run in para.runs:
            if run.text == "bold":
                assert run.bold
                return
    raise AssertionError("No bold run found")


def test_italic_run_is_italic():
    doc = _convert(FIXTURES / "simple.md")
    for para in doc.paragraphs:
        for run in para.runs:
            if run.text == "italic":
                assert run.italic
                return
    raise AssertionError("No italic run found")


def test_blockquote_uses_quote_style():
    doc = _convert(FIXTURES / "simple.md")
    quote_paras = [p for p in doc.paragraphs if p.style.name == "Quote"]
    assert len(quote_paras) >= 1
    assert "blockquote" in quote_paras[0].text


def test_table_created():
    doc = _convert(FIXTURES / "simple.md")
    assert len(doc.tables) == 1


def test_table_has_correct_content():
    doc = _convert(FIXTURES / "simple.md")
    table = doc.tables[0]
    assert table.cell(0, 0).text == "Col A"
    assert table.cell(1, 0).text == "One"


def test_image_embedded():
    """Image referenced in MD is embedded in DOCX."""
    md_content = "# Title\n\n![alt](sample.png)\n"
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        # Copy sample.png to tmp so it can be resolved relative to the MD file
        import shutil
        shutil.copy(FIXTURES / "sample.png", tmp / "sample.png")
        md_path = tmp / "test_img.md"
        md_path.write_text(md_content, encoding="utf-8")
        out_path = tmp / "test_img.docx"
        convert_md_to_docx(md_path, out_path, TEMPLATE)
        doc = Document(str(out_path))
        # Check that at least one inline shape / image exists in the document XML
        body_xml = doc.element.body.xml
        assert "graphicData" in body_xml or "drawing" in body_xml
```

- [ ] **Step 3: Run tests to verify they fail**

```bash
python -m pytest tests/test_md_to_docx.py -v
```

Expected: `ImportError`

- [ ] **Step 4: Implement `md_to_docx.py`**

Create `md_docx_converter/md_to_docx.py`:

```python
from pathlib import Path
from docx import Document
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.shared import Pt
import markdown_it
from md_docx_converter.heading_mapper import md_heading_offset
from md_docx_converter.image_handler import resolve_image_path, embed_image


def convert_md_to_docx(md_path: Path, out_path: Path, template_path: Path) -> Path:
    md_text = md_path.read_text(encoding="utf-8")
    offset = md_heading_offset(md_text)
    md_dir = md_path.parent

    doc = Document(str(template_path))
    # Remove all existing body content from template (keep sectPr for page layout)
    for element in list(doc.element.body):
        tag = element.tag.split('}')[-1] if '}' in element.tag else element.tag
        if tag in ('p', 'tbl'):
            doc.element.body.remove(element)

    mdi = markdown_it.MarkdownIt("gfm-like")
    tokens = mdi.parse(md_text)

    _write_tokens(doc, tokens, offset, md_dir)

    doc.save(str(out_path))
    return out_path


def _write_tokens(doc, tokens, offset, md_dir):
    i = 0
    while i < len(tokens):
        tok = tokens[i]

        if tok.type == "heading_open":
            level = int(tok.tag[1])  # h1→1, h2→2, etc.
            inline = tokens[i + 1]
            style = _heading_style(level, offset)
            para = doc.add_paragraph(style=style)
            _apply_inline(para, inline.children or [], md_dir)
            i += 3  # heading_open, inline, heading_close

        elif tok.type == "paragraph_open":
            inline = tokens[i + 1]
            para = doc.add_paragraph(style="Normal")
            _apply_inline(para, inline.children or [], md_dir)
            i += 3

        elif tok.type == "bullet_list_open":
            i, _ = _write_list(doc, tokens, i, "List Bullet", depth=0, md_dir=md_dir)

        elif tok.type == "ordered_list_open":
            i, _ = _write_list(doc, tokens, i, "List Number", depth=0, md_dir=md_dir)

        elif tok.type == "blockquote_open":
            i = _write_blockquote(doc, tokens, i, md_dir)

        elif tok.type == "fence":
            _write_code_block(doc, tok)
            i += 1

        elif tok.type == "hr":
            _write_hr(doc)
            i += 1

        elif tok.type in ("html_block", "html_inline"):
            i += 1  # silently drop HTML

        elif tok.type == "table_open":
            i = _write_table(doc, tokens, i)

        else:
            i += 1


def _heading_style(level: int, offset: int) -> str:
    if offset == 1 and level == 1:
        return "Title"
    adjusted = level - offset
    adjusted = max(1, min(adjusted, 9))
    return f"Heading {adjusted}"


def _apply_inline(para, children, md_dir: Path):
    """Apply inline tokens to a paragraph as runs, handling bold/italic/code/images/links."""
    bold = False
    italic = False
    strike = False
    link_href = None

    i = 0
    while i < len(children):
        child = children[i]

        if child.type == "strong_open":
            bold = True
        elif child.type == "strong_close":
            bold = False
        elif child.type == "em_open":
            italic = True
        elif child.type == "em_close":
            italic = False
        elif child.type == "s_open":
            strike = True
        elif child.type == "s_close":
            strike = False
        elif child.type == "link_open":
            link_href = child.attrs.get("href", "")
        elif child.type == "link_close":
            link_href = None
        elif child.type == "code_inline":
            run = para.add_run(child.content)
            run.font.name = "Courier New"
            run.font.size = Pt(10)
        elif child.type == "image":
            # Inline image: src is in child.attrs["src"], alt text in child.children
            src = child.attrs.get("src", "")
            resolved = resolve_image_path(src, md_dir)
            if resolved:
                embed_image(para, resolved)
            else:
                para.add_run(f"[image not found: {src}]")
        elif child.type in ("softbreak", "hardbreak"):
            para.add_run("\n")
        elif child.type == "text":
            content = child.content
            # If inside a link, append the URL as plain text after link text
            if link_href and i + 1 < len(children) and children[i + 1].type == "link_close":
                content = f"{content} ({link_href})"
            run = para.add_run(content)
            run.bold = bold
            run.italic = italic
            run.font.strike = strike
        elif child.type == "html_inline":
            pass  # drop inline HTML

        i += 1


def _task_list_prefix(children) -> tuple[str, list]:
    """
    If inline children start with text '[ ] ' or '[x] ', return the checkbox
    character and the children list with the prefix stripped from the first text token.
    Returns ('', children) if not a task list item.
    """
    if not children:
        return "", children
    first = children[0]
    if first.type != "text":
        return "", children

    import markdown_it.token as mit
    for prefix, symbol in [("[ ] ", "☐ "), ("[x] ", "☑ "), ("[X] ", "☑ ")]:
        if first.content.startswith(prefix):
            new_first = mit.Token(first.type, first.tag, first.nesting)
            new_first.content = first.content[len(prefix):]
            return symbol, [new_first] + list(children[1:])

    return "", children


def _write_list(doc, tokens, i, base_style, depth, md_dir):
    """Write a list block. Returns (new_index, None)."""
    open_type = tokens[i].type
    close_type = open_type.replace("_open", "_close")
    i += 1
    while i < len(tokens):
        tok = tokens[i]
        if tok.type == close_type:
            i += 1
            break
        elif tok.type == "list_item_open":
            i += 1
            while i < len(tokens) and tokens[i].type != "list_item_close":
                inner = tokens[i]
                if inner.type == "paragraph_open":
                    inline = tokens[i + 1]
                    children = inline.children or []
                    style = base_style if depth == 0 else f"{base_style} {min(depth + 1, 3)}"
                    checkbox, children = _task_list_prefix(children)
                    para = doc.add_paragraph(style=style)
                    if checkbox:
                        para.add_run(checkbox)
                    _apply_inline(para, children, md_dir)
                    i += 3  # paragraph_open, inline, paragraph_close
                elif inner.type in ("bullet_list_open", "ordered_list_open"):
                    nested_style = "List Bullet" if "bullet" in inner.type else "List Number"
                    i, _ = _write_list(doc, tokens, i, nested_style, depth + 1, md_dir)
                else:
                    i += 1
        else:
            i += 1
    return i, None


def _write_blockquote(doc, tokens, i, md_dir):
    i += 1  # skip blockquote_open
    depth = 1
    while i < len(tokens):
        tok = tokens[i]
        if tok.type == "blockquote_open":
            depth += 1
            i += 1
        elif tok.type == "blockquote_close":
            depth -= 1
            i += 1
            if depth == 0:
                break
        elif tok.type == "paragraph_open":
            inline = tokens[i + 1]
            para = doc.add_paragraph(style="Quote")
            _apply_inline(para, inline.children or [], md_dir)
            i += 3
        else:
            i += 1
    return i


def _write_code_block(doc, tok):
    content = tok.content.rstrip("\n")
    para = doc.add_paragraph(style="Normal")
    run = para.add_run(content)
    run.font.name = "Courier New"
    run.font.size = Pt(10)
    # Try to apply a Code style if it exists in the template
    try:
        para.style = doc.styles["Code"]
    except KeyError:
        pass  # No Code style in template — monospaced Normal is acceptable


def _write_hr(doc):
    para = doc.add_paragraph()
    pPr = para._p.get_or_add_pPr()
    pBdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), "6")
    bottom.set(qn("w:space"), "1")
    bottom.set(qn("w:color"), "auto")
    pBdr.append(bottom)
    pPr.append(pBdr)


def _write_table(doc, tokens, i):
    rows = []
    i += 1  # skip table_open
    while i < len(tokens) and tokens[i].type != "table_close":
        tok = tokens[i]
        if tok.type in ("thead_open", "tbody_open", "thead_close", "tbody_close"):
            i += 1
        elif tok.type == "tr_open":
            row_cells = []
            i += 1
            while i < len(tokens) and tokens[i].type != "tr_close":
                if tokens[i].type in ("th_open", "td_open"):
                    inline = tokens[i + 1]
                    text = "".join(
                        c.content for c in (inline.children or []) if c.type == "text"
                    )
                    row_cells.append(text)
                    i += 3  # th/td open, inline, th/td close
                else:
                    i += 1
            rows.append(row_cells)
            i += 1  # skip tr_close
        else:
            i += 1
    i += 1  # skip table_close

    if not rows:
        return i

    num_cols = max(len(r) for r in rows)
    rows = [r + [""] * (num_cols - len(r)) for r in rows]

    table = doc.add_table(rows=len(rows), cols=num_cols)
    table.style = "Table Grid"
    for r_idx, row in enumerate(rows):
        for c_idx, cell_text in enumerate(row):
            table.cell(r_idx, c_idx).text = cell_text

    return i
```

- [ ] **Step 5: Run tests to verify they pass**

```bash
python -m pytest tests/test_md_to_docx.py -v
```

Expected: all PASSED

- [ ] **Step 6: Commit**

```bash
git add md_docx_converter/md_to_docx.py tests/test_md_to_docx.py tests/fixtures/simple.md
git commit -m "feat: implement MD to DOCX conversion"
```

---

### Task 6: MD → DOCX task list verification test

**Files:**
- Modify: `tests/test_md_to_docx.py`
- Create: `tests/fixtures/tasks.md`

**What it does:** Task list support is already wired into `_write_list` via `_task_list_prefix`. This task adds a fixture and tests to verify the behaviour is correct.

- [ ] **Step 1: Create task list fixture**

Create `tests/fixtures/tasks.md`:

```markdown
- [ ] Unchecked task
- [x] Checked task
- Plain bullet
```

- [ ] **Step 2: Write failing tests**

Append to `tests/test_md_to_docx.py`:

```python
def test_task_list_unchecked():
    doc = _convert(FIXTURES / "tasks.md")
    texts = [p.text for p in doc.paragraphs if p.text.strip()]
    assert any("☐" in t for t in texts)


def test_task_list_checked():
    doc = _convert(FIXTURES / "tasks.md")
    texts = [p.text for p in doc.paragraphs if p.text.strip()]
    assert any("☑" in t for t in texts)


def test_plain_bullet_has_no_checkbox():
    doc = _convert(FIXTURES / "tasks.md")
    texts = [p.text for p in doc.paragraphs if p.text.strip()]
    plain = [t for t in texts if "Plain bullet" in t]
    assert len(plain) == 1
    assert "☐" not in plain[0] and "☑" not in plain[0]
```

- [ ] **Step 3: Run tests to verify they pass**

Note: task list support is already implemented in `md_to_docx.py` from Task 5. These tests are expected to pass immediately.

```bash
python -m pytest tests/test_md_to_docx.py::test_task_list_unchecked tests/test_md_to_docx.py::test_task_list_checked tests/test_md_to_docx.py::test_plain_bullet_has_no_checkbox -v
```

Expected: 3 PASSED

- [ ] **Step 4: Run all MD→DOCX tests**

```bash
python -m pytest tests/test_md_to_docx.py -v
```

Expected: all PASSED (task list support is already in `md_to_docx.py` from Task 5)

- [ ] **Step 5: Commit**

```bash
git add tests/test_md_to_docx.py tests/fixtures/tasks.md
git commit -m "test: verify GFM task list conversion"
```

---

## Chunk 3: DOCX → MD Conversion

### Task 7: Add image-bearing fixture

**Files:**
- Modify: `tests/fixtures/make_fixtures.py`

**What it does:** Extend the fixture generator with a DOCX that has an embedded image, for use in DOCX→MD image extraction tests.

- [ ] **Step 1: Append to `make_fixtures.py` and re-run**

Append the following to `tests/fixtures/make_fixtures.py` (before the final `print` statement, or add a new print):

```python
from docx.shared import Inches

# with_image.docx — has an embedded image
doc3 = Document()
doc3.add_paragraph("Before image")
doc3.add_picture(os.path.join(fixtures, "sample.png"), width=Inches(1))
doc3.add_paragraph("After image")
doc3.save(os.path.join(fixtures, "with_image.docx"))

# rich.docx — tests all element types for DOCX→MD
doc4 = Document()
doc4.add_paragraph("Document Title", style="Title")
doc4.add_paragraph("Section One", style="Heading 1")
doc4.add_paragraph("Normal body text.")
p = doc4.add_paragraph()
run = p.add_run("bold word")
run.bold = True
p.add_run(" and plain.")
doc4.add_paragraph("Quote text", style="Quote")
table = doc4.add_table(rows=2, cols=2)
table.cell(0, 0).text = "H1"
table.cell(0, 1).text = "H2"
table.cell(1, 0).text = "R1"
table.cell(1, 1).text = "R2"
doc4.save(os.path.join(fixtures, "rich.docx"))

print("All fixtures created.")
```

```bash
python tests/fixtures/make_fixtures.py
```

Expected: `All fixtures created.` and `with_image.docx`, `rich.docx` in `tests/fixtures/`

- [ ] **Step 2: Verify image extraction works with the new fixture**

```bash
python -m pytest tests/test_image_handler.py -v
```

Expected: all PASSED (the `extract_docx_images` function was implemented in Task 4)

- [ ] **Step 3: Write the image extraction tests**

Append to `tests/test_image_handler.py`:

```python
import tempfile
from md_docx_converter.image_handler import extract_docx_images

def test_extract_images_creates_folder():
    with tempfile.TemporaryDirectory() as tmp:
        out_md = Path(tmp) / "output.md"
        extract_docx_images(FIXTURES / "with_image.docx", out_md)
        images_dir = Path(tmp) / "output_images"
        assert images_dir.exists()

def test_extract_images_returns_map():
    with tempfile.TemporaryDirectory() as tmp:
        out_md = Path(tmp) / "output.md"
        image_map = extract_docx_images(FIXTURES / "with_image.docx", out_md)
        assert len(image_map) >= 1
        for extracted_path in image_map.values():
            assert Path(extracted_path).exists()
```

- [ ] **Step 4: Run all image handler tests**

```bash
python -m pytest tests/test_image_handler.py -v
```

Expected: all PASSED

- [ ] **Step 5: Commit**

```bash
git add tests/fixtures/make_fixtures.py tests/fixtures/ tests/test_image_handler.py
git commit -m "test: add image extraction tests and rich/image fixtures"
```

---

### Task 8: DOCX → MD core conversion

**Files:**
- Create: `md_docx_converter/docx_to_md.py`
- Create: `tests/test_docx_to_md.py`

**What it does:** Opens a `.docx`, walks paragraphs and tables in document order, and emits GFM Markdown text. Uses `heading_mapper.docx_heading_offset` first to determine heading shift. Uses `image_handler.extract_docx_images` to extract images and insert relative Markdown image references.

`python-docx` exposes paragraphs and tables as separate collections. To preserve document order (paragraphs and tables interleaved), iterate over `doc.element.body` child elements and dispatch by XML tag.

**Hyperlink implementation:** Word stores hyperlinks as `<w:hyperlink r:id="rId5">` elements in the paragraph XML. We walk these to extract the relationship URL and the run text inside, then emit `[text](url)` GFM syntax.

**Image detection:** Word inline images are stored in `<w:drawing>` elements inside runs. The blip (image reference) is at `w:drawing/wp:inline/a:graphic/a:graphicData/pic:pic/pic:blipFill/a:blip` with an `r:embed` relationship ID. We resolve this ID against the document's relationships to find the extracted image file.

- [ ] **Step 1: Write the failing tests**

Create `tests/test_docx_to_md.py`:

```python
from pathlib import Path
import tempfile
from md_docx_converter.docx_to_md import convert_docx_to_md

FIXTURES = Path(__file__).parent / "fixtures"


def _convert(docx_file):
    with tempfile.TemporaryDirectory() as tmp:
        out_md = Path(tmp) / (docx_file.stem + ".md")
        convert_docx_to_md(docx_file, out_md)
        return out_md.read_text(encoding="utf-8")


def test_title_becomes_h1():
    md = _convert(FIXTURES / "rich.docx")
    assert md.startswith("# Document Title")


def test_heading1_becomes_h2_when_title_present():
    md = _convert(FIXTURES / "rich.docx")
    assert "## Section One" in md


def test_bold_run_wrapped():
    md = _convert(FIXTURES / "rich.docx")
    assert "**bold word**" in md


def test_blockquote():
    md = _convert(FIXTURES / "rich.docx")
    assert "> Quote text" in md


def test_table_pipe_syntax():
    md = _convert(FIXTURES / "rich.docx")
    assert "| H1 |" in md
    assert "| R1 |" in md


def test_no_title_h1_stays_h1():
    md = _convert(FIXTURES / "no_title.docx")
    assert "# Section One" in md


def test_code_style_becomes_fenced_block():
    """A paragraph with Code style becomes a fenced code block."""
    from docx import Document
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        doc = Document()
        try:
            p = doc.add_paragraph("print('hello')", style="Code")
        except KeyError:
            import pytest
            pytest.skip("No 'Code' style in default template")
        docx_path = tmp / "code.docx"
        doc.save(str(docx_path))
        out_md = tmp / "code.md"
        convert_docx_to_md(docx_path, out_md)
        result = out_md.read_text(encoding="utf-8")
        assert "```" in result
        assert "print('hello')" in result


def test_image_extracted_and_referenced():
    """Converting a DOCX with an embedded image produces a ![...] reference."""
    md = _convert(FIXTURES / "with_image.docx")
    assert "![" in md
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_docx_to_md.py -v
```

Expected: `ImportError`

- [ ] **Step 3: Implement `docx_to_md.py`**

Create `md_docx_converter/docx_to_md.py`:

```python
from pathlib import Path
from docx import Document
from md_docx_converter.heading_mapper import docx_heading_offset
from md_docx_converter.image_handler import extract_docx_images

# Word namespace URIs
_W  = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_WP = "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
_A  = "http://schemas.openxmlformats.org/drawingml/2006/main"
_PIC = "http://schemas.openxmlformats.org/drawingml/2006/picture"
_R  = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

# Monospaced font names (lowercase)
_MONO_FONTS = {"courier new", "courier", "consolas", "lucida console",
               "monaco", "menlo", "source code pro"}


def convert_docx_to_md(docx_path: Path, out_md_path: Path) -> Path:
    offset = docx_heading_offset(docx_path)
    image_map = extract_docx_images(docx_path, out_md_path)

    doc = Document(str(docx_path))

    # Build relationship ID → extracted image Path
    rel_to_path: dict[str, Path] = {}
    for rId, rel in doc.part.rels.items():
        if "image" in rel.reltype:
            target = rel.target_ref          # e.g. '../media/image1.png'
            internal = "word/" + target.lstrip("../")
            if internal in image_map:
                rel_to_path[rId] = image_map[internal]

    lines: list[str] = []

    for child in doc.element.body:
        tag = child.tag.split("}")[1] if "}" in child.tag else child.tag
        if tag == "p":
            para = _find_para(doc, child)
            if para is not None:
                md_line = _para_to_md(para, offset, out_md_path, rel_to_path, doc)
                if md_line is not None:
                    lines.append(md_line)
        elif tag == "tbl":
            table = _find_table(doc, child)
            if table is not None:
                lines.append(_table_to_md(table))

    out_md_path.write_text("\n\n".join(lines) + "\n", encoding="utf-8")
    return out_md_path


def _find_para(doc, elem):
    for para in doc.paragraphs:
        if para._element is elem:
            return para
    return None


def _find_table(doc, elem):
    for table in doc.tables:
        if table._element is elem:
            return table
    return None


def _para_to_md(para, offset: int, out_md_path: Path,
                rel_to_path: dict, doc) -> str | None:
    style = para.style.name

    # Code style → fenced code block
    if style == "Code":
        return f"```\n{para.text}\n```"

    text = _runs_to_md(para, out_md_path, rel_to_path, doc)

    # Also check for hyperlinks in the paragraph XML
    text = _extract_hyperlinks(para, text, doc)

    if not text.strip():
        return None

    if style == "Title":
        return f"# {text}"

    if style.startswith("Heading "):
        try:
            level = int(style.split()[-1])
        except ValueError:
            return text
        md_level = level + offset
        return "#" * md_level + f" {text}"

    if style.startswith("List Bullet"):
        depth = _list_depth(style)
        return "  " * depth + f"- {text}"

    if style.startswith("List Number"):
        depth = _list_depth(style)
        return "  " * depth + f"1. {text}"

    if style in ("Quote", "Block Text", "Quotations"):
        return f"> {text}"

    return text


def _list_depth(style_name: str) -> int:
    parts = style_name.split()
    if len(parts) >= 3:
        try:
            return int(parts[-1]) - 1
        except ValueError:
            pass
    return 0


def _runs_to_md(para, out_md_path: Path, rel_to_path: dict, doc) -> str:
    parts = []
    for run in para.runs:
        text = run.text

        # Check for inline image drawing in this run
        img_md = _run_image_md(run, out_md_path, rel_to_path)
        if img_md:
            parts.append(img_md)
            continue

        if not text:
            continue

        is_bold = bool(run.bold)
        is_italic = bool(run.italic)
        is_strike = bool(run.font.strike)
        is_mono = (run.font.name or "").lower() in _MONO_FONTS

        # Approximate unsupported formatting as bold
        is_underline = bool(run.underline)
        is_highlight = bool(run.font.highlight_color)
        is_small_caps = bool(run.font.small_caps)
        is_large = bool(run.font.size and run.font.size.pt > 14) if run.font.size else False
        approx_bold = is_underline or is_highlight or is_small_caps or is_large
        effective_bold = is_bold or approx_bold

        if is_mono:
            parts.append(f"`{text}`")
            continue

        if is_strike:
            text = f"~~{text}~~"
        if effective_bold and is_italic:
            text = f"***{text}***"
        elif effective_bold:
            text = f"**{text}**"
        elif is_italic:
            text = f"*{text}*"

        parts.append(text)

    return "".join(parts)


def _run_image_md(run, out_md_path: Path, rel_to_path: dict) -> str | None:
    """
    Check if a run contains an inline Word drawing (image).
    Word inline images sit at: w:r/w:drawing/wp:inline/a:graphic/a:graphicData/
                                pic:pic/pic:blipFill/a:blip[@r:embed]
    """
    drawing_elems = run._element.findall(f"{{{_W}}}drawing")
    for drawing in drawing_elems:
        # Navigate to the blip element
        blip = drawing.find(
            f"{{{_WP}}}inline/{{{_A}}}graphic/{{{_A}}}graphicData"
            f"/{{{_PIC}}}pic/{{{_PIC}}}blipFill/{{{_A}}}blip"
        )
        if blip is None:
            continue
        r_embed = blip.get(f"{{{_R}}}embed")
        if r_embed and r_embed in rel_to_path:
            img_path = rel_to_path[r_embed]
            try:
                rel = img_path.relative_to(out_md_path.parent)
                return f"![]({rel.as_posix()})"
            except ValueError:
                return f"![]({img_path.as_posix()})"
    return None


def _extract_hyperlinks(para, plain_text: str, doc) -> str:
    """
    Walk paragraph XML for <w:hyperlink> elements. For each hyperlink found,
    extract the URL from the document relationships and the text from child runs,
    then emit [text](url). If no hyperlinks exist, return plain_text unchanged.
    """
    hyperlink_tag = f"{{{_W}}}hyperlink"
    hyperlinks = para._element.findall(hyperlink_tag)
    if not hyperlinks:
        return plain_text

    # Re-build the paragraph text from scratch, substituting hyperlinks
    parts = []
    for child in para._element:
        tag = child.tag.split("}")[1] if "}" in child.tag else child.tag
        if child.tag == hyperlink_tag:
            # Extract run text from child runs
            run_texts = []
            for r_elem in child.findall(f"{{{_W}}}r"):
                t_elem = r_elem.find(f"{{{_W}}}t")
                if t_elem is not None and t_elem.text:
                    run_texts.append(t_elem.text)
            link_text = "".join(run_texts)

            # Resolve URL from relationship
            r_id = child.get(f"{{{_R}}}id")
            url = ""
            if r_id and r_id in doc.part.rels:
                url = doc.part.rels[r_id].target_ref

            if url:
                parts.append(f"[{link_text}]({url})")
            else:
                parts.append(link_text)
        elif tag == "r":
            t_elem = child.find(f"{{{_W}}}t")
            if t_elem is not None and t_elem.text:
                parts.append(t_elem.text)

    rebuilt = "".join(parts)
    return rebuilt if rebuilt.strip() else plain_text


def _table_to_md(table) -> str:
    rows = []
    for row in table.rows:
        cells = [cell.text.strip().replace("|", "\\|") for cell in row.cells]
        rows.append("| " + " | ".join(cells) + " |")

    if not rows:
        return ""

    num_cols = len(table.columns)
    separator = "| " + " | ".join(["---"] * num_cols) + " |"
    rows.insert(1, separator)
    return "\n".join(rows)
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_docx_to_md.py -v
```

Expected: all PASSED (the `test_code_style_becomes_fenced_block` test may skip if the template has no Code style — that is acceptable)

- [ ] **Step 5: Commit**

```bash
git add md_docx_converter/docx_to_md.py tests/test_docx_to_md.py
git commit -m "feat: implement DOCX to MD conversion"
```

---

## Chunk 4: CLI, Launcher, and Integration Tests

### Task 9: CLI entry point

**Files:**
- Create: `md_docx_converter/converter.py`
- Create: `tests/test_converter.py`

**What it does:** Prompt loop with validation, overwrite check, dispatches to `md_to_docx` or `docx_to_md`, prints result. Stays open after completion until Enter is pressed. Checks that the Word template exists before attempting conversion and gives a clear error if not.

- [ ] **Step 1: Write failing unit tests**

Create `tests/test_converter.py`:

```python
from pathlib import Path
from md_docx_converter.converter import determine_output_path, validate_extension


def test_md_input_gives_docx_output():
    p = Path("/some/dir/report.md")
    assert determine_output_path(p) == Path("/some/dir/report.docx")


def test_docx_input_gives_md_output():
    p = Path("/some/dir/report.docx")
    assert determine_output_path(p) == Path("/some/dir/report.md")


def test_valid_md_extension():
    assert validate_extension(Path("file.md")) is True


def test_valid_docx_extension():
    assert validate_extension(Path("file.docx")) is True


def test_invalid_extension_txt():
    assert validate_extension(Path("file.txt")) is False


def test_invalid_extension_pdf():
    assert validate_extension(Path("file.pdf")) is False
```

- [ ] **Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_converter.py -v
```

Expected: `ImportError`

- [ ] **Step 3: Implement `converter.py`**

Create `md_docx_converter/converter.py`:

```python
from pathlib import Path

TEMPLATE_PATH = Path(r"C:\Users\Chris\AppData\Roaming\Microsoft\Templates\Normal.dotm")


def validate_extension(path: Path) -> bool:
    return path.suffix.lower() in (".md", ".docx")


def determine_output_path(input_path: Path) -> Path:
    if input_path.suffix.lower() == ".md":
        return input_path.with_suffix(".docx")
    return input_path.with_suffix(".md")


def run():
    print("MD ↔ DOCX Converter")
    print("--------------------")

    while True:
        raw = input("Enter file path: ").strip().strip('"').strip("'")
        if not raw:
            continue
        input_path = Path(raw)

        if not input_path.exists():
            print(f"  File not found: {input_path}")
            continue

        if not validate_extension(input_path):
            print(f"  Not a .md or .docx file: {input_path.name}")
            continue

        break

    out_path = determine_output_path(input_path)

    if out_path.exists():
        answer = input(f"  {out_path.name} already exists. Overwrite? [y/N] ").strip().lower()
        if answer != "y":
            print("  Cancelled.")
            input("\nPress Enter to close...")
            return

    try:
        if input_path.suffix.lower() == ".md":
            if not TEMPLATE_PATH.exists():
                raise FileNotFoundError(
                    f"Word template not found at:\n  {TEMPLATE_PATH}\n"
                    "Please check the path in converter.py"
                )
            from md_docx_converter.md_to_docx import convert_md_to_docx
            convert_md_to_docx(input_path, out_path, TEMPLATE_PATH)
        else:
            from md_docx_converter.docx_to_md import convert_docx_to_md
            convert_docx_to_md(input_path, out_path)

        print(f"\n✓ Saved: {out_path}")
    except Exception as e:
        print(f"\n  Error: {e}")

    input("\nPress Enter to close...")


if __name__ == "__main__":
    run()
```

- [ ] **Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_converter.py -v
```

Expected: all PASSED

- [ ] **Step 5: Smoke test the CLI manually**

```bash
python -m md_docx_converter.converter
```

Enter `tests/fixtures/simple.md` when prompted. Verify `tests/fixtures/simple.docx` is created and opens in Word correctly showing Title, Heading 1, bold text, and a table.

- [ ] **Step 6: Commit**

```bash
git add md_docx_converter/converter.py tests/test_converter.py
git commit -m "feat: add CLI entry point with template existence check"
```

---

### Task 10: Desktop launcher

**Files:**
- Create: `md_docx_converter/launch.pyw`
- Create: `create_shortcut.py`

**What it does:** `launch.pyw` opens a Windows console and runs `converter.py` inside it. The console stays open because `converter.py` ends with `input("\nPress Enter to close...")` — there is no extra `pause` needed in the launcher. `create_shortcut.py` is a one-time script to create the `.lnk` shortcut.

- [ ] **Step 1: Create `launch.pyw`**

Create `md_docx_converter/launch.pyw`:

```python
"""
Desktop launcher for MD-DOCX Converter.
Opens a cmd console window and runs converter.py inside it.
converter.py handles the 'Press Enter to close' prompt itself.
"""
import subprocess
import sys
from pathlib import Path

converter = Path(__file__).parent / "converter.py"
subprocess.run(
    ["cmd", "/c", f'python "{converter}"'],
    creationflags=subprocess.CREATE_NEW_CONSOLE,
)
```

- [ ] **Step 2: Create `create_shortcut.py`**

Create `create_shortcut.py` at the repo root:

```python
"""
Run once to create the desktop shortcut for MD-DOCX Converter.

Prerequisites:
    pip install pywin32

This script is a one-off utility; pywin32 is not a runtime dependency
of the converter itself.
"""
import sys
from pathlib import Path

try:
    import win32com.client
except ImportError:
    print("pywin32 not installed. Run: pip install pywin32")
    sys.exit(1)

desktop = Path.home() / "Desktop"
launch_pyw = (Path(__file__).parent / "md_docx_converter" / "launch.pyw").resolve()
python_exe = Path(sys.executable).with_name("pythonw.exe")

shell = win32com.client.Dispatch("WScript.Shell")
shortcut = shell.CreateShortCut(str(desktop / "MD-DOCX Converter.lnk"))
shortcut.TargetPath = str(python_exe)
shortcut.Arguments = f'"{launch_pyw}"'
shortcut.WorkingDirectory = str(launch_pyw.parent)
shortcut.Description = "Convert between Markdown and Word documents"
shortcut.save()

print(f"Shortcut created on Desktop: MD-DOCX Converter.lnk")
print(f"  Target: {python_exe}")
print(f"  Script: {launch_pyw}")
```

- [ ] **Step 3: Install pywin32 and create the shortcut**

```bash
pip install pywin32
python create_shortcut.py
```

Expected output:
```
Shortcut created on Desktop: MD-DOCX Converter.lnk
  Target: C:\Users\Chris\AppData\Local\Programs\Python\Python311\pythonw.exe
  Script: ...\md_docx_converter\launch.pyw
```

- [ ] **Step 4: Test the shortcut**

Double-click `MD-DOCX Converter` on the desktop. A console window should open with:
```
MD ↔ DOCX Converter
--------------------
Enter file path:
```

- [ ] **Step 5: Commit**

```bash
git add md_docx_converter/launch.pyw create_shortcut.py
git commit -m "feat: add desktop launcher and shortcut creator"
```

---

### Task 11: Round-trip integration tests

**Files:**
- Modify: `tests/test_converter.py`

**What it does:** End-to-end round-trip test — convert `tests/fixtures/simple.md` (created in Task 5) to DOCX, then convert that DOCX back to MD, and verify key content survives both directions.

- [ ] **Step 1: Write the round-trip tests**

Append to `tests/test_converter.py`:

```python
import tempfile
import pytest
from pathlib import Path
from md_docx_converter.md_to_docx import convert_md_to_docx
from md_docx_converter.docx_to_md import convert_docx_to_md

FIXTURES = Path(__file__).parent / "fixtures"
TEMPLATE = Path(r"C:\Users\Chris\AppData\Roaming\Microsoft\Templates\Normal.dotm")


def test_round_trip_headings_survive():
    if not TEMPLATE.exists():
        pytest.skip("Word template not found")
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        src_md = FIXTURES / "simple.md"
        mid_docx = tmp / "simple.docx"
        out_md = tmp / "simple_rt.md"

        convert_md_to_docx(src_md, mid_docx, TEMPLATE)
        convert_docx_to_md(mid_docx, out_md)

        result = out_md.read_text(encoding="utf-8")
        assert "# My Title" in result
        assert "## Section One" in result


def test_round_trip_table_survives():
    if not TEMPLATE.exists():
        pytest.skip("Word template not found")
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        src_md = FIXTURES / "simple.md"
        mid_docx = tmp / "simple.docx"
        out_md = tmp / "simple_rt.md"

        convert_md_to_docx(src_md, mid_docx, TEMPLATE)
        convert_docx_to_md(mid_docx, out_md)

        result = out_md.read_text(encoding="utf-8")
        assert "Col A" in result
        assert "One" in result


def test_round_trip_bold_survives():
    if not TEMPLATE.exists():
        pytest.skip("Word template not found")
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        src_md = FIXTURES / "simple.md"
        mid_docx = tmp / "simple.docx"
        out_md = tmp / "simple_rt.md"

        convert_md_to_docx(src_md, mid_docx, TEMPLATE)
        convert_docx_to_md(mid_docx, out_md)

        result = out_md.read_text(encoding="utf-8")
        assert "**bold**" in result
```

- [ ] **Step 2: Run the round-trip tests**

```bash
python -m pytest tests/test_converter.py -v
```

Expected: all PASSED (round-trip tests skip gracefully if template missing)

- [ ] **Step 3: Run the full test suite**

```bash
python -m pytest tests/ -v
```

Expected: all PASSED (some may skip if template not present — that is acceptable)

- [ ] **Step 4: Final commit**

```bash
git add tests/test_converter.py
git commit -m "test: add round-trip integration tests"
```
