# Markdown Syntax Reference — MD-DOCX Converter

This document defines the GitHub Flavored Markdown (GFM) elements supported by this tool, and how each element maps to/from Microsoft Word. It replaces the generic JetBrains Hub Markdown reference.

---

## Supported Elements

### Headings

```
# Heading 1
## Heading 2
### Heading 3
#### Heading 4
##### Heading 5
###### Heading 6
```

**Title rule (context-dependent):**
- If the document has exactly one `#`, it maps to Word's **Title** style. All other headings shift down by one (`##` → Heading 1, etc.)
- If the document has multiple `#` lines, they all map to **Heading 1**. No Title style is used.
- Reverse applies when converting DOCX → MD: a Word Title becomes `#`, shifting all headings up.

Alternative heading syntax (`===` and `---` underlines) is recognised on input but not used on output.

---

### Character Formatting

| Syntax | Renders as | Word style |
|---|---|---|
| `**bold**` or `__bold__` | **bold** | Bold |
| `*italic*` or `_italic_` | *italic* | Italic |
| `~~strikethrough~~` | ~~strikethrough~~ | Strikethrough |
| `` `inline code` `` | `inline code` | Monospaced (Courier New) |

**Combinations** are supported: `**bold and *italic***`

---

### Lists

Unordered list (use `-`, `*`, or `+`):
```
- First item
- Second item
  - Nested item (2-space indent)
```

Ordered list:
```
1. First item
2. Second item
```

Nested ordered lists are not supported — nesting uses unordered bullets only.

---

### Task Lists (GFM extension)

```
- [ ] Unchecked item
- [x] Checked item
```

Converts to/from bullet list items with `☐` / `☑` Unicode characters in Word. Checkbox state is preserved in both directions.

---

### Code

Inline code: `` `code` ``

Fenced code block:
````
```python
def hello():
    print("Hello, world!")
```
````

The language identifier (e.g. `python`) is preserved as a comment in the Word Code style paragraph but has no visual effect. Indented code blocks (4-space indent) are also recognised on input.

---

### Tables

```
| Column A | Column B | Column C |
| -------- | -------- | -------- |
| Cell 1   | Cell 2   | Cell 3   |
| Cell 4   | Cell 5   | Cell 6   |
```

- The separator row (`---`) defines the header row
- Alignment syntax (`:---`, `:---:`, `---:`) is recognised but not preserved in Word
- **Merged cells**: Word merged cells are unmerged on conversion — content is kept, structure is flattened
- **No header row**: Word tables without a header row get a blank header row inserted in Markdown output

---

### Blockquotes

```
> This is a blockquote.
> It can span multiple lines.
>
> Blank lines within a quote must start with >.
```

Nested quotes (`>>`) are supported on input; output uses a single `>` level with indentation.

---

### Thematic Breaks

Any of the following produce a horizontal rule in Word:
```
---
***
___
```

---

### Links

```
[link text](https://example.com)
[link with tooltip](https://example.com "Tooltip text")
```

Reference-style links are recognised on input and inlined on output:
```
[link text][ref]
[ref]: https://example.com
```

Autolinks (`<https://example.com>`) are also supported.

---

### Images

```
![alt text](image.png)
![alt text](subfolder/image.png)
```

- **MD → DOCX**: Images are resolved relative to the `.md` file's directory and embedded in the Word document. If the file is not found, `[image not found: path]` is inserted as text.
- **DOCX → MD**: Embedded images are extracted to `{document_name}_images/` in the same directory as the output `.md` file, named `image1.png`, `image2.png`, etc.
- URLs and absolute paths are not fetched — treated as not found.

---

### Backslash Escapes

Prepend `\` to use a Markdown special character literally:

```
\*not italic\*
\# not a heading
\| not a table delimiter
```

---

## Lossy Conversions

These Word elements have no direct Markdown equivalent and are approximated:

| Word formatting | Markdown output |
|---|---|
| Underline | `**bold**` |
| Highlight | `**bold**` |
| Small caps | `**bold**` |
| Font size change (relative to body) | `**bold**` |
| Font colour | Stripped — text content kept, colour lost |

---

## Unsupported / Dropped Elements

These are silently dropped during conversion:

- LaTeX / math equations
- Footnotes and endnotes
- Raw HTML passthrough
- Word text boxes
- Word tracked changes and comments
- Nested tables (inner table content is lost)
- Absolute URL images (not fetched)
- Table cell colours, borders, and column widths
- Table cell merging (content kept, merge structure lost)

---

## Round-Trip Notes

Converting MD → DOCX → MD or DOCX → MD → DOCX will not produce identical output. Expected differences:

- Heading levels may shift if the Title rule applies differently on re-import
- Table alignment is lost after the first conversion
- Code block language identifiers survive MD→DOCX but are stored as plain text comments, not as structured data
- Image filenames will be renamed (`image1.png`, `image2.png`, etc.) on DOCX→MD extraction
- Word-specific formatting (underline, highlight) becomes bold and cannot be reversed
