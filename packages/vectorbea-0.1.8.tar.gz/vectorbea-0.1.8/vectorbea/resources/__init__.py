from vectorbea.resources.prompts import Prompts

__all__ = ["Prompts"]
