#!/usr/bin/env python3
"""
Zeq OS — Molecular Dynamics Simulator Time-Modulation Sibling
Wraps zeq_md_simulator with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to energy values and trajectories via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import csv
import json
import math
import random
import sys
import time

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING


class MDSimulatorTM:
    """Molecular Dynamics Simulator with Time-Modulation."""
    
    def __init__(self, num_particles=10, dt=0.01, temperature=300, potential="lennard_jones"):
        self.num_particles = num_particles
        self.dt = dt
        self.temperature = temperature
        self.potential = potential
        
        # Initialize positions and velocities
        random.seed(42)
        self.positions = [[random.uniform(-5, 5) for _ in range(3)] for _ in range(num_particles)]
        self.velocities = [[random.uniform(-0.1, 0.1) for _ in range(3)] for _ in range(num_particles)]
        self.accelerations = [[0, 0, 0] for _ in range(num_particles)]
        
        self.energies = []
        self.trajectory = []
        self.kinetic_energies = []
        self.potential_energies = []
    
    def compute_forces(self):
        """Compute forces between particles."""
        for i in range(self.num_particles):
            self.accelerations[i] = [0, 0, 0]
        
        for i in range(self.num_particles):
            for j in range(i + 1, self.num_particles):
                dx = self.positions[j][0] - self.positions[i][0]
                dy = self.positions[j][1] - self.positions[i][1]
                dz = self.positions[j][2] - self.positions[i][2]
                r_sq = dx*dx + dy*dy + dz*dz
                r = math.sqrt(r_sq)
                
                if r < 0.1:
                    r = 0.1
                
                if self.potential == "lennard_jones":
                    # LJ: F = -dU/dr where U = 4ε[(σ/r)^12 - (σ/r)^6]
                    sigma = 1.0
                    epsilon = 1.0
                    s6 = (sigma / r) ** 6
                    force = 24 * epsilon * (2 * s6 * s6 - s6) / r
                else:  # harmonic
                    force = -100 * r
                
                fx = force * dx / r
                fy = force * dy / r
                fz = force * dz / r
                
                self.accelerations[i][0] += fx
                self.accelerations[i][1] += fy
                self.accelerations[i][2] += fz
                self.accelerations[j][0] -= fx
                self.accelerations[j][1] -= fy
                self.accelerations[j][2] -= fz
    
    def compute_energy(self):
        """Compute kinetic and potential energy."""
        ke = 0
        pe = 0
        
        for i in range(self.num_particles):
            v_sq = sum(v*v for v in self.velocities[i])
            ke += 0.5 * v_sq
        
        for i in range(self.num_particles):
            for j in range(i + 1, self.num_particles):
                dx = self.positions[j][0] - self.positions[i][0]
                dy = self.positions[j][1] - self.positions[i][1]
                dz = self.positions[j][2] - self.positions[i][2]
                r_sq = dx*dx + dy*dy + dz*dz
                r = math.sqrt(r_sq)
                
                if self.potential == "lennard_jones":
                    sigma = 1.0
                    epsilon = 1.0
                    s6 = (sigma / r) ** 6
                    pe += 4 * epsilon * (s6*s6 - s6)
                else:
                    pe += 50 * r_sq
        
        return ke, pe
    
    def velocity_verlet_step(self):
        """Perform one Velocity Verlet integration step."""
        # Update positions
        for i in range(self.num_particles):
            for d in range(3):
                self.positions[i][d] += self.velocities[i][d] * self.dt + 0.5 * self.accelerations[i][d] * self.dt * self.dt
        
        # Store old accelerations
        old_acc = [list(a) for a in self.accelerations]
        
        # Compute new forces/accelerations
        self.compute_forces()
        
        # Update velocities
        for i in range(self.num_particles):
            for d in range(3):
                self.velocities[i][d] += 0.5 * (old_acc[i][d] + self.accelerations[i][d]) * self.dt
        
        # Compute energy
        ke, pe = self.compute_energy()
        self.kinetic_energies.append(ke)
        self.potential_energies.append(pe)
        self.energies.append(ke + pe)
    
    def run(self, num_steps):
        """Run simulation for num_steps."""
        for step in range(num_steps):
            self.velocity_verlet_step()
            self.trajectory.append([list(p) for p in self.positions])
    
    def get_energy_data(self):
        """Return energy data as list of dicts."""
        return [
            {
                "step": i,
                "kinetic": self.kinetic_energies[i],
                "potential": self.potential_energies[i],
                "total": self.energies[i]
            }
            for i in range(len(self.energies))
        ]


def apply_time_modulation(values, zeq_client, domain="classical-mechanics", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to energy values via Zeq API."""
    modulated = []
    current_time = time.time()
    
    for val in values:
        try:
            cko = zeq_client.compute(
                operators=["KO42"],
                values={"energy_eV": abs(val) if val != 0 else 0.1},
                domain=domain
            )
            zeq_state = cko.get("zeqState", {})
            r_t = zeq_state.get("masterSum", val)
            phase = zeq_state.get("phase", 0.0)
            zeqond = zeq_state.get("zeqond", 0)
            proof = cko.get("zeqProof", "")
            
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": r_t,
                "phase": phase,
                "zeqond": zeqond,
                "proof": proof,
                "modulation_factor": modulation_factor
            })
        except Exception as e:
            print(f"[Zeq OS] Warning: API modulation failed: {e}", file=sys.stderr)
            phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": val,
                "phase": phase,
                "zeqond": int(current_time / ZEQOND_SEC),
                "proof": "",
                "modulation_factor": modulation_factor
            })
    
    return modulated


def main():
    parser = argparse.ArgumentParser(description="Zeq OS Molecular Dynamics Time-Modulation Sibling")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--num_particles", type=int, default=10, help="Number of particles (default 10)")
    parser.add_argument("--num_steps", type=int, default=100, help="Number of simulation steps (default 100)")
    parser.add_argument("--dt", type=float, default=0.01, help="Time step (default 0.01)")
    parser.add_argument("--potential", choices=["lennard_jones", "harmonic"], default="lennard_jones",
                        help="Potential energy model")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond steps for temporal projection (default 16)")
    parser.add_argument("--output_energy", default=None, help="Output CSV for energy trajectory")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    print(f"[Zeq OS] Initializing MD simulator: {args.num_particles} particles, {args.potential} potential",
          file=sys.stderr)
    
    # Create and run simulator
    sim = MDSimulatorTM(
        num_particles=args.num_particles,
        dt=args.dt,
        potential=args.potential
    )
    
    print(f"[Zeq OS] Running {args.num_steps} MD steps...", file=sys.stderr)
    sim.run(args.num_steps)
    print(f"[Zeq OS] MD simulation complete", file=sys.stderr)

    results = {
        "num_particles": args.num_particles,
        "num_steps": args.num_steps,
        "dt": args.dt,
        "potential": args.potential,
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_s": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Get energy data
    energy_data = sim.get_energy_data()
    total_energies = [e["total"] for e in energy_data]
    ke_energies = [e["kinetic"] for e in energy_data]
    pe_energies = [e["potential"] for e in energy_data]

    # Apply time modulation
    print(f"[Zeq OS] Applying HulyaPulse modulation to energy values...", file=sys.stderr)
    mod_total = apply_time_modulation(total_energies, client, domain="classical-mechanics", tm_steps=args.tm_steps)
    mod_ke = apply_time_modulation(ke_energies, client, domain="classical-mechanics", tm_steps=args.tm_steps)
    mod_pe = apply_time_modulation(pe_energies, client, domain="classical-mechanics", tm_steps=args.tm_steps)

    # Add modulated values to energy data
    for i, e in enumerate(energy_data):
        e["total_tm"] = mod_total[i]
        e["kinetic_tm"] = mod_ke[i]
        e["potential_tm"] = mod_pe[i]

    results["energy_data"] = energy_data

    # Output energy trajectory
    if args.output_energy:
        with open(args.output_energy, "w", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["step", "kinetic", "potential", "total",
                            "kinetic_tm", "potential_tm", "total_tm",
                            "R_t_total", "phase_total", "zeqond_total"])
            for e in energy_data:
                writer.writerow([
                    e["step"],
                    f"{e['kinetic']:.6f}",
                    f"{e['potential']:.6f}",
                    f"{e['total']:.6f}",
                    f"{e['kinetic_tm']['modulated']:.6f}",
                    f"{e['potential_tm']['modulated']:.6f}",
                    f"{e['total_tm']['modulated']:.6f}",
                    f"{e['total_tm']['R_t']:.6f}",
                    f"{e['total_tm']['phase']:.6f}",
                    e['total_tm']['zeqond']
                ])

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output (keep energy data size reasonable)
    if args.output_json:
        export_results = results.copy()
        # Only export first/last energies to keep JSON reasonable
        if energy_data:
            export_results["energy_data"] = energy_data[:5] + (energy_data[-5:] if len(energy_data) > 10 else [])
        
        with open(args.output_json, "w") as f:
            json.dump(export_results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete", file=sys.stderr)


if __name__ == "__main__":
    main()
