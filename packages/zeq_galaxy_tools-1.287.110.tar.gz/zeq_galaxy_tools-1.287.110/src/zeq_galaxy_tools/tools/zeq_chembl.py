#!/usr/bin/env python3
"""
================================================================================
Zeq OS ChEMBL Bioactivity Data Fetcher
================================================================================
ZeqSystem: HULYAS-CHEMBL-1.287.5
HulyaPulse Frequency: 1.287 Hz
Zeqond Duration: 0.777 seconds
KO42 Metric Tensioner Prime Directive: ACTIVE
Phase Lock: SYNCHRONIZED via Zeq API
================================================================================
Tool for fetching and processing ChEMBL bioactivity data via REST API.
Supports molecule lookup, activity data extraction, and statistical analysis.
All HulyaPulse modulation and CKO envelope generation routed through Zeq API.
Output formats: Tab-delimited TSV and JSON.

Full source code (open, not a black box):
  https://github.com/hulyasmath/zeq-hulyas-framework-v1287-python

Paper DOI: https://doi.org/10.5281/zenodo.18158152
Framework DOI: https://doi.org/10.5281/zenodo.15825138
SDK: https://sdk.1.287hz.com/

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
================================================================================
"""

import urllib.request
import urllib.parse
import json
import csv
import math
import time
import argparse
import sys
from typing import Dict, List, Optional, Tuple

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC

# Zeq OS Constants
API_BASE_URL = "https://www.ebi.ac.uk/chembl/api/data"
API_TIMEOUT = 30  # seconds

class ChEMBLFetcher:
    """Zeq OS wrapper for ChEMBL REST API queries."""

    def __init__(self):
        pass

    def _fetch_json(self, url: str) -> Optional[Dict]:
        """Fetch JSON from URL with error handling."""
        try:
            req = urllib.request.Request(url)
            req.add_header('User-Agent', 'Zeq-OS/1.287.5 (ChEMBL-Fetcher)')
            with urllib.request.urlopen(req, timeout=API_TIMEOUT) as response:
                return json.loads(response.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            print(f"HTTP Error {e.code}: {e.reason}", file=sys.stderr)
            return None
        except urllib.error.URLError as e:
            print(f"URL Error: {e.reason}", file=sys.stderr)
            return None
        except json.JSONDecodeError as e:
            print(f"JSON Decode Error: {e}", file=sys.stderr)
            return None
        except Exception as e:
            print(f"Error fetching {url}: {e}", file=sys.stderr)
            return None

    def resolve_molecule_name(self, molecule_name: str) -> Optional[str]:
        """
        Resolve molecule name to ChEMBL ID.
        Returns the ChEMBL ID (e.g., 'CHEMBL25') or None if not found.
        """
        print(f"[Zeq OS] Resolving molecule name: {molecule_name}", file=sys.stderr)

        # Check if already a ChEMBL ID
        if molecule_name.startswith('CHEMBL'):
            print(f"[Zeq OS] Input is already a ChEMBL ID: {molecule_name}", file=sys.stderr)
            return molecule_name

        search_url = f"{API_BASE_URL}/molecule/search.json?q={urllib.parse.quote(molecule_name)}"
        data = self._fetch_json(search_url)

        if not data or 'molecules' not in data or len(data['molecules']) == 0:
            print(f"[Zeq OS] ERROR: Molecule not found: {molecule_name}", file=sys.stderr)
            return None

        # Return the ChEMBL ID of the first match
        chembl_id = data['molecules'][0].get('molecule_chembl_id')
        if chembl_id:
            print(f"[Zeq OS] Resolved to ChEMBL ID: {chembl_id}", file=sys.stderr)
        return chembl_id

    def fetch_molecule_data(self, chembl_id: str) -> Optional[Dict]:
        """Fetch molecule data from ChEMBL."""
        print(f"[Zeq OS] Fetching molecule data for {chembl_id}", file=sys.stderr)
        mol_url = f"{API_BASE_URL}/molecule/{chembl_id}.json"
        return self._fetch_json(mol_url)

    def fetch_activities(self, chembl_id: str, limit: int = 100) -> Optional[List[Dict]]:
        """Fetch bioactivity data for a molecule."""
        print(f"[Zeq OS] Fetching activities for {chembl_id} (limit={limit})", file=sys.stderr)

        activities_url = f"{API_BASE_URL}/activity.json?molecule_chembl_id={chembl_id}&limit={limit}"
        data = self._fetch_json(activities_url)

        if not data or 'activities' not in data:
            print(f"[Zeq OS] WARNING: No activities found for {chembl_id}", file=sys.stderr)
            return []

        return data['activities']

    def fetch_target_data(self, target_chembl_id: str) -> Optional[Dict]:
        """Fetch target data from ChEMBL."""
        print(f"[Zeq OS] Fetching target data for {target_chembl_id}", file=sys.stderr)
        target_url = f"{API_BASE_URL}/target/{target_chembl_id}.json"
        return self._fetch_json(target_url)


def compute_statistics(activities: List[Dict], client) -> Dict:
    """Compute statistical summaries from activity data, with Zeq API modulation."""
    stats = {
        'activity_count': len(activities),
        'unique_targets': set(),
        'assay_types': {},
        'standard_types': {},
        'pchembl_values': []
    }

    for activity in activities:
        # Track unique targets
        if 'target_chembl_id' in activity:
            stats['unique_targets'].add(activity['target_chembl_id'])

        # Count assay types
        assay_type = activity.get('assay_type', 'Unknown')
        stats['assay_types'][assay_type] = stats['assay_types'].get(assay_type, 0) + 1

        # Count standard types
        std_type = activity.get('standard_type', 'Unknown')
        stats['standard_types'][std_type] = stats['standard_types'].get(std_type, 0) + 1

        # Collect pChEMBL values
        if 'pchembl_value' in activity and activity['pchembl_value'] is not None:
            try:
                stats['pchembl_values'].append(float(activity['pchembl_value']))
            except (ValueError, TypeError):
                pass

    # Convert set to count
    stats['unique_targets_count'] = len(stats['unique_targets'])
    stats['unique_targets'] = list(stats['unique_targets'])

    # Calculate average pChEMBL
    if stats['pchembl_values']:
        stats['avg_pchembl'] = sum(stats['pchembl_values']) / len(stats['pchembl_values'])
    else:
        stats['avg_pchembl'] = None

    return stats


def write_activities_tsv(activities: List[Dict], output_file: str) -> None:
    """Write activities to tab-delimited file."""
    if not activities:
        print(f"[Zeq OS] WARNING: No activities to write to {output_file}", file=sys.stderr)
        return

    # Define columns to extract
    fieldnames = [
        'activity_id',
        'molecule_chembl_id',
        'target_chembl_id',
        'assay_type',
        'assay_chembl_id',
        'target_organism',
        'standard_type',
        'standard_value',
        'standard_units',
        'pchembl_value',
        'activity_comment'
    ]

    try:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, delimiter='\t',
                                   restval='', extrasaction='ignore')
            writer.writeheader()
            writer.writerows(activities)
        print(f"[Zeq OS] Wrote {len(activities)} activities to {output_file}", file=sys.stderr)
    except Exception as e:
        print(f"[Zeq OS] ERROR: Failed to write activities TSV: {e}", file=sys.stderr)


def write_molecule_tsv(molecule_data: Dict, stats: Dict, output_file: str) -> None:
    """Write molecule summary to tab-delimited file."""
    try:
        with open(output_file, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f, delimiter='\t')
            writer.writerow(['Field', 'Value'])

            # Basic molecule info
            mol_props = molecule_data.get('molecule_properties', {}) or {}
            mol_structs = molecule_data.get('molecule_structures', {}) or {}
            writer.writerow(['ChEMBL ID', molecule_data.get('molecule_chembl_id', 'N/A')])
            writer.writerow(['Preferred Name', molecule_data.get('pref_name', 'N/A')])
            writer.writerow(['Molecular Formula', mol_props.get('full_molformula', 'N/A')])
            writer.writerow(['Molecular Weight', mol_props.get('full_mwt', 'N/A')])
            writer.writerow(['InChI', (mol_structs.get('standard_inchi', 'N/A') or 'N/A')[:80]])

            writer.writerow(['', ''])
            writer.writerow(['Statistics', ''])
            writer.writerow(['Total Activities', stats['activity_count']])
            writer.writerow(['Unique Targets', stats['unique_targets_count']])
            writer.writerow(['Average pChEMBL', f"{stats['avg_pchembl']:.2f}" if stats['avg_pchembl'] else 'N/A'])

            writer.writerow(['', ''])
            writer.writerow(['Assay Type Distribution', ''])
            for assay_type, count in sorted(stats['assay_types'].items(), key=lambda x: -x[1]):
                writer.writerow([f"  {assay_type}", count])

            writer.writerow(['', ''])
            writer.writerow(['Standard Type Distribution', ''])
            for std_type, count in sorted(stats['standard_types'].items(), key=lambda x: -x[1]):
                writer.writerow([f"  {std_type}", count])

        print(f"[Zeq OS] Wrote molecule summary to {output_file}", file=sys.stderr)
    except Exception as e:
        print(f"[Zeq OS] ERROR: Failed to write molecule TSV: {e}", file=sys.stderr)


def write_json_output(molecule_data: Dict, activities: List[Dict], stats: Dict,
                      output_file: str, cko_envelope: Dict) -> None:
    """Write comprehensive JSON output with CKO envelope."""
    output = {
        'zeq_metadata': {
            'tool': 'zeq_chembl',
            'version': '1.287.5',
            'hulyapulse_freq': HULYAPULSE_HZ,
            'zeqond': ZEQOND_SEC,
            'timestamp': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        },
        'molecule': molecule_data,
        'statistics': {
            'activity_count': stats['activity_count'],
            'unique_targets': stats['unique_targets_count'],
            'unique_targets_list': stats['unique_targets'],
            'assay_type_distribution': stats['assay_types'],
            'standard_type_distribution': stats['standard_types'],
            'avg_pchembl': stats['avg_pchembl']
        },
        'activities': activities,
        'cko_envelope': cko_envelope
    }

    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2)
        print(f"[Zeq OS] Wrote JSON output to {output_file}", file=sys.stderr)
    except Exception as e:
        print(f"[Zeq OS] ERROR: Failed to write JSON output: {e}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser(
        description='Zeq OS ChEMBL Bioactivity Data Fetcher (v1.287.5)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  %(prog)s --zeq_api_key zeq_ak_... --molecule aspirin --mode all
  %(prog)s --zeq_api_key zeq_ak_... --molecule CHEMBL25 --mode activities --limit 50
  %(prog)s --zeq_api_key zeq_ak_... --molecule ibuprofen --mode molecule --hulyapulse
        '''
    )

    parser.add_argument('--zeq_api_key', type=str, required=True,
                       help='Zeq API key (REQUIRED). Get your key at https://www.zeq.dev/dashboard')
    parser.add_argument('--molecule', type=str, required=True,
                       help='Molecule name or ChEMBL ID (e.g., "aspirin" or "CHEMBL25")')
    parser.add_argument('--mode', type=str, choices=['activities', 'molecule', 'target', 'all'],
                       default='all', help='Data to fetch (default: all)')
    parser.add_argument('--limit', type=int, default=100,
                       help='Maximum number of activities to fetch (default: 100)')
    parser.add_argument('--output_activities', type=str, default='activities.tsv',
                       help='Output TSV file for activities (default: activities.tsv)')
    parser.add_argument('--output_molecule', type=str, default='molecule.tsv',
                       help='Output TSV file for molecule summary (default: molecule.tsv)')
    parser.add_argument('--output_json', type=str, default='output.json',
                       help='Output JSON file (default: output.json)')
    parser.add_argument('--hulyapulse', action='store_true',
                       help='Enable HulyaPulse 1.287 Hz modulation via Zeq API')

    args = parser.parse_args()

    print("[Zeq OS] Zeq OS ChEMBL Bioactivity Fetcher v1.287.5", file=sys.stderr)
    print(f"[Zeq OS] HulyaPulse: {'ENABLED' if args.hulyapulse else 'DISABLED'}", file=sys.stderr)

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    # Initialize fetcher
    fetcher = ChEMBLFetcher()

    # Resolve molecule name to ChEMBL ID
    chembl_id = fetcher.resolve_molecule_name(args.molecule)
    if not chembl_id:
        print("[Zeq OS] ERROR: Could not resolve molecule name", file=sys.stderr)
        sys.exit(1)

    # Initialize output structures
    molecule_data = {}
    activities = []
    stats = {
        'activity_count': 0,
        'unique_targets': [],
        'unique_targets_count': 0,
        'assay_types': {},
        'standard_types': {},
        'avg_pchembl': None
    }

    # Fetch based on mode
    if args.mode in ['molecule', 'all']:
        mol_data = fetcher.fetch_molecule_data(chembl_id)
        if mol_data:
            molecule_data = mol_data

    if args.mode in ['activities', 'all']:
        activities = fetcher.fetch_activities(chembl_id, limit=args.limit)
        if activities:
            stats = compute_statistics(activities, client)

    # Apply HulyaPulse modulation via Zeq API if enabled
    if args.hulyapulse and activities:
        pchembl_values = stats.get('pchembl_values', [])
        if pchembl_values:
            modulated_values, result = client.modulate_values(pchembl_values)
            print(f"[Zeq OS] HulyaPulse modulation applied via Zeq API", file=sys.stderr)

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()

    # Write outputs based on mode
    if args.mode in ['molecule', 'all']:
        write_molecule_tsv(molecule_data, stats, args.output_molecule)

    if args.mode in ['activities', 'all']:
        write_activities_tsv(activities, args.output_activities)

    if args.output_json:
        write_json_output(molecule_data, activities, stats, args.output_json, cko_envelope)

    # Daemon tick
    client.daemon_tick()

    print("[Zeq OS] Zeq OS ChEMBL Fetcher completed successfully", file=sys.stderr)


if __name__ == '__main__':
    main()
