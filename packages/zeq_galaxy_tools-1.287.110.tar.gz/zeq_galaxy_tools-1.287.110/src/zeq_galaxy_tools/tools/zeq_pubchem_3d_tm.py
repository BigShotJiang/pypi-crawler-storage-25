#!/usr/bin/env python3
"""
Zeq OS — PubChem 3D Molecular Time-Modulation Sibling
Wraps zeq_pubchem_3d with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to all numerical outputs via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import csv
import json
import math
import sys
import time
import urllib.parse
import urllib.request

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING

PUBCHEM_BASE = "https://pubchem.ncbi.nlm.nih.gov/rest/pug"


def resolve_cid(molecule_name):
    """Resolve a molecule name to a PubChem CID."""
    try:
        url = f"{PUBCHEM_BASE}/compound/name/{urllib.parse.quote(molecule_name)}/cids/JSON"
        with urllib.request.urlopen(url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
            return data["IdentifierList"]["CID"][0]
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not resolve molecule '{molecule_name}': {e}", file=sys.stderr)
        sys.exit(1)


def fetch_3d_conformer(cid):
    """Fetch 3D conformer data for a CID."""
    url = f"{PUBCHEM_BASE}/compound/cid/{cid}/JSON?record_type=3d"
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch 3D data for CID {cid}: {e}", file=sys.stderr)
        sys.exit(1)


def fetch_properties(cid):
    """Fetch molecular properties for a CID."""
    props = "MolecularWeight,XLogP,HBondDonorCount,HBondAcceptorCount,TPSA,Complexity,HeavyAtomCount,RotatableBondCount,MolecularFormula,IsomericSMILES"
    url = f"{PUBCHEM_BASE}/compound/cid/{cid}/property/{props}/JSON"
    try:
        with urllib.request.urlopen(url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
            return data["PropertyTable"]["Properties"][0]
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch properties for CID {cid}: {e}", file=sys.stderr)
        sys.exit(1)


def compute_bond_lengths(compound):
    """Compute 3D bond lengths from conformer data."""
    coords = compound["coords"][0]["conformers"][0]
    bonds = compound.get("bonds", {})
    xs, ys, zs = coords["x"], coords["y"], coords["z"]

    bond_lengths = []
    if bonds and "aid1" in bonds:
        for i in range(len(bonds["aid1"])):
            a1 = bonds["aid1"][i] - 1
            a2 = bonds["aid2"][i] - 1
            dx = xs[a1] - xs[a2]
            dy = ys[a1] - ys[a2]
            dz = zs[a1] - zs[a2]
            bond_lengths.append({
                "atom1": a1 + 1,
                "atom2": a2 + 1,
                "element1": compound["atoms"]["element"][a1],
                "element2": compound["atoms"]["element"][a2],
                "length_angstrom": math.sqrt(dx*dx + dy*dy + dz*dz),
                "bond_order": bonds.get("order", [1]*len(bonds["aid1"]))[i] if "order" in bonds else 1
            })
    return bond_lengths


def compute_atomic_distances(compound):
    """Compute distances of each atom from the molecular centroid."""
    coords = compound["coords"][0]["conformers"][0]
    xs, ys, zs = coords["x"], coords["y"], coords["z"]
    n = len(xs)

    cx = sum(xs) / n
    cy = sum(ys) / n
    cz = sum(zs) / n

    distances = []
    for i in range(n):
        dx = xs[i] - cx
        dy = ys[i] - cy
        dz = zs[i] - cz
        distances.append({
            "atom_index": i + 1,
            "element": compound["atoms"]["element"][i],
            "x": xs[i],
            "y": ys[i],
            "z": zs[i],
            "distance_from_centroid": math.sqrt(dx*dx + dy*dy + dz*dz)
        })
    return distances, (cx, cy, cz)


ELEMENT_SYMBOLS = {
    1: "H", 2: "He", 3: "Li", 4: "Be", 5: "B", 6: "C", 7: "N", 8: "O",
    9: "F", 10: "Ne", 11: "Na", 12: "Mg", 13: "Al", 14: "Si", 15: "P",
    16: "S", 17: "Cl", 18: "Ar", 19: "K", 20: "Ca", 26: "Fe", 29: "Cu",
    30: "Zn", 35: "Br", 53: "I"
}


def element_symbol(num):
    return ELEMENT_SYMBOLS.get(num, f"#{num}")


def apply_time_modulation(values, zeq_client, domain="molecular", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to numerical values via Zeq API."""
    modulated = []
    current_time = time.time()
    
    for val in values:
        try:
            # Call Zeq API /compute with this value
            cko = zeq_client.compute(
                operators=["KO42"],
                values={"value": val, "energy_eV": abs(val) if val != 0 else 1.0},
                domain=domain
            )
            zeq_state = cko.get("zeqState", {})
            r_t = zeq_state.get("masterSum", val)
            phase = zeq_state.get("phase", 0.0)
            zeqond = zeq_state.get("zeqond", 0)
            proof = cko.get("zeqProof", "")
            
            # Apply R(t) modulation formula
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": r_t,
                "phase": phase,
                "zeqond": zeqond,
                "proof": proof,
                "modulation_factor": modulation_factor
            })
        except Exception as e:
            print(f"[Zeq OS] Warning: API modulation failed for value {val}: {e}", file=sys.stderr)
            # Fallback to local modulation
            phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": val,
                "phase": phase,
                "zeqond": int(current_time / ZEQOND_SEC),
                "proof": "",
                "modulation_factor": modulation_factor
            })
    
    return modulated


def generate_time_series(values, zeq_client, domain="molecular", tm_steps=16):
    """Generate time-series projection using zeq_shift."""
    time_series = []
    current_time = time.time()
    
    try:
        # For each value, compute forward projection
        for val in values:
            try:
                # Call zeq_shift equivalent through compute with multiple steps
                projections = []
                for step in range(tm_steps):
                    step_time = current_time + (step * ZEQOND_SEC)
                    cko = zeq_client.compute(
                        operators=["KO42"],
                        values={"value": val, "t": step_time},
                        domain=domain
                    )
                    zeq_state = cko.get("zeqState", {})
                    r_t = zeq_state.get("masterSum", val)
                    phase = zeq_state.get("phase", 0.0)
                    zeqond = zeq_state.get("zeqond", step)
                    
                    phase_mod = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * step_time + phase)
                    projections.append({
                        "zeqond": zeqond,
                        "t": step_time,
                        "phase": phase,
                        "R_t": r_t,
                        "modulated": val * phase_mod,
                        "delta": val * phase_mod - val if step == 0 else None
                    })
                time_series.append({
                    "original_value": val,
                    "projections": projections
                })
            except Exception as e:
                print(f"[Zeq OS] Warning: Time-series generation failed for value {val}: {e}", file=sys.stderr)
    except Exception as e:
        print(f"[Zeq OS] Warning: Time-series API call failed: {e}", file=sys.stderr)
    
    return time_series


def main():
    parser = argparse.ArgumentParser(description="Zeq OS PubChem 3D Time-Modulation Sibling")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--molecule", required=True, help="Molecule name (e.g., caffeine, aspirin)")
    parser.add_argument("--mode", choices=["bonds", "atoms", "properties", "all"], default="all",
                        help="Analysis mode: bonds, atoms, properties, or all")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_bonds", default=None, help="Output CSV for bond lengths")
    parser.add_argument("--output_atoms", default=None, help="Output CSV for atomic distances")
    parser.add_argument("--output_properties", default=None, help="Output CSV for properties")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")
    parser.add_argument("--output_timeseries", default=None, help="Output CSV for time-series")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    print(f"[Zeq OS] Resolving molecule: {args.molecule}", file=sys.stderr)
    cid = resolve_cid(args.molecule)
    print(f"[Zeq OS] Resolved to PubChem CID: {cid}", file=sys.stderr)

    results = {
        "molecule": args.molecule,
        "cid": cid,
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_s": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Fetch 3D conformer if needed
    if args.mode in ("bonds", "atoms", "all"):
        print(f"[Zeq OS] Fetching 3D conformer for CID {cid}...", file=sys.stderr)
        conf_data = fetch_3d_conformer(cid)
        compound = conf_data["PC_Compounds"][0]
        num_atoms = len(compound["atoms"]["element"])
        print(f"[Zeq OS] 3D conformer loaded: {num_atoms} atoms", file=sys.stderr)

    # Bond lengths with time modulation
    if args.mode in ("bonds", "all"):
        bond_lengths = compute_bond_lengths(compound)
        print(f"[Zeq OS] Computed {len(bond_lengths)} bond lengths", file=sys.stderr)

        raw_lengths = [b["length_angstrom"] for b in bond_lengths]
        mod_lengths = apply_time_modulation(raw_lengths, client, domain="molecular", tm_steps=args.tm_steps)
        
        for i, b in enumerate(bond_lengths):
            b["length_tm"] = mod_lengths[i]

        results["bond_lengths"] = bond_lengths

        if args.output_bonds:
            with open(args.output_bonds, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                header = ["atom1", "atom2", "element1", "element2", "bond_order", "length_angstrom",
                          "length_tm_modulated", "R_t", "phase", "zeqond"]
                writer.writerow(header)
                for b in bond_lengths:
                    mod = b["length_tm"]
                    row = [b["atom1"], b["atom2"], element_symbol(b["element1"]),
                           element_symbol(b["element2"]), b["bond_order"],
                           f"{b['length_angstrom']:.6f}",
                           f"{mod['modulated']:.6f}",
                           f"{mod['R_t']:.6f}",
                           f"{mod['phase']:.6f}",
                           mod['zeqond']]
                    writer.writerow(row)

    # Atomic distances with time modulation
    if args.mode in ("atoms", "all"):
        distances, centroid = compute_atomic_distances(compound)
        print(f"[Zeq OS] Computed {len(distances)} atomic distances", file=sys.stderr)

        raw_distances = [d["distance_from_centroid"] for d in distances]
        mod_distances = apply_time_modulation(raw_distances, client, domain="molecular", tm_steps=args.tm_steps)
        
        for i, d in enumerate(distances):
            d["distance_tm"] = mod_distances[i]

        results["atomic_distances"] = distances
        results["centroid"] = {"x": centroid[0], "y": centroid[1], "z": centroid[2]}

        if args.output_atoms:
            with open(args.output_atoms, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                header = ["atom_index", "element", "x", "y", "z", "distance_from_centroid",
                          "distance_tm_modulated", "R_t", "phase", "zeqond"]
                writer.writerow(header)
                for d in distances:
                    mod = d["distance_tm"]
                    row = [d["atom_index"], element_symbol(d["element"]),
                           f"{d['x']:.6f}", f"{d['y']:.6f}", f"{d['z']:.6f}",
                           f"{d['distance_from_centroid']:.6f}",
                           f"{mod['modulated']:.6f}",
                           f"{mod['R_t']:.6f}",
                           f"{mod['phase']:.6f}",
                           mod['zeqond']]
                    writer.writerow(row)

    # Properties with time modulation
    if args.mode in ("properties", "all"):
        print(f"[Zeq OS] Fetching molecular properties for CID {cid}...", file=sys.stderr)
        props = fetch_properties(cid)
        results["properties"] = props
        print(f"[Zeq OS] MW={props.get('MolecularWeight')}", file=sys.stderr)

        if args.output_properties:
            with open(args.output_properties, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["property", "value"])
                for k, v in props.items():
                    writer.writerow([k, v])

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    # Time-series output
    if args.output_timeseries and args.mode in ("bonds", "all"):
        bond_vals = [b["length_angstrom"] for b in bond_lengths]
        ts_data = generate_time_series(bond_vals, client, domain="molecular", tm_steps=args.tm_steps)
        
        with open(args.output_timeseries, "w", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["original_value", "zeqond", "time", "phase", "R_t", "modulated"])
            for ts in ts_data:
                for proj in ts["projections"]:
                    writer.writerow([
                        f"{ts['original_value']:.6f}",
                        proj["zeqond"],
                        f"{proj['t']:.3f}",
                        f"{proj['phase']:.6f}",
                        f"{proj['R_t']:.6f}",
                        f"{proj['modulated']:.6f}"
                    ])

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for {args.molecule} (CID {cid})", file=sys.stderr)


if __name__ == "__main__":
    main()
