#!/usr/bin/env python3
"""
Zeq OS Molecular Dynamics Simulator
Implements Velocity Verlet integration with multiple potential energy models.
All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Full source code (open, not a black box):
  https://github.com/hulyasmath/zeq-hulyas-framework-v1287-python

Paper DOI: https://doi.org/10.5281/zenodo.18158152
Framework DOI: https://doi.org/10.5281/zenodo.15825138
SDK: https://sdk.1.287hz.com/

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import csv
import json
import math
import random
import sys
import time

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC


class MDSimulator:
    """Molecular Dynamics Simulator with Velocity Verlet integration."""

    def __init__(self, num_particles, box_size, temperature, timestep, potential):
        self.num_particles = num_particles
        self.box_size = box_size
        self.temperature = temperature
        self.timestep = timestep
        self.potential_type = potential

        # Boltzmann constant (simplified units)
        self.boltzmann = 1.0

        # Potential parameters
        self.lennard_jones_epsilon = 0.01
        self.lennard_jones_sigma = 3.4
        self.morse_D = 0.1
        self.morse_a = 1.0
        self.morse_r0 = 3.0
        self.coulomb_k = 1.0

        # Initialize particles on a grid
        self.positions = []
        self.velocities = []
        self.forces = []

        self._init_particles()

    def _init_particles(self):
        """Initialize particles on a grid with random velocities scaled to temperature."""
        grid_size = math.ceil(self.num_particles ** (1.0 / 3.0))
        spacing = self.box_size / (grid_size + 1)

        particle_idx = 0
        for i in range(grid_size):
            for j in range(grid_size):
                for k in range(grid_size):
                    if particle_idx >= self.num_particles:
                        break
                    x = (i + 1) * spacing
                    y = (j + 1) * spacing
                    z = (k + 1) * spacing
                    self.positions.append([x, y, z])

                    # Maxwell-Boltzmann velocity distribution
                    v_scale = math.sqrt(
                        self.boltzmann * self.temperature / 1.0
                    )  # mass = 1
                    vx = random.gauss(0, v_scale)
                    vy = random.gauss(0, v_scale)
                    vz = random.gauss(0, v_scale)
                    self.velocities.append([vx, vy, vz])

                    self.forces.append([0.0, 0.0, 0.0])
                    particle_idx += 1

                if particle_idx >= self.num_particles:
                    break
            if particle_idx >= self.num_particles:
                break

    def _distance(self, pos1, pos2):
        """Calculate distance between two positions."""
        dx = pos1[0] - pos2[0]
        dy = pos1[1] - pos2[1]
        dz = pos1[2] - pos2[2]
        return math.sqrt(dx * dx + dy * dy + dz * dz)

    def _lennard_jones_potential(self, r):
        """Lennard-Jones potential: V(r) = 4*epsilon*((sigma/r)^12 - (sigma/r)^6)"""
        if r < 0.5:
            return 1e10
        sigma_r = self.lennard_jones_sigma / r
        return (
            4
            * self.lennard_jones_epsilon
            * (sigma_r**12 - sigma_r**6)
        )

    def _lennard_jones_force(self, r):
        """Force from Lennard-Jones potential: dV/dr"""
        if r < 0.5:
            return 1e10
        sigma_r = self.lennard_jones_sigma / r
        return (
            4
            * self.lennard_jones_epsilon
            * (-12 * sigma_r**12 + 6 * sigma_r**6)
            / r
        )

    def _morse_potential(self, r):
        """Morse potential: V(r) = D*(1-exp(-a*(r-r0)))^2"""
        exp_term = math.exp(-self.morse_a * (r - self.morse_r0))
        return self.morse_D * (1 - exp_term) ** 2

    def _morse_force(self, r):
        """Force from Morse potential: dV/dr"""
        exp_term = math.exp(-self.morse_a * (r - self.morse_r0))
        return (
            2
            * self.morse_D
            * self.morse_a
            * (1 - exp_term)
            * exp_term
            / r
        )

    def _coulomb_potential(self, r):
        """Coulomb potential: V(r) = k*q1*q2/r (all charges +1)"""
        if r < 0.1:
            return 1e10
        return self.coulomb_k / r

    def _coulomb_force(self, r):
        """Force from Coulomb potential: dV/dr"""
        if r < 0.1:
            return 1e10
        return self.coulomb_k / (r * r)

    def _compute_forces(self):
        """Compute forces on all particles."""
        for i in range(self.num_particles):
            self.forces[i] = [0.0, 0.0, 0.0]

        for i in range(self.num_particles):
            for j in range(i + 1, self.num_particles):
                r = self._distance(self.positions[i], self.positions[j])

                # Choose potential
                if self.potential_type == "lennard_jones":
                    force_mag = self._lennard_jones_force(r)
                elif self.potential_type == "morse":
                    force_mag = self._morse_force(r)
                elif self.potential_type == "coulomb":
                    force_mag = self._coulomb_force(r)
                else:
                    force_mag = 0.0

                # Unit vector from j to i
                dx = self.positions[i][0] - self.positions[j][0]
                dy = self.positions[i][1] - self.positions[j][1]
                dz = self.positions[i][2] - self.positions[j][2]

                if r > 0.01:
                    fx = force_mag * dx / r
                    fy = force_mag * dy / r
                    fz = force_mag * dz / r

                    self.forces[i][0] += fx
                    self.forces[i][1] += fy
                    self.forces[i][2] += fz

                    self.forces[j][0] -= fx
                    self.forces[j][1] -= fy
                    self.forces[j][2] -= fz

    def _compute_potential_energy(self):
        """Compute total potential energy."""
        pe = 0.0
        for i in range(self.num_particles):
            for j in range(i + 1, self.num_particles):
                r = self._distance(self.positions[i], self.positions[j])

                if self.potential_type == "lennard_jones":
                    pe += self._lennard_jones_potential(r)
                elif self.potential_type == "morse":
                    pe += self._morse_potential(r)
                elif self.potential_type == "coulomb":
                    pe += self._coulomb_potential(r)

        return pe

    def _compute_kinetic_energy(self):
        """Compute total kinetic energy."""
        ke = 0.0
        for i in range(self.num_particles):
            v2 = (
                self.velocities[i][0] ** 2
                + self.velocities[i][1] ** 2
                + self.velocities[i][2] ** 2
            )
            ke += 0.5 * v2  # mass = 1

        return ke

    def _compute_temperature(self):
        """Compute temperature from kinetic energy."""
        ke = self._compute_kinetic_energy()
        # (3/2) * N * k_B * T = KE
        return 2.0 * ke / (3.0 * self.num_particles * self.boltzmann)

    def _velocity_verlet_step(self):
        """Perform one Velocity Verlet integration step."""
        # Step 1: Update positions and half-step velocities
        for i in range(self.num_particles):
            for dim in range(3):
                # x(t+dt) = x(t) + v(t)*dt + (1/2)*a(t)*dt^2
                self.positions[i][dim] += (
                    self.velocities[i][dim] * self.timestep
                    + 0.5 * self.forces[i][dim] * self.timestep ** 2
                )
                # v(t+dt/2) = v(t) + (1/2)*a(t)*dt
                self.velocities[i][dim] += (
                    0.5 * self.forces[i][dim] * self.timestep
                )

        # Step 2: Compute new forces
        self._compute_forces()

        # Step 3: Complete velocity update
        for i in range(self.num_particles):
            for dim in range(3):
                # v(t+dt) = v(t+dt/2) + (1/2)*a(t+dt)*dt
                self.velocities[i][dim] += (
                    0.5 * self.forces[i][dim] * self.timestep
                )

        # Apply periodic boundary conditions
        for i in range(self.num_particles):
            for dim in range(3):
                if self.positions[i][dim] < 0:
                    self.positions[i][dim] += self.box_size
                elif self.positions[i][dim] > self.box_size:
                    self.positions[i][dim] -= self.box_size

    def run(self, num_steps):
        """Run MD simulation for num_steps."""
        trajectory = []
        energy_data = []

        self._compute_forces()

        for step in range(num_steps):
            self._velocity_verlet_step()

            ke = self._compute_kinetic_energy()
            pe = self._compute_potential_energy()
            te = ke + pe
            temp = self._compute_temperature()

            energy_data.append(
                {
                    "step": step,
                    "kinetic": ke,
                    "potential": pe,
                    "total": te,
                    "temperature": temp,
                }
            )

            for particle_idx in range(self.num_particles):
                traj_point = {
                    "step": step,
                    "particle": particle_idx,
                    "x": self.positions[particle_idx][0],
                    "y": self.positions[particle_idx][1],
                    "z": self.positions[particle_idx][2],
                    "vx": self.velocities[particle_idx][0],
                    "vy": self.velocities[particle_idx][1],
                    "vz": self.velocities[particle_idx][2],
                }
                trajectory.append(traj_point)

        return trajectory, energy_data


def main():
    parser = argparse.ArgumentParser(
        description="Zeq OS Molecular Dynamics Simulator"
    )
    parser.add_argument(
        "--zeq_api_key",
        type=str,
        required=True,
        help="Zeq API Key (required). Get your key at https://www.zeq.dev/dashboard",
    )
    parser.add_argument(
        "--num_particles",
        type=int,
        default=20,
        help="Number of particles (default: 20)",
    )
    parser.add_argument(
        "--box_size",
        type=float,
        default=10.0,
        help="Box size in Angstroms (default: 10.0)",
    )
    parser.add_argument(
        "--temperature",
        type=float,
        default=300.0,
        help="Temperature in Kelvin (default: 300.0)",
    )
    parser.add_argument(
        "--timestep",
        type=float,
        default=0.001,
        help="Timestep in picoseconds (default: 0.001)",
    )
    parser.add_argument(
        "--num_steps",
        type=int,
        default=1000,
        help="Number of simulation steps (default: 1000)",
    )
    parser.add_argument(
        "--potential",
        choices=["lennard_jones", "morse", "coulomb"],
        default="lennard_jones",
        help="Potential energy model (default: lennard_jones)",
    )
    parser.add_argument(
        "--output_trajectory",
        help="Output trajectory file (tabular format)",
    )
    parser.add_argument(
        "--output_energy",
        help="Output energy file (tabular format)",
    )
    parser.add_argument(
        "--output_json",
        help="Output JSON summary file",
    )
    parser.add_argument(
        "--hulyapulse",
        action="store_true",
        help="Apply HulyaPulse 1.287 Hz modulation via Zeq API",
    )

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    # Create simulator
    print(f"[Zeq OS] Initializing MD simulation: {args.num_particles} particles, "
          f"{args.potential} potential, T={args.temperature}K", file=sys.stderr)
    sim = MDSimulator(
        args.num_particles,
        args.box_size,
        args.temperature,
        args.timestep,
        args.potential,
    )

    # Run simulation
    print(f"[Zeq OS] Running {args.num_steps} steps (dt={args.timestep} ps)...", file=sys.stderr)
    start_time = time.time()
    trajectory, energy_data = sim.run(args.num_steps)
    elapsed_time = time.time() - start_time
    print(f"[Zeq OS] Simulation complete in {elapsed_time:.2f}s", file=sys.stderr)

    # Apply HulyaPulse modulation via API if enabled
    if args.hulyapulse and energy_data:
        energy_values = [e["total"] for e in energy_data]
        modulated_values, result = client.modulate_values(energy_values)
        for i, e in enumerate(energy_data):
            e["total_hulyapulse"] = modulated_values[i]
        print(f"[Zeq OS] HulyaPulse modulation applied via Zeq API", file=sys.stderr)

    # Write trajectory file
    if args.output_trajectory:
        with open(args.output_trajectory, "w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "step",
                    "particle",
                    "x",
                    "y",
                    "z",
                    "vx",
                    "vy",
                    "vz",
                ],
                delimiter="\t",
            )
            writer.writeheader()
            writer.writerows(trajectory)
        print(f"[Zeq OS] Wrote trajectory to {args.output_trajectory}", file=sys.stderr)

    # Write energy file
    if args.output_energy:
        fieldnames = ["step", "kinetic", "potential", "total", "temperature"]
        if args.hulyapulse:
            fieldnames.append("total_hulyapulse")
        with open(args.output_energy, "w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=fieldnames,
                delimiter="\t",
                extrasaction="ignore",
            )
            writer.writeheader()
            writer.writerows(energy_data)
        print(f"[Zeq OS] Wrote energy data to {args.output_energy}", file=sys.stderr)

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()

    # Write JSON summary
    if args.output_json:
        summary = {
            "parameters": {
                "num_particles": args.num_particles,
                "box_size": args.box_size,
                "temperature": args.temperature,
                "timestep": args.timestep,
                "num_steps": args.num_steps,
                "potential": args.potential,
                "hulyapulse": args.hulyapulse,
            },
            "constants": {
                "hulyapulse_freq": HULYAPULSE_HZ,
                "zeqond": ZEQOND_SEC,
            },
            "results": {
                "elapsed_time_seconds": elapsed_time,
                "final_kinetic_energy": energy_data[-1]["kinetic"]
                if energy_data
                else 0.0,
                "final_potential_energy": energy_data[-1]["potential"]
                if energy_data
                else 0.0,
                "final_total_energy": energy_data[-1]["total"]
                if energy_data
                else 0.0,
                "final_temperature": energy_data[-1]["temperature"]
                if energy_data
                else 0.0,
                "average_kinetic_energy": sum(e["kinetic"] for e in energy_data)
                / len(energy_data)
                if energy_data
                else 0.0,
                "average_temperature": sum(e["temperature"] for e in energy_data)
                / len(energy_data)
                if energy_data
                else 0.0,
            },
            "cko_envelope": cko_envelope,
        }
        with open(args.output_json, "w") as f:
            json.dump(summary, f, indent=2)
        print(f"[Zeq OS] Wrote JSON summary to {args.output_json}", file=sys.stderr)

    # Daemon tick
    client.daemon_tick()
    print(f"[Zeq OS] MD simulation complete for {args.num_particles} particles", file=sys.stderr)


if __name__ == "__main__":
    main()
