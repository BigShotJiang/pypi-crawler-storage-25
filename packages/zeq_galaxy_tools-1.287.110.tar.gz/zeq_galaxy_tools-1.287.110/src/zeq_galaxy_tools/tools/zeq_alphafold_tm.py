#!/usr/bin/env python3
"""
Zeq OS — AlphaFold Structure Time-Modulation Sibling
Wraps zeq_alphafold with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to pLDDT scores and coordinates via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import sys
import argparse
import json
import csv
import math
import time
import urllib.request
import urllib.error

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING


def fetch_alphafold_structure(uniprot_id):
    """Fetch AlphaFold predicted structure from EMBL-EBI."""
    try:
        # Try AF2 database
        url = f"https://www.ebi.ac.uk/pdbe/api/mmcif/entry_download/{uniprot_id}_model_v1.cif"
        with urllib.request.urlopen(url, timeout=30) as resp:
            return resp.read().decode(), True
    except:
        # Fallback to structure lookup
        try:
            url = f"https://www.ebi.ac.uk/pdbe/api/pdb/entry/summary/{uniprot_id}"
            with urllib.request.urlopen(url, timeout=30) as resp:
                return json.loads(resp.read().decode()), False
        except Exception as e:
            print(f"[Zeq OS] ERROR: Could not fetch AlphaFold structure for {uniprot_id}: {e}", file=sys.stderr)
            sys.exit(1)


def fetch_alphafold_metadata(uniprot_id):
    """Fetch pLDDT and other metadata."""
    try:
        url = f"https://alphafold.ebi.ac.uk/api/prediction/{uniprot_id}"
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[Zeq OS] Warning: Could not fetch AlphaFold metadata: {e}", file=sys.stderr)
        return {}


def parse_af_cif(cif_text):
    """Parse AlphaFold mmCIF to extract coordinates and pLDDT."""
    residues = []
    lines = cif_text.split('\n')
    
    in_atom_loop = False
    atom_keys = []
    atom_values = []
    
    for i, line in enumerate(lines):
        line = line.strip()
        
        if line.startswith('loop_') and i + 1 < len(lines) and '_atom_site' in lines[i + 1]:
            in_atom_loop = True
            atom_keys = []
            atom_values = []
            continue
        
        if in_atom_loop:
            if line.startswith('_atom_site'):
                atom_keys.append(line)
            elif line and not line.startswith('_') and not line.startswith('loop_'):
                atom_values.append(line)
            elif not line or line.startswith('_') or line.startswith('loop_'):
                if atom_keys and atom_values:
                    in_atom_loop = False
                    # Parse collected values
                    all_vals = []
                    for val_str in atom_values:
                        all_vals.extend(val_str.split())
                    
                    num_records = len(all_vals) // len(atom_keys) if atom_keys else 0
                    for r in range(num_records):
                        record = {}
                        for k_idx, key in enumerate(atom_keys):
                            idx = r * len(atom_keys) + k_idx
                            if idx < len(all_vals):
                                record[key] = all_vals[idx]
                        
                        # Extract residue data
                        try:
                            res_num = record.get('_atom_site.auth_seq_id', '0')
                            x = float(record.get('_atom_site.Cartn_x', 0))
                            y = float(record.get('_atom_site.Cartn_y', 0))
                            z = float(record.get('_atom_site.Cartn_z', 0))
                            b_factor = float(record.get('_atom_site.B_iso_or_equiv', 0))
                            
                            residues.append({
                                'residue_number': res_num,
                                'x': x,
                                'y': y,
                                'z': z,
                                'plddt_equivalent': b_factor,  # B-factor often encodes pLDDT
                                'distance_from_origin': math.sqrt(x*x + y*y + z*z)
                            })
                        except (ValueError, KeyError):
                            continue
    
    return residues


def apply_time_modulation(values, zeq_client, domain="quantum-mechanics", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to values via Zeq API."""
    modulated = []
    current_time = time.time()
    
    for val in values:
        try:
            cko = zeq_client.compute(
                operators=["KO42"],
                values={"plddt_score": val, "energy_eV": abs(val) / 100.0 if val != 0 else 1.0},
                domain=domain
            )
            zeq_state = cko.get("zeqState", {})
            r_t = zeq_state.get("masterSum", val)
            phase = zeq_state.get("phase", 0.0)
            zeqond = zeq_state.get("zeqond", 0)
            proof = cko.get("zeqProof", "")
            
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": r_t,
                "phase": phase,
                "zeqond": zeqond,
                "proof": proof,
                "modulation_factor": modulation_factor
            })
        except Exception as e:
            print(f"[Zeq OS] Warning: API modulation failed for value {val}: {e}", file=sys.stderr)
            phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": val,
                "phase": phase,
                "zeqond": int(current_time / ZEQOND_SEC),
                "proof": "",
                "modulation_factor": modulation_factor
            })
    
    return modulated


def main():
    parser = argparse.ArgumentParser(description="Zeq OS AlphaFold Time-Modulation Sibling")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--uniprot_id", required=True, help="UniProt ID (e.g., P12345)")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_residues", default=None, help="Output CSV for residue data")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    print(f"[Zeq OS] Fetching AlphaFold structure for {args.uniprot_id}...", file=sys.stderr)
    
    # Try to fetch structure and metadata
    struct_data, is_cif = fetch_alphafold_structure(args.uniprot_id)
    metadata = fetch_alphafold_metadata(args.uniprot_id)
    
    print(f"[Zeq OS] Fetched AlphaFold data for {args.uniprot_id}", file=sys.stderr)

    results = {
        "uniprot_id": args.uniprot_id,
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_s": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Parse structure
    residues = []
    if is_cif and isinstance(struct_data, str):
        residues = parse_af_cif(struct_data)
        print(f"[Zeq OS] Parsed {len(residues)} residues from mmCIF", file=sys.stderr)
    
    # Apply time modulation to pLDDT-equivalent scores
    if residues:
        scores = [r.get('plddt_equivalent', 50) for r in residues]
        mod_scores = apply_time_modulation(scores, client, domain="quantum-mechanics", tm_steps=args.tm_steps)
        
        for i, r in enumerate(residues):
            r["plddt_tm"] = mod_scores[i]
        
        results["residues"] = residues

        # Output residue data
        if args.output_residues:
            with open(args.output_residues, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["residue_number", "x", "y", "z", "plddt_score",
                                "plddt_tm_modulated", "R_t", "phase", "zeqond", "distance_from_origin"])
                for r in residues:
                    mod = r["plddt_tm"]
                    writer.writerow([
                        r["residue_number"],
                        f"{r['x']:.4f}",
                        f"{r['y']:.4f}",
                        f"{r['z']:.4f}",
                        f"{r['plddt_equivalent']:.1f}",
                        f"{mod['modulated']:.1f}",
                        f"{mod['R_t']:.6f}",
                        f"{mod['phase']:.6f}",
                        mod["zeqond"],
                        f"{r['distance_from_origin']:.4f}"
                    ])

    # Add metadata
    if metadata:
        results["alphafold_metadata"] = metadata

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for {args.uniprot_id}", file=sys.stderr)


if __name__ == "__main__":
    main()
