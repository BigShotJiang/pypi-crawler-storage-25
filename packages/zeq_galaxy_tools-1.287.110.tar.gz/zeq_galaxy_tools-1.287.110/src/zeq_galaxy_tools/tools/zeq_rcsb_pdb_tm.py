#!/usr/bin/env python3
"""
Zeq OS — RCSB PDB Protein Structure Time-Modulation Sibling
Wraps zeq_rcsb_pdb with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to atomic coordinates and structural metrics via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import sys
import argparse
import json
import csv
import math
import time
import urllib.request
import urllib.error

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING


def fetch_pdb_structure(pdb_id):
    """Fetch PDB structure via REST API."""
    try:
        url = f"https://data.rcsb.org/rest/v1/core/entry/{pdb_id}"
        with urllib.request.urlopen(url, timeout=30) as resp:
            return json.loads(resp.read().decode())
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch PDB {pdb_id}: {e}", file=sys.stderr)
        sys.exit(1)


def fetch_mmcif(pdb_id):
    """Fetch mmCIF format structure."""
    try:
        url = f"https://files.rcsb.org/download/{pdb_id}.cif"
        with urllib.request.urlopen(url, timeout=30) as resp:
            return resp.read().decode()
    except Exception as e:
        print(f"[Zeq OS] ERROR: Could not fetch mmCIF for {pdb_id}: {e}", file=sys.stderr)
        sys.exit(1)


def parse_mmcif(cif_text):
    """Parse mmCIF format to extract atomic coordinates."""
    atoms = []
    lines = cif_text.split('\n')
    in_loop = False
    loop_keys = []
    i = 0
    
    while i < len(lines):
        line = lines[i].strip()
        
        if not line or line.startswith('#'):
            i += 1
            continue
        
        if line.startswith('loop_'):
            in_loop = True
            loop_keys = []
            i += 1
            # Collect keys
            while i < len(lines):
                line = lines[i].strip()
                if line.startswith('_'):
                    loop_keys.append(line)
                    i += 1
                else:
                    break
            
            # Parse values
            values = []
            while i < len(lines):
                line = lines[i].strip()
                if not line or line.startswith('_') or line.startswith('loop_'):
                    break
                values.extend(line.split())
                i += 1
            
            # Map values to keys
            if loop_keys and values:
                num_records = len(values) // len(loop_keys)
                for r in range(num_records):
                    record = {}
                    for k_idx, key in enumerate(loop_keys):
                        idx = r * len(loop_keys) + k_idx
                        if idx < len(values):
                            record[key] = values[idx]
                    if '_atom_site.auth_seq_id' in record:
                        atoms.append(record)
        else:
            i += 1
    
    return atoms


def compute_bounding_box(atoms):
    """Compute 3D bounding box from atomic coordinates."""
    if not atoms:
        return None
    
    coords = []
    for atom in atoms:
        try:
            x = float(atom.get('_atom_site.Cartn_x', 0))
            y = float(atom.get('_atom_site.Cartn_y', 0))
            z = float(atom.get('_atom_site.Cartn_z', 0))
            coords.append((x, y, z))
        except ValueError:
            continue
    
    if not coords:
        return None
    
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    zs = [c[2] for c in coords]
    
    return {
        "x_min": min(xs),
        "x_max": max(xs),
        "y_min": min(ys),
        "y_max": max(ys),
        "z_min": min(zs),
        "z_max": max(zs),
        "dimensions": {
            "x": max(xs) - min(xs),
            "y": max(ys) - min(ys),
            "z": max(zs) - min(zs)
        }
    }


def apply_time_modulation(values, zeq_client, domain="classical-mechanics", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to values via Zeq API."""
    modulated = []
    current_time = time.time()
    
    for val in values:
        try:
            cko = zeq_client.compute(
                operators=["KO42"],
                values={"value": val, "distance_angstrom": abs(val) if val != 0 else 1.0},
                domain=domain
            )
            zeq_state = cko.get("zeqState", {})
            r_t = zeq_state.get("masterSum", val)
            phase = zeq_state.get("phase", 0.0)
            zeqond = zeq_state.get("zeqond", 0)
            proof = cko.get("zeqProof", "")
            
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": r_t,
                "phase": phase,
                "zeqond": zeqond,
                "proof": proof,
                "modulation_factor": modulation_factor
            })
        except Exception as e:
            print(f"[Zeq OS] Warning: API modulation failed for value {val}: {e}", file=sys.stderr)
            phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": val,
                "phase": phase,
                "zeqond": int(current_time / ZEQOND_SEC),
                "proof": "",
                "modulation_factor": modulation_factor
            })
    
    return modulated


def main():
    parser = argparse.ArgumentParser(description="Zeq OS RCSB PDB Time-Modulation Sibling")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--pdb_id", required=True, help="PDB ID (4 characters, e.g., 1BNA)")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_atoms", default=None, help="Output CSV for atomic coordinates")
    parser.add_argument("--output_bounding_box", default=None, help="Output JSON for bounding box")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Validate PDB ID
    if not args.pdb_id or len(args.pdb_id) != 4:
        print("[Zeq OS] ERROR: PDB ID must be 4 characters", file=sys.stderr)
        sys.exit(1)

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    print(f"[Zeq OS] Fetching PDB structure: {args.pdb_id}", file=sys.stderr)
    pdb_data = fetch_pdb_structure(args.pdb_id)
    
    print(f"[Zeq OS] Fetching mmCIF for {args.pdb_id}...", file=sys.stderr)
    mmcif_text = fetch_mmcif(args.pdb_id)
    atoms = parse_mmcif(mmcif_text)
    print(f"[Zeq OS] Parsed {len(atoms)} atoms from mmCIF", file=sys.stderr)

    results = {
        "pdb_id": args.pdb_id,
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_s": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING,
        "num_atoms": len(atoms)
    }

    # Compute bounding box
    if atoms:
        bbox = compute_bounding_box(atoms)
        if bbox:
            print(f"[Zeq OS] Bounding box: {bbox['dimensions']}", file=sys.stderr)
            
            # Apply time modulation to bounding box dimensions
            dims = [bbox['dimensions']['x'], bbox['dimensions']['y'], bbox['dimensions']['z']]
            mod_dims = apply_time_modulation(dims, client, domain="classical-mechanics", tm_steps=args.tm_steps)
            
            bbox["modulated"] = {
                "x_tm": mod_dims[0],
                "y_tm": mod_dims[1],
                "z_tm": mod_dims[2]
            }
            
            results["bounding_box"] = bbox

            if args.output_bounding_box:
                with open(args.output_bounding_box, "w") as f:
                    json.dump(bbox, f, indent=2)

        # Output atomic coordinates
        if args.output_atoms:
            with open(args.output_atoms, "w", newline="") as f:
                writer = csv.writer(f, delimiter="\t")
                writer.writerow(["atom_id", "residue", "atom_name", "x", "y", "z"])
                for atom in atoms:
                    try:
                        x = float(atom.get('_atom_site.Cartn_x', 0))
                        y = float(atom.get('_atom_site.Cartn_y', 0))
                        z = float(atom.get('_atom_site.Cartn_z', 0))
                        atom_id = atom.get('_atom_site.auth_atom_id', '')
                        res = atom.get('_atom_site.auth_resname', '')
                        seq = atom.get('_atom_site.auth_seq_id', '')
                        name = atom.get('_atom_site.label_atom_id', '')
                        writer.writerow([atom_id, f"{res}_{seq}", name, f"{x:.4f}", f"{y:.4f}", f"{z:.4f}"])
                    except (ValueError, KeyError):
                        continue

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for PDB {args.pdb_id}", file=sys.stderr)


if __name__ == "__main__":
    main()
