#!/usr/bin/env python3
"""
Zeq OS — NIST Spectral Emission Time-Modulation Sibling
Wraps zeq_nist_spectral with HulyaPulse 1.287 Hz temporal modulation.
Applies R(t) modulation to emission intensities and wavelengths via Zeq API.

All HulyaPulse modulation and CKO envelope generation routes through the Zeq API.

Part of the Zeq OS Generative Mathematics Operating System
HulyaPulse: 1.287 Hz | Zeqond: 0.777s
DOI: https://doi.org/10.5281/zenodo.18158152

Author: Zeq. H — Zeq OS 1.287 Hz Limited
License: CC BY 4.0
"""

import argparse
import sys
import json
import csv
import math
import time

from zeq_client import create_client, HULYAPULSE_HZ, ZEQOND_SEC, ALPHA_COUPLING

# Built-in NIST emission line database
EMISSION_DATABASE = {
    "H": [(656.3, 100, "H-alpha"), (486.1, 65, "H-beta"), (434.0, 35, "H-gamma"), (410.2, 10, "H-delta")],
    "He": [(587.6, 100, "He 587.6"), (667.8, 80, "He 667.8"), (471.3, 60, "He 471.3")],
    "Ne": [(640.0, 100, "Ne I"), (602.0, 85, "Ne I"), (614.0, 70, "Ne I")],
    "Ar": [(696.5, 100, "Ar I"), (706.5, 95, "Ar I"), (727.3, 80, "Ar I")],
    "Kr": [(811.5, 100, "Kr I"), (826.3, 90, "Kr I"), (769.2, 75, "Kr I")],
    "Xe": [(823.2, 100, "Xe I"), (881.9, 95, "Xe I"), (979.9, 80, "Xe I")],
    "N": [(658.4, 100, "N I"), (742.3, 85, "N I"), (868.0, 65, "N I")],
    "O": [(436.9, 100, "O I"), (495.9, 80, "O I"), (777.0, 60, "O I")],
    "S": [(545.4, 100, "S I"), (674.8, 75, "S I"), (867.0, 50, "S I")],
    "P": [(534.0, 100, "P I"), (589.0, 85, "P I")],
    "F": [(373.0, 100, "F I"), (471.3, 75, "F I")],
    "Cl": [(479.5, 100, "Cl I"), (837.6, 80, "Cl I")],
    "Br": [(827.2, 100, "Br I"), (540.0, 75, "Br I")],
    "I": [(516.9, 100, "I I"), (518.3, 95, "I I")],
    "Na": [(589.0, 100, "Na D"), (588.9, 100, "Na D")],
    "Ca": [(422.7, 100, "Ca I"), (454.9, 80, "Ca I"), (517.3, 60, "Ca I")],
}


def apply_time_modulation(values, zeq_client, domain="electromagnetism", tm_steps=16):
    """Apply HulyaPulse R(t) modulation to spectral values via Zeq API."""
    modulated = []
    current_time = time.time()
    
    for val in values:
        try:
            cko = zeq_client.compute(
                operators=["KO42"],
                values={"wavelength_nm": abs(val) if val != 0 else 500},
                domain=domain
            )
            zeq_state = cko.get("zeqState", {})
            r_t = zeq_state.get("masterSum", val)
            phase = zeq_state.get("phase", 0.0)
            zeqond = zeq_state.get("zeqond", 0)
            proof = cko.get("zeqProof", "")
            
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": r_t,
                "phase": phase,
                "zeqond": zeqond,
                "proof": proof,
                "modulation_factor": modulation_factor
            })
        except Exception as e:
            print(f"[Zeq OS] Warning: API modulation failed for value {val}: {e}", file=sys.stderr)
            phase = (current_time % ZEQOND_SEC) / ZEQOND_SEC * 2 * math.pi
            modulation_factor = 1 + ALPHA_COUPLING * math.sin(2 * math.pi * HULYAPULSE_HZ * current_time + phase)
            modulated_val = val * modulation_factor
            modulated.append({
                "original": val,
                "modulated": modulated_val,
                "R_t": val,
                "phase": phase,
                "zeqond": int(current_time / ZEQOND_SEC),
                "proof": "",
                "modulation_factor": modulation_factor
            })
    
    return modulated


def compute_gaussian_spectrum(wavelengths, intensities, sigma=2.0):
    """Compute Gaussian-broadened spectrum."""
    # Generate spectrum grid
    min_wl = min(wavelengths) - 50
    max_wl = max(wavelengths) + 50
    spectrum = []
    
    for wl in range(int(min_wl), int(max_wl), 5):
        intensity = 0
        for line_wl, line_int, _ in zip(wavelengths, intensities, [None]*len(wavelengths)):
            # Gaussian profile
            gauss = line_int * math.exp(-((wl - line_wl) ** 2) / (2 * sigma * sigma))
            intensity += gauss
        spectrum.append({"wavelength": wl, "intensity": intensity})
    
    return spectrum


def main():
    parser = argparse.ArgumentParser(description="Zeq OS NIST Spectral Time-Modulation Sibling")
    parser.add_argument("--zeq_api_key", required=True, help="Zeq API key (required)")
    parser.add_argument("--element", required=True, help="Element symbol (e.g., H, He, Ne, Ar)")
    parser.add_argument("--tm_steps", type=int, default=16,
                        help="Number of Zeqond time steps for temporal projection (default 16)")
    parser.add_argument("--output_lines", default=None, help="Output CSV for emission lines")
    parser.add_argument("--output_spectrum", default=None, help="Output CSV for broadened spectrum")
    parser.add_argument("--output_json", default=None, help="Output JSON with modulated results")

    args = parser.parse_args()

    # Create Zeq API client
    client = create_client(args.zeq_api_key)

    element = args.element.upper()
    
    if element not in EMISSION_DATABASE:
        print(f"[Zeq OS] ERROR: Element {element} not in database. Available: {', '.join(EMISSION_DATABASE.keys())}", file=sys.stderr)
        sys.exit(1)

    print(f"[Zeq OS] Fetching emission lines for {element}...", file=sys.stderr)
    
    # Get emission lines
    lines = EMISSION_DATABASE[element]
    wavelengths = [line[0] for line in lines]
    intensities = [line[1] for line in lines]
    labels = [line[2] for line in lines]
    
    print(f"[Zeq OS] Retrieved {len(lines)} emission lines for {element}", file=sys.stderr)

    results = {
        "element": element,
        "num_lines": len(lines),
        "hulyapulse_hz": HULYAPULSE_HZ,
        "zeqond_s": ZEQOND_SEC,
        "tm_steps": args.tm_steps,
        "alpha_coupling": ALPHA_COUPLING
    }

    # Apply time modulation to wavelengths
    mod_wavelengths = apply_time_modulation(wavelengths, client, domain="electromagnetism", tm_steps=args.tm_steps)
    mod_intensities = apply_time_modulation(intensities, client, domain="electromagnetism", tm_steps=args.tm_steps)

    # Build emission line data
    emission_lines = []
    for i, (wl, intensity, label) in enumerate(zip(wavelengths, intensities, labels)):
        emission_lines.append({
            "wavelength_nm": wl,
            "intensity": intensity,
            "label": label,
            "wavelength_tm": mod_wavelengths[i],
            "intensity_tm": mod_intensities[i]
        })

    results["emission_lines"] = emission_lines

    # Output emission lines
    if args.output_lines:
        with open(args.output_lines, "w", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["wavelength_nm", "intensity", "label",
                            "wavelength_tm_modulated", "intensity_tm_modulated",
                            "R_t_wl", "phase_wl", "zeqond_wl"])
            for line in emission_lines:
                wl_mod = line["wavelength_tm"]
                int_mod = line["intensity_tm"]
                writer.writerow([
                    f"{line['wavelength_nm']:.2f}",
                    f"{line['intensity']:.1f}",
                    line["label"],
                    f"{wl_mod['modulated']:.2f}",
                    f"{int_mod['modulated']:.1f}",
                    f"{wl_mod['R_t']:.6f}",
                    f"{wl_mod['phase']:.6f}",
                    wl_mod['zeqond']
                ])

    # Compute Gaussian-broadened spectrum
    print(f"[Zeq OS] Computing Gaussian-broadened spectrum...", file=sys.stderr)
    spectrum = compute_gaussian_spectrum(wavelengths, intensities)
    
    # Apply modulation to spectrum
    spec_intensities = [s["intensity"] for s in spectrum]
    mod_spec = apply_time_modulation(spec_intensities, client, domain="electromagnetism", tm_steps=args.tm_steps)
    
    for i, s in enumerate(spectrum):
        s["intensity_tm"] = mod_spec[i]

    results["spectrum"] = spectrum[:len(spectrum)//2 + len(spectrum)%2]  # Limit for JSON

    # Output spectrum
    if args.output_spectrum:
        with open(args.output_spectrum, "w", newline="") as f:
            writer = csv.writer(f, delimiter="\t")
            writer.writerow(["wavelength_nm", "intensity", "intensity_tm_modulated", "R_t", "phase", "zeqond"])
            for spec in spectrum:
                mod = spec["intensity_tm"]
                writer.writerow([
                    f"{spec['wavelength']:.2f}",
                    f"{spec['intensity']:.4f}",
                    f"{mod['modulated']:.4f}",
                    f"{mod['R_t']:.6f}",
                    f"{mod['phase']:.6f}",
                    mod['zeqond']
                ])

    # Get CKO envelope
    cko_envelope = client.get_cko_envelope()
    results["cko_envelope"] = cko_envelope

    # JSON output
    if args.output_json:
        with open(args.output_json, "w") as f:
            json.dump(results, f, indent=2)

    client.daemon_tick()
    print(f"[Zeq OS] Time-modulation analysis complete for {element}", file=sys.stderr)


if __name__ == "__main__":
    main()
