# Zeq OS Galaxy Tools

**Twelve production-ready molecular & scientific connector tools for Galaxy** — 6 originals + 6 time-modulation siblings. Powered by the Zeq API with 1.287 Hz HulyaPulse synchronization and CKO envelope verification.

[![PyPI version](https://badge.fury.io/py/zeq-galaxy-tools.svg)](https://pypi.org/project/zeq-galaxy-tools/)
[![Galaxy ToolShed](https://img.shields.io/badge/Galaxy-ToolShed-blue)](https://toolshed.g2.bx.psu.edu/view/Zeq)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)
[![Docker](https://img.shields.io/badge/Docker-Hub-blue)](https://hub.docker.com/r/zeqos/zeq-galaxy-tools)

## Quick Start

```bash
pip install zeq-galaxy-tools
```

Get your Zeq API key at **https://www.zeq.dev/dashboard**

## Tools

### Original Tools (6)

| Tool | Description | Data Source |
|------|-------------|-------------|
| `zeq-pubchem-3d` | 3D molecular structures, bond lengths, properties | [PubChem](https://pubchem.ncbi.nlm.nih.gov/) |
| `zeq-rcsb-pdb` | Experimental protein structures (X-ray, cryo-EM) | [RCSB PDB](https://www.rcsb.org/) |
| `zeq-alphafold` | AI-predicted protein structures with confidence | [AlphaFold DB](https://alphafold.ebi.ac.uk/) |
| `zeq-chembl` | Bioactivity data, IC50/EC50, pharmacology | [ChEMBL](https://www.ebi.ac.uk/chembl/) |
| `zeq-md-simulator` | Molecular dynamics (Lennard-Jones, Morse, Coulomb) | Simulation engine |
| `zeq-nist-spectral` | Spectral emission lines for 16 elements | [NIST ASD](https://www.nist.gov/pml/atomic-spectra-database) |

### Time-Modulation Siblings (6)

Each original tool has a TM (time-modulation) sibling that applies 1.287 Hz HulyaPulse temporal filtering:

| Tool | Description |
|------|-------------|
| `zeq-pubchem-3d-tm` | Time-modulated PubChem 3D structures |
| `zeq-rcsb-pdb-tm` | Time-modulated RCSB PDB structures |
| `zeq-alphafold-tm` | Time-modulated AlphaFold predictions |
| `zeq-chembl-tm` | Time-modulated ChEMBL bioactivity data |
| `zeq-md-simulator-tm` | Time-modulated molecular dynamics |
| `zeq-nist-spectral-tm` | Time-modulated spectral analysis |

## Usage

### Command Line

```bash
# Fetch aspirin 3D structure
zeq-pubchem-3d --zeq_api_key YOUR_KEY --molecule aspirin --mode all \
  --output_atoms atoms.tsv --output_bonds bonds.tsv \
  --output_properties props.tsv --output_json summary.json

# Fetch hemoglobin from PDB
zeq-rcsb-pdb --zeq_api_key YOUR_KEY --pdb_id 4HHB --mode all \
  --output_atoms atoms.tsv --output_summary summary.tsv --output_json data.json

# AlphaFold predicted structure
zeq-alphafold --zeq_api_key YOUR_KEY --uniprot_id P69905 --mode all \
  --output_atoms atoms.tsv --output_confidence conf.tsv --output_json summary.json

# ChEMBL bioactivity data
zeq-chembl --zeq_api_key YOUR_KEY --molecule ibuprofen --mode all \
  --output_activities activities.tsv --output_molecule mol.tsv --output_json data.json

# Run molecular dynamics
zeq-md-simulator --zeq_api_key YOUR_KEY --potential lennard_jones \
  --num_particles 50 --num_steps 1000 \
  --output_trajectory traj.tsv --output_energy energy.tsv --output_json summary.json

# Analyze iron emission spectrum
zeq-nist-spectral --zeq_api_key YOUR_KEY --element Fe --mode all \
  --output_lines lines.tsv --output_spectrum spectrum.tsv --output_json summary.json
```

### Python API

```python
from zeq_galaxy_tools.tools import zeq_pubchem_3d
import subprocess, sys

# Or call directly
subprocess.run([sys.executable, "-m", "zeq_galaxy_tools.tools.zeq_pubchem_3d",
    "--zeq_api_key", "YOUR_KEY", "--molecule", "caffeine", "--mode", "all",
    "--output_atoms", "atoms.tsv", "--output_bonds", "bonds.tsv",
    "--output_properties", "props.tsv", "--output_json", "summary.json"])
```

### Galaxy ToolShed

All tools are also available on the [Galaxy ToolShed](https://toolshed.g2.bx.psu.edu/view/Zeq) for use within Galaxy workflows.

### Docker

```bash
docker pull zeqos/zeq-galaxy-tools:1.287.5
docker run zeqos/zeq-galaxy-tools:1.287.5 zeq-pubchem-3d \
  --zeq_api_key YOUR_KEY --molecule aspirin --mode all \
  --output_atoms /data/atoms.tsv --output_bonds /data/bonds.tsv \
  --output_properties /data/props.tsv --output_json /data/summary.json
```

## HulyaPulse Modulation

Original tools support optional `--hulyapulse` flag. Time-modulation siblings apply 1.287 Hz temporal filtering by default. Both provide:

- Phase-locked synchronization with Zeq OS infrastructure
- Graceful API rate limiting
- Verified CKO envelope generation with zeqProof
- Zeqond period alignment (0.777 s)

## Zeq OS Integration

- **Version:** 1.287.5
- **HulyaPulse frequency:** 1.287 Hz
- **Zeqond period:** 0.777 s
- **KO42 Metric Tensioner:** Prime Directive
- **API:** https://www.zeq.dev
- **SDK:** https://sdk.1.287hz.com/

## Requirements

- Python 3.8+
- Zeq API key (get yours at https://www.zeq.dev/dashboard)
- No external dependencies (Python standard library only)

## Citations

- **Zeq OS Paper:** https://doi.org/10.5281/zenodo.18158152
- **Zeq OS Framework:** https://doi.org/10.5281/zenodo.15825138
- **AlphaFold2:** Jumper et al. (2021). Nature. https://doi.org/10.1038/s41586-021-03819-2

## License

CC BY 4.0 - Zeq. H, Zeq OS 1.287 Hz Limited

## Links

- **Zeq OS:** https://hulyas.org
- **Zeq API:** https://www.zeq.dev
- **Galaxy ToolShed:** https://toolshed.g2.bx.psu.edu/view/Zeq
- **SDK:** https://sdk.1.287hz.com/
