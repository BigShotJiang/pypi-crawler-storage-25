"""Utilities for the Claude Code adapter."""

import json
from pathlib import Path
from typing import cast

from clu.adapter.claude.constants import CLU_COMMAND_MARKER
from clu.models.claude_hook_command import ClaudeHookCommand
from clu.models.claude_hook_entry import ClaudeHookEntry
from clu.models.claude_hook_event import ClaudeHookEvent
from clu.models.claude_settings import ClaudeSettings
from clu.models.session_message import SessionMessage
from clu.utils.message_ids import build_message_uuid

# Record types that harnesses (e.g. Conductor) interleave with the standard
# Claude Code `user` / `assistant` stream. They carry bookkeeping — not
# transcript content — so we skip them explicitly instead of silently.
_IGNORED_TRANSCRIPT_TYPES = frozenset({
    "system",
    "attachment",
    "pr-link",
    "last-prompt",
})

# --- Settings IO ---


def read_claude_settings(*, path: Path) -> ClaudeSettings:
    """Read a Claude settings file into typed hook models."""
    if not path.exists():
        return ClaudeSettings()

    text = path.read_text().strip()
    if not text:
        return ClaudeSettings()

    payload = json.loads(text)
    raw_hooks = payload.get("hooks", {})
    if not isinstance(raw_hooks, dict):
        return ClaudeSettings()

    hook_events: list[ClaudeHookEvent] = []
    for event_name, raw_entries in raw_hooks.items():
        entries: list[ClaudeHookEntry] = []
        if isinstance(raw_entries, list):
            for raw_entry in raw_entries:
                if not isinstance(raw_entry, dict):
                    continue
                matcher = raw_entry.get("matcher", "")
                raw_commands = raw_entry.get("hooks", [])
                commands: list[ClaudeHookCommand] = []
                if isinstance(raw_commands, list):
                    for raw_command in raw_commands:
                        if not isinstance(raw_command, dict):
                            continue
                        command_type = raw_command.get("type")
                        command = raw_command.get("command")
                        if isinstance(command_type, str) and isinstance(command, str):
                            commands.append(
                                ClaudeHookCommand(type=command_type, command=command)
                            )
                entries.append(
                    ClaudeHookEntry(
                        matcher=matcher if isinstance(matcher, str) else "",
                        hooks=commands,
                    )
                )
        hook_events.append(ClaudeHookEvent(event_name=str(event_name), entries=entries))

    return ClaudeSettings(hook_events=hook_events)


def write_claude_settings(*, path: Path, settings: ClaudeSettings) -> None:
    """Write typed Claude settings back to disk."""
    hooks_payload: dict[str, list[dict[str, object]]] = {}
    for event in settings.hook_events:
        hooks_payload[event.event_name] = [
            {
                "matcher": entry.matcher,
                "hooks": [
                    command.model_dump(mode="json", exclude_none=True)
                    for command in entry.hooks
                ],
            }
            for entry in event.entries
        ]

    payload = {"hooks": hooks_payload} if hooks_payload else {}
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n")


# --- Hook entry helpers ---


def shell_quote(value: str) -> str:
    """Wrap a shell command token in quotes when needed."""
    if not any(character in value for character in " \t'\"\\$`!#&|;(){}"):
        return value
    return "'" + value.replace("'", "'\\''") + "'"


def find_event(
    events: list[ClaudeHookEvent],
    *,
    event_name: str,
) -> ClaudeHookEvent | None:
    """Find a configured Claude hook event by name."""
    for event in events:
        if event.event_name == event_name:
            return event
    return None


def build_clu_entry(*, command: str) -> ClaudeHookEntry:
    """Build a clu-managed Claude hook entry."""
    return ClaudeHookEntry(
        matcher="",
        hooks=[ClaudeHookCommand(type="command", command=command)],
    )


def is_clu_entry(*, entry: ClaudeHookEntry) -> bool:
    """Return whether a hook entry is managed by clu."""
    return any(CLU_COMMAND_MARKER in hook.command for hook in entry.hooks)


def has_clu_entry(*, entries: list[ClaudeHookEntry]) -> bool:
    """Return whether any hook entry is clu-managed."""
    return any(is_clu_entry(entry=entry) for entry in entries)


def update_clu_entry(*, entries: list[ClaudeHookEntry], command: str) -> None:
    """Update the shell command for existing clu-managed hook entries."""
    for entry in entries:
        if not is_clu_entry(entry=entry):
            continue
        for hook in entry.hooks:
            if CLU_COMMAND_MARKER in hook.command:
                hook.command = command


# --- Transcript parsing ---


def parse_claude_transcript(
    *,
    path: str,
    session_id: str,
    cwd: str,
    watermark: int = 0,
    turn_offset: int = 0,
    last_known_model: str = "",
) -> tuple[list[SessionMessage], int]:
    """Parse new transcript messages from a Claude Code JSONL transcript.

    Handles both the canonical Claude Code schema (``user`` / ``assistant``
    records with a nested ``message`` object) and the Conductor harness
    extensions (``queue-operation``, ``attachment``, ``pr-link``,
    ``last-prompt``). Conductor's ``queue-operation`` with
    ``operation=enqueue`` stores the raw user prompt at the top-level
    ``content`` key, and Claude Code then emits a duplicate ``user`` record
    moments later; we emit the prompt once and dedupe the duplicate.
    """
    messages: list[SessionMessage] = []
    line_number = 0
    carried_model = last_known_model
    # Maps user-prompt content to queue of indexes in ``messages`` of the
    # queue-op emits awaiting metadata enrichment from the matching
    # standard ``user`` record.
    pending_enqueue_dedup: dict[str, list[int]] = {}

    def _append(message: SessionMessage) -> None:
        messages.append(message)

    def _next_turn_index() -> int:
        return turn_offset + len(messages)

    def _parent_uuid_for(turn_index: int) -> str:
        if messages:
            return messages[-1].uuid
        if turn_index > 0:
            return build_message_uuid(
                session_id=session_id, turn_index=turn_index - 1,
            )
        return ""

    with open(path, encoding="utf-8") as file:
        for line_number, raw_line in enumerate(file, start=1):
            if line_number <= watermark:
                continue

            line = raw_line.strip()
            if not line:
                continue

            try:
                entry = json.loads(line)
            except (json.JSONDecodeError, ValueError):
                continue

            if not isinstance(entry, dict):
                continue

            entry_type = entry.get("type", "")

            if entry_type == "queue-operation":
                _handle_queue_operation(
                    entry=entry,
                    session_id=session_id,
                    cwd=cwd,
                    pending_enqueue_dedup=pending_enqueue_dedup,
                    next_turn_index=_next_turn_index,
                    parent_uuid_for=_parent_uuid_for,
                    append=_append,
                    messages=messages,
                )
                continue

            if entry_type in _IGNORED_TRANSCRIPT_TYPES:
                continue

            if entry_type not in ("user", "assistant"):
                continue

            message = entry.get("message")
            if not isinstance(message, dict):
                continue

            role = message.get("role", entry_type)
            raw_content = message.get("content")
            text = _extract_text(raw=raw_content)
            tool_calls = _extract_tool_calls(raw=raw_content)
            tool_results = _extract_tool_results(raw=raw_content)

            if not text and not tool_calls and not tool_results:
                continue

            # Dedupe: a Conductor enqueue was already emitted as a user turn
            # and this ``user`` record is Claude Code's duplicate copy. Enrich
            # the earlier emit with the user record's per-message metadata
            # (``gitBranch``, ``cwd``) that the queue-op record lacks.
            if (
                entry_type == "user"
                and isinstance(raw_content, str)
                and not tool_calls
                and not tool_results
                and pending_enqueue_dedup.get(text)
            ):
                target_index = pending_enqueue_dedup[text].pop(0)
                if not pending_enqueue_dedup[text]:
                    del pending_enqueue_dedup[text]
                entry_cwd = entry.get("cwd")
                entry_git_branch = entry.get("gitBranch", "")
                if isinstance(entry_cwd, str) and entry_cwd:
                    messages[target_index].cwd = entry_cwd
                if isinstance(entry_git_branch, str) and entry_git_branch:
                    messages[target_index].git_branch = entry_git_branch
                continue

            usage = message.get("usage")
            input_tokens, output_tokens, cache_read, cache_write = _extract_usage(
                raw=usage,
            )

            raw_model = str(message.get("model", ""))
            if raw_model:
                carried_model = raw_model
                model = raw_model
            elif tool_results:
                model = carried_model
            else:
                model = ""

            turn_index = _next_turn_index()
            entry_cwd = entry.get("cwd", cwd)
            entry_git_branch = entry.get("gitBranch", "")
            _append(
                SessionMessage(
                    uuid=build_message_uuid(
                        session_id=session_id, turn_index=turn_index,
                    ),
                    session_id=session_id,
                    parent_uuid=_parent_uuid_for(turn_index),
                    turn_index=turn_index,
                    role=str(role),
                    content=text,
                    tool_calls=tool_calls,
                    tool_results=tool_results,
                    model=model,
                    timestamp=_parse_timestamp_ms(raw=entry.get("timestamp")),
                    cwd=str(entry_cwd) if entry_cwd else cwd,
                    git_branch=str(entry_git_branch) if entry_git_branch else "",
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    cache_read_tokens=cache_read,
                    cache_write_tokens=cache_write,
                    dirty=True,
                )
            )

    return messages, max(line_number, watermark)


def _handle_queue_operation(
    *,
    entry: dict[str, object],
    session_id: str,
    cwd: str,
    pending_enqueue_dedup: dict[str, list[int]],
    next_turn_index,
    parent_uuid_for,
    append,
    messages: list[SessionMessage],
) -> None:
    """Emit a Conductor ``queue-operation`` enqueue as a user message.

    Only ``operation=enqueue`` with a non-empty top-level ``content`` field
    carries a real user prompt; ``dequeue`` and empty enqueues are queue
    bookkeeping.
    """
    if entry.get("operation") != "enqueue":
        return
    content = entry.get("content")
    if not isinstance(content, str) or not content:
        return

    turn_index = next_turn_index()
    append(
        SessionMessage(
            uuid=build_message_uuid(session_id=session_id, turn_index=turn_index),
            session_id=session_id,
            parent_uuid=parent_uuid_for(turn_index),
            turn_index=turn_index,
            role="user",
            content=content,
            timestamp=_parse_timestamp_ms(raw=entry.get("timestamp")),
            cwd=cwd,
            dirty=True,
        )
    )
    pending_enqueue_dedup.setdefault(content, []).append(len(messages) - 1)


def _extract_text(raw: object) -> str:
    """Extract plain-text content from a transcript message payload."""
    if isinstance(raw, str):
        return raw

    if isinstance(raw, list):
        parts: list[str] = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            block = cast(dict[str, object], item)
            if block.get("type") == "text":
                text = block.get("text")
                if isinstance(text, str) and text:
                    parts.append(text)
        return "\n".join(parts)

    return ""


def _extract_tool_calls(raw: object) -> str:
    """Extract tool_use blocks into a normalized JSON string."""
    if not isinstance(raw, list):
        return ""

    calls: list[dict[str, object]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        block = cast(dict[str, object], item)
        if block.get("type") != "tool_use":
            continue
        calls.append({
            "tool_use_id": block.get("id") or "",
            "name": block.get("name") or "",
            "input": block.get("input") or {},
        })

    return json.dumps(calls, separators=(",", ":")) if calls else ""


def _extract_tool_results(raw: object) -> str:
    """Extract tool_result blocks into a normalized JSON string."""
    if not isinstance(raw, list):
        return ""

    results: list[dict[str, object]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        block = cast(dict[str, object], item)
        if block.get("type") != "tool_result":
            continue
        results.append({
            "tool_use_id": block.get("tool_use_id") or "",
            "output": block.get("content") or "",
            "is_error": bool(block.get("is_error") or False),
        })

    return json.dumps(results, separators=(",", ":")) if results else ""


def _extract_usage(
    raw: object,
) -> tuple[int, int, int, int]:
    """Extract token usage from a message usage object.

    Returns (input_tokens, output_tokens, cache_read_tokens, cache_write_tokens).
    """
    if not isinstance(raw, dict):
        return 0, 0, 0, 0

    usage = cast(dict[str, int], raw)
    return (
        usage.get("input_tokens", 0),
        usage.get("output_tokens", 0),
        usage.get("cache_read_input_tokens", 0),
        usage.get("cache_creation_input_tokens", 0),
    )


def _parse_timestamp_ms(raw: object) -> int:
    """Parse an ISO-8601 timestamp into Unix epoch milliseconds."""
    if not isinstance(raw, str) or not raw:
        return 0
    try:
        from datetime import datetime

        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return int(dt.timestamp() * 1000)
    except (ValueError, TypeError):
        return 0
