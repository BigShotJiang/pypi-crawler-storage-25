"""Session flushing service."""


from dataclasses import dataclass
from typing import Iterator

from clu.api import SyncClient
from clu.store import Store


@dataclass(frozen=True)
class NothingToFlush:
    pass


@dataclass(frozen=True)
class DryRun:
    session_count: int


@dataclass(frozen=True)
class PhaseStart:
    total: int


@dataclass(frozen=True)
class SessionFlushed:
    session_id: str


@dataclass(frozen=True)
class Done:
    flushed: int


FlushEvent = NothingToFlush | DryRun | PhaseStart | SessionFlushed | Done


def stream_flush(*, limit: int, dry_run: bool, force: bool = False) -> Iterator[FlushEvent]:
    """Flush dirty sessions and their messages, yielding progress events.

    For each dirty session, session metadata is upserted via the
    ``/sessions`` endpoint, then its messages are pushed in batches to
    the ``/session-messages`` endpoint. When ``force`` is true, all
    sessions are flushed regardless of their dirty state.
    """
    db = Store.open()
    with db:
        sessions = (
            db.sessions.list_all(limit=limit)
            if force
            else db.sessions.list_dirty(limit=limit)
        )

        if not sessions:
            yield NothingToFlush()
            return

        if dry_run:
            yield DryRun(session_count=len(sessions))
            return

        yield PhaseStart(total=len(sessions))

        sync_client = SyncClient()
        flushed = 0

        for session in sessions:
            messages = db.messages.list_for_session(
                session_id=session.id,
            )
            if messages:
                sync_client.ingest_session(
                    session=session,
                    messages=messages,
                )
                flushed += 1

            db.sessions.mark_clean(session_ids=[session.id])
            db.messages.mark_clean_for_sessions(session_ids=[session.id])
            db.commit()

            yield SessionFlushed(session_id=session.id)

        yield Done(flushed=flushed)
