"""Session persistence helpers."""


import sqlite3
import time
import uuid

from clu.models.session import Session

_SELECT_SESSION = (
    "SELECT id, agent, path, is_git_repo, git_remote_url,"
    " start_time, end_time, active, transcript_path,"
    " transcript_parsing_watermark, dirty"
    " FROM sessions"
)


def _row_to_session(row: sqlite3.Row) -> Session:
    """Convert a SQLite row into a session model."""
    return Session(
        id=str(row["id"]),
        agent=str(row["agent"]),
        path=str(row["path"]),
        is_git_repo=bool(row["is_git_repo"]) if row["is_git_repo"] is not None else True,
        git_remote_url=str(row["git_remote_url"] or ""),
        start_time=int(row["start_time"] or 0),
        end_time=int(row["end_time"] or 0),
        active=bool(row["active"]) if row["active"] is not None else True,
        transcript_path=str(row["transcript_path"] or ""),
        transcript_parsing_watermark=int(row["transcript_parsing_watermark"] or 0),
        dirty=bool(row["dirty"]) if row["dirty"] is not None else True,
    )


class SessionRepository:
    """Repository for persisted session rows."""

    def __init__(self, db: sqlite3.Connection) -> None:
        """Bind the repository to an open SQLite connection."""
        self._db = db

    def create(self, *, session: Session) -> None:
        """Insert a new session row."""
        self._db.execute(
            "INSERT INTO sessions"
            " (id, agent, path, is_git_repo, git_remote_url,"
            "  start_time, end_time, active,"
            "  transcript_path, transcript_parsing_watermark, dirty)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?)",
            (
                session.id,
                session.agent,
                session.path,
                session.is_git_repo,
                session.git_remote_url,
                session.start_time,
                session.end_time,
                session.transcript_path,
                session.transcript_parsing_watermark,
                int(session.dirty),
            ),
        )

    def active_for_path(self, *, path: str) -> Session | None:
        """Return the newest active session for a repo path."""
        row = self._db.execute(
            _SELECT_SESSION
            + " WHERE path = ? AND active = 1 ORDER BY start_time DESC LIMIT 1",
            (path,),
        ).fetchone()
        return _row_to_session(row) if row is not None else None

    def active_all(self) -> list[Session]:
        """Return all active sessions."""
        rows = self._db.execute(
            _SELECT_SESSION + " WHERE active = 1 ORDER BY start_time DESC",
        ).fetchall()
        return [_row_to_session(row) for row in rows]

    def end(self, *, session_id: str) -> None:
        """Mark a session as ended and dirty."""
        self._db.execute(
            "UPDATE sessions SET active = 0, end_time = ?, dirty = 1 WHERE id = ?",
            (int(time.time() * 1000), session_id),
        )

    def find_or_create(
        self,
        *,
        path: str,
        agent: str,
        transcript_path: str,
        is_git_repo: bool = True,
        git_remote_url: str = "",
    ) -> Session:
        """Look up an active session by path or create one."""
        row = self._db.execute(
            _SELECT_SESSION
            + " WHERE path = ? AND active = 1"
            " ORDER BY start_time DESC LIMIT 1",
            (path,),
        ).fetchone()
        if row is not None:
            session = _row_to_session(row)
            if transcript_path and transcript_path != session.transcript_path:
                self._db.execute(
                    "UPDATE sessions SET transcript_path = ?, dirty = 1 WHERE id = ?",
                    (transcript_path, session.id),
                )
                session.transcript_path = transcript_path
                session.dirty = True
            return session

        session = Session(
            id=str(uuid.uuid4()),
            agent=agent,
            path=path,
            is_git_repo=is_git_repo,
            git_remote_url=git_remote_url,
            start_time=int(time.time() * 1000),
            end_time=0,
            transcript_path=transcript_path,
            dirty=True,
        )
        self.create(session=session)
        return session

    def update_watermark(self, *, session_id: str, watermark: int) -> None:
        """Persist the transcript parsing watermark."""
        self._db.execute(
            "UPDATE sessions SET transcript_parsing_watermark = ? WHERE id = ?",
            (watermark, session_id),
        )

    def list_dirty(self, *, limit: int = 0) -> list[Session]:
        """Return dirty sessions that need to be synced."""
        query = _SELECT_SESSION + " WHERE dirty = 1 ORDER BY start_time ASC"
        if limit > 0:
            query += f" LIMIT {limit}"
        rows = self._db.execute(query).fetchall()
        return [_row_to_session(row) for row in rows]

    def list_all(self, *, limit: int = 0) -> list[Session]:
        """Return all sessions regardless of dirty state."""
        query = _SELECT_SESSION + " ORDER BY start_time ASC"
        if limit > 0:
            query += f" LIMIT {limit}"
        rows = self._db.execute(query).fetchall()
        return [_row_to_session(row) for row in rows]

    def mark_clean(self, *, session_ids: list[str]) -> None:
        """Mark synced sessions as clean."""
        if not session_ids:
            return
        placeholders = ",".join("?" for _ in session_ids)
        self._db.execute(
            f"UPDATE sessions SET dirty = 0 WHERE id IN ({placeholders})",
            session_ids,
        )

    def dirty_count(self) -> int:
        """Return the number of dirty sessions."""
        row = self._db.execute("SELECT COUNT(*) FROM sessions WHERE dirty = 1").fetchone()
        return int(row[0]) if row else 0
