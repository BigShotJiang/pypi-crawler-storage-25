"""Session message model."""


from pydantic import BaseModel


class SessionMessage(BaseModel):
    """A single turn in an agent session transcript.

    Agent-agnostic: works for Claude Code, Codex, Gemini CLI, etc.
    Tool calls and tool results are stored as JSON strings for flat
    SQLite storage.

    Attributes:
        uuid: Stable message identifier.
        parent_uuid: Parent message identifier for threading.
        session_id: Owning session identifier.
        turn_index: Zero-based turn position within the session.
        role: Message role — ``user``, ``assistant``, or ``system``.
        content: Plain-text portion of the message.
        tool_calls: JSON list of tool calls ``[{name, input, tool_use_id}]``.
        tool_results: JSON list of tool results ``[{tool_use_id, output, is_error}]``.
        model: Model identifier, e.g. ``claude-opus-4-6``, ``gpt-4.1``.
        timestamp: Unix epoch milliseconds.
        cwd: Working directory when the message was produced.
        git_branch: Git branch checked out when the message was produced.
        input_tokens: Input tokens consumed (zero for user/system turns).
        output_tokens: Output tokens produced (zero for user/system turns).
        cache_read_tokens: Tokens served from prompt cache.
        cache_write_tokens: Tokens written to prompt cache.
        dirty: Whether the message needs to be flushed to the backend.
    """

    uuid: str
    parent_uuid: str = ""
    session_id: str
    turn_index: int
    role: str
    content: str = ""
    tool_calls: str = ""
    tool_results: str = ""
    model: str = ""
    timestamp: int = 0
    cwd: str = ""
    git_branch: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    dirty: bool = True
