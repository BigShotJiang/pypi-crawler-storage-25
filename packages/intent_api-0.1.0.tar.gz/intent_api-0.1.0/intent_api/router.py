"""
IntentRouter — The single-endpoint router factory.

Creates FastAPI routers that dispatch intents to registered services.
Supports multiple surfaces (standard, admin, guest, machine) from one configuration.

Example:
    from intent_api import IntentRouter, IntentService

    router = IntentRouter(debug=True)
    router.register("Todo", TodoService())

    # Standard surface (authenticated users)
    app.include_router(router.build(
        get_user=my_auth_dependency,
        get_db=my_db_dependency,
    ))

    # Machine surface (API key auth for SDKs / M2M)
    app.include_router(router.build_machine(
        get_user=my_api_key_auth,
        get_db=my_db_dependency,
    ))
"""

import inspect
import logging
from typing import Any, Awaitable, Callable, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from intent_api.registry import ServiceRegistry
from intent_api.schemas import IntentContext, IntentRequest
from intent_api.service import IntentService

logger = logging.getLogger("intent_api")

# Type for the user-provided auth dependency
# Should accept (credentials, context) and return a user object
AuthDependency = Callable[..., Awaitable[Any]]

# Type for admin authorization check
# Should accept (user, context) and return True if authorized
AdminAuthorize = Callable[[Any, Optional[IntentContext]], bool]


# ── Debug Logging ─────────────────────────────────────────────────────────────


def _log_intent(
    intent: IntentRequest,
    user: Any,
    surface: str,
    debug_payload: bool = False,
) -> None:
    """Print a formatted debug box for an intent."""
    user_id = getattr(user, "id", user) if user else "guest"
    context_type = intent.context.type if intent.context else "none"

    logger.info("--------------------------------")
    logger.info("|")
    logger.info(f"| {surface} Intent received: {intent.model}")
    logger.info(f"| Action: {intent.action}")
    logger.info(f"| Command: {intent.command}")
    logger.info("|")
    logger.info(f"| ID: {intent.id}")
    logger.info(f"| User: {user_id}")
    logger.info(f"| Context: {context_type}")
    if debug_payload:
        logger.info(f"| Payload: {intent.payload}")
    logger.info("|")
    logger.info("--------------------------------")


# ── Dispatch ──────────────────────────────────────────────────────────────────


async def _dispatch(
    service: IntentService,
    intent: IntentRequest,
    db: Any,
    user: Any,
    context: Optional[IntentContext],
) -> Any:
    """
    Core dispatch logic. Routes an intent to the correct service method.
    Shared by all surfaces (standard, admin, guest).
    """
    common = {"db": db, "user": user, "context": context}

    if intent.action == "create":
        return await service.create(**common, payload=intent.payload)
    elif intent.action == "read":
        return await service.read(**common, id=intent.id)
    elif intent.action == "update":
        return await service.update(**common, id=intent.id, payload=intent.payload)
    elif intent.action == "delete":
        return await service.delete(**common, id=intent.id)
    elif intent.action == "list":
        return await service.list(**common, skip=intent.skip, limit=intent.limit)
    elif intent.action == "custom":
        if not intent.command:
            raise HTTPException(
                status_code=400, detail="Missing 'command' for custom action."
            )
        return await service.custom_action(
            **common, command=intent.command, id=intent.id, payload=intent.payload
        )
    else:
        raise HTTPException(
            status_code=400, detail=f"Unknown action '{intent.action}'."
        )


# ── Router Factory ────────────────────────────────────────────────────────────


class IntentRouter:
    """
    Factory for creating intent-based FastAPI routers.

    Usage:
        router = IntentRouter(debug=True, debug_payload=True)
        router.register("Todo", TodoService())
        router.register("User", UserService())

        app.include_router(router.build(
            get_user=my_auth_dependency,
            get_db=my_db_dependency,
        ))

    Args:
        prefix: URL prefix for all intent endpoints. Defaults to "/api".
        debug: Enable debug logging for all intents. Defaults to False.
        debug_payload: Also log the payload (may contain sensitive data — DEV only). Defaults to False.
    """

    def __init__(
        self,
        prefix: str = "/api",
        debug: bool = False,
        debug_payload: bool = False,
    ) -> None:
        self._registry = ServiceRegistry()
        self._prefix = prefix
        self._debug = debug
        self._debug_payload = debug_payload

    # ── Registration ──────────────────────────────────────────────────────

    def register(self, model: str, service: IntentService) -> None:
        """Register an IntentService for a model name."""
        self._registry.register(model, service)

    # ── Registry Inspector (for DevTools) ─────────────────────────────────

    def _build_registry_map(self) -> Dict[str, Any]:
        """
        Introspect the service registry and return file paths + line numbers
        for every registered service method. Used by the debug endpoint.
        """
        registry_map = {}

        for model_name in self._registry.models:
            service = self._registry.get(model_name)
            if not service:
                continue

            # Get the source file for this service class
            try:
                source_file = inspect.getfile(service.__class__)
            except (TypeError, OSError):
                source_file = "unknown"

            # Get line numbers for each CRUD method + custom_action
            methods = {}
            for method_name in ["create", "read", "update", "delete", "list", "custom_action"]:
                method = getattr(service.__class__, method_name, None)
                if method is None:
                    continue
                try:
                    _, line_number = inspect.getsourcelines(method)
                    # Use "custom" as the display key for custom_action
                    display_key = "custom" if method_name == "custom_action" else method_name
                    methods[display_key] = line_number
                except (TypeError, OSError):
                    pass

            registry_map[model_name] = {
                "service": service.__class__.__name__,
                "file": source_file,
                "methods": methods,
            }

        return registry_map

    def build_debug_router(self) -> APIRouter:
        """
        Build a debug router with the registry inspection endpoint.
        Only mount this when debug=True.

        Returns a router with:
          GET /api/intent-debug/registry → file paths + line numbers for all services
        """
        debug_router = APIRouter(tags=["Intent API (Debug)"])
        endpoint = f"{self._prefix}/intent-debug/registry"

        @debug_router.get(endpoint)
        async def get_registry_map():
            return self._build_registry_map()

        return debug_router

    @property
    def registry(self) -> ServiceRegistry:
        """Access the underlying service registry."""
        return self._registry

    # ── Standard Surface ──────────────────────────────────────────────────

    def build(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        path: str = "/intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the standard authenticated intent router.

        Args:
            get_user: FastAPI dependency that returns the authenticated user.
            get_db: FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        api_router = APIRouter(tags=tags or ["Intent API"])
        registry = self._registry
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            # Resolve user
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Standard", debug_payload)

            # Look up service
            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            if service.is_admin_only:
                raise HTTPException(
                    status_code=403, detail="Admin access required."
                )

            return await _dispatch(service, intent, db, user, intent.context)

        return api_router

    # ── Admin Surface ─────────────────────────────────────────────────────

    def build_admin(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        authorize: AdminAuthorize,
        path: str = "/admin-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the admin intent router with an additional authorization check.

        Args:
            get_user: FastAPI dependency that returns the authenticated user.
            get_db: FastAPI dependency that yields a database session.
            authorize: A callable (user, context) -> bool that returns True
                if the user is authorized for admin access.
            path: Endpoint path (appended to prefix). Defaults to "/admin-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        api_router = APIRouter(tags=tags or ["Intent API (Admin)"])
        registry = self._registry
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_admin_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Admin", debug_payload)

            # Admin authorization gate
            if not authorize(user, intent.context):
                raise HTTPException(
                    status_code=403, detail="Admin access required."
                )

            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            return await _dispatch(service, intent, db, user, intent.context)

        return api_router

    # ── Machine Surface (API Key Auth) ──────────────────────────────────

    def build_machine(
        self,
        *,
        get_user: AuthDependency,
        get_db: Callable,
        path: str = "/machine-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the machine-to-machine intent router (API key auth).

        For SDK clients, external services, and M2M communication.
        Auth is handled by the provided get_user dependency, which
        should verify an API key (e.g., Clerk API keys, custom keys)
        instead of a JWT token.

        The get_user function receives (credentials, context, db) just like
        the standard surface — but credentials will contain an API key
        instead of a JWT. Your get_user implementation decides how to verify it.

        Args:
            get_user: FastAPI dependency that verifies the API key and returns a user/context.
            get_db: FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/machine-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.

        Example:
            async def get_machine_user(credentials, context, db):
                api_key = credentials.credentials  # "sk_live_xxx"
                # Verify with Clerk API keys or your own key table
                project = verify_api_key(db, api_key)
                return project.owner  # Return the user who owns this key

            app.include_router(intent_router.build_machine(
                get_user=get_machine_user,
                get_db=get_db,
            ))
        """
        api_router = APIRouter(tags=tags or ["Intent API (Machine)"])
        registry = self._registry
        security = HTTPBearer()
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        @api_router.post(endpoint)
        async def handle_machine_intent(
            intent: IntentRequest,
            request: Request,
            db=Depends(get_db),
            credentials: HTTPAuthorizationCredentials = Depends(security),
        ):
            # Resolve user via API key
            user = await get_user(credentials=credentials, context=intent.context, db=db)

            # Debug log
            if debug:
                _log_intent(intent, user, "Machine", debug_payload)

            # Look up service
            service = registry.get(intent.model)
            if not service:
                raise HTTPException(
                    status_code=404,
                    detail=f"Model '{intent.model}' not registered.",
                )

            return await _dispatch(service, intent, db, user, intent.context)

        return api_router

    # ── Guest Surface ─────────────────────────────────────────────────────

    def build_guest(
        self,
        *,
        get_db: Optional[Callable] = None,
        path: str = "/guest-intent",
        tags: Optional[list[str]] = None,
    ) -> APIRouter:
        """
        Build the guest (unauthenticated) intent router.

        Only services with `is_guest_allowed = True` are accessible.
        Only actions in `allowed_guest_actions` are permitted.

        Args:
            get_db: Optional FastAPI dependency that yields a database session.
            path: Endpoint path (appended to prefix). Defaults to "/guest-intent".
            tags: Optional OpenAPI tags.

        Returns:
            A FastAPI APIRouter with a single POST endpoint.
        """
        api_router = APIRouter(tags=tags or ["Intent API (Guest)"])
        registry = self._registry
        endpoint = f"{self._prefix}{path}"
        debug = self._debug
        debug_payload = self._debug_payload

        if get_db:

            @api_router.post(endpoint)
            async def handle_guest_intent_with_db(
                intent: IntentRequest,
                request: Request,
                db=Depends(get_db),
            ):
                return await _handle_guest(registry, intent, db=db, debug=debug, debug_payload=debug_payload)

        else:

            @api_router.post(endpoint)
            async def handle_guest_intent(
                intent: IntentRequest,
                request: Request,
            ):
                return await _handle_guest(registry, intent, db=None, debug=debug, debug_payload=debug_payload)

        return api_router


async def _handle_guest(
    registry: ServiceRegistry,
    intent: IntentRequest,
    db: Any = None,
    debug: bool = False,
    debug_payload: bool = False,
) -> Any:
    """Shared guest dispatch logic."""
    # Debug log
    if debug:
        _log_intent(intent, None, "Guest", debug_payload)

    service = registry.get(intent.model)
    if not service:
        raise HTTPException(
            status_code=404, detail="This action is not allowed."
        )

    if not service.guest_allowed(intent.action, intent.command):
        raise HTTPException(
            status_code=403,
            detail="You don't have permission to perform this action.",
        )

    # Guests can only read, list, or use allowed custom commands
    if intent.action not in ("read", "list", "custom"):
        raise HTTPException(
            status_code=403, detail="Guests can only read or list."
        )

    return await _dispatch(service, intent, db=db, user=None, context=intent.context)
