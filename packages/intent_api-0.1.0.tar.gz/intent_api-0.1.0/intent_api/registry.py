"""
ServiceRegistry — Maps model names to IntentService instances.

The registry is the central dispatch table. When an intent arrives,
the router looks up the model name here to find the right service.

Example:
    registry = ServiceRegistry()
    registry.register("Todo", TodoService())
    registry.register("User", UserService())

    service = registry.get("Todo")  # → TodoService instance
"""

import logging
from typing import Dict, Optional

from intent_api.service import IntentService

logger = logging.getLogger("intent_api")


class ServiceRegistry:
    """
    A registry that maps model names to IntentService instances.

    Thread-safe for reads (lookups during request handling).
    Registration should happen at startup before serving requests.
    """

    def __init__(self) -> None:
        self._services: Dict[str, IntentService] = {}

    def register(self, model: str, service: IntentService) -> None:
        """
        Register an IntentService for a model name.

        Args:
            model: The model name (e.g., "User", "Order"). Case-sensitive.
            service: An instance of an IntentService subclass.

        Raises:
            TypeError: If service is not an IntentService instance.
            ValueError: If a service is already registered for this model.
        """
        if not isinstance(service, IntentService):
            raise TypeError(
                f"Expected an IntentService instance, got {type(service).__name__}. "
                f"Make sure {type(service).__name__} extends IntentService."
            )

        if model in self._services:
            raise ValueError(
                f"Model '{model}' is already registered to {type(self._services[model]).__name__}. "
                f"Each model name can only have one service."
            )

        self._services[model] = service
        logger.info(f"Registered intent service: {model} → {type(service).__name__}")

    def get(self, model: str) -> Optional[IntentService]:
        """Look up the IntentService for a model name. Returns None if not found."""
        return self._services.get(model)

    def has(self, model: str) -> bool:
        """Check if a model name is registered."""
        return model in self._services

    @property
    def models(self) -> list[str]:
        """List all registered model names."""
        return list(self._services.keys())

    def __len__(self) -> int:
        return len(self._services)

    def __repr__(self) -> str:
        models = ", ".join(self.models)
        return f"<ServiceRegistry [{models}]>"
