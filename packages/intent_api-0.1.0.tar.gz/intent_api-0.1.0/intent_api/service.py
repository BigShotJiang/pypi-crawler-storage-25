"""
IntentService — The abstract base class for all intent handlers.

Every model in your application gets one IntentService subclass.
The framework dispatches intents to the correct method based on the action.

Example:
    class TodoService(IntentService):
        async def create(self, *, db, user, context, payload):
            todo = Todo(**payload)
            db.add(todo)
            db.commit()
            return MutationResponse(success=True, id=str(todo.id))

        async def list(self, *, db, user, context, skip, limit):
            todos = db.query(Todo).offset(skip).limit(limit).all()
            return {"items": todos, "total": len(todos)}
"""

from abc import ABC, abstractmethod
from typing import Any, Optional

from pydantic import BaseModel

from intent_api.schemas import IntentContext


class MutationResponse(BaseModel):
    """Standard response for create/update/delete operations."""

    success: bool
    message: Optional[str] = None
    id: Optional[str] = None
    data: Optional[dict] = None


class IntentService(ABC):
    """
    Abstract base class for intent service handlers.

    Subclass this for each model/resource in your application.
    Override the methods you need — unimplemented methods will
    return a 501 Not Implemented response by default.

    Class Attributes:
        is_admin_only: If True, this service is only accessible via admin surfaces.
        is_guest_allowed: If True, unauthenticated users can access this service.
        allowed_guest_actions: List of action strings allowed for guests.
            If None and is_guest_allowed is True, all actions are allowed.
    """

    is_admin_only: bool = False
    is_guest_allowed: bool = False
    allowed_guest_actions: Optional[list[str]] = None

    # ── CRUD + List ───────────────────────────────────────────────────────

    async def create(
        self,
        *,
        db: Any,
        user: Any,
        context: Optional[IntentContext] = None,
        payload: Optional[dict] = None,
    ) -> Any:
        """Handle 'create' intents. Override in your subclass."""
        raise NotImplementedError(f"{self.__class__.__name__} does not support 'create'.")

    async def read(
        self,
        *,
        db: Any,
        user: Any,
        id: Any,
        context: Optional[IntentContext] = None,
    ) -> Any:
        """Handle 'read' intents. Override in your subclass."""
        raise NotImplementedError(f"{self.__class__.__name__} does not support 'read'.")

    async def update(
        self,
        *,
        db: Any,
        user: Any,
        id: Any,
        context: Optional[IntentContext] = None,
        payload: Optional[dict] = None,
    ) -> Any:
        """Handle 'update' intents. Override in your subclass."""
        raise NotImplementedError(f"{self.__class__.__name__} does not support 'update'.")

    async def delete(
        self,
        *,
        db: Any,
        user: Any,
        id: Any,
        context: Optional[IntentContext] = None,
    ) -> Any:
        """Handle 'delete' intents. Override in your subclass."""
        raise NotImplementedError(f"{self.__class__.__name__} does not support 'delete'.")

    async def list(
        self,
        *,
        db: Any,
        user: Any,
        context: Optional[IntentContext] = None,
        skip: int = 0,
        limit: int = 10,
    ) -> Any:
        """Handle 'list' intents. Override in your subclass."""
        raise NotImplementedError(f"{self.__class__.__name__} does not support 'list'.")

    # ── Custom Commands ───────────────────────────────────────────────────

    async def custom_action(
        self,
        *,
        db: Any,
        user: Any,
        context: Optional[IntentContext] = None,
        command: str,
        id: Optional[Any] = None,
        payload: Optional[dict] = None,
    ) -> Any:
        """
        Handle 'custom' intents with named commands.
        
        Override in your subclass. Dispatch to specific methods
        based on the command string.

        Example:
            async def custom_action(self, *, db, user, context, command, id, payload):
                if command == "archive":
                    return await self._archive(db=db, user=user, id=id)
                elif command == "export_csv":
                    return await self._export_csv(db=db, user=user, payload=payload)
                raise ValueError(f"Unknown command: {command}")
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not support custom command '{command}'."
        )

    # ── Guest Access Control ──────────────────────────────────────────────

    def guest_allowed(self, action: str, command: Optional[str] = None) -> bool:
        """Check if a guest (unauthenticated user) can perform this action."""
        if not self.is_guest_allowed:
            return False
        if self.allowed_guest_actions is None:
            return True
        action_key = f"custom:{command}" if action == "custom" and command else action
        return action_key in self.allowed_guest_actions

    # ── Context Helpers ───────────────────────────────────────────────────

    @staticmethod
    def get_context_value(context: Optional[IntentContext], key: str) -> Optional[str]:
        """Safely extract a value from the intent context."""
        if not context:
            return None
        return getattr(context, key, None)
