"""
Intent API — A constraint-driven API framework for Python.

One endpoint. Typed intents. Zero boilerplate.

Usage:
    from intent_api import IntentRouter, IntentService, IntentRequest, IntentContext

    router = IntentRouter()

    class UserService(IntentService):
        async def create(self, *, db, user, context, payload):
            ...

    router.register("User", UserService())
    app.include_router(router.build())
"""

from intent_api.schemas import IntentRequest, IntentContext
from intent_api.service import IntentService
from intent_api.registry import ServiceRegistry
from intent_api.router import IntentRouter

__version__ = "0.1.0"

__all__ = [
    "IntentRequest",
    "IntentContext",
    "IntentService",
    "ServiceRegistry",
    "IntentRouter",
]
