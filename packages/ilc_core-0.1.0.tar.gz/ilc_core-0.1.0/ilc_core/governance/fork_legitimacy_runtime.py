# PUBLIC_RC_EXCLUDE: cdl_009_fork_legitimacy_ux_phase_1383.v0.1
# PUBLIC_RC_EXCLUDE_REASON: Phase 1383 governance fork-signal inspection helper only; no public API, graph write, or governance activation authority.
# PUBLIC_RC_INCLUDE_REQUIRES: public_rc_allowlist_review_and_explicit_governance_activation_authorization

"""CDL-009 fork-legitimacy operator inspection runtime.

This module implements the Phase 1383 CDL-009 badge schema, eligibility-rules
contract, and CLI/operator inspection surface. It validates and inspects
fork-signal artifacts only. It does not verify cryptographic signatures itself,
serve a public API, write graph state, or grant governance authority.
"""

from __future__ import annotations

import argparse
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any


FORK_LEGITIMACY_RUNTIME_VERSION = "cdl_009_fork_legitimacy_ux_phase_1383.v0.1"
CDL009_FORK_LEGITIMACY_UX_TOKEN = FORK_LEGITIMACY_RUNTIME_VERSION
CDL009_SIGNATURE_BADGE_SCHEMA_TOKEN = "cdl_009_signature_badge_schema_implemented"
CDL009_ELIGIBILITY_RULES_CONTRACT_TOKEN = (
    "cdl_009_eligibility_rules_contract_committed"
)

FORK_LEGITIMACY_BADGE_SCHEMA_VERSION = "cdl_009_fork_legitimacy_badge_v1"
FORK_ELIGIBILITY_RULE_VERSION = "cdl_009_eligibility_rules_v1"
FORK_SIGNAL_SCHEMA_VERSION = "cdl_009_fork_signal_v1"
FORK_SIGNAL_INSPECTION_RESULT_SCHEMA_VERSION = (
    "cdl_009_fork_signal_inspection_result_v1"
)
MAX_FORK_SIGNAL_JSON_BYTES = 1_048_576

ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH = (
    "ddc686019018e05f3d88be1a879663c7c2756823bf8bc7fbf980743a92fc6c3c"
)

REQUIRED_SIGNATURE_BADGE_FIELDS = (
    "authority_scope",
    "badge_id",
    "badge_schema_version",
    "canonical_genesis_root_hash",
    "evidence_refs",
    "fork_id",
    "fork_root_ref",
    "issued_epoch",
    "lineage_proof_ref",
    "signature_algorithm",
    "signature_ref",
    "signature_verification_status",
    "signer_authority",
)
REQUIRED_ELIGIBILITY_EVIDENCE_FIELDS = (
    "canonical_genesis_lineage",
    "canonical_genesis_root_hash",
    "eligibility_rule_version",
    "fork_root_ref",
    "lineage_proof_ref",
    "no_stripped_public_legitimacy_chain",
    "not_naming_only",
    "public_identity_lineage_ref",
    "public_legitimacy_chain",
    "public_quorum_lineage_ref",
    "settlement_lineage_ref",
)
REQUIRED_FORK_SIGNAL_FIELDS = (
    "eligibility_evidence",
    "fork_id",
    "fork_root_ref",
    "signal_schema_version",
    "signature_badge",
)

AUTHORITY_SCOPE_VALUES = ("fork_legitimacy", "canonical_lineage_fork_legitimacy")
SIGNER_AUTHORITY_VALUES = ("genesis_authority", "authorized_successor_governance")
SIGNATURE_ALGORITHM_VALUES = (
    "ML-DSA-65",
    "COSE_Sign1_ML-DSA-65",
    "COSE_Sign1_Ed25519",
    "Ed25519",
)
SIGNATURE_VERIFICATION_STATUS_VALUES = ("verified", "unverified", "not_checked")


@dataclass(frozen=True)
class ForkLegitimacyBadge:
    """Schema carrier for the CDL-009 signature badge."""

    badge_id: str
    badge_schema_version: str
    fork_id: str
    fork_root_ref: str
    canonical_genesis_root_hash: str
    lineage_proof_ref: str
    authority_scope: str
    signer_authority: str
    signature_algorithm: str
    signature_ref: str
    signature_verification_status: str
    issued_epoch: int
    evidence_refs: tuple[str, ...]


@dataclass(frozen=True)
class ForkEligibilityEvidence:
    """Schema carrier for CDL-009 eligibility evidence."""

    eligibility_rule_version: str
    fork_root_ref: str
    canonical_genesis_root_hash: str
    lineage_proof_ref: str
    public_identity_lineage_ref: str
    public_quorum_lineage_ref: str
    settlement_lineage_ref: str
    canonical_genesis_lineage: bool
    public_legitimacy_chain: bool
    no_stripped_public_legitimacy_chain: bool
    not_naming_only: bool


def canonical_json(payload: Mapping[str, Any]) -> str:
    """Return deterministic JSON for CDL-009 operator artifacts."""

    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


def signature_badge_schema() -> dict[str, Any]:
    """Return the CDL-009 signature-badge field contract."""

    return {
        "authority_scope_enum": list(AUTHORITY_SCOPE_VALUES),
        "canonical_genesis_root_hash": ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH,
        "required_fields": list(REQUIRED_SIGNATURE_BADGE_FIELDS),
        "schema_version": FORK_LEGITIMACY_BADGE_SCHEMA_VERSION,
        "signature_algorithm_enum": list(SIGNATURE_ALGORITHM_VALUES),
        "signature_verification_status_enum": list(
            SIGNATURE_VERIFICATION_STATUS_VALUES
        ),
        "signer_authority_enum": list(SIGNER_AUTHORITY_VALUES),
        "schema_token": CDL009_SIGNATURE_BADGE_SCHEMA_TOKEN,
        "runtime_token": CDL009_FORK_LEGITIMACY_UX_TOKEN,
    }


def eligibility_rules_contract() -> dict[str, Any]:
    """Return the Phase 1383 CDL-009 eligibility-rules contract."""

    return {
        "canonical_genesis_root_hash": ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH,
        "forbidden_models": ["naming-only", "bare signature-badge"],
        "required_evidence_fields": list(REQUIRED_ELIGIBILITY_EVIDENCE_FIELDS),
        "required_rules": [
            "signature_badge_must_be_present_and_verified",
            "fork_root_and_fork_id_must_match_across_signal_badge_and_evidence",
            "canonical_genesis_root_hash_must_match_adr_0037",
            "lineage_proof_ref_must_match_across_badge_and_evidence",
            "canonical_genesis_lineage_must_be_present",
            "public_legitimacy_chain_must_be_present",
            "stripped_public_legitimacy_chain_must_fail_closed",
            "naming_only_signal_must_fail_closed",
        ],
        "rule_version": FORK_ELIGIBILITY_RULE_VERSION,
        "contract_token": CDL009_ELIGIBILITY_RULES_CONTRACT_TOKEN,
        "runtime_token": CDL009_FORK_LEGITIMACY_UX_TOKEN,
    }


def fork_signal_schema() -> dict[str, Any]:
    """Return the CDL-009 fork-signal inspection schema."""

    return {
        "eligibility_rules_contract": eligibility_rules_contract(),
        "required_fields": list(REQUIRED_FORK_SIGNAL_FIELDS),
        "schema_version": FORK_SIGNAL_SCHEMA_VERSION,
        "signature_badge_schema": signature_badge_schema(),
        "runtime_token": CDL009_FORK_LEGITIMACY_UX_TOKEN,
    }


def canonical_schema_bundle_json() -> str:
    """Return deterministic JSON for the CDL-009 schema bundle."""

    return canonical_json(fork_signal_schema())


def validate_signature_badge(badge: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and normalize a CDL-009 signature badge."""

    record = _require_mapping(badge, "signature_badge_must_be_mapping")
    _require_fields(
        record, REQUIRED_SIGNATURE_BADGE_FIELDS, "signature_badge_missing_required_field"
    )
    return {
        "authority_scope": _require_enum(
            record["authority_scope"],
            AUTHORITY_SCOPE_VALUES,
            "signature_badge_authority_scope_invalid",
        ),
        "badge_id": _require_non_empty_string(
            record["badge_id"], "signature_badge_id_must_be_non_empty_string"
        ),
        "badge_schema_version": _require_exact_string(
            record["badge_schema_version"],
            FORK_LEGITIMACY_BADGE_SCHEMA_VERSION,
            "signature_badge_schema_version_invalid",
        ),
        "canonical_genesis_root_hash": _normalize_genesis_hash(
            record["canonical_genesis_root_hash"],
            "signature_badge_genesis_root_hash_invalid",
        ),
        "evidence_refs": _normalize_ref_sequence(
            record["evidence_refs"], "signature_badge_evidence_refs_invalid"
        ),
        "fork_id": _require_non_empty_string(
            record["fork_id"], "signature_badge_fork_id_must_be_non_empty_string"
        ),
        "fork_root_ref": _require_non_empty_string(
            record["fork_root_ref"],
            "signature_badge_fork_root_ref_must_be_non_empty_string",
        ),
        "issued_epoch": _require_non_negative_int(
            record["issued_epoch"], "signature_badge_issued_epoch_must_be_non_negative_int"
        ),
        "lineage_proof_ref": _require_non_empty_string(
            record["lineage_proof_ref"],
            "signature_badge_lineage_proof_ref_must_be_non_empty_string",
        ),
        "signature_algorithm": _require_enum(
            record["signature_algorithm"],
            SIGNATURE_ALGORITHM_VALUES,
            "signature_badge_algorithm_invalid",
        ),
        "signature_ref": _require_non_empty_string(
            record["signature_ref"], "signature_badge_signature_ref_must_be_non_empty_string"
        ),
        "signature_verification_status": _require_enum(
            record["signature_verification_status"],
            SIGNATURE_VERIFICATION_STATUS_VALUES,
            "signature_badge_verification_status_invalid",
        ),
        "signer_authority": _require_enum(
            record["signer_authority"],
            SIGNER_AUTHORITY_VALUES,
            "signature_badge_signer_authority_invalid",
        ),
    }


def validate_eligibility_evidence(evidence: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and normalize CDL-009 eligibility evidence."""

    record = _require_mapping(evidence, "eligibility_evidence_must_be_mapping")
    _require_fields(
        record,
        REQUIRED_ELIGIBILITY_EVIDENCE_FIELDS,
        "eligibility_evidence_missing_required_field",
    )
    return {
        "canonical_genesis_lineage": _require_bool(
            record["canonical_genesis_lineage"],
            "eligibility_canonical_genesis_lineage_must_be_bool",
        ),
        "canonical_genesis_root_hash": _normalize_genesis_hash(
            record["canonical_genesis_root_hash"],
            "eligibility_genesis_root_hash_invalid",
        ),
        "eligibility_rule_version": _require_exact_string(
            record["eligibility_rule_version"],
            FORK_ELIGIBILITY_RULE_VERSION,
            "eligibility_rule_version_invalid",
        ),
        "fork_root_ref": _require_non_empty_string(
            record["fork_root_ref"], "eligibility_fork_root_ref_must_be_non_empty_string"
        ),
        "lineage_proof_ref": _require_non_empty_string(
            record["lineage_proof_ref"],
            "eligibility_lineage_proof_ref_must_be_non_empty_string",
        ),
        "no_stripped_public_legitimacy_chain": _require_bool(
            record["no_stripped_public_legitimacy_chain"],
            "eligibility_no_stripped_chain_must_be_bool",
        ),
        "not_naming_only": _require_bool(
            record["not_naming_only"], "eligibility_not_naming_only_must_be_bool"
        ),
        "public_identity_lineage_ref": _require_non_empty_string(
            record["public_identity_lineage_ref"],
            "eligibility_public_identity_lineage_ref_must_be_non_empty_string",
        ),
        "public_legitimacy_chain": _require_bool(
            record["public_legitimacy_chain"],
            "eligibility_public_legitimacy_chain_must_be_bool",
        ),
        "public_quorum_lineage_ref": _require_non_empty_string(
            record["public_quorum_lineage_ref"],
            "eligibility_public_quorum_lineage_ref_must_be_non_empty_string",
        ),
        "settlement_lineage_ref": _require_non_empty_string(
            record["settlement_lineage_ref"],
            "eligibility_settlement_lineage_ref_must_be_non_empty_string",
        ),
    }


def validate_fork_signal(fork_signal: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and normalize a CDL-009 fork-signal inspection artifact."""

    record = _require_mapping(fork_signal, "fork_signal_must_be_mapping")
    _require_fields(record, REQUIRED_FORK_SIGNAL_FIELDS, "fork_signal_missing_required_field")
    return {
        "eligibility_evidence": validate_eligibility_evidence(
            record["eligibility_evidence"]
        ),
        "fork_id": _require_non_empty_string(
            record["fork_id"], "fork_signal_fork_id_must_be_non_empty_string"
        ),
        "fork_root_ref": _require_non_empty_string(
            record["fork_root_ref"], "fork_signal_fork_root_ref_must_be_non_empty_string"
        ),
        "signal_schema_version": _require_exact_string(
            record["signal_schema_version"],
            FORK_SIGNAL_SCHEMA_VERSION,
            "fork_signal_schema_version_invalid",
        ),
        "signature_badge": validate_signature_badge(record["signature_badge"]),
    }


def signature_badge_ref(badge: Mapping[str, Any]) -> str:
    """Return a deterministic SHA-256 reference for a validated CDL-009 badge."""

    normalized = validate_signature_badge(badge)
    return _sha256_ref(normalized)


def inspect_fork_signal(fork_signal: Mapping[str, Any]) -> dict[str, Any]:
    """Inspect a fork signal and return a deterministic eligibility decision."""

    normalized = validate_fork_signal(fork_signal)
    badge = normalized["signature_badge"]
    evidence = normalized["eligibility_evidence"]

    failed_rules: list[str] = []
    if badge["signature_verification_status"] != "verified":
        failed_rules.append("signature_badge_not_verified")
    if badge["canonical_genesis_root_hash"] != ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH:
        failed_rules.append("signature_badge_genesis_root_mismatch")
    if evidence["canonical_genesis_root_hash"] != ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH:
        failed_rules.append("eligibility_genesis_root_mismatch")
    if normalized["fork_id"] != badge["fork_id"]:
        failed_rules.append("signal_badge_fork_id_mismatch")
    if normalized["fork_root_ref"] != badge["fork_root_ref"]:
        failed_rules.append("signal_badge_fork_root_ref_mismatch")
    if normalized["fork_root_ref"] != evidence["fork_root_ref"]:
        failed_rules.append("signal_evidence_fork_root_ref_mismatch")
    if badge["lineage_proof_ref"] != evidence["lineage_proof_ref"]:
        failed_rules.append("lineage_proof_ref_mismatch")
    if not evidence["canonical_genesis_lineage"]:
        failed_rules.append("canonical_genesis_lineage_missing")
    if not evidence["public_legitimacy_chain"]:
        failed_rules.append("public_legitimacy_chain_missing")
    if not evidence["no_stripped_public_legitimacy_chain"]:
        failed_rules.append("stripped_public_legitimacy_chain")
    if not evidence["not_naming_only"]:
        failed_rules.append("naming_only_signal_forbidden")

    badge_ref = signature_badge_ref(badge)
    eligible = not failed_rules
    return {
        "badge_ref": badge_ref,
        "decision": "eligible" if eligible else "not_eligible",
        "eligible_for_legitimacy_badge": eligible,
        "failed_rules": failed_rules,
        "fork_id": normalized["fork_id"],
        "fork_root_ref": normalized["fork_root_ref"],
        "operator_surface": "cli_local_only_no_public_api",
        "public_api_activation": False,
        "runtime_token": CDL009_FORK_LEGITIMACY_UX_TOKEN,
        "schema_version": FORK_SIGNAL_INSPECTION_RESULT_SCHEMA_VERSION,
        "tokens": [
            CDL009_FORK_LEGITIMACY_UX_TOKEN,
            CDL009_SIGNATURE_BADGE_SCHEMA_TOKEN,
            CDL009_ELIGIBILITY_RULES_CONTRACT_TOKEN,
        ],
    }


def load_fork_signal_json_file(
    path: str | Path,
    *,
    max_bytes: int = MAX_FORK_SIGNAL_JSON_BYTES,
) -> dict[str, Any]:
    """Load a bounded local fork-signal JSON object for operator inspection."""

    signal_path = Path(path)
    if max_bytes <= 0:
        raise ValueError("fork_signal_max_bytes_must_be_positive")
    if signal_path.stat().st_size > max_bytes:
        raise ValueError("fork_signal_json_file_too_large")
    payload = json.loads(signal_path.read_bytes().decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("fork_signal_json_must_be_object")
    return payload


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entrypoint for local operator fork-signal inspection."""

    parser = argparse.ArgumentParser(
        description="Inspect a local CDL-009 fork-signal JSON artifact."
    )
    parser.add_argument("fork_signal_json", help="Path to the fork-signal JSON file")
    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Print indented JSON instead of canonical compact JSON",
    )
    args = parser.parse_args(argv)

    payload = load_fork_signal_json_file(args.fork_signal_json)
    result = inspect_fork_signal(payload)
    if args.pretty:
        print(json.dumps(result, sort_keys=True, indent=2, allow_nan=False))
    else:
        print(canonical_json(result))
    return 0 if result["eligible_for_legitimacy_badge"] else 1


def _require_mapping(value: Any, token: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(token)
    return value


def _require_fields(record: Mapping[str, Any], fields: Sequence[str], token: str) -> None:
    for field in fields:
        if field not in record:
            raise ValueError(f"{token}:{field}")


def _require_non_empty_string(value: Any, token: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(token)
    return value


def _require_exact_string(value: Any, expected: str, token: str) -> str:
    text = _require_non_empty_string(value, token)
    if text != expected:
        raise ValueError(token)
    return text


def _require_non_negative_int(value: Any, token: str) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(token)
    return value


def _require_bool(value: Any, token: str) -> bool:
    if type(value) is not bool:
        raise ValueError(token)
    return value


def _require_enum(value: Any, allowed_values: Sequence[str], token: str) -> str:
    text = _require_non_empty_string(value, token)
    if text not in allowed_values:
        raise ValueError(token)
    return text


def _normalize_ref_sequence(value: Any, token: str) -> list[str]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(token)
    return [_require_non_empty_string(item, token) for item in value]


def _normalize_genesis_hash(value: Any, token: str) -> str:
    text = _require_non_empty_string(value, token)
    normalized = text.removeprefix("sha256:")
    if normalized != ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH:
        raise ValueError(token)
    return normalized


def _sha256_ref(payload: Mapping[str, Any]) -> str:
    digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


__all__ = [
    "ADR0037_GENESIS_V0_1_ROOT_ENVELOPE_HASH",
    "AUTHORITY_SCOPE_VALUES",
    "CDL009_ELIGIBILITY_RULES_CONTRACT_TOKEN",
    "CDL009_FORK_LEGITIMACY_UX_TOKEN",
    "CDL009_SIGNATURE_BADGE_SCHEMA_TOKEN",
    "FORK_ELIGIBILITY_RULE_VERSION",
    "FORK_LEGITIMACY_BADGE_SCHEMA_VERSION",
    "FORK_LEGITIMACY_RUNTIME_VERSION",
    "FORK_SIGNAL_INSPECTION_RESULT_SCHEMA_VERSION",
    "FORK_SIGNAL_SCHEMA_VERSION",
    "MAX_FORK_SIGNAL_JSON_BYTES",
    "ForkEligibilityEvidence",
    "ForkLegitimacyBadge",
    "REQUIRED_ELIGIBILITY_EVIDENCE_FIELDS",
    "REQUIRED_FORK_SIGNAL_FIELDS",
    "REQUIRED_SIGNATURE_BADGE_FIELDS",
    "SIGNATURE_ALGORITHM_VALUES",
    "SIGNATURE_VERIFICATION_STATUS_VALUES",
    "SIGNER_AUTHORITY_VALUES",
    "canonical_json",
    "canonical_schema_bundle_json",
    "eligibility_rules_contract",
    "fork_signal_schema",
    "inspect_fork_signal",
    "load_fork_signal_json_file",
    "main",
    "signature_badge_ref",
    "signature_badge_schema",
    "validate_eligibility_evidence",
    "validate_fork_signal",
    "validate_signature_badge",
]


if __name__ == "__main__":
    raise SystemExit(main())
