# PUBLIC_RC_EXCLUDE: cdl_006_challenge_node_runtime_phase_1382.v0.1
# PUBLIC_RC_EXCLUDE_REASON: Phase 1382 governance challenge-node runtime helper only; no public serving or governance activation authority.
# PUBLIC_RC_INCLUDE_REQUIRES: public_rc_allowlist_review_and_explicit_governance_activation_authorization

"""CDL-006 challenge-node runtime.

Phase 1382 implements the CDL-006 challenge-node schema checks, 3-body
affirmative quorum verifier, and deterministic audit-path record writer. This
module does not decide when challenges are invoked, execute governance
decisions, write graph state, or activate public serving.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import hashlib
import json
from typing import Any


CHALLENGE_NODE_RUNTIME_VERSION = "cdl_006_challenge_node_runtime_phase_1382.v0.1"
CHALLENGE_NODE_RUNTIME_STUB_VERSION = "challenge_node_runtime_stub_1381.v0.1"
CDL006_CHALLENGE_NODE_SPEC_TOKEN = "cdl_006_challenge_node_spec_phase_1381"
CDL006_CHALLENGE_NODE_RUNTIME_STUB_TOKEN = (
    "cdl_006_challenge_node_runtime_stub_phase_1381"
)
CDL006_CHALLENGE_NODE_RUNTIME_TOKEN = CHALLENGE_NODE_RUNTIME_VERSION
CDL006_3_BODY_QUORUM_VERIFICATION_TOKEN = (
    "cdl_006_3_body_quorum_verification_implemented"
)
CDL006_AUDIT_PATH_RECORD_WRITER_TOKEN = (
    "cdl_006_audit_path_record_writer_implemented"
)
CDL006_MULTI_BODY_3_BODY_QUORUM_SPEC_TOKEN = (
    "cdl_006_multi_body_3_body_quorum_spec_committed"
)
CDL006_PRODUCTION_RUNTIME_DEFERRED_TOKEN = (
    "cdl_006_challenge_node_production_runtime_deferred_to_phase_1382"
)

CHALLENGE_RECORD_SCHEMA_VERSION = "cdl_006_challenge_record_v1"
AUDIT_PATH_ENTRY_SCHEMA_VERSION = "cdl_006_audit_path_entry_v1"

REQUIRED_CHALLENGE_BODIES = ("constitutional", "technical", "affected_party")
REQUIRED_BODY_COUNT = 3
REQUIRED_RECORD_FIELDS = (
    "audit_path_ref",
    "body_attestations",
    "challenge_id",
    "challenged_action_ref",
    "created_epoch",
    "creator_agent_id",
    "evidence_refs",
    "governance_basis_ref",
    "remedy_requested",
    "schema_version",
    "status",
)
REQUIRED_ATTESTATION_FIELDS = (
    "attestation_ref",
    "body_id",
    "body_role",
    "epoch",
    "signer_agent_id",
    "signature_ref",
    "verdict",
)
REQUIRED_AUDIT_ENTRY_FIELDS = (
    "audit_entry_id",
    "challenge_id",
    "entry_epoch",
    "entry_type",
    "payload_ref",
    "previous_entry_ref",
    "writer_agent_id",
)

CHALLENGE_STATUS_VALUES = (
    "proposed",
    "under_review",
    "quorum_met",
    "rejected",
    "superseded",
    "deferred",
)
ATTESTATION_VERDICT_VALUES = ("approve_challenge", "reject_challenge", "abstain")
AUDIT_ENTRY_TYPE_VALUES = (
    "opened",
    "evidence_added",
    "body_attested",
    "quorum_evaluated",
    "closed",
)


@dataclass(frozen=True)
class ChallengeBodyAttestation:
    """Schema carrier for one independent CDL-006 body attestation."""

    body_id: str
    body_role: str
    signer_agent_id: str
    verdict: str
    attestation_ref: str
    signature_ref: str
    epoch: int


@dataclass(frozen=True)
class ChallengeRecordSchema:
    """Schema carrier for a CDL-006 challenge record."""

    challenge_id: str
    schema_version: str
    creator_agent_id: str
    challenged_action_ref: str
    governance_basis_ref: str
    remedy_requested: str
    evidence_refs: tuple[str, ...]
    body_attestations: tuple[ChallengeBodyAttestation, ...]
    audit_path_ref: str
    created_epoch: int
    status: str


@dataclass(frozen=True)
class AuditPathEntry:
    """Schema carrier for one audit-path entry in a challenge proceeding."""

    audit_entry_id: str
    challenge_id: str
    previous_entry_ref: str | None
    entry_type: str
    payload_ref: str
    writer_agent_id: str
    entry_epoch: int


def challenge_body_attestation_schema() -> dict[str, Any]:
    """Return the field contract for one body attestation."""

    return {
        "required_fields": list(REQUIRED_ATTESTATION_FIELDS),
        "body_role_enum": list(REQUIRED_CHALLENGE_BODIES),
        "verdict_enum": list(ATTESTATION_VERDICT_VALUES),
        "phase": 1382,
        "runtime_token": CDL006_CHALLENGE_NODE_RUNTIME_TOKEN,
    }


def challenge_record_schema() -> dict[str, Any]:
    """Return the CDL-006 challenge record schema contract."""

    return {
        "required_fields": list(REQUIRED_RECORD_FIELDS),
        "required_body_count": REQUIRED_BODY_COUNT,
        "required_body_roles": list(REQUIRED_CHALLENGE_BODIES),
        "status_enum": list(CHALLENGE_STATUS_VALUES),
        "schema_version": CHALLENGE_RECORD_SCHEMA_VERSION,
        "schema_token": CDL006_CHALLENGE_NODE_SPEC_TOKEN,
        "quorum_token": CDL006_MULTI_BODY_3_BODY_QUORUM_SPEC_TOKEN,
        "runtime_token": CDL006_CHALLENGE_NODE_RUNTIME_TOKEN,
        "quorum_verification_token": CDL006_3_BODY_QUORUM_VERIFICATION_TOKEN,
    }


def audit_path_record_schema() -> dict[str, Any]:
    """Return the audit-path entry field contract."""

    return {
        "required_fields": list(REQUIRED_AUDIT_ENTRY_FIELDS),
        "entry_type_enum": list(AUDIT_ENTRY_TYPE_VALUES),
        "schema_version": AUDIT_PATH_ENTRY_SCHEMA_VERSION,
        "hash_link_field": "previous_entry_ref",
        "payload_commitment_field": "payload_ref",
        "writer_field": "writer_agent_id",
        "runtime_token": CDL006_CHALLENGE_NODE_RUNTIME_TOKEN,
        "audit_path_writer_token": CDL006_AUDIT_PATH_RECORD_WRITER_TOKEN,
    }


def build_challenge_record_schema_template() -> dict[str, Any]:
    """Return a canonical schema template for CDL-006 challenge records."""

    return {
        "attestation_schema": challenge_body_attestation_schema(),
        "audit_path_schema": audit_path_record_schema(),
        "challenge_record_schema": challenge_record_schema(),
        "runtime_version": CHALLENGE_NODE_RUNTIME_VERSION,
    }


def canonical_schema_template_json() -> str:
    """Return deterministic JSON for the schema template."""

    return canonical_json(build_challenge_record_schema_template())


def canonical_json(payload: Mapping[str, Any]) -> str:
    """Return deterministic JSON for challenge runtime records."""

    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


def challenge_record_ref(challenge_record: Mapping[str, Any]) -> str:
    """Return a deterministic SHA-256 reference for a validated challenge record."""

    normalized = validate_challenge_record(challenge_record)
    return _sha256_ref(normalized)


def audit_path_entry_ref(audit_path_entry: Mapping[str, Any]) -> str:
    """Return a deterministic SHA-256 reference for an audit-path entry."""

    normalized = _normalize_audit_path_entry(audit_path_entry)
    return _sha256_ref(_audit_entry_hash_core(normalized))


def validate_challenge_record(challenge_record: Mapping[str, Any]) -> dict[str, Any]:
    """Validate and normalize a CDL-006 challenge record."""

    record = _require_mapping(challenge_record, "challenge_record_must_be_mapping")
    _require_fields(record, REQUIRED_RECORD_FIELDS, "challenge_record_missing_required_field")

    normalized_attestations = _normalize_attestations(record["body_attestations"])
    return {
        "audit_path_ref": _require_non_empty_string(
            record["audit_path_ref"], "audit_path_ref_must_be_non_empty_string"
        ),
        "body_attestations": normalized_attestations,
        "challenge_id": _require_non_empty_string(
            record["challenge_id"], "challenge_id_must_be_non_empty_string"
        ),
        "challenged_action_ref": _require_non_empty_string(
            record["challenged_action_ref"],
            "challenged_action_ref_must_be_non_empty_string",
        ),
        "created_epoch": _require_non_negative_int(
            record["created_epoch"], "created_epoch_must_be_non_negative_int"
        ),
        "creator_agent_id": _require_non_empty_string(
            record["creator_agent_id"], "creator_agent_id_must_be_non_empty_string"
        ),
        "evidence_refs": _normalize_ref_sequence(
            record["evidence_refs"], "evidence_refs_must_be_string_sequence"
        ),
        "governance_basis_ref": _require_non_empty_string(
            record["governance_basis_ref"],
            "governance_basis_ref_must_be_non_empty_string",
        ),
        "remedy_requested": _require_non_empty_string(
            record["remedy_requested"], "remedy_requested_must_be_non_empty_string"
        ),
        "schema_version": _require_exact_string(
            record["schema_version"],
            CHALLENGE_RECORD_SCHEMA_VERSION,
            "challenge_record_schema_version_invalid",
        ),
        "status": _require_enum(
            record["status"], CHALLENGE_STATUS_VALUES, "challenge_record_status_invalid"
        ),
    }


def verify_challenge_quorum(
    challenge_record: Mapping[str, Any],
    *,
    required_body_roles: tuple[str, ...] = REQUIRED_CHALLENGE_BODIES,
) -> bool:
    """Verify the CDL-006 3-body affirmative challenge quorum."""

    normalized = validate_challenge_record(challenge_record)
    roles = _normalize_required_body_roles(required_body_roles)
    attestations = normalized["body_attestations"]

    seen_body_ids: set[str] = set()
    seen_roles: set[str] = set()
    for attestation in attestations:
        body_id = attestation["body_id"]
        body_role = attestation["body_role"]
        if body_id in seen_body_ids:
            raise ValueError("challenge_quorum_duplicate_body_id_phase_1382")
        if body_role in seen_roles:
            raise ValueError("challenge_quorum_duplicate_body_role_phase_1382")
        seen_body_ids.add(body_id)
        seen_roles.add(body_role)
        if attestation["verdict"] != "approve_challenge":
            return False

    if len(attestations) != len(roles):
        return False

    return seen_roles == set(roles)


def write_challenge_audit_path_record(
    challenge_record: Mapping[str, Any],
    audit_event: Mapping[str, Any],
    *,
    previous_entry_ref: str | None = None,
) -> dict[str, Any]:
    """Build a deterministic hash-linked challenge audit-path record."""

    normalized_record = validate_challenge_record(challenge_record)
    event = _normalize_audit_event(audit_event)
    previous_ref = _require_optional_ref(
        previous_entry_ref, "previous_entry_ref_must_be_string_or_null"
    )

    entry_core = {
        "challenge_id": normalized_record["challenge_id"],
        "entry_epoch": event["entry_epoch"],
        "entry_type": event["entry_type"],
        "payload_ref": event["payload_ref"],
        "previous_entry_ref": previous_ref,
        "schema_version": AUDIT_PATH_ENTRY_SCHEMA_VERSION,
        "writer_agent_id": event["writer_agent_id"],
    }
    audit_entry_id = _sha256_ref(entry_core)
    audit_entry = {
        "audit_entry_id": audit_entry_id,
        **entry_core,
        "graph_commitment_path": {
            "audit_path_head_ref": audit_entry_id,
            "challenge_id": normalized_record["challenge_id"],
            "commitment_kind": "cdl_006_challenge_audit_path_head",
            "previous_entry_ref": previous_ref,
            "prior_challenge_audit_path_ref": normalized_record["audit_path_ref"],
            "runtime_token": CDL006_CHALLENGE_NODE_RUNTIME_TOKEN,
            "writer_token": CDL006_AUDIT_PATH_RECORD_WRITER_TOKEN,
        },
        "phase": 1382,
        "runtime_version": CHALLENGE_NODE_RUNTIME_VERSION,
        "writer_token": CDL006_AUDIT_PATH_RECORD_WRITER_TOKEN,
    }
    if audit_path_entry_ref(audit_entry) != audit_entry_id:
        raise ValueError("audit_path_entry_id_mismatch_phase_1382")
    return audit_entry


def _normalize_attestations(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError("body_attestations_must_be_sequence")
    normalized: list[dict[str, Any]] = []
    for item in value:
        attestation = _require_mapping(item, "body_attestation_must_be_mapping")
        _require_fields(
            attestation,
            REQUIRED_ATTESTATION_FIELDS,
            "body_attestation_missing_required_field",
        )
        normalized.append(
            {
                "attestation_ref": _require_non_empty_string(
                    attestation["attestation_ref"],
                    "attestation_ref_must_be_non_empty_string",
                ),
                "body_id": _require_non_empty_string(
                    attestation["body_id"], "body_id_must_be_non_empty_string"
                ),
                "body_role": _require_enum(
                    attestation["body_role"],
                    REQUIRED_CHALLENGE_BODIES,
                    "body_role_invalid",
                ),
                "epoch": _require_non_negative_int(
                    attestation["epoch"], "body_attestation_epoch_must_be_non_negative_int"
                ),
                "signer_agent_id": _require_non_empty_string(
                    attestation["signer_agent_id"],
                    "signer_agent_id_must_be_non_empty_string",
                ),
                "signature_ref": _require_non_empty_string(
                    attestation["signature_ref"],
                    "signature_ref_must_be_non_empty_string",
                ),
                "verdict": _require_enum(
                    attestation["verdict"],
                    ATTESTATION_VERDICT_VALUES,
                    "attestation_verdict_invalid",
                ),
            }
        )
    return normalized


def _normalize_required_body_roles(required_body_roles: tuple[str, ...]) -> tuple[str, ...]:
    if not isinstance(required_body_roles, tuple):
        raise ValueError("required_body_roles_must_be_tuple_phase_1382")
    if required_body_roles != REQUIRED_CHALLENGE_BODIES:
        raise ValueError("required_body_roles_must_equal_cdl_006_3_body_set_phase_1382")
    if len(required_body_roles) != REQUIRED_BODY_COUNT:
        raise ValueError("required_body_roles_must_be_3_phase_1382")
    return required_body_roles


def _normalize_audit_event(audit_event: Mapping[str, Any]) -> dict[str, Any]:
    event = _require_mapping(audit_event, "audit_event_must_be_mapping")
    required_fields = ("entry_epoch", "entry_type", "payload_ref", "writer_agent_id")
    _require_fields(event, required_fields, "audit_event_missing_required_field")
    return {
        "entry_epoch": _require_non_negative_int(
            event["entry_epoch"], "audit_event_entry_epoch_must_be_non_negative_int"
        ),
        "entry_type": _require_enum(
            event["entry_type"], AUDIT_ENTRY_TYPE_VALUES, "audit_event_entry_type_invalid"
        ),
        "payload_ref": _require_non_empty_string(
            event["payload_ref"], "audit_event_payload_ref_must_be_non_empty_string"
        ),
        "writer_agent_id": _require_non_empty_string(
            event["writer_agent_id"],
            "audit_event_writer_agent_id_must_be_non_empty_string",
        ),
    }


def _normalize_audit_path_entry(value: Mapping[str, Any]) -> dict[str, Any]:
    entry = _require_mapping(value, "audit_path_entry_must_be_mapping")
    _require_fields(entry, REQUIRED_AUDIT_ENTRY_FIELDS, "audit_path_entry_missing_required_field")
    return {
        "audit_entry_id": _require_non_empty_string(
            entry["audit_entry_id"], "audit_entry_id_must_be_non_empty_string"
        ),
        "challenge_id": _require_non_empty_string(
            entry["challenge_id"], "audit_challenge_id_must_be_non_empty_string"
        ),
        "entry_epoch": _require_non_negative_int(
            entry["entry_epoch"], "audit_entry_epoch_must_be_non_negative_int"
        ),
        "entry_type": _require_enum(
            entry["entry_type"], AUDIT_ENTRY_TYPE_VALUES, "audit_entry_type_invalid"
        ),
        "payload_ref": _require_non_empty_string(
            entry["payload_ref"], "audit_payload_ref_must_be_non_empty_string"
        ),
        "previous_entry_ref": _require_optional_ref(
            entry["previous_entry_ref"], "audit_previous_entry_ref_must_be_string_or_null"
        ),
        "schema_version": _require_exact_string(
            entry.get("schema_version", AUDIT_PATH_ENTRY_SCHEMA_VERSION),
            AUDIT_PATH_ENTRY_SCHEMA_VERSION,
            "audit_path_entry_schema_version_invalid",
        ),
        "writer_agent_id": _require_non_empty_string(
            entry["writer_agent_id"], "audit_writer_agent_id_must_be_non_empty_string"
        ),
    }


def _audit_entry_hash_core(entry: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "challenge_id": entry["challenge_id"],
        "entry_epoch": entry["entry_epoch"],
        "entry_type": entry["entry_type"],
        "payload_ref": entry["payload_ref"],
        "previous_entry_ref": entry["previous_entry_ref"],
        "schema_version": entry["schema_version"],
        "writer_agent_id": entry["writer_agent_id"],
    }


def _require_mapping(value: Any, token: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(token)
    return value


def _require_fields(record: Mapping[str, Any], fields: Sequence[str], token: str) -> None:
    for field in fields:
        if field not in record:
            raise ValueError(f"{token}:{field}")


def _require_non_empty_string(value: Any, token: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(token)
    return value


def _require_exact_string(value: Any, expected: str, token: str) -> str:
    text = _require_non_empty_string(value, token)
    if text != expected:
        raise ValueError(token)
    return text


def _require_optional_ref(value: Any, token: str) -> str | None:
    if value is None:
        return None
    return _require_non_empty_string(value, token)


def _require_non_negative_int(value: Any, token: str) -> int:
    if type(value) is not int or value < 0:
        raise ValueError(token)
    return value


def _require_enum(value: Any, allowed_values: Sequence[str], token: str) -> str:
    text = _require_non_empty_string(value, token)
    if text not in allowed_values:
        raise ValueError(token)
    return text


def _normalize_ref_sequence(value: Any, token: str) -> list[str]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValueError(token)
    return [_require_non_empty_string(item, token) for item in value]


def _sha256_ref(payload: Mapping[str, Any]) -> str:
    digest = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


__all__ = [
    "AUDIT_ENTRY_TYPE_VALUES",
    "AUDIT_PATH_ENTRY_SCHEMA_VERSION",
    "ATTESTATION_VERDICT_VALUES",
    "CDL006_3_BODY_QUORUM_VERIFICATION_TOKEN",
    "CDL006_AUDIT_PATH_RECORD_WRITER_TOKEN",
    "CDL006_CHALLENGE_NODE_RUNTIME_STUB_TOKEN",
    "CDL006_CHALLENGE_NODE_RUNTIME_TOKEN",
    "CDL006_CHALLENGE_NODE_SPEC_TOKEN",
    "CDL006_MULTI_BODY_3_BODY_QUORUM_SPEC_TOKEN",
    "CDL006_PRODUCTION_RUNTIME_DEFERRED_TOKEN",
    "CHALLENGE_NODE_RUNTIME_STUB_VERSION",
    "CHALLENGE_NODE_RUNTIME_VERSION",
    "CHALLENGE_RECORD_SCHEMA_VERSION",
    "CHALLENGE_STATUS_VALUES",
    "REQUIRED_ATTESTATION_FIELDS",
    "REQUIRED_AUDIT_ENTRY_FIELDS",
    "REQUIRED_BODY_COUNT",
    "REQUIRED_CHALLENGE_BODIES",
    "REQUIRED_RECORD_FIELDS",
    "AuditPathEntry",
    "ChallengeBodyAttestation",
    "ChallengeRecordSchema",
    "audit_path_entry_ref",
    "audit_path_record_schema",
    "build_challenge_record_schema_template",
    "canonical_json",
    "canonical_schema_template_json",
    "challenge_body_attestation_schema",
    "challenge_record_ref",
    "challenge_record_schema",
    "validate_challenge_record",
    "verify_challenge_quorum",
    "write_challenge_audit_path_record",
]
