# PUBLIC_RC_EXCLUDE: internal_phase_helper_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1278 sidecar public-path preflight scaffold; no listener, bind, or serving surface.
# PUBLIC_RC_INCLUDE_REQUIRES: explicit public sidecar authorization, CDL-087 disposition, TransportPrincipal authority, privacy review, and release allowlist review.

"""Phase 1278 sidecar public-path authorization preflight.

This module records the fail-closed checks required before a future
non-loopback sidecar projection endpoint. It deliberately does not open a
listener, bind a socket, serve projection data, or enable peer discovery.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

from ilc_core.graph.sidecar_query_runtime import SIDECAR_QUERY_RUNTIME_VERSION


SIDECAR_PUBLIC_PATH_PREFLIGHT_VERSION = (
    "sidecar_non_loopback_projection_authorization_preflight_phase_1278.v0.1"
)
SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN = "sidecar_public_serving_not_enabled_phase_1278"
TRANSPORT_PRINCIPAL_AND_CDL087_REQUIRED_TOKEN = (
    "transport_principal_and_cdl087_required_before_public_projection_phase_1278"
)
NO_NEW_PUBLIC_LISTENER_TOKEN = "no_new_public_listener_phase_1278"
NON_LOOPBACK_BIND_NOT_ENABLED_TOKEN = "non_loopback_bind_not_enabled_phase_1278"
PUBLIC_PROJECTION_ENDPOINT_NOT_ENABLED_TOKEN = (
    "public_projection_endpoint_not_enabled_phase_1278"
)
SIDECAR_PRIVACY_REVIEW_REQUIRED_TOKEN = "sidecar_projection_privacy_review_required_phase_1278"
CDL087_FIX_AFTER_1278_PLANNED_TOKEN = (
    "cdl087_ratification_fix_phase_planned_after_1277_1278_if_both_pass_phase_1278"
)

SIDECAR_PUBLIC_PATH_PREFLIGHT_STATE = "sidecar_public_path_preflight_only"
SIDECAR_PUBLIC_PATH_PREFLIGHT_REF_PREFIX = "sidecar_public_path_preflight_sha256"
TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION = (
    "transport_principal_public_path_adr_runtime_preflight_phase_1277.v0.1"
)
TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_STATE = "public_path_preflight_only"
TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_REF_PREFIX = (
    "transport_principal_public_path_preflight_sha256"
)
_HEX_DIGEST_LENGTH = 64
_HEX = frozenset("0123456789abcdef")
_MAX_PREFLIGHT_PAYLOAD_DEPTH = 32
_MAX_PREFLIGHT_PAYLOAD_NODES = 100_000
_TRANSPORT_PRINCIPAL_REQUIRED_TOKENS = frozenset(
    {
        TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
        "transport_principal_public_p2p_not_activated_phase_1277",
        "requester_id_fallback_still_forbidden_phase_1277",
        "non_loopback_projection_still_blocked_phase_1277",
        "public_fetch_serving_not_enabled_phase_1277",
        "cdl087_not_ratified_by_phase_1277",
        "sidecar_public_path_not_authorized_phase_1277",
        "rust_public_p2p_hardening_still_open_phase_1277",
        "genesis_atlas_v0_2_signing_deferred_until_atlas_g_tail_phase_1277",
        "cdl087_ratification_fix_phase_planned_after_1277_1278_if_both_pass_phase_1277",
    }
)
_REQUIRED_TOKENS = frozenset(
    {
        SIDECAR_PUBLIC_PATH_PREFLIGHT_VERSION,
        SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN,
        TRANSPORT_PRINCIPAL_AND_CDL087_REQUIRED_TOKEN,
        NO_NEW_PUBLIC_LISTENER_TOKEN,
        NON_LOOPBACK_BIND_NOT_ENABLED_TOKEN,
        PUBLIC_PROJECTION_ENDPOINT_NOT_ENABLED_TOKEN,
        SIDECAR_PRIVACY_REVIEW_REQUIRED_TOKEN,
        CDL087_FIX_AFTER_1278_PLANNED_TOKEN,
    }
)


def _reject_float_values(
    value: Any,
    *,
    _depth: int = 0,
    _seen: set[int] | None = None,
    _counter: list[int] | None = None,
) -> None:
    if _depth > _MAX_PREFLIGHT_PAYLOAD_DEPTH:
        raise ValueError("sidecar_public_path_payload_too_deep")
    if _seen is None:
        _seen = set()
    if _counter is None:
        _counter = [0]
    _counter[0] += 1
    if _counter[0] > _MAX_PREFLIGHT_PAYLOAD_NODES:
        raise ValueError("sidecar_public_path_payload_too_large")
    if isinstance(value, float):
        raise ValueError("sidecar_public_path_float_values_forbidden")
    if isinstance(value, Mapping):
        object_id = id(value)
        if object_id in _seen:
            raise ValueError("sidecar_public_path_payload_cycle_forbidden")
        _seen.add(object_id)
        try:
            for key, item in value.items():
                if not isinstance(key, str):
                    raise ValueError("sidecar_public_path_payload_key_invalid")
                _reject_float_values(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)
        return
    if isinstance(value, (list, tuple)):
        object_id = id(value)
        if object_id in _seen:
            raise ValueError("sidecar_public_path_payload_cycle_forbidden")
        _seen.add(object_id)
        try:
            for item in value:
                _reject_float_values(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)


def _canonical_json(value: Mapping[str, Any]) -> str:
    _reject_float_values(value)
    return json.dumps(value, sort_keys=True, allow_nan=False, separators=(",", ":"))


def _sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _require_epoch(name: str, value: Any) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"sidecar_public_path_{name}_epoch_invalid")
    return value


def _require_false(value: Any, token: str) -> bool:
    if value is not False:
        raise ValueError(token)
    return False


def _require_text(name: str, value: Any) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"sidecar_public_path_{name}_invalid")
    return value


def _require_hex_digest(name: str, value: Any) -> str:
    if (
        not isinstance(value, str)
        or len(value) != _HEX_DIGEST_LENGTH
        or any(char not in _HEX for char in value)
    ):
        raise ValueError(f"sidecar_public_path_{name}_invalid")
    return value


def _require_prefixed_digest(name: str, value: Any, prefix: str) -> str:
    expected_prefix = f"{prefix}:"
    if not isinstance(value, str) or not value.startswith(expected_prefix):
        raise ValueError(f"sidecar_public_path_{name}_invalid")
    _require_hex_digest(name, value[len(expected_prefix) :])
    return value


def _preflight_sha256(preflight: Mapping[str, Any]) -> str:
    payload = dict(preflight)
    payload.pop("sidecar_preflight_sha256", None)
    return _sha256_hex(_canonical_json(payload))


def _transport_principal_preflight_sha256(preflight: Mapping[str, Any]) -> str:
    payload = dict(preflight)
    payload.pop("preflight_sha256", None)
    return _sha256_hex(_canonical_json(payload))


def _validate_transport_principal_public_path_preflight(
    preflight: Mapping[str, Any],
    *,
    current_epoch: int,
) -> dict[str, Any]:
    if not isinstance(preflight, Mapping):
        raise ValueError("sidecar_public_path_transport_principal_preflight_invalid")
    _reject_float_values(preflight)
    current = _require_epoch("transport_principal_current", current_epoch)
    if preflight.get("version") != TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION:
        raise ValueError("sidecar_public_path_transport_principal_version_invalid")
    if preflight.get("state") != TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_STATE:
        raise ValueError("sidecar_public_path_transport_principal_state_invalid")
    if _require_epoch("transport_principal_current", preflight.get("current_epoch")) != current:
        raise ValueError("sidecar_public_path_transport_principal_current_epoch_mismatch")
    if preflight.get("context_scope") != "pre_public_path":
        raise ValueError("sidecar_public_path_transport_principal_scope_invalid")

    issued = _require_epoch("transport_principal_issued", preflight.get("issued_epoch"))
    expires = _require_epoch("transport_principal_expires", preflight.get("expires_epoch"))
    if issued > current or current > expires:
        raise ValueError("sidecar_public_path_transport_principal_epoch_window_invalid")

    _require_hex_digest(
        "transport_principal_credential_fingerprint",
        preflight.get("credential_fingerprint"),
    )
    _require_text("transport_principal_credential_kind", preflight.get("credential_kind"))
    _require_text("transport_principal_context_version", preflight.get("context_version"))
    principal_id = _require_prefixed_digest(
        "transport_principal_principal_id",
        preflight.get("principal_id"),
        "tp",
    )
    rate_limit_key = _require_prefixed_digest(
        "transport_principal_rate_limit_key",
        preflight.get("rate_limit_key"),
        "tp_rate",
    )
    admission_key = _require_prefixed_digest(
        "transport_principal_admission_key",
        preflight.get("admission_key"),
        "tp_admission",
    )
    ban_key = _require_prefixed_digest(
        "transport_principal_ban_key",
        preflight.get("ban_key"),
        "tp_ban",
    )
    replay_key = _require_prefixed_digest(
        "transport_principal_replay_key",
        preflight.get("replay_key"),
        "tp_replay",
    )

    authorization_flags = preflight.get("authorization_flags")
    if not isinstance(authorization_flags, Mapping):
        raise ValueError("sidecar_public_path_transport_principal_flags_invalid")
    for flag in (
        "public_p2p_enabled",
        "public_fetch_serving_enabled",
        "non_loopback_projection_enabled",
        "cdl087_ratified",
        "sidecar_public_path_authorized",
        "rust_public_p2p_hardening_complete",
        "release_artifact_authorized",
    ):
        if authorization_flags.get(flag) is not False:
            raise ValueError("sidecar_public_path_transport_principal_public_flag_enabled")

    fallback_policy = preflight.get("fallback_policy")
    if not isinstance(fallback_policy, Mapping):
        raise ValueError("sidecar_public_path_transport_principal_fallback_invalid")
    for flag in (
        "requester_id_fallback_allowed",
        "client_ip_rate_limit_key_allowed",
        "agent_id_rate_limit_key_allowed",
        "harness_identity_rate_limit_key_allowed",
    ):
        if fallback_policy.get(flag) is not False:
            raise ValueError("sidecar_public_path_transport_principal_fallback_enabled")
    if fallback_policy.get("rate_limit_identity_source") != "authenticated_transport_principal":
        raise ValueError("sidecar_public_path_transport_principal_rate_limit_source_invalid")

    security_controls = preflight.get("security_controls")
    if not isinstance(security_controls, Mapping):
        raise ValueError("sidecar_public_path_transport_principal_security_invalid")
    for flag in (
        "revocation_checked",
        "replay_checked",
        "epoch_rotation_required",
        "full_hash_binding_required",
    ):
        if security_controls.get(flag) is not True:
            raise ValueError("sidecar_public_path_transport_principal_security_invalid")
    if security_controls.get("privacy_mode") not in {
        "ephemeral_principal_no_agentid_default",
        "rotating_pseudonymous_transport_principal",
    }:
        raise ValueError("sidecar_public_path_transport_principal_privacy_mode_invalid")

    tokens = preflight.get("tokens")
    if not isinstance(tokens, list) or not all(isinstance(token, str) for token in tokens):
        raise ValueError("sidecar_public_path_transport_principal_tokens_invalid")
    if not _TRANSPORT_PRINCIPAL_REQUIRED_TOKENS.issubset(set(tokens)):
        raise ValueError("sidecar_public_path_transport_principal_tokens_missing")

    context_tokens = preflight.get("context_tokens")
    if not isinstance(context_tokens, list) or not all(
        isinstance(token, str) for token in context_tokens
    ):
        raise ValueError("sidecar_public_path_transport_principal_context_tokens_invalid")
    carry_forward_requirements = preflight.get("carry_forward_requirements")
    if not isinstance(carry_forward_requirements, list) or not all(
        isinstance(item, str) for item in carry_forward_requirements
    ):
        raise ValueError("sidecar_public_path_transport_principal_requirements_invalid")

    preflight_sha256 = _require_hex_digest(
        "transport_principal_preflight_sha256",
        preflight.get("preflight_sha256"),
    )
    if preflight_sha256 != _transport_principal_preflight_sha256(preflight):
        raise ValueError("sidecar_public_path_transport_principal_hash_mismatch")

    return {
        "admission_key": admission_key,
        "ban_key": ban_key,
        "current_epoch": current,
        "preflight_sha256": preflight_sha256,
        "principal_id": principal_id,
        "rate_limit_key": rate_limit_key,
        "replay_key": replay_key,
        "version": TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
    }


def _transport_principal_public_path_preflight_ref(preflight: Mapping[str, Any]) -> str:
    validated = _validate_transport_principal_public_path_preflight(
        preflight,
        current_epoch=_require_epoch(
            "transport_principal_current",
            preflight.get("current_epoch"),
        ),
    )
    return (
        f"{TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_REF_PREFIX}:"
        f"{validated['preflight_sha256']}"
    )


def build_sidecar_public_path_preflight(
    *,
    transport_principal_preflight: Mapping[str, Any],
    current_epoch: int,
    sidecar_public_serving_enabled: bool = False,
    public_projection_endpoint_enabled: bool = False,
    non_loopback_bind_enabled: bool = False,
    new_public_listener_enabled: bool = False,
    peer_discovery_enabled: bool = False,
    public_fetch_serving_enabled: bool = False,
    public_p2p_enabled: bool = False,
    cdl087_ratified: bool = False,
    transport_principal_public_path_authorized: bool = False,
    release_artifact_authorized: bool = False,
) -> dict[str, Any]:
    """Build a fail-closed public sidecar/projection preflight payload."""

    current = _require_epoch("current", current_epoch)
    validated_transport = _validate_transport_principal_public_path_preflight(
        transport_principal_preflight,
        current_epoch=current,
    )

    _require_false(sidecar_public_serving_enabled, SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN)
    _require_false(
        public_projection_endpoint_enabled,
        PUBLIC_PROJECTION_ENDPOINT_NOT_ENABLED_TOKEN,
    )
    _require_false(non_loopback_bind_enabled, NON_LOOPBACK_BIND_NOT_ENABLED_TOKEN)
    _require_false(new_public_listener_enabled, NO_NEW_PUBLIC_LISTENER_TOKEN)
    _require_false(peer_discovery_enabled, NO_NEW_PUBLIC_LISTENER_TOKEN)
    _require_false(public_fetch_serving_enabled, SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN)
    _require_false(public_p2p_enabled, SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN)
    _require_false(cdl087_ratified, TRANSPORT_PRINCIPAL_AND_CDL087_REQUIRED_TOKEN)
    _require_false(
        transport_principal_public_path_authorized,
        TRANSPORT_PRINCIPAL_AND_CDL087_REQUIRED_TOKEN,
    )
    _require_false(release_artifact_authorized, "sidecar_release_artifact_not_authorized_phase_1278")

    preflight: dict[str, Any] = {
        "version": SIDECAR_PUBLIC_PATH_PREFLIGHT_VERSION,
        "state": SIDECAR_PUBLIC_PATH_PREFLIGHT_STATE,
        "current_epoch": current,
        "sidecar_runtime_version": SIDECAR_QUERY_RUNTIME_VERSION,
        "transport_principal_preflight_ref": _transport_principal_public_path_preflight_ref(
            transport_principal_preflight
        ),
        "transport_principal_preflight_version": TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
        "transport_principal_principal_id": validated_transport["principal_id"],
        "transport_principal_rate_limit_key": validated_transport["rate_limit_key"],
        "transport_principal_admission_key": validated_transport["admission_key"],
        "transport_principal_ban_key": validated_transport["ban_key"],
        "transport_principal_replay_key": validated_transport["replay_key"],
        "authorization_flags": {
            "sidecar_public_serving_enabled": False,
            "public_projection_endpoint_enabled": False,
            "non_loopback_bind_enabled": False,
            "new_public_listener_enabled": False,
            "peer_discovery_enabled": False,
            "public_fetch_serving_enabled": False,
            "public_p2p_enabled": False,
            "cdl087_ratified": False,
            "transport_principal_public_path_authorized": False,
            "release_artifact_authorized": False,
        },
        "required_before_public_projection": [
            "explicit_public_sidecar_authorization",
            "cdl087_ratification_or_equivalent_public_projection_policy",
            "transport_principal_public_path_authority",
            "privacy_leakage_review",
            "rate_limit_ban_replay_revocation_controls",
            "rust_public_p2p_or_non_loopback_substrate_hardening",
        ],
        "local_surface_policy": {
            "in_process_import_allowed": True,
            "harness_subprocess_allowed": True,
            "loopback_only_future_explicit_authorization_required": True,
            "unix_socket_future_explicit_authorization_required": True,
            "public_host_bind_allowed": False,
            "wildcard_bind_allowed": False,
        },
        "export_controls": {
            "canonical_json_required": True,
            "bounded_result_count_required": True,
            "bounded_response_bytes_required": True,
            "float_export_forbidden": True,
            "privacy_review_required": True,
        },
        "tokens": sorted(_REQUIRED_TOKENS),
    }
    preflight["sidecar_preflight_sha256"] = _preflight_sha256(preflight)
    return validate_sidecar_public_path_preflight(preflight, current_epoch=current)


def validate_sidecar_public_path_preflight(
    preflight: Mapping[str, Any],
    *,
    current_epoch: int,
) -> dict[str, Any]:
    """Validate a Phase 1278 sidecar public-path preflight payload."""

    if not isinstance(preflight, Mapping):
        raise ValueError("sidecar_public_path_preflight_invalid")
    _reject_float_values(preflight)
    current = _require_epoch("current", current_epoch)
    if preflight.get("version") != SIDECAR_PUBLIC_PATH_PREFLIGHT_VERSION:
        raise ValueError("sidecar_public_path_preflight_version_invalid")
    if preflight.get("state") != SIDECAR_PUBLIC_PATH_PREFLIGHT_STATE:
        raise ValueError("sidecar_public_path_preflight_state_invalid")
    if _require_epoch("current", preflight.get("current_epoch")) != current:
        raise ValueError("sidecar_public_path_current_epoch_mismatch")
    if preflight.get("sidecar_runtime_version") != SIDECAR_QUERY_RUNTIME_VERSION:
        raise ValueError("sidecar_public_path_runtime_version_invalid")
    if (
        preflight.get("transport_principal_preflight_version")
        != TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION
    ):
        raise ValueError("sidecar_public_path_transport_principal_version_invalid")

    transport_ref = _require_prefixed_digest(
        "transport_principal_preflight_ref",
        preflight.get("transport_principal_preflight_ref"),
        "transport_principal_public_path_preflight_sha256",
    )
    principal_id = _require_prefixed_digest(
        "transport_principal_principal_id",
        preflight.get("transport_principal_principal_id"),
        "tp",
    )
    rate_limit_key = _require_prefixed_digest(
        "transport_principal_rate_limit_key",
        preflight.get("transport_principal_rate_limit_key"),
        "tp_rate",
    )
    admission_key = _require_prefixed_digest(
        "transport_principal_admission_key",
        preflight.get("transport_principal_admission_key"),
        "tp_admission",
    )
    ban_key = _require_prefixed_digest(
        "transport_principal_ban_key",
        preflight.get("transport_principal_ban_key"),
        "tp_ban",
    )
    replay_key = _require_prefixed_digest(
        "transport_principal_replay_key",
        preflight.get("transport_principal_replay_key"),
        "tp_replay",
    )

    authorization_flags = preflight.get("authorization_flags")
    if not isinstance(authorization_flags, Mapping):
        raise ValueError("sidecar_public_path_authorization_flags_invalid")
    _require_false(
        authorization_flags.get("sidecar_public_serving_enabled"),
        SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN,
    )
    _require_false(
        authorization_flags.get("public_projection_endpoint_enabled"),
        PUBLIC_PROJECTION_ENDPOINT_NOT_ENABLED_TOKEN,
    )
    _require_false(
        authorization_flags.get("non_loopback_bind_enabled"),
        NON_LOOPBACK_BIND_NOT_ENABLED_TOKEN,
    )
    _require_false(
        authorization_flags.get("new_public_listener_enabled"),
        NO_NEW_PUBLIC_LISTENER_TOKEN,
    )
    _require_false(authorization_flags.get("peer_discovery_enabled"), NO_NEW_PUBLIC_LISTENER_TOKEN)
    _require_false(
        authorization_flags.get("public_fetch_serving_enabled"),
        SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN,
    )
    _require_false(
        authorization_flags.get("public_p2p_enabled"),
        SIDECAR_PUBLIC_SERVING_NOT_ENABLED_TOKEN,
    )
    _require_false(
        authorization_flags.get("cdl087_ratified"),
        TRANSPORT_PRINCIPAL_AND_CDL087_REQUIRED_TOKEN,
    )
    _require_false(
        authorization_flags.get("transport_principal_public_path_authorized"),
        TRANSPORT_PRINCIPAL_AND_CDL087_REQUIRED_TOKEN,
    )
    _require_false(
        authorization_flags.get("release_artifact_authorized"),
        "sidecar_release_artifact_not_authorized_phase_1278",
    )

    required_before_public_projection = preflight.get("required_before_public_projection")
    if not isinstance(required_before_public_projection, list) or not all(
        isinstance(item, str) for item in required_before_public_projection
    ):
        raise ValueError("sidecar_public_path_requirements_invalid")

    local_surface_policy = preflight.get("local_surface_policy")
    if not isinstance(local_surface_policy, Mapping):
        raise ValueError("sidecar_public_path_local_surface_policy_invalid")
    for true_field in (
        "in_process_import_allowed",
        "harness_subprocess_allowed",
        "loopback_only_future_explicit_authorization_required",
        "unix_socket_future_explicit_authorization_required",
    ):
        if local_surface_policy.get(true_field) is not True:
            raise ValueError("sidecar_public_path_local_surface_policy_invalid")
    for false_field in ("public_host_bind_allowed", "wildcard_bind_allowed"):
        if local_surface_policy.get(false_field) is not False:
            raise ValueError(NO_NEW_PUBLIC_LISTENER_TOKEN)

    export_controls = preflight.get("export_controls")
    if not isinstance(export_controls, Mapping):
        raise ValueError("sidecar_public_path_export_controls_invalid")
    for true_field in (
        "canonical_json_required",
        "bounded_result_count_required",
        "bounded_response_bytes_required",
        "float_export_forbidden",
        "privacy_review_required",
    ):
        if export_controls.get(true_field) is not True:
            raise ValueError("sidecar_public_path_export_controls_invalid")

    tokens = preflight.get("tokens")
    if not isinstance(tokens, list) or not all(isinstance(token, str) for token in tokens):
        raise ValueError("sidecar_public_path_tokens_invalid")
    if not _REQUIRED_TOKENS.issubset(set(tokens)):
        raise ValueError("sidecar_public_path_required_tokens_missing")

    if preflight.get("sidecar_preflight_sha256") != _preflight_sha256(preflight):
        raise ValueError("sidecar_public_path_preflight_hash_mismatch")

    validated = {
        "authorization_flags": dict(authorization_flags),
        "current_epoch": current,
        "export_controls": dict(export_controls),
        "local_surface_policy": dict(local_surface_policy),
        "required_before_public_projection": list(required_before_public_projection),
        "sidecar_preflight_sha256": _require_text(
            "sidecar_preflight_sha256",
            preflight.get("sidecar_preflight_sha256"),
        ),
        "sidecar_runtime_version": SIDECAR_QUERY_RUNTIME_VERSION,
        "state": SIDECAR_PUBLIC_PATH_PREFLIGHT_STATE,
        "tokens": sorted(_REQUIRED_TOKENS),
        "transport_principal_admission_key": admission_key,
        "transport_principal_ban_key": ban_key,
        "transport_principal_preflight_ref": transport_ref,
        "transport_principal_preflight_version": TRANSPORT_PRINCIPAL_PUBLIC_PATH_PREFLIGHT_VERSION,
        "transport_principal_principal_id": principal_id,
        "transport_principal_rate_limit_key": rate_limit_key,
        "transport_principal_replay_key": replay_key,
        "version": SIDECAR_PUBLIC_PATH_PREFLIGHT_VERSION,
    }
    _reject_float_values(validated)
    return validated


def sidecar_public_path_preflight_ref(preflight: Mapping[str, Any]) -> str:
    validated = validate_sidecar_public_path_preflight(
        preflight,
        current_epoch=_require_epoch("current", preflight.get("current_epoch")),
    )
    return f"{SIDECAR_PUBLIC_PATH_PREFLIGHT_REF_PREFIX}:{validated['sidecar_preflight_sha256']}"


def export_sidecar_public_path_preflight_json(preflight: Mapping[str, Any]) -> str:
    validated = validate_sidecar_public_path_preflight(
        preflight,
        current_epoch=_require_epoch("current", preflight.get("current_epoch")),
    )
    return _canonical_json(validated)
