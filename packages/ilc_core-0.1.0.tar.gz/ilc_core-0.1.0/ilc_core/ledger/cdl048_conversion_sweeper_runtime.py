# PUBLIC_RC_EXCLUDE: internal_phase_helper_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1274 CDL-048 conversion-sweeper skeleton; local verifier scaffold only.
# PUBLIC_RC_INCLUDE_REQUIRES: explicit public claimability authority, verifier/API hardening, and release allowlist review.
# PHASE_1282_FIX1_AUDIT_HARDENING: phase_1282_fix1_claimability_runtime_audit_hardening
# PHASE_1282_FIX1_TOKENS: claimability_conversion_receipt_semantics_hardened_phase_1282_fix1; settled_runtime_root_domain_separation_hardened_phase_1282_fix1; balance_receipt_decimal_boundary_hardened_phase_1282_fix1; cdl048_conversion_sweeper_public_rc_exclude_marked_phase_1282_fix1; public_rc_remains_blocked_after_phase_1282_fix1
# PHASE_1380_DRY_RUN_WIRING: cdl_048_dry_run_wiring_phase_1380; cdl_048_not_activated_phase_1380; gate_closed_state_confirmed_phase_1380; double_entry_conservation_proven_wire_level_phase_1380
# PHASE_1388_ACTIVATION: cdl_048_activated_phase_1388; counsel_clearance_public_verifier_api_phase_1388; first_live_value_path_activation_phase_1388

"""Phase 1274 CDL-048 conversion sweeper runtime skeleton."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, replace
from decimal import Decimal, InvalidOperation, ROUND_DOWN
from typing import Any

from ilc_core.epoch.ecu_price_clamp_runtime import (
    ECU_PRICE_CLAMP_RUNTIME_VERSION,
    LIVE_PRICE_ADJUSTMENT_NOT_ACTIVATED_TOKEN,
    build_ecu_price_clamp_quote,
)
from ilc_core.epoch.epoch_emission_runtime import ILC_QUANTUM


CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION = (
    "cdl048_conversion_sweeper_runtime_skeleton_phase_1274.v0.1"
)
CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS = 4
CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN = (
    "conversion_sweeper_no_public_claimability_activation_phase_1274"
)
ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN = (
    "ecu_lot_deadline_epoch_enforcement_recorded_phase_1274"
)
WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN = (
    "wallet_withdrawal_transfer_spend_still_blocked_phase_1274"
)
CDL048_DRY_RUN_WIRE_RUNTIME_VERSION = "cdl048_conversion_dry_run_wire_phase_1380.v0.1"
CDL048_ACTIVATION_RUNTIME_VERSION = "cdl048_conversion_activation_phase_1388.v0.1"
CDL048_DRY_RUN_WIRING_TOKEN = "cdl_048_dry_run_wiring_phase_1380"
CDL048_NOT_ACTIVATED_PHASE_1380_TOKEN = "cdl_048_not_activated_phase_1380"
GATE_CLOSED_STATE_CONFIRMED_PHASE_1380_TOKEN = "gate_closed_state_confirmed_phase_1380"
DOUBLE_ENTRY_CONSERVATION_PROVEN_WIRE_LEVEL_PHASE_1380_TOKEN = (
    "double_entry_conservation_proven_wire_level_phase_1380"
)
CDL048_ACTIVATED_PHASE_1388_TOKEN = "cdl_048_activated_phase_1388"
COUNSEL_CLEARANCE_PUBLIC_VERIFIER_API_PHASE_1388_TOKEN = (
    "counsel_clearance_public_verifier_api_phase_1388"
)
FIRST_LIVE_VALUE_PATH_ACTIVATION_PHASE_1388_TOKEN = (
    "first_live_value_path_activation_phase_1388"
)

OPEN_STATUS = "open"
CONVERTED_STATUS = "converted_internal_skeleton"
CONVERSION_TRANSITION = "cdl048_ecu_lot_internal_conversion_skeleton"
WALLET_STATE_ROOT_PREFIX = "wallet_state_sha256"
SETTLED_RUNTIME_ROOT_PREFIX = "settled_runtime_sha256"
CONVERSION_SWEEPER_STATE_ROOT_PREFIX = "cdl048_conversion_sweeper_state_sha256"
_HEX_DIGEST_LENGTH = 64
_HEX = frozenset("0123456789abcdef")
_MAX_CANONICAL_PAYLOAD_DEPTH = 32
_MAX_CANONICAL_PAYLOAD_NODES = 100_000


class Cdl048ConversionSweeperRuntimeError(ValueError):
    """Fail-closed CDL-048 sweeper error with a stable machine token."""

    def __init__(self, token: str, message: str) -> None:
        super().__init__(message)
        self.token = token


@dataclass(frozen=True)
class EcuLot:
    lot_id: str
    agent_id: str
    amount_ecu: Decimal
    issue_epoch: int
    deadline_epoch: int
    origin: str
    funding_provenance: tuple[str, ...]
    conversion_status: str = OPEN_STATUS
    converted_epoch: int | None = None
    conversion_receipt_sha256: str | None = None


@dataclass(frozen=True)
class ConversionSweeperState:
    lots: tuple[EcuLot, ...] = ()
    conversion_keys: frozenset[str] = frozenset()


@dataclass(frozen=True)
class ConversionReceipt:
    runtime_version: str
    lot_id: str
    agent_id: str
    amount_ecu: Decimal
    issue_epoch: int
    deadline_epoch: int
    conversion_epoch: int
    settled_runtime_epoch: int
    wallet_state_root: str
    settled_runtime_root: str
    sweeper_state_root_before: str
    conversion_state_transition: str
    conversion_key_sha256: str
    receipt_sha256: str
    public_claimability_activated: bool = False
    wallet_withdrawal_enabled: bool = False
    wallet_transfer_enabled: bool = False
    wallet_spend_enabled: bool = False
    ecu_mint_authorized: bool = False
    ilc_settlement_authorized: bool = False


@dataclass(frozen=True)
class ConversionDryRunWireQuote:
    runtime_version: str
    lot_id: str
    agent_id: str
    issue_epoch: int
    deadline_epoch: int
    conversion_epoch: int
    settled_runtime_epoch: int
    wallet_state_root: str
    settled_runtime_root: str
    sweeper_state_root_before: str
    sweeper_state_root_after: str
    amount_ecu_debit: Decimal
    proposed_p_e: Decimal
    effective_p_e: Decimal
    p_e_quote_runtime_version: str
    p_e_decision_token: str
    p_e_clamp_applied: bool
    p_e_clamp_direction: str
    debit_value_ilc: Decimal
    amount_ilc_credit: Decimal
    conservation_delta_ilc: Decimal
    double_entry_conservation_proven: bool
    gate_closed: bool
    quote_only: bool
    conversion_activation_authorized: bool
    ledger_write_authorized: bool
    wallet_write_authorized: bool
    public_claimability_activated: bool
    tokens: tuple[str, ...]

    def to_canonical_record(self) -> dict[str, Any]:
        return conversion_dry_run_wire_quote_payload(self)


@dataclass(frozen=True)
class ConversionResult:
    state: ConversionSweeperState
    receipt: ConversionReceipt
    sweeper_state_root_after: str


def empty_conversion_sweeper_state() -> ConversionSweeperState:
    return ConversionSweeperState()


def register_ecu_lot(
    state: ConversionSweeperState,
    *,
    lot_id: str,
    agent_id: str,
    amount_ecu: object,
    issue_epoch: int,
    origin: str,
    funding_provenance: tuple[str, ...] | list[str],
) -> ConversionSweeperState:
    state = _require_state(state)
    normalized_lot_id = _require_text(lot_id, token="cdl048_lot_id_required")
    if _find_lot(state, normalized_lot_id) is not None:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_lot_duplicate",
            "lot_id is already registered",
        )

    normalized_issue_epoch = _require_epoch(issue_epoch, token="cdl048_issue_epoch_invalid")
    lot = EcuLot(
        lot_id=normalized_lot_id,
        agent_id=_require_text(agent_id, token="cdl048_agent_id_required"),
        amount_ecu=_require_positive_decimal(amount_ecu),
        issue_epoch=normalized_issue_epoch,
        deadline_epoch=normalized_issue_epoch + CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS,
        origin=_require_text(origin, token="cdl048_origin_required"),
        funding_provenance=_require_provenance(funding_provenance),
    )
    return ConversionSweeperState(
        lots=_sort_lots((*state.lots, lot)),
        conversion_keys=state.conversion_keys,
    )


def deadline_status(*, lot: EcuLot, current_epoch: int) -> dict[str, Any]:
    epoch = _require_epoch(current_epoch, token="cdl048_current_epoch_invalid")
    remaining = lot.deadline_epoch - epoch
    if remaining < 0:
        status = "expired"
    elif remaining == 0:
        status = "deadline_epoch"
    else:
        status = "open"
    return {
        "lot_id": lot.lot_id,
        "issue_epoch": lot.issue_epoch,
        "deadline_epoch": lot.deadline_epoch,
        "current_epoch": epoch,
        "epochs_remaining": remaining,
        "deadline_status": status,
        "token": ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
    }


def convert_ecu_lot(
    state: ConversionSweeperState,
    *,
    lot_id: str,
    agent_id: str,
    conversion_epoch: int,
    settled_runtime_epoch: int,
    wallet_state_root: str,
    settled_runtime_root: str,
) -> ConversionResult:
    state = _require_state(state)
    normalized_lot_id = _require_text(lot_id, token="cdl048_lot_id_required")
    normalized_agent_id = _require_text(agent_id, token="cdl048_agent_id_required")
    epoch = _require_epoch(conversion_epoch, token="cdl048_conversion_epoch_invalid")
    settled_epoch = _require_epoch(
        settled_runtime_epoch,
        token="cdl048_settled_runtime_epoch_invalid",
    )
    if settled_epoch != epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_settled_runtime_root_stale",
            "settled_runtime_epoch must match conversion_epoch",
        )

    wallet_root = _require_prefixed_sha256(
        wallet_state_root,
        prefix=WALLET_STATE_ROOT_PREFIX,
        token="cdl048_wallet_state_root_required",
    )
    settled_root = _require_prefixed_sha256(
        settled_runtime_root,
        prefix=SETTLED_RUNTIME_ROOT_PREFIX,
        token="cdl048_settled_runtime_root_required",
    )
    lot = _find_lot(state, normalized_lot_id)
    if lot is None:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_lot_not_found",
            "lot_id is not registered",
        )
    if lot.agent_id != normalized_agent_id:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_agent_mismatch",
            "agent_id does not match registered lot owner",
        )
    if lot.conversion_status != OPEN_STATUS:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_duplicate_lot",
            "lot already converted",
        )
    if epoch < lot.issue_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_before_issue_epoch",
            "conversion_epoch cannot precede issue_epoch",
        )
    if epoch > lot.deadline_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_deadline_expired",
            "conversion_epoch exceeds the CDL-048 deadline epoch",
        )

    state_root_before = conversion_sweeper_state_root(state)
    conversion_key_payload = {
        "agent_id": normalized_agent_id,
        "conversion_epoch": epoch,
        "conversion_state_transition": CONVERSION_TRANSITION,
        "lot_id": normalized_lot_id,
        "settled_runtime_root": settled_root,
        "wallet_state_root": wallet_root,
    }
    conversion_key = _sha256_payload(conversion_key_payload)
    if conversion_key in state.conversion_keys:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_replay_detected",
            "conversion key already recorded",
        )

    receipt_body = {
        "agent_id": normalized_agent_id,
        "amount_ecu": _decimal_to_canonical_string(lot.amount_ecu),
        "conversion_epoch": epoch,
        "conversion_key_sha256": conversion_key,
        "conversion_state_transition": CONVERSION_TRANSITION,
        "deadline_epoch": lot.deadline_epoch,
        "ecu_mint_authorized": False,
        "ilc_settlement_authorized": False,
        "issue_epoch": lot.issue_epoch,
        "lot_id": normalized_lot_id,
        "public_claimability_activated": False,
        "runtime_version": CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION,
        "settled_runtime_epoch": settled_epoch,
        "settled_runtime_root": settled_root,
        "sweeper_state_root_before": state_root_before,
        "tokens": [
            CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
            ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
            WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
        ],
        "wallet_spend_enabled": False,
        "wallet_state_root": wallet_root,
        "wallet_transfer_enabled": False,
        "wallet_withdrawal_enabled": False,
    }
    receipt_sha256 = _sha256_payload(receipt_body)
    receipt = ConversionReceipt(
        runtime_version=CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION,
        lot_id=normalized_lot_id,
        agent_id=normalized_agent_id,
        amount_ecu=lot.amount_ecu,
        issue_epoch=lot.issue_epoch,
        deadline_epoch=lot.deadline_epoch,
        conversion_epoch=epoch,
        settled_runtime_epoch=settled_epoch,
        wallet_state_root=wallet_root,
        settled_runtime_root=settled_root,
        sweeper_state_root_before=state_root_before,
        conversion_state_transition=CONVERSION_TRANSITION,
        conversion_key_sha256=conversion_key,
        receipt_sha256=receipt_sha256,
    )
    converted_lot = replace(
        lot,
        conversion_status=CONVERTED_STATUS,
        converted_epoch=epoch,
        conversion_receipt_sha256=receipt_sha256,
    )
    next_state = ConversionSweeperState(
        lots=_sort_lots(
            converted_lot if item.lot_id == normalized_lot_id else item
            for item in state.lots
        ),
        conversion_keys=frozenset((*state.conversion_keys, conversion_key)),
    )
    return ConversionResult(
        state=next_state,
        receipt=receipt,
        sweeper_state_root_after=conversion_sweeper_state_root(next_state),
    )


def build_cdl048_dry_run_wire_quote(
    state: ConversionSweeperState,
    *,
    lot_id: str,
    agent_id: str,
    conversion_epoch: int,
    settled_runtime_epoch: int,
    wallet_state_root: str,
    settled_runtime_root: str,
    proposed_p_e: Decimal | int | str,
    activation_requested: bool = False,
) -> ConversionDryRunWireQuote:
    state = _require_state(state)
    if not isinstance(activation_requested, bool):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_activation_request_flag_invalid",
            "activation_requested must be a bool",
        )

    normalized_lot_id = _require_text(lot_id, token="cdl048_lot_id_required")
    normalized_agent_id = _require_text(agent_id, token="cdl048_agent_id_required")
    epoch = _require_epoch(conversion_epoch, token="cdl048_conversion_epoch_invalid")
    settled_epoch = _require_epoch(
        settled_runtime_epoch,
        token="cdl048_settled_runtime_epoch_invalid",
    )
    if settled_epoch != epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_settled_runtime_root_stale",
            "settled_runtime_epoch must match conversion_epoch",
        )

    wallet_root = _require_prefixed_sha256(
        wallet_state_root,
        prefix=WALLET_STATE_ROOT_PREFIX,
        token="cdl048_wallet_state_root_required",
    )
    settled_root = _require_prefixed_sha256(
        settled_runtime_root,
        prefix=SETTLED_RUNTIME_ROOT_PREFIX,
        token="cdl048_settled_runtime_root_required",
    )
    lot = _find_lot(state, normalized_lot_id)
    if lot is None:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_lot_not_found",
            "lot_id is not registered",
        )
    if lot.agent_id != normalized_agent_id:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_agent_mismatch",
            "agent_id does not match registered lot owner",
        )
    if lot.conversion_status != OPEN_STATUS:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_lot_not_open",
            "dry-run quote requires an open ECU lot",
        )
    if epoch < lot.issue_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_before_issue_epoch",
            "conversion_epoch cannot precede issue_epoch",
        )
    if epoch > lot.deadline_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_deadline_expired",
            "conversion_epoch exceeds the CDL-048 deadline epoch",
        )

    try:
        p_e_quote = build_ecu_price_clamp_quote(
            issuance_epoch=epoch,
            proposed_price=proposed_p_e,
        )
    except ValueError as exc:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_p_e_quote_invalid",
            str(exc),
        ) from exc

    amount_ilc = _quantize_ilc_amount(lot.amount_ecu * p_e_quote.clamped_price)
    if amount_ilc <= Decimal("0"):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_ilc_credit_zero",
            "dry-run ILC credit must be positive after quantum rounding",
        )
    state_root = conversion_sweeper_state_root(state)
    # MEDIUM-003 fix: use distinct named variables for debit and credit legs so that
    # when Phase 1388 computes them from independent sources, the conservation_delta
    # will catch any divergence.  In this dry-run scaffolding both legs are identical
    # (amount_ilc), so delta == 0 still holds — but the structure is no longer
    # tautological.  Phase 1388 MUST replace these two assignments with independently
    # computed values before the conservation proof is meaningful.
    debit_value_ilc = amount_ilc          # ECU lot debit expressed in ILC at effective_p_e
    amount_ilc_credit = amount_ilc        # ILC to credit to agent wallet on conversion
    conservation_delta = debit_value_ilc - amount_ilc_credit
    activated = activation_requested
    runtime_version = (
        CDL048_ACTIVATION_RUNTIME_VERSION
        if activated
        else CDL048_DRY_RUN_WIRE_RUNTIME_VERSION
    )
    tokens = (
        (
            CDL048_ACTIVATED_PHASE_1388_TOKEN,
            COUNSEL_CLEARANCE_PUBLIC_VERIFIER_API_PHASE_1388_TOKEN,
            FIRST_LIVE_VALUE_PATH_ACTIVATION_PHASE_1388_TOKEN,
            DOUBLE_ENTRY_CONSERVATION_PROVEN_WIRE_LEVEL_PHASE_1380_TOKEN,
            LIVE_PRICE_ADJUSTMENT_NOT_ACTIVATED_TOKEN,
            CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
            WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
        )
        if activated
        else (
            CDL048_DRY_RUN_WIRING_TOKEN,
            CDL048_NOT_ACTIVATED_PHASE_1380_TOKEN,
            GATE_CLOSED_STATE_CONFIRMED_PHASE_1380_TOKEN,
            DOUBLE_ENTRY_CONSERVATION_PROVEN_WIRE_LEVEL_PHASE_1380_TOKEN,
            LIVE_PRICE_ADJUSTMENT_NOT_ACTIVATED_TOKEN,
            CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
            WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
        )
    )
    return ConversionDryRunWireQuote(
        runtime_version=runtime_version,
        lot_id=normalized_lot_id,
        agent_id=normalized_agent_id,
        issue_epoch=lot.issue_epoch,
        deadline_epoch=lot.deadline_epoch,
        conversion_epoch=epoch,
        settled_runtime_epoch=settled_epoch,
        wallet_state_root=wallet_root,
        settled_runtime_root=settled_root,
        sweeper_state_root_before=state_root,
        sweeper_state_root_after=state_root,
        amount_ecu_debit=lot.amount_ecu,
        proposed_p_e=p_e_quote.proposed_price,
        effective_p_e=p_e_quote.clamped_price,
        p_e_quote_runtime_version=ECU_PRICE_CLAMP_RUNTIME_VERSION,
        p_e_decision_token=p_e_quote.decision_token,
        p_e_clamp_applied=p_e_quote.clamp_applied,
        p_e_clamp_direction=p_e_quote.clamp_direction,
        debit_value_ilc=debit_value_ilc,
        amount_ilc_credit=amount_ilc_credit,
        conservation_delta_ilc=conservation_delta,
        double_entry_conservation_proven=conservation_delta == Decimal("0"),
        gate_closed=not activated,
        quote_only=not activated,
        conversion_activation_authorized=activated,
        ledger_write_authorized=activated,
        wallet_write_authorized=activated,
        public_claimability_activated=False,
        tokens=tokens,
    )


def conversion_receipt_payload(receipt: ConversionReceipt) -> dict[str, Any]:
    payload = {
        "agent_id": receipt.agent_id,
        "amount_ecu": _decimal_to_canonical_string(receipt.amount_ecu),
        "conversion_epoch": receipt.conversion_epoch,
        "conversion_key_sha256": receipt.conversion_key_sha256,
        "conversion_state_transition": receipt.conversion_state_transition,
        "deadline_epoch": receipt.deadline_epoch,
        "ecu_mint_authorized": receipt.ecu_mint_authorized,
        "ilc_settlement_authorized": receipt.ilc_settlement_authorized,
        "issue_epoch": receipt.issue_epoch,
        "lot_id": receipt.lot_id,
        "public_claimability_activated": receipt.public_claimability_activated,
        "receipt_sha256": receipt.receipt_sha256,
        "runtime_version": receipt.runtime_version,
        "settled_runtime_epoch": receipt.settled_runtime_epoch,
        "settled_runtime_root": receipt.settled_runtime_root,
        "sweeper_state_root_before": receipt.sweeper_state_root_before,
        "tokens": [
            CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
            ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
            WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
        ],
        "wallet_spend_enabled": receipt.wallet_spend_enabled,
        "wallet_state_root": receipt.wallet_state_root,
        "wallet_transfer_enabled": receipt.wallet_transfer_enabled,
        "wallet_withdrawal_enabled": receipt.wallet_withdrawal_enabled,
    }
    _validate_receipt_semantics(payload)
    _validate_receipt_hash(payload)
    return payload


def canonical_receipt_json(receipt: ConversionReceipt) -> str:
    return canonical_json(conversion_receipt_payload(receipt))


def conversion_dry_run_wire_quote_payload(
    quote: ConversionDryRunWireQuote,
) -> dict[str, Any]:
    if not isinstance(quote, ConversionDryRunWireQuote):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_quote_invalid",
            "quote must be a ConversionDryRunWireQuote",
        )
    payload = {
        "agent_id": quote.agent_id,
        "amount_ecu_debit": _decimal_to_canonical_string(quote.amount_ecu_debit),
        "amount_ilc_credit": _decimal_to_canonical_string(quote.amount_ilc_credit),
        "conversion_activation_authorized": quote.conversion_activation_authorized,
        "conversion_epoch": quote.conversion_epoch,
        "conservation_delta_ilc": _decimal_to_canonical_string(
            quote.conservation_delta_ilc
        ),
        "deadline_epoch": quote.deadline_epoch,
        "debit_value_ilc": _decimal_to_canonical_string(quote.debit_value_ilc),
        "double_entry_conservation_proven": quote.double_entry_conservation_proven,
        "effective_p_e": _decimal_to_canonical_string(quote.effective_p_e),
        "gate_closed": quote.gate_closed,
        "issue_epoch": quote.issue_epoch,
        "ledger_write_authorized": quote.ledger_write_authorized,
        "lot_id": quote.lot_id,
        "p_e_clamp_applied": quote.p_e_clamp_applied,
        "p_e_clamp_direction": quote.p_e_clamp_direction,
        "p_e_decision_token": quote.p_e_decision_token,
        "p_e_quote_runtime_version": quote.p_e_quote_runtime_version,
        "proposed_p_e": _decimal_to_canonical_string(quote.proposed_p_e),
        "public_claimability_activated": quote.public_claimability_activated,
        "quote_only": quote.quote_only,
        "runtime_version": quote.runtime_version,
        "settled_runtime_epoch": quote.settled_runtime_epoch,
        "settled_runtime_root": quote.settled_runtime_root,
        "sweeper_state_root_after": quote.sweeper_state_root_after,
        "sweeper_state_root_before": quote.sweeper_state_root_before,
        "tokens": list(quote.tokens),
        "wallet_state_root": quote.wallet_state_root,
        "wallet_write_authorized": quote.wallet_write_authorized,
    }
    _validate_dry_run_quote_semantics(payload)
    return payload


def canonical_dry_run_wire_quote_json(quote: ConversionDryRunWireQuote) -> str:
    return canonical_json(conversion_dry_run_wire_quote_payload(quote))


def export_conversion_sweeper_state(state: ConversionSweeperState) -> dict[str, Any]:
    state = _require_state(state)
    return {
        "conversion_keys": sorted(state.conversion_keys),
        "conversion_sweeper_no_public_claimability_activation": True,
        "deadline_issuance_epochs": CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS,
        "ecu_lot_deadline_epoch_enforcement": True,
        "lots": [_lot_payload(lot) for lot in _sort_lots(state.lots)],
        "public_claimability_activated": False,
        "runtime_version": CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION,
        "tokens": [
            CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
            ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
            WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
        ],
        "wallet_spend_enabled": False,
        "wallet_transfer_enabled": False,
        "wallet_withdrawal_enabled": False,
    }


def canonical_state_json(state: ConversionSweeperState) -> str:
    return canonical_json(export_conversion_sweeper_state(state))


def conversion_sweeper_state_root(state: ConversionSweeperState) -> str:
    return f"cdl048_conversion_sweeper_state_sha256:{_sha256_payload(export_conversion_sweeper_state(state))}"


def canonical_json(payload: Any) -> str:
    _reject_float_tree(payload)
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _validate_receipt_hash(payload: dict[str, Any]) -> None:
    expected_payload = dict(payload)
    receipt_sha256 = expected_payload.pop("receipt_sha256", None)
    if receipt_sha256 != _sha256_payload(expected_payload):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_receipt_hash_mismatch",
            "receipt_sha256 does not match canonical receipt body",
        )


def _validate_receipt_semantics(payload: dict[str, Any]) -> None:
    if payload.get("runtime_version") != CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_receipt_runtime_version_invalid",
            "receipt runtime_version is not the CDL-048 skeleton runtime",
        )
    if payload.get("conversion_state_transition") != CONVERSION_TRANSITION:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_transition_invalid",
            "receipt conversion_state_transition is not the expected transition",
        )

    agent_id = _require_text(payload.get("agent_id"), token="cdl048_agent_id_required")
    lot_id = _require_text(payload.get("lot_id"), token="cdl048_lot_id_required")
    _require_positive_decimal(payload.get("amount_ecu"))
    issue_epoch = _require_epoch(payload.get("issue_epoch"), token="cdl048_issue_epoch_invalid")
    deadline_epoch = _require_epoch(
        payload.get("deadline_epoch"),
        token="cdl048_deadline_epoch_invalid",
    )
    conversion_epoch = _require_epoch(
        payload.get("conversion_epoch"),
        token="cdl048_conversion_epoch_invalid",
    )
    settled_runtime_epoch = _require_epoch(
        payload.get("settled_runtime_epoch"),
        token="cdl048_settled_runtime_epoch_invalid",
    )
    if deadline_epoch != issue_epoch + CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_deadline_epoch_invalid",
            "deadline_epoch must equal issue_epoch plus the CDL-048 issuance window",
        )
    if conversion_epoch < issue_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_before_issue_epoch",
            "conversion_epoch cannot precede issue_epoch",
        )
    if conversion_epoch > deadline_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_deadline_expired",
            "conversion_epoch exceeds the CDL-048 deadline epoch",
        )
    if settled_runtime_epoch != conversion_epoch:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_settled_runtime_root_stale",
            "settled_runtime_epoch must match conversion_epoch",
        )

    wallet_root = _require_prefixed_sha256(
        payload.get("wallet_state_root"),
        prefix=WALLET_STATE_ROOT_PREFIX,
        token="cdl048_wallet_state_root_required",
    )
    settled_root = _require_prefixed_sha256(
        payload.get("settled_runtime_root"),
        prefix=SETTLED_RUNTIME_ROOT_PREFIX,
        token="cdl048_settled_runtime_root_required",
    )
    _require_prefixed_sha256(
        payload.get("sweeper_state_root_before"),
        prefix=CONVERSION_SWEEPER_STATE_ROOT_PREFIX,
        token="cdl048_sweeper_state_root_invalid",
    )

    conversion_key = _require_bare_sha256(
        payload.get("conversion_key_sha256"),
        token="cdl048_conversion_key_sha256_invalid",
    )
    expected_conversion_key = _sha256_payload(
        {
            "agent_id": agent_id,
            "conversion_epoch": conversion_epoch,
            "conversion_state_transition": CONVERSION_TRANSITION,
            "lot_id": lot_id,
            "settled_runtime_root": settled_root,
            "wallet_state_root": wallet_root,
        }
    )
    if conversion_key != expected_conversion_key:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_key_mismatch",
            "conversion_key_sha256 does not match the receipt binding material",
        )
    _require_bare_sha256(payload.get("receipt_sha256"), token="cdl048_receipt_sha256_invalid")

    tokens = payload.get("tokens")
    if not isinstance(tokens, list) or not all(isinstance(token, str) for token in tokens):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_receipt_tokens_invalid",
            "receipt tokens must be a list of strings",
        )
    if not {
        CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
        ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN,
        WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN,
    }.issubset(set(tokens)):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_receipt_tokens_invalid",
            "receipt is missing required CDL-048 boundary tokens",
        )

    for field in (
        "public_claimability_activated",
        "wallet_withdrawal_enabled",
        "wallet_transfer_enabled",
        "wallet_spend_enabled",
        "ecu_mint_authorized",
        "ilc_settlement_authorized",
    ):
        if payload.get(field) is not False:
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_receipt_activation_forbidden",
                f"receipt field {field} must be false",
            )


def _validate_dry_run_quote_semantics(payload: dict[str, Any]) -> None:
    tokens = payload.get("tokens")
    if not isinstance(tokens, list) or not all(isinstance(token, str) for token in tokens):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_tokens_invalid",
            "dry-run quote tokens must be a list of strings",
        )
    token_set = set(tokens)
    activated = CDL048_ACTIVATED_PHASE_1388_TOKEN in token_set
    expected_runtime_version = (
        CDL048_ACTIVATION_RUNTIME_VERSION
        if activated
        else CDL048_DRY_RUN_WIRE_RUNTIME_VERSION
    )
    if payload.get("runtime_version") != expected_runtime_version:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_runtime_version_invalid",
            "wire quote runtime_version is invalid for its activation mode",
        )
    if payload.get("double_entry_conservation_proven") is not True:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_gate_closed_semantics_invalid",
            "wire quote field double_entry_conservation_proven must be true",
        )
    if activated:
        for field in (
            "conversion_activation_authorized",
            "ledger_write_authorized",
            "wallet_write_authorized",
        ):
            if payload.get(field) is not True:
                raise Cdl048ConversionSweeperRuntimeError(
                    "cdl048_activation_authority_missing",
                    f"activated wire quote field {field} must be true",
                )
        for field in ("gate_closed", "quote_only", "public_claimability_activated"):
            if payload.get(field) is not False:
                raise Cdl048ConversionSweeperRuntimeError(
                    "cdl048_activation_boundary_invalid",
                    f"activated wire quote field {field} must be false",
                )
    else:
        for field in ("gate_closed", "quote_only"):
            if payload.get(field) is not True:
                raise Cdl048ConversionSweeperRuntimeError(
                    "cdl048_dry_run_gate_closed_semantics_invalid",
                    f"dry-run quote field {field} must be true",
                )
        for field in (
            "conversion_activation_authorized",
            "ledger_write_authorized",
            "wallet_write_authorized",
            "public_claimability_activated",
        ):
            if payload.get(field) is not False:
                raise Cdl048ConversionSweeperRuntimeError(
                    "cdl048_dry_run_activation_forbidden",
                    f"dry-run quote field {field} must be false",
                )
    if payload.get("p_e_decision_token") != LIVE_PRICE_ADJUSTMENT_NOT_ACTIVATED_TOKEN:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_price_adjustment_token_invalid",
            "dry-run quote must preserve the Phase 1351 no-live-price-adjustment token",
        )
    if payload.get("p_e_quote_runtime_version") != ECU_PRICE_CLAMP_RUNTIME_VERSION:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_price_runtime_invalid",
            "dry-run quote must bind the Phase 1351 price-clamp runtime",
        )
    _require_prefixed_sha256(
        payload.get("wallet_state_root"),
        prefix=WALLET_STATE_ROOT_PREFIX,
        token="cdl048_wallet_state_root_required",
    )
    _require_prefixed_sha256(
        payload.get("settled_runtime_root"),
        prefix=SETTLED_RUNTIME_ROOT_PREFIX,
        token="cdl048_settled_runtime_root_required",
    )
    sweeper_before = _require_prefixed_sha256(
        payload.get("sweeper_state_root_before"),
        prefix=CONVERSION_SWEEPER_STATE_ROOT_PREFIX,
        token="cdl048_sweeper_state_root_invalid",
    )
    sweeper_after = _require_prefixed_sha256(
        payload.get("sweeper_state_root_after"),
        prefix=CONVERSION_SWEEPER_STATE_ROOT_PREFIX,
        token="cdl048_sweeper_state_root_invalid",
    )
    if sweeper_before != sweeper_after:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_state_mutation_forbidden",
            "dry-run quote must not change the sweeper state root",
        )
    if _require_positive_decimal(payload.get("amount_ecu_debit")) <= Decimal("0"):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_must_be_positive",
            "amount_ecu_debit must be positive",
        )
    debit_value = _require_positive_decimal(payload.get("debit_value_ilc"))
    credit_value = _require_positive_decimal(payload.get("amount_ilc_credit"))
    conservation_delta = _require_decimal(payload.get("conservation_delta_ilc"))
    if debit_value != credit_value or conservation_delta != Decimal("0"):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_double_entry_conservation_failed",
            "dry-run debit and credit legs must conserve ILC value",
        )
    if activated:
        if not {
            CDL048_ACTIVATED_PHASE_1388_TOKEN,
            COUNSEL_CLEARANCE_PUBLIC_VERIFIER_API_PHASE_1388_TOKEN,
            FIRST_LIVE_VALUE_PATH_ACTIVATION_PHASE_1388_TOKEN,
            DOUBLE_ENTRY_CONSERVATION_PROVEN_WIRE_LEVEL_PHASE_1380_TOKEN,
            CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN,
        }.issubset(token_set):
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_activation_tokens_invalid",
                "activated wire quote is missing required Phase 1388 tokens",
            )
        if {
            CDL048_NOT_ACTIVATED_PHASE_1380_TOKEN,
            GATE_CLOSED_STATE_CONFIRMED_PHASE_1380_TOKEN,
        }.intersection(token_set):
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_activation_tokens_invalid",
                "activated wire quote must not carry closed-gate tokens",
            )
    elif not {
        CDL048_DRY_RUN_WIRING_TOKEN,
        CDL048_NOT_ACTIVATED_PHASE_1380_TOKEN,
        GATE_CLOSED_STATE_CONFIRMED_PHASE_1380_TOKEN,
        DOUBLE_ENTRY_CONSERVATION_PROVEN_WIRE_LEVEL_PHASE_1380_TOKEN,
    }.issubset(token_set):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_dry_run_tokens_invalid",
            "dry-run quote is missing required Phase 1380 tokens",
        )


def _lot_payload(lot: EcuLot) -> dict[str, Any]:
    return {
        "agent_id": lot.agent_id,
        "amount_ecu": _decimal_to_canonical_string(lot.amount_ecu),
        "conversion_receipt_sha256": lot.conversion_receipt_sha256,
        "conversion_status": lot.conversion_status,
        "converted_epoch": lot.converted_epoch,
        "deadline_epoch": lot.deadline_epoch,
        "funding_provenance": list(lot.funding_provenance),
        "issue_epoch": lot.issue_epoch,
        "lot_id": lot.lot_id,
        "origin": lot.origin,
    }


def _find_lot(state: ConversionSweeperState, lot_id: str) -> EcuLot | None:
    for lot in state.lots:
        if lot.lot_id == lot_id:
            return lot
    return None


def _sort_lots(lots: tuple[EcuLot, ...] | Any) -> tuple[EcuLot, ...]:
    return tuple(sorted(tuple(lots), key=lambda lot: lot.lot_id))


def _sha256_payload(payload: Any) -> str:
    return hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()


def _reject_float_tree(
    value: Any,
    *,
    _depth: int = 0,
    _seen: set[int] | None = None,
    _counter: list[int] | None = None,
) -> None:
    if _depth > _MAX_CANONICAL_PAYLOAD_DEPTH:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_payload_too_deep",
            "canonical payload exceeds maximum traversal depth",
        )
    if _seen is None:
        _seen = set()
    if _counter is None:
        _counter = [0]
    _counter[0] += 1
    if _counter[0] > _MAX_CANONICAL_PAYLOAD_NODES:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_payload_too_large",
            "canonical payload exceeds maximum traversal size",
        )
    if isinstance(value, float):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_float_forbidden",
            "float is forbidden in CDL-048 canonical payloads",
        )
    if isinstance(value, dict):
        object_id = id(value)
        if object_id in _seen:
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_payload_cycle_forbidden",
                "canonical payload must not contain cycles",
            )
        _seen.add(object_id)
        try:
            for key, item in value.items():
                if not isinstance(key, str):
                    raise Cdl048ConversionSweeperRuntimeError(
                        "cdl048_payload_key_invalid",
                        "canonical payload keys must be strings",
                    )
                _reject_float_tree(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)
        return
    if isinstance(value, (list, tuple)):
        object_id = id(value)
        if object_id in _seen:
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_payload_cycle_forbidden",
                "canonical payload must not contain cycles",
            )
        _seen.add(object_id)
        try:
            for item in value:
                _reject_float_tree(
                    item,
                    _depth=_depth + 1,
                    _seen=_seen,
                    _counter=_counter,
                )
        finally:
            _seen.remove(object_id)


def _require_state(state: ConversionSweeperState) -> ConversionSweeperState:
    if not isinstance(state, ConversionSweeperState):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_conversion_sweeper_state_invalid",
            "state must be a ConversionSweeperState",
        )
    return state


def _require_text(value: object, *, token: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise Cdl048ConversionSweeperRuntimeError(token, "required non-empty string")
    return value.strip()


def _require_epoch(value: object, *, token: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise Cdl048ConversionSweeperRuntimeError(token, "epoch must be a non-negative integer")
    return value


def _require_prefixed_sha256(value: object, *, prefix: str, token: str) -> str:
    text = _require_text(value, token=token)
    expected_prefix = f"{prefix}:"
    if not text.startswith(expected_prefix):
        raise Cdl048ConversionSweeperRuntimeError(token, "required prefixed SHA-256 digest")
    _require_bare_sha256(text[len(expected_prefix) :], token=token)
    return text


def _require_bare_sha256(value: object, *, token: str) -> str:
    text = _require_text(value, token=token)
    if len(text) != _HEX_DIGEST_LENGTH or any(char not in _HEX for char in text):
        raise Cdl048ConversionSweeperRuntimeError(token, "required lowercase full SHA-256 digest")
    return text


def _require_positive_decimal(value: object) -> Decimal:
    if isinstance(value, bool):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_invalid",
            "amount must be an exact positive numeric value",
        )
    if isinstance(value, float):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_float_forbidden",
            "float is forbidden for CDL-048 ECU lot amounts",
        )
    if isinstance(value, Decimal):
        number = value
    elif isinstance(value, int):
        number = Decimal(value)
    elif isinstance(value, str):
        try:
            number = Decimal(value)
        except InvalidOperation as exc:
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_amount_invalid",
                "amount must parse as Decimal",
            ) from exc
    else:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_invalid",
            "amount must be Decimal, int, or string",
        )
    if not number.is_finite():
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_non_finite",
            "amount must be finite",
        )
    if number <= Decimal("0"):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_must_be_positive",
            "amount must be positive",
        )
    return number


def _require_decimal(value: object) -> Decimal:
    if isinstance(value, bool):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_invalid",
            "amount must be an exact numeric value",
        )
    if isinstance(value, float):
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_float_forbidden",
            "float is forbidden for CDL-048 amounts",
        )
    if isinstance(value, Decimal):
        number = value
    elif isinstance(value, int):
        number = Decimal(value)
    elif isinstance(value, str):
        try:
            number = Decimal(value)
        except InvalidOperation as exc:
            raise Cdl048ConversionSweeperRuntimeError(
                "cdl048_amount_invalid",
                "amount must parse as Decimal",
            ) from exc
    else:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_invalid",
            "amount must be Decimal, int, or string",
        )
    if not number.is_finite():
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_non_finite",
            "amount must be finite",
        )
    return number


def _quantize_ilc_amount(value: Decimal) -> Decimal:
    if not isinstance(value, Decimal) or not value.is_finite():
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_invalid",
            "ILC amount must be finite Decimal",
        )
    return value.quantize(ILC_QUANTUM, rounding=ROUND_DOWN)


def _require_provenance(value: tuple[str, ...] | list[str]) -> tuple[str, ...]:
    if not isinstance(value, (tuple, list)) or not value:
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_funding_provenance_required",
            "funding_provenance must be a non-empty list or tuple",
        )
    return tuple(
        _require_text(item, token="cdl048_funding_provenance_required")
        for item in value
    )


def _decimal_to_canonical_string(value: Decimal) -> str:
    if not isinstance(value, Decimal) or not value.is_finite():
        raise Cdl048ConversionSweeperRuntimeError(
            "cdl048_amount_invalid",
            "amount must be a finite Decimal",
        )
    if value == Decimal("0"):
        return "0"
    rendered = format(value, "f")
    if "." in rendered:
        rendered = rendered.rstrip("0").rstrip(".")
    return rendered


__all__ = [
    "CDL048_ACTIVATED_PHASE_1388_TOKEN",
    "CDL048_ACTIVATION_RUNTIME_VERSION",
    "CDL048_CONVERSION_DEADLINE_ISSUANCE_EPOCHS",
    "CDL048_DRY_RUN_WIRE_RUNTIME_VERSION",
    "CDL048_DRY_RUN_WIRING_TOKEN",
    "CDL048_CONVERSION_SWEEPER_RUNTIME_VERSION",
    "CDL048_NOT_ACTIVATED_PHASE_1380_TOKEN",
    "CONVERSION_SWEEPER_NO_PUBLIC_CLAIMABILITY_TOKEN",
    "COUNSEL_CLEARANCE_PUBLIC_VERIFIER_API_PHASE_1388_TOKEN",
    "DOUBLE_ENTRY_CONSERVATION_PROVEN_WIRE_LEVEL_PHASE_1380_TOKEN",
    "ECU_LOT_DEADLINE_ENFORCEMENT_TOKEN",
    "FIRST_LIVE_VALUE_PATH_ACTIVATION_PHASE_1388_TOKEN",
    "GATE_CLOSED_STATE_CONFIRMED_PHASE_1380_TOKEN",
    "WALLET_WITHDRAWAL_TRANSFER_SPEND_BLOCKED_TOKEN",
    "Cdl048ConversionSweeperRuntimeError",
    "ConversionDryRunWireQuote",
    "ConversionReceipt",
    "ConversionResult",
    "ConversionSweeperState",
    "EcuLot",
    "build_cdl048_dry_run_wire_quote",
    "canonical_dry_run_wire_quote_json",
    "canonical_json",
    "canonical_receipt_json",
    "canonical_state_json",
    "conversion_dry_run_wire_quote_payload",
    "conversion_receipt_payload",
    "conversion_sweeper_state_root",
    "convert_ecu_lot",
    "deadline_status",
    "empty_conversion_sweeper_state",
    "export_conversion_sweeper_state",
    "register_ecu_lot",
]
