"""
MCP CLI Adapter.

Command-line interface for invoking MCP tools locally with audit logging.
"""

from __future__ import annotations

import argparse
import json
import sys
import uuid
from pathlib import Path

from ilc_core.cli._cli_error import emit_cli_error
from ilc_core.exceptions import CliPayloadError, CliToolInvocationError
from ilc_core.node.node_v0 import ILCNodeV0
from ilc_core.mcp.node_service import NodeMCPToolService


def _read_payload(args: argparse.Namespace) -> dict:
    """
    Read payload from the appropriate source.
    
    Priority:
    1. --payload-file
    2. --payload - (stdin)
    3. --payload string
    """
    # Priority 1: payload file
    if args.payload_file:
        try:
            with open(args.payload_file, "r", encoding="utf-8") as f:
                payload = json.load(f)
        except FileNotFoundError:
            raise CliPayloadError(f"Payload file not found: {args.payload_file}")
        except json.JSONDecodeError as e:
            raise CliPayloadError(f"Invalid JSON in payload file: {e}")
        if not isinstance(payload, dict):
            raise CliPayloadError("Payload must be a JSON object")
        return payload
    
    # Priority 2 & 3: payload string or stdin
    if args.payload is None:
        raise CliPayloadError("No payload provided. Use --payload or --payload-file.")
    
    # Priority 2: stdin
    if args.payload == "-":
        try:
            payload = json.load(sys.stdin)
        except json.JSONDecodeError as e:
            raise CliPayloadError(f"Invalid JSON from stdin: {e}")
        if not isinstance(payload, dict):
            raise CliPayloadError("Payload must be a JSON object")
        return payload
    
    # Priority 3: payload string
    try:
        payload = json.loads(args.payload)
    except json.JSONDecodeError as e:
        raise CliPayloadError(f"Invalid JSON payload: {e}")
    if not isinstance(payload, dict):
        raise CliPayloadError("Payload must be a JSON object")
    return payload


def _invoke_tool(service: NodeMCPToolService, tool_name: str, payload: dict) -> dict:
    """Invoke an MCP tool and normalize invocation failures to CLI domain exceptions."""
    try:
        return service.handle_request(tool_name, payload)
    except ValueError as e:
        raise CliToolInvocationError(str(e)) from e


def main() -> int:
    """Main CLI entrypoint."""
    parser = argparse.ArgumentParser(
        description="Invoke MCP tools locally with audit logging."
    )
    parser.add_argument(
        "--tool",
        required=True,
        help="MCP tool name (e.g., ilc.capabilities.get)",
    )
    parser.add_argument(
        "--payload",
        help="JSON string payload (use '-' for stdin)",
    )
    parser.add_argument(
        "--payload-file",
        help="Path to JSON file containing payload",
    )
    parser.add_argument(
        "--data-dir",
        default="./data",
        help="Node data directory for audit log (default: ./data)",
    )
    parser.add_argument(
        "--node-id",
        help="Node ID for audit provenance (auto-generated if not provided)",
    )
    parser.add_argument(
        "--pretty",
        action="store_true",
        help="Pretty-print JSON output",
    )
    
    args = parser.parse_args()
    
    # Read payload from appropriate source
    try:
        payload = _read_payload(args)
    except CliPayloadError as e:
        emit_cli_error("mcp_payload_error", detail=str(e), exit_code=1)
    
    # Determine node ID
    node_id = args.node_id if args.node_id else f"mcp-cli-{uuid.uuid4().hex[:8]}"
    
    # Create node and service
    data_dir = Path(args.data_dir)
    node = ILCNodeV0(node_id=node_id, data_dir=data_dir)
    service = NodeMCPToolService(node)
    
    # Invoke tool
    try:
        result = _invoke_tool(service, args.tool, payload)
    except CliToolInvocationError as e:
        emit_cli_error("mcp_tool_error", detail=str(e), exit_code=1)
    
    # Output result
    if args.pretty:
        print(json.dumps(result, indent=2))
    else:
        print(json.dumps(result))
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
