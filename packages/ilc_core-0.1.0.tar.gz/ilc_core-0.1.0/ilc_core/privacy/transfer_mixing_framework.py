# PUBLIC_RC_EXCLUDE: transfer_mixing_framework_not_activated_phase_1359
# PUBLIC_RC_EXCLUDE_REASON: Default-off activation facade only; no production transfer routing authority.
# PUBLIC_RC_INCLUDE_REQUIRES: explicit privacy activation gate and sender-privacy proof.
"""Phase 1359 transfer-mixing/k-anonymity activation facade.

The Row-5 ``PrivacyLane`` runtime already carries the locked k-anonymity
mechanism. This module is only the production activation boundary: it can quote
the locked parameters, but it cannot route transfers while the gate is closed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ilc_core.privacy.lane import K_FALLBACK, K_PRIMARY, RELEASE_JITTER_EPOCHS

TRANSFER_MIXING_K_ANONYMITY_FRAMEWORK_TOKEN = (
    "transfer_mixing_k_anonymity_framework_phase_1359"
)
MIXING_FRAMEWORK_NOT_ACTIVATED_PRODUCTION_TOKEN = (
    "mixing_framework_not_activated_production_phase_1359"
)
ACTIVATION_GATE_REQUIRED = True


@dataclass(frozen=True)
class TransferMixingFrameworkQuote:
    """Default-off quote for future transfer-mixing activation."""

    activation_gate_required: bool
    production_route_active: bool
    requested_transfer_count: int
    primary_k: int
    fallback_k: int
    release_jitter_epochs: int
    framework_token: str
    not_activated_token: str


def build_transfer_mixing_framework_quote(
    *,
    requested_transfer_count: int,
) -> TransferMixingFrameworkQuote:
    """Return locked Row-5 parameters without routing transfers."""

    transfer_count = _require_non_negative_int(
        requested_transfer_count,
        "transfer_mixing_requested_transfer_count_invalid",
    )
    return TransferMixingFrameworkQuote(
        activation_gate_required=ACTIVATION_GATE_REQUIRED,
        production_route_active=False,
        requested_transfer_count=transfer_count,
        primary_k=K_PRIMARY,
        fallback_k=K_FALLBACK,
        release_jitter_epochs=RELEASE_JITTER_EPOCHS,
        framework_token=TRANSFER_MIXING_K_ANONYMITY_FRAMEWORK_TOKEN,
        not_activated_token=MIXING_FRAMEWORK_NOT_ACTIVATED_PRODUCTION_TOKEN,
    )


def route_transfer_through_mixing_framework(
    transfer: Any,
    *,
    protocol_epoch: int,
) -> None:
    """Fail closed until a later phase explicitly activates production routing."""

    _require_non_negative_int(protocol_epoch, "transfer_mixing_protocol_epoch_invalid")
    # Phase 1359 deliberately has no production routing implementation. Keep this
    # fail-closed even if a later edit changes the gate constant prematurely.
    raise ValueError(MIXING_FRAMEWORK_NOT_ACTIVATED_PRODUCTION_TOKEN)


def _require_non_negative_int(value: int, token: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValueError(token)
    if value < 0:
        raise ValueError(token)
    return value
