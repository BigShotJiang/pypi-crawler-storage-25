from __future__ import annotations

from collections import defaultdict
import hashlib

AESTHETIC_PANEL_RUNTIME_VERSION = 'aesthetic_panel_runtime_532.v0.1'
CDL_059_DEPENDENCY = 'cdl_059_ratified_531.v0.1'
BLOCKING_AUTHORITY_ACTIVE = False


def _validated_pool(agent_pool: list[dict]) -> list[dict]:
    validated: list[dict] = []
    seen_agent_ids: set[str] = set()
    for agent in agent_pool:
        if not isinstance(agent, dict):
            raise ValueError('agent_pool_entries_require_agent_id_and_model_type')
        if 'agent_id' not in agent or 'model_type' not in agent:
            raise ValueError('agent_pool_entries_require_agent_id_and_model_type')
        agent_id = str(agent['agent_id'])
        model_type = str(agent['model_type'])
        if not agent_id or not model_type:
            raise ValueError('agent_pool_entries_require_agent_id_and_model_type')
        if agent_id in seen_agent_ids:
            raise ValueError('duplicate_agent_id_in_pool')
        seen_agent_ids.add(agent_id)
        validated.append(agent)
    return validated


def compose_aesthetic_panel(agent_pool: list[dict], panel_size: int, seed: int | None = None) -> list[str]:
    if not isinstance(panel_size, int) or isinstance(panel_size, bool) or panel_size <= 0:
        raise ValueError('panel_size_must_be_positive_int')
    validated = _validated_pool(agent_pool)
    if len(validated) < panel_size:
        raise ValueError('insufficient_agent_pool_size')

    buckets: dict[str, list[str]] = defaultdict(list)
    for agent in validated:
        buckets[str(agent['model_type'])].append(str(agent['agent_id']))
    seed_token = str(seed) if seed is not None else "none"
    for model_type, ids in buckets.items():
        ids.sort(
            key=lambda agent_id: (
                hashlib.sha256(
                    f"{seed_token}|{model_type}|{agent_id}".encode("utf-8")
                ).hexdigest(),
                agent_id,
            )
        )

    ordered_types = sorted(buckets.keys(), key=lambda model_type: (len(buckets[model_type]), model_type))
    selected: list[str] = []
    while len(selected) < panel_size:
        progressed = False
        for model_type in ordered_types:
            if not buckets[model_type]:
                continue
            selected.append(buckets[model_type].pop(0))
            progressed = True
            if len(selected) == panel_size:
                break
        if not progressed:
            break
    if len(selected) != panel_size:
        raise ValueError('insufficient_agent_pool_size')
    return selected


def compute_aesthetic_score(votes: list[float]) -> float:
    if not votes:
        raise ValueError('votes_must_be_non_empty')
    normalized: list[float] = []
    for vote in votes:
        if isinstance(vote, bool) or not isinstance(vote, (int, float)):
            raise ValueError('vote_out_of_range')
        value = float(vote)
        if value < 0.0 or value > 1.0:
            raise ValueError('vote_out_of_range')
        normalized.append(value)
    mean = sum(normalized) / len(normalized)
    return max(0.0, min(1.0, mean))


def format_transparency_label(score: float) -> dict:
    if isinstance(score, bool) or not isinstance(score, (int, float)):
        raise ValueError('score_out_of_range')
    value = float(score)
    if value < 0.0 or value > 1.0:
        raise ValueError('score_out_of_range')
    return {
        'panel_type': 'digital_agent_aesthetic_consensus',
        'not_objective_truth': True,
        'score': value,
    }


def is_blocking_authority_active() -> bool:
    return False
