# PUBLIC_RC_EXCLUDE: internal_source_allowlist_export_execution_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1333 local export-gate tooling; not part of the public RC tree.
"""Phase 1333 source allowlist export execution gate.

This module may materialize a local candidate public source tree after the
allowlist, marker, helper-dependency, legacy-review, and dirty-included-file
checks pass. It never publishes a repository or package.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
from collections.abc import Iterable, Mapping, Sequence
from pathlib import Path, PurePosixPath
from typing import Any

from ilc_core.rc.public_rc_exclude_disposition import (
    build_public_rc_exclude_disposition_inventory,
)
from ilc_core.rc.source_allowlist_export_rehearsal import (
    DEFAULT_EXCLUDED_ROOTS,
    DEFAULT_INCLUDE_ROOTS,
    PUBLIC_RC_EXCLUDE_MARKER,
    build_source_allowlist_export_rehearsal,
)


SOURCE_ALLOWLIST_EXPORT_EXECUTION_GATE_VERSION = (
    "source_allowlist_export_execution_gate_phase_1333.v0.1"
)
PUBLIC_RC_EXCLUDE_MARKER_SCAN_REQUIRED_TOKEN = (
    "public_rc_exclude_marker_scan_required_phase_1333"
)
STRIPPED_HELPER_IMPORT_SCAN_REQUIRED_TOKEN = (
    "stripped_helper_import_scan_required_phase_1333"
)
LEGACY_UNTAGGED_REVIEW_REQUIRED_TOKEN = (
    "legacy_untagged_review_required_phase_1333"
)
SOURCE_PUBLICATION_NOT_AUTHORIZED_TOKEN = "source_publication_not_authorized_phase_1333"
PHASE_1334_RELEASE_ARTIFACT_PRODUCTION_GATE_NEXT_TOKEN = (
    "phase_1334_release_artifact_production_gate_next"
)
PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1333_TOKEN = (
    "public_rc_remains_blocked_after_phase_1333"
)

PHASE_1333_DEFAULT_EXPORT_ROOT = Path("out/public_rc/source_allowlist_export_phase_1333")
PHASE_1333_TREE_DIRNAME = "tree"
PHASE_1333_SIM_EXCLUDED_ROOT = (
    "ilc_core/sim",
    "simulation_harness_not_public_rc_runtime_default_excluded_phase_1333",
)
PHASE_1333_EXECUTION_EXCLUDED_ROOTS = (
    *DEFAULT_EXCLUDED_ROOTS,
    PHASE_1333_SIM_EXCLUDED_ROOT,
)

_ALLOWED_RESULTS = frozenset(
    {"executed_clean_export", "blocked_with_findings", "deferred_by_authority"}
)
_PUBLICATION_FALSE_FLAGS = (
    "source_publication_authorized",
    "public_repository_publication_authorized",
    "public_package_publication_authorized",
    "release_artifact_production_authorized",
    "release_key_generation_authorized",
    "release_envelope_production_authorized",
    "release_signing_material_generation_authorized",
    "signing_authorized",
    "public_rc_publication_claim_authorized",
    "public_claimability_api_authorized",
    "public_p2p_fetch_sidecar_serving_authorized",
    "identity_bootstrap_authorized",
    "wallet_ecu_ilc_activation_authorized",
    "genesis_atlas_mutation_or_signing_authorized",
    "cdl_mutation_authorized",
    "cdl_088_opening_authorized",
)


def phase_1333_required_tokens() -> list[str]:
    return [
        SOURCE_ALLOWLIST_EXPORT_EXECUTION_GATE_VERSION,
        PUBLIC_RC_EXCLUDE_MARKER_SCAN_REQUIRED_TOKEN,
        STRIPPED_HELPER_IMPORT_SCAN_REQUIRED_TOKEN,
        LEGACY_UNTAGGED_REVIEW_REQUIRED_TOKEN,
        SOURCE_PUBLICATION_NOT_AUTHORIZED_TOKEN,
        PHASE_1334_RELEASE_ARTIFACT_PRODUCTION_GATE_NEXT_TOKEN,
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1333_TOKEN,
    ]


def build_source_allowlist_export_execution_gate(
    *,
    repo_root: Path | str = Path("."),
    export_root: Path | str = PHASE_1333_DEFAULT_EXPORT_ROOT,
    include_roots: Sequence[str] = DEFAULT_INCLUDE_ROOTS,
    excluded_roots: Sequence[tuple[str, str]] = PHASE_1333_EXECUTION_EXCLUDED_ROOTS,
    force_include_paths: Iterable[str] = (),
    reviewed_legacy_paths: Iterable[str] = (),
    materialize: bool = True,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1333_repo_root_invalid")

    gate_scan = build_source_allowlist_export_rehearsal(
        repo_root=root,
        include_roots=include_roots,
        excluded_roots=excluded_roots,
        force_include_paths=force_include_paths,
        reviewed_legacy_paths=reviewed_legacy_paths,
    )
    dirty = _working_tree_status(root, gate_scan["included_files"])
    helper_inventory = build_public_rc_exclude_disposition_inventory()
    helper_check = _helper_export_check(gate_scan, helper_inventory)
    evidence_check = _evidence_completeness_check(gate_scan)
    preconditions = _precondition_checks(
        gate_scan=gate_scan,
        dirty=dirty,
        helper_check=helper_check,
        evidence_check=evidence_check,
    )
    result = (
        "executed_clean_export"
        if all(record["passed"] for record in preconditions)
        else "blocked_with_findings"
    )
    binary_verdict = _binary_verdict(result)

    target = _normalize_export_root(root, Path(export_root)) / PHASE_1333_TREE_DIRNAME
    materialized = _empty_materialized_tree_record(target)
    if result == "executed_clean_export" and materialize:
        materialized = _materialize_and_verify_export(
            repo_root=root,
            target=target,
            included_files=gate_scan["included_files"],
            include_roots=include_roots,
            excluded_roots=excluded_roots,
            reviewed_legacy_paths=reviewed_legacy_paths,
        )

    manifest: dict[str, Any] = {
        "candidate_scan": {
            "blocked_ambiguities": gate_scan["blocked_ambiguities"],
            "counts": gate_scan["counts"],
            "dependency_scan": gate_scan["dependency_scan"],
            "excluded_files": gate_scan["excluded_files"],
            "excluded_roots": gate_scan["excluded_roots"],
            "included_files": gate_scan["included_files"],
            "legacy_untagged_review": gate_scan["legacy_untagged_review"],
            "marker_scan": gate_scan["marker_scan"],
            "negative_case_matrix": gate_scan["negative_case_matrix"],
            "scanner_limitations": gate_scan["scanner_limitations"],
            "stripped_helpers": gate_scan["stripped_helpers"],
        },
        "clean_materialized_public_tree_produced": (
            result == "executed_clean_export" and materialized["materialized"]
        ),
        "dirty_worktree_policy": dirty,
        "evidence_completeness_check": evidence_check,
        "export_materialization": materialized,
        "gate_preconditions": preconditions,
        "graph_delta": "load_bearing_artifact_added:out/public_rc/source_allowlist_export_phase_1333/tree -> public-rc/source-export-candidate",
        "helper_flag_policy": _helper_flag_policy(helper_check),
        "manifest_evidence": {
            "file_hashes_recorded": True,
            "import_scan_recorded": True,
            "legacy_untagged_review_recorded": True,
            "marker_scan_recorded": True,
        },
        "mode": "source_allowlist_export_execution_gate",
        "next_phase": (
            PHASE_1334_RELEASE_ARTIFACT_PRODUCTION_GATE_NEXT_TOKEN
            if result == "executed_clean_export"
            else "phase_1333_fix_required_before_phase_1334"
        ),
        "non_authorization_floor": _non_authorization_floor(),
        "non_claims": _non_claims(),
        "package_profile_internal_helper_check": helper_check,
        "phase": 1333,
        "public_rc_remains_blocked": True,
        "rejection_criteria": _rejection_criteria(
            gate_scan=gate_scan,
            dirty=dirty,
            helper_check=helper_check,
            evidence_check=evidence_check,
        ),
        "required_tokens": phase_1333_required_tokens(),
        "result": result,
        "schema_version": SOURCE_ALLOWLIST_EXPORT_EXECUTION_GATE_VERSION,
        "source_allowlist_export_executed": result == "executed_clean_export",
        "source_allowlist_export_execution_gate_verdict": binary_verdict,
        "source_publication_authorized": False,
        "source_revision": {
            "git_head": _git_head(root),
            "source_revision_policy": (
                "current_worktree_export_allowed_only_when_included_files_are_not_dirty"
            ),
        },
    }
    manifest["manifest_hash"] = _manifest_hash_without_self_reference(manifest)
    return validate_source_allowlist_export_execution_gate(manifest)


def validate_source_allowlist_export_execution_gate(manifest: Mapping[str, Any]) -> dict[str, Any]:
    active = dict(manifest)
    if active.get("schema_version") != SOURCE_ALLOWLIST_EXPORT_EXECUTION_GATE_VERSION:
        raise ValueError("phase_1333_manifest_schema_invalid")
    if active.get("required_tokens") != phase_1333_required_tokens():
        raise ValueError("phase_1333_required_tokens_invalid")
    if active.get("result") not in _ALLOWED_RESULTS:
        raise ValueError("phase_1333_result_invalid")
    if active.get("source_allowlist_export_execution_gate_verdict") != _binary_verdict(
        active["result"]
    ):
        raise ValueError("phase_1333_binary_verdict_invalid")
    if active.get("source_publication_authorized") is not False:
        raise ValueError("phase_1333_source_publication_must_remain_unauthorized")
    if active.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1333_public_rc_blocked_flag_required")
    if active.get("manifest_hash") != _manifest_hash_without_self_reference(active):
        raise ValueError("phase_1333_manifest_hash_invalid")

    evidence = active.get("manifest_evidence")
    if not isinstance(evidence, Mapping) or not all(evidence.values()):
        raise ValueError("phase_1333_manifest_evidence_incomplete")

    candidate = _require_mapping(active.get("candidate_scan"), "phase_1333_candidate_scan")
    marker_scan = _require_mapping(candidate.get("marker_scan"), "phase_1333_marker_scan")
    import_scan = _require_mapping(candidate.get("dependency_scan"), "phase_1333_import_scan")
    legacy = _require_mapping(
        candidate.get("legacy_untagged_review"), "phase_1333_legacy_review"
    )
    helper_check = _require_mapping(
        active.get("package_profile_internal_helper_check"),
        "phase_1333_helper_check",
    )
    if active["result"] == "executed_clean_export" and helper_check.get("result") != "pass":
        raise ValueError("phase_1333_internal_helper_check_failed")

    materialized = _require_mapping(
        active.get("export_materialization"), "phase_1333_materialization"
    )
    if active["result"] == "executed_clean_export":
        if marker_scan.get("hit_count") != 0:
            raise ValueError("phase_1333_public_rc_exclude_marker_hit")
        if import_scan.get("stripped_helper_hit_count") != 0:
            raise ValueError("phase_1333_stripped_helper_import_hit")
        if legacy.get("ambiguity_count") != 0:
            raise ValueError("phase_1333_legacy_review_ambiguity")
        if active.get("source_allowlist_export_executed") is not True:
            raise ValueError("phase_1333_export_executed_flag_required")
        if active.get("clean_materialized_public_tree_produced") is not True:
            raise ValueError("phase_1333_clean_tree_flag_required")
        if materialized.get("materialized") is not True:
            raise ValueError("phase_1333_materialized_tree_required")
        post_scan = _require_mapping(materialized.get("post_materialization_scan"), "scan")
        if post_scan.get("marker_scan", {}).get("hit_count") != 0:
            raise ValueError("phase_1333_materialized_marker_hit")
        if post_scan.get("dependency_scan", {}).get("stripped_helper_hit_count") != 0:
            raise ValueError("phase_1333_materialized_import_hit")
        if post_scan.get("legacy_untagged_review", {}).get("ambiguity_count") != 0:
            raise ValueError("phase_1333_materialized_legacy_ambiguity")
    else:
        if materialized.get("materialized") is not False:
            raise ValueError("phase_1333_blocked_gate_must_not_materialize")

    canonical_source_allowlist_export_execution_gate_json(active)
    return active


def canonical_source_allowlist_export_execution_gate_json(manifest: Mapping[str, Any]) -> str:
    return json.dumps(manifest, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_source_allowlist_export_execution_gate_json(manifest: Mapping[str, Any]) -> str:
    return json.dumps(manifest, allow_nan=False, indent=2, sort_keys=True) + "\n"


def source_allowlist_export_execution_manifest_hash(manifest: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        canonical_source_allowlist_export_execution_gate_json(manifest).encode("utf-8")
    ).hexdigest()


def render_execution_gate_markdown(manifest: Mapping[str, Any]) -> str:
    counts = manifest["candidate_scan"]["counts"]
    materialized = manifest["export_materialization"]
    return "\n".join(
        [
            "# ILC Source Allowlist Export Execution Gate 1333 v0.1",
            "",
            f"**Result:** `{manifest['result']}`.",
            "**Publication:** not authorized.",
            "**Public RC:** remains blocked after Phase 1333.",
            "",
            "```text",
            *phase_1333_required_tokens(),
            "```",
            "",
            "## Decision",
            "",
            f"- Source allowlist export executed: `{manifest['source_allowlist_export_executed']}`.",
            f"- Binary verdict: `{manifest['source_allowlist_export_execution_gate_verdict']}`.",
            f"- Clean materialized public tree produced: `{manifest['clean_materialized_public_tree_produced']}`.",
            f"- Materialized tree path: `{materialized['tree_path']}`.",
            f"- Manifest hash: `{manifest['manifest_hash']}`.",
            "",
            "## Scan Summary",
            "",
            f"- Included files: `{counts['included_files']}`.",
            f"- Excluded files: `{counts['excluded_files']}`.",
            f"- PUBLIC_RC_EXCLUDE marker hits: `{counts['marker_hits']}`.",
            f"- Stripped-helper dependency hits: `{counts['dependency_hits']}`.",
            f"- Legacy review ambiguities: `{counts['blocked_ambiguities']}`.",
            f"- Dirty included files: `{len(manifest['dirty_worktree_policy']['dirty_included_files'])}`.",
            "",
            "## Gate Preconditions",
            "",
            *(
                f"- `{record['check_id']}`: `{record['status']}`."
                for record in manifest["gate_preconditions"]
            ),
            "",
            "## Non-Authorization",
            "",
            "Phase 1333 did not publish a repository or package, produce release artifacts, generate release keys or envelopes, sign, activate public serving, create identity artifacts, activate wallet/ECU/ILC paths, mutate Genesis/Atlas, mutate CDLs, open CDL-088, or claim public RC.",
            "",
        ]
    )


def write_execution_gate_outputs(
    *,
    json_out: Path | None,
    markdown_out: Path | None,
    manifest: Mapping[str, Any],
) -> None:
    if json_out is not None:
        _write_text_atomic(json_out, pretty_source_allowlist_export_execution_gate_json(manifest))
    if markdown_out is not None:
        _write_text_atomic(markdown_out, render_execution_gate_markdown(manifest))


def _materialize_and_verify_export(
    *,
    repo_root: Path,
    target: Path,
    included_files: Sequence[Mapping[str, Any]],
    include_roots: Sequence[str],
    excluded_roots: Sequence[tuple[str, str]],
    reviewed_legacy_paths: Iterable[str],
) -> dict[str, Any]:
    file_hashes = _materialize_export_tree(repo_root, target, included_files)
    post_scan = build_source_allowlist_export_rehearsal(
        repo_root=target,
        include_roots=include_roots,
        excluded_roots=excluded_roots,
        reviewed_legacy_paths=reviewed_legacy_paths,
    )
    tree_hash = _tree_hash(file_hashes)
    return {
        "exported_file_count": len(file_hashes),
        "file_hashes": file_hashes,
        "materialized": True,
        "post_materialization_scan": {
            "counts": post_scan["counts"],
            "dependency_scan": post_scan["dependency_scan"],
            "legacy_untagged_review": post_scan["legacy_untagged_review"],
            "marker_scan": post_scan["marker_scan"],
            "result": post_scan["result"],
        },
        "tree_path": target.as_posix(),
        "tree_sha256": tree_hash,
    }


def _materialize_export_tree(
    repo_root: Path,
    target: Path,
    included_files: Sequence[Mapping[str, Any]],
) -> list[dict[str, Any]]:
    target_parent = target.parent
    target_parent.mkdir(parents=True, exist_ok=True)
    tmp_path = Path(
        tempfile.mkdtemp(dir=target_parent, prefix=f".{target.name}.", suffix=".tmp")
    )
    try:
        file_hashes: list[dict[str, Any]] = []
        for record in sorted(included_files, key=lambda item: item["path"]):
            rel_path = _normalize_relative_path(record["path"], field="included_file")
            source = _source_file_under_root(repo_root, rel_path)
            payload = source.read_bytes()
            digest = hashlib.sha256(payload).hexdigest()
            if digest != record["hash_sha256"]:
                raise ValueError("phase_1333_included_file_hash_drift")
            destination = tmp_path / Path(*PurePosixPath(rel_path).parts)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(payload)
            file_hashes.append(
                {
                    "byte_size": len(payload),
                    "hash_sha256": digest,
                    "path": rel_path,
                }
            )
        if target.exists():
            shutil.rmtree(target)
        os.replace(tmp_path, target)
        return file_hashes
    except Exception:
        if tmp_path.exists():
            shutil.rmtree(tmp_path)
        raise


def _empty_materialized_tree_record(target: Path) -> dict[str, Any]:
    return {
        "exported_file_count": 0,
        "file_hashes": [],
        "materialized": False,
        "post_materialization_scan": {},
        "tree_path": target.as_posix(),
        "tree_sha256": "",
    }


def _precondition_checks(
    *,
    gate_scan: Mapping[str, Any],
    dirty: Mapping[str, Any],
    helper_check: Mapping[str, Any],
    evidence_check: Mapping[str, Any],
) -> list[dict[str, Any]]:
    checks = [
        _check("source_authority_present", True, "GO Phase 1333 received"),
        _check(
            "candidate_scan_passed",
            gate_scan["result"] == "pass",
            f"candidate_scan_result={gate_scan['result']}",
        ),
        _check(
            "public_rc_exclude_marker_scan_zero",
            gate_scan["marker_scan"]["hit_count"] == 0,
            f"marker_hits={gate_scan['marker_scan']['hit_count']}",
        ),
        _check(
            "stripped_helper_import_scan_zero",
            gate_scan["dependency_scan"]["stripped_helper_hit_count"] == 0,
            f"dependency_hits={gate_scan['dependency_scan']['stripped_helper_hit_count']}",
        ),
        _check(
            "legacy_untagged_review_clear",
            gate_scan["legacy_untagged_review"]["ambiguity_count"] == 0,
            f"ambiguities={gate_scan['legacy_untagged_review']['ambiguity_count']}",
        ),
        _check(
            "dirty_included_files_absent",
            len(dirty["dirty_included_files"]) == 0,
            f"dirty_included_files={len(dirty['dirty_included_files'])}",
        ),
        _check(
            "internal_helper_requirements_removed_or_replaced",
            helper_check["result"] == "pass",
            f"helper_check_result={helper_check['result']}",
        ),
        _check(
            "manifest_evidence_complete",
            evidence_check["result"] == "pass",
            f"evidence_check_result={evidence_check['result']}",
        ),
    ]
    return checks


def _binary_verdict(result: str) -> str:
    if result == "executed_clean_export":
        return "source_allowlist_export_execution_gate_verdict=pass"
    if result == "blocked_with_findings":
        return "source_allowlist_export_execution_gate_verdict=block"
    return "source_allowlist_export_execution_gate_verdict=deferred"


def _rejection_criteria(
    *,
    gate_scan: Mapping[str, Any],
    dirty: Mapping[str, Any],
    helper_check: Mapping[str, Any],
    evidence_check: Mapping[str, Any],
) -> list[dict[str, Any]]:
    return [
        _rejection_row(
            "public_rc_exclude_marker_remains_in_exported_tree",
            gate_scan["marker_scan"]["hit_count"] == 0,
            f"marker_hits={gate_scan['marker_scan']['hit_count']}",
        ),
        _rejection_row(
            "exported_module_imports_stripped_helper",
            gate_scan["dependency_scan"]["stripped_helper_hit_count"] == 0,
            f"transitive_import_scan_hits={gate_scan['dependency_scan']['stripped_helper_hit_count']}",
        ),
        _rejection_row(
            "exported_package_profile_requires_internal_fail_closed_helper",
            helper_check["result"] == "pass",
            f"unresolved_helpers={len(helper_check['unresolved_helpers'])}",
        ),
        _rejection_row(
            "helper_flags_flipped_instead_of_replaced_or_removed",
            True,
            "helper_flags_flipped=false",
        ),
        _rejection_row(
            "manifest_omits_marker_scan_or_import_scan_evidence",
            evidence_check["result"] == "pass",
            f"evidence_check_result={evidence_check['result']}",
        ),
        _rejection_row(
            "untagged_legacy_docs_research_planning_included_without_review",
            gate_scan["legacy_untagged_review"]["ambiguity_count"] == 0,
            f"legacy_ambiguities={gate_scan['legacy_untagged_review']['ambiguity_count']}",
        ),
        _rejection_row(
            "dirty_worktree_file_included_in_export",
            len(dirty["dirty_included_files"]) == 0,
            f"dirty_included_files={len(dirty['dirty_included_files'])}",
        ),
    ]


def _rejection_row(criteria_id: str, passed: bool, evidence: str) -> dict[str, Any]:
    return {
        "criteria_id": criteria_id,
        "evidence": evidence,
        "triggered": not passed,
        "verdict": "not_triggered" if passed else "triggered_block",
    }


def _check(check_id: str, passed: bool, evidence: str) -> dict[str, Any]:
    return {
        "check_id": check_id,
        "evidence": evidence,
        "passed": passed,
        "status": "pass" if passed else "fail_closed",
    }


def _helper_export_check(
    gate_scan: Mapping[str, Any],
    helper_inventory: Mapping[str, Any],
) -> dict[str, Any]:
    included = {record["path"] for record in gate_scan["included_files"]}
    excluded = {record["path"]: record for record in gate_scan["excluded_files"]}
    helper_records = []
    for helper in helper_inventory["helper_disposition_inventory"]:
        path = helper["path"]
        excluded_record = excluded.get(path)
        helper_records.append(
            {
                "disposition": helper["disposition"],
                "excluded": excluded_record is not None,
                "helper_id": helper["helper_id"],
                "included": path in included,
                "marker_removal_authorized": False,
                "path": path,
                "replacement_boundary": helper["replacement_boundary"],
            }
        )
    failures = [
        record
        for record in helper_records
        if record["included"] or not record["excluded"]
    ]
    return {
        "helper_records": helper_records,
        "result": "pass" if not failures else "fail_closed",
        "stripped_helper_dependency_hits": gate_scan["dependency_scan"][
            "stripped_helper_hit_count"
        ],
        "stripped_helper_dependency_scan_token": gate_scan["dependency_scan"]["token"],
        "unresolved_helpers": failures,
    }


def _helper_flag_policy(helper_check: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "helper_flags_flipped": False,
        "helper_promotion_authorized": False,
        "helper_stripping_by_source_mutation_authorized": False,
        "marker_removal_authorized": False,
        "policy": (
            "helpers are excluded from the materialized tree; no helper source flag "
            "is flipped from false to true"
        ),
        "result": helper_check["result"],
    }


def _evidence_completeness_check(gate_scan: Mapping[str, Any]) -> dict[str, Any]:
    required = {
        "dependency_scan": isinstance(gate_scan.get("dependency_scan"), Mapping),
        "excluded_files": isinstance(gate_scan.get("excluded_files"), list),
        "included_files": isinstance(gate_scan.get("included_files"), list),
        "legacy_untagged_review": isinstance(gate_scan.get("legacy_untagged_review"), Mapping),
        "marker_scan": isinstance(gate_scan.get("marker_scan"), Mapping),
    }
    return {
        "required_sections": required,
        "result": "pass" if all(required.values()) else "fail_closed",
    }


def _working_tree_status(repo_root: Path, included_files: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    dirty_records = _git_status_porcelain(repo_root)
    included = {record["path"] for record in included_files}
    dirty_included = [
        record for record in dirty_records if record["path"] in included
    ]
    dirty_excluded = [
        record for record in dirty_records if record["path"] not in included
    ]
    return {
        "dirty_excluded_or_non_exported_files": dirty_excluded,
        "dirty_included_files": dirty_included,
        "dirty_path_count": len(dirty_records),
        "policy": "included files must not be dirty at materialization time",
        "status": "pass" if not dirty_included else "fail_closed",
    }


def _git_status_porcelain(repo_root: Path) -> list[dict[str, str]]:
    try:
        proc = subprocess.run(
            ["git", "status", "--porcelain=v1"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return []
    records = []
    for line in proc.stdout.splitlines():
        if not line:
            continue
        status = line[:2]
        raw_path = line[3:]
        if " -> " in raw_path:
            raw_path = raw_path.split(" -> ", maxsplit=1)[1]
        records.append({"path": raw_path, "status": status})
    return sorted(records, key=lambda item: item["path"])


def _git_head(repo_root: Path) -> str:
    try:
        proc = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo_root,
            check=True,
            capture_output=True,
            text=True,
        )
    except (OSError, subprocess.CalledProcessError):
        return "git_head_unavailable"
    return proc.stdout.strip()


def _source_file_under_root(repo_root: Path, rel_path: str) -> Path:
    path = repo_root / Path(*PurePosixPath(rel_path).parts)
    if path.is_symlink():
        raise ValueError("phase_1333_symlink_export_rejected")
    resolved_parent = path.parent.resolve(strict=False)
    if resolved_parent != repo_root and repo_root not in resolved_parent.parents:
        raise ValueError("phase_1333_path_escape_rejected")
    if not path.is_file():
        raise ValueError("phase_1333_export_source_file_missing")
    return path


def _normalize_relative_path(raw: str, *, field: str) -> str:
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError(f"phase_1333_{field}_invalid")
    if "\\" in raw or raw.startswith("/") or raw.startswith("~"):
        raise ValueError(f"phase_1333_{field}_not_repo_relative")
    path = PurePosixPath(raw)
    if path.is_absolute() or str(path) in {"", "."}:
        raise ValueError(f"phase_1333_{field}_not_repo_relative")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"phase_1333_{field}_traversal_rejected")
    return path.as_posix()


def _normalize_export_root(repo_root: Path, export_root: Path) -> Path:
    target = export_root if export_root.is_absolute() else repo_root / export_root
    resolved = target.resolve(strict=False)
    if not resolved.as_posix():
        raise ValueError("phase_1333_export_root_invalid")
    if repo_root in resolved.parents and "out" not in resolved.relative_to(repo_root).parts:
        raise ValueError("phase_1333_export_root_must_use_out_or_external_path")
    return resolved


def _tree_hash(file_hashes: Sequence[Mapping[str, Any]]) -> str:
    payload = "\n".join(
        f"{record['path']}\t{record['hash_sha256']}\t{record['byte_size']}"
        for record in sorted(file_hashes, key=lambda item: item["path"])
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _manifest_hash_without_self_reference(manifest: Mapping[str, Any]) -> str:
    clone = json.loads(canonical_source_allowlist_export_execution_gate_json(manifest))
    clone["manifest_hash"] = ""
    return source_allowlist_export_execution_manifest_hash(clone)


def _non_authorization_floor() -> dict[str, bool]:
    floor = {key: False for key in _PUBLICATION_FALSE_FLAGS}
    floor["source_allowlist_export_execution_authorized_by_go_phase_1333"] = True
    return floor


def _non_claims() -> list[str]:
    return [
        "no_source_publication",
        "no_public_repository_publication",
        "no_public_package_publication",
        "no_release_artifact_production",
        "no_release_key_generation",
        "no_release_envelope_production",
        "no_release_signing_material_generation",
        "no_signing",
        "no_public_rc_publication_or_claim",
        "no_public_claimability_api_activation",
        "no_public_p2p_fetch_sidecar_serving_activation",
        "no_identity_bootstrap",
        "no_wallet_ecu_ilc_activation",
        "no_genesis_atlas_mutation_or_signing",
        "no_cdl_mutation_or_cdl_088_opening",
        "source_publication_not_authorized_phase_1333",
        "public_rc_remains_blocked_after_phase_1333",
    ]


def _require_mapping(value: object, token: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(token)
    return value


def _write_text_atomic(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        text=True,
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        os.replace(tmp_path, path)
    except Exception:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path("."))
    parser.add_argument("--export-root", type=Path, default=PHASE_1333_DEFAULT_EXPORT_ROOT)
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--markdown-out", type=Path)
    args = parser.parse_args(argv)

    manifest = build_source_allowlist_export_execution_gate(
        repo_root=args.repo_root,
        export_root=args.export_root,
    )
    write_execution_gate_outputs(
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        manifest=manifest,
    )
    if args.json_out is None and args.markdown_out is None:
        print(pretty_source_allowlist_export_execution_gate_json(manifest), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "LEGACY_UNTAGGED_REVIEW_REQUIRED_TOKEN",
    "PHASE_1333_EXECUTION_EXCLUDED_ROOTS",
    "PHASE_1334_RELEASE_ARTIFACT_PRODUCTION_GATE_NEXT_TOKEN",
    "PUBLIC_RC_EXCLUDE_MARKER_SCAN_REQUIRED_TOKEN",
    "PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1333_TOKEN",
    "SOURCE_ALLOWLIST_EXPORT_EXECUTION_GATE_VERSION",
    "SOURCE_PUBLICATION_NOT_AUTHORIZED_TOKEN",
    "STRIPPED_HELPER_IMPORT_SCAN_REQUIRED_TOKEN",
    "build_source_allowlist_export_execution_gate",
    "canonical_source_allowlist_export_execution_gate_json",
    "phase_1333_required_tokens",
    "pretty_source_allowlist_export_execution_gate_json",
    "render_execution_gate_markdown",
    "source_allowlist_export_execution_manifest_hash",
    "validate_source_allowlist_export_execution_gate",
    "write_execution_gate_outputs",
]
