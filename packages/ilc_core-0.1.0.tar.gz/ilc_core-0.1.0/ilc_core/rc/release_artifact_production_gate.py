# PUBLIC_RC_EXCLUDE: internal_release_artifact_production_gate_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1334 local unsigned artifact gate tooling; not part of the public RC tree.
"""Phase 1334 release artifact production gate.

This module produces a deterministic unsigned source-release tarball only after
Phase 1333 recorded a clean materialized public source tree. It never publishes,
signs, generates keys, or produces release envelopes.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import os
import re
import shutil
import tarfile
import tempfile
from collections.abc import Mapping, Sequence
from pathlib import Path, PurePosixPath
from typing import Any


RELEASE_ARTIFACT_PRODUCTION_GATE_VERSION = (
    "release_artifact_production_gate_phase_1334.v0.1"
)
RELEASE_ARTIFACT_MANIFEST_VALIDATED_TOKEN = (
    "release_artifact_manifest_validated_phase_1334"
)
CLEAN_SOURCE_EXPORT_DEPENDENCY_VERIFIED_TOKEN = (
    "clean_source_export_dependency_verified_phase_1334"
)
RELEASE_ARTIFACTS_UNSIGNED_BY_DEFAULT_TOKEN = (
    "release_artifacts_unsigned_by_default_phase_1334"
)
PHASE_1335_RELEASE_KEYS_ENVELOPES_GENERATION_GATE_NEXT_TOKEN = (
    "phase_1335_release_keys_envelopes_generation_gate_next"
)
PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1334_TOKEN = (
    "public_rc_remains_blocked_after_phase_1334"
)

PHASE_1213_SCHEMA_PATH = Path("docs/specs/ilc_release_artifact_manifest_schema_1213_v0.1.md")
PHASE_1333_MANIFEST_PATH = Path(
    "docs/specs/ilc_source_allowlist_export_execution_gate_1333_v0.1.json"
)
PHASE_1334_DEFAULT_ARTIFACT_ROOT = Path("out/release_artifacts/phase_1334")
PHASE_1334_DEFAULT_JSON_REPORT = Path(
    "docs/specs/ilc_release_artifact_production_gate_1334_v0.1.json"
)
PHASE_1334_DEFAULT_MARKDOWN_REPORT = Path(
    "docs/specs/ilc_release_artifact_production_gate_1334_v0.1.md"
)
SOURCE_TARBALL_NAME = "ilc-source-release-phase-1334.tar.gz"
SOURCE_TARBALL_ROOT = "ilc-source-release-phase-1334"
SOURCE_TARBALL_ARTIFACT_ID = "ilc-artifact:source-release-tarball@phase-1334"

_ALLOWED_GATE_RESULTS = frozenset(
    {"artifacts_produced_unsigned", "blocked_with_findings", "deferred_by_authority"}
)
_PHASE_1213_REQUIRED_FIELDS = frozenset(
    {
        "artifact_id",
        "artifact_type",
        "canonical_hash",
        "lineage_reference",
        "produced_phase",
        "ratification_token",
        "signing_status",
    }
)
_PHASE_1213_ALLOWED_ARTIFACT_TYPES = frozenset(
    {
        "runtime_module",
        "genesis_bundle",
        "cli_binary",
        "documentation_bundle",
        "source_release_tarball",
        "public_repository_tag",
        "container_image",
        "star_map_release_envelope",
        "operator_bootstrap_bundle",
        "verification_bundle",
    }
)
_ARTIFACT_ID_RE = re.compile(r"^ilc-artifact:[a-z0-9][a-z0-9-]*@phase-[1-9][0-9]*$")
_SHA256_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_GENESIS_LINEAGE_RE = re.compile(r"^genesis:v[0-9]+(\.[0-9]+)*$")
_ARTIFACT_LINEAGE_RE = re.compile(
    r"^artifact:ilc-artifact:[a-z0-9][a-z0-9-]*@phase-[1-9][0-9]*@sha256:[0-9a-f]{64}$"
)


def phase_1334_required_tokens() -> list[str]:
    return [
        RELEASE_ARTIFACT_PRODUCTION_GATE_VERSION,
        RELEASE_ARTIFACT_MANIFEST_VALIDATED_TOKEN,
        CLEAN_SOURCE_EXPORT_DEPENDENCY_VERIFIED_TOKEN,
        RELEASE_ARTIFACTS_UNSIGNED_BY_DEFAULT_TOKEN,
        PHASE_1335_RELEASE_KEYS_ENVELOPES_GENERATION_GATE_NEXT_TOKEN,
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1334_TOKEN,
    ]


def build_release_artifact_production_gate(
    *,
    repo_root: Path | str = Path("."),
    phase_1333_manifest_path: Path | str = PHASE_1333_MANIFEST_PATH,
    artifact_root: Path | str = PHASE_1334_DEFAULT_ARTIFACT_ROOT,
    produce_artifacts: bool = True,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1334_repo_root_invalid")

    phase_1333_manifest = _load_json(root / phase_1333_manifest_path)
    source_export = _validate_phase_1333_dependency(
        repo_root=root,
        manifest_path=root / phase_1333_manifest_path,
        manifest=phase_1333_manifest,
    )
    preconditions = _gate_preconditions(source_export)
    result = (
        "artifacts_produced_unsigned"
        if produce_artifacts and all(record["passed"] for record in preconditions)
        else "blocked_with_findings"
    )

    artifacts: list[dict[str, Any]] = []
    artifact_manifests: list[dict[str, Any]] = []
    if result == "artifacts_produced_unsigned":
        tarball = _produce_source_release_tarball(
            repo_root=root,
            tree_path=Path(source_export["tree_path"]),
            artifact_root=_resolve_under_repo(root, Path(artifact_root)),
        )
        artifact_manifest = _source_tarball_artifact_manifest(tarball)
        validate_phase_1213_artifact_manifest(artifact_manifest)
        artifacts.append(tarball)
        artifact_manifests.append(artifact_manifest)

    manifest: dict[str, Any] = {
        "artifact_manifests": artifact_manifests,
        "artifacts": artifacts,
        "atlas_g_status": _atlas_g_status(),
        "clean_source_export_dependency": source_export,
        "gate_preconditions": preconditions,
        "graph_delta": (
            "graph_delta=load_bearing_artifact_added:out/release_artifacts/phase_1334/"
            "ilc-source-release-phase-1334.tar.gz -> public-rc/release-artifact-candidate"
            if result == "artifacts_produced_unsigned"
            else "graph_delta=deferred:phase_1334_artifacts_blocked"
        ),
        "manifest_hash": "0" * 64,
        "mode": "release_artifact_production_gate",
        "next_phase": (
            PHASE_1335_RELEASE_KEYS_ENVELOPES_GENERATION_GATE_NEXT_TOKEN
            if result == "artifacts_produced_unsigned"
            else "phase_1334_fix_required_before_phase_1335"
        ),
        "non_authorization_floor": _non_authorization_floor(result),
        "non_claims": _non_claims(result),
        "phase": 1334,
        "phase_1213_manifest_validation": _phase_1213_validation_record(
            artifact_manifests
        ),
        "public_rc_remains_blocked": True,
        "release_artifact_production_gate_verdict": _binary_verdict(result),
        "required_tokens": phase_1334_required_tokens(),
        "result": result,
        "schema_version": RELEASE_ARTIFACT_PRODUCTION_GATE_VERSION,
        "unsigned_artifact_policy": _unsigned_artifact_policy(artifact_manifests),
    }
    manifest["manifest_hash"] = _manifest_hash_without_self_reference(manifest)
    return validate_release_artifact_production_gate(manifest)


def validate_release_artifact_production_gate(manifest: Mapping[str, Any]) -> dict[str, Any]:
    active = dict(manifest)
    if active.get("schema_version") != RELEASE_ARTIFACT_PRODUCTION_GATE_VERSION:
        raise ValueError("phase_1334_schema_version_invalid")
    if active.get("required_tokens") != phase_1334_required_tokens():
        raise ValueError("phase_1334_required_tokens_invalid")
    if active.get("result") not in _ALLOWED_GATE_RESULTS:
        raise ValueError("phase_1334_result_invalid")
    if active.get("release_artifact_production_gate_verdict") != _binary_verdict(
        active["result"]
    ):
        raise ValueError("phase_1334_binary_verdict_invalid")
    if active.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1334_public_rc_blocked_flag_required")
    if active.get("manifest_hash") != _manifest_hash_without_self_reference(active):
        raise ValueError("phase_1334_manifest_hash_invalid")

    non_auth = _require_mapping(
        active.get("non_authorization_floor"), "phase_1334_non_authorization_floor"
    )
    for key, value in non_auth.items():
        if key == "release_artifact_production_authorized_by_go_phase_1334":
            if value is not (active["result"] == "artifacts_produced_unsigned"):
                raise ValueError("phase_1334_artifact_authority_flag_invalid")
            continue
        if value is not False:
            raise ValueError("phase_1334_non_authorization_floor_invalid")

    source_export = _require_mapping(
        active.get("clean_source_export_dependency"), "phase_1334_source_export"
    )
    if (
        active["result"] == "artifacts_produced_unsigned"
        and source_export.get("dependency_result") != "pass"
    ):
        raise ValueError("phase_1334_clean_source_dependency_not_pass")

    if active["result"] == "artifacts_produced_unsigned":
        artifacts = _require_sequence(active.get("artifacts"), "phase_1334_artifacts")
        artifact_manifests = _require_sequence(
            active.get("artifact_manifests"), "phase_1334_artifact_manifests"
        )
        if len(artifacts) != 1 or len(artifact_manifests) != 1:
            raise ValueError("phase_1334_expected_one_artifact")
        validate_phase_1213_artifact_manifest(_require_mapping(artifact_manifests[0], "phase_1334_artifact_manifest"))
        if _require_mapping(artifacts[0], "phase_1334_artifact").get(
            "canonical_hash"
        ) != artifact_manifests[0]["canonical_hash"]:
            raise ValueError("phase_1334_artifact_hash_mismatch")
    else:
        if active.get("artifacts") or active.get("artifact_manifests"):
            raise ValueError("phase_1334_blocked_manifest_must_not_list_artifacts")

    unsigned_policy = _require_mapping(
        active.get("unsigned_artifact_policy"), "phase_1334_unsigned_policy"
    )
    if unsigned_policy.get("all_artifacts_unsigned") is not True:
        raise ValueError("phase_1334_unsigned_policy_invalid")
    return active


def validate_phase_1213_artifact_manifest(
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    active = dict(manifest)
    if frozenset(active) != _PHASE_1213_REQUIRED_FIELDS:
        raise ValueError("phase_1334_phase_1213_manifest_fields_invalid")
    if not _is_text(active.get("artifact_id")) or not _ARTIFACT_ID_RE.fullmatch(
        active["artifact_id"]
    ):
        raise ValueError("phase_1334_phase_1213_artifact_id_invalid")
    if active.get("artifact_type") not in _PHASE_1213_ALLOWED_ARTIFACT_TYPES:
        raise ValueError("phase_1334_phase_1213_artifact_type_invalid")
    if not _is_text(active.get("canonical_hash")) or not _SHA256_RE.fullmatch(
        active["canonical_hash"]
    ):
        raise ValueError("phase_1334_phase_1213_canonical_hash_invalid")
    lineage = active.get("lineage_reference")
    if not _is_text(lineage) or not (
        _GENESIS_LINEAGE_RE.fullmatch(lineage)
        or _ARTIFACT_LINEAGE_RE.fullmatch(lineage)
    ):
        raise ValueError("phase_1334_phase_1213_lineage_reference_invalid")
    if (
        not isinstance(active.get("produced_phase"), int)
        or isinstance(active["produced_phase"], bool)
        or active["produced_phase"] < 1
    ):
        raise ValueError("phase_1334_phase_1213_produced_phase_invalid")
    if not _is_text(active.get("ratification_token")):
        raise ValueError("phase_1334_phase_1213_ratification_token_invalid")
    if active.get("signing_status") not in {"signed", "unsigned", "deferred"}:
        raise ValueError("phase_1334_phase_1213_signing_status_invalid")
    canonical_json(active)
    return active


def canonical_json(payload: Mapping[str, Any]) -> str:
    _reject_unsafe_json_tree(payload)
    return json.dumps(payload, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_json(payload: Mapping[str, Any]) -> str:
    _reject_unsafe_json_tree(payload)
    return json.dumps(payload, allow_nan=False, indent=2, sort_keys=True) + "\n"


def render_markdown_report(manifest: Mapping[str, Any]) -> str:
    active = validate_release_artifact_production_gate(manifest)
    artifact_rows = [
        "| Artifact | Type | Signing | Hash |",
        "|----------|------|---------|------|",
    ]
    for artifact_manifest in active["artifact_manifests"]:
        artifact_rows.append(
            "| {artifact_id} | {artifact_type} | {signing_status} | {canonical_hash} |".format(
                **artifact_manifest
            )
        )
    if len(artifact_rows) == 2:
        artifact_rows.append("| none | none | none | none |")

    source = active["clean_source_export_dependency"]
    preconditions = [
        "| Check | Status | Evidence |",
        "|-------|--------|----------|",
    ]
    for record in active["gate_preconditions"]:
        preconditions.append(
            f"| {record['check_id']} | {record['status']} | {record['evidence']} |"
        )

    return "\n".join(
        [
            "# ILC Release Artifact Production Gate 1334 v0.1",
            "",
            "Status: release artifact gate executed / unsigned artifacts only",
            "Phase: 1334",
            "",
            "```text",
            *active["required_tokens"],
            "```",
            "",
            "## 1. Verdict",
            "",
            f"`{active['release_artifact_production_gate_verdict']}`",
            "",
            f"Result: `{active['result']}`.",
            f"Manifest hash: `{active['manifest_hash']}`.",
            f"Public RC remains blocked: `{active['public_rc_remains_blocked']}`.",
            "",
            "## 2. Artifact Decision",
            "",
            *artifact_rows,
            "",
            "Artifacts are unsigned by default. Phase 1334 does not generate release keys,",
            "produce release envelopes, sign artifacts, publish a repository or package,",
            "or claim public RC.",
            "",
            "## 3. Clean Source Export Dependency",
            "",
            f"Phase 1333 result: `{source['phase_1333_result']}`.",
            f"Phase 1333 verdict: `{source['phase_1333_verdict']}`.",
            f"Tree path: `{source['tree_path']}`.",
            f"Tree hash: `{source['tree_sha256']}`.",
            f"Recomputed tree hash: `{source['recomputed_tree_sha256']}`.",
            f"Exported files: `{source['exported_file_count']}`.",
            f"Marker hits: `{source['public_rc_exclude_marker_hits']}`.",
            f"Stripped-helper import hits: `{source['stripped_helper_import_hits']}`.",
            f"Legacy ambiguities: `{source['legacy_untagged_ambiguities']}`.",
            "",
            "## 4. Gate Preconditions",
            "",
            *preconditions,
            "",
            "## 5. Manifest Validation",
            "",
            f"Phase 1213 manifest validation: `{active['phase_1213_manifest_validation']['result']}`.",
            f"Unsigned policy: `{active['unsigned_artifact_policy']['result']}`.",
            "",
            "## 6. Non-Authorization Boundary",
            "",
            "Phase 1334 does not authorize public repository publication, public package",
            "publication, public RC claim, release-key generation, release-envelope",
            "production, signing, v0.2 signing, public claimability/API activation,",
            "public P2P/fetch/sidecar serving, Genesis mutation/signing, identity",
            "artifacts, wallet actions, ECU minting, ILC settlement, or public",
            "confidential coordination serving.",
            "",
            "## 7. Graph Delta",
            "",
            "```text",
            active["graph_delta"],
            "graph_delta=support_only:docs/specs/ilc_release_artifact_production_gate_1334_v0.1.json -> release-artifact-gate",
            "graph_delta=support_only:docs/specs/ilc_release_artifact_production_gate_1334_v0.1.md -> release-artifact-gate",
            "```",
            "",
        ]
    )


def write_phase_1334_outputs(
    *,
    repo_root: Path | str = Path("."),
    json_out: Path | str = PHASE_1334_DEFAULT_JSON_REPORT,
    markdown_out: Path | str = PHASE_1334_DEFAULT_MARKDOWN_REPORT,
    artifact_root: Path | str = PHASE_1334_DEFAULT_ARTIFACT_ROOT,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    manifest = build_release_artifact_production_gate(
        repo_root=root,
        artifact_root=artifact_root,
    )
    _write_text_atomic(root / json_out, pretty_json(manifest))
    _write_text_atomic(root / markdown_out, render_markdown_report(manifest))
    return manifest


def _validate_phase_1333_dependency(
    *,
    repo_root: Path,
    manifest_path: Path,
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    active = _require_mapping(manifest, "phase_1334_phase_1333_manifest")
    materialized = _require_mapping(
        active.get("export_materialization"), "phase_1334_phase_1333_materialization"
    )
    candidate = _require_mapping(
        active.get("candidate_scan"), "phase_1334_phase_1333_candidate_scan"
    )
    marker_scan = _require_mapping(
        candidate.get("marker_scan"), "phase_1334_phase_1333_marker_scan"
    )
    dependency_scan = _require_mapping(
        candidate.get("dependency_scan"), "phase_1334_phase_1333_dependency_scan"
    )
    legacy_review = _require_mapping(
        candidate.get("legacy_untagged_review"), "phase_1334_phase_1333_legacy_review"
    )
    dirty_policy = _require_mapping(
        active.get("dirty_worktree_policy"), "phase_1334_phase_1333_dirty_policy"
    )
    tree_path = Path(_require_text(materialized.get("tree_path"), "phase_1333_tree_path"))
    if not tree_path.is_absolute():
        tree_path = repo_root / tree_path
    tree_path = tree_path.resolve()
    if not tree_path.exists() or not tree_path.is_dir():
        raise ValueError("phase_1334_phase_1333_tree_missing")
    file_hashes = _require_sequence(
        materialized.get("file_hashes"), "phase_1334_phase_1333_file_hashes"
    )
    recomputed_file_hashes = _hash_tree_files(tree_path)
    recomputed_tree_hash = _tree_hash(recomputed_file_hashes)
    recorded_tree_hash = _require_sha256_hex(
        materialized.get("tree_sha256"), "phase_1334_phase_1333_tree_sha256"
    )
    if recomputed_tree_hash != recorded_tree_hash:
        raise ValueError("phase_1334_phase_1333_tree_hash_drift")
    if _tree_hash(_coerce_file_hashes(file_hashes)) != recorded_tree_hash:
        raise ValueError("phase_1334_phase_1333_recorded_file_hashes_invalid")

    dependency_result = "pass"
    blockers: list[str] = []
    checks = {
        "phase_1333_result": active.get("result") == "executed_clean_export",
        "phase_1333_verdict": active.get("source_allowlist_export_execution_gate_verdict")
        == "source_allowlist_export_execution_gate_verdict=pass",
        "clean_materialized_public_tree_produced": active.get(
            "clean_materialized_public_tree_produced"
        )
        is True,
        "materialized_flag": materialized.get("materialized") is True,
        "marker_hits_zero": marker_scan.get("hit_count") == 0,
        "stripped_helper_import_hits_zero": dependency_scan.get(
            "stripped_helper_hit_count"
        )
        == 0,
        "legacy_ambiguities_zero": legacy_review.get("ambiguity_count") == 0,
        "dirty_included_files_zero": len(
            _require_sequence(
                dirty_policy.get("dirty_included_files"),
                "phase_1334_phase_1333_dirty_included_files",
            )
        )
        == 0,
        "manifest_hash_present": _is_sha256_hex(active.get("manifest_hash")),
    }
    for check_id, passed in checks.items():
        if not passed:
            dependency_result = "block"
            blockers.append(check_id)

    return {
        "dependency_result": dependency_result,
        "blockers": blockers,
        "dirty_included_files": len(dirty_policy.get("dirty_included_files", ())),
        "exported_file_count": int(materialized.get("exported_file_count", 0)),
        "legacy_untagged_ambiguities": int(legacy_review.get("ambiguity_count", -1)),
        "manifest_hash": active.get("manifest_hash"),
        "manifest_path": _relative_or_absolute(repo_root, manifest_path),
        "phase_1333_result": active.get("result"),
        "phase_1333_verdict": active.get("source_allowlist_export_execution_gate_verdict"),
        "public_rc_exclude_marker_hits": int(marker_scan.get("hit_count", -1)),
        "recomputed_tree_sha256": recomputed_tree_hash,
        "stripped_helper_import_hits": int(
            dependency_scan.get("stripped_helper_hit_count", -1)
        ),
        "tree_path": tree_path.as_posix(),
        "tree_sha256": recorded_tree_hash,
    }


def _produce_source_release_tarball(
    *,
    repo_root: Path,
    tree_path: Path,
    artifact_root: Path,
) -> dict[str, Any]:
    artifact_root.mkdir(parents=True, exist_ok=True)
    target = artifact_root / SOURCE_TARBALL_NAME
    tmp_fd, tmp_name = tempfile.mkstemp(
        dir=artifact_root, prefix=f".{SOURCE_TARBALL_NAME}.", suffix=".tmp"
    )
    os.close(tmp_fd)
    tmp_path = Path(tmp_name)
    try:
        _write_deterministic_tar_gz(tree_path=tree_path, output_path=tmp_path)
        os.replace(tmp_path, target)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise
    digest = _sha256_file(target)
    return {
        "artifact_id": SOURCE_TARBALL_ARTIFACT_ID,
        "artifact_type": "source_release_tarball",
        "byte_size": target.stat().st_size,
        "canonical_hash": f"sha256:{digest}",
        "deterministic_tar_policy": {
            "compression": "gzip_mtime_0_compresslevel_9_no_filename",
            "entry_order": "lexicographic_relative_path",
            "entry_root": SOURCE_TARBALL_ROOT,
            "mtime": 0,
            "owner": "uid_0_gid_0_uname_empty_gname_empty",
            "regular_files_only": True,
        },
        "path": _relative_or_absolute(repo_root, target),
        "signing_status": "unsigned",
    }


def _write_deterministic_tar_gz(*, tree_path: Path, output_path: Path) -> None:
    raw = io.BytesIO()
    with gzip.GzipFile(
        filename="",
        mode="wb",
        compresslevel=9,
        fileobj=raw,
        mtime=0,
    ) as gzip_file:
        with tarfile.open(fileobj=gzip_file, mode="w", format=tarfile.PAX_FORMAT) as tar:
            for source in _iter_tree_files(tree_path):
                rel = source.relative_to(tree_path).as_posix()
                data = source.read_bytes()
                info = tarfile.TarInfo(f"{SOURCE_TARBALL_ROOT}/{rel}")
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                info.uid = 0
                info.gid = 0
                info.uname = ""
                info.gname = ""
                info.pax_headers = {}
                tar.addfile(info, io.BytesIO(data))
    output_path.write_bytes(raw.getvalue())


def _source_tarball_artifact_manifest(artifact: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "artifact_id": SOURCE_TARBALL_ARTIFACT_ID,
        "artifact_type": "source_release_tarball",
        "canonical_hash": artifact["canonical_hash"],
        "lineage_reference": "genesis:v0.1",
        "produced_phase": 1334,
        "ratification_token": RELEASE_ARTIFACT_PRODUCTION_GATE_VERSION,
        "signing_status": "unsigned",
    }


def _gate_preconditions(source_export: Mapping[str, Any]) -> list[dict[str, Any]]:
    checks = (
        (
            "clean_source_export_dependency_passed",
            source_export.get("dependency_result") == "pass",
            f"dependency_result={source_export.get('dependency_result')}",
        ),
        (
            "phase_1333_gate_passed",
            source_export.get("phase_1333_result") == "executed_clean_export",
            f"phase_1333_result={source_export.get('phase_1333_result')}",
        ),
        (
            "phase_1333_binary_verdict_passed",
            source_export.get("phase_1333_verdict")
            == "source_allowlist_export_execution_gate_verdict=pass",
            f"phase_1333_verdict={source_export.get('phase_1333_verdict')}",
        ),
        (
            "public_rc_exclude_marker_scan_zero",
            source_export.get("public_rc_exclude_marker_hits") == 0,
            f"marker_hits={source_export.get('public_rc_exclude_marker_hits')}",
        ),
        (
            "stripped_helper_import_scan_zero",
            source_export.get("stripped_helper_import_hits") == 0,
            f"stripped_helper_import_hits={source_export.get('stripped_helper_import_hits')}",
        ),
        (
            "legacy_untagged_review_clear",
            source_export.get("legacy_untagged_ambiguities") == 0,
            f"legacy_ambiguities={source_export.get('legacy_untagged_ambiguities')}",
        ),
        (
            "dirty_included_files_absent",
            source_export.get("dirty_included_files") == 0,
            f"dirty_included_files={source_export.get('dirty_included_files')}",
        ),
        (
            "tree_hash_recomputed",
            source_export.get("tree_sha256") == source_export.get("recomputed_tree_sha256"),
            f"tree_hash={source_export.get('tree_sha256')}",
        ),
    )
    return [
        {
            "check_id": check_id,
            "evidence": evidence,
            "passed": passed,
            "status": "pass" if passed else "block",
        }
        for check_id, passed, evidence in checks
    ]


def _phase_1213_validation_record(
    artifact_manifests: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    for artifact_manifest in artifact_manifests:
        validate_phase_1213_artifact_manifest(artifact_manifest)
    return {
        "artifact_manifest_count": len(artifact_manifests),
        "required_fields": sorted(_PHASE_1213_REQUIRED_FIELDS),
        "result": "pass",
        "schema_path": PHASE_1213_SCHEMA_PATH.as_posix(),
        "token": RELEASE_ARTIFACT_MANIFEST_VALIDATED_TOKEN,
    }


def _unsigned_artifact_policy(
    artifact_manifests: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    return {
        "all_artifacts_unsigned": all(
            item.get("signing_status") == "unsigned" for item in artifact_manifests
        ),
        "keys_generated": False,
        "release_envelopes_produced": False,
        "result": "pass",
        "signatures_produced": False,
        "token": RELEASE_ARTIFACTS_UNSIGNED_BY_DEFAULT_TOKEN,
    }


def _atlas_g_status() -> dict[str, Any]:
    return {
        "atlas_g_007_unsigned_candidate_regeneration_closed": False,
        "atlas_g_008_non_excisability_review_closed": False,
        "atlas_g_009_signing_root_envelope_prep_closed": False,
        "atlas_g_010_v0_2_signing_ceremony_closed": False,
        "signed_genesis_atlas_v0_2_claimed": False,
        "status": "no_signed_v0_2_or_atlas_linked_release_claim_phase_1334",
    }


def _non_authorization_floor(result: str) -> dict[str, bool]:
    return {
        "cdl_088_opening_authorized": False,
        "cdl_mutation_authorized": False,
        "genesis_atlas_mutation_or_signing_authorized": False,
        "identity_artifact_creation_authorized": False,
        "identity_bootstrap_authorized": False,
        "public_claimability_api_authorized": False,
        "public_confidential_coordination_serving_authorized": False,
        "public_p2p_fetch_sidecar_serving_authorized": False,
        "public_package_publication_authorized": False,
        "public_rc_publication_claim_authorized": False,
        "public_repository_publication_authorized": False,
        "release_artifact_production_authorized_by_go_phase_1334": (
            result == "artifacts_produced_unsigned"
        ),
        "release_envelope_production_authorized": False,
        "release_key_generation_authorized": False,
        "release_signing_material_generation_authorized": False,
        "signing_authorized": False,
        "source_publication_authorized": False,
        "v0_2_signing_authorized": False,
        "wallet_ecu_ilc_activation_authorized": False,
    }


def _non_claims(result: str) -> list[str]:
    return [
        "release_artifact_production_authorized_by_go_phase_1334"
        if result == "artifacts_produced_unsigned"
        else "no_release_artifact_production",
        "no_source_publication",
        "no_public_repository_publication",
        "no_public_package_publication",
        "no_release_key_generation",
        "no_release_envelope_production",
        "no_release_signing_material_generation",
        "no_signing",
        "no_v0_2_signing",
        "no_public_rc_publication_or_claim",
        "no_public_claimability_api_activation",
        "no_public_p2p_fetch_sidecar_serving_activation",
        "no_public_confidential_coordination_serving",
        "no_identity_bootstrap",
        "no_identity_artifacts",
        "no_wallet_ecu_ilc_activation",
        "no_genesis_atlas_mutation_or_signing",
        "no_cdl_mutation_or_cdl_088_opening",
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1334_TOKEN,
    ]


def _binary_verdict(result: str) -> str:
    if result == "artifacts_produced_unsigned":
        return "release_artifact_production_gate_verdict=pass"
    if result == "blocked_with_findings":
        return "release_artifact_production_gate_verdict=block"
    return "release_artifact_production_gate_verdict=deferred"


def _hash_tree_files(tree_path: Path) -> list[dict[str, Any]]:
    return [
        {
            "byte_size": source.stat().st_size,
            "hash_sha256": _sha256_file(source),
            "path": source.relative_to(tree_path).as_posix(),
        }
        for source in _iter_tree_files(tree_path)
    ]


def _coerce_file_hashes(records: Sequence[Any]) -> list[dict[str, Any]]:
    coerced: list[dict[str, Any]] = []
    for record in records:
        item = _require_mapping(record, "phase_1334_recorded_file_hash")
        coerced.append(
            {
                "byte_size": int(item["byte_size"]),
                "hash_sha256": _require_sha256_hex(
                    item["hash_sha256"], "phase_1334_recorded_file_hash_sha256"
                ),
                "path": _normalize_relative_path(item["path"]),
            }
        )
    return coerced


def _tree_hash(file_hashes: Sequence[Mapping[str, Any]]) -> str:
    payload = "\n".join(
        f"{record['path']}\t{record['hash_sha256']}\t{record['byte_size']}"
        for record in sorted(file_hashes, key=lambda item: item["path"])
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _iter_tree_files(tree_path: Path) -> list[Path]:
    files: list[Path] = []
    for path in sorted(tree_path.rglob("*"), key=lambda item: item.relative_to(tree_path).as_posix()):
        if path.is_symlink():
            raise ValueError("phase_1334_source_tree_symlink_forbidden")
        if path.is_file():
            _normalize_relative_path(path.relative_to(tree_path).as_posix())
            files.append(path)
    return files


def _normalize_relative_path(value: object) -> str:
    text = _require_text(value, "relative_path")
    pure = PurePosixPath(text)
    if pure.is_absolute() or ".." in pure.parts or "." in pure.parts or not pure.parts:
        raise ValueError("phase_1334_relative_path_invalid")
    if "\\" in text:
        raise ValueError("phase_1334_relative_path_invalid")
    return pure.as_posix()


def _resolve_under_repo(repo_root: Path, path: Path) -> Path:
    candidate = path if path.is_absolute() else repo_root / path
    return candidate.resolve(strict=False)


def _relative_or_absolute(repo_root: Path, path: Path) -> str:
    resolved = path.resolve(strict=False)
    try:
        return resolved.relative_to(repo_root).as_posix()
    except ValueError:
        return resolved.as_posix()


def _manifest_hash_without_self_reference(manifest: Mapping[str, Any]) -> str:
    clone = json.loads(canonical_json(manifest))
    clone["manifest_hash"] = "0" * 64
    return hashlib.sha256(canonical_json(clone).encode("utf-8")).hexdigest()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text())


def _write_text_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(tmp_path, path)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise


def _require_mapping(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label}_invalid")
    return value


def _require_sequence(value: object, label: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValueError(f"{label}_invalid")
    return value


def _require_text(value: object, label: str) -> str:
    if not _is_text(value):
        raise ValueError(f"{label}_invalid")
    return value


def _is_text(value: object) -> bool:
    return (
        isinstance(value, str)
        and value == value.strip()
        and value != ""
        and len(value) <= 4096
        and not any(ord(char) < 0x20 or char == "\x7f" for char in value)
    )


def _is_sha256_hex(value: object) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _require_sha256_hex(value: object, label: str) -> str:
    if not _is_sha256_hex(value):
        raise ValueError(f"{label}_invalid")
    return value


def _reject_unsafe_json_tree(value: object, *, depth: int = 0, seen: set[int] | None = None) -> None:
    if seen is None:
        seen = set()
    if depth > 64:
        raise ValueError("phase_1334_json_depth_exceeded")
    marker = id(value)
    if isinstance(value, (Mapping, list, tuple)):
        if marker in seen:
            raise ValueError("phase_1334_json_cycle_detected")
        seen.add(marker)
    if isinstance(value, Mapping):
        for key, item in value.items():
            _require_text(key, "json_key")
            _reject_unsafe_json_tree(item, depth=depth + 1, seen=seen)
    elif isinstance(value, list):
        for item in value:
            _reject_unsafe_json_tree(item, depth=depth + 1, seen=seen)
    elif isinstance(value, tuple):
        raise ValueError("phase_1334_json_tuple_forbidden")
    elif isinstance(value, str):
        _require_text(value, "json_text")
    elif isinstance(value, bool) or value is None:
        pass
    elif isinstance(value, int):
        if abs(value) > 10**12:
            raise ValueError("phase_1334_json_int_bound_exceeded")
    else:
        raise ValueError("phase_1334_json_scalar_invalid")
    if isinstance(value, (Mapping, list, tuple)):
        seen.remove(marker)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--json-out", default=PHASE_1334_DEFAULT_JSON_REPORT.as_posix())
    parser.add_argument(
        "--markdown-out", default=PHASE_1334_DEFAULT_MARKDOWN_REPORT.as_posix()
    )
    parser.add_argument("--artifact-root", default=PHASE_1334_DEFAULT_ARTIFACT_ROOT.as_posix())
    args = parser.parse_args(argv)
    manifest = write_phase_1334_outputs(
        repo_root=args.repo_root,
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        artifact_root=args.artifact_root,
    )
    print(pretty_json(manifest), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "PHASE_1334_DEFAULT_ARTIFACT_ROOT",
    "PHASE_1334_DEFAULT_JSON_REPORT",
    "PHASE_1334_DEFAULT_MARKDOWN_REPORT",
    "RELEASE_ARTIFACT_PRODUCTION_GATE_VERSION",
    "build_release_artifact_production_gate",
    "canonical_json",
    "main",
    "phase_1334_required_tokens",
    "pretty_json",
    "render_markdown_report",
    "validate_phase_1213_artifact_manifest",
    "validate_release_artifact_production_gate",
    "write_phase_1334_outputs",
]
