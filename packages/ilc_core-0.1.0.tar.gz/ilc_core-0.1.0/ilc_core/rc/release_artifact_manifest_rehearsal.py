# PUBLIC_RC_EXCLUDE: internal_release_artifact_manifest_rehearsal_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1320 dry-run release manifest rehearsal; never a public release artifact.
"""Deterministic release artifact manifest rehearsal for Phase 1320.

This module creates rehearsal evidence only. It does not produce release
artifacts, calculate checksums over produced artifacts, create source packages,
generate keys, produce release envelopes, sign anything, or authorize a public RC.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from collections.abc import Mapping, Sequence
from pathlib import Path, PurePosixPath
from typing import Any


RELEASE_ARTIFACT_MANIFEST_REHEARSAL_VERSION = (
    "release_artifact_manifest_instance_rehearsal_phase_1320.v0.1"
)
RELEASE_MANIFEST_SHAPE_REHEARSED_TOKEN = (
    "release_manifest_shape_rehearsed_no_artifacts_phase_1320"
)
RELEASE_ARTIFACT_PRODUCTION_NOT_AUTHORIZED_TOKEN = (
    "release_artifact_production_not_authorized_phase_1320"
)
CLEAN_EXPORT_EVIDENCE_DEPENDENCY_RECORDED_TOKEN = (
    "clean_export_evidence_dependency_recorded_phase_1320"
)
PHASE_1321_NEXT_TOKEN = "phase_1321_release_key_envelope_rehearsal_next"
PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1320_TOKEN = (
    "public_rc_remains_blocked_after_phase_1320"
)

PHASE_1213_SCHEMA_TOKEN = "release_artifact_manifest_schema_committed_phase_1213"
PHASE_1213_DISTRIBUTION_CHECKLIST_TOKEN = (
    "distribution_channel_integrity_checklist_committed_phase_1213"
)
PHASE_1319_SCHEMA_VERSION = (
    "deterministic_source_allowlist_export_rehearsal_phase_1319.v0.1"
)
PHASE_1319_NO_PUBLICATION_TOKEN = "source_export_rehearsal_no_publication_phase_1319"

DEFAULT_RELEASE_SCHEMA_PATH = (
    "docs/specs/ilc_release_artifact_manifest_schema_1213_v0.1.md"
)
DEFAULT_DISTRIBUTION_CHECKLIST_PATH = (
    "docs/specs/ilc_distribution_channel_integrity_checklist_1213_v0.1.md"
)
DEFAULT_PHASE_1319_REPORT_PATH = (
    "docs/specs/ilc_deterministic_source_allowlist_export_rehearsal_1319_v0.1.json"
)

REQUIRED_PHASE_1213_FIELDS = (
    "artifact_id",
    "artifact_type",
    "canonical_hash",
    "lineage_reference",
    "produced_phase",
    "ratification_token",
    "signing_status",
)
ALLOWED_PHASE_1213_ARTIFACT_TYPES = (
    "runtime_module",
    "genesis_bundle",
    "cli_binary",
    "documentation_bundle",
    "source_release_tarball",
    "public_repository_tag",
    "container_image",
    "star_map_release_envelope",
    "operator_bootstrap_bundle",
    "verification_bundle",
)
ARTIFACT_PAYLOAD_CLASSES = (
    "tarball",
    "wheel",
    "release_bundle",
    "container_image",
    "artifact_checksum",
)
REAL_SHA256_RE = re.compile(r"^sha256:[0-9a-f]{64}$")


def phase_1320_required_tokens() -> list[str]:
    return [
        RELEASE_ARTIFACT_MANIFEST_REHEARSAL_VERSION,
        RELEASE_MANIFEST_SHAPE_REHEARSED_TOKEN,
        RELEASE_ARTIFACT_PRODUCTION_NOT_AUTHORIZED_TOKEN,
        CLEAN_EXPORT_EVIDENCE_DEPENDENCY_RECORDED_TOKEN,
        PHASE_1321_NEXT_TOKEN,
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1320_TOKEN,
    ]


def build_release_artifact_manifest_rehearsal(
    *,
    repo_root: Path | str = Path("."),
    release_schema_path: str = DEFAULT_RELEASE_SCHEMA_PATH,
    distribution_checklist_path: str = DEFAULT_DISTRIBUTION_CHECKLIST_PATH,
    phase_1319_report_path: str = DEFAULT_PHASE_1319_REPORT_PATH,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1320_repo_root_invalid")

    schema_rel = _normalize_relative_path(release_schema_path, field="release_schema_path")
    checklist_rel = _normalize_relative_path(
        distribution_checklist_path,
        field="distribution_checklist_path",
    )
    phase_1319_rel = _normalize_relative_path(
        phase_1319_report_path,
        field="phase_1319_report_path",
    )

    schema_text = _read_text_under_root(root, schema_rel)
    checklist_text = _read_text_under_root(root, checklist_rel)
    phase_1319_report = _read_json_under_root(root, phase_1319_rel)

    schema_contract = _phase_1213_schema_contract(schema_text)
    checklist_contract = _distribution_checklist_contract(checklist_text)
    source_input = _phase_1319_source_tree_input(root, phase_1319_rel, phase_1319_report)

    dummy_placeholder = {
        "artifact_id": "DRY_RUN_PLACEHOLDER_NOT_A_REAL_ARTIFACT_ID",
        "artifact_type": "DRY_RUN_PLACEHOLDER_NOT_A_REAL_ARTIFACT_TYPE",
        "canonical_hash": "DRY_RUN_PLACEHOLDER_NO_ARTIFACT_BYTES_NO_SHA256",
        "lineage_reference": "DRY_RUN_PLACEHOLDER_NO_GENESIS_LINEAGE_CLAIM",
        "produced_phase": "DRY_RUN_PLACEHOLDER_NO_PRODUCED_PHASE",
        "ratification_token": "DRY_RUN_PLACEHOLDER_NO_RELEASE_RATIFICATION_TOKEN",
        "signing_status": "DRY_RUN_PLACEHOLDER_NO_SIGNING_STATUS",
    }
    _validate_dummy_placeholder(dummy_placeholder)

    manifest: dict[str, Any] = {
        "artifact_manifest_shape": {
            "allowed_artifact_types": list(ALLOWED_PHASE_1213_ARTIFACT_TYPES),
            "canonical_hash_rule": "real artifacts require sha256:<64 lowercase hex>",
            "dry_run_placeholder_instance": dummy_placeholder,
            "dummy_placeholder_policy": (
                "intentionally_non_conformant_placeholders_prevent_real_artifact_use"
            ),
            "phase_1213_schema_contract": schema_contract,
            "required_semantic_fields": list(REQUIRED_PHASE_1213_FIELDS),
            "signing_status_values": ["signed", "unsigned", "deferred"],
        },
        "blocked_materials": [
            _blocked("source_export_execution", "phase_1319_was_rehearsal_only"),
            _blocked("clean_public_tree_materialization", "not_authorized_phase_1320"),
            _blocked("release_artifact_production", "not_authorized_phase_1320"),
            _blocked("release_artifact_checksums", "no_artifact_bytes_produced"),
            _blocked("release_keys", "phase_1321_rehearsal_next_no_real_keys"),
            _blocked("release_envelopes", "phase_1321_rehearsal_next_no_real_envelopes"),
            _blocked("release_signing", "not_authorized_phase_1320"),
            _blocked("public_repository_publication", "not_authorized_phase_1320"),
            _blocked("public_package_publication", "not_authorized_phase_1320"),
            _blocked("genesis_atlas_mutation_or_signing", "not_authorized_phase_1320"),
            _blocked("v0_2_signing", "not_authorized_phase_1320"),
            _blocked("public_rc_claim", "public_rc_remains_blocked_after_phase_1320"),
        ],
        "distribution_channel_integrity_checklist": checklist_contract,
        "file_hash_references": [
            _file_reference(root, schema_rel, "existing_checked_in_phase_1213_schema"),
            _file_reference(root, checklist_rel, "existing_checked_in_phase_1213_checklist"),
            _file_reference(root, phase_1319_rel, "phase_1319_rehearsal_output"),
        ],
        "hash_algorithm": {
            "artifact_hash_algorithm_for_real_artifacts": "sha256",
            "canonical_json": (
                'json.dumps(..., sort_keys=True, allow_nan=False, separators=(",", ":"))'
            ),
            "machine_content_must_not_include_current_timestamps": True,
            "phase_1320_rehearsal_manifest_hash": "",
        },
        "mode": "dry_run_rehearsal_only",
        "negative_evidence": {
            "artifact_payload_absence_checks": [
                {"payload_class": value, "status": "not_produced_phase_1320"}
                for value in ARTIFACT_PAYLOAD_CLASSES
            ],
            "generated_release_artifact_paths": [],
            "generated_release_checksum_paths": [],
            "no_artifact_payloads_created": True,
            "no_artifact_checksums_created": True,
        },
        "non_claims": [
            "no_public_source_export",
            "no_source_publication",
            "no_package_publication",
            "no_clean_public_tree_materialization",
            "no_release_artifact_production",
            "no_release_artifact_checksums_for_produced_artifacts",
            "no_release_key_generation",
            "no_release_envelope_production",
            "no_signing",
            "no_genesis_atlas_mutation_or_signing",
            "no_v0_2_signing",
            "no_public_rc_claim",
            "no_public_claimability_activation",
            "no_public_p2p_or_fetch_serving",
            "no_public_confidential_coordination_serving",
            "public_rc_remains_blocked_after_phase_1320",
        ],
        "phase": 1320,
        "public_rc_remains_blocked": True,
        "required_tokens": phase_1320_required_tokens(),
        "result": "pass",
        "schema_version": RELEASE_ARTIFACT_MANIFEST_REHEARSAL_VERSION,
        "source_tree_rehearsal_input": source_input,
    }
    manifest["hash_algorithm"]["phase_1320_rehearsal_manifest_hash"] = (
        _manifest_hash_without_self_reference(manifest)
    )
    return _validate_rehearsal_manifest(manifest)


def canonical_release_artifact_manifest_rehearsal_json(
    manifest: Mapping[str, Any],
) -> str:
    return json.dumps(manifest, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_release_artifact_manifest_rehearsal_json(
    manifest: Mapping[str, Any],
) -> str:
    return json.dumps(manifest, allow_nan=False, indent=2, sort_keys=True) + "\n"


def manifest_hash(manifest: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        canonical_release_artifact_manifest_rehearsal_json(manifest).encode("utf-8")
    ).hexdigest()


def render_rehearsal_markdown(manifest: Mapping[str, Any]) -> str:
    source_input = manifest["source_tree_rehearsal_input"]
    return "\n".join(
        [
            "# ILC Release Artifact Manifest Instance Rehearsal 1320 v0.1",
            "",
            "**Status:** DRY-RUN REHEARSAL ONLY, NO ARTIFACTS.",
            "**Phase:** 1320.",
            "",
            "```text",
            *phase_1320_required_tokens(),
            "```",
            "",
            "## Verdict",
            "",
            f"- Result: `{manifest['result']}`.",
            f"- Phase 1319 input result: `{source_input['result']}`.",
            f"- Phase 1319 expected manifest hash: `{source_input['expected_manifest_hash']}`.",
            "- Release artifact payloads created: `0`.",
            "- Release artifact checksums created: `0`.",
            f"- Rehearsal manifest hash: `{manifest['hash_algorithm']['phase_1320_rehearsal_manifest_hash']}`.",
            "",
            "## Boundary",
            "",
            "This is a rehearsal envelope around the Phase 1213 manifest schema, not a real Phase 1213 artifact manifest.",
            "Dummy placeholders are intentionally non-conformant and cannot be used as real artifact digests, IDs, lineage references, signing status, or produced phase claims.",
            "Phase 1319 evidence is referenced as dry-run input only; no clean public tree is materialized.",
            "",
            "## Non-Claims",
            "",
            "No release artifact, tarball, wheel, release bundle, container image, produced-artifact checksum, release key, envelope, signature, source export, publication, or public RC claim is produced or authorized.",
            "Public RC remains blocked after Phase 1320.",
            "",
        ]
    )


def write_rehearsal_outputs(
    *,
    json_out: Path | None,
    markdown_out: Path | None,
    manifest: Mapping[str, Any],
) -> None:
    if json_out is not None:
        _write_text_atomic(json_out, pretty_release_artifact_manifest_rehearsal_json(manifest))
    if markdown_out is not None:
        _write_text_atomic(markdown_out, render_rehearsal_markdown(manifest))


def _phase_1213_schema_contract(schema_text: str) -> dict[str, Any]:
    if PHASE_1213_SCHEMA_TOKEN not in schema_text:
        raise ValueError("phase_1320_phase_1213_schema_token_missing")
    schema = _extract_first_json_block(schema_text)
    if schema.get("additionalProperties") is not False:
        raise ValueError("phase_1320_phase_1213_schema_additional_properties_invalid")
    if tuple(schema.get("required", ())) != REQUIRED_PHASE_1213_FIELDS:
        raise ValueError("phase_1320_phase_1213_schema_required_fields_invalid")
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        raise ValueError("phase_1320_phase_1213_schema_properties_invalid")
    artifact_type = properties.get("artifact_type", {})
    if tuple(artifact_type.get("enum", ())) != ALLOWED_PHASE_1213_ARTIFACT_TYPES:
        raise ValueError("phase_1320_phase_1213_schema_artifact_types_invalid")
    canonical_hash = properties.get("canonical_hash", {})
    if canonical_hash.get("pattern") != "^sha256:[0-9a-f]{64}$":
        raise ValueError("phase_1320_phase_1213_schema_hash_pattern_invalid")
    signing_status = properties.get("signing_status", {})
    if tuple(signing_status.get("enum", ())) != ("signed", "unsigned", "deferred"):
        raise ValueError("phase_1320_phase_1213_schema_signing_status_invalid")
    return {
        "additional_properties": False,
        "artifact_types_exhaustive": True,
        "canonical_hash_pattern": canonical_hash["pattern"],
        "required_fields": list(REQUIRED_PHASE_1213_FIELDS),
        "schema_token": PHASE_1213_SCHEMA_TOKEN,
        "schema_validated_against_phase_1320_expectations": True,
    }


def _distribution_checklist_contract(checklist_text: str) -> dict[str, Any]:
    if PHASE_1213_DISTRIBUTION_CHECKLIST_TOKEN not in checklist_text:
        raise ValueError("phase_1320_phase_1213_distribution_checklist_token_missing")
    required_items = [
        "Signing verification",
        "Lineage chain verification",
        "ADR-0036 compliance",
        "ADR-0037 compliance",
        "CDL-086 ratification check",
        "Counsel disposition check",
        "No public-launch implication",
        "Manifest schema conformance",
        "Preview-label non-bypass",
    ]
    missing = [item for item in required_items if item not in checklist_text]
    if missing:
        raise ValueError("phase_1320_distribution_checklist_required_item_missing")
    return {
        "checklist_token": PHASE_1213_DISTRIBUTION_CHECKLIST_TOKEN,
        "distribution_attempted": False,
        "required_items_present": required_items,
        "verdict": "not_run_no_distribution_phase_1320",
    }


def _phase_1319_source_tree_input(
    repo_root: Path,
    phase_1319_rel_path: str,
    report: Mapping[str, Any],
) -> dict[str, Any]:
    if report.get("schema_version") != PHASE_1319_SCHEMA_VERSION:
        raise ValueError("phase_1320_phase_1319_schema_version_invalid")
    if report.get("result") != "pass":
        raise ValueError("phase_1320_phase_1319_rehearsal_must_pass")
    if report.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1320_phase_1319_public_rc_blocked_required")
    if PHASE_1319_NO_PUBLICATION_TOKEN not in report.get("required_tokens", ()):
        raise ValueError("phase_1320_phase_1319_no_publication_token_missing")
    counts = report.get("counts")
    if not isinstance(counts, dict):
        raise ValueError("phase_1320_phase_1319_counts_missing")
    for key in ("marker_hits", "dependency_hits", "blocked_ambiguities"):
        if counts.get(key) != 0:
            raise ValueError("phase_1320_phase_1319_clean_export_rehearsal_failed")
    return {
        "clean_export_evidence_dependency": "phase_1319_rehearsal_only_not_export",
        "counts": {
            "blocked_ambiguities": counts["blocked_ambiguities"],
            "dependency_hits": counts["dependency_hits"],
            "included_files": counts["included_files"],
            "marker_hits": counts["marker_hits"],
        },
        "expected_manifest_hash": report["rerun"]["expected_manifest_hash"],
        "path": phase_1319_rel_path,
        "result": report["result"],
        "schema_version": report["schema_version"],
        "source_tree_status": "dry_run_only_no_clean_public_tree_materialized",
    }


def _validate_dummy_placeholder(dummy_placeholder: Mapping[str, str]) -> None:
    if REAL_SHA256_RE.match(dummy_placeholder["canonical_hash"]):
        raise ValueError("phase_1320_dummy_placeholder_must_not_be_real_digest")
    if not all(str(value).startswith("DRY_RUN_PLACEHOLDER_") for value in dummy_placeholder.values()):
        raise ValueError("phase_1320_dummy_placeholder_prefix_required")


def _validate_rehearsal_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    if manifest.get("schema_version") != RELEASE_ARTIFACT_MANIFEST_REHEARSAL_VERSION:
        raise ValueError("phase_1320_schema_version_invalid")
    if manifest.get("required_tokens") != phase_1320_required_tokens():
        raise ValueError("phase_1320_required_tokens_invalid")
    if manifest.get("mode") != "dry_run_rehearsal_only":
        raise ValueError("phase_1320_mode_invalid")
    if manifest.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1320_public_rc_blocked_required")
    negative = manifest["negative_evidence"]
    if negative["generated_release_artifact_paths"] or negative["generated_release_checksum_paths"]:
        raise ValueError("phase_1320_no_generated_release_artifact_paths_required")
    if negative["no_artifact_payloads_created"] is not True:
        raise ValueError("phase_1320_no_artifact_payloads_flag_required")
    if negative["no_artifact_checksums_created"] is not True:
        raise ValueError("phase_1320_no_artifact_checksums_flag_required")
    if (
        manifest["hash_algorithm"]["phase_1320_rehearsal_manifest_hash"]
        != _manifest_hash_without_self_reference(manifest)
    ):
        raise ValueError("phase_1320_manifest_hash_mismatch")
    canonical_release_artifact_manifest_rehearsal_json(manifest)
    return manifest


def _blocked(material: str, reason: str) -> dict[str, str]:
    return {"material": material, "reason": reason, "status": "blocked"}


def _file_reference(repo_root: Path, rel_path: str, source: str) -> dict[str, str]:
    payload = _read_bytes_under_root(repo_root, rel_path)
    return {
        "hash_classification": "existing_rehearsal_input_not_produced_artifact_checksum",
        "path": rel_path,
        "sha256": hashlib.sha256(payload).hexdigest(),
        "source": source,
    }


def _extract_first_json_block(text: str) -> dict[str, Any]:
    marker = "```json"
    if marker not in text:
        raise ValueError("phase_1320_json_schema_block_missing")
    raw = text.split(marker, maxsplit=1)[1].split("```", maxsplit=1)[0]
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ValueError("phase_1320_json_schema_block_invalid")
    return parsed


def _normalize_relative_path(raw: str, *, field: str) -> str:
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError(f"phase_1320_{field}_invalid")
    if "\\" in raw or raw.startswith("/") or raw.startswith("~"):
        raise ValueError(f"phase_1320_{field}_not_repo_relative")
    path = PurePosixPath(raw)
    if path.is_absolute() or str(path) in {"", "."}:
        raise ValueError(f"phase_1320_{field}_not_repo_relative")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"phase_1320_{field}_traversal_rejected")
    return path.as_posix()


def _resolve_under_root(repo_root: Path, rel_path: str) -> Path:
    candidate = (repo_root / Path(*PurePosixPath(rel_path).parts)).resolve(strict=False)
    if candidate != repo_root and repo_root not in candidate.parents:
        raise ValueError("phase_1320_path_escape_rejected")
    return candidate


def _read_bytes_under_root(repo_root: Path, rel_path: str) -> bytes:
    path = _resolve_under_root(repo_root, rel_path)
    if not path.is_file():
        raise ValueError("phase_1320_input_file_missing")
    return path.read_bytes()


def _read_text_under_root(repo_root: Path, rel_path: str) -> str:
    return _read_bytes_under_root(repo_root, rel_path).decode("utf-8")


def _read_json_under_root(repo_root: Path, rel_path: str) -> dict[str, Any]:
    parsed = json.loads(_read_text_under_root(repo_root, rel_path))
    if not isinstance(parsed, dict):
        raise ValueError("phase_1320_json_input_invalid")
    return parsed


def _manifest_hash_without_self_reference(manifest: Mapping[str, Any]) -> str:
    clone = json.loads(canonical_release_artifact_manifest_rehearsal_json(manifest))
    clone["hash_algorithm"]["phase_1320_rehearsal_manifest_hash"] = ""
    return manifest_hash(clone)


def _write_text_atomic(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        text=True,
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        os.replace(tmp_path, path)
    except Exception:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path("."))
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--markdown-out", type=Path)
    args = parser.parse_args(argv)

    manifest = build_release_artifact_manifest_rehearsal(repo_root=args.repo_root)
    write_rehearsal_outputs(
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        manifest=manifest,
    )
    if args.json_out is None and args.markdown_out is None:
        print(pretty_release_artifact_manifest_rehearsal_json(manifest), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "CLEAN_EXPORT_EVIDENCE_DEPENDENCY_RECORDED_TOKEN",
    "PHASE_1321_NEXT_TOKEN",
    "PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1320_TOKEN",
    "RELEASE_ARTIFACT_MANIFEST_REHEARSAL_VERSION",
    "RELEASE_ARTIFACT_PRODUCTION_NOT_AUTHORIZED_TOKEN",
    "RELEASE_MANIFEST_SHAPE_REHEARSED_TOKEN",
    "build_release_artifact_manifest_rehearsal",
    "canonical_release_artifact_manifest_rehearsal_json",
    "manifest_hash",
    "phase_1320_required_tokens",
    "pretty_release_artifact_manifest_rehearsal_json",
    "render_rehearsal_markdown",
    "write_rehearsal_outputs",
]
