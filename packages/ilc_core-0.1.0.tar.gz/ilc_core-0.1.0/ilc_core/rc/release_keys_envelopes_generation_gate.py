# PUBLIC_RC_EXCLUDE: internal_release_keys_envelopes_generation_gate_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1335 local release key/envelope gate tooling; not part of the public RC tree.
"""Phase 1335 release key/envelope generation gate.

This module generates an operator-local release key and unsigned release
envelope metadata only after explicit Phase 1335 authority and a passing Phase
1334 unsigned artifact report. It never signs release artifacts, never writes
secret material to the repository, and never prints private key material.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import ed25519


RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION = (
    "release_keys_envelopes_generation_gate_phase_1335.v0.1"
)
RELEASE_KEY_GENERATION_REQUIRES_AUTHORITY_TOKEN = (
    "release_key_generation_requires_explicit_authority_phase_1335"
)
RELEASE_ENVELOPE_GENERATION_REQUIRES_AUTHORITY_TOKEN = (
    "release_envelope_generation_requires_explicit_authority_phase_1335"
)
SECRET_MATERIAL_NOT_WRITTEN_TO_REPO_TOKEN = (
    "secret_material_not_written_to_repo_phase_1335"
)
PHASE_1336_PUBLIC_CLAIMABILITY_API_GATE_NEXT_TOKEN = (
    "phase_1336_public_claimability_api_gate_next"
)
PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1335_TOKEN = (
    "public_rc_remains_blocked_after_phase_1335"
)

EXPLICIT_AUTHORITY_PHRASE = "GO Phase 1335: authorize release key/envelope generation"
PHASE_1334_REPORT_PATH = Path(
    "docs/specs/ilc_release_artifact_production_gate_1334_v0.1.json"
)
PHASE_1335_DEFAULT_JSON_REPORT = Path(
    "docs/specs/ilc_release_keys_envelopes_generation_gate_1335_v0.1.json"
)
PHASE_1335_DEFAULT_MARKDOWN_REPORT = Path(
    "docs/specs/ilc_release_keys_envelopes_generation_gate_1335_v0.1.md"
)
DEFAULT_EXTERNAL_KEY_PATH = (
    Path.home()
    / ".ilc/private/release_keys/phase_1335/ilc-release-key-phase-1335.ed25519.pem"
)
ADR_0036_PATH = Path("docs/adr/ADR_0036_Operational_Release_Key_Genesis_Binding.md")
ADR_0037_PATH = Path("docs/adr/ADR_0037_Genesis_Canonical_Lineage_Contract.md")

GENESIS_ROOT_ENVELOPE_HASH = (
    "sha256:ddc686019018e05f3d88be1a879663c7c2756823bf8bc7fbf980743a92fc6c3c"
)
RELEASE_KEY_ID = "ilc-release-key-phase-1335-rc-candidate"
RELEASE_ENVELOPE_ID = "ilc-release-envelope-phase-1335-unsigned-candidate"
RELEASE_KEY_SCOPE = [
    "source_release_tarball",
    "release_envelope",
    "verification_bundle",
]

_ALLOWED_RESULTS = frozenset(
    {"keys_envelopes_generated", "blocked_no_authority", "blocked_with_findings"}
)
_SHA256_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
_HEX_64_RE = re.compile(r"^[0-9a-f]{64}$")
_MAX_JSON_DEPTH = 64
_MAX_TEXT_LENGTH = 4096
_MAX_INT_ABS = 10**12


def phase_1335_required_tokens() -> list[str]:
    return [
        RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION,
        RELEASE_KEY_GENERATION_REQUIRES_AUTHORITY_TOKEN,
        RELEASE_ENVELOPE_GENERATION_REQUIRES_AUTHORITY_TOKEN,
        SECRET_MATERIAL_NOT_WRITTEN_TO_REPO_TOKEN,
        PHASE_1336_PUBLIC_CLAIMABILITY_API_GATE_NEXT_TOKEN,
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1335_TOKEN,
    ]


def build_release_keys_envelopes_generation_gate(
    *,
    authority_token: str | None,
    repo_root: Path | str = Path("."),
    phase_1334_report_path: Path | str = PHASE_1334_REPORT_PATH,
    external_key_path: Path | str = DEFAULT_EXTERNAL_KEY_PATH,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1335_repo_root_invalid")

    authority = _authority_record(authority_token)
    phase_1334_dependency = _phase_1334_dependency_record(
        repo_root=root,
        report_path=root / Path(phase_1334_report_path),
    )
    canon = _canon_records(root)
    blockers = list(phase_1334_dependency["blockers"]) + list(canon["blockers"])
    if not authority["explicit_authority_present"]:
        result = "blocked_no_authority"
        blockers.append("missing_explicit_phase_1335_authority")
    elif blockers:
        result = "blocked_with_findings"
    else:
        result = "keys_envelopes_generated"

    release_key_registration: dict[str, Any] | None = None
    release_envelope_candidate: dict[str, Any] | None = None
    public_key_metadata: dict[str, Any] | None = None
    if result == "keys_envelopes_generated":
        key_path = _resolve_external_key_path(root, Path(external_key_path))
        private_key = _load_or_generate_ed25519_key(key_path)
        public_key_metadata = _public_key_metadata(private_key)
        release_key_registration = _release_key_registration(public_key_metadata)
        release_envelope_candidate = _release_envelope_candidate(
            phase_1334_dependency=phase_1334_dependency,
            release_key_registration=release_key_registration,
        )

    manifest: dict[str, Any] = {
        "authority": authority,
        "blockers": blockers,
        "canon_dependency": canon,
        "graph_delta": _graph_delta(result),
        "manifest_hash": "0" * 64,
        "mode": "release_keys_envelopes_generation_gate",
        "next_phase": _next_phase(result),
        "non_authorization_floor": _non_authorization_floor(result),
        "non_claims": _non_claims(result),
        "phase": 1335,
        "phase_1334_dependency": phase_1334_dependency,
        "public_key_metadata": public_key_metadata,
        "public_rc_remains_blocked": True,
        "release_envelope_candidate": release_envelope_candidate,
        "release_key_registration": release_key_registration,
        "release_keys_envelopes_generation_gate_verdict": _binary_verdict(result),
        "required_tokens": phase_1335_required_tokens(),
        "result": result,
        "schema_version": RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION,
        "secret_material_boundary": _secret_material_boundary(result),
    }
    manifest["manifest_hash"] = _manifest_hash_without_self_reference(manifest)
    return validate_release_keys_envelopes_generation_gate(manifest)


def validate_release_keys_envelopes_generation_gate(
    manifest: Mapping[str, Any],
) -> dict[str, Any]:
    active = dict(manifest)
    if active.get("schema_version") != RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION:
        raise ValueError("phase_1335_schema_version_invalid")
    if active.get("required_tokens") != phase_1335_required_tokens():
        raise ValueError("phase_1335_required_tokens_invalid")
    result = active.get("result")
    if result not in _ALLOWED_RESULTS:
        raise ValueError("phase_1335_result_invalid")
    if active.get("release_keys_envelopes_generation_gate_verdict") != _binary_verdict(
        str(result)
    ):
        raise ValueError("phase_1335_binary_verdict_invalid")
    if active.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1335_public_rc_blocked_flag_required")
    if active.get("manifest_hash") != _manifest_hash_without_self_reference(active):
        raise ValueError("phase_1335_manifest_hash_invalid")

    authority = _require_mapping(active.get("authority"), "phase_1335_authority")
    key_generation_authorized = result == "keys_envelopes_generated"
    if authority.get("explicit_authority_present") is not (
        result != "blocked_no_authority"
    ):
        raise ValueError("phase_1335_authority_result_mismatch")

    secret_boundary = _require_mapping(
        active.get("secret_material_boundary"), "phase_1335_secret_boundary"
    )
    for key in (
        "secret_material_written_to_repo",
        "secret_material_printed_to_stdout",
        "private_material_path_recorded_in_repo",
        "private_material_fingerprint_recorded_in_repo",
    ):
        if secret_boundary.get(key) is not False:
            raise ValueError("phase_1335_secret_boundary_invalid")

    non_auth = _require_mapping(
        active.get("non_authorization_floor"), "phase_1335_non_authorization_floor"
    )
    for key, value in non_auth.items():
        if key in {
            "release_key_generation_authorized_by_go_phase_1335",
            "release_envelope_generation_authorized_by_go_phase_1335",
        }:
            if value is not key_generation_authorized:
                raise ValueError("phase_1335_key_envelope_authority_flag_invalid")
            continue
        if value is not False:
            raise ValueError("phase_1335_non_authorization_floor_invalid")

    if result == "keys_envelopes_generated":
        _validate_public_key_metadata(
            _require_mapping(active.get("public_key_metadata"), "phase_1335_public_key")
        )
        registration = _validate_release_key_registration(
            _require_mapping(
                active.get("release_key_registration"), "phase_1335_key_registration"
            )
        )
        _validate_release_envelope_candidate(
            _require_mapping(
                active.get("release_envelope_candidate"), "phase_1335_release_envelope"
            ),
            registration,
        )
    else:
        if (
            active.get("public_key_metadata") is not None
            or active.get("release_key_registration") is not None
            or active.get("release_envelope_candidate") is not None
        ):
            raise ValueError("phase_1335_blocked_manifest_must_not_include_key_material")

    canonical = canonical_json(active)
    for forbidden in ("BEGIN PRIVATE KEY", "END PRIVATE KEY", ".ilc/private"):
        if forbidden in canonical:
            raise ValueError("phase_1335_secret_material_leak_detected")
    return active


def canonical_json(payload: Mapping[str, Any]) -> str:
    _reject_unsafe_json_tree(payload)
    return json.dumps(payload, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_json(payload: Mapping[str, Any]) -> str:
    _reject_unsafe_json_tree(payload)
    return json.dumps(payload, allow_nan=False, indent=2, sort_keys=True) + "\n"


def render_markdown_report(manifest: Mapping[str, Any]) -> str:
    active = validate_release_keys_envelopes_generation_gate(manifest)
    authority = active["authority"]
    phase_1334 = active["phase_1334_dependency"]
    key_metadata = active["public_key_metadata"] or {}
    registration = active["release_key_registration"] or {}
    envelope = active["release_envelope_candidate"] or {}

    blocker_rows = [
        "| Blocker |",
        "|---------|",
    ]
    for blocker in active["blockers"]:
        blocker_rows.append(f"| `{blocker}` |")
    if len(blocker_rows) == 2:
        blocker_rows.append("| none |")

    return "\n".join(
        [
            "# ILC Release Keys/Envelopes Generation Gate 1335 v0.1",
            "",
            "Status: release key/envelope generation gate executed",
            "Phase: 1335",
            "",
            "```text",
            *active["required_tokens"],
            "```",
            "",
            "## 1. Verdict",
            "",
            f"`{active['release_keys_envelopes_generation_gate_verdict']}`",
            "",
            f"Result: `{active['result']}`.",
            f"Manifest hash: `{active['manifest_hash']}`.",
            f"Public RC remains blocked: `{active['public_rc_remains_blocked']}`.",
            "",
            "## 2. Authority Decision",
            "",
            f"Required phrase matched: `{authority['explicit_authority_present']}`.",
            f"Authority token: `{authority['authority_token']}`.",
            "",
            "## 3. Phase 1334 Dependency",
            "",
            f"Dependency result: `{phase_1334['dependency_result']}`.",
            f"Phase 1334 result: `{phase_1334['phase_1334_result']}`.",
            f"Phase 1334 verdict: `{phase_1334['phase_1334_verdict']}`.",
            f"Source artifact hash: `{phase_1334['source_release_artifact_hash']}`.",
            f"Recomputed artifact hash: `{phase_1334['recomputed_source_release_artifact_hash']}`.",
            "",
            "## 4. Public Key Registration Metadata",
            "",
            f"Release key id: `{key_metadata.get('release_key_id', 'none')}`.",
            f"Algorithm: `{key_metadata.get('algorithm_id', 'none')}`.",
            f"Public key fingerprint: `{key_metadata.get('public_key_fingerprint', 'none')}`.",
            f"Registration hash: `{registration.get('registration_hash', 'none')}`.",
            "Only public identifiers, public key bytes, public key fingerprint, and",
            "unsigned registration metadata are stored in the repository.",
            "",
            "## 5. Unsigned Release Envelope Candidate",
            "",
            f"Envelope id: `{envelope.get('release_envelope_id', 'none')}`.",
            f"Envelope hash: `{envelope.get('envelope_hash', 'none')}`.",
            f"Signing status: `{envelope.get('signing_status', 'none')}`.",
            f"Signature produced: `{envelope.get('signature_produced', False)}`.",
            "",
            "## 6. Blockers",
            "",
            *blocker_rows,
            "",
            "## 7. Secret-Handling Boundary",
            "",
            "Secret material is generated or stored only in the operator-local external",
            "keyfile provider boundary. No private key bytes, private key path, private",
            "key fingerprint, seed, mnemonic, KMS secret, HSM credential, or operator",
            "credential value is recorded in this report, STATUS, walkthrough, or git.",
            "",
            "## 8. Non-Authorization Boundary",
            "",
            "Phase 1335 does not authorize release signing, v0.2 signing, public RC",
            "publication/claim, source publication, repository publication, package",
            "publication, public serving, public claimability/API activation, Genesis",
            "mutation/signing, identity artifacts, wallet actions, ECU minting, ILC",
            "settlement, CDL mutation, or CDL-088 opening.",
            "",
            "## 9. Graph Delta",
            "",
            "```text",
            active["graph_delta"],
            "graph_delta=support_only:docs/specs/ilc_release_keys_envelopes_generation_gate_1335_v0.1.json -> release-key-envelope-gate",
            "graph_delta=support_only:docs/specs/ilc_release_keys_envelopes_generation_gate_1335_v0.1.md -> release-key-envelope-gate",
            "```",
            "",
        ]
    )


def write_phase_1335_outputs(
    *,
    authority_token: str | None,
    repo_root: Path | str = Path("."),
    json_out: Path | str = PHASE_1335_DEFAULT_JSON_REPORT,
    markdown_out: Path | str = PHASE_1335_DEFAULT_MARKDOWN_REPORT,
    external_key_path: Path | str = DEFAULT_EXTERNAL_KEY_PATH,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    manifest = build_release_keys_envelopes_generation_gate(
        authority_token=authority_token,
        repo_root=root,
        external_key_path=external_key_path,
    )
    _write_text_atomic(root / Path(json_out), pretty_json(manifest))
    _write_text_atomic(root / Path(markdown_out), render_markdown_report(manifest))
    return manifest


def _authority_record(authority_token: str | None) -> dict[str, Any]:
    explicit = authority_token == EXPLICIT_AUTHORITY_PHRASE
    return {
        "authority_token": (
            "explicit_phase_1335_release_key_envelope_generation_authority"
            if explicit
            else "missing_or_non_matching_phase_1335_authority"
        ),
        "explicit_authority_present": explicit,
        "required_authority_phrase": EXPLICIT_AUTHORITY_PHRASE,
        "release_envelope_generation_requires_explicit_authority": True,
        "release_key_generation_requires_explicit_authority": True,
    }


def _phase_1334_dependency_record(*, repo_root: Path, report_path: Path) -> dict[str, Any]:
    blockers: list[str] = []
    try:
        report = _load_json(report_path)
        artifact = _single_source_release_artifact(report)
        artifact_path = Path(_require_text(artifact.get("path"), "phase_1335_artifact_path"))
        if not artifact_path.is_absolute():
            artifact_path = repo_root / artifact_path
        artifact_path = artifact_path.resolve()
        if not artifact_path.exists() or not artifact_path.is_file():
            blockers.append("phase_1334_source_release_artifact_missing")
            recomputed_hash = None
        else:
            recomputed_hash = f"sha256:{_sha256_file(artifact_path)}"
            if recomputed_hash != artifact.get("canonical_hash"):
                blockers.append("phase_1334_source_release_artifact_hash_drift")

        checks = {
            "phase_1334_schema_version": report.get("schema_version")
            == "release_artifact_production_gate_phase_1334.v0.1",
            "phase_1334_result": report.get("result") == "artifacts_produced_unsigned",
            "phase_1334_verdict": report.get("release_artifact_production_gate_verdict")
            == "release_artifact_production_gate_verdict=pass",
            "phase_1334_next_phase": report.get("next_phase")
            == "phase_1335_release_keys_envelopes_generation_gate_next",
            "phase_1334_public_rc_blocked": report.get("public_rc_remains_blocked") is True,
            "phase_1334_artifact_unsigned": artifact.get("signing_status") == "unsigned",
        }
        for check_id, passed in checks.items():
            if not passed:
                blockers.append(check_id)
        return {
            "artifact_path_recorded": _relative_or_absolute(repo_root, artifact_path),
            "blockers": blockers,
            "dependency_result": "pass" if not blockers else "block",
            "manifest_hash": report.get("manifest_hash"),
            "phase_1334_result": report.get("result"),
            "phase_1334_verdict": report.get("release_artifact_production_gate_verdict"),
            "recomputed_source_release_artifact_hash": recomputed_hash,
            "report_path": _relative_or_absolute(repo_root, report_path),
            "source_release_artifact_hash": artifact.get("canonical_hash"),
            "source_release_artifact_id": artifact.get("artifact_id"),
            "source_release_artifact_type": artifact.get("artifact_type"),
        }
    except Exception as exc:
        return {
            "artifact_path_recorded": None,
            "blockers": [f"phase_1334_dependency_invalid:{type(exc).__name__}"],
            "dependency_result": "block",
            "manifest_hash": None,
            "phase_1334_result": None,
            "phase_1334_verdict": None,
            "recomputed_source_release_artifact_hash": None,
            "report_path": _relative_or_absolute(repo_root, report_path),
            "source_release_artifact_hash": None,
            "source_release_artifact_id": None,
            "source_release_artifact_type": None,
        }


def _single_source_release_artifact(report: Mapping[str, Any]) -> Mapping[str, Any]:
    artifacts = _require_sequence(report.get("artifacts"), "phase_1335_artifacts")
    if len(artifacts) != 1:
        raise ValueError("phase_1335_expected_one_phase_1334_artifact")
    artifact = _require_mapping(artifacts[0], "phase_1335_artifact")
    if artifact.get("artifact_type") != "source_release_tarball":
        raise ValueError("phase_1335_phase_1334_artifact_type_invalid")
    if not _is_sha256(artifact.get("canonical_hash")):
        raise ValueError("phase_1335_phase_1334_artifact_hash_invalid")
    return artifact


def _canon_records(repo_root: Path) -> dict[str, Any]:
    blockers: list[str] = []
    adr_0036 = repo_root / ADR_0036_PATH
    adr_0037 = repo_root / ADR_0037_PATH
    adr_0036_text = adr_0036.read_text(encoding="utf-8") if adr_0036.exists() else ""
    adr_0037_text = adr_0037.read_text(encoding="utf-8") if adr_0037.exists() else ""
    if "**Status:** Accepted" not in adr_0036_text:
        blockers.append("adr_0036_not_accepted_or_missing")
    if "adr_0036_accepted_phase_1173" not in (
        repo_root / "docs/adr/adr_0036_acceptance_review_1173_v0.1.md"
    ).read_text(encoding="utf-8"):
        blockers.append("adr_0036_acceptance_review_token_missing")
    if "**Status:** Accepted" not in adr_0037_text:
        blockers.append("adr_0037_not_accepted_or_missing")
    if GENESIS_ROOT_ENVELOPE_HASH.removeprefix("sha256:") not in adr_0037_text:
        blockers.append("adr_0037_genesis_root_hash_missing")
    return {
        "adr_0036_path": ADR_0036_PATH.as_posix(),
        "adr_0037_path": ADR_0037_PATH.as_posix(),
        "blockers": blockers,
        "dependency_result": "pass" if not blockers else "block",
        "genesis_root_envelope_hash": GENESIS_ROOT_ENVELOPE_HASH,
    }


def _resolve_external_key_path(repo_root: Path, key_path: Path) -> Path:
    resolved = key_path.expanduser().resolve(strict=False)
    try:
        resolved.relative_to(repo_root)
    except ValueError:
        return resolved
    raise ValueError("phase_1335_secret_material_path_must_be_outside_repo")


def _load_or_generate_ed25519_key(key_path: Path) -> ed25519.Ed25519PrivateKey:
    key_path.parent.mkdir(parents=True, exist_ok=True)
    os.chmod(key_path.parent, 0o700)
    if key_path.exists():
        key = serialization.load_pem_private_key(key_path.read_bytes(), password=None)
        if not isinstance(key, ed25519.Ed25519PrivateKey):
            raise ValueError("phase_1335_existing_key_algorithm_invalid")
        os.chmod(key_path, 0o600)
        return key

    key = ed25519.Ed25519PrivateKey.generate()
    pem = key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    fd, tmp_name = tempfile.mkstemp(
        dir=key_path.parent, prefix=f".{key_path.name}.", suffix=".tmp"
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(pem)
        os.chmod(tmp_path, 0o600)
        os.replace(tmp_path, key_path)
        os.chmod(key_path, 0o600)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise
    return key


def _public_key_metadata(private_key: ed25519.Ed25519PrivateKey) -> dict[str, Any]:
    public_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    public_key_hex = public_bytes.hex()
    fingerprint = f"sha256:{hashlib.sha256(public_bytes).hexdigest()}"
    return {
        "algorithm_id": "Ed25519/COSE-EdDSA(-8)",
        "cose_kid": RELEASE_KEY_ID,
        "cose_kid_policy": "opaque_identifier_not_raw_public_key_or_direct_hash",
        "public_key_fingerprint": fingerprint,
        "public_key_hex": public_key_hex,
        "release_key_id": RELEASE_KEY_ID,
    }


def _release_key_registration(public_key_metadata: Mapping[str, Any]) -> dict[str, Any]:
    registration: dict[str, Any] = {
        "algorithm_id": public_key_metadata["algorithm_id"],
        "binding_status": "pending_future_genesis_root_or_successor_envelope_reference",
        "cose_kid": public_key_metadata["cose_kid"],
        "cose_kid_policy": public_key_metadata["cose_kid_policy"],
        "genesis_root_envelope_hash": GENESIS_ROOT_ENVELOPE_HASH,
        "key_scope": RELEASE_KEY_SCOPE,
        "produced_phase": 1335,
        "public_key_fingerprint": public_key_metadata["public_key_fingerprint"],
        "public_key_hex": public_key_metadata["public_key_hex"],
        "record_kind": "release_key_registration_candidate",
        "registration_hash": "sha256:" + "0" * 64,
        "release_key_id": public_key_metadata["release_key_id"],
        "schema_version": RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION,
        "signature_produced": False,
        "signing_status": "unsigned",
        "validity_window": {
            "activation_phase": 1335,
            "not_after": "deferred_until_future_ceremony_or_supersession",
            "not_before": "phase_1335_generation_gate",
        },
    }
    registration["registration_hash"] = _record_hash_without_key(
        registration, "registration_hash"
    )
    return registration


def _release_envelope_candidate(
    *,
    phase_1334_dependency: Mapping[str, Any],
    release_key_registration: Mapping[str, Any],
) -> dict[str, Any]:
    envelope: dict[str, Any] = {
        "artifact_manifests": [
            {
                "artifact_id": phase_1334_dependency["source_release_artifact_id"],
                "artifact_type": phase_1334_dependency["source_release_artifact_type"],
                "canonical_hash": phase_1334_dependency["source_release_artifact_hash"],
                "produced_phase": 1334,
                "signing_status": "unsigned",
            }
        ],
        "atlas_g_status": {
            "atlas_g_009_signing_root_envelope_prep_closed": False,
            "atlas_g_010_v0_2_signing_ceremony_closed": False,
            "signed_genesis_atlas_v0_2_claimed": False,
        },
        "envelope_hash": "sha256:" + "0" * 64,
        "genesis_root_envelope_hash": GENESIS_ROOT_ENVELOPE_HASH,
        "phase_1334_manifest_hash": phase_1334_dependency["manifest_hash"],
        "prior_release_envelope_hash": None,
        "produced_phase": 1335,
        "record_kind": "release_envelope_candidate",
        "release_envelope_id": RELEASE_ENVELOPE_ID,
        "release_key_id": release_key_registration["release_key_id"],
        "release_key_registration_hash": release_key_registration["registration_hash"],
        "schema_version": RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION,
        "signature_produced": False,
        "signing_status": "unsigned",
    }
    envelope["envelope_hash"] = _record_hash_without_key(envelope, "envelope_hash")
    return envelope


def _validate_public_key_metadata(metadata: Mapping[str, Any]) -> None:
    if metadata.get("release_key_id") != RELEASE_KEY_ID:
        raise ValueError("phase_1335_release_key_id_invalid")
    public_key_hex = metadata.get("public_key_hex")
    if not isinstance(public_key_hex, str) or not _HEX_64_RE.fullmatch(public_key_hex):
        raise ValueError("phase_1335_public_key_hex_invalid")
    fingerprint = f"sha256:{hashlib.sha256(bytes.fromhex(public_key_hex)).hexdigest()}"
    if metadata.get("public_key_fingerprint") != fingerprint:
        raise ValueError("phase_1335_public_key_fingerprint_invalid")
    if metadata.get("cose_kid") in {public_key_hex, fingerprint}:
        raise ValueError("phase_1335_cose_kid_must_be_opaque")


def _validate_release_key_registration(registration: Mapping[str, Any]) -> Mapping[str, Any]:
    if registration.get("record_kind") != "release_key_registration_candidate":
        raise ValueError("phase_1335_registration_kind_invalid")
    if registration.get("signature_produced") is not False:
        raise ValueError("phase_1335_registration_signature_forbidden")
    if registration.get("signing_status") != "unsigned":
        raise ValueError("phase_1335_registration_must_be_unsigned")
    if registration.get("genesis_root_envelope_hash") != GENESIS_ROOT_ENVELOPE_HASH:
        raise ValueError("phase_1335_registration_genesis_hash_invalid")
    if registration.get("registration_hash") != _record_hash_without_key(
        registration, "registration_hash"
    ):
        raise ValueError("phase_1335_registration_hash_invalid")
    return registration


def _validate_release_envelope_candidate(
    envelope: Mapping[str, Any],
    registration: Mapping[str, Any],
) -> None:
    if envelope.get("record_kind") != "release_envelope_candidate":
        raise ValueError("phase_1335_envelope_kind_invalid")
    if envelope.get("signature_produced") is not False:
        raise ValueError("phase_1335_envelope_signature_forbidden")
    if envelope.get("signing_status") != "unsigned":
        raise ValueError("phase_1335_envelope_must_be_unsigned")
    if envelope.get("release_key_registration_hash") != registration.get(
        "registration_hash"
    ):
        raise ValueError("phase_1335_envelope_registration_hash_invalid")
    if envelope.get("envelope_hash") != _record_hash_without_key(
        envelope, "envelope_hash"
    ):
        raise ValueError("phase_1335_envelope_hash_invalid")


def _secret_material_boundary(result: str) -> dict[str, Any]:
    return {
        "external_operator_local_keyfile_used": result == "keys_envelopes_generated",
        "private_material_fingerprint_recorded_in_repo": False,
        "private_material_path_recorded_in_repo": False,
        "secret_material_printed_to_stdout": False,
        "secret_material_storage_scope": "external_operator_local_keyfile_not_repo",
        "secret_material_written_to_repo": False,
        "token": SECRET_MATERIAL_NOT_WRITTEN_TO_REPO_TOKEN,
    }


def _non_authorization_floor(result: str) -> dict[str, bool]:
    key_envelope_generation = result == "keys_envelopes_generated"
    return {
        "cdl_088_opening_authorized": False,
        "cdl_mutation_authorized": False,
        "genesis_atlas_mutation_or_signing_authorized": False,
        "identity_artifact_creation_authorized": False,
        "identity_bootstrap_authorized": False,
        "public_claimability_api_authorized": False,
        "public_confidential_coordination_serving_authorized": False,
        "public_p2p_fetch_sidecar_serving_authorized": False,
        "public_package_publication_authorized": False,
        "public_rc_publication_claim_authorized": False,
        "public_repository_publication_authorized": False,
        "release_envelope_generation_authorized_by_go_phase_1335": (
            key_envelope_generation
        ),
        "release_signing_authorized": False,
        "release_signature_production_authorized": False,
        "release_key_generation_authorized_by_go_phase_1335": key_envelope_generation,
        "source_publication_authorized": False,
        "v0_2_signing_authorized": False,
        "wallet_ecu_ilc_activation_authorized": False,
    }


def _non_claims(result: str) -> list[str]:
    claims = [
        "no_source_publication",
        "no_public_repository_publication",
        "no_public_package_publication",
        "no_release_signing",
        "no_release_signature_production",
        "no_v0_2_signing",
        "no_public_rc_publication_or_claim",
        "no_public_claimability_api_activation",
        "no_public_p2p_fetch_sidecar_serving_activation",
        "no_public_confidential_coordination_serving",
        "no_identity_bootstrap",
        "no_identity_artifacts",
        "no_wallet_ecu_ilc_activation",
        "no_genesis_atlas_mutation_or_signing",
        "no_cdl_mutation_or_cdl_088_opening",
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1335_TOKEN,
    ]
    if result == "keys_envelopes_generated":
        return [
            "release_key_generation_authorized_by_go_phase_1335",
            "release_envelope_generation_authorized_by_go_phase_1335",
            "secret_material_not_written_to_repo_phase_1335",
            *claims,
        ]
    return [
        "no_release_key_generation",
        "no_release_envelope_generation",
        "secret_material_not_written_to_repo_phase_1335",
        *claims,
    ]


def _binary_verdict(result: str) -> str:
    if result == "keys_envelopes_generated":
        return "release_keys_envelopes_generation_gate_verdict=pass"
    if result == "blocked_no_authority":
        return "release_keys_envelopes_generation_gate_verdict=blocked_no_authority"
    return "release_keys_envelopes_generation_gate_verdict=block"


def _next_phase(result: str) -> str:
    if result == "keys_envelopes_generated":
        return PHASE_1336_PUBLIC_CLAIMABILITY_API_GATE_NEXT_TOKEN
    if result == "blocked_no_authority":
        return "phase_1335_explicit_authority_required_before_retry"
    return "phase_1335_fix_required_before_phase_1336"


def _graph_delta(result: str) -> str:
    if result == "keys_envelopes_generated":
        return (
            "graph_delta=load_bearing_artifact_added:"
            "docs/specs/ilc_release_keys_envelopes_generation_gate_1335_v0.1.json "
            "-> release-key-envelope-metadata"
        )
    return "graph_delta=deferred:phase_1335_key_envelope_generation_blocked"


def _manifest_hash_without_self_reference(manifest: Mapping[str, Any]) -> str:
    clone = json.loads(canonical_json(manifest))
    clone["manifest_hash"] = "0" * 64
    return hashlib.sha256(canonical_json(clone).encode("utf-8")).hexdigest()


def _record_hash_without_key(record: Mapping[str, Any], key: str) -> str:
    clone = dict(record)
    clone[key] = "sha256:" + "0" * 64
    return f"sha256:{hashlib.sha256(canonical_json(clone).encode('utf-8')).hexdigest()}"


def _load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_text_atomic(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(text)
        os.replace(tmp_path, path)
    except Exception:
        if tmp_path.exists():
            tmp_path.unlink()
        raise


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _relative_or_absolute(repo_root: Path, path: Path) -> str:
    resolved = path.resolve(strict=False)
    try:
        return resolved.relative_to(repo_root).as_posix()
    except ValueError:
        return resolved.as_posix()


def _is_sha256(value: object) -> bool:
    return isinstance(value, str) and _SHA256_RE.fullmatch(value) is not None


def _require_mapping(value: object, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"{label}_invalid")
    return value


def _require_sequence(value: object, label: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes, bytearray)) or not isinstance(value, Sequence):
        raise ValueError(f"{label}_invalid")
    return value


def _require_text(value: object, label: str) -> str:
    if (
        not isinstance(value, str)
        or value != value.strip()
        or value == ""
        or len(value) > _MAX_TEXT_LENGTH
        or any(ord(char) < 0x20 or char == "\x7f" for char in value)
    ):
        raise ValueError(f"{label}_invalid")
    return value


def _reject_unsafe_json_tree(
    value: object, *, depth: int = 0, seen: set[int] | None = None
) -> None:
    if seen is None:
        seen = set()
    if depth > _MAX_JSON_DEPTH:
        raise ValueError("phase_1335_json_depth_exceeded")
    marker = id(value)
    if isinstance(value, (Mapping, list, tuple)):
        if marker in seen:
            raise ValueError("phase_1335_json_cycle_detected")
        seen.add(marker)
    if isinstance(value, Mapping):
        for key, item in value.items():
            _require_text(key, "json_key")
            _reject_unsafe_json_tree(item, depth=depth + 1, seen=seen)
    elif isinstance(value, list):
        for item in value:
            _reject_unsafe_json_tree(item, depth=depth + 1, seen=seen)
    elif isinstance(value, tuple):
        raise ValueError("phase_1335_json_tuple_forbidden")
    elif isinstance(value, str):
        _require_text(value, "json_text")
    elif isinstance(value, bool) or value is None:
        pass
    elif isinstance(value, int):
        if abs(value) > _MAX_INT_ABS:
            raise ValueError("phase_1335_json_int_bound_exceeded")
    else:
        raise ValueError("phase_1335_json_scalar_invalid")
    if isinstance(value, (Mapping, list, tuple)):
        seen.remove(marker)


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--json-out", default=PHASE_1335_DEFAULT_JSON_REPORT.as_posix())
    parser.add_argument(
        "--markdown-out", default=PHASE_1335_DEFAULT_MARKDOWN_REPORT.as_posix()
    )
    parser.add_argument("--authority-token", default=None)
    parser.add_argument("--external-key-path", default=DEFAULT_EXTERNAL_KEY_PATH.as_posix())
    args = parser.parse_args(argv)
    manifest = write_phase_1335_outputs(
        authority_token=args.authority_token,
        repo_root=args.repo_root,
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        external_key_path=args.external_key_path,
    )
    print(pretty_json(manifest), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


__all__ = [
    "EXPLICIT_AUTHORITY_PHRASE",
    "PHASE_1335_DEFAULT_JSON_REPORT",
    "PHASE_1335_DEFAULT_MARKDOWN_REPORT",
    "RELEASE_KEYS_ENVELOPES_GENERATION_GATE_VERSION",
    "build_release_keys_envelopes_generation_gate",
    "canonical_json",
    "phase_1335_required_tokens",
    "pretty_json",
    "render_markdown_report",
    "validate_release_keys_envelopes_generation_gate",
    "write_phase_1335_outputs",
]
