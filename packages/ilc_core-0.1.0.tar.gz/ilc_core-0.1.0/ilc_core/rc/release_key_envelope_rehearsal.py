# PUBLIC_RC_EXCLUDE: internal_release_key_envelope_rehearsal_tool_not_public_rc_launch_surface
# PUBLIC_RC_EXCLUDE_REASON: Phase 1321 dry-run signing-procedure rehearsal; never release key material.
"""Deterministic release key/envelope procedure rehearsal for Phase 1321.

This module creates rehearsal evidence only. It does not generate keys, read key
paths, read credential environment variables, call signing providers, produce
release envelopes, sign anything, or authorize release material.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from collections.abc import Mapping
from pathlib import Path, PurePosixPath
from typing import Any


RELEASE_KEY_ENVELOPE_REHEARSAL_VERSION = (
    "release_key_envelope_procedure_rehearsal_phase_1321.v0.1"
)
RELEASE_KEY_GENERATION_NOT_AUTHORIZED_TOKEN = (
    "release_key_generation_not_authorized_phase_1321"
)
RELEASE_ENVELOPE_PRODUCTION_NOT_AUTHORIZED_TOKEN = (
    "release_envelope_production_not_authorized_phase_1321"
)
SIGNING_PROCEDURE_REHEARSED_NO_REAL_SIGNING_TOKEN = (
    "signing_procedure_rehearsed_no_real_signing_phase_1321"
)
PHASE_1322_NEXT_TOKEN = "phase_1322_private_deployment_rehearsal_next"
PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1321_TOKEN = (
    "public_rc_remains_blocked_after_phase_1321"
)

PHASE_1320_SCHEMA_VERSION = (
    "release_artifact_manifest_instance_rehearsal_phase_1320.v0.1"
)
PHASE_1320_NEXT_TOKEN = "phase_1321_release_key_envelope_rehearsal_next"
ADR_0036_TOKEN = "adr_0036_release_key_draft_committed_phase_1159"
ATLAS_G_009_TOKEN = "atlas_g_009_signing_root_envelope_prep_required_no_signing"
ATLAS_G_010_TOKEN = "atlas_g_010_v0_2_signing_only_if_explicitly_authorized"

DEFAULT_PHASE_1320_REPORT_PATH = (
    "docs/specs/ilc_release_artifact_manifest_instance_rehearsal_1320_v0.1.json"
)
DEFAULT_ADR_0036_PATH = "docs/adr/ADR_0036_Operational_Release_Key_Genesis_Binding.md"
DEFAULT_PHASE_1287_PATH = (
    "docs/specs/ilc_release_publication_signing_authorization_preflight_1287_v0.1.md"
)
DEFAULT_ATLAS_G_009_PROMPT_PATH = (
    "docs/antigravity_tasks/antigravity_prompt__atlas_g_009_signing_root_envelope_prep.md"
)
DEFAULT_ATLAS_G_010_PROMPT_PATH = (
    "docs/antigravity_tasks/antigravity_prompt__atlas_g_010_v0_2_signing_ceremony.md"
)
DEFAULT_FORWARD_PLAN_PATH = (
    "docs/specs/ilc_forward_phase_windows_1303_1342_packaging_and_signing_plan_v0.1.md"
)

DRY_RUN_KEY_ID = "DRY_RUN_KEY_ID_DO_NOT_USE"
DRY_RUN_PUBLIC_KEY_PLACEHOLDER = "DRY_RUN_PUBLIC_KEY_BYTES_NOT_A_KEY"
DRY_RUN_ENVELOPE_ID = "DRY_RUN_RELEASE_ENVELOPE_ID_DO_NOT_USE"
DRY_RUN_DIGEST_PLACEHOLDER = "DRY_RUN_DIGEST_NOT_SHA256"
DRY_RUN_SIGNATURE_PLACEHOLDER = "DRY_RUN_SIGNATURE_NOT_A_SIGNATURE"

REAL_SHA256_RE = re.compile(r"^sha256:[0-9a-f]{64}$")
FORBIDDEN_SIGNING_COMMAND_MARKERS = (
    "openssl genpkey",
    "openssl pkeyutl",
    "gpg --sign",
    "cosign sign",
    "ssh-keygen",
    "age-keygen",
    "aws kms sign",
    "gcloud kms asymmetric-sign",
    "az keyvault key sign",
    "pkcs11-tool",
    "ykman piv keys generate",
)


def phase_1321_required_tokens() -> list[str]:
    return [
        RELEASE_KEY_ENVELOPE_REHEARSAL_VERSION,
        RELEASE_KEY_GENERATION_NOT_AUTHORIZED_TOKEN,
        RELEASE_ENVELOPE_PRODUCTION_NOT_AUTHORIZED_TOKEN,
        SIGNING_PROCEDURE_REHEARSED_NO_REAL_SIGNING_TOKEN,
        PHASE_1322_NEXT_TOKEN,
        PUBLIC_RC_REMAINS_BLOCKED_AFTER_PHASE_1321_TOKEN,
    ]


def build_release_key_envelope_rehearsal(
    *,
    repo_root: Path | str = Path("."),
    phase_1320_report_path: str = DEFAULT_PHASE_1320_REPORT_PATH,
    adr_0036_path: str = DEFAULT_ADR_0036_PATH,
    phase_1287_path: str = DEFAULT_PHASE_1287_PATH,
    atlas_g_009_prompt_path: str = DEFAULT_ATLAS_G_009_PROMPT_PATH,
    atlas_g_010_prompt_path: str = DEFAULT_ATLAS_G_010_PROMPT_PATH,
    forward_plan_path: str = DEFAULT_FORWARD_PLAN_PATH,
) -> dict[str, Any]:
    root = Path(repo_root).resolve()
    if not root.exists() or not root.is_dir():
        raise ValueError("phase_1321_repo_root_invalid")

    phase_1320_rel = _normalize_relative_path(
        phase_1320_report_path,
        field="phase_1320_report_path",
    )
    adr_0036_rel = _normalize_relative_path(adr_0036_path, field="adr_0036_path")
    phase_1287_rel = _normalize_relative_path(phase_1287_path, field="phase_1287_path")
    atlas_009_rel = _normalize_relative_path(
        atlas_g_009_prompt_path,
        field="atlas_g_009_prompt_path",
    )
    atlas_010_rel = _normalize_relative_path(
        atlas_g_010_prompt_path,
        field="atlas_g_010_prompt_path",
    )
    forward_plan_rel = _normalize_relative_path(
        forward_plan_path,
        field="forward_plan_path",
    )

    phase_1320_report = _read_json_under_root(root, phase_1320_rel)
    phase_1320_input = _phase_1320_rehearsal_input(root, phase_1320_rel, phase_1320_report)
    adr_0036_contract = _adr_0036_contract(_read_text_under_root(root, adr_0036_rel))
    phase_1287_contract = _phase_1287_contract(_read_text_under_root(root, phase_1287_rel))
    atlas_contract = _atlas_contract(
        _read_text_under_root(root, atlas_009_rel),
        _read_text_under_root(root, atlas_010_rel),
        _read_text_under_root(root, forward_plan_rel),
    )

    dummy_envelope_shape = {
        "artifact_manifest_input": phase_1320_rel,
        "artifact_manifest_input_sha256": _file_sha256(root, phase_1320_rel),
        "dry_run_envelope_id": DRY_RUN_ENVELOPE_ID,
        "dry_run_release_key_id": DRY_RUN_KEY_ID,
        "public_key_placeholder": DRY_RUN_PUBLIC_KEY_PLACEHOLDER,
        "signature_placeholder": DRY_RUN_SIGNATURE_PLACEHOLDER,
        "signed_payload_digest_placeholder": DRY_RUN_DIGEST_PLACEHOLDER,
        "signing_status": "not_signed_rehearsal_only",
    }
    _validate_dummy_envelope_shape(dummy_envelope_shape)

    manifest: dict[str, Any] = {
        "authority_boundary": {
            "future_real_signing_requires_explicit_human_authority": True,
            "phase_1321_satisfies_future_authority_checkpoint": False,
            "required_future_checkpoint": (
                "two_person_or_explicit_human_authority_before_real_key_or_signature"
            ),
            "v0_2_signing_gate": "phase_1340_or_dedicated_atlas_g_010_authority",
        },
        "blocked_materials": [
            _blocked("release_key_generation", "not_authorized_phase_1321"),
            _blocked("release_key_registration_artifact", "not_produced_phase_1321"),
            _blocked("release_public_key_export", "not_produced_phase_1321"),
            _blocked("release_envelope_production", "not_authorized_phase_1321"),
            _blocked("release_signing_material", "not_generated_phase_1321"),
            _blocked("signature", "not_produced_phase_1321"),
            _blocked("hsm_interface", "not_called_phase_1321"),
            _blocked("cloud_kms_api", "not_called_phase_1321"),
            _blocked("wallet_or_signing_provider", "not_called_phase_1321"),
            _blocked("genesis_atlas_mutation_or_signing", "not_authorized_phase_1321"),
            _blocked("v0_2_signing", "not_authorized_phase_1321"),
            _blocked("public_rc_claim", "public_rc_remains_blocked_after_phase_1321"),
        ],
        "credential_observation_policy": {
            "credential_like_environment_values_read": False,
            "environment_names_inspected": [],
            "operator_key_paths_accepted_by_cli": False,
            "operator_key_paths_read": [],
            "release_key_path_inputs": [],
            "secret_material_read": False,
        },
        "dry_run_envelope_shape": dummy_envelope_shape,
        "file_hash_references": [
            _file_reference(root, phase_1320_rel, "phase_1320_dry_run_report_input"),
            _file_reference(root, adr_0036_rel, "adr_0036_release_key_mechanism"),
            _file_reference(root, phase_1287_rel, "phase_1287_signing_preflight"),
            _file_reference(root, atlas_009_rel, "atlas_g_009_future_prompt"),
            _file_reference(root, atlas_010_rel, "atlas_g_010_future_prompt"),
            _file_reference(root, forward_plan_rel, "forward_plan_phase_1339_1340_gate"),
        ],
        "hash_algorithm": {
            "canonical_json": (
                'json.dumps(..., sort_keys=True, allow_nan=False, separators=(",", ":"))'
            ),
            "machine_content_must_not_include_current_timestamps": True,
            "phase_1321_rehearsal_manifest_hash": "",
        },
        "mode": "dry_run_rehearsal_only",
        "non_claims": [
            "no_release_key_generation",
            "no_release_key_registration_artifact",
            "no_release_envelope_production",
            "no_release_signing_material_generation",
            "no_signature",
            "no_hsm_or_kms_call",
            "no_wallet_or_signing_provider_call",
            "no_credential_environment_value_read",
            "no_operator_key_path_read",
            "no_release_artifact_production",
            "no_source_export_execution",
            "no_source_publication",
            "no_package_publication",
            "no_genesis_atlas_mutation_or_signing",
            "no_v0_2_signing",
            "no_public_rc_claim",
            "public_rc_remains_blocked_after_phase_1321",
        ],
        "phase": 1321,
        "phase_1287_preflight": phase_1287_contract,
        "phase_1320_rehearsal_input": phase_1320_input,
        "procedure": {
            "commands_executed_by_this_rehearsal": [
                "python3 -m ilc_core.rc.release_key_envelope_rehearsal --repo-root ."
            ],
            "dangerous_command_markers_blocked": list(FORBIDDEN_SIGNING_COMMAND_MARKERS),
            "future_real_ceremony_file_inventory": _future_real_ceremony_file_inventory(),
            "procedure_steps": _procedure_steps(),
            "signing_binaries_called": [],
        },
        "public_rc_remains_blocked": True,
        "release_key_binding_context": adr_0036_contract,
        "required_tokens": phase_1321_required_tokens(),
        "result": "pass",
        "schema_version": RELEASE_KEY_ENVELOPE_REHEARSAL_VERSION,
        "signing_gate_context": atlas_contract,
    }
    manifest["hash_algorithm"]["phase_1321_rehearsal_manifest_hash"] = (
        _manifest_hash_without_self_reference(manifest)
    )
    return _validate_rehearsal_manifest(manifest)


def canonical_release_key_envelope_rehearsal_json(manifest: Mapping[str, Any]) -> str:
    return json.dumps(manifest, allow_nan=False, separators=(",", ":"), sort_keys=True)


def pretty_release_key_envelope_rehearsal_json(manifest: Mapping[str, Any]) -> str:
    return json.dumps(manifest, allow_nan=False, indent=2, sort_keys=True) + "\n"


def manifest_hash(manifest: Mapping[str, Any]) -> str:
    return hashlib.sha256(
        canonical_release_key_envelope_rehearsal_json(manifest).encode("utf-8")
    ).hexdigest()


def render_rehearsal_markdown(manifest: Mapping[str, Any]) -> str:
    phase_1320_input = manifest["phase_1320_rehearsal_input"]
    dummy = manifest["dry_run_envelope_shape"]
    return "\n".join(
        [
            "# ILC Release Key Envelope Procedure Rehearsal 1321 v0.1",
            "",
            "**Status:** DRY-RUN REHEARSAL ONLY, NO KEYS, NO ENVELOPES, NO SIGNING.",
            "**Phase:** 1321.",
            "",
            "```text",
            *phase_1321_required_tokens(),
            "```",
            "",
            "## Verdict",
            "",
            f"- Result: `{manifest['result']}`.",
            f"- Phase 1320 input result: `{phase_1320_input['result']}`.",
            f"- Dummy key id: `{dummy['dry_run_release_key_id']}`.",
            f"- Dummy envelope id: `{dummy['dry_run_envelope_id']}`.",
            "- Release key files created: `0`.",
            "- Release envelope files created: `0`.",
            "- Signature files created: `0`.",
            f"- Rehearsal manifest hash: `{manifest['hash_algorithm']['phase_1321_rehearsal_manifest_hash']}`.",
            "",
            "## Boundary",
            "",
            "This is a procedure rehearsal over fake identifiers only.",
            "It references ADR-0036 and Atlas-G signing gates as context, but it does not satisfy a future two-person or explicit-human signing checkpoint.",
            "The runtime environment is not inspected for secret values; no release-key path, credential-like environment value, HSM, KMS, wallet, or signing provider is read or called.",
            "",
            "## Non-Claims",
            "",
            "No release key, release key registration artifact, release envelope, signature, HSM/KMS/wallet-provider call, source export, publication, release artifact, Genesis Atlas mutation/signing, v0.2 signing, or public RC claim is produced or authorized.",
            "Public RC remains blocked after Phase 1321.",
            "",
        ]
    )


def write_rehearsal_outputs(
    *,
    json_out: Path | None,
    markdown_out: Path | None,
    manifest: Mapping[str, Any],
) -> None:
    if json_out is not None:
        _write_text_atomic(json_out, pretty_release_key_envelope_rehearsal_json(manifest))
    if markdown_out is not None:
        _write_text_atomic(markdown_out, render_rehearsal_markdown(manifest))


def _phase_1320_rehearsal_input(
    repo_root: Path,
    phase_1320_rel_path: str,
    report: Mapping[str, Any],
) -> dict[str, Any]:
    if report.get("schema_version") != PHASE_1320_SCHEMA_VERSION:
        raise ValueError("phase_1321_phase_1320_schema_version_invalid")
    if report.get("result") != "pass":
        raise ValueError("phase_1321_phase_1320_rehearsal_must_pass")
    if PHASE_1320_NEXT_TOKEN not in report.get("required_tokens", ()):
        raise ValueError("phase_1321_phase_1320_next_token_missing")
    if report.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1321_phase_1320_public_rc_blocked_required")
    negative = report.get("negative_evidence")
    if not isinstance(negative, dict):
        raise ValueError("phase_1321_phase_1320_negative_evidence_missing")
    if negative.get("generated_release_artifact_paths") or negative.get(
        "generated_release_checksum_paths"
    ):
        raise ValueError("phase_1321_phase_1320_artifact_paths_must_be_empty")
    if negative.get("no_artifact_payloads_created") is not True:
        raise ValueError("phase_1321_phase_1320_artifact_payload_absence_required")
    if negative.get("no_artifact_checksums_created") is not True:
        raise ValueError("phase_1321_phase_1320_artifact_checksum_absence_required")
    return {
        "input_report_sha256": _file_sha256(repo_root, phase_1320_rel_path),
        "path": phase_1320_rel_path,
        "result": report["result"],
        "schema_version": report["schema_version"],
        "status": "dry_run_manifest_shape_input_only",
    }


def _adr_0036_contract(text: str) -> dict[str, Any]:
    if ADR_0036_TOKEN not in text:
        raise ValueError("phase_1321_adr_0036_token_missing")
    normalized = " ".join(text.split())
    required_phrases = [
        "does not create the key and does not authorize any signing ceremony",
        "release key registration artifact",
        "release envelope",
        "canonical serialization",
    ]
    missing = [phrase for phrase in required_phrases if phrase not in normalized]
    if missing:
        raise ValueError("phase_1321_adr_0036_required_phrase_missing")
    return {
        "adr_token": ADR_0036_TOKEN,
        "header_status": "Accepted",
        "observed_status_note": (
            "ADR text also contains older deferred/proposed wording; Phase 1321 treats "
            "ADR-0036 as mechanism context only, never as signing authority."
        ),
        "release_key_is_delegated_not_root": True,
        "signing_authority_created_by_phase_1321": False,
    }


def _phase_1287_contract(text: str) -> dict[str, Any]:
    required = [
        "release_keys_not_generated_phase_1287",
        "release_envelope_not_produced_phase_1287",
        "v0_2_signing_not_authorized_phase_1287",
        "explicit release-key and release-envelope generation authority",
        "explicit v0.2 signing ceremony authority after the Atlas-G tail",
    ]
    missing = [phrase for phrase in required if phrase not in text]
    if missing:
        raise ValueError("phase_1321_phase_1287_required_phrase_missing")
    return {
        "phase_1287_preserves_no_key_generation": True,
        "phase_1287_preserves_no_envelope_production": True,
        "phase_1287_preserves_no_v0_2_signing": True,
    }


def _atlas_contract(atlas_009_text: str, atlas_010_text: str, forward_plan_text: str) -> dict[str, Any]:
    if ATLAS_G_009_TOKEN not in atlas_009_text:
        raise ValueError("phase_1321_atlas_g_009_token_missing")
    if ATLAS_G_010_TOKEN not in atlas_010_text:
        raise ValueError("phase_1321_atlas_g_010_token_missing")
    if "| 1340 | v0.2 signing ceremony gate |" not in forward_plan_text:
        raise ValueError("phase_1321_forward_plan_phase_1340_missing")
    return {
        "atlas_g_009_no_signing_token": ATLAS_G_009_TOKEN,
        "atlas_g_010_authorization_token": ATLAS_G_010_TOKEN,
        "phase_1321_satisfies_atlas_g_009": False,
        "phase_1321_satisfies_atlas_g_010": False,
        "signing_gate_phase": 1340,
    }


def _future_real_ceremony_file_inventory() -> list[dict[str, Any]]:
    return [
        _not_produced("release_key_registration_artifact"),
        _not_produced("operational_release_public_key_export"),
        _not_produced("release_envelope_json"),
        _not_produced("release_envelope_signature"),
        _not_produced("signing_root_envelope_candidate"),
        _not_produced("signature_verification_report"),
        _not_produced("release_signing_audit_log"),
    ]


def _procedure_steps() -> list[dict[str, str]]:
    return [
        {
            "step": "verify_phase_1320_rehearsal_input",
            "status": "rehearsed_no_artifact_or_key_material",
        },
        {
            "step": "bind_dummy_release_key_identifier",
            "status": "dry_run_identifier_only",
        },
        {
            "step": "construct_dummy_envelope_shape",
            "status": "placeholder_only_not_real_envelope",
        },
        {
            "step": "record_future_human_authority_checkpoint",
            "status": "checkpoint_not_satisfied_by_phase_1321",
        },
        {
            "step": "prove_no_key_envelope_signature_outputs",
            "status": "all_output_lists_empty",
        },
    ]


def _not_produced(material: str) -> dict[str, Any]:
    return {
        "material": material,
        "path": None,
        "produced_in_phase_1321": False,
        "status": "not_produced_dry_run_only",
    }


def _validate_dummy_envelope_shape(dummy: Mapping[str, str]) -> None:
    required_prefix_fields = (
        "dry_run_envelope_id",
        "dry_run_release_key_id",
        "public_key_placeholder",
        "signature_placeholder",
        "signed_payload_digest_placeholder",
    )
    for field in required_prefix_fields:
        value = dummy.get(field)
        if not isinstance(value, str) or not value.startswith("DRY_RUN_"):
            raise ValueError("phase_1321_dummy_identifier_prefix_required")
        if REAL_SHA256_RE.match(value):
            raise ValueError("phase_1321_dummy_identifier_must_not_be_real_digest")
    if dummy.get("signing_status") != "not_signed_rehearsal_only":
        raise ValueError("phase_1321_dummy_signing_status_invalid")


def _validate_rehearsal_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    if manifest.get("schema_version") != RELEASE_KEY_ENVELOPE_REHEARSAL_VERSION:
        raise ValueError("phase_1321_schema_version_invalid")
    if manifest.get("required_tokens") != phase_1321_required_tokens():
        raise ValueError("phase_1321_required_tokens_invalid")
    if manifest.get("mode") != "dry_run_rehearsal_only":
        raise ValueError("phase_1321_mode_invalid")
    if manifest.get("public_rc_remains_blocked") is not True:
        raise ValueError("phase_1321_public_rc_blocked_required")
    credential_policy = manifest["credential_observation_policy"]
    if credential_policy["credential_like_environment_values_read"] is not False:
        raise ValueError("phase_1321_environment_values_must_not_be_read")
    if credential_policy["operator_key_paths_read"]:
        raise ValueError("phase_1321_operator_key_paths_must_be_empty")
    if credential_policy["secret_material_read"] is not False:
        raise ValueError("phase_1321_secret_material_must_not_be_read")
    for item in manifest["procedure"]["future_real_ceremony_file_inventory"]:
        if item["produced_in_phase_1321"] is not False or item["path"] is not None:
            raise ValueError("phase_1321_future_file_inventory_must_not_be_produced")
    if manifest["procedure"]["signing_binaries_called"]:
        raise ValueError("phase_1321_signing_binaries_must_not_be_called")
    commands = "\n".join(manifest["procedure"]["commands_executed_by_this_rehearsal"])
    for marker in FORBIDDEN_SIGNING_COMMAND_MARKERS:
        if marker in commands:
            raise ValueError("phase_1321_forbidden_signing_command_marker")
    if (
        manifest["hash_algorithm"]["phase_1321_rehearsal_manifest_hash"]
        != _manifest_hash_without_self_reference(manifest)
    ):
        raise ValueError("phase_1321_manifest_hash_mismatch")
    canonical_release_key_envelope_rehearsal_json(manifest)
    return manifest


def _blocked(material: str, reason: str) -> dict[str, str]:
    return {"material": material, "reason": reason, "status": "blocked"}


def _file_reference(repo_root: Path, rel_path: str, source: str) -> dict[str, str]:
    return {
        "hash_classification": "existing_rehearsal_input_not_key_or_signature",
        "path": rel_path,
        "sha256": _file_sha256(repo_root, rel_path),
        "source": source,
    }


def _file_sha256(repo_root: Path, rel_path: str) -> str:
    return hashlib.sha256(_read_bytes_under_root(repo_root, rel_path)).hexdigest()


def _normalize_relative_path(raw: str, *, field: str) -> str:
    if not isinstance(raw, str) or not raw.strip():
        raise ValueError(f"phase_1321_{field}_invalid")
    if "\\" in raw or raw.startswith("/") or raw.startswith("~"):
        raise ValueError(f"phase_1321_{field}_not_repo_relative")
    path = PurePosixPath(raw)
    if path.is_absolute() or str(path) in {"", "."}:
        raise ValueError(f"phase_1321_{field}_not_repo_relative")
    if any(part in {"", ".", ".."} for part in path.parts):
        raise ValueError(f"phase_1321_{field}_traversal_rejected")
    return path.as_posix()


def _resolve_under_root(repo_root: Path, rel_path: str) -> Path:
    candidate = (repo_root / Path(*PurePosixPath(rel_path).parts)).resolve(strict=False)
    if candidate != repo_root and repo_root not in candidate.parents:
        raise ValueError("phase_1321_path_escape_rejected")
    return candidate


def _read_bytes_under_root(repo_root: Path, rel_path: str) -> bytes:
    path = _resolve_under_root(repo_root, rel_path)
    if not path.is_file():
        raise ValueError("phase_1321_input_file_missing")
    return path.read_bytes()


def _read_text_under_root(repo_root: Path, rel_path: str) -> str:
    return _read_bytes_under_root(repo_root, rel_path).decode("utf-8")


def _read_json_under_root(repo_root: Path, rel_path: str) -> dict[str, Any]:
    parsed = json.loads(_read_text_under_root(repo_root, rel_path))
    if not isinstance(parsed, dict):
        raise ValueError("phase_1321_json_input_invalid")
    return parsed


def _manifest_hash_without_self_reference(manifest: Mapping[str, Any]) -> str:
    clone = json.loads(canonical_release_key_envelope_rehearsal_json(manifest))
    clone["hash_algorithm"]["phase_1321_rehearsal_manifest_hash"] = ""
    return manifest_hash(clone)


def _write_text_atomic(path: Path, payload: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=path.parent,
        prefix=f".{path.name}.",
        suffix=".tmp",
        text=True,
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(payload)
        os.replace(tmp_path, path)
    except Exception:
        try:
            tmp_path.unlink()
        except FileNotFoundError:
            pass
        raise


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path("."))
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--markdown-out", type=Path)
    args = parser.parse_args(argv)

    manifest = build_release_key_envelope_rehearsal(repo_root=args.repo_root)
    write_rehearsal_outputs(
        json_out=args.json_out,
        markdown_out=args.markdown_out,
        manifest=manifest,
    )
    if args.json_out is None and args.markdown_out is None:
        print(pretty_release_key_envelope_rehearsal_json(manifest), end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
