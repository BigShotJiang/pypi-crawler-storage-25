"""
MCP Tool Service.

In-process MCP tool service for external agent integration.
Routes tool calls through schema validation and returns schema-valid responses.
Optionally logs tool calls to a ProtocolEventLog for audit trail.
"""

from __future__ import annotations

import hashlib
import importlib.resources
import json
import secrets
import time
from typing import Any, Callable, Dict, Optional

import jsonschema

from ilc_core.mcp.schema import (
    load_mcp_tools_schema,
    get_tool_schema,
    validate_tool_payload,
)
from ilc_core.protocol.event_log import ProtocolEventLog, make_event

# Payload size threshold for logging (8 KiB)
PAYLOAD_SIZE_THRESHOLD = 8 * 1024

# Keys to redact from audit logs (sensitive/large blob fields)
REDACTED_KEYS = {"bytes_b64", "bundle_bytes_b64", "blocks_inline"}

# Audit schema (cached)
_AUDIT_SCHEMA: Optional[Dict[str, Any]] = None


def _load_audit_schema() -> Dict[str, Any]:
    """Load the mcp_tool_call event schema from package resources (cached)."""
    global _AUDIT_SCHEMA
    if _AUDIT_SCHEMA is None:
        try:
            # Load from package resources (works when installed)
            schema_ref = importlib.resources.files("ilc_core.mcp.schemas").joinpath(
                "mcp_tool_call_event_schema_v0.1.json"
            )
            with schema_ref.open("r", encoding="utf-8") as f:
                _AUDIT_SCHEMA = json.load(f)
        except (FileNotFoundError, TypeError) as e:
            raise RuntimeError(
                "mcp_tool_call_event_schema_v0.1.json not found in package resources"
            ) from e
    return _AUDIT_SCHEMA


def _validate_audit_payload(payload: Dict[str, Any]) -> None:
    """Validate audit payload against schema. Raises ValueError if invalid."""
    schema = _load_audit_schema()
    try:
        jsonschema.validate(instance=payload, schema=schema)
    except jsonschema.ValidationError as e:
        raise ValueError(f"Audit payload schema validation failed: {e.message}") from e


def _compute_digest(value: Any) -> str:
    """Compute SHA-256 hex digest of a value."""
    serialized = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _redact_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Recursively redact sensitive keys from payload.
    
    Replaces values of redacted keys with {"redacted": true, "digest": "<sha256>"}.
    Preserves structure shape for audit trail clarity.
    """
    result = {}
    for key, value in payload.items():
        if key in REDACTED_KEYS:
            # Redact the value, compute digest for traceability
            result[key] = {
                "redacted": True,
                "digest": _compute_digest(value),
            }
        elif isinstance(value, dict):
            # Recurse into nested dicts
            result[key] = _redact_payload(value)
        elif isinstance(value, list):
            # Recurse into list items if they are dicts
            result[key] = [
                _redact_payload(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


def _maybe_summarize_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Return payload or summary if it exceeds size threshold.
    
    First applies redaction, then checks size.
    
    Returns dict with either the original payload or:
    - payload_summary: truncated string representation
    - payload_digest: SHA-256 hex digest
    """
    # Apply redaction first
    redacted = _redact_payload(payload)
    
    serialized = json.dumps(redacted, sort_keys=True, separators=(",", ":"), allow_nan=False)
    if len(serialized) <= PAYLOAD_SIZE_THRESHOLD:
        return {"data": redacted, "summarized": False}
    
    digest = hashlib.sha256(serialized.encode("utf-8")).hexdigest()
    summary = serialized[:200] + "..."
    return {
        "payload_summary": summary,
        "payload_digest": digest,
        "summarized": True,
    }


class MCPToolService:
    """
    In-process MCP tool service.
    
    Validates tool inputs and outputs against schema.
    Optionally logs tool calls to a ProtocolEventLog.
    """
    
    # Supported tool names
    SUPPORTED_TOOLS = [
        "ilc.capabilities.get",
        "ilc.task.get",
        "ilc.block.get",
        "ilc.bundle.submit",
    ]
    
    def __init__(
        self,
        event_log: Optional[ProtocolEventLog] = None,
        node_id: Optional[str] = None,
        audit_sample_rate: Optional[float] = None,
        audit_max_per_minute: Optional[int] = None,
        audit_rng_seed: Optional[int] = None,
        audit_clock: Optional[Callable[[], float]] = None,
    ) -> None:
        """
        Initialize tool service with schema.
        
        Args:
            event_log: Optional event log for audit trail.
            node_id: Optional node ID for audit provenance.
            audit_sample_rate: Optional sampling rate (0.0-1.0). None = log all.
            audit_max_per_minute: Optional rate limit. None = no limit.
            audit_rng_seed: Optional RNG seed for deterministic sampling in tests.
            audit_clock: Optional clock function for deterministic rate-limit tests.
        """
        self._schema = load_mcp_tools_schema()
        self._event_log = event_log
        self._node_id = node_id
        self._schema_version = self._schema.get("version", "0.1")
        
        # Sampling and rate-limiting
        self._sample_rate = audit_sample_rate
        self._max_per_minute = audit_max_per_minute
        self._audit_rng_seed = audit_rng_seed
        self._system_random = secrets.SystemRandom()
        self._sample_counter = 0
        self._clock = audit_clock or time.monotonic
        self._current_minute: Optional[int] = None
        self._events_this_minute = 0
    
    def handle_request(self, tool_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle a tool request.
        
        Args:
            tool_name: Name of the tool to invoke.
            payload: Input payload for the tool.
            
        Returns:
            Schema-valid output payload.
            
        Raises:
            ValueError: If tool is unknown, input is invalid, or output is invalid.
        """
        if tool_name not in self.SUPPORTED_TOOLS:
            raise ValueError(f"Unknown tool: {tool_name}")
        
        # Get tool schema and validate input
        tool_schema = get_tool_schema(self._schema, tool_name)
        
        try:
            validate_tool_payload(tool_schema, payload, mode="input")
        except ValueError as e:
            # Log error event
            self._log_event(
                tool_name=tool_name,
                input_payload=payload,
                output_payload=None,
                status="error",
                error=str(e),
            )
            raise
        
        # Route to handler
        if tool_name == "ilc.capabilities.get":
            result = self._handle_capabilities_get(payload)
        elif tool_name == "ilc.task.get":
            result = self._handle_task_get(payload)
        elif tool_name == "ilc.block.get":
            result = self._handle_block_get(payload)
        elif tool_name == "ilc.bundle.submit":
            result = self._handle_bundle_submit(payload)
        else:
            raise ValueError(f"Unhandled tool: {tool_name}")
        
        # Validate output before returning
        try:
            validate_tool_payload(tool_schema, result, mode="output")
        except ValueError as e:
            # Log output validation error
            self._log_event(
                tool_name=tool_name,
                input_payload=payload,
                output_payload=result,
                status="error",
                error=str(e),
            )
            raise
        
        # Log success event
        self._log_event(
            tool_name=tool_name,
            input_payload=payload,
            output_payload=result,
            status="ok",
        )
        
        return result
    
    def _log_event(
        self,
        tool_name: str,
        input_payload: Dict[str, Any],
        output_payload: Optional[Dict[str, Any]],
        status: str,
        error: Optional[str] = None,
    ) -> None:
        """Log an mcp_tool_call event if event_log is configured."""
        if self._event_log is None:
            return
        
        # Apply sampling (skip if random roll exceeds rate)
        if self._sample_rate is not None:
            if self._sample_roll(tool_name=tool_name, input_payload=input_payload) > self._sample_rate:
                return
        
        # Apply rate limiting
        if self._max_per_minute is not None:
            current_minute = int(self._clock() // 60)
            if self._current_minute != current_minute:
                # New minute, reset counter
                self._current_minute = current_minute
                self._events_this_minute = 0
            
            if self._events_this_minute >= self._max_per_minute:
                # Limit exceeded, silently skip
                return
            
            self._events_this_minute += 1
        
        # Build event payload with size guards
        input_info = _maybe_summarize_payload(input_payload)
        
        event_payload: Dict[str, Any] = {
            "tool_name": tool_name,
            "status": status,
            "schema_version": self._schema_version,
        }
        
        # Add node_id if provided
        if self._node_id:
            event_payload["node_id"] = self._node_id
        
        # Add input (possibly summarized)
        if input_info["summarized"]:
            event_payload["input_summary"] = input_info["payload_summary"]
            event_payload["input_digest"] = input_info["payload_digest"]
        else:
            event_payload["input"] = input_info["data"]
        
        # Add output (possibly summarized) if present
        if output_payload is not None:
            output_info = _maybe_summarize_payload(output_payload)
            if output_info["summarized"]:
                event_payload["output_summary"] = output_info["payload_summary"]
                event_payload["output_digest"] = output_info["payload_digest"]
            else:
                event_payload["output"] = output_info["data"]
        
        # Add error if present
        if error is not None:
            event_payload["error"] = error
        
        # Validate payload against schema before logging
        _validate_audit_payload(event_payload)
        
        event = make_event(
            kind="mcp_tool_call",
            payload=event_payload,
            source="mcp_tool_service",
        )
        self._event_log.append(event)

    def _sample_roll(self, *, tool_name: str, input_payload: Dict[str, Any]) -> float:
        if self._audit_rng_seed is None:
            return self._system_random.random()

        canonical_payload = json.dumps(
            {
                "seed": self._audit_rng_seed,
                "counter": self._sample_counter,
                "tool_name": tool_name,
                "input": input_payload,
            },
            sort_keys=True,
            separators=(",", ":"),
            allow_nan=False,
        )
        self._sample_counter += 1
        digest = hashlib.sha256(canonical_payload.encode("utf-8")).digest()
        return int.from_bytes(digest[:8], "big") / float(1 << 64)
    
    def _handle_capabilities_get(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle ilc.capabilities.get."""
        return {
            "protocol_version": "0.1",
            "supported_codecs": ["dag-cbor"],
            "supported_multihash": ["sha2-256"],
            "max_block_bytes": 1048576,
            "max_bundle_bytes": 10485760,
            "signature_algorithms": ["ed25519"],
            "notes": "MVP stub",
        }
    
    def _handle_task_get(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle ilc.task.get (stub)."""
        return {
            "tasks": [
                {
                    "task_id": "task-stub-001",
                    "task_class": "custom",
                    "input_cids": ["bafyreistub"],
                    "submission": {
                        "expected_outputs": "Stubbed task output",
                        "requires_attestation": True,
                        "accepted_signature_algorithms": ["ed25519"],
                        "max_submit_bytes": 1048576,
                    },
                    "bounty": {
                        "bounty_id": "bounty-stub-001",
                        "ecu_estimate": 1.0,
                        "deadline": "2026-12-31T00:00:00Z",
                    },
                }
            ]
        }
    
    def _handle_block_get(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle ilc.block.get (stub)."""
        cid = payload.get("cid", "bafyreistub")
        allow_inline = payload.get("allow_inline_bytes", True)
        
        result: Dict[str, Any] = {
            "cid": cid,
            "codec": "dag-cbor",
            "size_bytes": 0,
        }
        
        # Only include bytes_b64 if allow_inline_bytes is True
        if allow_inline:
            result["bytes_b64"] = ""
        
        return result
    
    def _handle_bundle_submit(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Handle ilc.bundle.submit (stub acknowledgment)."""
        roots = payload.get("roots", [])
        return {
            "accepted": True,
            "received_roots": roots,
        }
