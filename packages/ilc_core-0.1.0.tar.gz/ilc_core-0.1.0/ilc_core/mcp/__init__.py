# ILC Core MCP integration utilities.
