"""
MCP Schema Loader and Validator.

Provides utilities for loading and validating payloads against the
ILC MCP tool schemas. Loads from package resources first, falls back
to repo docs path for development.
"""

from __future__ import annotations

import json
from importlib import resources
from pathlib import Path
from typing import Any

from jsonschema import Draft7Validator, ValidationError


# Schema filename
SCHEMA_FILENAME = "ilc_mcp_tools_mvp_schema_v0.1.json"

# Fallback path relative to repo root
SCHEMA_FILE_FALLBACK = f"docs/mcp/{SCHEMA_FILENAME}"


def load_mcp_tools_schema() -> dict[str, Any]:
    """
    Load the MCP tools schema.
    
    First tries to load from package resources (ilc_core.mcp.schemas),
    then falls back to repo-relative docs path.
    
    Returns:
        Parsed JSON schema as dict.
        
    Raises:
        FileNotFoundError: If schema file does not exist.
        json.JSONDecodeError: If schema file is not valid JSON.
    """
    # Try package resources first
    try:
        pkg_files = resources.files("ilc_core.mcp.schemas")
        schema_file = pkg_files.joinpath(SCHEMA_FILENAME)
        with schema_file.open("r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, ModuleNotFoundError, TypeError):
        pass
    
    # Fallback: search for repo-relative path
    current = Path(__file__).resolve()
    for parent in current.parents:
        candidate = parent / SCHEMA_FILE_FALLBACK
        if candidate.exists():
            with open(candidate, "r", encoding="utf-8") as f:
                return json.load(f)
    
    raise FileNotFoundError(
        f"Could not find {SCHEMA_FILENAME} in package or repo"
    )


def get_tool_schema(schema: dict[str, Any], tool_name: str) -> dict[str, Any]:
    """
    Get a specific tool schema by name.
    
    Args:
        schema: The full MCP tools schema dict.
        tool_name: Name of the tool to retrieve.
        
    Returns:
        The tool schema dict.
        
    Raises:
        KeyError: If tool is not found.
    """
    tools = schema.get("tools", [])
    for tool in tools:
        if tool.get("name") == tool_name:
            return tool
    raise KeyError(f"Tool not found: {tool_name}")


def validate_tool_payload(
    tool_schema: dict[str, Any],
    payload: dict[str, Any],
    mode: str,
) -> None:
    """
    Validate a payload against a tool's input or output schema.
    
    Uses Draft 7 JSON Schema validation for consistency.
    
    Args:
        tool_schema: The tool schema dict (from get_tool_schema).
        payload: The payload to validate.
        mode: Either "input" or "output".
        
    Raises:
        ValueError: If mode is invalid or validation fails.
    """
    if mode not in ("input", "output"):
        raise ValueError(f"mode must be 'input' or 'output', got {mode!r}")
    
    schema_key = f"{mode}_schema"
    if schema_key not in tool_schema:
        raise ValueError(f"Tool schema missing {schema_key}")
    
    sub_schema = tool_schema[schema_key]
    
    try:
        validator = Draft7Validator(sub_schema)
        validator.validate(payload)
    except ValidationError as e:
        raise ValueError(f"Validation failed for {mode}: {e.message}") from e
