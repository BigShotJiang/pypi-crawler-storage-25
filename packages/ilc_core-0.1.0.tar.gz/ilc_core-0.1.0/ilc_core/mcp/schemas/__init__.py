# Package marker for ilc_core.mcp.schemas resource loading.
