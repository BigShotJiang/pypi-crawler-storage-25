"""
Node MCP Tool Service Adapter.

Wraps MCPToolService and binds it to an ILCNodeV0's event log.
"""

from __future__ import annotations

from typing import Any, Dict

from ilc_core.mcp.service import MCPToolService
from ilc_core.node.node_v0 import ILCNodeV0


class NodeMCPToolService:
    """
    MCP tool service bound to a node's event log.
    
    Convenience wrapper that wires up audit logging automatically.
    """
    
    def __init__(self, node: ILCNodeV0) -> None:
        """
        Initialize with a node.
        
        Args:
            node: The ILCNodeV0 instance whose event log will receive audit events.
        """
        self._node = node
        self._service = MCPToolService(event_log=node.event_log, node_id=node.node_id)
    
    def handle_request(self, tool_name: str, payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Handle a tool request.
        
        Delegates to the underlying MCPToolService, which logs to the node's event log.
        """
        return self._service.handle_request(tool_name, payload)
    
    @property
    def node(self) -> ILCNodeV0:
        """Access the bound node."""
        return self._node
