from __future__ import annotations

import xml.etree.ElementTree as ET
from html import unescape
from html.parser import HTMLParser

BLOCK_TAGS = {"div", "p", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"}


def enml_to_text(enml: str) -> str:
    """Convert ENML content into a simplified plain-text representation."""
    # This guard exists because deleted or metadata-only notes may not include content.
    if not enml:
        return ""

    try:
        root = ET.fromstring(enml)
        text = _element_text(root)
    except ET.ParseError:
        # This guard exists because some notes can contain markup that ElementTree rejects even though Evernote accepts it.
        parser = _EnmlTextParser()
        parser.feed(enml)
        text = parser.text()

    lines = [line.strip() for line in unescape(text).splitlines()]
    return "\n".join(line for line in lines if line)


def _element_text(node) -> str:
    parts: list[str] = []

    def walk(current) -> None:
        tag = current.tag.lower() if isinstance(current.tag, str) else ""

        if current.text:
            parts.append(current.text)

        for child in current:
            child_tag = child.tag.lower() if isinstance(child.tag, str) else ""

            # This guard exists because <br> should behave like a line break in plain text output.
            if child_tag == "br":
                parts.append("\n")

            walk(child)

            if child.tail:
                parts.append(child.tail)

        # This guard exists because block-like ENML tags should break lines in plain text output.
        if tag in BLOCK_TAGS:
            parts.append("\n")

    walk(node)
    return "".join(parts)


class _EnmlTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=False)
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        # This guard exists because <br> should behave like a line break in plain text output.
        if tag.lower() == "br":
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        # This guard exists because block-like ENML tags should break lines in plain text output.
        if tag.lower() in BLOCK_TAGS:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        self.parts.append(data)

    def handle_entityref(self, name: str) -> None:
        self.parts.append(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self.parts.append(f"&#{name};")

    def text(self) -> str:
        return "".join(self.parts)
