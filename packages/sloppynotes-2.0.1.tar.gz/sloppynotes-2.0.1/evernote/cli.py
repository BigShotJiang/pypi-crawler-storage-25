from __future__ import annotations

import argparse
from pathlib import Path

from .auth import (
    DEFAULT_AUTH_PATH,
    DEFAULT_CDP_PORT,
    DEFAULT_CDP_CONNECT_TIMEOUT_MS,
    DEFAULT_PROFILE_DIR,
    login_via_browser,
)


def main() -> int:
    parser = argparse.ArgumentParser(prog="evernote")
    subparsers = parser.add_subparsers(dest="command")

    login_parser = subparsers.add_parser(
        "login", help="capture Evernote auth from a managed CDP browser"
    )
    login_parser.add_argument("--auth-path", default=str(DEFAULT_AUTH_PATH))
    login_parser.add_argument("--profile-dir", default=str(DEFAULT_PROFILE_DIR))
    login_parser.add_argument("--browser-path", default=None)
    login_parser.add_argument("--cdp-port", type=int, default=DEFAULT_CDP_PORT)
    login_parser.add_argument(
        "--cdp-timeout-ms",
        type=int,
        default=DEFAULT_CDP_CONNECT_TIMEOUT_MS,
        help="timeout for connecting to an existing CDP browser",
    )
    login_parser.add_argument(
        "--use-existing-browser",
        "--no-launch",
        dest="use_existing_browser",
        action="store_true",
        help="connect to an existing CDP browser and do not launch a separate profile",
    )

    args = parser.parse_args()

    if args.command == "login":
        ok, message = login_via_browser(
            auth_path=Path(args.auth_path),
            profile_dir=Path(args.profile_dir),
            browser_path=args.browser_path,
            cdp_port=args.cdp_port,
            launch_browser=not args.use_existing_browser,
            cdp_connect_timeout_ms=args.cdp_timeout_ms,
        )
        print(message)
        return 0 if ok else 1

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
