from __future__ import annotations

from io import BytesIO, StringIO

import requests
import thriftpy2
from thriftpy2.protocol.binary import TBinaryProtocolFactory
from thriftpy2.thrift import TClient
from thriftpy2.transport.buffered import TBufferedTransportFactory

THRIFT_IDL = """
namespace py evernote_web_session_thrift

enum EDAMErrorCode {
  UNKNOWN = 1
  BAD_DATA_FORMAT = 2
  PERMISSION_DENIED = 3
  INTERNAL_ERROR = 4
  DATA_REQUIRED = 5
  LIMIT_REACHED = 6
  QUOTA_REACHED = 7
  INVALID_AUTH = 8
  AUTH_EXPIRED = 9
  DATA_CONFLICT = 10
  ENML_VALIDATION = 11
  SHARD_UNAVAILABLE = 12
  LEN_TOO_SHORT = 13
  LEN_TOO_LONG = 14
  TOO_FEW = 15
  TOO_MANY = 16
  UNSUPPORTED_OPERATION = 17
  TAKEN_DOWN = 18
  RATE_LIMIT_REACHED = 19
}

exception EDAMUserException {
  1: optional EDAMErrorCode errorCode
  2: optional string parameter
}

exception EDAMSystemException {
  1: optional EDAMErrorCode errorCode
  2: optional string message
  3: optional i32 rateLimitDuration
}

exception EDAMNotFoundException {
  1: optional string identifier
  2: optional string key
}

struct Notebook {
  1: optional string guid
  2: optional string name
  5: optional i32 updateSequenceNum
  6: optional bool defaultNotebook
  7: optional i64 serviceCreated
  8: optional i64 serviceUpdated
  12: optional string stack
  19: optional string workspaceGuid
  20: optional bool inWorkspace
}

struct LinkedNotebook {
  2: optional string shareName
  3: optional string username
  4: optional string shardId
  5: optional string shareKey
  8: optional i32 updateSequenceNum
  9: optional string noteStoreUrl
  10: optional string webApiUrlPrefix
  11: optional string stack
  12: optional i32 businessId
}

struct AuthenticationResult {
  2: optional string authenticationToken
  6: optional string noteStoreUrl
  7: optional string webApiUrlPrefix
}

struct SharedNotebook {
  3: optional string notebookGuid
  8: optional string shareKey
  9: optional string username
}

struct NoteFilter {
  1: optional i32 order
  2: optional bool ascending
  3: optional string words
  4: optional string notebookGuid
  5: optional list<string> tagGuids
  6: optional string timeZone
  7: optional bool inactive
}

struct NotesMetadataResultSpec {
  2: optional bool includeTitle
  5: optional bool includeContentLength
  6: optional bool includeCreated
  7: optional bool includeUpdated
  8: optional bool includeDeleted
  10: optional bool includeUpdateSequenceNum
  11: optional bool includeNotebookGuid
  12: optional bool includeTagGuids
}

struct NoteMetadata {
  1: optional string guid
  2: optional string title
  5: optional i32 contentLength
  6: optional i64 created
  7: optional i64 updated
  8: optional i64 deleted
  10: optional i32 updateSequenceNum
  11: optional string notebookGuid
  12: optional list<string> tagGuids
}

struct NotesMetadataList {
  1: optional i32 startIndex
  2: optional i32 totalNotes
  3: optional list<NoteMetadata> notes
}

struct Note {
  1: optional string guid
  2: optional string title
  3: optional string content
  5: optional i32 contentLength
  6: optional i64 created
  7: optional i64 updated
  8: optional i64 deleted
  10: optional i32 updateSequenceNum
  11: optional string notebookGuid
  12: optional list<string> tagGuids
}

service NoteStore {
  list<Notebook> listNotebooks(
    1: string authenticationToken,
  ) throws (
    1: EDAMUserException userException,
    2: EDAMSystemException systemException,
  )
  list<LinkedNotebook> listLinkedNotebooks(
    1: string authenticationToken,
  ) throws (
    1: EDAMUserException userException,
    2: EDAMSystemException systemException,
  )
  AuthenticationResult authenticateToSharedNotebook(
    1: string shareKey,
    2: string authenticationToken,
  ) throws (
    1: EDAMUserException userException,
    2: EDAMSystemException systemException,
    3: EDAMNotFoundException notFoundException,
  )
  SharedNotebook getSharedNotebookByAuth(
    1: string authenticationToken,
  ) throws (
    1: EDAMUserException userException,
    2: EDAMSystemException systemException,
    3: EDAMNotFoundException notFoundException,
  )
  NotesMetadataList findNotesMetadata(
    1: string authenticationToken,
    2: NoteFilter filter,
    3: i32 offset,
    4: i32 maxNotes,
    5: NotesMetadataResultSpec resultSpec,
  ) throws (
    1: EDAMUserException userException,
    2: EDAMSystemException systemException,
    3: EDAMNotFoundException notFoundException,
  )
  Note getNote(
    1: string authenticationToken,
    2: string guid,
    3: bool withContent,
    4: bool withResourcesData,
    5: bool withResourcesRecognition,
    6: bool withResourcesAlternateData,
  ) throws (
    1: EDAMUserException userException,
    2: EDAMSystemException systemException,
    3: EDAMNotFoundException notFoundException,
  )
}
"""

EVERNOTE_THRIFT = thriftpy2.load_fp(StringIO(THRIFT_IDL), "evernote_web_session_thrift")


class _RequestsThriftHttpTransport:
    def __init__(self, url: str, timeout_seconds: int):
        self.url = url
        self.timeout_seconds = timeout_seconds
        self._write_buffer = BytesIO()
        self._read_buffer = BytesIO()
        self._is_open = False

    def open(self) -> None:
        self._is_open = True

    def close(self) -> None:
        self._is_open = False
        self._write_buffer = BytesIO()
        self._read_buffer = BytesIO()

    def is_open(self) -> bool:
        return self._is_open

    def read(self, size: int) -> bytes:
        return self._read_buffer.read(size)

    def write(self, data: bytes) -> None:
        self._write_buffer.write(data)

    def flush(self) -> None:
        payload = self._write_buffer.getvalue()
        self._write_buffer = BytesIO()

        # This guard exists because buffered transports can flush during setup before any method call has been written.
        if not payload:
            return

        response = requests.post(
            self.url,
            data=payload,
            headers={
                "Content-Type": "application/x-thrift",
                "Accept": "application/x-thrift",
            },
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        self._read_buffer = BytesIO(response.content)


def make_note_store_client(url: str, timeout_seconds: int) -> TClient:
    """Create a NoteStore Thrift client backed by the HTTP transport in this module."""
    transport = TBufferedTransportFactory().get_transport(
        _RequestsThriftHttpTransport(url, timeout_seconds)
    )
    transport.open()
    protocol = TBinaryProtocolFactory().get_protocol(transport)
    return TClient(EVERNOTE_THRIFT.NoteStore, protocol)
