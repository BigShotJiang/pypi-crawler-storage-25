from __future__ import annotations

import json
import threading
import time
import warnings
from pathlib import Path
from typing import Any, Optional, TypedDict, cast

from .auth import DEFAULT_AUTH_PATH, SavedAuth, _normalize_monolith_token
from .enml import enml_to_text
from .thirft import EVERNOTE_THRIFT, make_note_store_client

DEFAULT_TIMEOUT_SECONDS = 30
NOTE_SORT_ORDER_UPDATED = 2
LATEST_NOTES_PAGE_SIZE = 100


class EvernoteServiceError(RuntimeError):
    pass


class EvernoteAuthError(EvernoteServiceError):
    pass


class EvernoteRateLimitError(EvernoteServiceError):
    pass


class NotebookDict(TypedDict, total=False):
    id: str
    guid: str
    name: str
    updateSequenceNum: int
    defaultNotebook: bool
    serviceCreated: int
    serviceUpdated: int
    stack: str
    workspaceGuid: str
    inWorkspace: bool
    source: str
    sharedWithMe: bool
    shareName: str
    ownerUsername: str
    ownerShardId: str
    shareKey: str
    noteStoreUrl: str
    webApiUrlPrefix: str
    businessId: int


class NoteMetadataDict(TypedDict, total=False):
    id: str
    guid: str
    title: str
    contentLength: int
    created: int
    updated: int
    deleted: int
    updateSequenceNum: int
    notebookGuid: str
    tagGuids: list[str]
    source: str
    sharedWithMe: bool
    shareKey: str
    noteStoreUrl: str
    webApiUrlPrefix: str
    ownerUsername: str
    linkedNotebookName: str


class NoteDict(NoteMetadataDict, total=False):
    content: str
    content_text: str


_auth_path = Path(DEFAULT_AUTH_PATH).expanduser()

if not _auth_path.exists():
    raise RuntimeError(
        "Run `evernote login` first so ~/.sloppynotes/evernote-auth.json exists."
    )

_notebooks_cache_path = _auth_path.parent / "notebooks-cache.json"
_notebooks_cache_ttl_seconds = 180
_note_route_cache_path = _auth_path.parent / "note-route-cache.json"
_note_route_cache_ttl_seconds = 86400
_linked_session_cache_ttl_seconds = 600
_linked_notebook_session_cache: dict[str, tuple[float, str, str, str]] = {}
# These locks exist because linked-note helpers may be called from concurrent code paths in the future,
# and the caches below mutate shared in-process state and read/write the same JSON route cache file.
_linked_notebook_session_cache_lock = threading.Lock()
_note_route_cache_lock = threading.RLock()


def _get_saved_auth() -> SavedAuth:
    if not _auth_path.exists():
        raise RuntimeError(
            "Run `evernote login` first so ~/.sloppynotes/evernote-auth.json exists."
        )

    saved_auth = SavedAuth.from_file(_auth_path)
    saved_auth.monolith_token = _normalize_monolith_token(saved_auth.monolith_token)
    return saved_auth


def _raise_evernote_service_error(exc: Exception) -> None:
    user_exception_type = getattr(EVERNOTE_THRIFT, "EDAMUserException", None)
    system_exception_type = getattr(EVERNOTE_THRIFT, "EDAMSystemException", None)
    not_found_exception_type = getattr(EVERNOTE_THRIFT, "EDAMNotFoundException", None)
    error_names = getattr(EVERNOTE_THRIFT.EDAMErrorCode, "_VALUES_TO_NAMES", {})

    if user_exception_type and isinstance(exc, user_exception_type):
        code_name = error_names.get(getattr(exc, "errorCode", None), "UNKNOWN")
        parameter = getattr(exc, "parameter", None)
        if code_name in {"AUTH_EXPIRED", "INVALID_AUTH"}:
            detail = f" (parameter={parameter})" if parameter else ""
            raise EvernoteAuthError(
                "Evernote authentication has expired or is invalid"
                f" [{code_name}]{detail}. Run `evernote login` again."
            ) from exc

        detail = f" (parameter={parameter})" if parameter else ""
        raise EvernoteServiceError(
            f"Evernote request failed with {code_name}{detail}."
        ) from exc

    if system_exception_type and isinstance(exc, system_exception_type):
        code_name = error_names.get(getattr(exc, "errorCode", None), "UNKNOWN")
        message = getattr(exc, "message", None)
        rate_limit_duration = getattr(exc, "rateLimitDuration", None)
        if code_name == "RATE_LIMIT_REACHED":
            suffix = (
                f" Retry after about {rate_limit_duration} seconds."
                if isinstance(rate_limit_duration, int)
                else ""
            )
            raise EvernoteRateLimitError(
                f"Evernote rate limit reached.{suffix}"
            ) from exc

        message_suffix = f" {message}" if message else ""
        raise EvernoteServiceError(
            f"Evernote system error [{code_name}].{message_suffix}"
        ) from exc

    if not_found_exception_type and isinstance(exc, not_found_exception_type):
        identifier = getattr(exc, "identifier", None)
        key = getattr(exc, "key", None)
        details = ", ".join(
            part
            for part in [
                f"identifier={identifier}" if identifier else "",
                f"key={key}" if key else "",
            ]
            if part
        )
        suffix = f" ({details})" if details else ""
        raise EvernoteServiceError(f"Evernote object was not found{suffix}.") from exc

    raise exc


def get_notebooks() -> list[NotebookDict]:
    saved_auth = _get_saved_auth()
    cached = _load_notebooks_cache(saved_auth)
    if cached is not None:
        return cached

    client = make_note_store_client(
        f"{saved_auth.service_base_url}/shard/{saved_auth.shard}/notestore",
        DEFAULT_TIMEOUT_SECONDS,
    )
    try:
        notebooks = client.listNotebooks(saved_auth.monolith_token)
        linked_notebooks = client.listLinkedNotebooks(saved_auth.monolith_token)
    except Exception as exc:
        _raise_evernote_service_error(exc)
    finally:
        client.close()

    owned_result = [_struct_to_dict(notebook) for notebook in notebooks]
    linked_result = [
        _linked_notebook_to_dict(notebook) for notebook in linked_notebooks
    ]

    notebooks_result = cast(list[NotebookDict], owned_result + linked_result)
    _save_notebooks_cache(saved_auth, notebooks_result)
    return notebooks_result


def search_notes(
    query: str, n: int = 10, notebook: Optional[NotebookDict] = None
) -> list[NoteMetadataDict]:
    needle = query.strip()

    # This guard exists because Evernote search should receive a real query string.
    if not needle:
        raise ValueError("query must be a non-empty string")

    results = _find_notes(query=needle, n=n, notebook=notebook)
    if notebook is None:
        _warn_about_linked_search_scope(results, _get_linked_notebooks())

    return results


def get_notes(notebook: NotebookDict, n: int = 10) -> list[NoteMetadataDict]:
    return _find_notes(query=None, n=n, notebook=notebook)


def get_latest_notes(days: int) -> list[NoteMetadataDict]:
    if not isinstance(days, int) or isinstance(days, bool) or days < 1:
        raise ValueError("days must be a positive integer")

    # The Evernote Notes UI's Updated filter maps to the search syntax updated:day-N.
    query = f"updated:day-{days}"
    return _find_notes(query=query, n=LATEST_NOTES_PAGE_SIZE, notebook=None)


def get_note(note_id: str | NoteMetadataDict | NoteDict) -> NoteDict:
    normalized_note_id = note_id

    # This guard exists because callers may pass note objects returned by get_notes().
    if isinstance(note_id, dict):
        guid = note_id.get("guid") or note_id.get("id")
        if not guid:
            raise ValueError("Note objects must include guid or id.")
        normalized_note_id = str(guid)

    saved_auth = _get_saved_auth()

    if isinstance(note_id, dict) and _is_linked_note(note_id):
        shared_auth_token, note_store_url, _ = _get_linked_notebook_session(
            cast(NotebookDict, note_id), saved_auth
        )
        client = make_note_store_client(note_store_url, DEFAULT_TIMEOUT_SECONDS)
        try:
            note = client.getNote(
                shared_auth_token,
                str(normalized_note_id),
                True,
                False,
                False,
                False,
            )
        except Exception as exc:
            _raise_evernote_service_error(exc)
        finally:
            client.close()

        result = cast(NoteDict, _struct_to_dict(note))
        result = _annotate_linked_note(
            result, cast(NoteMetadataDict, note_id), note_store_url
        )
        result["content_text"] = enml_to_text(result.get("content", ""))
        return result

    if isinstance(note_id, str):
        linked_route = _load_note_route(saved_auth, note_id)
        if linked_route is not None:
            shared_auth_token, note_store_url, _ = _get_linked_notebook_session(
                linked_route, saved_auth
            )
            client = make_note_store_client(note_store_url, DEFAULT_TIMEOUT_SECONDS)
            try:
                note = client.getNote(
                    shared_auth_token,
                    note_id,
                    True,
                    False,
                    False,
                    False,
                )
            except Exception:
                client.close()
            else:
                client.close()
                result = cast(NoteDict, _struct_to_dict(note))
                result = _annotate_linked_note(result, linked_route, note_store_url)
                result["content_text"] = enml_to_text(result.get("content", ""))
                return result

    client = make_note_store_client(
        f"{saved_auth.service_base_url}/shard/{saved_auth.shard}/notestore",
        DEFAULT_TIMEOUT_SECONDS,
    )
    try:
        note = client.getNote(
            saved_auth.monolith_token,
            str(normalized_note_id),
            True,
            False,
            False,
            False,
        )
    except Exception as exc:
        _raise_evernote_service_error(exc)
    finally:
        client.close()

    result = cast(NoteDict, _struct_to_dict(note))
    result["content_text"] = enml_to_text(result.get("content", ""))
    return result


def _is_linked_notebook(notebook: Optional[NotebookDict]) -> bool:
    if notebook is None:
        return False

    return bool(
        notebook.get("source") == "linked"
        or notebook.get("sharedWithMe")
        or notebook.get("shareKey")
    )


def _is_linked_note(note: NoteMetadataDict | NoteDict) -> bool:
    return bool(
        note.get("source") == "linked"
        or note.get("sharedWithMe")
        or note.get("shareKey")
    )


def _linked_notebook_to_dict(linked_notebook: Any) -> NotebookDict:
    payload = cast(dict[str, Any], _struct_to_dict(linked_notebook))
    name = cast(
        Optional[str],
        payload.get("shareName") or payload.get("username") or payload.get("shareKey"),
    )

    result: NotebookDict = {
        "name": str(name or "Shared notebook"),
        "source": "linked",
        "sharedWithMe": True,
    }

    if payload.get("shareName"):
        result["shareName"] = cast(str, payload["shareName"])
    if payload.get("username"):
        result["ownerUsername"] = cast(str, payload["username"])
    if payload.get("shardId"):
        result["ownerShardId"] = cast(str, payload["shardId"])
    if payload.get("shareKey"):
        result["shareKey"] = cast(str, payload["shareKey"])
    if payload.get("noteStoreUrl"):
        result["noteStoreUrl"] = cast(str, payload["noteStoreUrl"])
    if payload.get("webApiUrlPrefix"):
        result["webApiUrlPrefix"] = cast(str, payload["webApiUrlPrefix"])
    if payload.get("stack"):
        result["stack"] = cast(str, payload["stack"])
    if payload.get("businessId") is not None:
        result["businessId"] = cast(int, payload["businessId"])
    if payload.get("updateSequenceNum") is not None:
        result["updateSequenceNum"] = cast(int, payload["updateSequenceNum"])

    return result


def _get_linked_notebook_session(
    notebook: NotebookDict, saved_auth: SavedAuth
) -> tuple[str, str, str]:
    cached_session = _load_cached_linked_notebook_session(notebook)
    if cached_session is not None:
        return cached_session

    share_key = notebook.get("shareKey")
    note_store_url = notebook.get("noteStoreUrl")

    if not share_key or not note_store_url:
        raise EvernoteServiceError(
            "Linked notebook metadata is missing shareKey or noteStoreUrl."
        )

    client = make_note_store_client(note_store_url, DEFAULT_TIMEOUT_SECONDS)
    try:
        auth_result = client.authenticateToSharedNotebook(
            share_key, saved_auth.monolith_token
        )
        shared_auth_token = getattr(auth_result, "authenticationToken", None)
        resolved_note_store_url = (
            getattr(auth_result, "noteStoreUrl", None) or note_store_url
        )
        shared_notebook = client.getSharedNotebookByAuth(shared_auth_token)
        notebook_guid = getattr(shared_notebook, "notebookGuid", None)
    except Exception as exc:
        _raise_evernote_service_error(exc)
    finally:
        client.close()

    if not shared_auth_token:
        raise EvernoteServiceError(
            "Evernote did not return a shared notebook authentication token."
        )

    if not notebook_guid:
        raise EvernoteServiceError("Evernote did not return the shared notebook GUID.")

    _remember_linked_notebook_session(
        notebook,
        str(shared_auth_token),
        str(resolved_note_store_url),
        str(notebook_guid),
    )
    return str(shared_auth_token), str(resolved_note_store_url), str(notebook_guid)


def _annotate_linked_note(
    note_payload: NoteMetadataDict | NoteDict,
    notebook: NotebookDict | NoteMetadataDict,
    note_store_url: str,
) -> NoteMetadataDict | NoteDict:
    note_payload["source"] = "linked"
    note_payload["sharedWithMe"] = True
    note_payload["noteStoreUrl"] = note_store_url

    for source_key, target_key in [
        ("shareKey", "shareKey"),
        ("webApiUrlPrefix", "webApiUrlPrefix"),
        ("ownerUsername", "ownerUsername"),
    ]:
        value = notebook.get(source_key)
        if value:
            note_payload[target_key] = cast(str, value)

    notebook_name = notebook.get("name") or notebook.get("linkedNotebookName")
    if notebook_name:
        note_payload["linkedNotebookName"] = cast(str, notebook_name)

    _remember_note_route(note_payload)
    return note_payload


def _get_linked_notebooks() -> list[NotebookDict]:
    return [notebook for notebook in get_notebooks() if _is_linked_notebook(notebook)]


def _warn_about_linked_search_scope(
    results: list[NoteMetadataDict], linked_notebooks: list[NotebookDict]
) -> None:
    if results or not linked_notebooks:
        return

    warnings.warn(
        "search_notes() does not search linked/shared notebooks unless you pass "
        "notebook=... explicitly. Use get_notebooks() to pick a linked notebook first.",
        stacklevel=2,
    )


def _linked_notebook_cache_key(notebook: NotebookDict) -> Optional[str]:
    share_key = notebook.get("shareKey")
    note_store_url = notebook.get("noteStoreUrl")
    if not share_key or not note_store_url:
        return None

    return f"{share_key}|{note_store_url}"


def _remember_linked_notebook_session(
    notebook: NotebookDict,
    shared_auth_token: str,
    note_store_url: str,
    notebook_guid: str,
) -> None:
    cache_key = _linked_notebook_cache_key(notebook)
    if not cache_key:
        return

    with _linked_notebook_session_cache_lock:
        _linked_notebook_session_cache[cache_key] = (
            time.time(),
            shared_auth_token,
            note_store_url,
            notebook_guid,
        )


def _load_cached_linked_notebook_session(
    notebook: NotebookDict,
) -> Optional[tuple[str, str, str]]:
    cache_key = _linked_notebook_cache_key(notebook)
    if not cache_key:
        return None

    with _linked_notebook_session_cache_lock:
        cached = _linked_notebook_session_cache.get(cache_key)
        if cached is None:
            return None

        saved_at, shared_auth_token, note_store_url, notebook_guid = cached
        if time.time() - saved_at > _linked_session_cache_ttl_seconds:
            _linked_notebook_session_cache.pop(cache_key, None)
            return None

    return shared_auth_token, note_store_url, notebook_guid


def _load_note_route_payload(saved_auth: SavedAuth) -> Optional[dict[str, Any]]:
    if not _note_route_cache_path.exists():
        return None

    with _note_route_cache_lock:
        try:
            payload = json.loads(_note_route_cache_path.read_text())
        except (json.JSONDecodeError, OSError):
            return None

    saved_at = payload.get("saved_at")
    if (
        not isinstance(saved_at, (int, float))
        or time.time() - float(saved_at) > _note_route_cache_ttl_seconds
    ):
        return None

    if (
        payload.get("service_base_url") != saved_auth.service_base_url
        or payload.get("shard") != saved_auth.shard
    ):
        return None

    routes = payload.get("routes")
    if not isinstance(routes, dict):
        return None

    return payload


def _load_note_route(saved_auth: SavedAuth, note_guid: str) -> Optional[NotebookDict]:
    payload = _load_note_route_payload(saved_auth)
    if payload is None:
        return None

    route = payload.get("routes", {}).get(note_guid)
    if not isinstance(route, dict):
        return None

    return cast(NotebookDict, route)


def _remember_note_route(note_payload: NoteMetadataDict | NoteDict) -> None:
    note_guid = cast(Optional[str], note_payload.get("guid") or note_payload.get("id"))
    share_key = note_payload.get("shareKey")
    note_store_url = note_payload.get("noteStoreUrl")
    if not note_guid or not share_key or not note_store_url:
        return

    saved_auth = _get_saved_auth()
    with _note_route_cache_lock:
        payload = _load_note_route_payload(saved_auth) or {
            "service_base_url": saved_auth.service_base_url,
            "shard": saved_auth.shard,
            "routes": {},
        }

        routes = cast(dict[str, Any], payload.setdefault("routes", {}))
        routes[note_guid] = {
            "source": "linked",
            "sharedWithMe": True,
            "shareKey": share_key,
            "noteStoreUrl": note_store_url,
            "webApiUrlPrefix": note_payload.get("webApiUrlPrefix"),
            "ownerUsername": note_payload.get("ownerUsername"),
            "name": note_payload.get("linkedNotebookName"),
        }
        payload["saved_at"] = time.time()
        _note_route_cache_path.parent.mkdir(parents=True, exist_ok=True)
        _note_route_cache_path.write_text(json.dumps(payload, indent=2))


def _find_notes(
    query: Optional[str], n: int, notebook: Optional[NotebookDict]
) -> list[NoteMetadataDict]:
    result_spec = _make_notes_metadata_result_spec()
    saved_auth = _get_saved_auth()

    if _is_linked_notebook(notebook):
        linked_notebook = cast(NotebookDict, notebook)
        shared_auth_token, note_store_url, notebook_guid = _get_linked_notebook_session(
            linked_notebook, saved_auth
        )
        note_filter = EVERNOTE_THRIFT.NoteFilter(
            order=NOTE_SORT_ORDER_UPDATED,
            ascending=False,
            words=query,
            notebookGuid=notebook_guid,
        )
        client = make_note_store_client(note_store_url, DEFAULT_TIMEOUT_SECONDS)
        try:
            notes = client.findNotesMetadata(
                shared_auth_token, note_filter, 0, n, result_spec
            )
        except Exception as exc:
            _raise_evernote_service_error(exc)
        finally:
            client.close()

        return cast(
            list[NoteMetadataDict],
            [
                cast(
                    NoteMetadataDict,
                    _annotate_linked_note(
                        cast(NoteMetadataDict, _struct_to_dict(note)),
                        linked_notebook,
                        note_store_url,
                    ),
                )
                for note in notes.notes or []
            ],
        )

    notebook_guid = _resolve_notebook_guid(notebook)
    note_filter = EVERNOTE_THRIFT.NoteFilter(
        order=NOTE_SORT_ORDER_UPDATED,
        ascending=False,
        words=query,
        notebookGuid=notebook_guid,
    )
    client = make_note_store_client(
        f"{saved_auth.service_base_url}/shard/{saved_auth.shard}/notestore",
        DEFAULT_TIMEOUT_SECONDS,
    )
    try:
        notes = client.findNotesMetadata(
            saved_auth.monolith_token, note_filter, 0, n, result_spec
        )
    except Exception as exc:
        _raise_evernote_service_error(exc)
    finally:
        client.close()

    return cast(
        list[NoteMetadataDict], [_struct_to_dict(note) for note in notes.notes or []]
    )


def _resolve_notebook_guid(notebook: Optional[NotebookDict]) -> Optional[str]:
    """Resolve a notebook input into the notebook GUID used by NoteStore calls."""
    # This guard exists because notebook filtering is optional for search_notes() and get_latest_notes().
    if notebook is None:
        return None

    return cast(Optional[str], notebook.get("guid") or notebook.get("id"))


def _load_notebooks_cache(saved_auth: SavedAuth) -> Optional[list[NotebookDict]]:
    # This guard exists because the cache file is created lazily after the first notebook lookup.
    if not _notebooks_cache_path.exists():
        return None

    try:
        payload = json.loads(_notebooks_cache_path.read_text())
    except (json.JSONDecodeError, OSError):
        # This guard exists because a partial or corrupted cache file should not break notebook reads.
        return None

    saved_at = payload.get("saved_at")
    # This guard exists because the filesystem cache is only meant to survive for a few minutes.
    if (
        not isinstance(saved_at, (int, float))
        or time.time() - float(saved_at) > _notebooks_cache_ttl_seconds
    ):
        return None

    # This guard exists because notebook caches should not leak across different Evernote shards or service URLs.
    if (
        payload.get("service_base_url") != saved_auth.service_base_url
        or payload.get("shard") != saved_auth.shard
    ):
        return None

    notebooks = payload.get("notebooks")
    # This guard exists because cache files should only hydrate the exact notebook list shape we expect.
    if not isinstance(notebooks, list):
        return None

    return cast(list[NotebookDict], notebooks)


def _save_notebooks_cache(saved_auth: SavedAuth, notebooks: list[NotebookDict]) -> None:
    payload = {
        "saved_at": time.time(),
        "service_base_url": saved_auth.service_base_url,
        "shard": saved_auth.shard,
        "notebooks": notebooks,
    }
    _notebooks_cache_path.parent.mkdir(parents=True, exist_ok=True)
    _notebooks_cache_path.write_text(json.dumps(payload, indent=2))


def _make_notes_metadata_result_spec():
    return EVERNOTE_THRIFT.NotesMetadataResultSpec(
        includeTitle=True,
        includeContentLength=True,
        includeCreated=True,
        includeUpdated=True,
        includeDeleted=True,
        includeUpdateSequenceNum=True,
        includeNotebookGuid=True,
        includeTagGuids=True,
    )


def _struct_to_dict(value: Any) -> Any:
    # This guard exists because scalars should pass through unchanged.
    if value is None or isinstance(value, (str, int, float, bool, bytes)):
        return value

    # This guard exists because Thrift lists should come back as plain Python lists.
    if isinstance(value, list):
        return [_struct_to_dict(item) for item in value]

    # This guard exists because thriftpy2 structs expose their fields via thrift_spec.
    thrift_spec = getattr(value.__class__, "thrift_spec", None)
    if thrift_spec:
        result: dict[str, Any] = {}
        for _, spec in thrift_spec.items():
            # This guard exists because thrift_spec contains an internal STOP marker at key 0 in some builds.
            if spec is None:
                continue
            field_name = spec[1]
            field_value = getattr(value, field_name, None)
            # This guard exists because optional Evernote fields are often absent, and keeping None everywhere adds noise.
            if field_value is None:
                continue
            result[field_name] = _struct_to_dict(field_value)

        # This guard exists because Evernote uses GUIDs internally, but a plain id key is more ergonomic for callers.
        if "guid" in result and "id" not in result:
            result["id"] = result["guid"]
        return result

    return value
