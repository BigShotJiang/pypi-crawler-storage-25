from __future__ import annotations

import json
import os
import re
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests
from playwright.sync_api import sync_playwright


DEFAULT_STATE_DIR = Path.home() / ".sloppynotes"
DEFAULT_AUTH_PATH = DEFAULT_STATE_DIR / "evernote-auth.json"
DEFAULT_PROFILE_DIR = DEFAULT_STATE_DIR / "browser-profile"
DEFAULT_CDP_PORT = 9222
DEFAULT_CDP_CONNECT_TIMEOUT_MS = 15_000
DEFAULT_SERVICE_BASE_URL = "https://www.evernote.com"
DEFAULT_CDP_HOST = "127.0.0.1"


@dataclass
class SavedAuth:
    monolith_token: str
    shard: str
    service_base_url: str = DEFAULT_SERVICE_BASE_URL

    @classmethod
    def from_file(cls, auth_path: str | Path = DEFAULT_AUTH_PATH) -> "SavedAuth":
        payload = json.loads(Path(auth_path).read_text())
        return cls(
            monolith_token=_normalize_monolith_token(payload["monolith_token"]),
            shard=payload["shard"],
            service_base_url=payload.get("service_base_url", DEFAULT_SERVICE_BASE_URL),
        )

    def save(self, auth_path: str | Path = DEFAULT_AUTH_PATH) -> Path:
        auth_file = Path(auth_path)
        auth_file.parent.mkdir(parents=True, exist_ok=True)
        auth_file.write_text(
            json.dumps(
                {
                    "version": 1,
                    "source": "browser_cookie",
                    "service_base_url": self.service_base_url,
                    "monolith_token": self.monolith_token,
                    "shard": self.shard,
                    "saved_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                },
                indent=2,
            )
        )
        return auth_file


def login_via_browser(
    auth_path: str | Path = DEFAULT_AUTH_PATH,
    profile_dir: str | Path = DEFAULT_PROFILE_DIR,
    browser_path: Optional[str] = None,
    cdp_host: str = DEFAULT_CDP_HOST,
    cdp_port: int = DEFAULT_CDP_PORT,
    service_base_url: str = DEFAULT_SERVICE_BASE_URL,
    launch_browser: bool = True,
    cdp_connect_timeout_ms: int = DEFAULT_CDP_CONNECT_TIMEOUT_MS,
) -> tuple[bool, str]:
    cdp_url = f"http://{cdp_host}:{cdp_port}"

    # This guard exists because we only need to launch when CDP is not already available.
    if not _cdp_is_ready(cdp_url):
        # This guard exists because --use-existing-browser must not create a separate login profile.
        if not launch_browser:
            return False, (
                f"No existing CDP browser found at {cdp_url}. "
                "Start `faltoobot browser https://www.evernote.com/client/web` "
                "and log in to Evernote there, then run `evernote login --use-existing-browser` again."
            )

        executable = browser_path or _find_browser_executable()

        # This guard exists because login cannot proceed without a CDP-capable browser binary.
        if not executable:
            return False, (
                "Could not find a CDP-capable browser. Install Chrome/Chromium or pass --browser-path."
            )

        profile_path = Path(profile_dir)
        profile_path.mkdir(parents=True, exist_ok=True)
        _launch_browser(executable, profile_path, cdp_port, service_base_url)
        if not _wait_for_cdp(cdp_url, timeout_seconds=10):
            return False, "Started the browser, but CDP did not become ready in time."

    with sync_playwright() as playwright:
        try:
            browser = playwright.chromium.connect_over_cdp(
                cdp_url, timeout=cdp_connect_timeout_ms
            )
        except TypeError:
            # Backward compatibility for older Playwright versions that may not
            # accept the timeout keyword.
            browser = playwright.chromium.connect_over_cdp(cdp_url)
        try:
            # This guard exists because a persistent CDP browser normally exposes exactly one context.
            if not browser.contexts:
                return (
                    False,
                    "Connected to the browser, but no persistent context was available.",
                )

            context = browser.contexts[0]
            _ensure_evernote_page(context, service_base_url)
            auth_cookie = _get_auth_cookie(context, service_base_url)

            # This guard exists because the browser may be open before the user completes the Evernote login flow.
            if not auth_cookie:
                return False, (
                    "Browser is open but Evernote is not logged in yet. "
                    "Log in in the opened browser and run `evernote login` again."
                )

            monolith_token = _normalize_monolith_token(auth_cookie["value"])
            saved_auth = SavedAuth(
                monolith_token=monolith_token,
                shard=_extract_shard(monolith_token),
                service_base_url=service_base_url,
            )
            saved_path = saved_auth.save(auth_path)
            return True, f"Saved Evernote authentication to {saved_path}"
        finally:
            # We intentionally do not call browser.close() here because that would close the user-visible browser.
            pass


def _find_browser_executable() -> Optional[str]:
    env_browser = os.environ.get("EVERNOTE_BROWSER_PATH")

    # This guard exists because users may want to override browser discovery explicitly.
    if env_browser and Path(env_browser).exists():
        return env_browser

    candidates = [
        "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
        "/Applications/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
        "/Applications/Chromium.app/Contents/MacOS/Chromium",
        "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
        shutil_which("google-chrome"),
        shutil_which("chromium"),
        shutil_which("chromium-browser"),
        shutil_which("msedge"),
        shutil_which("brave"),
    ]

    for candidate in candidates:
        # This guard exists because some discovery methods return None when a browser is not installed.
        if candidate and Path(candidate).exists():
            return candidate

    with sync_playwright() as playwright:
        bundled = playwright.chromium.executable_path
        # This guard exists because Playwright may know a path even when the browser payload is not installed.
        if bundled and Path(bundled).exists():
            return bundled

    return None


def _launch_browser(
    browser_path: str, profile_dir: Path, cdp_port: int, service_base_url: str
) -> None:
    subprocess.Popen(
        [
            browser_path,
            f"--remote-debugging-port={cdp_port}",
            f"--user-data-dir={profile_dir}",
            "--no-first-run",
            "--no-default-browser-check",
            f"{service_base_url}/client/web",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,
    )


def _cdp_is_ready(cdp_url: str) -> bool:
    try:
        response = requests.get(f"{cdp_url}/json/version", timeout=2)
        return response.ok
    except requests.RequestException:
        return False


def _wait_for_cdp(cdp_url: str, timeout_seconds: int) -> bool:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        if _cdp_is_ready(cdp_url):
            return True
        time.sleep(0.5)
    return False


def _ensure_evernote_page(context, service_base_url: str) -> None:
    for page in context.pages:
        # This guard exists because the user may already have Evernote open in the managed browser.
        if page.url.startswith(service_base_url):
            return

    page = context.new_page()
    try:
        page.goto(
            f"{service_base_url}/client/web",
            wait_until="domcontentloaded",
            timeout=15_000,
        )
    except Exception:
        # This guard exists because the Evernote page can redirect during auth, and cookie inspection still works without a clean goto.
        pass


def _normalize_monolith_token(monolith_token: str) -> str:
    token = (monolith_token or "").strip()

    # This guard exists because some browser cookie APIs return quoted cookie values.
    if len(token) >= 2 and token[0] == token[-1] and token[0] in {'"', "'"}:
        token = token[1:-1]

    return token


def _get_auth_cookie(context, service_base_url: str) -> Optional[dict]:
    cookies = context.cookies([service_base_url])
    for cookie in cookies:
        # This guard exists because we only need the monolith auth cookie; all other cookies are irrelevant here.
        if cookie.get("name") == "auth":
            return cookie
    return None


def _extract_shard(monolith_token: str) -> str:
    monolith_token = _normalize_monolith_token(monolith_token)
    match = re.search(r"(?:^|:)S=(s\d+)(?:$|:)", monolith_token)

    # This guard exists because NoteStore URLs are shard-specific, so the saved auth must include a shard.
    if not match:
        raise ValueError("Could not extract the shard from the auth cookie.")
    return match.group(1)


def shutil_which(name: str) -> Optional[str]:
    from shutil import which

    return which(name)
