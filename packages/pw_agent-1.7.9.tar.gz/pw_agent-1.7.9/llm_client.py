"""LLM client — talks to Ollama via PastaWater broker or directly to a brain."""

import json
import requests
from typing import Iterator


DEFAULT_API_URL = "https://pastawater.io"


class LLMClient:
    """Client that talks to Ollama via PastaWater broker API or direct brain connection."""

    def __init__(
        self,
        token: str = "",
        device_id: str = "",
        slot: int = 0,
        model: str = "",
        api_url: str = DEFAULT_API_URL,
        brain_url: str = "",
        brain_key: str = "",
    ):
        self.token = token
        self.device_id = device_id
        self.slot = slot
        self.model = model
        self.api_url = api_url.rstrip("/")
        self.brain_url = brain_url.rstrip("/") if brain_url else ""
        self.brain_key = brain_key
        self.direct_mode = bool(brain_url)

        self.session = requests.Session()
        self.session.headers["Content-Type"] = "application/json"
        # Auth: PW token works for both cloud API and local brain proxy
        if token:
            self.session.headers["Authorization"] = f"Bearer {token}"
        if brain_key:
            self.session.headers["X-Controller-API-Key"] = brain_key

    def chat(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192) -> str:
        """Send messages and return the full response text."""
        chunks = []
        for chunk in self.chat_stream(messages, temperature, context_length):
            chunks.append(chunk)
        return "".join(chunks)

    def chat_stream(self, messages: list[dict], temperature: float = 0.3, context_length: int = 8192) -> Iterator[str]:
        """Stream chat tokens from Ollama."""
        if self.direct_mode:
            yield from self._stream_direct(messages, temperature, context_length)
        else:
            yield from self._stream_broker(messages, temperature, context_length)

    def _stream_direct(self, messages: list[dict], temperature: float, context_length: int) -> Iterator[str]:
        """Stream directly from brain's Ollama endpoint."""
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": temperature,
                "num_ctx": context_length,
            },
        }

        try:
            resp = self.session.post(
                f"{self.brain_url}/api/chat",
                json=payload,
                stream=True,
                timeout=300,
            )
        except requests.exceptions.ConnectionError:
            yield f"[Error: Could not connect to brain at {self.brain_url}]"
            return
        except requests.exceptions.Timeout:
            yield "[Error: Request timed out]"
            return

        if resp.status_code != 200:
            yield f"[Error: Brain returned {resp.status_code}]"
            return

        for line in resp.iter_lines():
            if not line:
                continue
            try:
                data = json.loads(line)
                content = data.get("message", {}).get("content", "")
                if content:
                    yield content
                if data.get("done"):
                    return
            except json.JSONDecodeError:
                continue

    def _flatten_messages(self, messages: list[dict]) -> str:
        """Flatten chat messages into a single prompt string for the llm model."""
        parts = []
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if role == "system":
                parts.append(f"<|system|>\n{content}")
            elif role == "assistant":
                parts.append(f"<|assistant|>\n{content}")
            else:
                parts.append(f"<|user|>\n{content}")
        parts.append("<|assistant|>")
        return "\n".join(parts)

    def _stream_broker(self, messages: list[dict], temperature: float, context_length: int) -> Iterator[str]:
        """Submit task asynchronously and poll for completion to avoid EOF/timeouts."""
        import time
        
        # Flatten messages to a raw prompt to bypass Ollama's tool-parsing bugs in /api/chat
        raw_prompt = self._flatten_messages(messages)

        payload = {
            "model": "llm",
            "slot": self.slot,
            "prompt": raw_prompt, # Brain uses this for /api/generate
            # "messages": messages, # EXPLICITLY OMITTED to trigger raw generation mode
            "llm_model": self.model,
            "temperature": temperature,
            "max_tokens": min(context_length, 4096),
            "context_length": context_length,
        }

        # 1. Submit the task asynchronously
        try:
            resp = self.session.post(
                f"{self.api_url}/api/v1/playground/generate/async",
                json=payload,
                timeout=30,
            )
            if resp.status_code != 202 and resp.status_code != 200:
                yield f"[Error: API returned {resp.status_code}: {resp.text[:200]}]"
                return

            data = resp.json()
            if not data.get("success"):
                yield f"[Error: {data.get('error', 'Submission failed')}]"
                return

            task_id = data.get("task_id")
            if not task_id:
                yield "[Error: No task_id returned from broker]"
                return

        except Exception as e:
            yield f"[Error: Failed to submit task: {str(e)}]"
            return

        # 2. Poll for result
        # Most LLM tasks take 5-60s. We'll poll every 1-2s.
        max_wait = 300 # 5 minutes
        start_time = time.time()

        # Add a subtle indicator that we are polling
        import sys

        while time.time() - start_time < max_wait:
            try:
                # Use a fresh request for polling to avoid session stickiness issues
                poll_resp = self.session.get(
                    f"{self.api_url}/api/v1/playground/tasks/{task_id}",
                    timeout=10
                )
                if poll_resp.status_code == 200:
                    poll_data = poll_resp.json()
                    status = poll_data.get("status")

                    if status == "completed":
                        result = poll_data.get("result", {})
                        text = result.get("text", "") or result.get("response", "") or ""
                        yield text
                        return

                    if status == "failed":
                        err = poll_data.get("error", "Generation failed")
                        yield f"[Error: {err}]"
                        return

                elif poll_resp.status_code != 404: 
                    # If we get a 500 or other error during polling, report it
                    try:
                        err_data = poll_resp.json()
                        err_msg = err_data.get("error", f"Status {poll_resp.status_code}")
                    except:
                        err_msg = f"Status {poll_resp.status_code}"
                    yield f"[Error: Polling failed: {err_msg}]"
                    return

            except Exception:
                pass # Continue polling on transient network errors

            time.sleep(1.5)

        yield "[Error: Task timed out after 5 minutes]"

    def list_devices(self) -> list:
        """List online GPU devices with running LLM."""
        if self.direct_mode:
            return [{"slot": 0, "device_id": "local", "device_name": "local", "gpu": "direct", "llm_model": self.model}]

        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code != 200:
                return []
            data = resp.json()
            if not data.get("success"):
                return []

            devices = []
            for s in data.get("slots", []):
                if not s.get("online"):
                    continue
                running = s.get("running_services", [])
                if "llm" in running:
                    devices.append({
                        "slot": s.get("slot_number"),
                        "device_id": s.get("device_id", ""),
                        "device_name": s.get("device_name", "Unknown"),
                        "gpu": s.get("gpu_info", {}).get("name", "Unknown"),
                        "vram_gb": round(s.get("gpu_info", {}).get("memory_total_mb", 0) / 1024, 1),
                        "llm_model": s.get("llm_current_model") or "ollama",
                    })
            return devices
        except Exception:
            return []

    def test_connection(self) -> tuple[bool, str]:
        """Test connectivity and return (ok, message)."""
        if self.direct_mode:
            try:
                resp = self.session.get(f"{self.brain_url}/api/tags", timeout=10)
                if resp.status_code != 200:
                    return False, f"Brain returned {resp.status_code}"
                data = resp.json()
                models = [m["name"] for m in data.get("models", [])]
                if self.model and self.model not in models:
                    available = ", ".join(models[:5]) or "none"
                    return False, f"Model '{self.model}' not found. Available: {available}"
                return True, f"Connected to brain at {self.brain_url} ({self.model})"
            except requests.exceptions.ConnectionError:
                return False, f"Could not connect to {self.brain_url}"
            except Exception as e:
                return False, str(e)

        # Cloud mode — find our slot
        try:
            resp = self.session.get(f"{self.api_url}/api/user/byog/slots", timeout=15)
            if resp.status_code == 401:
                return False, "Invalid API token"
            if resp.status_code != 200:
                return False, f"API error: {resp.status_code}"

            data = resp.json()
            if not data.get("success"):
                return False, data.get("error", "API error")

            for s in data.get("slots", []):
                if s.get("slot_number") == self.slot:
                    if not s.get("online"):
                        return False, f"Slot {self.slot} is offline"
                    if "llm" not in s.get("running_services", []):
                        return False, f"Slot {self.slot} has no LLM running"
                    gpu = s.get("gpu_info", {}).get("name", "unknown")
                    model = s.get("llm_current_model") or self.model or "ollama"
                    return True, f"Connected to {model} on {gpu} (slot {self.slot})"

            return False, f"Slot {self.slot} not found"
        except requests.exceptions.ConnectionError:
            return False, f"Could not connect to {self.api_url}"
        except Exception as e:
            return False, str(e)
