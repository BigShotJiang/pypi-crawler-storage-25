"""Interactive text-to-SQL pipeline orchestration with template learning and negative memory.

Coordinates the full end-to-end query lifecycle: intent parsing via LLM, join candidate generation, SQL generation and repair loops, result validation, and user feedback processing.

Maintains template acceptance/rejection state and negative memory buckets (by intent key, join signature, SQL fingerprint, and column map) to inform confidence scoring and hard-block decisions on future queries.
"""

from __future__ import annotations

import csv
import os
import re
from collections import Counter
from dataclasses import replace
from typing import Any

from .config import EngineConfig, PolicyConfig
from .contracts_base import QueryPlan, SchemaGraph
from .contracts_core import (
    RuntimeIntent,
    SQLShape,
    SelectCol,
    Template,
    TemplateMatch,
    concrete_cte_to_runtime,
)
from .core_utils import (
    ask_user_choice,
    colmap_signature,
    debug,
    explain_db_error_nl,
    is_repair_oscillating,
    issue_sig,
    join_sig_string,
    llm_chat,
    llm_sql_with_join,
    log,
    print_info,
    print_query_result,
    safe_json_loads,
    sql_fp,
    stable_json,
    substitute_params,
)
from .dialect import get_dialect
from .intent_expr import extract_structural_params, has_non_default_structural
from .intent_process import (
    full_intent_parse,
    intent_similarity,
    llm_ux_explain,
    find_trusted_template_match,
)
from .sql_gen import (
    JOIN_PLACEHOLDER,
    build_deterministic_sql,
    build_repair_prompt,
    cte_to_intent_for_ranking,
    deterministic_alias_sql,
    get_join_choice_from_llm,
    inject_join_into_deterministic_sql,
    join_candidate_map,
    join_hints_multi,
    normalize_cte_sql,
    normalize_where_having_predicates,
    physical_tables_for_join_hints,
    reorder_sql_joins_canonical,
)
from .templates import (
    best_template_by_intent_key,
    demote_template_to_rejected,
    find_rejected_by_intent_key,
    find_rejected_by_similarity,
    get_aggregated_hard_block_info,
    increment_rejected_template,
    insert_rejected_template,
    insert_template,
    maybe_demote_trust,
    promote_rejected_to_template,
    promote_trust,
    record_template_feedback,
    rejected_templates_to_store,
    save_template_store,
    templates_to_store,
    top_rejected_examples,
)
from .utils import extract_tables_from_sql, flatten_param_values, intent_key, sql_shape
from .validation_execute import (
    compute_confidence,
    execute_sql,
    get_spark_sql_for_execution,
    llm_classify_rejection,
    validate_sql,
)


def _llm_extract_reuse_params(q_norm: str, template: Template) -> dict[str, Any]:
    """Extract all parameter values from a new question for template reuse.

    Uses a single LLM call to extract both p-params (filter/having values) and s-params (structural numeric values such as LIMIT or coefficients) from the natural language question, using the template's previous question and values as an example.

    Args:

        q_norm: The normalised user question.

        template: The Template whose SQL and previous param values serve as context.

    Returns:

        Dict mapping param key -> extracted value.

        Empty dict on LLM failure.
    """
    sql_param = template.sql_param or ""
    p_keys = sorted(set(re.findall(r":p\d+", sql_param)))
    s_keys = sorted(set(re.findall(r":s\d+", sql_param)))
    all_keys = [k.lstrip(":") for k in p_keys + s_keys]
    if not all_keys:
        return {}
    vh = template.value_history
    if vh.questions:
        freq_q = Counter(vh.questions).most_common(1)[0][0]
        idx = vh.questions.index(freq_q)
    else:
        idx = 0
    prev_pv = vh.param_values[idx] if vh.param_values else {}
    example_pv = {}
    for k in all_keys:
        example_pv[k] = prev_pv.get(k, "example")
    matched_question = vh.questions[idx] if vh.questions else ""
    matched_values = prev_pv
    system = (
        "You are a deterministic parameter value extractor for text-to-SQL."
        " Output ONLY valid JSON that matches the requested format."
    )
    user = stable_json(
        {
            "task": "The parameterized SQL below uses placeholders for literal values. Extract the correct value from the question for every param_key listed.",
            "parameterized_sql": sql_param,
            "matched_question": matched_question,
            "matched_values": matched_values,
            "param_keys": all_keys,
            "question": q_norm,
            "extraction_rules": [
                "p-params (p1, p2, ...) are filter/having values: strings, numbers, dates, booleans, or arrays.",
                "s-params (s1, s2, ...) are structural numeric values: LIMIT, coefficients, function arguments.",
                "Quoted text or named entities → string/enum values. Preserve original case.",
                "Digits in the question → integer or number values. Use numeric type, not string.",
                "'in'/'not in' operators → value is an array of extracted items.",
                "Date expressions → convert to YYYY-MM-DD format.",
                "true/false/yes/no keywords → boolean values.",
                "s1, s2, ... correspond to LIMIT values, coefficients, or function arguments in expressions.",
            ],
            "output_format": {
                "param_values": example_pv,
            },
        }
    )
    raw = llm_chat(system, user, task="default")
    parsed = safe_json_loads(raw)
    if not parsed or not isinstance(parsed, dict):
        raw2 = llm_chat(system, user, task="default")
        parsed = safe_json_loads(raw2)
    if not parsed or not isinstance(parsed, dict):
        debug("[pipeline.llm_extract_reuse_params] JSON parse failed")
        return {}
    pv_raw = parsed.get("param_values", {})
    result: dict[str, Any] = {}
    for k in all_keys:
        if k in pv_raw:
            val = pv_raw[k]
            if k.startswith("s") and isinstance(val, str):
                try:
                    val = int(val)
                except ValueError:
                    try:
                        val = float(val)
                    except ValueError:
                        pass
            result[k] = val
    debug(f"[pipeline.llm_extract_reuse_params] extracted {len(result)}/{len(all_keys)} params")
    return result


def load_pipeline_resources(
    schema: SchemaGraph = None,
    store: Any = None,
    templates: list = None,
    rejected: list = None,
    schema_terms: set[str] = None,
) -> tuple:
    """Load schema, templates, rejected templates, and build schema terms.

    Validates that all required resources are provided and creates the database engine appropriate for the configured dialect type.

    Args:

        schema: Pre-loaded SchemaGraph; raises RuntimeError if None.

        store: Pre-loaded template store dict; raises RuntimeError if None.

        templates: Pre-loaded accepted templates dict; raises RuntimeError if None.

        rejected: Pre-loaded rejected templates dict; raises RuntimeError if None.

        schema_terms: Pre-built set of schema terms; raises RuntimeError if None.

    Returns:

        Tuple of ``(dialect, engine, schema, store, templates, rejected, schema_terms)``.
    """
    if not EngineConfig.API_TOKEN:
        raise RuntimeError("OPENAI_API_KEY missing")

    log("loading schema")
    dialect = get_dialect(EngineConfig.TYPE, EngineConfig.RUNTIME)

    if EngineConfig.TYPE == "postgresql":
        from sqlalchemy import create_engine

        engine = create_engine(EngineConfig.RUNTIME.db_url(), future=True)
    elif EngineConfig.TYPE == "databricks":
        engine = None
    else:
        raise ValueError(f"Unsupported engine type: {EngineConfig.TYPE}")

    if schema is None:
        raise RuntimeError("Schema must be provided to load_pipeline_resources")
    if store is None:
        raise RuntimeError("Store must be provided to load_pipeline_resources")
    if templates is None:
        raise RuntimeError("Templates must be provided to load_pipeline_resources")
    if rejected is None:
        raise RuntimeError("Rejected must be provided to load_pipeline_resources")
    if schema_terms is None:
        raise RuntimeError("Schema terms must be provided to load_pipeline_resources")

    log(f"templates_loaded={len(templates)}")
    debug(f"[pipeline.load_pipeline_resources] templates: {len(templates)} approved, {len(rejected)} rejected")
    debug(f"[pipeline.load_pipeline_resources] schema_terms: {len(schema_terms)} terms")

    return dialect, engine, schema, store, templates, rejected, schema_terms


def check_template_reuse(q_norm: str, templates: dict[str, Any]) -> TemplateMatch:
    """Check if a question matches an existing template for direct SQL or intent reuse.

    Args:

        q_norm: The normalised user question.

        templates: The accepted templates dict.

    Returns:

        TemplateMatch with ``reuse_type="direct_reuse"`` and similarity 1.0 on an exact fuzzy match, or ``reuse_type="none"`` if no match found.
    """
    debug("[pipeline.check_template_reuse] checking exact fuzzy match")
    templates_list = list(templates.values()) if isinstance(templates, dict) else templates
    result = find_trusted_template_match(q_norm, templates_list)

    if result is not None:
        intent, ref_tmpl = result
        log("exact question match found (trust=2, score=1.0)")
        debug(f"[pipeline.check_template_reuse] AUTO-DECISION: exact fuzzy match for template '{ref_tmpl.id}'")
        return TemplateMatch(
            intent=intent,
            best_template=ref_tmpl,
            similarity_score=1.0,
            reuse_type="direct_reuse",
        )

    return TemplateMatch(
        intent=None,
        best_template=None,
        similarity_score=0.0,
        reuse_type="none",
    )


def parse_intent_via_llm(
    q_norm: str, schema: SchemaGraph, templates: dict[str, Any], store: dict[str, Any]
) -> tuple[RuntimeIntent, list[dict[str, Any]], int] | None:
    """Parse user intent via LLM with semantic repair loop.

    Invokes ``full_intent_parse`` and auto-terminates on structural failure.
    Template matching is no longer performed here; the caller handles union
    matching after intent confirmation.

    Args:
        q_norm: The normalised user question.
        schema: The schema graph.
        templates: The accepted templates dict (unused, kept for signature compat).
        store: The mutable template store dict (saved if the user declines).

    Returns:
        ``(intent, semantic_warnings, llm_calls)`` on success, or ``None``
        when intent parsing fails or the user declines.
    """
    log("intent via LLM")
    debug("[pipeline.parse_intent_via_llm] calling full_intent_parse")
    intent, semantic_warnings, llm_calls = full_intent_parse(q_norm, schema)

    if intent is None:
        print("\nPlease rephrase your question.")
        return None

    if getattr(intent, "schema_invalid", False):
        choice = ask_user_choice(
            "This question seems invalid for this schema. Would you like to continue?",
            ["y", "n"],
        )
        if choice is None or choice != "y":
            print("\nPlease rephrase your question.")
            return None
        intent = replace(intent, schema_invalid=False)

    if semantic_warnings:
        log(f"Semantic warnings after repair: {len(semantic_warnings)} remaining")

    debug(f"[pipeline.parse_intent_via_llm] tables={intent.tables}, grain={intent.grain}")
    return intent, semantic_warnings, llm_calls


def generate_join_candidates(
    intent: RuntimeIntent, schema: SchemaGraph
) -> tuple[dict[str, Any], dict[str, list[str]], dict[str, dict[str, Any]]]:
    """Generate join candidates for intent tables and CTE steps.

    Args:

        intent: The RuntimeIntent whose tables and CTE steps are used.

        schema: The schema graph.

    Returns:

        Tuple of ``(join_candidates, cmap, cte_join_hints)`` where ``join_candidates`` is the hints dict for the main query, ``cmap`` is the candidate_id -> signature map, and ``cte_join_hints`` maps CTE name -> join hints dict.
    """
    debug("[pipeline.generate_join_candidates] generating join candidates")
    main_join_tables = physical_tables_for_join_hints(intent.tables, schema)
    join_candidates = join_hints_multi(schema, main_join_tables, intent)
    cmap = join_candidate_map(join_candidates)
    debug(f"[pipeline.generate_join_candidates] {len(join_candidates.get('candidates', []))} join candidates")
    for c in join_candidates.get("candidates", []):
        debug(f"[pipeline.generate_join_candidates] {c.get('candidate_id')}: {c.get('join_path_signature', [])}")

    cte_join_hints: dict[str, dict[str, Any]] = {}
    cte_steps = intent.cte_steps or []
    for cte in cte_steps:
        cte_name = cte.cte_name
        cte_tables = cte.tables or []
        if len(cte_tables) >= 2:
            cte_intent = cte_to_intent_for_ranking(cte)
            cte_hints = join_hints_multi(schema, cte_tables, cte_intent)
            cte_join_hints[cte_name] = cte_hints
            debug(
                f"[pipeline.generate_join_candidates] CTE '{cte_name}': {len(cte_hints.get('candidates', []))} candidates (CTE-specific ranking)"
            )
        else:
            cte_join_hints[cte_name] = {
                "candidates": [
                    {
                        "candidate_id": "J00",
                        "predicates": [],
                        "join_path_signature": [],
                        "edge_count": 0,
                        "description": "No join needed (single table CTE)",
                    }
                ]
            }
            debug(f"[pipeline.generate_join_candidates] CTE '{cte_name}': single table, J00 assigned")

    return join_candidates, cmap, cte_join_hints


def _create_query_plan(sql: str, chosen_join_id: str, cmap: dict[str, list[str]]) -> QueryPlan:
    """Create QueryPlan dataclass from SQL generation results.

    Args:

        sql: The generated SQL string.

        chosen_join_id: The candidate ID chosen by the LLM (e.g. ``"J01"``).

        cmap: Candidate ID -> join path signature map from ``join_candidate_map``.

    Returns:

        QueryPlan with sql, chosen_join_candidate_id, and chosen_join_path_signature populated.
    """
    chosen_sig = cmap.get(chosen_join_id, [])
    return QueryPlan(
        sql=sql,
        chosen_join_candidate_id=chosen_join_id,
        chosen_join_path_signature=chosen_sig,
    )


def _run_sql_validation_cascade(
    sql: str,
    intent: RuntimeIntent,
    dialect: Any,
    engine: Engine | None,
) -> tuple[bool, str]:
    """Validate SQL via AST parse and optional EXPLAIN check.

    Args:
        sql: The substituted SQL string.
        intent: The RuntimeIntent (provides bind parameter values).
        dialect: The database dialect instance.
        engine: Optional SQLAlchemy Engine for explain-based validation.

    Returns:
        Tuple of ``(ok, err)`` where ``ok`` is True if validation
        passes and ``err`` is the error message on failure (empty
        string when ok).
    """
    ok, err = validate_sql(dialect, sql, engine, intent.param_values)
    debug(f"[pipeline._run_sql_validation_cascade] validate_sql ok={ok}, err={err}")
    return ok, err


def _structural_fingerprint(sql_text: str, known_tables: list[str]) -> dict[str, Any]:
    """Extract a comprehensive structural fingerprint from SQL for drift detection.

    Captures tables, join count, and presence of major SQL clauses so
    that repairs which silently alter query structure can be rejected.

    Args:
        sql_text: The SQL string to fingerprint.
        known_tables: Sorted list of known table names for extraction.

    Returns:
        Dict of structural features suitable for equality comparison.
    """
    s = sql_text.lower()
    return {
        "tables": frozenset(extract_tables_from_sql(sql_text, known_tables)),
        "num_joins": len(re.findall(r"\bjoin\b", s)),
        "has_group_by": bool(re.search(r"\bgroup\s+by\b", s)),
        "has_order_by": bool(re.search(r"\border\s+by\b", s)),
        "has_having": bool(re.search(r"\bhaving\b", s)),
        "has_where": bool(re.search(r"\bwhere\b", s)),
        "has_distinct": bool(re.search(r"\bselect\s+distinct\b", s)),
        "num_cte": len(re.findall(r"\bas\s*\(", s)),
    }


def generate_and_validate_sql(
    q_norm: str,
    intent: RuntimeIntent,
    schema: SchemaGraph,
    join_candidates: dict[str, Any],
    cmap: dict[str, list[str]],
    dialect: Any,
    store: dict[str, Any],
    engine: Any | None = None,
    cte_join_hints: dict[str, dict[str, Any]] | None = None,
    matched_template: Template | None = None,
    union_select_cols: list[SelectCol] | None = None,
    cols_changed: bool = False,
) -> tuple[str, bool]:
    """Generate SQL and validate via EXPLAIN with up to MAX_REPAIR_LOOPS repairs.

    Three generation paths depending on template union results:

    * **Path C** — template matched, nothing changed: reuse stored
      ``sql_param`` with parameter substitution.
    * **Path B** — template matched, columns changed: rebuild
      deterministic SQL from the union intent using existing join
      signatures.
    * **Path D** — no template match: fresh ``build_deterministic_sql``
      with join choice selection and validation cascade.

    Args:
        q_norm: Normalised user question.
        intent: The validated ``RuntimeIntent``.
        schema: The schema graph.
        join_candidates: Join hint candidates dict.
        cmap: Candidate ID → join path signature map.
        dialect: Database dialect instance.
        store: Template store dict (for saving on failure).
        engine: Optional SQLAlchemy engine for EXPLAIN validation.
        cte_join_hints: Per-CTE join candidates.
        matched_template: Template from union matching, or ``None`` for
            Path D.
        union_select_cols: Merged select columns when a template
            matched.
        cols_changed: Whether the union introduced new columns.

    Returns:
        ``(substituted_sql, success)`` tuple.
    """
    log("sql generation")
    debug(f"[pipeline.generate_and_validate_sql] tables={intent.tables or []}")
    debug(f"[pipeline.generate_and_validate_sql] grain={intent.grain or 'unknown'}")
    debug(
        f"[pipeline.generate_and_validate_sql] select_cols={[s.expr.primary_term for s in (intent.select_cols or [])]}"
    )
    debug(f"[pipeline.generate_and_validate_sql] filters_param={len(intent.filters_param or [])}")
    debug(f"[pipeline.generate_and_validate_sql] having_param={len(intent.having_param or [])}")
    debug(
        f"[pipeline.generate_and_validate_sql] cte_join_hints={list(cte_join_hints.keys()) if cte_join_hints else None}"
    )
    path = "D"
    if matched_template:
        path = "B" if cols_changed else "C"
    debug(f"[pipeline.generate_and_validate_sql] generation path={path}")

    params = dict(flatten_param_values(intent))
    debug(f"[pipeline.generate_and_validate_sql] params={params}")

    if path == "C":
        sql_param = matched_template.sql_param
        for sk in re.findall(r":(s\d+)", sql_param):
            if sk not in params and sk in getattr(
                matched_template, "structural_defaults", {}
            ):
                params[sk] = matched_template.structural_defaults[sk]
        intent.param_values = dict(intent.param_values or {})
        for k, v in params.items():
            intent.param_values.setdefault(k, v)
        intent.chosen_join_candidate_id = matched_template.intent_signature.chosen_join_candidate_id
        intent.chosen_join_path_signature = list(
            matched_template.intent_signature.chosen_join_path_signature
        )
        if matched_template.intent_signature.cte_steps:
            for cte_step, tmpl_cte in zip(
                intent.cte_steps or [],
                matched_template.intent_signature.cte_steps,
                strict=False,
            ):
                cte_step.chosen_join_candidate_id = tmpl_cte.chosen_join_candidate_id
                cte_step.chosen_join_path_signature = list(tmpl_cte.chosen_join_path_signature)
        sql = substitute_params(sql_param, params) if params else sql_param
        intent.sql_param = sql_param
        intent.sql_substituted = sql
        intent.deterministic_sql = matched_template.deterministic_sql
        intent.sql_display_param = deterministic_alias_sql(sql_param, intent)
        debug("[pipeline.generate_and_validate_sql] path C: reused template sql_param")
        return sql, True

    if path == "B":
        gen_intent = replace(intent, select_cols=list(union_select_cols or []), param_values={})
        gen_intent = extract_structural_params(gen_intent)
        params = flatten_param_values(gen_intent)
        intent.param_values = gen_intent.param_values
        deterministic_sql = build_deterministic_sql(gen_intent, cte_join_hints)
        intent.deterministic_sql = deterministic_sql
        join_sigs_ordered = _collect_template_join_sigs(matched_template, intent)
        if JOIN_PLACEHOLDER in deterministic_sql:
            sql_param = inject_join_into_deterministic_sql(deterministic_sql, join_sigs_ordered)
        else:
            sql_param = deterministic_sql
        intent.chosen_join_candidate_id = matched_template.intent_signature.chosen_join_candidate_id
        intent.chosen_join_path_signature = list(
            matched_template.intent_signature.chosen_join_path_signature
        )
        if matched_template.intent_signature.cte_steps:
            for cte_step, tmpl_cte in zip(
                intent.cte_steps or [],
                matched_template.intent_signature.cte_steps,
                strict=False,
            ):
                cte_step.chosen_join_candidate_id = tmpl_cte.chosen_join_candidate_id
                cte_step.chosen_join_path_signature = list(tmpl_cte.chosen_join_path_signature)
        sql_param = _normalize_sql_param(sql_param, intent)
        sql = substitute_params(sql_param, params) if params is not None else sql_param
        intent.sql_param = sql_param
        intent.sql_substituted = sql
        debug("[pipeline.generate_and_validate_sql] path B: rebuilt deterministic SQL with union cols")

    else:
        deterministic_sql = build_deterministic_sql(intent, cte_join_hints)
        intent.deterministic_sql = deterministic_sql
        sql_param, cte_join_ids = _resolve_joins_fresh(
            deterministic_sql, intent, cmap, cte_join_hints, q_norm, join_candidates,
        )
        sql_param = _normalize_sql_param(sql_param, intent)
        sql = substitute_params(sql_param, params) if params is not None else sql_param
        intent.sql_param = sql_param
        intent.sql_substituted = sql
        debug("[pipeline.generate_and_validate_sql] path D: fresh deterministic SQL")

    ok, err = _run_sql_validation_cascade(sql, intent, dialect, engine)

    seen_errors: dict[str, int] = {}
    sql_fingerprints: list[str] = [sql_fp(sql_param)]
    loops = 0
    debug(f"[pipeline.generate_and_validate_sql] starting validation loop, max={PolicyConfig.MAX_REPAIR_LOOPS}")
    while not ok and loops < PolicyConfig.MAX_REPAIR_LOOPS:
        loops += 1
        debug(f"[pipeline.generate_and_validate_sql] repair iteration {loops}")
        seen_errors[err] = seen_errors.get(err, 0) + 1
        debug(f"[pipeline.generate_and_validate_sql] error count for '{err}': {seen_errors[err]}")

        if is_repair_oscillating(sql_fingerprints):
            log("oscillation detected; stopping repair")
            break
        if seen_errors[err] >= 2:
            log("repeated identical failure detected; stopping repair")
            break

        nl_err = explain_db_error_nl(err)

        pre_repair_sql = sql
        debug(f"[pipeline.generate_and_validate_sql] SQL being sent to repair LLM:\n{sql_param}")
        debug(f"[pipeline.generate_and_validate_sql] repair error: {err}")
        repair_system, repair_user = build_repair_prompt(
            schema, q_norm, sql_param, err, nl_err,
            join_candidates, cte_join_hints=cte_join_hints,
        )
        repaired_sql_param, chosen_join_id, ok_json, repaired_cte_join_ids = llm_sql_with_join(
            repair_system, repair_user, task="sql",
        )
        if not ok_json:
            break

        repair_plan = _create_query_plan(repaired_sql_param, chosen_join_id, cmap)
        sql_param = repair_plan.sql
        if repair_plan.chosen_join_path_signature:
            sql_param = reorder_sql_joins_canonical(sql_param, repair_plan.chosen_join_path_signature)
        sql_param = normalize_where_having_predicates(sql_param)
        cte_join_sigs = {
            s.cte_name: s.chosen_join_path_signature
            for s in (intent.cte_steps or []) if s.chosen_join_path_signature
        }
        if cte_join_sigs:
            sql_param = normalize_cte_sql(sql_param, cte_join_sigs)
        sql = substitute_params(sql_param, params) if params else sql_param

        known_tables = sorted(schema.tables.keys())
        pre_fp = _structural_fingerprint(pre_repair_sql, known_tables)
        post_fp = _structural_fingerprint(sql, known_tables)
        if pre_fp != post_fp:
            diffs = {k: (pre_fp[k], post_fp[k]) for k in pre_fp if pre_fp[k] != post_fp[k]}
            log(f"repair altered query structure {diffs}; rejecting")
            sql = pre_repair_sql
            break

        intent.sql_param = sql_param
        intent.sql_substituted = sql
        intent.chosen_join_candidate_id = repair_plan.chosen_join_candidate_id
        intent.chosen_join_path_signature = repair_plan.chosen_join_path_signature
        sql_fingerprints.append(sql_fp(sql_param))
        ok, err = _run_sql_validation_cascade(sql, intent, dialect, engine)

    if not ok:
        print("\nPlease rephrase your question.")
        save_template_store(store)
        return sql, False

    if intent.expected_rows == "one":
        intent.sql_display_param = intent.sql_param
    else:
        intent.sql_display_param = deterministic_alias_sql(intent.sql_param, intent)

    return sql, True


def _collect_template_join_sigs(
    template: Template,
    intent: RuntimeIntent,
) -> list[list[str]]:
    """Collect ordered join signatures from a matched template for injection.

    Returns CTE join signatures first (in intent CTE order), then the main
    query join signature — matching the order expected by
    ``inject_join_into_deterministic_sql``.

    Args:
        template: The matched template with stored join choices.
        intent: The runtime intent (for CTE step ordering).

    Returns:
        Ordered list of join path signature lists.
    """
    sigs: list[list[str]] = []
    tmpl_cte_map = {
        c.cte_name: list(c.chosen_join_path_signature)
        for c in (template.intent_signature.cte_steps or [])
    }
    for cte in intent.cte_steps or []:
        if (cte.tables or []) and len(cte.tables) >= 2:
            sigs.append(tmpl_cte_map.get(cte.cte_name, []))
    if (intent.tables or []) and len(intent.tables) >= 2:
        sigs.append(list(template.intent_signature.chosen_join_path_signature))
    return sigs


def _resolve_joins_fresh(
    deterministic_sql: str,
    intent: RuntimeIntent,
    cmap: dict[str, list[str]],
    cte_join_hints: dict[str, dict[str, Any]] | None,
    q_norm: str,
    join_candidates: dict[str, Any],
) -> tuple[str, dict[str, str]]:
    """Inject joins into deterministic SQL using the appropriate candidate.

    Selection logic:
    * Single-table intent → J00 (no join).
    * Multi-table with exactly one candidate → J01.
    * Multi-table with multiple candidates → LLM picks via
      ``get_join_choice_from_llm``.

    Args:
        deterministic_sql: Raw deterministic SQL with ``-- <JOIN>`` placeholders.
        intent: The runtime intent (mutated with join choices).
        cmap: Candidate ID → join path signature map.
        cte_join_hints: Per-CTE join candidates.
        q_norm: Normalised user question (needed for LLM candidate selection).
        join_candidates: Full join candidates dict (needed for LLM candidate selection).

    Returns:
        ``(sql_param, cte_join_ids)`` where ``sql_param`` has joins injected
        and ``cte_join_ids`` maps CTE names to chosen candidate IDs.
    """
    cte_join_ids: dict[str, str] = {}
    join_sigs_ordered: list[list[str]] = []

    if JOIN_PLACEHOLDER not in deterministic_sql:
        sql_param = deterministic_sql
        intent.chosen_join_candidate_id = "J00"
        intent.chosen_join_path_signature = []
        return sql_param, cte_join_ids

    multi_table = (intent.tables or []) and len(intent.tables) >= 2
    multi_table_candidates = {k: v for k, v in cmap.items() if k != "J00"}

    if not multi_table:
        candidate_id = "J00"
        debug("[pipeline._resolve_joins_fresh] single-table intent → J00")
    elif len(multi_table_candidates) == 1:
        candidate_id = next(iter(multi_table_candidates))
        debug(f"[pipeline._resolve_joins_fresh] single candidate → {candidate_id}")
    else:
        candidate_id, cte_join_ids = get_join_choice_from_llm(
            q_norm, deterministic_sql, join_candidates, cte_join_hints,
        )
        debug(f"[pipeline._resolve_joins_fresh] LLM chose candidate_id={candidate_id}")

    for cte in intent.cte_steps or []:
        if (cte.tables or []) and len(cte.tables) >= 2:
            cte_sig: list[str] = []
            if cte_join_hints and cte.cte_name in cte_join_hints:
                cte_cid = cte_join_ids.get(cte.cte_name, candidate_id)
                cte_join_ids[cte.cte_name] = cte_cid
                for cand in cte_join_hints[cte.cte_name].get("candidates", []):
                    if cand.get("candidate_id") == cte_cid:
                        cte_sig = cand.get("join_path_signature", [])
                        break
            join_sigs_ordered.append(cte_sig)
    if multi_table:
        join_sigs_ordered.append(cmap.get(candidate_id, []))

    sql_param = inject_join_into_deterministic_sql(deterministic_sql, join_sigs_ordered)
    intent.chosen_join_candidate_id = candidate_id
    intent.chosen_join_path_signature = cmap.get(candidate_id, [])
    if cte_join_ids and intent.cte_steps:
        for cte_step in intent.cte_steps:
            if cte_step.cte_name in cte_join_ids:
                cte_step.chosen_join_candidate_id = cte_join_ids[cte_step.cte_name]
                if cte_join_hints and cte_step.cte_name in cte_join_hints:
                    for cand in cte_join_hints[cte_step.cte_name].get("candidates", []):
                        if cand.get("candidate_id") == cte_step.chosen_join_candidate_id:
                            cte_step.chosen_join_path_signature = cand.get(
                                "join_path_signature", [],
                            )
                            break

    return sql_param, cte_join_ids


def _normalize_sql_param(sql_param: str, intent: RuntimeIntent) -> str:
    """Apply canonical ordering and normalisation to a parameterized SQL string.

    Reorders joins to match the chosen join path signature order and
    normalises WHERE/HAVING predicate operand positions.

    Args:
        sql_param: The raw parameterized SQL after join injection.
        intent: The runtime intent with join signature metadata.

    Returns:
        Normalised SQL string.
    """
    if intent.chosen_join_path_signature:
        sql_param = reorder_sql_joins_canonical(sql_param, intent.chosen_join_path_signature)
    sql_param = normalize_where_having_predicates(sql_param)
    cte_join_sigs = {
        s.cte_name: s.chosen_join_path_signature
        for s in (intent.cte_steps or []) if s.chosen_join_path_signature
    }
    if cte_join_sigs:
        sql_param = normalize_cte_sql(sql_param, cte_join_sigs)
    return sql_param


def compute_final_metrics(
    sql: str,
    intent: RuntimeIntent,
    schema: SchemaGraph,
    templates: dict[str, Any],
    join_candidates: dict[str, Any],
    store: dict[str, Any],
) -> float:
    """Compute confidence score and shape metrics.

    Combines intent similarity gap, shape distance, negative memory penalties, and column-map penalties into a single confidence float.

    Args:

        sql: The executed SQL string.

        intent: The RuntimeIntent (mutated with sql_shape).

        schema: The schema graph.

        templates: The accepted templates dict for similarity comparison.

        join_candidates: The join hint candidates dict.

        store: The template store dict containing negative memory.

    Returns:

        Confidence score float in [0, 1].
    """
    known_tables = sorted(schema.tables.keys())
    sql_tables = extract_tables_from_sql(sql, known_tables)
    used_new_tables = any(t not in (intent.tables or []) for t in sql_tables)

    scored = [(t, intent_similarity(intent, t.intent_signature)) for t in templates.values()]
    scored.sort(key=lambda x: (-x[1], x[0].id))
    best_score = scored[0][1] if scored else 0.0
    second_score = scored[1][1] if len(scored) > 1 else 0.0
    gap = best_score - second_score

    predicted_num_cte = len(intent.cte_steps or [])
    has_agg = any(s.is_aggregated for s in (intent.select_cols or []))
    predicted_shape = SQLShape(
        num_joins=max(0, len(intent.tables or []) - 1),
        has_group_by=(intent.grain == "grouped"),
        has_agg=has_agg,
        num_cte=predicted_num_cte,
    )
    actual_shape = sql_shape(sql, intent)
    shape_pen = _shape_distance(predicted_shape, actual_shape)

    num_cte_pen = float(abs(predicted_num_cte - actual_shape.num_cte))

    ikey = intent_key(intent)
    neg_pen = _negative_penalty(
        store,
        ikey,
        intent.chosen_join_path_signature or [],
        sql_fp(intent.sql_param),
    )

    colmap_sig_val = colmap_signature(intent.column_map or {})
    colmap_pen = _colmap_penalty(store, colmap_sig_val)

    conf = compute_confidence(best_score, gap, used_new_tables, shape_pen, neg_pen, colmap_pen, num_cte_pen)

    intent.sql_shape = actual_shape

    log(f"confidence={round(conf, 3)}")
    log(f"sql_tables={sql_tables}")
    log(f"shape={actual_shape}")

    return conf


def handle_user_feedback(
    choice: str,
    intent: RuntimeIntent,
    sql: str,
    schema: SchemaGraph,
    store: dict[str, Any],
    templates: dict[str, Any],
    rejected: dict[str, Any],
    q_norm: str,
    hard_block_override: bool,
    hard_block_rejected_template: Any | None,
    matched_rejected_template: Any | None,
    ux_summary: str = "",
    dialect: Any | None = None,
) -> dict[str, str] | None:
    """Record user feedback and update templates or rejected templates.

    On acceptance (``choice='y'``): promotes a rejected template if applicable, updates trust, or inserts a new template.

    On rejection (``choice='n'``): prompts for reason, classifies via LLM, and increments or inserts rejection records.

    Args:

        choice: User's choice string; ``'y'`` to accept, ``'n'`` to reject.

        intent: The RuntimeIntent for the query.

        sql: The generated SQL.

        schema: The schema graph.

        store: The mutable template store dict.

        templates: The accepted templates dict.

        rejected: The rejected templates dict.

        q_norm: The normalised user question.

        hard_block_override: True if the user overrode a hard-block.

        hard_block_rejected_template: The RejectedTemplate that triggered the hard-block, if any.

        matched_rejected_template: The best-matching RejectedTemplate by similarity, if any.

        ux_summary: Optional pre-computed UX summary.

    Returns:

        When choice is ``'n'``, a dict with keys ``category``, ``normalized_reason``, and ``reject_reason`` (raw user text). Otherwise ``None``.
    """
    if choice not in ("y", "n"):
        save_template_store(store)
        return None

    intent.sql_shape = sql_shape(sql, intent)
    ikey = intent_key(intent)
    colmap_sig_val = colmap_signature(intent.column_map or {})
    sql_fp_val = sql_fp(intent.sql_param)

    existing_template = best_template_by_intent_key(templates, ikey)
    if existing_template:
        debug(f"[pipeline.handle_user_feedback] found matching template by intent_key: {existing_template.id}")

    if choice == "y":
        if hard_block_override and hard_block_rejected_template:
            new_tmpl = promote_rejected_to_template(
                store,
                templates,
                rejected,
                hard_block_rejected_template,
                q_norm,
                intent,
                sql,
                schema.schema_hash,
            )
            log(f"promoted rejected template {hard_block_rejected_template.id} to template {new_tmpl.id}")
        elif matched_rejected_template and matched_rejected_template != hard_block_rejected_template:
            new_tmpl = promote_rejected_to_template(
                store,
                templates,
                rejected,
                matched_rejected_template,
                q_norm,
                intent,
                sql,
                schema.schema_hash,
            )
            log(f"promoted matched rejected template {matched_rejected_template.id} to template {new_tmpl.id}")
        elif existing_template:
            record_template_feedback(existing_template, accept=True)
            promote_trust(existing_template)
            all_pv = flatten_param_values(intent)
            existing_template.value_history.add(all_pv, q_norm, intent.natural_language or "")
        else:
            debug("[pipeline.handle_user_feedback] no duplicate, calling insert_template")

            insert_template(store, templates, schema, q_norm, intent, sql, ux_summary, dialect=dialect)

        store = templates_to_store(store, templates)
        store = rejected_templates_to_store(store, rejected)
        save_template_store(store)
        return None

    else:
        needs_reason = (
            (hard_block_override and hard_block_rejected_template)
            or (existing_template and existing_template.trust_level == 0)
            or (not existing_template)
        )

        if needs_reason:
            try:
                print("What was wrong?")
                reject_reason = input().strip()
            except (EOFError, KeyboardInterrupt):
                print("\nUser terminated.")
                save_template_store(store)
                return
            if not reject_reason:
                print("\nInvalid input.")
                save_template_store(store)
                return None
            ux = intent.natural_language or ""
            reject_info = llm_classify_rejection(q_norm, intent, sql, ux, reject_reason)
            if not reject_info:
                save_template_store(store)
                return None
            category = reject_info.get("category")
            norm_reason = reject_info.get("normalized_reason")
        else:
            category = "other"
            norm_reason = "user_rejected"
            reject_reason = ""

        if hard_block_override and hard_block_rejected_template:
            increment_rejected_template(hard_block_rejected_template, category, norm_reason, q_norm, intent, sql)
            debug(f"[pipeline.handle_user_feedback] incremented rejection for {hard_block_rejected_template.id}")
            chosen_sig = intent.chosen_join_path_signature or []
            _record_negative(
                store,
                ikey,
                chosen_sig,
                sql_fp_val,
                norm_reason,
                rejection_category=category,
            )
            if colmap_sig_val:
                _record_negative_colmap(store, colmap_sig_val, norm_reason)
        elif existing_template:
            record_template_feedback(existing_template, accept=False)
            chosen_sig = intent.chosen_join_path_signature or []

            if existing_template.trust_level == 0:
                demote_template_to_rejected(
                    store,
                    templates,
                    rejected,
                    existing_template,
                    schema,
                    intent,
                    sql,
                    q_norm,
                    category,
                    norm_reason,
                )
                debug(f"[pipeline.handle_user_feedback] demoted trust=0 template {existing_template.id}")
            else:
                maybe_demote_trust(existing_template)

            _record_negative(
                store,
                ikey,
                chosen_sig,
                sql_fp_val,
                norm_reason,
                rejection_category=category,
            )
            if colmap_sig_val:
                _record_negative_colmap(store, colmap_sig_val, norm_reason)
        else:
            existing_rejected = find_rejected_by_intent_key(rejected, ikey)
            if existing_rejected:
                increment_rejected_template(existing_rejected, category, norm_reason, q_norm, intent, sql)
                debug(f"[pipeline.handle_user_feedback] incremented rejection for existing {existing_rejected.id}")
            else:
                insert_rejected_template(
                    store, rejected, schema, q_norm, intent, sql, category, norm_reason, dialect=dialect
                )
            chosen_sig = intent.chosen_join_path_signature or []
            _record_negative(
                store,
                ikey,
                chosen_sig,
                sql_fp_val,
                norm_reason,
                rejection_category=category,
            )
            if colmap_sig_val:
                _record_negative_colmap(store, colmap_sig_val, norm_reason)

        store = templates_to_store(store, templates)
        store = rejected_templates_to_store(store, rejected)
        save_template_store(store)
        print("\nFeedback recorded.")
        print("Please rephrase your question.")
        return {
            "category": category or "other",
            "normalized_reason": norm_reason or "",
            "reject_reason": reject_reason if needs_reason else "",
        }


def _most_frequent_natural_language(vh) -> str:
    """Get the most frequently occurring natural_language from a ValueHistory.

    Args:

        vh: A ValueHistory object with a ``natural_language`` list.

    Returns:

        The most common non-empty natural language string, or empty string if none.
    """
    if not vh.natural_language:
        return ""
    non_empty = [nl for nl in vh.natural_language if nl]
    if not non_empty:
        return ""
    counts = Counter(non_empty)
    return counts.most_common(1)[0][0]


def _extract_column_headers(sql: str) -> list[str]:
    """Extract column aliases from aliased SQL SELECT clause.

    Parses the SELECT clause respecting parenthesis depth so that function arguments containing commas are handled correctly.

    Args:

        sql: The SQL string (typically the display SQL with AS aliases added).

    Returns:

        List of alias names (or fallback column/expression names) in SELECT order.
    """
    select_match = re.search(r"\bSELECT\s+(.*?)\s+FROM\b", sql, re.IGNORECASE | re.DOTALL)
    if not select_match:
        return []
    select_clause = select_match.group(1).strip()
    parts = []
    depth = 0
    current = []
    for char in select_clause:
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif char == "," and depth == 0:
            parts.append("".join(current).strip())
            current = []
            continue
        current.append(char)
    if current:
        parts.append("".join(current).strip())
    headers = []
    for part in parts:
        as_match = re.search(r"\bAS\s+(\w+)\s*$", part, re.IGNORECASE)
        if as_match:
            headers.append(as_match.group(1))
        else:
            col_match = re.search(r"\.(\w+)\s*$", part)
            if col_match:
                headers.append(col_match.group(1))
            else:
                headers.append(part.replace(" ", "_"))
    return headers


def handle_direct_sql_reuse(
    q_norm: str,
    ref_tmpl: Template,
    dialect: Any,
    store: dict[str, Any],
    templates: dict[str, Any],
    schema: SchemaGraph,
    engine: Any | None = None,
    existing_nl: str | None = None,
) -> bool:
    """Handle direct SQL reuse path from a matching template.

    Extracts parameters from the question, substitutes them into
    the template SQL, validates, executes, and presents results to
    the user.  Updates trust and value history on acceptance.

    Args:

        q_norm: The normalised user question.
        ref_tmpl: The matching Template to reuse.
        dialect: The database dialect instance for validation and
            execution.
        store: The mutable template store dict.
        templates: The accepted templates dict.
        engine: Optional SQLAlchemy Engine for explain-based
            validation.
        existing_nl: Optional pre-existing natural language summary.

    Returns:

        True if the reuse path completed (accepted or rejected by
        user), False if parameter extraction was incomplete or SQL
        validation failed.
    """
    vh = ref_tmpl.value_history
    matched_idx = -1
    for i, hist_q in enumerate(vh.questions):
        if hist_q and q_norm == hist_q:
            matched_idx = i
            break

    if matched_idx >= 0:
        new_params = dict(vh.param_values[matched_idx])
        debug(f"[pipeline.handle_direct_sql_reuse] zero_distance_match: index={matched_idx}")
    else:
        new_params = _llm_extract_reuse_params(q_norm, ref_tmpl)
        debug(f"[pipeline.handle_direct_sql_reuse] llm_reuse_extraction: {len(new_params)} params")
        if not has_non_default_structural(ref_tmpl):
            for sk, sv in ref_tmpl.structural_defaults.items():
                new_params.setdefault(sk, sv)
            debug(
                f"[pipeline.handle_direct_sql_reuse] backfilled_structural_defaults: {len(ref_tmpl.structural_defaults)} keys"
            )

    p_count = len(re.findall(r":p\d+", ref_tmpl.sql_param))
    s_count = len(re.findall(r":s\d+", ref_tmpl.sql_param))
    expected_param_count = p_count + s_count

    if len(new_params) < expected_param_count:
        debug(
            f"[pipeline.handle_direct_sql_reuse] param_extraction_incomplete: {len(new_params)}/{expected_param_count}"
        )
        return False

    sql = substitute_params(ref_tmpl.sql_param, new_params)
    debug(f"[pipeline.handle_direct_sql_reuse] params_substituted: {new_params}")
    debug(f"[pipeline.handle_direct_sql_reuse] final_sql: {sql}")

    reuse_nl = existing_nl if existing_nl else _most_frequent_natural_language(ref_tmpl.value_history)
    concrete_cte_steps = ref_tmpl.intent_signature.cte_steps or []
    runtime_cte_steps = [concrete_cte_to_runtime(c) for c in concrete_cte_steps]

    for cte in runtime_cte_steps:
        keys: set[str] = set()
        for fp in cte.filters_param or []:
            if fp.param_key:
                keys.add(fp.param_key)
        for hp in cte.having_param or []:
            if hp.param_key:
                keys.add(hp.param_key)
        cte.param_values = {k: v for k, v in new_params.items() if k in keys}

    intent = RuntimeIntent(
        tables=ref_tmpl.intent_signature.tables or [],
        grain=ref_tmpl.intent_signature.grain or "row_level",
        select_cols=ref_tmpl.intent_signature.select_cols or [],
        group_by_cols=ref_tmpl.intent_signature.group_by_cols or [],
        order_by_cols=ref_tmpl.intent_signature.order_by_cols or [],
        filters_param=ref_tmpl.intent_signature.filters_param or [],
        having_param=ref_tmpl.intent_signature.having_param or [],
        param_values=new_params,
        cte_steps=runtime_cte_steps,
        column_map=ref_tmpl.intent_signature.column_map or {},
        natural_language=reuse_nl,
        chosen_join_candidate_id=ref_tmpl.chosen_join_candidate_id,
        chosen_join_path_signature=ref_tmpl.chosen_join_path_signature or [],
        sql_display_param=ref_tmpl.sql_display_param,
    )

    ok, err = validate_sql(dialect, sql, engine, intent.param_values)
    if not ok:
        debug(f"[pipeline.handle_direct_sql_reuse] validation_failed: {err}")
        return False

    spark_sql = get_spark_sql_for_execution(
        ref_tmpl.sql_param,
        new_params,
        schema,
        intent,
        dialect,
        spark_sql_param_override=getattr(ref_tmpl, "spark_sql_param", None),
    )
    rows = execute_sql(
        dialect,
        sql,
        spark_sql_for_execution=spark_sql if spark_sql else None,
    )
    ux = ref_tmpl.ux_summary if ref_tmpl.ux_summary else llm_ux_explain(intent, q_norm)
    display_sql = (
        substitute_params(intent.sql_display_param, new_params)
        if intent.sql_display_param and new_params
        else (intent.sql_display_param or sql)
    )

    if ref_tmpl.stats.reject > 0:
        print_query_result(rows, display_sql, ux, headers=_extract_column_headers(display_sql))

        choice = ask_user_choice("\nIs this correct?", ["y", "n"])
        if choice is None or choice != "y":
            debug("[pipeline.handle_direct_sql_reuse] user_rejected_reuse")
            ref_tmpl.stats.reject += 1
            maybe_demote_trust(ref_tmpl)
            save_template_store(store)
            return True

        debug("[pipeline.handle_direct_sql_reuse] user_accepted_reuse")
    else:
        print_query_result(rows, display_sql, ux, headers=_extract_column_headers(display_sql))
        debug("[pipeline.handle_direct_sql_reuse] auto_accepted: reject_count=0")

    save_result_csv(rows, intent, sql)

    ref_tmpl.stats.accept += 1
    promote_trust(ref_tmpl)

    vh = ref_tmpl.value_history
    all_pv = flatten_param_values(intent)
    vh.add(all_pv, q_norm, intent.natural_language)
    store = templates_to_store(store, templates)
    save_template_store(store)
    return True


def confirm_intent_with_user(
    intent: RuntimeIntent,
    store: dict[str, Any],
    semantic_warnings: list[str] | None = None,
    similarity_score: float = 0.0,
    has_union_match: bool = False,
) -> bool:
    """Confirm parsed intent with user before SQL generation.

    Four-branch logic:

    * **warnings present** — print warning and prompt ``Continue? [y/n]``.
    * **union match present** — always prompt ``Is this correct? [y/n]``
      (no auto-proceed).
    * **no warnings/match, high similarity** (≥ ``AUTO_PROCEED_THRESHOLD``)
      — auto-proceed without prompting.
    * **no warnings/match, low similarity** — prompt ``Is this correct? [y/n]``.

    Args:

        intent: The RuntimeIntent to display for confirmation.
        store: The mutable template store dict (saved if user declines).
        semantic_warnings: Optional list of non-fatal warning strings.
        similarity_score: Template similarity score for auto-proceed decision.
        has_union_match: Whether union merge returned a positive match.

    Returns:

        True if the user confirms (or auto-proceeds), False if the user declines.
    """
    nl_summary = intent.natural_language or ""
    if not nl_summary:
        nl_summary = f"Query {', '.join(intent.tables or [])} for data"

    if semantic_warnings:
        print_info(f"Semantic issues were detected. I understood: {nl_summary}")
        intent_choice = ask_user_choice("\nContinue?", ["y", "n"])
        if intent_choice is None or intent_choice != "y":
            debug("[pipeline.confirm_intent_with_user] user_rejected_intent (warnings)")
            save_template_store(store)
            print("\nPlease rephrase your question.")
            return False
        debug("[pipeline.confirm_intent_with_user] user_confirmed_intent (warnings)")
        return True

    if not has_union_match and similarity_score >= PolicyConfig.AUTO_PROCEED_THRESHOLD:
        debug(f"[pipeline.confirm_intent_with_user] auto_proceed: similarity={similarity_score:.3f}")
        return True

    print_info(f"I understood: {nl_summary}")
    intent_choice = ask_user_choice("\nIs this correct?", ["y", "n"])
    if intent_choice is None or intent_choice != "y":
        debug("[pipeline.confirm_intent_with_user] user_rejected_intent")
        save_template_store(store)
        print("\nPlease rephrase your question.")
        return False
    debug("[pipeline.confirm_intent_with_user] user_confirmed_intent")
    return True


def check_and_handle_hard_block(
    rejected: dict[str, Any], ikey: str, intent: RuntimeIntent
) -> tuple[bool, Any | None, Any | None, bool]:
    """Check for hard-blocked rejected templates and prompt user override.

    Args:

        rejected: The rejected templates dict.
        ikey: The current intent key.
        intent: The RuntimeIntent for similarity matching.

    Returns:

        Tuple of ``(hard_block_override, hard_block_rejected_template, matched_rejected_template, proceed)`` where ``proceed`` is False if the user declined the override prompt.
    """
    hard_block_override = False

    hard_block_info = get_aggregated_hard_block_info(rejected, intent, similarity_threshold=0.70)
    debug(
        "[pipeline.check_and_handle_hard_block] "
        f"aggregated_rejections total={hard_block_info.get('total_rejects', 0)} "
        f"structural={hard_block_info.get('total_structural_rejects', 0)} "
        f"categories={hard_block_info.get('categories', {})}"
    )

    hard_block_rejected_template = find_rejected_by_intent_key(rejected, ikey)
    if not hard_block_rejected_template:
        hard_block_rejected_template = find_rejected_by_similarity(rejected, intent, threshold=0.70)

    matched_rejected_template = find_rejected_by_similarity(
        rejected, intent, threshold=PolicyConfig.AUTO_PROCEED_THRESHOLD
    )

    if hard_block_info["should_block"]:
        blocking_cat = hard_block_info["blocking_category"]
        total_structural = hard_block_info["total_structural_rejects"]

        debug(
            f"[pipeline.check_and_handle_hard_block] HARD-BLOCK triggered: total_structural={total_structural} primary_category={blocking_cat}"
        )
        log(
            f"[HARD-BLOCK] Similar query patterns were rejected {total_structural} times for structural issues (primary: '{blocking_cat}')."
        )

        choice = ask_user_choice(
            f"Similar queries were rejected {total_structural} times for structural errors. Proceed anyways?",
            ["y", "n"],
        )
        if choice is None or choice != "y":
            debug("[pipeline.check_and_handle_hard_block] user_declined_override")
            return False, hard_block_rejected_template, matched_rejected_template, False
        debug("[pipeline.check_and_handle_hard_block] user_override_accepted")
        log("user overrode hard-block; continuing with validation")
        hard_block_override = True
    else:
        debug("[pipeline.check_and_handle_hard_block] no hard block detected")

    return (
        hard_block_override,
        hard_block_rejected_template,
        matched_rejected_template,
        True,
    )


def display_final_results(
    q_norm: str,
    intent: RuntimeIntent,
    sql: str,
    rows: list[tuple],
) -> str:
    """Present final query results with a UX explanation.

    Args:

        q_norm: The normalised user question.
        intent: The RuntimeIntent whose sql_display_param and param_values are used.
        sql: Fallback SQL string if display param is unavailable.
        rows: The query result rows to display.

    Returns:

        The UX explanation string that was displayed.
    """
    ux = llm_ux_explain(intent, q_norm)
    display_sql = (
        substitute_params(intent.sql_display_param, intent.param_values)
        if intent.sql_display_param and intent.param_values
        else (intent.sql_display_param or sql)
    )
    print_query_result(rows, display_sql, ux, headers=_extract_column_headers(display_sql))
    return ux


def save_result_csv(rows: list[tuple], intent: RuntimeIntent, sql: str) -> None:
    """Save query results to CSV with column headers.

    Skips saving for scalar-grain queries.
    Writes column headers extracted from the aliased display SQL before the data rows.

    Args:

        rows: The query result rows to write.
        intent: The RuntimeIntent providing grain and display SQL.
        sql: Fallback SQL string if display param is unavailable.
    """
    if intent.grain == "scalar":
        return
    display_sql = (
        substitute_params(intent.sql_display_param, intent.param_values)
        if intent.sql_display_param and intent.param_values
        else (intent.sql_display_param or sql)
    )
    output_path = os.path.join(os.getcwd(), "results.csv")
    with open(output_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        headers = _extract_column_headers(display_sql)
        if headers:
            writer.writerow(headers)
        writer.writerows(rows)
    log(f"results saved to {output_path}")


def _shape_distance(a: SQLShape, b: SQLShape) -> float:
    """Compute distance between two SQL shapes.

    Args:

        a: The expected SQLShape.
        b: The actual SQLShape.

    Returns:

        Float in [0, 1] combining normalised join-count difference, group-by mismatch, and aggregation mismatch, each weighted by 1/3.
    """
    d = 0.0
    d += (1.0 / 3.0) * min(1.0, abs(a.num_joins - b.num_joins) / 4.0)
    d += (1.0 / 3.0) * (0.0 if a.has_group_by == b.has_group_by else 1.0)
    d += (1.0 / 3.0) * (0.0 if a.has_agg == b.has_agg else 1.0)
    return d


def _negative_penalty(
    store: dict[str, Any],
    ikey: str,
    join_sig: list[str],
    sql_fp: str,
) -> float:
    """Compute total penalty from rejection history.

    Looks up rejection counts across by_intent_key, by_join_sig, and by_sql_fp buckets and applies configured per-rejection weights.

    Args:

        store: The template store dict containing ``negative_memory``.
        ikey: The intent key string.
        join_sig: The chosen join path signature list.
        sql_fp: The SQL fingerprint string.

    Returns:

        Capped penalty float.
    """
    mem = store.get("negative_memory", {})
    js_str = join_sig_string(join_sig)
    by_ikey = mem.get("by_intent_key", {}).get(ikey, {})
    by_js = mem.get("by_join_sig", {}).get(js_str, {})
    by_fp = mem.get("by_sql_fp", {}).get(sql_fp, {})

    pen = 0.0
    ikey_rejects = int(by_ikey.get("rejects", 0))
    js_rejects = int(by_js.get("rejects", 0))
    fp_rejects = int(by_fp.get("rejects", 0))

    pen += ikey_rejects * PolicyConfig.PEN_BY_INTENT_KEY
    pen += js_rejects * PolicyConfig.PEN_BY_JOIN_SIG
    pen += fp_rejects * PolicyConfig.PEN_BY_SQL_FP

    result_cats = {"too_many_rows", "too_few_rows"}
    result_rejects = 0
    for b in [by_ikey, by_js, by_fp]:
        cats = b.get("categories", {})
        for rc in result_cats:
            result_rejects += int(cats.get(rc, 0))
    pen += result_rejects * PolicyConfig.PEN_BY_RESULT_ISSUE

    result = float(min(PolicyConfig.PENALTY_CAP, pen))
    debug(f"[pipeline.negative_penalty] rejects: ikey={ikey_rejects} js={js_rejects} fp={fp_rejects}")
    debug(f"[pipeline.negative_penalty] penalty: raw={pen:.3f} capped={result:.3f}")
    return result


def _record_negative(
    store: dict[str, Any],
    ikey: str,
    join_sig: list[str],
    sql_fp: str,
    reason: str,
    rejection_category: str = "",
) -> None:
    """Record rejection in main buckets (intent, join signature, SQL fingerprint).

    Args:

        store: The mutable template store dict.
        ikey: The intent key string.
        join_sig: The chosen join path signature list.
        sql_fp: The SQL fingerprint string.
        reason: The normalised rejection reason.
        rejection_category: The rejection category string (optional).
    """
    debug(f"[pipeline.record_negative] recording: ikey={ikey[:32]} category={rejection_category} reason='{reason}'")

    mem = store.setdefault(
        "negative_memory",
        {"by_intent_key": {}, "by_join_sig": {}, "by_sql_fp": {}, "by_colmap_sig": {}},
    )
    js_str = join_sig_string(join_sig)
    b1 = mem.setdefault("by_intent_key", {}).setdefault(
        ikey, {"rejects": 0, "reasons": [], "last_reason": None, "categories": {}}
    )
    b2 = mem.setdefault("by_join_sig", {}).setdefault(
        js_str, {"rejects": 0, "reasons": [], "last_reason": None, "categories": {}}
    )
    b3 = mem.setdefault("by_sql_fp", {}).setdefault(
        sql_fp, {"rejects": 0, "reasons": [], "last_reason": None, "categories": {}}
    )

    for name, b in [("by_intent_key", b1), ("by_join_sig", b2), ("by_sql_fp", b3)]:
        b["rejects"] = int(b.get("rejects", 0)) + 1
        rs = b.setdefault("reasons", [])
        if isinstance(rs, list):
            rs.append(reason)
        else:
            b["reasons"] = [reason]
        b["last_reason"] = reason
        if rejection_category:
            cats = b.setdefault("categories", {})
            cats[rejection_category] = int(cats.get(rejection_category, 0)) + 1
        debug(f"[pipeline.record_negative] {name}: rejects={b['rejects']} category={rejection_category}")


def _record_negative_colmap(store: dict[str, Any], colmap_sig: str, reason: str, rejection_category: str = "") -> None:
    """Record column mapping rejection in the by_colmap_sig negative memory bucket.

    Args:

        store: The mutable template store dict.
        colmap_sig: The column map signature string.
        reason: The normalised rejection reason.
        rejection_category: The rejection category string (optional).
    """
    debug(f"[pipeline.record_negative_colmap] sig={colmap_sig[:16] if colmap_sig else ''} reason='{reason}'")

    mem = store.setdefault("negative_memory", {})
    mem.setdefault("by_colmap_sig", {})
    b = mem["by_colmap_sig"].setdefault(
        colmap_sig, {"rejects": 0, "reasons": [], "last_reason": None, "categories": {}}
    )
    b["rejects"] = int(b.get("rejects", 0)) + 1
    rs = b.setdefault("reasons", [])
    if isinstance(rs, list):
        rs.append(reason)
    else:
        b["reasons"] = [reason]
    b["last_reason"] = reason
    if rejection_category:
        cats = b.setdefault("categories", {})
        cats[rejection_category] = int(cats.get(rejection_category, 0)) + 1
    debug(f"[pipeline.record_negative_colmap] rejects: {b['rejects']} reason='{reason}'")


def _colmap_penalty(store: dict[str, Any], colmap_sig: str) -> float:
    """Compute penalty for a column mapping based on rejection history.

    Args:

        store: The template store dict containing ``negative_memory``.
        colmap_sig: The column map signature string.

    Returns:

        Capped penalty float, or 0.0 if no rejections recorded for this signature.
    """
    if not colmap_sig:
        debug("[pipeline.colmap_penalty] no_sig")
        return 0.0
    mem = store.get("negative_memory", {})
    b = mem.get("by_colmap_sig", {}).get(colmap_sig, {})
    r = int(b.get("rejects", 0))
    if r <= 0:
        debug(f"[pipeline.colmap_penalty] no_rejects: {colmap_sig[:16]}")
        return 0.0
    result = float(min(PolicyConfig.PENALTY_CAP, r * PolicyConfig.PEN_BY_COLMAP_SIG))
    debug(f"[pipeline.colmap_penalty] penalty: {result:.3f}")
    return result
