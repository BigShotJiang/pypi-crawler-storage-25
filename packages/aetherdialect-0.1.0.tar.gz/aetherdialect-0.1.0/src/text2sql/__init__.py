from importlib.metadata import version

from .text2sql import Text2SQL

__version__ = version("aetherdialect")

__all__ = ["Text2SQL", "__version__"]
