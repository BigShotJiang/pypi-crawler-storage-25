"""Tests for live_testing module: soft assertions, scenario construction, and assertion logic."""

from __future__ import annotations

from types import SimpleNamespace

import pytest

from unittest.mock import MagicMock

from text2sql.live_testing import (
    Expected,
    Scenario,
    SequenceScenario,
    SoftAssert,
    SoftFailure,
    StepResult,
    _assert_scenario,
    _build_reuse_intent,
    _make_auto_responder,
    _make_input_responder,
    run_and_assert,
    run_sequence_and_assert,
)


class TestSoftAssert:
    """Tests for SoftAssert accumulation and reporting."""

    def test_no_failures_passes(self):
        """Empty SoftAssert should report as passed."""
        sa = SoftAssert()
        assert sa.passed is True

    def test_check_true_does_not_record(self):
        """True condition should not record a failure."""
        sa = SoftAssert()
        sa.check(True, "field", "expected", "actual")
        assert sa.passed is True

    def test_check_false_records_failure(self):
        """False condition should record a failure."""
        sa = SoftAssert()
        sa.check(False, "row_count", 10, 5)
        assert sa.passed is False
        assert len(sa.failures) == 1

    def test_multiple_failures_accumulated(self):
        """Multiple failures should all be recorded."""
        sa = SoftAssert()
        sa.check(False, "a", 1, 2)
        sa.check(False, "b", 3, 4)
        sa.check(True, "c", 5, 5)
        assert len(sa.failures) == 2

    def test_report_no_failures_does_nothing(self):
        """Report with no failures should not raise."""
        sa = SoftAssert()
        sa.report("header")

    def test_report_with_failures_raises(self):
        """Report with failures should raise AssertionError."""
        sa = SoftAssert()
        sa.check(False, "x", 1, 2)
        with pytest.raises(AssertionError, match="x"):
            sa.report("Test failed")

    def test_report_includes_header(self):
        """Error message should include the header."""
        sa = SoftAssert()
        sa.check(False, "f", "a", "b")
        with pytest.raises(AssertionError, match="MY HEADER"):
            sa.report("MY HEADER")

    def test_failure_message_default(self):
        """Default message should include field, expected, actual."""
        sa = SoftAssert()
        sa.check(False, "count", 10, 5)
        assert "count" in sa.failures[0].message
        assert "10" in sa.failures[0].message

    def test_failure_custom_message(self):
        """Custom message should be used when provided."""
        sa = SoftAssert()
        sa.check(False, "f", 1, 2, "custom msg here")
        assert sa.failures[0].message == "custom msg here"


class TestSoftFailure:
    """Tests for SoftFailure dataclass."""

    def test_fields_stored(self):
        """All fields should be stored correctly."""
        f = SoftFailure(field="rows", expected=10, actual=5, message="too few")
        assert f.field == "rows"
        assert f.expected == 10
        assert f.actual == 5
        assert f.message == "too few"


class TestExpected:
    """Tests for Expected dataclass construction."""

    def test_defaults_are_none(self):
        """All optional fields should default to None or False."""
        e = Expected()
        assert e.tables is None
        assert e.min_rows is None
        assert e.max_rows is None
        assert e.min_confidence is None
        assert e.reuse_type is None
        assert e.should_hard_block is False
        assert e.should_fail_validation is False

    def test_custom_values(self):
        """Custom values should be stored correctly."""
        e = Expected(
            tables=["orders"],
            min_rows=1,
            max_rows=100,
            min_confidence=0.5,
            contains_join=True,
        )
        assert e.tables == ["orders"]
        assert e.min_rows == 1
        assert e.max_rows == 100
        assert e.contains_join is True


class TestScenario:
    """Tests for Scenario dataclass construction."""

    def test_defaults(self):
        """Default auto_responses and feedback should be set."""
        s = Scenario(id="S-001", question="How many orders?", expected=Expected())
        assert s.feedback == "y"
        assert s.auto_responses is None
        assert s.reject_reason == "incorrect results"

    def test_custom_values(self):
        """Custom values should override defaults."""
        s = Scenario(
            id="S-002",
            question="Count customers",
            expected=Expected(min_rows=1),
            category="aggregation",
            auto_responses=["y", "n"],
            feedback="n",
            reject_reason="wrong tables",
        )
        assert s.category == "aggregation"
        assert s.feedback == "n"
        assert s.auto_responses == ["y", "n"]


class TestSequenceScenario:
    """Tests for SequenceScenario dataclass."""

    def test_stores_steps(self):
        """Steps should be stored as a list."""
        s1 = Scenario(id="S1", question="Q1", expected=Expected())
        s2 = Scenario(id="S2", question="Q2", expected=Expected())
        seq = SequenceScenario(id="SEQ-001", steps=[s1, s2])
        assert len(seq.steps) == 2
        assert seq.steps[0].id == "S1"


class TestStepResult:
    """Tests for StepResult dataclass."""

    def test_defaults(self):
        """Default fields should be sensible."""
        r = StepResult(scenario_id="S1", question="Q?")
        assert r.status == "unknown"
        assert r.intent is None
        assert r.sql is None
        assert r.rows is None
        assert r.hard_blocked is False
        assert r.validation_failed is False

    def test_captured_logs_default_empty(self):
        """captured_logs should default to empty list."""
        r = StepResult(scenario_id="S1", question="Q?")
        assert r.captured_logs == []


class TestMakeAutoResponder:
    """Tests for _make_auto_responder."""

    def test_drains_queue(self):
        """Should return responses in FIFO order."""
        responder = _make_auto_responder(["y", "n", "y"])
        assert responder("Prompt?", ["y", "n"]) == "y"
        assert responder("Prompt?", ["y", "n"]) == "n"
        assert responder("Prompt?", ["y", "n"]) == "y"

    def test_defaults_to_y_when_empty(self):
        """Should return 'y' when queue is exhausted."""
        responder = _make_auto_responder([])
        assert responder("Prompt?", ["y", "n"]) == "y"

    def test_single_response(self):
        """Single item queue should drain then default."""
        responder = _make_auto_responder(["n"])
        assert responder("Prompt?", ["y", "n"]) == "n"
        assert responder("Prompt?", ["y", "n"]) == "y"


class TestMakeInputResponder:
    """Tests for _make_input_responder."""

    def test_first_call_returns_reason(self):
        """First call should return the rejection reason."""
        responder = _make_input_responder("wrong data")
        assert responder("Why?") == "wrong data"

    def test_subsequent_calls_return_n(self):
        """Subsequent calls should return 'n'."""
        responder = _make_input_responder("bad")
        responder("First?")
        assert responder("Second?") == "n"
        assert responder("Third?") == "n"

    def test_default_reason(self):
        """Default reason should be 'incorrect results'."""
        responder = _make_input_responder()
        assert responder("") == "incorrect results"


class TestAssertScenario:
    """Tests for assert_scenario."""

    def _make_result(self, **overrides):
        """Build a StepResult with defaults."""
        defaults = dict(
            scenario_id="S1",
            question="test?",
            status="ok",
            sql="SELECT * FROM orders",
            rows=[(1,), (2,), (3,)],
            confidence=0.85,
            reuse_type="none",
            hard_blocked=False,
            validation_failed=False,
        )
        defaults.update(overrides)
        r = StepResult(**defaults)
        return r

    def test_status_check(self):
        """Status assertion should pass when matching."""
        result = self._make_result(status="ok")
        expected = Expected(status="ok")
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_status_mismatch(self):
        """Status mismatch should record failure."""
        result = self._make_result(status="error")
        expected = Expected(status="ok")
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_status_in_pass(self):
        """status_in should pass when result status in allowed tuple."""
        result = self._make_result(status="validation_failed")
        expected = Expected(status_in=("ok", "validation_failed"))
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_status_in_fail(self):
        """status_in should fail when result status not in tuple."""
        result = self._make_result(status="error")
        expected = Expected(status_in=("ok", "validation_failed"))
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_min_rows_pass(self):
        """min_rows within range should pass."""
        result = self._make_result(rows=[(1,), (2,)])
        expected = Expected(min_rows=1)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_min_rows_fail(self):
        """Too few rows should record failure."""
        result = self._make_result(rows=[])
        expected = Expected(min_rows=1)
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_max_rows_pass(self):
        """max_rows within range should pass."""
        result = self._make_result(rows=[(1,)])
        expected = Expected(max_rows=5)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_max_rows_fail(self):
        """Too many rows should record failure."""
        result = self._make_result(rows=[(i,) for i in range(100)])
        expected = Expected(max_rows=5)
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_min_confidence_pass(self):
        """Confidence above threshold should pass."""
        result = self._make_result(confidence=0.9)
        expected = Expected(min_confidence=0.5)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_min_confidence_fail(self):
        """Confidence below threshold should fail."""
        result = self._make_result(confidence=0.3)
        expected = Expected(min_confidence=0.5)
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_contains_join_true(self):
        """SQL with JOIN should pass when expected."""
        result = self._make_result(sql="SELECT * FROM a JOIN b ON a.id = b.id")
        expected = Expected(contains_join=True)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_contains_join_false(self):
        """SQL without JOIN should pass when expected False."""
        result = self._make_result(sql="SELECT * FROM orders")
        expected = Expected(contains_join=False)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_contains_group_by(self):
        """SQL with GROUP BY should pass when expected."""
        result = self._make_result(sql="SELECT status, COUNT(*) FROM orders GROUP BY status")
        expected = Expected(contains_group_by=True)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_contains_cte(self):
        """SQL starting with WITH should pass cte check."""
        result = self._make_result(sql="WITH x AS (SELECT 1) SELECT * FROM x")
        expected = Expected(contains_cte=True)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_sql_contains(self):
        """sql_contains substrings should all be found."""
        result = self._make_result(sql="SELECT customer_id, SUM(amount) FROM orders GROUP BY customer_id")
        expected = Expected(sql_contains=["customer_id", "SUM"])
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_sql_excludes(self):
        """sql_excludes substrings should not be found."""
        result = self._make_result(sql="SELECT * FROM orders")
        expected = Expected(sql_excludes=["DELETE", "UPDATE"])
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_sql_excludes_fail(self):
        """Found excluded substring should fail."""
        result = self._make_result(sql="SELECT * FROM orders WHERE customer_id = 1")
        expected = Expected(sql_excludes=["customer_id"])
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_should_hard_block(self):
        """Hard block assertion should pass when hard_blocked is
        True."""
        result = self._make_result(hard_blocked=True)
        expected = Expected(should_hard_block=True)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_should_fail_validation(self):
        """Validation failure assertion should pass when
        validation_failed is True."""
        result = self._make_result(validation_failed=True)
        expected = Expected(should_fail_validation=True)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_grain_tuple_pass(self):
        """Grain as tuple should pass when result grain in tuple."""
        from text2sql.contracts_core import RuntimeIntent

        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = self._make_result(intent=intent)
        expected = Expected(grain=("row_level", "grouped"))
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_grain_tuple_fail(self):
        """Grain as tuple should fail when result grain not in tuple."""
        from text2sql.contracts_core import RuntimeIntent

        intent = RuntimeIntent(
            tables=["orders"],
            grain="scalar",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = self._make_result(intent=intent)
        expected = Expected(grain=("row_level", "grouped"))
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_reuse_type_tuple_pass(self):
        """reuse_type as tuple should pass when result in tuple."""
        result = self._make_result(reuse_type="direct_reuse")
        expected = Expected(reuse_type=("direct_reuse", "intent_direct_reuse"))
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_reuse_type_check(self):
        """Reuse type assertion should match."""
        result = self._make_result(reuse_type="direct_reuse")
        expected = Expected(reuse_type="direct_reuse")
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_column_names_pass(self):
        """Column names assertion should pass when matching."""
        from text2sql.contracts_core import NormalizedExpr, RuntimeIntent, SelectCol

        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("title")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = self._make_result(intent=intent, rows=[("Alien",)])
        expected = Expected(column_names_one_of=[["title"]])
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_column_names_fail(self):
        """Column names mismatch should record failure."""
        from text2sql.contracts_core import NormalizedExpr, RuntimeIntent, SelectCol

        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("film_id")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = self._make_result(intent=intent, rows=[(1,)])
        expected = Expected(column_names_one_of=[["title"]])
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_column_names_one_of_multi_option_pass(self):
        """When multiple column sets allowed, matching one passes."""
        from text2sql.contracts_core import NormalizedExpr, RuntimeIntent, SelectCol

        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("first_name")),
                SelectCol(expr=NormalizedExpr.from_column("last_name")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = self._make_result(intent=intent, rows=[("a", "b")])
        expected = Expected(
            column_names_one_of=[
                ["customer_id", "first_name", "last_name"],
                ["first_name", "last_name"],
            ]
        )
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_row_value_check_pass(self):
        """Custom row value check should pass when returning True."""
        result = self._make_result(rows=[(1, "alice"), (2, "bob")])
        expected = Expected(row_value_check=lambda rows: len(rows) == 2)
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_row_value_check_fail(self):
        """Custom row value check should fail when returning False."""
        result = self._make_result(rows=[(1,)])
        expected = Expected(row_value_check=lambda rows: len(rows) > 5)
        soft = _assert_scenario(result, expected)
        assert not soft.passed

    def test_none_fields_skipped(self):
        """None expected fields should be silently skipped."""
        result = self._make_result()
        expected = Expected()
        soft = _assert_scenario(result, expected)
        assert soft.passed

    def test_existing_soft_reused(self):
        """Passing existing SoftAssert should append to it."""
        sa = SoftAssert()
        sa.check(False, "pre", 1, 2)
        result = self._make_result(status="ok")
        expected = Expected(status="ok")
        returned = _assert_scenario(result, expected, soft=sa)
        assert returned is sa
        assert len(returned.failures) == 1


class TestBuildReuseIntent:
    """Tests for _build_reuse_intent."""

    def test_builds_from_template(self):
        """Should construct RuntimeIntent from template
        intent_signature."""
        sig = SimpleNamespace(
            tables=["orders", "customers"],
            grain="grouped",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            column_map={},
        )
        tmpl = SimpleNamespace(intent_signature=sig)
        intent = _build_reuse_intent(tmpl)
        assert intent.tables == ["orders", "customers"]
        assert intent.grain == "grouped"

    def test_handles_none_fields(self):
        """None fields in signature should default to empty."""
        sig = SimpleNamespace(
            tables=None,
            grain=None,
            select_cols=None,
            group_by_cols=None,
            order_by_cols=None,
            filters_param=None,
            having_param=None,
            column_map=None,
        )
        tmpl = SimpleNamespace(intent_signature=sig)
        intent = _build_reuse_intent(tmpl)
        assert intent.tables == []
        assert intent.grain == "row_level"


def _make_passing_result() -> StepResult:
    """Build a StepResult that passes basic assertions."""
    return StepResult(
        scenario_id="T1",
        question="test?",
        status="ok",
        sql="SELECT 1",
        rows=[(1,)],
        confidence=0.9,
    )


def _make_failing_result() -> StepResult:
    """Build a StepResult with zero rows to fail min_rows checks."""
    return StepResult(
        scenario_id="T1",
        question="test?",
        status="ok",
        sql="SELECT 1",
        rows=[],
        confidence=0.9,
    )


class TestRunAndAssert:
    """Tests for the run_and_assert retry wrapper."""

    def test_passes_on_first_attempt(self):
        """No retry needed when assertions pass."""
        runner = MagicMock()
        runner.run.return_value = _make_passing_result()
        scenario = Scenario(id="T1", question="test?", expected=Expected(min_rows=1))
        run_and_assert(runner, scenario, header="[T1]")
        assert runner.run.call_count == 1

    def test_retries_on_failure_then_passes(self):
        """Retry from scratch when first attempt fails assertions."""
        runner = MagicMock()
        runner.run.side_effect = [
            _make_failing_result(),
            _make_passing_result(),
        ]
        scenario = Scenario(id="T1", question="test?", expected=Expected(min_rows=1))
        run_and_assert(runner, scenario, header="[T1]", max_attempts=2)
        assert runner.run.call_count == 2

    def test_raises_after_all_attempts_exhausted(self):
        """AssertionError raised when all retries fail."""
        runner = MagicMock()
        runner.run.return_value = _make_failing_result()
        scenario = Scenario(
            id="T1", question="test?", expected=Expected(min_rows=5)
        )
        with pytest.raises(AssertionError, match="T1"):
            run_and_assert(runner, scenario, header="[T1]", max_attempts=2)
        assert runner.run.call_count == 2

    def test_passes_retries_to_runner(self):
        """Per-attempt pipeline retries forwarded to runner.run."""
        runner = MagicMock()
        runner.run.return_value = _make_passing_result()
        scenario = Scenario(id="T1", question="test?", expected=Expected())
        run_and_assert(runner, scenario, header="[T1]", retries=3)
        runner.run.assert_called_once_with(scenario, retries=3)


class TestRunSequenceAndAssert:
    """Tests for the run_sequence_and_assert retry wrapper."""

    def test_passes_on_first_attempt(self):
        """No retry needed when all steps pass."""
        runner = MagicMock()
        runner.run_sequence.return_value = [
            _make_passing_result(),
            _make_passing_result(),
        ]
        s1 = Scenario(id="S1", question="Q1", expected=Expected(min_rows=1))
        s2 = Scenario(id="S2", question="Q2", expected=Expected(min_rows=1))
        seq = SequenceScenario(id="SEQ", steps=[s1, s2])
        run_sequence_and_assert(runner, seq)
        assert runner.run_sequence.call_count == 1

    def test_retries_entire_sequence_on_failure(self):
        """Full sequence re-runs when any step fails."""
        runner = MagicMock()
        runner.run_sequence.side_effect = [
            [_make_failing_result(), _make_passing_result()],
            [_make_passing_result(), _make_passing_result()],
        ]
        s1 = Scenario(id="S1", question="Q1", expected=Expected(min_rows=1))
        s2 = Scenario(id="S2", question="Q2", expected=Expected(min_rows=1))
        seq = SequenceScenario(id="SEQ", steps=[s1, s2])
        run_sequence_and_assert(runner, seq, max_attempts=2)
        assert runner.run_sequence.call_count == 2

    def test_raises_after_all_attempts_exhausted(self):
        """AssertionError raised when all retries fail."""
        runner = MagicMock()
        runner.run_sequence.return_value = [_make_failing_result()]
        s1 = Scenario(id="S1", question="Q1", expected=Expected(min_rows=5))
        seq = SequenceScenario(id="SEQ", steps=[s1])
        with pytest.raises(AssertionError, match="SEQ"):
            run_sequence_and_assert(runner, seq, max_attempts=2)
        assert runner.run_sequence.call_count == 2
