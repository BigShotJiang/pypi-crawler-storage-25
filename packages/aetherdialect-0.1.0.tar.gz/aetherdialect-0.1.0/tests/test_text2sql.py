"""Tests for text2sql module: high-level API mode management and validation."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from text2sql.contracts_base import QSimRange
from text2sql.text2sql import Text2SQL


def _make_t2s_stub(**overrides):
    """Build a minimal Text2SQL-like stub with schema_stats for unit
    tests."""

    defaults = dict(
        _mode="interactive",
        _api_key_set=True,
        _schema_stats={"table_count": 10, "total_filterable": 40},
    )
    defaults.update(overrides)

    obj = Text2SQL.__new__(Text2SQL)
    for k, v in defaults.items():
        setattr(obj, k, v)
    return obj


class TestSetMode:
    """Tests for Text2SQL.set_mode."""

    def test_valid_modes_accepted(self):
        """All three valid modes should be accepted."""
        t = _make_t2s_stub()
        for mode in ("interactive", "simulator", "qsim"):
            t.set_mode(mode)
            assert t._mode == mode

    def test_invalid_mode_raises(self):
        """Invalid mode should raise ValueError."""
        t = _make_t2s_stub()
        with pytest.raises(ValueError, match="Invalid mode"):
            t.set_mode("batch")

    def test_empty_mode_raises(self):
        """Empty string mode should raise ValueError."""
        t = _make_t2s_stub()
        with pytest.raises(ValueError):
            t.set_mode("")


class TestSetOpenaiApiKey:
    """Tests for Text2SQL.set_openai_api_key."""

    @patch("text2sql.text2sql.EngineConfig")
    def test_valid_key_sets_token(self, mock_config):
        """Non-empty key should be stored."""
        t = _make_t2s_stub()
        t.set_openai_api_key("sk-test123")
        assert t._api_key_set is True

    def test_empty_key_raises(self):
        """Empty key should raise ValueError."""
        t = _make_t2s_stub()
        with pytest.raises(ValueError, match="API key cannot be empty"):
            t.set_openai_api_key("")

    def test_whitespace_key_raises(self):
        """Whitespace-only key should raise ValueError."""
        t = _make_t2s_stub()
        with pytest.raises(ValueError, match="API key cannot be empty"):
            t.set_openai_api_key("   ")


class TestSetEnv:
    """Tests for Text2SQL.set_env."""

    def test_missing_file_raises(self):
        """Non-existent env file should raise FileNotFoundError."""
        t = _make_t2s_stub()
        with pytest.raises(FileNotFoundError):
            t.set_env("/nonexistent/path/env.env")


class TestComputeNumIntentsRange:
    """Tests for Text2SQL._compute_num_intents_range."""

    def test_small_schema(self):
        """Small table count should produce min=5."""
        t = _make_t2s_stub(_schema_stats={"table_count": 3, "total_filterable": 10})
        lo, hi = t._compute_num_intents_range()
        assert lo == 5
        assert hi == 30

    def test_medium_schema(self):
        """Medium table count should use table_count as min."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        lo, hi = t._compute_num_intents_range()
        assert lo == 10
        assert hi == 100

    def test_large_schema_capped(self):
        """Large schema should cap max_intents at 200."""
        t = _make_t2s_stub(_schema_stats={"table_count": 25, "total_filterable": 100})
        lo, hi = t._compute_num_intents_range()
        assert lo == 25
        assert hi == 200


class TestComputeNumQuestionsRange:
    """Tests for Text2SQL._compute_num_questions_range."""

    def test_basic_range(self):
        """Should compute range based on filterable columns."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        lo, hi = t._compute_num_questions_range()
        assert lo >= 10
        assert hi <= 2000

    def test_low_filterable(self):
        """Low filterable count should still produce min >=
        num_intents_min."""
        t = _make_t2s_stub(_schema_stats={"table_count": 3, "total_filterable": 2})
        lo, hi = t._compute_num_questions_range()
        assert lo >= 5


class TestValidateNumIntents:
    """Tests for Text2SQL._validate_num_intents."""

    def test_in_range_passes(self):
        """Value within range should not raise."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        t._validate_num_intents(10)
        t._validate_num_intents(50)
        t._validate_num_intents(100)

    def test_below_range_raises(self):
        """Value below min should raise ValueError."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        with pytest.raises(ValueError, match="num_intents must be"):
            t._validate_num_intents(1)

    def test_above_range_raises(self):
        """Value above max should raise ValueError."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        with pytest.raises(ValueError, match="num_intents must be"):
            t._validate_num_intents(999)


class TestValidateNumQuestions:
    """Tests for Text2SQL._validate_num_questions."""

    def test_in_range_passes(self):
        """Value within range should not raise."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        lo, hi = t._compute_num_questions_range()
        t._validate_num_questions(lo)
        t._validate_num_questions(hi)

    def test_below_range_raises(self):
        """Value below min should raise ValueError."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        with pytest.raises(ValueError, match="num_questions must be"):
            t._validate_num_questions(1)


class TestGetQsimRange:
    """Tests for Text2SQL.get_qsim_range."""

    def test_returns_qsim_range(self):
        """Should return a QSimRange dataclass."""
        t = _make_t2s_stub(_schema_stats={"table_count": 10, "total_filterable": 40})
        result = t.get_qsim_range()
        assert isinstance(result, QSimRange)
        assert len(result.num_intents_range) == 2
        assert len(result.num_questions_range) == 2

    def test_ranges_are_tuples(self):
        """Both ranges should be 2-tuples with min <= max."""
        t = _make_t2s_stub(_schema_stats={"table_count": 5, "total_filterable": 20})
        result = t.get_qsim_range()
        assert result.num_intents_range[0] <= result.num_intents_range[1]
        assert result.num_questions_range[0] <= result.num_questions_range[1]


class TestEnsureApiKey:
    """Tests for Text2SQL._ensure_api_key."""

    @patch("text2sql.text2sql.EngineConfig")
    def test_no_key_raises(self, mock_config):
        """Missing API key should raise RuntimeError."""
        mock_config.API_TOKEN = None
        t = _make_t2s_stub(_api_key_set=False)
        with pytest.raises(RuntimeError, match="OpenAI API key not set"):
            t._ensure_api_key()

    @patch("text2sql.text2sql.EngineConfig")
    def test_key_set_passes(self, mock_config):
        """With API key set, should not raise."""
        mock_config.API_TOKEN = "sk-test"
        t = _make_t2s_stub(_api_key_set=True)
        t._ensure_api_key()


class TestRunModeGuards:
    """Tests for mode-specific run method guards."""

    def test_run_interactive_wrong_mode_raises(self):
        """run_interactive should raise if mode is not interactive."""
        t = _make_t2s_stub(_mode="simulator")
        with pytest.raises(RuntimeError, match="Current mode"):
            t.run_interactive()

    def test_run_simulator_wrong_mode_raises(self):
        """run_simulator should raise if mode is not simulator."""
        t = _make_t2s_stub(_mode="interactive")
        with pytest.raises(RuntimeError, match="Current mode"):
            t.run_simulator("seed.txt")

    def test_run_qsim_wrong_mode_raises(self):
        """run_qsim should raise if mode is not qsim."""
        t = _make_t2s_stub(_mode="interactive")
        with pytest.raises(RuntimeError, match="Current mode"):
            t.run_qsim()


class TestInitValidation:
    """Tests for __init__ engine/mode validation."""

    def test_invalid_engine_raises(self):
        """Invalid engine should raise ValueError at init."""
        with pytest.raises(ValueError, match="Invalid engine"):
            Text2SQL(engine="mysql")

    def test_invalid_mode_raises(self):
        """Invalid mode should raise ValueError at init."""
        with pytest.raises(ValueError, match="Invalid mode"):
            Text2SQL(engine="postgresql", mode="batch")
