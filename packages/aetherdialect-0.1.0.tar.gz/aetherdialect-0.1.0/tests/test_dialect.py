"""Tests for dialect module: SQL dialect abstraction, AST validation, and date rendering."""

from __future__ import annotations

import importlib.util
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from text2sql.dialect import (
    DatabricksDialect,
    Dialect,
    PostgresDialect,
    _ast_structural_valid,
    _normalized_join_pairs_from_sql_ast,
    get_dialect,
    render_date_diff_expr,
    render_date_window_expr,
)


class TestRenderDateDiffExpr:
    """Tests for render_date_diff_expr."""

    def test_postgresql_day_interval(self):
        """PostgreSQL produces INTERVAL for day unit."""
        result = render_date_diff_expr(
            "postgresql", "rental.return_date - rental.rental_date", ">", "day", 7
        )
        assert "INTERVAL '7 days'" in result
        assert ">" in result

    def test_postgresql_singular_day(self):
        """PostgreSQL uses singular 'day' for amount 1."""
        result = render_date_diff_expr("postgresql", "col1 - col2", ">=", "day", 1)
        assert "INTERVAL '1 day'" in result

    def test_databricks_day_numeric(self):
        """Databricks produces numeric comparison for day unit."""
        result = render_date_diff_expr("databricks", "col1 - col2", ">", "day", 7)
        assert result == "(col1 - col2) > 7"

    def test_databricks_week_multiplied(self):
        """Databricks week unit multiplies by 7."""
        result = render_date_diff_expr("databricks", "a - b", ">=", "week", 2)
        assert result == "(a - b) >= 14"


class TestRenderDateWindowExprPostgresql:
    """Tests for render_date_window_expr with postgresql dialect."""

    def test_offset_zero_truncates_current_date(self):
        """Offset 0 should produce DATE_TRUNC for the unit."""
        result = render_date_window_expr("postgresql", "o.order_date", ">=", "month", 0)
        assert result == "o.order_date >= DATE_TRUNC('month', CURRENT_DATE)"

    def test_offset_zero_day(self):
        """Offset 0 with day unit."""
        result = render_date_window_expr("postgresql", "t.created", ">=", "day", 0)
        assert result == "t.created >= DATE_TRUNC('day', CURRENT_DATE)"

    def test_offset_zero_year(self):
        """Offset 0 with year unit."""
        result = render_date_window_expr("postgresql", "col", "<", "year", 0)
        assert result == "col < DATE_TRUNC('year', CURRENT_DATE)"

    def test_positive_offset_interval(self):
        """Positive offset should produce INTERVAL subtraction."""
        result = render_date_window_expr("postgresql", "d.ts", ">=", "day", 7)
        assert result == "d.ts >= CURRENT_DATE - INTERVAL '7 days'"

    def test_week_offset(self):
        """Week offset should use week unit in INTERVAL."""
        result = render_date_window_expr("postgresql", "col", ">=", "week", 2)
        assert result == "col >= CURRENT_DATE - INTERVAL '2 weeks'"

    def test_month_offset(self):
        """Month offset should use month unit in INTERVAL."""
        result = render_date_window_expr("postgresql", "col", "<", "month", 3)
        assert result == "col < CURRENT_DATE - INTERVAL '3 months'"

    def test_year_offset(self):
        """Year offset should use year unit in INTERVAL."""
        result = render_date_window_expr("postgresql", "col", ">=", "year", 1)
        assert result == "col >= CURRENT_DATE - INTERVAL '1 year'"

    def test_offset_zero_week(self):
        """Offset 0 with week unit uses DATE_TRUNC week."""
        result = render_date_window_expr("postgresql", "col", ">=", "week", 0)
        assert result == "col >= DATE_TRUNC('week', CURRENT_DATE)"

    def test_positive_offset_day_interval(self):
        """Positive day offset produces INTERVAL 'N days'."""
        result = render_date_window_expr("postgresql", "d.col", "<", "day", 1)
        assert result == "d.col < CURRENT_DATE - INTERVAL '1 day'"


class TestRenderDateWindowExprDatabricks:
    """Tests for render_date_window_expr with databricks dialect."""

    def test_offset_zero_truncates_current_date(self):
        """Offset 0 should produce date_trunc for the unit."""
        result = render_date_window_expr("databricks", "o.order_date", ">=", "month", 0)
        assert result == "o.order_date >= date_trunc('month', current_date())"

    def test_day_offset(self):
        """Day offset should produce date_sub."""
        result = render_date_window_expr("databricks", "col", ">=", "day", 7)
        assert result == "col >= date_sub(current_date(), 7)"

    def test_week_offset(self):
        """Week offset should multiply by 7 and use date_sub."""
        result = render_date_window_expr("databricks", "col", ">=", "week", 2)
        assert result == "col >= date_sub(current_date(), 14)"

    def test_month_offset(self):
        """Month offset should use add_months with negative value."""
        result = render_date_window_expr("databricks", "col", ">=", "month", 3)
        assert result == "col >= add_months(current_date(), -3)"

    def test_year_offset(self):
        """Year offset should use add_months with months =
        -offset*12."""
        result = render_date_window_expr("databricks", "col", ">=", "year", 1)
        assert result == "col >= add_months(current_date(), -12)"

    def test_year_offset_multiple(self):
        """Multiple year offset converts to months correctly."""
        result = render_date_window_expr("databricks", "col", "<", "year", 3)
        assert result == "col < add_months(current_date(), -36)"

    def test_unknown_unit_defaults_to_date_sub(self):
        """Unknown unit should fall back to date_sub with raw offset."""
        result = render_date_window_expr("databricks", "col", ">=", "quarter", 2)
        assert result == "col >= date_sub(current_date(), 2)"

    def test_offset_zero_week(self):
        """Offset 0 with week unit uses date_trunc."""
        result = render_date_window_expr("databricks", "col", ">=", "week", 0)
        assert result == "col >= date_trunc('week', current_date())"

    def test_offset_zero_year(self):
        """Offset 0 with year unit uses date_trunc."""
        result = render_date_window_expr("databricks", "col", "<", "year", 0)
        assert result == "col < date_trunc('year', current_date())"


class TestGetDialect:
    """Tests for get_dialect factory function."""

    @patch("text2sql.dialect.EngineConfig")
    def test_postgresql_returns_postgres_dialect(self, mock_config):
        """Requesting postgresql should return PostgresDialect
        instance."""
        mock_runtime = SimpleNamespace(
            HOST="localhost",
            PORT=5432,
            USER="test",
            PASSWORD="test",
            DATABASE="testdb",
            SCHEMA="public",
        )
        mock_runtime.db_url = lambda: "postgresql://test:test@localhost:5432/testdb"
        mock_config.TYPE = "postgresql"
        mock_config.RUNTIME = mock_runtime

        with patch("sqlalchemy.create_engine"):
            d = get_dialect("postgresql", mock_runtime)
        assert isinstance(d, PostgresDialect)
        assert d.name == "postgresql"

    def test_unsupported_raises_value_error(self):
        """Unsupported dialect name should raise ValueError."""
        with pytest.raises(ValueError, match="Unsupported dialect"):
            get_dialect("mysql", MagicMock())

    @patch("text2sql.dialect.EngineConfig")
    def test_none_engine_type_uses_config_type(self, mock_config):
        """get_dialect with engine_type None uses EngineConfig.TYPE."""
        mock_runtime = SimpleNamespace(
            HOST="localhost",
            PORT=5432,
            USER="u",
            PASSWORD="p",
            DATABASE="d",
            SCHEMA="public",
        )
        mock_runtime.db_url = lambda: "postgresql://u:p@localhost:5432/d"
        mock_config.TYPE = "postgresql"
        mock_config.RUNTIME = mock_runtime
        with patch("sqlalchemy.create_engine"):
            d = get_dialect(engine_type=None, config=mock_runtime)
        assert isinstance(d, PostgresDialect)


class TestDialectBase:
    """Tests for abstract Dialect base class."""

    def test_ast_validate_raises_not_implemented(self):
        """Base ast_validate should raise NotImplementedError."""
        d = Dialect(config=MagicMock())
        with pytest.raises(NotImplementedError):
            d.ast_validate("SELECT 1")

    def test_extract_join_pairs_raises_not_implemented(self):
        """Base extract_join_pairs should raise NotImplementedError."""
        d = Dialect(config=MagicMock())
        with pytest.raises(NotImplementedError):
            d.extract_join_pairs("SELECT 1")

    def test_extract_cte_bodies_raises_not_implemented(self):
        """Base extract_cte_bodies should raise NotImplementedError."""
        d = Dialect(config=MagicMock())
        with pytest.raises(NotImplementedError):
            d.extract_cte_bodies("SELECT 1")

    def test_explain_sql_raises_not_implemented(self):
        """Base explain_sql should raise NotImplementedError."""
        d = Dialect(config=MagicMock())
        with pytest.raises(NotImplementedError):
            d.explain_sql(MagicMock(), "SELECT 1")

    def test_reflect_enums_raises_not_implemented(self):
        """Base reflect_enums should raise NotImplementedError."""
        d = Dialect(config=MagicMock())
        with pytest.raises(NotImplementedError):
            d.reflect_enums(MagicMock(), "public")

    def test_name_attribute(self):
        """Base dialect name attribute should be 'base'."""
        d = Dialect(config=MagicMock())
        assert d.name == "base"


class TestExtractCteBodyDepthTracking:
    """Tests for _extract_cte_bodies_depth_tracking via
    PostgresDialect."""

    def _make_dialect(self):
        """Create a PostgresDialect with mocked engine."""
        with patch("sqlalchemy.create_engine"):
            mock_runtime = SimpleNamespace(
                HOST="localhost",
                PORT=5432,
                USER="u",
                PASSWORD="p",
                DATABASE="db",
                SCHEMA="public",
            )
            mock_runtime.db_url = lambda: "postgresql://u:p@localhost:5432/db"
            d = PostgresDialect(mock_runtime)
        return d

    def test_no_with_returns_empty(self):
        """SQL without WITH should return empty dict."""
        d = self._make_dialect()
        assert d._extract_cte_bodies_depth_tracking("SELECT 1") == {}

    def test_single_cte(self):
        """Single CTE body should be extracted."""
        d = self._make_dialect()
        sql = "WITH active AS (SELECT customer_id FROM customers WHERE active = true) SELECT * FROM active"
        result = d._extract_cte_bodies_depth_tracking(sql)
        assert "active" in result
        assert "customer_id" in result["active"]

    def test_multiple_ctes(self):
        """Multiple CTEs should all be extracted."""
        d = self._make_dialect()
        sql = (
            "WITH cte1 AS (SELECT a FROM t1), "
            "cte2 AS (SELECT b FROM t2) "
            "SELECT * FROM cte1 JOIN cte2 ON cte1.a = cte2.b"
        )
        result = d._extract_cte_bodies_depth_tracking(sql)
        assert "cte1" in result
        assert "cte2" in result

    def test_nested_parens_in_cte(self):
        """CTE containing nested parentheses should be handled."""
        d = self._make_dialect()
        sql = "WITH x AS (SELECT a FROM t WHERE a IN (1, 2, 3)) SELECT * FROM x"
        result = d._extract_cte_bodies_depth_tracking(sql)
        assert "x" in result
        assert "IN (1, 2, 3)" in result["x"]

    def test_string_with_parens_in_cte(self):
        """CTE containing string literals with parens should not break
        parsing."""
        d = self._make_dialect()
        sql = "WITH x AS (SELECT a FROM t WHERE name = 'test(val)') SELECT * FROM x"
        result = d._extract_cte_bodies_depth_tracking(sql)
        assert "x" in result

    def test_cte_name_lowercased(self):
        """CTE names should be lowercased in result keys."""
        d = self._make_dialect()
        sql = "WITH MyData AS (SELECT 1 AS id) SELECT * FROM MyData"
        result = d._extract_cte_bodies_depth_tracking(sql)
        assert "mydata" in result


class TestAstStructuralValid:
    """Tests for _ast_structural_valid (PostgreSQL pglast-based)."""

    @pytest.fixture(autouse=True)
    def _skip_if_no_pglast(self):
        """Skip tests when pglast is not available."""
        try:
            if importlib.util.find_spec("pglast") is None:
                pytest.skip("pglast not installed")
        except ImportError:
            pytest.skip("pglast not installed")

    @patch("text2sql.dialect.EngineConfig")
    def test_simple_select_passes(self, mock_config):
        """Simple SELECT should pass validation."""
        mock_config.TYPE = "postgresql"
        ok, err = _ast_structural_valid("SELECT customer_id, name FROM customers")
        assert ok is True
        assert err == ""

    @patch("text2sql.dialect.EngineConfig")
    def test_select_with_join_passes(self, mock_config):
        """SELECT with JOIN should pass validation."""
        mock_config.TYPE = "postgresql"
        sql = "SELECT o.order_id, c.name FROM orders o JOIN customers c ON o.customer_id = c.customer_id"
        ok, err = _ast_structural_valid(sql)
        assert ok is True

    @patch("text2sql.dialect.EngineConfig")
    def test_multiple_statements_rejected(self, mock_config):
        """Multiple statements should be rejected."""
        mock_config.TYPE = "postgresql"
        ok, err = _ast_structural_valid("SELECT 1; SELECT 2")
        assert ok is False
        assert err == "multiple_statements"

    @patch("text2sql.dialect.EngineConfig")
    def test_non_select_rejected(self, mock_config):
        """Non-SELECT statements should be rejected."""
        mock_config.TYPE = "postgresql"
        ok, err = _ast_structural_valid("INSERT INTO t VALUES (1)")
        assert ok is False
        assert err == "not_select"

    @patch("text2sql.dialect.EngineConfig")
    def test_cte_select_passes(self, mock_config):
        """CTE with simple SELECT should pass."""
        mock_config.TYPE = "postgresql"
        sql = "WITH active AS (SELECT customer_id FROM customers WHERE active = true) SELECT * FROM active"
        ok, err = _ast_structural_valid(sql)
        assert ok is True

    @patch("text2sql.dialect.EngineConfig")
    def test_parse_error_returns_ast_parse_failed(self, mock_config):
        """Malformed SQL should return ast_parse_failed."""
        mock_config.TYPE = "postgresql"
        ok, err = _ast_structural_valid("NOT VALID SQL AT ALL %%%")
        assert ok is False
        assert err == "ast_parse_failed"


class TestNormalizedJoinPairsFromSqlAst:
    """Tests for _normalized_join_pairs_from_sql_ast."""

    @pytest.fixture(autouse=True)
    def _skip_if_no_pglast(self):
        """Skip tests when pglast is not available."""
        try:
            if importlib.util.find_spec("pglast") is None:
                pytest.skip("pglast not installed")
        except ImportError:
            pytest.skip("pglast not installed")

    @patch("text2sql.dialect.EngineConfig")
    def test_simple_join(self, mock_config):
        """Simple two-table join should extract one pair."""
        mock_config.TYPE = "postgresql"
        sql = "SELECT o.order_id FROM orders o JOIN customers c ON o.customer_id = c.customer_id"
        ok, pairs = _normalized_join_pairs_from_sql_ast(sql)
        assert ok is True
        assert len(pairs) == 1
        pair = list(pairs)[0]
        assert "customer_id" in pair[0] or "customer_id" in pair[1]

    @patch("text2sql.dialect.EngineConfig")
    def test_empty_sql_returns_false(self, mock_config):
        """Empty SQL should return (False, empty set)."""
        mock_config.TYPE = "postgresql"
        ok, pairs = _normalized_join_pairs_from_sql_ast("")
        assert ok is False
        assert pairs == set()

    @patch("text2sql.dialect.EngineConfig")
    def test_where_clause_eq_join(self, mock_config):
        """Equality in WHERE clause should be extracted as join pair."""
        mock_config.TYPE = "postgresql"
        sql = "SELECT * FROM orders o, customers c WHERE o.customer_id = c.customer_id"
        ok, pairs = _normalized_join_pairs_from_sql_ast(sql)
        assert ok is True
        assert len(pairs) >= 1


class TestPrepareForExecution:
    """Tests for DatabricksDialect.prepare_for_execution."""

    def _make_dialect(self):
        """Create a DatabricksDialect with mocked internals."""
        mock_config = SimpleNamespace(CATALOG="dev", SCHEMA="dvdrental", DEBUG=False)
        d = DatabricksDialect.__new__(DatabricksDialect)
        d.config = mock_config
        return d

    def test_qualifies_table_references(self):
        """prepare_for_execution qualifies table references."""
        d = self._make_dialect()
        result = d.prepare_for_execution("SELECT * FROM customers")
        assert "dev" in result
        assert "dvdrental" in result
        assert "customers" in result


class TestQualifyTableReferences:
    """Tests for DatabricksDialect._qualify_table_references."""

    def _make_dialect(self):
        """Create a DatabricksDialect with mocked internals."""
        mock_config = SimpleNamespace(CATALOG="dev", SCHEMA="dvdrental", DEBUG=False)
        d = DatabricksDialect.__new__(DatabricksDialect)
        d.config = mock_config
        return d

    def test_from_clause_qualified(self):
        """Table in FROM should get catalog.schema prefix."""
        d = self._make_dialect()
        result = d._qualify_table_references("SELECT * FROM customers")
        assert "dev" in result
        assert "dvdrental" in result
        assert "customers" in result

    def test_join_clause_qualified(self):
        """Table in JOIN should get catalog.schema prefix."""
        d = self._make_dialect()
        result = d._qualify_table_references("SELECT * FROM orders JOIN customers ON orders.id = customers.id")
        assert result.count("dev") >= 2

    def test_extract_from_max_not_catalog_qualified(self):
        """Do not qualify MAX after EXTRACT(... FROM ...)."""
        d = self._make_dialect()
        sql = (
            "SELECT EXTRACT(YEAR FROM MAX(rental.rental_date)) AS y "
            "FROM rental GROUP BY rental.customer_id"
        )
        result = d._qualify_table_references(sql)
        assert "`dev`.`dvdrental`.`MAX`" not in result
        assert "`dev`.`dvdrental`.`rental`" in result


class TestRenderDateWindowExprEdgeCases:
    """Edge case tests for render_date_window_expr."""

    def test_different_operators(self):
        """Different comparison operators should be preserved."""
        for op in [">=", "<=", ">", "<"]:
            result = render_date_window_expr("postgresql", "col", op, "day", 1)
            assert f"col {op} " in result

    def test_zero_offset_with_different_ops(self):
        """Zero offset with various operators should all produce
        DATE_TRUNC."""
        for op in [">=", "<"]:
            result = render_date_window_expr("postgresql", "col", op, "week", 0)
            assert "DATE_TRUNC" in result
