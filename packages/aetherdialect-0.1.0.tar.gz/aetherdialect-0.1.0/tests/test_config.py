"""Tests for config module constants and normalization functions."""

import re

import pytest

from text2sql.config import (
    AGG_PATTERN,
    AGG_QUANTITY_RE,
    AGGREGATION_ALLOWED_COLUMN_TYPES,
    BOOLEAN_FILTER_OPS,
    CATEGORICAL_FILTER_OPS,
    COLUMN_TYPE_TO_VALUE_TYPE,
    FK_FILTER_OPS,
    INTENT_SCHEMA,
    NUMERIC_CATEGORICAL_FILTER_OPS,
    NUMERIC_FILTER_OPS,
    NUMERIC_ONLY_AGGREGATIONS,
    ROLE_ALLOWED_AGGREGATIONS,
    SCALAR_FUNCTIONS_AGG_COMPATIBLE,
    SCALAR_FUNCTIONS_LEADING_ARG,
    SCALAR_FUNCTIONS_NUMERIC,
    SCALAR_FUNCTIONS_STRING,
    SCALAR_FUNCTIONS_TEMPORAL,
    TABLE_COL_PATTERN,
    TEMPORAL_FILTER_OPS,
    VALID_AGGREGATION_FUNCTIONS,
    VALID_ARITH_OPS,
    VALID_DATE_DIFF_UNITS,
    VALID_DATE_WINDOW_UNITS,
    VALID_EXPECTED_ROWS,
    VALID_FILTER_OPS,
    VALID_FILTER_VALUE_TYPES,
    VALID_GRAINS,
    VALID_HAVING_OPS,
    VALID_HAVING_VALUE_TYPES,
    VALID_SCALAR_FUNCTIONS,
    VALID_VALUE_TYPES,
    VALUE_TYPE_NORMALIZATION,
    DatabricksRuntimeConfig,
    EngineConfig,
    PolicyConfig,
    PostgresRuntimeConfig,
    QSimConfig,
    SimulatorConfig,
    normalize_column_type,
    normalize_value_type,
)


class TestNormalizeColumnType:
    """Tests for normalize_column_type."""

    def test_strips_parenthesized_params(self):
        """normalize_column_type strips (N) from types."""
        assert normalize_column_type("VARCHAR(255)") == "varchar"
        assert normalize_column_type("NUMERIC(10,2)") == "numeric"

    def test_lowercases(self):
        """normalize_column_type lowercases."""
        assert normalize_column_type("INTEGER") == "integer"

    def test_strips_whitespace(self):
        """normalize_column_type strips whitespace."""
        assert normalize_column_type("  text  ") == "text"

    def test_no_params(self):
        """normalize_column_type with no params."""
        assert normalize_column_type("bigint") == "bigint"

    def test_empty_string_returns_empty(self):
        """normalize_column_type with empty string returns empty string."""
        assert normalize_column_type("") == ""

    def test_single_digit_in_parens(self):
        """normalize_column_type strips single numeric param."""
        assert normalize_column_type("char(1)") == "char"

    def test_complex_whitespace_after_strip(self):
        """normalize_column_type normalizes type with internal spaces in parens."""
        assert normalize_column_type("numeric(10, 2)") == "numeric"

    def test_parens_only_strips_to_empty(self):
        """normalize_column_type strips to empty when only parens and digits."""
        assert normalize_column_type("(10)") == ""

    def test_multiple_paren_groups_stripped(self):
        """normalize_column_type strips first parenthesized group only."""
        result = normalize_column_type("decimal(10,2)")
        assert result == "decimal"


class TestNormalizeValueType:
    """Tests for normalize_value_type."""

    def test_timestamp_to_date(self):
        """normalize_value_type maps timestamp -> date."""
        assert normalize_value_type("timestamp") == "date"

    def test_numeric_to_number(self):
        """normalize_value_type maps numeric -> number."""
        assert normalize_value_type("numeric") == "number"

    def test_varchar_to_string(self):
        """normalize_value_type maps varchar -> string."""
        assert normalize_value_type("varchar") == "string"

    def test_bool_to_boolean(self):
        """normalize_value_type maps bool -> boolean."""
        assert normalize_value_type("bool") == "boolean"

    def test_already_valid(self):
        """normalize_value_type passes through already valid types."""
        assert normalize_value_type("integer") == "integer"
        assert normalize_value_type("string") == "string"
        assert normalize_value_type("date") == "date"

    def test_empty_to_string(self):
        """normalize_value_type maps empty to string."""
        assert normalize_value_type("") == "string"

    def test_unknown_to_string(self):
        """normalize_value_type maps unknown to string."""
        assert normalize_value_type("xml_blob") == "string"

    def test_case_insensitive(self):
        """normalize_value_type is case-insensitive."""
        assert normalize_value_type("TIMESTAMP") == "date"
        assert normalize_value_type("Integer") == "integer"

    def test_whitespace_only_returns_string(self):
        """normalize_value_type returns string when input is only whitespace."""
        assert normalize_value_type("   ") == "string"
        assert normalize_value_type("\t\n") == "string"

    def test_stripped_whitespace_around_valid_type(self):
        """normalize_value_type strips leading and trailing whitespace."""
        assert normalize_value_type("  integer  ") == "integer"

    def test_all_value_type_normalization_keys(self):
        """normalize_value_type maps every VALUE_TYPE_NORMALIZATION key."""
        for raw, expected in VALUE_TYPE_NORMALIZATION.items():
            assert normalize_value_type(raw) == expected, f"{raw!r} -> {expected!r}"

    def test_timestamptz_maps_to_date(self):
        """normalize_value_type maps timestamptz to date."""
        assert normalize_value_type("timestamptz") == "date"

    def test_decimal_maps_to_number(self):
        """normalize_value_type maps decimal to number."""
        assert normalize_value_type("decimal") == "number"

    def test_uuid_maps_to_string(self):
        """normalize_value_type maps uuid to string."""
        assert normalize_value_type("uuid") == "string"

    def test_enum_maps_to_string(self):
        """normalize_value_type maps enum to string."""
        assert normalize_value_type("enum") == "string"

    def test_null_passthrough(self):
        """normalize_value_type passes through null as valid type."""
        assert normalize_value_type("null") == "null"


class TestAggQuantityRe:
    """Tests for AGG_QUANTITY_RE regex."""

    def test_more_than_matches(self):
        """AGG_QUANTITY_RE matches 'more than N'."""
        assert AGG_QUANTITY_RE.search("Orders with more than 5 items") is not None
        assert AGG_QUANTITY_RE.search("more than 10") is not None

    def test_at_least_matches(self):
        """AGG_QUANTITY_RE matches 'at least N'."""
        assert AGG_QUANTITY_RE.search("at least 3") is not None

    def test_over_matches(self):
        """AGG_QUANTITY_RE matches 'over N'."""
        assert AGG_QUANTITY_RE.search("over 100") is not None

    def test_less_than_matches(self):
        """AGG_QUANTITY_RE matches 'less than N'."""
        assert AGG_QUANTITY_RE.search("less than 2") is not None

    def test_no_more_than_matches(self):
        """AGG_QUANTITY_RE matches 'no more than N'."""
        assert AGG_QUANTITY_RE.search("no more than 1") is not None

    def test_a_minimum_of_matches(self):
        """AGG_QUANTITY_RE matches 'a minimum of N'."""
        assert AGG_QUANTITY_RE.search("a minimum of 5") is not None

    def test_a_maximum_of_matches(self):
        """AGG_QUANTITY_RE matches 'a maximum of N'."""
        assert AGG_QUANTITY_RE.search("a maximum of 10") is not None

    def test_no_match_without_number(self):
        """AGG_QUANTITY_RE does not match when no number follows phrase."""
        assert AGG_QUANTITY_RE.search("more than many") is None

    def test_case_insensitive(self):
        """AGG_QUANTITY_RE is case-insensitive."""
        assert AGG_QUANTITY_RE.search("MORE THAN 5") is not None

    def test_above_matches(self):
        """AGG_QUANTITY_RE matches 'above N'."""
        assert AGG_QUANTITY_RE.search("above 3") is not None
        assert AGG_QUANTITY_RE.search("customers with above 5 rentals") is not None

    def test_below_matches(self):
        """AGG_QUANTITY_RE matches 'below N'."""
        assert AGG_QUANTITY_RE.search("below 10") is not None
        assert AGG_QUANTITY_RE.search("stores with below 2 employees") is not None


class TestAggPattern:
    """Tests for AGG_PATTERN regex."""

    def test_matches_count(self):
        """AGG_PATTERN matches COUNT(expr)."""
        m = AGG_PATTERN.match("COUNT(table.id)")
        assert m is not None
        assert m.group(1).lower() == "count"
        assert m.group(2) == "table.id"

    def test_matches_sum_with_spaces(self):
        """AGG_PATTERN matches SUM( expr ) with spaces."""
        m = AGG_PATTERN.match("SUM( t.amount )")
        assert m is not None
        assert m.group(1).lower() == "sum"

    def test_no_match_bare_column(self):
        """AGG_PATTERN does not match bare column."""
        assert AGG_PATTERN.match("table.col") is None

    def test_matches_avg_min_max(self):
        """AGG_PATTERN matches AVG, MIN, MAX."""
        for agg in ("AVG", "MIN", "MAX"):
            m = AGG_PATTERN.match(f"{agg}(x)")
            assert m is not None, agg
            assert m.group(1).lower() == agg.lower()


class TestValidAggregationFunctions:
    """Tests for VALID_AGGREGATION_FUNCTIONS constant."""

    def test_exactly_five_functions(self):
        """VALID_AGGREGATION_FUNCTIONS has exactly 5 entries."""
        assert len(VALID_AGGREGATION_FUNCTIONS) == 5

    def test_expected_members(self):
        """VALID_AGGREGATION_FUNCTIONS contains expected members."""
        assert VALID_AGGREGATION_FUNCTIONS == {"count", "sum", "avg", "min", "max"}

    def test_no_count_distinct(self):
        """count_distinct is not in VALID_AGGREGATION_FUNCTIONS."""
        assert "count_distinct" not in VALID_AGGREGATION_FUNCTIONS


class TestRoleAllowedAggregations:
    """Tests for ROLE_ALLOWED_AGGREGATIONS constant."""

    def test_identifier_only_count(self):
        """IDENTIFIER role only allows count."""
        assert ROLE_ALLOWED_AGGREGATIONS["IDENTIFIER"] == {"count"}

    def test_numeric_measure_all(self):
        """NUMERIC_MEASURE role allows all agg functions."""
        assert ROLE_ALLOWED_AGGREGATIONS["NUMERIC_MEASURE"] == {
            "count",
            "sum",
            "avg",
            "min",
            "max",
        }

    def test_audit_empty(self):
        """AUDIT role allows no aggregations."""
        assert ROLE_ALLOWED_AGGREGATIONS["AUDIT"] == set()

    def test_boolean_count_and_sum(self):
        """BOOLEAN role allows count and sum."""
        assert ROLE_ALLOWED_AGGREGATIONS["BOOLEAN"] == {"count", "sum"}

    def test_all_roles_are_subset_of_valid(self):
        """Every role's aggregations are subset of
        VALID_AGGREGATION_FUNCTIONS."""
        for role, aggs in ROLE_ALLOWED_AGGREGATIONS.items():
            assert aggs.issubset(VALID_AGGREGATION_FUNCTIONS), (
                f"{role} has invalid aggs: {aggs - VALID_AGGREGATION_FUNCTIONS}"
            )


class TestNumericOnlyAggregations:
    """Tests for NUMERIC_ONLY_AGGREGATIONS constant."""

    def test_expected_members(self):
        """NUMERIC_ONLY_AGGREGATIONS is sum and avg."""
        assert NUMERIC_ONLY_AGGREGATIONS == {"sum", "avg"}


class TestValidConstants:
    """Tests for constant sets."""

    def test_valid_grains(self):
        """VALID_GRAINS has expected values."""
        assert VALID_GRAINS == {"scalar", "grouped", "row_level"}

    def test_valid_filter_ops_includes_like(self):
        """VALID_FILTER_OPS includes like operators."""
        assert "like" in VALID_FILTER_OPS
        assert "ilike" in VALID_FILTER_OPS

    def test_valid_having_ops_no_like(self):
        """VALID_HAVING_OPS does not include like."""
        assert "like" not in VALID_HAVING_OPS

    def test_valid_value_types(self):
        """VALID_VALUE_TYPES has expected members."""
        for vt in (
            "integer",
            "string",
            "date",
            "number",
            "null",
            "boolean",
            "date_window",
        ):
            assert vt in VALID_VALUE_TYPES

    def test_valid_scalar_functions(self):
        """VALID_SCALAR_FUNCTIONS includes core functions."""
        for f in (
            "upper",
            "lower",
            "trim",
            "abs",
            "round",
            "year",
            "month",
            "day",
            "coalesce",
        ):
            assert f in VALID_SCALAR_FUNCTIONS


class TestPolicyConfig:
    """Tests for PolicyConfig constants."""

    def test_penalty_cap(self):
        """PolicyConfig.PENALTY_CAP is a float."""
        assert isinstance(PolicyConfig.PENALTY_CAP, float)
        assert PolicyConfig.PENALTY_CAP > 0

    def test_structural_reject_categories_subset(self):
        """STRUCTURAL_REJECT_CATEGORIES is subset of
        REJECT_CATEGORIES."""
        all_cats = set(PolicyConfig.REJECT_CATEGORIES)
        assert PolicyConfig.STRUCTURAL_REJECT_CATEGORIES.issubset(all_cats)

    def test_stopwords_excludes_data_terms(self):
        """PolicyConfig.STOPWORDS does not contain data-relevant
        words."""
        assert "count" not in PolicyConfig.STOPWORDS
        assert "total" not in PolicyConfig.STOPWORDS
        assert "sum" not in PolicyConfig.STOPWORDS

    def test_max_repair_loops_positive(self):
        """PolicyConfig.MAX_REPAIR_LOOPS is a positive integer."""
        assert isinstance(PolicyConfig.MAX_REPAIR_LOOPS, int)
        assert PolicyConfig.MAX_REPAIR_LOOPS > 0

    def test_forbidden_sql_is_list_of_patterns(self):
        """PolicyConfig.FORBIDDEN_SQL is a non-empty list of regex
        strings."""
        assert isinstance(PolicyConfig.FORBIDDEN_SQL, list)
        assert len(PolicyConfig.FORBIDDEN_SQL) > 0

    def test_reject_categories_is_list(self):
        """PolicyConfig.REJECT_CATEGORIES is a non-empty list."""
        assert isinstance(PolicyConfig.REJECT_CATEGORIES, list)
        assert len(PolicyConfig.REJECT_CATEGORIES) > 0

    def test_categorical_thresholds_positive(self):
        """Categorical thresholds are positive."""
        assert PolicyConfig.CATEGORICAL_MAX_CARDINALITY > 0
        assert 0 < PolicyConfig.CATEGORICAL_MAX_RATIO < 1

    def test_trust_promote_min_total_positive(self):
        """Trust promote min total is positive."""
        assert PolicyConfig.TRUST_PROMOTE_MIN_TOTAL > 0

    def test_auto_proceed_threshold_in_unit_interval(self):
        """AUTO_PROCEED_THRESHOLD is in (0, 1]."""
        assert 0 < PolicyConfig.AUTO_PROCEED_THRESHOLD <= 1

    def test_final_sql_auto_accept_threshold_in_unit_interval(self):
        """FINAL_SQL_AUTO_ACCEPT_THRESHOLD is in (0, 1]."""
        assert 0 < PolicyConfig.FINAL_SQL_AUTO_ACCEPT_THRESHOLD <= 1

    def test_debug_and_verbose_are_bool(self):
        """PolicyConfig.DEBUG and VERBOSE are booleans."""
        assert isinstance(PolicyConfig.DEBUG, bool)
        assert isinstance(PolicyConfig.VERBOSE, bool)

    def test_regenerate_flags_are_bool(self):
        """REGENERATE flags are booleans."""
        assert isinstance(PolicyConfig.REGENERATE_TEMPLATE_STORE, bool)
        assert isinstance(PolicyConfig.REGENERATE_SCHEMA_GRAPH, bool)
        assert isinstance(PolicyConfig.REGENERATE_SKELETON_CACHE, bool)


class TestValidDateDiffUnits:
    """Tests for VALID_DATE_DIFF_UNITS constant."""

    def test_contains_standard_units(self):
        """VALID_DATE_DIFF_UNITS contains day, week, month, year."""
        assert "day" in VALID_DATE_DIFF_UNITS
        assert "week" in VALID_DATE_DIFF_UNITS
        assert "month" in VALID_DATE_DIFF_UNITS
        assert "year" in VALID_DATE_DIFF_UNITS

    def test_subset_of_date_window_units(self):
        """VALID_DATE_DIFF_UNITS is subset of VALID_DATE_WINDOW_UNITS."""
        from text2sql.config import VALID_DATE_WINDOW_UNITS

        assert VALID_DATE_DIFF_UNITS.issubset(VALID_DATE_WINDOW_UNITS)


class TestPostgresRuntimeConfig:
    """Tests for PostgresRuntimeConfig."""

    def test_default_host(self):
        """Default host is localhost."""
        assert PostgresRuntimeConfig.HOST == "localhost"

    def test_default_port(self):
        """Default port is 5432."""
        assert PostgresRuntimeConfig.PORT == 5432

    def test_default_schema(self):
        """Default schema is public."""
        assert PostgresRuntimeConfig.SCHEMA == "public"

    def test_db_url_raises_without_password(self):
        """db_url raises ValueError when PASSWORD is not set."""
        orig_pw = PostgresRuntimeConfig.PASSWORD
        orig_db = PostgresRuntimeConfig.DATABASE
        try:
            PostgresRuntimeConfig.PASSWORD = None
            PostgresRuntimeConfig.DATABASE = "testdb"
            with pytest.raises(ValueError, match="password"):
                PostgresRuntimeConfig.db_url()
        finally:
            PostgresRuntimeConfig.PASSWORD = orig_pw
            PostgresRuntimeConfig.DATABASE = orig_db

    def test_db_url_raises_without_database(self):
        """db_url raises ValueError when DATABASE is not set."""
        orig_pw = PostgresRuntimeConfig.PASSWORD
        orig_db = PostgresRuntimeConfig.DATABASE
        try:
            PostgresRuntimeConfig.PASSWORD = "pw"
            PostgresRuntimeConfig.DATABASE = None
            with pytest.raises(ValueError, match="database"):
                PostgresRuntimeConfig.db_url()
        finally:
            PostgresRuntimeConfig.PASSWORD = orig_pw
            PostgresRuntimeConfig.DATABASE = orig_db

    def test_db_url_success(self):
        """db_url returns proper connection string when configured."""
        orig_pw = PostgresRuntimeConfig.PASSWORD
        orig_db = PostgresRuntimeConfig.DATABASE
        try:
            PostgresRuntimeConfig.PASSWORD = "secret"
            PostgresRuntimeConfig.DATABASE = "mydb"
            url = PostgresRuntimeConfig.db_url()
            assert "postgresql+psycopg2://" in url
            assert "secret" in url
            assert "mydb" in url
        finally:
            PostgresRuntimeConfig.PASSWORD = orig_pw
            PostgresRuntimeConfig.DATABASE = orig_db


class TestDatabricksRuntimeConfig:
    """Tests for DatabricksRuntimeConfig."""

    def test_validate_raises_without_catalog(self):
        """Validate raises ValueError when CATALOG is not set."""
        orig_cat = DatabricksRuntimeConfig.CATALOG
        orig_sch = DatabricksRuntimeConfig.SCHEMA
        try:
            DatabricksRuntimeConfig.CATALOG = None
            DatabricksRuntimeConfig.SCHEMA = "myschema"
            with pytest.raises(ValueError, match="catalog"):
                DatabricksRuntimeConfig.validate()
        finally:
            DatabricksRuntimeConfig.CATALOG = orig_cat
            DatabricksRuntimeConfig.SCHEMA = orig_sch

    def test_validate_raises_without_schema(self):
        """Validate raises ValueError when SCHEMA is not set."""
        orig_cat = DatabricksRuntimeConfig.CATALOG
        orig_sch = DatabricksRuntimeConfig.SCHEMA
        try:
            DatabricksRuntimeConfig.CATALOG = "mycat"
            DatabricksRuntimeConfig.SCHEMA = None
            with pytest.raises(ValueError, match="schema"):
                DatabricksRuntimeConfig.validate()
        finally:
            DatabricksRuntimeConfig.CATALOG = orig_cat
            DatabricksRuntimeConfig.SCHEMA = orig_sch

    def test_validate_success(self):
        """Validate succeeds when both fields are set."""
        orig_cat = DatabricksRuntimeConfig.CATALOG
        orig_sch = DatabricksRuntimeConfig.SCHEMA
        try:
            DatabricksRuntimeConfig.CATALOG = "mycat"
            DatabricksRuntimeConfig.SCHEMA = "myschema"
            DatabricksRuntimeConfig.validate()
        finally:
            DatabricksRuntimeConfig.CATALOG = orig_cat
            DatabricksRuntimeConfig.SCHEMA = orig_sch


class TestEngineConfig:
    """Tests for EngineConfig."""

    def test_default_type_postgresql(self):
        """Default engine type is postgresql."""
        assert EngineConfig.TYPE == "postgresql"

    def test_runtime_is_postgres_by_default(self):
        """Default runtime class is PostgresRuntimeConfig."""
        assert EngineConfig.RUNTIME is PostgresRuntimeConfig

    def test_schema_json_path(self):
        """SCHEMA_JSON_PATH is a non-empty string."""
        assert isinstance(EngineConfig.SCHEMA_JSON_PATH, str)
        assert len(EngineConfig.SCHEMA_JSON_PATH) > 0

    def test_template_json_path(self):
        """TEMPLATE_JSON_PATH is a non-empty string."""
        assert isinstance(EngineConfig.TEMPLATE_JSON_PATH, str)
        assert len(EngineConfig.TEMPLATE_JSON_PATH) > 0


class TestQSimConfig:
    """Tests for QSimConfig."""

    def test_table_ratios_sum_to_one(self):
        """Single/two/three table ratios sum to 1.0."""
        total = QSimConfig.SINGLE_TABLE_RATIO + QSimConfig.TWO_TABLE_RATIO + QSimConfig.THREE_TABLE_RATIO
        assert abs(total - 1.0) < 1e-9

    def test_max_tables_per_intent_positive(self):
        """MAX_TABLES_PER_INTENT is positive."""
        assert QSimConfig.MAX_TABLES_PER_INTENT > 0

    def test_max_filters_per_intent_positive(self):
        """MAX_FILTERS_PER_INTENT is positive."""
        assert QSimConfig.MAX_FILTERS_PER_INTENT > 0

    def test_questions_output_path_is_non_empty_string(self):
        """QUESTIONS_OUTPUT_PATH is a non-empty string."""
        assert isinstance(QSimConfig.QUESTIONS_OUTPUT_PATH, str)
        assert len(QSimConfig.QUESTIONS_OUTPUT_PATH) > 0

    def test_excluded_filter_patterns_are_valid_regex(self):
        """EXCLUDED_FILTER_PATTERNS are valid regex strings."""
        for pat in QSimConfig.EXCLUDED_FILTER_PATTERNS:
            re.compile(pat)


class TestSimulatorConfig:
    """Tests for SimulatorConfig."""

    def test_max_filters_positive(self):
        """MAX_FILTERS is positive."""
        assert SimulatorConfig.MAX_FILTERS > 0

    def test_max_tables_positive(self):
        """MAX_TABLES is positive."""
        assert SimulatorConfig.MAX_TABLES > 0

    def test_gold_output_pattern_has_version_placeholder(self):
        """GOLD_OUTPUT_PATTERN contains {version}."""
        assert "{version}" in SimulatorConfig.GOLD_OUTPUT_PATTERN

    def test_report_pattern_has_version_placeholder(self):
        """REPORT_PATTERN contains {version}."""
        assert "{version}" in SimulatorConfig.REPORT_PATTERN

    def test_max_expr_comparisons_positive(self):
        """MAX_EXPR_COMPARISONS is positive."""
        assert SimulatorConfig.MAX_EXPR_COMPARISONS > 0

    def test_max_having_conditions_positive(self):
        """MAX_HAVING_CONDITIONS is positive."""
        assert SimulatorConfig.MAX_HAVING_CONDITIONS > 0


class TestIntentSchema:
    """Tests for INTENT_SCHEMA."""

    def test_is_dict(self):
        """INTENT_SCHEMA is a dict."""
        assert isinstance(INTENT_SCHEMA, dict)

    def test_required_includes_tables(self):
        """INTENT_SCHEMA required includes tables."""
        assert "tables" in INTENT_SCHEMA["required"]

    def test_properties_include_filters_param_and_having_param(self):
        """INTENT_SCHEMA properties include filters_param and having_param."""
        props = INTENT_SCHEMA["properties"]
        assert "filters_param" in props
        assert "having_param" in props

    def test_properties_include_cte_steps(self):
        """INTENT_SCHEMA properties include cte_steps."""
        assert "cte_steps" in INTENT_SCHEMA["properties"]

    def test_cte_steps_items_require_cte_name(self):
        """INTENT_SCHEMA cte_steps items require cte_name."""
        cte = INTENT_SCHEMA["properties"]["cte_steps"]["items"]
        assert "cte_name" in cte["required"]


class TestTableColPattern:
    """Tests for TABLE_COL_PATTERN regex."""

    def test_matches_table_dot_column(self):
        """TABLE_COL_PATTERN matches table.column."""
        m = TABLE_COL_PATTERN.match("orders.id")
        assert m is not None
        assert m.group(1) == "orders"
        assert m.group(2) == "id"

    def test_matches_schema_table_dot_column(self):
        """TABLE_COL_PATTERN matches first two word parts (schema.table)."""
        m = TABLE_COL_PATTERN.search("public.orders.id")
        assert m is not None
        assert m.group(1) == "public"
        assert m.group(2) == "orders"

    def test_no_match_without_dot(self):
        """TABLE_COL_PATTERN does not match identifier without dot."""
        assert TABLE_COL_PATTERN.match("tablename") is None


class TestScalarFunctionSets:
    """Tests for SCALAR_FUNCTIONS_* constants."""

    def test_string_subset_of_valid(self):
        """SCALAR_FUNCTIONS_STRING is subset of
        VALID_SCALAR_FUNCTIONS."""
        assert SCALAR_FUNCTIONS_STRING.issubset(VALID_SCALAR_FUNCTIONS)

    def test_numeric_subset_of_valid(self):
        """SCALAR_FUNCTIONS_NUMERIC is subset of
        VALID_SCALAR_FUNCTIONS."""
        assert SCALAR_FUNCTIONS_NUMERIC.issubset(VALID_SCALAR_FUNCTIONS)

    def test_temporal_subset_of_valid(self):
        """SCALAR_FUNCTIONS_TEMPORAL is subset of
        VALID_SCALAR_FUNCTIONS."""
        assert SCALAR_FUNCTIONS_TEMPORAL.issubset(VALID_SCALAR_FUNCTIONS)

    def test_leading_arg_subset_of_valid(self):
        """SCALAR_FUNCTIONS_LEADING_ARG is subset of
        VALID_SCALAR_FUNCTIONS."""
        assert SCALAR_FUNCTIONS_LEADING_ARG.issubset(VALID_SCALAR_FUNCTIONS)

    def test_agg_compatible_subset_of_valid(self):
        """SCALAR_FUNCTIONS_AGG_COMPATIBLE is subset of
        VALID_SCALAR_FUNCTIONS."""
        assert SCALAR_FUNCTIONS_AGG_COMPATIBLE.issubset(VALID_SCALAR_FUNCTIONS)


class TestFilterOpSets:
    """Tests for per-role filter operator sets."""

    def test_boolean_ops_subset_of_valid(self):
        """BOOLEAN_FILTER_OPS is subset of VALID_FILTER_OPS."""
        assert BOOLEAN_FILTER_OPS.issubset(VALID_FILTER_OPS)

    def test_categorical_ops_subset_of_valid(self):
        """CATEGORICAL_FILTER_OPS is subset of VALID_FILTER_OPS."""
        assert CATEGORICAL_FILTER_OPS.issubset(VALID_FILTER_OPS)

    def test_numeric_categorical_ops_subset_of_valid(self):
        """NUMERIC_CATEGORICAL_FILTER_OPS is subset of
        VALID_FILTER_OPS."""
        assert NUMERIC_CATEGORICAL_FILTER_OPS.issubset(VALID_FILTER_OPS)

    def test_numeric_ops_subset_of_valid(self):
        """NUMERIC_FILTER_OPS is subset of VALID_FILTER_OPS."""
        assert NUMERIC_FILTER_OPS.issubset(VALID_FILTER_OPS)

    def test_temporal_ops_subset_of_valid(self):
        """TEMPORAL_FILTER_OPS is subset of VALID_FILTER_OPS."""
        assert TEMPORAL_FILTER_OPS.issubset(VALID_FILTER_OPS)

    def test_fk_ops_subset_of_valid(self):
        """FK_FILTER_OPS is subset of VALID_FILTER_OPS."""
        assert FK_FILTER_OPS.issubset(VALID_FILTER_OPS)

    def test_boolean_no_like(self):
        """BOOLEAN_FILTER_OPS does not include like."""
        assert "like" not in BOOLEAN_FILTER_OPS


class TestMiscConstants:
    """Tests for remaining module-level constant sets."""

    def test_valid_arith_ops(self):
        """VALID_ARITH_OPS has four arithmetic operators."""
        assert VALID_ARITH_OPS == {"+", "-", "*", "/"}

    def test_valid_expected_rows(self):
        """VALID_EXPECTED_ROWS has three values."""
        assert VALID_EXPECTED_ROWS == {"one", "few", "many"}

    def test_valid_date_window_units(self):
        """VALID_DATE_WINDOW_UNITS has expected members."""
        assert VALID_DATE_WINDOW_UNITS == {
            "day",
            "week",
            "month",
            "year",
            "hour",
            "minute",
            "second",
        }

    def test_valid_filter_value_types(self):
        """VALID_FILTER_VALUE_TYPES has expected members."""
        for vt in ("categorical", "numeric", "temporal", "boolean"):
            assert vt in VALID_FILTER_VALUE_TYPES

    def test_valid_having_value_types(self):
        """VALID_HAVING_VALUE_TYPES has expected members."""
        assert VALID_HAVING_VALUE_TYPES == {"number", "integer"}

    def test_value_type_normalization_keys_map_to_valid(self):
        """All VALUE_TYPE_NORMALIZATION values are in
        VALID_VALUE_TYPES."""
        for v in VALUE_TYPE_NORMALIZATION.values():
            assert v in VALID_VALUE_TYPES

    def test_column_type_to_value_type_values_valid(self):
        """All COLUMN_TYPE_TO_VALUE_TYPE values are in
        VALID_VALUE_TYPES."""
        for v in COLUMN_TYPE_TO_VALUE_TYPE.values():
            assert v in VALID_VALUE_TYPES

    def test_aggregation_allowed_keys_match_valid(self):
        """AGGREGATION_ALLOWED_COLUMN_TYPES keys match
        VALID_AGGREGATION_FUNCTIONS."""
        assert set(AGGREGATION_ALLOWED_COLUMN_TYPES.keys()) == VALID_AGGREGATION_FUNCTIONS

    def test_valid_having_ops_subset_of_filter_ops(self):
        """VALID_HAVING_OPS is subset of VALID_FILTER_OPS."""
        assert VALID_HAVING_OPS.issubset(VALID_FILTER_OPS)
