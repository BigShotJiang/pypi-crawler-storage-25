"""Tests for main_execution module: artifact paths, template lists, and obfuscation."""

from __future__ import annotations

import json
import os
import tempfile
from types import SimpleNamespace

import pytest

from text2sql.contracts_base import (
    QSimSummary,
    RejectedTemplateInfo,
    SimulatorSummary,
    TemplateInfo,
)
from text2sql.main_execution import (
    _obfuscate_rejection_category,
    _obfuscate_trust_level,
    get_artifacts_dir,
    get_qsim,
    get_rejected_templates_list,
    get_simulator_summary_from_dir,
    get_templates_list,
    resolve_qsim_path,
)


class TestObfuscateTrustLevel:
    """Tests for _obfuscate_trust_level."""

    def test_high_trust(self):
        """Trust level >= 2 should return 'high'."""
        assert _obfuscate_trust_level(2) == "high"
        assert _obfuscate_trust_level(3) == "high"

    def test_moderate_trust(self):
        """Trust level 1 should return 'moderate'."""
        assert _obfuscate_trust_level(1) == "moderate"

    def test_low_trust(self):
        """Trust level 0 should return 'low'."""
        assert _obfuscate_trust_level(0) == "low"

    def test_negative_trust(self):
        """Negative trust level should return 'low'."""
        assert _obfuscate_trust_level(-1) == "low"


class TestObfuscateRejectionCategory:
    """Tests for _obfuscate_rejection_category."""

    def test_empty_returns_other(self):
        """Empty dict should return 'other'."""
        assert _obfuscate_rejection_category({}) == "other"

    def test_wrong_tables_maps_to_invalid_sql(self):
        """wrong_tables should map to 'invalid_sql'."""
        assert _obfuscate_rejection_category({"wrong_tables": 3}) == "invalid_sql"

    def test_wrong_join_maps_to_invalid_sql(self):
        """wrong_join should map to 'invalid_sql'."""
        assert _obfuscate_rejection_category({"wrong_join": 2}) == "invalid_sql"

    def test_too_many_rows_maps_to_incorrect_results(self):
        """too_many_rows should map to 'incorrect_results'."""
        assert _obfuscate_rejection_category({"too_many_rows": 5}) == "incorrect_results"

    def test_too_few_rows_maps_to_incorrect_results(self):
        """too_few_rows should map to 'incorrect_results'."""
        assert _obfuscate_rejection_category({"too_few_rows": 1}) == "incorrect_results"

    def test_wrong_filters_maps_to_incorrect_results(self):
        """wrong_filters_or_values should map to 'incorrect_results'."""
        assert _obfuscate_rejection_category({"wrong_filters_or_values": 2}) == "incorrect_results"

    def test_wrong_columns_maps_to_incorrect_results(self):
        """wrong_columns_selected should map to 'incorrect_results'."""
        assert _obfuscate_rejection_category({"wrong_columns_selected": 1}) == "incorrect_results"

    def test_wrong_intent_maps_to_ambiguous(self):
        """wrong_intent should map to 'ambiguous_intent'."""
        assert _obfuscate_rejection_category({"wrong_intent": 4}) == "ambiguous_intent"

    def test_unknown_category_maps_to_other(self):
        """Unknown category should map to 'other'."""
        assert _obfuscate_rejection_category({"something_else": 1}) == "other"

    def test_highest_count_wins(self):
        """Category with highest count should determine the result."""
        cats = {"wrong_tables": 1, "too_many_rows": 5}
        assert _obfuscate_rejection_category(cats) == "incorrect_results"


class TestGetTemplatesList:
    """Tests for get_templates_list."""

    def _make_template(self, **overrides):
        """Build a minimal template-like object."""
        defaults = dict(
            id="T001",
            trust_level=1,
            source="simulator",
            intent_key="ik1",
            chosen_join_candidate_id=None,
            sql_fp="fp1",
        )
        defaults.update(overrides)
        tmpl = SimpleNamespace(**defaults)
        tmpl.value_history = SimpleNamespace(
            questions=["what is the total?"],
            natural_language=["total amount"],
            param_values=[{}],
        )
        tmpl.stats = SimpleNamespace(accept=3, reject=0)
        return tmpl

    def test_returns_template_info_list(self):
        """Should return list of TemplateInfo."""
        templates = {"T001": self._make_template()}
        result = get_templates_list(templates)
        assert len(result) == 1
        assert isinstance(result[0], TemplateInfo)

    def test_trust_level_obfuscated(self):
        """Trust level should be obfuscated to string."""
        templates = {"T001": self._make_template(trust_level=2)}
        result = get_templates_list(templates)
        assert result[0].trust_level == "high"

    def test_empty_templates(self):
        """Empty dict should return empty list."""
        assert get_templates_list({}) == []


class TestGetRejectedTemplatesList:
    """Tests for get_rejected_templates_list."""

    def _make_rejected(self, **overrides):
        """Build a minimal rejected template-like object."""
        defaults = dict(id="R001")
        defaults.update(overrides)
        rt = SimpleNamespace(**defaults)
        rt.value_history = SimpleNamespace(
            questions=["bad question"],
            natural_language=["bad nl"],
            param_values=[{}],
            rejection_categories=["wrong_tables", "wrong_tables"],
        )
        return rt

    def test_returns_rejected_info_list(self):
        """Should return list of RejectedTemplateInfo."""
        rejected = {"R001": self._make_rejected()}
        result = get_rejected_templates_list(rejected)
        assert len(result) == 1
        assert isinstance(result[0], RejectedTemplateInfo)

    def test_rejection_count_from_categories(self):
        """Rejection count should match length of
        rejection_categories."""
        rejected = {"R001": self._make_rejected()}
        result = get_rejected_templates_list(rejected)
        assert result[0].rejection_count == 2

    def test_category_obfuscated(self):
        """Rejection category should be obfuscated."""
        rejected = {"R001": self._make_rejected()}
        result = get_rejected_templates_list(rejected)
        assert result[0].rejection_category == "invalid_sql"

    def test_empty_rejected(self):
        """Empty dict should return empty list."""
        assert get_rejected_templates_list({}) == []


class TestGetArtifactsDir:
    """Tests for get_artifacts_dir."""

    def test_postgresql_path_structure(self):
        """PostgreSQL path should contain engine, host, database,
        schema."""
        path = get_artifacts_dir("postgresql", "localhost", "mydb", "public", None)
        assert "postgresql" in path
        assert "localhost" in path
        assert "mydb" in path
        assert "public" in path

    def test_databricks_path_structure(self):
        """Databricks path should contain engine, catalog, schema."""
        path = get_artifacts_dir("databricks", None, None, "dvdrental", "dev")
        assert "databricks" in path
        assert "dev" in path
        assert "dvdrental" in path

    def test_none_values_get_defaults(self):
        """None values should produce default placeholders."""
        path = get_artifacts_dir("postgresql", None, None, None, None)
        assert "localhost" in path

    def test_special_chars_sanitized(self):
        """Dots and dashes should be replaced with underscores."""
        path = get_artifacts_dir("postgresql", "my.host-name", "db", "public", None)
        assert "." not in os.path.basename(path)


class TestResolveQsimPath:
    """Tests for resolve_qsim_path."""

    def test_from_string_timestamp(self):
        """String timestamp should produce correct filename."""
        path = resolve_qsim_path("240101120000", "/artifacts")
        assert path.endswith("qsim_intents_with_questions_240101120000.json")
        assert path.startswith("/artifacts")

    def test_from_qsim_summary(self):
        """QSimSummary should use its timestamp attribute."""
        summary = QSimSummary(timestamp="240615093000", num_intents=10, num_questions=50, seed=42)
        path = resolve_qsim_path(summary, "/out")
        assert "240615093000" in path


class TestGetQsim:
    """Tests for get_qsim."""

    def test_missing_summary_returns_empty(self):
        """Missing summary file should return empty list."""
        with tempfile.TemporaryDirectory() as td:
            result = get_qsim(td)
            assert result == []

    def test_loads_existing_summaries(self):
        """Should load and parse existing summary entries."""
        with tempfile.TemporaryDirectory() as td:
            data = [
                {
                    "timestamp": "240101120000",
                    "num_intents": 5,
                    "num_questions": 20,
                    "seed": 1,
                },
                {
                    "timestamp": "240102120000",
                    "num_intents": 10,
                    "num_questions": 50,
                    "seed": 2,
                },
            ]
            with open(os.path.join(td, "qsim_summary.json"), "w") as f:
                json.dump(data, f)
            result = get_qsim(td)
            assert len(result) == 2
            assert isinstance(result[0], QSimSummary)
            assert result[0].timestamp == "240101120000"


class TestGetSimulatorSummaryFromDir:
    """Tests for get_simulator_summary_from_dir."""

    def test_missing_report_raises(self):
        """Missing report file should raise FileNotFoundError."""
        with tempfile.TemporaryDirectory() as td:
            with pytest.raises(FileNotFoundError):
                get_simulator_summary_from_dir(td, 1)

    def test_loads_valid_report(self):
        """Valid report JSON should produce SimulatorSummary."""
        with tempfile.TemporaryDirectory() as td:
            report = {"total": 10, "success": 8, "failed": 2}
            with open(os.path.join(td, "simulation_report_v1.json"), "w") as f:
                json.dump(report, f)
            result = get_simulator_summary_from_dir(td, 1)
            assert isinstance(result, SimulatorSummary)
            assert result.total == 10
            assert result.success == 8
            assert result.success_rate == 0.8
