"""Tests for qsim_struct module."""

import json
import os

import pytest

from text2sql.config import QSimConfig
from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    FKEdge,
    QSimSkeleton,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import QSimFilter
from text2sql.qsim_struct import (
    _SKELETON_CACHE,
    _is_excluded_filter_column,
    build_fk_adjacency,
    build_schema_context,
    compute_intent_id,
    decompose_between_filter,
    enumerate_table_sets,
    generate_all_skeletons,
    get_aggregatable_columns,
    get_comparable_column_pairs,
    get_filterable_columns,
    get_groupable_columns,
    is_connected,
    load_or_create_skeletons,
    validate_column_exists,
)


@pytest.fixture
def three_table_schema():
    """Schema with customers, orders, products linked by FKs."""
    customers = TableMetadata(
        name="customers",
        columns={
            "id": ColumnMetadata(
                name="id",
                data_type="integer",
                value_type="integer",
                is_primary_key=True,
                role=ColumnRole.IDENTIFIER.value,
                distinct_count=100,
            ),
            "name": ColumnMetadata(
                name="name",
                data_type="varchar",
                value_type="string",
                role=ColumnRole.CATEGORICAL.value,
                distinct_count=50,
            ),
        },
        foreign_keys=[],
        primary_key="",
    )
    orders = TableMetadata(
        name="orders",
        columns={
            "id": ColumnMetadata(
                name="id",
                data_type="integer",
                value_type="integer",
                is_primary_key=True,
                role=ColumnRole.IDENTIFIER.value,
                distinct_count=100,
            ),
            "customer_id": ColumnMetadata(
                name="customer_id",
                data_type="integer",
                value_type="integer",
                is_foreign_key=True,
                role=ColumnRole.IDENTIFIER.value,
                distinct_count=50,
            ),
            "product_id": ColumnMetadata(
                name="product_id",
                data_type="integer",
                value_type="integer",
                is_foreign_key=True,
                role=ColumnRole.IDENTIFIER.value,
                distinct_count=30,
            ),
            "amount": ColumnMetadata(
                name="amount",
                data_type="numeric",
                value_type="number",
                role=ColumnRole.NUMERIC_MEASURE.value,
                distinct_count=80,
            ),
            "status": ColumnMetadata(
                name="status",
                data_type="varchar",
                value_type="string",
                role=ColumnRole.CATEGORICAL.value,
                distinct_count=5,
            ),
        },
        foreign_keys=[
            FKEdge(
                src_table="orders",
                src_cols=["customer_id"],
                dst_table="customers",
                dst_cols=["id"],
            ),
            FKEdge(
                src_table="orders",
                src_cols=["product_id"],
                dst_table="products",
                dst_cols=["id"],
            ),
        ],
        primary_key="",
    )
    products = TableMetadata(
        name="products",
        columns={
            "id": ColumnMetadata(
                name="id",
                data_type="integer",
                value_type="integer",
                is_primary_key=True,
                role=ColumnRole.IDENTIFIER.value,
                distinct_count=50,
            ),
            "price": ColumnMetadata(
                name="price",
                data_type="numeric",
                value_type="number",
                role=ColumnRole.NUMERIC_MEASURE.value,
                distinct_count=40,
            ),
            "category": ColumnMetadata(
                name="category",
                data_type="varchar",
                value_type="string",
                role=ColumnRole.CATEGORICAL.value,
                distinct_count=10,
            ),
        },
        foreign_keys=[],
        primary_key="",
    )
    return SchemaGraph(
        join_paths_multi={},
        schema_hash="",
        tables={"customers": customers, "orders": orders, "products": products},
    )


@pytest.fixture
def column_roles(three_table_schema):
    """Column roles dict matching the three_table_schema fixture."""
    roles = {}
    for tname, tmeta in three_table_schema.tables.items():
        for cname, cmeta in tmeta.columns.items():
            roles[f"{tname}.{cname}"] = cmeta.role
    return roles


class TestBuildFkAdjacency:
    """Tests for build_fk_adjacency."""

    def test_adjacency_map(self, three_table_schema):
        """Build adjacency map from FK edges."""
        adj = build_fk_adjacency(three_table_schema)
        assert "customers" in adj["orders"]
        assert "orders" in adj["customers"]
        assert "products" in adj["orders"]
        assert "orders" in adj["products"]

    def test_no_direct_link(self, three_table_schema):
        """Customers and products not directly linked."""
        adj = build_fk_adjacency(three_table_schema)
        assert "products" not in adj["customers"]
        assert "customers" not in adj["products"]


class TestIsConnected:
    """Tests for is_connected."""

    def test_single_table(self, three_table_schema):
        """Single table is always connected."""
        adj = build_fk_adjacency(three_table_schema)
        assert is_connected(["customers"], adj) is True

    def test_directly_linked(self, three_table_schema):
        """Directly linked tables are connected."""
        adj = build_fk_adjacency(three_table_schema)
        assert is_connected(["customers", "orders"], adj) is True

    def test_indirectly_linked(self, three_table_schema):
        """Tables linked through bridge table are connected."""
        adj = build_fk_adjacency(three_table_schema)
        assert is_connected(["customers", "orders", "products"], adj) is True

    def test_disconnected(self):
        """Disconnected tables return False."""
        adj = {"a": set(), "b": set()}
        assert is_connected(["a", "b"], adj) is False


class TestEnumerateTableSets:
    """Tests for enumerate_table_sets."""

    def test_includes_single_tables(self, three_table_schema):
        """All single tables included in results."""
        result = enumerate_table_sets(three_table_schema)
        assert ["customers"] in result
        assert ["orders"] in result
        assert ["products"] in result

    def test_includes_connected_pairs(self, three_table_schema):
        """Connected pairs included in results."""
        result = enumerate_table_sets(three_table_schema)
        pairs = [s for s in result if len(s) == 2]
        assert ["customers", "orders"] in pairs
        assert ["orders", "products"] in pairs

    def test_excludes_disconnected_pairs(self):
        """Disconnected pairs excluded from results."""
        t1 = TableMetadata(name="t1", columns={}, foreign_keys=[], primary_key="")
        t2 = TableMetadata(name="t2", columns={}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t1": t1, "t2": t2})
        result = enumerate_table_sets(schema)
        pairs = [s for s in result if len(s) == 2]
        assert len(pairs) == 0


class TestIsExcludedFilterColumn:
    """Tests for is_excluded_filter_column."""

    def test_normal_column(self):
        """Normal column not excluded."""
        assert _is_excluded_filter_column("name") is False

    def test_audit_column(self):
        """Audit-pattern column excluded if pattern matches."""
        patterns = QSimConfig.EXCLUDED_FILTER_PATTERNS
        if patterns:
            for p in patterns:
                assert _is_excluded_filter_column(p) is True
                break

    def test_empty_string_not_excluded(self):
        """Empty string matches no pattern."""
        assert _is_excluded_filter_column("") is False

    def test_substring_match(self):
        """Column containing pattern substring is excluded."""
        assert _is_excluded_filter_column("user_password") is True

    def test_case_insensitive(self):
        """Pattern match is case-insensitive."""
        assert _is_excluded_filter_column("PASSWORD") is True


class TestGetFilterableColumns:
    """Tests for get_filterable_columns."""

    def test_returns_filterable(self, three_table_schema, column_roles):
        """Return filterable columns for table."""
        result = get_filterable_columns("orders", three_table_schema, column_roles)
        col_names = [c for c, _ in result]
        assert any("amount" in c for c in col_names)

    def test_empty_for_unknown_table(self, three_table_schema, column_roles):
        """Return empty for unknown table."""
        result = get_filterable_columns("unknown", three_table_schema, column_roles)
        assert result == []

    def test_uses_column_roles_when_provided(self, three_table_schema):
        """Uses column_roles map when col_key present, else col_meta.role."""
        column_roles = {"orders.status": "categorical"}
        result = get_filterable_columns("orders", three_table_schema, column_roles)
        col_keys = [c for c, _ in result]
        assert any("status" in c for c in col_keys)
        roles = {c: r for c, r in result}
        assert roles.get("orders.status") == "categorical"


class TestGetAggregatableColumns:
    """Tests for get_aggregatable_columns."""

    def test_numeric_measure_columns(self, three_table_schema, column_roles):
        """Return NUMERIC_MEASURE columns only."""
        result = get_aggregatable_columns("orders", three_table_schema, column_roles)
        assert "orders.amount" in result

    def test_identifier_not_aggregatable(self, three_table_schema, column_roles):
        """IDENTIFIER columns not in aggregatable list."""
        result = get_aggregatable_columns("orders", three_table_schema, column_roles)
        assert "orders.id" not in result


class TestGetGroupableColumns:
    """Tests for get_groupable_columns."""

    def test_categorical_columns(self, three_table_schema, column_roles):
        """Return CATEGORICAL columns."""
        result = get_groupable_columns("orders", three_table_schema, column_roles)
        assert "orders.status" in result

    def test_numeric_measure_not_groupable(self, three_table_schema, column_roles):
        """NUMERIC_MEASURE columns not groupable."""
        result = get_groupable_columns("orders", three_table_schema, column_roles)
        assert "orders.amount" not in result


class TestGetComparableColumnPairs:
    """Tests for get_comparable_column_pairs."""

    def test_numeric_pairs_across_tables(self, three_table_schema, column_roles):
        """Find numeric column pairs across different tables."""
        result = get_comparable_column_pairs(["orders", "products"], three_table_schema, column_roles)
        assert any(("orders" in (t1, t2) and "products" in (t1, t2)) for t1, _, t2, _, _ in result)

    def test_single_table_no_cross_pairs(self, three_table_schema, column_roles):
        """No cross-table pairs for single table."""
        result = get_comparable_column_pairs(["orders"], three_table_schema, column_roles)
        assert len(result) == 0


class TestComputeIntentId:
    """Tests for compute_intent_id."""

    def test_deterministic(self):
        """Same input produces same intent_id."""
        d = {"tables": ["t1"], "grain": "scalar", "select_cols": ["t1.a"]}
        id1 = compute_intent_id(d)
        id2 = compute_intent_id(d)
        assert id1 == id2

    def test_different_inputs(self):
        """Different inputs produce different intent_ids."""
        d1 = {"tables": ["t1"], "grain": "scalar", "select_cols": ["t1.a"]}
        d2 = {"tables": ["t2"], "grain": "scalar", "select_cols": ["t2.b"]}
        assert compute_intent_id(d1) != compute_intent_id(d2)

    def test_order_independent_tables(self):
        """Table order does not affect intent_id."""
        d1 = {"tables": ["t1", "t2"], "grain": "grouped", "select_cols": ["t1.a"]}
        d2 = {"tables": ["t2", "t1"], "grain": "grouped", "select_cols": ["t1.a"]}
        assert compute_intent_id(d1) == compute_intent_id(d2)


class TestDecomposeBetweenFilter:
    """Tests for decompose_between_filter."""

    def test_between_decomposed(self):
        """BETWEEN filter decomposes into >= and <=."""
        f = QSimFilter(column="t.a", op="between", value_type="integer")
        result = decompose_between_filter(f)
        assert len(result) == 2
        assert result[0].op == ">="
        assert result[1].op == "<="

    def test_non_between_unchanged(self):
        """Non-BETWEEN filter returns as-is."""
        f = QSimFilter(column="t.a", op="=", value_type="string")
        result = decompose_between_filter(f)
        assert len(result) == 1
        assert result[0].op == "="


class TestValidateColumnExists:
    """Tests for validate_column_exists."""

    def test_existing_column(self, three_table_schema):
        """Return True for existing column."""
        assert validate_column_exists("orders.amount", ["orders"], three_table_schema) is True

    def test_nonexistent_column(self, three_table_schema):
        """Return False for nonexistent column."""
        assert validate_column_exists("orders.nonexistent", ["orders"], three_table_schema) is False

    def test_table_not_in_list(self, three_table_schema):
        """Return False for table not in allowed list."""
        assert validate_column_exists("orders.amount", ["customers"], three_table_schema) is False

    def test_unqualified_column(self, three_table_schema):
        """Return False for unqualified column."""
        assert validate_column_exists("amount", ["orders"], three_table_schema) is False


class TestBuildSchemaContext:
    """Tests for build_schema_context."""

    def test_includes_table_name(self, three_table_schema):
        """Schema context includes table names."""
        ctx = build_schema_context(["orders"], three_table_schema)
        assert "orders" in ctx

    def test_includes_column_info(self, three_table_schema):
        """Schema context includes column names and types."""
        ctx = build_schema_context(["orders"], three_table_schema)
        assert "amount" in ctx
        assert "PK" in ctx

    def test_includes_fk_markers(self, three_table_schema):
        """Schema context includes FK markers."""
        ctx = build_schema_context(["orders"], three_table_schema)
        assert "FK" in ctx


class TestGenerateAllSkeletons:
    """Tests for generate_all_skeletons."""

    def test_returns_non_empty(self, three_table_schema, column_roles):
        """Generates at least one skeleton for valid table set."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        assert len(result) > 0

    def test_all_items_are_skeletons(self, three_table_schema, column_roles):
        """All returned items are QSimSkeleton instances."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        for s in result:
            assert isinstance(s, QSimSkeleton)

    def test_tables_preserved(self, three_table_schema, column_roles):
        """All skeletons preserve the input table list."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders", "products"], three_table_schema, column_roles)
        for s in result:
            assert s.tables == ["orders", "products"]

    def test_cache_hit(self, three_table_schema, column_roles):
        """Second call returns cached result."""
        _SKELETON_CACHE.clear()
        first = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        second = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        assert first is second

    def test_both_agg_variants(self, three_table_schema, column_roles):
        """Generates skeletons with and without aggregation."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        has_agg_true = any(s.has_aggregation for s in result)
        has_agg_false = any(not s.has_aggregation for s in result)
        assert has_agg_true
        assert has_agg_false

    def test_non_agg_groupby_zero(self, three_table_schema, column_roles):
        """Non-aggregation skeletons always have num_groupby == 0."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        for s in result:
            if not s.has_aggregation:
                assert s.num_groupby == 0

    def test_having_requires_agg_and_groupby(self, three_table_schema, column_roles):
        """has_having only True when has_aggregation and num_groupby >
        0."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        for s in result:
            if s.has_having:
                assert s.has_aggregation
                assert s.num_groupby > 0

    def test_distinct_only_single_non_agg(self, three_table_schema, column_roles):
        """has_distinct only True for single-table non-aggregation
        skeletons."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders"], three_table_schema, column_roles)
        for s in result:
            if s.has_distinct:
                assert not s.has_aggregation
                assert len(s.tables) == 1

    def test_multi_table_no_distinct(self, three_table_schema, column_roles):
        """Multi-table skeletons never have has_distinct True."""
        _SKELETON_CACHE.clear()
        result = generate_all_skeletons(["orders", "products"], three_table_schema, column_roles)
        for s in result:
            assert not s.has_distinct


class TestLoadOrCreateSkeletons:
    """Tests for load_or_create_skeletons."""

    def test_creates_cache_file(self, three_table_schema, column_roles, tmp_path, monkeypatch):
        """Creates cache JSON file when none exists."""
        _SKELETON_CACHE.clear()
        cache_file = str(tmp_path / "skeletons.json")
        monkeypatch.setattr("text2sql.qsim_struct.QSimConfig.SKELETONS_JSON_PATH", cache_file)
        result = load_or_create_skeletons(three_table_schema, column_roles)
        assert os.path.exists(cache_file)
        assert len(result) > 0

    def test_loads_from_existing_cache(self, three_table_schema, column_roles, tmp_path, monkeypatch):
        """Loads from existing cache file with matching schema hash."""
        _SKELETON_CACHE.clear()
        cache_file = str(tmp_path / "skeletons.json")
        monkeypatch.setattr("text2sql.qsim_struct.QSimConfig.SKELETONS_JSON_PATH", cache_file)
        load_or_create_skeletons(three_table_schema, column_roles)
        first_count = len(_SKELETON_CACHE)
        _SKELETON_CACHE.clear()
        result = load_or_create_skeletons(three_table_schema, column_roles)
        assert len(result) == first_count

    def test_hash_mismatch_regenerates(self, three_table_schema, column_roles, tmp_path, monkeypatch):
        """Schema hash mismatch triggers regeneration."""
        _SKELETON_CACHE.clear()
        cache_file = str(tmp_path / "skeletons.json")
        monkeypatch.setattr("text2sql.qsim_struct.QSimConfig.SKELETONS_JSON_PATH", cache_file)
        load_or_create_skeletons(three_table_schema, column_roles)
        with open(cache_file, encoding="utf-8") as f:
            data = json.load(f)
        data["schema_hash"] = "wrong_hash"
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump(data, f)
        _SKELETON_CACHE.clear()
        result = load_or_create_skeletons(three_table_schema, column_roles)
        assert len(result) > 0

    def test_corrupt_cache_file(self, three_table_schema, column_roles, tmp_path, monkeypatch):
        """Corrupt cache file triggers regeneration instead of crash."""
        _SKELETON_CACHE.clear()
        cache_file = str(tmp_path / "skeletons.json")
        with open(cache_file, "w") as f:
            f.write("NOT JSON")
        monkeypatch.setattr("text2sql.qsim_struct.QSimConfig.SKELETONS_JSON_PATH", cache_file)
        result = load_or_create_skeletons(three_table_schema, column_roles)
        assert len(result) > 0

    def test_cache_file_contains_valid_json(self, three_table_schema, column_roles, tmp_path, monkeypatch):
        """Written cache file contains valid JSON with expected keys."""
        _SKELETON_CACHE.clear()
        cache_file = str(tmp_path / "skeletons.json")
        monkeypatch.setattr("text2sql.qsim_struct.QSimConfig.SKELETONS_JSON_PATH", cache_file)
        load_or_create_skeletons(three_table_schema, column_roles)
        with open(cache_file, encoding="utf-8") as f:
            data = json.load(f)
        assert "schema_hash" in data
        assert "skeletons" in data
        assert "num_table_sets" in data


class TestEnumerateTableSetsEdgeCases:
    """Edge case tests for enumerate_table_sets."""

    def test_single_table_schema(self):
        """Single-table schema returns only one set."""
        t = TableMetadata(name="t", columns={}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        result = enumerate_table_sets(schema)
        assert result == [["t"]]

    def test_empty_schema(self):
        """Empty schema returns empty list."""
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={})
        result = enumerate_table_sets(schema)
        assert result == []

    def test_max_tables_one(self):
        """max_tables=1 returns only single-table sets."""
        t1 = TableMetadata(name="t1", columns={}, foreign_keys=[], primary_key="")
        t2 = TableMetadata(name="t2", columns={}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t1": t1, "t2": t2})
        result = enumerate_table_sets(schema, max_tables=1)
        assert all(len(s) == 1 for s in result)


class TestIsConnectedEdgeCases:
    """Edge case tests for is_connected."""

    def test_empty_table_list(self):
        """Empty table list returns True."""
        adj = {"a": {"b"}, "b": {"a"}}
        assert is_connected([], adj) is True

    def test_table_not_in_adjacency(self):
        """Table missing from adjacency map is unreachable."""
        adj = {"a": set()}
        assert is_connected(["a", "b"], adj) is False


class TestBuildFkAdjacencyEdgeCases:
    """Edge case tests for build_fk_adjacency."""

    def test_empty_schema(self):
        """Empty schema produces empty adjacency."""
        empty = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        assert build_fk_adjacency(empty) == {}

    def test_no_fk_edges(self):
        """Schema with no FK edges returns empty adjacency sets."""
        t = TableMetadata(name="t", columns={}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        adj = build_fk_adjacency(schema)
        assert adj["t"] == set()

    def test_self_referential_fk(self):
        """Self-referential FK creates self-loop in adjacency."""
        t = TableMetadata(
            name="t",
            columns={},
            foreign_keys=[
                FKEdge(
                    src_table="t",
                    src_cols=["parent_id"],
                    dst_table="t",
                    dst_cols=["id"],
                )
            ],
            primary_key="",
        )
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        adj = build_fk_adjacency(schema)
        assert "t" in adj["t"]


class TestComputeIntentIdEdgeCases:
    """Edge case tests for compute_intent_id."""

    def test_empty_dict(self):
        """Empty dict produces a valid intent ID."""
        result = compute_intent_id({})
        assert isinstance(result, str)
        assert len(result) > 0

    def test_with_filters_and_having(self):
        """Intent ID accounts for filters and having params."""
        d1 = {
            "tables": ["t1"],
            "grain": "scalar",
            "select_cols": ["t1.a"],
            "filters_param": [{"column": "t1.x", "op": "="}],
        }
        d2 = {
            "tables": ["t1"],
            "grain": "scalar",
            "select_cols": ["t1.a"],
            "filters_param": [],
        }
        assert compute_intent_id(d1) != compute_intent_id(d2)

    def test_filter_order_independent(self):
        """Filter order does not affect intent ID."""
        f1 = {"column": "t1.a", "op": "="}
        f2 = {"column": "t1.b", "op": ">"}
        d1 = {"tables": ["t1"], "filters_param": [f1, f2]}
        d2 = {"tables": ["t1"], "filters_param": [f2, f1]}
        assert compute_intent_id(d1) == compute_intent_id(d2)


class TestGetAggregatableColumnsEdgeCases:
    """Edge case tests for get_aggregatable_columns."""

    def test_unknown_table(self, three_table_schema, column_roles):
        """Unknown table returns empty list."""
        result = get_aggregatable_columns("nonexistent", three_table_schema, column_roles)
        assert result == []

    def test_table_without_numeric(self, column_roles):
        """Table with no NUMERIC_MEASURE columns returns empty."""
        t = TableMetadata(
            name="t",
            columns={
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    distinct_count=10,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        result = get_aggregatable_columns("t", schema, column_roles)
        assert result == []


class TestGetGroupableColumnsEdgeCases:
    """Edge case tests for get_groupable_columns."""

    def test_unknown_table(self, three_table_schema, column_roles):
        """Unknown table returns empty list."""
        result = get_groupable_columns("nonexistent", three_table_schema, column_roles)
        assert result == []

    def test_temporal_column_groupable(self, column_roles):
        """TEMPORAL columns are groupable."""
        t = TableMetadata(
            name="t",
            columns={
                "created_at": ColumnMetadata(
                    name="created_at",
                    data_type="timestamp",
                    value_type="datetime",
                    role=ColumnRole.TEMPORAL.value,
                    distinct_count=100,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        result = get_groupable_columns("t", schema, column_roles)
        assert "t.created_at" in result


class TestGetComparableColumnPairsEdgeCases:
    """Edge case tests for get_comparable_column_pairs."""

    def test_empty_table_set(self, three_table_schema, column_roles):
        """Empty table list returns no pairs."""
        result = get_comparable_column_pairs([], three_table_schema, column_roles)
        assert result == []

    def test_same_role_required(self, column_roles):
        """Columns must share same role to be comparable."""
        t1 = TableMetadata(
            name="t1",
            columns={
                "x": ColumnMetadata(
                    name="x",
                    data_type="numeric",
                    value_type="number",
                    role=ColumnRole.NUMERIC_MEASURE.value,
                    distinct_count=10,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        t2 = TableMetadata(
            name="t2",
            columns={
                "y": ColumnMetadata(
                    name="y",
                    data_type="numeric",
                    value_type="number",
                    role=ColumnRole.NUMERIC_CATEGORICAL.value,
                    distinct_count=10,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t1": t1, "t2": t2})
        roles = {
            "t1.x": ColumnRole.NUMERIC_MEASURE.value,
            "t2.y": ColumnRole.NUMERIC_CATEGORICAL.value,
        }
        result = get_comparable_column_pairs(["t1", "t2"], schema, roles)
        assert result == []


class TestBuildSchemaContextEdgeCases:
    """Edge case tests for build_schema_context."""

    def test_unknown_table_skipped(self, three_table_schema):
        """Unknown table name produces no output."""
        ctx = build_schema_context(["nonexistent"], three_table_schema)
        assert ctx == ""

    def test_empty_table_list(self, three_table_schema):
        """Empty table list produces empty context."""
        ctx = build_schema_context([], three_table_schema)
        assert ctx == ""

    def test_multiple_tables_separated(self, three_table_schema):
        """Multiple tables separated by blank lines."""
        ctx = build_schema_context(["customers", "orders"], three_table_schema)
        assert "customers" in ctx
        assert "orders" in ctx
        assert "\n\n" in ctx


class TestValidateColumnExistsEdgeCases:
    """Edge case tests for validate_column_exists."""

    def test_empty_col_ref(self, three_table_schema):
        """Empty string returns False."""
        assert validate_column_exists("", ["orders"], three_table_schema) is False

    def test_multiple_dots(self, three_table_schema):
        """Column with multiple dots splits on first dot only."""
        assert validate_column_exists("orders.a.b", ["orders"], three_table_schema) is False

    def test_empty_tables_list(self, three_table_schema):
        """Empty tables list returns False for any column."""
        assert validate_column_exists("orders.amount", [], three_table_schema) is False


class TestDecomposeBetweenFilterEdgeCases:
    """Edge case tests for decompose_between_filter."""

    def test_preserves_column(self):
        """Decomposed filters preserve original column."""
        f = QSimFilter(column="t.date_col", op="between", value_type="date")
        result = decompose_between_filter(f)
        assert all(r.column == "t.date_col" for r in result)

    def test_preserves_value_type(self):
        """Decomposed filters preserve original value_type."""
        f = QSimFilter(column="t.x", op="between", value_type="integer")
        result = decompose_between_filter(f)
        assert all(r.value_type == "integer" for r in result)
