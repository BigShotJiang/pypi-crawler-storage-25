"""Tests for the new deterministic simulator pipeline.

Tests join cache, value instantiation, question generation integration,
and the end-to-end deterministic pipeline.
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from text2sql.contracts_base import SchemaGraph, ValueDomain
from text2sql.contracts_core import (
    FilterParam,
    HavingParam,
    NormalizedExpr,
    SelectCol,
    SimulatorIntent,
    SimulatorResult,
)
from text2sql.simulator import (
    _decompose_between_filter_param,
    _identify_range_pairs,
    instantiate_intent,
    resolve_joins_for_table_set,
)


def _sim_intent(**overrides) -> SimulatorIntent:
    """Build a minimal SimulatorIntent with optional overrides."""
    defaults = dict(
        intent_id="test_001",
        tables=["orders"],
        grain="row_level",
        select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
        group_by_cols=[],
        order_by_cols=[],
        filters_param=[],
        having_param=[],
        param_values={},
        expansion_metadata=None,
        limit=None,
    )
    defaults.update(overrides)
    return SimulatorIntent(**defaults)


class TestResolveJoinsCache:
    """Tests for join resolution caching."""

    def test_single_table_returns_j00(self, schema_graph):
        """Single table always gets J00."""
        cache: dict = {}
        jid, sig, cands = resolve_joins_for_table_set(
            ["orders"], schema_graph, "test", cache,
        )
        assert jid == "J00"
        assert frozenset(["orders"]) in cache

    def test_cache_hit_avoids_recompute(self, schema_graph):
        """Second call with same tables returns cached result."""
        cache: dict = {}
        resolve_joins_for_table_set(
            ["orders"], schema_graph, "test", cache,
        )
        result1 = cache[frozenset(["orders"])]
        resolve_joins_for_table_set(
            ["orders"], schema_graph, "test2", cache,
        )
        result2 = cache[frozenset(["orders"])]
        assert result1 is result2

    def test_different_table_sets_cached_separately(self, schema_graph):
        """Different table sets produce different cache entries."""
        cache: dict = {}
        resolve_joins_for_table_set(
            ["orders"], schema_graph, "test", cache,
        )
        resolve_joins_for_table_set(
            ["customers"], schema_graph, "test", cache,
        )
        assert len(cache) == 2
        assert frozenset(["orders"]) in cache
        assert frozenset(["customers"]) in cache


class TestInstantiateIntent:
    """Tests for single-intent instantiation."""

    def test_no_filters_returns_intent(self):
        """Intent with no filters returns successfully."""
        intent = _sim_intent()
        result = instantiate_intent(intent, {})
        assert result is not None
        assert result.param_values == {}

    def test_samples_filter_value(self):
        """Filter value is sampled from provided domain."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="=", value_type="string", param_key="p1",
                )
            ],
        )
        domains = {
            "orders.status": ValueDomain(
                values=["shipped", "pending"],
                min_val=None, max_val=None,
            ),
        }
        result = instantiate_intent(intent, domains)
        assert result is not None

    def test_null_filter_passthrough(self):
        """Null/is-null filters pass through without value sampling."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="is not null", value_type="null", param_key="p1",
                )
            ],
        )
        result = instantiate_intent(intent, {})
        assert result is not None
        assert result.filters_param[0].op == "is not null"

    def test_date_window_passthrough(self):
        """date_window filters pass through without value sampling."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.order_date"),
                    op=">=", value_type="date_window", param_key="",
                    raw_value={"unit": "day", "offset": 30},
                )
            ],
        )
        result = instantiate_intent(intent, {})
        assert result is not None
        assert result.filters_param[0].value_type == "date_window"

    def test_having_value_populated(self):
        """HAVING params get deterministic values."""
        intent = _sim_intent(
            grain="grouped",
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
            having_param=[
                HavingParam(
                    left_expr=NormalizedExpr.from_agg("count", "*"),
                    op=">", value_type="number", param_key="h1",
                )
            ],
        )
        result = instantiate_intent(intent, {})
        assert result is not None
        assert "h1" in result.param_values


class TestDecomposeBetween:
    """Tests for between filter decomposition."""

    def test_between_decomposed_to_pair(self):
        """BETWEEN becomes >= and <=."""
        f = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.amount"),
            op="between", value_type="number", param_key="p1",
        )
        parts = _decompose_between_filter_param(f)
        assert len(parts) == 2
        ops = {p.op for p in parts}
        assert ">=" in ops and "<=" in ops

    def test_non_between_passthrough(self):
        """Non-between filter passes through."""
        f = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=", value_type="string", param_key="p1",
        )
        parts = _decompose_between_filter_param(f)
        assert len(parts) == 1


class TestIdentifyRangePairs:
    """Tests for range pair identification."""

    def test_detects_paired_bounds(self):
        """Detects >= / <= on same column."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op=">=", value_type="number", param_key="p1",
            ),
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op="<=", value_type="number", param_key="p2",
            ),
        ]
        pairs = _identify_range_pairs(filters)
        assert "orders.amount" in pairs


class TestQuestionFromSqlIntegration:
    """Tests for generate_question_from_sql."""

    @patch("text2sql.utils.llm_json")
    def test_realistic_question_returned(self, mock_llm, schema_graph):
        """Realistic response returns question."""
        from text2sql.utils import generate_question_from_sql
        mock_llm.return_value = {
            "question": "How many orders exist?",
            "is_realistic": True,
            "drop_reason": None,
        }
        result = generate_question_from_sql(
            "SELECT COUNT(*) FROM orders",
            schema_graph, ["orders"],
        )
        assert result is not None
        assert result["is_realistic"] is True
        assert "orders" in result["question"].lower()

    @patch("text2sql.utils.llm_json")
    def test_unrealistic_dropped(self, mock_llm, schema_graph):
        """Unrealistic response returns is_realistic=False."""
        from text2sql.utils import generate_question_from_sql
        mock_llm.return_value = {
            "question": "",
            "is_realistic": False,
            "drop_reason": "meaningless cross join",
        }
        result = generate_question_from_sql(
            "SELECT * FROM orders, customers",
            schema_graph, ["orders", "customers"],
        )
        assert result is not None
        assert result["is_realistic"] is False
        assert "meaningless" in result["drop_reason"]

    @patch("text2sql.utils.llm_json", side_effect=Exception("timeout"))
    def test_llm_failure_returns_none(self, mock_llm, schema_graph):
        """LLM failure returns None."""
        from text2sql.utils import generate_question_from_sql
        result = generate_question_from_sql(
            "SELECT 1", schema_graph, ["orders"],
        )
        assert result is None
