"""Unit tests for text2sql.validation_execute module."""

from types import SimpleNamespace
from unittest.mock import patch

from text2sql.contracts_base import SchemaGraph
from text2sql.contracts_core import (
    FilterParam,
    HavingParam,
    NormalizedExpr,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
)
from text2sql.validation_execute import (
    _enforce_select_only,
    _validate_cte_cardinality,
    _validate_cte_output_types,
    _validate_main_query_cte_usage,
    compute_confidence,
    execute_sql,
    get_spark_sql_for_execution,
    llm_classify_rejection,
    validate_semantics,
    validate_sql,
)


class TestGetSparkSqlForExecution:
    """Tests for get_spark_sql_for_execution."""

    def test_returns_empty_when_not_databricks(self):
        """Return empty string when EngineConfig.TYPE is not databricks."""
        from text2sql.config import EngineConfig

        with patch.object(EngineConfig, "TYPE", "postgresql"):
            schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={})
            intent = RuntimeIntent(
                tables=[],
                grain="row_level",
                select_cols=[],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            )
            dialect = SimpleNamespace(prepare_for_execution=lambda s: s)
            result = get_spark_sql_for_execution(
                "SELECT 1", {}, schema, intent, dialect
            )
            assert result == ""

    def test_returns_spark_sql_when_databricks(self):
        """Return translated and substituted SQL when Databricks."""
        from text2sql.config import EngineConfig

        with patch.object(EngineConfig, "TYPE", "databricks"):
            schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={})
            intent = RuntimeIntent(
                tables=[],
                grain="row_level",
                select_cols=[],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            )
            dialect = SimpleNamespace(prepare_for_execution=lambda s: s)
            result = get_spark_sql_for_execution(
                "SELECT * FROM t WHERE col = :p1",
                {"p1": "x"},
                schema,
                intent,
                dialect,
            )
            assert result
            assert "'x'" in result


class TestEnforceSelectOnly:
    """Tests for enforce_select_only."""

    def test_valid_select(self):
        """Plain SELECT passes."""
        ok, reason = _enforce_select_only("SELECT * FROM film")
        assert ok is True
        assert reason == "ok"

    def test_select_with_joins(self):
        """SELECT with JOIN passes."""
        ok, _ = _enforce_select_only("SELECT f.title FROM film f JOIN language l ON f.language_id = l.language_id")
        assert ok is True

    def test_select_with_where(self):
        """SELECT with WHERE passes."""
        ok, _ = _enforce_select_only("SELECT title FROM film WHERE rating = 'PG'")
        assert ok is True

    def test_not_select(self):
        """Non-SELECT statement fails with not_select."""
        ok, reason = _enforce_select_only("UPDATE film SET title = 'x'")
        assert ok is False
        assert reason == "not_select"

    def test_empty_string(self):
        """Empty string fails with not_select."""
        ok, reason = _enforce_select_only("")
        assert ok is False
        assert reason == "not_select"

    def test_delete_forbidden(self):
        """DELETE keyword triggers forbidden_sql."""
        ok, reason = _enforce_select_only("SELECT 1; DELETE FROM film")
        assert ok is False
        assert reason == "forbidden_sql"

    def test_drop_forbidden(self):
        """DROP keyword triggers forbidden_sql."""
        ok, reason = _enforce_select_only("SELECT * FROM film; DROP TABLE film")
        assert ok is False
        assert reason == "forbidden_sql"

    def test_insert_forbidden(self):
        """INSERT keyword triggers forbidden_sql."""
        ok, reason = _enforce_select_only(
            "SELECT * FROM film WHERE title IN (SELECT title FROM (INSERT INTO x VALUES (1)))"
        )
        assert ok is False
        assert reason == "forbidden_sql"

    def test_union_forbidden(self):
        """UNION is in forbidden list."""
        ok, reason = _enforce_select_only("SELECT title FROM film UNION SELECT title FROM film")
        assert ok is False
        assert reason == "forbidden_sql"

    def test_case_insensitive_select(self):
        """Lowercase select passes."""
        ok, _ = _enforce_select_only("select title from film")
        assert ok is True

    def test_semicolon_injection(self):
        """Semicolon followed by content is forbidden."""
        ok, reason = _enforce_select_only("SELECT 1; DROP TABLE film")
        assert ok is False
        assert reason == "forbidden_sql"


class TestComputeConfidence:
    """Tests for compute_confidence."""

    def test_perfect_score(self):
        """High best_score with no penalties yields high confidence."""
        c = compute_confidence(1.0, 0.5, False, 0.0, 0.0, 0.0)
        assert c > 0.7

    def test_zero_inputs(self):
        """All-zero inputs with cold-start floor yields 0.5."""
        c = compute_confidence(0.0, 0.0, False, 0.0, 0.0, 0.0)
        assert c == 0.5

    def test_cold_start_floor_reduced_by_penalties(self):
        """Cold-start floor is reduced by negative/colmap/cte penalties."""
        c = compute_confidence(0.0, 0.0, False, 0.0, 1.0, 0.0)
        assert c < 0.5

    def test_new_tables_penalty(self):
        """Using new tables reduces confidence."""
        c_no = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 0.0)
        c_yes = compute_confidence(0.8, 0.3, True, 0.0, 0.0, 0.0)
        assert c_yes < c_no

    def test_shape_penalty(self):
        """Shape penalty reduces confidence."""
        c_low = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 0.0)
        c_high = compute_confidence(0.8, 0.3, False, 1.0, 0.0, 0.0)
        assert c_high < c_low

    def test_negative_penalty(self):
        """Negative memory penalty reduces confidence."""
        c_clean = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 0.0)
        c_neg = compute_confidence(0.8, 0.3, False, 0.0, 1.0, 0.0)
        assert c_neg < c_clean

    def test_clamped_to_0_1(self):
        """Result is always clamped to [0, 1]."""
        c = compute_confidence(0.0, 0.0, True, 1.0, 1.0, 1.0, 1.0)
        assert c >= 0.0
        c2 = compute_confidence(1.0, 1.0, False, 0.0, 0.0, 0.0, 0.0)
        assert c2 <= 1.0

    def test_colmap_penalty(self):
        """Column-map penalty reduces confidence."""
        c_clean = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 0.0)
        c_pen = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 1.0)
        assert c_pen < c_clean

    def test_cte_penalty(self):
        """CTE count penalty reduces confidence."""
        c_no_cte = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 0.0, 0.0)
        c_cte = compute_confidence(0.8, 0.3, False, 0.0, 0.0, 0.0, 1.0)
        assert c_cte < c_no_cte


class TestValidateCteCardinality:
    """Tests for validate_cte_cardinality."""

    def _make_cte(self, name="cte1", grain="row_level", limit=None, tables=None):
        """Build a minimal RuntimeCteStep."""
        return RuntimeCteStep(
            cte_name=name,
            tables=tables or ["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            output_columns=["order_id"],
            grain=grain,
            limit=limit,
        )

    def test_empty_list(self):
        """Empty CTE list yields no issues."""
        issues = _validate_cte_cardinality([])
        assert issues == []

    def test_row_level_no_limit_clean(self):
        """Row-level CTE without limit produces no issues."""
        cte = self._make_cte(grain="row_level")
        issues = _validate_cte_cardinality([cte])
        assert issues == []

    def test_scalar_grain_is_consistent(self):
        """Scalar grain CTE has expected_rows='one' via property, so no
        cardinality warning."""
        cte = self._make_cte(grain="scalar")
        issues = _validate_cte_cardinality([cte])
        cardinality_issues = [i for i in issues if "scalar_cardinality" in i.issue_id]
        assert cardinality_issues == []

    def test_limit_1_row_level_warns(self):
        """Row-level CTE with LIMIT 1 has expected_rows='few' which !=
        'one', triggers warning."""
        cte = self._make_cte(grain="row_level", limit=1)
        issues = _validate_cte_cardinality([cte])
        ids = [i.issue_id for i in issues]
        assert any("limit1_cardinality" in iid for iid in ids)

    def test_many_depends_on_single_row(self):
        """CTE expecting many rows depending on a single-row CTE
        produces info."""
        cte1 = self._make_cte(name="cte1", grain="scalar")
        cte2 = self._make_cte(name="cte2", grain="row_level", tables=["cte1"])
        issues = _validate_cte_cardinality([cte1, cte2])
        ids = [i.issue_id for i in issues]
        assert any("cardinality_expansion" in iid for iid in ids)


class TestValidateMainQueryCteUsage:
    """Tests for validate_main_query_cte_usage."""

    def test_no_cte_outputs(self):
        """No CTEs means no issues."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        issues = _validate_main_query_cte_usage(intent, {})
        assert issues == []

    def test_unreferenced_cte_warns(self):
        """CTE defined but not in main query tables produces warning."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        issues = _validate_main_query_cte_usage(intent, {"cte1": ["total"]})
        ids = [i.issue_id for i in issues]
        assert any("unreferenced" in iid for iid in ids)

    def test_valid_cte_reference(self):
        """Main query referencing CTE column correctly produces no
        column errors."""
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.total"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        issues = _validate_main_query_cte_usage(intent, {"cte1": ["total"]})
        errors = [i for i in issues if i.severity == "error"]
        assert errors == []

    def test_column_not_in_cte(self):
        """Main query referencing column absent from CTE outputs
        produces error."""
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.missing_col"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        issues = _validate_main_query_cte_usage(intent, {"cte1": ["total"]})
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_filter_references_cte(self):
        """Filter referencing non-existent CTE column produces error."""
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.total"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("cte1.bad_col"),
                    op=">",
                    value_type="number",
                    param_key="p1",
                    raw_value="10",
                )
            ],
        )
        issues = _validate_main_query_cte_usage(intent, {"cte1": ["total"]})
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_column_map_references_cte(self):
        """column_map referencing non-existent CTE column produces
        error."""
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.total"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            column_map={"ghost": "cte1"},
        )
        issues = _validate_main_query_cte_usage(intent, {"cte1": ["total"]})
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1


class TestValidateCteOutputTypes:
    """Tests for validate_cte_output_types."""

    def test_empty_list(self):
        """Empty CTE list yields no issues."""
        issues = _validate_cte_output_types([], SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h"))
        assert issues == []

    def test_sum_on_numeric_clean(self, schema_graph):
        """SUM on a numeric column produces no type warnings."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("sum", "orders.amount"))],
            output_columns=["sum_orders_amount"],
            grain="scalar",
        )
        issues = _validate_cte_output_types([cte], schema_graph)
        assert issues == []


class TestValidateSql:
    """Tests for validate_sql."""

    def test_valid_select_passes(self):
        """Valid SELECT with passing AST check succeeds."""
        mock_dialect = SimpleNamespace(ast_validate=lambda sql: (True, None))
        ok, err = validate_sql(mock_dialect, "SELECT * FROM film")
        assert ok is True
        assert err is None

    def test_non_select_fails(self):
        """Non-SELECT statement fails before AST check."""
        mock_dialect = SimpleNamespace(ast_validate=lambda sql: (True, None))
        ok, err = validate_sql(mock_dialect, "DELETE FROM film")
        assert ok is False
        assert err == "not_select"

    def test_ast_failure(self):
        """AST validation failure propagated."""
        mock_dialect = SimpleNamespace(ast_validate=lambda sql: (False, "syntax error"))
        ok, err = validate_sql(mock_dialect, "SELECT broken syntax")
        assert ok is False
        assert "syntax error" in err

    def test_forbidden_sql_caught(self):
        """Forbidden keywords caught before AST check."""
        mock_dialect = SimpleNamespace(ast_validate=lambda sql: (True, None))
        ok, err = validate_sql(mock_dialect, "SELECT 1; DROP TABLE film")
        assert ok is False
        assert err == "forbidden_sql"


class TestValidateSemantics:
    """Tests for validate_semantics."""

    def test_empty_tables_returns_tables_empty_issue(self, schema_graph):
        """validate_semantics returns tables_empty when intent has no tables."""
        intent = RuntimeIntent(
            tables=[],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = validate_semantics(intent, schema_graph)
        assert not result.is_valid
        issue_ids = [i.issue_id for i in result.issues]
        assert "tables_empty" in issue_ids

    def test_valid_minimal_intent_returns_result(self, schema_graph):
        """validate_semantics returns IntentValidationResult for valid minimal intent."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = validate_semantics(intent, schema_graph)
        assert hasattr(result, "is_valid")
        assert hasattr(result, "issues")
        assert isinstance(result.issues, list)

    def test_cte_empty_name_produces_error(self, schema_graph):
        """CTE with empty name produces error in validate_semantics."""
        cte = RuntimeCteStep(
            cte_name="",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            output_columns=["order_id"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = validate_semantics(intent, schema_graph)
        assert any(i.issue_id == "cte_name_empty" for i in result.issues)

    def test_cte_empty_output_columns_produces_error(self, schema_graph):
        """CTE with empty output_columns produces error."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            output_columns=[],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = validate_semantics(intent, schema_graph)
        assert any("empty_output" in i.issue_id or "output_columns_empty" in i.issue_id for i in result.issues)

    def test_cte_unknown_table_produces_error(self, schema_graph):
        """CTE referencing unknown table produces error."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["nonexistent_table"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("nonexistent_table.id"))],
            output_columns=["id"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = validate_semantics(intent, schema_graph)
        assert any("unknown_table" in i.issue_id for i in result.issues)

    def test_cte_duplicate_names_produce_error(self, schema_graph):
        """Duplicate CTE names produce error in validate_semantics."""
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            output_columns=["order_id"],
            grain="row_level",
        )
        cte2 = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            output_columns=["order_id"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte1, cte2],
        )
        result = validate_semantics(intent, schema_graph)
        assert any("duplicate" in i.issue_id for i in result.issues)

    def test_cte_forward_reference_produces_error(self, schema_graph):
        """CTE referencing later-defined CTE produces error."""
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            tables=["cte2"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte2.total"))],
            output_columns=["total"],
            grain="row_level",
        )
        cte2 = RuntimeCteStep(
            cte_name="cte2",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            output_columns=["order_id"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.total"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte1, cte2],
        )
        result = validate_semantics(intent, schema_graph)
        assert any("forward_ref" in i.issue_id for i in result.issues)


class _MockConnectContext:
    def __init__(self, conn):
        self._conn = conn

    def __enter__(self):
        return self._conn

    def __exit__(self, *args):
        pass


class TestExecuteSql:
    """Tests for execute_sql."""

    def test_returns_rows_from_dialect(self):
        """execute_sql returns list of tuples from dialect execution."""
        mock_cursor = SimpleNamespace(fetchall=lambda: [(1, "a"), (2, "b")])
        mock_conn = SimpleNamespace(execute=lambda sql: mock_cursor)
        mock_engine = SimpleNamespace(connect=lambda: _MockConnectContext(mock_conn))
        mock_dialect = SimpleNamespace(engine=mock_engine)
        with patch("text2sql.validation_execute.EngineConfig") as mock_cfg:
            mock_cfg.TYPE = "postgresql"
            rows = execute_sql(mock_dialect, "SELECT 1, 'a'")
        assert rows == [(1, "a"), (2, "b")]


class TestLlmClassifyRejection:
    """Tests for llm_classify_rejection."""

    def test_returns_category_and_normalized_reason(self):
        """llm_classify_rejection returns dict with category and normalized_reason."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        with patch("text2sql.validation_execute.llm_json") as mock_llm:
            mock_llm.return_value = {
                "category": "wrong_filters_or_having",
                "normalized_reason": "Filter value incorrect",
            }
            result = llm_classify_rejection(
                "How many orders?",
                intent,
                "SELECT COUNT(*) FROM orders",
                "Summary",
                "The filter is wrong",
            )
        assert result["category"] == "wrong_filters_or_having"
        assert result["normalized_reason"] == "Filter value incorrect"

    def test_invalid_category_falls_back_to_other(self):
        """llm_classify_rejection uses 'other' when category not in policy list."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        with patch("text2sql.validation_execute.llm_json") as mock_llm:
            mock_llm.return_value = {
                "category": "invalid_category",
                "normalized_reason": "Something else",
            }
            result = llm_classify_rejection(
                "List orders",
                intent,
                "SELECT * FROM orders",
                "",
                "Other reason",
            )
        assert result["category"] == "other"
        assert result["normalized_reason"] == "Something else"
