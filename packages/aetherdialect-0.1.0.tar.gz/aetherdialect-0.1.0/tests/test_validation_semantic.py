"""Tests for validation_semantic module."""

from text2sql.config import COMPATIBLE_TYPE_PAIRS
from text2sql.contracts_base import (
    ColumnMetadata,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import (
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    OrderByCol,
    RuntimeCteStep,
    SelectCol,
)
from text2sql.validation_semantic import (
    _check_mixed_aggregation_in_expr,
    _check_mixed_aggregation_in_group,
    _check_nested_aggregation,
    _term_has_aggregation,
    _validate_single_expr_types,
    _word_is_column_component,
    auto_repair_filter_having,
    validate_agg_vs_agg_having,
    validate_arith_expression_semantics,
    validate_count_threshold_missing_having,
    validate_cte_dependency_grains,
    validate_cte_grain_consistency,
    validate_expr_vs_expr_filters,
    validate_filter_expr_types,
    validate_filter_no_aggregation,
    validate_for_each_grouping,
    validate_grain_consistency,
    validate_grouped_requires_aggregation,
    validate_having_expr_types,
    validate_having_requires_aggregation,
    validate_mixed_aggregation_in_mulgroup,
    validate_no_nested_aggregation,
    validate_no_pk_fk_filters,
    validate_order_by_aggregation_context,
    validate_order_by_expr_types,
    validate_question_agg_keyword_coverage,
    validate_question_aggregation_hint,
    validate_question_numeric_coverage,
    validate_question_table_mentions,
    validate_select_expr_types,
    validate_select_group_by_membership,
    validate_semantic_contradictions,
    validate_threshold_missing_having,
)


class TestValidateGrainConsistency:
    """Tests for validate_grain_consistency."""

    def test_grouped_with_group_by(self):
        """No issues for grouped grain with GROUP BY columns."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("count", "t.a"))
        gb = NormalizedExpr.from_column("t.b")
        issues = validate_grain_consistency("grouped", [sc], [gb], [])
        assert len(issues) == 0

    def test_grouped_without_group_by(self):
        """Error for grouped grain without GROUP BY."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("count", "t.a"))
        issues = validate_grain_consistency("grouped", [sc], [], [])
        assert any("without GROUP BY" in i.message for i in issues)

    def test_scalar_with_group_by(self):
        """Error for scalar grain with GROUP BY present."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("count", "t.a"))
        gb = NormalizedExpr.from_column("t.b")
        issues = validate_grain_consistency("scalar", [sc], [gb], [])
        assert any("GROUP BY" in i.message for i in issues)

    def test_row_level_with_agg(self):
        """Error for row_level grain with aggregation."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("sum", "t.a"))
        issues = validate_grain_consistency("row_level", [sc], [], [])
        assert any("row_level" in i.message for i in issues)

    def test_invalid_grain_value(self):
        """Error for unrecognized grain value."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        issues = validate_grain_consistency("invalid", [sc], [], [])
        assert any("Invalid grain" in i.message for i in issues)

    def test_having_without_agg_grain(self):
        """Error for HAVING with row_level grain."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
        )
        issues = validate_grain_consistency("row_level", [sc], [], [hp])
        assert any("HAVING" in i.message for i in issues)


class TestValidateSemanticContradictions:
    """Tests for validate_semantic_contradictions."""

    def test_no_contradiction(self):
        """No issues for non-contradictory intent."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("count", "t.a"))
        issues = validate_semantic_contradictions([sc], "count of items", "scalar", "one")
        assert len(issues) == 0

    def test_nl_contradiction_pattern_never_total(self):
        """NL mentioning 'never' and 'total' triggers warning."""
        sc = SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["SUM(t.a)"])]))
        issues = validate_semantic_contradictions(
            [sc],
            natural_language="Show me records that never have a total over 100",
            grain="grouped",
            expected_rows="few",
        )
        nl_issues = [i for i in issues if "never" in i.message.lower() or "contradiction" in i.message.lower()]
        assert len(nl_issues) >= 1

    def test_scalar_with_many_rows(self):
        """Error for scalar grain but expecting many rows."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("count", "t.a"))
        issues = validate_semantic_contradictions([sc], "count", "scalar", "many")
        assert any("scalar" in i.message and "many" in i.message for i in issues)


class TestValidateExprVsExprFilters:
    """Tests for validate_expr_vs_expr_filters."""

    def test_self_comparison(self, typed_schema):
        """Error for self-comparison in filter."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.balance"),
            op=">",
            right_expr=NormalizedExpr.from_column("customers.balance"),
        )
        issues = validate_expr_vs_expr_filters([fp], typed_schema)
        assert any("Self-comparison" in i.message for i in issues)

    def test_type_mismatch(self, typed_schema):
        """Error for type mismatch in expr-vs-expr comparison."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.balance"),
            op=">",
            right_expr=NormalizedExpr.from_column("customers.name"),
        )
        issues = validate_expr_vs_expr_filters([fp], typed_schema)
        assert any("mismatch" in i.message.lower() for i in issues)

    def test_compatible_types_no_issue(self, typed_schema):
        """No issues for compatible type comparison."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.balance"),
            op=">",
            right_expr=NormalizedExpr.from_column("orders.amount"),
        )
        issues = validate_expr_vs_expr_filters([fp], typed_schema)
        type_issues = [i for i in issues if "mismatch" in i.message.lower()]
        assert len(type_issues) == 0


class TestValidateFilterNoAggregation:
    """Tests for validate_filter_no_aggregation."""

    def test_bare_column_filter(self):
        """No issues for non-aggregated filter."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        issues = validate_filter_no_aggregation([fp])
        assert len(issues) == 0

    def test_aggregated_filter(self):
        """Error for aggregated filter expression."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
        )
        issues = validate_filter_no_aggregation([fp])
        assert len(issues) > 0


class TestValidateHavingRequiresAggregation:
    """Tests for validate_having_requires_aggregation."""

    def test_aggregated_having(self):
        """No issues for aggregated having expression."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
        )
        issues = validate_having_requires_aggregation([hp])
        assert len(issues) == 0

    def test_non_aggregated_having(self):
        """Error for non-aggregated having expression."""
        hp = HavingParam(left_expr=NormalizedExpr.from_column("t.a"), op=">", value_type="integer")
        issues = validate_having_requires_aggregation([hp])
        assert len(issues) > 0


class TestAutoRepairFilterHaving:
    """Tests for auto_repair_filter_having."""

    def test_move_agg_filter_to_having(self):
        """Move aggregated filter to having list."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
            param_key="p1",
        )
        repaired_fp, repaired_hp = auto_repair_filter_having([fp], [])
        assert len(repaired_fp) == 0
        assert len(repaired_hp) == 1
        assert repaired_hp[0].param_key == "p1"

    def test_move_nonagg_having_to_filter(self):
        """Move non-aggregated having to filter list."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            value_type="string",
            param_key="p1",
        )
        repaired_fp, repaired_hp = auto_repair_filter_having([], [hp])
        assert len(repaired_fp) == 1
        assert len(repaired_hp) == 0
        assert repaired_fp[0].param_key == "p1"

    def test_keep_correct_placement(self):
        """Keep correctly placed filter and having."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
        )
        repaired_fp, repaired_hp = auto_repair_filter_having([fp], [hp])
        assert len(repaired_fp) == 1
        assert len(repaired_hp) == 1

    def test_empty_inputs(self):
        """Handle empty input lists."""
        repaired_fp, repaired_hp = auto_repair_filter_having([], [])
        assert repaired_fp == []
        assert repaired_hp == []

    def test_flip_having_when_right_has_agg(self):
        """Flip and keep in HAVING when left lacks agg but right has it."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("cte.avg_col"),
            op=">",
            right_expr=NormalizedExpr.from_agg("avg", "t.col"),
            param_key="p1",
        )
        repaired_fp, repaired_hp = auto_repair_filter_having([], [hp], cte_names=set())
        assert len(repaired_fp) == 0
        assert len(repaired_hp) == 1
        has_agg_left = repaired_hp[0].left_expr.has_aggregation
        has_agg_right = repaired_hp[0].right_expr is not None and repaired_hp[0].right_expr.has_aggregation
        assert has_agg_left or has_agg_right
        assert not (has_agg_left and has_agg_right)  # one side agg, one side column


class TestValidateQuestionNumericCoverage:
    """Tests for validate_question_numeric_coverage."""

    def test_year_in_date_literal_covered(self):
        """Year substring in date literal (e.g. 2005 in 2005-08-01) is covered."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">=",
            value_type="date",
            raw_value="2005-08-01",
        )
        issues = validate_question_numeric_coverage(
            "Show rentals from 2005",
            [fp],
            [],
            None,
            "main",
        )
        assert len(issues) == 0

    def test_missing_numeric_without_date_covered(self):
        """Number in question without matching filter produces issue."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            value_type="string",
            raw_value="x",
        )
        issues = validate_question_numeric_coverage(
            "Show rows where value is 42",
            [fp],
            [],
            None,
            "main",
        )
        assert len(issues) == 1
        assert "42" in issues[0].message


class TestCompatibleTypePairs:
    """Tests for COMPATIBLE_TYPE_PAIRS constant."""

    def test_int_integer_compatible(self):
        """Int and integer are compatible."""
        assert ("int", "integer") in COMPATIBLE_TYPE_PAIRS

    def test_varchar_text_compatible(self):
        """Varchar and text are compatible."""
        assert ("varchar", "text") in COMPATIBLE_TYPE_PAIRS

    def test_date_timestamp_compatible(self):
        """Date and timestamp are compatible."""
        assert ("date", "timestamp") in COMPATIBLE_TYPE_PAIRS

    def test_number_integer_compatible(self):
        """Number and integer are compatible."""
        assert ("number", "integer") in COMPATIBLE_TYPE_PAIRS

    def test_int_text_not_compatible(self):
        """Int and text are not compatible."""
        assert ("int", "text") not in COMPATIBLE_TYPE_PAIRS
        assert ("text", "int") not in COMPATIBLE_TYPE_PAIRS


class TestValidateNoNestedAggregation:
    """Tests for validate_no_nested_aggregation."""

    def test_nested_agg_in_select(self):
        """validate_no_nested_aggregation detects nested agg in
        select."""
        sc = SelectCol(
            expr=NormalizedExpr(
                agg_func="sum",
                add_groups=[MulGroup(coefficient=1.0, multiply=["orders.amount"], agg_func="count")],
            ),
        )
        issues = validate_no_nested_aggregation([sc], [], [], [])
        assert len(issues) >= 1
        assert any("nested" in i.message.lower() for i in issues)

    def test_no_nesting_passes(self):
        """validate_no_nested_aggregation passes for non-nested agg."""
        sc = SelectCol(
            expr=NormalizedExpr(
                add_groups=[MulGroup(coefficient=1.0, multiply=["orders.amount"], agg_func="sum")],
            ),
        )
        issues = validate_no_nested_aggregation([sc], [], [], [])
        assert len(issues) == 0


class TestValidateMixedAggregationInMulgroup:
    """Tests for validate_mixed_aggregation_in_mulgroup."""

    def test_mixed_agg_bare_errors(self):
        """validate_mixed_aggregation_in_mulgroup errors for mixed agg
        and bare terms."""
        sc = SelectCol(
            expr=NormalizedExpr(
                add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(orders.id)", "customers.name"])],
            ),
        )
        issues = validate_mixed_aggregation_in_mulgroup([sc], [], [], [])
        assert len(issues) >= 1

    def test_all_agg_passes(self):
        """validate_mixed_aggregation_in_mulgroup passes for all-agg
        terms."""
        sc = SelectCol(
            expr=NormalizedExpr(
                add_groups=[MulGroup(coefficient=1.0, multiply=["orders.amount"], agg_func="sum")],
            ),
        )
        issues = validate_mixed_aggregation_in_mulgroup([sc], [], [], [])
        assert len(issues) == 0


class TestValidateOrderByAggregationContext:
    """Tests for validate_order_by_aggregation_context."""

    def test_agg_in_row_level_errors(self):
        """validate_order_by_aggregation_context errors for agg order_by
        at row_level."""
        obc = OrderByCol(
            expr=NormalizedExpr(
                agg_func="count",
                add_groups=[MulGroup(coefficient=1.0, multiply=["orders.id"])],
            ),
        )
        issues = validate_order_by_aggregation_context([obc], grain="row_level")
        assert len(issues) >= 1

    def test_agg_in_grouped_passes(self):
        """validate_order_by_aggregation_context passes for agg order_by
        at grouped."""
        obc = OrderByCol(
            expr=NormalizedExpr(
                agg_func="count",
                add_groups=[MulGroup(coefficient=1.0, multiply=["orders.id"])],
            ),
        )
        issues = validate_order_by_aggregation_context([obc], grain="grouped")
        assert len(issues) == 0

    def test_no_agg_row_level_passes(self):
        """validate_order_by_aggregation_context passes for non-agg at
        row_level."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("orders.id"))
        issues = validate_order_by_aggregation_context([obc], grain="row_level")
        assert len(issues) == 0


class TestValidateSelectGroupByMembership:
    """Tests for validate_select_group_by_membership."""

    def test_non_agg_not_in_group_by_errors(self):
        """validate_select_group_by_membership errors for non-agg select
        not in group_by."""
        sc = SelectCol(expr=NormalizedExpr.from_column("customers.name"))
        gb = [NormalizedExpr.from_column("customers.id")]
        issues = validate_select_group_by_membership([sc], gb, grain="grouped")
        assert len(issues) >= 1

    def test_agg_select_passes(self):
        """validate_select_group_by_membership passes for aggregated
        select."""
        sc = SelectCol(
            expr=NormalizedExpr(
                agg_func="count",
                add_groups=[MulGroup(coefficient=1.0, multiply=["customers.id"])],
            ),
        )
        gb = [NormalizedExpr.from_column("customers.name")]
        issues = validate_select_group_by_membership([sc], gb, grain="grouped")
        assert len(issues) == 0

    def test_non_grouped_grain_passes(self):
        """validate_select_group_by_membership passes for row_level
        grain."""
        sc = SelectCol(expr=NormalizedExpr.from_column("customers.name"))
        issues = validate_select_group_by_membership([sc], [], grain="row_level")
        assert len(issues) == 0


class TestTermHasAggregation:
    """Tests for _term_has_aggregation."""

    def test_count_term(self):
        """Return True for COUNT term."""
        assert _term_has_aggregation("COUNT(t.a)") is True

    def test_sum_term(self):
        """Return True for SUM term."""
        assert _term_has_aggregation("SUM(t.a)") is True

    def test_bare_column(self):
        """Return False for bare column."""
        assert _term_has_aggregation("t.a") is False

    def test_upper_not_agg(self):
        """Return False for UPPER."""
        assert _term_has_aggregation("UPPER(t.a)") is False

    def test_min_term(self):
        """Return True for MIN term."""
        assert _term_has_aggregation("MIN(t.a)") is True


class TestValidateSingleExprTypes:
    """Tests for _validate_single_expr_types."""

    def test_no_arithmetic_no_issues(self, typed_schema):
        """No issues for non-arithmetic expression."""
        expr = NormalizedExpr.from_column("customers.name")
        issues = _validate_single_expr_types(expr, typed_schema, {}, "select_cols[0]", "main")
        assert len(issues) == 0

    def test_arithmetic_with_non_numeric(self, typed_schema):
        """Error for non-numeric column in arithmetic."""
        g = MulGroup(multiply=["customers.name"], coefficient=2.0)
        expr = NormalizedExpr(add_groups=[g])
        issues = _validate_single_expr_types(expr, typed_schema, {}, "select_cols[0]", "main")
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1
        assert "Non-numeric" in errors[0].message

    def test_arithmetic_with_numeric(self, typed_schema):
        """No errors for numeric column in arithmetic."""
        g = MulGroup(multiply=["customers.balance"], coefficient=2.0)
        expr = NormalizedExpr(add_groups=[g])
        issues = _validate_single_expr_types(expr, typed_schema, {}, "select_cols[0]", "main")
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) == 0

    def test_division_with_non_numeric(self, typed_schema):
        """Error for non-numeric column in division."""
        g = MulGroup(multiply=["customers.balance"], divide=["customers.name"])
        expr = NormalizedExpr(add_groups=[g])
        issues = _validate_single_expr_types(expr, typed_schema, {}, "select_cols[0]", "main")
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_role_warning_for_identifier(self, typed_schema):
        """Warning for identifier role in arithmetic."""
        g = MulGroup(multiply=["customers.id"], coefficient=2.0)
        expr = NormalizedExpr(add_groups=[g])
        issues = _validate_single_expr_types(expr, typed_schema, {}, "select_cols[0]", "main")
        warnings = [i for i in issues if i.severity == "warning"]
        assert len(warnings) >= 1


class TestValidateAggVsAggHaving:
    """Tests for validate_agg_vs_agg_having."""

    def test_self_comparison_detected(self, typed_schema):
        """Self-comparison in HAVING produces an issue."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["count(orders.id)"])])
        right = NormalizedExpr(add_groups=[MulGroup(multiply=["count(orders.id)"])])
        hp = HavingParam(
            left_expr=left,
            op=">",
            right_expr=right,
            value_type="integer",
        )
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        assert any("Self-comparison" in i.message for i in issues)

    def test_compatible_agg_no_issue(self, typed_schema):
        """Two numeric aggregations compared produce no issue."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["sum(orders.amount)"])])
        right = NormalizedExpr(add_groups=[MulGroup(multiply=["avg(orders.amount)"])])
        hp = HavingParam(
            left_expr=left,
            op=">",
            right_expr=right,
            value_type="number",
        )
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        assert len(issues) == 0

    def test_no_right_expr_skipped(self, typed_schema):
        """HAVING with no right_expr is skipped."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(multiply=["count(orders.id)"])]),
            op=">",
            value_type="integer",
        )
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        assert len(issues) == 0

    def test_empty_having(self, typed_schema):
        """Empty having list produces no issues."""
        assert validate_agg_vs_agg_having([], typed_schema) == []

    def test_none_having(self, typed_schema):
        """None having list produces no issues."""
        assert validate_agg_vs_agg_having(None, typed_schema) == []

    def test_empty_having_no_issues(self, typed_schema):
        """No issues for empty having list."""
        issues = validate_agg_vs_agg_having([], typed_schema)
        assert len(issues) == 0

    def test_no_right_expr_no_issues(self, typed_schema):
        """No issues when having has no right expr."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(customers.id)"])]),
            op=">",
            value_type="integer",
        )
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        assert len(issues) == 0

    def test_self_comparison_error(self, typed_schema):
        """Error for self-comparison in having."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(customers.id)"])])
        right = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(customers.id)"])])
        hp = HavingParam(left_expr=left, op=">", right_expr=right, value_type="integer")
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        assert any("Self-comparison" in i.message for i in issues)

    def test_type_mismatch_warning(self, typed_schema):
        """Warning for type mismatch between agg targets."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["MIN(customers.balance)"])])
        right = NormalizedExpr(add_groups=[MulGroup(multiply=["MIN(customers.name)"])])
        hp = HavingParam(left_expr=left, op=">", right_expr=right, value_type="number")
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        warnings = [i for i in issues if i.severity == "warning"]
        assert len(warnings) >= 1

    def test_compatible_numeric_aggs_pass(self, typed_schema):
        """No issues for numeric-result agg functions on same type."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["SUM(customers.balance)"])])
        right = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(customers.id)"])])
        hp = HavingParam(left_expr=left, op=">", right_expr=right, value_type="number")
        issues = validate_agg_vs_agg_having([hp], typed_schema)
        assert len(issues) == 0


class TestValidateArithExpressionSemantics:
    """Tests for validate_arith_expression_semantics."""

    def test_empty_inputs_no_issues(self, typed_schema):
        """No issues for empty filter and having lists."""
        issues = validate_arith_expression_semantics([], [], typed_schema)
        assert len(issues) == 0

    def test_no_arithmetic_no_issues(self, typed_schema):
        """Simple column filters with no arithmetic produce no
        issues."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.amount"),
            op=">",
            value_type="number",
        )
        issues = validate_arith_expression_semantics([fp], [], typed_schema)
        assert len(issues) == 0

    def test_arithmetic_with_text_column(self, typed_schema):
        """Arithmetic involving text column produces issue."""
        arith_expr = NormalizedExpr(
            add_groups=[
                MulGroup(multiply=["customers.balance", "customers.description"]),
            ]
        )
        fp = FilterParam(left_expr=arith_expr, op=">", value_type="number", param_key="p1")
        issues = validate_arith_expression_semantics([fp], [], typed_schema)
        assert len(issues) >= 1

    def test_empty_filters_and_having(self, typed_schema):
        """Empty input lists produce no issues."""
        assert validate_arith_expression_semantics([], [], typed_schema) == []

    def test_non_arithmetic_filter_no_issues(self, typed_schema):
        """No issues for non-arithmetic filter."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="=",
            value_type="string",
        )
        issues = validate_arith_expression_semantics([fp], [], typed_schema)
        assert len(issues) == 0

    def test_arithmetic_filter_with_non_numeric(self, typed_schema):
        """Error for non-numeric column in arithmetic filter."""
        g = MulGroup(multiply=["customers.name"], coefficient=2.0)
        fp = FilterParam(left_expr=NormalizedExpr(add_groups=[g]), op=">", value_type="number")
        issues = validate_arith_expression_semantics([fp], [], typed_schema)
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_arithmetic_having_with_non_numeric(self, typed_schema):
        """Error for non-numeric column in arithmetic having."""
        g = MulGroup(multiply=["customers.name"], coefficient=2.0)
        hp = HavingParam(left_expr=NormalizedExpr(add_groups=[g]), op=">", value_type="number")
        issues = validate_arith_expression_semantics([], [hp], typed_schema)
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1


class TestValidateSelectExprTypes:
    """Tests for validate_select_expr_types."""

    def test_empty_select_no_issues(self, typed_schema):
        """No issues for empty select list."""
        issues = validate_select_expr_types([], typed_schema)
        assert len(issues) == 0

    def test_bare_column_no_issues(self, typed_schema):
        """No issues for non-arithmetic select."""
        sc = SelectCol(expr=NormalizedExpr.from_column("customers.name"))
        issues = validate_select_expr_types([sc], typed_schema)
        assert len(issues) == 0

    def test_arithmetic_with_non_numeric(self, typed_schema):
        """Error for non-numeric in arithmetic select."""
        g = MulGroup(multiply=["customers.name"], coefficient=2.0)
        sc = SelectCol(expr=NormalizedExpr(add_groups=[g]))
        issues = validate_select_expr_types([sc], typed_schema)
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_simple_column_no_issue(self, typed_schema):
        """Simple column expression produces no issue."""
        sc = SelectCol(expr=NormalizedExpr.from_column("orders.amount"))
        issues = validate_select_expr_types([sc], typed_schema)
        assert len(issues) == 0

    def test_arithmetic_text_produces_issue(self, typed_schema):
        """Arithmetic on text column produces an issue."""
        arith_expr = NormalizedExpr(
            add_groups=[
                MulGroup(multiply=["customers.name", "customers.balance"]),
            ]
        )
        sc = SelectCol(expr=arith_expr)
        issues = validate_select_expr_types([sc], typed_schema)
        assert len(issues) >= 1


class TestValidateOrderByExprTypes:
    """Tests for validate_order_by_expr_types."""

    def test_empty_order_by_no_issues(self, typed_schema):
        """No issues for empty order_by list."""
        issues = validate_order_by_expr_types([], typed_schema)
        assert len(issues) == 0

    def test_bare_column_no_issues(self, typed_schema):
        """No issues for non-arithmetic order_by."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("customers.name"), direction="asc")
        issues = validate_order_by_expr_types([obc], typed_schema)
        assert len(issues) == 0

    def test_arithmetic_with_non_numeric(self, typed_schema):
        """Error for non-numeric in arithmetic order_by."""
        g = MulGroup(multiply=["customers.name"], coefficient=2.0)
        obc = OrderByCol(expr=NormalizedExpr(add_groups=[g]), direction="asc")
        issues = validate_order_by_expr_types([obc], typed_schema)
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_simple_column_no_issue(self, typed_schema):
        """Simple column ORDER BY produces no issue."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("orders.amount"), direction="asc")
        issues = validate_order_by_expr_types([obc], typed_schema)
        assert len(issues) == 0

    def test_arithmetic_text_produces_issue(self, typed_schema):
        """Arithmetic on text column in ORDER BY produces an issue."""
        arith_expr = NormalizedExpr(
            add_groups=[
                MulGroup(multiply=["customers.name", "customers.balance"]),
            ]
        )
        obc = OrderByCol(expr=arith_expr, direction="desc")
        issues = validate_order_by_expr_types([obc], typed_schema)
        assert len(issues) >= 1

    def test_empty_order_by(self, typed_schema):
        """Empty order by list produces no issues."""
        assert validate_order_by_expr_types([], typed_schema) == []


class TestValidateFilterExprTypes:
    """Tests for validate_filter_expr_types."""

    def test_empty_filters_no_issues(self, typed_schema):
        """No issues for empty filter list."""
        issues = validate_filter_expr_types([], typed_schema)
        assert len(issues) == 0

    def test_non_arithmetic_filter_no_issues(self, typed_schema):
        """No issues for non-arithmetic filter."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="=",
            value_type="string",
        )
        issues = validate_filter_expr_types([fp], typed_schema)
        assert len(issues) == 0

    def test_cross_type_mismatch(self, typed_schema):
        """Error for numeric vs non-numeric expr-vs-expr comparison."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["customers.balance"], coefficient=2.0)])
        right = NormalizedExpr.from_column("customers.name")
        fp = FilterParam(left_expr=left, op=">", right_expr=right, value_type="number")
        issues = validate_filter_expr_types([fp], typed_schema)
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_arithmetic_op_mismatch(self, typed_schema):
        """Error for LIKE on arithmetic expression."""
        g = MulGroup(multiply=["customers.balance"], coefficient=2.0)
        fp = FilterParam(left_expr=NormalizedExpr(add_groups=[g]), op="like", value_type="string")
        issues = validate_filter_expr_types([fp], typed_schema)
        errors = [i for i in issues if "invalid" in i.message.lower() or "op" in i.message.lower()]
        assert len(errors) >= 1

    def test_simple_filter_no_issue(self, typed_schema):
        """Simple column filter produces no issue."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.amount"),
            op=">",
            value_type="number",
            param_key="p1",
        )
        issues = validate_filter_expr_types([fp], typed_schema)
        assert len(issues) == 0

    def test_cross_type_mismatch_direct_columns(self, typed_schema):
        """Numeric vs non-numeric cross comparison produces issue."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.amount"),
            op=">",
            right_expr=NormalizedExpr.from_column("customers.name"),
            value_type="number",
            param_key="p1",
        )
        issues = validate_filter_expr_types([fp], typed_schema)
        assert any("cross_type_mismatch" in i.issue_id or "mismatch" in i.message.lower() for i in issues)

    def test_empty_filters(self, typed_schema):
        """Empty filter list produces no issues."""
        assert validate_filter_expr_types([], typed_schema) == []

    def test_none_filters(self, typed_schema):
        """None filter list produces no issues."""
        assert validate_filter_expr_types(None, typed_schema) == []


class TestValidateHavingExprTypes:
    """Tests for validate_having_expr_types."""

    def test_empty_having_no_issues(self, typed_schema):
        """No issues for empty having list."""
        issues = validate_having_expr_types([], typed_schema)
        assert len(issues) == 0

    def test_non_arithmetic_having_no_issues(self, typed_schema):
        """No issues for non-arithmetic having."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(customers.id)"])]),
            op=">",
            value_type="integer",
        )
        issues = validate_having_expr_types([hp], typed_schema)
        assert len(issues) == 0

    def test_cross_type_mismatch(self, typed_schema):
        """Error for numeric vs non-numeric having comparison."""
        left = NormalizedExpr(add_groups=[MulGroup(multiply=["customers.balance"], coefficient=2.0)])
        right = NormalizedExpr.from_column("customers.name")
        hp = HavingParam(left_expr=left, op=">", right_expr=right, value_type="number")
        issues = validate_having_expr_types([hp], typed_schema)
        errors = [i for i in issues if i.severity == "error"]
        assert len(errors) >= 1

    def test_simple_having_no_issue(self, typed_schema):
        """Aggregated having with numeric type produces no issue."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op=">",
            value_type="integer",
            param_key="p1",
        )
        issues = validate_having_expr_types([hp], typed_schema)
        assert len(issues) == 0

    def test_cross_type_mismatch_having(self, typed_schema):
        """Numeric vs non-numeric cross comparison in HAVING produces
        issue."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "orders.amount"),
            op=">",
            right_expr=NormalizedExpr.from_column("customers.name"),
            value_type="number",
            param_key="p1",
        )
        issues = validate_having_expr_types([hp], typed_schema)
        assert len(issues) >= 1

    def test_empty_having(self, typed_schema):
        """Empty having list produces no issues."""
        assert validate_having_expr_types([], typed_schema) == []

    def test_none_having(self, typed_schema):
        """None having list produces no issues."""
        assert validate_having_expr_types(None, typed_schema) == []


class TestCheckNestedAggregation:
    """Tests for _check_nested_aggregation."""

    def test_no_nesting(self):
        """No issues for non-nested expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["t.a"], agg_func="sum")])
        issues = _check_nested_aggregation(expr, "select_cols[0]", "main")
        assert len(issues) == 0

    def test_expr_wraps_group_agg(self):
        """Error for expr-level agg wrapping group-level agg."""
        expr = NormalizedExpr(agg_func="sum", add_groups=[MulGroup(multiply=["t.a"], agg_func="count")])
        issues = _check_nested_aggregation(expr, "select_cols[0]", "main")
        assert len(issues) >= 1
        assert any("nested" in i.message.lower() for i in issues)

    def test_expr_wraps_inline_agg(self):
        """Error for expr-level agg wrapping inline agg term."""
        expr = NormalizedExpr(agg_func="sum", add_groups=[MulGroup(multiply=["COUNT(t.a)"])])
        issues = _check_nested_aggregation(expr, "select_cols[0]", "main")
        assert len(issues) >= 1

    def test_group_wraps_inline_agg(self):
        """Error for group-level agg wrapping inline agg term."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(t.a)"], agg_func="sum")])
        issues = _check_nested_aggregation(expr, "select_cols[0]", "main")
        assert len(issues) >= 1


class TestCheckMixedAggregationInGroup:
    """Tests for _check_mixed_aggregation_in_group."""

    def test_all_agg_no_issues(self):
        """No issues when all terms are aggregated."""
        g = MulGroup(multiply=["COUNT(t.a)", "SUM(t.b)"])
        issues = _check_mixed_aggregation_in_group(g, "select_cols[0]_add[0]", "main")
        assert len(issues) == 0

    def test_mixed_agg_bare_error(self):
        """Error when mixing agg and bare terms."""
        g = MulGroup(multiply=["COUNT(t.a)", "t.b"])
        issues = _check_mixed_aggregation_in_group(g, "select_cols[0]_add[0]", "main")
        assert len(issues) == 1
        assert "mixes" in issues[0].message.lower()

    def test_group_level_agg_skips_check(self):
        """No issues when group has agg_func (covers all terms)."""
        g = MulGroup(multiply=["t.a", "t.b"], agg_func="sum")
        issues = _check_mixed_aggregation_in_group(g, "select_cols[0]_add[0]", "main")
        assert len(issues) == 0

    def test_single_term_no_issues(self):
        """No issues for single-term group."""
        g = MulGroup(multiply=["COUNT(t.a)"])
        issues = _check_mixed_aggregation_in_group(g, "select_cols[0]_add[0]", "main")
        assert len(issues) == 0


class TestCheckMixedAggregationInExpr:
    """Tests for _check_mixed_aggregation_in_expr."""

    def test_single_group_no_issues(self):
        """No issues for single-group expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(t.a)"])])
        issues = _check_mixed_aggregation_in_expr(expr, "select_cols[0]", "main")
        assert len(issues) == 0

    def test_mixed_across_groups_error(self):
        """Error when mixing agg and bare across groups."""
        g1 = MulGroup(multiply=["COUNT(t.a)"])
        g2 = MulGroup(multiply=["t.b"])
        expr = NormalizedExpr(add_groups=[g1, g2])
        issues = _check_mixed_aggregation_in_expr(expr, "select_cols[0]", "main")
        cross_issues = [
            i
            for i in issues
            if "across" in i.issue_id or "across" in i.message.lower() or "groups" in i.message.lower()
        ]
        assert len(cross_issues) >= 1

    def test_all_agg_groups_no_issues(self):
        """No issues when all groups have aggregation."""
        g1 = MulGroup(multiply=["COUNT(t.a)"])
        g2 = MulGroup(multiply=["SUM(t.b)"])
        expr = NormalizedExpr(add_groups=[g1, g2])
        issues = _check_mixed_aggregation_in_expr(expr, "select_cols[0]", "main")
        assert len(issues) == 0


class TestValidateCteGrainConsistency:
    """Tests for validate_cte_grain_consistency."""

    def test_grouped_with_group_by(self):
        """No issues for grouped CTE with group_by."""
        cte = RuntimeCteStep(
            cte_name="base",
            grain="grouped",
            group_by_cols=[NormalizedExpr.from_column("t.a")],
            select_cols=[SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(t.a)"])]))],
        )
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        grain_errors = [i for i in issues if i.severity == "error"]
        assert len(grain_errors) == 0

    def test_grouped_without_group_by(self):
        """Error for grouped CTE without group_by."""
        cte = RuntimeCteStep(cte_name="base", grain="grouped")
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        assert any("no group_by_cols" in i.message for i in issues)

    def test_row_level_with_group_by(self):
        """Error for row_level CTE with group_by."""
        cte = RuntimeCteStep(
            cte_name="base",
            grain="row_level",
            group_by_cols=[NormalizedExpr.from_column("t.a")],
        )
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        assert any("group_by_cols" in i.message for i in issues)

    def test_row_level_with_agg(self):
        """Error for row_level CTE with aggregation."""
        cte = RuntimeCteStep(
            cte_name="base",
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(t.a)"])]))],
        )
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        assert any("aggregation" in i.message.lower() and "row_level" in i.message for i in issues)

    def test_scalar_with_group_by(self):
        """Error for scalar CTE with group_by."""
        cte = RuntimeCteStep(
            cte_name="base",
            grain="scalar",
            group_by_cols=[NormalizedExpr.from_column("t.a")],
        )
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        assert any("group_by_cols" in i.message for i in issues)

    def test_having_without_agg(self):
        """Error for CTE with having but no aggregation."""
        cte = RuntimeCteStep(
            cte_name="base",
            having_param=[
                HavingParam(
                    left_expr=NormalizedExpr.from_column("t.a"),
                    op=">",
                    value_type="integer",
                )
            ],
        )
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        assert any("HAVING" in i.message for i in issues)

    def test_agg_without_group_by_non_scalar_warns(self):
        """Warning for aggregation without group_by when grain is not
        scalar."""
        cte = RuntimeCteStep(
            cte_name="base",
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(t.a)"])]))],
        )
        issues = validate_cte_grain_consistency(cte, "CTE 'base'")
        warnings = [i for i in issues if i.severity == "warning"]
        assert len(warnings) >= 1

    def test_grouped_without_group_by_explicit(self):
        """Grouped CTE without group_by produces error."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "t.a"))],
            group_by_cols=[],
        )
        issues = validate_cte_grain_consistency(cte, "cte1")
        assert any("grouped" in i.message and "no group_by" in i.message for i in issues)

    def test_row_level_with_aggregation(self):
        """Row-level CTE with aggregation produces error."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("sum", "t.a"))],
            group_by_cols=[],
        )
        issues = validate_cte_grain_consistency(cte, "cte1")
        assert any("row_level" in i.message for i in issues)

    def test_having_without_select_agg(self):
        """CTE with HAVING but no aggregation produces error."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.a"))],
            group_by_cols=[NormalizedExpr.from_column("t.a")],
            having_param=[
                HavingParam(
                    left_expr=NormalizedExpr.from_agg("count", "t.b"),
                    op=">",
                    value_type="integer",
                )
            ],
        )
        issues = validate_cte_grain_consistency(cte, "cte1")
        assert any("HAVING" in i.message and "no aggregation" in i.message for i in issues)


class TestValidateCteDependencyGrains:
    """Tests for validate_cte_dependency_grains."""

    def test_no_ctes_no_issues(self):
        """No issues for empty CTE list."""
        issues = validate_cte_dependency_grains([], "row_level")
        assert len(issues) == 0

    def test_row_level_depends_on_grouped(self):
        """Warning when row_level CTE depends on grouped CTE."""
        cte1 = RuntimeCteStep(cte_name="agg", grain="grouped", tables=["customers"])
        cte2 = RuntimeCteStep(cte_name="detail", grain="row_level", tables=["agg"])
        issues = validate_cte_dependency_grains([cte1, cte2], "row_level")
        warnings = [i for i in issues if "incompatible" in i.issue_id.lower()]
        assert len(warnings) >= 1

    def test_main_row_level_uses_grouped_cte(self):
        """Warning when main query (row_level) uses aggregated final
        CTE."""
        cte = RuntimeCteStep(cte_name="agg", grain="grouped", tables=["customers"])
        issues = validate_cte_dependency_grains([cte], "row_level")
        warnings = [i for i in issues if "main" in i.message.lower()]
        assert len(warnings) >= 1

    def test_compatible_grains_no_issues(self):
        """No issues when grains are compatible."""
        cte1 = RuntimeCteStep(cte_name="base", grain="row_level", tables=["customers"])
        cte2 = RuntimeCteStep(cte_name="agg", grain="grouped", tables=["base"])
        issues = validate_cte_dependency_grains([cte1, cte2], "grouped")
        dep_issues = [i for i in issues if "cte_grain_incompatible" in i.issue_id]
        assert len(dep_issues) == 0

    def test_single_cte_grouped_main_grouped(self):
        """No issues when single CTE and main are both grouped."""
        cte = RuntimeCteStep(cte_name="base", grain="grouped", tables=["customers"])
        issues = validate_cte_dependency_grains([cte], "grouped")
        assert len(issues) == 0

    def test_row_level_depends_on_grouped_message(self):
        """Row-level CTE depending on grouped CTE produces warning."""
        cte1 = RuntimeCteStep(cte_name="cte1", grain="grouped")
        cte2 = RuntimeCteStep(cte_name="cte2", grain="row_level", tables=["cte1"])
        issues = validate_cte_dependency_grains([cte1, cte2], "row_level")
        assert any("row_level" in i.message and "aggregated" in i.message for i in issues)

    def test_grouped_depends_on_grouped_no_issue(self):
        """Grouped CTE depending on grouped CTE produces no issue."""
        cte1 = RuntimeCteStep(cte_name="cte1", grain="grouped")
        cte2 = RuntimeCteStep(cte_name="cte2", grain="grouped", tables=["cte1"])
        issues = validate_cte_dependency_grains([cte1, cte2], "grouped")
        assert len(issues) == 0

    def test_main_row_level_with_grouped_final_cte(self):
        """Main query row_level with final CTE grouped produces
        warning."""
        cte1 = RuntimeCteStep(cte_name="cte1", grain="grouped")
        issues = validate_cte_dependency_grains([cte1], "row_level")
        assert any("Main query" in i.message for i in issues)

    def test_empty_cte_steps(self):
        """Empty CTE list produces no issues."""
        assert validate_cte_dependency_grains([], "row_level") == []

    def test_no_cross_cte_dependency(self):
        """Independent CTEs produce no cross-dependency issues."""
        cte1 = RuntimeCteStep(cte_name="cte1", grain="grouped", tables=["orders"])
        cte2 = RuntimeCteStep(cte_name="cte2", grain="row_level", tables=["customers"])
        issues = validate_cte_dependency_grains([cte1, cte2], "grouped")
        assert not any("depends on aggregated" in i.message for i in issues)


class TestValidateFilterNoAggregationEdgeCases:
    """Edge-case tests for validate_filter_no_aggregation."""

    def test_right_expr_aggregated(self):
        """Error for aggregated right expression."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            right_expr=NormalizedExpr.from_agg("count", "t.b"),
            value_type="integer",
        )
        issues = validate_filter_no_aggregation([fp])
        assert len(issues) >= 1

    def test_empty_filters(self):
        """No issues for empty filter list."""
        issues = validate_filter_no_aggregation([])
        assert len(issues) == 0

    def test_none_filters(self):
        """No issues for None filter list."""
        issues = validate_filter_no_aggregation(None)
        assert len(issues) == 0


class TestValidateHavingRequiresAggregationEdgeCases:
    """Edge-case tests for validate_having_requires_aggregation."""

    def test_empty_having(self):
        """No issues for empty having list."""
        issues = validate_having_requires_aggregation([])
        assert len(issues) == 0

    def test_none_having(self):
        """No issues for None having list."""
        issues = validate_having_requires_aggregation(None)
        assert len(issues) == 0

    def test_multiple_non_agg_having(self):
        """Multiple errors for multiple non-aggregated having."""
        hp1 = HavingParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            value_type="integer",
            param_key="p1",
        )
        hp2 = HavingParam(
            left_expr=NormalizedExpr.from_column("t.b"),
            op="=",
            value_type="string",
            param_key="p2",
        )
        issues = validate_having_requires_aggregation([hp1, hp2])
        assert len(issues) == 2


class TestValidateGroupedRequiresAggregation:
    def test_grouped_with_group_by_no_agg_error(self):
        select_cols = [SelectCol(expr=NormalizedExpr.from_column("orders.status"))]
        group_by_cols = [NormalizedExpr.from_column("orders.status")]
        issues = validate_grouped_requires_aggregation("grouped", select_cols, group_by_cols)
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert "aggregation" in issues[0].message.lower()

    def test_grouped_with_agg_no_issue(self):
        select_cols = [
            SelectCol(expr=NormalizedExpr.from_column("orders.status")),
            SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id")),
        ]
        group_by_cols = [NormalizedExpr.from_column("orders.status")]
        issues = validate_grouped_requires_aggregation("grouped", select_cols, group_by_cols)
        assert issues == []

    def test_row_level_no_issue(self):
        select_cols = [SelectCol(expr=NormalizedExpr.from_column("orders.status"))]
        issues = validate_grouped_requires_aggregation("row_level", select_cols, [])
        assert issues == []

    def test_grouped_without_group_by_no_issue(self):
        select_cols = [SelectCol(expr=NormalizedExpr.from_column("orders.status"))]
        issues = validate_grouped_requires_aggregation("grouped", select_cols, [])
        assert issues == []

    def test_scalar_no_issue(self):
        select_cols = [SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id"))]
        issues = validate_grouped_requires_aggregation("scalar", select_cols, [])
        assert issues == []


class TestValidateQuestionAggregationHint:
    """Tests for validate_question_aggregation_hint."""

    def test_empty_natural_language_returns_empty(self):
        """No issues when natural_language is empty."""
        issues = validate_question_aggregation_hint(
            "",
            [SelectCol(expr=NormalizedExpr.from_column("t.a"))],
            [],
            "row_level",
        )
        assert issues == []

    def test_no_match_returns_empty(self):
        """No issues when question has no quantity-comparison phrase."""
        issues = validate_question_aggregation_hint(
            "Show me all orders",
            [SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            [],
            "row_level",
        )
        assert issues == []

    def test_match_with_row_level_no_agg_returns_issue(self):
        """Issue when phrase like 'more than 5' present but no aggregation."""
        issues = validate_question_aggregation_hint(
            "Orders with more than 5 items",
            [SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            [],
            "row_level",
        )
        assert len(issues) == 1
        assert issues[0].severity == "warning"
        assert "missing_aggregation_hint" in issues[0].issue_id
        assert "aggregation" in issues[0].message.lower()

    def test_match_with_aggregation_returns_empty(self):
        """No issue when select_cols already has aggregation."""
        issues = validate_question_aggregation_hint(
            "Customers with more than 10 orders",
            [SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id"))],
            [],
            "row_level",
        )
        assert issues == []

    def test_match_with_having_returns_empty(self):
        """No issue when having_param is non-empty."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op=">",
            value_type="number",
            param_key="h1",
            raw_value="5",
        )
        issues = validate_question_aggregation_hint(
            "More than 5 orders",
            [SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            [hp],
            "row_level",
        )
        assert issues == []

    def test_match_with_grouped_grain_returns_empty(self):
        """No issue when grain is grouped."""
        issues = validate_question_aggregation_hint(
            "Orders with more than 5 items",
            [SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            [],
            "grouped",
        )
        assert issues == []

    def test_match_with_scalar_grain_returns_empty(self):
        """No issue when grain is scalar."""
        issues = validate_question_aggregation_hint(
            "Total more than 100",
            [SelectCol(expr=NormalizedExpr.from_agg("sum", "orders.amount"))],
            [],
            "scalar",
        )
        assert issues == []


class TestValidateThresholdMissingHaving:
    """Tests for validate_threshold_missing_having."""

    def test_fires_when_grouped_agg_threshold_no_having(self):
        """Issue raised when grain='grouped', agg exists, threshold phrase
        matches, but no HAVING is defined."""
        issues = validate_threshold_missing_having(
            "Customers with more than 5 orders",
            [
                SelectCol(expr=NormalizedExpr.from_column("customer.name")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id")),
            ],
            [],
            "grouped",
        )
        assert len(issues) == 1
        assert issues[0].category == "threshold_missing_having"
        assert issues[0].severity == "error"

    def test_silent_when_having_present(self):
        """No issue when HAVING is already defined."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op=">",
            value_type="number",
            raw_value=5,
        )
        issues = validate_threshold_missing_having(
            "Customers with more than 5 orders",
            [
                SelectCol(expr=NormalizedExpr.from_column("customer.name")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id")),
            ],
            [hp],
            "grouped",
        )
        assert issues == []

    def test_silent_when_not_grouped(self):
        """No issue when grain is row_level."""
        issues = validate_threshold_missing_having(
            "Orders with more than 5 items",
            [SelectCol(expr=NormalizedExpr.from_agg("count", "items.id"))],
            [],
            "row_level",
        )
        assert issues == []

    def test_silent_when_no_aggregation(self):
        """No issue when no aggregated select column exists."""
        issues = validate_threshold_missing_having(
            "Customers with more than 5 orders",
            [SelectCol(expr=NormalizedExpr.from_column("customer.name"))],
            [],
            "grouped",
        )
        assert issues == []

    def test_silent_when_no_threshold_phrase(self):
        """No issue when question has no threshold phrase."""
        issues = validate_threshold_missing_having(
            "List all customers and their order counts",
            [
                SelectCol(expr=NormalizedExpr.from_column("customer.name")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id")),
            ],
            [],
            "grouped",
        )
        assert issues == []

    def test_silent_when_empty_question(self):
        """No issue when natural_language is empty."""
        issues = validate_threshold_missing_having(
            "",
            [SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id"))],
            [],
            "grouped",
        )
        assert issues == []

    def test_at_least_phrase_fires(self):
        """'at least' threshold phrase triggers issue."""
        issues = validate_threshold_missing_having(
            "Actors in at least 10 films",
            [
                SelectCol(expr=NormalizedExpr.from_column("actor.name")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "film.id")),
            ],
            [],
            "grouped",
        )
        assert len(issues) == 1

    def test_context_label_propagated(self):
        """Context label appears in issue_id and context dict."""
        issues = validate_threshold_missing_having(
            "Items with more than 3 reviews",
            [
                SelectCol(expr=NormalizedExpr.from_column("items.name")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "reviews.id")),
            ],
            [],
            "grouped",
            context="cte_step",
        )
        assert len(issues) == 1
        assert "cte_step" in issues[0].issue_id
        assert issues[0].context["location"] == "cte_step"


class TestValidateForEachGrouping:
    """Tests for validate_for_each_grouping."""

    @staticmethod
    def _make_schema():
        """Build a minimal schema with customer and store tables."""
        return SchemaGraph(
            tables={
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "first_name": ColumnMetadata(
                            name="first_name",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="customer_id",
                ),
                "store": TableMetadata(
                    name="store",
                    columns={
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="store_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_fires_when_per_entity_missing_from_group_by(self):
        """Issue raised when 'per customer' without aggregation keyword
        prefix and customer not in group_by."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "show rentals per customer",
            [],
            schema,
            True,
            "main",
        )
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert issues[0].category == "for_each_grouping"

    def test_silent_when_entity_in_group_by(self):
        """No issue when 'per store' and store column in group_by."""
        schema = self._make_schema()
        gb = [NormalizedExpr.from_column("store.store_id")]
        issues = validate_for_each_grouping(
            "show sales per store",
            gb,
            schema,
            True,
            "main",
        )
        assert issues == []

    def test_silent_when_no_for_each_phrase(self):
        """No issue when question has no 'for each' / 'per' phrase."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "show all customers",
            [],
            schema,
            True,
            "main",
        )
        assert issues == []

    def test_silent_when_noun_not_in_schema(self):
        """No issue when the noun after 'per' does not match any table
        or column."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "revenue per region",
            [],
            schema,
            True,
            "main",
        )
        assert issues == []

    def test_silent_when_no_aggregation(self):
        """No issue when question says 'for each' but intent has no
        aggregation context."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "show district for each customer",
            [],
            schema,
            False,
            "main",
        )
        assert issues == []

    def test_silent_on_by_phrase(self):
        """No issue when question uses 'by total payment' — removed
        'by' from pattern to avoid false positives."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "top 5 customers by total payment",
            [],
            schema,
            True,
            "main",
        )
        assert issues == []


class TestValidateNoPkFkFilters:
    """Tests for validate_no_pk_fk_filters severity."""

    @staticmethod
    def _make_schema():
        """Schema with PK and FK columns on customer table."""
        return SchemaGraph(
            tables={
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                        ),
                        "first_name": ColumnMetadata(
                            name="first_name",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="customer_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_pk_filter_severity_error(self):
        """Filter on PK column produces severity=error."""
        schema = self._make_schema()
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.customer_id"),
            op="=",
            value_type="integer",
            raw_value=1,
        )
        issues = validate_no_pk_fk_filters([fp], schema)
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert issues[0].category == "pk_fk_filter"

    def test_fk_filter_literal_severity_error(self):
        """Filter on FK column with a literal raw_value produces severity=error."""
        schema = self._make_schema()
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.store_id"),
            op="=",
            value_type="integer",
            raw_value=2,
        )
        issues = validate_no_pk_fk_filters([fp], schema)
        assert len(issues) == 1
        assert issues[0].severity == "error"

    def test_fk_filter_column_comparison_severity_warning(self):
        """Filter comparing an FK column to a plain column (right_expr set) produces severity=warning."""
        schema = self._make_schema()
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.store_id"),
            right_expr=NormalizedExpr.from_column("customer.first_name"),
            op="=",
            value_type="string",
        )
        issues = validate_no_pk_fk_filters([fp], schema)
        assert len(issues) == 1
        assert issues[0].severity == "warning"

    def test_non_pk_fk_filter_no_issue(self):
        """Filter on a regular column produces no issue."""
        schema = self._make_schema()
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.first_name"),
            op="=",
            value_type="string",
            raw_value="Alice",
        )
        issues = validate_no_pk_fk_filters([fp], schema)
        assert issues == []


class TestForEachGroupingAggKeywordSkip:
    """Tests for validate_for_each_grouping skipping 'per X' after agg keywords."""

    @staticmethod
    def _make_schema():
        return SchemaGraph(
            tables={
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="customer_id",
                ),
                "rental": TableMetadata(
                    name="rental",
                    columns={
                        "rental_id": ColumnMetadata(
                            name="rental_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="rental_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_per_customer_after_average_keyword_skipped(self):
        """'average payment per customer' should NOT fire because 'per'
        is preceded by 'average'."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "average payment per customer",
            [],
            schema,
            True,
            "main",
        )
        assert issues == []

    def test_per_rental_after_total_keyword_skipped(self):
        """'total amount per rental' should NOT fire because 'per'
        is preceded by 'total'."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "total amount per rental",
            [],
            schema,
            True,
            "main",
        )
        assert issues == []

    def test_per_customer_after_count_keyword_skipped(self):
        """'count of films per customer' should NOT fire because 'per'
        is preceded by 'count'."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "count of films per customer",
            [],
            schema,
            True,
            "main",
        )
        assert issues == []

    def test_per_customer_without_agg_prefix_still_fires(self):
        """'show data per customer' fires because no agg keyword
        precedes 'per'."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "show data per customer",
            [],
            schema,
            True,
            "main",
        )
        assert len(issues) == 1
        assert issues[0].category == "for_each_grouping"

    def test_for_each_customer_still_fires(self):
        """'for each customer' always fires regardless of agg prefix
        (skip only applies to 'per')."""
        schema = self._make_schema()
        issues = validate_for_each_grouping(
            "average payment for each customer",
            [],
            schema,
            True,
            "main",
        )
        assert len(issues) == 1


class TestValidateQuestionTableMentionsSeverity:
    """Tests for validate_question_table_mentions severity."""

    @staticmethod
    def _make_schema():
        return SchemaGraph(
            tables={
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="customer_id",
                ),
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="film_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_missing_table_produces_error(self):
        """Missing table mention produces severity='warning'."""
        schema = self._make_schema()
        issues = validate_question_table_mentions(
            "show all customer films",
            ["customer"],
            schema,
        )
        assert len(issues) == 1
        assert issues[0].severity == "warning"
        assert issues[0].category == "missing_scoping_table"

    def test_no_issue_when_table_present(self):
        """No issue when all mentioned tables are in intent."""
        schema = self._make_schema()
        issues = validate_question_table_mentions(
            "show all customer films",
            ["customer", "film"],
            schema,
        )
        assert issues == []

    def test_no_issue_when_question_has_no_table_words(self):
        """No issue when question text does not match any table."""
        schema = self._make_schema()
        issues = validate_question_table_mentions(
            "show all data",
            ["customer"],
            schema,
        )
        assert issues == []


class TestWordIsColumnComponent:
    """Tests for _word_is_column_component suppression helper."""

    @staticmethod
    def _make_schema() -> SchemaGraph:
        """Schema with film table having a rental_duration column."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "rental_duration": ColumnMetadata(
                            name="rental_duration",
                            data_type="integer",
                            value_type="integer",
                        ),
                        "rating": ColumnMetadata(
                            name="rating",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="film_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_word_in_column_prefix_returns_true(self):
        """'rental' is a component of 'rental_duration' on film."""
        schema = self._make_schema()
        assert _word_is_column_component("rental", {"film"}, schema) is True

    def test_word_in_column_suffix_returns_true(self):
        """'duration' is a component of 'rental_duration' on film."""
        schema = self._make_schema()
        assert _word_is_column_component("duration", {"film"}, schema) is True

    def test_unrelated_word_returns_false(self):
        """'payment' does not appear in any column component."""
        schema = self._make_schema()
        assert _word_is_column_component("payment", {"film"}, schema) is False

    def test_table_not_in_intent_returns_false(self):
        """Even if the word matches, returns False when table is not
        in the intent set."""
        schema = self._make_schema()
        assert _word_is_column_component("rental", set(), schema) is False

    def test_exact_column_name_returns_true(self):
        """'rating' is a single-token column name on film."""
        schema = self._make_schema()
        assert _word_is_column_component("rating", {"film"}, schema) is True


class TestTableMentionsSuppression:
    """Tests validate_question_table_mentions with column-component
    suppression."""

    @staticmethod
    def _make_schema() -> SchemaGraph:
        """Schema with film (rental_duration) and rental tables."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "rental_duration": ColumnMetadata(
                            name="rental_duration",
                            data_type="integer",
                            value_type="integer",
                        ),
                        "rental_rate": ColumnMetadata(
                            name="rental_rate",
                            data_type="numeric",
                            value_type="float",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="film_id",
                ),
                "rental": TableMetadata(
                    name="rental",
                    columns={
                        "rental_id": ColumnMetadata(
                            name="rental_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="rental_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_rental_in_column_concept_is_suppressed(self):
        """'rental duration' does not trigger the rental table when
        film is already in the intent and film has rental_duration."""
        schema = self._make_schema()
        issues = validate_question_table_mentions(
            "average rental duration per film rating",
            ["film"],
            schema,
        )
        assert issues == []

    def test_rental_table_fires_when_no_column_match(self):
        """'rental' in the question fires when the intent table has no
        column whose name contains 'rental' as a component."""
        schema = SchemaGraph(
            tables={
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "first_name": ColumnMetadata(
                            name="first_name",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="customer_id",
                ),
                "rental": TableMetadata(
                    name="rental",
                    columns={
                        "rental_id": ColumnMetadata(
                            name="rental_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="rental_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )
        issues = validate_question_table_mentions(
            "show all rentals",
            ["customer"],
            schema,
        )
        assert len(issues) == 1
        assert issues[0].context["table"] == "rental"

    def test_rental_rate_column_also_suppresses(self):
        """'rate' is suppressed because it is a component of
        'rental_rate' on film."""
        schema = self._make_schema()
        issues = validate_question_table_mentions(
            "show average rental rate",
            ["film"],
            schema,
        )
        assert issues == []


class TestValidateQuestionAggKeywordCoverage:
    """Tests for validate_question_agg_keyword_coverage."""

    @staticmethod
    def _agg_select_col() -> SelectCol:
        """Return a SelectCol with an aggregated expression."""
        return SelectCol(expr=NormalizedExpr.from_agg("sum", "payment.amount"))

    def test_fires_when_total_keyword_and_no_agg(self):
        """'total' in question with no aggregation fires a warning."""
        issues = validate_question_agg_keyword_coverage(
            "total revenue per country",
            [],
            [],
        )
        assert len(issues) == 1
        assert issues[0].category == "agg_keyword_missing"
        assert issues[0].severity == "warning"

    def test_fires_when_count_keyword_and_no_agg(self):
        """'count' in question with no aggregation fires a warning."""
        issues = validate_question_agg_keyword_coverage(
            "count active customers",
            [],
            [],
        )
        assert len(issues) == 1
        assert issues[0].severity == "warning"

    def test_fires_when_average_keyword_and_no_agg(self):
        """'average' in question with no aggregation fires a warning."""
        issues = validate_question_agg_keyword_coverage(
            "average rental duration per rating",
            [],
            [],
        )
        assert len(issues) == 1

    def test_fires_when_how_many_keyword_and_no_agg(self):
        """'how many' in question with no aggregation fires a warning."""
        issues = validate_question_agg_keyword_coverage(
            "how many films is each actor in",
            [],
            [],
        )
        assert len(issues) == 1

    def test_silent_when_agg_present_in_select(self):
        """No issue when the intent already has an aggregated column."""
        col = self._agg_select_col()
        issues = validate_question_agg_keyword_coverage(
            "total revenue per country",
            [col],
            [],
        )
        assert issues == []

    def test_silent_when_having_present(self):
        """No issue when HAVING is present (aggregation implied)."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "rental.rental_id"),
            op=">",
            value_type="integer",
            raw_value=5,
        )
        issues = validate_question_agg_keyword_coverage(
            "total revenue per country",
            [],
            [hp],
        )
        assert issues == []

    def test_silent_when_no_agg_keyword(self):
        """No issue when the question has no aggregation keyword."""
        issues = validate_question_agg_keyword_coverage(
            "list all active customers",
            [],
            [],
        )
        assert issues == []

    def test_silent_when_question_empty(self):
        """No issue when question is empty string."""
        issues = validate_question_agg_keyword_coverage("", [], [])
        assert issues == []

    def test_issue_id_contains_context(self):
        """Issue id encodes the context label."""
        issues = validate_question_agg_keyword_coverage(
            "total revenue per country",
            [],
            [],
            context="cte_step_1",
        )
        assert "cte_step_1" in issues[0].issue_id


class TestValidateCountThresholdMissingHaving:
    """Tests for validate_count_threshold_missing_having."""

    @staticmethod
    def _make_schema():
        """Schema with film, inventory, and store for threshold tests."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "title": ColumnMetadata(
                            name="title",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="film_id",
                ),
                "inventory": TableMetadata(
                    name="inventory",
                    columns={
                        "inventory_id": ColumnMetadata(
                            name="inventory_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("film", "film_id"),
                        ),
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("store", "store_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="inventory_id",
                ),
                "store": TableMetadata(
                    name="store",
                    columns={
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="store_id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_emits_error_when_having_missing(self):
        """Threshold phrase without HAVING produces an error."""
        schema = self._make_schema()
        issues = validate_count_threshold_missing_having(
            "list films available in exactly 2 stores",
            ["film", "inventory"],
            [],
            schema,
        )
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert issues[0].category == "count_threshold_missing_having"
        assert "inventory.store_id" in issues[0].message

    def test_no_issue_when_having_present(self):
        """No issue when a HAVING clause already exists."""
        schema = self._make_schema()
        hp = HavingParam(
            left_expr=NormalizedExpr(
                add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(DISTINCT inventory.store_id)"])]
            ),
            op="=",
            value_type="integer",
            raw_value=2,
        )
        issues = validate_count_threshold_missing_having(
            "list films available in exactly 2 stores",
            ["film", "inventory"],
            [hp],
            schema,
        )
        assert issues == []

    def test_no_issue_when_pattern_absent(self):
        """No issue when question has no count-threshold pattern."""
        schema = self._make_schema()
        issues = validate_count_threshold_missing_having(
            "list all films",
            ["film"],
            [],
            schema,
        )
        assert issues == []

    def test_no_issue_when_word_not_in_schema(self):
        """No issue when threshold word does not resolve to a table."""
        schema = self._make_schema()
        issues = validate_count_threshold_missing_having(
            "list films in exactly 2 warehouses",
            ["film"],
            [],
            schema,
        )
        assert issues == []

    def test_fk_column_in_context(self):
        """Issue context includes the FK column reference."""
        schema = self._make_schema()
        issues = validate_count_threshold_missing_having(
            "films in exactly 3 stores",
            ["film", "inventory"],
            [],
            schema,
        )
        assert issues[0].context["fk_column"] == "inventory.store_id"
        assert issues[0].context["threshold_count"] == "3"
