"""Unit tests for text2sql.qsim_sample module."""

from datetime import datetime
from types import SimpleNamespace

from text2sql.config import (
    HAVING_COUNT_VALUES,
    HAVING_MIN_MAX_VALUES,
    HAVING_SUM_AVG_VALUES,
)
from text2sql.contracts_base import ValueDomain
from text2sql.contracts_core import QSimFilter, QSimHaving, QSimIntent
from text2sql.qsim_sample import (
    _compute_intent_variance,
    _extract_date_part,
    _format_date,
    _identify_range_pairs,
    _instantiate_intent,
    _is_integer_type,
    _parse_date,
    _sample_boolean,
    _sample_categorical,
    _sample_in_values,
    _sample_numeric,
    _sample_numeric_categorical,
    _sample_numeric_range,
    _sample_temporal,
    _sample_temporal_range,
    deterministic_having_value,
    instantiate_all,
    sample_coordinated_range,
    sample_value_from_domain,
)


class TestSampleValueFromDomain:
    """Tests for sample_value_from_domain."""

    def test_null_type_returns_none(self):
        """Null value type returns None."""
        domain = ValueDomain(values=["a", "b"], min_val=None, max_val=None, data_type="varchar")
        assert sample_value_from_domain(domain, "null") is None

    def test_is_null_op_returns_none(self):
        """IS NULL operator returns None regardless of value_type."""
        domain = ValueDomain(values=["a", "b"], min_val=None, max_val=None, data_type="varchar")
        assert sample_value_from_domain(domain, "categorical", op="is null") is None

    def test_is_not_null_op_returns_none(self):
        """IS NOT NULL operator returns None."""
        domain = ValueDomain(values=["a", "b"], min_val=None, max_val=None, data_type="varchar")
        assert sample_value_from_domain(domain, "categorical", op="is not null") is None

    def test_categorical_cycles(self):
        """Categorical sampling cycles through values by variant_idx."""
        domain = ValueDomain(values=["PG", "R", "G"], min_val=None, max_val=None, data_type="varchar")
        v0 = sample_value_from_domain(domain, "categorical", variant_idx=0)
        v1 = sample_value_from_domain(domain, "categorical", variant_idx=1)
        v3 = sample_value_from_domain(domain, "categorical", variant_idx=3)
        assert v0 == "PG"
        assert v1 == "R"
        assert v3 == v0

    def test_numeric_range(self):
        """Numeric sampling produces value within domain range."""
        domain = ValueDomain(values=[], min_val="10", max_val="100", data_type="integer")
        val = sample_value_from_domain(domain, "numeric", op="=", variant_idx=0)
        assert val is not None
        assert 10 <= int(val) <= 100

    def test_boolean_cycles(self):
        """Boolean sampling alternates true/false."""
        domain = ValueDomain(values=[], min_val=None, max_val=None, data_type="boolean")
        v0 = sample_value_from_domain(domain, "boolean", variant_idx=0)
        v1 = sample_value_from_domain(domain, "boolean", variant_idx=1)
        assert v0 in ("true", "false")
        assert v1 in ("true", "false")
        assert v0 != v1

    def test_in_operator_categorical(self):
        """IN operator returns comma-separated quoted values."""
        domain = ValueDomain(
            values=["a", "b", "c", "d", "e"],
            min_val=None,
            max_val=None,
            data_type="varchar",
        )
        val = sample_value_from_domain(domain, "categorical", op="in", variant_idx=0)
        assert val is not None
        assert "'" in val

    def test_temporal_returns_date(self):
        """Temporal sampling returns date string."""
        domain = ValueDomain(values=[], min_val="2020-01-01", max_val="2023-12-31", data_type="date")
        val = sample_value_from_domain(domain, "temporal", op="=", variant_idx=0)
        assert val is not None
        assert "-" in val

    def test_numeric_categorical_from_values(self):
        """Numeric categorical sampling picks from values list."""
        domain = ValueDomain(values=[1, 2, 3, 4, 5], min_val=None, max_val=None, data_type="integer")
        val = sample_value_from_domain(domain, "numeric_categorical", variant_idx=0)
        assert val is not None
        assert val in ("1", "2", "3", "4", "5")


class TestIdentifyRangePairs:
    """Tests for identify_range_pairs."""

    def test_paired_range(self):
        """Paired >= and <= on same column detected."""
        filters = [
            QSimFilter(column="orders.amount", op=">=", value_type="numeric"),
            QSimFilter(column="orders.amount", op="<=", value_type="numeric"),
        ]
        pairs = _identify_range_pairs(filters)
        assert "orders.amount" in pairs
        assert pairs["orders.amount"]["lower_idx"] == 0
        assert pairs["orders.amount"]["upper_idx"] == 1

    def test_no_pair(self):
        """Single-sided range is not a pair."""
        filters = [
            QSimFilter(column="orders.amount", op=">=", value_type="numeric"),
        ]
        pairs = _identify_range_pairs(filters)
        assert pairs == {}

    def test_expr_comparison_skipped(self):
        """Expr comparisons are skipped."""
        filters = [
            QSimFilter(
                column="orders.amount",
                op=">=",
                value_type="numeric",
                right_column="products.price",
            ),
        ]
        pairs = _identify_range_pairs(filters)
        assert pairs == {}

    def test_different_columns(self):
        """Different columns with matching ops don't pair."""
        filters = [
            QSimFilter(column="orders.amount", op=">=", value_type="numeric"),
            QSimFilter(column="orders.quantity", op="<=", value_type="numeric"),
        ]
        pairs = _identify_range_pairs(filters)
        assert pairs == {}

    def test_mixed_operators(self):
        """Mixed > and < on same column detected."""
        filters = [
            QSimFilter(column="rental.date", op=">", value_type="temporal"),
            QSimFilter(column="rental.date", op="<", value_type="temporal"),
        ]
        pairs = _identify_range_pairs(filters)
        assert "rental.date" in pairs


class TestSampleCoordinatedRange:
    """Tests for sample_coordinated_range."""

    def test_numeric_range(self):
        """Numeric range returns lower < upper."""
        domain = ValueDomain(values=[], min_val="0", max_val="100", data_type="integer")
        lower, upper = sample_coordinated_range(domain, "numeric", variant_idx=0)
        assert lower is not None
        assert upper is not None
        assert float(lower) < float(upper)

    def test_temporal_range(self):
        """Temporal range returns lower < upper date."""
        domain = ValueDomain(values=[], min_val="2020-01-01", max_val="2023-12-31", data_type="date")
        lower, upper = sample_coordinated_range(domain, "temporal", variant_idx=0)
        assert lower is not None
        assert upper is not None
        assert lower < upper

    def test_categorical_unsupported(self):
        """Categorical value type returns (None, None)."""
        domain = ValueDomain(values=["a", "b"], min_val=None, max_val=None, data_type="varchar")
        lower, upper = sample_coordinated_range(domain, "categorical", variant_idx=0)
        assert lower is None
        assert upper is None

    def test_variant_variation(self):
        """Different variant_idx yields different range values."""
        domain = ValueDomain(values=[], min_val="0", max_val="1000", data_type="numeric")
        r0 = sample_coordinated_range(domain, "numeric", variant_idx=0)
        r1 = sample_coordinated_range(domain, "numeric", variant_idx=1)
        assert r0 != r1


class TestDeterministicHavingValue:
    """Tests for deterministic_having_value."""

    def test_count_from_pool(self):
        """Count values come from HAVING_COUNT_VALUES pool."""
        val = deterministic_having_value("count", variant_idx=0)
        assert int(val) in HAVING_COUNT_VALUES

    def test_sum_from_pool(self):
        """Sum values come from HAVING_SUM_AVG_VALUES pool."""
        val = deterministic_having_value("sum", variant_idx=0)
        assert float(val) in HAVING_SUM_AVG_VALUES

    def test_avg_from_pool(self):
        """Avg values come from HAVING_SUM_AVG_VALUES pool."""
        val = deterministic_having_value("avg", variant_idx=0)
        assert float(val) in HAVING_SUM_AVG_VALUES

    def test_min_from_pool(self):
        """Min values come from HAVING_MIN_MAX_VALUES pool."""
        val = deterministic_having_value("min", variant_idx=0)
        assert float(val) in HAVING_MIN_MAX_VALUES

    def test_max_from_pool(self):
        """Max values come from HAVING_MIN_MAX_VALUES pool."""
        val = deterministic_having_value("max", variant_idx=0)
        assert float(val) in HAVING_MIN_MAX_VALUES

    def test_unknown_agg_fallback(self):
        """Unknown aggregation falls back to COUNT pool."""
        val = deterministic_having_value("median", variant_idx=0)
        assert int(val) in HAVING_COUNT_VALUES

    def test_deterministic(self):
        """Same inputs always produce same output."""
        v1 = deterministic_having_value("count", variant_idx=5, having_idx=2)
        v2 = deterministic_having_value("count", variant_idx=5, having_idx=2)
        assert v1 == v2

    def test_variant_varies(self):
        """Different variant_idx produces different values (for
        sufficient pool)."""
        vals = {deterministic_having_value("count", variant_idx=i) for i in range(10)}
        assert len(vals) > 1


class TestComputeIntentVariance:
    """Tests for compute_intent_variance."""

    def test_no_filters_no_having(self):
        """Intent with no filters and no having has zero variance."""
        intent = QSimIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=["orders.order_id"],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            question="",
            variant_idx=0,
        )
        score = _compute_intent_variance(intent, {})
        assert score == 0

    def test_filter_with_values(self):
        """Filter on column with values adds len(values) to variance."""
        intent = QSimIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=["orders.order_id"],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[QSimFilter(column="orders.status", op="=", value_type="categorical")],
            having_param=[],
            param_values={},
            question="",
            variant_idx=0,
        )
        domains = {
            "orders.status": ValueDomain(
                values=["pending", "shipped", "delivered"],
                min_val=None,
                max_val=None,
                data_type="varchar",
            )
        }
        score = _compute_intent_variance(intent, domains)
        assert score >= 3

    def test_having_adds_variance(self):
        """Having param adds variance score."""
        intent = QSimIntent(
            intent_id="test",
            tables=["orders"],
            grain="grouped",
            select_cols=["COUNT(orders.order_id)"],
            group_by_cols=["orders.status"],
            order_by_cols=[],
            filters_param=[QSimFilter(column="orders.status", op="=", value_type="categorical")],
            having_param=[QSimHaving(expression="COUNT(orders.order_id)", op=">", value_type="number")],
            param_values={},
            question="",
            variant_idx=0,
        )
        domains = {
            "orders.status": ValueDomain(values=["a", "b"], min_val=None, max_val=None, data_type="varchar"),
        }
        score_with_having = _compute_intent_variance(intent, domains)
        intent_no_having = QSimIntent(
            intent_id="test",
            tables=["orders"],
            grain="grouped",
            select_cols=["COUNT(orders.order_id)"],
            group_by_cols=["orders.status"],
            order_by_cols=[],
            filters_param=[QSimFilter(column="orders.status", op="=", value_type="categorical")],
            having_param=[],
            param_values={},
            question="",
            variant_idx=0,
        )
        score_no_having = _compute_intent_variance(intent_no_having, domains)
        assert score_with_having > score_no_having

    def test_expr_comparison_skipped(self):
        """Expr comparison filters do not contribute to variance."""
        intent = QSimIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=["orders.order_id"],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                QSimFilter(
                    column="orders.amount",
                    op=">",
                    value_type="numeric",
                    right_column="products.price",
                )
            ],
            having_param=[],
            param_values={},
            question="",
            variant_idx=0,
        )
        score = _compute_intent_variance(intent, {})
        assert score == 0


class TestIsIntegerType:
    """Tests for _is_integer_type helper."""

    def test_integer_types(self):
        """Standard integer type names recognised."""
        for dt in ("integer", "int", "bigint", "smallint", "tinyint", "long", "short"):
            assert _is_integer_type(dt) is True

    def test_mixed_case(self):
        """Case-insensitive matching."""
        assert _is_integer_type("INTEGER") is True
        assert _is_integer_type("BigInt") is True

    def test_non_integer_types(self):
        """Non-integer types rejected."""
        assert _is_integer_type("numeric") is False
        assert _is_integer_type("float") is False
        assert _is_integer_type("varchar") is False

    def test_interval_excluded(self):
        """Interval types not treated as integer despite containing
        'int'."""
        assert _is_integer_type("interval") is False

    def test_int_substring_included(self):
        """Type containing 'int' but not 'interval' is integer."""
        assert _is_integer_type("myinteger") is True

    def test_none_and_empty(self):
        """None and empty string return False."""
        assert _is_integer_type(None) is False
        assert _is_integer_type("") is False


class TestParseDate:
    """Tests for _parse_date helper."""

    def test_iso_format(self):
        """Standard YYYY-MM-DD parsed."""
        result = _parse_date("2024-01-15")
        assert result == datetime(2024, 1, 15)

    def test_datetime_with_time(self):
        """Datetime string with T separator truncated to date."""
        result = _parse_date("2024-06-01T14:30:00")
        assert result == datetime(2024, 6, 1)

    def test_datetime_with_space(self):
        """Datetime string with space separator truncated to date."""
        result = _parse_date("2024-06-01 14:30:00")
        assert result == datetime(2024, 6, 1)

    def test_slash_format(self):
        """Slash-separated date parsed."""
        result = _parse_date("2024/03/20")
        assert result == datetime(2024, 3, 20)

    def test_dd_mm_yyyy_format(self):
        """dd-mm-yyyy format parsed."""
        result = _parse_date("15-01-2024")
        assert result == datetime(2024, 1, 15)

    def test_dd_slash_mm_slash_yyyy_format(self):
        """dd/mm/yyyy format parsed."""
        result = _parse_date("15/01/2024")
        assert result == datetime(2024, 1, 15)

    def test_unparseable_returns_none(self):
        """Unrecognised format returns None."""
        assert _parse_date("not-a-date") is None


class TestFormatDate:
    """Tests for _format_date helper."""

    def test_basic_format(self):
        """Datetime formatted as YYYY-MM-DD."""
        assert _format_date(datetime(2024, 1, 15)) == "2024-01-15"

    def test_padding(self):
        """Single-digit months/days zero-padded."""
        assert _format_date(datetime(2024, 3, 5)) == "2024-03-05"


class TestExtractDatePart:
    """Tests for _extract_date_part helper."""

    def test_with_t_separator(self):
        """Date extracted before T."""
        assert _extract_date_part("2024-01-15T10:00:00") == "2024-01-15"

    def test_with_space_separator(self):
        """Date extracted before space."""
        assert _extract_date_part("2024-01-15 10:00:00") == "2024-01-15"

    def test_date_only(self):
        """Plain date returned unchanged."""
        assert _extract_date_part("2024-01-15") == "2024-01-15"


class TestSampleCategorical:
    """Tests for _sample_categorical helper."""

    def test_rotates_through_values(self):
        """Values list cycled by variant_idx."""
        domain = ValueDomain(values=["red", "green", "blue"])
        assert _sample_categorical(domain, 0) == "red"
        assert _sample_categorical(domain, 1) == "green"
        assert _sample_categorical(domain, 3) == "red"

    def test_min_max_fallback(self):
        """When no values, uses min/max range."""
        domain = ValueDomain(min_val="1", max_val="5")
        result = _sample_categorical(domain, 2)
        assert result == "3"

    def test_empty_returns_none(self):
        """No values and no range returns None."""
        domain = ValueDomain()
        assert _sample_categorical(domain, 0) is None


class TestSampleBoolean:
    """Tests for _sample_boolean helper."""

    def test_with_values(self):
        """Boolean values normalised and cycled."""
        domain = ValueDomain(values=[True, False])
        assert _sample_boolean(domain, 0) == "true"
        assert _sample_boolean(domain, 1) == "false"

    def test_default_without_values(self):
        """Defaults to ['true', 'false'] when no domain values."""
        domain = ValueDomain()
        assert _sample_boolean(domain, 0) == "true"
        assert _sample_boolean(domain, 1) == "false"


class TestSampleNumericCategorical:
    """Tests for _sample_numeric_categorical helper."""

    def test_with_values(self):
        """Discrete values cycled as integers."""
        domain = ValueDomain(values=[10, 20, 30])
        assert _sample_numeric_categorical(domain, 0) == "10"
        assert _sample_numeric_categorical(domain, 1) == "20"

    def test_min_max_fallback(self):
        """Range-based sampling when no values."""
        domain = ValueDomain(min_val="1", max_val="5")
        result = _sample_numeric_categorical(domain, 0)
        assert result == "1"

    def test_empty_returns_none(self):
        """No values and no range returns None."""
        domain = ValueDomain()
        assert _sample_numeric_categorical(domain, 0) is None


class TestSampleNumeric:
    """Tests for _sample_numeric helper."""

    def test_equals_integer(self):
        """Equal op on integer type produces integer string."""
        domain = ValueDomain(min_val="0", max_val="100", data_type="integer")
        result = _sample_numeric(domain, "=", 0)
        assert result == "0"

    def test_greater_than(self):
        """Greater-than op samples from lower portion."""
        domain = ValueDomain(min_val="0", max_val="100", data_type="integer")
        result = _sample_numeric(domain, ">", 0)
        assert result is not None
        assert int(result) >= 0

    def test_less_than(self):
        """Less-than op samples from upper portion."""
        domain = ValueDomain(min_val="0", max_val="100", data_type="integer")
        result = _sample_numeric(domain, "<", 0)
        assert result is not None
        assert int(result) <= 100

    def test_fallback_to_values(self):
        """Falls back to values list when no min/max."""
        domain = ValueDomain(values=["42", "99"])
        result = _sample_numeric(domain, "=", 0)
        assert result == "42"

    def test_no_domain_returns_none(self):
        """No values and no range returns None."""
        domain = ValueDomain()
        assert _sample_numeric(domain, "=", 0) is None


class TestSampleTemporal:
    """Tests for _sample_temporal helper."""

    def test_date_interpolation(self):
        """Samples date between min and max."""
        domain = ValueDomain(min_val="2020-01-01", max_val="2020-12-31")
        result = _sample_temporal(domain, "=", 0)
        assert result == "2020-01-01"

    def test_greater_than_segment(self):
        """Greater-than op uses lower segment range."""
        domain = ValueDomain(min_val="2020-01-01", max_val="2020-12-31")
        result = _sample_temporal(domain, ">=", 0)
        assert result is not None
        assert result >= "2020-01-01"

    def test_fallback_to_values(self):
        """Falls back to values list."""
        domain = ValueDomain(values=["2024-06-15T10:00:00"])
        result = _sample_temporal(domain, "=", 0)
        assert result == "2024-06-15"

    def test_unparseable_min(self):
        """Unparseable date falls back to extract_date_part."""
        domain = ValueDomain(min_val="not-a-date", max_val="also-bad")
        result = _sample_temporal(domain, "=", 0)
        assert result == "not-a-date"


class TestSampleInValues:
    """Tests for _sample_in_values helper."""

    def test_categorical_in(self):
        """Categorical IN produces quoted CSV."""
        domain = ValueDomain(values=["a", "b", "c", "d", "e"])
        result = _sample_in_values(domain, "categorical", 0)
        assert result.startswith("'")
        assert "," in result

    def test_numeric_categorical_in(self):
        """Numeric categorical IN produces comma-separated integers."""
        domain = ValueDomain(values=[1, 2, 3, 4, 5])
        result = _sample_in_values(domain, "numeric_categorical", 0)
        assert "," in result
        parts = result.split(",")
        for p in parts:
            int(p)

    def test_boolean_in(self):
        """Boolean IN returns 'true,false'."""
        domain = ValueDomain()
        result = _sample_in_values(domain, "boolean", 0)
        assert result == "true,false"

    def test_numeric_in_with_range(self):
        """Numeric IN with min/max range."""
        domain = ValueDomain(min_val="0", max_val="100", data_type="integer")
        result = _sample_in_values(domain, "numeric", 0)
        assert result is not None
        assert "," in result

    def test_unsupported_type_returns_none(self):
        """Unknown value_type returns None."""
        domain = ValueDomain()
        result = _sample_in_values(domain, "unknown_type", 0)
        assert result is None


class TestSampleNumericRange:
    """Tests for _sample_numeric_range helper."""

    def test_integer_range(self):
        """Integer range produces two ordered integer strings."""
        domain = ValueDomain(min_val="0", max_val="100", data_type="integer")
        lower, upper = _sample_numeric_range(domain, 0)
        assert lower is not None and upper is not None
        assert int(lower) < int(upper)

    def test_float_range(self):
        """Float range produces two ordered float strings."""
        domain = ValueDomain(min_val="0.0", max_val="100.0", data_type="numeric")
        lower, upper = _sample_numeric_range(domain, 0)
        assert lower is not None and upper is not None
        assert float(lower) < float(upper)

    def test_no_min_max_returns_nones(self):
        """Missing min/max returns (None, None)."""
        domain = ValueDomain()
        assert _sample_numeric_range(domain, 0) == (None, None)

    def test_zero_range_returns_nones(self):
        """Zero-width range returns (None, None)."""
        domain = ValueDomain(min_val="50", max_val="50", data_type="integer")
        assert _sample_numeric_range(domain, 0) == (None, None)


class TestSampleTemporalRange:
    """Tests for _sample_temporal_range helper."""

    def test_date_range(self):
        """Date range produces two ordered date strings."""
        domain = ValueDomain(min_val="2020-01-01", max_val="2020-12-31")
        lower, upper = _sample_temporal_range(domain, 0)
        assert lower is not None and upper is not None
        assert lower < upper

    def test_no_min_max_returns_nones(self):
        """Missing min/max returns (None, None)."""
        domain = ValueDomain()
        assert _sample_temporal_range(domain, 0) == (None, None)

    def test_unparseable_fallback(self):
        """Unparseable dates fall back to extract_date_part."""
        domain = ValueDomain(min_val="bad-date", max_val="also-bad")
        lower, upper = _sample_temporal_range(domain, 0)
        assert lower == "bad-date"
        assert upper == "also-bad"


class TestInstantiateIntent:
    """Tests for instantiate_intent."""

    def _make_intent(self, **overrides):
        defaults = dict(
            intent_id="test-1",
            tables=["orders"],
            grain="row_level",
            select_cols=["orders.order_id"],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            question="",
            variant_idx=0,
        )
        defaults.update(overrides)
        return QSimIntent(**defaults)

    def test_simple_filter_populated(self):
        """Single categorical filter gets value in param_values."""
        intent = self._make_intent(
            filters_param=[QSimFilter(column="orders.status", op="=", value_type="categorical")],
        )
        domains = {"orders.status": ValueDomain(values=["active", "closed"])}
        result = _instantiate_intent(intent, domains, 0)
        assert result is not None
        assert "f0" in result.param_values

    def test_null_filter_skipped(self):
        """IS NULL filter does not generate param value."""
        intent = self._make_intent(
            filters_param=[QSimFilter(column="orders.status", op="is null", value_type="null")],
        )
        result = _instantiate_intent(intent, {}, 0)
        assert result is not None
        assert len(result.param_values) == 0

    def test_expr_comparison_passthrough(self):
        """Expr comparison filters pass through without param value."""
        intent = self._make_intent(
            filters_param=[
                QSimFilter(
                    column="orders.amount",
                    op=">",
                    value_type="numeric",
                    right_column="orders.min_amount",
                ),
            ],
        )
        result = _instantiate_intent(intent, {}, 0)
        assert result is not None
        assert len(result.param_values) == 0

    def test_having_populated(self):
        """Having param gets deterministic value."""
        intent = self._make_intent(
            having_param=[QSimHaving(expression="COUNT(orders.order_id)", op=">", value_type="numeric")],
        )
        result = _instantiate_intent(intent, {}, 0)
        assert result is not None
        assert "h0" in result.param_values

    def test_variant_idx_propagated(self):
        """Variant index carried forward to result."""
        intent = self._make_intent()
        result = _instantiate_intent(intent, {}, 5)
        assert result is not None
        assert result.variant_idx == 5


class TestInstantiateAll:
    """Tests for instantiate_all."""

    def _make_col(self, **overrides):
        defaults = dict(
            data_type="varchar",
            top_k_values=["a", "b", "c"],
            min_val=None,
            max_val=None,
            distinct_count=3,
            role="dimension",
        )
        defaults.update(overrides)
        return SimpleNamespace(**defaults)

    def _make_schema(self):
        col = self._make_col()
        table = SimpleNamespace(columns={"status": col})
        return SimpleNamespace(tables={"orders": table})

    def test_produces_instances(self):
        """Generates at least one instantiated intent."""
        schema = self._make_schema()
        intent = QSimIntent(
            intent_id="i1",
            tables=["orders"],
            grain="row_level",
            select_cols=["orders.status"],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[QSimFilter(column="orders.status", op="=", value_type="categorical")],
            having_param=[],
            param_values={},
            question="",
            variant_idx=0,
        )
        results = instantiate_all([intent], schema, num_questions=3)
        assert len(results) >= 1
        assert all(isinstance(r, QSimIntent) for r in results)

    def test_empty_intents(self):
        """Empty intent list returns empty."""
        schema = self._make_schema()
        results = instantiate_all([], schema, num_questions=5)
        assert results == []

    def test_truncation_when_over_budget(self):
        """Output truncated to num_questions when allocation exceeds
        budget."""
        schema = self._make_schema()
        intents = []
        for i in range(20):
            intents.append(
                QSimIntent(
                    intent_id=f"i{i}",
                    tables=["orders"],
                    grain="row_level",
                    select_cols=["orders.status"],
                    group_by_cols=[],
                    order_by_cols=[],
                    filters_param=[QSimFilter(column="orders.status", op="=", value_type="categorical")],
                    having_param=[],
                    param_values={},
                    question="",
                    variant_idx=0,
                )
            )
        results = instantiate_all(intents, schema, num_questions=5)
        assert len(results) <= 5
