"""Unit tests for text2sql.simulator module."""

import os
import tempfile

import pytest

from text2sql.contracts_base import SchemaGraph
from text2sql.contracts_core import (
    FilterParam,
    NormalizedExpr,
    RuntimeIntent,
    SelectCol,
    SimulatorIntent,
    SimulatorResult,
)
from text2sql.simulator import (
    _abstract_values,
    _create_template_from_result,
    _decompose_between_filter_param,
    _identify_range_pairs,
    _load_seed_questions,
    get_next_simulator_version,
    instantiate_intent,
)


def _sim_intent(**overrides) -> SimulatorIntent:
    """Build a minimal SimulatorIntent with optional overrides."""
    defaults = dict(
        intent_id="sim_001",
        tables=["orders"],
        grain="row_level",
        select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
        group_by_cols=[],
        order_by_cols=[],
        filters_param=[],
        having_param=[],
        param_values={},
        expansion_metadata=None,
        limit=None,
    )
    defaults.update(overrides)
    return SimulatorIntent(**defaults)


class TestAbstractValues:
    """Tests for abstract_values."""

    def test_clears_param_values(self):
        """Abstracted intent has empty param_values."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            param_values={"p1": "shipped", "p2": "100"},
        )
        result = _abstract_values(intent)
        assert result.param_values == {}

    def test_preserves_tables(self):
        """Abstracted intent preserves tables."""
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            param_values={"p1": "val"},
        )
        result = _abstract_values(intent)
        assert result.tables == ["orders", "customers"]

    def test_preserves_grain(self):
        """Abstracted intent preserves grain."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="scalar",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            param_values={"p1": "x"},
        )
        result = _abstract_values(intent)
        assert result.grain == "scalar"

    def test_preserves_filters(self):
        """Abstracted intent preserves filter structure."""
        f = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=",
            value_type="string",
            param_key="p1",
            raw_value="shipped",
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[f],
            param_values={"p1": "shipped"},
        )
        result = _abstract_values(intent)
        assert len(result.filters_param) == 1
        assert result.param_values == {}

    def test_returns_new_object(self):
        """Abstracted intent is a different object."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            param_values={"p1": "val"},
        )
        result = _abstract_values(intent)
        assert result is not intent


class TestInstantiateIntent:
    """Tests for instantiate_intent."""

    def test_empty_filters_returns_intent(self):
        """Intent with no filters instantiates successfully."""
        from text2sql.contracts_base import ValueDomain
        intent = _sim_intent()
        result = instantiate_intent(intent, {})
        assert result is not None
        assert result.param_values == {}

    def test_populates_filter_value(self):
        """Filter value is sampled from domain."""
        from text2sql.contracts_base import ValueDomain
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="=", value_type="string", param_key="p1",
                )
            ],
        )
        domains = {
            "orders.status": ValueDomain(
                values=["shipped", "pending"],
                min_val=None, max_val=None,
            ),
        }
        result = instantiate_intent(intent, domains)
        assert result is not None


class TestGetNextSimulatorVersion:
    """Tests for get_next_simulator_version."""

    def test_empty_directory(self):
        """Returns 1 for empty directory."""
        with tempfile.TemporaryDirectory() as td:
            assert get_next_simulator_version(td) == 1

    def test_existing_versions(self):
        """Returns max + 1 for existing files."""
        with tempfile.TemporaryDirectory() as td:
            for v in [1, 2, 3]:
                open(os.path.join(td, f"gold_intents_v{v}.json"), "w").close()
            assert get_next_simulator_version(td) == 4

    def test_single_version(self):
        """Returns 2 when only v1 exists."""
        with tempfile.TemporaryDirectory() as td:
            open(os.path.join(td, "gold_intents_v1.json"), "w").close()
            assert get_next_simulator_version(td) == 2


class TestInstantiateIntentNullFilter:
    """Test null filter handling in instantiate_intent."""

    def test_null_filter_passes_through(self):
        """Null/is-null filters pass through without value sampling."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="is not null", value_type="null", param_key="p1",
                )
            ],
        )
        result = instantiate_intent(intent, {})
        assert result is not None
        assert len(result.filters_param) == 1
        assert result.filters_param[0].op == "is not null"


class TestLoadSeedQuestions:
    """Tests for load_seed_questions."""

    def test_file_not_found(self):
        """Raises FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            _load_seed_questions("/nonexistent/path.txt")

    def test_numbered_format(self):
        """Parses numbered lines."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write("1. What is the total revenue?\n")
            f.write("2. How many customers?\n")
            f.flush()
            path = f.name
        try:
            results = _load_seed_questions(path)
            assert len(results) == 2
            assert "revenue" in results[0]["question"].lower()
        finally:
            os.unlink(path)

    def test_phase_headers(self):
        """Parses phase headers."""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False, encoding="utf-8") as f:
            f.write("# Phase 1\n")
            f.write("What tables exist?\n")
            f.write("# Phase 2\n")
            f.write("Show revenue.\n")
            f.flush()
            path = f.name
        try:
            results = _load_seed_questions(path)
            assert len(results) >= 2
        finally:
            os.unlink(path)


class TestDecomposeBetweenFilterParam:
    """Tests for _decompose_between_filter_param."""

    def test_between_decomposed(self):
        """BETWEEN filter becomes >= and <= pair."""
        f = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.amount"),
            op="between",
            value_type="number",
            param_key="p1",
        )
        parts = _decompose_between_filter_param(f)
        assert len(parts) == 2
        ops = {p.op for p in parts}
        assert ">=" in ops
        assert "<=" in ops

    def test_non_between_passthrough(self):
        """Non-between filter passes through unchanged."""
        f = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=",
            value_type="string",
            param_key="p1",
        )
        parts = _decompose_between_filter_param(f)
        assert len(parts) == 1
        assert parts[0].op == "="


class TestIdentifyRangePairs:
    """Tests for _identify_range_pairs."""

    def test_identifies_range(self):
        """Detects paired >= / <= on the same column."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op=">=",
                value_type="number",
                param_key="p1",
            ),
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op="<=",
                value_type="number",
                param_key="p2",
            ),
        ]
        pairs = _identify_range_pairs(filters)
        assert "orders.amount" in pairs
        assert "lower_idx" in pairs["orders.amount"]
        assert "upper_idx" in pairs["orders.amount"]

    def test_no_range(self):
        """Single-sided filter produces no range pair."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op=">=",
                value_type="number",
                param_key="p1",
            ),
        ]
        pairs = _identify_range_pairs(filters)
        assert pairs == {}

    def test_expr_filters_excluded(self):
        """Filters with right_expr are excluded."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op=">=",
                value_type="number",
                param_key="p1",
                right_expr=NormalizedExpr.from_column("orders.order_id"),
            ),
        ]
        pairs = _identify_range_pairs(filters)
        assert pairs == {}


class TestInstantiateIntentDateWindow:
    """Test that date_window filters pass through without value sampling."""

    def test_date_window_passes_through(self):
        """date_window filter passes through without value sampling."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.order_date"),
                    op=">=", value_type="date_window", param_key="",
                    raw_value={"unit": "day", "offset": 30},
                )
            ],
        )
        result = instantiate_intent(intent, {})
        assert result is not None
        assert result.filters_param[0].value_type == "date_window"


class TestCreateTemplateFromResult:
    """Tests for create_template_from_result."""

    def test_unsuccessful_result_returns_none(self, schema_graph):
        """Unsuccessful result returns None."""
        result = SimulatorResult(
            intent=_sim_intent(),
            sql=None,
            success=False,
            question="q",
        )
        tmpl = _create_template_from_result(result, schema_graph, next_id=1)
        assert tmpl is None

    def test_successful_result_returns_template(self, schema_graph):
        """Successful result returns a Template."""
        intent = _sim_intent()
        intent.expected_rows = "many"
        intent.natural_language = "show orders"
        intent.chosen_join_candidate_id = ""
        intent.chosen_join_path_signature = []
        result = SimulatorResult(
            intent=intent,
            sql="SELECT order_id FROM orders",
            success=True,
            question="show orders",
        )
        tmpl = _create_template_from_result(result, schema_graph, next_id=42)
        assert tmpl is not None
        assert tmpl.id == "T0042"
        assert tmpl.source == "synthetic"
        assert tmpl.trust_level == 0

    def test_custom_source_and_trust(self, schema_graph):
        """Custom source and trust_level are respected."""
        intent = _sim_intent()
        intent.expected_rows = "many"
        intent.natural_language = "show orders"
        intent.chosen_join_candidate_id = ""
        intent.chosen_join_path_signature = []
        result = SimulatorResult(
            intent=intent,
            sql="SELECT order_id FROM orders",
            success=True,
            question="show orders",
        )
        tmpl = _create_template_from_result(result, schema_graph, next_id=1, source="gold", trust_level=2)
        assert tmpl.source == "gold"
        assert tmpl.trust_level == 2
