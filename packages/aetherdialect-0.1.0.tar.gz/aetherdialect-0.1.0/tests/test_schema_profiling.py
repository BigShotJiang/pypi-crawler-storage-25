"""Tests for schema_profiling module."""

import tempfile
from pathlib import Path

from text2sql.config import BOOLEAN_VALUE_PATTERNS, EngineConfig, PolicyConfig
from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import FilterParam, NormalizedExpr, RuntimeIntent
from text2sql.schema_profiling import (
    _build_column_profile_for_llm,
    _extract_column_block_from_create,
    _extract_fk_definition,
    _extract_pk_columns,
    _has_boolean_like_values,
    _infer_column_role,
    _parse_columns_and_constraints,
    _parse_partition_columns_from_create_stmt,
    _parse_sql_file_fallback,
    _parse_unity_catalog_constraints,
    _validate_column_classification,
    assign_column_ops,
    inject_partition_filters,
)


class TestBooleanValuePatterns:
    """Tests for _BOOLEAN_VALUE_PATTERNS constant."""

    def test_contains_zero_one(self):
        """Verify 0/1 pair is a boolean pattern."""
        assert frozenset(["0", "1"]) in BOOLEAN_VALUE_PATTERNS

    def test_contains_true_false(self):
        """Verify true/false pair is a boolean pattern."""
        assert frozenset(["true", "false"]) in BOOLEAN_VALUE_PATTERNS

    def test_contains_yes_no(self):
        """Verify yes/no pair is a boolean pattern."""
        assert frozenset(["yes", "no"]) in BOOLEAN_VALUE_PATTERNS

    def test_contains_active_inactive(self):
        """Verify active/inactive pair is a boolean pattern."""
        assert frozenset(["active", "inactive"]) in BOOLEAN_VALUE_PATTERNS

    def test_contains_enabled_disabled(self):
        """Verify enabled/disabled pair is a boolean pattern."""
        assert frozenset(["enabled", "disabled"]) in BOOLEAN_VALUE_PATTERNS

    def test_pattern_count(self):
        """Verify total number of boolean patterns."""
        assert len(BOOLEAN_VALUE_PATTERNS) == 8


class TestHasBooleanLikeValues:
    """Tests for _has_boolean_like_values."""

    def test_zero_one_integer(self):
        """Detect integer 0/1 as boolean-like."""
        col = ColumnMetadata(name="active", data_type="integer", distinct_count=2, top_k_values=[0, 1])
        assert _has_boolean_like_values(col) is True

    def test_true_false_strings(self):
        """Detect true/false strings as boolean-like."""
        col = ColumnMetadata(
            name="flag",
            data_type="varchar",
            distinct_count=2,
            top_k_values=["True", "False"],
        )
        assert _has_boolean_like_values(col) is True

    def test_yes_no_mixed_case(self):
        """Detect YES/NO as boolean-like regardless of case."""
        col = ColumnMetadata(
            name="approved",
            data_type="varchar",
            distinct_count=2,
            top_k_values=["YES", "NO"],
        )
        assert _has_boolean_like_values(col) is True

    def test_three_distinct_not_boolean(self):
        """Reject column with distinct_count != 2."""
        col = ColumnMetadata(
            name="status",
            data_type="varchar",
            distinct_count=3,
            top_k_values=["yes", "no", "maybe"],
        )
        assert _has_boolean_like_values(col) is False

    def test_none_top_k(self):
        """Reject column with no top_k_values."""
        col = ColumnMetadata(name="flag", data_type="integer", distinct_count=2, top_k_values=None)
        assert _has_boolean_like_values(col) is False

    def test_one_top_k_value(self):
        """Reject column with only one top_k value."""
        col = ColumnMetadata(name="flag", data_type="integer", distinct_count=2, top_k_values=["1"])
        assert _has_boolean_like_values(col) is False

    def test_non_pattern_pair(self):
        """Reject column with values not matching any known pattern."""
        col = ColumnMetadata(
            name="status",
            data_type="varchar",
            distinct_count=2,
            top_k_values=["pending", "done"],
        )
        assert _has_boolean_like_values(col) is False


class TestInferColumnRole:
    """Tests for infer_column_role."""

    def test_timestamp_column(self):
        """Infer TEMPORAL role for timestamp columns."""
        col = ColumnMetadata(name="created_at", data_type="timestamp", value_type="date")
        assert _infer_column_role(col) == ColumnRole.TEMPORAL

    def test_boolean_value_type(self):
        """Infer BOOLEAN role from value_type=boolean."""
        col = ColumnMetadata(name="is_active", data_type="boolean", value_type="boolean")
        assert _infer_column_role(col) == ColumnRole.BOOLEAN

    def test_primary_key(self):
        """Infer IDENTIFIER role for primary key columns."""
        col = ColumnMetadata(name="id", data_type="integer", value_type="integer", is_primary_key=True)
        assert _infer_column_role(col) == ColumnRole.IDENTIFIER

    def test_foreign_key(self):
        """Infer IDENTIFIER role for foreign key columns."""
        col = ColumnMetadata(
            name="customer_id",
            data_type="integer",
            value_type="integer",
            is_foreign_key=True,
        )
        assert _infer_column_role(col) == ColumnRole.IDENTIFIER

    def test_boolean_like_values(self):
        """Infer BOOLEAN role from boolean-like top_k_values."""
        col = ColumnMetadata(
            name="status",
            data_type="varchar",
            value_type="string",
            distinct_count=2,
            top_k_values=["0", "1"],
        )
        assert _infer_column_role(col) == ColumnRole.BOOLEAN

    def test_temporal(self):
        """Infer TEMPORAL role for date value_type."""
        col = ColumnMetadata(name="order_date", data_type="date", value_type="date")
        assert _infer_column_role(col) == ColumnRole.TEMPORAL

    def test_free_text_high_uniqueness(self):
        """Infer FREE_TEXT role for high distinct_ratio."""
        col = ColumnMetadata(
            name="description",
            data_type="varchar",
            value_type="string",
            distinct_ratio=PolicyConfig.IDENTIFIER_MIN_UNIQUENESS,
        )
        assert _infer_column_role(col) == ColumnRole.FREE_TEXT

    def test_categorical_string(self):
        """Infer CATEGORICAL role for low-cardinality string column."""
        col = ColumnMetadata(
            name="status",
            data_type="varchar",
            value_type="string",
            distinct_count=5,
            distinct_ratio=0.01,
        )
        assert _infer_column_role(col) == ColumnRole.CATEGORICAL

    def test_numeric_categorical(self):
        """Infer NUMERIC_CATEGORICAL role for low-cardinality integer
        column."""
        col = ColumnMetadata(
            name="rating",
            data_type="integer",
            value_type="integer",
            distinct_count=5,
            distinct_ratio=0.01,
        )
        assert _infer_column_role(col) == ColumnRole.NUMERIC_CATEGORICAL

    def test_numeric_measure(self):
        """Infer NUMERIC_MEASURE role for high-cardinality numeric
        column."""
        col = ColumnMetadata(
            name="amount",
            data_type="numeric",
            value_type="number",
            distinct_count=500,
            distinct_ratio=0.5,
        )
        assert _infer_column_role(col) == ColumnRole.NUMERIC_MEASURE


class TestParseColumnsAndConstraints:
    """Tests for _parse_columns_and_constraints."""

    def test_simple_columns(self):
        """Parse simple column definitions."""
        block = "id INTEGER PRIMARY KEY, name VARCHAR, age INTEGER"
        columns, types, pks, fks = _parse_columns_and_constraints(block)
        assert columns == ["id", "name", "age"]
        assert types == ["INTEGER", "VARCHAR", "INTEGER"]
        assert "id" in pks

    def test_separate_pk_constraint(self):
        """Parse PRIMARY KEY as separate constraint."""
        block = "id INTEGER, name VARCHAR, PRIMARY KEY (id)"
        columns, types, pks, fks = _parse_columns_and_constraints(block)
        assert columns == ["id", "name"]
        assert "id" in pks

    def test_foreign_key_constraint(self):
        """Parse FOREIGN KEY constraint."""
        block = "id INTEGER, customer_id INTEGER, FOREIGN KEY (customer_id) REFERENCES customers(id)"
        columns, types, pks, fks = _parse_columns_and_constraints(block)
        assert columns == ["id", "customer_id"]
        assert len(fks) == 1
        assert fks[0]["src_cols"] == ["customer_id"]
        assert fks[0]["dst_table"] == "customers"
        assert fks[0]["dst_cols"] == ["id"]

    def test_empty_block(self):
        """Parse empty column block."""
        columns, types, pks, fks = _parse_columns_and_constraints("")
        assert columns == []
        assert fks == []

    def test_quoted_column_names(self):
        """Parse quoted column names."""
        block = '"order_id" INTEGER PRIMARY KEY, "total" NUMERIC'
        columns, types, pks, fks = _parse_columns_and_constraints(block)
        assert "order_id" in columns
        assert "order_id" in pks


class TestExtractPkColumns:
    """Tests for _extract_pk_columns."""

    def test_single_pk(self):
        """Extract single primary key column."""
        result = _extract_pk_columns("PRIMARY KEY (id)")
        assert result == ["id"]

    def test_composite_pk(self):
        """Extract composite primary key columns."""
        result = _extract_pk_columns("PRIMARY KEY (order_id, product_id)")
        assert result == ["order_id", "product_id"]

    def test_no_match(self):
        """Return empty list for non-PK line."""
        result = _extract_pk_columns("id INTEGER NOT NULL")
        assert result == []


class TestExtractFkDefinition:
    """Tests for _extract_fk_definition."""

    def test_simple_fk(self):
        """Extract simple foreign key definition."""
        result = _extract_fk_definition("FOREIGN KEY (customer_id) REFERENCES customers(id)")
        assert result is not None
        assert result["src_cols"] == ["customer_id"]
        assert result["dst_table"] == "customers"
        assert result["dst_cols"] == ["id"]

    def test_no_match(self):
        """Return None for non-FK line."""
        result = _extract_fk_definition("id INTEGER PRIMARY KEY")
        assert result is None


class TestValidateColumnClassification:
    """Tests for _validate_column_classification."""

    def test_numeric_measure_on_string(self):
        """Hard error for NUMERIC_MEASURE on non-numeric column."""
        col = ColumnMetadata(name="name", data_type="varchar", value_type="string")
        hard, soft = _validate_column_classification(col, ColumnRole.NUMERIC_MEASURE.value)
        assert len(hard) > 0
        assert "NUMERIC_MEASURE" in hard[0]

    def test_temporal_on_integer(self):
        """Hard error for TEMPORAL on non-date column."""
        col = ColumnMetadata(name="count", data_type="integer", value_type="integer")
        hard, soft = _validate_column_classification(col, ColumnRole.TEMPORAL.value)
        assert len(hard) > 0

    def test_boolean_high_cardinality(self):
        """Hard error for BOOLEAN with distinct_count > 2."""
        col = ColumnMetadata(name="status", data_type="varchar", value_type="string", distinct_count=5)
        hard, soft = _validate_column_classification(col, ColumnRole.BOOLEAN.value)
        assert len(hard) > 0
        assert "distinct_count" in hard[0]

    def test_categorical_high_cardinality_warning(self):
        """Soft warning for CATEGORICAL with very high cardinality."""
        col = ColumnMetadata(name="code", data_type="varchar", value_type="string", distinct_count=2000)
        hard, soft = _validate_column_classification(col, ColumnRole.CATEGORICAL.value)
        assert len(soft) > 0
        assert "high cardinality" in soft[0]

    def test_identifier_non_pk_fk_warning(self):
        """Soft warning for IDENTIFIER on non-PK/FK column."""
        col = ColumnMetadata(
            name="code",
            data_type="varchar",
            value_type="string",
            is_primary_key=False,
            is_foreign_key=False,
        )
        hard, soft = _validate_column_classification(col, ColumnRole.IDENTIFIER.value)
        assert len(soft) > 0
        assert "non-PK/FK" in soft[0]

    def test_valid_classification_no_errors(self):
        """No errors for valid NUMERIC_MEASURE on numeric column."""
        col = ColumnMetadata(name="amount", data_type="numeric", value_type="number", distinct_count=100)
        hard, soft = _validate_column_classification(col, ColumnRole.NUMERIC_MEASURE.value)
        assert len(hard) == 0


class TestBuildColumnProfileForLlm:
    """Tests for _build_column_profile_for_llm."""

    def test_basic_fields(self):
        """Profile contains name, data_type, is_primary_key,
        is_foreign_key."""
        col = ColumnMetadata(name="id", data_type="integer", is_primary_key=True)
        result = _build_column_profile_for_llm(col)
        assert result["name"] == "id"
        assert result["data_type"] == "integer"
        assert result["is_primary_key"] is True
        assert result["is_foreign_key"] is False

    def test_hints_with_stats(self):
        """Profile includes profile_hints when stats present."""
        col = ColumnMetadata(
            name="x",
            data_type="int",
            distinct_count=10,
            distinct_ratio=0.5,
            null_ratio=0.1,
        )
        result = _build_column_profile_for_llm(col)
        assert "profile_hints" in result
        assert result["profile_hints"]["distinct_count"] == 10
        assert result["profile_hints"]["distinct_ratio"] == 0.5
        assert result["profile_hints"]["null_ratio"] == 0.1

    def test_default_stats_included(self):
        """Profile includes default stats in hints."""
        col = ColumnMetadata(name="x", data_type="int")
        result = _build_column_profile_for_llm(col)
        assert result["name"] == "x"
        assert result["data_type"] == "int"

    def test_hints_include_distinct_count(self):
        """Profile hints include distinct_count when set."""
        col = ColumnMetadata(name="x", data_type="int", distinct_count=5)
        result = _build_column_profile_for_llm(col)
        assert "profile_hints" in result
        assert result["profile_hints"]["distinct_count"] == 5

    def test_distinct_ratio_rounded(self):
        """Distinct ratio rounded to 3 decimal places."""
        col = ColumnMetadata(name="x", data_type="int", distinct_ratio=0.123456789)
        result = _build_column_profile_for_llm(col)
        assert result["profile_hints"]["distinct_ratio"] == 0.123

    def test_fk_target_in_profile(self):
        """Profile includes is_foreign_key and reflects fk_target."""
        col = ColumnMetadata(
            name="customer_id",
            data_type="integer",
            is_foreign_key=True,
            fk_target=("customers", "customer_id"),
        )
        result = _build_column_profile_for_llm(col)
        assert result["is_foreign_key"] is True
        assert result["is_primary_key"] is False


class TestAssignColumnOps:
    """Tests for assign_column_ops."""

    def test_audit_gets_empty_ops(self):
        """AUDIT columns get no filter ops or aggregations."""
        col = ColumnMetadata(
            name="created_at",
            data_type="timestamp",
            value_type="date",
            role=ColumnRole.AUDIT.value,
            distinct_count=10,
        )
        t = TableMetadata(name="t", columns={"created_at": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert col.valid_filter_ops == []
        assert col.valid_aggregations == []
        assert col.valid_having_ops == []

    def test_identifier_pk(self):
        """PK columns get identifier-level ops."""
        col = ColumnMetadata(
            name="id",
            data_type="integer",
            value_type="integer",
            is_primary_key=True,
            role=ColumnRole.IDENTIFIER.value,
            distinct_count=100,
        )
        t = TableMetadata(name="t", columns={"id": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "=" in col.valid_filter_ops
        assert "between" in col.valid_filter_ops
        assert "count" in col.valid_aggregations
        assert "sum" not in col.valid_aggregations

    def test_categorical_string(self):
        """CATEGORICAL string columns include LIKE operators."""
        col = ColumnMetadata(
            name="status",
            data_type="varchar",
            value_type="string",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=5,
        )
        t = TableMetadata(name="t", columns={"status": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "like" in col.valid_filter_ops
        assert "ilike" in col.valid_filter_ops

    def test_numeric_measure(self):
        """NUMERIC_MEASURE gets sum/avg aggregations."""
        col = ColumnMetadata(
            name="amount",
            data_type="numeric",
            value_type="number",
            role=ColumnRole.NUMERIC_MEASURE.value,
            distinct_count=100,
        )
        t = TableMetadata(name="t", columns={"amount": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "sum" in col.valid_aggregations
        assert "avg" in col.valid_aggregations
        assert "between" in col.valid_filter_ops

    def test_temporal(self):
        """TEMPORAL columns get date-appropriate ops."""
        col = ColumnMetadata(
            name="order_date",
            data_type="date",
            value_type="date",
            role=ColumnRole.TEMPORAL.value,
            distinct_count=100,
        )
        t = TableMetadata(name="t", columns={"order_date": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "between" in col.valid_filter_ops
        assert "min" in col.valid_aggregations
        assert "sum" not in col.valid_aggregations

    def test_boolean(self):
        """BOOLEAN columns get equality-only filter ops."""
        col = ColumnMetadata(
            name="is_active",
            data_type="boolean",
            value_type="boolean",
            role=ColumnRole.BOOLEAN.value,
            distinct_count=2,
        )
        t = TableMetadata(name="t", columns={"is_active": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "=" in col.valid_filter_ops
        assert "between" not in col.valid_filter_ops

    def test_free_text(self):
        """FREE_TEXT columns retain pattern ops despite is_filterable=False."""
        col = ColumnMetadata(
            name="description",
            data_type="text",
            value_type="string",
            role=ColumnRole.FREE_TEXT.value,
            distinct_count=1000,
        )
        t = TableMetadata(name="t", columns={"description": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "like" in col.valid_filter_ops
        assert "ilike" in col.valid_filter_ops
        assert "not like" in col.valid_filter_ops
        assert "not ilike" in col.valid_filter_ops
        assert "is null" in col.valid_filter_ops
        assert "is not null" in col.valid_filter_ops
        assert "=" not in col.valid_filter_ops
        assert col.valid_aggregations == ["count"]

    def test_numeric_categorical(self):
        """NUMERIC_CATEGORICAL gets appropriate ops."""
        col = ColumnMetadata(
            name="rating",
            data_type="integer",
            value_type="integer",
            role=ColumnRole.NUMERIC_CATEGORICAL.value,
            distinct_count=5,
        )
        t = TableMetadata(name="t", columns={"rating": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "between" in col.valid_filter_ops
        assert "like" not in col.valid_filter_ops

    def test_non_filterable_empty_ops(self):
        """Non-filterable columns get empty filter ops regardless of
        role."""
        col = ColumnMetadata(
            name="x",
            data_type="varchar",
            value_type="string",
            role=ColumnRole.AUDIT.value,
            distinct_count=100,
        )
        t = TableMetadata(name="t", columns={"x": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert col.valid_filter_ops == []

    def test_string_only_ops_removed_from_numeric(self):
        """String-only ops removed from non-string columns."""
        col = ColumnMetadata(
            name="amount",
            data_type="numeric",
            value_type="number",
            role=ColumnRole.NUMERIC_MEASURE.value,
            distinct_count=100,
        )
        t = TableMetadata(name="t", columns={"amount": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "like" not in col.valid_filter_ops
        assert "ilike" not in col.valid_filter_ops

    def test_numeric_aggs_removed_from_string(self):
        """Numeric-only aggregations removed from string columns."""
        col = ColumnMetadata(
            name="status",
            data_type="varchar",
            value_type="string",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=5,
        )
        t = TableMetadata(name="t", columns={"status": col}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})
        assign_column_ops(schema)
        assert "sum" not in col.valid_aggregations
        assert "avg" not in col.valid_aggregations


class TestParseUnityCatalogConstraints:
    """Tests for _parse_unity_catalog_constraints."""

    def test_pk_constraint(self):
        """Extract PK from CONSTRAINT clause."""
        stmt = "CREATE TABLE t (id INT, CONSTRAINT pk_t PRIMARY KEY (id))"
        pks, fks = _parse_unity_catalog_constraints(stmt)
        assert pks == ["id"]
        assert fks == []

    def test_fk_constraint(self):
        """Extract FK from CONSTRAINT clause."""
        stmt = "CREATE TABLE t (id INT, user_id INT, CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id))"
        pks, fks = _parse_unity_catalog_constraints(stmt)
        assert len(fks) == 1
        assert fks[0]["src_cols"] == ["user_id"]
        assert fks[0]["dst_table"] == "users"
        assert fks[0]["dst_cols"] == ["id"]

    def test_composite_pk(self):
        """Extract composite PK columns."""
        stmt = "CONSTRAINT pk_t PRIMARY KEY (a, b)"
        pks, fks = _parse_unity_catalog_constraints(stmt)
        assert pks == ["a", "b"]

    def test_no_constraints(self):
        """Return empty lists when no constraints present."""
        stmt = "CREATE TABLE t (id INT, name VARCHAR)"
        pks, fks = _parse_unity_catalog_constraints(stmt)
        assert pks == []
        assert fks == []

    def test_multiple_fks(self):
        """Extract multiple FK constraints."""
        stmt = """
        CONSTRAINT fk1 FOREIGN KEY (a_id) REFERENCES a(id),
        CONSTRAINT fk2 FOREIGN KEY (b_id) REFERENCES b(id)
        """
        pks, fks = _parse_unity_catalog_constraints(stmt)
        assert len(fks) == 2


class TestParseSqlFileFallback:
    """Tests for _parse_sql_file_fallback."""

    def test_simple_create_table(self):
        """Parse simple CREATE TABLE statement."""
        sql = "CREATE TABLE users (id INTEGER PRIMARY KEY, name VARCHAR);"
        result = _parse_sql_file_fallback(sql)
        assert "users" in result
        assert "id" in result["users"]["column_names_original"]
        assert "name" in result["users"]["column_names_original"]
        assert "id" in result["users"]["primary_keys"]

    def test_multiple_tables(self):
        """Parse multiple CREATE TABLE statements."""
        sql = """
        CREATE TABLE users (id INTEGER PRIMARY KEY, name VARCHAR);
        CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER);
        """
        result = _parse_sql_file_fallback(sql)
        assert len(result) == 2
        assert "users" in result
        assert "orders" in result

    def test_empty_sql(self):
        """Empty SQL returns empty dict."""
        result = _parse_sql_file_fallback("")
        assert result == {}

    def test_non_create_statements(self):
        """Non-CREATE statements ignored."""
        sql = "SELECT 1; INSERT INTO t VALUES (1); DROP TABLE t;"
        result = _parse_sql_file_fallback(sql)
        assert result == {}

    def test_columns_preserved(self):
        """Parsed columns preserved in result."""
        sql = "CREATE TABLE orders (id INTEGER PRIMARY KEY, user_id INTEGER);"
        result = _parse_sql_file_fallback(sql)
        assert "orders" in result
        assert "id" in result["orders"]["column_names_original"]
        assert "user_id" in result["orders"]["column_names_original"]

    def test_numeric_with_comma_in_type(self):
        """NUMERIC(4,2) and NUMERIC(5,2) parsed without splitting on internal comma."""
        sql = """
        CREATE TABLE film (
            film_id INTEGER PRIMARY KEY,
            rental_rate NUMERIC(4,2) DEFAULT 4.99 NOT NULL,
            replacement_cost NUMERIC(5,2) DEFAULT 19.99 NOT NULL
        );
        """
        result = _parse_sql_file_fallback(sql)
        assert "film" in result
        cols = result["film"]["column_names_original"]
        types = result["film"]["column_types"]
        assert "rental_rate" in cols
        assert "replacement_cost" in cols
        assert "2)" not in cols
        assert cols.count("rental_rate") == 1
        assert cols.count("replacement_cost") == 1
        assert "NUMERIC(4,2)" in types or "NUMERIC(5,2)" in types

    def test_partitioned_by_single_column(self):
        """Parse PARTITIONED BY with single column."""
        sql = "CREATE TABLE events (id BIGINT, dt DATE) PARTITIONED BY (dt)"
        result = _parse_sql_file_fallback(sql)
        table_key = next((k for k in result if result[k].get("partition_columns") == ["dt"]), None)
        assert table_key is not None
        assert result[table_key]["partition_columns"] == ["dt"]

    def test_partitioned_by_multiple_columns(self):
        """Parse PARTITIONED BY with multiple columns."""
        sql = "CREATE TABLE logs (id BIGINT, region STRING, dt DATE) PARTITIONED BY (region, dt)"
        result = _parse_sql_file_fallback(sql)
        assert "logs" in result
        assert result["logs"].get("partition_columns") == ["region", "dt"]

    def test_parses_language_table_reserved_keyword(self):
        """Parse CREATE TABLE language when language is a reserved keyword."""
        sql = """
        CREATE TABLE language (
            language_id INTEGER NOT NULL PRIMARY KEY,
            name CHAR(20) NOT NULL
        );
        """
        result = _parse_sql_file_fallback(sql)
        assert "language" in result
        assert "language_id" in result["language"]["column_names_original"]
        assert "name" in result["language"]["column_names_original"]


class TestParsePartitionColumnsFromCreateStmt:
    """Tests for _parse_partition_columns_from_create_stmt."""

    def test_single_partition_column(self):
        """Extract single partition column."""
        stmt = "CREATE TABLE t (id INT, dt DATE) PARTITIONED BY (dt)"
        assert _parse_partition_columns_from_create_stmt(stmt) == ["dt"]

    def test_multiple_partition_columns(self):
        """Extract multiple partition columns."""
        stmt = "CREATE TABLE t (id INT, r STRING, dt DATE) PARTITIONED BY (r, dt)"
        assert _parse_partition_columns_from_create_stmt(stmt) == ["r", "dt"]

    def test_backtick_quoted_columns(self):
        """Strip backticks from partition column names."""
        stmt = "CREATE TABLE t (id INT) PARTITIONED BY (`dt`)"
        assert _parse_partition_columns_from_create_stmt(stmt) == ["dt"]

    def test_case_insensitive(self):
        """PARTITIONED BY matches case-insensitively."""
        stmt = "CREATE TABLE t (id INT) partitioned by (dt)"
        assert _parse_partition_columns_from_create_stmt(stmt) == ["dt"]

    def test_no_partitioned_by(self):
        """Return empty list when no PARTITIONED BY."""
        stmt = "CREATE TABLE t (id INT, name VARCHAR)"
        assert _parse_partition_columns_from_create_stmt(stmt) == []

    def test_empty_statement(self):
        """Return empty list for empty string."""
        assert _parse_partition_columns_from_create_stmt("") == []


class TestParseSqlFileFallback:
    """Tests for _parse_sql_file_fallback with sqlglot."""

    def test_parses_create_table_spark(self):
        """Parse CREATE TABLE with Spark dialect."""
        orig = EngineConfig.TYPE
        try:
            EngineConfig.TYPE = "databricks"
            result = _parse_sql_file_fallback("CREATE TABLE users (id INT, name STRING);")
            assert "users" in result
            assert result["users"]["column_names_original"] == ["id", "name"]
        finally:
            EngineConfig.TYPE = orig

    def test_parses_reserved_keyword_table(self):
        """Parse CREATE TABLE when table name is reserved keyword."""
        orig = EngineConfig.TYPE
        try:
            EngineConfig.TYPE = "databricks"
            result = _parse_sql_file_fallback(
                "CREATE TABLE language (language_id INT PRIMARY KEY);"
            )
            assert "language" in result
        finally:
            EngineConfig.TYPE = orig

    def test_returns_empty_for_select(self):
        """Return empty dict for SELECT statement."""
        orig = EngineConfig.TYPE
        try:
            EngineConfig.TYPE = "databricks"
            result = _parse_sql_file_fallback("SELECT 1;")
            assert result == {}
        finally:
            EngineConfig.TYPE = orig


class TestExtractColumnBlockFromCreate:
    """Tests for _extract_column_block_from_create."""

    def test_extracts_block(self):
        """Extract column definition block from sqlglot Create."""
        import sqlglot
        from sqlglot import exp

        parsed = sqlglot.parse_one("CREATE TABLE t (id INT, name VARCHAR);", dialect="spark")
        assert isinstance(parsed, exp.Create)
        block = _extract_column_block_from_create(parsed)
        assert "id" in block
        assert "name" in block

    def test_handles_simple_schema(self):
        """Extract block from CREATE TABLE with single column."""
        import sqlglot
        from sqlglot import exp

        parsed = sqlglot.parse_one("CREATE TABLE t (id INT PRIMARY KEY);", dialect="spark")
        assert isinstance(parsed, exp.Create)
        block = _extract_column_block_from_create(parsed)
        assert "id" in block


class TestHasBooleanLikeValuesEdgeCases:
    """Edge case tests for _has_boolean_like_values."""

    def test_empty_top_k(self):
        """Empty top_k_values list returns False."""
        col = ColumnMetadata(name="flag", data_type="integer", distinct_count=2, top_k_values=[])
        assert _has_boolean_like_values(col) is False

    def test_on_off_values(self):
        """Detect on/off as boolean-like."""
        col = ColumnMetadata(
            name="switch",
            data_type="varchar",
            distinct_count=2,
            top_k_values=["on", "off"],
        )
        assert _has_boolean_like_values(col) is True

    def test_y_n_values(self):
        """Detect y/n as boolean-like."""
        col = ColumnMetadata(name="active", data_type="char", distinct_count=2, top_k_values=["Y", "N"])
        assert _has_boolean_like_values(col) is True


class TestInferColumnRoleEdgeCases:
    """Edge case tests for infer_column_role."""

    def test_identifier_high_uniqueness_numeric(self):
        """High uniqueness numeric column with _id suffix gets
        IDENTIFIER."""
        col = ColumnMetadata(
            name="record_id",
            data_type="integer",
            value_type="integer",
            distinct_ratio=0.99,
        )
        result = _infer_column_role(col)
        assert result in (
            ColumnRole.IDENTIFIER,
            ColumnRole.FREE_TEXT,
            ColumnRole.NUMERIC_MEASURE,
        )

    def test_no_stats_string(self):
        """String column without stats defaults to CATEGORICAL."""
        col = ColumnMetadata(name="label", data_type="varchar", value_type="string")
        result = _infer_column_role(col)
        assert result == ColumnRole.CATEGORICAL


class TestValidateColumnClassificationEdgeCases:
    """Edge case tests for _validate_column_classification."""

    def test_numeric_measure_low_cardinality_warning(self):
        """Soft warning for NUMERIC_MEASURE with distinct_count <= 5."""
        col = ColumnMetadata(name="score", data_type="integer", value_type="integer", distinct_count=3)
        hard, soft = _validate_column_classification(col, ColumnRole.NUMERIC_MEASURE.value)
        assert len(soft) > 0

    def test_temporal_on_year_column(self):
        """TEMPORAL on year column gives soft warning not hard error."""
        col = ColumnMetadata(name="birth_year", data_type="integer", value_type="integer")
        hard, soft = _validate_column_classification(col, ColumnRole.TEMPORAL.value)
        assert len(hard) > 0 or len(soft) > 0

    def test_boolean_distinct_none(self):
        """BOOLEAN with no distinct_count passes validation."""
        col = ColumnMetadata(name="flag", data_type="boolean", value_type="boolean")
        hard, soft = _validate_column_classification(col, ColumnRole.BOOLEAN.value)
        assert len(hard) == 0

    def test_categorical_low_cardinality(self):
        """CATEGORICAL with low cardinality produces no warnings."""
        col = ColumnMetadata(name="status", data_type="varchar", value_type="string", distinct_count=3)
        hard, soft = _validate_column_classification(col, ColumnRole.CATEGORICAL.value)
        assert len(hard) == 0
        assert len(soft) == 0


class TestExtractPkColumnsEdgeCases:
    """Edge case tests for _extract_pk_columns."""

    def test_quoted_columns(self):
        """Extract PK columns with quotes."""
        result = _extract_pk_columns('PRIMARY KEY ("id", "code")')
        assert "id" in result
        assert "code" in result

    def test_extra_whitespace(self):
        """Handle extra whitespace in PK definition."""
        result = _extract_pk_columns("PRIMARY  KEY  ( id ,  name )")
        assert "id" in result
        assert "name" in result


class TestExtractFkDefinitionEdgeCases:
    """Edge case tests for _extract_fk_definition."""

    def test_composite_fk(self):
        """Extract composite foreign key."""
        result = _extract_fk_definition("FOREIGN KEY (a, b) REFERENCES t2(x, y)")
        assert result is not None
        assert result["src_cols"] == ["a", "b"]
        assert result["dst_cols"] == ["x", "y"]

    def test_case_insensitive(self):
        """Handle lowercase foreign key keywords."""
        result = _extract_fk_definition("foreign key (col) references other(id)")
        assert result is not None
        assert result["dst_table"] == "other"


def _schema_with_partition(table: str, partition_cols: list[str]) -> SchemaGraph:
    """Build a SchemaGraph with a single table having the given partition columns."""
    cols = {"id": ColumnMetadata(name="id", data_type="integer")}
    for c in partition_cols:
        cols[c] = ColumnMetadata(name=c, data_type="string" if c != "dt" else "date")
    meta = TableMetadata(
        name=table,
        columns=cols,
        foreign_keys=[],
        primary_key="id",
        partition_columns=partition_cols,
    )
    return SchemaGraph(join_paths_multi={}, schema_hash="", tables={table: meta})


def _filter_param(col: str, op: str, param_key: str | None = None, raw_value=None) -> FilterParam:
    """Build a FilterParam for partition injection tests."""
    expr = NormalizedExpr.from_column(col)
    return FilterParam(left_expr=expr, op=op, param_key=param_key or "", raw_value=raw_value)


class TestInjectPartitionFilters:
    """Tests for inject_partition_filters."""

    def test_inject_equality_partition_predicate(self):
        """Inject single equality partition predicate into WHERE."""
        schema = _schema_with_partition("events", ["dt"])
        intent = RuntimeIntent(
            tables=["events"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[_filter_param("events.dt", "=", "p1", None)],
            param_values={"p1": "2024-01-15"},
        )
        sql = "SELECT * FROM events"
        result = inject_partition_filters(sql, schema, intent)
        assert "`events`.`dt` = '2024-01-15'" in result
        assert "WHERE" in result

    def test_inject_in_partition_predicate(self):
        """Inject IN partition predicate from multiple equality filters."""
        schema = _schema_with_partition("logs", ["region"])
        intent = RuntimeIntent(
            tables=["logs"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                _filter_param("logs.region", "=", "p1", None),
                _filter_param("logs.region", "=", "p2", None),
            ],
            param_values={"p1": "us", "p2": "eu"},
        )
        sql = "SELECT * FROM logs"
        result = inject_partition_filters(sql, schema, intent)
        assert "`logs`.`region` IN ('us', 'eu')" in result

    def test_inject_between_partition_predicate(self):
        """Inject BETWEEN as >= and <= partition predicates."""
        schema = _schema_with_partition("sales", ["dt"])
        intent = RuntimeIntent(
            tables=["sales"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                _filter_param("sales.dt", ">=", "p1", None),
                _filter_param("sales.dt", "<=", "p2", None),
            ],
            param_values={"p1": "2024-01-01", "p2": "2024-01-31"},
        )
        sql = "SELECT * FROM sales"
        result = inject_partition_filters(sql, schema, intent)
        assert ">=" in result
        assert "<=" in result
        assert "2024-01-01" in result
        assert "2024-01-31" in result

    def test_no_partition_columns_unchanged(self):
        """SQL unchanged when table has no partition columns."""
        meta = TableMetadata(
            name="plain",
            columns={"id": ColumnMetadata(name="id", data_type="integer")},
            foreign_keys=[],
            primary_key="id",
            partition_columns=[],
        )
        schema = SchemaGraph(join_paths_multi={}, schema_hash="", tables={"plain": meta})
        intent = RuntimeIntent(
            tables=["plain"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[_filter_param("plain.id", "=", "p1", None)],
            param_values={"p1": 1},
        )
        sql = "SELECT * FROM plain WHERE id = 1"
        result = inject_partition_filters(sql, schema, intent)
        assert result == sql

    def test_predicate_already_present_unchanged(self):
        """SQL unchanged when partition predicate already present."""
        schema = _schema_with_partition("events", ["dt"])
        intent = RuntimeIntent(
            tables=["events"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[_filter_param("events.dt", "=", "p1", None)],
            param_values={"p1": "2024-01-15"},
        )
        sql = "SELECT * FROM events WHERE `events`.`dt` = '2024-01-15'"
        result = inject_partition_filters(sql, schema, intent)
        assert result == sql

    def test_append_to_existing_where(self):
        """Append partition predicate to existing WHERE clause."""
        schema = _schema_with_partition("events", ["dt"])
        intent = RuntimeIntent(
            tables=["events"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[_filter_param("events.dt", "=", "p1", None)],
            param_values={"p1": "2024-01-15"},
        )
        sql = "SELECT * FROM events WHERE status = 'active'"
        result = inject_partition_filters(sql, schema, intent)
        assert "status = 'active'" in result
        assert "`events`.`dt` = '2024-01-15'" in result
        assert " AND " in result

