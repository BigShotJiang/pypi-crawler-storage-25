"""Tests for intent_repair module."""

import pytest

from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    FKEdge,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import (
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    OrderByCol,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
)
from text2sql.intent_repair import (
    _collect_referenced_tables,
    _extract_question_casing,
    _find_fk_column_for_pk,
    _infer_cte_output_columns,
    _is_impossible_having,
    _is_null_value,
    _is_pk_column,
    _match_enum_value,
    _resolve_filter_list_cascade,
    _rewrite_redundant_pk_aggregations,
    _strip_distinct_prefix,
    _tables_from_columns,
    best_descriptive_column,
    normalize_boolean_filter_values,
    normalize_in_filter_types,
    normalize_pk_distinct,
    prune_unreferenced_tables,
    qualify_cte_output_columns,
    repair_fk_filter_type_mismatch,
    repair_null_equality_filters,
    resolve_filter_value_case,
    sanitize_table_names,
    strip_impossible_having,
    strip_join_conditions,
    strip_spurious_group_by,
)


class TestStripDistinctPrefix:
    """Tests for _strip_distinct_prefix."""

    def test_strips_distinct(self):
        """_strip_distinct_prefix removes DISTINCT prefix."""
        assert _strip_distinct_prefix("DISTINCT t.id") == "t.id"

    def test_leaves_non_distinct(self):
        """_strip_distinct_prefix leaves non-DISTINCT unchanged."""
        assert _strip_distinct_prefix("t.id") == "t.id"

    def test_case_insensitive(self):
        """_strip_distinct_prefix is case-insensitive."""
        assert _strip_distinct_prefix("distinct t.id") == "t.id"


class TestNormalizePkDistinct:
    """Tests for normalize_pk_distinct."""

    @pytest.fixture
    def pk_schema(self):
        """Schema with a PK column for DISTINCT tests."""
        customers = TableMetadata(
            name="customers",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(join_paths_multi={}, schema_hash="", tables={"customers": customers})

    def test_strips_distinct_from_count_pk(self, pk_schema):
        """normalize_pk_distinct strips DISTINCT from COUNT on PK."""
        sc = SelectCol(
            expr=NormalizedExpr(
                add_groups=[
                    MulGroup(
                        coefficient=1.0,
                        multiply=["DISTINCT customers.id"],
                        agg_func="count",
                    )
                ],
            ),
        )
        intent = RuntimeIntent(
            tables=["customers"],
            grain="scalar",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_pk_distinct(intent, pk_schema)
        assert "DISTINCT" not in result.select_cols[0].expr.add_groups[0].multiply[0]

    def test_no_strip_non_pk(self, pk_schema):
        """normalize_pk_distinct does not strip DISTINCT for non-PK."""
        non_pk_schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "customers": TableMetadata(
                    name="customers",
                    columns={
                        "name": ColumnMetadata(
                            name="name",
                            data_type="varchar",
                            value_type="string",
                            role=ColumnRole.CATEGORICAL.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )
        sc = SelectCol(
            expr=NormalizedExpr(
                add_groups=[
                    MulGroup(
                        coefficient=1.0,
                        multiply=["DISTINCT customers.name"],
                        agg_func="count",
                    )
                ],
            ),
        )
        intent = RuntimeIntent(
            tables=["customers"],
            grain="scalar",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_pk_distinct(intent, non_pk_schema)
        assert "DISTINCT" in result.select_cols[0].expr.add_groups[0].multiply[0]


class TestPruneUnreferencedTables:
    """Tests for prune_unreferenced_tables."""

    def test_adds_missing_referenced_table(self):
        """prune_unreferenced_tables adds table referenced in
        columns."""
        intent = RuntimeIntent(
            tables=[],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(intent)
        assert "orders" in result.tables

    def test_removes_unreferenced_table(self):
        """prune_unreferenced_tables removes table not used in
        expressions."""
        intent = RuntimeIntent(
            tables=["customers", "orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("customers.name"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(intent)
        assert "customers" in result.tables
        assert "orders" not in result.tables


class TestStripJoinConditionsFromIntent:
    """Tests for strip_join_conditions."""

    @pytest.fixture
    def fk_schema(self):
        """Schema with FK relationship for join condition tests."""
        orders = TableMetadata(
            name="orders",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
            },
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["customer_id"],
                    dst_table="customers",
                    dst_cols=["id"],
                )
            ],
            primary_key="",
        )
        customers = TableMetadata(
            name="customers",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"orders": orders, "customers": customers},
        )

    def test_strips_fk_join_filter(self, fk_schema):
        """strip_join_conditions removes FK equi-join filter."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.customer_id"),
            op="=",
            right_expr=NormalizedExpr.from_column("customers.id"),
            value_type="integer",
        )
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = strip_join_conditions(intent, fk_schema)
        assert len(result.filters_param) == 0

    def test_keeps_non_fk_filter(self, fk_schema):
        """strip_join_conditions keeps non-FK filter."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.id"),
            op=">",
            value_type="number",
            param_key="p1",
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = strip_join_conditions(intent, fk_schema)
        assert len(result.filters_param) == 1


class TestBestDescriptiveColumn:
    """Tests for best_descriptive_column."""

    @pytest.fixture
    def desc_schema(self):
        """Schema with PK, FK, and descriptive columns."""
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "customers": TableMetadata(
                    name="customers",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                        "email": ColumnMetadata(
                            name="email",
                            data_type="varchar",
                            value_type="string",
                            role=ColumnRole.IDENTIFIER.value,
                            distinct_count=100,
                            distinct_ratio=0.99,
                        ),
                        "name": ColumnMetadata(
                            name="name",
                            data_type="varchar",
                            value_type="string",
                            role=ColumnRole.CATEGORICAL.value,
                            distinct_count=50,
                            distinct_ratio=0.5,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )

    def test_returns_best_non_pk_column(self, desc_schema):
        """best_descriptive_column returns column with highest
        distinct_count meeting threshold."""
        result = best_descriptive_column("customers", desc_schema, set())
        assert result == "email"

    def test_excludes_specified_columns(self, desc_schema):
        """best_descriptive_column skips columns in exclude set."""
        result = best_descriptive_column("customers", desc_schema, {"customers.email"})
        assert result is None

    def test_unknown_table_returns_none(self, desc_schema):
        """best_descriptive_column returns None for unknown table."""
        result = best_descriptive_column("nonexistent", desc_schema, set())
        assert result is None

    def test_all_pk_returns_none(self):
        """best_descriptive_column returns None when only PK columns
        exist."""
        schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )
        assert best_descriptive_column("t", schema, set()) is None


class TestIsPkColumn:
    """Tests for _is_pk_column."""

    @pytest.fixture
    def pk_schema(self):
        """Schema with a PK column."""
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )

    def test_pk_column_returns_true(self, pk_schema):
        """_is_pk_column returns True for PK column."""
        assert _is_pk_column("t.id", pk_schema) is True

    def test_non_pk_returns_false(self):
        """_is_pk_column returns False for non-PK column."""
        schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={
                        "name": ColumnMetadata(
                            name="name",
                            data_type="varchar",
                            value_type="string",
                            role=ColumnRole.CATEGORICAL.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )
        assert _is_pk_column("t.name", schema) is False

    def test_bare_column_returns_false(self, pk_schema):
        """_is_pk_column returns False for unqualified column."""
        assert _is_pk_column("id", pk_schema) is False

    def test_unknown_table_returns_false(self, pk_schema):
        """_is_pk_column returns False for unknown table."""
        assert _is_pk_column("x.id", pk_schema) is False


class TestTablesFromColumns:
    """Tests for _tables_from_columns."""

    def test_extracts_table_names(self):
        """_tables_from_columns extracts unique table names."""
        result = _tables_from_columns(["orders.id", "customers.name", "orders.amount"])
        assert result == {"orders", "customers"}

    def test_skips_bare_columns(self):
        """_tables_from_columns skips bare column names."""
        result = _tables_from_columns(["id", "name"])
        assert result == set()

    def test_empty_input(self):
        """_tables_from_columns returns empty set for empty input."""
        assert _tables_from_columns([]) == set()

    def test_single_qualified_column(self):
        """_tables_from_columns with one table.col returns one table."""
        assert _tables_from_columns(["orders.amount"]) == {"orders"}

    def test_deduplicates_same_table(self):
        """_tables_from_columns deduplicates table names."""
        result = _tables_from_columns(["t.a", "t.b", "t.c"])
        assert result == {"t"}


class TestCollectReferencedTables:
    """Tests for _collect_referenced_tables."""

    def test_collects_from_all_clauses(self):
        """_collect_referenced_tables gathers tables from all clause
        types."""
        sc = [SelectCol(expr=NormalizedExpr.from_column("orders.id"))]
        obc = [OrderByCol(expr=NormalizedExpr.from_column("customers.name"))]
        gb = [NormalizedExpr.from_column("products.category")]
        fp = [FilterParam(left_expr=NormalizedExpr.from_column("inventory.qty"), op=">")]
        hp = [HavingParam(left_expr=NormalizedExpr.from_agg("sum", "sales.amount"), op=">")]
        result = _collect_referenced_tables(sc, obc, gb, fp, hp)
        assert "orders" in result
        assert "customers" in result
        assert "products" in result
        assert "inventory" in result
        assert "sales" in result

    def test_empty_clauses(self):
        """_collect_referenced_tables returns empty for empty
        clauses."""
        result = _collect_referenced_tables([], [], [], [], [])
        assert result == set()


class TestStripJoinConditionsEdgeCases:
    """Edge-case tests for strip_join_conditions."""

    def test_strips_from_cte_steps(self):
        """strip_join_conditions also strips from CTE steps."""
        orders = TableMetadata(
            name="orders",
            columns={
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                )
            },
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["customer_id"],
                    dst_table="customers",
                    dst_cols=["id"],
                )
            ],
            primary_key="",
        )
        customers = TableMetadata(
            name="customers",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"orders": orders, "customers": customers},
        )
        fk_filter = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.customer_id"),
            op="=",
            right_expr=NormalizedExpr.from_column("customers.id"),
            value_type="integer",
        )
        cte = RuntimeCteStep(cte_name="cte1", filters_param=[fk_filter])
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = strip_join_conditions(intent, schema)
        assert len(result.cte_steps[0].filters_param) == 0

    def test_keeps_non_equality_join(self):
        """strip_join_conditions keeps non-equality operator."""
        orders = TableMetadata(
            name="orders",
            columns={
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                )
            },
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["customer_id"],
                    dst_table="customers",
                    dst_cols=["id"],
                )
            ],
            primary_key="",
        )
        customers = TableMetadata(
            name="customers",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"orders": orders, "customers": customers},
        )
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.customer_id"),
            op=">",
            right_expr=NormalizedExpr.from_column("customers.id"),
            value_type="integer",
        )
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = strip_join_conditions(intent, schema)
        assert len(result.filters_param) == 1


class TestPruneUnreferencedTablesEdgeCases:
    """Edge-case tests for prune_unreferenced_tables."""

    def test_preserves_cte_names_in_tables(self):
        """prune_unreferenced_tables keeps CTE names in tables list."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.x"))],
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.val"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = prune_unreferenced_tables(intent)
        assert "cte1" in result.tables

    def test_empty_intent(self):
        """prune_unreferenced_tables handles intent with no columns or
        tables."""
        intent = RuntimeIntent(
            tables=[],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(intent)
        assert result.tables == []


class TestNormalizePkDistinctEdgeCases:
    """Edge-case tests for normalize_pk_distinct."""

    def test_no_strip_non_count_agg(self):
        """normalize_pk_distinct does not strip DISTINCT for non-count
        aggregation."""
        schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )
        sc = SelectCol(
            expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["DISTINCT t.id"], agg_func="sum")])
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_pk_distinct(intent, schema)
        assert "DISTINCT" in result.select_cols[0].expr.add_groups[0].multiply[0]

    def test_strips_in_cte_steps(self):
        """normalize_pk_distinct strips DISTINCT from CTE step select
        cols."""
        schema = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )
        sc = SelectCol(
            expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["DISTINCT t.id"], agg_func="count")])
        )
        cte = RuntimeCteStep(cte_name="cte1", select_cols=[sc])
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_pk_distinct(intent, schema)
        assert "DISTINCT" not in result.cte_steps[0].select_cols[0].expr.add_groups[0].multiply[0]


class TestRepairFkFilterTypeMismatch:
    @pytest.fixture
    def fk_schema(self):
        orders = TableMetadata(
            name="orders",
            columns={
                "order_id": ColumnMetadata(
                    name="order_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=500,
                ),
                "category_id": ColumnMetadata(
                    name="category_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    fk_target=("categories", "category_id"),
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=10,
                ),
                "amount": ColumnMetadata(
                    name="amount",
                    data_type="numeric",
                    value_type="number",
                    role=ColumnRole.NUMERIC_MEASURE.value,
                    distinct_count=200,
                ),
            },
            primary_key=["order_id"],
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["category_id"],
                    dst_table="categories",
                    dst_cols=["category_id"],
                ),
            ],
        )
        categories = TableMetadata(
            name="categories",
            columns={
                "category_id": ColumnMetadata(
                    name="category_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=10,
                    distinct_ratio=1.0,
                ),
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    distinct_count=10,
                    distinct_ratio=1.0,
                ),
            },
            primary_key=["category_id"],
            foreign_keys=[],
        )
        return SchemaGraph(
            tables={"orders": orders, "categories": categories},
            join_paths_multi={},
            schema_hash="h",
        )

    def test_rewires_string_filter_on_fk_int(self, fk_schema):
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="string",
                    raw_value="Action",
                ),
            ],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.filters_param[0].left_expr.primary_column == "orders.category_id"
        assert result.tables == intent.tables

    def test_no_change_when_value_type_integer(self, fk_schema):
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="integer",
                    raw_value=5,
                ),
            ],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.filters_param[0].left_expr.primary_column == "orders.category_id"

    def test_no_change_when_column_not_fk(self, fk_schema):
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.amount"),
                    op=">",
                    value_type="string",
                    raw_value="high",
                ),
            ],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.filters_param[0].left_expr.primary_column == "orders.amount"

    def test_no_change_when_no_descriptive_column(self):
        orders = TableMetadata(
            name="orders",
            columns={
                "order_id": ColumnMetadata(
                    name="order_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=500,
                ),
                "tag_id": ColumnMetadata(
                    name="tag_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    fk_target=("tags", "tag_id"),
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=5,
                ),
            },
            primary_key=["order_id"],
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["tag_id"],
                    dst_table="tags",
                    dst_cols=["tag_id"],
                )
            ],
        )
        tags = TableMetadata(
            name="tags",
            columns={
                "tag_id": ColumnMetadata(
                    name="tag_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=5,
                    distinct_ratio=1.0,
                ),
            },
            primary_key=["tag_id"],
            foreign_keys=[],
        )
        sg = SchemaGraph(
            tables={"orders": orders, "tags": tags},
            join_paths_multi={},
            schema_hash="h",
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.tag_id"),
                    op="=",
                    value_type="string",
                    raw_value="important",
                ),
            ],
        )
        result = repair_fk_filter_type_mismatch(intent, sg)
        assert result.filters_param[0].left_expr.primary_column == "orders.tag_id"

    def test_target_table_not_duplicated(self, fk_schema):
        intent = RuntimeIntent(
            tables=["categories", "orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="string",
                    raw_value="Action",
                ),
            ],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.tables.count("categories") == 1

    def test_mixed_filters_only_bad_repaired(self, fk_schema):
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="=",
                    value_type="string",
                    raw_value="shipped",
                ),
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="string",
                    raw_value="Action",
                ),
            ],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.filters_param[0].left_expr.primary_column == "orders.status"
        assert result.filters_param[1].left_expr.primary_column == "orders.category_id"
        assert result.tables == intent.tables


class TestStripSpuriousGroupBy:
    """Tests for strip_spurious_group_by."""

    def test_no_group_by_unchanged(self):
        """Intent without group_by_cols is returned unchanged."""
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = strip_spurious_group_by(intent)
        assert result.group_by_cols == []
        assert result.grain == "row_level"

    def test_strips_when_no_agg(self):
        """GROUP BY is stripped when no select column is aggregated."""
        intent = RuntimeIntent(
            tables=["film"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[NormalizedExpr.from_column("film.title")],
            order_by_cols=[],
            filters_param=[],
        )
        result = strip_spurious_group_by(intent)
        assert result.group_by_cols == []
        assert result.grain == "row_level"

    def test_keeps_when_agg_present(self):
        """GROUP BY is kept when an aggregated select column exists."""
        intent = RuntimeIntent(
            tables=["film"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("film.rating")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "film.film_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("film.rating")],
            order_by_cols=[],
            filters_param=[],
        )
        result = strip_spurious_group_by(intent)
        assert len(result.group_by_cols) == 1
        assert result.grain == "grouped"

    def test_preserves_non_grouped_grain(self):
        """When stripping, grain that isn't 'grouped' stays
        unchanged."""
        intent = RuntimeIntent(
            tables=["film"],
            grain="scalar",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[NormalizedExpr.from_column("film.title")],
            order_by_cols=[],
            filters_param=[],
        )
        result = strip_spurious_group_by(intent)
        assert result.group_by_cols == []
        assert result.grain == "scalar"


class TestStripSpuriousGroupByCte:
    """CTE parity tests for strip_spurious_group_by."""

    def test_cte_spurious_group_by_stripped(self):
        """CTE step with group_by but no aggregation has group_by
        stripped."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["film"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[NormalizedExpr.from_column("film.title")],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = strip_spurious_group_by(intent)
        assert result.cte_steps[0].group_by_cols == []
        assert result.cte_steps[0].grain == "row_level"

    def test_cte_group_by_kept_with_agg(self):
        """CTE step with aggregation keeps group_by."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["film"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("film.rating")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "film.film_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("film.rating")],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = strip_spurious_group_by(intent)
        assert len(result.cte_steps[0].group_by_cols) == 1
        assert result.cte_steps[0].grain == "grouped"

    def test_main_and_cte_both_stripped(self):
        """Both main and CTE have spurious GROUP BY stripped."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["film"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[NormalizedExpr.from_column("film.title")],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["film"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.rating"))],
            group_by_cols=[NormalizedExpr.from_column("film.rating")],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = strip_spurious_group_by(intent)
        assert result.group_by_cols == []
        assert result.grain == "row_level"
        assert result.cte_steps[0].group_by_cols == []
        assert result.cte_steps[0].grain == "row_level"

    def test_no_cte_steps_unchanged(self):
        """Intent without CTE steps processes main only and returns
        unchanged if fine."""
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = strip_spurious_group_by(intent)
        assert result is intent


class TestRepairFkFilterTypeMismatchCte:
    """CTE parity tests for repair_fk_filter_type_mismatch."""

    @pytest.fixture
    def fk_schema(self):
        orders = TableMetadata(
            name="orders",
            columns={
                "order_id": ColumnMetadata(
                    name="order_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=500,
                ),
                "category_id": ColumnMetadata(
                    name="category_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    fk_target=("categories", "category_id"),
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=10,
                ),
            },
            primary_key=["order_id"],
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["category_id"],
                    dst_table="categories",
                    dst_cols=["category_id"],
                ),
            ],
        )
        categories = TableMetadata(
            name="categories",
            columns={
                "category_id": ColumnMetadata(
                    name="category_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=10,
                    distinct_ratio=1.0,
                ),
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    distinct_count=10,
                    distinct_ratio=1.0,
                ),
            },
            primary_key=["category_id"],
            foreign_keys=[],
        )
        return SchemaGraph(
            tables={"orders": orders, "categories": categories},
            join_paths_multi={},
            schema_hash="h",
        )

    def test_cte_fk_filter_rewired(self, fk_schema):
        """CTE step filter on FK integer column with string value is
        rewired."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="string",
                    raw_value="Action",
                ),
            ],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.cte_steps[0].filters_param[0].left_expr.primary_column == "orders.category_id"
        assert result.cte_steps[0].tables == cte.tables

    def test_cte_non_fk_filter_unchanged(self, fk_schema):
        """CTE step filter on non-FK column is not rewired."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.order_id"),
                    op="=",
                    value_type="integer",
                    raw_value=5,
                ),
            ],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.cte_steps[0].filters_param[0].left_expr.primary_column == "orders.order_id"

    def test_main_and_cte_both_rewired(self, fk_schema):
        """Both main and CTE FK filters are rewired."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="string",
                    raw_value="Drama",
                ),
            ],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.category_id"),
                    op="=",
                    value_type="string",
                    raw_value="Action",
                ),
            ],
            cte_steps=[cte],
        )
        result = repair_fk_filter_type_mismatch(intent, fk_schema)
        assert result.filters_param[0].left_expr.primary_column == "orders.category_id"
        assert result.cte_steps[0].filters_param[0].left_expr.primary_column == "orders.category_id"
        assert result.tables == intent.tables
        assert result.cte_steps[0].tables == cte.tables


class TestMatchEnumValue:
    """Tests for _match_enum_value."""

    def test_exact_match(self):
        """Exact casing returns the enum member unchanged."""
        col_meta = ColumnMetadata(
            name="rating",
            data_type="mpaa_rating",
            value_type="string",
            role=ColumnRole.CATEGORICAL.value,
        )
        sg = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={},
            enum_values={"mpaa_rating": ["G", "PG", "PG-13", "R", "NC-17"]},
        )
        assert _match_enum_value("PG-13", col_meta, sg) == "PG-13"

    def test_case_insensitive_match(self):
        """Lower-case input matches the correctly-cased enum member."""
        col_meta = ColumnMetadata(
            name="rating",
            data_type="mpaa_rating",
            value_type="string",
            role=ColumnRole.CATEGORICAL.value,
        )
        sg = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={},
            enum_values={"mpaa_rating": ["G", "PG", "PG-13", "R", "NC-17"]},
        )
        assert _match_enum_value("pg-13", col_meta, sg) == "PG-13"

    def test_no_enum_values_returns_none(self):
        """Returns None when schema has no enum_values."""
        col_meta = ColumnMetadata(
            name="rating",
            data_type="mpaa_rating",
            value_type="string",
            role=ColumnRole.CATEGORICAL.value,
        )
        sg = SchemaGraph(join_paths_multi={}, schema_hash="", tables={})
        assert _match_enum_value("PG", col_meta, sg) is None

    def test_no_match_returns_none(self):
        """Returns None when value does not match any enum member."""
        col_meta = ColumnMetadata(
            name="rating",
            data_type="mpaa_rating",
            value_type="string",
            role=ColumnRole.CATEGORICAL.value,
        )
        sg = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={},
            enum_values={"mpaa_rating": ["G", "PG", "R"]},
        )
        assert _match_enum_value("NC-17", col_meta, sg) is None


class TestExtractQuestionCasing:
    """Tests for _extract_question_casing."""

    def test_extracts_mixed_case(self):
        """Returns the mixed-case substring from the question."""
        assert _extract_question_casing("alice", "Show me Alice orders") == "Alice"

    def test_returns_none_when_all_lower(self):
        """Returns None when the matched substring is all lower-case."""
        assert _extract_question_casing("alice", "show me alice orders") is None

    def test_returns_none_when_not_found(self):
        """Returns None when the value does not appear in the
        question."""
        assert _extract_question_casing("bob", "show me alice") is None

    def test_returns_none_when_same_casing(self):
        """Returns None when the matched casing already matches
        raw_value."""
        assert _extract_question_casing("Alice", "Show me Alice orders") is None

    def test_empty_inputs(self):
        """Returns None for empty raw_value or question."""
        assert _extract_question_casing("", "some question") is None
        assert _extract_question_casing("val", "") is None


class TestResolveFilterListCascade:
    """Tests for _resolve_filter_list_cascade."""

    @pytest.fixture
    def rating_schema(self):
        """Schema with film.rating enum column."""
        film = TableMetadata(
            name="film",
            columns={
                "rating": ColumnMetadata(
                    name="rating",
                    data_type="mpaa_rating",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    top_k_values=["G", "PG", "PG-13", "R", "NC-17"],
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"film": film},
            enum_values={"mpaa_rating": ["G", "PG", "PG-13", "R", "NC-17"]},
        )

    def test_corrects_scalar_value(self, rating_schema):
        """Scalar string filter gets corrected via enum match."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="string",
            raw_value="pg",
        )
        result, changed = _resolve_filter_list_cascade([fp], rating_schema, "")
        assert changed
        assert result[0].raw_value == "PG"

    def test_corrects_list_values(self, rating_schema):
        """List filter values get corrected per element."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="in",
            value_type="string",
            raw_value=["pg", "r"],
        )
        result, changed = _resolve_filter_list_cascade([fp], rating_schema, "")
        assert changed
        assert result[0].raw_value == ["PG", "R"]

    def test_no_change_for_correct_casing(self, rating_schema):
        """Already correct casing returns unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="string",
            raw_value="PG",
        )
        result, changed = _resolve_filter_list_cascade([fp], rating_schema, "")
        assert not changed
        assert result[0].raw_value == "PG"

    def test_non_string_value_type_unchanged(self, rating_schema):
        """Non-string value_type filters are not touched."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="integer",
            raw_value=5,
        )
        result, changed = _resolve_filter_list_cascade([fp], rating_schema, "")
        assert not changed
        assert result[0].raw_value == 5


class TestResolveFilterValueCase:
    """Tests for resolve_filter_value_case."""

    @pytest.fixture
    def rating_schema(self):
        """Schema with film.rating enum column."""
        film = TableMetadata(
            name="film",
            columns={
                "rating": ColumnMetadata(
                    name="rating",
                    data_type="mpaa_rating",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    top_k_values=["G", "PG", "PG-13", "R", "NC-17"],
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"film": film},
            enum_values={"mpaa_rating": ["G", "PG", "PG-13", "R", "NC-17"]},
        )

    def test_main_query_corrected(self, rating_schema):
        """Main query filter value gets corrected."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="string",
            raw_value="pg-13",
        )
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            natural_language="Show PG-13 films",
        )
        result = resolve_filter_value_case(intent, rating_schema, "Show PG-13 films")
        assert result.filters_param[0].raw_value == "PG-13"

    def test_cte_step_corrected(self, rating_schema):
        """CTE step filter value gets corrected."""
        cte_fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="string",
            raw_value="r",
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["film"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[cte_fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        result = resolve_filter_value_case(intent, rating_schema, "test")
        assert result.cte_steps[0].filters_param[0].raw_value == "R"

    def test_no_change_returns_same_intent(self, rating_schema):
        """When no corrections needed the original intent is
        returned."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="string",
            raw_value="PG",
        )
        intent = RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            natural_language="test",
        )
        result = resolve_filter_value_case(intent, rating_schema, "test")
        assert result is intent


class TestNormalizeInFilterTypes:
    """Tests for normalize_in_filter_types."""

    @pytest.fixture
    def int_col_schema(self):
        """Schema with an integer column."""
        t = TableMetadata(
            name="t",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(join_paths_multi={}, schema_hash="", tables={"t": t})

    def test_coerces_string_elements_to_int(self, int_col_schema):
        """String elements on an integer column are coerced to ints."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.id"),
            op="in",
            value_type="integer",
            raw_value=["1", "2", "3"],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            natural_language="test",
        )
        result = normalize_in_filter_types(intent, int_col_schema)
        assert result.filters_param[0].raw_value == "1, 2, 3"

    def test_consolidates_string_list(self, int_col_schema):
        """String list on a string column is consolidated with
        quotes."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.name"),
            op="in",
            value_type="string",
            raw_value=["Alice", "Bob"],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            natural_language="test",
        )
        result = normalize_in_filter_types(intent, int_col_schema)
        assert result.filters_param[0].raw_value == "'Alice', 'Bob'"

    def test_non_in_op_unchanged(self, int_col_schema):
        """Filters with non-IN ops are not touched."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.id"),
            op="=",
            value_type="integer",
            raw_value=5,
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            natural_language="test",
        )
        result = normalize_in_filter_types(intent, int_col_schema)
        assert result.filters_param == intent.filters_param

    def test_cte_step_coerced(self, int_col_schema):
        """CTE step IN filters are also coerced."""
        cte_fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.id"),
            op="in",
            value_type="integer",
            raw_value=["10", "20"],
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[cte_fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        result = normalize_in_filter_types(intent, int_col_schema)
        assert result.cte_steps[0].filters_param[0].raw_value == "10, 20"


class TestNormalizeBooleanFilterValues:
    """Tests for normalize_boolean_filter_values (main + CTE)."""

    @pytest.fixture
    def bool_schema(self):
        """Schema with a boolean column."""
        t = TableMetadata(
            name="customer",
            columns={
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
                "activebool": ColumnMetadata(
                    name="activebool",
                    data_type="boolean",
                    value_type="boolean",
                    role=ColumnRole.CATEGORICAL.value,
                ),
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(join_paths_multi={}, schema_hash="", tables={"customer": t})

    def test_int_1_normalised_to_true(self, bool_schema):
        """Integer 1 on boolean column becomes True."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.activebool"),
            op="=",
            value_type="integer",
            raw_value=1,
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result.filters_param[0].raw_value is True
        assert result.filters_param[0].value_type == "boolean"

    def test_string_false_normalised(self, bool_schema):
        """String 'false' on boolean column becomes False."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.activebool"),
            op="=",
            value_type="string",
            raw_value="false",
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result.filters_param[0].raw_value is False
        assert result.filters_param[0].value_type == "boolean"

    def test_already_bool_unchanged(self, bool_schema):
        """Python bool on boolean column is kept unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.activebool"),
            op="=",
            value_type="boolean",
            raw_value=True,
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result.filters_param[0].raw_value is True
        assert result.filters_param[0].value_type == "boolean"

    def test_non_boolean_column_unchanged(self, bool_schema):
        """Non-boolean column filter is not touched."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.name"),
            op="=",
            value_type="string",
            raw_value="Alice",
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result.filters_param[0].raw_value == "Alice"

    def test_no_change_returns_same_intent(self, bool_schema):
        """When nothing changes the original intent is returned."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.name"),
            op="=",
            value_type="string",
            raw_value="Bob",
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result is intent

    def test_cte_boolean_normalised(self, bool_schema):
        """CTE step boolean filter is normalised."""
        cte_fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.activebool"),
            op="=",
            value_type="string",
            raw_value="yes",
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["customer"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[cte_fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result.cte_steps[0].filters_param[0].raw_value is True
        assert result.cte_steps[0].filters_param[0].value_type == "boolean"

    def test_main_and_cte_both_normalised(self, bool_schema):
        """Both main and CTE boolean filters are normalised."""
        main_fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.activebool"),
            op="=",
            value_type="integer",
            raw_value=0,
        )
        cte_fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.activebool"),
            op="=",
            value_type="string",
            raw_value="true",
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["customer"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[cte_fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[main_fp],
            cte_steps=[cte],
        )
        result = normalize_boolean_filter_values(intent, bool_schema)
        assert result.filters_param[0].raw_value is False
        assert result.cte_steps[0].filters_param[0].raw_value is True


class TestStripSpuriousGroupByHavingParam:
    """Tests for strip_spurious_group_by when having_param has aggregation."""

    def test_keeps_group_by_when_having_is_aggregated(self):
        """GROUP BY is preserved when having_param contains an aggregated
        expression even though no select column is aggregated."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.order_id"),
            op=">",
            value_type="number",
            raw_value=5,
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.status"))],
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
        )
        result = strip_spurious_group_by(intent)
        assert len(result.group_by_cols) == 1
        assert result.grain == "grouped"

    def test_strips_when_having_not_aggregated(self):
        """GROUP BY is stripped when having_param exists but is not
        aggregated and no select col is aggregated either."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=",
            value_type="string",
            raw_value="active",
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.status"))],
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
        )
        result = strip_spurious_group_by(intent)
        assert result.group_by_cols == []
        assert result.grain == "row_level"

    def test_cte_keeps_group_by_when_cte_having_is_aggregated(self):
        """CTE GROUP BY is preserved when CTE having_param has aggregated
        expression."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "items.amount"),
            op=">=",
            value_type="number",
            raw_value=100,
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["items"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("items.category"))],
            group_by_cols=[NormalizedExpr.from_column("items.category")],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["items"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = strip_spurious_group_by(intent)
        assert len(result.cte_steps[0].group_by_cols) == 1
        assert result.cte_steps[0].grain == "grouped"


class TestIsImpossibleHaving:
    """Tests for _is_impossible_having helper."""

    def test_count_less_than_zero(self):
        """COUNT(...) < 0 is impossible."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="<",
            raw_value=0,
        )
        assert _is_impossible_having(hp) is True

    def test_count_less_equal_zero(self):
        """COUNT(...) <= 0 is impossible."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="<=",
            raw_value=0,
        )
        assert _is_impossible_having(hp) is True

    def test_count_equal_negative(self):
        """COUNT(...) = -1 is impossible."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="=",
            raw_value=-1,
        )
        assert _is_impossible_having(hp) is True

    def test_count_greater_than_zero_possible(self):
        """COUNT(...) > 0 is possible and should not be flagged."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op=">",
            raw_value=0,
        )
        assert _is_impossible_having(hp) is False

    def test_count_equal_positive_possible(self):
        """COUNT(...) = 5 is possible and should not be flagged."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="=",
            raw_value=5,
        )
        assert _is_impossible_having(hp) is False

    def test_sum_less_than_negative_possible(self):
        """SUM(...) < -10 is possible for SUM."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "orders.amount"),
            op="<",
            raw_value=-10,
        )
        assert _is_impossible_having(hp) is False

    def test_non_agg_expr_not_flagged(self):
        """Plain column expression is never flagged as impossible."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="<",
            raw_value=0,
        )
        assert _is_impossible_having(hp) is False

    def test_none_raw_value_not_flagged(self):
        """None raw_value is not flagged."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="<",
            raw_value=None,
        )
        assert _is_impossible_having(hp) is False

    def test_string_raw_value_zero(self):
        """String '0' is converted and detected as impossible for COUNT < '0'."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="<",
            raw_value="0",
        )
        assert _is_impossible_having(hp) is True


class TestStripImpossibleHaving:
    """Tests for strip_impossible_having."""

    def test_removes_count_less_than_zero(self):
        """Impossible HAVING COUNT < 0 is removed from intent."""
        hp_bad = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op="<",
            raw_value=0,
        )
        hp_good = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op=">",
            raw_value=5,
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.status")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp_bad, hp_good],
        )
        result = strip_impossible_having(intent)
        assert len(result.having_param) == 1
        assert result.having_param[0].op == ">"

    def test_no_change_when_all_possible(self):
        """Intent returned unchanged when all HAVING conditions are
        possible."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.id"),
            op=">",
            raw_value=5,
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
        )
        result = strip_impossible_having(intent)
        assert result is intent

    def test_empty_having_unchanged(self):
        """Intent with empty having_param is returned unchanged."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        result = strip_impossible_having(intent)
        assert result is intent

    def test_cte_impossible_having_removed(self):
        """Impossible HAVING in CTE is removed independently."""
        hp_bad = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "items.id"),
            op="<=",
            raw_value=0,
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["items"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("items.category")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "items.id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("items.category")],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp_bad],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["items"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = strip_impossible_having(intent)
        assert result.cte_steps[0].having_param == []


class TestSanitizeTableNames:
    """Tests for sanitize_table_names."""

    @pytest.fixture
    def basic_schema(self):
        """Schema with two simple tables."""
        return SchemaGraph(
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_strips_distinct_prefix(self, basic_schema):
        """'DISTINCT customer' becomes 'customer'."""
        intent = RuntimeIntent(
            tables=["DISTINCT customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = sanitize_table_names(intent, basic_schema)
        assert result.tables == ["customer"]

    def test_strips_join_prefix(self, basic_schema):
        """'JOIN orders' becomes 'orders'."""
        intent = RuntimeIntent(
            tables=["JOIN orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = sanitize_table_names(intent, basic_schema)
        assert result.tables == ["orders"]

    def test_no_change_for_valid_name(self, basic_schema):
        """Already valid table name returns the same intent."""
        intent = RuntimeIntent(
            tables=["orders", "customer"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = sanitize_table_names(intent, basic_schema)
        assert result is intent

    def test_unknown_table_left_alone(self, basic_schema):
        """Table name that doesn't match schema even after stripping is
        left unchanged."""
        intent = RuntimeIntent(
            tables=["DISTINCT unknown_tbl"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = sanitize_table_names(intent, basic_schema)
        assert result.tables == ["DISTINCT unknown_tbl"]

    def test_multi_keyword_prefix(self, basic_schema):
        """'LEFT JOIN orders' strips both keywords."""
        intent = RuntimeIntent(
            tables=["LEFT JOIN orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = sanitize_table_names(intent, basic_schema)
        assert result.tables == ["orders"]


class TestPruneUnreferencedTablesWithSchemaGraph:
    """Tests for prune_unreferenced_tables with schema_graph parameter."""

    @pytest.fixture
    def prune_schema(self):
        """Schema with 'orders' (PK-only) and 'customer' (has descriptive
        'name' column)."""
        return SchemaGraph(
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={
                        "order_id": ColumnMetadata(
                            name="order_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                    },
                    foreign_keys=[
                        FKEdge(
                            src_table="orders",
                            dst_table="customer",
                            src_cols=["customer_id"],
                            dst_cols=["id"],
                        ),
                    ],
                    primary_key="",
                ),
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                        "name": ColumnMetadata(
                            name="name",
                            data_type="text",
                            value_type="string",
                            role=ColumnRole.CATEGORICAL.value,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_cosmetic_table_kept_when_descriptive_but_no_fk_filter(self, prune_schema):
        """After removing cosmetic prune logic, a table with
        descriptive select columns is kept even without FK filter."""
        intent = RuntimeIntent(
            tables=["orders", "customer"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.order_id")),
                SelectCol(expr=NormalizedExpr.from_column("customer.name")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.order_id"),
                    op=">",
                    raw_value=0,
                ),
            ],
        )
        result = prune_unreferenced_tables(intent, schema_graph=prune_schema)
        assert "customer" in result.tables
        assert "orders" in result.tables

    def test_cosmetic_table_kept_when_only_pk(self, prune_schema):
        """After removing cosmetic prune logic, a table contributing
        only PK columns is kept (pruning is purely reference-based)."""
        intent = RuntimeIntent(
            tables=["orders", "customer"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.order_id")),
                SelectCol(expr=NormalizedExpr.from_column("customer.id")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.order_id"),
                    op=">",
                    raw_value=0,
                ),
            ],
        )
        result = prune_unreferenced_tables(intent, schema_graph=prune_schema)
        assert "orders" in result.tables
        assert "customer" in result.tables


class TestResolveFilterListCascadeLower:
    """Tests for LOWER-based casing in _resolve_filter_list_cascade."""

    @pytest.fixture
    def name_schema(self):
        """Schema with a non-enum string column."""
        t = TableMetadata(
            name="customer",
            columns={
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"customer": t},
        )

    def test_lowercases_non_enum_string(self, name_schema):
        """Non-enum string value is lowercased."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.name"),
            op="=",
            value_type="string",
            raw_value="Alice",
        )
        result, changed = _resolve_filter_list_cascade([fp], name_schema, "")
        assert changed
        assert result[0].raw_value == "alice"

    def test_already_lowercase_unchanged(self, name_schema):
        """Already lowercase value is not changed."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.name"),
            op="=",
            value_type="string",
            raw_value="alice",
        )
        result, changed = _resolve_filter_list_cascade([fp], name_schema, "")
        assert not changed
        assert result[0].raw_value == "alice"

    def test_enum_match_preserves_casing(self):
        """Enum match preserves the database casing."""
        film = TableMetadata(
            name="film",
            columns={
                "rating": ColumnMetadata(
                    name="rating",
                    data_type="mpaa_rating",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        sg = SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={"film": film},
            enum_values={"mpaa_rating": ["G", "PG", "PG-13", "R", "NC-17"]},
        )
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("film.rating"),
            op="=",
            value_type="string",
            raw_value="pg",
        )
        result, changed = _resolve_filter_list_cascade([fp], sg, "")
        assert changed
        assert result[0].raw_value == "PG"

    def test_list_values_lowercased(self, name_schema):
        """List filter values are lowercased for non-enum columns."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customer.name"),
            op="in",
            value_type="string",
            raw_value=["Alice", "Bob"],
        )
        result, changed = _resolve_filter_list_cascade([fp], name_schema, "")
        assert changed
        assert result[0].raw_value == ["alice", "bob"]


class TestPruneWithFkFilterTarget:
    """Tests for prune_unreferenced_tables with FK filter target logic."""

    @pytest.fixture
    def fk_prune_schema(self):
        """Schema with FK fk_target metadata on orders.customer_id."""
        return SchemaGraph(
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={
                        "order_id": ColumnMetadata(
                            name="order_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                            fk_target=("customer", "id"),
                        ),
                    },
                    foreign_keys=[
                        FKEdge(
                            src_table="orders",
                            dst_table="customer",
                            src_cols=["customer_id"],
                            dst_cols=["id"],
                        ),
                    ],
                    primary_key="order_id",
                ),
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                        ),
                        "name": ColumnMetadata(
                            name="name",
                            data_type="text",
                            value_type="string",
                            role=ColumnRole.CATEGORICAL.value,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="id",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_kept_when_fk_filter_targets_table(self, fk_prune_schema):
        """Cosmetic table kept when FK filter targets its PK and it has
        descriptive select."""
        intent = RuntimeIntent(
            tables=["orders", "customer"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.order_id")),
                SelectCol(expr=NormalizedExpr.from_column("customer.name")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.customer_id"),
                    op="=",
                    raw_value=5,
                ),
            ],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=fk_prune_schema,
        )
        assert "customer" in result.tables
        assert "orders" in result.tables

    def test_kept_when_no_fk_filter_targets_table(self, fk_prune_schema):
        """After removing cosmetic prune logic, table is kept even
        without FK filter targeting its PK."""
        intent = RuntimeIntent(
            tables=["orders", "customer"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.order_id")),
                SelectCol(expr=NormalizedExpr.from_column("customer.name")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.order_id"),
                    op=">",
                    raw_value=0,
                ),
            ],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=fk_prune_schema,
        )
        assert "customer" in result.tables
        assert "orders" in result.tables


class TestInferCteOutputColumns:
    """Tests for _infer_cte_output_columns."""

    def test_bare_columns_extracted(self):
        """Extracts trailing column name from qualified expressions."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.customer_id")),
                SelectCol(expr=NormalizedExpr.from_column("orders.total")),
            ],
        )
        result = _infer_cte_output_columns(cte)
        assert result == ["customer_id", "total"]

    def test_aggregated_column_prefixed(self):
        """Aggregated columns get agg_func prefix."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["rental"],
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(multiply=["rental.rental_id"])],
                        agg_func="count",
                    ),
                ),
            ],
        )
        result = _infer_cte_output_columns(cte)
        assert result == ["count_rental_id"]

    def test_empty_select_cols(self):
        """Returns empty list when no select columns."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
        )
        result = _infer_cte_output_columns(cte)
        assert result == []

    def test_deduplicates_names(self):
        """Does not produce duplicate output column names."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.total")),
                SelectCol(expr=NormalizedExpr.from_column("payment.total")),
            ],
        )
        result = _infer_cte_output_columns(cte)
        assert result == ["total"]


class TestQualifyCteWithInferredOutputs:
    """Tests for qualify_cte_output_columns with inferred outputs."""

    def test_qualifies_main_query_from_inferred_outputs(self):
        """Main query references qualified when CTE output_columns is empty
        but select_cols can be inferred."""
        intent = RuntimeIntent(
            tables=[],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("customer_id")),
                SelectCol(expr=NormalizedExpr.from_column("count_rental_id")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[
                RuntimeCteStep(
                    cte_name="cte1",
                    tables=["rental"],
                    select_cols=[
                        SelectCol(expr=NormalizedExpr.from_column("rental.customer_id")),
                        SelectCol(
                            expr=NormalizedExpr(
                                add_groups=[MulGroup(multiply=["rental.rental_id"])],
                                agg_func="count",
                            ),
                        ),
                    ],
                ),
            ],
        )
        result = qualify_cte_output_columns(intent)
        main_cols = [sc.expr.primary_column for sc in result.select_cols]
        assert any("cte1." in c for c in main_cols)


class TestIsNullValue:
    """Tests for _is_null_value."""

    def test_none_is_null(self):
        """Python None is considered null."""
        assert _is_null_value(None) is True

    def test_null_string_is_null(self):
        """String 'null' is considered null."""
        assert _is_null_value("null") is True

    def test_null_string_case_insensitive(self):
        """String 'NULL' is considered null."""
        assert _is_null_value("NULL") is True

    def test_null_string_with_whitespace(self):
        """String ' null ' with whitespace is considered null."""
        assert _is_null_value(" null ") is True

    def test_non_null_string(self):
        """Regular string value is not null."""
        assert _is_null_value("hello") is False

    def test_zero_is_not_null(self):
        """Integer zero is not null."""
        assert _is_null_value(0) is False

    def test_empty_string_is_not_null(self):
        """Empty string is not null."""
        assert _is_null_value("") is False


class TestRepairNullEqualityFilters:
    """Tests for repair_null_equality_filters."""

    def test_equality_null_becomes_is_null(self):
        """Filter with op='=' and value=None becomes op='is null'."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.return_date"),
                    op="=",
                    value_type="date",
                    raw_value=None,
                ),
            ],
        )
        result = repair_null_equality_filters(intent)
        assert result.filters_param[0].op == "is null"
        assert result.filters_param[0].raw_value is None
        assert result.filters_param[0].value_type == "null"

    def test_equality_null_string_becomes_is_null(self):
        """Filter with op='=' and value='null' becomes op='is null'."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.return_date"),
                    op="=",
                    value_type="string",
                    raw_value="null",
                ),
            ],
        )
        result = repair_null_equality_filters(intent)
        assert result.filters_param[0].op == "is null"
        assert result.filters_param[0].raw_value is None

    def test_not_equal_null_becomes_is_not_null(self):
        """Filter with op='!=' and value=None becomes op='is not null'."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.return_date"),
                    op="!=",
                    value_type="date",
                    raw_value=None,
                ),
            ],
        )
        result = repair_null_equality_filters(intent)
        assert result.filters_param[0].op == "is not null"
        assert result.filters_param[0].raw_value is None
        assert result.filters_param[0].value_type == "null"

    def test_diamond_not_equal_null_becomes_is_not_null(self):
        """Filter with op='<>' and value=None becomes op='is not null'."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.return_date"),
                    op="<>",
                    value_type="date",
                    raw_value=None,
                ),
            ],
        )
        result = repair_null_equality_filters(intent)
        assert result.filters_param[0].op == "is not null"

    def test_non_null_equality_unchanged(self):
        """Filter with op='=' and non-null value is unchanged."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="=",
                    value_type="string",
                    raw_value="active",
                ),
            ],
        )
        result = repair_null_equality_filters(intent)
        assert result.filters_param[0].op == "="
        assert result.filters_param[0].raw_value == "active"

    def test_cte_filters_also_repaired(self):
        """Null equality filters inside CTE steps are also repaired."""
        intent = RuntimeIntent(
            tables=[],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[
                RuntimeCteStep(
                    cte_name="cte1",
                    tables=["rental"],
                    filters_param=[
                        FilterParam(
                            left_expr=NormalizedExpr.from_column("rental.return_date"),
                            op="=",
                            value_type="date",
                            raw_value=None,
                        ),
                    ],
                ),
            ],
        )
        result = repair_null_equality_filters(intent)
        assert result.cte_steps[0].filters_param[0].op == "is null"


class TestFindFkColumnForPk:
    """Tests for _find_fk_column_for_pk."""

    @pytest.fixture
    def bridge_schema(self):
        """Schema with film, film_actor, and actor tables."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "film_actor": TableMetadata(
                    name="film_actor",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("film", "film_id"),
                        ),
                        "actor_id": ColumnMetadata(
                            name="actor_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("actor", "actor_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "actor": TableMetadata(
                    name="actor",
                    columns={
                        "actor_id": ColumnMetadata(
                            name="actor_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_finds_fk_on_bridge_table(self, bridge_schema):
        """Finds film_actor.film_id as FK for film.film_id."""
        result = _find_fk_column_for_pk(
            "film",
            "film_id",
            {"film_actor", "actor"},
            bridge_schema,
        )
        assert result == "film_actor.film_id"

    def test_returns_none_when_no_fk(self, bridge_schema):
        """Returns None when no candidate has a matching FK."""
        result = _find_fk_column_for_pk(
            "film",
            "film_id",
            {"actor"},
            bridge_schema,
        )
        assert result is None


class TestRewriteRedundantPkAggregations:
    """Tests for _rewrite_redundant_pk_aggregations."""

    @pytest.fixture
    def bridge_schema(self):
        """Schema with film→film_actor FK and store→customer FK."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "film_actor": TableMetadata(
                    name="film_actor",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("film", "film_id"),
                        ),
                        "actor_id": ColumnMetadata(
                            name="actor_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("actor", "actor_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "actor": TableMetadata(
                    name="actor",
                    columns={
                        "actor_id": ColumnMetadata(
                            name="actor_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "store": TableMetadata(
                    name="store",
                    columns={
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("store", "store_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_rewrites_count_film_to_film_actor(self, bridge_schema):
        """COUNT(film.film_id) → COUNT(film_actor.film_id)."""
        select_cols = [
            SelectCol(expr=NormalizedExpr.from_column("actor.actor_id")),
            SelectCol(expr=NormalizedExpr.from_agg("count", "film.film_id")),
        ]
        result, eliminated = _rewrite_redundant_pk_aggregations(
            select_cols,
            select_only_tables={"film"},
            essential_tables={"actor", "film_actor"},
            schema_graph=bridge_schema,
        )
        assert "film" in eliminated
        assert len(result) == 2
        assert result[1].expr.primary_column == "film_actor.film_id"
        assert result[1].is_aggregated

    def test_drops_redundant_count_when_other_agg_exists(self, bridge_schema):
        """COUNT(store.store_id) is dropped when another COUNT exists."""
        select_cols = [
            SelectCol(expr=NormalizedExpr.from_column("customer.store_id")),
            SelectCol(expr=NormalizedExpr.from_agg("count", "customer.customer_id")),
            SelectCol(expr=NormalizedExpr.from_agg("count", "store.store_id")),
        ]
        result, eliminated = _rewrite_redundant_pk_aggregations(
            select_cols,
            select_only_tables={"store"},
            essential_tables={"customer"},
            schema_graph=bridge_schema,
        )
        assert "store" in eliminated
        assert len(result) == 2
        terms = [sc.expr.primary_term for sc in result]
        assert "store.store_id" not in terms

    def test_no_rewrite_when_no_fk_available(self, bridge_schema):
        """Keeps table when no FK column is available for rewrite."""
        select_cols = [
            SelectCol(expr=NormalizedExpr.from_agg("count", "actor.actor_id")),
        ]
        result, eliminated = _rewrite_redundant_pk_aggregations(
            select_cols,
            select_only_tables={"actor"},
            essential_tables={"film"},
            schema_graph=bridge_schema,
        )
        assert "actor" not in eliminated
        assert len(result) == 1

    def test_no_rewrite_when_table_has_bare_column(self, bridge_schema):
        """Table with non-aggregated column is not rewritten."""
        select_cols = [
            SelectCol(expr=NormalizedExpr.from_column("film.film_id")),
            SelectCol(expr=NormalizedExpr.from_agg("count", "film.film_id")),
        ]
        result, eliminated = _rewrite_redundant_pk_aggregations(
            select_cols,
            select_only_tables={"film"},
            essential_tables={"film_actor"},
            schema_graph=bridge_schema,
        )
        assert "film" not in eliminated
        assert len(result) == 2


class TestPruneKeepsAggregationTables:
    """Tests for Fix X: prune_unreferenced_tables keeps tables that
    contribute aggregated SelectCols."""

    @pytest.fixture
    def revenue_schema(self):
        """Schema with country and payment tables for AJ-006 scenario."""
        return SchemaGraph(
            tables={
                "country": TableMetadata(
                    name="country",
                    columns={
                        "country_id": ColumnMetadata(
                            name="country_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "country": ColumnMetadata(
                            name="country",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "payment": TableMetadata(
                    name="payment",
                    columns={
                        "payment_id": ColumnMetadata(
                            name="payment_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "amount": ColumnMetadata(
                            name="amount",
                            data_type="numeric",
                            value_type="number",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_payment_kept_for_total_revenue_per_country(self, revenue_schema):
        """payment table with SUM(amount) is not pruned even though
        'payment' is not in the question."""
        intent = RuntimeIntent(
            tables=["country", "payment"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("country.country")),
                SelectCol(expr=NormalizedExpr.from_agg("sum", "payment.amount")),
            ],
            group_by_cols=[NormalizedExpr.from_column("country.country")],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=revenue_schema,
        )
        assert "payment" in result.tables
        assert "country" in result.tables
        assert any(sc.is_aggregated for sc in result.select_cols)


class TestPruneColumnComponentSuppression:
    """Tests for Fix Y1: column-component suppression in pruning."""

    @pytest.fixture
    def rental_schema(self):
        """Schema where film has rental_duration and rental table
        exists."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "rating": ColumnMetadata(
                            name="rating",
                            data_type="varchar",
                            value_type="string",
                        ),
                        "rental_duration": ColumnMetadata(
                            name="rental_duration",
                            data_type="integer",
                            value_type="integer",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "inventory": TableMetadata(
                    name="inventory",
                    columns={
                        "inventory_id": ColumnMetadata(
                            name="inventory_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("film", "film_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "rental": TableMetadata(
                    name="rental",
                    columns={
                        "rental_id": ColumnMetadata(
                            name="rental_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "inventory_id": ColumnMetadata(
                            name="inventory_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("inventory", "inventory_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_rental_table_kept_when_referenced_in_select(self, rental_schema):
        """rental is kept because COUNT(rental.rental_id) references it;
        inventory pruned as genuinely unreferenced.  The old cosmetic
        column-component prune was removed (Fix 1)."""
        intent = RuntimeIntent(
            tables=["film", "inventory", "rental"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("film.rating")),
                SelectCol(expr=NormalizedExpr.from_agg("avg", "film.rental_duration")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "rental.rental_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("film.rating")],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=rental_schema,
        )
        assert "film" in result.tables
        assert "rental" in result.tables
        assert "inventory" not in result.tables


class TestPruneFkAggRewrite:
    """Tests for Fix Y2: FK aggregation rewrite in pruning."""

    @pytest.fixture
    def bridge_schema(self):
        """Schema with actor→film_actor→film chain."""
        return SchemaGraph(
            tables={
                "actor": TableMetadata(
                    name="actor",
                    columns={
                        "actor_id": ColumnMetadata(
                            name="actor_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "film_actor": TableMetadata(
                    name="film_actor",
                    columns={
                        "actor_id": ColumnMetadata(
                            name="actor_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("actor", "actor_id"),
                        ),
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("film", "film_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "customer": TableMetadata(
                    name="customer",
                    columns={
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("store", "store_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "store": TableMetadata(
                    name="store",
                    columns={
                        "store_id": ColumnMetadata(
                            name="store_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_film_pruned_via_fk_rewrite_bj001(self, bridge_schema):
        """film table pruned by rewriting COUNT(film.film_id) →
        COUNT(film_actor.film_id) for 'how many films is each actor
        in'."""
        intent = RuntimeIntent(
            tables=["actor", "film", "film_actor"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("actor.actor_id")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "film.film_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("actor.actor_id")],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=bridge_schema,
        )
        assert sorted(result.tables) == ["actor", "film_actor"]
        agg_cols = [sc for sc in result.select_cols if sc.is_aggregated]
        assert len(agg_cols) == 1
        assert "film_actor" in agg_cols[0].expr.primary_column

    def test_store_pruned_via_redundant_agg_drop_bf003(self, bridge_schema):
        """store table pruned by dropping redundant COUNT(store.store_id)
        for 'count active customers by store'."""
        intent = RuntimeIntent(
            tables=["customer", "store"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("customer.store_id")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "customer.customer_id")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "store.store_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("customer.store_id")],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("customer.activebool"),
                    op="=",
                    raw_value=True,
                    value_type="boolean",
                ),
            ],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=bridge_schema,
        )
        assert "customer" in result.tables
        assert "store" not in result.tables
        agg_cols = [sc for sc in result.select_cols if sc.is_aggregated]
        assert len(agg_cols) == 1


class TestPruneUnreferencedKeepsExplicitSelectCol:
    """Tests for Task 1 safety check: prune_unreferenced_tables keeps
    tables explicitly referenced as 'table.column' in select_cols."""

    @pytest.fixture
    def language_schema(self):
        """Minimal schema with film and language tables."""
        return SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={
                        "film_id": ColumnMetadata(
                            name="film_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "title": ColumnMetadata(
                            name="title",
                            data_type="varchar",
                            value_type="string",
                        ),
                        "language_id": ColumnMetadata(
                            name="language_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            fk_target=("language", "language_id"),
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "language": TableMetadata(
                    name="language",
                    columns={
                        "language_id": ColumnMetadata(
                            name="language_id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                        ),
                        "name": ColumnMetadata(
                            name="name",
                            data_type="varchar",
                            value_type="string",
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )

    def test_language_kept_when_explicitly_in_select_cols(self, language_schema):
        """language table is NOT pruned when a non-aggregated language.name
        is in select_cols and language appears in the question."""
        intent = RuntimeIntent(
            tables=["film", "language"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("film.title")),
                SelectCol(expr=NormalizedExpr.from_column("language.name")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = prune_unreferenced_tables(
            intent,
            schema_graph=language_schema,
        )
        assert "film" in result.tables
        assert "language" in result.tables
