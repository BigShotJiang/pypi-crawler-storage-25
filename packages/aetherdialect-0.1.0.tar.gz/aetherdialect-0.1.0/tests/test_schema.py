"""Tests for schema module: schema reflection, graph building, and utility functions."""

from __future__ import annotations

from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    FKEdge,
    SchemaGraph,
    SchemaLimits,
    TableMetadata,
    TableRole,
)
from text2sql.schema import (
    _analyze_fk_path_topology,
    _edge_key,
    _infer_missing_fks,
    _normalize_fk_path,
    _reverse_fk_path,
    _table_from_dict,
    _table_to_dict,
    _tables_meta_to_schema_graph,
    compute_schema_limits,
    compute_schema_stats,
)


def _col(**overrides) -> ColumnMetadata:
    """Build a ColumnMetadata with sensible defaults."""
    defaults = dict(
        name="col",
        data_type="varchar",
        is_primary_key=False,
        is_foreign_key=False,
        fk_target=None,
        role=ColumnRole.CATEGORICAL.value,
        distinct_count=10,
        distinct_ratio=0.5,
        row_count=20,
    )
    defaults.update(overrides)
    return ColumnMetadata(**defaults)


def _table(name, columns, **overrides) -> TableMetadata:
    """Build a TableMetadata with sensible defaults."""
    defaults = dict(
        name=name,
        columns=columns,
        primary_key=[],
        foreign_keys=[],
        role=TableRole.DIMENSION.value,
        row_count=100,
    )
    defaults.update(overrides)
    return TableMetadata(**defaults)


class TestComputeSchemaStats:
    """Tests for compute_schema_stats."""

    def test_basic_stats(self, schema_graph):
        """Should compute correct stats for the 3-table schema."""
        for t in schema_graph.tables.values():
            for c in t.columns.values():
                c.is_filterable_override = c.role in (
                    ColumnRole.CATEGORICAL.value,
                    ColumnRole.TEMPORAL.value,
                    ColumnRole.BOOLEAN.value,
                    ColumnRole.NUMERIC_MEASURE.value,
                )
                c.is_groupable_override = c.role in (ColumnRole.CATEGORICAL.value,)
                c.is_aggregatable_override = c.role in (ColumnRole.NUMERIC_MEASURE.value,)

        stats = compute_schema_stats(schema_graph)
        assert stats["table_count"] == 3
        assert stats["total_filterable"] > 0
        assert stats["total_groupable"] > 0
        assert stats["total_aggregatable"] > 0

    def test_empty_schema(self):
        """Empty schema should produce zero counts."""
        sg = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="empty")
        stats = compute_schema_stats(sg)
        assert stats["table_count"] == 0
        assert stats["total_filterable"] == 0
        assert stats["min_filterable_per_table"] == 0

    def test_filterable_per_table_populated(self, schema_graph):
        """filterable_per_table should have one entry per table with
        filterable cols."""
        for t in schema_graph.tables.values():
            for c in t.columns.values():
                c.is_filterable_override = True
                c.is_groupable_override = False
                c.is_aggregatable_override = False
        stats = compute_schema_stats(schema_graph)
        assert len(stats["filterable_per_table"]) == 3


class TestComputeSchemaLimits:
    """Tests for compute_schema_limits."""

    def test_small_schema(self):
        """Small schema (<=3 tables) should set max_tables =
        table_count."""
        stats = {
            "table_count": 3,
            "total_filterable": 12,
            "total_groupable": 6,
        }
        limits = compute_schema_limits(stats)
        assert isinstance(limits, SchemaLimits)
        assert limits.max_tables == 3
        assert limits.max_filters >= 1
        assert limits.max_groupby >= 1

    def test_medium_schema(self):
        """Medium schema (4-10 tables) should set max_tables = 3."""
        stats = {"table_count": 7, "total_filterable": 28, "total_groupable": 14}
        limits = compute_schema_limits(stats)
        assert limits.max_tables == 3

    def test_large_schema(self):
        """Large schema (>10 tables) should set max_tables = 4."""
        stats = {"table_count": 15, "total_filterable": 60, "total_groupable": 30}
        limits = compute_schema_limits(stats)
        assert limits.max_tables == 4

    def test_zero_tables(self):
        """Zero tables should produce valid limits without division
        error."""
        stats = {"table_count": 0, "total_filterable": 0, "total_groupable": 0}
        limits = compute_schema_limits(stats)
        assert limits.max_filters == 1
        assert limits.max_groupby == 1


class TestTableDictRoundtrip:
    """Tests for _table_to_dict / _table_from_dict roundtrip."""

    def test_roundtrip_preserves_name(self):
        """Table name should survive serialization roundtrip."""
        t = _table("orders", {"id": _col(name="id", is_primary_key=True)}, primary_key=["id"])
        d = _table_to_dict(t)
        restored = _table_from_dict(d)
        assert restored.name == "orders"

    def test_roundtrip_preserves_columns(self):
        """All columns should survive roundtrip."""
        t = _table(
            "t",
            {
                "a": _col(name="a", data_type="integer"),
                "b": _col(name="b", data_type="varchar"),
            },
        )
        d = _table_to_dict(t)
        restored = _table_from_dict(d)
        assert set(restored.columns.keys()) == {"a", "b"}
        assert restored.columns["a"].data_type == "integer"

    def test_roundtrip_preserves_fk(self):
        """Foreign keys should survive roundtrip."""
        fk = FKEdge(src_table="o", src_cols=["uid"], dst_table="u", dst_cols=["id"])
        t = _table("o", {"uid": _col(name="uid")}, foreign_keys=[fk])
        d = _table_to_dict(t)
        restored = _table_from_dict(d)
        assert len(restored.foreign_keys) == 1
        assert restored.foreign_keys[0].dst_table == "u"

    def test_roundtrip_preserves_role(self):
        """Table role should survive roundtrip."""
        t = _table("t", {"c": _col(name="c")}, role=TableRole.FACT.value)
        d = _table_to_dict(t)
        restored = _table_from_dict(d)
        assert restored.role == TableRole.FACT.value

    def test_roundtrip_preserves_row_count(self):
        """Row count should survive roundtrip."""
        t = _table("t", {"c": _col(name="c")}, row_count=42)
        d = _table_to_dict(t)
        restored = _table_from_dict(d)
        assert restored.row_count == 42


class TestReverseFkPath:
    """Tests for _reverse_fk_path."""

    def test_single_edge_reversal(self):
        """Single edge should have src/dst swapped."""
        path = [
            {
                "src_table": "A",
                "src_cols": ["a_id"],
                "dst_table": "B",
                "dst_cols": ["b_id"],
            }
        ]
        result = _reverse_fk_path(path)
        assert len(result) == 1
        assert result[0]["src_table"] == "B"
        assert result[0]["dst_table"] == "A"
        assert result[0]["src_cols"] == ["b_id"]
        assert result[0]["dst_cols"] == ["a_id"]

    def test_multi_edge_reversal(self):
        """Multi-edge path should reverse order and swap each edge."""
        path = [
            {"src_table": "A", "src_cols": ["x"], "dst_table": "B", "dst_cols": ["y"]},
            {"src_table": "B", "src_cols": ["z"], "dst_table": "C", "dst_cols": ["w"]},
        ]
        result = _reverse_fk_path(path)
        assert len(result) == 2
        assert result[0]["src_table"] == "C"
        assert result[0]["dst_table"] == "B"
        assert result[1]["src_table"] == "B"
        assert result[1]["dst_table"] == "A"

    def test_empty_path(self):
        """Empty path should return empty list."""
        assert _reverse_fk_path([]) == []


class TestAnalyzeFkPathTopology:
    """Tests for _analyze_fk_path_topology."""

    def test_empty_path(self):
        """Empty path should produce 'none' topology."""
        topo, anchor, leaves = _analyze_fk_path_topology([])
        assert topo == "none"
        assert anchor == ""
        assert leaves == []

    def test_linear_path(self):
        """A->B->C is a linear path."""
        path = [
            {"src_table": "A", "src_cols": ["x"], "dst_table": "B", "dst_cols": ["y"]},
            {"src_table": "B", "src_cols": ["z"], "dst_table": "C", "dst_cols": ["w"]},
        ]
        topo, anchor, leaves = _analyze_fk_path_topology(path)
        assert topo == "linear"
        assert set(leaves) == {"A", "C"}

    def test_star_topology(self):
        """Hub table connected to multiple leaves is a star."""
        path = [
            {
                "src_table": "Hub",
                "src_cols": ["x"],
                "dst_table": "L1",
                "dst_cols": ["y"],
            },
            {
                "src_table": "Hub",
                "src_cols": ["a"],
                "dst_table": "L2",
                "dst_cols": ["b"],
            },
            {
                "src_table": "Hub",
                "src_cols": ["c"],
                "dst_table": "L3",
                "dst_cols": ["d"],
            },
        ]
        topo, anchor, leaves = _analyze_fk_path_topology(path)
        assert topo == "star"
        assert anchor == "Hub"
        assert set(leaves) == {"L1", "L2", "L3"}


class TestNormalizeFkPath:
    """Tests for _normalize_fk_path."""

    def test_empty_path_unchanged(self):
        """Empty path should return empty."""
        assert _normalize_fk_path([]) == []

    def test_linear_path_oriented_from_smallest_leaf(self):
        """Linear path should start from lexicographically smallest
        leaf."""
        path = [
            {"src_table": "B", "src_cols": ["x"], "dst_table": "A", "dst_cols": ["y"]},
        ]
        result = _normalize_fk_path(path)
        assert result[0]["src_table"] in ("A", "B")


class TestInferMissingFks:
    """Tests for infer_missing_fks."""

    def test_infers_from_column_suffix(self):
        """Column ending in _id matching a table name should infer
        FK."""
        tables = {
            "orders": _table(
                "orders",
                {
                    "order_id": _col(name="order_id", is_primary_key=True),
                    "customer_id": _col(name="customer_id"),
                },
                primary_key=["order_id"],
            ),
            "customer": _table(
                "customer",
                {
                    "customer_id": _col(name="customer_id", is_primary_key=True),
                },
                primary_key=["customer_id"],
            ),
        }
        inferred = _infer_missing_fks(tables)
        assert len(inferred) == 1
        assert inferred[0].src_table == "orders"
        assert inferred[0].dst_table == "customer"

    def test_skips_existing_fk(self):
        """Column already marked as FK should not be inferred again."""
        tables = {
            "orders": _table(
                "orders",
                {
                    "customer_id": _col(name="customer_id", is_foreign_key=True),
                },
            ),
            "customer": _table(
                "customer",
                {
                    "customer_id": _col(name="customer_id", is_primary_key=True),
                },
                primary_key=["customer_id"],
            ),
        }
        inferred = _infer_missing_fks(tables)
        assert len(inferred) == 0

    def test_skips_pk_column(self):
        """Primary key columns should not be inferred as FK."""
        tables = {
            "customer": _table(
                "customer",
                {
                    "customer_id": _col(name="customer_id", is_primary_key=True),
                },
                primary_key=["customer_id"],
            ),
        }
        inferred = _infer_missing_fks(tables)
        assert len(inferred) == 0

    def test_no_match_returns_empty(self):
        """When no column suffix matches a table, no FKs should be
        inferred."""
        tables = {
            "alpha": _table("alpha", {"foo": _col(name="foo")}),
            "beta": _table("beta", {"bar": _col(name="bar")}),
        }
        inferred = _infer_missing_fks(tables)
        assert inferred == []

    def test_self_reference_skipped(self):
        """FK pointing to own table should be skipped."""
        tables = {
            "employee": _table(
                "employee",
                {
                    "employee_id": _col(name="employee_id", is_primary_key=True),
                },
                primary_key=["employee_id"],
            ),
        }
        inferred = _infer_missing_fks(tables)
        assert len(inferred) == 0


class TestTablesMetaToSchemaGraph:
    """Tests for _tables_meta_to_schema_graph."""

    def test_builds_tables(self):
        """Should create TableMetadata for each entry."""
        meta = {
            "users": {
                "column_names_original": ["user_id", "name"],
                "column_types": ["integer", "varchar"],
                "primary_keys": ["user_id"],
                "foreign_keys": [],
            },
        }
        sg = _tables_meta_to_schema_graph(meta)
        assert "users" in sg.tables
        assert "user_id" in sg.tables["users"].columns
        assert sg.tables["users"].columns["user_id"].is_primary_key is True

    def test_join_paths_populated(self):
        """Two tables with FK should have join paths."""
        meta = {
            "orders": {
                "column_names_original": ["order_id", "user_id"],
                "column_types": ["integer", "integer"],
                "primary_keys": ["order_id"],
                "foreign_keys": [
                    {
                        "src_cols": ["user_id"],
                        "dst_table": "users",
                        "dst_cols": ["user_id"],
                    },
                ],
            },
            "users": {
                "column_names_original": ["user_id", "name"],
                "column_types": ["integer", "varchar"],
                "primary_keys": ["user_id"],
                "foreign_keys": [],
            },
        }
        sg = _tables_meta_to_schema_graph(meta)
        assert "orders" in sg.join_paths_multi
        assert "users" in sg.join_paths_multi["orders"]
        assert len(sg.join_paths_multi["orders"]["users"]) >= 1

    def test_self_join_path_is_empty_list(self):
        """Join path from a table to itself should be [[]]."""
        meta = {
            "t": {
                "column_names_original": ["id"],
                "column_types": ["integer"],
                "primary_keys": ["id"],
                "foreign_keys": [],
            },
        }
        sg = _tables_meta_to_schema_graph(meta)
        assert sg.join_paths_multi["t"]["t"] == [[]]

    def test_schema_hash_is_set(self):
        """Generated graph should have a non-empty schema_hash."""
        meta = {
            "t": {
                "column_names_original": ["id"],
                "column_types": ["integer"],
                "primary_keys": ["id"],
                "foreign_keys": [],
            },
        }
        sg = _tables_meta_to_schema_graph(meta)
        assert sg.schema_hash
        assert isinstance(sg.schema_hash, str)

    def test_fk_marks_column_as_foreign_key(self):
        """FK columns should have is_foreign_key=True and fk_target
        set."""
        meta = {
            "orders": {
                "column_names_original": ["order_id", "user_id"],
                "column_types": ["integer", "integer"],
                "primary_keys": ["order_id"],
                "foreign_keys": [
                    {
                        "src_cols": ["user_id"],
                        "dst_table": "users",
                        "dst_cols": ["uid"],
                    },
                ],
            },
            "users": {
                "column_names_original": ["uid"],
                "column_types": ["integer"],
                "primary_keys": ["uid"],
                "foreign_keys": [],
            },
        }
        sg = _tables_meta_to_schema_graph(meta)
        assert sg.tables["orders"].columns["user_id"].is_foreign_key is True
        assert sg.tables["orders"].columns["user_id"].fk_target == ("users", "uid")

    def test_skips_fk_when_dst_table_missing(self):
        """FK edges referencing missing tables are skipped without KeyError."""
        meta = {
            "film": {
                "column_names_original": ["film_id", "language_id"],
                "column_types": ["integer", "integer"],
                "primary_keys": ["film_id"],
                "foreign_keys": [
                    {
                        "src_cols": ["language_id"],
                        "dst_table": "language",
                        "dst_cols": ["language_id"],
                    },
                ],
            },
        }
        sg = _tables_meta_to_schema_graph(meta)
        assert "film" in sg.tables
        assert sg.join_paths_multi["film"]["film"] == [[]]


class TestEdgeKey:
    """Tests for _edge_key."""

    def test_produces_stable_tuple(self):
        """_edge_key returns stable sortable tuple."""
        e = FKEdge(
            src_table="orders",
            src_cols=["customer_id"],
            dst_table="customers",
            dst_cols=["id"],
        )
        key = _edge_key(e)
        assert key == ("orders", ("customer_id",), "customers", ("id",))

    def test_composite_key(self):
        """_edge_key handles composite src and dst cols."""
        e = FKEdge(
            src_table="t1",
            src_cols=["a", "b"],
            dst_table="t2",
            dst_cols=["x", "y"],
        )
        key = _edge_key(e)
        assert key[1] == ("a", "b")
        assert key[3] == ("x", "y")


class TestComputeSchemaLimitsEdgeCases:
    """Edge cases for compute_schema_limits."""

    def test_table_count_over_10_max_tables_four(self):
        """table_count > 10 yields max_tables=4."""
        stats = {"table_count": 15, "total_filterable": 50, "total_groupable": 30}
        limits = compute_schema_limits(stats)
        assert limits.max_tables == 4

    def test_single_table(self):
        """Single table should have max_tables = 1."""
        stats = {"table_count": 1, "total_filterable": 3, "total_groupable": 2}
        limits = compute_schema_limits(stats)
        assert limits.max_tables == 1
