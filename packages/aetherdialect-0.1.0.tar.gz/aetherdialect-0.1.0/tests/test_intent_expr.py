"""Tests for intent_expr module."""

import json
from dataclasses import replace

import pytest

from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    SchemaGraph,
    SQLShape,
    TableMetadata,
    TemplateStats,
)
from text2sql.contracts_core import (
    ConcreteIntent,
    ExprValue,
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
    Template,
    ValueHistory,
)
from text2sql.intent_expr import (
    _assign_structural_expr,
    _assign_structural_group,
    _classify_cte_expr,
    _fill_expr_defaults,
    _fill_group_defaults,
    _is_date_or_interval_expr,
    _is_expr_numeric,
    _is_nontrivial_group,
    _is_trivial_zero,
    _parse_between_raw_value,
    _parse_term,
    _peel_function,
    _split_additive,
    _split_multiplicative,
    _strip_angle_brackets,
    _tag_single_expr,
    assign_param_keys,
    build_cte_output_metadata,
    decompose_between_params,
    derive_cte_output_columns,
    ensure_scalar_func_defaults,
    extract_columns_from_expr,
    extract_structural_params,
    has_non_default_structural,
    normalize_date_diff_raw_values,
    normalize_in_raw_values,
    parse_expr_string,
    parse_intent_response,
    repair_misclassified_date_diff,
    tag_expr_numeric,
)


class TestPeelFunction:
    """Tests for _peel_function."""

    def test_no_function(self):
        """Return None for bare column reference."""
        name, arg, body = _peel_function("table1.col1")
        assert name is None
        assert body == "table1.col1"

    def test_simple_function(self):
        """Peel single-argument function wrapper."""
        name, arg, body = _peel_function("COUNT(table1.col1)")
        assert name == "COUNT"
        assert body == "table1.col1"

    def test_function_with_numeric_arg(self):
        """Peel function with trailing numeric argument."""
        name, arg, body = _peel_function("ROUND(table1.col1, 2)")
        assert name == "ROUND"
        assert arg == 2
        assert body == "table1.col1"

    def test_nested_function(self):
        """Peel outermost function only."""
        name, arg, body = _peel_function("ROUND(SUM(table1.col1), 2)")
        assert name == "ROUND"
        assert arg == 2
        assert body == "SUM(table1.col1)"

    def test_extract_from_syntax(self):
        """Peel EXTRACT(month FROM col) style function."""
        name, arg, body = _peel_function("EXTRACT(month FROM table1.col1)")
        assert name == "EXTRACT"
        assert arg == "month"
        assert body == "table1.col1"

    def test_not_wrapping_whole_string(self):
        """Return None if function does not wrap entire string."""
        name, arg, body = _peel_function("SUM(a) + SUM(b)")
        assert name is None
        assert body == "SUM(a) + SUM(b)"


class TestSplitAdditive:
    """Tests for _split_additive."""

    def test_simple_addition(self):
        """Split a + b."""
        result = _split_additive("a + b")
        assert result == [("+", "a"), ("+", "b")]

    def test_subtraction(self):
        """Split a - b."""
        result = _split_additive("a - b")
        assert result == [("+", "a"), ("-", "b")]

    def test_nested_parens_preserved(self):
        """Do not split inside parentheses."""
        result = _split_additive("SUM(a + b) - c")
        assert len(result) == 2
        assert result[0] == ("+", "SUM(a + b)")
        assert result[1] == ("-", "c")

    def test_empty_string(self):
        """Return default for empty string."""
        result = _split_additive("")
        assert result == [("+", "")]

    def test_leading_minus(self):
        """Handle leading minus sign."""
        result = _split_additive("-a + b")
        assert result[0] == ("-", "a")
        assert result[1] == ("+", "b")


class TestSplitMultiplicative:
    """Tests for _split_multiplicative."""

    def test_simple_multiply(self):
        """Split a * b."""
        mul, div = _split_multiplicative("a * b")
        assert mul == ["a", "b"]
        assert div == []

    def test_divide(self):
        """Split a / b."""
        mul, div = _split_multiplicative("a / b")
        assert mul == ["a"]
        assert div == ["b"]

    def test_mixed(self):
        """Split a * b / c."""
        mul, div = _split_multiplicative("a * b / c")
        assert mul == ["a", "b"]
        assert div == ["c"]

    def test_empty_string(self):
        """Empty string returns ([''], [])."""
        mul, div = _split_multiplicative("")
        assert mul == [""]
        assert div == []


class TestParseTerm:
    """Tests for _parse_term."""

    def test_numeric_literal(self):
        """Parse numeric literal to ExprValue."""
        result = _parse_term("42")
        assert isinstance(result, ExprValue)
        assert result.value == 42.0

    def test_column_reference(self):
        """Parse column reference to MulGroup."""
        result = _parse_term("table1.col1")
        assert isinstance(result, MulGroup)
        assert "table1.col1" in result.multiply

    def test_aggregated_term(self):
        """Parse COUNT(table1.col1) to MulGroup with agg_func."""
        result = _parse_term("COUNT(table1.col1)")
        assert isinstance(result, MulGroup)
        assert result.agg_func == "count"

    def test_coefficient_multiply(self):
        """Parse column * 100 extracts coefficient."""
        result = _parse_term("table1.col1 * 100")
        assert isinstance(result, MulGroup)
        assert result.coefficient == 100.0


class TestIsTrivialZero:
    """Tests for _is_trivial_zero."""

    def test_zero_integer(self):
        """Detect zero integer literal."""
        assert _is_trivial_zero("0") is True

    def test_zero_float(self):
        """Detect zero float literal."""
        assert _is_trivial_zero("0.0") is True

    def test_zero_with_whitespace(self):
        """Detect zero with surrounding whitespace."""
        assert _is_trivial_zero("  0  ") is True

    def test_non_zero(self):
        """Reject non-zero literal."""
        assert _is_trivial_zero("5") is False

    def test_non_numeric(self):
        """Reject non-numeric string."""
        assert _is_trivial_zero("abc") is False


class TestParseExprString:
    """Tests for parse_expr_string."""

    def test_bare_column(self):
        """Parse bare column to NormalizedExpr."""
        expr = parse_expr_string("table1.col1")
        assert len(expr.add_groups) == 1
        assert expr.primary_column == "table1.col1"

    def test_count_star(self):
        """Parse COUNT(*)."""
        expr = parse_expr_string("COUNT(*)")
        assert expr.has_aggregation is True

    def test_additive_expression(self):
        """Parse SUM(a) - SUM(b) into add and sub groups."""
        expr = parse_expr_string("SUM(table1.a) - SUM(table1.b)")
        assert len(expr.add_groups) == 1
        assert len(expr.sub_groups) == 1

    def test_empty_string(self):
        """Parse empty string to empty NormalizedExpr."""
        expr = parse_expr_string("")
        assert expr == NormalizedExpr()

    def test_dict_with_expr_key(self):
        """Parse dict with 'expr' key uses value as expression."""
        expr = parse_expr_string({"expr": "orders.amount"})
        assert expr.primary_column == "orders.amount"

    def test_dict_missing_expr_returns_empty(self):
        """Parse dict without 'expr' key treats as empty."""
        expr = parse_expr_string({"other": "x"})
        assert expr == NormalizedExpr()

    def test_non_string_coerced_to_string(self):
        """Parse non-string input is coerced via str()."""
        expr = parse_expr_string(42)
        assert len(expr.add_values) == 1
        assert expr.add_values[0].value == 42.0

    def test_whitespace_only_returns_empty(self):
        """Parse whitespace-only string returns empty NormalizedExpr."""
        expr = parse_expr_string("   ")
        assert expr == NormalizedExpr()

    def test_single_negative_value_in_sub_values(self):
        """Parse single negative literal into sub_values."""
        expr = parse_expr_string("- 5")
        assert len(expr.sub_values) == 1
        assert expr.sub_values[0].value == 5.0

    def test_numeric_literal(self):
        """Parse standalone numeric literal."""
        expr = parse_expr_string("42")
        assert len(expr.add_values) == 1
        assert expr.add_values[0].value == 42.0


class TestStripAngleBrackets:
    """Tests for _strip_angle_brackets."""

    def test_string_with_brackets(self):
        """Strip angle brackets from string."""
        assert _strip_angle_brackets("<table1>") == "table1"

    def test_nested_dict(self):
        """Strip angle brackets in nested dict."""
        result = _strip_angle_brackets({"key": "<value>"})
        assert result == {"key": "value"}

    def test_list_values(self):
        """Strip angle brackets in list values."""
        result = _strip_angle_brackets(["<a>", "<b>"])
        assert result == ["a", "b"]

    def test_non_string(self):
        """Return non-string values unchanged."""
        assert _strip_angle_brackets(42) == 42


class TestAssignParamKeys:
    """Tests for assign_param_keys."""

    def test_sequential_keys(self):
        """Assign p1, p2, ...

        sequentially to filters.
        """
        fp1 = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op=">", value_type="integer")
        new_fp, new_hp, new_cte, idx = assign_param_keys([fp1, fp2], [])
        assert new_fp[0].param_key == "p1"
        assert new_fp[1].param_key == "p2"
        assert idx == 3

    def test_is_null_skipped(self):
        """Skip param_key assignment for IS NULL filters."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="is null", value_type="null")
        new_fp, _, _, idx = assign_param_keys([fp], [])
        assert new_fp[0].param_key == ""
        assert idx == 1

    def test_having_gets_keys(self):
        """Assign param_keys to having conditions."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
        )
        _, new_hp, _, idx = assign_param_keys([], [hp])
        assert new_hp[0].param_key == "p1"

    def test_cte_before_main(self):
        """CTE filters get lower param_key indices than main query."""
        cte_fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        main_fp = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", value_type="string")
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[cte_fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        new_fp, _, new_cte, _ = assign_param_keys([main_fp], [], [cte])
        assert new_cte[0].filters_param[0].param_key == "p1"
        assert new_fp[0].param_key == "p2"


class TestDecomposeBetweenFilters:
    """Tests for decompose_between_params."""

    def test_between_with_list_value(self):
        """Decompose BETWEEN with [low, high] raw_value."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="between",
            value_type="integer",
            raw_value=[10, 20],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert len(result.filters_param) == 2
        assert result.filters_param[0].op == ">="
        assert result.filters_param[0].raw_value == 10
        assert result.filters_param[1].op == "<="
        assert result.filters_param[1].raw_value == 20

    def test_non_between_unchanged(self):
        """Non-BETWEEN filters pass through unchanged."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert len(result.filters_param) == 1
        assert result.filters_param[0].op == "="


class TestNormalizeDateDiffRawValues:
    """Tests for normalize_date_diff_raw_values."""

    def test_plural_days_to_singular(self):
        """Plural 'days' in date_diff raw_value becomes 'day'."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            value_type="date_diff",
            raw_value={"unit": "days", "amount": 7},
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_date_diff_raw_values(intent)
        assert result.filters_param[0].raw_value["unit"] == "day"

    def test_plural_weeks_to_singular(self):
        """Plural 'weeks' becomes 'week'."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">=",
            value_type="date_diff",
            raw_value={"unit": "weeks", "amount": 2},
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_date_diff_raw_values(intent)
        assert result.filters_param[0].raw_value["unit"] == "week"

    def test_date_window_plural_normalized(self):
        """date_window with plural unit is also normalized."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">=",
            value_type="date_window",
            raw_value={"unit": "months", "offset": 1},
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_date_diff_raw_values(intent)
        assert result.filters_param[0].raw_value["unit"] == "month"

    def test_non_date_filter_unchanged(self):
        """Filters without date_window/date_diff pass through unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            value_type="string",
            raw_value="x",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_date_diff_raw_values(intent)
        assert result.filters_param[0].raw_value == "x"


class TestHasNonDefaultStructural:
    """Tests for has_non_default_structural."""

    def _make_template(self, structural_defaults):
        """Helper to create a minimal Template with all required
        fields."""
        return Template(
            id="t1",
            schema_hash="h",
            intent_signature=ConcreteIntent(
                intent_id="test",
                tables=["t"],
                grain="row_level",
                select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.a"))],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            ),
            intent_key="k1",
            tables_used=["t"],
            sql_param="SELECT 1",
            sql_display_param="SELECT 1",
            sql_fp="fp",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="sig",
            value_history=ValueHistory(param_values=[{}], questions=["q"], natural_language=["nl"]),
            stats=TemplateStats(),
            structural_defaults=structural_defaults,
        )

    def test_no_structural_defaults(self):
        """Return False when structural_defaults is empty."""
        tpl = self._make_template({})
        assert has_non_default_structural(tpl) is False

    def test_identity_values_only(self):
        """Return False when all values are identity (0, 1, 0.0,
        1.0)."""
        tpl = self._make_template({"s1": 1.0, "s2": 0})
        assert has_non_default_structural(tpl) is False

    def test_non_identity_value(self):
        """Return True when a non-identity value exists."""
        tpl = self._make_template({"s1": 2})
        assert has_non_default_structural(tpl) is True


class TestClassifyCteExpr:
    """Tests for _classify_cte_expr."""

    def test_passthrough(self):
        """Bare column is passthrough."""
        expr = NormalizedExpr.from_column("t.a")
        assert _classify_cte_expr(expr) == "passthrough"

    def test_aggregation(self):
        """COUNT(col) is aggregation."""
        expr = NormalizedExpr.from_agg("count", "t.a")
        assert _classify_cte_expr(expr) == "aggregation"

    def test_scalar(self):
        """Scalar function without agg is scalar."""
        expr = NormalizedExpr.from_column("t.a")
        expr = replace(expr, scalar_func="upper")
        assert _classify_cte_expr(expr) == "scalar"


class TestDeriveCteOutputColumns:
    """Tests for derive_cte_output_columns."""

    def test_passthrough_column(self):
        """Derive column name from passthrough expression."""
        sc = SelectCol(expr=NormalizedExpr.from_column("orders.customer_id"))
        result = derive_cte_output_columns([sc])
        assert result == ["customer_id"]

    def test_count_star(self):
        """Derive row_count from COUNT(*)."""
        expr = NormalizedExpr.from_agg("count", "*")
        sc = SelectCol(expr=expr)
        result = derive_cte_output_columns([sc])
        assert result == ["row_count"]

    def test_sum_column(self):
        """Derive sum_amount from SUM(orders.amount)."""
        expr = NormalizedExpr.from_agg("sum", "orders.amount")
        sc = SelectCol(expr=expr)
        result = derive_cte_output_columns([sc])
        assert result == ["sum_amount"]

    def test_duplicate_names_suffixed(self):
        """Duplicate derived names get numeric suffixes."""
        sc1 = SelectCol(expr=NormalizedExpr.from_column("t.id"))
        sc2 = SelectCol(expr=NormalizedExpr.from_column("t2.id"))
        result = derive_cte_output_columns([sc1, sc2])
        assert result[0] == "id"
        assert result[1] == "id_2"


class TestTagSingleExpr:
    """Tests for _tag_single_expr."""

    @pytest.fixture
    def num_schema(self):
        """Schema with numeric and non-numeric columns."""
        t = TableMetadata(
            name="t",
            columns={
                "amount": ColumnMetadata(
                    name="amount",
                    data_type="numeric",
                    role=ColumnRole.NUMERIC_MEASURE.value,
                ),
                "name": ColumnMetadata(name="name", data_type="varchar", role=ColumnRole.CATEGORICAL.value),
            },
            primary_key=[],
            foreign_keys=[],
        )
        return SchemaGraph(tables={"t": t}, join_paths_multi={}, schema_hash="test")

    def test_numeric_sets_is_numeric_true(self, num_schema):
        """_tag_single_expr sets is_numeric True for numeric column."""
        expr = NormalizedExpr.from_column("t.amount")
        result = _tag_single_expr(expr, num_schema)
        assert result.is_numeric is True

    def test_numeric_injects_offset(self, num_schema):
        """_tag_single_expr injects ExprValue(0.0) offset for numeric
        expression without add_values."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.amount"])])
        result = _tag_single_expr(expr, num_schema)
        assert len(result.add_values) == 1
        assert result.add_values[0].value == 0.0

    def test_numeric_preserves_existing_values(self, num_schema):
        """_tag_single_expr preserves existing add_values for numeric
        expression."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.amount"])],
            add_values=[ExprValue(value=5.0)],
        )
        result = _tag_single_expr(expr, num_schema)
        assert len(result.add_values) == 1
        assert result.add_values[0].value == 5.0

    def test_numeric_preserves_coefficient(self, num_schema):
        """_tag_single_expr preserves coefficient for numeric
        expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=3.5, multiply=["t.amount"])])
        result = _tag_single_expr(expr, num_schema)
        assert result.add_groups[0].coefficient == 3.5

    def test_non_numeric_sets_is_numeric_false(self, num_schema):
        """_tag_single_expr sets is_numeric False for non-numeric
        column."""
        expr = NormalizedExpr.from_column("t.name")
        result = _tag_single_expr(expr, num_schema)
        assert result.is_numeric is False

    def test_non_numeric_resets_coefficient(self, num_schema):
        """_tag_single_expr resets coefficient to 1.0 for non-numeric
        expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=2.5, multiply=["t.name"])])
        result = _tag_single_expr(expr, num_schema)
        assert result.add_groups[0].coefficient == 1.0

    def test_non_numeric_clears_coeff_param_key(self, num_schema):
        """_tag_single_expr clears coeff_param_key for non-numeric
        expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.name"], coeff_param_key="p1")])
        result = _tag_single_expr(expr, num_schema)
        assert result.add_groups[0].coeff_param_key == ""

    def test_non_numeric_clears_add_values(self, num_schema):
        """_tag_single_expr clears add_values for non-numeric
        expression."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.name"])],
            add_values=[ExprValue(value=10.0)],
        )
        result = _tag_single_expr(expr, num_schema)
        assert result.add_values == []

    def test_non_numeric_clears_sub_values(self, num_schema):
        """_tag_single_expr clears sub_values for non-numeric
        expression."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.name"])],
            sub_values=[ExprValue(value=5.0)],
        )
        result = _tag_single_expr(expr, num_schema)
        assert result.sub_values == []

    def test_non_numeric_preserves_multiply(self, num_schema):
        """_tag_single_expr preserves multiply list for non-numeric
        expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.name"])])
        result = _tag_single_expr(expr, num_schema)
        assert result.add_groups[0].multiply == ["t.name"]

    def test_non_numeric_preserves_agg_func(self, num_schema):
        """_tag_single_expr preserves agg_func for non-numeric count
        expression."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.name"], agg_func="count")])
        result = _tag_single_expr(expr, num_schema)
        assert result.add_groups[0].agg_func == "count"

    def test_skip_value_injection_numeric(self, num_schema):
        """_tag_single_expr with skip_value_injection tags numeric but
        skips ExprValue injection."""
        expr = NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.amount"])])
        result = _tag_single_expr(expr, num_schema, skip_value_injection=True)
        assert result.is_numeric is True
        assert result.add_values == []

    def test_skip_value_injection_preserves_existing_values(self, num_schema):
        """_tag_single_expr with skip_value_injection preserves pre-
        existing add_values."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.amount"])],
            add_values=[ExprValue(value=5.0)],
        )
        result = _tag_single_expr(expr, num_schema, skip_value_injection=True)
        assert result.is_numeric is True
        assert result.add_values == [ExprValue(value=5.0)]

    def test_skip_value_injection_non_numeric(self, num_schema):
        """_tag_single_expr with skip_value_injection still sanitizes
        non-numeric."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=2.0, multiply=["t.name"])],
            add_values=[ExprValue(value=10.0)],
        )
        result = _tag_single_expr(expr, num_schema, skip_value_injection=True)
        assert result.is_numeric is False
        assert result.add_groups[0].coefficient == 1.0
        assert result.add_values == []


class TestTagExprNumeric:
    """Tests for tag_expr_numeric."""

    @pytest.fixture
    def mixed_schema(self):
        """Schema with numeric and non-numeric columns."""
        t = TableMetadata(
            name="t",
            columns={
                "amount": ColumnMetadata(
                    name="amount",
                    data_type="numeric",
                    role=ColumnRole.NUMERIC_MEASURE.value,
                ),
                "name": ColumnMetadata(name="name", data_type="varchar", role=ColumnRole.CATEGORICAL.value),
            },
            primary_key=[],
            foreign_keys=[],
        )
        return SchemaGraph(tables={"t": t}, join_paths_multi={}, schema_hash="test")

    def test_tags_select_cols(self, mixed_schema):
        """tag_expr_numeric tags select column expressions."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.amount"])])),
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(coefficient=3.0, multiply=["t.name"])])),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.select_cols[0].expr.is_numeric is True
        assert result.select_cols[0].expr.add_groups[0].coefficient == 2.0
        assert result.select_cols[1].expr.is_numeric is False
        assert result.select_cols[1].expr.add_groups[0].coefficient == 1.0

    def test_tags_filter_exprs(self, mixed_schema):
        """tag_expr_numeric tags filter expressions."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=5.0, multiply=["t.name"])]),
                    op="=",
                    value_type="string",
                ),
            ],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.filters_param[0].left_expr.is_numeric is False
        assert result.filters_param[0].left_expr.add_groups[0].coefficient == 1.0

    def test_clears_non_numeric_values_in_intent(self, mixed_schema):
        """tag_expr_numeric clears add_values on non-numeric select
        expression."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(coefficient=1.0, multiply=["t.name"])],
                        add_values=[ExprValue(value=10.0)],
                    )
                ),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.select_cols[0].expr.add_values == []

    def test_numeric_agg_keeps_coefficient(self, mixed_schema):
        """tag_expr_numeric keeps coefficient for count aggregation
        (numeric result)."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.name"], agg_func="count")])
                ),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.select_cols[0].expr.is_numeric is True
        assert result.select_cols[0].expr.add_groups[0].coefficient == 2.0

    def test_filter_left_expr_skips_injection(self, mixed_schema):
        """tag_expr_numeric does not inject ExprValue offset into filter
        left_expr."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.amount"])]),
                    op=">",
                    value_type="number",
                ),
            ],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.filters_param[0].left_expr.is_numeric is True
        assert result.filters_param[0].left_expr.add_values == []

    def test_filter_right_expr_gets_injection(self, mixed_schema):
        """tag_expr_numeric injects ExprValue offset into filter
        right_expr when numeric."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["t.amount"])]),
                    op=">",
                    value_type="number",
                    right_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["t.amount"])]),
                ),
            ],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.filters_param[0].right_expr.is_numeric is True
        assert len(result.filters_param[0].right_expr.add_values) == 1
        assert result.filters_param[0].right_expr.add_values[0].value == 0.0

    def test_having_left_expr_skips_injection(self, mixed_schema):
        """tag_expr_numeric does not inject ExprValue offset into having
        left_expr."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[
                HavingParam(
                    left_expr=NormalizedExpr(
                        add_groups=[MulGroup(coefficient=2.0, multiply=["t.amount"], agg_func="sum")]
                    ),
                    op=">",
                    value_type="number",
                ),
            ],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.having_param[0].left_expr.is_numeric is True
        assert result.having_param[0].left_expr.add_values == []

    def test_cte_filter_left_expr_skips_injection(self, mixed_schema):
        """tag_expr_numeric does not inject ExprValue offset into CTE
        filter left_expr."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=2.0, multiply=["t.amount"])]),
                    op=">",
                    value_type="number",
                ),
            ],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = tag_expr_numeric(intent, mixed_schema)
        assert result.cte_steps[0].filters_param[0].left_expr.is_numeric is True
        assert result.cte_steps[0].filters_param[0].left_expr.add_values == []


class TestIsNontrivialGroup:
    """Tests for _is_nontrivial_group."""

    def test_trivial_group(self):
        """Bare column with coefficient 1.0 is trivial."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"])
        assert _is_nontrivial_group(g) is False

    def test_nontrivial_agg(self):
        """Group with agg_func is nontrivial."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], agg_func="count")
        assert _is_nontrivial_group(g) is True

    def test_nontrivial_coefficient(self):
        """Group with non-unit coefficient is nontrivial."""
        g = MulGroup(coefficient=2.0, multiply=["t.a"])
        assert _is_nontrivial_group(g) is True

    def test_nontrivial_scalar_func(self):
        """Group with scalar_func is nontrivial."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round")
        assert _is_nontrivial_group(g) is True

    def test_nontrivial_divide(self):
        """Group with divide list is nontrivial."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], divide=["t.b"])
        assert _is_nontrivial_group(g) is True


class TestAssignStructuralGroup:
    """Tests for _assign_structural_group."""

    def test_trivial_group_no_assignment(self):
        """Trivial group gets no structural param."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"])
        pv = {}
        idx = _assign_structural_group(g, 1, pv)
        assert idx == 1
        assert pv == {}

    def test_nontrivial_assigns_coeff_key(self):
        """Nontrivial group gets coefficient param key."""
        g = MulGroup(coefficient=2.5, multiply=["t.a"], agg_func="sum")
        pv = {}
        idx = _assign_structural_group(g, 1, pv)
        assert g.coeff_param_key == "s1"
        assert pv["s1"] == 2.5
        assert idx == 2

    def test_scalar_func_args(self):
        """Scalar func args get param keys."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round", scalar_func_args=[2])
        pv = {}
        idx = _assign_structural_group(g, 1, pv)
        assert pv["s1"] == 1.0
        assert pv["s2"] == 2
        assert idx == 3

    def test_non_numeric_skips_coeff(self):
        """Non-numeric group skips coefficient assignment."""
        g = MulGroup(coefficient=3.0, multiply=["t.a"], agg_func="count")
        pv = {}
        _assign_structural_group(g, 1, pv, is_numeric=False)
        assert g.coeff_param_key == ""
        assert "s1" not in pv


class TestAssignStructuralExpr:
    """Tests for _assign_structural_expr."""

    def test_add_values_get_keys(self):
        """ExprValue in add_values gets param key."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.a"])],
            add_values=[ExprValue(value=5.0)],
            is_numeric=True,
        )
        pv = {}
        _assign_structural_expr(expr, 1, pv)
        assert expr.add_values[0].param_key == "s1"
        assert pv["s1"] == 5.0

    def test_sub_values_get_keys(self):
        """ExprValue in sub_values gets param key."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.a"])],
            sub_values=[ExprValue(value=3.0)],
            is_numeric=True,
        )
        pv = {}
        _assign_structural_expr(expr, 1, pv)
        assert expr.sub_values[0].param_key == "s1"
        assert pv["s1"] == 3.0

    def test_nontrivial_group_and_values(self):
        """Both group coefficient and value get sequential keys."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=2.0, multiply=["t.a"], agg_func="sum")],
            add_values=[ExprValue(value=10.0)],
            is_numeric=True,
        )
        pv = {}
        idx = _assign_structural_expr(expr, 1, pv)
        assert pv["s1"] == 2.0
        assert pv["s2"] == 10.0
        assert idx == 3

    def test_non_numeric_skips_expr_values(self):
        """Non-numeric expr skips ExprValue param assignment for
        add_values and sub_values."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.a"])],
            add_values=[ExprValue(value=5.0)],
            sub_values=[ExprValue(value=3.0)],
            is_numeric=False,
        )
        pv = {}
        idx = _assign_structural_expr(expr, 1, pv)
        assert pv == {}
        assert expr.add_values[0].param_key == ""
        assert expr.sub_values[0].param_key == ""
        assert idx == 1

    def test_scalar_func_args_assigned_regardless(self):
        """Scalar func args get param keys even for non-numeric expr."""
        expr = NormalizedExpr(
            add_groups=[
                MulGroup(
                    coefficient=1.0,
                    multiply=["t.a"],
                    scalar_func="round",
                    scalar_func_args=[2],
                )
            ],
            is_numeric=False,
        )
        pv = {}
        idx = _assign_structural_expr(expr, 1, pv)
        assert pv["s1"] == 2
        assert idx == 2


class TestIsExprNumeric:
    """Tests for _is_expr_numeric."""

    @pytest.fixture
    def num_schema(self):
        """Schema with numeric and non-numeric columns."""
        t = TableMetadata(
            name="t",
            columns={
                "amount": ColumnMetadata(
                    name="amount",
                    data_type="numeric",
                    role=ColumnRole.NUMERIC_MEASURE.value,
                    value_type="number",
                ),
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    role=ColumnRole.CATEGORICAL.value,
                    value_type="string",
                ),
            },
            primary_key=[],
            foreign_keys=[],
        )
        return SchemaGraph(tables={"t": t}, join_paths_multi={}, schema_hash="test")

    def test_count_agg_is_numeric(self, num_schema):
        """COUNT agg returns numeric."""
        expr = NormalizedExpr.from_agg("count", "t.amount")
        assert _is_expr_numeric(expr, num_schema) is True

    def test_scalar_extract_is_numeric(self, num_schema):
        """EXTRACT scalar returns numeric."""
        expr = NormalizedExpr.from_column("t.amount")
        expr = replace(expr, scalar_func="extract")
        assert _is_expr_numeric(expr, num_schema) is True

    def test_numeric_column_by_value_type(self, num_schema):
        """Column with value_type number is numeric."""
        expr = NormalizedExpr.from_column("t.amount")
        assert _is_expr_numeric(expr, num_schema) is True

    def test_non_numeric_column(self, num_schema):
        """Column with value_type string is not numeric."""
        expr = NormalizedExpr.from_column("t.name")
        assert _is_expr_numeric(expr, num_schema) is False

    def test_multi_group_is_numeric(self, num_schema):
        """Multiple add/sub groups implies numeric when column
        unknown."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["unknown.col"])],
            sub_groups=[MulGroup(coefficient=1.0, multiply=["unknown.col2"])],
        )
        assert _is_expr_numeric(expr, num_schema) is True


class TestFillGroupDefaults:
    """Tests for _fill_group_defaults."""

    def test_round_gets_default_args(self):
        """Round scalar_func gets [2] default."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round")
        _fill_group_defaults(g)
        assert g.scalar_func_args == [2]

    def test_date_trunc_infers_unit(self):
        """date_trunc infers unit from column name."""
        g = MulGroup(coefficient=1.0, multiply=["t.created_year"], scalar_func="date_trunc")
        _fill_group_defaults(g)
        assert g.scalar_func_args == ["year"]

    def test_no_overwrite_existing_args(self):
        """Existing scalar_func_args are not overwritten."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round", scalar_func_args=[4])
        _fill_group_defaults(g)
        assert g.scalar_func_args == [4]

    def test_no_scalar_func_no_change(self):
        """Group without scalar_func unchanged."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"])
        _fill_group_defaults(g)
        assert g.scalar_func_args == []

    def test_inner_scalar_func_default(self):
        """Inner scalar func gets defaults."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], inner_scalar_func="round")
        _fill_group_defaults(g)
        assert g.inner_scalar_func_args == [2]


class TestFillExprDefaults:
    """Tests for _fill_expr_defaults."""

    def test_expr_scalar_func_default(self):
        """Expr-level scalar_func gets defaults."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.a"])],
            scalar_func="round",
        )
        _fill_expr_defaults(expr)
        assert expr.scalar_func_args == [2]

    def test_fills_child_groups(self):
        """Fills child MulGroup scalar_func defaults."""
        g = MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round")
        expr = NormalizedExpr(add_groups=[g])
        _fill_expr_defaults(expr)
        assert g.scalar_func_args == [2]

    def test_date_trunc_expr_level(self):
        """Expr-level date_trunc infers unit."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(coefficient=1.0, multiply=["t.order_month"])],
            scalar_func="date_trunc",
        )
        _fill_expr_defaults(expr)
        assert expr.scalar_func_args == ["month"]


class TestEnsureScalarFuncDefaults:
    """Tests for ensure_scalar_func_defaults."""

    def test_fills_main_select_defaults(self):
        """ensure_scalar_func_defaults fills select col defaults."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round")],
                    )
                )
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = ensure_scalar_func_defaults(intent)
        assert result.select_cols[0].expr.add_groups[0].scalar_func_args == [2]

    def test_fills_cte_defaults(self):
        """ensure_scalar_func_defaults fills CTE select col defaults."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(coefficient=1.0, multiply=["t.a"], scalar_func="round")],
                    )
                )
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = ensure_scalar_func_defaults(intent)
        assert result.cte_steps[0].select_cols[0].expr.add_groups[0].scalar_func_args == [2]

    def test_returns_same_intent(self):
        """ensure_scalar_func_defaults returns same intent object."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = ensure_scalar_func_defaults(intent)
        assert result is intent


class TestExtractStructuralParams:
    """Tests for extract_structural_params."""

    def test_limit_gets_param(self):
        """extract_structural_params assigns limit param key."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.a"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            limit=10,
        )
        result = extract_structural_params(intent)
        assert result.limit_param_key == "s1"
        assert result.param_values["s1"] == 10

    def test_no_limit_no_key(self):
        """extract_structural_params no limit_param_key when limit is
        None."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.a"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = extract_structural_params(intent)
        assert result.limit_param_key == ""

    def test_coefficient_in_select(self):
        """extract_structural_params assigns coefficient param in
        select."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(coefficient=2.0, multiply=["t.a"], agg_func="sum")],
                        is_numeric=True,
                    )
                )
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = extract_structural_params(intent)
        assert "s1" in result.param_values
        assert result.param_values["s1"] == 2.0


class TestPeelFunctionEdgeCases:
    """Edge-case tests for _peel_function."""

    def test_unclosed_paren_returns_none_and_original(self):
        """_peel_function returns (None, None, s) when parens are unclosed."""
        name, arg, body = _peel_function("SUM(col")
        assert name is None
        assert arg is None
        assert body == "SUM(col"

    def test_trailing_content_after_paren_returns_none(self):
        """_peel_function returns None when closing paren is not at end."""
        name, arg, body = _peel_function("SUM(a) + 1")
        assert name is None
        assert body == "SUM(a) + 1"

    def test_empty_string(self):
        """Return None for empty string."""
        name, arg, body = _peel_function("")
        assert name is None
        assert body == ""

    def test_function_no_args(self):
        """Function with no args returns empty body."""
        name, arg, body = _peel_function("NOW()")
        assert name == "NOW"
        assert body == ""

    def test_whitespace_preserved(self):
        """Whitespace inside function preserved."""
        name, arg, body = _peel_function("UPPER( table1.name )")
        assert name == "UPPER"
        assert body.strip() == "table1.name"


class TestSplitAdditiveEdgeCases:
    """Edge-case tests for _split_additive."""

    def test_single_term(self):
        """Single term returns [('+', term)]."""
        result = _split_additive("a")
        assert result == [("+", "a")]

    def test_multiple_additions(self):
        """Handle a + b + c."""
        result = _split_additive("a + b + c")
        assert len(result) == 3
        assert all(sign == "+" for sign, _ in result)


class TestSplitMultiplicativeEdgeCases:
    """Edge-case tests for _split_multiplicative."""

    def test_single_term(self):
        """Single term returns ([term], [])."""
        mul, div = _split_multiplicative("a")
        assert mul == ["a"]
        assert div == []


class TestParseTermEdgeCases:
    """Edge-case tests for _parse_term."""

    def test_negative_literal(self):
        """Parse negative numeric literal."""
        result = _parse_term("-5")
        assert isinstance(result, ExprValue)
        assert result.value == -5.0

    def test_float_literal(self):
        """Parse float literal."""
        result = _parse_term("3.14")
        assert isinstance(result, ExprValue)
        assert result.value == pytest.approx(3.14)


class TestDecomposeBetweenFiltersEdgeCases:
    """Edge-case tests for decompose_between_params."""

    def test_between_with_string_value(self):
        """Non-list raw_value between still decomposes into >= and
        <=."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="between",
            value_type="string",
            raw_value="invalid",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert len(result.filters_param) == 2
        assert result.filters_param[0].op == ">="
        assert result.filters_param[1].op == "<="

    def test_empty_filters(self):
        """Empty filters returns empty."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert result.filters_param == []


class TestAssignParamKeysEdgeCases:
    """Edge-case tests for assign_param_keys."""

    def test_empty_inputs(self):
        """Empty filters and having yield empty results."""
        fp, hp, cte, idx = assign_param_keys([], [])
        assert fp == []
        assert hp == []
        assert idx == 1

    def test_is_not_null_skipped(self):
        """IS NOT NULL filters skip param_key."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="is not null",
            value_type="null",
        )
        new_fp, _, _, idx = assign_param_keys([fp], [])
        assert new_fp[0].param_key == ""
        assert idx == 1

    def test_mixed_null_and_regular(self):
        """Mix of is null and regular filters."""
        fp1 = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="is null", value_type="null")
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", value_type="string")
        new_fp, _, _, idx = assign_param_keys([fp1, fp2], [])
        assert new_fp[0].param_key == ""
        assert new_fp[1].param_key == "p1"
        assert idx == 2

    def test_expr_vs_expr_filter_skips_param_key(self):
        """Filter with right_expr skips param_key assignment."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            value_type="number",
            right_expr=NormalizedExpr.from_column("t.b"),
        )
        new_fp, _, _, idx = assign_param_keys([fp], [])
        assert new_fp[0].param_key == ""
        assert idx == 1

    def test_expr_vs_expr_having_skips_param_key(self):
        """Having with right_expr skips param_key assignment."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.a"),
            op=">",
            value_type="number",
            right_expr=NormalizedExpr.from_agg("sum", "t.b"),
        )
        _, new_hp, _, idx = assign_param_keys([], [hp])
        assert new_hp[0].param_key == ""
        assert idx == 1

    def test_expr_vs_expr_cte_filter_skips_param_key(self):
        """CTE filter with right_expr skips param_key assignment."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            value_type="number",
            right_expr=NormalizedExpr.from_column("t.b"),
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        _, _, new_ctes, idx = assign_param_keys([], [], cte_steps=[cte])
        assert new_ctes[0].filters_param[0].param_key == ""
        assert idx == 1

    def test_expr_vs_expr_mixed_with_regular(self):
        """Expr-vs-expr filter followed by regular filter gets correct
        keys."""
        fp1 = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            value_type="number",
            right_expr=NormalizedExpr.from_column("t.b"),
        )
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", value_type="string")
        new_fp, _, _, idx = assign_param_keys([fp1, fp2], [])
        assert new_fp[0].param_key == ""
        assert new_fp[1].param_key == "p1"
        assert idx == 2


class TestIsDateOrIntervalExpr:
    """Tests for _is_date_or_interval_expr."""

    def test_current_date(self):
        """Recognize CURRENT_DATE."""
        assert _is_date_or_interval_expr("CURRENT_DATE") is True

    def test_current_date_minus_interval(self):
        """Recognize CURRENT_DATE - INTERVAL expression."""
        assert _is_date_or_interval_expr("CURRENT_DATE - INTERVAL '90 days'") is True

    def test_interval_only(self):
        """Recognize INTERVAL expression."""
        assert _is_date_or_interval_expr("INTERVAL '7 days'") is True

    def test_now(self):
        """Recognize NOW()."""
        assert _is_date_or_interval_expr("NOW()") is True

    def test_current_timestamp(self):
        """Recognize CURRENT_TIMESTAMP."""
        assert _is_date_or_interval_expr("CURRENT_TIMESTAMP") is True

    def test_table_column_rejected(self):
        """Reject table.column references."""
        assert _is_date_or_interval_expr("rental.rental_date") is False

    def test_plain_literal_rejected(self):
        """Reject plain literals."""
        assert _is_date_or_interval_expr("42") is False
        assert _is_date_or_interval_expr("foo") is False

    def test_empty_rejected(self):
        """Reject empty or None."""
        assert _is_date_or_interval_expr("") is False
        assert _is_date_or_interval_expr(None) is False


class TestParseIntentResponse:
    """Tests for parse_intent_response."""

    def test_valid_minimal_json(self):
        """Parses minimal valid JSON into RuntimeIntent."""
        raw = '{"tables": ["orders"], "grain": "row_level", "select_cols": ["orders.order_id"]}'
        result = parse_intent_response(raw, "list orders")
        assert result is not None
        assert result.tables == ["orders"]
        assert len(result.select_cols) == 1

    def test_returns_none_for_garbage(self):
        """Returns None for unparseable text."""
        assert parse_intent_response("not json at all", "q") is None

    def test_returns_none_for_empty(self):
        """Returns None for empty string."""
        assert parse_intent_response("", "q") is None

    def test_parses_filters(self):
        """Parses filters_param with left_expr and op."""
        raw = '{"tables": ["orders"], "select_cols": ["orders.order_id"], "filters_param": [{"left_expr": "orders.status", "op": "=", "value": "shipped", "value_type": "string"}]}'
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert len(result.filters_param) == 1
        assert result.filters_param[0].op == "="

    def test_parses_having(self):
        """Parses having_param with left_expr and op."""
        raw = '{"tables": ["orders"], "select_cols": ["orders.order_id"], "having_param": [{"left_expr": "count(orders.order_id)", "op": ">", "value": 5, "value_type": "integer"}]}'
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert len(result.having_param) == 1

    def test_parses_order_by(self):
        """Parses order_by_cols with direction."""
        raw = '{"tables": ["orders"], "select_cols": ["orders.order_id"], "order_by_cols": [{"expr": "orders.amount", "direction": "desc"}]}'
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert len(result.order_by_cols) == 1
        assert result.order_by_cols[0].direction.lower() == "desc"

    def test_tables_as_string(self):
        """Handles tables provided as a single string instead of
        list."""
        raw = '{"tables": "orders", "select_cols": ["orders.order_id"]}'
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.tables == ["orders"]

    def test_skips_filter_without_left_expr(self):
        """Filters with no left_expr are skipped."""
        raw = '{"tables": ["t"], "select_cols": ["t.x"], "filters_param": [{"op": "=", "value": "a"}]}'
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert len(result.filters_param) == 0

    def test_filter_bool_op_parsed(self):
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": ["t.x"],
                "filters_param": [
                    {
                        "left_expr": "t.a",
                        "op": "=",
                        "value": "1",
                        "value_type": "integer",
                    },
                    {
                        "left_expr": "t.b",
                        "op": ">",
                        "value": "2",
                        "value_type": "integer",
                        "bool_op": "OR",
                    },
                ],
            }
        )
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.filters_param[0].bool_op == "AND"
        assert result.filters_param[1].bool_op == "OR"

    def test_filter_bool_op_defaults_when_missing(self):
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": ["t.x"],
                "filters_param": [
                    {
                        "left_expr": "t.a",
                        "op": "=",
                        "value": "1",
                        "value_type": "integer",
                    },
                ],
            }
        )
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.filters_param[0].bool_op == "AND"

    def test_filter_group_parsed(self):
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": ["t.x"],
                "filters_param": [
                    {
                        "left_expr": "t.a",
                        "op": "=",
                        "value": "1",
                        "value_type": "integer",
                        "filter_group": 1,
                    },
                    {
                        "left_expr": "t.b",
                        "op": ">",
                        "value": "2",
                        "value_type": "integer",
                        "filter_group": 1,
                    },
                ],
            }
        )
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.filters_param[0].filter_group == 1
        assert result.filters_param[1].filter_group == 1

    def test_filter_group_defaults_to_none(self):
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": ["t.x"],
                "filters_param": [
                    {
                        "left_expr": "t.a",
                        "op": "=",
                        "value": "1",
                        "value_type": "integer",
                    },
                ],
            }
        )
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.filters_param[0].filter_group is None

    def test_having_bool_op_parsed(self):
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": ["t.x"],
                "having_param": [
                    {
                        "left_expr": "count(t.x)",
                        "op": ">",
                        "value": 5,
                        "value_type": "integer",
                    },
                    {
                        "left_expr": "sum(t.y)",
                        "op": "<",
                        "value": 10,
                        "value_type": "integer",
                        "bool_op": "OR",
                    },
                ],
            }
        )
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.having_param[0].bool_op == "AND"
        assert result.having_param[1].bool_op == "OR"

    def test_having_filter_group_parsed(self):
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": ["t.x"],
                "having_param": [
                    {
                        "left_expr": "count(t.x)",
                        "op": ">",
                        "value": 5,
                        "value_type": "integer",
                        "filter_group": 2,
                    },
                ],
            }
        )
        result = parse_intent_response(raw, "q")
        assert result is not None
        assert result.having_param[0].filter_group == 2

    def test_filter_preserves_date_interval_right_expr(self):
        """right_expr with date/interval expression is preserved, not cleared."""
        raw = json.dumps(
            {
                "tables": ["rental"],
                "select_cols": [{"expr": "rental.rental_id"}],
                "group_by_cols": [],
                "order_by_cols": [],
                "filters_param": [
                    {
                        "left_expr": "rental.rental_date",
                        "op": ">=",
                        "right_expr": "CURRENT_DATE - INTERVAL '90 days'",
                    }
                ],
                "having_param": [],
                "limit": None,
                "cte_steps": [],
                "natural_language": "rentals in last 90 days",
            }
        )
        result = parse_intent_response(raw, "rentals in last 90 days")
        assert result is not None
        assert len(result.filters_param) == 1
        fp = result.filters_param[0]
        assert fp.right_expr is not None

    def test_filter_clears_plain_literal_right_expr(self):
        """right_expr without table.column and not date/interval is cleared."""
        raw = json.dumps(
            {
                "tables": ["t"],
                "select_cols": [{"expr": "t.x"}],
                "group_by_cols": [],
                "order_by_cols": [],
                "filters_param": [
                    {
                        "left_expr": "t.a",
                        "op": "=",
                        "right_expr": "42",
                    }
                ],
                "having_param": [],
                "limit": None,
                "cte_steps": [],
                "natural_language": "test",
            }
        )
        result = parse_intent_response(raw, "test")
        assert result is not None
        assert len(result.filters_param) == 1
        assert result.filters_param[0].right_expr is None


class TestBuildCteOutputMetadata:
    """Tests for build_cte_output_metadata."""

    def test_passthrough_column(self, schema_graph):
        """Passthrough column inherits role and type from source."""
        sc = SelectCol(expr=NormalizedExpr.from_column("orders.amount"))
        out_cols = ["amount"]
        result = build_cte_output_metadata([sc], out_cols, schema_graph)
        assert "amount" in result
        assert result["amount"].data_type == "numeric"

    def test_aggregation_column(self, schema_graph):
        """Aggregation column gets numeric_measure role."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id"))
        out_cols = ["order_count"]
        result = build_cte_output_metadata([sc], out_cols, schema_graph)
        assert "order_count" in result
        meta = result["order_count"]
        assert meta.role == "numeric_measure"
        assert meta.data_type == "integer"

    def test_empty_inputs(self, schema_graph):
        """Returns empty dict for empty inputs."""
        assert build_cte_output_metadata([], [], schema_graph) == {}

    def test_output_shorter_than_select(self, schema_graph):
        """Stops at output_columns length when shorter than
        select_cols."""
        sc1 = SelectCol(expr=NormalizedExpr.from_column("orders.amount"))
        sc2 = SelectCol(expr=NormalizedExpr.from_column("orders.status"))
        result = build_cte_output_metadata([sc1, sc2], ["amount"], schema_graph)
        assert len(result) == 1

    def test_avg_aggregation_type(self, schema_graph):
        """AVG aggregation produces numeric data type."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("avg", "orders.amount"))
        out_cols = ["avg_amount"]
        result = build_cte_output_metadata([sc], out_cols, schema_graph)
        assert result["avg_amount"].data_type == "numeric"


class TestDecomposeBetweenHaving:
    """Tests for decompose_between_params on having_param."""

    def test_having_between_with_list(self):
        """BETWEEN having with [low, high] decomposes into >= and <=."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op="between",
            value_type="integer",
            raw_value=[5, 10],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="grouped",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert len(result.having_param) == 2
        assert result.having_param[0].op == ">="
        assert result.having_param[0].raw_value == 5
        assert result.having_param[1].op == "<="
        assert result.having_param[1].raw_value == 10

    def test_having_non_between_unchanged(self):
        """Non-BETWEEN having passes through unchanged."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            value_type="integer",
            raw_value=5,
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="grouped",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert len(result.having_param) == 1
        assert result.having_param[0].op == ">"

    def test_cte_having_between_decomposed(self):
        """BETWEEN having in a CTE step is also decomposed."""
        cte_hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.amount"),
            op="between",
            value_type="number",
            raw_value=[100, 500],
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[cte_hp],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        result = decompose_between_params(intent)
        assert len(result.cte_steps[0].having_param) == 2
        assert result.cte_steps[0].having_param[0].op == ">="
        assert result.cte_steps[0].having_param[1].op == "<="


class TestParseBetweenRawValue:
    """Tests for _parse_between_raw_value."""

    def test_list_of_two(self):
        """Two-element list returns (low, high)."""
        assert _parse_between_raw_value([10, 20]) == (10, 20)

    def test_string_with_and(self):
        """String with ' AND ' separator splits correctly."""
        assert _parse_between_raw_value("10 AND 20") == ("10", "20")

    def test_string_with_comma(self):
        """String with comma separator splits correctly."""
        assert _parse_between_raw_value("2020-01-01, 2020-12-31") == (
            "2020-01-01",
            "2020-12-31",
        )

    def test_string_with_dash_separator(self):
        """String with ' - ' separator splits correctly."""
        assert _parse_between_raw_value("5 - 10") == ("5", "10")

    def test_single_element_list_returns_none(self):
        """Single-element list returns None."""
        assert _parse_between_raw_value([42]) is None

    def test_integer_returns_none(self):
        """Plain integer returns None."""
        assert _parse_between_raw_value(42) is None

    def test_unparseable_string_returns_none(self):
        """Unsplittable string returns None."""
        assert _parse_between_raw_value("invalid") is None


class TestNormalizeInFilterRawValues:
    """Tests for normalize_in_raw_values."""

    def test_string_to_list_filter(self):
        """String IN value gets parsed to a list."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="in",
            value_type="string",
            raw_value="R, PG-13",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.filters_param[0].raw_value == ["R", "PG-13"]

    def test_quoted_string_to_list(self):
        """Quoted string IN value gets parsed correctly."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="in",
            value_type="string",
            raw_value="'R','PG-13','NC-17'",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.filters_param[0].raw_value == ["R", "PG-13", "NC-17"]

    def test_list_value_unchanged(self):
        """Already-list raw_value is not modified."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="in",
            value_type="string",
            raw_value=["R", "PG"],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.filters_param[0].raw_value == ["R", "PG"]

    def test_non_in_op_unchanged(self):
        """Non-IN ops are not touched even with string raw_value."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            value_type="string",
            raw_value="R, PG",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.filters_param[0].raw_value == "R, PG"

    def test_not_in_string_to_list(self):
        """NOT IN string value also gets parsed."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="not in",
            value_type="string",
            raw_value="R, G",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.filters_param[0].raw_value == ["R", "G"]

    def test_single_element_string_unchanged(self):
        """Single-element string is not split into a list."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="in",
            value_type="string",
            raw_value="PG-13",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.filters_param[0].raw_value == "PG-13"

    def test_cte_in_filter_normalised(self):
        """CTE step IN string value gets parsed too."""
        cte_fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="in",
            value_type="string",
            raw_value="A, B, C",
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[cte_fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        result = normalize_in_raw_values(intent)
        assert result.cte_steps[0].filters_param[0].raw_value == ["A", "B", "C"]


class TestExtractColumnsFromExpr:
    """Tests for extract_columns_from_expr."""

    def test_bare_column(self):
        """extract_columns_from_expr returns bare column."""
        expr = NormalizedExpr.from_column("orders.amount")
        cols = extract_columns_from_expr(expr)
        assert "orders.amount" in cols

    def test_function_wrapped(self):
        """extract_columns_from_expr strips function wrappers."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["UPPER(customers.name)"])])
        cols = extract_columns_from_expr(expr)
        assert "customers.name" in cols

    def test_star_excluded(self):
        """extract_columns_from_expr excludes *."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(*)"])])
        cols = extract_columns_from_expr(expr)
        assert "*" not in cols

    def test_multiple_groups(self):
        """extract_columns_from_expr handles add and sub groups."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.a"])],
            sub_groups=[MulGroup(multiply=["t.b"])],
        )
        cols = extract_columns_from_expr(expr)
        assert "t.a" in cols
        assert "t.b" in cols

    def test_only_add_values_returns_empty(self):
        """extract_columns_from_expr with only add_values returns empty list."""
        expr = NormalizedExpr(add_groups=[], sub_groups=[], add_values=[ExprValue(value=1.0)])
        cols = extract_columns_from_expr(expr)
        assert cols == []

    def test_nested_parens_stripped_to_column(self):
        """extract_columns_from_expr strips nested parens to get inner column."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["((t.col))"])])
        cols = extract_columns_from_expr(expr)
        assert "t.col" in cols


class TestRepairMisclassifiedDateDiff:
    """Tests for repair_misclassified_date_diff."""

    def test_plain_column_converted_to_date_window(self):
        """date_diff with a plain column left_expr becomes date_window."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("rental.rental_date"),
            op=">=",
            value_type="date_diff",
            raw_value={"unit": "day", "amount": 90},
        )
        intent = RuntimeIntent(
            tables=["rental"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            natural_language="test",
        )
        result = repair_misclassified_date_diff(intent)
        repaired = result.filters_param[0]
        assert repaired.value_type == "date_window"
        assert repaired.raw_value == {"unit": "day", "offset": 90}

    def test_subtraction_expr_stays_date_diff(self):
        """date_diff with a subtraction left_expr is not reclassified."""
        fp = FilterParam(
            left_expr=NormalizedExpr(
                add_groups=[MulGroup(multiply=["rental.return_date"])],
                sub_groups=[MulGroup(multiply=["rental.rental_date"])],
            ),
            op=">",
            value_type="date_diff",
            raw_value={"unit": "day", "amount": 7},
        )
        intent = RuntimeIntent(
            tables=["rental"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            natural_language="test",
        )
        result = repair_misclassified_date_diff(intent)
        assert result.filters_param[0].value_type == "date_diff"

    def test_non_date_diff_unchanged(self):
        """Non-date_diff filters pass through unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.col"),
            op="=",
            value_type="string",
            raw_value="hello",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            natural_language="test",
        )
        result = repair_misclassified_date_diff(intent)
        assert result.filters_param[0].value_type == "string"

    def test_cte_filters_also_repaired(self):
        """date_diff in CTE filters is also reclassified."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.order_date"),
            op=">=",
            value_type="date_diff",
            raw_value={"unit": "month", "amount": 6},
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
            natural_language="test",
        )
        result = repair_misclassified_date_diff(intent)
        repaired = result.cte_steps[0].filters_param[0]
        assert repaired.value_type == "date_window"
        assert repaired.raw_value == {"unit": "month", "offset": 6}
