"""Tests for pipeline module: shape_distance, negative_penalty, helpers."""

import csv
from types import SimpleNamespace
from unittest.mock import patch

import pytest as _pt

from text2sql.config import PolicyConfig
from text2sql.contracts_base import SQLShape, TemplateStats
from text2sql.contracts_core import (
    ConcreteIntent,
    NormalizedExpr,
    RejectedTemplate,
    RejectedValueHistory,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
    Template,
    ValueHistory,
)
from text2sql.pipeline import (
    _colmap_penalty,
    _create_query_plan,
    _extract_column_headers,
    _most_frequent_natural_language,
    _negative_penalty,
    _record_negative,
    _record_negative_colmap,
    _run_sql_validation_cascade,
    _shape_distance,
    check_and_handle_hard_block,
    check_template_reuse,
    compute_final_metrics,
    confirm_intent_with_user,
    display_final_results,
    generate_join_candidates,
    handle_user_feedback,
    load_pipeline_resources,
    save_result_csv,
)


class TestShapeDistance:
    """Tests for shape_distance."""

    def test_identical_shapes(self):
        """shape_distance of identical shapes is 0."""
        a = SQLShape(num_joins=1, has_group_by=True, has_agg=True)
        assert _shape_distance(a, a) == 0.0

    def test_different_group_by(self):
        """shape_distance penalizes group_by mismatch."""
        a = SQLShape(num_joins=0, has_group_by=True, has_agg=False)
        b = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        d = _shape_distance(a, b)
        assert d > 0.0
        assert d <= 1.0

    def test_different_agg(self):
        """shape_distance penalizes agg mismatch."""
        a = SQLShape(num_joins=0, has_group_by=False, has_agg=True)
        b = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        d = _shape_distance(a, b)
        assert d > 0.0

    def test_join_distance_scales(self):
        """shape_distance increases with join count difference."""
        a = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        b = SQLShape(num_joins=4, has_group_by=False, has_agg=False)
        d = _shape_distance(a, b)
        assert d > 0.0

    def test_symmetric(self):
        """shape_distance is symmetric."""
        a = SQLShape(num_joins=1, has_group_by=True, has_agg=False)
        b = SQLShape(num_joins=3, has_group_by=False, has_agg=False)
        assert abs(_shape_distance(a, b) - _shape_distance(b, a)) < 1e-9

    def test_max_distance_is_bounded(self):
        """shape_distance is bounded by 1.0."""
        a = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        b = SQLShape(num_joins=100, has_group_by=True, has_agg=True)
        assert _shape_distance(a, b) <= 1.0


class TestNegativePenalty:
    """Tests for negative_penalty."""

    def test_no_memory_zero_penalty(self):
        """negative_penalty returns 0 with empty store."""
        store = {}
        result = _negative_penalty(store, "key", ["sig"], "fp")
        assert result == 0.0

    def test_accumulates_by_intent_key(self):
        """negative_penalty accumulates from by_intent_key."""
        store = {
            "negative_memory": {
                "by_intent_key": {"key1": {"rejects": 2}},
                "by_join_sig": {},
                "by_sql_fp": {},
            }
        }
        result = _negative_penalty(store, "key1", [], "fp")
        expected = 2 * PolicyConfig.PEN_BY_INTENT_KEY
        assert abs(result - expected) < 1e-9

    def test_capped_at_penalty_cap(self):
        """negative_penalty is capped at PolicyConfig.PENALTY_CAP."""
        store = {
            "negative_memory": {
                "by_intent_key": {"key1": {"rejects": 999}},
                "by_join_sig": {},
                "by_sql_fp": {},
            }
        }
        result = _negative_penalty(store, "key1", [], "fp")
        assert result == PolicyConfig.PENALTY_CAP


class TestMostFrequentNaturalLanguage:
    """Tests for _most_frequent_natural_language."""

    def test_returns_most_common(self):
        """_most_frequent_natural_language returns most frequent
        string."""
        vh = ValueHistory(
            param_values=[{}, {}, {}],
            questions=["q1", "q2", "q3"],
            natural_language=["total sales", "total sales", "revenue"],
        )
        assert _most_frequent_natural_language(vh) == "total sales"

    def test_empty_returns_empty(self):
        """_most_frequent_natural_language returns empty for empty
        list."""
        vh = ValueHistory(param_values=[], questions=[], natural_language=[])
        assert _most_frequent_natural_language(vh) == ""

    def test_skips_empty_strings(self):
        """_most_frequent_natural_language skips empty strings."""
        vh = ValueHistory(
            param_values=[{}, {}],
            questions=["q1", "q2"],
            natural_language=["", "actual text"],
        )
        assert _most_frequent_natural_language(vh) == "actual text"


class TestExtractColumnHeaders:
    """Tests for _extract_column_headers."""

    def test_extracts_aliases(self):
        """_extract_column_headers extracts AS aliases."""
        sql = "SELECT customers.name AS customer_name, SUM(orders.amount) AS total FROM orders JOIN customers"
        headers = _extract_column_headers(sql)
        assert "customer_name" in headers
        assert "total" in headers

    def test_extracts_bare_columns(self):
        """_extract_column_headers extracts table.column format."""
        sql = "SELECT orders.order_id, orders.amount FROM orders"
        headers = _extract_column_headers(sql)
        assert "order_id" in headers
        assert "amount" in headers

    def test_no_select_returns_empty(self):
        """_extract_column_headers returns empty for non-SELECT."""
        headers = _extract_column_headers("INSERT INTO t VALUES (1)")
        assert headers == []

    def test_empty_sql_returns_empty(self):
        """_extract_column_headers returns empty for empty string."""
        assert _extract_column_headers("") == []

    def test_select_from_no_match_returns_empty(self):
        """_extract_column_headers returns empty when SELECT...FROM not found."""
        headers = _extract_column_headers("SELECT")
        assert headers == []

    def test_handles_nested_parens(self):
        """_extract_column_headers handles nested parentheses in
        functions."""
        sql = "SELECT ROUND(SUM(orders.amount), 2) AS rounded_total FROM orders"
        headers = _extract_column_headers(sql)
        assert "rounded_total" in headers

    def test_multiple_columns(self):
        """_extract_column_headers handles multiple columns."""
        sql = "SELECT a.x AS col1, b.y AS col2, c.z AS col3 FROM a"
        headers = _extract_column_headers(sql)
        assert len(headers) == 3


class TestRecordNegative:
    """Tests for record_negative."""

    def test_creates_negative_memory(self):
        """record_negative creates negative_memory structure."""
        store = {}
        _record_negative(store, "ikey1", ["a->b"], "fp1", "bad query")
        assert "negative_memory" in store
        assert store["negative_memory"]["by_intent_key"]["ikey1"]["rejects"] == 1

    def test_increments_rejects(self):
        """record_negative increments rejects on subsequent calls."""
        store = {}
        _record_negative(store, "ikey1", ["a->b"], "fp1", "reason1")
        _record_negative(store, "ikey1", ["a->b"], "fp1", "reason2")
        assert store["negative_memory"]["by_intent_key"]["ikey1"]["rejects"] == 2

    def test_records_category(self):
        """record_negative records rejection category."""
        store = {}
        _record_negative(store, "ikey1", ["a->b"], "fp1", "bad query", rejection_category="schema")
        cats = store["negative_memory"]["by_intent_key"]["ikey1"]["categories"]
        assert cats["schema"] == 1

    def test_stores_reasons(self):
        """record_negative stores reason list."""
        store = {}
        _record_negative(store, "ikey1", [], "fp1", "first reason")
        reasons = store["negative_memory"]["by_intent_key"]["ikey1"]["reasons"]
        assert "first reason" in reasons


class TestRecordNegativeColmap:
    """Tests for record_negative_colmap."""

    def test_creates_colmap_entry(self):
        """record_negative_colmap creates colmap entry."""
        store = {}
        _record_negative_colmap(store, "sig1", "bad mapping")
        assert store["negative_memory"]["by_colmap_sig"]["sig1"]["rejects"] == 1

    def test_increments_colmap_rejects(self):
        """record_negative_colmap increments rejects."""
        store = {}
        _record_negative_colmap(store, "sig1", "reason1")
        _record_negative_colmap(store, "sig1", "reason2")
        assert store["negative_memory"]["by_colmap_sig"]["sig1"]["rejects"] == 2

    def test_records_colmap_category(self):
        """record_negative_colmap records category."""
        store = {}
        _record_negative_colmap(store, "sig1", "bad", rejection_category="type_mismatch")
        cats = store["negative_memory"]["by_colmap_sig"]["sig1"]["categories"]
        assert cats["type_mismatch"] == 1


class TestColmapPenalty:
    """Tests for colmap_penalty."""

    def test_no_sig_returns_zero(self):
        """colmap_penalty returns 0 for empty sig."""
        assert _colmap_penalty({}, "") == 0.0

    def test_no_rejects_returns_zero(self):
        """colmap_penalty returns 0 for sig with no rejects."""
        assert _colmap_penalty({"negative_memory": {"by_colmap_sig": {}}}, "sig1") == 0.0

    def test_penalty_from_rejects(self):
        """colmap_penalty computes penalty from rejection count."""
        store = {}
        _record_negative_colmap(store, "sig1", "bad")
        pen = _colmap_penalty(store, "sig1")
        assert pen > 0.0

    def test_penalty_capped(self):
        """colmap_penalty is capped at PENALTY_CAP."""
        store = {}
        for i in range(100):
            _record_negative_colmap(store, "sig1", f"reason_{i}")
        pen = _colmap_penalty(store, "sig1")
        assert pen <= PolicyConfig.PENALTY_CAP


class TestCreateQueryPlan:
    """Tests for create_query_plan."""

    def test_creates_plan_with_chosen_sig(self):
        """create_query_plan populates chosen_join_path_signature."""
        cmap = {"J01": ["a->b", "b->c"], "J02": ["x->y"]}
        plan = _create_query_plan("SELECT 1", "J01", cmap)
        assert plan.sql == "SELECT 1"
        assert plan.chosen_join_candidate_id == "J01"
        assert plan.chosen_join_path_signature == ["a->b", "b->c"]

    def test_unknown_join_id(self):
        """create_query_plan returns empty sig for unknown join ID."""
        cmap = {"J01": ["a->b"]}
        plan = _create_query_plan("SELECT 1", "UNKNOWN", cmap)
        assert plan.chosen_join_path_signature == []

    def test_empty_cmap(self):
        """create_query_plan handles empty candidate map."""
        plan = _create_query_plan("SELECT 1", "", {})
        assert plan.chosen_join_path_signature == []


class TestSaveResultCsv:
    """Tests for save_result_csv."""

    def test_skips_scalar_grain(self, tmp_path, monkeypatch):
        """save_result_csv skips saving for scalar grain."""
        monkeypatch.chdir(tmp_path)
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        save_result_csv([(1,)], intent, "SELECT 1")
        assert not (tmp_path / "results.csv").exists()

    def test_writes_csv_with_headers(self, tmp_path, monkeypatch):
        """save_result_csv writes CSV with column headers."""
        monkeypatch.chdir(tmp_path)
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            sql_display_param="SELECT t.name AS customer_name FROM t",
        )
        save_result_csv([("Alice",), ("Bob",)], intent, "SELECT t.name FROM t")
        out = tmp_path / "results.csv"
        assert out.exists()
        with open(out, encoding="utf-8") as f:
            reader = csv.reader(f)
            rows = list(reader)
        assert rows[0] == ["customer_name"]
        assert len(rows) == 3

    def test_writes_without_headers_when_none(self, tmp_path, monkeypatch):
        """save_result_csv writes data only when no headers
        extracted."""
        monkeypatch.chdir(tmp_path)
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        save_result_csv([(1, 2)], intent, "INVALID SQL")
        out = tmp_path / "results.csv"
        assert out.exists()


class TestShapeDistanceEdgeCases:
    """Edge-case tests for shape_distance."""

    def test_zero_vs_zero(self):
        """shape_distance of default shapes is 0."""
        a = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        assert _shape_distance(a, a) == 0.0

    def test_max_join_difference_capped(self):
        """shape_distance caps join difference contribution."""
        a = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        b = SQLShape(num_joins=100, has_group_by=False, has_agg=False)
        d = _shape_distance(a, b)
        assert abs(d - 1.0 / 3.0) < 1e-9

    def test_all_different(self):
        """shape_distance max when all dimensions differ."""
        a = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        b = SQLShape(num_joins=10, has_group_by=True, has_agg=True)
        assert abs(_shape_distance(a, b) - 1.0) < 1e-9


class TestNegativePenaltyEdgeCases:
    """Edge-case tests for negative_penalty."""

    def test_join_sig_penalty(self):
        """negative_penalty accumulates from by_join_sig."""
        store = {}
        _record_negative(store, "k", ["a->b"], "fp", "reason")
        pen = _negative_penalty(store, "other_key", ["a->b"], "other_fp")
        assert pen >= PolicyConfig.PEN_BY_JOIN_SIG

    def test_sql_fp_penalty(self):
        """negative_penalty accumulates from by_sql_fp."""
        store = {}
        _record_negative(store, "k", [], "fp1", "reason")
        pen = _negative_penalty(store, "other_key", [], "fp1")
        assert pen >= PolicyConfig.PEN_BY_SQL_FP

    def test_combines_multiple_sources(self):
        """negative_penalty sums penalties from all sources."""
        store = {}
        _record_negative(store, "k", ["a->b"], "fp1", "reason")
        pen = _negative_penalty(store, "k", ["a->b"], "fp1")
        expected = PolicyConfig.PEN_BY_INTENT_KEY + PolicyConfig.PEN_BY_JOIN_SIG + PolicyConfig.PEN_BY_SQL_FP
        assert abs(pen - min(expected, PolicyConfig.PENALTY_CAP)) < 1e-9


class TestRecordNegativeEdgeCases:
    """Edge-case tests for record_negative."""

    def test_records_join_sig(self):
        """record_negative records in by_join_sig bucket."""
        store = {}
        _record_negative(store, "k", ["a->b"], "fp", "reason")
        js_key = next(iter(store["negative_memory"]["by_join_sig"]))
        assert store["negative_memory"]["by_join_sig"][js_key]["rejects"] == 1

    def test_records_sql_fp(self):
        """record_negative records in by_sql_fp bucket."""
        store = {}
        _record_negative(store, "k", [], "fp1", "reason")
        assert store["negative_memory"]["by_sql_fp"]["fp1"]["rejects"] == 1

    def test_multiple_categories(self):
        """record_negative tracks multiple categories."""
        store = {}
        _record_negative(store, "k", [], "fp", "r1", rejection_category="schema")
        _record_negative(store, "k", [], "fp", "r2", rejection_category="semantic")
        cats = store["negative_memory"]["by_intent_key"]["k"]["categories"]
        assert cats["schema"] == 1
        assert cats["semantic"] == 1


class TestExtractColumnHeadersEdgeCases:
    """Edge-case tests for _extract_column_headers."""

    def test_star_select(self):
        """_extract_column_headers handles SELECT *."""
        headers = _extract_column_headers("SELECT * FROM t")
        assert headers == ["*"]

    def test_count_star(self):
        """_extract_column_headers handles COUNT(*)."""
        headers = _extract_column_headers("SELECT COUNT(*) AS cnt FROM t")
        assert "cnt" in headers

    def test_expression_without_alias(self):
        """_extract_column_headers falls back to expression name."""
        headers = _extract_column_headers("SELECT 1+1 FROM t")
        assert len(headers) == 1


class TestMostFrequentNaturalLanguageEdgeCases:
    """Edge-case tests for _most_frequent_natural_language."""

    def test_tie_returns_first(self):
        """_most_frequent_natural_language returns first on tie."""
        vh = ValueHistory(
            param_values=[{}, {}],
            questions=["q1", "q2"],
            natural_language=["alpha", "beta"],
        )
        result = _most_frequent_natural_language(vh)
        assert result in ("alpha", "beta")

    def test_all_empty_returns_empty(self):
        """_most_frequent_natural_language returns empty when all
        entries are empty."""
        vh = ValueHistory(
            param_values=[{}],
            questions=["q"],
            natural_language=[""],
        )
        assert _most_frequent_natural_language(vh) == ""


def _make_pipeline_template(
    tid="T0001",
    trust_level=1,
    intent_key="test_key",
    accept=1,
    reject=0,
) -> Template:
    """Create a minimal Template for pipeline tests."""
    return Template(
        id=tid,
        schema_hash="test_hash",
        intent_signature=ConcreteIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        ),
        intent_key=intent_key,
        tables_used=["orders"],
        sql_param="SELECT order_id FROM orders",
        sql_display_param="SELECT order_id FROM orders",
        sql_fp="test_fp",
        shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
        colmap_sig="test_sig",
        value_history=ValueHistory(param_values=[{}], questions=["test"], natural_language=["test"]),
        stats=TemplateStats(accept=accept, reject=reject),
        trust_level=trust_level,
    )


def _make_pipeline_rejected(
    rid="R0001",
    intent_key="rej_key",
    categories=None,
    reasons=None,
) -> RejectedTemplate:
    """Create a minimal RejectedTemplate for pipeline tests."""
    return RejectedTemplate(
        id=rid,
        schema_hash="test_hash",
        intent_signature=ConcreteIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        ),
        intent_key=intent_key,
        tables_used=["orders"],
        sql_param="SELECT order_id FROM orders",
        sql_display_param="SELECT order_id FROM orders",
        sql_fp="rej_fp",
        shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
        colmap_sig="test_sig",
        value_history=RejectedValueHistory(
            param_values=[{}],
            questions=["test"],
            natural_language=["test"],
            rejection_reasons=reasons or ["test reason"],
            rejection_categories=categories or ["test_category"],
        ),
    )


class TestCheckTemplateReuse:
    """Tests for check_template_reuse."""

    @patch("text2sql.pipeline.find_trusted_template_match", return_value=None)
    def test_no_match_returns_none_type(self, mock_skip):
        """No match returns reuse_type='none'."""
        result = check_template_reuse("random question", {})
        assert result.reuse_type == "none"
        assert result.best_template is None

    @patch("text2sql.pipeline.find_trusted_template_match")
    def test_exact_match_returns_direct_reuse(self, mock_skip):
        """Exact match returns reuse_type='direct_reuse' with score
        1.0."""
        tmpl = _make_pipeline_template(trust_level=2)
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        mock_skip.return_value = (intent, tmpl)
        result = check_template_reuse("test question", {"T0001": tmpl})
        assert result.reuse_type == "direct_reuse"
        assert result.similarity_score == 1.0
        assert result.best_template.id == "T0001"


class TestCheckAndHandleHardBlock:
    """Tests for check_and_handle_hard_block."""

    def test_no_rejected_no_block(self):
        """Empty rejected dict produces no block."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        override, hb_rt, matched_rt, proceed = check_and_handle_hard_block({}, "key1", intent)
        assert override is False
        assert proceed is True

    @patch("text2sql.pipeline.ask_user_choice", return_value="y")
    def test_hard_block_user_overrides(self, mock_choice):
        """User override on hard block returns override=True and
        proceed=True."""
        rt = _make_pipeline_rejected(
            categories=["wrong_intent", "wrong_intent"],
            reasons=["reason1", "reason2"],
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        override, hb_rt, matched_rt, proceed = check_and_handle_hard_block({"R0001": rt}, "rej_key", intent)
        assert proceed is True
        assert override is True

    @patch("text2sql.pipeline.ask_user_choice", return_value="n")
    def test_hard_block_user_declines(self, mock_choice):
        """User decline on hard block returns proceed=False."""
        rt = _make_pipeline_rejected(
            categories=["wrong_intent", "wrong_intent"],
            reasons=["reason1", "reason2"],
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        override, hb_rt, matched_rt, proceed = check_and_handle_hard_block({"R0001": rt}, "rej_key", intent)
        assert proceed is False


class TestLoadPipelineResources:
    """Tests for load_pipeline_resources."""

    @patch("text2sql.pipeline.EngineConfig")
    def test_missing_api_token(self, mock_ec):
        """Missing API_TOKEN raises RuntimeError."""
        mock_ec.API_TOKEN = ""
        with _pt.raises(RuntimeError, match="OPENAI_API_KEY"):
            load_pipeline_resources(schema="s", store="st", templates="t", rejected="r", schema_terms=set())

    @patch("text2sql.pipeline.EngineConfig")
    @patch("text2sql.pipeline.get_dialect")
    @patch("sqlalchemy.create_engine")
    def test_missing_schema_raises(self, mock_ce, mock_gd, mock_ec):
        """None schema raises RuntimeError."""
        mock_ec.API_TOKEN = "key"
        mock_ec.TYPE = "postgresql"
        mock_ec.RUNTIME = SimpleNamespace(db_url=lambda: "postgresql://localhost/db")
        mock_gd.return_value = SimpleNamespace()
        with _pt.raises(RuntimeError, match="Schema"):
            load_pipeline_resources(schema=None, store={}, templates={}, rejected={}, schema_terms=set())

    @patch("text2sql.pipeline.EngineConfig")
    @patch("text2sql.pipeline.get_dialect")
    @patch("sqlalchemy.create_engine")
    def test_success_returns_tuple(self, mock_ce, mock_gd, mock_ec):
        """Valid inputs return 7-element tuple."""
        mock_ec.API_TOKEN = "key"
        mock_ec.TYPE = "postgresql"
        mock_ec.RUNTIME = SimpleNamespace(db_url=lambda: "postgresql://localhost/db")
        mock_gd.return_value = SimpleNamespace()
        mock_ce.return_value = "engine"
        result = load_pipeline_resources(schema="s", store="st", templates="t", rejected="r", schema_terms={"term"})
        assert len(result) == 7


class TestGenerateJoinCandidates:
    """Tests for generate_join_candidates."""

    @patch("text2sql.pipeline.join_candidate_map", return_value={"J00": []})
    @patch(
        "text2sql.pipeline.join_hints_multi",
        return_value={"candidates": [{"candidate_id": "J00", "join_path_signature": []}]},
    )
    def test_single_table_no_cte(self, mock_jh, mock_jcm):
        """Single table intent returns default candidates."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        schema = SimpleNamespace(tables={"orders": SimpleNamespace(columns={})})
        jc, cmap, cte_hints = generate_join_candidates(intent, schema)
        assert "candidates" in jc
        assert isinstance(cmap, dict)
        assert cte_hints == {}

    @patch(
        "text2sql.pipeline.cte_to_intent_for_ranking",
        return_value=SimpleNamespace(tables=["orders", "customers"]),
    )
    @patch("text2sql.pipeline.join_candidate_map", return_value={"J00": []})
    @patch(
        "text2sql.pipeline.join_hints_multi",
        return_value={"candidates": [{"candidate_id": "J00", "join_path_signature": []}]},
    )
    def test_cte_multi_table_gets_hints(self, mock_jh, mock_jcm, mock_cte_intent):
        """CTE with multiple tables gets its own join hints."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders", "customers"],
            select_cols=[],
            output_columns=["order_id"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        schema = SimpleNamespace(
            tables={
                "orders": SimpleNamespace(columns={}),
                "customers": SimpleNamespace(columns={}),
            }
        )
        jc, cmap, cte_hints = generate_join_candidates(intent, schema)
        assert "cte1" in cte_hints

    @patch("text2sql.pipeline.join_candidate_map", return_value={"J00": []})
    @patch("text2sql.pipeline.join_hints_multi", return_value={"candidates": []})
    def test_cte_single_table_j00(self, mock_jh, mock_jcm):
        """CTE with single table gets default J00 candidate."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[],
            output_columns=["order_id"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        schema = SimpleNamespace(tables={"orders": SimpleNamespace(columns={})})
        _, _, cte_hints = generate_join_candidates(intent, schema)
        assert cte_hints["cte1"]["candidates"][0]["candidate_id"] == "J00"

    @patch("text2sql.pipeline.join_candidate_map", return_value={})
    @patch(
        "text2sql.pipeline.join_hints_multi",
        return_value={"candidates": [{"candidate_id": "J01", "join_path_signature": ["x"]}]},
    )
    def test_main_join_hints_use_schema_tables_only(self, mock_jh, mock_jcm):
        """Main query join_hints_multi receives physical tables, not CTE names."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["payment"],
            select_cols=[],
            output_columns=["a"],
            grain="row_level",
        )
        intent = RuntimeIntent(
            tables=["cte2", "customer", "payment", "cte1"],
            grain="grouped",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        schema = SimpleNamespace(
            tables={
                "customer": SimpleNamespace(columns={}),
                "payment": SimpleNamespace(columns={}),
            }
        )
        generate_join_candidates(intent, schema)
        mock_jh.assert_called_once()
        assert mock_jh.call_args[0][1] == ["customer", "payment"]


class TestDisplayFinalResults:
    """Tests for display_final_results."""

    @patch("text2sql.pipeline.print_query_result")
    @patch("text2sql.pipeline.llm_ux_explain", return_value="Explanation text")
    def test_returns_ux_string(self, mock_ux, mock_print):
        """Returns UX explanation string."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        ux = display_final_results("show orders", intent, "SELECT * FROM orders", [(1,)])
        assert ux == "Explanation text"

    @patch("text2sql.pipeline.print_query_result")
    @patch("text2sql.pipeline.llm_ux_explain", return_value="new ux")
    def test_always_calls_llm_ux_explain(self, mock_ux, mock_print):
        """Always generates fresh UX via llm_ux_explain."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        ux = display_final_results(
            "show orders",
            intent,
            "SELECT order_id FROM orders",
            [(1,)],
        )
        assert ux == "new ux"
        mock_ux.assert_called_once()


class TestComputeFinalMetrics:
    """Tests for compute_final_metrics."""

    @patch("text2sql.pipeline.extract_tables_from_sql", return_value=["orders"])
    @patch(
        "text2sql.pipeline.sql_shape",
        return_value=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
    )
    @patch("text2sql.pipeline.sql_fp", return_value="fp1")
    @patch("text2sql.pipeline.colmap_signature", return_value="cm1")
    @patch("text2sql.pipeline.intent_key", return_value="ik1")
    def test_returns_float(self, _ik, _cm, _fp, _shape, _ext, schema_graph):
        """compute_final_metrics returns a float in [0,1]."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            column_map={},
            extra_tables=[],
        )
        tmpl = Template(
            id="T0001",
            schema_hash="h",
            intent_signature=ConcreteIntent(
                intent_id="t",
                tables=["orders"],
                grain="row_level",
                select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            ),
            intent_key="ik1",
            tables_used=["orders"],
            sql_param="SELECT order_id FROM orders",
            sql_display_param="SELECT order_id FROM orders",
            sql_fp="fp1",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="cm1",
            value_history=ValueHistory(param_values=[{}], questions=["q"], natural_language=["q"]),
            stats=TemplateStats(accept=1, reject=0),
            trust_level=1,
        )
        templates = {"T0001": tmpl}
        join_candidates = {"candidates": [{"join_path_signature": []}]}
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            }
        }
        conf = compute_final_metrics(
            "SELECT order_id FROM orders",
            intent,
            schema_graph,
            templates,
            join_candidates,
            store,
        )
        assert isinstance(conf, float)
        assert 0.0 <= conf <= 1.0

    @patch("text2sql.pipeline.extract_tables_from_sql", return_value=["orders"])
    @patch(
        "text2sql.pipeline.sql_shape",
        return_value=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
    )
    @patch("text2sql.pipeline.sql_fp", return_value="fp1")
    @patch("text2sql.pipeline.colmap_signature", return_value="cm1")
    @patch("text2sql.pipeline.intent_key", return_value="ik1")
    def test_sets_sql_shape(self, _ik, _cm, _fp, mock_shape, _ext, schema_graph):
        """compute_final_metrics sets intent.sql_shape."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            column_map={},
            extra_tables=[],
        )
        tmpl = Template(
            id="T0001",
            schema_hash="h",
            intent_signature=ConcreteIntent(
                intent_id="t",
                tables=["orders"],
                grain="row_level",
                select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            ),
            intent_key="ik1",
            tables_used=["orders"],
            sql_param="SELECT order_id FROM orders",
            sql_display_param="SELECT order_id FROM orders",
            sql_fp="fp1",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="cm1",
            value_history=ValueHistory(param_values=[{}], questions=["q"], natural_language=["q"]),
            stats=TemplateStats(accept=1, reject=0),
            trust_level=1,
        )
        templates = {"T0001": tmpl}
        join_candidates = {"candidates": [{"join_path_signature": []}]}
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            }
        }
        compute_final_metrics(
            "SELECT order_id FROM orders",
            intent,
            schema_graph,
            templates,
            join_candidates,
            store,
        )
        assert intent.sql_shape is not None


class TestHandleUserFeedback:
    """Tests for handle_user_feedback."""

    @patch("text2sql.pipeline.save_template_store")
    def test_invalid_choice_saves_and_returns(self, mock_save, schema_graph):
        """Invalid choice (not y/n) just saves store and returns."""
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
            "templates": {},
            "rejected_templates": {},
            "next_id": 1,
            "next_reject_id": 1,
        }
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        handle_user_feedback("x", intent, "SELECT 1", schema_graph, store, {}, {}, "q", False, None, None)
        mock_save.assert_called_once()

    @patch("text2sql.pipeline.save_template_store")
    @patch(
        "text2sql.pipeline.sql_shape",
        return_value=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
    )
    @patch("text2sql.pipeline.intent_key", return_value="ik1")
    @patch("text2sql.pipeline.colmap_signature", return_value="cm1")
    @patch("text2sql.pipeline.sql_fp", return_value="fp1")
    @patch("text2sql.pipeline.promote_trust")
    @patch("text2sql.pipeline.record_template_feedback")
    @patch("text2sql.pipeline.flatten_param_values", return_value={})
    def test_accept_existing_template(self, _flat, _rec, _promote, _fp, _cm, _ik, _shape, _save, schema_graph):
        """Accept with existing template promotes trust."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            column_map={},
        )
        tmpl = Template(
            id="T0001",
            schema_hash="h",
            intent_signature=ConcreteIntent(
                intent_id="t",
                tables=["orders"],
                grain="row_level",
                select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            ),
            intent_key="ik1",
            tables_used=["orders"],
            sql_param="SELECT order_id FROM orders",
            sql_display_param="SELECT order_id FROM orders",
            sql_fp="fp1",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="cm1",
            value_history=ValueHistory(param_values=[{}], questions=["q"], natural_language=["q"]),
            stats=TemplateStats(accept=1, reject=0),
            trust_level=1,
        )
        templates = {"T0001": tmpl}
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
            "templates": {},
            "rejected_templates": {},
            "next_id": 2,
            "next_reject_id": 1,
        }
        handle_user_feedback(
            "y",
            intent,
            "SELECT order_id FROM orders",
            schema_graph,
            store,
            templates,
            {},
            "q",
            False,
            None,
            None,
        )
        _rec.assert_called_once()
        _promote.assert_called_once()


class TestConfirmIntentWithUser:
    """Tests for the 3-branch confirm_intent_with_user logic."""

    @staticmethod
    def _make_intent(nl: str = "Show film titles") -> RuntimeIntent:
        return RuntimeIntent(
            tables=["film"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("film.title"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            natural_language=nl,
        )

    @staticmethod
    def _make_store() -> dict:
        return {"templates": {}, "next_id": 1}

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice", return_value="y")
    def test_warnings_user_confirms(self, mock_choice, mock_save):
        """Branch 1: warnings present, user says yes → True."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=["col type mismatch"],
            similarity_score=0.99,
        )
        assert result is True
        mock_choice.assert_called_once()
        assert "Continue?" in mock_choice.call_args[0][0]

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice", return_value="n")
    def test_warnings_user_declines(self, mock_choice, mock_save):
        """Branch 1: warnings present, user says no → False, store saved."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=["col type mismatch"],
            similarity_score=0.99,
        )
        assert result is False
        mock_save.assert_called_once()

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice")
    def test_high_similarity_auto_proceeds(self, mock_choice, mock_save):
        """Branch 2: no warnings, high similarity → auto-proceed, no prompt."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=None,
            similarity_score=PolicyConfig.AUTO_PROCEED_THRESHOLD,
        )
        assert result is True
        mock_choice.assert_not_called()
        mock_save.assert_not_called()

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice", return_value="y")
    def test_low_similarity_user_confirms(self, mock_choice, mock_save):
        """Branch 3: no warnings, low similarity, user says yes → True."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=None,
            similarity_score=0.0,
        )
        assert result is True
        mock_choice.assert_called_once()
        assert "Is this correct?" in mock_choice.call_args[0][0]

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice", return_value="n")
    def test_low_similarity_user_declines(self, mock_choice, mock_save):
        """Branch 3: no warnings, low similarity, user says no → False, store saved."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=None,
            similarity_score=0.0,
        )
        assert result is False
        mock_save.assert_called_once()

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice", return_value=None)
    def test_warnings_none_choice_declines(self, mock_choice, mock_save):
        """Branch 1: warnings present, ask_user_choice returns None → False."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=["warn1"],
            similarity_score=0.0,
        )
        assert result is False

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice")
    def test_empty_warnings_list_is_no_warnings(self, mock_choice, mock_save):
        """Empty warnings list treated as no warnings (falsy)."""
        result = confirm_intent_with_user(
            self._make_intent(),
            self._make_store(),
            semantic_warnings=[],
            similarity_score=PolicyConfig.AUTO_PROCEED_THRESHOLD,
        )
        assert result is True
        mock_choice.assert_not_called()

    @patch("text2sql.pipeline.save_template_store")
    @patch("text2sql.pipeline.ask_user_choice", return_value="y")
    def test_fallback_nl_summary(self, mock_choice, mock_save):
        """When natural_language is empty, a fallback summary is
        used."""
        intent = self._make_intent(nl="")
        result = confirm_intent_with_user(
            intent,
            self._make_store(),
            semantic_warnings=None,
            similarity_score=0.0,
        )
        assert result is True
        mock_choice.assert_called_once()


class TestRunSqlValidationCascade:
    """Tests for _run_sql_validation_cascade helper."""

    def _make_intent(self, tables=None, grain="row_level", select_cols=None):
        """Build a minimal RuntimeIntent."""
        sc = select_cols or [SelectCol(expr=NormalizedExpr.from_column("t.id"))]
        return RuntimeIntent(
            tables=tables or ["t"],
            grain=grain,
            select_cols=sc,
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )

    @patch("text2sql.pipeline.validate_sql", return_value=(True, ""))
    def test_all_pass(self, mock_sql):
        """When validate_sql passes, cascade returns (True, '')."""
        intent = self._make_intent()
        ok, err = _run_sql_validation_cascade(
            "SELECT t.id FROM t",
            intent,
            None,
            None,
        )
        assert ok is True
        assert err == ""

    @patch("text2sql.pipeline.validate_sql", return_value=(False, "explain_error"))
    def test_explain_failure_detected(self, mock_sql):
        """EXPLAIN failure stops cascade."""
        intent = self._make_intent(grain="grouped")
        ok, err = _run_sql_validation_cascade(
            "SELECT t.id FROM t",
            intent,
            None,
            None,
        )
        assert ok is False
        assert err == "explain_error"
