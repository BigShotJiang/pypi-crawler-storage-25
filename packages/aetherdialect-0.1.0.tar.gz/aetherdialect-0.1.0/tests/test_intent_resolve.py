"""Tests for intent_resolve module: normalization, sorting, simplification."""

import pytest

from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import (
    ExprValue,
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    OrderByCol,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
)
from text2sql.intent_expr import parse_expr_string, replace_refs_in_expr
from text2sql.intent_resolve import (
    _canonicalize_condition_order,
    _dedup_filters,
    _dedup_having,
    _filter_structural_key,
    _having_structural_key,
    _normalize_agg_to_agg_having,
    _normalize_col_to_col_filter,
    _normalize_filter_canonical,
    _normalize_filter_scalar_on_left,
    _normalize_having_canonical,
    _simplify_expr,
    enforce_cte_grain_consistency,
    enforce_grain_consistency,
    enforce_schema,
    force_main_grain_when_using_grouped_cte,
    normalize_count_star,
    normalize_cte_names,
    normalize_filters_havings,
    resolve_column_map,
    resolve_cte_column_maps,
    simplify_exprs,
    sort_filters,
    sort_having,
    sort_order_by_cols,
    sort_select_cols,
)


class TestReplaceRefsInExpr:
    """Tests for replace_refs_in_expr."""

    def test_replaces_terms(self):
        """replace_refs_in_expr applies replacer to multiply/divide
        terms."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["old_table.col"])],
        )
        result = replace_refs_in_expr(expr, lambda s: s.replace("old_table", "new_table"))
        assert result.add_groups[0].multiply == ["new_table.col"]

    def test_preserves_add_values_and_sub_values(self):
        """replace_refs_in_expr does not modify add_values or sub_values."""
        from text2sql.contracts_core import ExprValue

        expr = NormalizedExpr(
            add_groups=[],
            sub_groups=[],
            add_values=[ExprValue(value=1.0)],
            sub_values=[ExprValue(value=0.5)],
        )
        result = replace_refs_in_expr(expr, lambda s: s.upper())
        assert result.add_values == expr.add_values
        assert result.sub_values == expr.sub_values

    def test_empty_groups_returns_empty_groups(self):
        """replace_refs_in_expr with no groups returns empty add/sub groups."""
        expr = NormalizedExpr(add_groups=[], sub_groups=[])
        result = replace_refs_in_expr(expr, lambda s: s)
        assert result.add_groups == []
        assert result.sub_groups == []


class TestNormalizeCountStarInIntent:
    """Tests for normalize_count_star."""

    def test_converts_count_1_to_count_star(self):
        """normalize_count_star converts COUNT(1) to COUNT(*)."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(1)"])]))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_count_star(intent)
        assert result.select_cols[0].expr.add_groups[0].multiply == ["COUNT(*)"]

    def test_no_count_1_unchanged(self):
        """normalize_count_star leaves intent unchanged when no COUNT(1)."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.col"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_count_star(intent)
        assert result.select_cols[0].expr.primary_column == "t.col"

    def test_cte_steps_normalized(self):
        """normalize_count_star converts COUNT(1) in CTE select_cols."""
        cte = RuntimeCteStep(
            cte_name="c1",
            tables=["t"],
            select_cols=[SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(1)"])]))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_count_star(intent)
        assert result.cte_steps[0].select_cols[0].expr.add_groups[0].multiply == ["COUNT(*)"]


class TestSortFunctions:
    """Tests for sort_select_cols, sort_order_by_cols, sort_filters,
    sort_having."""

    def test_sort_select_cols_non_agg_first(self):
        """sort_select_cols places non-aggregated columns before
        aggregated."""
        cols = [
            SelectCol(expr=NormalizedExpr.from_agg("sum", "t.amount")),
            SelectCol(expr=NormalizedExpr.from_column("t.name")),
        ]
        sorted_cols = sort_select_cols(cols)
        assert sorted_cols[0].is_aggregated is False
        assert sorted_cols[1].is_aggregated is True

    def test_sort_select_cols_empty_list(self):
        """sort_select_cols returns empty list for empty input."""
        assert sort_select_cols([]) == []

    def test_sort_order_by_cols(self):
        """sort_order_by_cols sorts by aggregation then signature."""
        cols = [
            OrderByCol(expr=NormalizedExpr.from_agg("count", "t.id"), direction="DESC"),
            OrderByCol(expr=NormalizedExpr.from_column("t.name"), direction="ASC"),
        ]
        sorted_cols = sort_order_by_cols(cols)
        assert sorted_cols[0].is_aggregated is False

    def test_sort_filters_by_signature(self):
        """sort_filters sorts by left_expr signature."""
        f1 = FilterParam(left_expr=NormalizedExpr.from_column("z.col"), op="=")
        f2 = FilterParam(left_expr=NormalizedExpr.from_column("a.col"), op="=")
        sorted_f = sort_filters([f1, f2])
        assert sorted_f[0].left_expr.primary_term == "a.col"

    def test_sort_having_by_signature(self):
        """sort_having sorts by left_expr signature."""
        h1 = HavingParam(left_expr=NormalizedExpr.from_agg("sum", "z.col"), op=">")
        h2 = HavingParam(left_expr=NormalizedExpr.from_agg("count", "a.col"), op=">")
        sorted_h = sort_having([h1, h2])
        assert sorted_h[0].left_expr.add_groups[0].agg_func == "count"


class TestCanonicalizeConditionOrder:
    """Tests for _canonicalize_condition_order precedence-tree
    algorithm."""

    def test_single_item_unchanged(self):
        """Single-item list is returned unchanged."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="OR")
        result = _canonicalize_condition_order([fp], _filter_structural_key)
        assert len(result) == 1
        assert result[0].left_expr.primary_term == "t.a"
        assert result[0].bool_op == "OR"

    def test_empty_list(self):
        """Empty list returns empty."""
        assert _canonicalize_condition_order([], _filter_structural_key) == []

    def test_all_and_sorts_by_structural_key(self):
        """All-AND list sorts freely by structural key."""
        fz = FilterParam(left_expr=NormalizedExpr.from_column("t.z"), op="=", bool_op="AND")
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="AND")
        fm = FilterParam(left_expr=NormalizedExpr.from_column("t.m"), op="=", bool_op="AND")
        result = _canonicalize_condition_order([fz, fa, fm], _filter_structural_key)
        assert [r.left_expr.primary_term for r in result] == ["t.a", "t.m", "t.z"]
        assert all(r.bool_op == "AND" for r in result)

    def test_all_or_sorts_by_structural_key(self):
        """All-OR list sorts freely by structural key."""
        fz = FilterParam(left_expr=NormalizedExpr.from_column("t.z"), op="=", bool_op="OR")
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="OR")
        result = _canonicalize_condition_order([fz, fa], _filter_structural_key)
        assert result[0].left_expr.primary_term == "t.a"
        assert result[1].left_expr.primary_term == "t.z"

    def test_mixed_ops_preserves_semantics(self):
        """Mixed AND/OR: A(OR) B(AND) C → splits at OR into [A], [B,C]
        and canonicalizes."""
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="OR")
        fc = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="AND")
        fb = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", bool_op="AND")
        result = _canonicalize_condition_order([fa, fc, fb], _filter_structural_key)
        assert result[0].left_expr.primary_term == "t.a"
        assert result[0].bool_op == "OR"
        assert result[1].left_expr.primary_term == "t.b"
        assert result[1].bool_op == "AND"
        assert result[2].left_expr.primary_term == "t.c"

    def test_and_chunk_sorted_within(self):
        """AND-chunk members are sorted by structural key."""
        fc = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="AND")
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="AND")
        fb = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", bool_op="AND")
        result = _canonicalize_condition_order([fc, fa, fb], _filter_structural_key)
        assert [r.left_expr.primary_term for r in result] == ["t.a", "t.b", "t.c"]

    def test_or_chunks_sorted_by_first_element(self):
        """OR-separated chunks are sorted by their first element's
        structural key."""
        fz = FilterParam(left_expr=NormalizedExpr.from_column("t.z"), op="=", bool_op="OR")
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="AND")
        result = _canonicalize_condition_order([fz, fa], _filter_structural_key)
        assert result[0].left_expr.primary_term == "t.a"
        assert result[0].bool_op == "OR"
        assert result[1].left_expr.primary_term == "t.z"

    def test_inter_connector_preserved_on_last(self):
        """The last element's original bool_op (inter-group connector)
        is preserved on the new last."""
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="AND")
        fb = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", bool_op="OR")
        result = _canonicalize_condition_order([fa, fb], _filter_structural_key)
        assert result[-1].bool_op == "OR"

    def test_complex_mixed_expression(self):
        """Complex: D(OR) A(OR) C(AND) B(AND) E → parse as [D],[A],[C AND B AND E]."""
        fd = FilterParam(left_expr=NormalizedExpr.from_column("t.d"), op="=", bool_op="OR")
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="OR")
        fc = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="AND")
        fb = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", bool_op="AND")
        fe = FilterParam(left_expr=NormalizedExpr.from_column("t.e"), op="=", bool_op="AND")
        result = _canonicalize_condition_order([fd, fa, fc, fb, fe], _filter_structural_key)
        assert result[0].left_expr.primary_term == "t.a"
        assert result[0].bool_op == "OR"
        assert result[1].left_expr.primary_term == "t.b"
        assert result[1].bool_op == "AND"
        assert result[2].left_expr.primary_term == "t.c"
        assert result[2].bool_op == "AND"
        assert result[3].left_expr.primary_term == "t.e"
        assert result[3].bool_op == "OR"
        assert result[4].left_expr.primary_term == "t.d"

    def test_having_variant(self):
        """Canonicalization works with HavingParam via
        _having_structural_key."""
        hz = HavingParam(left_expr=NormalizedExpr.from_agg("sum", "t.z"), op=">", bool_op="AND")
        ha = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.a"), op=">", bool_op="AND")
        result = _canonicalize_condition_order([hz, ha], _having_structural_key)
        assert result[0].left_expr.add_groups[0].agg_func == "count"
        assert result[1].left_expr.add_groups[0].agg_func == "sum"

    def test_idempotent(self):
        """Applying canonicalization twice produces the same result."""
        fa = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", bool_op="OR")
        fc = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="AND")
        fb = FilterParam(left_expr=NormalizedExpr.from_column("t.b"), op="=", bool_op="AND")
        first = _canonicalize_condition_order([fa, fc, fb], _filter_structural_key)
        second = _canonicalize_condition_order(first, _filter_structural_key)
        assert [r.left_expr.primary_term for r in first] == [r.left_expr.primary_term for r in second]
        assert [r.bool_op for r in first] == [r.bool_op for r in second]


class TestSortFiltersGroupAware:
    """Tests for sort_filters with filter_group partitioning."""

    def test_single_group_or(self):
        """Filters in the same group with all-OR are sorted by
        structural key."""
        fz = FilterParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        result = sort_filters([fz, fa])
        assert result[0].left_expr.primary_term == "t.a"
        assert result[1].left_expr.primary_term == "t.z"
        assert all(r.filter_group == 1 for r in result)

    def test_ungrouped_and_grouped_inter_group_sort(self):
        """Inter-group order is determined by structural key of group
        representatives."""
        fz = FilterParam(left_expr=NormalizedExpr.from_column("t.z"), op="=", filter_group=None)
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fb = FilterParam(
            left_expr=NormalizedExpr.from_column("t.b"),
            op="=",
            bool_op="AND",
            filter_group=1,
        )
        result = sort_filters([fz, fa, fb])
        assert result[0].filter_group == 1
        assert result[1].filter_group == 1
        assert result[2].filter_group is None

    def test_multiple_groups_sorted_by_representative(self):
        """Multiple filter_groups are sorted by their representative
        structural key."""
        g2a = FilterParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op="=",
            bool_op="AND",
            filter_group=2,
        )
        g1a = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="AND",
            filter_group=1,
        )
        result = sort_filters([g2a, g1a])
        assert result[0].filter_group == 1
        assert result[1].filter_group == 2

    def test_inter_group_connector_preserved(self):
        """The inter-group connector (last filter's bool_op) is
        preserved through sorting."""
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fb = FilterParam(
            left_expr=NormalizedExpr.from_column("t.b"),
            op="=",
            bool_op="AND",
            filter_group=1,
        )
        fc = FilterParam(
            left_expr=NormalizedExpr.from_column("t.c"),
            op="=",
            bool_op="AND",
            filter_group=None,
        )
        result = sort_filters([fc, fa, fb])
        group1 = [r for r in result if r.filter_group == 1]
        assert group1[-1].bool_op in ("AND", "OR")

    def test_intra_group_mixed_ops_canonical(self):
        """Mixed ops within a group are canonicalized via precedence
        tree."""
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fc = FilterParam(
            left_expr=NormalizedExpr.from_column("t.c"),
            op="=",
            bool_op="AND",
            filter_group=1,
        )
        fb = FilterParam(
            left_expr=NormalizedExpr.from_column("t.b"),
            op="=",
            bool_op="AND",
            filter_group=1,
        )
        result = sort_filters([fa, fc, fb])
        terms = [r.left_expr.primary_term for r in result]
        assert terms == ["t.a", "t.b", "t.c"]

    def test_sort_filters_idempotent(self):
        """sort_filters applied twice yields the same result."""
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fb = FilterParam(
            left_expr=NormalizedExpr.from_column("t.b"),
            op="=",
            bool_op="AND",
            filter_group=1,
        )
        fc = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", filter_group=None)
        first = sort_filters([fc, fa, fb])
        second = sort_filters(first)
        assert [r.left_expr.primary_term for r in first] == [r.left_expr.primary_term for r in second]
        assert [r.bool_op for r in first] == [r.bool_op for r in second]
        assert [r.filter_group for r in first] == [r.filter_group for r in second]


class TestSortHavingGroupAware:
    """Tests for sort_having with filter_group partitioning."""

    def test_single_group_or(self):
        """Having conditions in the same group with all-OR are sorted by
        structural key."""
        hz = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.z"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        ha = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        result = sort_having([hz, ha])
        assert result[0].left_expr.add_groups[0].agg_func == "count"
        assert result[1].left_expr.add_groups[0].agg_func == "sum"
        assert all(r.filter_group == 1 for r in result)

    def test_ungrouped_and_grouped(self):
        """Having conditions with mixed groups are sorted by structural
        key across groups."""
        hz = HavingParam(left_expr=NormalizedExpr.from_agg("sum", "t.z"), op=">", filter_group=None)
        ha = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        result = sort_having([hz, ha])
        assert result[0].filter_group == 1
        assert result[1].filter_group is None

    def test_intra_group_mixed_ops(self):
        """Mixed ops within a having group are canonicalized via
        precedence tree."""
        ha = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.a"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        hc = HavingParam(
            left_expr=NormalizedExpr.from_agg("max", "t.c"),
            op=">",
            bool_op="AND",
            filter_group=1,
        )
        hb = HavingParam(
            left_expr=NormalizedExpr.from_agg("min", "t.b"),
            op=">",
            bool_op="AND",
            filter_group=1,
        )
        result = sort_having([ha, hc, hb])
        funcs = [r.left_expr.add_groups[0].agg_func for r in result]
        assert funcs[1] < funcs[2]

    def test_sort_having_idempotent(self):
        """sort_having applied twice yields the same result."""
        ha = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.a"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        hb = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.b"),
            op=">",
            bool_op="AND",
            filter_group=1,
        )
        first = sort_having([ha, hb])
        second = sort_having(first)
        assert [r.left_expr.primary_term for r in first] == [r.left_expr.primary_term for r in second]
        assert [r.bool_op for r in first] == [r.bool_op for r in second]


class TestDedupFiltersGroupAware:
    """Tests for _dedup_filters with bool_op and filter_group in dedup
    key."""

    def test_same_signature_different_bool_op_kept(self):
        """Filters with same signature_key but different bool_op are
        both kept."""
        fp_and = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            bool_op="AND",
        )
        fp_or = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            bool_op="OR",
        )
        result = _dedup_filters([fp_and, fp_or])
        assert len(result) == 2

    def test_same_signature_different_filter_group_kept(self):
        """Filters with same signature_key but different filter_group
        are both kept."""
        fp1 = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            filter_group=1,
        )
        fp2 = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            filter_group=2,
        )
        result = _dedup_filters([fp1, fp2])
        assert len(result) == 2

    def test_identical_including_bool_op_and_group_deduped(self):
        """Filters identical in signature_key, bool_op, and filter_group
        are deduped."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            bool_op="OR",
            filter_group=1,
        )
        result = _dedup_filters([fp, fp])
        assert len(result) == 1


class TestDedupHavingGroupAware:
    """Tests for _dedup_having with bool_op and filter_group in dedup
    key."""

    def test_same_signature_different_bool_op_kept(self):
        """Havings with same signature_key but different bool_op are
        both kept."""
        hp_and = HavingParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
            bool_op="AND",
        )
        hp_or = HavingParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
            bool_op="OR",
        )
        result = _dedup_having([hp_and, hp_or])
        assert len(result) == 2

    def test_same_signature_different_filter_group_kept(self):
        """Havings with same signature_key but different filter_group
        are both kept."""
        hp1 = HavingParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
            filter_group=1,
        )
        hp2 = HavingParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
            filter_group=2,
        )
        result = _dedup_having([hp1, hp2])
        assert len(result) == 2

    def test_identical_including_bool_op_and_group_deduped(self):
        """Havings identical in signature_key, bool_op, and filter_group
        are deduped."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
            bool_op="OR",
            filter_group=1,
        )
        result = _dedup_having([hp, hp])
        assert len(result) == 1


class TestNormalizeIntentFiltersHavingsGroupAware:
    """Tests for normalize_filters_havings with group-aware sort and
    dedup."""

    def test_grouped_or_filters_sorted_within_group(self):
        """Grouped OR filters are sorted by structural key within the
        group."""
        fz = FilterParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fz, fa],
        )
        result = normalize_filters_havings(intent)
        assert result.filters_param[0].left_expr.primary_term == "t.a"
        assert result.filters_param[1].left_expr.primary_term == "t.z"

    def test_grouped_having_sorted_within_group(self):
        """Grouped OR havings are sorted by structural key within the
        group."""
        hz = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.z"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        ha = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[hz, ha],
        )
        result = normalize_filters_havings(intent)
        assert result.having_param[0].left_expr.add_groups[0].agg_func == "count"

    def test_cte_filters_group_aware_sort(self):
        """CTE step filters are group-aware sorted."""
        fz = FilterParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        fa = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            bool_op="OR",
            filter_group=1,
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fz, fa],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_filters_havings(intent)
        assert result.cte_steps[0].filters_param[0].left_expr.primary_term == "t.a"

    def test_cte_having_group_aware_sort(self):
        """CTE step having conditions are group-aware sorted."""
        hz = HavingParam(
            left_expr=NormalizedExpr.from_agg("sum", "t.z"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        ha = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            bool_op="OR",
            filter_group=1,
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[hz, ha],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_filters_havings(intent)
        assert result.cte_steps[0].having_param[0].left_expr.add_groups[0].agg_func == "count"

    def test_dedup_respects_bool_op_in_pipeline(self):
        """Pipeline dedup keeps filters with same structure but
        different bool_op."""
        fp_and = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            bool_op="AND",
        )
        fp_or = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="string",
            bool_op="OR",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp_and, fp_or],
        )
        result = normalize_filters_havings(intent)
        assert len(result.filters_param) == 2


class TestSimplifyExpr:
    """Tests for simplify_expr."""

    def test_constant_folding(self):
        """simplify_expr folds constant values."""
        expr = NormalizedExpr(
            add_values=[ExprValue(value=3.0), ExprValue(value=7.0)],
        )
        result = _simplify_expr(expr)
        assert len(result.add_values) == 1
        assert result.add_values[0].value == 10.0

    def test_zero_elimination(self):
        """simplify_expr eliminates zero-coefficient groups."""
        g = MulGroup(coefficient=1.0, multiply=["t.col"])
        expr = NormalizedExpr(
            add_groups=[g],
            sub_groups=[MulGroup(coefficient=1.0, multiply=["t.col"])],
        )
        result = _simplify_expr(expr)
        assert len(result.add_groups) == 0
        assert len(result.sub_groups) == 0

    def test_like_term_combining(self):
        """simplify_expr combines like terms."""
        g1 = MulGroup(coefficient=2.0, multiply=["t.col"])
        g2 = MulGroup(coefficient=3.0, multiply=["t.col"])
        expr = NormalizedExpr(add_groups=[g1, g2])
        result = _simplify_expr(expr)
        assert len(result.add_groups) == 1
        assert result.add_groups[0].coefficient == 5.0

    def test_negative_coefficient_to_sub(self):
        """simplify_expr moves negative coefficient groups to
        sub_groups."""
        g1 = MulGroup(coefficient=2.0, multiply=["t.a"])
        g2 = MulGroup(coefficient=5.0, multiply=["t.a"])
        expr = NormalizedExpr(add_groups=[g1], sub_groups=[g2])
        result = _simplify_expr(expr)
        assert len(result.sub_groups) == 1
        assert result.sub_groups[0].coefficient == 3.0

    def test_preserves_parameterized_values(self):
        """simplify_expr preserves parameterized ExprValues."""
        expr = NormalizedExpr(
            add_values=[ExprValue(value=5.0, param_key="p1"), ExprValue(value=3.0)],
        )
        result = _simplify_expr(expr)
        parameterized = [v for v in result.add_values if v.param_key]
        assert len(parameterized) == 1
        assert parameterized[0].param_key == "p1"

    def test_constant_only_group_folded(self):
        """simplify_expr folds MulGroup with no multiply/divide into
        constants."""
        g = MulGroup(coefficient=7.0, multiply=[], divide=[])
        expr = NormalizedExpr(add_groups=[g])
        result = _simplify_expr(expr)
        assert len(result.add_groups) == 0
        assert len(result.add_values) == 1
        assert result.add_values[0].value == 7.0

    def test_net_negative_constant(self):
        """simplify_expr handles net negative constants."""
        expr = NormalizedExpr(
            add_values=[ExprValue(value=3.0)],
            sub_values=[ExprValue(value=10.0)],
        )
        result = _simplify_expr(expr)
        assert len(result.sub_values) == 1
        assert result.sub_values[0].value == 7.0
        assert len(result.add_values) == 0

    def test_preserves_agg_func(self):
        """simplify_expr preserves expr-level agg_func."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.col"])],
            agg_func="sum",
        )
        result = _simplify_expr(expr)
        assert result.agg_func == "sum"


class TestSimplifyIntentExprs:
    """Tests for simplify_exprs."""

    def test_simplifies_select_cols(self):
        """simplify_exprs simplifies select column expressions."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[
                            MulGroup(coefficient=2.0, multiply=["t.x"]),
                            MulGroup(coefficient=3.0, multiply=["t.x"]),
                        ],
                    )
                ),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = simplify_exprs(intent)
        assert len(result.select_cols[0].expr.add_groups) == 1
        assert result.select_cols[0].expr.add_groups[0].coefficient == 5.0


class TestNormalizeFilterScalarOnLeft:
    """Tests for _normalize_filter_scalar_on_left."""

    def test_swaps_scalar_left_column_right(self):
        """Swap when left is scalar and right is column, flipping operator."""
        fp = FilterParam(
            left_expr=parse_expr_string("CURRENT_DATE"),
            op="<=",
            right_expr=NormalizedExpr.from_column("payment.payment_date"),
            value_type="date",
        )
        result = _normalize_filter_scalar_on_left(fp)
        assert result.left_expr.primary_column == "payment.payment_date"
        assert result.right_expr is not None
        assert "CURRENT_DATE" in result.right_expr.signature_key
        assert result.op == ">="

    def test_swaps_interval_left_column_right(self):
        """Swap when left is INTERVAL expression and right is column."""
        fp = FilterParam(
            left_expr=parse_expr_string("CURRENT_DATE - INTERVAL '90 days'"),
            op="<",
            right_expr=NormalizedExpr.from_column("rental.rental_date"),
            value_type="date",
        )
        result = _normalize_filter_scalar_on_left(fp)
        assert result.left_expr.primary_column == "rental.rental_date"
        assert result.op == ">"

    def test_column_left_scalar_right_unchanged(self):
        """Leave column-on-left, scalar-on-right unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("rental.rental_date"),
            op=">=",
            right_expr=parse_expr_string("CURRENT_DATE - INTERVAL '90 days'"),
            value_type="date",
        )
        result = _normalize_filter_scalar_on_left(fp)
        assert result.left_expr.primary_column == "rental.rental_date"
        assert result.op == ">="

    def test_column_left_column_right_unchanged(self):
        """Leave col-vs-col filters unchanged (handled by _normalize_col_to_col_filter)."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            right_expr=NormalizedExpr.from_column("t.b"),
            value_type="string",
        )
        result = _normalize_filter_scalar_on_left(fp)
        assert result.left_expr.primary_column == "t.a"
        assert result.right_expr.primary_column == "t.b"

    def test_no_right_expr_unchanged(self):
        """Leave filters without right_expr unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="=",
            value_type="string",
            raw_value="x",
        )
        result = _normalize_filter_scalar_on_left(fp)
        assert result.left_expr.primary_column == "t.a"
        assert result.right_expr is None


class TestNormalizeFilterCanonical:
    """Tests for normalize_filter_canonical."""

    def test_swaps_empty_left_with_right(self):
        """normalize_filter_canonical swaps empty left with right."""
        fp = FilterParam(
            left_expr=NormalizedExpr(add_groups=[], add_values=[]),
            op=">",
            right_expr=NormalizedExpr.from_column("t.x"),
            value_type="number",
        )
        result = _normalize_filter_canonical(fp)
        assert result.left_expr.primary_term == "t.x"
        assert result.op == "<"

    def test_nonempty_left_unchanged(self):
        """normalize_filter_canonical leaves non-empty left
        unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
        )
        result = _normalize_filter_canonical(fp)
        assert result.left_expr.primary_column == "t.x"
        assert result.op == "="


class TestNormalizeHavingCanonical:
    """Tests for normalize_having_canonical."""

    def test_swaps_empty_left_with_right(self):
        """normalize_having_canonical swaps empty left with right."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[], add_values=[]),
            op=">=",
            right_expr=NormalizedExpr.from_column("t.x"),
            value_type="number",
        )
        result = _normalize_having_canonical(hp)
        assert result.left_expr.primary_term == "t.x"
        assert result.op == "<="

    def test_nonempty_left_unchanged(self):
        """normalize_having_canonical leaves non-empty left
        unchanged."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("t.x"),
            op="=",
            value_type="number",
        )
        result = _normalize_having_canonical(hp)
        assert result.left_expr.primary_column == "t.x"


class TestNormalizeColToColFilter:
    """Tests for normalize_col_to_col_filter."""

    def test_smaller_sig_on_left(self):
        """normalize_col_to_col_filter puts smaller signature on
        left."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op=">",
            right_expr=NormalizedExpr.from_column("t.a"),
            value_type="number",
        )
        result = _normalize_col_to_col_filter(fp)
        assert result.left_expr.primary_column == "t.a"
        assert result.op == "<"

    def test_already_ordered_unchanged(self):
        """normalize_col_to_col_filter leaves already-ordered
        unchanged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op=">",
            right_expr=NormalizedExpr.from_column("t.z"),
            value_type="number",
        )
        result = _normalize_col_to_col_filter(fp)
        assert result.left_expr.primary_column == "t.a"
        assert result.op == ">"


class TestNormalizeAggToAggHaving:
    """Tests for normalize_agg_to_agg_having."""

    def test_smaller_sig_on_left(self):
        """normalize_agg_to_agg_having puts smaller signature on
        left."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op=">",
            right_expr=NormalizedExpr.from_column("t.a"),
            value_type="number",
        )
        result = _normalize_agg_to_agg_having(hp)
        assert result.left_expr.primary_column == "t.a"
        assert result.op == "<"

    def test_with_param_key_no_swap(self):
        """normalize_agg_to_agg_having does not swap when param_key
        set."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_column("t.z"),
            op=">",
            right_expr=NormalizedExpr.from_column("t.a"),
            value_type="number",
            param_key="p1",
        )
        result = _normalize_agg_to_agg_having(hp)
        assert result.left_expr.primary_column == "t.a"


class TestDedupFilters:
    """Tests for _dedup_filters."""

    def test_removes_duplicate(self):
        """_dedup_filters removes duplicate by signature_key."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.x"), op="=", value_type="string")
        result = _dedup_filters([fp, fp])
        assert len(result) == 1

    def test_preserves_unique(self):
        """_dedup_filters preserves unique filters."""
        fp1 = FilterParam(left_expr=NormalizedExpr.from_column("t.x"), op="=", value_type="string")
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.y"), op=">", value_type="number")
        result = _dedup_filters([fp1, fp2])
        assert len(result) == 2

    def test_empty_list(self):
        """_dedup_filters returns empty for empty input."""
        assert _dedup_filters([]) == []


class TestDedupHaving:
    """Tests for _dedup_having."""

    def test_removes_duplicate(self):
        """_dedup_having removes duplicate by signature_key."""
        hp = HavingParam(left_expr=NormalizedExpr.from_column("t.x"), op="=", value_type="number")
        result = _dedup_having([hp, hp])
        assert len(result) == 1

    def test_preserves_unique(self):
        """_dedup_having preserves unique havings."""
        hp1 = HavingParam(left_expr=NormalizedExpr.from_column("t.x"), op="=", value_type="number")
        hp2 = HavingParam(left_expr=NormalizedExpr.from_column("t.y"), op=">", value_type="number")
        result = _dedup_having([hp1, hp2])
        assert len(result) == 2


class TestNormalizeIntentFiltersHavings:
    """Tests for normalize_filters_havings."""

    def test_deduplicates_filters(self):
        """normalize_filters_havings deduplicates filters."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.x"), op="=", value_type="string")
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp, fp],
        )
        result = normalize_filters_havings(intent)
        assert len(result.filters_param) == 1

    def test_normalizes_ops(self):
        """normalize_filters_havings normalizes operators."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.x"), op="==", value_type="string")
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_filters_havings(intent)
        assert result.filters_param[0].op == "="


class TestEnforceGrainConsistency:
    """Tests for enforce_grain_consistency."""

    @pytest.fixture
    def grain_schema(self):
        """Schema for grain consistency tests."""
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={
                        "id": ColumnMetadata(
                            name="id",
                            data_type="integer",
                            value_type="integer",
                            is_primary_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                            distinct_count=100,
                            distinct_ratio=0.99,
                        ),
                        "customer_id": ColumnMetadata(
                            name="customer_id",
                            data_type="integer",
                            value_type="integer",
                            is_foreign_key=True,
                            role=ColumnRole.IDENTIFIER.value,
                            distinct_count=50,
                        ),
                        "amount": ColumnMetadata(
                            name="amount",
                            data_type="numeric",
                            value_type="number",
                            role=ColumnRole.NUMERIC_MEASURE.value,
                            distinct_count=80,
                        ),
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )

    def test_infers_group_by_from_mixed_select(self, grain_schema):
        """enforce_grain_consistency infers group_by when select has agg
        and non-agg."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.customer_id")),
                SelectCol(expr=NormalizedExpr.from_agg("sum", "orders.amount")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = enforce_grain_consistency(intent, grain_schema)
        assert result.grain == "grouped"
        gb_terms = [g.primary_term for g in result.group_by_cols]
        assert "orders.customer_id" in gb_terms

    def test_no_change_when_no_agg(self, grain_schema):
        """enforce_grain_consistency returns unchanged when no
        aggregation."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = enforce_grain_consistency(intent, grain_schema)
        assert result.grain == "row_level"

    def test_no_change_all_agg(self, grain_schema):
        """enforce_grain_consistency returns unchanged when all columns
        are aggregated."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "orders.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = enforce_grain_consistency(intent, grain_schema)
        assert result.grain == "row_level"


class TestEnforceCteGrainConsistency:
    """Tests for enforce_cte_grain_consistency."""

    def test_sets_grouped_when_group_by_present(self):
        """enforce_cte_grain_consistency sets grain to grouped."""
        cte = RuntimeCteStep(cte_name="cte1", group_by_cols=[NormalizedExpr.from_column("t.a")])
        result = enforce_cte_grain_consistency(cte)
        assert result.grain == "grouped"

    def test_unchanged_when_no_group_by(self):
        """enforce_cte_grain_consistency returns unchanged without
        group_by."""
        cte = RuntimeCteStep(cte_name="cte1")
        result = enforce_cte_grain_consistency(cte)
        assert result.grain == "row_level"


class TestResolveColumnMap:
    """Tests for resolve_column_map."""

    @pytest.fixture
    def map_schema(self):
        """Schema for column map tests."""
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={
                        "id": ColumnMetadata(name="id", data_type="integer", value_type="integer"),
                        "amount": ColumnMetadata(name="amount", data_type="numeric", value_type="number"),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "customers": TableMetadata(
                    name="customers",
                    columns={
                        "id": ColumnMetadata(name="id", data_type="integer", value_type="integer"),
                        "name": ColumnMetadata(name="name", data_type="varchar", value_type="string"),
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
        )

    def test_bare_column_unique(self, map_schema):
        """resolve_column_map resolves unique bare column."""
        result = resolve_column_map(["name"], map_schema, ["orders", "customers"])
        assert result["name"] == "customers"

    def test_bare_column_ambiguous(self, map_schema):
        """resolve_column_map picks first candidate for ambiguous bare
        column."""
        result = resolve_column_map(["id"], map_schema, ["customers", "orders"])
        assert "id" in result

    def test_empty_columns(self, map_schema):
        """resolve_column_map returns empty for empty input."""
        result = resolve_column_map([], map_schema, ["orders"])
        assert result == {}

    def test_qualified_column(self, schema_graph):
        """Resolves table.column notation."""
        result = resolve_column_map(["orders.amount"], schema_graph, ["orders"])
        assert result["amount"] == "orders"

    def test_bare_column_single_match(self, schema_graph):
        """Resolves bare column name when unique across tables."""
        result = resolve_column_map(["amount"], schema_graph, ["orders"])
        assert result["amount"] == "orders"

    def test_bare_column_ambiguous_multi_table(self, schema_graph):
        """Ambiguous bare column resolves to first candidate."""
        schema = SchemaGraph(
            tables={
                "t1": TableMetadata(
                    name="t1",
                    columns={
                        "col": ColumnMetadata(
                            name="col",
                            data_type="integer",
                            value_type="integer",
                            role=ColumnRole.IDENTIFIER.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
                "t2": TableMetadata(
                    name="t2",
                    columns={
                        "col": ColumnMetadata(
                            name="col",
                            data_type="integer",
                            value_type="integer",
                            role=ColumnRole.IDENTIFIER.value,
                        )
                    },
                    foreign_keys=[],
                    primary_key="",
                ),
            },
            join_paths_multi={},
            schema_hash="",
        )
        result = resolve_column_map(["col"], schema, ["t1", "t2"])
        assert result["col"] in ("t1", "t2")

    def test_table_not_in_schema(self, schema_graph):
        """Skips tables not in schema graph."""
        result = resolve_column_map(["nonexistent.col"], schema_graph, ["nonexistent"])
        assert result == {}

    def test_qualified_column_wrong_table(self, schema_graph):
        """Qualified reference with table not in allowed list produces
        no mapping."""
        result = resolve_column_map(["products.name"], schema_graph, ["orders"])
        assert "name" not in result


class TestResolveCteColumnMaps:
    """Tests for resolve_cte_column_maps."""

    def test_single_cte_no_deps(self):
        """Single CTE with no upstream references produces empty
        column_map."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
            output_columns=["amount"],
        )
        result = resolve_cte_column_maps([cte])
        assert len(result) == 1
        assert result[0].column_map.get("amount") is None or "orders" in result[0].column_map.get("amount", "")

    def test_second_cte_references_first(self):
        """Second CTE maps bare column to first CTE name."""
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
            output_columns=["amount"],
        )
        cte2 = RuntimeCteStep(
            cte_name="cte2",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("amount"))],
        )
        result = resolve_cte_column_maps([cte1, cte2])
        assert result[1].column_map.get("amount") == "cte1"

    def test_empty_list(self):
        """Returns empty list for empty input."""
        assert resolve_cte_column_maps([]) == []

    def test_qualified_ref_in_cte(self):
        """Qualified reference is split into column_map entry."""
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
            output_columns=["amount"],
        )
        cte2 = RuntimeCteStep(
            cte_name="cte2",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("cte1.amount"))],
        )
        result = resolve_cte_column_maps([cte1, cte2])
        assert result[1].column_map.get("amount") == "cte1"

    def test_maps_bare_columns_to_prior_cte(self):
        """resolve_cte_column_maps maps bare columns to earlier CTE
        output."""
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.total"))],
            output_columns=["total"],
        )
        cte2 = RuntimeCteStep(
            cte_name="cte2",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("total"))],
        )
        result = resolve_cte_column_maps([cte1, cte2])
        assert result[1].column_map.get("total") == "cte1"

    def test_empty_cte_list(self):
        """resolve_cte_column_maps returns empty for empty input."""
        assert resolve_cte_column_maps([]) == []

    def test_qualified_column_uses_explicit_source(self):
        """resolve_cte_column_maps uses explicit table prefix for
        qualified column."""
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
        )
        result = resolve_cte_column_maps([cte1])
        assert result[0].column_map.get("amount") == "orders"


class TestNormalizeCteNames:
    """Tests for normalize_cte_names."""

    def test_renames_ctes_sequentially(self):
        """normalize_cte_names renames CTE steps to cte1, cte2."""
        cte1 = RuntimeCteStep(
            cte_name="my_step",
            tables=["my_step"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("my_step.col"))],
        )
        cte2 = RuntimeCteStep(
            cte_name="other_step",
            tables=["my_step"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("my_step.val"))],
        )
        intent = RuntimeIntent(
            tables=["other_step"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("other_step.val"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte1, cte2],
        )
        result = normalize_cte_names(intent)
        assert result.cte_steps[0].cte_name == "cte1"
        assert result.cte_steps[1].cte_name == "cte2"
        assert "cte2" in result.tables

    def test_no_ctes_unchanged(self):
        """normalize_cte_names returns unchanged when no CTE steps."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_cte_names(intent)
        assert result.cte_steps == []

    def test_updates_main_query_refs(self):
        """normalize_cte_names updates references in main query
        expressions."""
        cte = RuntimeCteStep(
            cte_name="old_name",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.x"))],
        )
        intent = RuntimeIntent(
            tables=["old_name"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("old_name.x"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_cte_names(intent)
        assert result.select_cols[0].expr.primary_term == "cte1.x"
        assert "cte1" in result.tables

    def test_renames_to_canonical(self):
        """CTE steps are renamed to cte1, cte2, etc."""
        cte1 = RuntimeCteStep(cte_name="my_aggregation", tables=["orders"])
        cte2 = RuntimeCteStep(cte_name="my_filter", tables=["my_aggregation"])
        intent = RuntimeIntent(
            tables=["my_filter"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte1, cte2],
        )
        result = normalize_cte_names(intent)
        assert result.cte_steps[0].cte_name == "cte1"
        assert result.cte_steps[1].cte_name == "cte2"

    def test_updates_table_references(self):
        """Table references inside CTE steps are updated to new
        names."""
        cte1 = RuntimeCteStep(cte_name="old_cte", tables=["orders"])
        cte2 = RuntimeCteStep(cte_name="second_cte", tables=["old_cte"])
        intent = RuntimeIntent(
            tables=["second_cte"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte1, cte2],
        )
        result = normalize_cte_names(intent)
        assert "cte1" in result.cte_steps[1].tables
        assert "cte2" in result.tables

    def test_no_cte_steps_returns_unchanged(self, minimal_intent):
        """Intent without CTE steps is returned unchanged."""
        result = normalize_cte_names(minimal_intent)
        assert result.tables == minimal_intent.tables

    def test_updates_expressions_in_cte(self):
        """Expression terms referencing old CTE names are updated."""
        cte1 = RuntimeCteStep(
            cte_name="agg_step",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
            output_columns=["amount"],
        )
        cte2 = RuntimeCteStep(
            cte_name="final_step",
            tables=["agg_step"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("agg_step.amount"))],
        )
        intent = RuntimeIntent(
            tables=["final_step"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("final_step.amount"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte1, cte2],
        )
        result = normalize_cte_names(intent)
        main_term = result.select_cols[0].expr.primary_column
        assert "cte2" in main_term
        cte2_term = result.cte_steps[1].select_cols[0].expr.primary_column
        assert "cte1" in cte2_term


class TestEnforceIntentSchema:
    """Tests for enforce_schema."""

    @pytest.fixture
    def validate_schema(self):
        """Schema for validation tests."""
        return SchemaGraph(
            join_paths_multi={},
            schema_hash="",
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={
                        "id": ColumnMetadata(name="id", data_type="integer", value_type="integer"),
                        "amount": ColumnMetadata(name="amount", data_type="numeric", value_type="number"),
                    },
                    foreign_keys=[],
                    primary_key="",
                )
            },
        )

    def test_valid_intent_no_errors(self, validate_schema):
        """enforce_schema returns no errors for valid intent."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        _, errors = enforce_schema(intent, validate_schema)
        assert errors == []

    def test_unknown_table_error(self, validate_schema):
        """enforce_schema reports unknown table."""
        intent = RuntimeIntent(
            tables=["nonexistent"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        _, errors = enforce_schema(intent, validate_schema)
        assert any("Unknown table" in e for e in errors)

    def test_unknown_column_error(self, validate_schema):
        """enforce_schema reports unknown column."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.nonexistent"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        _, errors = enforce_schema(intent, validate_schema)
        assert any("Unknown" in e and "nonexistent" in e for e in errors)

    def test_cte_name_accepted_as_table(self, validate_schema):
        """enforce_schema accepts CTE names as valid tables."""
        cte = RuntimeCteStep(cte_name="cte1")
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        _, errors = enforce_schema(intent, validate_schema)
        assert not any("Unknown table: cte1" in e for e in errors)


class TestReplaceRefsInExprEdgeCases:
    """Edge-case tests for replace_refs_in_expr."""

    def test_replaces_divide_terms(self):
        """replace_refs_in_expr applies replacer to divide terms."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=[], divide=["old.col"])])
        result = replace_refs_in_expr(expr, lambda s: s.replace("old", "new"))
        assert result.add_groups[0].divide == ["new.col"]

    def test_replaces_sub_groups(self):
        """replace_refs_in_expr applies replacer to sub_groups."""
        expr = NormalizedExpr(sub_groups=[MulGroup(multiply=["old.col"])])
        result = replace_refs_in_expr(expr, lambda s: s.replace("old", "new"))
        assert result.sub_groups[0].multiply == ["new.col"]

    def test_identity_replacer_no_change(self):
        """replace_refs_in_expr with identity function returns
        equivalent expr."""
        expr = NormalizedExpr.from_column("t.col")
        result = replace_refs_in_expr(expr, lambda s: s)
        assert result.primary_term == "t.col"

    def test_empty_groups_preserves_add_values(self):
        """replace_refs_in_expr with no groups preserves add_values."""
        expr = NormalizedExpr(add_groups=[], sub_groups=[], add_values=[ExprValue(value=1.0)])
        result = replace_refs_in_expr(expr, lambda s: s.upper())
        assert result.add_values == expr.add_values
        assert result.add_groups == []
        assert result.sub_groups == []


class TestNormalizeCountStarEdgeCases:
    """Edge-case tests for normalize_count_star."""

    def test_fixes_count_in_filters(self):
        """normalize_count_star fixes COUNT(1) in filter expressions."""
        fp = FilterParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(1)"])]),
            op=">",
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp],
        )
        result = normalize_count_star(intent)
        assert result.filters_param[0].left_expr.add_groups[0].multiply == ["COUNT(*)"]

    def test_no_count_unchanged(self):
        """normalize_count_star leaves non-count terms unchanged."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t.name"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = normalize_count_star(intent)
        assert result.select_cols[0].expr.primary_term == "t.name"


class TestSortFunctionsEdgeCases:
    """Edge-case tests for sort functions."""

    def test_sort_select_cols_stable_on_tie(self):
        """sort_select_cols preserves order on signature tie."""
        c1 = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        c2 = SelectCol(expr=NormalizedExpr.from_column("t.b"))
        result = sort_select_cols([c2, c1])
        assert result[0].expr.primary_term == "t.a"

    def test_sort_filters_empty(self):
        """sort_filters returns empty for empty input."""
        assert sort_filters([]) == []

    def test_sort_having_empty(self):
        """sort_having returns empty for empty input."""
        assert sort_having([]) == []

    def test_sort_order_by_empty(self):
        """sort_order_by_cols returns empty for empty input."""
        assert sort_order_by_cols([]) == []


class TestSimplifyExprEdgeCases:
    """Edge-case tests for simplify_expr."""

    def test_empty_expr(self):
        """simplify_expr handles empty expression."""
        expr = NormalizedExpr()
        result = _simplify_expr(expr)
        assert result.add_groups == []
        assert result.add_values == []

    def test_sub_value_folding(self):
        """simplify_expr folds sub_values correctly."""
        expr = NormalizedExpr(
            sub_values=[ExprValue(value=5.0), ExprValue(value=3.0)],
        )
        result = _simplify_expr(expr)
        assert len(result.sub_values) == 1
        assert result.sub_values[0].value == 8.0

    def test_preserves_scalar_func(self):
        """simplify_expr preserves scalar_func on expression."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.col"])],
            scalar_func="upper",
        )
        result = _simplify_expr(expr)
        assert result.scalar_func == "upper"


class TestNormalizeCountStarCte:
    """CTE path tests for normalize_count_star."""

    def test_cte_count_1_normalised(self):
        """COUNT(1) in a CTE select_col is converted to COUNT(*)."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(1)"])]))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_count_star(intent)
        assert result.cte_steps[0].select_cols[0].expr.add_groups[0].multiply == ["COUNT(*)"]


class TestSimplifyIntentExprsCte:
    """CTE path tests for simplify_exprs."""

    def test_cte_constant_folded(self):
        """Constant values in CTE expressions are folded."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[
                SelectCol(
                    expr=NormalizedExpr(
                        add_values=[ExprValue(value=3.0), ExprValue(value=7.0)],
                    )
                ),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = simplify_exprs(intent)
        assert len(result.cte_steps[0].select_cols[0].expr.add_values) == 1
        assert result.cte_steps[0].select_cols[0].expr.add_values[0].value == 10.0


class TestNormalizeIntentFiltersHavingsCte:
    """CTE path tests for normalize_filters_havings."""

    def test_cte_filters_deduped(self):
        """Duplicate filters in a CTE step are deduplicated."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.x"), op="=", value_type="string")
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp, fp],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_filters_havings(intent)
        assert len(result.cte_steps[0].filters_param) == 1

    def test_cte_having_ops_normalised(self):
        """Operators in CTE havings are normalised."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op="==",
            value_type="integer",
        )
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[hp],
            param_values={},
            output_columns=[],
        )
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = normalize_filters_havings(intent)
        assert result.cte_steps[0].having_param[0].op == "="


class TestForceMainGrainWhenUsingGroupedCte:
    """Tests for force_main_grain_when_using_grouped_cte."""

    def test_no_promotion_without_main_aggregation(self):
        """Main grain stays row_level when selecting from grouped CTE
        without own aggregation."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.product_id")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("orders.product_id")],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=["product_id", "order_count"],
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("cte1.product_id")),
                SelectCol(expr=NormalizedExpr.from_column("cte1.order_count")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = force_main_grain_when_using_grouped_cte(intent)
        assert result.grain == "row_level"

    def test_promotes_when_main_has_aggregation(self):
        """Main grain is promoted to grouped when it aggregates over a
        grouped CTE."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.product_id")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id")),
            ],
            group_by_cols=[NormalizedExpr.from_column("orders.product_id")],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=["product_id", "order_count"],
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("cte1.product_id")),
                SelectCol(expr=NormalizedExpr.from_agg("avg", "cte1.order_count")),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            cte_steps=[cte],
        )
        result = force_main_grain_when_using_grouped_cte(intent)
        assert result.grain == "grouped"

    def test_already_grouped_unchanged(self):
        """Intent that is already grouped is not modified."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("t.a")),
                SelectCol(expr=NormalizedExpr.from_agg("count", "t.b")),
            ],
            group_by_cols=[NormalizedExpr.from_column("t.a")],
            order_by_cols=[],
            filters_param=[],
        )
        result = force_main_grain_when_using_grouped_cte(intent)
        assert result.grain == "grouped"
