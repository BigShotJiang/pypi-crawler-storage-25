"""Tests for sql_gen module: join topology, rendering, normalization."""

from unittest.mock import MagicMock, patch

from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    FKEdge,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import (
    ExprValue,
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    OrderByCol,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
)
from text2sql.sql_gen import (
    JOIN_PLACEHOLDER,
    _analyze_join_topology,
    _candidate_join_paths_for_tables,
    _format_join_candidate_semantic,
    _format_sql_arg,
    _join_clause_from_signature,
    _join_path_signature_for_path,
    _rank_join_candidates,
    _render_expr_sql,
    _render_group_sql,
    _score_join_path,
    build_deterministic_sql,
    build_repair_prompt,
    cte_to_intent_for_ranking,
    inject_join_into_deterministic_sql,
    join_candidate_map,
    join_hints_multi,
    normalize_cte_sql,
    normalize_where_having_predicates,
    physical_tables_for_join_hints,
    reorder_sql_joins_canonical,
)


class TestPhysicalTablesForJoinHints:
    """Tests for physical_tables_for_join_hints."""

    def test_filters_cte_and_unknown_names(self):
        """Keeps only names that exist as schema table keys."""
        schema = SchemaGraph(
            tables={
                "customer": TableMetadata(
                    name="customer",
                    columns={},
                    primary_key=[],
                    foreign_keys=[],
                ),
                "payment": TableMetadata(
                    name="payment",
                    columns={},
                    primary_key=[],
                    foreign_keys=[],
                ),
            },
            join_paths_multi={},
            schema_hash="h",
        )
        got = physical_tables_for_join_hints(
            ["cte2", "customer", "payment", "cte1", "ghost"],
            schema,
        )
        assert got == ["customer", "payment"]

    def test_case_insensitive_match(self):
        """Resolves intent casing to canonical schema keys."""
        schema = SchemaGraph(
            tables={
                "film": TableMetadata(
                    name="film",
                    columns={},
                    primary_key=[],
                    foreign_keys=[],
                ),
            },
            join_paths_multi={},
            schema_hash="h",
        )
        assert physical_tables_for_join_hints(["Film"], schema) == ["film"]

    def test_empty_input(self):
        """None or empty tables yields empty list."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        assert physical_tables_for_join_hints(None, schema) == []
        assert physical_tables_for_join_hints([], schema) == []


class TestJoinCandidateMap:
    """Tests for join_candidate_map."""

    def test_builds_map(self):
        """join_candidate_map builds candidate_id -> signature map."""
        hints = {
            "candidates": [
                {
                    "candidate_id": "J01",
                    "join_path_signature": ["orders.customer_id->customers.customer_id"],
                },
                {
                    "candidate_id": "J02",
                    "join_path_signature": ["orders.product_id->products.product_id"],
                },
            ]
        }
        result = join_candidate_map(hints)
        assert "J01" in result
        assert "J02" in result
        assert result["J01"] == ["orders.customer_id->customers.customer_id"]

    def test_empty_candidates(self):
        """join_candidate_map returns empty for no candidates."""
        assert join_candidate_map({"candidates": []}) == {}

    def test_missing_candidates_key(self):
        """join_candidate_map returns empty for missing key."""
        assert join_candidate_map({}) == {}


class TestAnalyzeJoinTopology:
    """Tests for analyze_join_topology."""

    def test_linear_topology(self):
        """analyze_join_topology detects linear chain."""
        sig = [
            "orders.customer_id->customers.customer_id",
        ]
        topo, anchor, leaves = _analyze_join_topology(sig)
        assert topo == "linear"
        assert len(leaves) == 2

    def test_star_topology(self):
        """analyze_join_topology detects star pattern with 3+
        branches."""
        sig = [
            "orders.customer_id->customers.customer_id",
            "orders.product_id->products.product_id",
            "orders.store_id->stores.store_id",
        ]
        topo, anchor, leaves = _analyze_join_topology(sig)
        assert topo == "star"
        assert anchor == "orders"
        assert sorted(leaves) == ["customers", "products", "stores"]

    def test_empty_sig(self):
        """analyze_join_topology returns none for empty sig."""
        topo, anchor, leaves = _analyze_join_topology([])
        assert topo == "none"
        assert anchor == ""
        assert leaves == []


class TestRenderGroupSql:
    """Tests for _render_group_sql."""

    def test_bare_column(self):
        """_render_group_sql renders bare column."""
        g = MulGroup(multiply=["orders.amount"])
        assert _render_group_sql(g) == "orders.amount"

    def test_with_agg_func(self):
        """_render_group_sql renders with aggregation."""
        g = MulGroup(multiply=["orders.amount"], agg_func="sum")
        result = _render_group_sql(g)
        assert result == "SUM(orders.amount)"

    def test_with_coefficient(self):
        """_render_group_sql renders coefficient."""
        g = MulGroup(coefficient=2.0, multiply=["t.x"])
        result = _render_group_sql(g)
        assert "2.0" in result
        assert "t.x" in result

    def test_with_divide(self):
        """_render_group_sql renders division."""
        g = MulGroup(multiply=["t.a"], divide=["t.b"])
        result = _render_group_sql(g)
        assert "t.a" in result
        assert "t.b" in result

    def test_with_scalar_func(self):
        """_render_group_sql wraps with scalar function."""
        g = MulGroup(multiply=["t.x"], scalar_func="abs")
        result = _render_group_sql(g)
        assert result == "ABS(t.x)"

    def test_with_inner_scalar_func(self):
        """_render_group_sql wraps with inner scalar function."""
        g = MulGroup(multiply=["t.x"], inner_scalar_func="abs", agg_func="sum")
        result = _render_group_sql(g)
        assert "ABS(t.x)" in result
        assert "SUM" in result

    def test_empty_multiply(self):
        """_render_group_sql with empty multiply returns '1'."""
        g = MulGroup(multiply=[])
        assert _render_group_sql(g) == "1"

    def test_coeff_param_key(self):
        """_render_group_sql uses coeff_param_key."""
        g = MulGroup(multiply=["t.x"], coeff_param_key="s1")
        result = _render_group_sql(g)
        assert ":s1" in result


class TestRenderExprSql:
    """Tests for _render_expr_sql."""

    def test_single_column(self):
        """_render_expr_sql renders single column expression."""
        expr = NormalizedExpr.from_column("t.x")
        assert _render_expr_sql(expr) == "t.x"

    def test_addition(self):
        """_render_expr_sql renders addition."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.a"]), MulGroup(multiply=["t.b"])],
        )
        result = _render_expr_sql(expr)
        assert "+" in result

    def test_subtraction(self):
        """_render_expr_sql renders subtraction."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.a"])],
            sub_groups=[MulGroup(multiply=["t.b"])],
        )
        result = _render_expr_sql(expr)
        assert "-" in result


class TestFormatSqlArg:
    """Tests for _format_sql_arg."""

    def test_with_key(self):
        """_format_sql_arg returns placeholder for key."""
        assert _format_sql_arg("p1", "ignored") == ":p1"

    def test_empty_key_string_value(self):
        """_format_sql_arg quotes string when key is empty."""
        assert _format_sql_arg("", "hello") == "'hello'"

    def test_empty_key_numeric_value(self):
        """_format_sql_arg returns str for numeric when key is empty."""
        assert _format_sql_arg("", 42) == "42"

    def test_empty_key_float_value(self):
        """_format_sql_arg returns str for float when key is empty."""
        assert _format_sql_arg("", 3.14) == "3.14"


class TestJoinPathSignatureForPath:
    """Tests for join_path_signature_for_path."""

    def test_single_edge(self):
        """join_path_signature_for_path generates signature for single
        edge."""
        path = [
            {
                "src_table": "orders",
                "src_cols": ["customer_id"],
                "dst_table": "customers",
                "dst_cols": ["customer_id"],
            }
        ]
        result = _join_path_signature_for_path(path)
        assert result == ["orders.customer_id->customers.customer_id"]

    def test_multiple_edges(self):
        """join_path_signature_for_path generates signature for multiple
        edges."""
        path = [
            {
                "src_table": "orders",
                "src_cols": ["customer_id"],
                "dst_table": "customers",
                "dst_cols": ["customer_id"],
            },
            {
                "src_table": "orders",
                "src_cols": ["product_id"],
                "dst_table": "products",
                "dst_cols": ["product_id"],
            },
        ]
        result = _join_path_signature_for_path(path)
        assert len(result) == 2

    def test_empty_path(self):
        """join_path_signature_for_path returns empty for empty path."""
        assert _join_path_signature_for_path([]) == []

    def test_multi_column_key(self):
        """join_path_signature_for_path handles composite keys."""
        path = [
            {
                "src_table": "t1",
                "src_cols": ["a", "b"],
                "dst_table": "t2",
                "dst_cols": ["c", "d"],
            }
        ]
        result = _join_path_signature_for_path(path)
        assert result == ["t1.a,b->t2.c,d"]


class TestCteToIntentForRanking:
    """Tests for cte_to_intent_for_ranking."""

    def test_basic_conversion(self):
        """cte_to_intent_for_ranking creates RuntimeIntent from CTE."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t1", "t2"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("t1.id"))],
            group_by_cols=[NormalizedExpr.from_column("t1.name")],
            output_columns=["id"],
            order_by_cols=[OrderByCol(expr=NormalizedExpr.from_column("t1.name"))],
            filters_param=[FilterParam(left_expr=NormalizedExpr.from_column("t1.status"), op="=")],
        )
        intent = cte_to_intent_for_ranking(cte)
        assert intent.tables == ["t1", "t2"]
        assert intent.grain == "grouped"
        assert len(intent.select_cols) == 1
        assert len(intent.group_by_cols) == 1
        assert len(intent.filters_param) == 1
        assert intent.cte_steps == []

    def test_preserves_limit(self):
        """cte_to_intent_for_ranking preserves limit."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t1"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            output_columns=[],
            limit=10,
        )
        intent = cte_to_intent_for_ranking(cte)
        assert intent.limit == 10

    def test_preserves_column_map(self):
        """cte_to_intent_for_ranking preserves column_map."""
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t1"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            output_columns=[],
            column_map={"name": "t1"},
        )
        intent = cte_to_intent_for_ranking(cte)
        assert intent.column_map == {"name": "t1"}


class TestNormalizeWhereHavingPredicates:
    """Tests for normalize_where_having_predicates."""

    def test_swaps_param_left_col_right(self):
        """normalize_where_having_predicates swaps :param = table.col to
        table.col = :param."""
        sql = "SELECT * FROM t WHERE :p1 = t.col"
        result = normalize_where_having_predicates(sql)
        assert "t.col = :p1" in result

    def test_preserves_col_left(self):
        """normalize_where_having_predicates keeps col = :param
        unchanged."""
        sql = "SELECT * FROM t WHERE t.col = :p1"
        result = normalize_where_having_predicates(sql)
        assert "t.col = :p1" in result

    def test_swaps_in_having(self):
        """normalize_where_having_predicates swaps in HAVING clause."""
        sql = "SELECT COUNT(t.id) FROM t GROUP BY t.name HAVING :p1 > COUNT(t.id)"
        result = normalize_where_having_predicates(sql)
        assert result is not None

    def test_no_where_or_having(self):
        """normalize_where_having_predicates returns unchanged SQL
        without WHERE/HAVING."""
        sql = "SELECT * FROM t"
        assert normalize_where_having_predicates(sql) == sql

    def test_numeric_left_col_right(self):
        """normalize_where_having_predicates swaps numeric literal left
        of column."""
        sql = "SELECT * FROM t WHERE 5 > t.col"
        result = normalize_where_having_predicates(sql)
        assert "t.col" in result


class TestReorderSqlJoinsCanonical:
    """Tests for reorder_sql_joins_canonical."""

    def test_empty_sig_returns_original(self):
        """reorder_sql_joins_canonical returns original for empty
        sig."""
        sql = "SELECT * FROM orders JOIN customers ON orders.cid = customers.id"
        assert reorder_sql_joins_canonical(sql, []) == sql

    def test_no_from_returns_original(self):
        """reorder_sql_joins_canonical returns original without FROM
        clause."""
        sql = "SELECT 1"
        assert reorder_sql_joins_canonical(sql, ["a.col->b.col"]) == sql


class TestAnalyzeJoinTopologyEdgeCases:
    """Edge-case tests for analyze_join_topology."""

    def test_three_table_linear_chain(self):
        """analyze_join_topology detects 3-table linear chain."""
        sig = [
            "a.col->b.col",
            "b.col->c.col",
        ]
        topo, anchor, leaves = _analyze_join_topology(sig)
        assert topo == "linear"
        assert sorted(leaves) == ["a", "c"]

    def test_tree_topology(self):
        """analyze_join_topology detects tree pattern."""
        sig = [
            "a.col->b.col",
            "b.col->c.col",
            "b.col->d.col",
        ]
        topo, anchor, leaves = _analyze_join_topology(sig)
        assert topo in ("star", "tree")

    def test_single_edge(self):
        """analyze_join_topology handles single edge."""
        sig = ["orders.cid->customers.id"]
        topo, anchor, leaves = _analyze_join_topology(sig)
        assert len(leaves) == 2

    def test_no_arrow_items(self):
        """analyze_join_topology returns none for items without
        arrows."""
        sig = ["no_arrow"]
        topo, anchor, leaves = _analyze_join_topology(sig)
        assert topo == "none"


class TestJoinCandidateMapEdgeCases:
    """Edge-case tests for join_candidate_map."""

    def test_invalid_types_skipped(self):
        """join_candidate_map skips entries with invalid types."""
        hints = {
            "candidates": [
                {"candidate_id": 123, "join_path_signature": ["a.col->b.col"]},
                {"candidate_id": "J01", "join_path_signature": "not_a_list"},
            ]
        }
        result = join_candidate_map(hints)
        assert len(result) == 0

    def test_multiple_candidates(self):
        """join_candidate_map handles many candidates."""
        candidates = [
            {
                "candidate_id": f"J{i:02d}",
                "join_path_signature": [f"t{i}.col->t{i + 1}.col"],
            }
            for i in range(1, 6)
        ]
        result = join_candidate_map({"candidates": candidates})
        assert len(result) == 5

    def test_empty_signature_included(self):
        """join_candidate_map includes candidate with empty join_path_signature."""
        hints = {"candidates": [{"candidate_id": "J00", "join_path_signature": []}]}
        result = join_candidate_map(hints)
        assert result == {"J00": []}


class TestRenderGroupSqlEdgeCases:
    """Edge-case tests for _render_group_sql."""

    def test_multiply_divide_combined(self):
        """_render_group_sql renders multiply and divide together."""
        g = MulGroup(multiply=["t.revenue"], divide=["t.count"])
        result = _render_group_sql(g)
        assert "t.revenue" in result
        assert "t.count" in result
        assert "/" in result

    def test_coefficient_and_agg(self):
        """_render_group_sql renders coefficient with aggregation."""
        g = MulGroup(coefficient=1.5, multiply=["t.x"], agg_func="sum")
        result = _render_group_sql(g)
        assert "1.5" in result
        assert "SUM" in result

    def test_multiple_multiply_terms(self):
        """_render_group_sql joins multiple multiply terms."""
        g = MulGroup(multiply=["t.a", "t.b"])
        result = _render_group_sql(g)
        assert "t.a * t.b" in result


class TestRenderExprSqlEdgeCases:
    """Edge-case tests for _render_expr_sql."""

    def test_with_agg_func(self):
        """_render_expr_sql renders agg_func on expr level."""
        expr = NormalizedExpr.from_agg("count", "t.id")
        result = _render_expr_sql(expr)
        assert "COUNT" in result
        assert "t.id" in result

    def test_with_scalar_func(self):
        """_render_expr_sql renders scalar_func on expr level."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.x"])],
            scalar_func="round",
            scalar_func_args=[2],
        )
        result = _render_expr_sql(expr)
        assert "ROUND" in result

    def test_with_add_values(self):
        """_render_expr_sql renders add_values."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.x"])],
            add_values=[ExprValue(value=10, param_key="p1")],
        )
        result = _render_expr_sql(expr)
        assert ":p1" in result

    def test_with_sub_values(self):
        """_render_expr_sql renders sub_values."""
        expr = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.x"])],
            sub_values=[ExprValue(value=5, param_key="p2")],
        )
        result = _render_expr_sql(expr)
        assert ":p2" in result

    def test_empty_groups(self):
        """_render_expr_sql renders 0 for empty groups."""
        expr = NormalizedExpr()
        result = _render_expr_sql(expr)
        assert "0" in result


class TestNormalizeCTESql:
    """Tests for normalize_cte_sql."""

    def test_no_cte_returns_unchanged(self):
        """SQL without CTE is returned unchanged."""
        mock_dialect = MagicMock()
        mock_dialect.extract_cte_bodies.return_value = {}
        with patch("text2sql.sql_gen.get_dialect", return_value=mock_dialect):
            sql = "SELECT * FROM orders"
            assert normalize_cte_sql(sql, {}) == sql

    def test_normalizes_cte_body(self):
        """CTE body predicates are normalized when extracted."""
        mock_dialect = MagicMock()
        mock_dialect.extract_cte_bodies.return_value = {"cte1": "SELECT * FROM orders WHERE 'shipped' = orders.status"}
        with patch("text2sql.sql_gen.get_dialect", return_value=mock_dialect):
            sql = "WITH cte1 AS (SELECT * FROM orders WHERE 'shipped' = orders.status) SELECT * FROM cte1"
            result = normalize_cte_sql(sql, {})
            assert "orders.status" in result

    def test_empty_cte_join_sigs(self):
        """Empty cte_join_sigs dict skips join reordering but still
        normalizes predicates."""
        mock_dialect = MagicMock()
        mock_dialect.extract_cte_bodies.return_value = {"cte1": "SELECT * FROM orders WHERE orders.status = 'active'"}
        with patch("text2sql.sql_gen.get_dialect", return_value=mock_dialect):
            sql = "WITH cte1 AS (SELECT * FROM orders WHERE orders.status = 'active') SELECT * FROM cte1"
            result = normalize_cte_sql(sql, {})
            assert "orders.status" in result


class TestCandidateJoinPathsForTables:
    """Tests for candidate_join_paths_for_tables."""

    def test_single_table_returns_empty_path(self):
        """Single table returns [[]] (no joins needed)."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        result = _candidate_join_paths_for_tables(schema, ["orders"])
        assert result == [[]]

    def test_two_tables_with_path(self):
        """Two tables with join path returns candidate edges."""
        edge = {
            "src_table": "orders",
            "src_cols": ["customer_id"],
            "dst_table": "customers",
            "dst_cols": ["id"],
        }
        schema = SchemaGraph(
            tables={
                "orders": TableMetadata(name="orders", columns={}, foreign_keys=[], primary_key=""),
                "customers": TableMetadata(name="customers", columns={}, foreign_keys=[], primary_key=""),
            },
            join_paths_multi={
                "orders": {"customers": [[edge]]},
                "customers": {
                    "orders": [
                        [
                            {
                                "src_table": "customers",
                                "src_cols": ["id"],
                                "dst_table": "orders",
                                "dst_cols": ["customer_id"],
                            }
                        ]
                    ]
                },
            },
            schema_hash="",
        )
        result = _candidate_join_paths_for_tables(schema, ["orders", "customers"])
        assert len(result) >= 1
        assert any(len(path) > 0 for path in result)

    def test_empty_tables_list(self):
        """Empty tables list returns [[]]."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        result = _candidate_join_paths_for_tables(schema, [])
        assert result == [[]]

    def test_deduplicates_tables(self):
        """Duplicate tables are deduplicated."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        result = _candidate_join_paths_for_tables(schema, ["orders", "orders"])
        assert result == [[]]


class TestScoreJoinPath:
    """Tests for score_join_path."""

    def test_empty_edges_returns_max_base(self):
        """Empty edge list gets the max base score (20 - 0*3 = 20)."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        score = _score_join_path([], intent, schema)
        assert score == 20.0

    def test_forward_fk_scores_higher(self):
        """Edge with forward FK scores higher than reverse FK."""
        fk = FKEdge(
            src_table="orders",
            src_cols=["customer_id"],
            dst_table="customers",
            dst_cols=["id"],
        )
        orders_meta = TableMetadata(
            name="orders",
            columns={
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    role=ColumnRole.IDENTIFIER.value,
                ),
            },
            foreign_keys=[fk],
            primary_key="",
        )
        customers_meta = TableMetadata(
            name="customers",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                ),
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(
            tables={"orders": orders_meta, "customers": customers_meta},
            join_paths_multi={},
            schema_hash="",
        )
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        forward_edge = {
            "src_table": "orders",
            "src_cols": ["customer_id"],
            "dst_table": "customers",
            "dst_cols": ["id"],
        }
        reverse_edge = {
            "src_table": "customers",
            "src_cols": ["id"],
            "dst_table": "orders",
            "dst_cols": ["customer_id"],
        }
        forward_score = _score_join_path([forward_edge], intent, schema)
        reverse_score = _score_join_path([reverse_edge], intent, schema)
        assert forward_score > reverse_score

    def test_filter_column_bonus(self):
        """Edge connecting to a filtered column gets a bonus."""
        fk = FKEdge(
            src_table="orders",
            src_cols=["customer_id"],
            dst_table="customers",
            dst_cols=["id"],
        )
        orders_meta = TableMetadata(
            name="orders",
            columns={
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    role=ColumnRole.IDENTIFIER.value,
                )
            },
            foreign_keys=[fk],
            primary_key="",
        )
        customers_meta = TableMetadata(
            name="customers",
            columns={
                "id": ColumnMetadata(
                    name="id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                )
            },
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(
            tables={"orders": orders_meta, "customers": customers_meta},
            join_paths_multi={},
            schema_hash="",
        )
        edge = {
            "src_table": "orders",
            "src_cols": ["customer_id"],
            "dst_table": "customers",
            "dst_cols": ["id"],
        }
        intent_no_filter = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        intent_with_filter = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("customers.id"),
                    op="=",
                    value_type="integer",
                )
            ],
        )
        score_no = _score_join_path([edge], intent_no_filter, schema)
        score_yes = _score_join_path([edge], intent_with_filter, schema)
        assert score_yes > score_no


class TestFormatJoinCandidateSemantic:
    """Tests for format_join_candidate_semantic."""

    def test_no_edges_single_table(self):
        """Empty edges returns single table description."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        result = _format_join_candidate_semantic("J00", [], schema, 0.0)
        assert "Single table" in result

    def test_forward_fk_labelled(self):
        """Edge matching a foreign key is labelled Forward FK."""
        orders_meta = TableMetadata(
            name="orders",
            columns={
                "customer_id": ColumnMetadata(
                    name="customer_id",
                    data_type="integer",
                    value_type="integer",
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=100,
                    is_foreign_key=True,
                ),
            },
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    dst_table="customers",
                    src_cols=["customer_id"],
                    dst_cols=["customer_id"],
                )
            ],
            primary_key="order_id",
        )
        schema = SchemaGraph(tables={"orders": orders_meta}, join_paths_multi={}, schema_hash="h")
        edges = [
            {
                "src_table": "orders",
                "dst_table": "customers",
                "src_cols": ["customer_id"],
                "dst_cols": ["customer_id"],
            }
        ]
        result = _format_join_candidate_semantic("J01", edges, schema, 10.0)
        assert "Forward FK" in result

    def test_reverse_fk_default(self):
        """Edge not matching any FK is labelled Reverse FK."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        edges = [
            {
                "src_table": "customers",
                "dst_table": "orders",
                "src_cols": ["customer_id"],
                "dst_cols": ["customer_id"],
            }
        ]
        result = _format_join_candidate_semantic("J01", edges, schema, 5.0)
        assert "Reverse FK" in result

    def test_empty_edges_single_table(self):
        """Empty edges produces single table label."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        result = _format_join_candidate_semantic("J01", [], schema, 0.0)
        assert "Single table" in result
        assert "J01" in result

    def test_forward_fk_label(self):
        """Forward FK edge is labeled correctly."""
        fk = FKEdge(
            src_table="orders",
            src_cols=["customer_id"],
            dst_table="customers",
            dst_cols=["id"],
        )
        orders_meta = TableMetadata(
            name="orders",
            columns={},
            foreign_keys=[fk],
            primary_key="",
        )
        customers_meta = TableMetadata(
            name="customers",
            columns={},
            foreign_keys=[],
            primary_key="",
        )
        schema = SchemaGraph(
            tables={"orders": orders_meta, "customers": customers_meta},
            join_paths_multi={},
            schema_hash="",
        )
        edge = {
            "src_table": "orders",
            "src_cols": ["customer_id"],
            "dst_table": "customers",
            "dst_cols": ["id"],
        }
        result = _format_join_candidate_semantic("J01", [edge], schema, 35.0)
        assert "Forward FK" in result
        assert "35.0" in result

    def test_reverse_fk_label(self):
        """Reverse FK edge is labeled correctly."""
        customers_meta = TableMetadata(name="customers", columns={}, foreign_keys=[], primary_key="")
        orders_meta = TableMetadata(name="orders", columns={}, foreign_keys=[], primary_key="")
        schema = SchemaGraph(
            tables={"orders": orders_meta, "customers": customers_meta},
            join_paths_multi={},
            schema_hash="",
        )
        edge = {
            "src_table": "customers",
            "src_cols": ["id"],
            "dst_table": "orders",
            "dst_cols": ["customer_id"],
        }
        result = _format_join_candidate_semantic("J02", [edge], schema, 10.0)
        assert "Reverse FK" in result

    def test_score_in_output(self):
        """Score value appears in formatted output."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        edge = {
            "src_table": "a",
            "src_cols": ["x"],
            "dst_table": "b",
            "dst_cols": ["y"],
        }
        result = _format_join_candidate_semantic("J01", [edge], schema, 42.5)
        assert "42.5" in result


class TestRankJoinCandidates:
    """Tests for rank_join_candidates."""

    def test_single_candidate_unchanged(self):
        """Single candidate returned as-is."""
        edges = [
            {
                "src_table": "orders",
                "dst_table": "customers",
                "src_cols": ["customer_id"],
                "dst_cols": ["customer_id"],
            }
        ]
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = _rank_join_candidates([edges], intent, schema)
        assert len(result) == 1

    def test_empty_list(self):
        """Empty candidates returns empty."""
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = _rank_join_candidates([], intent, schema)
        assert result == []


class TestJoinHintsMulti:
    """Tests for join_hints_multi."""

    def test_single_table_returns_j00(self):
        """Single table returns J00 with empty signature."""
        schema = SchemaGraph(
            tables={"orders": TableMetadata(name="orders", columns={}, foreign_keys=[], primary_key="order_id")},
            join_paths_multi={},
            schema_hash="h",
        )
        result = join_hints_multi(schema, ["orders"])
        assert len(result["candidates"]) == 1
        assert result["candidates"][0]["candidate_id"] == "J00"
        assert result["candidates"][0]["edge_count"] == 0

    @patch("text2sql.sql_gen._rank_join_candidates")
    @patch(
        "text2sql.sql_gen._candidate_join_paths_for_tables",
        return_value=[
            [
                {
                    "src_table": "orders",
                    "dst_table": "customers",
                    "src_cols": ["cid"],
                    "dst_cols": ["cid"],
                }
            ]
        ],
    )
    def test_multi_table_ranked(self, mock_candidates, mock_rank):
        """Multi-table candidates ranked via rank_join_candidates."""
        mock_rank.return_value = [
            [
                {
                    "src_table": "orders",
                    "dst_table": "customers",
                    "src_cols": ["cid"],
                    "dst_cols": ["cid"],
                }
            ]
        ]
        schema = SchemaGraph(
            tables={
                "orders": TableMetadata(name="orders", columns={}, foreign_keys=[], primary_key="order_id"),
                "customers": TableMetadata(
                    name="customers",
                    columns={},
                    foreign_keys=[],
                    primary_key="customer_id",
                ),
            },
            join_paths_multi={},
            schema_hash="h",
        )
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = join_hints_multi(schema, ["orders", "customers"], intent)
        assert result["candidates"][0]["candidate_id"] == "J01"
        assert result["candidates"][0]["edge_count"] == 1


class TestBuildRepairPrompt:
    """Tests for build_repair_prompt."""

    @patch("text2sql.sql_gen.EngineConfig")
    def test_returns_system_and_user(self, mock_ec):
        """Returns tuple of (system_prompt, user_prompt)."""
        mock_ec.TYPE = "postgresql"
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        system, user = build_repair_prompt(
            schema,
            "show orders",
            "SELECT bad",
            "error",
            "explanation",
            {"candidates": []},
        )
        assert isinstance(system, str)
        assert isinstance(user, str)
        assert "error" in user.lower() or "explanation" in user.lower()

    @patch("text2sql.sql_gen.EngineConfig")
    def test_databricks_dialect_name(self, mock_ec):
        """Databricks engine uses Spark dialect label."""
        mock_ec.TYPE = "databricks"
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        system, user = build_repair_prompt(schema, "q", "SELECT 1", "err", "nl", {"candidates": []})
        assert "Spark" in user

    @patch("text2sql.sql_gen.EngineConfig")
    def test_unnecessary_tables_constraint(self, mock_ec):
        """Unnecessary tables error adds removal constraints."""
        mock_ec.TYPE = "postgresql"
        schema = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="h")
        _, user = build_repair_prompt(
            schema,
            "q",
            "SELECT 1",
            "err",
            "Query includes unnecessary tables",
            {"candidates": []},
        )
        assert "unnecessary" in user.lower()


class TestBuildDeterministicSql:
    """Unit tests for build_deterministic_sql from RuntimeIntent."""

    @patch("text2sql.sql_gen.EngineConfig")
    def test_row_level_select_from_single_table(self, mock_ec):
        """Row-level intent produces SELECT, FROM, no GROUP BY."""
        mock_ec.TYPE = "postgresql"
        intent = RuntimeIntent(
            tables=["t1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.a"])], sub_groups=[])),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        sql = build_deterministic_sql(intent)
        assert "SELECT" in sql
        assert "FROM t1" in sql
        assert "GROUP BY" not in sql
        assert "WHERE" not in sql

    @patch("text2sql.sql_gen.EngineConfig")
    def test_grouped_has_group_by_and_having(self, mock_ec):
        """Grouped intent produces GROUP BY and HAVING when present."""
        mock_ec.TYPE = "postgresql"
        intent = RuntimeIntent(
            tables=["t1"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.x"])], sub_groups=[])),
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(multiply=["t1.id"], agg_func="count")],
                        sub_groups=[],
                    )
                ),
            ],
            group_by_cols=[NormalizedExpr(add_groups=[MulGroup(multiply=["t1.x"])], sub_groups=[])],
            order_by_cols=[],
            filters_param=[],
            having_param=[
                HavingParam(
                    left_expr=NormalizedExpr(
                        add_groups=[MulGroup(multiply=["t1.id"], agg_func="count")],
                        sub_groups=[],
                    ),
                    op=">",
                    param_key="h1",
                ),
            ],
        )
        sql = build_deterministic_sql(intent)
        assert "GROUP BY" in sql
        assert "HAVING" in sql
        assert "t1.x" in sql

    @patch("text2sql.sql_gen.EngineConfig")
    def test_date_window_filter_renders_range(self, mock_ec):
        """date_window filter with start/end renders two predicates."""
        mock_ec.TYPE = "postgresql"
        intent = RuntimeIntent(
            tables=["t1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.d"])], sub_groups=[])),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.d"])], sub_groups=[]),
                    value_type="date_window",
                    raw_value={"start": "2020-01-01", "end": "2020-12-31"},
                ),
            ],
            having_param=[],
        )
        sql = build_deterministic_sql(intent)
        assert ">=" in sql and "2020-01-01" in sql
        assert "<=" in sql and "2020-12-31" in sql

    @patch("text2sql.sql_gen.EngineConfig")
    def test_cte_with_output_aliases(self, mock_ec):
        """CTE step is emitted with WITH and output column aliases."""
        mock_ec.TYPE = "postgresql"
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t1"],
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.id"])], sub_groups=[])),
                SelectCol(
                    expr=NormalizedExpr(
                        add_groups=[MulGroup(multiply=["t1.amt"], agg_func="sum")],
                        sub_groups=[],
                    )
                ),
            ],
            output_columns=["id", "total_amt"],
            group_by_cols=[NormalizedExpr(add_groups=[MulGroup(multiply=["t1.id"])], sub_groups=[])],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            column_map={},
            output_column_metadata={},
            description="",
            limit=None,
        )
        intent = RuntimeIntent(
            tables=["cte1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["cte1.id"])], sub_groups=[])),
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["cte1.total_amt"])], sub_groups=[])),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            cte_steps=[cte],
        )
        sql = build_deterministic_sql(intent)
        assert "WITH" in sql
        assert "cte1 AS" in sql
        assert "AS id" in sql or "AS total_amt" in sql
        assert "FROM cte1" in sql

    @patch("text2sql.sql_gen.EngineConfig")
    def test_limit_rendered(self, mock_ec):
        """Intent with limit produces LIMIT clause."""
        mock_ec.TYPE = "postgresql"
        intent = RuntimeIntent(
            tables=["t1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.a"])], sub_groups=[])),
            ],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            limit=10,
        )
        sql = build_deterministic_sql(intent)
        assert "LIMIT 10" in sql

    @patch("text2sql.sql_gen.EngineConfig")
    def test_order_by_with_direction(self, mock_ec):
        """ORDER BY clause includes expression and direction."""
        mock_ec.TYPE = "postgresql"
        intent = RuntimeIntent(
            tables=["t1"],
            grain="row_level",
            select_cols=[
                SelectCol(expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.a"])], sub_groups=[])),
            ],
            group_by_cols=[],
            order_by_cols=[
                OrderByCol(
                    expr=NormalizedExpr(add_groups=[MulGroup(multiply=["t1.a"])], sub_groups=[]),
                    direction="desc",
                ),
            ],
            filters_param=[],
            having_param=[],
        )
        sql = build_deterministic_sql(intent)
        assert "ORDER BY" in sql
        assert "DESC" in sql


class TestJoinClauseFromSignature:
    """Tests for _join_clause_from_signature."""

    def test_single_edge(self):
        """One segment produces one JOIN clause."""
        sig = ["a.fk->b.pk"]
        out = _join_clause_from_signature(sig)
        assert "JOIN b ON" in out
        assert "a.fk = b.pk" in out

    def test_multiple_edges(self):
        """Multiple segments produce multiple JOINs."""
        sig = ["a.x->b.x", "b.y->c.y"]
        out = _join_clause_from_signature(sig)
        assert "JOIN b ON" in out
        assert "JOIN c ON" in out
        assert "a.x = b.x" in out
        assert "b.y = c.y" in out

    def test_empty_returns_empty(self):
        """Empty signature returns empty string."""
        assert _join_clause_from_signature([]) == ""

    def test_multi_column_edge(self):
        """Segment with comma-separated columns produces AND terms."""
        sig = ["a.c1,c2->b.c1,c2"]
        out = _join_clause_from_signature(sig)
        assert "JOIN b ON" in out
        assert "a.c1 = b.c1" in out
        assert "a.c2 = b.c2" in out
        assert " AND " in out


class TestInjectJoinIntoDeterministicSql:
    """Tests for inject_join_into_deterministic_sql."""

    def test_single_placeholder_replaced(self):
        """One placeholder is replaced with main join clause."""
        det_sql = "SELECT t1.a\nFROM t1\n" + JOIN_PLACEHOLDER + "\nWHERE t1.a = :p1"
        sigs = [["t1.fk->t2.pk"]]
        out = inject_join_into_deterministic_sql(det_sql, sigs)
        assert JOIN_PLACEHOLDER not in out
        assert "JOIN t2 ON" in out
        assert "t1.fk = t2.pk" in out
        assert "FROM t1" in out
        assert "WHERE" in out

    def test_no_sigs_returns_unchanged(self):
        """Empty join_sigs_ordered leaves placeholder in place."""
        det_sql = "SELECT a\nFROM t1\n" + JOIN_PLACEHOLDER
        out = inject_join_into_deterministic_sql(det_sql, [])
        assert JOIN_PLACEHOLDER in out

    def test_multiple_placeholders_cte_then_main(self):
        """Two placeholders (CTE then main) get two signatures."""
        det_sql = (
            "WITH cte1 AS (\nSELECT x\nFROM a\n"
            + JOIN_PLACEHOLDER
            + "\n)\nSELECT cte1.x\nFROM cte1\n"
            + JOIN_PLACEHOLDER
        )
        sigs = [["a.fk->b.pk"], ["cte1.x->other.y"]]
        out = inject_join_into_deterministic_sql(det_sql, sigs)
        assert JOIN_PLACEHOLDER not in out
        assert "JOIN b ON" in out
        assert "a.fk = b.pk" in out
        assert "JOIN other ON" in out
        assert "cte1.x = other.y" in out
