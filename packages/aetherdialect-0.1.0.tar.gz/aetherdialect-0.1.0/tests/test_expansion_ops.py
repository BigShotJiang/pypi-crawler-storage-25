"""Unit tests for text2sql.expansion_ops module."""

from text2sql.contracts_base import (
    ColumnRole,
    ExpansionMetadata,
    SchemaGraph,
    TableRole,
)
from text2sql.contracts_core import (
    FilterParam,
    HavingParam,
    NormalizedExpr,
    RuntimeCteStep,
    SelectCol,
    SimulatorIntent,
)
from text2sql.expansion_ops import (
    _a1_add_filter,
    _a2_add_expr_filter,
    _a3_change_aggregation,
    _a4_add_groupby,
    _a5_add_orderby,
    _a6_add_having_value,
    _a7_add_having_expr,
    _a8_remove_filter,
    _a9_remove_groupby,
    _a10_remove_having,
    _add_expansion_metadata,
    _b1_add_dimension_join,
    _b2_add_fact_join,
    _b3_swap_dimension,
    _b4_remove_table,
    _b5_bridge_via_intermediate,
    _build_column_metadata,
    _build_fk_map,
    _c1_include_gold,
    _compatible_data_types,
    _d1_add_distinct,
    _e1_expression_select,
    _f1_or_filter_group,
    _get_dimension_tables,
    _get_filterable_columns,
    _get_groupable_columns,
    _get_numeric_measure_columns,
    _get_temporal_columns,
    _l1_add_limit,
    _n1_round_numeric,
    _n2_abs_filter,
    _swap_agg_func,
    _t1_extract_select_groupby,
    _t2_date_trunc_groupby,
    _t3_date_window_filter,
    _t4_date_diff_filter,
    _tables_are_connected,
    expand_gold_intents,
)
from text2sql.utils import intent_key


def _sim_intent(**overrides) -> SimulatorIntent:
    """Build a minimal SimulatorIntent with optional overrides."""
    defaults = dict(
        intent_id="test_001",
        tables=["orders"],
        grain="row_level",
        select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
        group_by_cols=[],
        order_by_cols=[],
        filters_param=[],
        having_param=[],
        param_values={},
        expansion_metadata=None,
        limit=None,
    )
    defaults.update(overrides)
    return SimulatorIntent(**defaults)


class TestAddExpansionMetadata:
    """Tests for add_expansion_metadata."""

    def test_first_expansion(self):
        """First expansion sets depth=1 and single-element path."""
        intent = _sim_intent()
        _add_expansion_metadata(intent, "A1_add_filter")
        meta = intent.expansion_metadata
        assert meta is not None
        assert meta.operator == "A1_add_filter"
        assert meta.depth == 1
        assert meta.expansion_path == ["A1_add_filter"]

    def test_second_expansion(self):
        """Second expansion increments depth and appends to path."""
        intent = _sim_intent()
        _add_expansion_metadata(intent, "A1_add_filter")
        _add_expansion_metadata(intent, "A3_add_groupby")
        meta = intent.expansion_metadata
        assert meta.depth == 2
        assert meta.expansion_path == ["A1_add_filter", "A3_add_groupby"]
        assert meta.operator == "A3_add_groupby"

    def test_parent_intent_id_propagated(self):
        """Second expansion inherits intent_id as parent when first
        parent is empty."""
        intent = _sim_intent()
        _add_expansion_metadata(intent, "A1_add_filter")
        assert intent.expansion_metadata.parent_intent_id == ""
        _add_expansion_metadata(intent, "A2_add_agg")
        assert intent.expansion_metadata.parent_intent_id == "test_001"

    def test_third_expansion(self):
        """Three-deep expansion has correct depth and path length."""
        intent = _sim_intent()
        _add_expansion_metadata(intent, "A1")
        _add_expansion_metadata(intent, "A2")
        _add_expansion_metadata(intent, "B1")
        meta = intent.expansion_metadata
        assert meta.depth == 3
        assert len(meta.expansion_path) == 3

    def test_existing_metadata_uses_original_parent(self):
        """Existing metadata with parent_intent_id preserves it."""
        intent = _sim_intent(
            expansion_metadata=ExpansionMetadata(
                parent_intent_id="original_parent",
                operator="A1",
                depth=1,
                expansion_path=["A1"],
            )
        )
        _add_expansion_metadata(intent, "B1")
        assert intent.expansion_metadata.parent_intent_id == "original_parent"
        assert intent.expansion_metadata.depth == 2


class TestGetDimensionTables:
    """Tests for get_dimension_tables."""

    def test_returns_dimensions(self, schema_graph):
        """Returns only dimension tables."""
        dims = _get_dimension_tables(schema_graph)
        assert "customers" in dims
        assert "products" in dims
        assert "orders" not in dims

    def test_empty_schema(self):
        """Empty schema returns empty list."""
        empty = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="empty")
        assert _get_dimension_tables(empty) == []


class TestTablesAreConnected:
    """Tests for tables_are_connected."""

    def test_single_table(self):
        """Single table is always connected."""
        assert _tables_are_connected(["orders"], {}) is True

    def test_empty_list(self):
        """Empty list is trivially connected."""
        assert _tables_are_connected([], {}) is True

    def test_two_connected(self):
        """Two tables with FK edge are connected."""
        fk_map = {
            "orders": [{
                "source_column": "customer_id",
                "target_table": "customers",
                "target_column": "customer_id",
            }]
        }
        assert _tables_are_connected(["orders", "customers"], fk_map) is True

    def test_two_disconnected(self):
        """Two tables with no FK edge are disconnected."""
        assert _tables_are_connected(["orders", "unrelated"], {}) is False

    def test_three_chain(self):
        """Three tables forming a chain are connected."""
        fk_map = {
            "orders": [{
                "source_column": "customer_id",
                "target_table": "customers",
                "target_column": "customer_id",
            }],
            "customers": [{
                "source_column": "region_id",
                "target_table": "regions",
                "target_column": "region_id",
            }],
        }
        assert _tables_are_connected(
            ["orders", "customers", "regions"], fk_map,
        ) is True


class TestGetFilterableColumns:
    """Tests for get_filterable_columns."""

    def test_returns_filterable_roles(self, schema_graph):
        """Returns columns with CATEGORICAL, TEMPORAL, or IDENTIFIER roles."""
        cols = _get_filterable_columns(schema_graph, "orders")
        qualified_names = [c.split(".")[1] for c in cols]
        assert "order_id" in qualified_names

    def test_unknown_table(self, schema_graph):
        """Unknown table returns empty list."""
        assert _get_filterable_columns(schema_graph, "nonexistent") == []

    def test_format(self, schema_graph):
        """Returns fully-qualified table.column format."""
        cols = _get_filterable_columns(schema_graph, "orders")
        for c in cols:
            assert c.startswith("orders.")


class TestGetGroupableColumns:
    """Tests for get_groupable_columns."""

    def test_returns_dimension_and_date_roles(self, schema_graph):
        """Returns columns with CATEGORICAL or TEMPORAL roles."""
        cols = _get_groupable_columns(schema_graph, "orders")
        qualified_names = [c.split(".")[1] for c in cols]
        for name in qualified_names:
            role = schema_graph.tables["orders"].columns[name].role
            assert role in (
                ColumnRole.CATEGORICAL.value,
                ColumnRole.TEMPORAL.value,
            )


class TestBuildColumnMetadata:
    """Tests for _build_column_metadata."""

    def test_basic_structure(self, schema_graph):
        """Returns nested dict of table -> column -> metadata."""
        meta = _build_column_metadata(schema_graph)
        assert "orders" in meta
        assert "order_id" in meta["orders"]
        assert "data_type" in meta["orders"]["order_id"]

    def test_all_tables_present(self, schema_graph):
        """Every schema table appears in the result."""
        meta = _build_column_metadata(schema_graph)
        for table_name in schema_graph.tables:
            assert table_name in meta

    def test_empty_schema_returns_empty_dict(self):
        """Empty schema produces empty metadata dict."""
        empty = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="")
        assert _build_column_metadata(empty) == {}


class TestBuildFkMap:
    """Tests for _build_fk_map."""

    def test_basic_fk(self, schema_graph):
        """FK edges are grouped by source table."""
        fk_map = _build_fk_map(schema_graph)
        found = False
        for fks in fk_map.values():
            for fk in fks:
                if fk["target_table"] in schema_graph.tables:
                    found = True
        assert found or not schema_graph.fk_edges

    def test_empty_schema(self):
        """Empty schema produces empty map."""
        empty = SchemaGraph(tables={}, join_paths_multi={}, schema_hash="empty")
        assert _build_fk_map(empty) == {}


class TestCompatibleDataTypes:
    """Tests for _compatible_data_types."""

    def test_same_type(self):
        """Identical types are compatible."""
        assert _compatible_data_types("integer", "integer") is True

    def test_numeric_group(self):
        """Different numeric types are compatible."""
        assert _compatible_data_types("integer", "decimal") is True
        assert _compatible_data_types("float", "bigint") is True

    def test_text_group(self):
        """Different text types are compatible."""
        assert _compatible_data_types("varchar", "text") is True

    def test_cross_group_incompatible(self):
        """Types from different groups are incompatible."""
        assert _compatible_data_types("integer", "varchar") is False


class TestSwapAggFunc:
    """Tests for _swap_agg_func."""

    def test_swap_on_agg_expr(self):
        """Swaps agg_func on an aggregated expression."""
        expr = NormalizedExpr.from_agg("count", "orders.order_id")
        swapped = _swap_agg_func(expr, "sum")
        assert swapped.add_groups[0].agg_func == "sum"

    def test_swap_preserves_column(self):
        """Column reference is preserved after swap."""
        expr = NormalizedExpr.from_agg("avg", "orders.amount")
        swapped = _swap_agg_func(expr, "max")
        assert swapped.primary_column == "orders.amount"


class TestA1AddFilter:
    """Tests for a1_add_filter (fully deterministic)."""

    def test_produces_variants(self, schema_graph):
        """Returns filter variants for filterable columns."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _a1_add_filter(intent, schema_graph, cm)
        assert len(results) > 0
        for r in results:
            assert len(r.filters_param) == 1

    def test_skips_max_filters(self, schema_graph):
        """Skips when max filters reached."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column(f"orders.col{i}"),
                op="=", value_type="string", param_key=f"p{i}",
            )
            for i in range(20)
        ]
        intent = _sim_intent(tables=["orders"], filters_param=filters)
        cm = _build_column_metadata(schema_graph)
        results = _a1_add_filter(intent, schema_graph, cm)
        assert results == []


class TestA3ChangeAggregation:
    """Tests for a3_change_aggregation."""

    def test_no_aggregation_skips(self, schema_graph):
        """Non-aggregated intent returns empty."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _a3_change_aggregation(intent, schema_graph, cm)
        assert results == []

    def test_swaps_aggregations(self, schema_graph):
        """Aggregated intent gets alternative aggregations."""
        intent = _sim_intent(
            tables=["orders"], grain="scalar",
            select_cols=[SelectCol(
                expr=NormalizedExpr.from_agg("count", "orders.order_id"),
            )],
        )
        cm = _build_column_metadata(schema_graph)
        results = _a3_change_aggregation(intent, schema_graph, cm)
        assert len(results) > 0


class TestA4AddGroupby:
    """Tests for a4_add_groupby."""

    def test_adds_groupby(self, schema_graph):
        """Adds groupable columns."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _a4_add_groupby(intent, schema_graph, cm)
        assert len(results) > 0
        for r in results:
            assert len(r.group_by_cols) >= 1
            assert r.grain == "grouped"


class TestA8RemoveFilter:
    """Tests for a8_remove_filter."""

    def test_no_filters_skips(self, schema_graph):
        """No filters returns empty."""
        intent = _sim_intent(tables=["orders"], filters_param=[])
        cm = _build_column_metadata(schema_graph)
        results = _a8_remove_filter(intent, schema_graph, cm)
        assert results == []

    def test_removes_each(self, schema_graph):
        """Removes each filter one at a time."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.status"),
                op="=", value_type="string", param_key="p1",
            ),
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op=">", value_type="number", param_key="p2",
            ),
        ]
        intent = _sim_intent(tables=["orders"], filters_param=filters)
        cm = _build_column_metadata(schema_graph)
        results = _a8_remove_filter(intent, schema_graph, cm)
        assert len(results) == 2
        for r in results:
            assert len(r.filters_param) == 1


class TestB1AddDimensionJoin:
    """Tests for b1_add_dimension_join."""

    def test_joins_dimension(self, schema_graph):
        """Joins a connected dimension table."""
        intent = _sim_intent(tables=["orders"])
        fk_map = _build_fk_map(schema_graph)
        cm = _build_column_metadata(schema_graph)
        results = _b1_add_dimension_join(intent, schema_graph, fk_map, cm)
        for r in results:
            assert len(r.tables) > 1


class TestB4RemoveTable:
    """Tests for b4_remove_table."""

    def test_single_table_skips(self, schema_graph):
        """Single table intent returns empty."""
        intent = _sim_intent(tables=["orders"])
        fk_map = _build_fk_map(schema_graph)
        cm = _build_column_metadata(schema_graph)
        results = _b4_remove_table(intent, schema_graph, fk_map, cm)
        assert results == []


class TestC1IncludeGold:
    """Tests for c1_include_gold."""

    def test_returns_single_copy(self, schema_graph):
        """Returns a single-element list."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _c1_include_gold(intent, schema_graph, cm)
        assert len(results) == 1

    def test_copy_has_metadata(self, schema_graph):
        """Copy is stamped with C1 metadata."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _c1_include_gold(intent, schema_graph, cm)
        assert results[0].expansion_metadata.operator == "C1_include_gold"


class TestT1ExtractSelectGroupby:
    """Tests for T1 EXTRACT expansion."""

    def test_produces_extract_variants(self, schema_graph):
        """Temporal columns get EXTRACT variants."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        temporal = _get_temporal_columns(schema_graph, "orders")
        results = _t1_extract_select_groupby(intent, schema_graph, cm)
        if temporal:
            assert len(results) > 0
            for r in results:
                assert r.grain == "grouped"


class TestT3DateWindowFilter:
    """Tests for T3 date_window filter expansion."""

    def test_produces_date_window_variants(self, schema_graph):
        """Temporal columns get date_window filter variants."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        temporal = _get_temporal_columns(schema_graph, "orders")
        results = _t3_date_window_filter(intent, schema_graph, cm)
        if temporal:
            assert len(results) > 0
            for r in results:
                added = [
                    f for f in r.filters_param
                    if f.value_type == "date_window"
                ]
                assert len(added) == 1


class TestD1AddDistinct:
    """Tests for D1 DISTINCT expansion."""

    def test_adds_distinct(self, schema_graph):
        """Produces one variant with distinct set."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _d1_add_distinct(intent, schema_graph, cm)
        assert len(results) == 1


class TestL1AddLimit:
    """Tests for L1 LIMIT expansion."""

    def test_adds_limit_variants(self, schema_graph):
        """Produces variants with different LIMIT values."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _l1_add_limit(intent, schema_graph, cm)
        assert len(results) == len(
            __import__("text2sql.config", fromlist=["SimulatorConfig"]).SimulatorConfig.LIMIT_EXPANSION_VALUES
        )
        for r in results:
            assert r.limit is not None

    def test_skips_when_limit_set(self, schema_graph):
        """Skips when limit already set."""
        intent = _sim_intent(tables=["orders"], limit=10)
        cm = _build_column_metadata(schema_graph)
        results = _l1_add_limit(intent, schema_graph, cm)
        assert results == []


class TestF1OrFilterGroup:
    """Tests for F1 OR filter group expansion."""

    def test_creates_or_groups(self, schema_graph):
        """Creates OR groups from pairs of existing filters."""
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.status"),
                op="=", value_type="string", param_key="p1",
            ),
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.amount"),
                op=">", value_type="number", param_key="p2",
            ),
        ]
        intent = _sim_intent(tables=["orders"], filters_param=filters)
        cm = _build_column_metadata(schema_graph)
        results = _f1_or_filter_group(intent, schema_graph, cm)
        assert len(results) == 1
        or_filters = [
            f for f in results[0].filters_param if f.bool_op == "OR"
        ]
        assert len(or_filters) == 2

    def test_needs_two_filters(self, schema_graph):
        """Returns empty when fewer than 2 filters."""
        intent = _sim_intent(tables=["orders"])
        cm = _build_column_metadata(schema_graph)
        results = _f1_or_filter_group(intent, schema_graph, cm)
        assert results == []


class TestExpandGoldIntents:
    """Tests for expand_gold_intents multi-depth."""

    def test_returns_list(self, schema_graph):
        """Returns a list."""
        gold = [_sim_intent(tables=["orders"])]
        results = expand_gold_intents(gold, schema_graph, max_depth=1)
        assert isinstance(results, list)

    def test_cte_intents_included(self, schema_graph):
        """CTE intents are now expanded (not skipped)."""
        cte_step = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(
                expr=NormalizedExpr.from_column("orders.order_id"),
            )],
            group_by_cols=[],
            filters_param=[],
            having_param=[],
            order_by_cols=[],
        )
        gold = [_sim_intent(tables=["orders"], cte_steps=[cte_step])]
        results = expand_gold_intents(gold, schema_graph, max_depth=1)
        assert len(results) > 0

    def test_deduplicates(self, schema_graph):
        """No duplicate intent keys in results."""
        gold = [_sim_intent(tables=["orders"])]
        results = expand_gold_intents(gold, schema_graph, max_depth=1)
        keys = [intent_key(r.to_runtime_intent()) for r in results]
        assert len(keys) == len(set(keys))

    def test_depth_2_produces_more(self, schema_graph):
        """Depth 2 produces at least as many variants as depth 1."""
        gold = [_sim_intent(tables=["orders"])]
        d1 = expand_gold_intents(gold, schema_graph, max_depth=1)
        d2 = expand_gold_intents(gold, schema_graph, max_depth=2)
        assert len(d2) >= len(d1)
