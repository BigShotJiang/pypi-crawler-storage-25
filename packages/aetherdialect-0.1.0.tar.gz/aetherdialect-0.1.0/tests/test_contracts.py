"""Tests for contracts_base and contracts_core dataclass contracts."""

from text2sql.config import ROLE_ALLOWED_AGGREGATIONS, VALID_AGGREGATION_FUNCTIONS
from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    CteOutputColumnMeta,
    ExpansionMetadata,
    FKEdge,
    IntentIssue,
    IntentValidationResult,
    QSimRange,
    QSimSkeleton,
    QSimSummary,
    QueryPlan,
    RejectedTemplateInfo,
    RetryFailureContext,
    SchemaGraph,
    SchemaLimits,
    SimulatorSummary,
    SkeletonPool,
    SQLShape,
    TableMetadata,
    TemplateInfo,
    TemplateStats,
    ValidationResult,
    ValueDomain,
    _data_type_to_value_type,
    _is_date_type,
    _is_numeric_type,
    is_string_type,
)
from text2sql.contracts_core import (
    ConcreteCteStep,
    ConcreteIntent,
    CteValidationResult,
    ExprValue,
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    OrderByCol,
    QSimFilter,
    QSimHaving,
    QSimIntent,
    RejectedTemplate,
    RejectedValueHistory,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
    SimulatorIntent,
    SimulatorResult,
    Template,
    TemplateMatch,
    ValueHistory,
    _runtime_cte_to_concrete,
    concrete_cte_to_runtime,
    runtime_intent_to_concrete,
)


class TestExprValue:
    """Tests for ExprValue dataclass."""

    def test_from_dict_with_int(self):
        """ExprValue.from_dict handles bare int."""
        ev = ExprValue.from_dict(5)
        assert ev.value == 5.0
        assert ev.param_key == ""

    def test_from_dict_with_float(self):
        """ExprValue.from_dict handles bare float."""
        ev = ExprValue.from_dict(3.14)
        assert ev.value == 3.14
        assert ev.param_key == ""

    def test_from_dict_with_dict(self):
        """ExprValue.from_dict handles dict with value and param_key."""
        ev = ExprValue.from_dict({"value": 10.0, "param_key": "p1"})
        assert ev.value == 10.0
        assert ev.param_key == "p1"

    def test_round_trip(self):
        """ExprValue to_dict/from_dict round trip."""
        original = ExprValue(value=42.0, param_key="s1")
        rebuilt = ExprValue.from_dict(original.to_dict())
        assert rebuilt.value == original.value
        assert rebuilt.param_key == original.param_key

    def test_signature_key_is_val(self):
        """ExprValue.signature_key always returns 'val'."""
        assert ExprValue(value=1.0).signature_key == "val"
        assert ExprValue(value=99.0, param_key="p1").signature_key == "val"


class TestMulGroup:
    """Tests for MulGroup dataclass."""

    def test_post_init_sorts_multiply(self):
        """MulGroup.__post_init__ sorts multiply list."""
        g = MulGroup(multiply=["b.col", "a.col"])
        assert g.multiply == ["a.col", "b.col"]

    def test_post_init_sorts_divide(self):
        """MulGroup.__post_init__ sorts divide list."""
        g = MulGroup(divide=["z.col", "a.col"])
        assert g.divide == ["a.col", "z.col"]

    def test_post_init_lowercases_agg_func(self):
        """MulGroup.__post_init__ lowercases agg_func."""
        g = MulGroup(agg_func="SUM")
        assert g.agg_func == "sum"

    def test_post_init_swaps_scalar_inner_if_needed(self):
        """MulGroup.__post_init__ swaps scalar/inner_scalar
        alphabetically."""
        g = MulGroup(scalar_func="ROUND", inner_scalar_func="ABS")
        assert g.scalar_func == "abs"
        assert g.inner_scalar_func == "round"

    def test_post_init_no_swap_when_scalar_less_than_inner(self):
        """MulGroup.__post_init__ does not swap when scalar < inner
        alphabetically."""
        g = MulGroup(
            scalar_func="abs",
            inner_scalar_func="round",
            scalar_func_args=[],
            inner_scalar_func_args=[2],
        )
        assert g.scalar_func == "abs"
        assert g.inner_scalar_func == "round"
        assert g.inner_scalar_func_args == [2]

    def test_signature_key_includes_coeff(self):
        """MulGroup.signature_key starts with 'coeff'."""
        g = MulGroup(multiply=["t.col"], agg_func="sum")
        assert g.signature_key.startswith("coeff")
        assert "agg=sum" in g.signature_key
        assert "*t.col" in g.signature_key

    def test_structural_key_excludes_coeff(self):
        """MulGroup.structural_key excludes coefficient prefix."""
        g = MulGroup(multiply=["t.col"], agg_func="sum")
        assert not g.structural_key.startswith("coeff")
        assert "agg=sum" in g.structural_key

    def test_signature_key_vs_structural_key(self):
        """Two MulGroups with different coefficients share
        structural_key but differ in signature_key."""
        g1 = MulGroup(coefficient=1.0, multiply=["t.col"])
        g2 = MulGroup(coefficient=2.0, multiply=["t.col"])
        assert g1.structural_key == g2.structural_key
        assert g1.signature_key == g2.signature_key

    def test_round_trip(self):
        """MulGroup to_dict/from_dict round trip."""
        original = MulGroup(coefficient=2.0, multiply=["a.x"], divide=["b.y"], agg_func="avg")
        rebuilt = MulGroup.from_dict(original.to_dict())
        assert rebuilt.coefficient == 2.0
        assert rebuilt.multiply == ["a.x"]
        assert rebuilt.divide == ["b.y"]
        assert rebuilt.agg_func == "avg"


class TestNormalizedExpr:
    """Tests for NormalizedExpr dataclass."""

    def test_from_column(self):
        """NormalizedExpr.from_column creates single MulGroup with
        multiply."""
        expr = NormalizedExpr.from_column("orders.amount")
        assert len(expr.add_groups) == 1
        assert expr.add_groups[0].multiply == ["orders.amount"]
        assert not expr.has_aggregation

    def test_from_agg(self):
        """NormalizedExpr.from_agg creates MulGroup with agg_func."""
        expr = NormalizedExpr.from_agg("count", "orders.order_id")
        assert len(expr.add_groups) == 1
        assert expr.add_groups[0].agg_func == "count"
        assert expr.add_groups[0].multiply == ["orders.order_id"]
        assert expr.has_aggregation is True

    def test_has_aggregation_detects_agg_prefix(self):
        """NormalizedExpr.has_aggregation detects AGG() string
        prefix."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["COUNT(orders.order_id)"])])
        assert expr.has_aggregation is True

    def test_has_aggregation_false_for_bare_column(self):
        """NormalizedExpr.has_aggregation returns False for bare
        column."""
        expr = NormalizedExpr.from_column("t.col")
        assert expr.has_aggregation is False

    def test_primary_column_strips_function(self):
        """NormalizedExpr.primary_column strips function wrappers."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["UPPER(customers.name)"])])
        assert expr.primary_column == "customers.name"

    def test_primary_term_returns_raw(self):
        """NormalizedExpr.primary_term returns first term as-is."""
        expr = NormalizedExpr(add_groups=[MulGroup(multiply=["UPPER(customers.name)"])])
        assert expr.primary_term == "UPPER(customers.name)"

    def test_round_trip(self):
        """NormalizedExpr to_dict/from_dict round trip."""
        original = NormalizedExpr(
            add_groups=[MulGroup(multiply=["t.x"], agg_func="sum")],
            sub_values=[ExprValue(value=1.0)],
        )
        rebuilt = NormalizedExpr.from_dict(original.to_dict())
        assert len(rebuilt.add_groups) == 1
        assert rebuilt.add_groups[0].agg_func == "sum"
        assert len(rebuilt.sub_values) == 1

    def test_signature_key_deterministic(self):
        """NormalizedExpr.signature_key is deterministic."""
        expr = NormalizedExpr.from_agg("sum", "t.col")
        assert expr.signature_key == expr.signature_key

    def test_post_init_sorts_groups(self):
        """NormalizedExpr.__post_init__ sorts add_groups by
        signature_key."""
        g1 = MulGroup(multiply=["z.col"])
        g2 = MulGroup(multiply=["a.col"])
        expr = NormalizedExpr(add_groups=[g1, g2])
        assert expr.add_groups[0].multiply == ["a.col"]
        assert expr.add_groups[1].multiply == ["z.col"]


class TestFilterParam:
    """Tests for FilterParam dataclass."""

    def test_round_trip(self):
        """FilterParam to_dict/from_dict round trip."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=",
            value_type="string",
            param_key="p1",
        )
        rebuilt = FilterParam.from_dict(fp.to_dict())
        assert rebuilt.op == "="
        assert rebuilt.value_type == "string"
        assert rebuilt.param_key == "p1"

    def test_post_init_normalizes_op(self):
        """FilterParam.__post_init__ lowercases and strips op."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="  LIKE  ")
        assert fp.op == "like"

    def test_post_init_canonicalizes_ordering(self):
        """FilterParam.__post_init__ swaps left/right if right has lower
        signature."""
        left = NormalizedExpr.from_column("z.col")
        right = NormalizedExpr.from_column("a.col")
        fp = FilterParam(left_expr=left, op=">", right_expr=right)
        assert fp.left_expr.primary_term == "a.col"
        assert fp.right_expr.primary_term == "z.col"
        assert fp.op == "<"

    def test_bool_op_defaults_to_and(self):
        """FilterParam.bool_op defaults to 'AND'."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        assert fp.bool_op == "AND"

    def test_bool_op_normalizes_to_uppercase(self):
        """FilterParam.__post_init__ normalizes bool_op to uppercase."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="or")
        assert fp.bool_op == "OR"

    def test_bool_op_strips_whitespace(self):
        """FilterParam.__post_init__ strips whitespace from bool_op."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="  and  ")
        assert fp.bool_op == "AND"

    def test_bool_op_invalid_falls_back_to_and(self):
        """FilterParam.__post_init__ falls back to 'AND' for invalid
        bool_op."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="XOR")
        assert fp.bool_op == "AND"

    def test_filter_group_defaults_to_none(self):
        """FilterParam.filter_group defaults to None."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        assert fp.filter_group is None

    def test_filter_group_set(self):
        """FilterParam.filter_group can be set to an integer."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", filter_group=1)
        assert fp.filter_group == 1

    def test_to_dict_omits_bool_op_when_and(self):
        """FilterParam.to_dict omits bool_op when it is the default
        'AND'."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        d = fp.to_dict()
        assert "bool_op" not in d

    def test_to_dict_includes_bool_op_when_or(self):
        """FilterParam.to_dict includes bool_op when it is 'OR'."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="OR")
        d = fp.to_dict()
        assert d["bool_op"] == "OR"

    def test_to_dict_omits_filter_group_when_none(self):
        """FilterParam.to_dict omits filter_group when None."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        d = fp.to_dict()
        assert "filter_group" not in d

    def test_to_dict_includes_filter_group_when_set(self):
        """FilterParam.to_dict includes filter_group when set."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", filter_group=2)
        d = fp.to_dict()
        assert d["filter_group"] == 2

    def test_from_dict_parses_bool_op(self):
        """FilterParam.from_dict parses bool_op."""
        d = {"left_expr": "t.c", "op": "=", "bool_op": "OR"}
        fp = FilterParam.from_dict(d)
        assert fp.bool_op == "OR"

    def test_from_dict_defaults_bool_op(self):
        """FilterParam.from_dict defaults bool_op to 'AND' when
        missing."""
        d = {"left_expr": "t.c", "op": "="}
        fp = FilterParam.from_dict(d)
        assert fp.bool_op == "AND"

    def test_from_dict_parses_filter_group(self):
        """FilterParam.from_dict parses filter_group."""
        d = {"left_expr": "t.c", "op": "=", "filter_group": 3}
        fp = FilterParam.from_dict(d)
        assert fp.filter_group == 3

    def test_from_dict_filter_group_none_when_missing(self):
        """FilterParam.from_dict sets filter_group to None when
        missing."""
        d = {"left_expr": "t.c", "op": "="}
        fp = FilterParam.from_dict(d)
        assert fp.filter_group is None

    def test_round_trip_with_bool_op_and_filter_group(self):
        """FilterParam round trip preserves bool_op and filter_group."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.c"),
            op="=",
            value_type="string",
            param_key="p1",
            bool_op="OR",
            filter_group=1,
        )
        rebuilt = FilterParam.from_dict(fp.to_dict())
        assert rebuilt.bool_op == "OR"
        assert rebuilt.filter_group == 1


class TestHavingParam:
    """Tests for HavingParam dataclass."""

    def test_round_trip(self):
        """HavingParam to_dict/from_dict round trip."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "orders.order_id"),
            op=">",
            value_type="integer",
            param_key="p2",
        )
        rebuilt = HavingParam.from_dict(hp.to_dict())
        assert rebuilt.op == ">"
        assert rebuilt.value_type == "integer"

    def test_default_value_type_is_number(self):
        """HavingParam defaults value_type to 'number'."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("sum", "t.x"), op=">=")
        assert hp.value_type == "number"

    def test_bool_op_defaults_to_and(self):
        """HavingParam.bool_op defaults to 'AND'."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">")
        assert hp.bool_op == "AND"

    def test_bool_op_normalizes_to_uppercase(self):
        """HavingParam.__post_init__ normalizes bool_op to uppercase."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">", bool_op="or")
        assert hp.bool_op == "OR"

    def test_bool_op_strips_whitespace(self):
        """HavingParam.__post_init__ strips whitespace from bool_op."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            bool_op="  and  ",
        )
        assert hp.bool_op == "AND"

    def test_bool_op_invalid_falls_back_to_and(self):
        """HavingParam.__post_init__ falls back to 'AND' for invalid
        bool_op."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">", bool_op="NAND")
        assert hp.bool_op == "AND"

    def test_filter_group_defaults_to_none(self):
        """HavingParam.filter_group defaults to None."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">")
        assert hp.filter_group is None

    def test_filter_group_set(self):
        """HavingParam.filter_group can be set to an integer."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">", filter_group=2)
        assert hp.filter_group == 2

    def test_to_dict_omits_bool_op_when_and(self):
        """HavingParam.to_dict omits bool_op when it is the default
        'AND'."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">")
        d = hp.to_dict()
        assert "bool_op" not in d

    def test_to_dict_includes_bool_op_when_or(self):
        """HavingParam.to_dict includes bool_op when it is 'OR'."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">", bool_op="OR")
        d = hp.to_dict()
        assert d["bool_op"] == "OR"

    def test_to_dict_omits_filter_group_when_none(self):
        """HavingParam.to_dict omits filter_group when None."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">")
        d = hp.to_dict()
        assert "filter_group" not in d

    def test_to_dict_includes_filter_group_when_set(self):
        """HavingParam.to_dict includes filter_group when set."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">", filter_group=1)
        d = hp.to_dict()
        assert d["filter_group"] == 1

    def test_from_dict_parses_bool_op(self):
        """HavingParam.from_dict parses bool_op."""
        d = {"left_expr": "COUNT(t.id)", "op": ">", "bool_op": "OR"}
        hp = HavingParam.from_dict(d)
        assert hp.bool_op == "OR"

    def test_from_dict_defaults_bool_op(self):
        """HavingParam.from_dict defaults bool_op to 'AND' when
        missing."""
        d = {"left_expr": "COUNT(t.id)", "op": ">"}
        hp = HavingParam.from_dict(d)
        assert hp.bool_op == "AND"

    def test_from_dict_parses_filter_group(self):
        """HavingParam.from_dict parses filter_group."""
        d = {"left_expr": "COUNT(t.id)", "op": ">", "filter_group": 2}
        hp = HavingParam.from_dict(d)
        assert hp.filter_group == 2

    def test_round_trip_with_bool_op_and_filter_group(self):
        """HavingParam round trip preserves bool_op and filter_group."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            value_type="integer",
            param_key="p1",
            bool_op="OR",
            filter_group=1,
        )
        rebuilt = HavingParam.from_dict(hp.to_dict())
        assert rebuilt.bool_op == "OR"
        assert rebuilt.filter_group == 1


class TestSelectCol:
    """Tests for SelectCol dataclass."""

    def test_is_aggregated(self):
        """SelectCol.is_aggregated delegates to expr.has_aggregation."""
        sc = SelectCol(expr=NormalizedExpr.from_agg("sum", "t.x"))
        assert sc.is_aggregated is True

    def test_not_aggregated(self):
        """SelectCol bare column is not aggregated."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.x"))
        assert sc.is_aggregated is False

    def test_round_trip(self):
        """SelectCol to_dict/from_dict round trip."""
        original = SelectCol(expr=NormalizedExpr.from_column("t.x"))
        rebuilt = SelectCol.from_dict(original.to_dict())
        assert rebuilt.expr.primary_term == "t.x"


class TestOrderByCol:
    """Tests for OrderByCol dataclass."""

    def test_direction_uppercased(self):
        """OrderByCol.__post_init__ uppercases direction."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("t.x"), direction="desc")
        assert obc.direction == "DESC"

    def test_round_trip(self):
        """OrderByCol to_dict/from_dict round trip."""
        original = OrderByCol(expr=NormalizedExpr.from_column("t.x"), direction="ASC")
        rebuilt = OrderByCol.from_dict(original.to_dict())
        assert rebuilt.direction == "ASC"


class TestCteRoundTrip:
    """Tests for CTE conversion functions."""

    def test_runtime_cte_to_concrete_preserves_fields(self):
        """runtime_cte_to_concrete preserves structural fields."""
        rt = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.amount"))],
            grain="grouped",
        )
        concrete = _runtime_cte_to_concrete(rt)
        assert isinstance(concrete, ConcreteCteStep)
        assert concrete.cte_name == "cte1"
        assert concrete.tables == ["orders"]
        assert concrete.grain == "grouped"

    def test_concrete_cte_to_runtime_drops_runtime_fields(self):
        """concrete_cte_to_runtime creates RuntimeCteStep with empty
        runtime fields."""
        concrete = ConcreteCteStep(cte_name="cte1", tables=["t1"])
        rt = concrete_cte_to_runtime(concrete)
        assert isinstance(rt, RuntimeCteStep)
        assert rt.description == ""
        assert rt.param_values == {}

    def test_round_trip(self):
        """RuntimeCteStep -> ConcreteCteStep -> RuntimeCteStep preserves
        structure."""
        original = RuntimeCteStep(
            cte_name="cte1",
            tables=["orders"],
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id"))],
            grain="grouped",
            output_columns=["order_count"],
        )
        concrete = _runtime_cte_to_concrete(original)
        restored = concrete_cte_to_runtime(concrete)
        assert restored.cte_name == original.cte_name
        assert restored.tables == original.tables
        assert restored.grain == original.grain
        assert len(restored.select_cols) == 1


class TestRuntimeIntentToConcreteIntent:
    """Tests for runtime_intent_to_concrete."""

    def test_basic_conversion(self, minimal_intent):
        """runtime_intent_to_concrete produces ConcreteIntent."""
        concrete = runtime_intent_to_concrete(minimal_intent, "id_123")
        assert isinstance(concrete, ConcreteIntent)
        assert concrete.intent_id == "id_123"
        assert concrete.tables == ["orders"]
        assert concrete.grain == "row_level"

    def test_drops_runtime_fields(self, grouped_intent):
        """ConcreteIntent does not contain param_values or
        natural_language."""
        concrete = runtime_intent_to_concrete(grouped_intent, "id_456")
        d = concrete.to_dict()
        assert "param_values" not in d
        assert "natural_language" not in d

    def test_round_trip_via_dict(self, grouped_intent):
        """ConcreteIntent to_dict/from_dict round trip."""
        concrete = runtime_intent_to_concrete(grouped_intent, "id_789")
        rebuilt = ConcreteIntent.from_dict(concrete.to_dict())
        assert rebuilt.intent_id == "id_789"
        assert rebuilt.tables == concrete.tables


class TestRuntimeIntent:
    """Tests for RuntimeIntent dataclass."""

    def test_expected_rows_scalar(self):
        """RuntimeIntent.expected_rows returns 'one' for scalar
        grain."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="scalar",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        assert intent.expected_rows == "one"

    def test_expected_rows_with_limit(self):
        """RuntimeIntent.expected_rows returns 'few' when limit is
        set."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            limit=10,
        )
        assert intent.expected_rows == "few"

    def test_expected_rows_many(self):
        """RuntimeIntent.expected_rows returns 'many' with no limit and
        non-scalar grain."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        assert intent.expected_rows == "many"

    def test_has_aggregation(self):
        """RuntimeIntent.has_aggregation detects aggregated select
        cols."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "t.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        assert intent.has_aggregation is True

    def test_round_trip(self, grouped_intent):
        """RuntimeIntent to_dict/from_dict round trip."""
        d = grouped_intent.to_dict()
        rebuilt = RuntimeIntent.from_dict(d)
        assert rebuilt.tables == grouped_intent.tables
        assert rebuilt.grain == grouped_intent.grain
        assert len(rebuilt.select_cols) == len(grouped_intent.select_cols)


class TestValueHistory:
    """Tests for ValueHistory dataclass."""

    def test_add_entry(self):
        """ValueHistory.add appends to all parallel lists."""
        vh = ValueHistory(param_values=[], questions=[], natural_language=[])
        vh.add({"p1": "x"}, "question one", "NL one")
        assert len(vh) == 1
        assert vh.questions[0] == "question one"

    def test_round_trip(self):
        """ValueHistory to_dict/from_dict round trip."""
        vh = ValueHistory(param_values=[{"p1": "a"}], questions=["q1"], natural_language=["nl1"])
        rebuilt = ValueHistory.from_dict(vh.to_dict())
        assert len(rebuilt) == 1


class TestRejectedValueHistory:
    """Tests for RejectedValueHistory dataclass."""

    def test_add_entry(self):
        """RejectedValueHistory.add appends to all parallel lists."""
        rvh = RejectedValueHistory(
            param_values=[],
            questions=[],
            natural_language=[],
            rejection_reasons=[],
            rejection_categories=[],
        )
        rvh.add({"p1": "x"}, "q1", "nl1", "bad join", "wrong_join")
        assert len(rvh) == 1
        assert rvh.rejection_categories[0] == "wrong_join"


class TestQSimIntent:
    """Tests for QSimIntent dataclass."""

    def test_distinct_field_exists(self):
        """QSimIntent has distinct field."""
        qi = QSimIntent(
            intent_id="test",
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            distinct=True,
        )
        assert qi.distinct is True

    def test_round_trip(self):
        """QSimIntent to_dict/from_dict round trip preserves
        distinct."""
        qi = QSimIntent(
            intent_id="test",
            tables=["t"],
            grain="row_level",
            select_cols=["t.x"],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            distinct=True,
        )
        rebuilt = QSimIntent.from_dict(qi.to_dict())
        assert rebuilt.distinct is True
        assert rebuilt.select_cols == ["t.x"]


class TestColumnMetadaTypeFunctions:
    """Tests for type detection functions."""

    def test_is_numeric_type(self):
        """is_numeric_type detects numeric types."""
        assert _is_numeric_type("integer") is True
        assert _is_numeric_type("BIGINT") is True
        assert _is_numeric_type("numeric(10,2)") is True
        assert _is_numeric_type("varchar") is False

    def test_is_string_type(self):
        """is_string_type detects string types."""
        assert is_string_type("varchar") is True
        assert is_string_type("TEXT") is True
        assert is_string_type("integer") is False

    def test_is_string_type_empty_returns_false(self):
        """is_string_type returns False for empty string."""
        assert is_string_type("") is False

    def test_is_numeric_type_empty_returns_false(self):
        """_is_numeric_type returns False for empty string."""
        assert _is_numeric_type("") is False

    def test_is_date_type(self):
        """is_date_type detects temporal types."""
        assert _is_date_type("timestamp") is True
        assert _is_date_type("DATE") is True
        assert _is_date_type("integer") is False

    def test_data_type_to_value_type_integer(self):
        """data_type_to_value_type maps integer types."""
        assert _data_type_to_value_type("integer") == "integer"
        assert _data_type_to_value_type("bigint") == "integer"
        assert _data_type_to_value_type("serial") == "integer"

    def test_data_type_to_value_type_number(self):
        """data_type_to_value_type maps numeric types."""
        assert _data_type_to_value_type("numeric") == "number"
        assert _data_type_to_value_type("float") == "number"
        assert _data_type_to_value_type("decimal(10,2)") == "number"

    def test_data_type_to_value_type_string(self):
        """data_type_to_value_type maps string types."""
        assert _data_type_to_value_type("varchar") == "string"
        assert _data_type_to_value_type("text") == "string"

    def test_data_type_to_value_type_date(self):
        """data_type_to_value_type maps temporal types."""
        assert _data_type_to_value_type("timestamp") == "date"
        assert _data_type_to_value_type("date") == "date"

    def test_data_type_to_value_type_boolean(self):
        """data_type_to_value_type maps boolean types."""
        assert _data_type_to_value_type("boolean") == "boolean"
        assert _data_type_to_value_type("bool") == "boolean"

    def test_data_type_to_value_type_fallback(self):
        """data_type_to_value_type falls back to string for unknown."""
        assert _data_type_to_value_type("xml") == "string"

    def test_data_type_to_value_type_empty_string(self):
        """data_type_to_value_type returns string for empty input."""
        assert _data_type_to_value_type("") == "string"

    def test_data_type_to_value_type_whitespace_stripped(self):
        """data_type_to_value_type strips whitespace before lookup."""
        assert _data_type_to_value_type("  integer  ") == "integer"

    def test_data_type_to_value_type_numeric_token_fallback(self):
        """_data_type_to_value_type maps unknown type with numeric token to number."""
        assert _data_type_to_value_type("myinteger") == "number"

    def test_is_date_type_interval(self):
        """_is_date_type returns True for interval."""
        assert _is_date_type("interval") is True


class TestColumnMetadataRoles:
    """Tests for ColumnMetadata role-based methods."""

    def test_get_valid_aggregations_identifier(self):
        """IDENTIFIER role only allows count."""
        cm = ColumnMetadata(
            name="id",
            data_type="integer",
            role=ColumnRole.IDENTIFIER.value,
            distinct_count=100,
            row_count=100,
            valid_aggregations=["count"],
        )
        assert cm.get_valid_aggregations() == {"count"}

    def test_get_valid_aggregations_numeric_measure(self):
        """NUMERIC_MEASURE role allows all agg functions."""
        cm = ColumnMetadata(
            name="amount",
            data_type="numeric",
            role=ColumnRole.NUMERIC_MEASURE.value,
            distinct_count=50,
            row_count=100,
            valid_aggregations=["sum", "avg", "min", "max", "count"],
        )
        assert cm.get_valid_aggregations() == {"count", "sum", "avg", "min", "max"}

    def test_get_valid_aggregations_categorical(self):
        """CATEGORICAL role allows count, min, max but not sum/avg."""
        cm = ColumnMetadata(
            name="name",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=50,
            row_count=100,
            valid_aggregations=["count", "min", "max"],
        )
        aggs = cm.get_valid_aggregations()
        assert "count" in aggs
        assert "sum" not in aggs
        assert "avg" not in aggs

    def test_get_valid_aggregations_boolean(self):
        """BOOLEAN role allows count only."""
        cm = ColumnMetadata(
            name="active",
            data_type="boolean",
            role=ColumnRole.BOOLEAN.value,
            distinct_count=2,
            row_count=100,
            valid_aggregations=["count"],
        )
        aggs = cm.get_valid_aggregations()
        assert "count" in aggs
        assert "sum" not in aggs

    def test_get_valid_filter_ops_pk(self):
        """Primary key column gets comparison ops."""
        cm = ColumnMetadata(
            name="id",
            data_type="integer",
            is_primary_key=True,
            role=ColumnRole.IDENTIFIER.value,
            distinct_count=100,
            row_count=100,
            valid_filter_ops=["=", "!=", "<", "<=", ">", ">=", "between", "in", "not in", "is null", "is not null"],
        )
        ops = cm.get_valid_filter_ops()
        assert "=" in ops
        assert "between" in ops
        assert "is null" in ops

    def test_get_valid_filter_ops_categorical(self):
        """Categorical string column gets LIKE ops."""
        cm = ColumnMetadata(
            name="name",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=50,
            row_count=100,
            valid_filter_ops=["=", "!=", "in", "not in", "like", "ilike", "not like", "not ilike", "is null", "is not null"],
        )
        ops = cm.get_valid_filter_ops()
        assert "like" in ops
        assert "ilike" in ops

    def test_is_filterable_audit_column(self):
        """AUDIT role columns are not filterable."""
        cm = ColumnMetadata(
            name="created_at",
            data_type="timestamp",
            role=ColumnRole.AUDIT.value,
            distinct_count=100,
            row_count=100,
        )
        assert cm.is_filterable is False

    def test_is_groupable_categorical(self):
        """CATEGORICAL columns are groupable."""
        cm = ColumnMetadata(
            name="status",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=5,
            row_count=100,
        )
        assert cm.is_groupable is True

    def test_is_aggregatable_numeric_measure(self):
        """NUMERIC_MEASURE columns are aggregatable."""
        cm = ColumnMetadata(
            name="amount",
            data_type="numeric",
            role=ColumnRole.NUMERIC_MEASURE.value,
            distinct_count=50,
            row_count=100,
        )
        assert cm.is_aggregatable is True

    def test_is_aggregatable_categorical_false(self):
        """CATEGORICAL columns are not aggregatable."""
        cm = ColumnMetadata(
            name="name",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=50,
            row_count=100,
        )
        assert cm.is_aggregatable is False

    def test_is_boolean_like(self):
        """Column with 2 distinct boolean-pattern values is boolean-
        like."""
        cm = ColumnMetadata(
            name="flag",
            data_type="integer",
            distinct_count=2,
            row_count=100,
            top_k_values=["0", "1"],
        )
        assert cm.is_boolean_like is True

    def test_is_boolean_like_false_for_pk(self):
        """PK column is never boolean-like even with 2 values."""
        cm = ColumnMetadata(
            name="id",
            data_type="integer",
            is_primary_key=True,
            distinct_count=2,
            row_count=100,
            top_k_values=["0", "1"],
        )
        assert cm.is_boolean_like is False


class TestSQLShape:
    """Tests for SQLShape dataclass."""

    def test_defaults(self):
        """SQLShape defaults."""
        shape = SQLShape(num_joins=0, has_group_by=False, has_agg=False)
        assert shape.num_joins == 0
        assert shape.has_group_by is False
        assert shape.has_agg is False
        assert shape.has_distinct is False

    def test_round_trip(self):
        """SQLShape to_dict/from_dict round trip."""
        original = SQLShape(
            num_joins=2,
            has_group_by=True,
            has_agg=True,
            num_cte=1,
            num_filters=3,
            has_distinct=True,
        )
        rebuilt = SQLShape.from_dict(original.to_dict())
        assert rebuilt.num_joins == 2
        assert rebuilt.has_group_by is True
        assert rebuilt.has_distinct is True


class TestNoCountDistinctRegression:
    """Regression tests verifying count_distinct is NOT a valid agg_func
    anywhere."""

    def test_no_count_distinct_in_valid_agg(self):
        """count_distinct is not in VALID_AGGREGATION_FUNCTIONS."""
        assert "count_distinct" not in VALID_AGGREGATION_FUNCTIONS

    def test_no_count_distinct_in_role_aggregations(self):
        """count_distinct is not in any ROLE_ALLOWED_AGGREGATIONS
        set."""
        for role, aggs in ROLE_ALLOWED_AGGREGATIONS.items():
            assert "count_distinct" not in aggs, f"count_distinct found in {role}"

    def test_no_distinct_field_on_select_col(self):
        """SelectCol does not have a 'distinct' attribute."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.x"))
        assert not hasattr(sc, "distinct")

    def test_no_distinct_field_on_runtime_intent(self):
        """RuntimeIntent does not have a 'distinct' attribute."""
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        assert not hasattr(intent, "distinct")

    def test_qsim_intent_has_distinct(self):
        """QSimIntent still has distinct field."""
        qi = QSimIntent(
            intent_id="t",
            tables=[],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        assert hasattr(qi, "distinct")


class TestFilterParamSignatureKey:
    """Tests for FilterParam.signature_key."""

    def test_signature_key_deterministic(self):
        """FilterParam.signature_key is deterministic."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", value_type="string")
        assert fp.signature_key == fp.signature_key

    def test_signature_key_includes_op(self):
        """FilterParam.signature_key includes the op."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op=">=", value_type="number")
        assert ">=" in fp.signature_key

    def test_different_ops_different_keys(self):
        """FilterParam with different ops have different
        signature_keys."""
        fp1 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="!=")
        assert fp1.signature_key != fp2.signature_key

    def test_signature_key_ignores_bool_op(self):
        """FilterParam.signature_key does not include bool_op."""
        fp1 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", bool_op="OR")
        assert fp1.signature_key == fp2.signature_key

    def test_signature_key_ignores_filter_group(self):
        """FilterParam.signature_key does not include filter_group."""
        fp1 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=")
        fp2 = FilterParam(left_expr=NormalizedExpr.from_column("t.c"), op="=", filter_group=1)
        assert fp1.signature_key == fp2.signature_key


class TestHavingParamSignatureKey:
    """Tests for HavingParam.signature_key."""

    def test_signature_key_deterministic(self):
        """HavingParam.signature_key is deterministic."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">")
        assert hp.signature_key == hp.signature_key

    def test_signature_key_includes_op(self):
        """HavingParam.signature_key includes the op."""
        hp = HavingParam(left_expr=NormalizedExpr.from_agg("count", "t.id"), op=">=")
        assert ">=" in hp.signature_key


class TestSelectColSignatureKey:
    """Tests for SelectCol.signature_key."""

    def test_signature_key_delegates_to_expr(self):
        """SelectCol.signature_key is the expr's signature_key."""
        expr = NormalizedExpr.from_column("t.x")
        sc = SelectCol(expr=expr)
        assert sc.signature_key == expr.signature_key


class TestOrderByColExtended:
    """Additional OrderByCol tests."""

    def test_is_aggregated_true(self):
        """OrderByCol.is_aggregated True when expr has aggregation."""
        obc = OrderByCol(expr=NormalizedExpr.from_agg("sum", "t.x"), direction="DESC")
        assert obc.is_aggregated is True

    def test_is_aggregated_false(self):
        """OrderByCol.is_aggregated False for bare column."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("t.x"), direction="ASC")
        assert obc.is_aggregated is False

    def test_signature_key_includes_direction(self):
        """OrderByCol.signature_key includes direction."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("t.x"), direction="DESC")
        assert "DESC" in obc.signature_key


class TestRuntimeCteStepExpectedRows:
    """Tests for RuntimeCteStep.expected_rows."""

    def test_scalar_returns_one(self):
        """RuntimeCteStep.expected_rows returns 'one' for scalar
        grain."""
        rt = RuntimeCteStep(cte_name="c1", tables=["t"], grain="scalar")
        assert rt.expected_rows == "one"

    def test_limit_returns_few(self):
        """RuntimeCteStep.expected_rows returns 'few' when limit is
        set."""
        rt = RuntimeCteStep(cte_name="c1", tables=["t"], grain="row_level", limit=10)
        assert rt.expected_rows == "few"

    def test_no_limit_returns_many(self):
        """RuntimeCteStep.expected_rows returns 'many' with no limit."""
        rt = RuntimeCteStep(cte_name="c1", tables=["t"], grain="grouped")
        assert rt.expected_rows == "many"


class TestCteValidationResult:
    """Tests for CteValidationResult."""

    def test_valid_result(self):
        """CteValidationResult with no issues."""
        cvr = CteValidationResult(is_valid=True, cte_outputs={"cte1": ["col_a"]})
        assert cvr.is_valid is True
        assert cvr.issues == []


class TestQSimFilter:
    """Tests for QSimFilter."""

    def test_round_trip(self):
        """QSimFilter to_dict/from_dict round trip."""
        qf = QSimFilter(column="orders.status", op="=", value_type="categorical")
        rebuilt = QSimFilter.from_dict(qf.to_dict())
        assert rebuilt.column == "orders.status"
        assert rebuilt.op == "="

    def test_is_expr_comparison_false(self):
        """QSimFilter.is_expr_comparison False when no right_column."""
        qf = QSimFilter(column="t.c", op="=", value_type="categorical")
        assert qf.is_expr_comparison is False

    def test_is_expr_comparison_true(self):
        """QSimFilter.is_expr_comparison True when right_column set."""
        qf = QSimFilter(column="t.c1", op=">", value_type="numeric", right_column="t.c2")
        assert qf.is_expr_comparison is True

    def test_to_dict_excludes_empty_right_column(self):
        """QSimFilter.to_dict omits right_column when empty."""
        qf = QSimFilter(column="t.c", op="=", value_type="categorical")
        d = qf.to_dict()
        assert "right_column" not in d

    def test_to_dict_includes_right_column(self):
        """QSimFilter.to_dict includes right_column when set."""
        qf = QSimFilter(column="t.c1", op=">", value_type="numeric", right_column="t.c2")
        d = qf.to_dict()
        assert d["right_column"] == "t.c2"


class TestQSimHaving:
    """Tests for QSimHaving."""

    def test_round_trip(self):
        """QSimHaving to_dict/from_dict round trip."""
        qh = QSimHaving(expression="COUNT(orders.order_id)", op=">", value_type="number")
        rebuilt = QSimHaving.from_dict(qh.to_dict())
        assert rebuilt.expression == "COUNT(orders.order_id)"

    def test_is_expression_comparison_false(self):
        """QSimHaving.is_expression_comparison False when no
        right_expression."""
        qh = QSimHaving(expression="COUNT(t.id)", op=">", value_type="number")
        assert qh.is_expression_comparison is False

    def test_is_expression_comparison_true(self):
        """QSimHaving.is_expression_comparison True when
        right_expression set."""
        qh = QSimHaving(
            expression="SUM(t.a)",
            op=">",
            value_type="number",
            right_expression="SUM(t.b)",
        )
        assert qh.is_expression_comparison is True

    def test_to_dict_excludes_empty_right_expression(self):
        """QSimHaving.to_dict omits right_expression when empty."""
        qh = QSimHaving(expression="COUNT(t.id)", op=">", value_type="number")
        d = qh.to_dict()
        assert "right_expression" not in d


class TestSimulatorIntent:
    """Tests for SimulatorIntent."""

    def test_round_trip(self):
        """SimulatorIntent to_dict/from_dict round trip."""
        si = SimulatorIntent(
            intent_id="sim_1",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        rebuilt = SimulatorIntent.from_dict(si.to_dict())
        assert rebuilt.intent_id == "sim_1"
        assert rebuilt.tables == ["orders"]

    def test_to_runtime_intent(self):
        """SimulatorIntent.to_runtime_intent returns RuntimeIntent."""
        si = SimulatorIntent(
            intent_id="sim_1",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        ri = si.to_runtime_intent()
        assert isinstance(ri, RuntimeIntent)
        assert ri.tables == ["orders"]

    def test_expansion_metadata_round_trip(self):
        """SimulatorIntent preserves expansion_metadata through round
        trip."""
        em = ExpansionMetadata(operator="add_filter")
        si = SimulatorIntent(
            intent_id="sim_3",
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            expansion_metadata=em,
        )
        rebuilt = SimulatorIntent.from_dict(si.to_dict())
        assert rebuilt.expansion_metadata is not None
        assert rebuilt.expansion_metadata.operator == "add_filter"


class TestConcreteIntentStandalone:
    """Standalone tests for ConcreteIntent."""

    def test_from_dict_round_trip(self):
        """ConcreteIntent from_dict/to_dict round trip."""
        ci = ConcreteIntent(
            intent_id="ci_1",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        rebuilt = ConcreteIntent.from_dict(ci.to_dict())
        assert rebuilt.intent_id == "ci_1"
        assert rebuilt.tables == ["orders"]

    def test_has_join_path_fields(self):
        """ConcreteIntent stores join candidate id and path
        signature."""
        ci = ConcreteIntent(
            intent_id="ci_2",
            tables=["orders", "customers"],
            grain="grouped",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            chosen_join_candidate_id="jc_1",
            chosen_join_path_signature=["orders.customer_id=customers.customer_id"],
        )
        assert ci.chosen_join_candidate_id == "jc_1"
        assert len(ci.chosen_join_path_signature) == 1


class TestTemplate:
    """Tests for Template dataclass."""

    def test_round_trip(self, sample_template):
        """Template to_dict/from_dict round trip."""
        rebuilt = Template.from_dict(sample_template.to_dict())
        assert rebuilt.id == sample_template.id
        assert rebuilt.schema_hash == sample_template.schema_hash
        assert rebuilt.trust_level == sample_template.trust_level

    def test_spark_sql_param_round_trip(self, sample_template):
        """Template spark_sql_param survives to_dict/from_dict."""
        from dataclasses import replace

        tmpl = replace(sample_template, spark_sql_param="SELECT * FROM `events` WHERE `dt` = :p1")
        rebuilt = Template.from_dict(tmpl.to_dict())
        assert rebuilt.spark_sql_param == tmpl.spark_sql_param

    def test_chosen_join_candidate_id_delegates(self, sample_template):
        """Template.chosen_join_candidate_id delegates to
        intent_signature."""
        assert sample_template.chosen_join_candidate_id == sample_template.intent_signature.chosen_join_candidate_id

    def test_chosen_join_path_signature_delegates(self, sample_template):
        """Template.chosen_join_path_signature delegates to
        intent_signature."""
        assert sample_template.chosen_join_path_signature == sample_template.intent_signature.chosen_join_path_signature


class TestRejectedTemplate:
    """Tests for RejectedTemplate dataclass."""

    def test_round_trip(self):
        """RejectedTemplate to_dict/from_dict round trip."""
        ci = ConcreteIntent(
            intent_id="rt_1",
            tables=["orders"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        rvh = RejectedValueHistory(
            param_values=[{"p1": "x"}],
            questions=["q1"],
            natural_language=["nl1"],
            rejection_reasons=["bad"],
            rejection_categories=["wrong_intent"],
        )
        rt = RejectedTemplate(
            id="RT001",
            schema_hash="hash",
            intent_signature=ci,
            intent_key="key",
            tables_used=["orders"],
            sql_param="SELECT 1",
            spark_sql_param="SELECT * FROM `orders`",
            sql_display_param="SELECT 1",
            sql_fp="fp",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="cm",
            value_history=rvh,
        )
        rebuilt = RejectedTemplate.from_dict(rt.to_dict())
        assert rebuilt.id == "RT001"
        assert rebuilt.spark_sql_param == "SELECT * FROM `orders`"
        assert len(rebuilt.value_history) == 1

    def test_delegates_join_fields(self):
        """RejectedTemplate delegates join fields to
        intent_signature."""
        ci = ConcreteIntent(
            intent_id="rt_2",
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            chosen_join_candidate_id="jc_x",
            chosen_join_path_signature=["a=b"],
        )
        rvh = RejectedValueHistory(
            param_values=[],
            questions=[],
            natural_language=[],
            rejection_reasons=[],
            rejection_categories=[],
        )
        rt = RejectedTemplate(
            id="RT002",
            schema_hash="h",
            intent_signature=ci,
            intent_key="k",
            tables_used=["t"],
            sql_param="",
            sql_display_param="",
            sql_fp="",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="",
            value_history=rvh,
        )
        assert rt.chosen_join_candidate_id == "jc_x"
        assert rt.chosen_join_path_signature == ["a=b"]


class TestSimulatorResult:
    """Tests for SimulatorResult dataclass."""

    def test_to_dict(self):
        """SimulatorResult.to_dict serializes all fields."""
        ri = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        sr = SimulatorResult(intent=ri, question="test question", success=True, confidence=0.9)
        d = sr.to_dict()
        assert d["question"] == "test question"
        assert d["success"] is True
        assert d["confidence"] == 0.9

    def test_defaults(self):
        """SimulatorResult defaults."""
        ri = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        sr = SimulatorResult(intent=ri, question="q")
        assert sr.sql is None
        assert sr.success is False
        assert sr.error is None
        assert sr.validation_issues == []


class TestTemplateMatch:
    """Tests for TemplateMatch dataclass."""

    def test_defaults(self):
        """TemplateMatch has correct defaults."""
        tm = TemplateMatch()
        assert tm.intent is None
        assert tm.best_template is None
        assert tm.similarity_score == 0.0
        assert tm.reuse_type == "none"


class TestFKEdge:
    """Tests for FKEdge dataclass."""

    def test_fields(self):
        """FKEdge stores src/dst table and column info."""
        fk = FKEdge(
            src_table="orders",
            src_cols=["customer_id"],
            dst_table="customers",
            dst_cols=["customer_id"],
        )
        assert fk.src_table == "orders"
        assert fk.dst_cols == ["customer_id"]


class TestValueDomain:
    """Tests for ValueDomain dataclass."""

    def test_defaults(self):
        """ValueDomain has correct defaults."""
        vd = ValueDomain()
        assert vd.values == []
        assert vd.min_val is None
        assert vd.max_val is None
        assert vd.data_type is None

    def test_with_values(self):
        """ValueDomain stores values."""
        vd = ValueDomain(values=["a", "b"], min_val="a", max_val="b", data_type="varchar")
        assert len(vd.values) == 2
        assert vd.data_type == "varchar"


class TestTableMetadata:
    """Tests for TableMetadata."""

    def test_column_names(self):
        """TableMetadata.column_names returns column keys."""
        tm = TableMetadata(
            name="t",
            columns={
                "c1": ColumnMetadata(name="c1", data_type="int", distinct_count=1, row_count=1),
                "c2": ColumnMetadata(name="c2", data_type="text", distinct_count=1, row_count=1),
            },
            primary_key=["c1"],
            foreign_keys=[],
        )
        assert set(tm.column_names) == {"c1", "c2"}

    def test_round_trip(self):
        """TableMetadata to_dict/from_dict round trip."""
        tm = TableMetadata(
            name="t",
            columns={"c1": ColumnMetadata(name="c1", data_type="int", distinct_count=1, row_count=1)},
            primary_key=["c1"],
            foreign_keys=[FKEdge(src_table="t", src_cols=["c1"], dst_table="u", dst_cols=["c1"])],
            role="FACT",
            row_count=10,
            description="test table",
        )
        rebuilt = TableMetadata.from_dict(tm.to_dict())
        assert rebuilt.name == "t"
        assert rebuilt.role == "FACT"
        assert rebuilt.row_count == 10
        assert len(rebuilt.foreign_keys) == 1


class TestSchemaGraphMethods:
    """Tests for SchemaGraph accessor methods."""

    def test_table_names(self, schema_graph):
        """SchemaGraph.table_names returns all table names."""
        assert set(schema_graph.table_names) == {"customers", "orders", "products"}

    def test_fk_edges(self, schema_graph):
        """SchemaGraph.fk_edges returns all FK edges from all tables."""
        edges = schema_graph.fk_edges
        assert len(edges) == 2

    def test_get_column_found(self, schema_graph):
        """SchemaGraph.get_column returns ColumnMetadata when found."""
        col = schema_graph.get_column("orders", "amount")
        assert col is not None
        assert col.name == "amount"

    def test_get_column_not_found(self, schema_graph):
        """SchemaGraph.get_column returns None for missing column."""
        assert schema_graph.get_column("orders", "nonexistent") is None

    def test_get_column_missing_table(self, schema_graph):
        """SchemaGraph.get_column returns None for missing table."""
        assert schema_graph.get_column("nonexistent", "col") is None

    def test_schema_literal_text(self, schema_graph):
        """SchemaGraph.schema_literal_text returns non-empty string."""
        text = schema_graph.schema_literal_text
        assert "TABLE" in text
        assert "customers" in text

    def test_schema_literal_text_join_paths_excluded(self):
        t1 = TableMetadata(
            name="orders",
            columns={"order_id": ColumnMetadata(name="order_id", data_type="integer", is_primary_key=True)},
            primary_key=["order_id"],
            foreign_keys=[],
        )
        t2 = TableMetadata(
            name="customers",
            columns={"customer_id": ColumnMetadata(name="customer_id", data_type="integer", is_primary_key=True)},
            primary_key=["customer_id"],
            foreign_keys=[],
        )
        sg = SchemaGraph(
            tables={"orders": t1, "customers": t2},
            join_paths_multi={
                "orders": {
                    "customers": [
                        [
                            {
                                "src_table": "orders",
                                "src_col": "customer_id",
                                "dst_table": "customers",
                                "dst_col": "customer_id",
                            }
                        ]
                    ]
                },
                "customers": {
                    "orders": [
                        [
                            {
                                "src_table": "orders",
                                "src_col": "customer_id",
                                "dst_table": "customers",
                                "dst_col": "customer_id",
                            }
                        ]
                    ]
                },
            },
            schema_hash="h",
        )
        text = sg.schema_literal_text
        assert "JOIN PATHS:" not in text

    def test_schema_literal_text_no_join_paths(self):
        t1 = TableMetadata(
            name="items",
            columns={"item_id": ColumnMetadata(name="item_id", data_type="integer", is_primary_key=True)},
            primary_key=["item_id"],
            foreign_keys=[],
        )
        sg = SchemaGraph(tables={"items": t1}, join_paths_multi={}, schema_hash="h")
        text = sg.schema_literal_text
        assert "JOIN PATHS:" not in text

    def test_schema_literal_text_enriched_roles(self):
        """schema_literal_text includes table role, description, column role, and hint."""
        t1 = TableMetadata(
            name="payment",
            role="fact",
            description="customer payments",
            columns={
                "payment_id": ColumnMetadata(
                    name="payment_id",
                    data_type="integer",
                    is_primary_key=True,
                    role="identifier",
                ),
                "amount": ColumnMetadata(
                    name="amount",
                    data_type="numeric",
                    role="numeric_measure",
                    description="revenue/income amount",
                ),
            },
            primary_key=["payment_id"],
            foreign_keys=[],
        )
        sg = SchemaGraph(tables={"payment": t1}, join_paths_multi={}, schema_hash="h")
        text = sg.schema_literal_text
        assert "(fact)" in text
        assert "— customer payments" in text
        assert "[numeric_measure]" in text
        assert "— revenue/income amount" in text
        assert "[identifier]" not in text

    def test_round_trip(self, schema_graph):
        """SchemaGraph to_dict/from_dict round trip."""
        rebuilt = SchemaGraph.from_dict(schema_graph.to_dict())
        assert set(rebuilt.table_names) == set(schema_graph.table_names)
        assert rebuilt.schema_hash == schema_graph.schema_hash


class TestColumnMetadataRoundTrip:
    """Tests for ColumnMetadata serialization."""

    def test_round_trip(self):
        """ColumnMetadata to_dict/from_dict round trip."""
        cm = ColumnMetadata(
            name="amount",
            data_type="numeric",
            role=ColumnRole.NUMERIC_MEASURE.value,
            distinct_count=50,
            distinct_ratio=0.5,
            row_count=100,
        )
        rebuilt = ColumnMetadata.from_dict(cm.to_dict())
        assert rebuilt.name == "amount"
        assert rebuilt.role == ColumnRole.NUMERIC_MEASURE.value

    def test_round_trip_description(self):
        """ColumnMetadata preserves description through round trip."""
        cm = ColumnMetadata(
            name="amount",
            data_type="numeric",
            description="revenue/income amount",
        )
        rebuilt = ColumnMetadata.from_dict(cm.to_dict())
        assert rebuilt.description == "revenue/income amount"

    def test_round_trip_description_empty(self):
        """ColumnMetadata defaults description to empty string."""
        cm = ColumnMetadata(name="id", data_type="integer")
        rebuilt = ColumnMetadata.from_dict(cm.to_dict())
        assert rebuilt.description == ""

    def test_is_usable(self):
        """ColumnMetadata.is_usable True for non-AUDIT columns with
        sufficient variance."""
        cm = ColumnMetadata(
            name="c",
            data_type="int",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=5,
            row_count=10,
        )
        assert cm.is_usable is True

    def test_is_usable_low_distinct(self):
        """ColumnMetadata.is_usable False when distinct_count <= 1."""
        cm = ColumnMetadata(
            name="c",
            data_type="int",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=1,
            row_count=10,
        )
        assert cm.is_usable is False

    def test_is_usable_audit(self):
        """ColumnMetadata.is_usable False for AUDIT columns."""
        cm = ColumnMetadata(
            name="c",
            data_type="timestamp",
            role=ColumnRole.AUDIT.value,
            distinct_count=1,
            row_count=1,
        )
        assert cm.is_usable is False

    def test_get_valid_having_ops(self):
        """ColumnMetadata.get_valid_having_ops returns list of ops."""
        cm = ColumnMetadata(
            name="c",
            data_type="numeric",
            role=ColumnRole.NUMERIC_MEASURE.value,
            distinct_count=50,
            row_count=100,
            valid_having_ops=["=", "!=", "<", "<=", ">", ">="],
        )
        ops = cm.get_valid_having_ops()
        assert ">" in ops
        assert "<" in ops

    def test_from_dict_fk_target_tuple(self):
        """ColumnMetadata.from_dict accepts fk_target as tuple."""
        d = {
            "name": "ref_id",
            "data_type": "int",
            "is_foreign_key": True,
            "fk_target": ("other", "id"),
        }
        cm = ColumnMetadata.from_dict(d)
        assert cm.fk_target == ("other", "id")

    def test_from_dict_fk_target_list_converted_to_tuple(self):
        """ColumnMetadata.from_dict converts fk_target list to tuple."""
        d = {
            "name": "ref_id",
            "data_type": "int",
            "is_foreign_key": True,
            "fk_target": ["other", "id"],
        }
        cm = ColumnMetadata.from_dict(d)
        assert cm.fk_target == ("other", "id")

    def test_post_init_sets_value_type_from_data_type_when_empty(self):
        """ColumnMetadata __post_init__ sets value_type from data_type when value_type empty."""
        cm = ColumnMetadata(name="x", data_type="varchar(100)", value_type="")
        assert cm.value_type == "string"

    def test_post_init_preserves_explicit_value_type(self):
        """ColumnMetadata __post_init__ does not overwrite explicit value_type."""
        cm = ColumnMetadata(name="x", data_type="varchar(100)", value_type="integer")
        assert cm.value_type == "integer"

    def test_is_filterable_excluded_pattern(self):
        """ColumnMetadata.is_filterable False when name matches excluded pattern."""
        cm = ColumnMetadata(
            name="user_password",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=10,
            row_count=100,
        )
        assert cm.is_filterable is False

    def test_is_filterable_override_true(self):
        """ColumnMetadata.is_filterable respects override True."""
        cm = ColumnMetadata(
            name="c",
            data_type="text",
            role=ColumnRole.FREE_TEXT.value,
            distinct_count=50,
            row_count=100,
            is_filterable_override=True,
        )
        assert cm.is_filterable is True

    def test_is_filterable_override_false(self):
        """ColumnMetadata.is_filterable respects override False."""
        cm = ColumnMetadata(
            name="c",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=50,
            row_count=100,
            is_filterable_override=False,
        )
        assert cm.is_filterable is False

    def test_is_boolean_like_data_type_contains_bool(self):
        """ColumnMetadata.is_boolean_like True when data_type contains bool."""
        cm = ColumnMetadata(name="flag", data_type="boolean", distinct_count=2)
        assert cm.is_boolean_like is True

    def test_is_boolean_like_false_when_distinct_not_two(self):
        """ColumnMetadata.is_boolean_like False when distinct_count is not 2."""
        cm = ColumnMetadata(
            name="status",
            data_type="varchar",
            distinct_count=3,
            top_k_values=["a", "b", "c"],
        )
        assert cm.is_boolean_like is False

    def test_is_boolean_like_false_when_top_k_not_two(self):
        """ColumnMetadata.is_boolean_like False when top_k_values length is not 2."""
        cm = ColumnMetadata(
            name="status",
            data_type="varchar",
            distinct_count=2,
            top_k_values=["only_one"],
        )
        assert cm.is_boolean_like is False

    def test_get_valid_filter_ops_uses_stored_when_set(self):
        """ColumnMetadata.get_valid_filter_ops returns stored ops plus null when set."""
        cm = ColumnMetadata(
            name="c",
            data_type="varchar",
            valid_filter_ops=["=", "!=", "in"],
        )
        ops = cm.get_valid_filter_ops()
        assert "=" in ops
        assert "is null" in ops
        assert "is not null" in ops

    def test_get_valid_filter_ops_foreign_key_includes_range(self):
        """ColumnMetadata.get_valid_filter_ops for FK includes range operators."""
        cm = ColumnMetadata(
            name="ref_id",
            data_type="int",
            is_foreign_key=True,
            role=ColumnRole.IDENTIFIER.value,
            distinct_count=10,
            valid_filter_ops=["=", "!=", "<", "<=", ">", ">=", "between", "in", "not in", "is null", "is not null"],
        )
        ops = cm.get_valid_filter_ops()
        assert "between" in ops
        assert ">=" in ops

    def test_get_valid_filter_ops_boolean_excludes_like(self):
        """ColumnMetadata.get_valid_filter_ops for boolean excludes like."""
        cm = ColumnMetadata(
            name="active",
            data_type="bool",
            role=ColumnRole.BOOLEAN.value,
            distinct_count=2,
            valid_filter_ops=["=", "!=", "in", "not in", "is null", "is not null"],
        )
        ops = cm.get_valid_filter_ops()
        assert "like" not in ops
        assert "=" in ops

    def test_get_valid_filter_ops_numeric_categorical_includes_between(self):
        """ColumnMetadata.get_valid_filter_ops for numeric_categorical includes between."""
        cm = ColumnMetadata(
            name="code",
            data_type="int",
            role=ColumnRole.NUMERIC_CATEGORICAL.value,
            distinct_count=20,
            valid_filter_ops=["=", "!=", "in", "not in", "<", "<=", ">", ">=", "between", "is null", "is not null"],
        )
        ops = cm.get_valid_filter_ops()
        assert "between" in ops

    def test_get_valid_aggregations_uses_stored_when_set(self):
        """ColumnMetadata.get_valid_aggregations returns stored when set."""
        cm = ColumnMetadata(
            name="c",
            data_type="numeric",
            valid_aggregations=["COUNT", "SUM"],
        )
        assert cm.get_valid_aggregations() == {"count", "sum"}

    def test_get_valid_aggregations_identifier_only_count(self):
        """ColumnMetadata.get_valid_aggregations IDENTIFIER returns count only."""
        cm = ColumnMetadata(
            name="id",
            data_type="int",
            role=ColumnRole.IDENTIFIER.value,
            distinct_count=100,
            valid_aggregations=["count"],
        )
        assert cm.get_valid_aggregations() == {"count"}

    def test_get_valid_aggregations_audit_allows_none(self):
        """ColumnMetadata.get_valid_aggregations AUDIT returns empty set."""
        cm = ColumnMetadata(
            name="updated_at",
            data_type="timestamp",
            role=ColumnRole.AUDIT.value,
        )
        assert cm.get_valid_aggregations() == set()

    def test_get_valid_having_ops_uses_stored_when_set(self):
        """ColumnMetadata.get_valid_having_ops returns stored when set."""
        cm = ColumnMetadata(
            name="c",
            data_type="numeric",
            valid_having_ops=["=", ">"],
        )
        assert cm.get_valid_having_ops() == ["=", ">"]

    def test_get_valid_having_ops_empty_when_not_aggregatable(self):
        """ColumnMetadata.get_valid_having_ops empty when not aggregatable."""
        cm = ColumnMetadata(
            name="label",
            data_type="varchar",
            role=ColumnRole.CATEGORICAL.value,
            distinct_count=100,
            is_aggregatable_override=False,
        )
        assert cm.get_valid_having_ops() == []


class TestExpansionMetadata:
    """Tests for ExpansionMetadata."""

    def test_round_trip(self):
        """ExpansionMetadata to_dict/from_dict round trip."""
        em = ExpansionMetadata(operator="add_filter", parent_intent_id="p1")
        rebuilt = ExpansionMetadata.from_dict(em.to_dict())
        assert rebuilt.operator == "add_filter"
        assert rebuilt.parent_intent_id == "p1"

    def test_defaults(self):
        """ExpansionMetadata defaults parent_intent_id to None."""
        em = ExpansionMetadata(operator="op")
        assert em.parent_intent_id is None


class TestCteOutputColumnMeta:
    """Tests for CteOutputColumnMeta."""

    def test_round_trip(self):
        """CteOutputColumnMeta to_dict/from_dict round trip."""
        meta = CteOutputColumnMeta(
            source="orders.amount",
            base_column="amount",
            agg_func="sum",
            role=ColumnRole.NUMERIC_MEASURE.value,
        )
        rebuilt = CteOutputColumnMeta.from_dict(meta.to_dict())
        assert rebuilt.source == "orders.amount"
        assert rebuilt.agg_func == "sum"

    def test_defaults(self):
        """CteOutputColumnMeta has correct defaults."""
        meta = CteOutputColumnMeta(source="t.c")
        assert meta.base_column == ""
        assert meta.filterable is True
        assert meta.aggregatable is True
        assert meta.groupable is True


class TestRetryFailureContext:
    """Tests for RetryFailureContext."""

    def test_fields(self):
        """RetryFailureContext stores failure context."""
        ctx = RetryFailureContext(
            failure_type="missing_table",
            required_tables=["orders", "customers"],
            used_tables={"orders"},
            missing_tables={"customers"},
            attempt_number=1,
        )
        assert ctx.failure_type == "missing_table"
        assert ctx.missing_tables == {"customers"}


class TestIntentIssue:
    """Tests for IntentIssue."""

    def test_round_trip(self):
        """IntentIssue to_dict/from_dict round trip."""
        issue = IntentIssue(
            issue_id="I001",
            category="wrong_tables",
            severity="error",
            message="missing table",
            context={"table": "orders"},
        )
        rebuilt = IntentIssue.from_dict(issue.to_dict())
        assert rebuilt.issue_id == "I001"
        assert rebuilt.context == {"table": "orders"}


class TestIntentValidationResult:
    """Tests for IntentValidationResult."""

    def test_is_valid_no_issues(self):
        """IntentValidationResult is_valid True with no issues."""
        ivr = IntentValidationResult()
        assert ivr.is_valid is True

    def test_is_valid_false_with_error(self):
        """IntentValidationResult is_valid False with error issue."""
        issue = IntentIssue(
            issue_id="I001",
            category="c",
            severity="error",
            message="err",
        )
        ivr = IntentValidationResult(issues=[issue])
        assert ivr.is_valid is False

    def test_is_valid_true_with_warning_only(self):
        """IntentValidationResult is_valid True with only warnings."""
        issue = IntentIssue(
            issue_id="I002",
            category="c",
            severity="warning",
            message="warn",
        )
        ivr = IntentValidationResult(issues=[issue])
        assert ivr.is_valid is True

    def test_issue_signature(self):
        """IntentValidationResult.issue_signature returns string."""
        issue = IntentIssue(
            issue_id="I001",
            category="c",
            severity="error",
            message="err",
        )
        ivr = IntentValidationResult(issues=[issue])
        assert isinstance(ivr.issue_signature, str)

    def test_round_trip(self):
        """IntentValidationResult to_dict/from_dict round trip."""
        issue = IntentIssue(
            issue_id="I001",
            category="c",
            severity="error",
            message="err",
        )
        ivr = IntentValidationResult(issues=[issue])
        rebuilt = IntentValidationResult.from_dict(ivr.to_dict())
        assert len(rebuilt.issues) == 1
        assert rebuilt.issues[0].issue_id == "I001"


class TestTemplateStats:
    """Tests for TemplateStats."""

    def test_defaults(self):
        """TemplateStats defaults to zero."""
        ts = TemplateStats()
        assert ts.accept == 0
        assert ts.reject == 0

    def test_round_trip(self):
        """TemplateStats to_dict/from_dict round trip."""
        ts = TemplateStats(accept=5, reject=2)
        rebuilt = TemplateStats.from_dict(ts.to_dict())
        assert rebuilt.accept == 5
        assert rebuilt.reject == 2


class TestQSimSkeleton:
    """Tests for QSimSkeleton."""

    def test_fields(self):
        """QSimSkeleton stores skeleton fields."""
        sk = QSimSkeleton(
            tables=["orders"],
            has_aggregation=True,
            num_filters=2,
            num_groupby=1,
            has_orderby=True,
            has_having=False,
        )
        assert sk.tables == ["orders"]
        assert sk.has_aggregation is True
        assert sk.num_filters == 2

    def test_defaults(self):
        """QSimSkeleton has defaults for optional fields."""
        sk = QSimSkeleton(
            tables=["t"],
            has_aggregation=False,
            num_filters=0,
            num_groupby=0,
            has_orderby=False,
            has_having=False,
        )
        assert sk.has_distinct is False
        assert sk.has_expr_comparison is False


class TestQSimSummary:
    """Tests for QSimSummary."""

    def test_round_trip(self):
        """QSimSummary to_dict/from_dict round trip."""
        qs = QSimSummary(timestamp="2026-01-01T00:00:00", num_intents=20, num_questions=100, seed=42)
        rebuilt = QSimSummary.from_dict(qs.to_dict())
        assert rebuilt.timestamp == "2026-01-01T00:00:00"
        assert rebuilt.seed == 42


class TestQueryPlan:
    """Tests for QueryPlan."""

    def test_fields(self):
        """QueryPlan stores plan fields."""
        qp = QueryPlan(
            sql="SELECT 1",
            chosen_join_candidate_id="jc1",
            chosen_join_path_signature=["a=b"],
        )
        assert qp.sql == "SELECT 1"
        assert qp.chosen_join_candidate_id == "jc1"


class TestValidationResult:
    """Tests for ValidationResult."""

    def test_defaults(self):
        """ValidationResult has correct defaults."""
        vr = ValidationResult(valid=True)
        assert vr.errors == []
        assert vr.warnings == []
        assert vr.extra_tables == set()

    def test_invalid_with_errors(self):
        """ValidationResult stores errors."""
        vr = ValidationResult(valid=False, errors=["missing column"])
        assert not vr.valid
        assert len(vr.errors) == 1


class TestTemplateInfo:
    """Tests for TemplateInfo."""

    def test_fields(self):
        """TemplateInfo stores user-facing fields."""
        ti = TemplateInfo(
            id="T1",
            natural_language="total orders",
            example_question="how many orders",
            trust_level="trusted",
            source="human",
        )
        assert ti.id == "T1"
        assert ti.trust_level == "trusted"


class TestRejectedTemplateInfo:
    """Tests for RejectedTemplateInfo."""

    def test_fields(self):
        """RejectedTemplateInfo stores user-facing fields."""
        rti = RejectedTemplateInfo(
            id="RT1",
            natural_language="bad query",
            example_question="q",
            rejection_category="wrong_intent",
            rejection_count=3,
        )
        assert rti.rejection_category == "wrong_intent"
        assert rti.rejection_count == 3


class TestSimulatorSummary:
    """Tests for SimulatorSummary."""

    def test_fields(self):
        """SimulatorSummary stores run statistics."""
        ss = SimulatorSummary(version=1, total=10, success=8, failed=2, success_rate=0.8)
        assert ss.success_rate == 0.8
        assert ss.total == 10


class TestQSimRange:
    """Tests for QSimRange."""

    def test_fields(self):
        """QSimRange stores range tuples."""
        qr = QSimRange(num_intents_range=(5, 50), num_questions_range=(10, 200))
        assert qr.num_intents_range == (5, 50)


class TestSchemaLimits:
    """Tests for SchemaLimits."""

    def test_fields(self):
        """SchemaLimits stores computed limits."""
        sl = SchemaLimits(max_filters=4, max_groupby=2, max_tables=3)
        assert sl.max_filters == 4
        assert sl.max_tables == 3


class TestSkeletonPool:
    """Tests for SkeletonPool."""

    def test_empty_pool(self):
        """Empty SkeletonPool has zero-length keys."""
        pool = SkeletonPool(
            tier_a_by_table_set={},
            tier_b_by_table_set={},
            tier_c_by_table_set={},
            table_set_keys=[],
            tier_a_indices={},
            tier_b_indices={},
            tier_c_indices={},
        )
        assert pool.table_set_keys == []
        assert pool.current_table_idx == 0

    def test_populated_pool(self):
        """SkeletonPool stores tier data correctly."""
        skel = QSimSkeleton(
            tables=["orders"],
            has_aggregation=False,
            num_filters=0,
            num_groupby=0,
            has_orderby=False,
            has_having=False,
            has_distinct=False,
            has_expr_comparison=False,
        )
        pool = SkeletonPool(
            tier_a_by_table_set={"orders": [skel]},
            tier_b_by_table_set={"orders": []},
            tier_c_by_table_set={"orders": []},
            table_set_keys=["orders"],
            tier_a_indices={"orders": 0},
            tier_b_indices={"orders": 0},
            tier_c_indices={"orders": 0},
        )
        assert len(pool.tier_a_by_table_set["orders"]) == 1
        assert pool.table_set_keys == ["orders"]

    def test_current_table_idx_default(self):
        """Default current_table_idx is 0."""
        pool = SkeletonPool(
            tier_a_by_table_set={},
            tier_b_by_table_set={},
            tier_c_by_table_set={},
            table_set_keys=[],
            tier_a_indices={},
            tier_b_indices={},
            tier_c_indices={},
        )
        assert pool.current_table_idx == 0
