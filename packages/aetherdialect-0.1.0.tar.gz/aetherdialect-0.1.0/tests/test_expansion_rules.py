"""Tests for expansion_rules module: LLM prompt context builders."""

from __future__ import annotations

from unittest.mock import patch

from text2sql.contracts_base import (
    ColumnMetadata,
    SchemaGraph,
    TableMetadata,
    TableRole,
)
from text2sql.contracts_core import (
    FilterParam,
    NormalizedExpr,
    OrderByCol,
    SelectCol,
    SimulatorIntent,
)
from text2sql.expansion_rules import (
    _build_b_series_context,
    _build_expansion_context,
    _format_column_details,
    _format_intent_state,
    llm_expand_operator,
)


def _sim_intent(**overrides) -> SimulatorIntent:
    """Build a SimulatorIntent with sensible defaults."""
    defaults = dict(
        intent_id="test_001",
        tables=["orders"],
        grain="row_level",
        select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
        group_by_cols=[],
        order_by_cols=[],
        filters_param=[],
        having_param=[],
    )
    defaults.update(overrides)
    return SimulatorIntent(**defaults)


def _make_column_metadata():
    """Build a minimal column metadata dict for testing."""
    return {
        "orders": {
            "order_id": {
                "data_type": "integer",
                "role": "identifier",
                "nullable": False,
                "cardinality": 500,
            },
            "amount": {
                "data_type": "numeric",
                "role": "numeric_measure",
                "nullable": True,
                "cardinality": 300,
            },
            "status": {
                "data_type": "varchar",
                "role": "dimension_attribute",
                "nullable": False,
                "cardinality": 5,
            },
            "order_date": {
                "data_type": "date",
                "role": "date",
                "nullable": False,
                "cardinality": 365,
            },
        },
        "customers": {
            "customer_id": {
                "data_type": "integer",
                "role": "identifier",
                "nullable": False,
                "cardinality": 100,
            },
            "name": {
                "data_type": "varchar",
                "role": "dimension_attribute",
                "nullable": False,
                "cardinality": 95,
            },
        },
    }


class TestFormatIntentState:
    """Tests for _format_intent_state."""

    def test_basic_intent(self):
        """Basic intent should show tables and grain."""
        intent = _sim_intent()
        text = _format_intent_state(intent)
        assert "orders" in text
        assert "row_level" in text

    def test_with_filters(self):
        """Filters should appear in output."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="=",
                    value_type="string",
                    param_key="p1",
                    raw_value="shipped",
                ),
            ],
        )
        text = _format_intent_state(intent)
        assert "Filters:" in text
        assert "orders.status" in text

    def test_with_group_by(self):
        """Group by columns should appear in output."""
        intent = _sim_intent(
            grain="grouped",
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
        )
        text = _format_intent_state(intent)
        assert "Group By:" in text

    def test_with_order_by(self):
        """Order by columns should appear in output."""
        intent = _sim_intent(
            order_by_cols=[
                OrderByCol(expr=NormalizedExpr.from_column("orders.amount"), direction="DESC"),
            ],
        )
        text = _format_intent_state(intent)
        assert "Order By:" in text
        assert "DESC" in text

    def test_with_having(self):
        """Having clauses should appear in output."""
        intent = _sim_intent(
            grain="grouped",
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
            having_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_agg("count", "orders.order_id"),
                    op=">",
                    value_type="number",
                    param_key="h1",
                    raw_value="5",
                ),
            ],
        )
        text = _format_intent_state(intent)
        assert "Having:" in text

    def test_empty_optional_sections(self):
        """Intent with no optional sections should only show tables and
        grain."""
        intent = _sim_intent(select_cols=[], filters_param=[], group_by_cols=[])
        text = _format_intent_state(intent)
        assert "Tables:" in text
        assert "Grain:" in text
        assert "Filters:" not in text
        assert "Group By:" not in text

    def test_select_cols_shown(self):
        """Select columns should appear in output."""
        intent = _sim_intent(
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_column("orders.order_id")),
                SelectCol(expr=NormalizedExpr.from_agg("sum", "orders.amount")),
            ],
        )
        text = _format_intent_state(intent)
        assert "Select:" in text

    def test_expr_filter_with_right_expr(self):
        """Filter with right_expr should show column-to-column
        comparison."""
        intent = _sim_intent(
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.amount"),
                    op=">",
                    value_type="number",
                    param_key="p1",
                    right_expr=NormalizedExpr.from_column("orders.order_id"),
                ),
            ],
        )
        text = _format_intent_state(intent)
        assert "Filters:" in text


class TestFormatColumnDetails:
    """Tests for _format_column_details."""

    def test_basic_output(self):
        """Should list columns with type and role."""
        meta = _make_column_metadata()
        text = _format_column_details(meta, ["orders"])
        assert "orders:" in text
        assert "order_id" in text
        assert "integer" in text

    def test_multiple_tables(self):
        """Should list columns for all requested tables."""
        meta = _make_column_metadata()
        text = _format_column_details(meta, ["orders", "customers"])
        assert "orders:" in text
        assert "customers:" in text

    def test_missing_table_skipped(self):
        """Missing table should be silently skipped."""
        meta = _make_column_metadata()
        text = _format_column_details(meta, ["nonexistent"])
        assert text == ""

    def test_nullable_shown(self):
        """Nullable/required should appear in output."""
        meta = _make_column_metadata()
        text = _format_column_details(meta, ["orders"])
        assert "nullable" in text or "required" in text

    def test_cardinality_shown(self):
        """Cardinality should appear when present."""
        meta = _make_column_metadata()
        text = _format_column_details(meta, ["orders"])
        assert "cardinality=" in text


class TestBuildBSeriesContext:
    """Tests for _build_b_series_context."""

    def _make_schema(self):
        """Build a minimal schema for B-series testing."""
        tables = {
            "orders": TableMetadata(
                name="orders",
                columns={"id": ColumnMetadata(name="id", data_type="int")},
                primary_key=["id"],
                foreign_keys=[],
                role=TableRole.FACT.value,
                row_count=100,
            ),
            "customers": TableMetadata(
                name="customers",
                columns={"id": ColumnMetadata(name="id", data_type="int")},
                primary_key=["id"],
                foreign_keys=[],
                role=TableRole.DIMENSION.value,
                row_count=50,
            ),
            "products": TableMetadata(
                name="products",
                columns={"id": ColumnMetadata(name="id", data_type="int")},
                primary_key=["id"],
                foreign_keys=[],
                role=TableRole.DIMENSION.value,
                row_count=30,
            ),
        }
        return SchemaGraph(tables=tables, join_paths_multi={}, schema_hash="test")

    def test_lists_available_tables(self):
        """Available tables should be listed by role."""
        schema = self._make_schema()
        text = _build_b_series_context(schema, ["orders"])
        assert "customers" in text or "products" in text
        assert "Schema Relationships" in text

    def test_current_tables_excluded(self):
        """Current tables should not appear in available list."""
        schema = self._make_schema()
        text = _build_b_series_context(schema, ["orders", "customers"])
        lines = text.split("\n")
        for line in lines:
            if "fact" in line.lower() and "Available" not in line:
                assert "orders" not in line

    def test_fk_map_connections_shown(self):
        """FK connections should appear when fk_map is provided."""
        schema = self._make_schema()
        fk_map = {
            "orders": [{"target_table": "customers"}],
        }
        text = _build_b_series_context(schema, ["orders"], fk_map=fk_map)
        assert "Foreign Key Connections" in text
        assert "customers" in text


class TestBuildExpansionContext:
    """Tests for _build_expansion_context."""

    def _make_schema(self):
        """Build a minimal schema."""
        tables = {
            "orders": TableMetadata(
                name="orders",
                columns={"id": ColumnMetadata(name="id", data_type="int")},
                primary_key=["id"],
                foreign_keys=[],
                role=TableRole.FACT.value,
                row_count=100,
            ),
        }
        return SchemaGraph(tables=tables, join_paths_multi={}, schema_hash="test")

    def test_includes_query_state(self):
        """Context should include current query state."""
        intent = _sim_intent()
        meta = _make_column_metadata()
        schema = self._make_schema()
        text = _build_expansion_context(intent, "A1", schema, meta)
        assert "Current Query State" in text

    def test_includes_available_columns(self):
        """Context should include available columns section."""
        intent = _sim_intent()
        meta = _make_column_metadata()
        schema = self._make_schema()
        text = _build_expansion_context(intent, "A1", schema, meta)
        assert "Available Columns" in text

    def test_a1_includes_filter_suitable(self):
        """A1 context should include filter-suitable columns."""
        intent = _sim_intent()
        meta = _make_column_metadata()
        schema = self._make_schema()
        text = _build_expansion_context(intent, "A1", schema, meta)
        assert "Filter-Suitable Columns" in text

    def test_a3_includes_aggregatable(self):
        """A3 context should include aggregatable numeric columns."""
        intent = _sim_intent()
        meta = _make_column_metadata()
        schema = self._make_schema()
        text = _build_expansion_context(intent, "A3", schema, meta)
        assert "Aggregatable Columns" in text

    def test_b_series_includes_schema_relationships(self):
        """B-series context should include schema relationships."""
        intent = _sim_intent()
        meta = _make_column_metadata()
        schema = self._make_schema()
        text = _build_expansion_context(intent, "B1", schema, meta)
        assert "Schema Relationships" in text


class TestLlmExpandOperator:
    """Tests for llm_expand_operator."""

    def test_unknown_operator_returns_empty(self):
        """Unknown operator code should return empty list."""
        schema = SchemaGraph(
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={"id": ColumnMetadata(name="id", data_type="int")},
                    primary_key=["id"],
                    foreign_keys=[],
                    row_count=10,
                )
            },
            join_paths_multi={},
            schema_hash="h",
        )
        intent = _sim_intent()
        result = llm_expand_operator(intent, "Z99", schema, _make_column_metadata())
        assert result == []

    @patch("text2sql.expansion_rules.llm_json")
    def test_llm_returns_list(self, mock_llm):
        """When LLM returns a list, it should be returned directly."""
        mock_llm.return_value = [{"column": "orders.status", "op": "=", "value_type": "string"}]
        schema = SchemaGraph(
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={"status": ColumnMetadata(name="status", data_type="varchar")},
                    primary_key=[],
                    foreign_keys=[],
                    row_count=100,
                )
            },
            join_paths_multi={},
            schema_hash="h",
        )
        intent = _sim_intent()
        result = llm_expand_operator(intent, "A1", schema, _make_column_metadata())
        assert len(result) == 1

    @patch("text2sql.expansion_rules.llm_json")
    def test_llm_returns_dict_with_expansions(self, mock_llm):
        """When LLM returns a dict with 'expansions' key, extract the
        list."""
        mock_llm.return_value = {"expansions": [{"column": "orders.amount"}]}
        schema = SchemaGraph(
            tables={
                "orders": TableMetadata(
                    name="orders",
                    columns={"amount": ColumnMetadata(name="amount", data_type="numeric")},
                    primary_key=[],
                    foreign_keys=[],
                    row_count=100,
                )
            },
            join_paths_multi={},
            schema_hash="h",
        )
        intent = _sim_intent()
        result = llm_expand_operator(intent, "A3", schema, _make_column_metadata())
        assert len(result) == 1

    @patch("text2sql.expansion_rules.llm_json")
    def test_llm_exception_returns_empty(self, mock_llm):
        """LLM exception should return empty list."""
        mock_llm.side_effect = RuntimeError("API error")
        schema = SchemaGraph(
            tables={
                "t": TableMetadata(
                    name="t",
                    columns={"c": ColumnMetadata(name="c", data_type="int")},
                    primary_key=[],
                    foreign_keys=[],
                    row_count=10,
                )
            },
            join_paths_multi={},
            schema_hash="h",
        )
        intent = _sim_intent()
        result = llm_expand_operator(intent, "A1", schema, _make_column_metadata())
        assert result == []
