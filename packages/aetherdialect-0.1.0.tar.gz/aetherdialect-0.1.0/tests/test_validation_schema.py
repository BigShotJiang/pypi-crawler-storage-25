"""Tests for validation_schema module."""

import pytest

from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    CteOutputColumnMeta,
    FKEdge,
    SchemaGraph,
    TableMetadata,
)
from text2sql.contracts_core import (
    FilterParam,
    HavingParam,
    MulGroup,
    NormalizedExpr,
    OrderByCol,
    SelectCol,
)
from text2sql.validation_schema import (
    _validate_agg_func_valid,
    _validate_filter_col,
    _validate_having_agg,
    _validate_scalar_func_valid,
    extract_agg_col,
    extract_col_from_scalar_wrapper,
    extract_functions_from_term,
    get_col_meta,
    get_col_type,
    is_col_arithmetic_role,
    is_col_numeric,
    validate_date_diff_units,
    validate_filter_ops_per_column,
    validate_filter_value_type_alignment,
    validate_filters_schema,
    validate_group_by_cols_schema,
    validate_having_schema,
    validate_no_between_ops,
    validate_null_filters,
    validate_order_by_cols_schema,
    validate_select_cols_schema,
)


class TestExtractColFromScalarWrapper:
    """Tests for extract_col_from_scalar_wrapper."""

    def test_bare_column(self):
        """Return bare column unchanged."""
        assert extract_col_from_scalar_wrapper("table1.col1") == "table1.col1"

    def test_abs_wrapper(self):
        """Extract column from ABS wrapper."""
        assert extract_col_from_scalar_wrapper("ABS(table1.col1)") == "table1.col1"

    def test_round_wrapper(self):
        """Extract column from ROUND wrapper."""
        assert extract_col_from_scalar_wrapper("ROUND(table1.col1)") == "table1.col1"

    def test_non_scalar_function(self):
        """Return expression unchanged for non-scalar function."""
        assert extract_col_from_scalar_wrapper("COUNT(table1.col1)") == "COUNT(table1.col1)"

    def test_empty_string(self):
        """Return empty string unchanged."""
        assert extract_col_from_scalar_wrapper("") == ""


class TestValidateScalarFuncValid:
    """Tests for validate_scalar_func_valid."""

    def test_valid_scalar(self):
        """No issues for valid scalar function."""
        issues = _validate_scalar_func_valid("round", "test", "select")
        assert len(issues) == 0

    def test_invalid_scalar(self):
        """Error for unknown scalar function."""
        issues = _validate_scalar_func_valid("foobar", "test", "select")
        assert len(issues) == 1
        assert issues[0].severity == "error"

    def test_none_scalar(self):
        """No issues when scalar_func is None."""
        issues = _validate_scalar_func_valid(None, "test", "select")
        assert len(issues) == 0


class TestValidateAggFuncValid:
    """Tests for validate_agg_func_valid."""

    def test_valid_agg(self):
        """No issues for valid aggregation function."""
        issues = _validate_agg_func_valid("count", "test", "select")
        assert len(issues) == 0

    def test_invalid_agg(self):
        """Error for unknown aggregation function."""
        issues = _validate_agg_func_valid("median", "test", "select")
        assert len(issues) == 1
        assert issues[0].severity == "error"

    def test_count_distinct_not_valid_agg(self):
        """count_distinct is not a valid aggregation function name."""
        issues = _validate_agg_func_valid("count_distinct", "test", "select")
        assert len(issues) == 1


class TestExtractAggCol:
    """Tests for extract_agg_col."""

    def test_count_col(self):
        """Extract COUNT aggregation."""
        func, target, has_distinct = extract_agg_col("COUNT(table1.col1)")
        assert func == "count"
        assert target == "table1.col1"
        assert has_distinct is False

    def test_count_distinct(self):
        """Extract COUNT DISTINCT."""
        func, target, has_distinct = extract_agg_col("COUNT(DISTINCT table1.col1)")
        assert func == "count"
        assert target == "table1.col1"
        assert has_distinct is True

    def test_count_star(self):
        """Extract COUNT(*)."""
        func, target, _ = extract_agg_col("COUNT(*)")
        assert func == "count"
        assert target == "*"

    def test_no_agg(self):
        """Return None for bare column."""
        func, target, _ = extract_agg_col("table1.col1")
        assert func is None


class TestExtractFunctionsFromTerm:
    """Tests for extract_functions_from_term."""

    def test_scalar_wrapping_agg(self):
        """Extract scalar and agg from ROUND(SUM(t.a))."""
        scalar, agg = extract_functions_from_term("ROUND(SUM(table1.col1))")
        assert scalar == "round"
        assert agg == "sum"

    def test_bare_agg(self):
        """Extract agg only from COUNT(t.a)."""
        scalar, agg = extract_functions_from_term("COUNT(table1.col1)")
        assert scalar is None
        assert agg == "count"

    def test_no_function(self):
        """Return None for bare column."""
        scalar, agg = extract_functions_from_term("table1.col1")
        assert scalar is None
        assert agg is None

    def test_empty_string(self):
        """Return None for empty string."""
        scalar, agg = extract_functions_from_term("")
        assert scalar is None
        assert agg is None


class TestValidateSelectColsSchema:
    """Tests for validate_select_cols_schema."""

    def test_valid_select(self, simple_schema):
        """No issues for valid qualified column."""
        sc = SelectCol(expr=NormalizedExpr.from_column("customers.name"))
        issues = validate_select_cols_schema([sc], simple_schema, {"customers", "orders"})
        assert len(issues) == 0

    def test_empty_select_cols(self, simple_schema):
        """Error for empty select_cols."""
        issues = validate_select_cols_schema([], simple_schema, {"customers"})
        assert len(issues) == 1
        assert "empty" in issues[0].message

    def test_unqualified_column(self, simple_schema):
        """Error for unqualified column reference."""
        sc = SelectCol(expr=NormalizedExpr.from_column("name"))
        issues = validate_select_cols_schema([sc], simple_schema, {"customers"})
        assert any("qualified" in i.message for i in issues)

    def test_column_not_found(self, simple_schema):
        """Error for column that does not exist in table."""
        sc = SelectCol(expr=NormalizedExpr.from_column("customers.nonexistent"))
        issues = validate_select_cols_schema([sc], simple_schema, {"customers"})
        assert any("not in table" in i.message for i in issues)

    def test_table_not_allowed(self, simple_schema):
        """Error for table not in allowed set."""
        sc = SelectCol(expr=NormalizedExpr.from_column("products.name"))
        issues = validate_select_cols_schema([sc], simple_schema, {"customers"})
        assert any("not in allowed" in i.message for i in issues)


class TestValidateOrderByColsSchema:
    """Tests for validate_order_by_cols_schema."""

    def test_valid_order_by(self, simple_schema):
        """No issues for valid order by column."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("customers.name"), direction="asc")
        issues = validate_order_by_cols_schema([obc], simple_schema, {"customers"})
        assert len(issues) == 0

    def test_invalid_direction(self, simple_schema):
        """Error for invalid direction."""
        obc = OrderByCol(expr=NormalizedExpr.from_column("customers.name"), direction="up")
        issues = validate_order_by_cols_schema([obc], simple_schema, {"customers"})
        assert any("direction" in i.message for i in issues)


class TestValidateGroupByColsSchema:
    """Tests for validate_group_by_cols_schema."""

    def test_valid_group_by(self, simple_schema):
        """No issues for valid group by column."""
        gb = NormalizedExpr.from_column("customers.name")
        issues = validate_group_by_cols_schema([gb], simple_schema, {"customers"})
        assert len(issues) == 0

    def test_column_not_found(self, simple_schema):
        """Error for column not found in schema."""
        gb = NormalizedExpr.from_column("customers.nonexistent")
        issues = validate_group_by_cols_schema([gb], simple_schema, {"customers"})
        assert any("not in table" in i.message for i in issues)


class TestValidateFiltersSchema:
    """Tests for validate_filters_schema."""

    def test_valid_filter(self, simple_schema):
        """No issues for valid filter."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="=",
            value_type="string",
        )
        issues = validate_filters_schema([fp], simple_schema, {"customers"})
        assert len(issues) == 0

    def test_invalid_op(self, simple_schema):
        """Error for invalid filter operator."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="<=>",
            value_type="string",
        )
        issues = validate_filters_schema([fp], simple_schema, {"customers"})
        assert any("Invalid filter operator" in i.message for i in issues)

    def test_empty_filters(self, simple_schema):
        """No issues for empty filter list."""
        issues = validate_filters_schema([], simple_schema, {"customers"})
        assert len(issues) == 0

    def test_valid_bool_op_and(self, simple_schema):
        """No issues for filter with bool_op 'AND'."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="=",
            value_type="string",
            bool_op="AND",
        )
        issues = validate_filters_schema([fp], simple_schema, {"customers"})
        bool_op_issues = [i for i in issues if "bool_op" in i.message]
        assert len(bool_op_issues) == 0

    def test_valid_bool_op_or(self, simple_schema):
        """No issues for filter with bool_op 'OR'."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="=",
            value_type="string",
            bool_op="OR",
        )
        issues = validate_filters_schema([fp], simple_schema, {"customers"})
        bool_op_issues = [i for i in issues if "bool_op" in i.message]
        assert len(bool_op_issues) == 0

    def test_invalid_bool_op_raises_issue(self, simple_schema):
        fp = FilterParam.__new__(FilterParam)
        object.__setattr__(fp, "left_expr", NormalizedExpr.from_column("customers.name"))
        object.__setattr__(fp, "op", "=")
        object.__setattr__(fp, "value", None)
        object.__setattr__(fp, "value_type", "string")
        object.__setattr__(fp, "scalar_func", None)
        object.__setattr__(fp, "bool_op", "XOR")
        object.__setattr__(fp, "filter_group", None)
        issues = validate_filters_schema([fp], simple_schema, {"customers"})
        assert any("bool_op" in i.message for i in issues)


class TestValidateHavingSchema:
    """Tests for validate_having_schema."""

    def test_valid_having(self, simple_schema):
        """No issues for valid having clause."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(customers.id)"])]),
            op=">",
            value_type="integer",
            raw_value=5,
        )
        issues = validate_having_schema([hp], simple_schema, {"customers"})
        assert len(issues) == 0

    def test_valid_having_bool_op_or(self, simple_schema):
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(customers.id)"])]),
            op=">",
            value_type="integer",
            bool_op="OR",
            raw_value=5,
        )
        issues = validate_having_schema([hp], simple_schema, {"customers"})
        bool_op_issues = [i for i in issues if "bool_op" in i.message]
        assert len(bool_op_issues) == 0

    def test_invalid_having_bool_op_raises_issue(self, simple_schema):
        hp = HavingParam.__new__(HavingParam)
        object.__setattr__(
            hp,
            "left_expr",
            NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(customers.id)"])]),
        )
        object.__setattr__(hp, "op", ">")
        object.__setattr__(hp, "value", None)
        object.__setattr__(hp, "value_type", "integer")
        object.__setattr__(hp, "scalar_func", None)
        object.__setattr__(hp, "bool_op", "NAND")
        object.__setattr__(hp, "filter_group", None)
        issues = validate_having_schema([hp], simple_schema, {"customers"})
        assert any("bool_op" in i.message for i in issues)

    def test_having_missing_raw_value_emits_error(self, simple_schema):
        """HavingParam with no raw_value and no right_expr emits
        having_missing_value error."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(customers.id)"])]),
            op=">",
            value_type="integer",
            raw_value=None,
        )
        issues = validate_having_schema([hp], simple_schema, {"customers"})
        missing = [i for i in issues if "missing_value" in i.issue_id]
        assert len(missing) == 1
        assert missing[0].severity == "error"

    def test_having_is_null_no_value_required(self, simple_schema):
        """HavingParam with op='is null' and no raw_value does NOT emit
        a missing-value error."""
        hp = HavingParam(
            left_expr=NormalizedExpr(add_groups=[MulGroup(coefficient=1.0, multiply=["COUNT(customers.id)"])]),
            op="is null",
            value_type="null",
            raw_value=None,
        )
        issues = validate_having_schema([hp], simple_schema, {"customers"})
        missing = [i for i in issues if "missing_value" in i.issue_id]
        assert len(missing) == 0


class TestValidateNullFilters:
    """Tests for validate_null_filters."""

    def test_valid_null_filter(self):
        """No issues for IS NULL with null value_type."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="is null", value_type="null")
        issues = validate_null_filters([fp])
        assert len(issues) == 0

    def test_null_filter_wrong_value_type(self):
        """Error for IS NULL with non-null value_type."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="is null",
            value_type="string",
        )
        issues = validate_null_filters([fp])
        assert len(issues) == 1
        assert "value_type" in issues[0].message

    def test_non_null_filter_no_issue(self):
        """No issues for non-null filter with any value_type."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        issues = validate_null_filters([fp])
        assert len(issues) == 0


class TestValidateFilterOpsPerColumn:
    """Tests for validate_filter_ops_per_column."""

    def test_valid_op_passes(self, simple_schema):
        """validate_filter_ops_per_column no issues for valid op."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.name"),
            op="=",
            value_type="string",
        )
        issues = validate_filter_ops_per_column([fp], simple_schema)
        assert len(issues) == 0

    def test_invalid_op_errors(self, simple_schema):
        """validate_filter_ops_per_column errors for invalid op."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("customers.id"),
            op="like",
            value_type="string",
        )
        issues = validate_filter_ops_per_column([fp], simple_schema)
        error_issues = [i for i in issues if i.severity == "error"]
        assert len(error_issues) >= 1

    def test_empty_filters_no_issues(self, simple_schema):
        """validate_filter_ops_per_column returns empty for no
        filters."""
        assert validate_filter_ops_per_column([], simple_schema) == []


class TestValidateFilterCol:
    """Tests for _validate_filter_col."""

    def test_empty_expr_no_issues(self, simple_schema):
        """No issues for empty column expression."""
        issues = _validate_filter_col("", simple_schema, {"customers"}, {}, "main", "left_col", "pk1")
        assert len(issues) == 0

    def test_unqualified_column(self, simple_schema):
        """Error for unqualified column reference."""
        issues = _validate_filter_col("name", simple_schema, {"customers"}, {}, "main", "left_col", "pk1")
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert "qualified" in issues[0].message

    def test_table_not_allowed(self, simple_schema):
        """Error when table not in allowed set."""
        issues = _validate_filter_col("orders.amount", simple_schema, {"customers"}, {}, "main", "left_col", "pk1")
        assert len(issues) == 1
        assert "not in allowed" in issues[0].message

    def test_table_not_in_schema(self, simple_schema):
        """Error when table not in schema."""
        issues = _validate_filter_col("products.name", simple_schema, {"products"}, {}, "main", "left_col", "pk1")
        assert len(issues) == 1
        assert "not in schema" in issues[0].message

    def test_column_not_found(self, simple_schema):
        """Error when column not found in table."""
        issues = _validate_filter_col(
            "customers.nonexistent",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_col",
            "pk1",
        )
        assert len(issues) == 1
        assert "not in table" in issues[0].message

    def test_valid_column(self, simple_schema):
        """No issues for valid qualified column."""
        issues = _validate_filter_col(
            "customers.name",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_col",
            "pk1",
        )
        assert len(issues) == 0

    def test_cte_column_found(self, simple_schema):
        """No issues for valid CTE column reference."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed")}}
        issues = _validate_filter_col(
            "cte1.total",
            simple_schema,
            {"customers"},
            cte_outputs,
            "main",
            "left_col",
            "pk1",
        )
        assert len(issues) == 0

    def test_cte_column_not_found(self, simple_schema):
        """Error when column not found in CTE outputs."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed")}}
        issues = _validate_filter_col(
            "cte1.missing",
            simple_schema,
            {"customers"},
            cte_outputs,
            "main",
            "left_col",
            "pk1",
        )
        assert len(issues) == 1
        assert "not in CTE" in issues[0].message

    def test_scalar_wrapped_column(self, simple_schema):
        """Validate inner column when wrapped in scalar function."""
        issues = _validate_filter_col(
            "ABS(customers.balance)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_col",
            "pk1",
        )
        assert len(issues) == 0

    def test_right_side_param(self, simple_schema):
        """Side parameter reflected in issue IDs."""
        issues = _validate_filter_col("name", simple_schema, {"customers"}, {}, "main", "right_col", "pk1")
        assert "right_col" in issues[0].issue_id


class TestValidateHavingAgg:
    """Tests for _validate_having_agg."""

    def test_empty_expr_no_issues(self, simple_schema):
        """No issues for empty aggregation expression."""
        issues = _validate_having_agg("", simple_schema, {"customers"}, {}, "main", "left_agg", "pk1")
        assert len(issues) == 0

    def test_bare_column_invalid_format(self, simple_schema):
        """Error for bare column without aggregation."""
        issues = _validate_having_agg(
            "customers.name",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "Invalid aggregation format" in issues[0].message

    def test_invalid_agg_func(self, simple_schema):
        """Error for invalid aggregation function."""
        issues = _validate_having_agg(
            "MEDIAN(customers.balance)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "Invalid aggregation function" in issues[0].message

    def test_distinct_on_non_count(self, simple_schema):
        """Error for DISTINCT with non-COUNT aggregation."""
        issues = _validate_having_agg(
            "SUM(DISTINCT customers.balance)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "DISTINCT only allowed with COUNT" in issues[0].message

    def test_star_on_non_count(self, simple_schema):
        """Error for star with non-COUNT aggregation."""
        issues = _validate_having_agg("SUM(*)", simple_schema, {"customers"}, {}, "main", "left_agg", "pk1")
        assert len(issues) == 1
        assert "'*' only allowed with COUNT" in issues[0].message

    def test_count_star_valid(self, simple_schema):
        """No issues for COUNT(*)."""
        issues = _validate_having_agg("COUNT(*)", simple_schema, {"customers"}, {}, "main", "left_agg", "pk1")
        assert len(issues) == 0

    def test_unqualified_target(self, simple_schema):
        """Error for unqualified aggregation target."""
        issues = _validate_having_agg("SUM(balance)", simple_schema, {"customers"}, {}, "main", "left_agg", "pk1")
        assert len(issues) == 1
        assert "qualified" in issues[0].message

    def test_table_not_allowed(self, simple_schema):
        """Error when target table not in allowed set."""
        issues = _validate_having_agg(
            "SUM(orders.amount)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "not in allowed" in issues[0].message

    def test_column_not_found(self, simple_schema):
        """Error when column not found in table."""
        issues = _validate_having_agg(
            "SUM(customers.nonexistent)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "not in table" in issues[0].message

    def test_type_mismatch(self, simple_schema):
        """Error for SUM on string column."""
        issues = _validate_having_agg(
            "SUM(customers.name)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "Cannot use SUM" in issues[0].message

    def test_valid_sum(self, simple_schema):
        """No issues for SUM on numeric column."""
        issues = _validate_having_agg(
            "SUM(customers.balance)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 0

    def test_count_on_any_type(self, simple_schema):
        """No issues for COUNT on any column type."""
        issues = _validate_having_agg(
            "COUNT(customers.name)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 0

    def test_cte_column_found(self, simple_schema):
        """No issues for valid CTE column in aggregation."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed")}}
        issues = _validate_having_agg(
            "SUM(cte1.total)",
            simple_schema,
            {"customers"},
            cte_outputs,
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 0

    def test_cte_column_not_found(self, simple_schema):
        """Error when CTE column not found."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed")}}
        issues = _validate_having_agg(
            "SUM(cte1.missing)",
            simple_schema,
            {"customers"},
            cte_outputs,
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "not in CTE" in issues[0].message

    def test_count_distinct_valid(self, simple_schema):
        """No issues for COUNT(DISTINCT col)."""
        issues = _validate_having_agg(
            "COUNT(DISTINCT customers.name)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 0


class TestValidateFilterColEdgeCases:
    """Edge-case tests for _validate_filter_col."""

    def test_cte_case_insensitive_match(self, simple_schema):
        """CTE column match is case-insensitive."""
        cte_outputs = {"cte1": {"Total": CteOutputColumnMeta(source="computed")}}
        issues = _validate_filter_col(
            "cte1.total",
            simple_schema,
            {"customers"},
            cte_outputs,
            "main",
            "left_col",
            "pk1",
        )
        assert len(issues) == 0

    def test_dotted_table_name(self, simple_schema):
        """Handles table.column split correctly."""
        issues = _validate_filter_col("customers.id", simple_schema, {"customers"}, {}, "main", "left_col", "pk1")
        assert len(issues) == 0


class TestValidateHavingAggEdgeCases:
    """Edge-case tests for _validate_having_agg."""

    def test_max_on_string_passes(self, simple_schema):
        """No issues for MAX on string column (string allowed for
        max)."""
        issues = _validate_having_agg(
            "MAX(customers.name)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 0

    def test_avg_on_string_errors(self, simple_schema):
        """Error for AVG on string column."""
        issues = _validate_having_agg(
            "AVG(customers.name)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "left_agg",
            "pk1",
        )
        assert len(issues) == 1
        assert "Cannot use AVG" in issues[0].message

    def test_right_side_param(self, simple_schema):
        """Side parameter reflected in issues."""
        issues = _validate_having_agg(
            "MEDIAN(customers.balance)",
            simple_schema,
            {"customers"},
            {},
            "main",
            "right_agg",
            "pk1",
        )
        assert "right_agg" in issues[0].issue_id


class TestValidateFilterValueTypeAlignment:
    @pytest.fixture
    def fk_schema(self):
        orders = TableMetadata(
            name="orders",
            columns={
                "order_id": ColumnMetadata(
                    name="order_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=500,
                ),
                "category_id": ColumnMetadata(
                    name="category_id",
                    data_type="integer",
                    value_type="integer",
                    is_foreign_key=True,
                    fk_target=("categories", "category_id"),
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=10,
                ),
                "status": ColumnMetadata(
                    name="status",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    distinct_count=5,
                ),
            },
            primary_key=["order_id"],
            foreign_keys=[
                FKEdge(
                    src_table="orders",
                    src_cols=["category_id"],
                    dst_table="categories",
                    dst_cols=["category_id"],
                ),
            ],
        )
        categories = TableMetadata(
            name="categories",
            columns={
                "category_id": ColumnMetadata(
                    name="category_id",
                    data_type="integer",
                    value_type="integer",
                    is_primary_key=True,
                    role=ColumnRole.IDENTIFIER.value,
                    distinct_count=10,
                ),
                "name": ColumnMetadata(
                    name="name",
                    data_type="varchar",
                    value_type="string",
                    role=ColumnRole.CATEGORICAL.value,
                    distinct_count=10,
                ),
            },
            primary_key=["category_id"],
            foreign_keys=[],
        )
        return SchemaGraph(
            tables={"orders": orders, "categories": categories},
            join_paths_multi={},
            schema_hash="h",
        )

    def test_string_on_fk_int_warns(self, fk_schema):
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.category_id"),
                op="=",
                value_type="string",
                raw_value="Action",
            ),
        ]
        issues = validate_filter_value_type_alignment(filters, fk_schema)
        assert len(issues) == 1
        assert issues[0].severity == "warning"

    def test_integer_on_fk_int_no_issue(self, fk_schema):
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.category_id"),
                op="=",
                value_type="integer",
                raw_value=5,
            ),
        ]
        issues = validate_filter_value_type_alignment(filters, fk_schema)
        assert issues == []

    def test_string_on_string_col_no_issue(self, fk_schema):
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.status"),
                op="=",
                value_type="string",
                raw_value="shipped",
            ),
        ]
        issues = validate_filter_value_type_alignment(filters, fk_schema)
        assert issues == []

    def test_no_raw_value_no_issue(self, fk_schema):
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.category_id"),
                op="is null",
                value_type="string",
            ),
        ]
        issues = validate_filter_value_type_alignment(filters, fk_schema)
        assert issues == []

    def test_unknown_column_no_issue(self, fk_schema):
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.unknown_col"),
                op="=",
                value_type="string",
                raw_value="test",
            ),
        ]
        issues = validate_filter_value_type_alignment(filters, fk_schema)
        assert issues == []

    def test_enum_on_fk_int_warns(self, fk_schema):
        filters = [
            FilterParam(
                left_expr=NormalizedExpr.from_column("orders.category_id"),
                op="=",
                value_type="enum",
                raw_value="Action",
            ),
        ]
        issues = validate_filter_value_type_alignment(filters, fk_schema)
        assert len(issues) == 1
        assert issues[0].severity == "warning"


class TestValidateNoBetweenOps:
    """Tests for validate_no_between_ops."""

    def test_no_between_no_issues(self):
        """No BETWEEN ops yields empty issue list."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op=">=", value_type="integer")
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            value_type="integer",
        )
        issues = validate_no_between_ops([fp], [hp])
        assert issues == []

    def test_filter_between_flagged(self):
        """BETWEEN on a filter produces an error issue."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="between",
            value_type="integer",
        )
        issues = validate_no_between_ops([fp], [])
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert "filter" in issues[0].issue_id.lower()

    def test_having_between_flagged(self):
        """BETWEEN on a having produces an error issue."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op="between",
            value_type="integer",
        )
        issues = validate_no_between_ops([], [hp])
        assert len(issues) == 1
        assert issues[0].severity == "error"
        assert "having" in issues[0].issue_id.lower()

    def test_both_between_flagged(self):
        """BETWEEN on both filter and having produces two issues."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="between",
            value_type="integer",
        )
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op="between",
            value_type="integer",
        )
        issues = validate_no_between_ops([fp], [hp])
        assert len(issues) == 2

    def test_empty_lists_no_issues(self):
        """Empty filter and having lists yield no issues."""
        issues = validate_no_between_ops([], [])
        assert issues == []

    def test_case_insensitive_between_flagged(self):
        """BETWEEN in any case is flagged."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.a"),
            op="BETWEEN",
            value_type="integer",
        )
        issues = validate_no_between_ops([fp], [])
        assert len(issues) == 1
        assert "between" in issues[0].message.lower()


class TestGetColType:
    """Tests for get_col_type."""

    def test_existing_column(self, typed_schema):
        """Return value_type for existing column."""
        result = get_col_type("customers.balance", typed_schema, {})
        assert result == "number"

    def test_unknown_column(self, typed_schema):
        """Return None for unknown column."""
        result = get_col_type("unknown.col", typed_schema, {})
        assert result is None

    def test_unqualified_column(self, typed_schema):
        """Return None for unqualified column."""
        result = get_col_type("balance", typed_schema, {})
        assert result is None


class TestGetColMeta:
    """Tests for get_col_meta."""

    def test_existing_column(self, typed_schema):
        """Return ColumnMetadata for existing column."""
        result = get_col_meta("customers.balance", typed_schema, {})
        assert result is not None
        assert result.name == "balance"

    def test_unknown_column(self, typed_schema):
        """Return None for unknown column."""
        result = get_col_meta("customers.nonexistent", typed_schema, {})
        assert result is None

    def test_unqualified_column(self, typed_schema):
        """Return None for unqualified column."""
        result = get_col_meta("balance", typed_schema, {})
        assert result is None

    def test_unknown_table(self, typed_schema):
        """Return None for unknown table."""
        result = get_col_meta("unknown.col", typed_schema, {})
        assert result is None

    def test_cte_column(self, typed_schema):
        """Return synthetic ColumnMetadata for CTE column."""
        cte_outputs = {
            "cte1": {
                "total": CteOutputColumnMeta(
                    source="computed",
                    data_type="numeric",
                    role=ColumnRole.NUMERIC_MEASURE.value,
                )
            }
        }
        result = get_col_meta("cte1.total", typed_schema, cte_outputs)
        assert result is not None
        assert result.name == "total"

    def test_cte_column_not_found(self, typed_schema):
        """Return None for CTE column not found."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed")}}
        result = get_col_meta("cte1.missing", typed_schema, cte_outputs)
        assert result is None

    def test_scalar_wrapped_column(self, typed_schema):
        """Return metadata for scalar-wrapped column."""
        result = get_col_meta("ABS(customers.balance)", typed_schema, {})
        assert result is not None
        assert result.name == "balance"


class TestIsColNumeric:
    """Tests for is_col_numeric."""

    def test_numeric_column(self, typed_schema):
        """Return True for numeric column."""
        assert is_col_numeric("customers.balance", typed_schema, {}) is True

    def test_integer_column(self, typed_schema):
        """Return True for integer column."""
        assert is_col_numeric("customers.id", typed_schema, {}) is True

    def test_string_column(self, typed_schema):
        """Return False for string column."""
        assert is_col_numeric("customers.name", typed_schema, {}) is False

    def test_unknown_column(self, typed_schema):
        """Return None for unknown column."""
        assert is_col_numeric("unknown.col", typed_schema, {}) is None

    def test_unqualified_column(self, typed_schema):
        """Return None for unqualified column."""
        assert is_col_numeric("balance", typed_schema, {}) is None


class TestIsColArithmeticRole:
    """Tests for is_col_arithmetic_role."""

    def test_numeric_measure(self, typed_schema):
        """Return True for NUMERIC_MEASURE role."""
        assert is_col_arithmetic_role("customers.balance", typed_schema, {}) is True

    def test_identifier_role(self, typed_schema):
        """Return non-True for IDENTIFIER role."""
        result = is_col_arithmetic_role("customers.id", typed_schema, {})
        assert result is not True

    def test_categorical_role(self, typed_schema):
        """Return non-True for CATEGORICAL role."""
        result = is_col_arithmetic_role("customers.name", typed_schema, {})
        assert result is not True

    def test_unknown_column(self, typed_schema):
        """Return None for unknown column."""
        assert is_col_arithmetic_role("unknown.col", typed_schema, {}) is None

    def test_cte_numeric_role(self, typed_schema):
        """Return True for CTE column with NUMERIC_MEASURE role."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed", role=ColumnRole.NUMERIC_MEASURE.value)}}
        assert is_col_arithmetic_role("cte1.total", typed_schema, cte_outputs) is True


class TestExtractAggColSemantic:
    """Tests for extract_agg_col (validation_semantic version)."""

    def test_count_col(self):
        """Extract COUNT aggregation."""
        func, target, has_distinct = extract_agg_col("COUNT(table1.col1)")
        assert func == "count"
        assert target == "table1.col1"
        assert has_distinct is False

    def test_count_distinct(self):
        """Extract COUNT DISTINCT."""
        func, target, has_distinct = extract_agg_col("COUNT(DISTINCT table1.col1)")
        assert func == "count"
        assert has_distinct is True

    def test_empty_string(self):
        """Return None for empty string."""
        func, target, has_distinct = extract_agg_col("")
        assert func is None

    def test_bare_column(self):
        """Return None for bare column."""
        func, target, has_distinct = extract_agg_col("table1.col1")
        assert func is None


class TestGetColTypeEdgeCases:
    """Edge-case tests for get_col_type."""

    def test_cte_column_found(self, typed_schema):
        """Return value_type from CTE output."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed", data_type="numeric")}}
        result = get_col_type("cte1.total", typed_schema, cte_outputs)
        assert result is not None

    def test_cte_column_not_found(self, typed_schema):
        """Return None when CTE column not found."""
        cte_outputs = {"cte1": {"total": CteOutputColumnMeta(source="computed")}}
        result = get_col_type("cte1.missing", typed_schema, cte_outputs)
        assert result is None

    def test_date_column_type(self, typed_schema):
        """Return date value_type for temporal column."""
        result = get_col_type("customers.created_at", typed_schema, {})
        assert result == "date"

    def test_empty_col_expr_returns_none(self, typed_schema):
        """get_col_type returns None for empty column expression."""
        result = get_col_type("", typed_schema, {})
        assert result is None

    def test_scalar_wrapped_column_resolves(self, typed_schema):
        """get_col_type resolves column wrapped in scalar function."""
        result = get_col_type("ABS(customers.balance)", typed_schema, {})
        assert result == "number"


class TestValidateDateDiffUnits:
    """Tests for validate_date_diff_units."""

    def test_valid_date_diff_no_issues(self):
        """No issues for valid date_diff with day unit and numeric amount."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.col"),
            op=">",
            value_type="date_diff",
            raw_value={"unit": "day", "amount": 7},
        )
        issues = validate_date_diff_units([fp])
        assert len(issues) == 0

    def test_invalid_unit_raises_issue(self):
        """Invalid unit produces an issue."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.col"),
            op=">",
            value_type="date_diff",
            raw_value={"unit": "invalid_unit", "amount": 7},
        )
        issues = validate_date_diff_units([fp])
        assert len(issues) == 1
        assert "invalid unit" in issues[0].message

    def test_non_date_diff_ignored(self):
        """Filters with other value_types are ignored."""
        fp = FilterParam(
            left_expr=NormalizedExpr.from_column("t.col"),
            op="=",
            value_type="string",
            raw_value="x",
        )
        issues = validate_date_diff_units([fp])
        assert len(issues) == 0
