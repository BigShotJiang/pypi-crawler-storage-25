"""Tests for intent_process module."""

from unittest.mock import patch

import pytest

from text2sql.contracts_base import (
    IntentIssue,
    SQLShape,
    TemplateStats,
)
from text2sql.contracts_core import (
    ConcreteIntent,
    FilterParam,
    HavingParam,
    NormalizedExpr,
    OrderByCol,
    RuntimeCteStep,
    RuntimeIntent,
    SelectCol,
    SimulatorIntent,
    Template,
    ValueHistory,
)
from text2sql.intent_process import (
    _base_similarity,
    _build_intent_format_repair_prompt,
    _build_intent_parse_prompt,
    _build_intent_semantic_repair_prompt,
    _classify_schema_error,
    _compute_error_signature_issues,
    _compute_error_signature_strings,
    _compute_filters_similarity,
    _compute_having_similarity,
    _compute_order_by_cols_similarity,
    _compute_select_cols_similarity,
    _cte_step_similarity,
    _detect_oscillation,
    _diff_cols_span_disjoint_tables,
    _jaccard,
    _select_col_diff,
    compute_intent_union,
    intent_approval,
    intent_similarity,
    llm_ux_explain,
    match_template_for_union,
    find_trusted_template_match,
    MAX_NON_AGG_COL_DIFF,
)


class TestJaccard:
    """Tests for _jaccard."""

    def test_identical_sets(self):
        """Jaccard of identical sets is 1.0."""
        assert _jaccard({"a", "b"}, {"a", "b"}) == 1.0

    def test_disjoint_sets(self):
        """Jaccard of disjoint sets is 0.0."""
        assert _jaccard({"a"}, {"b"}) == 0.0

    def test_partial_overlap(self):
        """Jaccard of partial overlap."""
        assert _jaccard({"a", "b"}, {"b", "c"}) == pytest.approx(1 / 3)

    def test_both_empty(self):
        """Jaccard of two empty sets is 1.0."""
        assert _jaccard(set(), set()) == 1.0

    def test_one_empty(self):
        """Jaccard with one empty set is 0.0."""
        assert _jaccard({"a"}, set()) == 0.0


class TestComputeSimilarities:
    """Tests for compute_*_similarity functions."""

    def test_filters_both_empty(self):
        """Both empty filter lists yield 1.0."""
        assert _compute_filters_similarity([], []) == 1.0

    def test_filters_one_empty(self):
        """One empty filter list yields 0.0."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        assert _compute_filters_similarity([fp], []) == 0.0

    def test_having_both_empty(self):
        """Both empty having lists yield 1.0."""
        assert _compute_having_similarity([], []) == 1.0

    def test_select_cols_identical(self):
        """Identical select cols yield 1.0."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        assert _compute_select_cols_similarity([sc], [sc]) == 1.0

    def test_order_by_cols_both_empty(self):
        """Both empty order_by lists yield 1.0."""
        assert _compute_order_by_cols_similarity([], []) == 1.0


class TestIntentSimilarity:
    """Tests for intent_similarity."""

    def test_identical_intents(self):
        """Identical intents yield 1.0."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        intent = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        assert intent_similarity(intent, intent) == pytest.approx(1.0)

    def test_completely_different_intents(self):
        """Completely different intents yield low score."""
        sc1 = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        sc2 = SelectCol(expr=NormalizedExpr.from_column("t2.b"))
        i1 = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[sc1],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        i2 = RuntimeIntent(
            tables=["t2"],
            grain="row_level",
            select_cols=[sc2],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        score = intent_similarity(i1, i2)
        assert score < 1.0


class TestBuildIntentSemanticRepairPrompt:
    """Tests for build_intent_semantic_repair_prompt."""

    def test_returns_string(self):
        """build_intent_semantic_repair_prompt returns a string."""
        issue = IntentIssue(
            issue_id="i1",
            category="tables",
            severity="error",
            message="missing table",
        )
        result = _build_intent_semantic_repair_prompt("test q", '{"tables":[]}', [issue], [], "schema text")
        assert isinstance(result, str)

    def test_contains_question(self):
        """build_intent_semantic_repair_prompt includes question in
        output."""
        issue = IntentIssue(
            issue_id="i1",
            category="tables",
            severity="error",
            message="missing",
        )
        result = _build_intent_semantic_repair_prompt("my question", "{}", [issue], [], "schema")
        assert "my question" in result

    def test_contains_issue_message(self):
        """build_intent_semantic_repair_prompt includes issue
        message."""
        issue = IntentIssue(
            issue_id="i1",
            category="select_cols",
            severity="warning",
            message="bad column",
        )
        result = _build_intent_semantic_repair_prompt("q", "{}", [], [issue], "schema")
        assert "bad column" in result

    def test_multiple_issues(self):
        """build_intent_semantic_repair_prompt handles multiple
        issues."""
        issues = [
            IntentIssue(
                issue_id="i1",
                category="tables",
                severity="error",
                message="issue1",
            ),
            IntentIssue(
                issue_id="i2",
                category="select_cols",
                severity="warning",
                message="issue2",
            ),
        ]
        result = _build_intent_semantic_repair_prompt("q", "{}", [issues[0]], [issues[1]], "schema")
        assert "issue1" in result
        assert "issue2" in result


class TestBuildIntentFormatRepairPrompt:
    """Tests for build_intent_format_repair_prompt."""

    def test_returns_string(self):
        """build_intent_format_repair_prompt returns a string."""
        result = _build_intent_format_repair_prompt("q", "bad json", "expected }")
        assert isinstance(result, str)

    def test_contains_parse_error(self):
        """build_intent_format_repair_prompt includes parse error."""
        result = _build_intent_format_repair_prompt("q", "raw", "missing bracket")
        assert "missing bracket" in result

    def test_includes_full_response(self):
        """build_intent_format_repair_prompt includes full raw response."""
        long_raw = "x" * 5000
        result = _build_intent_format_repair_prompt("q", long_raw, "err")
        assert "x" * 5000 in result


class TestBaseSimilarity:
    """Tests for _base_similarity."""

    def test_identical_fields(self):
        """Identical fields yield 1.0."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        score = _base_similarity(["t"], ["t"], [sc], [sc], [], [], [], [], [], [], [], [])
        assert score == pytest.approx(1.0)

    def test_completely_different(self):
        """Completely different fields yield low score."""
        sc1 = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        sc2 = SelectCol(expr=NormalizedExpr.from_column("t2.b"))
        score = _base_similarity(["t"], ["t2"], [sc1], [sc2], [], [], [], [], [], [], [], [])
        assert score < 1.0

    def test_all_empty(self):
        """All empty fields yield 1.0."""
        score = _base_similarity([], [], [], [], [], [], [], [], [], [], [], [])
        assert score == pytest.approx(1.0)


class TestCteStepSimilarity:
    """Tests for cte_step_similarity."""

    def test_identical_ctes(self):
        """Identical CTE steps yield 1.0."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        assert _cte_step_similarity(cte, cte) == pytest.approx(1.0)

    def test_different_ctes(self):
        """Different CTE steps yield low score."""
        sc1 = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        sc2 = SelectCol(expr=NormalizedExpr.from_column("t2.b"))
        cte1 = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[sc1],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        cte2 = RuntimeCteStep(
            cte_name="cte2",
            tables=["t2"],
            select_cols=[sc2],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        assert _cte_step_similarity(cte1, cte2) < 1.0


class TestIntentSimilarityEdgeCases:
    """Edge-case tests for intent_similarity."""

    def test_with_cte_steps(self):
        """intent_similarity with CTE steps weights properly."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        i1 = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        i2 = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        score = intent_similarity(i1, i2)
        assert score == pytest.approx(1.0)

    def test_mismatched_cte_count(self):
        """intent_similarity with different CTE counts still works."""
        sc = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        cte = RuntimeCteStep(
            cte_name="cte1",
            tables=["t"],
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            output_columns=[],
        )
        i1 = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[cte],
            natural_language="test",
        )
        i2 = RuntimeIntent(
            tables=["t"],
            grain="row_level",
            select_cols=[sc],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
            param_values={},
            cte_steps=[],
            natural_language="test",
        )
        score = intent_similarity(i1, i2)
        assert 0.0 <= score <= 1.0


class TestComputeSimilaritiesEdgeCases:
    """Edge-case tests for compute_*_similarity functions."""

    def test_filters_identical(self):
        """Identical filter lists yield 1.0."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.a"), op="=", value_type="string")
        assert _compute_filters_similarity([fp], [fp]) == 1.0

    def test_having_one_empty(self):
        """One empty having list yields 0.0."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.a"),
            op=">",
            value_type="integer",
        )
        assert _compute_having_similarity([hp], []) == 0.0

    def test_select_cols_different(self):
        """Different select cols yield low score."""
        sc1 = SelectCol(expr=NormalizedExpr.from_column("t.a"))
        sc2 = SelectCol(expr=NormalizedExpr.from_column("t.b"))
        score = _compute_select_cols_similarity([sc1], [sc2])
        assert score < 1.0

    def test_order_by_identical(self):
        """Identical order_by lists yield 1.0."""
        ob = OrderByCol(expr=NormalizedExpr.from_column("t.a"), direction="asc")
        assert _compute_order_by_cols_similarity([ob], [ob]) == 1.0

    def test_order_by_one_empty(self):
        """One empty order_by list yields 0.0."""
        ob = OrderByCol(expr=NormalizedExpr.from_column("t.a"), direction="asc")
        assert _compute_order_by_cols_similarity([ob], []) == 0.0


class TestIntentApproval:
    """Tests for intent_approval."""

    def test_identical_intents_score_one(self):
        """Identical intents produce score near 1.0 with no diffs."""
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        sim_intent = SimulatorIntent(
            intent_id="sim1",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        score, diffs = intent_approval(sim_intent, intent)
        assert score >= 0.9
        assert len(diffs) == 0

    def test_table_mismatch_produces_diff(self):
        """Table mismatch is recorded in diffs."""
        ri = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        si = SimulatorIntent(
            intent_id="sim2",
            tables=["customers"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("customers.customer_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        score, diffs = intent_approval(si, ri)
        assert any("tables" in d for d in diffs)
        assert score < 1.0

    def test_filter_count_mismatch(self):
        """Filter count mismatch is recorded."""
        ri = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[
                FilterParam(
                    left_expr=NormalizedExpr.from_column("orders.status"),
                    op="=",
                    value_type="string",
                )
            ],
        )
        si = SimulatorIntent(
            intent_id="sim3",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        score, diffs = intent_approval(si, ri)
        assert any("filters_count" in d for d in diffs)

    def test_score_between_zero_and_one(self):
        """Score is always in [0, 1]."""
        ri = RuntimeIntent(
            tables=["orders"],
            grain="grouped",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id"))],
            group_by_cols=[NormalizedExpr.from_column("orders.status")],
            order_by_cols=[],
            filters_param=[],
        )
        si = SimulatorIntent(
            intent_id="sim4",
            tables=["customers"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("customers.name"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
            having_param=[],
        )
        score, diffs = intent_approval(si, ri)
        assert 0.0 <= score <= 1.0

    def test_filter_bool_op_mismatch_produces_diff(self):
        """Filter bool_op mismatch is recorded when sigs match."""
        fp_and = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=",
            value_type="string",
            bool_op="AND",
        )
        fp_or = FilterParam(
            left_expr=NormalizedExpr.from_column("orders.status"),
            op="=",
            value_type="string",
            bool_op="OR",
        )
        ri = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp_and],
        )
        si = SimulatorIntent(
            intent_id="sim5",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[fp_or],
            having_param=[],
        )
        score, diffs = intent_approval(si, ri)
        assert any("filters_bool_op" in d for d in diffs)


class TestComputeFiltersSimilarity:
    """Tests for compute_filters_similarity."""

    def test_identical_filters_score_one(self):
        """Identical filter lists produce score 1.0."""
        fp = FilterParam(left_expr=NormalizedExpr.from_column("t.col"), op="=", value_type="string")
        assert _compute_filters_similarity([fp], [fp]) == 1.0

    def test_different_bool_op_penalized(self):
        """Different bool_ops produce score < 1.0 when sigs match."""
        fp1 = FilterParam(
            left_expr=NormalizedExpr.from_column("t.col"),
            op="=",
            value_type="string",
            bool_op="AND",
        )
        fp2 = FilterParam(
            left_expr=NormalizedExpr.from_column("t.col"),
            op="=",
            value_type="string",
            bool_op="OR",
        )
        score = _compute_filters_similarity([fp1], [fp2])
        assert 0 < score < 1.0

    def test_empty_lists_score_one(self):
        """Both empty lists produce score 1.0."""
        assert _compute_filters_similarity([], []) == 1.0


class TestComputeHavingSimilarity:
    """Tests for compute_having_similarity."""

    def test_identical_having_score_one(self):
        """Identical having lists produce score 1.0."""
        hp = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            value_type="integer",
        )
        assert _compute_having_similarity([hp], [hp]) == 1.0

    def test_different_bool_op_penalized(self):
        """Different bool_ops produce score < 1.0 when sigs match."""
        hp1 = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            value_type="integer",
            bool_op="AND",
        )
        hp2 = HavingParam(
            left_expr=NormalizedExpr.from_agg("count", "t.id"),
            op=">",
            value_type="integer",
            bool_op="OR",
        )
        score = _compute_having_similarity([hp1], [hp2])
        assert 0 < score < 1.0

    def test_empty_lists_score_one(self):
        """Both empty lists produce score 1.0."""
        assert _compute_having_similarity([], []) == 1.0


class TestBuildIntentParsePrompt:
    """Tests for _build_intent_parse_prompt."""

    def test_returns_tuple_of_strings(self):
        """Returns (system_message, user_message) tuple."""
        system, user = _build_intent_parse_prompt("how many orders?", "schema text here", ["orders", "customers"])
        assert isinstance(system, str)
        assert isinstance(user, str)

    def test_system_contains_parser_role(self):
        """System message contains parser role description."""
        system, _ = _build_intent_parse_prompt("q", "schema", ["orders"])
        assert "parser" in system.lower() or "json" in system.lower()

    def test_user_contains_table_list(self):
        """User message contains the allowed tables."""
        _, user = _build_intent_parse_prompt("q", "schema", ["orders", "customers"])
        assert "orders" in user
        assert "customers" in user

    def test_user_contains_question(self):
        """User message contains the question (embedded in the JSON task
        payload)."""
        _, user = _build_intent_parse_prompt("total revenue by customer", "schema", ["orders"])
        assert "total revenue" in user or "task" in user.lower()


class TestFindTrustedTemplateMatch:
    """Tests for find_trusted_template_match."""

    def test_empty_templates_returns_none(self):
        """No templates → returns None."""
        assert find_trusted_template_match("question", []) is None

    def test_trust_level_below_2_skipped(self):
        """Templates with trust_level != 2 are not matched."""
        tmpl = Template(
            id="T0001",
            schema_hash="h",
            intent_signature=ConcreteIntent(
                intent_id="t",
                tables=["orders"],
                grain="row_level",
                select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            ),
            intent_key="ik",
            tables_used=["orders"],
            sql_param="SELECT order_id FROM orders",
            sql_display_param="SELECT order_id FROM orders",
            sql_fp="fp",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="cm",
            value_history=ValueHistory(
                param_values=[{}],
                questions=["test question"],
                natural_language=["test"],
            ),
            stats=TemplateStats(accept=5, reject=0),
            trust_level=1,
        )
        assert find_trusted_template_match("test question", [tmpl]) is None

    def test_trust_level_2_exact_match_returns_tuple(self):
        """Trust level 2 with exact fuzzy match returns (None,
        template)."""
        tmpl = Template(
            id="T0001",
            schema_hash="h",
            intent_signature=ConcreteIntent(
                intent_id="t",
                tables=["orders"],
                grain="row_level",
                select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
                group_by_cols=[],
                order_by_cols=[],
                filters_param=[],
            ),
            intent_key="ik",
            tables_used=["orders"],
            sql_param="SELECT order_id FROM orders",
            sql_display_param="SELECT order_id FROM orders",
            sql_fp="fp",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="cm",
            value_history=ValueHistory(
                param_values=[{}],
                questions=["show all orders"],
                natural_language=["show orders"],
            ),
            stats=TemplateStats(accept=10, reject=0),
            trust_level=2,
        )
        result = find_trusted_template_match("show all orders", [tmpl])
        assert result is not None
        assert result[1] is tmpl


class TestLlmUxExplain:
    """Tests for llm_ux_explain."""

    @patch("text2sql.intent_process.llm_chat")
    def test_returns_llm_response_as_explanation(self, mock_llm_chat):
        """llm_ux_explain returns the string returned by llm_chat."""
        mock_llm_chat.return_value = '{"summary": "Count of orders by customer"}'
        intent = RuntimeIntent(
            tables=["orders", "customers"],
            grain="grouped",
            select_cols=[
                SelectCol(expr=NormalizedExpr.from_agg("count", "orders.order_id")),
                SelectCol(expr=NormalizedExpr.from_column("customers.name")),
            ],
            group_by_cols=[NormalizedExpr.from_column("customers.name")],
            order_by_cols=[],
            filters_param=[],
        )
        result = llm_ux_explain(intent, "How many orders per customer?")
        assert result == "Count of orders by customer"
        assert mock_llm_chat.call_count == 1

    @patch("text2sql.intent_process.llm_chat")
    def test_passes_intent_summary_in_user_prompt(self, mock_llm_chat):
        """llm_ux_explain includes tables and columns in the prompt."""
        mock_llm_chat.return_value = '{"summary": "Summary"}'
        intent = RuntimeIntent(
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        llm_ux_explain(intent, "List orders")
        call_args = mock_llm_chat.call_args
        assert call_args is not None
        user_msg = call_args[0][1]
        assert "orders" in user_msg
        assert "orders.id" in user_msg or "id" in user_msg


class TestClassifySchemaError:
    """Tests for _classify_schema_error."""

    def test_unknown_table(self):
        assert _classify_schema_error("Unknown table: payment") == "unknown_table"

    def test_unknown_column(self):
        assert _classify_schema_error("Unknown select column: film.revenue") == "unknown_column"

    def test_fallback(self):
        assert _classify_schema_error("Some other error") == "schema_validation"

    def test_unknown_table_case_insensitive(self):
        assert _classify_schema_error("UNKNOWN TABLE: foo") == "unknown_table"

    def test_unknown_column_varied_phrasing(self):
        assert _classify_schema_error("Unknown filter column: x.y") == "unknown_column"


class TestComputeErrorSignatureIssues:
    """Tests for _compute_error_signature_issues."""

    def test_empty(self):
        assert _compute_error_signature_issues([]) == frozenset()

    def test_deterministic(self):
        issues = [
            IntentIssue(issue_id="a", category="c1", severity="error", message="m1"),
            IntentIssue(issue_id="b", category="c2", severity="error", message="m2"),
        ]
        sig = _compute_error_signature_issues(issues)
        assert sig == frozenset({("c1", "m1"), ("c2", "m2")})

    def test_ignores_issue_id(self):
        i1 = [IntentIssue(issue_id="x", category="c", severity="error", message="m")]
        i2 = [IntentIssue(issue_id="y", category="c", severity="error", message="m")]
        assert _compute_error_signature_issues(i1) == _compute_error_signature_issues(i2)


class TestComputeErrorSignatureStrings:
    """Tests for _compute_error_signature_strings."""

    def test_empty(self):
        assert _compute_error_signature_strings([]) == frozenset()

    def test_basic(self):
        sig = _compute_error_signature_strings(["err1", "err2"])
        assert sig == frozenset({"err1", "err2"})


class TestDetectOscillation:
    """Tests for _detect_oscillation."""

    def test_too_short(self):
        assert _detect_oscillation([frozenset({"a"})]) is False

    def test_aa_pattern(self):
        s = frozenset({"err1"})
        assert _detect_oscillation([s, s]) is True

    def test_abab_pattern(self):
        a = frozenset({"err1"})
        b = frozenset({"err2"})
        assert _detect_oscillation([a, b, a, b]) is True

    def test_no_oscillation(self):
        a = frozenset({"err1"})
        b = frozenset({"err2"})
        c = frozenset({"err3"})
        assert _detect_oscillation([a, b, c]) is False

    def test_ab_not_oscillation(self):
        a = frozenset({"err1"})
        b = frozenset({"err2"})
        assert _detect_oscillation([a, b]) is False

    def test_aab_not_aa_at_end(self):
        a = frozenset({"err1"})
        b = frozenset({"err2"})
        assert _detect_oscillation([a, a, b]) is False


class TestSemanticRepairPromptCriticalRules:
    """Tests for critical_rules in semantic repair prompt."""

    def test_contains_critical_rules(self):
        issue = IntentIssue(
            issue_id="i1",
            category="tables",
            severity="error",
            message="missing table",
        )
        result = _build_intent_semantic_repair_prompt("test q", '{"tables":[]}', [issue], [], "schema text")
        assert "critical_rules" in result
        assert "HAVING" in result
        assert "SUM and AVG" in result


def _col(table: str, column: str) -> SelectCol:
    """Build a bare non-aggregated SelectCol."""
    return SelectCol(expr=NormalizedExpr.from_column(f"{table}.{column}"))


def _agg_col(agg: str, table: str, column: str) -> SelectCol:
    """Build an aggregated SelectCol."""
    return SelectCol(expr=NormalizedExpr.from_agg(agg, f"{table}.{column}"))


def _runtime(
    tables: list[str],
    cols: list[SelectCol],
) -> RuntimeIntent:
    """Build a minimal RuntimeIntent for union matching tests."""
    return RuntimeIntent(
        tables=tables,
        grain="row_level",
        select_cols=cols,
        group_by_cols=[],
        order_by_cols=[],
        filters_param=[],
    )


def _concrete(
    tables: list[str],
    cols: list[SelectCol],
) -> ConcreteIntent:
    """Build a minimal ConcreteIntent for union matching tests."""
    return ConcreteIntent(
        intent_id="",
        tables=tables,
        grain="row_level",
        select_cols=cols,
        group_by_cols=[],
        order_by_cols=[],
        filters_param=[],
    )


class TestMaxNonAggColDiff:
    """Tests for MAX_NON_AGG_COL_DIFF constant."""

    def test_value_is_two(self):
        """Threshold for non-aggregate column diff is 2."""
        assert MAX_NON_AGG_COL_DIFF == 2


class TestDiffColsSpanDisjointTables:
    """Tests for _diff_cols_span_disjoint_tables."""

    def test_no_diff_returns_false(self):
        """Identical column sets never span disjoint tables."""
        cols = [_col("customer", "first_name")]
        assert not _diff_cols_span_disjoint_tables(
            cols, cols, ["customer"], ["customer"],
        )

    def test_diff_from_shared_table_returns_false(self):
        """Extra column from a table both intents share is allowed."""
        intent_cols = [_col("customer", "first_name")]
        concrete_cols = [
            _col("customer", "first_name"),
            _col("customer", "email"),
        ]
        assert not _diff_cols_span_disjoint_tables(
            intent_cols, concrete_cols, ["customer"], ["customer"],
        )

    def test_template_col_from_foreign_table_returns_true(self):
        """Column in template from table not in intent is rejected."""
        intent_cols = [_col("customer", "first_name")]
        concrete_cols = [
            _col("customer", "first_name"),
            _col("rental", "rental_date"),
        ]
        assert _diff_cols_span_disjoint_tables(
            intent_cols,
            concrete_cols,
            ["customer"],
            ["customer", "rental"],
        )

    def test_intent_col_from_foreign_table_returns_true(self):
        """Column in intent from table not in template is rejected."""
        intent_cols = [
            _col("customer", "first_name"),
            _col("payment", "amount"),
        ]
        concrete_cols = [_col("customer", "first_name")]
        assert _diff_cols_span_disjoint_tables(
            intent_cols,
            concrete_cols,
            ["customer", "payment"],
            ["customer"],
        )

    def test_bidirectional_both_foreign_returns_true(self):
        """Diff columns from disjoint tables on both sides."""
        intent_cols = [
            _col("customer", "first_name"),
            _col("payment", "amount"),
        ]
        concrete_cols = [
            _col("customer", "first_name"),
            _col("rental", "rental_date"),
        ]
        assert _diff_cols_span_disjoint_tables(
            intent_cols,
            concrete_cols,
            ["customer", "payment"],
            ["customer", "rental"],
        )

    def test_empty_cols_returns_false(self):
        """Empty column lists produce no diff."""
        assert not _diff_cols_span_disjoint_tables([], [], [], [])

    def test_agg_cols_ignored(self):
        """Aggregated columns are excluded from the diff check."""
        intent_cols = [_col("customer", "first_name")]
        concrete_cols = [
            _col("customer", "first_name"),
            _agg_col("count", "rental", "rental_id"),
        ]
        assert not _diff_cols_span_disjoint_tables(
            intent_cols, concrete_cols, ["customer"], ["customer", "rental"],
        )


class TestSelectColDiff:
    """Tests for _select_col_diff."""

    def test_identical_cols(self):
        """Matching columns produce zero diff."""
        cols = [_col("t", "a"), _agg_col("sum", "t", "b")]
        agg_match, diff = _select_col_diff(cols, cols)
        assert agg_match
        assert diff == 0

    def test_non_agg_diff(self):
        """Non-aggregate symmetric difference counted correctly."""
        i_cols = [_col("t", "a")]
        c_cols = [_col("t", "a"), _col("t", "b"), _col("t", "c")]
        agg_match, diff = _select_col_diff(i_cols, c_cols)
        assert agg_match
        assert diff == 2

    def test_agg_mismatch(self):
        """Aggregation function mismatch flagged."""
        i_cols = [_agg_col("sum", "t", "a")]
        c_cols = [_agg_col("avg", "t", "a")]
        agg_match, _ = _select_col_diff(i_cols, c_cols)
        assert not agg_match

    def test_exceeds_max_threshold(self):
        """Diff of 3 exceeds the new threshold of 2."""
        i_cols = [_col("t", "a")]
        c_cols = [_col("t", "a"), _col("t", "b"), _col("t", "c"), _col("t", "d")]
        _, diff = _select_col_diff(i_cols, c_cols)
        assert diff > MAX_NON_AGG_COL_DIFF


class TestComputeIntentUnion:
    """Tests for compute_intent_union."""

    def test_identical_cols_no_change(self):
        """Same columns produce cols_changed=False."""
        cols = [_col("t", "a"), _col("t", "b")]
        intent = _runtime(["t"], list(cols))
        concrete = _concrete(["t"], list(cols))
        union_cols, cols_changed = compute_intent_union(intent, concrete)
        assert not cols_changed
        assert len(union_cols) == 2

    def test_new_col_detected(self):
        """Extra column in intent produces cols_changed=True."""
        intent = _runtime(
            ["t"],
            [_col("t", "a"), _col("t", "b"), _col("t", "c")],
        )
        concrete = _concrete(
            ["t"],
            [_col("t", "a"), _col("t", "b")],
        )
        union_cols, cols_changed = compute_intent_union(intent, concrete)
        assert cols_changed
        assert len(union_cols) == 3

    def test_concrete_order_preserved(self):
        """Concrete columns appear first in union."""
        intent = _runtime(["t"], [_col("t", "c")])
        concrete = _concrete(
            ["t"],
            [_col("t", "a"), _col("t", "b")],
        )
        union_cols, _ = compute_intent_union(intent, concrete)
        keys = [sc.signature_key for sc in union_cols]
        c_key = _col("t", "c").signature_key
        assert keys[-1] == c_key

    def test_returns_two_tuple(self):
        """Return type is (list, bool) with no table information."""
        intent = _runtime(["t"], [])
        concrete = _concrete(["t"], [])
        result = compute_intent_union(intent, concrete)
        assert isinstance(result, tuple)
        assert len(result) == 2


class TestMatchTemplateForUnion:
    """Tests for match_template_for_union end-to-end."""

    @staticmethod
    def _make_template(
        tid: str,
        cols: list[SelectCol],
        tables: list[str],
        trust: int = 1,
    ) -> Template:
        """Build a minimal template for matching tests."""
        sig = _concrete(tables, cols)
        sig.chosen_join_candidate_id = "J00"
        sig.chosen_join_path_signature = []
        return Template(
            id=tid,
            schema_hash="h",
            intent_signature=sig,
            intent_key="k",
            tables_used=tables,
            sql_param="SELECT 1",
            sql_display_param="SELECT 1",
            sql_fp="fp",
            shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
            colmap_sig="",
            value_history=ValueHistory(
                param_values=[], questions=[], natural_language=[],
            ),
            stats=TemplateStats(),
            trust_level=trust,
        )

    def test_same_table_extra_col_matches(self):
        """Extra column from shared table allows union match."""
        intent = _runtime(
            ["customer"],
            [_col("customer", "first_name")],
        )
        tmpl = self._make_template(
            "T0001",
            [_col("customer", "first_name"), _col("customer", "email")],
            ["customer"],
        )
        result = match_template_for_union(intent, {"T0001": tmpl})
        assert result is not None
        matched, union_cols, cols_changed = result
        assert matched.id == "T0001"
        assert not cols_changed

    def test_foreign_table_col_rejected(self):
        """Extra column from foreign table prevents match."""
        intent = _runtime(
            ["customer"],
            [_col("customer", "first_name")],
        )
        tmpl = self._make_template(
            "T0001",
            [_col("customer", "first_name"), _col("rental", "rental_date")],
            ["customer", "rental"],
        )
        result = match_template_for_union(intent, {"T0001": tmpl})
        assert result is None

    def test_low_trust_skipped(self):
        """Templates with trust_level < 1 are ignored."""
        intent = _runtime(["t"], [_col("t", "a")])
        tmpl = self._make_template("T0001", [_col("t", "a")], ["t"], trust=0)
        result = match_template_for_union(intent, {"T0001": tmpl})
        assert result is None

    def test_agg_mismatch_rejected(self):
        """Mismatched aggregation prevents union match."""
        intent = _runtime(["t"], [_agg_col("sum", "t", "a")])
        tmpl = self._make_template(
            "T0001", [_agg_col("avg", "t", "a")], ["t"],
        )
        result = match_template_for_union(intent, {"T0001": tmpl})
        assert result is None

    def test_exceeds_diff_threshold_rejected(self):
        """Diff of 3 exceeds threshold of 2 and prevents match."""
        intent = _runtime(["t"], [_col("t", "a")])
        tmpl = self._make_template(
            "T0001",
            [_col("t", "a"), _col("t", "b"), _col("t", "c"), _col("t", "d")],
            ["t"],
        )
        result = match_template_for_union(intent, {"T0001": tmpl})
        assert result is None

    def test_returns_three_tuple(self):
        """Successful match returns (template, cols, cols_changed)."""
        intent = _runtime(["t"], [_col("t", "a")])
        tmpl = self._make_template("T0001", [_col("t", "a")], ["t"])
        result = match_template_for_union(intent, {"T0001": tmpl})
        assert result is not None
        assert len(result) == 3

    def test_best_match_smallest_diff(self):
        """Among multiple candidates, smallest diff wins."""
        intent = _runtime(["t"], [_col("t", "a")])
        tmpl_far = self._make_template(
            "T0001",
            [_col("t", "a"), _col("t", "b"), _col("t", "c")],
            ["t"],
        )
        tmpl_close = self._make_template(
            "T0002",
            [_col("t", "a"), _col("t", "b")],
            ["t"],
        )
        result = match_template_for_union(
            intent, {"T0001": tmpl_far, "T0002": tmpl_close},
        )
        assert result is not None
        assert result[0].id == "T0002"
