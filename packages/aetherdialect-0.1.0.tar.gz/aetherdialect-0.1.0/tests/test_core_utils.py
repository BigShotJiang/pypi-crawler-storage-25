"""Tests for core_utils module: hashing, SQL normalization, question normalization."""

from decimal import Decimal
from unittest.mock import patch

from text2sql.core_utils import (
    _extract_first_json_object,
    _format_cell,
    _strip_fences,
    canonicalize_sql,
    colmap_signature,
    debug,
    explain_db_error_nl,
    intent_id,
    is_repair_oscillating,
    issue_sig,
    join_sig_string,
    log,
    normalize_op,
    normalize_question,
    normalize_sql,
    parameter_abstract,
    print_info,
    print_query_result,
    safe_json_loads,
    schema_hash_fp,
    sha256,
    sql_fp,
    stable_json,
    substitute_params,
)


class TestSha256:
    """Tests for sha256."""

    def test_deterministic(self):
        """Sha256 is deterministic."""
        assert sha256("hello") == sha256("hello")

    def test_different_input_different_hash(self):
        """Sha256 differs for different input."""
        assert sha256("hello") != sha256("world")

    def test_returns_64_hex_chars(self):
        """Sha256 returns 64-char hex string."""
        h = sha256("test")
        assert len(h) == 64
        assert all(c in "0123456789abcdef" for c in h)


class TestStableJson:
    """Tests for stable_json."""

    def test_sorted_keys(self):
        """stable_json sorts keys."""
        result = stable_json({"b": 1, "a": 2})
        assert result.index('"a"') < result.index('"b"')

    def test_no_spaces(self):
        """stable_json uses compact separators."""
        result = stable_json({"a": 1})
        assert " " not in result

    def test_deterministic(self):
        """stable_json is deterministic."""
        d = {"z": 3, "a": 1, "m": 2}
        assert stable_json(d) == stable_json(d)


class TestStripFences:
    """Tests for strip_fences."""

    def test_removes_code_fences(self):
        """strip_fences removes markdown code fences."""
        assert _strip_fences("```sql\nSELECT 1\n```") == "SELECT 1"

    def test_no_fences(self):
        """strip_fences leaves plain text unchanged."""
        assert _strip_fences("SELECT 1") == "SELECT 1"

    def test_strips_whitespace(self):
        """strip_fences strips surrounding whitespace."""
        assert _strip_fences("  SELECT 1  ") == "SELECT 1"


class TestNormalizeOp:
    """Tests for normalize_op."""

    def test_double_equals(self):
        """normalize_op maps == to =."""
        assert normalize_op("==") == "="

    def test_diamond(self):
        """normalize_op maps <> to !=."""
        assert normalize_op("<>") == "!="

    def test_ne(self):
        """normalize_op maps ne to !=."""
        assert normalize_op("ne") == "!="

    def test_gte(self):
        """normalize_op maps gte to >=."""
        assert normalize_op("gte") == ">="

    def test_lte(self):
        """normalize_op maps lte to <=."""
        assert normalize_op("lte") == "<="

    def test_eq(self):
        """normalize_op maps eq to =."""
        assert normalize_op("eq") == "="

    def test_gt(self):
        """normalize_op maps gt to >."""
        assert normalize_op("gt") == ">"

    def test_lt(self):
        """normalize_op maps lt to <."""
        assert normalize_op("lt") == "<"

    def test_ge(self):
        """normalize_op maps ge to >=."""
        assert normalize_op("ge") == ">="

    def test_le(self):
        """normalize_op maps le to <=."""
        assert normalize_op("le") == "<="

    def test_passthrough(self):
        """normalize_op passes through valid ops unchanged."""
        assert normalize_op("like") == "like"
        assert normalize_op("in") == "in"
        assert normalize_op("between") == "between"

    def test_case_insensitive(self):
        """normalize_op is case-insensitive."""
        assert normalize_op("NE") == "!="
        assert normalize_op("GTE") == ">="

    def test_whitespace_stripped(self):
        """normalize_op strips surrounding whitespace before lookup."""
        assert normalize_op("  ==  ") == "="

    def test_empty_string_returns_empty(self):
        """normalize_op returns empty string for empty input."""
        assert normalize_op("") == ""


class TestCanonicalizeSql:
    """Tests for canonicalize_sql."""

    def test_normalizes_whitespace(self):
        """canonicalize_sql collapses whitespace."""
        assert "  " not in canonicalize_sql("SELECT  *   FROM   t")

    def test_removes_trailing_semicolon(self):
        """canonicalize_sql removes trailing semicolon."""
        assert canonicalize_sql("SELECT 1;").endswith("1")

    def test_normalizes_equality_order(self):
        """canonicalize_sql normalizes equality operands
        alphabetically."""
        result = canonicalize_sql("SELECT * FROM t WHERE z.col = a.col")
        assert result.index("a.col") < result.index("z.col")

    def test_equality_order_preserved_when_left_less_than_right(self):
        """canonicalize_sql leaves operand order when left < right."""
        result = canonicalize_sql("SELECT * FROM t WHERE a.col = z.col")
        assert "a.col = z.col" in result

    def test_strips_code_fences(self):
        """canonicalize_sql handles code-fenced SQL."""
        result = canonicalize_sql("```sql\nSELECT 1\n```")
        assert result == "SELECT 1"


class TestNormalizeQuestion:
    """Tests for normalize_question."""

    def test_lowercases(self):
        """normalize_question lowercases unquoted text."""
        result = normalize_question("SHOW ALL Orders")
        assert "show" in result
        assert "orders" in result

    def test_preserves_quoted_case(self):
        """normalize_question preserves case inside quotes."""
        result = normalize_question("find orders with status 'Shipped'")
        assert "'Shipped'" in result

    def test_normalizes_smart_quotes(self):
        """normalize_question converts smart quotes to plain quotes."""
        result = normalize_question("status is \u2018Active\u2019")
        assert "'Active'" in result

    def test_removes_special_chars(self):
        """normalize_question removes non-alphanum special chars."""
        result = normalize_question("total $$ amount!!")
        assert "$" not in result
        assert "!" not in result


class TestColmapSignature:
    """Tests for colmap_signature."""

    def test_deterministic(self):
        """colmap_signature is deterministic."""
        cm = {"name": "customers", "amount": "orders"}
        assert colmap_signature(cm) == colmap_signature(cm)

    def test_different_maps_different_sig(self):
        """colmap_signature differs for different maps."""
        assert colmap_signature({"a": "t1"}) != colmap_signature({"b": "t2"})


class TestIntentId:
    """Tests for intent_id."""

    def test_returns_16_chars(self):
        """intent_id returns 16-character string."""
        result = intent_id({"tables": ["t"], "grain": "row_level"})
        assert len(result) == 16

    def test_deterministic(self):
        """intent_id is deterministic."""
        d = {"a": 1, "b": 2}
        assert intent_id(d) == intent_id(d)


class TestIssueSig:
    """Tests for issue_sig."""

    def test_deterministic(self):
        """issue_sig is deterministic."""
        ids = ["rule_a", "rule_b"]
        assert issue_sig(ids) == issue_sig(ids)

    def test_order_independent(self):
        """issue_sig is order-independent."""
        assert issue_sig(["a", "b"]) == issue_sig(["b", "a"])


class TestSchemaHashFp:
    """Tests for schema_hash_fp."""

    def test_deterministic(self):
        """schema_hash_fp is deterministic."""
        tables = {"t1": {"columns": ["a", "b"]}}
        assert schema_hash_fp(tables) == schema_hash_fp(tables)

    def test_different_tables_different_hash(self):
        """schema_hash_fp differs for different tables."""
        assert schema_hash_fp({"t1": {}}) != schema_hash_fp({"t2": {}})


class TestExtractFirstJsonObject:
    """Tests for extract_first_json_object."""

    def test_extracts_embedded_json(self):
        """extract_first_json_object extracts JSON from surrounding
        text."""
        result = _extract_first_json_object('Here is the answer: {"key": "value"} done.')
        assert result == '{"key": "value"}'

    def test_returns_none_for_no_json(self):
        """extract_first_json_object returns None when no braces
        found."""
        assert _extract_first_json_object("no json here") is None

    def test_handles_nested_braces(self):
        """extract_first_json_object handles nested objects."""
        result = _extract_first_json_object('{"a": {"b": 1}}')
        assert result == '{"a": {"b": 1}}'

    def test_handles_code_fences(self):
        """extract_first_json_object strips code fences first."""
        result = _extract_first_json_object('```json\n{"x": 1}\n```')
        assert result == '{"x": 1}'

    def test_returns_none_for_unclosed_brace(self):
        """extract_first_json_object returns None for unclosed brace."""
        assert _extract_first_json_object('{"key": "value"') is None


class TestSafeJsonLoads:
    """Tests for safe_json_loads."""

    def test_parses_valid_json(self):
        """safe_json_loads parses valid JSON directly."""
        result = safe_json_loads('{"a": 1}')
        assert result == {"a": 1}

    def test_parses_embedded_json(self):
        """safe_json_loads falls back to fragment extraction."""
        result = safe_json_loads('Some text {"a": 1} more text')
        assert result == {"a": 1}

    def test_returns_none_for_garbage(self):
        """safe_json_loads returns None for unparseable input."""
        assert safe_json_loads("not json at all") is None

    def test_handles_whitespace(self):
        """safe_json_loads strips whitespace."""
        result = safe_json_loads('  {"b": 2}  ')
        assert result == {"b": 2}


class TestParameterAbstract:
    """Tests for parameter_abstract."""

    def test_replaces_string_literal(self):
        """parameter_abstract replaces quoted strings."""
        sql, params = parameter_abstract("SELECT * FROM t WHERE name = 'Alice'")
        assert ":p" in sql
        assert "'Alice'" in params.values()

    def test_replaces_numeric_literal(self):
        """parameter_abstract replaces numeric values."""
        sql, params = parameter_abstract("SELECT * FROM t WHERE id = 42")
        assert ":p" in sql
        assert "42" in params.values()

    def test_replaces_date_literal(self):
        """parameter_abstract replaces ISO date values."""
        sql, params = parameter_abstract("SELECT * FROM t WHERE dt = 2024-01-15")
        assert "2024-01-15" in params.values()

    def test_returns_dict_of_params(self):
        """parameter_abstract returns dict with p1, p2, etc. keys."""
        _, params = parameter_abstract("WHERE a = 1 AND b = 'x'")
        assert all(k.startswith("p") for k in params)


class TestSubstituteParams:
    """Tests for substitute_params."""

    def test_substitutes_string(self):
        """substitute_params replaces string placeholders."""
        result = substitute_params("WHERE name = :p1", {"p1": "Alice"})
        assert "'Alice'" in result

    def test_substitutes_number(self):
        """substitute_params replaces numeric placeholders."""
        result = substitute_params("WHERE id = :p1", {"p1": 42})
        assert "42" in result

    def test_substitutes_list(self):
        """substitute_params replaces list placeholders."""
        result = substitute_params("WHERE id IN (:p1)", {"p1": [1, 2, 3]})
        assert "1, 2, 3" in result

    def test_substitutes_boolean(self):
        """substitute_params replaces boolean placeholders."""
        result = substitute_params("WHERE active = :p1", {"p1": True})
        assert "TRUE" in result

    def test_strips_trivial_coefficient(self):
        """substitute_params removes 1 * prefix."""
        result = substitute_params("SELECT 1 * col FROM t", {})
        assert "1 *" not in result

    def test_strips_trivial_offset(self):
        """substitute_params removes + 0 suffix."""
        result = substitute_params("SELECT col + 0 FROM t", {})
        assert "+ 0" not in result

    def test_strips_limit_none(self):
        """substitute_params removes LIMIT None."""
        result = substitute_params("SELECT * FROM t LIMIT None", {})
        assert "LIMIT" not in result

    def test_substitutes_quoted_string_in_list(self):
        """substitute_params directly substitutes pre-formatted quoted
        IN-lists."""
        result = substitute_params("WHERE x IN (:p1)", {"p1": "'R','PG-13'"})
        assert "'R','PG-13'" in result

    def test_substitutes_numeric_in_list_string(self):
        """substitute_params directly substitutes numeric comma-
        separated strings."""
        result = substitute_params("WHERE id IN (:p1)", {"p1": "1, 2, 3"})
        assert "1, 2, 3" in result
        assert "'" not in result

    def test_substitutes_float_in_list_string(self):
        """substitute_params directly substitutes float comma-separated
        strings."""
        result = substitute_params("WHERE price IN (:p1)", {"p1": "9.99, 19.99"})
        assert "9.99, 19.99" in result
        assert "'" not in result

    def test_non_numeric_string_gets_quoted(self):
        """substitute_params quotes a plain string that is not a numeric
        list."""
        result = substitute_params("WHERE name = :p1", {"p1": "Alice"})
        assert "'Alice'" in result


class TestSqlFp:
    """Tests for sql_fp."""

    def test_deterministic(self):
        """sql_fp is deterministic."""
        assert sql_fp("SELECT 1") == sql_fp("SELECT 1")

    def test_case_insensitive(self):
        """sql_fp is case-insensitive."""
        assert sql_fp("SELECT 1") == sql_fp("select 1")

    def test_returns_64_hex(self):
        """sql_fp returns 64-char hex string."""
        result = sql_fp("SELECT 1")
        assert len(result) == 64


class TestJoinSigString:
    """Tests for join_sig_string."""

    def test_joins_with_pipe(self):
        """join_sig_string joins elements with pipe."""
        assert join_sig_string(["a->b", "b->c"]) == "a->b|b->c"

    def test_empty_list(self):
        """join_sig_string returns empty string for empty list."""
        assert join_sig_string([]) == ""

    def test_single_element(self):
        """join_sig_string returns element for single-item list."""
        assert join_sig_string(["a->b"]) == "a->b"


class TestExplainDbErrorNl:
    """Tests for explain_db_error_nl."""

    def test_syntax_error(self):
        """explain_db_error_nl recognizes syntax error."""
        result = explain_db_error_nl("ERROR: syntax error at or near 'FROM'")
        assert "syntax" in result.lower()

    def test_column_not_exist(self):
        """explain_db_error_nl recognizes missing column."""
        result = explain_db_error_nl("ERROR: column 'foo' does not exist")
        assert "column" in result.lower()

    def test_relation_not_exist(self):
        """explain_db_error_nl recognizes missing relation."""
        result = explain_db_error_nl("ERROR: relation 'bar' does not exist")
        assert "table" in result.lower()

    def test_ambiguous_column(self):
        """explain_db_error_nl recognizes ambiguous column."""
        result = explain_db_error_nl("ERROR: column 'id' is ambiguous")
        assert "ambiguous" in result.lower()

    def test_division_by_zero(self):
        """explain_db_error_nl recognizes division by zero."""
        result = explain_db_error_nl("ERROR: division by zero")
        assert "division" in result.lower()

    def test_permission_denied(self):
        """explain_db_error_nl recognizes permission error."""
        result = explain_db_error_nl("ERROR: permission denied for table t")
        assert "permission" in result.lower()

    def test_fallback_message(self):
        """explain_db_error_nl returns generic message for unknown
        error."""
        result = explain_db_error_nl("something weird happened")
        assert "structural correction" in result

    def test_empty_input(self):
        """explain_db_error_nl handles empty input."""
        result = explain_db_error_nl("")
        assert len(result) > 0

    def test_none_input(self):
        """explain_db_error_nl handles None input."""
        result = explain_db_error_nl(None)
        assert len(result) > 0


class TestFormatCell:
    """Tests for _format_cell."""

    def test_none_returns_null(self):
        """_format_cell returns NULL for None."""
        assert _format_cell(None) == "NULL"

    def test_string_passthrough(self):
        """_format_cell returns string unchanged."""
        assert _format_cell("hello") == "hello"

    def test_integer_to_string(self):
        """_format_cell converts integer to string."""
        assert _format_cell(42) == "42"

    def test_decimal_integral(self):
        """_format_cell formats integral Decimal."""
        assert _format_cell(Decimal("5")) == "5"

    def test_decimal_fractional(self):
        """_format_cell formats fractional Decimal."""
        result = _format_cell(Decimal("3.14"))
        assert "3.14" in result


class TestLog:
    """Tests for log."""

    def test_prints_when_verbose(self, capsys):
        """Log prints when VERBOSE is True."""
        with patch("text2sql.core_utils.PolicyConfig") as mock_cfg:
            mock_cfg.VERBOSE = True
            log("hello")
        out = capsys.readouterr().out
        assert "[LOG] hello" in out

    def test_silent_when_not_verbose(self, capsys):
        """Log is silent when VERBOSE is False."""
        with patch("text2sql.core_utils.PolicyConfig") as mock_cfg:
            mock_cfg.VERBOSE = False
            log("hello")
        out = capsys.readouterr().out
        assert out == ""


class TestDebug:
    """Tests for debug."""

    def test_prints_when_debug(self, capsys):
        """Debug prints when DEBUG is True."""
        with patch("text2sql.core_utils.EngineConfig") as mock_cfg:
            mock_cfg.DEBUG = True
            debug("msg")
        out = capsys.readouterr().out
        assert "[DEBUG] msg" in out

    def test_silent_when_not_debug(self, capsys):
        """Debug is silent when DEBUG is False."""
        with patch("text2sql.core_utils.PolicyConfig") as mock_cfg:
            mock_cfg.DEBUG = False
            debug("msg")
        out = capsys.readouterr().out
        assert out == ""


class TestNormalizeSql:
    """Tests for normalize_sql."""

    def test_adds_asc_to_bare_order_by(self):
        """normalize_sql appends ASC to bare ORDER BY columns."""
        result = normalize_sql("SELECT * FROM t ORDER BY name")
        assert "name ASC" in result

    def test_preserves_explicit_desc(self):
        """normalize_sql keeps explicit DESC."""
        result = normalize_sql("SELECT * FROM t ORDER BY name DESC")
        assert "DESC" in result

    def test_preserves_explicit_asc(self):
        """normalize_sql keeps explicit ASC."""
        result = normalize_sql("SELECT * FROM t ORDER BY name ASC")
        assert "ASC" in result

    def test_multiple_order_columns(self):
        """normalize_sql handles multiple ORDER BY columns."""
        result = normalize_sql("SELECT * FROM t ORDER BY a, b DESC, c")
        assert "a ASC" in result
        assert "b DESC" in result
        assert "c ASC" in result

    def test_no_order_by(self):
        """normalize_sql returns canonicalized SQL when no ORDER BY
        present."""
        result = normalize_sql("SELECT * FROM t WHERE id = 1")
        assert "ORDER" not in result

    def test_order_by_with_limit(self):
        """normalize_sql handles ORDER BY followed by LIMIT."""
        result = normalize_sql("SELECT * FROM t ORDER BY id LIMIT 10")
        assert "id ASC" in result
        assert "LIMIT" in result

    def test_empty_string(self):
        """normalize_sql returns empty string for empty input."""
        assert normalize_sql("") == ""

    def test_order_by_skips_empty_segments(self):
        """normalize_sql skips empty segments between commas in ORDER BY."""
        result = normalize_sql("SELECT 1 FROM t ORDER BY a, , b")
        assert "a ASC" in result
        assert "b ASC" in result

    def test_order_by_single_column_no_direction(self):
        """normalize_sql handles single column without ASC/DESC."""
        result = normalize_sql("SELECT * FROM t ORDER BY x")
        assert result.strip().endswith("x ASC") or "x ASC" in result


class TestPrintQueryResult:
    """Tests for print_query_result."""

    def test_single_scalar(self, capsys):
        """print_query_result prints scalar answer for single-row
        single-col."""
        print_query_result([(42,)], "SELECT COUNT(*)")
        out = capsys.readouterr().out
        assert "Answer: 42" in out

    def test_multi_row(self, capsys):
        """print_query_result prints tabular output for multiple
        rows."""
        rows = [(1, "a"), (2, "b")]
        print_query_result(rows, "SELECT * FROM t")
        out = capsys.readouterr().out
        assert "col1" in out
        assert "col2" in out

    def test_custom_headers(self, capsys):
        """print_query_result uses provided column headers."""
        rows = [(1, "a")]
        print_query_result(rows, "SELECT id, name FROM t", headers=["id", "name"])
        out = capsys.readouterr().out
        assert "id" in out
        assert "name" in out

    def test_truncates_beyond_five_rows(self, capsys):
        """print_query_result shows ellipsis when more than 5 rows."""
        rows = [(i,) for i in range(10)]
        print_query_result(rows, "SELECT * FROM t")
        out = capsys.readouterr().out
        assert "10 total rows" in out

    def test_context_heading(self, capsys):
        """print_query_result prints the context heading."""
        print_query_result([(1,)], "SELECT 1", context="Test Context")
        out = capsys.readouterr().out
        assert "Test Context" in out


class TestPrintInfo:
    """Tests for print_info."""

    def test_title_only(self, capsys):
        """print_info prints title without items or footer."""
        print_info("My Title")
        out = capsys.readouterr().out
        assert "My Title" in out

    def test_with_items(self, capsys):
        """print_info prints key-value pairs."""
        print_info("Header", items={"key1": "val1", "key2": "val2"})
        out = capsys.readouterr().out
        assert "key1: val1" in out
        assert "key2: val2" in out

    def test_with_footer(self, capsys):
        """print_info prints footer text."""
        print_info("Title", footer="Done!")
        out = capsys.readouterr().out
        assert "Done!" in out

    def test_list_items_joined(self, capsys):
        """print_info joins list values with commas."""
        print_info("Title", items={"tags": ["a", "b", "c"]})
        out = capsys.readouterr().out
        assert "a, b, c" in out

    def test_set_items_displayed(self, capsys):
        """print_info handles set values."""
        print_info("Title", items={"s": {1}})
        out = capsys.readouterr().out
        assert "1" in out


class TestSha256EdgeCases:
    """Edge-case tests for sha256."""

    def test_empty_string(self):
        """Sha256 handles empty string."""
        h = sha256("")
        assert len(h) == 64

    def test_unicode(self):
        """Sha256 handles unicode characters."""
        h = sha256("日本語")
        assert len(h) == 64

    def test_long_string(self):
        """Sha256 handles long input."""
        h = sha256("x" * 100000)
        assert len(h) == 64


class TestStableJsonEdgeCases:
    """Edge-case tests for stable_json."""

    def test_nested_dict(self):
        """stable_json handles nested dicts with sorted keys."""
        result = stable_json({"z": {"b": 1, "a": 2}})
        assert '"a":2' in result or '"a": 2' in result

    def test_list_values(self):
        """stable_json handles list values."""
        result = stable_json({"items": [3, 1, 2]})
        assert "[3,1,2]" in result

    def test_empty_dict(self):
        """stable_json handles empty dict."""
        assert stable_json({}) == "{}"

    def test_boolean_values(self):
        """stable_json handles boolean values."""
        result = stable_json({"flag": True})
        assert "true" in result

    def test_null_value(self):
        """stable_json handles None values."""
        result = stable_json({"key": None})
        assert "null" in result


class TestStripFencesEdgeCases:
    """Edge-case tests for strip_fences."""

    def test_json_fence(self):
        """strip_fences removes json code fences."""
        assert _strip_fences("```json\n{}\n```") == "{}"

    def test_empty_fences(self):
        """strip_fences handles empty content in fences."""
        assert _strip_fences("```\n\n```") == ""

    def test_no_language_tag(self):
        """strip_fences removes fences without language tag."""
        assert _strip_fences("```\ncode\n```") == "code"

    def test_multiple_fences_keeps_inner(self):
        """strip_fences only removes outer fences."""
        result = _strip_fences("```sql\nSELECT '```'\n```")
        assert "SELECT" in result


class TestCanonicalizeSqlEdgeCases:
    """Edge-case tests for canonicalize_sql."""

    def test_empty_string(self):
        """canonicalize_sql handles empty string."""
        assert canonicalize_sql("") == ""

    def test_normalizes_comma_spacing(self):
        """canonicalize_sql normalizes spaces around commas."""
        result = canonicalize_sql("SELECT a,b,c FROM t")
        assert ", " in result

    def test_normalizes_paren_spacing(self):
        """canonicalize_sql removes spaces inside parentheses."""
        result = canonicalize_sql("SELECT COUNT( * ) FROM t")
        assert "( " not in result
        assert " )" not in result

    def test_equal_sign_spacing(self):
        """canonicalize_sql normalizes spaces around equals."""
        result = canonicalize_sql("WHERE a=1")
        assert " = " in result

    def test_strips_explain_prefix(self):
        """canonicalize_sql strips EXPLAIN prefix."""
        assert canonicalize_sql("EXPLAIN SELECT 1") == "SELECT 1"

    def test_strips_explain_analyze_prefix(self):
        """canonicalize_sql strips EXPLAIN ANALYZE prefix."""
        result = canonicalize_sql("EXPLAIN ANALYZE SELECT * FROM t")
        assert result.startswith("SELECT")
        assert "EXPLAIN" not in result

    def test_strips_explain_case_insensitive(self):
        """canonicalize_sql strips explain in any case."""
        assert canonicalize_sql("explain select 1") == "select 1"

    def test_plain_select_unchanged_by_explain_strip(self):
        """canonicalize_sql leaves plain SELECT unchanged."""
        result = canonicalize_sql("SELECT 1")
        assert result == "SELECT 1"


class TestNormalizeQuestionEdgeCases:
    """Edge-case tests for normalize_question."""

    def test_empty_string(self):
        """normalize_question handles empty string."""
        assert normalize_question("") == ""

    def test_multiple_quoted_values(self):
        """normalize_question preserves multiple quoted values."""
        result = normalize_question("find 'Alpha' and 'Beta'")
        assert "'Alpha'" in result
        assert "'Beta'" in result

    def test_double_smart_quotes(self):
        """normalize_question converts double smart quotes."""
        result = normalize_question("status is \u201cActive\u201d")
        assert "'Active'" in result

    def test_collapses_whitespace(self):
        """normalize_question collapses multiple spaces."""
        result = normalize_question("show   all   orders")
        assert "  " not in result


class TestExtractFirstJsonObjectEdgeCases:
    """Edge-case tests for extract_first_json_object."""

    def test_empty_string(self):
        """extract_first_json_object returns None for empty string."""
        assert _extract_first_json_object("") is None

    def test_multiple_json_objects(self):
        """extract_first_json_object returns the first object."""
        result = _extract_first_json_object('{"a":1} {"b":2}')
        assert result == '{"a":1}'

    def test_deeply_nested(self):
        """extract_first_json_object handles deep nesting."""
        result = _extract_first_json_object('{"a":{"b":{"c":1}}}')
        assert result == '{"a":{"b":{"c":1}}}'


class TestSafeJsonLoadsEdgeCases:
    """Edge-case tests for safe_json_loads."""

    def test_empty_string(self):
        """safe_json_loads returns None for empty string."""
        assert safe_json_loads("") is None

    def test_json_array(self):
        """safe_json_loads parses JSON arrays."""
        result = safe_json_loads("[1, 2, 3]")
        assert result == [1, 2, 3]

    def test_invalid_json_fragment(self):
        """safe_json_loads returns None when fragment is invalid."""
        assert safe_json_loads("{broken json") is None


class TestParameterAbstractEdgeCases:
    """Edge-case tests for parameter_abstract."""

    def test_no_literals(self):
        """parameter_abstract returns empty params for no literals."""
        sql, params = parameter_abstract("SELECT * FROM t")
        assert len(params) == 0

    def test_multiple_string_literals(self):
        """parameter_abstract replaces multiple string literals."""
        sql, params = parameter_abstract("WHERE a = 'foo' AND b = 'bar'")
        assert len([v for v in params.values() if v.startswith("'")]) == 2

    def test_date_format_slash(self):
        """parameter_abstract replaces slash-format dates."""
        sql, params = parameter_abstract("WHERE dt = 01/15/2024")
        assert "01/15/2024" in params.values()

    def test_decimal_number(self):
        """parameter_abstract replaces decimal numbers."""
        sql, params = parameter_abstract("WHERE price > 9.99")
        assert "9.99" in params.values()


class TestSubstituteParamsEdgeCases:
    """Edge-case tests for substitute_params."""

    def test_none_value(self):
        """substitute_params handles None value."""
        result = substitute_params("WHERE x = :p1", {"p1": None})
        assert "None" in result

    def test_already_quoted_csv_string(self):
        """substitute_params handles pre-quoted comma-separated
        string."""
        result = substitute_params("WHERE x IN (:p1)", {"p1": "'a','b'"})
        assert "'a','b'" in result

    def test_empty_params(self):
        """substitute_params returns SQL unchanged for empty params."""
        result = substitute_params("SELECT 1", {})
        assert result == "SELECT 1"

    def test_multiple_params_sorted_by_length(self):
        """substitute_params replaces longer keys first to avoid partial
        matches."""
        result = substitute_params("WHERE a = :p10 AND b = :p1", {"p1": "x", "p10": "y"})
        assert "'y'" in result
        assert "'x'" in result

    def test_skips_empty_key_in_params(self):
        """substitute_params skips placeholder for empty string key."""
        result = substitute_params("WHERE x = :p1", {"": "ignored", "p1": "val"})
        assert "val" in result


class TestSqlFpEdgeCases:
    """Edge-case tests for sql_fp."""

    def test_empty_string(self):
        """sql_fp handles empty string."""
        h = sql_fp("")
        assert len(h) == 64

    def test_whitespace_only(self):
        """sql_fp handles whitespace-only input."""
        h = sql_fp("   ")
        assert len(h) == 64


class TestJoinSigStringEdgeCases:
    """Edge-case tests for join_sig_string."""

    def test_multiple_elements(self):
        """join_sig_string joins multiple elements."""
        result = join_sig_string(["a->b", "c->d", "e->f"])
        assert result == "a->b|c->d|e->f"

    def test_elements_with_special_chars(self):
        """join_sig_string handles elements with special characters."""
        result = join_sig_string(["t1.id=t2.fk"])
        assert result == "t1.id=t2.fk"


class TestExplainDbErrorNlEdgeCases:
    """Edge-case tests for explain_db_error_nl."""

    def test_operator_not_exist(self):
        """explain_db_error_nl recognizes operator type mismatch."""
        result = explain_db_error_nl("ERROR: operator does not exist: text = integer")
        assert "incompatible" in result.lower() or "type" in result.lower()

    def test_invalid_input_syntax(self):
        """explain_db_error_nl recognizes invalid input syntax."""
        result = explain_db_error_nl("ERROR: invalid input syntax for type integer")
        assert "literal" in result.lower() or "type" in result.lower()

    def test_subquery_multiple_rows(self):
        """explain_db_error_nl recognizes scalar subquery returning
        multiple rows."""
        result = explain_db_error_nl("ERROR: more than one row returned by a subquery used as an expression")
        assert "subquery" in result.lower()


class TestFormatCellEdgeCases:
    """Edge-case tests for _format_cell."""

    def test_boolean(self):
        """_format_cell formats boolean."""
        assert _format_cell(True) == "True"

    def test_float(self):
        """_format_cell formats float."""
        assert _format_cell(3.14) == "3.14"

    def test_zero(self):
        """_format_cell formats zero."""
        assert _format_cell(0) == "0"

    def test_empty_string(self):
        """_format_cell formats empty string."""
        assert _format_cell("") == ""

    def test_decimal_zero(self):
        """_format_cell formats Decimal zero."""
        result = _format_cell(Decimal("0"))
        assert result == "0"

    def test_large_decimal(self):
        """_format_cell formats large Decimal."""
        result = _format_cell(Decimal("99999999"))
        assert "99999999" in result


class TestColmapSignatureEdgeCases:
    """Edge-case tests for colmap_signature."""

    def test_empty_map(self):
        """colmap_signature handles empty column map."""
        h = colmap_signature({})
        assert len(h) == 64

    def test_order_independent(self):
        """colmap_signature is order-independent."""
        assert colmap_signature({"a": "t1", "b": "t2"}) == colmap_signature({"b": "t2", "a": "t1"})


class TestIntentIdEdgeCases:
    """Edge-case tests for intent_id."""

    def test_empty_dict(self):
        """intent_id handles empty dict."""
        result = intent_id({})
        assert len(result) == 16

    def test_nested_structure(self):
        """intent_id handles nested structures."""
        result = intent_id({"a": {"b": [1, 2]}})
        assert len(result) == 16


class TestIssueSigEdgeCases:
    """Edge-case tests for issue_sig."""

    def test_empty_list(self):
        """issue_sig handles empty list."""
        h = issue_sig([])
        assert len(h) == 64

    def test_duplicate_ids(self):
        """issue_sig handles duplicate rule IDs."""
        h = issue_sig(["a", "a", "b"])
        assert len(h) == 64


class TestSchemaHashFpEdgeCases:
    """Edge-case tests for schema_hash_fp."""

    def test_empty_tables(self):
        """schema_hash_fp handles empty tables dict."""
        h = schema_hash_fp({})
        assert len(h) == 64

    def test_nested_column_info(self):
        """schema_hash_fp handles nested column info."""
        h = schema_hash_fp({"t1": {"columns": [{"name": "id", "type": "int"}]}})
        assert len(h) == 64


class TestIsRepairOscillating:
    """Tests for is_repair_oscillating."""

    def test_empty_list(self):
        """Empty fingerprint list does not oscillate."""
        assert is_repair_oscillating([]) is False

    def test_single_entry(self):
        """Single fingerprint does not oscillate."""
        assert is_repair_oscillating(["a"]) is False

    def test_aa_pattern(self):
        """Two identical fingerprints trigger AA oscillation."""
        assert is_repair_oscillating(["a", "a"]) is True

    def test_ab_no_oscillation(self):
        """Two different fingerprints do not oscillate."""
        assert is_repair_oscillating(["a", "b"]) is False

    def test_aba_pattern(self):
        """A-B-A cycle triggers oscillation."""
        assert is_repair_oscillating(["a", "b", "a"]) is True

    def test_abc_no_oscillation(self):
        """Three distinct fingerprints do not oscillate."""
        assert is_repair_oscillating(["a", "b", "c"]) is False

    def test_abab_triggers_via_aa_at_end(self):
        """A-B-A-B triggers via last two being B-B? No — A-B-A-B last 2 are A,B, last 3 are B,A,B → ABA detected."""
        assert is_repair_oscillating(["a", "b", "a", "b"]) is True

    def test_long_list_with_aa_at_end(self):
        """AA pattern at end of longer list triggers oscillation."""
        assert is_repair_oscillating(["a", "b", "c", "d", "d"]) is True

    def test_long_list_with_aba_at_end(self):
        """ABA pattern at end of longer list triggers oscillation."""
        assert is_repair_oscillating(["x", "y", "a", "b", "a"]) is True

    def test_long_list_no_oscillation(self):
        """Distinct trailing entries do not oscillate."""
        assert is_repair_oscillating(["a", "b", "c", "d", "e"]) is False
