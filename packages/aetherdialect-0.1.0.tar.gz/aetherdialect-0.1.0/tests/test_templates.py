"""Tests for templates module: trust promotion, demotion, feedback, store conversion."""

from unittest.mock import patch

from text2sql.config import PolicyConfig
from text2sql.contracts_base import (
    ColumnMetadata,
    ColumnRole,
    SchemaGraph,
    SQLShape,
    TableMetadata,
    TemplateStats,
)
from text2sql.contracts_core import (
    ConcreteIntent,
    NormalizedExpr,
    RejectedTemplate,
    RejectedValueHistory,
    RuntimeIntent,
    SelectCol,
    Template,
    ValueHistory,
)
from text2sql.templates import (
    _cleanup_negative_memory_for_rejected,
    _convert_to_json_serializable,
    best_template_by_intent_key,
    demote_template_to_rejected,
    find_rejected_by_intent_key,
    find_rejected_by_similarity,
    get_aggregated_hard_block_info,
    get_hard_block_info,
    increment_rejected_template,
    insert_rejected_template,
    insert_template,
    load_template_store,
    maybe_demote_trust,
    promote_rejected_to_template,
    promote_trust,
    record_template_feedback,
    rejected_templates_to_store,
    save_template_store,
    store_to_rejected_templates,
    store_to_templates,
    templates_to_store,
    top_rejected_examples,
)


def _make_template(trust_level: int = 1, accept: int = 1, reject: int = 0) -> Template:
    """Create a minimal Template for testing."""
    return Template(
        id="T0001",
        schema_hash="test_hash",
        intent_signature=ConcreteIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        ),
        intent_key="test_key",
        tables_used=["orders"],
        sql_param="SELECT order_id FROM orders",
        sql_display_param="SELECT order_id FROM orders",
        sql_fp="test_fp",
        shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
        colmap_sig="test_sig",
        value_history=ValueHistory(param_values=[{}], questions=["test"], natural_language=["test"]),
        stats=TemplateStats(accept=accept, reject=reject),
        trust_level=trust_level,
    )


def _make_rejected(
    id: str = "R0001",
    intent_key: str = "rej_key",
    sql_fp: str = "rej_fp",
    categories: list = None,
    reasons: list = None,
) -> RejectedTemplate:
    """Create a minimal RejectedTemplate for testing."""
    return RejectedTemplate(
        id=id,
        schema_hash="test_hash",
        intent_signature=ConcreteIntent(
            intent_id="test",
            tables=["orders"],
            grain="row_level",
            select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        ),
        intent_key=intent_key,
        tables_used=["orders"],
        sql_param="SELECT order_id FROM orders",
        sql_display_param="SELECT order_id FROM orders",
        sql_fp=sql_fp,
        shape=SQLShape(num_joins=0, has_group_by=False, has_agg=False),
        colmap_sig="test_colmap_sig",
        value_history=RejectedValueHistory(
            param_values=[{}],
            questions=["test"],
            natural_language=["test"],
            rejection_reasons=reasons or ["test reason"],
            rejection_categories=categories or ["test_category"],
        ),
    )


class TestPromoteTrust:
    """Tests for promote_trust."""

    def test_promote_0_to_1(self):
        """promote_trust promotes trust 0 to 1."""
        t = _make_template(trust_level=0)
        result = promote_trust(t)
        assert result is True
        assert t.trust_level == 1

    def test_promote_1_to_2_with_enough_history(self):
        """promote_trust promotes trust 1 to 2 when threshold met."""
        min_total = PolicyConfig.TRUST_PROMOTE_MIN_TOTAL
        t = _make_template(trust_level=1, accept=min_total, reject=0)
        result = promote_trust(t)
        assert result is True
        assert t.trust_level == 2

    def test_no_promote_1_to_2_insufficient_total(self):
        """promote_trust does not promote with insufficient total."""
        t = _make_template(trust_level=1, accept=1, reject=0)
        result = promote_trust(t)
        assert result is False
        assert t.trust_level == 1

    def test_no_promote_already_2(self):
        """promote_trust returns False when already at max trust."""
        t = _make_template(trust_level=2, accept=10, reject=0)
        result = promote_trust(t)
        assert result is False
        assert t.trust_level == 2

    def test_no_promote_high_reject_ratio(self):
        """promote_trust does not promote with high reject ratio."""
        min_total = PolicyConfig.TRUST_PROMOTE_MIN_TOTAL
        rejects = min_total
        t = _make_template(trust_level=1, accept=1, reject=rejects)
        result = promote_trust(t)
        assert result is False
        assert t.trust_level == 1


class TestMaybeDemoteTrust:
    """Tests for maybe_demote_trust."""

    def test_demote_2_to_1(self):
        """maybe_demote_trust demotes trust 2 to 1 on high reject
        ratio."""
        reject_ratio_needed = PolicyConfig.TRUST_DEMOTE_REJECT_RATIO_T2
        total = 10
        rejects = int(total * (reject_ratio_needed + 0.1))
        accepts = total - rejects
        t = _make_template(trust_level=2, accept=accepts, reject=rejects)
        result = maybe_demote_trust(t)
        assert result is True
        assert t.trust_level == 1

    def test_demote_1_to_0(self):
        """maybe_demote_trust demotes trust 1 to 0 on high reject
        ratio."""
        reject_ratio_needed = PolicyConfig.TRUST_DEMOTE_REJECT_RATIO_T1
        total = 10
        rejects = int(total * (reject_ratio_needed + 0.1))
        accepts = total - rejects
        t = _make_template(trust_level=1, accept=accepts, reject=rejects)
        result = maybe_demote_trust(t)
        assert result is True
        assert t.trust_level == 0

    def test_no_demote_zero_total(self):
        """maybe_demote_trust returns False with zero total."""
        t = _make_template(trust_level=1, accept=0, reject=0)
        result = maybe_demote_trust(t)
        assert result is False

    def test_no_demote_low_reject_ratio(self):
        """maybe_demote_trust does not demote with low reject ratio."""
        t = _make_template(trust_level=2, accept=10, reject=0)
        result = maybe_demote_trust(t)
        assert result is False
        assert t.trust_level == 2


class TestRecordTemplateFeedback:
    """Tests for record_template_feedback."""

    def test_accept_increments(self):
        """record_template_feedback increments accept count."""
        t = _make_template(accept=1, reject=0)
        record_template_feedback(t, accept=True)
        assert t.stats.accept == 2

    def test_reject_increments(self):
        """record_template_feedback increments reject count."""
        t = _make_template(accept=1, reject=0)
        record_template_feedback(t, accept=False)
        assert t.stats.reject == 1


class TestTemplatesToStore:
    """Tests for templates_to_store round trip."""

    def test_round_trip(self):
        """templates_to_store converts templates to store dict."""
        t = _make_template()
        store = {"templates": {}, "next_id": 2}
        result = templates_to_store(store, {"T0001": t})
        assert "T0001" in result["templates"]
        assert isinstance(result["templates"]["T0001"], dict)


class TestFindRejectedByIntentKey:
    """Tests for find_rejected_by_intent_key."""

    def test_found(self):
        """find_rejected_by_intent_key returns matching rejected
        template."""
        rt = _make_rejected(intent_key="target_key")
        rejected = {"R0001": rt}
        result = find_rejected_by_intent_key(rejected, "target_key")
        assert result is rt

    def test_not_found(self):
        """find_rejected_by_intent_key returns None when no match."""
        rt = _make_rejected(intent_key="other_key")
        rejected = {"R0001": rt}
        result = find_rejected_by_intent_key(rejected, "missing_key")
        assert result is None

    def test_empty_dict(self):
        """find_rejected_by_intent_key returns None for empty dict."""
        assert find_rejected_by_intent_key({}, "any_key") is None

    def test_multiple_entries(self):
        """find_rejected_by_intent_key finds correct one among many."""
        rt1 = _make_rejected(id="R0001", intent_key="key1")
        rt2 = _make_rejected(id="R0002", intent_key="key2")
        rejected = {"R0001": rt1, "R0002": rt2}
        result = find_rejected_by_intent_key(rejected, "key2")
        assert result is rt2


class TestGetHardBlockInfo:
    """Tests for get_hard_block_info."""

    def test_no_block_single_rejection(self):
        """get_hard_block_info does not block for single rejection."""
        rt = _make_rejected(categories=["schema_mismatch"], reasons=["bad schema"])
        result = get_hard_block_info(rt)
        assert result["should_block"] is False
        assert result["total_rejects"] == 1

    def test_block_on_two_structural_rejections(self):
        """get_hard_block_info blocks on 2+ structural rejections of
        same category."""
        structural_cat = (
            list(PolicyConfig.STRUCTURAL_REJECT_CATEGORIES)[0]
            if PolicyConfig.STRUCTURAL_REJECT_CATEGORIES
            else "schema_mismatch"
        )
        rt = _make_rejected(
            categories=[structural_cat, structural_cat],
            reasons=["reason1", "reason2"],
        )
        result = get_hard_block_info(rt)
        assert result["should_block"] is True
        assert result["blocking_category"] == structural_cat

    def test_no_block_non_structural(self):
        """get_hard_block_info does not block for non-structural
        categories."""
        rt = _make_rejected(
            categories=["user_reject", "user_reject", "user_reject"],
            reasons=["r1", "r2", "r3"],
        )
        result = get_hard_block_info(rt)
        if "user_reject" not in PolicyConfig.STRUCTURAL_REJECT_CATEGORIES:
            assert result["should_block"] is False

    def test_returns_last_reason(self):
        """get_hard_block_info returns last rejection reason."""
        rt = _make_rejected(
            categories=["cat1", "cat2"],
            reasons=["first", "last"],
        )
        result = get_hard_block_info(rt)
        assert result["last_reason"] == "last"

    def test_category_counts(self):
        """get_hard_block_info returns correct category counts."""
        rt = _make_rejected(
            categories=["cat_a", "cat_b", "cat_a"],
            reasons=["r1", "r2", "r3"],
        )
        result = get_hard_block_info(rt)
        assert result["categories"]["cat_a"] == 2
        assert result["categories"]["cat_b"] == 1


class TestBestTemplateByIntentKey:
    """Tests for best_template_by_intent_key."""

    def test_found(self):
        """best_template_by_intent_key returns matching template."""
        t = _make_template()
        templates = {"T0001": t}
        result = best_template_by_intent_key(templates, "test_key")
        assert result is t

    def test_not_found(self):
        """best_template_by_intent_key returns None when no match."""
        t = _make_template()
        templates = {"T0001": t}
        result = best_template_by_intent_key(templates, "missing_key")
        assert result is None

    def test_empty_templates(self):
        """best_template_by_intent_key returns None for empty dict."""
        assert best_template_by_intent_key({}, "any_key") is None


class TestRejectedTemplatesToStore:
    """Tests for rejected_templates_to_store."""

    def test_converts_to_store(self):
        """rejected_templates_to_store serializes rejected templates."""
        rt = _make_rejected()
        store = {"rejected_templates": {}}
        result = rejected_templates_to_store(store, {"R0001": rt})
        assert "R0001" in result["rejected_templates"]
        assert isinstance(result["rejected_templates"]["R0001"], dict)

    def test_empty_rejected(self):
        """rejected_templates_to_store handles empty dict."""
        store = {"rejected_templates": {}}
        result = rejected_templates_to_store(store, {})
        assert result["rejected_templates"] == {}


class TestStoreToTemplates:
    """Tests for store_to_templates."""

    def test_round_trip(self):
        """store_to_templates reconstructs Template from store dict."""
        t = _make_template()
        store = {"templates": {}, "next_id": 2}
        templates_to_store(store, {"T0001": t})
        result = store_to_templates(store)
        assert "T0001" in result
        assert result["T0001"].id == "T0001"
        assert result["T0001"].tables_used == ["orders"]

    def test_empty_store(self):
        """store_to_templates returns empty dict for empty store."""
        assert store_to_templates({"templates": {}}) == {}


class TestStoreToRejectedTemplates:
    """Tests for store_to_rejected_templates."""

    def test_round_trip(self):
        """store_to_rejected_templates reconstructs RejectedTemplate
        from store."""
        rt = _make_rejected()
        store = {"rejected_templates": {}}
        rejected_templates_to_store(store, {"R0001": rt})
        result = store_to_rejected_templates(store)
        assert "R0001" in result
        assert result["R0001"].id == "R0001"

    def test_empty_store(self):
        """store_to_rejected_templates returns empty dict for empty
        store."""
        assert store_to_rejected_templates({"rejected_templates": {}}) == {}


class TestConvertToJsonSerializable:
    """Tests for _convert_to_json_serializable."""

    def test_set_to_list(self):
        """_convert_to_json_serializable converts set to list."""
        result = _convert_to_json_serializable({1, 2, 3})
        assert isinstance(result, list)
        assert set(result) == {1, 2, 3}

    def test_nested_dict_with_set(self):
        """_convert_to_json_serializable converts nested sets."""
        result = _convert_to_json_serializable({"a": {1, 2}})
        assert isinstance(result["a"], list)

    def test_list_with_set(self):
        """_convert_to_json_serializable converts sets inside lists."""
        result = _convert_to_json_serializable([{1, 2}])
        assert isinstance(result[0], list)

    def test_plain_values_unchanged(self):
        """_convert_to_json_serializable leaves plain values
        unchanged."""
        assert _convert_to_json_serializable("hello") == "hello"
        assert _convert_to_json_serializable(42) == 42
        assert _convert_to_json_serializable(None) is None

    def test_frozenset_to_list(self):
        """_convert_to_json_serializable converts frozenset to list."""
        result = _convert_to_json_serializable(frozenset([1, 2, 3]))
        assert sorted(result) == [1, 2, 3]

    def test_tuple_to_list(self):
        """_convert_to_json_serializable converts tuple to list."""
        result = _convert_to_json_serializable((1, 2))
        assert isinstance(result, list)


class TestCleanupNegativeMemoryForRejected:
    """Tests for cleanup_negative_memory_for_rejected."""

    def test_removes_by_intent_key(self):
        """cleanup_negative_memory_for_rejected removes by_intent_key
        entry."""
        rt = _make_rejected(intent_key="target_key")
        store = {
            "negative_memory": {
                "by_intent_key": {"target_key": {"reason": "bad"}},
                "by_sql_fp": {},
                "by_join_sig": {},
                "by_colmap_sig": {},
            }
        }
        _cleanup_negative_memory_for_rejected(store, rt)
        assert "target_key" not in store["negative_memory"]["by_intent_key"]

    def test_removes_by_sql_fp(self):
        """cleanup_negative_memory_for_rejected removes by_sql_fp
        entry."""
        rt = _make_rejected(sql_fp="target_fp")
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_sql_fp": {"target_fp": {"reason": "bad"}},
                "by_join_sig": {},
                "by_colmap_sig": {},
            }
        }
        _cleanup_negative_memory_for_rejected(store, rt)
        assert "target_fp" not in store["negative_memory"]["by_sql_fp"]

    def test_no_crash_empty_memory(self):
        """cleanup_negative_memory_for_rejected handles empty
        negative_memory."""
        rt = _make_rejected()
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_sql_fp": {},
                "by_join_sig": {},
                "by_colmap_sig": {},
            }
        }
        _cleanup_negative_memory_for_rejected(store, rt)

    def test_decrements_colmap_sig_bucket(self):
        """cleanup_negative_memory_for_rejected decrements colmap_sig
        bucket."""
        rt = _make_rejected(categories=["cat1"], reasons=["reason1"])
        rt.colmap_sig = "cm_sig"
        store = {
            "negative_memory": {
                "by_intent_key": {},
                "by_sql_fp": {},
                "by_join_sig": {},
                "by_colmap_sig": {
                    "cm_sig": {
                        "rejects": 2,
                        "reasons": ["reason1", "other"],
                        "categories": {"cat1": 1, "cat2": 1},
                    }
                },
            }
        }
        _cleanup_negative_memory_for_rejected(store, rt)
        assert store["negative_memory"]["by_colmap_sig"]["cm_sig"]["rejects"] == 1


class TestPromoteTrustEdgeCases:
    """Edge-case tests for promote_trust."""

    def test_promote_boundary_total(self):
        """promote_trust promotes at exact threshold total."""
        min_total = PolicyConfig.TRUST_PROMOTE_MIN_TOTAL
        t = _make_template(trust_level=1, accept=min_total, reject=0)
        result = promote_trust(t)
        assert result is True
        assert t.trust_level == 2

    def test_just_below_threshold(self):
        """promote_trust does not promote below threshold."""
        min_total = PolicyConfig.TRUST_PROMOTE_MIN_TOTAL
        t = _make_template(trust_level=1, accept=min_total - 1, reject=0)
        result = promote_trust(t)
        assert result is False


class TestMaybeDemoteTrustEdgeCases:
    """Edge-case tests for maybe_demote_trust."""

    def test_trust_0_no_demote(self):
        """maybe_demote_trust does not demote trust level 0."""
        t = _make_template(trust_level=0, accept=0, reject=10)
        result = maybe_demote_trust(t)
        assert result is False

    def test_exact_ratio_t2(self):
        """maybe_demote_trust at exact T2 threshold ratio."""
        ratio = PolicyConfig.TRUST_DEMOTE_REJECT_RATIO_T2
        total = 100
        rejects = int(total * ratio) + 1
        accepts = total - rejects
        t = _make_template(trust_level=2, accept=accepts, reject=rejects)
        result = maybe_demote_trust(t)
        assert result is True
        assert t.trust_level == 1


class TestRecordTemplateFeedbackEdgeCases:
    """Edge-case tests for record_template_feedback."""

    def test_multiple_accepts(self):
        """record_template_feedback handles multiple accepts."""
        t = _make_template(accept=0, reject=0)
        record_template_feedback(t, accept=True)
        record_template_feedback(t, accept=True)
        record_template_feedback(t, accept=True)
        assert t.stats.accept == 3

    def test_mixed_feedback(self):
        """record_template_feedback handles mixed accept/reject."""
        t = _make_template(accept=0, reject=0)
        record_template_feedback(t, accept=True)
        record_template_feedback(t, accept=False)
        record_template_feedback(t, accept=True)
        assert t.stats.accept == 2
        assert t.stats.reject == 1


def _make_runtime_intent(tables=None, filters=None) -> RuntimeIntent:
    """Create a minimal RuntimeIntent for template tests."""
    return RuntimeIntent(
        tables=tables or ["orders"],
        grain="row_level",
        select_cols=[SelectCol(expr=NormalizedExpr.from_column("orders.order_id"))],
        group_by_cols=[],
        order_by_cols=[],
        filters_param=filters or [],
    )


def _simple_schema() -> SchemaGraph:
    """Create a minimal SchemaGraph for template tests."""
    return SchemaGraph(
        tables={
            "orders": TableMetadata(
                name="orders",
                columns={
                    "order_id": ColumnMetadata(
                        name="order_id",
                        data_type="integer",
                        value_type="integer",
                        is_primary_key=True,
                        role=ColumnRole.IDENTIFIER.value,
                    ),
                },
                foreign_keys=[],
                primary_key="",
            ),
        },
        join_paths_multi={},
        schema_hash="test_hash",
    )


class TestIncrementRejectedTemplate:
    """Tests for increment_rejected_template."""

    def test_increments_value_history(self):
        """Adds a new entry to value_history."""
        rt = _make_rejected()
        intent = _make_runtime_intent()
        increment_rejected_template(rt, "schema_mismatch", "bad join", "test q", intent, "SELECT 1")
        assert len(rt.value_history.questions) == 2
        assert rt.value_history.rejection_categories[-1] == "schema_mismatch"
        assert rt.value_history.rejection_reasons[-1] == "bad join"

    def test_multiple_increments(self):
        """Multiple increments accumulate."""
        rt = _make_rejected()
        intent = _make_runtime_intent()
        for i in range(3):
            increment_rejected_template(rt, "cat", f"reason_{i}", f"q_{i}", intent, "SELECT 1")
        assert len(rt.value_history.questions) == 4


class TestGetAggregatedHardBlockInfo:
    """Tests for get_aggregated_hard_block_info."""

    def test_no_rejected_no_block(self):
        """Empty rejected dict produces no block."""
        intent = _make_runtime_intent()
        result = get_aggregated_hard_block_info({}, intent)
        assert result["should_block"] is False
        assert result["total_rejects"] == 0

    def test_structural_rejects_trigger_block(self):
        """Enough structural rejections trigger should_block."""
        rt = _make_rejected(
            categories=["wrong_intent", "wrong_intent"],
            reasons=["r1", "r2"],
        )
        intent = _make_runtime_intent()
        result = get_aggregated_hard_block_info({"R0001": rt}, intent, similarity_threshold=0.0)
        assert result["should_block"] is True
        assert result["total_structural_rejects"] >= 2

    def test_non_structural_does_not_block(self):
        """Non-structural categories don't trigger block."""
        rt = _make_rejected(
            categories=["user_feedback", "user_feedback"],
            reasons=["r1", "r2"],
        )
        intent = _make_runtime_intent()
        result = get_aggregated_hard_block_info({"R0001": rt}, intent, similarity_threshold=0.0)
        assert result["should_block"] is False


class TestFindRejectedBySimilarity:
    """Tests for find_rejected_by_similarity."""

    def test_exact_match_found(self):
        """Identical intent returns the rejected template."""
        rt = _make_rejected()
        intent = _make_runtime_intent()
        result = find_rejected_by_similarity({"R0001": rt}, intent, threshold=0.0)
        assert result is not None
        assert result.id == "R0001"

    def test_no_match_returns_none(self):
        """Dissimilar intent returns None."""
        rt = _make_rejected()
        intent = RuntimeIntent(
            tables=["completely_different_table"],
            grain="scalar",
            select_cols=[SelectCol(expr=NormalizedExpr.from_agg("count", "x.y"))],
            group_by_cols=[],
            order_by_cols=[],
            filters_param=[],
        )
        result = find_rejected_by_similarity({"R0001": rt}, intent, threshold=0.99)
        assert result is None

    def test_empty_rejected(self):
        """Empty rejected dict returns None."""
        intent = _make_runtime_intent()
        assert find_rejected_by_similarity({}, intent) is None


class TestPromoteRejectedToTemplate:
    """Tests for promote_rejected_to_template."""

    @patch("text2sql.templates.llm_ux_explain", return_value="test summary")
    def test_creates_template_and_removes_rejected(self, mock_ux):
        """Promotes rejected to template and removes from rejected
        dict."""
        store = {
            "next_id": 1,
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
        }
        templates = {}
        rt = _make_rejected()
        rejected = {"R0001": rt}
        intent = _make_runtime_intent()
        result = promote_rejected_to_template(
            store,
            templates,
            rejected,
            rt,
            "q",
            intent,
            "SELECT order_id FROM orders",
            "test_hash",
        )
        assert result.id == "T0001"
        assert "T0001" in templates
        assert "R0001" not in rejected

    @patch("text2sql.templates.llm_ux_explain", return_value="ux")
    def test_increments_next_id(self, mock_ux):
        """Promotion increments store next_id."""
        store = {
            "next_id": 5,
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
        }
        templates = {}
        rt = _make_rejected()
        rejected = {"R0001": rt}
        intent = _make_runtime_intent()
        promote_rejected_to_template(store, templates, rejected, rt, "q", intent, "SELECT 1", "hash")
        assert store["next_id"] == 6


class TestDemoteTemplateToRejected:
    """Tests for demote_template_to_rejected."""

    def test_creates_rejected_and_removes_template(self):
        """Demotes template to rejected and removes from templates
        dict."""
        store = {"next_reject_id": 1}
        tmpl = _make_template()
        templates = {"T0001": tmpl}
        rejected = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        result = demote_template_to_rejected(
            store,
            templates,
            rejected,
            tmpl,
            schema,
            intent,
            "SELECT 1",
            "q",
            "schema_mismatch",
            "bad join",
        )
        assert result.id == "R0001"
        assert "R0001" in rejected
        assert "T0001" not in templates

    def test_increments_next_reject_id(self):
        """Demotion increments store next_reject_id."""
        store = {"next_reject_id": 3}
        tmpl = _make_template()
        templates = {"T0001": tmpl}
        rejected = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        demote_template_to_rejected(
            store,
            templates,
            rejected,
            tmpl,
            schema,
            intent,
            "SELECT 1",
            "q",
            "cat",
            "reason",
        )
        assert store["next_reject_id"] == 4


class TestTopRejectedExamples:
    """Tests for top_rejected_examples."""

    def test_empty_rejected(self):
        """Empty rejected dict returns no examples."""
        intent = _make_runtime_intent()
        assert top_rejected_examples({}, intent) == []

    def test_single_reject_insufficient(self):
        """Rejected template with only 1 rejection is skipped."""
        rt = _make_rejected(categories=["wrong_intent"], reasons=["r1"])
        intent = _make_runtime_intent()
        result = top_rejected_examples({"R0001": rt}, intent)
        assert len(result) == 0

    def test_structural_double_reject_included(self):
        """Rejected template with 2 structural rejections is
        included."""
        rt = _make_rejected(
            categories=["wrong_intent", "wrong_intent"],
            reasons=["r1", "r2"],
        )
        intent = _make_runtime_intent()
        result = top_rejected_examples({"R0001": rt}, intent, k=3)
        assert len(result) >= 1

    def test_exclude_id_skips(self):
        """Excluded ID is skipped."""
        rt = _make_rejected(
            categories=["wrong_intent", "wrong_intent"],
            reasons=["r1", "r2"],
        )
        intent = _make_runtime_intent()
        result = top_rejected_examples({"R0001": rt}, intent, exclude_id="R0001")
        assert len(result) == 0


class TestInsertTemplate:
    """Tests for insert_template."""

    @patch("text2sql.templates.llm_ux_explain", return_value="ux summary")
    def test_creates_new_template(self, mock_ux):
        """Inserts a new template when no duplicate exists."""
        store = {"next_id": 1}
        templates = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        result = insert_template(store, templates, schema, "q", intent, "SELECT order_id FROM orders")
        assert result.id == "T0001"
        assert "T0001" in templates
        assert store["next_id"] == 2

    @patch("text2sql.templates.llm_ux_explain", return_value="ux")
    def test_provides_ux_summary_skips_llm(self, mock_ux):
        """Pre-computed ux_summary skips the LLM call."""
        store = {"next_id": 1}
        templates = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        insert_template(
            store,
            templates,
            schema,
            "q",
            intent,
            "SELECT order_id FROM orders",
            ux_summary="pre-computed",
        )
        mock_ux.assert_not_called()

    @patch("text2sql.templates.llm_ux_explain", return_value="ux")
    def test_stats_initialized(self, mock_ux):
        """New template starts with accept=1, reject=0."""
        store = {"next_id": 1}
        templates = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        result = insert_template(store, templates, schema, "q", intent, "SELECT order_id FROM orders")
        assert result.stats.accept == 1
        assert result.stats.reject == 0


class TestInsertRejectedTemplate:
    """Tests for insert_rejected_template."""

    def test_creates_new_rejected(self):
        """Inserts a new rejected template."""
        store = {"next_reject_id": 1}
        rejected = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        result = insert_rejected_template(
            store,
            rejected,
            schema,
            "q",
            intent,
            "SELECT 1",
            "schema_mismatch",
            "bad join",
        )
        assert result.id == "R0001"
        assert "R0001" in rejected
        assert store["next_reject_id"] == 2

    def test_rejection_metadata_stored(self):
        """Rejection category and reason are stored in value_history."""
        store = {"next_reject_id": 1}
        rejected = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        result = insert_rejected_template(
            store,
            rejected,
            schema,
            "q",
            intent,
            "SELECT 1",
            "validation_error",
            "type mismatch",
        )
        assert result.value_history.rejection_categories == ["validation_error"]
        assert result.value_history.rejection_reasons == ["type mismatch"]

    def test_sequential_ids(self):
        """Sequential inserts produce sequential IDs."""
        store = {"next_reject_id": 1}
        rejected = {}
        schema = _simple_schema()
        intent = _make_runtime_intent()
        r1 = insert_rejected_template(store, rejected, schema, "q1", intent, "SELECT 1", "c1", "r1")
        r2 = insert_rejected_template(store, rejected, schema, "q2", intent, "SELECT 2", "c2", "r2")
        assert r1.id == "R0001"
        assert r2.id == "R0002"
        assert len(rejected) == 2


class TestLoadTemplateStore:
    """Tests for load_template_store."""

    @patch("text2sql.templates.os.path.exists", return_value=False)
    def test_no_file_returns_empty_store(self, _exists):
        """Missing file returns fresh empty store."""
        store = load_template_store("abc123")
        assert store["schema_hash"] == "abc123"
        assert store["next_id"] == 1
        assert store["templates"] == {}
        assert store["rejected_templates"] == {}
        assert "by_intent_key" in store["negative_memory"]

    @patch("text2sql.templates.os.path.exists", return_value=True)
    @patch("builtins.open")
    @patch("text2sql.templates.json.load")
    def test_mismatched_hash_resets(self, mock_json, mock_open, _exists):
        """Schema hash mismatch returns fresh store."""
        mock_json.return_value = {"schema_hash": "old_hash", "templates": {"T1": {}}}
        store = load_template_store("new_hash")
        assert store["schema_hash"] == "new_hash"
        assert store["templates"] == {}

    @patch("text2sql.templates.os.path.exists", return_value=True)
    @patch("builtins.open")
    @patch("text2sql.templates.json.load")
    def test_matching_hash_loads(self, mock_json, mock_open, _exists):
        """Matching hash preserves existing data."""
        mock_json.return_value = {
            "schema_hash": "match",
            "next_id": 5,
            "next_reject_id": 3,
            "templates": {"T1": {}},
            "rejected_templates": {},
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
        }
        store = load_template_store("match")
        assert store["next_id"] == 5
        assert "T1" in store["templates"]


class TestSaveTemplateStore:
    """Tests for save_template_store."""

    @patch("text2sql.templates._debug_check_types")
    @patch("builtins.open")
    @patch("text2sql.templates.json.dump")
    def test_calls_json_dump(self, mock_dump, mock_open, _debug):
        """save_template_store writes JSON to disk."""
        store = {
            "schema_hash": "h",
            "templates": {},
            "rejected_templates": {},
            "negative_memory": {
                "by_intent_key": {},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
        }
        save_template_store(store)
        mock_dump.assert_called_once()

    @patch("text2sql.templates._debug_check_types")
    @patch("builtins.open")
    @patch("text2sql.templates.json.dump")
    def test_converts_sets_before_save(self, mock_dump, mock_open, _debug):
        """Sets in store are converted to lists before JSON dump."""
        store = {
            "schema_hash": "h",
            "templates": {},
            "rejected_templates": {},
            "negative_memory": {
                "by_intent_key": {"k": {1, 2}},
                "by_join_sig": {},
                "by_sql_fp": {},
                "by_colmap_sig": {},
            },
        }
        save_template_store(store)
        mock_dump.assert_called_once()
