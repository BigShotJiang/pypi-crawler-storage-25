"""Unit tests for PTMClient using responses mock library."""

from __future__ import annotations

import pytest
import responses

from ptm_client import PTMClient, PTMError, PTMTimeoutError

BASE = "http://ptm.test"
TOKEN = "ptm_u_testtoken"


@pytest.fixture
def client() -> PTMClient:
    return PTMClient(BASE, TOKEN)


# ── list_prompts ──────────────────────────────────────────────────────────────


@responses.activate
def test_list_prompts_no_tag(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        json={"prompts": [{"prompt_id": "foo.bar"}]},
    )
    result = client.list_prompts()
    assert result == [{"prompt_id": "foo.bar"}]
    assert "tag" not in responses.calls[0].request.url


@responses.activate
def test_list_prompts_with_tag(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        json=[{"prompt_id": "my_team.summarizer"}],
    )
    result = client.list_prompts(tag="my_team")
    assert result == [{"prompt_id": "my_team.summarizer"}]
    assert "tag=my_team" in responses.calls[0].request.url


# ── list_providers ────────────────────────────────────────────────────────────


@responses.activate
def test_list_providers(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/providers",
        json={"profiles": [{"name": "mock_static"}, {"name": "openai_gpt41_mini"}]},
    )
    result = client.list_providers()
    assert len(result) == 2
    assert result[0]["name"] == "mock_static"


# ── get_prompt_tests ──────────────────────────────────────────────────────────


@responses.activate
def test_get_prompt_tests(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/my_team.summarizer/tests",
        json={"tests": [{"description": "tc1"}], "deepeval_metrics": []},
    )
    result = client.get_prompt_tests("my_team.summarizer")
    assert result["tests"][0]["description"] == "tc1"
    assert "my_team.summarizer/tests" in responses.calls[0].request.url


# ── run_eval ──────────────────────────────────────────────────────────────────


@responses.activate
def test_run_eval_happy_path(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/evaluations/repository",
        json={"run_key": "api-abc123", "status": "queued"},
        status=201,
    )
    run = client.run_eval(
        prompt_ids=["my_team.summarizer"],
        provider_ids=["mock_static"],
        visibility="private",
    )
    assert run["run_key"] == "api-abc123"
    import json

    body = json.loads(responses.calls[0].request.body)
    assert body["prompt_ids"] == ["my_team.summarizer"]
    assert body["provider_ids"] == ["mock_static"]
    assert body["visibility"] == "private"


# ── run_manual_eval ───────────────────────────────────────────────────────────


@responses.activate
def test_run_manual_eval(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/evaluations/manual",
        json={"run_key": "api-manual-1", "status": "queued"},
        status=202,
    )
    payload = {
        "prompt_text": "Hello {{input}}",
        "input_text": "world",
        "provider_profiles": ["mock_static"],
    }
    result = client.run_manual_eval(payload)
    assert result["run_key"] == "api-manual-1"
    import json

    body = json.loads(responses.calls[0].request.body)
    assert body["prompt_text"] == "Hello {{input}}"


# ── run_prompt_eval ───────────────────────────────────────────────────────────


@responses.activate
def test_run_prompt_eval_fetches_and_submits(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/my_team.summarizer",
        json={"prompt_id": "my_team.summarizer", "prompt_text": '[{"role":"user","content":"Hi"}]'},
    )
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/my_team.summarizer/tests",
        json={
            "promptfoo_tests": [{"description": "tc1", "vars": {"name": "Alice"}}],
            "deepeval_metrics": [{"name": "quality", "threshold": 0.7}],
            "judge_profile": "openai_gpt41_mini",
        },
    )
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/evaluations/manual",
        json={"run_key": "api-prompt-eval", "status": "queued"},
        status=202,
    )
    run = client.run_prompt_eval(
        "my_team.summarizer",
        ["openai_gpt41_mini"],
        inject_vars={"transcript": "real data"},
        label="my_eval",
    )
    assert run["run_key"] == "api-prompt-eval"
    import json

    body = json.loads(responses.calls[2].request.body)
    assert body["label"] == "my_eval"
    assert body["provider_profiles"] == ["openai_gpt41_mini"]
    assert body["visibility_scope"] == "org_visible"
    # Verify inject_vars merged into test case
    assert body["tests"][0]["vars"]["transcript"] == "real data"
    assert body["tests"][0]["vars"]["name"] == "Alice"  # original preserved
    assert body["additional_metrics"] == [{"name": "quality", "threshold": 0.7}]
    assert body["judge_profile"] == "openai_gpt41_mini"


@responses.activate
def test_run_prompt_eval_with_extra_tests(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/test.prompt",
        json={"prompt_text": "hello"},
    )
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/test.prompt/tests",
        json={"promptfoo_tests": [{"description": "stored", "vars": {}}]},
    )
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/evaluations/manual",
        json={"run_key": "api-extra", "status": "queued"},
        status=202,
    )
    client.run_prompt_eval(
        "test.prompt",
        ["mock_static"],
        extra_tests=[{"description": "extra", "vars": {"x": 1}}],
    )
    import json

    body = json.loads(responses.calls[2].request.body)
    assert len(body["tests"]) == 2
    assert body["tests"][1]["description"] == "extra"


@responses.activate
def test_run_prompt_eval_no_tests_raises(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/empty.prompt",
        json={"prompt_text": "hello"},
    )
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/empty.prompt/tests",
        json={"promptfoo_tests": []},
    )
    with pytest.raises(PTMError) as exc_info:
        client.run_prompt_eval("empty.prompt", ["mock_static"])
    assert "no test cases" in str(exc_info.value)


# ── get_run (score normalisation) ─────────────────────────────────────────────


@responses.activate
def test_get_run_score_normalisation_from_providers(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-abc123",
        json={
            "run_key": "api-abc123",
            "status": "completed",
            "score": None,
            "providers": [
                {
                    "final_success_percentage": 85.0,
                    "passed_assertions": 17,
                    "total_assertions": 20,
                }
            ],
        },
    )
    result = client.get_run("api-abc123")
    assert result["score"] == 0.85
    assert result["passed_tests"] == 17
    assert result["total_tests"] == 20


@responses.activate
def test_get_run_score_at_root_not_overwritten(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-xyz",
        json={
            "run_key": "api-xyz",
            "status": "completed",
            "score": 0.9,
            "providers": [{"final_success_percentage": 50.0}],
        },
    )
    result = client.get_run("api-xyz")
    assert result["score"] == 0.9  # root score wins


# ── wait_for_run ──────────────────────────────────────────────────────────────


@responses.activate
def test_wait_for_run_terminal_on_second_poll(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-poll",
        json={"run_key": "api-poll", "status": "running"},
    )
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-poll",
        json={"run_key": "api-poll", "status": "completed", "score": 0.95},
    )
    result = client.wait_for_run("api-poll", timeout=300, poll_interval=0)
    assert result["status"] == "completed"
    assert len(responses.calls) == 2


@responses.activate
def test_wait_for_run_timeout_raises(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-slow",
        json={"run_key": "api-slow", "status": "running"},
    )
    with pytest.raises(PTMTimeoutError) as exc_info:
        client.wait_for_run("api-slow", timeout=0, poll_interval=0)
    assert "api-slow" in str(exc_info.value)
    assert exc_info.value.status_code is None


@responses.activate
def test_wait_for_run_cancelled_is_terminal(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-cancel",
        json={"run_key": "api-cancel", "status": "cancelled"},
    )
    result = client.wait_for_run("api-cancel", timeout=10, poll_interval=0)
    assert result["status"] == "cancelled"


# ── PTMError on HTTP 4xx / 5xx ────────────────────────────────────────────────


@responses.activate
def test_ptm_error_on_404(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts/does.not.exist",
        json={"detail": "Not Found"},
        status=404,
    )
    with pytest.raises(PTMError) as exc_info:
        client.get_prompt("does.not.exist")
    assert exc_info.value.status_code == 404
    assert "404" in str(exc_info.value)


@responses.activate
def test_ptm_error_on_500(client: PTMClient) -> None:
    responses.add(
        responses.POST,
        f"{BASE}/api/v1/evaluations/repository",
        json={"detail": "Internal Server Error"},
        status=500,
    )
    with pytest.raises(PTMError) as exc_info:
        client.run_eval(prompt_ids=["x"], provider_ids=["y"])
    assert exc_info.value.status_code == 500


# ── Connection / timeout errors ────────────────────────────────────────────────


@responses.activate
def test_connection_error_raises_ptm_error(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/prompts",
        body=ConnectionError("Connection refused"),
    )
    with pytest.raises(PTMError) as exc_info:
        client.list_prompts()
    assert exc_info.value.status_code == 0
    assert "connection failed" in str(exc_info.value).lower()


def test_timeout_error_raises_ptm_error() -> None:
    # Use a client pointing at an unroutable address to trigger real timeout
    c = PTMClient("http://192.0.2.1:1", "tok", timeout=1)
    with pytest.raises(PTMError) as exc_info:
        c.list_prompts()
    assert exc_info.value.status_code == 0


# ── run_report ────────────────────────────────────────────────────────────────


@responses.activate
def test_run_report_html_content_type(client: PTMClient) -> None:
    html_body = "<html><body>Report</body></html>"
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-abc123/report",
        body=html_body,
        content_type="text/html",
    )
    result = client.run_report("api-abc123")
    assert result == html_body


@responses.activate
def test_run_report_json_wrapped(client: PTMClient) -> None:
    html_body = "<html><body>Report</body></html>"
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-abc123/report",
        json={"html": html_body},
        content_type="application/json",
    )
    result = client.run_report("api-abc123")
    assert result == html_body


@responses.activate
def test_run_report_error_raises_ptm_error(client: PTMClient) -> None:
    responses.add(
        responses.GET,
        f"{BASE}/api/v1/runs/api-bad/report",
        json={"detail": "Not Found"},
        status=404,
    )
    with pytest.raises(PTMError) as exc_info:
        client.run_report("api-bad")
    assert exc_info.value.status_code == 404
