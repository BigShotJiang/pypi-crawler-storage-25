"""
PTMClient — minimal PTM integration for external Python services.

Usage:
    from ptm_client import PTMClient

    client = PTMClient(base_url="http://localhost:8010", token="ptm_u_...")
    prompts = client.list_prompts(tag="my_team")
    run     = client.run_eval(prompt_ids=["my_team.summarizer"], provider_ids=["gpt-4o"])
    status  = client.wait_for_run(run["run_key"])
    html    = client.run_report(run["run_key"])
"""

from __future__ import annotations

import time
from typing import Any

import requests

from ptm_client.errors import PTMError, PTMTimeoutError

TERMINAL_STATES = {"completed", "failed", "cancelled"}


class PTMClient:
    def __init__(self, base_url: str, token: str, timeout: int = 30) -> None:
        self._base = base_url.rstrip("/")
        self._headers = {"Authorization": f"Bearer {token}"}
        self._timeout = timeout

    # ── internal helpers ──────────────────────────────────────────────────────

    def _get(self, path: str, **params: Any) -> Any:
        try:
            resp = requests.get(
                f"{self._base}{path}",
                headers=self._headers,
                params=params or None,
                timeout=self._timeout,
            )
        except requests.Timeout as exc:
            raise PTMError(f"GET {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"GET {path} connection failed: {exc}", status_code=0) from exc
        if resp.status_code >= 400:
            raise PTMError(
                f"GET {path} failed: {resp.status_code} {resp.text[:200]}", resp.status_code
            )
        return resp.json()

    def _post(self, path: str, body: dict[str, Any]) -> Any:
        try:
            resp = requests.post(
                f"{self._base}{path}",
                headers={**self._headers, "Content-Type": "application/json"},
                json=body,
                timeout=self._timeout,
            )
        except requests.Timeout as exc:
            raise PTMError(f"POST {path} timed out: {exc}", status_code=0) from exc
        except (requests.ConnectionError, ConnectionError) as exc:
            raise PTMError(f"POST {path} connection failed: {exc}", status_code=0) from exc
        if resp.status_code >= 400:
            raise PTMError(
                f"POST {path} failed: {resp.status_code} {resp.text[:200]}", resp.status_code
            )
        return resp.json()

    # ── prompts ───────────────────────────────────────────────────────────────

    def list_prompts(self, tag: str | None = None) -> list[dict]:
        """Return all prompts, optionally filtered by tag."""
        params = {"tag": tag} if tag else {}
        data = self._get("/api/v1/prompts", **params)
        return data.get("prompts", data) if isinstance(data, dict) else data

    def get_prompt(self, prompt_id: str) -> dict:
        """Return a single prompt by ID."""
        return self._get(f"/api/v1/prompts/{prompt_id}")

    def get_prompt_tests(self, prompt_id: str) -> dict:
        """Return test cases and deepeval metrics for a prompt."""
        return self._get(f"/api/v1/prompts/{prompt_id}/tests")

    # ── providers ─────────────────────────────────────────────────────────────

    def list_providers(self) -> list[dict]:
        """Return available provider profiles."""
        data = self._get("/api/v1/providers")
        return data.get("profiles", data) if isinstance(data, dict) else data

    # ── evaluations ───────────────────────────────────────────────────────────

    def run_eval(
        self,
        prompt_ids: list[str],
        provider_ids: list[str],
        **kwargs: Any,
    ) -> dict:
        """Submit a repository (library) evaluation and return the run metadata."""
        body = {"prompt_ids": prompt_ids, "provider_ids": provider_ids, **kwargs}
        return self._post("/api/v1/evaluations/repository", body)

    def run_manual_eval(self, payload: dict) -> dict:
        """Submit a manual (replay) evaluation payload and return the run metadata."""
        payload.setdefault("source", "api")
        return self._post("/api/v1/evaluations/manual", payload)

    def run_prompt_eval(
        self,
        prompt_id: str,
        provider_ids: list[str],
        *,
        inject_vars: dict[str, Any] | None = None,
        extra_tests: list[dict] | None = None,
        visibility_scope: str = "org_visible",
        label: str | None = None,
    ) -> dict:
        """Fetch a prompt's content and tests from PTM, then submit a manual eval.

        This is the recommended way for external services to evaluate a PTM prompt
        with live data — it fetches the prompt and its stored test cases, optionally
        injects runtime variables (e.g. a real transcript), and submits in one call.

        Args:
            prompt_id: PTM prompt ID (e.g. ``"my_team.summarizer"``).
            provider_ids: Provider profiles to evaluate against.
            inject_vars: Variables merged into every test case's ``vars`` dict.
            extra_tests: Additional test cases appended to the prompt's stored tests.
            visibility_scope: Run visibility (``org_visible``, ``private_only``,
                ``admins_can_view_all``).
            label: Optional label for the run (defaults to ``prompt_id``).
        """
        detail = self.get_prompt(prompt_id)
        test_data = self.get_prompt_tests(prompt_id)

        prompt_text = detail.get("prompt_text", "")
        tests = list(test_data.get("promptfoo_tests") or test_data.get("tests") or [])
        deepeval_metrics = test_data.get("deepeval_metrics", [])
        judge_profile = test_data.get("judge_profile") or ""

        if inject_vars:
            for tc in tests:
                vars_dict = tc.get("vars", {})
                vars_dict.update(inject_vars)
                tc["vars"] = vars_dict

        if extra_tests:
            tests.extend(extra_tests)

        if not tests:
            raise PTMError(f"Prompt {prompt_id} has no test cases and no extra_tests provided")

        payload: dict[str, Any] = {
            "label": label or prompt_id,
            "prompt_text": prompt_text,
            "tests": tests,
            "provider_profiles": provider_ids,
            "visibility_scope": visibility_scope,
            "include_security_preset": False,
            "cost_threshold": 1.0,
            "latency_threshold_ms": 30000,
        }
        if deepeval_metrics:
            payload["additional_metrics"] = deepeval_metrics
        if judge_profile:
            payload["judge_profile"] = judge_profile

        return self.run_manual_eval(payload)

    # ── runs ──────────────────────────────────────────────────────────────────

    def get_run(self, run_key: str) -> dict:
        """Return current status of a run."""
        data = self._get(f"/api/v1/runs/{run_key}")
        # Normalise score fields from providers array if not at root
        providers = data.get("providers") or []
        if providers and data.get("score") is None:
            pct = providers[0].get("final_success_percentage")
            data["score"] = round(pct / 100, 4) if pct is not None else None
            data["passed_tests"] = providers[0].get("passed_assertions")
            data["total_tests"] = providers[0].get("total_assertions")
        return data

    def wait_for_run(
        self,
        run_key: str,
        timeout: int = 300,
        poll_interval: int = 5,
    ) -> dict:
        """Block until a run reaches a terminal state. Returns the final status dict."""
        elapsed = 0
        while True:
            status = self.get_run(run_key)
            if status.get("status") in TERMINAL_STATES:
                return status
            if elapsed >= timeout:
                raise PTMTimeoutError(
                    f"Run {run_key} did not complete within {timeout}s "
                    f"(last status: {status.get('status')})"
                )
            time.sleep(poll_interval)
            elapsed += poll_interval

    def run_report(self, run_key: str, *, format: str = "html") -> str:
        """Return the eval report for a completed run (default: HTML)."""
        resp = requests.get(
            f"{self._base}/api/v1/runs/{run_key}/report",
            headers=self._headers,
            params={"format": format},
            timeout=self._timeout,
        )
        if resp.status_code >= 400:
            raise PTMError(f"run_report failed: {resp.status_code}", resp.status_code)
        ct = resp.headers.get("content-type", "")
        if "application/json" in ct:
            body = resp.json()
            return body.get("html") or body.get("content") or str(body)
        return resp.text
