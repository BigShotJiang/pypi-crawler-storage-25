"""PTM client error types."""

from __future__ import annotations


class PTMError(Exception):
    """Raised when a PTM API call fails."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class PTMTimeoutError(PTMError):
    """Raised when wait_for_run exceeds the timeout."""
