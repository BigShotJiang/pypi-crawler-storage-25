from pydantic import BaseModel, ConfigDict


class FrozenModel(BaseModel):
    """BaseModel with `frozen=True` semantics: immutable after construction, with value-based equality and hashing."""

    model_config = ConfigDict(frozen=True)
