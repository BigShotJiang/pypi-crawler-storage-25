from __future__ import annotations

from enum import IntEnum
from importlib import import_module
from importlib.util import find_spec
from typing import Final, Literal, NamedTuple

type _BumpType = Literal["major", "minor", "patch"]
_VALID_BUMP_TYPES: Final[tuple[_BumpType, ...]] = ("major", "minor", "patch")
_NULL_VER: Final = "0.0.0"
_NULL_TUP: Final = (0, 0, 0)
_ALL_PARTS: Final = 3


PACKAGE_NAME: Literal["fsm-cub"] = "fsm-cub"
PROJECT_NAME: Literal["fsm_cub"] = "fsm_cub"
PROJECT_NAME_UPPER: Literal["FSM_CUB"] = "FSM_CUB"
ENV_VARIABLE: Literal["FSM_CUB_ENV"] = "FSM_CUB_ENV"


class ExitCode(IntEnum):  # pragma: no cover
    """An enumeration of common exit codes used in shell commands."""

    SUCCESS = 0
    """An exit code indicating success."""
    FAILURE = 1
    """An exit code indicating a general error."""


class VersionParts(IntEnum):  # pragma: no cover
    """Enumeration for version parts."""

    MAJOR = 0
    MINOR = 1
    PATCH = 2


class _Version(NamedTuple):
    """Model to represent a version string."""

    major: int
    minor: int = 0
    patch: int = 0

    def new_version(self, bump_type: str) -> _Version:
        """Return a new version string based on the bump type."""
        bump_part: VersionParts = VersionParts[bump_type.upper()]
        match bump_part:
            case VersionParts.MAJOR:
                return _Version(major=self.major + 1, minor=0, patch=0)
            case VersionParts.MINOR:
                return _Version(major=self.major, minor=self.minor + 1, patch=0)
            case VersionParts.PATCH:
                return _Version(major=self.major, minor=self.minor, patch=self.patch + 1)
            case _:
                raise ValueError(f"Invalid bump type: {bump_type}")

    @classmethod
    def from_string(cls, version_str: str) -> _Version:
        """Create a Version instance from a version string."""
        parts: list[str] = version_str.split(".")
        default: list[int] = list(_NULL_TUP)
        for i in range(min(len(parts), _ALL_PARTS)):
            default[i] = int(parts[i])
        return cls(*default)

    @classmethod
    def default(cls) -> _Version:
        """Return the default version (0.0.0)."""
        return cls(major=0, minor=0, patch=0)

    def __repr__(self) -> str:
        """Return a string representation of the Version instance."""
        return f"{self.major}.{self.minor}.{self.patch}"

    def __str__(self) -> str:
        """Return a string representation of the Version instance."""
        return self.__repr__()


def _get_version(dist: str) -> str:  # pragma: no cover
    """Get version of the given distribution or the current package.

    Parameters:
        dist: A distribution name.

    Returns:
        A version number.
    """
    from importlib.metadata import PackageNotFoundError, version

    try:
        return version(dist)
    except PackageNotFoundError:
        return "0.0.0"


def _get_description(dist: str) -> str:  # pragma: no cover
    """Get description of the given distribution or the current package.

    Parameters:
        dist: A distribution name.

    Returns:
        A description string.
    """
    from importlib.metadata import PackageNotFoundError, distribution

    try:
        return distribution(dist).metadata.get("summary", "No description available.")
    except PackageNotFoundError:
        return "No description available."


class _Package(NamedTuple):
    """Model to represent package information."""

    name: str
    """Package name."""
    version: str = "0.0.0"
    """Package version."""
    version_tuple: _Version = _Version.default()
    """Package version as a tuple."""
    description: str = "No description available."
    """Package description."""

    def __str__(self) -> str:
        """String representation of the package information."""
        return f"{self.name} v{self.version}: {self.description}"

    @classmethod
    def new(cls, name: str) -> _Package:
        """Create a new Package instance with the given name."""
        version: str = _get_version(name)
        version_tuple: _Version = _Version.from_string(version)
        description: str = _get_description(name)
        return cls(name=name, version=version, version_tuple=version_tuple, description=description)

    @classmethod
    def package_info(cls, name: str) -> _Package:  # pragma: no cover
        """Get a string representation of the package information."""
        if find_spec(f"{PROJECT_NAME}._internal._version"):
            mod = import_module(f"{PROJECT_NAME}._internal._version")
            _ver: str = getattr(mod, "__version__", _NULL_VER)
            _ver_tuple: tuple[int, int, int] = getattr(mod, "__version_tuple__", _NULL_TUP)
        else:
            _ver = _NULL_VER
            _ver_tuple = _NULL_TUP
        v: str = _ver if _ver != _NULL_VER else _get_version(name)
        version_tuple: _Version = _Version(*_ver_tuple) if _ver_tuple != _NULL_TUP else _Version.from_string(v)
        description: str = _get_description(name)
        return cls(name=name, version=v, version_tuple=version_tuple, description=description)


PACKAGE: Final[_Package] = _Package.package_info(name=PACKAGE_NAME)


class _ProjectMetadata(NamedTuple):  # pragma: no cover
    """Metadata about the current project/package."""

    version: str = PACKAGE.version
    version_tuple: _Version = PACKAGE.version_tuple
    description: str = PACKAGE.description
    full_version: str = f"{PACKAGE_NAME} v{PACKAGE.version}"
    name: Literal["fsm-cub"] = PACKAGE_NAME
    project_name: Literal["fsm_cub"] = PROJECT_NAME
    name_upper: Literal["FSM_CUB"] = PROJECT_NAME_UPPER
    env_variable: Literal["FSM_CUB_ENV"] = ENV_VARIABLE

    def __str__(self) -> str:
        """String representation of the project metadata."""
        return str(PACKAGE)


METADATA = _ProjectMetadata()


__all__ = ["METADATA"]

# ruff: noqa: PLC0415
