from __future__ import annotations

import sys
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from argparse import ArgumentParser, Namespace

    from .info import ExitCode


def main(args: list[str] | None = None) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `fsm_cub` or `python -m fsm_cub`.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    from ._cmds import get_parser  # pyright: ignore[reportMissingImports]

    if args is None:
        args = sys.argv[1:]

    parser: ArgumentParser = get_parser()
    parsed: Namespace = parser.parse_args(args)
    try:
        return parsed.func(parsed)
    except Exception:
        from .info import ExitCode

        return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

# ruff: noqa: PLC0415
