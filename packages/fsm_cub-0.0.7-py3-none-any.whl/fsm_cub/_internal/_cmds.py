from __future__ import annotations

from argparse import ArgumentParser, Namespace, _SubParsersAction
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .info import ExitCode, _BumpType


def RaiseSystemExit(code: ExitCode) -> ExitCode:  # noqa: N802
    """Helper to raise SystemExit with a specific code from a CLI command handler."""
    raise SystemExit(code.value)


def get_version(args: Namespace) -> ExitCode:
    """CLI command to get the version of the package."""
    from .info import METADATA, ExitCode

    print(METADATA.full_version) if args.name else print(METADATA.version)
    return RaiseSystemExit(ExitCode.SUCCESS)


def bump_version(args: Namespace) -> ExitCode:
    """Bump the version of the current package."""
    from .info import _NULL_TUP, _VALID_BUMP_TYPES as VALIDS, METADATA, ExitCode, _Version

    b: _BumpType = args.bump_type
    v: _Version = METADATA.version_tuple
    if b not in VALIDS:
        print(f"Invalid argument '{b}'. Use one of: {', '.join(VALIDS)}.")
        return RaiseSystemExit(ExitCode.FAILURE)

    if v == _NULL_TUP:
        print("Current version is 0.0.0, cannot bump version.")
        return RaiseSystemExit(ExitCode.FAILURE)
    try:
        new_version: _Version = v.new_version(b)
        print(str(new_version))
        return RaiseSystemExit(ExitCode.SUCCESS)
    except ValueError:
        print(f"Invalid version tuple: {v}")
        return RaiseSystemExit(ExitCode.FAILURE)


def debug_info(args: Namespace) -> ExitCode:
    """CLI command to print debug information."""
    from .debug import _print_debug_info
    from .info import ExitCode

    _print_debug_info(no_color=args.no_color)
    return RaiseSystemExit(ExitCode.SUCCESS)


def get_parser() -> ArgumentParser:
    """Build the argument parser with handlers wired via set_defaults(func=...)."""
    from .info import _VALID_BUMP_TYPES as VALIDS

    parser = ArgumentParser(description="fsm-cub CLI")
    subparsers: _SubParsersAction[ArgumentParser] = parser.add_subparsers(dest="command", required=True)

    version: ArgumentParser = subparsers.add_parser("version", help="Get the version of the package.")
    version.add_argument("--name", "-n", action="store_true", help="Print only the version name.")
    version.set_defaults(func=get_version)

    bump: ArgumentParser = subparsers.add_parser("bump", help="Bump the version of the package.")
    bump.add_argument("bump_type", type=str, choices=VALIDS, help="Type of version bump (major, minor, patch).")
    bump.set_defaults(func=bump_version)

    debug: ArgumentParser = subparsers.add_parser("debug", help="Print debug information.")
    debug.add_argument("--no-color", "-nc", action="store_true", help="Disable colored output.")
    debug.set_defaults(func=debug_info)

    return parser


# ruff: noqa: PLC0415
