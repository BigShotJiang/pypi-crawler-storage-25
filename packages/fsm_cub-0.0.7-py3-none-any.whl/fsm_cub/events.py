"""Typed event bus for cross-system communication.

A `Topic[T]` is a typed publish/subscribe channel — publishers `emit`, many
subscribers receive, delivery is in registration order.  Port of
`ecs_bear::Topic<Args...>`, adapted to Python.

See the project README and `examples/` for runnable usage.

Design notes (the *why* — not in the README because it's library-internal):
- Events should be plain dataclasses (or Pydantic models if they need to
  serialize).  The `Topic` itself doesn't care what T is beyond "subscribers
  want to receive it."
- A subscriber returning `False` does NOT veto delivery to others — by design.
  Want vetos?  Add a `vetoed: bool` field to your event type and let
  subscribers mutate it.  Keeps the bus dumb; pushes semantics into the typed
  payload.
- Topics are intentionally NOT global.  Construct and pass them around (or
  stash them in a `World.bus: dict[type, Topic]`).  Keeps tests and
  multi-world setups clean.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

from fsm_cub._strict import is_strict


class Topic[T]:
    """A typed publish/subscribe channel.  Multiple subscribers per topic.

    Type parameter T is the event payload type.  Pyright will type-check
    `emit` calls and subscriber signatures; runtime makes no enforcement.
    """

    __slots__ = ("_name", "_subscribers")

    def __init__(self, name: str = "") -> None:
        """Construct an empty topic.  `name` is purely cosmetic (for repr / debug)."""
        self._name: str = name or self.__class__.__name__
        self._subscribers: list[Callable[[T], None]] = []

    def subscribe(self, callback: Callable[[T], None]) -> Callable[[T], None]:
        """Register `callback` to receive every emitted event.  Returns the callback so this works as a decorator."""
        self._subscribers.append(callback)
        return callback

    def unsubscribe(self, callback: Callable[[T], None]) -> bool:
        """Remove `callback` from the subscriber list.  Returns True if it was found, False otherwise."""
        try:
            self._subscribers.remove(callback)
        except ValueError:
            return False
        return True

    def emit(self, event: T) -> None:
        """Deliver `event` to every subscriber, in registration order.

        Subscriber exceptions propagate out of `emit` and abort delivery to
        any remaining subscribers — keep handlers exception-safe, or wrap
        emit in a try/except at the call site if you want fault-tolerance.
        """
        for cb in self._subscribers:
            cb(event)

    def clear(self) -> None:
        """Remove every subscriber.  Useful for test teardown."""
        self._subscribers.clear()

    def __len__(self) -> int:
        """Number of currently-registered subscribers."""
        return len(self._subscribers)

    def __bool__(self) -> bool:
        """A topic is truthy if it has at least one subscriber."""
        return bool(self._subscribers)

    def __repr__(self) -> str:
        """Show the topic name and subscriber count for easy debugging."""
        return f"Topic({self._name!r}, subscribers={len(self._subscribers)})"


class Bus:
    """A registry of `Topic`s keyed by event type.

    Convenient when an author wants ONE bus per game and lets the event class
    pick the topic.  Equivalent to a `dict[type, Topic[T]]` with type-safe
    helpers.

    Usage::

        bus = Bus()


        @bus.on(DoorOpened)
        def log_it(event: DoorOpened) -> None: ...


        bus.emit(DoorOpened(door_id=7, opened_by="hedgie"))
    """

    __slots__ = ("_topics",)

    def __init__(self) -> None:
        """Construct an empty bus.  Topics are created lazily on first subscribe/emit."""
        self._topics: dict[type, Topic[Any]] = {}

    def topic[T](self, event_type: type[T]) -> Topic[T]:
        """Get (or lazily create) the topic for `event_type`."""
        existing: Topic[Any] | None = self._topics.get(event_type)
        if existing is None:
            existing = Topic(name=event_type.__name__)
            self._topics[event_type] = existing
        return existing

    def on[T](self, event_type: type[T]) -> Callable[[Callable[[T], None]], Callable[[T], None]]:
        """Decorator: `@bus.on(DoorOpened)` registers the function as a subscriber."""

        def _wrap(callback: Callable[[T], None]) -> Callable[[T], None]:
            self.topic(event_type).subscribe(callback)
            return callback

        return _wrap

    def emit[T](self, event: T) -> None:  # type: ignore[override]
        """Deliver `event` to every subscriber of its type's topic.

        If no topic exists yet for this event's type and STRICT is True,
        raises KeyError.  Otherwise silently no-ops (no subscribers to call).
        """
        event_type: type = type(event)
        topic: Topic[Any] | None = self._topics.get(event_type)
        if topic is None:
            if is_strict():
                raise KeyError(f"no topic registered for event type {event_type.__name__}")
            return
        topic.emit(event)

    def clear(self) -> None:
        """Drop every topic and every subscriber.  Test-teardown helper."""
        self._topics.clear()

    def __repr__(self) -> str:
        """Show the bus's registered topics for debugging."""
        return f"Bus(topics={list(self._topics.keys())})"
