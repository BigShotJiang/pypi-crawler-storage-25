"""Shared strict-mode toggle for the fsm_cub core.

Strict mode controls whether dev-mode mistakes (invalid FSM transitions,
unknown event topics, etc.) raise exceptions or silently no-op.

  - **Lenient (default)**: subsystems return False / silently fail.
  - **Strict**: every subsystem raises a descriptive exception.

Single source of truth: `set_strict(True)` here applies everywhere.
"""

from __future__ import annotations

from os import getenv
from typing import Final

TRUTHY_STRINGS: Final[frozenset[str]] = frozenset(("1", "true", "yes", "on"))


def env_bool(key: str, default: bool = False) -> bool:
    """Get a boolean environment variable."""
    val: str | None = getenv(key)
    if val is None:
        return default
    return val.lower() in TRUTHY_STRINGS


_strict: bool = env_bool("FSM_CUB_STRICT", default=False)


def set_strict(value: bool) -> None:
    """Toggle strict mode for the entire fsm_cub core.  Affects all subsystems at once."""
    global _strict  # noqa: PLW0603
    _strict = value


def is_strict() -> bool:
    """Check whether strict mode is currently enabled."""
    return _strict
