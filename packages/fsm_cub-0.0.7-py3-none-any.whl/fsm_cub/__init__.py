"""fsm-cub package.

Tiny, type-safe FSMs in modern Python. Just states, transitions, and on_enter/on_exit hooks.
"""

from fsm_cub._internal.cli import main
from fsm_cub._internal.info import METADATA
from fsm_cub._strict import is_strict, set_strict
from fsm_cub.events import Bus, Topic
from fsm_cub.fsm import FSM, EventBoundFSM, StateChanged

__version__: str = METADATA.version

__all__: list[str] = [
    "FSM",
    "METADATA",
    "Bus",
    "EventBoundFSM",
    "StateChanged",
    "Topic",
    "__version__",
    "is_strict",
    "main",
    "set_strict",
]
