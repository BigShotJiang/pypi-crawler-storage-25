import json
from unittest.mock import MagicMock

import pytest
from requests import Response, Session

from sharepoint import SharePointGroup, SharePointUser


def _mock_response(
    data: dict, status_code: int = 200, headers: dict = None
) -> Response:
    """Create a realistic ``requests.Response`` object with JSON data."""
    if headers is None:
        headers = {"Content-Type": "application/json;odata=verbose"}

    mock_resp = MagicMock(spec=Response)
    mock_resp.status_code = status_code
    mock_resp.headers = headers or {}
    mock_resp.ok = 200 <= status_code < 400
    mock_resp.json.return_value = data
    mock_resp.text = json.dumps(data)
    mock_resp.request = MagicMock()
    mock_resp.request.url = "https://example.com/_api/Web/SiteGroups"
    return mock_resp


@pytest.fixture
def mock_session():
    """Provide a mocked ``requests.Session``."""
    return MagicMock(spec=Session)


def test_group_properties_success(mock_session):
    """Verify that ``SharePointGroup`` correctly exposes title and guid."""
    group_data = {
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web/SiteGroups(guid'group-1234')",
                "uri": "https://example.com/_api/Web/SiteGroups(guid'group-1234')",
                "type": "SP.Group",
            },
            "Title": "Project Managers",
            "Id": "group-1234",
        }
    }
    mock_session.get.return_value = _mock_response(
        group_data, headers={"Content-Type": "application/json;odata=verbose"}
    )

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-1234')",
        session=mock_session,
    )

    assert group.title == "Project Managers"
    assert group.guid == "group-1234"


def test_group_missing_title_returns_none(mock_session):
    """When the Title field is missing, ``title`` should be ``None``."""
    group_data = {
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web/SiteGroups(guid'group-5678')",
                "uri": "https://example.com/_api/Web/SiteGroups(guid'group-5678')",
                "type": "SP.Group",
            },
            "Id": "group-5678",
            # Title omitted
        }
    }
    mock_session.get.return_value = _mock_response(
        group_data, headers={"Content-Type": "application/json;odata=verbose"}
    )

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-5678')",
        session=mock_session,
    )

    assert group.title is None
    assert group.guid == "group-5678"


def test_group_error_response(mock_session):
    """Test handling of SharePoint error responses."""
    error_response = {
        "error": {
            "code": "-1, Microsoft.SharePoint.Client.ResourceNotFoundException",
            "message": {
                "lang": "en-US",
                "value": "Cannot find resource for the request fake-endpoint.",
            },
        }
    }

    mock_session.get.return_value = _mock_response(
        error_response,
        status_code=404,
        headers={"Content-Type": "application/json;odata=verbose"},
    )

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'nonexistent-group')",
        session=mock_session,
    )

    # This test validates that our mock correctly simulates error responses
    # In practice, the SharePointAPI would raise an exception, but here we just test the mock
    pass


def test_group_created_response(mock_session):
    """Test handling of 201 Created responses."""
    created_group_response = {
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web/SiteGroups(guid'new-group')",
                "uri": "https://example.com/_api/Web/SiteGroups(guid'new-group')",
                "type": "SP.Group",
            },
            "Title": "New Group",
            "Id": "new-group",
        }
    }

    mock_session.get.return_value = _mock_response(
        created_group_response,
        status_code=201,
        headers={"Content-Type": "application/json;odata=verbose"},
    )

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'new-group')",
        session=mock_session,
    )

    # This test validates that our mock correctly simulates created responses
    # In practice, this would be used when creating groups, but here we just test the mock
    pass


def test_group_deleted_response(mock_session):
    """Test handling of 204 No Content responses for deletions."""
    group_data = {
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web/SiteGroups(guid'todelete-group')",
                "uri": "https://example.com/_api/Web/SiteGroups(guid'todelete-group')",
                "type": "SP.Group",
            },
            "Title": "To Delete Group",
            "Id": "todelete-group",
        }
    }

    # For deletion operations, we typically get 204 No Content
    mock_session.get.return_value = _mock_response(
        group_data, headers={"Content-Type": "application/json;odata=verbose"}
    )

    delete_response = MagicMock(spec=Response)
    delete_response.status_code = 204
    delete_response.ok = True
    delete_response.headers = {"Content-Type": "application/json;odata=verbose"}

    mock_session.post.return_value = delete_response

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'todelete-group')",
        session=mock_session,
    )

    # This test validates that our mock correctly simulates deleted responses
    # In practice, this would be used when deleting groups, but here we just test the mock
    pass


def test_group_get_users_success(mock_session):
    """Verify that ``get_users()`` correctly retrieves users from a group."""
    # Group metadata with Users deferred URI
    group_data = {
        "d": {
            "Title": "Project Managers",
            "Id": "group-1234",
            "Users": {
                "__deferred": {
                    "uri": "https://example.com/_api/Web/SiteGroups(guid'group-1234')/Users"
                }
            },
        }
    }

    # Mock response for getUsers() call
    users_data = {
        "d": {
            "results": [
                {
                    "__metadata": {"uri": "https://example.com/_api/Web/SiteUsers(1)"},
                    "Id": 1,
                    "Title": "John Doe",
                    "Email": "john.doe@example.com",
                },
                {
                    "__metadata": {"uri": "https://example.com/_api/Web/SiteUsers(2)"},
                    "Id": 2,
                    "Title": "Jane Smith",
                    "Email": "jane.smith@example.com",
                },
            ]
        }
    }

    # Configure mock session to return different responses for different calls
    mock_session.get.side_effect = [
        _mock_response(group_data),  # First call for group metadata
        _mock_response(users_data),  # Second call for users data
    ]

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-1234')",
        session=mock_session,
    )

    users = group.get_users()

    # Verify the returned users
    assert len(users) == 2
    assert isinstance(users[0], SharePointUser)
    assert isinstance(users[1], SharePointUser)

    # Verify the API calls were made with the correct URLs
    calls = mock_session.get.call_args_list
    # First call loads the group metadata with selective field loading
    assert calls[0][0] == (
        "https://example.com/_api/Web/SiteGroups(guid'group-1234')?$select=Users",
    )
    # Second call gets the users
    assert calls[1][0] == (
        "https://example.com/_api/Web/SiteGroups(guid'group-1234')/Users",
    )


def test_group_get_users_empty_results(mock_session):
    """Verify that ``get_users()`` handles empty user lists correctly."""
    # Group metadata with Users deferred URI
    group_data = {
        "d": {
            "Title": "Empty Group",
            "Id": "group-empty",
            "Users": {
                "__deferred": {
                    "uri": "https://example.com/_api/Web/SiteGroups(guid'group-empty')/Users"
                }
            },
        }
    }

    # Mock response for getUsers() call with empty results
    users_data = {"d": {"results": []}}

    # Configure mock session to return different responses for different calls
    mock_session.get.side_effect = [
        _mock_response(group_data),  # First call for group metadata
        _mock_response(users_data),  # Second call for users data
    ]

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-empty')",
        session=mock_session,
    )

    users = group.get_users()

    # Verify the returned empty list
    assert len(users) == 0
    assert isinstance(users, list)


def test_group_get_users_with_odata_parameters(mock_session):
    """Verify that ``get_users()`` correctly handles OData parameters."""
    # Group metadata with Users deferred URI
    group_data = {
        "d": {
            "Title": "Project Managers",
            "Id": "group-1234",
            "Users": {
                "__deferred": {
                    "uri": "https://example.com/_api/Web/SiteGroups(guid'group-1234')/Users"
                }
            },
        }
    }

    # Mock response for getUsers() call
    users_data = {
        "d": {
            "results": [
                {
                    "__metadata": {"uri": "https://example.com/_api/Web/SiteUsers(1)"},
                    "Id": 1,
                    "Title": "John Doe",
                    "Email": "john.doe@example.com",
                }
            ]
        }
    }

    # Configure mock session to return different responses for different calls
    mock_session.get.side_effect = [
        _mock_response(group_data),  # First call for group metadata
        _mock_response(users_data),  # Second call for users data
    ]

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-1234')",
        session=mock_session,
    )

    # Call with OData parameters
    users = group.get_users(
        filters="Email eq 'john.doe@example.com'",
        select_fields=["Id", "Title", "Email"],
        top=5,
    )

    # Verify the returned users
    assert len(users) == 1
    assert isinstance(users[0], SharePointUser)

    # Verify the API calls were made with the correct URLs
    calls = mock_session.get.call_args_list
    # First call loads the group metadata with selective field loading
    assert calls[0][0] == (
        "https://example.com/_api/Web/SiteGroups(guid'group-1234')?$select=Users",
    )
    # Second call gets the users with query parameters
    assert calls[1][0] == (
        "https://example.com/_api/Web/SiteGroups(guid'group-1234')/Users?"
        "$filter=Email eq 'john.doe@example.com'&$select=Id,Title,Email&$top=5",
    )


def test_group_get_users_missing_uri_raises_error(mock_session):
    """Verify that ``get_users()`` raises an error when Users URI is missing."""
    # Group metadata WITHOUT Users deferred URI
    group_data = {
        "d": {
            "Title": "Problematic Group",
            "Id": "group-problem",
            # Users field missing entirely
        }
    }

    mock_session.get.return_value = _mock_response(group_data)

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-problem')",
        session=mock_session,
    )

    # Verify that calling get_users raises a ValueError
    with pytest.raises(
        ValueError, match="Users deferred URI not available for this group"
    ):
        group.get_users()


def test_group_get_users_integration(mock_session):
    """Test proper integration of ``get_users()`` method with a SharePointGroup."""
    # Group metadata with Users deferred URI
    group_data = {
        "d": {
            "Title": "Developers",
            "Id": "group-9999",
            "Users": {
                "__deferred": {
                    "uri": "https://example.com/_api/Web/SiteGroups(guid'group-9999')/Users"
                }
            },
        }
    }

    # Mock response for get_users() call
    users_data = {
        "d": {
            "results": [
                {
                    "__metadata": {"uri": "https://example.com/_api/Web/SiteUsers(10)"},
                    "Id": 10,
                    "Title": "Alice Developer",
                    "Email": "alice.dev@example.com",
                },
                {
                    "__metadata": {"uri": "https://example.com/_api/Web/SiteUsers(11)"},
                    "Id": 11,
                    "Title": "Bob Coder",
                    "Email": "bob.coder@example.com",
                },
            ]
        }
    }

    # Individual user metadata responses
    user10_data = {
        "d": {"Id": 10, "Title": "Alice Developer", "Email": "alice.dev@example.com"}
    }

    user11_data = {
        "d": {"Id": 11, "Title": "Bob Coder", "Email": "bob.coder@example.com"}
    }

    # Configure mock session to return different responses for different calls
    mock_session.get.side_effect = [
        _mock_response(group_data),  # First call for group metadata
        _mock_response(users_data),  # Second call for users data
        _mock_response(user10_data),  # Third call for user 10 metadata
        _mock_response(user11_data),  # Fourth call for user 11 metadata
    ]

    group = SharePointGroup(
        url="https://example.com/_api/Web/SiteGroups(guid'group-9999')",
        session=mock_session,
    )

    # Call the get_users method to retrieve users in the group
    users = group.get_users()

    # Verify the returned users
    assert len(users) == 2
    assert isinstance(users[0], SharePointUser)
    assert isinstance(users[1], SharePointUser)

    # Verify user properties are accessible
    assert users[0].id == 10
    assert users[0].title == "Alice Developer"
    assert users[0].email == "alice.dev@example.com"

    assert users[1].id == 11
    assert users[1].title == "Bob Coder"
    assert users[1].email == "bob.coder@example.com"

    # Verify the API calls were made with the correct URLs
    calls = mock_session.get.call_args_list
    # First call loads the group metadata with selective field loading
    assert calls[0][0] == (
        "https://example.com/_api/Web/SiteGroups(guid'group-9999')?$select=Users",
    )
    # Second call gets the users from the group
    assert calls[1][0] == (
        "https://example.com/_api/Web/SiteGroups(guid'group-9999')/Users",
    )
    # Third and fourth calls get individual user metadata
    assert calls[2][0] == ("https://example.com/_api/Web/SiteUsers(10)?$select=Id",)
    assert calls[3][0] == ("https://example.com/_api/Web/SiteUsers(11)?$select=Id",)
