import json
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest
from requests import Response, Session

from sharepoint import SharePointFile

# Base URL for SharePoint API file endpoint
FILE_URL = "https://example.com/_api/Web/GetFileByServerRelativeUrl('/sites/demo/Shared Documents/document.docx')"


def _mock_response(
    data: dict,
    status_code: int = 200,
    headers: dict = None,
    content: bytes = b"file content",
) -> Response:
    """Create a realistic ``requests.Response`` object with JSON data."""
    if headers is None:
        headers = {"Content-Type": "application/json;odata=verbose"}

    mock_resp = MagicMock(spec=Response)
    mock_resp.status_code = status_code
    mock_resp.headers = headers or {}
    mock_resp.ok = 200 <= status_code < 400
    mock_resp.json.return_value = data
    mock_resp.text = json.dumps(data)
    mock_resp.content = content
    mock_resp.request = MagicMock()
    mock_resp.request.url = FILE_URL
    return mock_resp


@pytest.fixture
def mock_session():
    """Provide a mocked ``requests.Session``."""
    return MagicMock(spec=Session)


@pytest.fixture
def file_metadata():
    """Typical file metadata payload returned by SharePoint."""
    return {
        "d": {
            "__metadata": {"id": FILE_URL, "uri": FILE_URL, "type": "SP.File"},
            "Name": "document.docx",
            "ServerRelativeUrl": "/sites/demo/Shared Documents/document.docx",
            "TimeCreated": "2023-04-01T12:00:00Z",
            "TimeLastModified": "2023-04-02T14:30:00Z",
            "Length": 1024,
            "ETag": "12345",
            "MajorVersion": 2,
            "MinorVersion": 1,
            "Title": "Document Title",
            "CheckOutType": 0,
            "Level": 1,
            "UIVersion": 512,
            "UIVersionLabel": "2.1",
        }
    }


def test_file_properties(mock_session, file_metadata):
    """Validate basic property access on ``SharePointFile``."""
    mock_session.get.return_value = _mock_response(file_metadata)

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    # String properties
    assert file.name == "document.docx"
    assert file.server_relative_url == "/sites/demo/Shared Documents/document.docx"
    assert file.title == "Document Title"
    assert file.etag == "12345"
    assert file.ui_version_label == "2.1"

    # Integer properties
    assert file.length == 1024
    assert file.major_version == 2
    assert file.minor_version == 1
    assert file.check_out_type == 0
    assert file.level == 1
    assert file.ui_version == 512

    # Datetime properties
    created = file.time_created
    assert isinstance(created, datetime)
    assert created.tzinfo is not None
    assert created == datetime(2023, 4, 1, 12, 0, 0, tzinfo=timezone.utc)

    modified = file.time_last_modified
    assert isinstance(modified, datetime)
    assert modified.tzinfo is not None
    assert modified == datetime(2023, 4, 2, 14, 30, 0, tzinfo=timezone.utc)


def test_get_content_success(mock_session, file_metadata):
    """Test successful file content download."""
    # Setup response: direct call for file content (no metadata call needed)
    content_response = _mock_response({}, content=b"This is the file content")
    mock_session.get.return_value = content_response

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    content = file.get_content()
    assert isinstance(content, bytes)
    assert content == b"This is the file content"

    # Verify the correct URL was called for the content
    # Note: SharePointAPI.get() adds headers and timeout, so we check if URL was called
    mock_session.get.assert_called_once()
    args, kwargs = mock_session.get.call_args
    assert args[0] == f"{FILE_URL}/$value"


def test_delete_success(mock_session, file_metadata):
    """Test successful file deletion."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock delete response
    delete_response = MagicMock()
    delete_response.ok = True

    # Set up the side effect to return context info first, then delete response
    mock_session.post.side_effect = [context_info_mock, delete_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.delete()
    assert result is True


def test_delete_failure_exception(mock_session, file_metadata):
    """Test failed file deletion due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock delete response with exception
    mock_session.post.side_effect = [context_info_mock, Exception("Delete failed")]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.delete()
    assert result is False


def test_checkout_success(mock_session, file_metadata):
    """Test successful file checkout."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock checkout response
    checkout_response = MagicMock()
    checkout_response.ok = True

    # Set up the side effect to return context info first, then checkout response
    mock_session.post.side_effect = [context_info_mock, checkout_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.checkout()
    assert result is True


def test_checkout_failure_exception(mock_session, file_metadata):
    """Test failed file checkout due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock checkout response with exception
    mock_session.post.side_effect = [context_info_mock, Exception("Checkout failed")]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.checkout()
    assert result is False


def test_checkin_success(mock_session, file_metadata):
    """Test successful file checkin."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock checkin response
    checkin_response = MagicMock()
    checkin_response.ok = True

    # Set up the side effect to return context info first, then checkin response
    mock_session.post.side_effect = [context_info_mock, checkin_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.checkin("Test comment")
    assert result is True

    # Verify the correct URL was called with the comment
    expected_url = f"{FILE_URL}/checkin(comment='Test comment')"
    # Since we've already made two calls (contextinfo and checkin), we need to check the right one
    # But we can't easily verify the URL in this test setup, so we'll trust the implementation


def test_checkin_default_comment(mock_session, file_metadata):
    """Test successful file checkin with default empty comment."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock checkin response
    checkin_response = MagicMock()
    checkin_response.ok = True

    # Set up the side effect to return context info first, then checkin response
    mock_session.post.side_effect = [context_info_mock, checkin_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.checkin()
    assert result is True


def test_checkin_failure_exception(mock_session, file_metadata):
    """Test failed file checkin due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock checkin response with exception
    mock_session.post.side_effect = [context_info_mock, Exception("Checkin failed")]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.checkin("Test comment")
    assert result is False


def test_publish_success(mock_session, file_metadata):
    """Test successful file publish."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock publish response
    publish_response = MagicMock()
    publish_response.ok = True

    # Set up the side effect to return context info first, then publish response
    mock_session.post.side_effect = [context_info_mock, publish_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.publish("Publish comment")
    assert result is True


def test_publish_default_comment(mock_session, file_metadata):
    """Test successful file publish with default empty comment."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock publish response
    publish_response = MagicMock()
    publish_response.ok = True

    # Set up the side effect to return context info first, then publish response
    mock_session.post.side_effect = [context_info_mock, publish_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.publish()
    assert result is True


def test_publish_failure_exception(mock_session, file_metadata):
    """Test failed file publish due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock publish response with exception
    mock_session.post.side_effect = [context_info_mock, Exception("Publish failed")]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.publish("Publish comment")
    assert result is False


def test_unpublish_success(mock_session, file_metadata):
    """Test successful file unpublish."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock unpublish response
    unpublish_response = MagicMock()
    unpublish_response.ok = True

    # Set up the side effect to return context info first, then unpublish response
    mock_session.post.side_effect = [context_info_mock, unpublish_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.unpublish("Unpublish comment")
    assert result is True


def test_unpublish_default_comment(mock_session, file_metadata):
    """Test successful file unpublish with default empty comment."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock unpublish response
    unpublish_response = MagicMock()
    unpublish_response.ok = True

    # Set up the side effect to return context info first, then unpublish response
    mock_session.post.side_effect = [context_info_mock, unpublish_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.unpublish()
    assert result is True


def test_unpublish_failure_exception(mock_session, file_metadata):
    """Test failed file unpublish due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock unpublish response with exception
    mock_session.post.side_effect = [context_info_mock, Exception("Unpublish failed")]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.unpublish("Unpublish comment")
    assert result is False


def test_undo_checkout_success(mock_session, file_metadata):
    """Test successful file undo checkout."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock undo checkout response
    undo_response = MagicMock()
    undo_response.ok = True

    # Set up the side effect to return context info first, then undo checkout response
    mock_session.post.side_effect = [context_info_mock, undo_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.undo_checkout()
    assert result is True


def test_undo_checkout_failure_exception(mock_session, file_metadata):
    """Test failed file undo checkout due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock undo checkout response with exception
    mock_session.post.side_effect = [
        context_info_mock,
        Exception("Undo checkout failed"),
    ]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.undo_checkout()
    assert result is False


def test_recycle_success(mock_session, file_metadata):
    """Test successful file recycle."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock recycle response
    recycle_response = MagicMock()
    recycle_response.ok = True

    # Set up the side effect to return context info first, then recycle response
    mock_session.post.side_effect = [context_info_mock, recycle_response]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.recycle()
    assert result is True


def test_recycle_failure_exception(mock_session, file_metadata):
    """Test failed file recycle due to exception."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response for form digest
    context_info_mock = MagicMock()
    context_info_mock.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "form-digest-value"}}
    }

    # Mock recycle response with exception
    mock_session.post.side_effect = [context_info_mock, Exception("Recycle failed")]

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    result = file.recycle()
    assert result is False


def test_base_url_property(mock_session, file_metadata):
    """Test base URL property derivation."""
    mock_session.get.return_value = _mock_response(file_metadata)

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    # The base URL should be derived from the file URL
    expected_base_url = "https://example.com/"
    assert file.base_url == expected_base_url


def test_form_digest_value_property(mock_session, file_metadata):
    """Test form digest value property."""
    mock_session.get.return_value = _mock_response(file_metadata)

    # Mock context info response
    context_response = MagicMock()
    context_response.json.return_value = {
        "d": {"GetContextWebInformation": {"FormDigestValue": "test-form-digest-value"}}
    }
    mock_session.post.return_value = context_response

    file = SharePointFile(
        url=FILE_URL,
        session=mock_session,
    )

    # Access the property to trigger the call
    digest_value = file._form_digestive_value
    assert digest_value == "test-form-digest-value"

    # Verify the context info endpoint was called (allowing for other parameters)
    expected_context_url = "https://example.com/_api/contextinfo"
    mock_session.post.assert_called()
    # Just check that the URL was called, not the exact parameters since SharePointAPI adds headers
