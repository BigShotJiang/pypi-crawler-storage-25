import json
from unittest.mock import MagicMock

import pytest
from requests import Response, Session

from sharepoint.list_field import (
    BooleanField,
    ChoiceField,
    DateTimeField,
    LookupField,
    MultiChoiceField,
    NumberField,
    PersonOrGroupField,
    SharePointListField,
)
from sharepoint.list import SharePointList


# Base URLs for SharePoint API endpoints
BASE_URL = "https://example.com/_api/Web/Lists(guid'list')"
FIELDS_URL = f"{BASE_URL}/fields"


def _mock_response(
    data: dict, status_code: int = 200, headers: dict = None
) -> Response:
    """Create a realistic ``requests.Response`` object with JSON data."""
    if headers is None:
        headers = {"Content-Type": "application/json;odata=verbose"}

    mock_resp = MagicMock(spec=Response)
    mock_resp.status_code = status_code
    mock_resp.headers = headers or {}
    mock_resp.ok = 200 <= status_code < 400
    mock_resp.json.return_value = data
    mock_resp.text = json.dumps(data)
    mock_resp.request = MagicMock()
    mock_resp.request.url = BASE_URL
    return mock_resp


@pytest.fixture
def mock_session():
    """Provide a mocked ``requests.Session``."""
    return MagicMock(spec=Session)


# Test SharePointListField base class
def test_sharepoint_list_field_base_properties(mock_session):
    """Test basic properties of SharePointListField."""
    field_data = {
        "d": {
            "__metadata": {
                "id": f"{FIELDS_URL}(1)",
                "uri": f"{FIELDS_URL}(1)",
                "type": "SP.Field",
                "etag": '"1"',
            },
            "Id": "field-id-1",
            "Title": "Test Field",
            "InternalName": "TestField",
            "StaticName": "TestField",
            "TypeAsString": "Text",
            "TypeDisplayName": "Single line of text",
            "Required": True,
            "Hidden": False,
            "ReadOnlyField": False,
        }
    }
    
    mock_session.get.return_value = _mock_response(field_data)
    
    field = SharePointListField(
        url=f"{FIELDS_URL}(1)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    # Test properties
    assert field.id == "field-id-1"
    assert field.etag == '"1"'
    assert field.title == "Test Field"
    assert field.internal_name == "TestField"
    assert field.static_name == "TestField"
    assert field.type_as_string == "Text"
    assert field.type_display_name == "Single line of text"
    assert field.required is True
    assert field.hidden is False
    assert field.read_only is False


def test_sharepoint_list_field_update_and_delete(mock_session):
    """Test update_field and delete_field methods."""
    field_data = {
        "d": {
            "__metadata": {
                "uri": f"{FIELDS_URL}(1)",
            },
            "Id": "field-id-1",
            "Title": "Test Field",
        }
    }
    
    # Mock contextinfo response
    contextinfo_response = {
        "d": {
            "GetContextWebInformation": {
                "FormDigestValue": "test-digest-value",
            }
        }
    }
    
    mock_session.get.return_value = _mock_response(field_data)
    mock_session.post.side_effect = [
        _mock_response(contextinfo_response),  # For form digest
        _mock_response({"d": {}}, status_code=204),  # For update
        _mock_response(contextinfo_response),  # For form digest (delete)
        _mock_response({"d": {}}, status_code=204),  # For delete
    ]
    
    field = SharePointListField(
        url=f"{FIELDS_URL}(1)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    # Test update
    update_success = field.update_field({"Title": "Updated Field"})
    assert update_success is True
    
    # Test delete
    delete_success = field.delete_field()
    assert delete_success is True


# Test ChoiceField
def test_choice_field_properties(mock_session):
    """Test ChoiceField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(choice-field)"},
            "Id": "choice-field-id",
            "Title": "Status",
            "TypeAsString": "Choice",
            "Choices": {"results": ["Active", "Inactive", "Pending"]},
            "DefaultValue": "Active",
        }
    }
    
    field = ChoiceField(
        url=f"{FIELDS_URL}(choice-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "Choice"
    assert field.choices == ["Active", "Inactive", "Pending"]
    assert field.default_choice == "Active"


# Test LookupField
def test_lookup_field_properties(mock_session):
    """Test LookupField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(lookup-field)"},
            "Id": "lookup-field-id",
            "Title": "Project",
            "TypeAsString": "Lookup",
            "LookupList": "{a1b2c3d4-e5f6-7890-g1h2-i3j4k5l6m7n8}",
            "LookupField": "Title",
            "AllowMultipleValues": True,
        }
    }
    
    field = LookupField(
        url=f"{FIELDS_URL}(lookup-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "Lookup"
    assert field.lookup_list_id == "{a1b2c3d4-e5f6-7890-g1h2-i3j4k5l6m7n8}"
    assert field.lookup_field == "Title"
    assert field.allow_multiple_values is True


def test_lookup_field_get_lookup_list(mock_session):
    """Test LookupField.get_lookup_list method."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(lookup-field)"},
            "Id": "lookup-field-id",
            "Title": "Project",
            "TypeAsString": "Lookup",
            "LookupList": "{a1b2c3d4-e5f6-7890-g1h2-i3j4k5l6m7n8}",
            "LookupField": "Title",
        }
    }
    
    field = LookupField(
        url=f"{FIELDS_URL}(lookup-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    # Test getting lookup list
    lookup_list = field.get_lookup_list()
    assert isinstance(lookup_list, SharePointList)
    expected_url = "https://example.com/_api/web/lists(guid'a1b2c3d4-e5f6-7890-g1h2-i3j4k5l6m7n8')"
    assert lookup_list._url == expected_url


def test_lookup_field_get_lookup_list_without_id(mock_session):
    """Test LookupField.get_lookup_list raises ValueError when no lookup list ID."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(lookup-field)"},
            "Id": "lookup-field-id",
            "Title": "Project",
            "TypeAsString": "Lookup",
            # Missing LookupList property
            "LookupField": "Title",
        }
    }
    
    # Mock the API response when the field tries to fetch missing metadata
    mock_session.get.return_value = _mock_response(field_data)
    
    field = LookupField(
        url=f"{FIELDS_URL}(lookup-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    with pytest.raises(ValueError, match="Lookup field does not have a target list ID"):
        field.get_lookup_list()


# Test DateTimeField
def test_datetime_field_properties(mock_session):
    """Test DateTimeField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(datetime-field)"},
            "Id": "datetime-field-id",
            "Title": "Created Date",
            "TypeAsString": "DateTime",
            "DisplayFormat": "DateOnly",
        }
    }
    
    field = DateTimeField(
        url=f"{FIELDS_URL}(datetime-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "DateTime"
    assert field.display_format == "DateOnly"


# Test PersonOrGroupField
def test_person_or_group_field_properties(mock_session):
    """Test PersonOrGroupField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(person-field)"},
            "Id": "person-field-id",
            "Title": "Assigned To",
            "TypeAsString": "User",
            "SelectionMode": "PeopleAndGroups",
            "AllowMultipleValues": True,
        }
    }
    
    field = PersonOrGroupField(
        url=f"{FIELDS_URL}(person-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "User"
    assert field.selection_mode == "PeopleAndGroups"
    assert field.allow_multiple_values is True


# Test MultiChoiceField
def test_multi_choice_field_properties(mock_session):
    """Test MultiChoiceField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(multichoice-field)"},
            "Id": "multichoice-field-id",
            "Title": "Tags",
            "TypeAsString": "MultiChoice",
            "Choices": {"results": ["Urgent", "Important", "Review", "Archive"]},
        }
    }
    
    field = MultiChoiceField(
        url=f"{FIELDS_URL}(multichoice-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "MultiChoice"
    assert field.choices == ["Urgent", "Important", "Review", "Archive"]


# Test NumberField
def test_number_field_properties(mock_session):
    """Test NumberField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(number-field)"},
            "Id": "number-field-id",
            "Title": "Score",
            "TypeAsString": "Number",
            "Decimals": 2,
            "MinimumValue": 0.0,
            "MaximumValue": 100.0,
        }
    }
    
    field = NumberField(
        url=f"{FIELDS_URL}(number-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "Number"
    assert field.decimal_places == 2
    assert field.min_value == 0.0
    assert field.max_value == 100.0


# Test BooleanField
def test_boolean_field_properties(mock_session):
    """Test BooleanField properties."""
    field_data = {
        "d": {
            "__metadata": {"uri": f"{FIELDS_URL}(boolean-field)"},
            "Id": "boolean-field-id",
            "Title": "Is Active",
            "TypeAsString": "Boolean",
            "Customization": {
                "TrueText": "Yes",
                "FalseText": "No"
            }
        }
    }
    
    field = BooleanField(
        url=f"{FIELDS_URL}(boolean-field)",
        session=mock_session,
        metadata=field_data["d"]
    )
    
    assert field.type_as_string == "Boolean"
    assert field.true_display_name == "Yes"
    assert field.false_display_name == "No"


# Test SharePointList.get_fields() returning specialized field types
def test_get_fields_returns_specialized_field_types(mock_session):
    """Test that SharePointList.get_fields() returns correct specialized field types."""
    list_metadata = {
        "d": {
            "__metadata": {"id": BASE_URL, "uri": BASE_URL, "type": "SP.List"},
            "Title": "Tasks",
            "Id": "list-id",
            "Items": {"__deferred": {"uri": f"{BASE_URL}/items"}},
            "Fields": {"__deferred": {"uri": FIELDS_URL}},
        }
    }
    
    fields_response = {
        "d": {
            "results": [
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(1)"},
                    "Id": "1",
                    "Title": "Status",
                    "TypeAsString": "Choice",
                    "Choices": {"results": ["Active", "Inactive"]},
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(2)"},
                    "Id": "2",
                    "Title": "Project",
                    "TypeAsString": "Lookup",
                    "LookupList": "project-list-id",
                    "LookupField": "Title",
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(3)"},
                    "Id": "3",
                    "Title": "Due Date",
                    "TypeAsString": "DateTime",
                    "DisplayFormat": "DateOnly",
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(4)"},
                    "Id": "4",
                    "Title": "Assigned To",
                    "TypeAsString": "User",
                    "SelectionMode": "PeopleOnly",
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(5)"},
                    "Id": "5",
                    "Title": "Categories",
                    "TypeAsString": "MultiChoice",
                    "Choices": {"results": ["Work", "Personal"]},
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(6)"},
                    "Id": "6",
                    "Title": "Priority",
                    "TypeAsString": "Number",
                    "Decimals": 0,
                    "MinimumValue": 1,
                    "MaximumValue": 5,
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(7)"},
                    "Id": "7",
                    "Title": "Completed",
                    "TypeAsString": "Boolean",
                    "Customization": {"TrueText": "Yes", "FalseText": "No"},
                },
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(8)"},
                    "Id": "8",
                    "Title": "Description",
                    "TypeAsString": "Note",  # Generic type
                },
            ]
        }
    }
    
    mock_session.get.side_effect = [
        _mock_response(list_metadata),  # List metadata
        _mock_response(fields_response),  # Fields response
    ]
    
    sp_list = SharePointList(
        url=BASE_URL,
        session=mock_session,
    )
    
    fields = sp_list.get_fields()
    
    # Check that we got the right number of fields
    assert len(fields) == 8
    
    # Check that each field is the correct specialized type
    assert isinstance(fields[0], ChoiceField)
    assert isinstance(fields[1], LookupField)
    assert isinstance(fields[2], DateTimeField)
    assert isinstance(fields[3], PersonOrGroupField)
    assert isinstance(fields[4], MultiChoiceField)
    assert isinstance(fields[5], NumberField)
    assert isinstance(fields[6], BooleanField)
    assert isinstance(fields[7], SharePointListField)  # Generic field
    
    # Verify specific properties
    assert fields[0].title == "Status"
    assert fields[0].choices == ["Active", "Inactive"]
    
    assert fields[1].title == "Project"
    assert fields[1].lookup_list_id == "project-list-id"
    
    assert fields[2].title == "Due Date"
    assert fields[2].display_format == "DateOnly"
    
    assert fields[3].title == "Assigned To"
    assert fields[3].selection_mode == "PeopleOnly"
    
    assert fields[4].title == "Categories"
    assert fields[4].choices == ["Work", "Personal"]
    
    assert fields[5].title == "Priority"
    assert fields[5].decimal_places == 0
    assert fields[5].min_value == 1
    assert fields[5].max_value == 5
    
    assert fields[6].title == "Completed"
    assert fields[6].true_display_name == "Yes"
    assert fields[6].false_display_name == "No"
    
    assert fields[7].title == "Description"
    assert fields[7].type_as_string == "Note"


def test_get_fields_with_select_fields_parameter(mock_session):
    """Test SharePointList.get_fields() with select_fields parameter."""
    list_metadata = {
        "d": {
            "__metadata": {"id": BASE_URL, "uri": BASE_URL, "type": "SP.List"},
            "Title": "Tasks",
            "Id": "list-id",
            "Items": {"__deferred": {"uri": f"{BASE_URL}/items"}},
            "Fields": {"__deferred": {"uri": FIELDS_URL}},
        }
    }
    
    fields_response = {
        "d": {
            "results": [
                {
                    "__metadata": {"uri": f"{FIELDS_URL}(1)"},
                    "Id": "1",
                    "Title": "Status",
                    "TypeAsString": "Choice",
                }
            ]
        }
    }
    
    mock_session.get.side_effect = [
        _mock_response(list_metadata),  # List metadata
        _mock_response(fields_response),  # Fields response
    ]
    
    sp_list = SharePointList(
        url=BASE_URL,
        session=mock_session,
    )
    
    # Call get_fields with select_fields parameter
    fields = sp_list.get_fields(select_fields=["Id", "Title", "TypeAsString"])
    
    # Verify the method was called with the correct URL parameters
    called_url = mock_session.get.call_args_list[1][0][0]
    assert "$select=Id,Title,TypeAsString" in called_url
    
    # Verify we still get the right field type
    assert len(fields) == 1
    assert isinstance(fields[0], ChoiceField)
    assert fields[0].title == "Status"