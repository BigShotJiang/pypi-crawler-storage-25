import pytest
from sharepoint._odata_utils import build_query_url


class TestBuildQueryUrl:
    """Test cases for the build_query_url function."""

    def test_build_query_url_with_orderby_single_field(self):
        """Test build_query_url with a single orderby field."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(base_url, orderby_fields="Title")
        assert result == "https://example.com/_api/web/lists?$orderby=Title"

    def test_build_query_url_with_orderby_single_field_desc(self):
        """Test build_query_url with a single orderby field in descending order."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(base_url, orderby_fields="Title desc")
        assert result == "https://example.com/_api/web/lists?$orderby=Title desc"

    def test_build_query_url_with_orderby_multiple_fields(self):
        """Test build_query_url with multiple orderby fields."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(base_url, orderby_fields=["Title", "Modified"])
        assert result == "https://example.com/_api/web/lists?$orderby=Title,Modified"

    def test_build_query_url_with_orderby_multiple_fields_mixed_direction(self):
        """Test build_query_url with multiple orderby fields with mixed directions."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(base_url, orderby_fields=["Title asc", "Modified desc"])
        assert result == "https://example.com/_api/web/lists?$orderby=Title asc,Modified desc"

    def test_build_query_url_with_orderby_and_other_params(self):
        """Test build_query_url with orderby and other parameters."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(
            base_url,
            filters="Title eq 'Test'",
            select_fields=["Title", "Id"],
            orderby_fields="Modified",
            top=10
        )
        assert result == "https://example.com/_api/web/lists?$filter=Title eq 'Test'&$select=Title,Id&$orderby=Modified&$top=10"

    def test_build_query_url_without_orderby(self):
        """Test build_query_url without orderby maintains backward compatibility."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(
            base_url,
            filters="Title eq 'Test'",
            select_fields=["Title", "Id"],
            top=10
        )
        assert result == "https://example.com/_api/web/lists?$filter=Title eq 'Test'&$select=Title,Id&$top=10"

    def test_build_query_url_with_none_orderby(self):
        """Test build_query_url with orderby=None maintains backward compatibility."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(
            base_url,
            orderby_fields=None
        )
        assert result == "https://example.com/_api/web/lists"

    # Additional comprehensive tests for orderby functionality
    
    def test_build_query_url_with_empty_orderby_list(self):
        """Test build_query_url with empty orderby list."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(base_url, orderby_fields=[])
        # Empty list should produce no orderby clause
        assert result == "https://example.com/_api/web/lists"

    def test_build_query_url_with_complex_orderby_fields(self):
        """Test build_query_url with complex field names in orderby."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(
            base_url, 
            orderby_fields=["Created_x0020_Date", "Author/Title asc", "Editor/Title desc"]
        )
        expected = "https://example.com/_api/web/lists?$orderby=Created_x0020_Date,Author/Title asc,Editor/Title desc"
        assert result == expected

    def test_build_query_url_with_orderby_and_skiptoken(self):
        """Test build_query_url with orderby and skiptoken parameters."""
        base_url = "https://example.com/_api/web/lists/items"
        result = build_query_url(
            base_url,
            orderby_fields="Modified desc",
            skiptoken="Paged=TRUE&p_ID=5&$top=10"
        )
        expected = "https://example.com/_api/web/lists/items?$orderby=Modified desc&$skiptoken=Paged=TRUE&p_ID=5&$top=10"
        assert result == expected

    def test_build_query_url_orderby_with_all_others(self):
        """Test build_query_url with orderby alongside all other parameters."""
        base_url = "https://example.com/_api/web/lists"
        result = build_query_url(
            base_url,
            filters=["Status eq 'Active'", "Priority ge 1"],
            select_fields=["Id", "Title", "Modified"],
            orderby_fields=["Priority desc", "Modified"],
            top=50,
            skiptoken="token123"
        )
        # Note: Order of parameters may vary based on dictionary ordering, so we check the components
        assert result.startswith("https://example.com/_api/web/lists?")
        assert "$filter=Status eq 'Active' and Priority ge 1" in result
        assert "$select=Id,Title,Modified" in result
        assert "$orderby=Priority desc,Modified" in result
        assert "$top=50" in result
        assert "$skiptoken=token123" in result