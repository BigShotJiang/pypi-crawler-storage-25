import json
from datetime import datetime, timezone
from unittest.mock import MagicMock

import pytest
from requests import Response, Session

from sharepoint import (
    SharePointFolder,
    SharePointGroup,
    SharePointList,
    SharePointSite,
    SharePointUser,
)


def _mock_response(
    data: dict, status_code: int = 200, headers: dict = None
) -> Response:
    """Create a realistic ``requests.Response`` object with JSON data."""
    if headers is None:
        headers = {"Content-Type": "application/json;odata=verbose"}

    mock_resp = MagicMock(spec=Response)
    mock_resp.status_code = status_code
    mock_resp.headers = headers or {}
    mock_resp.ok = 200 <= status_code < 400
    mock_resp.json.return_value = data
    mock_resp.text = json.dumps(data)
    mock_resp.request = MagicMock()
    mock_resp.request.url = "https://example.com/_api/Web"
    return mock_resp


@pytest.fixture
def mock_session():
    """Provide a mocked ``requests.Session``."""
    return MagicMock(spec=Session)


@pytest.fixture
def site_metadata():
    """Typical site metadata payload returned by SharePoint."""
    return {
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web",
                "uri": "https://example.com/_api/Web",
                "type": "SP.Web",
            },
            "Title": "Demo Site",
            "Url": "https://example.com/sites/demo",
            "Description": "A demo SharePoint site",
            "Created": "2023-04-01T12:00:00Z",
            "Language": 1033,  # en-US
            "ServerRelativeUrl": "/sites/demo",
            "Lists": {"__deferred": {"uri": "https://example.com/_api/Web/Lists"}},
            "SiteUsers": {
                "__deferred": {"uri": "https://example.com/_api/Web/SiteUsers"}
            },
            "SiteGroups": {
                "__deferred": {"uri": "https://example.com/_api/Web/SiteGroups"}
            },
            "Folders": {"__deferred": {"uri": "https://example.com/_api/Web/Folders"}},
        }
    }


def test_site_properties(mock_session, site_metadata):
    """Validate basic property access on ``SharePointSite``."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # Simple string properties
    assert site.title == "Demo Site"
    assert site.url == "https://example.com/sites/demo"
    assert site.description == "A demo SharePoint site"
    assert site.relative_url == "/sites/demo"

    # ``created`` returns a timezone-aware ``datetime``
    created = site.created
    assert isinstance(created, datetime)
    assert created.tzinfo is not None
    # The original string is UTC, so the datetime should be UTC
    assert created == datetime(2023, 4, 1, 12, 0, 0, tzinfo=timezone.utc)


def test_get_lists_returns_sharepointlist_instances(mock_session, site_metadata):
    """``get_lists`` should return a list of ``SharePointList`` objects."""
    # First call – site metadata
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response(
            {
                "d": {
                    "results": [
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/Lists(guid'list-1')"
                            },
                            "Title": "Tasks",
                        },
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/Lists(guid'list-2')"
                            },
                            "Title": "Documents",
                        },
                    ]
                }
            }
        ),  # response for the Lists endpoint
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    sp_lists = site.get_lists()
    assert isinstance(sp_lists, list)
    assert len(sp_lists) == 2
    assert all(isinstance(sp_list, SharePointList) for sp_list in sp_lists)

    # Verify that the underlying URLs are correctly passed to the ``SharePointList`` ctor
    assert sp_lists[0]._url == "https://example.com/_api/Web/Lists(guid'list-1')"
    assert sp_lists[1]._url == "https://example.com/_api/Web/Lists(guid'list-2')"


def test_get_user_returns_sharepointuser_instance(mock_session, site_metadata):
    """``get_user`` should return a ``SharePointUser`` with the correct endpoint."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    user = site.get_user(user_id=42)
    expected_url = "https://example.com/_api/Web/GetUserById(42)"
    assert isinstance(user, SharePointUser)
    assert user._url == expected_url


def test_get_group_returns_sharepointgroup_instance(mock_session, site_metadata):
    """``get_group`` should return a ``SharePointGroup`` with the correct endpoint."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    group = site.get_group(group_name="Project Managers")
    expected_url = (
        "https://example.com/_api/Web/SiteGroups/GetByName('Project Managers')"
    )
    assert isinstance(group, SharePointGroup)
    assert group._url == expected_url


def test_get_folder_returns_sharepointfolder_instance(mock_session, site_metadata):
    """``get_folder`` should return a ``SharePointFolder`` with the correct endpoint."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    folder = site.get_folder(folder_name="Shared Documents")
    expected_url = (
        "https://example.com/_api/Web/GetFolderByServerRelativeUrl('Shared Documents')"
    )
    assert isinstance(folder, SharePointFolder)
    assert folder._url == expected_url


def test_get_groups_returns_sharepointgroup_instances(mock_session, site_metadata):
    """``get_groups`` should return a list of ``SharePointGroup`` objects."""
    # First call – site metadata
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response(
            {
                "d": {
                    "results": [
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/SiteGroups(1)"
                            },
                            "Title": "Administrators",
                        },
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/SiteGroups(2)"
                            },
                            "Title": "Members",
                        },
                    ]
                }
            }
        ),  # response for the SiteGroups endpoint
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    groups = site.get_groups()
    assert isinstance(groups, list)
    assert len(groups) == 2
    assert all(isinstance(group, SharePointGroup) for group in groups)

    # Verify that the underlying URLs are correctly passed to the ``SharePointGroup`` ctor
    assert groups[0]._url == "https://example.com/_api/Web/SiteGroups(1)"
    assert groups[1]._url == "https://example.com/_api/Web/SiteGroups(2)"


def test_get_groups_with_filters(mock_session, site_metadata):
    """``get_groups`` should respect filters parameter."""
    # Setup site metadata and group response
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response({"d": {"results": []}}),
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # Call get_groups with a filter
    filters = "Title eq 'Admins'"
    site.get_groups(filters=filters)

    # Verify the correct URL was built with the filter
    expected_base_url = "https://example.com/_api/Web/SiteGroups"
    expected_filter_param = "$filter=Title eq 'Admins'"

    # Check that a request was made with the filtered URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(
        expected_base_url in url and expected_filter_param in url for url in called_urls
    )


def test_get_groups_with_select_fields(mock_session, site_metadata):
    """``get_groups`` should respect select_fields parameter."""
    # Setup site metadata and group response
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response({"d": {"results": []}}),
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # Call get_groups with select_fields
    select_fields = ["Title", "Id"]
    site.get_groups(select_fields=select_fields)

    # Verify the correct URL was built with the select fields
    expected_base_url = "https://example.com/_api/Web/SiteGroups"
    # Looking at the build_query_url implementation, it adds select_fields as comma-separated string
    expected_select_param = "$select=Title,Id"

    # Check that a request was made with the select fields in URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(
        expected_base_url in url and expected_select_param in url for url in called_urls
    )


def test_get_groups_with_top_parameter(mock_session, site_metadata):
    """``get_groups`` should respect top parameter."""
    # Setup site metadata and group response
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response({"d": {"results": []}}),
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # Call get_groups with top parameter
    top = 5
    site.get_groups(top=top)

    # Verify the correct URL was built with the top parameter
    expected_base_url = "https://example.com/_api/Web/SiteGroups"
    expected_top_param = "$top=5"

    # Check that a request was made with the top parameter in URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(
        expected_base_url in url and expected_top_param in url for url in called_urls
    )


def test_get_groups_handles_empty_results(mock_session, site_metadata):
    """``get_groups`` should handle empty results gracefully."""
    # Setup site metadata and empty group response
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response({"d": {"results": []}}),
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # Should not raise an exception and return an empty list
    groups = site.get_groups()
    assert isinstance(groups, list)
    assert len(groups) == 0


def test_get_groups_with_all_parameters(mock_session, site_metadata):
    """``get_groups`` should work correctly with all parameters combined."""
    # Setup site metadata and group response
    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # metadata for the site
        _mock_response(
            {
                "d": {
                    "results": [
                        {
                            "__metadata": {
                                "uri": "https://example.com/_api/Web/SiteGroups(1)"
                            },
                            "Title": "Admins",
                            "Id": 1,
                        }
                    ]
                }
            }
        ),
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # Call get_groups with all parameters
    filters = "Id gt 0"
    select_fields = ["Title", "Id"]
    top = 10

    groups = site.get_groups(filters=filters, select_fields=select_fields, top=top)

    # Verify the correct URL was built
    expected_base_url = "https://example.com/_api/Web/SiteGroups"
    expected_filter_param = "$filter=Id gt 0"
    expected_select_param = "$select=Title,Id"
    expected_top_param = "$top=10"

    # Check that a request was made with all parameters in URL
    called_urls = [call[0][0] for call in mock_session.get.call_args_list]
    assert any(
        expected_base_url in url
        and expected_filter_param in url
        and expected_select_param in url
        and expected_top_param in url
        for url in called_urls
    )

    # Should return properly constructed SharePointGroup instances
    assert len(groups) == 1
    assert isinstance(groups[0], SharePointGroup)
    assert groups[0]._url == "https://example.com/_api/Web/SiteGroups(1)"


def test_site_error_response(mock_session, site_metadata):
    """Test handling of SharePoint error responses."""
    error_response = {
        "error": {
            "code": "-1, Microsoft.SharePoint.Client.ResourceNotFoundException",
            "message": {
                "lang": "en-US",
                "value": "Cannot find resource for the request fake-endpoint.",
            },
        }
    }

    mock_session.get.side_effect = [
        _mock_response(site_metadata),  # Initial site metadata
        _mock_response(
            error_response,
            status_code=404,
            headers={"Content-Type": "application/json;odata=verbose"},
        ),
    ]

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # This test validates that our mock correctly simulates error responses
    # In practice, the SharePointAPI would raise an exception, but here we just test the mock
    pass


def test_site_created_item_response(mock_session, site_metadata):
    """Test handling of 201 Created responses."""
    created_response = {
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web/Lists(guid'list-id')/Items(1)",
                "uri": "https://example.com/_api/Web/Lists(guid'list-id')/Items(1)",
                "type": "SP.ListItem",
                "etag": "1",
            },
            "Id": 1,
            "Title": "New Item",
        }
    }

    mock_session.post.return_value = _mock_response(
        created_response,
        status_code=201,
        headers={"Content-Type": "application/json;odata=verbose", "ETag": "1"},
    )
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    # This test validates that our mock correctly simulates created responses
    # In practice, this would be used when creating items, but here we just test the mock
    pass


def test_self_typing_inheritance(mock_session):
    """Test that Self typing works correctly with inheritance."""
    
    class CustomSharePointSite(SharePointSite):
        """A custom SharePoint site subclass for testing Self typing."""
        
        def custom_method(self) -> str:
            """A custom method to distinguish this subclass."""
            return "custom"

    # Mock the session to prevent actual HTTP calls
    mock_session.get.return_value = _mock_response({
        "d": {
            "__metadata": {
                "id": "https://example.com/_api/Web",
                "uri": "https://example.com/_api/Web",
                "type": "SP.Web",
            },
            "Title": "Test Site",
            "Url": "https://example.com/sites/test",
            "Description": "A test SharePoint site",
            "Created": "2023-04-01T12:00:00Z",
            "Language": 1033,
            "ServerRelativeUrl": "/sites/test",
            "Lists": {"__deferred": {"uri": "https://example.com/_api/Web/Lists"}},
            "SiteUsers": {
                "__deferred": {"uri": "https://example.com/_api/Web/SiteUsers"}
            },
            "SiteGroups": {
                "__deferred": {"uri": "https://example.com/_api/Web/SiteGroups"}
            },
            "Folders": {"__deferred": {"uri": "https://example.com/_api/Web/Folders"}},
        }
    })

    # Call from_relative_url on the subclass
    custom_site = CustomSharePointSite.from_relative_url(
        base_sharepoint_url="https://example.com",
        relative_url="/sites/test",
        session=mock_session,
    )

    # Assert that the returned instance is of the subclass type, not the parent SharePointSite type
    assert isinstance(custom_site, CustomSharePointSite)
    assert isinstance(custom_site, SharePointSite)  # It's still an instance of the parent
    assert type(custom_site) == CustomSharePointSite  # But the concrete type is the subclass
    # Verify that custom methods work
    assert hasattr(custom_site, 'custom_method')
    assert custom_site.custom_method() == "custom"


def test_get_list_by_title_returns_sharepointlist_instance(mock_session, site_metadata):
    """``get_list`` should return a ``SharePointList`` with the correct endpoint when using list_title."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    list_obj = site.get_list(list_title="Tasks")
    expected_url = "https://example.com/_api/Web/Lists/GetByTitle('Tasks')"
    assert isinstance(list_obj, SharePointList)
    assert list_obj._url == expected_url


def test_get_list_by_guid_returns_sharepointlist_instance(mock_session, site_metadata):
    """``get_list`` should return a ``SharePointList`` with the correct endpoint when using list_guid."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    list_obj = site.get_list(list_guid="12345678-1234-1234-1234-123456789012")
    expected_url = (
        "https://example.com/_api/Web/Lists(guid'12345678-1234-1234-1234-123456789012')"
    )
    assert isinstance(list_obj, SharePointList)
    assert list_obj._url == expected_url


def test_get_list_raises_error_when_both_parameters_provided(
    mock_session, site_metadata
):
    """``get_list`` should raise ValueError when both list_guid and list_title are provided."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    with pytest.raises(
        ValueError,
        match=r"Provide \*\*either\*\* `list_guid` \*\*or\*\* `list_title`, but not both\.",
    ):
        site.get_list(
            list_guid="12345678-1234-1234-1234-123456789012", list_title="Tasks"
        )


def test_get_list_raises_error_when_neither_parameter_provided(
    mock_session, site_metadata
):
    """``get_list`` should raise ValueError when neither list_guid nor list_title are provided."""
    mock_session.get.return_value = _mock_response(site_metadata)

    site = SharePointSite(
        url="https://example.com/_api/Web",
        session=mock_session,
    )

    with pytest.raises(
        ValueError,
        match=r"Provide \*\*either\*\* `list_guid` \*\*or\*\* `list_title`, but not both\.",
    ):
        site.get_list()
