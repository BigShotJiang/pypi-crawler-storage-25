# Agent Development Guide

This document contains essential information for AI coding agents working on this repository.

## Project Overview

This is a Python client library for SharePoint REST API operations using a client pattern for better abstraction. The library provides classes for site-scoped operations, user management, list item operations, and more.

## Build/Lint/Test Commands

### Task Runner (Primary Method)

This project uses `task` as its primary task runner. Agents should EXCLUSIVELY use the namespaced agent tasks to ensure consistency and proper isolation.

#### For AI Agent Usage

```bash
# Run the full test suite in a Docker container
task agent:test

# Run all linting tools in a Docker container
task agent:lint

# Run individual linting tools
task agent:lint-flake8
task agent:lint-black
task agent:lint-isort
```

**Important**: AI agents should EXCLUSIVELY use the namespaced agent tasks to ensure consistency and proper isolation. The non-namespaced tasks are for developer use only.

### Agent Usage

For AI agent usage, it's recommended to use the namespaced agent tasks:

- `task agent:test` for running tests
- `task agent:lint` for running all linting tools
- `task agent:lint-flake8` for running flake8
- `task agent:lint-black` for running black
- `task agent:lint-isort` for running isort

**Important**: AI agents should EXCLUSIVELY use the namespaced agent tasks to ensure consistency and proper isolation.

### Linting Commands

This project follows PEP 8 standards with a line length of 88 characters. Agents should use the task runner for linting, which uses Docker containers for consistency:

### Task-based Linting (Agent Usage Only)

```bash
# Run all linting tools
task agent:lint

# Run individual linting tools
task agent:lint-flake8
task agent:lint-black
task agent:lint-isort
```

### Agent Usage Guidelines

For AI agent usage, it's recommended to use the namespaced agent tasks:

- `task agent:test` for running tests
- `task agent:lint` for running all linting tools
- `task agent:lint-flake8` for running flake8
- `task agent:lint-black` for running black
- `task agent:lint-isort` for running isort

**Important**: AI agents should EXCLUSIVELY use the namespaced agent tasks to ensure consistency and proper isolation. The non-namespaced tasks are for developer use only.

### Test Organization

Tests are organized by module:

- `tests/test_site.py` - Tests for SharePointSite
- `tests/test_list.py` - Tests for SharePointList
- `tests/test_list_item.py` - Tests for SharePointListItem
- `tests/test_user.py` - Tests for SharePointUser
- `tests/test_group.py` - Tests for SharePointGroup

## Code Style Guidelines

### General Principles

1. Follow existing patterns in the codebase
2. Maintain consistency with current naming conventions and structure
3. Use clear, descriptive variable and function names
4. Write comprehensive docstrings following the existing format
5. Follow the principles described in `docs/CODING_GUIDELINES.md`

### Imports

1. Standard library imports first
2. Third-party imports second
3. Local application imports last
4. Within each group, sort alphabetically
5. Use explicit imports rather than wildcards
6. Group imports by category with blank lines between groups

Example:

```python
import json
import locale
import requests
from datetime import datetime
from typing import List, Optional
from os import path

from ._base import SharePointBase
from .list import SharePointList
```

### Formatting

1. Indentation: 4 spaces (no tabs)
2. Maximum line length: 88 characters (follows Black defaults)
3. Use parentheses for line continuation
4. Surround binary operators with spaces (`a = b + c`, not `a=b+c`)
5. No trailing whitespace
6. Files should end with a newline
7. Use f-strings for string interpolation (preferred over % or .format())

### Types

1. Use type hints for all function parameters and return values
2. Import typing modules as needed (List, Optional, Dict, etc.)
3. Use `TYPE_CHECKING` guard for circular imports:

```python
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from .site import SharePointSite
```

1. Use union syntax with `|` instead of `Union[]` for optional values (PEP 604)

### Naming Conventions

1. Classes: PascalCase (`SharePointSite`, `SharePointList`)
2. Functions and variables: snake_case (`get_lists`, `site_url`)
3. Constants: UPPER_SNAKE_CASE (`MAX_RETRIES`, `DEFAULT_TIMEOUT`)
4. Private members: prefixed with underscore (`_ensure_metadata`)
5. Properties: snake_case when single words, snake_case for multiple words (`title`, `language_name`)

### Docstrings

1. Use triple double quotes for all docstrings
2. Follow NumPy-style documentation for public APIs
3. Include parameter descriptions, return values, and exceptions
4. Use backticks for code references and literals
5. Include examples where appropriate

Example:

```python
def from_relative_url(
    base_sharepoint_url: str,
    relative_url: str,
    session: requests.Session,
) -> "SharePointSite":
    """
    Initialise a :class:`SharePointSite` using a base SharePoint URL and a
    server-relative URL.

    Parameters
    ----------
    base_sharepoint_url : str
        The root URL of the SharePoint tenant (e.g. ``https://example.com``).
    relative_url : str
        The server-relative path to the site (e.g. ``/sites/demo``).
    session : requests.Session
        A pre-configured session with authentication.

    Returns
    -------
    SharePointSite
        An instance configured with the combined site URL.
    """
```

### Error Handling

1. Use specific exception types rather than generic exceptions
2. Handle expected errors gracefully with meaningful messages
3. Re-raise exceptions with additional context when appropriate
4. Don't ignore exceptions silently
5. Validate inputs early in functions
6. Use centralized error handling through `SharePointAPI` methods (`_handle_response`)

### Class Structure

1. Place class docstring immediately after class declaration
2. Organize class methods logically:
   - Class methods first
   - Properties grouped together
   - Instance methods grouped by functionality
3. Use section headers as comments to organize methods:

```python
# -----------------------------------------------------------------
# Exposed properties (lazy-loaded)
# -----------------------------------------------------------------
@property
def title(self) -> str:
    """Site title."""
    return self.get("Title", "")
```

### Base Classes

Most SharePoint objects inherit from `SharePointBase` which provides:

- `_ensure_metadata()` for lazy loading of object metadata
- Common utility methods
- API client initialization

When creating new SharePoint object classes, inherit from `SharePointBase` and follow the established patterns in existing implementations.

### API Design Patterns

1. Use lazy loading for metadata properties (using `@property` decorators)
2. Provide class methods for alternative constructors (e.g., `from_relative_url`)
3. Follow consistent return types for methods
4. Use OData query parameters consistently across list operations
5. Handle pagination automatically where appropriate
6. Use exclusive-or validation pattern for methods that accept exactly one of several optional arguments:

```python
if (list_guid is None) == (list_title is None):
    raise ValueError(
        "Provide **either** `list_guid` **or** `list_title`, "
        "but not both."
    )
```

### URL Construction

1. Use `os.path.join` for building URLs to avoid manual slash handling
2. For query-parameter URLs, use the `build_query_url` helper in `_odata_utils.py`
3. Construct URLs using f-strings for readability

### Session and HTTP Interaction

1. Store a single `requests.Session` in each wrapper and reuse it for all API calls
2. All network calls must go through `SharePointAPI` methods (`_api_get_call`, `_api_post_call`, etc.)
3. Mandatory SharePoint headers (X-RequestDigest, X-HTTP-Method for MERGE/PUT) should be added centrally
4. Handle HTTP errors consistently using the `_handle_response` method

### Validation Patterns

1. Always validate input parameters early in functions
2. Use clear, helpful error messages that guide users to correct usage
3. For parameters that are mutually exclusive, use the XOR validation pattern shown above

## Repository Structure

- `sharepoint/` - Main source code package
- `tests/` - Unit tests for each module
- `docs/` - Documentation files
- `Taskfile.yml` - Task definitions for common operations
- `setup.py` - Package setup and metadata
- `pyproject.toml` - Build system requirements

## Dependencies

Main dependencies (defined in setup.py):

- `requests>=2.32.2` - HTTP library
- `requests-ntlm>=1.3.0` - NTLM authentication support
- `pytz>=2021.1` - Timezone handling

Development dependencies (installed via task):

- `pytest` - Testing framework
- `twine` - Package publishing
- `build` - Package building
- `flake8` - Linting
- `black` - Code formatting
- `isort` - Import sorting

Always check existing code before making changes to ensure consistency with established patterns.
