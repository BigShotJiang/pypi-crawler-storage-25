import datetime
from typing import List
from urllib.parse import urljoin

from ._base import SharePointBase
from ._odata_utils import build_query_url
from .file import SharePointFile


class SharePointFolder(SharePointBase):
    """
    Base class representing a SharePoint folder.

    Provides common functionality for handling folder items, including
    retrieval, addition, and serialization to JSON. Subclasses such as
    :class:`Casesfolder` and :class:`TimeRegistrationfolder` extend this
    class with domain-specific behavior.
    """

    _base_url = None

    # -----------------------------------------------------------------
    # Properties
    # -----------------------------------------------------------------

    @property
    def base_url(self) -> str:
        """Base URL of the SharePoint site (without the '_api' part)."""
        if not self._base_url:
            self._base_url = self._url.split("_api")[0]
        return self._base_url

    @property
    def _form_digestive_value(self) -> str:
        """Form digest value required for POST/PUT/MERGE operations."""
        context_url = urljoin(self.base_url, "_api/contextinfo")
        r = self._api.post(context_url, {})
        return r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

    @property
    def name(self) -> str:
        """Folder name."""
        return self.get("Name", "")

    @property
    def id(self) -> str:
        """Unique identifier of the folder."""
        return self.get("UniqueId", "")

    @property
    def relative_url(self) -> str:
        """Server-relative URL of the folder."""
        return self.get("ServerRelativeUrl", "")

    @property
    def created(self) -> datetime.datetime | None:
        """Timestamp when the item was created."""
        return self.get_datetime("TimeCreated")

    @property
    def modified(self) -> datetime.datetime | None:
        """Timestamp when the item was last modified."""
        return self.get_datetime("TimeLastModified")

    def get_folders(
        self,
        filters: str | None = None,
        select_fields: List[str] | None = None,
        top: int | None = None,
    ) -> List["SharePointFolder"]:
        """Return a collection of folders for this site.

        Parameters
        ----------
        filters : str | None, optional
            OData ``$filter`` expression to restrict returned folders.
        select_fields : List[str] | None, optional
            OData ``$select`` fields to limit properties returned for each folder.
        top : int | None, optional
            OData ``$top`` limit for the number of folders returned.

        Returns
        -------
        List[SharePointFolder]
            A list of SharePointFolder objects representing the subfolders.
        """
        url = build_query_url(
            self.get("Folders", {}).get("__deferred", {}).get("uri"),  # type: ignore
            filters=filters,
            select_fields=select_fields if select_fields else ["__metadata"],
            top=top,
        )

        r = self._api.get(url)
        # Use the same class (including subclasses) for each returned folder.
        # ``self.__class__`` ensures that if this method is called on a subclass,
        # the instances created are of that subclass, preserving any overridden
        # behavior. Pass the existing session so the new objects share the
        # authenticated session.
        return [
            self.__class__(
                sp_item.get("__metadata", {}).get("uri"),
                self._api.session,
            )
            for sp_item in r.json()["d"]["results"]
        ]

    def get_folder(
        self,
        folder_guid: str | None = None,
        folder_name: str | None = None,
    ) -> "SharePointFolder":
        """Return a :class:`SharePointFolder` for this site.

        Exactly **one** of ``folder_guid`` or ``folder_name`` must be supplied.
        ``folder_guid`` should be the GUID string (e.g. ``'1234-ABCD-...'``),
        while ``folder_name`` is the human-readable folder name.

        Raises
        ------
        ValueError
            If both arguments are provided or if neither is provided.
        """
        # ---- exclusive-or validation -----------------------------------------
        if (folder_guid is None) == (folder_name is None):
            raise ValueError(
                "Provide **either** `folder_guid` **or** `folder_name`, "
                "but not both."
            )

        # ---- build the appropriate endpoint ------------------------------------
        if folder_guid:
            # Retrieve folder by GUID using the documented Web method
            url = urljoin(self.base_url, f"_api/Web/GetFolderById(guid'{folder_guid}')")
        else:
            # Retrieve folder by its server-relative URL as per SharePoint REST API
            url = urljoin(
                self.base_url,
                f"_api/Web/GetFolderByServerRelativeUrl('{folder_name}')",
            )

        # ---- return the wrapper object -----------------------------------------
        return self.__class__(url, self._api.session)

    def get_files(
        self,
        filters: str | None = None,
        select_fields: List[str] | None = None,
        top: int | None = None,
    ) -> List["SharePointFile"]:
        """Return a collection of files in this folder.

        Parameters
        ----------
        filters : str | None, optional
            OData ``$filter`` expression to restrict returned files.
        select_fields : List[str] | None, optional
            OData ``$select`` fields to limit properties returned for each file.
        top : int | None, optional
            OData ``$top`` limit for the number of files returned.

        Returns
        -------
        List[SharePointFile]
            A list of SharePointFile objects in this folder.
        """
        url = build_query_url(
            self.get("Files", {}).get("__deferred", {}).get("uri"),  # type: ignore
            filters=filters,
            select_fields=select_fields if select_fields else ["__metadata"],
            top=top,
        )

        r = self._api.get(url)
        return [
            SharePointFile(
                sp_item.get("__metadata", {}).get("uri"),
                self._api.session,
            )
            for sp_item in r.json()["d"]["results"]
        ]

    def get_file(self, file_name: str) -> "SharePointFile":
        """Return a specific :class:`SharePointFile` from this folder.

        Parameters
        ----------
        file_name : str
            The name of the file to retrieve.

        Returns
        -------
        SharePointFile
            The requested file object.

        Raises
        ------
        ValueError
            If ``file_name`` is not provided.
        """
        # ---- validate required parameter ---------------------------------------
        if not file_name:
            raise ValueError("`file_name` must be provided.")

        # ---- build the endpoint ------------------------------------------------
        url = f"{self._url}/Files('{file_name}')"

        # ---- return the wrapper object -----------------------------------------
        return SharePointFile(url, self._api.session)

    def add_file(
        self,
        file_name: str,
        content: str | bytes,
        overwrite: bool = True,
    ) -> "SharePointFile":
        """Upload a new file to this folder.

        Parameters
        ----------
        file_name : str
            The name of the file to create.
        content : str | bytes
            The content of the file to upload.
        overwrite : bool, optional
            Whether to overwrite an existing file with the same name (default is True).

        Returns
        -------
        SharePointFile
            The newly created file object.
        """
        # ---- build the endpoint ------------------------------------------------
        url = (
            f"{self._url}/Files/Add(url='{file_name}', "
            f"overwrite={'true' if overwrite else 'false'})"
        )

        # ---- post the file content ---------------------------------------------
        # Handle both text and binary content
        if isinstance(content, str):
            content_bytes = content.encode("utf-8")
        else:
            content_bytes = content

        r = self._api.post_complex(
            url,
            post_data=content_bytes,
            form_digest_value=self._form_digestive_value,
        )

        # ---- return the wrapper object -----------------------------------------
        return SharePointFile(
            r.json()["d"].get("__metadata", {}).get("uri"),
            self._api.session,
        )

    def create_subfolder(self, folder_name: str) -> "SharePointFolder":
        """Create a new subfolder within this folder.

        Parameters
        ----------
        folder_name : str
            The name of the subfolder to create.

        Returns
        -------
        SharePointFolder
            The newly created folder object.

        Raises
        ------
        ValueError
            If ``folder_name`` is not provided.
        """
        # ---- validate required parameter ---------------------------------------
        if not folder_name:
            raise ValueError("`folder_name` must be provided.")

        # ---- build the endpoint ------------------------------------------------
        url = f"{self._url}/Folders"

        # Build the server-relative URL for the new folder
        server_relative_url = f"{self.relative_url}/{folder_name}"

        # ---- post the folder creation request ----------------------------------
        payload = {"ServerRelativeUrl": server_relative_url}

        r = self._api.post(
            url,
            post_data=payload,
            form_digest_value=self._form_digestive_value,
        )

        # ---- return the wrapper object -----------------------------------------
        return self.__class__(
            r.json()["d"].get("__metadata", {}).get("uri"),
            self._api.session,
        )

    def delete(self) -> bool:
        """
        Delete the folder.

        Returns
        -------
        bool
            True if the deletion succeeded, False otherwise.
        """
        try:
            r = self._api.post_complex(
                self._url,
                post_data=None,
                form_digest_value=self._form_digestive_value,
                x_http_method="DELETE",
            )
            return r.ok
        except Exception:
            return False
