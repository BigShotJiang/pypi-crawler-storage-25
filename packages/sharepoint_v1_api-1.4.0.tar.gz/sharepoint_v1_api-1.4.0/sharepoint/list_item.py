from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, List, Optional, Union
from urllib.parse import urljoin

from ._base import SharePointBase
from ._odata_utils import build_query_url
from .list_item_version import SharePointListItemVersion

if TYPE_CHECKING:
    from .list import SharePointList


class SharePointListItem(SharePointBase):
    """
    Represents a generic item in a SharePoint list.
    """

    _base_url = None

    # -----------------------------------------------------------------
    # Properties
    # -----------------------------------------------------------------
    @property
    def _parent_list_url(self) -> str:
        parent_list = self.get("ParentList") or {}
        deferred = parent_list.get("__deferred") or {}
        return deferred.get("uri") or ""

    @property
    def _versions_url(self) -> str:
        versions = self.get("Versions") or {}
        deferred = versions.get("__deferred") or {}
        return deferred.get("uri") or ""

    @property
    def _form_digestive_value(self) -> str:
        r = self._api.post(urljoin(self.base_url, "_api/contextinfo"), {})
        return r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

    @property
    def base_url(self) -> str:
        if not self._base_url:
            self._base_url = self._url.split("_api")[0]
        return self._base_url

    @property
    def id(self) -> Optional[str]:
        """Unique identifier of the list item."""
        return self.get("Id")

    @property
    def etag(self) -> Optional[str]:
        """Entity tag of the list item."""
        metadata = self.get("__metadata") or {}
        return metadata.get("etag")

    @property
    def title(self) -> Optional[str]:
        """Title of the list item."""
        return self.get("Title")

    @property
    def modified(self) -> Optional[datetime]:
        """Timestamp when the item was last modified."""
        return self.get_datetime("Modified")

    def get_parent_list(self) -> "SharePointList":
        from .list import SharePointList

        r = self._api.get(self._parent_list_url)
        return SharePointList(
            r.json()["d"].get("__metadata", {}).get("uri"), self._api.session
        )

    def get_versions(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        top: Optional[int] = None,
        orderby_fields: Optional[Union[str, List[str]]] = None,
    ) -> List[SharePointListItemVersion]:
        """
        Get a collection of version history for this list item.

        Parameters
        ----------
        filters : Optional[str], optional
            OData filter string, by default None
        select_fields : Optional[List[str]], optional
            Fields to select, by default None
        top : Optional[int], optional
            Maximum number of items to return, by default None
        orderby_fields : Optional[Union[str, List[str]]], optional
            Field(s) to order the results by. If a list is provided, fields are ordered
            in sequence. Append ``desc`` to a field name for descending order
            (e.g., ``Title desc``), by default None

        Returns
        -------
        List[SharePointListItemVersion]
            List of SharePointListItemVersion objects representing the version history
        """

        if not select_fields:
            select_fields = ["VersionId"]
        elif "versionId" not in select_fields:
            select_fields.append("versionId")

        url = build_query_url(
            self._versions_url,
            filters=filters,
            select_fields=select_fields,
            top=top,
            orderby_fields=orderby_fields,
        )

        r = self._api.get(url)
        return [
            SharePointListItemVersion(
                url=self._versions_url + f"({sp_list_item.get('VersionId')})",
                session=self._api.session,
                metadata=sp_list_item,
            )
            for sp_list_item in r.json()["d"]["results"]
        ]

    def update_item(self, data: dict) -> bool:
        """
        Update a sharepoint item.

        Parameters
        ----------
        data : dict
            Data to push to the item

        Returns
        -------
        bool
            True if the update succeeded, False otherwise.
        """

        form_digest_value = self._form_digestive_value

        r = self._api.post(
            self._url, data, form_digest_value=form_digest_value, merge=True
        )
        self._update_metadata

        return r.ok

    def delete_item(self) -> bool:
        """
        Delete the SharePoint list item.

        Returns True if the deletion succeeded, False otherwise.
        """
        form_digest_value = self._form_digestive_value

        r = self._api.delete(
            self._url,
            form_digest_value=form_digest_value,
        )
        return r.ok
