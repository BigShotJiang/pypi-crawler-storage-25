"""
Base utilities for SharePoint objects.

Provides common functionality for handling metadata retrieval and merging.
All high-level SharePoint objects (Site, Folder, Group, List, ListItem,
ListField, User) should inherit from :class:`SharePointBase`.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

import requests

from ._api import SharePointAPI
from ._datetime_utils import parse_sharepoint_datetime
from ._odata_utils import build_query_url


class SharePointBase:
    """
    Base class representing a generic SharePoint object.

    Sub-classes should pass the object's primary URL (e.g. the endpoint used
    for a GET request) to ``super().__init__(url, session)``. The base class
    stores a thin :class:`SharePointAPI` transport client, caches the raw
    metadata dictionary and provides helpers for lazy loading and optional
    OData queries.

    Attributes
    ----------
    _api : SharePointAPI
        Thin transport client used for all HTTP calls.
    _url : str
        Primary endpoint URL for the object (used by ``_ensure_metadata``).
    _metadata : Optional[dict]
        Cached metadata dictionary returned by SharePoint.
    """

    def __init__(
        self, url: str, session: requests.Session, metadata: Optional[dict] = None
    ):
        """
        Initialise the base object.

        Parameters
        ----------
        url : str
            The primary endpoint URL for the SharePoint object.
        session : requests.Session
            A pre-configured session with authentication (NTLM, etc.).
        """
        # Initialise the thin transport client.
        self._api: SharePointAPI = SharePointAPI(session=session)
        self._url: str = url
        self._metadata: Optional[dict] = metadata

    # -----------------------------------------------------------------
    # Internal helpers
    # -----------------------------------------------------------------
    def _ensure_metadata(self) -> dict:
        """Fetch object metadata on first use and cache it."""
        if self._metadata is None:
            r = self._api.get(self._url)
            self._metadata = r.json().get("d", {})
        return self._metadata or {}

    @property
    def _update_metadata(self) -> dict:
        """Fetch site metadata on first use and cache it."""
        return self._get_metadata()

    def _get_metadata_lookup(
        self,
        select_field: str,
        filters: Optional[str] = None,
        top: Optional[int] = None,
    ) -> dict:
        """
        Retrieve metadata for a lookup field on an item
        """
        params = []

        # Always select the lookup field with Title and Id, plus the base Id field
        select_fields = f"Id,{select_field}/Title,{select_field}/Id"
        params.append(f"$select={select_fields}")

        # This needs to be added for lookup fields
        params.append(f"$expand={select_field}")

        # #TODO: Add optional parameters (only for collections, not single items)
        # if not self._url.endswith(")"):  # Check if it's a single item URL
        #     if filters:
        #         params.append(f"$filter={filters}")
        #     if top:
        #         params.append(f"$top={top}")

        lookup_field_url = f"{self._url}?{'&'.join(params)}"

        try:
            r = self._api.get(lookup_field_url)
            data = r.json().get("d", {})

            if isinstance(self._metadata, dict):
                self._metadata.update(data)
            else:
                self._metadata = data

            return self._metadata or {}

        except Exception as e:
            if "must contains" in str(e) and "$expand" in str(e):
                raise ValueError(
                    f"'{select_field}' is not a valid lookup field or doesn't exist in this list."
                ) from e
            raise

    def _get_metadata(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        top: Optional[int] = None,
    ) -> dict:
        """
        Retrieve metadata using an optional OData query and merge it into the
        cached ``_metadata`` dictionary.

        Parameters
        ----------
        filters : Optional[str]
            OData ``$filter`` expression.
        select_fields : Optional[List[str]]
            OData ``$select`` fields.
        top : Optional[int]
            OData ``$top`` limit.

        Returns
        -------
        dict
            The updated metadata cache.
        """
        query_url = build_query_url(
            self._url,
            filters=filters,
            select_fields=select_fields,
            top=top,
        )

        r = self._api.get(query_url)
        data = r.json().get("d", {})
        if isinstance(self._metadata, dict):
            self._metadata.update(data)
        else:
            self._metadata = data
        return self._metadata or {}

    def get(
        self,
        field_name: str,
        default: Optional[Any] = None,
        lookup_field: bool = False,
    ) -> Any:
        """Get a value from the object's metadata, loading it lazily if necessary.

        Parameters
        ----------
        field_name : str
            The metadata field name to retrieve.
        lookup_field: bool
            If the field in question is of type lookup, then the api call is different
            and for now we set a flag explicitly on input to let the backend now it
            should use another get method.

        Returns
        -------
        Any
            The value of the requested metadata field, or ``None`` if not present.
        """
        if lookup_field:
            self._get_metadata_lookup(select_field=field_name)
        elif self._metadata is None or field_name not in self._metadata:
            # Retrieve only the requested field
            self._get_metadata(select_fields=[field_name])

        metadata = self._metadata or {}
        return metadata.get(field_name, default)

    def get_datetime(
        self, field_name: str, default: Optional[Any] = None
    ) -> datetime | None:
        datetime_str = self.get(field_name, default)
        return parse_sharepoint_datetime(datetime_str, self._api.timezone)

    @property
    def created(self) -> datetime | None:
        """Creation timestamp of the site."""
        return self.get_datetime("Created")
