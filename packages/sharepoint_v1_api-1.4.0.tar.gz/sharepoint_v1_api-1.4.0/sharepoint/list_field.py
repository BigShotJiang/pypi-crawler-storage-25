from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional
from urllib.parse import urljoin

from ._base import SharePointBase

if TYPE_CHECKING:
    from .list import SharePointList


class SharePointListField(SharePointBase):
    """
    Represents a generic field in a SharePoint list.
    """

    _base_url = None

    @property
    def _update_metadata(self) -> None:
        """Fetch field metadata on first use and cache it."""
        r = self._api.get(self._url)
        self._metadata = r.json().get("d", {})

    @property
    def _form_digestive_value(self) -> str:
        # Properly construct URL avoiding double slashes
        context_info_url = urljoin(self.base_url, "_api/contextinfo")
        r = self._api.post(context_info_url, {})

        return r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

    @property
    def base_url(self) -> str:
        if not self._base_url:
            self._base_url = self._url.split("_api")[0]
        return self._base_url

    @property
    def id(self) -> Optional[str]:
        """Field identifier (GUID)."""
        return self.get("Id")

    @property
    def etag(self) -> Optional[str]:
        """Entity tag of the field."""
        return self.get("__metadata", {}).get("etag")

    @property
    def title(self) -> Optional[str]:
        """Display title of the field."""
        return self.get("Title")

    @property
    def internal_name(self) -> Optional[str]:
        """Internal name of the field."""
        return self.get("InternalName")

    @property
    def static_name(self) -> Optional[str]:
        """Static name of the field."""
        return self.get("StaticName")

    @property
    def type_as_string(self) -> Optional[str]:
        """Field type as string."""
        return self.get("TypeAsString")

    @property
    def type_display_name(self) -> Optional[str]:
        """Human-readable field type."""
        return self.get("TypeDisplayName")

    @property
    def required(self) -> bool:
        """Whether the field is required."""
        return bool(self.get("Required"))

    @property
    def hidden(self) -> bool:
        """Whether the field is hidden."""
        return bool(self.get("Hidden"))

    @property
    def read_only(self) -> bool:
        """Whether the field is read-only."""
        return bool(self.get("ReadOnlyField"))

    def update_field(self, data: dict) -> bool:
        """
        Update a SharePoint field

        _url: The URL of the field to update
        data: Dictionary of fields to update

        Returns
        -------
        bool
            True if the update succeeded, False otherwise.
        """
        r = self._api.post(self._url, data, self._form_digestive_value, merge=True)
        self._update_metadata
        return r.ok

    def delete_field(self) -> bool:
        """
        Delete the SharePoint list field.

        Returns True if the deletion succeeded, False otherwise.
        """
        r = self._api.post_complex(
            self._url,
            post_data=None,
            form_digest_value=self._form_digestive_value,
            x_http_method="DELETE",
        )
        return r.ok


class ChoiceField(SharePointListField):
    """
    Represents a choice field in a SharePoint list.
    """

    @property
    def choices(self) -> List[str]:
        """Available choices for the field."""
        return self.get("Choices", {}).get("results", [])

    @property
    def default_choice(self) -> Optional[str]:
        """Default choice for the field."""
        return self.get("DefaultValue")


class LookupField(SharePointListField):
    """
    Represents a lookup field in a SharePoint list.
    """

    @property
    def lookup_list_id(self) -> Optional[str]:
        """GUID of the target list for the lookup."""
        return self.get("LookupList")

    @property
    def lookup_field(self) -> Optional[str]:
        """Field in the target list to display."""
        return self.get("LookupField")

    @property
    def allow_multiple_values(self) -> bool:
        """Whether multiple values are allowed."""
        return bool(self.get("AllowMultipleValues"))

    def get_lookup_list(self) -> "SharePointList":
        """
        Get the SharePoint list that this field looks up to.

        Returns
        -------
        SharePointList
            The target SharePoint list object.
        """
        from .list import SharePointList

        if not self.lookup_list_id:
            raise ValueError("Lookup field does not have a target list ID.")

        # Clean the GUID if it has braces
        list_id = self.lookup_list_id
        if list_id.startswith("{") and list_id.endswith("}"):
            list_id = list_id[1:-1]

        # Construct the URL for the target list using the field's session
        list_url = urljoin(self.base_url, f"_api/web/lists(guid'{list_id}')")
        return SharePointList(list_url, self._api.session)


class DateTimeField(SharePointListField):
    """
    Represents a datetime field in a SharePoint list.
    """

    @property
    def display_format(self) -> Optional[str]:
        """Display format for the datetime field."""
        return self.get("DisplayFormat")


class PersonOrGroupField(LookupField):
    """
    Represents a person or group field in a SharePoint list.
    """

    @property
    def selection_mode(self) -> Optional[str]:
        """Selection mode for the field (People only, People and Groups)."""
        return self.get("SelectionMode")

    @property
    def allow_multiple_values(self) -> bool:
        """Whether multiple values are allowed."""
        return bool(self.get("AllowMultipleValues"))


class MultiChoiceField(SharePointListField):
    """
    Represents a multi-choice field in a SharePoint list.
    """

    @property
    def choices(self) -> List[str]:
        """Available choices for the field."""
        return self.get("Choices", {}).get("results", [])


class NumberField(SharePointListField):
    """
    Represents a number field in a SharePoint list.
    """

    @property
    def decimal_places(self) -> Optional[int]:
        """Number of decimal places to display."""
        return self.get("Decimals")

    @property
    def min_value(self) -> Optional[float]:
        """Minimum allowed value."""
        return self.get("MinimumValue")

    @property
    def max_value(self) -> Optional[float]:
        """Maximum allowed value."""
        return self.get("MaximumValue")


class TextField(SharePointListField):
    """
    Represents a text field in a SharePoint list.
    """

    @property
    def max_length(self) -> Optional[int]:
        """Maximum length of the text field."""
        return self.get("MaxLength")


class BooleanField(SharePointListField):
    """
    Represents a boolean field in a SharePoint list.
    """

    @property
    def true_display_name(self) -> Optional[str]:
        """Display name for True values."""
        return self.get("Customization", {}).get("TrueText")

    @property
    def false_display_name(self) -> Optional[str]:
        """Display name for False values."""
        return self.get("Customization", {}).get("FalseText")


class ComputedField(SharePointListField):
    """
    Represents a computed field in a SharePoint list.
    """

    @property
    def formula(self) -> Optional[str]:
        """Formula used to calculate the field value."""
        return self.get("Formula")

    @property
    def output_type(self) -> Optional[str]:
        """Data type of the computed field's output."""
        return self.get("OutputType")
