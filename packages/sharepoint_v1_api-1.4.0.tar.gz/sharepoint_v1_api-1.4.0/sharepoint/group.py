from typing import List, Optional

from ._base import SharePointBase
from ._odata_utils import build_query_url
from .user import SharePointUser


class SharePointGroup(SharePointBase):
    """
    Represents a SharePoint group.

    Provides methods and properties for interacting with SharePoint groups.
    """

    # -----------------------------------------------------------------
    # Properties
    # -----------------------------------------------------------------

    @property
    def title(self) -> Optional[str]:
        """Group title."""
        return self.get("Title", None)

    @property
    def guid(self) -> str:
        """Group ID."""
        return self.get("Id", "")

    @property
    def _users_url(self) -> str:
        """URL to retrieve users in this group."""
        users_data = self.get("Users")
        if users_data is None:
            users_data = {}
        if isinstance(users_data, dict):
            deferred_data = users_data.get("__deferred", {})
            if isinstance(deferred_data, dict):
                return deferred_data.get("uri", "")
        return ""

    # -----------------------------------------------------------------
    # Methods
    # -----------------------------------------------------------------

    def get_users(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        top: Optional[int] = None,
    ) -> List[SharePointUser]:
        """
        Return a collection of users in this group.

        Parameters
        ----------
        filters : Optional[str]
            OData filter expression.
        select_fields : Optional[List[str]]
            OData $select fields.
        top : Optional[int]
            OData $top limit.

        Returns
        -------
        List[SharePointUser]
            Collection of users in the group.
        """
        if not self._users_url:
            raise ValueError("Users deferred URI not available for this group")

        # Build the query URL with OData parameters
        query_url = build_query_url(
            self._users_url,
            filters=filters,
            select_fields=select_fields,
            top=top,
        )

        # Get the users data from the API
        r = self._api.get(query_url)

        # Parse the results into SharePointUser objects
        results = r.json().get("d", {}).get("results", [])
        return [
            SharePointUser(user.get("__metadata", {}).get("uri"), self._api.session)
            for user in results
        ]
