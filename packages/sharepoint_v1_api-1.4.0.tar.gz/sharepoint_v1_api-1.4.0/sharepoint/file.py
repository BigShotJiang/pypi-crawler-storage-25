from __future__ import annotations

from datetime import datetime
from urllib.parse import urljoin

from ._base import SharePointBase


class SharePointFile(SharePointBase):
    """
    Represents a file in a SharePoint document library or folder.

    Provides methods for file operations such as downloading content, checking in/out,
    publishing, and deleting files.
    """

    _base_url = None

    # -----------------------------------------------------------------
    # Properties
    # -----------------------------------------------------------------

    @property
    def base_url(self) -> str:
        """Base URL of the SharePoint site (without the '_api' part)."""
        if not self._base_url:
            self._base_url = self._url.split("_api")[0]
        return self._base_url

    @property
    def _form_digestive_value(self) -> str:
        """Form digest value required for POST/PUT/MERGE operations."""
        context_url = urljoin(self.base_url, "_api/contextinfo")
        r = self._api.post(context_url, {})
        return r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

    @property
    def name(self) -> str | None:
        """File name."""
        return self.get("Name")

    @property
    def server_relative_url(self) -> str | None:
        """Server-relative URL of the file."""
        return self.get("ServerRelativeUrl")

    @property
    def time_created(self) -> datetime | None:
        """Timestamp when the file was created."""
        return self.get_datetime("TimeCreated")

    @property
    def time_last_modified(self) -> datetime | None:
        """Timestamp when the file was last modified."""
        return self.get_datetime("TimeLastModified")

    @property
    def length(self) -> int | None:
        """Size of the file in bytes."""
        return self.get("Length")

    @property
    def etag(self) -> str | None:
        """Entity tag of the file."""
        return self.get("ETag")

    @property
    def major_version(self) -> int | None:
        """Major version number of the file."""
        return self.get("MajorVersion")

    @property
    def minor_version(self) -> int | None:
        """Minor version number of the file."""
        return self.get("MinorVersion")

    @property
    def title(self) -> str | None:
        """Title of the file."""
        return self.get("Title")

    @property
    def check_out_type(self) -> int | None:
        """Checkout type of the file."""
        return self.get("CheckOutType")

    @property
    def level(self) -> int | None:
        """Level of the file (draft, published, etc.)."""
        return self.get("Level")

    @property
    def ui_version(self) -> int | None:
        """UI version of the file."""
        return self.get("UIVersion")

    @property
    def ui_version_label(self) -> str | None:
        """UI version label of the file."""
        return self.get("UIVersionLabel")

    # -----------------------------------------------------------------
    # File Operations
    # -----------------------------------------------------------------

    def get_content(self) -> bytes:
        """
        Download the content of the file.

        Returns
        -------
        bytes
            The file content as bytes.
        """
        # The $value endpoint returns the raw file content
        content_url = f"{self._url}/$value"
        r = self._api.get(content_url)
        return r.content

    def delete(self) -> bool:
        """
        Delete the file.

        Returns
        -------
        bool
            True if the deletion succeeded, False otherwise.
        """
        try:
            r = self._api.post_complex(
                self._url,
                post_data=None,
                form_digest_value=self._form_digestive_value,
                x_http_method="DELETE",
            )
            return r.ok
        except Exception:
            return False

    def checkout(self) -> bool:
        """
        Check out the file for editing.

        Returns
        -------
        bool
            True if the checkout succeeded, False otherwise.
        """
        try:
            checkout_url = f"{self._url}/checkout"
            r = self._api.post(
                checkout_url, {}, form_digest_value=self._form_digestive_value
            )
            return r.ok
        except Exception:
            return False

    def checkin(self, comment: str = "") -> bool:
        """
        Check in the file after editing.

        Parameters
        ----------
        comment : str, optional
            Check-in comment (default is empty string).

        Returns
        -------
        bool
            True if the checkin succeeded, False otherwise.
        """
        try:
            checkin_url = f"{self._url}/checkin(comment='{comment}')"
            r = self._api.post(
                checkin_url, {}, form_digest_value=self._form_digestive_value
            )
            return r.ok
        except Exception:
            return False

    def publish(self, comment: str = "") -> bool:
        """
        Publish the file.

        Parameters
        ----------
        comment : str, optional
            Publishing comment (default is empty string).

        Returns
        -------
        bool
            True if the publishing succeeded, False otherwise.
        """
        try:
            publish_url = f"{self._url}/publish(comment='{comment}')"
            r = self._api.post(
                publish_url, {}, form_digest_value=self._form_digestive_value
            )
            return r.ok
        except Exception:
            return False

    def unpublish(self, comment: str = "") -> bool:
        """
        Unpublish the file.

        Parameters
        ----------
        comment : str, optional
            Unpublishing comment (default is empty string).

        Returns
        -------
        bool
            True if the unpublishing succeeded, False otherwise.
        """
        try:
            unpublish_url = f"{self._url}/unpublish(comment='{comment}')"
            r = self._api.post(
                unpublish_url, {}, form_digest_value=self._form_digestive_value
            )
            return r.ok
        except Exception:
            return False

    def undo_checkout(self) -> bool:
        """
        Undo the checkout of the file.

        Returns
        -------
        bool
            True if the undo checkout succeeded, False otherwise.
        """
        try:
            undo_url = f"{self._url}/undocheckout"
            r = self._api.post(
                undo_url, {}, form_digest_value=self._form_digestive_value
            )
            return r.ok
        except Exception:
            return False

    def recycle(self) -> bool:
        """
        Move the file to the recycle bin.

        Returns
        -------
        bool
            True if the recycle operation succeeded, False otherwise.
        """
        try:
            recycle_url = f"{self._url}/recycle"
            r = self._api.post(
                recycle_url, {}, form_digest_value=self._form_digestive_value
            )
            return r.ok
        except Exception:
            return False
