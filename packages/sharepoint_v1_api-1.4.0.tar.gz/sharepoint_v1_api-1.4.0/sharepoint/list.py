from __future__ import annotations

from typing import TYPE_CHECKING, Generator, List, Optional, TypedDict, Union
from urllib.parse import parse_qs, urljoin, urlparse

import requests

from ._base import SharePointBase
from ._odata_utils import build_query_url
from .list_field import (
    BooleanField,
    ChoiceField,
    ComputedField,
    DateTimeField,
    LookupField,
    MultiChoiceField,
    NumberField,
    PersonOrGroupField,
    SharePointListField,
    TextField,
)
from .list_item import SharePointListItem

if TYPE_CHECKING:
    from .site import SharePointSite

    SPItem = SharePointListItem


class PagedResult(TypedDict):
    items: List["SPItem"]
    next_skiptoken: Optional[str]
    has_next: bool


class SharePointList(SharePointBase):
    """
    Base class representing a SharePoint list.

    Provides common functionality for handling list items, including
    retrieval, addition, and serialization to JSON.

    Specialized field types returned by get_fields():
    - ChoiceField for Choice fields
    - ComputedField for Computed fields
    - LookupField for Lookup fields
    - DateTimeField for DateTime fields
    - PersonOrGroupField for User (Person or Group) fields
    - MultiChoiceField for MultiChoice fields
    - NumberField for Number, Integer, and Counter fields
    - TextField for Text fields
    - BooleanField for Boolean fields
    """

    # Class variable for list item type - can be overridden by subclasses
    SPItem = SharePointListItem

    @classmethod
    def from_relative_url(
        cls,
        base_sharepoint_url: str,
        relative_url: str,
        session: requests.Session,
    ) -> "SharePointList":
        """
        Initialise a :class:`SharePointList` using a base SharePoint URL and a
        server-relative URL.

        Parameters
        ----------
        base_sharepoint_url : str
            The root URL of the SharePoint tenant (e.g. ``https://example.com``).
        relative_url : str
            The server-relative path to the list (e.g. ``/sites/demo/Lists/Tasks``).
        session : requests.Session
            A pre-configured session with authentication.

        Returns
        -------
        SharePointList
            An instance configured with the combined list URL.
        """
        _url = urljoin(base_sharepoint_url, relative_url.lstrip("/"))
        return cls(_url, session)

    settings = None
    _items = None
    _fields = None
    _base_url = None
    sharepoint_site = None

    # -----------------------------------------------------------------
    # Properties
    # -----------------------------------------------------------------

    @property
    def _items_url(self) -> str:
        items_data = self.get("Items", None)
        if items_data and isinstance(items_data, dict):
            deferred_data = items_data.get("__deferred")
            if deferred_data and isinstance(deferred_data, dict):
                return deferred_data.get("uri", "")
        return ""

    @property
    def _fields_url(self) -> str:
        fields_data = self.get("Fields")
        if fields_data and isinstance(fields_data, dict):
            deferred_data = fields_data.get("__deferred")
            if deferred_data and isinstance(deferred_data, dict):
                return deferred_data.get("uri", "")
        return ""

    @property
    def _form_digestive_value(self):
        r = self._api.post(urljoin(self.base_url, "_api/contextinfo"), {})

        return r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

    @property
    def base_url(self) -> str:
        if not self._base_url:
            self._base_url = self._url.split("_api")[0]
        return self._base_url

    @property
    def title(self) -> str:
        """List title."""
        return self.get("Title")

    @property
    def id(self) -> str:
        """List identifier."""
        return self.get("Id")

    def get_fields(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        top: Optional[int] = None,
        orderby_fields: Optional[Union[str, List[str]]] = None,
    ) -> List[SharePointListField]:
        """
        Return a collection of fields for this list.

        Parameters
        ----------
        filters : Optional[str], optional
            OData filter expression
        select_fields : Optional[List[str]], optional
            Fields to include in the response
        top : Optional[int], optional
            Maximum number of fields to return
        orderby_fields : Optional[Union[str, List[str]]], optional
            Field(s) to order the results by. If a list is provided, fields are ordered in sequence.
            Append ``desc`` to a field name for descending order (e.g., ``Title desc``).

        Returns
        -------
        List[SharePointListField]
            List of SharePointListField objects (specialized based on field type)

        Examples
        --------
        >>> fields = sharepoint_list.get_fields()
        >>> len(fields)
        5
        """

        item_url = build_query_url(
            self._fields_url,
            filters=filters,
            select_fields=select_fields or ["Id", "TypeAsString"],
            top=top,
            orderby_fields=orderby_fields,
        )

        r = self._api.get(item_url)
        fields = []

        for sp_list in r.json()["d"]["results"]:
            field_type = sp_list.get("TypeAsString", "")
            field_url = sp_list.get("__metadata", {}).get("uri", "")

            # Instantiate specialized field class based on field type
            if field_type == "Choice":
                field = ChoiceField(field_url, self._api.session, sp_list)
            elif field_type == "Computed":
                field = ComputedField(field_url, self._api.session, sp_list)
            elif field_type == "Lookup":
                field = LookupField(field_url, self._api.session, sp_list)
            elif field_type == "DateTime":
                field = DateTimeField(field_url, self._api.session, sp_list)
            elif field_type == "User":
                field = PersonOrGroupField(field_url, self._api.session, sp_list)
            elif field_type == "MultiChoice":
                field = MultiChoiceField(field_url, self._api.session, sp_list)
            elif field_type in ("Number", "Integer", "Counter"):
                field = NumberField(field_url, self._api.session, sp_list)
            elif field_type == "Text":
                field = TextField(field_url, self._api.session, sp_list)
            elif field_type == "Boolean":
                field = BooleanField(field_url, self._api.session, sp_list)
            else:
                field = SharePointListField(field_url, self._api.session, sp_list)

            fields.append(field)

        return fields

    def get_items(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        top: Optional[int] = None,
        orderby_fields: Optional[Union[str, List[str]]] = None,
    ) -> List["SPItem"]:
        """
        Return a collection of items for this list.

        Parameters
        ----------
        filters : Optional[str], optional
            OData filter expression
        select_fields : Optional[List[str]], optional
            Fields to include in the response
        top : Optional[int], optional
            Maximum number of items to return
        orderby_fields : Optional[Union[str, List[str]]], optional
            Field(s) to order the results by. If a list is provided, fields are ordered in sequence.
            Append ``desc`` to a field name for descending order (e.g., ``Title desc``).

        Returns
        -------
        List[SPItem]
            List of SharePointListItem objects

        Examples
        --------
        >>> items = sharepoint_list.get_items()
        >>> len(items)
        10
        """

        item_url = build_query_url(
            self._items_url,
            filters=filters,
            select_fields=select_fields or ["Id"],
            top=top,
            orderby_fields=orderby_fields,
        )

        r = self._api.get(item_url)
        return [
            self.SPItem(sp_list.get("__metadata", {}).get("uri"), self._api.session)
            for sp_list in r.json()["d"]["results"]
        ]

    def get_items_paged(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        top: Optional[int] = None,
        skiptoken: Optional[str] = None,
        orderby_fields: Optional[Union[str, List[str]]] = None,
    ) -> "PagedResult":
        """
        Return a collection of items for this list along with pagination information.

        Parameters
        ----------
        filters : Optional[str], optional
            OData filter expression
        select_fields : Optional[List[str]], optional
            Fields to include in the response
        top : Optional[int], optional
            Maximum number of items to return
        skiptoken : Optional[str], optional
            Token for pagination to get the next page of results
        orderby_fields : Optional[Union[str, List[str]]], optional
            Field(s) to order the results by. If a list is provided, fields are ordered in sequence.
            Append ``desc`` to a field name for descending order (e.g., ``Title desc``).

        Returns
        -------
        PagedResult
            A dictionary containing:
            - items: List of SPItem objects
            - next_skiptoken: Token for next page (None if no more pages)
            - has_next: Boolean indicating if there are more pages

        Examples
        --------
        >>> result = sharepoint_list.get_items_paged(top=100)
        >>> len(result["items"])
        100
        >>> result["has_next"]
        True
        """

        item_url = build_query_url(
            self._items_url,
            filters=filters,
            select_fields=select_fields or ["Id"],
            top=top,
            skiptoken=skiptoken,
            orderby_fields=orderby_fields,
        )

        r = self._api.get(item_url)
        response_data = r.json()["d"]
        items = [
            self.SPItem(sp_list.get("__metadata", {}).get("uri"), self._api.session)
            for sp_list in response_data["results"]
        ]

        # Extract next skiptoken from __next link if present
        next_skiptoken: Optional[str] = None
        has_next = False

        if "__next" in response_data:
            has_next = True
            next_link = response_data["__next"]
            # Extract skiptoken from the next link
            if "$skiptoken=" in next_link:
                # Extract the skiptoken parameter from the URL
                parsed_url = urlparse(next_link)
                query_params = parse_qs(parsed_url.query)
                if "$skiptoken" in query_params:
                    # The skiptoken value is already properly encoded
                    next_skiptoken = query_params["$skiptoken"][0]

        return {"items": items, "next_skiptoken": next_skiptoken, "has_next": has_next}

    def iterate_all_items(
        self,
        filters: Optional[str] = None,
        select_fields: Optional[List[str]] = None,
        page_size: int = 1000,
        orderby_fields: Optional[Union[str, List[str]]] = None,
    ) -> Generator["SPItem", None, None]:
        """
        Generator that yields all items from the list, handling pagination automatically.

        Parameters
        ----------
        filters : Optional[str], optional
            OData filter expression
        select_fields : Optional[List[str]], optional
            Fields to include in the response
        page_size : int, optional
            Number of items to retrieve per page (default: 1000)
        orderby_fields : Optional[Union[str, List[str]]], optional
            Field(s) to order the results by. If a list is provided, fields are ordered in sequence.
            Append ``desc`` to a field name for descending order (e.g., ``Title desc``).

        Yields
        ------
        SPItem
            Individual list items

        Examples
        --------
        >>> for item in sharepoint_list.iterate_all_items():
        ...     print(item.id)
        """
        skiptoken = None

        while True:
            page_result = self.get_items_paged(
                filters=filters,
                select_fields=select_fields,
                top=page_size,
                skiptoken=skiptoken,
                orderby_fields=orderby_fields,
            )

            # Yield each item in the current page
            for item in page_result["items"]:
                yield item

            # If there are no more pages, break the loop
            if not page_result["has_next"]:
                break

            # Set the skiptoken for the next iteration
            skiptoken = page_result["next_skiptoken"]

    def get_item(
        self,
        item_id: str,
    ) -> "SPItem":
        """
        Return a :class:`SharePointListItem` for the given item ID.

        Parameters
        ----------
        item_id : str
            The ID of the item to retrieve.

        Returns
        -------
        SPItem
            A SharePointListItem object for the specified item

        Examples
        --------
        >>> item = sharepoint_list.get_item("1")
        >>> item.id
        '1'
        """
        # Remove trailing slash from base URL and ensure we don't have a leading slash in the relative path
        base_url = self._url.rstrip("/")
        relative_path = f"items({item_id})"
        list_item_url = urljoin(base_url + "/", relative_path)
        return self.SPItem(list_item_url, self._api.session)

    def get_parent_site(self) -> "SharePointSite":
        """
        Retrieve the parent SharePoint site of this list.
        """
        from .site import SharePointSite

        site_url = urljoin(self.base_url, "_api/Web")
        return SharePointSite(url=site_url, session=self._api.session)

    def create_item(self, data) -> "SPItem":
        base_url = self._url.split("_api")[0]
        r = self._api.post(urljoin(base_url, "_api/contextinfo"), {})

        form_digest_value = r.json()["d"]["GetContextWebInformation"]["FormDigestValue"]

        r = self._api.post(self._items_url, data, form_digest_value)

        metadata = r.json()["d"].get("__metadata", {})
        list_item_url = metadata.get("uri", "")
        return self.SPItem(list_item_url, self._api.session)

    def delete_item(self, item_id: str) -> bool:
        """
        Delete a list item by its ID.

        Parameters
        ----------
        item_id : str
            The ID of the item to delete.

        Returns
        -------
        bool
            True if the deletion succeeded, False otherwise.

        Raises
        ------
        requests.HTTPError
            If the deletion request fails.
        """
        # Get the specific item
        item = self.get_item(item_id)

        # Delete the item using the SharePointListItem's delete method
        return item.delete_item()
