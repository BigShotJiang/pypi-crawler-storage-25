# Axiom 2026 OKRs

> **Last Updated:** April 2, 2026
> **Planning Horizon:** Q2-Q4 2026 (Q1 complete)
> **Aligned With:** [Executive PRD](prd-executive.md), [Digital Twin Hosting PRD](prd-digital-twin-hosting.md), [Model Corral PRD](prd-model-corral.md), [RAG PRD](prd-rag.md), [Prompt Registry PRD](prd-prompt-registry.md)
>
> **Scope:** This document covers **platform-level** objectives for the Axiom framework. Domain-specific objectives (e.g., nuclear operations, facility-specific workflows) live in downstream product OKRs (see [axiom OKRs](https://github.com/…/Neutron_OS/docs/prds/prd-okrs-2026.md)).
>
> **Major update (2026-03-26):** Split from combined OKRs into platform-only objectives. Nuclear-domain objectives (Reactor Ops, Medical Isotope) moved to axiom OKRs. SeaweedFS replaced with S3-compatible object storage (Ceph/Rook recommended).

---

## PRD → OKR Linkage Matrix

| PRD | OKR Objective | Implementation Status |
|-----|---------------|----------------------|
| [Executive PRD](prd-executive.md) | All | ✅ Platform shipped (v0.4.1) |
| [CLI PRD](prd-axi-cli.md) | All | ✅ Shipped |
| [Agent Platform PRD](prd-agents.md) | O1, O5, O6, **O7** | ✅ Platform shipped; D-FIB absorbed SECUR-T security functions (30 tests); intelligence layer planned |
| [Agent State Mgmt PRD](prd-agent-state-management.md) | O1, O5 | ✅ Shipped |
| [Publisher PRD](prd-publisher.md) | O5 | ✅ Shipped |
| [Connections PRD](prd-connections.md) | O1, O3, O5 | ✅ Active (v0.4.2 shipped) |
| [RAG PRD](prd-rag.md) | **O7**, O1 | 📋 Spec'd |
| [Prompt Registry PRD](prd-prompt-registry.md) | **O7** | 📋 Spec'd |
| [Digital Twin Hosting PRD](prd-digital-twin-hosting.md) | **O1**, O4, O6 | 📋 Spec'd |
| [Model Corral PRD](prd-model-corral.md) | **O2** | 📋 Spec'd |
| [Data Platform PRD](prd-data-platform.md) | **O3**, O1, O4 | 📋 Spec'd |
| [Analytics Dashboards PRD](prd-analytics-dashboards.md) | O1, O3 | 🔲 Not started |
| [Auto-Research PRD](prd-auto-research.md) | **O7** | 🟡 Partial (Call to Research: 34 tests, knowledge observatory: tested, WASM sandbox: tested) |
| [Security & Access Control PRD](prd-security.md) | O5, O6 | 🟡 Partial (D-FIB security [formerly SECUR-T]: 30 tests, content sanitizer: 37 tests, chaos: 13 tests) |
| [Media Library PRD](prd-media-library.md) | O5 | 🔲 Not started |

**Domain-specific PRDs** (System Ops Log, Compliance Tracking, Scheduling, Experiment Manager, Medical Isotope) are tracked in downstream product OKRs, not here.

---

## Immediate Priorities (Q2 2026)

These are the concrete deliverables that matter most in the next 6-8 weeks:

### 1. Ondrej's Deployment — WALL-E agent (Neut) + Qwen on Private-Server + RAG
**Who:** Ondrej (first external operator user)
**What:** WALL-E agent (Neut) running in VS Code, routing `axiom chat` to Qwen on Private-Server, with a loaded RAG corpus answering real questions.
**Why now:** Validates the self-hosted LLM path end-to-end on real hardware. First external user deployment. Shows the product works outside Ben's laptop.
**Blockers to clear:** Private-Server k3d + containerd setup (ADR-013), Qwen provider configured in models.toml, RAG corpus loaded (community v1 or facility docs), VS Code extension working.

### 2. Model Corral v1 — First Users
**Who:** First researchers needing model registry access
**What:** `axiom model` CLI working — register, search, pull physics models. Basic Model Corral schema deployed.
**Why now:** Immediate user need. Model Corral is already spec'd. This is spec → implementation, not new design work.
**Blockers to clear:** model.yaml manifest schema, PostgreSQL schema migration, `axiom model search/add/pull/validate` CLI commands.

### 3. Intelligence Platform Phase 1 — Interaction Log + Prompt Registry
**Who:** Platform (enables knowledge maturity pipeline)
**What:** Interaction log writing on every completion, feedback signals, prompt template registry shipped.
**Why now:** Every day without the interaction log is interaction data we're not capturing. The knowledge flywheel can't start spinning until logging is in place.

---

## Current State Summary (March 2026)

### ✅ Shipped (Q4 2025 - Q1 2026)

| Component | Status | Description |
|-----------|--------|-------------|
| **LLM Gateway** | ✅ Shipped | Multi-provider routing with export control classification |
| **Signal Agent** | ✅ Shipped | Voice/Teams/GitLab → extractors → correlator → synthesizer |
| **Chat Agent** | ✅ Shipped | Interactive LLM with tool use, RAG, per-turn routing |
| **Publisher** | ✅ Shipped | Markdown → generate → publish to 19 endpoints |
| **RAG** | ✅ Shipped | Three-tier corpus (community/org/personal), pgvector |
| **M-O Agent** | ✅ Shipped | Resource steward, scratch lifecycle, retention |
| **State Store** | ✅ Shipped | Hybrid file + PostgreSQL backend |
| **CLI Framework** | ✅ Shipped | `axiom <noun> <verb>` with extension discovery |
| **Connections** | ✅ Shipped | Connection registry, credential resolution, managed service lifecycle (v0.4.2) |
| **Demo** | ✅ Shipped | 9-act guided walkthrough ("Jay's Story") |

### 📋 Spec'd (Ready for Implementation)

| Component | PRD | Spec | Target |
|-----------|-----|------|--------|
| **Prompt Template Registry** | [PRD](prd-prompt-registry.md) | [Spec](../tech-specs/spec-prompt-registry.md) | Q2 2026 |
| **Agentic RAG + Knowledge Maturity** | [PRD](prd-rag.md) | [Spec §14](../tech-specs/spec-rag-architecture.md) + [Maturity Spec](../tech-specs/spec-rag-knowledge-maturity.md) | Q2-Q3 2026 |
| **Community Corpus Federation** | [PRD](prd-rag.md) | [Spec](../tech-specs/spec-rag-community.md) | Q3-Q4 2026 (core infra ✅, sync protocol 🔲) |
| **Model Corral** | [PRD](prd-model-corral.md) | [Spec](../tech-specs/spec-model-corral.md) | Q2 2026 |
| **Digital Twin Hosting** | [PRD](prd-digital-twin-hosting.md) | [Spec](../tech-specs/spec-digital-twin-architecture.md) | Q2-Q4 2026 |
| **Data Lakehouse** | [PRD](prd-data-platform.md) | [Spec](../tech-specs/spec-data-architecture.md) | Q2 2026 |
| **Private-Server EC Staging** | [ADR-013](adr-013-private-server-ec-staging.md) | `infra/environments/private-server/` | Q2 2026 |

---

## Objective 1: Digital Twin Foundation
> Establish generic infrastructure for ROM execution and Shadow simulations

**Aligns with:** [Digital Twin Hosting PRD](prd-digital-twin-hosting.md) Phases 1-2

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| Run tracking schema deployed | PostgreSQL tables live | Q2 | 🔲 |
| `axiom twin run/status` CLI working | Commands operational | Q2 | 🔲 |
| Shadow automation for first facility | Nightly runs | Q2 | 🔲 |
| ROM-2 inference operational | <20s latency | Q3 | 🔲 |
| Prediction vs measured comparison | Dashboard live | Q3 | 🔲 |

### Supporting Work
- [ ] Define `dt_runs`, `dt_run_states`, `dt_run_validations` schema
- [ ] Integrate SLURM job submission for secure HPC
- [ ] Complete WASM surrogate runtime (from spike)
- [ ] Build ROM-2 training pipeline
- [ ] Create basic Superset dashboards for validation

---

## Objective 2: Model Registry (Model Corral)
> Physics models versioned, searchable, validated, and federation-ready

**Aligns with:** [Model Corral PRD](prd-model-corral.md)

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| `axiom model` CLI working | search/add/pull/validate | Q2 | 🔲 |
| Model Corral schema deployed | PostgreSQL + S3 | Q2 | 🔲 |
| First facility models migrated | 10+ models in registry | Q2 | 🔲 |
| Web catalog UI | Browse + upload wizard | Q3 | 🔲 |
| Git sync operational | Bidirectional with lab repos | Q3 | 🔲 |
| Federated model artifact support | `federation_round`, `participating_facilities`, `aggregation_method` fields in `model.yaml` | Q3 | 🔲 |

### Supporting Work
- [ ] Implement `model.yaml` manifest schema validation
- [ ] Build ROM extension fields (training provenance, tier)
- [ ] Create validation framework (schema, file, syntax checks)
- [ ] Integrate with RAG for model documentation search
- [ ] Add federated model fields to `model.yaml` schema and validation

---

## Objective 3: Data Platform Maturity
> Bronze/Silver/Gold lakehouse operational with dbt transforms

**Aligns with:** [Data Platform PRD](prd-data-platform.md)

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| Iceberg tables operational | Bronze layer populated | Q2 | 🔲 |
| dbt models for facility data | Silver layer transforms | Q2 | 🔲 |
| Dagster orchestration | Scheduled pipelines | Q3 | 🔲 |
| Streaming ingest (Kafka) | <10s latency | Q3 | 🔲 |
| Gold layer KPIs | Superset dashboards | Q3 | 🔲 |

### Supporting Work
- [ ] Deploy S3-compatible object storage (Ceph/Rook recommended)
- [ ] Create dbt project structure
- [ ] Define Bronze schemas for generic data sources (time-series, logs, agent state)
- [ ] Build Silver transforms for data quality
- [ ] Configure Dagster schedules and sensors

---

## Objective 4: Real-Time Predictions (ROM-1)
> Control room display shows ROM predictions alongside sensors

**Aligns with:** [Digital Twin Hosting PRD](prd-digital-twin-hosting.md) Phase 3

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| ROM-1 inference <100ms | 10 Hz update rate | Q4 | 🔲 |
| Streaming integration | Kafka → ROM-1 | Q4 | 🔲 |
| WebSocket endpoint | Real-time predictions | Q4 | 🔲 |
| Control room display | Sensor + prediction overlay | Q4 | 🔲 |

### Supporting Work
- [ ] Optimize ROM-1 WASM module for latency
- [ ] Build WebSocket server for real-time push
- [ ] Create divergence alerting system
- [ ] Document uncertainty bounds

---

## Objective 5: Community & Adoption
> Researchers and facility operators actively using Axiom

**Aligns with:** [Publisher PRD](prd-publisher.md), [Security & Access Control PRD](prd-security.md), [Media Library PRD](prd-media-library.md), [Connections PRD](prd-connections.md)

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| Demo deployed publicly | Web-accessible | Q2 | 🔲 |
| Documentation site | Searchable docs | Q2 | 🔲 |
| User feedback mechanism | In-app feedback | Q3 | 🔲 |
| 10+ active weekly users | WAU metric | Q4 | 🔲 |

### Supporting Work
- [ ] Deploy demo environment (non-VPN accessible)
- [ ] Create onboarding tutorials
- [ ] Implement analytics (Plausible or PostHog)

---

## Objective 6: Multi-Facility Foundation + Federation
> Architecture ready for second facility deployment; federation partnerships grounded in working infrastructure

**Aligns with:** [Digital Twin Hosting PRD](prd-digital-twin-hosting.md) Phase 4

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| Facility provider abstraction | Generic interface | Q4 | 🔲 |
| Private-Server live — first external deployment validated | k3d + containerd deployed, Qwen running | Q2 | 🔲 |
| VS Code → WALL-E agent (Neut) → Qwen (Private-Server) → RAG path end-to-end | Ondrej running `axiom chat` with RAG | Q2 | 🔲 |
| Community corpus federation v1 (bilateral) | Facts flowing between 2 sites | Q4 | 🔲 |
| Deployment playbook documented | Private-Server → PrivateCloud path | Q3 | 🔲 |
| 1+ external facility expressing interest | Letter of intent | Q4 | 🔲 |
| Federation v1 core infrastructure | Identity, discovery, trust, .axiompack, security, CLI | Q2 | ✅ (254 tests) |

### Supporting Work
- [x] Federation identity (Ed25519 keypair, node_id, NodeManifest, A2A Agent Cards) — 28 tests
- [x] Node discovery (NodeRegistry, NodeState 8-state machine, SSH + A2A transport)
- [x] Trust bootstrap (InvitationToken, 24h TTL, create/validate)
- [x] .axiompack format (create, verify, extract, install, remove) — 21 tests
- [x] Pack server client (list, download, publish, health_check)
- [x] EC safety guard (export_controlled blocked locally, allowed in PrivateCloud)
- [x] ~~SECUR-T~~ security service (content verification, anomaly detection, trust scoring) — 30 tests — **Retired: absorbed by D-FIB**
- [x] Content sanitizer (14 prompt injection categories) — 37 tests
- [x] Chaos test framework (6 scenarios) — 13 tests
- [x] CLI: `axi federation` (7), `axi nodes` (5), `axi security` (8), `axi chaos` (3) — 31 CLI tests
- [ ] Abstract facility-specific code into provider
- [ ] Document facility provider contract
- [ ] Set up k3d + containerd on Private-Server (ADR-013)
- [ ] Create `infra/environments/private-server/` Terraform target
- [ ] Validate EC dual-store architecture on Private-Server hardware
- [ ] Cost model for deployment

---

## Objective 7: Intelligence Platform
> Build the compound knowledge flywheel: every interaction makes the system smarter

**Aligns with:** [RAG PRD](prd-rag.md), [Prompt Registry PRD](prd-prompt-registry.md), [Agent Platform PRD](prd-agents.md), [Auto-Research PRD](prd-auto-research.md)

The intelligence platform closes the loop between user interactions and corpus quality. The interaction log captures every RAG completion tuple. The knowledge maturity pipeline evaluates those interactions and crystallizes recurring validated facts via EVE. The prompt registry ensures all agent prompts are versioned, auditable, and cache-efficient. Together these form a self-improving knowledge flywheel that compounds with usage rather than degrading.

| Key Result | Target | Timeline | Status |
|------------|--------|----------|--------|
| Interaction log deployed and writing on every completion | 100% completion coverage | Q2 | 🟡 (spec'd — PG session store provides interaction log as a view over `session_messages`. See [spec-session-store.md](../tech-specs/spec-session-store.md)) |
| Agentic RAG (heuristic query planner + context evaluator) | ≥70% queries resolved single-pass | Q2 | 🔲 |
| Prompt Template Registry shipped, EC preamble migrated | All agent prompts versioned | Q2 | 🔲 |
| Prompt cache hit ratio ≥60% for active sessions | Measured via `axiom_llm_cache_hit_ratio` | Q3 | 🔲 |
| EVE crystallization producing approved facts | ≥5 approved community facts/week | Q3 | 🔲 |
| M-O knowledge sweep operational | Weekly sweeps with ≥90% GREEN/YELLOW rate | Q3 | 🔲 |
| Community corpus federation v1 (bilateral) | Facts flowing between 2 sites | Q4 | 🔲 |
| Observability dashboard live | All 35 metrics visible | Q3 | 🔲 |
| Call to Research (5 levels, composable DAG chains) | `axi research` CLI (7 commands) | Q2 | ✅ (34 tests) |
| Knowledge observatory (velocity/accumulation/impact) | `axi knowledge` CLI (6 commands) | Q2 | ✅ (tested) |
| CURI-O research core shipped | `axi curio research` with RAG sources, synthesis, knowledge feedback. REPL Eval: CURI-O validates research outputs in the REPL loop before promotion. | Q3 | 🔲 |
| CURI-O external sources + standing orders | arXiv, web, domain connectors, `axi curio watch` | Q4 | 🔲 |

### Supporting Work
- [ ] Deploy session store schema (`sessions` + `session_messages` tables) — Alembic migration. The `interaction_log` is a SQL view over `session_messages`, not a separate table. See [spec-session-store.md](../tech-specs/spec-session-store.md).
- [ ] Wire `PGSessionStore` into ChatAgent so every completion writes to `session_messages` (covers interaction log automatically)
- [ ] Implement feedback signal capture (thumbs up/down in `axiom chat`)
- [ ] Implement heuristic query planner in `store.py` (is retrieval needed? which tier/scope?)
- [ ] Implement heuristic context evaluator in `store.py` (sufficient context? or retrieve again?)
- [ ] Ship `TemplateRegistry` + `axiom prompt` CLI
- [ ] Migrate `_EC_HARDENED_PREAMBLE` to versioned template
- [ ] Wire `cache_control` headers in `gateway._build_messages()`
- [ ] Ship EVE crystallization pipeline (Evaluator-Optimizer)
- [ ] Create `knowledge_facts` table + schema
- [ ] Ship GREEN/YELLOW/RED trust gradient in promotion policy
- [ ] Ship M-O knowledge maturity sweep
- [ ] Ship `axiom rag review` CLI
- [ ] Ship `axiom metrics` CLI from log aggregation
- [ ] Build federation sync v1 pull endpoint
- [ ] Ship CURI-O research core — task lifecycle, planner, RAG sources, synthesis, report generation ([spec](../tech-specs/spec-auto-research.md))
- [ ] Ship source connector framework + extension point
- [ ] Ship standing orders + briefing generator
- [ ] Ship CURI-O → knowledge maturity feedback loop (proposed facts → `axi rag review`)

---

## Implementation Priority List

> Updated 2026-03-26. Order reflects dependency chain and stakeholder value.

### v0.4.2: Connections ✅ SHIPPED

- [x] Connection registry + credential resolution (env → settings → file)
- [x] `axiom connect` CLI with tab completion, health checks, JSON
- [x] Declare `[[connections]]` in all builtin extension manifests (11 connections)
- [x] Integrate connections into `axiom status`
- [x] Capabilities (read/write), usage tracking, throttle detection
- [x] Adaptive rate limiter (learns from API response headers)
- [x] Managed service lifecycle (launchd/systemd/Windows)
- [x] D-FIB self-healing for connection failures
- [x] Embedding provider fallback (OpenAI → Ollama → skip)
- [x] Migrate extractors to `get_credential()` (8 files)
- [x] Auth method negotiation (browser, graph_api, manual)
- [x] Playwright browser auth with session persistence
- [x] Provider preference chain (`routing.prefer_provider`)
- [x] VPN failure guidance (configurable per connection)
- [x] `axiom connect qwen-private-server` configures EC routing
- [x] Extension metadata fully documented (ConnectionDef docstring, contract docs, scaffold)

### v0.4.3: Intelligence Platform — Phase 1 (Q2 2026)

- [ ] Interaction log schema + Alembic migration
- [ ] Write `interaction_log` on every RAG completion
- [ ] Feedback signal capture (thumbs up/down in `axiom chat`)
- [ ] Heuristic query planner (is retrieval needed? which tier/scope?)
- [ ] Heuristic context evaluator (sufficient context? or retrieve again?)
- [ ] Prompt Template Registry + `axiom prompt` CLI
- [ ] Migrate `_EC_HARDENED_PREAMBLE` to versioned template
- [ ] `axiom metrics` CLI from log aggregation

### v0.4.4: Private-Server + Ondrej Deployment (Q2 2026)

- [ ] k3d + containerd install on Private-Server
- [ ] Qwen provider configured in `llm-providers.toml` pointing to Private-Server
- [ ] Community RAG corpus (or facility docs) loaded on Private-Server
- [ ] VS Code → WALL-E agent (Neut) → Qwen → RAG path validated with Ondrej

### v0.5.0: Security — Credential Providers + Routing Profiles

- [ ] OS Keychain credential provider (macOS/Linux/Windows)
- [ ] Credential metadata (saved_at, expires_at, last_verified)
- [ ] `axiom connect --migrate` (.env → Keychain)
- [ ] M-O credential expiry watch
- [ ] EVE secret leak scanning
- [ ] Per-agent routing profiles (chat, extraction, diagnosis, embedding, classification)

### v0.5.x: Security — Identity (Ory Kratos)

- [ ] Deploy Kratos as managed service
- [ ] `axiom login` / `axiom logout` / `axiom whoami`
- [ ] Local registration + TOTP MFA
- [ ] OAuth (Google, Microsoft, GitHub, GitLab) via Kratos
- [ ] Session management + identity in agent context

### v0.5.5: Intelligence Platform — Phase 2 (Q3 2026)

- [ ] EVE crystallization pipeline (Evaluator-Optimizer)
- [ ] `knowledge_facts` table + schema
- [ ] GREEN/YELLOW/RED trust gradient in promotion policy
- [ ] M-O knowledge maturity sweep
- [ ] `axiom rag review` CLI
- [ ] Prompt `cache_control` headers wired (requires prompt registry)
- [ ] `axiom eval regression` CLI

### v0.6.0: Security — Authorization (OpenFGA) + Connections Phase 3

- [ ] Deploy OpenFGA as managed service
- [ ] Kratos → OpenFGA webhook bridge
- [ ] Connection-level access control (who can use which provider)
- [ ] Document/corpus-level access control (who can query which RAG corpus)
- [ ] LDAP/AD, OIDC, SAML via Kratos
- [ ] `axiom connect` shows authorization status per user

### v0.6.x: Security — EC Defense Layers

- [ ] Chunk sanitization, response scanning, prompt hardening
- [ ] Security audit log (PostgreSQL + HMAC)
- [ ] `axiom doctor --security` + red-team suite (promptfoo)

### v0.7.0: Security — OpenBao + Rotation

- [ ] BaoProvider for production deployments (OpenBao — Vault-API-compatible, MPL 2.0)
- [ ] `axiom connect --migrate --target bao`
- [ ] Automatic credential rotation

### v0.7.x+: Data Platform + Digital Twin

- [ ] Data Platform (Iceberg, dbt, Bronze/Silver layers, Ceph/Rook object storage)
- [ ] Model Corral (`axiom model` CLI)
- [ ] DT run tracking schema
- [ ] Shadow automation for first facility

---

## Quarterly Roadmap Summary

### Q2 2026: Intelligence Platform Phase 1 + Private-Server Staging + Security Routing Profiles
**Theme:** Intelligence Platform Phase 1 + Private-Server staging + Security routing profiles

- Ship interaction log, query planner, context evaluator (v0.4.3)
- Ship Prompt Template Registry + `axiom prompt` CLI
- Deploy Private-Server k3d + containerd, validate EC dual-store (v0.4.4)
- Ship Security credential providers + routing profiles (v0.5.0)
- Deploy Iceberg + dbt Bronze/Silver layers
- Ship Model Corral with `axiom model` CLI
- Deploy public demo environment

### Q3 2026: Intelligence Platform Phase 2 + ROM-2
**Theme:** Intelligence Platform Phase 2 + ROM-2 + Data Platform Gold layer

- Ship EVE crystallization pipeline + knowledge maturity sweep (v0.5.5)
- Ship `axiom rag review`, `axiom eval regression` CLIs
- ROM-2 inference with <20s latency
- Prediction vs measured dashboards
- dbt Gold layer KPIs
- Kafka streaming ingest
- Deployment playbook (Private-Server → PrivateCloud path)

### Q4 2026: Real-Time + Community Corpus Federation v1 + Multi-Facility Prep
**Theme:** Real-Time + Community corpus federation v1 + Multi-facility prep

- ROM-1 at 10 Hz in control room display
- Community corpus federation v1 (bilateral)
- Federated model artifact support
- Facility provider abstraction
- Pilot facility engagement (1+ letter of intent)
- 10+ active weekly users

---

## Dependencies & Risks

| Risk | Impact | Mitigation |
|------|--------|------------|
| WASM runtime performance | ROM-1 misses latency target | Prototype early, optimize iteratively |
| Secure HPC access (SLURM) | Shadow runs blocked | Work with HPC provider on authentication |
| Streaming complexity (Kafka) | Delayed real-time features | Start with batch, add streaming incrementally |
| ROM accuracy | Can't validate predictions | Increase training data, improve models |
| EVE crystallization quality | Low-trust facts flood corpus | Require human approval gate before community tier promotion |
| Private-Server hardware access | EC staging blocked | Coordinate GPU scheduling early |
| Ondrej's availability for first deployment validation | Medium | Schedule early; don't let this slip to end of quarter |

---

## Review Schedule

| Cadence | Activity |
|---------|----------|
| Weekly | Implementation progress check |
| Monthly | KR scoring, blocker review |
| Quarterly | OKR retrospective, stakeholder update |

---

## Related Documents

### PRDs
- [Executive PRD](prd-executive.md) — Product vision
- [CLI PRD](prd-axi-cli.md) — CLI architecture
- [Agent Platform PRD](prd-agents.md) — Agent capabilities
- [Agent State Mgmt PRD](prd-agent-state-management.md) — State store design
- [Publisher PRD](prd-publisher.md) — Document lifecycle
- [Connections PRD](prd-connections.md) — Credential resolution
- [RAG PRD](prd-rag.md) — Retrieval-augmented generation
- [Prompt Registry PRD](prd-prompt-registry.md) — Versioned prompt templates
- [Digital Twin Hosting PRD](prd-digital-twin-hosting.md) — DT execution infrastructure
- [Model Corral PRD](prd-model-corral.md) — Physics model registry
- [Data Platform PRD](prd-data-platform.md) — Lakehouse architecture
- [Analytics Dashboards PRD](prd-analytics-dashboards.md) — Visualization
- [Security & Access Control PRD](prd-security.md) — Auth & permissions
- [Media Library PRD](prd-media-library.md) — Media asset management

### Tech Specs
- [Executive Tech Spec](../tech-specs/spec-executive.md) — Implementation status
- [Digital Twin Architecture](../tech-specs/spec-digital-twin-architecture.md)
- [Model Corral Spec](../tech-specs/spec-model-corral.md)
- [Data Architecture Spec](../tech-specs/spec-data-architecture.md)
- [Agent Architecture Spec](../tech-specs/spec-agent-architecture.md)
- [Connections Spec](../tech-specs/spec-connections.md)
- [RAG Architecture Spec](../tech-specs/spec-rag-architecture.md)
- [RAG Knowledge Maturity Spec](../tech-specs/spec-rag-knowledge-maturity.md)
- [RAG Community Federation Spec](../tech-specs/spec-rag-community.md)
- [Prompt Registry Spec](../tech-specs/spec-prompt-registry.md)
- [Observability Spec](../tech-specs/spec-observability.md)

### ADRs
- [ADR-011: Concurrent File Writes](adr-011-concurrent-file-writes.md)
- [ADR-012: Provider Identity](adr-012-provider-identity.md)
- [ADR-013: Private-Server EC Staging](adr-013-private-server-ec-staging.md)
