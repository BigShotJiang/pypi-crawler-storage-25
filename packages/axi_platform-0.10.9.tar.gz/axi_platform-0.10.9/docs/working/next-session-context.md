# Next Session Context: CLI Audit + Phase 0 Implementation

## What happened last session (2026-04-13)

We designed and documented the entire Axiom Classroom & Learning Module in a single marathon session. Key deliverables:

### Architecture Decisions
- **Axiom REPL Agent Framework** (`docs/working/axiom-repl-agent-framework.md`): WALL-E=Loop (protagonist/chat, branded as "Neut" in NeutronOS), EVE=Read (signals), CURI-O=Eval (autonomous research), PR-T=Print (publisher+content gate). Mirror and SECUR-T retired. SKILLS.md for all 7 agents.
- **CURI-O Research Loop** (`docs/working/curio-research-loop.md`): Karpathy-style iterative research loop (formulate→search→evaluate→refine→promote) as CURI-O's core primitive. Federation scales it across nodes for distributed convergent research. This is the killer feature.
- **ArtifactRegistry**: Generic versioned-artifact infrastructure extracted from Model Corral. Course and Model Corral are both consumers.

### New PRDs
- **Classroom Module** (`docs/prds/prd-classroom.md`): Course (template) vs Classroom (instance), 11 agent-driven workflows (WF-1 through WF-11), Open WebUI as chat layer, structured Q&A engine, student learning toolkit, multi-label per-turn classification, MVP boundary defined.
- **Evals Framework** (`docs/prds/prd-evals.md`): 11 eval types across all modules, extensible eval type registry, comparative evals, automated gates. Axiom-level, domain-agnostic.

### Tech Specs
- **Classroom Tech Spec** (`docs/specs/tech-spec-classroom.md`): Langfuse/LangSmith trace provider (factory pattern), Open WebUI integration, ArtifactRegistry, Q&A engine, 4 federation topologies, WALL-E+CURI-O classroom skills.
- **LTI/xAPI/Evals Addendum** (`docs/specs/addendum-lti-xapi-evals.md`): LTI 1.3 Advantage Tool Provider (Canvas/Moodle/Blackboard/Brightspace), xAPI + Ralph LRS, eval harness architecture. Needs merging into main tech spec.

### Propagation
- REPL framework propagated to ALL docs: prd-agents.md, CLI PRDs, glossary, canary nodes, auto-research, OKRs, execution plans, AGENT.md delegation refs, source code docstrings. ~30 files updated.

### Drafts (stale, need rewrite)
- Note to Ondrej/Soha (`docs/working/note-ondrej-soha-classroom.md`) — doesn't reflect Open WebUI, evals, LTI, research loop, learning toolkit, REPL framework.

## What to do this session

### 1. CLI Audit (do first)
End-to-end review of all CLI nouns, verbs, and param flags — both existing and new from the classroom/evals/research work. Audit slash commands. Ensure cohesive, intuitive, clean design.

New CLI surface area to design:
- `axi course {create, validate, publish, share, list, show}` — Course artifacts
- `axi classroom {create, status, student, objectives, classify, export, quiz, survey}` — Classroom lifecycle
- `axi eval {create-suite, run, compare, history, report, gate}` — Eval framework
- `axi research {start, status, resume, stop, list, show}` — CURI-O research loops (or is this `axi curio`?)
- `axi questionnaire {create, start, status, export}` — Structured Q&A
- `axi lti {register, status, keys}` — LTI integration
- Existing nouns that may need new verbs: `neut chat`, `neut signal`, `neut pub`, `axi mo`, `neut doctor`, `axi release`

### 2. Rewrite Ondrej/Soha Note
Reflect: Open WebUI, REPL agents, research loop, evals, LTI, learning toolkit, structured Q&A, cross-device sessions. This note is their introduction to what we've built.

### 3. Phase 0 Implementation
Start building (TDD):
- Trace provider protocol + Langfuse implementation
- OpenAI-compatible endpoint in `neut serve`
- Open WebUI deployment on Rascal
- Eval harness + core scorers
- Research loop engine (the core primitive)

### Key files to read
- `docs/working/axiom-repl-agent-framework.md` — agent architecture
- `docs/working/curio-research-loop.md` — research loop design
- `docs/prds/prd-classroom.md` — classroom PRD
- `docs/prds/prd-evals.md` — evals PRD
- `docs/specs/tech-spec-classroom.md` — classroom tech spec
- `docs/specs/addendum-lti-xapi-evals.md` — LTI/xAPI/evals (to merge)
- `docs/working/repl-implementation-impact.md` — what existing code needs changing

### Deployment target
- Rascal (rascal.austin.utexas.edu) — UT campus tower, NOT TACC
- Cloudflare Tunnel for public HTTPS
- Open WebUI + Axiom backend + Langfuse + Ralph LRS
- Prague summer 2026 class (Ondrej + Soha, 12 students)
