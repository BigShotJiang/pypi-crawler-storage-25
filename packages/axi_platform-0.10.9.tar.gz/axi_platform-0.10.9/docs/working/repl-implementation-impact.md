# REPL Framework: Implementation Impact on Existing Code

**Purpose:** Identify where the REPL agent framework impacts already-built source code.  
**Last updated:** 2026-04-13

---

## Source Code Changes Required

### 1. Mirror Agent — Retire

**Files:**
- `axiom/src/axiom/extensions/builtins/mirror_agent/` (entire directory)

**Current state:** Functional agent that hooks into M-O's heartbeat to review commits touching public paths for sensitive content. Maintains a scrub list extracted from `institutional.md`.

**Change:** Mark as retired. Two options:
- **Option A (clean):** Move content filtering logic into PR-T's publish pipeline (`prt_agent/`) as a pre-publish gate function. Move commit scanning into D-FIB's security scan. Delete the `mirror_agent/` directory.
- **Option B (minimal):** Add `enabled = false` to `axiom-extension.toml`. Leave code in place. PR-T and D-FIB call Mirror's filtering functions as a library, not as an agent.

**Recommendation:** Option B for now (minimal disruption), Option A when we next touch PR-T.

---

### 2. SECUR-T References — Retire

**Files:**
- `axiom/src/axiom/federation/security.py` — `SecurityGuardian` class (docstring references SECUR-T)
- `axiom/src/axiom/extensions/builtins/federation/security_cli.py` — CLI descriptions reference SECUR-T
- `axiom/src/axiom/extensions/builtins/federation/axiom-extension.toml` — description: "SECUR-T — federation security guardian"
- `axiom/src/axiom/federation/chaos.py` — chaos scenario strings reference SECUR-T
- `axiom/src/axiom/agents/learning.py` — agent list in docstring includes SECUR-T

**Current state:** SECUR-T was referenced but never built as a standalone agent. The `SecurityGuardian` class in `federation/security.py` is the closest implementation — it's a library, not an agent.

**Change:** 
- Update docstrings/descriptions to reference D-FIB instead of SECUR-T
- `SecurityGuardian` class stays — it's a library that D-FIB invokes
- Federation CLI `security` noun stays — it's the interface to the security functions, now owned by D-FIB
- Update `agents/learning.py` docstring to remove SECUR-T, add WALL-E

---

### 3. Neut Agent — Identity Update (NOT a rename)

**Files:**
- `axiom/src/axiom/extensions/builtins/neut_agent/axiom-extension.toml` — ✅ Already updated by agent
- `axiom/src/axiom/extensions/builtins/neut_agent/agent.py` — `ChatAgent` class
- `axiom/src/axiom/extensions/builtins/neut_agent/fullscreen.py` — TUI
- `axiom/src/axiom/extensions/builtins/neut_agent/providers/` — LLM providers

**Current state:** The chat agent is implemented as `neut_agent` with `ChatAgent` class. This IS WALL-E — just not named that way in code yet.

**Change:** 
- **Do NOT rename the directory or class.** `neut_agent/` and `ChatAgent` are fine as implementation names. The REPL identity lives in SKILLS.md and the extension manifest, not in class names.
- The `axiom-extension.toml` description has already been updated to reference WALL-E.
- No code changes needed — this is a documentation/identity update, not a refactor.

---

### 4. Agent AGENT.md Files — Delegation References

**Files:**
- `axiom/src/axiom/extensions/builtins/eve_agent/AGENT.md` — references "Neut" in delegation section
- `axiom/src/axiom/extensions/builtins/prt_agent/AGENT.md` — references "Neut" in delegation section  
- `axiom/src/axiom/extensions/builtins/dfib_agent/AGENT.md` — references "Neut" in delegation section

**Change:** In each AGENT.md, replace "Neut" with "WALL-E" in delegation descriptions. The new SKILLS.md files provide the REPL-framed identity; the AGENT.md files contain implementation details that reference agent names in delegation patterns.

---

### 5. Canary Nodes — SECUR-T Gate Replacement

**Files:**
- `axiom/docs/specs/spec-canary-nodes.md` — SECUR-T is deeply integrated as the mandatory pre-smoke gate (lines 744-857)
- `axiom/docs/prds/prd-canary-nodes.md` — SECUR-T referenced as gate

**Current state:** The canary node spec has SECUR-T as a mandatory security gate before smoke tests run on a canary deployment.

**Change:** Replace SECUR-T with D-FIB as the pre-smoke security gate. D-FIB already has security scanning skills; this is a natural fit. The gate function itself (scan for sensitive content, validate package integrity) stays the same — only the agent name changes.

**Impact level:** Medium. The canary spec has extensive SECUR-T integration. Needs a focused editing pass.

---

### 6. CLI Noun Mapping

**Files:**
- `axiom/src/axiom/extensions/builtins/*/axiom-extension.toml` — CLI noun definitions

**Current CLI nouns (no changes needed):**
| Agent | CLI Noun | Command |
|-------|----------|---------|
| WALL-E | `chat` | `axi chat` / `neut chat` |
| EVE | `signal` | `neut signal` |
| CURI-O | `research` | `axi research` |
| PR-T | `pub` / `doc` | `neut pub` / `neut doc` |
| M-O | `mo` | `axi mo` |
| D-FIB | `doctor` | `neut doctor` |
| BURN-E | `release` | `axi release` |

**Retired nouns:**
| Agent | CLI Noun | Disposition |
|-------|----------|-------------|
| Mirror | `mirror` | Deprecated — mark in CLI help |
| SECUR-T | `security` | Keep as noun, now owned by D-FIB |

No CLI breaking changes — users' muscle memory is preserved.

---

## Docs That Need Focused Editing Passes (Not Yet Updated)

These are the remaining docs from the impact report that have NOT been updated by the current agents:

| Document | Key Change | Effort |
|----------|-----------|--------|
| `axiom/docs/prds/prd-agents.md` | Full roster rewrite with REPL roles. Canonical doc. | 1 hour |
| `Neutron_OS/docs/prds/prd-agents.md` | Mirror of above | 30 min |
| `axiom/docs/prds/prd-axi-cli.md` | CLI↔agent mapping table update | 15 min |
| `Neutron_OS/docs/prds/prd-neut-cli.md` | Mirror of above | 15 min |
| `Neutron_OS/docs/glossary.md` | Agent naming convention update | 15 min |
| `axiom/docs/prds/prd-auto-research.md` | CURI-O origin story — resolve "WALL-E himself" conflict | 15 min |
| `axiom/docs/specs/spec-auto-research.md` | Agent roster table at line 1302 | 15 min |
| `axiom/docs/specs/spec-canary-nodes.md` | SECUR-T → D-FIB gate replacement (extensive) | 1 hour |
| `axiom/docs/prds/prd-okrs-2026.md` | SECUR-T status, CURI-O OKR alignment | 15 min |
| `axiom/docs/working/execution-plan-2026.md` | "Neut agent" → "WALL-E agent" | 10 min |

**Total remaining effort:** ~4 hours of editing across ~10 docs.

---

## No Code Changes Needed

These source files reference agents by name but the names they use are UNCHANGED by the REPL framework:

- All EVE source code (`eve_agent/`) — EVE identity unchanged
- All M-O source code (`mo_agent/`) — M-O identity unchanged
- All PR-T source code (`prt_agent/`) — PR-T identity unchanged, gains Mirror's gate function
- All D-FIB source code (`dfib_agent/`) — D-FIB identity unchanged, gains SECUR-T duties
- All BURN-E source code (`burn_e_agent/`) — BURN-E identity unchanged
- `neut_agent/agent.py`, `fullscreen.py` — Class names stay (`ChatAgent`), identity lives in SKILLS.md
- `federation/security.py` — `SecurityGuardian` stays as library, docstring update only
- `model_corral/` — References EVE watching model changes, EVE unchanged

**Key principle:** The REPL framework is an identity/documentation change, not a code refactor. Agent directory names, class names, and CLI nouns are stable. Only SKILLS.md files, AGENT.md delegation references, and docs change.
