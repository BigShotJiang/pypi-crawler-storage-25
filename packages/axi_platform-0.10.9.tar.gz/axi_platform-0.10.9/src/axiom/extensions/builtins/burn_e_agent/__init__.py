"""BURN-E — Release and CI/CD pipeline agent.

Named after the construction robot in Wall-E. BURN-E builds and ships things
while Mo keeps them clean after deployment.

Responsibilities:
- CI pipeline monitoring (watches GitHub Actions / GitLab CI)
- Build verification (tests green? lint clean?)
- Version management (bump, tag, changelog)
- PyPI publishing (build wheel, upload, verify propagation)
- Deployment coordination (local -> Rascal -> verify)
- Failure pattern learning (accumulates knowledge from CI failures)
- Release planning integration (ReleasePlanService)
- Handoff to Mo for post-deploy monitoring

Mode detection:
- Developer mode: editable install, watching source repos
- Operator mode: wheel install, watching for upgrades
"""
