"""Axiom agent framework — unified learning and pattern matching."""
