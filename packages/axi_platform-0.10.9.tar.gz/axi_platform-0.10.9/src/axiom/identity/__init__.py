"""Axiom identity: Ed25519 keypairs + Matrix-style principal handles.

Foundation for ADR-020 four identity layers (platform/node/affiliation/
context) and ADR-021 signed-content-addressed findings. Private keys
never leave the process that generated them; verification is a pure
function of public bytes + message + signature.
"""

from __future__ import annotations

from axiom.identity.keypair import Keypair, generate_keypair, verify
from axiom.identity.principal import Principal

__all__ = ["Keypair", "Principal", "generate_keypair", "verify"]
