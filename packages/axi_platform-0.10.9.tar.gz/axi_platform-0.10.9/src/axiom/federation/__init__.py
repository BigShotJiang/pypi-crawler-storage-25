"""Federation — node identity, A2A agent cards, peer discovery, trust,
digest exchange, and signed-finding receive pipeline.

Slice 7 additions (digest + receive) implement ADR-021 P2/P3/P6/P7 on
top of axiom.identity (Ed25519) and axiom.findings (content-addressed
signed findings).
"""

from axiom.federation.digest import Digest, build_digest, verify_digest
from axiom.federation.receive import (
    ReceiveOutcome,
    Rejected,
    receive_digest,
)

__all__ = [
    "Digest",
    "ReceiveOutcome",
    "Rejected",
    "build_digest",
    "receive_digest",
    "verify_digest",
]
