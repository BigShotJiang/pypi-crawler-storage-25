from __future__ import annotations

from pathlib import Path
from typing import Any, ClassVar, List, Literal

from loguru import logger
import numpy as np
from pydantic import ConfigDict, Field
import torch
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioChunk, AudioSpan
from fasr.model import ASRModel
from fasr_asr_qwen3asr.inference import Qwen3ASRModel


def _result_to_text(item: Any) -> str:
    if isinstance(item, str):
        return item.strip()
    if isinstance(item, dict):
        text = item.get("text")
        return "" if text is None else str(text).strip()
    text_attr = getattr(item, "text", None)
    if text_attr is not None:
        return str(text_attr).strip()
    return str(item).strip()


class _Qwen3ForASRBase(ASRModel):
    """Unified base for Qwen3 ASR (vLLM backend), supporting both batch and streaming.

    A single :class:`Qwen3ASRModel.LLM` engine is loaded in :meth:`load_checkpoint`
    and reused by both :meth:`transcribe` (offline batch) and
    :meth:`push_chunk` (streaming). An instance therefore occupies a single
    GPU weight footprint regardless of which path the caller exercises.

    Streaming specifics
    -------------------
    Streaming path delegates to :meth:`Qwen3ASRModel.streaming_transcribe` and
    emits the latest cumulative text on each chunk via ``AudioSpan.raw_text``.
    Since Qwen3-ASR re-decodes from accumulated audio with prefix rollback, the
    returned text may revise earlier characters; callers should overwrite the
    displayed partial text instead of appending deltas.
    """

    # Config-shape selectors. Subclasses flip these so that ``get_config`` emits
    # the correct outer key / registry annotation for the registry they live in.
    _config_outer_key: ClassVar[str] = "asr_model"
    _config_registry: ClassVar[str] = "asr_models"

    registry_name: ClassVar[str] = ""

    endpoint: str = "modelscope"
    sample_rate: int = 16000
    language: str | None = Field(
        default=None,
        description="Optional forced language (e.g. 'zh', 'en'). ``None`` lets the model auto-detect per utterance.",
    )
    context: str = Field(
        default="",
        description="Context hint forwarded to the ASR prompt; useful for biasing rare terms or speaker names.",
    )
    chunk_size_ms: int | None = Field(
        default=None,
        description="Streaming chunk size in ms; controls how often `streaming_transcribe` advances the decode loop.",
    )
    unfixed_chunk_num: int | None = Field(
        default=None,
        description="For first N chunks, do not use history as decoding prefix.",
    )
    unfixed_token_num: int | None = Field(
        default=None,
        description="Rollback K tokens from history before using it as decoding prefix.",
    )

    qwen3: Any | None = Field(
        default=None,
        exclude=True,
        description="Underlying Qwen3 vLLM engine handle; populated by ``load_checkpoint`` and skipped during serialization.",
    )
    max_new_tokens: int = Field(
        default=4096,
        description="Maximum number of tokens the decoder may generate per request; increase for long-form audio.",
    )
    max_inference_batch_size: int = Field(
        default=-1,
        description="Upper bound on the vLLM inference batch size; ``-1`` disables the limit. Lower values trade throughput for VRAM headroom.",
    )
    gpu_memory_utilization: float = Field(
        default=0.8,
        description="Fraction of total GPU memory vLLM is allowed to reserve for the KV cache and weights, in ``(0, 1]``.",
    )
    max_model_len: int | None = Field(
        default=None,
        description="vLLM ``max_model_len`` override (prompt + generation). ``None`` falls back to ``2 * max_new_tokens``.",
    )

    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    # ------------------------------------------------------------------ batch
    def transcribe(
        self,
        batch: List[AudioSpan],
        **kwargs,
    ) -> List[AudioSpan]:
        if self.qwen3 is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        if not batch:
            return batch
        inputs: list[tuple[np.ndarray, int]] = []
        for span in batch:
            wf = span.waveform
            data = wf.data
            if isinstance(data, torch.Tensor):
                wav = data.detach().cpu().float().numpy()
            else:
                wav = np.asarray(data)
            wav = wav.squeeze()
            inputs.append((wav, int(wf.sample_rate)))
        results = self.qwen3.transcribe(inputs)
        if not isinstance(results, list):
            results = [results]
        assert len(results) == len(inputs), (
            f"results length {len(results)} != inputs length {len(inputs)}"
        )
        # Qwen3-ASR returns the full utterance text with no word-level timing,
        # so populate ``span.raw_text`` and leave ``span.tokens`` untouched.
        for span, result in zip(batch, results):
            span.raw_text = _result_to_text(result)
        return batch

    # -------------------------------------------------------------- streaming
    def push_chunk(self, chunk: AudioChunk) -> AudioSpan | None:
        # Qwen3-ASR streaming returns cumulative text and may rewrite prefixes.
        # We return the latest full partial as `AudioSpan.raw_text` each step.
        if self.qwen3 is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        if chunk.is_start and chunk.stream_id in self.states:
            logger.warning(
                "Found start chunk with existing state, this is not expected."
            )
            self.states.pop(chunk.stream_id, None)

        waveform = chunk.waveform
        if waveform.sample_rate != self.sample_rate:
            waveform = waveform.resample(self.sample_rate)
        pcm = np.asarray(waveform.data).reshape(-1).astype(np.float32, copy=False)
        session = self.states.get(chunk.stream_id)
        if session is None:
            session = {
                "state": self.qwen3.init_streaming_state(
                    context=self.context,
                    language=self.language,
                    unfixed_chunk_num=self.unfixed_chunk_num
                    if self.unfixed_chunk_num is not None
                    else 2,
                    unfixed_token_num=self.unfixed_token_num
                    if self.unfixed_token_num is not None
                    else 5,
                    chunk_size_sec=(
                        (self.chunk_size_ms if self.chunk_size_ms is not None else 2000)
                        / 1000.0
                    ),
                ),
                "last_text": "",
            }
            self.states[chunk.stream_id] = session

        stream_state = session["state"]
        self.qwen3.streaming_transcribe(pcm16k=pcm, state=stream_state)
        if chunk.is_last:
            self.qwen3.finish_streaming_transcribe(state=stream_state)
        text = str(getattr(stream_state, "text", "") or "").strip()
        last_text = session.get("last_text", "")
        # Avoid spamming unchanged cumulative text on every audio chunk.
        if not chunk.is_last and text == last_text:
            return None
        if chunk.is_last and not text:
            # Keep a meaningful final span when the flush step yields empty text.
            text = last_text
        session["last_text"] = text
        if chunk.is_last:
            self.states.pop(chunk.stream_id, None)
        if not text and not chunk.is_last:
            return None
        return AudioSpan(raw_text=text, is_last=bool(chunk.is_last))

    # ---------------------------------------------------------------- engine
    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the Qwen3 vLLM engine from a local checkpoint directory.

        The same engine serves both batch and streaming paths, so the caller
        never pays the cost of loading Qwen3 twice even when both capabilities
        are exercised on a single instance.

        Resolution order for the checkpoint path:
            1. ``checkpoint_dir`` argument.
            2. ``self.checkpoint`` (repo_id) -> ``self.download_checkpoint()``
               + ``self.checkpoint_dir``.

        Raises:
            ValueError: neither ``checkpoint_dir`` nor ``self.checkpoint`` is set.
            FileNotFoundError: resolved checkpoint directory does not exist.
        """
        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir

        checkpoint_dir = Path(checkpoint_dir)
        if not checkpoint_dir.exists():
            raise FileNotFoundError(f"Checkpoint not found: {checkpoint_dir}")

        self.qwen3 = Qwen3ASRModel.LLM(
            model=str(checkpoint_dir),
            gpu_memory_utilization=self.gpu_memory_utilization,
            max_inference_batch_size=self.max_inference_batch_size,
            max_new_tokens=self.max_new_tokens,
            max_model_len=self.max_model_len or self.max_new_tokens * 2,
        )
        return self

    # --------------------------------------------------------------- config
    def get_config(self) -> Config:
        payload: dict[str, Any] = {
            f"@{self._config_registry}": self.registry_name,
            "checkpoint": self.checkpoint,
            "endpoint": self.endpoint,
            "max_new_tokens": self.max_new_tokens,
            "max_inference_batch_size": self.max_inference_batch_size,
            "gpu_memory_utilization": self.gpu_memory_utilization,
            "max_model_len": self.max_model_len,
        }
        # Streaming subclasses carry extra knobs; inline them only for that registry
        # so offline configs stay minimal and round-trip cleanly.
        if self._config_outer_key == "stream_asr_model":
            payload.update(
                {
                    "sample_rate": self.sample_rate,
                    "chunk_size_ms": self.chunk_size_ms,
                    "language": self.language,
                    "context": self.context,
                    "unfixed_chunk_num": self.unfixed_chunk_num,
                    "unfixed_token_num": self.unfixed_token_num,
                }
            )
        return Config(data={self._config_outer_key: payload})


class Qwen3ASRSmall(_Qwen3ForASRBase):
    registry_name: ClassVar[str] = "qwen3_0_6b"
    checkpoint: str = "Qwen/Qwen3-ASR-0.6B"


class Qwen3ASRLarge(_Qwen3ForASRBase):
    registry_name: ClassVar[str] = "qwen3_1_7b"
    checkpoint: str = "Qwen/Qwen3-ASR-1.7B"


@registry.asr_models.register("qwen3asr")
def qwen3asr_entrypoint(
    language: str | None = None,
    context: str = "",
    chunk_size_ms: int | None = None,
    unfixed_chunk_num: int | None = None,
    unfixed_token_num: int | None = None,
    gpu_memory_utilization: float = 0.8,
    max_new_tokens: int = 4096,
    max_inference_batch_size: int = -1,
    max_model_len: int | None = None,
    size: Literal["small", "large"] = "small",
    **kwargs,
) -> Qwen3ASRSmall | Qwen3ASRLarge:
    common_kwargs: dict[str, Any] = {
        "language": language,
        "context": context,
        "chunk_size_ms": chunk_size_ms,
        "unfixed_chunk_num": unfixed_chunk_num,
        "unfixed_token_num": unfixed_token_num,
        "gpu_memory_utilization": gpu_memory_utilization,
        "max_new_tokens": max_new_tokens,
        "max_inference_batch_size": max_inference_batch_size,
        "max_model_len": max_model_len,
        **kwargs,
    }
    return (
        Qwen3ASRSmall(**common_kwargs)
        if size == "small"
        else Qwen3ASRLarge(**common_kwargs)
    )
