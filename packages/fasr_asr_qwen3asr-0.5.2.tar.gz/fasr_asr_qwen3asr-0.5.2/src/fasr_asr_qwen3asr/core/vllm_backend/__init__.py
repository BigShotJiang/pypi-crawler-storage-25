# coding=utf-8
# Copyright 2026 The Alibaba Qwen team.
# SPDX-License-Identifier: Apache-2.0
from .qwen3_asr import Qwen3ASRForConditionalGeneration

__all__ = ["Qwen3ASRForConditionalGeneration"]
