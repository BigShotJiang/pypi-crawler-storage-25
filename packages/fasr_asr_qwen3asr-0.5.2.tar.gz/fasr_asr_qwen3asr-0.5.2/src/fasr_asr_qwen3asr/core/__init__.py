"""Qwen3-ASR model implementation (Transformers + vLLM backends)."""
