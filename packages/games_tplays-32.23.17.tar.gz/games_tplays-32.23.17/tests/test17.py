from games import Window, get_color

cor = get_color()

class Teste(Window):
    def __init__(self):
        super().__init__(800, 600, 'O meu jogo')
        self.bgColor = cor['black']
        self.fps = 60

        self.segundos = 0
        self.texto = self.draw_text(f'Segundos: {self.segundos}', 'Arial', 100, 50, 50, cor['white'], bold=True)

    def animation(self):
        if self.after(1000):
            self.segundos += 1
        self.texto[self.CONTENT[self.TEXTS]] = f'Segundos: {self.segundos}'

Teste().run()