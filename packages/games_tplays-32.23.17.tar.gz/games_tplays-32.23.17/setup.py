from setuptools import setup, find_packages
from libConfig import *

setup(
    name="games-TPlays",
    version="32.23.17",
    author="TiagoPlays",
    description=description,
    long_description=longDescription,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=requires,
    classifiers=classifiers,
    python_requires='>=3.6'
)