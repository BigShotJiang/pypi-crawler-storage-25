"""CLI for Bilinc."""
