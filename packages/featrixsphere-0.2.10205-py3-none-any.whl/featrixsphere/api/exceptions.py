#  -*- coding: utf-8 -*-
#
#  Copyright (c) 2023-2026 Featrix, Inc, All Rights Reserved
#
#  Proprietary and Confidential.  Unauthorized use, copying or dissemination
#  of these materials is strictly prohibited.
#

"""
Exceptions for FeatrixSphere API client.
"""


class FeatrixAuthenticationError(Exception):
    """Raised when the server returns 401 Unauthorized.

    This means the API key is missing, invalid, or expired.
    Set your API key in ~/.featrix or the FEATRIX_API_KEY environment variable.
    """

    def __init__(self, message: str = None, status_code: int = 401):
        if message is None:
            message = (
                "Authentication required. "
                "Set your API key in ~/.featrix (as api_key=sk_live_...) "
                "or the FEATRIX_API_KEY environment variable."
            )
        self.status_code = status_code
        super().__init__(message)


class FeatrixPredictionError(Exception):
    """Raised when a prediction request fails on the server.

    Contains the server's error detail (e.g., model integrity check failure,
    missing model, version mismatch) so the customer sees an actionable message
    instead of a raw HTTP 500.
    """

    def __init__(self, message: str, status_code: int = 500):
        self.status_code = status_code
        super().__init__(message)


class ModelNotLoadingError(Exception):
    """Raised when ``get_load_status`` is called for a model the server isn't
    tracking. Either the model was never asked to load, or the load entry has
    been evicted from the server's in-memory state.
    """

    def __init__(self, model_id: str = None, message: str = None):
        self.model_id = model_id
        if message is None:
            message = f"Server is not tracking a load for model {model_id!r}"
        super().__init__(message)


class LoadTimeoutError(Exception):
    """Raised by ``wait_until_loaded`` when ``timeout_s`` elapses before the
    load reaches ``phase='done'``.
    """

    def __init__(self, model_id: str = None, last_status=None, timeout_s: float = None):
        self.model_id = model_id
        self.last_status = last_status
        self.timeout_s = timeout_s
        super().__init__(
            f"Timed out after {timeout_s:.0f}s waiting for {model_id!r} to load; "
            f"last phase={getattr(last_status, 'phase', '?')}"
        )


class LoadFailedError(Exception):
    """Raised by ``wait_until_loaded`` (and surfaced from ``get_load_status``
    when phase=='failed') when the server reports the load failed.
    """

    def __init__(self, model_id: str = None, status=None):
        self.model_id = model_id
        self.status = status
        err = getattr(status, 'error', None) or "unknown error"
        super().__init__(f"Load failed for {model_id!r}: {err}")
