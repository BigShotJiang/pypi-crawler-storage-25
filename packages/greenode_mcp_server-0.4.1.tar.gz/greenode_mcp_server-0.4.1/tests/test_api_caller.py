"""Tests for api_caller — call_api tool implementation."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import httpx
import pytest
import respx

from greennode.greenode_mcp_server.api_caller import (
    _format_list,
    _format_object,
    _format_response,
    call_api,
)
from greennode.greenode_mcp_server.api_index import (
    EndpointEntry,
    reset_index,
    set_index,
)


@pytest.fixture(autouse=True)
def _reset():
    reset_index()
    # Initialize with a minimal VKS spec for testing
    set_index([
        EndpointEntry(
            product="vks",
            method="GET",
            path="/v1/clusters",
            summary="List clusters",
            description="",
            servers={"HCM-3": "https://vks.api.vngcloud.vn", "HAN": "https://vks.api.vngcloud.vn"},
        ),
        EndpointEntry(
            product="vks",
            method="POST",
            path="/v1/clusters",
            summary="Create cluster",
            description="",
            servers={"HCM-3": "https://vks.api.vngcloud.vn", "HAN": "https://vks.api.vngcloud.vn"},
        ),
        EndpointEntry(
            product="vks",
            method="DELETE",
            path="/v1/clusters/{cluster_id}",
            summary="Delete cluster",
            description="",
            servers={"HCM-3": "https://vks.api.vngcloud.vn", "HAN": "https://vks.api.vngcloud.vn"},
        ),
    ])
    yield
    reset_index()


@pytest.fixture
def mock_config():
    config = MagicMock()
    config.default_region = "HCM-3"
    config.default_project_id = None
    endpoints = MagicMock()
    endpoints.vks = "https://vks.api.vngcloud.vn"
    config.get_endpoints.return_value = endpoints
    return config


@pytest.fixture
def mock_token_manager():
    tm = MagicMock()
    tm.get_token = AsyncMock(return_value="test-token")
    return tm


async def _call(
    method, path, *, config, token_manager, allow_write=True,
    product=None, region=None, params=None, body=None,
):
    return await call_api(
        method, path, product, region, params, body,
        config, token_manager, allow_write,
    )


# --- Write guard ---

async def test_write_guard_blocks_post_when_not_allowed(mock_config, mock_token_manager):
    result = await _call(
        "POST", "/v1/clusters",
        config=mock_config, token_manager=mock_token_manager, allow_write=False,
    )
    assert "write operation" in result.lower()
    assert "--allow-write" in result


async def test_write_guard_blocks_delete_when_not_allowed(mock_config, mock_token_manager):
    result = await _call(
        "DELETE", "/v1/clusters/abc",
        config=mock_config, token_manager=mock_token_manager, allow_write=False,
    )
    assert "write operation" in result.lower()


async def test_write_guard_allows_get_always(mock_config, mock_token_manager):
    with respx.mock:
        respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(200, json={"items": []})
        )
        result = await _call(
            "GET", "/v1/clusters",
            config=mock_config, token_manager=mock_token_manager, allow_write=False,
        )
    assert "No items found" in result


async def test_write_guard_allows_post_when_enabled(mock_config, mock_token_manager):
    with respx.mock:
        respx.post("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(202, json={"uid": "abc123", "name": "my-cluster"})
        )
        result = await _call(
            "POST", "/v1/clusters",
            config=mock_config, token_manager=mock_token_manager, allow_write=True,
        )
    assert "202" in result or "accepted" in result.lower()


# --- Path validation ---

async def test_path_must_start_with_slash(mock_config, mock_token_manager):
    result = await _call(
        "GET", "v1/clusters",
        config=mock_config, token_manager=mock_token_manager,
    )
    assert "Error" in result
    assert "start with '/'" in result


async def test_path_traversal_rejected(mock_config, mock_token_manager):
    result = await _call(
        "GET", "/v1/../etc/passwd",
        config=mock_config, token_manager=mock_token_manager,
    )
    assert "traversal" in result.lower()


# --- Auth injection ---

async def test_bearer_token_injected(mock_config, mock_token_manager):
    with respx.mock:
        route = respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(200, json={"items": []})
        )
        await _call("GET", "/v1/clusters", config=mock_config, token_manager=mock_token_manager)
    assert route.called
    assert route.calls[0].request.headers["authorization"] == "Bearer test-token"


# --- Response formatting ---

def test_format_list_with_dicts():
    items = [{"name": "c1", "status": "ACTIVE"}, {"name": "c2", "status": "CREATING"}]
    result = _format_list(items)
    assert "name" in result
    assert "c1" in result
    assert "|" in result  # markdown table


def test_format_list_empty():
    assert "No items found" in _format_list([])


def test_format_object():
    result = _format_object({"uid": "abc", "name": "test"})
    assert "uid" in result
    assert "abc" in result
    assert "**uid**" in result  # multi-field still uses bold


def test_format_object_single_field_uses_plain_format():
    """Single-field responses avoid markdown bold noise."""
    result = _format_object({"status": "DELETING"})
    assert result == "status: DELETING"
    assert "**" not in result


def test_format_response_with_items_key():
    data = {"items": [{"name": "c1"}], "total": 1}
    result = _format_response(data)
    assert "c1" in result


def test_format_response_plain_object():
    result = _format_response({"uid": "abc"})
    assert "uid" in result


def test_format_response_list():
    result = _format_response([{"name": "item1"}])
    assert "item1" in result


def test_format_response_listData_key_vserver_style():
    """vServer APIs wrap lists under 'listData' key, not 'items'."""
    data = {"listData": [{"id": "sg-1", "name": "secgroup-1"}], "total": 1}
    result = _format_response(data)
    assert "sg-1" in result
    assert "|" in result  # markdown table, not object dump


def test_format_response_data_key():
    data = {"data": [{"name": "x"}]}
    result = _format_response(data)
    assert "x" in result
    assert "|" in result


def test_format_response_results_key():
    data = {"results": [{"name": "y"}]}
    result = _format_response(data)
    assert "y" in result


def test_format_list_truncates_long_lists():
    items = [{"id": i, "name": f"item-{i}"} for i in range(150)]
    result = _format_list(items)
    # Only first 100 shown
    assert "item-0" in result
    assert "item-99" in result
    assert "item-100" not in result
    # Truncation footer present
    assert "Showing 100 of 150" in result


def test_format_list_no_truncation_footer_when_small():
    items = [{"id": i} for i in range(10)]
    result = _format_list(items)
    assert "Showing" not in result


def test_format_list_scalar_items_truncated():
    items = [f"str-{i}" for i in range(150)]
    result = _format_list(items)
    assert "str-0" in result
    assert "str-99" in result
    assert "str-100" not in result
    assert "Showing 100 of 150" in result


# --- HTTP responses ---

async def test_404_error_returned_as_message(mock_config, mock_token_manager):
    with respx.mock:
        respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(404, json={"message": "cluster not found"})
        )
        result = await _call("GET", "/v1/clusters", config=mock_config, token_manager=mock_token_manager)
    assert "404" in result
    assert "cluster not found" in result


async def test_204_no_content_returns_success_message(mock_config, mock_token_manager):
    with respx.mock:
        respx.delete("https://vks.api.vngcloud.vn/v1/clusters/abc").mock(
            return_value=httpx.Response(204)
        )
        result = await _call(
            "DELETE", "/v1/clusters/abc",
            config=mock_config, token_manager=mock_token_manager, allow_write=True,
        )
    assert "success" in result.lower() or "completed" in result.lower()


async def test_timeout_returns_error_message(mock_config, mock_token_manager):
    with respx.mock:
        respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            side_effect=httpx.ConnectTimeout("timeout")
        )
        result = await _call("GET", "/v1/clusters", config=mock_config, token_manager=mock_token_manager)
    assert "timed out" in result.lower()


# --- project_id auto-substitution ---

async def test_project_id_placeholder_substituted_from_config(mock_config, mock_token_manager):
    mock_config.default_project_id = "pro-abc"
    with respx.mock:
        route = respx.get("https://vks.api.vngcloud.vn/v2/pro-abc/networks").mock(
            return_value=httpx.Response(200, json={"items": []})
        )
        await call_api(
            "GET", "/v2/{projectId}/networks", None, None, None, None,
            mock_config, mock_token_manager, False,
        )
    assert route.called


async def test_project_id_snake_case_placeholder_substituted(mock_config, mock_token_manager):
    mock_config.default_project_id = "pro-xyz"
    with respx.mock:
        route = respx.get("https://vks.api.vngcloud.vn/v1/pro-xyz/flavors").mock(
            return_value=httpx.Response(200, json={"items": []})
        )
        await call_api(
            "GET", "/v1/{project_id}/flavors", None, None, None, None,
            mock_config, mock_token_manager, False,
        )
    assert route.called


async def test_no_substitution_when_placeholder_absent(mock_config, mock_token_manager):
    """Config has project_id but path doesn't need it — pass through unchanged."""
    mock_config.default_project_id = "pro-abc"
    with respx.mock:
        route = respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(200, json={"items": []})
        )
        await call_api(
            "GET", "/v1/clusters", None, None, None, None,
            mock_config, mock_token_manager, False,
        )
    assert route.called


async def test_missing_project_id_returns_actionable_error(mock_config, mock_token_manager):
    mock_config.default_project_id = None
    result = await call_api(
        "GET", "/v2/{projectId}/networks", None, None, None, None,
        mock_config, mock_token_manager, False,
    )
    assert "project_id not configured" in result
    assert "grn configure" in result
    assert "GRN_DEFAULT_PROJECT_ID" in result


# --- raw response + size guard ---

async def test_raw_true_returns_json(mock_config, mock_token_manager):
    """raw=True skips markdown formatting and returns JSON."""
    with respx.mock:
        respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(200, json={"items": [{"id": "c1", "hidden_field": "x"}]})
        )
        result = await call_api(
            "GET", "/v1/clusters", None, None, None, None,
            mock_config, mock_token_manager, False, raw=True,
        )
    # Should be JSON — every field visible including ones beyond the 6-column default
    import json as _json
    parsed = _json.loads(result)
    assert parsed["items"][0]["hidden_field"] == "x"


async def test_raw_false_returns_markdown_table(mock_config, mock_token_manager):
    """Default raw=False keeps current markdown behavior."""
    with respx.mock:
        respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(200, json={"items": [{"id": "c1", "name": "my-cluster"}]})
        )
        result = await call_api(
            "GET", "/v1/clusters", None, None, None, None,
            mock_config, mock_token_manager, False,
        )
    assert "|" in result  # markdown table


async def test_response_size_guard_triggers_when_too_large(mock_config, mock_token_manager):
    """Responses exceeding MAX_RESPONSE_BYTES return an actionable error."""
    # Build a list big enough that raw JSON exceeds 800KB
    big_items = [{"id": f"id-{i}", "blob": "x" * 1000} for i in range(900)]
    with respx.mock:
        respx.get("https://vks.api.vngcloud.vn/v1/clusters").mock(
            return_value=httpx.Response(200, json={"items": big_items})
        )
        result = await call_api(
            "GET", "/v1/clusters", None, None, None, None,
            mock_config, mock_token_manager, False, raw=True,
        )
    assert "exceeds" in result
    assert "pagination" in result.lower()
