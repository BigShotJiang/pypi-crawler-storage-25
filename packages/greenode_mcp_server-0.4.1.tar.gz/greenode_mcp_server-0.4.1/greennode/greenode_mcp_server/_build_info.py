"""Build-time configuration baked by CI."""
from __future__ import annotations

DEFAULT_DOCS_PORTAL_URL = "https://docs.api.vngcloud.vn"
