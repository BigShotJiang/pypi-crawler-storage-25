"""Kubernetes handler for the GreenNode MCP Server."""
from __future__ import annotations

import json
import logging
import os

import yaml
from pydantic import Field
from typing import Any, Dict, Optional

from greennode.greenode_mcp_server.client import GreenodeClient
from greennode.greenode_mcp_server.config import GreenodeConfig
from greennode.greenode_mcp_server.k8s_apis import K8sApis
from greennode.greenode_mcp_server.k8s_client_cache import K8sClientCache
from greennode.greenode_mcp_server.models import (
    ApiVersionsData,
    ApplyYamlData,
    EventItem,
    EventsData,
    KubernetesResourceData,
    KubernetesResourceListData,
    Operation,
    PodLogsData,
    ResourceSummary,
)

logger = logging.getLogger(__name__)


# Default apiVersion for common built-in K8s kinds.
# Used when the caller doesn't specify `api_version` explicitly.
# Custom resources are not in this list — caller must pass api_version.
COMMON_API_VERSIONS: dict[str, str] = {
    # core/v1
    "Pod": "v1",
    "Service": "v1",
    "ConfigMap": "v1",
    "Secret": "v1",
    "Namespace": "v1",
    "Node": "v1",
    "PersistentVolume": "v1",
    "PersistentVolumeClaim": "v1",
    "ServiceAccount": "v1",
    "Event": "v1",
    "Endpoints": "v1",
    "LimitRange": "v1",
    "ResourceQuota": "v1",
    # apps/v1
    "Deployment": "apps/v1",
    "StatefulSet": "apps/v1",
    "DaemonSet": "apps/v1",
    "ReplicaSet": "apps/v1",
    # batch/v1
    "Job": "batch/v1",
    "CronJob": "batch/v1",
    # networking
    "Ingress": "networking.k8s.io/v1",
    "NetworkPolicy": "networking.k8s.io/v1",
    "IngressClass": "networking.k8s.io/v1",
    # rbac
    "Role": "rbac.authorization.k8s.io/v1",
    "RoleBinding": "rbac.authorization.k8s.io/v1",
    "ClusterRole": "rbac.authorization.k8s.io/v1",
    "ClusterRoleBinding": "rbac.authorization.k8s.io/v1",
    # storage
    "StorageClass": "storage.k8s.io/v1",
    "VolumeAttachment": "storage.k8s.io/v1",
    # autoscaling
    "HorizontalPodAutoscaler": "autoscaling/v2",
    # apiextensions
    "CustomResourceDefinition": "apiextensions.k8s.io/v1",
    # policy
    "PodDisruptionBudget": "policy/v1",
}


def _summarize_status(kind: str, resource: dict) -> str:
    """Return a compact one-line status summary for common K8s kinds.

    Unknown kinds fall through to a generic `status.phase` lookup and an
    empty string if nothing meaningful is present.
    """
    status = resource.get("status") or {}
    spec = resource.get("spec") or {}

    if kind == "Pod":
        phase = status.get("phase", "Unknown")
        container_statuses = status.get("containerStatuses") or []
        ready = sum(1 for c in container_statuses if c.get("ready"))
        total = len(container_statuses)
        restarts = sum(c.get("restartCount", 0) for c in container_statuses)
        return f"{phase} (ready {ready}/{total}, restarts {restarts})"

    if kind in ("Deployment", "ReplicaSet", "StatefulSet"):
        ready = status.get("readyReplicas", 0) or 0
        desired = spec.get("replicas", 0) or 0
        return f"{ready}/{desired} ready"

    if kind == "DaemonSet":
        ready = status.get("numberReady", 0) or 0
        desired = status.get("desiredNumberScheduled", 0) or 0
        return f"{ready}/{desired} ready"

    if kind == "Service":
        svc_type = spec.get("type", "")
        cluster_ip = spec.get("clusterIP", "")
        ingress = (status.get("loadBalancer") or {}).get("ingress") or []
        external = ", ".join(i.get("ip") or i.get("hostname") or "" for i in ingress if i)
        return f"{svc_type} {cluster_ip}".strip() + (f" → {external}" if external else "")

    if kind == "PersistentVolumeClaim":
        phase = status.get("phase", "Unknown")
        capacity = (status.get("capacity") or {}).get("storage", "")
        return f"{phase}" + (f" ({capacity})" if capacity else "")

    if kind == "PersistentVolume":
        phase = status.get("phase", "Unknown")
        capacity = (spec.get("capacity") or {}).get("storage", "")
        claim = spec.get("claimRef") or {}
        claim_name = f"{claim.get('namespace', '')}/{claim.get('name', '')}" if claim else ""
        return f"{phase}" + (f" ({capacity})" if capacity else "") + (f" → {claim_name}" if claim_name else "")

    if kind == "Node":
        conditions = status.get("conditions") or []
        ready_cond = next((c for c in conditions if c.get("type") == "Ready"), None)
        ready = ready_cond and ready_cond.get("status") == "True"
        version = (status.get("nodeInfo") or {}).get("kubeletVersion", "")
        return f"{'Ready' if ready else 'NotReady'}" + (f" ({version})" if version else "")

    if kind == "Job":
        succeeded = status.get("succeeded", 0) or 0
        failed = status.get("failed", 0) or 0
        active = status.get("active", 0) or 0
        return f"active={active} succeeded={succeeded} failed={failed}"

    if kind == "CronJob":
        last = status.get("lastScheduleTime", "") or ""
        active = len(status.get("active") or [])
        return f"active={active}" + (f" lastSchedule={last}" if last else "")

    if kind == "Ingress":
        ingress = (status.get("loadBalancer") or {}).get("ingress") or []
        addrs = ", ".join(i.get("ip") or i.get("hostname") or "" for i in ingress if i)
        return addrs or "no address"

    # Generic fallback
    phase = status.get("phase")
    if phase:
        return str(phase)
    return ""


def _resolve_api_version(kind: str, api_version: str | None) -> str:
    """Return `api_version` if set; otherwise look up kind in COMMON_API_VERSIONS.

    Raises ValueError with a helpful hint when neither works.
    """
    if api_version:
        return api_version
    resolved = COMMON_API_VERSIONS.get(kind)
    if resolved:
        return resolved
    raise ValueError(
        f"api_version is required for kind {kind!r} (not in the built-in defaults). "
        f"Use list_api_versions to find available versions."
    )


class K8sHandler:
    """Handler for Kubernetes operations in the GreenNode MCP Server.

    This class provides tools for interacting with Kubernetes clusters, including
    listing resources, managing individual resources, applying YAML manifests,
    retrieving pod logs and events, and listing API versions.
    """

    def __init__(
        self,
        mcp,
        config: GreenodeConfig,
        vks_client: GreenodeClient,
        allow_write: bool = False,
        allow_sensitive_data_access: bool = False,
    ):
        """Initialize the Kubernetes handler.

        Args:
            mcp: The MCP server instance
            config: GreenNode configuration
            vks_client: GreenNode HTTP client
            allow_write: Whether to enable write access (default: False)
            allow_sensitive_data_access: Whether to allow access to sensitive data (default: False)
        """
        self.mcp = mcp
        self.config = config
        self.client_cache = K8sClientCache(vks_client)
        self.allow_write = allow_write
        self.allow_sensitive_data_access = allow_sensitive_data_access

        self.mcp.tool(name="list_k8s_resources")(self.list_k8s_resources)
        self.mcp.tool(name="get_pod_logs")(self.get_pod_logs)
        self.mcp.tool(name="get_k8s_events")(self.get_k8s_events)
        self.mcp.tool(name="list_api_versions")(self.list_api_versions)
        self.mcp.tool(name="manage_k8s_resource")(self.manage_k8s_resource)
        self.mcp.tool(name="apply_yaml")(self.apply_yaml)

    async def get_client(self, cluster_id: str, region: str | None = None) -> K8sApis:
        """Get a Kubernetes client for the specified cluster.

        Args:
            cluster_id: ID of the VKS cluster
            region: Region override (optional)

        Returns:
            K8sApis instance
        """
        return await self.client_cache.get_client(cluster_id, region)

    def filter_null_values(self, data: Any) -> Any:
        """Recursively filter out null values from dictionaries and lists.

        Args:
            data: The data structure to filter (dict, list, or primitive)

        Returns:
            The filtered data structure with null values removed
        """
        if isinstance(data, dict):
            return {k: self.filter_null_values(v) for k, v in data.items() if v is not None}
        if isinstance(data, list):
            return [self.filter_null_values(item) for item in data if item is not None]
        return data

    def remove_managed_fields(self, resource: Dict[str, Any]) -> Dict[str, Any]:
        """Remove metadata.managed_fields from a Kubernetes resource.

        Args:
            resource: The Kubernetes resource dictionary

        Returns:
            The resource with metadata.managed_fields removed
        """
        if isinstance(resource, dict):
            if "metadata" in resource:
                resource["metadata"].pop("managedFields", None)
        return resource

    def cleanup_resource_response(self, resource: Any) -> Any:
        """Clean up a Kubernetes resource response by removing managed fields and null values.

        This method:
        1. Removes metadata.managed_fields which is typically large and not useful
        2. Recursively removes null values to reduce response size

        Args:
            resource: The Kubernetes resource to clean up

        Returns:
            The cleaned up resource
        """
        resource = self.remove_managed_fields(resource)
        return self.filter_null_values(resource)

    async def list_k8s_resources(
        self,
        cluster_id: str = Field(..., description="VKS Cluster ID"),
        kind: str = Field(..., description="Kind of the Kubernetes resources to list (e.g., 'Pod', 'Service', 'Deployment').\n            Use the list_api_versions tool to find available resource kinds."),
        api_version: Optional[str] = Field(None, description="API version of the Kubernetes resources (e.g., 'v1', 'apps/v1', 'networking.k8s.io/v1').\n            Optional for common built-in kinds (Pod, Deployment, Service, etc.) — auto-defaulted.\n            Required for custom resources; use list_api_versions to find available API versions."),
        namespace: Optional[str] = Field(None, description="Namespace of the Kubernetes resources to list.\n            If not provided, resources will be listed across all namespaces (for namespaced resources)."),
        label_selector: Optional[str] = Field(None, description="Label selector to filter resources (e.g., 'app=nginx,tier=frontend').\n            Uses the same syntax as kubectl's --selector flag."),
        field_selector: Optional[str] = Field(None, description="Field selector to filter resources (e.g., 'metadata.name=my-pod,status.phase=Running').\n            Uses the same syntax as kubectl's --field-selector flag."),
        region: str | None = Field(None, description="Region override"),
    ) -> str:
        """List Kubernetes resources of a specific kind.

        This tool lists Kubernetes resources of a specified kind in a VKS cluster,
        with options to filter by namespace, labels, and fields. It returns a summary
        of each resource including name, namespace, creation time, and metadata, useful
        for listing pods in a namespace, finding services with specific labels, or
        checking resources in a specific state.

        IMPORTANT: Use this tool instead of 'kubectl get' commands.

        ## Response Information
        Each item includes name, namespace, creation timestamp, labels, annotations,
        and `status_summary` — a compact per-kind status string (e.g. "Running
        (ready 1/1, restarts 0)" for Pods, "3/3 ready" for Deployments).

        ## Usage Tips
        - Leave `namespace` empty to list across all namespaces (response shows
          `namespace: "all namespaces"`). Pass a specific namespace to scope.
        - For non-namespaced resources (like Nodes), the namespace parameter is ignored
        - Combine label and field selectors for more precise filtering
        - **Finding unhealthy Pods:** `status.phase != Running` MISSES
          CrashLoopBackOff (those pods keep `phase=Running`). To catch them,
          list all pods and inspect `status_summary` (shows restart count)
          or check container statuses via manage_k8s_resource.
        - Results are summarized to avoid overwhelming responses
        """
        try:
            api_version = _resolve_api_version(kind, api_version)
            k8s_client = await self.get_client(cluster_id, region)
            response = k8s_client.list_resources(
                kind, api_version,
                namespace=namespace,
                label_selector=label_selector,
                field_selector=field_selector,
            )

            summaries = []
            for item in response.items:
                item_dict = self.cleanup_resource_response(item.to_dict())
                metadata = item_dict.get("metadata", {})
                creation_timestamp = metadata.get("creationTimestamp", "")
                summary = ResourceSummary(
                    name=metadata.get("name", ""),
                    namespace=metadata.get("namespace", None),
                    creation_timestamp=str(creation_timestamp),
                    labels=metadata.get("labels", None),
                    annotations=metadata.get("annotations", None),
                    status_summary=_summarize_status(kind, item_dict) or None,
                )
                summaries.append(summary)

            logger.info("Cleaned up resource responses for %s resources", len(summaries))

            resource_location = f"in {namespace}" if namespace else "all namespaces"
            logger.info("Listed %d %s resources %s", len(summaries), kind, resource_location)

            data = KubernetesResourceListData(
                kind=kind,
                api_version=api_version,
                namespace=namespace if namespace else "all namespaces",
                count=len(summaries),
                items=summaries,
            )
            return json.dumps(data.model_dump())
        except Exception as e:
            error_msg = f"Failed to list {kind} resources: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

    async def get_pod_logs(
        self,
        cluster_id: str = Field(..., description="VKS Cluster ID"),
        namespace: str = Field(..., description="Kubernetes namespace where the pod is located."),
        pod_name: str = Field(..., description="Name of the pod to retrieve logs from."),
        container_name: Optional[str] = Field(None, description="Name of the specific container to get logs from. Required only if the pod contains multiple containers."),
        since_seconds: Optional[int] = Field(None, description="Only return logs newer than this many seconds. Useful for getting recent logs without retrieving the entire history."),
        tail_lines: int = Field(100, description="Number of lines to return from the end of the logs. Default: 100. Use higher values for more context."),
        limit_bytes: int = Field(10240, description="Maximum number of bytes to return. Default: 10KB (10240 bytes). Prevents retrieving extremely large log files."),
        previous: bool = Field(False, description="Return previous terminated container logs. Default: false. Useful to get logs for pods that are restarting."),
        region: str | None = Field(None, description="Region override"),
    ) -> str:
        """Get logs from a pod in a Kubernetes cluster.

        This tool retrieves logs from a specified pod in a VKS cluster, with options
        to filter by container, time range, and size. It's useful for debugging application
        issues, monitoring behavior, investigating crashes, and verifying startup configuration.

        IMPORTANT: Use this tool instead of 'kubectl logs' commands.

        ## Requirements
        - The pod must exist and be accessible in the specified namespace
        - The VKS cluster must exist and be accessible

        ## Response Information
        The response includes pod name, namespace, container name (if specified),
        and log lines as an array of strings.
        """

        try:
            k8s_client = await self.get_client(cluster_id, region)
            logs = k8s_client.get_pod_logs(
                pod_name=pod_name,
                namespace=namespace,
                container_name=container_name,
                since_seconds=since_seconds,
                tail_lines=tail_lines,
                limit_bytes=limit_bytes,
                previous=previous,
            )

            log_lines = logs.splitlines(keepends=False)
            if log_lines and log_lines[-1].endswith("\n"):
                log_lines.append("")

            container_info = f" (container: {container_name})" if container_name else ""
            logger.info(
                "Retrieved %d log lines from pod %s/%s%s",
                len(log_lines), namespace, pod_name, container_info,
            )

            data = PodLogsData(
                pod_name=pod_name,
                namespace=namespace,
                container_name=container_name,
                log_lines=log_lines,
            )
            return json.dumps(data.model_dump())
        except Exception as e:
            error_msg = f"Failed to get logs from pod {namespace}/{pod_name}: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

    async def get_k8s_events(
        self,
        cluster_id: str = Field(..., description="VKS Cluster ID"),
        kind: str = Field(..., description='Kind of the involved object (e.g., "Pod", "Deployment", "Service"). Must match the resource kind exactly.'),
        name: str = Field(..., description="Name of the involved object to get events for."),
        namespace: Optional[str] = Field(None, description="Namespace of the involved object. Required for namespaced resources (like Pods, Deployments).\n            Not required for cluster-scoped resources (like Nodes, PersistentVolumes)."),
        region: str | None = Field(None, description="Region override"),
    ) -> str:
        """Get events related to a specific Kubernetes resource.

        This tool retrieves Kubernetes events related to a specific resource, providing
        detailed information about what has happened to the resource over time. Events
        are useful for troubleshooting pod startup failures, investigating deployment issues,
        understanding resource modifications, and diagnosing scheduling problems.

        IMPORTANT: Use this tool instead of 'kubectl describe' or 'kubectl get events' commands.

        ## Requirements
        - The resource must exist and be accessible in the specified namespace

        ## Response Information
        The response includes events with timestamps (first and last), occurrence counts,
        messages, reasons, reporting components, and event types (Normal or Warning).

        ## Usage Tips
        - Warning events often indicate problems that need attention
        - Normal events provide information about expected lifecycle operations
        - The count field shows how many times the same event has occurred
        - Recent events are most relevant for current issues
        """

        try:
            k8s_client = await self.get_client(cluster_id, region)
            events = k8s_client.get_events(kind=kind, name=name, namespace=namespace)

            resource_name = f"{namespace}/{name}" if namespace else name

            cleaned_events = [self.cleanup_resource_response(event) for event in events]

            event_items = [
                EventItem(
                    first_timestamp=event.get("first_timestamp"),
                    last_timestamp=event.get("last_timestamp"),
                    count=event.get("count"),
                    message=event.get("message", ""),
                    reason=event.get("reason", ""),
                    reporting_component=event.get("reporting_component", ""),
                    type=event.get("type", ""),
                )
                for event in cleaned_events
            ]

            logger.info("Retrieved %d events for %s %s", len(event_items), kind, resource_name)

            data = EventsData(
                involved_object_kind=kind,
                involved_object_name=name,
                involved_object_namespace=namespace,
                count=len(event_items),
                events=event_items,
            )
            return json.dumps(data.model_dump())
        except Exception as e:
            error_msg = f"Failed to get events for {kind} {name}: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

    async def list_api_versions(
        self,
        cluster_id: str = Field(..., description="VKS Cluster ID"),
        region: str | None = Field(None, description="Region override"),
    ) -> str:
        """List all available API versions in the Kubernetes cluster.

        This tool discovers all available API versions on the Kubernetes cluster,
        which is helpful for determining the correct apiVersion to use when
        managing Kubernetes resources. It returns both core APIs and API groups,
        useful for verifying API compatibility and discovering available resources.

        ## Response Information
        The response includes core APIs (like 'v1'), API groups with versions
        (like 'apps/v1'), extension APIs (like 'networking.k8s.io/v1'), and
        any Custom Resource Definition (CRD) APIs installed in the cluster.

        ## Usage Tips
        - Use this tool before creating or updating resources to ensure API compatibility
        - Different Kubernetes versions may have different available APIs
        - Some APIs may be deprecated or removed in newer Kubernetes versions
        - Custom resources will only appear if their CRDs are installed in the cluster
        """
        try:
            k8s_client = await self.get_client(cluster_id, region)
            api_versions = k8s_client.get_api_versions()

            logger.info("Retrieved %d API versions from cluster %s", len(api_versions), cluster_id)

            data = ApiVersionsData(
                cluster_id=cluster_id,
                api_versions=api_versions,
                count=len(api_versions),
            )
            return json.dumps(data.model_dump())
        except Exception as e:
            error_msg = f"Failed to get API versions from cluster {cluster_id}: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

    async def manage_k8s_resource(
        self,
        operation: str = Field(..., description="Operation to perform on the resource. Valid values:\n            - create: Create a new resource\n            - replace: Replace an existing resource\n            - patch: Update specific fields of an existing resource\n            - delete: Delete an existing resource\n            - read: Get details of an existing resource\n            Use list_k8s_resources for listing multiple resources."),
        cluster_id: str = Field(..., description="VKS Cluster ID"),
        kind: str = Field(..., description='Kind of the Kubernetes resource (e.g., "Pod", "Service", "Deployment").'),
        api_version: Optional[str] = Field(None, description='API version of the Kubernetes resource (e.g., "v1", "apps/v1", "networking.k8s.io/v1"). Optional for common built-in kinds — auto-defaulted. Required for custom resources.'),
        name: Optional[str] = Field(None, description="Name of the Kubernetes resource. Required for all operations except create (where it can be specified in the body)."),
        namespace: Optional[str] = Field(None, description="Namespace of the Kubernetes resource. Required for namespaced resources.\n            Not required for cluster-scoped resources (like Nodes, PersistentVolumes)."),
        body: Optional[Dict[str, Any]] = Field(None, description="Resource definition as a dictionary. Required for create, replace, and patch operations.\n            For create and replace, this should be a complete resource definition.\n            For patch, this should contain only the fields to update."),
        region: str | None = Field(None, description="Region override"),
    ) -> str:
        """Manage a single Kubernetes resource with various operations.

        This tool provides complete CRUD (Create, Read, Update, Delete) operations
        for Kubernetes resources in a VKS cluster. It supports all resource types
        and allows for precise control over individual resources, enabling you to create
        custom resources, update specific fields, read detailed information, and delete
        resources that are no longer needed.

        IMPORTANT: Use this tool instead of 'kubectl create', 'kubectl edit', 'kubectl patch',
        'kubectl delete', or 'kubectl get' commands.

        ## Requirements
        - The server must be run with the `--allow-write` flag for mutating operations
        - The server must be run with the `--allow-sensitive-data-access` flag for Secret resources
        - The VKS cluster must exist and be accessible

        ## Operations
        - **create**: Create a new resource with the provided definition
        - **replace**: Replace an existing resource with a new definition
        - **patch**: Update specific fields of an existing resource
        - **delete**: Remove an existing resource
        - **read**: Get details of an existing resource

        ## Usage Tips
        - Use list_api_versions to find available API versions
        - For namespaced resources, always provide the namespace
        - When creating resources, ensure the name in the body matches the name parameter
        - For patch operations, only include the fields you want to update
        """
        # Validate operation
        try:
            operation_enum = Operation(operation)
        except ValueError:
            valid_ops = ", ".join(op.value for op in Operation)
            raise ValueError(f"Invalid operation: {operation}. Valid operations are: {valid_ops}")

        # Check write permissions
        if operation_enum in (Operation.CREATE, Operation.REPLACE, Operation.PATCH, Operation.DELETE):
            if not self.allow_write:
                raise RuntimeError(f"Write access denied: {operation} operation requires --allow-write flag.")

        # Check sensitive data access for Secrets
        if kind.lower() == "secret" and operation_enum == Operation.READ:
            if not self.allow_sensitive_data_access:
                raise RuntimeError("Access denied: reading Kubernetes Secrets requires --allow-sensitive-data-access flag.")

        try:
            api_version = _resolve_api_version(kind, api_version)
            k8s_client = await self.get_client(cluster_id, region)
            response = k8s_client.manage_resource(
                operation_enum, kind, api_version,
                name=name, namespace=namespace, body=body,
            )

            resource_name = f"{namespace}/{name}" if namespace else (name or "")
            operation_past_tense = {
                Operation.CREATE: "created",
                Operation.REPLACE: "replaced",
                Operation.PATCH: "patched",
                Operation.DELETE: "deleted",
                Operation.READ: "retrieved",
            }.get(operation_enum, operation)

            logger.info("%s %s %s", operation_past_tense.capitalize(), kind, resource_name)

            resource_data = None
            if operation_enum == Operation.READ:
                resource_data = self.cleanup_resource_response(response.to_dict())
                logger.info("Cleaned up resource response for %s %s", kind, resource_name)

            data = KubernetesResourceData(
                kind=kind,
                name=name or "",
                namespace=namespace,
                api_version=api_version,
                operation=operation_past_tense,
                resource=resource_data,
            )
            return json.dumps(data.model_dump())
        except Exception as e:
            error_msg = f"Failed to {operation} {kind} {name or ''}: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)

    async def apply_yaml(
        self,
        cluster_id: str = Field(..., description="VKS Cluster ID"),
        yaml_content: Optional[str] = Field(None, description="Inline YAML manifest string. Preferred when the MCP client and server run on different machines. Supports multi-document YAML (--- separators). Either yaml_content or yaml_path must be provided."),
        yaml_path: Optional[str] = Field(None, description="Absolute path to a local YAML file on the server's machine (e.g. '/home/user/app.yaml'). Use yaml_content instead when running MCP remotely. Either yaml_content or yaml_path must be provided."),
        namespace: Optional[str] = Field(None, description="Default namespace for resources in the YAML that don't specify one. If omitted, resources must declare their own namespace or be cluster-scoped."),
        force: bool = Field(True, description="Whether to update resources if they already exist (similar to kubectl apply). Set to false to only create new resources."),
        region: str | None = Field(None, description="Region override"),
    ) -> str:
        """Apply Kubernetes YAML manifest to a VKS cluster.

        Accepts either inline YAML content (recommended for remote MCP) or
        an absolute file path. Supports multi-document YAML (--- separators).
        Creates new resources or updates existing ones (when force=True), like
        `kubectl apply -f`.

        IMPORTANT: Use this tool instead of 'kubectl apply -f' commands.

        ## Requirements
        - The server must be run with the `--allow-write` flag
        - Provide ONE of: yaml_content (inline string) or yaml_path (server-local file)
        - The VKS cluster must exist and be accessible

        ## Response Information
        The response includes the number of resources created, number of resources
        updated (when force=True), and whether force was applied.
        """
        if not self.allow_write:
            raise RuntimeError("Write access denied: apply_yaml requires --allow-write flag.")

        if not yaml_content and not yaml_path:
            raise RuntimeError("Provide either yaml_content (inline) or yaml_path (file path).")
        if yaml_content and yaml_path:
            raise RuntimeError("Provide only one of yaml_content or yaml_path, not both.")

        try:
            k8s_client = await self.get_client(cluster_id, region)

            if yaml_path:
                if not os.path.isabs(yaml_path):
                    raise RuntimeError(f"Path must be absolute: {yaml_path}")
                logger.info("Reading YAML content from file: %s", yaml_path)
                try:
                    with open(yaml_path, "r") as yaml_file:
                        yaml_content = yaml_file.read()
                except FileNotFoundError:
                    raise RuntimeError(f"YAML file not found: {yaml_path}")
                except IOError as e:
                    raise RuntimeError(f"Error reading YAML file {yaml_path}: {str(e)}")
            else:
                logger.info("Applying inline YAML content (%d bytes)", len(yaml_content))

            yaml_objects = list(yaml.safe_load_all(yaml_content))
            yaml_objects = [doc for doc in yaml_objects if doc is not None]
            logger.info("Found %d resources in the manifest", len(yaml_objects))

            results, created_count, updated_count = k8s_client.apply_from_yaml(
                yaml_objects=yaml_objects,
                namespace=namespace or "default",
                force=force,
            )

            source = f"file {yaml_path}" if yaml_path else "inline YAML"
            success_msg = (
                f"Successfully applied all resources from {source}"
                f" ({created_count} created, {updated_count} updated)"
            )
            logger.info(success_msg)

            data = ApplyYamlData(
                force_applied=force,
                resources_created=created_count,
                resources_updated=updated_count,
            )
            return json.dumps(data.model_dump())
        except Exception as e:
            error_msg = f"Error applying YAML from file: {str(e)}"
            logger.error(error_msg)
            raise RuntimeError(error_msg)
