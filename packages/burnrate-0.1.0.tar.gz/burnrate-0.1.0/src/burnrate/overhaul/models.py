from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Recommendation:
    replace: str
    replace_cost: float
    with_tool: str
    with_cost: float
    reason: str
    alt: str = ""
    requires: list[str] = field(default_factory=list)


@dataclass
class OverhaulPlan:
    recommendations: list[Recommendation]
    current_monthly: float
    new_monthly: float

    @property
    def annual_savings(self) -> float:
        return (self.current_monthly - self.new_monthly) * 12
