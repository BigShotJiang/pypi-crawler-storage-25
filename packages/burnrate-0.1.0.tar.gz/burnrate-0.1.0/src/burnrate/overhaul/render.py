from __future__ import annotations

from rich.console import Console
from rich.rule import Rule

from burnrate.config import BurnrateConfig
from burnrate.overhaul.models import OverhaulPlan


def render_plan(plan: OverhaulPlan, config: BurnrateConfig, con: Console) -> None:
    con.print()
    con.print(Rule(style="red dim"))
    con.print("  [bold red]RECOMMENDED OVERHAUL[/bold red]")
    con.print(f"  [dim]Based on:[/dim] {_system_summary(config)}")
    con.print(Rule(style="red dim"))
    con.print()

    if not plan.recommendations:
        con.print("[dim]  No subscriptions found to replace.[/dim]")
        con.print()
        return

    for r in plan.recommendations:
        con.print(f"[bold]REPLACE[/bold] {r.replace} [dim](${r.replace_cost:.0f}/mo)[/dim]")
        con.print(f"  → [bold]{r.with_tool}[/bold] [dim](${r.with_cost:.0f}/mo)[/dim]")
        con.print(f"    [dim]Reason:[/dim] {r.reason}")
        if r.alt:
            con.print(f"    [dim]Alt:[/dim] {r.alt}")
        con.print()

    con.print(Rule(style="red dim"))
    con.print(f"  [dim]New monthly cost:[/dim]    ~${plan.new_monthly:.0f}/mo")
    con.print(f"  [dim]Current cost:[/dim]        ~${plan.current_monthly:.0f}/mo")
    con.print(
        f"  [bold green]Annual savings:[/bold green]      ${plan.annual_savings:.0f}/yr"
    )
    con.print(Rule(style="red dim"))
    con.print()


def _system_summary(config: BurnrateConfig) -> str:
    sys = config.system
    if sys is None:
        return "system not profiled"
    arch_label = "Apple Silicon" if sys.arch == "arm64" else sys.arch
    ram = f"{sys.ram_gb}GB RAM" if sys.ram_gb else "RAM unknown"
    editor = sys.editor or "no editor detected"
    return f"{sys.os} {arch_label}, {ram}, {editor} user"
