from __future__ import annotations

from burnrate.config import BurnrateConfig
from burnrate.overhaul.catalog import CATALOG, CatalogEntry, Variant
from burnrate.overhaul.models import OverhaulPlan, Recommendation


def _system_satisfies(req: str, config: BurnrateConfig) -> bool:
    sys = config.system
    if sys is None:
        return False
    if req.startswith("ram>="):
        threshold = int(req.split(">=", 1)[1])
        return (sys.ram_gb or 0) >= threshold
    if req == "darwin":
        return sys.os == "darwin"
    if req == "darwin-arm64":
        return sys.os == "darwin" and sys.arch == "arm64"
    if req == "linux":
        return sys.os == "linux"
    return True


def _pick_variant(entry: CatalogEntry, config: BurnrateConfig) -> Variant:
    for variant in entry.variants:
        if all(_system_satisfies(r, config) for r in variant.requires):
            return variant
    return entry.variants[-1]


def recommend(config: BurnrateConfig) -> OverhaulPlan:
    subs = config.baseline.subscriptions if config.baseline else []
    recs: list[Recommendation] = []

    for sub_id in subs:
        entry = CATALOG.get(sub_id)
        if entry is None:
            recs.append(
                Recommendation(
                    replace=sub_id,
                    replace_cost=0,
                    with_tool="(no replacement in v0 catalog)",
                    with_cost=0,
                    reason="unknown — leaving as-is",
                )
            )
            continue
        variant = _pick_variant(entry, config)
        recs.append(
            Recommendation(
                replace=entry.label,
                replace_cost=entry.cost,
                with_tool=variant.with_tool,
                with_cost=variant.with_cost,
                reason=variant.reason,
                alt=variant.alt,
                requires=list(variant.requires),
            )
        )

    current = sum(r.replace_cost for r in recs)
    new = sum(r.with_cost for r in recs)
    return OverhaulPlan(recommendations=recs, current_monthly=current, new_monthly=new)
