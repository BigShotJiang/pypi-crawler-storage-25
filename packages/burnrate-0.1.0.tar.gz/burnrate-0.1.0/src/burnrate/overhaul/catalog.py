from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CatalogEntry:
    label: str
    cost: float
    variants: list["Variant"]


@dataclass
class Variant:
    with_tool: str
    with_cost: float
    reason: str
    alt: str = ""
    requires: list[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.requires is None:
            self.requires = []


CATALOG: dict[str, CatalogEntry] = {
    "cursor-pro": CatalogEntry(
        label="Cursor Pro",
        cost=20,
        variants=[
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native Apple Silicon, built-in AI, faster than Cursor",
                alt="VS Code + Continue extension",
                requires=["darwin-arm64"],
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Free AI editor, native AI integration",
                alt="VS Code + Continue extension",
            ),
        ],
    ),
    "cursor-pro-plus": CatalogEntry(
        label="Cursor Pro+",
        cost=60,
        variants=[
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native Apple Silicon, built-in AI, faster than Cursor",
                alt="VS Code + Continue extension",
                requires=["darwin-arm64"],
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Free AI editor, native AI integration",
                alt="VS Code + Continue extension",
            ),
        ],
    ),
    "cursor-ultra": CatalogEntry(
        label="Cursor Ultra",
        cost=200,
        variants=[
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native Apple Silicon, built-in AI, faster than Cursor",
                alt="VS Code + Continue extension",
                requires=["darwin-arm64"],
            ),
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Free AI editor, native AI integration",
                alt="VS Code + Continue extension",
            ),
        ],
    ),
    "claude-max-5x": CatalogEntry(
        label="Claude Max 5x",
        cost=100,
        variants=[
            Variant(
                with_tool="Anthropic API + Aider",
                with_cost=25,
                reason="Same Claude, no rate limits, pay only for what you use",
                alt="Claude Code direct",
            ),
        ],
    ),
    "claude-max-20x": CatalogEntry(
        label="Claude Max 20x",
        cost=200,
        variants=[
            Variant(
                with_tool="Anthropic API + Aider",
                with_cost=25,
                reason="Same Claude, no rate limits, pay only for what you use",
                alt="Claude Code direct",
            ),
        ],
    ),
    "claude-pro": CatalogEntry(
        label="Claude Pro",
        cost=20,
        variants=[
            Variant(
                with_tool="Anthropic API direct",
                with_cost=20,
                reason="Same model, no UI subscription tax",
            ),
        ],
    ),
    "github-copilot": CatalogEntry(
        label="GitHub Copilot",
        cost=19,
        variants=[
            Variant(
                with_tool="Ollama + Qwen3:30b-a3b",
                with_cost=0,
                reason="Local autocomplete, zero latency, zero cost",
                alt="Continue extension",
                requires=["ram>=16"],
            ),
            Variant(
                with_tool="Ollama + Qwen3:7b",
                with_cost=0,
                reason="Smaller local model — fits in <16GB RAM, still free",
                alt="Continue extension",
            ),
        ],
    ),
    "windsurf": CatalogEntry(
        label="Windsurf",
        cost=15,
        variants=[
            Variant(
                with_tool="Zed",
                with_cost=0,
                reason="Native AI editor, free",
                alt="Aider",
            ),
        ],
    ),
    "tabnine": CatalogEntry(
        label="Tabnine",
        cost=12,
        variants=[
            Variant(
                with_tool="Ollama + Qwen3:30b-a3b",
                with_cost=0,
                reason="Local autocomplete, free",
                requires=["ram>=16"],
            ),
            Variant(
                with_tool="Ollama + Qwen3:7b",
                with_cost=0,
                reason="Smaller local model — fits in <16GB RAM",
            ),
        ],
    ),
}
