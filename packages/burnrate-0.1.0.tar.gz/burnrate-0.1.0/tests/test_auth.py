from __future__ import annotations

from burnrate.commands.auth import _select_subscriptions


def _set_confirm_answers(monkeypatch, answers: list[bool]) -> None:
    it = iter(answers)
    monkeypatch.setattr(
        "burnrate.commands.auth.Confirm.ask", lambda *a, **k: next(it)
    )


def test_select_subscriptions_none_selected(monkeypatch):
    _set_confirm_answers(monkeypatch, [False] * 9)
    subs, total = _select_subscriptions()
    assert subs == []
    assert total == 0


def test_select_subscriptions_cursor_pro_and_copilot(monkeypatch):
    answers = [True, False, False, False, False, False, True, False, False]
    _set_confirm_answers(monkeypatch, answers)
    subs, total = _select_subscriptions()
    assert subs == ["cursor-pro", "github-copilot"]
    assert total == 20 + 19


def test_select_subscriptions_all_selected(monkeypatch):
    _set_confirm_answers(monkeypatch, [True] * 9)
    subs, total = _select_subscriptions()
    assert len(subs) == 9
    assert total > 0
