"""Codebase Indexer — Python ast + 정규식 기반 코드 시맨틱 청킹 + Qdrant 로컬 적재.

사용자 로컬 코드베이스를 파싱하여 함수/클래스/메서드 단위로 Qdrant 로컬 DB에 적재.
Chat 모드에서 코드 관련 질문 시 자동 검색.
"""

from __future__ import annotations

import ast
import hashlib
import json
import logging
import os
import re
import uuid
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# 상수
# ---------------------------------------------------------------------------

CODEBASE_QDRANT_PATH = os.path.expanduser("~/.codebuff/rag/codebase")
COLLECTION_NAME = "codebase"
LAST_INDEXED_AT_FILE = os.path.expanduser(
    "~/.codebuff/rag/codebase_last_indexed_at.txt"
)

SUPPORTED_EXTENSIONS = {".py", ".sql", ".ipynb"}

EXCLUDED_EXTENSIONS = {
    ".whl",
    ".jar",
    ".pyc",
    ".pyo",
    ".so",
    ".dll",
    ".exe",
    ".bin",
    ".egg",
    ".class",
    ".o",
    ".a",
    ".lib",
    ".dylib",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".bmp",
    ".ico",
    ".svg",
    ".zip",
    ".tar",
    ".gz",
    ".bz2",
    ".7z",
    ".rar",
    ".pdf",
    ".doc",
    ".docx",
    ".xls",
    ".xlsx",
    ".ppt",
    ".db",
    ".sqlite",
    ".sqlite3",
    ".map",
    ".min.js",
    ".min.css",
    ".lock",
    ".log",
}

EXCLUDED_DIRS = {
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".git",
    "dist",
    "build",
    ".egg-info",
    ".tox",
    ".pytest_cache",
    ".mypy_cache",
    ".ruff_cache",
    ".ipynb_checkpoints",
}

MAX_FILE_SIZE = 1_000_000  # 1MB
MAX_CHUNK_SIZE = 2000  # 2000자 초과 시 분할
MIN_CHUNK_SIZE = 50  # 50자 미만은 병합


# ---------------------------------------------------------------------------
# CodeIndexer
# ---------------------------------------------------------------------------


class CodeIndexer:
    """Python ast + 정규식 기반 코드 인덱서. Qdrant 로컬 전용."""

    def __init__(self, embedding_service: Any):
        self._embedding = embedding_service
        self._client = None
        self._gitignore_spec = None
        self._observer = None

    # ------------------------------------------------------------------
    # Qdrant 초기화
    # ------------------------------------------------------------------

    def _ensure_client(self):
        """Qdrant 로컬 client lazy 초기화."""
        if self._client is not None:
            return
        from qdrant_client import QdrantClient

        Path(CODEBASE_QDRANT_PATH).mkdir(parents=True, exist_ok=True)
        self._client = QdrantClient(path=CODEBASE_QDRANT_PATH)
        logger.info("CodeIndexer: Qdrant local client at %s", CODEBASE_QDRANT_PATH)

    def _ensure_collection(self):
        """code_search 컬렉션 생성 (없으면)."""
        self._ensure_client()
        from qdrant_client.models import Distance, VectorParams

        existing = {c.name for c in self._client.get_collections().collections}
        if COLLECTION_NAME not in existing:
            self._client.create_collection(
                collection_name=COLLECTION_NAME,
                vectors_config=VectorParams(
                    size=self._embedding.dimension,
                    distance=Distance.COSINE,
                ),
            )
            logger.info(
                "Created collection: %s (dim=%d)",
                COLLECTION_NAME,
                self._embedding.dimension,
            )

    # ------------------------------------------------------------------
    # 파일 수집
    # ------------------------------------------------------------------

    def _load_gitignore(self, root: Path):
        """프로젝트 .gitignore 로드."""
        self._gitignore_spec = None
        try:
            import pathspec

            gitignore = root / ".gitignore"
            if gitignore.is_file():
                self._gitignore_spec = pathspec.PathSpec.from_lines(
                    "gitwildmatch", gitignore.read_text().splitlines()
                )
        except ImportError:
            logger.debug("pathspec not installed, .gitignore ignored")

    def _is_excluded(self, fp: Path, root: Path) -> str:
        """파일 제외 여부 + 사유 반환. 빈 문자열이면 포함."""
        rel = fp.relative_to(root)
        for part in rel.parts[:-1]:
            if part in EXCLUDED_DIRS or part.startswith("."):
                return f"dir:{part}"
        if fp.suffix.lower() in EXCLUDED_EXTENSIONS:
            return f"extension:{fp.suffix}"
        try:
            if fp.stat().st_size > MAX_FILE_SIZE:
                return f"size:{fp.stat().st_size}"
        except OSError:
            return "os_error"
        if self._gitignore_spec and self._gitignore_spec.match_file(str(rel)):
            return "gitignore"
        return ""

    def _collect_files(self, root: Path) -> Tuple[List[Path], List[Tuple[Path, str]]]:
        """디렉토리 스캔. (포함 파일, [(제외 파일, 사유)]) 반환."""
        included: List[Path] = []
        excluded: List[Tuple[Path, str]] = []

        for fp in sorted(root.rglob("*")):
            if not fp.is_file() or fp.name.startswith("."):
                continue
            reason = self._is_excluded(fp, root)
            if reason:
                excluded.append((fp, reason))
            elif fp.suffix.lower() in SUPPORTED_EXTENSIONS:
                included.append(fp)

        return included, excluded

    @staticmethod
    def _file_hash(fp: Path) -> str:
        """SHA256 해시 (앞 16자)."""
        return f"sha256:{hashlib.sha256(fp.read_bytes()).hexdigest()[:16]}"

    # ------------------------------------------------------------------
    # Python AST 파싱
    # ------------------------------------------------------------------

    def _parse_python(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Python ast 모듈로 시맨틱 블록 추출."""
        try:
            tree = ast.parse(content)
        except SyntaxError:
            logger.warning(
                "SyntaxError parsing %s, falling back to line chunking", file_path
            )
            return self._fallback_chunk(content, file_path, "python")

        lines = content.splitlines()
        chunks: List[Dict[str, Any]] = []
        header_end = 0  # 모듈 레벨 코드 끝 위치

        for node in ast.iter_child_nodes(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                text = self._get_node_source(node, lines)
                chunks.append(
                    {
                        "content": text,
                        "symbol_name": node.name,
                        "symbol_type": "function",
                        "line_start": node.lineno,
                        "line_end": node.end_lineno or node.lineno,
                    }
                )
                header_end = max(header_end, node.lineno - 1)

            elif isinstance(node, ast.ClassDef):
                text = self._get_node_source(node, lines)
                if len(text) > MAX_CHUNK_SIZE:
                    chunks.extend(self._split_class(node, lines, file_path))
                else:
                    chunks.append(
                        {
                            "content": text,
                            "symbol_name": node.name,
                            "symbol_type": "class",
                            "line_start": node.lineno,
                            "line_end": node.end_lineno or node.lineno,
                        }
                    )
                header_end = max(header_end, node.lineno - 1)

        # 모듈 헤더 (import, 상수, 전역 변수)
        if header_end > 0:
            header = "\n".join(lines[:header_end]).strip()
            if len(header) > MIN_CHUNK_SIZE:
                chunks.insert(
                    0,
                    {
                        "content": header,
                        "symbol_name": "(module)",
                        "symbol_type": "module",
                        "line_start": 1,
                        "line_end": header_end,
                    },
                )

        # 함수/클래스가 전혀 없는 파일 (예: conftest.py, __init__.py) → 전체 내용을 모듈 chunk로
        if not chunks:
            full_content = content.strip()
            if len(full_content) > MIN_CHUNK_SIZE:
                chunks.append(
                    {
                        "content": full_content,
                        "symbol_name": "(module)",
                        "symbol_type": "module",
                        "line_start": 1,
                        "line_end": len(lines),
                    }
                )

        return chunks

    def _split_class(
        self, class_node: ast.ClassDef, lines: List[str], file_path: str
    ) -> List[Dict[str, Any]]:
        """큰 클래스를 메서드 단위로 분할."""
        class_name = class_node.name
        # 클래스 헤더: class 선언 + docstring
        class_header_lines = []
        for i in range(class_node.lineno - 1, min(class_node.lineno + 5, len(lines))):
            class_header_lines.append(lines[i])
            # docstring 끝 감지
            stripped = lines[i].strip()
            if stripped.endswith('"""') or stripped.endswith("'''"):
                if i > class_node.lineno - 1:
                    break

        class_header = "\n".join(class_header_lines)
        chunks: List[Dict[str, Any]] = []

        for node in ast.iter_child_nodes(class_node):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                method_text = self._get_node_source(node, lines)
                # 클래스 헤더 + 메서드
                full_text = f"{class_header}\n\n    {method_text}"
                chunks.append(
                    {
                        "content": full_text,
                        "symbol_name": f"{class_name}.{node.name}",
                        "symbol_type": "method",
                        "line_start": node.lineno,
                        "line_end": node.end_lineno or node.lineno,
                    }
                )

        if not chunks:
            # 메서드 없는 클래스
            text = self._get_node_source(class_node, lines)
            chunks.append(
                {
                    "content": text,
                    "symbol_name": class_name,
                    "symbol_type": "class",
                    "line_start": class_node.lineno,
                    "line_end": class_node.end_lineno or class_node.lineno,
                }
            )

        return chunks

    @staticmethod
    def _get_node_source(node: ast.AST, lines: List[str]) -> str:
        """AST 노드의 소스 코드 추출. 데코레이터 포함."""
        start = node.lineno - 1
        end = node.end_lineno if node.end_lineno else node.lineno

        # 데코레이터 포함
        if hasattr(node, "decorator_list") and node.decorator_list:
            first_decorator = node.decorator_list[0]
            start = first_decorator.lineno - 1

        return "\n".join(lines[start:end])

    # ------------------------------------------------------------------
    # SQL 파싱
    # ------------------------------------------------------------------

    def _parse_sql(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """SQL 파일을 세미콜론 기준으로 분할."""
        statements = re.split(r";\s*\n", content)
        chunks: List[Dict[str, Any]] = []
        line = 1

        for stmt in statements:
            stmt = stmt.strip()
            if not stmt or len(stmt) < 10:
                line += stmt.count("\n") + 1
                continue

            upper = stmt.upper().lstrip()
            if upper.startswith("SELECT"):
                sym_type = "query"
            elif upper.startswith("CREATE"):
                sym_type = "ddl"
            elif upper.startswith(("INSERT", "UPDATE", "DELETE", "MERGE")):
                sym_type = "dml"
            else:
                sym_type = "sql"

            name_match = re.search(
                r"(?:TABLE|VIEW|INDEX|FUNCTION|PROCEDURE)\s+"
                r"(?:IF\s+NOT\s+EXISTS\s+)?(\S+)",
                stmt,
                re.IGNORECASE,
            )
            symbol_name = name_match.group(1) if name_match else f"({sym_type})"

            end_line = line + stmt.count("\n")
            chunks.append(
                {
                    "content": stmt + ";",
                    "symbol_name": symbol_name,
                    "symbol_type": sym_type,
                    "line_start": line,
                    "line_end": end_line,
                }
            )
            line = end_line + 1

        return chunks

    # ------------------------------------------------------------------
    # 폴백 청킹
    # ------------------------------------------------------------------

    def _fallback_chunk(
        self, content: str, file_path: str, language: str
    ) -> List[Dict[str, Any]]:
        """구문 분석 실패 시 라인 기반 청킹."""
        lines = content.split("\n")
        chunks: List[Dict[str, Any]] = []
        current: List[str] = []
        start_line = 1

        for i, line in enumerate(lines, 1):
            current.append(line)
            if len("\n".join(current)) > 1000:
                chunks.append(
                    {
                        "content": "\n".join(current),
                        "symbol_name": "(block)",
                        "symbol_type": "block",
                        "line_start": start_line,
                        "line_end": i,
                    }
                )
                current = []
                start_line = i + 1

        if current:
            text = "\n".join(current)
            if len(text.strip()) > MIN_CHUNK_SIZE:
                chunks.append(
                    {
                        "content": text,
                        "symbol_name": "(block)",
                        "symbol_type": "block",
                        "line_start": start_line,
                        "line_end": len(lines),
                    }
                )

        return chunks

    # ------------------------------------------------------------------
    # 인덱싱 (전체)
    # ------------------------------------------------------------------

    async def index_codebase(
        self, root_dir: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """전체 코드베이스 인덱싱 (기존 데이터 삭제 후 재적재)."""
        root = Path(root_dir)
        if not root.is_dir():
            yield {"status": "error", "error": f"Not a directory: {root_dir}"}
            return

        self._load_gitignore(root)
        self._ensure_client()

        # 기존 컬렉션 삭제 후 재생성
        try:
            self._client.delete_collection(COLLECTION_NAME)
        except Exception:
            pass
        self._ensure_collection()

        included, excluded = self._collect_files(root)

        # 제외 파일 메타데이터 적재
        if excluded:
            await self._upsert_excluded_files(excluded, root)

        # 코드 파일 파싱 + 임베딩 + 적재
        total_chunks = 0
        for i, fp in enumerate(included):
            yield {
                "status": "running",
                "current": i + 1,
                "total": len(included),
                "file": fp.name,
            }

            try:
                chunks = self._parse_file(fp, root)
                if not chunks:
                    continue

                await self._upsert_chunks(chunks, fp, root)
                total_chunks += len(chunks)
            except Exception as e:
                logger.warning("CodeIndexer error %s: %s", fp, e)
                yield {"status": "error", "file": fp.name, "error": str(e)}

        self._save_last_indexed_at()
        yield {
            "status": "complete",
            "total_files": len(included),
            "excluded_files": len(excluded),
            "total_chunks": total_chunks,
        }

    # ------------------------------------------------------------------
    # 증분 업데이트
    # ------------------------------------------------------------------

    async def update_codebase(
        self, root_dir: str
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """증분 업데이트: 변경/추가/삭제된 파일만 처리."""
        root = Path(root_dir).resolve()
        print(f"[Codebase] update root={root}", flush=True)
        self._load_gitignore(root)
        self._ensure_collection()

        included, _ = self._collect_files(root)
        print(
            f"[Codebase] update collected {len(included)} files",
            flush=True,
        )

        # 기존 Qdrant 데이터 조회
        existing_hashes: Dict[str, str] = {}  # file_path → file_hash
        existing_ids: Dict[str, List[str]] = {}  # file_path → [point_ids]
        scroll_result = self._client.scroll(
            collection_name=COLLECTION_NAME,
            limit=100000,
            with_payload=True,
            with_vectors=False,
        )
        for pt in scroll_result[0]:
            fp = pt.payload.get("file_path", "")
            if not fp:
                continue
            existing_ids.setdefault(fp, []).append(str(pt.id))
            fh = pt.payload.get("file_hash", "")
            if fh:
                existing_hashes[fp] = fh

        current_paths = {str(fp.relative_to(root)) for fp in included}
        added = 0
        updated = 0
        deleted = 0
        added_files: List[str] = []
        updated_files: List[str] = []
        deleted_files: List[str] = []

        # 삭제된 파일
        from qdrant_client.models import PointIdsList

        # excluded_file 타입 포인트는 삭제 대상에서 제외
        excluded_paths: set[str] = set()
        for pt in scroll_result[0]:
            if pt.payload.get("symbol_type") == "excluded_file":
                excluded_paths.add(pt.payload.get("file_path", ""))

        for old_path, point_ids in existing_ids.items():
            if old_path in excluded_paths:
                continue  # 제외 파일 메타데이터는 유지
            if old_path not in current_paths:
                self._client.delete(
                    collection_name=COLLECTION_NAME,
                    points_selector=PointIdsList(points=point_ids),
                )
                deleted += 1
                deleted_files.append(old_path)

        # 변경/추가 대상 파일 먼저 식별
        changed_files: List[Tuple[Path, str, str]] = []  # (fp, rel_path, new_hash)
        for fp in included:
            rel_path = str(fp.relative_to(root))
            new_hash = self._file_hash(fp)
            _old_hash = existing_hashes.get(rel_path)
            if _old_hash == new_hash:
                continue
            changed_files.append((fp, rel_path, new_hash))

        total_changed = len(changed_files)
        print(
            f"[Codebase] changed files: {total_changed}",
            flush=True,
        )

        for i, (fp, rel_path, new_hash) in enumerate(changed_files):
            yield {
                "status": "running",
                "current": i + 1,
                "total": total_changed,
                "file": fp.name,
            }

            # 기존 포인트 삭제
            if rel_path in existing_ids:
                self._client.delete(
                    collection_name=COLLECTION_NAME,
                    points_selector=PointIdsList(points=existing_ids[rel_path]),
                )

            try:
                chunks = self._parse_file(fp, root)
                if chunks:
                    await self._upsert_chunks(chunks, fp, root)
                    if rel_path in existing_hashes:
                        updated += 1
                        updated_files.append(rel_path)
                    else:
                        added += 1
                        added_files.append(rel_path)
            except Exception as e:
                yield {"status": "error", "file": fp.name, "error": str(e)}

        print(
            f"[Codebase] update complete: added={added} updated={updated} deleted={deleted} "
            f"existing_hashes={len(existing_hashes)} current_paths={len(current_paths)}",
            flush=True,
        )
        if added or updated or deleted:
            self._save_last_indexed_at()
        yield {
            "status": "complete",
            "added": added,
            "updated": updated,
            "deleted": deleted,
            "added_files": added_files,
            "updated_files": updated_files,
            "deleted_files": deleted_files,
        }

    # ------------------------------------------------------------------
    # 삭제 / 상태 / 검색
    # ------------------------------------------------------------------

    def delete_codebase(self):
        """code_search 컬렉션 전체 삭제."""
        self._ensure_client()
        try:
            self._client.delete_collection(COLLECTION_NAME)
            logger.info("Deleted collection: %s", COLLECTION_NAME)
        except Exception:
            pass
        try:
            Path(LAST_INDEXED_AT_FILE).unlink(missing_ok=True)
        except Exception:
            pass

    @staticmethod
    def _save_last_indexed_at() -> None:
        """현재 시각을 ISO-8601 로 마지막 인덱싱 timestamp 파일에 기록."""
        try:
            from datetime import datetime

            Path(LAST_INDEXED_AT_FILE).parent.mkdir(parents=True, exist_ok=True)
            Path(LAST_INDEXED_AT_FILE).write_text(
                datetime.now().isoformat(timespec="seconds")
            )
        except Exception as e:
            logger.warning("Failed to save last_indexed_at: %s", e)

    @staticmethod
    def _read_last_indexed_at() -> Optional[str]:
        try:
            p = Path(LAST_INDEXED_AT_FILE)
            if p.is_file():
                return p.read_text().strip() or None
        except Exception:
            pass
        return None

    def get_status(self) -> Dict[str, Any]:
        """인덱싱 상태 조회. dirty 플래그 + 마지막 인덱싱 시각 포함."""
        dirty = self.is_dirty()
        last_indexed_at = self._read_last_indexed_at()
        self._ensure_client()
        try:
            existing = {c.name for c in self._client.get_collections().collections}
            if COLLECTION_NAME not in existing:
                return {
                    "indexed": False,
                    "total_points": 0,
                    "dirty": dirty,
                    "last_indexed_at": last_indexed_at,
                }
            count = self._client.count(COLLECTION_NAME).count
            return {
                "indexed": True,
                "total_points": count,
                "dirty": dirty,
                "last_indexed_at": last_indexed_at,
            }
        except Exception:
            return {
                "indexed": False,
                "total_points": 0,
                "dirty": dirty,
                "last_indexed_at": last_indexed_at,
            }

    def clear_dirty(self):
        """dirty 플래그 리셋. update 완료 후 호출."""
        self._dirty = False

    def browse(
        self,
        offset: Optional[str] = None,
        limit: int = 10,
    ) -> Dict[str, Any]:
        """컬렉션 포인트 페이징 조회."""
        self._ensure_client()
        try:
            existing = {c.name for c in self._client.get_collections().collections}
            if COLLECTION_NAME not in existing:
                return {"items": [], "next_offset": None, "count": 0}
        except Exception:
            return {"items": [], "next_offset": None, "count": 0}

        scroll_result = self._client.scroll(
            collection_name=COLLECTION_NAME,
            offset=offset,
            limit=limit,
            with_payload=True,
            with_vectors=False,
        )
        points, next_offset = scroll_result
        items = []
        for pt in points:
            payload = dict(pt.payload) if pt.payload else {}
            if "_embed_text" in payload:
                payload["_embed_text"] = payload["_embed_text"][:200] + "..."
            items.append({"id": str(pt.id), "payload": payload})
        return {
            "items": items,
            "next_offset": str(next_offset) if next_offset else None,
            "count": len(items),
        }

    async def search(
        self, query: str, top_k: int = 10, score_threshold: float = 0.3
    ) -> List[Dict[str, Any]]:
        """코드 검색."""
        self._ensure_client()
        try:
            existing = {c.name for c in self._client.get_collections().collections}
            if COLLECTION_NAME not in existing:
                return []
        except Exception:
            return []

        query_vec = await self._embedding.embed_query(query)
        # excluded_file 메타데이터를 검색 단계에서 제외 (실제 코드 청크만 top-k에 포함)
        from qdrant_client.models import FieldCondition, Filter, MatchValue

        qdrant_filter = Filter(
            must_not=[
                FieldCondition(
                    key="symbol_type",
                    match=MatchValue(value="excluded_file"),
                )
            ]
        )
        results = self._client.query_points(
            collection_name=COLLECTION_NAME,
            query=query_vec,
            limit=top_k,
            score_threshold=score_threshold,
            query_filter=qdrant_filter,
            with_payload=True,
        )
        return [
            {
                "content": pt.payload.get("content", ""),
                "file_path": pt.payload.get("file_path", ""),
                "symbol_name": pt.payload.get("symbol_name", ""),
                "symbol_type": pt.payload.get("symbol_type", ""),
                "line_start": pt.payload.get("line_start", 0),
                "line_end": pt.payload.get("line_end", 0),
                "language": pt.payload.get("language", ""),
                "score": round(pt.score, 4),
            }
            for pt in results.points
        ]

    # ------------------------------------------------------------------
    # Watchdog 자동 증분
    # ------------------------------------------------------------------

    def start_watcher(self, root_dir: str):
        """파일 변경 감시 시작. dirty 플래그만 설정 (업데이트는 polling으로 실행)."""
        try:
            from watchdog.events import FileSystemEventHandler
            from watchdog.observers import Observer
        except ImportError:
            logger.warning("watchdog not installed, auto-update disabled")
            return

        if self._observer:
            self.stop_watcher()

        class _Handler(FileSystemEventHandler):
            def __init__(self, indexer_ref):
                self._indexer = indexer_ref

            def on_any_event(self, event):
                if event.is_directory:
                    return
                src = Path(event.src_path)
                if src.suffix.lower() not in SUPPORTED_EXTENSIONS:
                    return
                self._indexer._dirty = True

        self._dirty = False
        self._observer = Observer()
        self._observer.schedule(_Handler(self), root_dir, recursive=True)
        self._observer.start()
        logger.info("CodeIndexer: watcher started for %s", root_dir)

    def stop_watcher(self):
        """파일 변경 감시 중지."""
        if self._observer:
            self._observer.stop()
            self._observer.join()
            self._observer = None
            self._dirty = False
            logger.info("CodeIndexer: watcher stopped")

    def is_dirty(self) -> bool:
        """변경 감지 여부 확인. polling에서 호출."""
        return getattr(self, "_dirty", False)

    # ------------------------------------------------------------------
    # 내부 헬퍼
    # ------------------------------------------------------------------

    def _parse_file(self, fp: Path, root: Path) -> List[Dict[str, Any]]:
        """파일 파싱 → 청크 리스트."""
        content = fp.read_text(encoding="utf-8", errors="replace")
        rel_path = str(fp.relative_to(root))

        if fp.suffix.lower() == ".py":
            return self._parse_python(content, rel_path)
        elif fp.suffix.lower() == ".sql":
            return self._parse_sql(content, rel_path)
        elif fp.suffix.lower() == ".ipynb":
            return self._parse_ipynb(content, rel_path)
        return []

    # ------------------------------------------------------------------
    # Jupyter Notebook 파싱
    # ------------------------------------------------------------------

    def _parse_ipynb(self, content: str, file_path: str) -> List[Dict[str, Any]]:
        """Jupyter notebook 파싱.

        - outputs는 인덱싱 제외 (소스 셀만)
        - 짧은 인접 셀을 묶어서 의미 단위 chunk 구성 (markdown→code 컨텍스트 보존)
        - 각 셀에 ``# [셀 N - code|markdown]`` prefix → LLM이 노트북 셀임을 인식
        - 큰 셀(MAX_CHUNK_SIZE 초과)은 AST로 함수/클래스 단위 split (code only)
        """
        try:
            nb = json.loads(content)
        except (json.JSONDecodeError, ValueError):
            logger.warning("Invalid notebook JSON: %s", file_path)
            return []

        raw_cells = nb.get("cells", [])
        cells: List[Dict[str, Any]] = []
        for idx, cell in enumerate(raw_cells):
            src = cell.get("source", "")
            if isinstance(src, list):
                src = "".join(src)
            src = (src or "").strip()
            if not src:
                continue
            ctype = cell.get("cell_type", "raw")
            if ctype not in ("code", "markdown"):
                continue
            if ctype == "markdown":
                # 링크 [text](url) → text만 유지
                src = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", src)
            cells.append({"index": idx, "type": ctype, "content": src})

        if not cells:
            return []

        target_size = 400  # 셀 그룹 최소 누적 크기
        chunks: List[Dict[str, Any]] = []
        buffer: List[Dict[str, Any]] = []
        buffer_len = 0

        def flush_buffer():
            nonlocal buffer, buffer_len
            if not buffer:
                return
            parts = []
            has_code = False
            for c in buffer:
                tag = f"# [셀 {c['index']} - {c['type']}]"
                parts.append(f"{tag}\n{c['content']}")
                if c["type"] == "code":
                    has_code = True
            merged = "\n\n".join(parts)
            first_idx = buffer[0]["index"]
            last_idx = buffer[-1]["index"]
            symbol_name = (
                f"cell_{first_idx}"
                if first_idx == last_idx
                else f"cells_{first_idx}_{last_idx}"
            )
            symbol_type = "notebook_code_cell" if has_code else "notebook_markdown"
            chunks.append(
                {
                    "content": merged,
                    "symbol_name": symbol_name,
                    "symbol_type": symbol_type,
                    "line_start": 1,
                    "line_end": len(merged.splitlines()),
                }
            )
            buffer = []
            buffer_len = 0

        for c in cells:
            # 거대 셀: 단독 처리 (AST split 또는 그대로)
            if len(c["content"]) > MAX_CHUNK_SIZE:
                flush_buffer()
                if c["type"] == "code":
                    sub = self._parse_python(c["content"], file_path)
                    for s in sub:
                        s["symbol_type"] = "notebook_code_function"
                        s["symbol_name"] = f"cell_{c['index']}::{s['symbol_name']}"
                    if sub:
                        chunks.extend(sub)
                    else:
                        # AST 실패 → 단일 chunk
                        chunks.append(
                            {
                                "content": f"# [셀 {c['index']} - code]\n{c['content']}",
                                "symbol_name": f"cell_{c['index']}",
                                "symbol_type": "notebook_code_cell",
                                "line_start": 1,
                                "line_end": len(c["content"].splitlines()),
                            }
                        )
                else:
                    chunks.append(
                        {
                            "content": f"# [셀 {c['index']} - markdown]\n{c['content']}",
                            "symbol_name": f"cell_{c['index']}_md",
                            "symbol_type": "notebook_markdown",
                            "line_start": 1,
                            "line_end": len(c["content"].splitlines()),
                        }
                    )
                continue

            buffer.append(c)
            buffer_len += len(c["content"])
            if buffer_len >= target_size:
                flush_buffer()

        flush_buffer()
        return chunks

    async def _upsert_chunks(self, chunks: List[Dict[str, Any]], fp: Path, root: Path):
        """청크 임베딩 + Qdrant upsert."""
        from qdrant_client.models import PointStruct

        rel_path = str(fp.relative_to(root))
        file_hash = self._file_hash(fp)
        lang = fp.suffix.lstrip(".")

        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []

        for chunk in chunks:
            embed_text = (
                f"[{rel_path} > {chunk['symbol_name']} ({chunk['symbol_type']})]\n"
                f"{chunk['content']}"
            )
            texts.append(embed_text)
            payloads.append(
                {
                    "content": chunk["content"],
                    "file_path": rel_path,
                    "symbol_name": chunk["symbol_name"],
                    "symbol_type": chunk["symbol_type"],
                    "line_start": chunk["line_start"],
                    "line_end": chunk["line_end"],
                    "language": lang,
                    "file_hash": file_hash,
                    "_embed_text": embed_text,
                }
            )

        embeddings = await self._embedding.embed_texts(texts)

        points = [
            PointStruct(id=str(uuid.uuid4()), vector=vec, payload=payload)
            for vec, payload in zip(embeddings, payloads)
        ]
        self._client.upsert(collection_name=COLLECTION_NAME, points=points)

    async def _upsert_excluded_files(
        self, excluded: List[Tuple[Path, str]], root: Path
    ):
        """제외 파일 메타데이터만 적재."""
        from qdrant_client.models import PointStruct

        texts: List[str] = []
        payloads: List[Dict[str, Any]] = []

        for fp, reason in excluded:
            rel_path = str(fp.relative_to(root))
            try:
                size = fp.stat().st_size
            except OSError:
                size = 0
            texts.append(f"[excluded] {rel_path}")
            payloads.append(
                {
                    "content": "",
                    "file_path": rel_path,
                    "symbol_name": "",
                    "symbol_type": "excluded_file",
                    "language": "",
                    "file_size": size,
                    "excluded_reason": reason,
                    "line_start": 0,
                    "line_end": 0,
                }
            )

        embeddings = await self._embedding.embed_texts(texts)

        points = [
            PointStruct(id=str(uuid.uuid4()), vector=vec, payload=payload)
            for vec, payload in zip(embeddings, payloads)
        ]
        self._client.upsert(collection_name=COLLECTION_NAME, points=points)
