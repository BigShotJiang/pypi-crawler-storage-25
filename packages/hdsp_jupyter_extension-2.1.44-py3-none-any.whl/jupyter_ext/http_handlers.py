"""HDSP Jupyter Extension Handlers.

ServiceFactory-based handlers for in-process execution.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import time
from collections.abc import Awaitable, Callable
from datetime import datetime as _datetime, timezone as _tz
from typing import Any
from uuid import uuid4

import httpx
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join

from .handlers.analytics_handler import AnalyticsEventsHandler
from .handlers.benchmark_handler import (
    BenchmarkGenerateHandler,
    BenchmarkResultsHandler,
    BenchmarkRunHandler,
    BenchmarkSourcesHandler,
    BenchmarkTestCasesHandler,
)
from .handlers.eda_benchmark_handler import (
    EdaBenchmarkGenerateHandler,
    EdaBenchmarkResultsHandler,
    EdaBenchmarkRunHandler,
    EdaBenchmarkSourcesHandler,
    EdaBenchmarkTestCasesHandler,
)
from .handlers.rag_admin_handler import (
    RAGAdminBrowseHandler as _RAGAdminBrowseHandler,
    RAGAdminConfigHandler as _RAGAdminConfigHandler,
    RAGAdminDeleteHandler as _RAGAdminDeleteHandler,
    RAGAdminDryRunHandler as _RAGAdminDryRunHandler,
    RAGAdminHistoryHandler as _RAGAdminHistoryHandler,
    RAGAdminPreviewHandler as _RAGAdminPreviewHandler,
    RAGAdminProgressHandler as _RAGAdminProgressHandler,
    RAGAdminSearchTestHandler as _RAGAdminSearchTestHandler,
    RAGAdminStatsHandler as _RAGAdminStatsHandler,
    RAGAdminTestConnectionHandler as _RAGAdminTestConnectionHandler,
    RAGAdminUpsertHandler as _RAGAdminUpsertHandler,
    RAGAdminGuidePipelineHandler as _RAGAdminGuidePipelineHandler,
    RAGAdminGuidePipelineStatusHandler as _RAGAdminGuidePipelineStatusHandler,
    RAGAdminValidateHandler as _RAGAdminValidateHandler,
    RAGAdminCodebaseHandler as _RAGAdminCodebaseHandler,
    RAGAdminCodebaseStatusHandler as _RAGAdminCodebaseStatusHandler,
    RAGAdminCodebaseWatcherHandler as _RAGAdminCodebaseWatcherHandler,
    RAGAdminCancelHandler as _RAGAdminCancelHandler,
)
from .resource_usage import (
    classify_resource_tiers,
    generate_tier_guidance,
    get_integrated_resources,
)

# Lazy imports: these pull in deepagents/langgraph which may fail in some environments.
# Import failures here must NOT prevent basic handler registration.
try:
    from langgraph.checkpoint.memory import MemorySaver as _MemorySaver

    _LANGGRAPH_AVAILABLE = True
except ImportError:
    _MemorySaver = None  # type: ignore[assignment,misc]
    _LANGGRAPH_AVAILABLE = False

try:
    from .agent.json_repair_utils import ensure_str, safe_json_dumps, safe_parse_json

    _AGENT_UTILS_AVAILABLE = True
except ImportError:
    _AGENT_UTILS_AVAILABLE = False

    def ensure_str(v: Any) -> str:  # type: ignore[misc]
        return str(v) if v is not None else ""

    def safe_json_dumps(v: Any) -> str:  # type: ignore[misc]
        import json as _json

        return _json.dumps(v)

    def safe_parse_json(v: Any) -> Any:  # type: ignore[misc]
        import json as _json

        try:
            return _json.loads(v)
        except Exception:
            return None


logger = logging.getLogger(__name__)
if not logger.handlers and not logger.parent.handlers:
    logger.setLevel(logging.INFO)

DEFAULT_EXECUTE_COMMAND_TIMEOUT_MS = 600_000
MAX_EXECUTE_COMMAND_STREAM_BYTES = 1_000_000


def _resolve_timeout_ms(
    value: Any,
    default: int = DEFAULT_EXECUTE_COMMAND_TIMEOUT_MS,
) -> int:
    """Resolve timeout in milliseconds with a safe default."""
    try:
        timeout_ms = int(value)
    except (TypeError, ValueError):
        return default
    if timeout_ms <= 0:
        return default
    return timeout_ms


def _resolve_stream_timeout_ms(
    value: Any,
    default: int = DEFAULT_EXECUTE_COMMAND_TIMEOUT_MS,
) -> int | None:
    """Resolve timeout in milliseconds; non-positive disables timeout."""
    try:
        timeout_ms = int(value)
    except (TypeError, ValueError):
        return default
    if timeout_ms <= 0:
        return None
    return timeout_ms


def _resolve_workspace_root(server_root: str) -> str:
    """Resolve workspace root by walking up to the project root if needed."""
    current = os.path.abspath(server_root)
    while True:
        if os.path.isdir(os.path.join(current, "extensions")):
            return current
        parent = os.path.dirname(current)
        if parent == current:
            return os.path.abspath(server_root)
        current = parent


def _get_effective_workspace_root(
    server_root: str,
    user_workspace_root: str | None,
) -> str:
    """Get effective workspace root, respecting user's setting if provided.

    Args:
        server_root: The Jupyter server's root directory
        user_workspace_root: User-provided workspace root from settings

    Returns:
        The effective workspace root to use for file operations

    """
    resolved_root = _resolve_workspace_root(server_root)

    if user_workspace_root and os.path.isabs(user_workspace_root):
        return user_workspace_root
    if user_workspace_root:
        return os.path.join(resolved_root, user_workspace_root)
    return resolved_root


def _get_service_factory():
    """Get ServiceFactory instance (lazy import to avoid circular imports)"""
    from hdsp_agent_core.factory import get_service_factory

    return get_service_factory()


def _is_embedded_mode() -> bool:
    """Check if running in embedded mode"""
    try:
        factory = _get_service_factory()
        return factory.is_embedded
    except Exception:
        return False


def _run_shell_command(
    command: str,
    timeout_ms: int,
    cwd: str,
    stdin_input: str | None = None,
) -> dict[str, Any]:
    """Run a shell command with timeout and capture output.

    Args:
        command: Shell command to execute
        timeout_ms: Timeout in milliseconds
        cwd: Working directory
        stdin_input: Optional input to provide to the command (for interactive prompts)

    """
    timeout_sec = max(0.1, timeout_ms / 1000)
    try:
        result = subprocess.run(
            command,
            check=False,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            cwd=cwd,
            input=stdin_input,  # Provide stdin if specified
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "returncode": result.returncode,
            "cwd": cwd,
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": f"Command timed out after {timeout_sec}s. If the command requires user input, use stdin parameter or non-interactive flags.",
            "cwd": cwd,
        }
    except Exception as exc:
        return {"success": False, "error": str(exc), "cwd": cwd}


def _append_stream_output(
    current: str,
    chunk: str,
    max_bytes: int = MAX_EXECUTE_COMMAND_STREAM_BYTES,
) -> tuple[str, bool]:
    """Append output chunk, truncating when max_bytes is reached."""
    if not chunk:
        return current, False
    current_bytes = current.encode("utf-8")
    if len(current_bytes) >= max_bytes:
        return current, True
    chunk_bytes = chunk.encode("utf-8")
    remaining = max_bytes - len(current_bytes)
    if len(chunk_bytes) <= remaining:
        return current + chunk, False
    truncated_chunk = chunk_bytes[:remaining].decode("utf-8", errors="ignore")
    return current + truncated_chunk, True


async def _stream_subprocess_output(
    stream: asyncio.StreamReader | None,
    stream_name: str,
    emit: Callable[[str, dict[str, Any]], Awaitable[None]],
    append: Callable[[str], None],
) -> None:
    """Stream subprocess output lines and collect them."""
    if stream is None:
        return
    while True:
        chunk = await stream.readline()
        if not chunk:
            break
        text = chunk.decode("utf-8", errors="replace")
        await emit("output", {"stream": stream_name, "text": text})
        append(text)


def _resolve_path_in_workspace(
    path: str,
    workspace_root: str,
    requested_cwd: str | None = None,
) -> str:
    """Resolve a relative path within the workspace root."""
    if os.path.isabs(path):
        raise ValueError("absolute paths are not allowed")
    if ".." in path:
        raise ValueError("parent directory traversal is not allowed")

    normalized_path = os.path.normpath(path)
    base_dir = workspace_root
    if requested_cwd:
        if os.path.isabs(requested_cwd):
            resolved_cwd = os.path.abspath(requested_cwd)
        else:
            resolved_cwd = os.path.abspath(os.path.join(workspace_root, requested_cwd))
        if os.path.commonpath([workspace_root, resolved_cwd]) != workspace_root:
            raise ValueError("cwd escapes workspace root")
        base_dir = resolved_cwd

        rel_cwd = os.path.normpath(os.path.relpath(resolved_cwd, workspace_root))
        if rel_cwd != ".":
            prefix = rel_cwd + os.sep
            if normalized_path == rel_cwd:
                normalized_path = "."
            elif normalized_path.startswith(prefix):
                normalized_path = normalized_path[len(prefix) :]

    resolved_path = os.path.abspath(os.path.join(base_dir, normalized_path))
    if os.path.commonpath([workspace_root, resolved_path]) != workspace_root:
        raise ValueError("path escapes workspace root")
    return resolved_path


def _resolve_command_cwd(
    server_root: str,
    workspace_root: str,
    requested_cwd: str | None = None,
) -> str:
    """Resolve command cwd within workspace root."""
    default_cwd = os.path.abspath(server_root)
    if os.path.commonpath([workspace_root, default_cwd]) != workspace_root:
        default_cwd = workspace_root

    if not requested_cwd:
        return default_cwd

    if os.path.isabs(requested_cwd):
        resolved_cwd = os.path.abspath(requested_cwd)
    else:
        resolved_cwd = os.path.abspath(os.path.join(default_cwd, requested_cwd))

    if os.path.commonpath([workspace_root, resolved_cwd]) != workspace_root:
        raise ValueError("cwd escapes workspace root")

    return resolved_cwd


def _write_file(
    resolved_path: str,
    content: str,
    encoding: str,
    overwrite: bool,
) -> dict[str, Any]:
    """Write content to a file on disk."""
    print(
        f"[WRITE DEBUG] resolved_path={resolved_path}, overwrite={overwrite}, type={type(overwrite)}",
        flush=True,
    )
    try:
        dir_path = os.path.dirname(resolved_path)
        if dir_path:
            os.makedirs(dir_path, exist_ok=True)
        mode = "w" if overwrite else "x"
        print(f"[WRITE DEBUG] mode={mode}", flush=True)
        with open(resolved_path, mode, encoding=encoding) as f:
            f.write(content)
        return {
            "success": True,
            "size": len(content),
        }
    except FileExistsError:
        return {
            "success": False,
            "error": "File already exists. Set overwrite=true to overwrite.",
        }
    except Exception as exc:
        return {"success": False, "error": str(exc)}


def _is_ripgrep_available() -> bool:
    """Check if ripgrep (rg) is installed."""
    import shutil

    return shutil.which("rg") is not None


def _build_search_command(
    pattern: str,
    file_types: list,
    path: str,
    case_sensitive: bool,
    max_results: int,
) -> tuple:
    """Build grep/ripgrep command for searching files."""
    use_ripgrep = _is_ripgrep_available()

    if use_ripgrep:
        cmd_parts = ["rg", "--line-number", "--with-filename"]
        if not case_sensitive:
            cmd_parts.append("--ignore-case")
        for ft in file_types:
            cmd_parts.extend(["--glob", ft])
        cmd_parts.extend(["--max-count", str(max_results)])
        escaped_pattern = pattern.replace("'", "'\\''")
        cmd_parts.append(f"'{escaped_pattern}'")
        cmd_parts.append(path)
        return " ".join(cmd_parts), "rg"
    find_parts = ["find", path, "-type", "f", "\\("]
    for i, ft in enumerate(file_types):
        if i > 0:
            find_parts.append("-o")
        find_parts.extend(["-name", f"'{ft}'"])
    find_parts.append("\\)")
    grep_flags = "n" + ("" if case_sensitive else "i")
    escaped_pattern = pattern.replace("'", "'\\''")
    cmd = f"{' '.join(find_parts)} 2>/dev/null | xargs grep -{grep_flags} '{escaped_pattern}' 2>/dev/null | head -n {max_results}"
    return cmd, "grep"


def _parse_grep_output(output: str, workspace_root: str) -> list:
    """Parse grep/ripgrep output into structured results."""
    results = []
    for line in output.strip().split("\n"):
        if not line:
            continue
        parts = line.split(":", 2)
        if len(parts) >= 2:
            file_path = parts[0]
            try:
                line_num = int(parts[1])
                content = parts[2] if len(parts) > 2 else ""
            except ValueError:
                line_num = 0
                content = line
            try:
                rel_path = os.path.relpath(file_path, workspace_root)
            except ValueError:
                rel_path = file_path
            results.append(
                {
                    "file_path": rel_path,
                    "line_number": line_num,
                    "content": content.strip()[:200],
                    "match_type": "line",
                },
            )
    return results


def _search_in_notebook(
    notebook_path: str,
    pattern: str,
    cell_type: str | None,
    case_sensitive: bool,
) -> list:
    """Search for pattern in notebook cells."""
    import re

    results = []
    flags = 0 if case_sensitive else re.IGNORECASE

    try:
        compiled = re.compile(pattern, flags)
    except re.error:
        compiled = re.compile(re.escape(pattern), flags)

    try:
        with open(notebook_path, encoding="utf-8") as f:
            notebook = json.load(f)
        cells = notebook.get("cells", [])
        for idx, cell in enumerate(cells):
            current_type = cell.get("cell_type", "code")
            if cell_type and current_type != cell_type:
                continue
            source = cell.get("source", [])
            if isinstance(source, list):
                source = "".join(source)
            if compiled.search(source):
                matching_lines = []
                for line_num, line in enumerate(source.split("\n"), 1):
                    if compiled.search(line):
                        matching_lines.append(
                            {"line": line_num, "content": line.strip()[:150]},
                        )
                results.append(
                    {
                        "cell_index": idx,
                        "cell_type": current_type,
                        "content": source[:300] + "..."
                        if len(source) > 300
                        else source,
                        "matching_lines": matching_lines[:5],
                        "match_type": "cell",
                    },
                )
    except Exception as e:
        logger.warning(f"Error searching notebook {notebook_path}: {e}")
    return results


def _execute_search_workspace(
    pattern: str,
    file_types: list,
    path: str,
    max_results: int,
    case_sensitive: bool,
    workspace_root: str,
) -> dict[str, Any]:
    """Execute workspace search using subprocess."""
    search_path = os.path.normpath(os.path.join(workspace_root, path))
    if not os.path.exists(search_path):
        return {
            "success": False,
            "error": f"Path does not exist: {path}",
            "results": [],
            "total_results": 0,
        }

    command, tool_used = _build_search_command(
        pattern,
        file_types,
        search_path,
        case_sensitive,
        max_results,
    )
    print(f"[SEARCH DEBUG] Executing search: {command}", flush=True)
    print(
        f"[SEARCH DEBUG] cwd: {workspace_root}, search_path: {search_path}",
        flush=True,
    )

    # Debug: test find command separately
    find_only = f"find {search_path} -type f -name '*.py' | head -5"
    find_result = subprocess.run(
        find_only,
        check=False,
        shell=True,
        capture_output=True,
        text=True,
        timeout=10,
        cwd=workspace_root,
    )
    print(
        f"[SEARCH DEBUG] find only stdout: {find_result.stdout[:300] if find_result.stdout else 'EMPTY'}",
        flush=True,
    )

    try:
        result = subprocess.run(
            command,
            check=False,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=workspace_root,
        )
        print(
            f"[SEARCH DEBUG] stdout: {result.stdout[:500] if result.stdout else 'EMPTY'}",
            flush=True,
        )
        print(
            f"[SEARCH DEBUG] stderr: {result.stderr[:500] if result.stderr else 'EMPTY'}",
            flush=True,
        )
        print(f"[SEARCH DEBUG] returncode: {result.returncode}", flush=True)
        results = _parse_grep_output(result.stdout, workspace_root)

        # Also search in notebook cell contents
        notebook_results = []
        if any("ipynb" in ft for ft in file_types):
            find_cmd = f"find {search_path} -name '*.ipynb' -type f 2>/dev/null"
            nb_result = subprocess.run(
                find_cmd,
                check=False,
                shell=True,
                capture_output=True,
                text=True,
                timeout=10,
                cwd=workspace_root,
            )
            if nb_result.returncode == 0 and nb_result.stdout:
                notebooks = nb_result.stdout.strip().split("\n")
                for nb_path in notebooks[:20]:
                    if nb_path and os.path.exists(nb_path):
                        nb_matches = _search_in_notebook(
                            nb_path,
                            pattern,
                            None,
                            case_sensitive,
                        )
                        for m in nb_matches:
                            try:
                                m["file_path"] = os.path.relpath(
                                    nb_path,
                                    workspace_root,
                                )
                            except ValueError:
                                m["file_path"] = nb_path
                        notebook_results.extend(nb_matches)
                        if len(notebook_results) >= max_results:
                            break

        all_results = results + notebook_results
        return {
            "success": True,
            "command": command,
            "tool_used": tool_used,
            "results": all_results[:max_results],
            "total_results": len(all_results),
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "error": "Search timed out",
            "results": [],
            "total_results": 0,
        }
    except Exception as e:
        return {"success": False, "error": str(e), "results": [], "total_results": 0}


def _execute_search_notebook_cells(
    pattern: str,
    notebook_path: str | None,
    cell_type: str | None,
    max_results: int,
    case_sensitive: bool,
    workspace_root: str,
) -> dict[str, Any]:
    """Execute notebook cell search."""
    results = []
    notebooks_searched = 0

    try:
        if notebook_path:
            full_path = os.path.normpath(os.path.join(workspace_root, notebook_path))
            if os.path.exists(full_path) and full_path.endswith(".ipynb"):
                matches = _search_in_notebook(
                    full_path,
                    pattern,
                    cell_type,
                    case_sensitive,
                )
                for m in matches:
                    m["file_path"] = notebook_path
                results.extend(matches)
                notebooks_searched = 1
            else:
                return {
                    "success": False,
                    "error": f"Notebook not found: {notebook_path}",
                    "results": [],
                    "total_results": 0,
                    "notebooks_searched": 0,
                }
        else:
            find_cmd = f"find {workspace_root} -name '*.ipynb' -type f 2>/dev/null"
            find_result = subprocess.run(
                find_cmd,
                check=False,
                shell=True,
                capture_output=True,
                text=True,
                timeout=10,
                cwd=workspace_root,
            )
            if find_result.returncode == 0 and find_result.stdout:
                notebooks = find_result.stdout.strip().split("\n")
                for nb_full_path in notebooks:
                    if not nb_full_path or not os.path.exists(nb_full_path):
                        continue
                    notebooks_searched += 1
                    matches = _search_in_notebook(
                        nb_full_path,
                        pattern,
                        cell_type,
                        case_sensitive,
                    )
                    try:
                        rel_path = os.path.relpath(nb_full_path, workspace_root)
                    except ValueError:
                        rel_path = nb_full_path
                    for m in matches:
                        m["file_path"] = rel_path
                    results.extend(matches)
                    if len(results) >= max_results:
                        break

        return {
            "success": True,
            "results": results[:max_results],
            "total_results": len(results),
            "notebooks_searched": notebooks_searched,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "results": [],
            "total_results": 0,
            "notebooks_searched": 0,
        }


# ============ Service-Based Handlers ============


class AgentPlanHandler(APIHandler):
    """Handler for /agent/plan endpoint using ServiceFactory."""

    async def post(self):
        """Generate execution plan."""
        try:
            from hdsp_agent_core.models.agent import PlanRequest

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            # Parse request
            body = json.loads(self.request.body.decode("utf-8"))
            request = PlanRequest(**body)

            # Call service
            response = await agent_service.generate_plan(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Plan generation failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentRefineHandler(APIHandler):
    """Handler for /agent/refine endpoint using ServiceFactory."""

    async def post(self):
        """Refine code after error."""
        try:
            from hdsp_agent_core.models.agent import RefineRequest

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = RefineRequest(**body)

            response = await agent_service.refine_code(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Refine failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentReplanHandler(APIHandler):
    """Handler for /agent/replan endpoint using ServiceFactory."""

    async def post(self):
        """Determine how to handle failed step."""
        try:
            from hdsp_agent_core.models.agent import ReplanRequest

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = ReplanRequest(**body)

            response = await agent_service.replan(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Replan failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentValidateHandler(APIHandler):
    """Handler for /agent/validate endpoint using ServiceFactory."""

    async def post(self):
        """Validate code before execution."""
        try:
            factory = _get_service_factory()
            agent_service = factory.get_agent_service()

            body = json.loads(self.request.body.decode("utf-8"))
            code = body.get("code", "")
            notebook_context = body.get("notebookContext")

            response = await agent_service.validate_code(code, notebook_context)

            self.set_header("Content-Type", "application/json")
            self.write(response)

        except Exception as e:
            logger.error(f"Validate failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ChatMessageHandler(APIHandler):
    """Handler for /chat/message endpoint using ServiceFactory."""

    async def post(self):
        """Send chat message and get response."""
        try:
            from hdsp_agent_core.models.chat import ChatRequest

            factory = _get_service_factory()
            chat_service = factory.get_chat_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = ChatRequest(**body)

            response = await chat_service.send_message(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"Chat message failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


def _inject_resource_context(message: str, settings: dict) -> str:
    """{{RESOURCE_CONTEXT}} 플레이스홀더를 실제 시스템 리소스 정보로 치환."""
    try:
        server_root = settings.get("server_root_dir", os.getcwd())
        data = get_integrated_resources(
            workspace_root=_resolve_workspace_root(server_root),
        )

        # summary 생성
        parts: list[str] = []
        cpu = data.get("cpu", {})
        if cpu.get("cores"):
            usage = (
                f" ({cpu['usage_percent']:.0f}%)"
                if cpu.get("usage_percent") is not None
                else ""
            )
            parts.append(f"CPU {cpu['cores']}코어{usage}")
        mem = data.get("memory", {})
        if mem.get("total_gb") is not None:
            avail = (
                f", 가용 {mem['available_gb']:.1f}GB"
                if mem.get("available_gb") is not None
                else ""
            )
            parts.append(f"RAM {mem['total_gb']:.1f}GB{avail}")
        gpus = data.get("gpus", [])
        if gpus:
            for g in gpus:
                name = g.get("name", "GPU")
                total = (
                    f" {g['memory_total_mb'] / 1024:.0f}GB"
                    if g.get("memory_total_mb")
                    else ""
                )
                used = (
                    f" (사용 {g['memory_used_mb'] / 1024:.1f}GB)"
                    if g.get("memory_used_mb")
                    else ""
                )
                parts.append(f"GPU {name}{total}{used}")
        summary = " | ".join(parts) if parts else ""

        # guidance 생성 (세분화된 tier 기반)
        tiers = classify_resource_tiers(data)
        guidance = generate_tier_guidance(tiers, mode="review")

        if not summary:
            return message.replace("{{RESOURCE_CONTEXT}}", "")

        replacement = (
            f"> **실행 환경**: {summary}\n\n**환경 기반 점검 가이드**:\n{guidance}"
        )
        return message.replace("{{RESOURCE_CONTEXT}}", replacement)

    except Exception as e:
        logger.warning(f"Resource context injection failed: {e}")
        return message.replace("{{RESOURCE_CONTEXT}}", "")


class ChatStreamHandler(APIHandler):
    """Handler for /chat/stream endpoint using ServiceFactory."""

    async def post(self):
        """Send chat message and get streaming response."""
        try:
            from hdsp_agent_core.models.chat import ChatRequest

            factory = _get_service_factory()
            chat_service = factory.get_chat_service()

            body = json.loads(self.request.body.decode("utf-8"))

            # 리소스 컨텍스트 플레이스홀더 치환
            msg = body.get("message", "")
            if "{{RESOURCE_CONTEXT}}" in msg:
                body["message"] = _inject_resource_context(msg, self.settings)

            request = ChatRequest(**body)

            # Set SSE headers
            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async for chunk in chat_service.send_message_stream(request):
                self.write(f"data: {json.dumps(chunk)}\n\n")
                await self.flush()

            self.finish()

        except Exception as e:
            logger.error(f"Chat stream failed: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
            self.finish()


class RAGSearchHandler(APIHandler):
    """Handler for /rag/search endpoint using ServiceFactory."""

    async def post(self):
        """Search knowledge base."""
        try:
            from hdsp_agent_core.models.rag import SearchRequest

            factory = _get_service_factory()
            rag_service = factory.get_rag_service()

            body = json.loads(self.request.body.decode("utf-8"))
            request = SearchRequest(**body)

            response = await rag_service.search(request)

            self.set_header("Content-Type", "application/json")
            self.write(response.model_dump(mode="json"))

        except Exception as e:
            logger.error(f"RAG search failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ExecuteCommandHandler(APIHandler):
    """Handler for /execute-command endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute shell command after user approval."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            command = (body.get("command") or "").strip()
            timeout_ms = _resolve_timeout_ms(body.get("timeout"))
            requested_cwd = (body.get("cwd") or "").strip()
            stdin_input = body.get("stdin")  # Optional stdin for interactive commands
            user_workspace_root = body.get("workspaceRoot")

            if not command:
                self.set_status(400)
                self.write({"error": "command is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            try:
                cwd = _resolve_command_cwd(server_root, workspace_root, requested_cwd)
            except ValueError as exc:
                self.set_status(400)
                self.write({"error": str(exc)})
                return

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: _run_shell_command(command, timeout_ms, cwd, stdin_input),
            )

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Execute command failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ExecuteCommandStreamHandler(APIHandler):
    """Handler for /execute-command/stream endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute shell command and stream output."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            command = (body.get("command") or "").strip()
            timeout_ms = _resolve_stream_timeout_ms(body.get("timeout"))
            requested_cwd = (body.get("cwd") or "").strip()
            stdin_input = body.get("stdin")  # Optional stdin for interactive commands
            user_workspace_root = body.get("workspaceRoot")

            if not command:
                self.set_status(400)
                self.write({"error": "command is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            try:
                cwd = _resolve_command_cwd(server_root, workspace_root, requested_cwd)
            except ValueError as exc:
                self.set_status(400)
                self.write({"error": str(exc)})
                return

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async def emit(event: str, payload: dict[str, Any]) -> None:
                self.write(f"event: {event}\n")
                self.write(f"data: {json.dumps(payload)}\n\n")
                await self.flush()

            start_time = time.monotonic()
            await emit("start", {"command": command, "cwd": cwd})

            # Use PIPE for stdin if input is provided
            stdin_pipe = asyncio.subprocess.PIPE if stdin_input else None
            process = await asyncio.create_subprocess_shell(
                command,
                stdin=stdin_pipe,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )

            # Write stdin if provided
            if stdin_input and process.stdin:
                process.stdin.write(stdin_input.encode())
                await process.stdin.drain()
                process.stdin.close()
                await process.stdin.wait_closed()

            stdout_text = ""
            stderr_text = ""
            stdout_truncated = False
            stderr_truncated = False

            def append_stdout(text: str) -> None:
                nonlocal stdout_text, stdout_truncated
                stdout_text, truncated = _append_stream_output(stdout_text, text)
                stdout_truncated = stdout_truncated or truncated

            def append_stderr(text: str) -> None:
                nonlocal stderr_text, stderr_truncated
                stderr_text, truncated = _append_stream_output(stderr_text, text)
                stderr_truncated = stderr_truncated or truncated

            stdout_task = asyncio.create_task(
                _stream_subprocess_output(
                    process.stdout, "stdout", emit, append_stdout
                ),
            )
            stderr_task = asyncio.create_task(
                _stream_subprocess_output(
                    process.stderr, "stderr", emit, append_stderr
                ),
            )

            timed_out = False
            timeout_sec = None if timeout_ms is None else max(0.1, timeout_ms / 1000)
            try:
                if timeout_sec is None:
                    await process.wait()
                else:
                    await asyncio.wait_for(process.wait(), timeout=timeout_sec)
            except TimeoutError:
                timed_out = True
                process.kill()
                await process.wait()

            try:
                await asyncio.wait_for(
                    asyncio.gather(stdout_task, stderr_task),
                    timeout=0.5,
                )
            except TimeoutError:
                stdout_task.cancel()
                stderr_task.cancel()
                await asyncio.gather(stdout_task, stderr_task, return_exceptions=True)

            duration_ms = int((time.monotonic() - start_time) * 1000)
            truncated = stdout_truncated or stderr_truncated
            if timed_out:
                result = {
                    "success": False,
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "returncode": process.returncode,
                    "error": f"Command timed out after {timeout_sec}s",
                    "truncated": truncated,
                    "cwd": cwd,
                    "duration_ms": duration_ms,
                }
            else:
                result = {
                    "success": process.returncode == 0,
                    "stdout": stdout_text,
                    "stderr": stderr_text,
                    "returncode": process.returncode,
                    "truncated": truncated,
                    "cwd": cwd,
                    "duration_ms": duration_ms,
                }

            await emit("result", result)
            self.finish()

        except Exception as e:
            logger.error(f"Execute command stream failed: {e}", exc_info=True)
            self.set_header("Content-Type", "text/event-stream")
            self.write(f"event: error\ndata: {json.dumps({'error': str(e)})}\n\n")
            self.finish()


class ResourceUsageHandler(APIHandler):
    """Handler for /resource-usage endpoint (runs on Jupyter server)."""

    async def get(self):
        """Return resource usage summary for the client host."""
        try:
            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _resolve_workspace_root(server_root)

            resource = get_integrated_resources(workspace_root=workspace_root)

            self.set_header("Content-Type", "application/json")
            self.write({"resource": resource})

        except Exception as e:
            logger.error(f"Resource usage collection failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class CheckResourceHandler(APIHandler):
    """Handler for /check-resource endpoint (runs on Jupyter server).

    Checks system resources, file sizes, and DataFrame shapes for resource-aware
    code generation.
    """

    async def post(self):
        """Check resources for the requested files and dataframes."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            files = body.get("files", [])
            dataframes = body.get("dataframes", [])
            dataframe_check_code = body.get("dataframe_check_code", "")
            user_workspace_root = body.get("workspaceRoot")

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            result: dict[str, Any] = {"success": True}

            # 1. Get system resources
            resource = get_integrated_resources(workspace_root=workspace_root)
            memory = resource.get("memory", {})
            result["system"] = {
                "ram_available_mb": round((memory.get("available_gb") or 0) * 1024, 2),
                "ram_total_mb": round((memory.get("total_gb") or 0) * 1024, 2),
                "cpu_cores": resource.get("cpu", {}).get("cores"),
                "environment": resource.get("environment"),
            }

            # 2. Get file sizes
            file_info = []
            for file_path in files:
                # Resolve path relative to server_root (Jupyter's working directory)
                # NOT workspace_root (project root) to match list_files_tool behavior
                if os.path.isabs(file_path):
                    abs_path = file_path
                else:
                    abs_path = os.path.join(server_root, file_path)

                try:
                    stat = os.stat(abs_path)
                    info = {
                        "name": os.path.basename(file_path),
                        "path": file_path,
                        "size_bytes": stat.st_size,
                        "size_mb": round(stat.st_size / (1024 * 1024), 2),
                        "exists": True,
                    }

                    # CSV files: include column schema so LLM uses real column names
                    if abs_path.lower().endswith(".csv"):
                        try:
                            import pandas as pd

                            df_sample = pd.read_csv(abs_path, nrows=5)
                            # Count total rows efficiently (without loading full file)
                            with open(abs_path) as f:
                                rows_total = sum(1 for _ in f) - 1  # subtract header
                            info["schema"] = {
                                "columns": list(df_sample.columns),
                                "dtypes": {
                                    c: str(d) for c, d in df_sample.dtypes.items()
                                },
                                "rows_total": rows_total,
                                "sample_rows": df_sample.head(3).to_dict(
                                    orient="records",
                                ),
                            }
                            # Warn about boolean columns (is_numeric_dtype=True but describe() gives categorical stats)
                            bool_cols = [
                                c for c, d in df_sample.dtypes.items() if d == "bool"
                            ]
                            if bool_cols:
                                info["schema"]["dtype_warnings"] = (
                                    f"Columns {bool_cols} have dtype 'bool'. "
                                    "Do NOT use .describe()['mean'] on bool columns — "
                                    "use .mean() or .sum() directly."
                                )
                        except Exception as e:
                            info["schema_error"] = str(e)

                    file_info.append(info)
                except OSError as e:
                    file_info.append(
                        {
                            "name": os.path.basename(file_path),
                            "path": file_path,
                            "exists": False,
                            "error": str(e),
                        },
                    )
            result["files"] = file_info

            # 3. Get DataFrame info (if dataframe_check_code provided)
            df_info = []
            if dataframe_check_code and dataframes:
                try:
                    # Execute the code in the active kernel
                    kernel_manager = self.settings.get("kernel_manager")
                    if kernel_manager:
                        # Try to get the active kernel
                        kernel_ids = list(kernel_manager.list_kernel_ids())
                        if kernel_ids:
                            kernel_id = kernel_ids[0]
                            kernel = kernel_manager.get_kernel(kernel_id)
                            if kernel and hasattr(kernel, "client"):
                                client = kernel.client()
                                # Execute code and get result
                                msg_id = client.execute(
                                    dataframe_check_code,
                                    silent=True,
                                )
                                # Wait for result (with timeout)
                                import asyncio

                                try:
                                    reply = await asyncio.wait_for(
                                        asyncio.to_thread(
                                            client.get_shell_msg,
                                            msg_id,
                                            timeout=5,
                                        ),
                                        timeout=10,
                                    )
                                    # Parse output
                                    if reply.get("content", {}).get("status") == "ok":
                                        # Get stdout from iopub
                                        while True:
                                            try:
                                                iopub_msg = client.get_iopub_msg(
                                                    timeout=1,
                                                )
                                                if (
                                                    iopub_msg.get("msg_type")
                                                    == "stream"
                                                ):
                                                    text = iopub_msg.get(
                                                        "content",
                                                        {},
                                                    ).get("text", "")
                                                    if text:
                                                        df_info = json.loads(text)
                                                        break
                                            except Exception:
                                                break
                                except TimeoutError:
                                    logger.warning("DataFrame check timed out")
                except Exception as e:
                    logger.warning(f"DataFrame check failed: {e}")
                    # Return placeholder for requested dataframes
                    for df_name in dataframes:
                        df_info.append(
                            {
                                "name": df_name,
                                "exists": False,
                                "error": "Kernel execution failed",
                            },
                        )
            result["dataframes"] = df_info

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Resource check failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"success": False, "error": str(e)})


class ReadFileHandler(APIHandler):
    """Handler for /read-file endpoint (runs on Jupyter server)."""

    async def post(self):
        """Read file content."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            path = (body.get("path") or "").strip()
            encoding = body.get("encoding") or "utf-8"
            requested_cwd = (body.get("cwd") or "").strip()
            user_workspace_root = body.get("workspaceRoot")

            if not path:
                self.set_status(400)
                self.write({"success": False, "error": "path is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            # If no cwd requested, use server_root as default (notebook directory)
            effective_cwd = requested_cwd
            if not effective_cwd:
                abs_server_root = os.path.abspath(server_root)
                if (
                    os.path.commonpath([workspace_root, abs_server_root])
                    == workspace_root
                ):
                    effective_cwd = abs_server_root
                else:
                    effective_cwd = workspace_root

            try:
                resolved_path = _resolve_path_in_workspace(
                    path,
                    workspace_root,
                    effective_cwd,
                )
            except ValueError as exc:
                self.set_status(400)
                self.write({"success": False, "error": str(exc)})
                return

            try:
                with open(resolved_path, encoding=encoding) as f:
                    content = f.read()
                result = {
                    "success": True,
                    "path": path,
                    "resolved_path": resolved_path,
                    "content": content,
                    "size": len(content),
                }
            except FileNotFoundError:
                result = {
                    "success": False,
                    "path": path,
                    "error": f"File not found: {path}",
                }
            except Exception as exc:
                result = {
                    "success": False,
                    "path": path,
                    "error": str(exc),
                }

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Read file failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"success": False, "error": str(e)})


class WriteFileHandler(APIHandler):
    """Handler for /write-file endpoint (runs on Jupyter server)."""

    async def post(self):
        """Write file content after user approval."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            path = (body.get("path") or "").strip()
            content = body.get("content") or ""
            encoding = body.get("encoding") or "utf-8"
            overwrite = bool(body.get("overwrite", False))
            requested_cwd = (body.get("cwd") or "").strip()
            user_workspace_root = body.get("workspaceRoot")

            if not path:
                self.set_status(400)
                self.write({"error": "path is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            # If no cwd requested, use server_root as default (notebook directory)
            # This ensures files are saved relative to where Jupyter was started
            effective_cwd = requested_cwd
            if not effective_cwd:
                abs_server_root = os.path.abspath(server_root)
                # Use server_root if it's within workspace_root, otherwise use workspace_root
                if (
                    os.path.commonpath([workspace_root, abs_server_root])
                    == workspace_root
                ):
                    effective_cwd = abs_server_root
                else:
                    effective_cwd = workspace_root

            try:
                resolved_path = _resolve_path_in_workspace(
                    path,
                    workspace_root,
                    effective_cwd,
                )
            except ValueError as exc:
                self.set_status(400)
                self.write({"error": str(exc)})
                return

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                _write_file,
                resolved_path,
                content,
                encoding,
                overwrite,
            )

            result.update(
                {
                    "path": path,
                    "resolved_path": resolved_path,
                    "overwrite": overwrite,
                },
            )
            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Write file failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class RAGStatusHandler(APIHandler):
    """Handler for /rag/status endpoint using ServiceFactory."""

    async def get(self):
        """Get RAG system status."""
        try:
            factory = _get_service_factory()
            rag_service = factory.get_rag_service()

            status = await rag_service.get_index_status()

            self.set_header("Content-Type", "application/json")
            self.write(status)

        except Exception as e:
            logger.error(f"RAG status failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Embedded Config Handlers ============


def _get_config_manager():
    """Lazy import ConfigManager to avoid circular imports."""
    from hdsp_agent_core.managers.config_manager import get_config_manager

    return get_config_manager()


def _is_admin_mode() -> tuple:
    """Detect if running in admin mode based on environment variables.

    Returns:
        tuple[bool, str | None]: (is_admin, reason)

    """
    sagemaker_space = os.environ.get("SAGEMAKER_SPACE_NAME")
    hdsp_prj_id = os.environ.get("HDSP_PRJ_ID")

    if sagemaker_space is None and hdsp_prj_id is None:
        return True, "development_environment"
    if hdsp_prj_id == "local_dev":
        return True, "development_environment"
    if sagemaker_space and "pl2wadmprj" in sagemaker_space:
        return True, "sagemaker_admin_space"
    if hdsp_prj_id == "pl2wadmprj":
        return True, "hdsp_admin_project"
    return False, None


def _mask_api_key(key: str) -> str:
    """Mask an API key for safe display."""
    if not key or len(key) < 8:
        return "***" if key else ""
    return key[:4] + "..." + key[-4:]


def _mask_config_keys(config: dict) -> dict:
    """Return a copy of config with API keys masked."""
    import copy

    masked = copy.deepcopy(config)
    key_fields = {"apiKey", "apiKeys"}
    for section_key, section_val in masked.items():
        if isinstance(section_val, dict):
            for field_key in list(section_val.keys()):
                if field_key == "apiKey" and isinstance(section_val[field_key], str):
                    section_val[field_key] = _mask_api_key(section_val[field_key])
                elif field_key == "apiKeys" and isinstance(
                    section_val[field_key],
                    list,
                ):
                    section_val[field_key] = [
                        _mask_api_key(k) for k in section_val[field_key]
                    ]
        elif section_key in key_fields and isinstance(section_val, str):
            masked[section_key] = _mask_api_key(section_val)
    return masked


# ============ Health Handler ============


class HealthHandler(APIHandler):
    """Health check handler."""

    async def get(self):
        """Return extension health status."""
        try:
            factory = _get_service_factory()
            _mode = getattr(factory, "mode", None)
            mode = (
                _mode.value if (_mode and factory.is_initialized) else "not_initialized"
            )

            status = {
                "status": "healthy",
                "extension_version": "2.0.2",
                "mode": mode,
            }

            rag_service = factory.get_rag_service()
            status["rag"] = {
                "ready": rag_service.is_ready(),
            }

            self.write(status)

        except Exception as e:
            logger.error(f"Health check failed: {e}")
            self.write(
                {
                    "status": "degraded",
                    "error": str(e),
                },
            )


class ConfigHandler(APIHandler):
    """GET: full config, POST: save config."""

    async def get(self):
        try:
            cm = _get_config_manager()
            self.write(_mask_config_keys(cm.get_config()))
        except Exception as e:
            logger.error(f"ConfigHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            cm = _get_config_manager()
            cm.save_config(body)
            self.write({"status": "ok"})
        except Exception as e:
            logger.error(f"ConfigHandler POST error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


def _get_default_prompts() -> dict:
    """기본 에이전트 프롬프트 반환."""
    from .agent.subagent_prompts import (
        ATHENA_QUERY_SYSTEM_PROMPT,
        PLANNER_SYSTEM_PROMPT,
        PYTHON_EXPERT_SYSTEM_PROMPT,
        RESEARCHER_SYSTEM_PROMPT,
    )

    from hdsp_agent_core.llm.service import _CHAT_SYSTEM_PROMPT
    from hdsp_agent_core.services.rag_chat_agent import _RAG_SYSTEM_PROMPT_ADDITION

    return {
        "chat_system_prompt": _CHAT_SYSTEM_PROMPT,
        "chat_rag_prompt": _RAG_SYSTEM_PROMPT_ADDITION,
        "planner": PLANNER_SYSTEM_PROMPT,
        "python_expert": PYTHON_EXPERT_SYSTEM_PROMPT,
        # backward compat: frontend may still use "python_developer"
        "python_developer": PYTHON_EXPERT_SYSTEM_PROMPT,
        "researcher": RESEARCHER_SYSTEM_PROMPT,
        "athena_query": ATHENA_QUERY_SYSTEM_PROMPT,
        "athena_tuning_prompt": _ATHENA_TUNING_DEFAULT_PROMPT,
    }


# Frontend fallback string — if this was saved to config, treat as null
_FALLBACK_SENTINEL = "(프롬프트를 불러오는 중...)"


def _resolve_prompts(stored: dict) -> dict:
    """저장된 프롬프트에 기본값을 채워 반환. 폴백 문자열은 무시."""
    defaults = _get_default_prompts()
    result = {}
    for key in defaults:
        val = stored.get(key)
        if val and val != _FALLBACK_SENTINEL:
            result[key] = val
        else:
            result[key] = defaults[key]
    return result


class ConfigPromptsHandler(APIHandler):
    """GET: return prompts (custom if set, otherwise defaults).

    Query params:
        defaults=true — 항상 코드 기본값만 반환 (기본값 복원용)
    """

    async def get(self):
        try:
            if self.get_argument("defaults", "").lower() == "true":
                self.write(_get_default_prompts())
                return
            cm = _get_config_manager()
            config = cm.get_config()
            stored = config.get("prompts", {})
            self.write(_resolve_prompts(stored))
        except Exception as e:
            logger.error(f"ConfigPromptsHandler error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ConfigIsAdminHandler(APIHandler):
    """GET: return admin mode status."""

    async def get(self):
        try:
            is_admin, reason = _is_admin_mode()
            self.write({"isAdmin": is_admin, "reason": reason})
        except Exception as e:
            logger.error(f"ConfigIsAdminHandler error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ConfigAdminHandler(APIHandler):
    """GET: admin config (API keys masked), POST: update admin config.

    Normal mode: LLM settings hidden (managed by K8s env vars).
    Admin mode: returns prompts/server settings only (LLM settings in localStorage).
    """

    async def get(self):
        try:
            is_admin, _ = _is_admin_mode()
            if not is_admin:
                # 일반모드: LLM 설정 없이, idleTimeout만 반환
                cm = _get_config_manager()
                config = cm.get_config()
                self.write(
                    {
                        "message": "LLM settings managed by system",
                        "idleTimeout": min(config.get("idleTimeout", 3600), 3600),
                    },
                )
                return
            # 관리자모드: 프롬프트/서버 설정만 서버에서 반환
            cm = _get_config_manager()
            config = cm.get_admin_config()
            masked = _mask_config_keys(config)
            masked["prompts"] = _resolve_prompts(masked.get("prompts", {}))
            masked["idleTimeout"] = min(masked.get("idleTimeout", 3600), 3600)
            self.write(masked)
        except Exception as e:
            logger.error(f"ConfigAdminHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    async def post(self):
        try:
            is_admin, _ = _is_admin_mode()
            if not is_admin:
                self.set_status(403)
                self.write({"error": "Admin only"})
                return
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            cm = _get_config_manager()
            # 관리자모드: 프롬프트/서버 설정만 서버에 저장 (LLM 설정은 localStorage)
            server_fields = {
                k: v
                for k, v in body.items()
                if k in ("prompts", "idleTimeout", "rawLlmLogging")
            }
            if server_fields:
                cm.update_admin_config(server_fields)
            self.write({"status": "ok"})
        except Exception as e:
            logger.error(f"ConfigAdminHandler POST error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class ConfigUserHandler(APIHandler):
    """GET: user config, POST: update user config."""

    async def get(self):
        try:
            cm = _get_config_manager()
            self.write(cm.get_user_config())
        except Exception as e:
            logger.error(f"ConfigUserHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            cm = _get_config_manager()
            cm.update_user_config(body)
            self.write({"status": "ok"})
        except Exception as e:
            logger.error(f"ConfigUserHandler POST error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class CodebuffStatusHandler(APIHandler):
    """Check if codebuff.md exists in workspace root."""

    async def get(self):
        try:
            server_root = self.settings.get("server_root_dir", os.getcwd())
            cm = _get_config_manager()
            user_ws = cm.get_user_config().get("workspaceRoot")
            ws_root = _get_effective_workspace_root(server_root, user_ws)
            # Case-insensitive search for codebuff.md
            codebuff_path = None
            try:
                for name in os.listdir(ws_root):
                    if name.lower() == "codebuff.md" and os.path.isfile(
                        os.path.join(ws_root, name)
                    ):
                        codebuff_path = os.path.join(ws_root, name)
                        break
            except OSError:
                pass
            exists = codebuff_path is not None
            size = os.path.getsize(codebuff_path) if exists else 0
            truncated = size > 10_000
            self.write(
                {
                    "exists": exists,
                    "path": codebuff_path,
                    "size": size,
                    "truncated": truncated,
                }
            )
        except Exception as e:
            logger.error(f"CodebuffStatusHandler GET error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Notebook Generation Handlers ============

# Module-level task store for notebook generation
_notebook_tasks: dict[str, dict[str, Any]] = {}  # taskId → task state
_notebook_task_queues: dict[str, asyncio.Queue] = {}  # taskId → SSE event queue

_NOTEBOOK_SYSTEM_PROMPT = """\
You are a Jupyter notebook generator. Given a user's request, create a well-structured \
Jupyter notebook with markdown explanations and Python code cells.

Output format - use these exact delimiters:

FIRST, output a short English filename (no extension) on the very first line:
---FILENAME---
short_descriptive_name
(e.g. eda_sales_2024, lstm_stock_prediction, pandas_data_cleaning)

THEN, output notebook cells:
---MARKDOWN---
(markdown cell content)
---CODE---
(python code cell content)
---MARKDOWN---
(next markdown cell)
...

Rules:
- The filename must be lowercase, use underscores, 2-5 words, descriptive of the notebook content
- Start with a title markdown cell
- Include explanatory markdown between code cells
- Write complete, runnable Python code
- Add comments in code for clarity
- Do NOT wrap cell content in code fences
- CRITICAL: All markdown cell text MUST be written entirely in Korean (한국어). No English in markdown cells.
- CRITICAL: Code comments MUST also be in Korean (한국어)
- Do NOT use Chinese characters (한자 금지)
- Variable names, function names, and Python keywords remain in English (코드 자체는 영어 유지)

Code quality rules (MUST apply to all generated code):
- 보안: SQL은 파라미터 바인딩 사용 (f-string 삽입 금지), 민감 정보는 os.environ.get() 사용, PII 컬럼은 마스킹 처리 포함
- 성능: DataFrame dtypes 최적화 (object→category 등), 파일 읽기 시 usecols로 필요 컬럼만 지정, 벡터 연산 우선 (iterrows 대신 apply/vectorized ops)
- 품질: 매직 넘버 대신 상수 정의, I/O는 try-except로 감싸기, 반복 로직은 함수로 분리, 데이터 검증(shape/dtypes/null) 포함
- 각 코드 셀 위 마크다운에 적용된 품질 원칙 한 줄 포함: "💡 [성능] dtypes 최적화 적용" / "💡 [보안] 파라미터 바인딩 적용" 등
{{RESOURCE_CONTEXT}}
"""


def _parse_notebook_cells(llm_response: str) -> list[dict]:
    """Parse LLM response into a list of {cell_type, source} dicts."""
    import re

    cells: list[dict] = []
    # Split by ---MARKDOWN--- or ---CODE--- delimiters
    parts = re.split(r"---(?:MARKDOWN|CODE)---", llm_response)
    types = re.findall(r"---(MARKDOWN|CODE)---", llm_response)

    for cell_type_str, content in zip(types, parts[1:]):
        source = content.strip()
        if not source:
            continue
        cell_type = "markdown" if cell_type_str == "MARKDOWN" else "code"
        cells.append({"cell_type": cell_type, "source": source})

    # Fallback: if no delimiters found, treat entire response as a single markdown cell
    if not cells:
        cells.append({"cell_type": "markdown", "source": llm_response.strip()})

    return cells


def _extract_filename(llm_response: str) -> str | None:
    """Extract the LLM-generated filename from ---FILENAME--- block."""
    import re

    m = re.search(r"---FILENAME---\s*\n\s*(.+)", llm_response)
    if not m:
        return None
    raw = m.group(1).strip()
    # Sanitize: keep only alphanumeric, underscores, hyphens
    sanitized = re.sub(r"[^\w-]", "_", raw).strip("_")
    # Collapse multiple underscores
    sanitized = re.sub(r"_+", "_", sanitized)
    return sanitized[:60] if sanitized else None


async def _update_notebook_task(task_id: str, updates: dict[str, Any]) -> None:
    """Update task state and push event to SSE queue."""
    task = _notebook_tasks.get(task_id)
    if not task:
        return
    task.update(updates)
    queue = _notebook_task_queues.get(task_id)
    if queue:
        await queue.put(dict(task))


async def _generate_notebook_task(
    task_id: str,
    prompt: str,
    output_dir: str,
    llm_overrides: dict | None = None,
) -> None:
    """Background coroutine: call LLM, parse response, write .ipynb file."""
    import math
    from datetime import datetime

    from .agent.agent_factory import _dbg

    try:
        _dbg(f"NOTEBOOK_GEN: start task_id={task_id} prompt={prompt[:80]!r}")
        await _update_notebook_task(
            task_id,
            {
                "status": "running",
                "progress": 0,
                "message": "노트북 내용 생성 중...",
                "startedAt": datetime.now(_tz.utc).isoformat(),
            },
        )

        # Get LLM config
        cm = _get_config_manager()
        config_dict = cm.get_config()

        # Apply LLM overrides (from admin localStorage or env vars)
        if llm_overrides:
            config_dict.update(llm_overrides)

        # Validate apiKey is not masked or empty
        from hdsp_agent_core.managers.config_manager import _is_masked_api_key

        vllm_cfg = config_dict.get("vllm", {})
        api_key = vllm_cfg.get("apiKey", "")
        if not api_key:
            raise ValueError(
                "LLM API 키가 설정되지 않았습니다. "
                "관리자 설정 패널에서 API 키를 입력해주세요.",
            )
        if _is_masked_api_key(api_key):
            raise ValueError(
                "API 키가 손상되었습니다. "
                "관리자 설정 패널에서 API 키를 다시 입력해주세요.",
            )

        from hdsp_agent_core.llm.service import LLMService

        llm = LLMService(config_dict)

        # Inject resource context into system prompt
        system_prompt = _NOTEBOOK_SYSTEM_PROMPT
        if "{{RESOURCE_CONTEXT}}" in system_prompt:
            from .agent.agent_factory import _inject_resource_context_for_codegen

            system_prompt = _inject_resource_context_for_codegen(
                system_prompt,
                output_dir,
            )

        # RAG agent로 노트북 생성에 필요한 테이블/가이드 사전 검색
        rag_context = ""
        try:
            from .handlers.rag_admin_handler import _ensure_manager

            _ensure_manager()  # RAG 매니저 lazy 초기화

            from hdsp_agent_core.services.rag_chat_agent import RAGChatAgent

            rag_agent = RAGChatAgent(config_dict)
            await _update_notebook_task(
                task_id,
                {"progress": 2, "message": "관련 테이블/가이드 검색 중..."},
            )
            rag_msg = (
                f"Jupyter 노트북 코드를 생성하려고 합니다. "
                f"아래 요청에 필요한 테이블 스키마와 가이드를 "
                f"검색해주세요.\n\n{prompt}"
            )
            rag_chunks: list = []
            async for event in rag_agent.stream_response(
                user_message=rag_msg,
                thread_id=f"notebook-gen-{task_id}",
            ):
                if isinstance(event, dict) and event.get("content"):
                    rag_chunks.append(event["content"])
            if rag_chunks:
                rag_context = "\n\n## 참고: RAG 검색 결과\n" + "".join(rag_chunks)
                _dbg(f"NOTEBOOK_GEN: RAG context added ({len(rag_context)} chars)")
        except Exception as rag_err:
            _dbg(f"NOTEBOOK_GEN: RAG search skipped: {rag_err}")

        # Call LLM (streaming to avoid timeout with large models)
        full_prompt = f"{system_prompt}{rag_context}\n\nUser request:\n{prompt}"
        _dbg("NOTEBOOK_GEN: calling LLM via streaming...")
        chunks: list[str] = []
        chunk_count = 0
        async for chunk in llm.generate_response_stream(full_prompt):
            chunks.append(chunk)
            chunk_count += 1
            if chunk_count % 10 == 0:
                raw = min(math.log1p(chunk_count / 10) / math.log1p(30), 1.0)
                pct = 5 + int(raw * 40)  # 5% ~ 45%
                await _update_notebook_task(
                    task_id,
                    {"progress": pct, "message": "노트북 내용 생성 중..."},
                )
        llm_response = "".join(chunks)
        _dbg(f"NOTEBOOK_GEN: LLM response received, len={len(llm_response)}")

        # Check if cancelled during LLM call
        task = _notebook_tasks.get(task_id)
        if not task or task.get("status") == "cancelled":
            return

        await _update_notebook_task(
            task_id,
            {"progress": 50, "message": "셀 구성 중..."},
        )

        # Parse response into cells
        parsed_cells = _parse_notebook_cells(llm_response)

        # Build notebook
        import nbformat

        nb = nbformat.v4.new_notebook()
        for cell_info in parsed_cells:
            if cell_info["cell_type"] == "code":
                nb.cells.append(nbformat.v4.new_code_cell(cell_info["source"]))
            else:
                nb.cells.append(nbformat.v4.new_markdown_cell(cell_info["source"]))

        await _update_notebook_task(
            task_id,
            {"progress": 80, "message": "파일 저장 중..."},
        )

        # Generate filename from LLM response, fallback to prompt-based
        import re as _re

        llm_filename = _extract_filename(llm_response)
        if llm_filename:
            safe_name = llm_filename
        else:
            safe_name = _re.sub(r"[^\w\s-]", "", prompt[:40]).strip()
            safe_name = _re.sub(r"\s+", "_", safe_name) or "notebook"
        filename = f"{safe_name}_{task_id[:8]}.ipynb"
        filepath = os.path.join(output_dir, filename)

        with open(filepath, "w", encoding="utf-8") as f:
            nbformat.write(nb, f)

        now = datetime.now(_tz.utc).isoformat()
        await _update_notebook_task(
            task_id,
            {
                "status": "completed",
                "progress": 100,
                "message": "노트북 생성 완료",
                "notebookPath": filename,
                "completedAt": now,
            },
        )

    except Exception as e:
        _dbg(f"NOTEBOOK_GEN: FAILED task_id={task_id} error={e!r}")
        logger.error(
            f"Notebook generation failed for task {task_id}: {e}",
            exc_info=True,
        )
        from datetime import datetime

        await _update_notebook_task(
            task_id,
            {
                "status": "failed",
                "error": str(e),
                "message": f"생성 실패: {e}",
                "completedAt": datetime.now(_tz.utc).isoformat(),
            },
        )
    finally:
        # Send sentinel to close SSE stream
        queue = _notebook_task_queues.get(task_id)
        if queue:
            await queue.put(None)


class NotebookEnrichHandler(APIHandler):
    """POST /hdsp-agent/notebook/enrich — AST-based cell analysis + local module resolution."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            notebook_path = (body.get("notebookPath") or "").strip()
            cells_input = body.get("cells") or []

            if not cells_input:
                self.write(
                    {"cells": [], "crossCellDependencies": [], "moduleSummary": {}},
                )
                return

            from hdsp_agent_core.core.code_validator import CodeValidator

            validator = CodeValidator()

            # Resolve notebook directory for local module lookup
            notebook_dir = ""
            if notebook_path:
                server_root = self.settings.get("server_root_dir", os.getcwd())
                server_root = os.path.expanduser(server_root)
                abs_notebook = os.path.join(os.path.abspath(server_root), notebook_path)
                notebook_dir = os.path.dirname(abs_notebook)

            # --- Per-cell AST analysis ---
            enriched_cells = []
            all_defined_by_cell: list[list[str]] = []  # cell_index -> defined_names

            for cell_data in cells_input:
                idx = cell_data.get("index", 0)
                content = cell_data.get("content", "")

                deps = validator.analyze_dependencies(content)
                all_defined_by_cell.append(deps.defined_names)

                enriched_cells.append(
                    {
                        "index": idx,
                        "dependencies": deps.to_dict(),
                        "localModuleSources": {},
                    },
                )

            # --- Cross-cell dependency calculation ---
            cross_cell_deps = []
            cumulative_defined: set[str] = set()
            for i, cell_data in enumerate(enriched_cells):
                if i == 0:
                    cumulative_defined.update(all_defined_by_cell[0])
                    continue
                used = set(cell_data["dependencies"]["used_names"])
                for prev_idx in range(i):
                    prev_defined = set(all_defined_by_cell[prev_idx])
                    shared = used & prev_defined
                    # Exclude names also defined in current cell (local override)
                    shared -= set(all_defined_by_cell[i])
                    if shared:
                        cross_cell_deps.append(
                            {
                                "cellIndex": cells_input[i].get("index", i),
                                "usesFrom": cells_input[prev_idx].get(
                                    "index",
                                    prev_idx,
                                ),
                                "variables": sorted(shared),
                            },
                        )
                cumulative_defined.update(all_defined_by_cell[i])

            # --- Local module resolution (2-level recursive) ---
            merged_from_imports: dict[str, list[str]] = {}
            for cell_data in enriched_cells:
                deps = cell_data["dependencies"]
                for mod, items in deps.get("from_imports", {}).items():
                    if mod and mod not in merged_from_imports:
                        merged_from_imports[mod] = items

            module_sources, transitive_sources, module_summary = (
                _resolve_modules_recursive(
                    merged_from_imports, notebook_dir, validator=validator
                )
                if notebook_dir
                else ({}, {}, {})
            )

            # Distribute depth-1 sources back to each cell's localModuleSources
            for cell_data in enriched_cells:
                deps = cell_data["dependencies"]
                for mod in deps.get("from_imports", {}):
                    if mod in module_sources:
                        cell_data["localModuleSources"][mod] = module_sources[mod]

            self.write(
                {
                    "cells": enriched_cells,
                    "crossCellDependencies": cross_cell_deps,
                    "moduleSummary": module_summary,
                    "transitiveModuleSources": transitive_sources,
                },
            )

        except Exception as e:
            logger.exception("NotebookEnrichHandler error")
            self.set_status(500)
            self.write({"error": str(e)})


def _resolve_local_module(module_name: str, notebook_dir: str) -> str | None:
    """Return file path if module_name is a local module relative to notebook_dir, else None."""
    # Relative import (starts with '.')
    if module_name.startswith("."):
        rel_path = module_name.lstrip(".").replace(".", "/")
        candidate = os.path.join(notebook_dir, f"{rel_path}.py")
        if os.path.isfile(candidate):
            return candidate
        return None

    # Absolute path: look for file in notebook_dir
    candidate = os.path.join(notebook_dir, module_name.replace(".", "/") + ".py")
    if os.path.isfile(candidate):
        return candidate

    # Package __init__.py
    candidate_pkg = os.path.join(
        notebook_dir,
        module_name.replace(".", "/"),
        "__init__.py",
    )
    if os.path.isfile(candidate_pkg):
        return candidate_pkg

    return None


def _resolve_modules_recursive(
    from_imports: dict[str, list[str]],
    base_dir: str,
    max_depth: int = 2,
    max_source_bytes: int = 45 * 1024,
    max_lines_l1: int = 200,
    max_lines_l2: int = 100,
    validator: Any = None,
) -> tuple[dict[str, str], dict[str, str], dict[str, dict]]:
    """Resolve local module sources up to max_depth levels using BFS.

    Returns:
        (direct_sources, transitive_sources, module_summary)
    """
    from collections import deque

    from hdsp_agent_core.core.code_validator import CodeValidator

    if validator is None:
        validator = CodeValidator()

    seen: set[str] = set()
    total_bytes = 0
    direct_sources: dict[str, str] = {}
    transitive_sources: dict[str, str] = {}
    module_summary: dict[str, dict] = {}

    # BFS queue: (module_name, depth, imported_by)
    queue: deque[tuple[str, int, str | None]] = deque()
    for mod in from_imports:
        if mod:
            queue.append((mod, 1, None))

    while queue:
        module_name, depth, imported_by = queue.popleft()

        if module_name in seen or depth > max_depth:
            continue
        seen.add(module_name)

        if total_bytes >= max_source_bytes:
            break

        resolved = _resolve_local_module(module_name, base_dir)
        if not resolved:
            continue

        max_lines = max_lines_l1 if depth == 1 else max_lines_l2
        try:
            with open(resolved, encoding="utf-8") as f:
                lines = f.readlines()
            truncated = len(lines) > max_lines
            if truncated:
                lines = lines[:max_lines]
            source = "".join(lines)
            if truncated:
                source += "\n# ... [truncated] ...\n"

            remaining = max_source_bytes - total_bytes
            source_bytes = len(source.encode("utf-8"))
            if source_bytes > remaining:
                source = source[:remaining] + "\n# ... [truncated by budget] ...\n"
                truncated = True
                source_bytes = len(source.encode("utf-8"))

            total_bytes += source_bytes

            if depth == 1:
                direct_sources[module_name] = source
            else:
                transitive_sources[module_name] = source

            module_summary[module_name] = {
                "path": os.path.relpath(resolved, base_dir),
                "lines": len(lines),
                "truncated": truncated,
                "depth": depth,
                "importedBy": imported_by,
            }

            # Parse this module's imports for next depth level
            if depth < max_depth:
                try:
                    deps = validator.analyze_dependencies(source)
                    for sub_mod in deps.from_imports:
                        if sub_mod and sub_mod not in seen:
                            queue.append((sub_mod, depth + 1, module_name))
                except Exception:
                    pass

        except (OSError, UnicodeDecodeError):
            pass

    return direct_sources, transitive_sources, module_summary


class FileEnrichHandler(APIHandler):
    """POST /hdsp-agent/file/enrich — import resolution for a single Python file."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            file_path = (body.get("filePath") or "").strip()

            if not file_path or not file_path.endswith(".py"):
                self.write(
                    {
                        "moduleSources": {},
                        "transitiveModuleSources": {},
                        "moduleSummary": {},
                    }
                )
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            abs_path = os.path.join(os.path.abspath(server_root), file_path)

            if not os.path.isfile(abs_path):
                self.set_status(404)
                self.write({"error": "file not found"})
                return

            file_dir = os.path.dirname(abs_path)
            with open(abs_path, encoding="utf-8") as f:
                content = f.read()

            from hdsp_agent_core.core.code_validator import CodeValidator

            validator = CodeValidator()
            deps = validator.analyze_dependencies(content)

            direct_sources, transitive_sources, module_summary = (
                _resolve_modules_recursive(
                    deps.from_imports, file_dir, validator=validator
                )
            )

            self.write(
                {
                    "moduleSources": direct_sources,
                    "transitiveModuleSources": transitive_sources,
                    "moduleSummary": module_summary,
                }
            )

        except Exception as e:
            logger.exception("FileEnrichHandler error")
            self.set_status(500)
            self.write({"error": str(e)})


_ATHENA_TUNING_DEFAULT_PROMPT = """\
당신은 AWS Athena SQL 전문가이자 EDA(탐색적 데이터 분석) 에이전트입니다.
BDP(빅데이터플랫폼)의 테이블을 대상으로 사용자의 다양한 요청을 처리합니다.

## 핵심 원칙
사용자가 데이터를 "찾아봐", "조회해", "알려줘", "분석해", "비교해" 등 **데이터 탐색/조회를 요청하면 반드시 SQL을 생성**하세요.
"쿼리 만들어" 같은 명시적 지시가 없더라도, 데이터를 확인해야 답할 수 있는 질문이면 SQL을 생성해야 합니다.
**[기존 SQL]이 존재할 때 반드시 정확한 테이블 정보 확인을 위해 rag_search를 호출한 후 응답을 생성하세요**

## 응답 형식
반드시 JSON만 출력하세요. JSON 외의 텍스트 금지.

**SQL을 생성하거나 수정한 경우** (대부분의 요청):
```json
{"title": "제목 (한국어, 50자 이내)", "description": "설명 (한국어, Markdown)", "sql": "SELECT ..."}
```

**사용자가 "최적화", "튜닝", "개선", "수정" 등을 요청한 경우** 반드시 수정된 SQL을 "sql" 필드에 별도로 포함하세요. description에 SQL을 넣지 마세요.
**중요: 최적화/튜닝 시 쿼리 결과(반환 데이터)는 반드시 원본과 동일해야 합니다.** 성능만 개선하고 결과 집합을 변경하지 마세요.

**SQL 없이 텍스트만 응답하는 경우** (테이블 구조 설명, 컬럼 의미 질문, 기존 SQL 해석/분석 등 실행할 쿼리가 불필요한 경우만):
```json
{"title": "제목 (한국어, 50자 이내)", "description": "설명 (한국어, Markdown)"}
```

## title 작성 규칙
- 요청의 핵심을 한 줄로 요약. 예: "카드매출 테이블을 통한 월별 매출 집계 쿼리 생성", "주문 테이블 인덱스 튜닝", "매출 추이 분석"
- 50자 이내, 한국어

## description 작성 규칙
description은 **Markdown 형식**으로 작성하세요.
요청 맥락에 따라 목적, 사용 테이블, 주요 로직, 변경 사항, 분석 결과 등을 항목별로 상세히 설명하세요.
목록(`-`)과 **굵은 글씨**를 활용하세요.

## SQL 규칙 (SQL 응답 시 적용)
- sql: 실행 가능한 완전한 Athena SQL. 세미콜론 없이.
- 테이블명은 반드시 RAG 검색 결과의 실제 테이블명을 사용
- 컬럼명은 반드시 RAG 검색 결과에 있는 실제 컬럼명 사용
- 반드시 테이블 명 앞에 RAG 검색 결과의 'db명' 필드 값을 사용하여 DB명을 명시 (예시: wdp_bdp_dlk_l1_msk_view.card_pchs). DB명을 추측하거나 지어내지 마세요.

## RAG 검색 도구

rag_search로 BDP 테이블 메타데이터를 검색할 수 있습니다.
[기존 SQL]이 제공된 경우에도, SQL에 사용된 테이블명을 match_text에 지정하여 반드시 rag_search를 호출하세요.
**절대로 검색 결과 없이 테이블명이나 컬럼명을 만들어내지 마세요.**

### 컬렉션
- **bdp_tables**: BDP 테이블 메타데이터 (테이블명, 컬럼명, 타입, 스키마)

### 도구 호출 규칙
1. **`rag_search`**: queries 배열에 쿼리를 담아 **1회만 호출**. bdp_tables 컬렉션 사용.
   - **query 작성법**: 반드시 `"필드명:값"` 형식을 사용하거나 자연어 키워드로 작성하세요.
     예: `"테이블명:card_pchs"`, `"테이블한글명:카드매출"`, `"컬럼명:brno"`, `"원천DB명:ADW"`
     모르는 정보만 있을 땐 자연어 키워드도 가능: `"카드매출 관련 테이블"`
   - **match_text**: 정확한 테이블 영문명을 알 때 추가. 예: `"match_text": ["card_pchs"]`
2. **`get_table_columns`**: 테이블의 전체 컬럼 목록을 조회. rag_search 결과에서 컬럼이 축약된 경우 사용.
   - 예: `get_table_columns(table_name="card_pchs", collection="bdp_tables")`
3. 결과가 0건일 때만 쿼리를 변경하여 1회 재시도를 허용합니다.

### 검색 결과 사용 시 주의사항
- 테이블명, 컬럼명 등 고유명사는 **RAG 검색 결과에 있는 값을 그대로** 사용하세요.
- 검색 결과에 "[토큰 제한으로 컬럼 정보가 축약되었습니다]" 안내가 있으면 get_table_columns로 전체 컬럼을 조회하세요.

### 도구 호출 시 주의사항
- 도구 호출(tool call)이 필요하면, content에는 "검색 중입니다"처럼 **한 줄 상태 메시지만** 넣으세요.\
"""


def _parse_llm_json(accumulated: str) -> dict:
    """LLM 응답에서 {title, description, sql} JSON 추출."""
    import re as _re

    _VALID_KEYS = {"description", "sql", "title", "tuning_info"}
    text = accumulated.strip()

    # 1) 직접 json.loads 시도 (LLM이 순수 JSON만 반환한 경우)
    try:
        obj = json.loads(text)
        if isinstance(obj, dict) and _VALID_KEYS & set(obj):
            return obj
    except Exception:
        pass

    # 2) 코드블록 내 JSON
    m = _re.search(r"```(?:json)?\s*(\{[\s\S]*?\})\s*```", text)
    if m:
        try:
            obj = json.loads(m.group(1))
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    # 3) 텍스트 내 JSON 객체 추출 (마지막 { ... } 블록)
    for m in reversed(list(_re.finditer(r"\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", text))):
        try:
            obj = json.loads(m.group(0))
            if isinstance(obj, dict) and _VALID_KEYS & set(obj):
                return obj
        except Exception:
            continue

    return {}


async def _run_explain(sql_text: str) -> dict:
    """EXPLAIN 실행 → {"success": bool, "plan": str, "error": str}."""
    try:
        from bdpengine.functions import get_boto3_client, start_query

        result = start_query(query=f"EXPLAIN {sql_text}")
        if result.get("Error"):
            return {"success": False, "error": result["Error"], "plan": ""}

        qid = result.get("QueryExecutionId")
        if not qid:
            return {"success": False, "error": "QueryExecutionId 없음", "plan": ""}

        client = get_boto3_client("athena")
        # Poll (최대 30초)
        for _ in range(30):
            await asyncio.sleep(1)
            resp = client.get_query_execution(QueryExecutionId=qid)
            state = resp["QueryExecution"]["Status"]["State"]
            if state == "SUCCEEDED":
                rr = client.get_query_results(QueryExecutionId=qid)
                rows = rr.get("ResultSet", {}).get("Rows", [])
                plan_lines = [
                    (r.get("Data") or [{}])[0].get("VarCharValue", "")
                    for r in rows
                    if r.get("Data")
                ]
                return {"success": True, "plan": "\n".join(plan_lines), "error": ""}
            elif state in ("FAILED", "CANCELLED"):
                reason = resp["QueryExecution"]["Status"].get(
                    "StateChangeReason", state
                )
                return {"success": False, "error": reason, "plan": ""}
        return {"success": False, "error": "EXPLAIN 타임아웃 (30초)", "plan": ""}
    except ImportError:
        return {"success": False, "error": "bdpengine 미설치", "plan": ""}
    except Exception as e:
        return {"success": False, "error": str(e), "plan": ""}


# Phase 2: EXPLAIN 오류 수정 — 시스템 프롬프트 추가분 (Athena 기본 프롬프트에 append)
_EXPLAIN_FIX_SYSTEM_PROMPT = None  # lazy init (athena_sql.md 포함)


def _get_explain_fix_system_prompt() -> str:
    """EXPLAIN 오류 수정 전용 시스템 프롬프트 (lazy 생성)."""
    global _EXPLAIN_FIX_SYSTEM_PROMPT  # noqa: PLW0603
    if _EXPLAIN_FIX_SYSTEM_PROMPT is not None:
        return _EXPLAIN_FIX_SYSTEM_PROMPT

    skill_content = ""
    try:
        from pathlib import Path as _P

        skill_path = _P(__file__).parent / "agent" / "skills" / "athena_sql.md"
        if skill_path.exists():
            skill_content = skill_path.read_text(encoding="utf-8")
    except Exception:
        pass

    prompt = """\
당신은 AWS Athena SQL 오류 수정 전문가입니다.
EXPLAIN 실행 시 발생한 오류를 분석하고 SQL을 수정하세요.

## 규칙
- 제공된 테이블/컬럼 정보만 사용하세요. 추측하지 마세요.
- RAG 검색 도구를 호출하지 마세요.
- 반드시 아래 JSON 형식으로만 응답하세요. JSON 외의 텍스트 금지.
{"sql": "수정된 SQL"}

## 주요 수정 패턴
- 존재하지 않는 컬럼 → 제공된 컬럼 목록에서 올바른 컬럼명 사용
- 타입 불일치 → CAST로 명시적 변환
- 함수 오류 → Athena(Trino) 호환 함수로 교체
- 예약어 충돌 → 큰따옴표로 감싸기
"""
    if skill_content:
        prompt += "\n## Athena SQL 참고 가이드\n" + skill_content

    _EXPLAIN_FIX_SYSTEM_PROMPT = prompt
    return _EXPLAIN_FIX_SYSTEM_PROMPT


# Phase 3: 쿼리 플랜 튜닝 — 시스템 프롬프트 추가분
_PLAN_TUNING_SYSTEM_ADDITION = """\

## 현재 작업

당신은 두 가지 역할을 수행합니다. RAG 검색 도구 없이 즉시 JSON 형식으로 반환하세요.

### 역할 1: 쿼리 플랜 기반 추가 튜닝 (쿼리 플랜이 제공된 경우만)
[쿼리 플랜]이 제공되면 아래 기준으로 [SQL]을 추가 튜닝하세요. 제공되지 않으면 튜닝하지 마세요.
- **TableScan / ScanFilter**: SELECT * → 필요 컬럼만 명시. 파티션 키 필터 없으면 추가. 파티션 키에 함수 적용(CAST, YEAR 등) → 리터럴 비교로 변경.
- **Exchange**: 큰 테이블에 REPLICATE → 조인 순서 변경. 불필요한 Exchange → 서브쿼리 정리 또는 CTE 병합.
- **HashJoin**: 큰 테이블 LEFT, 작은 테이블 RIGHT. 조인 키 타입 불일치 → 명시적 CAST.
- **Aggregate**: GROUP BY 카디널리티 높으면 WHERE로 사전 필터링. COUNT(DISTINCT x) → approx_distinct(x) 고려.
- **TopN / Sort**: ORDER BY + LIMIT 조합은 효율적. ORDER BY만 있고 LIMIT 없으면 반드시 추가.
- **쿼리 결과(반환 데이터)는 반드시 원본과 동일해야 합니다.** 성능만 개선하고 결과 집합을 변경하지 마세요.

### 역할 2: REASON 주석 추가 (항상 수행 — 가장 중요한 역할)
[원본 SQL]과 [SQL]을 한 라인씩 비교하여, 변경된 **모든** 라인 바로 위에 `-- [REASON] 변경 사유` 주석을 추가하세요.
- [변경 설명]의 각 항목을 하나씩 확인하고, 해당하는 SQL 라인에 빠짐없이 REASON을 달아야 합니다.
- 예: `-- [REASON] 파티션 프루닝을 위해 YEAR() 대신 날짜 범위 사용`
- 변경되지 않은 라인에는 주석을 넣지 마세요.
- **[변경 설명]에 6가지 변경이 있으면 최소 6개의 REASON 주석이 있어야 합니다.** 누락 금지.
- 역할 1에서 추가 튜닝한 라인에도 REASON을 추가하세요.

## 응답 형식 (이 작업 전용)
반드시 아래 JSON만 출력하세요. description 필드는 포함하지 마세요.
```json
{"sql": "...", "tuning_info": "- 항목1\\n- 항목2"}
```
- **sql**: REASON 주석이 포함된 최종 SQL. 추가 튜닝이 없으면 REASON만 추가한 SQL.
- **tuning_info**: **역할 1(쿼리 플랜 기반 튜닝)에서 추가로 변경한 내용만** bullet list로 간결하게. [변경 설명]에 이미 있는 내용은 절대 포함하지 마세요. 쿼리 플랜 분석으로 인한 추가 최적화가 없으면 빈 문자열."""


class AthenaQueryStreamHandler(APIHandler):
    """POST /hdsp-agent/athena/query/stream — Athena SQL generation/tuning via SSE."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            natural_language = (body.get("naturalLanguage") or "").strip()
            existing_sql = (body.get("existingSql") or "").strip()

            if not natural_language and not existing_sql:
                self.set_status(400)
                self.write({"error": "naturalLanguage 또는 existingSql이 필요합니다."})
                return

            # Resolve LLM config
            llm_overrides = None
            is_admin, _ = _is_admin_mode()
            if is_admin and "llmConfig" in body:
                llm_overrides = {}
                llm_config = body["llmConfig"]
                for key in ("provider", "vllm", "summarization", "embedding"):
                    if key in llm_config:
                        llm_overrides[key] = llm_config[key]
            else:
                # 일반모드 또는 admin이지만 body에 llmConfig 없는 경우 → 환경변수 우선
                from hdsp_agent_core.managers.config_manager import (
                    ConfigManager as _CM,
                )

                env_config = _CM.get_env_llm_config()
                if env_config:
                    llm_overrides = env_config
                elif not is_admin:
                    self.set_status(400)
                    self.write({"error": "LLM 설정이 구성되지 않았습니다."})
                    return

            cm = _get_config_manager()
            config_dict = cm.get_config()
            if llm_overrides:
                config_dict.update(llm_overrides)

            _vllm_cfg = config_dict.get("vllm", {})
            print(
                f"AthenaQuery: is_admin={is_admin} "
                f"endpoint={_vllm_cfg.get('endpoint', '')} "
                f"model={_vllm_cfg.get('model', '')} "
                f"api_key={'SET' if _vllm_cfg.get('apiKey') else 'EMPTY'}",
                flush=True,
            )

            # System prompt
            prompts = config_dict.get("prompts", {})
            base_prompt = (prompts.get("athena_tuning_prompt") or "").strip()
            if not base_prompt:
                base_prompt = _ATHENA_TUNING_DEFAULT_PROMPT

            skill_content = ""
            try:
                from pathlib import Path as _Path

                skill_path = (
                    _Path(__file__).parent / "agent" / "skills" / "athena_sql.md"
                )
                if skill_path.exists():
                    skill_content = skill_path.read_text(encoding="utf-8")
            except Exception:
                pass

            import zoneinfo as _zoneinfo

            _now_kst = _datetime.now(_zoneinfo.ZoneInfo("Asia/Seoul"))
            _today_str = _now_kst.strftime("%Y-%m-%d %H:%M:%S (KST)")
            system_prompt = base_prompt + f"\n\n현재 날짜/시각: {_today_str}"
            if skill_content:
                system_prompt += "\n\n## Athena SQL 참고 가이드\n" + skill_content

            # User message
            parts: list[str] = []
            if natural_language:
                parts.append(f"[요청사항]\n{natural_language}")
            if existing_sql:
                parts.append(f"[기존 SQL]\n{existing_sql}")
            user_message = "\n\n".join(parts)

            # SSE headers
            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async def send_sse(data: dict):
                self.write(f"data: {json.dumps(data, ensure_ascii=False)}\n\n")
                await self.flush()

            # ─── Phase 1: SQL 생성 ───
            selected_tables = body.get("selectedTables")
            accumulated = ""
            rag_agent = None
            thread_id = f"athena-query-{uuid4()}"
            table_ctx = ""  # selectedTables 경로에서 생성, EXPLAIN 수정에서 재활용

            if selected_tables:
                # 사용자가 테이블을 이미 선택 → RAG 없이 LLM 직접 호출
                _sel_names = [t.get("table_name", "?") for t in selected_tables]
                print(
                    f"AthenaQuery: selectedTables count={len(selected_tables)} "
                    f"names={_sel_names}",
                    flush=True,
                )
                _auto_names = set(body.get("autoSelectedTableNames") or [])
                _status_parts = []
                for t in selected_tables:
                    name = t.get("table_name", "")
                    if not name:
                        continue
                    if name in _auto_names:
                        _status_parts.append(f"{name} (자동)")
                    else:
                        _status_parts.append(name)
                await send_sse({"status": f"처리 중 ({', '.join(_status_parts)})"})

                table_ctx = json.dumps(selected_tables, ensure_ascii=False, default=str)

                from hdsp_agent_core.llm.service import LLMService as _LLM

                _llm = _LLM(config_dict)
                # RAG 도구 섹션 제거 — 테이블 이미 제공됨
                import re as _re

                _direct_prompt = _re.sub(
                    r"## RAG 검색 도구.*",
                    "",
                    system_prompt,
                    flags=_re.DOTALL,
                )
                _direct_prompt += (
                    "\n\n## 중요: 테이블 정보가 JSON으로 제공됩니다.\n"
                    "아래 JSON의 테이블/컬럼 정보만 사용하여 SQL을 생성하세요. "
                    "columns는 col_headers와 매핑되는 배열 형태입니다. "
                    "도구 호출이나 검색 없이, 반드시 JSON 형식으로 즉시 응답하세요."
                )
                _messages = [
                    {"role": "system", "content": _direct_prompt},
                    {"role": "user", "content": f"{table_ctx}\n\n{user_message}"},
                ]
                _chunks: list = []
                try:
                    async for _c in _llm._call_vllm_stream_internal(
                        _messages, max_tokens=16384
                    ):
                        _chunks.append(_c)
                except Exception as llm_err:
                    print(
                        f"AthenaQuery: LLM stream error: {llm_err}",
                        flush=True,
                    )
                    await send_sse({"error": f"LLM 호출 실패: {llm_err}"})
                    self.finish()
                    return
                accumulated = "".join(_chunks)
                print(
                    f"AthenaQuery: selectedTables LLM done, "
                    f"chunks={len(_chunks)}, acc_len={len(accumulated)}",
                    flush=True,
                )
            else:
                # RAG Agent로 검색 + SQL 생성
                await send_sse({"status": "처리 중"})

                from .handlers.rag_admin_handler import _ensure_manager

                _ensure_manager()

                from hdsp_agent_core.services.rag_chat_agent import (
                    RAGChatAgent,
                    TableConfirmationNeeded,
                )

                excluded_table_names = body.get("excludedTableNames") or []
                from langgraph.checkpoint.memory import MemorySaver as _MemorySaver

                from .agent.langchain_tools import set_eda_only_bdp

                set_eda_only_bdp(True)

                rag_agent = RAGChatAgent(
                    config_dict,
                    system_prompt_override=system_prompt,
                    table_score_threshold=0.7,
                    excluded_table_names=excluded_table_names,
                    checkpointer=_MemorySaver(),
                    grounding_constraint=(
                        "위 검색 결과의 테이블/컬럼 정보를 활용하여 "
                        "사용자 요청에 맞는 응답을 생성하세요.\n"
                        "반드시 JSON 형식(title, description, sql)으로 응답하세요.\n"
                        "description은 보고서 형태의 Markdown으로 "
                        "목적, 사용 테이블·컬럼, 주요 로직, "
                        "변경 사항, 참고사항을 구조적으로 정리하세요."
                    ),
                )

                try:
                    async for chunk in rag_agent.stream_response(
                        user_message=user_message, thread_id=thread_id
                    ):
                        if isinstance(chunk, dict):
                            if chunk.get("content"):
                                accumulated += chunk["content"]
                            if chunk.get("status"):
                                await send_sse({"status": chunk["status"]})
                except TableConfirmationNeeded as tcn:
                    _sse_data: dict = {
                        "needs_table_confirmation": True,
                        "candidates": tcn.candidates,
                    }
                    if tcn.confirmed_tables:
                        _sse_data["confirmed_tables"] = tcn.confirmed_tables
                    await send_sse(_sse_data)
                    self.finish()
                    return
                except Exception as rag_err:
                    print(f"AthenaQuery: RAG error: {rag_err}", flush=True)
                    await send_sse({"error": f"RAG 검색 실패: {rag_err}"})
                    self.finish()
                    return

            # RAG 경로: agent state에서 rag_search 결과를 table_ctx로 추출
            if not table_ctx and rag_agent is not None:
                try:
                    _config = {"configurable": {"thread_id": thread_id}}
                    _state = await rag_agent._agent.aget_state(_config)
                    _msgs = _state.values.get("messages", [])
                    from langchain_core.messages import ToolMessage as _TM

                    for _msg in reversed(_msgs):
                        if not isinstance(_msg, _TM) or not _msg.content:
                            continue
                        try:
                            _parsed = json.loads(_msg.content)
                        except (json.JSONDecodeError, TypeError):
                            continue
                        if not isinstance(_parsed, dict):
                            continue
                        # 테이블 검색 결과 키 확인 (한글/영문 모두)
                        if "테이블 검색 결과" in _parsed or "table_results" in _parsed:
                            table_ctx = _msg.content
                            break
                    if table_ctx:
                        print(
                            f"AthenaQuery: table_ctx from state "
                            f"({len(table_ctx)} chars)",
                            flush=True,
                        )
                    else:
                        # ToolMessage는 있지만 rag_search 결과가 아닌 경우 — 마지막 ToolMessage 사용
                        for _msg in reversed(_msgs):
                            if isinstance(_msg, _TM) and _msg.content:
                                table_ctx = _msg.content
                                print(
                                    f"AthenaQuery: table_ctx fallback from "
                                    f"last ToolMessage ({len(table_ctx)} chars)",
                                    flush=True,
                                )
                                break
                except Exception as _err:
                    print(
                        f"AthenaQuery: table_ctx extraction error: {_err}",
                        flush=True,
                    )

            # Parse JSON
            print(
                f"AthenaQuery: accumulated len={len(accumulated)}, "
                f"preview={accumulated[:300]}",
                flush=True,
            )
            parsed = _parse_llm_json(accumulated)
            print(f"AthenaQuery: parsed keys={list(parsed.keys())}", flush=True)
            current_sql = parsed.get("sql", "").strip()
            current_desc = parsed.get("description", "")
            current_title = parsed.get("title", "")
            # Phase 1 description 고정 보존 (Phase 3 최적화 내역 append용)
            _phase1_desc = current_desc

            # ─── 텍스트 전용 응답 (SQL 없음) ───
            if not current_sql:
                print("AthenaQuery: no sql found, sending text response", flush=True)
                text = current_desc or accumulated.strip()
                if text:
                    await send_sse({"status": ""})
                    await send_sse(
                        {"content": text, "is_text_only": True, "title": current_title}
                    )
                else:
                    await send_sse(
                        {"error": "LLM 응답이 비어있습니다. 다시 시도해주세요."}
                    )
                self.finish()
                return

            # Phase 1 SQL을 프론트에 즉시 표시
            await send_sse({"sql_update": current_sql})

            # SQL이 기존과 동일하면 EXPLAIN 불필요 (공백/케이스 정규화 후 비교)
            import re as _re_norm

            def _norm_sql(s: str) -> str:
                return _re_norm.sub(r"\s+", " ", s).strip().lower()

            if _norm_sql(current_sql) == _norm_sql(existing_sql):
                print("AthenaQuery: SQL unchanged, skipping EXPLAIN", flush=True)
                await send_sse({"status": ""})
                await send_sse(
                    {
                        "content": json.dumps(
                            {
                                "title": current_title,
                                "description": current_desc,
                                "sql": current_sql,
                            },
                            ensure_ascii=False,
                        )
                    }
                )
                self.finish()
                return

            # Phase 2/3용 RAGChatAgent: RAG 경로면 이미 생성됨, selectedTables 경로면 새로 생성
            import re as _re_strip

            if rag_agent is None:
                from .handlers.rag_admin_handler import _ensure_manager
                from hdsp_agent_core.services.rag_chat_agent import RAGChatAgent
                from langgraph.checkpoint.memory import MemorySaver as _MemorySaver

                _ensure_manager()
                rag_agent = RAGChatAgent(
                    config_dict,
                    system_prompt_override=system_prompt,
                    checkpointer=_MemorySaver(),
                    grounding_constraint=(
                        "위 검색 결과의 테이블/컬럼 정보를 활용하여 "
                        "사용자 요청에 맞는 응답을 생성하세요.\n"
                        "반드시 JSON 형식(title, description, sql)으로 응답하세요.\n"
                        "description은 보고서 형태의 Markdown으로 "
                        "목적, 사용 테이블·컬럼, 주요 로직, "
                        "변경 사항, 참고사항을 구조적으로 정리하세요."
                    ),
                )

            # Phase 2: EXPLAIN fix 전용 프롬프트 (분리)
            _explain_fix_system = _get_explain_fix_system_prompt()
            # Phase 3: 플랜 튜닝 (기존 프롬프트에서 RAG 섹션 제거)
            _no_rag_prompt = _re_strip.sub(
                r"\n+## RAG 검색 도구.*", "", system_prompt, flags=_re_strip.DOTALL
            ).strip()
            _plan_tuning_system = _no_rag_prompt + _PLAN_TUNING_SYSTEM_ADDITION

            async def _rag_stream_accumulate(
                user_msg: str,
                phase_prompt: str,
                override_thread_id=None,
                block_tools: bool = False,
            ) -> str:
                """RAGChatAgent로 user_msg를 보내고 content를 누적하여 반환."""
                acc = ""
                async for chunk in rag_agent.stream_response(
                    user_message=user_msg,
                    thread_id=override_thread_id or thread_id,
                    phase_system_prompt=phase_prompt,
                    block_tools=block_tools,
                ):
                    if isinstance(chunk, dict) and chunk.get("content"):
                        acc += chunk["content"]
                return acc

            # ─── Phase 2: EXPLAIN 검증 루프 (최대 5회, 문법 오류 fix) ───
            max_retries = 5
            explain_result: dict = {}

            for attempt in range(1, max_retries + 1):
                await send_sse({"status": f"EXPLAIN 검증 중 ({attempt}/{max_retries})"})
                explain_result = await _run_explain(current_sql)

                if explain_result["success"]:
                    break

                # EXPLAIN 실패 → RAGChatAgent에게 수정 요청
                if attempt == max_retries:
                    await send_sse(
                        {
                            "error": f"EXPLAIN 검증 실패 "
                            f"({max_retries}회 시도): "
                            f"{explain_result['error']}"
                        }
                    )
                    self.finish()
                    return

                await send_sse(
                    {
                        "status": f"EXPLAIN 오류 수정 중 ({attempt}/{max_retries}): "
                        f"{explain_result['error'][:80]}"
                    }
                )
                fix_user_msg = (
                    f"[EXPLAIN 오류 수정]\n\n"
                    f"[SQL]\n{current_sql}\n\n"
                    f"[오류]\n{explain_result['error']}\n\n"
                )
                if table_ctx:
                    fix_user_msg += (
                        "[참고: 테이블 컬럼 정보 (JSON)]\n"
                        "columns는 col_headers와 매핑되는 배열입니다.\n"
                        f"{table_ctx}\n\n"
                    )
                fix_user_msg += (
                    "위 오류를 수정한 SQL을 JSON 형식으로 반환하세요. "
                    "반드시 제공된 테이블의 실제 컬럼명을 사용하세요."
                )
                # 매 시도마다 새 thread_id: 이전 실패 컨텍스트가 누적되지 않도록
                fix_thread_id = f"athena-fix-{uuid4()}"
                fix_text = await _rag_stream_accumulate(
                    fix_user_msg, _explain_fix_system, fix_thread_id
                )
                fixed = _parse_llm_json(fix_text)
                print(
                    f"AthenaQuery: EXPLAIN fix attempt={attempt} "
                    f"parsed_keys={list(fixed.keys())} "
                    f"has_sql={bool(fixed.get('sql'))} "
                    f"fix_text_len={len(fix_text)} "
                    f"fix_text_preview={fix_text[:200]}",
                    flush=True,
                )
                if fixed.get("sql"):
                    current_sql = fixed["sql"]
                    await send_sse({"sql_update": current_sql})

            # ─── Phase 3: 쿼리 플랜 기반 튜닝 + REASON 주석 (1회) ───
            # REASON은 기존 SQL 대비 변경을 설명하므로, existing_sql이 있고 실제로 변경된 경우만
            plan = explain_result.get("plan", "")
            _sql_actually_changed = (
                existing_sql and current_sql.strip() != existing_sql.strip()
            )
            if _sql_actually_changed or plan:
                await send_sse({"status": "쿼리 플랜 분석 중"})
                _origin_block = (
                    f"\n\n[원본 SQL]\n{existing_sql}" if existing_sql else ""
                )
                _desc_block = (
                    f"\n\n[변경 설명]\n{current_desc}"
                    if existing_sql and current_desc
                    else ""
                )
                _plan_block = f"\n\n[쿼리 플랜]\n{plan[:8000]}" if plan else ""
                plan_user_msg = (
                    f"[SQL]\n{current_sql}{_plan_block}{_origin_block}{_desc_block}"
                )
                _phase3_thread = f"athena-phase3-{uuid4()}"
                tuning_text = await _rag_stream_accumulate(
                    plan_user_msg,
                    _plan_tuning_system,
                    override_thread_id=_phase3_thread,
                    block_tools=True,
                )
                tuned = _parse_llm_json(tuning_text)
                _has_reason = "[REASON]" in tuned.get("sql", "")
                print(
                    f"AthenaQuery Phase3: keys={list(tuned.keys())} "
                    f"sql_changed={bool(tuned.get('sql') and tuned['sql'].strip() != current_sql.strip())} "
                    f"tuning_info={bool(tuned.get('tuning_info'))} "
                    f"has_reason={_has_reason} "
                    f"raw_len={len(tuning_text)}",
                    flush=True,
                )

                if tuned.get("sql") and tuned["sql"].strip() != current_sql.strip():
                    # SQL 변경됨 → Phase 4: 최종 EXPLAIN 1회 (플랜 튜닝 없음)
                    current_sql = tuned["sql"]
                    # Phase 1 description 유지 + tuning_info append
                    tuning_info = tuned.get("tuning_info", "")
                    if tuning_info:
                        # blockquote로 감싸서 CSS 타겟 가능하도록
                        _quoted = "\n".join(
                            f"> {line}" for line in tuning_info.strip().splitlines()
                        )
                        current_desc = (
                            _phase1_desc
                            + "\n\n---\n\n"
                            + "**🔧 Query Plan 기반 추가 최적화**\n\n"
                            + _quoted
                        )
                    await send_sse({"sql_update": current_sql})

                    await send_sse({"status": "최종 EXPLAIN 검증 중"})
                    final_explain = await _run_explain(current_sql)
                    if not final_explain["success"]:
                        await send_sse(
                            {
                                "error": f"플랜 튜닝 후 EXPLAIN 실패: "
                                f"{final_explain['error']}"
                            }
                        )
                        self.finish()
                        return
                else:
                    # SQL 변경 없음 → Phase 1 description 원본 복원
                    current_desc = _phase1_desc

            # ─── 최종 결과 전송 ───
            await send_sse({"status": ""})
            await send_sse(
                {
                    "content": json.dumps(
                        {
                            "title": current_title,
                            "description": current_desc,
                            "sql": current_sql,
                        },
                        ensure_ascii=False,
                    )
                }
            )
            self.finish()

        except Exception as e:
            logger.error(f"AthenaQueryStream failed: {e}", exc_info=True)
            try:
                self.write(
                    f"data: {json.dumps({'error': str(e)}, ensure_ascii=False)}\n\n"
                )
                self.finish()
            except Exception:
                pass
        finally:
            try:
                from .agent.langchain_tools import set_eda_only_bdp

                set_eda_only_bdp(False)
            except Exception:
                pass


class AthenaCandidatesHandler(APIHandler):
    """POST /hdsp-agent/athena/candidates — RAG search only, no LLM.

    '다른 테이블 살펴보기' 버튼에서 사용.
    queries 배열의 각 쿼리에 대해 RAG 검색 후 후보 테이블 목록 반환.
    """

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            queries = body.get("queries") or []
            excluded_table_names = body.get("excludedTableNames") or []

            if not queries:
                self.set_status(400)
                self.write({"error": "queries 배열이 필요합니다."})
                return

            # Build excluded set
            _excluded = {str(n).lower() for n in excluded_table_names if n}

            # Use rag_collections search_with_filter directly
            from hdsp_agent_core.factory import get_service_factory as _get_sf

            factory = _get_sf()
            rag_service = factory.get_rag_service()
            # Access underlying rag_manager's rag_collections
            rag_manager = getattr(rag_service, "_rag_manager", None)
            rag_collections = getattr(rag_manager, "_collections", None)

            def _get_field(p: dict, *keys: str) -> str:
                for k in keys:
                    v = p.get(k)
                    if v:
                        return str(v)
                return ""

            candidates: dict = {}
            # exclude 수만큼 top_k 확장 (필터링 후에도 결과가 남도록)
            _result_limit = body.get("limit", 5)
            _base_top_k = max(_result_limit, 10)
            _effective_top_k = _base_top_k + len(_excluded)
            # Cross-group dedup: 이미 다른 쿼리 그룹에 할당된 테이블 제외
            _assigned_tables: set = set()

            for query in queries:
                if not query or not query.strip():
                    continue

                # RAG search
                try:
                    if rag_collections is not None:
                        results = await rag_collections.search_with_filter(
                            query=query,
                            collection="bdp_tables",
                            top_k=_effective_top_k,
                            score_threshold=0.15,
                        )
                    else:
                        # Fallback to rag_manager.search
                        results = await rag_manager.search(
                            query=query,
                            collection_name="bdp_tables",
                            top_k=_effective_top_k,
                        )
                        # Normalize format: metadata → payload
                        results = [
                            {
                                "score": r.get("score", 0),
                                "payload": r.get("metadata", {}),
                                "id": r.get("id", ""),
                            }
                            for r in results
                        ]
                except Exception as e:
                    logger.warning(f"AthenaCandidates search failed for '{query}': {e}")
                    results = []

                if not results:
                    continue

                # Apply exclusion filter
                if _excluded:
                    results = [
                        r
                        for r in results
                        if str(
                            r.get("payload", {}).get("table_name")
                            or r.get("payload", {}).get("테이블명")
                            or ""
                        ).lower()
                        not in _excluded
                    ]

                if not results:
                    continue

                # Sort by score
                sorted_r = sorted(
                    results, key=lambda x: x.get("score", 0), reverse=True
                )

                # Dedup by table name (same logic as middleware)
                # + cross-group dedup: 다른 쿼리 그룹에 이미 할당된 테이블 제외
                seen_table_names: dict = {}
                for r in sorted_r:
                    p = r.get("payload", {})
                    tname = (
                        p.get("table_name")
                        or p.get("테이블명")
                        or p.get("table_id")
                        or r.get("id", "")
                    )
                    tname_lower = str(tname).lower()
                    if (
                        tname not in seen_table_names
                        and tname_lower not in _assigned_tables
                    ):
                        seen_table_names[tname] = r
                deduped = list(seen_table_names.values())[:_result_limit]
                # 할당된 테이블 기록
                for r in deduped:
                    p = r.get("payload", {})
                    tname = (
                        p.get("table_name")
                        or p.get("테이블명")
                        or p.get("table_id")
                        or r.get("id", "")
                    )
                    _assigned_tables.add(str(tname).lower())

                candidates[query] = [
                    {
                        "table_name": _get_field(
                            r.get("payload", {}), "table_name", "테이블명", "table_id"
                        ),
                        "korean_name": _get_field(
                            r.get("payload", {}),
                            "korean_name",
                            "테이블한글명",
                            "한글명",
                        ),
                        "score": r.get("score", 0),
                        "description": _get_field(
                            r.get("payload", {}), "description", "설명"
                        ),
                        "domain": _get_field(r.get("payload", {}), "domain", "도메인"),
                        "columns": r.get("payload", {}).get("columns", []),
                        "col_headers": r.get("payload", {}).get("col_headers", []),
                        "payload": {
                            k: v
                            for k, v in r.get("payload", {}).items()
                            if k
                            not in (
                                "columns",
                                "col_headers",
                                "_embed_text",
                                "_content_hash",
                                "_collection",
                            )
                        },
                    }
                    for r in deduped
                ]

            self.set_header("Content-Type", "application/json")
            self.write(
                json.dumps(
                    {"candidates": candidates, "needs_table_confirmation": True},
                    ensure_ascii=False,
                    default=str,
                )
            )

        except Exception as e:
            logger.error(f"AthenaCandidates failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AthenaTableColumnsHandler(APIHandler):
    """POST /hdsp-agent/athena/table-columns — 테이블 컬럼 조회 (청크 단위 lazy 로딩).

    chunk_index=0 (기본): 첫 번째 청크 컬럼 + 메타 반환.
    chunk_index=N: N번째 청크 컬럼 반환.
    응답에 has_more=True이면 다음 chunk_index로 추가 요청.
    """

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            table_name = body.get("table_name", "")
            collection = body.get("collection", "bdp_tables")
            chunk_index = body.get("chunk_index", 0)

            if not table_name:
                self.set_status(400)
                self.write({"error": "table_name이 필요합니다."})
                return

            from .handlers.rag_admin_handler import _ensure_manager

            mgr = _ensure_manager()
            if mgr is None:
                self.set_status(500)
                self.write({"error": "RAG 매니저가 초기화되지 않았습니다."})
                return

            from qdrant_client.models import FieldCondition, Filter, MatchValue

            client = mgr._client

            # table_name 또는 테이블명 필드로 검색
            points: list = []
            _FIELDS = ["table_name", "테이블명"]
            for f in _FIELDS:
                for val in (table_name, table_name.lower()):
                    try:
                        scroll_result = client.scroll(
                            collection_name=collection,
                            scroll_filter=Filter(
                                must=[
                                    FieldCondition(key=f, match=MatchValue(value=val))
                                ]
                            ),
                            limit=100,
                            with_payload=True,
                            with_vectors=False,
                        )
                        points = scroll_result[0] if scroll_result else []
                        if points:
                            break
                    except Exception:
                        continue
                if points:
                    break

            if not points:
                self.write(
                    {
                        "success": False,
                        "error": f"'{table_name}'을(를) 찾을 수 없습니다.",
                    }
                )
                return

            # 청크 순서대로 정렬
            def _chunk_sort(pt):
                chunk = (pt.payload or {}).get("_chunk", "1/1")
                try:
                    return int(str(chunk).split("/")[0])
                except (ValueError, IndexError):
                    return 0

            points.sort(key=_chunk_sort)
            total_chunks = len(points)

            # 요청한 청크의 컬럼 반환
            if chunk_index >= total_chunks:
                self.write({"success": True, "columns": [], "has_more": False})
                return

            pt = points[chunk_index]
            cols = (pt.payload or {}).get("columns", [])
            if not isinstance(cols, list):
                cols = []

            result: dict = {
                "success": True,
                "table_name": table_name,
                "columns": cols,
                "chunk_index": chunk_index,
                "total_chunks": total_chunks,
                "has_more": chunk_index + 1 < total_chunks,
            }

            # 첫 청크에만 메타 정보 포함
            if chunk_index == 0:
                first_payload = dict(points[0].payload or {})
                result["meta"] = {
                    k: v
                    for k, v in first_payload.items()
                    if k
                    not in (
                        "columns",
                        "col_headers",
                        "_embed_text",
                        "_content_hash",
                        "_collection",
                        "_group_key",
                        "_chunk",
                    )
                }

            self.write(result)
        except Exception as e:
            self.set_status(500)
            self.write({"error": str(e)})


def _substitute_date_vars(sql: str) -> str:
    """SQL 내 ${prefix_format} 날짜 변수를 치환.

    prefix: today, bf{N}{d|m|y}, af{N}{d|m|y}
    format: y, m, d, ym, ymd, y_m, y_m_d, ymdhms 등 (구분자 _ 포함)
    """
    import re as _re
    from datetime import datetime, timedelta

    from dateutil.relativedelta import relativedelta

    now = datetime.now()

    def _resolve(match: _re.Match) -> str:
        var = match.group(1)  # prefix_format
        parts = var.split("_", 1)

        # prefix 파싱
        prefix = parts[0]
        fmt_str = parts[1] if len(parts) > 1 else ""

        # 기준 날짜 결정
        base = now
        prefix_lower = prefix.lower()
        if prefix_lower == "today":
            base = now
        elif prefix_lower.startswith("bf"):
            # bf1d, bf3m, bf1y
            num_unit = prefix_lower[2:]
            num = (
                int(_re.match(r"\d+", num_unit).group())
                if _re.match(r"\d+", num_unit)
                else 1
            )
            unit = num_unit[len(str(num)) :] if len(str(num)) < len(num_unit) else "d"
            if unit == "d":
                base = now - timedelta(days=num)
            elif unit == "m":
                base = now - relativedelta(months=num)
            elif unit == "y":
                base = now - relativedelta(years=num)
        elif prefix_lower.startswith("af"):
            num_unit = prefix_lower[2:]
            num = (
                int(_re.match(r"\d+", num_unit).group())
                if _re.match(r"\d+", num_unit)
                else 1
            )
            unit = num_unit[len(str(num)) :] if len(str(num)) < len(num_unit) else "d"
            if unit == "d":
                base = now + timedelta(days=num)
            elif unit == "m":
                base = now + relativedelta(months=num)
            elif unit == "y":
                base = now + relativedelta(years=num)

        # 포맷 변환
        # y=연, m=월(h 뒤면 분), d=일, h=시, s=초, _=구분자
        if not fmt_str:
            return match.group(0)

        result = ""
        after_h = False  # h 이후의 m은 분(minute)
        for ch in fmt_str:
            if ch == "y":
                result += f"{base.year:04d}"
            elif ch == "m" and not after_h:
                result += f"{base.month:02d}"
            elif ch == "m" and after_h:
                result += f"{base.minute:02d}"
            elif ch == "d":
                result += f"{base.day:02d}"
            elif ch == "h":
                result += f"{base.hour:02d}"
                after_h = True
            elif ch == "s":
                result += f"{base.second:02d}"
            else:
                result += ch

        return result

    return _re.sub(r"\$\{([^}]+)\}", _resolve, sql)


class AthenaExecuteHandler(APIHandler):
    """POST /hdsp-agent/athena/execute — start Athena query."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            query = body.get("sql", "").strip()
            if not query:
                self.set_status(400)
                self.write({"error": "sql is required"})
                return

            # 날짜 변수 치환
            query = _substitute_date_vars(query)

            # bdpengine의 start_query 사용
            from bdpengine.functions import start_query

            result = start_query(query=query)
            self.write(result)
        except ImportError:
            self.set_status(500)
            self.write({"error": "bdpengine이 설치되지 않았습니다."})
        except Exception as e:
            logger.error(f"AthenaExecute error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AthenaStatusHandler(APIHandler):
    """GET /hdsp-agent/athena/status/<execution_id> — check query status."""

    async def get(self, execution_id: str):
        try:
            from bdpengine.functions import get_boto3_client

            client = get_boto3_client("athena")
            resp = client.get_query_execution(QueryExecutionId=execution_id)
            qe = resp["QueryExecution"]
            status = qe.get("Status", {})
            result: dict = {
                "State": status.get("State", ""),
                "StateChangeReason": status.get("StateChangeReason", ""),
            }
            # SUCCEEDED 시 Statistics 포함
            stats = qe.get("Statistics", {})
            if stats:
                data_scanned = stats.get("DataScannedInBytes", 0)
                exec_ms = stats.get("EngineExecutionTimeInMillis", 0)
                # Athena 비용: $5/TB, 환율 1500원, 부가세 10%
                cost_usd = (data_scanned / (1024**4)) * 5
                cost_krw = cost_usd * 1500 * 1.1
                result["Statistics"] = {
                    "DataScannedInBytes": data_scanned,
                    "EngineExecutionTimeInMillis": exec_ms,
                    "CostUSD": round(cost_usd, 6),
                    "CostKRW": round(cost_krw, 2),
                }
            self.write(result)
        except ImportError:
            self.set_status(500)
            self.write({"error": "bdpengine이 설치되지 않았습니다."})
        except Exception as e:
            logger.error(f"AthenaStatus error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AthenaDownloadHandler(APIHandler):
    """POST /hdsp-agent/athena/download/<execution_id> — S3 결과를 워크스페이스에 저장."""

    async def post(self, execution_id: str):
        try:
            from bdpengine.functions import get_boto3_client

            client = get_boto3_client("athena")
            resp = client.get_query_execution(QueryExecutionId=execution_id)
            qe = resp["QueryExecution"]

            # S3 OutputLocation 추출
            output_location = qe.get("ResultConfiguration", {}).get(
                "OutputLocation", ""
            )
            if not output_location:
                self.set_status(404)
                self.write({"error": "결과 파일 경로를 찾을 수 없습니다."})
                return

            # s3://bucket/key 파싱
            s3_path = output_location.replace("s3://", "")
            bucket = s3_path.split("/", 1)[0]
            key = s3_path.split("/", 1)[1] if "/" in s3_path else ""

            if not key:
                self.set_status(404)
                self.write({"error": f"S3 경로 파싱 실패: {output_location}"})
                return

            # JupyterLab 워크스페이스 루트 디렉토리에 저장
            import os

            root_dir = self.settings.get(
                "server_root_dir",
                self.settings.get("root_dir", os.getcwd()),
            )
            filename = f"query_result_{execution_id[:12]}.csv"
            local_path = os.path.join(root_dir, filename)

            # S3에서 다운로드
            s3_client = get_boto3_client("s3")
            s3_client.download_file(bucket, key, local_path)

            file_size = os.path.getsize(local_path)
            self.write(
                {
                    "status": "success",
                    "filename": filename,
                    "path": local_path,
                    "size": file_size,
                    "s3_source": output_location,
                }
            )

        except ImportError:
            self.set_status(500)
            self.write({"error": "bdpengine이 설치되지 않았습니다."})
        except Exception as e:
            logger.error(f"AthenaDownload error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AthenaStopHandler(APIHandler):
    """POST /hdsp-agent/athena/stop/<execution_id> — stop query."""

    async def post(self, execution_id: str):
        try:
            from bdpengine.functions import get_boto3_client

            client = get_boto3_client("athena")
            client.stop_query_execution(QueryExecutionId=execution_id)
            self.write({"status": "stopped"})
        except ImportError:
            self.set_status(500)
            self.write({"error": "bdpengine이 설치되지 않았습니다."})
        except Exception as e:
            logger.error(f"AthenaStop error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AthenaResultsHandler(APIHandler):
    """GET /hdsp-agent/athena/results/<execution_id> — get query results.

    Query params:
        page: 페이지 번호 (1부터, 기본 1)
        page_size: 페이지당 행 수 (기본 100, 최대 1000)
    """

    async def get(self, execution_id: str):
        try:
            from bdpengine.functions import get_boto3_client

            page = int(self.get_argument("page", "1"))
            page_size = min(int(self.get_argument("page_size", "100")), 1000)

            client = get_boto3_client("athena")

            # 첫 페이지: 헤더 + 데이터
            # N페이지: NextToken으로 스킵
            all_rows = []
            columns = []
            next_token = None
            # 필요한 행 수: page * page_size + 1 (헤더)
            rows_needed = page * page_size + 1

            while len(all_rows) < rows_needed:
                kwargs = {
                    "QueryExecutionId": execution_id,
                    "MaxResults": min(1000, rows_needed - len(all_rows) + 1),
                }
                if next_token:
                    kwargs["NextToken"] = next_token

                resp = client.get_query_results(**kwargs)
                result_set = resp.get("ResultSet", {})
                row_data = result_set.get("Rows", [])

                if not row_data:
                    break

                # 첫 응답의 첫 행 = 헤더
                start_idx = 0
                if not columns and row_data:
                    columns = [
                        c.get("VarCharValue", "") for c in row_data[0].get("Data", [])
                    ]
                    start_idx = 1

                for row in row_data[start_idx:]:
                    all_rows.append(
                        [c.get("VarCharValue", "") for c in row.get("Data", [])]
                    )

                next_token = resp.get("NextToken")
                if not next_token:
                    break

            total_rows = len(all_rows)
            total_pages = (
                (total_rows + page_size - 1) // page_size if total_rows > 0 else 1
            )

            # 요청한 페이지의 행만 추출
            start = (page - 1) * page_size
            end = start + page_size
            page_rows = all_rows[start:end]

            self.write(
                {
                    "columns": columns,
                    "rows": page_rows,
                    "count": len(page_rows),
                    "total_rows": total_rows,
                    "page": page,
                    "page_size": page_size,
                    "total_pages": total_pages,
                    "has_more": next_token is not None or end < total_rows,
                }
            )
        except ImportError:
            self.set_status(500)
            self.write({"error": "bdpengine이 설치되지 않았습니다."})
        except Exception as e:
            logger.error(f"AthenaResults error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class NotebookGenerateHandler(APIHandler):
    """POST /hdsp-agent/notebook/generate — start notebook generation task."""

    async def post(self):
        try:
            from datetime import datetime

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            prompt = body.get("prompt", "").strip()
            if not prompt:
                self.set_status(400)
                self.write({"error": "prompt is required"})
                return

            task_id = str(uuid4())
            output_dir = body.get("outputDir") or os.getcwd()

            # Resolve LLM overrides based on admin/normal mode
            llm_overrides = None
            is_admin, _ = _is_admin_mode()
            if is_admin and "llmConfig" in body:
                llm_overrides = {}
                llm_config = body["llmConfig"]
                for key in ("provider", "vllm", "summarization", "embedding"):
                    if key in llm_config:
                        llm_overrides[key] = llm_config[key]
            elif not is_admin:
                from hdsp_agent_core.managers.config_manager import ConfigManager as _CM

                env_config = _CM.get_env_llm_config()
                if env_config:
                    llm_overrides = env_config
                else:
                    self.set_status(400)
                    self.write(
                        {
                            "error": "LLM 설정이 구성되지 않았습니다. 관리자에게 문의하세요.",
                        },
                    )
                    return

            now = datetime.now(_tz.utc).isoformat()
            task_state = {
                "taskId": task_id,
                "prompt": prompt,
                "status": "pending",
                "progress": 0,
                "message": "작업이 시작되었습니다",
                "result": None,
                "error": None,
                "notebookPath": None,
                "createdAt": now,
                "startedAt": None,
                "completedAt": None,
            }
            _notebook_tasks[task_id] = task_state
            _notebook_task_queues[task_id] = asyncio.Queue()

            # Spawn background task
            asyncio.create_task(
                _generate_notebook_task(task_id, prompt, output_dir, llm_overrides),
            )

            self.write(
                {
                    "taskId": task_id,
                    "status": "pending",
                    "message": "작업이 시작되었습니다",
                },
            )
        except Exception as e:
            logger.error(f"NotebookGenerate error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class TaskStatusHandler(APIHandler):
    """GET /hdsp-agent/task/<taskId>/status — poll task status."""

    async def get(self, task_id: str):
        task = _notebook_tasks.get(task_id)
        if not task:
            self.set_status(404)
            self.write({"error": "Task not found"})
            return
        self.write(task)


class TaskStreamHandler(APIHandler):
    """GET /hdsp-agent/task/<taskId>/stream — SSE stream of task status updates."""

    async def get(self, task_id: str):
        task = _notebook_tasks.get(task_id)
        if not task:
            self.set_status(404)
            self.write({"error": "Task not found"})
            return

        queue = _notebook_task_queues.get(task_id)
        if not queue:
            self.set_status(404)
            self.write({"error": "Task stream not found"})
            return

        self.set_header("Content-Type", "text/event-stream")
        self.set_header("Cache-Control", "no-cache")
        self.set_header("Connection", "keep-alive")
        self.set_header("X-Accel-Buffering", "no")

        # Send current state immediately
        self.write(f"data: {json.dumps(task)}\n\n")
        await self.flush()

        # If already terminal, close
        if task.get("status") in ("completed", "failed", "cancelled"):
            self.finish()
            return

        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=15.0)
            except TimeoutError:
                # Heartbeat
                self.write(": heartbeat\n\n")
                await self.flush()
                continue

            if event is None:
                # Sentinel — stream done
                break

            self.write(f"data: {json.dumps(event)}\n\n")
            await self.flush()

            if event.get("status") in ("completed", "failed", "cancelled"):
                break

        self.finish()


class TaskCancelHandler(APIHandler):
    """POST /hdsp-agent/task/<taskId>/cancel — cancel a running task."""

    async def post(self, task_id: str):
        task = _notebook_tasks.get(task_id)
        if not task:
            self.set_status(404)
            self.write({"error": "Task not found"})
            return

        from datetime import datetime

        await _update_notebook_task(
            task_id,
            {
                "status": "cancelled",
                "message": "작업이 취소되었습니다",
                "completedAt": datetime.now(_tz.utc).isoformat(),
            },
        )

        # Push sentinel to close SSE stream
        queue = _notebook_task_queues.get(task_id)
        if queue:
            await queue.put(None)

        self.write({"status": "cancelled", "taskId": task_id})


# ============ Embedded Agent Handlers ============

# Module-level agent session management
_active_agents: dict = {}  # thread_id → AgentRunner (실행 중만)
_agent_locks: dict = {}

# Global checkpointer & agent cache (Phase 1: 대화 지속성)
_global_checkpointer = (
    _MemorySaver() if _LANGGRAPH_AVAILABLE else None
)  # 모든 스레드 공유 (thread_id로 네임스페이스 분리)
_agent_cache: dict = {}  # cache_key → CompiledStateGraph
_thread_metadata: dict = {}  # thread_id → {emitted_contents: set, ...}


def _get_agent_runner(thread_id: str):
    """Get an active AgentRunner by thread_id."""
    return _active_agents.get(thread_id)


def _get_agent_cache_key(config_dict: dict, workspace_root: str) -> str:
    """Agent 캐시 키 생성 — 동일 모델/엔드포인트/모드/프롬프트면 그래프 재사용."""
    import hashlib

    vllm = config_dict.get("vllm", {})
    # 관리자 커스텀 프롬프트가 변경되면 캐시 무효화
    prompts = config_dict.get("prompts", {})
    data = json.dumps(
        {
            "model": vllm.get("model", ""),
            "endpoint": vllm.get("endpoint", ""),
            "mode": config_dict.get("mode", "default"),
            "agentMode": config_dict.get("agentMode", "multi"),
            "prompts": prompts,
        },
        sort_keys=True,
    )
    return hashlib.md5(f"{data}|{workspace_root}".encode()).hexdigest()


def _inject_workspace_root(body: dict, settings: dict) -> dict:
    """Inject resolved workspaceRoot into request body."""
    server_root = settings.get("server_root_dir", os.getcwd())
    server_root = os.path.expanduser(server_root)
    resolved_root = _resolve_workspace_root(server_root)
    workspace_root = body.get("workspaceRoot")

    if not workspace_root or workspace_root == ".":
        body["workspaceRoot"] = resolved_root
    elif not os.path.isabs(workspace_root):
        body["workspaceRoot"] = os.path.join(resolved_root, workspace_root)
    return body


class LangChainStreamHandler(APIHandler):
    """POST: run agent with SSE streaming."""

    async def post(self):
        try:
            from .agent.agent_factory import (
                AgentEvent,
                AgentFactory,
                config_from_dict,
            )
            from .tools import NotebookContextManager

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            body = _inject_workspace_root(body, self.settings)

            body_len = len(self.request.body) if self.request.body else 0
            logger.info("LangChainStream: request body size=%d bytes", body_len)

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            thread_id = body.get("threadId", "")
            request_text = body.get("request", "")
            workspace_root = body.get("workspaceRoot", "")

            # 리소스 컨텍스트 플레이스홀더 치환 (Agent 모드)
            if "{{RESOURCE_CONTEXT}}" in request_text:
                body["request"] = _inject_resource_context(request_text, self.settings)
                request_text = body["request"]

            # /reset 명령 감지
            if request_text.strip().startswith("/reset"):
                effective_thread_id = thread_id or ""
                _active_agents.pop(effective_thread_id, None)
                _thread_metadata.pop(effective_thread_id, None)
                try:
                    storage = getattr(_global_checkpointer, "storage", {})
                    storage.pop(effective_thread_id, None)
                except Exception:
                    pass
                self.write(
                    f"event: complete\ndata: {json.dumps({'thread_id': effective_thread_id, 'reset': True})}\n\n",
                )
                await self.flush()
                self.finish()
                return

            # Build agent config from request body
            is_admin, _ = _is_admin_mode()
            cm = _get_config_manager()
            config_dict = cm.get_config()
            config_dict.update(
                {
                    k: v
                    for k, v in body.items()
                    if k in ("temperature", "mode", "autoApprove", "agentMode")
                },
            )

            if is_admin and "llmConfig" in body:
                # 관리자모드: 프론트엔드 localStorage에서 받은 LLM 설정 사용
                llm_config = body["llmConfig"]
                for key in (
                    "provider",
                    "vllm",
                    "summarization",
                    "embedding",
                    "prompts",
                    "idleTimeout",
                ):
                    if key in llm_config:
                        config_dict[key] = llm_config[key]
            elif not is_admin:
                # 일반모드: 환경변수에서 LLM 설정 읽기
                from hdsp_agent_core.managers.config_manager import ConfigManager as _CM

                env_config = _CM.get_env_llm_config()
                if env_config:
                    config_dict.update(env_config)
                else:
                    error_msg = "LLM 설정이 구성되지 않았습니다. 관리자에게 문의하세요."
                    self.write(f"data: {json.dumps({'error': error_msg})}\n\n")
                    self.write(
                        f"event: complete\ndata: {json.dumps({'thread_id': ''})}\n\n",
                    )
                    await self.flush()
                    self.finish()
                    return

            agent_config = config_from_dict(config_dict)

            # API 키 사전 검증: 빈/마스킹된 키로 불필요한 LLM 호출 방지
            from hdsp_agent_core.managers.config_manager import _is_masked_api_key

            if not agent_config.api_key or _is_masked_api_key(agent_config.api_key):
                if agent_config.api_key and _is_masked_api_key(agent_config.api_key):
                    error_msg = "API 키가 손상되었습니다. 설정 패널에서 API 키를 다시 입력해주세요."
                else:
                    error_msg = "LLM API 키가 설정되지 않았습니다. 설정 패널에서 API 키를 입력해주세요."
                self.write(f"data: {json.dumps({'error': error_msg})}\n\n")
                self.write(
                    f"event: complete\ndata: {json.dumps({'thread_id': ''})}\n\n",
                )
                await self.flush()
                self.finish()
                return

            # SSE event queue for streaming
            event_queue: asyncio.Queue = asyncio.Queue()

            async def on_event(event: AgentEvent):
                await event_queue.put(event)

            notebook_context = NotebookContextManager(
                kernel_manager=None,
                contents_manager=getattr(self, "contents_manager", None),
            )

            # Initialize notebook context from frontend's notebookContext
            nb_ctx = body.get("notebookContext", {})
            nb_path = nb_ctx.get("notebook_path", "") if nb_ctx else ""
            if nb_path:
                cm = getattr(self, "contents_manager", None)
                loaded = False
                if cm:
                    try:
                        nb_model = cm.get(nb_path, content=True, type="notebook")
                        notebook_context.set_notebook(nb_path, nb_model)
                        loaded = True
                    except Exception as e:
                        logger.warning("Failed to load notebook %s: %s", nb_path, e)

                if not loaded:
                    # Fallback: build minimal model from frontend data
                    recent_cells = nb_ctx.get("recent_cells", [])
                    minimal_model = {
                        "content": {
                            "cells": [
                                {
                                    "cell_type": "code",
                                    "source": c.get("source", ""),
                                    "outputs": [],
                                    "metadata": {},
                                }
                                for c in recent_cells
                            ],
                            "metadata": {"kernelspec": {"name": "python3"}},
                        },
                    }
                    notebook_context.set_notebook(nb_path, minimal_model)
                logger.info(
                    "LangChainStream: notebook context set for %s (loaded=%s)",
                    nb_path,
                    loaded,
                )
            else:
                logger.info(
                    "LangChainStream: notebookContext=%s, no notebook_path",
                    bool(nb_ctx),
                )

            # [ROUTE:xxx] 감지 → xxx_direct 모드 오버라이드 (캐시 키 생성 전에 적용)
            import re

            _route_match = re.search(r"\[ROUTE:(\w+)\]", request_text)
            if _route_match:
                _agent_name = _route_match.group(1)
                agent_config.agent_mode = f"{_agent_name}_direct"
                config_dict["agentMode"] = f"{_agent_name}_direct"
                request_text = request_text.replace(_route_match.group(0), "").strip()

            # Agent 캐시 키 생성 및 그래프 재사용
            from .agent.agent_factory import AgentRunner

            cache_key = _get_agent_cache_key(config_dict, workspace_root)
            effective_thread_id = thread_id or str(uuid4())

            if cache_key in _agent_cache:
                # 캐시된 그래프 재사용 → AgentRunner만 새로 생성
                runner = AgentRunner(
                    agent=_agent_cache[cache_key],
                    config=agent_config,
                    on_event=on_event,
                    thread_id=effective_thread_id,
                )
            else:
                # 새 agent 생성 (global checkpointer 전달)
                factory = AgentFactory(
                    notebook_context=notebook_context,
                    workspace_root=workspace_root,
                    on_event=on_event,
                )
                runner = factory.create_agent(
                    agent_config,
                    checkpointer=_global_checkpointer,
                    thread_id=effective_thread_id,
                )
                _agent_cache[cache_key] = runner.agent

            logger.info(
                "LangChainStream: provider=%s model=%s base_url=%s thread=%s cached=%s",
                agent_config.provider,
                agent_config.model,
                getattr(agent_config, "base_url", None),
                effective_thread_id,
                cache_key in _agent_cache,
            )
            _active_agents[effective_thread_id] = runner

            # Phase 2: 기존 상태 확인 + Todo 리셋
            config = {
                "configurable": {"thread_id": effective_thread_id},
                "recursion_limit": 1000,
            }
            previous_todos_context = None
            existing_todos = []
            try:
                existing_state = await runner.agent.aget_state(config)
                if existing_state and hasattr(existing_state, "values"):
                    existing_todos = existing_state.values.get("todos", [])
                    if existing_todos:
                        await asyncio.to_thread(
                            runner.agent.update_state,
                            config,
                            {"todos": [], "todo_active": False},
                        )
                        completed = [
                            t.get("content", "") if isinstance(t, dict) else t.content
                            for t in existing_todos
                            if (t.get("status") if isinstance(t, dict) else t.status)
                            == "completed"
                        ]
                        if completed:
                            items_summary = ", ".join(completed[:5]) + (
                                "..." if len(completed) > 5 else ""
                            )
                            previous_todos_context = (
                                f"[SYSTEM] 이전 todo list 완료. 완료 작업: {items_summary}. "
                                f"새 작업을 시작합니다. 간단한 작업이면 write_todos 없이 바로 실행하세요."
                            )
            except Exception as e:
                logger.warning("State check failed: %s", e)

            # Todos 리셋 SSE 이벤트 전송
            if existing_todos:
                await event_queue.put(
                    AgentEvent(type="todos", data={"todos": [], "reset": True}),
                )

            # 이전 맥락 주입
            full_prompt = request_text
            if previous_todos_context:
                full_prompt = f"{previous_todos_context}\n\n{request_text}"

            # Run agent in background, stream events via queue
            async def run_agent():
                try:
                    await runner.run(full_prompt)
                except Exception as e:
                    logger.error(f"LangChainStream run error: {e}", exc_info=True)
                    await event_queue.put(
                        AgentEvent(type="error", data={"message": str(e)}),
                    )
                finally:
                    await event_queue.put(None)  # sentinel

            task = asyncio.create_task(run_agent())

            import time as _time

            _stream_start = _time.monotonic()
            _HEARTBEAT_TIMEOUT = 15  # seconds per queue.get
            _ABSOLUTE_TIMEOUT = 300  # 5 min absolute

            _hitl_pending = False

            try:
                while True:
                    try:
                        event = await asyncio.wait_for(
                            event_queue.get(),
                            timeout=_HEARTBEAT_TIMEOUT,
                        )
                    except TimeoutError:
                        elapsed = _time.monotonic() - _stream_start
                        if elapsed > _ABSOLUTE_TIMEOUT:
                            logger.error("LangChainStream absolute timeout exceeded")
                            self.write(
                                f"data: {json.dumps({'error': 'Agent timeout (5 min)'})}\n\n",
                            )
                            # 타임아웃 후에도 complete 이벤트 전송 — 프론트엔드 정상 종료 보장
                            self.write(
                                f"event: complete\ndata: {json.dumps({'thread_id': effective_thread_id})}\n\n",
                            )
                            await self.flush()
                            break
                        self.write(": heartbeat\n\n")
                        await self.flush()
                        continue
                    if event is None:
                        break

                    etype = event.type
                    edata = event.data or {}

                    if etype == "start":
                        self.write(
                            f"data: {json.dumps({'status': '에이전트 시작'})}\n\n",
                        )
                    elif etype == "progress":
                        msg = edata.get("message", "Thinking...")
                        icon = edata.get("icon")
                        payload_progress: dict = {"status": msg}
                        if icon:
                            payload_progress["icon"] = icon
                        if edata.get("turn") is not None:
                            payload_progress["turn"] = edata["turn"]
                        if edata.get("step") is not None:
                            payload_progress["step"] = edata["step"]
                        if edata.get("tool_label"):
                            payload_progress["tool_label"] = edata["tool_label"]
                        self.write(f"data: {json.dumps(payload_progress)}\n\n")
                    elif etype == "tool_call":
                        name = edata.get("name", "unknown")
                        # 셀 생성 도구 + 멀티에이전트 도구만 tool_call SSE 전송
                        if name in (
                            "jupyter_cell",
                            "jupyter_markdown",
                            "file_write",
                            "task",
                            "ask_user_tool",
                            "final_summary_tool",
                        ):
                            args = edata.get("arguments", {})
                            if not isinstance(args, dict):
                                args = {}
                            payload: dict = {"tool": name}
                            if name == "jupyter_markdown":
                                payload["content"] = args.get("content", "")
                            elif name == "task":
                                payload["agent_name"] = args.get(
                                    "subagent_type",
                                    args.get("agent_name", ""),
                                )
                                payload["description"] = args.get("description", "")
                            elif name == "final_summary_tool":
                                payload["summary"] = args.get("summary", "")
                                payload["next_items"] = args.get("next_items", [])
                            else:
                                payload["code"] = args.get("code", "")
                            self.write(
                                f"event: tool_call\ndata: {json.dumps(payload)}\n\n",
                            )
                    elif etype == "tool_result":
                        name = edata.get("name", "unknown")
                        # final_summary_tool 결과를 별도 SSE 이벤트로 전송
                        if name in ("final_summary_tool", "final_summary"):
                            result_data = edata.get("result", {})
                            tool_output = ensure_str(result_data.get("data", ""))
                            summary_data = safe_parse_json(tool_output) or {
                                "summary": tool_output,
                            }
                            self.write(
                                f"event: summary\ndata: {safe_json_dumps(summary_data)}\n\n",
                            )
                        self.write(
                            f"data: {json.dumps({'status': f'{name} 완료'})}\n\n",
                        )
                    elif etype == "stream":
                        content = edata.get("content", "")
                        if content:
                            self.write(f"data: {json.dumps({'content': content})}\n\n")
                    elif etype == "complete":
                        # Response was already streamed via 'stream' events,
                        # just send the completion signal.
                        self.write(
                            f"event: complete\ndata: {json.dumps({'thread_id': effective_thread_id})}\n\n",
                        )
                    elif etype == "hitl_request":
                        _hitl_pending = True
                        # hitl_request에 thread_id 보장
                        if "thread_id" not in edata:
                            edata["thread_id"] = effective_thread_id
                        hitl_json = json.dumps(edata)
                        logger.warning(
                            "HITL_SSE: sending hitl_request event, action=%s, data_len=%d, thread_id=%s",
                            edata.get("action", "?"),
                            len(hitl_json),
                            edata.get("thread_id", "?"),
                        )
                        self.write(f"event: hitl_request\ndata: {hitl_json}\n\n")
                    elif etype == "todos":
                        todos_list = edata.get("todos", [])
                        self.write(
                            f"event: todos\ndata: {json.dumps({'todos': todos_list})}\n\n",
                        )
                    elif etype == "debug_clear":
                        self.write(f"event: debug_clear\ndata: {json.dumps({})}\n\n")
                    elif etype == "done":
                        edata.setdefault("thread_id", effective_thread_id)
                        self.write(f"event: done\ndata: {json.dumps(edata)}\n\n")
                    elif etype == "cancelled":
                        edata.setdefault("thread_id", effective_thread_id)
                        self.write(f"event: cancelled\ndata: {json.dumps(edata)}\n\n")
                    elif etype == "error":
                        msg = edata.get("error", edata.get("message", "Unknown error"))
                        self.write(f"data: {json.dumps({'error': str(msg)})}\n\n")
                    else:
                        self.write(f"data: {json.dumps({'status': str(edata)})}\n\n")

                    await self.flush()
            finally:
                # hitl_request 대기 중이면 runner를 유지 + thread_metadata 저장
                if _hitl_pending:
                    _thread_metadata.setdefault(effective_thread_id, {})[
                        "emitted_contents"
                    ] = runner.emitted_content_hashes.copy()
                else:
                    _active_agents.pop(effective_thread_id, None)
                if not task.done():
                    task.cancel()

        except Exception as e:
            logger.error(f"LangChainStream error: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
        finally:
            self.finish()


def _transform_decisions_for_middleware(
    frontend_decisions: list,
    pending_tool_names: list[str] | None = None,
) -> list:
    """프론트엔드 decision → HumanInTheLoopMiddleware 포맷.

    Args:
        frontend_decisions: 프론트엔드에서 전달된 decision 목록
        pending_tool_names: 인터럽트된 도구 이름 목록 (state에서 추출)

    """
    result = []
    for i, d in enumerate(frontend_decisions):
        dtype = d.get("type", "approve")
        logger.debug(
            "TRANSFORM_DECISION: type=%s, keys=%s",
            dtype,
            list(d.keys()),
        )
        if dtype == "approve":
            result.append({"type": "approve"})
        elif dtype == "edit":
            args = d.get("args", {})
            exec_result = args.get("execution_result", {})
            logger.debug(
                "TRANSFORM_DECISION edit: args_keys=%s, exec_result_keys=%s, "
                "success=%s, error=%s",
                list(args.keys()) if isinstance(args, dict) else type(args),
                list(exec_result.keys())
                if isinstance(exec_result, dict)
                else type(exec_result),
                exec_result.get("success") if isinstance(exec_result, dict) else "N/A",
                exec_result.get("error", "")[:100]
                if isinstance(exec_result, dict)
                else "N/A",
            )
            if isinstance(exec_result, dict) and (
                exec_result.get("success") is False or exec_result.get("error")
            ):
                # 실행 실패 → reject로 변환하여 에러를 LLM에 전달
                logger.debug("TRANSFORM_DECISION: -> REJECT (execution failed)")
                result.append(
                    {
                        "type": "reject",
                        "message": json.dumps({"execution_result": exec_result}),
                    },
                )
            else:
                # 실행 성공 → edit (execution_result 포함하여 도구에 전달)
                tool_name = (
                    pending_tool_names[i]
                    if pending_tool_names and i < len(pending_tool_names)
                    else "jupyter_cell"
                )
                logger.debug(
                    "TRANSFORM_DECISION: -> EDIT (execution succeeded, tool=%s)",
                    tool_name,
                )
                result.append(
                    {
                        "type": "edit",
                        "edited_action": {"name": tool_name, "args": args},
                    },
                )
        elif dtype == "reject":
            result.append(
                {"type": "reject", "message": d.get("feedback", "User rejected")},
            )
        else:
            result.append({"type": "approve"})
    return result


class LangChainResumeHandler(APIHandler):
    """POST: resume agent after HITL decision with SSE streaming."""

    async def post(self):
        try:
            from langgraph.types import Command

            from .agent.agent_factory import _transform_interrupt_to_frontend

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            body = _inject_workspace_root(body, self.settings)

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            thread_id = body.get("threadId", "")
            decisions = body.get("decisions", [])
            _hitl_pending = False

            runner = _get_agent_runner(thread_id)
            if not runner:
                self.write(
                    f"data: {json.dumps({'error': '세션을 찾을 수 없습니다.', 'code': 'CHECKPOINT_NOT_FOUND'})}\n\n",
                )
                self.finish()
                return

            config = {
                "configurable": {"thread_id": thread_id},
                "recursion_limit": 1000,
            }

            # decisions 포맷 변환 + 딕셔너리로 감싸기
            # HumanInTheLoopMiddleware는 interrupt된 tool call 수만큼
            # decisions를 요구하므로, 프론트엔드가 보낸 단일 decision을
            # hanging tool call 개수에 맞게 확장.
            # 가장 신뢰할 수 있는 방법: agent state에서 직접 pending interrupt 수를 읽음
            actual_interrupt_count = 0
            pending_tool_names: list[str] = []
            try:
                pre_state = await runner.agent.aget_state(config)
                if pre_state.tasks:
                    for ts in pre_state.tasks:
                        if ts.interrupts:
                            hitl_val = ts.interrupts[0].value
                            if isinstance(hitl_val, dict):
                                action_requests = hitl_val.get("action_requests", [])
                                actual_interrupt_count = len(action_requests)
                                for ar in action_requests:
                                    pending_tool_names.append(ar.get("name", "unknown"))
                            break
            except Exception as exc:
                logger.warning("LangChainResume: aget_state failed: %s", exc)
            transformed = _transform_decisions_for_middleware(
                decisions,
                pending_tool_names,
            )
            # fallback: 프론트엔드가 보낸 actionCount 사용
            action_count = actual_interrupt_count or body.get("actionCount", 1)
            logger.warning(
                "LangChainResume: decisions=%d, actionCount=%d (actual=%d), transformed=%d",
                len(decisions),
                action_count,
                actual_interrupt_count,
                len(transformed),
            )
            if len(transformed) == 1 and action_count > 1:
                transformed = transformed * action_count
                logger.warning(
                    "LangChainResume: expanded to %d decisions",
                    len(transformed),
                )

            # 코드 히스토리 기록: edit + 성공한 실행 결과 추적
            try:
                from .agent.code_history_middleware import track_tool_execution

                for i, d in enumerate(decisions):
                    if d.get("type") == "edit":
                        args = d.get("args", {})
                        exec_result = args.get("execution_result", {})
                        exec_failed = isinstance(exec_result, dict) and (
                            exec_result.get("success") is False
                            or exec_result.get("error")
                        )
                        if not exec_failed:
                            tool_name = (
                                pending_tool_names[i]
                                if i < len(pending_tool_names)
                                else ""
                            )
                            if tool_name in ("jupyter_cell", "file_write"):
                                track_tool_execution(tool_name, args, thread_id)
            except Exception as exc:
                logger.debug("CodeHistory tracking failed: %s", exc)

            resume_value = {"decisions": transformed}

            import time as _time

            _resume_start = _time.monotonic()
            _RESUME_ABSOLUTE_TIMEOUT = 300  # 5분
            _resume_timed_out = False

            try:
                from .agent.agent_factory import (
                    _dbg,
                    _get_tool_status_message,
                    _repair_summary_json_content,
                )

                # reasoning filter: on_chat_model_start/end 버퍼링
                _stream_buffer: list[str] = []
                # Turn/step tracking for resume
                _iteration_r: int = (
                    runner.iteration if hasattr(runner, "iteration") else 0
                )
                _tool_count_r: int = (
                    runner._tool_count if hasattr(runner, "_tool_count") else 0
                )
                # Resume 시 dedup 복원
                _emitted_hashes: set = set()
                meta = _thread_metadata.get(thread_id, {})
                if "emitted_contents" in meta:
                    _emitted_hashes = meta["emitted_contents"].copy()
                # Auto-terminate 상태
                _last_todos_data: list = []
                _all_todos_completed: bool = False
                # Subagent tracking: task 도구 실행 중 서브에이전트 LLM 응답 필터링
                _inside_subagent: bool = False

                # 실행 재개 상태 메시지
                _dbg(
                    f"=== RESUME START === thread_id={thread_id} decisions={len(transformed)}",
                )
                self.write(
                    f"data: {json.dumps({'status': '실행 재개 중', 'icon': 'play'})}\n\n",
                )
                await self.flush()

                async for event in runner.agent.astream_events(
                    Command(resume=resume_value),
                    config=config,
                    version="v2",
                ):
                    # Cancel 체크: 사용자가 작업 중지 시 즉시 종료
                    if runner._is_cancelled:
                        _dbg("RESUME_CANCELLED: user cancelled, breaking loop")
                        self.write(
                            f"event: cancelled\ndata: {json.dumps({'threadId': thread_id})}\n\n",
                        )
                        await self.flush()
                        break

                    event_kind = event.get("event", "")
                    event_data = None
                    event_name = event.get("name", "")
                    logger.debug(
                        "RESUME_EVENT: kind=%s name=%s",
                        event_kind,
                        event_name,
                    )

                    # 주요 이벤트 디버그 로깅
                    if event_kind in (
                        "on_chat_model_start",
                        "on_chat_model_end",
                        "on_tool_start",
                        "on_tool_end",
                    ):
                        _dbg(
                            f"RESUME_EVENT: kind={event_kind} name={event_name} "
                            f"inside_subagent={_inside_subagent}",
                        )

                    if event_kind == "on_chat_model_start":
                        # 서브에이전트 내부 LLM은 무시
                        if _inside_subagent:
                            continue
                        _iteration_r += 1
                        _stream_buffer = []
                        self.write(
                            f"data: {json.dumps({'status': 'LLM 응답 대기 중', 'icon': 'thinking', 'turn': _iteration_r, 'step': _tool_count_r})}\n\n",
                        )
                        await self.flush()
                        continue

                    if event_kind == "on_chat_model_end":
                        # 서브에이전트 내부 LLM은 무시
                        if _inside_subagent:
                            continue
                        output_msg = event.get("data", {}).get("output", None)
                        if output_msg and hasattr(output_msg, "message"):
                            output_msg = output_msg.message
                        has_tool_calls = bool(
                            output_msg
                            and hasattr(output_msg, "tool_calls")
                            and output_msg.tool_calls,
                        )

                        # Resume 중 LLM 응답 로깅
                        if has_tool_calls and output_msg:
                            tc_summary = [
                                {
                                    "name": tc.get("name"),
                                    "args_keys": list(tc.get("args", {}).keys()),
                                }
                                for tc in output_msg.tool_calls
                            ]
                            _dbg(f"RESUME_LLM_END: tool_calls={tc_summary}")
                        elif output_msg:
                            content_preview = getattr(output_msg, "content", "")[:100]
                            _dbg(
                                f"RESUME_LLM_END: no_tool_calls content_preview={content_preview!r}",
                            )

                        # Summarization 감지
                        if output_msg and hasattr(output_msg, "additional_kwargs"):
                            if (output_msg.additional_kwargs or {}).get(
                                "lc_source",
                            ) == "summarization":
                                self.write(
                                    f"data: {json.dumps({'status': '대화가 자동으로 압축되었습니다.'})}\n\n",
                                )
                                await self.flush()

                        if has_tool_calls and output_msg:
                            # Tool calling content 제거 (context window 절약)
                            if getattr(output_msg, "content", ""):
                                try:
                                    output_msg.content = ""
                                except (AttributeError, TypeError):
                                    pass
                            # Premature summary 필터링
                            if _stream_buffer:
                                buf_check = "".join(_stream_buffer)
                                if (
                                    '"summary"' in buf_check
                                    and '"next_items"' in buf_check
                                ):
                                    non_todo_tools = [
                                        tc
                                        for tc in output_msg.tool_calls
                                        if tc.get("name") not in ("write_todos",)
                                    ]
                                    if non_todo_tools:
                                        _stream_buffer = []

                        if _stream_buffer and not has_tool_calls:
                            # tool_calls 없는 턴 → 최종 응답
                            buf = "".join(_stream_buffer)
                            if "assistantfinal" in buf:
                                buf = buf[
                                    buf.index("assistantfinal")
                                    + len("assistantfinal") :
                                ]
                            # JSON tool response 필터링
                            if buf:
                                stripped = buf.strip()
                                is_json_tool = (
                                    stripped.startswith('{"tool":')
                                    or stripped.startswith('{"status":')
                                    or '"pending_execution"' in stripped
                                )
                                if is_json_tool:
                                    buf = ""
                            # Summary JSON repair + content hash dedup
                            if buf:
                                buf = _repair_summary_json_content(buf)
                                content_hash = hash(buf)
                                if content_hash not in _emitted_hashes:
                                    _emitted_hashes.add(content_hash)
                                    event_data = json.dumps({"content": buf})
                                    logger.info(
                                        "RESUME_CONTENT: sending %d chars to frontend",
                                        len(buf),
                                    )
                                else:
                                    logger.info("RESUME_CONTENT: dedup skipped")
                            # Auto-terminate: summary 감지 후 자동 종료
                            if _all_todos_completed and buf:
                                if '"summary"' in buf and '"next_items"' in buf:
                                    self.write(
                                        f"event: debug_clear\ndata: {json.dumps({})}\n\n",
                                    )
                                    self.write(
                                        f"event: done\ndata: {json.dumps({'reason': 'all_todos_completed', 'thread_id': thread_id})}\n\n",
                                    )
                                    await self.flush()
                                    break
                        elif not _stream_buffer and not has_tool_calls and output_msg:
                            # List content 핸들링 (multimodal)
                            raw_content = getattr(output_msg, "content", "")
                            if isinstance(raw_content, list):
                                text_parts = []
                                for part in raw_content:
                                    if isinstance(part, str):
                                        text_parts.append(part)
                                    elif (
                                        isinstance(part, dict)
                                        and part.get("type") == "text"
                                    ):
                                        text_parts.append(part.get("text", ""))
                                buf = "".join(text_parts)
                            else:
                                buf = raw_content or ""
                            if buf:
                                content_hash = hash(buf)
                                if content_hash not in _emitted_hashes:
                                    _emitted_hashes.add(content_hash)
                                    event_data = json.dumps({"content": buf})
                        elif _stream_buffer and has_tool_calls:
                            logger.info(
                                "RESUME_CONTENT: discarding reasoning (%d chars, has_tool_calls)",
                                len("".join(_stream_buffer)),
                            )
                        _stream_buffer = []

                    elif event_kind == "on_chat_model_stream":
                        # 서브에이전트 내부 LLM 스트리밍은 무시
                        if _inside_subagent:
                            continue
                        chunk = event.get("data", {}).get("chunk", None)
                        if chunk and hasattr(chunk, "content") and chunk.content:
                            _stream_buffer.append(chunk.content)

                    elif event_kind == "on_tool_start":
                        tool_name = event.get("name", "unknown")
                        tool_input = event.get("data", {}).get("input", {}) or {}
                        if not isinstance(tool_input, dict):
                            tool_input = {}
                        # 서브에이전트 진입 추적
                        if tool_name == "task":
                            _inside_subagent = True
                        _tool_count_r += 1
                        # 도구별 한국어 상태 메시지
                        status_msg = _get_tool_status_message(tool_name, tool_input)
                        payload_progress_r: dict = {"status": status_msg["status"]}
                        if status_msg.get("icon"):
                            payload_progress_r["icon"] = status_msg["icon"]
                        payload_progress_r["turn"] = _iteration_r
                        payload_progress_r["step"] = _tool_count_r
                        if status_msg.get("label"):
                            payload_progress_r["tool_label"] = status_msg["label"]
                        self.write(f"data: {json.dumps(payload_progress_r)}\n\n")
                        await self.flush()

                        # 셀 생성 도구 + 멀티에이전트 도구만 tool_call SSE 전송
                        if tool_name in (
                            "jupyter_cell",
                            "jupyter_markdown",
                            "file_write",
                            "task",
                            "ask_user_tool",
                            "final_summary_tool",
                        ):
                            resume_payload: dict = {"tool": tool_name}
                            if tool_name == "jupyter_markdown":
                                resume_payload["content"] = tool_input.get(
                                    "content",
                                    "",
                                )
                            elif tool_name == "task":
                                resume_payload["agent_name"] = tool_input.get(
                                    "subagent_type",
                                    tool_input.get("agent_name", ""),
                                )
                                resume_payload["description"] = tool_input.get(
                                    "description",
                                    "",
                                )
                            elif tool_name == "final_summary_tool":
                                resume_payload["summary"] = tool_input.get(
                                    "summary",
                                    "",
                                )
                                resume_payload["next_items"] = tool_input.get(
                                    "next_items",
                                    [],
                                )
                            else:
                                resume_payload["code"] = tool_input.get("code", "")
                            self.write(
                                f"event: tool_call\ndata: {json.dumps(resume_payload)}\n\n",
                            )
                            await self.flush()
                        # write_todos → 즉시 todos SSE emit + auto-terminate 캡처
                        # 서브에이전트 내부 write_todos는 프론트엔드에 전송하지 않음
                        if (
                            tool_name == "write_todos"
                            and isinstance(tool_input, dict)
                            and not _inside_subagent
                        ):
                            todos_data = tool_input.get("todos", [])
                            _last_todos_data = todos_data
                            if todos_data:
                                self.write(
                                    f"event: todos\ndata: {json.dumps({'todos': todos_data})}\n\n",
                                )
                                await self.flush()
                        continue  # skip duplicate write below
                    elif event_kind == "on_tool_end":
                        tool_name = event.get("name", "unknown")
                        # 서브에이전트 이탈 추적
                        if tool_name == "task":
                            _inside_subagent = False
                        # final_summary_tool 결과를 별도 SSE 이벤트로 전송
                        if tool_name in (
                            "final_summary_tool",
                            "final_summary",
                        ):
                            tool_output = ensure_str(
                                event.get("data", {}).get("output", ""),
                            )
                            summary_data = safe_parse_json(tool_output) or {
                                "summary": tool_output,
                            }
                            self.write(
                                f"event: summary\ndata: {safe_json_dumps(summary_data)}\n\n",
                            )
                            await self.flush()
                        event_data = json.dumps(
                            {
                                "status": f"{tool_name} 완료",
                            },
                        )
                        # Auto-terminate: write_todos 완료 체크
                        if tool_name == "write_todos" and _last_todos_data:
                            all_completed = all(
                                t.get("status") == "completed"
                                for t in _last_todos_data
                                if isinstance(t, dict)
                            )
                            if all_completed and _last_todos_data:
                                _all_todos_completed = True

                    if event_data:
                        self.write(f"data: {event_data}\n\n")
                        await self.flush()

                    # 절대 타임아웃 체크
                    elapsed = _time.monotonic() - _resume_start
                    if elapsed > _RESUME_ABSOLUTE_TIMEOUT:
                        logger.error(
                            "LangChainResume absolute timeout exceeded (%.1fs)",
                            elapsed,
                        )
                        self.write(
                            f"data: {json.dumps({'error': 'Agent resume timeout (5 min)'})}\n\n",
                        )
                        _resume_timed_out = True
                        await self.flush()
                        break

                # Resume 후 체인된 인터럽트 감지
                _dbg("=== RESUME STREAM DONE === astream_events loop completed")
                logger.debug("RESUME_STREAM_DONE: astream_events loop completed")
                if not _resume_timed_out:
                    state = await runner.agent.aget_state(config)
                    logger.debug(
                        "RESUME_STATE: tasks=%d, next=%s",
                        len(state.tasks) if state.tasks else 0,
                        state.next if hasattr(state, "next") else "N/A",
                    )

                    # 최종 todos state emit (일관성 보장)
                    # 서브에이전트 실행 중 중단된 경우 오염된 todos 전송 방지
                    if not _inside_subagent:
                        state_values = state.values if hasattr(state, "values") else {}
                        final_todos = state_values.get("todos", [])
                        if final_todos:
                            serializable = [
                                {
                                    "content": t["content"]
                                    if isinstance(t, dict)
                                    else t.content,
                                    "status": t["status"]
                                    if isinstance(t, dict)
                                    else t.status,
                                }
                                for t in final_todos
                            ]
                            self.write(
                                f"event: todos\ndata: {json.dumps({'todos': serializable})}\n\n",
                            )
                            await self.flush()

                    if state.tasks:
                        for task_state in state.tasks:
                            if task_state.interrupts:
                                hitl_request = task_state.interrupts[0].value
                                hitl_event = _transform_interrupt_to_frontend(
                                    hitl_request,
                                    thread_id,
                                )
                                if "thread_id" not in hitl_event:
                                    hitl_event["thread_id"] = thread_id
                                _hitl_pending = True
                                _dbg(
                                    f"CHAINED_INTERRUPT: action={hitl_event.get('action')} "
                                    f"args_keys={list(hitl_event.get('args', {}).keys())}",
                                )
                                # HITL 대기 시 dedup 상태 저장
                                _thread_metadata.setdefault(thread_id, {})[
                                    "emitted_contents"
                                ] = _emitted_hashes.copy()
                                self.write(
                                    f"data: {json.dumps({'status': '사용자 승인 대기 중', 'icon': 'pause'})}\n\n",
                                )
                                self.write(
                                    f"event: hitl_request\ndata: {json.dumps(hitl_event)}\n\n",
                                )
                                await self.flush()
                                break

                    if not _hitl_pending:
                        # 인터럽트 없으면 정상 완료
                        logger.info(
                            "RESUME_COMPLETE: sending complete event for thread=%s",
                            thread_id,
                        )
                        self.write(f"event: debug_clear\ndata: {json.dumps({})}\n\n")
                        self.write(
                            f"event: complete\ndata: {json.dumps({'thread_id': thread_id})}\n\n",
                        )
                        await self.flush()

            except Exception as run_err:
                logger.error(f"LangChainResume run error: {run_err}", exc_info=True)
                self.write(f"data: {json.dumps({'error': str(run_err)})}\n\n")
                await self.flush()

        except Exception as e:
            logger.error(f"LangChainResume error: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
            await self.flush()
        finally:
            # hitl_pending이면 runner 유지, 아니면 정리
            if not _hitl_pending:
                _active_agents.pop(thread_id, None)
            if not self._finished:
                self.finish()


class LangChainCancelHandler(APIHandler):
    """POST: cancel running agent."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            thread_id = body.get("threadId", "")

            runner = _get_agent_runner(thread_id)
            if runner:
                runner.cancel()
                # Cancel 시 todo_active 리셋
                try:
                    config = {"configurable": {"thread_id": thread_id}}
                    runner.agent.update_state(config, {"todo_active": False})
                except Exception:
                    pass
                _active_agents.pop(thread_id, None)
                self.write({"status": "cancelled", "threadId": thread_id})
            else:
                self.write({"status": "not_found", "threadId": thread_id})
        except Exception as e:
            logger.error(f"LangChainCancel error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class LangChainResetHandler(APIHandler):
    """POST: reset agent session."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            thread_id = body.get("threadId", "")

            runner = _get_agent_runner(thread_id)
            if runner:
                runner.cancel()
                _active_agents.pop(thread_id, None)
            _thread_metadata.pop(thread_id, None)
            # global checkpointer에서 해당 thread 데이터 제거
            try:
                storage = getattr(_global_checkpointer, "storage", {})
                storage.pop(thread_id, None)
            except Exception:
                pass

            self.write({"status": "reset", "threadId": thread_id})
        except Exception as e:
            logger.error(f"LangChainReset error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class LangChainHealthHandler(APIHandler):
    """GET: agent health status."""

    async def get(self):
        try:
            self.write(
                {
                    "status": "healthy",
                    "active_agents": len(_active_agents),
                    "agent_threads": list(_active_agents.keys()),
                },
            )
        except Exception as e:
            logger.error(f"LangChainHealth error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Context Autocomplete Handler ============


class ContextAutocompleteHandler(APIHandler):
    """GET: @file and command autocomplete."""

    async def get(self):
        try:
            partial_command = self.get_argument("partialCommand", default=None)
            base_dir = self.get_argument("baseDir", default=None)

            server_root = self.settings.get("server_root_dir", os.getcwd())
            base_directory = base_dir or os.path.expanduser(server_root)

            # Available providers
            providers = {
                "@file": {
                    "id": "@file",
                    "description": "파일 내용을 프롬프트에 포함",
                    "requires_arg": True,
                    "only_start": False,
                },
                "/reset": {
                    "id": "/reset",
                    "description": "세션 초기화 및 에이전트 리셋",
                    "requires_arg": False,
                    "only_start": False,
                },
                "/help": {
                    "id": "/help",
                    "description": "도움말 및 사용 가이드",
                    "requires_arg": False,
                    "only_start": False,
                },
                "/version": {
                    "id": "/version",
                    "description": "현재 Codebuff 버전 정보",
                    "requires_arg": False,
                    "only_start": False,
                },
                "/review": {
                    "id": "/review",
                    "description": "코드리뷰 (/review 또는 /review @file:경로)",
                    "requires_arg": False,
                    "only_start": True,
                },
                "/unittest": {
                    "id": "/unittest",
                    "description": "파일 기반 유닛테스트 생성 (/unittest @file:경로)",
                    "requires_arg": False,
                    "only_start": True,
                },
                "/create-notebook": {
                    "id": "/create-notebook",
                    "description": "프롬프트로 노트북 자동생성",
                    "requires_arg": False,
                    "only_start": True,
                },
                "@notebook": {
                    "id": "@notebook",
                    "description": "현재 노트북 전체 내용 포함",
                    "requires_arg": False,
                    "only_start": False,
                },
                "@cell": {
                    "id": "@cell",
                    "description": "선택된 셀 코드 포함",
                    "requires_arg": False,
                    "only_start": False,
                },
                "@error": {
                    "id": "@error",
                    "description": "최근 에러 내용 포함",
                    "requires_arg": False,
                    "only_start": False,
                },
                "@eda-agent": {
                    "id": "@eda-agent",
                    "description": "EDA Agent를 열고 프롬프트를 바로 실행합니다",
                    "requires_arg": True,
                    "only_start": True,
                },
            }

            if not partial_command:
                options = []
                for p in providers.values():
                    label = f"{p['id']}:" if p["requires_arg"] else p["id"]
                    options.append(
                        {
                            "id": p["id"],
                            "label": label,
                            "description": p["description"],
                            "only_start": p["only_start"],
                            "is_complete": not p["requires_arg"],
                        },
                    )
                self.write({"options": options})
                return

            if ":" not in partial_command:
                options = []
                for cmd_id, p in providers.items():
                    if cmd_id.startswith(partial_command):
                        label = f"{p['id']}:" if p["requires_arg"] else p["id"]
                        options.append(
                            {
                                "id": p["id"],
                                "label": label,
                                "description": p["description"],
                                "only_start": p["only_start"],
                                "is_complete": not p["requires_arg"],
                            },
                        )
                self.write({"options": options})
                return

            cmd_id, _, arg_prefix = partial_command.partition(":")

            if cmd_id == "@file":
                # File autocomplete — uses FileIndex for both prefix and fuzzy
                from .tools.file_finder import FileIndex

                SUPPORTED_EXTS = {
                    ".py",
                    ".md",
                    ".txt",
                    ".json",
                    ".yaml",
                    ".yml",
                    ".toml",
                    ".ini",
                    ".cfg",
                    ".sh",
                    ".bash",
                    ".ipynb",
                    ".js",
                    ".ts",
                    ".jsx",
                    ".tsx",
                    ".html",
                    ".css",
                    ".scss",
                    ".sql",
                    ".r",
                    ".R",
                    ".Rmd",
                    ".jl",
                    ".csv",
                    ".xml",
                    ".env",
                    ".gitignore",
                    ".dockerignore",
                    ".tex",
                }

                file_index = FileIndex(base_directory)

                # Determine search mode:
                # - trailing slash or <=1 char → prefix search (dir browsing)
                # - 2+ chars without trailing slash → fuzzy search
                use_fuzzy = (
                    not arg_prefix.endswith("/")
                    and len(arg_prefix) >= 2
                    and not os.path.isabs(arg_prefix)
                )

                if use_fuzzy:
                    results = file_index.fuzzy_search(
                        query=arg_prefix,
                        max_results=20,
                        supported_exts=SUPPORTED_EXTS,
                    )
                else:
                    results = file_index.prefix_search(
                        prefix=arg_prefix,
                        max_results=20,
                        supported_exts=SUPPORTED_EXTS,
                    )

                options = []
                for r in results:
                    is_dir = r["type"] == "directory"
                    display_path = r["path"]
                    label_path = display_path + "/" if is_dir else display_path
                    if " " in label_path:
                        label_path = f"'{label_path}'"

                    option: dict = {
                        "id": "@file",
                        "label": f"@file:{label_path}",
                        "description": "디렉토리" if is_dir else "파일",
                        "only_start": False,
                        "is_complete": not is_dir,
                    }
                    if use_fuzzy:
                        option["score"] = r["score"]
                    options.append(option)

                self.write({"options": options})
            elif cmd_id in providers and not providers[cmd_id]["requires_arg"]:
                p = providers[cmd_id]
                self.write(
                    {
                        "options": [
                            {
                                "id": p["id"],
                                "label": p["id"],
                                "description": p["description"],
                                "only_start": p["only_start"],
                                "is_complete": True,
                            },
                        ],
                    },
                )
            else:
                self.write({"options": []})

        except Exception as e:
            logger.error(f"ContextAutocomplete error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Remaining Embedded Handlers ============


class AgentReflectHandler(APIHandler):
    """POST: agent reflection via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.reflect(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"AgentReflect error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentVerifyStateHandler(APIHandler):
    """POST: agent state verification via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.verify_state(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"AgentVerifyState error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AgentPlanStreamHandler(APIHandler):
    """POST: plan generation with SSE streaming via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()

            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")
            self.set_header("X-Accel-Buffering", "no")

            async for chunk in agent_service.plan_stream(body):
                data = json.dumps(chunk) if isinstance(chunk, dict) else chunk
                self.write(f"data: {data}\n\n")
                await self.flush()

        except Exception as e:
            logger.error(f"AgentPlanStream error: {e}", exc_info=True)
            self.write(f"data: {json.dumps({'error': str(e)})}\n\n")
        finally:
            self.finish()


class CellActionHandler(APIHandler):
    """POST: cell action execution via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.cell_action(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"CellAction error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class FileActionHandler(APIHandler):
    """POST: file action execution via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.file_action(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"FileAction error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class FileResolveHandler(APIHandler):
    """POST: resolve file path in workspace."""

    async def post(self):
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )

            # Convert notebookDir to absolute path
            if body.get("notebookDir"):
                server_root = self.settings.get("server_root_dir", os.getcwd())
                server_root = os.path.expanduser(server_root)
                notebook_dir = body["notebookDir"]
                if not os.path.isabs(notebook_dir):
                    body["notebookDir"] = os.path.join(server_root, notebook_dir)

            factory = _get_service_factory()
            agent_service = factory.get_agent_service()
            result = await agent_service.file_resolve(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"FileResolve error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class FileSelectHandler(APIHandler):
    """POST: file selection via ServiceFactory."""

    async def post(self):
        try:
            factory = _get_service_factory()
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            agent_service = factory.get_agent_service()
            result = await agent_service.file_select(body)
            self.write(result.model_dump() if hasattr(result, "model_dump") else result)
        except Exception as e:
            logger.error(f"FileSelect error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class SearchWorkspaceHandler(APIHandler):
    """Handler for /search-workspace endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute workspace search."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            pattern = (body.get("pattern") or "").strip()
            file_types = body.get("file_types") or ["*.py", "*.ipynb"]
            path = body.get("path") or "."
            max_results = body.get("max_results", 50)
            case_sensitive = bool(body.get("case_sensitive", False))
            user_workspace_root = body.get("workspaceRoot")

            if not pattern:
                self.set_status(400)
                self.write({"error": "pattern is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                _execute_search_workspace,
                pattern,
                file_types,
                path,
                max_results,
                case_sensitive,
                workspace_root,
            )

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Search workspace failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class SearchNotebookCellsHandler(APIHandler):
    """Handler for /search-notebook-cells endpoint (runs on Jupyter server)."""

    async def post(self):
        """Execute notebook cells search."""
        try:
            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            pattern = (body.get("pattern") or "").strip()
            notebook_path = body.get("notebook_path")
            cell_type = body.get("cell_type")
            max_results = body.get("max_results", 30)
            case_sensitive = bool(body.get("case_sensitive", False))
            user_workspace_root = body.get("workspaceRoot")

            if not pattern:
                self.set_status(400)
                self.write({"error": "pattern is required"})
                return

            server_root = self.settings.get("server_root_dir", os.getcwd())
            server_root = os.path.expanduser(server_root)
            workspace_root = _get_effective_workspace_root(
                server_root,
                user_workspace_root,
            )

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                _execute_search_notebook_cells,
                pattern,
                notebook_path,
                cell_type,
                max_results,
                case_sensitive,
                workspace_root,
            )

            self.set_header("Content-Type", "application/json")
            self.write(result)

        except Exception as e:
            logger.error(f"Search notebook cells failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class RAGReindexHandler(APIHandler):
    """Handler for /rag/reindex endpoint using ServiceFactory."""

    async def post(self):
        """Trigger reindex operation."""
        try:
            factory = _get_service_factory()
            rag_service = factory.get_rag_service()

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            force = body.get("force", False)

            response = await rag_service.trigger_reindex(force=force)

            self.set_header("Content-Type", "application/json")
            self.write(response)

        except Exception as e:
            logger.error(f"RAG reindex failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ============ Idle Status / Shutdown Handler ============


class IdleStatusHandler(APIHandler):
    """서버사이드 idle 상태 반환. 터미널 프로세스 감지 포함."""

    async def get(self):
        """터미널/커널 활동 기반 idle 상태 반환."""
        try:
            monitor = self.settings.get("hdsp_idle_monitor")
            if monitor:
                status = monitor.get_idle_status()
                self.write(status)
            else:
                self.write(
                    {
                        "idle": True,
                        "idle_seconds": 0,
                        "timeout_seconds": 0,
                        "monitor": False,
                    }
                )
        except Exception as e:
            logger.error("[IdleStatus] Error: %s", e)
            self.set_status(500)
            self.write({"error": str(e)})


class IdleShutdownHandler(APIHandler):
    """Handler for idle timeout shutdown - calls HDSP API from server side."""

    @property
    def hdsp_env(self) -> str | None:
        return os.environ.get("HDSP_ENV")

    @property
    def hdsp_prj_id(self) -> str | None:
        return os.environ.get("HDSP_PRJ_ID")

    @property
    def jupyterhub_user(self) -> str | None:
        return os.environ.get("JUPYTERHUB_USER")

    async def post(self):
        """Trigger idle shutdown by calling HDSP API."""
        try:
            # Log idle shutdown event (client-triggered)
            try:
                body = (
                    json.loads(self.request.body.decode("utf-8"))
                    if self.request.body
                    else {}
                )
            except Exception:
                body = {}
            from .log_paths import write_idle_shutdown_log

            write_idle_shutdown_log(
                idle_seconds=body.get("idle_seconds", 0),
                timeout_setting=body.get("timeout_setting", 0),
                trigger_source="client",
            )

            hdsp_env = self.hdsp_env
            project_id = self.hdsp_prj_id
            user_id = self.jupyterhub_user

            # Check required environment variables
            if not hdsp_env or not project_id or not user_id:
                logger.warning(
                    f"[IdleShutdown] Missing env vars: HDSP_ENV={hdsp_env}, "
                    f"HDSP_PRJ_ID={project_id}, JUPYTERHUB_USER={user_id}",
                )
                self.set_status(400)
                self.write(
                    {
                        "success": False,
                        "error": "Missing required environment variables",
                        "details": {
                            "HDSP_ENV": hdsp_env is not None,
                            "HDSP_PRJ_ID": project_id is not None,
                            "JUPYTERHUB_USER": user_id is not None,
                        },
                    },
                )
                return

            # Build API URL based on environment
            if hdsp_env == "dev":
                api_base_url = "https://hdsp-api-dev.hyundaicard.com"
            elif hdsp_env == "prod":
                api_base_url = "https://hdsp-api.hyundaicard.com"
            else:
                logger.warning(f"[IdleShutdown] Unknown HDSP_ENV: {hdsp_env}")
                self.set_status(400)
                self.write(
                    {"success": False, "error": f"Unknown HDSP_ENV value: {hdsp_env}"},
                )
                return

            api_url = f"{api_base_url}/k8s/jupyter/{project_id}/{user_id}"
            logger.info(f"[IdleShutdown] Calling shutdown API: {api_url}")

            # Call DELETE API
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.delete(api_url)

            if response.status_code in (200, 204):
                logger.info("[IdleShutdown] Shutdown API call successful")
                self.write(
                    {
                        "success": True,
                        "message": "Shutdown initiated",
                        "api_url": api_url,
                    },
                )
            else:
                logger.error(
                    f"[IdleShutdown] API call failed: {response.status_code} {response.text}",
                )
                self.set_status(response.status_code)
                self.write(
                    {
                        "success": False,
                        "error": f"API call failed: {response.status_code}",
                        "details": response.text,
                    },
                )

        except httpx.TimeoutException:
            logger.error("[IdleShutdown] API call timeout")
            self.set_status(504)
            self.write({"success": False, "error": "API call timeout"})
        except Exception as e:
            logger.error(f"[IdleShutdown] Error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"success": False, "error": str(e)})


# ============ Handler Setup ============


def _get_websocket_handler_entry(base_url: str) -> list:
    """Return [(url, AgentWebSocketHandler)] or [] if deepagents is unavailable."""
    try:
        from .handlers.websocket import AgentWebSocketHandler as _WS

        return [(url_path_join(base_url, "hdsp-agent", "agent", "ws"), _WS)]
    except Exception as e:
        logger.warning("AgentWebSocketHandler unavailable (deepagents missing?): %s", e)
        return []


# ============ Analytics Aggregation Handler ============

# Global progress state for analytics aggregation
_analytics_progress: dict = {}


class AnalyticsAggregateHandler(APIHandler):
    """POST: 분석 리포트 생성 (JSONL → CSV). 관리자 전용."""

    async def post(self):
        global _analytics_progress
        try:
            is_admin, _ = _is_admin_mode()
            if not is_admin:
                self.set_status(403)
                self.write({"error": "Admin only"})
                return

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            input_dir = body.get("inputDir", "")
            output_dir = body.get("outputDir", "")
            date_from = body.get("dateFrom") or None
            date_to = body.get("dateTo") or None

            if not input_dir:
                self.set_status(400)
                self.write({"error": "inputDir is required"})
                return

            from pathlib import Path

            input_path = Path(input_dir)
            if not input_path.is_dir():
                self.set_status(400)
                self.write({"error": f"Directory not found: {input_dir}"})
                return

            output_path = Path(output_dir) if output_dir else input_path / "reports"
            output_path.mkdir(parents=True, exist_ok=True)

            # Reset progress
            _analytics_progress = {
                "status": "running",
                "current": 0,
                "total": 8,
                "step": "초기화 중...",
            }

            import asyncio

            asyncio.ensure_future(
                self._run_aggregation(input_path, output_path, date_from, date_to)
            )

            self.write(
                {
                    "success": True,
                    "message": "리포트 생성 시작",
                    "outputDir": str(output_path),
                }
            )
        except Exception as e:
            logger.error(f"AnalyticsAggregate error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})

    @staticmethod
    async def _run_aggregation(input_path, output_path, date_from, date_to):
        """백그라운드에서 집계 실행."""
        global _analytics_progress
        import asyncio

        try:
            from hdsp_agent_core.services.analytics_aggregate import (
                _read_jsonl_files,
                aggregate_active_users,
                aggregate_agent_frequency,
                aggregate_feature_preference,
                aggregate_errors,
                aggregate_cell_attribution,
                aggregate_codebuff_users,
                aggregate_codebuff_feature_mix,
                aggregate_codebuff_utilization,
            )

            # Step 0: Read JSONL
            _analytics_progress = {
                "status": "running",
                "current": 0,
                "total": 8,
                "step": "JSONL 파일 읽는 중...",
            }
            await asyncio.sleep(0)  # yield to event loop

            impressions = _read_jsonl_files(input_path, "analytics_impression_")
            clicks = _read_jsonl_files(input_path, "analytics_click_")
            errors = _read_jsonl_files(input_path, "analytics_error_")
            structured = _read_jsonl_files(input_path, "agent_structured")

            file_counts = f"impressions={len(impressions)}, clicks={len(clicks)}, errors={len(errors)}, structured={len(structured)}"
            reports = []

            steps = [
                (
                    "A1_active_users",
                    "DAU/MAU 집계 중...",
                    lambda: aggregate_active_users(
                        impressions, clicks, date_from, date_to
                    ),
                ),
                (
                    "A2_agent_frequency",
                    "사용 빈도 집계 중...",
                    lambda: aggregate_agent_frequency(clicks, date_from, date_to),
                ),
                (
                    "A3_feature_preference",
                    "기능별 사용량 집계 중...",
                    lambda: aggregate_feature_preference(clicks, date_from, date_to),
                ),
                (
                    "A4_errors",
                    "에러 집계 중...",
                    lambda: aggregate_errors(errors, structured, date_from, date_to),
                ),
                (
                    "A5_cell_attribution",
                    "셀 기여율 집계 중...",
                    lambda: aggregate_cell_attribution(
                        impressions, clicks, date_from, date_to
                    ),
                ),
                (
                    "A6_codebuff_users",
                    "Codebuff 사용자 집계 중...",
                    lambda: aggregate_codebuff_users(
                        impressions, clicks, date_from, date_to
                    ),
                ),
                (
                    "A7_codebuff_feature_mix",
                    "기능 비중 집계 중...",
                    lambda: aggregate_codebuff_feature_mix(clicks, date_from, date_to),
                ),
                (
                    "A8_codebuff_utilization",
                    "활용률 집계 중...",
                    lambda: aggregate_codebuff_utilization(
                        impressions, clicks, date_from, date_to
                    ),
                ),
            ]

            for i, (name, step_label, fn) in enumerate(steps):
                _analytics_progress = {
                    "status": "running",
                    "current": i,
                    "total": 8,
                    "step": step_label,
                }
                await asyncio.sleep(0)

                df = fn()
                csv_path = output_path / f"{name}.csv"
                df.to_csv(csv_path, index=False)
                reports.append({"name": f"{name}.csv", "rows": len(df)})

            _analytics_progress = {
                "status": "done",
                "current": 8,
                "total": 8,
                "step": "완료",
                "reports": reports,
                "fileCounts": file_counts,
                "outputDir": str(output_path),
            }
        except Exception as e:
            logger.error(f"Analytics aggregation error: {e}", exc_info=True)
            _analytics_progress = {"status": "error", "step": str(e)}


class AnalyticsReadCsvHandler(APIHandler):
    """POST: CSV 파일 읽어서 JSON 배열로 반환. 관리자 전용."""

    async def post(self):
        try:
            is_admin, _ = _is_admin_mode()
            if not is_admin:
                self.set_status(403)
                self.write({"error": "Admin only"})
                return

            body = (
                json.loads(self.request.body.decode("utf-8"))
                if self.request.body
                else {}
            )
            file_path = body.get("filePath", "")
            if not file_path:
                self.set_status(400)
                self.write({"error": "filePath is required"})
                return

            import csv as csv_mod
            from pathlib import Path

            p = Path(file_path)
            if not p.exists():
                self.set_status(404)
                self.write({"error": f"File not found: {file_path}"})
                return

            rows = []
            with open(p, encoding="utf-8-sig") as f:
                reader = csv_mod.DictReader(f)
                headers = reader.fieldnames or []
                for row in reader:
                    rows.append(dict(row))

            self.write({"headers": headers, "rows": rows, "total": len(rows)})
        except Exception as e:
            logger.error(f"AnalyticsReadCsv error: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


class AnalyticsProgressHandler(APIHandler):
    """GET: 분석 리포트 생성 진행 상황."""

    async def get(self):
        self.write(_analytics_progress or {"status": "idle"})


class _IdleResetMixin:
    """Mixin that resets server-side idle monitor on user-initiated requests.

    GET 요청은 폴링/자동 요청일 수 있으므로 idle 리셋하지 않는다.
    POST/PUT/DELETE 등 사용자 명시적 행동만 idle을 리셋한다.
    """

    def prepare(self):
        monitor = self.settings.get("hdsp_idle_monitor")
        if monitor and self.request.method not in ("GET", "HEAD", "OPTIONS"):
            monitor.reset()
        return super().prepare()


def setup_handlers(web_app):
    """Register all handlers based on execution mode."""
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]

    handlers = [
        # Health check
        (url_path_join(base_url, "hdsp-agent", "health"), HealthHandler),
        # Config endpoints (embedded)
        (url_path_join(base_url, "hdsp-agent", "config"), ConfigHandler),
        (
            url_path_join(base_url, "hdsp-agent", "config", "prompts"),
            ConfigPromptsHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "is-admin"),
            ConfigIsAdminHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "admin"),
            ConfigAdminHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "user"),
            ConfigUserHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "config", "codebuff-status"),
            CodebuffStatusHandler,
        ),
        # ===== ServiceFactory-based handlers =====
        # Agent endpoints
        (url_path_join(base_url, "hdsp-agent", "auto-agent", "plan"), AgentPlanHandler),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "refine"),
            AgentRefineHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "replan"),
            AgentReplanHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "validate"),
            AgentValidateHandler,
        ),
        # Chat endpoints
        (url_path_join(base_url, "hdsp-agent", "chat", "message"), ChatMessageHandler),
        (url_path_join(base_url, "hdsp-agent", "chat", "stream"), ChatStreamHandler),
        # LangChain agent endpoints (embedded)
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "stream"),
            LangChainStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "resume"),
            LangChainResumeHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "health"),
            LangChainHealthHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "cancel"),
            LangChainCancelHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "agent", "langchain", "reset"),
            LangChainResetHandler,
        ),
        # Shell command execution (server-side, approval required)
        (
            url_path_join(base_url, "hdsp-agent", "execute-command"),
            ExecuteCommandHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "execute-command", "stream"),
            ExecuteCommandStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "resource-usage"),
            ResourceUsageHandler,
        ),
        # Resource check for data processing (server-side, auto-approved)
        (
            url_path_join(base_url, "hdsp-agent", "check-resource"),
            CheckResourceHandler,
        ),
        # File read/write execution (server-side)
        (url_path_join(base_url, "hdsp-agent", "read-file"), ReadFileHandler),
        (url_path_join(base_url, "hdsp-agent", "write-file"), WriteFileHandler),
        # Search endpoints (server-side, no approval required)
        (
            url_path_join(base_url, "hdsp-agent", "search-workspace"),
            SearchWorkspaceHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "search-notebook-cells"),
            SearchNotebookCellsHandler,
        ),
        # RAG endpoints
        (url_path_join(base_url, "hdsp-agent", "rag", "search"), RAGSearchHandler),
        (url_path_join(base_url, "hdsp-agent", "rag", "status"), RAGStatusHandler),
        (url_path_join(base_url, "hdsp-agent", "rag", "reindex"), RAGReindexHandler),
        # RAG Admin endpoints
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "config"),
            _RAGAdminConfigHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "test-connection"),
            _RAGAdminTestConnectionHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "stats"),
            _RAGAdminStatsHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "upsert"),
            _RAGAdminUpsertHandler,
        ),
        (
            url_path_join(
                base_url, "hdsp-agent", "rag", "admin", "collection", r"([^/]+)"
            ),
            _RAGAdminDeleteHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "preview"),
            _RAGAdminPreviewHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "dry-run"),
            _RAGAdminDryRunHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "validate"),
            _RAGAdminValidateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "browse", r"([^/]+)"),
            _RAGAdminBrowseHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "search-test"),
            _RAGAdminSearchTestHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "history"),
            _RAGAdminHistoryHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "progress"),
            _RAGAdminProgressHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "cancel"),
            _RAGAdminCancelHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "guide-pipeline"),
            _RAGAdminGuidePipelineHandler,
        ),
        (
            url_path_join(
                base_url, "hdsp-agent", "rag", "admin", "guide-pipeline", "status"
            ),
            _RAGAdminGuidePipelineStatusHandler,
        ),
        # Codebase indexing endpoints
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "codebase"),
            _RAGAdminCodebaseHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "rag", "admin", "codebase", "status"),
            _RAGAdminCodebaseStatusHandler,
        ),
        (
            url_path_join(
                base_url, "hdsp-agent", "rag", "admin", "codebase", "watcher"
            ),
            _RAGAdminCodebaseWatcherHandler,
        ),
        # Idle status & shutdown endpoint (server-side)
        (
            url_path_join(base_url, "hdsp-agent", "idle-status"),
            IdleStatusHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "idle-shutdown"),
            IdleShutdownHandler,
        ),
        # Analytics aggregation
        (
            url_path_join(base_url, "hdsp-agent", "analytics", "aggregate"),
            AnalyticsAggregateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "analytics", "progress"),
            AnalyticsProgressHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "analytics", "read-csv"),
            AnalyticsReadCsvHandler,
        ),
        # WebSocket handler for ReAct Agent (lazy import: requires deepagents)
        *_get_websocket_handler_entry(base_url),
        # Embedded handlers (previously proxied to agent-server)
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "reflect"),
            AgentReflectHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "verify-state"),
            AgentVerifyStateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "auto-agent", "plan", "stream"),
            AgentPlanStreamHandler,
        ),
        # Cell/File action endpoints (embedded)
        (
            url_path_join(base_url, "hdsp-agent", "cell", "action"),
            CellActionHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "action"),
            FileActionHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "resolve"),
            FileResolveHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "select"),
            FileSelectHandler,
        ),
        # Context provider endpoints (@file autocomplete, embedded)
        (
            url_path_join(base_url, "hdsp-agent", "context", "autocomplete"),
            ContextAutocompleteHandler,
        ),
        # Notebook endpoints
        (
            url_path_join(base_url, "hdsp-agent", "notebook", "enrich"),
            NotebookEnrichHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "file", "enrich"),
            FileEnrichHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "notebook", "generate"),
            NotebookGenerateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "query", "stream"),
            AthenaQueryStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "candidates"),
            AthenaCandidatesHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "table-columns"),
            AthenaTableColumnsHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "execute"),
            AthenaExecuteHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "status", r"([^/]+)"),
            AthenaStatusHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "stop", r"([^/]+)"),
            AthenaStopHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "results", r"([^/]+)"),
            AthenaResultsHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "athena", "download", r"([^/]+)"),
            AthenaDownloadHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "task", r"([^/]+)", "status"),
            TaskStatusHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "task", r"([^/]+)", "stream"),
            TaskStreamHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "task", r"([^/]+)", "cancel"),
            TaskCancelHandler,
        ),
        # Benchmark
        (
            url_path_join(base_url, "hdsp-agent", "benchmark", "test-cases"),
            BenchmarkTestCasesHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "benchmark", "generate"),
            BenchmarkGenerateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "benchmark", "sources"),
            BenchmarkSourcesHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "benchmark", "run"),
            BenchmarkRunHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "benchmark", "results"),
            BenchmarkResultsHandler,
        ),
        # EDA Benchmark
        (
            url_path_join(base_url, "hdsp-agent", "eda-benchmark", "test-cases"),
            EdaBenchmarkTestCasesHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "eda-benchmark", "generate"),
            EdaBenchmarkGenerateHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "eda-benchmark", "sources"),
            EdaBenchmarkSourcesHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "eda-benchmark", "run"),
            EdaBenchmarkRunHandler,
        ),
        (
            url_path_join(base_url, "hdsp-agent", "eda-benchmark", "results"),
            EdaBenchmarkResultsHandler,
        ),
        # Analytics events
        (
            url_path_join(base_url, "hdsp-agent", "analytics", "events"),
            AnalyticsEventsHandler,
        ),
    ]

    # 모든 핸들러에 idle reset mixin 주입
    patched = []
    for entry in handlers:
        url_pattern = entry[0]
        handler_cls = entry[1]
        rest = entry[2:]
        # _IdleResetMixin을 동적으로 주입 (WebSocket 핸들러 제외)
        if (
            issubclass(handler_cls, APIHandler)
            and _IdleResetMixin not in handler_cls.__mro__
        ):
            handler_cls = type(handler_cls.__name__, (_IdleResetMixin, handler_cls), {})
        patched.append((url_pattern, handler_cls, *rest))

    web_app.add_handlers(host_pattern, patched)
