"""EDA Agent Benchmark Handler — 테스트 케이스 관리, 벤치마크 실행, 결과 조회."""

from __future__ import annotations

import json
import logging
import time
import uuid
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from jupyter_server.base.handlers import APIHandler

logger = logging.getLogger(__name__)

# 벤치마크 데이터 저장 경로
_EDA_BENCHMARK_DIR = Path.home() / ".hdsp_agent" / "eda_benchmark"
_TEST_CASES_FILE = _EDA_BENCHMARK_DIR / "test_cases.json"
_RESULTS_DIR = _EDA_BENCHMARK_DIR / "results"


def _ensure_dirs():
    _EDA_BENCHMARK_DIR.mkdir(parents=True, exist_ok=True)
    _RESULTS_DIR.mkdir(parents=True, exist_ok=True)


def _load_test_cases() -> List[Dict[str, Any]]:
    _ensure_dirs()
    if _TEST_CASES_FILE.exists():
        try:
            return json.loads(_TEST_CASES_FILE.read_text(encoding="utf-8"))
        except Exception:
            return []
    return []


def _save_test_cases(cases: List[Dict[str, Any]]):
    _ensure_dirs()
    _TEST_CASES_FILE.write_text(
        json.dumps(cases, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def _load_results() -> List[Dict[str, Any]]:
    _ensure_dirs()
    results = []
    for f in sorted(_RESULTS_DIR.glob("*.json"), reverse=True):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            results.append(
                {
                    "id": f.stem,
                    "date": data.get("date", ""),
                    "memo": data.get("memo", ""),
                    "total_cases": data.get("total_cases", 0),
                    "summary": data.get("summary", {}),
                }
            )
        except Exception:
            continue
    return results


def _load_result_detail(result_id: str) -> Optional[Dict[str, Any]]:
    path = _RESULTS_DIR / f"{result_id}.json"
    if path.exists():
        return json.loads(path.read_text(encoding="utf-8"))
    return None


def _save_result(result: Dict[str, Any]) -> str:
    _ensure_dirs()
    result_id = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    path = _RESULTS_DIR / f"{result_id}.json"
    result["id"] = result_id
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    return result_id


# ─── Test Cases CRUD ───


class EdaBenchmarkTestCasesHandler(APIHandler):
    """GET/POST /hdsp-agent/eda-benchmark/test-cases"""

    async def get(self):
        self.write(json.dumps(_load_test_cases(), ensure_ascii=False))

    async def post(self):
        body = (
            json.loads(self.request.body.decode("utf-8")) if self.request.body else {}
        )
        action = body.get("action", "save_all")

        if action == "save_all":
            cases = body.get("test_cases", [])
            _save_test_cases(cases)
            self.write({"status": "ok", "count": len(cases)})
        elif action == "add":
            cases = _load_test_cases()
            new_case = body.get("test_case", {})
            if not new_case.get("id"):
                new_case["id"] = f"eda_{uuid.uuid4().hex[:8]}"
            cases.append(new_case)
            _save_test_cases(cases)
            self.write({"status": "ok", "id": new_case["id"]})
        elif action == "delete":
            tc_id = body.get("id")
            cases = [c for c in _load_test_cases() if c.get("id") != tc_id]
            _save_test_cases(cases)
            self.write({"status": "ok"})
        elif action == "update":
            tc_id = body.get("id")
            updated = body.get("test_case", {})
            cases = _load_test_cases()
            for i, c in enumerate(cases):
                if c.get("id") == tc_id:
                    cases[i] = {**c, **updated}
                    break
            _save_test_cases(cases)
            self.write({"status": "ok"})


# ─── Sources (bdp_tables 목록) ───


class EdaBenchmarkSourcesHandler(APIHandler):
    """GET /hdsp-agent/eda-benchmark/sources — bdp_tables 테이블 목록."""

    async def get(self):
        try:
            from .rag_admin_handler import _ensure_manager

            mgr = _ensure_manager()
            if mgr is None:
                self.write(json.dumps({"tables": []}))
                return

            client = mgr._client
            tables: List[Dict] = []
            scroll_offset = None
            while True:
                pts, scroll_offset = client.scroll(
                    collection_name="bdp_tables",
                    limit=100,
                    with_payload=True,
                    with_vectors=False,
                    offset=scroll_offset,
                )
                for pt in pts:
                    p = pt.payload or {}
                    tname = p.get("table_name", p.get("테이블명", ""))
                    kname = p.get("korean_name", p.get("테이블한글명", ""))
                    cols = p.get("columns", [])
                    if tname and len(cols) >= 5:
                        col_names = []
                        for c in cols:
                            cn = (
                                (c.get("col_name", "") or c.get("컬럼명", ""))
                                if isinstance(c, dict)
                                else ""
                            )
                            if cn:
                                col_names.append(cn)
                        tables.append(
                            {
                                "table_name": tname,
                                "korean_name": kname,
                                "column_count": len(cols),
                                "column_names": col_names,
                                "description": p.get("description", p.get("설명", "")),
                            }
                        )
                if scroll_offset is None:
                    break

            self.write(
                json.dumps({"tables": tables, "total": len(tables)}, ensure_ascii=False)
            )
        except Exception as e:
            self.write(json.dumps({"tables": [], "error": str(e)}))


# ─── Auto-generate test cases ───


class EdaBenchmarkGenerateHandler(APIHandler):
    """POST /hdsp-agent/eda-benchmark/generate — 테이블 조합 선정 + 질문 자동 생성."""

    async def post(self):
        body = (
            json.loads(self.request.body.decode("utf-8")) if self.request.body else {}
        )
        selected_tables = body.get("tables", [])  # 사용자가 선택한 테이블 목록
        per_difficulty = body.get("per_difficulty", 3)  # easy/medium/hard 각 N개

        try:
            from .rag_admin_handler import _ensure_manager

            mgr = _ensure_manager()
            if mgr is None:
                self.set_status(500)
                self.write({"error": "RAG 매니저 미초기화"})
                return

            client = mgr._client

            # 1. 전체 테이블 메타 수집
            all_tables: Dict[str, Dict] = {}
            scroll_offset = None
            while True:
                pts, scroll_offset = client.scroll(
                    collection_name="bdp_tables",
                    limit=100,
                    with_payload=True,
                    with_vectors=False,
                    offset=scroll_offset,
                )
                for pt in pts:
                    p = pt.payload or {}
                    tname = p.get("table_name", p.get("테이블명", ""))
                    if not tname:
                        continue
                    cols = p.get("columns", [])
                    if len(cols) < 5:
                        continue
                    kname = p.get("korean_name", p.get("테이블한글명", ""))
                    if not kname:
                        continue
                    # 선택된 테이블만 사용 (선택 안 했으면 전체)
                    if selected_tables and tname not in selected_tables:
                        continue
                    col_names = []
                    col_details = []
                    for c in cols[:50]:  # 최대 50개 컬럼
                        if isinstance(c, dict):
                            cn = c.get("col_name", "") or c.get("컬럼명", "")
                            ck = c.get("col_korean_name", "") or c.get("컬럼한글명", "")
                            ct = c.get("col_type", "") or c.get("컬럼타입", "")
                            if cn:
                                col_names.append(cn)
                                col_details.append(
                                    {"name": cn, "korean": ck, "type": ct}
                                )
                    if tname not in all_tables:
                        all_tables[tname] = {
                            "table_name": tname,
                            "korean_name": kname,
                            "description": p.get("description", p.get("설명", "")),
                            "column_names": col_names,
                            "column_details": col_details,
                        }
                    else:
                        # 청크 병합: 컬럼 추가
                        existing = all_tables[tname]
                        existing_names = set(existing["column_names"])
                        for cn, cd in zip(col_names, col_details):
                            if cn not in existing_names:
                                existing["column_names"].append(cn)
                                existing["column_details"].append(cd)
                                existing_names.add(cn)
                if scroll_offset is None:
                    break

            if not all_tables:
                self.write(
                    json.dumps(
                        {"test_cases": [], "message": "테이블을 찾을 수 없습니다."}
                    )
                )
                return

            # 2. 컬럼 빈도 집계 → 흔한 컬럼 제외
            col_frequency: Dict[str, int] = defaultdict(int)
            for t in all_tables.values():
                for cn in t["column_names"]:
                    col_frequency[cn] += 1

            total_tables = len(all_tables)
            threshold = max(total_tables * 0.2, 5)
            common_cols = {c for c, freq in col_frequency.items() if freq >= threshold}

            print(
                f"[EDA-Bench] Tables: {total_tables}, "
                f"Common columns excluded ({len(common_cols)}): "
                f"{sorted(common_cols)[:10]}",
                flush=True,
            )

            # 3. 특화 컬럼으로 JOIN 가능 테이블 쌍 찾기
            table_names = list(all_tables.keys())
            table_specialized: Dict[str, set] = {}
            for tname, tdata in all_tables.items():
                specialized = set(tdata["column_names"]) - common_cols
                table_specialized[tname] = specialized

            joinable_pairs: List[tuple] = []
            for i, t1 in enumerate(table_names):
                for t2 in table_names[i + 1 :]:
                    shared = table_specialized[t1] & table_specialized[t2]
                    if shared:
                        joinable_pairs.append((t1, t2, shared))

            print(f"[EDA-Bench] Joinable pairs: {len(joinable_pairs)}", flush=True)

            # 4. 테이블 조합 선정
            import random

            random.shuffle(table_names)
            random.shuffle(joinable_pairs)

            # simple: 단일 테이블
            simple_tables = table_names[: per_difficulty * 2]  # 여유 있게

            # medium: 2개 테이블 쌍
            medium_pairs = joinable_pairs[: per_difficulty * 2]

            # hard: 3개 테이블 체인 (A-B, B-C 공통 컬럼)
            hard_chains: List[tuple] = []
            pair_by_table: Dict[str, List[tuple]] = defaultdict(list)
            for t1, t2, shared in joinable_pairs:
                pair_by_table[t1].append((t2, shared))
                pair_by_table[t2].append((t1, shared))

            used_chains: set = set()
            for t1, t2, shared_ab in joinable_pairs:
                if len(hard_chains) >= per_difficulty * 2:
                    break
                for t3, shared_bc in pair_by_table.get(t2, []):
                    if t3 != t1:
                        chain_key = tuple(sorted([t1, t2, t3]))
                        if chain_key not in used_chains:
                            used_chains.add(chain_key)
                            hard_chains.append((t1, t2, t3, shared_ab, shared_bc))
                            break

            # SSE 헤더
            self.set_header("Content-Type", "text/event-stream")
            self.set_header("Cache-Control", "no-cache")
            self.set_header("Connection", "keep-alive")

            # 5. LLM으로 질문 생성
            from hdsp_agent_core.llm.service import LLMService
            from hdsp_agent_core.managers.config_manager import get_config_manager

            cfg = get_config_manager().get_config()
            env_cfg = get_config_manager().get_env_llm_config()
            if env_cfg:
                cfg.update(env_cfg)
            llm_config = cfg.get("vllm", {})
            if not llm_config:
                self.write(
                    f"data: {json.dumps({'type': 'error', 'error': 'LLM 설정 없음'})}\n\n"
                )
                self.finish()
                return

            llm = LLMService({"provider": "vllm", "vllm": llm_config})
            generated: List[Dict] = []

            # 생성 태스크 준비
            tasks: List[Dict] = []

            # simple (generate)
            for tname in simple_tables[:per_difficulty]:
                t = all_tables[tname]
                cols_str = ", ".join(
                    f"{c['name']}({c['korean']})" for c in t["column_details"][:20]
                )
                tasks.append(
                    {
                        "type": "generate",
                        "difficulty": "easy",
                        "tables": [tname],
                        "prompt_context": (
                            f"테이블: {tname} ({t['korean_name']})\n"
                            f"설명: {t['description']}\n"
                            f"컬럼: {cols_str}"
                        ),
                    }
                )

            # tune — joinable pair로 복잡한 비효율 SQL 생성
            tune_pairs = joinable_pairs[
                per_difficulty * 2 : per_difficulty * 2 + per_difficulty
            ]
            # pair가 부족하면 단일 테이블로 fallback
            tune_single = simple_tables[per_difficulty : per_difficulty * 2]
            tune_idx = 0
            for _ in range(per_difficulty):
                if tune_idx < len(tune_pairs):
                    t1, t2, shared = tune_pairs[tune_idx]
                    tune_idx += 1
                    d1, d2 = all_tables[t1], all_tables[t2]
                    cols1 = ", ".join(
                        f"{c['name']}({c['korean']}, {c['type']})"
                        for c in d1["column_details"][:20]
                    )
                    cols2 = ", ".join(
                        f"{c['name']}({c['korean']}, {c['type']})"
                        for c in d2["column_details"][:20]
                    )
                    tasks.append(
                        {
                            "type": "tune",
                            "difficulty": "medium",
                            "tables": [t1, t2],
                            "shared_columns": list(shared),
                            "prompt_context": (
                                f"테이블1: {t1} ({d1['korean_name']})\n"
                                f"컬럼: {cols1}\n\n"
                                f"테이블2: {t2} ({d2['korean_name']})\n"
                                f"컬럼: {cols2}\n\n"
                                f"공통 컬럼(JOIN 키): {', '.join(shared)}"
                            ),
                        }
                    )
                elif tune_idx - len(tune_pairs) < len(tune_single):
                    tname = tune_single[tune_idx - len(tune_pairs)]
                    tune_idx += 1
                    t = all_tables.get(tname)
                    if not t:
                        continue
                    cols_str = ", ".join(
                        f"{c['name']}({c['korean']}, {c['type']})"
                        for c in t["column_details"][:20]
                    )
                    tasks.append(
                        {
                            "type": "tune",
                            "difficulty": "easy",
                            "tables": [tname],
                            "prompt_context": (
                                f"테이블: {tname} ({t['korean_name']})\n"
                                f"설명: {t['description']}\n"
                                f"컬럼: {cols_str}"
                            ),
                        }
                    )

            # medium (generate)
            for t1, t2, shared in medium_pairs[:per_difficulty]:
                d1, d2 = all_tables[t1], all_tables[t2]
                cols1 = ", ".join(
                    f"{c['name']}({c['korean']})" for c in d1["column_details"][:15]
                )
                cols2 = ", ".join(
                    f"{c['name']}({c['korean']})" for c in d2["column_details"][:15]
                )
                tasks.append(
                    {
                        "type": "generate",
                        "difficulty": "medium",
                        "tables": [t1, t2],
                        "shared_columns": list(shared),
                        "prompt_context": (
                            f"테이블1: {t1} ({d1['korean_name']})\n"
                            f"컬럼: {cols1}\n\n"
                            f"테이블2: {t2} ({d2['korean_name']})\n"
                            f"컬럼: {cols2}\n\n"
                            f"공통 컬럼: {', '.join(shared)}"
                        ),
                    }
                )

            # hard (generate)
            for chain in hard_chains[:per_difficulty]:
                t1, t2, t3 = chain[0], chain[1], chain[2]
                d1, d2, d3 = all_tables[t1], all_tables[t2], all_tables[t3]
                cols1 = ", ".join(
                    f"{c['name']}({c['korean']})" for c in d1["column_details"][:10]
                )
                cols2 = ", ".join(
                    f"{c['name']}({c['korean']})" for c in d2["column_details"][:10]
                )
                cols3 = ", ".join(
                    f"{c['name']}({c['korean']})" for c in d3["column_details"][:10]
                )
                tasks.append(
                    {
                        "type": "generate",
                        "difficulty": "hard",
                        "tables": [t1, t2, t3],
                        "prompt_context": (
                            f"테이블1: {t1} ({d1['korean_name']})\n컬럼: {cols1}\n\n"
                            f"테이블2: {t2} ({d2['korean_name']})\n컬럼: {cols2}\n\n"
                            f"테이블3: {t3} ({d3['korean_name']})\n컬럼: {cols3}"
                        ),
                    }
                )

            total_tasks = len(tasks)
            self.write(
                f"data: {json.dumps({'type': 'progress', 'current': 0, 'total': total_tasks}, ensure_ascii=False)}\n\n"
            )
            await self.flush()

            # 병렬 LLM 호출
            _PARALLEL = 5
            _completed = 0

            async def _generate_one(task: Dict) -> Optional[Dict]:
                task_type = task["type"]
                if task_type == "generate":
                    prompt = (
                        "아래 테이블 정보를 읽고 SQL 쿼리 생성 요청을 만들어주세요.\n\n"
                        "규칙:\n"
                        "- 실제 분석가가 할 법한 자연어 요청으로 만드세요.\n"
                        "- 반드시 '쿼리를 작성해줘', '조회하는 SQL을 만들어줘' 형태로 끝나야 합니다.\n"
                        "- expected_columns에는 SQL에 반드시 포함되어야 할 핵심 컬럼명을 넣으세요.\n\n"
                        "반드시 아래 JSON 형식으로만 응답하세요:\n"
                        '{"question": "자연어 쿼리 생성 요청", '
                        '"expected_columns": ["핵심 컬럼명"]}\n\n'
                        f"{task['prompt_context']}"
                    )
                else:  # tune
                    prompt = (
                        "아래 테이블 정보를 읽고 두 가지를 만들어주세요:\n"
                        "1. 이 테이블들을 사용하는 **복잡하고 비효율적인** Athena SQL\n"
                        "2. 그 SQL에 대한 튜닝 요청 자연어\n\n"
                        "SQL 작성 규칙 (매우 중요):\n"
                        "- **최소 50줄 이상**의 복잡한 SQL이어야 합니다.\n"
                        "- 반드시 다음 요소를 포함하세요:\n"
                        "  * 여러 CTE (WITH절) 또는 서브쿼리\n"
                        "  * JOIN (가능하면 여러 테이블)\n"
                        "  * GROUP BY + 집계함수 (SUM, COUNT, AVG 등)\n"
                        "  * CASE WHEN 조건 분기\n"
                        "  * ORDER BY\n"
                        "- 비효율적 요소를 포함하세요:\n"
                        "  * SELECT * 사용\n"
                        "  * 파티션 컬럼에 함수 적용 (WHERE YEAR(date_col) = 2024)\n"
                        "  * 불필요한 서브쿼리 중첩\n"
                        "  * 큰 테이��이 RIGHT JOIN의 오른쪽에 위치\n"
                        "  * 타입 불일치 JOIN (문자열 vs 숫자)\n"
                        "- SQL은 Athena(Presto/Trino) 문법이어야 합니다.\n"
                        "- 테이블명과 컬럼명은 아래 제공된 것만 사용하세요.\n\n"
                        "튜닝 요청 규칙:\n"
                        "- '이 쿼리의 용도를 분석하고 최적화해줘' 형태로.\n"
                        "- expected_improvements에는 기대하는 개선사항을 넣으세요.\n\n"
                        "반드시 아래 JSON 형식으로만 응답하세요:\n"
                        '{"question": "튜닝 요청 자연어", '
                        '"existing_sql": "복잡한 비��율적 SQL (50줄 이상)", '
                        '"expected_improvements": ["파티션 필터 개선", "컬럼 축소", '
                        '"JOIN 순서 최적화", "서브쿼리 제거"]}\n\n'
                        f"{task['prompt_context']}"
                    )

                try:
                    resp = await llm.generate_response(prompt)
                    resp = resp.strip()
                    if resp.startswith("```"):
                        resp = resp.split("```")[1]
                        if resp.startswith("json"):
                            resp = resp[4:]
                    parsed = json.loads(resp)

                    tc = {
                        "id": f"eda_{uuid.uuid4().hex[:8]}",
                        "type": task_type,
                        "question": parsed.get("question", ""),
                        "difficulty": task["difficulty"],
                        "expected_tables": task["tables"],
                        "auto_generated": True,
                    }

                    if task_type == "generate":
                        tc["existing_sql"] = None
                        tc["expected_columns"] = parsed.get("expected_columns", [])
                    else:
                        tc["existing_sql"] = parsed.get("existing_sql", "")
                        tc["expected_improvements"] = parsed.get(
                            "expected_improvements", []
                        )

                    return tc
                except Exception as e:
                    logger.warning(f"EDA test case generation failed: {e}")
                    return None

            import asyncio as _aio

            sem = _aio.Semaphore(_PARALLEL)

            async def _gen_with_sem(task: Dict):
                nonlocal _completed
                async with sem:
                    r = await _generate_one(task)
                    _completed += 1
                    if r is not None:
                        generated.append(r)
                        self.write(
                            f"data: {json.dumps({'type': 'case', 'test_case': r}, ensure_ascii=False)}\n\n"
                        )
                    self.write(
                        f"data: {json.dumps({'type': 'progress', 'current': _completed, 'total': total_tasks}, ensure_ascii=False)}\n\n"
                    )
                    await self.flush()
                    return r

            await _aio.gather(*[_gen_with_sem(t) for t in tasks])

            self.write(
                f"data: {json.dumps({'type': 'complete', 'total': len(generated)})}\n\n"
            )
            await self.flush()
            self.finish()

        except Exception as e:
            logger.error(f"EDA benchmark generate failed: {e}", exc_info=True)
            self.set_status(500)
            self.write({"error": str(e)})


# ─── Run benchmark ───


class EdaBenchmarkRunHandler(APIHandler):
    """POST /hdsp-agent/eda-benchmark/run — EDA 벤치마크 실행 (SSE)."""

    async def post(self):
        body = (
            json.loads(self.request.body.decode("utf-8")) if self.request.body else {}
        )
        test_case_ids = body.get("test_case_ids")
        memo = body.get("memo", "")

        all_cases = _load_test_cases()
        if test_case_ids:
            cases = [c for c in all_cases if c.get("id") in test_case_ids]
        else:
            cases = all_cases

        if not cases:
            self.set_status(400)
            self.write({"error": "테스트 케이스가 없습니다."})
            return

        self.set_header("Content-Type", "text/event-stream")
        self.set_header("Cache-Control", "no-cache")
        self.set_header("Connection", "keep-alive")

        from hdsp_agent_core.managers.config_manager import get_config_manager

        cfg = get_config_manager().get_config()
        env_cfg = get_config_manager().get_env_llm_config()
        if env_cfg:
            cfg.update(env_cfg)

        results: List[Dict] = []
        total = len(cases)
        _completed = 0
        _cancelled = False
        _PARALLEL = 3  # EDA는 EXPLAIN 호출이 있어서 낮게

        import asyncio as _aio

        sem = _aio.Semaphore(_PARALLEL)

        async def _run_one(tc):
            nonlocal _completed, _cancelled
            if _cancelled:
                return None
            async with sem:
                if _cancelled:
                    return None
                try:
                    r = await self._run_single_case(tc, cfg)
                except Exception as e:
                    logger.error(f"EDA benchmark case {tc['id']} failed: {e}")
                    r = {"case_id": tc["id"], "error": str(e), "scores": {}}
                _completed += 1
                results.append(r)
                try:
                    self.write(
                        f"data: {json.dumps({'type': 'case_result', 'result': r}, ensure_ascii=False, default=str)}\n\n"
                    )
                    self.write(
                        f"data: {json.dumps({'type': 'progress', 'current': _completed, 'total': total})}\n\n"
                    )
                    await self.flush()
                except Exception:
                    _cancelled = True
                return r

        try:
            await _aio.gather(*[_run_one(tc) for tc in cases])
        except Exception:
            _cancelled = True

        valid_results = [r for r in results if r is not None]
        summary = self._calc_summary(valid_results)

        full_result = {
            "date": datetime.now().isoformat(),
            "memo": memo + (" (중단됨)" if _cancelled else ""),
            "total_cases": len(valid_results),
            "summary": summary,
            "results": valid_results,
        }
        result_id = _save_result(full_result)

        try:
            self.write(
                f"data: {json.dumps({'type': 'complete', 'result_id': result_id, 'summary': summary, 'cancelled': _cancelled}, ensure_ascii=False, default=str)}\n\n"
            )
            await self.flush()
        except Exception:
            pass
        self.finish()

    async def _run_single_case(
        self, tc: Dict[str, Any], cfg: Dict[str, Any]
    ) -> Dict[str, Any]:
        """단일 EDA 테스트 케이스 실행."""
        from hdsp_agent_core.services.rag_chat_agent import (
            RAGChatAgent,
            TableConfirmationNeeded,
        )

        llm_cfg = {"provider": "vllm", "vllm": cfg.get("vllm", {})}
        tc_type = tc.get("type", "generate")
        question = tc.get("question", "")
        existing_sql = tc.get("existing_sql")
        expected_tables = tc.get("expected_tables", [])

        start_time = time.time()
        result: Dict[str, Any] = {
            "case_id": tc["id"],
            "type": tc_type,
            "question": question,
            "difficulty": tc.get("difficulty", ""),
            "expected_tables": expected_tables,
        }

        # ── Phase 1: SQL 생성 ──
        from langgraph.checkpoint.memory import MemorySaver

        # EDA Agent 시스템 프롬프트 사용 (JSON 응답 형식 강제)
        from jupyter_ext.http_handlers import _ATHENA_TUNING_DEFAULT_PROMPT

        thread_id = f"eda-bench-{uuid.uuid4().hex[:8]}"
        _eda_grounding = (
            "위 검색 결과의 테이블/컬럼 정보를 활용하여 "
            "사용자 요청에 맞는 응답을 생성하세요.\n"
            "반드시 JSON 형식(title, description, sql)으로 응답하세요."
        )
        from jupyter_ext.agent.langchain_tools import set_eda_only_bdp

        set_eda_only_bdp(True)
        agent = RAGChatAgent(
            llm_cfg,
            system_prompt_override=_ATHENA_TUNING_DEFAULT_PROMPT,
            checkpointer=MemorySaver(),
            table_score_threshold=0.7,
            grounding_constraint=_eda_grounding,
        )

        response_text = ""
        selected_tables = []
        confirmed_tables = []
        path_used = "B" if existing_sql else "A"

        if tc_type == "tune" and existing_sql:
            # 튜닝: existingSql과 함께 요청
            user_msg = f"[기존 SQL]\n```sql\n{existing_sql}\n```\n\n{question}"
            path_used = "direct"
            try:
                async for chunk in agent.stream_response(
                    user_message=user_msg, thread_id=thread_id
                ):
                    if isinstance(chunk, dict) and chunk.get("content"):
                        response_text += chunk["content"]
            except TableConfirmationNeeded as e:
                # tune에서도 테이블 확인 필요 시 top-1 자동 선택 후 재실행
                for _q, candidates in e.candidates.items():
                    if candidates:
                        selected_tables.append(candidates[0])
                confirmed_tables = e.confirmed_tables or []
                all_selected = selected_tables + confirmed_tables
                table_ctx = json.dumps(all_selected, ensure_ascii=False, default=str)
                user_msg2 = (
                    f"[선택된 테이블 정보]\n{table_ctx}\n\n"
                    f"[기존 SQL]\n```sql\n{existing_sql}\n```\n\n{question}"
                )
                thread_id2 = f"eda-bench-{uuid.uuid4().hex[:8]}"
                agent2 = RAGChatAgent(
                    llm_cfg,
                    system_prompt_override=_ATHENA_TUNING_DEFAULT_PROMPT,
                    checkpointer=MemorySaver(),
                    grounding_constraint=_eda_grounding,
                )
                try:
                    async for chunk in agent2.stream_response(
                        user_message=user_msg2, thread_id=thread_id2
                    ):
                        if isinstance(chunk, dict) and chunk.get("content"):
                            response_text += chunk["content"]
                except Exception as e2:
                    result["error"] = f"Tune Path B failed: {e2}"
                    result["scores"] = {}
                    return result
            except Exception as e:
                result["error"] = f"SQL generation failed: {e}"
                result["scores"] = {}
                return result
        else:
            # 생성: RAG 경로 (Path A)
            try:
                async for chunk in agent.stream_response(
                    user_message=question, thread_id=thread_id
                ):
                    if isinstance(chunk, dict) and chunk.get("content"):
                        response_text += chunk["content"]
            except TableConfirmationNeeded as e:
                # 자동 테이블 선택: 각 그룹의 top-1
                for _q, candidates in e.candidates.items():
                    if candidates:
                        selected_tables.append(candidates[0])
                confirmed_tables = e.confirmed_tables or []

                # Path B로 재실행
                path_used = "A→B"
                response_text = ""
                thread_id2 = f"eda-bench-{uuid.uuid4().hex[:8]}"
                agent2 = RAGChatAgent(
                    llm_cfg,
                    system_prompt_override=_ATHENA_TUNING_DEFAULT_PROMPT,
                    checkpointer=MemorySaver(),
                    grounding_constraint=_eda_grounding,
                )
                # selectedTables 형태로 전달
                all_selected = selected_tables + confirmed_tables
                table_ctx = json.dumps(all_selected, ensure_ascii=False, default=str)
                user_msg2 = f"[선택된 테이블 정보]\n{table_ctx}\n\n{question}"
                try:
                    async for chunk in agent2.stream_response(
                        user_message=user_msg2, thread_id=thread_id2
                    ):
                        if isinstance(chunk, dict) and chunk.get("content"):
                            response_text += chunk["content"]
                except Exception as e2:
                    result["error"] = f"Path B failed: {e2}"
                    result["scores"] = {}
                    return result
            except Exception as e:
                result["error"] = f"Path A failed: {e}"
                result["scores"] = {}
                return result

        # title / description / sql 추출
        sql = ""
        title = ""
        description = ""
        try:
            import re

            # JSON 파싱 시도 (EDA Agent는 {title, description, sql} 또는 {title, description} JSON 반환)
            json_match = re.search(
                r"\{.*(?:\"sql\"|\"title\")\s*:", response_text, re.DOTALL
            )
            if json_match:
                # JSON 시작점부터 끝까지 추출
                json_start = json_match.start()
                # 중첩 브레이스 처리
                depth = 0
                json_end = json_start
                for ci, ch in enumerate(response_text[json_start:], json_start):
                    if ch == "{":
                        depth += 1
                    elif ch == "}":
                        depth -= 1
                        if depth == 0:
                            json_end = ci + 1
                            break
                try:
                    parsed = json.loads(response_text[json_start:json_end])
                    sql = parsed.get("sql", "")
                    title = parsed.get("title", "")
                    description = parsed.get("description", "")
                except Exception:
                    pass
            if not sql:
                # 코드 블록에서 SQL 추출
                sql_match = re.search(
                    r"```(?:sql)?\s*\n(.*?)\n```", response_text, re.DOTALL
                )
                if sql_match:
                    sql = sql_match.group(1).strip()
        except Exception:
            pass

        result["response"] = response_text[:2000]
        result["sql"] = sql
        result["title"] = title
        result["description"] = description
        result["path_used"] = path_used
        result["selected_tables"] = [
            t.get("table_name", "") if isinstance(t, dict) else str(t)
            for t in selected_tables + confirmed_tables
        ]

        # ── Phase 2: EXPLAIN 검증 ──
        explain_success = False
        explain_error = ""
        fix_count = 0

        if sql:
            from jupyter_ext.http_handlers import _run_explain

            explain_result = await _run_explain(sql)
            explain_success = explain_result.get("success", False)
            explain_error = explain_result.get("error", "")

            # Fix loop (최대 3회 — 벤치마크에서는 간소화)
            current_sql = sql
            max_fixes = 3
            while not explain_success and fix_count < max_fixes:
                fix_count += 1
                # LLM에게 fix 요청
                from hdsp_agent_core.llm.service import LLMService

                fix_llm = LLMService({"provider": "vllm", "vllm": cfg.get("vllm", {})})
                fix_prompt = (
                    f"아래 SQL에서 EXPLAIN 실행 시 오류가 발생했습니다. 오류를 수정하세요.\n\n"
                    f"[SQL]\n{current_sql}\n\n"
                    f"[오류]\n{explain_error}\n\n"
                    '수정된 SQL만 JSON으로 응답하세요: {{"sql": "수정된 SQL"}}'
                )
                try:
                    fix_resp = await fix_llm.generate_response(fix_prompt)
                    fix_resp = fix_resp.strip()
                    if fix_resp.startswith("```"):
                        fix_resp = fix_resp.split("```")[1]
                        if fix_resp.startswith("json"):
                            fix_resp = fix_resp[4:]
                    fix_parsed = json.loads(fix_resp)
                    fixed_sql = fix_parsed.get("sql", "")
                    if fixed_sql:
                        current_sql = fixed_sql
                        explain_result = await _run_explain(current_sql)
                        explain_success = explain_result.get("success", False)
                        explain_error = explain_result.get("error", "")
                except Exception:
                    break

            result["final_sql"] = current_sql
            result["explain_success"] = explain_success
            result["explain_error"] = explain_error if not explain_success else ""
            result["fix_count"] = fix_count

            # ── Phase 3: 쿼리플랜 튜닝 + REASON 주석 ──
            plan_tuned = False
            tuned_sql = ""
            tuning_description = ""
            tune_explain_success = False
            reason_count = 0

            if explain_success and (existing_sql or explain_result.get("plan")):
                explain_plan = explain_result.get("plan", "")
                try:
                    from jupyter_ext.http_handlers import (
                        _PLAN_TUNING_SYSTEM_ADDITION,
                    )
                    from hdsp_agent_core.llm.service import LLMService

                    tune_llm = LLMService(
                        {"provider": "vllm", "vllm": cfg.get("vllm", {})}
                    )
                    tune_system = (
                        _ATHENA_TUNING_DEFAULT_PROMPT
                        + "\n\n"
                        + _PLAN_TUNING_SYSTEM_ADDITION
                    )
                    _plan_block = (
                        f"\n\n[쿼리 플랜]\n{explain_plan[:3000]}"
                        if explain_plan
                        else ""
                    )
                    _origin_block = (
                        f"\n\n[원본 SQL]\n{existing_sql}" if existing_sql else ""
                    )
                    _desc_block = (
                        f"\n\n[변경 설명]\n{description}"
                        if existing_sql and description
                        else ""
                    )
                    tune_prompt = (
                        f"[SQL]\n{current_sql}{_plan_block}{_origin_block}{_desc_block}"
                    )
                    tune_resp = await tune_llm.generate_response(
                        tune_prompt, system_prompt=tune_system
                    )
                    tune_resp = tune_resp.strip()
                    if tune_resp.startswith("```"):
                        tune_resp = tune_resp.split("```")[1]
                        if tune_resp.startswith("json"):
                            tune_resp = tune_resp[4:]

                    # JSON 파싱
                    import re as _re

                    _tm = _re.search(
                        r"\{.*(?:\"sql\"|\"title\")\s*:", tune_resp, _re.DOTALL
                    )
                    if _tm:
                        _ts = _tm.start()
                        _depth = 0
                        _te = _ts
                        for _ci, _ch in enumerate(tune_resp[_ts:], _ts):
                            if _ch == "{":
                                _depth += 1
                            elif _ch == "}":
                                _depth -= 1
                                if _depth == 0:
                                    _te = _ci + 1
                                    break
                        tune_parsed = json.loads(tune_resp[_ts:_te])
                        tuned_sql = tune_parsed.get("sql", "")
                        tuning_description = tune_parsed.get(
                            "tuning_info", ""
                        ) or tune_parsed.get("description", "")

                    if tuned_sql and tuned_sql.strip() != current_sql.strip():
                        plan_tuned = True
                        # Count REASON comments
                        reason_count = len(
                            _re.findall(
                                r"^\s*--\s*\[REASON\]",
                                tuned_sql,
                                _re.MULTILINE | _re.IGNORECASE,
                            )
                        )

                        # Phase 4: 튜닝 후 EXPLAIN 재검증
                        tune_explain = await _run_explain(tuned_sql)
                        tune_explain_success = tune_explain.get("success", False)
                        if tune_explain_success:
                            current_sql = tuned_sql
                            result["final_sql"] = current_sql

                except Exception as e:
                    logger.warning(f"Plan tuning failed: {e}")

            result["plan_tuned"] = plan_tuned
            result["tuned_sql"] = tuned_sql if plan_tuned else ""
            result["tuning_description"] = tuning_description
            result["tune_explain_success"] = tune_explain_success
            result["reason_count"] = reason_count

        else:
            result["final_sql"] = ""
            result["explain_success"] = False
            result["explain_error"] = "SQL 생성 실패"
            result["fix_count"] = 0
            result["plan_tuned"] = False
            result["tuned_sql"] = ""
            result["tuning_description"] = ""
            result["tune_explain_success"] = False
            result["reason_count"] = 0

        elapsed = round(time.time() - start_time, 1)

        # ── 평가 ──
        scores: Dict[str, Any] = {
            "response_time": elapsed,
            "explain_first_try": explain_success and fix_count == 0,
            "explain_final": explain_success,
            "fix_count": fix_count,
            "path_used": path_used,
            "plan_tuned": result.get("plan_tuned", False),
            "tune_explain_success": result.get("tune_explain_success", False),
            "reason_count": result.get("reason_count", 0),
        }

        # 컬럼 정확성 (기본 문자열 매칭)

        # 컬럼 정확성
        expected_cols = tc.get("expected_columns", [])
        if expected_cols and sql:
            sql_lower = sql.lower()
            col_hits = sum(1 for c in expected_cols if c.lower() in sql_lower)
            scores["column_accuracy"] = round(col_hits / len(expected_cols) * 100, 1)

        # LLM 평가 (title/description/sql 각각)
        if sql or title or description:
            try:
                from hdsp_agent_core.llm.service import LLMService

                eval_llm = LLMService({"provider": "vllm", "vllm": cfg.get("vllm", {})})
                expected_tables_str = (
                    ", ".join(expected_tables) if expected_tables else "(없음)"
                )
                eval_prompt = (
                    "아래 EDA Agent의 응답을 평가하세요.\n\n"
                    f"[사용자 질문]\n{question}\n\n"
                    f"[기대 테이블]\n{expected_tables_str}\n\n"
                    f"[Title]\n{title or '(없음)'}\n\n"
                    f"[Description]\n{description or '(없음)'}\n\n"
                    f"[SQL]\n{sql or '(없음)'}\n\n"
                    "평가 항목 (각 1~10점):\n"
                    "- title_quality: 제목이 요청의 핵심을 한 줄로 잘 요약했는지\n"
                    "- description_quality: 설명이 SQL의 목적·로직·사용 테이블을 "
                    "명확히 설명하는지\n"
                    "- semantic_accuracy: SQL이 질문의 의도를 정확히 반영하는지\n"
                    "- sql_quality: SQL 문법·구조·효율성이 적절한지\n\n"
                    "테이블 사용 분석:\n"
                    "- SQL에서 FROM/JOIN에 사용된 테이블명을 모두 추출하세요.\n"
                    "- [기대 테이블]과 비교하여 올바른 테이블을 사용했는지 확인하세요.\n"
                    "- used_tables: SQL에서 실제 사용한 테이블명 배열\n\n"
                    "파티션 컬럼 사용 여부:\n"
                    "- SQL에서 사용하는 테이블에 날짜/시간 기반 파티션 컬럼이 "
                    "있을 가능성이 높습니다.\n"
                    "- WHERE절에 파티션 컬럼(날짜, dt, date, yyyymmdd 등)을 "
                    "사용하고 있는지 확인하세요.\n"
                    "- partition_missing: 파티션 컬럼이 있을 가능성이 높은데 "
                    "WHERE절에서 사용하지 않았으면 true, 그 외 false\n\n"
                    "반드시 아래 JSON만 출력:\n"
                    '{"title_quality": N, "description_quality": N, '
                    '"semantic_accuracy": N, "sql_quality": N, '
                    '"used_tables": ["테이블명1", "테이블명2"], '
                    '"partition_missing": true/false, '
                    '"comment": "종합 평가 의견"}'
                )
                eval_resp = await eval_llm.generate_response(eval_prompt)
                eval_resp = eval_resp.strip()
                if eval_resp.startswith("```"):
                    eval_resp = eval_resp.split("```")[1]
                    if eval_resp.startswith("json"):
                        eval_resp = eval_resp[4:]
                import re as _re

                # JSON 추출 (배열 포함 가능)
                json_match = _re.search(r"\{[^{}]*(?:\[[^\[\]]*\])?[^{}]*\}", eval_resp)
                if json_match:
                    eval_resp = json_match.group(0)
                eval_parsed = json.loads(eval_resp)
                scores["title_quality"] = eval_parsed.get("title_quality", 5)
                scores["description_quality"] = eval_parsed.get(
                    "description_quality", 5
                )
                scores["semantic_accuracy"] = eval_parsed.get("semantic_accuracy", 5)
                scores["sql_quality"] = eval_parsed.get("sql_quality", 5)
                scores["partition_missing"] = eval_parsed.get(
                    "partition_missing", False
                )
                scores["eval_comment"] = eval_parsed.get("comment", "")

                # LLM이 추출한 테이블로 F1 계산
                used_tables = eval_parsed.get("used_tables", [])
                if used_tables and expected_tables:
                    used_set = set(t.lower() for t in used_tables)
                    exp_set = set(t.lower() for t in expected_tables)
                    if used_set:
                        precision = len(used_set & exp_set) / len(used_set)
                        recall = len(used_set & exp_set) / len(exp_set)
                        f1 = (
                            2 * precision * recall / (precision + recall)
                            if (precision + recall) > 0
                            else 0
                        )
                        scores["table_precision"] = round(precision * 100, 1)
                        scores["table_recall"] = round(recall * 100, 1)
                        scores["table_f1"] = round(f1 * 100, 1)
                        scores["sql_tables"] = sorted(used_set)
            except Exception as e:
                logger.warning(f"EDA eval failed: {e}")
                scores["title_quality"] = 5
                scores["description_quality"] = 5
                scores["semantic_accuracy"] = 5
                scores["sql_quality"] = 5
                scores["partition_missing"] = False
                scores["eval_comment"] = f"평가 실패: {e}"

        # 종합 점수
        overall_parts = []
        if scores.get("title_quality"):
            overall_parts.append(scores["title_quality"])
        if scores.get("description_quality"):
            overall_parts.append(scores["description_quality"])
        if scores.get("semantic_accuracy"):
            overall_parts.append(scores["semantic_accuracy"])
        if scores.get("sql_quality"):
            overall_parts.append(scores["sql_quality"])
        # EXPLAIN 보너스/페널티
        if explain_success:
            explain_bonus = {0: 15, 1: 5, 2: 0}.get(fix_count, -5)
        else:
            explain_bonus = -15
        scores["explain_bonus"] = explain_bonus

        # 파티션 미사용 페널티
        partition_penalty = -10 if scores.get("partition_missing") else 0
        scores["partition_penalty"] = partition_penalty

        # 쿼리플랜 튜닝 보너스
        tune_bonus = 0
        if result.get("plan_tuned"):
            if result.get("tune_explain_success"):
                tune_bonus = 5  # 튜닝 적용 + EXPLAIN 성공
            else:
                tune_bonus = -5  # 튜닝 적용했지만 EXPLAIN 실패
        scores["tune_bonus"] = tune_bonus

        # REASON 주석 보너스 (existing_sql이 있는 tune 케이스에서만)
        reason_bonus = 0
        rc = scores.get("reason_count", 0)
        if existing_sql and rc > 0:
            reason_bonus = min(rc, 5)  # 최대 +5
        scores["reason_bonus"] = reason_bonus

        scores["overall"] = (
            round(
                sum(overall_parts) / len(overall_parts) * 10
                + explain_bonus
                + partition_penalty
                + tune_bonus
                + reason_bonus,
                1,
            )
            if overall_parts
            else 0
        )

        result["scores"] = scores
        set_eda_only_bdp(False)
        return result

    def _calc_summary(self, results: List[Dict]) -> Dict[str, Any]:
        """결과 요약."""
        if not results:
            return {}

        valid = [r for r in results if r.get("scores")]

        # 유형별 분류
        gen_a = [
            r
            for r in valid
            if r.get("type") == "generate" and "A" in r.get("path_used", "")
        ]
        gen_b = [
            r
            for r in valid
            if r.get("type") == "generate" and r.get("path_used") == "B"
        ]
        tune = [r for r in valid if r.get("type") == "tune"]

        def _group_summary(group, label):
            if not group:
                return {}
            success = sum(1 for r in group if r["scores"].get("explain_final"))
            avg_fix = sum(r["scores"].get("fix_count", 0) for r in group) / len(group)
            avg_time = sum(r["scores"].get("response_time", 0) for r in group) / len(
                group
            )
            avg_overall = sum(r["scores"].get("overall", 0) for r in group) / len(group)
            s = {
                "label": label,
                "count": len(group),
                "success_rate": round(success / len(group) * 100, 1),
                "avg_fix_count": round(avg_fix, 2),
                "avg_response_time": round(avg_time, 1),
                "avg_overall": round(avg_overall, 1),
            }
            # 테이블 F1 (generate만)
            f1_vals = [
                r["scores"]["table_f1"] for r in group if "table_f1" in r["scores"]
            ]
            if f1_vals:
                s["avg_table_f1"] = round(sum(f1_vals) / len(f1_vals), 1)
            return s

        return {
            "total_cases": len(valid),
            "generate_path_a": _group_summary(gen_a, "쿼리 생성 (RAG)"),
            "generate_path_b": _group_summary(gen_b, "쿼리 생성 (직접)"),
            "tune": _group_summary(tune, "SQL 튜닝"),
            "overall_success_rate": round(
                sum(1 for r in valid if r["scores"].get("explain_final"))
                / len(valid)
                * 100,
                1,
            )
            if valid
            else 0,
            "overall_avg_fix": round(
                sum(r["scores"].get("fix_count", 0) for r in valid) / len(valid), 2
            )
            if valid
            else 0,
        }


# ─── Results ───


class EdaBenchmarkResultsHandler(APIHandler):
    """GET/POST /hdsp-agent/eda-benchmark/results"""

    async def get(self):
        result_id = self.get_argument("id", None)
        if result_id:
            detail = _load_result_detail(result_id)
            if detail:
                self.write(json.dumps(detail, ensure_ascii=False, default=str))
            else:
                self.set_status(404)
                self.write({"error": "결과를 찾을 수 없습니다."})
        else:
            self.write(json.dumps(_load_results(), ensure_ascii=False, default=str))

    async def post(self):
        body = (
            json.loads(self.request.body.decode("utf-8")) if self.request.body else {}
        )
        action = body.get("action")
        if action == "delete":
            ids = body.get("ids", [])
            deleted = 0
            for rid in ids:
                path = _RESULTS_DIR / f"{rid}.json"
                if path.exists():
                    path.unlink()
                    deleted += 1
            self.write({"status": "ok", "deleted": deleted})
