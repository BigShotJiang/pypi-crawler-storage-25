from setuptools import setup

def readme():
      with open('README.rst') as f:
               return f.read()

setup(name='TElocal',
      version='1.1.3',
      description='Tool for estimating differential enrichment of Transposable Elements and other highly repetitive regions in a locus-specific approach',
      long_description=readme(),
      classifiers=[
          'Development Status :: 3 - Alpha',
          'Intended Audience :: Science/Research',
          'Environment :: Console',
          'Natural Language :: English',
          'License :: OSI Approved :: GNU General Public License v3 (GPLv3)',
          'Topic :: Scientific/Engineering :: Bio-Informatics',
          'Programming Language :: Python :: 3',
          'Operating System :: MacOS',
          'Operating System :: Unix'
      ],
      keywords='TE transposable element differential enrichment',
      url='https://www.mghlab.org/software/telocal',
      author='Talitha Forcier, Ying Jin, Eric Paniagua, Oliver Tam, Molly Hammell',
      author_email='mghcompbio@gmail.com',
      license='GPLv3',
      packages=[
          'TElocal_Toolkit'
      ],
      platforms=[
          'Linux',
          'MacOS'
      ],
      install_requires=[
          'pysam>=0.9'
      ],
      include_package_data=True,
      zip_safe=False,
      scripts=[
          'TElocal'
      ]
)
