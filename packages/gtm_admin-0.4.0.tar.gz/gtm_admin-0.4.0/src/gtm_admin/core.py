from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from fastapi import Request
from fastapi.responses import JSONResponse

if TYPE_CHECKING:
    from fastapi import FastAPI

STATIC_DIR = Path(__file__).parent / "static"


class GTMAdmin:
    def __init__(
        self,
        app: "FastAPI",
        db_url: str,
        secret: str,
        dev: bool = False,
        auto_seed: bool = False,
    ) -> None:
        from .auth import configure
        from .database import setup_engine

        configure(secret)
        setup_engine(db_url)

        self._workflows: dict = {}
        self._cron_workflows: list[dict] = []  # [{fn, cron, interval, name}]
        self._webhook_workflows: dict[str, Any] = {}  # name -> fn
        self._app = app

        @app.on_event("startup")
        async def _startup() -> None:
            from .database import run_migrations

            await run_migrations()

            if auto_seed:
                from .seed import seed_demo_data
                await seed_demo_data()

            self._start_scheduler()

        self._register_router(app, secret)
        self._mount_dashboard(app, dev)

    def _start_scheduler(self) -> None:
        if not self._cron_workflows:
            return

        try:
            from apscheduler.schedulers.asyncio import AsyncIOScheduler
            from apscheduler.triggers.cron import CronTrigger
            from apscheduler.triggers.interval import IntervalTrigger
        except ImportError as exc:
            raise ImportError(
                "APScheduler is required for cron/interval workflows. "
                "Install it with: pip install apscheduler"
            ) from exc

        scheduler = AsyncIOScheduler()

        for entry in self._cron_workflows:
            fn = entry["fn"]
            name = entry["name"]
            cron_expr = entry.get("cron")
            interval_seconds = entry.get("interval")

            if interval_seconds is not None:
                trigger = IntervalTrigger(seconds=interval_seconds)
            elif cron_expr:
                fields = cron_expr.split()
                if len(fields) != 5:
                    raise ValueError(
                        f"Cron expression for '{name}' must have 5 fields "
                        f"(minute hour day month day_of_week), got: {cron_expr!r}"
                    )
                minute, hour, day, month, day_of_week = fields
                trigger = CronTrigger(
                    minute=minute,
                    hour=hour,
                    day=day,
                    month=month,
                    day_of_week=day_of_week,
                )
            else:
                continue

            async def _cron_job(_fn=fn, _name=name):
                await _fn({}, _trigger_type="cron")

            scheduler.add_job(_cron_job, trigger=trigger, id=f"cron_{name}")

        scheduler.start()

    def _register_router(self, app: "FastAPI", secret: str) -> None:
        from .router import create_router

        router = create_router(secret, self._workflows)
        app.include_router(router, prefix="/api")

    def _mount_dashboard(self, app: "FastAPI", dev: bool) -> None:
        if dev:
            self._mount_dev_proxy(app)
        elif STATIC_DIR.exists():
            from fastapi.responses import FileResponse

            @app.get("/admin/{path:path}", include_in_schema=False)
            async def _serve_dashboard(path: str) -> FileResponse:
                candidate = STATIC_DIR / path
                if candidate.is_file():
                    return FileResponse(candidate)
                return FileResponse(STATIC_DIR / "index.html")

    def _mount_dev_proxy(self, app: "FastAPI") -> None:
        import httpx
        from fastapi import Request
        from fastapi.responses import StreamingResponse

        @app.api_route("/admin/{path:path}", methods=["GET"])
        async def _proxy(path: str, request: Request) -> StreamingResponse:
            async with httpx.AsyncClient() as client:
                url = f"http://localhost:5173/admin/{path}"
                resp = await client.get(url, headers=dict(request.headers))
                return StreamingResponse(
                    content=iter([resp.content]),
                    status_code=resp.status_code,
                    media_type=resp.headers.get("content-type"),
                )

    def workflow(
        self,
        fn=None,
        *,
        cron: str | None = None,
        interval: int | None = None,
        webhook: bool = False,
    ):
        """Decorator that registers a workflow function.

        Usage:
            @gtm.workflow
            async def my_workflow(inputs): ...

            @gtm.workflow(cron="0 9 * * 1-5")
            async def daily_workflow(inputs): ...

            @gtm.workflow(interval=10)   # every 10 seconds
            async def frequent_workflow(inputs): ...

            @gtm.workflow(webhook=True)
            async def webhook_workflow(inputs): ...
        """

        def _decorate(func):
            from .decorator import make_workflow_wrapper

            wrapper = make_workflow_wrapper(func)
            self._workflows[func.__name__] = func

            if cron or interval is not None:
                self._cron_workflows.append(
                    {"fn": wrapper, "cron": cron, "interval": interval, "name": func.__name__}
                )

            if webhook:
                self._register_webhook(func.__name__, wrapper)

            return wrapper

        if fn is not None:
            return _decorate(fn)

        return _decorate

    def _register_webhook(self, name: str, wrapper) -> None:
        """Mount POST /api/webhooks/{name} that calls the workflow."""
        app = self._app
        path = f"/api/webhooks/{name}"

        @app.post(path, tags=["webhooks"])
        async def _webhook_handler(request: Request) -> JSONResponse:
            try:
                body = await request.json()
            except Exception:
                body = {}
            try:
                result = await wrapper(body, _trigger_type="webhook")
            except Exception as exc:
                return JSONResponse(status_code=500, content={"error": str(exc)})
            return JSONResponse(content=result if result is not None else {})

        self._webhook_workflows[name] = wrapper

    def log(self, message: str, *, type: str = "info", json: bool = False) -> None:
        """Append a structured log entry to the currently executing node's log buffer.

        Call from inside a ``@gtm.node`` function.  If called outside a node
        the message is silently dropped.

        Args:
            message: The log message text.
            type:    ``"info"`` (default), ``"warning"``, or ``"error"``.
            json:    Set to ``True`` when *message* is a JSON string.
        """
        from .decorator import log as _log
        _log(message, type=type, json=json)

    def plan(self, *names: str) -> None:
        """Declare the ordered list of nodes this workflow intends to run.

        Any nodes in the plan that do not complete (due to an earlier failure)
        will be recorded with ``pending`` status in the dashboard.

        Call once at the top of a ``@gtm.workflow`` function body.
        """
        from .decorator import plan as _plan
        _plan(*names)

    def node(self, fn=None):
        """Decorator that wraps a function as a tracked workflow node.

        Each call is recorded as an individual step in the active workflow run,
        with its own inputs, outputs, timing, and logs.  When called outside a
        workflow the function executes transparently with no tracking overhead.

        Usage:
            @gtm.node
            async def my_step(inputs: dict) -> dict: ...
        """

        def _decorate(func):
            from .decorator import make_node_wrapper

            return make_node_wrapper(func)

        if fn is not None:
            return _decorate(fn)

        return _decorate
