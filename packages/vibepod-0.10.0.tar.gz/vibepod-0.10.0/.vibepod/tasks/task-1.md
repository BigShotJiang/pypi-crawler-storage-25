# TASK-1: Add openclaw agent core integration

## Context

VibePod is a CLI tool (`vp`) that launches AI coding agents in Docker containers. Agents are registered in several places across the codebase. Your job is to add full support for a new agent called **openclaw**.

The key files to modify are:

- `src/vibepod/constants.py` — agent list, shortcuts, image env keys, default images
- `src/vibepod/core/agents.py` — `AgentSpec` entries in `AGENT_SPECS`
- `src/vibepod/core/config.py` — default per-agent config block in `_default_config()`

## What to do

### 1. `src/vibepod/constants.py`

- Add `"openclaw"` to the `SUPPORTED_AGENTS` tuple (after `"codex"`)
- Add a shortcut entry `"oc": "openclaw"` to `AGENT_SHORTCUTS`
- Add `"VP_IMAGE_OPENCLAW"` to `IMAGE_OVERRIDE_ENV_KEYS`
- In `get_default_images()`, add:
  ```python
  "openclaw": os.environ.get(
      "VP_IMAGE_OPENCLAW",
      f"{os.environ.get('VP_IMAGE_NAMESPACE', 'vibepod')}/openclaw:latest",
  ),
  ```

### 2. `src/vibepod/core/agents.py`

Add an `AgentSpec` entry for `"openclaw"` in the `AGENT_SPECS` dict:

```python
"openclaw": AgentSpec(
    "openclaw",
    "anthropic",
    DEFAULT_IMAGES["openclaw"],
    "openclaw",
    ["openclaw"],
    "/config",
    {"HOME": "/config"},
    ikwid_args=["--dangerously-skip-permissions"],
    llm_env_map={
        "base_url": "ANTHROPIC_BASE_URL",
        "api_key": ["ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"],
        "model": [
            "ANTHROPIC_MODEL",
            "ANTHROPIC_DEFAULT_OPUS_MODEL",
            "ANTHROPIC_DEFAULT_SONNET_MODEL",
            "ANTHROPIC_DEFAULT_HAIKU_MODEL",
        ],
    },
    llm_model_args=["--model"],
),
```

### 3. `src/vibepod/core/config.py`

In `_default_config()`, inside the `"agents"` dict, add the openclaw block (after the `"codex"` entry):

```python
"openclaw": {
    "enabled": True,
    "image": DEFAULT_IMAGES["openclaw"],
    "auto_pull": None,
    "env": {},
    "volumes": [],
    "init": [],
},
```

## Verification

After making changes, verify:

1. `python -c "from vibepod.constants import SUPPORTED_AGENTS, AGENT_SHORTCUTS; assert 'openclaw' in SUPPORTED_AGENTS; assert 'oc' in AGENT_SHORTCUTS"` — should exit 0 with no output
2. `python -c "from vibepod.core.agents import AGENT_SPECS; assert 'openclaw' in AGENT_SPECS"` — should exit 0 with no output
3. `python -c "from vibepod.core.config import _default_config; cfg = _default_config(); assert 'openclaw' in cfg['agents']"` — should exit 0 with no output
4. `python -m pytest tests/ -x -q 2>&1 | tail -5` — existing tests should still pass

---

When you have finished all your work, write the following JSON to the file at the path stored in the VP_STATUS_FILE environment variable:

  {"status": "done", "summary": "<one sentence summary>", "files_changed": ["path/to/file", ...]}

If you cannot complete the task, write:

  {"status": "failed", "reason": "<why it failed>"}

Do not exit or stop until you have written this file.
