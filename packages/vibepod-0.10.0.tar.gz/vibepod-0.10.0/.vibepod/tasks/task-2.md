# TASK-2: Add tests for the openclaw agent

## Context

TASK-1 adds openclaw as a new supported agent in VibePod. Your job is to add tests that cover the new agent's registration, spec, and CLI shortcut.

The relevant test files are:

- `tests/test_agents.py` — agent registry and spec tests
- `tests/test_config.py` — config default tests

**Important:** TASK-1 must be completed before this task. The changes in TASK-1 add openclaw to `SUPPORTED_AGENTS`, `AGENT_SHORTCUTS`, `AGENT_SPECS`, and the default config. Your tests validate those additions.

## What to do

### 1. Fix `tests/test_agents.py` — hardcoded agent lists

Two existing tests contain hardcoded lists that will need updating after openclaw is added:

**`test_unsupported_agents_have_no_ikwid_args`** — openclaw has `ikwid_args`, so it must NOT be in this list. It already won't be, since the list is hardcoded. No change needed here.

**`test_agents_without_llm_env_map`** — openclaw has `llm_env_map`, so it must NOT be in this list. It already won't be. No change needed here.

### 2. Add new tests to `tests/test_agents.py`

Add the following tests at the end of the file:

```python
def test_openclaw_in_supported_agents() -> None:
    assert "openclaw" in SUPPORTED_AGENTS


def test_openclaw_shortcut_is_oc() -> None:
    assert AGENT_SHORTCUTS.get("oc") == "openclaw"
    assert resolve_agent_name("oc") == "openclaw"
    assert resolve_agent_name("openclaw") == "openclaw"


def test_openclaw_spec() -> None:
    spec = get_agent_spec("openclaw")
    assert spec.id == "openclaw"
    assert spec.provider == "anthropic"
    assert "openclaw" in spec.image
    assert spec.config_subdir == "openclaw"
    assert spec.command == ["openclaw"]
    assert spec.config_mount_path == "/config"
    assert spec.extra_env.get("HOME") == "/config"


def test_openclaw_spec_has_ikwid_args() -> None:
    spec = get_agent_spec("openclaw")
    assert spec.ikwid_args == ["--dangerously-skip-permissions"]


def test_openclaw_spec_has_llm_env_map() -> None:
    spec = get_agent_spec("openclaw")
    assert spec.llm_env_map is not None
    assert "base_url" in spec.llm_env_map
    assert "api_key" in spec.llm_env_map
    assert "model" in spec.llm_env_map
    assert spec.llm_model_args == ["--model"]
```

### 3. Add a new test to `tests/test_config.py`

Add the following test (it already imports `SUPPORTED_AGENTS` and `get_config`):

```python
def test_default_config_includes_openclaw(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("VP_CONFIG_DIR", str(tmp_path))
    config = get_config()
    assert "openclaw" in config["agents"]
    openclaw_cfg = config["agents"]["openclaw"]
    assert openclaw_cfg["enabled"] is True
    assert "openclaw" in openclaw_cfg["image"]
```

You will also need to add `import pytest` to `tests/test_config.py` if it is not already imported.

## Verification

Run the test suite and confirm all tests pass:

```
python -m pytest tests/test_agents.py tests/test_config.py -v
```

All new tests should pass and no existing tests should be broken.

---

When you have finished all your work, write the following JSON to the file at the path stored in the VP_STATUS_FILE environment variable:

  {"status": "done", "summary": "<one sentence summary>", "files_changed": ["path/to/file", ...]}

If you cannot complete the task, write:

  {"status": "failed", "reason": "<why it failed>"}

Do not exit or stop until you have written this file.
