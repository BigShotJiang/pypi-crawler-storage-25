"""Tests for PLAN.md data model, parsing and writing."""

from __future__ import annotations

from pathlib import Path

import pytest

from vibepod.core.orchestrate.plan_file import (
    parse_plan,
    update_task_status,
    write_plan,
)

SAMPLE_PLAN_MD = """\
# VibePod Orchestration Plan

## Meta
- **run-id**: abc12345
- **created**: 2026-03-22T10:00:00Z

## Task
Build a login feature with JWT auth and a React UI.

## Sub-tasks

### [TASK-1] Implement JWT authentication
- **persona**: backend
- **agent**: codex (fallback: claude)
- **worktree**: .vibepod/worktrees/task-1
- **prompt-file**: .vibepod/tasks/task-1.md
- **depends-on**: none
- **status**: pending

### [TASK-2] Build login UI
- **persona**: frontend
- **agent**: claude (fallback: codex)
- **worktree**: .vibepod/worktrees/task-2
- **prompt-file**: .vibepod/tasks/task-2.md
- **depends-on**: TASK-1
- **status**: pending
"""


def test_parse_plan_meta():
    plan = parse_plan(SAMPLE_PLAN_MD)
    assert plan.run_id == "abc12345"
    assert plan.created == "2026-03-22T10:00:00Z"
    assert plan.task_description == "Build a login feature with JWT auth and a React UI."


def test_parse_plan_task_count():
    plan = parse_plan(SAMPLE_PLAN_MD)
    assert len(plan.tasks) == 2


def test_parse_plan_task_fields():
    plan = parse_plan(SAMPLE_PLAN_MD)
    t1 = plan.tasks[0]
    assert t1.id == "TASK-1"
    assert t1.title == "Implement JWT authentication"
    assert t1.persona == "backend"
    assert t1.agent == "codex"
    assert t1.fallback == "claude"
    assert t1.worktree == ".vibepod/worktrees/task-1"
    assert t1.prompt_file == ".vibepod/tasks/task-1.md"
    assert t1.depends_on == []
    assert t1.status == "pending"


def test_parse_plan_task_dependency():
    plan = parse_plan(SAMPLE_PLAN_MD)
    t2 = plan.tasks[1]
    assert t2.depends_on == ["TASK-1"]


def test_parse_plan_multiple_dependencies():
    md = SAMPLE_PLAN_MD.replace("- **depends-on**: TASK-1\n", "- **depends-on**: TASK-1, TASK-2\n")
    plan = parse_plan(md)
    assert plan.tasks[1].depends_on == ["TASK-1", "TASK-2"]


def test_write_plan_roundtrip(tmp_path: Path):
    plan = parse_plan(SAMPLE_PLAN_MD)
    output_path = tmp_path / "PLAN.md"
    write_plan(plan, output_path)
    content = output_path.read_text()
    plan2 = parse_plan(content)
    assert plan2.run_id == plan.run_id
    assert len(plan2.tasks) == len(plan.tasks)
    assert plan2.tasks[0].id == "TASK-1"
    assert plan2.tasks[1].depends_on == ["TASK-1"]


def test_update_task_status(tmp_path: Path):
    plan_path = tmp_path / "PLAN.md"
    plan_path.write_text(SAMPLE_PLAN_MD)
    update_task_status(plan_path, "TASK-1", "running")
    content = plan_path.read_text()
    assert "- **status**: running" in content
    # Other tasks must be unchanged
    plan2 = parse_plan(content)
    assert plan2.tasks[1].status == "pending"


def test_update_task_status_unknown_id(tmp_path: Path):
    plan_path = tmp_path / "PLAN.md"
    plan_path.write_text(SAMPLE_PLAN_MD)
    with pytest.raises(ValueError, match="TASK-99"):
        update_task_status(plan_path, "TASK-99", "running")
