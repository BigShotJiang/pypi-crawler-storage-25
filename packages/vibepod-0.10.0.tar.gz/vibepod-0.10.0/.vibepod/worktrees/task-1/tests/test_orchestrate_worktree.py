"""Tests for git worktree operations."""

from __future__ import annotations

import subprocess
from pathlib import Path

from vibepod.core.orchestrate.worktree import (
    create_worktree,
    delete_worktree,
    reset_worktree,
    worktree_branch_name,
)


def _init_git_repo(path: Path) -> None:
    """Initialize a git repo with an initial commit."""
    subprocess.run(["git", "init", str(path)], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(path), "config", "user.email", "test@test.com"],
        check=True, capture_output=True,
    )
    subprocess.run(
        ["git", "-C", str(path), "config", "user.name", "Test"],
        check=True, capture_output=True,
    )
    (path / "README.md").write_text("hello")
    subprocess.run(["git", "-C", str(path), "add", "."], check=True, capture_output=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True, capture_output=True,
    )


def test_worktree_branch_name():
    assert worktree_branch_name("TASK-1", "abc123") == "orchestrate/task-1-abc123"
    assert worktree_branch_name("TASK-42", "xyz") == "orchestrate/task-42-xyz"


def test_create_worktree(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)

    worktree_path = tmp_path / "wt"
    create_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")

    assert worktree_path.exists()
    assert (worktree_path / "README.md").exists()


def test_create_worktree_creates_branch(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)

    worktree_path = tmp_path / "wt"
    create_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")

    result = subprocess.run(
        ["git", "-C", str(repo), "branch", "--list", "orchestrate/task-1-abc123"],
        capture_output=True, text=True, check=True,
    )
    assert "orchestrate/task-1-abc123" in result.stdout


def test_reset_worktree_removes_changes(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)

    worktree_path = tmp_path / "wt"
    create_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")

    # Make changes in worktree
    (worktree_path / "new_file.py").write_text("print('hello')")
    (worktree_path / "README.md").write_text("modified")

    reset_worktree(worktree_path)

    assert not (worktree_path / "new_file.py").exists()
    assert (worktree_path / "README.md").read_text() == "hello"


def test_delete_worktree(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)

    worktree_path = tmp_path / "wt"
    create_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")
    delete_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")

    assert not worktree_path.exists()


def test_delete_worktree_removes_branch(tmp_path: Path):
    repo = tmp_path / "repo"
    repo.mkdir()
    _init_git_repo(repo)

    worktree_path = tmp_path / "wt"
    create_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")
    delete_worktree(repo, worktree_path, branch="orchestrate/task-1-abc123")

    result = subprocess.run(
        ["git", "-C", str(repo), "branch", "--list", "orchestrate/task-1-abc123"],
        capture_output=True, text=True, check=True,
    )
    assert "orchestrate/task-1-abc123" not in result.stdout
