"""Tests for orchestrate prompt template generation."""

from __future__ import annotations

from vibepod.core.orchestrate.plan_file import OrchestratePlan, OrchestrateTask
from vibepod.core.orchestrate.prompts import (
    COMPLETION_INSTRUCTION,
    build_merge_prompt,
    build_planning_prompt,
)

PERSONAS = {
    "backend": {
        "preferred": "codex",
        "fallback": "claude",
        "description": "Implements APIs and server logic",
        "capabilities": ["REST APIs", "Database design"],
    },
    "frontend": {
        "preferred": "claude",
        "fallback": "codex",
        "description": "Builds UI components",
        "capabilities": ["React components", "CSS"],
    },
}

PLAN = OrchestratePlan(
    run_id="abc12345",
    created="2026-03-22T10:00:00Z",
    task_description="Build a login feature",
    tasks=[
        OrchestrateTask(
            id="TASK-1",
            title="JWT auth",
            persona="backend",
            agent="codex",
            fallback="claude",
            worktree=".vibepod/worktrees/task-1",
            prompt_file=".vibepod/tasks/task-1.md",
            depends_on=[],
            status="done",
        ),
    ],
)


def test_planning_prompt_contains_task():
    prompt = build_planning_prompt("Build a login feature", PERSONAS, run_id="abc12345")
    assert "Build a login feature" in prompt


def test_planning_prompt_contains_personas():
    prompt = build_planning_prompt("Build a login feature", PERSONAS, run_id="abc12345")
    assert "backend" in prompt
    assert "Implements APIs and server logic" in prompt
    assert "REST APIs" in prompt
    assert "frontend" in prompt


def test_planning_prompt_contains_plan_format():
    prompt = build_planning_prompt("Build a login feature", PERSONAS, run_id="abc12345")
    assert "PLAN.md" in prompt
    assert "## Sub-tasks" in prompt
    assert "run-id" in prompt
    assert "abc12345" in prompt


def test_planning_prompt_contains_completion_instruction():
    prompt = build_planning_prompt("Build a login feature", PERSONAS, run_id="abc12345")
    assert COMPLETION_INSTRUCTION in prompt


def test_merge_prompt_contains_task_description():
    prompt = build_merge_prompt(PLAN, workspace=".vibepod/worktrees")
    assert "Build a login feature" in prompt


def test_merge_prompt_contains_branch_names():
    prompt = build_merge_prompt(PLAN, workspace=".vibepod/worktrees")
    assert "orchestrate/task-1-abc12345" in prompt


def test_merge_prompt_contains_summaries():
    plan_with_summary = OrchestratePlan(
        run_id="abc12345",
        created="2026-03-22T10:00:00Z",
        task_description="Build a login feature",
        tasks=[
            OrchestrateTask(
                id="TASK-1",
                title="JWT auth",
                persona="backend",
                agent="codex",
                fallback="claude",
                worktree=".vibepod/worktrees/task-1",
                prompt_file=".vibepod/tasks/task-1.md",
                depends_on=[],
                status="done",
            ),
        ],
    )
    # Add summary via extra metadata (stored as task.summary attribute added at runtime)
    plan_with_summary.tasks[0].summary = "Implemented JWT with refresh tokens"  # type: ignore[attr-defined]
    prompt = build_merge_prompt(plan_with_summary, workspace=".vibepod/worktrees")
    assert "Implemented JWT with refresh tokens" in prompt
