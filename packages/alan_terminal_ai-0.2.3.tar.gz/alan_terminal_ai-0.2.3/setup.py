"""
Minimal setup.py for backwards compatibility.
All project metadata is defined in pyproject.toml.
"""

from setuptools import setup

setup()
