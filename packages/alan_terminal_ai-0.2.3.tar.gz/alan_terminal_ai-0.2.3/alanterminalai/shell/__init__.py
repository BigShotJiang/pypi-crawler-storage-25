"""
Cross-Shell Support - Support for bash, zsh, fish, powershell, etc.
"""

import os
import subprocess
from typing import Dict, Optional


class ShellDetector:
    """Detect current shell"""

    def detect_shell(self) -> Dict[str, str]:
        """Detect current shell"""
        shell_env = os.getenv("SHELL", "/bin/bash")
        shell_name = shell_env.split("/")[-1]

        return {
            "path": shell_env,
            "name": shell_name,
            "type": (
                "posix"
                if shell_name in ["bash", "zsh", "fish", "sh"]
                else "windows"
            ),
        }

    def get_shell_version(self) -> Optional[str]:
        """Get shell version"""
        try:
            result = subprocess.run(
                f"{os.getenv('SHELL')} --version",
                shell=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.stdout.split("\n")[0] if result.stdout else None
        except:
            return None


class ShellIntegration:
    """Shell integration and compatibility"""

    def __init__(self, llm):
        self.llm = llm
        self.detector = ShellDetector()

    def convert_command(self, command: str, target_shell: str) -> str:
        """Convert command to target shell syntax"""
        current = self.detector.detect_shell()["name"]

        # Simple conversions
        conversions = {
            ("bash", "zsh"): {},  # zsh is compatible with bash
            ("bash", "fish"): {
                "export ": "set -x ",
                "&&": "; and ",
                "||": "; or ",
            },
        }

        key = (current, target_shell)
        if key in conversions:
            result = command
            for old, new in conversions[key].items():
                result = result.replace(old, new)
            return result

        return command

    def install_integration(self) -> Dict:
        """Install shell integration files"""
        return {
            "status": "installed",
            "shells": ["bash", "zsh", "fish", "powershell"],
            "config_files": [".bashrc", ".zshrc", ".config/fish/config.fish"],
        }
