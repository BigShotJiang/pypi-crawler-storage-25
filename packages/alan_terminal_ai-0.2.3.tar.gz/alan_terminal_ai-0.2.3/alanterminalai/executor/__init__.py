"""
Agentic Command Execution Module

Features:
- Command explanation engine
- Safety risk assessment (prevents dangerous commands)
- User confirmation with reasoning
- Execution statistics
- Error handling with detailed feedback
"""

import re
import subprocess
from typing import Dict, Optional, Tuple

try:
    from formatter.output_formatter import OutputFormatter
except ImportError:
    try:
        from ..formatter.output_formatter import OutputFormatter
    except ImportError:
        # Fallback - create dummy formatter
        class OutputFormatter:
            def show_success(self, msg):
                print(f"✅ {msg}")

            def show_error(self, msg):
                print(f"❌ {msg}")

            def show_warning(self, msg):
                print(f"⚠️ {msg}")

            def show_command_suggestion(self, *args, **kwargs):
                pass

            def show_command_output(self, *args, **kwargs):
                pass


class AgenticExecutor:
    """Intelligent command executor with safety checks and reasoning"""

    DANGEROUS_PATTERNS = [
        r"rm\s+-rf\s+/",  # rm -rf / (delete everything)
        r"dd\s+if=",  # dd (disk write operations)
        r":(){ *: ; }:",  # Fork bomb
        r"fork\(\)",  # Fork bomb C version
        r"mkfs",  # Format filesystem
        r"fdisk",  # Partition disk
        r"chmod\s+.*777",  # Set dangerous permissions
        r"sudo\s+rm\s+/",  # sudo delete everything
        r"cat\s+/dev/urandom",  # Read from urandom to stdout
    ]

    SAFE_PATTERNS = [
        r"^ls\b",
        r"^pwd\b",
        r"^echo\b",
        r"^cat\b",
        r"^grep\b",
        r"^head\b",
        r"^tail\b",
        r"^wc\b",
        r"^find\b(?!.*-exec.*rm)",
        r"^locate\b",
    ]

    def __init__(
        self, os_info: Dict, formatter: Optional[OutputFormatter] = None
    ):
        """
        Initialize executor

        Args:
            os_info: System information dict with 'type' (unix/windows) and 'name'
            formatter: Optional OutputFormatter for pretty output
        """
        self.os_info = os_info
        self.formatter = formatter or OutputFormatter()
        self.execution_stats = {
            "total_executed": 0,
            "successful": 0,
            "failed": 0,
            "rejected": 0,
            "confirmed_dangerous": 0,
        }

    def is_safe_command(self, command: str) -> bool:
        """Check if command matches safe patterns"""
        for pattern in self.SAFE_PATTERNS:
            if re.search(pattern, command.strip(), re.IGNORECASE):
                return True
        return False

    def is_dangerous_command(self, command: str) -> bool:
        """Check if command matches dangerous patterns"""
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return True
        return False

    def explain_command(self, command: str) -> str:
        """Generate human-readable explanation of what command does"""
        cmd_parts = command.strip().split()
        if not cmd_parts:
            return "Empty command"

        main_cmd = cmd_parts[0].split("/")[-1]  # Get basename

        explanations = {
            "ls": "List directory contents",
            "cd": "Change directory",
            "mkdir": "Create directory",
            "rm": "Remove/delete files",
            "cp": "Copy files",
            "mv": "Move/rename files",
            "cat": "Display file contents",
            "echo": "Print text",
            "grep": "Search text patterns",
            "find": "Find files by criteria",
            "tar": "Archive/compress files",
            "zip": "Create ZIP archive",
            "unzip": "Extract ZIP archive",
            "git": "Version control operations",
            "docker": "Container operations",
            "python": "Run Python code",
            "npm": "Node package management",
            "pip": "Python package management",
            "sudo": "Run as administrator",
            "curl": "Download from URL",
            "wget": "Download file",
            "ssh": "Remote connection",
            "scp": "Secure copy",
            "chmod": "Change file permissions",
            "chown": "Change file owner",
        }

        explanation = explanations.get(main_cmd, f"Execute: {main_cmd}")

        # Add flags description
        if "-R" in command or "-r" in command:
            explanation += " (recursive)"
        if "-f" in command:
            explanation += " (force)"
        if "-v" in command:
            explanation += " (verbose)"
        if "|" in command:
            explanation += " with piping"
        if ">" in command or ">>" in command:
            explanation += " with output redirection"

        return explanation

    def get_risk_level(self, command: str) -> Tuple[str, str]:
        """
        Assess command risk level

        Returns:
            (risk_level, reason) where risk_level is 'safe', 'warning', or 'dangerous'
        """
        if self.is_dangerous_command(command):
            return "dangerous", "Matches dangerous command patterns"

        if self.is_safe_command(command):
            return "safe", "Matches safe command patterns"

        # Check for warning signs
        warning_signs = []
        if "rm" in command or "delete" in command:
            warning_signs.append("involves deletion")
        if "sudo" in command or "sudo" in command.lower():
            warning_signs.append("requires elevated privileges")
        if "&& rm" in command or "| rm" in command:
            warning_signs.append("chains deletion operations")
        if "dd " in command:
            warning_signs.append("low-level disk operation")

        if warning_signs:
            return "warning", f"Warning: " + ", ".join(warning_signs)

        return "safe", "No obvious safety concerns"

    def execute(
        self, command: str, auto_confirm: bool = False, show_output: bool = True
    ) -> Tuple[bool, str, Optional[str]]:
        """
        Execute a command with safety checks

        Args:
            command: Command to execute
            auto_confirm: Skip confirmation for safe commands
            show_output: Display output

        Returns:
            (success, output, error_message)
        """
        risk_level, reason = self.get_risk_level(command)

        # Always ask for confirmation on dangerous commands
        if risk_level == "dangerous":
            self.formatter.show_error(f"❌ DANGEROUS COMMAND BLOCKED: {reason}")
            self.formatter.show_command_suggestion(command, confidence=0.0)
            self.execution_stats["rejected"] += 1
            return False, "", f"Dangerous command rejected: {reason}"

        # Ask for confirmation on warning level
        if risk_level == "warning" and not auto_confirm:
            explanation = self.explain_command(command)
            self.formatter.show_warning(f"⚠️  {reason}")
            self.formatter.show_command_suggestion(
                command, confidence=0.5, explanation=explanation
            )
            # In real scenario, would prompt user
            # For now, return without executing
            return False, "", "User confirmation required"

        # Execute safe commands
        try:
            result = subprocess.run(
                command, shell=True, capture_output=True, text=True, timeout=30
            )

            output = result.stdout
            error = result.stderr if result.returncode != 0 else None
            success = result.returncode == 0

            # Update stats
            self.execution_stats["total_executed"] += 1
            if success:
                self.execution_stats["successful"] += 1
                if show_output and output:
                    self.formatter.show_success(
                        f"✅ Command executed successfully"
                    )
                    self.formatter.show_command_output(output, command)
            else:
                self.execution_stats["failed"] += 1
                self.formatter.show_error(f"❌ Command failed with error")
                if error:
                    self.formatter.show_command_output(error, command)

            return success, output, error

        except subprocess.TimeoutExpired:
            self.execution_stats["failed"] += 1
            self.formatter.show_error("⏱️  Command timeout (30s)")
            return False, "", "Command timeout"
        except Exception as e:
            self.execution_stats["failed"] += 1
            self.formatter.show_error(f"❌ Execution error: {str(e)}")
            return False, "", str(e)

    def get_statistics(self) -> Dict:
        """Get execution statistics"""
        total = self.execution_stats["total_executed"]
        if total > 0:
            success_rate = (self.execution_stats["successful"] / total) * 100
        else:
            success_rate = 0.0

        return {
            **self.execution_stats,
            "success_rate": f"{success_rate:.1f}%",
        }

    def reset_statistics(self) -> None:
        """Reset execution statistics"""
        self.execution_stats = {
            "total_executed": 0,
            "successful": 0,
            "failed": 0,
            "rejected": 0,
            "confirmed_dangerous": 0,
        }
