"""
Plugin System Module - Dynamic plugin management
"""

import importlib
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional


class PluginManager:
    """Manage and load plugins dynamically"""

    def __init__(self, plugins_dir: Optional[str] = None):
        """Initialize plugin manager"""
        if plugins_dir is None:
            plugins_dir = str(Path.home() / ".alan" / "plugins")

        self.plugins_dir = Path(plugins_dir)
        self.plugins_dir.mkdir(parents=True, exist_ok=True)
        self.plugins = {}
        self.plugin_metadata = {}

    def discover_plugins(self) -> List[str]:
        """Discover available plugins"""
        plugin_files = list(self.plugins_dir.glob("*.py"))
        plugins = [f.stem for f in plugin_files if f.stem != "__init__"]
        return plugins

    def load_plugin(self, plugin_name: str) -> bool:
        """Load a plugin dynamically"""
        try:
            plugin_file = self.plugins_dir / f"{plugin_name}.py"
            if not plugin_file.exists():
                return False

            # Add to sys.path
            if str(self.plugins_dir) not in sys.path:
                sys.path.insert(0, str(self.plugins_dir))

            # Import module
            module = importlib.import_module(plugin_name)
            self.plugins[plugin_name] = module

            # Load metadata if available
            if hasattr(module, "PLUGIN_INFO"):
                self.plugin_metadata[plugin_name] = module.PLUGIN_INFO

            return True
        except Exception as e:
            print(f"Error loading plugin {plugin_name}: {e}")
            return False

    def unload_plugin(self, plugin_name: str) -> bool:
        """Unload a plugin"""
        if plugin_name in self.plugins:
            del self.plugins[plugin_name]
            if plugin_name in self.plugin_metadata:
                del self.plugin_metadata[plugin_name]
            return True
        return False

    def get_plugin(self, plugin_name: str) -> Optional[Any]:
        """Get loaded plugin"""
        return self.plugins.get(plugin_name)

    def list_plugins(self) -> Dict[str, Dict]:
        """List all loaded plugins with metadata"""
        result = {}
        for name, module in self.plugins.items():
            result[name] = self.plugin_metadata.get(name, {})
        return result


class DeveloperAssistant:
    """Developer-focused assistant"""

    def __init__(self, llm_manager):
        self.llm_manager = llm_manager

    def review_code(self, code: str) -> Dict:
        """Review code for issues"""
        prompt = f"Review this code and suggest improvements:\n\n{code[:1000]}"
        review = self.llm_manager.generate(prompt)
        return {"review": review, "code_length": len(code)}

    def explain_code(self, code: str) -> str:
        """Explain what code does"""
        prompt = f"Explain what this code does:\n\n{code[:500]}"
        return self.llm_manager.generate(prompt)

    def debug_error(self, error: str) -> Dict:
        """Help debug error message"""
        prompt = f"How do I fix this error?\n\n{error}"
        solution = self.llm_manager.generate(prompt)
        return {"error": error, "solution": solution}


class SysAdminAssistant:
    """System administration assistant"""

    def __init__(self, llm_manager):
        self.llm_manager = llm_manager

    def diagnose_system(self) -> Dict:
        """Diagnose system health"""
        return {
            "status": "healthy",
            "checks": ["cpu", "memory", "disk", "network"],
        }

    def suggest_optimization(self, config: str) -> str:
        """Suggest system optimization"""
        prompt = (
            f"How can I optimize this system configuration?\n\n{config[:500]}"
        )
        return self.llm_manager.generate(prompt)

    def security_audit(self) -> Dict:
        """Run security audit"""
        return {"vulnerabilities": 0, "warnings": 0, "critical_issues": 0}
