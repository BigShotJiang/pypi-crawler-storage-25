"""
Offline Mode - Offline/air-gapped operation support
"""

import json
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional


class NetworkDetector:
    """Detect network availability"""

    def is_internet_available(self) -> bool:
        """Check if internet is available"""
        try:
            # Try multiple DNS servers
            for host in ["8.8.8.8", "1.1.1.1", "google.com"]:
                result = subprocess.run(
                    f"ping -c 1 -W 1 {host}",
                    shell=True,
                    capture_output=True,
                    timeout=3,
                )
                if result.returncode == 0:
                    return True
        except:
            pass
        return False

    def get_network_status(self) -> Dict[str, Any]:
        """Get detailed network status"""
        return {
            "internet": self.is_internet_available(),
            "dns": self._check_dns(),
            "local_network": self._check_local_network(),
        }

    def _check_dns(self) -> bool:
        """Check if DNS is working"""
        try:
            import socket

            socket.gethostbyname("google.com")
            return True
        except:
            return False

    def _check_local_network(self) -> bool:
        """Check if local network is available"""
        try:
            result = subprocess.run(
                "ifconfig", shell=True, capture_output=True, timeout=2
            )
            return result.returncode == 0
        except:
            return False


class OllamaDetector:
    """Detect Ollama installation and status"""

    def is_ollama_installed(self) -> bool:
        """Check if Ollama is installed"""
        try:
            result = subprocess.run(
                "which ollama", shell=True, capture_output=True, timeout=2
            )
            return result.returncode == 0
        except:
            return False

    def is_ollama_running(self) -> bool:
        """Check if Ollama service is running"""
        try:
            result = subprocess.run(
                "curl -s http://localhost:11434/api/tags",
                shell=True,
                capture_output=True,
                timeout=3,
            )
            return result.returncode == 0
        except:
            return False

    def get_available_models(self) -> list:
        """Get locally available Ollama models"""
        try:
            result = subprocess.run(
                "curl -s http://localhost:11434/api/tags",
                shell=True,
                capture_output=True,
                text=True,
                timeout=3,
            )
            if result.returncode == 0:
                data = json.loads(result.stdout)
                return [m["name"] for m in data.get("models", [])]
        except:
            pass
        return []


class OfflineCache:
    """Cache for offline operation"""

    def __init__(self):
        self.cache_dir = Path.home() / ".alan" / "offline_cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def get(self, key: str) -> Optional[Any]:
        """Get cached value"""
        cache_file = self.cache_dir / f"{key}.json"
        if cache_file.exists():
            try:
                with open(cache_file, "r") as f:
                    return json.load(f)
            except:
                pass
        return None

    def set(self, key: str, value: Any) -> bool:
        """Cache a value"""
        try:
            cache_file = self.cache_dir / f"{key}.json"
            with open(cache_file, "w") as f:
                json.dump(value, f)
            return True
        except:
            return False

    def clear(self) -> bool:
        """Clear all cache"""
        try:
            import shutil

            shutil.rmtree(self.cache_dir)
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            return True
        except:
            return False


class OfflineMode:
    """Complete offline/air-gapped mode support"""

    def __init__(self, llm_manager=None):
        self.llm_manager = llm_manager
        self.network_detector = NetworkDetector()
        self.ollama_detector = OllamaDetector()
        self.cache = OfflineCache()

    def is_offline(self) -> bool:
        """Check if operating in offline mode"""
        return not self.network_detector.is_internet_available()

    def handle_status_command(self) -> Dict[str, Any]:
        """Get complete offline/online status"""
        return {
            "mode": "OFFLINE" if self.is_offline() else "ONLINE",
            "timestamp": datetime.now().isoformat(),
            "network": self.network_detector.get_network_status(),
            "ollama_installed": self.ollama_detector.is_ollama_installed(),
            "ollama_running": self.ollama_detector.is_ollama_running(),
            "available_models": self.ollama_detector.get_available_models(),
            "cache_size": self._get_cache_size(),
        }

    def enable_offline_mode(self) -> Dict:
        """Enable offline operation"""
        return {
            "status": "enabled",
            "using_cache": True,
            "using_local_ollama": self.ollama_detector.is_ollama_running(),
            "message": "Operating in offline mode - using local Ollama and cache",
        }

    def _get_cache_size(self) -> str:
        """Get total cache size"""
        try:
            total = sum(
                f.stat().st_size
                for f in self.cache.cache_dir.rglob("*")
                if f.is_file()
            )
            return f"{total / (1024*1024):.2f} MB"
        except:
            return "0 MB"
