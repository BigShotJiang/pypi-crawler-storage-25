"""
Privacy-First Telemetry - Anonymous event tracking
"""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Dict


class PrivacyTelemetry:
    """Privacy-first event tracking (no personal data)"""

    def __init__(self, llm):
        self.llm = llm
        self.storage_dir = Path.home() / ".alan" / "telemetry"
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.enabled = True

    def log_event(self, event_type: str, data: Dict = {}) -> bool:
        """Log anonymous event (no personal data)"""
        if not self.enabled:
            return False

        # Sanitize data - remove any paths, IPs, etc.
        safe_data = {
            "feature": data.get("feature", ""),
            "status": data.get("status", ""),
        }

        event = {
            "type": event_type,
            "data": safe_data,
            "timestamp": datetime.now().isoformat(),
            "session_id": self._get_session_id(),
        }

        return self._write_event(event)

    def _get_session_id(self) -> str:
        """Get anonymous session ID"""
        id_file = self.storage_dir / ".session_id"
        if id_file.exists():
            return id_file.read_text().strip()

        # Generate new session ID (hash of timestamp)
        session_id = hashlib.sha256(str(datetime.now()).encode()).hexdigest()[
            :16
        ]
        id_file.write_text(session_id)
        return session_id

    def _write_event(self, event: Dict) -> bool:
        """Write event to log"""
        try:
            log_file = self.storage_dir / "events.jsonl"
            with open(log_file, "a") as f:
                f.write(json.dumps(event) + "\n")
            return True
        except:
            return False

    def enable_telemetry(self) -> None:
        """Enable telemetry"""
        self.enabled = True

    def disable_telemetry(self) -> None:
        """Disable telemetry"""
        self.enabled = False

    def get_summary(self) -> Dict:
        """Get telemetry summary"""
        return {
            "enabled": self.enabled,
            "session_id": self._get_session_id(),
            "privacy_level": "maximum - no personal data collected",
        }
