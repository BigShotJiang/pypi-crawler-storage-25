"""
Multi-step operations module for Alan Terminal Assistant
Handles complex multi-command workflows
"""
