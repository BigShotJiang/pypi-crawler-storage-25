# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Unit tests for borg.fep."""

import numpy as np

from borg.fep import FEPConfig, refine


def test_refine_is_noop_without_probe():
    resolved = {"layer0.weight": np.array([[1.0, 0.0], [0.0, 2.0]], dtype=np.float32)}
    out = refine(resolved)
    np.testing.assert_array_equal(out["layer0.weight"], resolved["layer0.weight"])


def test_refine_preserves_zero_cells():
    rng = np.random.default_rng(0)
    w = rng.standard_normal((8, 4)).astype(np.float32)
    mask = rng.random((8, 4)) > 0.7
    w = w * mask
    resolved = {"w": w.copy()}

    probe_in = rng.standard_normal((4, 8)).astype(np.float32)
    probe_out = rng.standard_normal((4, 4)).astype(np.float32)

    out = refine(
        resolved,
        probe_inputs=probe_in,
        probe_targets=probe_out,
        config=FEPConfig(steps=2, lr=1e-3, alpha=0.05),
    )

    zero_mask = w == 0
    assert np.all(out["w"][zero_mask] == 0)
