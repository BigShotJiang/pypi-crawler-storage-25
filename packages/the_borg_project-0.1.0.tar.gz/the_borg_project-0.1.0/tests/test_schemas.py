# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Validate the JSON schemas themselves against Draft 2020-12, and verify
that a real SignedEnvelope from `borg.worker` conforms to the schema.

The envelope-schema divergence tracked in the alignment audit is locked
in here: if a future refactor breaks the wire format, this test fails.
"""

import base64
import json
import pathlib
import time

import numpy as np
import pytest
from jsonschema import Draft202012Validator, validate

SCHEMA_DIR = pathlib.Path(__file__).parent.parent / "proto"


def test_contribution_schema_is_valid():
    schema = json.loads((SCHEMA_DIR / "contribution.schema.json").read_text())
    Draft202012Validator.check_schema(schema)


def test_manifest_schema_is_valid():
    schema = json.loads((SCHEMA_DIR / "manifest.schema.json").read_text())
    Draft202012Validator.check_schema(schema)


def test_signed_envelope_conforms_to_contribution_schema():
    """A real SignedEnvelope from borg.worker must validate against the schema."""
    pytest.importorskip("crdt_merge.model.crdt_state")
    from borg.sparse import SparseDelta
    from borg.worker import Signer, to_envelope

    dense = np.zeros((4, 4), dtype=np.float32)
    dense[0, 0] = 1.5
    dense[2, 3] = -0.75
    indices = np.argwhere(dense != 0).astype(np.int32)
    values = dense[indices[:, 0], indices[:, 1]].astype(np.float32)
    delta = SparseDelta(
        indices=indices,
        values=values,
        shape=dense.shape,
        layer="layers.0.attn.q_proj.weight",
        model_id="test/peer",
        version=1,
        trust=np.ones(6, dtype=np.float32) * 0.5,
        source_hash="a" * 64,
        time_steps=8,
        threshold=1.0,
    )
    signer = Signer(secret=b"\x11" * 32)
    env = to_envelope(delta, signer)
    # Build the over-the-wire JSON payload the worker would receive.
    payload = {
        "model_id": env.model_id,
        "layer": env.layer,
        "indices_b64": env.indices_b64,
        "values_b64": env.values_b64,
        "shape": list(env.shape),
        "version": env.version,
        "trust": env.trust,
        "source_hash": env.source_hash,
        "time_steps": env.time_steps,
        "threshold": env.threshold,
        "spike_times_b64": env.spike_times_b64,
        "signature_b64": env.signature_b64,
        "public_key_b64": env.public_key_b64,
        "timestamp": env.timestamp,
    }
    schema = json.loads((SCHEMA_DIR / "contribution.schema.json").read_text())
    validate(instance=payload, schema=schema)
