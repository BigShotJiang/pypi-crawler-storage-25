# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the timing-aware SparseDelta envelope."""

import numpy as np
import pytest

from borg.sparse import SparseDelta, apply_timing, extract, merge_timings


def test_envelope_carries_spike_times():
    dense = np.array([[0.0, 1.0], [2.0, 0.0]], dtype=np.float32)
    times = np.array([[np.nan, 1.0], [3.0, np.nan]], dtype=np.float32)
    d = extract(dense, layer="l", model_id="m", spike_times=times)
    assert d.spike_times is not None
    assert d.spike_times.shape == (2,)


def test_timing_mismatch_rejected():
    with pytest.raises(ValueError):
        SparseDelta(
            indices=np.array([[0, 0]], dtype=np.int32),
            values=np.array([1.0], dtype=np.float32),
            shape=(2, 2),
            layer="l",
            model_id="m",
            spike_times=np.array([1.0, 2.0], dtype=np.float32),
        )


def test_earliest_wins_at_merge():
    d1 = SparseDelta(
        indices=np.array([[0, 0]], dtype=np.int32),
        values=np.array([1.0], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="a",
        spike_times=np.array([5.0], dtype=np.float32),
    )
    d2 = SparseDelta(
        indices=np.array([[0, 0]], dtype=np.int32),
        values=np.array([1.0], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="b",
        spike_times=np.array([2.0], dtype=np.float32),
    )
    merged = merge_timings([d1, d2])
    assert merged is not None
    assert merged[0, 0] == pytest.approx(2.0)
    assert np.isnan(merged[0, 1])


def test_apply_timing_returns_dense_with_nan_background():
    d = SparseDelta(
        indices=np.array([[1, 1]], dtype=np.int32),
        values=np.array([0.5], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="m",
        spike_times=np.array([3.0], dtype=np.float32),
    )
    dense = apply_timing(d)
    assert dense is not None
    assert np.isnan(dense[0, 0])
    assert dense[1, 1] == pytest.approx(3.0)


def test_threshold_carrier_round_trips_through_to_crdt_kwargs():
    from borg.sparse import LayerContribution

    dense = np.eye(3, dtype=np.float32)
    d = extract(dense, layer="x", model_id="m", neuron_threshold=1.7)
    env = LayerContribution(delta=d)
    kwargs = env.to_crdt_kwargs()
    assert kwargs["metadata"]["threshold"] == pytest.approx(1.7)
