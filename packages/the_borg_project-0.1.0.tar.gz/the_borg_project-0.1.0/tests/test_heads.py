# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Head-type detection and registry persistence.

Locks the contract that every absorbed model is tagged with its
capability (causal_lm / masked_lm / embedder / classifier / unknown)
so the universal decoder can dispatch correctly and the app panel can
show the full collective.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.heads import (  # noqa: E402
    CAUSAL_LM,
    CLASSIFIER,
    EMBEDDER,
    HEADS_KEY,
    MASKED_LM,
    UNKNOWN,
    HeadRecord,
    detect_head_type,
    get_registered_heads,
    primary_head,
    register_head,
    summarise_heads,
)
from borg.inference import BorgState, load, save  # noqa: E402


# ---- detection for every supported layout -------------------------------


def test_detect_causal_lm_gpt2_layout():
    sd = {
        "transformer.h.0.attn.c_attn.weight": torch.zeros(16, 48),
        "lm_head.weight": torch.zeros(50257, 768),
    }
    rec = detect_head_type(sd)
    assert rec.head_type == CAUSAL_LM
    assert rec.vocab_size == 50257
    assert rec.hidden_size == 768


def test_detect_masked_lm_roberta_layout():
    sd = {
        "roberta.encoder.layer.0.attention.self.query.weight": torch.zeros(768, 768),
        "lm_head.dense.weight": torch.zeros(768, 768),
        "roberta.embeddings.word_embeddings.weight": torch.zeros(50265, 768),
    }
    rec = detect_head_type(sd)
    assert rec.head_type == MASKED_LM
    assert rec.vocab_size == 50265
    assert rec.hidden_size == 768


def test_detect_masked_lm_bert_cls_layout():
    sd = {
        "bert.encoder.layer.0.attention.self.query.weight": torch.zeros(768, 768),
        "cls.predictions.decoder.weight": torch.zeros(30522, 768),
    }
    rec = detect_head_type(sd)
    assert rec.head_type == MASKED_LM
    assert rec.vocab_size == 30522


def test_detect_embedder_bge_layout():
    """BGE / Sentence-Transformers have a pooler.dense output."""
    sd = {
        "encoder.layer.0.attention.self.query.weight": torch.zeros(1024, 1024),
        "pooler.dense.weight": torch.zeros(1024, 1024),
    }
    rec = detect_head_type(sd)
    assert rec.head_type == EMBEDDER
    assert rec.hidden_size == 1024


def test_detect_classifier_layout():
    """Small output vocab signals a classifier head."""
    sd = {
        "bert.encoder.layer.0.attention.self.query.weight": torch.zeros(768, 768),
        "classifier.weight": torch.zeros(2, 768),  # binary classifier
        "classifier.bias": torch.zeros(2),
    }
    rec = detect_head_type(sd)
    assert rec.head_type == CLASSIFIER
    assert rec.vocab_size == 2


def test_detect_unknown_when_no_head():
    sd = {
        "layer.0.weight": torch.zeros(128, 64),
    }
    rec = detect_head_type(sd)
    assert rec.head_type == UNKNOWN
    assert rec.head_keys == []


# ---- registry persistence -----------------------------------------------


def _fresh_state() -> BorgState:
    return BorgState(
        state_dict={"dummy.weight": torch.zeros(4, 4)},
        thresholds={},
        time_steps=4,
        quantized=False,
        tokenizer_id=None,
    )


def test_register_head_round_trip():
    state = _fresh_state()
    rec = HeadRecord(
        model_id="test/model-a",
        head_type=CAUSAL_LM,
        head_keys=["lm_head.weight"],
        vocab_size=50257,
        hidden_size=768,
        tokenizer_id="test/model-a",
    )
    register_head(state, rec)

    out = get_registered_heads(state)
    assert len(out) == 1
    assert out[0].model_id == "test/model-a"
    assert out[0].head_type == CAUSAL_LM
    assert out[0].vocab_size == 50257


def test_register_multiple_heads_are_dedup_by_model_id():
    state = _fresh_state()
    register_head(state, HeadRecord(
        model_id="m/a", head_type=CAUSAL_LM, head_keys=[], vocab_size=1000, hidden_size=64,
    ))
    register_head(state, HeadRecord(
        model_id="m/b", head_type=EMBEDDER, head_keys=[], hidden_size=128,
    ))
    # Re-register A with different type; latest wins.
    register_head(state, HeadRecord(
        model_id="m/a", head_type=MASKED_LM, head_keys=[], vocab_size=2000, hidden_size=64,
    ))

    out = get_registered_heads(state)
    assert len(out) == 2
    by_id = {r.model_id: r for r in out}
    assert by_id["m/a"].head_type == MASKED_LM
    assert by_id["m/a"].vocab_size == 2000
    assert by_id["m/b"].head_type == EMBEDDER


def test_heads_survive_torch_save_and_load():
    state = _fresh_state()
    register_head(state, HeadRecord(
        model_id="persisted/model",
        head_type=EMBEDDER, head_keys=["pooler.dense.weight"],
        hidden_size=384,
    ))
    with tempfile.TemporaryDirectory() as d:
        p = str(Path(d) / "state.pt")
        save(state, p)
        reloaded = load(p)
    out = get_registered_heads(reloaded)
    assert len(out) == 1
    assert out[0].model_id == "persisted/model"
    assert out[0].head_type == EMBEDDER
    assert out[0].hidden_size == 384


def test_summarise_heads_counts_by_type():
    state = _fresh_state()
    register_head(state, HeadRecord(model_id="a", head_type=CAUSAL_LM, head_keys=[]))
    register_head(state, HeadRecord(model_id="b", head_type=EMBEDDER, head_keys=[]))
    register_head(state, HeadRecord(model_id="c", head_type=EMBEDDER, head_keys=[]))

    summary = summarise_heads(state)
    assert summary["total"] == 3
    assert summary["has_causal_lm"] is True
    assert summary["has_embedder"] is True
    assert summary["has_masked_lm"] is False
    assert len(summary["by_type"][EMBEDDER]) == 2


def test_primary_head_prefers_causal_over_embedder():
    state = _fresh_state()
    register_head(state, HeadRecord(model_id="emb", head_type=EMBEDDER, head_keys=[]))
    register_head(state, HeadRecord(model_id="lm", head_type=CAUSAL_LM, head_keys=[]))
    register_head(state, HeadRecord(model_id="cls", head_type=CLASSIFIER, head_keys=[]))

    head = primary_head(state)
    assert head is not None
    assert head.head_type == CAUSAL_LM
    assert head.model_id == "lm"


def test_heads_key_constant_is_unique():
    """Guard against accidental rename that would orphan all registries."""
    assert HEADS_KEY == "__borg_heads_v1__"
