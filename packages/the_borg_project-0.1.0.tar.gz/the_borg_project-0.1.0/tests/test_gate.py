# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the probe-loss gate in borg.merge."""

import numpy as np
import pytest

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.merge import GateConfig, build_contributions, gate_by_probe  # noqa: E402


def test_gate_disabled_is_passthrough():
    sd = {"m": {"w": np.eye(4, dtype=np.float32)}}
    envs = build_contributions(sd)
    accepted, rejected = gate_by_probe(envs, GateConfig(enabled=False))
    assert len(accepted) == len(envs)
    assert not rejected


def test_gate_rejects_high_loss_bundle():
    sd = {
        "good": {"w": np.eye(4, dtype=np.float32)},
        "bad": {"w": np.full((4, 4), 10.0, dtype=np.float32)},
    }
    envs = build_contributions(sd)

    base = {"w": np.eye(4, dtype=np.float32)}

    def probe(state):
        if state is None:
            return 0.0
        w = state.get("w")
        if w is None:
            return 0.0
        return float(np.mean(np.abs(w)))

    accepted, rejected = gate_by_probe(
        envs,
        GateConfig(enabled=True, tolerance=0.1, probe_fn=probe),
        base=base,
    )
    mids_accepted = {c.delta.model_id for c in accepted}
    mids_rejected = {c.delta.model_id for c in rejected}
    assert "bad" in mids_rejected
    assert "good" in mids_accepted
