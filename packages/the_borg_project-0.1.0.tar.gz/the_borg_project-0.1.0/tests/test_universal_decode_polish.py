# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Regression tests for the universal-decoder polish pass.

Locks in the fixes for the user-reported issues on the HF Space:
1. Pre-capability states retroactively detect their head type.
2. The CoT restate line shows the user's question, not the composed
   system prompt.
3. Embedder + RAG hits produces a natural-language answer, not an
   activation tuple dump.
4. Zero rate vector falls back gracefully without emitting
   "latent signature: norm=0.0000, top activations=..." style text.
"""

from __future__ import annotations

import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.decode import DecodeConfig, universal_decode  # noqa: E402
from borg.heads import (  # noqa: E402
    EMBEDDER,
    UNKNOWN,
    HeadRecord,
    get_registered_heads,
    register_head,
    retroactively_register,
)
from borg.inference import BorgState  # noqa: E402


def _bge_like_state() -> BorgState:
    """Build a state that mimics a BGE absorb: encoder layers + pooler.dense.

    No HEADS_KEY is registered -- simulates legacy state from before the
    capability layer shipped.
    """
    sd = {
        "bert.encoder.layer.0.attention.self.query.weight": torch.eye(16) * 0.3,
        "pooler.dense.weight": torch.eye(16) * 0.3,
    }
    return BorgState(
        state_dict=sd,
        thresholds={"bert.encoder.layer.0.attention.self.query": 1.0,
                    "pooler.dense": 1.0},
        time_steps=2,
        quantized=False,
        tokenizer_id=None,
    )


def test_retroactively_register_detects_legacy_bge_as_embedder():
    """A BGE-shaped state with no HEADS_KEY should get classified as embedder."""
    state = _bge_like_state()
    assert get_registered_heads(state) == []
    n = retroactively_register(state, manifest_model_ids=["BAAI/bge-large-en-v1.5"])
    assert n == 1
    heads = get_registered_heads(state)
    assert len(heads) == 1
    assert heads[0].head_type == EMBEDDER
    assert heads[0].model_id == "BAAI/bge-large-en-v1.5"


def test_retroactively_register_is_noop_when_heads_already_present():
    state = _bge_like_state()
    register_head(state, HeadRecord(
        model_id="pre/existing", head_type=EMBEDDER, head_keys=[],
    ))
    added = retroactively_register(state, manifest_model_ids=["would/not-register"])
    assert added == 0
    heads = get_registered_heads(state)
    assert len(heads) == 1
    assert heads[0].model_id == "pre/existing"


def test_retroactively_register_uses_fallback_id_when_manifest_empty():
    state = _bge_like_state()
    n = retroactively_register(state, manifest_model_ids=None)
    assert n == 1
    heads = get_registered_heads(state)
    assert heads[0].model_id == "legacy/unknown"


def test_universal_decode_auto_registers_on_first_call():
    """`universal_decode` calls `retroactively_register` when no heads exist
    so legacy states dispatch correctly without a code change on the caller."""
    state = _bge_like_state()
    assert get_registered_heads(state) == []
    out = universal_decode(state, "What can you do?", rag_hits=None,
                           config=DecodeConfig(max_new_tokens=1))
    assert isinstance(out, str)
    assert out
    # After the call, heads are registered.
    heads = get_registered_heads(state)
    assert heads, "universal_decode should have retroactively registered a head"
    assert heads[0].head_type == EMBEDDER


def test_restate_line_uses_user_prompt_not_composed():
    """The CoT restate line must not leak the system prompt text even when
    the caller passes a composed prompt for the forward pass."""
    state = _bge_like_state()
    user_prompt = "what is jupiter"
    composed = (
        "You are Borg. Answer in three steps.\n"
        "step 1: restate the question in one sentence.\n"
        "step 2: list the facts you are using and where they came from.\n"
        "step 3: give the final answer. keep it concise.\n\n"
        "question: " + user_prompt
    )
    out = universal_decode(
        state, user_prompt=user_prompt, composed_prompt=composed,
        rag_hits=None, config=DecodeConfig(max_new_tokens=1),
    )
    # Step 1 line must contain the user's question, not "You are Borg".
    step1_line = [ln for ln in out.splitlines() if "step 1" in ln][0]
    assert user_prompt in step1_line
    assert "You are Borg" not in step1_line
    assert "step 1: restate the question" not in step1_line


def test_embedder_with_rag_produces_natural_language():
    """The embedder + RAG path must read like a grounded answer, not an
    activation-index tuple."""
    state = _bge_like_state()
    rag_hits = [
        ("docs/astronomy.txt",
         "Jupiter is the fifth planet from the Sun and the largest in the solar system."),
        ("docs/astronomy.txt",
         "It is a gas giant with at least 95 known moons."),
    ]
    out = universal_decode(
        state, "What is Jupiter?", rag_hits=rag_hits,
        config=DecodeConfig(max_new_tokens=1),
    )
    # Must contain a conversational framing and real content.
    assert "Jupiter" in out
    assert "Based on the documents" in out or "Additionally" in out
    # Activation-tuple dump must NOT appear.
    assert "top activations=" not in out
    assert "norm=0.0000" not in out
    assert "latent signature" not in out


def test_zero_rate_vector_does_not_dump_numbers():
    """Explicitly covers the BGE-on-Space failure mode: spike_forward
    returns zeros, but the response must still be human-readable."""
    state = _bge_like_state()
    out = universal_decode(state, "zzz", rag_hits=None,
                           config=DecodeConfig(max_new_tokens=1))
    for banned in ("top activations=", "norm=0.0000", "cluster=0", "activation=0.000"):
        assert banned not in out, f"zero-rate fallback leaked {banned!r}"
    assert len(out) > 40
