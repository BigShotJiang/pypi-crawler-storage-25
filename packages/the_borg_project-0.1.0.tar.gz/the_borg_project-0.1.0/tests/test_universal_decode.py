# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Universal decoder dispatch chain.

universal_decode must produce a readable string for every combination
of absorbed heads -- including when only an embedder is present, or
when no head is registered at all. This replaces the old "cluster=0
activation=0.000" diagnostic with an actionable, grounded response.
"""

from __future__ import annotations

import numpy as np
import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.decode import DecodeConfig, universal_decode  # noqa: E402
from borg.heads import (  # noqa: E402
    CAUSAL_LM,
    CLASSIFIER,
    EMBEDDER,
    MASKED_LM,
    HeadRecord,
    register_head,
)
from borg.inference import BorgState  # noqa: E402


def _state_with_head(head_type: str) -> BorgState:
    sd = {
        "layer.0.weight": torch.zeros(16, 16),
    }
    # Give layer 0 non-zero values so the forward pass produces activations.
    sd["layer.0.weight"] = torch.eye(16) * 0.5
    state = BorgState(
        state_dict=sd,
        thresholds={"layer.0": 1.0},
        time_steps=2,
        quantized=False,
        tokenizer_id=None,
    )
    record = HeadRecord(
        model_id=f"test/{head_type}",
        head_type=head_type,
        head_keys=[],
        vocab_size=100 if head_type in (CAUSAL_LM, MASKED_LM) else None,
        hidden_size=16 if head_type == EMBEDDER else None,
    )
    register_head(state, record)
    return state


def test_unknown_head_returns_three_step_report():
    """With no generative head, the decoder must still produce readable output."""
    state = BorgState(
        state_dict={"layer.0.weight": torch.eye(16) * 0.5},
        thresholds={"layer.0": 1.0},
        time_steps=2,
        quantized=False,
        tokenizer_id=None,
    )
    out = universal_decode(state, "What is the meaning of life?", rag_hits=None)
    assert isinstance(out, str)
    assert out  # non-empty
    # Three-step CoT structure present.
    assert "step 1" in out
    assert "step 2" in out
    assert "step 3" in out


def test_embedder_without_rag_reports_activation_signature():
    state = _state_with_head(EMBEDDER)
    out = universal_decode(state, "query", rag_hits=None)
    assert "embedder" in out
    assert "no documents" in out.lower() or "upload documents" in out.lower() or "signature" in out


def test_embedder_with_rag_returns_grounded_answer():
    state = _state_with_head(EMBEDDER)
    rag_hits = [
        ("sources/a.txt", "Jupiter is the largest planet in the solar system."),
        ("sources/b.txt", "The gas giant has 95 known moons."),
    ]
    out = universal_decode(state, "Tell me about Jupiter", rag_hits=rag_hits)
    assert "Jupiter" in out
    assert "a.txt" in out or "b.txt" in out


def test_classifier_head_returns_activation_report():
    state = _state_with_head(CLASSIFIER)
    out = universal_decode(state, "classify this", rag_hits=None)
    assert "class" in out.lower()


def test_universal_decode_never_raises_on_missing_lm_head():
    """Even with a CAUSAL_LM head registered but no actual lm_head.weight,
    the decoder must fall back cleanly instead of crashing."""
    state = _state_with_head(CAUSAL_LM)
    # No lm_head.weight in state_dict.
    out = universal_decode(state, "hello", rag_hits=None,
                           config=DecodeConfig(max_new_tokens=1))
    assert isinstance(out, str)
    assert out


def test_universal_decode_output_is_actionable_for_bge_only():
    """Reproduces the user's HF Space scenario: only a BGE embedder absorbed.
    Output must be human-readable, not 'cluster=0 activation=0.000'."""
    state = _state_with_head(EMBEDDER)
    out = universal_decode(state, "What can you do?", rag_hits=None)
    assert "cluster=0" not in out
    assert "activation=0.000" not in out
    # Must mention something concrete about the state of the collective.
    assert "embedder" in out.lower() or "signature" in out.lower()


def test_universal_decode_includes_source_count_in_cot():
    state = _state_with_head(EMBEDDER)
    rag_hits = [("a", "text1"), ("b", "text2")]
    out = universal_decode(state, "q", rag_hits=rag_hits, chain_of_thought=True)
    # Sources appear in the CoT trace.
    assert "sources" in out.lower()
