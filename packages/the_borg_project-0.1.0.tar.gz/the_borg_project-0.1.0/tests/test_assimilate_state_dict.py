# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for `borg.assimilation.assimilate_state_dict`.

This is the source-code-free absorption path used by the `absorb-nord`
workflow. The tests use a synthetic in-memory state dict so they run
fast and offline.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import numpy as np
import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.assimilation import _autodetect_lm_head_key, assimilate_state_dict  # noqa: E402


def _synthetic_snn_state_dict(hidden: int = 16, vocab: int = 64, blocks: int = 2):
    rng = np.random.default_rng(0)
    sd: dict[str, torch.Tensor] = {}
    for b in range(blocks):
        # Sparse body weight (90% sparse).
        w = (rng.standard_normal((hidden, hidden)) * 0.5).astype(np.float32)
        mask = rng.random((hidden, hidden)) > 0.9
        sd[f"transformer.h.{b}.attn.c_attn.weight"] = torch.from_numpy(w * mask)
    sd["lm_head.weight"] = torch.from_numpy(rng.standard_normal((vocab, hidden)).astype(np.float32))
    sd["lm_head.bias"] = torch.from_numpy(rng.standard_normal(vocab).astype(np.float32))
    return sd


def _fresh_borg_path() -> str:
    """Return a path that does not yet exist (so assimilate treats it as cold)."""
    d = tempfile.mkdtemp(prefix="borg-test-")
    return str(Path(d) / "borg_snn.pt")


def test_assimilate_state_dict_emits_manifest_with_contributions():
    sd = _synthetic_snn_state_dict()
    path = _fresh_borg_path()
    manifest = assimilate_state_dict(
        state_dict=sd,
        model_id="zerdovzad/Nord-AI",
        borg_path=path,
        time_steps=4,
        tokenizer_id="meta-llama/Meta-Llama-3-8B-Instruct",
    )
    assert manifest["contributions"]
    assert manifest["contributions"][0]["model_id"] == "zerdovzad/Nord-AI"
    assert len(manifest["merkle_root"]) == 64


def test_assimilated_state_persists_lm_head_and_tokenizer():
    sd = _synthetic_snn_state_dict()
    path = _fresh_borg_path()
    assimilate_state_dict(
        state_dict=sd,
        model_id="zerdovzad/Nord-AI",
        borg_path=path,
        time_steps=4,
        tokenizer_id="meta-llama/Meta-Llama-3-8B-Instruct",
    )
    from borg.decode import LM_BIAS_KEY, LM_HEAD_KEY, has_lm_head
    from borg.inference import load

    state = load(path)
    assert has_lm_head(state)
    assert LM_BIAS_KEY in state.state_dict
    assert LM_HEAD_KEY in state.state_dict
    assert state.tokenizer_id == "meta-llama/Meta-Llama-3-8B-Instruct"


def test_thresholds_passed_to_state():
    sd = _synthetic_snn_state_dict()
    path = _fresh_borg_path()
    thresholds = {f"transformer.h.{b}.attn.c_attn": 0.7 for b in range(2)}
    assimilate_state_dict(
        state_dict=sd,
        model_id="m",
        borg_path=path,
        thresholds=thresholds,
        tokenizer_id="t",
    )
    from borg.inference import load

    state = load(path)
    assert state.thresholds["transformer.h.0.attn.c_attn"] == 0.7


def test_autodetect_lm_head_key_finds_standard_name():
    sd = _synthetic_snn_state_dict()
    assert _autodetect_lm_head_key(sd) == "lm_head.weight"


def test_autodetect_lm_head_key_finds_alternates():
    sd = {
        "transformer.h.0.attn.c_attn.weight": torch.zeros(8, 8),
        "head.weight": torch.zeros(64, 8),
    }
    assert _autodetect_lm_head_key(sd) == "head.weight"


def test_autodetect_lm_head_key_returns_none_when_no_head():
    sd = {"transformer.h.0.attn.c_attn.weight": torch.zeros(8, 8)}
    assert _autodetect_lm_head_key(sd) is None


def test_repeat_assimilation_merges_into_existing_state():
    """Two successive calls must carry BOTH contributions forward.

    The manifest is cumulative by design -- the HF Space diagnostic panel
    needs to show every absorbed model, not just the latest merge.

    Gate disabled because this test asserts cumulative manifest semantics,
    not gate semantics.
    """
    sd_1 = _synthetic_snn_state_dict(hidden=16, blocks=1)
    sd_2 = _synthetic_snn_state_dict(hidden=16, blocks=1)
    path = _fresh_borg_path()
    m1 = assimilate_state_dict(
        state_dict=sd_1, model_id="A", borg_path=path, tokenizer_id="t",
        gate_enabled=False, apply_calibration=False,
    )
    m2 = assimilate_state_dict(
        state_dict=sd_2, model_id="B", borg_path=path, tokenizer_id="t",
        gate_enabled=False, apply_calibration=False,
    )
    # First absorb lands a single contribution.
    assert {c["model_id"] for c in m1["contributions"]} == {"A"}
    # Second absorb's manifest contains both (cumulative).
    assert {c["model_id"] for c in m2["contributions"]} == {"A", "B"}
    with open(path + ".manifest.json") as fh:
        persisted = json.load(fh)
    assert {c["model_id"] for c in persisted["contributions"]} == {"A", "B"}
