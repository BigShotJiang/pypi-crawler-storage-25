# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Locks in that Borg manifests use upstream crdt_merge primitives directly.

The alignment audit flagged that architecture.md names `crdt_merge.core.ORSet`,
`crdt_merge.merkle.MerkleTree`, and `crdt_merge.provenance.ProvenanceLog` as
first-class manifest surfaces, but grep found zero imports. These tests exercise
the real upstream classes through build_manifest so the architecture doc is
kept honest.
"""

from __future__ import annotations

import numpy as np
import pytest

pytest.importorskip("crdt_merge.core")
pytest.importorskip("crdt_merge.merkle")
pytest.importorskip("crdt_merge.provenance")

from borg.merge import (  # noqa: E402
    LayerContribution,
    build_contributions,
    build_manifest,
)


def _make_bundle(seed: int, model_id: str = "m/a") -> list[LayerContribution]:
    rng = np.random.default_rng(seed)
    sd = {
        "layer0.weight": rng.standard_normal((8, 8)).astype(np.float32),
        "layer1.weight": rng.standard_normal((8, 8)).astype(np.float32),
    }
    contribs = build_contributions(
        source_state_dicts={model_id: sd},
        threshold=0.0,
        time_steps=8,
        peer_id="peer",
    )
    return contribs


def test_manifest_merkle_root_matches_upstream_tree():
    from crdt_merge.merkle import MerkleTree

    accepted = _make_bundle(seed=1)
    manifest = build_manifest(
        contributions=accepted,
        rejected=[],
        strategy="ties",
        fep_refine=False,
        seed=0,
        borg_path="/tmp/x",
    )
    tags = sorted(c.delta.tag() for c in accepted)
    reference = MerkleTree(leaves=[{"id": t} for t in tags], leaf_key="id")
    ref_root = reference.root_hash() if callable(reference.root_hash) else reference.root_hash
    assert manifest.merkle_root == ref_root


def test_manifest_contributor_or_set_uses_upstream_crdt():
    from crdt_merge.core import ORSet

    accepted = _make_bundle(seed=2, model_id="facebook/roberta-base")
    manifest = build_manifest(
        contributions=accepted, rejected=[], strategy="ties",
        fep_refine=False, seed=0, borg_path="/tmp/x",
    )
    assert manifest.contributor_or_set is not None
    # Upstream ORSet round-trips through from_dict.
    or_set = ORSet.from_dict(manifest.contributor_or_set)
    assert or_set.contains("facebook/roberta-base")


def test_manifest_provenance_log_uses_upstream_crdt():
    accepted = _make_bundle(seed=3, model_id="openai/gpt2")
    manifest = build_manifest(
        contributions=accepted, rejected=[], strategy="ties",
        fep_refine=False, seed=0, borg_path="/tmp/x",
    )
    log = manifest.provenance_log
    assert log is not None
    # ProvenanceLog.to_dict() shape: has records + summary counts.
    assert "records" in log or "merged_rows" in log
    # At least one record per contribution layer.
    records = log.get("records", [])
    if records:
        assert len(records) >= 2  # two layers in the bundle


def test_manifest_or_set_captures_all_accepted_models():
    from crdt_merge.core import ORSet

    bundle_a = _make_bundle(seed=4, model_id="model/a")
    bundle_b = _make_bundle(seed=5, model_id="model/b")
    manifest = build_manifest(
        contributions=bundle_a + bundle_b,
        rejected=[],
        strategy="ties",
        fep_refine=False,
        seed=0,
        borg_path="/tmp/x",
    )
    or_set = ORSet.from_dict(manifest.contributor_or_set)
    assert or_set.contains("model/a")
    assert or_set.contains("model/b")
