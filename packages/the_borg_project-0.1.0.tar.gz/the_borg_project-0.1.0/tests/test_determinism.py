# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Determinism property test for the CRDT merge pipeline.

Closes the P2 exit gate: three replicas observing the same set of
contributions in shuffled order must resolve to bit-identical outputs
across multiple seeds.
"""

from __future__ import annotations

import hashlib
import random

import numpy as np
import pytest

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.merge import build_contributions, resolve_per_layer  # noqa: E402


def _random_state_dict(seed: int, sparsity: float = 0.7) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    return {
        "layer.0.weight": (
            rng.standard_normal((8, 8)) * (rng.random((8, 8)) > sparsity)
        ).astype(np.float32),
        "layer.1.weight": (
            rng.standard_normal((8, 4)) * (rng.random((8, 4)) > sparsity)
        ).astype(np.float32),
    }


def _resolved_hash(resolved: dict[str, np.ndarray]) -> str:
    h = hashlib.sha256()
    for k in sorted(resolved):
        h.update(k.encode("utf-8"))
        h.update(resolved[k].tobytes())
    return h.hexdigest()


@pytest.mark.parametrize("seed", [0, 1, 2, 7, 13])
def test_three_replicas_converge_to_identical_state(seed: int):
    """Three replicas, same four contributions, three shuffled orders."""
    models = {
        "a": _random_state_dict(seed * 11 + 1),
        "b": _random_state_dict(seed * 11 + 2),
        "c": _random_state_dict(seed * 11 + 3),
        "d": _random_state_dict(seed * 11 + 4),
    }
    envelopes = build_contributions(models, peer_id=f"p-{seed}")

    hashes: list[str] = []
    for replica in range(3):
        rng = random.Random(seed * 31 + replica)
        order = envelopes[:]
        rng.shuffle(order)
        resolved, _timings, _tags = resolve_per_layer(
            order, strategy="linear", seed=seed
        )
        hashes.append(_resolved_hash(resolved))

    assert len(set(hashes)) == 1, f"replicas diverged: {hashes}"


def test_determinism_holds_under_base_state():
    """Merging the same contributions against the same base across shuffled
    orders still converges bit-exactly."""
    models = {m: _random_state_dict(seed + 100) for m, seed in zip("ab", range(2), strict=True)}
    envelopes = build_contributions(models, peer_id="base-test")
    base = _random_state_dict(999)

    r1, _, _ = resolve_per_layer(envelopes, strategy="ties", base=base, seed=42)
    r2, _, _ = resolve_per_layer(list(reversed(envelopes)), strategy="ties", base=base, seed=42)
    assert _resolved_hash(r1) == _resolved_hash(r2)


def test_different_seeds_produce_different_state():
    """Seed controls tie-breaking in some strategies; sanity check it matters."""
    models = {m: _random_state_dict(m_seed) for m, m_seed in zip("ab", (1, 2), strict=True)}
    envelopes = build_contributions(models, peer_id="seed-test")
    base = _random_state_dict(0)

    r1, _, _ = resolve_per_layer(envelopes, strategy="ties", base=base, seed=0)
    r2, _, _ = resolve_per_layer(envelopes, strategy="ties", base=base, seed=42)
    # Weak check: hashes may coincide for tiny inputs; don't fail if they do,
    # but assert at least one layer's bytes differ under different seeds for
    # a strategy known to use them.
    a = _resolved_hash(r1)
    b = _resolved_hash(r2)
    # For TIES with random tie-breaking we expect difference most of the time.
    # Don't hard-fail: this is informational.
    if a == b:
        pytest.skip("tie-breaking did not surface a difference at this size")
    assert a != b
