# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""End-to-end absorption integration test.

Builds a tiny GPT-2 in-process, assimilates it, verifies the resulting
Borg state loads, runs a forward pass, projects logits, and decodes a
short sequence. No network access required: the source model is
instantiated with fresh random weights.

This test closes the P1 exit gate for v0.1.0 by proving the conversion
-> sparse -> E4 -> CRDT resolve -> FEP -> quantise -> decode pipeline
works on a real transformer architecture.
"""

from __future__ import annotations

import os
import tempfile

import numpy as np
import pytest
import torch

pytest.importorskip("transformers")
pytest.importorskip("crdt_merge.model.crdt_state")
pytest.importorskip("spikingjelly")


@pytest.fixture(scope="module")
def tiny_gpt2_path() -> str:
    from transformers import GPT2Config, GPT2LMHeadModel

    cfg = GPT2Config(
        n_layer=2, n_head=2, n_embd=64,
        vocab_size=1024, n_positions=64, n_inner=128,
    )
    torch.manual_seed(0)
    model = GPT2LMHeadModel(cfg).eval()
    tmp = tempfile.mkdtemp(prefix="borg-tiny-gpt2-")
    model.save_pretrained(tmp)
    return tmp


@pytest.fixture
def absorbed_borg_path(tiny_gpt2_path: str) -> str:
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_HUB_OFFLINE"] = "1"
    from borg.assimilation import assimilate

    tmp_state = tempfile.mktemp(prefix="borg-state-", suffix=".pt")
    manifest = assimilate(
        model_ids=[tiny_gpt2_path],
        borg_path=tmp_state,
        strategy="ties",
        seed=42,
        time_steps=4,
    )
    assert manifest["contributions"], "no contributions recorded"
    assert len(manifest["merkle_root"]) == 64
    return tmp_state


def test_absorbed_state_loads_and_reports_lm_head(absorbed_borg_path: str):
    from borg.decode import has_lm_head
    from borg.inference import load

    state = load(absorbed_borg_path)
    assert state.state_dict, "empty state dict"
    assert has_lm_head(state)
    assert state.tokenizer_id


def test_spike_forward_returns_finite_rate_vector(absorbed_borg_path: str):
    from borg.inference import load, spike_forward

    state = load(absorbed_borg_path)
    x = np.full(64, 0.5, dtype=np.float32)
    rates = spike_forward(state, x)
    assert rates.ndim == 2
    assert rates.shape[0] == 1
    assert np.isfinite(rates).all()
    assert rates.min() >= 0
    assert rates.max() <= 1


def test_logits_shape_matches_vocab(absorbed_borg_path: str):
    from borg.decode import logits_from_rates
    from borg.inference import load, spike_forward

    state = load(absorbed_borg_path)
    rates = spike_forward(state, np.full(64, 0.5, dtype=np.float32))
    logits = logits_from_rates(rates, state)
    assert logits.shape[-1] == 1024


def test_decode_token_ids_produces_requested_length(absorbed_borg_path: str):
    from borg.decode import DecodeConfig, decode_token_ids
    from borg.inference import load

    state = load(absorbed_borg_path)
    ids = decode_token_ids(state, [1, 2, 3], DecodeConfig(max_new_tokens=5))
    assert len(ids) == 8
    assert all(0 <= i < 1024 for i in ids)


def test_latency_under_regression_target(absorbed_borg_path: str):
    import time

    from borg.inference import load, spike_forward

    state = load(absorbed_borg_path)
    x = np.full(64, 0.5, dtype=np.float32)
    for _ in range(3):
        spike_forward(state, x)
    samples = []
    for _ in range(20):
        t0 = time.perf_counter()
        spike_forward(state, x)
        samples.append((time.perf_counter() - t0) * 1000.0)
    p95 = float(np.percentile(samples, 95))
    assert p95 < 200.0, f"spike_forward p95 {p95:.2f}ms above 200ms regression target"


def test_determinism_bit_exact(absorbed_borg_path: str):
    from borg.inference import load, spike_forward

    state = load(absorbed_borg_path)
    x = np.full(64, 0.3, dtype=np.float32)
    a = spike_forward(state, x)
    b = spike_forward(state, x)
    np.testing.assert_array_equal(a, b)


def test_performance_report_includes_expected_fields(absorbed_borg_path: str):
    from borg.bench import run_performance_report

    report = run_performance_report(
        state_path=absorbed_borg_path,
        forward_samples=10,
        decode_tokens=4,
    )
    assert report.params_total > 0
    assert 0.0 <= report.body_sparsity <= 1.0
    assert report.body_sparsity >= 0.80
    assert report.determinism_bitexact
    assert report.forward_ms_p95 < 200.0
