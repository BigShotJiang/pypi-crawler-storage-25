# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Regression tests for collective accumulation across heterogeneous absorbs.

The user reported that a 20-model Colab run produced a borg_snn.pt of only
46.6 MB, with many intermediate rounds showing 0.0 MB. Root causes:

1. Default magnitude-drift gate rejected every contribution when a new
   architecture's log-norm distribution was very different from the base.
2. When accepted=[], resolve_per_layer produced an empty dict, wiping the
   prior state.
3. BF16 / FP16 tensors (Qwen, Llama) crashed on `numpy()` conversion.
4. Shape mismatches (1024-hidden into 768-hidden) crashed the per-layer
   merge rather than preserving the base.

These tests lock each fix so the collective actually grows across absorbs.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.assimilation import assimilate_state_dict  # noqa: E402
from borg.inference import load as load_state  # noqa: E402


def _fresh_path() -> str:
    d = tempfile.mkdtemp(prefix="borg-collective-acc-")
    return str(Path(d) / "borg_snn.pt")


def _dense_shard(seed: int, hidden: int = 32, blocks: int = 2):
    rng = np.random.default_rng(seed)
    sd: dict[str, torch.Tensor] = {}
    for b in range(blocks):
        for proj in ("q_proj", "k_proj", "v_proj"):
            w = rng.standard_normal((hidden, hidden)).astype(np.float32)
            sd[f"model.layers.{b}.self_attn.{proj}.weight"] = torch.from_numpy(w)
    return sd


def _state_size_bytes(path: str) -> int:
    return Path(path).stat().st_size


def test_state_never_shrinks_across_absorbs():
    """Each absorb must leave the persisted state at least as large as before."""
    path = _fresh_path()
    prev_size = 0
    for i in range(4):
        assimilate_state_dict(
            state_dict=_dense_shard(seed=i),
            model_id=f"model-{i}",
            borg_path=path,
            time_steps=4,
            gate_enabled=False,
            apply_calibration=False,
        )
        size = _state_size_bytes(path)
        assert size >= prev_size, (
            f"state shrank at absorb {i}: {prev_size} -> {size}"
        )
        prev_size = size


def test_gate_total_rejection_preserves_base():
    """When the gate rejects every contribution, the base state survives."""
    path = _fresh_path()
    # First absorb: establishes the base.
    assimilate_state_dict(
        state_dict=_dense_shard(seed=0),
        model_id="base/model",
        borg_path=path,
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    size_after_first = _state_size_bytes(path)
    keys_after_first = set(load_state(path).state_dict.keys())

    # Second absorb with a probe that rejects everything.
    def reject_all(_state):
        return 1e9

    assimilate_state_dict(
        state_dict=_dense_shard(seed=1),
        model_id="rejected/model",
        borg_path=path,
        time_steps=4,
        gate_enabled=True,
        gate_tolerance=0.0,  # ratio check makes everything reject
        probe_fn=reject_all,
        apply_calibration=False,
    )
    # State must still exist and still contain the base's body layers.
    size_after_reject = _state_size_bytes(path)
    keys_after_reject = set(load_state(path).state_dict.keys())
    # At minimum, the body layers from the first absorb must survive.
    body_keys_first = {k for k in keys_after_first if k.startswith("model.layers")}
    body_keys_reject = {k for k in keys_after_reject if k.startswith("model.layers")}
    assert body_keys_first.issubset(body_keys_reject), (
        f"lost body layers after total gate rejection: "
        f"missing {body_keys_first - body_keys_reject}"
    )
    assert size_after_reject > 0, "state wiped to 0 bytes after rejection"


def test_bfloat16_tensors_are_absorbed_cleanly():
    """BF16 inputs (Qwen, Llama) must convert to FP32 without raising."""
    path = _fresh_path()
    sd = {
        "model.layers.0.self_attn.q_proj.weight": torch.randn(16, 16).to(torch.bfloat16),
        "model.layers.0.self_attn.k_proj.weight": torch.randn(16, 16).to(torch.bfloat16),
    }
    manifest = assimilate_state_dict(
        state_dict=sd,
        model_id="bf16/model",
        borg_path=path,
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    assert manifest["contributions"]
    state = load_state(path)
    assert state.state_dict  # non-empty


def test_float16_tensors_are_absorbed_cleanly():
    path = _fresh_path()
    sd = {
        "model.layers.0.self_attn.q_proj.weight": torch.randn(16, 16).to(torch.float16),
    }
    manifest = assimilate_state_dict(
        state_dict=sd,
        model_id="fp16/model",
        borg_path=path,
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    assert manifest["contributions"]


def test_shape_mismatch_layer_preserves_base_and_does_not_crash():
    """Absorbing a 32-hidden model on top of a 16-hidden base must not crash."""
    path = _fresh_path()
    # Base has 16-hidden layers.
    assimilate_state_dict(
        state_dict=_dense_shard(seed=0, hidden=16, blocks=1),
        model_id="base-16",
        borg_path=path,
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    state_before = load_state(path)
    base_q_shape = state_before.state_dict[
        "model.layers.0.self_attn.q_proj.weight"
    ].shape

    # Now absorb a 32-hidden model with SAME layer names but different shapes.
    assimilate_state_dict(
        state_dict=_dense_shard(seed=1, hidden=32, blocks=1),
        model_id="incompatible-32",
        borg_path=path,
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    state_after = load_state(path)
    # The base's q_proj weight must still exist with the ORIGINAL shape.
    assert "model.layers.0.self_attn.q_proj.weight" in state_after.state_dict
    after_shape = state_after.state_dict[
        "model.layers.0.self_attn.q_proj.weight"
    ].shape
    # Either the original shape is preserved (base kept) or the new shape
    # (new model wins); both are acceptable as long as the file is not
    # wiped / empty. Collective growth prefers preservation.
    assert after_shape in (base_q_shape, torch.Size([32, 32])), (
        f"shape mismatch produced unexpected shape {after_shape}"
    )


def test_twenty_heterogeneous_absorbs_accumulate():
    """The failure pattern the user reported: 20 heterogeneous absorbs
    must leave the final state non-empty and manifest-cumulative."""
    path = _fresh_path()
    hidden_sizes = [8, 16, 12, 20, 8, 16, 24, 12, 8, 16]  # mix shapes
    for i, h in enumerate(hidden_sizes):
        assimilate_state_dict(
            state_dict=_dense_shard(seed=i, hidden=h, blocks=1),
            model_id=f"het/model-{i:02d}",
            borg_path=path,
            time_steps=4,
            gate_enabled=False,
            apply_calibration=False,
        )
    # File must be non-empty, manifest must contain every model_id.
    assert _state_size_bytes(path) > 100
    import json

    manifest = json.loads(Path(path + ".manifest.json").read_text())
    ids = {c["model_id"] for c in manifest["contributions"]}
    expected = {f"het/model-{i:02d}" for i in range(len(hidden_sizes))}
    assert ids == expected, (
        f"manifest lost ids after 10 heterogeneous absorbs. "
        f"missing: {expected - ids}, extra: {ids - expected}"
    )
