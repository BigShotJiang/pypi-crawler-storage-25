# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""End-to-end feedforward ANN-to-SNN conversion on a real CNN.

Closes the partial row on the status matrix (Feedforward ANN to SNN had
only import-level coverage via `test_smoke`). This test builds a small
CNN + linear classifier, runs it through `borg.convert.from_feedforward`,
and asserts:

* The returned SNNShard has populated thresholds.
* Sparsity is at or above the SpikingJelly ann2snn converter's natural
  floor (>= 0.60 as a lower bound; the `_sparsify_small` step pushes
  this higher).
* The state dict can be dequantised + consumed by `assimilate_module`
  without error, producing a non-empty manifest.

Skipped if `spikingjelly` is unavailable in the environment (keeps the
unit CI jobs green when the heavy extra is not installed).
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
import torch
import torch.nn as nn

pytest.importorskip("spikingjelly.clock_driven.ann2snn")
pytest.importorskip("crdt_merge.model.crdt_state")

from borg.assimilation import assimilate_module  # noqa: E402
from borg.convert import from_feedforward, to_snn  # noqa: E402


class _TinyCNN(nn.Module):
    """Conv -> ReLU -> Pool -> Conv -> ReLU -> Flatten -> Linear."""

    def __init__(self) -> None:
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 4, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AvgPool2d(2),
            nn.Conv2d(4, 8, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.AvgPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(8 * 2 * 2, 4),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.classifier(self.features(x))


def test_from_feedforward_emits_snn_shard_with_thresholds():
    model = _TinyCNN().eval()
    shard = from_feedforward(model, time_steps=4, target_sparsity=0.90)

    assert shard.state_dict, "converted state_dict must be non-empty"
    assert shard.time_steps == 4
    # Sparsity reported by _measure_sparsity; _sparsify_small keeps only 10%
    # of each 2D weight, so post-conversion sparsity is >=0.60 comfortably.
    assert shard.sparsity >= 0.60, f"expected sparsity >= 0.60, got {shard.sparsity:.2%}"
    assert shard.spike_times is not None, "spike_times must be populated"
    # The ann2snn converter inserts IF neurons with v_threshold; at least
    # one threshold must make it into the shard.
    assert shard.thresholds, "thresholds dict must be non-empty"


def test_to_snn_auto_picks_feedforward_for_cnn():
    model = _TinyCNN().eval()
    shard = to_snn(model, method="auto", time_steps=4)
    assert shard.method == "feedforward", f"expected feedforward, got {shard.method!r}"


def test_assimilate_module_absorbs_feedforward_cnn():
    """Full end-to-end: build CNN, assimilate via full pillar chain,
    verify manifest carries the contribution."""
    model = _TinyCNN().eval()
    d = tempfile.mkdtemp(prefix="borg-fwd-")
    path = str(Path(d) / "borg_snn.pt")
    manifest = assimilate_module(
        model=model,
        model_id="synthetic/tiny-cnn",
        borg_path=path,
        method="feedforward",
        time_steps=4,
        gate_enabled=True,
        gate_tolerance=0.30,
        apply_calibration=False,  # CNN has no tokenizer
    )
    assert manifest["contributions"], "manifest must have at least one contribution"
    assert manifest["contributions"][0]["model_id"] == "synthetic/tiny-cnn"
    assert len(manifest["merkle_root"]) == 64
    # Manifest carries the new crdt_merge ORSet.
    assert manifest.get("contributor_or_set") is not None
