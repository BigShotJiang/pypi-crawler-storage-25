# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the MBE-style transformer conversion path."""

import pytest
from torch import nn

from borg.convert import SNNShard, _autodetect, from_transformer


class _TinyAttention(nn.Module):
    def __init__(self, dim: int = 8):
        super().__init__()
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)

    def forward(self, x):
        return self.v_proj(x)


class _TinyMLP(nn.Module):
    def __init__(self, dim: int = 8):
        super().__init__()
        self.fc1 = nn.Linear(dim, dim)
        self.fc2 = nn.Linear(dim, dim)

    def forward(self, x):
        return self.fc2(self.fc1(x))


class _TinyTransformerBlock(nn.Module):
    def __init__(self, dim: int = 8):
        super().__init__()
        self.attention = _TinyAttention(dim)
        self.mlp = _TinyMLP(dim)

    def forward(self, x):
        return self.mlp(self.attention(x))


def test_autodetect_selects_transformer_when_attention_present():
    model = _TinyTransformerBlock()
    assert _autodetect(model) == "transformer"


def test_from_transformer_emits_mbe_coefficients():
    model = _TinyTransformerBlock()
    shard = from_transformer(model, time_steps=16, target_sparsity=0.5)
    assert isinstance(shard, SNNShard)
    assert shard.method == "transformer"
    assert any(k.endswith(".mbe_alpha") for k in shard.state_dict)
    assert any(k.endswith(".mbe_beta") for k in shard.state_dict)


def test_from_transformer_sets_layer_thresholds():
    model = _TinyTransformerBlock()
    shard = from_transformer(model, time_steps=8, target_sparsity=0.5)
    expected = {
        "attention.q_proj",
        "attention.k_proj",
        "attention.v_proj",
        "mlp.fc1",
        "mlp.fc2",
    }
    assert expected.issubset(shard.thresholds.keys())
    for layer in expected:
        assert shard.thresholds[layer] == pytest.approx(1.0)
