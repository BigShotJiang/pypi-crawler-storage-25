# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""MBE fidelity benchmark executed as a test.

Asserts the converted SNN preserves structure on a small reference
transformer. Floors are deliberately loose because the reference block
is randomly initialised. When a pretrained shard is available these
become tighter bounds.
"""

from borg.bench import run_mbe_fidelity


def test_mbe_fidelity_runs_and_reports_sparsity():
    report = run_mbe_fidelity(dim=16, n_samples=16, time_steps=16, seed=42)
    assert report.output_dim == 16
    assert 0.0 <= report.sparsity <= 1.0
    assert report.n_samples == 16


def test_mbe_fidelity_is_reproducible():
    a = run_mbe_fidelity(dim=16, n_samples=8, time_steps=8, seed=7)
    b = run_mbe_fidelity(dim=16, n_samples=8, time_steps=8, seed=7)
    assert a.cosine_mean == b.cosine_mean
    assert a.spearman_mean == b.spearman_mean
    assert a.pearson_mean == b.pearson_mean
    assert a.sparsity == b.sparsity


def test_mbe_fidelity_cosine_in_valid_range():
    report = run_mbe_fidelity(dim=8, n_samples=8, time_steps=8, seed=42)
    assert -1.0 <= report.cosine_mean <= 1.0
    assert -1.0 <= report.pearson_mean <= 1.0
    assert -1.0 <= report.spearman_mean <= 1.0
