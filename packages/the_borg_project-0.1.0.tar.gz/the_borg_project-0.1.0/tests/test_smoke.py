# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Import-level smoke tests."""

import importlib


def test_package_importable():
    mod = importlib.import_module("borg")
    assert hasattr(mod, "__version__")


def test_submodules_importable():
    for name in [
        "borg.sparse",
        "borg.merge",
        "borg.fep",
        "borg.inference",
        "borg.decode",
        "borg.convert",
        "borg.assimilation",
        "borg.app",
        "borg.worker",
        "borg.rag",
        "borg.rag.ingest",
        "borg.rag.retrieve",
    ]:
        importlib.import_module(name)


def test_e4_module_importable_when_crdt_merge_available():
    try:
        import crdt_merge.e4  # noqa: F401
    except ImportError:
        return
    importlib.import_module("borg.e4")
