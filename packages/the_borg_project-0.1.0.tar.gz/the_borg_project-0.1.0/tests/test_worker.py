# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the FastAPI worker and Ed25519-signed envelopes."""

import numpy as np
import pytest

from borg.sparse import SparseDelta
from borg.worker import MergeQueue, Signer, from_envelope, to_envelope


def _toy_delta() -> SparseDelta:
    return SparseDelta(
        indices=np.array([[0, 0], [1, 1]], dtype=np.int32),
        values=np.array([1.0, -1.0], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="m",
        trust=np.ones(6, dtype=np.float32),
        spike_times=np.array([0.0, 1.0], dtype=np.float32),
    )


def test_envelope_round_trip_preserves_content():
    signer = Signer(secret=b"\x01" * 32)
    env = to_envelope(_toy_delta(), signer)
    recovered = from_envelope(env)
    np.testing.assert_array_equal(recovered.indices, _toy_delta().indices)
    np.testing.assert_array_equal(recovered.values, _toy_delta().values)


def test_signature_verification_accepts_untampered():
    signer = Signer(secret=b"\x02" * 32)
    env = to_envelope(_toy_delta(), signer)
    assert Signer.verify(env)


def test_signature_verification_rejects_tampered_values():
    signer = Signer(secret=b"\x03" * 32)
    env = to_envelope(_toy_delta(), signer)
    tampered = env
    tampered.values_b64 = "AAAAAAAA"
    assert not Signer.verify(tampered)


def test_queue_accepts_valid_envelope_and_dedupes():
    signer = Signer(secret=b"\x04" * 32)
    env = to_envelope(_toy_delta(), signer)
    queue = MergeQueue(flush_threshold=1000)
    assert queue.submit(env)
    assert queue.pending() == 1
    assert queue.submit(env)
    assert queue.pending() == 1


def test_queue_rejects_invalid_signature():
    signer = Signer(secret=b"\x05" * 32)
    env = to_envelope(_toy_delta(), signer)
    env.signature_b64 = "AAAA"
    queue = MergeQueue(flush_threshold=1000)
    assert not queue.submit(env)
    assert queue.pending() == 0


def test_ed25519_path_exercised_when_cryptography_available():
    pytest.importorskip("cryptography")
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    signer = Signer(secret=bytes(range(32)))
    assert signer._ed25519 is not None  # real ed25519, not HMAC fallback
    env = to_envelope(_toy_delta(), signer)
    assert Signer.verify(env)
    raw_sig = signer.sign(b"test message")
    assert len(raw_sig) == 64
    _ = Ed25519PrivateKey  # ensure the symbol is the one tests expect


def test_fastapi_app_constructs_if_available():
    fastapi = pytest.importorskip("fastapi")
    from borg.worker import create_app

    app = create_app()
    routes = {r.path for r in app.router.routes}
    assert "/contribute" in routes
    assert "/gossip" in routes
    assert "/health" in routes
    _ = fastapi


def test_queue_flush_fires_callback_at_threshold():
    signer = Signer(secret=b"\x06" * 32)
    flushed: list = []
    queue = MergeQueue(flush_threshold=2, flush_fn=lambda batch: flushed.extend(batch))
    env1 = to_envelope(_toy_delta(), signer)
    d2 = SparseDelta(
        indices=np.array([[0, 1]], dtype=np.int32),
        values=np.array([0.5], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="n",
        trust=np.ones(6, dtype=np.float32),
    )
    env2 = to_envelope(d2, signer)
    queue.submit(env1)
    queue.submit(env2)
    assert len(flushed) == 2
    assert queue.pending() == 0
