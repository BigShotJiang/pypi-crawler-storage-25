# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

"""Offline tests for `borg.gcs`.

The upload path needs `google.cloud.storage` + real credentials, so
these tests only cover the pieces that are testable without a live
bucket: version serialisation round-trip, sha256 stability across
runs, URL construction, and the download helper against a local HTTP
server stand-in for GCS public-read.
"""

from __future__ import annotations

import http.server
import json
import socketserver
import tempfile
import threading
import time
from pathlib import Path

import pytest

from borg.gcs import (
    BorgVersion,
    MODEL_KEY,
    VERSION_KEY,
    _sha256,
    fetch_version,
    public_url,
    sync_from_gcs,
)


def test_public_url_shape():
    assert public_url("bucket", "obj") == "https://storage.googleapis.com/bucket/obj"


def test_version_json_roundtrip():
    v = BorgVersion(sha256="a" * 64, size_bytes=123, uploaded_at=1.0,
                    n_absorbed=2, bucket="b")
    blob = v.to_json()
    assert BorgVersion.from_json(blob) == v


def test_sha256_is_stable():
    d = Path(tempfile.mkdtemp())
    p = d / "x.bin"
    p.write_bytes(b"deterministic")
    assert _sha256(p) == _sha256(p)


@pytest.fixture
def local_gcs_mirror():
    """Spin up a local HTTP server that mimics GCS public-read."""
    root = Path(tempfile.mkdtemp())

    class _Handler(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a, **kw):  # silence
            return

    class _ReusableTCPServer(socketserver.TCPServer):
        allow_reuse_address = True

    # Serve from root. Map /bucket-name/key -> root/bucket-name/key.
    import os
    os.chdir(root)
    httpd = _ReusableTCPServer(("127.0.0.1", 0), _Handler)
    port = httpd.server_address[1]
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    try:
        yield root, port
    finally:
        httpd.shutdown()


def _write_remote(root: Path, bucket: str, key: str, blob: bytes):
    p = root / bucket / key
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(blob)


def test_fetch_version_missing(local_gcs_mirror, monkeypatch):
    root, port = local_gcs_mirror
    monkeypatch.setattr(
        "borg.gcs.public_url",
        lambda bucket, key: f"http://127.0.0.1:{port}/{bucket}/{key}",
    )
    # No version file yet.
    assert fetch_version(bucket="bkt") is None


def test_sync_downloads_on_first_run(local_gcs_mirror, monkeypatch):
    root, port = local_gcs_mirror
    monkeypatch.setattr(
        "borg.gcs.public_url",
        lambda bucket, key: f"http://127.0.0.1:{port}/{bucket}/{key}",
    )
    _write_remote(root, "bkt", MODEL_KEY, b"\x00\x01\x02\x03" * 1024)
    remote_version = BorgVersion(sha256="sha", size_bytes=4096,
                                  uploaded_at=time.time(), n_absorbed=3,
                                  bucket="bkt")
    _write_remote(root, "bkt", VERSION_KEY, remote_version.to_json().encode())

    local_dir = Path(tempfile.mkdtemp())
    model_path, v = sync_from_gcs(local_dir=local_dir, bucket="bkt")
    assert model_path is not None
    assert model_path.read_bytes() == b"\x00\x01\x02\x03" * 1024
    assert v.n_absorbed == 3
    assert (local_dir / VERSION_KEY).exists()


def test_sync_skips_download_when_hash_matches(local_gcs_mirror, monkeypatch):
    root, port = local_gcs_mirror
    monkeypatch.setattr(
        "borg.gcs.public_url",
        lambda bucket, key: f"http://127.0.0.1:{port}/{bucket}/{key}",
    )
    payload = b"stable payload"
    _write_remote(root, "bkt", MODEL_KEY, payload)
    v = BorgVersion(sha256="stable", size_bytes=len(payload),
                    uploaded_at=time.time(), n_absorbed=1, bucket="bkt")
    _write_remote(root, "bkt", VERSION_KEY, v.to_json().encode())

    local_dir = Path(tempfile.mkdtemp())
    m1, _ = sync_from_gcs(local_dir=local_dir, bucket="bkt")
    mtime_first = m1.stat().st_mtime

    # Re-run; same sha256 on disk should skip the re-download.
    time.sleep(0.01)
    m2, _ = sync_from_gcs(local_dir=local_dir, bucket="bkt")
    assert m2 == m1
    assert m2.stat().st_mtime == mtime_first
