# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the event-driven SNN forward pass."""

import numpy as np
import torch

from borg.inference import BorgState, quantize_int8, spike_forward


def _tiny_state(width_in: int = 8, width_mid: int = 8, width_out: int = 4) -> BorgState:
    rng = np.random.default_rng(0)
    w1 = torch.from_numpy((rng.standard_normal((width_in, width_mid)) * 0.5).astype(np.float32))
    w2 = torch.from_numpy((rng.standard_normal((width_mid, width_out)) * 0.5).astype(np.float32))
    return BorgState(
        state_dict={"layer.0.weight": w1, "layer.1.weight": w2},
        thresholds={"layer.0.weight": 0.5, "layer.1.weight": 0.5},
        time_steps=8,
    )


def test_forward_returns_rate_vector_of_output_width():
    state = _tiny_state()
    x = np.full(8, 0.5, dtype=np.float32)
    rates = spike_forward(state, x)
    assert rates.shape == (1, 4)
    assert rates.min() >= 0
    assert rates.max() <= 1


def test_quantized_forward_matches_shape():
    state = quantize_int8(_tiny_state())
    x = np.full(8, 0.5, dtype=np.float32)
    rates = spike_forward(state, x)
    assert rates.shape == (1, 4)


def test_empty_state_returns_empty_rates():
    state = BorgState(state_dict={}, thresholds={}, time_steps=4)
    x = np.zeros(8, dtype=np.float32)
    rates = spike_forward(state, x)
    assert rates.shape[0] == 1
    assert rates.shape[1] == 0
