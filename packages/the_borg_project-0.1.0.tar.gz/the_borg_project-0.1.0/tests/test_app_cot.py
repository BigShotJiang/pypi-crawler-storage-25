# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the chain-of-thought prompt composer in borg.app."""

from borg.app import SYSTEM_PROMPT, compose_prompt


def test_system_prompt_enumerates_three_steps():
    assert "step 1" in SYSTEM_PROMPT
    assert "step 2" in SYSTEM_PROMPT
    assert "step 3" in SYSTEM_PROMPT


def test_compose_prompt_with_context():
    out = compose_prompt("why?", context="fact about water")
    assert "context:" in out
    assert "fact about water" in out
    assert out.endswith("why?")


def test_compose_prompt_without_context():
    out = compose_prompt("hi")
    assert "context:" not in out
    assert out.endswith("hi")
