# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the Borg Collective peer-to-peer gossip layer.

Covers:
* CID determinism -- same envelope produces the same CID
* Bloom digest -- no false negatives, acceptable false positives
* Pairwise sync -- two peers converge after one round
* N-peer convergence -- 5 peers converge after O(log N) rounds
* Dedup -- same model_id never re-absorbed
* Unsigned-envelope rejection
* Bootstrap -- seed list resolves with env override
"""

from __future__ import annotations

import random

import numpy as np
import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.collective import (  # noqa: E402
    BloomDigest,
    DEFAULT_SEEDS,
    Peer,
    cid_of,
    collective_assimilate,
    local_sync,
    resolve_seeds,
    validate_cid,
)
from borg.sparse import SparseDelta  # noqa: E402
from borg.worker import Signer, to_envelope  # noqa: E402


def _mk_envelope(seed: int, model_id: str, layer: str = "layers.0.q.weight"):
    rng = np.random.default_rng(seed)
    dense = rng.standard_normal((4, 4)).astype(np.float32)
    dense[dense < 0.8] = 0
    indices = np.argwhere(dense != 0).astype(np.int32)
    values = dense[indices[:, 0], indices[:, 1]].astype(np.float32)
    delta = SparseDelta(
        indices=indices, values=values, shape=(4, 4),
        layer=layer, model_id=model_id, version=1,
        trust=np.ones(6, dtype=np.float32),
        source_hash=f"{seed:064x}", time_steps=8, threshold=1.0,
    )
    signer = Signer(secret=bytes([seed % 256]) * 32)
    return to_envelope(delta, signer), signer


# ---- CID tests -----------------------------------------------------------


def test_cid_is_deterministic():
    env, _ = _mk_envelope(seed=1, model_id="m/a")
    assert cid_of(env) == cid_of(env)


def test_cid_is_valid_hex():
    env, _ = _mk_envelope(seed=2, model_id="m/b")
    cid = cid_of(env)
    assert validate_cid(cid)
    assert not validate_cid("nothex")
    assert not validate_cid("a" * 63)  # too short


def test_different_envelopes_have_different_cids():
    a, _ = _mk_envelope(seed=3, model_id="m/c")
    b, _ = _mk_envelope(seed=4, model_id="m/d")
    assert cid_of(a) != cid_of(b)


# ---- Bloom tests ---------------------------------------------------------


def test_bloom_no_false_negatives():
    b = BloomDigest()
    items = [f"cid-{i:04d}" for i in range(128)]
    for it in items:
        b.add(it)
    for it in items:
        assert b.contains(it), f"Bloom dropped {it}"


def test_bloom_from_cids_round_trips_via_b64():
    cids = [f"cid-{i:04d}" for i in range(50)]
    digest = BloomDigest.from_cids(cids)
    restored = BloomDigest.from_b64(digest.to_b64())
    for c in cids:
        assert restored.contains(c)


def test_bloom_union_contains_both():
    a = BloomDigest.from_cids(["x"])
    b = BloomDigest.from_cids(["y"])
    u = a.union(b)
    assert u.contains("x")
    assert u.contains("y")


# ---- Peer tests ----------------------------------------------------------


def test_peer_accepts_and_dedups():
    peer = Peer(peer_id="p0")
    env, _ = _mk_envelope(seed=5, model_id="m/e")
    cid1 = peer.accept(env)
    cid2 = peer.accept(env)  # dup
    assert cid1 == cid2
    assert peer.has(cid1)
    assert len(peer.cids()) == 1
    assert "m/e" in peer.absorbed_model_ids()


def test_peer_rejects_unsigned_envelope():
    peer = Peer(peer_id="p1")
    env, _ = _mk_envelope(seed=6, model_id="m/f")
    # Corrupt the signature.
    tampered = env
    tampered.signature_b64 = "AAAA"
    assert peer.accept(tampered) is None


def test_peer_missing_from_excludes_held_cids():
    a = Peer(peer_id="a")
    b = Peer(peer_id="b")
    env, _ = _mk_envelope(seed=7, model_id="m/g")
    a.accept(env)
    b.accept(env)
    assert a.missing_from(b.bloom()) == []


# ---- Pairwise sync -------------------------------------------------------


def test_local_sync_converges_two_peers():
    a = Peer(peer_id="a")
    b = Peer(peer_id="b")
    env_a, _ = _mk_envelope(seed=10, model_id="only-a")
    env_b, _ = _mk_envelope(seed=11, model_id="only-b")
    a.accept(env_a)
    b.accept(env_b)
    ra, rb = local_sync(a, b)
    assert ra.sent == 1 and ra.received == 1
    assert rb.sent == 1 and rb.received == 1
    assert set(a.cids()) == set(b.cids())
    assert a.absorbed_model_ids() == b.absorbed_model_ids() == {"only-a", "only-b"}


def test_five_peers_converge_via_random_pairwise():
    """N=5 peers each absorb a unique model, random pairwise gossip until convergence."""
    rng = random.Random(42)
    peers = [Peer(peer_id=f"p{i}") for i in range(5)]
    for i, p in enumerate(peers):
        env, _ = _mk_envelope(seed=100 + i, model_id=f"model-{i}")
        p.accept(env)

    # Run random pairwise sync rounds until every peer holds every CID.
    def all_converged() -> bool:
        ref = set(peers[0].cids())
        return all(set(p.cids()) == ref for p in peers[1:])

    rounds = 0
    max_rounds = 50
    while not all_converged() and rounds < max_rounds:
        a, b = rng.sample(peers, 2)
        local_sync(a, b)
        rounds += 1

    assert all_converged(), f"failed to converge after {rounds} rounds"
    assert rounds <= 20, f"took {rounds} rounds; expected O(log N)=~5"


# ---- collective_assimilate -----------------------------------------------


def test_collective_assimilate_dedups_against_local_peer():
    """Second absorb of the same model_id short-circuits."""
    peer = Peer(peer_id="dedup")

    sd = {"x.weight": torch.randn(8, 8)}
    r1 = collective_assimilate(
        state_dict=sd,
        model_id="dup/test",
        local_peer=peer,
        borg_path=f"/tmp/borg-dedup-1-{id(peer)}.pt",
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    assert r1.already_known is False
    assert r1.cids_broadcast  # at least one envelope

    r2 = collective_assimilate(
        state_dict=sd,
        model_id="dup/test",
        local_peer=peer,
        borg_path=f"/tmp/borg-dedup-2-{id(peer)}.pt",
        time_steps=4,
        gate_enabled=False,
        apply_calibration=False,
    )
    assert r2.already_known is True
    assert r2.cids_broadcast == []


def test_collective_assimilate_dedups_against_remote_peer():
    """If a remote peer already absorbed, local absorb is skipped."""
    local = Peer(peer_id="local")
    remote = Peer(peer_id="remote")

    sd = {"x.weight": torch.randn(8, 8)}
    collective_assimilate(
        state_dict=sd, model_id="pre/absorbed", local_peer=remote,
        borg_path=f"/tmp/borg-dedup-remote-{id(remote)}.pt",
        time_steps=4, gate_enabled=False, apply_calibration=False,
    )
    result = collective_assimilate(
        state_dict=sd, model_id="pre/absorbed", local_peer=local,
        remote_peers=[remote],
        borg_path=f"/tmp/borg-dedup-local-{id(local)}.pt",
        time_steps=4, gate_enabled=False, apply_calibration=False,
    )
    assert result.already_known is True
    assert remote.peer_id in result.peers_reached


def test_collective_assimilate_broadcasts_to_peers():
    """Local absorb followed by sync drops envelopes into every remote peer."""
    local = Peer(peer_id="L")
    r1 = Peer(peer_id="R1")
    r2 = Peer(peer_id="R2")

    sd = {"x.weight": torch.randn(8, 8)}
    result = collective_assimilate(
        state_dict=sd, model_id="broadcast/test", local_peer=local,
        remote_peers=[r1, r2],
        borg_path=f"/tmp/borg-broadcast-{id(local)}.pt",
        time_steps=4, gate_enabled=False, apply_calibration=False,
    )
    assert result.already_known is False
    assert set(local.cids()) == set(r1.cids()) == set(r2.cids())
    assert {"broadcast/test"} == local.absorbed_model_ids() == r1.absorbed_model_ids() == r2.absorbed_model_ids()


# ---- Bootstrap -----------------------------------------------------------


def test_default_seeds_include_hf_space():
    ids = [s.peer_id for s in DEFAULT_SEEDS]
    assert "hf-space" in ids


def test_resolve_seeds_merges_env_override(monkeypatch):
    monkeypatch.setenv(
        "BORG_COLLECTIVE_SEEDS",
        "https://peer.example.com,https://peer2.example.com",
    )
    seeds = resolve_seeds()
    urls = [s.url for s in seeds]
    assert "https://peer.example.com" in urls
    assert "https://peer2.example.com" in urls
    # Default seed must still be there.
    assert "https://optitransfer-the-borg-project.hf.space" in urls
