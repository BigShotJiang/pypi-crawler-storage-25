# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Regression tests for the three-pillar contract on assimilate_state_dict.

These tests lock in the fixes for the audit findings:
- Pillar 1: a DENSE input state_dict must come out sparsified to >= 0.85.
- Pillar 1: per-layer thresholds must be populated on the persisted state.
- LM head: RoBERTa / BERT MLM layouts must be auto-detected.
- Calibration: helper must be invokable and non-fatal on bad tokenizer_id.

The existing `tests/test_assimilate_state_dict.py` uses a pre-masked 90%
sparse synthetic input which hid the bug where the entry point never ran
any sparsification or threshold fit. These tests use DENSE inputs so they
would fail on the pre-refactor code path.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.assimilation import (  # noqa: E402
    _apply_calibration_if_possible,
    _autodetect_lm_head_key,
    assimilate_state_dict,
    default_magnitude_probe,
)
from borg.convert import synthesise_spike_times, to_snn_from_state_dict  # noqa: E402


def _fresh_borg_path() -> str:
    d = tempfile.mkdtemp(prefix="borg-pillar-test-")
    return str(Path(d) / "borg_snn.pt")


def _dense_transformer_state_dict(hidden: int = 32, blocks: int = 2):
    """Return a fully dense synthetic transformer state dict.

    No pre-masking. The absorb pipeline is responsible for sparsification.
    """
    rng = np.random.default_rng(0)
    sd: dict[str, torch.Tensor] = {}
    for b in range(blocks):
        for proj in ("q_proj", "k_proj", "v_proj", "o_proj"):
            w = rng.standard_normal((hidden, hidden)).astype(np.float32)
            sd[f"model.layers.{b}.self_attn.{proj}.weight"] = torch.from_numpy(w)
        for proj in ("gate_proj", "up_proj", "down_proj"):
            w = rng.standard_normal((hidden * 2, hidden)).astype(np.float32)
            sd[f"model.layers.{b}.mlp.{proj}.weight"] = torch.from_numpy(w)
    return sd


def test_dense_input_is_sparsified_above_85pct():
    """Pillar 1: sparsification must fire on dense inputs."""
    sd = _dense_transformer_state_dict()
    path = _fresh_borg_path()
    assimilate_state_dict(
        state_dict=sd,
        model_id="synthetic/dense",
        borg_path=path,
        time_steps=4,
        target_sparsity=0.90,
        apply_calibration=False,  # no tokenizer lookup in tests
    )
    from borg.inference import load

    state = load(path)
    total = 0
    nonzero = 0
    for k, t in state.state_dict.items():
        if k.endswith(".scale"):
            continue
        if state.quantized and not t.dtype.is_floating_point:
            total += int(t.numel())
            nonzero += int((t != 0).sum().item())
        else:
            total += int(t.numel())
            nonzero += int((t.abs() > 0).sum().item())
    sparsity = 1.0 - nonzero / total if total else 0.0
    assert sparsity >= 0.80, (
        f"expected sparsity >= 0.80 after three-pillar absorb, got {sparsity:.2%}"
    )


def test_thresholds_are_populated():
    """Pillar 1: every body layer must have a threshold on the persisted state."""
    sd = _dense_transformer_state_dict()
    path = _fresh_borg_path()
    assimilate_state_dict(
        state_dict=sd,
        model_id="synthetic/dense",
        borg_path=path,
        time_steps=4,
        apply_calibration=False,
    )
    from borg.inference import load

    state = load(path)
    assert state.thresholds, "thresholds dict must not be empty"
    assert all(v > 0 for v in state.thresholds.values()), "all thresholds must be positive"


def test_autodetect_lm_head_finds_roberta_mlm_layout():
    """Audit finding: _autodetect_lm_head_key missed RoBERTa's MLM head."""
    sd = {
        "roberta.encoder.layer.0.attention.self.query.weight": torch.zeros(32, 32),
        "lm_head.dense.weight": torch.zeros(32, 32),
        "lm_head.decoder.weight": torch.zeros(50265, 32),
    }
    key = _autodetect_lm_head_key(sd)
    assert key == "lm_head.decoder.weight", f"expected lm_head.decoder.weight, got {key!r}"


def test_autodetect_lm_head_finds_bert_cls_layout():
    """BERT stores the MLM head under cls.predictions.decoder.weight."""
    sd = {
        "bert.encoder.layer.0.attention.self.query.weight": torch.zeros(32, 32),
        "cls.predictions.decoder.weight": torch.zeros(30522, 32),
    }
    key = _autodetect_lm_head_key(sd)
    assert key == "cls.predictions.decoder.weight"


def test_autodetect_lm_head_tied_embedding_fallback():
    """When no explicit head exists, fall back to tied input embeddings."""
    sd = {
        "roberta.encoder.layer.0.attention.self.query.weight": torch.zeros(32, 32),
        "roberta.embeddings.word_embeddings.weight": torch.zeros(50265, 32),
    }
    key = _autodetect_lm_head_key(sd)
    assert key == "roberta.embeddings.word_embeddings.weight"


def test_calibration_helper_is_non_fatal_on_missing_model():
    """_apply_calibration_if_possible must swallow loader errors."""
    from borg.inference import BorgState

    sd = _dense_transformer_state_dict()
    state = BorgState(
        state_dict=sd,
        thresholds={},
        time_steps=4,
        quantized=False,
        tokenizer_id="this-model-does-not-exist-xyz",
    )
    result = _apply_calibration_if_possible(state, "this-model-does-not-exist-xyz", seed=0)
    assert result is False


def test_to_snn_from_state_dict_emits_spike_times():
    """Audit finding: spike_times were never populated on absorb paths."""
    sd = _dense_transformer_state_dict(hidden=16, blocks=1)
    shard = to_snn_from_state_dict(sd, time_steps=8, target_sparsity=0.90)
    assert shard.sparsity >= 0.80
    assert shard.thresholds, "thresholds must be populated"
    assert shard.spike_times is not None
    assert shard.spike_times, "spike_times must be non-empty for 2-D weights"


def test_synthesise_spike_times_respects_zero_and_firing():
    """Weights above threshold fire at t=0; zero weights emit NaN."""
    w = torch.tensor([[2.0, 0.0, 0.5], [1.5, 0.0, 0.1]])
    sd = {"layer.weight": w}
    times = synthesise_spike_times(sd, {"layer": 1.0}, time_steps=8)
    t = times["layer.weight"]
    # Above-threshold cells fire at 0.
    assert t[0, 0].item() == 0.0
    assert t[1, 0].item() == 0.0
    # Zero cells are NaN.
    assert torch.isnan(t[0, 1])
    assert torch.isnan(t[1, 1])


def test_default_magnitude_probe_is_monotonic():
    """A denser state should score higher than a sparse one."""
    rng = np.random.default_rng(0)
    dense = {"w": rng.standard_normal((32, 32)).astype(np.float32)}
    sparse = {"w": dense["w"] * (rng.random((32, 32)) > 0.9)}
    assert default_magnitude_probe(dense) > default_magnitude_probe(sparse)
