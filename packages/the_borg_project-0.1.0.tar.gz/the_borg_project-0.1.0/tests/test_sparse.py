# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Unit tests for borg.sparse."""

import numpy as np
import pytest

from borg.sparse import LayerContribution, SparseDelta, apply, extract, merge_cellwise


def test_extract_then_apply_roundtrip():
    dense = np.array([[0.0, 1.0, 0.0], [0.0, 0.0, -2.0]], dtype=np.float32)
    delta = extract(dense, layer="linear.weight", model_id="m1", threshold=0.0)
    assert delta.nnz == 2
    assert 0 < delta.sparsity < 1
    recovered = apply(delta)
    np.testing.assert_array_equal(recovered, dense)


def test_tag_stable_across_identical_inputs():
    dense = np.zeros((4, 4), dtype=np.float32)
    dense[1, 2] = 0.5
    a = extract(dense, layer="l", model_id="m")
    b = extract(dense, layer="l", model_id="m")
    assert a.tag() == b.tag()


def test_merge_cellwise_preserves_sparsity():
    d1 = SparseDelta(
        indices=np.array([[0, 0], [1, 1]], dtype=np.int32),
        values=np.array([1.0, 2.0], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="a",
    )
    d2 = SparseDelta(
        indices=np.array([[0, 0]], dtype=np.int32),
        values=np.array([3.0], dtype=np.float32),
        shape=(2, 2),
        layer="l",
        model_id="b",
    )
    merged = merge_cellwise([d1, d2], strategy="mean")
    assert merged.shape == (2, 2)
    assert merged[0, 0] == pytest.approx(2.0)
    assert merged[1, 1] == pytest.approx(2.0)
    assert merged[0, 1] == 0.0
    assert merged[1, 0] == 0.0


def test_layer_contribution_envelope():
    dense = np.eye(3, dtype=np.float32)
    delta = extract(dense, layer="x", model_id="m", threshold=0.0)
    env = LayerContribution(delta=delta, weight=0.7)
    kwargs = env.to_crdt_kwargs()
    assert kwargs["weight"] == 0.7
    assert kwargs["model_id"] == "m"
    assert kwargs["metadata"]["layer"] == "x"
    assert "tag" in kwargs["metadata"]
    np.testing.assert_array_equal(kwargs["tensor"], dense)
