# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Cumulative manifest across multiple absorptions.

Closes the user-visible bug where the HF Space only showed the
most-recently-absorbed model in its diagnostic panel. Every absorb
must union its contributions with the prior manifest's.
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import numpy as np
import pytest
import torch

pytest.importorskip("crdt_merge.model.crdt_state")

from borg.assimilation import assimilate_state_dict  # noqa: E402


def _dense_shard(seed: int):
    rng = np.random.default_rng(seed)
    return {
        f"model.layers.{b}.self_attn.q_proj.weight":
            torch.from_numpy(rng.standard_normal((16, 16)).astype(np.float32))
        for b in range(2)
    }


def test_manifest_accumulates_three_model_ids():
    d = tempfile.mkdtemp(prefix="borg-cum-")
    path = str(Path(d) / "borg_snn.pt")

    for i, mid in enumerate(["alice/m", "bob/m", "carol/m"]):
        assimilate_state_dict(
            state_dict=_dense_shard(seed=i),
            model_id=mid,
            borg_path=path,
            time_steps=4,
            gate_enabled=False,
            apply_calibration=False,
        )

    manifest = json.loads(Path(path + ".manifest.json").read_text())
    ids = [c["model_id"] for c in manifest["contributions"]]
    assert set(ids) == {"alice/m", "bob/m", "carol/m"}, (
        f"manifest lost prior contributions: got {ids}"
    )


def test_manifest_or_set_unions_across_absorbs():
    """The upstream CRDT OR-Set must contain every absorbed model_id."""
    pytest.importorskip("crdt_merge.core")
    from crdt_merge.core import ORSet

    d = tempfile.mkdtemp(prefix="borg-or-")
    path = str(Path(d) / "borg_snn.pt")

    ids = [f"peer{i}/model" for i in range(5)]
    for i, mid in enumerate(ids):
        assimilate_state_dict(
            state_dict=_dense_shard(seed=i + 100),
            model_id=mid,
            borg_path=path,
            time_steps=4,
            gate_enabled=False,
            apply_calibration=False,
        )

    manifest = json.loads(Path(path + ".manifest.json").read_text())
    or_set_raw = manifest.get("contributor_or_set")
    assert or_set_raw is not None
    or_set = ORSet.from_dict(or_set_raw)
    for mid in ids:
        assert or_set.contains(mid), f"OR-Set missing {mid} after 5 absorbs"


def test_manifest_dedup_by_model_id():
    """Absorbing the same model_id twice produces one entry, not two."""
    d = tempfile.mkdtemp(prefix="borg-dedup-")
    path = str(Path(d) / "borg_snn.pt")

    for i in range(3):
        assimilate_state_dict(
            state_dict=_dense_shard(seed=i),
            model_id="same/model",
            borg_path=path,
            time_steps=4,
            gate_enabled=False,
            apply_calibration=False,
        )

    manifest = json.loads(Path(path + ".manifest.json").read_text())
    ids = [c["model_id"] for c in manifest["contributions"]]
    assert ids.count("same/model") == 1


def test_manifest_head_registry_reflects_every_absorb():
    """Every absorbed model registers its head type on the state."""
    from borg.heads import get_registered_heads
    from borg.inference import load as load_state

    d = tempfile.mkdtemp(prefix="borg-heads-")
    path = str(Path(d) / "borg_snn.pt")

    # Three distinct shard shapes to make them recognisable.
    shards = {
        "model/alpha": _dense_shard(seed=1),
        "model/beta": _dense_shard(seed=2),
        "model/gamma": _dense_shard(seed=3),
    }
    for mid, sd in shards.items():
        assimilate_state_dict(
            state_dict=sd, model_id=mid, borg_path=path,
            time_steps=4, gate_enabled=False, apply_calibration=False,
        )

    state = load_state(path)
    heads = get_registered_heads(state)
    mids = {h.model_id for h in heads}
    assert mids == {"model/alpha", "model/beta", "model/gamma"}
