# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the variational FEP layer."""

import numpy as np

from borg.fep import FEPConfig, elbo, init_posterior, kl_to_prior, refine


def test_posterior_init_matches_resolved():
    resolved = {"w": np.eye(3, dtype=np.float32)}
    cfg = FEPConfig()
    q = init_posterior(resolved, cfg)
    for k in resolved:
        np.testing.assert_array_equal(q.mu[k], resolved[k])


def test_kl_is_nonnegative():
    resolved = {"w": np.eye(4, dtype=np.float32)}
    cfg = FEPConfig()
    q = init_posterior(resolved, cfg)
    mask = {k: (np.abs(v) > 0).astype(np.float32) for k, v in resolved.items()}
    kl = kl_to_prior(q, resolved, mask, cfg.prior_sigma)
    assert kl >= -1e-6


def test_elbo_returns_three_scalars():
    resolved = {"w": np.eye(4, dtype=np.float32)}
    cfg = FEPConfig(mc_samples=1)
    rng = np.random.default_rng(0)
    mask = {k: (np.abs(v) > 0).astype(np.float32) for k, v in resolved.items()}
    x = np.eye(4, dtype=np.float32)
    y = np.zeros((4, 4), dtype=np.float32)
    e, nll, kl = elbo(init_posterior(resolved, cfg), resolved, mask, x, y, cfg, rng)
    assert isinstance(e, float)
    assert isinstance(nll, float)
    assert isinstance(kl, float)


def test_refine_preserves_zero_cells():
    rng = np.random.default_rng(0)
    w = rng.standard_normal((8, 4)).astype(np.float32)
    mask = rng.random((8, 4)) > 0.5
    w = w * mask
    resolved = {"w": w.copy()}

    probe_in = rng.standard_normal((4, 8)).astype(np.float32)
    probe_out = rng.standard_normal((4, 4)).astype(np.float32)

    refined = refine(
        resolved,
        probe_inputs=probe_in,
        probe_targets=probe_out,
        config=FEPConfig(steps=2, lr=1e-3, alpha=0.05, mc_samples=1),
    )
    zero_mask = w == 0
    assert np.all(refined["w"][zero_mask] == 0)


def test_refine_noop_without_probe():
    resolved = {"w": np.eye(3, dtype=np.float32)}
    out = refine(resolved)
    np.testing.assert_array_equal(out["w"], resolved["w"])
