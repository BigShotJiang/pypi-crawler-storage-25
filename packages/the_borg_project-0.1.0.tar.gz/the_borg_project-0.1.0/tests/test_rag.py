# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Round-trip corpus test for the RAG ingest + retrieve path.

Closes the partial row on the status matrix. Uses an injected
bag-of-words deterministic embedder so the test runs offline and
doesn't depend on downloading sentence-transformers weights, while
still exercising the real DocStore ingest / query / save / load code.

The sentence-transformers-backed behaviour is covered by the
`bench-pretrained` CI job which has network access.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np
import pytest

pytest.importorskip("faiss", exc_type=ImportError)

from borg.rag import DocStore  # noqa: E402
from borg.rag.retrieve import retrieve  # noqa: E402


class _KeywordEmbedder:
    """Offline deterministic embedder: one-hot over a fixed keyword vocab.

    Each sentence is encoded by counting keyword occurrences. Separable
    vocabularies produce near-orthogonal embeddings, so FAISS L2 search
    ranks the correct source first for each probe prompt.
    """

    _VOCAB = [
        "jupiter", "planet", "solar", "moon", "gas",
        "sourdough", "bread", "yeast", "flour", "fermentation",
        "crdt", "merge", "replicated", "lattice", "orset",
    ]

    def encode(self, texts: list[str]) -> np.ndarray:
        out = np.zeros((len(texts), len(self._VOCAB)), dtype=np.float32)
        for i, t in enumerate(texts):
            low = t.lower()
            for j, kw in enumerate(self._VOCAB):
                out[i, j] = float(low.count(kw))
        # L2-normalise so FAISS distances behave.
        norms = np.linalg.norm(out, axis=1, keepdims=True) + 1e-9
        return out / norms

    def get_sentence_embedding_dimension(self) -> int:
        return len(self._VOCAB)


_CORPUS = {
    "astronomy.txt": (
        "Jupiter is the fifth planet from the Sun and the largest in the solar system. "
        "Jupiter is a gas giant with many moons."
    ),
    "cooking.txt": (
        "Sourdough bread is leavened by wild yeast and lactic acid bacteria. "
        "Bakers refresh the sourdough starter daily with flour and water. "
        "Fermentation temperatures above 25 Celsius accelerate rise."
    ),
    "computing.txt": (
        "CRDT stands for conflict-free replicated data type. They converge "
        "without coordination through a mathematical lattice. ORSet is a "
        "canonical CRDT example."
    ),
}


@pytest.fixture(scope="module")
def corpus_dir():
    with tempfile.TemporaryDirectory(prefix="borg-rag-test-") as d:
        root = Path(d)
        for name, body in _CORPUS.items():
            (root / name).write_text(body, encoding="utf-8")
        yield root


def _fresh_store() -> DocStore:
    return DocStore(chunk_size=128, chunk_overlap=16, embedder=_KeywordEmbedder())


def test_ingest_returns_positive_chunk_count(corpus_dir):
    store = _fresh_store()
    n = store.ingest([str(corpus_dir / name) for name in _CORPUS])
    assert n > 0


def test_query_returns_correct_source_for_each_topic(corpus_dir):
    store = _fresh_store()
    store.ingest([str(corpus_dir / name) for name in _CORPUS])

    probes = {
        "astronomy.txt": "Which planet is the largest gas giant?",
        "cooking.txt": "How does sourdough fermentation work with flour and yeast?",
        "computing.txt": "Explain the ORSet CRDT lattice.",
    }
    for expected_name, prompt in probes.items():
        hits = store.query(prompt, k=3)
        assert hits, f"no hits for prompt: {prompt!r}"
        top_sources = [Path(src).name for src, _chunk in hits]
        assert expected_name in top_sources, (
            f"expected {expected_name} in top 3 for {prompt!r}, got {top_sources}"
        )


def test_retrieve_returns_context_and_sources(corpus_dir):
    store = _fresh_store()
    store.ingest([str(corpus_dir / name) for name in _CORPUS])

    context, sources = retrieve(store, "Jupiter moons gas giant", k=2)
    assert context, "retrieve must produce a non-empty context string"
    assert isinstance(sources, list)
    assert len(sources) >= 1
    for src in sources:
        assert Path(src).exists()


def test_save_and_load_round_trips(corpus_dir):
    store = _fresh_store()
    store.ingest([str(corpus_dir / name) for name in _CORPUS])
    with tempfile.TemporaryDirectory(prefix="borg-rag-save-") as d:
        store.save(d)
        restored = DocStore(embedder=_KeywordEmbedder())
        restored.load(d)
        assert restored._chunks == store._chunks
        assert restored._sources == store._sources
        hits = restored.query("replicated lattice orset", k=1)
        assert hits
        assert Path(hits[0][0]).name == "computing.txt"


def test_default_embedder_path_is_importable():
    """Default (sentence-transformers) code path must at least be constructable
    without attempting to download weights."""
    store = DocStore()
    assert store.embedder_name == "sentence-transformers/all-MiniLM-L6-v2"
    assert store._embedder is None  # lazy
