# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Three-worker gossip convergence simulation.

Closes the P7 exit gate: three independent `MergeQueue` instances start
with disjoint digest sets, exchange digests via the `/gossip` semantics
round-robin, and converge on a common set.

Uses `borg.worker.Signer` + `to_envelope` directly in-process so no
network is required.
"""

from __future__ import annotations

import numpy as np
import pytest

from borg.sparse import SparseDelta
from borg.worker import MergeQueue, Signer, to_envelope


def _delta(i: int) -> SparseDelta:
    """Return a small deterministic SparseDelta."""
    return SparseDelta(
        indices=np.array([[0, i % 2]], dtype=np.int32),
        values=np.array([float(i) / 10.0 + 0.1], dtype=np.float32),
        shape=(2, 2),
        layer=f"layer.{i}.weight",
        model_id=f"m-{i}",
        trust=np.ones(6, dtype=np.float32),
    )


def _gossip_once(a: MergeQueue, b: MergeQueue, envelopes_by_digest: dict) -> None:
    """Simulate one /gossip exchange from a to b: b learns missing digests and
    accepts the corresponding envelopes."""
    a_set = set(a.observed_digests())
    b_set = set(b.observed_digests())
    need = a_set - b_set
    for d in need:
        env = envelopes_by_digest[d]
        b.submit(env)


def test_three_workers_converge_on_common_digest_set():
    # Three workers each start empty.
    signers = [Signer(secret=bytes([i]) * 32) for i in range(3)]
    q = [MergeQueue(flush_threshold=10_000) for _ in range(3)]

    # Build 9 envelopes, each signed by one of the three signers.
    envelopes_by_digest: dict[str, object] = {}
    for i in range(9):
        env = to_envelope(_delta(i), signers[i % 3])
        envelopes_by_digest[env.digest()] = env

    # Seed each worker with 3 distinct envelopes.
    for i, env in enumerate(envelopes_by_digest.values()):
        assert q[i % 3].submit(env)

    # Baseline: before gossip, each worker holds 3 distinct digests.
    sizes_before = sorted(len(w.observed_digests()) for w in q)
    assert sizes_before == [3, 3, 3]

    # Gossip rounds: ring (0 -> 1 -> 2 -> 0) until everyone converges.
    for _ in range(6):
        _gossip_once(q[0], q[1], envelopes_by_digest)
        _gossip_once(q[1], q[2], envelopes_by_digest)
        _gossip_once(q[2], q[0], envelopes_by_digest)
        sets = [set(w.observed_digests()) for w in q]
        if sets[0] == sets[1] == sets[2]:
            break

    final = [sorted(w.observed_digests()) for w in q]
    assert final[0] == final[1] == final[2]
    assert len(final[0]) == 9


def test_gossip_rejects_tampered_envelope_and_keeps_convergence():
    signer = Signer(secret=b"\x07" * 32)
    env = to_envelope(_delta(42), signer)
    tampered = env
    tampered.values_b64 = "AAAAAAAA"

    q1 = MergeQueue(flush_threshold=10_000)
    q2 = MergeQueue(flush_threshold=10_000)

    assert not q1.submit(tampered)
    clean = to_envelope(_delta(99), signer)
    assert q1.submit(clean)

    # Gossip: q1 -> q2. q2 should get the clean envelope only.
    envelopes_by_digest = {clean.digest(): clean, env.digest(): tampered}
    _gossip_once(q1, q2, envelopes_by_digest)
    assert clean.digest() in set(q2.observed_digests())
    assert env.digest() not in set(q2.observed_digests())


def test_gossip_is_idempotent():
    signer = Signer(secret=b"\x08" * 32)
    env = to_envelope(_delta(1), signer)
    q1 = MergeQueue(flush_threshold=10_000)
    q2 = MergeQueue(flush_threshold=10_000)
    q1.submit(env)
    envelopes_by_digest = {env.digest(): env}
    _gossip_once(q1, q2, envelopes_by_digest)
    before = q2.pending()
    _gossip_once(q1, q2, envelopes_by_digest)
    _gossip_once(q1, q2, envelopes_by_digest)
    assert q2.pending() == before


def test_partition_reconciles_after_healing():
    """Two partitions A={q0,q1}, B={q2} diverge, then heal."""
    signers = [Signer(secret=bytes([i]) * 32) for i in range(3)]
    q = [MergeQueue(flush_threshold=10_000) for _ in range(3)]
    envelopes_by_digest: dict[str, object] = {}
    for i in range(6):
        env = to_envelope(_delta(i), signers[i % 3])
        envelopes_by_digest[env.digest()] = env
        target = 0 if i < 4 else 2
        q[target].submit(env)

    # Partition A gossips internally (q0 <-> q1).
    _gossip_once(q[0], q[1], envelopes_by_digest)
    _gossip_once(q[1], q[0], envelopes_by_digest)
    assert set(q[0].observed_digests()) == set(q[1].observed_digests())
    # q2 remains separate with 2 items.
    assert len(q[2].observed_digests()) == 2

    # Heal: bidirectional gossip across all pairs.
    for _ in range(3):
        _gossip_once(q[0], q[2], envelopes_by_digest)
        _gossip_once(q[2], q[0], envelopes_by_digest)
        _gossip_once(q[1], q[2], envelopes_by_digest)
        _gossip_once(q[2], q[1], envelopes_by_digest)

    sets = [set(w.observed_digests()) for w in q]
    assert sets[0] == sets[1] == sets[2]
    assert len(sets[0]) == 6


@pytest.mark.parametrize("worker_count", [3, 5, 7])
def test_arbitrary_worker_count_converges(worker_count):
    signers = [Signer(secret=bytes([i % 250]) * 32) for i in range(worker_count)]
    q = [MergeQueue(flush_threshold=100_000) for _ in range(worker_count)]
    envelopes_by_digest: dict[str, object] = {}
    for i in range(worker_count * 2):
        env = to_envelope(_delta(i), signers[i % worker_count])
        envelopes_by_digest[env.digest()] = env
        q[i % worker_count].submit(env)

    for _ in range(worker_count * 2):
        for i in range(worker_count):
            _gossip_once(q[i], q[(i + 1) % worker_count], envelopes_by_digest)

    sets = [set(w.observed_digests()) for w in q]
    for s in sets[1:]:
        assert s == sets[0]
    assert len(sets[0]) == worker_count * 2
