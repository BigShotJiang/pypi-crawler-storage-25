# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for borg.decode."""

import numpy as np
import torch

from borg.decode import (
    LM_HEAD_KEY,
    DecodeConfig,
    decode_text,
    decode_token_ids,
    has_lm_head,
    logits_from_rates,
)
from borg.inference import BorgState


def _state_with_head(vocab: int = 17, hidden: int = 8) -> BorgState:
    rng = np.random.default_rng(0)
    body = torch.from_numpy((rng.standard_normal((hidden, hidden)) * 0.2).astype(np.float32))
    head = torch.from_numpy((rng.standard_normal((vocab, hidden)) * 0.5).astype(np.float32))
    return BorgState(
        state_dict={"body.weight": body, LM_HEAD_KEY: head},
        thresholds={"body.weight": 0.5},
        time_steps=4,
    )


def test_has_lm_head_detects_presence():
    state = _state_with_head()
    assert has_lm_head(state)
    empty = BorgState(state_dict={}, thresholds={}, time_steps=4)
    assert not has_lm_head(empty)


def test_logits_shape_matches_vocab():
    state = _state_with_head(vocab=19, hidden=6)
    rates = np.full((1, 6), 0.2, dtype=np.float32)
    logits = logits_from_rates(rates, state)
    assert logits.shape == (1, 19)


def test_logits_width_projection_when_rates_too_narrow():
    state = _state_with_head(vocab=10, hidden=8)
    rates = np.full((1, 4), 0.3, dtype=np.float32)
    logits = logits_from_rates(rates, state)
    assert logits.shape == (1, 10)


def test_decode_token_ids_greedy_is_deterministic():
    state = _state_with_head(vocab=13, hidden=8)
    ids_a = decode_token_ids(
        state,
        input_ids=[1, 2, 3],
        config=DecodeConfig(max_new_tokens=5, temperature=0.0, seed=7),
    )
    ids_b = decode_token_ids(
        state,
        input_ids=[1, 2, 3],
        config=DecodeConfig(max_new_tokens=5, temperature=0.0, seed=7),
    )
    assert ids_a == ids_b
    assert len(ids_a) == 8


def test_decode_stops_when_stop_token_is_first_output():
    state = _state_with_head(vocab=5, hidden=8)
    first_run = decode_token_ids(
        state,
        input_ids=[1],
        config=DecodeConfig(max_new_tokens=10, temperature=0.0),
    )
    first_generated = first_run[1]
    stopped = decode_token_ids(
        state,
        input_ids=[1],
        config=DecodeConfig(max_new_tokens=10, temperature=0.0, stop_token=first_generated),
    )
    assert stopped[-1] == first_generated
    assert len(stopped) == 2


def test_decode_text_calls_tokenizer_round_trip():
    class _Tok:
        def encode(self, s: str) -> list[int]:
            return [ord(c) % 13 for c in s][:8]

        def decode(self, ids: list[int]) -> str:
            return " ".join(str(i) for i in ids)

    state = _state_with_head(vocab=13, hidden=8)
    out = decode_text(state, "hello", _Tok(), DecodeConfig(max_new_tokens=3))
    parts = out.split()
    assert len(parts) == 3
    for p in parts:
        assert p.isdigit()
