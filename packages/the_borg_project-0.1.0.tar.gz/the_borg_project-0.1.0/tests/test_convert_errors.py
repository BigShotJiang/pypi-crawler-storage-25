# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for ConversionAccuracyError and UnsupportedOpError.

The alignment audit flagged these as spec'd (specs 01 + 02) but missing.
These tests lock the behaviour in: real callers can catch both errors
and skip the bad contribution rather than silently merging gibberish.
"""

from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from borg.convert import (
    ConversionAccuracyError,
    UnsupportedOpError,
    _check_supported_ops,
    to_snn,
)


class _SimpleLinearNet(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.fc1 = nn.Linear(16, 16)
        self.fc2 = nn.Linear(16, 16)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc2(torch.relu(self.fc1(x)))


class _NetWithLSTMCell(nn.Module):
    def __init__(self) -> None:
        super().__init__()
        self.fc = nn.Linear(8, 8)
        self.cell = nn.LSTMCell(8, 8)  # unsupported

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        h = self.fc(x)
        return self.cell(h)[0]


def test_unsupported_op_error_is_raised_for_lstm_cell():
    with pytest.raises(UnsupportedOpError) as exc:
        _check_supported_ops(_NetWithLSTMCell())
    assert "LSTMCell" in str(exc.value)
    assert exc.value.module_cls == "LSTMCell"


def test_supported_net_passes_check():
    # Should not raise.
    _check_supported_ops(_SimpleLinearNet())


def test_to_snn_surfaces_unsupported_op_error():
    with pytest.raises(UnsupportedOpError):
        to_snn(_NetWithLSTMCell(), method="feedforward", time_steps=4)


def test_conversion_accuracy_error_raised_when_probe_fails():
    """to_snn raises when the supplied probe reports below-floor accuracy."""
    # Sparsity below 60% would already warn; use method="snn" to bypass
    # the sparsify step and focus on the accuracy gate behaviour.
    model = _SimpleLinearNet()

    def probe(_shard):
        return 0.05

    with pytest.raises(ConversionAccuracyError) as exc:
        to_snn(
            model,
            method="transformer",
            time_steps=4,
            accuracy_floor=0.8,
            accuracy_probe_fn=probe,
        )
    assert exc.value.observed == 0.05
    assert exc.value.floor == 0.8


def test_conversion_accuracy_probe_not_invoked_when_floor_zero():
    """accuracy_floor=0 (default) skips the probe entirely."""
    called = {"n": 0}

    def probe(_shard):
        called["n"] += 1
        return 0.0

    to_snn(
        _SimpleLinearNet(),
        method="transformer",
        time_steps=4,
        accuracy_floor=0.0,
        accuracy_probe_fn=probe,
    )
    assert called["n"] == 0


def test_conversion_accuracy_passes_when_above_floor():
    def probe(_shard):
        return 0.99

    shard = to_snn(
        _SimpleLinearNet(),
        method="transformer",
        time_steps=4,
        accuracy_floor=0.5,
        accuracy_probe_fn=probe,
    )
    assert shard.thresholds  # smoke check that conversion ran
