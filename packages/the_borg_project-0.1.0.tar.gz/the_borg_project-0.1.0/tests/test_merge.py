# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Unit tests for borg.merge. Requires crdt-merge to be installed."""

import numpy as np
import pytest

crdt = pytest.importorskip("crdt_merge.model.crdt_state")

from borg.merge import (  # noqa: E402
    build_contributions,
    build_manifest,
    resolve_per_layer,
)


def _tiny_state_dict(seed: int) -> dict[str, np.ndarray]:
    rng = np.random.default_rng(seed)
    return {
        "layer0.weight": rng.standard_normal((4, 4)).astype(np.float32) * (rng.random((4, 4)) > 0.7),
        "layer1.weight": rng.standard_normal((4, 2)).astype(np.float32) * (rng.random((4, 2)) > 0.5),
    }


def test_build_contributions_emits_layer_envelopes():
    sd = {"a": _tiny_state_dict(1), "b": _tiny_state_dict(2)}
    envs = build_contributions(sd)
    layers = {e.delta.layer for e in envs}
    model_ids = {e.delta.model_id for e in envs}
    assert layers == {"layer0.weight", "layer1.weight"}
    assert model_ids == {"a", "b"}


def test_resolve_is_deterministic_under_shuffled_input():
    sd = {"a": _tiny_state_dict(1), "b": _tiny_state_dict(2)}
    envs = build_contributions(sd)

    r1, _t1, _tags1 = resolve_per_layer(envs, strategy="linear", seed=7)
    r2, _t2, _tags2 = resolve_per_layer(list(reversed(envs)), strategy="linear", seed=7)
    for k in r1:
        np.testing.assert_array_equal(r1[k], r2[k])


def test_manifest_contains_merkle_root_and_sparsity():
    sd = {"a": _tiny_state_dict(1)}
    envs = build_contributions(sd)
    manifest = build_manifest(
        contributions=envs,
        rejected=[],
        strategy="linear",
        fep_refine=False,
        seed=42,
        borg_path="borg_snn.pt",
    )
    assert len(manifest.merkle_root) == 64
    assert len(manifest.contributions) == 1
    assert 0.0 <= manifest.contributions[0]["sparsity"] <= 1.0
    assert manifest.rejected == []
