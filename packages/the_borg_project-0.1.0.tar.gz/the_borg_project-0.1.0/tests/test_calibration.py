# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for `borg.calibration` (logit rescale).

The calibration step is what turns the raw SNN's repetitive token output
into something coherent enough for a demo. The tests here cover the
pure-numerical path with a fake source model + tokenizer so they run
fast and offline.
"""

from __future__ import annotations

import numpy as np
import torch

from borg.calibration import (
    CALIB_BIAS_KEY,
    CALIB_SCALE_KEY,
    CalibrationConfig,
    attach_calibration,
    fit_logit_rescale,
)
from borg.decode import LM_HEAD_KEY, logits_from_rates
from borg.inference import BorgState


class _FakeTokenizer:
    """Tokeniser that exposes `vocab_size`."""

    def __init__(self, vocab_size: int):
        self.vocab_size = vocab_size


class _FakeOutput:
    def __init__(self, logits: torch.Tensor):
        self.logits = logits


class _FakeSourceModel:
    """Source model whose logits are a known affine transform of the
    SNN's logits, so the fitter should recover the inverse."""

    def __init__(self, vocab_size: int, scale: torch.Tensor, bias: torch.Tensor):
        self.vocab_size = vocab_size
        self._scale = scale
        self._bias = bias

    def __call__(self, input_ids: torch.Tensor) -> _FakeOutput:
        # Source logits = arbitrary deterministic per-token value derived
        # from the input ids. Independent of SNN, but the fitter should
        # still find a per-token affine that matches the observed pairs.
        seq_len = input_ids.shape[1]
        rng = np.random.default_rng(int(input_ids.flatten().sum().item()))
        last_token_logits = rng.standard_normal(self.vocab_size).astype(np.float32)
        # Apply known affine.
        adjusted = last_token_logits * self._scale.numpy() + self._bias.numpy()
        logits = torch.zeros((1, seq_len, self.vocab_size), dtype=torch.float32)
        logits[0, -1] = torch.from_numpy(adjusted)
        return _FakeOutput(logits)


def _state_with_lm_head(vocab: int = 17, hidden: int = 8) -> BorgState:
    rng = np.random.default_rng(0)
    body = torch.from_numpy((rng.standard_normal((hidden, hidden)) * 0.2).astype(np.float32))
    head = torch.from_numpy((rng.standard_normal((vocab, hidden)) * 0.5).astype(np.float32))
    return BorgState(
        state_dict={"body.weight": body, LM_HEAD_KEY: head},
        thresholds={"body.weight": 0.5},
        time_steps=2,
    )


def test_attach_calibration_persists_keys_on_state():
    state = _state_with_lm_head(vocab=11)
    scale = np.full(11, 2.0, dtype=np.float32)
    bias = np.full(11, -0.5, dtype=np.float32)
    attach_calibration(state, scale, bias)
    assert CALIB_SCALE_KEY in state.state_dict
    assert CALIB_BIAS_KEY in state.state_dict


def test_logits_apply_calibration_when_attached():
    state = _state_with_lm_head(vocab=11, hidden=8)
    rates = np.full((1, 8), 0.3, dtype=np.float32)
    raw = logits_from_rates(rates, state, _bypass_calibration=True)
    scale = np.full(11, 3.0, dtype=np.float32)
    bias = np.full(11, 1.0, dtype=np.float32)
    attach_calibration(state, scale, bias)
    cal = logits_from_rates(rates, state)
    expected = raw * 3.0 + 1.0
    np.testing.assert_allclose(cal, expected, atol=1e-5)


def test_fit_logit_rescale_returns_correct_shapes():
    state = _state_with_lm_head(vocab=13, hidden=8)
    tok = _FakeTokenizer(vocab_size=13)
    src = _FakeSourceModel(
        vocab_size=13,
        scale=torch.full((13,), 1.0),
        bias=torch.full((13,), 0.0),
    )
    scale, bias = fit_logit_rescale(src, tok, state, CalibrationConfig(n_probes=4))
    assert scale.shape == (13,)
    assert bias.shape == (13,)
    assert np.isfinite(scale).all()
    assert np.isfinite(bias).all()


def test_calibration_bypass_flag_works():
    state = _state_with_lm_head(vocab=11, hidden=8)
    attach_calibration(
        state,
        np.full(11, 5.0, dtype=np.float32),
        np.full(11, 100.0, dtype=np.float32),
    )
    rates = np.full((1, 8), 0.5, dtype=np.float32)
    bypass = logits_from_rates(rates, state, _bypass_calibration=True)
    applied = logits_from_rates(rates, state, _bypass_calibration=False)
    assert not np.allclose(bypass, applied)
