# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the native-SNN absorption path (`borg.convert.from_snn`).

This is the path Project Nord and other already-spiking source models
take. The conversion step is skipped — the SNN's state_dict is used
directly and per-layer thresholds are pulled from common SNN attribute
names (`v_threshold`, `spike_threshold`, `threshold`).
"""

from __future__ import annotations

import torch
from torch import nn

from borg.convert import (
    SNNShard,
    _autodetect,
    _looks_like_native_snn,
    from_snn,
    to_snn,
)


class _LIFNeuron(nn.Module):
    """Stand-in for a leaky integrate-and-fire layer."""

    def __init__(self, dim: int = 8):
        super().__init__()
        self.linear = nn.Linear(dim, dim, bias=False)
        self.v_threshold = 1.2
        self.v_reset = 0.0
        self.tau = 10.0
        self.T = 16

    def forward(self, x):
        return self.linear(x)


class _NativeSNNStack(nn.Module):
    def __init__(self, dim: int = 8):
        super().__init__()
        self.lif1 = _LIFNeuron(dim)
        self.lif2 = _LIFNeuron(dim)

    def forward(self, x):
        return self.lif2(self.lif1(x))


class _AssociativeLIF(nn.Module):
    """Stand-in for Project-Nord-style AssociativeLIF."""

    def __init__(self, dim: int = 8):
        super().__init__()
        self.proj = nn.Linear(dim, dim, bias=False)
        self.spike_threshold = 0.7

    def forward(self, x):
        return self.proj(x)


class _NordStyleNetwork(nn.Module):
    def __init__(self, dim: int = 8):
        super().__init__()
        self.assoc_block_0 = _AssociativeLIF(dim)
        self.assoc_block_1 = _AssociativeLIF(dim)

    def forward(self, x):
        return self.assoc_block_1(self.assoc_block_0(x))


def test_looks_like_native_snn_picks_up_lif():
    assert _looks_like_native_snn(_NativeSNNStack())


def test_looks_like_native_snn_picks_up_membrane_attr():
    class _Custom(nn.Module):
        def __init__(self):
            super().__init__()
            self.proj = nn.Linear(8, 8)
            self.v_membrane = torch.zeros(8)

        def forward(self, x):
            return self.proj(x)

    assert _looks_like_native_snn(_Custom())


def test_looks_like_native_snn_rejects_plain_ann():
    class _Plain(nn.Module):
        def __init__(self):
            super().__init__()
            self.layer = nn.Linear(8, 8)

        def forward(self, x):
            return self.layer(x)

    assert not _looks_like_native_snn(_Plain())


def test_from_snn_extracts_thresholds_and_skips_ann2snn():
    model = _NativeSNNStack()
    shard = from_snn(model, time_steps=4)
    assert isinstance(shard, SNNShard)
    assert shard.method == "snn"
    # Thresholds picked up from `v_threshold` attribute.
    assert shard.thresholds.get("lif1") == 1.2
    assert shard.thresholds.get("lif2") == 1.2
    # State dict is the source's, not transformed.
    assert "lif1.linear.weight" in shard.state_dict
    assert "lif2.linear.weight" in shard.state_dict


def test_from_snn_promotes_time_steps_from_module_attribute():
    """If the source declares T=16, that wins over the supplied default."""
    shard = from_snn(_NativeSNNStack(), time_steps=4)
    assert shard.time_steps == 16


def test_from_snn_handles_nord_style_module_names():
    shard = from_snn(_NordStyleNetwork(), time_steps=8)
    assert shard.method == "snn"
    assert shard.thresholds["assoc_block_0"] == 0.7
    assert shard.thresholds["assoc_block_1"] == 0.7


def test_autodetect_routes_to_snn_when_input_is_native_snn():
    assert _autodetect(_NativeSNNStack()) == "snn"


def test_to_snn_with_auto_picks_native_path_for_snn_input():
    shard = to_snn(_NativeSNNStack(), method="auto", time_steps=4)
    assert shard.method == "snn"
    # No `ann2snn`-introduced layers; only the original LIF + linear.
    keys = set(shard.state_dict.keys())
    assert {"lif1.linear.weight", "lif2.linear.weight"}.issubset(keys)


def test_to_snn_explicit_snn_method_is_equivalent():
    shard_a = to_snn(_NativeSNNStack(), method="auto", time_steps=4)
    shard_b = to_snn(_NativeSNNStack(), method="snn", time_steps=4)
    assert shard_a.state_dict.keys() == shard_b.state_dict.keys()
