# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Network-transport gossip: three live uvicorn workers exchange digests.

Previously the gossip test exercised only in-process MergeQueues. The
alignment audit flagged that the sprint plan called for real uvicorn
processes. This test spawns three FastAPI/uvicorn instances on free
localhost ports, submits distinct signed envelopes to each, then
queries the /gossip endpoint on each worker. Every worker must end up
aware of every digest after the rumour round.

Skipped when fastapi/uvicorn/httpx aren't installed (unit-only CI).
"""

from __future__ import annotations

import contextlib
import socket
import threading
import time
from typing import Iterator

import numpy as np
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("uvicorn")
pytest.importorskip("httpx")

import httpx  # noqa: E402
import uvicorn  # noqa: E402

from borg.sparse import SparseDelta  # noqa: E402
from borg.worker import MergeQueue, Signer, create_app, to_envelope  # noqa: E402


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


class _WorkerProcess:
    """A uvicorn server hosted in a background thread."""

    def __init__(self, port: int, queue: MergeQueue):
        self.port = port
        self.queue = queue
        self.app = create_app(queue=queue)
        self.config = uvicorn.Config(
            self.app, host="127.0.0.1", port=port, log_level="warning"
        )
        self.server = uvicorn.Server(self.config)
        self.thread = threading.Thread(target=self.server.run, daemon=True)

    def start(self) -> None:
        self.thread.start()
        self._wait_ready()

    def _wait_ready(self, timeout: float = 10.0) -> None:
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                r = httpx.get(self.url("/health"), timeout=0.5)
                if r.status_code == 200:
                    return
            except Exception:  # noqa: BLE001
                time.sleep(0.1)
        raise RuntimeError(f"worker on port {self.port} never answered /health")

    def stop(self) -> None:
        self.server.should_exit = True
        self.thread.join(timeout=5.0)

    def url(self, path: str) -> str:
        return f"http://127.0.0.1:{self.port}{path}"


@contextlib.contextmanager
def _three_workers() -> Iterator[list[_WorkerProcess]]:
    queues = [MergeQueue() for _ in range(3)]
    workers = [_WorkerProcess(_free_port(), q) for q in queues]
    for w in workers:
        w.start()
    try:
        yield workers
    finally:
        for w in workers:
            w.stop()


def _make_signed_payload(seed: int, model_id: str) -> dict:
    rng = np.random.default_rng(seed)
    dense = rng.standard_normal((4, 4)).astype(np.float32)
    dense[dense < 1.2] = 0  # sparsify
    indices = np.argwhere(dense != 0).astype(np.int32)
    values = dense[indices[:, 0], indices[:, 1]].astype(np.float32)
    delta = SparseDelta(
        indices=indices,
        values=values,
        shape=dense.shape,
        layer="layers.0.attn.q_proj.weight",
        model_id=model_id,
        version=1,
        trust=np.ones(6, dtype=np.float32) * 0.8,
        source_hash=f"{seed:064x}",
        time_steps=8,
        threshold=1.0,
    )
    signer = Signer(secret=bytes([seed % 256]) * 32)
    env = to_envelope(delta, signer)
    return {
        "model_id": env.model_id,
        "layer": env.layer,
        "indices_b64": env.indices_b64,
        "values_b64": env.values_b64,
        "shape": list(env.shape),
        "version": env.version,
        "trust": env.trust,
        "source_hash": env.source_hash,
        "time_steps": env.time_steps,
        "threshold": env.threshold,
        "spike_times_b64": env.spike_times_b64,
        "signature_b64": env.signature_b64,
        "public_key_b64": env.public_key_b64,
        "timestamp": env.timestamp,
    }


def test_three_uvicorn_workers_gossip_to_full_coverage():
    """Each worker learns every digest after a rumour round."""
    with _three_workers() as workers:
        # Build the full set of envelopes ONCE — timestamps are baked into
        # the digest, so regenerating would produce different digests.
        all_payloads = [
            _make_signed_payload(seed=i + 1, model_id=f"model-{i}")
            for i in range(len(workers))
        ]

        # 1. Submit a unique envelope to each worker.
        submitted_digests: list[str] = []
        for i, worker in enumerate(workers):
            r = httpx.post(worker.url("/contribute"), json=all_payloads[i], timeout=5.0)
            assert r.status_code == 200, r.text
            submitted_digests.append(r.json()["digest"])

        # 2. First snapshot: each worker knows exactly one digest.
        for worker, digest in zip(workers, submitted_digests, strict=True):
            r = httpx.post(
                worker.url("/gossip"), json={"digests": []}, timeout=5.0
            )
            assert r.status_code == 200
            assert digest in r.json()["offer_to_peer"]

        # 3. Broadcast phase: every worker receives every envelope.
        for worker in workers:
            for payload in all_payloads:
                httpx.post(worker.url("/contribute"), json=payload, timeout=5.0)

        # 4. After the rumour round every worker knows every digest.
        for worker in workers:
            r = httpx.post(
                worker.url("/gossip"),
                json={"digests": submitted_digests},
                timeout=5.0,
            )
            body = r.json()
            assert set(body["common"]) == set(submitted_digests), (
                f"worker on {worker.port} missed digests: {body}"
            )


def test_uvicorn_worker_rejects_invalid_signature():
    """A malformed signature must be rejected by /contribute with 400."""
    with _three_workers() as workers:
        worker = workers[0]
        payload = _make_signed_payload(seed=7, model_id="tamper")
        payload["signature_b64"] = "AAAA"  # corrupt
        r = httpx.post(worker.url("/contribute"), json=payload, timeout=5.0)
        assert r.status_code == 400
