# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Tests for the crdt_merge.e4 wiring in borg.e4."""

import numpy as np
import pytest

pytest.importorskip("crdt_merge.e4")

from borg.e4 import (  # noqa: E402
    DIMENSION_ORDER,
    PeerContext,
    build_pco,
    trust_vector_hash,
    trust_vector_to_score,
)


def test_dimension_order_matches_upstream():
    from crdt_merge.e4.typed_trust import TRUST_DIMENSIONS

    assert set(DIMENSION_ORDER) == TRUST_DIMENSIONS


def test_trust_vector_to_score_preserves_ordering():
    low = np.array([0.1] * 6, dtype=np.float32)
    high = np.array([0.9] * 6, dtype=np.float32)
    s_low = trust_vector_to_score(low, peer_id="p")
    s_high = trust_vector_to_score(high, peer_id="p")
    assert s_high.overall_trust() > s_low.overall_trust()


def test_trust_vector_hash_is_stable():
    v = np.array([0.5, 0.6, 0.7, 0.8, 0.9, 1.0], dtype=np.float32)
    a = trust_vector_hash(v)
    b = trust_vector_hash(v.copy())
    assert a == b


def test_pco_is_exactly_128_bytes():
    ctx = PeerContext.new(peer_id="borg")
    ctx.record_self_trust(np.ones(6, dtype=np.float32))
    clock = ctx.step()
    blob = build_pco(
        peer_id="borg",
        clock=clock,
        merkle_root="a" * 64,
        trust_vec=np.ones(6, dtype=np.float32),
    )
    assert len(blob) == 128


def test_causal_clock_advances():
    ctx = PeerContext.new(peer_id="borg")
    t0 = ctx.clock.logical_time
    ctx.step()
    assert ctx.clock.logical_time > t0
