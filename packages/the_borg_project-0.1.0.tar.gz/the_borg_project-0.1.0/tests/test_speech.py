# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Fixture-based speech transcription test.

Closes the partial row on the status matrix. Uses an injected transcriber
so the test runs without downloading Whisper-Tiny weights. The test
asserts:

* A short synthetic sine wave is written to wav, the injected
  transcriber is called exactly once, and the returned string is
  propagated.
* Empty-audio short-circuits without invoking the transcriber.
* Invalid sample rates raise ValueError.
* The default transcriber code path raises a clear RuntimeError when
  transformers is unavailable.

Whisper-Tiny is still the production backend; the full network-backed
behaviour is exercised by `bench-pretrained.yml` on a live runner.
"""

from __future__ import annotations

import numpy as np
import pytest

pytest.importorskip("soundfile", exc_type=ImportError)

from borg.speech import transcribe  # noqa: E402


def _sine_wave(rate: int = 16000, freq: float = 440.0, seconds: float = 0.5) -> np.ndarray:
    t = np.linspace(0, seconds, int(rate * seconds), endpoint=False, dtype=np.float32)
    return (0.1 * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_transcribe_with_injected_backend_returns_its_string():
    calls = {"n": 0, "path": None}

    def fake_asr(path: str) -> str:
        calls["n"] += 1
        calls["path"] = path
        return "hello borg"

    samples = _sine_wave()
    out = transcribe((16000, samples), transcriber=fake_asr)
    assert out == "hello borg"
    assert calls["n"] == 1
    # The path passed to the transcriber must be a real wav file.
    from pathlib import Path

    # file is deleted after transcribe returns (finally block), so we only
    # assert the suffix was set correctly.
    assert str(calls["path"]).endswith(".wav")


def test_transcribe_accepts_dict_result_shape():
    def pipeline_like(path: str) -> dict:
        return {"text": "whisper-compatible", "chunks": []}

    out = transcribe((16000, _sine_wave()), transcriber=pipeline_like)
    assert out == "whisper-compatible"


def test_empty_audio_short_circuits_without_calling_backend():
    called = {"n": 0}

    def should_not_run(_path: str) -> str:  # noqa: ARG001
        called["n"] += 1
        return "unreachable"

    out = transcribe((16000, np.zeros(0, dtype=np.float32)), transcriber=should_not_run)
    assert out == ""
    assert called["n"] == 0


def test_invalid_sample_rate_raises():
    with pytest.raises(ValueError):
        transcribe((0, _sine_wave()), transcriber=lambda p: "ignored")


def test_default_backend_raises_clear_error_when_transformers_missing(monkeypatch):
    """If transformers isn't installed, user gets a RuntimeError with a hint."""
    import sys

    # Simulate transformers being absent by shadowing the import.
    monkeypatch.setitem(sys.modules, "transformers", None)
    with pytest.raises(RuntimeError) as exc:
        transcribe((16000, _sine_wave()))
    assert "speech" in str(exc.value).lower() or "transformers" in str(exc.value).lower()
