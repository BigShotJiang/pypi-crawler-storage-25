# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""FAISS-backed document store."""

from __future__ import annotations

import json
import os
from collections.abc import Iterable
from pathlib import Path

import numpy as np


class DocStore:
    def __init__(
        self,
        embedder_name: str = "sentence-transformers/all-MiniLM-L6-v2",
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        embedder=None,
    ):
        """Document store backed by FAISS over sentence-transformer embeddings.

        `embedder` can be injected for tests and offline use. Any object with
        an `.encode(list[str]) -> array-like` method and
        `get_sentence_embedding_dimension()` is accepted.
        """
        self.embedder_name = embedder_name
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self._chunks: list[str] = []
        self._sources: list[str] = []
        self._embedder = embedder
        self._index = None
        if embedder is not None and hasattr(embedder, "get_sentence_embedding_dimension"):
            self._dim = int(embedder.get_sentence_embedding_dimension())
        else:
            self._dim = 384

    def _lazy_embedder(self):
        if self._embedder is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as exc:
                raise RuntimeError(
                    "sentence-transformers is required. "
                    "Install with: pip install the-borg-project[rag]"
                ) from exc
            self._embedder = SentenceTransformer(self.embedder_name)
            self._dim = int(self._embedder.get_sentence_embedding_dimension())
        return self._embedder

    def _lazy_index(self):
        if self._index is None:
            try:
                import faiss
            except ImportError as exc:
                raise RuntimeError(
                    "faiss is required. Install with: pip install the-borg-project[rag]"
                ) from exc
            self._lazy_embedder()
            self._index = faiss.IndexFlatL2(self._dim)
        return self._index

    def ingest(self, paths: Iterable[str]) -> int:
        new_chunks: list[str] = []
        new_sources: list[str] = []
        for p in paths:
            text = _read_any(p)
            for chunk in _chunk(text, self.chunk_size, self.chunk_overlap):
                new_chunks.append(chunk)
                new_sources.append(str(p))
        if not new_chunks:
            return 0
        embedder = self._lazy_embedder()
        index = self._lazy_index()
        vecs = np.asarray(embedder.encode(new_chunks), dtype=np.float32)
        index.add(vecs)
        self._chunks.extend(new_chunks)
        self._sources.extend(new_sources)
        return len(new_chunks)

    def query(self, prompt: str, k: int = 3) -> list[tuple[str, str]]:
        if not self._chunks:
            return []
        embedder = self._lazy_embedder()
        index = self._lazy_index()
        q = np.asarray(embedder.encode([prompt]), dtype=np.float32)
        _, idx = index.search(q, min(k, len(self._chunks)))
        return [(self._sources[i], self._chunks[i]) for i in idx[0] if i < len(self._chunks)]

    def save(self, path: str) -> None:
        import faiss

        Path(path).mkdir(parents=True, exist_ok=True)
        faiss.write_index(self._lazy_index(), os.path.join(path, "index.faiss"))
        with open(os.path.join(path, "chunks.json"), "w", encoding="utf-8") as f:
            json.dump({"chunks": self._chunks, "sources": self._sources}, f)

    def load(self, path: str) -> None:
        import faiss

        self._index = faiss.read_index(os.path.join(path, "index.faiss"))
        with open(os.path.join(path, "chunks.json"), encoding="utf-8") as f:
            payload = json.load(f)
        self._chunks = payload["chunks"]
        self._sources = payload["sources"]


def _chunk(text: str, size: int, overlap: int) -> list[str]:
    if size <= 0:
        raise ValueError("size must be positive")
    if overlap >= size:
        raise ValueError("overlap must be smaller than size")
    step = size - overlap
    return [text[i : i + size] for i in range(0, max(1, len(text)), step)]


def _read_any(path: str) -> str:
    p = Path(path)
    suffix = p.suffix.lower()
    if suffix in {".txt", ".md"}:
        return p.read_text(encoding="utf-8", errors="replace")
    if suffix == ".pdf":
        from pypdf import PdfReader

        reader = PdfReader(str(p))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    if suffix == ".docx":
        from docx import Document

        doc = Document(str(p))
        return "\n".join(par.text for par in doc.paragraphs)
    return p.read_text(encoding="utf-8", errors="replace")
