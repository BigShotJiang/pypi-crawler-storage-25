# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Retrieval helpers on top of `DocStore`."""

from __future__ import annotations

from borg.rag.ingest import DocStore


def format_context(hits: list[tuple[str, str]]) -> str:
    if not hits:
        return ""
    return "\n\n".join(f"[{i + 1}] ({src}) {chunk}" for i, (src, chunk) in enumerate(hits))


def retrieve(store: DocStore, prompt: str, k: int = 3) -> tuple[str, list[str]]:
    hits = store.query(prompt, k=k)
    return format_context(hits), [src for src, _ in hits]
