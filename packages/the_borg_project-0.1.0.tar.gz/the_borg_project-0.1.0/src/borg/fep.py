# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Variational free-energy refinement.

Implements a mean-field Gaussian variational posterior `q(theta) = N(mu, diag(sigma^2))`
over the non-zero cells of the resolved state, and descends the evidence
lower bound:

    ELBO(theta, q) = E_q[log p(o | theta)] - KL(q || p)

with `p = N(resolved, prior_sigma^2)` as the prior centred on the CRDT
resolve output. `F = -ELBO` is the free energy; minimising it tunes the
posterior to reduce prediction error on a probe set while staying
anchored to the CRDT state.

Monotonicity on the lattice is preserved by two rules (Spec 04):
1. Only cells with |resolved| > 0 are refinable. Zero cells stay zero.
2. The mean update is clipped to `alpha * |resolved|` per step, so the
   refined state remains in the half-space reachable by the original
   contributions.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class FEPConfig:
    lr: float = 1e-4
    steps: int = 50
    alpha: float = 0.05
    prior_sigma: float = 1.0
    init_log_sigma: float = -2.0
    mc_samples: int = 4
    seed: int = 0


@dataclass
class Posterior:
    mu: dict[str, np.ndarray]
    log_sigma: dict[str, np.ndarray]


def init_posterior(resolved: dict[str, np.ndarray], config: FEPConfig) -> Posterior:
    mu = {k: v.copy() for k, v in resolved.items()}
    log_sigma = {
        k: np.full_like(v, config.init_log_sigma, dtype=np.float32) for k, v in resolved.items()
    }
    return Posterior(mu=mu, log_sigma=log_sigma)


def sample(
    posterior: Posterior,
    rng: np.random.Generator,
    resolved_mask: dict[str, np.ndarray],
) -> dict[str, np.ndarray]:
    """Draw theta from the posterior using the reparameterisation trick."""
    out: dict[str, np.ndarray] = {}
    for k, mu in posterior.mu.items():
        sigma = np.exp(posterior.log_sigma[k])
        eps = rng.standard_normal(mu.shape).astype(np.float32)
        out[k] = mu + sigma * eps
        out[k] = out[k] * resolved_mask[k]
    return out


def kl_to_prior(
    posterior: Posterior,
    resolved: dict[str, np.ndarray],
    mask: dict[str, np.ndarray],
    prior_sigma: float,
) -> float:
    """Closed-form KL divergence per cell, summed over all cells.

    KL(N(mu, sigma^2) || N(m, s^2)) =
        log(s/sigma) + (sigma^2 + (mu - m)^2) / (2 s^2) - 0.5
    """
    total = 0.0
    s2 = prior_sigma * prior_sigma
    for k, mu in posterior.mu.items():
        sigma = np.exp(posterior.log_sigma[k])
        m = resolved[k]
        cellwise = (
            np.log(prior_sigma) - posterior.log_sigma[k]
            + (sigma * sigma + (mu - m) ** 2) / (2 * s2)
            - 0.5
        )
        total += float(np.sum(cellwise * mask[k]))
    return total


def _probe_loss(
    weights: dict[str, np.ndarray],
    inputs: np.ndarray,
    targets: np.ndarray,
) -> float:
    pred = inputs
    for layer in sorted(weights):
        w = weights[layer]
        if pred.ndim != 2 or w.ndim != 2:
            continue
        if pred.shape[1] != w.shape[0]:
            continue
        pred = pred @ w
    diff = pred - targets
    return float(0.5 * np.mean(diff * diff))


def elbo(
    posterior: Posterior,
    resolved: dict[str, np.ndarray],
    mask: dict[str, np.ndarray],
    probe_inputs: np.ndarray,
    probe_targets: np.ndarray,
    config: FEPConfig,
    rng: np.random.Generator,
) -> tuple[float, float, float]:
    """Monte-Carlo ELBO estimate. Returns (elbo, neg_loglik, kl)."""
    loglik_sum = 0.0
    for _ in range(config.mc_samples):
        theta = sample(posterior, rng, mask)
        loglik_sum += -_probe_loss(theta, probe_inputs, probe_targets)
    expected_loglik = loglik_sum / max(1, config.mc_samples)
    kl = kl_to_prior(posterior, resolved, mask, config.prior_sigma)
    return expected_loglik - kl, -expected_loglik, kl


def refine(
    resolved: dict[str, np.ndarray],
    probe_inputs: np.ndarray | None = None,
    probe_targets: np.ndarray | None = None,
    config: FEPConfig | None = None,
) -> dict[str, np.ndarray]:
    """Variational refinement of the resolved state.

    Returns the posterior mean, clipped to the lattice-monotone envelope.
    If no probe is supplied, returns `resolved` unchanged.
    """
    if probe_inputs is None or probe_targets is None:
        return resolved

    cfg = config or FEPConfig()
    rng = np.random.default_rng(cfg.seed)

    mask = {k: (np.abs(v) > 0).astype(np.float32) for k, v in resolved.items()}
    posterior = init_posterior(resolved, cfg)

    prev_elbo = elbo(posterior, resolved, mask, probe_inputs, probe_targets, cfg, rng)[0]

    for _ in range(cfg.steps):
        grads_mu, grads_ls = _elbo_grads(
            posterior, resolved, mask, probe_inputs, probe_targets, cfg, rng
        )
        for k in posterior.mu:
            posterior.mu[k] = posterior.mu[k] + cfg.lr * grads_mu[k] * mask[k]
            cap = cfg.alpha * np.abs(resolved[k])
            delta = np.clip(posterior.mu[k] - resolved[k], -cap, cap)
            posterior.mu[k] = resolved[k] + delta
            posterior.log_sigma[k] = posterior.log_sigma[k] + cfg.lr * grads_ls[k] * mask[k]
            posterior.log_sigma[k] = np.clip(posterior.log_sigma[k], -6.0, 1.0)

        new_elbo = elbo(
            posterior, resolved, mask, probe_inputs, probe_targets, cfg, rng
        )[0]
        if new_elbo + 1e-8 < prev_elbo:
            return {k: resolved[k] * mask[k] for k in resolved}
        prev_elbo = new_elbo

    return {k: posterior.mu[k] * mask[k] for k in resolved}


def _elbo_grads(
    posterior: Posterior,
    resolved: dict[str, np.ndarray],
    mask: dict[str, np.ndarray],
    probe_inputs: np.ndarray,
    probe_targets: np.ndarray,
    config: FEPConfig,
    rng: np.random.Generator,
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    """Monte-Carlo reparameterised gradient estimates for mu and log_sigma.

    Gradient signal is the score-function rule applied to the sampled
    theta, projected back through the reparameterisation. We approximate
    with finite differences on a small random set of non-zero cells to
    keep the step cost bounded.
    """
    base_elbo, _, _ = elbo(
        posterior, resolved, mask, probe_inputs, probe_targets, config, rng
    )

    grads_mu: dict[str, np.ndarray] = {}
    grads_ls: dict[str, np.ndarray] = {}

    eps = 1e-3
    for k, mu in posterior.mu.items():
        gmu = np.zeros_like(mu)
        gls = np.zeros_like(posterior.log_sigma[k])
        nz = np.argwhere(mask[k] > 0)
        if nz.shape[0] == 0:
            grads_mu[k] = gmu
            grads_ls[k] = gls
            continue
        sample_size = min(128, nz.shape[0])
        sel = nz[rng.choice(nz.shape[0], size=sample_size, replace=False)]

        for idx in sel:
            pos = tuple(int(x) for x in idx)
            original = mu[pos]
            mu[pos] = original + eps
            perturbed_elbo = elbo(
                posterior, resolved, mask, probe_inputs, probe_targets, config, rng
            )[0]
            mu[pos] = original
            gmu[pos] = (perturbed_elbo - base_elbo) / eps

            original_ls = posterior.log_sigma[k][pos]
            posterior.log_sigma[k][pos] = original_ls + eps
            perturbed_elbo_ls = elbo(
                posterior, resolved, mask, probe_inputs, probe_targets, config, rng
            )[0]
            posterior.log_sigma[k][pos] = original_ls
            gls[pos] = (perturbed_elbo_ls - base_elbo) / eps

        grads_mu[k] = gmu
        grads_ls[k] = gls

    return grads_mu, grads_ls


def free_energy(
    posterior: Posterior,
    resolved: dict[str, np.ndarray],
    mask: dict[str, np.ndarray],
    probe_inputs: np.ndarray,
    probe_targets: np.ndarray,
    config: FEPConfig,
    rng: np.random.Generator | None = None,
) -> float:
    """Return F = -ELBO as a scalar, for diagnostics."""
    rng = rng or np.random.default_rng(config.seed)
    e, _, _ = elbo(posterior, resolved, mask, probe_inputs, probe_targets, config, rng)
    return -e


__all__ = [
    "FEPConfig",
    "Posterior",
    "elbo",
    "free_energy",
    "init_posterior",
    "kl_to_prior",
    "refine",
    "sample",
]
