# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Microphone transcription adapter.

Default backend: `transformers.pipeline("automatic-speech-recognition",
model="openai/whisper-tiny")`. A converted SNN ASR path is on the roadmap.

The `transcriber` arg accepts an injected callable for tests and
offline use. Any callable that takes a wav-file path and returns
either a string or `{"text": ...}` works. When None, the default
Whisper-Tiny HF pipeline is lazy-loaded.
"""

from __future__ import annotations

import tempfile
from collections.abc import Callable
from pathlib import Path
from typing import Any

import numpy as np


def transcribe(
    audio: tuple[int, np.ndarray],
    model: str = "openai/whisper-tiny",
    transcriber: Callable[[str], Any] | None = None,
) -> str:
    """Transcribe a (sample_rate, samples) pair into a string.

    Raises `RuntimeError` with install hints when the default backend
    is used and its deps are missing.
    """
    try:
        import soundfile as sf
    except ImportError as exc:
        raise RuntimeError(
            "speech extras are required. "
            "Install with: pip install the-borg-project[speech]"
        ) from exc

    rate, samples = audio
    if rate <= 0:
        raise ValueError("sample rate must be positive")
    if getattr(samples, "size", 0) == 0:
        return ""

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        sf.write(tmp.name, samples, rate)
        tmp_path = Path(tmp.name)

    try:
        if transcriber is None:
            try:
                from transformers import pipeline
            except ImportError as exc:
                raise RuntimeError(
                    "transformers is required for default speech backend. "
                    "Install with: pip install the-borg-project[speech]"
                ) from exc
            transcriber = pipeline("automatic-speech-recognition", model=model)
        result = transcriber(str(tmp_path))
        if isinstance(result, dict):
            return str(result.get("text", ""))
        if isinstance(result, str):
            return result
        return str(result)
    finally:
        tmp_path.unlink(missing_ok=True)
