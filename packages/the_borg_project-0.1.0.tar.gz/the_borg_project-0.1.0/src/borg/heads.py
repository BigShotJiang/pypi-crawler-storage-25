# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Head-type registry for the Borg collective.

Every absorbed model is categorised by what it can produce: a causal
language-model head, a masked language-model head, a sentence embedder,
a classifier, or unknown. The registry is persisted alongside the
state so the universal decoder can pick the right dispatch path per
query.

Storage is a base64-encoded JSON blob inside the state_dict under
`HEADS_KEY`. Using the state_dict keeps the heads registry inside the
same torch.save payload as the weights, and it round-trips through
the INT8 quantiser unchanged because it's a 1-D byte tensor.
"""

from __future__ import annotations

import base64
import json
from dataclasses import asdict, dataclass
from typing import Any

import torch

HEADS_KEY = "__borg_heads_v1__"

CAUSAL_LM = "causal_lm"
MASKED_LM = "masked_lm"
EMBEDDER = "embedder"
CLASSIFIER = "classifier"
UNKNOWN = "unknown"

# Ordered so dispatch prefers the most expressive output first.
DISPATCH_ORDER = (CAUSAL_LM, MASKED_LM, CLASSIFIER, EMBEDDER, UNKNOWN)


@dataclass
class HeadRecord:
    """One absorbed model's capability registration."""

    model_id: str
    head_type: str
    head_keys: list[str]
    vocab_size: int | None = None
    hidden_size: int | None = None
    tokenizer_id: str | None = None


# ---- detection -----------------------------------------------------------


def detect_head_type(state_dict: dict[str, torch.Tensor]) -> HeadRecord:
    """Inspect a source state dict and classify its output head.

    Returns a HeadRecord with `model_id` unset (caller fills it in).
    """
    keys = list(state_dict.keys())

    # 1. Causal LM: a standalone lm_head.weight (shape [vocab, hidden])
    #    OR any *.lm_head.weight / decoder.weight / output_projection.weight
    #    at the top of a transformer-style stack.
    for k in ("lm_head.weight", "lm_head.decoder.weight", "head.weight",
              "output_projection.weight", "output.weight", "decoder.weight",
              "embed_out.weight"):
        if k in state_dict and state_dict[k].ndim == 2:
            w = state_dict[k]
            return HeadRecord(
                model_id="",
                head_type=CAUSAL_LM,
                head_keys=_collect_head_keys(keys, k),
                vocab_size=int(w.shape[0]),
                hidden_size=int(w.shape[1]),
            )

    # 2. Masked LM (BERT / RoBERTa MLM): cls.predictions.decoder.weight
    #    or lm_head.dense + lm_head.layer_norm + tied input embeddings.
    for k in ("cls.predictions.decoder.weight", "cls.predictions.transform.dense.weight"):
        if k in state_dict and state_dict[k].ndim == 2:
            w = state_dict[k]
            return HeadRecord(
                model_id="",
                head_type=MASKED_LM,
                head_keys=_collect_head_keys(keys, k),
                vocab_size=int(w.shape[0]),
                hidden_size=int(w.shape[1]),
            )
    if "lm_head.dense.weight" in state_dict:
        # RoBERTa MLM-style. Tied embeddings serve as the decoder.
        tied = None
        for k in ("roberta.embeddings.word_embeddings.weight",
                  "embeddings.word_embeddings.weight"):
            if k in state_dict and state_dict[k].ndim == 2:
                tied = state_dict[k]
                break
        if tied is not None:
            return HeadRecord(
                model_id="",
                head_type=MASKED_LM,
                head_keys=_collect_head_keys(keys, "lm_head.dense.weight"),
                vocab_size=int(tied.shape[0]),
                hidden_size=int(tied.shape[1]),
            )

    # 3. Sentence embedder: has pooler output / mean-pool layer,
    #    no causal or masked head. BGE, all-MiniLM, Sentence-Transformers.
    if any(k.endswith("pooler.dense.weight") for k in keys):
        dense_key = next(k for k in keys if k.endswith("pooler.dense.weight"))
        w = state_dict[dense_key]
        return HeadRecord(
            model_id="",
            head_type=EMBEDDER,
            head_keys=[dense_key],
            hidden_size=int(w.shape[0]),
        )
    # Alternate sentence-embedder layouts.
    for k in ("sentence_embedding.weight", "embedding_projection.weight"):
        if k in state_dict and state_dict[k].ndim == 2:
            w = state_dict[k]
            return HeadRecord(
                model_id="", head_type=EMBEDDER,
                head_keys=[k], hidden_size=int(w.shape[0]),
            )

    # 4. Classifier: classifier.weight with vocab-size << 1000 is a clear signal.
    for k in ("classifier.weight", "classifier.out_proj.weight", "score.weight"):
        if k in state_dict and state_dict[k].ndim == 2:
            w = state_dict[k]
            if w.shape[0] < 1000:  # cap: vocabs have vocab_size >= 30k
                return HeadRecord(
                    model_id="",
                    head_type=CLASSIFIER,
                    head_keys=[k],
                    vocab_size=int(w.shape[0]),
                    hidden_size=int(w.shape[1]),
                )

    return HeadRecord(model_id="", head_type=UNKNOWN, head_keys=[])


def _collect_head_keys(all_keys: list[str], primary: str) -> list[str]:
    """Group keys that share the primary's prefix (head weight + bias + norms)."""
    prefix = primary.rsplit(".", 1)[0]
    return [k for k in all_keys if k.startswith(prefix)]


# ---- registry ------------------------------------------------------------


def register_head(state: Any, record: HeadRecord) -> None:
    """Append a HeadRecord onto the state's capability registry.

    `state` is a `borg.inference.BorgState`. The registry is stored as
    a base64-encoded JSON blob under `HEADS_KEY` in `state.state_dict`,
    so it survives `torch.save` without schema changes.
    """
    existing = get_registered_heads(state)
    # Dedup by model_id -- latest registration wins.
    by_id = {r.model_id: r for r in existing}
    by_id[record.model_id] = record
    _write_heads(state, list(by_id.values()))


def get_registered_heads(state: Any) -> list[HeadRecord]:
    raw = getattr(state, "state_dict", {}).get(HEADS_KEY)
    if raw is None:
        return []
    try:
        blob = bytes(raw.cpu().numpy().tobytes()) if hasattr(raw, "cpu") else bytes(raw)
        payload = json.loads(base64.b64decode(blob).decode("utf-8"))
        return [HeadRecord(**r) for r in payload.get("heads", [])]
    except Exception:  # noqa: BLE001
        return []


def _write_heads(state: Any, heads: list[HeadRecord]) -> None:
    payload = {"version": 1, "heads": [asdict(h) for h in heads]}
    blob = base64.b64encode(json.dumps(payload).encode("utf-8"))
    tensor = torch.tensor(list(blob), dtype=torch.uint8)
    state.state_dict[HEADS_KEY] = tensor
    if hasattr(state, "clear_cache"):
        state.clear_cache()


# ---- summary helpers for the UI -----------------------------------------


def summarise_heads(state: Any) -> dict[str, Any]:
    """Produce a compact summary for the diagnostic panel.

    Returns totals by head type plus the list of model ids per type.
    """
    heads = get_registered_heads(state)
    by_type: dict[str, list[str]] = {}
    for h in heads:
        by_type.setdefault(h.head_type, []).append(h.model_id)
    return {
        "total": len(heads),
        "by_type": by_type,
        "has_causal_lm": CAUSAL_LM in by_type,
        "has_masked_lm": MASKED_LM in by_type,
        "has_embedder": EMBEDDER in by_type,
        "has_classifier": CLASSIFIER in by_type,
    }


def primary_head(state: Any) -> HeadRecord | None:
    """Pick the best head for text generation, by DISPATCH_ORDER."""
    heads = get_registered_heads(state)
    if not heads:
        return None
    for t in DISPATCH_ORDER:
        for h in heads:
            if h.head_type == t:
                return h
    return heads[0]


def retroactively_register(
    state: Any,
    manifest_model_ids: list[str] | None = None,
) -> int:
    """Best-effort head detection for states absorbed before the registry shipped.

    If `state` already has registrations, this is a no-op. Otherwise we
    inspect the merged state's own layer keys -- BERT / RoBERTa / BGE /
    GPT-2 all leave architecture fingerprints (`pooler.dense.weight`,
    `encoder.layer.*`, `lm_head.weight`, `cls.predictions.decoder.weight`)
    that `detect_head_type` can read. Any detected record is registered
    under every model_id from the manifest (we can't attribute heads to
    specific models without the original source dict; the legacy state is
    a superposition anyway).

    Returns the number of records registered. Caller is responsible for
    persisting the state if it wants the registry saved.
    """
    if get_registered_heads(state):
        return 0
    sd = getattr(state, "state_dict", None)
    if not sd:
        return 0
    # Filter out borg-internal keys and 0-D scalars to keep detection tight.
    sample: dict[str, Any] = {}
    for k, v in sd.items():
        if k == HEADS_KEY:
            continue
        if k.endswith(".scale"):
            continue
        sample[k] = v
    rec = detect_head_type(sample)
    if rec.head_type == UNKNOWN:
        # Even the unknown record is useful on the panel; flag it.
        pass
    mids = list(manifest_model_ids or [])
    if not mids:
        mids = ["legacy/unknown"]
    for mid in mids:
        this_rec = HeadRecord(
            model_id=mid,
            head_type=rec.head_type,
            head_keys=rec.head_keys,
            vocab_size=rec.vocab_size,
            hidden_size=rec.hidden_size,
            tokenizer_id=getattr(state, "tokenizer_id", None),
        )
        register_head(state, this_rec)
    return len(mids)


__all__ = [
    "CAUSAL_LM",
    "CLASSIFIER",
    "DISPATCH_ORDER",
    "EMBEDDER",
    "HEADS_KEY",
    "HeadRecord",
    "MASKED_LM",
    "UNKNOWN",
    "detect_head_type",
    "get_registered_heads",
    "primary_head",
    "register_head",
    "retroactively_register",
    "summarise_heads",
]
