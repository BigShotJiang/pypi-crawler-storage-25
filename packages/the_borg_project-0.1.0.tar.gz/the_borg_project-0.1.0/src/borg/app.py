# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Gradio demo UI: chat, file upload (RAG), microphone input.

Chain-of-thought is applied at the prompt layer. The system prompt below is
injected before the user's question and instructs the downstream decoder to
show its intermediate steps.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

SYSTEM_PROMPT = """You are Borg. Answer in three steps.
step 1: restate the question in one sentence.
step 2: list the facts you are using and where they came from.
step 3: give the final answer. keep it concise.
If a document context is provided, ground every factual claim in it and
name the chunk index you used.
""".strip()


def compose_prompt(user_prompt: str, context: str = "") -> str:
    parts = [SYSTEM_PROMPT, ""]
    if context:
        parts += ["context:", context, ""]
    parts += ["question:", user_prompt]
    return "\n".join(parts)


def build():
    # Importing gradio can fail not only if it is missing, but also if a
    # transitive dep (e.g. pydub on Python 3.13 missing the removed
    # `audioop` stdlib) raises ModuleNotFoundError. Surface the real
    # error rather than masking it with a generic install hint.
    import gradio as gr

    # Optional: HF Spaces ZeroGPU. The `spaces` package only exists on
    # the HF infrastructure. When absent (local dev, CI, the standard
    # CPU Space), `gpu` becomes a no-op decorator so the same code runs
    # everywhere unchanged.
    try:
        import spaces  # type: ignore[import-not-found]

        gpu = spaces.GPU
    except ImportError:
        def gpu(duration: int = 60):  # noqa: ARG001
            def _decorator(fn):
                return fn

            return _decorator

    from borg.inference import BorgState, forward, load
    from borg.rag import DocStore
    from borg.rag.retrieve import retrieve

    borg_path = os.environ.get("BORG_STATE", "borg_snn.pt")

    # State is loaded lazily and re-loaded if the file is replaced underneath
    # us. Two refresh triggers land in the cache below:
    #   1. mtime change on `borg_path` -- covers `publish.yml` redeploys
    #      that bundle a new borg_snn.pt into the Space repo.
    #   2. remote `borg_version.json` sha256 change on GCS -- covers the
    #      Colab notebook's `_checkpoint_to_space` uploads. Polled on
    #      every state access; the HTTPS GET is ~200 bytes so the cost
    #      is negligible compared to a spike_forward call.
    _state_cache: dict[str, BorgState | float | None] = {"obj": None, "mtime": 0.0}

    def _maybe_refresh_from_gcs() -> None:
        """Best-effort re-sync from GCS. Any failure is swallowed so the
        Space keeps serving from the cached local state."""
        if os.environ.get("BORG_GCS_BUCKET", "unset") == "":
            return
        try:
            from borg.gcs import apply_gcs_state_env
            apply_gcs_state_env()
        except Exception:  # noqa: BLE001
            pass

    def _current_state() -> BorgState | None:
        _maybe_refresh_from_gcs()
        # BORG_STATE may have been updated by the GCS sync above.
        path = Path(os.environ.get("BORG_STATE", borg_path))
        if not path.exists():
            _state_cache["obj"] = None
            _state_cache["mtime"] = 0.0
            return None
        mtime = path.stat().st_mtime
        if _state_cache["obj"] is None or mtime != _state_cache["mtime"]:
            _state_cache["obj"] = load(str(path))
            _state_cache["mtime"] = mtime
        return _state_cache["obj"]  # type: ignore[return-value]

    def _state_status() -> str:
        path = Path(borg_path)
        cwd = Path.cwd()
        if not path.exists():
            neighbours = sorted(p.name for p in cwd.iterdir())[:20]
            return (
                "## Borg state\n"
                f"- cwd: `{cwd}`\n"
                f"- borg_path: `{borg_path}` -> **(missing)**\n"
                f"- cwd contents (top 20): {neighbours}\n\n"
                "Run a `publish` workflow with the `assimilate_source` "
                "input set to absorb a model.\n"
            )

        size_mb = path.stat().st_size / 1024 / 1024
        state = _current_state()
        body_keys = []
        n_params_total = 0
        n_params_nonzero = 0
        thresholds_range: tuple[float, float] | None = None
        calibrated = False
        if state is not None:
            from borg.decode import has_lm_head
            from borg.inference import _linear_layers

            body_keys = _linear_layers(state)
            for k, t in state.state_dict.items():
                if k.endswith(".scale"):
                    continue
                n_params_total += int(t.numel())
                if state.quantized and not t.dtype.is_floating_point:
                    n_params_nonzero += int((t != 0).sum().item())
                else:
                    n_params_nonzero += int((t.abs() > 0).sum().item())
            if state.thresholds:
                vals = list(state.thresholds.values())
                thresholds_range = (min(vals), max(vals))
            from borg.calibration import CALIB_SCALE_KEY

            calibrated = CALIB_SCALE_KEY in state.state_dict
            head_present = has_lm_head(state)
        else:
            head_present = False

        sparsity = 1.0 - n_params_nonzero / n_params_total if n_params_total else 0.0

        absorbed: list[dict] = []
        contributor_count = 0
        manifest_path = Path(borg_path + ".manifest.json")
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text())
                absorbed = list(manifest.get("contributions", []))
                or_set = manifest.get("contributor_or_set") or {}
                contributor_count = len(or_set.get("contributors", [])) if or_set else len(absorbed)
            except Exception:  # noqa: BLE001
                pass

        # Heads registry -- know what the collective can actually produce.
        # Legacy states absorbed before the capability layer shipped carry
        # no HEADS_KEY; retroactively_register inspects the merged state's
        # own layer names and registers a best-guess record so the panel
        # reflects reality on the very first load.
        head_rows: list[dict] = []
        head_summary: dict = {"total": 0, "by_type": {}}
        if state is not None:
            try:
                from borg.heads import (
                    get_registered_heads,
                    retroactively_register,
                    summarise_heads,
                )

                if not get_registered_heads(state):
                    manifest_ids = [a.get("model_id") for a in absorbed if a.get("model_id")]
                    retroactively_register(state, manifest_model_ids=manifest_ids)

                heads = get_registered_heads(state)
                head_rows = [
                    {
                        "model_id": h.model_id,
                        "head_type": h.head_type,
                        "tokenizer_id": h.tokenizer_id,
                        "vocab": h.vocab_size,
                        "hidden": h.hidden_size,
                    }
                    for h in heads
                ]
                head_summary = summarise_heads(state)
            except Exception:  # noqa: BLE001
                pass

        total_absorbed = max(len(absorbed), contributor_count, head_summary.get("total", 0))

        lines = [
            "## Borg state",
            f"- file: `{path.resolve()}` ({size_mb:.2f} MB)",
            f"- tokenizer: `{state.tokenizer_id}`" if state and state.tokenizer_id else "- tokenizer: (none)",
            f"- quantized: {state.quantized if state else 'n/a'}",
            f"- LM head present: {head_present}",
            f"- calibration applied: {calibrated}",
            "",
            "## Architecture",
            f"- total tensors: {len(state.state_dict) if state else 0}",
            f"- body linear layers (in spike loop): {len(body_keys)}",
            f"- total parameters: {n_params_total:,}",
            f"- non-zero parameters: {n_params_nonzero:,}",
            f"- sparsity: {sparsity:.2%}",
            (f"- thresholds range: {thresholds_range[0]:.3f} -> {thresholds_range[1]:.3f}"
             + (" (normalised to 1.0 by rescale)" if thresholds_range[0] == thresholds_range[1] == 1.0 else ""))
            if thresholds_range else "- thresholds range: n/a",
            f"- time steps per token: {state.time_steps if state else 'n/a'}",
            "",
            "## Capability registry",
            f"- heads registered: {head_summary.get('total', 0)}",
            f"- has causal LM: {head_summary.get('has_causal_lm', False)}",
            f"- has masked LM: {head_summary.get('has_masked_lm', False)}",
            f"- has embedder: {head_summary.get('has_embedder', False)}",
            f"- has classifier: {head_summary.get('has_classifier', False)}",
            "",
            "## Assimilated models",
            f"- count: {total_absorbed}",
        ]
        if absorbed:
            sorted_abs = sorted(absorbed, key=lambda e: -int(e.get("params", 0)))
            for m in sorted_abs[:20]:
                mid = m.get("model_id", "?")
                head_type = next(
                    (h.get("head_type", "unknown") for h in head_rows if h.get("model_id") == mid),
                    "unknown",
                )
                layers = m.get("layers", 0)
                params = int(m.get("params", 0))
                sp = m.get("sparsity")
                sp_str = f"{sp:.1%}" if isinstance(sp, (int, float)) else "n/a"
                lines.append(
                    f"  - `{mid}` [{head_type}] layers={layers} params={params:,} sparsity={sp_str}"
                )
            if len(sorted_abs) > 20:
                lines.append(f"  - ... (+{len(sorted_abs) - 20} more)")
        return "\n".join(lines)

    store = DocStore()

    max_new_tokens = int(os.environ.get("BORG_MAX_NEW_TOKENS", "8"))

    @gpu(duration=60)
    def chat(prompt: str, files):
        if files:
            store.ingest([f.name if hasattr(f, "name") else str(f) for f in files])
        context, sources = retrieve(store, prompt, k=3)
        composed = compose_prompt(prompt, context)
        borg_state = _current_state()
        if borg_state is None:
            body = "state not initialised. Run: python -m borg.assimilation <model-id>"
            return body, json.dumps(sources, indent=2)

        from borg.decode import DecodeConfig, universal_decode
        from borg.heads import get_registered_heads

        # Universal decoder dispatches on the capability registry so any
        # combination of absorbed heads produces a readable response.
        # We pass the user's raw `prompt` for the CoT restate step and
        # the full `composed` string (with system prompt + context) only
        # for the forward pass -- keeps the restate line clean.
        rag_hits: list[tuple[str, str]] = []
        try:
            rag_hits = store.query(prompt, k=3) or []
        except Exception:  # noqa: BLE001
            rag_hits = []
        try:
            body = universal_decode(
                borg_state,
                user_prompt=prompt,
                rag_hits=rag_hits,
                config=DecodeConfig(max_new_tokens=max_new_tokens),
                chain_of_thought=True,
                composed_prompt=composed,
            )
        except Exception as exc:  # noqa: BLE001
            heads = get_registered_heads(borg_state)
            body = (
                f"universal_decode failed ({type(exc).__name__}: {exc}). "
                f"Collective has {len(heads)} registered head(s); "
                "retry with a refreshed state or absorb a generative model."
            )
        return body, json.dumps(sources, indent=2)

    @gpu(duration=30)
    def speak(audio):
        from borg.speech import transcribe

        if audio is None:
            return ""
        return transcribe(audio)

    with gr.Blocks(title="The Borg Project") as demo:
        gr.Markdown(
            "# The Borg Project\n"
            "Upload documents, speak, or type. The Borg answers in three "
            "steps: restate, cite, conclude."
        )
        gr.Markdown(value=_state_status, label="state status", every=10)
        with gr.Row():
            with gr.Column(scale=3):
                prompt = gr.Textbox(label="prompt", lines=3)
            with gr.Column(scale=1):
                audio = gr.Audio(sources=["microphone"], type="numpy", label="microphone")
        files = gr.File(label="attach documents", file_count="multiple")
        answer = gr.Textbox(label="answer", lines=12)
        citations = gr.Textbox(label="citations (source paths)", lines=3)

        gr.Button("send", variant="primary").click(
            chat,
            inputs=[prompt, files],
            outputs=[answer, citations],
            api_name="chat",
        )
        gr.Button("transcribe").click(
            speak,
            inputs=audio,
            outputs=prompt,
            api_name="transcribe",
        )

    return demo


# Module-level demo so HF Spaces can discover it on import
demo = build()


def main() -> None:
    demo.launch()


if __name__ == "__main__":
    main()


__all__ = ["SYSTEM_PROMPT", "build", "compose_prompt", "main"]
