# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Post-absorption logit calibration.

Training-free ANN-to-SNN conversion preserves rate-coded structure but
distorts the precise scale of the logit distribution at the LM head.
The argmax decode then locks onto a small basin of high-rate tokens and
oscillates (the "ophy ophy" failure mode).

`fit_logit_rescale` runs a small probe set through both the source model
and the freshly-absorbed Borg state, captures the logit vectors at each
side, and fits a per-token affine transform `(scale, bias)` that aligns
the SNN-decoded logits to the source-model distribution. The transform
is persisted on the state at `state_dict["lm_head.calibration_scale"]`
and `state_dict["lm_head.calibration_bias"]`. `borg.decode.logits_from_rates`
applies them before argmax.

This is one of the cheapest coherence improvements: ~10 probe samples,
~30 seconds extra at absorption time, and the decoded text typically
moves from random-token spam to recognisable English fragments.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch

CALIB_SCALE_KEY = "lm_head.calibration_scale"
CALIB_BIAS_KEY = "lm_head.calibration_bias"


@dataclass
class CalibrationConfig:
    n_probes: int = 8
    max_input_tokens: int = 16
    seed: int = 0


def _probe_inputs(tokenizer, n_probes: int, max_tokens: int, seed: int) -> list[list[int]]:
    """Sample short token sequences from the tokenizer's vocab as probes."""
    rng = np.random.default_rng(seed)
    vocab_size = getattr(tokenizer, "vocab_size", None) or len(tokenizer.get_vocab())
    probes: list[list[int]] = []
    for _ in range(n_probes):
        n = int(rng.integers(2, max_tokens + 1))
        ids = rng.integers(0, vocab_size, size=n).tolist()
        probes.append([int(t) for t in ids])
    return probes


def _source_logits(source_model, input_ids: list[int]) -> np.ndarray:
    """Last-token logits from the source ANN."""
    with torch.no_grad():
        out = source_model(torch.tensor([input_ids], dtype=torch.long))
        logits = out.logits if hasattr(out, "logits") else out[0]
    return logits[0, -1].detach().cpu().numpy().astype(np.float32)


def _snn_logits(borg_state, input_ids: list[int]) -> np.ndarray:
    """Last-token logits from the SNN forward + lm_head projection."""
    from borg.decode import _encode_ids, _first_layer_width, logits_from_rates
    from borg.inference import spike_forward

    width = _first_layer_width(borg_state)
    x = _encode_ids(input_ids, width)
    rates = spike_forward(borg_state, x)
    logits = logits_from_rates(rates, borg_state, _bypass_calibration=True)
    return logits[0].astype(np.float32)


def fit_logit_rescale(
    source_model,
    tokenizer,
    borg_state,
    config: CalibrationConfig | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Fit per-vocab `(scale, bias)` so SNN logits approximate source logits.

    Solves a 2-parameter affine fit per token id: minimise
    `sum_i (scale[v] * snn_logits[i, v] + bias[v] - src_logits[i, v])^2`.
    Returns (scale, bias), each shape (vocab_size,).
    """
    cfg = config or CalibrationConfig()
    probes = _probe_inputs(tokenizer, cfg.n_probes, cfg.max_input_tokens, cfg.seed)

    src_rows: list[np.ndarray] = []
    snn_rows: list[np.ndarray] = []
    for ids in probes:
        src_rows.append(_source_logits(source_model, ids))
        snn_rows.append(_snn_logits(borg_state, ids))

    src = np.stack(src_rows, axis=0)  # (n, vocab)
    snn = np.stack(snn_rows, axis=0)
    vocab = src.shape[1]
    if snn.shape[1] != vocab:
        raise ValueError(
            f"vocab mismatch: source {vocab}, snn {snn.shape[1]}"
        )

    scale = np.ones(vocab, dtype=np.float32)
    bias = np.zeros(vocab, dtype=np.float32)
    for v in range(vocab):
        x = snn[:, v].astype(np.float64)
        y = src[:, v].astype(np.float64)
        x_mean, y_mean = x.mean(), y.mean()
        denom = float(((x - x_mean) ** 2).sum())
        if denom < 1e-9:
            scale[v] = 1.0
            bias[v] = float(y_mean - x_mean)
        else:
            s = float(((x - x_mean) * (y - y_mean)).sum() / denom)
            scale[v] = s
            bias[v] = float(y_mean - s * x_mean)
    return scale, bias


def attach_calibration(
    state,
    scale: np.ndarray,
    bias: np.ndarray,
) -> None:
    """Persist the calibration on the state dict."""
    state.state_dict[CALIB_SCALE_KEY] = torch.from_numpy(scale.astype(np.float32))
    state.state_dict[CALIB_BIAS_KEY] = torch.from_numpy(bias.astype(np.float32))
    state.clear_cache()


__all__ = [
    "CALIB_BIAS_KEY",
    "CALIB_SCALE_KEY",
    "CalibrationConfig",
    "attach_calibration",
    "fit_logit_rescale",
]
