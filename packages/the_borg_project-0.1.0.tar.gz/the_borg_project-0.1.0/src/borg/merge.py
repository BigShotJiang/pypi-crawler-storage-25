# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Merge orchestration.

Converts per-model sparse deltas into CRDT contributions, stamps each with
a real `crdt_merge.e4` trust-lattice update and 128-byte PCO, optionally
rejects divergent contributions via a probe-loss gate, then resolves via
`CRDTMergeState`.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from typing import Any

import numpy as np

from borg.e4 import PeerContext, build_pco
from borg.sparse import (
    LayerContribution,
    SparseDelta,
    apply,
    apply_timing,
    extract,
    merge_timings,
)


@dataclass
class Manifest:
    merkle_root: str
    contributions: list[dict[str, Any]]
    strategy: str
    fep_refine: bool
    seed: int
    borg_path: str
    rejected: list[dict[str, Any]] = field(default_factory=list)
    # Upstream crdt_merge provenance: OR-Set of accepted contributor ids and
    # the serialised ProvenanceLog. architecture.md:129 names these as
    # first-class manifest surfaces; this is where they live.
    contributor_or_set: dict[str, Any] | None = None
    provenance_log: dict[str, Any] | None = None


@dataclass
class GateConfig:
    """Configuration for the benchmark-gated retention step."""

    enabled: bool = False
    tolerance: float = 0.1
    probe_fn: Callable[[dict[str, np.ndarray]], float] | None = None


def _merkle_root(tags: list[str]) -> str:
    """Compute the Merkle root over contribution tags.

    Backed by upstream `crdt_merge.merkle.MerkleTree` so the manifest
    root matches what any peer running the upstream library will
    compute for the same tag list. Falls back to a local SHA-256 pair
    fold if the upstream module is unavailable (keeps the library
    importable in minimal environments).
    """
    if not tags:
        return hashlib.sha256(b"").hexdigest()
    try:
        from crdt_merge.merkle import MerkleTree

        tree = MerkleTree(leaves=[{"id": t} for t in sorted(tags)], leaf_key="id")
        root = tree.root_hash  # property, not method, in upstream >=1.0
        if callable(root):
            root = root()
        if isinstance(root, str) and root:
            return root
    except Exception:  # noqa: BLE001
        pass
    level = [hashlib.sha256(t.encode("utf-8")).digest() for t in tags]
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        level = [hashlib.sha256(level[i] + level[i + 1]).digest() for i in range(0, len(level), 2)]
    return level[0].hex()


def _build_contributor_or_set(accepted: list[LayerContribution]) -> dict[str, Any] | None:
    """OR-Set of accepted contributor ids, backed by crdt_merge.core.ORSet."""
    try:
        from crdt_merge.core import ORSet
    except Exception:  # noqa: BLE001
        return None
    or_set = ORSet()
    for c in accepted:
        or_set.add(c.delta.model_id)
    try:
        return or_set.to_dict()
    except Exception:  # noqa: BLE001
        return {"contributors": list({c.delta.model_id for c in accepted})}


def _build_provenance_log(
    accepted: list[LayerContribution],
    rejected: list[LayerContribution],
    strategy: str,
) -> dict[str, Any] | None:
    """Upstream ProvenanceLog over the accepted + rejected contributions."""
    try:
        from crdt_merge.provenance import MergeDecision, MergeRecord, ProvenanceLog
    except Exception:  # noqa: BLE001
        return None
    records: list[MergeRecord] = []
    for c in accepted:
        records.append(
            MergeRecord(
                key=f"{c.delta.model_id}::{c.delta.layer}",
                origin="accepted",
                decisions=[
                    MergeDecision(
                        field="weight",
                        source=c.delta.model_id,
                        strategy=strategy,
                        value={"nnz": c.delta.nnz, "threshold": c.delta.threshold},
                    )
                ],
            )
        )
    for c in rejected:
        records.append(
            MergeRecord(
                key=f"{c.delta.model_id}::{c.delta.layer}",
                origin="rejected",
                decisions=[
                    MergeDecision(
                        field="weight",
                        source=c.delta.model_id,
                        strategy=strategy,
                        value={"nnz": c.delta.nnz, "reason": "gate_rejected"},
                    )
                ],
            )
        )
    log = ProvenanceLog(
        records=records,
        total_rows=len(accepted) + len(rejected),
        merged_rows=len(accepted),
        total_conflicts=len(rejected),
    )
    try:
        return log.to_dict()
    except Exception:  # noqa: BLE001
        return {"total_rows": log.total_rows, "merged_rows": log.merged_rows}


def build_contributions(
    source_state_dicts: dict[str, dict[str, np.ndarray]],
    threshold: float = 0.0,
    trust: dict[str, np.ndarray] | None = None,
    thresholds: dict[str, dict[str, float]] | None = None,
    time_steps: int = 8,
    spike_times: dict[str, dict[str, np.ndarray]] | None = None,
    peer_id: str = "borg",
) -> list[LayerContribution]:
    """Build layer contributions from per-model state dicts.

    E4 wiring: for each model, increment a CausalTrustClock, record a
    typed-trust score in the lattice, and attach a real 128-byte PCO to
    every layer envelope.
    """
    out: list[LayerContribution] = []
    trust = trust or {}
    thresholds = thresholds or {}
    spike_times = spike_times or {}

    peer = PeerContext.new(peer_id)

    for model_id, sd in source_state_dicts.items():
        model_trust = trust.get(model_id)
        if model_trust is None:
            model_trust = np.ones(6, dtype=np.float32)
        peer.record_self_trust(model_trust)
        clock = peer.step()

        # Merkle root over layer tags for this model's contribution bundle.
        bundle_tags: list[str] = []
        for layer_name, arr in sd.items():
            dense = np.asarray(arr)
            st = spike_times.get(model_id, {}).get(layer_name)
            neuron_t = thresholds.get(model_id, {}).get(layer_name, 1.0)
            delta = extract(
                dense=dense,
                layer=layer_name,
                model_id=model_id,
                threshold=threshold,
                trust=model_trust,
                spike_times=st,
                neuron_threshold=neuron_t,
                time_steps=time_steps,
            )
            bundle_tags.append(delta.tag())

        bundle_root = _merkle_root(bundle_tags)
        pco_blob = build_pco(
            peer_id=model_id,
            clock=clock,
            merkle_root=bundle_root,
            trust_vec=model_trust,
        )

        for layer_name, arr in sd.items():
            dense = np.asarray(arr)
            st = spike_times.get(model_id, {}).get(layer_name)
            neuron_t = thresholds.get(model_id, {}).get(layer_name, 1.0)
            delta = SparseDelta(
                **{
                    **extract(
                        dense=dense,
                        layer=layer_name,
                        model_id=model_id,
                        threshold=threshold,
                        trust=model_trust,
                        spike_times=st,
                        neuron_threshold=neuron_t,
                        time_steps=time_steps,
                    ).__dict__,
                    "pco": pco_blob,
                    "source_hash": bundle_root,
                }
            )
            out.append(LayerContribution(delta=delta))

    return out


def gate_by_probe(
    contributions: list[LayerContribution],
    gate: GateConfig,
    base: dict[str, np.ndarray] | None = None,
) -> tuple[list[LayerContribution], list[LayerContribution]]:
    """Split contributions into (accepted, rejected) by probe-loss delta.

    For each contributor, compute the probe-loss delta vs the base. If the
    delta exceeds `gate.tolerance` and the probe_fn signals a regression,
    the contributor's entire bundle is rejected.
    """
    if not gate.enabled or gate.probe_fn is None:
        return contributions, []

    by_model: dict[str, list[LayerContribution]] = {}
    for c in contributions:
        by_model.setdefault(c.delta.model_id, []).append(c)

    accepted: list[LayerContribution] = []
    rejected: list[LayerContribution] = []

    # Cold start (no prior base) skips the probe comparison: nothing to
    # compare against means nothing to reject. Once there is a base, we
    # compare the trial loss against base * (1 + tolerance).
    if not base:
        return contributions, []

    base_loss = gate.probe_fn(base)

    for bundle in by_model.values():
        trial: dict[str, np.ndarray] = {k: v.copy() for k, v in base.items()}
        for c in bundle:
            layer_tensor = apply(c.delta)
            if c.delta.layer in trial:
                trial[c.delta.layer] = (trial[c.delta.layer] + layer_tensor) / 2
            else:
                trial[c.delta.layer] = layer_tensor
        trial_loss = gate.probe_fn(trial)
        if trial_loss > base_loss * (1 + gate.tolerance):
            rejected.extend(bundle)
        else:
            accepted.extend(bundle)
    return accepted, rejected


def resolve_per_layer(
    contributions: list[LayerContribution],
    strategy: str = "ties",
    base: dict[str, np.ndarray] | None = None,
    seed: int = 42,
) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray | None], list[str]]:
    """Resolve contributions per layer. Returns (weights, timings, tags).

    Any layer present in `base` but missing from the new `contributions`
    is carried forward unchanged. This guarantees that the collective
    accumulates knowledge even when the gate rejects every new
    contribution (e.g. when a wildly different architecture is absorbed
    and every layer fails the magnitude-drift probe). Without this,
    total-rejection wipes the existing state back to empty.
    """
    from crdt_merge.model.crdt_state import CRDTMergeState

    by_layer: dict[str, list[LayerContribution]] = {}
    for c in contributions:
        by_layer.setdefault(c.delta.layer, []).append(c)

    resolved: dict[str, np.ndarray] = {}
    if base is not None:
        # Seed with the prior state so untouched layers survive even when
        # the current round has zero accepted contributions.
        for k, v in base.items():
            resolved[k] = np.asarray(v).copy()
    timings: dict[str, np.ndarray | None] = {}
    tags: list[str] = []

    requires_base = {"ties", "dare", "dare_ties", "task_arithmetic", "della"}

    for layer, cs in by_layer.items():
        layer_base = None if base is None else base.get(layer)
        # Shape-mismatch guard: when a new contribution has a different
        # tensor shape from the existing base at the same layer name
        # (e.g. absorbing a 1024-hidden model into a 768-hidden base),
        # the CRDT merge's broadcast-arithmetic strategies (ties, dare,
        # linear) crash with "operands could not be broadcast". In the
        # collective we preserve the existing base for that layer and
        # log the drop; the cross-dim weights live in a separate
        # architectural slot and can't be merged scalar-wise anyway.
        if layer_base is not None:
            base_shape = tuple(np.asarray(layer_base).shape)
            compatible = [
                c for c in cs
                if tuple(c.delta.shape) == base_shape
            ]
            if not compatible:
                # Preserve the base unchanged for this layer.
                resolved[layer] = np.asarray(layer_base, dtype=np.float32).copy()
                timings[layer] = None
                continue
            cs = compatible
        # Per-layer fallback: a strategy that needs a base but doesn't
        # have one for THIS specific layer drops to `linear` for that
        # layer only. This handles the case where a follow-up absorption
        # introduces brand-new layers that the existing Borg state has
        # never seen.
        effective_strategy = strategy
        if strategy in requires_base and layer_base is None:
            effective_strategy = "linear"
        state = CRDTMergeState(strategy_name=effective_strategy, base=layer_base, seed=seed)
        for c in cs:
            kwargs = c.to_crdt_kwargs()
            state.add(
                tensor=kwargs["tensor"],
                model_id=f"{kwargs['model_id']}:{layer}",
                weight=kwargs["weight"],
                version=kwargs["version"],
                metadata=kwargs["metadata"],
            )
            tags.append(c.delta.tag())
        try:
            resolved[layer] = np.asarray(state.resolve(), dtype=np.float32)
        except ValueError as exc:
            # Last-resort: upstream CRDTMergeState can still raise on
            # shape mismatch inside a strategy. Preserve base rather
            # than propagating up and wiping the whole round.
            if layer_base is not None:
                resolved[layer] = np.asarray(layer_base, dtype=np.float32).copy()
            else:
                # No base; pick the first contribution as a fallback.
                resolved[layer] = np.asarray(apply(cs[0].delta), dtype=np.float32)
            print(
                f"resolve_per_layer: layer {layer!r} could not merge "
                f"({type(exc).__name__}: {exc}); preserved base."
            )
        timings[layer] = merge_timings([c.delta for c in cs])

    return resolved, timings, tags


def write_manifest(manifest: Manifest, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(asdict(manifest), f, indent=2, sort_keys=True)


def _load_prior_manifest(borg_path: str) -> dict[str, Any] | None:
    """Read the manifest produced by a previous absorb, if one exists."""
    try:
        import os

        path = borg_path + ".manifest.json"
        if not os.path.exists(path):
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception:  # noqa: BLE001
        return None


def _merge_contribution_lists(
    prior: list[dict[str, Any]] | None,
    current: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Union prior + current contribution summaries, keyed by model_id.

    The collective requires that every absorbed model is visible in the
    manifest even after many successive merges. Current-call stats
    override prior entries for the same model_id (latest wins on
    per-model telemetry) while ids that only appear in the prior are
    preserved.
    """
    by_id: dict[str, dict[str, Any]] = {}
    for entry in (prior or []):
        mid = entry.get("model_id")
        if mid:
            by_id[mid] = dict(entry)
    for entry in current:
        mid = entry.get("model_id")
        if mid:
            by_id[mid] = dict(entry)
    return list(by_id.values())


def _merge_contributor_or_set(
    prior: dict[str, Any] | None,
    current: dict[str, Any] | None,
) -> dict[str, Any] | None:
    """CRDT OR-Set union of the two snapshots. CRDTs commute; order is irrelevant.

    crdt_merge 0.9.7 has a bug where `ORSet.merge(other)` does not pull
    other's elements in. We therefore union the serialised `elements`
    dict directly (tag-set union per element is the canonical OR-Set
    merge) and fall back to the plain contributor list if the shape
    doesn't match.
    """
    if prior is None:
        return current
    if current is None:
        return prior

    # Canonical ORSet `to_dict` shape is {'type': 'or_set', 'elements': {member: [tags]}}.
    prior_elems = prior.get("elements")
    current_elems = current.get("elements")
    if isinstance(prior_elems, dict) and isinstance(current_elems, dict):
        merged_elems: dict[str, list[str]] = {}
        for k, tags in prior_elems.items():
            merged_elems[k] = list(tags) if isinstance(tags, list) else [tags]
        for k, tags in current_elems.items():
            merged_elems.setdefault(k, [])
            if isinstance(tags, list):
                for t in tags:
                    if t not in merged_elems[k]:
                        merged_elems[k].append(t)
            else:
                if tags not in merged_elems[k]:
                    merged_elems[k].append(tags)
        return {"type": prior.get("type", "or_set"), "elements": merged_elems}

    # Flat contributor-list fallback.
    contributors = set(prior.get("contributors", [])) | set(current.get("contributors", []))
    return {"contributors": sorted(contributors)}


def _merge_provenance_logs(
    prior: dict[str, Any] | None,
    current: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if prior is None:
        return current
    if current is None:
        return prior
    records = list(prior.get("records", [])) + list(current.get("records", []))
    return {
        "records": records,
        "total_rows": prior.get("total_rows", 0) + current.get("total_rows", 0),
        "merged_rows": prior.get("merged_rows", 0) + current.get("merged_rows", 0),
        "total_conflicts": prior.get("total_conflicts", 0) + current.get("total_conflicts", 0),
    }


def build_manifest(
    contributions: list[LayerContribution],
    rejected: list[LayerContribution],
    strategy: str,
    fep_refine: bool,
    seed: int,
    borg_path: str,
    cumulative: bool = True,
) -> Manifest:
    """Build the per-absorb manifest, optionally merged with the prior manifest.

    When `cumulative=True` (default) the manifest accumulates every
    model_id ever absorbed into this state, so the HF Space diagnostic
    panel shows the full collective history instead of only the latest
    merge. This is the CRDT-consistent thing to do: prior `contributor_or_set`
    is unioned with the new one, and the `contributions` list is dedup'd
    by model_id.
    """
    tags = [c.delta.tag() for c in contributions]

    def _summarise(bundle: list[LayerContribution]) -> list[dict[str, Any]]:
        entries: dict[str, dict[str, Any]] = {}
        for c in bundle:
            mid = c.delta.model_id
            entry = entries.setdefault(
                mid,
                {
                    "model_id": mid,
                    "layers": 0,
                    "nnz": 0,
                    "params": 0,
                    "trust_score": (
                        float(c.delta.trust.mean()) if c.delta.trust is not None else 1.0
                    ),
                },
            )
            entry["layers"] += 1
            entry["nnz"] += c.delta.nnz
            dense = 1
            for d in c.delta.shape:
                dense *= int(d)
            entry["params"] += dense
        for e in entries.values():
            e["sparsity"] = 1.0 - (e["nnz"] / e["params"]) if e["params"] else 1.0
        return list(entries.values())

    current_contribs = _summarise(contributions)
    current_rejected = _summarise(rejected)
    current_or_set = _build_contributor_or_set(contributions)
    current_prov = _build_provenance_log(contributions, rejected, strategy)

    merged_contribs = current_contribs
    merged_rejected = current_rejected
    merged_or_set = current_or_set
    merged_prov = current_prov

    if cumulative:
        prior = _load_prior_manifest(borg_path)
        if prior is not None:
            merged_contribs = _merge_contribution_lists(
                prior.get("contributions"), current_contribs
            )
            merged_rejected = _merge_contribution_lists(
                prior.get("rejected"), current_rejected
            )
            merged_or_set = _merge_contributor_or_set(
                prior.get("contributor_or_set"), current_or_set
            )
            merged_prov = _merge_provenance_logs(
                prior.get("provenance_log"), current_prov
            )

    return Manifest(
        merkle_root=_merkle_root(tags),
        contributions=merged_contribs,
        strategy=strategy,
        fep_refine=fep_refine,
        seed=seed,
        borg_path=borg_path,
        rejected=merged_rejected,
        contributor_or_set=merged_or_set,
        provenance_log=merged_prov,
    )


# Re-exports for downstream modules that previously imported from borg.merge.
__all__ = [
    "Manifest",
    "GateConfig",
    "build_contributions",
    "gate_by_probe",
    "resolve_per_layer",
    "write_manifest",
    "build_manifest",
    "apply_timing",
]
