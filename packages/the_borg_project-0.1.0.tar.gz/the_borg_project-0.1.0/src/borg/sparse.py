# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Sparse delta envelope and helpers.

Upstream `crdt-merge` exposes OR-Set, Merkle, and E4 primitives but not a
sparse-aware contribution type. The envelope defined here is the unit of
merge traffic used throughout this repository. Each envelope carries
indices, values, shape, provenance, a six-dimension trust vector, a
128-byte PCO, and a per-cell spike-timing trace so temporal structure
survives merge. See `docs/specs/03-spike-convergence.md`.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterable
from dataclasses import dataclass, field

import numpy as np


@dataclass(frozen=True)
class SparseDelta:
    indices: np.ndarray
    values: np.ndarray
    shape: tuple[int, ...]
    layer: str
    model_id: str
    version: int = 1
    trust: np.ndarray | None = None
    pco: bytes | None = None
    source_hash: str = ""
    # Per-cell spike timing, same leading axis as `values`.
    # Fractional time-step inside [0, time_steps). NaN means "no spike
    # observed for this cell in the probe pass".
    spike_times: np.ndarray | None = None
    # Per-layer neuron firing threshold, carried with the envelope so the
    # threshold is CRDT-merged alongside the weight update rather than
    # overwritten by last-writer-wins at aggregation time.
    threshold: float = 1.0
    time_steps: int = 8

    def __post_init__(self) -> None:
        if self.indices.ndim != 2:
            raise ValueError("indices must be 2-D (k, ndim)")
        if self.values.ndim != 1:
            raise ValueError("values must be 1-D")
        if self.indices.shape[0] != self.values.shape[0]:
            raise ValueError("indices and values must have matching first axis")
        if self.indices.shape[1] != len(self.shape):
            raise ValueError("indices inner dim must match len(shape)")
        if self.trust is not None and self.trust.shape != (6,):
            raise ValueError("trust vector must have 6 dimensions")
        if self.pco is not None and len(self.pco) != 128:
            raise ValueError("pco must be exactly 128 bytes")
        if self.spike_times is not None and self.spike_times.shape != self.values.shape:
            raise ValueError("spike_times must match values shape")
        if self.time_steps <= 0:
            raise ValueError("time_steps must be positive")

    @property
    def nnz(self) -> int:
        return int(self.values.shape[0])

    @property
    def sparsity(self) -> float:
        dense = 1
        for d in self.shape:
            dense *= int(d)
        if dense == 0:
            return 1.0
        return 1.0 - (self.nnz / dense)

    def tag(self) -> str:
        hasher = hashlib.sha256()
        hasher.update(self.layer.encode("utf-8"))
        hasher.update(self.model_id.encode("utf-8"))
        hasher.update(str(self.version).encode("utf-8"))
        hasher.update(self.indices.tobytes())
        hasher.update(self.values.tobytes())
        if self.spike_times is not None:
            hasher.update(self.spike_times.tobytes())
        hasher.update(str(self.threshold).encode("utf-8"))
        return hasher.hexdigest()


def extract(
    dense: np.ndarray,
    layer: str,
    model_id: str,
    threshold: float = 0.0,
    version: int = 1,
    trust: np.ndarray | None = None,
    spike_times: np.ndarray | None = None,
    neuron_threshold: float = 1.0,
    time_steps: int = 8,
) -> SparseDelta:
    """Extract a SparseDelta from a dense tensor.

    `threshold` is the absolute-value cutoff for non-zero cells.
    `spike_times`, if supplied, must be dense with the same shape as
    `dense`; it is masked to the non-zero cells. Missing spike times are
    recorded as NaN so downstream merge can recognise them.
    """
    mask = np.abs(dense) > threshold
    idx = np.argwhere(mask).astype(np.int32)
    vals = dense[mask].astype(np.float32)
    times = None
    if spike_times is not None:
        if spike_times.shape != dense.shape:
            raise ValueError("spike_times dense shape must match dense shape")
        times = spike_times[mask].astype(np.float32)
    return SparseDelta(
        indices=idx,
        values=vals,
        shape=tuple(int(d) for d in dense.shape),
        layer=layer,
        model_id=model_id,
        version=version,
        trust=trust,
        spike_times=times,
        threshold=float(neuron_threshold),
        time_steps=int(time_steps),
    )


def apply(delta: SparseDelta, dtype: np.dtype = np.float32) -> np.ndarray:
    """Materialise a SparseDelta back into a dense tensor of zeros + values."""
    out = np.zeros(delta.shape, dtype=dtype)
    if delta.nnz == 0:
        return out
    out[tuple(delta.indices.T)] = delta.values
    return out


def apply_timing(delta: SparseDelta) -> np.ndarray | None:
    """Materialise spike timings into a dense NaN-filled array."""
    if delta.spike_times is None:
        return None
    out = np.full(delta.shape, np.nan, dtype=np.float32)
    if delta.nnz == 0:
        return out
    out[tuple(delta.indices.T)] = delta.spike_times
    return out


def merge_cellwise(
    deltas: Iterable[SparseDelta],
    strategy: str = "mean",
) -> np.ndarray:
    """Resolve a stack of SparseDelta objects targeting the same layer.

    Zero cells in every contributor remain zero in the output, which preserves
    sparsity. The strategy is applied only to the union of touched cells.
    """
    deltas = list(deltas)
    if not deltas:
        raise ValueError("no deltas supplied")
    shape = deltas[0].shape
    for d in deltas:
        if d.shape != shape:
            raise ValueError("all deltas must target the same shape")

    touched: dict[tuple[int, ...], list[float]] = {}
    for d in deltas:
        for row, v in zip(d.indices, d.values, strict=True):
            touched.setdefault(tuple(int(x) for x in row), []).append(float(v))

    out = np.zeros(shape, dtype=np.float32)
    if strategy == "mean":
        for pos, stack in touched.items():
            out[pos] = float(np.mean(stack))
    elif strategy == "sum":
        for pos, stack in touched.items():
            out[pos] = float(np.sum(stack))
    elif strategy == "max_abs":
        for pos, stack in touched.items():
            arr = np.asarray(stack, dtype=np.float32)
            out[pos] = float(arr[np.argmax(np.abs(arr))])
    else:
        raise ValueError(f"unsupported strategy: {strategy}")
    return out


def merge_timings(deltas: Iterable[SparseDelta]) -> np.ndarray | None:
    """Merge per-cell spike timings with earliest-wins semantics.

    Earliest-wins preserves temporal precedence: if two contributors
    observe a spike at the same cell, the one that spiked earlier in the
    time-step window is retained. This matches the behaviour of STDP
    plasticity where the pre-synaptic event timing is what drives the
    weight update.
    """
    deltas = list(deltas)
    if not deltas or all(d.spike_times is None for d in deltas):
        return None
    shape = deltas[0].shape
    out = np.full(shape, np.nan, dtype=np.float32)
    for d in deltas:
        if d.spike_times is None:
            continue
        for row, t in zip(d.indices, d.spike_times, strict=True):
            pos = tuple(int(x) for x in row)
            current = out[pos]
            if np.isnan(current) or t < current:
                out[pos] = float(t)
    return out


@dataclass
class LayerContribution:
    """Envelope passed from `borg.merge` into `CRDTMergeState.add`."""

    delta: SparseDelta
    weight: float = 1.0
    metadata: dict = field(default_factory=dict)

    def to_crdt_kwargs(self) -> dict:
        md = {
            **self.metadata,
            "layer": self.delta.layer,
            "sparsity": self.delta.sparsity,
            "tag": self.delta.tag(),
            "source_hash": self.delta.source_hash,
            "threshold": self.delta.threshold,
            "time_steps": self.delta.time_steps,
        }
        if self.delta.trust is not None:
            md["trust_vector"] = self.delta.trust.tolist()
        if self.delta.pco is not None:
            md["pco_hex"] = self.delta.pco.hex()
        if self.delta.spike_times is not None:
            md["has_timing"] = True
        return {
            "tensor": apply(self.delta),
            "model_id": self.delta.model_id,
            "weight": self.weight,
            "version": self.delta.version,
            "metadata": md,
        }
