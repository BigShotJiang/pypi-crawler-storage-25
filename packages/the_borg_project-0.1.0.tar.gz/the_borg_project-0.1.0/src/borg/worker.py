# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Distributed worker: FastAPI endpoint + Ed25519-signed envelopes.

Exposes two endpoints:

* `POST /contribute` accepts a signed envelope carrying a single
  `SparseDelta`. Verifies the signature, decodes indices/values, wraps
  as a `LayerContribution`, and forwards to an in-process merge queue.
* `POST /gossip` exchanges envelope digests with peer workers. A peer
  advertises the digests it has observed, the local worker responds
  with the intersection plus any digests it holds that the peer
  doesn't.

The queue is drained by a background resolver that calls
`borg.merge.resolve_per_layer` whenever a flush threshold is reached.

Ed25519 signing uses the `cryptography` library when available, falls
back to a deterministic-but-insecure HMAC for development.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field

import numpy as np

from borg.sparse import LayerContribution, SparseDelta


@dataclass
class SignedEnvelope:
    """Wire format for a worker-to-coordinator contribution."""

    model_id: str
    layer: str
    indices_b64: str
    values_b64: str
    shape: tuple[int, ...]
    version: int
    trust: list[float]
    source_hash: str
    time_steps: int
    threshold: float
    spike_times_b64: str | None
    signature_b64: str
    public_key_b64: str
    timestamp: float

    def canonical_bytes(self) -> bytes:
        """Deterministic serialisation for signing / verification."""
        payload = {
            "model_id": self.model_id,
            "layer": self.layer,
            "indices_b64": self.indices_b64,
            "values_b64": self.values_b64,
            "shape": list(self.shape),
            "version": self.version,
            "trust": self.trust,
            "source_hash": self.source_hash,
            "time_steps": self.time_steps,
            "threshold": self.threshold,
            "spike_times_b64": self.spike_times_b64,
            "timestamp": self.timestamp,
        }
        return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")

    def digest(self) -> str:
        return hashlib.sha256(self.canonical_bytes()).hexdigest()


def to_envelope(delta: SparseDelta, signer: Signer) -> SignedEnvelope:
    indices_b64 = base64.b64encode(delta.indices.astype(np.int32).tobytes()).decode("ascii")
    values_b64 = base64.b64encode(delta.values.astype(np.float32).tobytes()).decode("ascii")
    spike_b64: str | None = None
    if delta.spike_times is not None:
        spike_b64 = base64.b64encode(delta.spike_times.astype(np.float32).tobytes()).decode("ascii")
    trust = (delta.trust.astype(np.float32).tolist() if delta.trust is not None else [1.0] * 6)
    env = SignedEnvelope(
        model_id=delta.model_id,
        layer=delta.layer,
        indices_b64=indices_b64,
        values_b64=values_b64,
        shape=tuple(int(x) for x in delta.shape),
        version=delta.version,
        trust=trust,
        source_hash=delta.source_hash,
        time_steps=delta.time_steps,
        threshold=delta.threshold,
        spike_times_b64=spike_b64,
        signature_b64="",
        public_key_b64=signer.public_key_b64(),
        timestamp=time.time(),
    )
    sig = signer.sign(env.canonical_bytes())
    env.signature_b64 = base64.b64encode(sig).decode("ascii")
    return env


def from_envelope(env: SignedEnvelope) -> SparseDelta:
    indices = np.frombuffer(base64.b64decode(env.indices_b64), dtype=np.int32)
    values = np.frombuffer(base64.b64decode(env.values_b64), dtype=np.float32)
    ndim = len(env.shape)
    if ndim == 0 or indices.size % ndim != 0:
        raise ValueError("indices length must be multiple of shape dim")
    indices = indices.reshape(-1, ndim)
    spike_times = None
    if env.spike_times_b64:
        spike_times = np.frombuffer(
            base64.b64decode(env.spike_times_b64), dtype=np.float32
        ).copy()
    return SparseDelta(
        indices=indices.copy(),
        values=values.copy(),
        shape=tuple(env.shape),
        layer=env.layer,
        model_id=env.model_id,
        version=env.version,
        trust=np.asarray(env.trust, dtype=np.float32),
        pco=None,
        source_hash=env.source_hash,
        spike_times=spike_times,
        threshold=env.threshold,
        time_steps=env.time_steps,
    )


class Signer:
    """Ed25519 signer with graceful fallback for dev/test."""

    def __init__(self, secret: bytes | None = None):
        self._secret = secret or b"\x00" * 32
        self._ed25519 = None
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PrivateKey,
            )

            self._ed25519 = Ed25519PrivateKey.from_private_bytes(self._secret[:32])
        except Exception:  # noqa: BLE001
            self._ed25519 = None

    def public_key_b64(self) -> str:
        if self._ed25519 is not None:
            from cryptography.hazmat.primitives.serialization import (
                Encoding,
                PublicFormat,
            )

            pub = self._ed25519.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
            return base64.b64encode(pub).decode("ascii")
        return base64.b64encode(hashlib.sha256(self._secret).digest()).decode("ascii")

    def sign(self, message: bytes) -> bytes:
        if self._ed25519 is not None:
            return bytes(self._ed25519.sign(message))
        return hmac.new(self._secret, message, hashlib.sha256).digest() + b"\x00" * 32

    @staticmethod
    def verify(envelope: SignedEnvelope) -> bool:
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import (
                Ed25519PublicKey,
            )

            pub_bytes = base64.b64decode(envelope.public_key_b64)
            if len(pub_bytes) != 32:
                return False
            pub = Ed25519PublicKey.from_public_bytes(pub_bytes)
            sig = base64.b64decode(envelope.signature_b64)
            pub.verify(sig, envelope.canonical_bytes())
            return True
        except Exception:  # noqa: BLE001
            return _verify_hmac(envelope)


def _verify_hmac(envelope: SignedEnvelope) -> bool:
    expected = hashlib.sha256(base64.b64decode(envelope.public_key_b64)).digest()
    full = hmac.new(expected, envelope.canonical_bytes(), hashlib.sha256).digest() + b"\x00" * 32
    return hmac.compare_digest(full, base64.b64decode(envelope.signature_b64))


@dataclass
class MergeQueue:
    """Thread-safe in-memory queue of pending contributions."""

    _items: list[LayerContribution] = field(default_factory=list)
    _digests: set[str] = field(default_factory=set)
    _lock: threading.Lock = field(default_factory=threading.Lock)
    flush_threshold: int = 16
    flush_fn: Callable[[list[LayerContribution]], None] | None = None

    def submit(self, envelope: SignedEnvelope) -> bool:
        if not Signer.verify(envelope):
            return False
        digest = envelope.digest()
        with self._lock:
            if digest in self._digests:
                return True
            self._digests.add(digest)
            delta = from_envelope(envelope)
            self._items.append(LayerContribution(delta=delta))
            should_flush = len(self._items) >= self.flush_threshold
            batch: list[LayerContribution] = []
            if should_flush:
                batch, self._items = self._items, []
        if should_flush and self.flush_fn is not None:
            self.flush_fn(batch)
        return True

    def pending(self) -> int:
        with self._lock:
            return len(self._items)

    def observed_digests(self) -> list[str]:
        with self._lock:
            return sorted(self._digests)


try:  # module-level so pydantic can resolve forward refs cleanly
    from pydantic import BaseModel, Field

    class EnvelopeBody(BaseModel):
        model_id: str
        layer: str
        indices_b64: str
        values_b64: str
        shape: list[int] = Field(..., min_length=1)
        version: int
        trust: list[float] = Field(..., min_length=6, max_length=6)
        source_hash: str
        time_steps: int
        threshold: float
        spike_times_b64: str | None = None
        signature_b64: str
        public_key_b64: str
        timestamp: float

    class GossipBody(BaseModel):
        digests: list[str]

except ImportError:  # pragma: no cover - pydantic optional at lib-import time
    EnvelopeBody = None  # type: ignore[assignment]
    GossipBody = None  # type: ignore[assignment]


def create_app(queue: MergeQueue | None = None):
    """Build a FastAPI app bound to `queue`."""
    try:
        from fastapi import Body, FastAPI, HTTPException
    except ImportError as exc:
        raise RuntimeError(
            "fastapi is required for the worker. "
            "Install with: pip install fastapi pydantic"
        ) from exc

    if EnvelopeBody is None:  # pragma: no cover
        raise RuntimeError("pydantic is required for the worker app")

    queue = queue or MergeQueue()
    app = FastAPI(title="Borg worker", version="0.1.0")

    @app.post("/contribute")
    def contribute(body: EnvelopeBody = Body(...)):
        payload = body.model_dump()
        payload["shape"] = tuple(payload["shape"])
        env = SignedEnvelope(**payload)
        if not queue.submit(env):
            raise HTTPException(status_code=400, detail="signature verification failed")
        return {"accepted": True, "digest": env.digest(), "pending": queue.pending()}

    @app.post("/gossip")
    def gossip(body: GossipBody = Body(...)):
        local = set(queue.observed_digests())
        peer = set(body.digests)
        return {
            "common": sorted(local & peer),
            "need_from_peer": sorted(peer - local),
            "offer_to_peer": sorted(local - peer),
        }

    @app.get("/health")
    def health():
        return {"status": "ok", "pending": queue.pending()}

    return app


__all__ = [
    "MergeQueue",
    "Signer",
    "SignedEnvelope",
    "create_app",
    "from_envelope",
    "to_envelope",
]
