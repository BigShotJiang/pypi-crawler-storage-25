# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Content-addressable storage for SparseDelta envelopes.

The CID (Content Identifier) is `sha256(canonical_bytes)` of the signed
envelope. Two peers that independently produce the same envelope will
always derive the same CID, which gives automatic deduplication on the
gossip path -- if peer B already has CID X, peer A doesn't resend it.

CIDs are also the node ids on the collective's Merkle-DAG. A peer's
full state is the set of CIDs it holds; `resolve_per_layer` over the
union of CIDs is the converged Borg state.
"""

from __future__ import annotations

import hashlib

from borg.worker import SignedEnvelope

_CID_BYTES = 32  # full sha256
CID_HEX_LEN = _CID_BYTES * 2


def cid_of(envelope: SignedEnvelope) -> str:
    """Derive the content id of a signed envelope.

    Uses the envelope's canonical_bytes (already excludes the signature
    field via SignedEnvelope.canonical_bytes) so two envelopes produced
    by different peers for the same logical contribution at the same
    timestamp collapse to the same CID.
    """
    return hashlib.sha256(envelope.canonical_bytes()).hexdigest()


def validate_cid(cid: str) -> bool:
    """Check a string looks like a valid hex CID."""
    if len(cid) != CID_HEX_LEN:
        return False
    try:
        int(cid, 16)
    except ValueError:
        return False
    return True


__all__ = ["CID_HEX_LEN", "cid_of", "validate_cid"]
