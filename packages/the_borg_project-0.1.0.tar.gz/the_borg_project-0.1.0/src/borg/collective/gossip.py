# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Pairwise gossip synchronisation.

The sync round between peer A and peer B:

1. A and B exchange BloomDigests (one HTTP round trip each, or a single
   in-process call for tests).
2. A computes `missing_from(bloom_B)` -- every CID A holds that B's
   Bloom does not show. A streams those envelopes to B.
3. B does the symmetric operation for A.
4. Both peers verify signatures + store received envelopes. New CIDs
   are added to each local Peer's store; duplicates are dropped.
5. Merge convergence is emergent: both peers now hold the union. Over
   `O(log N)` pairwise rounds across the network, every peer converges
   to the same CRDT-resolved state (gossip-spreading theorem).

The implementation here is transport-agnostic. `local_sync` runs both
peers in-process (fast; used by tests). `http_sync` uses the existing
FastAPI endpoints (`/gossip` + `/contribute`) over the network.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from borg.collective.bloom import BloomDigest
from borg.collective.peer import Peer


@dataclass
class SyncResult:
    sent: int
    received: int
    peer_id: str
    elapsed_s: float


def local_sync(a: Peer, b: Peer) -> tuple[SyncResult, SyncResult]:
    """Synchronise two in-process peers. Returns (a's result, b's result)."""
    t0 = time.monotonic()
    bloom_a = a.bloom()
    bloom_b = b.bloom()
    a_to_b = a.missing_from(bloom_b)
    b_to_a = b.missing_from(bloom_a)
    sent_a = 0
    for cid in a_to_b:
        env = a.envelope_for(cid)
        if env is not None and b.accept(env) is not None:
            sent_a += 1
    sent_b = 0
    for cid in b_to_a:
        env = b.envelope_for(cid)
        if env is not None and a.accept(env) is not None:
            sent_b += 1
    a.note_peer(b.peer_id, f"inproc:{b.peer_id}")
    b.note_peer(a.peer_id, f"inproc:{a.peer_id}")
    elapsed = time.monotonic() - t0
    return (
        SyncResult(sent=sent_a, received=sent_b, peer_id=b.peer_id, elapsed_s=elapsed),
        SyncResult(sent=sent_b, received=sent_a, peer_id=a.peer_id, elapsed_s=elapsed),
    )


def http_sync(local: Peer, remote_url: str, remote_id: str, httpx_client=None) -> SyncResult:
    """Synchronise `local` against a remote worker exposed over HTTP.

    Requires `httpx`. Uses the existing /gossip endpoint to exchange the
    CID list (digest form) and /contribute to push missing envelopes.
    """
    if httpx_client is None:
        import httpx

        httpx_client = httpx.Client(timeout=10.0)
    t0 = time.monotonic()
    # Step 1: swap digests via /gossip. We advertise our full CID list as
    # the `digests` payload; the server answers with offer_to_peer (CIDs
    # it has that we don't).
    local_cids = local.cids()
    r = httpx_client.post(
        f"{remote_url}/gossip", json={"digests": local_cids}, timeout=10.0
    )
    r.raise_for_status()
    body = r.json()
    offer_from_remote = body.get("offer_to_peer", [])
    need_from_us = body.get("need_from_peer", [])

    # Step 2: push envelopes the remote is missing.
    sent = 0
    for cid in need_from_us:
        env = local.envelope_for(cid)
        if env is None:
            continue
        payload = _env_to_payload(env)
        try:
            r2 = httpx_client.post(f"{remote_url}/contribute", json=payload, timeout=10.0)
            if r2.status_code == 200:
                sent += 1
        except Exception:  # noqa: BLE001
            continue

    # Step 3: pull envelopes offered by remote. The worker's /contribute
    # shape is symmetric -- we'd need a corresponding GET-by-digest in a
    # follow-up sprint. For now this sync is push-dominant; the symmetric
    # pull happens when the remote syncs back with us.
    received = 0
    local.note_peer(remote_id, remote_url)
    elapsed = time.monotonic() - t0
    return SyncResult(sent=sent, received=received, peer_id=remote_id, elapsed_s=elapsed)


def _env_to_payload(env) -> dict:
    return {
        "model_id": env.model_id,
        "layer": env.layer,
        "indices_b64": env.indices_b64,
        "values_b64": env.values_b64,
        "shape": list(env.shape),
        "version": env.version,
        "trust": env.trust,
        "source_hash": env.source_hash,
        "time_steps": env.time_steps,
        "threshold": env.threshold,
        "spike_times_b64": env.spike_times_b64,
        "signature_b64": env.signature_b64,
        "public_key_b64": env.public_key_b64,
        "timestamp": env.timestamp,
    }


__all__ = ["SyncResult", "local_sync", "http_sync"]
