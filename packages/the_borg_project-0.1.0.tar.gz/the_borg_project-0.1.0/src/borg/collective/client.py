# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Top-level collective_assimilate entry point.

Wraps `assimilate_state_dict` with the gossip lifecycle:

1. Pre-absorb: query known peers for whether `model_id` is already
   present in the collective. If any peer's OR-Set has it, skip the
   absorb entirely. This is the dedup guarantee: 1M clones all running
   `collective_assimilate("gpt2")` produce exactly one logical
   absorption network-wide.

2. Absorb locally via `assimilate_state_dict`. The result lands in a
   fresh BorgState + manifest.

3. Post-absorb: package each 2-D SparseDelta in the resolved state as
   a SignedEnvelope, add it to the local Peer's store (which derives
   its CID and indexes into the Bloom digest), and broadcast to all
   known peers via `local_sync` (tests) or `http_sync` (production).

The CRDT guarantees a single converged state across all participating
peers regardless of arrival order. No coordinator. No rate limits.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import numpy as np
import torch

from borg.assimilation import assimilate_state_dict
from borg.collective.bloom import BloomDigest
from borg.collective.bootstrap import resolve_seeds
from borg.collective.cid import cid_of
from borg.collective.gossip import local_sync
from borg.collective.peer import Peer
from borg.sparse import SparseDelta, extract
from borg.worker import Signer, to_envelope


@dataclass
class CollectiveResult:
    model_id: str
    already_known: bool
    cids_broadcast: list[str]
    peers_reached: list[str]
    manifest: dict[str, Any] | None


def _envelope_for_layer(
    layer_name: str,
    dense: np.ndarray,
    model_id: str,
    trust: np.ndarray,
    threshold: float,
    time_steps: int,
    signer: Signer,
):
    delta = extract(
        dense=dense,
        layer=layer_name,
        model_id=model_id,
        threshold=0.0,
        trust=trust,
        neuron_threshold=threshold,
        time_steps=time_steps,
    )
    # to_envelope returns a signed envelope
    return to_envelope(delta, signer)


def collective_assimilate(
    state_dict: dict[str, torch.Tensor],
    model_id: str,
    local_peer: Peer,
    borg_path: str = "borg_snn.pt",
    remote_peers: Iterable[Peer] = (),
    broadcast: bool = True,
    **assimilate_kwargs,
) -> CollectiveResult:
    """Join-aware absorb: dedup + local absorb + broadcast.

    `remote_peers` is a list of live in-process peers to sync against;
    for HTTP-backed production this would be replaced by `http_sync`
    calls in a follow-up. The behaviour contract is transport-agnostic:
    every absorb produces signed envelopes; the peer gossip layer
    disseminates them; the CRDT merge converges.
    """
    # Step 1: dedup against the local peer's absorbed set.
    if model_id in local_peer.absorbed_model_ids():
        return CollectiveResult(
            model_id=model_id,
            already_known=True,
            cids_broadcast=[],
            peers_reached=[],
            manifest=None,
        )
    # Any remote peer already has it? (pre-gossip fast-path)
    for remote in remote_peers:
        if model_id in remote.absorbed_model_ids():
            return CollectiveResult(
                model_id=model_id,
                already_known=True,
                cids_broadcast=[],
                peers_reached=[remote.peer_id],
                manifest=None,
            )

    # Step 2: local absorb via the existing three-pillar pipeline.
    manifest = assimilate_state_dict(
        state_dict=state_dict,
        model_id=model_id,
        borg_path=borg_path,
        **assimilate_kwargs,
    )

    # Step 3: package every 2-D body tensor as a signed envelope and
    # add to the local peer so it enters the content-addressable store.
    time_steps = int(assimilate_kwargs.get("time_steps", 16))
    trust_vec = np.ones(6, dtype=np.float32)
    cids_broadcast: list[str] = []
    for k, t in state_dict.items():
        if not torch.is_floating_point(t) or t.ndim != 2:
            continue
        dense = t.detach().cpu().contiguous().numpy().astype(np.float32)
        env = _envelope_for_layer(
            layer_name=k,
            dense=dense,
            model_id=model_id,
            trust=trust_vec,
            threshold=1.0,
            time_steps=time_steps,
            signer=local_peer.signer,
        )
        cid = local_peer.accept(env)
        if cid is not None:
            cids_broadcast.append(cid)

    # Step 4: pairwise gossip with every supplied remote peer.
    peers_reached: list[str] = []
    if broadcast:
        for remote in remote_peers:
            local_sync(local_peer, remote)
            peers_reached.append(remote.peer_id)

    return CollectiveResult(
        model_id=model_id,
        already_known=False,
        cids_broadcast=cids_broadcast,
        peers_reached=peers_reached,
        manifest=manifest,
    )


def default_seed_peer_ids() -> list[str]:
    """Convenience: expose the resolved seed peer ids to callers."""
    return [s.peer_id for s in resolve_seeds()]


__all__ = ["CollectiveResult", "collective_assimilate", "default_seed_peer_ids"]
