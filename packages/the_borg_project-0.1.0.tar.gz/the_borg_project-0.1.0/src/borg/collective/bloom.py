# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Bloom filter digest for O(1) "what do you have?" pairwise sync.

Two peers exchange their BloomDigest, and each peer then sends the
other any CIDs not visible in the remote Bloom. False positives cost
bandwidth (one missed envelope per bit collision) but never miss an
actual gossip edge. False-negative rate is zero by construction.

Sizing: m = 65536 bits, k = 5 hash fns gives false-positive rate
~1% at n = 8k CIDs, ~10% at 25k CIDs. Envelopes can always be
resynced in a later round; CRDT idempotence makes missed edges
self-healing.
"""

from __future__ import annotations

import base64
import hashlib
import struct
from dataclasses import dataclass, field

_BLOOM_M = 65_536  # bit array size
_BLOOM_K = 5  # number of hash functions


@dataclass
class BloomDigest:
    bits: bytearray = field(default_factory=lambda: bytearray(_BLOOM_M // 8))

    def add(self, item: str) -> None:
        for i in _positions(item):
            self.bits[i // 8] |= 1 << (i % 8)

    def contains(self, item: str) -> bool:
        for i in _positions(item):
            if not (self.bits[i // 8] & (1 << (i % 8))):
                return False
        return True

    def union(self, other: "BloomDigest") -> "BloomDigest":
        out = BloomDigest(bits=bytearray(len(self.bits)))
        for i in range(len(self.bits)):
            out.bits[i] = self.bits[i] | other.bits[i]
        return out

    def to_b64(self) -> str:
        return base64.b64encode(bytes(self.bits)).decode("ascii")

    @classmethod
    def from_b64(cls, payload: str) -> "BloomDigest":
        raw = base64.b64decode(payload)
        if len(raw) * 8 != _BLOOM_M:
            raise ValueError(f"bloom digest must be {_BLOOM_M} bits")
        return cls(bits=bytearray(raw))

    @classmethod
    def from_cids(cls, cids: list[str]) -> "BloomDigest":
        b = cls()
        for c in cids:
            b.add(c)
        return b


def _positions(item: str) -> list[int]:
    """K independent hash positions in [0, _BLOOM_M) via double-hashing."""
    h = hashlib.sha256(item.encode("utf-8")).digest()
    h1 = struct.unpack(">Q", h[:8])[0]
    h2 = struct.unpack(">Q", h[8:16])[0]
    return [(h1 + i * h2) % _BLOOM_M for i in range(_BLOOM_K)]


__all__ = ["BloomDigest"]
