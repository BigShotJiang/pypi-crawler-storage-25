# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Seed peer list for joining the collective on first run.

A new clone learns about the network by asking a handful of hardcoded
seed peers for their roster. This is the ONLY centralised piece, and
it is deliberately minimal -- seeds do not hold authoritative state,
they just offer their known-peer list so a new clone can expand its
view. From that point onward the clone gossips with its peers
independently and the seeds are irrelevant.

The HuggingFace Space is in the seed list because it already runs the
FastAPI worker. Additional community seeds can be appended via the
`BORG_COLLECTIVE_SEEDS` env var (comma-separated urls).
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class SeedPeer:
    peer_id: str
    url: str


DEFAULT_SEEDS: tuple[SeedPeer, ...] = (
    SeedPeer(
        peer_id="hf-space",
        url="https://optitransfer-the-borg-project.hf.space",
    ),
)


def resolve_seeds() -> list[SeedPeer]:
    """Return the effective seed list, merging env overrides onto defaults."""
    seeds = list(DEFAULT_SEEDS)
    extra = os.environ.get("BORG_COLLECTIVE_SEEDS", "").strip()
    if not extra:
        return seeds
    for i, url in enumerate(u.strip() for u in extra.split(",") if u.strip()):
        seeds.append(SeedPeer(peer_id=f"env-seed-{i}", url=url))
    return seeds


__all__ = ["DEFAULT_SEEDS", "SeedPeer", "resolve_seeds"]
