# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Borg Collective -- peer-to-peer gossip layer.

See `docs/collective.md` for the architecture. Top-level symbols are
exposed via PEP 562 lazy attribute access so that importing a light
submodule (e.g. `borg.collective.gcs` on the HF Space) does not pull
in the heavy gossip stack and its `crdt_merge` dependency.
"""

from typing import Any

__all__ = [
    "BloomDigest",
    "CollectiveResult",
    "DEFAULT_SEEDS",
    "Peer",
    "PeerRecord",
    "SeedPeer",
    "SyncResult",
    "cid_of",
    "collective_assimilate",
    "default_seed_peer_ids",
    "http_sync",
    "local_sync",
    "resolve_seeds",
    "validate_cid",
]

_LAZY = {
    "BloomDigest": ("borg.collective.bloom", "BloomDigest"),
    "DEFAULT_SEEDS": ("borg.collective.bootstrap", "DEFAULT_SEEDS"),
    "SeedPeer": ("borg.collective.bootstrap", "SeedPeer"),
    "resolve_seeds": ("borg.collective.bootstrap", "resolve_seeds"),
    "cid_of": ("borg.collective.cid", "cid_of"),
    "validate_cid": ("borg.collective.cid", "validate_cid"),
    "CollectiveResult": ("borg.collective.client", "CollectiveResult"),
    "collective_assimilate": ("borg.collective.client", "collective_assimilate"),
    "default_seed_peer_ids": ("borg.collective.client", "default_seed_peer_ids"),
    "SyncResult": ("borg.collective.gossip", "SyncResult"),
    "http_sync": ("borg.collective.gossip", "http_sync"),
    "local_sync": ("borg.collective.gossip", "local_sync"),
    "Peer": ("borg.collective.peer", "Peer"),
    "PeerRecord": ("borg.collective.peer", "PeerRecord"),
}


def __getattr__(name: str) -> Any:
    if name not in _LAZY:
        raise AttributeError(f"module 'borg.collective' has no attribute {name!r}")
    module_name, attr = _LAZY[name]
    import importlib

    mod = importlib.import_module(module_name)
    value = getattr(mod, attr)
    globals()[name] = value  # cache so subsequent access bypasses __getattr__
    return value


def __dir__() -> list[str]:
    return sorted(__all__)
