# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Peer: a single node in the collective gossip network.

A Peer wraps the existing `borg.worker.MergeQueue` with:

* a content-addressable store of SparseDelta envelopes keyed by CID
* a BloomDigest of held CIDs for fast pairwise sync
* a contributor OR-Set (backed by crdt_merge) of absorbed model_ids
* a peer roster it has successfully synced with

Every `borg.collective.Peer` is a full member of the collective. There
is no distinction between clients and servers. The hardcoded seed list
is a discovery convenience, not a coordination authority.
"""

from __future__ import annotations

import threading
from collections.abc import Iterable
from dataclasses import dataclass, field

from borg.collective.bloom import BloomDigest
from borg.collective.cid import cid_of, validate_cid
from borg.sparse import LayerContribution
from borg.worker import MergeQueue, SignedEnvelope, Signer, from_envelope


@dataclass
class PeerRecord:
    peer_id: str
    url: str
    last_sync: float = 0.0
    cids_learned: int = 0


class Peer:
    def __init__(self, peer_id: str, signer: Signer | None = None):
        self.peer_id = peer_id
        self.signer = signer or Signer()
        self._envelopes: dict[str, SignedEnvelope] = {}
        self._model_ids: set[str] = set()
        self._peers: dict[str, PeerRecord] = {}
        self._lock = threading.Lock()
        self._queue = MergeQueue()

    # ---- contribution ingest -------------------------------------------------

    def accept(self, envelope: SignedEnvelope) -> str | None:
        """Store + queue an envelope; return its CID or None on reject."""
        if not Signer.verify(envelope):
            return None
        cid = cid_of(envelope)
        if not validate_cid(cid):
            return None
        with self._lock:
            if cid in self._envelopes:
                return cid  # dedup by CID
            self._envelopes[cid] = envelope
            self._model_ids.add(envelope.model_id)
        delta = from_envelope(envelope)
        self._queue.submit(envelope)  # runs Signer.verify again; cheap
        return cid

    def has(self, cid: str) -> bool:
        with self._lock:
            return cid in self._envelopes

    # ---- gossip digest -------------------------------------------------------

    def bloom(self) -> BloomDigest:
        with self._lock:
            return BloomDigest.from_cids(list(self._envelopes.keys()))

    def cids(self) -> list[str]:
        with self._lock:
            return list(self._envelopes.keys())

    def envelope_for(self, cid: str) -> SignedEnvelope | None:
        with self._lock:
            return self._envelopes.get(cid)

    def missing_from(self, remote_bloom: BloomDigest) -> list[str]:
        """CIDs we hold that the remote Bloom says it does not have."""
        with self._lock:
            return [c for c in self._envelopes if not remote_bloom.contains(c)]

    # ---- peer roster ---------------------------------------------------------

    def note_peer(self, peer_id: str, url: str) -> None:
        with self._lock:
            rec = self._peers.get(peer_id)
            if rec is None:
                self._peers[peer_id] = PeerRecord(peer_id=peer_id, url=url)
            else:
                rec.url = url

    def known_peers(self) -> list[PeerRecord]:
        with self._lock:
            return list(self._peers.values())

    # ---- merged state --------------------------------------------------------

    def contributions(self) -> list[LayerContribution]:
        with self._lock:
            return [LayerContribution(delta=from_envelope(e)) for e in self._envelopes.values()]

    def absorbed_model_ids(self) -> set[str]:
        with self._lock:
            return set(self._model_ids)

    def ingest_many(self, envelopes: Iterable[SignedEnvelope]) -> list[str]:
        out: list[str] = []
        for e in envelopes:
            cid = self.accept(e)
            if cid is not None:
                out.append(cid)
        return out


__all__ = ["Peer", "PeerRecord"]
