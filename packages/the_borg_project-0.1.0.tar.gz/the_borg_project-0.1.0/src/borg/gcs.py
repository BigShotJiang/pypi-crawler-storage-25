# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

"""GCS source-of-truth for borg_snn.pt + manifest + registry.

The HF Space 1 GB LFS cap is incompatible with a growing collective.
This module moves the model file off HF and onto a GCS bucket: the
Vertex notebook uploads (via ADC), the Space reads anonymously over
HTTPS (bucket has public read). A small `borg_version.json` is the
poll target so the Space can cheaply detect new model versions
without re-downloading the full file every request.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path

DEFAULT_BUCKET = "the-borg-bucket"
MODEL_KEY = "borg_snn.pt"
MANIFEST_KEY = "borg_snn.pt.manifest.json"
REGISTRY_KEY = "borg_registry.json"
VERSION_KEY = "borg_version.json"


def public_url(bucket: str, key: str) -> str:
    return f"https://storage.googleapis.com/{bucket}/{key}"


@dataclass
class BorgVersion:
    """Version descriptor written alongside the model on GCS.

    The Space fetches this tiny JSON on startup (and optionally on
    every request) to decide whether the cached local copy is stale.
    """

    sha256: str
    size_bytes: int
    uploaded_at: float
    n_absorbed: int
    bucket: str

    def to_json(self) -> str:
        return json.dumps(asdict(self), indent=2, sort_keys=True)

    @classmethod
    def from_json(cls, blob: str) -> "BorgVersion":
        d = json.loads(blob)
        return cls(**{k: d[k] for k in cls.__dataclass_fields__ if k in d})


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def upload_collective(
    borg_path: str | Path,
    bucket: str = DEFAULT_BUCKET,
    n_absorbed: int = 0,
    include_manifest: bool = True,
    include_registry: str | Path | None = None,
) -> BorgVersion:
    """Push the model + manifest + registry + version file to GCS.

    Uses `google.cloud.storage.Client()` which picks up Vertex AI's
    ADC automatically. Raises if `borg_path` does not exist.
    """
    from google.cloud import storage

    borg_path = Path(borg_path)
    if not borg_path.exists():
        raise FileNotFoundError(borg_path)

    client = storage.Client()
    b = client.bucket(bucket)

    version = BorgVersion(
        sha256=_sha256(borg_path),
        size_bytes=borg_path.stat().st_size,
        uploaded_at=time.time(),
        n_absorbed=n_absorbed,
        bucket=bucket,
    )

    # Mark every uploaded object as non-cacheable. GCS public objects
    # are fronted by a CDN that by default caches with a ~1 hour TTL,
    # which causes the Space (in a different edge region from the
    # notebook) to keep serving a stale manifest for up to an hour
    # after the notebook uploads a fresh one. `no-cache` forces the
    # edge to revalidate on every request.
    def _upload(key: str, filename: str | None = None, data: str | None = None, ctype: str | None = None):
        blob = b.blob(key)
        blob.cache_control = "no-cache, max-age=0"
        if data is not None:
            blob.upload_from_string(data, content_type=ctype or "application/octet-stream")
        else:
            blob.upload_from_filename(filename)

    _upload(MODEL_KEY, filename=str(borg_path))

    manifest_path = borg_path.with_suffix(borg_path.suffix + ".manifest.json")
    if include_manifest and manifest_path.exists():
        _upload(MANIFEST_KEY, filename=str(manifest_path))

    if include_registry:
        reg = Path(include_registry)
        if reg.exists():
            _upload(REGISTRY_KEY, filename=str(reg))

    _upload(VERSION_KEY, data=version.to_json(), ctype="application/json")
    return version


def _bust(url: str) -> str:
    """Append a monotonically-increasing query string to bypass CDN edge
    caches. GCS public-read objects are cached ~1 hour by default; we
    want the freshest copy every time the Space or notebook reads."""
    return f"{url}?t={int(time.time() * 1000)}"


def fetch_version(bucket: str = DEFAULT_BUCKET, timeout: float = 5.0) -> BorgVersion | None:
    """Fetch `borg_version.json` anonymously over HTTPS. Returns None
    if the file is missing, inaccessible, or the bucket has not been
    made public-read."""
    try:
        with urllib.request.urlopen(_bust(public_url(bucket, VERSION_KEY)), timeout=timeout) as r:
            return BorgVersion.from_json(r.read().decode("utf-8"))
    except Exception:
        return None


def _download(url: str, dest: Path, timeout: float = 300.0) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url, timeout=timeout) as r, dest.open("wb") as f:
        while chunk := r.read(1 << 20):
            f.write(chunk)


def sync_from_gcs(
    local_dir: str | Path = "/tmp/borg",
    bucket: str = DEFAULT_BUCKET,
) -> tuple[Path | None, BorgVersion | None]:
    """Download model + manifest + version file from GCS if the remote
    version differs from what is cached locally. Returns
    (local_model_path, version_descriptor) so the caller can set
    BORG_STATE and report diagnostics. Returns (None, None) if the
    bucket has no version file or the download fails."""
    local_dir = Path(local_dir)
    local_dir.mkdir(parents=True, exist_ok=True)

    remote = fetch_version(bucket=bucket)
    if remote is None:
        return None, None

    local_version_path = local_dir / VERSION_KEY
    local_model_path = local_dir / MODEL_KEY
    local_manifest_path = local_dir / MANIFEST_KEY

    try:
        local = BorgVersion.from_json(local_version_path.read_text())
    except Exception:
        local = None

    need_model = (
        local is None
        or local.sha256 != remote.sha256
        or not local_model_path.exists()
    )
    if need_model:
        _download(_bust(public_url(bucket, MODEL_KEY)), local_model_path)
        local_version_path.write_text(remote.to_json())

    # The manifest can change independently of the model weights (a
    # registry-rebuild cell that catches up lost history without
    # re-merging weights, for instance). Always re-fetch the manifest;
    # it is typically <1 MB versus tens of MB for the model, so the
    # bandwidth cost is negligible and the diagnostic panel stays
    # consistent with whatever the notebook last wrote to GCS.
    try:
        _download(_bust(public_url(bucket, MANIFEST_KEY)), local_manifest_path)
        # Loud diagnostic: print the contribution count so a stale manifest
        # on the Space is visible in the startup log instead of silently
        # masked by a broken panel.
        try:
            import json as _json
            m = _json.loads(local_manifest_path.read_text())
            n = len(m.get("contributions", []))
            print(f"[gcs] manifest downloaded: {local_manifest_path} has {n} contributions")
        except Exception as exc:  # noqa: BLE001
            print(f"[gcs] manifest parse failed: {type(exc).__name__}: {exc}")
    except Exception as exc:  # noqa: BLE001
        print(f"[gcs] manifest download skipped: {type(exc).__name__}: {exc}")

    return local_model_path, remote


def apply_gcs_state_env(
    local_dir: str | Path = "/tmp/borg",
    bucket: str | None = None,
) -> BorgVersion | None:
    """Convenience for the HF Space entrypoint: sync from GCS and set
    the BORG_STATE env var so `borg.app` picks up the downloaded
    model. Bucket name is read from BORG_GCS_BUCKET if unset.
    Returns the version descriptor on success, None otherwise."""
    bucket = bucket or os.environ.get("BORG_GCS_BUCKET", DEFAULT_BUCKET)
    model_path, version = sync_from_gcs(local_dir=local_dir, bucket=bucket)
    if model_path is not None:
        os.environ["BORG_STATE"] = str(model_path)
    return version
