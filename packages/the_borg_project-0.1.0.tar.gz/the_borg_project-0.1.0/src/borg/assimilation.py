# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Top-level assimilate entry.

Ties convert -> sparse -> e4-stamped contribution -> optional probe gate ->
CRDT resolve -> optional variational FEP refinement -> INT8 quantisation ->
persist. See `docs/specs/01-universal-absorption.md`.
"""

from __future__ import annotations

import argparse
import json
import os
from collections.abc import Callable
from dataclasses import asdict
from pathlib import Path
from typing import Any

import numpy as np
import torch

from borg.fep import FEPConfig, refine
from borg.inference import BorgState, dequantize_tensor, quantize_int8
from borg.inference import load as load_state
from borg.inference import save as save_state
from borg.merge import (
    GateConfig,
    build_contributions,
    build_manifest,
    gate_by_probe,
    resolve_per_layer,
    write_manifest,
)


def _safe_np(t: torch.Tensor) -> np.ndarray:
    """Torch -> numpy FP32, tolerant of BF16 / FP16 / float8 / non-contiguous.

    numpy has no kernel for BF16 or FP16 on CPU, so `.numpy()` raises
    `TypeError: Got unsupported ScalarType BFloat16` on any Qwen / Llama /
    Mistral checkpoint. This helper casts to FP32 first, then materialises
    a contiguous numpy view. Used everywhere an arbitrary-dtype tensor
    crosses the torch/numpy boundary inside the absorb pipeline.
    """
    t = t.detach()
    if t.dtype not in (torch.float32, torch.float64):
        t = t.to(torch.float32)
    return t.cpu().contiguous().numpy().astype(np.float32, copy=False)


def default_magnitude_probe(state: dict[str, np.ndarray] | None) -> float:
    """Reference-free probe loss for the E4 gate.

    Measures the mean log of the per-layer weight-norm distribution. A
    contribution that inflates this value (e.g. a dense unsparsified
    shard) produces a higher loss than the sparse base, so the gate
    rejects it. Works without any probe inputs / targets, so every
    absorb path can turn the gate on by default.
    """
    if not state:
        return 0.0
    norms: list[float] = []
    for v in state.values():
        if v is None:
            continue
        arr = np.asarray(v)
        if arr.size == 0:
            continue
        norms.append(float(np.linalg.norm(arr) / np.sqrt(arr.size) + 1e-12))
    if not norms:
        return 0.0
    return float(np.mean(np.log(norms)))


def assimilate(
    model_ids: list[str],
    borg_path: str = "borg_snn.pt",
    strategy: str = "ties",
    fep_refine: bool = False,
    trust_scores: dict[str, float] | None = None,
    seed: int = 42,
    time_steps: int = 8,
    peer_id: str = "borg",
    gate_enabled: bool = False,
    gate_tolerance: float = 0.10,
    probe_fn: Callable[[dict[str, np.ndarray]], float] | None = None,
    probe_inputs: np.ndarray | None = None,
    probe_targets: np.ndarray | None = None,
    keep_lm_head: bool = True,
) -> dict[str, Any]:
    from transformers import AutoModelForCausalLM

    from borg.convert import to_snn

    state_dicts: dict[str, dict[str, np.ndarray]] = {}
    per_model_thresholds: dict[str, dict[str, float]] = {}
    lm_head_tensor: torch.Tensor | None = None
    lm_head_bias: torch.Tensor | None = None
    tokenizer_id: str | None = None

    for mid in model_ids:
        model = AutoModelForCausalLM.from_pretrained(mid, torch_dtype=torch.float32)
        if keep_lm_head and lm_head_tensor is None:
            head_weight, head_bias = _extract_lm_head(model)
            if head_weight is not None:
                lm_head_tensor = head_weight
                lm_head_bias = head_bias
                tokenizer_id = mid
        shard = to_snn(model, time_steps=time_steps)
        state_dicts[mid] = {
            k: _safe_np(v)
            for k, v in shard.state_dict.items()
            if torch.is_floating_point(v)
        }
        per_model_thresholds[mid] = shard.thresholds

    base: dict[str, np.ndarray] | None = None
    if Path(borg_path).exists():
        prev = load_state(borg_path)
        base = {
            k: _safe_np(dequantize_tensor(prev, k))
            for k in prev.state_dict
            if not k.endswith(".scale") and prev.state_dict[k].ndim == 2
        }

    trust_vectors: dict[str, np.ndarray] = {}
    if trust_scores:
        for mid, s in trust_scores.items():
            trust_vectors[mid] = np.full(6, float(s), dtype=np.float32)

    contributions = build_contributions(
        source_state_dicts=state_dicts,
        threshold=0.0,
        trust=trust_vectors or None,
        thresholds=per_model_thresholds,
        time_steps=time_steps,
        peer_id=peer_id,
    )

    gate = GateConfig(enabled=gate_enabled, tolerance=gate_tolerance, probe_fn=probe_fn)
    accepted, rejected = gate_by_probe(contributions, gate, base=base)

    resolved, _timings, _tags = resolve_per_layer(
        contributions=accepted,
        strategy=strategy,
        base=base,
        seed=seed,
    )

    if fep_refine and probe_inputs is not None and probe_targets is not None:
        resolved = refine(
            resolved,
            probe_inputs=probe_inputs,
            probe_targets=probe_targets,
            config=FEPConfig(seed=seed),
        )

    merged_sd = {k: torch.from_numpy(v) for k, v in resolved.items()}
    merged_thresholds: dict[str, float] = {}
    for t_map in per_model_thresholds.values():
        for layer, thr in t_map.items():
            merged_thresholds[layer] = max(merged_thresholds.get(layer, 0.0), thr)

    if lm_head_tensor is not None:
        from borg.decode import LM_BIAS_KEY, LM_HEAD_KEY

        merged_sd[LM_HEAD_KEY] = lm_head_tensor.detach().float().contiguous()
        if lm_head_bias is not None:
            merged_sd[LM_BIAS_KEY] = lm_head_bias.detach().float().contiguous()

    state = BorgState(
        state_dict=merged_sd,
        thresholds=merged_thresholds,
        time_steps=time_steps,
        quantized=False,
        tokenizer_id=tokenizer_id,
    )
    state = quantize_int8(state)

    # Optional: post-absorption logit calibration. Cheap (~10 probes,
    # ~30s) and dramatically improves decoded coherence by aligning the
    # SNN's per-vocab logit distribution to the source model's.
    if keep_lm_head and lm_head_tensor is not None:
        _apply_calibration_if_possible(state, tokenizer_id, seed)

    _register_head_for_model(
        state=state,
        model_id=model_ids[0] if model_ids else "unknown",
        tokenizer_id=tokenizer_id,
        source_state_dict={
            mid: dict(sd) for mid, sd in state_dicts.items()
        }.get(model_ids[0] if model_ids else "", {}),
        prior_borg_path=borg_path,
    )

    save_state(state, borg_path)

    manifest = build_manifest(
        contributions=accepted,
        rejected=rejected,
        strategy=strategy,
        fep_refine=fep_refine,
        seed=seed,
        borg_path=borg_path,
    )
    write_manifest(manifest, borg_path + ".manifest.json")
    return asdict(manifest)


def _register_head_for_model(
    state: "BorgState",
    model_id: str,
    tokenizer_id: str | None,
    source_state_dict: dict[str, Any] | None = None,
    module: "torch.nn.Module | None" = None,
    prior_borg_path: str | None = None,
) -> None:
    """Detect and register the source model's head type on the state.

    Accepts either a raw state dict or an instantiated module. When a
    module is provided, `module.state_dict()` is inspected. The
    registry is persisted on `state.state_dict` via `borg.heads`.

    If `prior_borg_path` is supplied and points at an existing state,
    prior head registrations are pulled forward before the new head is
    added. This is how the registry accumulates across absorbs.
    """
    from borg.heads import detect_head_type, get_registered_heads, register_head

    # Pull prior heads forward.
    if prior_borg_path and Path(prior_borg_path).exists():
        try:
            prior_state = load_state(prior_borg_path)
            for prior_rec in get_registered_heads(prior_state):
                if prior_rec.model_id == model_id:
                    continue
                register_head(state, prior_rec)
        except Exception:  # noqa: BLE001
            pass

    if source_state_dict is None and module is not None:
        source_state_dict = {k: v for k, v in module.state_dict().items()}
    if not source_state_dict:
        return
    # Coerce any numpy arrays back to tensors for ndim inspection.
    sample: dict[str, torch.Tensor] = {}
    for k, v in source_state_dict.items():
        if isinstance(v, torch.Tensor):
            sample[k] = v
        elif hasattr(v, "ndim") and hasattr(v, "shape"):
            try:
                sample[k] = torch.as_tensor(v)
            except Exception:  # noqa: BLE001
                continue
    record = detect_head_type(sample)
    record.model_id = model_id
    record.tokenizer_id = tokenizer_id
    register_head(state, record)


def _extract_lm_head(model: torch.nn.Module) -> tuple[torch.Tensor | None, torch.Tensor | None]:
    """Pull the language-model head from a HuggingFace causal LM model.

    Looks for `lm_head` or `get_output_embeddings()` on the model. If tied
    embeddings are used, the input embedding weight is returned (the
    standard HF convention). Bias is returned when present.
    """
    head: torch.nn.Module | None = None
    if hasattr(model, "lm_head") and isinstance(model.lm_head, torch.nn.Module):
        head = model.lm_head
    else:
        getter = getattr(model, "get_output_embeddings", None)
        if getter is not None:
            head = getter()

    if head is None:
        getter = getattr(model, "get_input_embeddings", None)
        if getter is not None:
            head = getter()

    if head is None or not hasattr(head, "weight"):
        return None, None

    weight = head.weight
    bias = getattr(head, "bias", None)
    return weight, bias


def assimilate_module(
    model: torch.nn.Module,
    model_id: str,
    borg_path: str = "borg_snn.pt",
    strategy: str = "ties",
    seed: int = 42,
    time_steps: int = 8,
    peer_id: str = "borg",
    method: str = "auto",
    keep_lm_head: bool = True,
    tokenizer_id: str | None = None,
    fep_refine: bool = False,
    probe_inputs: np.ndarray | None = None,
    probe_targets: np.ndarray | None = None,
    trust_scores: dict[str, float] | None = None,
    gate_enabled: bool = True,
    gate_tolerance: float = 1.00,
    probe_fn: Callable[[dict[str, np.ndarray] | None], float] | None = None,
    apply_calibration: bool = True,
    accuracy_floor: float = 0.0,
    accuracy_probe_fn: Callable[[Any], float] | None = None,
) -> dict[str, Any]:
    """Absorb an already-instantiated PyTorch module through all three pillars.

    `method` is forwarded to `borg.convert.to_snn`. Pass `"snn"` to
    skip the ANN-to-SNN conversion step entirely (the model's
    state_dict is taken as-is and per-layer thresholds are extracted
    from `v_threshold` / `spike_threshold` / `threshold` attributes).

    Gate is on by default with the reference-free magnitude probe.
    FEP refinement runs when `fep_refine=True` and probe data is
    supplied. Logit calibration runs post-merge when `tokenizer_id`
    resolves to a loadable HF model (CausalLM or MaskedLM).

    Raises `borg.convert.UnsupportedOpError` if the module contains an
    op the converter cannot decompose, and `ConversionAccuracyError` if
    `accuracy_probe_fn(shard) < accuracy_floor`.
    """
    from borg.convert import to_snn

    shard = to_snn(
        model,
        method=method,
        time_steps=time_steps,
        accuracy_floor=accuracy_floor,
        accuracy_probe_fn=accuracy_probe_fn,
    )
    # Only 2-D+ float tensors flow through the sparse-delta merge. 0-D /
    # 1-D / non-float tensors (scalar scales, biases, integer buffers)
    # are preserved verbatim on the merged state after the merge so the
    # SNN forward can still consume them.
    preserved_extras: dict[str, torch.Tensor] = {}
    mergeable: dict[str, torch.Tensor] = {}
    for k, v in shard.state_dict.items():
        if not torch.is_floating_point(v):
            preserved_extras[k] = v.detach().clone()
            continue
        if v.ndim < 2:
            preserved_extras[k] = v.detach().clone()
            continue
        mergeable[k] = v
    state_dicts: dict[str, dict[str, np.ndarray]] = {
        model_id: {
            k: _safe_np(v)
            for k, v in mergeable.items()
        }
    }
    per_model_thresholds = {model_id: shard.thresholds}

    trust_vectors: dict[str, np.ndarray] = {}
    if trust_scores:
        for mid, s in trust_scores.items():
            trust_vectors[mid] = np.full(6, float(s), dtype=np.float32)

    base: dict[str, np.ndarray] | None = None
    if Path(borg_path).exists():
        prev = load_state(borg_path)
        base = {
            k: _safe_np(dequantize_tensor(prev, k))
            for k in prev.state_dict
            if not k.endswith(".scale") and prev.state_dict[k].ndim == 2
        }

    shard_spike_times = {
        model_id: {
            k: _safe_np(v)
            for k, v in (shard.spike_times or {}).items()
        }
    }

    contributions = build_contributions(
        source_state_dicts=state_dicts,
        threshold=0.0,
        trust=trust_vectors or None,
        thresholds=per_model_thresholds,
        time_steps=shard.time_steps,
        spike_times=shard_spike_times,
        peer_id=peer_id,
    )

    effective_probe = probe_fn or default_magnitude_probe
    gate = GateConfig(enabled=gate_enabled, tolerance=gate_tolerance, probe_fn=effective_probe)
    accepted, rejected = gate_by_probe(contributions, gate, base=base)

    resolved, _timings, _tags = resolve_per_layer(
        contributions=accepted, strategy=strategy, base=base, seed=seed
    )

    fep_applied = False
    if fep_refine and probe_inputs is not None and probe_targets is not None:
        resolved = refine(
            resolved,
            probe_inputs=probe_inputs,
            probe_targets=probe_targets,
            config=FEPConfig(seed=seed),
        )
        fep_applied = True

    lm_head_tensor: torch.Tensor | None = None
    lm_head_bias: torch.Tensor | None = None
    if keep_lm_head:
        head_weight, head_bias = _extract_lm_head(model)
        if head_weight is not None:
            lm_head_tensor = head_weight
            lm_head_bias = head_bias

    merged_sd = {k: torch.from_numpy(v) for k, v in resolved.items()}
    # Fold preserved scalars / biases / non-float buffers back in.
    for k, v in preserved_extras.items():
        merged_sd[k] = v
    merged_thresholds: dict[str, float] = dict(shard.thresholds)
    if lm_head_tensor is not None:
        from borg.decode import LM_BIAS_KEY, LM_HEAD_KEY

        merged_sd[LM_HEAD_KEY] = lm_head_tensor.detach().float().contiguous()
        if lm_head_bias is not None:
            merged_sd[LM_BIAS_KEY] = lm_head_bias.detach().float().contiguous()

    state = BorgState(
        state_dict=merged_sd,
        thresholds=merged_thresholds,
        time_steps=shard.time_steps,
        quantized=False,
        tokenizer_id=tokenizer_id,
    )
    state = quantize_int8(state)

    if apply_calibration:
        _apply_calibration_if_possible(state, tokenizer_id, seed)

    _register_head_for_model(
        state=state,
        model_id=model_id,
        tokenizer_id=tokenizer_id,
        module=model,
        prior_borg_path=borg_path,
    )

    save_state(state, borg_path)

    manifest = build_manifest(
        contributions=accepted,
        rejected=rejected,
        strategy=strategy,
        fep_refine=fep_applied,
        seed=seed,
        borg_path=borg_path,
    )
    write_manifest(manifest, borg_path + ".manifest.json")
    return asdict(manifest)


def assimilate_state_dict(
    state_dict: dict[str, torch.Tensor],
    model_id: str,
    borg_path: str = "borg_snn.pt",
    strategy: str = "ties",
    seed: int = 42,
    time_steps: int = 16,
    peer_id: str = "borg",
    thresholds: dict[str, float] | None = None,
    tokenizer_id: str | None = None,
    lm_head_key: str | None = None,
    lm_bias_key: str | None = None,
    max_layer_params: int = 5_000_000,
    skip_layer_patterns: tuple[str, ...] = (
        "lm_head.",
        ".wte.",
        ".wpe.",
        "embed_tokens",
        "embeddings.",
        "shared.weight",
    ),
    target_sparsity: float = 0.90,
    fep_refine: bool = False,
    probe_inputs: np.ndarray | None = None,
    probe_targets: np.ndarray | None = None,
    trust_scores: dict[str, float] | None = None,
    gate_enabled: bool = True,
    gate_tolerance: float = 1.00,
    probe_fn: Callable[[dict[str, np.ndarray] | None], float] | None = None,
    apply_calibration: bool = True,
    keep_lm_head: bool = True,
) -> dict[str, Any]:
    """Absorb a raw state dict with the full three-pillar chain.

    Source model code is not required. Every pillar from the design runs:

    * Pillar 1: `to_snn_from_state_dict` fits per-layer thresholds
      (weight-stat + name hints), rescales so thresholds normalise to
      1.0, and sparsifies to `target_sparsity` unless the source is
      already a native SNN (sparsity >= 60%).
    * Pillar 2: `build_contributions` stamps E4 trust + PCO envelopes,
      `gate_by_probe` runs with a reference-free magnitude-drift probe
      by default so divergent shards are rejected before CRDT resolve.
    * Pillar 3: optional `borg.fep.refine` over the resolved state if
      probe_inputs / probe_targets are supplied.

    The LM head + tokenizer id from the first source are preserved
    verbatim so the Space decoder can emit text. Logit calibration
    runs post-merge when `tokenizer_id` resolves to a loadable HF model.
    """
    from borg.convert import to_snn_from_state_dict

    # Filter the state dict before conversion to keep memory bounded.
    # Cast every non-FP32/FP64 float tensor to FP32 up-front. numpy has
    # no kernel for BF16, FP16, or the float8 variants, so any downstream
    # `.numpy()` call on such a tensor raises e.g.
    # `TypeError: Got unsupported ScalarType BFloat16`. Every Qwen /
    # Llama / Mistral checkpoint ships in BF16; GPT-OSS-level quant
    # checkpoints ship in float8. Promoting here makes them all absorb
    # cleanly without touching the caller. `.contiguous()` guards
    # against non-contiguous storage surviving to `.numpy()`.
    floats: dict[str, torch.Tensor] = {}
    for k, v in state_dict.items():
        if not torch.is_floating_point(v):
            continue
        if v.dtype in (torch.float32, torch.float64):
            floats[k] = v
        else:
            floats[k] = v.detach().to(torch.float32).contiguous()
    skipped: list[str] = []
    keep_for_merge: dict[str, torch.Tensor] = {}
    for k, v in floats.items():
        if any(pat in k for pat in skip_layer_patterns):
            skipped.append(k)
            continue
        if v.numel() > max_layer_params:
            skipped.append(k)
            continue
        keep_for_merge[k] = v
    if skipped:
        print(
            f"assimilate_state_dict: skipping {len(skipped)} large/incompatible tensors "
            f"(out of {len(floats)} total floats)"
        )

    # Pillar 1: ANN-to-SNN conversion on the raw tensors.
    shard = to_snn_from_state_dict(
        keep_for_merge,
        time_steps=time_steps,
        target_sparsity=target_sparsity,
    )
    print(
        f"assimilate_state_dict: pillar-1 shard sparsity={shard.sparsity:.2%}, "
        f"thresholds={len(shard.thresholds)}, method={shard.method}"
    )

    # Caller-supplied thresholds override the auto-detected ones.
    if thresholds:
        shard.thresholds.update(thresholds)

    state_dicts: dict[str, dict[str, np.ndarray]] = {
        model_id: {
            k: _safe_np(v)
            for k, v in shard.state_dict.items()
        }
    }
    per_model_thresholds = {model_id: shard.thresholds}

    trust_vectors: dict[str, np.ndarray] = {}
    if trust_scores:
        for mid, s in trust_scores.items():
            trust_vectors[mid] = np.full(6, float(s), dtype=np.float32)

    base: dict[str, np.ndarray] | None = None
    if Path(borg_path).exists():
        prev = load_state(borg_path)
        base = {
            k: _safe_np(dequantize_tensor(prev, k))
            for k in prev.state_dict
            if not k.endswith(".scale") and prev.state_dict[k].ndim == 2
        }

    shard_spike_times = {
        model_id: {
            k: _safe_np(v)
            for k, v in (shard.spike_times or {}).items()
        }
    }

    contributions = build_contributions(
        source_state_dicts=state_dicts,
        threshold=0.0,
        trust=trust_vectors or None,
        thresholds=per_model_thresholds,
        time_steps=shard.time_steps,
        spike_times=shard_spike_times,
        peer_id=peer_id,
    )

    # Pillar 2: E4 gate on by default, reference-free probe.
    effective_probe = probe_fn or default_magnitude_probe
    gate = GateConfig(enabled=gate_enabled, tolerance=gate_tolerance, probe_fn=effective_probe)
    accepted, rejected = gate_by_probe(contributions, gate, base=base)
    if rejected:
        print(f"assimilate_state_dict: pillar-2 gate rejected {len(rejected)} of {len(contributions)} contributions")

    resolved, _timings, _tags = resolve_per_layer(
        contributions=accepted, strategy=strategy, base=base, seed=seed
    )

    # Pillar 3: optional variational FEP refinement.
    fep_applied = False
    if fep_refine and probe_inputs is not None and probe_targets is not None:
        resolved = refine(
            resolved,
            probe_inputs=probe_inputs,
            probe_targets=probe_targets,
            config=FEPConfig(seed=seed),
        )
        fep_applied = True

    manifest = build_manifest(
        contributions=accepted,
        rejected=rejected,
        strategy=strategy,
        fep_refine=fep_applied,
        seed=seed,
        borg_path=borg_path,
    )

    del state_dicts, contributions, accepted, rejected, base
    import gc as _gc

    _gc.collect()

    # LM head preservation from the ORIGINAL state dict (pre-sparsify).
    if lm_head_key is None and keep_lm_head:
        lm_head_key = _autodetect_lm_head_key(state_dict)
    if lm_bias_key is None and lm_head_key is not None:
        candidate = lm_head_key.replace(".weight", ".bias")
        lm_bias_key = candidate if candidate in state_dict else None

    merged_sd = {k: torch.from_numpy(v) for k, v in resolved.items()}
    merged_thresholds: dict[str, float] = dict(shard.thresholds)
    if keep_lm_head and lm_head_key and lm_head_key in state_dict:
        from borg.decode import LM_BIAS_KEY, LM_HEAD_KEY

        merged_sd[LM_HEAD_KEY] = state_dict[lm_head_key].detach().float().contiguous()
        if lm_bias_key and lm_bias_key in state_dict:
            merged_sd[LM_BIAS_KEY] = state_dict[lm_bias_key].detach().float().contiguous()

    state = BorgState(
        state_dict=merged_sd,
        thresholds=merged_thresholds,
        time_steps=shard.time_steps,
        quantized=False,
        tokenizer_id=tokenizer_id,
    )
    state = quantize_int8(state)

    if apply_calibration:
        calibrated = _apply_calibration_if_possible(state, tokenizer_id, seed)
        if calibrated:
            print("assimilate_state_dict: logit calibration attached")

    _register_head_for_model(
        state=state,
        model_id=model_id,
        tokenizer_id=tokenizer_id,
        source_state_dict=state_dict,
        prior_borg_path=borg_path,
    )

    save_state(state, borg_path)
    write_manifest(manifest, borg_path + ".manifest.json")
    return asdict(manifest)


def _autodetect_lm_head_key(state_dict: dict[str, torch.Tensor]) -> str | None:
    """Find the most likely LM-head weight in a raw state_dict.

    Covers the usual causal-LM layouts and the MLM layouts (BERT,
    RoBERTa, XLM-R, ModernBERT, etc.) which stash the head under
    `lm_head.decoder.weight` or `cls.predictions.decoder.weight`.
    Falls back to tied input embeddings so encoder-only checkpoints
    that don't materialise a separate head still decode.
    """
    candidates = [
        "lm_head.weight",
        "lm_head.decoder.weight",
        "lm_head.dense.weight",
        "cls.predictions.decoder.weight",
        "cls.predictions.transform.dense.weight",
        "head.weight",
        "output_projection.weight",
        "output.weight",
        "decoder.weight",
        "embed_out.weight",
    ]
    for c in candidates:
        if c in state_dict and state_dict[c].ndim == 2:
            return c
    # Any 2-D tensor whose suffix matches a known head shape.
    head_suffixes = (
        ".lm_head.weight",
        ".lm_head.decoder.weight",
        ".head.weight",
        ".decoder.weight",
    )
    for k, v in state_dict.items():
        if v.ndim != 2:
            continue
        low = k.lower()
        if low.endswith(head_suffixes):
            return k
    # Tied-embedding fallback (roberta-base, bert-base-uncased, etc.).
    tied_candidates = (
        "roberta.embeddings.word_embeddings.weight",
        "bert.embeddings.word_embeddings.weight",
        "embeddings.word_embeddings.weight",
        "model.embed_tokens.weight",
        "transformer.wte.weight",
    )
    for c in tied_candidates:
        if c in state_dict and state_dict[c].ndim == 2:
            return c
    return None


def _apply_calibration_if_possible(
    state: BorgState,
    tokenizer_id: str | None,
    seed: int,
) -> bool:
    """Run logit calibration if tokenizer_id resolves to a loadable HF model.

    Tries CausalLM first, then MaskedLM (RoBERTa / BERT). Any failure is
    logged to stdout and swallowed so calibration stays best-effort. Returns
    True iff the calibration was attached to `state.state_dict`.
    """
    if tokenizer_id is None:
        return False
    if os.environ.get("BORG_SKIP_CALIBRATION", "").lower() in ("1", "true", "yes"):
        return False
    try:
        from transformers import AutoTokenizer

        from borg.calibration import (
            CalibrationConfig,
            attach_calibration,
            fit_logit_rescale,
        )
    except Exception as exc:  # noqa: BLE001
        print(f"calibration skipped (import): {exc}")
        return False

    tokenizer = None
    source_model = None
    for loader_name in ("AutoModelForCausalLM", "AutoModelForMaskedLM", "AutoModel"):
        try:
            from transformers import AutoModelForCausalLM, AutoModelForMaskedLM, AutoModel

            loader = {
                "AutoModelForCausalLM": AutoModelForCausalLM,
                "AutoModelForMaskedLM": AutoModelForMaskedLM,
                "AutoModel": AutoModel,
            }[loader_name]
            source_model = loader.from_pretrained(tokenizer_id, torch_dtype=torch.float32)
            source_model.eval()
            tokenizer = AutoTokenizer.from_pretrained(tokenizer_id)
            break
        except Exception as exc:  # noqa: BLE001
            print(f"calibration: {loader_name} failed ({exc}); trying next loader")
            continue
    if source_model is None or tokenizer is None:
        print(f"calibration skipped: no loader matched {tokenizer_id}")
        return False
    try:
        scale_vec, bias_vec = fit_logit_rescale(
            source_model, tokenizer, state, CalibrationConfig(seed=seed)
        )
        attach_calibration(state, scale_vec, bias_vec)
        return True
    except Exception as exc:  # noqa: BLE001
        print(f"calibration skipped (fit): {exc}")
        return False


def cli() -> None:
    parser = argparse.ArgumentParser(description="Assimilate one or more models into a Borg state.")
    parser.add_argument("model_ids", nargs="+", help="Hugging Face model IDs or local paths.")
    parser.add_argument("--borg-path", default="borg_snn.pt")
    parser.add_argument("--strategy", default="ties")
    parser.add_argument("--fep", action="store_true")
    parser.add_argument("--gate", action="store_true")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--time-steps", type=int, default=8)
    args = parser.parse_args()

    manifest = assimilate(
        model_ids=args.model_ids,
        borg_path=args.borg_path,
        strategy=args.strategy,
        fep_refine=args.fep,
        gate_enabled=args.gate,
        seed=args.seed,
        time_steps=args.time_steps,
    )
    print(json.dumps(manifest, indent=2, sort_keys=True))


if __name__ == "__main__":
    cli()
