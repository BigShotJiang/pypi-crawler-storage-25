# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Token-level language decoder.

Wraps `borg.inference.spike_forward` with an LM-head projection so the
Borg emits real token IDs instead of a diagnostic rate string. The LM
head is stored alongside the merged weights (`state_dict["lm_head.weight"]`
and optional `state_dict["lm_head.bias"]`); if absent, `decode_text`
raises rather than silently falling back to the diagnostic decoder.

`tokenizer_id` is stored at `BorgState.tokenizer_id` so the tokenizer can
be loaded lazily without hard-wiring a specific model.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from borg.inference import BorgState, layer_array, spike_forward

LM_HEAD_KEY = "lm_head.weight"
LM_BIAS_KEY = "lm_head.bias"


@dataclass
class DecodeConfig:
    max_new_tokens: int = 8
    temperature: float = 0.0
    top_k: int = 0
    seed: int = 0
    stop_token: int | None = None
    time_steps: int = 1   # spike loop iterations per token; 1 = lightning-fast inference


def has_lm_head(state: BorgState) -> bool:
    return LM_HEAD_KEY in state.state_dict


def logits_from_rates(
    rates: np.ndarray,
    state: BorgState,
    _bypass_calibration: bool = False,
) -> np.ndarray:
    """Project a spike-rate vector through the LM head to token logits.

    If a calibration was attached during absorption (`borg.calibration.fit_logit_rescale`),
    apply the per-vocab affine `(scale, bias)` so the SNN's logit
    distribution matches the source model. Set `_bypass_calibration=True`
    when calibrating to avoid feedback.
    """
    if not has_lm_head(state):
        raise RuntimeError("state has no LM head; cannot produce logits")
    head = layer_array(state, LM_HEAD_KEY)
    bias = layer_array(state, LM_BIAS_KEY) if LM_BIAS_KEY in state.state_dict else None

    hidden = head.shape[1]
    if rates.shape[-1] != hidden:
        rates = _project(rates, hidden)
    logits = rates @ head.T
    if bias is not None:
        logits = logits + bias

    if not _bypass_calibration:
        from borg.calibration import CALIB_BIAS_KEY, CALIB_SCALE_KEY

        if CALIB_SCALE_KEY in state.state_dict:
            scale = layer_array(state, CALIB_SCALE_KEY)
            calib_bias = layer_array(state, CALIB_BIAS_KEY)
            logits = logits * scale + calib_bias
    return logits


def _project(rates: np.ndarray, target_dim: int) -> np.ndarray:
    if rates.ndim == 1:
        rates = rates[None, :]
    current = rates.shape[-1]
    if current == target_dim:
        return rates
    if current > target_dim:
        return rates[..., :target_dim]
    pad = np.zeros((*rates.shape[:-1], target_dim - current), dtype=rates.dtype)
    return np.concatenate([rates, pad], axis=-1)


def _sample_next_token(
    logits: np.ndarray,
    config: DecodeConfig,
    rng: np.random.Generator,
) -> int:
    row = logits if logits.ndim == 1 else logits[-1]
    if config.temperature <= 0.0:
        return int(np.argmax(row))
    scaled = row / config.temperature
    scaled = scaled - scaled.max()
    probs = np.exp(scaled)
    if config.top_k > 0 and config.top_k < probs.shape[0]:
        cutoff = np.sort(probs)[-config.top_k]
        probs = np.where(probs >= cutoff, probs, 0.0)
    probs = probs / probs.sum()
    return int(rng.choice(probs.shape[0], p=probs))


def decode_token_ids(
    state: BorgState,
    input_ids: list[int],
    config: DecodeConfig | None = None,
) -> list[int]:
    """Greedy / sampling decode using the Borg forward pass + LM head."""
    cfg = config or DecodeConfig()
    rng = np.random.default_rng(cfg.seed)
    ids = list(input_ids)
    hidden_width = _first_layer_width(state)

    for _ in range(cfg.max_new_tokens):
        x = _encode_ids(ids, hidden_width)
        rates = spike_forward(state, x, time_steps_override=cfg.time_steps)
        logits = logits_from_rates(rates, state)
        next_id = _sample_next_token(logits, cfg, rng)
        ids.append(next_id)
        if cfg.stop_token is not None and next_id == cfg.stop_token:
            break
    return ids


def decode_text(
    state: BorgState,
    prompt: str,
    tokenizer: Any,
    config: DecodeConfig | None = None,
) -> str:
    """Greedy decode a text completion.

    `tokenizer` should quack like a HF `PreTrainedTokenizer`: it needs
    `encode(str) -> list[int]` and `decode(list[int]) -> str`.
    """
    cfg = config or DecodeConfig()
    input_ids = list(tokenizer.encode(prompt))
    output_ids = decode_token_ids(state, input_ids, cfg)
    new_ids = output_ids[len(input_ids):]
    return str(tokenizer.decode(new_ids))


def _first_layer_width(state: BorgState) -> int:
    for k, t in state.state_dict.items():
        if k.endswith(".scale"):
            continue
        if t.ndim == 2 and k != LM_HEAD_KEY:
            return int(t.shape[0])
    return 32


def _encode_ids(ids: list[int], width: int) -> np.ndarray:
    """Deterministic rate-code from a token-id prefix.

    Uses the token id stream modulo `width` so the input rate vector is
    a repeatable function of the sequence. The last 16 tokens dominate
    because we weight more-recent tokens higher.
    """
    x = np.zeros(width, dtype=np.float32)
    if not ids:
        return x
    tail = ids[-16:]
    for pos, token_id in enumerate(tail):
        weight = (pos + 1) / len(tail)
        x[int(token_id) % width] += weight
    if x.max() > 0:
        x /= x.max()
    return x


def universal_decode(
    state: BorgState,
    user_prompt: str,
    rag_hits: list[tuple[str, str]] | None = None,
    config: DecodeConfig | None = None,
    chain_of_thought: bool = True,
    composed_prompt: str | None = None,
) -> str:
    """Produce a response regardless of what heads the collective carries.

    `user_prompt` is what the user actually typed -- used verbatim for
    the "step 1 (restate)" header so the CoT trace reads naturally.
    `composed_prompt` (when supplied) is the full system-prompt-plus-
    context string used for the spike-forward pass; callers should pass
    this separately so the restate step never leaks the system prompt.

    Dispatch chain, first match wins:

    1. Causal-LM head + tokenizer resolvable -> decode_text
    2. Masked-LM head + tokenizer resolvable -> mask-fill over the prompt
    3. Classifier head -> class-activation synthesis
    4. Embedder head -> RAG-grounded natural-language synthesis
    5. Retroactive detection or unknown -> actionable guidance + RAG-grounded
       answer if documents are available

    The response is always a human-readable string. Embedder + RAG hits
    produces a conversational synthesis of the retrieved chunks; the
    old "latent signature / top activations" dump is now a last-resort
    fallback only when the state truly has no capability and no
    retrieved context.
    """
    from borg.heads import (
        CAUSAL_LM,
        CLASSIFIER,
        EMBEDDER,
        MASKED_LM,
        UNKNOWN,
        get_registered_heads,
        primary_head,
        retroactively_register,
    )

    # Retroactive registry recovery: legacy states absorbed before the
    # capability layer shipped carry no HEADS_KEY. Detect from the
    # state's own layer keys and register so the panel + dispatch are
    # populated without requiring a re-absorb.
    if not get_registered_heads(state):
        retroactively_register(state)

    cfg = config or DecodeConfig()
    forward_prompt = composed_prompt if composed_prompt is not None else user_prompt
    head = primary_head(state)
    hidden_width = _first_layer_width(state)
    x = _encode_ids(_text_to_token_stream(forward_prompt), hidden_width)
    rates = spike_forward(state, x, time_steps_override=cfg.time_steps)
    rates_are_zero = _is_all_zero(rates)

    if head is not None and head.head_type == CAUSAL_LM and has_lm_head(state):
        tokenizer = _try_load_tokenizer(head.tokenizer_id or state.tokenizer_id)
        if tokenizer is not None:
            try:
                body = decode_text(state, forward_prompt, tokenizer, cfg)
                return _format_cot(
                    user_prompt, body, sources=_source_names(rag_hits),
                    chain_of_thought=chain_of_thought,
                    backend=f"causal_lm ({head.model_id})",
                )
            except Exception as exc:  # noqa: BLE001
                return _embedder_grounded_synthesis(
                    user_prompt, rag_hits, head, chain_of_thought,
                    note=f"causal_lm decode failed ({exc}); falling back to RAG.",
                )

    if head is not None and head.head_type == MASKED_LM and has_lm_head(state):
        tokenizer = _try_load_tokenizer(head.tokenizer_id or state.tokenizer_id)
        if tokenizer is not None:
            try:
                completion = _masked_lm_fill(state, forward_prompt, tokenizer, cfg)
                return _format_cot(
                    user_prompt, completion, sources=_source_names(rag_hits),
                    chain_of_thought=chain_of_thought,
                    backend=f"masked_lm ({head.model_id})",
                )
            except Exception as exc:  # noqa: BLE001
                return _embedder_grounded_synthesis(
                    user_prompt, rag_hits, head, chain_of_thought,
                    note=f"masked_lm decode failed ({exc}); falling back to RAG.",
                )

    # Embedder (or embedder-equivalent): prefer natural-language synthesis
    # from the RAG hits. Works even if the forward pass returned zeros.
    if head is not None and head.head_type == EMBEDDER:
        return _embedder_grounded_synthesis(
            user_prompt, rag_hits, head, chain_of_thought,
            note=None,
        )

    if head is not None and head.head_type == CLASSIFIER:
        return _classifier_report(user_prompt, rates, head, rag_hits, chain_of_thought)

    # Unknown head OR no head at all.
    heads_total = len(get_registered_heads(state))
    # If RAG hits exist, still produce a useful grounded response.
    if rag_hits:
        return _embedder_grounded_synthesis(
            user_prompt, rag_hits, head, chain_of_thought,
            note=(
                f"no generative head registered ({heads_total} head(s) on "
                "the state). Answering from retrieved documents only."
            ),
        )
    # Nothing to work with. Explain the state of the collective clearly.
    return _actionable_capability_report(
        user_prompt, state, rates_are_zero, chain_of_thought,
    )


# ---- universal-decoder helpers ------------------------------------------


def _text_to_token_stream(prompt: str) -> list[int]:
    """Cheap deterministic tokeniser for the rate-encoder fallback.

    Uses unicode code points mod 2**16 so the rate vector reflects the
    prompt content even when no HF tokenizer is available.
    """
    return [ord(c) & 0xFFFF for c in prompt[-128:]]


def _try_load_tokenizer(tokenizer_id: str | None) -> Any:
    if not tokenizer_id:
        return None
    try:
        from transformers import AutoTokenizer

        return AutoTokenizer.from_pretrained(tokenizer_id)
    except Exception:  # noqa: BLE001
        return None


def _masked_lm_fill(state: BorgState, prompt: str, tokenizer: Any, cfg: DecodeConfig) -> str:
    """One-token mask-fill. Appends a mask at the end and decodes top-1."""
    mask_token = getattr(tokenizer, "mask_token", None) or "<mask>"
    masked = f"{prompt} {mask_token}"
    ids = list(tokenizer.encode(masked))
    hidden_width = _first_layer_width(state)
    x = _encode_ids(ids, hidden_width)
    rates = spike_forward(state, x, time_steps_override=cfg.time_steps)
    logits = logits_from_rates(rates, state)
    row = logits if logits.ndim == 1 else logits[-1]
    top = int(row.argmax())
    return str(tokenizer.decode([top]))


def _classifier_report(
    user_prompt: str,
    rates: np.ndarray,
    head: Any,
    rag_hits: list[tuple[str, str]] | None,
    chain_of_thought: bool,
) -> str:
    if head.vocab_size and head.hidden_size:
        if rates.ndim == 1:
            rates = rates[None, :]
        if rates.shape[-1] != head.hidden_size:
            rates = _project(rates, head.hidden_size)
    # Show top-k predicted class indices in a readable form.
    top = _top_activations(rates, k=3)
    if not top:
        body = (
            "Classifier head is registered but the spike-forward pass "
            "produced no distinguishable activations for this query."
        )
    else:
        cls_lines = [
            f"Most-activated class indices for this query:"
        ] + [f"  - class {i} (activation {v:.3f})" for i, v in top]
        body = "\n".join(cls_lines)
    return _format_cot(
        user_prompt, body,
        sources=_source_names(rag_hits),
        chain_of_thought=chain_of_thought,
        backend=f"classifier ({head.model_id})",
        extra_note=None,
    )


def _embedder_grounded_synthesis(
    user_prompt: str,
    rag_hits: list[tuple[str, str]] | None,
    head: Any,
    chain_of_thought: bool,
    note: str | None,
) -> str:
    """Natural-language answer assembled from RAG-retrieved chunks.

    When chunks are available this reads like a concise grounded reply.
    When no documents are uploaded we explain exactly what to do next
    (upload docs, or absorb a generative model) instead of dumping
    activation numbers.
    """
    backend = (
        f"embedder ({head.model_id}) + RAG"
        if head is not None and getattr(head, "model_id", None)
        else "embedder + RAG"
    )
    if rag_hits:
        top = rag_hits[:3]
        chunks = [c.strip() for _src, c in top if c and c.strip()]
        # Conversational synthesis: stitch chunks with connecting phrasing.
        if chunks:
            body_lines = [
                f"Based on the documents in the collective: {chunks[0][:300]}",
            ]
            if len(chunks) > 1:
                body_lines.append(f"Additionally, {chunks[1][:240]}")
            if len(chunks) > 2:
                body_lines.append(f"The retrieval also surfaced: {chunks[2][:160]}")
            body = " ".join(body_lines)
        else:
            body = "Retrieved chunks were empty; unable to ground an answer."
        return _format_cot(
            user_prompt, body,
            sources=_source_names(rag_hits),
            chain_of_thought=chain_of_thought,
            backend=backend,
            extra_note=note,
        )
    # Embedder present, no documents yet.
    guidance = (
        "No documents have been uploaded yet. The collective contains an "
        "embedder that can retrieve grounded passages once a document "
        "corpus is present. Two options to enable answers:"
        "\n  1. Upload text / PDF / Word documents via the file input. "
        "The embedder will index them and future questions will return "
        "grounded citations."
        "\n  2. Absorb a causal-LM model (GPT-2, Phi-3, Llama) through "
        "the Colab notebook. The collective will then gain generative "
        "capability and produce free-form text responses."
    )
    return _format_cot(
        user_prompt, guidance, sources=[],
        chain_of_thought=chain_of_thought,
        backend=backend,
        extra_note=note,
    )


def _actionable_capability_report(
    user_prompt: str,
    state: BorgState,
    rates_are_zero: bool,
    chain_of_thought: bool,
) -> str:
    """Last-resort when no head and no RAG hits.

    Explains the state of the collective concretely and tells the user
    what to do to unlock a real response. No activation numbers.
    """
    from borg.heads import get_registered_heads

    heads = get_registered_heads(state)
    total = len(heads)
    by_type: dict[str, list[str]] = {}
    for h in heads:
        by_type.setdefault(h.head_type, []).append(h.model_id)

    summary_lines: list[str] = []
    if total == 0:
        summary_lines.append("The collective currently has no registered capability head.")
    else:
        summary_lines.append(f"The collective contains {total} registered head(s):")
        for t, mids in by_type.items():
            summary_lines.append(f"  - {t}: {', '.join(mids[:5])}"
                                 + (f" (+{len(mids) - 5} more)" if len(mids) > 5 else ""))

    action_lines = [
        "To produce text answers, either:",
        "  1. Upload documents using the file input so the retriever can "
        "ground responses in your corpus.",
        "  2. Absorb a causal-LM (for example GPT-2, Phi-3, Llama) via the "
        "Colab notebook at examples/colab/continuous_assimilation.ipynb.",
    ]
    if rates_are_zero:
        action_lines.insert(0,
            "The spike-forward pass for this query returned a zero rate "
            "vector, meaning the absorbed weights do not activate on the "
            "encoded prompt. That typically indicates an encoder-only "
            "model (which is normal) -- the collective still works, it "
            "just needs documents or a generative head."
        )

    body = "\n".join(summary_lines + [""] + action_lines)
    return _format_cot(
        user_prompt, body, sources=[],
        chain_of_thought=chain_of_thought,
        backend="capability-report",
        extra_note=None,
    )


def _is_all_zero(rates: np.ndarray | None) -> bool:
    if rates is None:
        return True
    arr = np.asarray(rates)
    if arr.size == 0:
        return True
    return bool(np.all(arr == 0))


def _source_names(rag_hits: list[tuple[str, str]] | None) -> list[str]:
    if not rag_hits:
        return []
    return [h[0] for h in rag_hits]


def _top_activations(rates: np.ndarray, k: int = 5) -> list[tuple[int, float]]:
    if rates is None:
        return []
    arr = np.asarray(rates).ravel()
    if arr.size == 0:
        return []
    top = np.argsort(-np.abs(arr))[:k]
    return [(int(i), float(arr[int(i)])) for i in top]


def _format_cot(
    user_prompt: str,
    body: str,
    sources: list[str],
    chain_of_thought: bool,
    backend: str,
    extra_note: str | None = None,
) -> str:
    """Render a clean three-step chain-of-thought response.

    `user_prompt` is the user's actual question (not the composed
    system-prompt blob). Truncated to a sensible single-line preview.
    """
    if not chain_of_thought:
        return body
    question = _single_line(user_prompt, limit=200)
    source_line = ", ".join(sources) if sources else "none supplied"
    lines = [
        f"step 1 (restate): {question}",
        f"step 2 (sources): {source_line}",
        f"step 3 (answer, via {backend}):",
        body,
    ]
    if extra_note:
        lines.append("")
        lines.append(f"note: {extra_note}")
    return "\n".join(lines)


def _single_line(text: str, limit: int = 200) -> str:
    """Strip whitespace / newlines so the restate step fits on one line."""
    collapsed = " ".join(text.split())
    return collapsed[:limit] + ("..." if len(collapsed) > limit else "")


def _state_keys(head: Any) -> list[str]:
    return list(head.head_keys or [])


__all__ = [
    "DecodeConfig",
    "LM_BIAS_KEY",
    "LM_HEAD_KEY",
    "decode_text",
    "decode_token_ids",
    "has_lm_head",
    "logits_from_rates",
    "universal_decode",
]
