# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""Fidelity benchmarks for conversion pipelines.

Kept here so tests can import `run_mbe_fidelity` directly without
manipulating `sys.path`. Script wrappers in `scripts/` call these
entry points.
"""

from __future__ import annotations

import statistics
from dataclasses import dataclass

import numpy as np
import torch
from torch import nn


@dataclass
class FidelityReport:
    n_samples: int
    spearman_mean: float
    pearson_mean: float
    cosine_mean: float
    output_dim: int
    sparsity: float


class _Attention(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.q_proj = nn.Linear(dim, dim, bias=False)
        self.k_proj = nn.Linear(dim, dim, bias=False)
        self.v_proj = nn.Linear(dim, dim, bias=False)

    def forward(self, x):
        return self.v_proj(x)


class _MLP(nn.Module):
    def __init__(self, dim: int):
        super().__init__()
        self.fc1 = nn.Linear(dim, dim * 2)
        self.fc2 = nn.Linear(dim * 2, dim)

    def forward(self, x):
        return self.fc2(torch.nn.functional.gelu(self.fc1(x)))


class _TransformerBlock(nn.Module):
    def __init__(self, dim: int = 32):
        super().__init__()
        self.attention = _Attention(dim)
        self.mlp = _MLP(dim)

    def forward(self, x):
        return self.mlp(self.attention(x))


def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    ra = np.argsort(np.argsort(a))
    rb = np.argsort(np.argsort(b))
    if ra.std() == 0 or rb.std() == 0:
        return 0.0
    return float(np.corrcoef(ra, rb)[0, 1])


def _pearson(a: np.ndarray, b: np.ndarray) -> float:
    if a.std() == 0 or b.std() == 0:
        return 0.0
    return float(np.corrcoef(a, b)[0, 1])


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na == 0 or nb == 0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def _align(snn: np.ndarray, ann: np.ndarray) -> np.ndarray:
    if snn.shape == ann.shape:
        return snn
    if snn.shape[0] < ann.shape[0]:
        pad = np.zeros(ann.shape[0] - snn.shape[0], dtype=snn.dtype)
        return np.concatenate([snn, pad])
    return snn[: ann.shape[0]]


def run_mbe_fidelity(
    dim: int = 32,
    n_samples: int = 32,
    time_steps: int = 16,
    seed: int = 42,
) -> FidelityReport:
    from borg.convert import from_transformer
    from borg.inference import BorgState, spike_forward

    torch.manual_seed(seed)
    rng = np.random.default_rng(seed)

    model = _TransformerBlock(dim=dim).eval()
    shard = from_transformer(model, time_steps=time_steps, target_sparsity=0.5)
    state = BorgState(
        state_dict=shard.state_dict,
        thresholds=shard.thresholds,
        time_steps=shard.time_steps,
        quantized=False,
    )

    spearman: list[float] = []
    pearson: list[float] = []
    cosine: list[float] = []

    for _ in range(n_samples):
        x = torch.from_numpy(rng.standard_normal(dim).astype(np.float32)).unsqueeze(0)
        with torch.no_grad():
            ann_out = model(x).squeeze(0).numpy()

        x_rate = np.clip(x.squeeze(0).numpy() + 0.5, 0.0, 1.0).astype(np.float32)
        snn_out = spike_forward(state, x_rate).squeeze(0)
        snn_out = _align(snn_out, ann_out)

        spearman.append(_spearman(ann_out, snn_out))
        pearson.append(_pearson(ann_out, snn_out))
        cosine.append(_cosine(ann_out, snn_out))

    return FidelityReport(
        n_samples=n_samples,
        spearman_mean=statistics.fmean(spearman),
        pearson_mean=statistics.fmean(pearson),
        cosine_mean=statistics.fmean(cosine),
        output_dim=dim,
        sparsity=shard.sparsity,
    )


@dataclass
class PerformanceReport:
    params_total: int
    params_nonzero: int
    sparsity: float
    body_params_total: int
    body_params_nonzero: int
    body_sparsity: float
    state_mb_on_disk: float
    layers_body: int
    layers_total: int
    time_steps: int
    quantized: bool
    forward_ms_mean: float
    forward_ms_p50: float
    forward_ms_p95: float
    logits_ms_mean: float
    decode_tokens_per_s: float
    tokens_emitted: int
    determinism_bitexact: bool


def run_performance_report(
    state_path: str,
    hidden_width: int | None = None,
    forward_samples: int = 50,
    decode_tokens: int = 16,
) -> PerformanceReport:
    import os
    import time

    import numpy as np

    from borg.decode import DecodeConfig, decode_token_ids, logits_from_rates
    from borg.inference import _linear_layers, load, spike_forward

    state = load(state_path)

    params_nonzero = 0
    params_total = 0
    for k, t in state.state_dict.items():
        if k.endswith(".scale"):
            continue
        params_total += int(t.numel())
        if state.quantized and t.dtype.is_floating_point is False:
            params_nonzero += int((t != 0).sum().item())
        else:
            params_nonzero += int((t.abs() > 0).sum().item())

    body_keys = _linear_layers(state)
    layers_body = len(body_keys)
    layers_total = sum(1 for k in state.state_dict if not k.endswith(".scale"))

    body_params_nonzero = 0
    body_params_total = 0
    for k in body_keys:
        t = state.state_dict[k]
        body_params_total += int(t.numel())
        if state.quantized and t.dtype.is_floating_point is False:
            body_params_nonzero += int((t != 0).sum().item())
        else:
            body_params_nonzero += int((t.abs() > 0).sum().item())
    width = hidden_width
    if width is None and body_keys:
        width = int(state.state_dict[body_keys[0]].shape[0])
    if width is None:
        width = 32
    x = np.full(width, 0.5, dtype=np.float32)

    for _ in range(3):
        spike_forward(state, x)
    fwd_samples_ms: list[float] = []
    for _ in range(forward_samples):
        t0 = time.perf_counter()
        rates = spike_forward(state, x)
        fwd_samples_ms.append((time.perf_counter() - t0) * 1000.0)

    logits_samples_ms: list[float] = []
    if "lm_head.weight" in state.state_dict:
        for _ in range(forward_samples):
            t0 = time.perf_counter()
            logits_from_rates(rates, state)
            logits_samples_ms.append((time.perf_counter() - t0) * 1000.0)

    decode_throughput = 0.0
    tokens_emitted = 0
    if "lm_head.weight" in state.state_dict:
        t0 = time.perf_counter()
        ids = decode_token_ids(
            state,
            input_ids=[1, 2, 3],
            config=DecodeConfig(max_new_tokens=decode_tokens, temperature=0.0),
        )
        elapsed = time.perf_counter() - t0
        tokens_emitted = len(ids) - 3
        if elapsed > 0:
            decode_throughput = tokens_emitted / elapsed

    det_a = spike_forward(state, x)
    det_b = spike_forward(state, x)
    determinism = bool(np.array_equal(det_a, det_b))

    state_mb = os.path.getsize(state_path) / 1024 / 1024

    return PerformanceReport(
        params_total=params_total,
        params_nonzero=params_nonzero,
        sparsity=1.0 - (params_nonzero / params_total) if params_total else 1.0,
        body_params_total=body_params_total,
        body_params_nonzero=body_params_nonzero,
        body_sparsity=(
            1.0 - (body_params_nonzero / body_params_total) if body_params_total else 1.0
        ),
        state_mb_on_disk=state_mb,
        layers_body=layers_body,
        layers_total=layers_total,
        time_steps=state.time_steps,
        quantized=state.quantized,
        forward_ms_mean=float(np.mean(fwd_samples_ms)),
        forward_ms_p50=float(np.percentile(fwd_samples_ms, 50)),
        forward_ms_p95=float(np.percentile(fwd_samples_ms, 95)),
        logits_ms_mean=float(np.mean(logits_samples_ms)) if logits_samples_ms else 0.0,
        decode_tokens_per_s=decode_throughput,
        tokens_emitted=tokens_emitted,
        determinism_bitexact=determinism,
    )


__all__ = ["FidelityReport", "PerformanceReport", "run_mbe_fidelity", "run_performance_report"]
