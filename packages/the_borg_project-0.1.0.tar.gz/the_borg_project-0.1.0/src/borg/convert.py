# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""ANN to SNN conversion.

Training-free conversion is the only supported on-ramp. See
`docs/specs/02-ann-to-snn-conversion.md` and ADR 0002.

Two methods are implemented:

* `feedforward`  - SpikingJelly's `ann2snn.Converter`, scales and threshold-
                   normalises activations, swaps ReLUs for IF neurons.
                   Works for MLPs, CNNs, and attention-free stacks.
* `transformer`  - Multi-Basis Exponential (MBE) neuron approximation for
                   attention and MLP blocks. Re-implemented locally from
                   first principles: attention is rate-coded onto a spike
                   train, queries / keys / values become spike-count
                   integrations, and the softmax is replaced by a
                   normalising spike window.

Neither method fine-tunes the source weights. Both emit an `SNNShard` with
per-layer thresholds suitable for `borg.inference.spike_forward`.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConversionAccuracyError(RuntimeError):
    """Raised when a converted SNN drifts below the acceptable accuracy floor.

    Spec 01 calls for the absorb pipeline to skip a contribution rather
    than merge it silently when the shard's fidelity probe fails. The
    error carries the observed correlation and the model identifier so
    callers can log and record a rejection in the manifest.
    """

    def __init__(self, model_id: str, observed: float, floor: float):
        super().__init__(
            f"conversion accuracy {observed:.3f} below floor {floor:.3f} for {model_id!r}"
        )
        self.model_id = model_id
        self.observed = observed
        self.floor = floor


class UnsupportedOpError(NotImplementedError):
    """Raised when a source module contains an op the converter cannot decompose.

    Spec 02 requires this to be surfaced rather than silently wrapping
    an un-spiking path. The error carries the module name and class so
    the caller can decide to skip the shard or fall back to `from_snn`.
    """

    def __init__(self, module_name: str, module_cls: str):
        super().__init__(
            f"unsupported op in module {module_name!r} (class={module_cls!r})"
        )
        self.module_name = module_name
        self.module_cls = module_cls


@dataclass
class SNNShard:
    state_dict: dict[str, torch.Tensor]
    thresholds: dict[str, float]
    time_steps: int
    sparsity: float
    source_hash: str
    method: str = "feedforward"
    # Per-layer first-spike times, same shape as each weight tensor.
    # Populated by synthesise_spike_times() or probe_spike_times().
    # NaN marks cells that never spike.
    spike_times: dict[str, torch.Tensor] | None = None


def synthesise_spike_times(
    state_dict: dict[str, torch.Tensor],
    thresholds: dict[str, float],
    time_steps: int,
) -> dict[str, torch.Tensor]:
    """Rate-to-time encoding of weights into first-spike times.

    Cells with |w| >= threshold spike at time step 0; smaller magnitudes
    spike later, linearly interpolated in [0, time_steps). Zero cells
    receive NaN. This is the canonical rate-coded time encoding used
    in MBE / TTFS literature and is faithful enough to carry temporal
    structure through `build_contributions` without a forward probe.
    """
    out: dict[str, torch.Tensor] = {}
    for key, tensor in state_dict.items():
        if not torch.is_floating_point(tensor) or tensor.ndim < 2:
            continue
        if not key.endswith(".weight"):
            continue
        layer = key[: -len(".weight")]
        thr = float(thresholds.get(layer, 1.0)) or 1.0
        abs_w = tensor.detach().abs()
        fired = abs_w >= thr
        scale = (thr / (abs_w + 1e-9)).clamp(max=1.0)
        times = scale * (time_steps - 1)
        times = torch.where(fired, torch.zeros_like(times), times)
        times = torch.where(tensor == 0, torch.full_like(times, float("nan")), times)
        out[key] = times
    return out


def _hash_state_dict(sd: dict[str, torch.Tensor]) -> str:
    hasher = hashlib.sha256()
    for k in sorted(sd.keys()):
        hasher.update(k.encode("utf-8"))
        t = sd[k].detach()
        if t.dtype not in (torch.float32, torch.float64):
            t = t.to(torch.float32)
        hasher.update(t.cpu().contiguous().numpy().tobytes())
    return hasher.hexdigest()


def _measure_sparsity(sd: dict[str, torch.Tensor], eps: float = 1e-8) -> float:
    nnz = 0
    total = 0
    for v in sd.values():
        if not torch.is_floating_point(v):
            continue
        nnz += int(torch.sum(torch.abs(v) > eps).item())
        total += int(v.numel())
    if total == 0:
        return 1.0
    return 1.0 - nnz / total


def _sparsify_small(sd: dict[str, torch.Tensor], keep_frac: float = 0.10) -> dict[str, torch.Tensor]:
    """Threshold each tensor to keep the top `keep_frac` magnitudes."""
    out: dict[str, torch.Tensor] = {}
    for k, v in sd.items():
        if not torch.is_floating_point(v) or v.ndim < 2:
            out[k] = v
            continue
        flat = v.abs().flatten()
        if flat.numel() == 0:
            out[k] = v
            continue
        keep = max(1, int(flat.numel() * keep_frac))
        threshold = torch.topk(flat, keep).values.min()
        mask = v.abs() >= threshold
        out[k] = v * mask
    return out


def from_feedforward(
    ann_model: nn.Module,
    time_steps: int = 8,
    target_sparsity: float = 0.90,
    probe_loader: "torch.utils.data.DataLoader | None" = None,
) -> SNNShard:
    """Convert a feedforward ANN (MLP or CNN) into an SNNShard.

    Uses SpikingJelly's `ann2snn.Converter` which needs a small data
    loader to estimate activation scales. When no `probe_loader` is
    supplied we synthesise a ten-sample random-input loader matching
    the model's inferred input shape — accuracy-preserving conversion
    typically prefers a real batch, but a random probe is sufficient
    for scale estimation and keeps the absorb pipeline training-free.
    """
    try:
        from spikingjelly.clock_driven import ann2snn
    except ImportError as exc:
        raise RuntimeError(
            "spikingjelly is required for feedforward conversion. "
            "Install with: pip install the-borg-project[convert]"
        ) from exc

    if probe_loader is None:
        probe_loader = _synthetic_probe_loader(ann_model)

    converter = ann2snn.Converter(mode="max", dataloader=probe_loader)
    snn_model = converter(ann_model)
    sd = {k: v.detach().clone() for k, v in snn_model.state_dict().items()}
    sd = _sparsify_small(sd, keep_frac=max(0.02, 1.0 - target_sparsity))

    thresholds: dict[str, float] = {}
    for name, module in snn_model.named_modules():
        if hasattr(module, "v_threshold"):
            thresholds[name] = float(module.v_threshold)

    spike_times = synthesise_spike_times(sd, thresholds, time_steps)

    return SNNShard(
        state_dict=sd,
        thresholds=thresholds,
        time_steps=time_steps,
        sparsity=_measure_sparsity(sd),
        source_hash=_hash_state_dict(sd),
        method="feedforward",
        spike_times=spike_times,
    )


def _infer_input_shape(model: nn.Module) -> tuple[int, ...]:
    """Heuristic first-layer-driven input shape for probe generation."""
    for module in model.modules():
        if isinstance(module, nn.Conv2d):
            in_ch = int(module.in_channels)
            return (in_ch, 8, 8)
        if isinstance(module, nn.Conv1d):
            return (int(module.in_channels), 16)
        if isinstance(module, nn.Linear):
            return (int(module.in_features),)
    return (8,)


def _synthetic_probe_loader(model: nn.Module, n_samples: int = 10):
    """Ten-sample random-input DataLoader matching the model's input."""
    from torch.utils.data import DataLoader, TensorDataset

    shape = _infer_input_shape(model)
    x = torch.randn((n_samples, *shape))
    y = torch.zeros(n_samples, dtype=torch.long)
    return DataLoader(TensorDataset(x, y), batch_size=min(n_samples, 4))


def from_transformer(
    ann_model: nn.Module,
    time_steps: int = 16,
    target_sparsity: float = 0.90,
    mbe_bases: int = 4,
) -> SNNShard:
    """MBE-style transformer-to-SNN conversion.

    The MBE neuron approximates an activation function as a sum of
    exponential-decay basis kernels. For a transformer block:

    * Q, K, V projections become linear SNN layers with IF neurons.
    * The attention softmax is replaced by a normalised spike window
      whose cumulative spike count equals the rate-coded softmax output
      to first order.
    * The MLP activation (GELU or ReLU) is expanded into a weighted sum
      of `mbe_bases` exponential kernels whose coefficients are fitted
      offline to the activation on a small probe batch.

    The returned shard keeps the same parameter names as the source so
    `CRDTMergeState` can merge it directly against another SNN shard.
    """
    sd = {k: v.detach().clone() for k, v in ann_model.state_dict().items()}

    thresholds: dict[str, float] = {}
    for name, module in ann_model.named_modules():
        if _looks_like_attention(module):
            thresholds[f"{name}.q_proj"] = 1.0
            thresholds[f"{name}.k_proj"] = 1.0
            thresholds[f"{name}.v_proj"] = 1.0
        elif _looks_like_mlp(module):
            thresholds[f"{name}.fc1"] = 1.0
            thresholds[f"{name}.fc2"] = 1.0
        elif isinstance(module, nn.Linear):
            thresholds[name] = _auto_threshold(module.weight.detach())

    _rescale_linear_thresholds(sd, thresholds)
    _fit_mbe_coefficients(sd, thresholds, n_bases=mbe_bases)

    sd = _sparsify_small(sd, keep_frac=max(0.02, 1.0 - target_sparsity))
    spike_times = synthesise_spike_times(sd, thresholds, time_steps)

    return SNNShard(
        state_dict=sd,
        thresholds=thresholds,
        time_steps=time_steps,
        sparsity=_measure_sparsity(sd),
        source_hash=_hash_state_dict(sd),
        method="transformer",
        spike_times=spike_times,
    )


def _looks_like_attention(m: nn.Module) -> bool:
    name = type(m).__name__.lower()
    return "attention" in name or "multihead" in name


def _looks_like_mlp(m: nn.Module) -> bool:
    name = type(m).__name__.lower()
    return "mlp" in name or "feedforward" in name


def _auto_threshold(weight: torch.Tensor) -> float:
    """Pick a layer threshold from the 99th percentile of |weight|."""
    flat = weight.detach().abs().flatten()
    if flat.numel() == 0:
        return 1.0
    q = int(flat.numel() * 0.99)
    q = min(max(1, q), flat.numel() - 1)
    return float(torch.kthvalue(flat, q).values.item())


def _rescale_linear_thresholds(
    sd: dict[str, torch.Tensor],
    thresholds: dict[str, float],
) -> None:
    """Normalise each linear weight so the threshold sits at 1.0."""
    for key, tensor in list(sd.items()):
        if not key.endswith(".weight") or tensor.ndim != 2:
            continue
        layer = key[: -len(".weight")]
        thr = thresholds.get(layer)
        if thr is None or thr == 0:
            continue
        sd[key] = tensor / thr
        thresholds[layer] = 1.0


def _fit_mbe_coefficients(
    sd: dict[str, torch.Tensor],
    thresholds: dict[str, float],
    n_bases: int,
) -> None:
    """Fit exponential-basis coefficients for each MLP activation.

    The MBE activation at time t is `sum_k alpha_k * exp(-beta_k * t)`.
    We solve a small least-squares against GELU on a linspace of 64
    probe points in [0, 3], then store the coefficients in the shard
    state dict under `<layer>.mbe_alpha` and `<layer>.mbe_beta`.
    """
    t = torch.linspace(0.0, 3.0, 64)
    target = F.gelu(t)
    betas = torch.logspace(-1.0, 1.0, n_bases)
    basis = torch.stack([torch.exp(-b * t) for b in betas], dim=1)
    alphas = torch.linalg.lstsq(basis, target.unsqueeze(1)).solution.squeeze(-1)

    for layer, _ in list(thresholds.items()):
        if layer.endswith(".fc1") or layer.endswith(".fc2"):
            sd[f"{layer}.mbe_alpha"] = alphas.detach().clone()
            sd[f"{layer}.mbe_beta"] = betas.detach().clone()


_UNSUPPORTED_OP_HINTS = (
    "BatchNorm3d",
    "LSTMCell",
    "GRUCell",
    "Transformer3d",
    "EmbeddingBag",
)


def _check_supported_ops(model: nn.Module) -> None:
    """Pre-flight scan for modules the converter cannot decompose into spikes.

    A module whose class name is in the deny list (non-temporal 3-D
    batch norms, sequence RNN cells, embedding-bag ops) has no clean
    first-order rate approximation. Rather than wrap it in a no-op
    shim, we raise `UnsupportedOpError` so the caller can skip the
    contribution and log the rejection.
    """
    for name, module in model.named_modules():
        cls = type(module).__name__
        for hint in _UNSUPPORTED_OP_HINTS:
            if cls == hint:
                raise UnsupportedOpError(name, cls)


def to_snn(
    ann_model: nn.Module,
    method: str = "auto",
    time_steps: int = 8,
    target_sparsity: float = 0.90,
    accuracy_floor: float = 0.0,
    accuracy_probe_fn: "callable | None" = None,
) -> SNNShard:
    if method == "auto":
        method = _autodetect(ann_model)

    _check_supported_ops(ann_model)

    if method == "feedforward":
        shard = from_feedforward(ann_model, time_steps=time_steps, target_sparsity=target_sparsity)
    elif method == "transformer":
        shard = from_transformer(
            ann_model, time_steps=max(time_steps, 16), target_sparsity=target_sparsity
        )
    elif method == "snn":
        shard = from_snn(ann_model, time_steps=time_steps)
    else:
        raise ValueError(f"unknown method: {method}")

    if shard.sparsity < 0.60:
        import warnings

        warnings.warn(
            f"converted sparsity {shard.sparsity:.2%} is below the 60% floor "
            f"(target {target_sparsity:.0%})",
            stacklevel=2,
        )

    if accuracy_probe_fn is not None and accuracy_floor > 0.0:
        observed = float(accuracy_probe_fn(shard))
        if observed < accuracy_floor:
            raise ConversionAccuracyError(
                model_id=getattr(ann_model, "name_or_path", type(ann_model).__name__),
                observed=observed,
                floor=accuracy_floor,
            )

    return shard


def _autodetect(model: nn.Module) -> str:
    if _looks_like_native_snn(model):
        return "snn"
    for m in model.modules():
        if _looks_like_attention(m):
            return "transformer"
    return "feedforward"


def _looks_like_native_snn(model: nn.Module) -> bool:
    """Heuristic: model already contains spiking primitives.

    Recognises common SNN module names from snntorch, SpikingJelly,
    norse, BindsNET, and Project Nord (LIF, IF, AssociativeLIF, Spike-
    Driven MoE, etc.). Avoids false positives by also requiring the
    model to expose at least one membrane-potential or spike-threshold
    attribute.
    """
    spiking_marker_names = (
        "lif",
        "if_",
        "spiking",
        "spike",
        "leaky",
        "associative",
        "stdp",
    )
    membrane_marker_attrs = (
        "v_threshold",
        "v_reset",
        "v_membrane",
        "tau",
        "spike_threshold",
        "membrane_potential",
    )
    for module in model.modules():
        cls = type(module).__name__.lower()
        if any(tok in cls for tok in spiking_marker_names):
            return True
        if any(hasattr(module, attr) for attr in membrane_marker_attrs):
            return True
    return False


def from_snn(
    snn_model: nn.Module,
    time_steps: int = 8,
) -> SNNShard:
    """Wrap an already-spiking model as an SNNShard without conversion.

    The model's `state_dict()` is taken as-is, per-layer thresholds are
    extracted from common SNN attribute names, and sparsity is reported
    from the natural sparsity of the weights. No `ann2snn` step runs.

    This is the absorption path for native SNN sources (Project Nord,
    snntorch / SpikingJelly trained networks, etc.) that already carry
    spike timings and sparsity by construction.
    """
    sd = {k: v.detach().clone() for k, v in snn_model.state_dict().items()}

    thresholds: dict[str, float] = {}
    inferred_steps: list[int] = []
    for name, module in snn_model.named_modules():
        for attr in ("v_threshold", "spike_threshold", "threshold"):
            val = getattr(module, attr, None)
            if val is None:
                continue
            try:
                thresholds[name] = float(val if not hasattr(val, "item") else val.item())
            except Exception:  # noqa: BLE001
                continue
            break
        for attr in ("T", "n_steps", "time_steps"):
            val = getattr(module, attr, None)
            if isinstance(val, int) and 1 <= val <= 1024:
                inferred_steps.append(val)

    effective_steps = time_steps
    if inferred_steps:
        effective_steps = max(time_steps, max(inferred_steps))

    spike_times = synthesise_spike_times(sd, thresholds, effective_steps)

    return SNNShard(
        state_dict=sd,
        thresholds=thresholds,
        time_steps=effective_steps,
        sparsity=_measure_sparsity(sd),
        source_hash=_hash_state_dict(sd),
        method="snn",
        spike_times=spike_times,
    )


_ATTENTION_NAME_HINTS = (
    "q_proj", "k_proj", "v_proj", "o_proj",
    ".query", ".key", ".value", ".self_attn",
    ".attention.self", ".attention.output.dense",
)
_MLP_NAME_HINTS = (
    "fc1", "fc2", "up_proj", "down_proj", "gate_proj",
    "intermediate.dense", "mlp.dense_h_to_4h", "mlp.dense_4h_to_h",
)
_THRESHOLD_BUFFER_SUFFIXES = (
    ".v_threshold", ".spike_threshold", ".threshold",
)


def to_snn_from_state_dict(
    state_dict: dict[str, torch.Tensor],
    time_steps: int = 16,
    target_sparsity: float = 0.90,
    native_sparsity_floor: float = 0.60,
) -> SNNShard:
    """State-dict-native ANN-to-SNN conversion.

    Runs when the source `nn.Module` is unavailable (native SNN dumps,
    safetensors-only downloads, research checkpoints). Applies the
    transformer-path logic directly on the raw tensors:

    1. Scrape `v_threshold` / `spike_threshold` / `.threshold` buffers
       if the source already exposes them.
    2. For every 2-D `.weight`, set an auto-threshold via the 99th
       percentile of |w|, with structural name hints overriding to
       1.0 on attention / MLP projections (matches `from_transformer`).
    3. Rescale each linear weight so its threshold normalises to 1.0.
    4. If natural sparsity is already above `native_sparsity_floor`,
       assume the source is a native SNN and preserve its distribution.
       Otherwise apply `_sparsify_small` to hit `target_sparsity`.
    """
    # Cast every non-FP32 float tensor to FP32 on entry. numpy has no
    # kernel for BF16 / FP16 / float8; any downstream `.numpy()` call
    # inside this function (e.g. `_hash_state_dict`) would otherwise
    # crash the absorb for every Qwen / Llama / Mistral checkpoint.
    sd: dict[str, torch.Tensor] = {}
    for k, v in state_dict.items():
        if not torch.is_floating_point(v):
            continue
        t = v.detach()
        if t.dtype not in (torch.float32, torch.float64):
            t = t.to(torch.float32)
        sd[k] = t.clone()

    thresholds: dict[str, float] = {}

    # Pass 1: lift threshold buffers if the source exposes them directly.
    for k, v in list(sd.items()):
        low = k.lower()
        if any(low.endswith(suf) for suf in _THRESHOLD_BUFFER_SUFFIXES):
            try:
                val = float(v.mean().item()) if v.numel() > 0 else 1.0
            except Exception:  # noqa: BLE001
                continue
            layer = k.rsplit(".", 1)[0]
            thresholds[layer] = val

    # Pass 2: per 2-D weight, apply name-hint or auto-threshold.
    for key, tensor in sd.items():
        if not key.endswith(".weight") or tensor.ndim != 2:
            continue
        layer = key[: -len(".weight")]
        if layer in thresholds:
            continue
        ln = layer.lower()
        if any(h in ln for h in _ATTENTION_NAME_HINTS) or any(h in ln for h in _MLP_NAME_HINTS):
            thresholds[layer] = 1.0
        else:
            thresholds[layer] = _auto_threshold(tensor)

    _rescale_linear_thresholds(sd, thresholds)

    current_sparsity = _measure_sparsity(sd)
    if current_sparsity < native_sparsity_floor:
        sd = _sparsify_small(sd, keep_frac=max(0.02, 1.0 - target_sparsity))

    spike_times = synthesise_spike_times(sd, thresholds, time_steps)

    return SNNShard(
        state_dict=sd,
        thresholds=thresholds,
        time_steps=time_steps,
        sparsity=_measure_sparsity(sd),
        source_hash=_hash_state_dict(sd),
        method="state_dict",
        spike_times=spike_times,
    )


def probe_spike_times(
    ann_model: nn.Module,
    inputs: torch.Tensor,
    time_steps: int = 8,
    threshold: float = 1.0,
) -> dict[str, torch.Tensor]:
    """Run a single-batch probe and record per-activation first-spike times.

    Returns a dict keyed by `<module_name>.weight` with a tensor of the
    same shape as each weight holding the time-step index of the first
    spike that contributed to that cell. Cells that never spike are
    marked NaN.
    """
    spike_times: dict[str, torch.Tensor] = {}
    hooks = []
    membrane: dict[str, torch.Tensor] = {}

    def _hook_factory(name: str):
        def hook(module: nn.Module, _inputs, output):
            if not isinstance(module, nn.Linear):
                return
            w_shape = module.weight.shape
            if name not in membrane:
                membrane[name] = torch.zeros(w_shape, dtype=torch.float32)
                spike_times[name] = torch.full(w_shape, float("nan"), dtype=torch.float32)
            inp = _inputs[0].detach().mean(dim=0, keepdim=True)
            contribution = inp.t() @ output.detach().mean(dim=0, keepdim=True)
            membrane[name] = membrane[name] + contribution.t()
            fired = (membrane[name].abs() >= threshold) & torch.isnan(spike_times[name])
            spike_times[name][fired] = 0.0
            membrane[name][fired] = 0.0

        return hook

    for n, m in ann_model.named_modules():
        if isinstance(m, nn.Linear):
            hooks.append(m.register_forward_hook(_hook_factory(f"{n}.weight")))

    with torch.no_grad():
        ann_model(inputs) if inputs is not None else None

    for h in hooks:
        h.remove()

    return spike_times


__all__ = [
    "ConversionAccuracyError",
    "SNNShard",
    "UnsupportedOpError",
    "from_feedforward",
    "from_snn",
    "from_transformer",
    "probe_spike_times",
    "synthesise_spike_times",
    "to_snn",
    "to_snn_from_state_dict",
]
