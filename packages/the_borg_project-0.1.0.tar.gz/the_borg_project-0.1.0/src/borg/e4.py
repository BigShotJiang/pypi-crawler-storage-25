# SPDX-License-Identifier: BUSL-1.1
# Copyright 2026 Ryan Gillespie / Optitransfer
#
# Licensed under the Business Source License 1.1 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://github.com/mgillr/the-borg-project/blob/main/LICENSE
# Patent: UK Application No. 2607132.4, GB2608127.3
#
# Change Date: 2028-03-29
# Change License: Apache License, Version 2.0

#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#
# On 2028-03-29 this file converts to Apache License, Version 2.0.

"""E4 trust-lattice wiring.

Bridges contributions between `borg.sparse` and the upstream E4 stack
(`crdt_merge.e4.*`). The upstream types accept arbitrary data; this module
supplies the conversions and canonical hashing required for real PCO
generation, trust updates, and causal-clock increments.

Six trust dimensions (from `crdt_merge.e4.typed_trust.TRUST_DIMENSIONS`):
integrity, causality, consistency, gossip, model, context.
"""

from __future__ import annotations

import hashlib
from collections.abc import Iterable
from dataclasses import dataclass

import numpy as np
from crdt_merge.e4 import (
    AggregateProofCarryingOperation,
    SubtreeRef,
    TypedTrustScore,
)
from crdt_merge.e4.causal_trust_clock import CausalTrustClock
from crdt_merge.e4.delta_trust_lattice import DeltaTrustLattice
from crdt_merge.e4.typed_trust import TRUST_DIMENSIONS

DIMENSION_ORDER: tuple[str, ...] = (
    "integrity",
    "causality",
    "consistency",
    "gossip",
    "model",
    "context",
)

assert set(DIMENSION_ORDER) == TRUST_DIMENSIONS


def trust_vector_to_score(vector: np.ndarray, peer_id: str) -> TypedTrustScore:
    """Build a TypedTrustScore that yields the given six-dim trust vector.

    The trust for a dimension is `max(0, 1 - total_evidence)`. To target
    an arbitrary value `t` in `[0, 1]`, we record `1 - t` worth of
    evidence against the peer itself (self-attestation is rejected
    upstream, so we record via a distinct synthetic observer).
    """
    if vector.shape != (6,):
        raise ValueError("trust vector must be length 6")
    score = TypedTrustScore.full_trust()
    for dim, value in zip(DIMENSION_ORDER, vector.tolist(), strict=True):
        if value >= 1.0:
            continue
        amount = float(1.0 - value)
        if amount <= 0:
            continue
        score = score.record_evidence(
            observer=f"{peer_id}:bootstrap",
            dimension=dim,
            amount=amount,
            proof=_AcceptingProof(),
        )
    return score


def trust_vector_hash(vector: np.ndarray) -> str:
    """Deterministic hex hash of a six-dim trust vector."""
    if vector.shape != (6,):
        raise ValueError("trust vector must be length 6")
    h = hashlib.sha256()
    for v in vector.tolist():
        h.update(np.float64(v).tobytes())
    return h.hexdigest()


@dataclass
class PeerContext:
    peer_id: str
    lattice: DeltaTrustLattice
    clock: CausalTrustClock

    @classmethod
    def new(cls, peer_id: str) -> PeerContext:
        lattice = DeltaTrustLattice(peer_id=peer_id)
        clock = CausalTrustClock(peer_id=peer_id, trust_lattice=lattice)
        clock.bind_trust_lattice(lattice)
        return cls(peer_id=peer_id, lattice=lattice, clock=clock)

    def record_self_trust(self, vector: np.ndarray) -> TypedTrustScore:
        score = trust_vector_to_score(vector, self.peer_id)
        self.lattice._trust_scores[self.peer_id] = score  # noqa: SLF001
        return score

    def step(self) -> CausalTrustClock:
        new_clock = self.clock.increment()
        self.clock = new_clock
        return new_clock


def build_pco(
    peer_id: str,
    clock: CausalTrustClock,
    merkle_root: str,
    trust_vec: np.ndarray,
    bounds: Iterable[tuple[tuple[int, ...], int, str, str]] | None = None,
) -> bytes:
    """Build a 128-byte AggregateProofCarryingOperation wire blob.

    `bounds` is a sequence of `(path, depth, old_hash, new_hash)` tuples
    describing the delta bounds covered by this PCO. If omitted, a single
    synthetic bound derived from `merkle_root` is used.
    """
    if bounds is None:
        bounds_tuple: tuple[SubtreeRef, ...] = (
            SubtreeRef(path=(), depth=0, old_hash=merkle_root, new_hash=merkle_root),
        )
    else:
        bounds_tuple = tuple(
            SubtreeRef(path=p, depth=d, old_hash=o, new_hash=n) for p, d, o, n in bounds
        )

    pco = AggregateProofCarryingOperation.build(
        originator_id=peer_id,
        signing_fn=_null_sign,
        merkle_root=merkle_root,
        clock_snapshot=clock.serialize_compact(),
        trust_vector_hash=trust_vector_hash(trust_vec),
        delta_bounds=bounds_tuple,
    )
    return bytes(pco.to_wire())


class _AcceptingProof:
    def verify(self) -> bool:  # noqa: D401 - matches TypedTrustScore proof protocol
        return True


def _null_sign(digest: bytes) -> bytes:
    """Placeholder signer returning a 64-byte zeroed signature.

    Real Ed25519 signing is wired in `borg.worker.signing`. For the
    merge-time PCO the signature proves the originator held the digest
    at the time of stamping; when crypto extras are installed this is
    swapped for a real signer.
    """
    _ = digest
    return b"\x00" * 64
