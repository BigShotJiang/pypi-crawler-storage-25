"""Varity entry point for python -m varity."""

from varity.cli import main

if __name__ == "__main__":
    main()
