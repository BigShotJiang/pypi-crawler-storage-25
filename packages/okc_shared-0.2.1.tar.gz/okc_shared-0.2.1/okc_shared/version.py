"""Version information for okc-shared package."""

__version__ = "0.2.1"
