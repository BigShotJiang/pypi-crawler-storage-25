"""Setup for okc-shared."""

import re
from setuptools import setup, find_packages

with open("okc_shared/version.py", "r") as fh:
    match = re.search(r"^__version__ = ['\"]([^'\"]*)['\"]", fh.read(), re.M)
    if not match:
        raise RuntimeError("Unable to find version string in okc_shared/version.py")
    __version__ = match.group(1)

with open("requirements-package.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="okc-shared",
    version=__version__,
    packages=find_packages(exclude=["tests", "tests.*"]),
    python_requires=">=3.10",
    install_requires=requirements,
    extras_require={"dev": ["pytest"]},
)
