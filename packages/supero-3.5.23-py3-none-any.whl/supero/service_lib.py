"""
supero.service_lib — Client-side library for Supero services + event triggers.

Three responsibilities:
  1. Typed service accessors (sl.email.send, sl.slack.message, ...)
  2. Event triggers (sl.trigger("@create:order", payload))
  3. Backward-compat Services(session, url, domain) shim

Actual workflow execution happens server-side in the workflow engine
(workflows tenant service). This library just:
  - Looks up event→workflow bindings from workflow service config_data
  - Resolves input_map dotted paths against the event payload
  - POSTs to /api/v1/services/execute to run the workflow

Event bindings live in workflow service config_data.event_bindings:
  {
    "event_bindings": [
      {
        "event": "@signup",
        "workflow_id": "welcome_new_user",
        "input_map": {"email": "user.email", "name": "user.name"}
      }
    ]
  }

Configured at app.supero.dev → Services → workflows.

Environment variables read:
  SUPERO_URL          — Platform base URL (default: https://api.supero.dev)
  SUPERO_API_KEY      — Admin API key (required for exec/trigger)
  SUPERO_DOMAIN       — Domain name
  SUPERO_PROJECT_UUID — Project UUID (optional)
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request

__version__ = "1.6.0"
# Cache TTL for event_bindings fetched from workflow service config.
# Five minutes is a reasonable tradeoff: config changes propagate within
# 5 min, and we don't hammer the config endpoint on every trigger.
_DEFAULT_CONFIG_TTL_SECONDS = 300

_BROWSER_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
)

# ═══════════════════════════════════════════════════════════════════
# v4: Use PlatformClient as shared HTTP machinery.
#
# Prior versions of service_lib had inline urllib.request calls
# duplicating what PlatformClient already does. Now all outbound
# HTTP goes through a single lazy-constructed PlatformClient.
# ═══════════════════════════════════════════════════════════════════
_SERVICELIB_V4 = True  # Marker for idempotency

try:
    from supero.platform_client import PlatformClient
except ImportError:
    try:
        from .platform_client import PlatformClient
    except ImportError:
        try:
            from platform_client import PlatformClient
        except ImportError:
            PlatformClient = None  # ServiceLib will degrade gracefully




# ═══════════════════════════════════════════════════════════════════
# Transactional services support (added in v1.6.0)
#
# 17 platform-level transactional services (task, cart, order, payment,
# approval, etc.) are exposed via sl.task, sl.cart, ..., backed by a
# shared TransactionalClient that lives at sl.transactional.
#
# See supero/transactional.py for the full implementation.
# ═══════════════════════════════════════════════════════════════════
# [TXN_PATCH_v1_6_0]  ← do not remove; used to detect already-applied state

try:
    from supero.transactional import (
        TransactionalClient,
        RefClient,
        TRANSACTIONAL_ACCESSORS,
        # Re-exported so callers can `from supero.service_lib import StateConflictError`
        ServiceResult,
        ServiceError,
        BadRequestError,
        NotFoundError,
        StateConflictError,
        PlatformError,
        SoftFailureError,
    )
except ImportError:
    try:
        from .transactional import (
            TransactionalClient,
            RefClient,
            TRANSACTIONAL_ACCESSORS,
            ServiceResult,
            ServiceError,
            BadRequestError,
            NotFoundError,
            StateConflictError,
            PlatformError,
            SoftFailureError,
        )
    except ImportError:
        try:
            from transactional import (
                TransactionalClient,
                RefClient,
                TRANSACTIONAL_ACCESSORS,
                ServiceResult,
                ServiceError,
                BadRequestError,
                NotFoundError,
                StateConflictError,
                PlatformError,
                SoftFailureError,
            )
        except ImportError:
            TransactionalClient = None
            RefClient = None
            TRANSACTIONAL_ACCESSORS = ()
            class ServiceError(Exception): pass
            class BadRequestError(ServiceError): pass
            class NotFoundError(ServiceError): pass
            class StateConflictError(ServiceError): pass
            class PlatformError(ServiceError): pass
            class SoftFailureError(ServiceError): pass
            class ServiceResult(dict): pass

# Hoist accessor classes to stable module-level names. Driven by the
# canonical TRANSACTIONAL_ACCESSORS tuple from transactional.py so this
# stays in sync if accessors are added/renamed.
if TRANSACTIONAL_ACCESSORS:
    _ACCESSORS_BY_NAME = dict(TRANSACTIONAL_ACCESSORS)
    _T_Task              = _ACCESSORS_BY_NAME["task"]
    _T_Ticket            = _ACCESSORS_BY_NAME["ticket"]
    _T_Comment           = _ACCESSORS_BY_NAME["comment"]
    _T_Attachment        = _ACCESSORS_BY_NAME["attachment"]
    _T_Feedback          = _ACCESSORS_BY_NAME["feedback"]
    _T_Membership        = _ACCESSORS_BY_NAME["membership"]
    _T_Notification      = _ACCESSORS_BY_NAME["notification"]
    _T_Payment           = _ACCESSORS_BY_NAME["payment"]
    _T_Cart              = _ACCESSORS_BY_NAME["cart"]
    _T_Order             = _ACCESSORS_BY_NAME["order"]
    _T_Booking           = _ACCESSORS_BY_NAME["booking"]
    _T_Appointment       = _ACCESSORS_BY_NAME["appointment"]
    _T_RecurringPlan     = _ACCESSORS_BY_NAME["recurring_plan"]
    _T_Approval          = _ACCESSORS_BY_NAME["approval"]
    _T_Inventory         = _ACCESSORS_BY_NAME["inventory"]
    _T_LoyaltyPoints     = _ACCESSORS_BY_NAME["loyalty_points"]
    _T_DocumentSignature = _ACCESSORS_BY_NAME["document_signature"]
else:
    _T_Task = _T_Ticket = _T_Comment = _T_Attachment = None
    _T_Feedback = _T_Membership = _T_Notification = _T_Payment = None
    _T_Cart = _T_Order = _T_Booking = _T_Appointment = None
    _T_RecurringPlan = _T_Approval = _T_Inventory = None
    _T_LoyaltyPoints = _T_DocumentSignature = None

class _CrudAccessor:
    """Minimal CRUD surface on ServiceLib, backed by PlatformClient.

    Exists because server.py's event-trigger hook needs to fetch full
    records after CREATE to enrich workflow input. The platform's CREATE
    response only returns system fields (uuid/name/fq_name), so we GET
    the full record separately.

    This is NOT a replacement for Supero.crud (CrudManager) — that's
    the rich API for application code. ServiceLib._CrudAccessor is the
    infrastructure-minimal surface for server.py triggers.
    """

    def __init__(self, service_lib):
        self._sl = service_lib

    def get(self, qualified_type, uuid):
        """GET /api/v1/crud/{domain}/{qualified_type}/{uuid}.

        Returns the inner record dict (peeled from platform envelope)
        or None. Never raises.
        """
        if not uuid or not qualified_type:
            return None
        if not self._sl.domain:
            return None
        http = self._sl._get_http()
        if http is None:
            self._sl._logger("warning", "crud.get: PlatformClient unavailable")
            return None
        try:
            envelope = http.get(
                f"/api/v1/crud/{self._sl.domain}/{qualified_type}/{uuid}"
            )
            return _peel_envelope(envelope)
        except Exception as e:
            self._sl._logger(
                "warning",
                f"crud.get({qualified_type}/{uuid}): {e}",
            )
            return None


def _peel_envelope(envelope):
    """Extract inner record from a platform response envelope.

    Platform envelope shape: {"success": True, "data": {"<type>": {...}}, "uuid": ..., "fq_name": [...]}
    Some endpoints return the record flat. Handle both.
    """
    if not isinstance(envelope, dict):
        return None
    data = envelope.get("data")
    if isinstance(data, dict):
        for inner in data.values():
            if isinstance(inner, dict):
                # Merge envelope's top-level uuid/fq_name if not already in inner
                # (they're authoritative from platform-core's mirror logic)
                if "uuid" not in inner and envelope.get("uuid"):
                    inner = dict(inner)
                    inner["uuid"] = envelope["uuid"]
                return inner
    # Record-directly style (some endpoints)
    if envelope.get("uuid"):
        return envelope
    return None





def _strip_env(value):
    """Strip surrounding quotes (EnvManager wraps values in double quotes)."""
    if value is None:
        return ""
    return str(value).strip().strip('"').strip("'")


def _resolve_dotted_path(data, path):
    """Walk a dotted path through a nested dict.

    >>> _resolve_dotted_path({"user": {"email": "x@y.com"}}, "user.email")
    'x@y.com'
    >>> _resolve_dotted_path({}, "nope") is None
    True
    """
    if not path:
        return None
    obj = data
    for part in path.split("."):
        if not isinstance(obj, dict):
            return None
        obj = obj.get(part)
        if obj is None:
            return None
    return obj


def _resolve_input_map(input_map, payload):
    """Turn {key: "dotted.path"} + payload → {key: value}.

    Paths that don't resolve are omitted (workflow defaults may fill in).
    Non-string values in input_map are passed through as-is (literals).
    """
    if not isinstance(input_map, dict) or not input_map:
        return {}
    result = {}
    for key, path in input_map.items():
        if isinstance(path, str):
            value = _resolve_dotted_path(payload, path)
            if value is not None:
                result[key] = value
        else:
            # Literal value (not a dotted path) — pass through
            result[key] = path
    return result


# ═══════════════════════════════════════════════════════════════════
# Typed service accessors
# ═══════════════════════════════════════════════════════════════════

class _ServiceAccessor:
    """Base class for sl.email, sl.slack, etc.

    Each accessor holds a reference to its parent ServiceLib and its
    service_id. Operation methods call self._sl.exec(...).
    """

    def __init__(self, service_lib, service_id):
        self._sl = service_lib
        self._service_id = service_id

    def _exec(self, operation, input_data):
        return self._sl.exec(self._service_id, operation, input_data)


class _EmailAccessor(_ServiceAccessor):
    def send(self, to, subject, body_html=None, body_text=None, from_name=None):
        inp = {"to_email": to, "subject": subject}
        if body_html: inp["body_html"] = body_html
        if body_text: inp["body_text"] = body_text
        if from_name: inp["from_name"] = from_name
        return self._exec("send_email", inp)


class _SmsAccessor(_ServiceAccessor):
    def send(self, to, body):
        return self._exec("send_sms", {"to_number": to, "body": body})


class _WhatsAppAccessor(_ServiceAccessor):
    def send(self, to, body):
        return self._exec("send_message", {"to_number": to, "body": body})

    def send_template(self, to, template_name, template_params=None):
        return self._exec("send_template", {
            "to_number": to, "template_name": template_name,
            "template_params": template_params or {},
        })


class _PushAccessor(_ServiceAccessor):
    def notify(self, device_token, title, body):
        return self._exec("send_notification", {
            "device_token": device_token, "title": title, "body": body,
        })

    def broadcast(self, topic, title, body):
        return self._exec("send_topic_broadcast", {
            "topic": topic, "title": title, "body": body,
        })


class _SlackAccessor(_ServiceAccessor):
    def message(self, channel, text):
        return self._exec("send_message", {"channel": channel, "text": text})

    def create_channel(self, name, topic=""):
        return self._exec("create_channel", {"channel_name": name, "topic": topic})


class _StripeAccessor(_ServiceAccessor):
    def checkout(self, amount, product, success_url):
        return self._exec("create_checkout_session", {
            "amount": amount, "product_name": product, "success_url": success_url,
        })

    def payment_link(self, price_id):
        return self._exec("create_payment_link", {"price_id": price_id})


class _AiAccessor(_ServiceAccessor):
    def complete(self, prompt, model="claude-sonnet", max_tokens=1000):
        return self._exec("simple_completion", {
            "prompt": prompt, "model": model, "max_tokens": max_tokens,
        })

    def chat(self, messages, model="claude-sonnet"):
        return self._exec("chat_completion", {"messages": messages, "model": model})


class _WorkflowAccessor(_ServiceAccessor):
    def run(self, workflow_id, **input_data):
        return self._exec("run_workflow", {
            "workflow_id": workflow_id, "input": input_data,
        })

    def validate(self, workflow_id):
        return self._exec("validate_workflow", {"workflow_id": workflow_id})


class _OtpAccessor(_ServiceAccessor):
    def send(self, to, channel="sms", purpose="login"):
        return self._exec("send_otp", {
            "channel": channel, "recipient": to, "purpose": purpose,
        })


# ═══════════════════════════════════════════════════════════════════
# ServiceLib — main client
# ═══════════════════════════════════════════════════════════════════

class ServiceLib:
    """Thin client for Supero services + event triggers.

    Usage:
        sl = ServiceLib.from_env()

        # Event trigger (looks up binding, runs configured workflow):
        sl.trigger("@create:order", {"uuid": "...", "record": {...}})

        # Direct service call:
        sl.email.send("user@x.com", "Hi", body_html="<p>Hello</p>")

        # Direct workflow (skip event binding lookup):
        sl.run_workflow("my_workflow", order_uuid="...", amount=99)
    """

    def __init__(
        self,
        api_url="",
        api_key="",
        domain="",
        project_uuid="",
        project_name="",  # [PROJECT_UUID_LAZY_RESOLVE_v1]
        config_ttl_seconds=_DEFAULT_CONFIG_TTL_SECONDS,
        logger=None,
    ):
        self.api_url = (_strip_env(api_url) or "https://api.supero.dev").rstrip("/")
        self.api_key = _strip_env(api_key)
        self.domain = _strip_env(domain)
        self.project_uuid = _strip_env(project_uuid)

        self.project_name = _strip_env(project_name)  # [PROJECT_UUID_LAZY_RESOLVE_v1]

        self._config_ttl = config_ttl_seconds
        self._config_cache = None          # {"event_bindings": [...]} or {}
        self._config_cache_expires = 0.0
        self._config_lock = threading.Lock()

        self._http = None  # v4: lazy PlatformClient
        self._logger = logger or self._default_logger
        self._accessors = {}  # lazy cache of typed accessors

        self._txn_lock = threading.Lock()  # v1.6.0 — singleton lock for transactional
    # ── Typed accessors (lazy) ─────────────────────────────────────

    def _accessor(self, attr, cls, service_id):
        if attr not in self._accessors:
            self._accessors[attr] = cls(self, service_id)
        return self._accessors[attr]

    @property
    def email(self):      return self._accessor("email", _EmailAccessor, "email")
    @property
    def email_smtp(self): return self._accessor("email_smtp", _EmailAccessor, "email_smtp")
    @property
    def sms(self):        return self._accessor("sms", _SmsAccessor, "sms")
    @property
    def whatsapp(self):   return self._accessor("whatsapp", _WhatsAppAccessor, "whatsapp")
    @property
    def push(self):       return self._accessor("push", _PushAccessor, "push_notification")
    @property
    def slack(self):      return self._accessor("slack", _SlackAccessor, "slack")
    @property
    def stripe(self):     return self._accessor("stripe", _StripeAccessor, "stripe_checkout")
    @property
    def ai(self):         return self._accessor("ai", _AiAccessor, "ai")
    @property
    def workflow(self):   return self._accessor("workflow", _WorkflowAccessor, "workflows")
    @property
    def otp(self):        return self._accessor("otp", _OtpAccessor, "auth_otp")


    # ── Transactional services (v1.6.0) ─────────────────────────────

    @property
    def transactional(self):
        """The TransactionalClient — engine for the 17 platform services.

        Use this for low-level work or to register schema extensions:

            sl.transactional.register_extensions({
                "task": "myapp:project_task",
                "cart": ("myapp:user_cart", "myapp:user_cart_item"),
                ...
            })

        Most callers should use the per-service accessors instead:
        sl.task, sl.cart, sl.payment, etc.

        Thread-safe: under concurrent first-touch, the lock guarantees
        all callers see the same singleton (so register_extensions()
        and per-service accessors agree on one registry).
        """
        existing = self._accessors.get("transactional")
        if existing is not None:
            return existing
        if TransactionalClient is None:
            self._logger("warning",
                "TransactionalClient unavailable — install/import "
                "supero.transactional to enable transactional services")
            return None
        with self._txn_lock:
            existing = self._accessors.get("transactional")
            if existing is not None:
                return existing
            client = TransactionalClient(self)
            self._accessors["transactional"] = client
            return client

    def _txn_accessor(self, attr, cls):
        """Lazy-build a per-service accessor backed by the transactional engine.

        Thread-safe via the same lock pattern as `transactional`. Accessor
        classes are stateless wrappers, so even if two threads race past
        the fast-path check the only cost is a discarded extra instance —
        but the lock makes the cache deterministically singleton.
        """
        existing = self._accessors.get(attr)
        if existing is not None:
            return existing
        tx = self.transactional
        if tx is None:
            return None
        with self._txn_lock:
            existing = self._accessors.get(attr)
            if existing is not None:
                return existing
            inst = cls(tx)
            self._accessors[attr] = inst
            return inst

    @property
    def refs(self):
        """RefClient — record-level reference operations.

        References are first-class platform primitives separate from
        attribute fields. Used to attach catalog records (customer,
        address, product) to records under transactional services.

        Usage:

            sl.refs.add(source_type="myapp:b2b_cart", source_uuid=cart_id,
                        ref_name="myapp:customer", target_uuid=cust_id)
            sl.refs.list(record, "customer")
            sl.refs.has_ref(record, "customer", cust_id)
            sl.refs.re_attach_after_checkout(
                cart_record, order_uuid, "myapp:b2b_order",
                ("myapp:customer", "myapp:shipping_address"),
            )

        Thread-safe.
        """
        existing = self._accessors.get("refs")
        if existing is not None:
            return existing
        if RefClient is None:
            self._logger("warning",
                "RefClient unavailable — install/import supero.transactional")
            return None
        with self._txn_lock:
            existing = self._accessors.get("refs")
            if existing is not None:
                return existing
            inst = RefClient(self)
            self._accessors["refs"] = inst
            return inst

    @property
    def task(self):                return self._txn_accessor("task", _T_Task)
    @property
    def ticket(self):              return self._txn_accessor("ticket", _T_Ticket)
    @property
    def comment(self):             return self._txn_accessor("comment", _T_Comment)
    @property
    def attachment(self):          return self._txn_accessor("attachment", _T_Attachment)
    @property
    def feedback(self):            return self._txn_accessor("feedback", _T_Feedback)
    @property
    def membership(self):          return self._txn_accessor("membership", _T_Membership)
    @property
    def notification(self):        return self._txn_accessor("notification", _T_Notification)
    @property
    def payment(self):             return self._txn_accessor("payment", _T_Payment)
    @property
    def cart(self):                return self._txn_accessor("cart", _T_Cart)
    @property
    def order(self):               return self._txn_accessor("order", _T_Order)
    @property
    def booking(self):             return self._txn_accessor("booking", _T_Booking)
    @property
    def appointment(self):         return self._txn_accessor("appointment", _T_Appointment)
    @property
    def recurring_plan(self):      return self._txn_accessor("recurring_plan", _T_RecurringPlan)
    @property
    def approval(self):            return self._txn_accessor("approval", _T_Approval)
    @property
    def inventory(self):           return self._txn_accessor("inventory", _T_Inventory)
    @property
    def loyalty_points(self):      return self._txn_accessor("loyalty_points", _T_LoyaltyPoints)
    @property
    def document_signature(self):  return self._txn_accessor("document_signature", _T_DocumentSignature)

    # ── v4: Shared HTTP client ─────────────────────────────────────

    def _get_http(self):
        """Lazy-construct the shared PlatformClient.

        Returns None if PlatformClient couldn't be imported (graceful
        degradation — ServiceLib still works, just without full SDK
        integration).
        """
        if self._http is not None:
            return self._http
        if PlatformClient is None:
            return None
        if not self.api_key:
            self._logger("warning", "PlatformClient: no SUPERO_API_KEY")
            return None
        try:
            self._http = PlatformClient(
                base_url=self.api_url,
                api_key=self.api_key,
                timeout=30,
            )
            return self._http
        except Exception as e:
            self._logger("warning", f"PlatformClient init failed: {e}")
            return None

    # ── v4: CRUD accessor (via PlatformClient) ─────────────────────

    @property
    def crud(self):
        """Minimal CRUD surface — .crud.get(type, uuid) returns full record.

        Not a full CrudManager — that's the application SDK. This is the
        infrastructure-minimal surface server.py uses to enrich event
        payloads with fetched records.
        """
        if "crud" not in self._accessors:
            self._accessors["crud"] = _CrudAccessor(self)
        return self._accessors["crud"]

    # ── Factory ────────────────────────────────────────────────────

    @classmethod
    def from_env(cls, env=None):
        """Build a ServiceLib from environment variables.

        env: optional dict (defaults to os.environ). Useful for tests.
        """
        env = env if env is not None else os.environ
        return cls(
            api_url=env.get("SUPERO_URL", ""),
            api_key=env.get("SUPERO_API_KEY", ""),
            domain=env.get("SUPERO_DOMAIN", ""),
            project_uuid=env.get("SUPERO_PROJECT_UUID", ""),
            project_name=env.get("SUPERO_PROJECT", ""),  # [PROJECT_UUID_LAZY_RESOLVE_v1]
        )

    # ── Logging ────────────────────────────────────────────────────

    @staticmethod
    def _default_logger(level, msg):
        """Default logger — writes to stderr with a prefix."""
        prefix = {
            "info": "  ·",
            "warning": "  ⚠",
            "error": "  ✗",
            "success": "  ✓",
        }.get(level, "  ·")
        try:
            print(f"{prefix} [service_lib] {msg}", file=sys.stderr)
        except Exception:
            pass  # never let logging itself break something

    # ── Generic service call ──────────────────────────────────────

    # [PROJECT_UUID_LAZY_RESOLVE_v1]

    def _ensure_project_uuid(self):

        """Lazy-resolve project_uuid from project_name on first use.

    

        Mirrors the JS SDK's _svc fallback chain. If SUPERO_PROJECT_UUID

        is set, returns it directly. Otherwise, if SUPERO_PROJECT (name)

        is set, queries the platform for the project's UUID once and

        caches it on the instance.

        Returns the empty string if neither is available — exec() will

        then omit project_uuid from the payload (legacy behavior).

        """

        if self.project_uuid:

            return self.project_uuid

        if not getattr(self, 'project_name', None):

            return ''

        # Resolve once via list-bulk filter on project name.

        if not self.domain:

            self._logger('warning',

                'cannot resolve project_uuid: SUPERO_DOMAIN not set')

            return ''

        http = self._get_http() if hasattr(self, '_get_http') else self._http

        if http is None:

            return ''

        try:

            body = {

                "type": "project",

                "filters": {"name": self.project_name},

                "limit": 1,

            }

            resp = http.post(

                f"/api/v1/crud/{self.domain}/list-bulk", json=body)

            records = (resp or {}).get('results', [])

            if records and records[0].get('uuid'):

                self.project_uuid = records[0]['uuid']

                self._logger('info',

                    f'resolved project_uuid from project_name '

                    f'{self.project_name!r} -> {self.project_uuid}; '

                    f'set SUPERO_PROJECT_UUID in .env to skip this lookup')

                return self.project_uuid

            self._logger('warning',

                f'project {self.project_name!r} not found in domain '

                f'{self.domain!r}')

            return ''

        except Exception as e:

            self._logger('warning',

                f'project_uuid resolution failed: {e}')

            return ''



    def exec(self, service_id, operation, input_data):
        """POST /api/v1/services/execute with X-API-Key auth.

        Returns parsed JSON dict on success, None on any failure.
        Never raises — callers shouldn't need to wrap in try/except.
        """
        if not self.api_key:
            self._logger("warning",
                f"exec({service_id}.{operation}): SUPERO_API_KEY not set")
            return None
        if not self.domain:
            self._logger("warning",
                f"exec({service_id}.{operation}): SUPERO_DOMAIN not set")
            return None

        payload = {
            "service_id": service_id,
            "operation": operation,
            "input": input_data or {},
            "domain": self.domain,
        }
        # [PROJECT_UUID_LAZY_RESOLVE_v1]
        _puuid = self._ensure_project_uuid()
        if _puuid:
            payload["project_uuid"] = _puuid

        http = self._get_http()
        if http is None:
            return None
        try:
            return http.post("/api/v1/services/execute", json=payload)
        except Exception as e:
            self._logger(
                "warning",
                f"exec({service_id}.{operation}) failed: {e}",
            )
            return None

    def run_workflow(self, workflow_id, **input_data):
        """Direct workflow invocation (no event lookup).

        Use when you already know the workflow_id. For event-driven
        invocations, use trigger() instead.
        """
        return self.exec("workflows", "run_workflow", {
            "workflow_id": workflow_id,
            "input": input_data,
        })

    # ── Trigger (the event → workflow bridge) ──────────────────────

    def trigger(self, event, payload=None):
        """Fire an event. Looks up binding, runs workflow if matched.

        Fire-and-forget semantics:
          - Returns result dict on success
          - Returns None when no binding exists (silent no-op)
          - Returns None on any error (never raises)

        Event format: "@signup", "@create:order", etc.
        Payload: any dict; workflow input_map cherry-picks fields.
        """
        if not event:
            return None

        # Wrap the entire body — including binding lookup and payload
        # resolution — so that no internal failure (config fetch error,
        # malformed binding, resolution bug) can ever propagate up to
        # the caller. trigger() being never-raise is a hard contract
        # that server.py hooks depend on.
        try:
            binding = self._find_binding(event)
            if not binding:
                self._logger("debug", f"trigger({event}): no binding")
                return None

            workflow_id = binding.get("workflow_id")
            if not workflow_id:
                self._logger("warning",
                    f"trigger({event}): binding missing workflow_id")
                return None

            input_map = binding.get("input_map") or {}
            resolved_input = _resolve_input_map(input_map, payload or {})

            self._logger("success",
                f"trigger({event}) → {workflow_id} "
                f"input_keys={sorted(resolved_input.keys())}")

            return self.exec("workflows", "run_workflow", {
                "workflow_id": workflow_id,
                "input": resolved_input,
                "trigger_source": f"event:{event}",
            })
        except Exception as e:
            self._logger("warning", f"trigger({event}) unexpected error: {e}")
            return None

    def _find_binding(self, event):
        """First-match lookup of event in cached workflow config."""
        cfg = self._get_cached_config()
        bindings = (cfg or {}).get("event_bindings") or []
        for b in bindings:
            if b.get("event") == event:
                return b
        return None

    # ── Config fetch + cache ───────────────────────────────────────

    def _get_cached_config(self):
        """Return workflow service config_data, fetching if expired."""
        now = time.time()
        with self._config_lock:
            if (self._config_cache is not None
                    and now < self._config_cache_expires):
                return self._config_cache
            fresh = self._fetch_config()
            self._config_cache = fresh or {}
            self._config_cache_expires = now + self._config_ttl
            return self._config_cache

    def _fetch_config(self):
        """GET /api/v1/services/workflows/config → config_data dict.

        Returns {} on any error (no bindings = silent no-op behavior).
        """
        if not self.api_key or not self.domain:
            return {}
        http = self._get_http()
        if http is None:
            return {}
        try:
            body = http.get("/api/v1/services/workflows/config")
            if isinstance(body, dict):
                return body.get("config_data") or {}
            return {}
        except Exception as e:
            self._logger("warning", f"config fetch failed: {e}")
            return {}

    def refresh_config(self):
        """Force-refresh the cached config on next call."""
        with self._config_lock:
            self._config_cache = None
            self._config_cache_expires = 0.0


# ═══════════════════════════════════════════════════════════════════
# Module-level singleton (for convenience in server.py hooks)
# ═══════════════════════════════════════════════════════════════════

_default_instance = None
_default_lock = threading.Lock()


def default():
    """Get (or create) the process-wide ServiceLib singleton from env."""
    global _default_instance
    with _default_lock:
        if _default_instance is None:
            _default_instance = ServiceLib.from_env()
        return _default_instance


def reset_default():
    """Clear the singleton. Useful for tests or env reloads."""
    global _default_instance
    with _default_lock:
        _default_instance = None


# ═══════════════════════════════════════════════════════════════════
# Backward-compat Services shim
#
# Old code:
#     from supero.service_lib import Services
#     svc = Services(session, base_url, domain)
#     svc.email.send(...)
#
# session arg is ignored (service_lib uses urllib, not sessions).
# API key and project_uuid come from env vars.
# ═══════════════════════════════════════════════════════════════════

class Services(ServiceLib):
    """Backward-compat: Services(session, base_url, domain).

    session arg is ignored (API preserved for signature compat).
    """

    def __init__(self, session, base_url, domain):
        super().__init__(
            api_url=base_url,
            api_key=os.environ.get("SUPERO_API_KEY", ""),
            domain=domain,
            project_uuid=os.environ.get("SUPERO_PROJECT_UUID", ""),
        )
        # session deliberately ignored
