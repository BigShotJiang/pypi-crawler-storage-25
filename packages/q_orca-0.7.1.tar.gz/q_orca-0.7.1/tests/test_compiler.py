"""Tests for Q-Orca compilers (Mermaid, QASM, Qiskit)."""

import pytest

from q_orca.parser.markdown_parser import parse_q_orca_markdown
from q_orca.compiler.mermaid import compile_to_mermaid
from q_orca.compiler.qasm import compile_to_qasm
from q_orca.compiler.qiskit import compile_to_qiskit, QSimulationOptions
from tests.fixtures.effect_strings import EFFECT_STRING_CASES


def _machine(source: str):
    return parse_q_orca_markdown(source).file.machines[0]


class TestMermaidCompiler:
    def test_produces_state_diagram(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "stateDiagram-v2" in output

    def test_contains_states(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "|00>" in output
        assert "|ψ>" in output

    def test_contains_initial_transition(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "[*] -->" in output

    def test_contains_final_transitions(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "--> [*]" in output

    def test_contains_event_labels(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "prepare_H" in output
        assert "entangle" in output
        assert "measure_done" in output

    def test_contains_guard_labels(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "prob_collapse" in output

    def test_contains_verification_note(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_mermaid(machine)
        assert "Verification Rules" in output

    def test_minimal_machine(self, minimal_source):
        machine = _machine(minimal_source)
        output = compile_to_mermaid(machine)
        assert "stateDiagram-v2" in output
        assert "[*] -->" in output
        assert "--> [*]" in output


class TestQASMCompiler:
    def test_produces_openqasm(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_qasm(machine)
        assert "OPENQASM 3.0" in output

    def test_declares_qubits(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_qasm(machine)
        assert "qubit[" in output

    def test_contains_hadamard_gate(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_qasm(machine)
        assert "h q[0]" in output

    def test_contains_cnot_gate(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_qasm(machine)
        assert "cx q[0], q[1]" in output

    def test_contains_measurement(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_qasm(machine)
        assert "measure" in output

    def test_machine_name_in_comment(self, bell_source):
        machine = _machine(bell_source)
        output = compile_to_qasm(machine)
        assert "BellEntangler" in output

    def test_custom_measurement_gate_declares_bit_register(self):
        """Bug 2 regression: M(q[0]) custom measurement must emit bit[] declaration."""
        source = """\
# machine CustomMeasure

## context
| Field  | Type        | Default |
|--------|-------------|---------|
| qubits | list<qubit> | [q0]    |

## events
- init
- done

## state |0> [initial]
> Ground

## state |+>
> Superposition

## state |result> [final]
> Measured

## transitions
| Source | Event | Guard | Target   | Action  |
|--------|-------|-------|----------|---------|
| |0>    | init  |       | |+>      | do_H    |
| |+>    | done  |       | |result> | do_M    |

## actions
| Name | Signature    | Effect       |
|------|--------------|--------------|
| do_H | (qs) -> qs  | Hadamard(qs[0]) |
| do_M | (qs) -> bit | M(qs[0])     |

## verification rules
- unitarity: all gates preserve norm
"""
        machine = _machine(source)
        output = compile_to_qasm(machine)
        assert "bit[" in output, (
            "QASM output missing 'bit[' register declaration for M(q[0]) measurement action"
        )
        assert "measure" in output, (
            "QASM output missing measurement instruction for M(q[0]) action"
        )

    def test_standard_measure_still_works(self, bell_source):
        """The standard measure(...) pattern must still produce bit[] declaration."""
        source = """\
# machine StandardMeasure

## context
| Field  | Type        | Default |
|--------|-------------|---------|
| qubits | list<qubit> | [q0]    |

## events
- init
- collapse

## state |0> [initial]
> Ground

## state |result> [final]
> Measured

## transitions
| Source | Event    | Guard | Target   | Action  |
|--------|----------|-------|----------|---------|
| |0>    | init     |       | |result> | do_meas |

## actions
| Name    | Signature    | Effect            |
|---------|--------------|-------------------|
| do_meas | (qs) -> bit | measure(qs[0])    |

## verification rules
- unitarity: all gates preserve norm
"""
        machine = _machine(source)
        output = compile_to_qasm(machine)
        assert "bit[" in output


class TestInferQubitCount:
    """Tests for _infer_qubit_count function."""

    def test_n_plus_ancilla(self):
        """Machine with n control qubits + ancilla should return n + 1."""
        source = """\
# machine DeutschJozsa

## context
| Field          | Type          | Default |
|----------------|---------------|---------|
| qubits         | list<qubit>   |         |
| n              | int           | 3       |
| control_qubits | list<qubit>   | qs[0:n] |
| ancilla        | qubit         | qs[n]   |

## events
- init

## state |psi0> [initial]
> Initial

## transitions
| Source | Event | Guard | Target |
|--------|-------|-------|--------|
| |psi0> | init |       | |psi0> |

## actions
| Name | Signature | Effect |
|------|-----------|--------|
| noop | (qs) -> qs | Identity |

## verification rules
- unitarity: all gates preserve norm
"""
        from q_orca.compiler.qiskit import _infer_qubit_count
        machine = _machine(source)
        assert _infer_qubit_count(machine) == 4  # n=3 + ancilla=1

    def test_explicit_qubits_list(self):
        """Machine with explicit qubits list should return length of list."""
        source = """\
# machine CustomQubits

## context
| Field   | Type        | Default       |
|---------|-------------|---------------|
| qubits  | list<qubit> | [q0, q1, q2] |

## events
- init

## state |psi0> [initial]
> Initial

## transitions
| Source | Event | Guard | Target |
|--------|-------|-------|--------|
| |psi0> | init |       | |psi0> |

## actions
| Name | Signature | Effect |
|------|-----------|--------|
| noop | (qs) -> qs | Identity |

## verification rules
- unitarity: all gates preserve norm
"""
        from q_orca.compiler.qiskit import _infer_qubit_count
        machine = _machine(source)
        assert _infer_qubit_count(machine) == 3

    def test_bitstring_in_state_name(self):
        """Machine with bitstrings in state names should return max bitstring length."""
        source = """\
# machine BitstringMachine

## events
- init

## state |0000> [initial]
> Initial

## state |1111>
> Final

## transitions
| Source | Event | Guard | Target |
|--------|-------|-------|--------|
| |0000> | init |       | |1111> |

## actions
| Name | Signature | Effect |
|------|-----------|--------|
| noop | (qs) -> qs | Identity |

## verification rules
- unitarity: all gates preserve norm
"""
        from q_orca.compiler.qiskit import _infer_qubit_count
        machine = _machine(source)
        assert _infer_qubit_count(machine) == 4

    def test_fallback_to_one(self):
        """Machine with no context or bitstrings should default to 1."""
        source = """\
# machine MinimalNoQubits

## events
- go

## state |psi0> [initial]
> Start

## transitions
| Source | Event | Guard | Target |
|--------|-------|-------|--------|
| |psi0> | go   |       | |psi0> |

## actions
| Name | Signature | Effect |
|------|-----------|--------|
| noop | (qs) -> qs | Identity |

## verification rules
- unitarity: all gates preserve norm
"""
        from q_orca.compiler.qiskit import _infer_qubit_count
        machine = _machine(source)
        assert _infer_qubit_count(machine) == 1

    def test_n_minus_1_ancilla(self):
        """Machine with n=5 + ancilla should return 6."""
        source = """\
# machine SixQubits

## context
| Field    | Type        | Default |
|----------|-------------|---------|
| qubits   | list<qubit> |         |
| n        | int         | 5       |
| ctrl     | list<qubit> | qs[0:n] |
| ancilla  | qubit       | qs[n]   |

## events
- init

## state |psi0> [initial]
> Initial

## transitions
| Source | Event | Guard | Target |
|--------|-------|-------|--------|
| |psi0> | init |       | |psi0> |

## actions
| Name | Signature | Effect |
|------|-----------|--------|
| noop | (qs) -> qs | Identity |

## verification rules
- unitarity: all gates preserve norm
"""
        from q_orca.compiler.qiskit import _infer_qubit_count
        machine = _machine(source)
        assert _infer_qubit_count(machine) == 6  # n=5 + ancilla=1


class TestQiskitCompiler:
    def test_produces_python_script(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True)
        output = compile_to_qiskit(machine, opts)
        assert "QuantumCircuit" in output
        assert "Statevector" in output

    def test_contains_gates(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True)
        output = compile_to_qiskit(machine, opts)
        assert "qc.h(0)" in output
        assert "qc.cx(0, 1)" in output

    def test_analytic_mode(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True)
        output = compile_to_qiskit(machine, opts)
        assert "Statevector" in output
        assert "prob_dict" in output

    def test_shots_mode(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=False, shots=2048)
        output = compile_to_qiskit(machine, opts)
        assert "shots = 2048" in output
        assert "BasicSimulator" in output

    def test_shots_mode_unseeded_omits_seed_kwarg(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=False, shots=1024)
        output = compile_to_qiskit(machine, opts)
        assert "seed_simulator" not in output

    def test_shots_mode_seeded_threads_seed_kwarg(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=False, shots=1024, seed_simulator=7)
        output = compile_to_qiskit(machine, opts)
        assert "backend.run(qc_shots, shots=shots, seed_simulator=7)" in output
        assert "noisy_backend.run(qc_shots, shots=shots, seed_simulator=7)" in output

    def test_skip_qutip(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True, skip_qutip=True)
        output = compile_to_qiskit(machine, opts)
        assert "qutip" not in output.lower() or "skip" in output.lower()

    def test_qutip_uses_operator(self, bell_source):
        """Unitarity check must use Operator(qc), not qc.unitary_matrix()."""
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True, skip_qutip=False)
        output = compile_to_qiskit(machine, opts)
        assert "Operator(qc)" in output
        assert "unitary_matrix()" not in output

    def test_numpy_bools_wrapped(self, bell_source):
        """Numpy bool comparisons must be wrapped in bool() for JSON serialization."""
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True, skip_qutip=False)
        output = compile_to_qiskit(machine, opts)
        assert "bool(unitarity_error" in output
        assert "bool(schmidt_rank" in output

    def test_machine_name_in_comment(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True)
        output = compile_to_qiskit(machine, opts)
        assert "BellEntangler" in output

    def test_json_output(self, bell_source):
        machine = _machine(bell_source)
        opts = QSimulationOptions(analytic=True)
        output = compile_to_qiskit(machine, opts)
        assert "json.dumps" in output

    def test_multi_gate_effects_expanded(self):
        """Multi-gate effects (semicolon-separated) should generate all gates."""
        source = """\
# machine MultiGateTest

## context
| Field   | Type        | Default |
|---------|-------------|---------|
| qubits  | list<qubit> | [q0, q1, q2, q3] |

## events
- init
- apply

## state |s0> [initial]
> Initial

## state |s1>
> After gates

## transitions
| Source | Event | Guard | Target | Action |
|--------|-------|-------|--------|--------|
| |s0>   | init  |       | |s1>   | multi_h |

## actions
| Name     | Signature   | Effect                                |
|----------|-------------|---------------------------------------|
| multi_h  | (qs) -> qs | H(qs[0]); H(qs[1]); H(qs[2]); H(qs[3]) |

## verification rules
- unitarity: all gates preserve norm
"""
        machine = _machine(source)
        opts = QSimulationOptions(analytic=True, skip_qutip=True)
        output = compile_to_qiskit(machine, opts)
        # All 4 Hadamards should appear
        assert output.count("qc.h(0)") == 1
        assert output.count("qc.h(1)") == 1
        assert output.count("qc.h(2)") == 1
        assert output.count("qc.h(3)") == 1

    def test_multi_gate_cnot_oracle(self):
        """CNOT gates from semicolon-separated effect should all be generated."""
        source = """\
# machine BVOracle

## context
| Field   | Type        | Default |
|---------|-------------|---------|
| qubits  | list<qubit> | [q0, q1, q2, q3] |

## events
- init
- apply

## state |s0> [initial]
> Initial

## state |s1>
> After oracle

## transitions
| Source | Event | Guard | Target | Action |
|--------|-------|-------|--------|--------|
| |s0>   | init  |       | |s1>   | bv_oracle |

## actions
| Name     | Signature   | Effect                            |
|----------|-------------|-----------------------------------|
| bv_oracle | (qs) -> qs | CNOT(qs[0], qs[3]); CNOT(qs[2], qs[3]) |

## verification rules
- unitarity: all gates preserve norm
"""
        machine = _machine(source)
        opts = QSimulationOptions(analytic=True, skip_qutip=True)
        output = compile_to_qiskit(machine, opts)
        # Both CNOTs should appear
        assert "qc.cx(0, 3)" in output
        assert "qc.cx(2, 3)" in output

    def test_qubit_count_from_n_plus_ancilla(self):
        """Machine with n=3 and ancilla should produce 4 qubits."""
        source = """\
# machine BVTest

## context
| Field   | Type        | Default |
|---------|-------------|---------|
| qubits  | list<qubit> |         |
| n       | int         | 3       |
| ancilla | qubit       | qs[n]   |

## events
- init

## state |s0> [initial]
> Initial

## transitions
| Source | Event | Guard | Target |
|--------|-------|-------|--------|
| |s0>   | init  |       | |s0>   | noop |

## actions
| Name | Signature | Effect |
|------|-----------|--------|
| noop | (qs) -> qs | H(qs[0]) |

## verification rules
- unitarity: all gates preserve norm
"""
        machine = _machine(source)
        opts = QSimulationOptions(analytic=True, skip_qutip=True)
        output = compile_to_qiskit(machine, opts)
        assert "qubit_count = 4" in output
        assert "qc = QuantumCircuit(4)" in output


class TestContextAngleCompilation:
    """Verify the QASM and Qiskit backends resolve context-field angle refs."""

    SOURCE = """\
# machine CtxAngleCompile

## context
| Field  | Type        | Default |
|--------|-------------|---------|
| qubits | list<qubit> | [q0, q1] |
| gamma  | float       | 0.5     |
| beta   | float       | 0.25    |

## events
- run

## state |00> [initial]
## state |out> [final]

## transitions
| Source | Event | Guard | Target | Action  |
|--------|-------|-------|--------|---------|
| |00>   | run   |       | |out>  | rotate  |

## actions
| Name   | Signature  | Effect                                       |
|--------|------------|----------------------------------------------|
| rotate | (qs) -> qs | Rx(qs[0], gamma); RZZ(qs[0], qs[1], beta)    |
"""

    def test_qasm_emits_resolved_angle(self):
        machine = _machine(self.SOURCE)
        out = compile_to_qasm(machine)
        # Rx(gamma) → rx(0.5) on q[0]; RZZ(beta) is decomposed into
        # `cx q0,q1; rz(0.25) q[1]; cx q0,q1;`.
        assert "rx(0.5) q[0];" in out
        assert "rz(0.25) q[1];" in out

    def test_qiskit_emits_resolved_angle(self):
        machine = _machine(self.SOURCE)
        out = compile_to_qiskit(machine, QSimulationOptions(analytic=True, skip_qutip=True))
        assert "qc.rx(0.5, 0)" in out
        assert "qc.rzz(0.25, 0, 1)" in out


def _multi_controlled_source(effect: str, qubits: str = "[q0, q1, q2]") -> str:
    return f"""\
# machine MultiCtrl

## context
| Field  | Type        | Default |
|--------|-------------|---------|
| qubits | list<qubit> | {qubits} |

## events
- run

## state |s0> [initial]
> Start

## state |s1> [final]
> End

## transitions
| Source | Event | Guard | Target | Action |
|--------|-------|-------|--------|--------|
| |s0>   | run   |       | |s1>   | apply  |

## actions
| Name  | Signature   | Effect   |
|-------|-------------|----------|
| apply | (qs) -> qs  | {effect} |

## verification rules
- unitarity: all gates preserve norm
"""


class TestMultiControlledGateEmission:
    """QASM and Qiskit emission for CCZ/MCX/MCZ mirrors the CNOT/CCNOT cases."""

    # --- CCZ (two controls + one target) ---

    def test_qasm_ccz_expands_to_h_ccx_h_sandwich(self):
        source = _multi_controlled_source("CCZ(qs[0], qs[1], qs[2])")
        out = compile_to_qasm(_machine(source))
        # CCZ is emitted as `h q[t]; ccx q[c0], q[c1], q[t]; h q[t];` on one line.
        assert "h q[2]; ccx q[0], q[1], q[2]; h q[2];" in out

    def test_qiskit_ccz_expands_to_h_ccx_h_sandwich(self):
        source = _multi_controlled_source("CCZ(qs[0], qs[1], qs[2])")
        out = compile_to_qiskit(_machine(source), QSimulationOptions(analytic=True, skip_qutip=True))
        # Qiskit emits a 3-line block: pre-H, CCX, post-H. Line ordering is the
        # load-bearing assertion — swapping pre/post-H breaks the CCZ identity.
        idx_pre = out.index("qc.h(2)")
        idx_ccx = out.index("qc.ccx(0, 1, 2)")
        idx_post = out.index("qc.h(2)", idx_pre + 1)
        assert idx_pre < idx_ccx < idx_post

    # --- MCX (≥2 controls + one target) ---

    def test_qasm_mcx_emits_ctrl_n_x(self):
        source = _multi_controlled_source(
            "MCX(qs[0], qs[1], qs[2], qs[3])",
            qubits="[q0, q1, q2, q3]",
        )
        out = compile_to_qasm(_machine(source))
        assert "ctrl(3) @ x q[0], q[1], q[2], q[3];" in out

    def test_qiskit_mcx_emits_mcx_list_target(self):
        source = _multi_controlled_source(
            "MCX(qs[0], qs[1], qs[2], qs[3])",
            qubits="[q0, q1, q2, q3]",
        )
        out = compile_to_qiskit(_machine(source), QSimulationOptions(analytic=True, skip_qutip=True))
        assert "qc.mcx([0, 1, 2], 3)" in out

    # --- MCZ (H-sandwich around MCX) ---

    def test_qasm_mcz_expands_to_h_ctrl_n_x_h_sandwich(self):
        source = _multi_controlled_source(
            "MCZ(qs[0], qs[1], qs[2], qs[3])",
            qubits="[q0, q1, q2, q3]",
        )
        out = compile_to_qasm(_machine(source))
        assert "h q[3]; ctrl(3) @ x q[0], q[1], q[2], q[3]; h q[3];" in out

    def test_qiskit_mcz_expands_to_h_mcx_h_sandwich(self):
        source = _multi_controlled_source(
            "MCZ(qs[0], qs[1], qs[2], qs[3])",
            qubits="[q0, q1, q2, q3]",
        )
        out = compile_to_qiskit(_machine(source), QSimulationOptions(analytic=True, skip_qutip=True))
        idx_pre = out.index("qc.h(3)")
        idx_mcx = out.index("qc.mcx([0, 1, 2], 3)")
        idx_post = out.index("qc.h(3)", idx_pre + 1)
        assert idx_pre < idx_mcx < idx_post

    # --- Shots branch transpiles against a fixed basis ---

    def test_qiskit_shots_branch_transpiles_for_mcx(self):
        source = _multi_controlled_source(
            "MCX(qs[0], qs[1], qs[2], qs[3])",
            qubits="[q0, q1, q2, q3]",
        )
        out = compile_to_qiskit(_machine(source), QSimulationOptions(analytic=False, shots=1024, skip_qutip=True))
        # BasicSimulator does not run `mcx` natively, so the shots script must
        # transpile to a fixed basis before simulating.
        assert "transpile" in out
        assert "basis_gates=_basis" in out


class TestCSWAPGateEmission:
    """CSWAP (Fredkin) is the odd 3-qubit gate: 1 control + 2 swap targets.
    It was in `KNOWN_UNITARY_GATES` and the README gate table but had no
    compiler test — a documentation-without-test asymmetry flagged by PR #14
    QA. These tests close the loop.
    """

    def test_qasm_cswap_emits_cswap_with_ctrl_and_two_targets(self):
        source = _multi_controlled_source("CSWAP(qs[0], qs[1], qs[2])")
        out = compile_to_qasm(_machine(source))
        assert "cswap q[0], q[1], q[2];" in out

    def test_qiskit_cswap_emits_cswap_with_ctrl_and_two_targets(self):
        source = _multi_controlled_source("CSWAP(qs[0], qs[1], qs[2])")
        out = compile_to_qiskit(_machine(source), QSimulationOptions(analytic=True, skip_qutip=True))
        assert "qc.cswap(0, 1, 2)" in out


def _polysemy_source(action_cells: list[str], n_qubits: int = 3) -> str:
    """Build a linear-chain machine with one parametric action `query_concept`
    and one parametric action `rotate` invoked at each transition.

    ``action_cells`` is a list of Action-cell strings placed on successive
    transitions, allowing each test to vary the argument expressions.
    """
    qubits = ", ".join(f"q{i}" for i in range(n_qubits))
    events = "\n".join(f"- e{i}" for i in range(len(action_cells)))
    states = ["## state |s0> [initial]"] + [
        f"## state |s{i}>" for i in range(1, len(action_cells))
    ] + [f"## state |s{len(action_cells)}> [final]"]
    transitions = "\n".join(
        f"| |s{i}> | e{i} |  | |s{i + 1}> | {cell} |"
        for i, cell in enumerate(action_cells)
    )
    return f"""# machine Polysemy

## context
| Field  | Type        | Default      |
|--------|-------------|--------------|
| qubits | list<qubit> | [{qubits}]   |

## events
{events}

{chr(10).join(states)}

## transitions
| Source | Event | Guard | Target | Action |
|--------|-------|-------|--------|--------|
{transitions}

## actions
| Name          | Signature                | Effect           |
|---------------|--------------------------|------------------|
| query_concept | (qs, c: int) -> qs       | Hadamard(qs[c])  |
| rotate        | (qs, theta: angle) -> qs | Rx(qs[0], theta) |
"""


class TestParametricActionExpansion:
    """Per-call-site expansion (Section 5). A parametric action SHALL emit
    one independent gate sequence per invoking transition, with bound
    argument values substituted into the template at compile time."""

    def test_qasm_twelve_call_sites_emit_independent_gate_sequences(self):
        # Expand to 3 qubits × 4 concepts each, 12 total call sites. Both
        # arities (12) and range (0..11 mod 3) match the polysemantic-12
        # demo's shape.
        action_cells = [f"query_concept({i % 3})" for i in range(12)]
        source = _polysemy_source(action_cells, n_qubits=3)
        out = compile_to_qasm(_machine(source))
        # Each of qubits 0, 1, 2 gets 4 Hadamards → 4 `h q[0]`, etc.
        assert out.count("h q[0];") == 4
        assert out.count("h q[1];") == 4
        assert out.count("h q[2];") == 4

    def test_qiskit_angle_parameter_substituted_into_rotation(self):
        source = _polysemy_source(["rotate(pi/4)"], n_qubits=1)
        out = compile_to_qiskit(_machine(source), QSimulationOptions(analytic=True, skip_qutip=True))
        # pi/4 ≈ 0.7853981633974483 — the exact repr expand_action_call emits
        assert "qc.rx(0.7853981633974483, 0)" in out

    def test_mermaid_label_uses_source_form_call_text(self):
        source = _polysemy_source(["query_concept(2)"], n_qubits=3)
        out = compile_to_mermaid(_machine(source))
        # The bare action name MUST NOT leak through when the transition
        # carries a call form — the source text is what the user wrote.
        assert "/ query_concept(2)" in out

    def test_mermaid_label_falls_back_to_bare_action_name(self):
        # Non-parametric actions keep their bare-name display.
        source = """# machine Bare
## context
| Field  | Type        | Default |
|--------|-------------|---------|
| qubits | list<qubit> | [q0]    |

## events
- go

## state |s0> [initial]
## state |s1> [final]

## transitions
| Source | Event | Guard | Target | Action |
|--------|-------|-------|--------|--------|
| |s0>   | go    |       | |s1>   | apply_h |

## actions
| Name    | Signature  | Effect          |
|---------|------------|-----------------|
| apply_h | (qs) -> qs | Hadamard(qs[0]) |
"""
        out = compile_to_mermaid(_machine(source))
        assert "/ apply_h" in out

    def test_qasm_mixed_parametric_and_bare_actions_coexist(self):
        source = """# machine Mixed
## context
| Field  | Type        | Default      |
|--------|-------------|--------------|
| qubits | list<qubit> | [q0, q1, q2] |

## events
- e0
- e1

## state |s0> [initial]
## state |s1>
## state |s2> [final]

## transitions
| Source | Event | Guard | Target | Action |
|--------|-------|-------|--------|--------|
| |s0>   | e0    |       | |s1>   | apply_h |
| |s1>   | e1    |       | |s2>   | query_concept(2) |

## actions
| Name          | Signature          | Effect          |
|---------------|--------------------|-----------------|
| apply_h       | (qs) -> qs         | Hadamard(qs[0]) |
| query_concept | (qs, c: int) -> qs | Hadamard(qs[c]) |
"""
        out = compile_to_qasm(_machine(source))
        # Bare action emits its fixed gate once; parametric action emits
        # its expanded gate once — no cross-contamination.
        assert "h q[0];" in out
        assert "h q[2];" in out


class TestExpandActionCallSubscriptScope:
    """`_SUBSCRIPT_RE` is intentionally narrowed to `qs[...]` so non-qubit
    subscripts (e.g. classical `bits[c]`) are never rewritten by parametric
    expansion, even when the int-parameter name happens to appear inside
    them. Pins task 3.1.
    """

    def test_classical_bits_subscript_is_not_substituted(self):
        from q_orca.ast import (
            ActionParameter,
            BoundArg,
            QActionSignature,
        )
        from q_orca.compiler.parametric import expand_action_call

        action = QActionSignature(
            name="correct",
            parameters=[ActionParameter(name="c", type="int")],
            effect="if bits[c] == 1: X(qs[c])",
        )
        out = expand_action_call(action, [BoundArg(name="c", value=0)])
        # qs[c] gets the int substitution; bits[c] is left alone.
        assert "X(qs[0])" in out
        assert "bits[c]" in out
        assert "bits[0]" not in out


class TestComputeConceptGram:
    """Covers the `compute_concept_gram` analysis helper (Section 2 of
    add-polysemantic-clusters)."""

    def _make_machine(
        self,
        sig: str,
        effect: str,
        calls: list[str],
        action_name: str = "query_concept",
    ):
        """Build a minimal machine with N call sites to a parametric action.

        ``calls`` is a list of argument-literal strings (e.g. "0.1, 0.2, 0.3").
        """
        transitions = []
        states = ["## state idle [initial]"]
        for i, args in enumerate(calls):
            state_name = f"q{i}"
            states.append(f"## state {state_name}")
            transitions.append(
                f"| idle | ev{i} | | {state_name} | {action_name}({args}) |"
            )
        states.append("## state done [final]")
        events = "\n".join(f"- ev{i}" for i in range(len(calls))) or "- noop"
        trans_body = "\n".join(transitions) or (
            "| idle | noop | | done |  |"
        )
        source = (
            "# machine M\n\n"
            "## context\n"
            "| Field  | Type        | Default      |\n"
            "|--------|-------------|--------------|\n"
            "| qubits | list<qubit> | [q0, q1, q2] |\n\n"
            "## events\n"
            f"{events}\n\n"
            + "\n\n".join(states) + "\n\n"
            "## transitions\n"
            "| Source | Event | Guard | Target | Action |\n"
            "|--------|-------|-------|--------|--------|\n"
            f"{trans_body}\n\n"
            "## actions\n"
            "| Name | Signature | Effect |\n"
            "|------|-----------|--------|\n"
            f"| {action_name} | {sig} | {effect} |\n"
        )
        result = parse_q_orca_markdown(source)
        assert result.errors == [], result.errors
        return result.file.machines[0]

    def test_happy_path_on_clusters_example(self):
        """Gram matrix of the canonical example matches the documented
        block structure."""
        import numpy as np
        from pathlib import Path

        from q_orca import compute_concept_gram

        examples_dir = Path(__file__).parent.parent / "examples"
        source = (examples_dir / "larql-polysemantic-clusters.q.orca.md").read_text()
        parsed = parse_q_orca_markdown(source)
        machine = parsed.file.machines[0]

        gram = compute_concept_gram(machine)
        assert gram.shape == (12, 12)
        assert gram.dtype == np.complex128

        np.testing.assert_allclose(np.diag(np.abs(gram)), np.ones(12), atol=1e-9)

        gsq = np.abs(gram) ** 2
        # Intra-cluster uniformity at 0.72 (cos(0)² · cos(0.4)² · cos(0.4)² ≈ 0.7197)
        for ci in range(3):
            block = gsq[ci * 4:(ci + 1) * 4, ci * 4:(ci + 1) * 4]
            off_diag = block[~np.eye(4, dtype=bool)]
            np.testing.assert_allclose(off_diag, 0.7197, atol=1e-3)
        # All inter-cluster < 0.10
        for i in range(3):
            for j in range(i + 1, 3):
                block = gsq[i * 4:(i + 1) * 4, j * 4:(j + 1) * 4]
                assert block.max() < 0.10

    def test_wrong_signature_int_parameter_raises(self):
        """An action with an int parameter (not three angles) raises."""
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, c: int) -> qs",
            "Hadamard(qs[c])",
            ["0"],
            action_name="query_concept",
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine)
        message = str(exc_info.value)
        assert "query_concept" in message
        assert "three angle" in message

    def test_missing_action_raises(self):
        """Passing a label that doesn't name a parametric action raises."""
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Ry(qs[1], b); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
            action_name="query_concept",
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine, concept_action_label="does_not_exist")
        message = str(exc_info.value)
        assert "does_not_exist" in message
        assert "query_concept" in message  # listed as hint

    def test_no_call_sites_raises(self):
        """Action exists with correct shape but has zero call sites."""
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Ry(qs[1], b); Ry(qs[2], c)",
            [],
            action_name="query_concept",
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine)
        message = str(exc_info.value)
        assert "query_concept" in message
        assert "no call sites" in message

    def test_wrong_effect_shape_with_foreign_gates_raises(self):
        # The signature shape check (3 angle params) accepts this, but the
        # effect mixes a CNOT with a single Rz — clearly not a Ry product —
        # so the formula in `compute_concept_gram` would silently emit a
        # numerically wrong matrix without the effect-structure check.
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "CNOT(qs[0], qs[1]); Rz(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine)
        message = str(exc_info.value)
        assert "query_concept" in message
        # Two segments instead of three triggers the segment-count branch.
        assert "2 gate segment" in message

    def test_wrong_effect_non_ry_segment_raises(self):
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Rz(qs[1], b); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine)
        message = str(exc_info.value)
        assert "Rz(qs[1], b)" in message
        assert "Ry(qs[i], [-]name)" in message

    def test_wrong_effect_param_qubit_mismatch_raises(self):
        # `Ry(qs[0], b)` swaps the parameter at qubit 0 (signature position
        # 0 declares `a`, not `b`). Numerically wrong: angles[i, 0] would
        # drive qs[1] instead of qs[0].
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], b); Ry(qs[1], a); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine)
        message = str(exc_info.value)
        assert "qs[0]" in message and "'b'" in message and "'a'" in message
        assert "positional alignment" in message

    def test_wrong_effect_mixed_signs_raises(self):
        # A mixed-sign effect would compute `cos((θ_i,k - θ_j,k)/2)` while
        # the actual circuit is no longer a clean preparation/inverse pair.
        from q_orca import ConceptGramConfigurationError, compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Ry(qs[1], -b); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(ConceptGramConfigurationError) as exc_info:
            compute_concept_gram(machine)
        message = str(exc_info.value)
        assert "mixes positive and negated" in message

    def test_inverse_form_effect_passes(self):
        # The inverse-preparation form (`Ry(qs[2], -c); Ry(qs[1], -b);
        # Ry(qs[0], -a)`) is the canonical query shape used by the bundled
        # `larql-polysemantic-clusters` example. It MUST pass the
        # structural check unchanged.
        from q_orca import compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[2], -c); Ry(qs[1], -b); Ry(qs[0], -a)",
            ["0.1, 0.2, 0.3"],
        )
        gram = compute_concept_gram(machine)
        assert gram.shape == (1, 1)

    def test_analytic_identity_matrix_on_zero_angles(self):
        """Multiple call sites all at angles (0, 0, 0) must produce all-ones gram."""
        import numpy as np

        from q_orca import compute_concept_gram

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Ry(qs[1], b); Ry(qs[2], c)",
            ["0, 0, 0", "0, 0, 0", "0, 0, 0"],
            action_name="query_concept",
        )
        gram = compute_concept_gram(machine)
        assert gram.shape == (3, 3)
        np.testing.assert_allclose(np.abs(gram), np.ones((3, 3)), atol=1e-9)


class TestComputeConceptGramMps:
    """Covers the `compute_concept_gram_mps` analysis helper (Section 2 of
    add-mps-concept-encoding)."""

    def _make_machine(
        self,
        sig: str,
        effect: str,
        calls: list[str],
        action_name: str = "query_concept",
        n_qubits: int = 3,
    ):
        """Build a minimal machine with N call sites to a parametric action.

        ``calls`` is a list of argument-literal strings. ``n_qubits``
        controls the size of the ``qubits`` register.
        """
        qubit_list = ", ".join(f"q{k}" for k in range(n_qubits))
        transitions = []
        states = ["## state idle [initial]"]
        for i, args in enumerate(calls):
            state_name = f"q{i}"
            states.append(f"## state {state_name}")
            transitions.append(
                f"| idle | ev{i} | | {state_name} | {action_name}({args}) |"
            )
        states.append("## state done [final]")
        events = "\n".join(f"- ev{i}" for i in range(len(calls))) or "- noop"
        trans_body = "\n".join(transitions) or (
            "| idle | noop | | done |  |"
        )
        source = (
            "# machine M\n\n"
            "## context\n"
            "| Field  | Type        | Default      |\n"
            "|--------|-------------|--------------|\n"
            f"| qubits | list<qubit> | [{qubit_list}] |\n\n"
            "## events\n"
            f"{events}\n\n"
            + "\n\n".join(states) + "\n\n"
            "## transitions\n"
            "| Source | Event | Guard | Target | Action |\n"
            "|--------|-------|-------|--------|--------|\n"
            f"{trans_body}\n\n"
            "## actions\n"
            "| Name | Signature | Effect |\n"
            "|------|-----------|--------|\n"
            f"| {action_name} | {sig} | {effect} |\n"
        )
        result = parse_q_orca_markdown(source)
        assert result.errors == [], result.errors
        return result.file.machines[0]

    def _staircase_inverse(self, n: int) -> str:
        """Canonical inverse-form CNOT-staircase effect on n qubits."""
        param_names = "abcdefgh"[:n]
        # Inverse: Ry(qs[n-1], -p_{n-1}); CNOT(n-2, n-1); ...;
        # Ry(qs[1], -p_1); CNOT(0, 1); Ry(qs[0], -p_0).
        segs: list[str] = []
        for k in range(n - 1, -1, -1):
            segs.append(f"Ry(qs[{k}], -{param_names[k]})")
            if k > 0:
                segs.append(f"CNOT(qs[{k - 1}], qs[{k}])")
        return "; ".join(segs)

    def _staircase_prep(self, n: int) -> str:
        """Canonical preparation-form CNOT-staircase effect on n qubits."""
        param_names = "abcdefgh"[:n]
        segs: list[str] = []
        for k in range(n):
            segs.append(f"Ry(qs[{k}], {param_names[k]})")
            if k < n - 1:
                segs.append(f"CNOT(qs[{k}], qs[{k + 1}])")
        return "; ".join(segs)

    def test_zero_angles_identity_gram(self):
        """Zero angles → all Ry rotations are identity → CNOTs stay
        controlled by |0⟩ → final state is |0...0⟩ → all-ones Gram."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_prep(3),
            ["0, 0, 0", "0, 0, 0", "0, 0, 0"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (3, 3)
        assert gram.dtype == np.complex128
        np.testing.assert_allclose(np.abs(gram), np.ones((3, 3)), atol=1e-9)

    def test_diagonal_is_unit_modulus(self):
        """Self-overlap |⟨c_i|c_i⟩| = 1 for any angle tuple."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_prep(3),
            ["0.7, 1.3, 2.1", "0.4, 0.5, 0.6", "1.5707963, 0.0, 1.5707963"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        np.testing.assert_allclose(np.abs(np.diag(gram)), np.ones(3), atol=1e-9)

    def test_inverse_form_effect_passes(self):
        """The inverse (query) form is the canonical shape used by the
        upcoming hierarchical example. It MUST pass the structural check."""
        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            ["0.1, 0.2, 0.3"],
        )
        gram = compute_concept_gram_mps(machine)
        assert gram.shape == (1, 1)

    def test_prep_form_effect_passes(self):
        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_prep(3),
            ["0.1, 0.2, 0.3"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (1, 1)

    def test_n2_register_works(self):
        """Helper accepts any register size, not just n=3."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        # Two call sites at angles (0, π) and (π, 0). Both produce
        # computational-basis states that are orthogonal:
        #   prep(0, π): Ry(0)|0⟩ ⊗ |0⟩ → CNOT(0,1) → |00⟩ → Ry(π) on qs[1] → |01⟩
        #   prep(π, 0): Ry(π)|0⟩ → |1⟩, CNOT(0,1) → |11⟩, Ry(0) on qs[1] → |11⟩
        machine = self._make_machine(
            "(qs, a: angle, b: angle) -> qs",
            self._staircase_prep(2),
            [f"0, {np.pi}", f"{np.pi}, 0"],
            action_name="prepare_concept",
            n_qubits=2,
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (2, 2)
        np.testing.assert_allclose(np.abs(np.diag(gram)), np.ones(2), atol=1e-9)
        # Off-diagonal: ⟨01|11⟩ = 0
        assert abs(gram[0, 1]) < 1e-9
        assert abs(gram[1, 0]) < 1e-9

    def test_wrong_signature_int_parameter_raises(self):
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, c: int) -> qs",
            "Hadamard(qs[c])",
            ["0"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        assert "query_concept" in message
        assert "all parameters of type `angle`" in message

    def test_wrong_signature_non_angle_param_raises(self):
        """A non-angle parameter type fails the signature check. (The
        loosened convention accepts >= 1 parameters of any name, but all
        of them must be of type `angle`.)"""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, n: int) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Ry(qs[1], b); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], a)",
            ["0.1, 0.2, 1"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        assert "all parameters of type `angle`" in message

    def test_call_site_wrong_arity_raises(self):
        """Defensive guard for callers that build a `QMachineDef`
        programmatically (bypassing the parser, which enforces arity at
        parse time). Without this guard, ragged ``bound_arguments`` reach
        the angle-matrix build and numpy raises `setting an array element
        with a sequence` — a confusing message that mentions neither the
        machine nor the helper. The helper must surface a contextful
        `MpsGramConfigurationError` instead."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            ["0.1, 0.2, 0.3", "0.4, 0.5, 0.6"],
        )
        # Truncate the second call site's bound arguments to 2, mimicking
        # a hand-built machine that sidestepped parser-level arity checks.
        machine.transitions[1].bound_arguments = (
            machine.transitions[1].bound_arguments[:2]
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        assert "query_concept" in message
        assert "2 arguments" in message
        assert "expected exactly 3" in message

    def test_missing_action_raises(self):
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(
                machine, concept_action_label="does_not_exist"
            )
        message = str(exc_info.value)
        assert "does_not_exist" in message
        assert "query_concept" in message  # listed as hint

    def test_no_call_sites_raises(self):
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            [],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        assert "query_concept" in message
        assert "no call sites" in message

    def test_non_staircase_product_state_raises(self):
        """Pure product-state effect (no CNOTs) is the rung-0 shape;
        callers must use `compute_concept_gram` for that case."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Ry(qs[1], b); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        # Three Ry segments and zero CNOTs → skeleton-shape branch.
        assert "3 Ry segment(s)" in message
        assert "0 CNOT segment(s)" in message

    def test_non_staircase_non_adjacent_cnot_raises(self):
        """A long-range CNOT between non-adjacent qubits violates the
        staircase pattern."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[2]); Ry(qs[1], b); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        assert "adjacent CNOTs" in message

    def test_non_staircase_wrong_segment_kind_raises(self):
        """A non-Ry/non-CNOT gate at a staircase position is rejected."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); Hadamard(qs[1]); Ry(qs[1], b); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        message = str(exc_info.value)
        assert "Hadamard(qs[1])" in message
        assert "CNOT(qs[i], qs[j])" in message

    def test_cross_coupled_angles_happy_path(self):
        """The canonical cross-coupled-by-sum encoding parses and produces a
        Gram that differs measurably from the same-angle product-state Gram
        (i.e., does NOT factorize)."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Ry(qs[1], a + b); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            ["0.0, -0.5, -0.35", "0.0, -0.5, 0.35", "0.0, 0.5, -0.35"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (3, 3)
        gsq = np.abs(gram) ** 2
        np.testing.assert_allclose(np.diag(gsq), np.ones(3), atol=1e-9)

        # Build the same-angle product-state Gram and confirm the cross-
        # coupled variant is structurally distinct on at least one entry.
        triples = [(0.0, -0.5, -0.35), (0.0, -0.5, 0.35), (0.0, 0.5, -0.35)]
        prod = np.zeros((3, 3))
        for i, (ai, bi, ci) in enumerate(triples):
            for j, (aj, bj, cj) in enumerate(triples):
                prod[i, j] = (
                    np.cos((ai - aj) / 2)
                    * np.cos((bi - bj) / 2)
                    * np.cos((ci - cj) / 2)
                )
        diff = np.abs(gsq - prod ** 2)
        np.fill_diagonal(diff, 0.0)
        assert diff.max() >= 0.05

    def test_single_bound_param_degenerate_linear_combination(self):
        """The strict single-bound-param staircase (the archived shape) must
        still parse — it is the degenerate one-term linear combination
        ``1·p`` and the helper SHALL produce the same Gram it produced
        before generalization."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_prep(3),
            ["0.1, 0.2, 0.3", "0.4, 0.5, 0.6"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (2, 2)
        np.testing.assert_allclose(np.abs(np.diag(gram)), np.ones(2), atol=1e-9)
        # Bare staircase factorizes — the off-diagonal must equal the
        # product-state Gram for this same set of angle triples.
        triples = [(0.1, 0.2, 0.3), (0.4, 0.5, 0.6)]
        ai, bi, ci = triples[0]
        aj, bj, cj = triples[1]
        expected = (
            np.cos((ai - aj) / 2)
            * np.cos((bi - bj) / 2)
            * np.cos((ci - cj) / 2)
        )
        np.testing.assert_allclose(abs(gram[0, 1]), abs(expected), atol=1e-9)

    def test_swapped_param_position_accepted(self):
        """A linear-combination Ry need not bind its `positionally aligned`
        parameter — `Ry(qs[0], b)` is a valid one-term linear combination
        and the helper accepts it (this was rejected pre-generalization)."""
        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], b); CNOT(qs[0], qs[1]); Ry(qs[1], a); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], c)",
            ["0.1, 0.2, 0.3"],
        )
        gram = compute_concept_gram_mps(machine)
        assert gram.shape == (1, 1)

    def test_unrecognized_angle_expression_product_raises(self):
        """A non-linear angle expression (multiplication of two parameters)
        must raise `unrecognized_angle_expression`. The parser's parametric-
        template validator already rejects such expressions, so the helper
        only sees them when a caller builds a machine programmatically;
        this test mutates a parsed action's effect string to mimic that
        bypass and exercises the helper's own structural error path."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            ["0.1, 0.2, 0.3"],
        )
        action = next(a for a in machine.actions if a.name == "query_concept")
        action.effect = (
            "Ry(qs[2], -c); CNOT(qs[1], qs[2]); Ry(qs[1], a * b); "
            "CNOT(qs[0], qs[1]); Ry(qs[0], -a)"
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        assert exc_info.value.kind == "unrecognized_angle_expression"
        message = str(exc_info.value)
        assert "a * b" in message
        assert "linear combination" in message

    def test_unrecognized_angle_expression_function_call_raises(self):
        """A non-linear angle expression with a function call (e.g.,
        ``sin(a)``) is also rejected with `unrecognized_angle_expression`.
        Same parser-bypass approach as the multiplication test."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            ["0.1, 0.2, 0.3"],
        )
        action = next(a for a in machine.actions if a.name == "query_concept")
        action.effect = (
            "Ry(qs[2], -c); CNOT(qs[1], qs[2]); Ry(qs[1], sin(a)); "
            "CNOT(qs[0], qs[1]); Ry(qs[0], -a)"
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        assert exc_info.value.kind == "unrecognized_angle_expression"
        assert "sin(a)" in str(exc_info.value)

    def test_unsupported_bond_dim_raises(self):
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            self._staircase_inverse(3),
            ["0.1, 0.2, 0.3"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine, bond_dim=4)
        message = str(exc_info.value)
        assert "bond_dim=4" in message
        assert "not yet implemented" in message

    # ------------------------------------------------------------------
    # Rz interference-knob extension (extend-mps-matcher-rz-phases).
    # The matcher accepts optional Rz phase rotations anywhere in the
    # staircase as 1-qubit interference knobs — they preserve the bond-2
    # MPS structure and feed through the analytic contraction.
    # ------------------------------------------------------------------

    def test_rz_with_zero_phase_matches_bare_staircase(self):
        """A staircase with `Rz(qs[k], phi)` and `phi=0` at every call
        site MUST produce the same Gram as the bare-staircase machine
        (Rz(0) is the identity). This is the strict backward-compat
        check for the new shape."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        triples = ["0.4, 1.1, 0.7", "0.3, -0.2, 0.5"]

        machine_with_rz = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Rz(qs[1], phi); "
            "Ry(qs[1], a + b); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            [f"{t}, 0.0" for t in triples],
            action_name="prepare_concept",
        )
        machine_bare = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); "
            "Ry(qs[1], a + b); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            triples,
            action_name="prepare_concept",
        )
        g_rz = compute_concept_gram_mps(
            machine_with_rz, concept_action_label="prepare_concept"
        )
        g_bare = compute_concept_gram_mps(
            machine_bare, concept_action_label="prepare_concept"
        )
        np.testing.assert_allclose(np.abs(g_rz), np.abs(g_bare), atol=1e-12)

    def test_rz_changes_gram_amplitude(self):
        """Two call sites with identical (a, b, c) but different `phi`
        SHALL produce an off-diagonal overlap strictly less than 1."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Rz(qs[1], phi); "
            "Ry(qs[1], a + b); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            ["0.4, 1.1, 0.7, 0.0", "0.4, 1.1, 0.7, 0.5"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        np.testing.assert_allclose(np.abs(np.diag(gram)), np.ones(2), atol=1e-9)
        assert abs(gram[0, 1]) < 1.0 - 1e-6

    def test_rz_on_zero_state_is_global_phase(self):
        """All angles 0 → register stays in |000> through Ry/CNOT, so an
        Rz(qs[k], phi) at the end only adds a global phase. Two
        concepts with phi=±θ thus have |<c_0|c_1>|² = 1 (modulus is
        invariant under global phase), even though the complex Gram
        entry has nontrivial argument."""
        import numpy as np

        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Ry(qs[1], a + b); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], b + c); Rz(qs[0], phi)",
            ["0.0, 0.0, 0.0, 0.7", "0.0, 0.0, 0.0, -0.7"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        # |<c_0|c_1>|² = 1 (only differ by a global phase factor).
        assert abs(abs(gram[0, 1]) - 1.0) < 1e-9
        # But the complex entry itself isn't real — phase = exp(i*0.7).
        assert abs(gram[0, 1].imag) > 1e-3

    def test_rz_linear_combination_angle_accepted(self):
        """An Rz with a linear-combination angle (e.g., `phi_a + phi_b`)
        SHALL parse via the same `_parse_linear_combination` path as Ry."""
        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi_a: angle, phi_b: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Rz(qs[1], phi_a + phi_b); "
            "Ry(qs[1], a + b); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            ["0.4, 1.1, 0.7, 0.1, 0.2"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (1, 1)

    def test_rz_out_of_range_qubit_raises(self):
        """An Rz on a qubit index outside the register is rejected."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Rz(qs[5], phi); "
            "Ry(qs[1], a + b); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            ["0.1, 0.2, 0.3, 0.5"],
            action_name="prepare_concept",
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(
                machine, concept_action_label="prepare_concept"
            )
        message = str(exc_info.value)
        assert "qs[5]" in message
        assert "out of range" in message

    def test_rz_in_inverse_form_rejected(self):
        """An inverse-form (query) effect with a non-trivial `Rz` is
        rejected with `kind="rz_in_inverse_form"`. Reason: the helper
        builds states by applying the effect to `|0^n>`; the inverse
        form's `Rz` lands on `|0>` and collapses to a global phase, so
        the analytic Gram would silently lose the phase axis. The
        guardrail directs the user to use the preparation form
        instead. See `tech-debt-backlog/tasks.md` §5.16."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[2], -b - c); CNOT(qs[1], qs[2]); Rz(qs[1], -phi); "
            "Ry(qs[1], -a - b); CNOT(qs[0], qs[1]); Ry(qs[0], -a)",
            ["0.1, 0.2, 0.3, 0.5"],
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(machine)
        assert exc_info.value.kind == "rz_in_inverse_form"
        message = str(exc_info.value)
        assert "Rz(qs[1], <expr>)" in message
        assert "preparation form" in message
        assert "larql-animals-interference" in message

    def test_rz_in_inverse_form_with_zero_coeffs_accepted(self):
        """A trivial `Rz` in the inverse form (all coefficients zero,
        e.g., `Rz(qs[1], a - a)`) is accepted because it is the identity
        at every call site. The guardrail only rejects non-trivial
        `Rz` segments where at least one coefficient is non-zero."""
        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle) -> qs",
            "Ry(qs[2], -b - c); CNOT(qs[1], qs[2]); Rz(qs[1], a - a); "
            "Ry(qs[1], -a - b); CNOT(qs[0], qs[1]); Ry(qs[0], -a)",
            ["0.1, 0.2, 0.3"],
        )
        gram = compute_concept_gram_mps(machine)
        assert gram.shape == (1, 1)

    def test_rz_in_preparation_form_accepted(self):
        """The companion to the inverse-form guardrail: a non-trivial
        `Rz` in the *preparation* form is fine and must NOT trigger
        `rz_in_inverse_form`. This is the canonical
        `larql-animals-interference.q.orca.md` shape."""
        from q_orca import compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Ry(qs[1], a + b); "
            "Rz(qs[1], phi); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            ["0.0, -0.5, 0.0, 0.0", "0.0, -0.5, 0.0, 1.5707963"],
            action_name="prepare_concept",
        )
        gram = compute_concept_gram_mps(
            machine, concept_action_label="prepare_concept"
        )
        assert gram.shape == (2, 2)

    def test_rz_unrecognized_angle_expression_raises(self):
        """A non-linear angle expression inside an Rz raises with the
        same `unrecognized_angle_expression` kind as Ry."""
        from q_orca import MpsGramConfigurationError, compute_concept_gram_mps

        machine = self._make_machine(
            "(qs, a: angle, b: angle, c: angle, phi: angle) -> qs",
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Ry(qs[1], a + b); "
            "CNOT(qs[1], qs[2]); Ry(qs[2], b + c)",
            ["0.1, 0.2, 0.3, 0.5"],
            action_name="prepare_concept",
        )
        action = next(
            a for a in machine.actions if a.name == "prepare_concept"
        )
        action.effect = (
            "Ry(qs[0], a); CNOT(qs[0], qs[1]); Rz(qs[1], phi * a); "
            "Ry(qs[1], a + b); CNOT(qs[1], qs[2]); Ry(qs[2], b + c)"
        )
        with pytest.raises(MpsGramConfigurationError) as exc_info:
            compute_concept_gram_mps(
                machine, concept_action_label="prepare_concept"
            )
        assert exc_info.value.kind == "unrecognized_angle_expression"
        assert "phi * a" in str(exc_info.value)


class TestSharedFixtureCompilerAdapter:
    """The Qiskit compiler's effect-string adapter must agree with the
    shared parser fixture on AST gate shape for every supported gate kind.
    """

    @pytest.mark.parametrize(
        "effect_str,angle_context,expected,notes",
        EFFECT_STRING_CASES,
        ids=[c[3] for c in EFFECT_STRING_CASES],
    )
    def test_quantum_gate_shape(self, effect_str, angle_context, expected, notes):
        from q_orca.compiler.qiskit import _parse_single_gate

        gate = _parse_single_gate(effect_str, angle_context=angle_context)
        assert gate is not None, f"{effect_str!r} returned None ({notes})"
        assert gate.kind == expected.name
        assert gate.targets == list(expected.targets)
        if expected.controls:
            assert gate.controls == list(expected.controls)
        else:
            assert not gate.controls
        if expected.parameter is None:
            assert gate.parameter is None
        else:
            assert gate.parameter == pytest.approx(expected.parameter)
        if expected.custom_name is not None:
            assert gate.custom_name == expected.custom_name
