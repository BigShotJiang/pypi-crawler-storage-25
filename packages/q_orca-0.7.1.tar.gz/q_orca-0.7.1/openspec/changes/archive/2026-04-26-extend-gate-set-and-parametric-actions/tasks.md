## 1. Multi-controlled gate set (already shipped — record as done)

- [x] 1.1 `q_orca/compiler/qiskit.py::_parse_single_gate` recognizes
      `CCX`/`CCNOT`/`Toffoli`/`CCZ` (3-arg form) and `MCX`/`MCZ`
      (≥3-arg form).
- [x] 1.2 `q_orca/compiler/qiskit.py::_gate_to_qiskit` emits `qc.ccx`
      for `CCNOT`, `qc.h(t); qc.ccx(...); qc.h(t)` for `CCZ`,
      `qc.mcx([controls], target)` for `MCX`, and the H-sandwich
      around `qc.mcx` for `MCZ`.
- [x] 1.3 `q_orca/compiler/qasm.py::_gate_to_qasm` emits `ccx` /
      `h … ccx … h` for the 3-control variants and `ctrl(N) @ x` /
      `h … ctrl(N) @ x … h` for `MCX` / `MCZ`.
- [x] 1.4 `q_orca/verifier/quantum.py::KNOWN_UNITARY_GATES` includes
      `CCZ`, `MCX`, `MCZ`.
- [x] 1.5 The Qiskit script's shots branch imports `transpile` and
      runs it over the measurement-augmented circuit with a fixed
      basis-gate list before invoking `BasicSimulator`.
- [x] 1.6 `examples/larql-gate-knn-grover.q.orca.md` exercises the
      new gate set end-to-end (4-qubit, 3-iteration Grover with
      `MCZ` on 3 controls).
- [x] 1.7 `demos/larql_gate_knn/demo.py` runs parse → verify →
      compile → simulate → decode and confirms ~96% probability
      mass on the marked state.

## 2. Multi-controlled gate set — formalize as spec

- [ ] 2.1 Land this proposal so the spec deltas in
      `specs/language/spec.md`, `specs/compiler/spec.md`, and
      `specs/verifier/spec.md` are reviewable in isolation from
      future changes.
- [x] 2.2 Add `tests/test_compiler.py` cases for CCZ/MCX/MCZ QASM and
      Qiskit emission, mirroring the existing CNOT / CCNOT cases.
      Include the H-sandwich line ordering as an explicit assertion.
- [x] 2.3 Add `tests/test_verifier.py` cases that confirm
      `unitarity` rules pass for CCZ/MCX/MCZ and that an
      `MCX(qs[c0], qs[c1], qs[c2], qs[c2])` (control = target) raises
      `CONTROL_TARGET_OVERLAP`.
- [x] 2.4 Add a regression test that runs the Grover demo machine
      through `compile_to_qiskit` + `BasicSimulator` shots and
      asserts a > 95% count on `|1010>` for 1024 shots — the same
      check the demo performs end-to-end.
- [x] 2.5 Add `MCX` / `MCZ` to the README / docs gate-set table.
- [x] 2.6 Add `tests/test_compiler.py` coverage for `CSWAP`. The gate
      is listed in `KNOWN_UNITARY_GATES` and in the README gate table
      but has no compiler or verifier test anywhere — a
      documentation-without-test asymmetry flagged in PR #14 QA.
- [x] 2.7 Tighten `MCX` / `MCZ` arity validation to parse time.
      Today the markdown parser's regex silently no-matches on
      `MCX(qs[0], qs[1])` (only 2 args) and the error surfaces late
      at Qiskit compile with a `ValueError`. Promote this to a
      structured parser error naming the action and the minimum
      arity.
- [x] 2.8 Warn on unrecognized effect strings. The markdown parser
      currently returns `None` for unknown gates (e.g. a typo like
      `MCXY(qs[0], ...)`), and the verifier silently skips the
      transition. Emit a structured warning so typos surface early
      instead of becoming silent test gaps. Cross-reference
      `openspec/changes/consolidate-gate-parser/` — the shared parser
      is the natural home for this behavior.

## 3. Parametric actions — parser

- [x] 3.1 Extend `q_orca/ast.py` with `ActionParameter(name: str,
      type: Literal["int", "angle"])` and add
      `parameters: list[ActionParameter] = []` to
      `QActionSignature`. Add `bound_arguments: list[BoundArg] | None
      = None` and `action_label: str | None = None` to
      `QTransition`.
- [x] 3.2 Extend `q_orca/parser/markdown_parser.py`'s signature
      parser to accept `(qs, name1: type1, name2: type2, ...) -> qs`.
      Reject duplicate names and unknown types with structured
      errors. Preserve the zero-parameter form as a no-op change.
      Typed-parameter grammar is opt-in via the presence of `:` in a
      parameter slot, so `(ctx) -> ctx` signatures used by classical
      context-update actions continue to parse as zero-parameter.
- [x] 3.3 Extend the same module's transitions-table parser to
      accept `name(arg1, arg2, ...)` in the Action column. Validate
      arity and per-argument type against the referenced action's
      signature. Populate `QTransition.bound_arguments` and
      `QTransition.action_label`.
- [x] 3.4 Bare-name references to a parameterized action and
      call-form references to a non-parameterized action SHALL raise
      structured errors with both the action name and the source
      line of the offending transition.
- [x] 3.5 Resolve action references in a two-pass approach: collect
      all action definitions first, then walk transitions resolving
      against the collected set, so forward references parse without
      ordering constraints.

## 4. Parametric actions — effect-string subscripts

- [x] 4.1 Extend the shared effect parser (post
      `consolidate-gate-parser`) to accept either a literal int or
      a bare identifier inside `qs[...]` subscripts. Identifier
      subscripts SHALL be valid only when a `signature_context` is
      provided that lists the parameter names in scope.
- [x] 4.2 Same change for angle slots: identifier-form angles inside
      a parametric action's effect SHALL resolve against the
      signature's `angle`-typed parameters when an
      `signature_context` is provided.
- [x] 4.3 Add an `unbound_identifier` structured error path; the
      action-definition parser uses it when a subscript or angle
      identifier is not in the signature.

## 5. Parametric actions — compiler expansion

- [x] 5.1 Add `q_orca/compiler/parametric.py::expand_action_call(action,
      bound_arguments) -> str` that returns the literal effect string
      with all parameter slots substituted. Out-of-range subscripts
      and unparseable angle substitutions SHALL raise structured
      errors carrying the bound-argument values.
- [x] 5.2 Update `q_orca/compiler/qiskit.py::_extract_gate_sequence`
      (and the parallel paths in QASM and Mermaid) to detect a
      transition with `bound_arguments is not None` and route through
      `expand_action_call` before parsing the gate sequence.
- [x] 5.3 Mermaid label generation SHALL use
      `t.action_label` when present, falling back to `t.action` for
      bare-name transitions.
- [x] 5.4 Confirm Qiskit emission for an N-call-site machine
      produces N independent gate sequences in the script (BFS visit
      order preserved) and that the basis transpile pass still runs
      correctly.

## 6. Parametric actions — verifier

- [x] 6.1 Update `q_orca/verifier/quantum.py` and
      `q_orca/verifier/dynamic.py` to enumerate transitions (not
      action definitions) when collecting gate sequences for
      checking. For each transition with bound arguments, expand and
      verify the resulting sequence; for bare-name transitions, fall
      through to the existing path.
- [x] 6.2 Add a template-only check pass that runs once per
      parametric action: signature shape, effect-string parseability,
      identifier-binding closure. Errors raised here SHALL point at
      the action's source location.
- [x] 6.3 Per-call-site errors (range, overlap) SHALL report the
      transition's source location and the bound argument values, not
      the action's location.
- [x] 6.4 Confirm `ORPHAN_ACTION` warning still fires for
      parametric actions that no transition invokes, and that no
      expansion-time check runs against the orphaned template.

## 7. Tests

- [x] 7.1 `tests/test_parser.py`: zero-parameter signature still
      parses identically; new typed-parameter cases (int-only,
      angle-only, mixed); duplicate-name and unknown-type error
      cases; call-form arity and type checks.
- [x] 7.2 `tests/test_compiler.py`: per-call-site expansion produces
      N distinct gate-sequence entries; angle-typed parameter
      expands through the rotation-gate emitter; Mermaid label uses
      the source-form call text.
- [x] 7.3 `tests/test_verifier.py`: per-call-site range error
      (12-call-site machine with one bad bound value produces one
      error pointing at that transition); template-only unbound-
      identifier error; orphan parametric action.
- [x] 7.4 `tests/test_examples.py`: pull the new
      `examples/larql-polysemantic-12.q.orca.md` through the
      pipeline end-to-end (parse → verify → compile → optional
      simulate → decode).

## 8. Example & demo

- [x] 8.1 Author `examples/larql-polysemantic-12.q.orca.md`: 12-qubit
      concept register (generalized from the 2-qubit sketch), 12
      non-orthogonal concept vectors (pairwise overlap 1/2), single
      parametric `query_concept(c: int)` action, 12 query transitions.
      Overlap matrix documented in the leading paragraph. Note:
      deviates from the proposal's "3-qubit" phrasing — a single-int
      parameter over a product-family concept basis needs one qubit
      per concept so the subscript stays in range.
- [x] 8.2 Author `demos/larql_polysemantic_12/demo.py` mirroring
      `demos/larql_gate_knn/demo.py`: parse + verify → compile
      (Mermaid + QASM + Qiskit) → run 12 independent Qiskit
      simulations → decode the polysemy score per concept. Empirical
      scores match analytic (3/4 on in-feature, 1/3 cross-talk floor
      on out-of-feature) within Monte-Carlo tolerance at 1024 shots.
- [x] 8.3 Promote the 2-qubit / 2-concept sketch as
      `examples/larql-polysemantic-2.q.orca.md`. Rewritten as a
      parametric variant using the same `query_concept(c: int)` action
      as the 12-qubit sibling (so both machines share a template).
      Sketch under `.../sketches/` is kept as the pre-parametric
      design-exploration artifact the change documents.

## 9. Documentation

- [x] 9.1 README gate-set table lists `CCZ`, `MCX`, `MCZ` (plus
      `CCX`/`CCNOT`/`Toffoli` three-qubit row and the many-controlled
      row with example). Already in place from the earlier multi-
      controlled shipping commit.
- [x] 9.2 README has a dedicated "Parametric actions" section with a
      minimal `query_concept(c: int)` action + 3-row call-site table
      and a pointer to `examples/larql-polysemantic-12.q.orca.md`.
- [x] 9.3 `CHANGELOG.md` has an `## Unreleased` section documenting
      parametric actions and the two new polysemantic examples/demo
      as additive-compatible.
- [ ] 9.4 Run `openspec archive extend-gate-set-and-parametric-actions`
      after merge so the deltas land in
      `openspec/specs/{language,compiler,verifier}/spec.md`.

## 10. Spec consistency

- [x] 10.1 `openspec validate extend-gate-set-and-parametric-actions
      --strict` passes.
- [x] 10.2 Full pytest suite green (554 passed, 6 skipped).
- [x] 10.3 Ruff clean across the touched files.
