#!/bin/zsh
# Q-Orca nightly development run
# Runs at 2:07am, implements next pending OpenSpec change, opens PR for review.

export HOME="/Users/allans"
export PATH="/Users/allans/.local/bin:/usr/local/bin:/usr/bin:/bin"
LOG_DIR="/Users/allans/code/q-orca-lang/logs"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/nightly-$(date +%Y-%m-%d).log"

PROMPT_SRC="/Users/allans/code/q-orca-lang/scripts/nightly-prompt.txt"
PROMPT_TMP="/tmp/q-orca-nightly-prompt.txt"
cp "$PROMPT_SRC" "$PROMPT_TMP"

echo "=== Q-Orca nightly run $(date) ===" >> "$LOG"

claude -p "$(cat "$PROMPT_TMP")" \
  --model claude-opus-4-7 \
  --allowedTools "Bash,Read,Write,Edit,Glob,Grep,Agent" \
  --output-format text \
  >> "$LOG" 2>&1

echo "=== Done $(date) ===" >> "$LOG"
