from pathlib import Path
from datetime import datetime
from pyspark.sql import functions as F
from pyspark.sql.types import StructType
from .utils import get_env, get_table_info, get_spark


class _LocalFileInfo:
    # univamentemente para uso de la libreria en entornos locales
    def __init__(self, path: str):
        self.path = path
        p = Path(path)
        self.name = p.name
        self.size = p.stat().st_size if p.exists() else 0
        self.modificationTime = int(p.stat().st_mtime * 1000) if p.exists() else 0

    def isFile(self) -> bool:
        return Path(self.path).is_file()

    def __repr__(self) -> str:
        return (
            "FileInfo("
            f"path='{self.path}', "
            f"name='{self.name}', "
            f"size={self.size}, "
            f"modificationTime={self.modificationTime}"
            ")"
        )

def _normalize_path(path):
    if path.startswith("dbfs:"):
        return path.replace("dbfs:", "", 1)
    return path


def _ls_path(base_path):
    try:
        # Databricks runtime provides dbutils in globals.
        files = dbutils.fs.ls(base_path)  # type: ignore
        return files
    except Exception:
        local_path = _normalize_path(base_path)
        p = Path(local_path)
        if not p.exists():
            return []
        return [_LocalFileInfo(str(child)) for child in p.iterdir()]


def _coerce_header_option(header):
    if isinstance(header, bool):
        return 0 if header else None
    if header is None:
        return None
    if isinstance(header, int):
        return header
    raise ValueError("El parámetro 'header' debe ser bool, int o None.")


def _get_latest_file(base_path, allowed_extensions=None):
    files = _ls_path(base_path)
    file_candidates = [f for f in files if f.isFile()]

    if allowed_extensions:
        normalized_extensions = {ext.lower() for ext in allowed_extensions}
        file_candidates = [
            f for f in file_candidates
            if Path(f.name).suffix.lower() in normalized_extensions
        ]

    if not file_candidates:
        return None

    return sorted(file_candidates, key=lambda f: f.name, reverse=True)[0]


def _build_default_column_names(column_count):
    return [f"column_{idx + 1}" for idx in range(column_count)]


def _load_excel_with_pandas(
    spark=None,
    file_path=None,
    header=True,
    sheet_name=0,
    dtype=None,
    schema=None,
):
    import pandas as pd

    if schema is not None and not isinstance(schema, StructType):
        raise TypeError("El parámetro 'schema' debe ser un pyspark.sql.types.StructType.")

    header_option = _coerce_header_option(header)
    suffix = Path(file_path).suffix.lower()
    engine = None

    if suffix == ".xlsx":
        engine = "openpyxl"
    elif suffix == ".xls":
        engine = "xlrd"

    read_kwargs = {
        "header": header_option,
        "sheet_name": sheet_name,
    }
    if dtype is not None:
        read_kwargs["dtype"] = dtype
    if engine is not None:
        read_kwargs["engine"] = engine

    try:
        pdf = pd.read_excel(file_path, **read_kwargs)
    except Exception as read_error:
        raise RuntimeError(
            f"No fue posible leer el archivo Excel con pandas: {file_path}. "
            "Verifique dependencias del entorno: openpyxl para .xlsx, xlrd para .xls. "
            "Verifique también que el archivo no esté corrupto y que la ruta sea correcta."
        ) from read_error

    if header_option is None:
        pdf.columns = _build_default_column_names(len(pdf.columns))

    try:
        if schema is not None:
            return spark.createDataFrame(pdf, schema=schema)
        return spark.createDataFrame(pdf)
    except Exception as conversion_error:
        raise RuntimeError(
            f"El archivo Excel fue leído correctamente con pandas, pero no fue posible "
            f"convertirlo a DataFrame Spark: {file_path}. "
            "Esto suele ocurrir cuando una columna del Excel tiene valores con tipos mixtos "
            "(por ejemplo texto y números) y Spark/Arrow no puede inferir un tipo único. "
            "Para fijar el contrato de salida, pase schema=StructType(...) a la función."
        ) from conversion_error


def _load_excel_with_spark(
    spark=None,
    file_path=None,
    header=True,
    sheet_name=0,
    infer_schema=True,
    data_address=None,
):
    reader = (
        spark.read
        .format("com.crealytics.spark.excel")
        .option("header", str(bool(header)).lower())
        .option("inferSchema", str(bool(infer_schema)).lower())
        .option("treatEmptyValuesAsNulls", "true")
        .option("addColorColumns", "false")
    )

    if data_address:
        reader = reader.option("dataAddress", data_address)
    elif sheet_name not in (None, 0):
        reader = reader.option("dataAddress", f"'{sheet_name}'!A1")

    df = reader.load(file_path)

    if not header:
        df = df.toDF(*_build_default_column_names(len(df.columns)))

    return df


def _base_raw_files_path(env=None):
    env = env or get_env()
    return f"/Volumes/bronze/files/{env}"


def _resolve_column_name(columns, column_name, object_name):
    normalized_columns = {c.lower(): c for c in columns}
    resolved_name = normalized_columns.get(column_name.lower())
    if resolved_name is None:
        raise ValueError(f"La columna '{column_name}' no existe en {object_name}.")
    return resolved_name


def _sql_literal(value):
    if value is None:
        return "NULL"

    if isinstance(value, datetime):
        return f"TIMESTAMP '{value.strftime('%Y-%m-%d %H:%M:%S')}'"

    if hasattr(value, "isoformat"):
        return f"DATE '{value.isoformat()}'"

    if isinstance(value, str):
        escaped_value = value.replace("'", "''")
        return f"'{escaped_value}'"

    return str(value)


def load_latest_delimited_file(
    spark=None,
    source_file=None,
    env=None,
    delimiter=",",
    header=True,
    infer_schema=True,
    encoding="utf-8",
    quote='"',
    escape='"',
    multiline=False,
    extensions=None,
):
    """
    Carga el último archivo delimitado desde una carpeta y retorna un DataFrame Spark.

    Parámetros:
      spark (SparkSession): Sesión activa de Spark.
      source_file (str): Ruta relativa dentro de /Volumes/bronze/excel/{env}/.
      env (str, opcional): Entorno de ejecución.
      delimiter (str, opcional): Delimitador del archivo. Ejemplos: ',', ';', '\\t', '|'.
      header (bool, opcional): Indica si el archivo tiene encabezado.
      infer_schema (bool, opcional): Si Spark debe inferir tipos.
      encoding (str, opcional): Encoding del archivo.
      quote (str, opcional): Carácter quote para CSV/TXT.
      escape (str, opcional): Carácter escape.
      multiline (bool, opcional): Si el archivo soporta registros multilinea.
      extensions (iterable, opcional): Extensiones permitidas. Por defecto csv/txt.

    Retorna:
      DataFrame Spark o None si no se encuentra archivo.
    """
    spark = get_spark(spark)
    base_path = f"{_base_raw_files_path(env)}/{source_file}/"
    latest_file = _get_latest_file(base_path, extensions or {".csv", ".txt"})

    if latest_file is None:
        print(f"No se encontraron archivos delimitados en la carpeta: {source_file}")
        return None

    return (
        spark.read
        .option("header", str(bool(header)).lower())
        .option("inferSchema", str(bool(infer_schema)).lower())
        .option("sep", delimiter)
        .option("encoding", encoding)
        .option("quote", quote)
        .option("escape", escape)
        .option("multiLine", str(bool(multiline)).lower())
        .csv(latest_file.path)
    )


def load_latest_excel_file(
    spark=None,
    source_file=None,
    env=None,
    header=True,
    sheet_name=0,
    schema=None,
):
    """
    Carga el último archivo Excel (.xls o .xlsx) desde una carpeta.
    La lectura se hace con pandas y luego se convierte a DataFrame Spark.
    Si se informa schema, debe ser un pyspark.sql.types.StructType y se aplica
    durante la creación del DataFrame Spark.
    """
    spark = get_spark(spark)
    base_path = f"{_base_raw_files_path(env)}/{source_file}/"
    latest_file = _get_latest_file(base_path, {".xls", ".xlsx"})

    if latest_file is None:
        print(f"No se encontraron archivos Excel en la carpeta: {source_file}")
        return None
    
    print(f"Archivo Excel encontrado: {latest_file.path}")
    file_path = _normalize_path(latest_file.path)

    return _load_excel_with_pandas(
        spark=spark,
        file_path=file_path,
        header=header,
        sheet_name=sheet_name,
        schema=schema,
    )


def load_latest_file(
    spark=None,
    source_file=None,
    env=None,
    file_format=None,
    header=True,
    delimiter=",",
    infer_schema=True,
    encoding="utf-8",
    quote='"',
    escape='"',
    multiline=False,
    sheet_name=0,
    schema=None,
):
    """
    Dispatcher de carga para archivos crudos versionados.

    Formatos soportados:
      - excel, xls, xlsx
      - csv
      - txt
      - tsv
      - delimited
    """
    normalized_format = (file_format or "").lower()

    if normalized_format in {"excel", "xls", "xlsx"}:
        return load_latest_excel_file(
            spark=spark,
            source_file=source_file,
            env=env,
            header=header,
            sheet_name=sheet_name,
            schema=schema,
        )

    if normalized_format == "csv":
        return load_latest_delimited_file(
            spark=spark,
            source_file=source_file,
            env=env,
            delimiter=delimiter,
            header=header,
            infer_schema=infer_schema,
            encoding=encoding,
            quote=quote,
            escape=escape,
            multiline=multiline,
            extensions={".csv"},
        )

    if normalized_format == "txt":
        return load_latest_delimited_file(
            spark=spark,
            source_file=source_file,
            env=env,
            delimiter=delimiter,
            header=header,
            infer_schema=infer_schema,
            encoding=encoding,
            quote=quote,
            escape=escape,
            multiline=multiline,
            extensions={".txt"},
        )

    if normalized_format in {"tsv", "tab"}:
        return load_latest_delimited_file(
            spark=spark,
            source_file=source_file,
            env=env,
            delimiter="\t",
            header=header,
            infer_schema=infer_schema,
            encoding=encoding,
            quote=quote,
            escape=escape,
            multiline=multiline,
            extensions={".tsv", ".txt"},
        )

    if normalized_format == "delimited":
        return load_latest_delimited_file(
            spark=spark,
            source_file=source_file,
            env=env,
            delimiter=delimiter,
            header=header,
            infer_schema=infer_schema,
            encoding=encoding,
            quote=quote,
            escape=escape,
            multiline=multiline,
        )

    raise ValueError(f"Formato de archivo no soportado: {file_format}")

# def load_latest_file_bronze(spark, data_base, schema, table, env=None):
def load_latest_parquet(spark=None, data_base=None, schema=None, table=None, env=None):
    """
    Carga el último archivo Parquet para la tabla especificada y retorna un DataFrame.
    
    Parámetros:
      spark (SparkSession): Sesión activa de Spark.
      data_base (str): Nombre de la base de datos.
      schema (str): Nombre del esquema.
      table (str): Nombre de la tabla.
      env (str, opcional): Entorno de ejecución (por ejemplo: 'dev', 'qa', 'prod').
                           Si no se proporciona, se obtiene usando get_env().
    
    Retorna:
      DataFrame de Spark cargado desde el archivo Parquet más reciente.
    """
    spark = get_spark(spark)
    env = env or get_env()
    base_path = f"/Volumes/bronze/{data_base}_{schema}/{env}/{table}/"

    try:
        files = _ls_path(base_path)

        parquet_files = [f for f in files if table in f.name]
        
        if not parquet_files:
            return None
        
        latest_file = sorted(parquet_files, key=lambda f: f.name, reverse=True)[0]
        df = spark.read.parquet(latest_file.path)
        return df
             
    except Exception as e:
        print("Error al procesar los archivos:", e)
        return None

    
def return_parquets_and_register_temp_views(spark=None, tables_load=None, verbose=False, env=None):
    """
    Carga dataframes a partir de un diccionario de definición de tablas y materializa vistas temporales.
    Retorna un diccionario con los dataframes.
    
    Parámetros:
        spark (SparkSession): Sesión activa de Spark.
        tables_load (dict): Diccionario que define las tablas a cargar y sus vistas temporales.
        verbose (bool): Si es True, imprime mensajes de estado durante la carga.
        env (str, opcional): Entorno de ejecución (por ejemplo: 'dev', 'qa', 'prod').
                             Si no se proporciona, se obtiene usando get_env().
                             
    Retorna:
        dict: Diccionario donde las claves son nombres completos de tablas y los valores son DataFrames.
    """
    spark = get_spark(spark)
    dataframes = {}

    for data_base, schemas in tables_load.items():
        for schema, tables in schemas.items():
            for t in tables:
                table = t['table']
                view = t['view']

                # Cargar el dataframe usando la función que proveés
                df = load_latest_parquet(spark, data_base, schema, table, env)
                
                # Guardar en el diccionario
                key = f"{data_base}.{schema}.{table}"
                dataframes[key] = df

                # Materializar la vista (esto no necesita asignación en Python)
                try:
                    df.createOrReplaceTempView(view)
                    if verbose:
                        print(f'Tabla "{key}" cargada y vista "{view}" materializada')
                except Exception as e:
                    print(f"Error al materializar la vista '{view} tabla {key}': {e}")
                
    return dataframes


def parquets_register_temp_views(spark=None, tables_load=None, verbose=False, env=None):
    """
    Lee los últimos parquets y materializa vistas temporales en Spark. Sin retorna nada.
    Parámetros:
        spark (SparkSession): Sesión activa de Spark.
        tables_load (dict): Diccionario que define las tablas a cargar y sus vistas temporales.
            La estructura esperada del parámetro `tables_load` es un diccionario
            anidado con el siguiente formato:

                {
                    "<base_de_datos>": {
                        "<schema>": [
                            {
                                "table": "<nombre_tabla>",
                                "view": "<nombre_vista_temporal>"
                            },
                            ...
                        ]
                    },
                    ...
                }
            Ejemplo:
                tables_load = {
                    "bup": {
                        "bup": [
                            {"table": "naturalpersons", "view": "vw_naturalpersons"},
                            {"table": "maritalstatus", "view": "vw_maritalstatus"},
                            {"table": "genders", "view": "vw_genders"},
                            {"table": "legalpersons", "view": "vw_legalpersons"},
                            {"table": "phones", "view": "vw_phones"},
                            {"table": "emails", "view": "vw_emails"},
                            {"table": "addresses", "view": "vw_addresses"},
                            {"table": "persons", "view": "vw_persons"},
                            {"table": "administrativefreezeperiods", "view": "vw_administrativefreezeperiods"},
                            {"table": "fraudrisklevels", "view": "vw_fraudrisklevels"},
                        ],
                    },
                    "oraculo": {
                        "dbo": [
                            {"table": "ml_segmentacion", "view": "vw_segmentacion"},
                        ],
                    },
                    "timepro": {
                        "insudb": [
                            {"table": "logauth0user", "view": "vw_logauth0user"},
                            {"table": "benefitprogramadhesion", "view": "vw_benefitprogramadhesion"},
                        ],
                    },
                    "dwgssprotmp": {
                        "dwo": [
                            {"table": "int_dim_clientactive_bds", "view": "vw_int_dim_cliente_active"},
                        ],
                    },
                    "odscommon": {
                        "employee": [
                            {"table": "vw_active_employee", "view": "vw_active_employee"},
                        ],
                    },
                }
        verbose (bool): Si es True, imprime mensajes de estado durante la carga.
        env (str, opcional): Entorno de ejecución (por ejemplo: 'dev', 'qa', 'prod').
                             Si no se proporciona, se obtiene usando get_env().
    Retorna:
        None
    """
    spark = get_spark(spark)
    for data_base, schemas in tables_load.items():
        for schema, tables in schemas.items():
            for t in tables:
                table = t['table']
                view = t['view']
                try:
                    df = load_latest_parquet(spark, data_base, schema, table, env)
                    df.createOrReplaceTempView(view)
                    if verbose:
                        print(f'Vista "{view}" materializada desde {data_base}.{schema}.{table}')
                except Exception as e:
                    print(f"Error al materializar la vista '{view}' desde {data_base}.{schema}.{table}: {e}")


def load_latest_excel(spark=None, source_file=None, env=None, schema=None):
    
    """
    Carga el último archivo de Excel (aunque no tenga extensión visible) para la carpeta especificada
    y retorna un DataFrame.
    
    Parámetros:
      spark (SparkSession): Sesión activa de Spark.
      source_file (str): Nombre de la carpeta.
      env (str, opcional): Entorno de ejecución (por ejemplo: 'dev', 'qa', 'prod').
                           Si no se proporciona, se obtiene usando get_env().
      schema (StructType, opcional): Esquema Spark a aplicar al crear el DataFrame.
    Retorna:
      DataFrame de Spark cargado desde el archivo Excel más reciente (en formato xls).
    """
    return load_latest_excel_file(
        spark=spark,
        source_file=source_file,
        env=env,
        header=True,
        schema=schema,
    )


def return_excels_and_register_temp_views(spark=None, files_load=None, verbose=False, env=None):
    """
    Carga dataframes a partir de un diccionario de definición de excels y materializa vistas temporales.
    Retorna un diccionario con los dataframes.
    
    Parámetros:
        spark (SparkSession): Sesión activa de Spark.
        files_load (dict): Diccionario que define las tablas a cargar y sus vistas temporales.
            La estructura esperada del parámetro `files_load` es un diccionario
            anidado con el siguiente formato:

                {
                    "<Dominio>": {
                        "<SubDominio>": [
                            {
                                "file": "<nombre_archivo>",
                                "view": "<nombre_vista_temporal>"
                            },
                            ...
                        ]
                    },
                    ...
                }
            Ejemplo:
        verbose (bool): Si es True, imprime mensajes de estado durante la carga.
        env (str, opcional): Entorno de ejecución (por ejemplo: 'dev', 'qa', 'prod').
                             Si no se proporciona, se obtiene usando get_env().
    
    Retorna:
        dict: Diccionario donde las claves son nombres completos de tablas y los valores son DataFrames.
            Quedando las vistas materializadas en el entorno Spark.
    """
    spark = get_spark(spark)
    dataframes = {}

    for domain, subdomain in files_load.items():
        for subdomain, tables in subdomain.items():
            for t in tables:
                file = t['file']
                view = t['view']

                # Cargar el dataframe usando la función que proveés
                source_file = f"{domain}/{subdomain}/{file}"
                df = load_latest_excel(spark, source_file, env)
                
                # Guardar en el diccionario
                key = f"{domain}.{subdomain}.{file}"
                dataframes[key] = df

                # Materializar la vista (esto no necesita asignación en Python)
                try:
                    df.createOrReplaceTempView(view)
                    if verbose:
                        print(f'El archivo "{key}" cargado y vista "{view}" materializada')
                except Exception as e:
                    print(f"Error al materializar la vista '{view} tabla {key}': {e}")
                
    return dataframes


def excels_register_temp_views(spark=None, files_load=None, verbose=False, env=None):
    """
    Lee los últimos archivos excels y materializa vistas temporales en Spark. Sin retorna nada.
    
    Parámetros:
        spark (SparkSession): Sesión activa de Spark.
        files_load (dict): Diccionario que define las tablas a cargar y sus vistas temporales.
            La estructura esperada del parámetro `files_load` es un diccionario
            anidado con el siguiente formato:

                {
                    "<Dominio>": {
                        "<SubDominio>": [
                            {
                                "file": "<nombre_archivo>",
                                "view": "<nombre_vista_temporal>"
                            },
                            ...
                        ]
                    },
                    ...
                }
            Ejemplo:
        verbose (bool): Si es True, imprime mensajes de estado durante la carga.
        env (str, opcional): Entorno de ejecución (por ejemplo: 'dev', 'qa', 'prod').
                             Si no se proporciona, se obtiene usando get_env().
    
    Retorna:
        Nada
    """

    spark = get_spark(spark)
    for domain, subdomain in files_load.items():
        for subdomain, tables in subdomain.items():
            for t in tables:
                file = t['file']
                view = t['view']

                # Cargar el dataframe usando la función que proveés
                source_file = f"{domain}/{subdomain}/{file}"
                df = load_latest_excel(spark, source_file, env)
                
                # Guardar en el diccionario
                key = f"{domain}.{subdomain}.{file}"

                # Materializar la vista (esto no necesita asignación en Python)
                try:
                    df.createOrReplaceTempView(view)
                    if verbose:
                        print(f'El archivo "{key}" leido y vista "{view}" materializada')
                except Exception as e:
                    print(f"Error al materializar la vista '{view} tabla {key}': {e}")


def load_and_materialize_views(action, **kwargs):    
    actions_load_bronze = {
        # Todas las acciones aqui declaradas deberan devolver un diccionario de DataFrames
        # 'load_notebook': load_notebook,
        'return_parquets_and_register_temp_views': return_parquets_and_register_temp_views,
        'parquets_register_temp_views': parquets_register_temp_views,
        'return_excels_and_register_temp_views': return_excels_and_register_temp_views,
        'excels_register_temp_views': excels_register_temp_views,
        # ir agregando más acciones acá
    }
    results = {}
    func = actions_load_bronze.get(action)
    if func:
        results = func(**kwargs)
        # results[action] = result
    else:
        print(f"Acción '{action}' no está implementada.")
    return results


def save_table_to_delta(spark=None, df=None, catalog=None, schema=None, table_name=None, mode="overwrite"):
    """
    Guarda un DataFrame en formato Delta en la ubicación y tabla especificadas,
    usando el modo de escritura indicado y actualizando el esquema si es necesario.

    Parámetros:
      spark (SparkSession): Sesión activa de Spark.
      df (DataFrame): DataFrame de Spark que se desea guardar.
      catalog (str): Nombre del catálogo o base de datos destino.
      schema (str): Nombre del esquema, capa o entorno destino (ejemplo: 'silver', 'gold').
      table_name (str): Nombre de la tabla destino.
      mode (str, opcional): Modo de escritura de Spark. Por defecto es 'overwrite'.

    Retorna:
      None

    Lógica:
      - Utiliza la función auxiliar 'get_table_info' para obtener el path
        de almacenamiento y el nombre completo de la tabla.
      - Escribe el DataFrame en formato Delta en la ruta especificada,
        usando el modo configurado y adaptando el esquema si es necesario.
      - Registra la tabla como tabla administrada en el metastore con el nombre completo.

    Notas:
      - El parámetro `mode` permite controlar la estrategia de escritura
        (por ejemplo: 'overwrite', 'append', 'error', 'ignore').
      - El modo 'overwrite' reemplaza todos los datos existentes en la tabla.
      - La opción 'overwriteSchema' asegura que el esquema de la tabla se actualice si cambió.
      - Es necesario que la ruta y la tabla existan o sean accesibles en el entorno Spark.
      - Las opciones
        `.option("delta.columnMapping.mode", "nameMapping")` y `.option("delta.columnMapping.mode", "name")`
        permiten especificar el modo de mapeo de columnas para Delta Lake:
          - **"nameMapping"**: usa un mapeo explícito de columnas por nombre, útil para cambios de nombre o reordenamiento de columnas sin perder datos.
          - **"name"**: usa el nombre de columna directamente para el mapeo, opción recomendada cuando no se necesita trazabilidad de cambios en los nombres de columna, permite utilizar los acentos en el nombre de las columnas.
      - Si ambas opciones se usan al mismo tiempo, solo una tendrá efecto (se aplicará la última indicada).

    """
    spark = get_spark(spark)
    target_table_info = get_table_info(spark=spark, catalog=catalog, schema=schema, table=table_name)
    (
        df.write
        .format("delta")
        .option("path", target_table_info["path"])
        .mode(mode)
        .option("overwriteSchema", "true")
        .option("delta.columnMapping.mode", "nameMapping") \
        .option("delta.columnMapping.mode", "name") \
        .saveAsTable(target_table_info["full_table_name"])
    )


def save_snapshot_to_delta(spark=None, df=None, catalog=None, schema=None, table_name=None, snapshot_column=None):
    """
    Guarda un snapshot de una tabla fact en formato Delta, eliminando previamente
    el rango temporal existente en destino para la columna de snapshot indicada.

    Parámetros:
      spark (SparkSession): Sesión activa de Spark.
      df (DataFrame): DataFrame de Spark que se desea guardar.
      catalog (str): Nombre del catálogo o base de datos destino.
      schema (str): Nombre del esquema, capa o entorno destino (ejemplo: 'silver', 'gold').
      table_name (str): Nombre de la tabla destino.
      snapshot_column (str): Nombre de la columna que identifica el snapshot o time_key.

    Retorna:
      None

    Lógica:
      - Valida que el DataFrame contenga registros.
      - Verifica que la columna de snapshot exista en el DataFrame fuente.
      - Si la tabla destino ya existe, valida también que la columna exista allí.
      - Calcula el mínimo y máximo valor de la columna snapshot/time_key.
      - Elimina de la tabla destino el período comprendido entre ambos valores.
      - Inserta los nuevos registros en la tabla Delta.

    Notas:
      - Está pensada para cargas tradicionales de Data Warehouse sobre tablas fact
        sin particionamiento físico.
      - Si la tabla destino no existe, realiza una carga inicial creando la tabla.
      - Si la columna snapshot/time_key contiene únicamente valores nulos, la función falla.
    """
    spark = get_spark(spark)

    if df is None:
        raise ValueError("Debe informar un DataFrame en el parámetro 'df'.")

    if not snapshot_column:
        raise ValueError("Debe informar el nombre de la columna snapshot/time_key en 'snapshot_column'.")

    if df.limit(1).count() == 0:
        raise ValueError("El DataFrame recibido no contiene registros para guardar.")

    df_snapshot_column = _resolve_column_name(df.columns, snapshot_column, "el DataFrame origen")
    target_table_info = get_table_info(spark=spark, catalog=catalog, schema=schema, table=table_name)

    snapshot_range = (
        df.select(
            F.min(F.col(df_snapshot_column)).alias("min_snapshot"),
            F.max(F.col(df_snapshot_column)).alias("max_snapshot"),
        )
        .collect()[0]
    )
    min_snapshot = snapshot_range["min_snapshot"]
    max_snapshot = snapshot_range["max_snapshot"]

    if min_snapshot is None or max_snapshot is None:
        raise ValueError(
            f"La columna '{df_snapshot_column}' no contiene valores válidos para determinar el período del snapshot."
        )

    write_builder = (
        df.write
        .format("delta")
        .option("path", target_table_info["path"])
        .option("delta.columnMapping.mode", "nameMapping")
        .option("delta.columnMapping.mode", "name")
    )

    if target_table_info["exists"]:
        target_df = spark.table(target_table_info["full_table_name"])
        table_snapshot_column = _resolve_column_name(
            target_df.columns,
            snapshot_column,
            f"la tabla destino {target_table_info['full_table_name']}",
        )

        delete_condition = (
            f"`{table_snapshot_column}` >= {_sql_literal(min_snapshot)} "
            f"AND `{table_snapshot_column}` <= {_sql_literal(max_snapshot)}"
        )
        spark.sql(f"DELETE FROM {target_table_info['full_table_name']} WHERE {delete_condition}")
        write_builder.mode("append").saveAsTable(target_table_info["full_table_name"])
        return

    (
        write_builder
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(target_table_info["full_table_name"])
    )
