"""Tests for emt_skill_sync.filter — apply_filters() semantics."""
import pytest

from emt_skill_sync.filter import apply_filters
from emt_skill_sync.manifest import BundleEntry, Manifest, SkillEntry


def _skill(id: str, tags: list[str] = None, phase: str = "") -> SkillEntry:
    return SkillEntry(id=id, source=f"flezi-emt/skills/{id}", tags=tags or [], phase=phase)


def _bundle(id: str, skills: list[str], tags: list[str] = None) -> BundleEntry:
    return BundleEntry(id=id, source=f"flezi-emt/bundles/{id}.bundle.yaml",
                       skills=skills, tags=tags or [])


@pytest.fixture
def manifest():
    skills = [
        _skill("emt-analyze-baseline", tags=["baseline", "analysis"], phase="assessment"),
        _skill("emt-search-artifact", tags=["analysis", "xray"], phase="assessment"),
        _skill("emt-xray-assessment", tags=["xray"], phase="assessment"),
        _skill("emt-generate-plan", tags=["planning"], phase="planning"),
        _skill("emt-skill-help", tags=["help", "navigation"], phase="utility"),
    ]
    bundles = [
        _bundle("emt-stage-assessment",
                skills=["emt-analyze-baseline", "emt-search-artifact", "emt-xray-assessment"],
                tags=["baseline", "analysis", "xray"]),
        _bundle("emt-stage-planning",
                skills=["emt-generate-plan"],
                tags=["planning"]),
    ]
    return Manifest(skills=skills, bundles=bundles)


# --- --only ---

def test_only_bare_id(manifest):
    result = apply_filters(manifest, only="emt-skill-help")
    assert [e.id for e in result] == ["emt-skill-help"]


def test_only_prefixed(manifest):
    result = apply_filters(manifest, only="skill:emt-skill-help")
    assert [e.id for e in result] == ["emt-skill-help"]


def test_only_unknown_returns_empty(manifest):
    result = apply_filters(manifest, only="emt-nonexistent")
    assert result == []


def test_only_conflicts_with_profile(manifest):
    with pytest.raises(ValueError, match="--only cannot be combined"):
        apply_filters(manifest, only="emt-skill-help", profile="emt-stage-assessment")


def test_only_conflicts_with_filter_tags(manifest):
    with pytest.raises(ValueError, match="--only cannot be combined"):
        apply_filters(manifest, only="emt-skill-help", filter_tags="xray")


# --- --profile ---

def test_profile_restricts_to_bundle_skills(manifest):
    result = apply_filters(manifest, profile="emt-stage-assessment")
    ids = {e.id for e in result}
    assert ids == {"emt-analyze-baseline", "emt-search-artifact", "emt-xray-assessment"}


def test_profile_does_not_include_skills_outside_bundle(manifest):
    result = apply_filters(manifest, profile="emt-stage-planning")
    ids = {e.id for e in result}
    assert "emt-skill-help" not in ids
    assert "emt-generate-plan" in ids


def test_unknown_profile_raises(manifest):
    with pytest.raises(ValueError, match="Unknown profile 'emt-stage-solutioning'"):
        apply_filters(manifest, profile="emt-stage-solutioning")


def test_unknown_profile_lists_available(manifest):
    with pytest.raises(ValueError, match="emt-stage-assessment"):
        apply_filters(manifest, profile="emt-nonexistent")


# --- --filter-tags (OR semantics) ---

def test_filter_tags_single(manifest):
    result = apply_filters(manifest, filter_tags="xray")
    ids = {e.id for e in result}
    assert "emt-search-artifact" in ids
    assert "emt-xray-assessment" in ids
    assert "emt-generate-plan" not in ids


def test_filter_tags_or_semantics(manifest):
    result = apply_filters(manifest, filter_tags="baseline,planning")
    ids = {e.id for e in result}
    assert "emt-analyze-baseline" in ids   # has "baseline"
    assert "emt-generate-plan" in ids      # has "planning"
    assert "emt-skill-help" not in ids


def test_filter_tags_no_match_returns_empty(manifest):
    result = apply_filters(manifest, filter_tags="nonexistent-tag")
    assert result == []


def test_filter_tags_unknown_tag_warns_but_does_not_raise(manifest, capsys):
    # Should not raise; only print a warning via Rich console (no capsys for Rich)
    result = apply_filters(manifest, filter_tags="totally-unknown-tag")
    assert result == []


# --- --profile AND --filter-tags (AND semantics) ---

def test_profile_and_filter_tags_and_semantics(manifest):
    # Bundle has 3 skills; only 2 have "baseline" or "analysis" tag
    result = apply_filters(manifest, profile="emt-stage-assessment", filter_tags="baseline")
    ids = {e.id for e in result}
    assert "emt-analyze-baseline" in ids   # has "baseline"
    assert "emt-xray-assessment" not in ids  # only has "xray", not "baseline"


def test_profile_and_filter_tags_skill_in_bundle_missing_tag_is_dropped(manifest):
    # emt-xray-assessment is in the bundle but NOT tagged "baseline"
    result = apply_filters(manifest, profile="emt-stage-assessment", filter_tags="baseline")
    ids = {e.id for e in result}
    assert "emt-xray-assessment" not in ids


def test_profile_and_filter_tags_all_dropped(manifest):
    # Filter for "planning" within "emt-stage-assessment" → nothing matches
    result = apply_filters(manifest, profile="emt-stage-assessment", filter_tags="planning")
    assert result == []


# --- no filters ---

def test_no_filters_returns_all_skills(manifest):
    result = apply_filters(manifest)
    assert len(result) == len(manifest.skills)


# --- empty manifest ---

def test_empty_manifest():
    m = Manifest(skills=[], bundles=[])
    assert apply_filters(m) == []
    assert apply_filters(m, filter_tags="xray") == []


def test_profile_on_empty_bundles():
    m = Manifest(skills=[_skill("emt-skill-help")], bundles=[])
    with pytest.raises(ValueError, match="Unknown profile"):
        apply_filters(m, profile="emt-stage-assessment")
