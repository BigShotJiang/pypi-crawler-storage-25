"""
Megakino Downloader - A modern CLI for watching and downloading movies/series.
"""
__version__ = "1.0.0"
