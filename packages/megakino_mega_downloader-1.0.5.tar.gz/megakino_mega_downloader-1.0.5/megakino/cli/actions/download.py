import os
import concurrent.futures
import re
from pathlib import Path
from typing import List
from rich.console import Console
from rich.progress import Progress, TextColumn, BarColumn, DownloadColumn, TransferSpeedColumn, TimeRemainingColumn
from yt_dlp import YoutubeDL
from megakino.core.models import Episode
from megakino.core.config import config

console = Console()

def sanitize_filename(name: str) -> str:
    # Remove invalid characters for all OS filesystems
    return re.sub(r'[<>:"/\\|?*]', '', name).strip()

def download_task(link: str, episode: Episode, progress: Progress, task_id):
    safe_title = sanitize_filename(episode.title)
    output_dir = Path(config.download_path)
    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"{safe_title}.mp4"

    def my_hook(d):
        if d['status'] == 'downloading':
            total_bytes = d.get('total_bytes') or d.get('total_bytes_estimate')
            if total_bytes:
                progress.update(task_id, total=total_bytes)
            downloaded = d.get('downloaded_bytes', 0)
            progress.update(task_id, completed=downloaded)
        elif d['status'] == 'finished':
            progress.update(task_id, description=f"[green]Processing:[/green] {safe_title}")

    ydl_opts = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'outtmpl': str(output_file),
        'quiet': True,
        'no_warnings': True,
        'progress_hooks': [my_hook],
        'fragment_retries': 20,
        'retries': 10,
        'concurrent_fragment_downloads': 5,
        'nocheckcertificate': True,
    }

    # Add compression if enabled
    if config.use_compression:
        ydl_opts['postprocessors'] = [{
            'key': 'FFmpegVideoConvertor',
            'preferedformat': 'mp4',
        }]
        # ffmpeg_args to control speed/quality preset
        ydl_opts['postprocessor_args'] = [
            '-c:v', 'libx264',
            '-crf', '23', # Good balance of quality/size
            '-preset', config.compression_preset,
            '-c:a', 'aac',
            '-b:a', '128k'
        ]

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([link])
        progress.update(task_id, completed=progress.tasks[task_id].total, description=f"[green]Done:[/green] {safe_title}")
    except Exception as e:
        progress.update(task_id, description=f"[red]Failed:[/red] {safe_title}")
        console.print(f"\n[red]Error downloading {safe_title}: {e}[/red]")

def download_concurrently(direct_links: List[str], episodes: List[Episode]):
    with Progress(
        TextColumn("[bold blue]{task.description}", justify="right"),
        BarColumn(bar_width=40),
        "[progress.percentage]{task.percentage:>3.1f}%",
        "•",
        DownloadColumn(),
        "•",
        TransferSpeedColumn(),
        "•",
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        
        tasks = []
        for link, episode in zip(direct_links, episodes):
            task_id = progress.add_task(f"[cyan]Downloading[/cyan] {episode.title}", total=None)
            tasks.append((link, episode, task_id))
            
        with concurrent.futures.ThreadPoolExecutor(max_workers=config.concurrent_downloads) as executor:
            futures = [
                executor.submit(download_task, link, episode, progress, task_id)
                for link, episode, task_id in tasks
            ]
            concurrent.futures.wait(futures)
            
    console.print("\n[bold green]All downloads completed![/bold green]")
