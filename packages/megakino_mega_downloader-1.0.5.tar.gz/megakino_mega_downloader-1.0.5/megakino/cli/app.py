import asyncio
from InquirerPy import inquirer
from InquirerPy.base.control import Choice
from rich.console import Console

from megakino.api.client import APIClient
from megakino.api.scraper import search_for_movie, get_media_details
from megakino.api.extractors.megakino import megakino_get_direct_link
from megakino.api.extractors.voe import voe_get_direct_link
from megakino.core.config import config, config_manager
from megakino.cli.actions.download import download_concurrently
from megakino.cli.actions.watch import watch
from megakino.cli.actions.syncplay import syncplay

console = Console()

async def interactive_app():
    if config.show_animations:
        console.print("[bold cyan]✨ Loading Megakino Downloader... ✨[/bold cyan]")
        await asyncio.sleep(0.5)
    
    console.print("[bold cyan]Welcome to Megakino Downloader![/bold cyan]")
    
    async with APIClient() as client:
        while True:
            action = inquirer.select(
                message="What would you like to do?",
                choices=["Search Movie/Series", "Settings", "Exit"],
                default="Search Movie/Series"
            ).execute()
            
            if action == "Exit":
                break
            elif action == "Settings":
                await settings_menu()
            elif action == "Search Movie/Series":
                await search_flow(client)

async def settings_menu():
    while True:
        choice = inquirer.select(
            message="Settings:",
            choices=[
                f"Download Path [{config.download_path}]",
                f"Concurrent Downloads [{config.concurrent_downloads}]",
                f"Preferred Provider [{config.preferred_provider}]",
                f"Video Compression [{'ON' if config.use_compression else 'OFF'}]",
                f"UI Animations [{'ON' if config.show_animations else 'OFF'}]",
                "Back"
            ]
        ).execute()

        if choice == "Back":
            break
        elif choice.startswith("Download Path"):
            new_path = inquirer.text(message="Enter new download path:", default=config.download_path).execute()
            config.download_path = new_path
        elif choice.startswith("Concurrent Downloads"):
            new_val = inquirer.number(
                message="Max concurrent downloads:",
                min_allowed=1,
                max_allowed=10,
                default=config.concurrent_downloads
            ).execute()
            config.concurrent_downloads = int(new_val)
        elif choice.startswith("Preferred Provider"):
            new_prov = inquirer.select(
                message="Select preferred provider:",
                choices=["Megakino", "VOE"],
                default=config.preferred_provider
            ).execute()
            config.preferred_provider = new_prov
        elif choice.startswith("Video Compression"):
            config.use_compression = inquirer.confirm(
                message="Enable Video Compression? (Requires FFmpeg)",
                default=config.use_compression
            ).execute()
            if config.use_compression:
                console.print("\n[bold yellow]Info to Compression Presets:[/bold yellow]")
                console.print(" - [cyan]veryslow[/cyan]: Best quality & smallest file, but VERY slow.")
                console.print(" - [cyan]medium[/cyan]: Balanced (Good for most users).")
                console.print(" - [cyan]veryfast[/cyan]: Fastest, but larger file and lower quality.")
                
                config.compression_preset = inquirer.select(
                    message="Select Compression Speed:",
                    choices=[
                        Choice("veryslow", "Very Slow (Smallest file)"),
                        Choice("slow", "Slow"),
                        Choice("medium", "Medium (Balanced)"),
                        Choice("fast", "Fast"),
                        Choice("veryfast", "Very Fast (Largest file)")
                    ],
                    default=config.compression_preset
                ).execute()
        elif choice.startswith("UI Animations"):
            config.show_animations = inquirer.confirm(
                message="Enable UI Animations/Intro? (Visual flavor only)",
                default=config.show_animations
            ).execute()
        
        config_manager.save()
        console.print("[green]Settings saved![/green]")

async def search_flow(client: APIClient):
    query = inquirer.text(message="Enter movie or series name:").execute()
    if not query or not query.strip():
        console.print("[yellow]Query cannot be empty![/yellow]")
        return
    
    query = query.strip()
    with console.status(f"[bold green]Searching for '{query}'...[/bold green]"):
        try:
            results = await search_for_movie(query, client)
        except Exception as e:
            console.print(f"[red]Search failed: {e}[/red]")
            return
        
    if not results:
        console.print("[red]No results found for your search.[/red]")
        return
        
    choices = [Choice(value=res.url, name=res.title) for res in results]
    choices.append(Choice(value=None, name="Cancel"))
    
    selected_url = inquirer.select(
        message="Select a result:",
        choices=choices
    ).execute()
    
    if not selected_url:
        return
        
    with console.status("[bold green]Fetching details...[/bold green]"):
        details = await get_media_details(selected_url, client)
        
    if not details.episodes:
        console.print("[red]No playable media found for this selection.[/red]")
        return
        
    ep_choices = [Choice(value=ep, name=ep.title) for ep in details.episodes]
    selected_episodes = inquirer.checkbox(
        message="Select episodes (Space to select/deselect, Enter to confirm, Ctrl+A to select all):",
        choices=ep_choices,
        validate=lambda result: len(result) > 0,
        invalid_message="You must select at least one episode!"
    ).execute()
    
    if not selected_episodes:
        return
        
    action = inquirer.select(
        message="What do you want to do with the selected episodes?",
        choices=[
            Choice("Watch", "Watch in MPV"),
            Choice("Download", f"Download to {config.download_path}"),
            Choice("Syncplay", "Watch with friends (Syncplay)")
        ],
        default="Watch"
    ).execute()
    
    provider = inquirer.select(
        message="Select provider:",
        choices=["Megakino", "VOE"],
        default=config.preferred_provider
    ).execute()
    
    direct_links = []
    final_episodes = []
    
    with console.status("[bold green]Extracting direct links...[/bold green]"):
        for ep in selected_episodes:
            link = None
            if provider == "Megakino":
                # Assuming the URL points to a page where we can extract Megakino links
                link = await megakino_get_direct_link(ep.url, client)
                # Fallback to VOE if Megakino fails
                if not link:
                    link = await voe_get_direct_link(ep.url, client)
            else:
                link = await voe_get_direct_link(ep.url, client)
                if not link:
                    link = await megakino_get_direct_link(ep.url, client)
            
            if link:
                direct_links.append(link)
                final_episodes.append(ep)
            else:
                console.print(f"[yellow]Failed to extract link for {ep.title}[/yellow]")
                
    if not direct_links:
        console.print("[red]No valid links could be extracted.[/red]")
        return
        
    if action == "Watch":
        watch(direct_links, final_episodes)
    elif action == "Download":
        download_concurrently(direct_links, final_episodes)
    elif action == "Syncplay":
        syncplay(direct_links, final_episodes)
