"""Terminal abstraction layer for keep.

Provides a uniform interface for spawning, sending text, reading screen,
and closing sessions across different terminal emulators.
"""
from __future__ import annotations
from typing import Protocol, runtime_checkable


@runtime_checkable
class Terminal(Protocol):
    def new_surface(self, cwd: str, cmd: str) -> str:
        """Spawn a new terminal session in the given directory running cmd.
        Returns a target_id string that identifies this session."""
        ...

    def send_text(self, target_id: str, text: str) -> None:
        """Send text followed by Enter to the session."""
        ...

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to the session. key values: 'escape', 'enter', 'ctrl-c'."""
        ...

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content of the session."""
        ...

    def close(self, target_id: str) -> None:
        """Close/kill the session."""
        ...

    def resolve_target_id(self, pid: int) -> str | None:
        """Discover a running process's target_id by introspecting the OS (env vars, etc).
        Returns None if this terminal does not support runtime discovery (target_id is
        only known at spawn time and must come from the participant cache)."""
        ...


def _default_factory(terminal_type: str) -> Terminal:
    match terminal_type:
        case "cmux":
            from keep.terminals.cmux import CmuxTerminal
            return CmuxTerminal()
        case "tmux":
            from keep.terminals.tmux import TmuxTerminal
            return TmuxTerminal()
        case "terminal":
            from keep.terminals.terminal_app import TerminalAppTerminal
            return TerminalAppTerminal()
        case "kitty":
            from keep.terminals.kitty import KittyTerminal
            return KittyTerminal()
        case "iterm2":
            from keep.terminals.iterm2 import ITerm2Terminal
            return ITerm2Terminal()
        case _:
            raise ValueError(f"Unknown terminal type: {terminal_type!r}. Choose from: cmux, tmux, terminal, kitty, iterm2")


_factory = _default_factory


def get_terminal(terminal_type: str) -> Terminal:
    """Factory: return Terminal implementation for the given type.

    Delegates to the module-level ``_factory`` so tests can swap in a fake by
    monkeypatching ``keep.terminal._factory`` — works regardless of how callers
    imported ``get_terminal`` (``from keep.terminal import get_terminal`` binds
    the function object, but the function still looks up ``_factory`` at call
    time, so the patch takes effect everywhere).
    """
    return _factory(terminal_type)
