"""Cmux terminal backend for keep."""
from __future__ import annotations

import json
import os
import socket
import subprocess
import time


# --- Module-level private RPC helpers (ported from keep/cmux.py) ---

SOCKET_PATH = os.environ.get(
    "CMUX_SOCKET_PATH",
    os.path.expanduser("~/Library/Application Support/cmux/cmux.sock"),
)


def _rpc(method: str, params: dict | None = None) -> dict:
    payload = {"id": "keep", "method": method, "params": params or {}}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
        s.connect(SOCKET_PATH)
        s.sendall(json.dumps(payload).encode() + b"\n")
        s.settimeout(10)
        data = s.recv(65536).decode()
    resp = json.loads(data)
    if not resp.get("ok"):
        error = resp.get("error", {})
        msg = error.get("message", str(error)) if isinstance(error, dict) else str(error)
        raise RuntimeError(f"cmux {method}: {msg}")
    return resp.get("result", {})


class CmuxTerminal:
    def new_surface(self, cwd: str, cmd: str) -> str:
        """Spawn a new cmux terminal surface running cmd in cwd.
        Returns the surface ref (e.g. 'surface:42')."""
        result = subprocess.run(
            ["cmux", "new-surface", "--type", "terminal"],
            capture_output=True,
            text=True,
            check=True,
        )
        # Output: "OK surface:42 pane:N workspace:N" — extract surface:N
        raw = result.stdout.strip()
        surface_ref = next((p for p in raw.split() if p.startswith("surface:")), None)
        if not surface_ref:
            raise RuntimeError(f"cmux new-surface: unexpected output: {raw!r}")
        _rpc("surface.send_text", {"surface_id": surface_ref, "text": f"cd {cwd} && {cmd}"})
        time.sleep(0.5)
        _rpc("surface.send_key", {"surface_id": surface_ref, "key": "Enter"})
        return surface_ref

    def send_text(self, target_id: str, text: str) -> None:
        """Send text to the session, wait for processing, then send Enter."""
        _rpc("surface.send_text", {"surface_id": target_id, "text": text})
        time.sleep(2)
        _rpc("surface.send_key", {"surface_id": target_id, "key": "Enter"})

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to the session."""
        key_map = {"escape": "escape", "enter": "Enter", "ctrl-c": "ctrl-c"}
        cmux_key = key_map.get(key, key)
        _rpc("surface.send_key", {"surface_id": target_id, "key": cmux_key})

    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content via cmux CLI."""
        result = subprocess.run(
            ["cmux", "read-screen", "--surface", target_id],
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout

    def close(self, target_id: str) -> None:
        """Close the surface via RPC."""
        try:
            _rpc("surface.close", {"surface_id": target_id})
        except RuntimeError as e:
            import logging
            logging.getLogger(__name__).warning("close %s: %s", target_id, e)

    def resolve_target_id(self, pid: int) -> str | None:
        """Read CMUX_SURFACE_ID from the running process's env."""
        try:
            result = subprocess.run(
                ["ps", "eww", "-p", str(pid)],
                capture_output=True, text=True, timeout=5,
            )
        except Exception:
            return None
        for token in result.stdout.replace("\n", " ").split(" "):
            if token.startswith("CMUX_SURFACE_ID="):
                return token.split("=", 1)[1]
        return None
