"""TMUX terminal backend for keep."""
from __future__ import annotations
import subprocess
import time
import uuid


class TmuxTerminal:
    def new_surface(self, cwd: str, cmd: str) -> str:
        """Create a new tmux session running cmd in cwd.
        Returns target_id in format 'session_name:0.%N'."""
        session_name = f"keep-{uuid.uuid4().hex[:8]}"
        subprocess.run(
            ["tmux", "new-session", "-d", "-s", session_name, "-c", cwd, "-x", "220", "-y", "50"],
            check=True, capture_output=True,
        )
        # Get the pane id
        pane_id = subprocess.check_output(
            ["tmux", "display-message", "-t", session_name, "-p", "#{pane_id}"],
            text=True,
        ).strip()
        # Send the command
        subprocess.run(
            ["tmux", "send-keys", "-t", session_name, cmd, "Enter"],
            check=True, capture_output=True,
        )
        return f"{session_name}:0.{pane_id}"

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then Enter to tmux pane as two separate calls.

        CRITICAL: do NOT collapse into one `send-keys text Enter`, and
        do NOT shorten the sleep. See keep/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. When a terminal
          wraps a payload in "\\e[200~ ... \\e[201~" (paste mode), any
          Enter/CR inside that envelope is treated as a multi-line
          newline, NOT submit — the message stays stuck in the input
          buffer.

          tmux's `send-keys text Enter` today sends Enter as a raw
          keystroke outside any paste envelope, but tmux 3.x has started
          auto-bracketing certain paste-sized writes. Aligning all
          backends on "text → ~2s sleep → Enter" eliminates the
          bracketed-paste regression class and matches cmux/iterm2.
        """
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, text],
            check=True, capture_output=True,
        )
        time.sleep(2)
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, "Enter"],
            check=True, capture_output=True,
        )

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to tmux pane."""
        key_map = {"escape": "Escape", "enter": "Enter", "ctrl-c": "C-c"}
        tmux_key = key_map.get(key, key)
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, tmux_key],
            check=True, capture_output=True,
        )

    def read_screen(self, target_id: str) -> str:
        return subprocess.check_output(
            ["tmux", "capture-pane", "-t", target_id, "-p"],
            text=True,
        )

    def close(self, target_id: str) -> None:
        # target_id format: "session_name:0.%N" — extract session name
        session_name = target_id.split(":")[0]
        subprocess.run(
            ["tmux", "kill-session", "-t", session_name],
            capture_output=True,  # don't raise if already dead
        )

    def resolve_target_id(self, pid: int) -> str | None:
        # tmux target_id is assigned at spawn and stored in cache; no runtime discovery.
        return None
