"""macOS Terminal.app backend for keep.

Requires Accessibility permission:
    System Settings → Privacy & Security → Accessibility
    (grant permission to the terminal running keep)

Uses CGEventPostToPid for background text injection without focus steal.
Requires pyobjc-framework-Quartz (installed automatically on first use).
"""
from __future__ import annotations
import subprocess
import sys
import time
import shlex


def _ensure_quartz():
    """Import Quartz, installing into the current Python env if necessary."""
    try:
        import Quartz
        return Quartz
    except ImportError:
        subprocess.run(
            ["uv", "pip", "install", "--python", sys.executable, "pyobjc-framework-Quartz"],
            check=True,
        )
        import Quartz
        return Quartz


def _terminal_pid() -> int:
    result = subprocess.check_output(["pgrep", "-x", "Terminal"], text=True)
    return int(result.strip().split("\n")[0])


def _inject_text(pid: int, window_id: str, text: str) -> None:
    """Inject text into a specific Terminal.app window via CGEventPostToPid."""
    Quartz = _ensure_quartz()
    # Bring target window to front within Terminal.app (no app focus steal)
    script = f'tell application "Terminal" to set frontmost of (first window whose id is {window_id}) to true'
    subprocess.run(["osascript", "-e", script], capture_output=True)
    time.sleep(0.2)
    for char in text:
        kd = Quartz.CGEventCreateKeyboardEvent(None, 0, True)
        ku = Quartz.CGEventCreateKeyboardEvent(None, 0, False)
        Quartz.CGEventKeyboardSetUnicodeString(kd, len(char), char)
        Quartz.CGEventKeyboardSetUnicodeString(ku, len(char), char)
        Quartz.CGEventPostToPid(pid, kd)
        Quartz.CGEventPostToPid(pid, ku)
        time.sleep(0.015)


def _send_return(pid: int) -> None:
    """Send Return key (key code 36) via CGEvent."""
    Quartz = _ensure_quartz()
    kd = Quartz.CGEventCreateKeyboardEvent(None, 36, True)
    ku = Quartz.CGEventCreateKeyboardEvent(None, 36, False)
    Quartz.CGEventPostToPid(pid, kd)
    Quartz.CGEventPostToPid(pid, ku)


class TerminalAppTerminal:
    def new_surface(self, cwd: str, cmd: str) -> str:
        """Open a new Terminal.app window running cmd in cwd. Returns window id."""
        safe_cwd = shlex.quote(cwd)
        safe_cmd = cmd.replace('"', '\\"')
        script = f'''
tell application "Terminal"
    set t to do script "cd {safe_cwd} && {safe_cmd}"
    delay 0.5
    return id of front window as string
end tell
'''
        result = subprocess.check_output(["osascript", "-e", script], text=True).strip()
        return result  # window id as string

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then Return to Terminal.app without focus steal.

        CRITICAL: do NOT shorten the sleep. See keep/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. Even with
          CGEvent-based per-character injection, back-to-back CGEvents
          can be coalesced by the input system into a single paste
          burst. If that burst ends with Return, Return lands inside
          the bracketed-paste envelope and is treated as a multi-line
          newline, NOT submit — the message stays stuck in the input
          buffer.

          Sleeping ~2s between the last character event and the Return
          keystroke lets the TUI close the paste envelope before Return
          arrives, so Return is interpreted as Enter. Matches
          cmux/kitty/tmux/iterm2.
        """
        pid = _terminal_pid()
        _inject_text(pid, target_id, text)
        time.sleep(2)
        _send_return(pid)

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to Terminal.app window."""
        Quartz = _ensure_quartz()
        pid = _terminal_pid()
        # Key code map for macOS
        key_codes = {"escape": 53, "enter": 36, "ctrl-c": None}
        if key == "ctrl-c":
            # Send Ctrl+C via CGEvent with control modifier
            ev = Quartz.CGEventCreateKeyboardEvent(None, 8, True)  # 'c' key
            Quartz.CGEventSetFlags(ev, Quartz.kCGEventFlagMaskControl)
            Quartz.CGEventPostToPid(pid, ev)
            ev2 = Quartz.CGEventCreateKeyboardEvent(None, 8, False)
            Quartz.CGEventPostToPid(pid, ev2)
        else:
            code = key_codes.get(key, 36)
            kd = Quartz.CGEventCreateKeyboardEvent(None, code, True)
            ku = Quartz.CGEventCreateKeyboardEvent(None, code, False)
            Quartz.CGEventPostToPid(pid, kd)
            Quartz.CGEventPostToPid(pid, ku)

    def read_screen(self, target_id: str) -> str:
        script = f'tell application "Terminal" to contents of tab 1 of (first window whose id is {target_id})'
        return subprocess.check_output(["osascript", "-e", script], text=True)

    def close(self, target_id: str) -> None:
        # Step 1: get tty of the window so we can kill all processes without a dialog
        tty_script = f'tell application "Terminal" to tty of selected tab of (first window whose id is {target_id})'
        r = subprocess.run(["osascript", "-e", tty_script], capture_output=True, text=True)
        tty = r.stdout.strip()
        if tty:
            # Kill all processes on the tty (avoids "Terminate running processes?" dialog)
            pids = subprocess.run(["lsof", "-t", tty], capture_output=True, text=True).stdout.split()
            for pid in pids:
                subprocess.run(["kill", "-9", pid], capture_output=True)
            time.sleep(0.5)
        # Step 2: close the now-empty window
        close_script = f'tell application "Terminal" to close (first window whose id is {target_id}) saving no'
        subprocess.run(["osascript", "-e", close_script], capture_output=True)

    def resolve_target_id(self, pid: int) -> str | None:
        # Terminal.app window id is assigned at spawn and stored in cache; no runtime discovery.
        return None
