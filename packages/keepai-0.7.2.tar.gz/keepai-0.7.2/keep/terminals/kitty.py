"""Kitty terminal backend for keep.

Requires in ~/.config/kitty/kitty.conf:
    allow_remote_control yes
    listen_on unix:/tmp/kitty.sock   # or any path; set KITTY_LISTEN_ON env var

The socket path is read from KITTY_LISTEN_ON environment variable of the
running Claude Code process (same pattern as CMUX_SURFACE_ID for cmux).
"""
from __future__ import annotations
import subprocess
import os
import time


class KittyTerminal:
    def __init__(self, socket_path: str | None = None):
        self._socket = socket_path or os.environ.get("KITTY_LISTEN_ON", "")
        if not self._socket:
            raise RuntimeError(
                "Kitty socket not configured. Set KITTY_LISTEN_ON env var or "
                "add 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf "
                "and 'allow_remote_control yes'."
            )

    def _run(self, *args: str) -> str:
        cmd = ["kitty", "@", "--to", self._socket, *args]
        return subprocess.check_output(cmd, text=True).strip()

    def _run_silent(self, *args: str) -> None:
        cmd = ["kitty", "@", "--to", self._socket, *args]
        subprocess.run(cmd, capture_output=True)

    def new_surface(self, cwd: str, cmd: str) -> str:
        """Open a new Kitty window running cmd in cwd. Returns window id as string."""
        # Pass cmd via bash -c to preserve quoting and spaces in arguments
        window_id = self._run(
            "new-window", "--new-tab", "--cwd", cwd, "--", "bash", "-c", cmd
        )
        return window_id  # e.g. "4"

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then CR to Kitty window as two separate calls.

        CRITICAL: do NOT collapse into one `send-text ... text + "\\r"`,
        and do NOT shorten the sleep. See keep/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. When a terminal
          wraps a payload in "\\e[200~ ... \\e[201~" (either because the
          terminal auto-bracketed a paste-sized write, or because a future
          kitty version starts doing it), ANY "\\r" inside that envelope
          is interpreted as a multi-line newline, NOT submit — the
          message stays stuck in the input buffer.

          Splitting the body and CR into two `send-text` calls with a
          ~2s gap in between ensures the CR lands OUTSIDE any paste
          envelope, so the TUI treats it as Enter.

          Kitty's `send-text` today does not bracket by default, but
          aligning all backends on this pattern removes a whole class of
          future regressions and matches cmux/iterm2.
        """
        self._run_silent(
            "send-text", "--match", f"id:{target_id}", text
        )
        time.sleep(2)
        self._run_silent(
            "send-text", "--match", f"id:{target_id}", "\r"
        )

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key. Raises ValueError for unsupported keys."""
        key_map = {"escape": "\x1b", "enter": "\r", "ctrl-c": "\x03"}
        if key not in key_map:
            raise ValueError(f"Kitty: unsupported key {key!r}; valid: {sorted(key_map)}")
        self._run_silent(
            "send-text", "--match", f"id:{target_id}", key_map[key]
        )

    def read_screen(self, target_id: str) -> str:
        return self._run(
            "get-text", "--match", f"id:{target_id}", "--extent", "screen"
        )

    def close(self, target_id: str) -> None:
        self._run_silent("close-window", "--match", f"id:{target_id}")

    def resolve_target_id(self, pid: int) -> str | None:
        # Kitty window id is assigned at spawn and stored in cache; no runtime discovery.
        return None
