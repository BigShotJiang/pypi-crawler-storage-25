"""`keep <mission_id> reviewer ...` verb dispatch.

Reviewer CRUD plus the per-event verdict subcommand:
  keep <m> reviewer <event_id> pass|reject [file] [--reviewer-id ID]
"""

from __future__ import annotations

import json
from pathlib import Path

import typer

from keep._cli.constants import REVIEW_EVENT_TERMINAL_VERDICTS
from keep._cli.contracts import (
    build_reviewer_bootstrap_prompt_v1,
    build_reviewer_contract_v1,
    build_reviewer_layer1,
)
from keep._cli.helpers import (
    ensure_file_in_messages_dir,
    extract_named_option,
    generate_session_id,
    parse_name_path_update,
    resolve_reviewer_id_by_prefix_or_fail,
    validate_spawn_path_or_fail,
)
from keep._cli import spawn as _spawn_mod
from keep.state import (
    add_reviewer,
    get_review_event,
    get_reviewer,
    iter_reviewers,
    mission_terminal_type,
    remove_reviewer,
    update_review_event,
    update_reviewer,
)


def _resolve_reviewer_file(name: str | None, path_val: str | None) -> Path:
    if path_val is not None:
        return Path(path_val).expanduser().resolve()
    if name is not None:
        reviewers_dir = Path.home() / ".keep" / "reviewers"
        return reviewers_dir / f"{name}.md"
    typer.echo("--name or --path is required", err=True)
    raise typer.Exit(2)


def _cmd_create(mission_id: str, mission: dict, payload: list[str]) -> None:
    name, rest = extract_named_option(payload, "--name")
    path_val, rest = extract_named_option(rest, "--path")
    if rest:
        typer.echo("No such argument", err=True)
        raise typer.Exit(2)

    reviewer_file = _resolve_reviewer_file(name, path_val)
    if not reviewer_file.is_file():
        typer.echo(f"Reviewer file not found: {reviewer_file}", err=True)
        raise typer.Exit(1)

    reviewer_name = name or reviewer_file.stem
    layer1 = build_reviewer_layer1(mission_id, reviewer_name)
    layer2 = reviewer_file.read_text(encoding="utf-8")
    append_system_prompt = build_reviewer_contract_v1(layer1, layer2)
    validate_spawn_path_or_fail(None)

    session = generate_session_id()
    reviewer_data_tmp: dict = {
        "name": reviewer_name,
        "path": str(reviewer_file),
        "status": "inactive",
        "system_prompt": append_system_prompt,
    }
    reviewer_id = add_reviewer(mission_id, reviewer_data_tmp)
    bootstrap_prompt = build_reviewer_bootstrap_prompt_v1(
        mission_id, session, reviewer_id, reviewer_name
    )
    terminal_type = mission_terminal_type(mission)
    reviewer_cache, _info = _spawn_mod.spawn_and_wait_for_ready(
        session,
        None,
        terminal_type=terminal_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        on_failure=lambda: remove_reviewer(mission_id, reviewer_id),
    )
    update_reviewer(
        mission_id, reviewer_id,
        session=session, status="active", cache=reviewer_cache,
    )
    typer.echo(f"Reviewer '{reviewer_name}' ({reviewer_id[:8]}) 已创建。")
    # Signal daemon to sync mission to the new reviewer
    from keep.daemon import mission_sync_signal_file
    mission_sync_signal_file(mission_id).write_text("")


def _cmd_list(mission_id: str) -> None:
    try:
        reviewers = list(iter_reviewers(mission_id))
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if not reviewers:
        typer.echo("(无 reviewer)")
        return
    for r in reviewers:
        rid = r.get("id", "?")
        rname = r.get("name", "")
        rstatus = r.get("status", "?")
        typer.echo(f"{rid}  {rname}  [{rstatus}]")


def _cmd_show(mission_id: str, payload: list[str]) -> None:
    if not payload:
        typer.echo("reviewer_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_reviewer_id_by_prefix_or_fail(mission_id=mission_id, raw_id=payload[0])
    try:
        reviewer = get_reviewer(mission_id, resolved)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(reviewer, ensure_ascii=False, indent=2))


def _cmd_update(mission_id: str, payload: list[str]) -> None:
    reviewer_id_raw, name, path_val = parse_name_path_update(payload, id_label="reviewer_id")
    resolved = resolve_reviewer_id_by_prefix_or_fail(
        mission_id=mission_id, raw_id=reviewer_id_raw,
    )
    kwargs: dict = {}
    if name is not None:
        kwargs["name"] = name
    if path_val is not None:
        kwargs["path"] = path_val
    try:
        update_reviewer(mission_id, resolved, **kwargs)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Reviewer '{resolved}' 已更新。")


def _cmd_remove(mission_id: str, mission: dict, payload: list[str]) -> None:
    if not payload:
        typer.echo("reviewer_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_reviewer_id_by_prefix_or_fail(mission_id=mission_id, raw_id=payload[0])
    reviewer = get_reviewer(mission_id, resolved)
    reviewer_session = reviewer.get("session") if reviewer else None
    if reviewer:
        _spawn_mod.kill_and_close_worker(reviewer, mission)
    try:
        remove_reviewer(mission_id, resolved)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if reviewer_session:
        from keep._daemon import runtime_state as _rt
        _rt.purge_worker(mission_id, reviewer_session)
    typer.echo(f"Reviewer '{resolved}' 已删除。")


def _cmd_verdict(
    mission_id: str, mission: dict, event_id_candidate: str, payload: list[str]
) -> None:
    """`keep <m> reviewer <event_id> pass|reject [file] [--reviewer-id ID]`."""
    verdict = payload[0]
    remaining = payload[1:]
    # Extract optional --reviewer-id flag
    explicit_reviewer_id: str | None = None
    if "--reviewer-id" in remaining:
        idx = remaining.index("--reviewer-id")
        if idx + 1 < len(remaining):
            explicit_reviewer_id = remaining[idx + 1]
            remaining = remaining[:idx] + remaining[idx + 2:]
    verdict_file_args = remaining

    if verdict == "reject" and not verdict_file_args:
        typer.echo("reject requires a rationale_msg_file", err=True)
        raise typer.Exit(1)

    rationale_content: str | None = None
    if verdict_file_args:
        final_path = ensure_file_in_messages_dir(
            mission, verdict_file_args[0],
            label="rationale file", record_index=True,
        )
        rationale_content = str(final_path)

    try:
        event = get_review_event(mission_id, event_id_candidate)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    if event.get("final_verdict") or event.get("verdict") in REVIEW_EVENT_TERMINAL_VERDICTS:
        terminal = event.get("final_verdict") or event.get("verdict")
        typer.echo(
            f"Review event '{event_id_candidate}' 已是终态 ({terminal})，无法再次判决。",
            err=True,
        )
        raise typer.Exit(1)

    verdict_by = _resolve_verdict_by(mission_id, explicit_reviewer_id)

    update_kwargs: dict = {"verdict": verdict}
    if rationale_content is not None:
        update_kwargs["rationale"] = rationale_content
    if verdict_by is not None:
        update_kwargs["verdict_by"] = verdict_by
        existing_verdicts = dict(event.get("reviewer_verdicts") or {})
        existing_verdicts[verdict_by] = verdict
        update_kwargs["reviewer_verdicts"] = existing_verdicts

    try:
        update_review_event(mission_id, event_id_candidate, **update_kwargs)
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    typer.echo(f"Review event '{event_id_candidate}' 判决: {verdict}。")


def _resolve_verdict_by(mission_id: str, explicit_reviewer_id: str | None) -> str | None:
    """Reviewer UUID to stamp on the verdict, if determinable.

    Daemon aggregates by UUID, not name. Explicit flag wins; otherwise we only
    auto-stamp when there's exactly one reviewer registered (no ambiguity).
    """
    if explicit_reviewer_id is not None:
        return resolve_reviewer_id_by_prefix_or_fail(
            mission_id=mission_id, raw_id=explicit_reviewer_id,
        )
    try:
        all_reviewers = list(iter_reviewers(mission_id))
        if len(all_reviewers) == 1:
            return all_reviewers[0].get("id")
    except ValueError:
        pass
    return None


def dispatch(mission_id: str, mission: dict, command: str | None, payload: list[str]) -> None:
    if command == "create":
        _cmd_create(mission_id, mission, payload)
    elif command == "list":
        _cmd_list(mission_id)
    elif command == "show":
        _cmd_show(mission_id, payload)
    elif command == "update":
        _cmd_update(mission_id, payload)
    elif command == "remove":
        _cmd_remove(mission_id, mission, payload)
    # Reviewer verdict subcommands: keep <m> reviewer <event_id> pass|reject [file]
    # Here `command` is actually the event_id, and `payload` holds [pass|reject, ...]
    elif command is not None and payload and payload[0] in {"pass", "reject"}:
        _cmd_verdict(mission_id, mission, command, payload)
    else:
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)
