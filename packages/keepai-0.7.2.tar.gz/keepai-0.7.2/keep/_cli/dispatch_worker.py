"""`keep <mission_id> worker ...` verb dispatch."""

from __future__ import annotations

import json

import typer

from keep._cli.contracts import (
    build_contract_metadata,
    build_worker_bootstrap_prompt_v1,
    build_worker_contract_v1,
)
from keep._cli.helpers import (
    extract_named_option,
    generate_session_id,
    parse_name_path_update,
    require_mission_active,
    resolve_session_id_by_prefix_or_fail,
    validate_spawn_path_or_fail,
)
from keep._cli import spawn as _spawn_mod
from keep.state import (
    add_worker,
    find_worker,
    iter_workers,
    mission_terminal_type,
    mutate_mission,
    remove_worker,
)
from keep.worker import resolve_worker, worker_cache_from_info


def _register_existing_session(
    mission_id: str,
    mission: dict,
    *,
    existing_session: str,
    name: str | None,
    path: str | None,
) -> None:
    require_mission_active(mission_id, mission)
    info = resolve_worker(existing_session, mission_terminal_type(mission))
    if info.jsonl_path is None:
        typer.echo(
            f"session 不存在或尚未产生对话记录: '{existing_session}'",
            err=True,
        )
        raise typer.Exit(1)
    add_worker(
        mission_id,
        existing_session,
        cache=worker_cache_from_info(info),
        name=name,
        path=path,
        contract=None,
        bootstrapped=True,
    )
    typer.echo(f"Worker '{existing_session}' 已创建。")


def _spawn_new_worker(
    mission_id: str,
    mission: dict,
    *,
    name: str | None,
    path: str | None,
) -> None:
    require_mission_active(mission_id, mission)
    validate_spawn_path_or_fail(path)
    session = generate_session_id()
    append_system_prompt = build_worker_contract_v1()
    bootstrap_prompt = build_worker_bootstrap_prompt_v1(mission_id, session, name)
    contract = build_contract_metadata("worker", append_system_prompt, bootstrap_prompt)
    terminal_type = mission_terminal_type(mission)
    cache, _info = _spawn_mod.spawn_and_wait_for_ready(
        session,
        path,
        terminal_type=terminal_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
    )
    add_worker(
        mission_id,
        session,
        cache=cache,
        name=name,
        path=path,
        contract=contract,
    )
    typer.echo(f"Worker '{session}' 已创建。")


def _cmd_create(mission_id: str, mission: dict, payload: list[str]) -> None:
    name, rest = extract_named_option(payload, "--name")
    path, rest = extract_named_option(rest, "--path")
    existing_session, rest = extract_named_option(rest, "--session")
    if rest:
        typer.echo("No such argument", err=True)
        raise typer.Exit(2)

    if existing_session is not None:
        _register_existing_session(
            mission_id, mission,
            existing_session=existing_session, name=name, path=path,
        )
    else:
        _spawn_new_worker(mission_id, mission, name=name, path=path)


def _cmd_list(mission: dict) -> None:
    workers = iter_workers(mission)
    if not workers:
        typer.echo("(无 worker)")
        return
    typer.echo("\n".join(worker["session"] for worker in workers))


def _cmd_show(mission: dict, payload: list[str]) -> None:
    if not payload:
        typer.echo("worker_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    worker = find_worker(mission, resolved)
    if worker is None:
        typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(worker, ensure_ascii=False, indent=2))


def _cmd_update(mission_id: str, mission: dict, payload: list[str]) -> None:
    worker_id, name, path = parse_name_path_update(payload, id_label="worker_id")
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="worker",
        raw_id=worker_id,
        id_label="worker_id",
    )
    worker = find_worker(mission, resolved)
    if worker is None:
        typer.echo(f"Worker '{worker_id}' 不存在", err=True)
        raise typer.Exit(1)
    with mutate_mission(mission_id) as locked_mission:
        locked_worker = find_worker(locked_mission, resolved)
        if locked_worker is None:
            typer.echo(f"Worker '{worker_id}' 不存在", err=True)
            raise typer.Exit(1)
        if name is not None:
            locked_worker["name"] = name
        if path is not None:
            locked_worker["path"] = path
    typer.echo(f"Worker '{resolved}' 已更新。")


def _cmd_remove(mission_id: str, mission: dict, payload: list[str]) -> None:
    if not payload:
        typer.echo("worker_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_session_id_by_prefix_or_fail(
        mission=mission,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    worker = find_worker(mission, resolved)
    if worker is None:
        typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    _spawn_mod.kill_and_close_worker(worker, mission)
    if not remove_worker(mission_id, resolved):
        typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    from keep._daemon import runtime_state as _rt
    _rt.purge_worker(mission_id, resolved)
    typer.echo(f"Worker '{resolved}' 已删除。")


def dispatch(mission_id: str, mission: dict, command: str | None, payload: list[str]) -> None:
    if command == "create":
        _cmd_create(mission_id, mission, payload)
    elif command == "list":
        _cmd_list(mission)
    elif command == "show":
        _cmd_show(mission, payload)
    elif command == "update":
        _cmd_update(mission_id, mission, payload)
    elif command == "remove":
        _cmd_remove(mission_id, mission, payload)
    else:
        typer.echo(f"No such command '{command}'", err=True)
        raise typer.Exit(2)
