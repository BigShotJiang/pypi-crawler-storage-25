"""Test-wide safety net: prevent any test from touching the user's real terminal.

The CLI's worker/supervisor/reviewer/mission remove paths call
`get_terminal(...).close(target_id)` on real cmux / Terminal.app / Kitty /
tmux. Without this fixture, a test that exercises those paths via
`runner.invoke(app, [...])` would issue real RPC calls to the user's running
terminal — which has actually closed real windows in development (including
the Claude Code session running the tests).

`keep.terminal.get_terminal` delegates to `keep.terminal._factory` at call
time, so monkeypatching that single symbol diverts every caller — no matter
how they imported `get_terminal`. Tests that need a custom terminal should
override `keep.terminal._factory` via the same monkeypatch.
"""

from __future__ import annotations

import pytest


class _NoopTerminal:
    """Fake Terminal: all operations are no-ops. Used by autouse safety fixture."""

    def new_surface(self, cwd: str, cmd: str) -> str:
        return "noop:test"

    def send_text(self, target_id: str, text: str) -> None:
        return None

    def send_key(self, target_id: str, key: str) -> None:
        return None

    def read_screen(self, target_id: str) -> str:
        return ""

    def close(self, target_id: str) -> None:
        return None

    def resolve_target_id(self, pid: int) -> str | None:
        return None


@pytest.fixture(autouse=True)
def _block_real_terminal(monkeypatch):
    monkeypatch.setattr("keep.terminal._factory", lambda terminal_type: _NoopTerminal())
    yield
