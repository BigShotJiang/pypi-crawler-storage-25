"""Tests for the iTerm2 Python API backend.

The real ``iterm2`` package is async and talks to a running iTerm2 process, so
every test here swaps in a fake module with ``AsyncMock`` coroutines for the
API surface we actually use. ``asyncio.run`` inside the backend still executes
— we're only faking the *network-facing* calls.
"""

from __future__ import annotations

import sys
import types
from typing import Any
from unittest.mock import AsyncMock, MagicMock

import pytest

from keep.terminals import iterm2 as iterm2_mod
from keep.terminals.iterm2 import ITerm2Terminal


# ---------------------------------------------------------------------------
# Fake iterm2 module
# ---------------------------------------------------------------------------


def _make_fake_iterm2(*, session_id: str = "FAKE-UUID-1234",
                     session_lookup: Any = "USE_SPAWNED",
                     screen_lines: list[str] | None = None):
    """Build a fake ``iterm2`` module covering the subset the backend uses.

    - ``session_lookup="USE_SPAWNED"`` means ``get_session_by_id`` returns the
      same session object that ``Window.async_create`` produced.
    - ``session_lookup=None`` simulates a missing session (unknown target_id).
    - Any other value is returned verbatim.
    """
    fake = types.ModuleType("iterm2")

    # Session object: async_send_text, async_close, async_get_screen_contents,
    # session_id attribute.
    session = MagicMock(name="Session")
    session.session_id = session_id
    session.async_send_text = AsyncMock(name="async_send_text")
    session.async_close = AsyncMock(name="async_close")

    contents = MagicMock(name="ScreenContents")
    lines = screen_lines if screen_lines is not None else ["hello", "world"]
    contents.number_of_lines = len(lines)
    contents.line = lambda i: MagicMock(string=lines[i])
    session.async_get_screen_contents = AsyncMock(return_value=contents)

    tab = MagicMock(current_session=session)
    window = MagicMock(current_tab=tab)

    # Window.async_create is a staticmethod-like awaitable.
    fake.Window = MagicMock()
    fake.Window.async_create = AsyncMock(return_value=window)

    # Connection.async_create → returns a bare connection sentinel.
    connection_sentinel = MagicMock(name="Connection")
    fake.Connection = MagicMock()
    fake.Connection.async_create = AsyncMock(return_value=connection_sentinel)

    # async_get_app → returns an App with get_session_by_id.
    app = MagicMock(name="App")
    if session_lookup == "USE_SPAWNED":
        app.get_session_by_id = MagicMock(return_value=session)
    else:
        app.get_session_by_id = MagicMock(return_value=session_lookup)
    fake.async_get_app = AsyncMock(return_value=app)

    # Auth submodule — authenticate() is a sync no-op; AuthenticationException
    # is a real exception type so `except` matches.
    auth_mod = types.ModuleType("iterm2.auth")

    class AuthenticationException(Exception):
        pass

    auth_mod.AuthenticationException = AuthenticationException
    auth_mod.authenticate = MagicMock(return_value=True)
    fake.auth = auth_mod

    # App submodule — the backend resets `iterm2.app.App.instance = None`
    # before each connect to force async_get_app to rebuild the singleton
    # against a fresh websocket. Provide a writable attribute.
    app_mod = types.ModuleType("iterm2.app")
    app_mod.App = MagicMock(name="App_class")
    app_mod.App.instance = None
    fake.app = app_mod

    # Expose helpers for assertions
    fake._fake_session = session
    fake._fake_window = window
    fake._fake_app = app
    fake._fake_connection = connection_sentinel
    return fake


@pytest.fixture
def fake_iterm2(monkeypatch):
    """Swap the lazy importer so every backend call uses our fake."""
    fake = _make_fake_iterm2()
    monkeypatch.setattr(iterm2_mod, "_import_iterm2", lambda: fake)
    return fake


# ---------------------------------------------------------------------------
# new_surface
# ---------------------------------------------------------------------------


def test_new_surface_spawns_window_with_baked_command_and_returns_session_id(fake_iterm2):
    term = ITerm2Terminal()
    result = term.new_surface(cwd="/tmp/work dir", cmd='echo "hi"')

    assert result == "FAKE-UUID-1234"
    fake_iterm2.Window.async_create.assert_awaited_once()
    kwargs = fake_iterm2.Window.async_create.await_args.kwargs
    cmd_arg = kwargs["command"]
    # Command should be baked into argv via /bin/bash -c with cwd + user cmd.
    assert cmd_arg.startswith("/bin/bash -c ")
    # cwd and inner cmd must survive shlex-quoting.
    assert "/tmp/work dir" in cmd_arg
    assert 'echo "hi"' in cmd_arg
    assert "cd " in cmd_arg


def test_new_surface_subscribes_app_before_creating_window(monkeypatch):
    """async_get_app MUST be awaited before Window.async_create. Under a
    short-lived asyncio.run() connection, window.current_tab stays None
    unless the App has already subscribed to notifications. This is the
    load-bearing ordering that real iTerm2 enforces."""
    fake = _make_fake_iterm2()
    call_order: list[str] = []

    async def _get_app(conn):
        call_order.append("async_get_app")
        return fake._fake_app

    async def _create(conn, command):
        call_order.append("Window.async_create")
        return fake._fake_window

    fake.async_get_app = _get_app
    fake.Window.async_create = _create
    monkeypatch.setattr(iterm2_mod, "_import_iterm2", lambda: fake)

    term = ITerm2Terminal()
    term.new_surface(cwd="/tmp", cmd="true")

    assert call_order == ["async_get_app", "Window.async_create"], (
        f"async_get_app must be awaited before Window.async_create, got {call_order}"
    )


def test_new_surface_raises_if_current_tab_none(monkeypatch):
    """If notifications weren't subscribed in time and current_tab is None,
    we should raise a clear error rather than AttributeError."""
    fake = _make_fake_iterm2()
    bad_window = MagicMock(current_tab=None)
    fake.Window.async_create = AsyncMock(return_value=bad_window)
    monkeypatch.setattr(iterm2_mod, "_import_iterm2", lambda: fake)

    term = ITerm2Terminal()
    with pytest.raises(RuntimeError, match="current_tab is None"):
        term.new_surface(cwd="/tmp", cmd="true")


def test_new_surface_raises_if_window_creation_returns_none(monkeypatch):
    fake = _make_fake_iterm2()
    fake.Window.async_create = AsyncMock(return_value=None)
    monkeypatch.setattr(iterm2_mod, "_import_iterm2", lambda: fake)

    term = ITerm2Terminal()
    with pytest.raises(RuntimeError, match="Window.async_create returned None"):
        term.new_surface(cwd="/tmp", cmd="true")


# ---------------------------------------------------------------------------
# send_text
# ---------------------------------------------------------------------------


def test_send_text_sends_body_and_cr_as_two_separate_calls(fake_iterm2, monkeypatch):
    # The real backend sleeps 2s between body and CR to let the Claude Code
    # TUI close its bracketed-paste envelope before Enter lands — see the
    # comment in keep/terminals/iterm2.py send_text(). In the test we just
    # need to assert the two-call pattern, so skip the real sleep.
    monkeypatch.setattr(iterm2_mod.asyncio, "sleep", AsyncMock())

    term = ITerm2Terminal()
    term.send_text("ABCD-1234", 'hello "world"')

    fake_iterm2.async_get_app.assert_awaited_once()
    fake_iterm2._fake_app.get_session_by_id.assert_called_once_with("ABCD-1234")

    # CRITICAL assertion: body and CR must be TWO separate async_send_text
    # calls, not concatenated. Collapsing them re-introduces the
    # bracketed-paste-submit regression.
    calls = fake_iterm2._fake_session.async_send_text.await_args_list
    assert len(calls) == 2, f"expected 2 send_text calls, got {len(calls)}: {calls}"
    assert calls[0].args == ('hello "world"',), f"first call should be body only: {calls[0]}"
    assert calls[1].args == ("\r",), f"second call should be lone CR: {calls[1]}"

    # And the sleep between them must actually be awaited.
    iterm2_mod.asyncio.sleep.assert_awaited_once_with(2)


# ---------------------------------------------------------------------------
# send_key
# ---------------------------------------------------------------------------


def test_send_key_enter_sends_carriage_return(fake_iterm2):
    term = ITerm2Terminal()
    term.send_key("SESSION-XYZ", "enter")

    fake_iterm2._fake_session.async_send_text.assert_awaited_once_with("\r")


def test_send_key_ctrl_c_sends_etx(fake_iterm2):
    term = ITerm2Terminal()
    term.send_key("S", "ctrl-c")

    fake_iterm2._fake_session.async_send_text.assert_awaited_once_with("\x03")


def test_send_key_escape_sends_esc(fake_iterm2):
    term = ITerm2Terminal()
    term.send_key("S", "escape")

    fake_iterm2._fake_session.async_send_text.assert_awaited_once_with("\x1b")


def test_send_key_rejects_unknown_key():
    # Unknown key is rejected BEFORE any iterm2 import/network call, so no
    # fake module is needed. ValueError mentions "unsupported".
    term = ITerm2Terminal()
    with pytest.raises(ValueError, match="unsupported key"):
        term.send_key("ABCD", "f1")


# ---------------------------------------------------------------------------
# read_screen
# ---------------------------------------------------------------------------


def test_read_screen_joins_lines_from_screen_contents(monkeypatch):
    fake = _make_fake_iterm2(screen_lines=["line one", "line two", "line three"])
    monkeypatch.setattr(iterm2_mod, "_import_iterm2", lambda: fake)

    term = ITerm2Terminal()
    out = term.read_screen("SESSION-1")

    assert out == "line one\nline two\nline three"


# ---------------------------------------------------------------------------
# close
# ---------------------------------------------------------------------------


def test_close_uses_async_close_with_force_true(fake_iterm2):
    term = ITerm2Terminal()
    term.close("UUID-TO-CLOSE")

    fake_iterm2._fake_app.get_session_by_id.assert_called_once_with("UUID-TO-CLOSE")
    fake_iterm2._fake_session.async_close.assert_awaited_once()
    # force=True is the whole point of switching off AppleScript — assert it
    # explicitly rather than trusting positional defaults.
    kwargs = fake_iterm2._fake_session.async_close.await_args.kwargs
    assert kwargs.get("force") is True


def test_close_raises_when_session_not_found(monkeypatch):
    fake = _make_fake_iterm2(session_lookup=None)
    monkeypatch.setattr(iterm2_mod, "_import_iterm2", lambda: fake)

    term = ITerm2Terminal()
    with pytest.raises(RuntimeError, match="UUID-GONE"):
        term.close("UUID-GONE")


# ---------------------------------------------------------------------------
# resolve_target_id
# ---------------------------------------------------------------------------


def test_resolve_target_id_returns_none():
    # Does not touch iterm2 at all.
    term = ITerm2Terminal()
    assert term.resolve_target_id(12345) is None


# ---------------------------------------------------------------------------
# Install / environment errors
# ---------------------------------------------------------------------------


def test_missing_iterm2_package_raises_with_install_hint(monkeypatch):
    """If `import iterm2` fails, the backend should nudge the user to uv add."""
    # Hide any real iterm2 module and make import fail.
    monkeypatch.setitem(sys.modules, "iterm2", None)

    term = ITerm2Terminal()
    with pytest.raises(RuntimeError, match="uv add iterm2"):
        term.send_key("S", "enter")  # goes through _import_iterm2 after key validation


# ---------------------------------------------------------------------------
# Factory / registration
# ---------------------------------------------------------------------------


def test_factory_returns_iterm2_terminal():
    """The default factory in keep.terminal must resolve 'iterm2'."""
    from keep.terminal import _default_factory

    inst = _default_factory("iterm2")
    assert isinstance(inst, ITerm2Terminal)


def test_iterm2_in_valid_terminals():
    from keep._state.paths import VALID_TERMINALS

    assert "iterm2" in VALID_TERMINALS
