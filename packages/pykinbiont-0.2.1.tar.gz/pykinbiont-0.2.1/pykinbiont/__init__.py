"""pykinbiont — Python interface for KinBiont.jl.

Quick start
-----------
>>> import pykinbiont
>>> pykinbiont.configure("/path/to/KinBiont.jl")   # once, persists to disk
>>> from pykinbiont import GrowthData, FitOptions, ModelSpec, LogLinModel, fit
>>> data = GrowthData.from_csv("experiment.csv")
>>> opts = FitOptions(smooth=True, cluster=True, n_clusters=3)
>>> spec = ModelSpec(models=[LogLinModel()], params=[[]])
>>> results = fit(data, spec, opts)
>>> results.to_dataframe()
"""

from pykinbiont._core import configure, init, get_jl

from pykinbiont.types import (
    GrowthData,
    IrregularGrowthData,
    FitOptions,
    ModelSpec,
    CurveFitResult,
    GrowthFitResults,
)

from pykinbiont.models import (
    AbstractGrowthModel,
    NLModel,
    ODEModel,
    LogLinModel,
    DDDEModel,
    MODEL_REGISTRY,
)

from pykinbiont.fit import fit, preprocess

from pykinbiont.io import save_results

__all__ = [
    # bridge
    "configure",
    "init",
    "get_jl",
    # data
    "GrowthData",
    "IrregularGrowthData",
    # config
    "FitOptions",
    # models
    "AbstractGrowthModel",
    "NLModel",
    "ODEModel",
    "LogLinModel",
    "DDDEModel",
    "ModelSpec",
    "MODEL_REGISTRY",
    # results
    "CurveFitResult",
    "GrowthFitResults",
    # functions
    "fit",
    "preprocess",
    "save_results",
]
