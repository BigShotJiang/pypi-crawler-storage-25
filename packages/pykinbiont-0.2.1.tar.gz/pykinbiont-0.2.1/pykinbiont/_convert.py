"""Internal Python↔Julia type conversion. Never import this in user code."""

from __future__ import annotations

from typing import TYPE_CHECKING
import numpy as np

from pykinbiont._core import get_jl

__all__ = [
    "py_to_jl_growth_data",
    "py_to_jl_irregular",
    "py_to_jl_fit_options",
    "py_to_jl_model_spec",
    "jl_to_py_growth_fit_results",
]

if TYPE_CHECKING:
    from pykinbiont.types import (
        GrowthData, IrregularGrowthData, FitOptions, ModelSpec,
        GrowthFitResults, CurveFitResult,
    )
    from pykinbiont.models import AbstractGrowthModel


# ---------------------------------------------------------------------------
# Python → Julia
# ---------------------------------------------------------------------------

def py_to_jl_growth_data(gd: "GrowthData"):
    """Convert Python GrowthData to Julia Kinbiont.GrowthData."""
    jl = get_jl()
    curves = np.ascontiguousarray(gd.curves, dtype=np.float64)
    times  = np.ascontiguousarray(gd.times, dtype=np.float64)
    return jl.Kinbiont.GrowthData(curves, times, list(gd.labels))


def py_to_jl_irregular(igd: "IrregularGrowthData"):
    """Convert Python IrregularGrowthData to Julia Kinbiont.IrregularGrowthData."""
    jl = get_jl()
    raw_curves = [np.ascontiguousarray(c, dtype=np.float64) for c in igd.raw_curves]
    raw_times  = [np.ascontiguousarray(t, dtype=np.float64) for t in igd.raw_times]
    return jl.Kinbiont.IrregularGrowthData(raw_curves, raw_times, list(igd.labels),
                                            step=float(igd.step))


def py_to_jl_fit_options(opts: "FitOptions"):
    """Convert Python FitOptions to Julia Kinbiont.FitOptions."""
    jl = get_jl()

    def sym(s: str):
        return jl.seval(f":{s}")

    # Build Julia NamedTuple for opt_params
    # opt_params keys and values are validated in FitOptions.__post_init__
    # (identifier-only keys, numeric values only) so seval is safe here.
    if opts.opt_params:
        nt_parts = ", ".join(f"{k} = {v!r}" for k, v in opts.opt_params.items())
        opt_params_jl = jl.seval(f"(; {nt_parts})")
    else:
        opt_params_jl = jl.seval("(;)")

    # gaussian_time_grid: None → Julia nothing, else pass array
    gtg = (
        None if opts.gaussian_time_grid is None
        else np.ascontiguousarray(opts.gaussian_time_grid, dtype=np.float64)
    )

    return jl.Kinbiont.FitOptions(
        smooth                        = opts.smooth,
        smooth_method                 = sym(opts.smooth_method),
        smooth_pt_avg                 = opts.smooth_pt_avg,
        boxcar_window                 = opts.boxcar_window,
        lowess_frac                   = opts.lowess_frac,
        gaussian_h_mult               = opts.gaussian_h_mult,
        gaussian_time_grid            = gtg,
        average_replicates            = opts.average_replicates,
        blank_subtraction             = opts.blank_subtraction,
        blank_value                   = opts.blank_value,
        blank_from_labels             = opts.blank_from_labels,
        correct_negatives             = opts.correct_negatives,
        negative_method               = sym(opts.negative_method),
        negative_threshold            = opts.negative_threshold,
        scattering_correction         = opts.scattering_correction,
        calibration_file              = opts.calibration_file,
        scattering_method             = sym(opts.scattering_method),
        cut_stationary_phase          = opts.cut_stationary_phase,
        stationary_percentile_thr     = opts.stationary_percentile_thr,
        stationary_pt_smooth_derivative = opts.stationary_pt_smooth_derivative,
        stationary_win_size           = opts.stationary_win_size,
        stationary_thr_od             = opts.stationary_thr_od,
        cluster                       = opts.cluster,
        n_clusters                    = opts.n_clusters,
        cluster_trend_test            = opts.cluster_trend_test,
        cluster_prescreen_constant    = opts.cluster_prescreen_constant,
        cluster_tol_const             = opts.cluster_tol_const,
        cluster_q_low                 = opts.cluster_q_low,
        cluster_q_high                = opts.cluster_q_high,
        cluster_exp_prototype         = opts.cluster_exp_prototype,
        kmeans_n_init                 = opts.kmeans_n_init,
        kmeans_max_iters              = opts.kmeans_max_iters,
        kmeans_tol                    = opts.kmeans_tol,
        kmeans_seed                   = opts.kmeans_seed,
        loss                          = opts.loss,
        multistart                    = opts.multistart,
        n_restart                     = opts.n_restart,
        aic_correction                = opts.aic_correction,
        pt_smooth_derivative          = opts.pt_smooth_derivative,
        opt_params                    = opt_params_jl,
    )


def _wrap_callable_for_julia(func, jl):
    """Wrap a Python callable so Julia can invoke it as (p, t) -> y.

    juliacall passes Julia arrays as Python objects when calling back into Python.
    We convert them to numpy, call the Python function, and return the result.
    juliacall handles the return-value conversion automatically.
    """
    def julia_callable(p, t):
        p_np = np.asarray(p, dtype=np.float64)
        t_np = np.asarray(t, dtype=np.float64) if hasattr(t, "__len__") else float(t)
        result = func(p_np, t_np)
        return np.asarray(result, dtype=np.float64)
    return julia_callable


def _wrap_ode_callable_for_julia(func, jl):
    """Wrap a Python ODE callable for Julia's in-place SciML signature ``f!(du, u, p, t)``.

    The Python function must have signature ``func(du, u, p, t)`` where:
    - du: output array (modified in place)
    - u: state array
    - p: parameter array
    - t: scalar time
    """
    def julia_callable(du, u, p, t):
        du_np = np.asarray(du, dtype=np.float64)
        u_np  = np.asarray(u,  dtype=np.float64)
        p_np  = np.asarray(p,  dtype=np.float64)
        t_f   = float(t)
        func(du_np, u_np, p_np, t_f)
        # Copy result back if du is a Julia array (juliacall may or may not share memory)
        for i in range(len(du_np)):
            du[i] = du_np[i]
    return julia_callable


def py_to_jl_model_spec(spec: "ModelSpec"):
    """Convert Python ModelSpec to Julia Kinbiont.ModelSpec."""
    from pykinbiont.models import NLModel, ODEModel, LogLinModel, DDDEModel
    jl = get_jl()

    jl_models = []
    for model in spec.models:
        if isinstance(model, LogLinModel):
            jl_models.append(jl.Kinbiont.LogLinModel())

        elif isinstance(model, DDDEModel):
            jl_models.append(jl.Kinbiont.DDDEModel(
                max_degree  = model.max_degree,
                lambda_min  = model.lambda_min,
                lambda_max  = model.lambda_max,
                lambda_step = model.lambda_step,
            ))

        elif isinstance(model, NLModel):
            if model.func is not None:
                # Custom callable — wrap as a proper Julia Function then construct NLModel.
                # NLModel.func is typed ::Function; passing a raw Py object fails.
                wrapped = _wrap_callable_for_julia(model.func, jl)
                jl_func = jl._pykinbiont_make_nl_func(wrapped)
                jl_models.append(jl.Kinbiont.NLModel(
                    model.name, jl_func, list(model.param_names)
                ))
            else:
                # Built-in — fetch from Julia registry
                jl_models.append(jl.Kinbiont.MODEL_REGISTRY[model.name])

        elif isinstance(model, ODEModel):
            if model.func is not None:
                wrapped = _wrap_ode_callable_for_julia(model.func, jl)
                jl_func = jl._pykinbiont_make_ode_func(wrapped)
                jl_models.append(jl.Kinbiont.ODEModel(
                    model.name, jl_func, list(model.param_names), model.n_eq
                ))
            else:
                jl_models.append(jl.Kinbiont.MODEL_REGISTRY[model.name])

        else:
            raise TypeError(f"Unknown model type: {type(model)}")

    # PythonCall cannot auto-convert Python lists to the Julia types required by
    # ModelSpec's fields.  Build each field as a proper Julia typed vector.
    jl_push = jl.seval("push!")

    # models::Vector{<:AbstractGrowthModel}
    models_vec = jl.seval("Kinbiont.AbstractGrowthModel[]")
    for m in jl_models:
        jl_push(models_vec, m)

    # params::Vector{Vector{Float64}}
    params_vec = jl.seval("Vector{Float64}[]")
    for p in spec.params:
        p_jl = jl.seval("Float64[]")
        for x in p:
            jl_push(p_jl, float(x))
        jl_push(params_vec, p_jl)

    # lower / upper :: Union{Nothing, Vector{Union{Nothing, Vector{Float64}}}}
    def _build_bounds(bounds):
        if bounds is None:
            return None
        outer = jl.seval("Union{Nothing, Vector{Float64}}[]")
        for b in bounds:
            if b is None:
                jl_push(outer, None)
            else:
                b_jl = jl.seval("Float64[]")
                for x in b:
                    jl_push(b_jl, float(x))
                jl_push(outer, b_jl)
        return outer

    lower_vec = _build_bounds(spec.lower)
    upper_vec = _build_bounds(spec.upper)

    return jl.Kinbiont.ModelSpec(models_vec, params_vec, lower=lower_vec, upper=upper_vec)


def jl_to_py_growth_fit_results(jl_res) -> "GrowthFitResults":
    """Parse a Julia GrowthFitResults struct into Python result types."""
    from pykinbiont.types import GrowthData, CurveFitResult, GrowthFitResults

    jl_data = jl_res.data

    # Clustering fields: juliacall returns Julia nothing as Python None
    clusters  = (
        np.array(jl_data.clusters, dtype=int)
        if jl_data.clusters is not None else None
    )
    centroids = (
        np.array(jl_data.centroids, dtype=np.float64)
        if jl_data.centroids is not None else None
    )
    wcss = float(jl_data.wcss) if jl_data.wcss is not None else None

    data = GrowthData(
        curves    = np.array(jl_data.curves, dtype=np.float64),
        times     = np.array(jl_data.times,  dtype=np.float64),
        labels    = [str(lb) for lb in jl_data.labels],
        clusters  = clusters,
        centroids = centroids,
        wcss      = wcss,
    )

    results = [_parse_curve_fit_result(r) for r in jl_res.results]
    return GrowthFitResults(data=data, results=results)


def _safe_float_list(jl_vec) -> list:
    """Convert a Julia Vector{Any} to a Python list of floats.

    KinBiont's legacy fitting functions (e.g. LogLinModel) embed metadata strings
    (label, well name) as the first elements of the params vector alongside the
    actual numeric values.  We skip any element that can't be converted to float
    so callers get a clean numeric list regardless of model type.
    """
    result = []
    for p in jl_vec:
        try:
            result.append(float(p))
        except (ValueError, TypeError):
            pass  # skip strings and Julia missing / nothing values
    return result


def _parse_curve_fit_result(jl_r) -> "CurveFitResult":
    from pykinbiont.types import CurveFitResult

    best_model = jl_r.best_model
    model_name = str(best_model.name) if hasattr(best_model, "name") else "log_lin"
    param_names = (
        [str(p) for p in best_model.param_names]
        if hasattr(best_model, "param_names") else []
    )

    all_results = [
        {
            "model_name": str(c.model_name),
            "params":     _safe_float_list(c.params),
            "aic":        float(c.aic),
            "loss":       float(c.loss),
        }
        for c in jl_r.all_results
    ]

    # KinBiont's LogLinModel stores the fit in log-space:
    # fitted_curve contains log(OD) values, not OD values.
    # Exponentiate so that fitted_curve is always in the same units as the data.
    raw_fitted = np.array(jl_r.fitted_curve, dtype=np.float64)
    if model_name == "log_lin":
        raw_fitted = np.exp(raw_fitted)

    return CurveFitResult(
        label        = str(jl_r.label),
        best_model   = model_name,
        best_params  = _safe_float_list(jl_r.best_params),
        param_names  = param_names,
        best_aic     = float(jl_r.best_aic),
        fitted_curve = raw_fitted,
        times        = np.array(jl_r.times, dtype=np.float64),
        loss         = float(jl_r.loss),
        all_results  = all_results,
    )


def py_to_jl_growth_fit_results(results: "GrowthFitResults"):
    """Convert Python GrowthFitResults back to a Julia GrowthFitResults.

    Used only by save_results() to delegate CSV writing to Julia.
    """
    jl = get_jl()
    jl_data = py_to_jl_growth_data(results.data)

    jl_push = jl.seval("push!")
    # Empty NamedTuple vector for all_results (only the CSV keys matter for saving)
    empty_nt_vec = jl.seval("NamedTuple[]")

    jl_curve_results = []
    for r in results.results:
        # Reconstruct Julia CurveFitResult from the stored data
        jl_model = jl.Kinbiont.MODEL_REGISTRY.get(r.best_model, None)
        if jl_model is None:
            jl_model = jl.Kinbiont.LogLinModel()

        # best_params::Vector{Any} — must be a typed Julia vector
        best_params_jl = jl.seval("Any[]")
        for x in r.best_params:
            jl_push(best_params_jl, float(x))

        jl_r = jl.Kinbiont.CurveFitResult(
            r.label,
            jl_model,
            best_params_jl,
            float(r.best_aic),
            np.ascontiguousarray(r.fitted_curve, dtype=np.float64),
            np.ascontiguousarray(r.times, dtype=np.float64),
            float(r.loss),
            empty_nt_vec,
        )
        jl_curve_results.append(jl_r)

    return jl.Kinbiont.GrowthFitResults(jl_data, jl_curve_results)
