"""Usage demo for pykinbiont."""

import numpy as np
import pykinbiont

# --- One-time setup: persist the Julia project path ---
#pykinbiont.configure("/home/aivuk/pinheiroTech/KinBiont.jl")

# After configure() is called once, the path is saved to
# ~/.config/pykinbiont/config.json and reloaded automatically.
# You can also use: export KINBIONT_PROJECT_PATH=/path/to/KinBiont.jl


def main():
    # Sample growth curve: at least pt_avg + pt_smoothing_derivative points
    data = np.array([
        [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0],
        [0.01, 0.012, 0.015, 0.02, 0.03, 0.05, 0.08, 0.13, 0.20, 0.30, 0.42, 0.52, 0.59, 0.63, 0.65],
    ])

    result = pykinbiont.fitting.fitting_one_well_log_lin(
        data, "A1", "exp1",
        pt_avg=3,
        pt_smoothing_derivative=3,
        pt_min_size_of_win=3,
    )

    print("=== Parameters ===")
    print(result.params)

    print("\n=== Fit (log-linear window) ===")
    print(result.fit)

    print("\n=== Smoothed data ===")
    print(result.smoothed)


if __name__ == "__main__":
    main()
