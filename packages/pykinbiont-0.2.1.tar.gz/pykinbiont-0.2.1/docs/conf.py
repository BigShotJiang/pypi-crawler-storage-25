# Configuration file for the Sphinx documentation builder.

import sys
from pathlib import Path

# Make the package importable without installing Julia dependencies
sys.path.insert(0, str(Path(__file__).parent.parent))

project = "pykinbiont"
author = "Fuzue Tech"
copyright = "2026, Fuzue Tech"
release = "0.2.0"

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.viewcode",
    "sphinx.ext.intersphinx",
    "sphinx_autodoc_typehints",
    "sphinx_copybutton",
    "myst_parser",
]

# Mock heavy dependencies so autodoc can import pykinbiont without Julia / numpy
autodoc_mock_imports = [
    "juliacall",
    "juliapkg",
    "juliacall.Main",
    "numpy",
    "pandas",
]

templates_path = ["_templates"]
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store", "superpowers"]

html_theme = "pydata_sphinx_theme"
html_static_path = ["_static"]
html_css_files = ["custom.css"]

html_theme_options = {
    "github_url": "https://github.com/fuzue/pykinbiont",
    "navbar_center": [],
    "navbar_end": ["navbar-icon-links"],
    "secondary_sidebar_items": ["page-toc", "edit-this-page", "sourcelink"],
    "footer_start": ["copyright"],
    "footer_end": ["fuzue-footer"],
    "logo": {
        "text": "pykinbiont",
    },
}

html_sidebars = {
    "**": ["sidebar-globalnav"],
}

# Napoleon settings (for NumPy-style docstrings)
napoleon_numpy_docstring = True
napoleon_google_docstring = False
napoleon_include_init_with_doc = False
napoleon_include_private_with_doc = False
napoleon_use_param = True
napoleon_use_rtype = True

# Autodoc settings
autodoc_typehints = "description"
autodoc_member_order = "bysource"
autodoc_default_options = {
    "members": True,
    "undoc-members": False,
    "show-inheritance": True,
}

# MyST settings
myst_enable_extensions = [
    "colon_fence",
    "deflist",
    "dollarmath",
]

# Intersphinx links to Python and NumPy/pandas
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "numpy": ("https://numpy.org/doc/stable", None),
    "pandas": ("https://pandas.pydata.org/pandas-docs/stable", None),
}

source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}
