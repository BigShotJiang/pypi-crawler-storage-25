# API reference

Complete reference for all public classes and functions in pykinbiont.

## Data containers

### GrowthData

```{eval-rst}
.. autoclass:: pykinbiont.GrowthData
   :members:
   :special-members: __getitem__
```

### IrregularGrowthData

```{eval-rst}
.. autoclass:: pykinbiont.IrregularGrowthData
   :members:
   :special-members: __getitem__
```

## Configuration

### FitOptions

```{eval-rst}
.. autoclass:: pykinbiont.FitOptions
   :members:
```

### ModelSpec

```{eval-rst}
.. autoclass:: pykinbiont.ModelSpec
   :members:
```

## Models

### AbstractGrowthModel

```{eval-rst}
.. autoclass:: pykinbiont.AbstractGrowthModel
```

### NLModel

```{eval-rst}
.. autoclass:: pykinbiont.NLModel
   :members:
```

### ODEModel

```{eval-rst}
.. autoclass:: pykinbiont.ODEModel
   :members:
```

### LogLinModel

```{eval-rst}
.. autoclass:: pykinbiont.LogLinModel
```

### DDDEModel

```{eval-rst}
.. autoclass:: pykinbiont.DDDEModel
   :members:
```

### MODEL\_REGISTRY

```{eval-rst}
.. autodata:: pykinbiont.MODEL_REGISTRY
```

## Results

### GrowthFitResults

```{eval-rst}
.. autoclass:: pykinbiont.GrowthFitResults
   :members:
   :special-members: __iter__, __len__, __getitem__
```

### CurveFitResult

```{eval-rst}
.. autoclass:: pykinbiont.CurveFitResult
   :members:
```

## Functions

### fit

```{eval-rst}
.. autofunction:: pykinbiont.fit
```

### preprocess

```{eval-rst}
.. autofunction:: pykinbiont.preprocess
```

### save\_results

```{eval-rst}
.. autofunction:: pykinbiont.save_results
```

### configure

```{eval-rst}
.. autofunction:: pykinbiont.configure
```

### init

```{eval-rst}
.. autofunction:: pykinbiont.init
```

### get\_jl

```{eval-rst}
.. autofunction:: pykinbiont.get_jl
```
