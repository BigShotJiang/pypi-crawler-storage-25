# Saving results

`save_results()` writes a `GrowthFitResults` to three CSV files in a directory.

```python
from pykinbiont import save_results

paths = save_results(results, "output/", prefix="my_experiment")
```

## Output files

Three files are created (or overwritten):

### `<prefix>_summary.csv`

One row per curve with the best model, AICc, loss, and all parameter values.

| Column | Description |
|---|---|
| `label` | Curve identifier |
| `cluster` | Cluster assignment (empty if no clustering) |
| `best_model` | Winning model name |
| `n_params` | Number of fitted parameters |
| `param_names` | Semicolon-separated list of parameter names |
| `aic` | AICc of the best fit |
| `loss` | Final loss |
| `param_1`, `param_2`, … | Parameter values in positional order |

### `<prefix>_fitted_curves.csv`

Long-format table with one row per (curve, time point).

| Column | Description |
|---|---|
| `label` | Curve identifier |
| `time` | Time point |
| `observed` | Observed OD value |
| `fitted` | Fitted OD value from the best model |

### `<prefix>_all_models.csv`

All candidate models per curve (useful for comparing AICc values across models).

| Column | Description |
|---|---|
| `label` | Curve identifier |
| `model_name` | Candidate model name |
| `aic` | AICc for this model/curve combination |
| `loss` | Loss for this model/curve combination |
| `is_best` | `True` if this was the selected model |
| `param_1`, … | Parameter values |

## Return value

`save_results` returns a dict with the three file paths:

```python
paths = save_results(results, "output/")
print(paths["summary"])        # output/kinbiont_summary.csv
print(paths["fitted_curves"])  # output/kinbiont_fitted_curves.csv
print(paths["all_models"])     # output/kinbiont_all_models.csv
```

## Reading results back

```python
import pandas as pd

summary = pd.read_csv(paths["summary"])
fitted  = pd.read_csv(paths["fitted_curves"])

# Plot fitted vs observed for the first well
well = summary.iloc[0]["label"]
well_df = fitted[fitted["label"] == well]
well_df.plot(x="time", y=["observed", "fitted"])
```
