"""04_preprocessing.py — Preprocessing pipeline: smoothing, blank subtraction, clustering.

Demonstrates:
  - Smoothing noisy curves before fitting
  - Blank subtraction
  - Clustering curves into groups
  - Inspecting cluster assignments and centroids
"""

import numpy as np
import pykinbiont
from pykinbiont import GrowthData, FitOptions, ModelSpec, LogLinModel, fit, preprocess

pykinbiont.configure("/home/aivuk/pinheiroTech/KinBiont.jl")

# ---------------------------------------------------------------------------
# 1. Synthetic data — two groups of curves with different growth rates
# ---------------------------------------------------------------------------

def logistic(t, K=1.2, mu=0.5, N0=0.01):
    return K / (1 + ((K - N0) / N0) * np.exp(-mu * t))

rng = np.random.default_rng(7)
times = np.linspace(0, 20, 50)

# Fast growers (mu ~ 0.7)
fast = [
    logistic(times, K=1.1, mu=0.70 + rng.uniform(-0.02, 0.02))
    + rng.normal(0, 0.015, len(times))
    for _ in range(4)
]
# Slow growers (mu ~ 0.3)
slow = [
    logistic(times, K=0.9, mu=0.30 + rng.uniform(-0.02, 0.02))
    + rng.normal(0, 0.015, len(times))
    for _ in range(4)
]
# Blank (no growth)
blank = [rng.normal(0.02, 0.003, len(times)) for _ in range(2)]

curves = np.stack(fast + slow + blank)
labels = (
    [f"Fast_{i+1}" for i in range(4)]
    + [f"Slow_{i+1}" for i in range(4)]
    + [f"Blank_{i+1}" for i in range(2)]
)
data = GrowthData(curves=curves, times=times, labels=labels)
print(f"Data: {curves.shape[0]} curves × {curves.shape[1]} time points")

# ---------------------------------------------------------------------------
# 2. Smoothing only
# ---------------------------------------------------------------------------

opts_smooth = FitOptions(smooth=True, smooth_method="rolling_avg", smooth_pt_avg=5)
smoothed = preprocess(data, opts_smooth)
print(f"\nAfter smoothing: shape={smoothed.curves.shape}")

# ---------------------------------------------------------------------------
# 3. Blank subtraction (use mean of blank wells)
# ---------------------------------------------------------------------------

blank_mean = np.mean(data.curves[-2:])
print(f"Blank mean OD: {blank_mean:.4f}")

opts_blank = FitOptions(
    blank_subtraction=True,
    blank_value=float(blank_mean),
    correct_negatives=True,
    negative_method="thr_correction",
    negative_threshold=0.001,
)
subtracted = preprocess(data, opts_blank)
print(f"After blank subtraction: min={subtracted.curves.min():.4f}")

# ---------------------------------------------------------------------------
# 4. Clustering — group curves by shape
# ---------------------------------------------------------------------------

opts_cluster = FitOptions(cluster=True, n_clusters=3)
clustered = preprocess(data, opts_cluster)

print(f"\nClustering into 3 groups:")
for label, cluster_id in zip(data.labels, clustered.clusters):
    print(f"  {label:12s} → cluster {cluster_id}")

print(f"\nWCSS (within-cluster sum of squares): {clustered.wcss:.4f}")
print(f"Centroid matrix shape: {clustered.centroids.shape}")

# ---------------------------------------------------------------------------
# 5. Full pipeline: smooth + cluster, then fit
# ---------------------------------------------------------------------------

opts_full = FitOptions(
    smooth=True,
    smooth_method="rolling_avg",
    smooth_pt_avg=5,
    blank_subtraction=True,
    blank_value=float(blank_mean),
    correct_negatives=True,
    negative_method="thr_correction",
    negative_threshold=0.001,
)
spec = ModelSpec(models=[LogLinModel()], params=[[]])

results = fit(data[labels[:8]], spec, opts_full)   # exclude blank wells
df = results.to_dataframe()
print("\nFit results with full preprocessing pipeline:")
print(df[["label", "best_model", "aic"]].to_string(index=False))
