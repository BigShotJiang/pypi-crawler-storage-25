"""05_from_csv.py — Load data from CSV, fit, and save results.

Expected CSV layout (first column = times, remaining = curves, headers = labels):

    time,Well_A1,Well_A2,Well_A3
    0.0,0.012,0.011,0.013
    0.5,0.014,0.013,0.015
    ...

Demonstrates:
  - GrowthData.from_csv()
  - GrowthData.from_dataframe()
  - save_results() → three CSV files
"""

import sys
import numpy as np
import pandas as pd
import tempfile
import pykinbiont
from pykinbiont import (
    GrowthData, FitOptions, ModelSpec, LogLinModel, MODEL_REGISTRY,
    fit, save_results,
)

pykinbiont.configure("/home/aivuk/pinheiroTech/KinBiont.jl")

# ---------------------------------------------------------------------------
# 1. Generate a sample CSV (stands in for a real plate-reader file)
# ---------------------------------------------------------------------------

def logistic(t, K=1.2, mu=0.5, N0=0.01):
    return K / (1 + ((K - N0) / N0) * np.exp(-mu * t))

rng = np.random.default_rng(3)
times = np.linspace(0, 20, 48)
n_wells = 6
well_labels = [f"Well_{chr(65 + i//3)}{i%3 + 1}" for i in range(n_wells)]

df_in = pd.DataFrame({"time": times})
for i, label in enumerate(well_labels):
    df_in[label] = (
        logistic(times, K=0.9 + 0.1 * i, mu=0.4 + 0.04 * i)
        + rng.normal(0, 0.006, len(times))
    )

with tempfile.NamedTemporaryFile(suffix=".csv", mode="w", delete=False) as f:
    csv_path = f.name
    df_in.to_csv(f, index=False)

print(f"Sample CSV written to: {csv_path}")

# ---------------------------------------------------------------------------
# 2. Load from CSV
# ---------------------------------------------------------------------------

data = GrowthData.from_csv(csv_path)
print(f"Loaded: {len(data.labels)} curves, {len(data.times)} time points")
print(f"Labels: {data.labels}")

# Alternatively, load from a DataFrame you already have in memory:
# data = GrowthData.from_dataframe(df_in)

# ---------------------------------------------------------------------------
# 3. Subset to a few wells of interest
# ---------------------------------------------------------------------------

subset = data[["Well_A1", "Well_B1", "Well_A2"]]
print(f"\nSubset: {subset.labels}")

# ---------------------------------------------------------------------------
# 4. Fit
# ---------------------------------------------------------------------------

logistic_model = MODEL_REGISTRY["NL_logistic"]
spec = ModelSpec(
    models=[logistic_model],
    params=[[1.2, 0.5, 0.01]],
    lower=[[0.0, 0.0, 0.0]],
    upper=[[5.0, 5.0, 1.0]],
)
opts = FitOptions(smooth=True, smooth_method="rolling_avg")

results = fit(data, spec, opts)
print("\nFit results:")
print(results.to_dataframe()[["label", "best_model", "aic"]].to_string(index=False))

# ---------------------------------------------------------------------------
# 5. Save results to CSV files
# ---------------------------------------------------------------------------

out_dir = tempfile.mkdtemp()
paths = save_results(results, out_dir, prefix="my_experiment")

print(f"\nResults saved:")
for key, path in paths.items():
    n_rows = len(pd.read_csv(path))
    print(f"  {key:15s}: {path}  ({n_rows} rows)")
