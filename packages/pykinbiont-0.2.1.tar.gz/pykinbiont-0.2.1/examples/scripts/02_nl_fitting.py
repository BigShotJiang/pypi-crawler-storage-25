"""02_nl_fitting.py — Fit growth curves with built-in non-linear models.

Demonstrates:
  - Looking up models in MODEL_REGISTRY
  - Fitting multiple models and comparing AICc
  - Accessing per-curve fitted curves
"""

import numpy as np
import pykinbiont
from pykinbiont import GrowthData, FitOptions, ModelSpec, MODEL_REGISTRY, fit

pykinbiont.configure("/home/aivuk/pinheiroTech/KinBiont.jl")

# ---------------------------------------------------------------------------
# 1. Synthetic data
# ---------------------------------------------------------------------------

def logistic(t, K=1.2, mu=0.5, N0=0.01):
    return K / (1 + ((K - N0) / N0) * np.exp(-mu * t))

rng = np.random.default_rng(1)
times = np.linspace(0, 24, 80)
curves = np.stack([
    np.maximum(
        logistic(times, K=1.0 + 0.2 * i, mu=0.35 + 0.05 * i)
        + rng.normal(0, 0.008, len(times)),
        1e-4,
    )
    for i in range(4)
])
data = GrowthData(curves=curves, times=times, labels=[f"S{i+1}" for i in range(4)])

# ---------------------------------------------------------------------------
# 2. Explore the built-in model registry
# ---------------------------------------------------------------------------

print("Available models (first 10):")
for name in list(MODEL_REGISTRY.keys())[:10]:
    m = MODEL_REGISTRY[name]
    print(f"  {name:30s}  params={m.param_names}")

# ---------------------------------------------------------------------------
# 3. Fit with the logistic NL model
# ---------------------------------------------------------------------------

logistic_model = MODEL_REGISTRY["NL_logistic"]
print(f"\nUsing: {logistic_model.name}  params={logistic_model.param_names}")

# Initial parameter guess: [K, mu, N0]
spec = ModelSpec(
    models=[logistic_model],
    params=[[1.2, 0.5, 0.01]],
    lower=[[0.0, 0.0, 0.0]],
    upper=[[5.0, 5.0, 1.0]],
)
opts = FitOptions(loss="RE", multistart=True, n_restart=20)

results = fit(data, spec, opts)

# ---------------------------------------------------------------------------
# 4. Report
# ---------------------------------------------------------------------------

df = results.to_dataframe()
print("\nFit results:")
print(df.to_string(index=False))

print("\nPer-curve best parameters:")
for r in results:
    params_str = "  ".join(f"{n}={v:.4f}" for n, v in zip(r.param_names, r.best_params))
    print(f"  {r.label}: {params_str}")
    print(f"         fitted_curve shape: {r.fitted_curve.shape}")
