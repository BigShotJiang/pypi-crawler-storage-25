"""01_quickstart.py — Fit a set of growth curves with the log-linear model.

Demonstrates the minimal workflow:
  GrowthData → fit() → GrowthFitResults → to_dataframe()
"""

import numpy as np
import pykinbiont
from pykinbiont import GrowthData, FitOptions, ModelSpec, LogLinModel, fit

# ---------------------------------------------------------------------------
# Configure — remove or adjust if using the registry-installed Kinbiont.
# configure() saves the path permanently; subsequent runs pick it up
# automatically from ~/.config/pykinbiont/config.json.
# ---------------------------------------------------------------------------
pykinbiont.configure("/home/aivuk/pinheiroTech/KinBiont.jl")

# ---------------------------------------------------------------------------
# 1. Build synthetic data (5 curves, 60 time points)
# ---------------------------------------------------------------------------

def logistic(t, K=1.2, mu=0.5, N0=0.01):
    return K / (1 + ((K - N0) / N0) * np.exp(-mu * t))

rng = np.random.default_rng(0)
times = np.linspace(0, 20, 60)
curves = np.stack([
    logistic(times, K=1.0 + 0.15 * i, mu=0.4 + 0.06 * i)
    + rng.normal(0, 0.005, len(times))
    for i in range(5)
])
labels = [f"Well_{i+1}" for i in range(5)]

data = GrowthData(curves=curves, times=times, labels=labels)
print(f"Loaded {len(data.labels)} curves × {len(data.times)} time points")

# ---------------------------------------------------------------------------
# 2. Fit with log-linear model
# ---------------------------------------------------------------------------

spec = ModelSpec(models=[LogLinModel()], params=[[]])
opts = FitOptions()

results = fit(data, spec, opts)
print(f"Fit complete: {len(results)} results")

# ---------------------------------------------------------------------------
# 3. Inspect results
# ---------------------------------------------------------------------------

for r in results:
    print(f"  {r.label}: model={r.best_model}  AIC={r.best_aic:.2f}  loss={r.loss:.5f}")

# ---------------------------------------------------------------------------
# 4. Export to DataFrame
# ---------------------------------------------------------------------------

df = results.to_dataframe()
print("\nSummary table:")
print(df[["label", "best_model", "aic", "loss"]].to_string(index=False))
