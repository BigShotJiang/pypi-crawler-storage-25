"""03_custom_model.py — Define and fit a custom Python growth model.

Demonstrates:
  - Wrapping a Python function as an NLModel
  - Fitting with a user-defined analytical expression
  - Comparing a custom model against a built-in one
"""

import numpy as np
import pykinbiont
from pykinbiont import GrowthData, FitOptions, ModelSpec, NLModel, MODEL_REGISTRY, fit

pykinbiont.configure("/home/aivuk/pinheiroTech/KinBiont.jl")

# ---------------------------------------------------------------------------
# 1. Define a custom Gompertz growth model
#    f(p, t) where p = [A, mu, lam]
#      A   = maximum OD (carrying capacity)
#      mu  = maximum specific growth rate
#      lam = lag time
# ---------------------------------------------------------------------------

def gompertz(p, t):
    A, mu, lam = p[0], p[1], p[2]
    return A * np.exp(-np.exp(mu * np.e / A * (lam - t) + 1))

custom_gompertz = NLModel(
    name="gompertz",
    func=gompertz,
    param_names=["A", "mu", "lam"],
)

# ---------------------------------------------------------------------------
# 2. Synthetic data with a visible lag phase (suits Gompertz)
# ---------------------------------------------------------------------------

def true_gompertz(t, A=1.1, mu=0.5, lam=2.0):
    return A * np.exp(-np.exp(mu * np.e / A * (lam - t) + 1))

rng = np.random.default_rng(42)
times = np.linspace(0, 18, 60)
curves = np.stack([
    np.maximum(
        true_gompertz(times, A=1.0 + 0.1 * i, mu=0.4 + 0.05 * i, lam=2.0 + 0.3 * i)
        + rng.normal(0, 0.007, len(times)),
        1e-4,
    )
    for i in range(3)
])
data = GrowthData(curves=curves, times=times, labels=["G1", "G2", "G3"])

# ---------------------------------------------------------------------------
# 3. Fit with the custom Gompertz model
# ---------------------------------------------------------------------------

spec = ModelSpec(
    models=[custom_gompertz],
    params=[[1.0, 0.5, 2.0]],
    lower=[[0.0, 0.0, 0.0]],
    upper=[[3.0, 3.0, 10.0]],
)
opts = FitOptions(multistart=True, n_restart=30)

print("Fitting custom Gompertz model...")
results = fit(data, spec, opts)

for r in results:
    p = dict(zip(r.param_names, r.best_params))
    print(f"  {r.label}: A={p['A']:.3f}  mu={p['mu']:.3f}  lam={p['lam']:.3f}"
          f"  AIC={r.best_aic:.2f}")

# ---------------------------------------------------------------------------
# 4. Compare against built-in logistic (two-model spec)
# ---------------------------------------------------------------------------

logistic_model = MODEL_REGISTRY["NL_logistic"]

spec_both = ModelSpec(
    models=[custom_gompertz, logistic_model],
    params=[[1.0, 0.5, 2.0], [1.2, 0.5, 0.01]],
    lower=[[0.0, 0.0, 0.0], [0.0, 0.0, 0.0]],
    upper=[[3.0, 3.0, 10.0], [5.0, 5.0, 1.0]],
)

print("\nFitting both models, selecting best by AICc...")
results_both = fit(data, spec_both, opts)

df = results_both.to_dataframe()
print(df[["label", "best_model", "aic", "loss"]].to_string(index=False))
