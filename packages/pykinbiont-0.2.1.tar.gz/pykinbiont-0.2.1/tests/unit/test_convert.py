import numpy as np
import pytest


def _make_growth_data():
    from pykinbiont.types import GrowthData
    return GrowthData(
        curves=np.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]]),
        times=np.array([0.0, 1.0, 2.0]),
        labels=["A", "B"],
    )


def test_py_to_jl_growth_data_calls_constructor(mocker):
    from pykinbiont._convert import py_to_jl_growth_data
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    gd = _make_growth_data()
    py_to_jl_growth_data(gd)

    fake_jl.Kinbiont.GrowthData.assert_called_once()
    args = fake_jl.Kinbiont.GrowthData.call_args[0]
    # First arg should be curves (2D array), second times (1D), third labels (list)
    assert args[0].shape == (2, 3)   # curves
    assert len(args[1]) == 3         # times
    assert list(args[2]) == ["A", "B"]


def test_py_to_jl_irregular_calls_constructor(mocker):
    from pykinbiont._convert import py_to_jl_irregular
    from pykinbiont.types import IrregularGrowthData
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    igd = IrregularGrowthData(
        raw_curves=[np.array([0.1, 0.2]), np.array([0.3, 0.4])],
        raw_times=[np.array([0.0, 1.0]), np.array([0.0, 1.0])],
        labels=["A", "B"],
    )
    py_to_jl_irregular(igd)
    fake_jl.Kinbiont.IrregularGrowthData.assert_called_once()


def test_py_to_jl_fit_options_basic(mocker):
    from pykinbiont._convert import py_to_jl_fit_options
    from pykinbiont.types import FitOptions
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    opts = FitOptions(smooth=True, n_clusters=4, cluster=True)
    py_to_jl_fit_options(opts)

    fake_jl.Kinbiont.FitOptions.assert_called_once()
    kwargs = fake_jl.Kinbiont.FitOptions.call_args[1]
    assert kwargs["smooth"] is True
    assert kwargs["n_clusters"] == 4
    assert kwargs["cluster"] is True


def test_py_to_jl_fit_options_symbols(mocker):
    from pykinbiont._convert import py_to_jl_fit_options
    from pykinbiont.types import FitOptions
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    opts = FitOptions(smooth_method="rolling_avg", negative_method="thr_correction")
    py_to_jl_fit_options(opts)

    kwargs = fake_jl.Kinbiont.FitOptions.call_args[1]
    # smooth_method and negative_method should be Julia Symbols
    fake_jl.seval.assert_any_call(":rolling_avg")
    fake_jl.seval.assert_any_call(":thr_correction")


def test_py_to_jl_fit_options_opt_params(mocker):
    from pykinbiont._convert import py_to_jl_fit_options
    from pykinbiont.types import FitOptions
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    opts = FitOptions(opt_params={"maxiters": 100000})
    py_to_jl_fit_options(opts)

    # opt_params should be forwarded as a Julia NamedTuple via seval
    calls = [str(c) for c in fake_jl.seval.call_args_list]
    assert any("maxiters" in c for c in calls)


def test_py_to_jl_model_spec_loglin(mocker):
    from pykinbiont._convert import py_to_jl_model_spec
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import LogLinModel
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    spec = ModelSpec(models=[LogLinModel()], params=[[]])
    py_to_jl_model_spec(spec)

    fake_jl.Kinbiont.ModelSpec.assert_called_once()
    args = fake_jl.Kinbiont.ModelSpec.call_args[0]
    # First arg is list of Julia model objects
    assert len(args[0]) == 1
    # Second arg is list of param vectors
    assert len(args[1]) == 1


def test_py_to_jl_model_spec_nl_builtin(mocker):
    from pykinbiont._convert import py_to_jl_model_spec
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import NLModel
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    m = NLModel(name="NL_logistic", param_names=["K", "mu", "N0"])
    spec = ModelSpec(models=[m], params=[[1.2, 0.5, 0.01]])
    py_to_jl_model_spec(spec)

    # Built-in NLModel (no func) — should look up from MODEL_REGISTRY on Julia side
    fake_jl.Kinbiont.MODEL_REGISTRY.__getitem__.assert_called_with("NL_logistic")


def test_py_to_jl_model_spec_nl_custom_callable(mocker):
    from pykinbiont._convert import py_to_jl_model_spec
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import NLModel
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    import numpy as np
    func = lambda p, t: p[0] * np.exp(p[1] * t)
    m = NLModel(name="custom_exp", func=func, param_names=["N0", "mu"])
    spec = ModelSpec(models=[m], params=[[0.01, 0.5]])
    py_to_jl_model_spec(spec)

    # Custom callable — should construct a new Julia NLModel wrapping the Python func
    fake_jl.Kinbiont.NLModel.assert_called_once()
    call_args = fake_jl.Kinbiont.NLModel.call_args[0]
    assert call_args[0] == "custom_exp"   # name
    assert callable(call_args[1])         # wrapped callable


def test_fit_options_opt_params_invalid_key():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="valid Julia identifier"):
        FitOptions(opt_params={"invalid-key": 100})


def test_fit_options_opt_params_invalid_value():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="int, float, bool"):
        FitOptions(opt_params={"maxiters": "many"})


def test_fit_options_opt_params_valid():
    from pykinbiont.types import FitOptions
    opts = FitOptions(opt_params={"maxiters": 100000, "reltol": 1e-8})
    assert opts.opt_params["maxiters"] == 100000


def test_py_to_jl_model_spec_ode_custom_callable(mocker):
    from pykinbiont._convert import py_to_jl_model_spec
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import ODEModel
    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)

    import numpy as np
    def logistic_ode(du, u, p, t):
        du[0] = p[0] * u[0] * (1 - u[0] / p[1])

    m = ODEModel(name="custom_logistic", func=logistic_ode, param_names=["r", "K"], n_eq=1)
    spec = ModelSpec(models=[m], params=[[0.5, 1.0]])
    py_to_jl_model_spec(spec)

    # ODEModel custom callable — should construct a new Julia ODEModel wrapping the Python func
    fake_jl.Kinbiont.ODEModel.assert_called_once()
    call_args = fake_jl.Kinbiont.ODEModel.call_args[0]
    assert call_args[0] == "custom_logistic"   # name
    assert callable(call_args[1])               # wrapped callable
    assert call_args[3] == 1                    # n_eq


def test_wrap_ode_callable_accepts_four_args():
    from pykinbiont._convert import _wrap_ode_callable_for_julia
    import numpy as np

    def my_ode(du, u, p, t):
        du[0] = p[0] * u[0]

    wrapped = _wrap_ode_callable_for_julia(my_ode, None)
    du = np.zeros(1)
    u  = np.array([0.5])
    p  = np.array([0.3])
    # Should not raise
    wrapped(du, u, p, 0.0)
    assert abs(du[0] - 0.15) < 1e-10


def test_fit_calls_kinbiont_fit(mocker):
    from pykinbiont.fit import fit
    from pykinbiont.types import FitOptions, ModelSpec, GrowthData
    from pykinbiont.models import LogLinModel
    import numpy as np

    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)
    mocker.patch("pykinbiont.fit.get_jl", return_value=fake_jl)
    mocker.patch("pykinbiont.fit.py_to_jl_growth_data", return_value="jl_data")
    mocker.patch("pykinbiont.fit.py_to_jl_fit_options", return_value="jl_opts")
    mocker.patch("pykinbiont.fit.py_to_jl_model_spec", return_value="jl_spec")

    # Make the return value look like a real GrowthFitResults
    fake_result = mocker.MagicMock()
    fake_result.data.curves   = np.ones((1, 3))
    fake_result.data.times    = np.array([0.0, 1.0, 2.0])
    fake_result.data.labels   = ["A"]
    fake_result.data.clusters  = None
    fake_result.data.centroids = None
    fake_result.data.wcss      = None
    fake_result.results = []
    fake_jl.Kinbiont.kinbiont_fit.return_value = fake_result

    gd = GrowthData(curves=np.ones((1, 3)), times=np.array([0.0, 1.0, 2.0]), labels=["A"])
    spec = ModelSpec(models=[LogLinModel()], params=[[]])
    result = fit(gd, spec)

    fake_jl.Kinbiont.kinbiont_fit.assert_called_once_with("jl_data", "jl_spec", "jl_opts")


def test_preprocess_calls_kinbiont_preprocess(mocker):
    from pykinbiont.fit import preprocess
    from pykinbiont.types import FitOptions, GrowthData
    import numpy as np

    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont._convert.get_jl", return_value=fake_jl)
    mocker.patch("pykinbiont.fit.get_jl", return_value=fake_jl)
    mocker.patch("pykinbiont.fit.py_to_jl_growth_data", return_value="jl_data")
    mocker.patch("pykinbiont.fit.py_to_jl_fit_options", return_value="jl_opts")

    fake_processed = mocker.MagicMock()
    fake_processed.curves   = np.ones((1, 3))
    fake_processed.times    = np.array([0.0, 1.0, 2.0])
    fake_processed.labels   = ["A"]
    fake_processed.clusters  = None
    fake_processed.centroids = None
    fake_processed.wcss      = None
    fake_jl.Kinbiont.preprocess.return_value = fake_processed

    gd = GrowthData(curves=np.ones((1, 3)), times=np.array([0.0, 1.0, 2.0]), labels=["A"])
    opts = FitOptions()
    preprocess(gd, opts)

    fake_jl.Kinbiont.preprocess.assert_called_once_with("jl_data", "jl_opts")


def test_save_results_calls_julia(mocker, tmp_path):
    from pykinbiont.io import save_results
    from pykinbiont.types import GrowthData, GrowthFitResults
    import numpy as np

    fake_jl = mocker.MagicMock()
    mocker.patch("pykinbiont.io.get_jl", return_value=fake_jl)
    mocker.patch("pykinbiont.io.py_to_jl_growth_fit_results", return_value="jl_results")
    fake_jl.Kinbiont.save_results.return_value = mocker.MagicMock(
        summary="s.csv", fitted_curves="f.csv", all_models="a.csv"
    )

    gd = GrowthData(curves=np.ones((1, 3)), times=np.array([0.0, 1.0, 2.0]), labels=["A"])
    res = GrowthFitResults(data=gd, results=[])
    out = save_results(res, str(tmp_path))

    fake_jl.Kinbiont.save_results.assert_called_once_with(
        "jl_results", str(tmp_path), prefix="kinbiont"
    )
    assert "summary" in out
