import pytest


def test_nl_model_construction():
    from pykinbiont.models import NLModel
    m = NLModel(name="my_model", param_names=["a", "b"])
    assert m.name == "my_model"
    assert m.func is None
    assert m.param_names == ["a", "b"]


def test_nl_model_with_callable():
    from pykinbiont.models import NLModel
    func = lambda p, t: p[0] * t
    m = NLModel(name="exp", func=func, param_names=["N0", "mu"])
    assert callable(m.func)


def test_ode_model_construction():
    from pykinbiont.models import ODEModel
    m = ODEModel(name="logistic", param_names=["r", "K"], n_eq=1)
    assert m.n_eq == 1
    assert m.func is None


def test_loglin_model_sentinel():
    from pykinbiont.models import LogLinModel
    m = LogLinModel()
    assert isinstance(m, LogLinModel)


def test_ddde_model_defaults():
    from pykinbiont.models import DDDEModel
    m = DDDEModel()
    assert m.max_degree == 4
    assert m.lambda_min == -5.0
    assert m.lambda_max == -1.0
    assert m.lambda_step == 0.5


def test_ddde_model_custom():
    from pykinbiont.models import DDDEModel
    m = DDDEModel(max_degree=6, lambda_min=-4.0)
    assert m.max_degree == 6
    assert m.lambda_min == -4.0


def test_model_registry_lazy_population(mocker):
    from pykinbiont import models as m_module

    # Build minimal fake Julia model objects
    fake_nl = mocker.MagicMock()
    fake_nl.param_names = ["K", "mu", "N0"]

    fake_ode = mocker.MagicMock()
    fake_ode.param_names = ["r", "K"]
    fake_ode.n_eq = 1

    fake_jl = mocker.MagicMock()
    fake_jl.Kinbiont.MODEL_REGISTRY.items.return_value = [
        ("NL_logistic", fake_nl),
        ("logistic_ode", fake_ode),
    ]
    mocker.patch("pykinbiont._core.get_jl", return_value=fake_jl)

    # Create a fresh registry (not the module-level singleton)
    registry = m_module._LazyRegistry()
    assert not registry._populated

    # Trigger population via __contains__
    assert "NL_logistic" in registry
    assert registry._populated

    # Verify correct model types
    from pykinbiont.models import NLModel, ODEModel
    assert isinstance(registry["NL_logistic"], NLModel)
    assert registry["NL_logistic"].param_names == ["K", "mu", "N0"]
    assert isinstance(registry["logistic_ode"], ODEModel)
    assert registry["logistic_ode"].n_eq == 1


def test_all_models_inherit_abstract():
    from pykinbiont.models import AbstractGrowthModel, NLModel, ODEModel, LogLinModel, DDDEModel
    assert isinstance(NLModel(name="x"), AbstractGrowthModel)
    assert isinstance(ODEModel(name="y"), AbstractGrowthModel)
    assert isinstance(LogLinModel(), AbstractGrowthModel)
    assert isinstance(DDDEModel(), AbstractGrowthModel)
