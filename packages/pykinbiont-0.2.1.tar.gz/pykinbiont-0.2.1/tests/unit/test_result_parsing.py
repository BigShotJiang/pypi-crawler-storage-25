import numpy as np
import pytest
from unittest.mock import MagicMock


def _make_fake_jl_result():
    """Build a fake Julia GrowthFitResults-shaped object using MagicMock."""
    # fake GrowthData inside result
    jl_data = MagicMock()
    jl_data.curves = np.array([[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
    jl_data.times  = np.array([0.0, 1.0, 2.0])
    jl_data.labels = ["A", "B"]
    jl_data.clusters  = None
    jl_data.centroids = None
    jl_data.wcss      = None

    # fake CurveFitResult
    best_model = MagicMock()
    best_model.name        = "NL_logistic"
    best_model.param_names = ["K", "mu", "N0"]

    candidate = MagicMock()
    candidate.model_name  = "NL_logistic"
    candidate.params      = [1.2, 0.5, 0.01]
    candidate.aic         = -15.3
    candidate.loss        = 0.002

    jl_curve_result = MagicMock()
    jl_curve_result.label        = "A"
    jl_curve_result.best_model   = best_model
    jl_curve_result.best_params  = [1.2, 0.5, 0.01]
    jl_curve_result.best_aic     = -15.3
    jl_curve_result.fitted_curve = np.array([0.1, 0.2, 0.3])
    jl_curve_result.times        = np.array([0.0, 1.0, 2.0])
    jl_curve_result.loss         = 0.002
    jl_curve_result.all_results  = [candidate]

    jl_res = MagicMock()
    jl_res.data    = jl_data
    jl_res.results = [jl_curve_result]
    return jl_res


def test_jl_to_py_growth_fit_results_basic():
    from pykinbiont._convert import jl_to_py_growth_fit_results
    jl_res = _make_fake_jl_result()
    result = jl_to_py_growth_fit_results(jl_res)

    assert result.data.curves.shape == (2, 3)
    assert result.data.labels == ["A", "B"]
    assert len(result.results) == 1
    r = result.results[0]
    assert r.label == "A"
    assert r.best_model == "NL_logistic"
    assert r.param_names == ["K", "mu", "N0"]
    assert r.best_aic == pytest.approx(-15.3)
    assert r.fitted_curve.shape == (3,)


def test_jl_to_py_growth_fit_results_clustering():
    from pykinbiont._convert import jl_to_py_growth_fit_results
    jl_res = _make_fake_jl_result()
    jl_res.data.clusters  = np.array([1, 2])
    jl_res.data.centroids = np.ones((2, 3))
    jl_res.data.wcss      = 3.14
    result = jl_to_py_growth_fit_results(jl_res)
    assert result.data.clusters is not None
    np.testing.assert_array_equal(result.data.clusters, [1, 2])
    assert result.data.wcss == pytest.approx(3.14)


def test_growth_fit_results_to_dataframe_columns():
    from pykinbiont._convert import jl_to_py_growth_fit_results
    jl_res = _make_fake_jl_result()
    result = jl_to_py_growth_fit_results(jl_res)
    df = result.to_dataframe()
    assert "label" in df.columns
    assert "best_model" in df.columns
    assert "aic" in df.columns
    assert "param_1" in df.columns


def test_growth_fit_results_empty_results():
    from pykinbiont._convert import jl_to_py_growth_fit_results
    jl_res = _make_fake_jl_result()
    jl_res.results = []
    result = jl_to_py_growth_fit_results(jl_res)
    assert len(result) == 0
    assert len(result.to_dataframe()) == 0


def test_jl_to_py_growth_fit_results_loglin_fallback():
    """LogLinModel results have no name/param_names — should fall back gracefully."""
    from pykinbiont._convert import jl_to_py_growth_fit_results
    from unittest.mock import MagicMock, PropertyMock
    import numpy as np

    jl_data = MagicMock()
    jl_data.curves = np.array([[0.1, 0.2, 0.3]])
    jl_data.times  = np.array([0.0, 1.0, 2.0])
    jl_data.labels = ["A"]
    jl_data.clusters  = None
    jl_data.centroids = None
    jl_data.wcss      = None

    # Simulate a Julia LogLinModel result — no name or param_names attributes
    loglin_model = MagicMock(spec=[])  # spec=[] means NO attributes

    jl_curve_result = MagicMock()
    jl_curve_result.label        = "A"
    jl_curve_result.best_model   = loglin_model
    jl_curve_result.best_params  = []
    jl_curve_result.best_aic     = -10.0
    jl_curve_result.fitted_curve = np.array([0.1, 0.2, 0.3])
    jl_curve_result.times        = np.array([0.0, 1.0, 2.0])
    jl_curve_result.loss         = 0.001
    jl_curve_result.all_results  = []

    jl_res = MagicMock()
    jl_res.data    = jl_data
    jl_res.results = [jl_curve_result]

    result = jl_to_py_growth_fit_results(jl_res)
    assert result.results[0].best_model == "log_lin"
    assert result.results[0].param_names == []
