import numpy as np
import pandas as pd
import pytest
from io import StringIO


def test_growth_data_construction():
    from pykinbiont.types import GrowthData
    curves = np.ones((3, 10), dtype=np.float64)
    times = np.linspace(0, 9, 10)
    labels = ["A1", "A2", "A3"]
    gd = GrowthData(curves=curves, times=times, labels=labels)
    assert gd.curves.shape == (3, 10)
    assert len(gd.labels) == 3
    assert gd.clusters is None
    assert gd.centroids is None
    assert gd.wcss is None


def test_growth_data_shape_mismatch_times():
    from pykinbiont.types import GrowthData
    with pytest.raises(ValueError, match="times length"):
        GrowthData(
            curves=np.ones((2, 10)),
            times=np.ones(9),   # wrong length
            labels=["A", "B"],
        )


def test_growth_data_shape_mismatch_labels():
    from pykinbiont.types import GrowthData
    with pytest.raises(ValueError, match="labels length"):
        GrowthData(
            curves=np.ones((2, 10)),
            times=np.ones(10),
            labels=["A"],       # wrong length
        )


def test_growth_data_from_dataframe():
    from pykinbiont.types import GrowthData
    df = pd.DataFrame({
        "time": [0.0, 1.0, 2.0],
        "A1":   [0.1, 0.2, 0.3],
        "B2":   [0.4, 0.5, 0.6],
    })
    gd = GrowthData.from_dataframe(df)
    assert gd.times.tolist() == [0.0, 1.0, 2.0]
    assert gd.labels == ["A1", "B2"]
    assert gd.curves.shape == (2, 3)
    np.testing.assert_allclose(gd.curves[0], [0.1, 0.2, 0.3])


def test_growth_data_from_csv(tmp_path):
    from pykinbiont.types import GrowthData
    csv = tmp_path / "data.csv"
    csv.write_text("time,A1,B2\n0.0,0.1,0.4\n1.0,0.2,0.5\n2.0,0.3,0.6\n")
    gd = GrowthData.from_csv(str(csv))
    assert gd.labels == ["A1", "B2"]
    assert gd.curves.shape == (2, 3)


def test_growth_data_getitem():
    from pykinbiont.types import GrowthData
    curves = np.arange(12, dtype=np.float64).reshape(3, 4)
    gd = GrowthData(curves=curves, times=np.arange(4, dtype=np.float64), labels=["A", "B", "C"])
    sub = gd[["C", "A"]]
    assert sub.labels == ["C", "A"]
    assert sub.curves.shape == (2, 4)
    np.testing.assert_array_equal(sub.curves[0], curves[2])
    np.testing.assert_array_equal(sub.curves[1], curves[0])


def test_growth_data_getitem_missing():
    from pykinbiont.types import GrowthData
    gd = GrowthData(curves=np.ones((2, 4)), times=np.arange(4, dtype=np.float64), labels=["A", "B"])
    with pytest.raises(KeyError):
        gd[["X"]]


def test_growth_data_clusters_length_mismatch():
    from pykinbiont.types import GrowthData
    with pytest.raises(ValueError, match="clusters length"):
        GrowthData(
            curves=np.ones((3, 5)),
            times=np.arange(5, dtype=np.float64),
            labels=["A", "B", "C"],
            clusters=np.array([1, 2]),  # wrong length (2 != 3)
        )


def test_irregular_growth_data_construction():
    from pykinbiont.types import IrregularGrowthData
    raw_curves = [np.array([0.1, 0.2, 0.3]), np.array([0.4, 0.5, 0.6, 0.7])]
    raw_times  = [np.array([0.0, 1.0, 2.0]), np.array([0.0, 0.5, 1.5, 2.0])]
    labels = ["A", "B"]
    igd = IrregularGrowthData(raw_curves=raw_curves, raw_times=raw_times, labels=labels)
    assert len(igd.raw_curves) == 2
    assert igd.curves.ndim == 2        # resampled matrix
    assert igd.times[0] == pytest.approx(0.0)
    assert igd.times[-1] == pytest.approx(1.0)
    assert igd.clusters is None


def test_irregular_growth_data_length_mismatch():
    from pykinbiont.types import IrregularGrowthData
    with pytest.raises((ValueError, Exception)):
        IrregularGrowthData(
            raw_curves=[np.array([0.1, 0.2])],
            raw_times=[np.array([0.0, 1.0]), np.array([0.0, 1.0])],  # 2 != 1
            labels=["A"],
        )


def test_irregular_growth_data_getitem():
    from pykinbiont.types import IrregularGrowthData
    raw_curves = [np.array([0.1, 0.2, 0.3]), np.array([0.4, 0.5, 0.6])]
    raw_times  = [np.array([0.0, 1.0, 2.0]), np.array([0.0, 1.0, 2.0])]
    igd = IrregularGrowthData(raw_curves=raw_curves, raw_times=raw_times, labels=["A", "B"])
    sub = igd[["B"]]
    assert sub.labels == ["B"]
    assert len(sub.raw_curves) == 1


def test_fit_options_defaults():
    from pykinbiont.types import FitOptions
    opts = FitOptions()
    assert opts.smooth is False
    assert opts.smooth_method == "lowess"
    assert opts.cluster is False
    assert opts.n_clusters == 3
    assert opts.loss == "RE"
    assert opts.multistart is False


def test_fit_options_bad_smooth_method():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="smooth_method"):
        FitOptions(smooth_method="foobar")


def test_fit_options_bad_negative_method():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="negative_method"):
        FitOptions(negative_method="foobar")


def test_fit_options_bad_scattering_method():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="scattering_method"):
        FitOptions(scattering_method="foobar")


def test_fit_options_cluster_requires_n_clusters_ge_2():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="n_clusters"):
        FitOptions(cluster=True, n_clusters=1)


def test_fit_options_scattering_requires_calibration_file():
    from pykinbiont.types import FitOptions
    with pytest.raises(ValueError, match="calibration_file"):
        FitOptions(scattering_correction=True, calibration_file="")


def test_fit_options_valid_clustering():
    from pykinbiont.types import FitOptions
    opts = FitOptions(cluster=True, n_clusters=4)
    assert opts.n_clusters == 4


def test_model_spec_valid():
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import LogLinModel
    spec = ModelSpec(models=[LogLinModel()], params=[[]])
    assert len(spec.models) == 1


def test_model_spec_length_mismatch():
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import LogLinModel
    with pytest.raises(ValueError, match="same length"):
        ModelSpec(models=[LogLinModel(), LogLinModel()], params=[[]])


def test_model_spec_lower_length_mismatch():
    from pykinbiont.types import ModelSpec
    from pykinbiont.models import LogLinModel
    with pytest.raises(ValueError, match="lower"):
        ModelSpec(models=[LogLinModel()], params=[[]], lower=[None, None])


def test_growth_fit_results_to_dataframe():
    from pykinbiont.types import GrowthData, CurveFitResult, GrowthFitResults
    curves = np.ones((2, 5))
    times = np.arange(5, dtype=np.float64)
    gd = GrowthData(curves=curves, times=times, labels=["A", "B"])
    r1 = CurveFitResult(
        label="A", best_model="log_lin", best_params=[0.1, 0.5],
        param_names=["intercept", "slope"], best_aic=-10.0,
        fitted_curve=np.ones(5), times=times, loss=0.01, all_results=[],
    )
    r2 = CurveFitResult(
        label="B", best_model="NL_logistic", best_params=[1.2, 0.5, 0.01],
        param_names=["K", "mu", "N0"], best_aic=-12.0,
        fitted_curve=np.ones(5), times=times, loss=0.005, all_results=[],
    )
    results = GrowthFitResults(data=gd, results=[r1, r2])
    df = results.to_dataframe()
    assert list(df["label"]) == ["A", "B"]
    assert "param_1" in df.columns
    assert "param_3" in df.columns   # 3 params in r2
    # r1 has only 2 params so param_3 should be None or NaN
    val = df.loc[0, "param_3"]
    assert val is None or (isinstance(val, float) and np.isnan(val))
    assert len(results) == 2
    assert results[0].label == "A"
