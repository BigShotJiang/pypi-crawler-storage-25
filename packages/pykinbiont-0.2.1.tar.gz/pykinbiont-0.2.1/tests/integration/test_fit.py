"""Integration tests for fit() — require Julia + KinBiont.jl."""

import numpy as np
import pytest


pytestmark = pytest.mark.integration


def test_fit_loglin(small_growth_data, basic_opts, loglin_spec):
    from pykinbiont import fit
    results = fit(small_growth_data, loglin_spec, basic_opts)
    assert len(results) == 5
    for r in results:
        assert r.best_model == "log_lin"
        assert r.fitted_curve.ndim == 1
        assert np.isfinite(r.best_aic)
        assert np.isfinite(r.loss)


def test_fit_nl_logistic(small_growth_data, basic_opts, nl_logistic_spec):
    from pykinbiont import fit
    results = fit(small_growth_data, nl_logistic_spec, basic_opts)
    assert len(results) == 5
    for r in results:
        assert r.best_model == "NL_logistic"
        assert len(r.best_params) == 3
        assert r.best_params[0] > 0   # K > 0


def test_fit_custom_nl_callable(small_growth_data, basic_opts):
    from pykinbiont import fit, NLModel, ModelSpec
    import numpy as np

    def logistic(p, t):
        K, mu, N0 = p[0], p[1], p[2]
        return K / (1 + ((K - N0) / N0) * np.exp(-mu * t))

    model = NLModel(name="custom_logistic", func=logistic, param_names=["K", "mu", "N0"])
    spec = ModelSpec(models=[model], params=[[1.2, 0.5, 0.01]])
    results = fit(small_growth_data, spec, basic_opts)
    assert len(results) == 5
    for r in results:
        assert r.best_model == "custom_logistic"


def test_fit_clustering_only(small_growth_data):
    from pykinbiont import fit, FitOptions, ModelSpec, LogLinModel
    opts = FitOptions(cluster=True, n_clusters=2)
    spec = ModelSpec(models=[LogLinModel()], params=[[]])
    results = fit(small_growth_data, spec, opts)
    assert results.data.clusters is not None
    assert len(results.data.clusters) == 5
    assert set(results.data.clusters).issubset({1, 2})
    assert results.data.wcss is not None
    assert results.data.wcss >= 0.0


def test_fit_returns_growth_fit_results_interface(small_growth_data, basic_opts, loglin_spec):
    from pykinbiont import fit, GrowthFitResults
    results = fit(small_growth_data, loglin_spec, basic_opts)
    assert isinstance(results, GrowthFitResults)
    assert len(results) == 5
    assert results[0].label in small_growth_data.labels
    df = results.to_dataframe()
    assert list(df["label"]) == [r.label for r in results]
