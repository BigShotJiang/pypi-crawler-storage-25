"""Integration tests for save_results() — require Julia + KinBiont.jl."""

import pandas as pd
import pytest
from pathlib import Path

pytestmark = pytest.mark.integration


@pytest.fixture(scope="module")
def fit_results(small_growth_data, basic_opts, loglin_spec):
    from pykinbiont import fit
    return fit(small_growth_data, loglin_spec, basic_opts)


def test_save_results_creates_three_files(fit_results, tmp_path):
    from pykinbiont import save_results
    paths = save_results(fit_results, str(tmp_path))
    assert Path(paths["summary"]).exists()
    assert Path(paths["fitted_curves"]).exists()
    assert Path(paths["all_models"]).exists()


def test_save_results_summary_columns(fit_results, tmp_path):
    from pykinbiont import save_results
    paths = save_results(fit_results, str(tmp_path))
    df = pd.read_csv(paths["summary"])
    assert "label" in df.columns
    assert "best_model" in df.columns
    assert "aic" in df.columns
    assert len(df) == 5   # one row per curve


def test_save_results_fitted_curves_columns(fit_results, tmp_path):
    from pykinbiont import save_results
    paths = save_results(fit_results, str(tmp_path))
    df = pd.read_csv(paths["fitted_curves"])
    assert "label" in df.columns
    assert "time" in df.columns
    assert "fitted" in df.columns


def test_save_results_custom_prefix(fit_results, tmp_path):
    from pykinbiont import save_results
    paths = save_results(fit_results, str(tmp_path), prefix="myexp")
    assert Path(paths["summary"]).name == "myexp_summary.csv"
