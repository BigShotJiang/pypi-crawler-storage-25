"""Integration tests for preprocess() — require Julia + KinBiont.jl."""

import numpy as np
import pytest

pytestmark = pytest.mark.integration


def test_preprocess_smoothing(small_growth_data):
    from pykinbiont import preprocess, FitOptions, GrowthData
    opts = FitOptions(smooth=True, smooth_method="rolling_avg", smooth_pt_avg=5)
    result = preprocess(small_growth_data, opts)
    assert isinstance(result, GrowthData)
    assert result.curves.shape[0] == 5   # same number of curves


def test_preprocess_blank_subtraction(small_growth_data):
    from pykinbiont import preprocess, FitOptions
    opts = FitOptions(blank_subtraction=True, blank_value=0.02)
    result = preprocess(small_growth_data, opts)
    # All values should be shifted down by 0.02
    expected_shift = small_growth_data.curves - 0.02
    np.testing.assert_allclose(result.curves, expected_shift, atol=1e-10)


def test_preprocess_clustering_populates_clusters(small_growth_data):
    from pykinbiont import preprocess, FitOptions
    opts = FitOptions(cluster=True, n_clusters=2)
    result = preprocess(small_growth_data, opts)
    assert result.clusters is not None
    assert len(result.clusters) == 5
    assert set(result.clusters).issubset({1, 2})


def test_preprocess_clustering_centroids(small_growth_data):
    from pykinbiont import preprocess, FitOptions
    opts = FitOptions(cluster=True, n_clusters=2)
    result = preprocess(small_growth_data, opts)
    assert result.centroids is not None
    assert result.centroids.shape[0] == 2   # one centroid per cluster
    assert result.centroids.shape[1] == small_growth_data.curves.shape[1]


def test_preprocess_clustering_wcss(small_growth_data):
    from pykinbiont import preprocess, FitOptions
    opts = FitOptions(cluster=True, n_clusters=2)
    result = preprocess(small_growth_data, opts)
    assert result.wcss is not None
    assert result.wcss >= 0.0


def test_preprocess_no_mutation(small_growth_data):
    from pykinbiont import preprocess, FitOptions
    original_curves = small_growth_data.curves.copy()
    preprocess(small_growth_data, FitOptions(smooth=True))
    np.testing.assert_array_equal(small_growth_data.curves, original_curves)
