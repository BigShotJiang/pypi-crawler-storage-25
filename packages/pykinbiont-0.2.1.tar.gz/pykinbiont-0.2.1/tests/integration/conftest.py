"""Shared fixtures for integration tests (require Julia + KinBiont.jl)."""

import numpy as np
import pytest


def _logistic(t, K=1.2, mu=0.5, N0=0.01):
    """Synthetic logistic growth curve."""
    return K / (1 + ((K - N0) / N0) * np.exp(-mu * t))


@pytest.fixture(scope="session")
def small_growth_data():
    """5 curves × 50 time points, synthetic logistic growth with small noise."""
    from pykinbiont import GrowthData
    rng = np.random.default_rng(42)
    times = np.linspace(0, 20, 50)
    curves = np.stack([
        _logistic(times, K=1.0 + 0.1 * i, mu=0.4 + 0.05 * i) + rng.normal(0, 0.005, 50)
        for i in range(5)
    ])
    labels = [f"W{i+1}" for i in range(5)]
    return GrowthData(curves=curves, times=times, labels=labels)


@pytest.fixture(scope="session")
def basic_opts():
    from pykinbiont import FitOptions
    return FitOptions()


@pytest.fixture(scope="session")
def loglin_spec():
    from pykinbiont import ModelSpec, LogLinModel
    return ModelSpec(models=[LogLinModel()], params=[[]])


@pytest.fixture(scope="session")
def nl_logistic_spec():
    from pykinbiont import ModelSpec, MODEL_REGISTRY
    model = MODEL_REGISTRY["NL_logistic"]
    return ModelSpec(models=[model], params=[[1.2, 0.5, 0.01]])
