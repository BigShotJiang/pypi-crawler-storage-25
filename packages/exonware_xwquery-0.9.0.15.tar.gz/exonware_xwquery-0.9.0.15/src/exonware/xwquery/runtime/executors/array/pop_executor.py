#!/usr/bin/env python3
"""
POP Executor
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.15
"""

from typing import Any, Optional
from ..base import AUniversalOperationExecutor
from ....contracts import QueryAction, ExecutionContext, ExecutionResult
from ....defs import OperationType
from ..utils import extract_items, extract_field_value


class PopExecutor(AUniversalOperationExecutor):
    """POP - Remove and return an element from an array field."""
    OPERATION_NAME = "POP"
    OPERATION_TYPE = OperationType.ARRAY
    SUPPORTED_NODE_TYPES = []

    def _do_execute(self, action: QueryAction, context: ExecutionContext) -> ExecutionResult:
        params = action.params
        result_data = self._execute_op(context.node, params, context)
        return ExecutionResult(
            success=True,
            data=result_data,
            action_type=self.OPERATION_NAME,
            metadata={"operation": self.OPERATION_NAME},
        )

    def _execute_op(self, node: Any, params: dict, context: ExecutionContext) -> dict:
        field: Optional[str] = params.get("field")
        position: int = int(params.get("position", -1))
        as_field: str = params.get("as_field", "_popped")
        items = extract_items(node)

        result_items = []
        for item in items:
            item_copy = item.copy() if isinstance(item, dict) else {"value": item}
            current_value = extract_field_value(item_copy, field) if field else None
            target_array = list(current_value) if isinstance(current_value, list) else []

            popped_value = None
            if target_array:
                if position == 0:
                    popped_value = target_array.pop(0)
                else:
                    popped_value = target_array.pop()

            if field:
                item_copy[field] = target_array
            item_copy[as_field] = popped_value
            result_items.append(item_copy)

        return {
            "items": result_items,
            "count": len(result_items),
            "total_items": len(items),
            "field": field,
            "position": position,
            "as_field": as_field,
        }


__all__ = ["PopExecutor"]
