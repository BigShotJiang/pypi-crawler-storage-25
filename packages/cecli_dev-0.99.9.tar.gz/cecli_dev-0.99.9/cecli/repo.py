import contextlib
import os
import time
from pathlib import Path, PurePosixPath

try:
    import git

    ANY_GIT_ERROR = [
        git.exc.ODBError,
        git.exc.GitError,
        git.exc.InvalidGitRepositoryError,
        git.exc.GitCommandNotFound,
    ]
except ImportError:
    git = None
    ANY_GIT_ERROR = []

import pathspec

import cecli.prompts.utils.system as prompts
from cecli import utils

from .dump import dump  # noqa: F401

ANY_GIT_ERROR += [
    OSError,
    IndexError,
    BufferError,
    TypeError,
    ValueError,
    AttributeError,
    AssertionError,
    TimeoutError,
]
ANY_GIT_ERROR = tuple(ANY_GIT_ERROR)

git.Git.USE_SHELL = False


@contextlib.contextmanager
def set_git_env(var_name, value, original_value):
    """Temporarily set a Git environment variable."""
    os.environ[var_name] = value
    try:
        yield
    finally:
        if original_value is not None:
            os.environ[var_name] = original_value
        elif var_name in os.environ:
            del os.environ[var_name]


class GitRepo:
    repo = None
    cecli_ignore_file = None
    cecli_ignore_spec = None
    cecli_ignore_ts = 0
    cecli_ignore_last_check = 0
    subtree_only = False
    ignore_file_cache = {}
    git_repo_error = None
    gitignore_spec_cache = {}
    gitignore_file_cache = {}
    gitignore_last_check = 0

    def __init__(
        self,
        io,
        fnames,
        git_dname,
        cecli_ignore_file=None,
        models=None,
        attribute_author=True,
        attribute_committer=True,
        attribute_commit_message_author=False,
        attribute_commit_message_committer=False,
        commit_prompt=None,
        subtree_only=False,
        git_commit_verify=True,
        attribute_co_authored_by=False,  # Added parameter
    ):
        self.io = io
        self.models = models

        self.normalized_path = {}
        self.tree_files = {}

        self.attribute_author = attribute_author
        self.attribute_committer = attribute_committer
        self.attribute_commit_message_author = attribute_commit_message_author
        self.attribute_commit_message_committer = attribute_commit_message_committer
        self.attribute_co_authored_by = attribute_co_authored_by  # Assign from parameter
        self.commit_prompt = commit_prompt
        self.subtree_only = subtree_only
        self.git_commit_verify = git_commit_verify
        self.ignore_file_cache = {}
        self.is_workspace = False
        self.workspace_path = None
        self.workspace_config = {}
        self.workspace_ignore_specs = {}
        self.workspace_ignore_ts = {}
        # Workspace detection and config loading occurs later in __init__

        if git_dname:
            check_fnames = [git_dname]
        elif fnames:
            check_fnames = fnames
        else:
            check_fnames = ["."]

        repo_paths = []
        for fname in check_fnames:
            fname = Path(fname)
            fname = fname.resolve()

            if not fname.exists() and fname.parent.exists():
                fname = fname.parent

            try:
                with git.Repo(
                    fname, search_parent_directories=True, odbt=git.GitCmdObjectDB
                ) as temp_repo:
                    repo_path = utils.safe_abs_path(temp_repo.working_dir)
                    repo_paths.append(repo_path)
            except ANY_GIT_ERROR:
                pass

        num_repos = len(set(repo_paths))

        if num_repos == 0:
            raise FileNotFoundError
        if num_repos > 1:
            self.io.tool_error("Files are in different git repos.")
            raise FileNotFoundError

        self._init_repo_path = repo_paths.pop()

        # Detect if we're in a workspace
        self.workspace_path = self._detect_workspace_path(self._init_repo_path)
        if self.workspace_path:
            self.is_workspace = True

            try:
                from cecli.helpers.monorepo.config import load_workspace_config

                self.workspace_config = load_workspace_config(name=self.workspace_path.name)
            except Exception:
                self.workspace_config = {}

            self.refresh_cecli_ignore()

        self.init_repo()
        if cecli_ignore_file:
            self.cecli_ignore_file = Path(cecli_ignore_file)

    def init_repo(self):
        if not self.repo:
            self.repo = git.Repo(self._init_repo_path, odbt=git.GitCmdObjectDB)
            self.root = utils.safe_abs_path(self.repo.working_tree_dir)

        if self.is_workspace:
            self.root = self.workspace_path

        try:
            commit = self.repo.head.commit
            return commit
        except ANY_GIT_ERROR:
            if not self.is_workspace:
                self.repo = git.Repo(self._init_repo_path, odbt=git.GitCmdObjectDB)
                self.root = utils.safe_abs_path(self.repo.working_tree_dir)

    def _detect_workspace_path(self, start_path: str):
        """Check if current directory is within a workspace"""
        current = Path(start_path).resolve()
        workspace_root = Path("~/.cecli/workspaces").expanduser()

        # Walk up directory tree looking for workspace root
        while current != current.parent:
            if workspace_root in current.parents or current == workspace_root:
                # If we are inside the workspace root, the workspace is the first child of workspace_root
                try:
                    rel = current.relative_to(workspace_root)
                    if rel.parts:
                        return workspace_root / rel.parts[0]
                except (IndexError, ValueError):
                    pass

            # Alternative check: look for .cecli-workspace.json
            if (current / ".cecli-workspace.json").exists():
                return current

            current = current.parent
        return None

    def __del__(self):
        if self.repo:
            self.repo.close()

    async def commit(self, fnames=None, context=None, message=None, coder_edits=False, coder=None):
        """
        Commit the specified files or all dirty files if none are specified.

        Args:
            fnames (list, optional): List of filenames to commit. Defaults to None (commit all
                                     dirty files).
            context (str, optional): Context for generating commit message. Defaults to None.
            message (str, optional): Explicit commit message. Defaults to None (generate message).
            coder_edits (bool, optional): Whether the changes were made by cecli. Defaults to False.
                                          This affects attribution logic.
            coder (Coder, optional): The Coder instance, used for config and model info.
                                     Defaults to None.

        Returns:
            tuple(str, str) or None: The commit hash and commit message if successful,
                                     else None.

        Attribution Logic:
        ------------------
        This method handles Git commit attribution based on configuration flags and whether
        cecli generated the changes (`coder_edits`).

        Key Concepts:
        - Author: The person who originally wrote the code changes.
        - Committer: The person who last applied the commit to the repository.
        - coder_edits=True: Changes were generated by cecli (LLM).
        - coder_edits=False: Commit is user-driven (e.g., /commit manually staged changes).
        - Explicit Setting: A flag (--attribute-...) is set to True or False
          via command line or config file.
        - Implicit Default: A flag is not explicitly set, defaulting to None in args, which is
          interpreted as True unless overridden by other logic.

        Flags:
        - --attribute-author: Modify Author name to "User Name (cecli)".
        - --attribute-committer: Modify Committer name to "User Name (cecli)".
        - --attribute-co-authored-by: Add
          "Co-authored-by: cecli (<model>)" trailer to commit message.

        Behavior Summary:

        1. When coder_edits = True (AI Changes):
           - If --attribute-co-authored-by=True:
             - Co-authored-by trailer IS ADDED.
             - Author/Committer names are NOT modified by default (co-authored-by takes precedence).
             - EXCEPTION: If --attribute-author/--attribute-committer is EXPLICITLY True, the
               respective name IS modified (explicit overrides precedence).
           - If --attribute-co-authored-by=False:
             - Co-authored-by trailer is NOT added.
             - Author/Committer names ARE modified by default (implicit True).
             - EXCEPTION: If --attribute-author/--attribute-committer is EXPLICITLY False,
               the respective name is NOT modified.

        2. When coder_edits = False (User Changes):
           - --attribute-co-authored-by is IGNORED (trailer never added).
           - Author name is NEVER modified (--attribute-author ignored).
           - Committer name IS modified by default (implicit True, as cecli runs `git commit`).
           - EXCEPTION: If --attribute-committer is EXPLICITLY False, the name is NOT modified.

        Resulting Scenarios:
        - Standard AI edit (defaults): Co-authored-by=False -> Author=You(cecli),
          Committer=You(cecli)
        - AI edit with Co-authored-by (default): Co-authored-by=True -> Author=You,
          Committer=You, Trailer added
        - AI edit with Co-authored-by + Explicit Author: Co-authored-by=True,
          --attribute-author -> Author=You(cecli), Committer=You, Trailer added
        - User commit (defaults): coder_edits=False -> Author=You, Committer=You(cecli)
        - User commit with explicit no-committer: coder_edits=False,
          --no-attribute-committer -> Author=You, Committer=You
        """
        if not fnames and not self.repo.is_dirty():
            return

        diffs = self.get_diffs(fnames)
        if not diffs:
            return

        if message:
            commit_message = message
        else:
            user_language = None
            if coder:
                user_language = coder.commit_language
                if not user_language:
                    user_language = coder.get_user_language()
            commit_message = await self.get_commit_message(diffs, context, user_language)

        # Retrieve attribute settings, prioritizing coder.args if available
        if coder and hasattr(coder, "args") and coder.args:
            attribute_author = coder.args.attribute_author
            attribute_committer = coder.args.attribute_committer
            attribute_commit_message_author = coder.args.attribute_commit_message_author
            attribute_commit_message_committer = coder.args.attribute_commit_message_committer
            attribute_co_authored_by = coder.args.attribute_co_authored_by
        else:
            # Fallback to self attributes (initialized from config/defaults)
            attribute_author = self.attribute_author
            attribute_committer = self.attribute_committer
            attribute_commit_message_author = self.attribute_commit_message_author
            attribute_commit_message_committer = self.attribute_commit_message_committer
            attribute_co_authored_by = self.attribute_co_authored_by

        # Determine explicit settings (None means use default behavior)
        author_explicit = attribute_author is not None
        committer_explicit = attribute_committer is not None

        # Determine effective settings (apply default True if not explicit)
        effective_author = True if attribute_author is None else attribute_author
        effective_committer = True if attribute_committer is None else attribute_committer

        # Determine commit message prefixing
        prefix_commit_message = coder_edits and (
            attribute_commit_message_author or attribute_commit_message_committer
        )

        # Determine Co-authored-by trailer
        commit_message_trailer = ""
        if coder_edits and attribute_co_authored_by:
            model_name = "unknown-model"
            if coder and hasattr(coder, "main_model") and coder.main_model.name:
                model_name = coder.main_model.name
            commit_message_trailer = f"\n\nCo-authored-by: cecli ({model_name})"

        # Determine if author/committer names should be modified
        # Author modification applies only to cecli edits.
        # It's used if effective_author is True AND
        # (co-authored-by is False OR author was explicitly set).
        use_attribute_author = (
            coder_edits and effective_author and (not attribute_co_authored_by or author_explicit)
        )

        # Committer modification applies regardless of coder_edits (based on tests).
        # It's used if effective_committer is True AND
        # (it's not an cecli edit with co-authored-by OR committer was explicitly set).
        use_attribute_committer = effective_committer and (
            not (coder_edits and attribute_co_authored_by) or committer_explicit
        )

        if not commit_message:
            commit_message = "(no commit message provided)"

        if prefix_commit_message:
            commit_message = "cecli: " + commit_message

        full_commit_message = commit_message + commit_message_trailer

        cmd = ["-m", full_commit_message]
        if not self.git_commit_verify:
            cmd.append("--no-verify")
        if fnames:
            fnames = [str(self.abs_root_path(fn)) for fn in fnames]
            added_fnames = []
            for fname in fnames:
                try:
                    # Check if file is git-ignored before trying to add
                    if (
                        coder
                        and hasattr(coder, "add_gitignore_files")
                        and coder.add_gitignore_files
                    ):
                        rel_fname = self.get_rel_fname(fname)
                        if self.git_ignored_file(rel_fname):
                            # Skip git-ignored files when add_gitignore_files is enabled
                            continue
                    self.repo.git.add(fname)
                    added_fnames.append(fname)
                except ANY_GIT_ERROR as err:
                    self.io.tool_error(f"Unable to add {fname}: {err}")
            if added_fnames:
                cmd += ["--"] + added_fnames
            else:
                # No files to commit (all were git-ignored or failed to add)
                return
        else:
            cmd += ["-a"]

        original_user_name = self.repo.git.config("--get", "user.name")
        original_committer_name_env = os.environ.get("GIT_COMMITTER_NAME")
        original_author_name_env = os.environ.get("GIT_AUTHOR_NAME")
        committer_name = f"{original_user_name} (cecli)"

        try:
            # Use context managers to handle environment variables
            with contextlib.ExitStack() as stack:
                if use_attribute_committer:
                    stack.enter_context(
                        set_git_env(
                            "GIT_COMMITTER_NAME", committer_name, original_committer_name_env
                        )
                    )
                if use_attribute_author:
                    stack.enter_context(
                        set_git_env("GIT_AUTHOR_NAME", committer_name, original_author_name_env)
                    )

                # Perform the commit
                self.repo.git.commit(cmd)
                commit_hash = self.get_head_commit_sha(short=True)
                self.io.tool_success(f"Commit {commit_hash} {commit_message}")
                return commit_hash, commit_message

        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to commit: {err}")
            # No return here, implicitly returns None

    def get_rel_repo_dir(self):
        try:
            return os.path.relpath(self.repo.git_dir, os.getcwd())
        except (ValueError, OSError):
            return self.repo.git_dir

    def get_rel_fname(self, fname):
        try:
            return os.path.relpath(fname, self.root)
        except ValueError:
            return fname

    async def get_commit_message(self, diffs, context, user_language=None):
        diffs = "# Diffs:\n" + diffs

        content = ""
        if context:
            content += context + "\n"
        content += diffs

        system_content = self.commit_prompt or prompts.commit_system

        language_instruction = ""
        if user_language:
            language_instruction = f"\n- Is written in {user_language}."
        system_content = system_content.format(language_instruction=language_instruction)

        commit_message = None
        for model in self.models:
            spinner_text = f"Generating commit message with {model.name}\n"
            self.io.start_spinner(spinner_text, update_last_text=False)

            if model.system_prompt_prefix:
                current_system_content = model.system_prompt_prefix + "\n" + system_content
            else:
                current_system_content = system_content

            messages = [
                dict(role="system", content=current_system_content),
                dict(role="user", content=content),
            ]

            num_tokens = model.token_count(messages)
            max_tokens = model.info.get("max_input_tokens") or 0

            if max_tokens and num_tokens > max_tokens:
                continue

            commit_message = await model.simple_send_with_retries(
                messages,
                override_kwargs={
                    "reasoning_effort": None,
                    "thinking": None,
                    "drop_params": True,
                },
            )
            if commit_message:
                break  # Found a model that could generate the message

        if not commit_message:
            self.io.tool_error("Failed to generate commit message!")
            return

        commit_message = commit_message.strip()
        if commit_message and commit_message[0] == '"' and commit_message[-1] == '"':
            commit_message = commit_message[1:-1].strip()

        self.io.start_spinner(self.io.last_spinner_text, update_last_text=False)
        return commit_message

    def get_diffs(self, fnames=None):
        # We always want diffs of index and working dir

        current_branch_has_commits = False
        try:
            active_branch = self.repo.active_branch
            try:
                commits = self.repo.iter_commits(active_branch)
                current_branch_has_commits = any(commits)
            except ANY_GIT_ERROR:
                pass
        except (TypeError,) + ANY_GIT_ERROR:
            pass

        if not fnames:
            fnames = []

        diffs = ""
        for fname in fnames:
            if not self.path_in_repo(fname):
                diffs += f"Added {fname}\n"

        try:
            if current_branch_has_commits:
                args = ["HEAD", "--"] + list(fnames)
                diffs += self.repo.git.diff(*args, stdout_as_string=False).decode(
                    self.io.encoding, "replace"
                )
                return diffs

            wd_args = ["--"] + list(fnames)
            index_args = ["--cached"] + wd_args

            diffs += self.repo.git.diff(*index_args, stdout_as_string=False).decode(
                self.io.encoding, "replace"
            )
            diffs += self.repo.git.diff(*wd_args, stdout_as_string=False).decode(
                self.io.encoding, "replace"
            )

            return diffs
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to diff: {err}")

    def diff_commits(self, pretty, from_commit, to_commit=None):
        args = []
        if pretty:
            args += ["--color"]
        else:
            args += ["--color=never"]

        if to_commit is not None:
            args += [from_commit, to_commit]
        else:
            args += [from_commit]
        diffs = self.repo.git.diff(*args, stdout_as_string=False).decode(
            self.io.encoding, "replace"
        )

        return diffs

    def get_tracked_files(self):
        if not self.repo:
            return []

        self.init_repo()

        try:
            commit = self.repo.head.commit
        except ValueError:
            commit = None
        except ANY_GIT_ERROR as err:
            self.git_repo_error = err
            self.io.tool_error(f"Unable to list files in git repo: {err}")
            self.io.tool_output("Is your git repo corrupted?")
            return []

        files = set()
        if commit:
            if commit in self.tree_files:
                files = self.tree_files[commit]
            else:
                try:
                    iterator = commit.tree.traverse()
                    blob = None  # Initialize blob
                    while True:
                        try:
                            blob = next(iterator)
                            if blob.type == "blob":  # blob is a file
                                files.add(blob.path)
                        except IndexError:
                            # Handle potential index error during tree traversal
                            # without relying on potentially unassigned 'blob'
                            self.io.tool_warning(
                                "GitRepo: Index error encountered while reading git tree object."
                                " Skipping."
                            )
                            continue
                        except StopIteration:
                            break
                except ANY_GIT_ERROR as err:
                    self.git_repo_error = err
                    self.io.tool_error(f"Unable to list files in git repo: {err}")
                    self.io.tool_output("Is your git repo corrupted?")
                    return []
                files = set(self.normalize_path(path) for path in files)
                self.tree_files[commit] = set(files)

        # Add staged files
        index = self.repo.index
        try:
            staged_files = [path for path, _ in index.entries.keys()]
            files.update(self.normalize_path(path) for path in staged_files)
        except ANY_GIT_ERROR as err:
            self.io.tool_error(f"Unable to read staged files: {err}")

        res = [fname for fname in files if not self.ignored_file(fname)]

        return res

    def get_workspace_files(self):
        """
        If in a workspace, return all tracked files from all projects.
        Paths are relative to the workspace root.
        """
        if not self.workspace_path:
            return self.get_tracked_files()

        import hashlib
        import json
        import subprocess

        metadata_path = self.workspace_path / ".cecli-workspace.json"
        if not metadata_path.exists():
            return self.get_tracked_files()

        try:
            with open(metadata_path, "r") as f:
                config = json.load(f)
        except Exception:
            return self.get_tracked_files()

        # Generate a cache key based on the SHAs of all project HEADs
        # This is similar to how base_coder uses staged files hash
        projects = config.get("projects", [])
        project_shas = []
        for proj in projects:
            proj_name = proj.get("name")
            if not proj_name:
                continue
            proj_root = self.workspace_path / proj_name / "main"
            if not proj_root.exists():
                continue
            try:
                sha = subprocess.check_output(
                    ["git", "-C", str(proj_root), "rev-parse", "HEAD"],
                    stderr=subprocess.DEVNULL,
                    encoding="utf-8",
                ).strip()
                project_shas.append(f"{proj_name}:{sha}")
            except Exception:
                project_shas.append(f"{proj_name}:unknown")

        cache_key = hashlib.sha1(",".join(project_shas).encode()).hexdigest()

        if hasattr(self, "_workspace_files_cache"):
            cached_key, cached_files = self._workspace_files_cache
            if cached_key == cache_key:
                return cached_files

        all_files = []
        for proj in projects:
            proj_name = proj.get("name")
            if not proj_name:
                continue

            proj_root = self.workspace_path / proj_name / "main"
            if not proj_root.exists():
                continue

            try:
                res = subprocess.check_output(
                    ["git", "-C", str(proj_root), "ls-files"],
                    stderr=subprocess.DEVNULL,
                    encoding="utf-8",
                ).splitlines()

                for f in res:
                    rel_path = f"{proj_name}/main/{f}"
                    if not self.ignored_file(rel_path):
                        all_files.append(rel_path)
            except Exception:
                continue

        self._workspace_files_cache = (cache_key, all_files)
        return all_files

    def normalize_path(self, path):
        orig_path = path
        res = self.normalized_path.get(orig_path)
        if res:
            return res

        if self.is_workspace:
            try:
                # In workspace mode, try to make it relative to workspace_path first
                path = str(
                    Path(
                        PurePosixPath(
                            (Path(self.workspace_path) / path).relative_to(self.workspace_path)
                        )
                    )
                )
            except ValueError:
                # Fallback to standard relative_to(self.root)
                path = str(Path(PurePosixPath((Path(self.root) / path).relative_to(self.root))))
        else:
            path = str(Path(PurePosixPath((Path(self.root) / path).relative_to(self.root))))

        self.normalized_path[orig_path] = path
        return path

    def refresh_cecli_ignore(self):
        if not self.cecli_ignore_file and not self.is_workspace:
            return

        current_time = time.time()
        if current_time - self.cecli_ignore_last_check < 1:
            return

        if self.is_workspace:
            self._refresh_workspace_ignores()

        self.cecli_ignore_last_check = current_time

        if not self.cecli_ignore_file or not self.cecli_ignore_file.is_file():
            return

        mtime = self.cecli_ignore_file.stat().st_mtime
        if mtime != self.cecli_ignore_ts:
            self.cecli_ignore_ts = mtime
            self.ignore_file_cache = {}
            lines = self.cecli_ignore_file.read_text().splitlines()
            self.cecli_ignore_spec = pathspec.PathSpec.from_lines(
                pathspec.patterns.GitWildMatchPattern,
                lines,
            )

    def _refresh_workspace_ignores(self):
        if not hasattr(self, "workspace_config") or not self.workspace_config:
            return

        if not hasattr(self, "workspace_ignore_specs"):
            self.workspace_ignore_specs = {}
            self.workspace_ignore_ts = {}

        projects = self.workspace_config.get("projects", [])
        for proj in projects:
            proj_name = proj.get("name")
            ignore_file = proj.get("ignore")
            if not proj_name or not ignore_file:
                continue

            ignore_path = self.workspace_path / f"{proj_name}.ignore"
            if not ignore_path.is_file():
                continue

            mtime = ignore_path.stat().st_mtime
            if mtime != self.workspace_ignore_ts.get(proj_name):
                self.workspace_ignore_ts[proj_name] = mtime
                self.ignore_file_cache = {}
                lines = ignore_path.read_text().splitlines()
                self.workspace_ignore_specs[proj_name] = pathspec.PathSpec.from_lines(
                    pathspec.patterns.GitWildMatchPattern,
                    lines,
                )

    def _get_gitignore_spec(self, dir_path):
        """Get or create a GitIgnoreSpec for a directory, caching for performance."""
        dir_path = Path(dir_path).resolve()

        # Check cache first
        if dir_path in self.gitignore_spec_cache:
            return self.gitignore_spec_cache[dir_path]

        # Read .gitignore from this directory
        patterns = []
        gitignore_path = dir_path / ".gitignore"
        if gitignore_path.is_file():
            try:
                with open(gitignore_path, "r") as f:
                    patterns = [
                        line.rstrip("\n") for line in f if line.strip() and not line.startswith("#")
                    ]
            except (OSError, IOError):
                pass

        # Create spec for this directory
        if patterns:
            spec = pathspec.GitIgnoreSpec.from_lines(patterns)
        else:
            spec = pathspec.GitIgnoreSpec.from_lines([])

        self.gitignore_spec_cache[dir_path] = spec
        return spec

    def _is_gitignored_by_pathspec(self, path):
        """Check if a file is ignored by any .gitignore file using pathspec."""
        if not self.repo:
            return False

        try:
            file_path = Path(path).resolve()
            if not file_path.is_relative_to(self.root):
                return False

            # Walk up from file's directory to root
            current_dir = file_path.parent
            relative_path = file_path.relative_to(self.root)

            # Check each directory level
            while current_dir.is_relative_to(self.root):
                spec = self._get_gitignore_spec(current_dir)

                # Get path relative to the directory containing the .gitignore
                if current_dir == Path(self.root).resolve():
                    path_to_check = str(relative_path)
                else:
                    path_to_check = str(
                        relative_path.relative_to(current_dir.relative_to(self.root))
                    )

                if spec.match_file(path_to_check):
                    return True

                # Move up one directory
                if current_dir == Path(self.root).resolve():
                    break
                current_dir = current_dir.parent

            return False
        except (ValueError, OSError):
            return False

    def git_ignored_file(self, path):
        if not self.repo:
            return
        try:
            if not self.cecli_ignore_file or not self.cecli_ignore_file.is_file():
                return self._is_gitignored_by_pathspec(path)
            else:
                return self.ignored_file(path)
        except ANY_GIT_ERROR:
            return False

    def ignored_file(self, fname):
        self.refresh_cecli_ignore()

        if fname in self.ignore_file_cache:
            return self.ignore_file_cache[fname]

        result = self.ignored_file_raw(fname)
        self.ignore_file_cache[fname] = result
        return result

    def ignored_file_raw(self, fname):
        if self.subtree_only:
            try:
                fname_path = Path(self.normalize_path(fname))
                cwd_path = Path.cwd().resolve().relative_to(Path(self.root).resolve())
            except ValueError:
                # Issue #1524
                # ValueError: 'C:\\dev\\squid-certbot' is not in the subpath of
                # 'C:\\dev\\squid-certbot'
                # Clearly, fname is not under cwd... so ignore it
                return True

            if cwd_path not in fname_path.parents and fname_path != cwd_path:
                return True

        if self.is_workspace:
            # Check project-specific ignores
            try:
                fname_rel = self.normalize_path(fname)
                parts = Path(fname_rel).parts
                if parts:
                    proj_name = parts[0]
                    if (
                        hasattr(self, "workspace_ignore_specs")
                        and proj_name in self.workspace_ignore_specs
                    ):
                        # Check against project-specific spec
                        # The spec expects paths relative to the project root (usually proj/main/)
                        if len(parts) > 2 and parts[1] == "main":
                            proj_rel_path = str(Path(*parts[2:]))
                        else:
                            proj_rel_path = str(Path(*parts[1:]))

                        if self.workspace_ignore_specs[proj_name].match_file(proj_rel_path):
                            return True
                # If not matched by project-specific ignore, continue to global ignore
                # but don't return False yet as there might be a global .cecli.ignore
            except (ValueError, IndexError):
                pass

        if not self.cecli_ignore_file or not self.cecli_ignore_file.is_file():
            return False

        try:
            fname = self.normalize_path(fname)
        except ValueError:
            return True

        return self.cecli_ignore_spec.match_file(fname)

    def get_non_ignored_files_from_root(self):
        """
        Return a set of all files in the repository that match the cecli ignore spec.

        Uses pathspec's match_tree_files method to efficiently find all matching files
        from the project root directory.

        Returns:
            set: Set of relative file paths that are ignored by the cecli ignore spec.
        """
        self.refresh_cecli_ignore()

        if not self.cecli_ignore_file or not self.cecli_ignore_file.is_file():
            return []

        if not self.cecli_ignore_spec:
            return []

        try:
            all_files = self.repo.git.ls_files(
                "--others", "--cached", f"--exclude-from={str(self.cecli_ignore_file)}"
            ).splitlines()

            return [f for f in all_files if not self.ignored_file(f)]
        except Exception as e:
            # Fall back to empty set if there's an error
            self.io.tool_warning(f"Error getting ignored files from root: {e}")
            return []

    def path_in_repo(self, path):
        if not self.repo:
            return
        if not path:
            return

        tracked_files = set(self.get_tracked_files())
        return self.normalize_path(path) in tracked_files

    def abs_root_path(self, path):
        res = Path(self.root) / path
        return utils.safe_abs_path(res)

    def get_dirty_files(self):
        """
        Returns a list of all files which are dirty (not committed), either staged or in the working
        directory.
        """
        dirty_files = set()

        # Get staged files
        staged_files = self.repo.git.diff("--name-only", "--cached").splitlines()
        dirty_files.update(staged_files)

        # Get unstaged files
        unstaged_files = self.repo.git.diff("--name-only").splitlines()
        dirty_files.update(unstaged_files)

        return list(dirty_files)

    def is_dirty(self, path=None):
        if path and not self.path_in_repo(path):
            return True

        return self.repo.is_dirty(path=path)

    def get_head_commit(self):
        try:
            return self.repo.head.commit
        except (ValueError,) + ANY_GIT_ERROR:
            return None

    def get_head_commit_sha(self, short=False):
        commit = self.get_head_commit()
        if not commit:
            return
        if short:
            return commit.hexsha[:7]
        return commit.hexsha

    def get_head_commit_message(self, default=None):
        commit = self.get_head_commit()
        if not commit:
            return default
        return commit.message
