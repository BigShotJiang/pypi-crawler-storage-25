
import pyvista as pv
import numpy as np
from tqdm import tqdm

from .Point3 import Point3
from .Color4 import Color4

from jerboapy import *

def convert_vertices_attributes(gmap):
    vertices = []
    normals = []
    colors = []
    for dart in tqdm(gmap, desc="Extraction of vertices attributes"):
        p = dart.ebd123.get("pos", Point3(0.0, 0.0, 0.0))
        if isinstance(p, Point3) or isinstance(p, Color4):
            p = p.toNumpy()
        vertices.append(p)
        
        n = dart.ebd01.get("normal", Point3(0.0, 0.0, 1.0))
        if isinstance(n, Point3) or isinstance(n, Color4):
            n = n.toNumpy()
        else:
            print(">>> normal is not a Point3 or Color4: ", n)
        normals.append(n)
        
        c = dart.ebd01.get("color", Color4(1.0, 1.0, 1.0))
        if isinstance(c, Point3) or isinstance(c, Color4):
            c = c.toNumpy()
        # else:
        #     print(">>> color is not a Point3 or Color4: ", c)
        c = np.resize(c, 4) if len(c) > 4 else np.pad(c, (0, 4 - len(c)), constant_values=1.0)
        colors.append(c)
    return (
        np.array(vertices, dtype=np.float32),
        np.array(normals, dtype=np.float32),
        np.array(colors, dtype=np.float32),
    )


def convert_faces(gmap):
    islet01 = Islet([0,1])
    ilot01 = islet01(gmap)
    # print(">>> ilot01 : ", ilot01)
    faces_flat = []
    # print("islet done.")
    faces_darts = set(ilot01)
    
    for id in tqdm(faces_darts, desc="Extraction of faces"):
        # print(">>> FaceID: ", id)
        face = []
        size = 0
        cur = id
        marks = []
        while cur not in marks:
            if size%2 == 0:
                # print("    >>> point : ", cur, " -> ", gmap[cur].ebd123.get("pos", [-10.0, -11.0, -12.0]))
                face.append(cur)
            marks.append(cur)
            cur = gmap.alpha(cur, size%2)
            size += 1
        # print(">>> new face : {} - size : {}".format(id, len(face)))
        faces_flat.append(len(face))
        faces_flat.extend(face)
    
    return faces_flat
def extract_geometries(gmap,
                    ebdpos={"name":"pos", "orbit": Orbit([1,2,3])}, 
                    ebdnormal={"name":"normal", "orbit": Orbit([0,1])}, 
                    ebdcolor={"name":"color", "orbit": Orbit([0,1])}):
    """
    Extracts vertices, normals, colors and faces from the given gmap.
    
    Parameters:
    - gmap: The GMap3D object to extract geometries from.
    - ebdpos: The key for position in the edge-based data (default is "pos").
    - ebdnormal: The key for normal in the edge-based data (default is "normal").
    - ebdcolor: The key for color in the edge-based data (default is "color").
    
    Returns:
    - A tuple containing vertices, normals, colors, and faces.
    """
    (vertdart, faces_flat) = gmap.extractGeometryCompacted3D()

    vertices = []
    normals = []
    colors = []
    for did in tqdm(vertdart, desc="Extraction of the geometry"):
        p = np.array(gmap.e(did, ebdpos["orbit"]).get(ebdpos["name"], Point3(0.0, 0.0, 0.0)), dtype=np.float32).ravel()
        vertices.append(p)

        n = np.array(gmap.e(did, ebdnormal["orbit"]).get(ebdnormal["name"], Point3(0.0, 0.0, 1.0)), dtype=np.float32).ravel()
        normals.append(n)

        c = gmap.e(did, ebdcolor["orbit"]).get(ebdcolor["name"], Color4.LIGHTGRAY)
        if hasattr(c, '__array__'):
            c = np.array(c.__array__(), dtype=np.float32)
        else:
            c = np.array(c, dtype=np.float32)
        c = c.ravel()
        c = np.resize(c, 4) if c.size > 4 else np.pad(c, (0, 4 - c.size), constant_values=1.0)
        colors.append(c)

    faces_flat = [item for sublist in faces_flat for item in [len(sublist)] + sublist]

    return (
        np.array(vertices, dtype=np.float32),
        np.array(normals, dtype=np.float32),
        np.array(colors, dtype=np.float32),
        faces_flat
    )



# @numba.jit(nopython=True, parallel=True)
def extract_geometries_old(gmap,ebdpos="pos", ebdnormal="normal", ebdcolor="color"):
    vertices = []
    normals = []
    colors = []
    faces_flat = []
    # islet01 = Islet([0,1])
    # ilot01 = islet01(gmap)
    

    for dart in tqdm(gmap, desc="Extraction of the geometry"):

        p = np.array(dart.ebd123.get(ebdpos, Point3(0.0, 0.0, 0.0)).ravel())
        vertices.append(p)

        n = np.array(dart.ebd01.get(ebdnormal, Point3(0.0, 0.0, 1.0)).ravel())
        normals.append(n)

        c = np.array(dart.ebd01.get(ebdcolor, Color4.LIGHTGRAY).toNumpy().ravel())
        c = np.resize(c, 4) if c.size > 4 else np.pad(c, (0, 4 - c.size), constant_values=1.0)
        colors.append(c)
        
    
    faces_flat = gmap.extractFaces2D()
    faces_flat = [item for sublist in faces_flat for item in [len(sublist)] + sublist]

    return (
        np.array(vertices, dtype=np.float32),
        np.array(normals, dtype=np.float32),
        np.array(colors, dtype=np.float32),
        faces_flat
    )


def extract_geometries_compact(gmap,ebdpos="pos", ebdnormal="normal", ebdcolor="color"):
    vertices = []
    normals = []
    colors = []
    faces_flat = []
    islet01 = Islet([0,1])
    ilot01 = islet01(gmap)
    

    for dart in tqdm(gmap, desc="Extraction of the geometry"):
        id = dart.id
        
        if id == ilot01[id]:
            # print(">>> FaceID: ", id)
            face = []
            size = 0
            cur = id
            marks = []
            while cur not in marks:
                if size%2 == 0:
                    # print("    >>> point : ", cur, " -> ", gmap[cur].ebd123.get("pos", [-10.0, -11.0, -12.0]))
                    newid = len(vertices)
                    p = dart.ebd123.get(ebdpos, Point3(0.0, 0.0, 0.0))
                    # if isinstance(p, Point3) or isinstance(p, Color4):
                    if hasattr(p, '__array__'):
                        p = np.array(p.__array__(), dtype=np.float32)
                    vertices.append(p)
                    
                    n = dart.ebd01.get(ebdnormal, Point3(0.0, 0.0, 1.0))
                    # if isinstance(n, Point3) or isinstance(n, Color4):
                    if hasattr(n, '__array__'):
                        n = np.array(n.__array__(), dtype=np.float32)
                    else:
                        print(">>> normal is not a Point3 or Color4: ", n)
                    normals.append(n)
                    
                    c = dart.ebd01.get(ebdcolor, Color4(1.0, 1.0, 1.0))
                    # if isinstance(c, Point3) or isinstance(c, Color4):
                    if hasattr(c, '__array__'):
                        c = np.array(c.__array__(), dtype=np.float32)
                    c = np.resize(c, 4) if c.size > 4 else np.pad(c, (0, 4 - c.size), constant_values=1.0)
                    colors.append(c)
                    face.append(newid)
                    # face.append(cur)
                marks.append(cur)
                cur = gmap.alpha(cur, size%2)
                size += 1
            # print(">>> new face : {} - size : {}".format(id, len(face)))
            faces_flat.append(len(face))
            faces_flat.extend(face)


    return (
        np.array(vertices, dtype=np.float32),
        np.array(normals, dtype=np.float32),
        np.array(colors, dtype=np.float32),
        faces_flat
    )


def show(gmap, title="Jerboa display",  ebdpos={"name":"pos", "orbit": Orbit([1,2,3])}, 
                    ebdnormal={"name":"normal", "orbit": Orbit([0,1])}, 
                    ebdcolor={"name":"color", "orbit": Orbit([0,1])},
                    with_ui=True):
    # vertices, normals, colors = convert_vertices_attributes(gmap)
    # faces = convert_faces(gmap)

    vertices, normals, colors, faces = extract_geometries(gmap,
        ebdpos=ebdpos,
        ebdnormal=ebdnormal,
        ebdcolor=ebdcolor
    )
    # vertices, normals, colors, faces = extract_geometries_compact(gmap)

    print("Prepare polydata by pyvista...")
    # Create a PyVista PolyData object
    mesh = pv.PolyData(vertices, faces)

    # Add normals and colors to the mesh
    mesh["Normals"] = normals
    mesh["Colors"] = colors
    
    print("Prepare plotter for pyvista...")
    # Create a PyVista plotter
    plotter = pv.Plotter(window_size=(1280, 960), notebook=False, off_screen=False, title=title)

    # Constantes UI
    UI_FONT_SIZE = 8
    SLIDER_TITLE_HEIGHT = 0.012
    SLIDER_LABEL_HEIGHT = 0.010

    # Acteur principal du mesh (référencé par nom pour updates dynamiques).
    line_width_state = 3.0
    show_edges_state = True
    show_points_state = False
    wireframe_state = False
    point_size_state = 10.0

    mesh_actor = plotter.add_mesh(
        mesh,
        scalars="Colors",
        rgb=True,
        show_edges=show_edges_state,
        line_width=line_width_state,
        style="surface",
        name="main_mesh",
    )

    if with_ui:
        plotter.add_axes(interactive=True, viewport=(0.84, 0.84, 0.995, 0.995))

        # --- Widgets natifs PyVista ---
        # 1. Slider pour l'épaisseur des arêtes
        def update_edge_width(value):
            nonlocal mesh_actor, line_width_state
            line_width_state = float(value)
            if mesh_actor is not None:
                mesh_actor.prop.line_width = line_width_state
            plotter.render()

        plotter.add_slider_widget(
            callback=update_edge_width,
            rng=[0.1, 10],
            value=1,
            title="Épaisseur arêtes",
            style='modern',
            pointa=(0.65, 0.08),
            pointb=(0.95, 0.08),
            title_height=SLIDER_TITLE_HEIGHT,
            tube_width=0.004,
            slider_width=0.018,
        )

        # 2. Checkbox pour afficher/masquer les arêtes
        def toggle_edges(state):
            nonlocal mesh_actor, show_edges_state, wireframe_state
            show_edges_state = bool(state)
            # Recréation de l'acteur pour garantir une compatibilité large des propriétés.
            mesh_actor = plotter.add_mesh(
                mesh,
                scalars="Colors",
                rgb=True,
                show_edges=show_edges_state,
                line_width=line_width_state,
                style="wireframe" if wireframe_state else "surface",
                name="main_mesh",
                reset_camera=False,
            )
            plotter.render()

        plotter.add_checkbox_button_widget(toggle_edges, value=True, position=(10, 94), size=20)
        plotter.add_text("Afficher aretes", position=(36, 98), font_size=UI_FONT_SIZE)

        # 3. Checkbox pour afficher/masquer les sommets
        def toggle_points(state):
            nonlocal show_points_state
            show_points_state = bool(state)
            if show_points_state:
                plotter.add_points(
                    mesh.points,
                    render_points_as_spheres=True,
                    point_size=point_size_state,
                    color="red",
                    name="points_overlay",
                    reset_camera=False,
                )
            else:
                plotter.remove_actor("points_overlay", reset_camera=False)
            plotter.render()

        plotter.add_checkbox_button_widget(toggle_points, value=False, position=(10, 64), size=20)
        plotter.add_text("Afficher sommets", position=(36, 68), font_size=UI_FONT_SIZE)

        # 4. Checkbox pour basculer le mode fil de fer
        def toggle_wireframe(state):
            nonlocal mesh_actor, wireframe_state
            wireframe_state = bool(state)
            mesh_actor = plotter.add_mesh(
                mesh,
                scalars="Colors",
                rgb=True,
                show_edges=show_edges_state,
                line_width=line_width_state,
                style="wireframe" if wireframe_state else "surface",
                name="main_mesh",
                reset_camera=False,
            )
            plotter.render()

        plotter.add_checkbox_button_widget(toggle_wireframe, value=False, position=(10, 34), size=20)
        plotter.add_text("Mode fil de fer", position=(36, 38), font_size=UI_FONT_SIZE)

        # 5. Slider pour la taille des points
        def update_point_size(value):
            nonlocal point_size_state
            point_size_state = float(value)
            if show_points_state:
                plotter.add_points(
                    mesh.points,
                    render_points_as_spheres=True,
                    point_size=point_size_state,
                    color="red",
                    name="points_overlay",
                    reset_camera=False,
                )
            plotter.render()

        plotter.add_slider_widget(
            callback=update_point_size,
            rng=[1, 30],
            value=10,
            title="Taille points",
            style='modern',
            pointa=(0.65, 0.15),
            pointb=(0.95, 0.15),
            title_height=SLIDER_TITLE_HEIGHT,
            tube_width=0.004,
            slider_width=0.018,
        )

        # 6. Checkbox pour activer/désactiver la lumière
        def toggle_light(state):
            for light in plotter.renderer.lights:
                if bool(state):
                    try:
                        light.switch_on()
                    except AttributeError:
                        light.SetSwitch(True)
                else:
                    try:
                        light.switch_off()
                    except AttributeError:
                        light.SetSwitch(False)
            plotter.render()

        plotter.add_checkbox_button_widget(toggle_light, value=True, position=(10, 4), size=20)
        plotter.add_text("Lumiere", position=(36, 8), font_size=UI_FONT_SIZE)

        # Réduit explicitement la taille des textes numériques sur les sliders.
        for widget in plotter.slider_widgets:
            try:
                rep = widget.GetRepresentation()
                rep.SetLabelHeight(SLIDER_LABEL_HEIGHT)
                rep.SetTitleHeight(SLIDER_TITLE_HEIGHT)
            except Exception:
                pass

    
    plotter.show()