from __future__ import annotations

import logging
import os
from typing import Any, Callable, Dict, Iterable, List, Optional, Protocol, Tuple, Union, cast

from natural_pdf.ocr.ocr_manager import (
    normalize_ocr_options,
    resolve_ocr_device,
    resolve_ocr_languages,
    resolve_ocr_min_confidence,
)
from natural_pdf.ocr.unified_dispatch import get_registry, run_ocr
from natural_pdf.services._text_state import bump_text_state
from natural_pdf.services.registry import register_delegate

logger = logging.getLogger(__name__)


class _OCRElementManager(Protocol):
    def remove_ocr_elements(self) -> int: ...

    def clear_text_layer(self) -> Tuple[int, int]: ...

    def create_text_elements_from_ocr(
        self,
        ocr_results: Any,
        scale_x: Optional[float] = None,
        scale_y: Optional[float] = None,
        engine_name: Optional[str] = None,
    ) -> List[Any]: ...


class SupportsOCRElementManager(Protocol):
    def _ocr_element_manager(self) -> _OCRElementManager: ...


class OCRService:
    """Shared OCR helpers extracted from OCRMixin."""

    def __init__(self, context):
        self._context = context

    @staticmethod
    def _scope(host) -> str:
        scope_getter = getattr(host, "_ocr_scope", None)
        if callable(scope_getter):
            try:
                scope = scope_getter()
            except TypeError:
                scope = scope_getter
            if isinstance(scope, str) and scope:
                return scope
        return "page"

    @staticmethod
    def _render_kwargs(host, *, apply_exclusions: bool) -> Dict[str, Any]:
        hook = getattr(host, "_ocr_render_kwargs", None)
        if callable(hook):
            try:
                kwargs = hook(apply_exclusions=apply_exclusions)
            except TypeError:
                kwargs = hook()
            if isinstance(kwargs, dict):
                return kwargs
        return {"apply_exclusions": apply_exclusions}

    @staticmethod
    def _resolve_offsets(host, render_kwargs: Optional[Dict[str, Any]]) -> Tuple[float, float]:
        if not render_kwargs:
            return 0.0, 0.0

        crop_bbox = render_kwargs.get("crop_bbox")
        bbox = None
        if (
            isinstance(crop_bbox, (list, tuple))
            and len(crop_bbox) == 4
            and all(isinstance(coord, (int, float)) for coord in crop_bbox)
        ):
            bbox = crop_bbox
        elif render_kwargs.get("crop"):
            bbox = getattr(host, "bbox", None)

        if bbox and len(bbox) >= 2:
            try:
                return float(bbox[0]), float(bbox[1])
            except (TypeError, ValueError):
                return 0.0, 0.0
        return 0.0, 0.0

    def _resolve_resolution(self, host, requested: Optional[int], scope: str) -> int:
        if requested is not None:
            return requested

        option_value = self._context.get_option(
            "ocr",
            "resolution",
            host=host,
            default=None,
            scope=scope,
        )
        if option_value is not None:
            coerced = self._coerce_int(option_value)
            if coerced is not None:
                return coerced

        return 150

    @register_delegate("ocr", "remove_ocr_elements")
    def remove_ocr_elements(self, host: SupportsOCRElementManager) -> int:
        mgr = host._ocr_element_manager()
        removed = int(mgr.remove_ocr_elements())
        if removed:
            bump_text_state(host)
        return removed

    @register_delegate("ocr", "clear_text_layer")
    def clear_text_layer(self, host: SupportsOCRElementManager):
        mgr = host._ocr_element_manager()
        removed = mgr.clear_text_layer()
        if removed and any(removed):
            bump_text_state(host)
        return removed

    @register_delegate("ocr", "create_text_elements_from_ocr")
    def create_text_elements_from_ocr(
        self,
        host: SupportsOCRElementManager,
        ocr_results: Any,
        scale_x: Optional[float] = None,
        scale_y: Optional[float] = None,
        offset_x: float = 0.0,
        offset_y: float = 0.0,
        engine_name: Optional[str] = None,
    ):
        mgr = host._ocr_element_manager()
        created = mgr.create_text_elements_from_ocr(
            ocr_results,
            scale_x=scale_x,
            scale_y=scale_y,
            offset_x=offset_x,
            offset_y=offset_y,
            engine_name=engine_name,
        )
        if created:
            bump_text_state(host, elements=created)
        return created

    def _resolve_engine_name(
        self,
        host,
        requested: Optional[str],
        options: Optional[Any],
        scope: str,
    ) -> str:
        """Resolve engine name using the unified registry."""
        registry = get_registry()
        if requested is not None:
            normalized = requested.strip().lower()
            if normalized in registry:
                return normalized

        # Fall back to config/global defaults for classic engines
        from natural_pdf.ocr.ocr_manager import resolve_ocr_engine_name

        return resolve_ocr_engine_name(
            context=host, requested=requested, options=options, scope=scope
        )

    def _process_ocr_payload(
        self, host, ocr_payload, engine_name, min_confidence, offset_x, offset_y
    ):
        """Scale OCR results and create text elements.

        Returns the created element list, or ``None`` if the payload is invalid.
        Used by both cache-hit and fresh-OCR paths to avoid duplication.
        """
        image_width, image_height = ocr_payload.image_size
        if not image_width or not image_height:
            logger.error("OCR payload missing image dimensions.")
            return None

        width = (
            getattr(host, "width", None) or getattr(getattr(host, "page", None), "width", None) or 0
        )
        height = (
            getattr(host, "height", None)
            or getattr(getattr(host, "page", None), "height", None)
            or 0
        )
        scale_x = width / image_width if width else 1.0
        scale_y = height / image_height if height else 1.0

        if ocr_payload.engine_type == "vlm":
            from natural_pdf.ocr.vlm_ocr import create_table_regions_from_ocr, scale_ocr_results

            scaled = scale_ocr_results(
                ocr_payload.results,
                image_width=image_width,
                image_height=image_height,
                page_width=width,
                page_height=height,
                offset_x=offset_x,
                offset_y=offset_y,
            )
            if min_confidence is not None:
                scaled = [r for r in scaled if r.get("confidence", 1.0) >= min_confidence]

            page_obj = getattr(host, "page", host)
            text_results, _table_regions = create_table_regions_from_ocr(page_obj, scaled)

            return self.create_text_elements_from_ocr(
                host,
                text_results,
                scale_x=1.0,
                scale_y=1.0,
                offset_x=0.0,
                offset_y=0.0,
                engine_name=engine_name,
            )
        else:
            return self.create_text_elements_from_ocr(
                host,
                ocr_payload.results,
                scale_x=scale_x,
                scale_y=scale_y,
                offset_x=offset_x,
                offset_y=offset_y,
                engine_name=engine_name,
            )

    def _payload_can_replace_text(
        self,
        host,
        ocr_payload,
        engine_name,
        min_confidence,
        offset_x,
        offset_y,
    ) -> bool:
        image_width, image_height = ocr_payload.image_size
        if not image_width or not image_height:
            return False

        width = (
            getattr(host, "width", None) or getattr(getattr(host, "page", None), "width", None) or 0
        )
        height = (
            getattr(host, "height", None)
            or getattr(getattr(host, "page", None), "height", None)
            or 0
        )
        scale_x = width / image_width if width else 1.0
        scale_y = height / image_height if height else 1.0

        staged_results = ocr_payload.results
        staged_scale_x = scale_x
        staged_scale_y = scale_y
        staged_offset_x = offset_x
        staged_offset_y = offset_y

        if ocr_payload.engine_type == "vlm":
            from natural_pdf.ocr.vlm_ocr import scale_ocr_results

            scaled = scale_ocr_results(
                ocr_payload.results,
                image_width=image_width,
                image_height=image_height,
                page_width=width,
                page_height=height,
                offset_x=offset_x,
                offset_y=offset_y,
            )
            if min_confidence is not None:
                scaled = [r for r in scaled if r.get("confidence", 1.0) >= min_confidence]

            staged_results = [
                result
                for result in scaled
                if str(result.get("source_category", "")).lower() != "table"
            ]
            staged_scale_x = 1.0
            staged_scale_y = 1.0
            staged_offset_x = 0.0
            staged_offset_y = 0.0

        if not staged_results:
            return False

        mgr = host._ocr_element_manager()
        converter = getattr(mgr, "_ocr_converter", None)
        if converter is None:
            return True

        try:
            staged_words, staged_chars = converter.convert(
                staged_results,
                scale_x=staged_scale_x,
                scale_y=staged_scale_y,
                offset_x=staged_offset_x,
                offset_y=staged_offset_y,
                engine_name=engine_name,
            )
        except Exception:
            logger.debug("Failed to validate OCR payload before replacement.", exc_info=True)
            return False

        return bool(staged_words or staged_chars)

    @register_delegate("ocr", "apply_ocr")
    def apply_ocr(
        self,
        host,
        *,
        engine: Optional[str] = None,
        options: Optional[Any] = None,
        languages: Optional[List[str]] = None,
        min_confidence: Optional[float] = None,
        device: Optional[str] = None,
        resolution: Optional[int] = None,
        detect_only: bool = False,
        apply_exclusions: bool = True,
        replace: Union[bool, str] = True,
        use_cache: bool = True,
        # VLM params:
        model: Optional[str] = None,
        client: Optional[Any] = None,
        prompt: Optional[str] = None,
        instructions: Optional[str] = None,
        max_new_tokens: Optional[int] = None,
        layout: Optional[bool | str] = None,
        **kwargs,
    ):
        normalized_options = normalize_ocr_options(options)
        scope = self._scope(host)

        # If model= or client= provided without engine, default to "vlm"
        if engine is None and (model is not None or client is not None):
            engine = "vlm"

        engine_name = self._resolve_engine_name(host, engine, normalized_options, scope)
        resolved_languages = resolve_ocr_languages(host, languages, scope=scope)
        resolved_min_conf = resolve_ocr_min_confidence(host, min_confidence, scope=scope)
        resolved_device = resolve_ocr_device(host, device, scope=scope)

        final_resolution = self._resolve_resolution(host, resolution, scope)
        render_kwargs = self._render_kwargs(host, apply_exclusions=apply_exclusions)
        offset_x, offset_y = self._resolve_offsets(host, render_kwargs)

        # --- OCR result cache ---
        from natural_pdf.ocr.ocr_cache import compute_cache_key, get_default_cache

        cache = get_default_cache() if use_cache else None
        cache_key = None

        page_obj = getattr(host, "page", host)
        pdf_obj = getattr(page_obj, "pdf", getattr(page_obj, "_parent", None))
        pdf_path = getattr(pdf_obj, "_resolved_path", None)

        if cache is not None and pdf_path and pdf_path != "<stream>":
            try:
                file_stat = os.stat(pdf_path)
                page_index = getattr(page_obj, "index", 0)
                options_key = (
                    normalized_options._init_key()
                    if hasattr(normalized_options, "_init_key")
                    else ""
                )
                cache_key = compute_cache_key(
                    pdf_path=pdf_path,
                    file_mtime_ns=file_stat.st_mtime_ns,
                    file_size=file_stat.st_size,
                    page_index=page_index,
                    engine_name=engine_name,
                    languages=tuple(sorted(resolved_languages or ["en"])),
                    resolution=final_resolution,
                    detect_only=detect_only,
                    device=resolved_device or "cpu",
                    options_init_key=options_key,
                    apply_exclusions=apply_exclusions,
                    model=model,
                    prompt=prompt,
                    instructions=instructions,
                    max_new_tokens=max_new_tokens,
                )

                cached = cache.get(cache_key)
                if cached is not None:
                    logger.info("OCR cache hit for page %d (%s)", page_index, engine_name)
                    if replace is True or replace == "all":
                        if not self._payload_can_replace_text(
                            host,
                            cached,
                            engine_name,
                            resolved_min_conf,
                            offset_x,
                            offset_y,
                        ):
                            logger.warning(
                                "Skipping replacement OCR because the cached payload could not be validated."
                            )
                            return host
                        words, chars = self.clear_text_layer(host)
                        if words or chars:
                            logger.info(
                                "Cleared text layer (%d words, %d chars) before OCR.", words, chars
                            )
                    elif replace == "ocr":
                        removed = self.remove_ocr_elements(host)
                        if removed:
                            logger.info("Removed %d OCR elements before new OCR run.", removed)
                    created = self._process_ocr_payload(
                        host, cached, engine_name, resolved_min_conf, offset_x, offset_y
                    )
                    if created is not None:
                        logger.info(
                            "Added %d OCR elements from cache using '%s'.",
                            len(created),
                            engine_name,
                        )
                        return host
            except OSError:
                pass  # Can't stat file — skip cache

        ocr_payload = run_ocr(
            target=host,
            engine_name=engine_name,
            resolution=final_resolution,
            languages=resolved_languages,
            min_confidence=resolved_min_conf,
            device=resolved_device,
            detect_only=detect_only,
            options=normalized_options,
            render_kwargs=render_kwargs,
            context=host,
            model=model,
            client=client,
            prompt=prompt,
            instructions=instructions,
            max_new_tokens=max_new_tokens,
            layout=layout,
        )

        # Cache the results
        if cache_key is not None:
            page_index = getattr(page_obj, "index", 0)
            cache.put(cache_key, ocr_payload, engine_name, page_index)

        if replace is True or replace == "all":
            if not self._payload_can_replace_text(
                host,
                ocr_payload,
                engine_name,
                resolved_min_conf,
                offset_x,
                offset_y,
            ):
                logger.warning(
                    "Skipping replacement OCR because the OCR payload could not be validated."
                )
                return host
            words, chars = self.clear_text_layer(host)
            if words or chars:
                logger.info("Cleared text layer (%d words, %d chars) before OCR.", words, chars)
        elif replace == "ocr":
            removed = self.remove_ocr_elements(host)
            if removed:
                logger.info("Removed %d OCR elements before new OCR run.", removed)

        created_elements = self._process_ocr_payload(
            host, ocr_payload, engine_name, resolved_min_conf, offset_x, offset_y
        )
        if created_elements is None:
            return host

        logger.info("Added %d OCR elements using '%s'.", len(created_elements), engine_name)
        return host

    @register_delegate("ocr", "apply_custom_ocr")
    def apply_custom_ocr(
        self,
        host,
        *,
        ocr_function: Callable[[Any], Optional[str]],
        source_label: str = "custom-ocr",
        replace: bool = True,
        confidence: Optional[float] = None,
        add_to_page: bool = True,
    ):
        if not callable(ocr_function):
            raise TypeError("ocr_function must be callable.")

        if replace:
            self._remove_custom_ocr_elements(host, source_label=source_label)

        logger.debug("Running custom OCR function for %s", host)
        ocr_text = ocr_function(host)
        if ocr_text is not None and not isinstance(ocr_text, str):
            raise TypeError(
                f"Custom OCR function returned {type(ocr_text).__name__}; expected str or None."
            )

        if ocr_text is None:
            logger.debug("Custom OCR function returned None; no elements created.")
            return host

        to_text_element = getattr(host, "to_text_element", None)
        if not callable(to_text_element):
            raise AttributeError(
                f"{host.__class__.__name__} must implement to_text_element() for custom OCR."
            )

        to_text_element(
            text_content=ocr_text,
            source_label=source_label,
            confidence=confidence,
            add_to_page=add_to_page,
        )
        logger.info(
            "Created custom OCR text element (%d chars) via %s.",
            len(ocr_text),
            source_label,
        )
        return host

    @staticmethod
    def _coerce_int(value: Any) -> Optional[int]:
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, (int, float)):
            try:
                return int(value)
            except (TypeError, ValueError):
                return None
        if isinstance(value, str):
            stripped = value.strip()
            if not stripped:
                return None
            try:
                return int(float(stripped))
            except (ValueError, TypeError):
                return None
        return None

    def _remove_custom_ocr_elements(self, host, *, source_label: str) -> None:
        page = getattr(host, "page", None)
        if page is None:
            return
        get_elements = getattr(page, "get_elements_by_type", None)
        remove_element = getattr(page, "remove_element", None)
        if not callable(get_elements) or not callable(remove_element):
            return

        intersects = getattr(host, "intersects", None)
        bbox = getattr(host, "bbox", None)

        def _overlaps(candidate: Any) -> bool:
            if callable(intersects):
                try:
                    return bool(intersects(candidate))
                except Exception:
                    return False
            if bbox is None:
                return True
            candidate_bbox = self._element_bbox(candidate)
            if candidate_bbox is None:
                return False
            x0, top, x1, bottom = candidate_bbox
            hx0, htop, hx1, hbottom = bbox
            return not (x1 < hx0 or x0 > hx1 or bottom < htop or top > hbottom)

        def _safe_remove(element: Any):
            etype = getattr(element, "object_type", None)
            try:
                remove_element(element, element_type=etype)
            except Exception:
                return

        removed = 0
        word_iter = get_elements("words") or []
        for word in list(cast(Iterable[Any], word_iter)):
            source = getattr(word, "source", "")
            if source not in {"ocr", source_label}:
                continue
            if _overlaps(word):
                _safe_remove(word)
                removed += 1

        char_iter = get_elements("chars") or []
        for char in list(cast(Iterable[Any], char_iter)):
            char_source = (
                char.get("source") if isinstance(char, dict) else getattr(char, "source", None)
            )
            if char_source not in {"ocr", source_label}:
                continue
            if _overlaps(char):
                _safe_remove(char)
                removed += 1

        if removed:
            logger.info("Removed %d existing OCR element(s) before custom OCR.", removed)

    @staticmethod
    def _element_bbox(element: Any) -> Optional[Tuple[float, float, float, float]]:
        bbox = getattr(element, "bbox", None)
        if (
            isinstance(bbox, tuple)
            and len(bbox) == 4
            and all(isinstance(coord, (int, float)) for coord in bbox)
        ):
            return float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3])
        if isinstance(element, dict):
            try:
                return (
                    float(element.get("x0", 0)),
                    float(element.get("top", 0)),
                    float(element.get("x1", 0)),
                    float(element.get("bottom", 0)),
                )
            except (TypeError, ValueError):
                return None
        if hasattr(element, "x0") and hasattr(element, "x1") and hasattr(element, "top"):
            try:
                return (
                    float(getattr(element, "x0")),
                    float(getattr(element, "top")),
                    float(getattr(element, "x1")),
                    float(getattr(element, "bottom", getattr(element, "top"))),
                )
            except (TypeError, ValueError):
                return None
        return None

    @register_delegate("ocr", "extract_ocr_elements")
    def extract_ocr_elements(
        self,
        host,
        *,
        engine: Optional[str] = None,
        options: Optional[Any] = None,
        languages: Optional[List[str]] = None,
        min_confidence: Optional[float] = None,
        device: Optional[str] = None,
        resolution: Optional[int] = None,
    ):
        normalized_options = normalize_ocr_options(options)
        scope = self._scope(host)
        engine_name = self._resolve_engine_name(
            host,
            engine,
            normalized_options,
            scope,
        )
        resolved_languages = resolve_ocr_languages(host, languages, scope=scope)
        resolved_min_conf = resolve_ocr_min_confidence(host, min_confidence, scope=scope)
        resolved_device = resolve_ocr_device(host, device, scope=scope)

        final_resolution = self._resolve_resolution(host, resolution, scope)
        render_kwargs = self._render_kwargs(host, apply_exclusions=True)
        offset_x, offset_y = self._resolve_offsets(host, render_kwargs)

        ocr_payload = run_ocr(
            target=host,
            engine_name=engine_name,
            resolution=final_resolution,
            languages=resolved_languages,
            min_confidence=resolved_min_conf,
            device=resolved_device,
            detect_only=False,
            options=normalized_options,
            render_kwargs=render_kwargs,
            context=host,
        )

        created = self._process_ocr_payload(
            host,
            ocr_payload,
            engine_name,
            resolved_min_conf,
            offset_x,
            offset_y,
        )
        return created or []
