# natural_pdf/ocr/engine_doctr.py
import importlib.util
import logging
from importlib import import_module
from types import ModuleType
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple, cast

import numpy as np
from PIL import Image

from natural_pdf.utils.option_validation import validate_option_type

from .engine import OCREngine, TextRegion
from .ocr_options import BaseOCROptions, DoctrOCROptions

logger = logging.getLogger(__name__)


class DoctrOCREngine(OCREngine):
    """docTR engine implementation."""

    def __init__(self):
        super().__init__()
        self._model: Optional[Any] = None
        self._detection_model: Optional[Any] = None
        self._orientation_model: Optional[Any] = None
        self._doctr_models: Optional[ModuleType] = None

    def is_available(self) -> bool:
        """Check if doctr is installed."""
        return importlib.util.find_spec("doctr") is not None

    def _load_doctr_models(self) -> ModuleType:
        """Import doctr.models lazily and cache the module reference."""
        if self._doctr_models is None:
            try:
                self._doctr_models = import_module("doctr.models")
                self.logger.info("doctr.models imported successfully.")
            except ImportError as exc:
                self.logger.error(f"Failed to import doctr: {exc}")
                raise
        return self._doctr_models

    def _initialize_model(
        self, languages: List[str], device: str, options: Optional[BaseOCROptions]
    ):
        """Initialize the doctr model."""
        if not self.is_available():
            raise ImportError(
                "Doctr engine requires the 'python-doctr' package. "
                "Install with: pip install python-doctr[torch] or python-doctr[tf]"
            )

        try:
            doctr_models = self._load_doctr_models()
        except ImportError:
            raise

        # Cast to DoctrOCROptions or use default (with warning if wrong type)
        doctr_opts, _ = validate_option_type(options, DoctrOCROptions, "DoctrOCREngine")

        # Determine if we should move models to a non-CPU device
        use_gpu = device and device.lower() not in ("cpu", "")
        gpu_device = device.lower() if use_gpu else None

        # Prepare OCR predictor arguments
        predictor_args = {
            "det_arch": doctr_opts.det_arch,
            "reco_arch": doctr_opts.reco_arch,
            "pretrained": doctr_opts.pretrained,
            "assume_straight_pages": doctr_opts.assume_straight_pages,
            "export_as_straight_boxes": doctr_opts.export_as_straight_boxes,
        }
        # Filter out None values
        predictor_args = {k: v for k, v in predictor_args.items() if v is not None}

        # Filter only allowed doctr ocr_predictor args
        allowed_ocr_args = {
            "det_arch",
            "reco_arch",
            "pretrained",
            "assume_straight_pages",
            "export_as_straight_boxes",
        }
        filtered_ocr_args = {k: v for k, v in predictor_args.items() if k in allowed_ocr_args}
        dropped_ocr = set(predictor_args) - allowed_ocr_args
        if dropped_ocr:
            self.logger.warning(f"Dropped unsupported doctr ocr_predictor args: {dropped_ocr}")

        self.logger.debug(f"doctr ocr_predictor constructor args: {filtered_ocr_args}")
        try:
            self._model = doctr_models.ocr_predictor(**filtered_ocr_args)

            # Move model to requested device (cuda, mps, etc.)
            if use_gpu and self._model is not None:
                if hasattr(self._model, "to"):
                    self._model = self._model.to(gpu_device)
                elif hasattr(self._model, "cuda") and gpu_device.startswith("cuda"):
                    self._model = self._model.cuda()
                else:
                    self.logger.warning(
                        f"Device '{gpu_device}' requested but doctr OCR model does not support .to(); continuing on CPU."
                    )

            self.logger.info("doctr ocr_predictor created successfully")

            # Now initialize the detection-only model
            try:
                detection_args = {
                    "arch": doctr_opts.det_arch,
                    "pretrained": doctr_opts.pretrained,
                    "assume_straight_pages": doctr_opts.assume_straight_pages,
                    "symmetric_pad": doctr_opts.symmetric_pad,
                    "preserve_aspect_ratio": doctr_opts.preserve_aspect_ratio,
                    "batch_size": doctr_opts.batch_size,
                }
                # Filter out None values
                detection_args = {k: v for k, v in detection_args.items() if v is not None}
                allowed_det_args = {
                    "arch",
                    "pretrained",
                    "assume_straight_pages",
                    "symmetric_pad",
                    "preserve_aspect_ratio",
                    "batch_size",
                }
                filtered_det_args = {
                    k: v for k, v in detection_args.items() if k in allowed_det_args
                }
                dropped_det = set(detection_args) - allowed_det_args
                if dropped_det:
                    self.logger.warning(
                        f"Dropped unsupported doctr detection_predictor args: {dropped_det}"
                    )
                self.logger.debug(
                    f"doctr detection_predictor constructor args: {filtered_det_args}"
                )
                self._detection_model = doctr_models.detection_predictor(**filtered_det_args)

                # Move detection model to requested device
                if use_gpu and self._detection_model is not None:
                    if hasattr(self._detection_model, "to"):
                        self._detection_model = self._detection_model.to(gpu_device)
                    elif hasattr(self._detection_model, "cuda") and gpu_device.startswith("cuda"):
                        self._detection_model = self._detection_model.cuda()
                    else:
                        self.logger.warning(
                            f"Device '{gpu_device}' requested but doctr detection model does not support .to(); continuing on CPU."
                        )

                # Configure postprocessing parameters if provided
                if self._detection_model is not None and hasattr(self._detection_model, "model"):
                    postprocessor = getattr(self._detection_model.model, "postprocessor", None)
                    if postprocessor is not None:
                        if doctr_opts.bin_thresh is not None:
                            postprocessor.bin_thresh = doctr_opts.bin_thresh
                        if doctr_opts.box_thresh is not None:
                            postprocessor.box_thresh = doctr_opts.box_thresh
                else:
                    self.logger.warning(
                        "Detection model missing postprocessor; skipping threshold configuration."
                    )

                self.logger.info("doctr detection_predictor created successfully")
            except Exception as e:
                self.logger.error(f"Failed to create detection_predictor: {e}")
                self._detection_model = None

            # Initialize orientation predictor if enabled
            if doctr_opts.use_orientation_predictor:
                try:
                    self._orientation_model = doctr_models.page_orientation_predictor(
                        pretrained=True, batch_size=doctr_opts.batch_size
                    )
                    if use_gpu and self._orientation_model is not None:
                        if hasattr(self._orientation_model, "to"):
                            self._orientation_model = self._orientation_model.to(gpu_device)
                        elif hasattr(self._orientation_model, "cuda") and gpu_device.startswith(
                            "cuda"
                        ):
                            self._orientation_model = self._orientation_model.cuda()
                        else:
                            self.logger.warning(
                                f"Device '{gpu_device}' requested but doctr orientation model does not support .to(); continuing on CPU."
                            )
                    self.logger.info("doctr page_orientation_predictor created successfully")
                except Exception as e:
                    self.logger.error(f"Failed to create page_orientation_predictor: {e}")
                    self._orientation_model = None

        except Exception as e:
            self.logger.error(f"Failed to create doctr models: {e}")
            raise

        # Doctr doesn't explicitly use language list in ocr_predictor initialization
        if languages and languages != [self.DEFAULT_LANGUAGES[0]]:
            logger.warning(
                f"Doctr engine currently doesn't support language selection during initialization. Using its default language capabilities for model: {doctr_opts.reco_arch}"
            )

    def _preprocess_image(self, image: Image.Image) -> np.ndarray:
        """Convert PIL Image to RGB numpy array for doctr."""
        # Ensure the image is in RGB mode
        if image.mode != "RGB":
            image = image.convert("RGB")
        # Convert to numpy array
        return np.array(image)

    def _process_single_image(
        self, image: Any, detect_only: bool, options: Optional[BaseOCROptions]
    ) -> Any:
        """Process a single image with doctr."""
        if self._model is None:
            raise RuntimeError("Doctr model not initialized")

        if not isinstance(image, np.ndarray):
            raise TypeError("DoctrOCREngine expects numpy arrays after preprocessing")

        # Capture image dimensions for denormalization and store for _standardize_results
        height, width = image.shape[:2]
        self._last_image_dimensions = (height, width)

        # Cast options to DoctrOCROptions or use default (with warning if wrong type)
        doctr_opts, _ = validate_option_type(options, DoctrOCROptions, "DoctrOCREngine")

        # Check if we need to detect orientation first
        if self._orientation_model is not None and doctr_opts.use_orientation_predictor:
            try:
                # Process with orientation predictor
                # For orientation predictor, we need to pass a batch of images
                orientations = self._orientation_model([image])
                orientation = orientations[1][0]  # Get the orientation angle
                logger.info(f"Detected page orientation: {orientation} degrees")
                # Note: doctr handles rotation internally for detection/recognition
            except Exception as e:
                logger.error(f"Error detecting orientation: {e}")

        # Process differently based on detect_only flag
        if detect_only and self._detection_model is not None:
            try:
                postprocessor = getattr(self._detection_model.model, "postprocessor", None)
                original_bin_thresh = None
                original_box_thresh = None
                if postprocessor is not None:
                    if doctr_opts.bin_thresh is not None:
                        original_bin_thresh = getattr(postprocessor, "bin_thresh", None)
                        postprocessor.bin_thresh = doctr_opts.bin_thresh
                        logger.debug(f"Temporarily set bin_thresh to {doctr_opts.bin_thresh}")

                    if doctr_opts.box_thresh is not None:
                        original_box_thresh = getattr(postprocessor, "box_thresh", None)
                        postprocessor.box_thresh = doctr_opts.box_thresh
                        logger.debug(f"Temporarily set box_thresh to {doctr_opts.box_thresh}")

                # Use the dedicated detection model with a list of numpy arrays
                result = self._detection_model([image])

                # Restore original thresholds
                if postprocessor is not None:
                    if doctr_opts.bin_thresh is not None and original_bin_thresh is not None:
                        postprocessor.bin_thresh = original_bin_thresh

                    if doctr_opts.box_thresh is not None and original_box_thresh is not None:
                        postprocessor.box_thresh = original_box_thresh

                return result
            except Exception as e:
                logger.error(f"Error in detection_predictor: {e}")
                # Fall back to OCR predictor if detection fails
                logger.warning("Falling back to OCR predictor for detection")

        # Process with full OCR model, passing a list of numpy arrays directly
        try:
            # For full OCR, we should also apply the thresholds
            original_bin_thresh = None
            original_box_thresh = None
            if (
                detect_only
                and doctr_opts.bin_thresh is not None
                and hasattr(self._model.det_predictor.model.postprocessor, "bin_thresh")
            ):
                original_bin_thresh = self._model.det_predictor.model.postprocessor.bin_thresh
                self._model.det_predictor.model.postprocessor.bin_thresh = doctr_opts.bin_thresh

            if (
                detect_only
                and doctr_opts.box_thresh is not None
                and hasattr(self._model.det_predictor.model.postprocessor, "box_thresh")
            ):
                original_box_thresh = self._model.det_predictor.model.postprocessor.box_thresh
                self._model.det_predictor.model.postprocessor.box_thresh = doctr_opts.box_thresh

            result = self._model([image])

            # Restore original thresholds
            if (
                detect_only
                and doctr_opts.bin_thresh is not None
                and hasattr(self._model.det_predictor.model.postprocessor, "bin_thresh")
                and original_bin_thresh is not None
            ):
                self._model.det_predictor.model.postprocessor.bin_thresh = original_bin_thresh

            if (
                detect_only
                and doctr_opts.box_thresh is not None
                and hasattr(self._model.det_predictor.model.postprocessor, "box_thresh")
                and original_box_thresh is not None
            ):
                self._model.det_predictor.model.postprocessor.box_thresh = original_box_thresh

            return result
        except Exception as e:
            logger.error(f"Error in OCR prediction: {e}")
            raise

    def _standardize_results(
        self, raw_results: Any, min_confidence: float, detect_only: bool, **kwargs
    ) -> List[TextRegion]:
        """Convert doctr results to standardized TextRegion objects."""
        standardized_regions = []

        # Get results and dimensions from instance attribute
        results = raw_results
        dims = getattr(self, "_last_image_dimensions", None)
        if dims is not None:
            image_height, image_width = dims
        else:
            # Fallback if dimensions aren't available
            image_width = 1
            image_height = 1
            logger.warning("Image dimensions not available, using normalized coordinates")

        # Handle detection-only results differently
        if detect_only and self._detection_model is not None and not hasattr(results, "pages"):
            # Import doctr utils for detach_scores if needed
            try:
                geometry_module = import_module("doctr.utils.geometry")
                detach_scores = cast(
                    Callable[[Sequence[Any]], Tuple[Sequence[Any], Sequence[Any]]],
                    getattr(geometry_module, "detach_scores"),
                )
            except (ImportError, AttributeError):
                logger.error("Failed to import doctr.utils.geometry.detach_scores")
                return standardized_regions
            if not callable(detach_scores):
                logger.error("doctr.utils.geometry.detach_scores is not callable.")
                return standardized_regions

            # Extract coordinates and scores from detection results
            for result in results:
                # Detection results structure is different from ocr_predictor
                if "words" in result:
                    try:
                        words = result.get("words")
                        if not words:
                            continue
                        # Detach the coordinates and scores
                        detached_coords, prob_scores = detach_scores([words])

                        for i, coords in enumerate(detached_coords[0]):
                            score = (
                                prob_scores[0][i]
                                if prob_scores and len(prob_scores[0]) > i
                                else 0.0
                            )

                            if score >= min_confidence:
                                try:
                                    # Handle both straight and rotated boxes
                                    if coords.shape == (
                                        4,
                                    ):  # Straight box as [xmin, ymin, xmax, ymax]
                                        xmin, ymin, xmax, ymax = coords.tolist()
                                        # Denormalize coordinates
                                        bbox = (
                                            float(xmin * image_width),
                                            float(ymin * image_height),
                                            float(xmax * image_width),
                                            float(ymax * image_height),
                                        )
                                    else:  # Polygon points
                                        # Get bounding box from polygon
                                        coords_list = coords.tolist()
                                        x_coords = [p[0] * image_width for p in coords_list]
                                        y_coords = [p[1] * image_height for p in coords_list]
                                        bbox = (
                                            float(min(x_coords)),
                                            float(min(y_coords)),
                                            float(max(x_coords)),
                                            float(max(y_coords)),
                                        )

                                    # Detection mode has no text; capture score as confidence
                                    standardized_regions.append(TextRegion(bbox, "", float(score)))
                                except Exception as e:
                                    logger.error(f"Error processing detection result: {e}")
                    except Exception as e:
                        logger.error(f"Error detaching scores: {e}")

            return standardized_regions

        pages_obj = getattr(results, "pages", None)
        if not pages_obj:
            logger.warning("Doctr result object does not contain pages.")
            return standardized_regions

        # Process results page by page (we typically process one image at a time)
        # Merge words into lines so that extract_text() gets proper spacing.
        # doctr produces word-level boxes; other engines produce line-level.
        # Without merging, adjacent words like "NAPLES," and "FLORIDA" get
        # concatenated without spaces because the bbox gap is below x_tolerance.
        for page in cast(Iterable[Any], pages_obj):
            for block in page.blocks:
                for line in block.lines:
                    line_words = []
                    for word in line.words:
                        if word.confidence >= min_confidence:
                            try:
                                x_min, y_min = word.geometry[0]
                                x_max, y_max = word.geometry[1]
                                text_value = "" if detect_only else str(getattr(word, "value", ""))
                                confidence_raw = getattr(word, "confidence", 0.0)
                                line_words.append(
                                    {
                                        "x_min": x_min,
                                        "y_min": y_min,
                                        "x_max": x_max,
                                        "y_max": y_max,
                                        "text": text_value,
                                        "confidence": float(confidence_raw or 0.0),
                                    }
                                )
                            except (ValueError, TypeError, IndexError) as e:
                                logger.error(
                                    f"Could not standardize bounding box/word from doctr result: {word}"
                                )
                                logger.error(f"Error: {e}")

                    if not line_words:
                        continue

                    # Merge words into a single line-level TextRegion
                    line_text = " ".join(w["text"] for w in line_words)
                    line_bbox = (
                        float(min(w["x_min"] for w in line_words) * image_width),
                        float(min(w["y_min"] for w in line_words) * image_height),
                        float(max(w["x_max"] for w in line_words) * image_width),
                        float(max(w["y_max"] for w in line_words) * image_height),
                    )
                    avg_confidence = sum(w["confidence"] for w in line_words) / len(line_words)
                    standardized_regions.append(TextRegion(line_bbox, line_text, avg_confidence))

        return standardized_regions

    def get_default_options(self) -> DoctrOCROptions:
        """Return the default options specific to this engine."""
        return DoctrOCROptions()
