# fastsprout-core

[![PyPI version](https://img.shields.io/pypi/v/fastsprout-core.svg)](https://pypi.org/project/fastsprout-core/)
[![Python versions](https://img.shields.io/pypi/pyversions/fastsprout-core.svg)](https://pypi.org/project/fastsprout-core/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Downloads](https://static.pepy.tech/badge/fastsprout-core/month)](https://pepy.tech/project/fastsprout-core)
[![Typed](https://img.shields.io/pypi/types/fastsprout-core.svg)](https://pypi.org/project/fastsprout-core/)
[![CI](https://forgejo.3dcra.eu/fastsprout/fastsprout-core/actions/workflows/build-and-publish.yaml/badge.svg)](https://forgejo.3dcra.eu/fastsprout/fastsprout-core/actions)

Core contracts for the [FastSprout](https://fastsprout.dev) framework.

Foundation package — base protocols, types, exceptions and the typed-field layer that every other `fastsprout-*` package builds on. No dependencies on other framework packages.

## Install

```bash
pip install fastsprout-core
```

## Quick look

```python
from fastsprout_core.schema import BaseSchema
from fastsprout_core.fields import Field


class Hero(BaseSchema):
    id: Field[int]
    name: Field[str]


hero = Hero(id=1, name="SuperMan")
hero.name                    # "SuperMan"   (str)
Hero.name                    # <Hero.name>  (FieldRef[Hero, str, None])
Hero.name.set("Spider")      # FieldAssignment(name='name', value='Spider')
```

See [`examples/`](examples/) for one runnable file per feature.

## What's inside

- **Action protocols** — `BaseAction`, `BaseSequenceAction`, `BaseIterableAction`, `BaseIteratorAction` (+ trigger variants), `BaseActionGroup`. One protocol per return shape: single value, `Sequence[O]`, `Iterable[O]`, `AsyncIterator[O]`.
- **Schema** — `BaseSchema` with snake↔camel aliasing, declares fields as `Field[T]`.
- **Typed fields** — `Field[T]`, `FieldRef[E, T, OrmCtor]`, `FieldAssignment[T]`, `HasOrm[OrmCtor]`.
- **Decorators** — `@typed_fields`, `@typed_dataclass`, `@typed_pydantic_dataclass`, `TypedModelMeta`.
- **Identifiers, errors, DI** — `IDType` (UUID v7), `FastSproutError`, `Depends`.
- **mypy plugin** — refines `FieldRef.orm` to `OrmCtor[T]`. Enable with `plugins = ["fastsprout_core.mypy_plugin"]` in `[tool.mypy]`.

## Python

3.12, 3.13, 3.14. CI runs the full pipeline on each, including PEP 749 lazy-annotation paths.

See [CHANGELOG.md](CHANGELOG.md) for what's in each version.

## Links

- [fastsprout.dev](https://fastsprout.dev)
- [forgejo.3dcra.eu/fastsprout](https://forgejo.3dcra.eu/fastsprout)
- [pypi.org/project/fastsprout-core](https://pypi.org/project/fastsprout-core/)

## License

Apache License 2.0 — see [LICENSE](LICENSE)
