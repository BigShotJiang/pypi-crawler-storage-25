from pydantic.types import UUID7

__all__ = ["IDType", "IdentificatorType", "PublicIDType"]

type IdentificatorType = UUID7
type IDType = IdentificatorType
type PublicIDType = IdentificatorType
