"""BaseSequenceAction — eager collection (list/tuple). Class and function styles."""

import asyncio
from collections.abc import Sequence

from fastsprout_core.action import BaseSequenceAction
from fastsprout_core.fields import Field
from fastsprout_core.schema import BaseSchema


class GreetBatchIn(BaseSchema):
    name: Field[str]
    times: Field[int]


class GreetOut(BaseSchema):
    message: Field[str]


class GreetBatch(BaseSequenceAction[GreetBatchIn, GreetOut]):
    async def __call__(self, payload: GreetBatchIn, /) -> Sequence[GreetOut]:
        return [
            GreetOut(message=f"hello, {payload.name} #{i}")
            for i in range(payload.times)
        ]


async def greet_batch(payload: GreetBatchIn, /) -> Sequence[GreetOut]:
    return [
        GreetOut(message=f"hello, {payload.name} #{i}")
        for i in range(payload.times)
    ]


async def main() -> None:
    payload = GreetBatchIn(name="world", times=3)

    assert isinstance(GreetBatch(), BaseSequenceAction)
    assert isinstance(greet_batch, BaseSequenceAction)

    print([g.message for g in await GreetBatch()(payload)])
    print([g.message for g in await greet_batch(payload)])


if __name__ == "__main__":
    asyncio.run(main())
