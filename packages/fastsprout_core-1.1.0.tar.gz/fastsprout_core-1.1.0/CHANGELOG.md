# Changelog

## 1.1.0

### Added
- Action protocols by return shape:
  - `BaseSequenceAction[I, O]` — returns `Sequence[O]` (eager collection).
  - `BaseIterableAction[I, O]` — returns `Iterable[O]` (lazy sync generator).
  - `BaseIteratorAction[I, O]` — returns `AsyncIterator[O]` (async streaming).
  - Trigger variants: `BaseSequenceTriggerAction[O]`, `BaseIterableTriggerAction[O]`, `BaseIteratorTriggerAction[O]`.
- Typed-field layer:
  - `Field[T]` descriptor — `hero.name` returns `T`, `Hero.name` returns a `FieldRef`.
  - `FieldRef[E, T, OrmCtor]` — class-bound reference carrying entity, name and an ORM extension on `.orm`.
  - `FieldAssignment[T]` — return value of `Field("x").set(value)` for partial updates.
  - `HasOrm[OrmCtor]` — marker generic base for entities exposing an ORM wrapper class.
- Class decorators / metaclasses:
  - `@typed_fields` — install `Field[T]` descriptors on a plain class.
  - `@typed_dataclass` — stdlib `@dataclass` + `Field[T]` descriptors.
  - `@typed_pydantic_dataclass` (alias `@typed_pyd_dataclass`) — Pydantic `@dataclass` + descriptors with runtime validation.
  - `TypedModelMeta` — Pydantic metaclass behind `BaseSchema`.
- `Depends(...)` — re-export of FastAPI's `Depends` with a graceful fallback when FastAPI isn't installed.
- mypy plugin (`fastsprout_core.mypy_plugin`) — refines `FieldRef.orm` from `OrmCtor` to `OrmCtor[T]` at access sites.
- Python 3.14 PEP 749 (lazy annotations) support — annotations read via `__annotate_func__` / `__annotate__` when `__annotations__` is missing.
- CI matrix: full pipeline on Python 3.12, 3.13, 3.14 (blocking).
- Examples under `examples/` covering schema, fields, decorators, ORM wiring and the four action return shapes (single / sequence / iterable / iterator).

### Changed
- `BaseSchema` uses `TypedModelMeta` so subclasses can declare `Field[T]` directly.
- `[tool.mypy]` and `[tool.basedpyright]` no longer pin `python_version` — type checkers follow the active interpreter.

## 1.0.0

### Added
- `BaseAction[I, O]`, `BaseTriggerAction[O]`, `BaseActionGroup` — action protocols.
- `BaseSchema` — Pydantic base model with snake_case ↔ camelCase aliasing.
- `IDType`, `IdentificatorType`, `PublicIDType` — UUID v7 identifier type aliases.
- `BaseFastSproutError` / `FastSproutError` — base exception classes.
