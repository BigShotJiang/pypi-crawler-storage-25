#!/usr/bin/env python3
__author__  = "Teddy Chantrait"
__email__   = "teddy.chantrait@gmail.com"
__status__  = "Development"
__date__    = "2026-04-02 13:29:49"
__version__ = "0.0.13"
