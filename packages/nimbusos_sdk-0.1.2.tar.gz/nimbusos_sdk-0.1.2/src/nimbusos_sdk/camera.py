from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CameraFrame:
    seq: int
    t_ns: int
    width: int
    height: int
    jpeg: bytes


def decode_camera_frame(message: Any) -> CameraFrame:
    decoded = message.decoded
    if decoded.JpegIsNone():
        raise ValueError("camera frame missing jpeg")

    return CameraFrame(
        seq=_required_int(message.seq, "seq"),
        t_ns=_required_int(message.t_ns, "t_ns"),
        width=decoded.Width(),
        height=decoded.Height(),
        jpeg=bytes(decoded.Jpeg(index) for index in range(decoded.JpegLength())),
    )


def _required_int(value: int | None, name: str) -> int:
    if value is None:
        raise ValueError(f"camera frame missing {name}")
    return value
