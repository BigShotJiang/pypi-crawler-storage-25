from __future__ import annotations

from collections.abc import Iterator
from dataclasses import dataclass
import math
import os
import time
from typing import Any
from typing import Literal

import flatbuffers
import zmq

from .camera import CameraFrame
from .camera import decode_camera_frame
from .schema import decode_payload
from .schema import ensure_generated_schema_on_path
from .state import State
from .state import decode_state
from .telemetry import Telemetry
from .telemetry import decode_telemetry

ensure_generated_schema_on_path()

from droneforge.schema.ArmMessage import ArmMessageAddArmed
from droneforge.schema.ArmMessage import ArmMessageAddSeq
from droneforge.schema.ArmMessage import ArmMessageAddTNs
from droneforge.schema.ArmMessage import ArmMessageEnd
from droneforge.schema.ArmMessage import ArmMessageStart
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageAddHoldTimeS
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageAddSeq
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageAddTNs
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageAddType
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageAddWaypoint
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageEnd
from droneforge.schema.GuidanceRequestMessage import GuidanceRequestMessageStart
from droneforge.schema.GuidanceRequestType import GuidanceRequestType
from droneforge.schema.LocalFrameVector3D import CreateLocalFrameVector3D
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageAddHoldTimeS
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageAddMode
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageAddSeq
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageAddTNs
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageAddTarget
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageAddThresholdM
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageEnd
from droneforge.schema.WaypointCommandMessage import WaypointCommandMessageStart
from droneforge.schema.WaypointCommandMode import WaypointCommandMode


DEFAULT_PUB_ENDPOINT = os.environ.get("DF_ZMQ_PUB_ENDPOINT", "tcp://127.0.0.1:7771")
DEFAULT_SUB_ENDPOINT = os.environ.get("DF_ZMQ_SUB_ENDPOINT", "tcp://127.0.0.1:7772")
DEFAULT_WAYPOINT_THRESHOLD_M = 0.05
ARM_STATE_TOPIC = "arm_state"
GUIDANCE_REQUEST_TOPIC = "guidance_request"
WAYPOINT_COMMAND_TOPIC = "waypoint_command"

GuidanceRequestTypeName = Literal["go", "land", "relative_waypoint", "return_home"]
CameraTopicName = Literal["camera", "live_camera"]
SubscriptionTopicName = Literal["telemetry", "state", "camera", "live_camera"]
WaypointCommandModeName = Literal["override", "queue"]

GUIDANCE_REQUEST_TYPES: dict[str, int] = {
    "go": GuidanceRequestType.Go,
    "land": GuidanceRequestType.Land,
    "relative_waypoint": GuidanceRequestType.RelativeWaypoint,
    "return_home": GuidanceRequestType.ReturnHome,
}

WAYPOINT_COMMAND_MODES: dict[str, int] = {
    "override": WaypointCommandMode.Override,
    "queue": WaypointCommandMode.Queue,
}


@dataclass(frozen=True)
class ReceivedMessage:
    topic: str
    payload: bytes
    received_at_s: float
    decoded: Any
    root_type: str
    seq: int | None
    t_ns: int | None


class NimbusClient:
    def __init__(
        self,
        *,
        pub_endpoint: str = DEFAULT_PUB_ENDPOINT,
        sub_endpoint: str = DEFAULT_SUB_ENDPOINT,
    ) -> None:
        self.pub_endpoint = pub_endpoint
        self.sub_endpoint = sub_endpoint
        self._context = zmq.Context.instance()
        self._publisher: Any | None = None
        self._next_arm_state_seq = 0
        self._next_guidance_request_seq = 0
        self._next_waypoint_command_seq = 0

    def close(self) -> None:
        if self._publisher is not None:
            self._publisher.close()
            self._publisher = None

    def __enter__(self) -> "NimbusClient":
        return self

    def __exit__(self, _exc_type: Any, _exc: Any, _traceback: Any) -> None:
        self.close()

    def subscribe_telemetry(
        self,
        *,
        timeout_sec: float | None = None,
        receive_hwm: int = 128,
    ) -> Iterator[ReceivedMessage]:
        return self._subscribe(
            "telemetry",
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        )

    def telemetry(
        self,
        *,
        timeout_sec: float | None = None,
        receive_hwm: int = 128,
    ) -> Iterator[Telemetry]:
        for message in self.subscribe_telemetry(
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        ):
            yield decode_telemetry(message)

    def subscribe_state(
        self,
        *,
        timeout_sec: float | None = None,
        receive_hwm: int = 128,
    ) -> Iterator[ReceivedMessage]:
        return self._subscribe(
            "state",
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        )

    def state(
        self,
        *,
        timeout_sec: float | None = None,
        receive_hwm: int = 128,
    ) -> Iterator[State]:
        for message in self.subscribe_state(
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        ):
            yield decode_state(message)

    def subscribe_camera(
        self,
        *,
        topic: CameraTopicName = "camera",
        timeout_sec: float | None = None,
        receive_hwm: int = 8,
    ) -> Iterator[ReceivedMessage]:
        return self._subscribe(
            topic,
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        )

    def subscribe_live_camera(
        self,
        *,
        timeout_sec: float | None = None,
        receive_hwm: int = 8,
    ) -> Iterator[ReceivedMessage]:
        return self.subscribe_camera(
            topic="live_camera",
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        )

    def camera_frames(
        self,
        *,
        topic: CameraTopicName = "camera",
        timeout_sec: float | None = None,
        receive_hwm: int = 8,
    ) -> Iterator[CameraFrame]:
        for message in self.subscribe_camera(
            topic=topic,
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        ):
            yield decode_camera_frame(message)

    def live_camera_frames(
        self,
        *,
        timeout_sec: float | None = None,
        receive_hwm: int = 8,
    ) -> Iterator[CameraFrame]:
        return self.camera_frames(
            topic="live_camera",
            timeout_sec=timeout_sec,
            receive_hwm=receive_hwm,
        )

    def publish_arm_state(self, armed: bool = True) -> None:
        payload = _build_arm_state_payload(
            seq=self._take_arm_state_seq(),
            armed=armed,
        )
        self._publish(ARM_STATE_TOPIC, payload)

    def publish_guidance_request(
        self,
        request_type: GuidanceRequestTypeName,
        *,
        forward: float = 0.0,
        right: float = 0.0,
        down: float = 0.0,
        hold_time_s: float = 0.0,
    ) -> None:
        payload = _build_guidance_request_payload(
            seq=self._take_guidance_request_seq(),
            request_type=request_type,
            forward=forward,
            right=right,
            down=down,
            hold_time_s=hold_time_s,
        )
        self._publish(GUIDANCE_REQUEST_TOPIC, payload)

    def publish_waypoint_command(
        self,
        *,
        forward: float,
        right: float,
        down: float,
        mode: WaypointCommandModeName = "override",
        threshold_m: float = DEFAULT_WAYPOINT_THRESHOLD_M,
        hold_time_s: float = 0.0,
    ) -> None:
        payload = _build_waypoint_command_payload(
            seq=self._take_waypoint_command_seq(),
            mode=mode,
            forward=forward,
            right=right,
            down=down,
            threshold_m=threshold_m,
            hold_time_s=hold_time_s,
        )
        self._publish(WAYPOINT_COMMAND_TOPIC, payload)

    def _subscribe(
        self,
        topic: SubscriptionTopicName,
        *,
        timeout_sec: float | None,
        receive_hwm: int,
    ) -> Iterator[ReceivedMessage]:
        socket = self._context.socket(zmq.SUB)
        socket.setsockopt(zmq.LINGER, 0)
        socket.setsockopt(zmq.RCVHWM, receive_hwm)
        socket.setsockopt(zmq.SUBSCRIBE, topic.encode("utf-8"))
        socket.connect(self.sub_endpoint)
        deadline = time.monotonic() + timeout_sec if timeout_sec is not None else None

        try:
            while True:
                poll_timeout_ms = self._poll_timeout_ms(deadline)
                if poll_timeout_ms is not None and poll_timeout_ms <= 0:
                    return

                if socket.poll(timeout=poll_timeout_ms) == 0:
                    if deadline is not None:
                        return
                    continue

                topic_frame, payload_frame = socket.recv_multipart()
                received_topic = topic_frame.decode("utf-8")
                payload = bytes(payload_frame)
                decoded, root_type = decode_payload(received_topic, payload)
                yield ReceivedMessage(
                    topic=received_topic,
                    payload=payload,
                    received_at_s=time.monotonic(),
                    decoded=decoded,
                    root_type=root_type,
                    seq=_read_int_field(decoded, "Seq"),
                    t_ns=_read_int_field(decoded, "TNs"),
                )
        finally:
            socket.close()

    def _publish(self, topic: str, payload: bytes) -> None:
        publisher = self._ensure_publisher()
        publisher.send_multipart([topic.encode("utf-8"), payload])

    def _ensure_publisher(self) -> Any:
        if self._publisher is not None:
            return self._publisher

        publisher = self._context.socket(zmq.PUB)
        publisher.setsockopt(zmq.LINGER, 0)
        publisher.connect(self.pub_endpoint)
        self._publisher = publisher

        # Give the PUB socket a moment to connect before the first command.
        time.sleep(0.05)
        return publisher

    def _take_arm_state_seq(self) -> int:
        seq = self._next_arm_state_seq
        self._next_arm_state_seq += 1
        return seq

    def _take_guidance_request_seq(self) -> int:
        seq = self._next_guidance_request_seq
        self._next_guidance_request_seq += 1
        return seq

    def _take_waypoint_command_seq(self) -> int:
        seq = self._next_waypoint_command_seq
        self._next_waypoint_command_seq += 1
        return seq

    @staticmethod
    def _poll_timeout_ms(deadline: float | None) -> int | None:
        if deadline is None:
            return None

        remaining_sec = deadline - time.monotonic()
        if remaining_sec <= 0:
            return 0
        return max(1, int(remaining_sec * 1000))


def _build_arm_state_payload(*, seq: int, armed: bool) -> bytes:
    if not isinstance(armed, bool):
        raise ValueError("armed must be a bool")

    builder = flatbuffers.Builder(32)
    ArmMessageStart(builder)
    ArmMessageAddSeq(builder, seq)
    ArmMessageAddTNs(builder, time.monotonic_ns())
    ArmMessageAddArmed(builder, armed)
    message = ArmMessageEnd(builder)
    builder.Finish(message)
    return bytes(builder.Output())


def _build_guidance_request_payload(
    *,
    seq: int,
    request_type: GuidanceRequestTypeName,
    forward: float,
    right: float,
    down: float,
    hold_time_s: float,
) -> bytes:
    type_value = _guidance_request_type_value(request_type)
    _validate_waypoint(forward=forward, right=right, down=down)
    _validate_hold_time(hold_time_s)

    builder = flatbuffers.Builder(64)
    GuidanceRequestMessageStart(builder)
    GuidanceRequestMessageAddSeq(builder, seq)
    GuidanceRequestMessageAddTNs(builder, time.monotonic_ns())
    GuidanceRequestMessageAddType(builder, type_value)
    GuidanceRequestMessageAddWaypoint(
        builder,
        CreateLocalFrameVector3D(builder, forward, right, down),
    )
    GuidanceRequestMessageAddHoldTimeS(builder, hold_time_s)
    message = GuidanceRequestMessageEnd(builder)
    builder.Finish(message)
    return bytes(builder.Output())


def _build_waypoint_command_payload(
    *,
    seq: int,
    mode: WaypointCommandModeName,
    forward: float,
    right: float,
    down: float,
    threshold_m: float,
    hold_time_s: float,
) -> bytes:
    mode_value = _waypoint_command_mode_value(mode)
    _validate_waypoint(forward=forward, right=right, down=down)
    _validate_threshold(threshold_m)
    _validate_hold_time(hold_time_s)

    builder = flatbuffers.Builder(64)
    WaypointCommandMessageStart(builder)
    WaypointCommandMessageAddSeq(builder, seq)
    WaypointCommandMessageAddTNs(builder, time.monotonic_ns())
    WaypointCommandMessageAddMode(builder, mode_value)
    WaypointCommandMessageAddTarget(
        builder,
        CreateLocalFrameVector3D(builder, forward, right, down),
    )
    WaypointCommandMessageAddThresholdM(builder, threshold_m)
    WaypointCommandMessageAddHoldTimeS(builder, hold_time_s)
    message = WaypointCommandMessageEnd(builder)
    builder.Finish(message)
    return bytes(builder.Output())


def _guidance_request_type_value(request_type: GuidanceRequestTypeName) -> int:
    try:
        return GUIDANCE_REQUEST_TYPES[request_type]
    except KeyError as exc:
        raise ValueError(f"unsupported guidance request type: {request_type}") from exc


def _waypoint_command_mode_value(mode: WaypointCommandModeName) -> int:
    try:
        return WAYPOINT_COMMAND_MODES[mode]
    except KeyError as exc:
        raise ValueError(f"unsupported waypoint command mode: {mode}") from exc


def _validate_waypoint(*, forward: float, right: float, down: float) -> None:
    if not (math.isfinite(forward) and math.isfinite(right) and math.isfinite(down)):
        raise ValueError("waypoint forward, right, and down must be finite numbers")


def _validate_threshold(threshold_m: float) -> None:
    if not math.isfinite(threshold_m) or threshold_m <= 0.0:
        raise ValueError("waypoint threshold_m must be a positive finite number")


def _validate_hold_time(hold_time_s: float) -> None:
    if not math.isfinite(hold_time_s) or hold_time_s < 0.0:
        raise ValueError("waypoint hold_time_s must be a non-negative finite number")


def _read_int_field(root: Any, method_name: str) -> int | None:
    method = getattr(root, method_name, None)
    if method is None:
        return None

    value = method()
    if isinstance(value, int):
        return value
    return None
