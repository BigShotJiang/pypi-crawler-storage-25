"""Packaged FlatBuffer schema modules used by the NimbusOS SDK."""
