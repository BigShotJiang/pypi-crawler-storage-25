from dataclasses import dataclass
import math
from typing import Any


@dataclass(frozen=True)
class BatteryTelemetry:
    voltage: float
    current: float
    remaining_capacity: float


@dataclass(frozen=True)
class AttitudeTelemetry:
    roll_deg: float
    pitch_deg: float
    yaw_deg: float


@dataclass(frozen=True)
class LinkTelemetry:
    uplink_link_quality: float
    rf_mode: str


@dataclass(frozen=True)
class Telemetry:
    seq: int
    t_ns: int
    battery: BatteryTelemetry
    attitude: AttitudeTelemetry
    link: LinkTelemetry


def decode_telemetry(message: Any) -> Telemetry:
    decoded = message.decoded

    battery = _required(decoded.Battery(), "battery")
    attitude = _required(decoded.Attitude(), "attitude")
    link = _required(decoded.LinkStats(), "link")

    return Telemetry(
        seq=_required_int(message.seq, "seq"),
        t_ns=_required_int(message.t_ns, "t_ns"),
        battery=BatteryTelemetry(
            voltage=battery.Voltage(),
            current=battery.Current(),
            remaining_capacity=battery.RemainingCapacity(),
        ),
        attitude=AttitudeTelemetry(
            roll_deg=math.degrees(attitude.Roll()),
            pitch_deg=math.degrees(attitude.Pitch()),
            yaw_deg=math.degrees(attitude.Yaw()),
        ),
        link=LinkTelemetry(
            uplink_link_quality=link.UplinkLinkQuality(),
            rf_mode=_required_string(link.RfMode(), "link.rf_mode"),
        ),
    )


def _required(value: Any | None, name: str) -> Any:
    if value is None:
        raise ValueError(f"telemetry message missing {name}")
    return value


def _required_int(value: int | None, name: str) -> int:
    if value is None:
        raise ValueError(f"telemetry message missing {name}")
    return value


def _required_string(value: bytes | str | None, name: str) -> str:
    if value is None:
        raise ValueError(f"telemetry message missing {name}")
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return value
