from dataclasses import dataclass
import math
from typing import Any


@dataclass(frozen=True)
class LocalFramePosition:
    x_m: float
    y_m: float
    z_m: float


@dataclass(frozen=True)
class LocalFrameVelocity:
    x_mps: float
    y_mps: float
    z_mps: float


@dataclass(frozen=True)
class LocalFrameDirection:
    x: float
    y: float
    z: float


@dataclass(frozen=True)
class StateAttitude:
    roll_deg: float
    pitch_deg: float
    yaw_deg: float


@dataclass(frozen=True)
class StateOrientation:
    w: float
    x: float
    y: float
    z: float


@dataclass(frozen=True)
class State:
    seq: int
    t_ns: int
    valid: bool
    position: LocalFramePosition
    velocity: LocalFrameVelocity
    forward: LocalFrameDirection
    right: LocalFrameDirection
    attitude: StateAttitude
    orientation: StateOrientation


def decode_state(message: Any) -> State:
    decoded = message.decoded
    state = _required(decoded.State(), "state")

    position = _required(state.Position(), "state.position")
    velocity = _required(state.Velocity(), "state.velocity")
    forward = _required(state.Forward(), "state.forward")
    right = _required(state.Right(), "state.right")
    attitude = _required(state.Attitude(), "state.attitude")
    orientation = _required(state.Orientation(), "state.orientation")

    return State(
        seq=_required_int(message.seq, "seq"),
        t_ns=_required_int(message.t_ns, "t_ns"),
        valid=state.Valid(),
        position=LocalFramePosition(
            x_m=position.X(),
            y_m=position.Y(),
            z_m=position.Z(),
        ),
        velocity=LocalFrameVelocity(
            x_mps=velocity.X(),
            y_mps=velocity.Y(),
            z_mps=velocity.Z(),
        ),
        forward=LocalFrameDirection(
            x=forward.X(),
            y=forward.Y(),
            z=forward.Z(),
        ),
        right=LocalFrameDirection(
            x=right.X(),
            y=right.Y(),
            z=right.Z(),
        ),
        attitude=StateAttitude(
            roll_deg=math.degrees(attitude.Roll()),
            pitch_deg=math.degrees(attitude.Pitch()),
            yaw_deg=math.degrees(attitude.Yaw()),
        ),
        orientation=StateOrientation(
            w=orientation.W(),
            x=orientation.X(),
            y=orientation.Y(),
            z=orientation.Z(),
        ),
    )


def _required(value: Any | None, name: str) -> Any:
    if value is None:
        raise ValueError(f"state message missing {name}")
    return value


def _required_int(value: int | None, name: str) -> int:
    if value is None:
        raise ValueError(f"state message missing {name}")
    return value
