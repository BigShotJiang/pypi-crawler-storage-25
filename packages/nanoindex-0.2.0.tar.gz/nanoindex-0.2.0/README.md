<div align="center">

<img src="assets/Nanoindex.png" alt="NanoIndex" width="200"/>

# NanoIndex

**Turn any PDF into searchable trees and Karpathy-inspired knowledge graphs.**
**Ask questions, get answers with page citations.**

<p>
  <a href="https://github.com/nanonets/nanoindex"><img src="https://img.shields.io/badge/GitHub-NanoIndex-181717?style=for-the-badge&logo=github&logoColor=white" /></a>
  <a href="https://nanonets.com/research/nanonets-ocr-3"><img src="https://img.shields.io/badge/Built%20on-Nanonets%20OCR--3-546FFF?style=for-the-badge" /></a>
  <a href="https://www.apache.org/licenses/LICENSE-2.0"><img src="https://img.shields.io/badge/License-Apache%202.0-20C997?style=for-the-badge" /></a>
</p>

<p>
  <a href="https://docstrange.nanonets.com/app"><img src="https://img.shields.io/badge/Get%20API%20Key-Free%2010K%20Pages-FCC419?style=for-the-badge" /></a>
  <a href="https://colab.research.google.com/github/NanoNets/nanoindex/blob/main/examples/nanoindex_quickstart.ipynb"><img src="https://img.shields.io/badge/Try%20in-Google%20Colab-F9AB00?style=for-the-badge&logo=googlecolab&logoColor=white" /></a>
</p>

| Benchmark | Documents | Avg Pages | Accuracy |
|---|---|---|---|
| FinanceBench (SEC 10-K filings) | 84 | 143 | **94.5%** |
| DocBench Legal (court filings, legislation) | 51 | 54 | **96.0%** |

</div>

No vector databases. No chunk tuning. No embeddings.

NanoIndex reads your document, understands its structure (headings, sections, tables, figures), and builds a tree you can search with plain English. Every document also gets a knowledge graph built automatically with entity extraction (spaCy NER + dependency parsing, enhanced by LLM when available). Inspired by [Karpathy's LLM knowledge base approach](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f) — documents compile into an interlinked wiki that grows smarter with every query.

Built on [Nanonets OCR-3](https://nanonets.com/research/nanonets-ocr-3) for extraction. Fully open source.

---

## Quick Start

### 1. Install

```bash
pip install nanoindex
```

### 2. Set your API keys

```bash
export NANONETS_API_KEY=your_key    # Get free at docstrange.nanonets.com/app (10K pages free)
export ANTHROPIC_API_KEY=your_key    # Or OPENAI_API_KEY, GOOGLE_API_KEY, GROQ_API_KEY
```

### 3. Go

```python
from nanoindex import NanoIndex

ni = NanoIndex()
tree = ni.index("report.pdf")
answer = ni.ask("What was the revenue?", tree)
print(answer.content)
```

That's it. Keys auto-detected from env. LLM auto-selected from available keys.

---

## What Can You Do With It

### Ask questions, get cited answers

```python
answer = ni.ask("What was Q3 gross margin?", tree)
print(answer.content)     # "Gross margin was 42.3% in Q3..."
print(answer.citations)   # [Citation(title="Income Statement", pages=[45, 46])]
```

### From the command line

```bash
nanoindex index report.pdf -o tree.json
nanoindex ask report.pdf "What was the revenue?"
nanoindex viz tree.json
```

### Pick your LLM

```python
ni = NanoIndex(llm="anthropic:claude-sonnet-4-6")
ni = NanoIndex(llm="openai:gpt-5.4")
ni = NanoIndex(llm="gemini:gemini-2.5-flash")
ni = NanoIndex(llm="groq:llama-3.3-70b-versatile")
ni = NanoIndex(llm="ollama:llama3")
```

Or just set the env var and NanoIndex picks the right one:

```bash
export ANTHROPIC_API_KEY=...   # NanoIndex uses Claude automatically
```

### Save and reuse trees

```python
from nanoindex.utils.tree_ops import save_tree, load_tree

save_tree(tree, "my_tree.json")
tree = load_tree("my_tree.json")  # instant, no API call
```

### Search across multiple documents

```python
from nanoindex import DocumentStore

store = DocumentStore()
for pdf in ["q1.pdf", "q2.pdf", "q3.pdf"]:
    store.add(ni.index(pdf))

answer = ni.multi_ask("Compare revenue across quarters", store)
```

### Build a Knowledge Base

```python
from nanoindex import KnowledgeBase

kb = KnowledgeBase("./my-research")
kb.add("report1.pdf")
kb.add("report2.pdf")

answer = kb.ask("How do these compare?")  # answers filed back into wiki
```

Open the `my-research/` folder in Obsidian to browse the compiled wiki with `[[backlinks]]`.

---

## How It Works

### Indexing: PDF to tree + graph

<p align="center">
  <img src="assets/ingestion-pipeline.gif" alt="Ingestion Pipeline" width="800"/>
</p>

### Querying: Agentic Mode (default)

<p align="center">
  <img src="assets/query-agentic.gif" alt="Query Pipeline - Agentic Mode" width="800"/>
</p>

### Querying: Fast Mode (graph-based, cheaper)

<p align="center">
  <img src="assets/query-fast.gif" alt="Query Pipeline - Fast Mode" width="800"/>
</p>

---

## Query Modes

| Mode | How it works | Best for |
|---|---|---|
| `agentic_vision` (default) | LLM navigates full tree + reads page images | Highest accuracy |
| `agentic` | Same without images | Text-heavy docs |
| `fast` | Graph entity lookup, LLM sees ~20 nodes | Cheapest, fastest |
| `fast_vision` | Same + page images | Charts and figures |

```python
# Default — agentic with vision
answer = ni.ask("What was revenue?", tree, pdf_path="report.pdf")

# Fast mode — graph-based, 3x cheaper
answer = ni.ask("What was revenue?", tree, mode="fast")
```

---

## Entity Graph

Every indexed document gets a knowledge graph built automatically. No extra API calls needed.

**How it works:**
1. **spaCy NER** extracts named entities (organizations, people, money, dates, locations) from every tree node
2. **Dependency parsing** extracts subject-verb-object triples as relationships
3. **Co-occurrence linking** connects entities that appear in the same sentence
4. **Cross-node dedup** merges the same entity found across different sections
5. **LLM enhancement** (optional) adds domain-specific entities and relationships when a reasoning LLM is configured

```python
# Graph is built automatically during indexing
tree = ni.index("report.pdf")
graph = ni._graphs[tree.doc_name]

print(f"Entities: {len(graph.entities)}")
print(f"Relationships: {len(graph.relationships)}")

for e in graph.entities[:5]:
    print(f"  [{e.entity_type}] {e.name} (found in {len(e.source_node_ids)} sections)")

for r in graph.relationships[:5]:
    print(f"  {r.source} --{r.keywords}--> {r.target}")
```

The graph powers:
- **Fast mode** retrieval (entity keyword match + relationship expansion, 3x cheaper than agentic)
- **Knowledge Base** concept articles with `[[backlinks]]` across documents
- **Entities tab** in the visualization dashboard

---

## Bounding Boxes and Citations

Every answer includes citations with exact bounding box coordinates:

```python
for citation in answer.citations:
    print(f"Section: {citation.title}, Pages: {citation.pages}")
    for bb in citation.bounding_boxes:
        print(f"  Page {bb.page}: ({bb.x:.2f}, {bb.y:.2f}) — {bb.text}")
```

The citation resolver matches answer text back to specific regions on the PDF page, so you can highlight exactly where the answer came from.

---

## Open-Source Mode (No API Key for Parsing)

```python
ni = NanoIndex(parser="pymupdf")
tree = ni.index("report.pdf")  # no API key needed
```

PyMuPDF gives basic text and table extraction. The tree will be simpler (no heading detection), but works for quick experiments. For production, use Nanonets OCR-3.

---

## Benchmarks

| Benchmark | Documents | Avg Pages | Accuracy |
|---|---|---|---|
| FinanceBench (SEC 10-K filings) | 84 | 143 | **94.5%** |
| DocBench Legal (court filings, legislation) | 51 | 54 | **96.0%** |

Evidence page retrieval: **93.3%**

<p align="center">
  <img src="assets/financebench-architecture.png" alt="FinanceBench Architecture" width="800"/>
</p>

---

## How It Compares

| | Traditional RAG | NanoIndex |
|---|---|---|
| Indexing | Chunk + embed + vector DB | Extract + build tree |
| Retrieval | Similarity search | LLM reasons over structure |
| Tables | Poorly handled | Natively extracted |
| Figures | Not supported | Vision mode |
| Scanned docs | Needs separate OCR | Built-in |
| Structure-aware | No | Yes |
| Citations | Approximate | Exact page + bounding box |

---

## Development

```bash
git clone https://github.com/nanonets/nanoindex.git
cd nanoindex
pip install -e ".[dev]"
pytest
```

---

## License

Apache 2.0 — see [LICENSE](LICENSE).
