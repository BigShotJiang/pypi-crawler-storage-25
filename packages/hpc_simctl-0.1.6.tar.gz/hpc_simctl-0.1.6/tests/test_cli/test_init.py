"""Tests for simctl init and simctl doctor CLI commands."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from simctl.cli.main import app

runner = CliRunner()


@pytest.fixture(autouse=True)
def _mock_bootstrap(monkeypatch: pytest.MonkeyPatch) -> None:
    """Skip the bootstrap step (uv/git clone) in all init tests."""
    monkeypatch.setattr(
        "simctl.cli.init._bootstrap_environment",
        lambda *_args, **_kwargs: None,
    )


class TestInit:
    """Tests for the 'simctl init' command."""

    def test_init_creates_all_files(self, tmp_path: Path) -> None:
        """Init in an empty directory creates all expected files and dirs."""
        result = runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        assert result.exit_code == 0
        assert (tmp_path / "simproject.toml").exists()
        assert (tmp_path / "simulators.toml").exists()
        assert (tmp_path / "launchers.toml").exists()
        assert (tmp_path / "campaign.toml").exists()
        assert (tmp_path / "cases").is_dir()
        assert (tmp_path / "runs").is_dir()
        assert (tmp_path / ".gitignore").exists()
        assert (tmp_path / ".git").is_dir()
        assert (tmp_path / "CLAUDE.md").exists()
        assert (tmp_path / "AGENTS.md").exists()
        assert (tmp_path / ".claude" / "skills").is_dir()
        assert (tmp_path / ".vscode" / "settings.json").exists()

    def test_init_simproject_content(self, tmp_path: Path) -> None:
        """simproject.toml has correct project name derived from dir name."""
        result = runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        assert result.exit_code == 0
        content = (tmp_path / "simproject.toml").read_text(encoding="utf-8")
        assert "[project]" in content
        assert f'name = "{tmp_path.name}"' in content

    def test_init_custom_name(self, tmp_path: Path) -> None:
        """--name option overrides directory name in simproject.toml."""
        result = runner.invoke(
            app, ["init", "-y", "--path", str(tmp_path), "--name", "my-project"]
        )
        assert result.exit_code == 0
        content = (tmp_path / "simproject.toml").read_text(encoding="utf-8")
        assert 'name = "my-project"' in content
        assert "my-project" in result.output

    def test_init_simulators_content(self, tmp_path: Path) -> None:
        """simulators.toml has empty [simulators] section."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        content = (tmp_path / "simulators.toml").read_text(encoding="utf-8")
        assert "[simulators]" in content

    def test_init_launchers_content(self, tmp_path: Path) -> None:
        """launchers.toml has default srun launcher."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        content = (tmp_path / "launchers.toml").read_text(encoding="utf-8")
        assert "[launchers.srun]" in content
        assert 'type = "srun"' in content
        assert "use_slurm_ntasks = true" in content

    def test_init_campaign_content(self, tmp_path: Path) -> None:
        """campaign.toml is created with schema and simulator hint."""
        runner.invoke(app, ["init", "emses", "-y", "--path", str(tmp_path)])
        content = (tmp_path / "campaign.toml").read_text(encoding="utf-8")
        assert "#:schema" in content
        assert "[campaign]" in content
        assert f'name = "{tmp_path.name}"' in content
        assert 'simulator = "emses"' in content
        assert "[variables]" in content
        assert "[observables]" in content

    def test_init_gitignore_content(self, tmp_path: Path) -> None:
        """.gitignore contains run output exclusion patterns."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert "runs/**/work/outputs/" in content
        assert "runs/**/work/restart/" in content
        assert "runs/**/work/tmp/" in content

    def test_init_skips_existing_files(self, tmp_path: Path) -> None:
        """Init does not overwrite existing files."""
        (tmp_path / "simproject.toml").write_text('[project]\nname = "original"\n')
        result = runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        assert result.exit_code == 0
        content = (tmp_path / "simproject.toml").read_text(encoding="utf-8")
        assert 'name = "original"' in content
        assert "Skipped" in result.output

    def test_init_reports_created_items(self, tmp_path: Path) -> None:
        """Init output lists created items."""
        result = runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        assert result.exit_code == 0
        assert "Created:" in result.output
        assert "simproject.toml" in result.output

    def test_init_creates_target_directory(self, tmp_path: Path) -> None:
        """Init creates the target directory if it does not exist."""
        target = tmp_path / "new-project"
        result = runner.invoke(app, ["init", "-y", "--path", str(target)])
        assert result.exit_code == 0
        assert target.is_dir()
        assert (target / "simproject.toml").exists()

    def test_init_defaults_to_cwd(self, tmp_path: Path) -> None:
        """Init without path argument uses current working directory."""
        import os

        original_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(app, ["init", "-y"])
            assert result.exit_code == 0
            assert (tmp_path / "simproject.toml").exists()
        finally:
            os.chdir(original_cwd)

    def test_init_skips_git_init_if_exists(self, tmp_path: Path) -> None:
        """Init skips git init when .git already exists."""
        (tmp_path / ".git").mkdir()
        result = runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        assert result.exit_code == 0
        assert "git init" in result.output
        assert "Skipped" in result.output

    def test_init_claude_md_with_simulators(self, tmp_path: Path) -> None:
        """CLAUDE.md includes refs but not inline simulator details."""
        runner.invoke(app, ["init", "emses", "beach", "-y", "--path", str(tmp_path)])
        content = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        # Simulator details are via imports.md, not inline
        assert "シミュレータ固有知識" not in content
        assert "Agent ガイド" not in content
        assert "simctl context" in content
        assert "campaign.toml" in content
        # Ref repos should be listed
        assert "リファレンスリポジトリ" in content
        # Cookbook rule should be generated separately
        cookbook_rule = tmp_path / ".claude" / "rules" / "cookbook.md"
        assert cookbook_rule.exists()
        assert "cookbook" in cookbook_rule.read_text(encoding="utf-8").lower()

    def test_init_claude_md_without_simulators(self, tmp_path: Path) -> None:
        """CLAUDE.md is generated without simulator sections when none given."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        content = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert "simctl" in content
        assert "シミュレータ固有知識" not in content
        # No cookbook rule when no simulators
        cookbook_rule = tmp_path / ".claude" / "rules" / "cookbook.md"
        assert not cookbook_rule.exists()

    def test_init_agents_md(self, tmp_path: Path) -> None:
        """AGENTS.md is generated as a standalone instruction file."""
        runner.invoke(app, ["init", "emses", "-y", "--path", str(tmp_path)])
        agents_path = tmp_path / "AGENTS.md"
        assert agents_path.exists()
        assert not agents_path.is_symlink()
        content = agents_path.read_text(encoding="utf-8")
        assert "simctl" in content
        assert "simctl context" in content
        assert "役割分担" in content

    def test_init_skills(self, tmp_path: Path) -> None:
        """Individual SKILL.md files are created under .claude/skills/."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        skills_dir = tmp_path / ".claude" / "skills"
        assert (skills_dir / "setup-env" / "SKILL.md").exists()
        assert (skills_dir / "survey-design" / "SKILL.md").exists()
        assert (skills_dir / "check-status" / "SKILL.md").exists()
        assert (skills_dir / "simctl-reference" / "SKILL.md").exists()
        setup_content = (skills_dir / "setup-env" / "SKILL.md").read_text(
            encoding="utf-8"
        )
        assert "uv venv" in setup_content

    def test_init_skills_with_packages(self, tmp_path: Path) -> None:
        """Setup-env skill includes pip packages when simulators specified."""
        runner.invoke(app, ["init", "emses", "-y", "--path", str(tmp_path)])
        content = (
            tmp_path / ".claude" / "skills" / "setup-env" / "SKILL.md"
        ).read_text(encoding="utf-8")
        assert "emout" in content
        assert "h5py" in content

    def test_init_claude_settings(self, tmp_path: Path) -> None:
        """Team-shared .claude/settings.json is created with permissions."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        settings_path = tmp_path / ".claude" / "settings.json"
        assert settings_path.exists()
        import json

        data = json.loads(settings_path.read_text(encoding="utf-8"))
        assert "permissions" in data
        assert "allow" in data["permissions"]
        assert any("simctl" in r for r in data["permissions"]["allow"])

    def test_init_claude_rules(self, tmp_path: Path) -> None:
        """Project rules are created in .claude/rules/."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        rules_dir = tmp_path / ".claude" / "rules"
        assert (rules_dir / "simctl-workflow.md").exists()
        assert (rules_dir / "plan-before-act.md").exists()
        workflow = (rules_dir / "simctl-workflow.md").read_text(encoding="utf-8")
        assert "manifest.toml" in workflow

    def test_init_subdirectory_claude_md(self, tmp_path: Path) -> None:
        """Context-specific CLAUDE.md files are created in cases/ and runs/."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        assert (tmp_path / "cases" / "CLAUDE.md").exists()
        assert (tmp_path / "runs" / "CLAUDE.md").exists()
        cases_content = (tmp_path / "cases" / "CLAUDE.md").read_text(
            encoding="utf-8"
        )
        assert "case.toml" in cases_content
        runs_content = (tmp_path / "runs" / "CLAUDE.md").read_text(
            encoding="utf-8"
        )
        assert "manifest.toml" in runs_content

    def test_init_gitignore_personal_overrides(self, tmp_path: Path) -> None:
        """.gitignore excludes personal agent override files."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        content = (tmp_path / ".gitignore").read_text(encoding="utf-8")
        assert "CLAUDE.local.md" in content
        assert "settings.local.json" in content

    def test_init_with_simulators(self, tmp_path: Path) -> None:
        """Init with simulator names generates default simulators.toml."""
        result = runner.invoke(
            app, ["init", "emses", "beach", "-y", "--path", str(tmp_path)]
        )
        assert result.exit_code == 0
        content = (tmp_path / "simulators.toml").read_text(encoding="utf-8")
        assert "[simulators.emses]" in content
        assert 'adapter = "emses"' in content
        assert 'executable = "mpiemses3D"' in content
        assert "[simulators.beach]" in content
        assert 'adapter = "beach"' in content

    def test_init_with_unknown_simulator(self, tmp_path: Path) -> None:
        """Init with unknown simulator name fails with helpful error."""
        result = runner.invoke(
            app, ["init", "nonexistent", "-y", "--path", str(tmp_path)]
        )
        assert result.exit_code != 0
        assert "Unknown simulator" in result.output

    def test_init_with_single_simulator(self, tmp_path: Path) -> None:
        """Init with a single simulator name works."""
        result = runner.invoke(app, ["init", "emses", "-y", "--path", str(tmp_path)])
        assert result.exit_code == 0
        content = (tmp_path / "simulators.toml").read_text(encoding="utf-8")
        assert "[simulators.emses]" in content
        assert "beach" not in content

    def test_init_schema_comments(self, tmp_path: Path) -> None:
        """Generated TOMLs include #:schema comments."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        for filename in ("simproject.toml", "simulators.toml", "launchers.toml"):
            content = (tmp_path / filename).read_text(encoding="utf-8")
            assert "#:schema" in content

    def test_init_references_tools_dir(self, tmp_path: Path) -> None:
        """CLAUDE.md references tools/hpc-simctl/ for docs."""
        runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])
        content = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert "tools/hpc-simctl/" in content
        # docs/ directory should NOT be generated
        assert not (tmp_path / "docs").exists()

    def test_init_renders_imports_after_bootstrap(self, tmp_path: Path, monkeypatch) -> None:
        """Init discovers tool docs only after bootstrap and wires imports.md."""

        def _fake_bootstrap(
            project_dir: Path,
            _sim_names: list[str],
            _simctl_repo: str,
            created: list[str],
            _skipped: list[str],
        ) -> None:
            docs_dir = project_dir / "tools" / "hpc-simctl" / "docs"
            docs_dir.mkdir(parents=True, exist_ok=True)
            (docs_dir / "agent-user-guide.md").write_text("# Agent guide\n")
            created.append("tools/hpc-simctl")

        monkeypatch.setattr("simctl.cli.init._bootstrap_environment", _fake_bootstrap)

        result = runner.invoke(app, ["init", "-y", "--path", str(tmp_path)])

        assert result.exit_code == 0
        imports_path = tmp_path / ".simctl" / "knowledge" / "enabled" / "imports.md"
        assert imports_path.is_file()
        imports = imports_path.read_text(encoding="utf-8")
        assert "@tools/hpc-simctl/docs/agent-user-guide.md" in imports
        claude = (tmp_path / "CLAUDE.md").read_text(encoding="utf-8")
        assert "@.simctl/knowledge/enabled/imports.md" in claude

    def test_init_default_is_interactive(self, tmp_path: Path) -> None:
        """Init without -y is interactive (prompts for project name)."""
        user_input = "\n" * 20
        result = runner.invoke(app, ["init", "--path", str(tmp_path)], input=user_input)
        assert result.exit_code == 0
        assert "Project name" in result.output


class TestDoctor:
    """Tests for the 'simctl doctor' command."""

    def test_doctor_all_pass(self, tmp_path: Path) -> None:
        """Doctor passes on a properly initialized project with sbatch."""
        # Set up a valid project
        (tmp_path / "simproject.toml").write_text('[project]\nname = "test-project"\n')
        (tmp_path / "simulators.toml").write_text("[simulators]\n")
        (tmp_path / "launchers.toml").write_text("[launchers]\n")
        (tmp_path / "runs").mkdir()

        with patch("simctl.cli.init.shutil.which", return_value="/usr/bin/sbatch"):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 0
        assert "All checks passed" in result.output

    def test_doctor_missing_simproject(self, tmp_path: Path) -> None:
        """Doctor fails if simproject.toml is missing."""
        result = runner.invoke(app, ["doctor", str(tmp_path)])
        assert result.exit_code == 1
        assert "[FAIL] simproject.toml not found" in result.output

    def test_doctor_invalid_simproject(self, tmp_path: Path) -> None:
        """Doctor fails if simproject.toml is invalid."""
        (tmp_path / "simproject.toml").write_text("invalid content\n")
        (tmp_path / "simulators.toml").write_text("[simulators]\n")
        (tmp_path / "launchers.toml").write_text("[launchers]\n")

        with patch("simctl.cli.init.shutil.which", return_value="/usr/bin/sbatch"):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 1
        assert "[FAIL] simproject.toml" in result.output

    def test_doctor_missing_simulators(self, tmp_path: Path) -> None:
        """Doctor fails if simulators.toml is missing."""
        (tmp_path / "simproject.toml").write_text('[project]\nname = "test-project"\n')
        (tmp_path / "launchers.toml").write_text("[launchers]\n")

        with patch("simctl.cli.init.shutil.which", return_value="/usr/bin/sbatch"):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 1
        assert "[FAIL] simulators.toml not found" in result.output

    def test_doctor_missing_launchers(self, tmp_path: Path) -> None:
        """Doctor fails if launchers.toml is missing."""
        (tmp_path / "simproject.toml").write_text('[project]\nname = "test-project"\n')
        (tmp_path / "simulators.toml").write_text("[simulators]\n")

        with patch("simctl.cli.init.shutil.which", return_value="/usr/bin/sbatch"):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 1
        assert "[FAIL] launchers.toml not found" in result.output

    def test_doctor_missing_sbatch(self, tmp_path: Path) -> None:
        """Doctor fails if sbatch is not in PATH."""
        (tmp_path / "simproject.toml").write_text('[project]\nname = "test-project"\n')
        (tmp_path / "simulators.toml").write_text("[simulators]\n")
        (tmp_path / "launchers.toml").write_text("[launchers]\n")

        with patch("simctl.cli.init.shutil.which", return_value=None):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 1
        assert "[FAIL] sbatch not found in PATH" in result.output

    def test_doctor_duplicate_run_ids(self, tmp_path: Path) -> None:
        """Doctor fails if duplicate run_ids exist."""
        (tmp_path / "simproject.toml").write_text('[project]\nname = "test-project"\n')
        (tmp_path / "simulators.toml").write_text("[simulators]\n")
        (tmp_path / "launchers.toml").write_text("[launchers]\n")
        runs_dir = tmp_path / "runs"
        runs_dir.mkdir()

        # Create two runs with the same run_id
        for sub in ("run_a", "run_b"):
            run_dir = runs_dir / sub
            run_dir.mkdir()
            (run_dir / "manifest.toml").write_text(
                '[run]\nid = "R20260327-0001"\nstatus = "created"\n'
            )

        with patch("simctl.cli.init.shutil.which", return_value="/usr/bin/sbatch"):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 1
        assert "[FAIL] Duplicate run_id" in result.output

    def test_doctor_no_runs_dir(self, tmp_path: Path) -> None:
        """Doctor passes run_id check when runs/ does not exist."""
        (tmp_path / "simproject.toml").write_text('[project]\nname = "test-project"\n')
        (tmp_path / "simulators.toml").write_text("[simulators]\n")
        (tmp_path / "launchers.toml").write_text("[launchers]\n")

        with patch("simctl.cli.init.shutil.which", return_value="/usr/bin/sbatch"):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 0
        assert "[PASS] No runs/ directory" in result.output

    def test_doctor_reports_failure_count(self, tmp_path: Path) -> None:
        """Doctor output includes the number of failed checks."""
        # Empty dir: simproject, simulators, launchers all missing + no sbatch
        with patch("simctl.cli.init.shutil.which", return_value=None):
            result = runner.invoke(app, ["doctor", str(tmp_path)])

        assert result.exit_code == 1
        assert "check(s) failed" in result.output
