"""dvt = dbt Visualisation Tool. Visualizes dbt execution timeline over threads."""
from __future__ import annotations

import argparse
import html as htmllib
import json
import webbrowser
from pathlib import Path
from typing import Optional

import pandas as pd
import plotly.colors as pcolors
import plotly.graph_objects as go
import plotly.io as pio

from . import __version__


STATUS_COLORS = {
    "success": "#4caf50",
    "pass": "#81c784",
    "warn": "#ffb74d",
    "error": "#e53935",
    "fail": "#e53935",
    "runtime error": "#b71c1c",
    "skipped": "#bdbdbd",
}


def _fmt_dur(seconds: float) -> str:
    if seconds < 1:
        return f"{seconds * 1000:.0f} ms"
    if seconds < 60:
        return f"{seconds:.2f} s"
    m, s = divmod(seconds, 60)
    return f"{int(m)}m {s:.1f}s"


def _name(uid: str) -> str:
    # test unique_ids carry a trailing hash: test.<pkg>.<name>.<hash>
    parts = uid.split(".")
    if parts[0] == "test" and len(parts) >= 4:
        return parts[2]
    return parts[-1]


def _rtype(uid: str) -> str:
    return uid.split(".", 1)[0]


def _load_manifest_nodes(path: Optional[Path]) -> dict:
    if not path:
        return {}
    with path.open() as f:
        return json.load(f).get("nodes", {})


def _folder(uid: str, nodes: dict, depth: int, _seen: Optional[set] = None) -> str:
    if not nodes:
        return "—"
    node = nodes.get(uid)
    if not node:
        return "—"
    if node.get("resource_type") == "test":
        seen = _seen or set()
        if uid in seen:
            return "test"
        seen.add(uid)
        for dep in node.get("depends_on", {}).get("nodes", []):
            if dep in nodes:
                return _folder(dep, nodes, depth, seen)
        return "test"
    path = node.get("path") or ""
    dirpath = path.rsplit("/", 1)[0] if "/" in path else ""
    if not dirpath:
        return node.get("resource_type", "—")
    parts = dirpath.split("/")
    return "/".join(parts[:depth])


def _load(results_path: Path, manifest_path: Optional[Path]) -> tuple[pd.DataFrame, bool]:
    with results_path.open() as f:
        data = json.load(f)
    nodes = _load_manifest_nodes(manifest_path)
    has_manifest = bool(nodes)

    rows = []
    for r in data.get("results", []):
        execute = next((t for t in r.get("timing", []) if t.get("name") == "execute"), None)
        if not execute:
            continue
        uid = r["unique_id"]
        name = _name(uid)
        rtype = _rtype(uid)
        start = pd.to_datetime(execute["started_at"])
        end = pd.to_datetime(execute["completed_at"])
        dur = (end - start).total_seconds()
        node = nodes.get(uid, {})
        materialization = (node.get("config") or {}).get("materialized") or "—"
        if rtype != "model":
            materialization = "—"
        rows.append({
            "uid": uid,
            "name": name,
            "thread": r["thread_id"],
            "s": start, "e": end,
            "duration": dur,
            "duration_str": _fmt_dur(dur),
            "start_str": start.strftime("%H:%M:%S"),
            "end_str": end.strftime("%H:%M:%S"),
            "status": r.get("status", "?"),
            "type": rtype,
            "prefix1": (name.split("_", 1)[0] if "_" in name else name) or "?",
            "prefix2": "_".join(name.split("_")[:2]) or "?",
            "folder": _folder(uid, nodes, 1),
            "folder2": _folder(uid, nodes, 2),
            "materialization": materialization,
        })
    return pd.DataFrame(rows), has_manifest


def _thread_order(df: pd.DataFrame) -> list[str]:
    first = df.groupby("thread")["s"].min().sort_values()
    threads = list(first.index)
    if "main" in threads:
        threads.remove("main")
        threads.append("main")
    return threads


_HOVER = (
    "<b>%{customdata[0]}</b><br>"
    "%{customdata[1]} · %{customdata[2]}%{customdata[6]}<br>"
    "%{y} · %{customdata[3]} → %{customdata[4]} · <b>%{customdata[5]}</b>"
    "<extra></extra>"
)


def _palette(n: int) -> list[str]:
    seq = (
        pcolors.qualitative.Plotly
        + pcolors.qualitative.D3
        + pcolors.qualitative.Set3
        + pcolors.qualitative.Pastel
    )
    return [seq[i % len(seq)] for i in range(n)]


def _colors_for(dim: str, cats: list[str]) -> list[str]:
    if dim == "status":
        return [STATUS_COLORS.get(c.lower(), "#888") for c in cats]
    out = []
    palette = _palette(len(cats))
    for i, cat in enumerate(cats):
        out.append("#bdbdbd" if cat == "other" else palette[i])
    return out


def _bucket_top_n(values: pd.Series, top_n: int = 12) -> pd.Series:
    """Keep the top-N most common values; everything else becomes 'other'."""
    counts = values.value_counts()
    if len(counts) <= top_n:
        return values
    keep = set(counts.head(top_n).index)
    return values.where(values.isin(keep), "other")


def _build_chart(df: pd.DataFrame, has_manifest: bool) -> tuple[go.Figure, dict, dict]:
    wall = (df["e"].max() - df["s"].min()).total_seconds()
    n_threads = df["thread"].nunique()

    dims: list[tuple[str, str]] = [
        ("type", "type (model · test · op)"),
        ("status", "status"),
        ("prefix1", "name prefix (1)"),
        ("prefix2", "name prefix (2)"),
    ]
    if has_manifest:
        dims += [
            ("folder", "folder (top)"),
            ("folder2", "folder (path)"),
            ("materialization", "materialization"),
        ]

    df = df.copy()
    if has_manifest:
        df["extra"] = " · " + df["folder2"].astype(str) + " · " + df["materialization"].astype(str)
    else:
        df["extra"] = ""

    # bucket high-cardinality dimensions so the legend stays readable
    for dk, _ in dims:
        df[dk] = _bucket_top_n(df[dk].astype(str).fillna("—"), top_n=12)

    order = _thread_order(df)

    fig = go.Figure()
    dim_trace_idx: dict[str, list[int]] = {}
    for di, (dim_key, _) in enumerate(dims):
        cats = sorted(df[dim_key].astype(str).fillna("—").unique())
        colors = _colors_for(dim_key, cats)
        idxs = []
        for cat, color in zip(cats, colors):
            sub = df[df[dim_key].astype(str) == cat]
            customdata = sub[["uid", "type", "status", "start_str",
                              "end_str", "duration_str", "extra"]].to_numpy()
            fig.add_trace(go.Bar(
                base=sub["s"],
                x=(sub["e"] - sub["s"]).dt.total_seconds() * 1000,
                y=sub["thread"],
                orientation="h",
                name=cat,
                marker=dict(color=color, line=dict(width=0)),
                customdata=customdata,
                hovertemplate=_HOVER,
                visible=(di == 0),
                legendgroup=dim_key,
            ))
            idxs.append(len(fig.data) - 1)
        dim_trace_idx[dim_key] = idxs

    title = (
        f"<b>dbt run timeline</b> – "
        f"<b>{len(df)} nodes</b>, ran <b>{_fmt_dur(wall)}</b> "
    )
    fig.update_layout(
        title=dict(text=title),
        barmode="overlay",
        bargap=0.25,
        xaxis=dict(type="date", title=None, showgrid=True, gridcolor="#eee"),
        yaxis=dict(
            title=None,
            categoryorder="array",
            categoryarray=list(reversed(order)),
            showgrid=False,
        ),
        legend=dict(title="", orientation="v", yanchor="top", y=1, xanchor="left", x=1.01),
        margin=dict(l=80, r=200, t=80, b=40),
        plot_bgcolor="white",
        paper_bgcolor="white",
        height=max(380, 90 * (n_threads + 1)),
    )
    dim_labels = {k: lbl for k, lbl in dims}
    return fig, dim_trace_idx, dim_labels


_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>{title}</title>
<style>
  html, body {{ margin: 0; padding: 0; background: #fff; color: #222;
    font: 14px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }}
  .dvt-toolbar {{ display: flex; align-items: center; gap: 10px;
    padding: 14px 22px 4px; }}
  .dvt-toolbar label {{ color: #777; font-size: 12px; letter-spacing: .02em; }}
  .dvt-toolbar select {{ font: 13px inherit; padding: 4px 28px 4px 10px;
    border: 1px solid #d0d0d0; border-radius: 4px; background: #fff; cursor: pointer; }}
  .dvt-toolbar select:hover {{ border-color: #999; }}
  .dvt-chart {{ padding: 0 8px; }}
  .dvt-table-wrap {{ padding: 16px 22px 56px; overflow-x: auto; }}
  .dvt-table-title {{ margin: 0 0 8px; font-size: 14px; font-weight: 600; color: #444; }}
  .dvt-table-title small {{ font-weight: 400; color: #888; }}
  .dvt-table {{ border-collapse: collapse; font-size: 12.5px; }}
  .dvt-table th, .dvt-table td {{ padding: 6px 12px; border-bottom: 1px solid #eee;
    text-align: left; vertical-align: top; white-space: nowrap; }}
  .dvt-table th {{ color: #666; font-weight: 600; background: #fafafa;
    position: sticky; top: 0; user-select: none; }}
  .dvt-table th[data-sort] {{ cursor: pointer; }}
  .dvt-table th[data-sort]:hover {{ background: #f0f0f0; }}
  .dvt-table th[data-dir="asc"]::after {{ content: " ▲"; color: #999; }}
  .dvt-table th[data-dir="desc"]::after {{ content: " ▼"; color: #999; }}
  .dvt-table td.num, .dvt-table th.num {{ text-align: right;
    font-variant-numeric: tabular-nums; }}
  .dvt-table td.name {{ font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 12px; max-width: 360px; overflow: hidden; text-overflow: ellipsis; }}
  .dvt-table th.bar, .dvt-table td.bar {{ width: 160px; min-width: 160px; padding-right: 14px; }}
  .dvt-table .bar-track {{ background: #f2f2f2; height: 8px; border-radius: 2px;
    overflow: hidden; }}
  .dvt-table .bar-fill {{ background: #636efa; height: 100%; min-width: 1px; }}
  .dvt-table tbody tr:hover td {{ background: #fafafa; }}
  .dvt-table tbody tr.dvt-row-hl td {{ background: #fff3cd; }}
  .dvt-footer {{ position: fixed; bottom: 6px; right: 10px;
    font: 11px/1 sans-serif; color: #888; opacity: .7; }}
  .dvt-footer a {{ color: #888; }}
</style>
</head>
<body>
  <div class="dvt-toolbar">
    <label for="dvt-color-by">color by</label>
    <select id="dvt-color-by">{options}</select>
  </div>
  <div class="dvt-chart">{plot_div}</div>
  {table_html}
  <div class="dvt-footer">generated by <a href="https://github.com/pif/dvt" target="_blank" rel="noopener">dvt</a></div>
  <script>
  (function() {{
    var VIS = {vis_map};
    var sel = document.getElementById('dvt-color-by');
    sel.addEventListener('change', function(e) {{
      Plotly.restyle('{div_id}', {{visible: VIS[e.target.value]}});
    }});
    document.querySelectorAll('.dvt-table th[data-sort]').forEach(function(th) {{
      th.addEventListener('click', function() {{
        var idx = parseInt(th.dataset.sort, 10);
        var tbl = th.closest('table');
        var tbody = tbl.querySelector('tbody');
        var rows = Array.from(tbody.querySelectorAll('tr'));
        var asc = th.dataset.dir !== 'asc';
        th.parentNode.querySelectorAll('th').forEach(function(x) {{ x.dataset.dir = ''; }});
        th.dataset.dir = asc ? 'asc' : 'desc';
        rows.sort(function(a, b) {{
          var av = a.cells[idx].dataset.v != null ? a.cells[idx].dataset.v : a.cells[idx].textContent;
          var bv = b.cells[idx].dataset.v != null ? b.cells[idx].dataset.v : b.cells[idx].textContent;
          var an = parseFloat(av), bn = parseFloat(bv);
          if (!isNaN(an) && !isNaN(bn)) return (an - bn) * (asc ? 1 : -1);
          return String(av).localeCompare(String(bv)) * (asc ? 1 : -1);
        }});
        rows.forEach(function(r) {{ tbody.appendChild(r); }});
      }});
    }});
  }})();
  </script>
</body>
</html>
"""


def _table_html(df: pd.DataFrame, has_manifest: bool) -> str:
    df = df.sort_values("duration", ascending=False).reset_index(drop=True)
    max_dur = float(df["duration"].max()) if not df.empty else 1.0
    if max_dur <= 0:
        max_dur = 1.0
    headers: list[tuple[str, str, bool]] = [
        ("#", "num", False),
        ("name", "name", True),
        ("type", "", True),
        ("status", "", True),
        ("thread", "", True),
        ("started", "num", True),
        ("duration", "num", True),
        ("", "bar", False),
    ]
    if has_manifest:
        headers += [("folder", "", True), ("materialization", "", True)]

    th_html = []
    for i, (label, cls, sortable) in enumerate(headers):
        attrs = f' class="{cls}"' if cls else ""
        if sortable:
            attrs += f' data-sort="{i}"'
        if label == "duration":
            attrs += ' data-dir="desc"'
        th_html.append(f"<th{attrs}>{label}</th>")

    row_html = []
    for i, r in df.iterrows():
        esc_name = htmllib.escape(r["name"])
        pct = (r["duration"] / max_dur) * 100
        cells = [
            f'<td class="num">{i + 1}</td>',
            f'<td class="name" title="{htmllib.escape(r["uid"])}">{esc_name}</td>',
            f'<td>{htmllib.escape(r["type"])}</td>',
            f'<td>{htmllib.escape(r["status"])}</td>',
            f'<td>{htmllib.escape(r["thread"])}</td>',
            f'<td class="num" data-v="{r["s"].timestamp():.0f}">{r["start_str"]}</td>',
            f'<td class="num" data-v="{r["duration"]:.6f}">{r["duration_str"]}</td>',
            f'<td class="bar"><div class="bar-track">'
            f'<div class="bar-fill" style="width:{pct:.2f}%"></div></div></td>',
        ]
        if has_manifest:
            cells.append(f'<td>{htmllib.escape(str(r["folder2"]))}</td>')
            cells.append(f'<td>{htmllib.escape(str(r["materialization"]))}</td>')
        row_html.append(f"<tr>{''.join(cells)}</tr>")

    return (
        '<div class="dvt-table-wrap">'
        f'<div class="dvt-table-title">{len(df)} nodes <small>· sorted by duration · click any header to re-sort</small></div>'
        '<table class="dvt-table">'
        f'<thead><tr>{"".join(th_html)}</tr></thead>'
        f'<tbody>{"".join(row_html)}</tbody>'
        '</table>'
        '</div>'
    )


def _wrap_html(
    fig: go.Figure,
    doc_title: str,
    dim_indices: dict,
    dim_labels: dict,
    df: pd.DataFrame,
    has_manifest: bool,
    *,
    static: bool,
) -> str:
    div_id = "dvt-chart-div"
    plot_div = pio.to_html(
        fig,
        full_html=False,
        include_plotlyjs=True if static else "cdn",
        div_id=div_id,
        config={"responsive": True, "displaylogo": False},
    )
    n = sum(len(idxs) for idxs in dim_indices.values())
    vis_map = {}
    for key, idxs in dim_indices.items():
        v = [False] * n
        for i in idxs:
            v[i] = True
        vis_map[key] = v
    options = "".join(
        f'<option value="{htmllib.escape(k)}">{htmllib.escape(label)}</option>'
        for k, label in dim_labels.items()
    )
    return _PAGE.format(
        title=htmllib.escape(doc_title),
        options=options,
        plot_div=plot_div,
        table_html=_table_html(df, has_manifest),
        vis_map=json.dumps(vis_map),
        div_id=div_id,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="dvt",
        description="dbt Visualisation Tool — render dbt run timings as a Gantt chart.",
    )
    parser.add_argument(
        "-i", "--input", default="target/run_results.json",
        help="path to dbt's run_results.json (default: %(default)s)",
    )
    parser.add_argument(
        "-m", "--manifest", default=None,
        help="path to dbt's manifest.json (optional; unlocks folder/materialization color modes)",
    )
    parser.add_argument(
        "-o", "--output", default="target/run_results_timeline.html",
        help="path to write the HTML timeline (default: %(default)s)",
    )
    parser.add_argument(
        "--no-open", action="store_true",
        help="don't open the chart in a browser after writing",
    )
    parser.add_argument(
        "--static", action="store_true",
        help="produce a single self-contained HTML with plotly.js embedded "
             "(default loads it from a CDN; ~200KB → ~5MB)",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    args = parser.parse_args(argv)

    input_path = Path(args.input)
    if not input_path.exists():
        parser.error(f"{input_path} not found — run `dbt run` first, or pass --input.")
    manifest_path = Path(args.manifest) if args.manifest else None
    if manifest_path and not manifest_path.exists():
        parser.error(f"{manifest_path} not found")

    df, has_manifest = _load(input_path, manifest_path)
    if df.empty:
        parser.error("no model execute timings found in run_results.json.")

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig, dim_indices, dim_labels = _build_chart(df, has_manifest)
    output_path.write_text(
        _wrap_html(
            fig, "dvt = dbt run timeline",
            dim_indices, dim_labels, df, has_manifest,
            static=args.static,
        ),
        encoding="utf-8",
    )
    print(f"timeline written to {output_path}")

    if not args.no_open:
        webbrowser.open(output_path.resolve().as_uri())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
