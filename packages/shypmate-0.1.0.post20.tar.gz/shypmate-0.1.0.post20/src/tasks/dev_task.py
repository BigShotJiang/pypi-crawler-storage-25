"""
Task prompt builder for dev agent runs.
"""

import json
import os
from datetime import datetime, timezone

from shypmate.config.project import PROJECT


def _build_metadata_json(task_description: str, branch_name: str) -> str:
    """Build the JSON metadata string the agent should embed in the PR body."""
    meta = {
        "task": task_description,
        "agent_id": os.environ.get("AGENT_ID", "unknown"),
        "branch": branch_name,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "rebase_count": int(os.environ.get("AGENT_REBASE_COUNT", "0")),
    }
    return json.dumps(meta)


def build_task_prompt(
    task_description: str,
    branch_name: str,
    is_rebase: bool = False,
) -> str:
    """Build the task prompt for the dev agent.

    Args:
        task_description: Human description of what to build/fix.
        branch_name: The git branch this work should be on.
        is_rebase: Whether this is a rebase/conflict-resolution run.

    Returns:
        The full task prompt string.
    """

    if is_rebase:
        return f"""You are re-running on branch '{branch_name}' because master has advanced.

Your job:
1. Fetch the latest from origin.
2. Rebase your branch onto origin/{PROJECT.base_branch}.
3. Resolve any merge conflicts. For simple conflicts (different parts of file, import ordering,
   migration numbering), resolve them automatically. For semantic conflicts in the same
   function/method, or contradictory changes, mark the PR as needing human review.
4. Re-run validation: ruff check --fix and ruff format.
5. Force-push the updated branch.
6. Comment on the PR explaining what changed during the rebase.

Original task for context:
{task_description}
"""

    validation_steps = "\n".join(
        f"   - `{cmd}` ({desc})" for cmd, desc in PROJECT.validation_commands
    )
    return f"""TASK: {task_description}

BRANCH: You are already on branch '{branch_name}'. Do NOT create or checkout a branch — it's done.
BASE: origin/{PROJECT.base_branch}

STEPS:
1. Call recall() to check shared agent memory for lessons from past agent runs.
   Then use search_issues to check for related GitHub issues.
   These are TWO calls maximum — do not search repeatedly.
2. Break the task into logical sub-parts if it contains multiple items.
3. For EACH sub-part:
   a. Implement the change. Only read files you need to modify.
   b. Run run_ruff_check() — it only checks your new files.
   c. Fix only linting issues in YOUR new code. Ignore pre-existing issues.
   d. Commit with a clear message describing WHAT and WHY for that specific change.
   Do NOT bundle unrelated changes into one commit.
4. Do NOT run run_ruff_format(). It reformats entire files and creates noise.
5. After all commits, push: git_push(branch_name="{branch_name}")
6. Create a PR with create_pull_request:
   - Title prefixed with '{PROJECT.pr_title_prefix}'
   - Body: summary of all changes with a section per commit
   - If you found relevant issues, reference them in the PR body (e.g., "Relates to #23")
   - metadata parameter: {_build_metadata_json(task_description, branch_name)}
7. After PR is created, use comment_on_pr to add review comments explaining
   key decisions, tradeoffs, or anything the reviewer should pay attention to.

COMMIT GUIDELINES:
- One logical change per commit. "Add model + add API endpoint + add tests" = 3 commits.
- If the task is a single focused change, one commit is fine.
- Commit messages: short subject line, then blank line, then "why" explanation.
- Example: "Add pagination to /api/products/\\n\\nPreviously returned all rows which caused timeouts on large datasets."

RULES:
- Do NOT explore the repo or read files out of curiosity.
- Do NOT create or checkout branches — you're already on the right one.
- Your diff must ONLY contain changes for this task. ZERO formatting-only changes.
- Do NOT reformat, restyle, or clean up existing code. Touch ONLY what the task requires.
- If the task explicitly asks for cleanup/formatting, pass all_files=True to ruff tools.

MEMORY:
- After completing the task, use remember() to save anything useful for future agents:
  gotchas, patterns you discovered, decisions you made, or mistakes you corrected.
- Use forget() if you find an existing memory that is wrong or outdated.
- Be selective — only save things that are NOT already in the project docs.
"""
