# Shypmate Roadmap

This file tracks planned features, architectural decisions, and future work. Claude agents should reference this file to understand what's coming and avoid implementing things that conflict with planned directions.

---

## Competitive Positioning

### Shypmate vs GitHub Copilot Coding Agent

GitHub Copilot's coding agent (GA as of 2026) offers a similar workflow: assign a GitHub issue to Copilot, it works autonomously in an isolated environment, and opens a PR. Shypmate's value is **not** in replicating that basic flow — it's in the areas Copilot can't reach.

#### Where Shypmate stands out

| Capability | Copilot Coding Agent | Shypmate |
|---|---|---|
| **LLM provider** | GitHub/OpenAI only | Any provider — Anthropic, OpenAI, Groq, Ollama, local models, any OpenAI-compatible endpoint |
| **Infrastructure access** | GitHub's cloud VMs, no access to your services | Agents run in your Docker containers on your Docker network — they can reach your DB, Redis, queues, etc. |
| **Customization** | Black box — GitHub controls the agent behavior | Full control over tools, system prompts, sandboxing rules, validation commands, shell allowlists |
| **Tool ecosystem** | Fixed toolset | Extensible tool registry — add custom tools per project or agent type |
| **Human-in-the-loop** | PR review only (after agent finishes) | Mid-task escalation via `request_human_input` — agent can ask questions while working |
| **Task planning** | One issue = one independent agent | Manager analyzes all tasks, detects dependencies, and orchestrates in waves — parallel where safe, sequential where needed |
| **Validation** | Copilot's environment | Your ruff, pytest, your CI pipeline, your custom validation commands |
| **Data sovereignty** | Code processed on GitHub/Microsoft infrastructure | Fully self-hosted — code never leaves your machines (except LLM API calls to your chosen provider) |
| **Cost model** | Copilot subscription (per seat) | Your choice of LLM provider pricing — use cheap models for simple tasks, expensive ones for complex work |
| **Shared services** | No access | Agents attach to project's Docker network with configurable safety rules (read-only access, blocklists) |
| **Multi-provider** | No | LLM pool with round-robin or custom selection — mix providers per task type |

#### What Copilot does better (today)

- Zero setup — just assign an issue, no Docker/config needed
- Native GitHub integration — no separate CLI or config files
- Jira integration (as of March 2026)
- Backed by GitHub's infrastructure team for reliability/scaling

#### Strategic direction

Shypmate should embrace GitHub Issues as a task source (see planned feature below) to match Copilot's DX while retaining all the advantages above. The goal is: **same ease of use, but you own the agent, the infrastructure, and the provider choice.**

---

## Planned Features

### GitHub Issues as Task Source

**Status:** Planned
**Priority:** High
**Context:** Currently tasks live in `shypmate_tasks.yml`. GitHub Issues are a natural replacement — teams already use them, they have labels/assignees/milestones, and PRs link to them natively.

**Design:**
- `shypmate work` fetches open issues with a configurable label (e.g. `shypmate`, `ai-task`)
- Priority mapped from labels: `shypmate:critical`, `shypmate:high`, `shypmate:normal`, `shypmate:low`
- Agent is "assigned" to the issue when it starts (visible in GitHub UI)
- Agent comments progress on the issue as it works
- PR uses `closes #123` to auto-close the issue on merge
- `request_human_input` becomes a comment on the issue — human replies as a comment, agent polls for new comments
- GitHub's existing notification system (email, mobile app) provides free push notifications

**What this replaces:**
- `shypmate_tasks.yml` becomes optional (local-only fallback or cache)
- `task_manager.py` CRUD wraps GitHub API calls instead of YAML file ops
- Custom SaaS notification backend may not be needed for v1 — GitHub notifications already work on mobile

**Configuration in `shypmate.yml`:**
```yaml
tasks:
  source: github_issues          # or "local" for shypmate_tasks.yml
  label: shypmate                # issues with this label are eligible
  priority_labels:               # maps labels to priority
    shypmate:critical: critical
    shypmate:high: high
    shypmate:normal: normal
    shypmate:low: low
  auto_assign: true              # assign agent to issue when started
  comment_progress: true         # agent comments on issue during work
```

---

### Intelligent Wave Planning (Task Dependency Analysis)

**Status:** Planned
**Priority:** Critical
**Context:** When multiple tasks are queued, the manager must decide what can run in parallel vs what must be sequential. This is especially important for greenfield projects where tasks build on each other. Developers should not have to think about ordering — the manager figures it out.

**How it works:**

When `shypmate start` runs (or new tasks are added), the manager makes one LLM call to analyze all pending tasks against the current repo state and produces a wave plan:

```
Manager receives 5 tasks for a new project:
  1. "Set up FastAPI project with pyproject.toml and health endpoint"
  2. "Add user model with SQLAlchemy + migrations"
  3. "Add JWT authentication endpoints"
  4. "Add CRUD endpoints for products"
  5. "Add Dockerfile and docker-compose"

Manager analyzes → produces:

  Wave 1: [Task 1]              ← foundation, must go first
  Wave 2: [Task 2, Task 5]      ← independent of each other, both need wave 1
  Wave 3: [Task 3]              ← needs user model from task 2
  Wave 4: [Task 4]              ← needs auth + models from wave 2-3
```

For a mature codebase with independent features:
```
  Wave 1: [Task 1, Task 2, Task 3, Task 4]   ← all independent, launch in parallel
```

**Execution loop:**

```
Manager starts
    │
    ├─ Build project brief (existing)
    ├─ Analyze ALL pending tasks → wave plan (one LLM call)
    ├─ Launch Wave 1 (parallel agents)
    │
    └─ Continuous loop:
         ├─ Monitor running agents
         ├─ Monitor PRs for merges
         │
         ├─ New task added to queue?
         │     └─ Re-analyze against current wave plan
         │           ├─ Independent of everything → slot into current wave, launch now
         │           ├─ Depends on running wave → slot into next wave, wait
         │           └─ Critical priority → launch immediately regardless
         │
         ├─ Wave complete + PRs merged?
         │     └─ Re-analyze remaining tasks against updated repo
         │        (repo now has previous wave's code — context changed)
         │     └─ Launch next wave
         │
         ├─ Agent failed or PR rejected?
         │     └─ Re-analyze, possibly re-plan remaining waves
         │
         └─ All waves done, no pending tasks → idle (keep watching for new tasks)
```

**Re-analysis after each wave is critical.** The repo changes after merges. What looked like a dependency before might not be one anymore. The manager adapts the plan as the codebase evolves — it's not locked into the original plan.

**New task handling (mid-run):**

| Scenario | Manager does |
|---|---|
| New task, no dependencies on anything in flight | Add to current wave, launch immediately |
| New task, depends on running wave | Slot into next wave, wait |
| New task, `critical` priority | Launch immediately regardless |
| Task added while idle (all waves done) | Single-task wave, launch immediately |
| PR rejected / agent fails | Re-analyze, possibly re-plan remaining waves |

**Interaction with `run-agent`:**

`run-agent` bypasses the manager entirely — no queue, no wave planning, no dependencies. It branches from current `main` and works. This is intentional. If a `run-agent` task conflicts with a managed wave, the PR monitor handles rebasing later.

| Command | Planning | Queue | Waves |
|---|---|---|---|
| `shypmate start` + `work` | Manager plans | Yes | Yes |
| `shypmate run-agent` | None | No | No |

**Dashboard visualization:**
```
Wave Plan (5 tasks)
  Wave 1  ████████████ DONE     Set up FastAPI project
  Wave 2  ██████░░░░░░ RUNNING  Add user model | Add Dockerfile
  Wave 3  ░░░░░░░░░░░░ WAITING  Add JWT auth
  Wave 4  ░░░░░░░░░░░░ WAITING  Add CRUD for products
```

**Configuration in `shypmate.yml`:**
```yaml
tasks:
  execution: auto          # default — manager decides wave ordering
  # execution: parallel    # force all parallel (I know what I'm doing)
  # execution: sequential  # force one at a time
```

**Or in `shypmate.py`:**
```python
def task_execution():
    return "auto"  # or "parallel" or "sequential"
```

**Key design decisions:**
- Wave planning is one LLM call per analysis (cheap, runs on manager)
- Re-analyze after each wave completes, not locked to original plan
- PRs must be merged (human-reviewed) before next wave — this is the safety gate
- Developer never manually specifies dependencies — manager figures it out
- `critical` priority tasks bypass wave ordering and launch immediately
- `run-agent` is unaffected — stays as the direct, no-planning path
- Future: if auto-merge is enabled, waves can chain without human intervention

**Implementation approach:**
1. Add `WavePlan` dataclass: list of waves, each wave is a list of task IDs
2. Add `plan_waves()` function in manager: one LLM call, returns `WavePlan`
3. Add wave state tracking to manager loop (current wave, completed waves)
4. Add new-task detection to manager loop (poll task queue for additions)
5. Add re-analysis trigger after wave completion or new task addition
6. Update dashboard to show wave progress

---

### Escalation Triage via Claude CLI (`claude -p`)

**Status:** Planned
**Priority:** High
**Context:** The `request_human_input` tool and `shypmate inbox`/`shypmate respond` commands already provide file-based human-in-the-loop communication via `/comms/requests/` and `/comms/responses/`. This feature adds an AI triage layer before bothering the human.

**Design:**
- When an agent writes a question to `/comms/requests/`, the host-side watcher runs it through `claude --bare -p` first
- If Claude can answer confidently, it writes directly to `/comms/responses/` (no human needed)
- If Claude determines a human is needed, it escalates via the configured channel
- Uses the user's Claude subscription (not API credits) for cost efficiency
- Must include retry/backoff for subscription rate limits

**Architecture:**
```
Agent calls request_human_input → writes /comms/requests/{id}.json
    ↓
Host watcher detects new request
    ↓
claude --bare -p (triage on subscription)
    ├─ Can answer → write /comms/responses/{id}.json (done)
    └─ Needs human → escalate via terminal or SaaS
```

**Key decisions:**
- Claude CLI is not suitable as a drop-in replacement for the API provider in the agent loop — it manages its own tool loop and doesn't expose raw tool_use blocks
- CLI is best used for host-side orchestration (triage, PR review, task planning), not container-side agent work
- The API remains the correct choice for the container agent loop because it's provider-agnostic (Anthropic, OpenAI, Groq, Ollama, etc.)

---

### SaaS Backend for Remote Escalation

**Status:** Planned (not started)
**Priority:** Medium
**Context:** Currently, human responses only come via the terminal (`shypmate inbox`/`shypmate respond` or `--no-detach` interactive mode). This feature adds a remote notification channel.

**Design:**
- Host-side watcher POSTs question to a SaaS backend API when a human is needed
- Backend sends push notification to mobile app
- Human responds on mobile app
- Backend receives response, calls webhook or writes to `/comms/responses/`
- Same file-based protocol — the agent doesn't know or care which channel answered

**Components needed:**
- SaaS backend API (not started)
- Mobile app (not started)
- Host-side SaaS responder (new module alongside terminal responder)
- Configuration in `shypmate.yml` for escalation channel routing

---

### Escalation Channel Routing

**Status:** Planned
**Priority:** Medium
**Depends on:** SaaS Backend, CLI Triage

**Design:**
- Configurable escalation pipeline in `shypmate.yml`:
```yaml
escalation:
  channels:
    - type: cli_triage    # Try Claude CLI first
      enabled: true
    - type: terminal      # Fall back to terminal prompt
      enabled: true
    - type: saas          # Or push to SaaS/mobile
      enabled: false
      endpoint: https://api.shypmate.com/escalations
  timeout: 3600           # Max seconds to wait for response
```
- Channels are tried in order; first successful response wins
- Timeout handling (currently agents wait indefinitely)

---

### Agent Hats & Task Pipeline

**Status:** Planned
**Priority:** High
**Context:** Currently one agent type (developer) does everything: code, validate, PR. The "hats" system introduces specialized agent roles that form a pipeline per task. Each hat has its own personality, tools, expertise, and quota.

**Core concept:**
```
Task assigned
    ↓
Developer Hat → writes code, commits to branch (NO PR yet)
    ↓
QA Hat → runs tests, checks coverage, security scan on the branch
    ├─ FAIL → Developer Hat re-spawned with failure details
    └─ PASS ↓
Product Owner Hat → reviews changes against requirements
    ├─ REJECT → Developer Hat re-spawned with feedback
    └─ APPROVE → PR opened
```

**Built-in hats:**

| Hat | Personality | Tools | Responsibility |
|-----|-------------|-------|----------------|
| `developer` | Senior dev, writes clean code | file, git, shell, memory | Implement task, commit, push |
| `qa` | QA engineer, finds bugs | shell (test runners), git (read), file (read) | Run tests, coverage, security, report pass/fail |
| `product_owner` | Product manager, cares about requirements | file (read), git (read), github (comment) | Review against acceptance criteria, approve/reject |

**Custom hats:** Users can define their own hats in `shypmate.yml` or `shypmate.py`:

```yaml
hats:
  developer:
    enabled: true
    # Built-in — uses default prompt + tools
  qa:
    enabled: true
    validation_commands:
      - command: "pytest --tb=short -q"
        description: "Run tests"
      - command: "pytest --cov --cov-fail-under=80"
        description: "Check coverage"
  product_owner:
    enabled: false  # skip PO review for this project
  security_reviewer:
    prompt: "You are a security engineer. Review code for OWASP top 10 vulnerabilities."
    tools: [read_file, search_files, comment_on_pr]
    position: after_qa  # runs after QA, before PO
```

Or dynamically in `shypmate.py`:
```python
def hats():
    return {
        "developer": {"enabled": True},
        "qa": {"enabled": True},
        "devops": {
            "prompt": "You are a DevOps engineer. Review Dockerfile and CI changes.",
            "tools": ["read_file", "search_files", "run_shell_command"],
            "trigger": lambda task: "docker" in task.lower() or "ci" in task.lower(),
        },
    }
```

**Smart routing:** Instead of a fixed pipeline, agents can route tasks to the next hat based on content:
- Developer finishes → looks at what changed → if tests exist, route to QA; if infra changed, route to DevOps
- QA fails → route back to Developer with failure details
- Task description says "review only" → skip Developer, go straight to PO

**Pipeline visualization:**
```
$ shypmate task list

  PRI  ID                     HAT          STATUS     DESCRIPTION
  !!   add-pagination         developer    RUNNING    Add pagination to /api/products
   .   fix-auth-bug           qa           TESTING    Fix auth token refresh
   .   update-readme          product_owner REVIEWING Update API documentation
   -   add-logging            developer    DONE→QA    Add structured logging
```

`shypmate dashboard` would show the pipeline stages with containers:
```
Pipeline: add-pagination
  [developer] ████████████ DONE (3 commits)
  [qa]        ██████░░░░░░ RUNNING (pytest...)
  [po]        ░░░░░░░░░░░░ WAITING
```

**Implementation approach:**
1. `Hat` dataclass: name, prompt, tools, quota, trigger function
2. `Pipeline` config: ordered list of hats per task
3. Pipeline coordinator: launches next hat when previous passes
4. Each hat runs as its own container on the same branch
5. Pass/fail communicated via files on shared volume or container exit codes

**Key design decisions:**
- Each hat gets its own container (isolation, different tool access)
- All hats work on the same branch (developer commits, QA tests those commits)
- PR is only opened after the pipeline completes successfully
- Failed stages loop back with context about what failed
- The developer can configure which hats are active per project

---

### Git Forge Abstraction (GitHub, GitLab, Bitbucket)

**Status:** Planned
**Priority:** High
**Context:** Git is a hard requirement — shypmate will not proceed without it. Currently the platform-specific code (PRs, issues, comments) is GitHub-only via `tools/github_tools.py` and `PyGithub`. This feature abstracts the hosting layer so agents can work with any major git forge.

**Supported forges (planned):**

| Platform | PR concept | Issues | Auth | Priority |
|---|---|---|---|---|
| **GitHub** | Pull Requests | GitHub Issues | `GITHUB_TOKEN` (PAT) | **Already done** |
| **GitLab** | Merge Requests | GitLab Issues | `GITLAB_TOKEN` (PAT or OAuth) | **High — next** |
| **Bitbucket** | Pull Requests | Jira integration | `BITBUCKET_TOKEN` (app password) | **Medium** |
| **Azure DevOps** | Pull Requests | Work Items | `AZURE_DEVOPS_TOKEN` (PAT) | **Later** |
| **Gitea/Forgejo** | Pull Requests | Gitea Issues | `GITEA_TOKEN` (PAT) | **Nice to have** |

**What stays the same:** Everything in `git_tools.py` — clone, branch, commit, push, diff, rebase. Git operations are forge-agnostic and work unchanged against any remote.

**What gets abstracted:** The 5-6 functions in `github_tools.py` that call the GitHub API:
- `create_pull_request` → create merge request / PR
- `update_pull_request` → update MR / PR
- `comment_on_pr` → comment on MR / PR
- `list_ai_pull_requests` → list open AI MRs / PRs
- `get_pr_changed_files` → get MR / PR diff

**New file structure:**
```
tools/
├── git_tools.py            # Unchanged — works with any git remote
├── forge_tools.py          # Thin dispatch layer: calls the right forge backend
└── forges/
    ├── base.py             # Abstract interface (create_pr, comment, list_prs, etc.)
    ├── github.py           # Current github_tools.py logic (PyGithub)
    ├── gitlab.py           # GitLab API (python-gitlab)
    └── bitbucket.py        # Bitbucket API (atlassian-python-api)
```

**Auto-detection from git remote URL:**
```python
# Detect forge from remote URL pattern
"github.com"    → GitHub
"gitlab.com"    → GitLab
"bitbucket.org" → Bitbucket
"dev.azure.com" → Azure DevOps
# Self-hosted → configurable in shypmate.yml
```

**Configuration in `shypmate.yml`:**
```yaml
git:
  forge: auto              # auto-detect from remote URL (default)
  # forge: gitlab          # or override explicitly
  # forge_url: https://gitlab.mycompany.com  # self-hosted
```

**Or in `shypmate.py`:**
```python
def forge():
    return "gitlab"

def forge_url():
    return "https://gitlab.mycompany.com"
```

**Key decisions:**
- Git is a hard requirement. If the project is not a git repo, `shypmate init` should refuse to proceed (or offer to `git init`)
- Forge is auto-detected from `git remote get-url origin` — no config needed for GitHub/GitLab/Bitbucket on their public domains
- Self-hosted instances need explicit `forge_url` in config
- Token env var name changes per forge (`GITHUB_TOKEN`, `GITLAB_TOKEN`, etc.)
- GitLab is the highest priority after GitHub — large enterprise/self-hosted adoption

**GitLab API mapping (nearly 1:1):**

| Shypmate action | GitHub API | GitLab API |
|---|---|---|
| Create PR | `POST /repos/{owner}/{repo}/pulls` | `POST /projects/{id}/merge_requests` |
| Update PR | `PATCH /repos/{owner}/{repo}/pulls/{n}` | `PUT /projects/{id}/merge_requests/{iid}` |
| Comment | `POST /repos/{owner}/{repo}/issues/{n}/comments` | `POST /projects/{id}/merge_requests/{iid}/notes` |
| List PRs | `GET /repos/{owner}/{repo}/pulls?label=...` | `GET /projects/{id}/merge_requests?labels=...` |
| PR files | `GET /repos/{owner}/{repo}/pulls/{n}/files` | `GET /projects/{id}/merge_requests/{iid}/changes` |

---

### Greenfield Project Setup (Empty Repo Handling)

**Status:** Planned
**Priority:** High
**Context:** Currently shypmate fails on empty repos (no commits, no branches). A developer should be able to `pip install shypmate` in an empty directory and get going.

**Blockers to fix:**
1. **`entrypoint.py`** — after cloning an empty repo, `git checkout main` fails because no branches exist. Need to detect empty repo, create initial commit, push to default branch, then create working branch.
2. **`git_tools.py`** — `repo.head.commit` errors when there's no commit history. Handle first-commit case.
3. **`init` command** — if no `.git` exists, offer to `git init`. If no GitHub remote, offer to create the repo via GitHub API (or the configured forge).

**Ideal flow:**
```bash
mkdir my-app && cd my-app
pip install shypmate
shypmate init
# → "No git repo found. Initialize one?" [Y]
# → git init
# → "GitHub repo name?" [user/my-app]
# → Creates repo via API, adds remote, initial commit, pushes
# → Creates shypmate.yml
# → Ready

shypmate task add "Set up FastAPI project with health endpoint" -p critical
shypmate work
# → Agent starts from scratch, builds the project
```

---

## Existing Known Issues

- Agent container Dockerfile has system deps for Python/Django projects — needs to be more generic or configurable per project
- Monitor `cleanup_merged_containers` needs more testing
- No frontend/mobile agent specialization yet (v1 is backend-focused)
- No multi-agent collaboration within a single task
- No auto-merge capability
- Rate limiting on Anthropic API can slow agents significantly on low-tier plans

---

## Architecture Notes for Future Reference

### CLI vs API — When to Use Each

| Layer | Use | Why |
|---|---|---|
| **Container agent loop** | API (`providers.py`) | Provider-agnostic, returns raw tool_use blocks, supports custom tool schemas |
| **Host-side orchestration** | Claude CLI (`claude -p`) | Runs on subscription, good for planning/review/triage |
| **Escalation triage** | Claude CLI (`claude -p`) | Low volume, subscription cost, filters out trivial questions |
| **Task decomposition** | Claude CLI (`claude -p`) | Pre-launch planning, saves API credits |
| **PR review** | Claude CLI (`claude -p`) | Post-agent review before merge |

### Why Claude CLI Can't Replace the API in the Agent Loop

The agent loop sends messages + tool schemas to the LLM and receives back `tool_use` blocks indicating which custom tool to call with what arguments. The loop then dispatches those tools locally. `claude -p` is a full agent — it runs its own internal tool loop (Read, Edit, Bash) and returns final text. It doesn't expose intermediate tool_use decisions, so it can't drive a custom tool registry.

### Subscription Rate Limit Considerations

All `claude -p` calls share a single subscription quota. For escalation triage (low volume, sporadic), this is fine. For heavy workloads (all agent thinking), subscription limits would throttle quickly. The API has higher rate limits and scales with spend.
