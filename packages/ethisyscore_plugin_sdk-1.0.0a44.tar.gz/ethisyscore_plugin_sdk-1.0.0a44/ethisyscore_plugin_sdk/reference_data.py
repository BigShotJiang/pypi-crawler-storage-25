"""
Reference data L1 cache for Python container plugins.
Dict-based L1 with DataStore L2 fallback. Mirrors the .NET CachedReferenceData pattern.
"""

from __future__ import annotations

import asyncio
import json
import logging
import random
from typing import Any, Callable, Awaitable, Protocol, runtime_checkable

from .types import ReferenceDataSubscription, RefDataInvalidationSignal

logger = logging.getLogger("ethisyscore.refdata")


@runtime_checkable
class ReferenceDataProtocol(Protocol):
    """Protocol for reference data access."""

    async def get(self, entity_type: str, entity_id: str) -> dict[str, Any] | None: ...
    async def query(self, entity_type: str) -> list[dict[str, Any]]: ...
    async def get_sequence_number(self, entity_type: str) -> int: ...
    async def request_sync(self, entity_type: str) -> None: ...


class CachedReferenceData:
    """Dict-based L1 cache with DataStore L2 fallback."""

    def __init__(self, data_store: Any, plugin_logger: Any) -> None:
        self._data_store = data_store
        self._logger = plugin_logger
        self._buckets: dict[str, _L1Bucket] = {}
        self._entity_type_to_key: dict[str, str] = {}
        self._reconciliation_tasks: list[asyncio.Task[None]] = []
        self._reconciliation_cancelled = False

        # Callback for requesting a full re-sync from the platform.
        # Set by PluginHost after initialization to wire the host callback path.
        # None = log-only (no host callback available).
        self._request_sync_callback: Callable[[str], Awaitable[None]] | None = None

    async def get(self, entity_type: str, entity_id: str) -> dict[str, Any] | None:
        bucket = self._find_bucket(entity_type)
        if bucket:
            entry = bucket.entries.get(entity_id)
            if entry is not None:
                return json.loads(entry)

        # L2 fallback
        if bucket:
            try:
                key = f"_ref/{bucket.module_prefix}/{bucket.entity_type}/{entity_id}"
                value = await self._data_store.get(key)
                if value and not value.get("_deleted"):
                    bucket.entries[entity_id] = json.dumps(value)
                    return value
            except Exception as e:
                self._logger.warning(f"L2 fallback failed for {entity_type}/{entity_id}: {e}")

        return None

    async def query(self, entity_type: str) -> list[dict[str, Any]]:
        bucket = self._find_bucket(entity_type)
        if not bucket:
            return []
        if bucket.is_partial:
            raise RuntimeError(
                f"PartialDataSet: L1 cache for '{entity_type}' exceeds MaxMemoryEntries "
                f"({bucket.max_memory_entries}). Use get() for individual lookups."
            )
        return [json.loads(v) for v in bucket.entries.values()]

    async def get_sequence_number(self, entity_type: str) -> int:
        bucket = self._find_bucket(entity_type)
        return bucket.sequence_number if bucket else 0

    async def request_sync(self, entity_type: str) -> None:
        self._logger.info(f"Manual sync requested for {entity_type}")

        if self._request_sync_callback is not None:
            try:
                await self._request_sync_callback(entity_type)
            except Exception as e:
                self._logger.warning(
                    f"RequestSync callback failed for {entity_type}: {e} "
                    "-- platform 30s reconciliation will recover"
                )
        else:
            self._logger.info("No RequestSync callback wired -- relying on platform reconciliation")

    async def warm(self, subscriptions: list[ReferenceDataSubscription]) -> None:
        """Warm L1 from L2 DataStore on startup."""
        for sub in subscriptions:
            bucket_key = f"{sub.module_prefix}:{sub.entity_type}"
            # Warn on ambiguity: short entity_type already mapped to a different module
            existing_key = self._entity_type_to_key.get(sub.entity_type)
            if existing_key and existing_key != bucket_key:
                logger.warning(
                    f"Entity type '{sub.entity_type}' registered by both '{existing_key}' and "
                    f"'{bucket_key}'. Use qualified form (e.g., '{bucket_key}') to avoid ambiguity."
                )

            self._entity_type_to_key[sub.entity_type] = bucket_key

            # Reuse existing bucket if present (preserves resolved options across re-warm)
            bucket = self._buckets.get(bucket_key)
            if bucket is None:
                max_entries = sub.options.max_memory_entries if sub.options else 5_000
                reconciliation_seconds = (
                    sub.options.reconciliation_interval_seconds if sub.options else 30
                )
                bucket = _L1Bucket(
                    module_prefix=sub.module_prefix,
                    entity_type=sub.entity_type,
                    max_memory_entries=max_entries,
                    reconciliation_interval_seconds=reconciliation_seconds,
                )
            elif sub.options is not None:
                # First warm with real options sets them; subsequent re-warms keep existing
                if bucket.max_memory_entries == 5_000 and sub.options.max_memory_entries != 5_000:
                    bucket.max_memory_entries = sub.options.max_memory_entries
                if (
                    bucket.reconciliation_interval_seconds == 30
                    and sub.options.reconciliation_interval_seconds != 30
                ):
                    bucket.reconciliation_interval_seconds = (
                        sub.options.reconciliation_interval_seconds
                    )

            max_entries = bucket.max_memory_entries

            try:
                prefix = f"_ref/{sub.module_prefix}/{sub.entity_type}/"
                entries = await self._data_store.query(prefix)

                new_entries: dict[str, str] = {}
                for entry in entries:
                    key = entry.get("key", "")
                    value = entry.get("value")
                    parts = key.split("/")
                    entity_id = parts[-1] if len(parts) >= 4 else None

                    if entity_id == "_meta" or not entity_id:
                        continue
                    if value and value.get("_deleted"):
                        continue

                    new_entries[entity_id] = json.dumps(value)

                # Load meta
                meta_key = f"_ref/{sub.module_prefix}/{sub.entity_type}/_meta"
                meta = await self._data_store.get(meta_key)
                if meta:
                    bucket.sequence_number = meta.get("sequenceNumber", 0)
                    bucket.sync_token = meta.get("syncToken", "")

                # Enforce MaxMemoryEntries -- mark bucket as partial if exceeded
                if len(new_entries) > max_entries:
                    bucket.is_partial = True
                    trimmed = dict(list(new_entries.items())[:max_entries])
                    bucket.entries = trimmed
                    logger.warning(
                        f"L1 for {sub.module_prefix}/{sub.entity_type} exceeds MaxMemoryEntries "
                        f"({len(new_entries)} > {max_entries}) -- marked as partial"
                    )
                else:
                    bucket.is_partial = False
                    bucket.entries = new_entries

                self._buckets[bucket_key] = bucket
                logger.info(
                    f"Warmed L1 for {sub.module_prefix}/{sub.entity_type}: "
                    f"{len(bucket.entries)} entries (partial: {bucket.is_partial}), seq {bucket.sequence_number}"
                )
            except Exception as e:
                logger.error(f"Failed to warm L1 for {sub.module_prefix}/{sub.entity_type}: {e}")
                self._buckets[bucket_key] = bucket

    async def handle_invalidation(self, signal: RefDataInvalidationSignal) -> None:
        """Handle invalidation signal from platform."""
        bucket_key = f"{signal.module_prefix}:{signal.entity_type}"
        bucket = self._buckets.get(bucket_key)
        if not bucket:
            return

        # Monotonic guard
        if signal.sequence_number <= bucket.sequence_number:
            return

        # SyncToken mismatch
        if bucket.sync_token and bucket.sync_token != signal.sync_token:
            logger.warning(f"SyncToken mismatch for {signal.module_prefix}/{signal.entity_type}")
            await self.request_sync(signal.entity_type)
            return

        if not signal.entity_id:
            # Full re-sync -- uses bucket's resolved options (not a bare synthetic subscription)
            await self.warm([ReferenceDataSubscription(
                module_prefix=signal.module_prefix,
                entity_type=signal.entity_type,
                fields=[],
            )])
            return

        # Single entity delta
        try:
            if signal.change_type == "Deleted":
                # Delete: remove from L1
                bucket.entries.pop(signal.entity_id, None)
            elif signal.projected_fields_json:
                # Optimization: use inline payload directly -- no L2 read needed.
                # The platform broadcaster includes projected fields in single-entity signals.
                bucket.entries[signal.entity_id] = signal.projected_fields_json
            else:
                # Fallback: read from L2 DataStore (bulk signals without inline payload)
                ref_key = f"_ref/{signal.module_prefix}/{signal.entity_type}/{signal.entity_id}"
                value = await self._data_store.get(ref_key)

                if not value or value.get("_deleted"):
                    bucket.entries.pop(signal.entity_id, None)
                else:
                    bucket.entries[signal.entity_id] = json.dumps(value)

            bucket.sequence_number = signal.sequence_number
            bucket.sync_token = signal.sync_token
        except Exception as e:
            logger.error(f"Failed to refresh L1 for {signal.entity_type}/{signal.entity_id}: {e}")

    # -- Reconciliation timer --

    def start_reconciliation(self) -> None:
        """
        Start periodic reconciliation timers for all warmed entity types.
        Compares L1 sequence against L2 _meta sequence and triggers re-warm on drift.
        Timer interval from subscription options (default 30s) with +/-15% jitter.
        """
        self.stop_reconciliation()
        self._reconciliation_cancelled = False

        for bucket_key, bucket in self._buckets.items():
            task = asyncio.ensure_future(
                self._reconciliation_loop(bucket_key, bucket)
            )
            self._reconciliation_tasks.append(task)

    def stop_reconciliation(self) -> None:
        """Stop all reconciliation timers. Called on plugin shutdown."""
        self._reconciliation_cancelled = True
        for task in self._reconciliation_tasks:
            task.cancel()
        self._reconciliation_tasks.clear()

    async def _reconciliation_loop(self, bucket_key: str, bucket: _L1Bucket) -> None:
        """Periodic loop that compares L1 seq vs L2 _meta seq and re-warms on drift."""
        base_interval = bucket.reconciliation_interval_seconds

        while not self._reconciliation_cancelled:
            try:
                # +/-15% jitter to prevent thundering herd across replicas
                jitter = base_interval * 0.15 * (random.random() * 2 - 1)
                await asyncio.sleep(base_interval + jitter)

                if self._reconciliation_cancelled:
                    break

                # Parse bucket key to get module_prefix and entity_type
                parts = bucket_key.split(":", 1)
                if len(parts) != 2:
                    continue

                module_prefix, entity_type = parts
                meta_key = f"_ref/{module_prefix}/{entity_type}/_meta"

                meta = await self._data_store.get(meta_key)
                if not meta:
                    continue

                l2_seq = meta.get("sequenceNumber", 0)
                l1_seq = bucket.sequence_number

                if l1_seq != l2_seq:
                    logger.info(
                        f"Reconciliation drift detected for {bucket_key}: "
                        f"L1 seq {l1_seq} vs L2 seq {l2_seq} -- re-warming"
                    )
                    await self.warm([ReferenceDataSubscription(
                        module_prefix=module_prefix,
                        entity_type=entity_type,
                        fields=[],
                    )])
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.warning(f"Reconciliation check failed for {bucket_key}: {e}")

    def _find_bucket(self, entity_type: str) -> _L1Bucket | None:
        # Support qualified form "hr:employees" -- direct bucket lookup
        if ":" in entity_type:
            return self._buckets.get(entity_type)

        # Short form "employees" -- use the pre-built entityType -> bucketKey mapping.
        # If multiple modules register the same entityType, the last warm wins (ambiguous).
        # Callers should use qualified form when subscribing to multiple modules with overlapping names.
        bucket_key = self._entity_type_to_key.get(entity_type)
        return self._buckets.get(bucket_key) if bucket_key else None


class NullReferenceData:
    """No-op implementation for plugins without subscriptions."""

    async def get(self, entity_type: str, entity_id: str) -> None:
        return None

    async def query(self, entity_type: str) -> list:
        return []

    async def get_sequence_number(self, entity_type: str) -> int:
        return 0

    async def request_sync(self, entity_type: str) -> None:
        pass


class _L1Bucket:
    """Internal L1 cache bucket for a single entity type."""

    def __init__(
        self,
        module_prefix: str,
        entity_type: str,
        max_memory_entries: int = 5_000,
        reconciliation_interval_seconds: int = 30,
    ) -> None:
        self.module_prefix = module_prefix
        self.entity_type = entity_type
        self.entries: dict[str, str] = {}
        self.sequence_number: int = 0
        self.sync_token: str = ""
        self.is_partial: bool = False
        self.max_memory_entries: int = max_memory_entries
        self.reconciliation_interval_seconds: int = reconciliation_interval_seconds
