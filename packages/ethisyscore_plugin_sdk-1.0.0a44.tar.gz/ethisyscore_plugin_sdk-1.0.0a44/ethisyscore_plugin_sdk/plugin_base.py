"""
Abstract base class for EthisysCore container plugins.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from .types import HealthResult, PluginContext, PluginManifest, PluginNotification, ResourceResult, ToolResult


class PluginBase(ABC):
    """
    Extend this class to create a EthisysCore container plugin.

    You must implement ``manifest`` and ``on_invoke_tool`` at minimum.
    The SDK handles the HTTP server, health probes, and Dapr callback wiring.
    """

    @property
    @abstractmethod
    def manifest(self) -> PluginManifest:
        """The plugin manifest describing tools, resources, and metadata."""
        ...

    @abstractmethod
    async def on_invoke_tool(
        self, tool_name: str, args: dict, context: PluginContext
    ) -> ToolResult:
        """
        Called when a tool is invoked via MCP.

        Args:
            tool_name: The name of the tool to invoke.
            args: Parsed JSON arguments for the tool.
            context: Plugin context with data store, logger, etc.
        """
        ...

    async def on_initialize(self, context: PluginContext) -> None:
        """Called once when the plugin is initialized by the host."""

    async def on_enable(self, context: PluginContext) -> None:
        """Called when the plugin is enabled for a tenant."""

    async def on_disable(self, context: PluginContext) -> None:
        """Called when the plugin is disabled for a tenant."""

    async def on_shutdown(self, context: PluginContext) -> None:
        """
        Called when the host is shutting down the plugin permanently.
        Override to perform final cleanup (flush buffers, close connections).

        Note: Only called during explicit lifecycle operations (disable,
        uninstall, upgrade) — NOT during normal API replica shutdown.
        """

    async def on_update(
        self, from_version: str, to_version: str, context: PluginContext
    ) -> None:
        """
        Called when the plugin is upgraded from a previous version (ENT-13).
        Override to perform data migrations in the data store.

        Args:
            from_version: Previous version string.
            to_version: New version string.
            context: Plugin context with data store access.
        """

    async def on_get_resource(
        self, uri: str, context: PluginContext
    ) -> ResourceResult:
        """Called when the host requests a resource via MCP."""
        return ResourceResult(success=False, error="Resource not found")

    async def on_check_health(self) -> HealthResult:
        """Called by the host to check plugin health."""
        return HealthResult(status=0, message="Healthy")

    async def on_notification(self, notification: PluginNotification, context: PluginContext) -> None:
        """
        Called when the host sends a notification (e.g., reference data invalidation).
        Reference data signals are auto-handled by the SDK. Override for custom notification types.
        """
