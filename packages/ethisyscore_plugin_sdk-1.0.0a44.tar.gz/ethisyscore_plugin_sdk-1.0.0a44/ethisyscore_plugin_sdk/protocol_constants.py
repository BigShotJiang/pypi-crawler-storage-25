"""
Protocol constants mirroring the canonical EthisysCore.Protocol NuGet package.

Canonical C# source (ethisyscore-protocol repository):
  - EthisysCore.Protocol.Packaging.PackageConstants
  - EthisysCore.Protocol.Transport.PluginHttpRoutes
  - EthisysCore.Protocol.Transport.HostCallbackRoutes
  - EthisysCore.Protocol.Transport.ExtensionHeaders
  - EthisysCore.Protocol.ReferenceData.RequestRefDataSyncEvent

When a C# constant changes, update the corresponding entry here.
"""

# ── PackageConstants ──────────────────────────────────────────────────────────

MANIFEST_FILE_NAME: str = "feature.manifest.json"
SIGNING_PREFIX: str = "_signing/"
CONTAINER_IMAGE_ENTRY: str = "container-image.tar"
#: Base route prefix for container plugin-to-host callback endpoints.
CALLBACK_ROUTE_PREFIX: str = "/api/v1/plugin-callbacks"
#: Base path prefix for kernel SignalR hubs. Plugins must not register REST routes under this prefix.
SIGNAL_R_HUBS_PREFIX: str = "/hubs"

# ── PluginHttpRoutes ──────────────────────────────────────────────────────────

PLUGIN_ROUTE_INITIALIZE: str = "/plugin/initialize"
PLUGIN_ROUTE_ENABLE: str = "/plugin/enable"
PLUGIN_ROUTE_DISABLE: str = "/plugin/disable"
PLUGIN_ROUTE_SHUTDOWN: str = "/plugin/shutdown"
PLUGIN_ROUTE_INVOKE_TOOL: str = "/plugin/invoke-tool"
PLUGIN_ROUTE_GET_RESOURCE: str = "/plugin/get-resource"
PLUGIN_ROUTE_HEALTH: str = "/plugin/health"
PLUGIN_ROUTE_HEARTBEAT: str = "/plugin/heartbeat"
PLUGIN_ROUTE_NOTIFY: str = "/plugin/notify"
PLUGIN_ROUTE_BATCH_INVOKE_TOOL: str = "/plugin/batch-invoke-tool"
PLUGIN_ROUTE_CUSTOM_ENDPOINT_PREFIX: str = "/plugin/api"
PLUGIN_ROUTE_TASK_INVOKE_PREFIX: str = "/plugin/tasks"

# ── HostCallbackRoutes ────────────────────────────────────────────────────────

CB_DATA_GET: str = "/data/get"
CB_DATA_SET: str = "/data/set"
CB_DATA_DELETE: str = "/data/delete"
CB_DATA_EXISTS: str = "/data/exists"
CB_DATA_QUERY: str = "/data/query"
CB_DATA_LIST_KEYS: str = "/data/list-keys"
CB_DATA_SET_BATCH: str = "/data/set-batch"
CB_DATA_DELETE_BY_PREFIX: str = "/data/delete-by-prefix"
CB_DATA_STORAGE_INFO: str = "/data/storage-info"
CB_DATA_QUERY_FILTERED: str = "/data/query-filtered"
CB_DATA_COUNT: str = "/data/count"
CB_CACHE_GET: str = "/cache/get"
CB_CACHE_SET: str = "/cache/set"
CB_CACHE_INVALIDATE: str = "/cache/invalidate"
CB_CACHE_REMOVE: str = "/cache/remove"
CB_MCP_INVOKE_TOOL: str = "/mcp/invoke-tool"
CB_MCP_LIST_TOOLS: str = "/mcp/list-tools"
CB_MCP_GET_RESOURCE: str = "/mcp/get-resource"
CB_MCP_LIST_RESOURCES: str = "/mcp/list-resources"
CB_LOG: str = "/log"
CB_LOG_BATCH: str = "/log-batch"
CB_PUBLISH_EVENT: str = "/publish-event"
CB_PUBLISH_EVENT_BATCH: str = "/publish-event-batch"
CB_MCP_BATCH_INVOKE_TOOL: str = "/mcp/batch-invoke-tool"
CB_STORAGE_UPLOAD: str = "/storage/upload"
CB_STORAGE_DOWNLOAD: str = "/storage/download"
CB_STORAGE_DELETE: str = "/storage/delete"
CB_STORAGE_EXISTS: str = "/storage/exists"
CB_STORAGE_LIST: str = "/storage/list"

# ── ExtensionHeaders ──────────────────────────────────────────────────────────

HEADER_EXTENSION_ID: str = "x-extension-id"
HEADER_CALLBACK_TOKEN: str = "x-callback-token"
HEADER_DAPR_API_TOKEN: str = "dapr-api-token"
HEADER_TRACE_ID: str = "x-trace-id"
HEADER_SPAN_ID: str = "x-span-id"
HEADER_CORRELATION_ID: str = "x-correlation-id"
HEADER_ORGANISATION_ID: str = "x-organisation-id"
HEADER_TENANT_ID: str = "x-tenant-id"
HEADER_USER_ID: str = "x-user-id"

# ── RequestRefDataSyncEvent ───────────────────────────────────────────────────

REQUEST_REF_DATA_SYNC_EVENT_TYPE_NAME: str = "request-ref-data-sync"
