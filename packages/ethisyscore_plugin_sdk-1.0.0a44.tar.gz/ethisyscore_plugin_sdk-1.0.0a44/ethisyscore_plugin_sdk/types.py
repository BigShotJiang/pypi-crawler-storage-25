"""
EthisysCore Plugin SDK — Pydantic models for the HTTP plugin contract.
"""

from __future__ import annotations

from enum import IntFlag
from typing import Any, Literal, Optional, Protocol, runtime_checkable
from uuid import UUID

from pydantic import BaseModel, Field, field_validator


def normalize_uuid_string(value: str, field_name: str, *, allow_empty: bool = False) -> str:
    """Validate and normalize UUID strings to canonical lowercase form."""
    if value == "" and allow_empty:
        return value

    try:
        return str(UUID(value))
    except ValueError as exc:  # pragma: no cover - exercised through validators
        raise ValueError(f"{field_name} must be a UUID string") from exc


# ── Tool Permissions ─────────────────────────────────────────────────────────


class ToolPermission(IntFlag):
    """Permission bitmask for MCP tools and RBAC.

    Matches the host platform's PermissionMask enum.
    Combine with bitwise OR: ``ToolPermission.View | ToolPermission.Read``.
    """

    NONE = 0
    ASSIGN = 1
    VIEW = 2
    DELETE = 4
    WRITE = 8
    READ = 16
    APPROVE = 32
    PUBLISH_GLOBAL = 64

    # --- Composite Masks ---
    READER_ACCESS = VIEW | READ              # 18
    CONTRIBUTOR_ACCESS = VIEW | WRITE | READ  # 26
    OWNER_ACCESS = ASSIGN | VIEW | DELETE | WRITE | READ | APPROVE | PUBLISH_GLOBAL  # 127


# ── Plugin Manifest ───────────────────────────────────────────────────────────


class McpToolDefinition(BaseModel):
    name: str
    description: str
    input_schema_json: str = Field(alias="inputSchemaJson", default="{}")
    required_permission: Optional[int] = Field(
        alias="requiredPermission",
        default=None,
        description=(
            "Permission required to invoke this tool. Mirrors the backend ToolPermission enum. "
            "Use ToolPermission constants. Defaults to Write (8) when omitted."
        ),
    )


class McpResourceDefinition(BaseModel):
    uri: str
    name: str
    description: str
    mime_type: str | None = Field(alias="mimeType", default=None)


PluginType = Literal["CORE", "PLATFORM_APP", "TENANT_APP"]


# ── UI Contributions ─────────────────────────────────────────────────────────


class UiNavigationItem(BaseModel):
    """A navigation item within a plugin's sidebar section."""
    id: str
    label: str
    order: int = 0
    path: str | None = None
    required_permission: int | None = Field(alias="requiredPermission", default=None)
    initial_visibility: bool = Field(alias="initialVisibility", default=True)
    permanent: bool = False
    children: list["UiNavigationItem"] | None = None

    model_config = {"populate_by_name": True}


class UiNavigationContribution(BaseModel):
    """Hierarchical navigation section contributed to the host sidebar."""
    id: str
    label: str
    icon: str
    location: str
    order: int = 0
    children: list[UiNavigationItem] | None = None

    model_config = {"populate_by_name": True}


class UiPageContribution(BaseModel):
    """Full-page application rendered in a sandboxed iframe."""
    id: str
    route: str
    title: str
    entrypoint: str
    bridge_version: str | None = Field(alias="bridgeVersion", default=None)
    token_version: str | None = Field(alias="tokenVersion", default=None)

    model_config = {"populate_by_name": True}


class UiWidgetContribution(BaseModel):
    """Dashboard widget rendered via server-driven UI."""
    id: str
    type: str
    title: str
    resource_uri: str = Field(alias="resourceUri")

    model_config = {"populate_by_name": True}


class UiSurfaceContribution(BaseModel):
    """Pluggable UI surface such as a dialog or panel."""
    id: str
    type: str
    title: str
    entrypoint: str

    model_config = {"populate_by_name": True}


class UiConfigContribution(BaseModel):
    """JSON Schema-driven configuration form for the extension."""
    schema_uri: str = Field(alias="schemaUri")
    entrypoint: str | None = None

    model_config = {"populate_by_name": True}


class UiContributions(BaseModel):
    """UI contributions declared by an extension in the packaged feature manifest."""
    navigation: UiNavigationContribution | None = None
    pages: list[UiPageContribution] | None = None
    widgets: list[UiWidgetContribution] | None = None
    surfaces: list[UiSurfaceContribution] | None = None
    config: UiConfigContribution | None = None
    token_version: str | None = Field(alias="tokenVersion", default=None)
    bridge_version: str | None = Field(alias="bridgeVersion", default=None)

    model_config = {"populate_by_name": True}


class PluginManifest(BaseModel):
    id: str
    name: str
    version: str
    type: PluginType
    owner: str
    compatible_core_version: str = Field(alias="compatibleCoreVersion")
    mcp_version: str = Field(alias="mcpVersion")
    execution_mode: str = Field(alias="executionMode", default="Container")
    group_code: str | None = Field(alias="groupCode", default=None)
    container_image_uri: str | None = Field(alias="containerImageUri", default=None)
    mcp_tools: list[McpToolDefinition] = Field(alias="mcpTools", default_factory=list)
    mcp_resources: list[McpResourceDefinition] = Field(alias="mcpResources", default_factory=list)
    dependencies: list["PluginDependency"] = Field(default_factory=list)
    data_classification: str | None = Field(alias="dataClassification", default=None)
    reference_data_subscriptions: list["ReferenceDataSubscription"] = Field(
        alias="referenceDataSubscriptions", default_factory=list
    )
    ui: UiContributions | None = None

    model_config = {"populate_by_name": True}

    @field_validator("id")
    @classmethod
    def _validate_id(cls, value: str) -> str:
        return normalize_uuid_string(value, "PluginManifest.id")


class ReferenceDataSubscriptionOptions(BaseModel):
    """Cache and sync options for a reference data subscription."""
    max_memory_entries: int = Field(alias="maxMemoryEntries", default=5_000)
    reconciliation_interval_seconds: int = Field(alias="reconciliationIntervalSeconds", default=30)

    model_config = {"populate_by_name": True}


class ReferenceDataSubscription(BaseModel):
    """Declares a plugin subscription to cross-module reference data."""
    module_prefix: str = Field(alias="modulePrefix")
    entity_type: str = Field(alias="entityType")
    fields: list[str]
    options: ReferenceDataSubscriptionOptions | None = None

    model_config = {"populate_by_name": True}


class NotificationContext(BaseModel):
    """Distributed tracing and identity context propagated with notifications."""
    trace_id: str = Field(alias="traceId", default="")
    span_id: str = Field(alias="spanId", default="")
    correlation_id: str = Field(alias="correlationId", default="")
    organisation_id: str = Field(alias="organisationId", default="")
    tenant_id: str = Field(alias="tenantId", default="")
    extension_id: str = Field(alias="extensionId", default="")

    model_config = {"populate_by_name": True}

    @field_validator("organisation_id", "tenant_id", "extension_id")
    @classmethod
    def _validate_identity_ids(cls, value: str, info) -> str:
        return normalize_uuid_string(value, f"NotificationContext.{info.field_name}", allow_empty=True)


class PluginNotification(BaseModel):
    """Notification envelope from the platform."""
    type: str
    version: int = 1
    organisation_id: str = Field(alias="organisationId")
    payload_json: str | None = Field(alias="payloadJson", default=None)
    requires_ack: bool = Field(alias="requiresAck", default=False)
    idempotency_key: str = Field(alias="idempotencyKey", default="")
    context: NotificationContext | None = None

    model_config = {"populate_by_name": True}

    @field_validator("organisation_id")
    @classmethod
    def _validate_organisation_id(cls, value: str) -> str:
        return normalize_uuid_string(value, "PluginNotification.organisation_id")


class RefDataInvalidationSignal(BaseModel):
    """Invalidation signal carried in PluginNotification payload."""
    module_prefix: str = Field(alias="modulePrefix")
    entity_type: str = Field(alias="entityType")
    sequence_number: int = Field(alias="sequenceNumber")
    sync_token: str = Field(alias="syncToken")
    change_type: Literal["Created", "Updated", "Deleted"] = Field(alias="changeType")
    organisation_id: str = Field(alias="organisationId")
    entity_id: str | None = Field(alias="entityId", default=None)
    projected_fields_json: str | None = Field(alias="projectedFieldsJson", default=None)
    included_fields: list[str] | None = Field(alias="includedFields", default=None)

    model_config = {"populate_by_name": True}

    @field_validator("organisation_id")
    @classmethod
    def _validate_organisation_id(cls, value: str) -> str:
        return normalize_uuid_string(value, "RefDataInvalidationSignal.organisation_id")


# ── Tool / Resource Results ───────────────────────────────────────────────────


class ToolResult(BaseModel):
    success: bool
    result_json: str | None = Field(alias="resultJson", default=None)
    error: str | None = None

    model_config = {"populate_by_name": True}


class ResourceResult(BaseModel):
    success: bool
    content: str | None = None  # Base64-encoded
    mime_type: str | None = Field(alias="mimeType", default=None)
    error: str | None = None

    model_config = {"populate_by_name": True}


class HealthResult(BaseModel):
    status: int = 0  # 0=Healthy, 1=Degraded, 2=Unhealthy
    message: str | None = None


# ── Service Protocols ─────────────────────────────────────────────────────────


class DataStoreFieldFilter(BaseModel):
    """A single filter condition on a JSON field in the DataStore."""

    field_name: str = Field(alias="fieldName")
    operator: Literal[
        "eq", "notEq", "gt", "gte", "lt", "lte", "in", "notIn",
        "contains", "notContains", "startsWith", "endsWith", "isNull", "isNotNull"
    ]
    value_json: str = Field(alias="valueJson", default="")

    model_config = {"populate_by_name": True}


class DataStoreFieldSort(BaseModel):
    """Sort specification for DataStore queries."""

    field_name: str = Field(alias="fieldName")
    direction: Literal["ascending", "descending"] = "ascending"

    model_config = {"populate_by_name": True}


class DataStoreQueryOptions(BaseModel):
    """Query options for filtered, sorted, paginated DataStore queries."""

    filters: list[DataStoreFieldFilter] | None = None
    sort: DataStoreFieldSort | None = None
    take: int = Field(default=50, ge=1, le=1000)
    page_token: str | None = Field(alias="pageToken", default=None)
    include_total_count: bool = Field(alias="includeTotalCount", default=True)

    model_config = {"populate_by_name": True}


class DataStorePagedResult(BaseModel):
    """Token-based paginated result from a DataStore query."""

    items: list[Any] = Field(default_factory=list)
    total_count: int | None = Field(alias="totalCount", default=None)
    has_total_count: bool = Field(alias="hasTotalCount", default=False)
    next_page_token: str | None = Field(alias="nextPageToken", default=None)
    page_size: int = Field(alias="pageSize", default=0)

    model_config = {"populate_by_name": True}


class PluginStorageInfo(BaseModel):
    """Storage usage and quota information for a plugin's data store partition."""

    used_bytes: int = Field(alias="usedBytes", default=0)
    max_bytes: int = Field(alias="maxBytes", default=0)
    key_count: int = Field(alias="keyCount", default=0)
    max_keys: int = Field(alias="maxKeys", default=0)
    usage_pct: float = Field(alias="usagePct", default=0.0)

    model_config = {"populate_by_name": True}


@runtime_checkable
class PluginDataStoreProtocol(Protocol):
    """Protocol for the plugin data store provided by the host."""

    async def get(self, key: str) -> Any: ...
    async def set(self, key: str, value: Any) -> None: ...
    async def delete(self, key: str) -> bool: ...
    async def exists(self, key: str) -> bool: ...
    async def list_keys(self, prefix: str) -> list[str]: ...
    async def query(self, prefix: str) -> list[dict[str, Any]]: ...
    async def query_filtered(
        self, key_prefix: str, options: DataStoreQueryOptions
    ) -> DataStorePagedResult:
        """Query entries matching the key prefix with filtering, sorting, and pagination."""
        ...
    async def count(
        self, key_prefix: str, filters: list[DataStoreFieldFilter] | None = None
    ) -> int:
        """Count entries matching the key prefix and optional filters."""
        ...


@runtime_checkable
class PluginLoggerProtocol(Protocol):
    """Protocol for the plugin logger provided by the host."""

    def info(self, message: str, *args: Any) -> None: ...
    def warning(self, message: str, *args: Any) -> None: ...
    def error(self, message: str, *args: Any) -> None: ...
    def debug(self, message: str, *args: Any) -> None: ...


@runtime_checkable
class McpClientProtocol(Protocol):
    """Protocol for the MCP client provided by the host."""

    async def invoke_tool(self, tool_name: str, arguments_json: str = "{}") -> Any: ...
    async def list_tools(self) -> list[Any]: ...
    async def get_resource(self, uri: str) -> Any: ...
    async def list_resources(self) -> list[Any]: ...
    async def batch_invoke_tools(
        self, requests: list[dict[str, str]],
    ) -> list[Any]:
        """Invoke multiple tools in parallel (ENT-15)."""
        ...


# ── Plugin Context ────────────────────────────────────────────────────────────


class PluginContext:
    """Runtime context provided to plugin methods."""

    def __init__(
        self,
        extension_id: str,
        organisation_id: str,
        tenant_id: str,
        host_app_id: str,
        data_store: PluginDataStoreProtocol,
        logger: PluginLoggerProtocol,
        mcp_client: McpClientProtocol,
        reference_data: Any = None,
        publish_event: Any = None,
    ) -> None:
        self.extension_id = normalize_uuid_string(extension_id, "PluginContext.extension_id")
        self.organisation_id = normalize_uuid_string(organisation_id, "PluginContext.organisation_id")
        self.tenant_id = normalize_uuid_string(tenant_id, "PluginContext.tenant_id")
        self.host_app_id = host_app_id
        self.data_store = data_store
        self.reference_data = reference_data
        self.logger = logger
        self.mcp_client = mcp_client
        self._publish_event = publish_event

    async def publish_event(self, event_type: str, payload: Any) -> None:
        """Publish a domain event to the host for distribution via the event bus."""
        if self._publish_event is not None:
            await self._publish_event(event_type, payload)


# ── Error Taxonomy (ENT-2) ───────────────────────────────────────────────────


class PluginErrorCode:
    """Structured error codes for plugin responses."""

    TOOL_NOT_FOUND = "TOOL_NOT_FOUND"
    RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND"
    INVALID_ARGUMENTS = "INVALID_ARGUMENTS"
    TIMEOUT = "TIMEOUT"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    NOT_INITIALIZED = "NOT_INITIALIZED"


class PluginError(BaseModel):
    """Structured error response for programmatic handling by the host."""

    code: str
    message: str
    details: dict[str, Any] | None = None


# ── Data Classification (ENT-10) ─────────────────────────────────────────────


class DataClassification:
    """Data classification for stored values (GDPR compliance)."""

    PUBLIC = "Public"
    INTERNAL = "Internal"
    PII = "PII"
    SENSITIVE = "Sensitive"


# ── Plugin Dependencies (ENT-8) ──────────────────────────────────────────────


class PluginDependency(BaseModel):
    """Declares a dependency on another plugin (matches backend ExtensionDependency)."""

    feature_id: str = Field(alias="featureId")
    minimum_version: str | None = Field(alias="minimumVersion", default=None)
    optional: bool = False

    model_config = {"populate_by_name": True}

    @field_validator("feature_id")
    @classmethod
    def _validate_feature_id(cls, value: str) -> str:
        return normalize_uuid_string(value, "PluginDependency.feature_id")
