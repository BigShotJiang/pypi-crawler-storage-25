"""
Basic tests for the DaprHostClient and its sub-clients.

These tests verify the public API surface and payload construction
without requiring a running Dapr sidecar or host.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, patch

import pytest

from ethisyscore_plugin_sdk.dapr_host_client import DaprHostClient, _PluginLogger
from ethisyscore_plugin_sdk.protocol_constants import (
    CB_DATA_COUNT,
    CB_DATA_QUERY_FILTERED,
    CB_PUBLISH_EVENT,
)
from ethisyscore_plugin_sdk.types import DataStoreFieldFilter, DataStorePagedResult, DataStoreQueryOptions

EXTENSION_ID = "11111111-1111-1111-1111-111111111111"


class TestPluginLogger:
    """Tests for the synchronous logger wrapper."""

    def test_logger_has_all_methods(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)
        logger = client.logger

        assert callable(logger.debug)
        assert callable(logger.info)
        assert callable(logger.warning)
        assert callable(logger.error)

    def test_logger_methods_are_synchronous(self) -> None:
        """Logger methods should be plain functions, not coroutines."""
        client = DaprHostClient("test-host", EXTENSION_ID)
        logger = client.logger

        # Synchronous methods should not return a coroutine
        import asyncio
        result = logger.debug("test message")
        assert not asyncio.iscoroutine(result)

        result = logger.info("test message")
        assert not asyncio.iscoroutine(result)

        result = logger.warning("test message")
        assert not asyncio.iscoroutine(result)

        result = logger.error("test message")
        assert not asyncio.iscoroutine(result)

    def test_logger_does_not_raise_without_event_loop(self) -> None:
        """Logger should not raise when no event loop is running."""
        client = DaprHostClient("test-host", EXTENSION_ID)
        logger = client.logger

        # These should not raise — fire-and-forget silently catches RuntimeError
        logger.debug("test")
        logger.info("test")
        logger.warning("test")
        logger.error("test")
        logger.error("test", exception="traceback here")


class TestDataStore:
    """Tests for the DataStore client API surface."""

    def test_data_store_has_all_methods(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)
        ds = client.data_store

        assert callable(ds.get)
        assert callable(ds.set)
        assert callable(ds.delete)
        assert callable(ds.exists)
        assert callable(ds.query)
        assert callable(ds.list_keys)
        assert callable(ds.set_batch)
        assert callable(ds.delete_by_prefix)
        assert callable(ds.get_storage_info)
        assert callable(ds.query_filtered)
        assert callable(ds.count)


class TestMcpClient:
    """Tests for the MCP client API surface."""

    def test_mcp_client_has_all_methods(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)
        mcp = client.mcp_client

        assert callable(mcp.invoke_tool)
        assert callable(mcp.list_tools)
        assert callable(mcp.get_resource)
        assert callable(mcp.list_resources)


class TestPublishEvent:
    """Tests for event publishing payload construction."""

    @pytest.mark.asyncio
    async def test_publish_event_constructs_correct_payload(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {}

            await client.publish_event("TestEvent", {"key": "value"})

            mock_invoke.assert_called_once_with(
                CB_PUBLISH_EVENT,
                {
                    "extensionId": EXTENSION_ID,
                    "eventJson": json.dumps({"eventType": "TestEvent", "payload": {"key": "value"}}),
                },
            )

    @pytest.mark.asyncio
    async def test_publish_event_serializes_nested_payload(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {}

            payload = {"items": [1, 2, 3], "nested": {"a": True}}
            await client.publish_event("ComplexEvent", payload)

            call_args = mock_invoke.call_args[0]
            event_json = json.loads(call_args[1]["eventJson"])
            assert event_json["eventType"] == "ComplexEvent"
            assert event_json["payload"] == payload


class TestDataStoreQueryFiltered:
    """Tests for the DataStore query_filtered method."""

    @pytest.mark.asyncio
    async def test_query_filtered_constructs_correct_payload_with_pydantic_options(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {
                "items": [{"key": "k1", "value": "v1"}],
                "totalCount": 1,
                "nextPageToken": None,
            }

            options = DataStoreQueryOptions(
                filters=[DataStoreFieldFilter(fieldName="Category", operator="eq", value="Electronics")],
                take=10,
            )
            result = await client.data_store.query_filtered("product:", options)

            mock_invoke.assert_called_once()
            call_args = mock_invoke.call_args[0]
            assert call_args[0] == CB_DATA_QUERY_FILTERED
            body = call_args[1]
            assert body["extensionId"] == EXTENSION_ID
            assert body["keyPrefix"] == "product:"
            assert body["options"]["take"] == 10
            assert body["options"]["filters"][0]["fieldName"] == "Category"
            assert body["options"]["filters"][0]["operator"] == "eq"
            assert isinstance(result, DataStorePagedResult)
            assert result.total_count == 1
            assert len(result.items) == 1

    @pytest.mark.asyncio
    async def test_query_filtered_constructs_correct_payload_with_dict_options(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {"items": [], "totalCount": 0, "nextPageToken": None}

            options = {"take": 5, "filters": [{"fieldName": "Name", "operator": "contains", "value": "test"}]}
            result = await client.data_store.query_filtered("item:", options)

            mock_invoke.assert_called_once()
            call_args = mock_invoke.call_args[0]
            body = call_args[1]
            assert body["keyPrefix"] == "item:"
            assert body["options"]["take"] == 5
            assert isinstance(result, DataStorePagedResult)
            assert result.total_count == 0
            assert result.items == []

    @pytest.mark.asyncio
    async def test_query_filtered_with_no_filters(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {"items": [], "totalCount": 0, "nextPageToken": None}

            options = DataStoreQueryOptions(take=50)
            await client.data_store.query_filtered("prefix:", options)

            call_args = mock_invoke.call_args[0]
            body = call_args[1]
            assert body["options"]["take"] == 50
            # filters should be excluded (exclude_none)
            assert "filters" not in body["options"] or body["options"]["filters"] is None


class TestDataStoreCount:
    """Tests for the DataStore count method."""

    @pytest.mark.asyncio
    async def test_count_constructs_correct_payload_without_filters(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {"count": 42}

            result = await client.data_store.count("product:")

            mock_invoke.assert_called_once()
            call_args = mock_invoke.call_args[0]
            assert call_args[0] == CB_DATA_COUNT
            body = call_args[1]
            assert body["extensionId"] == EXTENSION_ID
            assert body["keyPrefix"] == "product:"
            assert body["filters"] is None
            assert result == 42

    @pytest.mark.asyncio
    async def test_count_constructs_correct_payload_with_pydantic_filters(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {"count": 3}

            filters = [
                DataStoreFieldFilter(fieldName="Category", operator="eq", value="Electronics"),
            ]
            result = await client.data_store.count("product:", filters=filters)

            call_args = mock_invoke.call_args[0]
            body = call_args[1]
            assert body["filters"] is not None
            assert len(body["filters"]) == 1
            assert body["filters"][0]["fieldName"] == "Category"
            assert body["filters"][0]["operator"] == "eq"
            assert result == 3

    @pytest.mark.asyncio
    async def test_count_constructs_correct_payload_with_dict_filters(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {"count": 7}

            filters = [{"fieldName": "Price", "operator": "gte", "value": 100}]
            result = await client.data_store.count("item:", filters=filters)

            call_args = mock_invoke.call_args[0]
            body = call_args[1]
            assert body["keyPrefix"] == "item:"
            assert body["filters"][0]["fieldName"] == "Price"
            assert result == 7

    @pytest.mark.asyncio
    async def test_count_returns_zero_when_no_count_in_response(self) -> None:
        client = DaprHostClient("test-host", EXTENSION_ID)

        with patch.object(client, "_invoke_host", new_callable=AsyncMock) as mock_invoke:
            mock_invoke.return_value = {}

            result = await client.data_store.count("empty:")

            assert result == 0
