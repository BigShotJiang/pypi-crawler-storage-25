"""
pytmrobot — Python TM Robot 控制函式庫

讓 Python 開發者無需了解 TMScript，直接以 Pythonic API 控制達明機器人。

Quick Start::

    from pytmrobot import TMRobot, CartPoint

    with TMRobot("192.168.1.101") as robot:
        home = CartPoint(400, -100, 500, 180, 0, 90)
        pick = CartPoint(400, -100, 280, 180, 0, 90)

        robot.move.ptp(home, speed=30)
        robot.move.ptp(pick, speed=10)
        robot.io.set_do(2, True)          # 夾爪閉合
        robot.sleep(500)
        robot.move.ptp(home, speed=30)
        robot.io.set_do(2, False)         # 夾爪張開

        pos = robot.state.tcp_position
        print(f"完成！位置: X={pos[0]:.2f}, Y={pos[1]:.2f}, Z={pos[2]:.2f}")

Public API
----------
主類別：
    TMRobot         控制機器人的主要入口（支援 context manager）

點位型別：
    CartPoint       笛卡爾座標目標點 (X, Y, Z, Rx, Ry, Rz)
    JointPoint      關節角度目標點 (J1, J2, J3, J4, J5, J6)

列舉：
    SpeedUnit       直線/圓弧速度單位 (PERCENT / ABS_SYNC / ABS_LOCK)
    BlendUnit       軌跡混合單位 (PERCENT / RADIUS)

資料容器：
    RobotState      robot.state.snapshot() 的回傳型別
    IOState         robot.io.get_all_io() 的回傳型別

例外：
    TMError         所有例外的基礎類別
    TMConnectionError  連線失敗
    TMScriptError   機器人回傳 ERROR
    TMTimeoutError  等待逾時
    TMValueError    參數超出範圍
"""

from .exceptions import (
    TMConnectionError,
    TMError,
    TMScriptError,
    TMTimeoutError,
    TMValueError,
)
from .robot import TMRobot
from .types import (
    BlendUnit,
    CartPoint,
    IOState,
    JointPoint,
    Pose6,
    RobotState,
    SpeedUnit,
)

__version__ = "0.2.1"
__author__  = "TMDemo Contributors"

__all__ = [
    # 主類別
    "TMRobot",
    # 點位型別
    "CartPoint",
    "JointPoint",
    "Pose6",
    # 列舉
    "SpeedUnit",
    "BlendUnit",
    # 資料容器
    "RobotState",
    "IOState",
    # 例外
    "TMError",
    "TMConnectionError",
    "TMScriptError",
    "TMTimeoutError",
    "TMValueError",
]
