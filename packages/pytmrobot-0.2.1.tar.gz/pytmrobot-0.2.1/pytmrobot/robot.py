"""
pytmrobot.robot — TMRobot 主類別

使用者的主要入口。支援 context manager（with 語句）。
組合 MotionController、IOController、StateReader 三個子控制器。
"""

from __future__ import annotations

from . import script_builder as sb
from ._client import TMClientWrapper
from .compliance import ComplianceController
from .decision import DecisionController
from .force import ForceController
from .io import IOController
from .modbus import ModbusManager
from .motion import MotionController
from .state import StateReader
from .tag_manager import TagManager
from .touchstop import TouchStopController
from .vision import VisionController

# 從現有模組取得預設值
try:
    import os
    import sys
    _REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if _REPO_ROOT not in sys.path:
        sys.path.insert(0, _REPO_ROOT)
    from tm_listen_client import ROBOT_IP as _DEFAULT_IP
    from tm_listen_client import ROBOT_PORT as _DEFAULT_PORT
except ImportError:
    _DEFAULT_IP   = "127.0.0.1"
    _DEFAULT_PORT = 5890


class TMRobot:
    """TM Robot 高階控制主類別。

    建議使用 context manager（with 語句）確保連線正確釋放：

    Examples::

        from pytmrobot import TMRobot, CartPoint

        with TMRobot("192.168.1.101") as robot:
            robot.move.ptp(CartPoint(400, -100, 350, 180, 0, 90), speed=30)
            robot.sleep(500)
            robot.io.set_do(2, True)
            pos = robot.state.tcp_position
            print(f"到達位置: {pos}")

    若需要手動管理連線生命週期::

        robot = TMRobot("192.168.1.101")
        robot.connect()
        try:
            robot.move.ptp(CartPoint(400, -100, 350, 180, 0, 90))
        finally:
            robot.disconnect()
    """

    def __init__(
        self,
        ip:      str   = _DEFAULT_IP,
        port:    int   = _DEFAULT_PORT,
        timeout: float = 60.0,
    ) -> None:
        """
        Args:
            ip:      機器人 IP 位址（實體機請修改，Simulator 預設 127.0.0.1）
            port:    Listen Node TCP 埠，固定 5890
            timeout: Socket 逾時秒數
        """
        self._wrapper = TMClientWrapper(ip=ip, port=port, timeout=timeout)
        self._tags    = TagManager()
        self._ip      = ip
        self._port    = port

        # 子控制器（純 Python 物件，可直接建立）
        self._move     = MotionController(self._wrapper, self._tags)
        self._io       = IOController(self._wrapper, self._tags)
        self._state    = StateReader(self._wrapper, self._tags)
        self._decision   = DecisionController(self._wrapper, self._tags)
        self._modbus     = ModbusManager(self._wrapper, self._tags)
        self._touchstop  = TouchStopController(self._wrapper, self._tags)
        self._compliance = ComplianceController(self._wrapper, self._tags)
        self._force      = ForceController(self._wrapper, self._tags)
        self._vision     = VisionController(self._wrapper, self._tags)

        self._connected = False

    # ── Context Manager ──────────────────────────────────────────────────────

    def __enter__(self) -> TMRobot:
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()
        return False  # 不吞例外

    def __repr__(self) -> str:
        status = "connected" if self._connected else "disconnected"
        return f"TMRobot(ip={self._ip!r}, port={self._port}, status={status})"

    # ── 連線管理 ─────────────────────────────────────────────────────────────

    def connect(self) -> None:
        """建立 TCP 連線並等待機器人進入 Listen Node。

        Raises:
            TMConnectionError: 連線失敗
        """
        self._wrapper.connect()
        self._io._reset_session()         # 新 session，重設 IO 變數宣告狀態
        self._decision._reset_session()   # 重設 MDecision 物件宣告狀態
        self._modbus._reset_session()     # 重設 ModbusTCP 物件宣告狀態
        self._touchstop._reset_session()  # 重設 TouchStop 物件宣告狀態
        self._compliance._reset_session() # 重設 Compliance 物件宣告狀態
        self._force._reset_session()      # 重設 Force/FTSensor 物件宣告狀態
        self._vision._reset_session()     # 重設 Vision 變數宣告狀態
        self._connected = True

    def disconnect(self, exit_listen: bool = False) -> None:
        """斷開 TCP 連線。

        Args:
            exit_listen: True=先發送 ScriptExit(0) 退出 Listen Node 再斷線
        """
        if self._connected:
            try:
                if exit_listen:
                    self._wrapper.exit_listen(pass_exit=False)
            except Exception:
                pass
            self._wrapper.disconnect()
            self._connected = False

    # ── 子控制器 ─────────────────────────────────────────────────────────────

    @property
    def move(self) -> MotionController:
        """運動控制器：``robot.move.ptp()`` / ``robot.move.line()`` 等。"""
        return self._move

    @property
    def io(self) -> IOController:
        """IO 控制器：``robot.io.set_do()`` / ``robot.io.get_di()`` 等。"""
        return self._io

    @property
    def state(self) -> StateReader:
        """狀態讀取器：``robot.state.tcp_position`` / ``robot.state.snapshot()`` 等。"""
        return self._state

    @property
    def decision(self) -> DecisionController:
        """人機互動控制器：``robot.decision.ask()`` / ``robot.decision.popup()``。"""
        return self._decision

    @property
    def modbus(self) -> ModbusManager:
        """Modbus TCP 管理器：``robot.modbus.connect()`` / ``robot.modbus.read_int()`` 等。"""
        return self._modbus

    @property
    def touchstop(self) -> TouchStopController:
        """TouchStop 控制器：``robot.touchstop.run()`` / ``robot.touchstop.get_stopped_pos()``。"""
        return self._touchstop

    @property
    def compliance(self) -> ComplianceController:
        """Compliance 順從控制器：``robot.compliance.run()``。"""
        return self._compliance

    @property
    def force(self) -> ForceController:
        """Force 力控制器：``robot.force.open_sensor()`` / ``robot.force.run()``。"""
        return self._force

    @property
    def vision(self) -> VisionController:
        """視覺控制器：``robot.vision.do_job()`` / ``robot.vision.get_output_pose()``。"""
        return self._vision

    # ── 直接動作 ─────────────────────────────────────────────────────────────

    def _send_single(self, prefix: str, line: str) -> None:
        """發送單行 TMScript（取得 tag、包成列表、確認 OK）。"""
        tag = self._tags.next()
        self._wrapper.send_script_checked(f"{prefix}{tag}", [line])

    def stop(self, mode: int = 0) -> None:
        """立即停止手臂並清除運動緩衝區。

        Args:
            mode: 0=清除運動緩衝, 1=清除全部, 2=清除運動+條件等待

        Note:
            這是優先命令（Priority Command），不受運動隊列影響，立即執行。
        """
        self._send_single("stop", sb.build_stop(mode))

    def sleep(self, ms: int) -> None:
        """在機器人端執行 Sleep，Python 端同步等待完成。

        Args:
            ms: 等待毫秒數

        Examples::

            robot.io.set_do(0, True)
            robot.sleep(500)          # 等待 500ms
            robot.io.set_do(0, False)
        """
        self._send_single("slp", sb.build_sleep(ms))

    def change_base(self, name: str) -> None:
        """切換運動參考座標系。

        Args:
            name: 座標系名稱（空字串=""表示 RobotBase）
        """
        self._send_single("base", sb.build_change_base(name))

    def change_tcp(self, name: str) -> None:
        """切換工具中心點（TCP）。

        Args:
            name: TCP 名稱（空字串=""表示 RobotEndFlange）
        """
        self._send_single("tcp", sb.build_change_tcp(name))

    def change_load(self, kg: float) -> None:
        """設定補償附載重量。

        Args:
            kg: 附載重量，單位 kg
        """
        self._send_single("load", sb.build_change_load(kg))

    def exit_listen(self, success: bool = True) -> None:
        """退出 Listen Node。

        Args:
            success: True=Pass 路線（ScriptExit(1)），False=Fail 路線（ScriptExit(0)）

        Note:
            通常不需要手動呼叫，``disconnect()`` 已處理；
            但若需要明確讓機器人繼續下一個流程節點，可呼叫此方法。
        """
        self._wrapper.exit_listen(pass_exit=success)

    def run_script(self, lines: list[str], wait: bool = True) -> bool:
        """直接發送 TMScript 行列表（進階逃生口）。

        使用者熟悉 TMScript 時可透過此方法直接控制。

        Args:
            lines: TMScript 行列表
            wait:  True=等待 TMSCT OK 回應

        Returns:
            True=OK, False=ERROR

        Examples::

            robot.run_script([
                'PTP("CPP",{400,-100,350,180,0,90},30,200,0,false)',
                'QueueTag(1,1)',
            ])
        """
        tag = self._tags.next()
        return self._wrapper.send_script(f"raw{tag}", lines)

    # ── 屬性 ─────────────────────────────────────────────────────────────────

    @property
    def is_connected(self) -> bool:
        """是否已建立連線。"""
        return self._connected

    @property
    def client(self) -> TMClientWrapper:
        """底層 TMClientWrapper（進階使用）。"""
        return self._wrapper
