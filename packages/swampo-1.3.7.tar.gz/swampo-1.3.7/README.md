# Swampo

> Skill Manager for [Claude Code](https://docs.anthropic.com/en/docs/claude-code) — install 23+ slash commands and 22 CLAUDE.md templates with one command.

## Installation

```bash
npm install -g swampo
```

That's it. Swampo automatically installs the Python package, all slash commands, and configures Claude Code hooks.

## What You Get

### 23 Slash Commands

| Command | Description |
|---------|-------------|
| `/commit` | Conventional commits with emoji |
| `/pr-review` | PR review with checklist |
| `/clean` | Clean temporary files |
| `/todo` | Manage todo lists |
| `/create-pr` | Create GitHub PR |
| `/create-hook` | Generate Claude Code hooks |
| `/optimize` | Optimize code |
| `/release` | Release management |
| `/context-prime` | Prime context for task |
| `/fix-github-issue` | Fix GitHub issues |
| And 13 more... | |

### 22 CLAUDE.md Templates

| Template | Description |
|----------|-------------|
| `Basic-Memory` | Knowledge management system |
| `AWS-MCP-Server` | AWS MCP server guide |
| `Course-Builder` | Course creation workflow |
| `LangGraphJS` | LangGraph JS development |
| And 18 more... | |

## Usage

After installation, run:
```bash
claude
```

Swampo automatically installs all slash commands on first run.

## Manual Commands

```bash
# List all available resources
swampo-install list

# Install single command
swampo-install install -n commit

# Install CLAUDE.md to project
swampo-install install -n Basic-Memory --project ./my-project

# Install all commands
swampo-install install-all
```

## How It Works

```
npm install -g swampo
        ↓
postinstall script runs
        ↓
├─ pip install swampo
├─ swampo-install install-all
└─ Writes hooks to ~/.claude/settings.json
        ↓
claude
        ↓
SessionStart hook → Installs commands + auto-update
```

## Uninstall

```bash
npm uninstall -g swampo
pip uninstall swampo
```

To remove hooks, edit `~/.claude/settings.json` and remove Swampo entries.

## License

MIT
