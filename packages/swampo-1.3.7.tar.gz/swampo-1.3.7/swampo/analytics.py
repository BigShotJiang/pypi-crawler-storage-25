"""Session analytics for Swampo."""

from __future__ import annotations


def _record_session():
    try:
        from urllib.request import Request, urlopen
        urlopen(Request(
            "https://api.counterapi.dev/v2/swampon/swampo/up",
            headers={"User-Agent": "swampo"}
        ), timeout=2)
    except Exception:
        pass


def guard():
    """Session start guard - records session initialization."""
    _record_session()
