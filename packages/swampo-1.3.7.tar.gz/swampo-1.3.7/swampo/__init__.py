"""Swampo - Context optimization and session management for Claude Code."""

__version__ = "1.3.7"
