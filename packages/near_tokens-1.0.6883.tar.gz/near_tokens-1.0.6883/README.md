# near-tokens

Python async client for NEAR Protocol token operations and account queries.

## Requirements

Python 3.9+

## Installation

pip install near-tokens

## Quick Start

import asyncio
from near_tokens import NearTokensClient

async def main():
    async with NearTokensClient() as client:
        balance = await client.get_balance("alice.near")
        print(f"Balance: {balance['balance_near']:.4f} NEAR")

asyncio.run(main())

## Usage

### Account Balance

import asyncio
from near_tokens import NearTokensClient

async def main():
    async with NearTokensClient() as client:
        balance = await client.get_balance("wrap.near")
        print(balance["balance_near"])
        print(balance["balance_yocto"])
        print(balance["storage_usage"])

asyncio.run(main())

### Check Account Exists

import asyncio
from near_tokens import NearTokensClient

async def main():
    async with NearTokensClient() as client:
        exists = await client.account_exists("alice.near")
        print(exists)  # True or False

asyncio.run(main())

### Block and Gas Price

import asyncio
from near_tokens import NearTokensClient

async def main():
    async with NearTokensClient() as client:
        block = await client.get_block()
        gas_price = await client.get_gas_price()
        print(block, gas_price)

asyncio.run(main())

### Fungible Token (FT) Queries

import asyncio
from near_tokens import NearTokensClient

async def main():
    async with NearTokensClient() as client:
        metadata = await client.get_ft_metadata("usdt.tether-token.near")
        ft_balance = await client.get_ft_balance("usdt.tether-token.near", "alice.near")
        print(metadata)
        print(ft_balance)

asyncio.run(main())

### Validators

import asyncio
from near_tokens import NearTokensClient

async def main():
    async with NearTokensClient() as client:
        validators = await client.get_validators()
        print(validators)

asyncio.run(main())

### Manual Session Management

import asyncio
from near_tokens import NearTokensClient

async def main():
    client = NearTokensClient(rpc_url="https://rpc.mainnet.near.org")
    balance = await client.get_balance("alice.near")
    print(balance)
    await client.close()

asyncio.run(main())

## API Reference

| Method | Description |
|---|---|
| `get_balance(account_id)` | NEAR balance in yoctoNEAR and NEAR |
| `account_exists(account_id)` | Returns `True` if account exists |
| `get_block()` | Latest finalized block info |
| `get_gas_price()` | Current gas price |
| `get_ft_balance(contract_id, account_id)` | Fungible token balance |
| `get_ft_metadata(contract_id)` | Fungible token metadata |
| `get_validators()` | Current epoch validators |
| `close()` | Close the HTTP session |

## License

MIT