"""
near_tokens - Python client for NEAR Protocol token operations.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

import aiohttp

__version__ = "1.0.0"
__all__ = ["NearTokensClient"]

NEAR_RPC_URL = "https://rpc.mainnet.near.org"
YOCTO_NEAR = 10**24


class NearTokensClient:
    """Async client for NEAR Protocol token queries and account operations."""

    def __init__(self, rpc_url: str = NEAR_RPC_URL) -> None:
        self.rpc_url = rpc_url
        self._session: Optional[aiohttp.ClientSession] = None

    async def __aenter__(self) -> "NearTokensClient":
        self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._session:
            await self._session.close()
            self._session = None

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self._session

    async def _rpc_call(self, method: str, params: Any) -> Dict[str, Any]:
        """Send a JSON-RPC request to the NEAR RPC endpoint."""
        session = await self._get_session()
        payload = {
            "jsonrpc": "2.0",
            "id": "near_tokens",
            "method": method,
            "params": params,
        }
        async with session.post(self.rpc_url, json=payload) as resp:
            resp.raise_for_status()
            data = await resp.json()
        if "error" in data:
            raise ValueError(f"RPC error: {data['error']}")
        return data.get("result", {})

    async def get_balance(self, account_id: str) -> Dict[str, Any]:
        """Return NEAR balance for an account in both yoctoNEAR and NEAR."""
        result = await self._rpc_call(
            "query",
            {
                "request_type": "view_account",
                "finality": "final",
                "account_id": account_id,
            },
        )
        amount_yocto = int(result.get("amount", "0"))
        locked_yocto = int(result.get("locked", "0"))
        return {
            "account_id": account_id,
            "balance_yocto": amount_yocto,
            "balance_near": amount_yocto / YOCTO_NEAR,
            "locked_yocto": locked_yocto,
            "locked_near": locked_yocto / YOCTO_NEAR,
            "storage_usage": result.get("storage_usage"),
            "code_hash": result.get("code_hash"),
        }

    async def account_exists(self, account_id: str) -> bool:
        """Check whether a NEAR account exists on-chain."""
        try:
            await self.get_balance(account_id)
            return True
        except ValueError:
            return False

    async def get_block(self, finality: str = "final") -> Dict[str, Any]:
        """Fetch the latest block header from NEAR."""
        result = await self._rpc_call("block", {"finality": finality})
        header = result.get("header", {})
        return {
            "block_height": header.get("height"),
            "block_hash": header.get("hash"),
            "timestamp_ns": header.get("timestamp"),
            "gas_price": header.get("gas_price"),
            "total_supply": header.get("total_supply"),
        }

    async def get_gas_price(self, block_hash: Optional[str] = None) -> Dict[str, Any]:
        """Return the current gas price in yoctoNEAR."""
        params = [block_hash]
        result = await self._rpc_call("gas_price", params)
        gas_price_yocto = int(result.get("gas_price", "0"))
        return {
            "gas_price_yocto": gas_price_yocto,
            "gas_price_near": gas_price_yocto / YOCTO_NEAR,
        }

    async def view_function(
        self,
        contract_id: str,
        method_name: str,
        args_base64: str = "e30=",
    ) -> Dict[str, Any]:
        """Call a read-only (view) function on a NEAR smart contract."""
        result = await self._rpc_call(
            "query",
            {
                "request_type": "call_function",
                "finality": "final",
                "account_id": contract_id,
                "method_name": method_name,
                "args_base64": args_base64,
            },
        )
        return result

    async def get_ft_balance(self, contract_id: str, account_id: str) -> Dict[str, Any]:
        """Return fungible token (NEP-141) balance for an account."""
        import base64, json as _json
        args = base64.b64encode(_json.dumps({"account_id": account_id}).encode()).decode()
        result = await self.view_function(contract_id, "ft_balance_of", args)
        raw_bytes: List[int] = result.get("result", [])
        raw_str = bytes(raw_bytes).decode("utf-8").strip('"')
        balance = int(raw_str) if raw_str.isdigit() else 0
        return {
            "contract_id": contract_id,
            "account_id": account_id,
            "balance_raw": balance,
        }

    async def get_ft_metadata(self, contract_id: str) -> Dict[str, Any]:
        """Return NEP-141 fungible token metadata for a contract."""
        import json as _json
        result = await self.view_function(contract_id, "ft_metadata")
        raw_bytes: List[int] = result.get("result", [])
        try:
            return _json.loads(bytes(raw_bytes).decode("utf-8"))
        except Exception:
            return {"raw": raw_bytes}

    async def get_validators(self) -> Dict[str, Any]:
        """Return current epoch validators and stake info."""
        result = await self._rpc_call("validators", [None])
        current = result.get("current_validators", [])
        return {
            "epoch_height": result.get("epoch_height"),
            "validator_count": len(current),
            "validators": [
                {
                    "account_id": v.get("account_id"),
                    "stake_near": int(v.get("stake", "0")) / YOCTO_NEAR,
                }
                for v in current[:10]
            ],
        }

    async def close(self) -> None:
        """Close the underlying HTTP session."""
        if self._session:
            await self._session.close()
            self._session = None