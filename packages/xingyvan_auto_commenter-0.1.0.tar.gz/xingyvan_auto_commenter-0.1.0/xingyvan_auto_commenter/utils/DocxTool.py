import win32com.client as win32
import os
import docx2txt

def to_txt(filename:str)->str:
    # 将Word文档转换为纯文本
    text = docx2txt.process(filename)
    return text

class WordCommenter:
    def __init__(self,file_path) -> None:
        self.abs_path = os.path.abspath(file_path)
    
        self.word_app = None
        self.doc = None
        
    def add_word_comments(self, keyword, comment_content):
        self.word_app = word_app = win32.Dispatch('Word.Application') 
        word_app.Visible = True
        
        self.doc = word_app.Documents.Open(self.abs_path)
        #遍历文档中的所有段落
        for para in self.doc.Paragraphs:
            # 获取段落文本
            para_text = para.Range.Text
            
            # 如果段落中包含关键词
            if keyword in para_text:
                # 在该段落的 Range 处添加批注
                # 参数1: Range (位置), 参数2: Text (批注内容)
                self.doc.Comments.Add(para.Range, comment_content)
                break
            
    def __enter__(self):
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        # 保存、关闭、退出
        base, ext = os.path.splitext(self.abs_path)
        new_path = f"{base}-批注后{ext}"
        self.doc.SaveAs(new_path) # type: ignore
        self.doc.Close() # type: ignore
        if self.word_app:
            self.word_app.Quit()
        # 如果返回 True，会吞掉异常；返回 None/False 则正常抛出



# --- 使用示例 ---
if __name__ == "__main__":
    with WordCommenter("./test.docx") as commenter:
        commenter.add_word_comments(
        keyword="was part",
        comment_content="请在此处补充详细说明"
    )
