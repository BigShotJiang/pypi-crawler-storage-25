from openai import OpenAI
import os

SYSTEM_CONTENT="""你是中国海洋大学行远书院《语言：认知与文化》课程的助教。你的任务是对学生的课程作业进行精细化批注。

【批注原则】
1. 批注语言：使用英文撰写批注，因为课程以英文授课；
2. 批注风格：温和、建设性、具体、偏鼓励。避免泛泛而谈（如"写得很好"），必须指出具体好。
3. 批注数量：控制在 3-4 条，优先选择最有价值的点评，避免过度批注。
4. 每条批注必须包含：
   - location：所引用的原文片段（10 词左右，确保能唯一定位位置，不许跨段落（段落分割指回车符，跨越段落即跨越换行符））
   - content：具体的批注内容（2–4 句话，解释原因并给出可操作的建议或思考方向）

【输出格式】
你必须且只能输出一个合法的 JSON 对象，不要包含 markdown 代码块标记（如 ```json），也不要包含任何解释性文字。JSON 结构如下：

[{
    "location": "第一处批注原文引用片段",
    "content": "第一处批注具体批注内容"
},
....
]
【重要约束】
- 严禁在 JSON 之外输出任何内容（包括开头问候、结尾总结、markdown 格式标记）。
- 不要批注可能导致 JSON 格式产生错误的内容，如带双引号的文本 如Another example comes from writing styles. Bertrand Russell’s essays, such as “What I Have Lived For,” open with a clear thesis.等等
- 不要批注题目等无意义的内容（给你的是作业全文，包含题目，标题等非同学完成的内容）
"""

def get_LLM_comment_content_json(artical:str):
    client = OpenAI(
        api_key=os.environ.get('DEEPSEEK_API_KEY'),
        base_url="https://api.deepseek.com")

    completion = client.chat.completions.create(
        model = "deepseek-v4-pro",
        messages = [
    {"role": "system", "content": SYSTEM_CONTENT},
    {"role": "user", "content":f"作业内容：{artical}"}
    ],
        #reasoning_effort="medium"
        extra_body={"thinking": {"type": "disabled"}}
        )

    return completion.choices[0].message.content

if __name__ == "__main__":
    res = get_LLM_comment_content_json("""
                        2026语言：认知与文化 第1-2周 作业
姓名	兰竣越	组别	4	座号	1032
上课日期	3.12 3.19	学号	24090032015	年级
专业	24海洋科学
上课地点	6101	学院	海洋与大气学院		
反思与自我提问。（包括阅读材料、课程内容、讨论课、上一份作业的反馈）
第一周：
The course re-examines language from multiple perspectives, going beyond the view of language as merely a tool for communication to encourage us to reflect on its dual nature as both a cognitive instinct and a vehicle for culture. I gradually came to realise that language is both an innate human endowment and something that is constantly shaped by our social identities, class and cultural backgrounds. This relationship, which appears contradictory yet is in fact symbiotic, is key to understanding the complexity of language.

Pink’s argument that language is an ‘instinct’ seeks to separate it from being a purely cultural product and to ascribe a biological basis to it, which stands in stark contrast to my previous view of language. In particular, research on children’s language development powerfully demonstrates that the emergence of linguistic ability possesses a certain ‘inevitability’ and ‘universality’. Do we often overlook the commonalities in human cognitive structures by overemphasising cultural differences? Language may indeed be, as Pinker suggests, a set of ‘computational modules’ embedded in our brains; it is innate, awaiting activation by a specific linguistic environment.

Yet does this ‘instinctive’ perspective imply that language is entirely equivalent to a natural phenomenon, entirely divorced from human socio-cultural attributes? In Anthony Browne’s picture book Sounds in the Park, the same park is depicted in starkly different ways through the eyes of a wealthy mother, an unemployed father, a lonely boy and a cheerful girl. Their narrative language—be it in phrasing, tone or focus—deeply reflects their social status, psychological state and values. Here, language is no longer a neutral expression of instinct, but rather a complex network of identity markers, manifestations of power and expressions of emotion. If language is indeed a universal, innate instinct, why does it exhibit such marked stratification and individual variation at the social level? How should we understand this inherent tension?

Perhaps the crux of the matter lies not in an either/or choice, but in understanding language as a dialectical unity of ‘biological instinct’ and ‘social practice’. Pink[RZ1.1] reveals the ‘hardware’ foundation of language—namely, the human brain’s innate capacity to process complex grammatical structures—whilst Brown’s picture books demonstrate how this ‘hardware’ is loaded, operated and made meaningful within specific socio-cultural ‘software’. If we view language merely as a mechanical system for processing symbols, without taking the time to listen to the diverse life stories, social perspectives and cultural logics it carries, we will miss out on language’s most moving and complex aspects.

How can we truly understand and appreciate the diversity and social nature of language whilst acknowledging its innate nature? This is perhaps the very question that this course—and we, as young people of today—need to reflect upon over the long term. Language is not merely a tool of cognition; it is also the arena through which we understand the world, situate ourselves, and coexist with others. Only by recognising its dual nature can we use it with greater clarity and humility, carving out time and space in the clamour of modern life to ‘stand and gaze’ and listen to others. As the poet reminds us, if we rush through our days, we will miss out on life’s true richness; and the charm of language lies precisely in its ability to guide us to pause and discover those silent, yet equally real, voices.

第二周：
The seemingly disparate topics covered in the class all point to the same core idea: language is far more than a mere tool for communication; it is both the ‘operating system’ through which we perceive the world and the fundamental means by which we affirm our sense of self and forge social connections.

At the start of the session, the lecturer shared his insights into Habermas’s theory, interpreting the essence of ‘communicative action’ as communication mediated by language, which seeks understanding, sincerity and legitimacy. This may sound like common sense, but in today’s era of fragmented information, algorithm-driven content, and a growing reluctance to listen and understand, this commitment to sincere communication has, paradoxically, become a rare and precious ideal. How much of our everyday language use is truly directed towards mutual understanding? And how much has degenerated into the assertion of positions or the venting of emotions? Language seems to possess the power to both connect and divide, and how to use it well is a challenge we must all face.

The classroom discussion centred on the question of whether linguistic symbols are arbitrary or grounded in reason—a truly classic topic. We observed seemingly arbitrary correspondences such as ‘水’ and ‘water’ in Chinese and English, whilst also discovering the rationality embodied in the Chinese character ‘好’ (good), which is composed of the radicals ‘女’ (woman) and ‘子’ (child), and in the pictographic character ‘山’ (mountain). Language is not a completely closed, self-sufficient system. Its genesis and evolution are governed not only by the universal laws of human physiology and cognition, but are also deeply rooted in the modes of thought and historical accumulation of specific cultures. So-called ‘arbitrariness’ and ‘rationality’ are not mutually exclusive, but rather two sides of the same linguistic coin.

The emergence of language may not merely serve to describe the world; it is, in itself, a force capable of transforming it. Language enables us to pass on the knowledge of the past to the future, allowing the experiences of countless individuals to coalesce into the vast ocean of civilisation. Yet this power also brings with it a responsibility: language can be used to build a ‘Tower of Babel’, just as it can become a source of division and conflict. The dialogue and rational communication advocated by Habermas may well be the very remedy we need to harness this power and avert a clash of civilisations.

Whether it be the sigh of ‘no time to stand and gaze’ or the choice of ‘two roads diverging in a wood’, language here becomes the vessel through which we examine ourselves and express the predicaments of existence. Language is the boundary of thought, and also the sanctuary of the soul. To explore language is, in fact, to explore ourselves. How we use language determines how we think, how we interact with others, and ultimately, what kind of people we will become.








作业题：What is the relationship between language and thought? Can you illustrate your opinion with your own examples?
The relationship between language and thought is not simply a matter of ‘one determining the other’, but rather resembles a two-way, ongoing dialogue. On the one hand, thought provides the foundation for language; on the other, language profoundly shapes the trajectory of thought.

Fundamentally, thought is the prerequisite for language. Even before they begin to speak, infants are able to express their emotions through eye contact and facial expressions, which demonstrates that thought can exist independently of language. We have all experienced moments when ‘the words are on the tip of our tongue but we cannot articulate them’; that feeling of ‘I know it, but I cannot explain it’ precisely demonstrates that what is in our minds is not necessarily the same as what comes out of our mouths.

However, once language is acquired, it in turn becomes the track along which thought runs. The most direct experience of this is that when using different languages, our thought patterns seem to undergo a subtle shift. When speaking our mother tongue, many judgements and perceptions are made almost ‘automatically’; yet when we switch to another language—especially when engaging in complex discourse—our thinking becomes slower, more deliberate, and more reliant on logical structures. This illustrates that language provides a ready-made set of concepts and a logical framework; whilst it does not rigidly confine our thoughts, it undoubtedly influences our habits and pathways for organising information and drawing inferences.

Furthermore, in [RZ2.1]my own experience, the elders in my hometown speak a dialect; they say ‘the light comes（天光）’ rather than ‘it gets light（天亮）’, and ‘the rain falls（落雨）’ rather than ‘it rains（下雨）’. This language, which distinguishes between ‘light（光）’ and ‘bright（亮）’ and differentiates between ‘fall（落）’ and ‘come（下）’, seems to give them a more nuanced perception of natural changes. When they say ‘the sky has grown light（天光了）’, I can sense a slow transition from darkness to light; whereas when I say ‘it has dawned（天亮了）’, it feels more like a black-and-white statement of fact. The vocabulary and expressions provided by language do indeed act as a ‘filter’, drawing our attention to certain aspects of the world.

Yet the shaping of thought by language is not a one-way process. We can also actively employ language to express and create, thereby influencing and expanding the boundaries of our own thinking. Just as poets use exquisite language to capture fleeting inspiration, and writers use narrative to construct complex maps of human nature, this is both an externalisation of thought and a deepening and sublimation of it. Habermas’s ‘theory of communicative action’, cited in the classroom, emphasises the importance of sincere communication. This precisely illustrates that language is not merely a tool for individual thought, but also a medium through which we establish understanding with others and with society. When we attempt to use language to express ourselves sincerely and to understand others, language itself becomes the stepping stone towards the maturation and broadening of our thinking.

Language and thought are like water and fish: the fish lives in the water, yet also influences it. Thought is the negative of language, whilst language is the developer of thought. They are interdependent, shaping one another, and together form the complete picture through which we understand the world and express ourselves.


                        """)
    print(res)