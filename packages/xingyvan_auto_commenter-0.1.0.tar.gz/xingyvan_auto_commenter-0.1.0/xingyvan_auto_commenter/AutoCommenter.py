from .utils.DocxTool import to_txt,WordCommenter
from .utils.AIAsker import get_LLM_comment_content_json
from json_repair import repair_json
import json,shutil,os
import win32com

class AutoCommenter:
    def __init__(self,file_name) -> None:
        self.file_path = file_name
        gen_py_path = os.path.join(win32com.__gen_path__)
        shutil.rmtree(gen_py_path, ignore_errors=True)
        print(f"清理缓存: {gen_py_path}")
        # 其实这不是必要的，但如果改了DocxTool的实现方式，可能就必要了。
            
    def get_comment_obj(self):
        file_content_txt = to_txt(self.file_path)
        json_content_llm = get_LLM_comment_content_json(file_content_txt)
        fixed_json = repair_json(json_content_llm) # type: ignore
        comment_data = json.loads(fixed_json)
        return comment_data
        
    def auto_comment(self):
        comment_obj = self.get_comment_obj()
        with WordCommenter(self.file_path) as commenter:
            for item in comment_obj:
                location = item['location']
                content = item['content']
                print(f'{self.file_path[:10]:10.10} | {location:40.40} | {content:40.40}')
                #print(f'{self.file_path} | {location} | {content}')
                commenter.add_word_comments(
                    keyword=location,
                    comment_content=content
                    )
        
        
    
        