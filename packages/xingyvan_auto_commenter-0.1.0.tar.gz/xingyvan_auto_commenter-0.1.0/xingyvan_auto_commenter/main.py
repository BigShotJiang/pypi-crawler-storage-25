from .AutoCommenter import AutoCommenter
import os,sys

def main():
    acs= []
    homework_dir = sys.argv[1]
    #homework_dir = "./homeworks"
    for folder, _, file_name_list in os.walk(homework_dir):
        for file_name in file_name_list:
            if file_name.endswith('.docx'):
                file_path = os.path.join(folder, file_name)
                acs.append(AutoCommenter(file_path))
        break
    for ac in acs:
        ac.auto_comment()

if __name__=="__main__":
    main()