fn main() {
    std::process::exit(falcorn_cli::run_main());
}
