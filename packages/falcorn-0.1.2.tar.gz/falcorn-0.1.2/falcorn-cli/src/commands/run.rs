//! Run command implementation

use anyhow::Result;
use falcorn_core::config::{CliOverrides, ConfigParser, ProtocolType, ServerConfig, WorkerClass};
use falcorn_core::logging::ipc;
use falcorn_core::server::FalcornServer;
use std::path::PathBuf;

/// Options for running the server
pub struct RunOptions {
    pub app: Option<String>,
    pub app_module: Option<String>,
    pub app_callable: Option<String>,
    pub host: Option<String>,
    pub port: Option<u16>,
    pub backlog: Option<u32>,
    pub protocol: Option<String>,
    pub h2c: bool,
    pub no_h2c: bool,
    pub strict_http: bool,
    pub no_strict_http: bool,
    pub workers: Option<usize>,
    pub worker_class: Option<String>,
    pub worker_id: Option<u32>,
    pub timeout: Option<u64>,
    pub max_requests: Option<usize>,
    pub max_requests_jitter: Option<usize>,
    pub buffer_size: Option<usize>,
    pub keepalive: Option<u64>,
    pub max_connections: Option<usize>,
    pub sync_handler_threads: Option<usize>,
    pub sync_conn_queue_capacity: Option<usize>,
    pub async_worker_threads: Option<usize>,
    pub async_max_blocking_threads: Option<usize>,
    pub pythonpath: Vec<String>,
    pub asgi_event_loop: Option<String>,
    pub asgi_event_loop_fallback: bool,
    pub no_asgi_event_loop_fallback: bool,
    pub asgi_submit_timeout_ms: Option<u64>,
    pub asgi_scheduler: Option<String>,
    pub asgi_max_inflight: Option<usize>,
    pub asgi_send_pool_size: Option<usize>,
    pub worker_mode: bool,
    pub config: Option<PathBuf>,
    pub log_stdout: bool,
    pub no_log_stdout: bool,
    pub log_level: Option<String>,
    pub access_log_format: Option<String>,
    pub access_log: Option<String>,
    pub error_log: Option<String>,
    pub plugin_socket: Option<String>,
    pub plugin_auth_token: Option<String>,
    pub plugin_drop_policy: Option<String>,
    pub plugin_max_lagged_events: Option<usize>,
    pub plugin_write_timeout_ms: Option<u64>,
    pub plugin_bus_capacity: Option<usize>,
    pub plugin_max_clients: Option<usize>,
    pub plugin_subscribe_timeout_ms: Option<u64>,
    pub plugin_auth_fail_window_secs: Option<u64>,
    pub plugin_auth_fail_max_attempts: Option<usize>,
    pub plugin_acl_mode: Option<String>,
    pub plugin_socket_mode: Option<u32>,
    pub metrics_interval_ms: Option<u64>,
    pub metrics_workers_enabled: bool,
    pub no_metrics_workers_enabled: bool,
    pub metrics_os_enabled: bool,
    pub no_metrics_os_enabled: bool,
    pub metrics_percentiles_enabled: bool,
    pub no_metrics_percentiles_enabled: bool,
    pub metrics_top_errors_limit: Option<usize>,
    pub control_socket: Option<String>,
    pub control_auth_token: Option<String>,
    pub control_acl_mode: Option<String>,
    pub control_socket_mode: Option<u32>,
    pub ssl_enabled: bool,
    pub no_ssl_enabled: bool,
    pub ssl_certfile: Option<String>,
    pub ssl_keyfile: Option<String>,
    pub daemon: bool,
    pub pid: Option<PathBuf>,
}

/// Execute the run command
pub fn execute(opts: RunOptions) -> Result<()> {
    if opts.h2c && opts.no_h2c {
        anyhow::bail!("Conflicting flags: --h2c and --no-h2c");
    }
    if opts.strict_http && opts.no_strict_http {
        anyhow::bail!("Conflicting flags: --strict-http and --no-strict-http");
    }
    if opts.log_stdout && opts.no_log_stdout {
        anyhow::bail!("Conflicting flags: --log-stdout and --no-log-stdout");
    }
    if opts.ssl_enabled && opts.no_ssl_enabled {
        anyhow::bail!("Conflicting flags: --ssl-enabled and --no-ssl-enabled");
    }
    if opts.asgi_event_loop_fallback && opts.no_asgi_event_loop_fallback {
        anyhow::bail!(
            "Conflicting flags: --asgi-event-loop-fallback and --no-asgi-event-loop-fallback"
        );
    }
    if opts.metrics_workers_enabled && opts.no_metrics_workers_enabled {
        anyhow::bail!(
            "Conflicting flags: --metrics-workers-enabled and --no-metrics-workers-enabled"
        );
    }
    if opts.metrics_os_enabled && opts.no_metrics_os_enabled {
        anyhow::bail!("Conflicting flags: --metrics-os-enabled and --no-metrics-os-enabled");
    }
    if opts.metrics_percentiles_enabled && opts.no_metrics_percentiles_enabled {
        anyhow::bail!(
            "Conflicting flags: --metrics-percentiles-enabled and --no-metrics-percentiles-enabled"
        );
    }

    // Load base configuration
    let (mut config, loaded_from_file) = if let Some(config_path) = opts.config.as_ref() {
        println!("Loading configuration from: {}", config_path.display());
        (ConfigParser::parse_file(config_path)?, true)
    } else {
        (ServerConfig::default(), false)
    };
    // Apply environment overrides before CLI overrides so CLI remains highest precedence.
    config = ConfigParser::parse_env_vars(config);

    // Resolve app/module/callable with explicit precedence:
    // 1) --app-module/--app-callable
    // 2) positional app "module:callable"
    // 3) config file value (if loaded from file)
    let mut app_module_override = opts.app_module.clone();
    let mut app_callable_override = opts.app_callable.clone();
    if let Some(app) = opts.app.as_deref() {
        let (m, c) = parse_app(app)?;
        if app_module_override.is_none() {
            app_module_override = Some(m);
        }
        if app_callable_override.is_none() {
            app_callable_override = Some(c);
        }
    }

    match (&app_module_override, &app_callable_override) {
        (Some(_), None) | (None, Some(_)) => {
            anyhow::bail!("Both --app-module and --app-callable must be provided together");
        }
        (None, None) => {
            if !loaded_from_file {
                anyhow::bail!(
                    "Application is required. Use positional app 'module:callable' or --app-module/--app-callable"
                );
            }
        }
        _ => {}
    }

    if loaded_from_file {
        let cli_overrides = build_cli_overrides(
            &opts,
            app_module_override.clone(),
            app_callable_override.clone(),
        );
        config = ConfigParser::merge_with_cli(config, cli_overrides)?;
    } else {
        // No TOML config: apply values directly on default config.
        if let (Some(module), Some(callable)) = (app_module_override, app_callable_override) {
            config.app_module = module;
            config.app_callable = callable;
        }

        if let Some(host) = opts.host {
            config.host = host;
        }
        if let Some(port) = opts.port {
            config.port = port;
        }
        if let Some(backlog) = opts.backlog {
            config.backlog = backlog;
        }
        if let Some(protocol) = opts.protocol {
            config.protocol = ProtocolType::from_str(&protocol)?;
        }
        if opts.h2c {
            config.h2c_enabled = true;
        } else if opts.no_h2c {
            config.h2c_enabled = false;
        }
        if opts.strict_http {
            config.strict_http = true;
        } else if opts.no_strict_http {
            config.strict_http = false;
        }
        if let Some(workers) = opts.workers {
            config.workers = Some(workers);
        }
        if let Some(worker_class) = opts.worker_class {
            config.worker_class = WorkerClass::from_str(&worker_class)?;
        }
        if let Some(timeout) = opts.timeout {
            config.worker_timeout = timeout;
        }
        if opts.worker_mode {
            config.worker_mode = true;
        }
        if let Some(max_requests) = opts.max_requests {
            config.max_requests = Some(max_requests);
        }
        if let Some(max_requests_jitter) = opts.max_requests_jitter {
            config.max_requests_jitter = Some(max_requests_jitter);
        }
        if let Some(buffer_size) = opts.buffer_size {
            config.buffer_size = buffer_size;
        }
        if let Some(keepalive) = opts.keepalive {
            config.keepalive_timeout = keepalive;
        }
        if let Some(max_connections) = opts.max_connections {
            config.max_connections = max_connections;
        }
        if let Some(sync_handler_threads) = opts.sync_handler_threads {
            config.sync_handler_threads = sync_handler_threads;
        }
        if let Some(sync_conn_queue_capacity) = opts.sync_conn_queue_capacity {
            config.sync_conn_queue_capacity = sync_conn_queue_capacity;
        }
        if let Some(async_worker_threads) = opts.async_worker_threads {
            config.async_worker_threads = async_worker_threads;
        }
        if let Some(async_max_blocking_threads) = opts.async_max_blocking_threads {
            config.async_max_blocking_threads = async_max_blocking_threads;
        }
        if !opts.pythonpath.is_empty() {
            config.pythonpath = opts.pythonpath;
        }
        if let Some(asgi_event_loop) = opts.asgi_event_loop {
            config.asgi_event_loop = asgi_event_loop;
        }
        if opts.asgi_event_loop_fallback {
            config.asgi_event_loop_fallback = true;
        } else if opts.no_asgi_event_loop_fallback {
            config.asgi_event_loop_fallback = false;
        }
        if let Some(asgi_submit_timeout_ms) = opts.asgi_submit_timeout_ms {
            config.asgi_submit_timeout_ms = asgi_submit_timeout_ms;
        }
        if let Some(asgi_scheduler) = opts.asgi_scheduler {
            config.asgi_scheduler = asgi_scheduler;
        }
        if let Some(asgi_max_inflight) = opts.asgi_max_inflight {
            config.asgi_max_inflight = asgi_max_inflight;
        }
        if let Some(asgi_send_pool_size) = opts.asgi_send_pool_size {
            config.asgi_send_pool_size = asgi_send_pool_size;
        }
        if opts.log_stdout {
            config.log_stdout = true;
        } else if opts.no_log_stdout {
            config.log_stdout = false;
        }
        if let Some(log_level) = opts.log_level {
            config.log_level = log_level;
        }
        if let Some(access_log_format) = opts.access_log_format {
            config.access_log_format = access_log_format;
        }
        if let Some(access_log) = opts.access_log {
            config.access_log = Some(access_log);
        }
        if let Some(error_log) = opts.error_log {
            config.error_log = Some(error_log);
        }
        if let Some(plugin_socket) = opts.plugin_socket {
            config.plugin_socket = Some(plugin_socket);
        }
        if let Some(plugin_auth_token) = opts.plugin_auth_token {
            config.plugin_auth_token = Some(plugin_auth_token);
        }
        if let Some(plugin_drop_policy) = opts.plugin_drop_policy {
            config.plugin_drop_policy = plugin_drop_policy;
        }
        if let Some(plugin_max_lagged_events) = opts.plugin_max_lagged_events {
            config.plugin_max_lagged_events = plugin_max_lagged_events;
        }
        if let Some(plugin_write_timeout_ms) = opts.plugin_write_timeout_ms {
            config.plugin_write_timeout_ms = plugin_write_timeout_ms;
        }
        if let Some(plugin_bus_capacity) = opts.plugin_bus_capacity {
            config.plugin_bus_capacity = plugin_bus_capacity;
        }
        if let Some(plugin_max_clients) = opts.plugin_max_clients {
            config.plugin_max_clients = plugin_max_clients;
        }
        if let Some(plugin_subscribe_timeout_ms) = opts.plugin_subscribe_timeout_ms {
            config.plugin_subscribe_timeout_ms = plugin_subscribe_timeout_ms;
        }
        if let Some(plugin_auth_fail_window_secs) = opts.plugin_auth_fail_window_secs {
            config.plugin_auth_fail_window_secs = plugin_auth_fail_window_secs;
        }
        if let Some(plugin_auth_fail_max_attempts) = opts.plugin_auth_fail_max_attempts {
            config.plugin_auth_fail_max_attempts = plugin_auth_fail_max_attempts;
        }
        if let Some(plugin_acl_mode) = opts.plugin_acl_mode {
            config.plugin_acl_mode = plugin_acl_mode;
        }
        if let Some(plugin_socket_mode) = opts.plugin_socket_mode {
            config.plugin_socket_mode = plugin_socket_mode;
        }
        if let Some(metrics_interval_ms) = opts.metrics_interval_ms {
            config.metrics_interval_ms = metrics_interval_ms;
        }
        if opts.metrics_workers_enabled {
            config.metrics_workers_enabled = true;
        } else if opts.no_metrics_workers_enabled {
            config.metrics_workers_enabled = false;
        }
        if opts.metrics_os_enabled {
            config.metrics_os_enabled = true;
        } else if opts.no_metrics_os_enabled {
            config.metrics_os_enabled = false;
        }
        if opts.metrics_percentiles_enabled {
            config.metrics_percentiles_enabled = true;
        } else if opts.no_metrics_percentiles_enabled {
            config.metrics_percentiles_enabled = false;
        }
        if let Some(metrics_top_errors_limit) = opts.metrics_top_errors_limit {
            config.metrics_top_errors_limit = metrics_top_errors_limit;
        }
        if let Some(control_socket) = opts.control_socket {
            config.control_socket = Some(control_socket);
        }
        if let Some(control_auth_token) = opts.control_auth_token {
            config.control_auth_token = Some(control_auth_token);
        }
        if let Some(control_acl_mode) = opts.control_acl_mode {
            config.control_acl_mode = control_acl_mode;
        }
        if let Some(control_socket_mode) = opts.control_socket_mode {
            config.control_socket_mode = control_socket_mode;
        }
        if opts.ssl_enabled {
            config.ssl_enabled = true;
        } else if opts.no_ssl_enabled {
            config.ssl_enabled = false;
        }
        if let Some(ssl_certfile) = opts.ssl_certfile {
            config.ssl_certfile = Some(ssl_certfile);
        }
        if let Some(ssl_keyfile) = opts.ssl_keyfile {
            config.ssl_keyfile = Some(ssl_keyfile);
        }
    }

    // Handle daemon mode
    if opts.daemon {
        #[cfg(unix)]
        {
            daemonize(opts.pid)?;
        }
        #[cfg(not(unix))]
        {
            anyhow::bail!("Daemon mode is only supported on Unix systems");
        }
    } else if let Some(pid_file) = opts.pid {
        // Write PID file in foreground mode
        super::utils::write_pid_file(&pid_file, std::process::id())?;
    }

    // Print banner
    // print_banner(&config);

    let result = if !config.worker_mode {
        // Then run master mode
        run_master_mode(&config) //.await
    } else {
        // run worker mode
        run_worker_mode(&config, opts.worker_id) //.await
    };

    result
}

/// Daemonize the process (Unix only)
#[cfg(unix)]
fn daemonize(pid_file: Option<PathBuf>) -> Result<()> {
    use std::process::{Command, Stdio};

    println!("🔄 Starting daemon...");

    let exe = std::env::current_exe()?;
    let args: Vec<String> = std::env::args()
        .skip(1)
        .filter(|arg| arg != "--daemon" && arg != "-d")
        .collect();

    // Fork and run in background
    let child = Command::new(exe)
        .args(&args)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()?;

    if let Some(pid_path) = pid_file {
        super::utils::write_pid_file(&pid_path, child.id())?;
        println!("✓ Daemon started with PID: {}", child.id());
        println!("  PID file: {}", pid_path.display());
    } else {
        println!("✓ Daemon started with PID: {}", child.id());
    }

    std::process::exit(0);
}

fn parse_app(app: &str) -> Result<(String, String)> {
    let (module, callable) = app
        .split_once(':')
        .ok_or_else(|| anyhow::anyhow!("Invalid app format. Expected 'module:callable'"))?;
    if module.is_empty() || callable.is_empty() {
        anyhow::bail!("Invalid app format. Expected non-empty 'module:callable'");
    }
    Ok((module.to_string(), callable.to_string()))
}

fn build_cli_overrides(
    opts: &RunOptions,
    app_module: Option<String>,
    app_callable: Option<String>,
) -> CliOverrides {
    let h2c_enabled = if opts.h2c {
        Some(true)
    } else if opts.no_h2c {
        Some(false)
    } else {
        None
    };

    let strict_http = if opts.strict_http {
        Some(true)
    } else if opts.no_strict_http {
        Some(false)
    } else {
        None
    };

    let log_stdout = if opts.log_stdout {
        Some(true)
    } else if opts.no_log_stdout {
        Some(false)
    } else {
        None
    };

    let ssl_enabled = if opts.ssl_enabled {
        Some(true)
    } else if opts.no_ssl_enabled {
        Some(false)
    } else {
        None
    };

    let asgi_event_loop_fallback = if opts.asgi_event_loop_fallback {
        Some(true)
    } else if opts.no_asgi_event_loop_fallback {
        Some(false)
    } else {
        None
    };

    CliOverrides {
        app_module,
        app_callable,
        host: opts.host.clone(),
        port: opts.port,
        backlog: opts.backlog,
        workers: opts.workers,
        protocol: opts.protocol.clone(),
        worker_class: opts.worker_class.clone(),
        timeout: opts.timeout,
        worker_mode: if opts.worker_mode { Some(true) } else { None },
        h2c_enabled,
        strict_http,
        max_requests: opts.max_requests,
        max_requests_jitter: opts.max_requests_jitter,
        buffer_size: opts.buffer_size,
        keepalive_timeout: opts.keepalive,
        max_connections: opts.max_connections,
        sync_handler_threads: opts.sync_handler_threads,
        sync_conn_queue_capacity: opts.sync_conn_queue_capacity,
        async_worker_threads: opts.async_worker_threads,
        async_max_blocking_threads: opts.async_max_blocking_threads,
        log_stdout,
        log_level: opts.log_level.clone(),
        access_log_format: opts.access_log_format.clone(),
        access_log: opts.access_log.clone(),
        error_log: opts.error_log.clone(),
        plugin_socket: opts.plugin_socket.clone(),
        plugin_auth_token: opts.plugin_auth_token.clone(),
        plugin_drop_policy: opts.plugin_drop_policy.clone(),
        plugin_max_lagged_events: opts.plugin_max_lagged_events,
        plugin_write_timeout_ms: opts.plugin_write_timeout_ms,
        plugin_bus_capacity: opts.plugin_bus_capacity,
        plugin_max_clients: opts.plugin_max_clients,
        plugin_subscribe_timeout_ms: opts.plugin_subscribe_timeout_ms,
        plugin_auth_fail_window_secs: opts.plugin_auth_fail_window_secs,
        plugin_auth_fail_max_attempts: opts.plugin_auth_fail_max_attempts,
        plugin_acl_mode: opts.plugin_acl_mode.clone(),
        plugin_socket_mode: opts.plugin_socket_mode,
        metrics_interval_ms: opts.metrics_interval_ms,
        metrics_workers_enabled: if opts.metrics_workers_enabled {
            Some(true)
        } else if opts.no_metrics_workers_enabled {
            Some(false)
        } else {
            None
        },
        metrics_os_enabled: if opts.metrics_os_enabled {
            Some(true)
        } else if opts.no_metrics_os_enabled {
            Some(false)
        } else {
            None
        },
        metrics_percentiles_enabled: if opts.metrics_percentiles_enabled {
            Some(true)
        } else if opts.no_metrics_percentiles_enabled {
            Some(false)
        } else {
            None
        },
        metrics_top_errors_limit: opts.metrics_top_errors_limit,
        control_socket: opts.control_socket.clone(),
        control_auth_token: opts.control_auth_token.clone(),
        control_acl_mode: opts.control_acl_mode.clone(),
        control_socket_mode: opts.control_socket_mode,
        ssl_enabled,
        ssl_certfile: opts.ssl_certfile.clone(),
        ssl_keyfile: opts.ssl_keyfile.clone(),
        pythonpath: if opts.pythonpath.is_empty() {
            None
        } else {
            Some(opts.pythonpath.clone())
        },
        asgi_event_loop: opts.asgi_event_loop.clone(),
        asgi_event_loop_fallback,
        asgi_submit_timeout_ms: opts.asgi_submit_timeout_ms,
        asgi_scheduler: opts.asgi_scheduler.clone(),
        asgi_max_inflight: opts.asgi_max_inflight,
        asgi_send_pool_size: opts.asgi_send_pool_size,
    }
}

/// Run Falcorn in Master Mode
fn run_master_mode(config: &ServerConfig) -> Result<()> {
    // Spawn logger daemon (master only) if logging is enabled
    if config.access_events_enabled() {
        let _ = spawn_logger_daemon(config);
    }

    // Create Falcorn server instance
    let mut server = FalcornServer::new(config.clone())?;

    // Banner
    print_banner(&config);

    // Run server
    if let Err(e) = server.run() {
        anyhow::bail!("{:?}", e,)
    } else {
        Ok(())
    }
}

fn spawn_logger_daemon(config: &ServerConfig) -> Result<()> {
    use std::process::{Command, Stdio};

    let exe = std::env::current_exe()?;
    let socket = ipc::socket_path();

    let mut cmd = Command::new(exe);
    cmd.arg("logger-daemon")
        .arg("--socket")
        .arg(socket)
        .arg("--access-log-format")
        .arg(config.access_log_format.clone());

    if let Some(access_log) = config.access_log.clone() {
        cmd.arg("--access-log").arg(access_log);
    }
    if let Some(error_log) = config.error_log.clone() {
        cmd.arg("--error-log").arg(error_log);
    }
    if let Some(plugin_socket) = config.plugin_socket.clone() {
        cmd.arg("--plugin-socket").arg(plugin_socket);
    }
    if let Some(plugin_auth_token) = config.plugin_auth_token.clone() {
        cmd.arg("--plugin-auth-token").arg(plugin_auth_token);
    }
    cmd.arg("--plugin-drop-policy")
        .arg(config.plugin_drop_policy.clone());
    cmd.arg("--plugin-max-lagged-events")
        .arg(config.plugin_max_lagged_events.to_string());
    cmd.arg("--plugin-write-timeout-ms")
        .arg(config.plugin_write_timeout_ms.to_string());
    cmd.arg("--plugin-bus-capacity")
        .arg(config.plugin_bus_capacity.to_string());
    cmd.arg("--plugin-max-clients")
        .arg(config.plugin_max_clients.to_string());
    cmd.arg("--plugin-subscribe-timeout-ms")
        .arg(config.plugin_subscribe_timeout_ms.to_string());
    cmd.arg("--plugin-auth-fail-window-secs")
        .arg(config.plugin_auth_fail_window_secs.to_string());
    cmd.arg("--plugin-auth-fail-max-attempts")
        .arg(config.plugin_auth_fail_max_attempts.to_string());
    cmd.arg("--plugin-acl-mode")
        .arg(config.plugin_acl_mode.clone());
    cmd.arg("--plugin-socket-mode")
        .arg(format!("{:o}", config.plugin_socket_mode));
    cmd.arg("--metrics-interval-ms")
        .arg(config.metrics_interval_ms.to_string());
    if config.metrics_workers_enabled {
        cmd.arg("--metrics-workers-enabled");
    } else {
        cmd.arg("--no-metrics-workers-enabled");
    }
    if config.metrics_os_enabled {
        cmd.arg("--metrics-os-enabled");
    } else {
        cmd.arg("--no-metrics-os-enabled");
    }
    if config.metrics_percentiles_enabled {
        cmd.arg("--metrics-percentiles-enabled");
    } else {
        cmd.arg("--no-metrics-percentiles-enabled");
    }
    cmd.arg("--metrics-top-errors-limit")
        .arg(config.metrics_top_errors_limit.to_string());
    if config.log_stdout {
        cmd.arg("--log-stdout");
    }

    cmd.stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()?;

    Ok(())
}

/// Run server in worker mode
fn run_worker_mode(config: &ServerConfig, worker_id: Option<u32>) -> Result<()> {
    let worker_id = worker_id.expect("Worker ID required in worker mode");

    // Run worker
    let mut worker = FalcornServer::new_worker(config.clone(), worker_id as u32)?;

    if let Err(e) = worker.run() {
        anyhow::bail!("{:?}", e)
    } else {
        Ok(())
    }
}

/// Print startup banner
fn print_banner(config: &ServerConfig) {
    println!();
    super::utils::print_falcorn();
    println!();
    println!("   ═══════════════════════════════════");
    println!("   Address:      {}:{}", config.host, config.port);
    println!(
        "   Workers:      {} ({})",
        config.worker_count(),
        config.worker_class.as_str()
    );
    println!("   Interface:    {}", config.protocol.as_str());
    println!(
        "   H2C:          {}",
        if config.h2c_enabled {
            "enabled"
        } else {
            "disabled"
        }
    );
    println!("   Timeout:      {}s", config.worker_timeout);
    println!("   Keepalive:    {}s", config.keepalive_timeout);
    println!("   Max Conns:    {}", config.max_connections);
    println!(
        "   App:          {}:{}",
        config.app_module, config.app_callable
    );
    if !config.pythonpath.is_empty() {
        println!("   Python Path:  {:?}", config.pythonpath);
    }
    println!("   ═══════════════════════════════════");
    println!();
}
