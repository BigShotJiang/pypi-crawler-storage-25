//! Initialize project command

use anyhow::Result;
use std::fs;
use std::path::PathBuf;

/// Execute the init command
pub fn execute(project_type: String, output: PathBuf, force: bool) -> Result<()> {
    // Check if file exists
    if output.exists() && !force {
        anyhow::bail!(
            "Configuration file already exists: {}\nUse --force to overwrite",
            output.display()
        );
    }

    // Get template content
    let template = get_template(&project_type)?;

    // Ensure parent directory exists
    super::utils::ensure_directory(&output)?;

    // Write template
    fs::write(&output, template)?;

    // Print success message
    println!("✓ Created {} configuration file", project_type);
    println!("  File: {}", output.display());
    println!();
    println!("Next steps:");
    println!(
        "  1. Edit {} to configure your application",
        output.display()
    );
    println!(
        "  2. Run: falcorn run --config {} your_app:application",
        output.display()
    );
    println!();

    // Print template-specific instructions
    print_template_instructions(&project_type);

    Ok(())
}

/// Get template content based on project type
fn get_template(project_type: &str) -> Result<String> {
    let template = match project_type.to_lowercase().as_str() {
        "flask" => FLASK_TEMPLATE,
        "django" => DJANGO_TEMPLATE,
        "fastapi" => FASTAPI_TEMPLATE,
        "generic" => GENERIC_TEMPLATE,
        other => anyhow::bail!(
            "Unknown project type: '{}'\nValid types: flask, django, fastapi, generic",
            other
        ),
    };

    Ok(template.to_string())
}

/// Print template-specific instructions
fn print_template_instructions(project_type: &str) {
    match project_type.to_lowercase().as_str() {
        "flask" => {
            println!("Flask Configuration:");
            println!("  • Update 'app.module' to match your Flask app module");
            println!("  • Update 'app.callable' to your Flask app variable name");
            println!("  • Use 'sync' workers for Flask applications");
            println!("  • Example: falcorn run --config falcorn.toml myapp:app");
        }
        "django" => {
            println!("Django Configuration:");
            println!("  • Update 'app.module' to 'your_project.wsgi'");
            println!("  • Keep 'app.callable' as 'application'");
            println!("  • Ensure DJANGO_SETTINGS_MODULE is set");
            println!("  • Example: DJANGO_SETTINGS_MODULE=myproject.settings Falcorn run ...");
        }
        "fastapi" => {
            println!("FastAPI Configuration:");
            println!("  • Update 'app.module' to your FastAPI module");
            println!("  • Update 'app.callable' to your FastAPI app variable");
            println!("  • Use 'async' workers for FastAPI");
            println!("  • Example: falcorn run --worker-class async --config falcorn.toml");
        }
        _ => {
            println!("Generic Configuration:");
            println!("  • Update 'app.module' and 'app.callable' for your app");
            println!("  • Choose 'sync' or 'async' worker class based on your app");
        }
    }
    println!();
}

// Templates
const FLASK_TEMPLATE: &str = r#"# Flask Application Configuration

[server]
host = "127.0.0.1"
port = 8000
backlog = 2048

[workers]
count = 4
class = "sync"        # Flask uses blocking I/O
timeout = 30
max_requests = 1000
max_requests_jitter = 50

[performance]
buffer_size = 4096
keepalive_timeout = 5
max_connections = 2048

[app]
module = "app"        # Change to your Flask module
callable = "app"      # Change to your Flask app variable name
pythonpath = []
asgi_event_loop = "asyncio"
asgi_event_loop_fallback = true
asgi_submit_timeout_ms = 30000
asgi_scheduler = "task"
asgi_max_inflight = 2048
asgi_send_pool_size = 4096

[logging]
level = "INFO"
format = "%(h)s %(l)s %(u)s %(t)s \"%(r)s\" %(s)s %(b)s"
access_log = "./logs/access.log"
error_log = "./logs/error.log"
plugin_drop_policy = "drop_oldest"
plugin_max_lagged_events = 2048
plugin_write_timeout_ms = 500
plugin_bus_capacity = 8192
plugin_max_clients = 1024
plugin_subscribe_timeout_ms = 5000
plugin_auth_fail_window_secs = 60
plugin_auth_fail_max_attempts = 10
plugin_acl_mode = "same_user"
plugin_socket_mode = 0o660

[ssl]
enabled = false
# certfile = "./certs/cert.pem"
# keyfile = "./certs/key.pem"
"#;

const DJANGO_TEMPLATE: &str = r#"# Django Application Configuration

[server]
host = "0.0.0.0"
port = 8000
backlog = 2048

[workers]
count = 4
class = "sync"        # Django with mod_wsgi compatibility
timeout = 30
max_requests = 1000

[performance]
buffer_size = 4096
keepalive_timeout = 5
max_connections = 2048

[app]
module = "myproject.wsgi"    # Change to your Django project
callable = "application"
pythonpath = ["."]
asgi_event_loop = "asyncio"
asgi_event_loop_fallback = true
asgi_submit_timeout_ms = 30000
asgi_scheduler = "task"
asgi_max_inflight = 2048
asgi_send_pool_size = 4096

[logging]
level = "INFO"
access_log = "./logs/access.log"
error_log = "./logs/error.log"
plugin_drop_policy = "drop_oldest"
plugin_max_lagged_events = 2048
plugin_write_timeout_ms = 500
plugin_bus_capacity = 8192
plugin_max_clients = 1024
plugin_subscribe_timeout_ms = 5000
plugin_auth_fail_window_secs = 60
plugin_auth_fail_max_attempts = 10
plugin_acl_mode = "same_user"
plugin_socket_mode = 0o660

[ssl]
enabled = false
"#;

const FASTAPI_TEMPLATE: &str = r#"# FastAPI Application Configuration

[server]
host = "0.0.0.0"
port = 8000
backlog = 2048

[workers]
count = 8
class = "async"       # FastAPI works best with async workers
timeout = 30
max_requests = 1000

[performance]
buffer_size = 8192
keepalive_timeout = 5
max_connections = 4096

[app]
module = "main"       # Change to your FastAPI module
callable = "app"      # Change to your FastAPI app variable
pythonpath = []
asgi_event_loop = "asyncio"  # or "uvloop"
asgi_event_loop_fallback = true
asgi_submit_timeout_ms = 30000
asgi_scheduler = "task"
asgi_max_inflight = 2048
asgi_send_pool_size = 4096

[logging]
level = "DEBUG"
access_log = "./logs/access.log"
error_log = "./logs/error.log"
plugin_drop_policy = "drop_oldest"
plugin_max_lagged_events = 2048
plugin_write_timeout_ms = 500
plugin_bus_capacity = 8192
plugin_max_clients = 1024
plugin_subscribe_timeout_ms = 5000
plugin_auth_fail_window_secs = 60
plugin_auth_fail_max_attempts = 10
plugin_acl_mode = "same_user"
plugin_socket_mode = 0o660

[ssl]
enabled = false
"#;

const GENERIC_TEMPLATE: &str = r#"# Generic WSGI Application Configuration

[server]
host = "127.0.0.1"
port = 8000
backlog = 2048

[workers]
count = 4
class = "sync"        # Change to "async" for async-capable apps
timeout = 30

[performance]
buffer_size = 4096
keepalive_timeout = 5
max_connections = 2048

[app]
module = "app"
callable = "application"
pythonpath = []
asgi_event_loop = "asyncio"
asgi_event_loop_fallback = true
asgi_submit_timeout_ms = 30000
asgi_scheduler = "task"
asgi_max_inflight = 2048
asgi_send_pool_size = 4096

[logging]
level = "INFO"
access_log = "./logs/access.log"
error_log = "./logs/error.log"
plugin_drop_policy = "drop_oldest"
plugin_max_lagged_events = 2048
plugin_write_timeout_ms = 500
plugin_bus_capacity = 8192
plugin_max_clients = 1024
plugin_subscribe_timeout_ms = 5000
plugin_auth_fail_window_secs = 60
plugin_auth_fail_max_attempts = 10
plugin_acl_mode = "same_user"
plugin_socket_mode = 0o660

[ssl]
enabled = false
"#;
