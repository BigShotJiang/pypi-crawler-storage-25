//! Stop command implementation

use anyhow::Result;
use std::path::PathBuf;

/// Execute the stop command
pub async fn execute(pid_file: Option<PathBuf>, force: bool) -> Result<()> {
    let pid_path = pid_file.unwrap_or_else(|| PathBuf::from("falcorn.pid"));

    if !pid_path.exists() {
        println!("✗ Server is not running (PID file not found)");
        return Ok(());
    }

    let pid = super::utils::read_pid_file(&pid_path)?;

    if !super::utils::is_process_running(pid) {
        println!("✗ Server is not running (stale PID file)");
        println!("  Removing PID file: {}", pid_path.display());
        std::fs::remove_file(&pid_path)?;
        return Ok(());
    }

    println!("Stopping server (PID: {})...", pid);

    if force {
        println!("  Force stop requested");
        super::restart::send_force_stop(pid)?;
    } else {
        println!("  Graceful stop requested");
        super::restart::send_graceful_stop(pid)?;
    }

    // Wait for process to stop
    super::restart::wait_for_process_stop(pid, 30).await?;

    // Remove PID file
    std::fs::remove_file(&pid_path)?;

    println!("✓ Server stopped");
    println!("  PID file removed: {}", pid_path.display());

    Ok(())
}
