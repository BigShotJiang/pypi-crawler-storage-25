//! Restart command implementation

use anyhow::Result;
use std::path::PathBuf;

/// Execute the restart command
pub async fn execute(pid_file: Option<PathBuf>, graceful: bool) -> Result<()> {
    let pid_path = pid_file
        .clone()
        .unwrap_or_else(|| PathBuf::from("falcorn.pid"));

    println!("Restarting server...");

    // Stop current server
    if pid_path.exists() {
        let pid = super::utils::read_pid_file(&pid_path)?;

        if super::utils::is_process_running(pid) {
            println!("  Stopping current server (PID: {})...", pid);

            if graceful {
                send_graceful_stop(pid)?;
            } else {
                send_force_stop(pid)?;
            }

            // Wait for process to stop
            wait_for_process_stop(pid, 30).await?;
            println!("  ✓ Server stopped");
        } else {
            println!("  ⚠️  Server not running (stale PID file)");
        }

        // Remove PID file
        std::fs::remove_file(&pid_path)?;
    } else {
        println!("  No running server found");
    }

    println!();
    println!("  Please restart the server manually with:");
    println!("    falcorn run --pid {} <options>", pid_path.display());

    Ok(())
}

#[cfg(unix)]
pub fn send_graceful_stop(pid: u32) -> Result<()> {
    use std::process::Command;

    Command::new("kill")
        .arg("-TERM")
        .arg(pid.to_string())
        .status()?;

    Ok(())
}

#[cfg(not(unix))]
pub fn send_graceful_stop(pid: u32) -> Result<()> {
    use std::process::Command;

    Command::new("taskkill")
        .args(&["/PID", &pid.to_string()])
        .status()?;

    Ok(())
}

#[cfg(unix)]
pub fn send_force_stop(pid: u32) -> Result<()> {
    use std::process::Command;

    Command::new("kill")
        .arg("-KILL")
        .arg(pid.to_string())
        .status()?;

    Ok(())
}

#[cfg(not(unix))]
pub fn send_force_stop(pid: u32) -> Result<()> {
    use std::process::Command;

    Command::new("taskkill")
        .args(&["/F", "/PID", &pid.to_string()])
        .status()?;

    Ok(())
}

pub async fn wait_for_process_stop(pid: u32, max_wait: u32) -> Result<()> {
    use tokio::time::{Duration, sleep};

    for _ in 0..max_wait {
        if !super::utils::is_process_running(pid) {
            return Ok(());
        }
        sleep(Duration::from_secs(1)).await;
    }

    anyhow::bail!("Timeout waiting for process to stop");
}
