// Falcorn-cli/src/commands/dev.rs
//! Development mode command with hot reload

use std::path::PathBuf;
use std::time::Duration;
use std::sync::{Arc, atomic::{AtomicBool, Ordering}};
use notify::{Watcher, RecursiveMode, recommended_watcher};
use notify::event::{EventKind, ModifyKind};
use tokio::sync::mpsc;
use anyhow::Result;

use falcorn_core::config::{ServerConfig, WorkerClass};
use falcorn_core::server::FalcornServer;

/// Options for dev mode
#[derive(Clone)]
pub struct DevOptions {
    pub app: String,
    pub host: String,
    pub port: u16,
    pub watch: Option<PathBuf>,
    pub workers: usize,
    pub pythonpath: Vec<String>,
    pub reload: bool,
}

/// Execute the dev command
pub fn execute(opts: DevOptions) -> Result<()> {
    // Parse app string
    let parts: Vec<&str> = opts.app.split(':').collect();
    if parts.len() != 2 {
        anyhow::bail!(
            "Invalid app format. Expected 'module:callable', got '{}'",
            opts.app
        );
    }

    let app_module = parts[0].to_string();
    let app_callable = parts[1].to_string();

    // Print dev mode banner
    print_dev_banner(&opts);

    if opts.reload {
        // Run with file watcher
        run_with_reload(opts, app_module, app_callable)
    } else {
        // Run without reload
        run_without_reload(opts, app_module, app_callable)
    }
}

/// Run server with hot reload
async fn run_with_reload(
    opts: DevOptions,
    app_module: String,
    app_callable: String,
) -> Result<()> {

    println!("🔄 Hot reload enabled");
    
    let watch_path = opts.watch.clone().unwrap_or_else(|| PathBuf::from("."));
    println!("   Watching: {}", watch_path.display());
    println!();

    // Create channel for file system events
    let (tx, mut rx) = mpsc::channel(100);

    // Setup file watcher
    let tx_clone = tx.clone();
    let mut watcher = recommended_watcher(move |res: notify::Result<notify::Event>| {
        if let Ok(event) = res {
            // Filter for Python file modifications
            if is_python_file_event(&event) {
                let _ = tx_clone.try_send(event);
            }
        }
    })?;

    watcher.watch(&watch_path, RecursiveMode::Recursive)?;

    // Shared shutdown flag
    let shutdown = Arc::new(AtomicBool::new(false));

    // Run server loop
    loop {
        if shutdown.load(Ordering::Relaxed) {
            break;
        }

        println!("🚀 Starting development server...");
        
        // Create server task
        let opts_clone = opts.clone();
        let app_module_clone = app_module.clone();
        let app_callable_clone = app_callable.clone();
        let _shutdown_clone = Arc::clone(&shutdown);

        let mut server_task = Some(tokio::spawn(async move {
            run_server_once(opts_clone, app_module_clone, app_callable_clone).await
        }));

        // Wait for file change or server error
        tokio::select! {
            // Event from watcher
            Some(event) = rx.recv() => {
                println!("\n📝 File changed: {:?}", event.paths);
                println!("   Reloading server...\n");
                
                // Abort current server
                if let Some(task) = server_task.take() {
                    task.abort();
                }
                
                // Brief delay before restart
                tokio::time::sleep(Duration::from_millis(500)).await;
            }

            // Server finished
            result = async {
                    // Extract the task
                    match server_task.take() {
                        Some(task) => Some(task.await),
                        None => None,
                    }
                } => {
                    if let Some(result) = result {
                    match result {
                        Ok(Ok(())) => {
                            println!("Server stopped normally");
                        }
                        Ok(Err(e)) => {
                            eprintln!("❌ Server error: {}", e);
                            eprintln!("   Waiting 2 seconds before restart...");
                            tokio::time::sleep(Duration::from_secs(2)).await;
                        }
                        Err(e) if e.is_cancelled() => {
                            // Task was cancelled for reload, continue
                        }
                        Err(e) => {
                            eprintln!("❌ Task error: {}", e);
                            tokio::time::sleep(Duration::from_secs(2)).await;
                        }
                    }
                }
            }
        }
    }

    Ok(())
}

/// Run server without reload
async fn run_without_reload(
    opts: DevOptions,
    app_module: String,
    app_callable: String,
) -> Result<()> {
    println!("🚀 Starting development server (without hot-reload)...\n");
    run_server_once(opts, app_module, app_callable).await
}

/// Run server once
async fn run_server_once(
    opts: DevOptions,
    app_module: String,
    app_callable: String,
) -> Result<()> {
    // Create configuration
    let mut config = ServerConfig::new(app_module, app_callable);
    config.host = opts.host;
    config.port = opts.port;
    config.workers = Some(opts.workers);
    config.worker_class = WorkerClass::Sync;
    config.worker_timeout = 30;
    config.log_level = "DEBUG".to_string();     // Absolute debug for dev mode
    config.log_stdout = true;                   // Absolute logging 
    config.pythonpath = opts.pythonpath;        //.iter().map(PathBuf::from).collect();
    config.buffer_size = 4096;
    config.keepalive_timeout = 5;
    config.max_connections = 1024;

    // Validate
    config.validate()?;

    println!("✓ Configuration validated");
    println!("  App: {}:{}", config.app_module, config.app_callable);
    println!("  Address: {}:{}", config.host, config.port);
    println!("  Workers: {}", config.workers.unwrap_or(1));
    println!();

    // Create and run server
    let mut server = FalcornServer::new(config)?;
    
    // Setup graceful shutdown for dev mode
    setup_dev_shutdown(Arc::new(server.clone())).await;
    
    server.run().await?;

    Ok(())
}

/// Setup graceful shutdown for dev mode
async fn setup_dev_shutdown(server: Arc<FalcornServer>) {
    use tokio::signal;
    
    
    let server_clone = Arc::clone(&server);
    
    tokio::spawn(async move {
        #[cfg(unix)]
        {
            let mut sigint = signal::unix::signal(signal::unix::SignalKind::interrupt())
                .expect("Failed to setup SIGINT handler");
            
            sigint.recv().await;
        }
        
        #[cfg(not(unix))]
        {
            let _ = signal::ctrl_c().await;
        }
        
        println!("\n🛑 Shutting down development server...");
        
        // if let Err(e) = server_clone.graceful_shutdown().await {
        //     eprintln!("Error during shutdown: {}", e);
        // }

        std::process::exit(0);
    });
}

/// Check if event is for a Python file
fn is_python_file_event(event: &notify::Event) -> bool {
    
    // Only process modify events
    match event.kind {
        EventKind::Modify(ModifyKind::Data(_)) |
        EventKind::Create(_) |
        EventKind::Remove(_) => {
            // Check if any path is a Python file
            event.paths.iter().any(|path| {
                path.extension()
                    .and_then(|ext| ext.to_str())
                    .map(|ext| ext == "py" || ext == "pyw")
                    .unwrap_or(false)
            })
        }
        _ => false,
    }
}

/// Print dev mode banner
fn print_dev_banner(opts: &DevOptions) {
    println!();
    super::utils::print_falcorn();
    println!("╔════════════════════════════════════════════╗");
    println!("║      🛠️  Falcorn Development Mode         ║");
    println!("╚════════════════════════════════════════════╝");
    println!();
    println!("  Address:      {}:{}", opts.host, opts.port);
    println!("  Workers:      {}", opts.workers);
    println!("  App:          {}", opts.app);
    println!("  Hot Reload:   {}", if opts.reload { "✓ Enabled" } else { "✗ Disabled" });
    if let Some(ref watch) = opts.watch {
        println!("  Watch Dir:    {}", watch.display());
    } else {
        println!("  Watch Dir:    . (current directory)");
    }
    if !opts.pythonpath.is_empty() {
        println!("  Python Path:  {:?}", opts.pythonpath);
    }
    println!();
    println!("  💡 Tip: Edit your Python files to see live reload");
    println!("  🛑 Press Ctrl+C to stop");
    println!();
    println!("════════════════════════════════════════════");
    println!();
}