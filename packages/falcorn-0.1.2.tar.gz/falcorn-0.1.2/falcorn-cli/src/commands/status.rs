//! Status command implementation

use anyhow::Result;
use std::path::PathBuf;

/// Execute the status command
pub fn execute(pid_file: Option<PathBuf>, verbose: bool) -> Result<()> {
    let pid_path = pid_file.unwrap_or_else(|| PathBuf::from("falcorn.pid"));

    if !pid_path.exists() {
        println!("✗ Server is not running (PID file not found)");
        println!("  Expected: {}", pid_path.display());
        return Ok(());
    }

    let pid = super::utils::read_pid_file(&pid_path)?;

    if super::utils::is_process_running(pid) {
        println!("✓ Server is running");
        println!("  PID: {}", pid);
        println!("  PID file: {}", pid_path.display());

        if verbose {
            print_detailed_status(pid)?;
        }
    } else {
        println!("✗ Server is not running (stale PID file)");
        println!("  PID: {} (process not found)", pid);
        println!("  PID file: {}", pid_path.display());
        println!();
        println!("  Tip: Remove the stale PID file with:");
        println!("       rm {}", pid_path.display());
    }

    Ok(())
}

/// Print detailed status information
#[cfg(unix)]
fn print_detailed_status(pid: u32) -> Result<()> {
    use std::process::Command;

    println!();
    println!("Process Information:");

    // Get process info using ps
    let output = Command::new("ps")
        .args(&[
            "-p",
            &pid.to_string(),
            "-o",
            "pid,ppid,%cpu,%mem,etime,command",
        ])
        .output()?;

    if output.status.success() {
        let info = String::from_utf8_lossy(&output.stdout);
        println!("{}", info);
    }

    Ok(())
}

#[cfg(not(unix))]
fn print_detailed_status(pid: u32) -> Result<()> {
    println!();
    println!("  Detailed status not available on this platform");
    Ok(())
}
