//! Check configuration command

use anyhow::Result;
use falcorn_core::config::{ConfigValidator, ServerConfig};
use std::path::PathBuf;

/// Execute the check command
pub fn execute(config_path: PathBuf) -> Result<()> {
    println!("Checking configuration: {}\n", config_path.display());

    // Load configuration
    let config = match ServerConfig::from_toml(&config_path) {
        Ok(cfg) => {
            println!("✓ Configuration file loaded successfully");
            cfg
        }
        Err(e) => {
            println!("✗ Failed to load configuration");
            println!();
            return Err(e.into());
        }
    };

    // Validate configuration
    match ConfigValidator::validate(&config) {
        Ok(report) => {
            println!("✓ Configuration is valid");
            println!();

            // Show warnings if any
            if report.has_warnings() {
                println!("⚠️  Warnings:");
                for warning in report.warnings() {
                    println!("  • {}", warning);
                }
                println!();
            }

            // Show configuration summary
            println!("Configuration Summary:");
            println!("  Server:    {}:{}", config.host, config.port);
            println!(
                "  Workers:   {} ({})",
                config.worker_count(),
                config.worker_class.as_str()
            );
            println!("  App:       {}:{}", config.app_module, config.app_callable);
            println!();

            println!("✓ Ready to run!");
            println!();
            println!("Start the server with:");
            println!("  falcorn run --config {}", config_path.display());
        }
        Err(e) => {
            println!("✗ Configuration validation failed");
            println!();
            println!("Errors:");
            println!("  {}", e);
            println!();
            return Err(e.into());
        }
    }

    Ok(())
}
