//! falcorn CLI - Command-line interface for running WSGI applications

mod commands;

use clap::{ArgAction, Parser, Subcommand};
use std::ffi::OsString;
use std::path::PathBuf;

/// falcorn - High-performance WSGI/ASGI application server
#[derive(Parser)]
#[command(name = "falcorn")]
#[command(author, version, about, long_about = None)]
#[command(propagate_version = true)]
#[command(about = "A high-performance WSGI/ASGI server written in Rust", long_about = None)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Run a WSGI/ASGI application
    Run {
        /// Python application (module:callable)
        app: Option<String>,

        /// Python application module (alternative to positional app)
        #[arg(long)]
        app_module: Option<String>,

        /// Python application callable (alternative to positional app)
        #[arg(long)]
        app_callable: Option<String>,

        /// Bind address
        #[arg(long, short = 'H')]
        host: Option<String>,

        /// Bind port
        #[arg(short = 'p', long)]
        port: Option<u16>,

        /// Listen backlog
        #[arg(long)]
        backlog: Option<u32>,

        /// Protocol type (wsgi or asgi)
        #[arg(long, short = 'i')]
        protocol: Option<String>,

        /// Enable HTTP/2 cleartext (h2c) support
        #[arg(long, action = ArgAction::SetTrue)]
        h2c: bool,

        /// Disable HTTP/2 cleartext (h2c) support
        #[arg(long, action = ArgAction::SetTrue)]
        no_h2c: bool,

        /// Enable strict HTTP validation
        #[arg(long, action = ArgAction::SetTrue)]
        strict_http: bool,

        /// Disable strict HTTP validation
        #[arg(long, action = ArgAction::SetTrue)]
        no_strict_http: bool,

        /// Number of workers
        #[arg(short = 'w', long)]
        workers: Option<usize>,

        /// Worker class (sync or async)
        #[arg(long, short = 'C')]
        worker_class: Option<String>,

        #[arg(long = "worker-id", hide = true)]
        worker_id: Option<u32>,

        /// Worker timeout in seconds
        #[arg(long, short = 't')]
        timeout: Option<u64>,

        /// Max requests per worker
        #[arg(long, short = 'm')]
        max_requests: Option<usize>,

        /// Max requests jitter
        #[arg(long)]
        max_requests_jitter: Option<usize>,

        /// Buffer size in bytes
        #[arg(long)]
        buffer_size: Option<usize>,

        /// Keepalive timeout in seconds
        #[arg(long)]
        keepalive: Option<u64>,

        /// Max connections
        #[arg(long, short = 'M')]
        max_connections: Option<usize>,

        /// Sync worker handler threads
        #[arg(long)]
        sync_handler_threads: Option<usize>,

        /// Sync worker connection queue capacity
        #[arg(long)]
        sync_conn_queue_capacity: Option<usize>,

        /// Async worker runtime threads
        #[arg(long)]
        async_worker_threads: Option<usize>,

        /// Async worker max blocking threads
        #[arg(long)]
        async_max_blocking_threads: Option<usize>,

        /// Python path (can be specified multiple times)
        #[arg(long)]
        pythonpath: Vec<String>,

        /// ASGI Python event loop backend (asyncio or uvloop)
        #[arg(long)]
        asgi_event_loop: Option<String>,

        /// Allow fallback to asyncio if selected ASGI loop backend is unavailable
        #[arg(long, action = ArgAction::SetTrue)]
        asgi_event_loop_fallback: bool,

        /// Disable fallback to asyncio when selected ASGI loop backend is unavailable
        #[arg(long, action = ArgAction::SetTrue)]
        no_asgi_event_loop_fallback: bool,

        /// Max wait time for ASGI coroutine completion submitted to Python loop (ms)
        #[arg(long)]
        asgi_submit_timeout_ms: Option<u64>,

        /// ASGI scheduler mode (task or callback)
        #[arg(long)]
        asgi_scheduler: Option<String>,

        /// Max concurrent in-flight ASGI requests per worker
        #[arg(long)]
        asgi_max_inflight: Option<usize>,

        /// Max cached ASGI send event buffers per worker
        #[arg(long)]
        asgi_send_pool_size: Option<usize>,

        /// Run in worker mode (internal use by master process)
        #[arg(long = "worker-mode", hide = true, action = ArgAction::SetTrue)]
        worker_mode: bool,

        /// Configuration file
        #[arg(long, short)]
        config: Option<PathBuf>,

        /// Enable stdout logging
        #[arg(long, short, action = ArgAction::SetTrue)]
        log_stdout: bool,

        /// Disable stdout logging
        #[arg(long, action = ArgAction::SetTrue)]
        no_log_stdout: bool,

        /// Log level (TRACE, DEBUG, INFO, WARN, ERROR)
        #[arg(long)]
        log_level: Option<String>,

        /// Access log format
        #[arg(long)]
        access_log_format: Option<String>,

        /// Access log file
        #[arg(long)]
        access_log: Option<String>,

        /// Error log file
        #[arg(long)]
        error_log: Option<String>,

        /// Plugin IPC socket path for logs/metrics stream
        #[arg(long)]
        plugin_socket: Option<String>,

        /// Plugin IPC auth token required by plugin clients
        #[arg(long)]
        plugin_auth_token: Option<String>,

        /// Plugin backpressure policy (drop_oldest or disconnect)
        #[arg(long)]
        plugin_drop_policy: Option<String>,

        /// Max lagged plugin events tolerated before action
        #[arg(long)]
        plugin_max_lagged_events: Option<usize>,

        /// Max write timeout (ms) for plugin socket writes
        #[arg(long)]
        plugin_write_timeout_ms: Option<u64>,

        /// Plugin broadcast bus capacity
        #[arg(long)]
        plugin_bus_capacity: Option<usize>,

        /// Max concurrent plugin clients connected to plugin socket
        #[arg(long)]
        plugin_max_clients: Option<usize>,

        /// Subscribe handshake timeout in milliseconds
        #[arg(long)]
        plugin_subscribe_timeout_ms: Option<u64>,

        /// Sliding window (seconds) for failed plugin auth attempts
        #[arg(long)]
        plugin_auth_fail_window_secs: Option<u64>,

        /// Max failed plugin auth attempts allowed in window
        #[arg(long)]
        plugin_auth_fail_max_attempts: Option<usize>,

        /// Plugin ACL mode (off or same_user)
        #[arg(long)]
        plugin_acl_mode: Option<String>,

        /// Unix socket mode for plugin socket (octal, e.g. 660)
        #[arg(long, value_parser = parse_socket_mode)]
        plugin_socket_mode: Option<u32>,

        /// Metrics snapshot interval (ms)
        #[arg(long)]
        metrics_interval_ms: Option<u64>,

        /// Enable per-worker metrics reporting
        #[arg(long, action = ArgAction::SetTrue)]
        metrics_workers_enabled: bool,

        /// Disable per-worker metrics reporting
        #[arg(long, action = ArgAction::SetTrue)]
        no_metrics_workers_enabled: bool,

        /// Enable OS-level metrics (CPU/mem) when supported
        #[arg(long, action = ArgAction::SetTrue)]
        metrics_os_enabled: bool,

        /// Disable OS-level metrics (CPU/mem)
        #[arg(long, action = ArgAction::SetTrue)]
        no_metrics_os_enabled: bool,

        /// Enable latency percentiles (p50/p95/p99/p999)
        #[arg(long, action = ArgAction::SetTrue)]
        metrics_percentiles_enabled: bool,

        /// Disable latency percentiles (p50/p95/p99/p999)
        #[arg(long, action = ArgAction::SetTrue)]
        no_metrics_percentiles_enabled: bool,

        /// Max number of top error codes emitted
        #[arg(long)]
        metrics_top_errors_limit: Option<usize>,

        /// Control IPC socket path for actions
        #[arg(long)]
        control_socket: Option<String>,

        /// Control IPC auth token required by control clients
        #[arg(long)]
        control_auth_token: Option<String>,

        /// Control ACL mode (off or same_user)
        #[arg(long)]
        control_acl_mode: Option<String>,

        /// Unix socket mode for control socket (octal, e.g. 660)
        #[arg(long, value_parser = parse_socket_mode)]
        control_socket_mode: Option<u32>,

        /// Enable TLS
        #[arg(long, action = ArgAction::SetTrue)]
        ssl_enabled: bool,

        /// Disable TLS
        #[arg(long, action = ArgAction::SetTrue)]
        no_ssl_enabled: bool,

        /// TLS certificate file
        #[arg(long)]
        ssl_certfile: Option<String>,

        /// TLS private key file
        #[arg(long)]
        ssl_keyfile: Option<String>,

        /// Daemon mode (run in background)
        #[arg(long, short)]
        daemon: bool,

        /// PID file
        #[arg(long)]
        pid: Option<PathBuf>,
    },

    /// Initialize a new project configuration
    Init {
        /// Project type (flask, django, fastapi, generic)
        #[arg(long, default_value = "generic")]
        project_type: String,

        /// Output file
        #[arg(long, short, default_value = "falcorn.toml")]
        output: PathBuf,

        /// Force overwrite existing file
        #[arg(long, short)]
        force: bool,
    },

    /// Configuration management
    Config {
        #[command(subcommand)]
        action: ConfigAction,
    },

    /// Show server status
    Status {
        /// PID file to check
        #[arg(long)]
        pid: Option<PathBuf>,

        /// Show detailed information
        #[arg(long, short)]
        verbose: bool,
    },

    /// Restart server
    Restart {
        /// PID file
        #[arg(long)]
        pid: Option<PathBuf>,

        /// Graceful restart
        #[arg(long, short)]
        graceful: bool,
    },

    /// Stop server
    Stop {
        /// PID file
        #[arg(long)]
        pid: Option<PathBuf>,

        /// Force stop
        #[arg(long, short)]
        force: bool,
    },

    /// Check configuration validity
    Check {
        /// Configuration file
        #[arg(default_value = "falcorn.toml")]
        config: PathBuf,
    },

    /// Internal: logger daemon (IPC)
    #[command(hide = true)]
    LoggerDaemon {
        /// Socket path
        #[arg(long, default_value = "/tmp/falcorn-logger.sock")]
        socket: String,

        /// Access log file
        #[arg(long)]
        access_log: Option<String>,

        /// Error log file
        #[arg(long)]
        error_log: Option<String>,

        /// Access log format
        #[arg(long, default_value = "%(h)s %(l)s %(u)s %(t)s \"%(r)s\" %(s)s %(b)s")]
        access_log_format: String,

        /// Enable stdout logging
        #[arg(long, action = ArgAction::SetTrue)]
        log_stdout: bool,

        /// Plugin IPC socket path
        #[arg(long)]
        plugin_socket: Option<String>,

        /// Plugin IPC auth token
        #[arg(long)]
        plugin_auth_token: Option<String>,

        /// Plugin backpressure policy
        #[arg(long, default_value = "drop_oldest")]
        plugin_drop_policy: String,

        /// Max lagged plugin events tolerated before action
        #[arg(long, default_value_t = 2048)]
        plugin_max_lagged_events: usize,

        /// Max write timeout (ms) for plugin socket writes
        #[arg(long, default_value_t = 500)]
        plugin_write_timeout_ms: u64,

        /// Plugin broadcast bus capacity
        #[arg(long, default_value_t = 8192)]
        plugin_bus_capacity: usize,

        /// Max concurrent plugin clients connected to plugin socket
        #[arg(long, default_value_t = 1024)]
        plugin_max_clients: usize,

        /// Subscribe handshake timeout in milliseconds
        #[arg(long, default_value_t = 5000)]
        plugin_subscribe_timeout_ms: u64,

        /// Sliding window (seconds) for failed plugin auth attempts
        #[arg(long, default_value_t = 60)]
        plugin_auth_fail_window_secs: u64,

        /// Max failed plugin auth attempts allowed in window
        #[arg(long, default_value_t = 10)]
        plugin_auth_fail_max_attempts: usize,

        /// Plugin ACL mode (off or same_user)
        #[arg(long, default_value = "same_user")]
        plugin_acl_mode: String,

        /// Unix socket mode for plugin socket (octal, e.g. 660)
        #[arg(long, default_value = "660", value_parser = parse_socket_mode)]
        plugin_socket_mode: u32,

        /// Metrics snapshot interval (ms)
        #[arg(long, default_value_t = 5000)]
        metrics_interval_ms: u64,

        /// Enable per-worker metrics reporting
        #[arg(long, default_value_t = true)]
        metrics_workers_enabled: bool,

        /// Enable OS-level metrics (CPU/mem) when supported
        #[arg(long, default_value_t = false)]
        metrics_os_enabled: bool,

        /// Enable latency percentiles (p50/p95/p99/p999)
        #[arg(long, default_value_t = false)]
        metrics_percentiles_enabled: bool,

        /// Max number of top error codes emitted
        #[arg(long, default_value_t = 5)]
        metrics_top_errors_limit: usize,
    },
}

#[derive(Subcommand)]
enum ConfigAction {
    /// Show current configuration
    Show {
        /// Configuration file
        #[arg(default_value = "falcorn.toml")]
        config: PathBuf,
    },

    /// Validate configuration
    Validate {
        /// Configuration file
        #[arg(default_value = "falcorn.toml")]
        config: PathBuf,
    },
}

pub fn run_from<I, T>(args: I) -> anyhow::Result<()>
where
    I: IntoIterator<Item = T>,
    T: Into<OsString> + Clone,
{
    let cli = Cli::parse_from(args);

    let result = match cli.command {
        Commands::Run {
            app,
            app_module,
            app_callable,
            host,
            port,
            backlog,
            protocol,
            h2c,
            no_h2c,
            strict_http,
            no_strict_http,
            workers,
            worker_class,
            worker_id,
            timeout,
            max_requests,
            max_requests_jitter,
            buffer_size,
            keepalive,
            max_connections,
            sync_handler_threads,
            sync_conn_queue_capacity,
            async_worker_threads,
            async_max_blocking_threads,
            pythonpath,
            asgi_event_loop,
            asgi_event_loop_fallback,
            no_asgi_event_loop_fallback,
            asgi_submit_timeout_ms,
            asgi_scheduler,
            asgi_max_inflight,
            asgi_send_pool_size,
            worker_mode,
            config,
            log_stdout,
            no_log_stdout,
            log_level,
            access_log_format,
            access_log,
            error_log,
            plugin_socket,
            plugin_auth_token,
            plugin_drop_policy,
            plugin_max_lagged_events,
            plugin_write_timeout_ms,
            plugin_bus_capacity,
            plugin_max_clients,
            plugin_subscribe_timeout_ms,
            plugin_auth_fail_window_secs,
            plugin_auth_fail_max_attempts,
            plugin_acl_mode,
            plugin_socket_mode,
            metrics_interval_ms,
            metrics_workers_enabled,
            no_metrics_workers_enabled,
            metrics_os_enabled,
            no_metrics_os_enabled,
            metrics_percentiles_enabled,
            no_metrics_percentiles_enabled,
            metrics_top_errors_limit,
            control_socket,
            control_auth_token,
            control_acl_mode,
            control_socket_mode,
            ssl_enabled,
            no_ssl_enabled,
            ssl_certfile,
            ssl_keyfile,
            daemon,
            pid,
        } => commands::run::execute(commands::run::RunOptions {
            app,
            app_module,
            app_callable,
            host,
            port,
            backlog,
            protocol,
            h2c,
            no_h2c,
            strict_http,
            no_strict_http,
            workers,
            worker_class,
            worker_id,
            timeout,
            max_requests,
            max_requests_jitter,
            buffer_size,
            keepalive,
            max_connections,
            sync_handler_threads,
            sync_conn_queue_capacity,
            async_worker_threads,
            async_max_blocking_threads,
            pythonpath,
            asgi_event_loop,
            asgi_event_loop_fallback,
            no_asgi_event_loop_fallback,
            asgi_submit_timeout_ms,
            asgi_scheduler,
            asgi_max_inflight,
            asgi_send_pool_size,
            worker_mode,
            config,
            log_stdout,
            no_log_stdout,
            log_level,
            access_log_format,
            access_log,
            error_log,
            plugin_socket,
            plugin_auth_token,
            plugin_drop_policy,
            plugin_max_lagged_events,
            plugin_write_timeout_ms,
            plugin_bus_capacity,
            plugin_max_clients,
            plugin_subscribe_timeout_ms,
            plugin_auth_fail_window_secs,
            plugin_auth_fail_max_attempts,
            plugin_acl_mode,
            plugin_socket_mode,
            metrics_interval_ms,
            metrics_workers_enabled,
            no_metrics_workers_enabled,
            metrics_os_enabled,
            no_metrics_os_enabled,
            metrics_percentiles_enabled,
            no_metrics_percentiles_enabled,
            metrics_top_errors_limit,
            control_socket,
            control_auth_token,
            control_acl_mode,
            control_socket_mode,
            ssl_enabled,
            no_ssl_enabled,
            ssl_certfile,
            ssl_keyfile,
            daemon,
            pid,
        }),

        Commands::Init {
            project_type,
            output,
            force,
        } => commands::init::execute(project_type, output, force),

        Commands::Config { action } => match action {
            ConfigAction::Show { config } => commands::config::show(Some(config.as_path())),
            ConfigAction::Validate { config } => commands::config::validate(&config),
        },

        Commands::Status { pid, verbose } => commands::status::execute(pid, verbose),

        Commands::Restart { pid, graceful } => run_async(commands::restart::execute(pid, graceful)),

        Commands::Stop { pid, force } => run_async(commands::stop::execute(pid, force)),

        Commands::Check { config } => commands::check::execute(config),

        Commands::LoggerDaemon {
            socket,
            access_log,
            error_log,
            access_log_format,
            log_stdout,
            plugin_socket,
            plugin_auth_token,
            plugin_drop_policy,
            plugin_max_lagged_events,
            plugin_write_timeout_ms,
            plugin_bus_capacity,
            plugin_max_clients,
            plugin_subscribe_timeout_ms,
            plugin_auth_fail_window_secs,
            plugin_auth_fail_max_attempts,
            plugin_acl_mode,
            plugin_socket_mode,
            metrics_interval_ms,
            metrics_workers_enabled,
            metrics_os_enabled,
            metrics_percentiles_enabled,
            metrics_top_errors_limit,
        } => run_async(async {
            falcorn_core::logging::run_logger_daemon(
                &socket,
                access_log,
                error_log,
                access_log_format,
                log_stdout,
                plugin_socket,
                plugin_auth_token,
                plugin_drop_policy,
                plugin_max_lagged_events,
                plugin_write_timeout_ms,
                plugin_bus_capacity,
                plugin_max_clients,
                plugin_subscribe_timeout_ms,
                plugin_auth_fail_window_secs,
                plugin_auth_fail_max_attempts,
                plugin_acl_mode,
                plugin_socket_mode,
                metrics_interval_ms,
                metrics_workers_enabled,
                metrics_os_enabled,
                metrics_percentiles_enabled,
                metrics_top_errors_limit,
            )
            .await
            .map_err(|e| anyhow::anyhow!(e.to_string()))
        }),
    };

    result
}

pub fn run_main() -> i32 {
    if let Err(e) = run_from(std::env::args()) {
        eprintln!("Error: {}", e);
        1
    } else {
        0
    }
}

fn run_async<F>(fut: F) -> anyhow::Result<()>
where
    F: std::future::Future<Output = anyhow::Result<()>>,
{
    let rt = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()?;
    rt.block_on(fut)
}

fn parse_socket_mode(raw: &str) -> std::result::Result<u32, String> {
    let mode = u32::from_str_radix(raw.trim_start_matches("0o"), 8)
        .map_err(|_| format!("invalid socket mode '{}': expected octal like 660", raw))?;
    if mode == 0 || mode > 0o777 {
        return Err(format!(
            "invalid socket mode '{}': expected octal range 001..777",
            raw
        ));
    }
    Ok(mode)
}
