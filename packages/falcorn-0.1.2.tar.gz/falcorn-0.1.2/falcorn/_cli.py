"""CLI wrapper that delegates to the Rust bindings."""

from __future__ import annotations

import os
import sys

import falcorn._falcorn as _falcorn


# Cli Entry Point
def main() -> None:
    # Setup FALCORN BIN PATH
    os.environ["FALCORN_BIN_PATH"] = os.path.join(sys.prefix, "bin", "falcorn")
    # Exit Properly with the exit code returned by the Rust bindings
    raise SystemExit(_falcorn.cli_main(sys.argv[1:]))
