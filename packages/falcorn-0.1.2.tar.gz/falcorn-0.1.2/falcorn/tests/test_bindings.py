"""
Unit tests for Falcorn Python bindings
"""

import pytest
from _falcorn import FalcornServer, PyServerConfig, WorkerClass


def test_worker_class():
    """Test WorkerClass enum"""
    sync = WorkerClass("sync")
    async_wc = WorkerClass("async")

    assert str(sync) == "sync"
    assert str(async_wc) == "async"

    # Test invalid
    with pytest.raises(ValueError):
        WorkerClass("invalid")


def test_server_config_creation():
    """Test PyServerConfig creation"""
    config = PyServerConfig("app", "application")

    assert config.app_module == "app"
    assert config.app_callable == "application"
    assert config.host == "127.0.0.1"
    assert config.port == 8000
    assert config.worker_class == WorkerClass.Sync


def test_server_config_validation():
    """Test configuration validation"""
    config = PyServerConfig("app", "application")

    # Valid config should not raise
    config.validate()

    # Invalid port
    config.port = 0
    with pytest.raises(ValueError):
        config.validate()


def test_server_config_worker_count():
    """Test worker count auto-detection"""
    config = PyServerConfig("app", "application")
    config.workers = None

    # Should auto-detect
    count = config.get_worker_count()
    assert count > 0


def test_server_creation():
    """Test FalcornServer creation"""

    server = FalcornServer("app", "application")

    assert server is not None

    # Check status
    status = server.status()
    assert "Falcorn Server" in status


def test_server_from_config():
    """Test server creation from config"""

    config = PyServerConfig("app", "application")
    config.workers = 4

    server = FalcornServer.from_config(config)

    assert server is not None
    retrieved_config = server.get_config()
    assert retrieved_config.workers == 4


def test_server_setters():
    """Test server setter methods"""

    server = FalcornServer("app", "application")

    # Set worker class
    server.set_worker_class("async")
    config = server.get_config()
    assert config.worker_class == WorkerClass.Async

    # Set timeout
    server.set_timeout(60)
    config = server.get_config()
    assert config.worker_timeout == 60

    # Set log level
    server.set_log_level("DEBUG")
    config = server.get_config()
    assert config.log_level == "DEBUG"

    # Add pythonpath
    server.add_pythonpath("./src")
    config = server.get_config()
    assert "./src" in config.pythonpath


def test_server_invalid_setters():
    """Test invalid setter values"""

    server = FalcornServer("app", "application")

    # Invalid worker class
    with pytest.raises(ValueError):
        server.set_worker_class("invalid")

    # Invalid timeout
    with pytest.raises(ValueError):
        server.set_timeout(0)

    # Invalid log level
    with pytest.raises(ValueError):
        server.set_log_level("INVALID")


def test_config_toml_roundtrip(tmp_path):
    """Test TOML save/load"""

    config = PyServerConfig("app", "application")
    config.workers = 8
    config.worker_class = WorkerClass.Async

    # Save
    toml_file = tmp_path / "test.toml"
    config.to_toml(str(toml_file))

    # Load
    loaded = PyServerConfig.from_toml(str(toml_file))

    assert loaded.workers == 8
    assert loaded.worker_class == WorkerClass.Async


def test_repr():
    """Test string representations"""

    server = FalcornServer("app", "application", port=8080)
    repr_str = repr(server)

    assert "FalcornServer" in repr_str
    assert "app:application" in repr_str
    assert "8080" in repr_str

    config = PyServerConfig("app", "application")
    config_repr = repr(config)

    assert "ServerConfig" in config_repr
