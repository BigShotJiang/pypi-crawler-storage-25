"""Falcorn Python API."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._falcorn import (
    DEFAULT_CONTROL_SOCKET,
    DEFAULT_LOG_SOCKET,
    PLUGIN_FILTER_ACCESS_LOG,
    PLUGIN_FILTER_ALL,
    PLUGIN_FILTER_LOG_MESSAGE,
    PLUGIN_FILTER_METRICS,
    ControlClient,
    FalcornServer,
    LoggingClient,
    ProtocolType,
    ServerConfig,
    WorkerClass,
    __version__,
    cli_main,
)

PyServerConfig = ServerConfig

__all__ = [
    "ControlClient",
    "FalcornServer",
    "LoggingClient",
    "ServerConfig",
    "PyServerConfig",
    "WorkerClass",
    "ProtocolType",
    "DEFAULT_CONTROL_SOCKET",
    "DEFAULT_LOG_SOCKET",
    "PLUGIN_FILTER_LOG_MESSAGE",
    "PLUGIN_FILTER_ACCESS_LOG",
    "PLUGIN_FILTER_METRICS",
    "PLUGIN_FILTER_ALL",
    "cli_main",
    "__version__",
]
