//! Main server implementation orchestrating workers and request handling

pub mod request_handler;
pub mod server;

pub use server::FalcornServer;
