//! Common HTTP engine types

use http::Version as HttpCrateVersion;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HttpVersion {
    Http10,
    Http11,
    Http2,
    Http3,
}

impl HttpVersion {
    pub fn as_str(&self) -> &'static str {
        match self {
            HttpVersion::Http10 => "HTTP/1.0",
            HttpVersion::Http11 => "HTTP/1.1",
            HttpVersion::Http2 => "HTTP/2",
            HttpVersion::Http3 => "HTTP/3",
        }
    }

    pub fn to_http_crate(self) -> HttpCrateVersion {
        match self {
            HttpVersion::Http10 => HttpCrateVersion::HTTP_10,
            HttpVersion::Http11 => HttpCrateVersion::HTTP_11,
            HttpVersion::Http2 => HttpCrateVersion::HTTP_2,
            HttpVersion::Http3 => HttpCrateVersion::HTTP_3,
        }
    }
}

// TESTS
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_as_str() {
        assert_eq!(HttpVersion::Http10.as_str(), "HTTP/1.0");
        assert_eq!(HttpVersion::Http11.as_str(), "HTTP/1.1");
        assert_eq!(HttpVersion::Http2.as_str(), "HTTP/2");
        assert_eq!(HttpVersion::Http3.as_str(), "HTTP/3");
    }

    #[test]
    fn test_to_http_crate() {
        assert_eq!(
            HttpVersion::Http10.to_http_crate(),
            HttpCrateVersion::HTTP_10
        );
        assert_eq!(
            HttpVersion::Http11.to_http_crate(),
            HttpCrateVersion::HTTP_11
        );
        assert_eq!(HttpVersion::Http2.to_http_crate(), HttpCrateVersion::HTTP_2);
        assert_eq!(HttpVersion::Http3.to_http_crate(), HttpCrateVersion::HTTP_3);
    }
}
