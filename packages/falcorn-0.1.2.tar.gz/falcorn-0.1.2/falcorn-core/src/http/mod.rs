pub mod body;
pub mod engine;
pub mod request;
pub mod response;
pub mod response_builder;

pub mod middleware;

pub use body::Body;
pub use engine::HttpEngine;
pub use engine::types::HttpVersion;
pub use middleware::{CompressionMiddleware, CorsMiddleware, Middleware, MiddlewareChain};
pub use request::{HttpMethod, HttpRequest};
pub use response::HttpResponse;

use crate::errors::Result;
// use http::StatusCode;
use std::net::SocketAddr;

/// Parse HTTP request from bytes
pub fn parse_request(bytes: &[u8], peer_addr: SocketAddr) -> Result<HttpRequest> {
    request::parse(bytes, peer_addr)
}

pub fn response() -> response_builder::ResponseBuilder {
    response_builder::ResponseBuilder::new()
}
