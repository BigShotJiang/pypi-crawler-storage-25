//! IPC definitions for logger daemon

pub use falcorn_proto::logging::*;

pub fn socket_path() -> String {
    std::env::var("FALCORN_LOG_SOCKET").unwrap_or_else(|_| DEFAULT_LOG_SOCKET.to_string())
}
