//! Structured logging for Falcorn

pub mod client;
pub mod daemon;
pub mod ipc;
pub mod logger;
pub mod metrics;

pub use client::start_logger_client;
pub use daemon::run_logger_daemon;
pub use logger::Logger;
