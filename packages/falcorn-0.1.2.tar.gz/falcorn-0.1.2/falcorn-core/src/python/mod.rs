//! Python integration layer for Falcorn
//! Handles loading Python apps and WSGI interface

pub mod app;
pub mod app_loader;
pub mod asgi;
pub mod py_context;
pub mod python_errors;
pub mod runtime;
pub mod wsgi;

pub use crate::python::python_errors::{
    convert_py_error, convert_to_py_error, log_python_exception,
};
use runtime::PythonRuntime;

use std::sync::{Arc, OnceLock};

static PY_RUNTIME: OnceLock<Arc<PythonRuntime>> = OnceLock::new();

pub fn init_python() -> Arc<PythonRuntime> {
    let rt = Arc::new(PythonRuntime::start());
    PY_RUNTIME
        .set(rt.clone())
        .expect("Python runtime already initialized");
    rt
}

pub fn python() -> Arc<PythonRuntime> {
    PY_RUNTIME
        .get()
        .expect("Python runtime not initialized")
        .clone()
}

// With Python Macro
macro_rules! with_python {
    ($rt:expr, $body:expr) => {{ $rt.exec(move |py| $body(py)) }};
}
