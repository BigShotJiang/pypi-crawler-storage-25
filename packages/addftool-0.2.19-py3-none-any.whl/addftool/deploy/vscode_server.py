import os
import shlex
import subprocess

from addftool.util import need_sudo, execute_command, install_packages


def _find_addf_path():
    addf_path = execute_command("which addf", hide=True)
    if addf_path is None:
        return None
    addf_path = addf_path.strip()
    return addf_path or None


def _create_code_symlink(code_binary_path, command_prefix):
    addf_path = _find_addf_path()
    if addf_path is None:
        raise RuntimeError("Unable to find addf in PATH. Install addftool before linking the VS Code CLI.")

    symlink_path = os.path.join(os.path.dirname(addf_path), "code")
    print(f"Creating symlink: {symlink_path} -> {code_binary_path}")

    if os.path.isdir(symlink_path) and not os.path.islink(symlink_path):
        raise RuntimeError(f"Cannot create symlink because {symlink_path} is an existing directory.")

    try:
        if os.path.lexists(symlink_path):
            os.remove(symlink_path)
        os.symlink(code_binary_path, symlink_path)
    except PermissionError:
        execute_command(
            command_prefix
            + f"ln -sfn {shlex.quote(code_binary_path)} {shlex.quote(symlink_path)}"
        )


def _install_vscode_cli_tar(command_prefix):
    print("Checking if curl is installed...")
    install_packages(["curl"])

    print("Downloading VS Code CLI tar package...")
    execute_command(
        "curl -Lk 'https://code.visualstudio.com/sha/download?build=stable&os=cli-alpine-x64' "
        "-o /tmp/vscode_cli.tar.gz"
    )

    print("Extracting VS Code CLI tar package...")
    execute_command("rm -rf /tmp/bin")
    execute_command("mkdir -p /tmp/bin")
    execute_command("tar -xf /tmp/vscode_cli.tar.gz -C /tmp/bin")

    code_binary_path = execute_command(
        "find /tmp/bin -type f -name code | head -n 1",
        hide=True,
    )
    if code_binary_path is None or not code_binary_path.strip():
        raise RuntimeError("Unable to locate the extracted VS Code CLI binary.")

    code_binary_path = code_binary_path.strip()
    execute_command(f"chmod +x {shlex.quote(code_binary_path)}")
    _create_code_symlink(code_binary_path, command_prefix)
    execute_command("rm -f /tmp/vscode_cli.tar.gz")


def deploy_vscode_server(install_tunnel=True, install_method="wget", max_retries=3, timeout=120):
    """
    Deploy Visual Studio Code and optionally start VS Code Tunnel.
    
    Args:
        install_tunnel (bool): Whether to start VS Code Tunnel after installation
        install_method (str): Method to install VS Code ('apt', 'wget', or 'cli-tar')
        max_retries (int): Maximum number of installation attempts for .deb package
        timeout (int): Timeout in seconds for each installation attempt
    """
    command_prefix = "sudo " if need_sudo() else ""
    if install_method == "apt":
        # Install prerequisites
        print("Installing prerequisites...")
        execute_command(command_prefix + "apt-get install -y wget gpg")
        
        # Add Microsoft's GPG key
        print("Adding Microsoft's GPG key...")
        execute_command("wget -qO- https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor > packages.microsoft.gpg")
        execute_command(command_prefix + "install -D -o root -g root -m 644 packages.microsoft.gpg /etc/apt/keyrings/packages.microsoft.gpg")
        
        # Add VS Code repository
        print("Adding VS Code repository...")
        execute_command(command_prefix + "sh -c 'echo \"deb [arch=amd64,arm64,armhf signed-by=/etc/apt/keyrings/packages.microsoft.gpg] "
                    "https://packages.microsoft.com/repos/code stable main\" > /etc/apt/sources.list.d/vscode.list'")
        
        # Clean up
        execute_command("rm -f packages.microsoft.gpg")
        
        # Install VS Code
        print("Installing VS Code...")
        execute_command(command_prefix + "apt install -y apt-transport-https")
        execute_command(command_prefix + "apt update")
        execute_command(command_prefix + "apt install -y code")
    elif install_method == "wget":
        # check if wget is installed
        print("Checking if wget is installed...")
        install_packages(["wget"])
        # wget https://go.microsoft.com/fwlink/?LinkID=760868 -O /tmp/vscode-server.deb
        # sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --allow-downgrades /tmp/vscode-server.deb
        print("Downloading VS Code .deb package...")
        execute_command("wget https://go.microsoft.com/fwlink/?LinkID=760868 -O /tmp/vscode-server.deb")
        print("Installing VS Code from .deb package...")
        install_cmd = command_prefix + "DEBIAN_FRONTEND=noninteractive apt-get install -y --allow-downgrades /tmp/vscode-server.deb"
        for attempt in range(1, max_retries + 1):
            try:
                print(f"Installation attempt {attempt}/{max_retries} (timeout={timeout}s)...")
                proc = subprocess.Popen(install_cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                stdout, stderr = proc.communicate(timeout=timeout)
                if proc.returncode == 0:
                    print("VS Code .deb package installed successfully.")
                    break
                else:
                    print(f"Attempt {attempt} failed with return code {proc.returncode}.")
                    if stdout:
                        print(f"Stdout: {stdout.decode()}")
                    if stderr:
                        print(f"Stderr: {stderr.decode()}")
            except subprocess.TimeoutExpired:
                print(f"Attempt {attempt} timed out after {timeout}s, killing process...")
                proc.kill()
                proc.communicate()
            if attempt == max_retries:
                raise RuntimeError(f"Failed to install VS Code .deb package after {max_retries} attempts.")
        execute_command("rm -f /tmp/vscode-server.deb")
    elif install_method == "cli-tar":
        _install_vscode_cli_tar(command_prefix)
    else:
        raise ValueError(f"Unsupported install method: {install_method}")
    
    # Start VS Code Tunnel if requested
    if install_tunnel:
        print("Starting VS Code Tunnel...")
    
    print("VS Code installation completed successfully!")
    print("Run the following commands to sign in and start a tunnel:")
    print("code tunnel user login --provider github")
    print("code tunnel --accept-server-license-terms --random-name")


def add_deploy_vscode_server_args(parser):
    """
    Add VS Code deployment arguments to the parser.
    
    Args:
        parser (argparse.ArgumentParser): The argument parser to add the arguments to.
    """
    parser.add_argument("--no-tunnel", dest="install_tunnel", action="store_false", 
                        help="Skip starting VS Code Tunnel after installation")
    parser.add_argument("--install-method", type=str, default="cli-tar", choices=["apt", "wget", "cli-tar"],
                        help="Method to install VS Code (default: cli-tar)")
    parser.add_argument("--max-retries", type=int, default=3,
                        help="Maximum number of installation attempts for .deb package (default: 3)")
    parser.add_argument("--timeout", type=int, default=120,
                        help="Timeout in seconds for each installation attempt (default: 120)")
    parser.set_defaults(install_tunnel=True)


def deploy_vscode_server_main(args):
    """
    Main function for VS Code deployment.
    
    Args:
        args: Parsed command-line arguments
    """
    deploy_vscode_server(install_tunnel=args.install_tunnel, install_method=args.install_method,
                          max_retries=args.max_retries, timeout=args.timeout)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="VS Code deployment arguments")
    add_deploy_vscode_server_args(parser)

    args = parser.parse_args()

    deploy_vscode_server_main(args)
