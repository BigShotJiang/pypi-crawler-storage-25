# Changelog

All notable changes to `z4j` are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.4] - 2026-04-23

### Fixed

- **Bumps `z4j-brain` floor to `>=1.0.4`** which fixes four UX bugs in the bare-metal first-boot flow:
  1. Stale-DB cross-version safety net: when a fresh secret is auto-minted, any pre-existing `~/.z4j/z4j.db` from a crashed older install is moved aside to `.stale-bak`.
  2. Setup rate-limit budget bumped from 5 to 30 attempts per IP per 15-min window.
  3. Rate-limit lockout no longer self-perpetuates (used to count each blocked retry, extending the window indefinitely).
  4. Setup error messages now include actionable guidance instead of the opaque "setup token expired or already used".
- New `z4j-brain reset-setup` CLI command for stuck operators (escape hatch when locked out without wanting to nuke `~/.z4j/`).

### Compatibility

- Backwards compatible. Compose files unchanged from 1.0.3.

## [1.0.3] - 2026-04-22

### Fixed

- **Bumps `z4j-brain` floor to `>=1.0.3`** which fixes the zero-config bare-metal `pip install z4j && z4j-brain serve` flow. Before this fix, the CLI auto-defaulted `Z4J_DATABASE_URL` to `~/.z4j/z4j.db` but did NOT auto-mint HMAC signing keys, so `z4j-brain serve` crashed with a Pydantic `ValidationError: secret + session_secret Field required` until the operator manually exported them. The Docker entrypoint had always done this; the bare-metal CLI now matches.
- README "Quick start" rewritten: `pip install z4j && z4j-brain serve` is now the entire flow. No manual `secrets.token_urlsafe` dance.

### Compatibility

- Backwards compatible. Operators who already set `Z4J_SECRET`, `Z4J_SESSION_SECRET`, etc. via env vars or compose files see no behavior change. The auto-mint kicks in only when those env vars are unset.
- Compose files unchanged from 1.0.2.

## [1.0.2] - 2026-04-22

### Added

- **Docker Compose recipes ship with the package.** `docker-compose.yml` (SQLite mode), `docker-compose.postgres.yml` (PostgreSQL sidecar), `docker-compose.caddy.yml` (Let's Encrypt HTTPS overlay), and `.env.example` are now included in the `z4j` sdist and the [z4jdev/z4j GitHub repo](https://github.com/z4jdev/z4j). Operators can `git clone github.com/z4jdev/z4j && docker compose up -d` for a fully working self-host without reading the Dockerfile.
- Compose files reference the public `z4jdev/z4j:latest` image on Docker Hub (published in v1.0.1 of the brain).

### Notes

- Wheel content is unchanged from 1.0.1 - the compose files are sdist + repo artifacts, not runtime Python code. `pip install z4j==1.0.1` and `pip install z4j==1.0.2` land identical Python on disk. The sdist (and the GitHub repo) is where compose recipes appear.

## [1.0.1] - 2026-04-22

First public release of the z4j umbrella package. Synchronized with z4j-brain 1.0.1.

### Features

- **Meta-install for the z4j control plane.** `pip install z4j` resolves to `z4j-brain>=1.0.1` + `z4j-core>=1.0.1`, giving a fully working brain server (dashboard, REST API, WebSocket gateway, SQLite DB, Alembic migrations, CLI) in one command. Mirrors the `docker run z4jdev/z4j` experience for Python-first operators.
- **Clean extras surface for adapter selection**: `[celery]`, `[django]`, `[flask]`, `[fastapi]`, `[rq]`, `[dramatiq]`, `[huey]`, `[arq]`, `[taskiq]`, `[apscheduler]`, `[bare]`. Each extra pulls the engine adapter plus its companion scheduler (where applicable) in one shot, covering the 95% case.
- **Infra pass-through extra** `[postgres]` defers to `z4j-brain[postgres]`, so asyncpg's version floor stays owned by the brain package rather than being duplicated here.
- **Convenience bundles**: `[agents]` (every engine adapter at once) and `[all]` (= `[agents,postgres]`, the kitchen sink for CI / dev rigs).
- **Agent-only install recipe documented** for organizations whose policy forbids AGPL code: `pip install z4j-core z4j-<adapter>` keeps Apache-2.0 purity without touching the brain.

### Notes

- **OpenTelemetry is not shipped.** The umbrella intentionally does not expose an `[otel]` extra. z4j-brain 1.0.1 simultaneously drops its own `[otel]` extra because the packages were installed but the integration code was never wired (no `TracerProvider` init, no FastAPI instrumentation, no OTLP export path). OpenTelemetry support will return as a real working feature in a future release, at which point both packages will reintroduce the extra. Until then, the working observability story is Prometheus `/metrics` + structlog JSON logs, both wired in z4j-brain since 1.0.0.

### Compatibility

- Python 3.11, 3.12, 3.13, 3.14.
- Operating-system independent (Linux, macOS, Windows).
- Depends on `z4j-brain>=1.0.1` (AGPL v3) and `z4j-core>=1.0.1` (Apache 2.0).

## Links

- Repository: <https://github.com/z4jdev/z4j>
- Issues: <https://github.com/z4jdev/z4j/issues>
- PyPI: <https://pypi.org/project/z4j/>

[Unreleased]: https://github.com/z4jdev/z4j/compare/v1.0.0...HEAD
[1.0.0]: https://github.com/z4jdev/z4j/releases/tag/v1.0.0
