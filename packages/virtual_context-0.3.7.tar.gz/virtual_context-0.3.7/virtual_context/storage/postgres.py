"""PostgresStore: storage backend using psycopg (PostgreSQL)."""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timedelta, timezone

import psycopg
from psycopg.rows import dict_row

from ..core.store import ContextStore
from ..types import (
    ChunkEmbedding,
    ConversationStats,
    DepthLevel,
    EngineStateSnapshot,
    Fact,
    FactLink,
    FactSignal,
    FullTextChunkEmbedding,
    FullTextRow,
    LinkedFact,
    QuoteResult,
    SegmentMetadata,
    StoredSegment,
    StoredSummary,
    TagStats,
    TagSummary,
    TemporalStatus,
    TurnTagEntry,
    WorkingSetEntry,
)
from .helpers import dt_to_str as _dt_to_str, str_to_dt as _str_to_dt, extract_excerpt as _extract_excerpt

logger = logging.getLogger(__name__)


SCHEMA_SQL = """\
CREATE TABLE IF NOT EXISTS segments (
    ref TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL DEFAULT '',
    primary_tag TEXT NOT NULL DEFAULT '_general',
    summary TEXT NOT NULL DEFAULT '',
    full_text TEXT NOT NULL DEFAULT '',
    messages_json TEXT NOT NULL DEFAULT '[]',
    metadata_json TEXT NOT NULL DEFAULT '{}',
    summary_tokens INTEGER NOT NULL DEFAULT 0,
    full_tokens INTEGER NOT NULL DEFAULT 0,
    compression_ratio REAL NOT NULL DEFAULT 0.0,
    compaction_model TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    start_timestamp TEXT NOT NULL,
    end_timestamp TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS segment_tags (
    segment_ref TEXT NOT NULL,
    tag TEXT NOT NULL,
    PRIMARY KEY (segment_ref, tag),
    FOREIGN KEY (segment_ref) REFERENCES segments(ref) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tag_aliases (
    alias TEXT NOT NULL,
    conversation_id TEXT NOT NULL DEFAULT '',
    canonical TEXT NOT NULL,
    PRIMARY KEY (alias, conversation_id)
);

CREATE TABLE IF NOT EXISTS tag_summaries (
    tag TEXT NOT NULL,
    conversation_id TEXT NOT NULL DEFAULT '',
    summary TEXT NOT NULL DEFAULT '',
    description TEXT NOT NULL DEFAULT '',
    code_refs TEXT NOT NULL DEFAULT '[]',
    summary_tokens INTEGER NOT NULL DEFAULT 0,
    source_segment_refs TEXT NOT NULL DEFAULT '[]',
    source_turn_numbers TEXT NOT NULL DEFAULT '[]',
    covers_through_turn INTEGER NOT NULL DEFAULT -1,
    generated_by_turn_id TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (tag, conversation_id)
);

CREATE TABLE IF NOT EXISTS engine_state (
    conversation_id TEXT PRIMARY KEY,
    compacted_through INTEGER NOT NULL,
    turn_count INTEGER NOT NULL,
    turn_tag_entries TEXT NOT NULL,
    saved_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS conversation_lifecycle (
    conversation_id TEXT PRIMARY KEY,
    generation INTEGER NOT NULL DEFAULT 0,
    deleted BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS turn_messages (
    conversation_id TEXT NOT NULL,
    turn_number INTEGER NOT NULL,
    user_content TEXT NOT NULL DEFAULT '',
    assistant_content TEXT NOT NULL DEFAULT '',
    user_raw_content TEXT,
    assistant_raw_content TEXT,
    PRIMARY KEY (conversation_id, turn_number)
);

CREATE TABLE IF NOT EXISTS full_text (
    conversation_id TEXT NOT NULL,
    turn_number INTEGER NOT NULL,
    user_content TEXT NOT NULL DEFAULT '',
    assistant_content TEXT NOT NULL DEFAULT '',
    user_raw_content TEXT,
    assistant_raw_content TEXT,
    primary_tag TEXT NOT NULL DEFAULT '_general',
    tags_json TEXT NOT NULL DEFAULT '[]',
    session_date TEXT NOT NULL DEFAULT '',
    sender TEXT NOT NULL DEFAULT '',
    fact_signals_json TEXT NOT NULL DEFAULT '[]',
    code_refs_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL DEFAULT '',
    updated_at TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (conversation_id, turn_number)
);

CREATE TABLE IF NOT EXISTS conversation_aliases (
    alias_id TEXT PRIMARY KEY,
    target_id TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS segment_chunks (
    segment_ref TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL,
    embedding_json TEXT NOT NULL,
    PRIMARY KEY (segment_ref, chunk_index)
);

CREATE TABLE IF NOT EXISTS full_text_chunks (
    conversation_id TEXT NOT NULL,
    turn_number INTEGER NOT NULL,
    side TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL,
    embedding_json TEXT NOT NULL,
    PRIMARY KEY (conversation_id, turn_number, side, chunk_index)
);

CREATE TABLE IF NOT EXISTS facts (
    id TEXT PRIMARY KEY,
    subject TEXT NOT NULL DEFAULT '',
    verb TEXT NOT NULL DEFAULT '',
    object TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'active',
    what TEXT NOT NULL DEFAULT '',
    who TEXT NOT NULL DEFAULT '',
    when_date TEXT NOT NULL DEFAULT '',
    "where" TEXT NOT NULL DEFAULT '',
    why TEXT NOT NULL DEFAULT '',
    fact_type TEXT NOT NULL DEFAULT 'personal',
    tags_json TEXT NOT NULL DEFAULT '[]',
    segment_ref TEXT NOT NULL DEFAULT '',
    conversation_id TEXT NOT NULL DEFAULT '',
    turn_numbers_json TEXT NOT NULL DEFAULT '[]',
    mentioned_at TEXT NOT NULL DEFAULT '',
    session_date TEXT NOT NULL DEFAULT '',
    superseded_by TEXT
);

CREATE TABLE IF NOT EXISTS fact_tags (
    fact_id TEXT NOT NULL,
    tag TEXT NOT NULL,
    PRIMARY KEY (fact_id, tag),
    FOREIGN KEY (fact_id) REFERENCES facts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS fact_links (
    id TEXT PRIMARY KEY,
    source_fact_id TEXT NOT NULL,
    target_fact_id TEXT NOT NULL,
    relation_type TEXT NOT NULL,
    confidence REAL NOT NULL DEFAULT 1.0,
    context TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT '',
    created_by TEXT NOT NULL DEFAULT 'compaction',
    FOREIGN KEY (source_fact_id) REFERENCES facts(id) ON DELETE CASCADE,
    FOREIGN KEY (target_fact_id) REFERENCES facts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tool_outputs (
    ref TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    command TEXT NOT NULL DEFAULT '',
    turn INTEGER NOT NULL,
    content TEXT NOT NULL,
    original_bytes INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS request_captures (
    conversation_id TEXT NOT NULL DEFAULT '',
    turn INTEGER NOT NULL,
    turn_id TEXT NOT NULL DEFAULT '',
    ts TEXT NOT NULL,
    recorded_at DOUBLE PRECISION NOT NULL,
    data_json TEXT NOT NULL,
    PRIMARY KEY (conversation_id, turn, turn_id)
);

CREATE TABLE IF NOT EXISTS tool_calls (
    id SERIAL PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    request_turn INTEGER NOT NULL,
    round INTEGER NOT NULL,
    group_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    tool_input TEXT NOT NULL,
    tool_result TEXT NOT NULL,
    result_length INTEGER NOT NULL,
    duration_ms DOUBLE PRECISION NOT NULL,
    found BOOLEAN,
    timestamp TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tool_calls_conv ON tool_calls(conversation_id);
CREATE INDEX IF NOT EXISTS idx_tool_calls_group ON tool_calls(group_id);

CREATE TABLE IF NOT EXISTS request_context (
    id SERIAL PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    request_turn INTEGER NOT NULL,
    timestamp TEXT NOT NULL,
    user_message TEXT NOT NULL,
    inbound_tags TEXT NOT NULL,
    retrieval_method TEXT NOT NULL,
    candidates_found INTEGER NOT NULL,
    candidates_selected INTEGER NOT NULL,
    segments_injected TEXT NOT NULL,
    facts_injected TEXT NOT NULL,
    facts_count INTEGER NOT NULL,
    facts_tags TEXT NOT NULL,
    pool_used INTEGER NOT NULL,
    pool_budget INTEGER NOT NULL,
    total_context_tokens INTEGER NOT NULL,
    non_virtualizable_floor INTEGER NOT NULL,
    tool_call_count INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_request_context_conv ON request_context(conversation_id);

CREATE TABLE IF NOT EXISTS tag_summary_embeddings (
    tag TEXT NOT NULL,
    conversation_id TEXT NOT NULL DEFAULT '',
    embedding_json TEXT NOT NULL,
    PRIMARY KEY (tag, conversation_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_segments_primary_tag ON segments(primary_tag);
CREATE INDEX IF NOT EXISTS idx_segments_created_at ON segments(created_at);
CREATE INDEX IF NOT EXISTS idx_segments_conversation_id ON segments(conversation_id);
CREATE INDEX IF NOT EXISTS idx_segment_tags_tag ON segment_tags(tag);
CREATE INDEX IF NOT EXISTS idx_facts_subject ON facts(subject);
CREATE INDEX IF NOT EXISTS idx_facts_verb ON facts(verb);
CREATE INDEX IF NOT EXISTS idx_facts_status ON facts(status);
CREATE INDEX IF NOT EXISTS idx_facts_subject_verb ON facts(subject, verb);
CREATE INDEX IF NOT EXISTS idx_facts_segment_ref ON facts(segment_ref);
CREATE INDEX IF NOT EXISTS idx_facts_conversation_id ON facts(conversation_id);
CREATE INDEX IF NOT EXISTS idx_facts_fact_type ON facts(fact_type);
CREATE INDEX IF NOT EXISTS idx_fact_tags_tag ON fact_tags(tag);
CREATE INDEX IF NOT EXISTS idx_fact_links_source ON fact_links(source_fact_id);
CREATE INDEX IF NOT EXISTS idx_fact_links_target ON fact_links(target_fact_id);
CREATE INDEX IF NOT EXISTS idx_fact_links_type ON fact_links(relation_type);

CREATE TABLE IF NOT EXISTS turn_tool_outputs (
    conversation_id TEXT NOT NULL,
    turn_number INTEGER NOT NULL,
    tool_output_ref TEXT NOT NULL,
    PRIMARY KEY (conversation_id, turn_number, tool_output_ref)
);

CREATE TABLE IF NOT EXISTS segment_tool_outputs (
    conversation_id TEXT NOT NULL,
    segment_ref TEXT NOT NULL,
    tool_output_ref TEXT NOT NULL,
    PRIMARY KEY (conversation_id, segment_ref, tool_output_ref)
);

CREATE TABLE IF NOT EXISTS chain_snapshots (
    ref TEXT PRIMARY KEY,
    conversation_id TEXT NOT NULL,
    turn_number INTEGER NOT NULL,
    chain_json TEXT NOT NULL,
    message_count INTEGER NOT NULL,
    tool_output_refs TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS media_outputs (
    ref TEXT NOT NULL,
    conversation_id TEXT NOT NULL,
    media_type TEXT NOT NULL,
    width INTEGER NOT NULL,
    height INTEGER NOT NULL,
    original_bytes INTEGER NOT NULL,
    compressed_bytes INTEGER NOT NULL,
    file_path TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT '',
    PRIMARY KEY (conversation_id, ref)
);
"""

# Postgres FTS: tsvector columns + GIN indexes
FTS_SQL = """\
DO $$ BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name='segments' AND column_name='summary_tsv') THEN
        ALTER TABLE segments ADD COLUMN summary_tsv tsvector;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name='segments' AND column_name='full_text_tsv') THEN
        ALTER TABLE segments ADD COLUMN full_text_tsv tsvector;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name='facts' AND column_name='facts_tsv') THEN
        ALTER TABLE facts ADD COLUMN facts_tsv tsvector;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name='tool_outputs' AND column_name='content_tsv') THEN
        ALTER TABLE tool_outputs ADD COLUMN content_tsv tsvector;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name='turn_messages' AND column_name='turn_tsv') THEN
        ALTER TABLE turn_messages ADD COLUMN turn_tsv tsvector;
    END IF;
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                   WHERE table_name='full_text' AND column_name='full_text_tsv') THEN
        ALTER TABLE full_text ADD COLUMN full_text_tsv tsvector;
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_segments_summary_tsv ON segments USING gin(summary_tsv);
CREATE INDEX IF NOT EXISTS idx_segments_full_text_tsv ON segments USING gin(full_text_tsv);
CREATE INDEX IF NOT EXISTS idx_facts_tsv ON facts USING gin(facts_tsv);
CREATE INDEX IF NOT EXISTS idx_tool_outputs_tsv ON tool_outputs USING gin(content_tsv);
CREATE INDEX IF NOT EXISTS idx_turn_messages_tsv ON turn_messages USING gin(turn_tsv);
CREATE INDEX IF NOT EXISTS idx_full_text_tsv ON full_text USING gin(full_text_tsv);

-- Triggers to keep tsvector columns in sync
CREATE OR REPLACE FUNCTION segments_summary_tsv_trigger() RETURNS trigger AS $$
BEGIN
    NEW.summary_tsv := to_tsvector('english', COALESCE(NEW.summary, ''));
    RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION segments_full_text_tsv_trigger() RETURNS trigger AS $$
BEGIN
    NEW.full_text_tsv := to_tsvector('english', COALESCE(NEW.full_text, ''));
    RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION facts_tsv_trigger() RETURNS trigger AS $$
BEGIN
    NEW.facts_tsv := to_tsvector('english',
        COALESCE(NEW.subject, '') || ' ' || COALESCE(NEW.verb, '') || ' ' ||
        COALESCE(NEW.object, '') || ' ' || COALESCE(NEW.what, ''));
    RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION tool_outputs_tsv_trigger() RETURNS trigger AS $$
BEGIN
    NEW.content_tsv := to_tsvector('english', COALESCE(NEW.content, ''));
    RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION turn_messages_tsv_trigger() RETURNS trigger AS $$
BEGIN
    NEW.turn_tsv := to_tsvector(
        'english',
        COALESCE(NEW.user_content, '') || ' ' || COALESCE(NEW.assistant_content, '')
    );
    RETURN NEW;
END $$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION canonical_full_text_tsv_trigger() RETURNS trigger AS $$
BEGIN
    NEW.full_text_tsv := to_tsvector(
        'english',
        COALESCE(NEW.user_content, '') || ' ' || COALESCE(NEW.assistant_content, '')
    );
    RETURN NEW;
END $$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_segments_summary_tsv ON segments;
CREATE TRIGGER trg_segments_summary_tsv BEFORE INSERT OR UPDATE ON segments
    FOR EACH ROW EXECUTE FUNCTION segments_summary_tsv_trigger();

DROP TRIGGER IF EXISTS trg_segments_full_text_tsv ON segments;
CREATE TRIGGER trg_segments_full_text_tsv BEFORE INSERT OR UPDATE ON segments
    FOR EACH ROW EXECUTE FUNCTION segments_full_text_tsv_trigger();

DROP TRIGGER IF EXISTS trg_facts_tsv ON facts;
CREATE TRIGGER trg_facts_tsv BEFORE INSERT OR UPDATE ON facts
    FOR EACH ROW EXECUTE FUNCTION facts_tsv_trigger();

DROP TRIGGER IF EXISTS trg_tool_outputs_tsv ON tool_outputs;
CREATE TRIGGER trg_tool_outputs_tsv BEFORE INSERT OR UPDATE ON tool_outputs
    FOR EACH ROW EXECUTE FUNCTION tool_outputs_tsv_trigger();

DROP TRIGGER IF EXISTS trg_turn_messages_tsv ON turn_messages;
CREATE TRIGGER trg_turn_messages_tsv BEFORE INSERT OR UPDATE ON turn_messages
    FOR EACH ROW EXECUTE FUNCTION turn_messages_tsv_trigger();

DROP TRIGGER IF EXISTS trg_canonical_full_text_tsv ON full_text;
CREATE TRIGGER trg_canonical_full_text_tsv BEFORE INSERT OR UPDATE ON full_text
    FOR EACH ROW EXECUTE FUNCTION canonical_full_text_tsv_trigger();
"""


def _escape_like(text: str) -> str:
    return text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _turn_query_terms(query: str) -> list[str]:
    return [term.lower() for term in re.findall(r"[a-zA-Z0-9_.%-]+", query or "") if len(term) >= 2]


def _text_term_hits(text: str, terms: list[str]) -> int:
    lowered = (text or "").lower()
    if not lowered or not terms:
        return 0
    return sum(1 for term in terms if re.search(rf"\b{re.escape(term)}\b", lowered))


def _matched_turn_side(query: str, user_text: str, assistant_text: str) -> str:
    query_lower = (query or "").strip().lower()
    user_lower = (user_text or "").lower()
    assistant_lower = (assistant_text or "").lower()
    user_hits = 0
    assistant_hits = 0
    if query_lower:
        if query_lower in user_lower:
            user_hits += 2
        if query_lower in assistant_lower:
            assistant_hits += 2
    terms = _turn_query_terms(query)
    user_hits += _text_term_hits(user_text, terms)
    assistant_hits += _text_term_hits(assistant_text, terms)
    if user_hits and assistant_hits:
        return "both"
    if user_hits:
        return "user"
    if assistant_hits:
        return "assistant"
    return "unknown"


def _build_turn_excerpt(
    query: str,
    user_text: str,
    assistant_text: str,
    matched_side: str,
    *,
    context_chars: int = 200,
) -> str:
    if matched_side == "user":
        return f"User: {_extract_excerpt(user_text or '', query, context_chars=context_chars)}"
    if matched_side == "assistant":
        return f"Assistant: {_extract_excerpt(assistant_text or '', query, context_chars=context_chars)}"
    if matched_side == "both":
        return (
            f"User: {_extract_excerpt(user_text or '', query, context_chars=context_chars)}\n\n"
            f"Assistant: {_extract_excerpt(assistant_text or '', query, context_chars=context_chars)}"
        )
    combined = f"User: {user_text or ''}\n\nAssistant: {assistant_text or ''}".strip()
    return _extract_excerpt(combined, query, context_chars=context_chars)


def _row_to_segment(row: dict, tags: list[str]) -> StoredSegment:
    metadata_raw = json.loads(row["metadata_json"])
    return StoredSegment(
        ref=row["ref"],
        conversation_id=row["conversation_id"],
        primary_tag=row["primary_tag"],
        tags=tags,
        summary=row["summary"],
        summary_tokens=row["summary_tokens"],
        full_text=row["full_text"],
        full_tokens=row["full_tokens"],
        messages=json.loads(row["messages_json"]),
        metadata=SegmentMetadata(
            entities=metadata_raw.get("entities", []),
            key_decisions=metadata_raw.get("key_decisions", []),
            action_items=metadata_raw.get("action_items", []),
            date_references=metadata_raw.get("date_references", []),
            code_refs=metadata_raw.get("code_refs", []),
            turn_count=metadata_raw.get("turn_count", 0),
            start_turn_number=metadata_raw.get("start_turn_number", -1),
            end_turn_number=metadata_raw.get("end_turn_number", -1),
            generated_by_turn_id=metadata_raw.get("generated_by_turn_id", ""),
            session_date=metadata_raw.get("session_date", ""),
        ),
        created_at=_str_to_dt(row["created_at"]),
        start_timestamp=_str_to_dt(row["start_timestamp"]),
        end_timestamp=_str_to_dt(row["end_timestamp"]),
        compaction_model=row["compaction_model"],
        compression_ratio=row["compression_ratio"],
    )


def _row_to_summary(row: dict, tags: list[str]) -> StoredSummary:
    metadata_raw = json.loads(row["metadata_json"])
    return StoredSummary(
        ref=row["ref"],
        primary_tag=row["primary_tag"],
        tags=tags,
        summary=row["summary"],
        summary_tokens=row["summary_tokens"],
        full_tokens=row["full_tokens"],
        metadata=SegmentMetadata(
            entities=metadata_raw.get("entities", []),
            key_decisions=metadata_raw.get("key_decisions", []),
            action_items=metadata_raw.get("action_items", []),
            date_references=metadata_raw.get("date_references", []),
            code_refs=metadata_raw.get("code_refs", []),
            turn_count=metadata_raw.get("turn_count", 0),
            start_turn_number=metadata_raw.get("start_turn_number", -1),
            end_turn_number=metadata_raw.get("end_turn_number", -1),
            generated_by_turn_id=metadata_raw.get("generated_by_turn_id", ""),
            session_date=metadata_raw.get("session_date", ""),
        ),
        created_at=_str_to_dt(row["created_at"]),
        start_timestamp=_str_to_dt(row["start_timestamp"]),
        end_timestamp=_str_to_dt(row["end_timestamp"]),
    )


def _row_to_full_text(row: dict) -> FullTextRow:
    try:
        tags = json.loads(row.get("tags_json", "[]") or "[]")
    except Exception:
        tags = []
    try:
        code_refs = json.loads(row.get("code_refs_json", "[]") or "[]")
    except Exception:
        code_refs = []
    fact_signals: list[FactSignal] = []
    try:
        for item in json.loads(row.get("fact_signals_json", "[]") or "[]"):
            if isinstance(item, dict):
                fact_signals.append(
                    FactSignal(
                        subject=item.get("subject", ""),
                        verb=item.get("verb", ""),
                        object=item.get("object", ""),
                        status=item.get("status", ""),
                        fact_type=item.get("fact_type", ""),
                        what=item.get("what", ""),
                    )
                )
    except Exception:
        fact_signals = []
    return FullTextRow(
        conversation_id=row["conversation_id"],
        turn_number=row["turn_number"],
        user_content=row["user_content"] or "",
        assistant_content=row["assistant_content"] or "",
        user_raw_content=row["user_raw_content"],
        assistant_raw_content=row["assistant_raw_content"],
        primary_tag=row.get("primary_tag", "_general") or "_general",
        tags=list(tags or []),
        session_date=row.get("session_date", "") or "",
        sender=row.get("sender", "") or "",
        fact_signals=fact_signals,
        code_refs=list(code_refs or []),
        created_at=row.get("created_at", "") or "",
        updated_at=row.get("updated_at", "") or "",
    )


class PostgresStore(ContextStore):
    """PostgreSQL storage backend with tsvector FTS and full protocol support."""

    def __init__(self, dsn: str) -> None:
        self.dsn = dsn
        self._conn: psycopg.Connection | None = None
        self.search_config = None  # set by engine after construction
        self._ensure_schema()

    def _get_conn(self) -> psycopg.Connection:
        if self._conn is None or self._conn.closed:
            self._conn = psycopg.connect(self.dsn, row_factory=dict_row, autocommit=True)
        return self._conn

    def _ensure_schema(self) -> None:
        conn = self._get_conn()
        # Split SCHEMA_SQL by statements and execute individually
        for stmt in SCHEMA_SQL.split(";"):
            stmt = stmt.strip()
            if stmt:
                try:
                    conn.execute(stmt)
                except Exception:
                    pass  # Table/index already exists
        # FTS setup
        try:
            conn.execute(FTS_SQL)
        except Exception as e:
            logger.warning("FTS setup issue (non-fatal): %s", e)
        # Backfill tsvector columns for existing rows
        try:
            conn.execute("UPDATE segments SET summary_tsv = to_tsvector('english', COALESCE(summary, '')) WHERE summary_tsv IS NULL")
            conn.execute("UPDATE segments SET full_text_tsv = to_tsvector('english', COALESCE(full_text, '')) WHERE full_text_tsv IS NULL")
            conn.execute("UPDATE facts SET facts_tsv = to_tsvector('english', COALESCE(subject,'') || ' ' || COALESCE(verb,'') || ' ' || COALESCE(object,'') || ' ' || COALESCE(what,'')) WHERE facts_tsv IS NULL")
            conn.execute("UPDATE turn_messages SET turn_tsv = to_tsvector('english', COALESCE(user_content,'') || ' ' || COALESCE(assistant_content,'')) WHERE turn_tsv IS NULL")
            conn.execute("UPDATE full_text SET full_text_tsv = to_tsvector('english', COALESCE(user_content,'') || ' ' || COALESCE(assistant_content,'')) WHERE full_text_tsv IS NULL")
        except Exception:
            pass
        # Migration: add raw_content columns to turn_messages
        try:
            conn.execute("""
                DO $$ BEGIN
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='turn_messages' AND column_name='user_raw_content') THEN
                        ALTER TABLE turn_messages ADD COLUMN user_raw_content TEXT;
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='turn_messages' AND column_name='assistant_raw_content') THEN
                        ALTER TABLE turn_messages ADD COLUMN assistant_raw_content TEXT;
                    END IF;
                END $$;
            """)
        except Exception:
            pass
        try:
            conn.execute("""
                DO $$ BEGIN
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='full_text' AND column_name='primary_tag') THEN
                        ALTER TABLE full_text ADD COLUMN primary_tag TEXT NOT NULL DEFAULT '_general';
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='full_text' AND column_name='tags_json') THEN
                        ALTER TABLE full_text ADD COLUMN tags_json TEXT NOT NULL DEFAULT '[]';
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='full_text' AND column_name='session_date') THEN
                        ALTER TABLE full_text ADD COLUMN session_date TEXT NOT NULL DEFAULT '';
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='full_text' AND column_name='sender') THEN
                        ALTER TABLE full_text ADD COLUMN sender TEXT NOT NULL DEFAULT '';
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='full_text' AND column_name='fact_signals_json') THEN
                        ALTER TABLE full_text ADD COLUMN fact_signals_json TEXT NOT NULL DEFAULT '[]';
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='full_text' AND column_name='code_refs_json') THEN
                        ALTER TABLE full_text ADD COLUMN code_refs_json TEXT NOT NULL DEFAULT '[]';
                    END IF;
                END $$;
            """)
        except Exception:
            pass
        try:
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_full_text_chunks_conversation ON full_text_chunks(conversation_id, turn_number, side)"
            )
        except Exception:
            pass
        try:
            conn.execute("""
                DO $$ BEGIN
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='tag_summaries' AND column_name='code_refs') THEN
                        ALTER TABLE tag_summaries ADD COLUMN code_refs TEXT NOT NULL DEFAULT '[]';
                    END IF;
                    IF NOT EXISTS (SELECT 1 FROM information_schema.columns
                                   WHERE table_name='tag_summaries' AND column_name='generated_by_turn_id') THEN
                        ALTER TABLE tag_summaries ADD COLUMN generated_by_turn_id TEXT NOT NULL DEFAULT '';
                    END IF;
                END $$;
            """)
        except Exception:
            pass
        try:
            conn.execute("""
                DO $$ DECLARE
                    pk_cols text[];
                BEGIN
                    IF EXISTS (
                        SELECT 1 FROM information_schema.tables
                        WHERE table_name = 'request_captures'
                    ) THEN
                        IF NOT EXISTS (
                            SELECT 1 FROM information_schema.columns
                            WHERE table_name='request_captures' AND column_name='conversation_id'
                        ) THEN
                            ALTER TABLE request_captures
                                ADD COLUMN conversation_id TEXT NOT NULL DEFAULT '';
                            UPDATE request_captures
                            SET conversation_id = COALESCE(data_json::jsonb->>'conversation_id', '');
                        END IF;

                        IF NOT EXISTS (
                            SELECT 1 FROM information_schema.columns
                            WHERE table_name='request_captures' AND column_name='turn_id'
                        ) THEN
                            ALTER TABLE request_captures
                                ADD COLUMN turn_id TEXT NOT NULL DEFAULT '';
                            UPDATE request_captures
                            SET turn_id = COALESCE(data_json::jsonb->>'turn_id', '');
                        END IF;

                        SELECT array_agg(kcu.column_name ORDER BY kcu.ordinal_position)
                        INTO pk_cols
                        FROM information_schema.table_constraints tc
                        JOIN information_schema.key_column_usage kcu
                          ON tc.constraint_name = kcu.constraint_name
                         AND tc.table_schema = kcu.table_schema
                         AND tc.table_name = kcu.table_name
                        WHERE tc.table_name = 'request_captures'
                          AND tc.constraint_type = 'PRIMARY KEY';

                        IF pk_cols IS NULL OR pk_cols <> ARRAY['conversation_id', 'turn', 'turn_id'] THEN
                            IF EXISTS (
                                SELECT 1 FROM information_schema.table_constraints
                                WHERE table_name='request_captures'
                                  AND constraint_type='PRIMARY KEY'
                            ) THEN
                                ALTER TABLE request_captures DROP CONSTRAINT request_captures_pkey;
                            END IF;
                            ALTER TABLE request_captures
                                ADD PRIMARY KEY (conversation_id, turn, turn_id);
                        END IF;
                    END IF;
                END $$;
            """)
        except Exception:
            pass
        try:
            conn.execute("""
                DO $$ DECLARE
                    pk_cols text[];
                BEGIN
                    IF EXISTS (
                        SELECT 1 FROM information_schema.tables
                        WHERE table_name = 'tag_aliases'
                    ) THEN
                        IF NOT EXISTS (
                            SELECT 1 FROM information_schema.columns
                            WHERE table_name='tag_aliases' AND column_name='conversation_id'
                        ) THEN
                            ALTER TABLE tag_aliases
                                ADD COLUMN conversation_id TEXT NOT NULL DEFAULT '';
                        END IF;

                        SELECT array_agg(kcu.column_name ORDER BY kcu.ordinal_position)
                        INTO pk_cols
                        FROM information_schema.table_constraints tc
                        JOIN information_schema.key_column_usage kcu
                          ON tc.constraint_name = kcu.constraint_name
                         AND tc.table_schema = kcu.table_schema
                         AND tc.table_name = kcu.table_name
                        WHERE tc.table_name = 'tag_aliases'
                          AND tc.constraint_type = 'PRIMARY KEY';

                        IF pk_cols IS NULL OR pk_cols <> ARRAY['alias', 'conversation_id'] THEN
                            IF EXISTS (
                                SELECT 1 FROM information_schema.table_constraints
                                WHERE table_name='tag_aliases'
                                  AND constraint_type='PRIMARY KEY'
                            ) THEN
                                ALTER TABLE tag_aliases DROP CONSTRAINT tag_aliases_pkey;
                            END IF;
                            ALTER TABLE tag_aliases
                                ADD PRIMARY KEY (alias, conversation_id);
                        END IF;
                    END IF;
                END $$;
            """)
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_tags_for_ref(self, ref: str) -> list[str]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT tag FROM segment_tags WHERE segment_ref = %s ORDER BY tag", (ref,)
        ).fetchall()
        return [r["tag"] for r in rows]

    def _batch_get_tags(self, refs: list[str]) -> dict[str, list[str]]:
        if not refs:
            return {}
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT segment_ref, tag FROM segment_tags WHERE segment_ref = ANY(%s) ORDER BY segment_ref, tag",
            (refs,),
        ).fetchall()
        result: dict[str, list[str]] = {ref: [] for ref in refs}
        for row in rows:
            result[row["segment_ref"]].append(row["tag"])
        return result

    def _row_to_fact(self, row: dict) -> Fact:
        return Fact.from_dict(row, dt_parser=_str_to_dt)

    def _row_to_fact_link(self, row: dict) -> FactLink:
        return FactLink(
            id=row["id"],
            source_fact_id=row["source_fact_id"],
            target_fact_id=row["target_fact_id"],
            relation_type=row["relation_type"],
            confidence=row["confidence"],
            context=row["context"],
            created_at=_str_to_dt(row["created_at"]) if row.get("created_at") else datetime.now(timezone.utc),
            created_by=row["created_by"],
        )

    # ------------------------------------------------------------------
    # SegmentStore
    # ------------------------------------------------------------------

    def store_segment(self, segment: StoredSegment) -> str:
        conn = self._get_conn()
        primary_tag = segment.primary_tag
        summary_text = segment.summary
        full_text = segment.full_text
        metadata_dict = {
            "entities": segment.metadata.entities,
            "key_decisions": segment.metadata.key_decisions,
            "action_items": segment.metadata.action_items,
            "date_references": segment.metadata.date_references,
            "code_refs": getattr(segment.metadata, "code_refs", []),
            "turn_count": segment.metadata.turn_count,
            "start_turn_number": getattr(segment.metadata, "start_turn_number", -1),
            "end_turn_number": getattr(segment.metadata, "end_turn_number", -1),
            "generated_by_turn_id": getattr(segment.metadata, "generated_by_turn_id", ""),
        }
        if segment.metadata.session_date:
            metadata_dict["session_date"] = segment.metadata.session_date

        with conn.transaction():
            conn.execute(
                """INSERT INTO segments
                (ref, conversation_id, primary_tag, summary, full_text, messages_json,
                 metadata_json, summary_tokens, full_tokens, compression_ratio,
                 compaction_model, created_at, start_timestamp, end_timestamp)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (ref) DO UPDATE SET
                    conversation_id=EXCLUDED.conversation_id, primary_tag=EXCLUDED.primary_tag,
                    summary=EXCLUDED.summary, full_text=EXCLUDED.full_text,
                    messages_json=EXCLUDED.messages_json, metadata_json=EXCLUDED.metadata_json,
                    summary_tokens=EXCLUDED.summary_tokens, full_tokens=EXCLUDED.full_tokens,
                    compression_ratio=EXCLUDED.compression_ratio, compaction_model=EXCLUDED.compaction_model,
                    created_at=EXCLUDED.created_at, start_timestamp=EXCLUDED.start_timestamp,
                    end_timestamp=EXCLUDED.end_timestamp""",
                (segment.ref, segment.conversation_id, primary_tag, summary_text,
                 full_text, json.dumps(segment.messages, default=str),
                 json.dumps(metadata_dict), segment.summary_tokens, segment.full_tokens,
                 segment.compression_ratio, segment.compaction_model,
                 _dt_to_str(segment.created_at), _dt_to_str(segment.start_timestamp),
                 _dt_to_str(segment.end_timestamp)),
            )
            conn.execute("DELETE FROM segment_tags WHERE segment_ref = %s", (segment.ref,))
            for tag in segment.tags:
                conn.execute(
                    "INSERT INTO segment_tags (segment_ref, tag) VALUES (%s, %s)",
                    (segment.ref, tag),
                )
        return segment.ref

    def get_segment(self, ref: str, conversation_id: str | None = None) -> StoredSegment | None:
        conn = self._get_conn()
        if conversation_id is not None:
            row = conn.execute(
                "SELECT * FROM segments WHERE ref = %s AND conversation_id = %s",
                (ref, conversation_id),
            ).fetchone()
        else:
            row = conn.execute("SELECT * FROM segments WHERE ref = %s", (ref,)).fetchone()
        if not row:
            return None
        return _row_to_segment(row, self._get_tags_for_ref(ref))

    def get_summary(self, ref: str, conversation_id: str | None = None) -> StoredSummary | None:
        conn = self._get_conn()
        if conversation_id is not None:
            row = conn.execute(
                "SELECT * FROM segments WHERE ref = %s AND conversation_id = %s",
                (ref, conversation_id),
            ).fetchone()
        else:
            row = conn.execute("SELECT * FROM segments WHERE ref = %s", (ref,)).fetchone()
        if not row:
            return None
        return _row_to_summary(row, self._get_tags_for_ref(ref))

    def get_all_segments(
        self,
        *,
        conversation_id: str | None = None,
        limit: int | None = None,
    ) -> list[StoredSegment]:
        conn = self._get_conn()
        if conversation_id is not None and limit is not None and limit > 0:
            rows = conn.execute(
                "SELECT * FROM segments WHERE conversation_id = %s ORDER BY created_at DESC LIMIT %s",
                (conversation_id, limit),
            ).fetchall()
        elif conversation_id is not None:
            rows = conn.execute(
                "SELECT * FROM segments WHERE conversation_id = %s ORDER BY created_at DESC",
                (conversation_id,),
            ).fetchall()
        elif limit is not None and limit > 0:
            rows = conn.execute(
                "SELECT * FROM segments ORDER BY created_at DESC LIMIT %s",
                (limit,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM segments ORDER BY created_at DESC").fetchall()
        if not rows:
            return []
        refs = [row["ref"] for row in rows]
        tags_map = self._get_tags_for_refs(refs)
        return [_row_to_segment(row, tags_map.get(row["ref"], [])) for row in rows]

    def get_summaries_by_tags(
        self, tags: list[str], min_overlap: int = 1, limit: int = 10,
        before: datetime | None = None, after: datetime | None = None,
        conversation_id: str | None = None,
    ) -> list[StoredSummary]:
        if not tags:
            return []
        conn = self._get_conn()
        query = """
            SELECT s.*, COUNT(st.tag) as overlap_count
            FROM segments s
            JOIN segment_tags st ON s.ref = st.segment_ref
            WHERE st.tag = ANY(%s)
        """
        params: list = [tags]
        if conversation_id is not None:
            query += " AND s.conversation_id = %s"
            params.append(conversation_id)
        if before:
            query += " AND s.created_at < %s"
            params.append(_dt_to_str(before))
        if after:
            query += " AND s.created_at > %s"
            params.append(_dt_to_str(after))
        query += """
            GROUP BY s.ref
            HAVING COUNT(st.tag) >= %s
            ORDER BY COUNT(st.tag) DESC, s.created_at DESC
            LIMIT %s
        """
        params.extend([min_overlap, limit])
        rows = conn.execute(query, params).fetchall()
        refs = [row["ref"] for row in rows]
        tags_map = self._batch_get_tags(refs)
        return [_row_to_summary(row, tags_map[row["ref"]]) for row in rows]

    def search(self, query: str, tags: list[str] | None = None, limit: int = 5, conversation_id: str | None = None) -> list[StoredSummary]:
        conn = self._get_conn()
        tsquery = " & ".join(query.split())
        if tags:
            sql = """SELECT DISTINCT s.* FROM segments s
                JOIN segment_tags st ON s.ref = st.segment_ref
                WHERE s.summary_tsv @@ to_tsquery('english', %s)
                AND st.tag = ANY(%s)"""
            params: list = [tsquery, tags]
            if conversation_id is not None:
                sql += " AND s.conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY s.created_at DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
        else:
            sql = """SELECT * FROM segments
                WHERE summary_tsv @@ to_tsquery('english', %s)"""
            params = [tsquery]
            if conversation_id is not None:
                sql += " AND conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY created_at DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
        refs = [row["ref"] for row in rows]
        tags_map = self._batch_get_tags(refs)
        return [_row_to_summary(row, tags_map[row["ref"]]) for row in rows]

    def get_all_tags(self, conversation_id: str | None = None) -> list[TagStats]:
        conn = self._get_conn()
        if conversation_id is not None:
            rows = conn.execute("""
                SELECT st.tag,
                       COUNT(DISTINCT st.segment_ref) as usage_count,
                       COALESCE(SUM(s.full_tokens), 0) as total_full,
                       COALESCE(SUM(s.summary_tokens), 0) as total_summary,
                       MIN(s.created_at) as oldest,
                       MAX(s.created_at) as newest
                FROM segment_tags st
                JOIN segments s ON s.ref = st.segment_ref
                WHERE s.conversation_id = %s
                GROUP BY st.tag
                ORDER BY usage_count DESC
            """, (conversation_id,)).fetchall()
        else:
            rows = conn.execute("""
                SELECT st.tag,
                       COUNT(DISTINCT st.segment_ref) as usage_count,
                       COALESCE(SUM(s.full_tokens), 0) as total_full,
                       COALESCE(SUM(s.summary_tokens), 0) as total_summary,
                       MIN(s.created_at) as oldest,
                       MAX(s.created_at) as newest
                FROM segment_tags st
                JOIN segments s ON s.ref = st.segment_ref
                GROUP BY st.tag
                ORDER BY usage_count DESC
            """).fetchall()
        return [
            TagStats(
                tag=row["tag"],
                usage_count=row["usage_count"],
                total_full_tokens=row["total_full"],
                total_summary_tokens=row["total_summary"],
                oldest_segment=_str_to_dt(row["oldest"]),
                newest_segment=_str_to_dt(row["newest"]),
            )
            for row in rows
        ]

    def get_conversation_stats(self) -> list[ConversationStats]:
        conn = self._get_conn()
        rows = conn.execute("""
            SELECT conversation_id, COUNT(*) as seg_count,
                   SUM(full_tokens) as total_full, SUM(summary_tokens) as total_summary,
                   MIN(created_at) as oldest, MAX(created_at) as newest,
                   compaction_model
            FROM segments WHERE conversation_id != ''
            GROUP BY conversation_id, compaction_model
            ORDER BY MAX(created_at) DESC
        """).fetchall()
        # Batch-fetch distinct tags per conversation (avoids N+1)
        conv_ids = [row["conversation_id"] for row in rows]
        tags_by_conv: dict[str, list[str]] = {cid: [] for cid in conv_ids}
        if conv_ids:
            tag_rows = conn.execute(
                """SELECT s.conversation_id, st.tag
                FROM segment_tags st
                JOIN segments s ON s.ref = st.segment_ref
                WHERE s.conversation_id = ANY(%s)
                GROUP BY s.conversation_id, st.tag
                ORDER BY st.tag""",
                (conv_ids,),
            ).fetchall()
            for tr in tag_rows:
                tags_by_conv[tr["conversation_id"]].append(tr["tag"])

        results = []
        for row in rows:
            results.append(ConversationStats(
                conversation_id=row["conversation_id"],
                segment_count=row["seg_count"],
                total_full_tokens=row["total_full"],
                total_summary_tokens=row["total_summary"],
                oldest_segment=_str_to_dt(row["oldest"]),
                newest_segment=_str_to_dt(row["newest"]),
                distinct_tags=tags_by_conv.get(row["conversation_id"], []),
                compaction_model=row["compaction_model"],
            ))
        return results

    def get_tag_aliases(self, conversation_id: str | None = None) -> dict[str, str]:
        conn = self._get_conn()
        params: list[object] = []
        query = "SELECT alias, canonical, conversation_id FROM tag_aliases"
        if conversation_id:
            query += " WHERE conversation_id IN ('', %s)"
            params.append(conversation_id)
        else:
            query += " WHERE conversation_id = ''"
        query += " ORDER BY CASE WHEN conversation_id = '' THEN 0 ELSE 1 END, alias"
        rows = conn.execute(query, params).fetchall()
        aliases: dict[str, str] = {}
        for row in rows:
            aliases[row["alias"]] = row["canonical"]
        return aliases

    def set_tag_alias(
        self,
        alias: str,
        canonical: str,
        conversation_id: str = "",
    ) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tag_aliases (alias, conversation_id, canonical)
            VALUES (%s, %s, %s)
            ON CONFLICT (alias, conversation_id)
            DO UPDATE SET canonical = EXCLUDED.canonical""",
            (alias, conversation_id or "", canonical),
        )

    def delete_tag_aliases_for_conversation(self, conversation_id: str) -> int:
        conn = self._get_conn()
        cur = conn.execute(
            "DELETE FROM tag_aliases WHERE conversation_id = %s",
            (conversation_id,),
        )
        return int(cur.rowcount or 0)

    def delete_segment(self, ref: str) -> bool:
        conn = self._get_conn()
        with conn.transaction():
            conn.execute("DELETE FROM segment_tags WHERE segment_ref = %s", (ref,))
            conn.execute("DELETE FROM segment_chunks WHERE segment_ref = %s", (ref,))
            conn.execute("DELETE FROM facts WHERE segment_ref = %s", (ref,))
            cur = conn.execute("DELETE FROM segments WHERE ref = %s", (ref,))
        return cur.rowcount > 0

    def cleanup(self, max_age: timedelta | None = None, max_total_tokens: int | None = None) -> int:
        if not max_age:
            return 0
        conn = self._get_conn()
        cutoff = _dt_to_str(datetime.now(timezone.utc) - max_age)
        cur = conn.execute("DELETE FROM segments WHERE created_at < %s", (cutoff,))
        return cur.rowcount

    def _table_exists(self, conn, table: str) -> bool:
        row = conn.execute(
            "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = %s)",
            (table,),
        ).fetchone()
        if not row:
            return False
        if isinstance(row, dict):
            return bool(next(iter(row.values())))
        return bool(row[0])

    def _delete_conversation_rows(self, conn, table: str, conversation_id: str) -> int:
        if not self._table_exists(conn, table):
            return 0
        cur = conn.execute(
            f"DELETE FROM {table} WHERE conversation_id = %s",
            (conversation_id,),
        )
        return int(cur.rowcount or 0)

    def activate_conversation(self, conversation_id: str) -> int:
        conn = self._get_conn()
        row = conn.execute(
            """INSERT INTO conversation_lifecycle (conversation_id, generation, deleted, updated_at)
            VALUES (%s, 0, FALSE, %s)
            ON CONFLICT (conversation_id) DO UPDATE SET
                deleted = FALSE,
                updated_at = EXCLUDED.updated_at
            RETURNING generation""",
            (conversation_id, _dt_to_str(datetime.now(timezone.utc))),
        ).fetchone()
        return int(row["generation"] if isinstance(row, dict) else row[0])

    def begin_conversation_deletion(self, conversation_id: str) -> int:
        conn = self._get_conn()
        row = conn.execute(
            """INSERT INTO conversation_lifecycle (conversation_id, generation, deleted, updated_at)
            VALUES (%s, 1, TRUE, %s)
            ON CONFLICT (conversation_id) DO UPDATE SET
                generation = conversation_lifecycle.generation + 1,
                deleted = TRUE,
                updated_at = EXCLUDED.updated_at
            RETURNING generation""",
            (conversation_id, _dt_to_str(datetime.now(timezone.utc))),
        ).fetchone()
        return int(row["generation"] if isinstance(row, dict) else row[0])

    def get_conversation_generation(self, conversation_id: str) -> int:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT generation FROM conversation_lifecycle WHERE conversation_id = %s",
            (conversation_id,),
        ).fetchone()
        if not row:
            return 0
        return int(row["generation"] if isinstance(row, dict) else row[0])

    def is_conversation_generation_current(
        self,
        conversation_id: str,
        generation: int,
    ) -> bool:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT generation, deleted FROM conversation_lifecycle WHERE conversation_id = %s",
            (conversation_id,),
        ).fetchone()
        if not row:
            return int(generation or 0) == 0
        current = int(row["generation"] if isinstance(row, dict) else row[0])
        deleted = bool(row["deleted"] if isinstance(row, dict) else row[1])
        return current == int(generation or 0) and not deleted

    def delete_conversation(self, conversation_id: str) -> int:
        conn = self._get_conn()
        with conn.transaction():
            deleted = self._delete_conversation_rows(conn, "segments", conversation_id)
            for table in (
                "engine_state",
                "facts",
                "full_text",
                "full_text_chunks",
                "turn_messages",
                "tag_summaries",
                "tag_aliases",
                "request_captures",
                "tool_outputs",
                "tool_calls",
                "request_context",
                "tag_summary_embeddings",
                "turn_tool_outputs",
                "segment_tool_outputs",
                "chain_snapshots",
                "media_outputs",
            ):
                self._delete_conversation_rows(conn, table, conversation_id)

        # Disk cleanup: remove media files for this conversation
        import os
        import shutil
        _data_dir = os.environ.get("VC_DATA_DIR", "/data/tenants")
        media_dir = os.path.join(_data_dir, "media", conversation_id) if _data_dir else ""
        if media_dir and os.path.isdir(media_dir):
            shutil.rmtree(media_dir, ignore_errors=True)

        return deleted

    def save_tag_summary(self, tag_summary: TagSummary, conversation_id: str = "") -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tag_summaries
            (tag, conversation_id, summary, description, code_refs, summary_tokens, source_segment_refs, source_turn_numbers,
             covers_through_turn, generated_by_turn_id, created_at, updated_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (tag, conversation_id) DO UPDATE SET
                summary=EXCLUDED.summary, description=EXCLUDED.description, code_refs=EXCLUDED.code_refs,
                summary_tokens=EXCLUDED.summary_tokens,
                source_segment_refs=EXCLUDED.source_segment_refs,
                source_turn_numbers=EXCLUDED.source_turn_numbers,
                covers_through_turn=EXCLUDED.covers_through_turn,
                generated_by_turn_id=EXCLUDED.generated_by_turn_id,
                updated_at=EXCLUDED.updated_at""",
            (tag_summary.tag, conversation_id, tag_summary.summary, getattr(tag_summary, "description", ""),
             json.dumps(getattr(tag_summary, "code_refs", []) or []),
             tag_summary.summary_tokens, json.dumps(tag_summary.source_segment_refs),
             json.dumps(tag_summary.source_turn_numbers), tag_summary.covers_through_turn,
             getattr(tag_summary, "generated_by_turn_id", "") or "",
             _dt_to_str(tag_summary.created_at), _dt_to_str(tag_summary.updated_at)),
        )

    def get_tag_summary(self, tag: str, conversation_id: str = "") -> TagSummary | None:
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM tag_summaries WHERE tag = %s AND conversation_id = %s", (tag, conversation_id)).fetchone()
        if not row:
            return None
        return TagSummary(
            tag=row["tag"], summary=row["summary"],
            description=row.get("description", ""),
            code_refs=json.loads(row.get("code_refs", "[]") or "[]"),
            summary_tokens=row["summary_tokens"],
            source_segment_refs=json.loads(row["source_segment_refs"]),
            source_turn_numbers=json.loads(row["source_turn_numbers"]),
            covers_through_turn=row["covers_through_turn"],
            generated_by_turn_id=row.get("generated_by_turn_id", ""),
            created_at=_str_to_dt(row["created_at"]),
            updated_at=_str_to_dt(row["updated_at"]),
        )

    def get_all_tag_summaries(self, *, conversation_id: str | None = None) -> list[TagSummary]:
        conn = self._get_conn()
        if conversation_id is not None:
            rows = conn.execute(
                "SELECT * FROM tag_summaries WHERE conversation_id = %s ORDER BY updated_at DESC",
                (conversation_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM tag_summaries ORDER BY updated_at DESC").fetchall()
        return [
            TagSummary(
                tag=row["tag"], summary=row["summary"],
                description=row.get("description", ""),
                code_refs=json.loads(row.get("code_refs", "[]") or "[]"),
                summary_tokens=row["summary_tokens"],
                source_segment_refs=json.loads(row["source_segment_refs"]),
                source_turn_numbers=json.loads(row["source_turn_numbers"]),
                covers_through_turn=row["covers_through_turn"],
                generated_by_turn_id=row.get("generated_by_turn_id", ""),
                created_at=_str_to_dt(row["created_at"]),
                updated_at=_str_to_dt(row["updated_at"]),
            )
            for row in rows
        ]

    def get_segments_by_tags(self, tags: list[str], min_overlap: int = 1, limit: int = 20, conversation_id: str | None = None) -> list[StoredSegment]:
        if not tags:
            return []
        conn = self._get_conn()
        sql = """SELECT s.*, COUNT(st.tag) as overlap_count
            FROM segments s JOIN segment_tags st ON s.ref = st.segment_ref
            WHERE st.tag = ANY(%s)"""
        params: list = [tags]
        if conversation_id is not None:
            sql += " AND s.conversation_id = %s"
            params.append(conversation_id)
        sql += """ GROUP BY s.ref HAVING COUNT(st.tag) >= %s
            ORDER BY COUNT(st.tag) DESC, s.created_at DESC LIMIT %s"""
        params.extend([min_overlap, limit])
        rows = conn.execute(sql, params).fetchall()
        refs = [row["ref"] for row in rows]
        tags_map = self._batch_get_tags(refs)
        return [_row_to_segment(row, tags_map[row["ref"]]) for row in rows]

    def get_orphan_tag_snippets(self, limit: int = 1000) -> list[dict]:
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT st.tag, substring(s.summary from 1 for 100) as snippet
            FROM segment_tags st JOIN segments s ON s.ref = st.segment_ref
            WHERE st.tag NOT IN (SELECT tag FROM tag_summaries)
            GROUP BY st.tag, substring(s.summary from 1 for 100) LIMIT %s""",
            (limit,),
        ).fetchall()
        return [{"tag": row["tag"], "snippet": row["snippet"]} for row in rows]

    # ------------------------------------------------------------------
    # SearchStore
    # ------------------------------------------------------------------

    def search_full_text(self, query: str, limit: int = 5, conversation_id: str | None = None) -> list[QuoteResult]:
        conn = self._get_conn()
        _sc = self.search_config
        _pg_words = _sc.postgres_max_words if _sc else 100
        tsquery = " & ".join(query.split())
        try:
            sql = """SELECT s.ref, s.primary_tag, s.metadata_json,
                    ts_headline('english', s.full_text, to_tsquery('english', %s),
                                'StartSel=>>>, StopSel=<<<, MaxFragments=1, MaxWords=""" + str(_pg_words) + """') as excerpt,
                    s.created_at
                FROM segments s
                WHERE s.full_text_tsv @@ to_tsquery('english', %s)"""
            params: list = [tsquery, tsquery]
            if conversation_id is not None:
                sql += " AND s.conversation_id = %s"
                params.append(conversation_id)
            sql += """
                ORDER BY ts_rank(s.full_text_tsv, to_tsquery('english', %s)) DESC
                LIMIT %s"""
            params.extend([tsquery, limit])
            rows = conn.execute(sql, params).fetchall()
        except Exception:
            # Fallback to ILIKE
            _excerpt_chars = _sc.excerpt_context_chars if _sc else 200
            sql = "SELECT ref, primary_tag, full_text, metadata_json, created_at FROM segments WHERE full_text ILIKE %s"
            params = [f"%{query}%"]
            if conversation_id is not None:
                sql += " AND conversation_id = %s"
                params.append(conversation_id)
            sql += " LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            results = []
            for row in rows:
                meta = json.loads(row["metadata_json"])
                results.append(QuoteResult(
                    text=_extract_excerpt(row["full_text"], query, context_chars=_excerpt_chars),
                    tag=row["primary_tag"], segment_ref=row["ref"],
                    session_date=meta.get("session_date", ""),
                    match_type="text_search",
                ))
            return results

        results = []
        for row in rows:
            meta = json.loads(row["metadata_json"])
            results.append(QuoteResult(
                text=row["excerpt"], tag=row["primary_tag"],
                segment_ref=row["ref"],
                session_date=meta.get("session_date", ""),
                match_type="fts",
            ))
        return results

    def search_canonical_full_text(
        self,
        query: str,
        limit: int = 5,
        conversation_id: str | None = None,
    ) -> list[QuoteResult]:
        conn = self._get_conn()
        rows = []
        try:
            sql = """SELECT turn_number, user_content, assistant_content, created_at,
                            primary_tag, tags_json, session_date
                     FROM full_text
                     WHERE full_text_tsv @@ plainto_tsquery('english', %s)"""
            params: list[object] = [query]
            if conversation_id is not None:
                sql += " AND conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY ts_rank(full_text_tsv, plainto_tsquery('english', %s)) DESC, turn_number DESC LIMIT %s"
            params.extend([query, limit])
            rows = conn.execute(sql, params).fetchall()
        except Exception:
            pattern = f"%{query}%"
            sql = """SELECT turn_number, user_content, assistant_content, created_at,
                            primary_tag, tags_json, session_date
                     FROM full_text
                     WHERE (user_content ILIKE %s OR assistant_content ILIKE %s)"""
            params = [pattern, pattern]
            if conversation_id is not None:
                sql += " AND conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY turn_number DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()

        results = []
        _sc = getattr(self, "search_config", None)
        _ctx = _sc.excerpt_context_chars if _sc else 200
        for row in rows:
            turn = row["turn_number"]
            u = row["user_content"] or ""
            a = row["assistant_content"] or ""
            primary_tag = row.get("primary_tag", "_general") or "_general"
            try:
                tags = json.loads(row.get("tags_json", "[]") or "[]")
            except Exception:
                tags = []
            session_date = row.get("session_date", "") or ""
            matched_side = _matched_turn_side(query, u, a)
            excerpt = _build_turn_excerpt(
                query,
                u,
                a,
                matched_side,
                context_chars=_ctx,
            )
            results.append(QuoteResult(
                text=excerpt,
                tag=primary_tag,
                segment_ref=f"turn_{turn}",
                tags=list(tags or []),
                match_type="full_text_search",
                session_date=session_date,
                source_scope="turn",
                turn_number=turn,
                matched_side=matched_side,
                created_at=row.get("created_at", "") or "",
            ))
        return results

    def store_chunk_embeddings(self, segment_ref: str, chunks: list[ChunkEmbedding]) -> None:
        conn = self._get_conn()
        with conn.transaction():
            conn.execute("DELETE FROM segment_chunks WHERE segment_ref = %s", (segment_ref,))
            for chunk in chunks:
                conn.execute(
                    "INSERT INTO segment_chunks (segment_ref, chunk_index, text, embedding_json) VALUES (%s,%s,%s,%s)",
                    (segment_ref, chunk.chunk_index, chunk.text, json.dumps(chunk.embedding)),
                )

    def get_all_chunk_embeddings(self) -> list[ChunkEmbedding]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT segment_ref, chunk_index, text, embedding_json FROM segment_chunks ORDER BY segment_ref, chunk_index"
        ).fetchall()
        return [
            ChunkEmbedding(
                segment_ref=row["segment_ref"], chunk_index=row["chunk_index"],
                text=row["text"], embedding=json.loads(row["embedding_json"]),
            )
            for row in rows
        ]

    def store_full_text_chunk_embeddings(
        self,
        conversation_id: str,
        turn_number: int,
        side: str,
        chunks: list[FullTextChunkEmbedding],
    ) -> None:
        conn = self._get_conn()
        with conn.transaction():
            conn.execute(
                "DELETE FROM full_text_chunks WHERE conversation_id = %s AND turn_number = %s AND side = %s",
                (conversation_id, turn_number, side),
            )
            for chunk in chunks:
                conn.execute(
                    """INSERT INTO full_text_chunks
                    (conversation_id, turn_number, side, chunk_index, text, embedding_json)
                    VALUES (%s,%s,%s,%s,%s,%s)""",
                    (
                        chunk.conversation_id,
                        chunk.turn_number,
                        chunk.side,
                        chunk.chunk_index,
                        chunk.text,
                        json.dumps(chunk.embedding),
                    ),
                )

    def get_all_full_text_chunk_embeddings(
        self,
        conversation_id: str | None = None,
    ) -> list[FullTextChunkEmbedding]:
        conn = self._get_conn()
        if conversation_id is None:
            rows = conn.execute(
                """SELECT conversation_id, turn_number, side, chunk_index, text, embedding_json
                FROM full_text_chunks
                ORDER BY conversation_id, turn_number, side, chunk_index"""
            ).fetchall()
        else:
            rows = conn.execute(
                """SELECT conversation_id, turn_number, side, chunk_index, text, embedding_json
                FROM full_text_chunks
                WHERE conversation_id = %s
                ORDER BY turn_number, side, chunk_index""",
                (conversation_id,),
            ).fetchall()
        return [
            FullTextChunkEmbedding(
                conversation_id=row["conversation_id"],
                turn_number=row["turn_number"],
                side=row["side"],
                chunk_index=row["chunk_index"],
                text=row["text"],
                embedding=json.loads(row["embedding_json"]),
            )
            for row in rows
        ]

    def delete_full_text_chunk_embeddings(
        self,
        conversation_id: str,
        turn_number: int | None = None,
    ) -> int:
        conn = self._get_conn()
        if turn_number is None:
            cur = conn.execute(
                "DELETE FROM full_text_chunks WHERE conversation_id = %s",
                (conversation_id,),
            )
        else:
            cur = conn.execute(
                "DELETE FROM full_text_chunks WHERE conversation_id = %s AND turn_number = %s",
                (conversation_id, turn_number),
            )
        return int(cur.rowcount or 0)

    def store_tool_output(self, ref: str, conversation_id: str, tool_name: str, command: str, turn: int, content: str, original_bytes: int) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tool_outputs (ref, conversation_id, tool_name, command, turn, content, original_bytes, created_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (ref) DO UPDATE SET content=EXCLUDED.content, original_bytes=EXCLUDED.original_bytes""",
            (ref, conversation_id, tool_name, command, turn, content, original_bytes, _dt_to_str(datetime.now(timezone.utc))),
        )

    def search_tool_outputs(self, query: str, limit: int = 5, conversation_id: str | None = None) -> list:
        conn = self._get_conn()
        tsquery = " & ".join(query.split())
        try:
            sql = """SELECT t.ref, t.tool_name,
                    ts_headline('english', t.content, to_tsquery('english', %s),
                                'StartSel=>>>, StopSel=<<<, MaxFragments=1, MaxWords=20') as excerpt
                FROM tool_outputs t
                WHERE t.content_tsv @@ to_tsquery('english', %s)"""
            params: list = [tsquery, tsquery]
            if conversation_id is not None:
                sql += " AND t.conversation_id = %s"
                params.append(conversation_id)
            sql += """
                ORDER BY ts_rank(t.content_tsv, to_tsquery('english', %s)) DESC
                LIMIT %s"""
            params.extend([tsquery, limit])
            rows = conn.execute(sql, params).fetchall()
        except Exception:
            return []
        return [
            QuoteResult(
                text=row["excerpt"],
                tag=row["tool_name"],
                segment_ref=row["ref"],
                session_date="",
                match_type="tool_output",
                source_scope="tool_output",
            )
            for row in rows
        ]

    # ------------------------------------------------------------------
    # Turn / Segment ↔ Tool Output linkage
    # ------------------------------------------------------------------

    def link_turn_tool_output(self, conversation_id: str, turn_number: int, tool_output_ref: str) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO turn_tool_outputs (conversation_id, turn_number, tool_output_ref)
            VALUES (%s, %s, %s)
            ON CONFLICT DO NOTHING""",
            (conversation_id, turn_number, tool_output_ref),
        )

    def get_tool_outputs_for_turn(self, conversation_id: str, turn_number: int) -> list[str]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT tool_output_ref FROM turn_tool_outputs WHERE conversation_id = %s AND turn_number = %s",
            (conversation_id, turn_number),
        ).fetchall()
        return [row["tool_output_ref"] for row in rows]

    def link_segment_tool_output(self, conversation_id: str, segment_ref: str, tool_output_ref: str) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO segment_tool_outputs (conversation_id, segment_ref, tool_output_ref)
            VALUES (%s, %s, %s)
            ON CONFLICT DO NOTHING""",
            (conversation_id, segment_ref, tool_output_ref),
        )

    def get_tool_outputs_for_segment(self, conversation_id: str, segment_ref: str) -> list[str]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT tool_output_ref FROM segment_tool_outputs WHERE conversation_id = %s AND segment_ref = %s",
            (conversation_id, segment_ref),
        ).fetchall()
        return [row["tool_output_ref"] for row in rows]

    def get_tool_output_refs_for_turn(self, conversation_id: str, turn: int) -> list[str]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT ref FROM tool_outputs WHERE conversation_id = %s AND turn = %s",
            (conversation_id, turn),
        ).fetchall()
        return [row["ref"] for row in rows]

    def get_tool_output_by_ref(self, conversation_id: str, ref: str) -> str | None:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT content FROM tool_outputs WHERE conversation_id = %s AND ref = %s",
            (conversation_id, ref),
        ).fetchone()
        return row["content"] if row else None

    # ------------------------------------------------------------------
    # Media Output Storage
    # ------------------------------------------------------------------

    def store_media_output(
        self,
        ref: str,
        conversation_id: str,
        media_type: str,
        width: int,
        height: int,
        original_bytes: int,
        compressed_bytes: int,
        file_path: str,
    ) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO media_outputs (ref, conversation_id, media_type, width, height, original_bytes, compressed_bytes, file_path, created_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (conversation_id, ref) DO UPDATE SET
                media_type=EXCLUDED.media_type, width=EXCLUDED.width, height=EXCLUDED.height,
                original_bytes=EXCLUDED.original_bytes, compressed_bytes=EXCLUDED.compressed_bytes,
                file_path=EXCLUDED.file_path""",
            (ref, conversation_id, media_type, width, height, original_bytes, compressed_bytes, file_path, _dt_to_str(datetime.now(timezone.utc))),
        )

    def get_media_output(self, conversation_id: str, ref: str) -> dict | None:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT ref, conversation_id, media_type, width, height, original_bytes, compressed_bytes, file_path FROM media_outputs WHERE conversation_id = %s AND ref = %s",
            (conversation_id, ref),
        ).fetchone()
        if not row:
            return None
        return {
            "ref": row["ref"],
            "conversation_id": row["conversation_id"],
            "media_type": row["media_type"],
            "width": row["width"],
            "height": row["height"],
            "original_bytes": row["original_bytes"],
            "compressed_bytes": row["compressed_bytes"],
            "file_path": row["file_path"],
        }

    # ------------------------------------------------------------------
    # Chain Snapshots (turn chain collapse)
    # ------------------------------------------------------------------

    def store_chain_snapshot(
        self,
        ref: str,
        conversation_id: str,
        turn_number: int,
        chain_json: str,
        message_count: int,
        tool_output_refs: str = "",
    ) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO chain_snapshots
            (ref, conversation_id, turn_number, chain_json, message_count, tool_output_refs, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (ref) DO UPDATE SET
                chain_json=EXCLUDED.chain_json, message_count=EXCLUDED.message_count,
                tool_output_refs=EXCLUDED.tool_output_refs""",
            (ref, conversation_id, turn_number, chain_json, message_count, tool_output_refs,
             _dt_to_str(datetime.now(timezone.utc))),
        )

    def get_chain_snapshot(self, conversation_id: str, ref: str) -> dict | None:
        conn = self._get_conn()
        row = conn.execute(
            """SELECT ref, conversation_id, turn_number, chain_json, message_count, tool_output_refs
            FROM chain_snapshots WHERE conversation_id = %s AND ref = %s""",
            (conversation_id, ref),
        ).fetchone()
        if not row:
            return None
        return {
            "ref": row["ref"],
            "conversation_id": row["conversation_id"],
            "turn_number": row["turn_number"],
            "chain_json": row["chain_json"],
            "message_count": row["message_count"],
            "tool_output_refs": row["tool_output_refs"],
        }

    def get_chain_snapshots_for_conversation(self, conversation_id: str, min_turn: int = 0) -> list[dict]:
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT ref, turn_number, tool_output_refs, message_count
            FROM chain_snapshots WHERE conversation_id = %s AND turn_number >= %s
            ORDER BY turn_number""",
            (conversation_id, min_turn),
        ).fetchall()
        return [{"ref": r["ref"], "turn_number": r["turn_number"],
                 "tool_output_refs": r["tool_output_refs"], "message_count": r["message_count"]} for r in rows]

    def get_chain_recovery_manifest(self, conversation_id: str, min_turn: int = 0) -> list[dict]:
        conn = self._get_conn()
        rows = conn.execute(
            """
            SELECT
                s.ref,
                s.turn_number,
                s.tool_output_refs,
                s.message_count,
                COALESCE(
                    STRING_AGG(DISTINCT t.tool_name, ', ' ORDER BY t.tool_name)
                        FILTER (WHERE t.tool_name != ''),
                    ''
                ) AS tool_names
            FROM chain_snapshots s
            LEFT JOIN tool_outputs t
                ON t.ref = ANY(string_to_array(NULLIF(s.tool_output_refs, ''), ','))
            WHERE s.conversation_id = %s
              AND s.turn_number >= %s
            GROUP BY s.ref, s.turn_number, s.tool_output_refs, s.message_count
            ORDER BY s.turn_number
            """,
            (conversation_id, min_turn),
        ).fetchall()
        return [
            {
                "ref": row["ref"],
                "turn_number": row["turn_number"],
                "tool_output_refs": row["tool_output_refs"],
                "message_count": row["message_count"],
                "tool_names": row["tool_names"] or "",
            }
            for row in rows
        ]

    def get_tool_names_for_refs(self, refs: list[str]) -> list[str]:
        if not refs:
            return []
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT DISTINCT tool_name FROM tool_outputs WHERE ref = ANY(%s) AND tool_name != ''",
            (refs,),
        ).fetchall()
        return [row["tool_name"] for row in rows]

    def get_tool_names_for_segment(self, conversation_id: str, segment_ref: str) -> list[str]:
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT DISTINCT t.tool_name
            FROM segment_tool_outputs s
            JOIN tool_outputs t ON t.ref = s.tool_output_ref AND t.conversation_id = s.conversation_id
            WHERE s.conversation_id = %s AND s.segment_ref = %s
            ORDER BY t.tool_name""",
            (conversation_id, segment_ref),
        ).fetchall()
        return [row["tool_name"] for row in rows]

    def save_request_capture(self, capture: dict) -> None:
        conn = self._get_conn()
        import time as _time
        conversation_id = capture.get("conversation_id", "") or ""
        turn_id = capture.get("turn_id", "") or ""
        conn.execute(
            """INSERT INTO request_captures
            (conversation_id, turn, turn_id, ts, recorded_at, data_json)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (conversation_id, turn, turn_id) DO UPDATE SET
                ts=EXCLUDED.ts,
                recorded_at=EXCLUDED.recorded_at,
                data_json=EXCLUDED.data_json""",
            (
                conversation_id,
                capture["turn"],
                turn_id,
                capture.get("ts", ""),
                _time.time(),
                json.dumps(capture),
            ),
        )
        conn.execute(
            """DELETE FROM request_captures
            WHERE conversation_id = %s
              AND (conversation_id, turn, turn_id) NOT IN (
                SELECT conversation_id, turn, turn_id
                FROM request_captures
                WHERE conversation_id = %s
                ORDER BY recorded_at DESC LIMIT 50
            )""",
            (conversation_id, conversation_id),
        )

    def load_request_captures(
        self,
        limit: int = 50,
        conversation_id: str | None = None,
    ) -> list[dict]:
        conn = self._get_conn()
        try:
            if conversation_id is None:
                rows = conn.execute(
                    "SELECT data_json FROM request_captures ORDER BY recorded_at ASC LIMIT %s",
                    (limit,),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT data_json FROM request_captures
                    WHERE conversation_id = %s
                    ORDER BY recorded_at ASC LIMIT %s""",
                    (conversation_id, limit),
                ).fetchall()
        except Exception:
            return []
        result = []
        for row in rows:
            try:
                result.append(json.loads(row["data_json"]))
            except (json.JSONDecodeError, TypeError, KeyError):
                pass
        return result

    # ------------------------------------------------------------------
    # StateStore
    # ------------------------------------------------------------------

    def save_engine_state(self, state: EngineStateSnapshot) -> None:
        conn = self._get_conn()
        entries_data = {
            "entries": [
                {
                    "turn_number": e.turn_number,
                    "tags": e.tags,
                    "primary_tag": e.primary_tag,
                    "message_hash": e.message_hash,
                    "sender": e.sender,
                    "fact_signals": [
                        {"subject": fs.subject, "verb": fs.verb, "object": fs.object,
                         "status": fs.status, "fact_type": fs.fact_type, "what": fs.what}
                        for fs in (e.fact_signals or [])
                    ] if e.fact_signals else [],
                    "code_refs": list(getattr(e, "code_refs", []) or []),
                }
                for e in state.turn_tag_entries
            ],
            "split_processed_tags": list(state.split_processed_tags) if state.split_processed_tags else [],
            "working_set": [
                {
                    "tag": ws.tag,
                    "depth": ws.depth.value if hasattr(ws.depth, 'value') else ws.depth,
                    "tokens": ws.tokens,
                    "last_accessed_turn": ws.last_accessed_turn,
                }
                for ws in (state.working_set or [])
            ],
            "trailing_fingerprint": state.trailing_fingerprint or "",
            "request_captures": state.request_captures,
            "provider": state.provider,
            "flushed_through": state.flushed_through,
            "last_request_time": state.last_request_time,
            "tool_tag_counter": state.tool_tag_counter,
            "last_compacted_turn": state.last_compacted_turn,
            "last_completed_turn": state.last_completed_turn,
            "last_indexed_turn": state.last_indexed_turn,
            "checkpoint_version": state.checkpoint_version,
        }
        conn.execute(
            """INSERT INTO engine_state (conversation_id, compacted_through, turn_count, turn_tag_entries, saved_at, flushed_through, last_request_time)
            VALUES (%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (conversation_id) DO UPDATE SET
                compacted_through=EXCLUDED.compacted_through, turn_count=EXCLUDED.turn_count,
                turn_tag_entries=EXCLUDED.turn_tag_entries, saved_at=EXCLUDED.saved_at,
                flushed_through=EXCLUDED.flushed_through, last_request_time=EXCLUDED.last_request_time""",
            (state.conversation_id, state.compacted_through, state.turn_count,
             json.dumps(entries_data), _dt_to_str(state.saved_at),
             state.flushed_through, state.last_request_time),
        )

    def _parse_engine_state_row(self, row: dict) -> EngineStateSnapshot:
        raw = json.loads(row["turn_tag_entries"])
        if isinstance(raw, list):
            entries_list = raw
            split_tags: set[str] = set()
            working_set: dict = {}
            fingerprint = ""
            request_captures = []
            provider = ""
            flushed_through = row.get("flushed_through") or 0
            flushed_through_present = bool(row.get("flushed_through"))
            last_request_time = row.get("last_request_time") or 0.0
            tool_tag_counter = 0
            last_compacted_turn = (row["compacted_through"] // 2) - 1 if row["compacted_through"] > 0 else -1
            last_completed_turn = max(row["turn_count"] - 1, len(entries_list) - 1)
            last_indexed_turn = len(entries_list) - 1
            checkpoint_version = 0
        elif isinstance(raw, dict):
            entries_list = raw.get("entries", raw.get("turn_tag_entries", []))
            split_tags = set(raw.get("split_processed_tags", []))
            ws_raw = raw.get("working_set", [])
            if isinstance(ws_raw, dict):
                # Legacy format: convert dict to list
                working_set = [
                    WorkingSetEntry(
                        tag=tag,
                        depth=DepthLevel(ws["depth"]),
                        tokens=ws.get("tokens", 0),
                        last_accessed_turn=ws.get("last_accessed_turn", 0),
                    )
                    for tag, ws in ws_raw.items()
                ]
            else:
                working_set = [
                    WorkingSetEntry(
                        tag=ws["tag"],
                        depth=DepthLevel(ws["depth"]),
                        tokens=ws.get("tokens", 0),
                        last_accessed_turn=ws.get("last_accessed_turn", 0),
                    )
                    for ws in ws_raw
                ]
            fingerprint = raw.get("trailing_fingerprint", "")
            request_captures = raw.get("request_captures", [])
            provider = raw.get("provider", "")
            flushed_through = raw.get("flushed_through", 0)
            flushed_through_present = "flushed_through" in raw
            last_request_time = raw.get("last_request_time", 0.0)
            tool_tag_counter = raw.get("tool_tag_counter", 0)
            last_compacted_turn = raw.get(
                "last_compacted_turn",
                (row["compacted_through"] // 2) - 1 if row["compacted_through"] > 0 else -1,
            )
            last_completed_turn = raw.get(
                "last_completed_turn",
                max(row["turn_count"] - 1, len(entries_list) - 1),
            )
            last_indexed_turn = raw.get("last_indexed_turn", len(entries_list) - 1)
            checkpoint_version = raw.get("checkpoint_version", 0)
        else:
            entries_list = []
            split_tags = set()
            working_set = {}
            fingerprint = ""
            request_captures = []
            provider = ""
            flushed_through = row.get("flushed_through") or 0
            flushed_through_present = bool(row.get("flushed_through"))
            last_request_time = row.get("last_request_time") or 0.0
            tool_tag_counter = 0
            last_compacted_turn = (row["compacted_through"] // 2) - 1 if row["compacted_through"] > 0 else -1
            last_completed_turn = row["turn_count"] - 1
            last_indexed_turn = -1
            checkpoint_version = 0

        entries = []
        for e in entries_list:
            signals = []
            for fs in e.get("fact_signals", []):
                signals.append(FactSignal(
                    subject=fs.get("subject", ""), verb=fs.get("verb", ""),
                    object=fs.get("object", ""), status=fs.get("status", ""),
                    fact_type=fs.get("fact_type", "personal"), what=fs.get("what", ""),
                ))
            entries.append(TurnTagEntry(
                turn_number=e["turn_number"], tags=e["tags"],
                primary_tag=e.get("primary_tag", e["tags"][0] if e["tags"] else "_general"),
                message_hash=e.get("message_hash", ""),
                fact_signals=signals if signals else None,
                code_refs=e.get("code_refs", []) or [],
                sender=e.get("sender", ""),
            ))

        return EngineStateSnapshot(
            conversation_id=row["conversation_id"],
            compacted_through=row["compacted_through"],
            flushed_through=flushed_through,
            flushed_through_present=flushed_through_present,
            last_request_time=last_request_time,
            turn_count=row["turn_count"],
            turn_tag_entries=entries,
            last_compacted_turn=last_compacted_turn,
            last_completed_turn=last_completed_turn,
            last_indexed_turn=last_indexed_turn,
            checkpoint_version=checkpoint_version,
            conversation_generation=self.get_conversation_generation(row["conversation_id"]),
            split_processed_tags=split_tags,
            working_set=working_set,
            trailing_fingerprint=fingerprint,
            request_captures=request_captures,
            provider=provider,
            tool_tag_counter=tool_tag_counter,
        )

    def load_engine_state(self, conversation_id: str) -> EngineStateSnapshot | None:
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM engine_state WHERE conversation_id = %s", (conversation_id,)).fetchone()
        if not row:
            return None
        return self._parse_engine_state_row(row)

    def load_latest_engine_state(self) -> EngineStateSnapshot | None:
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM engine_state ORDER BY compacted_through DESC, saved_at DESC LIMIT 1").fetchone()
        if not row:
            return None
        return self._parse_engine_state_row(row)

    def list_engine_state_fingerprints(self) -> dict[str, str]:
        conn = self._get_conn()
        rows = conn.execute("SELECT conversation_id, turn_tag_entries FROM engine_state").fetchall()
        result: dict[str, str] = {}
        for row in rows:
            raw = json.loads(row["turn_tag_entries"])
            fp = raw.get("trailing_fingerprint", "") if isinstance(raw, dict) else ""
            if fp:
                result[fp] = row["conversation_id"]
        return result

    # ------------------------------------------------------------------
    # Turn messages
    # ------------------------------------------------------------------

    def save_turn_message(
        self,
        conversation_id: str,
        turn_number: int,
        user_content: str,
        assistant_content: str,
        user_raw_content: str | None = None,
        assistant_raw_content: str | None = None,
    ) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO turn_messages
            (conversation_id, turn_number, user_content, assistant_content,
             user_raw_content, assistant_raw_content)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (conversation_id, turn_number) DO UPDATE SET
                user_content=EXCLUDED.user_content,
                assistant_content=EXCLUDED.assistant_content,
                user_raw_content=EXCLUDED.user_raw_content,
                assistant_raw_content=EXCLUDED.assistant_raw_content""",
            (conversation_id, turn_number, user_content, assistant_content,
             user_raw_content, assistant_raw_content),
        )

    def search_turn_messages(
        self,
        query: str,
        limit: int = 5,
        conversation_id: str | None = None,
    ) -> list["QuoteResult"]:
        """Search raw turn_messages with tsvector search and turn-backed excerpts."""
        conn = self._get_conn()
        rows = []
        try:
            sql = """SELECT turn_number, user_content, assistant_content
                     FROM turn_messages
                     WHERE turn_tsv @@ plainto_tsquery('english', %s)"""
            params: list[object] = [query]
            if conversation_id is not None:
                sql += " AND conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY ts_rank(turn_tsv, plainto_tsquery('english', %s)) DESC, turn_number DESC LIMIT %s"
            params.extend([query, limit])
            rows = conn.execute(sql, params).fetchall()
        except Exception:
            pattern = f"%{query}%"
            sql = """SELECT turn_number, user_content, assistant_content
                     FROM turn_messages
                     WHERE (user_content ILIKE %s OR assistant_content ILIKE %s)"""
            params = [pattern, pattern]
            if conversation_id is not None:
                sql += " AND conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY turn_number DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
        results = []
        _sc = getattr(self, "search_config", None)
        _ctx = _sc.excerpt_context_chars if _sc else 200
        for row in rows:
            turn = row["turn_number"]
            u = row["user_content"] or ""
            a = row["assistant_content"] or ""
            matched_side = _matched_turn_side(query, u, a)
            excerpt = _build_turn_excerpt(
                query,
                u,
                a,
                matched_side,
                context_chars=_ctx,
            )
            results.append(QuoteResult(
                text=excerpt,
                tag="uncompacted",
                segment_ref=f"turn_{turn}",
                match_type="turn_search",
                source_scope="turn",
                turn_number=turn,
                matched_side=matched_side,
            ))
        return results

    def save_conversation_alias(self, alias_id: str, target_id: str) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO conversation_aliases (alias_id, target_id)
            VALUES (%s, %s)
            ON CONFLICT (alias_id) DO UPDATE SET target_id = EXCLUDED.target_id""",
            (alias_id, target_id),
        )

    def resolve_conversation_alias(self, alias_id: str) -> str | None:
        conn = self._get_conn()
        row = conn.execute(
            "SELECT target_id FROM conversation_aliases WHERE alias_id = %s",
            (alias_id,),
        ).fetchone()
        return row["target_id"] if row else None

    def get_turn_messages(
        self,
        conversation_id: str,
        turn_numbers: list[int],
    ) -> dict[int, tuple[str, str, str | None, str | None]]:
        if not turn_numbers:
            return {}
        conn = self._get_conn()
        placeholders = ",".join("%s" for _ in turn_numbers)
        rows = conn.execute(
            f"""SELECT turn_number, user_content, assistant_content,
                       user_raw_content, assistant_raw_content
            FROM turn_messages
            WHERE conversation_id = %s AND turn_number IN ({placeholders})""",
            [conversation_id] + turn_numbers,
        ).fetchall()
        return {
            row["turn_number"]: (
                row["user_content"],
                row["assistant_content"],
                row["user_raw_content"],
                row["assistant_raw_content"],
            )
            for row in rows
        }

    def load_recent_turn_messages(
        self,
        conversation_id: str,
        limit: int = 100,
    ) -> list[tuple[int, str, str]]:
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT turn_number, user_content, assistant_content
            FROM turn_messages
            WHERE conversation_id = %s
            ORDER BY turn_number DESC
            LIMIT %s""",
            (conversation_id, limit),
        ).fetchall()
        return [(r["turn_number"], r["user_content"], r["assistant_content"]) for r in reversed(rows)]

    def prune_turn_messages(self, conversation_id: str, keep_from_turn: int) -> int:
        conn = self._get_conn()
        cur = conn.execute(
            """DELETE FROM turn_messages
            WHERE conversation_id = %s AND turn_number < %s""",
            (conversation_id, keep_from_turn),
        )
        return int(cur.rowcount or 0)

    def save_full_text(
        self,
        conversation_id: str,
        turn_number: int,
        user_content: str,
        assistant_content: str,
        user_raw_content: str | None = None,
        assistant_raw_content: str | None = None,
        primary_tag: str = "_general",
        tags: list[str] | None = None,
        session_date: str = "",
        sender: str = "",
        fact_signals: list[FactSignal] | None = None,
        code_refs: list[dict] | None = None,
        created_at: str | None = None,
        updated_at: str | None = None,
    ) -> None:
        now = _dt_to_str(datetime.now(timezone.utc))
        created = created_at or now
        updated = updated_at or now
        fact_signal_payload = [
            {
                "subject": fs.subject,
                "verb": fs.verb,
                "object": fs.object,
                "status": fs.status,
                "fact_type": getattr(fs, "fact_type", ""),
                "what": getattr(fs, "what", ""),
            }
            for fs in (fact_signals or [])
        ]
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO full_text
            (conversation_id, turn_number, user_content, assistant_content,
             user_raw_content, assistant_raw_content, primary_tag, tags_json,
             session_date, sender, fact_signals_json, code_refs_json, created_at, updated_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (conversation_id, turn_number) DO UPDATE SET
                user_content=EXCLUDED.user_content,
                assistant_content=EXCLUDED.assistant_content,
                user_raw_content=EXCLUDED.user_raw_content,
                assistant_raw_content=EXCLUDED.assistant_raw_content,
                primary_tag=EXCLUDED.primary_tag,
                tags_json=EXCLUDED.tags_json,
                session_date=EXCLUDED.session_date,
                sender=EXCLUDED.sender,
                fact_signals_json=EXCLUDED.fact_signals_json,
                code_refs_json=EXCLUDED.code_refs_json,
                updated_at=EXCLUDED.updated_at""",
            (
                conversation_id,
                turn_number,
                user_content,
                assistant_content,
                user_raw_content,
                assistant_raw_content,
                primary_tag or "_general",
                json.dumps(list(tags or [])),
                session_date or "",
                sender or "",
                json.dumps(fact_signal_payload),
                json.dumps(list(code_refs or [])),
                created,
                updated,
            ),
        )

    def get_full_text_rows(
        self,
        conversation_id: str,
        turn_numbers: list[int],
    ) -> dict[int, FullTextRow]:
        if not turn_numbers:
            return {}
        conn = self._get_conn()
        placeholders = ",".join("%s" for _ in turn_numbers)
        rows = conn.execute(
            f"""SELECT conversation_id, turn_number, user_content, assistant_content,
                       user_raw_content, assistant_raw_content, primary_tag, tags_json,
                       session_date, sender, fact_signals_json, code_refs_json,
                       created_at, updated_at
            FROM full_text
            WHERE conversation_id = %s AND turn_number IN ({placeholders})""",
            [conversation_id] + turn_numbers,
        ).fetchall()
        return {
            row["turn_number"]: _row_to_full_text(row)
            for row in rows
        }

    def get_all_full_text_rows(
        self,
        conversation_id: str,
    ) -> list[FullTextRow]:
        conn = self._get_conn()
        rows = conn.execute(
            """SELECT conversation_id, turn_number, user_content, assistant_content,
                      user_raw_content, assistant_raw_content, primary_tag, tags_json,
                      session_date, sender, fact_signals_json, code_refs_json,
                      created_at, updated_at
               FROM full_text
               WHERE conversation_id = %s
               ORDER BY turn_number""",
            (conversation_id,),
        ).fetchall()
        return [_row_to_full_text(row) for row in rows]

    def delete_full_text_rows(
        self,
        conversation_id: str,
        turn_number: int | None = None,
    ) -> int:
        conn = self._get_conn()
        if turn_number is None:
            cur = conn.execute(
                "DELETE FROM full_text WHERE conversation_id = %s",
                (conversation_id,),
            )
        else:
            cur = conn.execute(
                "DELETE FROM full_text WHERE conversation_id = %s AND turn_number = %s",
                (conversation_id, turn_number),
            )
        return int(cur.rowcount or 0)

    def search_tag_summaries_fts(
        self, query: str, limit: int = 20, conversation_id: str | None = None,
    ) -> list[tuple[str, float]]:
        conn = self._get_conn()
        tsquery = " & ".join(query.split()[:10])
        try:
            sql = """SELECT ts.tag,
                    ts_rank(to_tsvector('english', ts.summary), to_tsquery('english', %s)) as score
                FROM tag_summaries ts
                WHERE to_tsvector('english', ts.summary) @@ to_tsquery('english', %s)"""
            params: list = [tsquery, tsquery]
            if conversation_id is not None:
                sql += " AND ts.conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY score DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
            return [(row["tag"], float(row["score"])) for row in rows]
        except Exception:
            return []

    def store_tag_summary_embedding(
        self, tag: str, conversation_id: str, embedding: list[float],
    ) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tag_summary_embeddings (tag, conversation_id, embedding_json)
            VALUES (%s, %s, %s)
            ON CONFLICT (tag, conversation_id) DO UPDATE SET embedding_json = EXCLUDED.embedding_json""",
            (tag, conversation_id, json.dumps(embedding)),
        )

    def load_tag_summary_embeddings(
        self, conversation_id: str | None = None,
    ) -> dict[str, list[float]]:
        conn = self._get_conn()
        if conversation_id is not None:
            rows = conn.execute(
                "SELECT tag, embedding_json FROM tag_summary_embeddings WHERE conversation_id = %s",
                (conversation_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT tag, embedding_json FROM tag_summary_embeddings").fetchall()
        result = {}
        for row in rows:
            try:
                result[row["tag"]] = json.loads(row["embedding_json"])
            except (json.JSONDecodeError, TypeError):
                pass
        return result

    def get_actionable_fact_tags(
        self, tags: list[str], conversation_id: str | None = None,
    ) -> set[str]:
        if not tags:
            return set()
        conn = self._get_conn()
        placeholders = ",".join("%s" for _ in tags)
        params: list = list(tags)
        conv_clause = ""
        if conversation_id is not None:
            conv_clause = " AND f.conversation_id = %s"
            params.append(conversation_id)
        try:
            rows = conn.execute(
                f"""SELECT DISTINCT ft.tag FROM fact_tags ft
                JOIN facts f ON f.id = ft.fact_id
                WHERE ft.tag IN ({placeholders})
                AND f.superseded_by IS NULL
                AND (f.status IN ('active', 'completed') OR f.fact_type = 'personal'){conv_clause}""",
                params,
            ).fetchall()
            return {row["tag"] for row in rows}
        except Exception:
            return set()

    # ------------------------------------------------------------------
    # FactStore
    # ------------------------------------------------------------------

    def store_facts(self, facts: list[Fact]) -> int:
        if not facts:
            return 0
        conn = self._get_conn()
        count = 0
        with conn.transaction():
            for fact in facts:
                conn.execute(
                    """INSERT INTO facts
                    (id, subject, verb, object, status, what, who, when_date, "where", why,
                     fact_type, tags_json, segment_ref, conversation_id, turn_numbers_json,
                     mentioned_at, session_date, superseded_by)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    ON CONFLICT (id) DO UPDATE SET
                        subject=EXCLUDED.subject, verb=EXCLUDED.verb, object=EXCLUDED.object,
                        status=EXCLUDED.status, what=EXCLUDED.what, who=EXCLUDED.who,
                        when_date=EXCLUDED.when_date, "where"=EXCLUDED."where", why=EXCLUDED.why,
                        fact_type=EXCLUDED.fact_type, tags_json=EXCLUDED.tags_json,
                        segment_ref=EXCLUDED.segment_ref, conversation_id=EXCLUDED.conversation_id,
                        turn_numbers_json=EXCLUDED.turn_numbers_json, mentioned_at=EXCLUDED.mentioned_at,
                        session_date=EXCLUDED.session_date, superseded_by=EXCLUDED.superseded_by""",
                    (fact.id, fact.subject, fact.verb, fact.object, fact.status,
                     fact.what, fact.who, fact.when_date, fact.where, fact.why,
                     fact.fact_type, json.dumps(fact.tags), fact.segment_ref,
                     fact.conversation_id, json.dumps(fact.turn_numbers),
                     _dt_to_str(fact.mentioned_at), fact.session_date, fact.superseded_by),
                )
                conn.execute("DELETE FROM fact_tags WHERE fact_id = %s", (fact.id,))
                for tag in fact.tags:
                    conn.execute("INSERT INTO fact_tags (fact_id, tag) VALUES (%s, %s)", (fact.id, tag))
                count += 1
        return count

    def query_facts(
        self, *, subject: str | None = None, verb: str | None = None,
        verbs: list[str] | None = None, object_contains: str | None = None,
        status: str | None = None, fact_type: str | None = None,
        tags: list[str] | None = None, limit: int = 50,
        conversation_id: str | None = None,
    ) -> list[Fact]:
        conn = self._get_conn()
        conditions: list[str] = []
        params: list = []

        if conversation_id is not None:
            conditions.append("f.conversation_id = %s")
            params.append(conversation_id)
        if subject:
            conditions.append("f.subject = %s")
            params.append(subject)
        if verbs is not None:
            like_clauses = [f"f.verb ILIKE %s" for _ in verbs]
            conditions.append("(" + " OR ".join(like_clauses) + ")")
            params.extend(f"%{_escape_like(v)}%" for v in verbs)
        elif verb is not None:
            conditions.append("f.verb ILIKE %s")
            params.append(f"%{_escape_like(verb)}%")
        if object_contains:
            conditions.append("f.object ILIKE %s")
            params.append(f"%{_escape_like(object_contains)}%")
        if status:
            conditions.append("f.status = %s")
            params.append(status)
        if fact_type:
            conditions.append("f.fact_type = %s")
            params.append(fact_type)
        conditions.append("f.superseded_by IS NULL")

        if tags:
            where = " AND ".join(conditions) if conditions else "TRUE"
            sql = f"""
                SELECT DISTINCT f.* FROM facts f
                JOIN fact_tags ft ON f.id = ft.fact_id
                WHERE ft.tag = ANY(%s) AND {where}
                ORDER BY f.mentioned_at DESC LIMIT %s
            """
            params_list = [tags] + params + [limit]
            rows = conn.execute(sql, params_list).fetchall()
        else:
            where = " AND ".join(conditions) if conditions else "TRUE"
            sql = f"SELECT * FROM facts f WHERE {where} ORDER BY f.mentioned_at DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()

        return [self._row_to_fact(row) for row in rows]

    def get_unique_fact_verbs(self, *, conversation_id: str | None = None) -> list[str]:
        conn = self._get_conn()
        if conversation_id is not None:
            rows = conn.execute(
                "SELECT DISTINCT verb FROM facts WHERE verb != '' AND superseded_by IS NULL AND conversation_id = %s",
                (conversation_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT DISTINCT verb FROM facts WHERE verb != '' AND superseded_by IS NULL").fetchall()
        return [row["verb"] for row in rows]

    def get_facts_by_segment(self, segment_ref: str) -> list[Fact]:
        conn = self._get_conn()
        rows = conn.execute("SELECT * FROM facts WHERE segment_ref = %s ORDER BY mentioned_at", (segment_ref,)).fetchall()
        return [self._row_to_fact(row) for row in rows]

    def replace_facts_for_segment(self, conversation_id: str, segment_ref: str, facts: list) -> tuple[int, int]:
        conn = self._get_conn()
        with conn.transaction():
            result = conn.execute(
                "DELETE FROM facts WHERE conversation_id = %s AND segment_ref = %s",
                (conversation_id, segment_ref),
            )
            deleted = result.rowcount
            inserted = self.store_facts(facts) if facts else 0
        return deleted, inserted

    def search_facts(self, query: str, limit: int = 10, conversation_id: str | None = None) -> list[Fact]:
        conn = self._get_conn()
        tsquery = " & ".join(query.split())
        try:
            sql = """SELECT f.* FROM facts f
                WHERE f.facts_tsv @@ to_tsquery('english', %s) AND f.superseded_by IS NULL"""
            params: list = [tsquery]
            if conversation_id is not None:
                sql += " AND f.conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY ts_rank(f.facts_tsv, to_tsquery('english', %s)) DESC LIMIT %s"
            params.extend([tsquery, limit])
            rows = conn.execute(sql, params).fetchall()
        except Exception:
            like = f"%{query}%"
            sql = """SELECT * FROM facts f
                WHERE (f.subject ILIKE %s OR f.verb ILIKE %s OR f.object ILIKE %s OR f.what ILIKE %s)
                AND f.superseded_by IS NULL"""
            params = [like, like, like, like]
            if conversation_id is not None:
                sql += " AND f.conversation_id = %s"
                params.append(conversation_id)
            sql += " ORDER BY f.mentioned_at DESC LIMIT %s"
            params.append(limit)
            rows = conn.execute(sql, params).fetchall()
        return [self._row_to_fact(row) for row in rows]

    def set_fact_superseded(self, old_fact_id: str, new_fact_id: str) -> None:
        conn = self._get_conn()
        conn.execute("UPDATE facts SET superseded_by = %s WHERE id = %s", (new_fact_id, old_fact_id))

    def update_fact_fields(self, fact_id: str, verb: str, object: str, status: str, what: str) -> None:
        conn = self._get_conn()
        conn.execute(
            "UPDATE facts SET verb = %s, object = %s, status = %s, what = %s WHERE id = %s",
            (verb, object, status, what, fact_id),
        )

    def get_fact_count_by_tags(self, *, conversation_id: str | None = None) -> dict[str, int]:
        conn = self._get_conn()
        if conversation_id is not None:
            rows = conn.execute(
                "SELECT ft.tag, COUNT(*) as cnt FROM fact_tags ft JOIN facts f ON f.id = ft.fact_id WHERE f.conversation_id = %s GROUP BY ft.tag",
                (conversation_id,),
            ).fetchall()
        else:
            rows = conn.execute("SELECT tag, COUNT(*) as cnt FROM fact_tags GROUP BY tag").fetchall()
        return {row["tag"]: row["cnt"] for row in rows}

    def get_superseded_facts(self, fact_ids: list[str]) -> list[dict]:
        if not fact_ids:
            return []
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT superseded_by, subject, verb, object FROM facts WHERE superseded_by = ANY(%s)",
            (fact_ids,),
        ).fetchall()
        return [dict(row) for row in rows]

    def query_experience_facts_by_date(
        self,
        start_date: str,
        end_date: str,
        limit: int = 50,
        conversation_id: str | None = None,
    ) -> list[Fact]:
        conn = self._get_conn()
        sql = """SELECT * FROM facts
                 WHERE when_date >= %s AND when_date <= %s"""
        params: list = [start_date, end_date + "~"]
        if conversation_id:
            sql += " AND conversation_id = %s"
            params.append(conversation_id)
        sql += " ORDER BY when_date ASC LIMIT %s"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
        return [self._row_to_fact(row) for row in rows]

    # ------------------------------------------------------------------
    # FactLinkStore
    # ------------------------------------------------------------------

    def store_fact_links(self, links: list[FactLink]) -> int:
        if not links:
            return 0
        conn = self._get_conn()
        count = 0
        with conn.transaction():
            for link in links:
                conn.execute(
                    """INSERT INTO fact_links (id, source_fact_id, target_fact_id, relation_type,
                       confidence, context, created_at, created_by)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s)
                    ON CONFLICT (id) DO UPDATE SET
                        source_fact_id=EXCLUDED.source_fact_id, target_fact_id=EXCLUDED.target_fact_id,
                        relation_type=EXCLUDED.relation_type, confidence=EXCLUDED.confidence,
                        context=EXCLUDED.context""",
                    (link.id, link.source_fact_id, link.target_fact_id, link.relation_type,
                     link.confidence, link.context, _dt_to_str(link.created_at), link.created_by),
                )
                count += 1
        return count

    def get_fact_links(self, fact_id: str, direction: str = "both") -> list[FactLink]:
        conn = self._get_conn()
        if direction == "outgoing":
            rows = conn.execute("SELECT * FROM fact_links WHERE source_fact_id = %s", (fact_id,)).fetchall()
        elif direction == "incoming":
            rows = conn.execute("SELECT * FROM fact_links WHERE target_fact_id = %s", (fact_id,)).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM fact_links WHERE source_fact_id = %s OR target_fact_id = %s",
                (fact_id, fact_id),
            ).fetchall()
        return [self._row_to_fact_link(row) for row in rows]

    def get_linked_facts(self, fact_ids: list[str], depth: int = 1) -> list[LinkedFact]:
        if not fact_ids:
            return []
        conn = self._get_conn()
        visited = set(fact_ids)
        result: list[LinkedFact] = []
        current_layer = set(fact_ids)

        for _hop in range(depth):
            if not current_layer:
                break
            layer_list = list(current_layer)
            visited_list = list(visited)
            rows = conn.execute(
                """SELECT fl.source_fact_id, fl.target_fact_id, fl.relation_type, fl.confidence, fl.context,
                    f.id AS fact_id, f.subject, f.verb, f.object, f.status, f.what, f.who,
                    f.when_date, f."where", f.why, f.fact_type, f.tags_json, f.segment_ref,
                    f.conversation_id, f.turn_numbers_json, f.mentioned_at, f.session_date, f.superseded_by
                FROM fact_links fl
                JOIN facts f ON (
                    (fl.source_fact_id = ANY(%s) AND f.id = fl.target_fact_id)
                    OR (fl.target_fact_id = ANY(%s) AND f.id = fl.source_fact_id)
                )
                WHERE f.superseded_by IS NULL
                AND f.id != ALL(%s)""",
                (layer_list, layer_list, visited_list),
            ).fetchall()

            next_layer: set[str] = set()
            for row in rows:
                fact = Fact(
                    id=row["fact_id"], subject=row["subject"], verb=row["verb"],
                    object=row["object"], status=row["status"], what=row["what"],
                    who=row["who"], when_date=row["when_date"], where=row["where"],
                    why=row["why"], fact_type=row.get("fact_type", "personal"),
                    tags=json.loads(row["tags_json"]) if row["tags_json"] else [],
                    segment_ref=row["segment_ref"], conversation_id=row["conversation_id"],
                    turn_numbers=json.loads(row["turn_numbers_json"]) if row["turn_numbers_json"] else [],
                    mentioned_at=_str_to_dt(row["mentioned_at"]) if row["mentioned_at"] else datetime.now(timezone.utc),
                    session_date=row.get("session_date", ""), superseded_by=row["superseded_by"],
                )
                src = row["source_fact_id"]
                tgt = row["target_fact_id"]
                linked_from = src if src in current_layer else tgt
                result.append(LinkedFact(
                    fact=fact, linked_from_fact_id=linked_from,
                    relation_type=row["relation_type"], confidence=row["confidence"],
                    link_context=row["context"],
                ))
                visited.add(fact.id)
                next_layer.add(fact.id)
            current_layer = next_layer

        return result

    def delete_fact_links(self, fact_id: str) -> int:
        conn = self._get_conn()
        cur = conn.execute(
            "DELETE FROM fact_links WHERE source_fact_id = %s OR target_fact_id = %s",
            (fact_id, fact_id),
        )
        return cur.rowcount

    def migrate_supersession_to_links(self) -> int:
        conn = self._get_conn()
        rows = conn.execute("SELECT id, superseded_by FROM facts WHERE superseded_by IS NOT NULL").fetchall()
        if not rows:
            return 0
        count = 0
        for row in rows:
            old_id, new_id = row["id"], row["superseded_by"]
            existing = conn.execute(
                "SELECT 1 FROM fact_links WHERE source_fact_id = %s AND target_fact_id = %s AND relation_type = 'supersedes'",
                (new_id, old_id),
            ).fetchone()
            if existing:
                continue
            link = FactLink(source_fact_id=new_id, target_fact_id=old_id, relation_type="supersedes",
                            confidence=1.0, context="Migrated from superseded_by column", created_by="migration")
            conn.execute(
                """INSERT INTO fact_links (id, source_fact_id, target_fact_id, relation_type,
                   confidence, context, created_at, created_by) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                (link.id, link.source_fact_id, link.target_fact_id, link.relation_type,
                 link.confidence, link.context, _dt_to_str(link.created_at), link.created_by),
            )
            count += 1
        return count

    # ------------------------------------------------------------------
    # Tool calls
    # ------------------------------------------------------------------

    def save_tool_call(self, call: dict) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO tool_calls
            (conversation_id, request_turn, round, group_id, tool_name,
             tool_input, tool_result, result_length, duration_ms, found, timestamp)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                call.get("conversation_id", ""),
                call.get("request_turn", 0),
                call.get("round", 1),
                call.get("group_id", ""),
                call.get("tool_name", ""),
                json.dumps(call.get("tool_input", {})),
                call.get("tool_result", ""),
                call.get("result_length", 0),
                call.get("duration_ms", 0),
                call.get("found"),
                call.get("timestamp", ""),
            ),
        )
        conv_id = call.get("conversation_id", "")
        conn.execute(
            """DELETE FROM tool_calls WHERE id NOT IN (
                SELECT id FROM tool_calls WHERE conversation_id = %s
                ORDER BY id DESC LIMIT 50
            ) AND conversation_id = %s""",
            (conv_id, conv_id),
        )

    def load_tool_calls(self, conversation_id: str, limit: int = 50) -> list[dict]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT * FROM tool_calls WHERE conversation_id = %s ORDER BY id DESC LIMIT %s",
            (conversation_id, limit),
        ).fetchall()
        return [dict(row) for row in reversed(rows)]

    def load_tool_call(self, call_id: int) -> dict | None:
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM tool_calls WHERE id = %s", (call_id,)).fetchone()
        return dict(row) if row else None

    # ------------------------------------------------------------------
    # Request context persistence (dashboard recall page)
    # ------------------------------------------------------------------

    def save_request_context(self, context: dict) -> None:
        conn = self._get_conn()
        conn.execute(
            """INSERT INTO request_context
            (conversation_id, request_turn, timestamp, user_message, inbound_tags,
             retrieval_method, candidates_found, candidates_selected,
             segments_injected, facts_injected, facts_count, facts_tags,
             pool_used, pool_budget, total_context_tokens,
             non_virtualizable_floor, tool_call_count)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
            (
                context.get("conversation_id", ""),
                context.get("request_turn", 0),
                context.get("timestamp", ""),
                context.get("user_message", ""),
                json.dumps(context.get("inbound_tags", [])),
                context.get("retrieval_method", ""),
                context.get("candidates_found", 0),
                context.get("candidates_selected", 0),
                json.dumps(context.get("segments_injected", [])),
                json.dumps(context.get("facts_injected", [])),
                context.get("facts_count", 0),
                json.dumps(context.get("facts_tags", [])),
                context.get("pool_used", 0),
                context.get("pool_budget", 0),
                context.get("total_context_tokens", 0),
                context.get("non_virtualizable_floor", 0),
                context.get("tool_call_count", 0),
            ),
        )
        conv_id = context.get("conversation_id", "")
        conn.execute(
            """DELETE FROM request_context WHERE id NOT IN (
                SELECT id FROM request_context WHERE conversation_id = %s
                ORDER BY id DESC LIMIT 50
            ) AND conversation_id = %s""",
            (conv_id, conv_id),
        )

    def load_request_contexts(self, conversation_id: str, limit: int = 50) -> list[dict]:
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT * FROM request_context WHERE conversation_id = %s ORDER BY id DESC LIMIT %s",
            (conversation_id, limit),
        ).fetchall()
        result = []
        for row in reversed(rows):
            d = dict(row)
            for json_field in ("inbound_tags", "segments_injected", "facts_injected", "facts_tags"):
                try:
                    d[json_field] = json.loads(d.get(json_field, "[]"))
                except (json.JSONDecodeError, TypeError):
                    d[json_field] = []
            result.append(d)
        return result

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self) -> None:
        if self._conn and not self._conn.closed:
            self._conn.close()
            self._conn = None

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
