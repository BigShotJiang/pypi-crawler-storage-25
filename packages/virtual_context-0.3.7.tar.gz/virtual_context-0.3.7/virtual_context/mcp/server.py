"""MCP server exposing virtual-context as tools, resources, and prompts."""

from __future__ import annotations

import json
import logging
import os

from mcp.server.fastmcp import FastMCP

logger = logging.getLogger(__name__)

mcp = FastMCP(
    "virtual-context",
    instructions="Domain-aware virtual memory for persistent context across long conversations",
)

# Lazy engine singleton
_engine = None


def _get_engine():
    global _engine
    if _engine is None:
        from ..engine import VirtualContextEngine
        config_path = os.environ.get("VIRTUAL_CONTEXT_CONFIG")
        _engine = VirtualContextEngine(config_path=config_path)
    return _engine


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def recall_context(
    message: str,
    active_tags: list[str] | None = None,
) -> str:
    """Retrieve relevant context summaries for an inbound message.

    Tags the message, fetches matching stored summaries by tag overlap,
    and returns the assembled context block ready to prepend to a prompt.

    Args:
        message: The user message to find relevant context for.
        active_tags: Tags already present in recent conversation (will be skipped).

    Returns:
        The assembled virtual-context block as XML, or empty string if no relevant context.
    """
    engine = _get_engine()
    return engine.transform(message, active_tags=active_tags)


@mcp.tool()
def compact_context(
    messages: list[dict],
) -> str:
    """Compact a conversation into stored domain summaries.

    Takes conversation messages, segments them by topic, summarizes each
    segment via LLM, and stores the summaries for future retrieval.

    Args:
        messages: List of message dicts with 'role' and 'content' keys.

    Returns:
        JSON summary of compaction results.
    """
    from ..types import Message
    engine = _get_engine()

    parsed = [
        Message(role=m.get("role", "user"), content=m.get("content", ""))
        for m in messages
    ]

    report = engine.compact_manual(parsed)
    if report is None:
        return json.dumps({"status": "no_compaction", "reason": "No content to compact or no LLM provider"})

    return json.dumps({
        "status": "compacted",
        "segments_compacted": report.segments_compacted,
        "tokens_freed": report.tokens_freed,
        "tags": report.tags,
    })


@mcp.tool()
def expand_topic(
    tag: str, depth: str = "full", collapse_tags: list[str] | None = None,
) -> str:
    """Zoom into a topic you can already see in the context-topics list.

    Use when a topic summary mentions the area you need but lacks detail.
    Requires knowing which tag to expand. For specific facts when you
    don't know which topic holds them, use find_quote instead.

    Args:
        tag: The topic tag to expand (from the context-topics list).
        depth: Target depth level: "segments" (individual summaries) or "full" (original text).
        collapse_tags: Optional list of topic tags to collapse back to summary
            depth before expanding. Frees context budget in the same call.

    Returns:
        JSON with expansion result including tokens added and any evicted topics.
    """
    engine = _get_engine()

    # Collapse specified tags first to free budget
    collapse_results = []
    for ctag in collapse_tags or []:
        cr = engine.collapse_topic(tag=ctag, depth="summary")
        if cr.get("tokens_freed", 0) > 0:
            collapse_results.append(cr)

    result = engine.expand_topic(tag, depth)

    if collapse_results:
        result["collapsed"] = collapse_results
        result["total_tokens_freed"] = sum(
            cr.get("tokens_freed", 0) for cr in collapse_results
        )

    return json.dumps(result)


@mcp.tool()
def recall_all() -> str:
    """Load summaries of all stored conversation topics at once.

    Use when the user asks for a broad overview or wants to know
    everything discussed. Returns all tag summaries within token budget.
    """
    engine = _get_engine()
    result = engine.recall_all()
    return json.dumps(result)


@mcp.tool()
def remember_when(query: str, time_range: dict, max_results: int = 12, mode: str = "auto") -> str:
    """Find memory by topic within a time window.

    Prefer relative presets in ``time_range``; the backend resolves exact dates.
    """
    engine = _get_engine()
    result = engine.remember_when(
        query=query,
        time_range=time_range,
        max_results=max_results,
        mode=mode,
    )
    return json.dumps(result)


@mcp.tool()
def find_quote(query: str, mode: str = "lookup") -> str:
    """Find direct quote-like evidence from raw conversation turns.

    Use this when you need the literal place something was said: names,
    numbers, dates, versions, recommendations, or short factual details.
    This tool is turn-first and returns raw turn excerpts before falling back
    to older segment-backed evidence.

    Args:
        query: Word or phrase to search for. Use distinctive terms, e.g.
            'magnesium glycinate' not 'supplement'.
        mode: Retrieval mode. Use 'lookup' for normal quote search. Use
            'exact_value' only when one excerpt should contain the answer
            verbatim as an explicit number/version/date/count.
    Returns:
        JSON with matching excerpts and quote provenance.
    """
    engine = _get_engine()
    # Keep MCP behavior aligned with proxy tool loop: always return top 20.
    result = engine.find_quote(query, max_results=20, mode=mode)
    return json.dumps(result)


@mcp.tool()
def search_summaries(query: str, mode: str = "lookup") -> str:
    """Search summaries, segment text, and related stored context.

    Use this when you need broader topic recall rather than one literal quote,
    especially for cross-topic aggregation or coverage questions.
    """
    engine = _get_engine()
    result = engine.search_summaries(query, max_results=20, mode=mode)
    return json.dumps(result)


@mcp.tool()
def domain_status() -> str:
    """Show statistics for all stored tags/domains.

    Returns tag names, usage counts, and token totals.

    Returns:
        JSON array of tag statistics.
    """
    engine = _get_engine()
    tags = engine._store.get_all_tags()
    return json.dumps([
        {
            "tag": t.tag,
            "usage_count": t.usage_count,
            "total_full_tokens": t.total_full_tokens,
            "total_summary_tokens": t.total_summary_tokens,
            "oldest_segment": t.oldest_segment.isoformat() if t.oldest_segment else None,
            "newest_segment": t.newest_segment.isoformat() if t.newest_segment else None,
        }
        for t in tags
    ], indent=2)


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

@mcp.resource("virtualcontext://domains")
def list_domains() -> str:
    """List all stored tags/domains with their statistics."""
    engine = _get_engine()
    tags = engine._store.get_all_tags()
    lines = []
    for t in tags:
        lines.append(f"- **{t.tag}**: {t.usage_count} segments, {t.total_summary_tokens} summary tokens")
    return "\n".join(lines) if lines else "No domains stored yet."


@mcp.resource("virtualcontext://domains/{tag}")
def get_domain_summaries(tag: str) -> str:
    """Get all stored summaries for a specific tag/domain."""
    engine = _get_engine()
    summaries = engine._store.get_summaries_by_tags(tags=[tag], min_overlap=1, limit=50)
    if not summaries:
        return f"No summaries found for tag: {tag}"

    parts = []
    for s in summaries:
        parts.append(
            f"## {s.ref}\n"
            f"Tags: {', '.join(s.tags)}\n"
            f"Tokens: {s.summary_tokens}\n"
            f"Created: {s.created_at.isoformat()}\n\n"
            f"{s.summary}"
        )
    return "\n\n---\n\n".join(parts)


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

@mcp.prompt()
def recall(topic: str) -> str:
    """Recall stored context about a specific topic.

    Use this when you want to retrieve everything the system knows about a topic.

    Args:
        topic: The topic to recall context about.
    """
    return f"Please recall any stored context relevant to: {topic}"


@mcp.prompt()
def summarize_conversation() -> str:
    """Request a conversation summary for compaction.

    Use this to trigger compaction of the current conversation.
    """
    return (
        "Please compact the current conversation. "
        "Identify topic segments, summarize each independently, "
        "and store the summaries for future retrieval."
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def serve():
    mcp.run()


if __name__ == "__main__":
    serve()
