"""Live web dashboard for the virtual-context proxy.

Serves a self-contained single-page HTML dashboard at ``/dashboard``
and an SSE event stream at ``/dashboard/events``.
"""

from __future__ import annotations

import asyncio
import json
import logging
import mimetypes
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING

import httpx
from fastapi import Request
from fastapi.responses import HTMLResponse, JSONResponse, Response, StreamingResponse

from ..tui.state import load_replay_prompts
from ..types import Message, StrategyConfig

if TYPE_CHECKING:
    from fastapi import FastAPI

    from .metrics import ProxyMetrics
    from .server import ProxyState

logger = logging.getLogger(__name__)

# Module-level replay state (one replay at a time)
_replay_state: dict = {}
_replay_lock: asyncio.Lock | None = None  # created lazily inside the event loop


def _get_replay_lock() -> asyncio.Lock:
    global _replay_lock
    if _replay_lock is None:
        _replay_lock = asyncio.Lock()
    return _replay_lock


def _build_settings_response(cfg) -> dict:
    strategy = cfg.retriever.strategy_configs.get("default") or StrategyConfig()
    return {
        "readonly": {
            "context_window": cfg.monitor.context_window,
            "tagger_type": cfg.tag_generator.type,
            "tagger_model": cfg.tag_generator.model,
            "summarizer_model": cfg.summarization.model,
            "storage_backend": cfg.storage.backend,
        },
        "compaction": {
            "soft_threshold": cfg.monitor.soft_threshold,
            "hard_threshold": cfg.monitor.hard_threshold,
            "protected_recent_turns": cfg.monitor.protected_recent_turns,
            "min_summary_tokens": cfg.compactor.min_summary_tokens,
            "max_summary_tokens": cfg.compactor.max_summary_tokens,
        },
        "tagging": {
            "context_lookback_pairs": cfg.tag_generator.context_lookback_pairs,
            "context_bleed_threshold": cfg.tag_generator.context_bleed_threshold,
            "temporal_heuristic_enabled": cfg.tag_generator.temporal_heuristic_enabled,
        },
        "retrieval": {
            "active_tag_lookback": cfg.retriever.active_tag_lookback,
            "anchorless_lookback": cfg.retriever.anchorless_lookback,
            "max_results": strategy.max_results,
            "max_budget_fraction": strategy.max_budget_fraction,
            "include_related": strategy.include_related,
        },
        "assembly": {
            "tag_context_max_tokens": cfg.assembler.tag_context_max_tokens,
            "recent_turns_always_included": cfg.assembler.recent_turns_always_included,
            "context_hint_enabled": cfg.assembler.context_hint_enabled,
            "context_hint_max_tokens": cfg.assembler.context_hint_max_tokens,
            "pre_compaction_filtering": cfg.assembler.pre_compaction_filtering,
        },
        "summarization": {
            "temperature": cfg.summarization.temperature,
        },
    }


def get_dashboard_html() -> str:
    return _DASHBOARD_HTML


def _check_dashboard_auth(request: Request, dashboard_token: str) -> JSONResponse | None:
    """Validate ``X-VC-Dashboard-Token`` header (or ``?token=`` query param) for mutating endpoints.

    Returns a 403 response if authentication fails, or ``None`` to allow access.
    If *dashboard_token* is empty, auth is skipped.

    Check order: header first, then ``token`` query parameter (needed for
    EventSource which cannot send custom headers).
    """
    if not dashboard_token:
        return None
    provided = request.headers.get("X-VC-Dashboard-Token", "")
    if not provided:
        provided = request.query_params.get("token", "")
    if provided != dashboard_token:
        return JSONResponse({"error": "Invalid or missing dashboard token"}, status_code=403)
    return None


def register_dashboard_routes(
    app: "FastAPI",
    metrics: "ProxyMetrics",
    state: "ProxyState | None",
    shutdown_event: asyncio.Event | None = None,
    *,
    registry: "object | None" = None,
    instance_label: str = "",
    dashboard_token: str = "",
) -> None:
    _static_dir = Path(__file__).parent / "static"
    _token = dashboard_token or os.environ.get("VC_DASHBOARD_TOKEN", "")
    if not _token:
        logger.warning(
            "Dashboard token not configured — mutating endpoints "
            "(shutdown, compact, replay, settings) are unprotected. "
            "Set VC_DASHBOARD_TOKEN or pass dashboard_token to secure them."
        )

    def _registry_states() -> dict[str, ProxyState]:
        conversations = getattr(registry, "_conversations", None)
        return conversations if isinstance(conversations, dict) else {}

    def _dashboard_state(
        preferred_conversation_id: str | None = None,
    ) -> ProxyState | None:
        nonlocal state

        if preferred_conversation_id and registry and hasattr(registry, "get_state"):
            preferred = registry.get_state(preferred_conversation_id)
            if preferred is not None:
                return preferred

        conversations = _registry_states()
        if conversations:
            if state is not None:
                current_id = getattr(
                    getattr(getattr(state, "engine", None), "config", None),
                    "conversation_id",
                    "",
                )
                if current_id and conversations.get(current_id) is state:
                    return state
            resolved = next(iter(conversations.values()), None)
            state = resolved
            return resolved

        if preferred_conversation_id:
            if (
                state is not None
                and getattr(state.engine.config, "conversation_id", "") == preferred_conversation_id
            ):
                return state
            return None

        return state if registry is None else None

    def _dashboard_store():
        active_state = _dashboard_state()
        if active_state is not None:
            return active_state.engine._store
        return None

    async def _stop_replay_for_conversation(conversation_id: str) -> None:
        if _replay_state.get("conversation_id") != conversation_id:
            return
        cancel = _replay_state.get("cancel")
        if cancel:
            cancel.set()
        task = _replay_state.get("task")
        if isinstance(task, asyncio.Task) and not task.done():
            task.cancel()
            try:
                await asyncio.wait_for(task, timeout=5.0)
            except asyncio.CancelledError:
                pass
            except asyncio.TimeoutError:
                logger.warning(
                    "Replay task did not stop within 5.0s for conversation %s",
                    conversation_id,
                )
            except Exception:
                logger.warning(
                    "Replay task shutdown failed for conversation %s",
                    conversation_id,
                    exc_info=True,
                )

    # ------------------------------------------------------------------
    # CORS middleware for virtual-context.com
    # ------------------------------------------------------------------
    _allowed_origins = {
        "https://virtual-context.com",
        "https://www.virtual-context.com",
    }

    @app.middleware("http")
    async def _cors_middleware(request: Request, call_next):
        origin = request.headers.get("origin", "")
        if origin not in _allowed_origins:
            # Non-allowed origin — no CORS headers at all
            return await call_next(request)

        # Preflight (OPTIONS)
        if request.method == "OPTIONS":
            return Response(
                status_code=200,
                headers={
                    "Access-Control-Allow-Origin": origin,
                    "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
                    "Access-Control-Allow-Headers": "Authorization, X-VC-Dashboard-Token, Content-Type",
                    "Access-Control-Max-Age": "3600",
                },
            )

        # Normal request — forward then stamp CORS headers on the response
        response = await call_next(request)
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Access-Control-Allow-Headers"] = (
            "Authorization, X-VC-Dashboard-Token, Content-Type"
        )
        return response

    @app.get("/dashboard")
    async def dashboard_page():
        return HTMLResponse(get_dashboard_html())

    @app.get("/dashboard/static/{filename}")
    async def dashboard_static(filename: str):
        filepath = (_static_dir / filename).resolve()
        # Ensure resolved path is still within _static_dir (prevents traversal)
        if not filepath.is_file() or not str(filepath).startswith(str(_static_dir.resolve())):
            return Response(status_code=404)
        media_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        return Response(content=filepath.read_bytes(), media_type=media_type)

    @app.get("/favicon.ico")
    async def favicon_ico():
        filepath = _static_dir / "favicon.ico"
        if not filepath.is_file():
            return Response(status_code=404)
        return Response(content=filepath.read_bytes(), media_type="image/x-icon")

    @app.get("/dashboard/events")
    async def dashboard_events(request: Request):
        async def event_stream():
            try:
                # Send snapshot immediately
                snap, cursor = metrics.snapshot_with_cursor()
                # Augment with live engine state
                active_state = _dashboard_state()
                if active_state:
                    try:
                        engine = active_state.engine
                        snap["active_tags"] = list(
                            engine._turn_tag_index.get_active_tags(lookback=6)
                        )
                        snap["store_tag_count"] = len(
                            engine._store.get_all_tags(
                                conversation_id=engine.config.conversation_id,
                            )
                        )
                        snap["compacted_through"] = engine._engine_state.compacted_through
                        snap["flushed_through"] = engine._engine_state.flushed_through
                        snap["history_len"] = len(active_state.conversation_history)
                        snap["context_window"] = engine.config.monitor.context_window
                        snap["current_conversation_id"] = engine.config.conversation_id
                        snap["compaction_state"] = active_state.compaction_snapshot()
                    except Exception:
                        logger.debug("SSE engine snapshot failed", exc_info=True)

                # Add live conversations from registry
                live_conversations = []
                if registry and hasattr(registry, "_conversations"):
                    for sid, s in registry._conversations.items():
                        try:
                            live_conversations.append(s.live_snapshot())
                        except Exception:
                            logger.debug("live snapshot failed for conversation %s", sid, exc_info=True)
                snap["live_conversations"] = live_conversations

                if instance_label:
                    snap["instance_label"] = instance_label

                yield f"data: {json.dumps(snap)}\n\n"

                while True:
                    if await request.is_disconnected():
                        break
                    if shutdown_event and shutdown_event.is_set():
                        break
                    new_events = metrics.events_since(cursor)
                    for evt in new_events:
                        yield f"data: {json.dumps(evt)}\n\n"
                        s = evt.get("_seq", -1)
                        if s > cursor:
                            cursor = s
                    await asyncio.sleep(1)
            except asyncio.CancelledError:
                return

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
            },
        )

    @app.get("/dashboard/conversations")
    async def dashboard_conversations():
        active_state = _dashboard_state()
        store = _dashboard_store()
        if not store:
            return JSONResponse({"conversations": [], "current_conversation_id": ""})

        conversations_raw = await asyncio.to_thread(
            store.get_conversation_stats
        )
        current_id = (
            active_state.engine.config.conversation_id if active_state else ""
        )

        conversations = []
        for s in conversations_raw:
            conversations.append({
                "conversation_id": s.conversation_id,
                "is_current": s.conversation_id == current_id,
                "segment_count": s.segment_count,
                "total_full_tokens": s.total_full_tokens,
                "total_summary_tokens": s.total_summary_tokens,
                "compression_ratio": s.compression_ratio,
                "distinct_tags": s.distinct_tags,
                "oldest_segment": (
                    s.oldest_segment.isoformat() if s.oldest_segment else None
                ),
                "newest_segment": (
                    s.newest_segment.isoformat() if s.newest_segment else None
                ),
                "compaction_model": s.compaction_model,
            })

        return JSONResponse({
            "conversations": conversations,
            "current_conversation_id": current_id,
        })

    @app.delete("/dashboard/conversations/{conversation_id}")
    async def dashboard_delete_conversation(conversation_id: str, request: Request):
        nonlocal state
        if err := _check_dashboard_auth(request, _token):
            return err
        active_state = _dashboard_state(conversation_id)
        store = active_state.engine._store if active_state else _dashboard_store()
        if not store:
            return JSONResponse(
                {"error": "Engine not initialized"}, status_code=503,
            )
        if not hasattr(store, "delete_conversation"):
            return JSONResponse(
                {"error": "Store does not support conversation deletion"},
                status_code=501,
            )
        try:
            begin_delete = getattr(store, "begin_conversation_deletion", None)
            if callable(begin_delete):
                await asyncio.to_thread(begin_delete, conversation_id)
            await _stop_replay_for_conversation(conversation_id)
            target_state = None
            if registry and hasattr(registry, "remove_conversation"):
                target_state = registry.remove_conversation(conversation_id)
            elif (
                active_state is not None
                and conversation_id == active_state.engine.config.conversation_id
            ):
                target_state = active_state

            if target_state is not None:
                try:
                    await asyncio.to_thread(
                        target_state.reset_for_conversation_deletion,
                        conversation_id,
                        authoritative=True,
                    )
                except Exception:
                    logger.warning(
                        "Failed to reset deleted conversation %s before store cleanup",
                        conversation_id,
                        exc_info=True,
                    )
                try:
                    await asyncio.to_thread(
                        target_state.shutdown,
                        wait=True,
                        cancel_futures=True,
                    )
                except Exception:
                    logger.warning(
                        "Failed to shut down deleted conversation %s",
                        conversation_id,
                        exc_info=True,
                    )
            deleted = await asyncio.to_thread(store.delete_conversation, conversation_id)
            if metrics:
                await asyncio.to_thread(
                    metrics.delete_conversation_artifacts,
                    conversation_id,
                )
            # Invalidate Redis cache
            cache_state = target_state or active_state or _dashboard_state()
            if (
                cache_state is not None
                and hasattr(cache_state, "engine")
                and hasattr(cache_state.engine, "_session_cache")
                and cache_state.engine._session_cache
            ):
                cache_state.engine._session_cache.delete_conversation(conversation_id)
            if metrics:
                metrics.record({
                    "type": "conversation_deleted",
                    "conversation_id": conversation_id,
                    "segments_removed": deleted,
                })
            if target_state is not None and state is target_state:
                state = _dashboard_state()
            logger.info("Deleted conversation %s: %d segments removed", conversation_id, deleted)
            return JSONResponse({"deleted": deleted})
        except Exception as exc:
            logger.error("Failed to delete conversation %s: %s", conversation_id, exc, exc_info=True)
            return JSONResponse(
                {"error": "Internal server error"}, status_code=500,
            )

    @app.get("/dashboard/conversations/live")
    async def dashboard_conversations_live():
        live_conversations = []
        if registry and hasattr(registry, "_conversations"):
            for sid, s in registry._conversations.items():
                try:
                    live_conversations.append(s.live_snapshot())
                except Exception:
                    logger.debug("live snapshot failed for conversation %s", sid, exc_info=True)
        return JSONResponse(live_conversations)

    @app.post("/dashboard/conversations/{conversation_id}/passthrough")
    async def dashboard_toggle_passthrough(conversation_id: str, request: Request):
        if err := _check_dashboard_auth(request, _token):
            return err
        if not registry or not hasattr(registry, "_conversations"):
            return JSONResponse(
                {"error": "No registry"}, status_code=503,
            )
        s = registry._conversations.get(conversation_id)
        if not s:
            return JSONResponse(
                {"error": "Conversation not found"}, status_code=404,
            )
        body = await request.json()
        enabled = body.get("enabled", False)
        s.set_manual_passthrough(enabled)
        return JSONResponse({"ok": True})

    # -----------------------------------------------------------------------
    # Session export
    # -----------------------------------------------------------------------

    @app.get("/dashboard/export")
    async def dashboard_export():
        from .. import __version__

        snap = metrics.snapshot()
        snap.pop("type", None)
        snap["version"] = __version__

        active_state = _dashboard_state()
        if active_state:
            try:
                engine = active_state.engine
                # TurnTagIndex — full per-turn tag data
                entries = []
                for entry in engine._turn_tag_index.entries:
                    entries.append({
                        "turn": entry.turn_number,
                        "tags": entry.tags,
                        "primary_tag": entry.primary_tag,
                    })
                snap["turn_tag_index"] = entries

                # Store tags
                cfg = engine.config
                snap["store_tags"] = [
                    ts.tag
                    for ts in engine._store.get_all_tags(
                        conversation_id=cfg.conversation_id,
                    )
                ]

                # Config summary
                snap["config"] = {
                    "conversation_id": cfg.conversation_id,
                    "context_window": cfg.monitor.context_window,
                    "soft_threshold": cfg.monitor.soft_threshold,
                    "hard_threshold": cfg.monitor.hard_threshold,
                    "tagger_type": cfg.tag_generator.type,
                    "tagger_model": cfg.tag_generator.model,
                    "summarizer_model": cfg.summarization.model,
                    "storage_backend": cfg.storage.backend,
                }

                snap["conversation_turns"] = len(
                    active_state.conversation_history
                ) // 2
                snap["compacted_through"] = engine._engine_state.compacted_through
                snap["flushed_through"] = engine._engine_state.flushed_through
            except Exception as e:
                logger.error("Export error: %s", e, exc_info=True)
                snap["_export_error"] = "Failed to export engine state"

        return JSONResponse(snap)

    # -----------------------------------------------------------------------
    # Telemetry endpoint
    # -----------------------------------------------------------------------

    @app.get("/dashboard/telemetry")
    async def dashboard_telemetry():
        if metrics._telemetry_ledger:
            telem = metrics._telemetry_ledger.to_dict()
            telem.pop("events", None)
            return JSONResponse(telem)
        return JSONResponse({})

    # -----------------------------------------------------------------------
    # Request inspection endpoints
    # -----------------------------------------------------------------------

    @app.get("/dashboard/requests")
    async def list_captured_requests():
        return JSONResponse(metrics.get_captured_requests_summary())

    @app.get("/dashboard/requests/{turn}")
    async def get_captured_request(turn: int):
        req = metrics.get_captured_request(turn)
        if req is None:
            return JSONResponse({"error": "not found"}, status_code=404)
        return JSONResponse(req)

    # -----------------------------------------------------------------------
    # Replay endpoints
    # -----------------------------------------------------------------------

    @app.post("/dashboard/replay/start")
    async def replay_start(request: Request):
        if err := _check_dashboard_auth(request, _token):
            return err
        active_state = _dashboard_state()
        if not active_state:
            return JSONResponse(
                {"error": "Engine not initialized"}, status_code=503,
            )

        # I4: serialize check-and-set to prevent double-start race
        async with _get_replay_lock():
            if _replay_state.get("running"):
                return JSONResponse(
                    {"error": "Replay already running"}, status_code=409,
                )

            if not getattr(active_state.engine, "_llm_provider", None):
                return JSONResponse(
                    {"error": "No LLM provider configured in engine"},
                    status_code=503,
                )

            body = await request.json()
            file_path = body.get("file", "")

            if not file_path:
                return JSONResponse(
                    {"error": "Missing 'file' field"}, status_code=400,
                )

            p = Path(file_path).resolve()

            # Prevent path traversal: resolved path must be under CWD
            allowed_root = Path.cwd().resolve()
            if not str(p).startswith(str(allowed_root) + os.sep) and p != allowed_root:
                return JSONResponse(
                    {"error": "Path is outside the allowed directory"}, status_code=403,
                )

            # Restrict to files with expected replay extensions to prevent
            # arbitrary file reads via this endpoint.
            allowed_extensions = {".txt", ".md", ".yaml", ".yml", ".json", ".jsonl"}
            if p.suffix.lower() not in allowed_extensions:
                return JSONResponse(
                    {"error": f"File type not allowed: {p.suffix}"}, status_code=400,
                )

            if not p.exists():
                return JSONResponse(
                    {"error": "File not found"}, status_code=400,
                )

            try:
                prompts = load_replay_prompts(p)
            except Exception as e:
                logger.error("Failed to load prompts from %s: %s", p, e)
                return JSONResponse(
                    {"error": "Failed to load prompts file"}, status_code=400,
                )

            if not prompts:
                return JSONResponse(
                    {"error": "No prompts found in file"}, status_code=400,
                )

            cancel = asyncio.Event()
            task = asyncio.create_task(
                _replay_worker(prompts, active_state, metrics, cancel)
            )

            def _on_replay_done(t: asyncio.Task) -> None:
                exc = t.exception() if not t.cancelled() else None
                if exc:
                    logger.error("Replay task failed: %s", exc, exc_info=exc)
                    metrics.record({
                        "type": "replay_done",
                        "turns_completed": 0,
                        "total": len(prompts),
                        "status": "error",
                        "error": str(exc),
                    })
                    _replay_state.clear()

            task.add_done_callback(_on_replay_done)
            _replay_state.update({
                "running": True,
                "task": task,
                "cancel": cancel,
                "turn": 0,
                "total": len(prompts),
                "conversation_id": active_state.engine.config.conversation_id,
            })

        return JSONResponse({
            "status": "started",
            "total_prompts": len(prompts),
        })

    @app.post("/dashboard/replay/stop")
    async def replay_stop(request: Request):
        if err := _check_dashboard_auth(request, _token):
            return err
        cancel = _replay_state.get("cancel")
        if cancel:
            cancel.set()
        return JSONResponse({"status": "stopping"})

    @app.get("/dashboard/replay/status")
    async def replay_status():
        if _replay_state.get("running"):
            return JSONResponse({
                "running": True,
                "turn": _replay_state.get("turn", 0),
                "total": _replay_state.get("total", 0),
            })
        return JSONResponse({"running": False})

    @app.post("/dashboard/shutdown")
    async def dashboard_shutdown(request: Request):
        if err := _check_dashboard_auth(request, _token):
            return err
        import signal

        logger.info("Shutdown requested via dashboard")
        # Send SIGINT to ourselves — triggers the same graceful shutdown as Ctrl+C
        os.kill(os.getpid(), signal.SIGINT)
        return JSONResponse({"status": "shutting_down"})

    # -------------------------------------------------------------------
    # Manual compaction endpoint
    # -------------------------------------------------------------------

    @app.post("/dashboard/compact")
    async def dashboard_compact(request: Request):
        if err := _check_dashboard_auth(request, _token):
            return err
        active_state = _dashboard_state()
        if not active_state:
            return JSONResponse(
                {"error": "Engine not initialized"}, status_code=503,
            )

        # Reject if compaction is already running
        if not active_state._compaction_lock.acquire(blocking=False):
            return JSONResponse(
                {"status": "busy", "message": "Compaction already in progress"},
                status_code=409,
            )

        try:
            # Wait for any pending on_turn_complete to finish
            await asyncio.to_thread(active_state.wait_for_complete)

            # Run compaction in a thread (accesses engine internals)
            report = await asyncio.to_thread(
                active_state.engine.compact_manual, active_state.conversation_history
            )

            if report is None:
                return JSONResponse({
                    "status": "no_action",
                    "message": "Nothing to compact (not enough messages outside protected zone)",
                })

            # Emit compaction event so the dashboard updates live
            if metrics:
                turn = len(active_state.conversation_history) // 2 - 1
                original_tokens = sum(r.original_tokens for r in report.results)
                summary_tokens = sum(r.summary_tokens for r in report.results)
                metrics.record({
                    "type": "compaction",
                    "turn": turn,
                    "segments": report.segments_compacted,
                    "tokens_freed": report.tokens_freed,
                    "original_tokens": original_tokens,
                    "summary_tokens": summary_tokens,
                    "tags": report.tags,
                    "tag_summaries_built": report.tag_summaries_built,
                    "compacted_through": active_state.engine._engine_state.compacted_through,
                    "flushed_through": active_state.engine._engine_state.flushed_through,
                })

            return JSONResponse({
                "status": "compacted",
                "segments": report.segments_compacted,
                "tokens_freed": report.tokens_freed,
                "tags": report.tags,
                "tag_summaries_built": report.tag_summaries_built,
            })
        finally:
            active_state._compaction_lock.release()

    # -------------------------------------------------------------------
    # Settings endpoints
    # -------------------------------------------------------------------

    @app.get("/dashboard/settings")
    async def dashboard_settings_get():
        active_state = _dashboard_state()
        if not active_state:
            return JSONResponse(
                {"error": "Engine not initialized"}, status_code=503,
            )
        resp = _build_settings_response(active_state.engine.config)
        if instance_label:
            resp["instance_label"] = instance_label
        resp["non_virtualizable_floor"] = getattr(active_state, "_last_non_virtualizable_floor", 0)

        # Upstream context limit (resolved from last request's model)
        from ..model_limits import resolve_upstream_limit
        try:
            _inst_lim = getattr(active_state, '_instance_upstream_limit', 0)
            _global_lim = active_state.engine.config.proxy.upstream_context_limit
            _model = getattr(active_state, '_last_model', '')
            resp["upstream_context_limit"] = resolve_upstream_limit(_model, _inst_lim, _global_lim)
        except Exception:
            resp["upstream_context_limit"] = 200_000

        return JSONResponse(resp)

    @app.put("/dashboard/settings")
    async def dashboard_settings_put(request: Request):
        if err := _check_dashboard_auth(request, _token):
            return err
        active_state = _dashboard_state()
        if not active_state:
            return JSONResponse(
                {"error": "Engine not initialized"}, status_code=503,
            )
        body = await request.json()
        cfg = active_state.engine.config
        strategy = cfg.retriever.strategy_configs.get("default")
        if strategy is None:
            strategy = StrategyConfig()
            cfg.retriever.strategy_configs["default"] = strategy

        # Map of (section, key) -> (target_obj, attr_name, type_cast)
        field_map = {
            ("compaction", "soft_threshold"): (cfg.monitor, "soft_threshold", float),
            ("compaction", "hard_threshold"): (cfg.monitor, "hard_threshold", float),
            ("compaction", "protected_recent_turns"): (cfg.monitor, "protected_recent_turns", int),
            ("compaction", "min_summary_tokens"): (cfg.compactor, "min_summary_tokens", int),
            ("compaction", "max_summary_tokens"): (cfg.compactor, "max_summary_tokens", int),
            ("tagging", "context_lookback_pairs"): (cfg.tag_generator, "context_lookback_pairs", int),
            ("tagging", "context_bleed_threshold"): (cfg.tag_generator, "context_bleed_threshold", float),
            ("tagging", "temporal_heuristic_enabled"): (cfg.tag_generator, "temporal_heuristic_enabled", bool),
            ("retrieval", "active_tag_lookback"): (cfg.retriever, "active_tag_lookback", int),
            ("retrieval", "anchorless_lookback"): (cfg.retriever, "anchorless_lookback", int),
            ("retrieval", "max_results"): (strategy, "max_results", int),
            ("retrieval", "max_budget_fraction"): (strategy, "max_budget_fraction", float),
            ("retrieval", "include_related"): (strategy, "include_related", bool),
            ("assembly", "tag_context_max_tokens"): (cfg.assembler, "tag_context_max_tokens", int),
            ("assembly", "recent_turns_always_included"): (cfg.assembler, "recent_turns_always_included", int),
            ("assembly", "context_hint_enabled"): (cfg.assembler, "context_hint_enabled", bool),
            ("assembly", "context_hint_max_tokens"): (cfg.assembler, "context_hint_max_tokens", int),
            ("summarization", "temperature"): (cfg.summarization, "temperature", float),
        }

        # String enum fields: (target_obj, attr_name, valid_values)
        _str_enum_fields = {
            ("assembly", "pre_compaction_filtering"): (
                cfg.assembler, "pre_compaction_filtering",
                {"off", "conservative", "aggressive"},
            ),
        }

        # Collect updates
        updates = []
        for section, keys in body.items():
            if section == "readonly":
                continue
            if not isinstance(keys, dict):
                return JSONResponse(
                    {"error": f"Section '{section}' must be an object"},
                    status_code=400,
                )
            for key, value in keys.items():
                mapping = field_map.get((section, key))
                if mapping is not None:
                    obj, attr, cast = mapping
                    try:
                        value = cast(value)
                    except (ValueError, TypeError):
                        return JSONResponse(
                            {"error": f"Invalid type for {section}.{key}"},
                            status_code=400,
                        )
                    updates.append((obj, attr, value, section, key))
                    continue

                str_enum = _str_enum_fields.get((section, key))
                if str_enum is not None:
                    obj, attr, valid_values = str_enum
                    if value not in valid_values:
                        return JSONResponse(
                            {"error": f"'{key}' must be one of {sorted(valid_values)}, got '{value}'"},
                            status_code=400,
                        )
                    updates.append((obj, attr, value, section, key))
                    continue

                return JSONResponse(
                    {"error": f"Unknown setting: {section}.{key}"},
                    status_code=400,
                )

        # Preview-validate cross-field constraints
        preview = {
            "soft_threshold": cfg.monitor.soft_threshold,
            "hard_threshold": cfg.monitor.hard_threshold,
            "min_summary_tokens": cfg.compactor.min_summary_tokens,
            "max_summary_tokens": cfg.compactor.max_summary_tokens,
        }
        for obj, attr, value, section, key in updates:
            if key in preview:
                preview[key] = value

        if preview["soft_threshold"] >= preview["hard_threshold"]:
            return JSONResponse(
                {"error": "soft_threshold must be less than hard_threshold"},
                status_code=400,
            )
        if preview["min_summary_tokens"] > preview["max_summary_tokens"]:
            return JSONResponse(
                {"error": "min_summary_tokens must not exceed max_summary_tokens"},
                status_code=400,
            )

        # Apply updates
        for obj, attr, value, section, key in updates:
            setattr(obj, attr, value)

        # Sync tag_context_max_tokens to retriever when assembler changes
        if any(key == "tag_context_max_tokens" for _, _, _, _, key in updates):
            cfg.retriever.tag_context_max_tokens = cfg.assembler.tag_context_max_tokens

        return JSONResponse(_build_settings_response(cfg))


async def _call_llm(
    client: httpx.AsyncClient,
    prov: dict,
    system_text: str,
    messages: list[dict],
) -> str:
    """Call the LLM in the correct format (OpenAI or Anthropic)."""
    # Build auth headers at call time from _raw_key (headers dict has redacted keys)
    raw_key = prov.get("_raw_key", "")
    if prov["format"] == "anthropic":
        call_headers = {
            "x-api-key": raw_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        payload = {
            "model": prov["model"],
            "max_tokens": 4096,
            "messages": messages,
        }
        if system_text:
            context_block = (
                f"<system-reminder>\n{system_text}\n</system-reminder>"
            )
            payload["system"] = context_block
        resp = await client.post(prov["url"], headers=call_headers, json=payload)
        data = resp.json()
        content = data.get("content", [])
        parts = [b["text"] for b in content if b.get("type") == "text"]
        return "".join(parts)
    else:
        # OpenAI-compatible
        call_headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {raw_key}",
        }
        msgs = []
        if system_text:
            context_block = (
                f"<system-reminder>\n{system_text}\n</system-reminder>"
            )
            msgs.append({"role": "system", "content": context_block})
        msgs.extend(messages)
        payload = {
            "model": prov["model"],
            "messages": msgs,
            "stream": False,
        }
        resp = await client.post(prov["url"], headers=call_headers, json=payload)
        data = resp.json()
        choices = data.get("choices", [])
        return choices[0].get("message", {}).get("content", "") if choices else ""


def _get_provider_config(engine) -> dict:
    from ..providers.generic_openai import GenericOpenAIProvider

    provider = engine._llm_provider

    def _redact(key: str) -> str:
        if not key or len(key) <= 8:
            return "***"
        return key[:4] + "..." + key[-4:]

    try:
        from ..providers.anthropic import AnthropicProvider
        if isinstance(provider, AnthropicProvider):
            return {
                "format": "anthropic",
                "url": "https://api.anthropic.com/v1/messages",
                "model": provider.model,
                "headers": {
                    "x-api-key": _redact(provider.api_key),
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                "_raw_key": provider.api_key,
            }
    except ImportError:
        pass

    # GenericOpenAI (Ollama, OpenRouter, vLLM, etc.)
    return {
        "format": "openai",
        "url": f"{provider.base_url}/chat/completions",
        "model": provider.model,
        "headers": {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {_redact(provider.api_key)}",
        },
        "_raw_key": provider.api_key,
    }


async def _replay_worker(
    prompts: list[str],
    state: "ProxyState",
    metrics: "ProxyMetrics",
    cancel: asyncio.Event,
) -> None:
    """Execute prompts through the proxy engine, calling the configured LLM."""
    total = len(prompts)
    completed = 0

    try:
        prov = _get_provider_config(state.engine)
        logger.info(
            "Replay starting: %d prompts, provider=%s, model=%s, url=%s",
            total, prov["format"], prov["model"], prov["url"],
        )

        async with httpx.AsyncClient(
            timeout=httpx.Timeout(120.0, connect=10.0),
        ) as client:
            for i, prompt in enumerate(prompts):
                if cancel.is_set():
                    break
                if state.is_conversation_deleted():
                    break

                t_start = time.monotonic()

                # Wait for previous on_turn_complete
                t0 = time.monotonic()
                await asyncio.to_thread(state.wait_for_complete)
                wait_ms = round((time.monotonic() - t0) * 1000, 1)

                # Append user message to history
                if state.is_conversation_deleted():
                    break
                state.conversation_history.append(
                    Message(role="user", content=prompt)
                )

                # Engine: tag + retrieve + assemble
                t1 = time.monotonic()
                if state.is_conversation_deleted():
                    break
                assembled = await asyncio.to_thread(
                    state.engine.on_message_inbound,
                    prompt,
                    state.conversation_history,
                )
                inbound_ms = round((time.monotonic() - t1) * 1000, 1)

                system_text = assembled.prepend_text

                # Filter history by tag relevance
                filtered = state.engine.filter_history(
                    state.conversation_history,
                    current_tags=assembled.matched_tags,
                )

                # Build messages for LLM
                api_messages = []
                for m in filtered:
                    api_messages.append({"role": m.role, "content": m.content})

                # Brief mode: short answers for stress testing
                if api_messages and api_messages[-1]["role"] == "user":
                    api_messages[-1] = dict(api_messages[-1])
                    api_messages[-1]["content"] += "\n\n(Answer in 2 lines.)"

                # Call LLM (format depends on provider)
                try:
                    assistant_text = await _call_llm(
                        client, prov, system_text, api_messages,
                    )
                except Exception as e:
                    logger.error("Replay LLM error at turn %d: %s", i, e)
                    assistant_text = f"[replay error: {e}]"

                # Append assistant response
                if state.is_conversation_deleted():
                    break
                state.conversation_history.append(
                    Message(role="assistant", content=assistant_text)
                )

                # Emit request event (same shape as catch_all)
                turn = len(state.conversation_history) // 2 - 1
                context_tokens = len(system_text) // 4 if system_text else 0
                total_turns = len(state.conversation_history) // 2
                filtered_turns = len(filtered) // 2
                # Estimate total payload tokens (system + filtered messages)
                payload_chars = len(system_text)
                for m in filtered:
                    payload_chars += len(m.content)
                input_tokens = payload_chars // 4
                metrics.record({
                    "type": "request",
                    "turn": turn,
                    "message_preview": prompt[:200],
                    "api_format": prov["format"],
                    "streaming": False,
                    "tags": assembled.matched_tags,
                    "context_tokens": context_tokens,
                    "budget": assembled.budget_breakdown,
                    "history_len": len(state.conversation_history),
                    "compacted_through": state.engine._engine_state.compacted_through,
                    "flushed_through": state.engine._engine_state.flushed_through,
                    "wait_ms": wait_ms,
                    "inbound_ms": inbound_ms,
                    "total_turns": total_turns,
                    "filtered_turns": filtered_turns,
                    "input_tokens": input_tokens,
                })

                # Fire on_turn_complete in background
                state.fire_turn_complete(list(state.conversation_history))

                completed = i + 1
                _replay_state["turn"] = completed

                # Emit progress event
                elapsed_ms = round((time.monotonic() - t_start) * 1000, 1)
                metrics.record({
                    "type": "replay_progress",
                    "turn": completed,
                    "total": total,
                    "prompt_preview": prompt[:80],
                    "elapsed_ms": elapsed_ms,
                })

        # Wait for final on_turn_complete
        await asyncio.to_thread(state.wait_for_complete)

    except Exception as e:
        logger.error("Replay worker error: %s", e, exc_info=True)
        metrics.record({
            "type": "replay_done",
            "turns_completed": completed,
            "total": total,
            "status": "error",
            "error": str(e),
        })
        return
    finally:
        _replay_state.clear()

    status = "stopped" if cancel.is_set() else "complete"
    logger.info("Replay %s: %d/%d turns", status, completed, total)
    metrics.record({
        "type": "replay_done",
        "turns_completed": completed,
        "total": total,
        "status": status,
    })


# ---------------------------------------------------------------------------
# Self-contained HTML dashboard (loaded from dashboard.html)
# ---------------------------------------------------------------------------

_DASHBOARD_HTML = (Path(__file__).with_name("dashboard.html")).read_text(encoding="utf-8")
