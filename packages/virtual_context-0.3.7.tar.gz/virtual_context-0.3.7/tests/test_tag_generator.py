"""Tests for tag generator: LLM-based and keyword-based."""

import pytest

from virtual_context.core.tag_generator import (
    CODE_TAG_GENERATOR_PROMPTS,
    KeywordTagGenerator,
    LLMTagGenerator,
    build_tag_generator,
)
from virtual_context.core.tag_canonicalizer import TagCanonicalizer
from virtual_context.types import KeywordTagConfig, TagGeneratorConfig

from conftest import MockLLMProvider


class TestKeywordTagGenerator:
    @pytest.fixture
    def keyword_config(self):
        return KeywordTagConfig(
            tag_keywords={
                "legal": ["court", "filing", "motion", "attorney"],
                "medical": ["insulin", "medication", "doctor", "blood"],
                "code": ["function", "bug", "deploy", "API"],
            },
            tag_patterns={
                "legal": [r"\b\d{2}-cv-\d+"],
                "code": [r"\bdef \w+\("],
            },
        )

    @pytest.fixture
    def generator(self, keyword_config):
        return KeywordTagGenerator(config=keyword_config)

    def test_keyword_match(self, generator):
        result = generator.generate_tags("The attorney filed a motion in court")
        assert "legal" in result.tags
        assert result.primary == "legal"
        assert result.source == "keyword"

    def test_pattern_match(self, generator):
        result = generator.generate_tags("Check case 24-cv-1234 details")
        assert "legal" in result.tags

    def test_no_match_returns_general(self, generator):
        result = generator.generate_tags("What's the weather like today?")
        assert result.tags == ["_general"]
        assert result.primary == "_general"
        assert result.source == "fallback"

    def test_multiple_tag_match(self, generator):
        result = generator.generate_tags(
            "The doctor said the bug in the insulin pump needs fixing"
        )
        assert len(result.tags) >= 1



class TestLLMTagGenerator:
    @pytest.fixture
    def llm_response(self):
        return '{"tags": ["database-schema", "migration"], "primary": "database-schema"}'

    @pytest.fixture
    def generator(self, llm_response):
        provider = MockLLMProvider(response=llm_response)
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        return LLMTagGenerator(llm_provider=provider, config=config)

    def test_llm_tag_generation(self, generator):
        result = generator.generate_tags("We need to create the users table")
        assert "database-schema" in result.tags
        assert result.primary == "database-schema"
        assert result.source == "llm"

    def test_normalize_tags(self, generator):
        tags = generator._normalize_tags(["Database Schema", "API Design", "auth-flow"])
        assert tags == ["database-schema", "api-design", "auth-flow"]

    def test_normalize_single_tag(self, generator):
        assert generator._normalize_tag("Database Schema") == "database-schema"
        assert generator._normalize_tag("  auth-flow  ") == "auth-flow"
        assert generator._normalize_tag("API_Design") == "api-design"

    def test_vocabulary_tracking(self, generator):
        generator.generate_tags("First call")
        assert "database-schema" in generator._tag_vocabulary
        assert generator._tag_vocabulary["database-schema"] == 1

        generator.generate_tags("Second call")
        assert generator._tag_vocabulary["database-schema"] == 2

    def test_alias_resolution(self):
        canonicalizer = TagCanonicalizer()
        canonicalizer.register_alias("db-schema", "database-schema")
        provider = MockLLMProvider(response='{"tags": ["database-schema"], "primary": "database-schema"}')
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config, canonicalizer=canonicalizer)
        assert generator._normalize_tag("db-schema") == "database-schema"

    def test_fallback_on_error(self):
        """Test fallback when LLM fails."""
        provider = MockLLMProvider(response="invalid json {{{")
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)
        result = generator.generate_tags("test text")
        assert result.tags == ["_general"]
        assert result.source == "fallback"

    def test_strips_thinking_tags(self):
        """Test that <think>...</think> tags are stripped."""
        provider = MockLLMProvider(
            response='<think>Let me analyze this...</think>{"tags": ["api-design"], "primary": "api-design"}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)
        result = generator.generate_tags("Design an API")
        assert "api-design" in result.tags

    def test_load_vocabulary(self, generator):
        generator.load_vocabulary({"auth": 10, "database": 5})
        assert generator._tag_vocabulary["auth"] == 10
        assert generator._tag_vocabulary["database"] == 5

    def test_code_refs_parsed_and_normalized(self):
        provider = MockLLMProvider(
            response=(
                '{"tags": ["backend"], "primary": "backend", '
                '"code_refs": ['
                '{"file": " server.py ", "line": "42", "symbol": "handle_request"}, '
                '{"path": "server.py", "line": 42, "name": "handle_request"}, '
                '{"file": "retriever.py", "class": "ContextRetriever"}'
                ']}'
            )
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config, code_mode=True)

        result = generator.generate_tags("Patch the request path")

        assert result.code_refs == [
            {"file": "server.py", "line": 42, "symbol": "handle_request"},
            {"file": "retriever.py", "symbol": "ContextRetriever"},
        ]

    @pytest.mark.parametrize("prompt_mode", ["detailed", "compact", "small_model"])
    def test_code_mode_uses_dedicated_tagger_prompt_family(self, prompt_mode):
        from virtual_context.core.compactor import CODE_FACT_EXTRACTION_PROMPT

        provider = MockLLMProvider(
            response='{"tags": ["backend"], "primary": "backend", "fact_signals": [], "code_refs": []}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1, prompt_mode=prompt_mode)
        generator = LLMTagGenerator(llm_provider=provider, config=config, code_mode=True)

        generator.generate_tags("We fixed the cache boundary in server.py.")

        system = provider.calls[0]["system"]
        assert system == CODE_TAG_GENERATOR_PROMPTS[prompt_mode].format(min_tags=1, max_tags=5)
        assert "fact_signals" in system
        assert "code_refs" in system
        assert CODE_FACT_EXTRACTION_PROMPT.strip() not in system

    def test_fact_signals_parsed_from_code_mode_response(self):
        provider = MockLLMProvider(
            response=(
                '{"tags": ["backend"], "primary": "backend", '
                '"fact_signals": ['
                '{"subject": "cache boundary", "verb": "changed", "object": "moved above vc reminder injection", '
                '"status": "completed", "fact_type": "world", "what": "Cache boundary changed to sit above the VC reminder injection."}'
                '], "code_refs": []}'
            )
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config, code_mode=True)

        result = generator.generate_tags("Patch the cache boundary.")

        assert len(result.fact_signals) == 1
        assert result.fact_signals[0].subject == "cache boundary"
        assert result.fact_signals[0].verb == "changed"

    def test_select_relevant_store_tags_reuses_cached_embeddings(self):
        provider = MockLLMProvider(response='{"tags": ["database"], "primary": "database"}')
        cache_loads: list[list[str]] = []
        cache_saves: list[dict[str, list[float]]] = []
        embed_calls: list[list[str]] = []

        def embed_fn(texts: list[str]) -> list[list[float]]:
            embed_calls.append(list(texts))
            vectors = {
                "database": [1.0, 0.0, 0.0],
                "api": [0.0, 1.0, 0.0],
                "schema design": [0.9, 0.1, 0.0],
            }
            return [vectors.get(text.lower(), [0.0, 0.0, 1.0]) for text in texts]

        def load_cached(model_name: str, tags: list[str]) -> dict[str, list[float]]:
            cache_loads.append(list(tags))
            return {"database": [1.0, 0.0, 0.0]}

        def save_cached(model_name: str, embeddings: dict[str, list[float]]) -> None:
            cache_saves.append(dict(embeddings))

        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(
            llm_provider=provider,
            config=config,
            embed_fn_factory=lambda: embed_fn,
            embedding_model_name="model-x",
            load_cached_embeddings=load_cached,
            save_cached_embeddings=save_cached,
        )

        selected = generator._select_relevant_store_tags(
            "schema design",
            ["database", "api"],
            limit=2,
        )

        assert selected[0] == "database"
        assert cache_loads == [["database", "api"]]
        assert cache_saves and "api" in cache_saves[0]
        assert ["api"] in embed_calls
        assert ["schema design"] in embed_calls


class TestRelatedTagsParsing:
    """Test that related_tags are parsed and normalized from LLM response."""

    def test_related_tags_parsed(self):
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database", "broad": false, "related_tags": ["sql", "postgres"]}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        result = generator.generate_tags("database design")
        assert result.related_tags == ["sql", "postgres"]

    def test_related_tags_normalized(self):
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database", "broad": false, "related_tags": ["SQL Server", "Post Gres"]}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        result = generator.generate_tags("database design")
        assert "sql-server" in result.related_tags
        assert "post-gres" in result.related_tags

    def test_related_tags_deduped_against_primary(self):
        provider = MockLLMProvider(
            response='{"tags": ["database", "schema"], "primary": "database", "broad": false, "related_tags": ["database", "sql", "schema"]}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        result = generator.generate_tags("database schema")
        # "database" and "schema" should be removed since they're already in primary tags
        assert "database" not in result.related_tags
        assert "schema" not in result.related_tags
        assert "sql" in result.related_tags

    def test_no_related_tags_returns_empty(self):
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database", "broad": false}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        result = generator.generate_tags("database design")
        assert result.related_tags == []

    def test_related_tags_invalid_type_returns_empty(self):
        """If related_tags is not a list, return empty."""
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database", "related_tags": "not-a-list"}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        result = generator.generate_tags("database design")
        assert result.related_tags == []


class TestContextLookback:
    """Test that context_turns are injected into the tagger prompt."""

    def test_context_turns_in_prompt(self):
        """When context_turns is provided, the prompt should contain a context section."""
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database"}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        context = [
            "How do I optimize the users table query?",
            "Add an index on the email column and use EXPLAIN ANALYZE.",
        ]
        generator.generate_tags("of course", context_turns=context)

        # Check the prompt sent to the LLM
        assert len(provider.calls) == 1
        prompt = provider.calls[0]["user"]
        assert "Recent conversation context:" in prompt
        assert "optimize the users table" in prompt

    def test_no_context_turns_no_section(self):
        """When context_turns is not provided, no context section in prompt."""
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database"}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        generator.generate_tags("How do I optimize queries?")

        prompt = provider.calls[0]["user"]
        assert "Recent conversation context:" not in prompt

    def test_context_turns_none_backward_compat(self):
        """context_turns=None is identical to omitting it."""
        provider = MockLLMProvider(
            response='{"tags": ["database"], "primary": "database"}'
        )
        config = TagGeneratorConfig(type="llm", max_tags=5, min_tags=1)
        generator = LLMTagGenerator(llm_provider=provider, config=config)

        generator.generate_tags("test", context_turns=None)

        prompt = provider.calls[0]["user"]
        assert "Recent conversation context:" not in prompt


class TestBuildTagGenerator:
    def test_build_keyword_generator(self):
        config = TagGeneratorConfig(
            type="keyword",
            keyword_fallback=KeywordTagConfig(
                tag_keywords={"test": ["hello"]},
            ),
        )
        gen = build_tag_generator(config)
        assert isinstance(gen, KeywordTagGenerator)

    def test_build_llm_generator(self):
        config = TagGeneratorConfig(type="llm")
        provider = MockLLMProvider()
        gen = build_tag_generator(config, llm_provider=provider)
        assert isinstance(gen, LLMTagGenerator)

    def test_build_embedding_generator_passes_shared_cache_hooks(self):
        config = TagGeneratorConfig(type="embedding")
        loaded: list[list[str]] = []
        saved: list[dict[str, list[float]]] = []

        def embed_fn(texts: list[str]) -> list[list[float]]:
            return [[1.0] for _ in texts]

        def load_cached(model_name: str, tags: list[str]) -> dict[str, list[float]]:
            loaded.append(list(tags))
            return {}

        def save_cached(model_name: str, embeddings: dict[str, list[float]]) -> None:
            saved.append(dict(embeddings))

        gen = build_tag_generator(
            config,
            embed_fn_factory=lambda: embed_fn,
            embedding_model_name="model-x",
            load_cached_embeddings=load_cached,
            save_cached_embeddings=save_cached,
        )

        gen.generate_tags("hello", existing_tags=["alpha"])
        assert loaded == [["alpha"]]
        assert saved and "alpha" in saved[0]

    def test_fallback_to_keyword_when_no_provider(self):
        config = TagGeneratorConfig(
            type="llm",
            keyword_fallback=KeywordTagConfig(tag_keywords={"x": ["y"]}),
        )
        gen = build_tag_generator(config, llm_provider=None)
        assert isinstance(gen, KeywordTagGenerator)
