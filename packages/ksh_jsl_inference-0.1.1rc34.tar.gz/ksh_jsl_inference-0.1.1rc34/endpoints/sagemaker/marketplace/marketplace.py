"""Utilities for creating and monitoring SageMaker Marketplace model packages.

This module provides functions to upload validation data to S3, create SageMaker
Marketplace model packages with validation specifications, and poll package status
until completion or timeout.

Usage:
    from endpoints.sagemaker import marketplace

    marketplace.create_model_package(
        model_package_name="my-model",
        ...
    )
"""

from typing import Optional

from endpoints.core import ModelInfo
from endpoints.sagemaker import build_docker_image
from endpoints.server.utils import download_model
from endpoints.settings import DEFAULT_JOHNSNOWLABS_VERSION

from .. import utils
from . import helper


def upload_model_artifacts(
    model_info: ModelInfo, s3_bucket: str, s3_key: Optional[str] = None
):
    """Packages and uploads model artifacts to an S3 bucket.

    Downloads model artifacts, creates a tarball, and uploads it to the specified S3 bucket.
    If no s3_key is provided, one is generated based on the model info.

    Args:
        model_info (ModelInfo): Metadata and configuration for the model to upload.
        s3_bucket (str): Name of the S3 bucket where the model artifacts should be uploaded.
        s3_key (Optional[str], optional): Custom S3 key for the uploaded file. If not provided, it is generated automatically.

    Returns:
        None
    """
    if not s3_key:
        s3_key = helper.build_model_artifacts_s3_key(model_info)
    model_artifacts_path = download_model(model_info)
    model_artifacts_path = utils.create_model_tarball(model_artifacts_path)
    utils.upload_model_to_s3(
        file_path=model_artifacts_path,
        bucket_name=s3_bucket,
        s3_key=s3_key,
    )


def build_ecr_image(
    model_info: ModelInfo,
    json_license_path: Optional[str] = None,
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    image_name: Optional[str] = None,
    image_tag: str = "latest",
):
    """Builds and pushes a Docker image to Amazon ECR for SageMaker Marketplace.

    This function builds a Docker image based on the given model info and optional license and version,
    logs into Amazon ECR, and pushes the image for later use in SageMaker Marketplace workflows.

    Args:
        model_info (ModelInfo): Metadata and info about the model.
        json_license_path (Optional[str], optional): Path to a license in JSON format for airgapped validation. Defaults to None.
        johnsnowlabs_version (str, optional): Version of JohnSnowLabs libraries to use in the image. Defaults to DEFAULT_JOHNSNOWLABS_VERSION.
        image_name (Optional[str], optional): Custom image name. If not supplied, one is constructed from model_info. Defaults to None.
        image_tag (str, optional): Image tag. Defaults to "latest".

    Returns:
        str: The URI of the pushed ECR image.
    """
    # TODO: Validate that the license is an airgap license.
    # Model Validation runs with network isolation
    if not image_name:
        image_name, image_tag = helper.build_ecr_image_name_with_tag(model_info)

    ecr_image = build_docker_image(
        model_id=model_info.model_id,
        language=model_info.language,
        johnsnowlabs_version=johnsnowlabs_version,
        image_name=image_name,
        image_tag=image_tag,
        json_license_path=json_license_path,
    )
    utils.login_to_ecr()
    return utils.push_image_to_ecr(ecr_image, image_name, image_tag)


def create_model_package(
    model_info: ModelInfo,
    s3_bucket: str,
    reuse_existing: bool = True,
    execution_role_arn: Optional[str] = None,
    johnsnowlabs_version: str = DEFAULT_JOHNSNOWLABS_VERSION,
    json_license_path: Optional[str] = None,
):
    image_to_use = ""
    image_tag = f"v{DEFAULT_JOHNSNOWLABS_VERSION}"

    if not execution_role_arn:
        execution_role_arn = utils.get_sagemaker_execution_role()

    #######  Docker Image
    should_create_image = not reuse_existing
    image_to_use, image_tag = helper.build_ecr_image_name_with_tag(model_info)

    if not should_create_image:
        should_create_image = not utils.check_ecr_image_exists(
            image_name=image_to_use, image_tag=image_tag
        )

    if should_create_image:
        build_ecr_image(
            model_info=model_info,
            json_license_path=json_license_path,
            johnsnowlabs_version=johnsnowlabs_version,
            image_name=image_to_use,
            image_tag=image_tag,
        )

    ### Model Artifacts

    key = helper.build_model_artifacts_s3_key(model_info)

    model_artifacts_s3_path = f"s3://{s3_bucket}/{key}"
    should_upload_model_artifacts = not reuse_existing

    if not should_upload_model_artifacts:
        should_upload_model_artifacts = not utils.s3_object_exists(
            model_artifacts_s3_path
        )
    if should_upload_model_artifacts:

        model_artifacts_path = download_model(model_info)
        model_artifacts_path = utils.create_model_tarball(model_artifacts_path)
        utils.upload_model_to_s3(
            file_path=model_artifacts_path,
            bucket_name=s3_bucket,
            s3_key=key,
        )

    ## TODO: Use model_info.example for create input data
    should_upload_validation_data = not reuse_existing

    input_validation_data_s3_path = f"s3://{s3_bucket}/validation_data/{model_info.key}/validation-input/input1.json"
    if not should_upload_model_artifacts:
        should_upload_model_artifacts = not utils.s3_object_exists(
            input_validation_data_s3_path
        )

    if should_upload_validation_data:
        input_validation_data_s3_path = helper.upload_validation_data_to_s3(
            # todo: use model_info.example to prepare input_data
            input_data={
                "text": "Patient Name: Samantha JohnsonAge: 52Gender: FemalePatient Info:Name: Samantha JohnsonAge: 52Gender: FemaleMedical History:Patient has a history of Chronic respiratory disease.Clinical History:Patient presented with shortness of breath and chest pain.Chief Complaint:Patient complained of chest pain and difficulty breathing.History of Present Illness:Patient has been experiencing chest pain and shortness of breath for the past week. Symptoms were relieved by medication at first but became worse over time.Past Medical History:Patient has a history of Asthma and was previously diagnosed with Bronchitis.Medications:Patient is currently taking Albuterol, Singulair, and Advair for respiratory issues.Allergies:Patient has a documented allergy to Penicillin.Physical Examination:Patient had diffuse wheezing and decreased breath sounds on lung auscultation. Heart rate and rhythm were regular.Laboratory Results:Pulmonary function test results showed a decrease in Forced Expiratory Volume in one second (FEV1).Imaging Studies:Chest x-ray showed bilateral infiltrates consistent with Chronic obstructive pulmonary disease (COPD).Diagnosis:The patient was diagnosed with COPD exacerbation."
            },
            file_name="input1.json",
            s3_bucket=s3_bucket,
            key_prefix=f"validation_data/{model_info.key}",
        )
    output_validation_data_s3_path = (
        f"s3://{s3_bucket}/validation_data/{model_info.key}/validation-output"
    )

    ecr_image = f"{utils.get_ecr_registry()}/{image_to_use}:{image_tag}"
    helper.create_model_package(
        model_package_name=utils.format_for_sagemaker(
            f"{model_info.key}_v{DEFAULT_JOHNSNOWLABS_VERSION}"
        ),
        model_description=f"{model_info.model_id} ({model_info.language}) - SageMaker Marketplace",
        docker_image_arn=ecr_image,
        execution_role_arn=execution_role_arn,
        validation_input_json_path=input_validation_data_s3_path,
        validation_output_json_path=output_validation_data_s3_path,
        model_artifacts_s3_path=model_artifacts_s3_path,
    )
