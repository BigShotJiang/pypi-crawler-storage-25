from typing import Optional

from endpoints import Platform


def run_local(
    model_id: str,
    language: str,
    platform: Platform,
    port: int = 8080,
    api_server_count: Optional[int] = None,
    load_from_disk: bool = False,
) -> None:
    """Run a model locally using the endpoints server.

    Args:
        model_id: Identifier of the model to run.
        language: Language key used to resolve the model.
        platform: Platform configuration used for local serving.
        port: Port number for the local server.
        api_server_count: Number of API workers to start.

    Returns:
        None
    """
    from endpoints.core import ModelRegistry
    from endpoints.server import serve, setup_env

    model = ModelRegistry.find(model_id, language)
    setup_env(model=model, platform=platform, store_model=load_from_disk)

    serve(model=model, platform=platform, port=port, workers=api_server_count)
