from http import HTTPStatus

from fastapi import Depends, HTTPException, Request

from endpoints.core.models.base import BaseModel
from endpoints.johnsnowlabs import is_base_visual_nlp_model, is_visual_nlp_model


def get_serving_model(request: Request) -> BaseModel:
    """Return the serving model from application state.

    Args:
        request: FastAPI request carrying application state.

    Returns:
        The model instance stored in the app state.
    """
    return request.app.state.model_info.model


def enforce_content_type(request: Request) -> str:
    """Validate the request content type against allowed types.

    Args:
        request: FastAPI request with headers and application state.

    Returns:
        The normalized content type from the request.

    Raises:
        HTTPException: When the content type is not allowed.
    """
    content_type = request.headers.get("content-type", "application/json").split(";")[0]
    state = request.app.state
    allowed_content_types = list(getattr(state, "allowed_content_types", []))

    if content_type not in allowed_content_types:
        raise HTTPException(
            status_code=HTTPStatus.UNSUPPORTED_MEDIA_TYPE,
            detail=(
                "Invalid Content-Type. Supported Content-Types: "
                f"{', '.join(allowed_content_types)}"
            ),
        )
    return content_type


def get_mime_type(
    request: Request,
    model: BaseModel = Depends(get_serving_model),
) -> str:
    """Resolve and validate the response MIME type.

    Args:
        request: FastAPI request containing the Accept header.
        model: Serving model dependency.

    Returns:
        The selected MIME type for the response.

    Raises:
        HTTPException: When the requested MIME type is not acceptable.
    """

    requested_mime_type = request.headers.get("accept", "").split(",")[0]
    if requested_mime_type == "*/*":
        requested_mime_type = "application/json"

    # Special handling for base VisualNlpModel. It can only send json as output
    if is_base_visual_nlp_model(model) and requested_mime_type != "application/json":
        raise HTTPException(status_code=HTTPStatus.NOT_ACCEPTABLE)

    allowed_mime_types = request.app.state.allowed_mime_types
    if requested_mime_type not in allowed_mime_types:
        raise HTTPException(status_code=HTTPStatus.NOT_ACCEPTABLE)
    return requested_mime_type


async def parse_multi_modal_input(
    request: Request, content_type=Depends(enforce_content_type)
):
    """Parse request input using the configured strategies.

    Args:
        request: FastAPI request containing the input payload.
        content_type: Validated content type dependency.

    Returns:
        Parsed input payload based on model type and content type.

    Raises:
        HTTPException: When parsing fails.
    """
    state = request.app.state
    key = "text"

    if is_visual_nlp_model(state.model_info.model):
        key = "visual"

    strategies = request.app.state.input_parser_strategies

    try:
        parsed_input = await strategies[key][content_type](
            request=request, content_type=content_type
        )

        return parsed_input
    except:
        raise HTTPException(status_code=HTTPStatus.BAD_REQUEST)
