from typing import Dict, List

from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import expr
from typing_extensions import override

from .med_nlp import MedNlpModel


class ExtractClinicalDocSODHSmall(MedNlpModel):
    """
    Identify socio-environmental health determinants
    """

    @override
    def process_pretrained_pipeline_results(
        self, inputs: List[str], results: DataFrame, params: Dict
    ) -> List:
        """Convert Spark pipeline results prediction results

        Overrides base class implementation.

        Args:
            inputs: Input texts corresponding to each pipeline result.
            results: Spark DataFrame containing de-identification annotations.
            params: Per-input parameters

        Returns:
            List[str]: List of prediction dict
        """
        df = results.select(
            expr("sdoh_chunk.result").alias("ner_chunk"),
            expr("sdoh_chunk.begin").alias("ner_begin"),
            expr("sdoh_chunk.end").alias("ner_end"),
            expr("transform(sdoh_chunk.metadata, x -> x['entity'])").alias("ner_label"),
            expr("transform(sdoh_chunk.metadata, x -> x['confidence'])").alias(
                "ner_confidence"
            ),
            expr("transform(assertion.metadata, x -> x['ner_chunk'])").alias(
                "assertion_ner_chunk"
            ),
            expr("assertion.begin").alias("assertion_begin"),
            expr("assertion.end").alias("assertion_end"),
            expr("transform(assertion.metadata, x -> x['ner_label'])").alias(
                "assertion_ner_label"
            ),
            expr("assertion.result").alias("assertion_result"),
            expr("transform(assertion.metadata, x -> x['confidence'])").alias(
                "assertion_confidence"
            ),
            expr("relations.result").alias("relation"),
            expr("transform(relations.metadata, x -> x['confidence'])").alias(
                "relation_confidence"
            ),
            expr("transform(relations.metadata, x -> x['chunk1'])").alias(
                "relation_ner_chunk1"
            ),
            expr("transform(relations.metadata, x -> x['entity1'])").alias(
                "relation_ner_label1"
            ),
            expr("transform(relations.metadata, x -> x['entity1_begin'])").alias(
                "relation_ner_chunk1_begin"
            ),
            expr("transform(relations.metadata, x -> x['entity1_end'])").alias(
                "relation_ner_chunk1_end"
            ),
            expr("transform(relations.metadata, x -> x['chunk2'])").alias(
                "relation_ner_chunk2"
            ),
            expr("transform(relations.metadata, x -> x['entity2'])").alias(
                "relation_ner_label2"
            ),
            expr("transform(relations.metadata, x -> x['entity2_begin'])").alias(
                "relation_ner_chunk2_begin"
            ),
            expr("transform(relations.metadata, x -> x['entity2_end'])").alias(
                "relation_ner_chunk2_end"
            ),
        )

        pdf = df.toPandas()

        # Extract NER results
        ner_results = pdf.apply(
            lambda row: [
                dict(
                    ner_chunk=row["ner_chunk"][i],
                    begin=row["ner_begin"][i],
                    end=row["ner_end"][i],
                    ner_label=row["ner_label"][i],
                    ner_confidence=row["ner_confidence"][i],
                )
                for i in range(len(row["ner_chunk"]))
            ],
            axis=1,
        ).tolist()

        # Extract assertion results
        assertion_results = pdf.apply(
            lambda row: [
                dict(
                    ner_chunk=row["assertion_ner_chunk"][i],
                    begin=row["assertion_begin"][i],
                    end=row["assertion_end"][i],
                    ner_label=row["assertion_ner_label"][i],
                    assertion=row["assertion_result"][i],
                    assertion_confidence=row["assertion_confidence"][i],
                )
                for i in range(len(row["assertion_result"]))
            ],
            axis=1,
        ).tolist()

        # Extract relational results
        relational_results = pdf.apply(
            lambda row: [
                dict(
                    ner_chunk1=row["relation_ner_chunk1"][i],
                    ner_chunk1_begin=row["relation_ner_chunk1_begin"][i],
                    ner_chunk1_end=row["relation_ner_chunk1_end"][i],
                    ner_label1=row["relation_ner_label1"][i],
                    ner_chunk2=row["relation_ner_chunk2"][i],
                    ner_chunk2_begin=row["relation_ner_chunk2_begin"][i],
                    ner_chunk2_end=row["relation_ner_chunk2_end"][i],
                    ner_label2=row["relation_ner_label2"][i],
                    relation=row["relation"][i],
                    relation_confidence=row["relation_confidence"][i],
                )
                for i in range(len(row["relation"]))
            ],
            axis=1,
        ).tolist()

        return self.post_process(
            {
                "ner_results": ner_results,
                "assertion_results": assertion_results,
                "relational_results": relational_results,
            }
        )

    @override
    def process_light_pipeline_results(
        self, inputs: List[str], results: List, params: Dict
    ) -> List:
        """Convert light pipeline results into prediction results

        Overrides base class implementation.

        Args:
            inputs: Input texts corresponding to each pipeline result.
            results: Light pipeline outputs for each input.
            params: Per-input parameters

        Returns:
            List[str]: List of prediction dict
        """
        ner_results = []
        relational_results = []
        assertion_results = []

        for prediction in results:
            ner_results.append(
                [
                    {
                        "ner_chunk": chunk.result,
                        "begin": chunk.begin,
                        "end": chunk.end,
                        "ner_label": chunk.metadata["entity"],
                        "ner_confidence": chunk.metadata["confidence"],
                    }
                    for chunk in prediction["sdoh_chunk"]
                ]
            )

            assertion_results.append(
                [
                    {
                        "ner_chunk": assertion.metadata["ner_chunk"],
                        "begin": assertion.begin,
                        "end": assertion.end,
                        "ner_label": assertion.metadata["ner_label"],
                        "assertion": assertion.result,
                        "assertion_confidence": assertion.metadata["confidence"],
                    }
                    for assertion in prediction["assertion"]
                ]
            )

            relational_results.append(
                [
                    {
                        "ner_chunk1": relations.metadata["chunk1"],
                        "ner_chunk1_begin": relations.metadata["entity1_begin"],
                        "ner_chunk1_end": relations.metadata["entity1_end"],
                        "ner_label1": relations.metadata["entity1"],
                        "ner_chunk2": relations.metadata["chunk2"],
                        "ner_chunk2_begin": relations.metadata["entity2_begin"],
                        "ner_chunk2_end": relations.metadata["entity2_end"],
                        "ner_label2": relations.metadata["entity2"],
                        "relation": relations.result,
                        "relation_confidence": relations.metadata["confidence"],
                    }
                    for relations in prediction["relations"]
                ]
            )

            return self.post_process(
                {
                    "ner_results": ner_results,
                    "assertion_results": assertion_results,
                    "relational_results": relational_results,
                }
            )

    def post_process(self, prediction_results: dict) -> List:
        """Process prediction results output to match expected format.

        Args:
            prediction_results (dict): Prediction results.
        Returns:
            List: Prediction results.
        """
        result_list = list()
        for idx in range(len(prediction_results["ner_results"])):
            temp = dict()
            temp["ner_predictions"] = prediction_results["ner_results"][idx]
            temp["relation_predictions"] = prediction_results["relational_results"][idx]
            temp["assertion_predictions"] = prediction_results["assertion_results"][idx]
            result_list.append(temp)
        return result_list
