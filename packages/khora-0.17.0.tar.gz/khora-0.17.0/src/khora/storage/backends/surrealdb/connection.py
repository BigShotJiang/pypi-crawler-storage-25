"""SurrealDB connection manager for Khora."""

from __future__ import annotations

import asyncio
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

from loguru import logger

from ..._log_safe import _safe_url_for_log
from .._loop_lock import get_loop_lock

# Cross-instance schema-init lock keyed on the running event loop.
# The StorageCoordinator connects four SurrealDB-backed adapters in
# parallel against the same embedded DB; the lock serializes their
# DEFINE statements to avoid embedded-mode transaction conflicts.
# A plain module-level ``asyncio.Lock()`` would bind to the first loop
# that touched it, which breaks pytest-asyncio's function-scoped loops.
_SCHEMA_INIT_LOCK_NAME = "surrealdb_schema_init"


class SurrealDBConnection:
    """Manages the lifecycle of a SurrealDB client connection.

    Supports three modes:
    - memory: In-process ephemeral database (for testing)
    - embedded: File-backed persistent database (zero infrastructure)
    - remote: WebSocket connection to a SurrealDB server
    """

    def __init__(
        self,
        *,
        mode: str = "memory",
        path: str | None = None,
        url: str | None = None,
        namespace: str = "khora",
        database: str = "default",
        user: str = "root",
        password: str = "root",  # noqa: S107
        sync_data: bool = True,
    ) -> None:
        self._mode = mode
        self._path = path
        self._url = url
        self._namespace = namespace
        self._database = database
        self._user = user
        self._password = password
        self._sync_data = sync_data
        self._client: Any = None
        self._connected = False
        self._schema_initialized = False
        # Serializes concurrent disconnect() calls. The StorageCoordinator
        # calls disconnect() on all four SurrealDB adapters in parallel via
        # asyncio.gather; they all delegate to this shared connection. Without
        # serialization, four awaits race into `self._client.close()` on the
        # same client object, which (a) makes the close non-idempotent inside
        # surrealdb-py and (b) leaves pyo3 tokio worker threads in a state
        # where they can call back into Python after interpreter finalization
        # — triggering a SIGABRT/pyo3 panic that masks the user's traceback
        # (#715).
        self._close_lock: asyncio.Lock = asyncio.Lock()

        # Write semaphore for embedded/memory modes: SurrealDB's surrealkv
        # engine can panic under high concurrent HNSW index mutations.
        # Semaphore(3) allows enough parallelism for the read-modify-write
        # entity upsert pattern while preventing thundering-herd writes.
        # Combined with retry-on-conflict, this balances throughput and safety.
        # Remote mode doesn't need this — the server serializes internally.
        self._write_sem: asyncio.Semaphore | None = asyncio.Semaphore(3) if mode in ("embedded", "memory") else None

        if not sync_data:
            logger.warning("SurrealDB running without sync_data — data may be lost on crash")

    @property
    def connected(self) -> bool:
        return self._connected

    @property
    def client(self) -> Any:
        return self._client

    def _build_endpoint(self) -> str:
        if self._mode == "memory":
            return "memory://default"
        if self._mode == "embedded":
            if not self._path:
                raise ValueError("SurrealDB embedded mode requires 'path' to be set")
            return f"surrealkv://{self._path}"
        if self._mode == "remote":
            if not self._url:
                raise ValueError("SurrealDB remote mode requires 'url' to be set")
            return self._url
        raise ValueError(f"Unknown SurrealDB mode: {self._mode}")

    async def connect(self) -> None:
        if self._connected:
            return

        if self._sync_data:
            os.environ["SURREAL_SYNC_DATA"] = "true"

        import surrealdb

        endpoint = self._build_endpoint()
        logger.info(f"Connecting to SurrealDB ({self._mode}): {_safe_url_for_log(endpoint)}")
        # Use getattr to create the client so ty does not infer the union
        # return type of AsyncSurreal() (whose HTTP variant .connect(url)
        # has a required url param that conflicts with the WS variant).
        factory = getattr(surrealdb, "AsyncSurreal")
        self._client = factory(endpoint)
        await self._client.connect()
        await self._client.use(self._namespace, self._database)
        # Embedded/memory modes don't have a root user — only sign in for remote
        if self._mode == "remote":
            await self._client.signin({"username": self._user, "password": self._password})
        self._connected = True
        logger.info(f"Connected to SurrealDB ({self._mode}), ns={self._namespace}, db={self._database}")

        # Auto-initialize schema (idempotent, skipped on reconnect).
        # The lock prevents concurrent connections from running DEFINE
        # statements in parallel, which causes SurrealDB transaction
        # conflicts on embedded mode.
        if not self._schema_initialized:
            async with get_loop_lock(_SCHEMA_INIT_LOCK_NAME):
                if not self._schema_initialized:
                    from .schema import initialize_schema

                    await initialize_schema(self)
                    self._schema_initialized = True

    async def disconnect(self) -> None:
        # Serialize concurrent disconnects from the four SurrealDB adapters
        # that share this connection. Flip `_connected` before awaiting close
        # so any caller blocked on the lock sees the connection as already
        # closed and skips the second close() entirely. Awaiting close() to
        # completion (rather than letting it run after the GIL release) is
        # what prevents the surrealdb-py tokio worker from calling back into
        # Python after interpreter finalization — the SIGABRT/pyo3 panic
        # reported in #715.
        async with self._close_lock:
            if not (self._client and self._connected):
                return
            client = self._client
            self._connected = False
            self._client = None
            try:
                await client.close()
            except Exception as exc:  # noqa: BLE001
                # Log at warning rather than debug: a close failure that
                # leaves tokio workers alive is exactly the precondition for
                # the #715 SIGABRT, so operators need to see it.
                logger.warning("SurrealDB client close raised during disconnect: {}", exc)
            logger.info("Disconnected from SurrealDB")

    async def is_healthy(self) -> bool:
        if not self._connected or not self._client:
            return False
        try:
            result = await self._client.query("RETURN 1")
            return result is not None
        except Exception:
            return False

    _WRITE_CONFLICT_MSG = "read or write conflict"
    _MAX_CONFLICT_RETRIES = 5
    _CONFLICT_BASE_DELAY = 0.05  # 50ms, doubles each retry

    async def _execute_raw(self, sql: str, bindings: dict[str, Any] | None = None) -> Any:
        """Execute a SurrealQL statement with write serialization and retry.

        For embedded/memory modes, acquires a semaphore to prevent concurrent
        HNSW index mutations (which cause Rust panics in surrealkv).  Also
        retries on transaction conflicts with exponential backoff.
        """
        if not self._connected:
            raise RuntimeError("SurrealDB not connected")

        async def _do_query() -> Any:
            last_err: Exception | None = None
            for attempt in range(self._MAX_CONFLICT_RETRIES):
                try:
                    return await self._client.query(sql, bindings or {})
                except Exception as e:
                    if self._WRITE_CONFLICT_MSG in str(e) and attempt < self._MAX_CONFLICT_RETRIES - 1:
                        delay = self._CONFLICT_BASE_DELAY * (2**attempt)
                        logger.debug(f"SurrealDB write conflict (attempt {attempt + 1}), retrying in {delay:.3f}s")
                        await asyncio.sleep(delay)
                        last_err = e
                    else:
                        raise
            assert last_err is not None  # guaranteed by loop with retries > 0
            raise last_err

        if self._write_sem is not None:
            async with self._write_sem:
                return await _do_query()
        return await _do_query()

    async def query(self, sql: str, bindings: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        result = await self._execute_raw(sql, bindings)
        if isinstance(result, list):
            # SurrealDB returns list of statement results; flatten
            flat: list[dict[str, Any]] = []
            for item in result:
                if isinstance(item, dict):
                    flat.append(item)
                elif isinstance(item, list):
                    flat.extend(item)
            return flat
        if isinstance(result, dict):
            return [result]
        return []

    async def query_one(self, sql: str, bindings: dict[str, Any] | None = None) -> dict[str, Any] | None:
        results = await self.query(sql, bindings)
        return results[0] if results else None

    async def execute(self, sql: str, bindings: dict[str, Any] | None = None) -> Any:
        """Execute a SurrealQL statement, returning raw result."""
        return await self._execute_raw(sql, bindings)

    # ------------------------------------------------------------------
    # Transactions (Issue #541)
    #
    # SurrealDB supports SurrealQL-level transactions via the
    # BEGIN / COMMIT / CANCEL statements. The Python client surfaces
    # these as plain queries on the WebSocket connection in remote mode.
    # surrealkv (embedded / memory) raises ``UnsupportedFeatureError`` on
    # BEGIN, so on those modes ``transaction()`` is a no-op and the
    # caller's writes proceed as ordinary statements — preserving the
    # "partial atomicity on embedded" contract documented in CLAUDE.md.
    # ------------------------------------------------------------------

    @property
    def supports_transactions(self) -> bool:
        """Return True when the active mode supports atomic multi-statement
        transactions (remote WebSocket only)."""
        return self._mode == "remote"

    @asynccontextmanager
    async def transaction(self) -> AsyncGenerator[SurrealDBConnection]:
        """Async context manager for atomic multi-statement SurrealDB ops.

        Remote mode wraps the body in ``BEGIN TRANSACTION`` /
        ``COMMIT TRANSACTION``; on exception, issues ``CANCEL TRANSACTION``
        and re-raises. Embedded / memory modes yield without issuing
        BEGIN — surrealkv doesn't support it and would raise
        ``UnsupportedFeatureError``. Callers needing per-statement
        atomicity on embedded mode should use semicolon-batched
        SurrealQL via :meth:`execute_batch`.

        Usage::

            async with conn.transaction():
                await conn.execute("CREATE entity SET name = $n", {"n": "Acme"})
                await conn.execute("RELATE $a->relates_to->$b", {...})

        On embedded / memory the writes still go through atomically per
        statement (each `execute` is its own surrealkv tx) but not
        across statements — matching the existing CLAUDE.md contract.
        """
        if not self._connected:
            raise RuntimeError("SurrealDB not connected")

        if not self.supports_transactions:
            # No-op for embedded / memory — surrealkv raises on BEGIN.
            yield self
            return

        await self._execute_raw("BEGIN TRANSACTION;")
        try:
            yield self
        except Exception:
            try:
                await self._execute_raw("CANCEL TRANSACTION;")
            except Exception as cancel_exc:  # noqa: BLE001
                logger.warning("SurrealDB CANCEL TRANSACTION failed: {}", cancel_exc)
            raise
        else:
            await self._execute_raw("COMMIT TRANSACTION;")

    async def execute_batch(
        self,
        statements: list[tuple[str, dict[str, Any] | None]],
    ) -> list[Any]:
        """Execute multiple SurrealQL statements in a single round-trip.

        On embedded / memory modes this is the closest analogue to a
        transaction: surrealkv applies all statements as one batch and
        the engine's snapshot isolation means partial visibility is
        bounded to the batch. On remote mode, prefer :meth:`transaction`
        — it gives true atomicity across statements.

        The Python client doesn't natively expose batch execution, so we
        concatenate statements with ``;`` and rely on SurrealQL's
        statement-separator semantics. Each statement may carry its own
        parameter dict; we merge them keyed by parameter name, raising on
        collision so callers can rename rather than silently overwrite.
        """
        if not self._connected:
            raise RuntimeError("SurrealDB not connected")
        if not statements:
            return []

        joined_sql_parts: list[str] = []
        merged_bindings: dict[str, Any] = {}
        for sql, bindings in statements:
            joined_sql_parts.append(sql.strip().rstrip(";"))
            if bindings:
                for k, v in bindings.items():
                    if k in merged_bindings and merged_bindings[k] != v:
                        raise ValueError(
                            f"execute_batch: parameter {k!r} conflicts between statements; rename one of them"
                        )
                    merged_bindings[k] = v
        joined_sql = ";\n".join(joined_sql_parts) + ";"
        result = await self._execute_raw(joined_sql, merged_bindings)
        # SurrealDB returns a list of per-statement results.
        return result if isinstance(result, list) else [result]
