"""Apophatic Guard — deterministic in/out-of-scope detection (Day 9 — full routing)"""
import json
import re
from pathlib import Path
from rapidfuzz import fuzz

# ─── Paths ─────────────────────────────────────────────────────────────
# citations.json ships inside the package so it survives wheel/sdist install.
# v0.1.3 fix: previously at src/citations.json (outside the package) — wheel
# omitted it and uvx/pip installs crashed with FileNotFoundError on import.
CITATIONS_PATH = Path(__file__).parent / "citations.json"

with open(CITATIONS_PATH, "r", encoding="utf-8") as f:
    CITATIONS = json.load(f)

# ─── Refusal Templates (apophatic discipline — no unsubstituted placeholders) ──
# Soul.md grammar preserved. [citation] + [URL] in below_confidence ARE substituted
# at the call site; the rest are now self-contained, no leak risk.
REFUSAL_TEMPLATES = {
    "out_of_scope":      "That's outside FAF. I cover the .faf format, scoring, IANA registration, and the FAF Family. Your IDE's docs or community will serve you better for other topics.",
    "below_confidence":  "Confidence is below threshold. Closest match: [citation]. For verification: [URL].",
    "not_in_corpus":     "Not documented in current FAF specs. Filing as a candidate spec extension.",
    "opinion":           "I don't carry opinions outside FAF. The spec defines what FAF is and isn't — that's all I can speak to.",
}

# ─── Opinion Patterns (compiled once at load) ──────────────────────────
OPINION_PATTERNS = [
    re.compile(r"\bdo you think\b", re.IGNORECASE),
    re.compile(r"\bdo you prefer\b", re.IGNORECASE),
    re.compile(r"\bdo you like\b", re.IGNORECASE),
    re.compile(r"\bin your opinion\b", re.IGNORECASE),
    re.compile(r"\bwhat.{0,15}your opinion\b", re.IGNORECASE),
    re.compile(r"\bwould you (recommend|suggest|prefer)\b", re.IGNORECASE),
    re.compile(r"\bis .{1,40} better than\b", re.IGNORECASE),
    re.compile(r"\bshould (i|we) use\b", re.IGNORECASE),
]

# ─── FAF Keywords (for not_in_corpus routing) ──────────────────────────
FAF_KEYWORDS = [
    ".faf", ".fafm", ".fafb", "fafm", "fafb",
    "faf format", "faf spec", "mk4", "scoring algorithm",
    "vnd.faf", "iana-registered"
]


# ─── Core Guard Logic ──────────────────────────────────────────────────
def apophatic_guard(query: str, threshold: float = 75.0) -> dict:
    """Return guard result with full 4-template routing."""
    tokens = query.split()
    token_count = len(tokens)

    # 1. Short bypass (≤4 tokens)
    if token_count <= 4:
        return {"allowed": True}

    query_lower = query.lower()

    # 2. Opinion check (highest priority after short bypass)
    for pattern in OPINION_PATTERNS:
        if pattern.search(query):
            return {
                "allowed": False,
                "refusal_type": "opinion",
                "message": REFUSAL_TEMPLATES["opinion"]
            }

    # 3. Fuzzy match against citations.json
    best_score = 0.0
    best_match = None

    for entry in CITATIONS:
        score = fuzz.partial_ratio(query_lower, entry["pattern"].lower())
        if score > best_score:
            best_score = score
            best_match = entry

    # 4. Routing — note: below_confidence + not_in_corpus require FAF_KEYWORDS;
    # otherwise spurious fuzzy partial-ratio scores (e.g., "translate to French"
    # scoring 61 against "6. Core Operations") would route to below_confidence
    # incorrectly. has_faf_keyword gates "is this FAF-shaped at all?" before
    # the score-based routing.
    has_faf_keyword = any(kw in query_lower for kw in FAF_KEYWORDS)

    if best_score >= threshold and best_match:
        return {
            "allowed": True,
            "citation": best_match["section"],
            "url": best_match["url"],
            "confidence": best_match["confidence"],
            "score": best_score
        }

    elif has_faf_keyword:
        if best_score >= 50 and best_match:
            # FAF-shaped query, partial fuzzy match — below confidence
            return {
                "allowed": False,
                "refusal_type": "below_confidence",
                "message": REFUSAL_TEMPLATES["below_confidence"]
                    .replace("[citation]", best_match["section"])
                    .replace("[URL]", best_match["url"]),
                "closest_match": best_match["section"],
                "url": best_match["url"],
                "score": best_score
            }
        else:
            # FAF-shaped query but no real pattern hit
            return {
                "allowed": False,
                "refusal_type": "not_in_corpus",
                "message": REFUSAL_TEMPLATES["not_in_corpus"]
            }

    else:
        # Not FAF-shaped at all
        return {
            "allowed": False,
            "refusal_type": "out_of_scope",
            "message": REFUSAL_TEMPLATES["out_of_scope"],
        }
