"""FAF-RAG Client — xAI Grok Collections + Mock for tests"""
import os
from typing import Protocol
from pathlib import Path


# ─── Protocol ──────────────────────────────────────────────────────────
class RAGClient(Protocol):
    def retrieve(self, query: str) -> dict:
        """Returns dict: passages, answer, found, plus optional citation/url/confidence.

        Citation/url/confidence are best-effort. When the client cannot extract
        a reliable citation from the LLM response, it returns empty strings;
        server.py falls back to the apophatic guard's match.
        """
        ...


# ─── Real Client (xAI Grok Collections) ────────────────────────────────
class XAIFAFRAGClient:
    """Real RAG client using xAI Grok Collections.

    Reads XAI_API_KEY from env. Uses collection_becf059f-7896-4a32-bb3b-14b4dbec4b04
    (matches xai-faf-rag demo). System prompt = Soul.md verbatim.
    """

    COLLECTION_ID = "collection_becf059f-7896-4a32-bb3b-14b4dbec4b04"

    def __init__(self):
        # Lazy import — only fail at construction (when XAI_API_KEY is present).
        # Avoids xai-sdk being a hard import requirement when MockRAGClient suffices.
        from xai_sdk import Client
        self._Client = Client
        self.client = Client(api_key=os.getenv("XAI_API_KEY"))
        # Load Soul.md as system prompt (ships inside package — v0.1.4 fix)
        soul_path = Path(__file__).parent / "Soul.md"
        with open(soul_path, "r", encoding="utf-8") as f:
            self.system_prompt = f.read().strip()

    def retrieve(self, query: str) -> dict:
        from xai_sdk.chat import user, system
        from xai_sdk.tools import collections_search
        try:
            chat = self.client.chat.create(
                model="grok-4-fast",
                messages=[
                    system(self.system_prompt),
                    user(query)
                ],
                tools=[collections_search(
                    collection_ids=[self.COLLECTION_ID],
                    retrieval_mode="hybrid"
                )],
                max_tokens=500
            )
            answer = chat.sample().content

            # Citation/url left empty — server.py falls back to apophatic guard's
            # match (which has accurate section + url for the matched pattern).
            # Future v0.1.x: parse LLM output for explicit citation if model
            # cites a section name. For v0.1.0 the guard's citation is canonical.
            return {
                "passages": [answer],
                "answer": answer,
                "citation": "",
                "url": "",
                "confidence": 0.0,
                "found": True
            }
        except Exception as e:
            return {
                "passages": [],
                "answer": "",
                "citation": "",
                "url": "",
                "confidence": 0.0,
                "found": False,
                "error": str(e)
            }


# ─── Mock Client (for tests, no API key needed) ────────────────────────
class MockRAGClient:
    """Mock RAG client for testing — no network, no API key required."""

    def __init__(self, found: bool = True, answer: str | None = None):
        self.found = found
        self.answer = answer or "Mock passage about FAF format and structure."

    def retrieve(self, query: str) -> dict:
        if not self.found:
            return {
                "passages": [],
                "answer": "",
                "citation": "",
                "url": "",
                "confidence": 0.0,
                "found": False
            }

        return {
            "passages": [self.answer],
            "answer": self.answer,
            "citation": "Overview",
            "url": "https://github.com/Wolfe-Jam/faf/blob/main/SPECIFICATION.md#overview",
            "confidence": 0.85,
            "found": True
        }


# ─── Client Selector ───────────────────────────────────────────────────
def get_rag_client() -> RAGClient:
    """Returns real client if XAI_API_KEY is set, else Mock.

    Module-level `rag_client` is created at import time based on then-current env.
    Tests can monkeypatch `faf_agent_mcp.server.rag_client` directly to inject
    a different mock without setting env vars.
    """
    if os.getenv("XAI_API_KEY"):
        return XAIFAFRAGClient()
    return MockRAGClient()


# Module-level instance (patchable in tests)
rag_client = get_rag_client()
