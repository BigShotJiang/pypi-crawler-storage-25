"""FAF Agent MCP Server"""
__version__ = "0.1.4"
