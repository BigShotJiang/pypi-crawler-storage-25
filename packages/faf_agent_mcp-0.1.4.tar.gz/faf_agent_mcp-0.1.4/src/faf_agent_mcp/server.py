"""FAF Agent MCP Server — FastMCP implementation"""
from fastmcp import FastMCP
from pathlib import Path
from . import __version__
from .apophatic import apophatic_guard, REFUSAL_TEMPLATES, CITATIONS
from rapidfuzz import fuzz
from .wasm_bridge import validate_faf as wasm_validate, score_faf as wasm_score
from .rag_client import rag_client
from .mcpaas_client import mcpaas_client


# Load Soul.md verbatim. Ships inside the package via hatch force-include
# so wheel/sdist install reaches it. (Dev mode also has it here because
# pyproject.toml force-include copies the repo-root Soul.md at build time;
# in editable installs hatchling symlinks, in `pip install .` it copies.)
# v0.1.4 fix: previously read from `Path(__file__).parent.parent.parent`
# which resolved outside the installed package and broke `uvx faf-agent-mcp`.
SOUL_PATH = Path(__file__).parent / "Soul.md"
with open(SOUL_PATH, "r", encoding="utf-8") as f:
    SOUL_PROMPT = f.read().strip()


def build_system_prompt() -> str:
    """Return the canonical system prompt: Soul.md verbatim.

    Day 10 may extend this with runtime context (e.g., current date)
    above the LLM call. Day 8 keeps it dumb: Soul.md verbatim.
    """
    return SOUL_PROMPT


mcp = FastMCP(
    "faf-agent-mcp",
    version=__version__,
    instructions=SOUL_PROMPT
)


@mcp.tool()
def validate_faf(path: str) -> dict:
    """Validate a .faf file (deterministic path)."""
    return wasm_validate(path)


@mcp.tool()
def score_faf(path: str) -> dict:
    """Score a .faf file using Mk4 (deterministic path)."""
    return wasm_score(path)


@mcp.tool()
def ask(query: str) -> dict:
    """Answer a question about FAF with mandatory citation + real RAG.

    Day 10 enforcement: rag_client.retrieve() returns passages.
    If RAG returns no match, fall through to below_confidence refusal.
    Citation comes from RAG if provided, else from apophatic guard.
    """
    guard = apophatic_guard(query)

    if not guard["allowed"]:
        return {
            "refusal": guard["message"],
            "refusal_type": guard.get("refusal_type", "out_of_scope")
        }

    # Real RAG call (or Mock if no API key)
    result = rag_client.retrieve(query)

    if not result.get("found") or not result.get("passages"):
        return {
            "refusal": REFUSAL_TEMPLATES["below_confidence"]
                .replace("[citation]", guard.get("citation", "no closest match"))
                .replace("[URL]", guard.get("url", "")),
            "refusal_type": "below_confidence",
            "telemetry_note": "rag_no_match"
        }

    # Citation: prefer RAG's, fall back to apophatic guard's match
    response = {
        "answer": result.get("answer", " | ".join(result.get("passages", []))),
        "citation": result.get("citation") or guard.get("citation"),
        "url": result.get("url") or guard.get("url"),
        "confidence": result.get("confidence") or guard.get("confidence", 0.0)
    }

    # Final citation enforcement (Day 8 path preserved)
    if not response.get("citation") or response["citation"] in (None, "", "N/A"):
        return {
            "refusal": REFUSAL_TEMPLATES["out_of_scope"],
            "refusal_type": "out_of_scope",
            "telemetry_note": "no_citation_available"
        }

    return response


@mcp.tool()
def cite(topic: str) -> dict:
    """Return spec section for a topic.

    Day 8 enforcement: every successful response includes a `section` field.
    Missing section → fall back to a relaxed fuzzy match at threshold 65
    (one v0.1.1 audit finding: cite("FAF format overview") was being refused
    because short-bypass returned allowed-without-citation). Still missing
    after fallback → fall through to out_of_scope refusal template.
    """
    guard = apophatic_guard(topic)

    if not guard["allowed"]:
        return {
            "refusal": guard["message"],
            "refusal_type": guard.get("refusal_type", "out_of_scope")
        }

    response = {
        "section": guard.get("citation", "N/A"),
        "url": guard.get("url", "N/A"),
        "confidence": guard.get("confidence", 0.0)
    }

    # Cite-specific fallback (v0.1.1): when guard allowed but no citation
    # (e.g., 3-token query like "FAF format overview" hit the short bypass),
    # try a relaxed fuzzy match at threshold 65 to find a reasonable section.
    # This widens cite() coverage without affecting ask() or the apophatic
    # guard's own routing.
    if response["section"] in (None, "", "N/A"):
        topic_lower = topic.lower()
        best_score = 0.0
        best_match = None
        for entry in CITATIONS:
            score = fuzz.partial_ratio(topic_lower, entry["pattern"].lower())
            if score > best_score:
                best_score = score
                best_match = entry
        if best_score >= 65 and best_match:
            response = {
                "section": best_match["section"],
                "url": best_match["url"],
                "confidence": best_match["confidence"] * (best_score / 100.0),
                "match_score": best_score,
                "fallback": True,
            }

    # Citation enforcement (Day 8) — final guard if both paths failed
    if not response.get("section") or response["section"] in (None, "", "N/A"):
        return {
            "refusal": REFUSAL_TEMPLATES["out_of_scope"],
            "refusal_type": "out_of_scope",
            "telemetry_note": "no_citation_available"
        }

    return response


@mcp.tool()
async def etch_memory(namepoint: str, content: str, tags: list[str] | None = None) -> dict:
    """Write a memory entry to a namepoint's soul on mcpaas.live.

    Forwards to write_soul on mcpaas.live/mcp. Requires MCPAAS_API_KEY env var
    for production use; the Mock client (no key) returns ok with in-memory state
    so tests stay deterministic.
    """
    return await mcpaas_client.etch(namepoint, content, tags=tags)


@mcp.tool()
async def recall_memory(namepoint: str, query: str = "") -> dict:
    """Recall the soul body for a namepoint, optionally filtered by query substring.

    Forwards to get_soul on mcpaas.live/mcp. `query` is a local substring filter;
    mcpaas's full-text search lives behind `search_context` and is not surfaced
    in v0.1.0 (keeping the tool surface lean — exactly six tools, the size of FAF).
    """
    return await mcpaas_client.recall(namepoint, query=query)


def main() -> None:
    """Console-script entry point (`uvx faf-agent-mcp` / `python -m faf_agent_mcp`)."""
    mcp.run()


if __name__ == "__main__":
    main()
