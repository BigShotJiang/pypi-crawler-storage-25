"""WASM Bridge — honest deferral to v0.2.0.

Per Soul.md: "If I can't cite, I don't claim." The same discipline applies
to deterministic execution: if the WASM kernel isn't wired here, this
package says so plainly and points users at the working tool (faf-cli).

The Rust IP (xai-faf-rust + faf-rust-sdk) ships the Mk4 scoring + validation
kernels. faf-cli already consumes them via wasmtime. This package will
consume the same kernel in v0.2.0; v0.1.x defers to faf-cli explicitly.
"""


def validate_faf(path: str) -> dict:
    """Validation is not implemented in v0.1.x — use faf-cli check.

    Returns a structured "not_implemented" response with explicit redirect
    so MCP clients can surface a clean message to the user instead of
    receiving placeholder data.
    """
    return {
        "status": "not_implemented",
        "available_in": "v0.2.0",
        "use_instead": "bunx faf-cli check <path>",
        "reason": (
            "Rust/WASM kernel integration deferred to v0.2.0. "
            "faf-cli ships the same Mk4 validation deterministically — "
            "use it now; this tool wires through to the same kernel in v0.2.0."
        ),
        "path_received": path,
    }


def score_faf(path: str) -> dict:
    """Scoring is not implemented in v0.1.x — use faf-cli score.

    Returns a structured "not_implemented" response with explicit redirect
    so MCP clients can surface a clean message to the user instead of
    receiving placeholder data.
    """
    return {
        "status": "not_implemented",
        "available_in": "v0.2.0",
        "use_instead": "bunx faf-cli score <path>",
        "reason": (
            "Rust/WASM kernel integration deferred to v0.2.0. "
            "faf-cli ships the same Mk4 scoring deterministically — "
            "use it now; this tool wires through to the same kernel in v0.2.0."
        ),
        "path_received": path,
    }
