"""MCPaaS Client — write_soul / get_soul over mcpaas.live/mcp + Mock for tests.

Day 13 wiring. Mirrors rag_client.py shape: Protocol + Real + Mock + selector.

The mcpaas server-side contract:
- Endpoint: https://mcpaas.live/mcp (Streamable HTTP)
- Tools: write_soul(soul, entry, type, token, tags?) + get_soul(soul)
- Auth: API key passed via the `token` field on write_soul (legacy wire name;
  read calls work without auth on public souls).

faf-agent vocabulary mapping: the public-facing parameter is `namepoint`
(matches FAF-Voice + slash-tokens vocab); the wire field on mcpaas is `soul`.
The translation is internal to this module.

v0.1.2 (2026-05-11): mcpaas-cf upstream flipped to strict-default Sessionless
MCP per SEP-2567 + SEP-2575. fastmcp.Client(URL) doesn't send the now-required
spec headers (Mcp-Method, MCP-Protocol-Version) by default. To preserve back-compat
while the ecosystem catches up, we construct an explicit StreamableHttpTransport
with `X-MCP-Mode: flexi` — opts into mcpaas-cf's co-existence mode (validate
headers when present, accept when absent). When fastmcp upstream ships full
spec-header support, this opt-in can be dropped.

Audit: PLANET-FAF/IMCP/audit-mcpaas-mcp-state-2026-05-11.md
Doctrine: memory/mcpaas-coexistence-strict-default-x-mcp-mode.md
"""
from __future__ import annotations

import os
from typing import Protocol


MCPAAS_URL = "https://mcpaas.live/mcp"

# Header for mcpaas-cf co-existence mode (Sessionless MCP toggle).
# Default mcpaas-cf behavior is 'strict' (spec-grade); 'flexi' preserves
# the fastmcp-compatible back-compat path. Inject via StreamableHttpTransport.
_MCPAAS_MODE_HEADER = {"X-MCP-Mode": "flexi"}


# ─── Protocol ──────────────────────────────────────────────────────────
class MCPaaSClient(Protocol):
    async def etch(self, namepoint: str, content: str, *, tags: list[str] | None = None) -> dict:
        """Append an entry to the namepoint's soul. Returns server confirmation."""
        ...

    async def recall(self, namepoint: str, query: str = "") -> dict:
        """Read the namepoint's soul body. `query` is local-filter only (not server-side)."""
        ...


# ─── Real Client (fastmcp over Streamable HTTP) ────────────────────────
class RealMCPaaSClient:
    """Live MCPaaS client. Reads MCPAAS_API_KEY from env or constructor arg."""

    def __init__(self, api_key: str | None = None, mcp_url: str = MCPAAS_URL):
        self._api_key = api_key or os.getenv("MCPAAS_API_KEY")
        self._mcp_url = mcp_url

    async def etch(
        self,
        namepoint: str,
        content: str,
        *,
        tags: list[str] | None = None,
        entry_type: str = "note",
    ) -> dict:
        if not self._api_key:
            return {
                "status": "error",
                "error": "MCPAAS_API_KEY not set — etch requires a Voice API key",
            }

        from fastmcp import Client
        from fastmcp.client.transports import StreamableHttpTransport
        from fastmcp.exceptions import ToolError

        args: dict = {
            "soul": namepoint,
            "entry": content,
            "type": entry_type,
            "token": self._api_key,
        }
        if tags:
            args["tags"] = tags

        # v0.1.2: explicit transport with X-MCP-Mode: flexi (opts into mcpaas-cf
        # co-existence mode; preserves fastmcp back-compat against strict-default upstream).
        transport = StreamableHttpTransport(url=self._mcp_url, headers=_MCPAAS_MODE_HEADER)
        try:
            async with Client(transport) as client:
                result = await client.call_tool("write_soul", args)
                text = _first_text(result)
            return {"status": "ok", "namepoint": namepoint, "message": text}
        except ToolError as e:
            return {"status": "error", "error": f"etch failed: {e}"}
        except Exception as e:
            return {"status": "error", "error": f"etch transport error: {e}"}

    async def recall(self, namepoint: str, query: str = "") -> dict:
        from fastmcp import Client
        from fastmcp.client.transports import StreamableHttpTransport
        from fastmcp.exceptions import ToolError

        # v0.1.2: explicit transport with X-MCP-Mode: flexi (see etch() above).
        transport = StreamableHttpTransport(url=self._mcp_url, headers=_MCPAAS_MODE_HEADER)
        try:
            async with Client(transport) as client:
                result = await client.call_tool("get_soul", {"soul": namepoint})
                body = _first_text(result)
        except ToolError as e:
            return {"status": "error", "error": f"recall failed: {e}"}
        except Exception as e:
            return {"status": "error", "error": f"recall transport error: {e}"}

        # Local query filter — pure substring scan over body lines.
        # mcpaas's search_context tool does server-side full-text but for v0.1.0
        # the agent surface stays minimal: full body or filtered body.
        if query:
            lines = [ln for ln in body.splitlines() if query.lower() in ln.lower()]
            body = "\n".join(lines)

        return {"status": "ok", "namepoint": namepoint, "body": body}


# ─── Mock Client (in-memory dict, for tests) ───────────────────────────
class MockMCPaaSClient:
    """In-memory mock — no network. Each instance is its own store."""

    def __init__(self):
        self._store: dict[str, list[str]] = {}

    async def etch(
        self,
        namepoint: str,
        content: str,
        *,
        tags: list[str] | None = None,
        entry_type: str = "note",
    ) -> dict:
        self._store.setdefault(namepoint, []).append(content)
        return {
            "status": "ok",
            "namepoint": namepoint,
            "message": f"etched to {namepoint} (mock)",
        }

    async def recall(self, namepoint: str, query: str = "") -> dict:
        entries = self._store.get(namepoint, [])
        body = "\n".join(entries)
        if query:
            body = "\n".join(ln for ln in body.splitlines() if query.lower() in ln.lower())
        return {"status": "ok", "namepoint": namepoint, "body": body}


# ─── Client Selector ───────────────────────────────────────────────────
def get_mcpaas_client() -> MCPaaSClient:
    """Returns Real client when MCPAAS_API_KEY is set, else Mock.

    Mirrors get_rag_client(): module-level instance is created at import.
    Tests can monkeypatch faf_agent_mcp.server.mcpaas_client directly.
    """
    if os.getenv("MCPAAS_API_KEY"):
        return RealMCPaaSClient()
    return MockMCPaaSClient()


# Module-level instance (patchable in tests)
mcpaas_client = get_mcpaas_client()


# ─── Helpers ───────────────────────────────────────────────────────────
def _first_text(result) -> str:
    """Extract the first text payload from a fastmcp CallToolResult."""
    content = getattr(result, "content", None)
    if isinstance(content, list) and content:
        first = content[0]
        text = getattr(first, "text", None)
        if isinstance(text, str):
            return text
    return str(content)
