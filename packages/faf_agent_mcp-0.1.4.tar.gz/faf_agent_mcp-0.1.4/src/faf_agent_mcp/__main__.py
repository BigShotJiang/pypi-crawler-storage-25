"""Module entry point: `python -m faf_agent_mcp` → faf_agent_mcp.server:main."""
from .server import main

if __name__ == "__main__":
    main()
