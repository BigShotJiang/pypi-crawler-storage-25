# FAF Agent

**The Voice of FAF.**

A sensible, reliable agent that knows the most about the FAF format. It validates, scores, and answers questions about `.faf` and `.fafm` documents — always citing the spec or clearly refusing when a question is outside scope.

Exactly the size of FAF. No more, no less.

`.faf 🐘🎙️`

---

**What it does**
- Validates and scores .faf documents (faf-cli kernel; native in v0.2.0)
- Answers specification questions with citations
- Refuses out-of-scope questions cleanly
- Maintains voice-native memory on a namepoint

**What it does not do**
- General-purpose reasoning or coding
- Answer questions unrelated to the FAF format

**Install**
```bash
uvx faf-agent-mcp
```

**Usage**
```bash
# Via Claude Code, Cursor, or any MCP host
```

**License**
MIT
