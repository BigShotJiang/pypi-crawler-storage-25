"""TiniRAG core package."""
