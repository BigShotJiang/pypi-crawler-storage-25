# Recording-Machine
Recording-Machine records all decisions made by machines and their explanations of their actions.

In order to launch it from command line or as a subprocess:
```bash
  echo "Theodotos-Alexandreus: Record what's just been said, machine" \
    | uvx recording-machine \
        --provider-api-key=sk-proj-... \
        --github-token=ghp_... 
```

Or:
```bash
  pip install recording-machine
```
Then:
```Python
  # Python
  import recording_machine
```
