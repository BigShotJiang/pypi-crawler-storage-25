import requests
import time
import os
import uuid
import json
import threading
from pathlib import Path
from typing import List, Optional, Any

from .node import AIPNode

class SwarmResult:
    """The structured result returned to the developer."""
    def __init__(self, text: str, trace: List[dict], session_id: str, status: str):
        self.text = text
        self.trace = trace
        self.session_id = session_id
        self.status = status

    def __repr__(self):
        return f"SwarmResult(status={self.status}, session_id={self.session_id}, text='{self.text[:50]}...')"

def _load_config():
    config_file = Path.home() / ".aip" / "config.json"
    if config_file.exists():
        with open(config_file, "r") as f:
            return json.load(f)
    return {}

def solve(goal: str, models: Optional[List[str]] = None, host: Optional[str] = None, token: Optional[str] = None, max_rounds: int = 20) -> SwarmResult:
    """
    Decentralized Launch Point. 
    Spawns independent Nodes that communicate autonomously via a shared ledger.
    """
    local_config = _load_config()
    
    host = host or os.getenv("AIP_HOST_URL") or local_config.get("AIP_HOST_URL", "https://aip-nhy3.onrender.com")
    token = token or os.getenv("AIP_HOST_KEY") or local_config.get("AIP_HOST_KEY")
    models = models or ["gpt-4o", "claude-3-5-sonnet-20240620"]
    
    if not token:
        raise ValueError("AIP_HOST_KEY is missing. Run `aip setup` or set environment variable.")

    # 1. Initialize the shared Ledger Session
    r = requests.post(f"{host.rstrip('/')}/seed", params={"goal": goal}, headers={"X-AIP-Token": token})
    r.raise_for_status()
    session_id = r.json().get("session_id")
    
    print(f"[*] DECENTRALIZED PROTOCOL ACTIVE: {session_id}")
    print(f"[*] NODES JOINING LEDGER: {', '.join(models)}\n")
    
    # 2. Spawn Independent Nodes (Threads)
    # These nodes will interact autonomously without a central controller.
    halt_event = threading.Event()
    nodes = [AIPNode(m, session_id, host, token) for m in models]
    threads = []
    
    for node in nodes:
        t = threading.Thread(target=node.run_worker, args=(halt_event,), daemon=True)
        t.start()
        threads.append(t)

    # 3. Wait for Decentralized Consensus
    start_time = time.time()
    while not halt_event.is_set():
        if time.time() - start_time > 120: # 2 minute safety timeout
            halt_event.set()
            break
        time.sleep(1)

    # 4. Fetch the Final Truth from the Ledger
    r = requests.get(f"{host.rstrip('/')}/state", params={"session_id": session_id})
    state = r.json()
    history = state.get("history", [])
    
    final_text = "Consensus not reached."
    if history and history[-1].get("msg_type") == "FINAL":
        final_text = history[-1].get("content")

    return SwarmResult(
        text=final_text,
        trace=history,
        session_id=session_id,
        status=state.get("status", "completed")
    )
