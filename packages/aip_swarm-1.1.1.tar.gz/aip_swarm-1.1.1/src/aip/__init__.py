from .client import AIPClient, solve

__version__ = "1.0.0"
__all__ = ["AIPClient", "solve"]
