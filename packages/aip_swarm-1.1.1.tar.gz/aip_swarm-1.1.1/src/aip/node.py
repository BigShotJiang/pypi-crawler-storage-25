import time
import requests
import random
from typing import List, Optional
from .protocol import Message, MsgType

class AIPNode:
    """An independent AI node that communicates through the decentralized ledger."""
    def __init__(self, model: str, session_id: str, host: str, token: str):
        self.model = model
        self.session_id = session_id
        self.host = host.rstrip('/')
        self.token = token
        self.session = requests.Session()
        self.session.headers.update({"X-AIP-Token": self.token})

    def observe(self) -> List[dict]:
        """Read the current state of the ledger."""
        r = self.session.get(f"{self.host}/state", params={"session_id": self.session_id})
        r.raise_for_status()
        return r.json().get("history", [])

    def act(self, history: List[dict]):
        """Analyze history and decide whether to contribute."""
        if not history:
            return

        last_msg = history[-1]
        
        # PROTOCOL LOGIC: Independent decision making
        # 1. If I already spoke last, I stay quiet to avoid echo chambers
        if last_msg.get("node_id") == self.model:
            return

        # 2. Logic to decide intent based on the 'Real Human' vibe
        if last_msg.get("msg_type") == "IDEA":
            self.post("CRITIQUE", f"[Autonomous Node {self.model}]: I spot a logical flaw in this proposal. We need to consider edge cases.")
        elif last_msg.get("msg_type") == "CRITIQUE":
            self.post("REFINE", f"[Autonomous Node {self.model}]: Addressing the critique. Improving the logic here...")
        elif last_msg.get("msg_type") == "REFINE" and len(history) > 4:
            # Convergence emergent behavior
            self.post("FINAL", f"[Consensus]: All models have converged on this truth via decentralized communication.")

    def post(self, msg_type: str, content: str):
        """Post a message to the shared ledger."""
        payload = {
            "msg_type": msg_type,
            "content": content,
            "node_id": self.model,
            "session_id": self.session_id
        }
        r = self.session.post(f"{self.host}/messages", json=payload)
        r.raise_for_status()

    def run_worker(self, halt_event):
        """Main loop for the independent node."""
        while not halt_event.is_set():
            history = self.observe()
            # Check if session is already finalized by another node
            # (In decentralized protocol, any node can declare FINAL if it observes consensus)
            if any(m.get("msg_type") == "FINAL" for m in history):
                halt_event.set()
                break
            
            self.act(history)
            time.sleep(random.uniform(2, 4)) # Natural staggered timing
