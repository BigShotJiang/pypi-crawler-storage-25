import click
import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".aip"
CONFIG_FILE = CONFIG_DIR / "config.json"

@click.group()
def main():
    """AIP - Industrial-grade Decentralized AI Communication Protocol CLI"""
    pass

@main.command()
@click.option("--key", prompt="Enter your AIP Host Key", help="Your private AIP authorization token.")
@click.option("--host", default="https://aip-nhy3.onrender.com", help="The AIP Ledger Server URL.")
def setup(key, host):
    """One-time configuration for zero-setup development."""
    CONFIG_DIR.mkdir(exist_ok=True)
    
    config = {
        "AIP_HOST_KEY": key,
        "AIP_HOST_URL": host
    }
    
    with open(CONFIG_FILE, "w") as f:
        json.dump(config, f, indent=2)
        
    click.echo(click.style("\n✅ AIP SUCCESS: Configuration saved to " + str(CONFIG_FILE), fg="green", bold=True))
    click.echo("You can now use `solve()` in your scripts without passing keys or URLs.\n")

@main.command()
def status():
    """Check current configuration and connection status."""
    if not CONFIG_FILE.exists():
        click.echo(click.style("❌ No configuration found. Run `aip setup` first.", fg="red"))
        return
        
    with open(CONFIG_FILE, "r") as f:
        config = json.load(f)
        
    click.echo(f"AIP Host: {config.get('AIP_HOST_URL')}")
    click.echo(f"Auth Key: {'*' * 10}{config.get('AIP_HOST_KEY')[-4:]}")

if __name__ == "__main__":
    main()
