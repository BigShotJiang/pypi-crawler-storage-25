from enum import Enum
from pydantic import BaseModel
from typing import List, Optional, Any

class MsgType(str, Enum):
    IDEA = "IDEA"           # Initial proposal
    REFINE = "REFINE"       # Constructive improvement
    CRITIQUE = "CRITIQUE"   # Logical challenge
    AGREEMENT = "AGREEMENT" # Consensus signal
    FINAL = "FINAL"         # Hallucination-free result

class Message(BaseModel):
    msg_type: MsgType
    content: str
    node_id: str
    session_id: Optional[str] = None
    metadata: Optional[Any] = None

class AIPState(BaseModel):
    history: List[Message]
    status: str
    session_id: Optional[str] = None
    version: str = "1.1.1"
