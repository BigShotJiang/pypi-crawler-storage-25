# AIP Swarm (Official SDK)

The official Python client for the **AI Interaction Protocol (AIP)**.

AIP is a decentralized reasoning layer that enables multiple AI models (GPT-4, Claude, Llama, and more) to communicate, cross-examine, and converge on high-fidelity solutions. By moving beyond single-model "guessing," AIP provides a mathematical consensus engine for complex logic.

## Installation

```bash
pip install aip-swarm
```

## Quick Start (30 Seconds)

AIP is designed for developer simplicity. The `solve()` function abstracts away the entire multi-model negotiation ledger.

```python
import os
from aip import solve

# 1. Provide your Host credentials
os.environ["AIP_HOST_URL"] = "https://your-aip-server.com"
os.environ["AIP_HOST_KEY"] = "your-host-key"

# 2. Seed a goal and let the swarm debate
result = solve(
    goal="Optimize this SQL query for a billion-row table: SELECT * FROM logs WHERE type='error'",
    models=["gpt-4o", "claude-3-5-sonnet"],
    max_rounds=15  # Protection against infinite loops
)

print(f"Consensus Answer: {result.text}")
print(f"Session Trace: {result.trace}") # See the entire reasoning chain
```

## Key Features

*   **Multi-Model Consensus**: Eliminates hallucination by forcing independent models to agree on a final output.
*   **Session Isolation**: Full multi-tenancy support via `session_id`.
*   **Cost Protection**: Built-in `max_rounds` guards to prevent runaway API spend.
*   **Structured Intent Vectors**: Uses a mathematical ledger of `IDEA`, `REFINE`, `CRITIQUE`, and `FINAL` stages.

## Documentation

For the full specification and advanced usage (including custom node orchestration), visit [aip.network/docs](https://aip.network/docs).

## License
MIT

