/// Selection point with side tracking for pixel-perfect text selection
///
/// This module implements the selection point tracking system inspired by
/// KCM's GUACAMOLE-2117 improvements. It tracks which side of a character
/// the mouse is on (left vs right) to provide accurate selection boundaries.
use crate::TerminalEmulator;

/// Which side of a terminal column the selection point is on
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ColumnSide {
    /// Left side of the column (left half of character)
    Left,
    /// Right side of the column (right half of character)
    Right,
}

/// A precise selection point within the terminal
///
/// Tracks not just row/column, but also which side of the character
/// and the character's width for accurate selection boundaries.
#[derive(Debug, Clone, PartialEq)]
pub struct SelectionPoint {
    /// The row value of the point
    pub row: u16,
    /// The column value of the point
    pub column: u16,
    /// The specific side of the column pointed to
    pub side: ColumnSide,
    /// The starting column of the character pointed to
    pub char_starting_column: u16,
    /// The width of the character pointed to (1 for ASCII, 2+ for wide chars)
    pub char_width: u16,
}

impl SelectionPoint {
    /// Create a new selection point from pixel coordinates
    ///
    /// # Arguments
    /// * `x_px` - X coordinate in pixels
    /// * `y_px` - Y coordinate in pixels
    /// * `char_width` - Width of a character cell in pixels
    /// * `char_height` - Height of a character cell in pixels
    /// * `cols` - Number of columns in terminal
    /// * `rows` - Number of rows in terminal
    /// * `terminal` - Terminal emulator to query character information
    pub fn from_pixel_coords(
        x_px: u32,
        y_px: u32,
        char_width: u32,
        char_height: u32,
        cols: u16,
        rows: u16,
        terminal: &TerminalEmulator,
    ) -> Self {
        // Convert to cell coordinates
        let col = (x_px / char_width).min(cols as u32 - 1) as u16;
        let row = (y_px / char_height).min(rows as u32 - 1) as u16;

        // Determine which side of the character (left or right half)
        let char_x_offset = x_px % char_width;
        let side = if char_x_offset < (char_width / 2) {
            ColumnSide::Left
        } else {
            ColumnSide::Right
        };

        // Find the actual character at this position
        let (char_starting_column, char_width_cells) = find_char_at_position(terminal, row, col);

        SelectionPoint {
            row,
            column: col,
            side,
            char_starting_column,
            char_width: char_width_cells,
        }
    }

    /// Create a selection point directly from row/column/side
    ///
    /// This is useful for programmatic selection (e.g., double-click word selection)
    pub fn new(row: u16, column: u16, side: ColumnSide, terminal: &TerminalEmulator) -> Self {
        let (char_starting_column, char_width) = find_char_at_position(terminal, row, column);

        SelectionPoint {
            row,
            column,
            side,
            char_starting_column,
            char_width,
        }
    }

    /// Create a selection point from pixel coordinates using a ratatui buffer
    pub fn from_pixel_coords_ratatui(
        x_px: u32,
        y_px: u32,
        char_width: u32,
        char_height: u32,
        cols: u16,
        rows: u16,
        buffer: &ratatui::buffer::Buffer,
    ) -> Self {
        let col = (x_px / char_width).min(cols as u32 - 1) as u16;
        let row = (y_px / char_height).min(rows as u32 - 1) as u16;
        let side = if (x_px % char_width) < (char_width / 2) {
            ColumnSide::Left
        } else {
            ColumnSide::Right
        };
        let (char_starting_column, char_width_cells) =
            find_char_at_position_ratatui(buffer, row, col);
        SelectionPoint {
            row,
            column: col,
            side,
            char_starting_column,
            char_width: char_width_cells,
        }
    }

    /// Create a selection point directly from row/column/side using a ratatui buffer
    pub fn new_ratatui(
        row: u16,
        column: u16,
        side: ColumnSide,
        buffer: &ratatui::buffer::Buffer,
    ) -> Self {
        let (char_starting_column, char_width) = find_char_at_position_ratatui(buffer, row, column);
        SelectionPoint {
            row,
            column,
            side,
            char_starting_column,
            char_width,
        }
    }

    /// Determine if this point comes after another point
    ///
    /// Uses left-to-right, top-to-bottom ordering. A point is "after"
    /// if it's further right or down from the other point.
    ///
    /// # Arguments
    /// * `other` - Point to compare against
    ///
    /// # Returns
    /// `true` if this point comes after the other point
    pub fn is_after(&self, other: &SelectionPoint) -> bool {
        if self.row != other.row {
            return self.row > other.row;
        }
        if self.column != other.column {
            return self.column > other.column;
        }
        if self.side != other.side {
            // If same column, right side is after left side
            return self.side == ColumnSide::Right;
        }
        // Points are identical
        false
    }

    /// Round the column up to the next character boundary
    ///
    /// If we're anywhere except the leftmost position in a character,
    /// return the starting column of the next character.
    ///
    /// # Returns
    /// Column value for the start of the selection
    pub fn round_up(&self) -> u16 {
        if self.column == self.char_starting_column && self.side == ColumnSide::Left {
            // Already at the leftmost position
            self.column
        } else {
            // Round up to next character
            self.char_starting_column + self.char_width
        }
    }

    /// Round the column down to the previous character boundary
    ///
    /// If we're anywhere except the rightmost position in a character,
    /// return the ending column of the previous character.
    ///
    /// # Returns
    /// Column value for the end of the selection
    pub fn round_down(&self) -> u16 {
        let end_char_column = self.char_starting_column + self.char_width - 1;
        if self.column == end_char_column && self.side == ColumnSide::Right {
            // Already at the rightmost position
            end_char_column
        } else {
            // Round down to previous character
            if self.char_starting_column > 0 {
                self.char_starting_column - 1
            } else {
                0
            }
        }
    }
}

/// Determine if two selection points enclose at least one character
///
/// A range encloses text if it stretches from the furthest left to
/// furthest right of any complete character.
///
/// # Arguments
/// * `start` - Starting point (must come before end)
/// * `end` - Ending point (must come after start)
///
/// # Returns
/// `true` if the range contains at least one complete character
pub fn points_enclose_text(start: &SelectionPoint, end: &SelectionPoint) -> bool {
    // Different rows always contain at least one character
    if start.row != end.row {
        return true;
    }

    // Check if the starting point completely contains a character
    let start_char_end = start.char_starting_column + start.char_width - 1;
    if start.side == ColumnSide::Left
        && start.column == start.char_starting_column
        && (end.column > start_char_end
            || (end.column == start_char_end && end.side == ColumnSide::Right))
    {
        return true;
    }

    // Check the next character after start
    let end_char_end = end.char_starting_column + end.char_width - 1;
    let second_char_start = start_char_end + 1;
    if second_char_start < end.char_starting_column
        || (second_char_start == end.char_starting_column
            && end.column == end_char_end
            && end.side == ColumnSide::Right)
    {
        return true;
    }

    false
}

/// Find the character at a given position and return its starting column and width
///
/// # Arguments
/// * `terminal` - Terminal emulator to query
/// * `row` - Row to search
/// * `column` - Column to search
///
/// # Returns
/// Tuple of (starting_column, width) for the character at this position
fn find_char_at_position(terminal: &TerminalEmulator, row: u16, column: u16) -> (u16, u16) {
    let screen = terminal.screen();

    // Get the cell at this position
    if let Some(cell) = screen.cell(row, column) {
        let contents: String = cell.contents();

        // Check if this is a wide character
        if contents.chars().count() > 0 {
            let first_char = contents.chars().next().unwrap();
            let width = unicode_width::UnicodeWidthChar::width(first_char).unwrap_or(1) as u16;

            // If width > 1, we need to find the starting column
            if width > 1 {
                // Check if we're on a continuation cell
                // Scan backwards to find the start
                let mut start_col = column;
                while start_col > 0 {
                    if let Some(prev_cell) = screen.cell(row, start_col - 1) {
                        let prev_contents: String = prev_cell.contents();
                        if prev_contents.chars().count() > 0 {
                            let prev_char = prev_contents.chars().next().unwrap();
                            let prev_width =
                                unicode_width::UnicodeWidthChar::width(prev_char).unwrap_or(1);
                            if prev_width > 1 && prev_contents == contents {
                                // This is part of the same wide character
                                start_col -= 1;
                                continue;
                            }
                        }
                    }
                    break;
                }
                return (start_col, width);
            }

            return (column, width);
        }
    }

    // Default: single-width character
    (column, 1)
}

/// Find the character at a given position in a ratatui buffer and return its starting column and width
fn find_char_at_position_ratatui(
    buffer: &ratatui::buffer::Buffer,
    row: u16,
    col: u16,
) -> (u16, u16) {
    let buf_width = buffer.area.width as usize;
    let idx = row as usize * buf_width + col as usize;
    if idx >= buffer.content.len() {
        return (col, 1);
    }
    let symbol = buffer.content[idx].symbol();
    if let Some(first_char) = symbol.chars().next() {
        let char_w = unicode_width::UnicodeWidthChar::width(first_char).unwrap_or(1) as u16;
        if char_w > 1 {
            // Find the starting column for this wide character
            let mut start_col = col;
            while start_col > 0 {
                let prev_idx = row as usize * buf_width + (start_col - 1) as usize;
                if prev_idx < buffer.content.len() && buffer.content[prev_idx].symbol() == symbol {
                    start_col -= 1;
                } else {
                    break;
                }
            }
            return (start_col, char_w);
        }
        return (col, char_w.max(1));
    }
    (col, 1)
}
