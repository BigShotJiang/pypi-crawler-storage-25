#  Pylogram - Telegram MTProto API Client Library for Python
#  Copyright (C) 2017-2023 Dan <https://github.com/delivrance>
#  Copyright (C) 2023-2024 Pylakey <https://github.com/pylakey>
#
#  This file is part of Pylogram.
#
#  Pylogram is free software: you can redistribute it and/or modify
#  it under the terms of the GNU Lesser General Public License as published
#  by the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  Pylogram is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public License
#  along with Pylogram.  If not, see <http://www.gnu.org/licenses/>.

import logging
import os
import sqlite3
from pathlib import Path

from .sqlite_storage import SQLiteStorage

log = logging.getLogger(__name__)


class FileStorage(SQLiteStorage):
    FILE_EXTENSION = ".session"

    def __init__(self, name: str, workdir: Path):
        super().__init__(name)
        self.database = workdir / (self.name + self.FILE_EXTENSION)

    def update(self):
        version = self.version()

        if version == 1:
            with self.conn:
                self.conn.execute("DELETE FROM peers")
                self.conn.commit()

            version += 1

        if version == 2:
            with self.conn:
                self.conn.execute("ALTER TABLE sessions ADD api_id INTEGER")
                self.conn.commit()

            version += 1

        if version == 3:
            with self.conn:
                self.conn.execute("""
                    CREATE TABLE IF NOT EXISTS update_state (
                        id   INTEGER PRIMARY KEY CHECK (id = 1),
                        pts  INTEGER NOT NULL DEFAULT 0,
                        qts  INTEGER NOT NULL DEFAULT 0,
                        seq  INTEGER NOT NULL DEFAULT 0,
                        date INTEGER NOT NULL DEFAULT 0
                    )
                """)
                self.conn.execute("""
                    CREATE TABLE IF NOT EXISTS channel_pts (
                        channel_id     INTEGER PRIMARY KEY,
                        pts            INTEGER NOT NULL,
                        last_update_on INTEGER NOT NULL
                            DEFAULT (CAST(STRFTIME('%s', 'now') AS INTEGER))
                    )
                """)
                self.conn.commit()

            version += 1

        self.version(version)

    async def open(self):
        path = self.database
        file_exists = path.is_file()

        self.conn = sqlite3.connect(str(path), timeout=1, check_same_thread=False)

        if not file_exists:
            self.create()
        else:
            self.update()

        with self.conn:
            self.conn.execute("VACUUM")

    async def delete(self):
        os.remove(self.database)
