import pytest
import requests
from unittest.mock import patch
from pynhl.classes import Team
from pynhl.exceptions import NHLApiError, NHLApiTimeoutError

VALID_TEAM_RESPONSE = {
    "data": [
        {
            "triCode": "MTL",
            "fullName": "Montreal Canadiens",
            "id": 8,
            "franchiseId": 1,
        },
        {
            "triCode": "TOR",
            "fullName": "Toronto Maple Leafs",
            "id": 10,
            "franchiseId": 5,
        },
    ]
}


class TestTeamInit:
    def test_successful_init(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_TEAM_RESPONSE)
            team = Team("MTL")
            assert team.data == VALID_TEAM_RESPONSE

    def test_timeout_raises_nhl_timeout_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout
            with pytest.raises(NHLApiTimeoutError):
                Team("MTL")

    def test_request_exception_raises_nhl_api_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException
            with pytest.raises(NHLApiError):
                Team("MTL")

    def test_invalid_json_raises_nhl_api_error(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            r = mock_response()
            r.json.side_effect = ValueError("no JSON")
            mock_get.return_value = r
            with pytest.raises(NHLApiError):
                Team("MTL")


class TestTeamInfo:
    def test_returns_team_data(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_TEAM_RESPONSE)
            team = Team("MTL")
            info = team.team_info()
            assert info["team_name"] == "Montreal Canadiens"
            assert info["team_id"] == 8
            assert info["team_abbrev"] == "MTL"
            assert info["team_logo"].endswith("MTL_light.svg")
            assert info["team_logo_dark"].endswith("MTL_dark.svg")

    def test_case_insensitive_team_id(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_TEAM_RESPONSE)
            team = Team("mtl")
            info = team.team_info()
            assert info["team_name"] == "Montreal Canadiens"

    def test_returns_empty_dict_for_unknown_team(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_TEAM_RESPONSE)
            team = Team("BUF")
            assert team.team_info() == {}

    def test_returns_empty_dict_on_bad_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_TEAM_RESPONSE)
            team = Team.__new__(Team)
            team.team_id = "MTL"
            team.response = mock_response(ok=False)
            team.data = {}
            assert team.team_info() == {}

    def test_returns_empty_dict_on_missing_data_key(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data={})
            team = Team("MTL")
            assert team.team_info() == {}
