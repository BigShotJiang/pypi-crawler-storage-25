import pytest
import requests
from unittest.mock import patch
from pynhl.classes import Schedule
from pynhl.exceptions import NHLApiError, NHLApiTimeoutError
from tests.conftest import mock_response

VALID_SCHEDULE_RESPONSE = {
    "focusedDateCount": 2,
    "gamesByDate": [
        {
            "games": [
                {
                    "id": 2024020001,
                    "gameCenterLink": "/gamecenter/2024020001",
                    "gameState": "LIVE",
                    "startTimeUTC": "2024-10-10T23:00:00Z",
                    "awayTeam": {
                        "id": 8,
                        "abbrev": "MTL",
                        "name": {"default": "Canadiens"},
                        "logo": "https://example.com/mtl.svg",
                    },
                    "homeTeam": {
                        "id": 10,
                        "abbrev": "TOR",
                        "name": {"default": "Maple Leafs"},
                        "logo": "https://example.com/tor.svg",
                    },
                    "tvBroadcasts": [
                        {"network": "CBC", "market": "N"},
                        {"network": "RDS", "market": "H"},
                    ],
                }
            ]
        }
    ],
}


class TestScheduleInit:
    def test_successful_init(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_SCHEDULE_RESPONSE)
            schedule = Schedule("MTL")
            assert schedule.data == VALID_SCHEDULE_RESPONSE

    def test_timeout_raises_nhl_timeout_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout
            with pytest.raises(NHLApiTimeoutError):
                Schedule("MTL")

    def test_request_exception_raises_nhl_api_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException("connection error")
            with pytest.raises(NHLApiError):
                Schedule("MTL")

    def test_invalid_json_raises_nhl_api_error(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            r = mock_response()
            r.json.side_effect = ValueError("no JSON")
            mock_get.return_value = r
            with pytest.raises(NHLApiError):
                Schedule("MTL")


class TestScheduleGameInfo:
    def test_returns_game_data_on_valid_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            with patch("pynhl.classes.Standings") as mock_standings:
                mock_standings.return_value.team_record.return_value = {
                    "team_wins": 40, "team_losses": 30, "team_ot_losses": 10
                }
                mock_get.return_value = mock_response(json_data=VALID_SCHEDULE_RESPONSE)
                schedule = Schedule("MTL")
                info = schedule.game_info()
                assert info["game_state"] == "LIVE"
                assert info["game_id"] == 2024020001
                assert info["away_name"] == "Canadiens"
                assert info["home_name"] == "Maple Leafs"
                assert info["away_record"] == "40-30-10"
                assert info["home_record"] == "40-30-10"

    def test_returns_no_game_scheduled_on_bad_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(ok=False, status_code=404)
            schedule = Schedule.__new__(Schedule)
            schedule.response = mock_response(ok=False)
            schedule.data = {}
            info = schedule.game_info()
            assert info == {"game_state": "No Game Scheduled"}

    def test_returns_no_game_scheduled_on_missing_key(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data={"gamesByDate": []})
            schedule = Schedule("MTL")
            info = schedule.game_info()
            assert info == {"game_state": "No Game Scheduled"}

    def test_game_info_handles_standings_failure(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            with patch("pynhl.classes.Standings") as mock_standings:
                mock_standings.return_value.team_record.return_value = {}
                mock_get.return_value = mock_response(json_data=VALID_SCHEDULE_RESPONSE)
                schedule = Schedule("MTL")
                info = schedule.game_info()
                assert info["away_record"] == "N/A"
                assert info["home_record"] == "N/A"


class TestScheduleBroadcastInfo:
    def test_returns_broadcasts(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            with patch("pynhl.classes.Standings"):
                mock_get.return_value = mock_response(json_data=VALID_SCHEDULE_RESPONSE)
                schedule = Schedule("MTL")
                broadcasts = schedule.broadcast_info()
                assert broadcasts["national_broadcasts"] == ["CBC"]
                assert broadcasts["home_broadcasts"] == ["RDS"]
                assert broadcasts["away_broadcasts"] == []
