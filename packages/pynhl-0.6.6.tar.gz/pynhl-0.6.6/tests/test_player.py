import pytest
import requests
from unittest.mock import patch
from pynhl.classes import Player
from pynhl.exceptions import NHLApiError, NHLApiTimeoutError

VALID_PLAYER_RESPONSE = {
    "playerId": 8478402,
    "currentTeamId": 8,
    "currentTeamAbbrev": "MTL",
    "fullTeamName": {"default": "Montreal Canadiens"},
    "firstName": {"default": "Cole"},
    "lastName": {"default": "Caufield"},
    "sweaterNumber": 22,
    "position": "R",
    "headshot": "https://assets.nhle.com/mugs/nhl/20232024/MTL/8478402.png",
    "featuredStats": {
        "regularSeason": {
            "subSeason": {
                "gamesPlayed": 70,
                "goals": 28,
                "assists": 37,
                "points": 65,
            }
        }
    },
}


class TestPlayerInit:
    def test_successful_init(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYER_RESPONSE)
            player = Player(8478402)
            assert player.data == VALID_PLAYER_RESPONSE

    def test_timeout_raises_nhl_timeout_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout
            with pytest.raises(NHLApiTimeoutError):
                Player(8478402)

    def test_request_exception_raises_nhl_api_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException
            with pytest.raises(NHLApiError):
                Player(8478402)

    def test_invalid_json_raises_nhl_api_error(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            r = mock_response()
            r.json.side_effect = ValueError("no JSON")
            mock_get.return_value = r
            with pytest.raises(NHLApiError):
                Player(8478402)


class TestPlayerInfo:
    def test_returns_player_data(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYER_RESPONSE)
            player = Player(8478402)
            info = player.player_info()
            assert info["player_name"] == "Cole Caufield"
            assert info["player_number"] == 22
            assert info["current_team_abbrev"] == "MTL"
            assert info["season_goals"] == 28

    def test_assembles_name_from_dict(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYER_RESPONSE)
            player = Player(8478402)
            info = player.player_info()
            assert info["player_name"] == "Cole Caufield"

    def test_assembles_name_from_string(self, mock_response):
        data = {**VALID_PLAYER_RESPONSE, "firstName": "Cole", "lastName": "Caufield"}
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=data)
            player = Player(8478402)
            info = player.player_info()
            assert info["player_name"] == "Cole Caufield"

    def test_returns_not_found_on_missing_key(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data={})
            player = Player(8478402)
            info = player.player_info()
            assert info == {"player_id": "Not Found"}

    def test_returns_not_found_on_missing_stats(self, mock_response):
        data = {**VALID_PLAYER_RESPONSE, "featuredStats": None}
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=data)
            player = Player(8478402)
            info = player.player_info()
            assert info == {"player_id": "Not Found"}

    def test_returns_empty_dict_on_bad_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYER_RESPONSE)
            player = Player.__new__(Player)
            player.response = mock_response(ok=False)
            player.data = {}
            assert player.player_info() == {}
