import pytest
import requests
from unittest.mock import patch
from pynhl.classes import Plays
from pynhl.exceptions import NHLApiError, NHLApiTimeoutError

VALID_PLAYS_RESPONSE = {
    "awayTeam": {
        "id": 8, "abbrev": "MTL", "score": 2, "sog": 15,
        "commonName": {"default": "Canadiens"},
        "placeName": {"default": "Montreal"},
    },
    "homeTeam": {
        "id": 10, "abbrev": "TOR", "score": 1, "sog": 20,
        "commonName": {"default": "Maple Leafs"},
        "placeName": {"default": "Toronto"},
    },
    "clock": {"timeRemaining": "10:00", "inIntermission": False},
    "periodDescriptor": {"number": 2, "periodType": "REG"},
    "plays": [
        {
            "typeDescKey": "goal",
            "eventId": 123,
            "situationCode": "1551",
            "details": {
                "eventOwnerTeamId": 8,
                "scoringPlayerId": 1001,
                "scoringPlayerTotal": 20,
                "assist1PlayerId": 1002,
                "assist1PlayerTotal": 15,
                "assist2PlayerId": None,
                "assist2PlayerTotal": None,
            },
        }
    ],
}


class TestPlaysInit:
    def test_successful_init(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYS_RESPONSE)
            plays = Plays("2024020001")
            assert plays.data == VALID_PLAYS_RESPONSE

    def test_timeout_raises_nhl_timeout_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout
            with pytest.raises(NHLApiTimeoutError):
                Plays("2024020001")

    def test_request_exception_raises_nhl_api_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException
            with pytest.raises(NHLApiError):
                Plays("2024020001")


class TestScoringInfo:
    def test_returns_goal_data(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            with patch("pynhl.classes.Player") as mock_player:
                mock_player.return_value.player_info.return_value = {
                    "player_name": "Cole Caufield", "player_number": 22
                }
                mock_get.return_value = mock_response(json_data=VALID_PLAYS_RESPONSE)
                plays = Plays("2024020001")
                info = plays.scoring_info()
                assert info["goal_event_id"] == 123
                assert info["goal_team_abbrev"] == "MTL"
                assert info["away_score"] == 2
                assert info["home_score"] == 1

    def test_returns_scores_only_when_no_goal(self, mock_response):
        data = {**VALID_PLAYS_RESPONSE, "plays": [{"typeDescKey": "hit", "eventId": 50}]}
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=data)
            plays = Plays("2024020001")
            info = plays.scoring_info()
            assert info == {"away_score": 2, "home_score": 1}

    def test_returns_empty_dict_on_bad_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYS_RESPONSE)
            plays = Plays.__new__(Plays)
            plays.response = mock_response(ok=False)
            plays.data = {}
            assert plays.scoring_info() == {}

    def test_scoring_info_handles_player_lookup_failure(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            with patch("pynhl.classes.Player") as mock_player:
                mock_player.return_value.player_info.return_value = {}
                mock_get.return_value = mock_response(json_data=VALID_PLAYS_RESPONSE)
                plays = Plays("2024020001")
                info = plays.scoring_info()
                assert info["goal_event_id"] == 123
                assert info["scoring_player_name"] is None
                assert info["scoring_player_number"] is None


class TestLinescoreInfo:
    def test_returns_linescore(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYS_RESPONSE)
            plays = Plays("2024020001")
            info = plays.linescore_info()
            assert info["time_remaining"] == "10:00"
            assert info["current_period"] == 2
            assert info["is_intermission"] is False

    def test_returns_empty_dict_on_bad_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_PLAYS_RESPONSE)
            plays = Plays.__new__(Plays)
            plays.response = mock_response(ok=False)
            plays.data = {}
            assert plays.linescore_info() == {}
