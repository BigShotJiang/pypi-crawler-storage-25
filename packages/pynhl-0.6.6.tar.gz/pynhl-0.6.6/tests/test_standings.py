import pytest
import requests
from unittest.mock import patch
from pynhl.classes import Standings
from pynhl.exceptions import NHLApiError, NHLApiTimeoutError

VALID_STANDINGS_RESPONSE = {
    "standings": [
        {
            "teamAbbrev": {"default": "MTL"},
            "wins": 40,
            "losses": 30,
            "otLosses": 10,
        },
        {
            "teamAbbrev": {"default": "TOR"},
            "wins": 45,
            "losses": 25,
            "otLosses": 8,
        },
    ]
}


class TestStandingsInit:
    def test_successful_init(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_STANDINGS_RESPONSE)
            standings = Standings("MTL")
            assert standings.data == VALID_STANDINGS_RESPONSE

    def test_timeout_raises_nhl_timeout_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.Timeout
            with pytest.raises(NHLApiTimeoutError):
                Standings("MTL")

    def test_request_exception_raises_nhl_api_error(self):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.side_effect = requests.RequestException
            with pytest.raises(NHLApiError):
                Standings("MTL")

    def test_invalid_json_raises_nhl_api_error(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            r = mock_response()
            r.json.side_effect = ValueError("no JSON")
            mock_get.return_value = r
            with pytest.raises(NHLApiError):
                Standings("MTL")


class TestTeamRecord:
    def test_returns_record_for_known_team(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_STANDINGS_RESPONSE)
            standings = Standings("MTL")
            record = standings.team_record()
            assert record == {"team_wins": 40, "team_losses": 30, "team_ot_losses": 10}

    def test_case_insensitive_team_id(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_STANDINGS_RESPONSE)
            standings = Standings("mtl")
            record = standings.team_record()
            assert record["team_wins"] == 40

    def test_returns_empty_dict_for_unknown_team(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_STANDINGS_RESPONSE)
            standings = Standings("BUF")
            assert standings.team_record() == {}

    def test_returns_empty_dict_on_bad_response(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data=VALID_STANDINGS_RESPONSE)
            standings = Standings.__new__(Standings)
            standings.team_id = "MTL"
            standings.response = mock_response(ok=False)
            standings.data = {}
            assert standings.team_record() == {}

    def test_returns_empty_dict_on_missing_standings_key(self, mock_response):
        with patch("pynhl.classes.requests.get") as mock_get:
            mock_get.return_value = mock_response(json_data={})
            standings = Standings("MTL")
            assert standings.team_record() == {}
