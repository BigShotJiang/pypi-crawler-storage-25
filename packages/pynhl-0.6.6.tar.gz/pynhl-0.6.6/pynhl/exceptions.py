class NHLApiError(Exception):
    """Raised when the NHL API returns an unexpected response."""

class NHLApiTimeoutError(NHLApiError):
    """Raised when a request to the NHL API times out."""