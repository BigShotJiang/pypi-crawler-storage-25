from collections.abc import Iterator

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.event_types import ExecutionEventTypes
from anusara._core.execution_status import ExecutionStatus
from anusara._core.execution_summary import ExecutionSummary


class ExecutionLogInspector:
    """
    Streams execution summaries from an event log.

    This is a pure projection layer:
    - does not mutate state
    - does not modify the event log
    - derives execution lifecycle status from events

    Useful for:
    - dashboards
    - CLI inspection
    - debugging execution history
    """

    def __init__(self, event_log: ExecutionEventLog):
        self._event_log = event_log

    # ---------------------------------------------------------
    # Public API
    # ---------------------------------------------------------

    def stream_summaries(self) -> Iterator[ExecutionSummary]:
        counters: dict[str, dict[str, int]] = {}

        for event in self._event_log.iter():
            request_id = event.request_id

            if request_id not in counters:
                counters[request_id] = {
                    "started": 0,
                    "completed": 0,
                    "paused": 0,
                }

            if event.EVENT_TYPE == ExecutionEventTypes.MAIN_EXECUTION_STARTED:
                counters[request_id]["started"] += 1

            elif event.EVENT_TYPE == ExecutionEventTypes.MAIN_EXECUTION_COMPLETED:
                counters[request_id]["completed"] += 1

            elif event.EVENT_TYPE == ExecutionEventTypes.MAIN_EXECUTION_PAUSED:
                counters[request_id]["paused"] += 1

        for request_id, counts in counters.items():
            yield ExecutionSummary(
                request_id=request_id,
                status=self._resolve_status(counts),
            )

    # ---------------------------------------------------------
    # Internal
    # ---------------------------------------------------------

    def _resolve_status(self, counts: dict[str, int]) -> ExecutionStatus:
        started = counts["started"]
        completed = counts["completed"]
        paused = counts["paused"]

        # No events
        if started == 0 and completed == 0 and paused == 0:
            return ExecutionStatus.NOT_FOUND

        # 🚨 Structural corruption (must detect)
        if started > 1 and completed == 0 and paused == 0:
            return ExecutionStatus.CORRUPTED

        # Terminal states take priority
        if completed > 0:
            return ExecutionStatus.COMPLETED

        if paused > 0:
            return ExecutionStatus.PAUSED

        # Otherwise still in progress
        if started > 0:
            return ExecutionStatus.INCOMPLETE

        return ExecutionStatus.CORRUPTED
