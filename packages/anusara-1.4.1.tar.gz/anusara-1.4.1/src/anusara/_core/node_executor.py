import asyncio
import inspect
from collections.abc import Callable
from datetime import datetime
from typing import cast

from anusara._contracts.agent import Agent
from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    NodeExecutionCompleted,
    NodeExecutionFailed,
    NodeExecutionRetried,
    NodeExecutionStarted,
)
from anusara._contracts.execution_input import ExecutionInput
from anusara._contracts.execution_request import ExecutionRequest
from anusara._contracts.json_types import JSONValue
from anusara._core.errors import ApprovalRequiredError, SimulatedHardKillError
from anusara._core.execute_node_command import ExecuteNodeCommand
from anusara._core.middleware.retry_middleware import RetryMiddleware
from anusara._core.orchestration_event_emitter import OrchestrationEventEmitter
from anusara._registry.agents_registry import AgentRegistry
from anusara._registry.errors import AgentNotFoundError
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_state import ExecutionState
from anusara._runtime.retry_policy import RetryPolicy
from anusara._utils.time import utc_now


# -----------------------------------------------------------------------------
# ARCHITECTURAL INVARIANT
#
# NodeExecutor is responsible ONLY for:
#   - invoking agents
#   - emitting execution lifecycle events
#
# NodeExecutor MUST NOT:
#   - create ExecutionRecord
#   - mutate ExecutionState
#
# ExecutionState mutations are owned by ExecutionEngine.
# -----------------------------------------------------------------------------
class NodeExecutor:
    """
    Responsible for executing a single orchestration node.

    Invariant:
    - Emits events only.
    - Does NOT mutate ExecutionState directly.
    - Must return deterministic execution record.
    """

    def __init__(
        self,
        registry: AgentRegistry,
        retry_policy: RetryPolicy,
        event_emitter: OrchestrationEventEmitter,
        graph: ExecutionGraph,
    ) -> None:
        self._registry = registry
        self._retry = RetryMiddleware(retry_policy)
        self._emitter = event_emitter
        self._graph = graph  # read-only reference

    # ---------------------------------------------------------
    # PUBLIC ENTRY
    # ---------------------------------------------------------

    async def execute(
        self,
        node_id: str,
        agent_name: str,
        request: ExecutionRequest,
        state: ExecutionState,
        sequence_number: int,
    ) -> AgentResult:
        previous_attempts = len(state.records_for(node_id))
        attempt = previous_attempts + 1

        command = ExecuteNodeCommand(
            request_id=request.request_id,
            node_id=node_id,
            agent=agent_name,
            attempt=attempt,
            payload=request.payload,  # ✅ now matches JSONValue contract
        )

        return await self._execute_command(
            command, request, state, sequence_number=sequence_number
        )

    # ---------------------------------------------------------
    # COMMAND EXECUTION
    # ---------------------------------------------------------

    async def _execute_command(
        self,
        command: ExecuteNodeCommand,
        request: ExecutionRequest,
        state: ExecutionState,
        sequence_number: int,
    ) -> AgentResult:

        agent = self._resolve_agent(command.agent)
        base_attempt = command.attempt

        max_attempts = self._retry.max_attempts()

        # -------------------------------------------------
        # 🔥 Retry gate
        # -------------------------------------------------
        total_attempts = 1 if not request.policy.enable_retry else max_attempts

        final_result: AgentResult | None = None
        final_attempt: int = base_attempt
        final_sequence_number: int | None = None
        completed_at: datetime | None = None

        for retry_offset in range(total_attempts):
            attempt = base_attempt + retry_offset
            final_attempt = attempt
            started_at = utc_now()

            try:
                # -------------------------------------------------
                # START EVENT (per attempt)
                # -------------------------------------------------
                if self._emitter:
                    self._emitter.emit(
                        NodeExecutionStarted(
                            request_id=request.request_id,
                            timestamp=started_at,
                            node_id=command.node_id,
                            agent=command.agent,
                            attempt=attempt,
                        )
                    )

                # -------------------------------------------------
                # INVOKE
                # -------------------------------------------------
                result = await self._invoke(
                    node_id=command.node_id,
                    agent=agent,
                    request=request,
                    state=state,
                    attempt=attempt,
                )

                final_sequence_number = sequence_number

                completed_at = utc_now()
                final_result = result

                # -------------------------------------------------
                # FAILURE EVENT (per failed attempt)
                # -------------------------------------------------
                if not result.success:
                    if self._emitter:
                        raw_error = (
                            result.metadata.get("error") if result.metadata else None
                        )
                        error_str = (
                            raw_error if isinstance(raw_error, str) else "unknown error"
                        )

                        self._emitter.emit(
                            NodeExecutionFailed(
                                request_id=request.request_id,
                                timestamp=completed_at,
                                node_id=command.node_id,
                                agent=command.agent,
                                attempt=attempt,
                                error=error_str,
                                metadata=result.metadata or {},  # 🔥 KEY
                                sequence_number=sequence_number,
                            )
                        )

                # -------------------------------------------------
                # SUCCESS → EXIT LOOP
                # -------------------------------------------------
                if result.success:
                    break

                # -------------------------------------------------
                # FAILURE → RETRY
                # -------------------------------------------------
                if retry_offset < total_attempts - 1:
                    delay = self._retry.compute_delay(attempt)

                    if self._emitter:
                        self._emitter.emit(
                            NodeExecutionRetried(
                                request_id=request.request_id,
                                timestamp=utc_now(),
                                node_id=command.node_id,
                                agent=command.agent,
                                attempt=attempt,
                                delay_seconds=delay,
                            )
                        )

                    await asyncio.sleep(delay)
                    continue

                # Final failure → exit loop
                break

            except SimulatedHardKillError:
                raise

            except ApprovalRequiredError:
                raise

            except Exception as e:
                completed_at = utc_now()

                failure_result = AgentResult(
                    success=False,
                    output=None,
                    confidence=0.0,
                    metadata={"error": str(e)},
                )

                final_result = failure_result

                final_sequence_number = sequence_number

                # -------------------------------------------------
                # FAILURE EVENT
                # -------------------------------------------------
                if self._emitter:
                    self._emitter.emit(
                        NodeExecutionFailed(
                            request_id=request.request_id,
                            timestamp=completed_at,
                            node_id=command.node_id,
                            agent=command.agent,
                            attempt=attempt,
                            error=str(e),
                            metadata={"error": str(e)},  # 🔥 consistent
                            sequence_number=sequence_number,
                        )
                    )

                # -------------------------------------------------
                # RETRY OR EXIT
                # -------------------------------------------------
                if retry_offset < total_attempts - 1:
                    delay = self._retry.compute_delay(attempt)

                    if self._emitter:
                        self._emitter.emit(
                            NodeExecutionRetried(
                                request_id=request.request_id,
                                timestamp=utc_now(),
                                node_id=command.node_id,
                                agent=command.agent,
                                attempt=attempt,
                                delay_seconds=delay,
                            )
                        )

                    await asyncio.sleep(delay)
                    continue

                break

        # -------------------------------------------------
        # 🔥 FINAL COMPLETION (ONLY ONCE)
        # -------------------------------------------------
        if final_result is None or final_sequence_number is None:
            raise RuntimeError("Execution produced no result")

        if self._emitter:
            self._emitter.emit(
                NodeExecutionCompleted(
                    request_id=request.request_id,
                    timestamp=completed_at or utc_now(),
                    node_id=command.node_id,
                    agent=command.agent,
                    attempt=final_attempt,
                    success=final_result.success,
                    confidence=final_result.confidence,
                    metadata=final_result.metadata or {},
                    output=(
                        final_result.output
                        if isinstance(final_result.output, dict)
                        else None
                    ),
                    sequence_number=sequence_number,
                )
            )

        return final_result

    # ---------------------------------------------------------
    # AGENT RESOLUTION
    # ---------------------------------------------------------

    def _resolve_agent(self, agent_name: str) -> Agent:
        try:
            return self._registry.get(agent_name)
        except KeyError as e:
            raise AgentNotFoundError(agent_name) from e

    # ---------------------------------------------------------
    # INVOCATION CORE
    # ---------------------------------------------------------

    async def _invoke(
        self,
        node_id: str,
        agent: Agent,
        request: ExecutionRequest,
        state: ExecutionState,
        attempt: int,
    ) -> AgentResult:

        payload: dict[str, JSONValue] = {}

        deps = self._graph.dependencies_of(node_id)

        for dep in deps:
            dep_record = state.latest_record(dep)

            if not dep_record:
                continue

            output = dep_record.result.output

            if isinstance(output, dict):
                payload.update(output)

        # Fallback
        if not payload:
            payload = request.payload

        execution_input = ExecutionInput(
            request_id=request.request_id,
            payload=payload,
            metadata=request.metadata,
            scenario=request.resolve_scenario(),
        )

        # ---------------------------------------------------------
        # Scenario-driven failure injection (fail_nodes)
        # ---------------------------------------------------------
        raw_fail_nodes = execution_input.param("fail_nodes", None)

        should_fail = isinstance(raw_fail_nodes, list) and node_id in raw_fail_nodes

        should_fail = False
        if isinstance(raw_fail_nodes, list):
            for v in raw_fail_nodes:
                if isinstance(v, str) and v == node_id:
                    should_fail = True
                    break

        if should_fail:
            return AgentResult(
                success=False,
                output={
                    "error": "Injected failure (fail_nodes)",
                    "node_id": node_id,
                    "request_id": request.request_id,
                },
                confidence=0.0,
                metadata={"non_blocking": True},
            )

        # ---------------------------------------------------------
        # Invoke agent
        # ---------------------------------------------------------
        if inspect.iscoroutinefunction(agent.execute):
            result = await agent.execute(execution_input)
        else:
            result = await asyncio.to_thread(
                cast(Callable[[ExecutionInput], AgentResult], agent.execute),
                execution_input,
            )

        if not isinstance(result, AgentResult):
            raise TypeError(
                f"Agent '{type(agent).__name__}' returned invalid result type: "
                f"{type(result).__name__}"
            )

        return result
