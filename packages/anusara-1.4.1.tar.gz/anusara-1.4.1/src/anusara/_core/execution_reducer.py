from typing import cast

from anusara._contracts.agent_result import AgentResult
from anusara._contracts.events import (
    ExecutionCompleted,
    ExecutionStarted,
    NodeExecutionCompleted,
    NodeExecutionFailed,
    NodeExecutionRetried,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._contracts.json_types import JSONValue
from anusara._routing.execution_graph import ExecutionGraph
from anusara._routing.execution_record import ExecutionRecord
from anusara._routing.execution_state import ExecutionState


class ExecutionReducer:
    """
    Applies orchestration events to reconstruct execution state.

    Guarantees:
    - Deterministic reconstruction
    - Idempotent under replay
    - Event-log driven (no hidden state)
    """

    def apply(
        self,
        event: OrchestrationEvent,
        state: ExecutionState,
        graph: ExecutionGraph,
    ) -> None:
        # -----------------------------------------------------
        # Ignore unrelated events
        # -----------------------------------------------------
        if event.request_id != state.request_id:
            return

        # -----------------------------------------------------
        # Execution START
        # -----------------------------------------------------
        if isinstance(event, ExecutionStarted):
            state.mark_started()
            return

        # -----------------------------------------------------
        # Execution COMPLETED
        # -----------------------------------------------------
        if isinstance(event, ExecutionCompleted):
            state.mark_completed()
            return

        # -----------------------------------------------------
        # Node START
        # -----------------------------------------------------
        if isinstance(event, NodeExecutionStarted):
            state._register_attempt_start(
                event.node_id,
                event.attempt,
                event.timestamp,
            )
            return

        # -----------------------------------------------------
        # Node FAILED
        # -----------------------------------------------------
        if isinstance(event, NodeExecutionFailed):
            started_ts = state._pop_attempt_start(
                event.node_id,
                event.attempt,
            )

            if started_ts is None:
                started_ts = event.timestamp

            existing = state._records.get(event.node_id, [])

            if any(
                r.attempt == event.attempt
                and r.sequence_number == event.sequence_number
                for r in existing
            ):
                return

            failed_metadata: dict[str, JSONValue] = {}

            if event.metadata is not None:
                failed_metadata.update(event.metadata)

            if event.error is not None:
                failed_metadata["error"] = event.error

            record = ExecutionRecord(
                node_id=event.node_id,
                result=AgentResult(
                    success=False,
                    output=None,
                    confidence=0.0,
                    metadata=failed_metadata,
                ),
                attempt=event.attempt,
                sequence_number=event.sequence_number,
                started_at=started_ts,
                completed_at=event.timestamp,
                forced=False,
            )

            state._append_internal(record)
            return

        # -----------------------------------------------------
        # Node COMPLETED
        # -----------------------------------------------------
        if isinstance(event, NodeExecutionCompleted):
            started_ts = state._pop_attempt_start(
                event.node_id,
                event.attempt,
            )

            if started_ts is None:
                started_ts = event.timestamp

            existing = state._records.get(event.node_id, [])

            # Do not override an already-recorded failure for the same attempt
            for r in existing:
                if r.attempt == event.attempt and not r.result.success:
                    return

            if any(
                r.attempt == event.attempt
                and r.sequence_number == event.sequence_number
                for r in existing
            ):
                return

            completed_metadata: dict[str, JSONValue]
            if event.metadata is not None:
                completed_metadata = event.metadata.copy()
            else:
                completed_metadata = {}

            output: dict[str, JSONValue] | None
            if event.output is not None:
                output = event.output.copy()
            else:
                output = None

            record = ExecutionRecord(
                node_id=event.node_id,
                result=AgentResult(
                    success=event.success,
                    output=cast(JSONValue | None, output),
                    confidence=event.confidence,
                    metadata=completed_metadata,
                ),
                attempt=event.attempt,
                sequence_number=event.sequence_number,
                started_at=started_ts,
                completed_at=event.timestamp,
                forced=False,
            )

            state._append_internal(record)
            return

        # -----------------------------------------------------
        # Node RETRIED (no-op)
        # -----------------------------------------------------
        if isinstance(event, NodeExecutionRetried):
            return
