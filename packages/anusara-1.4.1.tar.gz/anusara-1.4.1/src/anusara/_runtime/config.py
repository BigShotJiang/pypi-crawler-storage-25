from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Final

DEFAULT_EVENT_LOG_PATH: Final[str] = "/app/data/events.jsonl"


@dataclass(frozen=True)
class RuntimeConfig:
    event_log_path: str

    @staticmethod
    def from_env() -> RuntimeConfig:
        path = os.getenv("ANUSARA_EVENT_LOG")

        if path is None:
            path = DEFAULT_EVENT_LOG_PATH

        return RuntimeConfig(event_log_path=path)
