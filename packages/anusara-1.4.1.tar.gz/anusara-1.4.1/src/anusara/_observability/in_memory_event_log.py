from collections.abc import Iterator

from anusara._contracts.event_log import ExecutionEventLog
from anusara._contracts.events import OrchestrationEvent


class InMemoryExecutionEventLog(ExecutionEventLog):
    """
    In-memory append-only event log.

    Characteristics:
    - deterministic ordering
    - non-persistent (lifecycle bound to process)
    - fast and lightweight
    - ideal for testing and local execution
    """

    def __init__(self) -> None:
        self._events: list[OrchestrationEvent] = []
        self._seen: set[
            tuple[str, str | None, int | None, type[OrchestrationEvent]]
        ] = set()

    # ---------------------------------------------------------

    def append(self, event: OrchestrationEvent) -> None:
        key = (
            event.request_id,
            getattr(event, "node_id", None),
            getattr(event, "attempt", None),
            type(event),
        )

        if key in self._seen:
            return

        self._seen.add(key)
        self._events.append(event)

    # ---------------------------------------------------------

    def read_all(self) -> list[OrchestrationEvent]:
        return list(self._events)

    def read_by_request(self, request_id: str) -> list[OrchestrationEvent]:
        return [e for e in self._events if e.request_id == request_id]

    # ---------------------------------------------------------

    def stream(self) -> Iterator[OrchestrationEvent]:
        """
        Stream events (snapshot-safe).
        """
        return iter(list(self._events))

    def iter(self) -> Iterator[OrchestrationEvent]:
        """
        Alias for stream() (contract compatibility).
        """
        return self.stream()

    # ---------------------------------------------------------

    def clear(self) -> None:
        self._events.clear()
        self._seen.clear()
