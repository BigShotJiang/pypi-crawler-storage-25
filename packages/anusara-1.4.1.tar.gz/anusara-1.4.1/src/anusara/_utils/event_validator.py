# anusara/_utils/event_validator.py

from __future__ import annotations

from collections import defaultdict
from collections.abc import Iterable

from anusara._contracts.events import (
    NodeExecutionCompleted,
    NodeExecutionStarted,
    OrchestrationEvent,
)
from anusara._routing.execution_graph import ExecutionGraph


class EventInvariantError(Exception):
    """Raised when event stream violates execution invariants."""


class EventInvariantValidator:
    """
    Validates execution event stream invariants.

    Ensures:
    - Attempt lifecycle integrity
    - Monotonic attempt ordering per node
    - Start-before-complete guarantees
    - Topological execution correctness

    This is a read-only, deterministic validator.
    """

    def __init__(self, events: Iterable[OrchestrationEvent]) -> None:
        self.events = list(events)  # materialize for stable indexing

    # ---------------------------------------------------------
    # I-EVT-1 / I-EVT-2 / I-EVT-3
    # ---------------------------------------------------------

    def validate_attempt_integrity(self) -> None:
        starts: list[tuple[int, NodeExecutionStarted]] = []
        completes: list[tuple[int, NodeExecutionCompleted]] = []

        for idx, event in enumerate(self.events):
            if isinstance(event, NodeExecutionStarted):
                starts.append((idx, event))

            elif isinstance(event, NodeExecutionCompleted):
                completes.append((idx, event))

        # -----------------------------------------------------
        # 1. Start/Complete count match
        # -----------------------------------------------------

        if len(starts) != len(completes):
            raise EventInvariantError("Mismatch between start and completion events.")

        # -----------------------------------------------------
        # 2. Attempt monotonicity per node
        # -----------------------------------------------------

        per_node_attempts: dict[str, list[int]] = defaultdict(list)

        for _, event in starts:
            per_node_attempts[event.node_id].append(event.attempt)

        for node_id, attempts in per_node_attempts.items():
            if attempts != sorted(attempts):
                raise EventInvariantError(
                    f"Non-monotonic attempts for node '{node_id}'."
                )

        # -----------------------------------------------------
        # 3. Start must occur before completion (pair-wise)
        # -----------------------------------------------------

        for (start_idx, start_evt), (complete_idx, complete_evt) in zip(
            starts, completes, strict=False
        ):
            if start_idx >= complete_idx:
                raise EventInvariantError(
                    f"Completion before start for node '{start_evt.node_id}'."
                )

            # Optional: enforce same node pairing
            if start_evt.node_id != complete_evt.node_id:
                raise EventInvariantError("Mismatched start/complete pairing detected.")

    # ---------------------------------------------------------
    # I-EVT-4 (Topology correctness)
    # ---------------------------------------------------------

    def validate_topology(self, graph: ExecutionGraph) -> None:
        """
        Ensures that:
        - Parent node completes before child node starts
        """

        # Final completion index per node
        final_completion_index: dict[str, int] = {}

        for idx, event in enumerate(self.events):
            if isinstance(event, NodeExecutionCompleted):
                final_completion_index[event.node_id] = idx

        # -----------------------------------------------------
        # Validate parent → child ordering
        # -----------------------------------------------------

        for parent in graph.nodes:
            parent_completion = final_completion_index.get(parent)

            if parent_completion is None:
                continue  # parent never completed

            for child in graph.children_of(parent):
                # find first child start
                child_start_idx = next(
                    (
                        i
                        for i, e in enumerate(self.events)
                        if isinstance(e, NodeExecutionStarted) and e.node_id == child
                    ),
                    None,
                )

                if child_start_idx is None:
                    continue

                if parent_completion >= child_start_idx:
                    raise EventInvariantError(
                        f"Topology violation: '{parent}' completed after '{child}' started."
                    )
