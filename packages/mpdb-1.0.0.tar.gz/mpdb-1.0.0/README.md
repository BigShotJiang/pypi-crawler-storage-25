# dpdb

`dpdb` is a lightweight distributed debugger built on top of `ipdb`.

## Release Notes

- 1.0.0: first public release version.
    - single-process debugging
    - distributed command broadcast
    - file-based synchronization for non-`torch.distributed` scenarios
    - a built-in web UI
    - switching between web and terminal modes during a session

## Install

```bash
pip install .
```

## Quick Start

```python
import dpdb

def train():
    for step in range(10):
        if step == 5:
            dpdb.set_trace()
```

Run a script directly:

```bash
python -m dpdb your_script.py
```

## Demo

The standalone repository ships with runnable examples under `demo/`:

```bash
python demo/demo_dpdb.py --mode single
python demo/demo_dpdb.py --mode file
python demo/demo_dpdb.py --mode torch
```

There is also a helper launcher for the `torch` demo:

```bash
bash demo/launch_dpdb.sh
```

## Notes

- `torch` is optional and only required when you use `sync_method='torch'`.
- The web UI template is packaged with the wheel and works with `pip install .`.
