import uuid
from datetime import datetime, timedelta, timezone
from typing import Union, Dict, Any, List, Optional
from pydantic import BaseModel
from jose import jwt, JWTError, ExpiredSignatureError
from ..tools.single import Singleton


class Response(BaseModel):
    ok: bool
    msg: str = ""
    data: Union[Dict[str, Any], List[Dict[str, Any]], None] = None


class BaseJWT:
    """
    JWT 基类（模板类）
    子类只需要实现：
    - _encode
    - _decode
    """

    def __init__(
        self,
        access_token_expire_seconds: int = 86400,
        refresh_token_expire_seconds: int = 604800,
        issuer: Optional[str] = None,
        audience: Optional[str] = None,
    ):
        self.access_token_expire_seconds = access_token_expire_seconds
        self.refresh_token_expire_seconds = refresh_token_expire_seconds
        self.issuer = issuer
        self.audience = audience

    # =========================
    # 子类必须实现
    # =========================
    def _encode(self, payload: dict) -> str:
        raise NotImplementedError

    def _decode(self, token: str, verify_exp: bool = True) -> dict:
        raise NotImplementedError

    # ==========================================================
    # 创建 Access + Refresh Token
    # ==========================================================
    def create_at_rf_token(self, payload: dict) -> Response:
        """
        payload 建议：
        {
            "sub": user_id   # 标准字段（用户唯一标识）
        }
        """

        now = datetime.now(timezone.utc)
        jti = uuid.uuid4().hex  # token 唯一ID

        base_payload = {
            **payload,
            "jti": jti,
        }

        # 可选字段（只有配置才加）
        if self.issuer:
            base_payload["iss"] = self.issuer

        if self.audience:
            base_payload["aud"] = self.audience

        # Access Token
        access_payload = {
            **base_payload,
            "token_type": "access",
            "iat": now,
            "exp": now + timedelta(seconds=self.access_token_expire_seconds),
        }

        # Refresh Token
        refresh_payload = {
            **base_payload,
            "token_type": "refresh",
            "iat": now,
            "exp": now + timedelta(seconds=self.refresh_token_expire_seconds),
        }

        return Response(
            ok=True,
            msg="生成成功",
            data={
                "access_token": self._encode(access_payload),
                "refresh_token": self._encode(refresh_payload),
            },
        )

    # ==========================================================
    # 验证 Token（严格校验）
    # ==========================================================
    def verify_token(self, token: str) -> Response:
        try:
            payload = self._decode(token, verify_exp=True)
            return Response(ok=True, msg="验证成功", data=payload)

        except ExpiredSignatureError:
            return Response(ok=False, msg="Token 过期")

        except JWTError:
            return Response(ok=False, msg="Token 非法")

        except Exception as e:
            return Response(ok=False, msg=str(e))

    # ==========================================================
    # 解析 Token（允许过期）
    # ==========================================================
    def parse_token(self, token: str) -> Response:
        """
        用于 refresh 场景
        """
        try:
            payload = self._decode(token, verify_exp=False)
            return Response(ok=True, msg="解析成功", data=payload)

        except JWTError:
            return Response(ok=False, msg="Token 非法")

        except Exception as e:
            return Response(ok=False, msg=str(e))

    # ==========================================================
    # 刷新 Token（仅基础逻辑）
    # ==========================================================
    def refresh_token(self, access_token: str, refresh_token: str) -> Response:
        """
        ⚠️ 注意：
        ✔ 不做黑名单
        ✔ 不做真正“轮换控制”
        ✔ 只负责生成新 token
        """

        # 1. 校验 refresh_token
        rf_res = self.verify_token(refresh_token)
        if not rf_res.ok:
            return rf_res

        rf_payload = rf_res.data

        if rf_payload.get("token_type") != "refresh":
            return Response(ok=False, msg="RefreshToken 非法")

        # 2. 解析 access_token（允许过期）
        at_res = self.parse_token(access_token)
        if not at_res.ok:
            return at_res

        at_payload = at_res.data

        # 3. 校验 jti 一致
        if at_payload.get("jti") != rf_payload.get("jti"):
            return Response(ok=False, msg="Token 不一致")

        # 4. 提取业务 payload（去掉系统字段）
        base_payload = {
            k: v for k, v in at_payload.items() if k not in ["exp", "iat", "token_type"]
        }

        # 5. 生成新 token（⚠️这里只是“重新签发”，不是完整轮换策略）
        return Response(
            ok=True, msg="刷新成功", data=self.create_at_rf_token(base_payload).data
        )


@Singleton
class JWTSymmetry(BaseJWT):
    """
    对称 JWT（HS256）

    ✔ 支持 issuer / audience 可选（None 不校验）
    ✔ 标准 JWT 字段（sub / jti / token_type）
    ✔ 只负责 token 处理（不包含黑名单、轮换策略）
    """

    def __init__(self, secret_key: str, algorithm="HS256", **kwargs):
        super().__init__(**kwargs)
        self.secret_key = secret_key
        self.algorithm = algorithm

    # ==========================================================
    # 内部：编码
    # ==========================================================
    def _encode(self, payload: dict) -> str:
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    # ==========================================================
    # 内部：解码（关键：动态校验 issuer / audience）
    # ==========================================================
    def _decode(self, token: str, verify_exp: bool = True) -> dict:
        """
        支持 issuer / audience 为 None 时自动关闭校验
        """

        options = {
            "verify_exp": verify_exp,
            "verify_aud": self.audience is not None,
            "verify_iss": self.issuer is not None,
        }

        decode_kwargs = {
            "key": self.secret_key,
            "algorithms": [self.algorithm],
            "options": options,
        }

        # 只有配置了才传（否则会报错）
        if self.audience is not None:
            decode_kwargs["audience"] = self.audience

        if self.issuer is not None:
            decode_kwargs["issuer"] = self.issuer

        return jwt.decode(token, **decode_kwargs)

    def create_at_rf_token(self, payload: dict) -> Response:
        return super().create_at_rf_token(payload)

    def verify_token(self, token: str) -> Response:
        # 直接调用父类实现
        return super().verify_token(token)

    def parse_token(self, token: str) -> Response:
        return super().parse_token(token)

    def refresh_token(self, access_token: str, refresh_token: str) -> Response:
        return super().refresh_token(access_token, refresh_token)


@Singleton
class JWTAsymmetry(BaseJWT):
    def __init__(self, private_key: str, public_key: str, algorithm="RS256", **kwargs):
        super().__init__(**kwargs)
        self.private_key = private_key
        self.public_key = public_key
        self.algorithm = algorithm

    # ==========================================================
    # 内部：编码（用私钥签名）
    # ==========================================================
    def _encode(self, payload: dict) -> str:
        return jwt.encode(payload, self.private_key, algorithm=self.algorithm)

    # ==========================================================
    # 内部：解码（用公钥验证 + 动态校验 iss / aud）
    # ==========================================================
    def _decode(self, token: str, verify_exp: bool = True) -> dict:
        """
        ✔ 使用公钥验证签名
        ✔ 支持 issuer / audience 为 None 时不校验
        """

        options = {
            "verify_exp": verify_exp,
            "verify_aud": self.audience is not None,
            "verify_iss": self.issuer is not None,
        }

        decode_kwargs = {
            "key": self.public_key,
            "algorithms": [self.algorithm],
            "options": options,
        }

        # 只有配置了才传，否则会报错
        if self.audience is not None:
            decode_kwargs["audience"] = self.audience

        if self.issuer is not None:
            decode_kwargs["issuer"] = self.issuer

        return jwt.decode(token, **decode_kwargs)

    def create_at_rf_token(self, payload: dict) -> Response:
        return super().create_at_rf_token(payload)

    def verify_token(self, token: str) -> Response:
        # 直接调用父类实现
        return super().verify_token(token)

    def parse_token(self, token: str) -> Response:
        return super().parse_token(token)

    def refresh_token(self, access_token: str, refresh_token: str) -> Response:
        return super().refresh_token(access_token, refresh_token)
