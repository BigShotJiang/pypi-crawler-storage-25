import hashlib
import random
import uuid
from passlib.handlers.pbkdf2 import pbkdf2_sha256


def md5(s: str) -> str:
    """返回字符串的 MD5 值"""
    return hashlib.md5(s.encode("utf-8")).hexdigest()


def random_str() -> str:
    """返回唯一随机字符串（基于 UUID + MD5）"""
    return hashlib.md5(uuid.uuid1().bytes).hexdigest()


def en_password(psw: str) -> str:
    """使用 PBKDF2 进行加密"""
    return pbkdf2_sha256.hash(psw)


def check_password(password: str, hashed: str) -> bool:
    """验证密码"""
    try:
        return pbkdf2_sha256.verify(password, hashed)
    except Exception:
        return False


def code_number(length: int) -> str:
    """生成指定长度的纯数字验证码"""
    return "".join(random.choices("0123456789", k=length))


if __name__ == "__main__":
    password = "25d55ad283aa400af464c76d713c07ad"  # "12345678"
    other = en_password(md5(password))
    print(other)
    print(check_password(md5(password), other))
