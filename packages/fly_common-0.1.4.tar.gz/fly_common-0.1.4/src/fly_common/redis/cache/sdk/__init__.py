# -*- coding: utf-8 -*-
"""SDK 层导出。"""

from fly_common.redis.cache.sdk.decorators import cached, hot_cached

__all__ = ["cached", "hot_cached"]
