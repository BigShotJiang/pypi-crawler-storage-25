# -*- coding: utf-8 -*-
"""缓存装饰器。"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable, Optional

from fly_common.redis.cache.core.cache import RedisCache


def cached(
    cache: RedisCache,
    key_builder: Callable[..., str],
    ttl: Optional[int] = None,
    null_ttl: Optional[int] = None,
    jitter: Optional[int] = None,
    default: Any = None,
) -> Callable:
    """缓存装饰器。

    Args:
        cache: RedisCache 实例。
        key_builder: 生成缓存键的函数，接收原函数参数。
        ttl: 缓存过期时间（秒）。
        null_ttl: 空值缓存时间（秒）。
        jitter: TTL 随机抖动范围（秒）。
        default: 冷启动失败时的默认值。

    Example:
        @cached(cache, lambda user_id: f"user:{user_id}", ttl=300)
        def get_user(user_id):
            return db.query_user(user_id)
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            key = key_builder(*args, **kwargs)
            return cache.get(
                key=key,
                db_func=lambda: func(*args, **kwargs),
                ttl=ttl,
                null_ttl=null_ttl,
                jitter=jitter,
                default=default,
            )

        return wrapper

    return decorator


def hot_cached(
    cache: RedisCache,
    key_builder: Callable[..., str],
    ttl: int = 3600,
    jitter: int = 300,
    null_ttl: int = 60,
) -> Callable:
    """热点数据缓存装饰器（长 TTL）。

    Args:
        cache: RedisCache 实例。
        key_builder: 生成缓存键的函数。
        ttl: 缓存过期时间（秒），默认 3600。
        jitter: TTL 随机抖动范围（秒），默认 300。
        null_ttl: 空值缓存时间（秒）。

    Example:
        @hot_cached(cache, lambda pid: f"product:{pid}")
        def get_product(pid):
            return db.query_product(pid)
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            key = key_builder(*args, **kwargs)
            return cache.get_hot(
                key=key,
                db_func=lambda: func(*args, **kwargs),
                ttl=ttl,
                jitter=jitter,
                null_ttl=null_ttl,
            )

        return wrapper

    return decorator
