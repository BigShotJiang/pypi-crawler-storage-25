# -*- coding: utf-8 -*-
"""FastAPI 接入示例。"""

from fastapi import FastAPI
from pydantic import BaseModel
from redis import Redis

from fly_common.redis.cache import RedisCache, CacheConfig, CachePreset, cached, hot_cached


app = FastAPI(title="cache demo")

# FastAPI 中通常在启动时创建基础设施单例，这里为了演示直接放模块级。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)
config = CacheConfig(namespace="fastapi", default_ttl=60)
cache = RedisCache(redis_client, config=config)


class UserPayload(BaseModel):
    """请求体示例。"""

    name: str


# 模拟数据库
_users_db = {}


def query_user(user_id: str) -> dict | None:
    """模拟数据库查询。"""
    return _users_db.get(user_id)


@app.get("/users/{user_id}")
async def get_user(user_id: str):
    """通过缓存获取用户信息。"""
    data = cache.get(
        key=f"user:{user_id}",
        db_func=lambda: query_user(user_id),
        null_ttl=30,
    )
    return {"user_id": user_id, "data": data}


@app.post("/users/{user_id}")
async def create_user(user_id: str, payload: UserPayload):
    """创建用户并删除缓存。"""
    _users_db[user_id] = {"user_id": user_id, "name": payload.name}
    cache.delete(f"user:{user_id}")
    return {"created": True, "user_id": user_id}


@app.get("/products/{product_id}")
@hot_cached(cache, lambda pid: f"product:{pid}")
async def get_product(product_id: str):
    """通过热点缓存装饰器获取商品信息。"""
    return {"product_id": product_id, "name": f"Product {product_id}"}
