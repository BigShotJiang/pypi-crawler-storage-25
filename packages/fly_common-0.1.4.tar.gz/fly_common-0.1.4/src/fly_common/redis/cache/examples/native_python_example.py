# -*- coding: utf-8 -*-
"""原生 Python 示例。"""

from redis import Redis

from fly_common.redis.cache import RedisCache, CacheConfig, cached


# 创建 Redis 客户端；生产环境请改成你们自己的连接配置。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)

# 使用自定义配置。
config = CacheConfig(
    namespace="demo",
    default_ttl=60,
    default_null_ttl=10,
    default_jitter=30,
)
cache = RedisCache(redis_client, config=config)


def query_user(user_id: str) -> dict:
    """模拟数据库查询。"""
    print(f"Querying database for user: {user_id}")
    return {"user_id": user_id, "name": f"User {user_id}"}


def example_basic_usage():
    """展示最基础的 get 用法。"""
    # 第一次调用会查询数据库
    user = cache.get("user:1001", lambda: query_user("1001"))
    print(f"First call: {user}")

    # 第二次调用会命中缓存
    user = cache.get("user:1001", lambda: query_user("1001"))
    print(f"Second call (cached): {user}")


def example_decorator():
    """展示装饰器用法。"""

    @cached(cache, lambda uid: f"user:{uid}", ttl=120)
    def get_user(uid: str) -> dict:
        return query_user(uid)

    user = get_user("1002")
    print(f"Decorator call: {user}")


def example_stats():
    """展示统计信息。"""
    cache.get("user:1003", lambda: query_user("1003"))
    cache.get("user:1003", lambda: query_user("1003"))
    print(f"Stats: {cache.stats()}")


if __name__ == "__main__":
    example_basic_usage()
    example_decorator()
    example_stats()
