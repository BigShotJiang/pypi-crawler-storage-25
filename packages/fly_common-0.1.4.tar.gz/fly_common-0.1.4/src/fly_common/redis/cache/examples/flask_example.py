# -*- coding: utf-8 -*-
"""Flask 接入示例。"""

from flask import Flask, jsonify
from redis import Redis

from fly_common.redis.cache import RedisCache, CacheConfig, cached


app = Flask(__name__)

# Flask 里也建议把 Cache 做成应用级单例。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)
config = CacheConfig(namespace="flask", default_ttl=60)
cache = RedisCache(redis_client, config=config)


def query_product(product_id: str) -> dict:
    """模拟数据库查询。"""
    return {"product_id": product_id, "name": f"Product {product_id}", "price": 99.9}


@app.get("/products/<product_id>")
def get_product(product_id: str):
    """通过缓存获取商品信息。"""
    data = cache.get(
        key=f"product:{product_id}",
        db_func=lambda: query_product(product_id),
        ttl=300,
    )
    return jsonify(data)


@app.get("/products/<product_id>/hot")
def get_product_hot(product_id: str):
    """通过热点缓存获取商品信息。"""
    data = cache.get_hot(
        key=f"product:{product_id}",
        db_func=lambda: query_product(product_id),
    )
    return jsonify(data)


@app.delete("/products/<product_id>")
def delete_product_cache(product_id: str):
    """删除商品缓存。"""
    cache.delete(f"product:{product_id}")
    return jsonify({"deleted": True})
