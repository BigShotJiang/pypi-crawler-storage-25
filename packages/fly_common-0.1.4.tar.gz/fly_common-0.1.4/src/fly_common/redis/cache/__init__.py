# -*- coding: utf-8 -*-
"""cache 包对外入口。"""

from fly_common.redis.cache.core.cache import RedisCache
from fly_common.redis.cache.core.config import CacheConfig, CachePreset
from fly_common.redis.cache.sdk.decorators import cached, hot_cached

__all__ = [
    "CacheConfig",
    "CachePreset",
    "RedisCache",
    "cached",
    "hot_cached",
]
