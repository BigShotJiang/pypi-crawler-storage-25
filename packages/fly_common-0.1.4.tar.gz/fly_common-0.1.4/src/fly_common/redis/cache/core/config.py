# -*- coding: utf-8 -*-
"""缓存配置定义。"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional


class CacheEvent(str, Enum):
    """缓存事件类型。"""

    HIT = "hit"
    MISS = "miss"
    STALE_HIT = "stale_hit"
    ERROR = "error"


@dataclass
class CacheConfig:
    """缓存客户端配置。

    Attributes:
        namespace: 键命名空间前缀，避免跨业务 key 冲突。
        default_ttl: 默认缓存过期时间（秒）。
        default_null_ttl: 默认空值缓存过期时间（秒）。
        default_jitter: 默认 TTL 随机抖动范围（秒），防止缓存集体过期。
        clock_drift_tolerance: 时钟漂移容差（秒）。
        max_refresh_workers: 刷新线程池最大工作线程数。
        refresh_flag_ttl: refresh_flag 过期时间（秒），防止刷新任务卡住。
        refresh_retry_ttl: 刷新重试过期时间（秒），失败时退避。
        lock_ttl: 冷启动锁过期时间（秒）。
        event_callback: 事件回调函数，用于监控指标。
    """

    namespace: str = "cache"
    default_ttl: int = 60
    default_null_ttl: int = 10
    default_jitter: int = 30
    clock_drift_tolerance: int = 5
    max_refresh_workers: int = 10
    refresh_flag_ttl: int = 30
    refresh_retry_ttl: int = 60
    lock_ttl: int = 10
    event_callback: Optional[Callable[[str, dict[str, Any]], None]] = None

    def validate(self) -> None:
        """校验配置合法性。"""
        if self.default_ttl <= 0:
            raise ValueError("default_ttl must be positive")
        if self.default_null_ttl <= 0:
            raise ValueError("default_null_ttl must be positive")
        if self.max_refresh_workers <= 0:
            raise ValueError("max_refresh_workers must be positive")
        if self.refresh_flag_ttl <= 0:
            raise ValueError("refresh_flag_ttl must be positive")
        if self.lock_ttl <= 0:
            raise ValueError("lock_ttl must be positive")


@dataclass
class CachePreset:
    """缓存预设配置。"""

    @staticmethod
    def hot() -> CacheConfig:
        """热点数据预设（长 TTL）。"""
        return CacheConfig(
            default_ttl=3600,
            default_null_ttl=60,
            default_jitter=300,
        )

    @staticmethod
    def cold() -> CacheConfig:
        """冷数据预设（短 TTL）。"""
        return CacheConfig(
            default_ttl=60,
            default_null_ttl=10,
            default_jitter=30,
        )

    @staticmethod
    def realtime() -> CacheConfig:
        """实时数据预设（极短 TTL）。"""
        return CacheConfig(
            default_ttl=5,
            default_null_ttl=2,
            default_jitter=1,
        )
