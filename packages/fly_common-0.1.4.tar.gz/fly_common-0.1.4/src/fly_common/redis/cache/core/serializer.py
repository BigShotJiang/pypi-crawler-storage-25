# -*- coding: utf-8 -*-
"""缓存序列化器接口与默认实现。"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from typing import Any


class Serializer(ABC):
    """序列化器抽象基类。

    用户可实现此类来使用自定义序列化方式，如 orjson、msgpack 等。
    """

    @abstractmethod
    def dumps(self, obj: Any) -> str:
        """将对象序列化为字符串。"""
        ...

    @abstractmethod
    def loads(self, s: str) -> Any:
        """将字符串反序列化为对象。"""
        ...


class JsonSerializer(Serializer):
    """默认 JSON 序列化器（兼容性最好）。"""

    def dumps(self, obj: Any) -> str:
        return json.dumps(obj, default=str)

    def loads(self, s: str) -> Any:
        return json.loads(s)
