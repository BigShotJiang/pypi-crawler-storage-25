# -*- coding: utf-8 -*-
"""缓存模块异常定义。"""


class CacheError(Exception):
    """缓存基础异常。"""


class CacheConfigurationError(CacheError):
    """缓存配置错误。"""


class CacheConnectionError(CacheError):
    """缓存连接错误。"""


class CacheSerializationError(CacheError):
    """缓存序列化/反序列化错误。"""
