# -*- coding: utf-8 -*-
"""Redis 缓存核心实现。"""

from __future__ import annotations

import atexit
import logging
import random
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from threading import Lock
from typing import Any, Callable, Dict, List, Optional

from fly_common.redis.cache.core.config import CacheConfig, CacheEvent
from fly_common.redis.cache.core.errors import (
    CacheConfigurationError,
    CacheSerializationError,
)
from fly_common.redis.cache.core.serializer import JsonSerializer, Serializer

try:
    from redis import Redis
except Exception:  # pragma: no cover - 允许在未安装 redis 依赖时导入类型占位
    Redis = Any  # type: ignore[misc,assignment]

logger = logging.getLogger(__name__)

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


class _RefreshPoolManager:
    """管理刷新线程池生命周期。"""

    _pools: Dict[int, ThreadPoolExecutor] = {}
    _lock = Lock()

    @classmethod
    def get_pool(cls, max_workers: int) -> ThreadPoolExecutor:
        """获取或创建线程池。"""
        with cls._lock:
            if max_workers not in cls._pools:
                pool = ThreadPoolExecutor(max_workers=max_workers)
                cls._pools[max_workers] = pool
                atexit.register(lambda: pool.shutdown(wait=False))
            return cls._pools[max_workers]


@dataclass
class CacheState:
    """保存当前缓存实例的运行态。"""

    total_hits: int = 0
    total_misses: int = 0
    total_stale_hits: int = 0
    total_errors: int = 0


class RedisCache:
    """面向生产场景的 Redis 缓存客户端。

    通过依赖注入接收 Redis 客户端，支持灵活配置多个实例。
    """

    def __init__(
        self,
        client: Redis,
        config: Optional[CacheConfig] = None,
        serializer: Optional[Serializer] = None,
    ) -> None:
        self.client = client
        self.config = config or CacheConfig()
        self.serializer = serializer or JsonSerializer()
        self.state = CacheState()
        self._refresh_pool = _RefreshPoolManager.get_pool(
            self.config.max_refresh_workers
        )
        self._validate_init()

    def _validate_init(self) -> None:
        """校验配置。"""
        try:
            self.config.validate()
        except ValueError as exc:
            raise CacheConfigurationError(str(exc)) from exc

    def _normalize_key(self, key: str) -> str:
        """为所有 key 统一加 namespace，避免跨业务 key 冲突。"""
        return f"{self.config.namespace}:{key}"

    def _now(self) -> int:
        """获取当前时间戳（秒）。"""
        return int(time.time())

    def _random_ttl(self, ttl: int, jitter: int) -> int:
        """生成带随机抖动的 TTL，防止缓存集体过期。"""
        return ttl + random.randint(0, jitter)

    def _build_data(self, data: Any, ttl: int) -> Dict:
        """构建缓存数据结构。"""
        return {"data": data, "expire_at": self._now() + ttl}

    def _emit_event(
        self, event: CacheEvent, key: str, extra: Optional[Dict] = None
    ) -> None:
        """安全调用事件回调，不影响主流程。"""
        if self.config.event_callback:
            try:
                payload = {"key": key, **(extra or {})}
                self.config.event_callback(event.value, payload)
            except Exception:
                pass

    def _serialize(self, obj: Any) -> str:
        """安全序列化。"""
        try:
            return self.serializer.dumps(obj)
        except Exception as exc:
            raise CacheSerializationError(f"serialization failed: {exc}") from exc

    def _deserialize(self, s: str) -> Any:
        """安全反序列化。"""
        try:
            return self.serializer.loads(s)
        except Exception as exc:
            raise CacheSerializationError(f"deserialization failed: {exc}") from exc

    # ========================
    # 核心缓存方法
    # ========================

    def get(
        self,
        key: str,
        db_func: Callable[[], Any],
        ttl: Optional[int] = None,
        null_ttl: Optional[int] = None,
        jitter: Optional[int] = None,
        default: Any = None,
    ) -> Any:
        """核心缓存读取方法（逻辑过期策略）。

        策略说明：
        1. 先从 Redis 读取缓存
        2. 缓存命中且未过期 → 直接返回（hit）
        3. 缓存命中但已过期 → 触发异步刷新，返回旧数据（stale_hit）
        4. 缓存未命中 → 抢锁后查询数据库（miss）
        5. 抢锁失败 → 降级等待后重试或返回默认值

        Args:
            key: 缓存键。
            db_func: 数据库查询函数（缓存未命中时调用）。
            ttl: 缓存过期时间（秒），默认使用配置值。
            null_ttl: 空值缓存过期时间（秒），默认使用配置值。
            jitter: TTL 随机抖动范围（秒），默认使用配置值。
            default: 冷启动失败时的默认返回值。

        Returns:
            缓存数据或 db_func() 的返回值。
        """
        ttl = ttl if ttl is not None else self.config.default_ttl
        null_ttl = null_ttl if null_ttl is not None else self.config.default_null_ttl
        jitter = jitter if jitter is not None else self.config.default_jitter
        safe_key = self._normalize_key(key)

        # 1. 读取缓存
        try:
            cache_str = self.client.get(safe_key)
        except Exception:
            self._emit_event(CacheEvent.ERROR, key)
            self.state.total_errors += 1
            return db_func()

        # 2. 缓存命中
        if cache_str:
            try:
                cache_data = self._deserialize(cache_str)
            except CacheSerializationError:
                self.client.delete(safe_key)
                self._emit_event(CacheEvent.ERROR, key)
                self.state.total_errors += 1
                return db_func()

            data = cache_data.get("data")
            expire_at = cache_data.get("expire_at", 0)

            # 空值缓存：缓存的是 None，表示数据库中确实没有数据
            # 使用 "data" in cache_data 检查，而不是 data is None
            # 这样可以正确处理 data = False 或 data = 0 的情况
            if "data" in cache_data and data is None:
                self._emit_event(CacheEvent.HIT, key)
                self.state.total_hits += 1
                return None

            # 未过期：正常返回
            if expire_at > (self._now() - self.config.clock_drift_tolerance):
                self._emit_event(CacheEvent.HIT, key)
                self.state.total_hits += 1
                return data

            # 3. 逻辑过期：缓存过期但数据仍可用，触发异步刷新
            refresh_key = self._normalize_key(f"refresh:{key}")

            # 使用 set nx ex 原子操作抢锁，只允许一个线程执行刷新
            if not self.client.get(refresh_key):
                token = uuid.uuid4().hex
                if self.client.set(
                    refresh_key, token, nx=True, ex=self.config.refresh_flag_ttl
                ):
                    self._refresh_pool.submit(
                        self._do_refresh,
                        key,
                        safe_key,
                        db_func,
                        ttl,
                        null_ttl,
                        jitter,
                        refresh_key,
                        token,
                    )

            # 返回过期数据（带病运行），不影响业务
            self._emit_event(CacheEvent.STALE_HIT, key)
            self.state.total_stale_hits += 1
            return data

        # 4. 缓存未命中（冷启动）
        self._emit_event(CacheEvent.MISS, key)
        self.state.total_misses += 1

        lock_key = self._normalize_key(f"lock:{key}")

        # 非阻塞抢锁：抢到锁的线程负责回源
        if self.client.set(lock_key, "1", nx=True, ex=self.config.lock_ttl):
            try:
                result = db_func()

                # 空值缓存：防止缓存穿透（数据库也没有的数据）
                if result is None:
                    self.client.set(
                        safe_key,
                        self._serialize(self._build_data(None, null_ttl)),
                        ex=self._random_ttl(null_ttl, jitter),
                    )
                    return None

                # 正常写入缓存
                self.client.set(
                    safe_key,
                    self._serialize(self._build_data(result, ttl)),
                    ex=self._random_ttl(ttl, jitter),
                )
                return result

            finally:
                # 释放锁
                self.client.delete(lock_key)

        else:
            # 抢锁失败：降级等待后重试，避免线程阻塞
            time.sleep(0.02)

            try:
                cache_str = self.client.get(safe_key)
                if cache_str:
                    return self._deserialize(cache_str)["data"]
            except Exception:
                pass

            return default

    def _do_refresh(
        self,
        key: str,
        safe_key: str,
        db_func: Callable,
        ttl: int,
        null_ttl: int,
        jitter: int,
        refresh_key: str,
        token: str,
    ) -> None:
        """异步刷新缓存的执行逻辑。

        在独立线程中执行，不阻塞主请求。
        """
        start = time.time()

        try:
            result = db_func()

            if result is None:
                self.client.set(
                    safe_key,
                    self._serialize(self._build_data(None, null_ttl)),
                    ex=self._random_ttl(null_ttl, jitter),
                )
            else:
                self.client.set(
                    safe_key,
                    self._serialize(self._build_data(result, ttl)),
                    ex=self._random_ttl(ttl, jitter),
                )

            # 只删除自己设置的 refresh_flag（防误删其他线程的）
            if self.client.get(refresh_key) == token:
                self.client.delete(refresh_key)

            logger.info(
                f"[CACHE] refresh success: {key}, cost={time.time() - start:.3f}s"
            )

        except Exception as e:
            # 刷新失败：延长 refresh_flag 过期时间，实现退避策略
            self.client.expire(refresh_key, self.config.refresh_retry_ttl)
            logger.warning(f"[CACHE] refresh failed: {key}, err={e}")

    # ========================
    # 热点缓存快捷方法
    # ========================

    def get_hot(
        self,
        key: str,
        db_func: Callable[[], Any],
        ttl: int = 3600,
        jitter: int = 300,
        null_ttl: int = 60,
    ) -> Any:
        """热点数据缓存（长 TTL，适用于频繁访问的数据）。

        Args:
            key: 缓存键。
            db_func: 数据库查询函数。
            ttl: 缓存过期时间（秒），默认 3600（1小时）。
            jitter: TTL 随机抖动范围（秒），默认 300（5分钟）。
            null_ttl: 空值缓存时间（秒），默认 60。
        """
        return self.get(
            key=key,
            db_func=db_func,
            ttl=ttl,
            jitter=jitter,
            null_ttl=null_ttl,
            default={},
        )

    # ========================
    # 运维方法
    # ========================

    def delete(self, key: str) -> None:
        """强制删除缓存键及其相关键。

        Args:
            key: 缓存键。
        """
        safe_key = self._normalize_key(key)
        pipe = self.client.pipeline()
        pipe.delete(safe_key)
        pipe.delete(self._normalize_key(f"refresh:{key}"))
        pipe.delete(self._normalize_key(f"lock:{key}"))
        pipe.execute()

    def warm_up(self, keys: List[str], loader: Callable[[str], Any]) -> None:
        """批量预热缓存。

        Args:
            keys: 需要预热的缓存键列表。
            loader: 缓存加载函数，接收 key 参数。
        """
        for key in keys:
            self._refresh_pool.submit(
                self.get,
                key,
                lambda k=key: loader(k),  # 使用默认参数避免闭包问题
                3600,
                60,
                300,
            )

    def stats(self) -> Dict[str, int]:
        """获取缓存统计信息。"""
        return {
            "total_hits": self.state.total_hits,
            "total_misses": self.state.total_misses,
            "total_stale_hits": self.state.total_stale_hits,
            "total_errors": self.state.total_errors,
        }
