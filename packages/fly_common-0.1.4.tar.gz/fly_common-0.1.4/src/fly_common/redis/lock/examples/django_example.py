# -*- coding: utf-8 -*-
"""Django 接入示例。"""

from django.http import JsonResponse
from redis import Redis

from fly_common.redis.lock import LockPreset, RedisLockSDK


# 实际项目里建议把客户端和 SDK 放进 Django settings 对应的基础设施模块。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)
sdk = RedisLockSDK(redis_client, LockPreset.strict()).with_namespace("django")


def update_inventory_service(product_id: str, delta: int) -> None:
    """把 service 层作为真正持锁的地方。"""
    with sdk.lock_for_resource("inventory", product_id) as lock:
        def do_update() -> None:
            print(f"update inventory for {product_id}, delta={delta}")

        lock.guarded_execute(do_update)


def update_inventory_view(request, product_id: str):
    """在 view 中调用 service，不把锁逻辑散落到控制器。"""
    delta = int(request.POST.get("delta", "1"))
    update_inventory_service(product_id, delta)
    return JsonResponse({"ok": True, "product_id": product_id, "delta": delta})
