# -*- coding: utf-8 -*-
"""Flask 接入示例。"""

from flask import Flask, jsonify, request
from redis import Redis

from fly_common.redis.lock import LockPreset, RedisLockSDK


app = Flask(__name__)

# Flask 里也建议把 SDK 做成应用级单例。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)
sdk = RedisLockSDK(redis_client, LockPreset.strict()).with_namespace("flask")


@app.post("/orders/<order_id>/settle")
def settle_order(order_id: str):
    """用 with 明确包住关键资源。"""
    with sdk.lock_for_resource("order", order_id) as lock:
        def do_settle() -> dict:
            amount = request.json.get("amount", 0) if request.is_json else 0
            return {"order_id": order_id, "amount": amount, "status": "settled"}

        result = lock.guarded_execute(do_settle)
    return jsonify(result)
