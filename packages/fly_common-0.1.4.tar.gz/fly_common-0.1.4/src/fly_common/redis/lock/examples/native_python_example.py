# -*- coding: utf-8 -*-
"""原生 Python 示例。"""

from redis import Redis

from fly_common.redis.lock import LockPreset, RedisLockSDK


# 创建 Redis 客户端；生产环境请改成你们自己的连接配置。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)

# 使用严格预设，默认开启 fencing、lease 校验和 strict mode。
sdk = RedisLockSDK(redis_client, LockPreset.strict())


def settle_order(order_id: str) -> None:
    """展示最简单的 with 接入方式。"""
    with sdk.lock(f"order:{order_id}") as lock:
        # 关键逻辑放在 guarded_execute 里，执行前后都校验租约。
        lock.guarded_execute(lambda: print(f"settling order {order_id}"))


if __name__ == "__main__":
    settle_order("1001")
