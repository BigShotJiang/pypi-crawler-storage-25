# -*- coding: utf-8 -*-
"""FastAPI 接入示例。"""

from fastapi import FastAPI
from pydantic import BaseModel
from redis import Redis

from fly_common.redis.lock import LockPreset, RedisLockSDK


app = FastAPI(title="lock demo")

# FastAPI 中通常在启动时创建基础设施单例，这里为了演示直接放模块级。
redis_client = Redis(host="127.0.0.1", port=6379, db=0, decode_responses=False)
sdk = RedisLockSDK(redis_client, LockPreset.strict()).with_namespace("fastapi")


class InventoryPayload(BaseModel):
    """请求体示例。"""

    delta: int


@app.post("/inventory/{product_id}")
async def update_inventory(product_id: str, payload: InventoryPayload):
    """演示在接口层通过 SDK 保护共享资源。"""
    with sdk.lock_for_resource("inventory", product_id) as lock:
        result = lock.guarded_execute(
            lambda: {
                "product_id": product_id,
                "delta": payload.delta,
                "fencing_headers": lock.fencing_headers(),
            }
        )
    return result
