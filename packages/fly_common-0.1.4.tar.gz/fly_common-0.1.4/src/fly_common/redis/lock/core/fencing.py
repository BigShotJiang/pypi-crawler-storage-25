# -*- coding: utf-8 -*-
"""Fencing token provider 与回退检测。"""

from __future__ import annotations

from dataclasses import dataclass, field
from threading import Lock
from typing import Protocol

from fly_common.redis.lock.core.errors import TokenRollbackError


class SupportsRedis(Protocol):
    """描述 Redis fencing provider 需要的最小客户端能力。"""
    def incr(self, name: str) -> int:
        ...


class FencingProvider(Protocol):
    """所有 fencing provider 都要实现的统一协议。"""
    def next_token(self, lock_key: str) -> int:
        ...

    def validate_monotonic(self, lock_key: str, token: int) -> None:
        ...


@dataclass
class RedisFencingProvider:
    """基于 Redis 自增计数器生成单调递增 token。"""

    client: SupportsRedis
    token_prefix: str = "lock:fencing"
    _last_seen_by_key: dict[str, int] = field(default_factory=dict)
    _guard: Lock = field(default_factory=Lock)

    def next_token(self, lock_key: str) -> int:
        """获取下一个 token，并做本地单调校验。"""
        token = int(self.client.incr(f"{self.token_prefix}:{lock_key}"))
        self.validate_monotonic(lock_key, token)
        return token

    def validate_monotonic(self, lock_key: str, token: int) -> None:
        """检测 token 是否发生回退。"""
        with self._guard:
            previous = self._last_seen_by_key.get(lock_key)
            if previous is not None and token <= previous:
                raise TokenRollbackError(
                    f"fencing token rollback detected for {lock_key}: {token} <= {previous}"
                )
            self._last_seen_by_key[lock_key] = token


@dataclass
class NullFencingProvider:
    """在关闭 fencing 时使用的空实现。"""

    def next_token(self, lock_key: str) -> int:
        """禁用 fencing 时统一返回 0。"""
        return 0

    def validate_monotonic(self, lock_key: str, token: int) -> None:
        """空实现不做任何校验。"""
        return None
