# -*- coding: utf-8 -*-
"""后台续期调度器。"""

from __future__ import annotations

from dataclasses import dataclass
from threading import Event, Lock, Thread
from time import monotonic, sleep
from typing import Dict, Protocol


class RenewableLock(Protocol):
    """定义 watchdog 依赖的最小锁接口。"""
    owner_id: str
    safe_key: str

    def renew(self) -> bool:
        ...

    def mark_lease_lost(self, reason: str) -> None:
        ...


@dataclass
class WatchdogEntry:
    """调度器内部维护的任务条目。"""
    lock: RenewableLock
    interval: float
    last_run: float


class WatchdogScheduler:
    """单进程 watchdog，支持空闲自动退出。"""

    def __init__(self) -> None:
        # owner_id 作为唯一键，避免同一锁重复注册多个续期任务。
        self._entries: Dict[str, WatchdogEntry] = {}
        self._guard = Lock()
        self._stop_event = Event()
        self._thread: Thread | None = None

    def register(self, lock: RenewableLock, interval: float) -> None:
        """注册需要自动续期的锁。"""
        with self._guard:
            self._entries[lock.owner_id] = WatchdogEntry(
                lock=lock,
                interval=interval,
                last_run=0.0,
            )
            if self._thread is None or not self._thread.is_alive():
                self._stop_event.clear()
                self._thread = Thread(target=self._run, name="redis-lock-watchdog", daemon=True)
                self._thread.start()

    def unregister(self, owner_id: str) -> None:
        """移除不再需要续期的锁；当队列为空时自动停线程。"""
        with self._guard:
            self._entries.pop(owner_id, None)
            if not self._entries:
                self._stop_event.set()

    def _run(self) -> None:
        """循环续期所有到期任务。"""
        while not self._stop_event.is_set():
            now = monotonic()
            due_entries: list[WatchdogEntry] = []
            with self._guard:
                # 复制出到期条目，避免持锁执行网络 IO。
                due_entries = [
                    entry
                    for entry in self._entries.values()
                    if now - entry.last_run >= entry.interval
                ]
            for entry in due_entries:
                try:
                    renewed = entry.lock.renew()
                    if not renewed:
                        entry.lock.mark_lease_lost("watchdog renewal failed")
                finally:
                    entry.last_run = monotonic()
            sleep(0.2)
