# -*- coding: utf-8 -*-
"""领域异常定义。"""


class RedisLockError(Exception):
    """组件基础异常。"""


class LockConfigurationError(RedisLockError):
    """配置非法时抛出。"""


class LockAcquireError(RedisLockError):
    """获取锁失败时抛出。"""


class LockReleaseError(RedisLockError):
    """释放锁失败且需要显式处理时抛出。"""


class LeaseLostError(RedisLockError):
    """租约丢失时抛出。"""


class TokenRollbackError(RedisLockError):
    """fencing token 回退时抛出。"""
