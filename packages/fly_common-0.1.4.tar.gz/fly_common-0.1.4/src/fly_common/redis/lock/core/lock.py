# -*- coding: utf-8 -*-
"""Redis 分布式锁核心实现。"""

from __future__ import annotations

from dataclasses import dataclass
from threading import Event, Lock
from time import monotonic, sleep
from typing import Any, Iterable, Iterator, Optional
from uuid import uuid4

from fly_common.redis.lock.core.config import LockConfig
from fly_common.redis.lock.core.errors import (
    LeaseLostError,
    LockAcquireError,
    LockConfigurationError,
    LockReleaseError,
)
from fly_common.redis.lock.core.events import LockEvent, emit_event
from fly_common.redis.lock.core.fencing import FencingProvider, NullFencingProvider, RedisFencingProvider
from fly_common.redis.lock.core.watchdog import WatchdogScheduler

try:
    from redis import Redis
except Exception:  # pragma: no cover - 允许在未安装 redis 依赖时导入类型占位
    Redis = Any  # type: ignore[misc,assignment]


# 通过 Lua 保证“检查并设置”原子化，避免并发下被多个客户端同时拿到锁。
_ACQUIRE_SCRIPT = """
if #KEYS < 1 or #ARGV < 3 then
  return {err = "invalid lua args"}
end
if redis.call("exists", KEYS[1]) == 0 then
  redis.call("hset", KEYS[1], "owner_id", ARGV[1], "token", ARGV[2])
  redis.call("expire", KEYS[1], ARGV[3])
  return 1
end
return 0
"""


# 续期时必须再次确认 owner_id，防止旧持有者误续期新持有者的锁。
_RENEW_SCRIPT = """
if #KEYS < 1 or #ARGV < 2 then
  return {err = "invalid lua args"}
end
local owner = redis.call("hget", KEYS[1], "owner_id")
if owner == ARGV[1] then
  return redis.call("expire", KEYS[1], ARGV[2])
end
return 0
"""


# 释放锁同样要求 owner_id 一致，保证释放行为幂等且安全。
_RELEASE_SCRIPT = """
if #KEYS < 1 or #ARGV < 1 then
  return {err = "invalid lua args"}
end
local owner = redis.call("hget", KEYS[1], "owner_id")
if owner == ARGV[1] then
  return redis.call("del", KEYS[1])
end
return 0
"""


@dataclass
class LockState:
    """保存当前锁实例的运行态。"""

    acquired: bool = False
    fencing_token: int = 0
    lease_lost_reason: str = ""
    lease_lost_notified: bool = False


class RedisLock:
    """面向生产场景的 Redis 分布式锁。"""

    # 进程级计数器用于限制单进程内同时持有的锁数量，防止误用压垮本地资源。
    _process_lock_count = 0
    _process_guard = Lock()
    _watchdog = WatchdogScheduler()

    def __init__(
        self,
        client: Redis,
        key: str,
        config: LockConfig,
        fencing_provider: Optional[FencingProvider] = None,
    ) -> None:
        # 初始化时只做参数合法性检查，不提前占用进程级锁配额。
        self.client = client
        self.key = key
        self.config = config
        self.owner_id = str(uuid4())
        self.safe_key = self._normalize_key(key)
        self.state = LockState()
        self.cancel_flag = Event()
        self._fencing_provider = fencing_provider or self._build_fencing_provider()
        self._validate_init()

    def _validate_init(self) -> None:
        """校验配置和 key 基础约束。"""
        try:
            self.config.validate()
        except ValueError as exc:
            raise LockConfigurationError(str(exc)) from exc
        if len(self.key) > self.config.max_key_length:
            raise LockConfigurationError("lock key exceeds max_key_length")

    def _build_fencing_provider(self) -> FencingProvider:
        """根据配置构造 fencing provider。"""
        if self.config.fencing_mode == "redis":
            return RedisFencingProvider(client=self.client)
        if self.config.fencing_mode == "external":
            raise LockConfigurationError(
                "external fencing_mode requires an explicit fencing_provider"
            )
        return NullFencingProvider()

    def _normalize_key(self, key: str) -> str:
        """为所有锁统一加 namespace，避免跨业务 key 冲突。"""
        return f"{self.config.namespace}:{key}"

    def acquire(self) -> bool:
        """获取锁；阻塞与否由配置决定。"""
        if self.state.acquired:
            raise LockAcquireError(f"lock already acquired by this instance: {self.safe_key}")

        deadline = monotonic() + self.config.blocking_timeout
        while True:
            self._assert_process_capacity()
            token = self._fencing_provider.next_token(self.safe_key)
            acquired = bool(
                self.client.eval(
                    _ACQUIRE_SCRIPT,
                    1,
                    self.safe_key,
                    self.owner_id,
                    token,
                    self.config.ttl_seconds,
                )
            )
            if acquired:
                if not self._confirm_ownership():
                    self._release_owned_key()
                    raise LockAcquireError("ownership confirmation failed")
                if self.config.ttl_final_check_enabled and not self._check_redis_ttl_sufficient():
                    self._release_owned_key()
                    raise LockAcquireError("redis ttl final check failed")

                # 成功后再切换运行态，避免半初始化状态泄漏到业务层。
                self.state.acquired = True
                self.state.fencing_token = token
                self.state.lease_lost_reason = ""
                self.state.lease_lost_notified = False
                self.cancel_flag.clear()
                self._increase_process_lock_count()
                if self.config.watchdog_enabled:
                    self._watchdog.register(self, self.config.watchdog_interval)
                emit_event(
                    self.config.event_callback,
                    LockEvent("lock_acquired", self.safe_key, self.owner_id, {"token": token}),
                )
                return True

            if not self.config.blocking:
                return False
            if monotonic() >= deadline:
                return False
            sleep(self.config.retry_interval)

    def release(self) -> bool:
        """释放锁；已经失效或未获取时保持幂等。"""
        if not self.state.acquired:
            return True

        self._watchdog.unregister(self.owner_id)
        released = bool(self.client.eval(_RELEASE_SCRIPT, 1, self.safe_key, self.owner_id))

        # 无论 Redis 是否仍然承认 ownership，本地状态都必须收敛，避免计数泄漏。
        self._transition_to_released()
        emit_event(
            self.config.event_callback,
            LockEvent("lock_released", self.safe_key, self.owner_id, {"released": released}),
        )
        if not released and self.config.strict_mode:
            raise LockReleaseError(f"release rejected because ownership changed: {self.safe_key}")
        return released

    def renew(self) -> bool:
        """手动续期；失败时根据配置决定是否宣布租约丢失。"""
        if not self.state.acquired:
            return False

        renewed = bool(
            self.client.eval(
                _RENEW_SCRIPT,
                1,
                self.safe_key,
                self.owner_id,
                self.config.ttl_seconds,
            )
        )
        if not renewed and self.config.lease_validation_enabled:
            self.mark_lease_lost("renew failed")
        return renewed

    def validate_lease(self) -> None:
        """校验当前实例仍然持有这把锁。"""
        if not self.state.acquired:
            raise LeaseLostError("lock is not acquired")

        owner = self.client.hget(self.safe_key, "owner_id")
        normalized_owner = self._decode(owner)
        if normalized_owner != self.owner_id:
            self.mark_lease_lost("redis ownership verification failed")
            raise LeaseLostError(self.state.lease_lost_reason)

    def guarded_execute(self, func: Any, *args: Any, **kwargs: Any) -> Any:
        """在执行前后做租约校验，适合中短任务。"""
        self.validate_lease()
        result = func(*args, **kwargs)
        self.validate_lease()
        return result

    def guarded_iterator(self, iterable: Iterable[Any]) -> Iterator[Any]:
        """在迭代边界持续校验租约，适合批处理和遍历场景。"""
        for item in iterable:
            self.validate_lease()
            yield item

    def mark_lease_lost(self, reason: str) -> None:
        """标记租约丢失，并且只做一次状态收敛和事件通知。"""
        if self.state.lease_lost_notified:
            return

        self.state.lease_lost_reason = reason
        self.state.lease_lost_notified = True
        self._watchdog.unregister(self.owner_id)
        self._transition_to_released()
        emit_event(
            self.config.event_callback,
            LockEvent("lease_lost", self.safe_key, self.owner_id, {"reason": reason}),
        )

    def fencing_headers(self) -> dict[str, str]:
        """给 HTTP/RPC 场景导出 fencing token。"""
        if self.state.fencing_token <= 0:
            return {}
        return {"X-Fencing-Token": str(self.state.fencing_token)}

    def execute_update(
        self,
        table: str,
        values: dict[str, Any],
        where: dict[str, Any],
        fencing_column: str = "fencing_token",
    ) -> tuple[str, list[Any]]:
        """生成带 fencing 防护的结构化 UPDATE 语句。"""
        self._validate_sql_identifier(table)
        self._validate_sql_identifier(fencing_column)
        values = dict(values)
        where = dict(where)
        for column in values:
            self._validate_sql_identifier(column)
        for column in where:
            self._validate_sql_identifier(column)
        if self.config.strict_mode and (not values or not where):
            raise LockConfigurationError("strict_mode requires non-empty values and where")
        if self.config.auto_inject_fencing_column and self.state.fencing_token:
            # 既写入新 token，也把旧 token 拦在 WHERE 条件外，防止旧写覆盖新写。
            values[fencing_column] = self.state.fencing_token

        set_clause = ", ".join(f"{column} = %s" for column in values)
        where_clause = " AND ".join(f"{column} = %s" for column in where)
        params = list(values.values()) + list(where.values())
        if self.config.auto_inject_fencing_column and self.state.fencing_token:
            where_clause = (
                f"{where_clause} AND ({fencing_column} IS NULL OR {fencing_column} < %s)"
            )
            params.append(self.state.fencing_token)

        sql = f"UPDATE {table} SET {set_clause} WHERE {where_clause}"
        return sql, params

    def execute_delete(self, table: str, where: dict[str, Any]) -> tuple[str, list[Any]]:
        """生成结构化 DELETE 语句，避免业务层手写裸 SQL。"""
        self._validate_sql_identifier(table)
        where = dict(where)
        for column in where:
            self._validate_sql_identifier(column)
        if self.config.strict_mode and not where:
            raise LockConfigurationError("strict_mode requires non-empty where")
        where_clause = " AND ".join(f"{column} = %s" for column in where)
        sql = f"DELETE FROM {table} WHERE {where_clause}"
        params = list(where.values())
        return sql, params

    def _confirm_ownership(self) -> bool:
        """获取成功后再次确认 ownership，降低幽灵锁风险。"""
        if not self.config.ownership_check_enabled:
            return True
        owner = self.client.hget(self.safe_key, "owner_id")
        return self._decode(owner) == self.owner_id

    def _check_redis_ttl_sufficient(self) -> bool:
        """获取成功后检查剩余 TTL 是否足够，避免马上过期。"""
        ttl = int(self.client.ttl(self.safe_key))
        minimum = max(1, int(self.config.ttl_seconds * 0.5))
        return ttl >= minimum

    def _validate_sql_identifier(self, identifier: str) -> None:
        """对表名和字段名做最基本的白名单校验。"""
        if not identifier.replace("_", "").isalnum():
            raise LockConfigurationError(f"invalid sql identifier: {identifier}")

    def _decode(self, value: Any) -> str:
        """兼容 Redis bytes/str 返回。"""
        if isinstance(value, bytes):
            return value.decode("utf-8")
        return "" if value is None else str(value)

    @classmethod
    def _increase_process_lock_count(cls) -> None:
        """在获取锁成功后累加进程级计数。"""
        with cls._process_guard:
            cls._process_lock_count += 1

    def _assert_process_capacity(self) -> None:
        """在真正加锁前校验进程内配额。"""
        with self._process_guard:
            if self._process_lock_count >= self.config.max_concurrent_locks_per_process:
                raise LockConfigurationError("too many concurrent locks in one process")

    @classmethod
    def _decrease_process_lock_count(cls) -> None:
        """在释放或丢锁后回收进程级计数。"""
        with cls._process_guard:
            cls._process_lock_count = max(0, cls._process_lock_count - 1)

    def _release_owned_key(self) -> None:
        """仅在当前 owner 仍被 Redis 承认时清理锁 key。"""
        self.client.eval(_RELEASE_SCRIPT, 1, self.safe_key, self.owner_id)

    def _transition_to_released(self) -> None:
        """统一收敛本地状态，避免不同释放路径出现漏回收。"""
        was_acquired = self.state.acquired
        self.state.acquired = False
        self.state.fencing_token = 0
        self.cancel_flag.set()
        if was_acquired:
            self._decrease_process_lock_count()

    def __enter__(self) -> "RedisLock":
        """支持 with 语法。"""
        acquired = self.acquire()
        if not acquired:
            raise LockAcquireError(f"failed to acquire lock: {self.safe_key}")
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        """优先保留业务异常，不让释放异常覆盖原始错误。"""
        try:
            self.release()
        except LockReleaseError:
            if exc_type is None:
                raise
