# -*- coding: utf-8 -*-
"""事件与可观测性辅助工具。"""

from __future__ import annotations

from dataclasses import dataclass, field
from time import time
from typing import Dict, Optional

from fly_common.redis.lock.core.config import EventCallback


@dataclass
class LockEvent:
    """统一事件载荷结构，方便接 Prometheus、日志或审计系统。"""

    name: str
    lock_key: str
    owner_id: str
    metadata: Dict[str, object] = field(default_factory=dict)
    timestamp: float = field(default_factory=time)


def emit_event(callback: Optional[EventCallback], event: LockEvent) -> None:
    """发射事件；监控回调异常不能影响锁主流程。"""
    if callback is None:
        return
    try:
        callback(
            event.name,
            {
                "lock_key": event.lock_key,
                "owner_id": event.owner_id,
                "metadata": event.metadata,
                "timestamp": event.timestamp,
            },
        )
    except Exception:
        # 观测逻辑属于旁路能力，不允许反向破坏锁的正确性。
        return
