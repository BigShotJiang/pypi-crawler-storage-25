# -*- coding: utf-8 -*-
"""锁配置与预设。"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Optional


# 事件回调统一采用事件名 + 字典载荷，方便和监控系统对接。
EventCallback = Callable[[str, dict], None]


@dataclass(frozen=True)
class LockConfig:
    """定义 core 与 sdk 共享的锁行为契约。"""

    namespace: str = "lock"
    ttl_seconds: int = 30
    blocking: bool = True
    blocking_timeout: float = 10.0
    retry_interval: float = 0.2
    watchdog_enabled: bool = True
    watchdog_interval: float = 10.0
    lease_validation_enabled: bool = True
    ownership_check_enabled: bool = True
    ttl_final_check_enabled: bool = True
    strict_mode: bool = True
    fencing_mode: str = "redis"
    max_key_length: int = 128
    max_concurrent_locks_per_process: int = 128
    auto_inject_fencing_column: bool = True
    event_callback: Optional[EventCallback] = None

    def validate(self) -> None:
        """校验配置边界，尽量在初始化阶段就暴露错误。"""
        if not self.namespace.strip():
            raise ValueError("namespace must not be empty")
        if self.ttl_seconds < 5:
            raise ValueError("ttl_seconds must be >= 5")
        if self.watchdog_enabled and self.watchdog_interval <= 0:
            raise ValueError("watchdog_interval must be positive")
        if self.watchdog_enabled and self.watchdog_interval >= self.ttl_seconds:
            raise ValueError("watchdog_interval must be smaller than ttl_seconds")
        if self.blocking_timeout < 0:
            raise ValueError("blocking_timeout must be >= 0")
        if self.retry_interval <= 0:
            raise ValueError("retry_interval must be positive")
        if self.max_key_length < 8:
            raise ValueError("max_key_length must be >= 8")
        if self.max_concurrent_locks_per_process < 1:
            raise ValueError("max_concurrent_locks_per_process must be >= 1")
        if self.fencing_mode not in {"none", "redis", "external"}:
            raise ValueError("fencing_mode must be one of none, redis, external")


class LockPreset:
    """用预设降低复杂配置对业务方的认知负担。"""

    @staticmethod
    def default() -> LockConfig:
        """默认预设，适合普通场景。"""
        return LockConfig()

    @staticmethod
    def strict() -> LockConfig:
        """严格预设，优先保证锁安全。"""
        return LockConfig(
            fencing_mode="redis",
            strict_mode=True,
            lease_validation_enabled=True,
            ownership_check_enabled=True,
            ttl_final_check_enabled=True,
        )

    @staticmethod
    def high_availability() -> LockConfig:
        """高可用预设，适合锁持有时间更长的任务。"""
        return LockConfig(
            ttl_seconds=60,
            watchdog_interval=20.0,
            fencing_mode="redis",
            blocking_timeout=15.0,
        )
