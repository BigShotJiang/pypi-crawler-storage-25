# -*- coding: utf-8 -*-
"""装饰器形式的接入辅助。"""

from __future__ import annotations

from functools import wraps
from typing import Any, Callable

from fly_common.redis.lock.sdk.manager import RedisLockSDK


def synchronized(
    sdk: RedisLockSDK, key_builder: Callable[..., str]
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    """把业务函数包装进分布式锁边界。"""

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # key_builder 由业务方定义，确保 key 能表达真正的资源唯一性。
            key = key_builder(*args, **kwargs)
            with sdk.lock(key) as lock:
                return lock.guarded_execute(func, *args, **kwargs)

        return wrapper

    return decorator
