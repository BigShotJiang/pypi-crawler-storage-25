# -*- coding: utf-8 -*-
"""SDK 稳定入口。"""

from __future__ import annotations

from dataclasses import replace
from typing import Any, Callable, Optional

from fly_common.redis.lock.core.config import LockConfig
from fly_common.redis.lock.core.lock import RedisLock


class RedisLockSDK:
    """业务侧统一通过这个类创建锁实例。"""

    def __init__(self, redis_client: Any, config: Optional[LockConfig] = None) -> None:
        # SDK 固定住默认配置，避免业务层到处复制参数。
        self.redis_client = redis_client
        self.config = config or LockConfig()

    def lock(self, key: str, *, config: Optional[LockConfig] = None) -> RedisLock:
        """按 key 创建锁实例。"""
        return RedisLock(self.redis_client, key, config or self.config)

    def lock_for_resource(self, resource_type: str, resource_id: str) -> RedisLock:
        """按资源类型和资源 ID 构造标准锁 key。"""
        return self.lock(f"{resource_type}:{resource_id}")

    def with_namespace(self, namespace: str) -> "RedisLockSDK":
        """返回带新 namespace 的 SDK 副本。"""
        return RedisLockSDK(self.redis_client, replace(self.config, namespace=namespace))

    def guarded_call(self, key: str, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """为简单场景提供一行式受保护调用。"""
        with self.lock(key) as lock:
            return lock.guarded_execute(func, *args, **kwargs)
