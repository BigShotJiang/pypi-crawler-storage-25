import json
import time
import random
import logging
import threading
from typing import Dict, Any, List, Union, Optional, Tuple

from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_dysmsapi20170525 import models as dy_sms_api_models
from alibabacloud_dysmsapi20170525.client import Client as SmsClient
from alibabacloud_tea_util.models import RuntimeOptions
from fly_common.tools.response import Response
from fly_common.tools.single import Singleton

logger = logging.getLogger(__name__)

if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)s | %(name)s | %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


@Singleton
class AliyunSMS:
    """
    阿里云短信服务（生产级组件 ）
    """

    # 可重试的系统级错误码（通常是瞬时故障）
    RETRYABLE_ERRORS = {
        "isv.SYSTEM_ERROR",
        "ServiceUnavailable",
        "Throttling",
        "InternalError",
    }

    # 不可重试的业务错误码
    NON_RETRYABLE_ERRORS = {
        "isv.MOBILE_NUMBER_ILLEGAL": "手机号格式错误",
        "isv.USER_NOT_EXIST": "用户不存在",
        "isv.TEMPLATE_MISSING_PARAMETERS": "模板参数缺失或格式错误",
        "isv.INVALID_PARAMETERS": "参数无效",
        "isv.AMOUNT_NOT_ENOUGH": "账户余额不足",
        "isv.SMS_TEMPLATE_ILLEGAL": "短信模板不合法",
        "isv.SMS_SIGN_ILLEGAL": "短信签名不合法",
        "isv.BUSINESS_LIMIT_CONTROL": "发送频率过高，请稍后再试",
    }

    def __init__(
            self,
            access_key_id: str,
            access_key_secret: str,
            sign_name: str,
            endpoint: str = "dysmsapi.aliyuncs.com",
    ):
        self.access_key_id = access_key_id
        self.access_key_secret = access_key_secret
        self.sign_name = sign_name
        self.endpoint = endpoint

        """初始化客户端（必须在锁内调用或构造时调用）"""
        cfg = open_api_models.Config(
            access_key_id=self.access_key_id,
            access_key_secret=self.access_key_secret,
            endpoint=self.endpoint,
        )
        self._client = SmsClient(cfg)

        # 添加初始化日志
        logger.info(
            "AliyunSMS initialized",
            extra={"provider": "aliyun", "endpoint": self.endpoint}
        )


    def _sleep_with_backoff(self, attempt: int, remaining_time: float) -> float:
        """指数退避，严格遵守剩余时间"""
        base_delay = min(2 ** attempt, 32)
        jitter = random.uniform(0, 0.5 * base_delay)
        calculated_sleep = base_delay + jitter
        actual_sleep = min(calculated_sleep, max(0, remaining_time - 0.1))

        if actual_sleep > 0:
            time.sleep(actual_sleep)

        return actual_sleep

    def send_sms(
            self,
            phone: str,
            template_code: str,
            params: Dict[str, Any],
            sign_name: Optional[str] = None,
            max_retry: int = 3
    ) -> Response:
        """
        发送短信

        :param phone: 手机号（支持国际格式）
        :param template_code: 短信模板编码
        :param params: 模板参数字典
        :param sign_name: 短信签名（可选）
        :param max_retry: 最大重试次数
        :return: Response 统一响应
        """
        start_time = time.time()

        # 使用局部引用避免并发close竞态
        client = self._client
        if not client:
            return Response(
                ok=False,
                msg="短信服务未就绪",
                data={"error_code": "CLIENT_NOT_READY"}
            )

        try:
            template_param_str = json.dumps(params, ensure_ascii=False)
        except (TypeError, ValueError) as e:
            return Response(
                ok=False,
                msg=f"参数序列化失败: {str(e)}",
                data={"error_code": "SERIALIZATION_ERROR"}
            )

        request = dy_sms_api_models.SendSmsRequest(
            phone_numbers=phone.strip(),
            sign_name=(sign_name or self.sign_name).strip(),
            template_code=template_code.strip(),
            template_param=template_param_str,
        )

        # 超时参数收敛：确保SDK超时 < 逻辑超时
        runtime = RuntimeOptions(
            connect_timeout=3000,  # 3秒
            read_timeout=5000,  # 5秒
        )

        # 逻辑超时（严格控制）
        total_timeout = 10  # 秒

        last_exception: Optional[Exception] = None

        for attempt in range(max_retry):
            elapsed_time = time.time() - start_time
            remaining_time = total_timeout - elapsed_time

            if remaining_time <= 0:
                logger.error(
                    "SMS call total timeout exceeded",
                    extra={
                        "provider": "aliyun",
                        "phone": phone,
                        "total_time": elapsed_time,
                        "max_timeout": total_timeout,
                    }
                )
                return Response(
                    ok=False,
                    msg="短信服务调用超时",
                    data={"error_code": "TOTAL_TIMEOUT"}
                )

            try:
                response = client.send_sms_with_options(request, runtime)
                body = response.body
                request_id = body.request_id if body else None

                # 成功
                if body and body.code == "OK":
                    logger.info(
                        "SMS sent successfully",
                        extra={
                            "provider": "aliyun",
                            "phone": phone,
                            "template": template_code,
                            "request_id": request_id,
                            "attempt": attempt + 1,
                            "total_time": time.time() - start_time,
                        },
                    )
                    return Response(
                        ok=True,
                        msg="短信发送成功",
                        data={
                            "request_id": request_id,
                            "biz_id": body.biz_id,
                        }
                    )

                # 业务错误
                error_code = body.code if body else "UNKNOWN"
                error_message = body.message if body else "未知错误"

                # 业务限流直接返回
                if error_code == "isv.BUSINESS_LIMIT_CONTROL":
                    logger.warning(
                        "SMS business limit control",
                        extra={
                            "provider": "aliyun",
                            "phone": phone,
                            "error_code": error_code,
                        },
                    )
                    return Response(
                        ok=False,
                        msg="发送频率过高，请稍后再试",
                        data={
                            "error_code": error_code,
                            "error_message": error_message,
                            "request_id": request_id,
                        }
                    )

                # 可重试错误
                if error_code in self.RETRYABLE_ERRORS and attempt < max_retry - 1:
                    logger.warning(
                        "SMS retryable error, will retry",
                        extra={
                            "provider": "aliyun",
                            "phone": phone,
                            "error_code": error_code,
                            "attempt": attempt + 1,
                        },
                    )
                    self._sleep_with_backoff(attempt, remaining_time)
                    continue

                # 不可重试错误
                friendly_msg = self.NON_RETRYABLE_ERRORS.get(
                    error_code, f"短信发送失败: {error_message}"
                )

                logger.warning(
                    "SMS failed",
                    extra={
                        "provider": "aliyun",
                        "phone": phone,
                        "error_code": error_code,
                        "attempt": attempt + 1,
                    },
                )

                return Response(
                    ok=False,
                    msg=friendly_msg,
                    data={
                        "error_code": error_code,
                        "error_message": error_message,
                        "request_id": request_id,
                    }
                )

            except Exception as e:
                last_exception = e
                error_type = type(e).__name__

                elapsed_time = time.time() - start_time
                remaining_time = total_timeout - elapsed_time

                if remaining_time <= 0:
                    logger.error(
                        "SMS call total timeout during exception",
                        extra={
                            "provider": "aliyun",
                            "phone": phone,
                            "total_time": elapsed_time,
                            "error_type": error_type,
                        },
                        exc_info=True,
                    )
                    return Response(
                        ok=False,
                        msg="短信服务调用超时",
                        data={"error_code": "TOTAL_TIMEOUT"}
                    )

                # 可重试异常
                if attempt < max_retry - 1:
                    logger.warning(
                        "SMS exception, will retry",
                        extra={
                            "provider": "aliyun",
                            "phone": phone,
                            "error_type": error_type,
                            "attempt": attempt + 1,
                        },
                        exc_info=True,
                    )
                    self._sleep_with_backoff(attempt, remaining_time)
                    continue

                logger.error(
                    "SMS final failure",
                    extra={
                        "provider": "aliyun",
                        "phone": phone,
                        "error_type": error_type,
                        "total_attempts": attempt + 1,
                        "total_time": time.time() - start_time,
                    },
                    exc_info=True,
                )

        # 重试耗尽
        return Response(
            ok=False,
            msg=f"短信发送失败，已重试{max_retry}次",
            data={
                "error_code": "MAX_RETRIES_EXCEEDED",
                "error_detail": str(last_exception) if last_exception else "未知异常",
            }
        )
