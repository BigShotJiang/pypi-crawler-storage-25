import oss2
from urllib.parse import quote
from typing import Optional
from fly_common.tools.response import Response


class OssUploader:
    """
    通用 OSS 上传组件

    支持功能：
    - 自动判断文件大小，选择普通上传或分片上传
    - 分片上传支持自动重试和异常中止
    - 禁止覆盖（可选），防止数据被意外覆盖
    - 结构化响应，不抛出异常

    OSS 分片规则：
    - 每个分片大小建议 100KB ~ 5GB
    - 除最后一片外，其他分片必须 >= 100KB
    - 总分片数不能超过 10000
    """

    def __init__(
            self,
            access_key_id: str,
            access_key_secret: str,
            internal_endpoint: str,
            public_endpoint: str,
            bucket_name: str,
            max_file_size: int = 100 * 1024 * 1024,  # 默认最大 100MB
            multipart_threshold: int = 10 * 1024 * 1024,  # 小于此值用普通上传，默认 10MB
            part_size: int = 5 * 1024 * 1024,  # 分片大小，默认 5MB
            forbid_overwrite: bool = False  # 是否禁止覆盖同名文件
    ):
        """
        初始化 OSS 上传组件

        Args:
            access_key_id:         RAM 用户访问密钥 ID
            access_key_secret:     RAM 用户访问密钥 Secret
            internal_endpoint:     OSS 内部端点（同地域使用内网，节省流量费用）
            public_endpoint:       CDN 加速域名或 OSS 公网域名
            bucket_name:           OSS 存储桶名称
            max_file_size:         单文件最大限制（字节），默认 100MB
            multipart_threshold:   触发分片上传的文件大小阈值，默认 10MB
            part_size:             分片大小（字节），默认 5MB
            forbid_overwrite:      是否禁止覆盖已存在的文件，默认 False
        """
        # 分片大小不能小于 OSS 规定的最小值 100KB
        if part_size < 1024 * 100:
            raise ValueError("part_size 不能小于 100KB")

        # 初始化认证和存储桶
        auth = oss2.Auth(access_key_id, access_key_secret)
        self.bucket = oss2.Bucket(auth, internal_endpoint, bucket_name)

        # 保存配置
        self.max_file_size = max_file_size
        self.multipart_threshold = multipart_threshold
        self.part_size = part_size
        self.public_endpoint = public_endpoint.rstrip('/')  # 去掉末尾斜杠，避免 URL 多斜杠
        self.forbid_overwrite = forbid_overwrite

    def upload(self, file_obj, object_name: str, content_type: str = None) -> Response:
        """
        上传文件入口方法

        自动根据文件大小选择上传策略：
        - size == 0 或 size < multipart_threshold：普通上传（put_object）
        - multipart_threshold <= size <= max_file_size：分片上传（multipart_upload）

        Args:
            file_obj:      文件对象，必须支持 read() 和 seek() 方法
            object_name:   OSS 上的存储路径，如 "uploads/avatar.png"
            content_type:  文件 MIME 类型，如 "image/png"，可选

        Returns:
            Response: 包含上传结果的响应对象
        """
        # 1. 参数校验（必填项检查）
        validate_result = self._validate(object_name, file_obj)
        if validate_result:
            return validate_result

        # 2. 获取文件大小
        size = self._get_file_size(file_obj)

        # 3. 文件大小校验（是否超过最大限制）
        if size > self.max_file_size:
            max_mb = self.max_file_size / 1024 / 1024
            return Response(
                ok=False,
                msg=f"文件过大，最大 {max_mb:.1f}MB"
            )

        # 4. 根据文件大小路由上传方式
        if size == 0 or size < self.multipart_threshold:
            # 普通上传（简单快速，适合小文件）
            result = self._simple_upload(file_obj, object_name, content_type, size)
        else:
            # 分片上传（支持大文件，自动分片并行上传）
            result = self._multipart_upload(file_obj, object_name, content_type, size)

        # 5. 处理上传结果
        if not result.ok:
            return result

        # 6. 构造成功响应
        return Response(
            ok=True,
            msg="上传成功",
            data={
                "url": self._make_public_url(object_name),
                "object_name": object_name,
                "size": size,
                "content_type": content_type
            }
        )

    # ==================== 私有方法 ====================

    def _validate(self, object_name: str, file_obj) -> Optional[Response]:
        """
        统一参数校验

        检查：
        - object_name 是否合法（非空、不以斜杠开头）
        - file_obj 是否是合规的文件对象

        Args:
            object_name: OSS 存储路径
            file_obj:    文件对象

        Returns:
            校验失败时返回 OssUploadResponse，成功时返回 None
        """
        # 校验 object_name
        # - 不能为空
        # - 不能以斜杠开头（会导致 URL 问题）
        if not object_name or object_name.startswith("/"):
            return Response(ok=False, msg="非法 object_name")

        # 校验 file_obj
        # - 必须支持 read() 方法（读取数据）
        # - 必须支持 seek() 方法（计算文件大小）
        if not hasattr(file_obj, "read") or not hasattr(file_obj, "seek"):
            return Response(ok=False, msg="file_obj 必须支持 read 和 seek")

        return None

    def _get_file_size(self, file_obj) -> int:
        """
        获取文件大小

        通过 seek() 方法实现，不影响文件当前读取位置

        原理：
        1. 记录当前位置
        2. 移动到文件末尾，获取偏移量（= 文件大小）
        3. 恢复原始位置

        Args:
            file_obj: 文件对象

        Returns:
            文件大小（字节）
        """
        pos = file_obj.tell()  # 记录当前位置
        file_obj.seek(0, 2)  # 移动到文件末尾
        size = file_obj.tell()  # 获取偏移量 = 文件大小
        file_obj.seek(pos)  # 恢复到原始位置
        return size

    def _build_headers(self, content_type: str) -> dict:
        """
        构建 HTTP 请求头

        Args:
            content_type: 文件 MIME 类型

        Returns:
            请求头字典
        """
        headers = {}

        # Content-Type 设置
        if content_type:
            headers["Content-Type"] = content_type

        # 禁止覆盖设置（OSS 特定头）
        # 设置后如果 object_name 已存在，OSS 会返回错误而非覆盖
        if self.forbid_overwrite:
            headers["x-oss-forbid-overwrite"] = "true"

        return headers

    def _simple_upload(
            self,
            file_obj,
            object_name: str,
            content_type: str,
            size: int
    ) -> Response:
        """
        普通上传（单次请求，适合小文件）

        使用 OSS put_object 接口，一次性上传整个文件

        Args:
            file_obj:      文件对象
            object_name:   OSS 存储路径
            content_type:  文件 MIME 类型
            size:          文件大小

        Returns:
            Response
        """
        try:
            # 确保从文件开头开始读取
            file_obj.seek(0)
            # 调用 OSS SDK 上传
            self.bucket.put_object(
                object_name,
                file_obj,
                headers=self._build_headers(content_type)
            )
            return Response(ok=True)
        except Exception as e:
            return Response(ok=False, msg=f"上传失败: {e}")

    def _multipart_upload(
            self,
            file_obj,
            object_name: str,
            content_type: str,
            size: int
    ) -> Response:
        """
        分片上传（支持大文件）

        流程：
        1. 初始化分片上传，获取 upload_id
        2. 按分片大小切分文件，逐片上传
        3. 合并所有分片，完成上传

        分片规则：
        - 每个分片 100KB ~ 5GB
        - 除最后一片外，其他分片必须 >= 100KB
        - 总分片数 <= 10000

        异常处理：
        - 任何步骤失败都会中止上传并清理已上传的分片
        - 避免产生碎片文件浪费存储空间

        Args:
            file_obj:      文件对象
            object_name:   OSS 存储路径
            content_type:  文件 MIME 类型
            size:          文件大小

        Returns:
            Response
        """
        # 1. 校验分片数量是否超过 OSS 限制
        # 公式：ceil(文件大小 / 分片大小) = 分片数量
        part_count = (size + self.part_size - 1) // self.part_size
        if part_count > 10000:
            return Response(
                ok=False,
                msg="分片数量超过 OSS 10000 限制"
            )

        upload_id = None  # 分片上传唯一标识，后续操作都需要

        try:
            # 2. 确保从头开始读取文件
            file_obj.seek(0)

            # 3. 初始化分片上传，获取 upload_id
            result = self.bucket.init_multipart_upload(object_name)
            upload_id = result.upload_id

            if not upload_id:
                return Response(
                    ok=False,
                    msg="初始化分片上传失败"
                )

            # 4. 逐片上传
            parts = []  # 保存每片的信息（part_number + etag）
            part_number = 1  # 分片编号，从 1 开始

            while True:
                # 读取一个分片大小的数据
                data = file_obj.read(self.part_size)
                if not data:
                    # 没有更多数据，说明已读完，跳出循环
                    break

                # 5. 校验分片大小
                # OSS 规则：除最后一片外，其他分片必须 >= 100KB
                # 判断是否为最后一片：文件指针位置 == 文件大小
                current_pos = file_obj.tell()
                if len(data) < 100 * 1024 and current_pos != size:
                    return Response(
                        ok=False,
                        msg="分片大小异常（小于 100KB）"
                    )

                # 6. 上传当前分片
                result = self.bucket.upload_part(
                    object_name,
                    upload_id,
                    part_number,
                    data
                )

                # 7. 保存分片信息，用于后续合并
                # etag 是 OSS 返回的文件片 MD5 标识
                parts.append(oss2.models.PartInfo(part_number, result.etag))
                part_number += 1

            # 8. 所有分片上传完成，合并分片
            self.bucket.complete_multipart_upload(
                object_name,
                upload_id,
                parts,
                headers=self._build_headers(content_type)
            )

            return Response(ok=True)

        except Exception as e:
            # 9. 发生异常，中止分片上传
            # 清理已上传的分片，避免产生碎片
            if upload_id:
                try:
                    self.bucket.abort_multipart_upload(object_name, upload_id)
                except Exception:
                    # 中止失败不影响主异常
                    pass

            return Response(ok=False, msg=f"分片上传失败: {e}")

    def _make_public_url(self, object_name: str) -> str:
        """
        生成文件公开访问 URL

        Args:
            object_name: OSS 存储路径

        Returns:
            完整的公开访问 URL
        """
        # quote() 对特殊字符进行 URL 编码
        # safe='/' 表示斜杠不编码（它是路径分隔符）
        # 例如："测试 文件.png" -> "测试%20文件.png"
        return f"{self.public_endpoint}/{quote(object_name, safe='/')}"
