from pydantic import BaseModel
from typing import Any, Dict, List, Union


class Response(BaseModel):
    """统一响应模型"""
    ok: bool
    msg: str = ""
    data: Union[Dict[str, Any], List[Dict[str, Any]], None] = None
