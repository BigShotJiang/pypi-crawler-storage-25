from threading import Lock


class Singleton:
    """单例装饰器，支持缓存不同参数的实例。"""

    _instances = {}
    _lock = Lock()

    def __init__(self, cls):
        self.cls = cls

    def __call__(self, *args, **kwargs):
        # 用 (cls, args, kwargs) 作为 key
        key = (self.cls, args, tuple(kwargs.items()))

        if key not in self._instances:
            with self._lock:
                if key not in self._instances:
                    self._instances[key] = self.cls(*args, **kwargs)
        return self._instances[key]
