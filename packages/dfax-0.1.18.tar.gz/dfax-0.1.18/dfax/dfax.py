import jax
import chex
import jax.numpy as jnp
from flax import struct
from functools import partial


@struct.dataclass
class DFAx:
    start: int
    transitions: jnp.ndarray
    labels: jnp.ndarray
    is_reach: jnp.ndarray

    @classmethod
    @partial(jax.jit, static_argnames=("cls",))
    def create(cls, start, transitions, labels):
        n_states, n_tokens = transitions.shape
        trans_flat = transitions.flatten()
        is_reach_init = jnp.zeros((n_states,), dtype=bool).at[start].set(True)

        def step(is_reach: jnp.ndarray) -> jnp.ndarray:
            reach_repeat = jnp.repeat(is_reach, n_tokens)
            dest_counts = jnp.zeros((n_states,), dtype=jnp.int32).at[trans_flat].add(reach_repeat)
            return dest_counts > 0

        def cond(pair):
            prev_is_reach, curr_is_reach = pair
            return jnp.any(prev_is_reach != curr_is_reach)

        def body(pair):
            prev_is_reach, curr_is_reach = pair
            next_is_reach = step(curr_is_reach)
            return (curr_is_reach, next_is_reach)

        is_reach, _ = jax.lax.while_loop(cond, body, (is_reach_init, step(is_reach_init)))

        return cls(start=start,
                    transitions=transitions,
                    labels=labels,
                    is_reach=is_reach)

    @property
    def n_states(self):
        return jnp.sum(self.is_reach)

    @property
    def max_n_states(self):
        return self.transitions.shape[0]

    @property
    def n_tokens(self):
        return self.transitions.shape[1]

    @property
    def is_reach_tile(self) -> jnp.ndarray:
        return jnp.tile(self.is_reach.reshape(-1, 1), (1, self.n_tokens))

    @jax.jit
    def __eq__(self, other: "DFAx") -> jnp.ndarray:
        self_norm = self.normalize()
        other_norm = other.normalize()

        n = min(self_norm.max_n_states, other_norm.max_n_states)

        start_eq = (self_norm.start == other_norm.start)
        transitions_eq = jnp.where(
            self_norm.n_tokens == other_norm.n_tokens,
            jnp.all(self_norm.transitions[:n] == other_norm.transitions[:n]),
            False
        )
        labels_eq = jnp.all(self_norm.labels[:n] == other_norm.labels[:n])

        return jnp.logical_and(start_eq, jnp.logical_and(transitions_eq, labels_eq))

    @partial(jax.jit, static_argnames="op")
    def _binary_op(self, other: "DFAx", op) -> "DFAx":
        assert self.n_tokens == other.n_tokens
        s1, s2 = self.max_n_states, other.max_n_states
        a = self.n_tokens
        prod_start = self.start * s2 + other.start
        t1, t2 = self.transitions[:, None, :], other.transitions[None, :, :]
        prod_transitions = (t1 * s2 + t2).reshape((s1 * s2, a))
        prod_labels = op(self.labels[:, None], other.labels[None, :]).reshape((s1 * s2,))
        return DFAx.create(
            start=prod_start,
            transitions=prod_transitions,
            labels=prod_labels
        )

    @jax.jit
    def __and__(self, other: "DFAx") -> "DFAx":
        return self._binary_op(other, jnp.logical_and)

    @jax.jit
    def __or__(self, other: "DFAx") -> "DFAx":
        return self._binary_op(other, jnp.logical_or)

    @jax.jit
    def __xor__(self, other: "DFAx") -> "DFAx":
        return self._binary_op(other, jnp.logical_xor)
    
    @jax.jit
    def __invert__(self) -> "DFAx":
        return DFAx.create(
            start=self.start,
            transitions=self.transitions,
            labels=jnp.logical_not(self.labels)
        )
    
    @jax.jit
    def __sub__(self, other: "DFAx") -> "DFAx":
        return self._binary_op(other, lambda a, b: jnp.logical_and(a, jnp.logical_not(b)))

    def __hash__(self) -> int:
        from dfax import dfax2dfa
        dfa = dfax2dfa(self)
        return dfa.__hash__()

    @jax.jit
    def advance(self, symbols) -> "DFAx":
        symbols = jnp.atleast_1d(symbols)

        def step(state, symbol):
            next_state = jnp.where(
                jnp.logical_and(symbol >= 0, symbol < self.n_tokens),
                self.transitions[state, symbol],
                state
            )
            return next_state, None

        final_state, _ = jax.lax.scan(step, self.start, symbols)

        return DFAx.create(
            start=final_state,
            transitions=self.transitions,
            labels=self.labels
        )

    @jax.jit
    def mutate(self, key: chex.PRNGKey) -> "DFAx":
        key, k1, k2 = jax.random.split(key, 3)

        flat_is_reach_tile = self.is_reach_tile.flatten()

        scores, indices = jax.lax.top_k(jnp.where(flat_is_reach_tile, 1, 0), flat_is_reach_tile.size)
        num_valid = jnp.sum(scores > 0)
        valid_idx = jax.random.randint(k1, (), 0, num_valid)
        flat_idx = indices[valid_idx]
        s, a = jnp.divmod(flat_idx, self.n_tokens)

        scores, indices = jax.lax.top_k(jnp.where(self.is_reach, 1, 0), self.max_n_states)
        num_valid = jnp.sum(scores > 0)
        valid_idx = jax.random.randint(k2, (), 0, num_valid)
        t = indices[valid_idx]

        transitions = self.transitions.at[s, a].set(t)

        return DFAx.create(
            start=self.start,
            transitions=transitions,
            labels=self.labels
        )

    @jax.jit
    def mutate_reject_lang(self, key: chex.PRNGKey) -> "DFAx":
        key, k1, k2 = jax.random.split(key, 3)

        is_self_loop = self.transitions == jnp.arange(self.max_n_states)[:, None]
        sa_mask = jnp.logical_and(
            jnp.logical_and(self.is_reach_tile, is_self_loop),
            jnp.logical_not(self.labels)[:, None]
        ).flatten()

        scores, indices = jax.lax.top_k(jnp.where(sa_mask, 1, 0), sa_mask.size)
        num_valid = jnp.sum(scores > 0)
        valid_idx = jax.random.randint(k1, (), 0, num_valid)
        flat_idx = indices[valid_idx]
        s, a = jnp.divmod(flat_idx, self.n_tokens)

        is_sink = jnp.all(is_self_loop, axis=-1)
        is_reject = jnp.logical_and.reduce(jnp.array([self.is_reach, is_sink, jnp.logical_not(self.labels)]))
        t_mask = jnp.where(jnp.any(is_reject), is_reject, jnp.logical_not(self.is_reach))

        scores, indices = jax.lax.top_k(jnp.where(t_mask, 1, 0), t_mask.size)
        num_valid = jnp.sum(scores > 0)
        valid_idx = jax.random.randint(k2, (), 0, num_valid)
        t = indices[valid_idx]

        transitions = self.transitions.at[s, a].set(t)

        return DFAx.create(
            start=self.start,
            transitions=transitions,
            labels=self.labels
        )

    @jax.jit
    def sink_accepts(self) -> "DFAx":
        accept_mask = jnp.tile(self.labels.reshape(-1, 1), (1, self.n_tokens))
        replace_mask = accept_mask & self.is_reach_tile

        sink_indices = jnp.tile(jnp.arange(self.max_n_states).reshape(-1, 1), (1, self.n_tokens))
        transitions = jnp.where(replace_mask, sink_indices, self.transitions)

        return DFAx.create(
            start=self.start,
            transitions=transitions,
            labels=self.labels
        )

    @jax.jit
    def prune(self) -> "DFAx":
        pruned_transitions = jnp.where(self.is_reach_tile, self.transitions, jnp.arange(self.max_n_states)[:, None])
        pruned_labels = jnp.where(self.is_reach, self.labels, False)

        return DFAx.create(
            start=self.start,
            transitions=pruned_transitions,
            labels=pruned_labels
        )

    @jax.jit
    def minimize(self) -> "DFAx":
        return self.naivePR().prune().normalize()

    @jax.jit
    def naivePR(self) -> "DFAx":
        # Algorithm 2 from https://arxiv.org/pdf/2410.22764
        q_f = jnp.argmax(jnp.where(self.is_reach, self.labels, 0))
        q_n = jnp.argmin(jnp.where(self.is_reach, self.labels, 1))
        block = jnp.where(self.labels, q_f, q_n)
        block = jnp.where(self.is_reach, block, jnp.arange(self.max_n_states))

        qs = jnp.arange(self.max_n_states)
        as_ = jnp.arange(self.n_tokens)
        qas = jnp.stack(jnp.meshgrid(qs, as_, indexing="ij"), axis=-1).reshape(-1, 2)

        def iteration(state):
            block, _ = state

            def elect(q_a):
                q, a = q_a
                return jax.lax.cond(
                    self.is_reach[q],
                    lambda _: (
                        block[q],
                        jnp.where(
                            block[self.transitions[q, a]] != block[self.transitions[block[q], a]],
                            q,
                            -1
                        )
                    ),
                    lambda _: (block[q], -1),
                    operand=None
                )
            blk_idx, leaders = jax.vmap(elect)(qas)
            new_leader = jax.ops.segment_max(leaders, blk_idx, num_segments=self.max_n_states)

            def assign(q_a):
                q, a = q_a
                return jax.lax.cond(
                    self.is_reach[q],
                    lambda _: (
                        q,
                        jnp.where(
                            (block[self.transitions[q, a]] != block[self.transitions[block[q], a]]),
                            new_leader[block[q]],
                            -1
                        )
                    ),
                    lambda _: (q, -1),
                    operand=None
                )
            qs_idx, new_vals = jax.vmap(assign)(qas)
            new_block = jax.ops.segment_max(new_vals, qs_idx, num_segments=self.max_n_states)
            new_block = jnp.where(new_block < 0, block, new_block)

            return (new_block, jnp.any(new_block != block))

        block, _ = jax.lax.while_loop(
            lambda s: s[1],
            lambda s: iteration((s[0], False)),
            (block, True)
        )

        minimized_start       = block[self.start]
        minimized_labels      = self.labels[block]
        minimized_transitions = block[self.transitions]

        return DFAx.create(
            start=minimized_start,
            transitions=minimized_transitions,
            labels=minimized_labels
        )

    @partial(jax.jit, static_argnames="max_length")
    def find_word(self, key: chex.PRNGKey, max_length: int = None) -> jnp.ndarray:
        if max_length is None:
            max_length = self.max_n_states

        stack     = (-jnp.ones((max_length,), dtype=jnp.int32)).at[0].set(self.start)
        stack_ptr = 1
        visited   = jnp.zeros((max_length,), dtype=bool).at[self.start].set(True)
        parent    = -jnp.ones((max_length,), dtype=jnp.int32)
        token_to  = -jnp.ones((max_length,), dtype=jnp.int32)
        depth     = jnp.zeros((max_length,), dtype=jnp.int32)
        found     = -1
        
        def cond(carry):
            _, stack_ptr, _, _, _, _, _, found = carry
            return (stack_ptr > 0) & (found < 0)
        
        def body(carry):
            key, stack_ptr, stack, visited, parent, token_to, depth, found = carry

            stack_ptr    = stack_ptr - 1
            state        = stack[stack_ptr]
            curr_depth   = depth[state]

            is_accepting = self.labels[state].astype(bool)
            found        = jnp.where(is_accepting, state, found)

            key, subkey  = jax.random.split(key)
            token_order  = jax.random.permutation(subkey, self.n_tokens)
            
            def push(i, carry):
                visited, stack, stack_ptr, parent, token_to, depth = carry
                token = token_order[i]
                ns    = self.transitions[state, token]

                do_push   = ~is_accepting & (curr_depth < max_length) & ~visited[ns]
                stack     = stack.at[stack_ptr].set(jnp.where(do_push, ns, stack[stack_ptr]))
                stack_ptr = stack_ptr + do_push.astype(jnp.int32)
                visited   = visited.at[ns].set(visited[ns] | do_push)
                parent    = parent.at[ns].set(jnp.where(do_push, state, parent[ns]))
                token_to  = token_to.at[ns].set(jnp.where(do_push, token, token_to[ns]))
                depth     = depth.at[ns].set(jnp.where(do_push, curr_depth + 1, depth[ns]))

                return visited, stack, stack_ptr, parent, token_to, depth

            visited, stack, stack_ptr, parent, token_to, depth = jax.lax.fori_loop(
                0, self.n_tokens, push, (visited, stack, stack_ptr, parent, token_to, depth)
            )
            
            return key, stack_ptr, stack, visited, parent, token_to, depth, found
        
        _, _, _, _, parent, token_to, depth, found = jax.lax.while_loop(
            cond, body, (key, stack_ptr, stack, visited, parent, token_to, depth, found)
        )

        word_length = depth[found]
        word        = -jnp.ones((max_length,), dtype=jnp.int32)

        def trace(i, carry):
            word, state = carry
            word  = word.at[word_length - 1 - i].set(token_to[state])
            state = parent[state]
            return word, state

        word, _ = jax.lax.fori_loop(0, word_length, trace, (word, found))

        return word

    @jax.jit
    def normalize(self) -> "DFAx":
        old_to_new = (-jnp.ones((self.max_n_states,), dtype=jnp.int32)).at[self.start].set(0)
        visited    = jnp.zeros((self.max_n_states,), dtype=bool).at[self.start].set(True)
        queue      = (-jnp.ones((self.max_n_states,), dtype=jnp.int32)).at[0].set(self.start)
        head       = 0
        tail       = (head + 1) % self.max_n_states
        count      = 0

        def cond(carry):
            _, _, _, head, tail, _ = carry
            return head != tail

        def body(carry):
            visited, old_to_new, queue, head, tail, count = carry

            current_state = queue[head]
            head = (head + 1) % self.max_n_states

            old_to_new = old_to_new.at[current_state].set(count)
            count += 1

            next_states = self.transitions[current_state]

            def push(i, carry):
                visited, queue, tail = carry
                ns = next_states[i]
                unseen = jnp.logical_not(visited[ns])

                queue = queue.at[tail].set(jnp.where(unseen, ns, queue[tail]))
                tail  = (tail + unseen) % self.max_n_states

                visited = visited.at[ns].set(True)
                return visited, queue, tail

            visited, queue, tail = jax.lax.fori_loop(
                0, self.n_tokens, push, (visited, queue, tail)
            )

            return visited, old_to_new, queue, head, tail, count

        visited, old_to_new, queue, head, tail, count = jax.lax.while_loop(
            cond, body, (visited, old_to_new, queue, head, tail, count)
        )

        mask = (old_to_new < 0)
        ranks = jnp.cumsum(mask) - 1
        fill_vals = count + ranks
        old_to_new = jnp.where(mask, fill_vals, old_to_new)

        start        = old_to_new[self.start]
        transitions  = self.transitions.at[old_to_new].set(old_to_new[self.transitions])
        labels       = self.labels.at[old_to_new].set(self.labels)

        return DFAx.create(
            start=start,
            transitions=transitions,
            labels=labels
        )

    @jax.jit
    def to_graph(self):
        srcs, tgts = jnp.meshgrid(jnp.arange(self.max_n_states), jnp.arange(self.max_n_states), indexing="ij")
        srcs = srcs.flatten()
        tgts = tgts.flatten()

        edge_index = jnp.stack([srcs, tgts])
        
        is_init = jnp.logical_and(
            self.is_reach,
            jnp.arange(self.max_n_states) == self.start
        )
        is_accept = jnp.logical_and(
            self.is_reach,
            self.labels
        )
        is_reject = jnp.logical_and(
            self.is_reach,
            jnp.all(
                jnp.logical_and(
                    self.transitions == jnp.arange(self.max_n_states)[:, None], # has all loops
                    jnp.logical_not(self.labels[:, None]) # not accepting
                ),
                axis=1
            )
        )
        is_non_terminal = jnp.logical_and(
            self.is_reach,
            jnp.logical_and(
                jnp.logical_not(is_accept),
                jnp.logical_not(is_reject)
            )
        )

        node_features = jnp.stack([is_init, is_accept, is_reject, is_non_terminal], axis=1).astype(jnp.float32)

        edge_features = jnp.logical_and(
            self.is_reach[:, None, None],
            self.transitions[:, None, :] == jnp.arange(self.max_n_states)[None, :, None] # one hot tokens
        ).astype(jnp.float32).reshape(-1, self.n_tokens)

        mask = jnp.any(edge_features != 0, axis=-1)[:, None]
        edge_features = jnp.concatenate([node_features[srcs] * mask, edge_features, node_features[tgts] * mask], axis=-1)

        graph = {
            "node_features": node_features,
            "edge_features": edge_features,
            "edge_index": edge_index,
            "current_state": jnp.array([self.start]),
            "n_states": jnp.full(self.max_n_states, self.n_states)
        }

        return graph

    @jax.jit
    def reward(self, binary: bool = False) -> float:
        is_accept = self.labels[self.start]
        start_row = self.transitions[self.start]
        start_vec = jnp.full((self.n_tokens,), self.start, dtype=start_row.dtype)
        is_sink = jnp.all(start_row == start_vec)

        return jnp.where(binary,
            jnp.where(is_accept, 1.0, 0.0),
            jnp.where(is_accept, 1.0, jnp.where(is_sink, -1.0, 0.0))
        )

    def shrink(self) -> "DFAx":
        is_reach = self.is_reach
        reach_i = jnp.cumsum(is_reach.astype(jnp.int32)) - 1
        start_reach = reach_i[self.start]
        transitions_reach = reach_i[self.transitions[is_reach]]
        labels_reach = self.labels[is_reach]
        return DFAx.create(
            start=start_reach,
            transitions=transitions_reach,
            labels=labels_reach
        )

    def expand(self, dim):
        if self.max_n_states >= dim:
            return DFAx.create(
                start=self.start,
                transitions=self.transitions,
                labels=self.labels
            )

        # create self-loop rows for new states: each new state transitions to itself for all tokens
        new_indices = jnp.arange(self.max_n_states, dim, dtype=self.transitions.dtype)
        new_rows = jnp.tile(new_indices.reshape(-1, 1), (1, self.n_tokens))
        transitions = jnp.concatenate([self.transitions, new_rows], axis=0)

        # extend labels with False for new states
        labels = jnp.concatenate([self.labels, jnp.zeros((dim - self.max_n_states,), dtype=bool)], axis=0)

        return DFAx.create(
            start=self.start,
            transitions=transitions,
            labels=labels
        )

