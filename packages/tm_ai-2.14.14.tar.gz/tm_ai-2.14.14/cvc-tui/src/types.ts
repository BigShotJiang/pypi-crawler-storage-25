// CVC TUI shared types.

export type Role = 'user' | 'assistant' | 'system' | 'tool';

export interface Message {
  id: string;
  role: Role;
  content: string;
  ts: number;
}

export interface TurnState {
  id: string;
  status: 'idle' | 'streaming' | 'done' | 'error';
  startedAt: number;
  endedAt?: number;
  error?: string;
}

export interface UiTheme {
  primary: string;
  dark: string;
  accent: string;
  dim: string;
}

export const CVC_THEME: UiTheme = {
  primary: '#e63946', // CVC red
  dark: '#0d1b2a',
  accent: '#4a9eff',
  dim: '#6b7280',
};
