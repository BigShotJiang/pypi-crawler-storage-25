import React from 'react';
import { Text } from 'ink';

export interface StreamingMarkdownProps {
  content: string;
  color?: string;
}

/**
 * PLACEHOLDER. Slice 12 will wire a streaming markdown renderer
 * (likely marked + ink-aware token-to-React mapping). For now this just
 * dumps the content as plain text so the rest of the app can be built around it.
 */
export const StreamingMarkdown: React.FC<StreamingMarkdownProps> = ({ content, color }) => {
  return <Text color={color}>{content}</Text>;
};
