import React, { useEffect, useState } from 'react';
import { Box, Text } from 'ink';
import { TIMING } from '../config/timing.js';

// unicode-animations exposes a large catalog of frame arrays. We import lazily
// and gracefully fall back if the shape changes.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let UA: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  UA = await import('unicode-animations').catch(() => null);
} catch {
  UA = null;
}

const FALLBACK_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏'];

function pickFrames(): string[] {
  try {
    if (UA?.default?.dots) return UA.default.dots as string[];
    if (Array.isArray(UA?.dots)) return UA.dots as string[];
  } catch {
    /* ignore */
  }
  return FALLBACK_FRAMES;
}

export interface ThinkingProps {
  label?: string;
  color?: string;
}

export const Thinking: React.FC<ThinkingProps> = ({ label = 'thinking', color = '#e63946' }) => {
  const [frame, setFrame] = useState(0);
  const frames = pickFrames();

  useEffect(() => {
    const id = setInterval(() => {
      setFrame((f) => (f + 1) % frames.length);
    }, TIMING.SPINNER_FRAME_MS);
    return () => clearInterval(id);
  }, [frames.length]);

  return (
    <Box>
      <Text color={color}>{frames[frame]} </Text>
      <Text color="gray">{label}…</Text>
    </Box>
  );
};
