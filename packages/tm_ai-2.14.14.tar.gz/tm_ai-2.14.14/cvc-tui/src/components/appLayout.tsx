import React, { useEffect } from 'react';
import { Box, useStdout } from 'ink';
import { setSize } from '../app/uiStore.js';

export interface AppLayoutProps {
  children: React.ReactNode;
}

/**
 * Root flex container. Tracks terminal resizes and pushes dims into the UI store
 * so child components can react via nanostores selectors.
 */
export const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { stdout } = useStdout();

  useEffect(() => {
    const onResize = (): void => {
      setSize(stdout.columns ?? 80, stdout.rows ?? 24);
    };
    onResize();
    stdout.on('resize', onResize);
    return () => {
      stdout.off('resize', onResize);
    };
  }, [stdout]);

  return (
    <Box flexDirection="column" width="100%" paddingX={1} paddingY={0}>
      {children}
    </Box>
  );
};
