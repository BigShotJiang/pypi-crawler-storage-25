import React from 'react';
import { Box, Text } from 'ink';
import InkTextInput from 'ink-text-input';

export interface TextInputProps {
  value: string;
  onChange: (v: string) => void;
  onSubmit?: (v: string) => void;
  placeholder?: string;
  prompt?: string;
}

/** Thin wrapper around ink-text-input adding the CVC `❯` prompt + theming. */
export const TextInput: React.FC<TextInputProps> = ({
  value,
  onChange,
  onSubmit,
  placeholder,
  prompt = '❯',
}) => {
  return (
    <Box>
      <Text color="#e63946">{prompt} </Text>
      <InkTextInput
        value={value}
        onChange={onChange}
        onSubmit={onSubmit}
        placeholder={placeholder}
      />
    </Box>
  );
};
