import React from 'react';
import { Box, Text } from 'ink';
import { CVC_BANNER, CVC_TAGLINE, BANNER_COLOR, TAGLINE_COLOR } from '../banner.js';

export interface BrandingProps {
  version?: string;
  model?: string;
}

export const Branding: React.FC<BrandingProps> = ({ version = '0.0.1', model = 'unknown' }) => {
  return (
    <Box flexDirection="column" marginBottom={1}>
      <Text color={BANNER_COLOR} bold>
        {CVC_BANNER}
      </Text>
      <Box marginTop={1}>
        <Text color={TAGLINE_COLOR}>{CVC_TAGLINE}</Text>
        <Text color="gray">{`  v${version}  ·  `}</Text>
        <Text color="white">{model}</Text>
      </Box>
    </Box>
  );
};
