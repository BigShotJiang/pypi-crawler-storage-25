// Turn-lifecycle store: tracks the current conversational turn + transcript.
import { atom } from 'nanostores';
import type { Message, TurnState } from '../types.js';

export const $messages = atom<Message[]>([]);
export const $turn = atom<TurnState | null>(null);

export function appendMessage(msg: Message): void {
  $messages.set([...$messages.get(), msg]);
}

export function startTurn(id: string): void {
  $turn.set({ id, status: 'streaming', startedAt: Date.now() });
}

export function endTurn(error?: string): void {
  const cur = $turn.get();
  if (!cur) return;
  $turn.set({
    ...cur,
    status: error ? 'error' : 'done',
    endedAt: Date.now(),
    error,
  });
}

export function clearTranscript(): void {
  $messages.set([]);
  $turn.set(null);
}
