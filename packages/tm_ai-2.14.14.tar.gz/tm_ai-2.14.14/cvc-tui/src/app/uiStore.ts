// UI-wide store: terminal dimensions, focus, modal visibility, theme overrides.
import { atom, map } from 'nanostores';
import { CVC_THEME, type UiTheme } from '../types.js';

export interface UiState {
  cols: number;
  rows: number;
  focused: 'input' | 'transcript' | 'modal';
  modal: string | null;
  busy: boolean;
}

export const $ui = map<UiState>({
  cols: process.stdout.columns ?? 80,
  rows: process.stdout.rows ?? 24,
  focused: 'input',
  modal: null,
  busy: false,
});

export const $theme = atom<UiTheme>(CVC_THEME);

export function setBusy(b: boolean): void {
  $ui.setKey('busy', b);
}

export function setSize(cols: number, rows: number): void {
  $ui.setKey('cols', cols);
  $ui.setKey('rows', rows);
}
