// Centralised timing constants for the CVC TUI.
// Keep all magic numbers controlling UI cadence in this file.

export const TIMING = {
  /** Spinner frame interval (ms) */
  SPINNER_FRAME_MS: 80,
  /** Throttle for streaming markdown re-renders (ms) */
  STREAM_THROTTLE_MS: 16,
  /** Debounce on text-input change handlers (ms) */
  INPUT_DEBOUNCE_MS: 0,
  /** Gateway connect retry backoff (ms) */
  GATEWAY_RECONNECT_MS: 1500,
  /** Heartbeat ping interval (ms) */
  HEARTBEAT_MS: 15000,
} as const;
