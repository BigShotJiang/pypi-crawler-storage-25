import React, { useState } from 'react';
import { Box, Text } from 'ink';
import { useStore } from '@nanostores/react';
import { AppLayout } from './components/appLayout.js';
import { Branding } from './components/branding.js';
import { TextInput } from './components/textInput.js';
import { StreamingMarkdown } from './components/streamingMarkdown.js';
import { Thinking } from './components/thinking.js';
import { $messages } from './app/turnStore.js';
import { $ui } from './app/uiStore.js';

export interface AppProps {
  version?: string;
  model?: string;
}

const TranscriptArea: React.FC = () => {
  const messages = useStore($messages);
  if (messages.length === 0) {
    return (
      <Box marginY={1}>
        <Text color="gray">— no messages yet — type below to start —</Text>
      </Box>
    );
  }
  return (
    <Box flexDirection="column" marginY={1}>
      {messages.map((m) => (
        <Box key={m.id} flexDirection="column" marginBottom={1}>
          <Text color={m.role === 'user' ? '#4a9eff' : '#e63946'} bold>
            {m.role}
          </Text>
          <StreamingMarkdown content={m.content} />
        </Box>
      ))}
    </Box>
  );
};

const InputLine: React.FC = () => {
  const [value, setValue] = useState('');
  const ui = useStore($ui);
  if (ui.busy) return <Thinking label="thinking" />;
  return (
    <TextInput
      value={value}
      onChange={setValue}
      onSubmit={() => setValue('')}
      placeholder="ask CVC anything"
    />
  );
};

export const App: React.FC<AppProps> = ({ version, model }) => {
  return (
    <AppLayout>
      <Branding version={version} model={model} />
      <TranscriptArea />
      <InputLine />
    </AppLayout>
  );
};
