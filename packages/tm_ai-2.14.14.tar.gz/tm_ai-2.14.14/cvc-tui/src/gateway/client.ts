// GatewayClient — STUB (Slice 11+ will implement JSON-RPC over stdio to the Python gateway).
// The interface here is the contract the rest of the TUI will code against.

export type GatewayEvent = 'message' | 'token' | 'error' | 'close' | 'open';

type Listener = (payload: unknown) => void;

export interface SendOptions {
  timeoutMs?: number;
}

export class GatewayClient {
  private listeners = new Map<GatewayEvent, Set<Listener>>();
  private connected = false;

  /** Start the gateway subprocess and wire stdio. (Stub: no-op.) */
  async connect(): Promise<void> {
    this.connected = true;
    this.emit('open', null);
  }

  /** Send a request to the gateway. (Stub: returns a placeholder.) */
  async send(_method: string, _params?: unknown, _opts?: SendOptions): Promise<unknown> {
    if (!this.connected) throw new Error('GatewayClient: not connected');
    return { ok: true, stub: true };
  }

  /** Subscribe to a gateway event. */
  on(event: GatewayEvent, listener: Listener): () => void {
    let set = this.listeners.get(event);
    if (!set) {
      set = new Set();
      this.listeners.set(event, set);
    }
    set.add(listener);
    return () => set!.delete(listener);
  }

  /** Tear down the gateway subprocess. (Stub: no-op.) */
  async close(): Promise<void> {
    this.connected = false;
    this.emit('close', null);
  }

  private emit(event: GatewayEvent, payload: unknown): void {
    this.listeners.get(event)?.forEach((l) => l(payload));
  }
}
