// CVC ASCII banner. Rendered once at startup by <Branding/>.
// Colour applied at render-time via Ink <Text color="..."> wrappers.

export const CVC_BANNER = String.raw`
  ██████╗██╗   ██╗ ██████╗
 ██╔════╝██║   ██║██╔════╝
 ██║     ██║   ██║██║
 ██║     ╚██╗ ██╔╝██║
 ╚██████╗ ╚████╔╝ ╚██████╗
  ╚═════╝  ╚═══╝   ╚═════╝
`.trim();

export const CVC_TAGLINE = 'Cognitive Version Control';

export const BANNER_COLOR = '#e63946';
export const TAGLINE_COLOR = '#4a9eff';

export interface BannerOpts {
  version?: string;
  model?: string;
}

/**
 * Returns the banner as a plain (uncoloured) string suitable for tests
 * and for non-TTY fallbacks. The TTY renderer colours it via Ink.
 */
export function renderBannerPlain({ version = '0.0.1', model = 'unknown' }: BannerOpts = {}): string {
  return [CVC_BANNER, '', `${CVC_TAGLINE}  v${version}  ·  model: ${model}`].join('\n');
}
