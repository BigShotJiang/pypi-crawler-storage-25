#!/usr/bin/env node
// CVC TUI entrypoint. Verifies a TTY, spins up the (stubbed) gateway client,
// then mounts <App/> via Ink.
import { render } from 'ink';
import { App } from './app.js';
import { GatewayClient } from './gateway/client.js';
import { renderBannerPlain } from './banner.js';

const VERSION = '0.0.1';
const MODEL = process.env.CVC_MODEL ?? 'claude-opus-4.7';

async function main(): Promise<void> {
  if (!process.stdout.isTTY) {
    // Non-interactive fallback — print plain banner and exit cleanly.
    process.stdout.write(renderBannerPlain({ version: VERSION, model: MODEL }) + '\n');
    process.stdout.write('cvc-tui requires a TTY to run interactively.\n');
    process.exit(0);
  }

  // Spawn / connect the gateway (stub today; real impl in Slice 11).
  const gateway = new GatewayClient();
  try {
    await gateway.connect();
  } catch (err) {
    process.stderr.write(`gateway connect failed: ${(err as Error).message}\n`);
  }

  const { waitUntilExit } = render(<App version={VERSION} model={MODEL} />);
  await waitUntilExit();
  await gateway.close();
}

main().catch((err) => {
  process.stderr.write(`fatal: ${(err as Error).stack ?? err}\n`);
  process.exit(1);
});
