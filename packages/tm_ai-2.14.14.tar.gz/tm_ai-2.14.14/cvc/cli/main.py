"""CVC main CLI entry point — Typer app wiring all subcommands.

Subcommands are imported lazily inside each handler so the app loads even
when sibling slices haven't shipped yet (curator/trajectory/tips/skills).
"""
from __future__ import annotations

from importlib import metadata as _metadata
from typing import Optional

import typer

app = typer.Typer(
    name="cvc",
    help="Cognitive Version Control — the most advanced agentic AI workstation",
    no_args_is_help=False,
    add_completion=False,
)


# ---------------------------------------------------------------------------
# Root callback — show welcome banner when invoked with no subcommand.
# ---------------------------------------------------------------------------
@app.callback(invoke_without_command=True)
def _root(ctx: typer.Context) -> None:
    """Default action when ``cvc`` is run with no subcommand."""
    if ctx.invoked_subcommand is None:
        from cvc.cli.banner import print_welcome_banner
        print_welcome_banner()


# ---------------------------------------------------------------------------
# version
# ---------------------------------------------------------------------------
@app.command("version")
def version_cmd() -> None:
    """Print the installed CVC (tm-ai) version."""
    try:
        v = _metadata.version("tm-ai")
    except Exception:
        v = "0.0.0+unknown"
    typer.echo(f"cvc {v}")


# ---------------------------------------------------------------------------
# setup
# ---------------------------------------------------------------------------
@app.command("setup")
def setup_cmd(
    quick: bool = typer.Option(False, "--quick", help="Skip optional steps."),
) -> None:
    """Run the CVC first-run setup wizard."""
    from cvc.cli.setup import run_setup
    run_setup(quick=quick)


# ---------------------------------------------------------------------------
# auth
# ---------------------------------------------------------------------------
@app.command("auth")
def auth_cmd(
    action: str = typer.Argument(..., help="login | status | logout | list"),
    provider: Optional[str] = typer.Argument(None, help="Provider name (copilot, openai, anthropic, ...)"),
) -> None:
    """Manage provider authentication."""
    from cvc.cli.auth import run_auth
    run_auth(provider or "copilot", action)


# ---------------------------------------------------------------------------
# doctor
# ---------------------------------------------------------------------------
@app.command("doctor")
def doctor_cmd(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Verbose output."),
    fix: bool = typer.Option(False, "--fix", help="Attempt automatic fixes."),
) -> None:
    """Diagnose your CVC environment."""
    from cvc.cli.doctor import run_doctor
    raise typer.Exit(code=run_doctor(verbose=verbose, fix=fix) or 0)


# ---------------------------------------------------------------------------
# curator (lazy — sibling slice may not exist yet)
# ---------------------------------------------------------------------------
@app.command("curator")
def curator_cmd(
    action: str = typer.Argument(..., help="Curator action (list, add, remove, ...)."),
    name: Optional[str] = typer.Argument(None),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmations."),
) -> None:
    """Curate context, prompts, and skills."""
    try:
        from cvc.cli.curator import run_curator  # type: ignore
    except ImportError:
        typer.echo("Curator not available — upgrade tm-ai")
        raise typer.Exit(code=1)
    run_curator(action, name=name, assume_yes=yes)


# ---------------------------------------------------------------------------
# trajectory (lazy)
# ---------------------------------------------------------------------------
@app.command("trajectory")
def trajectory_cmd(
    action: str = typer.Argument(..., help="Trajectory action (list, show, replay, ...)."),
    id: Optional[str] = typer.Argument(None),
) -> None:
    """Inspect agent trajectories."""
    try:
        from cvc.cli.trajectory import run_trajectory  # type: ignore
    except ImportError:
        typer.echo("Trajectory not available — upgrade tm-ai")
        raise typer.Exit(code=1)
    run_trajectory(action, id=id)


# ---------------------------------------------------------------------------
# tips (lazy)
# ---------------------------------------------------------------------------
@app.command("tips")
def tips_cmd(
    action: Optional[str] = typer.Argument(None, help="Tips action (show, list, next, ...)."),
    arg: Optional[str] = typer.Argument(None),
) -> None:
    """Daily tips and cheatsheet."""
    try:
        from cvc.cli.tips import run_tips  # type: ignore
    except ImportError:
        typer.echo("Tips not available — upgrade tm-ai")
        raise typer.Exit(code=1)
    run_tips(action, arg)


# ---------------------------------------------------------------------------
# agent — launches the Node Ink TUI
# ---------------------------------------------------------------------------
from cvc.cli.agent import register_agent_command  # noqa: E402

register_agent_command(app)


def main() -> None:
    """Console-script entry point."""
    app()


if __name__ == "__main__":
    main()
