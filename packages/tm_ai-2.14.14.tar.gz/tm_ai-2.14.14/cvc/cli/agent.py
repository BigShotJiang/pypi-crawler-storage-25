"""``cvc agent`` — launch the Node Ink TUI front-end.

The CVC agent runtime is a Node (Ink + React) process living under
``<repo_root>/cvc-tui``. This module is a thin Python launcher: it locates
the TUI entry point (built ``dist/entry.js`` preferred, dev ``src/entry.tsx``
fallback), picks ``bun`` over ``node`` if available, sets a few env vars
the TUI relies on, then hands the process over via :func:`os.execvp` so
signals (Ctrl-C) flow cleanly with no double-handling.
"""
from __future__ import annotations

import os
import shutil
import sys
from importlib import metadata as _metadata
from pathlib import Path
from typing import Optional, Tuple

import typer


# ---------------------------------------------------------------------------
# Locating the cvc-tui package.
# ---------------------------------------------------------------------------
def _candidate_repo_roots() -> list[Path]:
    """Best-effort list of directories where ``cvc-tui/`` might live."""
    roots: list[Path] = []
    # Walk up from this file (installed source layout: <repo>/cvc/cli/agent.py).
    here = Path(__file__).resolve()
    for parent in [here.parent, *here.parents]:
        roots.append(parent)
    # Current working directory as last resort.
    roots.append(Path.cwd().resolve())
    # De-dup preserving order.
    seen: set[Path] = set()
    uniq: list[Path] = []
    for r in roots:
        if r not in seen:
            seen.add(r)
            uniq.append(r)
    return uniq


def find_tui_entry(start: Optional[Path] = None) -> Optional[Tuple[Path, Path]]:
    """Return (repo_root, entry_path) for the cvc-tui package, or None.

    Prefers built ``cvc-tui/dist/entry.js`` over dev ``cvc-tui/src/entry.tsx``.
    """
    candidates: list[Path]
    if start is not None:
        start = Path(start).resolve()
        candidates = [start, *start.parents]
    else:
        candidates = _candidate_repo_roots()

    for root in candidates:
        tui = root / "cvc-tui"
        if not tui.is_dir():
            continue
        built = tui / "dist" / "entry.js"
        if built.is_file():
            return root, built
        dev = tui / "src" / "entry.tsx"
        if dev.is_file():
            return root, dev
    return None


# ---------------------------------------------------------------------------
# Runtime detection.
# ---------------------------------------------------------------------------
def detect_runtime() -> Optional[str]:
    """Return absolute path to ``bun`` (preferred) or ``node``, or None."""
    return shutil.which("bun") or shutil.which("node")


# ---------------------------------------------------------------------------
# Public launcher.
# ---------------------------------------------------------------------------
def _cvc_version() -> str:
    try:
        return _metadata.version("tm-ai")
    except Exception:
        return "0.0.0+unknown"


def _config_dir() -> str:
    return os.environ.get("CVC_CONFIG_DIR") or str(Path.home() / ".cvc")


def run_agent(
    *,
    start: Optional[Path] = None,
    _exec: callable = os.execvpe,  # for tests; default uses execvpe
) -> int:
    """Launch the cvc-tui Node process and hand over the terminal.

    On success this function does not return (``os.execvpe`` replaces the
    Python process). On failure it returns an exit code.
    """
    found = find_tui_entry(start=start)
    if found is None:
        # Best effort: report the most likely repo root.
        repo_hint = "<repo>"
        if start is not None:
            repo_hint = str(Path(start).resolve())
        else:
            roots = _candidate_repo_roots()
            if roots:
                repo_hint = str(roots[0])
        typer.echo(
            f"CVC TUI not built. Run: cd {repo_hint}/cvc-tui && "
            "bun install && bun run build",
            err=True,
        )
        return 1

    repo_root, entry = found

    runtime = detect_runtime()
    if runtime is None:
        typer.echo(
            "No JavaScript runtime found. Install bun (https://bun.sh) "
            "or node (https://nodejs.org).",
            err=True,
        )
        return 1

    # Build child env.
    env = os.environ.copy()
    env["CVC_VERSION"] = _cvc_version()
    env["CVC_CONFIG_DIR"] = _config_dir()
    env["CVC_GATEWAY_PYTHON"] = sys.executable
    env["CVC_REPO_ROOT"] = str(repo_root)

    argv = [runtime, str(entry)]

    # Hand off — execvpe replaces the current process, so signals (SIGINT,
    # SIGTERM) are delivered straight to the Node TUI with no Python wrapper
    # in the middle.
    try:
        _exec(runtime, argv, env)
    except FileNotFoundError:
        typer.echo(f"Failed to exec runtime at {runtime!r}", err=True)
        return 127
    except OSError as exc:  # pragma: no cover - defensive
        typer.echo(f"Failed to launch cvc-tui: {exc}", err=True)
        return 1
    # Unreachable in production (execvpe doesn't return).
    return 0


# ---------------------------------------------------------------------------
# Typer registration helper.
# ---------------------------------------------------------------------------
def register_agent_command(app) -> None:
    """Register the ``cvc agent`` subcommand on a Typer app."""
    @app.command("agent")
    def _agent_cmd() -> None:
        """Launch the CVC agent TUI (Node Ink)."""
        code = run_agent()
        raise typer.Exit(code=code)


__all__ = [
    "find_tui_entry",
    "detect_runtime",
    "run_agent",
    "register_agent_command",
]
