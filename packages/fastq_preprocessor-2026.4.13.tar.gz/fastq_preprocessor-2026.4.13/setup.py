from setuptools import setup

# Version
version = None
with open("./fastq_preprocessor/__init__.py", "r") as f:
    for line in f.readlines():
        line = line.strip()
        if line.startswith("__version__"):
            version = line.split("=")[-1].strip().strip('"')
assert version is not None, "Check version in fastq_preprocessor/__init__.py"

setup(name='fastq_preprocessor',
      version=version,
      description='Fast short read fastq preprocessor with optional contamination removal',
      url='https://github.com/jolespin/fastq_preprocessor',
      author='Josh L. Espinoza',
      author_email='jespinoz@jcvi.org',
      license='GNU AFFERO GENERAL PUBLIC LICENSE',
      packages=["fastq_preprocessor"],
      install_requires=[
      "sh",
      "loguru",
      "pandas >=0.24",
      ],
    include_package_data=True,
    entry_points={
        'console_scripts': [
            'fastq_preprocessor=fastq_preprocessor.fastq_preprocessor:main',
            'fastq_preprocessor_short=fastq_preprocessor.fastq_preprocessor_short:main',
            'fastq_preprocessor_long=fastq_preprocessor.fastq_preprocessor_long:main',
            'strobealign_wrapper=fastq_preprocessor.strobealign_wrapper:main',
        ],
    },

)
