```
╔══════════════════════════════════════════════════════════════════╗
║                      ████████╗███╗   ███╗██████╗ ║
║                      ╚══██╔══╝████╗ ████║██╔══██╗║
║                         ██║   ██╔████╔██║██║  ██║║
║                         ██║   ██║╚██╔╝██║██║  ██║║
║                         ██║   ██║ ╚═╝ ██║██████╔╝║
║                         ╚═╝   ╚═╝     ╚═╝╚═════╝ ║
║                          🔧 DIFF CLI 🔧                        ║
║     Professional Power BI TMDL/PBIP Semantic Comparison Tool    ║
╚══════════════════════════════════════════════════════════════════╝
```

# TMDL Diff CLI

A professional CLI tool for comparing Power BI TMDL export files, PBIP project files, and inspecting open Power BI Desktop instances.

[![Python 3.12+](https://img.shields.io/badge/python-3.12%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

## Features

- **`tmdl-diff list`**: Show open Power BI Desktop model instances and local `.tmdl` / `.pbip` files
- **`tmdl-diff diff file1.pbip file2.pbip`**: Compare two PBIP projects with semantic diff - shows exactly which tables, measures, and columns changed
- **`tmdl-diff diff file1.tmdl file2.tmdl`**: Compare two exported TMDL files with line-level diff summary
- **`tmdl-diff status file1 file2`**: Show whether two export files differ
- **`tmdl-diff compare`**: Interactively choose two exported files to compare
- **`tmdl-diff compare-open`**: Choose two detected running Power BI Desktop instances and inspect their workspaces
- **`tmdl-diff info file`**: Show metadata and extract possible model/table/measure names from a snapshot file

## 📁 File Organization & Setup

**Before using the tool, you need to prepare your PBIP files for comparison.**

### Step 1: Export Your Power BI Models

In **Power BI Desktop**, for each model version you want to compare:

1. Open your Power BI file (`.pbix`)
2. Go to **File → Save as project**
3. Choose a folder and save as `.pbip` format (this creates a directory structure)

### Step 2: Organize Files in Your Working Directory

Create a working folder where you'll keep your PBIP project files:

```
my-pbi-comparisons/          ← Your working directory
├── Old_Model.pbip/           ← First PBIP project (directory)
│   ├── Old_Model.pbip        ← Project descriptor file
│   ├── Old_Model.Report/
│   └── Old_Model.SemanticModel/
│       ├── definition/
│       ├── tables/
│       └── model.tmdl
│
├── New_Model.pbip/           ← Second PBIP project (directory)
│   ├── New_Model.pbip        ← Project descriptor file
│   ├── New_Model.Report/
│   └── New_Model.SemanticModel/
│       ├── definition/
│       ├── tables/
│       └── model.tmdl
```

### Step 3: Run the Tool from Your Working Directory

```bash
cd my-pbi-comparisons
tmdl-diff list                              # See all PBIP files
tmdl-diff diff Old_Model.pbip New_Model.pbip  # Compare them
```

## Installation

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
```

After installation, the command is available as:

```bash
tmdl-diff --help
```

## Usage

```bash
# List available files and open instances
python main.py list

# Compare two PBIP projects with professional semantic diff
python main.py diff Baptist.pbip Baptist_ch1.pbip

# Compare TMDL files
python main.py diff saved.tmdl current.tmdl

# Interactive comparison
python main.py compare

# Show file status
python main.py status file1.pbip file2.pbip

# Inspect file metadata
python main.py info file.pbip
```

If you install the package, use the `tmdl-diff` command directly:

```bash
tmdl-diff list
tmdl-diff diff Baptist.pbip Baptist_ch1.pbip
tmdl-diff info Baptist.pbip
```

## How the tool works

- **PBIP File Comparison**: When comparing `.pbip` files, the tool performs a semantic diff:
  - Recursively scans both project directories for TMDL definition files
  - Identifies added, removed, and modified files
  - Shows detailed previews of line-by-line changes for each modified component
  - Displays results in a professional, color-coded format with timestamps

- **TMDL File Comparison**: For `.tmdl` files, uses Python's standard `difflib` library for text-level comparison

- **Open Instance Detection**: `list` detects open Power BI Desktop model instances by scanning the local Power BI workspace folders in `%LOCALAPPDATA%`

- **File Metadata**: `info` extracts file-level metadata from a snapshot and reports possible model/table/measure names

- **Open Instance Inspection**: `compare-open` lets you select detected running Power BI instances and inspect the workspace path for each instance

## Example Output

```
╭────── TMDL Semantic Diff ──────╮
│ 📊 Power BI Model Comparison   │
│ Generated: 2026-04-14 16:03:12 │
╰────────────────────────────────╯

Comparing:
  From: Baptist.pbip
  To:   Baptist_ch1.pbip

Total Changes: 7

📋 TABLES & STRUCTURES
✓ Added:
   ▪ TMDLScripts\Script 1.tmdl
   ▪ TMDLScripts\Script 2.tmdl
~ Modified:
   ▪ definition\tables\Query1.tmdl
      - column TableName
      + column TableName0

   ▪ definition\model.tmdl
      -annotation PBI_ProTooling = ["MCP-PBIModeling","DevMode"]
      +annotation PBI_ProTooling = ["MCP-PBIModeling","DevMode","TMDLView_Desktop"]

╭────── Summary ───────╮
│ 2 added • 5 modified │
╰──────────────────────╯
```

## Notes

- Power BI Desktop does not expose raw live model definitions directly through the workspace folder
- To compare running instances, export them to `.pbip` or `.tmdl` files and then use `tmdl-diff diff`
- PBIP format is a directory structure containing TMDL definition files in subdirectories
- This tool is intended for file-based TMDL comparison and status checks
- Open Power BI model detection is useful for awareness, but actual model diff content relies on exported snapshots

## 🚀 Publishing to GitHub

### 1. Initialize Git Repository

```bash
cd your-tmdl-diff-folder
git init
git add .
git commit -m "Initial commit: TMDL Diff CLI tool"
```

### 2. Create Repository on GitHub

1. Go to [GitHub.com](https://github.com/new)
2. Create a new repository named `tmdl-diff`
3. Copy the repository URL (e.g., `https://github.com/YOUR_USERNAME/tmdl-diff.git`)

### 3. Push to GitHub

```bash
git remote add origin https://github.com/YOUR_USERNAME/tmdl-diff.git
git branch -M main
git push -u origin main
```

### 4. Add Git Ignore

Create `.gitignore` to exclude unnecessary files:

```bash
# Generated
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Test
.pytest_cache/
.coverage

# Local
*.pbip
*.tmdl
sample_models/
```

### 5. Publish to PyPI

#### Step 1: Build the package

```bash
pip install build twine
python -m build
```

This creates:
- `dist/tmdl-diff-X.X.X.tar.gz` (source distribution)
- `dist/tmdl-diff-X.X.X-py3-none-any.whl` (wheel)

#### Step 2: Upload to PyPI

```bash
# Test PyPI first (optional)
python -m twine upload --repository testpypi dist/*

# Then upload to production PyPI
python -m twine upload dist/*
```

You'll need:
- PyPI account: https://pypi.org/account/register/
- API token: Go to Account Settings → API tokens

#### Step 3: Install from PyPI

After publishing, anyone can install with:

```bash
pip install tmdl-diff
```

### 6. GitHub Release

```bash
git tag v1.0.0
git push origin v1.0.0
```

Then create a Release on GitHub with release notes.

## 📦 Project Structure

```
tmdl-diff/
├── main.py                    # Main CLI application
├── pbip_parser.py             # PBIP file parsing logic
├── semantic_formatter.py      # Output formatting
├── pbi_detector.py             # Power BI instance detection
├── requirements.txt           # Python dependencies
├── pyproject.toml             # Package configuration
├── README.md                  # This file
├── LICENSE                    # MIT License
└── .gitignore                 # Git ignore rules
```

## 💡 Tips for GitHub

- Add a **badge** to your README: [![PyPI](https://img.shields.io/pypi/v/tmdl-diff)](https://pypi.org/project/tmdl-diff/)
- Write a **CONTRIBUTING.md** for contributors
- Add **GitHub Actions** for automated testing
- Create **Issues** and **Discussions** for users to report bugs

## 📄 License

MIT License - see LICENSE file for details.

## 👨‍💻 Author

Created for Power BI professionals who need precise model comparison tools.

---

**Ready to share with the world? 🌍**

Your TMDL-DIFF CLI is production-ready for release!
