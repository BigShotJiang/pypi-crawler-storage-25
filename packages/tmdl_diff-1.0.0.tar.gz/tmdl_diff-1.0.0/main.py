import difflib
from pathlib import Path
from typing import Dict, List, Optional

import questionary
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from pbi_detector import get_open_pbi_models
from pbip_parser import compare_models
from semantic_formatter import render_semantic_diff

app = typer.Typer(
    help="TMDL Diff CLI - compare Power BI TMDL export files and open Power BI instances",
    no_args_is_help=True,
)
console = Console()


def load_tmdl_lines(file_path: Path) -> List[str]:
    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    with file_path.open("r", encoding="utf-8", errors="replace") as fp:
        return [line.rstrip("\n") for line in fp.readlines()]


def find_tmdl_files(search_dir: Path = Path.cwd()) -> List[Path]:
    tmdl_files = sorted(search_dir.glob("*.tmdl"))
    pbip_files = sorted(search_dir.glob("*.pbip"))
    return tmdl_files + pbip_files


def compute_diff(file_a: Path, file_b: Path) -> Dict[str, object]:
    left = load_tmdl_lines(file_a)
    right = load_tmdl_lines(file_b)
    diff_lines = list(
        difflib.unified_diff(
            left,
            right,
            fromfile=str(file_a),
            tofile=str(file_b),
            lineterm="",
        )
    )

    added = sum(1 for line in diff_lines if line.startswith("+") and not line.startswith("+++"))
    removed = sum(1 for line in diff_lines if line.startswith("-") and not line.startswith("---"))
    context = sum(1 for line in diff_lines if line.startswith(" "))

    return {
        "diff": diff_lines,
        "added": added,
        "removed": removed,
        "context": context,
    }


def choose_file(prompt: str, candidates: List[Path]) -> Path:
    if candidates:
        choices = [str(path) for path in candidates] + ["Enter a custom path"]
        selected = questionary.select(prompt, choices=choices).ask()

        if selected == "Enter a custom path":
            custom_path = questionary.text("Enter the full path to a .tmdl or .pbip file:").ask()
            return Path(custom_path).expanduser().resolve()

        return Path(selected)

    file_path = questionary.text(prompt).ask()
    return Path(file_path).expanduser().resolve()


def render_diff_result(file_a: Path, file_b: Path, diff_data: Dict[str, object]) -> None:
    if not diff_data["diff"]:
        console.print(
            Panel.fit(
                f"No differences found between\n[file]{file_a}[/file]\nand\n[file]{file_b}[/file]",
                title="✅ TMDL Diff Summary",
                subtitle="Files are identical",
            )
        )
        return

    summary = (
        f"Comparing:\n"
        f"  [cyan]1.[/cyan] {file_a.name}\n"
        f"  [cyan]2.[/cyan] {file_b.name}\n"
        f"\n"
        f"[bold green]+ Added lines:[/bold green] {diff_data['added']}\n"
        f"[bold red]- Removed lines:[/bold red] {diff_data['removed']}\n"
        f"[bold blue]  Context lines:[/bold blue] {diff_data['context']}\n"
    )

    diff_preview = "\n".join(diff_data["diff"][:100])
    console.print(Panel.fit(summary, title="📊 TMDL Diff Summary"))
    console.print("\n[bold]Diff preview:[/bold]\n")
    console.print(diff_preview)
    if len(diff_data["diff"]) > 100:
        console.print(f"[dim]...output truncated ({len(diff_data['diff'])} diff lines total)[/dim]")


def extract_tmdl_metadata(file_path: Path) -> Dict[str, object]:
    lines = load_tmdl_lines(file_path)
    metadata = {
        "path": str(file_path),
        "name": file_path.name,
        "size_bytes": file_path.stat().st_size,
        "line_count": len(lines),
        "model_name": None,
        "tables": [],
        "measures": [],
        "possible_names": [],
        "preview": lines[:20],
    }

    import json
    import re

    text = "\n".join(lines[:5000])
    try:
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            model_data = parsed.get("model") or parsed.get("Model") or parsed.get("modelObject")
            if isinstance(model_data, dict):
                metadata["model_name"] = model_data.get("name")
                metadata["tables"] = [t.get("name") for t in model_data.get("tables", []) if isinstance(t, dict)]
                metadata["measures"] = [m.get("name") for m in model_data.get("measures", []) if isinstance(m, dict)]
    except json.JSONDecodeError:
        pass

    names = re.findall(r'"name"\s*:\s*"([^"]+)"', text)
    metadata["possible_names"] = list(dict.fromkeys(names))[:20]

    table_names = re.findall(r'"table"\s*:\s*"([^"]+)"', text)
    metadata["tables"] = list(dict.fromkeys(metadata["tables"] + table_names))[:20]

    measure_names = re.findall(r'"measure"\s*:\s*"([^"]+)"', text)
    metadata["measures"] = list(dict.fromkeys(metadata["measures"] + measure_names))[:20]

    return metadata


def render_model_info(metadata: Dict[str, object]) -> None:
    table = Table(title=f"Model info for {metadata['name']}")
    table.add_column("Field", style="bold green")
    table.add_column("Value", style="cyan")
    table.add_row("Path", metadata["path"])
    table.add_row("Size", f"{metadata['size_bytes']} bytes")
    table.add_row("Lines", str(metadata["line_count"]))
    if metadata["model_name"]:
        table.add_row("Model name", str(metadata["model_name"]))
    if metadata["tables"]:
        table.add_row("Tables", ", ".join(metadata["tables"][:10]))
    if metadata["measures"]:
        table.add_row("Measures", ", ".join(metadata["measures"][:10]))
    if metadata["possible_names"] and not metadata["model_name"]:
        table.add_row("Possible names", ", ".join(metadata["possible_names"][:10]))

    console.print(table)
    console.print("\n[bold]Preview of first 20 lines:[/bold]\n")
    console.print("\n".join(metadata["preview"]))


@app.command(name="info")
def info_file(
    file_path: Path = typer.Argument(..., exists=True, help="Path to the .tmdl or .pbip file to inspect."),
) -> None:
    """Show metadata for a local TMDL/PBIP snapshot file."""
    metadata = extract_tmdl_metadata(file_path)
    render_model_info(metadata)


@app.command(name="list")
def list_models() -> None:
    """List open Power BI Desktop instances and local .tmdl/.pbip snapshots."""
    open_models = get_open_pbi_models()
    tmdl_files = find_tmdl_files()

    if open_models:
        table = Table(title="Open Power BI Models")
        table.add_column("Name", style="bold green")
        table.add_column("Port")
        table.add_column("Workspace Path", style="dim")
        for model in open_models:
            table.add_row(model["name"], model["port"], model.get("workspace", "n/a"))
        console.print(table)
    else:
        console.print("[yellow]No open Power BI Desktop instances found.[/yellow]")

    if tmdl_files:
        from datetime import datetime

        table = Table(title="Local TMDL / PBIP Files")
        table.add_column("File", style="bold cyan")
        table.add_column("Modified", style="dim")
        for path in tmdl_files:
            modified = datetime.fromtimestamp(path.stat().st_mtime).isoformat(sep=" ", timespec="seconds")
            table.add_row(str(path.name), modified)
        console.print(table)
    else:
        console.print("[yellow]No .tmdl or .pbip files found in the current directory.[/yellow]")


@app.command(name="diff")
def diff_files(
    file_a: Path = typer.Argument(..., exists=True, help="Path to the first .tmdl or .pbip file."),
    file_b: Path = typer.Argument(..., exists=True, help="Path to the second .tmdl or .pbip file."),
) -> None:
    """Compare two TMDL/PBIP export files and print a detailed semantic diff."""
    if file_a.suffix.lower() in ['.pbip', '.pbix'] and file_b.suffix.lower() in ['.pbip', '.pbix']:
        changes = compare_models(file_a, file_b)
        render_semantic_diff(file_a, file_b, changes)
    else:
        diff_data = compute_diff(file_a, file_b)
        render_diff_result(file_a, file_b, diff_data)


@app.command(name="status")
def status_files(
    file_a: Path = typer.Argument(..., exists=True, help="Path to the first .tmdl or .pbip file."),
    file_b: Path = typer.Argument(..., exists=True, help="Path to the second .tmdl or .pbip file."),
) -> None:
    """Show whether two TMDL export files differ."""
    diff_data = compute_diff(file_a, file_b)
    if diff_data["diff"]:
        console.print(
            Panel.fit(
                f"Files differ:\n[file]{file_a.name}[/file]\n[file]{file_b.name}[/file]\n\n"
                f"Added lines: {diff_data['added']}\n"
                f"Removed lines: {diff_data['removed']}",
                title="⚠️ TMDL Status",
            )
        )
    else:
        console.print(
            Panel.fit(
                f"Files are identical:\n[file]{file_a.name}[/file]\n[file]{file_b.name}[/file]",
                title="✅ TMDL Status",
            )
        )


@app.command(name="compare")
def compare_interactive() -> None:
    """Interactively choose two local files to compare."""
    open_models = get_open_pbi_models()
    if open_models:
        console.print("[bold blue]Detected open Power BI models. You can export them to .tmdl and compare the exported snapshots.[/bold blue]\n")
        for model in open_models:
            console.print(f"- {model['name']} (port {model['port']})\n  workspace: {model.get('workspace', 'n/a')}")
        console.print(
            "[yellow]Note: this tool compares exported TMDL/PBIP files. Open models are listed for reference, but you must select saved snapshot files for comparison.[/yellow]\n"
        )

    available_files = find_tmdl_files()
    if available_files:
        file_a = choose_file("Select the first file to compare:", available_files)
        file_b = choose_file("Select the second file to compare:", available_files)

        if file_a == file_b:
            console.print("[red]Please select two different files to compare.[/red]")
            raise typer.Exit(1)
    else:
        console.print("[yellow]No .tmdl or .pbip files were found in the current directory.[/yellow]")
        file_a = choose_file("Enter the path to the first TMDL/PBIP file:", [])
        file_b = choose_file("Enter the path to the second TMDL/PBIP file:", [])

    if file_a.suffix.lower() in ['.pbip', '.pbix'] and file_b.suffix.lower() in ['.pbip', '.pbix']:
        changes = compare_models(file_a, file_b)
        render_semantic_diff(file_a, file_b, changes)
    else:
        diff_data = compute_diff(file_a, file_b)
        render_diff_result(file_a, file_b, diff_data)


@app.command(name="compare-open")
def compare_open_instances() -> None:
    """Choose two detected Power BI Desktop instances and inspect their workspaces."""
    open_models = get_open_pbi_models()
    if not open_models:
        console.print("[red]No open Power BI Desktop instances detected.[/red]")
        console.print("Open Power BI Desktop and load a model, then try again.")
        raise typer.Exit(1)

    choices = [f"{model['name']} (port {model['port']}) - {model.get('workspace', 'workspace unknown')}" for model in open_models]
    selected = questionary.checkbox(
        "Select exactly 2 open Power BI models to compare:",
        choices=choices,
        validate=lambda x: True if len(x) == 2 else "Please select exactly 2 models."
    ).ask()

    if not selected:
        console.print("[red]Operation cancelled.[/red]")
        raise typer.Exit(1)

    selected_models = [open_models[choices.index(choice)] for choice in selected]
    console.print("\n[bold green]Selected open models:[/bold green]")
    for model in selected_models:
        console.print(f"- {model['name']} (port {model['port']})\n  workspace: {model['workspace']}")

    console.print(
        "\n[yellow]To compare these models, export each model to a .tmdl/.pbip file and then run `tmdl-diff diff file1.tmdl file2.tmdl`.[/yellow]"
    )


if __name__ == "__main__":
    app()
