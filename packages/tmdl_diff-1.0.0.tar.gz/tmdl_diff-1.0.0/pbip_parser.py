import json
import zipfile
import re
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime


def extract_pbip_model(file_path: Path) -> Optional[Dict[str, Any]]:
    """
    Extract model definition from a .pbip file.
    PBIP files can be ZIP archives or directory-based projects.
    Returns a model dict with structure information or None if extraction fails.
    """
    try:
        # Check if it's a directory-based PBIP (modern format)
        base_name = file_path.stem  # e.g., "Baptist" from "Baptist.pbip"
        semantic_model_dir = file_path.parent / f"{base_name}.SemanticModel"
        
        if semantic_model_dir.exists() and semantic_model_dir.is_dir():
            return _extract_from_directory(semantic_model_dir)
        
        # Try as ZIP-based PBIP (older format or .pbix)
        try:
            with zipfile.ZipFile(file_path, 'r') as zip_ref:
                return _extract_from_zip(zip_ref)
        except (zipfile.BadZipFile, FileNotFoundError):
            return None
            
    except Exception:
        return None


def _extract_from_directory(sem_model_dir: Path) -> Optional[Dict[str, Any]]:
    """Extract model definition from a directory-based semantic model."""
    try:
        model_tmdl_path = sem_model_dir / "model.tmdl"
        if not model_tmdl_path.exists():
            return None
        
        with open(model_tmdl_path, 'r', encoding='utf-8') as f:
            model_text = f.read()
        
        # Parse the TMDL file to extract model metadata
        model_data = _parse_tmdl(model_text, sem_model_dir)
        return model_data
    except Exception:
        return None


def _extract_from_zip(zip_ref: zipfile.ZipFile) -> Optional[Dict[str, Any]]:
    """Extract model definition from a ZIP-based PBIP/PBIX file."""
    try:
        files = zip_ref.namelist()
        model_file = None
        
        for candidate in ['model.json', 'Model/definition.json', 'definition.json']:
            if candidate in files:
                model_file = candidate
                break
        
        if not model_file:
            return None
        
        with zip_ref.open(model_file) as f:
            model_data = json.load(f)
            return model_data
    except Exception:
        return None


def _parse_tmdl(tmdl_text: str, sem_model_dir: Path) -> Dict[str, Any]:
    """Parse TMDL format and extract model structure."""
    model_data = {
        "tables": [],
        "measures": [],
        "relationships": [],
        "expressions": [],
    }
    
    # Extract model name
    name_match = re.search(r'table\s+(\w+)', tmdl_text, re.IGNORECASE)
    
    # List all TMDL files to get tables
    for tmdl_file in sem_model_dir.glob("*.tmdl"):
        if tmdl_file.name in ['model.tmdl', 'relationships.tmdl', 'expressions.tmdl', 'database.tmdl']:
            continue
        
        table_name = tmdl_file.stem
        model_data["tables"].append({"name": table_name, "file": tmdl_file.name})
    
    # Parse relationships from relationships.tmdl
    rel_file = sem_model_dir / "relationships.tmdl"
    if rel_file.exists():
        with open(rel_file, 'r', encoding='utf-8') as f:
            rel_text = f.read()
        
        relationship_matches = re.findall(r'relationship\s+(?:fromTable|sourceTable|table)\s*:\s*(\w+).*?(?:toTable|targetTable)\s*:\s*(\w+)', rel_text, re.IGNORECASE | re.DOTALL)
        for from_table, to_table in relationship_matches:
            model_data["relationships"].append({"from": from_table, "to": to_table})
    
    # Count measures
    for tmdl_file in sem_model_dir.glob("*.tmdl"):
        with open(tmdl_file, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            measure_count = len(re.findall(r'measure\s+\w+', content, re.IGNORECASE))
            if measure_count > 0:
                model_data["measures"].append({
                    "file": tmdl_file.name,
                    "count": measure_count
                })
    
    return model_data


def compare_models(file_a: Path, file_b: Path) -> Dict[str, List[Dict]]:
    """
    Compare two PBIP directories and return added, removed, and modified objects.
    """
    changes = {
        "tables_added": [],
        "tables_removed": [],
        "tables_modified": [],
        "relationships_added": [],
        "relationships_removed": [],
        "relationships_modified": [],
    }
    
    # Get semantic model directories
    base_a = file_a.stem
    base_b = file_b.stem
    
    sem_model_a = file_a.parent / f"{base_a}.SemanticModel"
    sem_model_b = file_b.parent / f"{base_b}.SemanticModel"
    
    if not sem_model_a.exists() or not sem_model_b.exists():
        return changes
    
    # Get all TMDL files recursively
    all_files_a = {f.relative_to(sem_model_a): f for f in sem_model_a.rglob("*.tmdl")}
    all_files_b = {f.relative_to(sem_model_b): f for f in sem_model_b.rglob("*.tmdl")}
    
    # Added files
    for path in set(all_files_b.keys()) - set(all_files_a.keys()):
        changes["tables_added"].append({"name": str(path)})
    
    # Removed files
    for path in set(all_files_a.keys()) - set(all_files_b.keys()):
        changes["tables_removed"].append({"name": str(path)})
    
    # Modified files - compare content
    for path in set(all_files_a.keys()) & set(all_files_b.keys()):
        file_a_path = all_files_a[path]
        file_b_path = all_files_b[path]
        
        with open(file_a_path, 'rb') as f:
            content_a = f.read()
        with open(file_b_path, 'rb') as f:
            content_b = f.read()
        
        if content_a != content_b:
            changes["tables_modified"].append({"name": str(path)})
    
    return changes
