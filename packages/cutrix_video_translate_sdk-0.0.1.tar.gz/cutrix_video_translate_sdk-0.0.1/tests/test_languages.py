"""Tests for cutrix.languages – supported language constants."""
from __future__ import annotations

import cutrix
from cutrix.languages import SOURCE_LANGUAGES, TARGET_LANGUAGES, SourceLanguage, TargetLanguage


class TestSourceLanguages:
    def test_auto_is_supported(self) -> None:
        assert "auto" in SOURCE_LANGUAGES

    def test_known_languages_present(self) -> None:
        expected = {"zh", "en", "ja", "ko", "fr", "de", "es", "ar", "ru", "hi"}
        assert expected <= SOURCE_LANGUAGES

    def test_extended_languages_present(self) -> None:
        assert "yue" in SOURCE_LANGUAGES   # Cantonese
        assert "fil" in SOURCE_LANGUAGES   # Filipino
        assert "fa" in SOURCE_LANGUAGES    # Persian
        assert "mk" in SOURCE_LANGUAGES    # Macedonian

    def test_is_frozenset(self) -> None:
        assert isinstance(SOURCE_LANGUAGES, frozenset)

    def test_all_values_are_lowercase_strings(self) -> None:
        for code in SOURCE_LANGUAGES:
            assert isinstance(code, str)
            assert code == code.lower(), f"{code!r} should be lowercase"


class TestTargetLanguages:
    def test_does_not_include_auto(self) -> None:
        assert "auto" not in TARGET_LANGUAGES

    def test_known_languages_present(self) -> None:
        expected = {"zh", "en", "ja", "ko", "fr", "de", "es", "ar", "ru", "hi"}
        assert expected <= TARGET_LANGUAGES

    def test_target_only_languages_present(self) -> None:
        assert "sw" in TARGET_LANGUAGES   # Swahili
        assert "no" in TARGET_LANGUAGES   # Norwegian
        assert "he" in TARGET_LANGUAGES   # Hebrew

    def test_is_frozenset(self) -> None:
        assert isinstance(TARGET_LANGUAGES, frozenset)

    def test_all_values_are_lowercase_strings(self) -> None:
        for code in TARGET_LANGUAGES:
            assert isinstance(code, str)
            assert code == code.lower(), f"{code!r} should be lowercase"


class TestLiteralTypesMatchFrozensets:
    def test_source_language_literal_matches_frozenset(self) -> None:
        literal_args = set(SourceLanguage.__args__)  # type: ignore[attr-defined]
        assert literal_args == SOURCE_LANGUAGES

    def test_target_language_literal_matches_frozenset(self) -> None:
        literal_args = set(TargetLanguage.__args__)  # type: ignore[attr-defined]
        assert literal_args == TARGET_LANGUAGES


class TestPublicExports:
    def test_source_languages_exported(self) -> None:
        assert cutrix.SOURCE_LANGUAGES is SOURCE_LANGUAGES

    def test_target_languages_exported(self) -> None:
        assert cutrix.TARGET_LANGUAGES is TARGET_LANGUAGES

    def test_source_language_type_exported(self) -> None:
        assert cutrix.SourceLanguage is SourceLanguage

    def test_target_language_type_exported(self) -> None:
        assert cutrix.TargetLanguage is TargetLanguage
