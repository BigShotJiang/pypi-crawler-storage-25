from collections.abc import Callable
from pathlib import Path

import httpx
import pytest

from cutrix import (
    AuthenticationError,
    Client,
    FAILED_CODE_MESSAGES,
    RateLimitError,
    SDKError,
    UploadVideoCompleteResponse,
    UploadVideoInitResponse,
    UploadVideoSTS,
    VideoTaskDetailResponse,
    VideoTranslateTaskResponse,
)
from cutrix.exceptions import APIError

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SUCCESS_ENVELOPE = {
    "code": 0,
    "message": "success",
    "detail": {
        "task_id": 945,
        "required_minutes": 1,
        "video_duration_seconds": 16.767667,
    },
}

_TASK_DETAIL_ENVELOPE = {
    "code": 0,
    "message": "success",
    "detail": {
        "id": 945,
        "type": "one_click",
        "status": "pending",
        "created_at": "2026-03-25T12:00:00",
        "estimate_finish_time": "2026-03-25T12:05:00",
        "finished_at": None,
        "source_lang": "en",
        "target_lang": "zh",
        "input_video_duration": 16.767667,
        "name": "demo task",
        "failed_code": None,
        "input_video_jpg": "",
        "output_video_path": "",
        "input_video_path": "",
    },
}


def _make_client(handler: httpx.MockTransport | None = None) -> Client:
    transport = handler or httpx.MockTransport(
        lambda _: httpx.Response(200, json=_SUCCESS_ENVELOPE)
    )
    return Client(api_key="sk-test", http_client=httpx.Client(transport=transport))


def _patch_upload_pipeline(
    client: Client,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        client.video,
        "_init_upload_video",
        lambda _: UploadVideoInitResponse(
            upload_video_id="upload-123",
            upload_cos_key="videos/demo.mp4",
            sts=UploadVideoSTS(
                session_token="token",
                tmp_secret_id="secret-id",
                tmp_secret_key="secret-key",
                expired_time=1,
                start_time=1,
                bucket="bucket-123",
                region="ap-shanghai",
            ),
        ),
    )
    monkeypatch.setattr(client.video, "_upload_to_cos", lambda **_: None)
    monkeypatch.setattr(
        client.video,
        "_complete_upload_video",
        lambda upload_video_id: UploadVideoCompleteResponse(
            upload_video_id=upload_video_id,
            size=123,
            content_type="video/mp4",
            etag="etag",
            crc64="crc64",
            status="completed",
        ),
    )


# ---------------------------------------------------------------------------
# Happy-path tests
# ---------------------------------------------------------------------------


def test_translate_returns_typed_model(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = _make_client()
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        result = client.video.translate(
            file_path=file_path,
            target_lang="zh",
        )
    finally:
        client.close()

    assert isinstance(result, VideoTranslateTaskResponse)
    assert result.task_id == 945
    assert result.required_minutes == 1
    assert result.video_duration_seconds == pytest.approx(16.767667)


def test_translate_sends_correct_method_and_path(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_SUCCESS_ENVELOPE)

    client = _make_client(httpx.MockTransport(handler))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        client.video.translate(file_path=file_path, target_lang="zh")
    finally:
        client.close()

    assert len(captured) == 1
    req = captured[0]
    assert req.method == "POST"
    assert req.url.path == "/v1/translate_video_task/create"


def test_translate_sends_auth_header(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_SUCCESS_ENVELOPE)

    client = _make_client(httpx.MockTransport(handler))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        client.video.translate(file_path=file_path, target_lang="zh")
    finally:
        client.close()

    assert captured[0].headers["Authorization"] == "sk-test"


def test_translate_sends_required_form_fields(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_SUCCESS_ENVELOPE)

    client = _make_client(httpx.MockTransport(handler))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        client.video.translate(
            file_path=file_path,
            target_lang="zh",
            source_lang="en",
            task_name="my task",
            add_subtitle=False,
            erase_original_subtitle=True,
            remove_cutrix_logo=False,
        )
    finally:
        client.close()

    content_type = captured[0].headers.get("content-type", "")
    assert "multipart/form-data" in content_type

    body = captured[0].read().decode()
    assert "upload-123" in body
    assert "zh" in body
    assert "en" in body
    assert "my task" in body
    assert 'name="is_logo"' in body
    assert "false" in body   # add_subtitle=False
    assert "true" in body    # erase_original_subtitle=True


def test_translate_source_lang_defaults_to_auto(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_SUCCESS_ENVELOPE)

    client = _make_client(httpx.MockTransport(handler))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        client.video.translate(file_path=file_path, target_lang="zh")
    finally:
        client.close()

    body = captured[0].read().decode()
    assert "auto" in body


def test_translate_file_alias_uploads_then_creates_task(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[httpx.Request] = []
    upload_events: list[tuple[str, str]] = []
    progress_updates: list[int] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_SUCCESS_ENVELOPE)

    client = _make_client(httpx.MockTransport(handler))
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")

    def fake_init(file_name: str) -> UploadVideoInitResponse:
        upload_events.append(("init", file_name))
        return UploadVideoInitResponse(
            upload_video_id="upload-123",
            upload_cos_key="videos/demo.mp4",
            sts=UploadVideoSTS(
                session_token="token",
                tmp_secret_id="secret-id",
                tmp_secret_key="secret-key",
                expired_time=1,
                start_time=1,
                bucket="bucket-123",
                region="ap-shanghai",
            ),
        )

    def fake_upload(
        *,
        file_path: Path,
        init: UploadVideoInitResponse,
        progress_callback: Callable[[int], None] | None,
    ) -> None:
        upload_events.append(("upload", str(file_path)))
        assert init.upload_video_id == "upload-123"
        assert progress_callback is not None
        progress_callback(47)

    def fake_complete(upload_video_id: str) -> UploadVideoCompleteResponse:
        upload_events.append(("complete", upload_video_id))
        return UploadVideoCompleteResponse(
            upload_video_id=upload_video_id,
            size=123,
            content_type="video/mp4",
            etag="etag",
            crc64="crc64",
            status="completed",
        )

    monkeypatch.setattr(client.video, "_init_upload_video", fake_init)
    monkeypatch.setattr(client.video, "_upload_to_cos", fake_upload)
    monkeypatch.setattr(client.video, "_complete_upload_video", fake_complete)

    try:
        result = client.video.translate_file(
            file_path=file_path,
            target_lang="zh",
            source_lang="en",
            task_name="local demo",
            progress_callback=progress_updates.append,
        )
    finally:
        client.close()

    assert isinstance(result, VideoTranslateTaskResponse)
    assert upload_events == [
        ("init", "demo.mp4"),
        ("upload", str(file_path)),
        ("complete", "upload-123"),
    ]
    assert progress_updates == [0, 47, 100]

    assert len(captured) == 1
    assert captured[0].url.path == "/v1/translate_video_task/create"
    body = captured[0].read().decode()
    assert "upload-123" in body
    assert "local demo" in body
    assert "https://example.com/video.mp4" not in body


def test_translate_file_raises_when_local_file_is_missing(tmp_path: Path) -> None:
    client = _make_client()
    missing = tmp_path / "missing.mp4"

    try:
        with pytest.raises(SDKError) as exc_info:
            client.video.translate_file(file_path=missing, target_lang="zh")
    finally:
        client.close()

    assert str(missing) in str(exc_info.value)


def test_get_task_returns_typed_model() -> None:
    transport = httpx.MockTransport(lambda _: httpx.Response(200, json=_TASK_DETAIL_ENVELOPE))
    client = Client(api_key="sk-test", http_client=httpx.Client(transport=transport))
    try:
        result = client.video.get_task(task_id=945)
    finally:
        client.close()

    assert isinstance(result, VideoTaskDetailResponse)
    assert result.id == 945
    assert result.status == "pending"
    assert result.target_lang == "zh"
    assert result.input_video_duration == pytest.approx(16.767667)
    assert result.failed_message is None


def test_get_task_exposes_failed_message_for_known_failed_code() -> None:
    envelope = {
        **_TASK_DETAIL_ENVELOPE,
        "detail": {
            **_TASK_DETAIL_ENVELOPE["detail"],
            "status": "failed",
            "failed_code": 2002,
        },
    }
    transport = httpx.MockTransport(lambda _: httpx.Response(200, json=envelope))
    client = Client(api_key="sk-test", http_client=httpx.Client(transport=transport))
    try:
        result = client.video.get_task(task_id=945)
    finally:
        client.close()

    assert result.failed_code == 2002
    assert result.failed_message == (
        "No audio was detected. Please make sure the video contains an audio track."
    )


def test_failed_code_messages_export_contains_known_codes() -> None:
    assert FAILED_CODE_MESSAGES["2001"] == (
        "Automatic language detection failed. Please select the source language manually "
        "and try again."
    )
    assert FAILED_CODE_MESSAGES["2005"] == (
        "The source and target languages are the same, so translation is not needed."
    )


def test_get_task_sends_correct_method_path_and_form_data() -> None:
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_TASK_DETAIL_ENVELOPE)

    transport = httpx.Client(transport=httpx.MockTransport(handler))
    client = Client(api_key="sk-test", http_client=transport)
    try:
        client.video.get_task(task_id=945)
    finally:
        client.close()

    assert len(captured) == 1
    req = captured[0]
    assert req.method == "POST"
    assert req.url.path == "/v1/get_video_task"
    assert req.headers["Authorization"] == "sk-test"
    body = req.read().decode()
    assert "945" in body


def test_get_task_rate_limits_high_frequency_calls(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: list[httpx.Request] = []
    monotonic_values = iter([100.0, 100.2])
    sleep_calls: list[float] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(200, json=_TASK_DETAIL_ENVELOPE)

    def fake_monotonic() -> float:
        return next(monotonic_values)

    def fake_sleep(seconds: float) -> None:
        sleep_calls.append(seconds)

    transport = httpx.Client(transport=httpx.MockTransport(handler))
    client = Client(api_key="sk-test", http_client=transport)
    monkeypatch.setattr("cutrix.resources.video.time.monotonic", fake_monotonic)
    monkeypatch.setattr("cutrix.resources.video.time.sleep", fake_sleep)
    try:
        client.video.get_task(task_id=945)
        client.video.get_task(task_id=946)
    finally:
        client.close()

    assert len(captured) == 2
    assert sleep_calls == [pytest.approx(0.8)]


# ---------------------------------------------------------------------------
# Error-mapping tests
# ---------------------------------------------------------------------------


def test_translate_maps_authentication_errors(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(401, json={"error": {"message": "Invalid API key"}})
    )
    client = Client(api_key="bad-key", http_client=httpx.Client(transport=transport))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        with pytest.raises(AuthenticationError) as exc_info:
            client.video.translate(file_path=file_path, target_lang="zh")
    finally:
        client.close()

    assert exc_info.value.status_code == 401
    assert exc_info.value.message == "Invalid API key"


def test_translate_maps_rate_limit_errors(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    transport = httpx.MockTransport(
        lambda _: httpx.Response(429, json={"message": "Too many requests"})
    )
    client = Client(api_key="sk-test", http_client=httpx.Client(transport=transport))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        with pytest.raises(RateLimitError) as exc_info:
            client.video.translate(file_path=file_path, target_lang="zh")
    finally:
        client.close()

    assert exc_info.value.status_code == 429
    assert exc_info.value.message == "Too many requests"


def test_translate_raises_on_nonzero_api_code(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A 200 response with code != 0 should raise APIError."""
    transport = httpx.MockTransport(
        lambda _: httpx.Response(
            200, json={"code": 1001, "message": "Insufficient credits", "detail": None}
        )
    )
    client = Client(api_key="sk-test", http_client=httpx.Client(transport=transport))
    _patch_upload_pipeline(client, monkeypatch)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"fake video bytes")
    try:
        with pytest.raises(APIError) as exc_info:
            client.video.translate(file_path=file_path, target_lang="zh")
    finally:
        client.close()

    assert "Insufficient credits" in exc_info.value.message
