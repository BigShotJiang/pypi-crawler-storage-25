import httpx
import pytest
from pathlib import Path

from cutrix import Client


def test_client_attaches_video_resource() -> None:
    client = Client(api_key="secret")

    try:
        assert client.video is not None
    finally:
        client.close()


def test_client_uses_raw_authorization_value_with_custom_http_client(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return httpx.Response(
            200,
            json={"code": 0, "message": "success", "detail": {
                "task_id": 1, "required_minutes": 1, "video_duration_seconds": 5.0
            }},
        )

    http_client = httpx.Client(transport=httpx.MockTransport(handler))
    client = Client(api_key="secret", http_client=http_client)
    file_path = tmp_path / "demo.mp4"
    file_path.write_bytes(b"demo")

    monkeypatch.setattr(
        client.video,
        "_init_upload_video",
        lambda _: type(
            "Init",
            (),
            {"upload_video_id": "upload-123"},
        )(),
    )
    monkeypatch.setattr(client.video, "_upload_to_cos", lambda **_: None)
    monkeypatch.setattr(client.video, "_complete_upload_video", lambda _: None)

    try:
        client.video.translate(file_path=file_path, target_lang="en")
    finally:
        client.close()

    assert len(captured) == 1
    # Authorization header must be injected even when a custom client is used,
    # and the original http_client must NOT be mutated.
    assert captured[0].headers["Authorization"] == "secret"
    assert "Authorization" not in http_client.headers
