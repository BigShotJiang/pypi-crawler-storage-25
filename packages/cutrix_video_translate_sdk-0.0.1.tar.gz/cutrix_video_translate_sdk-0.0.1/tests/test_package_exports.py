import cutrix
import cutrix_sdk


def test_primary_package_exports_client() -> None:
    assert cutrix.Client is not None


def test_compatibility_package_exports_client() -> None:
    assert cutrix_sdk.Client is cutrix.Client
