from __future__ import annotations

from collections.abc import Mapping
from importlib.metadata import PackageNotFoundError, version
from typing import Any

import httpx

from .exceptions import APIError, AuthenticationError, RateLimitError

DEFAULT_BASE_URL = "https://www.cutrix.cc/v1"
DEFAULT_TIMEOUT = 30.0

try:
    _sdk_version = version("cutrix-video-translate-sdk")
except PackageNotFoundError:
    _sdk_version = "unknown"

# Content-Type is NOT included here; each request method sets it contextually
# so that JSON requests and form requests don't share a conflicting default.
DEFAULT_HEADERS = {
    "Accept": "application/json",
    "User-Agent": f"cutrix-python/{_sdk_version}",
}


class HTTPClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        headers: Mapping[str, str] | None = None,
        client: httpx.Client | None = None,
    ) -> None:
        # See: docs/ARCHITECTURE.md#http-layer
        self._base_url = httpx.URL(f"{base_url.rstrip('/')}/")
        self._timeout = timeout
        auth_and_defaults: dict[str, str] = {
            **DEFAULT_HEADERS,
            # Cutrix API authenticates with a bare API key (no "Bearer" prefix).
            "Authorization": api_key,
            **dict(headers or {}),
        }
        self._owns_client = client is None
        # When a custom client is provided we inject auth and default headers at
        # request time (see request_json) rather than mutating the caller's object.
        self._request_headers: dict[str, str] | None = None
        if client is not None:
            self._client = client
            self._request_headers = auth_and_defaults
        else:
            self._client = httpx.Client(
                base_url=str(self._base_url),
                timeout=timeout,
                headers=auth_and_defaults,
            )

    def request_json(
        self,
        method: str,
        path: str,
        *,
        params: Mapping[str, Any] | None = None,
        json: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        json_headers = {**(self._request_headers or {}), "Content-Type": "application/json"}
        response = self._client.request(
            method,
            self._build_url(path),
            params=params,
            json=json,
            headers=json_headers,
            timeout=timeout if timeout is not None else self._timeout,
        )
        if response.is_error:
            raise self._build_api_error(response)

        return self._parse_json(response)

    def request_form(
        self,
        method: str,
        path: str,
        *,
        data: Mapping[str, str],
        params: Mapping[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """Send a multipart/form-data request. httpx sets Content-Type automatically."""
        # Pass all fields through `files=` as (None, value) tuples — this is
        # the httpx idiom for text-only multipart/form-data, matching browser
        # FormData behaviour without requiring actual file objects.
        multipart_fields = {k: (None, v) for k, v in data.items()}
        response = self._client.request(
            method,
            self._build_url(path),
            params=params,
            files=multipart_fields,
            headers=self._request_headers,
            timeout=timeout if timeout is not None else self._timeout,
        )
        if response.is_error:
            raise self._build_api_error(response)

        return self._parse_json(response)

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def _build_url(self, path: str) -> str:
        return str(self._base_url.join(path.lstrip("/")))

    def _parse_json(self, response: httpx.Response) -> dict[str, Any]:
        try:
            data = response.json()
        except ValueError as exc:
            raise APIError(
                message="Expected a JSON response from the API.",
                status_code=response.status_code,
                raw_response=response.text,
            ) from exc

        if not isinstance(data, dict):
            raise APIError(
                message="Expected the API response body to be a JSON object.",
                status_code=response.status_code,
                raw_response=data,
            )
        return data

    def _build_api_error(self, response: httpx.Response) -> APIError:
        raw_response: Any
        try:
            raw_response = response.json()
        except ValueError:
            raw_response = response.text

        message = self._extract_error_message(raw_response, response)
        status_code = response.status_code

        if status_code == 401:
            return AuthenticationError(
                message=message,
                status_code=status_code,
                raw_response=raw_response,
            )
        if status_code == 429:
            return RateLimitError(
                message=message,
                status_code=status_code,
                raw_response=raw_response,
            )
        return APIError(
            message=message,
            status_code=status_code,
            raw_response=raw_response,
        )

    def _extract_error_message(self, raw_response: Any, response: httpx.Response) -> str:
        if isinstance(raw_response, dict):
            error = raw_response.get("error")
            if isinstance(error, dict):
                message = error.get("message")
                if isinstance(message, str) and message:
                    return message
            message = raw_response.get("message")
            if isinstance(message, str) and message:
                return message

        if isinstance(raw_response, str) and raw_response:
            return raw_response

        return f"Request failed with status {response.status_code}."
