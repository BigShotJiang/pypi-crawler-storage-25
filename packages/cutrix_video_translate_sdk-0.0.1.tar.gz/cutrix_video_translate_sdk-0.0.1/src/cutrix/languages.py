from __future__ import annotations

"""Supported language codes for Cutrix video translation.

Use :data:`SOURCE_LANGUAGES` and :data:`TARGET_LANGUAGES` to enumerate valid
values at runtime.  The :class:`SourceLanguage` and :class:`TargetLanguage`
type aliases provide IDE auto-complete for ``source_lang`` / ``target_lang``
parameters.

Example::

    from cutrix import SOURCE_LANGUAGES, TARGET_LANGUAGES

    print("zh" in TARGET_LANGUAGES)   # True
    print("auto" in SOURCE_LANGUAGES)  # True
"""

from typing import Final, FrozenSet, Literal

# ---------------------------------------------------------------------------
# Type aliases – used as annotations on video translation entrypoints
# ---------------------------------------------------------------------------

SourceLanguage = Literal[
    "auto",
    "zh",   # Chinese (Mandarin)
    "en",   # English
    "yue",  # Cantonese
    "ar",   # Arabic
    "cs",   # Czech
    "da",   # Danish
    "de",   # German
    "el",   # Greek
    "es",   # Spanish
    "fa",   # Persian
    "fi",   # Finnish
    "fil",  # Filipino
    "fr",   # French
    "hi",   # Hindi
    "hu",   # Hungarian
    "id",   # Indonesian
    "it",   # Italian
    "ja",   # Japanese
    "ko",   # Korean
    "mk",   # Macedonian
    "ms",   # Malay
    "nl",   # Dutch
    "pl",   # Polish
    "pt",   # Portuguese
    "ro",   # Romanian
    "ru",   # Russian
    "sv",   # Swedish
    "th",   # Thai
    "tr",   # Turkish
    "vi",   # Vietnamese
]

TargetLanguage = Literal[
    "zh",   # Chinese (Mandarin)
    "en",   # English
    "ar",   # Arabic
    "da",   # Danish
    "de",   # German
    "el",   # Greek
    "es",   # Spanish
    "fi",   # Finnish
    "fr",   # French
    "he",   # Hebrew
    "hi",   # Hindi
    "it",   # Italian
    "ja",   # Japanese
    "ko",   # Korean
    "ms",   # Malay
    "nl",   # Dutch
    "no",   # Norwegian
    "pl",   # Polish
    "pt",   # Portuguese
    "ru",   # Russian
    "sv",   # Swedish
    "sw",   # Swahili
    "tr",   # Turkish
]

# ---------------------------------------------------------------------------
# Runtime sets – use these for membership checks in application code
# ---------------------------------------------------------------------------

SOURCE_LANGUAGES: Final[FrozenSet[str]] = frozenset(SourceLanguage.__args__)  # type: ignore[attr-defined]

TARGET_LANGUAGES: Final[FrozenSet[str]] = frozenset(TargetLanguage.__args__)  # type: ignore[attr-defined]
