from __future__ import annotations

from datetime import datetime
from typing import Callable, Final

from pydantic import BaseModel, ConfigDict, Field


FAILED_CODE_MESSAGES: Final[dict[str, str]] = {
    "2001": "Automatic language detection failed. Please select the source language manually and try again.",
    "2002": "No audio was detected. Please make sure the video contains an audio track.",
    "2003": "No video was detected. Please make sure the file contains video content.",
    "2004": "Unknown error. Please try again later or contact support.",
    "2005": "The source and target languages are the same, so translation is not needed.",
}


class VideoTranslateTaskResponse(BaseModel):
    """Returned by client.video.translate(...).

    This represents an async translation job created from a local file upload.
    Poll the task status using ``task_id`` until the job completes.
    """

    model_config = ConfigDict(extra="allow")

    task_id: int
    required_minutes: int
    video_duration_seconds: float


class UploadVideoSTS(BaseModel):
    # Fields use aliases to match the camelCase API response keys while
    # exposing Pythonic snake_case names to SDK users.
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    session_token: str = Field(alias="sessionToken")
    tmp_secret_id: str = Field(alias="tmpSecretId")
    tmp_secret_key: str = Field(alias="tmpSecretKey")
    expired_time: int = Field(alias="expiredTime")
    start_time: int = Field(alias="startTime")
    bucket: str
    region: str


class UploadVideoInitResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    upload_video_id: str
    upload_cos_key: str
    sts: UploadVideoSTS


class UploadVideoCompleteResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    upload_video_id: str
    size: int
    content_type: str
    etag: str
    crc64: str
    status: str


class VideoTaskDetailResponse(BaseModel):
    """Returned by client.video.get_task(...)."""

    model_config = ConfigDict(extra="allow")

    id: int
    type: str | None = None
    status: str | None = None
    created_at: datetime | None = None
    estimate_finish_time: datetime | None = None
    finished_at: datetime | None = None
    source_lang: str | None = None
    target_lang: str | None = None
    input_video_duration: float | None = None
    name: str | None = None
    failed_code: int | str | None = None
    input_video_jpg: str = ""
    output_video_path: str = ""
    input_video_path: str = ""

    @property
    def task_id(self) -> int:
        """Alias for ``id``, consistent with :attr:`VideoTranslateTaskResponse.task_id`."""
        return self.id

    @property
    def failed_message(self) -> str | None:
        """Human-readable message for ``failed_code`` when known."""
        if self.failed_code is None:
            return None
        return FAILED_CODE_MESSAGES.get(str(self.failed_code))


UploadProgressCallback = Callable[[int], None]
