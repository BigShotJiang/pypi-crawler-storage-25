from __future__ import annotations

from typing import Any


class SDKError(Exception):
    """Base exception for all SDK errors."""


class APIError(SDKError):
    def __init__(
        self,
        *,
        message: str,
        status_code: int | None,
        raw_response: Any,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.raw_response = raw_response


class AuthenticationError(APIError):
    """Raised when the API rejects the provided credentials."""


class RateLimitError(APIError):
    """Raised when the API rate limit is exceeded."""
