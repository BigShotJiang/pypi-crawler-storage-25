from __future__ import annotations

import threading
import time
from pathlib import Path
from typing import Any

from .._http import HTTPClient
from ..exceptions import APIError, SDKError
from ..models import (
    UploadProgressCallback,
    UploadVideoCompleteResponse,
    UploadVideoInitResponse,
    VideoTaskDetailResponse,
    VideoTranslateTaskResponse,
)


class VideoResource:
    _GET_TASK_MIN_INTERVAL_SECONDS = 1.0

    def __init__(self, http_client: HTTPClient) -> None:
        # See: docs/ARCHITECTURE.md#resource-layer
        self._http = http_client
        self._get_task_lock = threading.Lock()
        self._next_get_task_at = 0.0

    def translate(
        self,
        *,
        file_path: str | Path,
        target_lang: str,
        source_lang: str = "auto",
        task_name: str | None = None,
        add_subtitle: bool = True,
        erase_original_subtitle: bool = False,
        remove_cutrix_logo: bool = True,
        progress_callback: UploadProgressCallback | None = None,
    ) -> VideoTranslateTaskResponse:
        """Upload a local file and create a video translation task.

        Args:
            file_path: Local path of the source video file to upload.
            target_lang: BCP-47 language code for the output language.
                See :data:`cutrix.TARGET_LANGUAGES` for supported values.
            source_lang: BCP-47 language code of the source audio, or ``"auto"`` for
                automatic detection.  See :data:`cutrix.SOURCE_LANGUAGES` for supported
                values.  Defaults to ``"auto"``.
            task_name: Optional human-readable label for the task.
            add_subtitle: Whether to burn subtitles into the output video. Defaults to ``True``.
            erase_original_subtitle: Whether to erase existing hard-coded subtitles from the
                source video before adding translated ones. Defaults to ``False``.
            remove_cutrix_logo: Whether to request removal of the Cutrix logo in the
                output. Internally this maps to the API field ``is_logo``. Defaults
                to ``True``.
            progress_callback: Optional callback receiving upload progress percentages from
                0 to 100.

        Returns:
            :class:`VideoTranslateTaskResponse` containing the ``task_id`` for polling.
        """
        path = Path(file_path).expanduser()
        if not path.is_file():
            raise SDKError(f"Local file does not exist: {path}")

        if progress_callback is not None:
            progress_callback(0)

        init = self._init_upload_video(path.name)
        self._upload_to_cos(
            file_path=path,
            init=init,
            progress_callback=progress_callback,
        )
        self._complete_upload_video(init.upload_video_id)
        if progress_callback is not None:
            progress_callback(100)

        raw = self._http.request_form(
            "POST",
            "/translate_video_task/create",
            data=self._build_create_form(
                upload_video_id=init.upload_video_id,
                target_lang=target_lang,
                source_lang=source_lang,
                task_name=task_name,
                add_subtitle=add_subtitle,
                erase_original_subtitle=erase_original_subtitle,
                remove_cutrix_logo=remove_cutrix_logo,
            ),
        )
        detail = self._unwrap(raw)
        return VideoTranslateTaskResponse.model_validate(detail)

    def translate_file(
        self,
        *,
        file_path: str | Path,
        target_lang: str,
        source_lang: str = "auto",
        task_name: str | None = None,
        add_subtitle: bool = True,
        erase_original_subtitle: bool = False,
        remove_cutrix_logo: bool = True,
        progress_callback: UploadProgressCallback | None = None,
    ) -> VideoTranslateTaskResponse:
        """Backward-compatible alias for :meth:`translate`."""
        return self.translate(
            file_path=file_path,
            target_lang=target_lang,
            source_lang=source_lang,
            task_name=task_name,
            add_subtitle=add_subtitle,
            erase_original_subtitle=erase_original_subtitle,
            remove_cutrix_logo=remove_cutrix_logo,
            progress_callback=progress_callback,
        )

    def get_task(self, *, task_id: int) -> VideoTaskDetailResponse:
        """Fetch a video translation task by task ID."""
        self._throttle_get_task()
        raw = self._http.request_form(
            "POST",
            "/get_video_task",
            data={"task_id": str(task_id)},
        )
        detail = self._unwrap(raw)
        return VideoTaskDetailResponse.model_validate(detail)

    def _build_create_form(
        self,
        *,
        upload_video_id: str,
        target_lang: str,
        source_lang: str,
        task_name: str | None,
        add_subtitle: bool,
        erase_original_subtitle: bool,
        remove_cutrix_logo: bool,
    ) -> dict[str, str]:
        form: dict[str, str] = {
            "url": "",
            "upload_video_id": upload_video_id,
            "target_lang": target_lang,
            "source_lang": source_lang,
            "task_name": task_name or "",
            "add_subtitle": str(add_subtitle).lower(),
            "erase_original_subtitle": str(erase_original_subtitle).lower(),
            # Fixed internal fields — not exposed to callers in this SDK version.
            "type": "one_click",
            "is_multi_speaker": "true",
            "dynamic_adjust_duration": "true",
            "is_logo": str(remove_cutrix_logo).lower(),
        }
        return form

    def _init_upload_video(self, file_name: str) -> UploadVideoInitResponse:
        raw = self._http.request_form(
            "POST",
            "/upload_video/init",
            data={"file_name": file_name},
        )
        detail = self._unwrap(raw)
        return UploadVideoInitResponse.model_validate(detail)

    def _complete_upload_video(self, upload_video_id: str) -> UploadVideoCompleteResponse:
        raw = self._http.request_form(
            "POST",
            "/upload_video/complete",
            data={"upload_video_id": upload_video_id},
        )
        detail = self._unwrap(raw)
        return UploadVideoCompleteResponse.model_validate(detail)

    def _upload_to_cos(
        self,
        *,
        file_path: Path,
        init: UploadVideoInitResponse,
        progress_callback: UploadProgressCallback | None,
    ) -> None:
        try:
            from qcloud_cos import CosConfig, CosS3Client
        except ImportError as exc:
            raise SDKError(
                "Missing required dependency 'cos-python-sdk-v5'. "
                "Install the package with: pip install cutrix-video-translate-sdk"
            ) from exc

        config = CosConfig(
            Region=init.sts.region,
            SecretId=init.sts.tmp_secret_id,
            SecretKey=init.sts.tmp_secret_key,
            Token=init.sts.session_token,
        )
        client = CosS3Client(config)

        def _report_progress(consumed_bytes: int, total_bytes: int) -> None:
            if progress_callback is None or total_bytes <= 0:
                return
            progress = round(consumed_bytes / total_bytes * 95)
            progress_callback(progress)

        # MD5 is disabled to avoid the extra per-chunk computation overhead
        # on large files; COS server-side integrity checks remain active.
        client.upload_file(
            Bucket=init.sts.bucket,
            Key=init.upload_cos_key,
            LocalFilePath=str(file_path),
            EnableMD5=False,
            progress_callback=_report_progress,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _throttle_get_task(self) -> None:
        """Apply a small per-client delay to avoid hot-loop task polling."""
        with self._get_task_lock:
            now = time.monotonic()
            wait_seconds = self._next_get_task_at - now
            if wait_seconds > 0:
                time.sleep(wait_seconds)
                now = self._next_get_task_at

            self._next_get_task_at = now + self._GET_TASK_MIN_INTERVAL_SECONDS

    def _unwrap(self, raw: dict[str, Any]) -> dict[str, Any]:
        """Extract ``detail`` from the standard API envelope.

        The Cutrix API wraps every response in::

            {"code": 0, "message": "success", "detail": {...}}

        A non-zero ``code`` is treated as an application-level error.
        """
        code = raw.get("code")
        if code != 0:
            message = raw.get("message") or f"API returned code {code}"
            raise APIError(message=str(message), status_code=None, raw_response=raw)

        detail = raw.get("detail")
        if not isinstance(detail, dict):
            raise APIError(
                message="Expected 'detail' object in API response.",
                status_code=None,
                raw_response=raw,
            )
        return detail
