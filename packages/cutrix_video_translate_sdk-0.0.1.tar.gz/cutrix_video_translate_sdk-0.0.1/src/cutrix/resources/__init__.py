from .video import VideoResource

__all__ = ["VideoResource"]
