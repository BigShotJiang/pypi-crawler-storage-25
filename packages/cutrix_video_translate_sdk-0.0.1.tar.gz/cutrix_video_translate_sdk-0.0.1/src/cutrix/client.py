from __future__ import annotations

from collections.abc import Mapping

import httpx

from ._http import DEFAULT_BASE_URL, HTTPClient
from .resources import VideoResource


class Client:
    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
        headers: Mapping[str, str] | None = None,
        http_client: httpx.Client | None = None,
    ) -> None:
        # See: docs/ARCHITECTURE.md#client-layer
        self._http = HTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            headers=headers,
            client=http_client,
        )
        self.video = VideoResource(self._http)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> Client:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
