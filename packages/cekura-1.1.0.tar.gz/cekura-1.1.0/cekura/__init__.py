"""
Cekura SDK - Observability for AI Agents
"""

__author__ = "Cekura"
__email__ = "support@cekura.ai"

# Get version from package metadata
try:
    from importlib.metadata import version
    __version__ = version("cekura")
except Exception:
    __version__ = "0.0.0.dev0"

from cekura.livekit import LiveKitTracer

__all__ = ["LiveKitTracer", "__version__"]
