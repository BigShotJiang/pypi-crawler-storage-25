"""CLI entrypoint for mattermind."""
