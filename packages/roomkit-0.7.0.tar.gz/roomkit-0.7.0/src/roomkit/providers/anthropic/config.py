"""Anthropic provider configuration."""

from __future__ import annotations

from pydantic import BaseModel, SecretStr


class AnthropicConfig(BaseModel):
    """Anthropic AI provider configuration."""

    api_key: SecretStr
    model: str = "claude-sonnet-4-20250514"
    max_tokens: int = 1024
    temperature: float = 0.7
    timeout: float = 60.0
    """Request timeout in seconds (default 60s)."""
    base_url: str | None = None
    """Override the base URL (e.g., for Claude Code sandbox proxy)."""
    extra_headers: dict[str, str] | None = None
    """Extra headers sent with every request (e.g., X-Tenant-ID)."""
