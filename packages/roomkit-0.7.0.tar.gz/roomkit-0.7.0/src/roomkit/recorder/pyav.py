"""PyAV-based media recorder — muxes audio + video into a single MP4."""

from __future__ import annotations

import logging
import os
import threading
import time
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from roomkit.recorder._pyav_mux import (
    ENCODED_VIDEO_CODECS,
    compute_pts,
    create_stream,
    h264_annex_b,
    import_av,
    probe_encoded_dimensions,
    safe_mux,
)
from roomkit.recorder.base import (
    MediaRecorder,
    MediaRecordingConfig,
    MediaRecordingHandle,
    MediaRecordingResult,
    RecordingTrack,
    validate_storage_path,
)

logger = logging.getLogger("roomkit.recorder.pyav")


@dataclass
class _TrackState:
    """Per-track muxing state."""

    track: RecordingTrack
    stream: Any = None
    frame_count: int = 0
    last_pts: int = -1  # monotonic guard for PTS (video)
    audio_end: int = 0  # next expected sample position (audio cursor)
    video_fps: int = 30  # stream rate for video timestamp→PTS conversion
    decoder: Any = None  # codec context for decoding encoded video
    pending: list[tuple[bytes, float | None]] = field(default_factory=list)
    t0_ms: float = 0.0  # per-track timestamp origin
    mux_error_logged: bool = False  # per-track first-error suppression flag


@dataclass
class _RecordingState:
    """Per-recording muxing state."""

    config: MediaRecordingConfig = field(default_factory=MediaRecordingConfig)
    tracks: dict[str, _TrackState] = field(default_factory=dict)
    lock: threading.Lock = field(default_factory=threading.Lock)
    container: Any = None
    path: str = ""
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    encoding_started: bool = False


class PyAVMediaRecorder(MediaRecorder):
    """Muxes audio (AAC) and video (H.264/VP9) into a single MP4 via PyAV.

    MP4 requires all streams to exist before any data is muxed.
    Streams are created when all registered tracks are "ready":

    - Audio tracks are ready immediately (codec is known at registration).
    - Video tracks become ready when the first frame arrives (the tap
      populates ``track.codec`` from the frame).

    If only some tracks have data, frames are buffered until all tracks
    are ready.  Once ready, all streams are created and buffered frames
    are flushed.

    A/V sync strategy: both audio and video PTS are derived from each
    frame's capture timestamp (set at acquisition time), so playback
    speed matches real time regardless of the configured stream rate
    or actual capture FPS.  Falls back to frame-count PTS when
    timestamps are unavailable.

    Thread-safe: each recording has its own lock so video frames from
    capture threads and audio from the event loop can write concurrently.
    """

    @property
    def name(self) -> str:
        return "pyav"

    def __init__(self) -> None:
        self._av = import_av()
        self._recordings: dict[str, _RecordingState] = {}

    # -- lifecycle -----------------------------------------------------------

    def on_recording_start(self, config: MediaRecordingConfig) -> MediaRecordingHandle:
        handle_id = uuid4().hex[:12]
        ts = datetime.now(UTC).strftime("%Y%m%dT%H%M%S")
        storage = config.storage or os.path.join(os.getcwd(), "recordings")
        resolved = validate_storage_path(storage)
        path = os.path.join(resolved, f"room_{handle_id}_{ts}.{config.format}")

        state = _RecordingState(config=config, path=path)
        self._recordings[handle_id] = state

        handle = MediaRecordingHandle(
            id=handle_id,
            room_id="",
            state="recording",
            started_at=state.started_at,
            path=path,
        )
        logger.info("PyAV recording created: %s → %s", handle_id, path)
        return handle

    def on_recording_stop(self, handle: MediaRecordingHandle) -> MediaRecordingResult:
        state = self._recordings.pop(handle.id, None)
        if state is None:
            return MediaRecordingResult(id=handle.id)

        result_tracks: list[RecordingTrack] = []
        with state.lock:
            if state.container is not None:
                for ts in state.tracks.values():
                    result_tracks.append(ts.track)
                    if ts.stream is not None and ts.frame_count > 0:
                        try:
                            for packet in ts.stream.encode(None):
                                state.container.mux(packet)
                        except Exception:
                            logger.debug("Flush error for track %s", ts.track.id)
                    ts.decoder = None
                frame_counts = {
                    t.id: state.tracks[t.id].frame_count
                    for t in result_tracks
                    if t.id in state.tracks
                }
                logger.info(
                    "Closing container %s (%d tracks, %s frames)",
                    state.path,
                    len(result_tracks),
                    frame_counts,
                )
                state.container.close()
                state.container = None

        handle.state = "stopped"
        duration = (datetime.now(UTC) - state.started_at).total_seconds()
        size_bytes = 0
        if os.path.exists(state.path):
            size_bytes = os.path.getsize(state.path)
        return MediaRecordingResult(
            id=handle.id,
            url=state.path,
            duration_seconds=duration,
            tracks=result_tracks,
            format=state.config.format,
            size_bytes=size_bytes,
        )

    # -- track management ----------------------------------------------------

    def on_track_added(self, handle: MediaRecordingHandle, track: RecordingTrack) -> None:
        state = self._recordings.get(handle.id)
        if state is None:
            return
        with state.lock:
            ts = _TrackState(track=track)
            state.tracks[track.id] = ts

            # If encoding already started, we can't add streams to an MP4
            # container after muxing. Log a warning — to fix, ensure all
            # channels connect before video capture starts, or increase
            # the encoding_delay_seconds on MediaRecordingConfig.
            if state.encoding_started and state.container is not None:
                logger.warning(
                    "Late track %s (%s) added after encoding started — "
                    "audio won't be recorded. Connect voice before video capture.",
                    track.id,
                    track.kind,
                )

        logger.debug("Track registered: %s (%s)", track.id, track.kind)

    def on_track_removed(self, handle: MediaRecordingHandle, track: RecordingTrack) -> None:
        state = self._recordings.get(handle.id)
        if state is None:
            return
        with state.lock:
            ts = state.tracks.pop(track.id, None)
            if ts and ts.stream and state.container and ts.frame_count > 0:
                try:
                    for packet in ts.stream.encode(None):
                        state.container.mux(packet)
                except Exception:
                    logger.debug("Flush error on track removal: %s", track.id)

    # -- data ingestion ------------------------------------------------------

    def on_data(
        self,
        handle: MediaRecordingHandle,
        track: RecordingTrack,
        data: bytes,
        timestamp_ms: float | None,
    ) -> None:
        state = self._recordings.get(handle.id)
        if state is None:
            return

        with state.lock:
            ts = state.tracks.get(track.id)
            if ts is None:
                return

            if not state.encoding_started:
                ts.pending.append((data, timestamp_ms))
                if self._all_tracks_ready(state):
                    logger.info(
                        "Encoding started: %d tracks, pending=%s",
                        len(state.tracks),
                        {tid: len(t.pending) for tid, t in state.tracks.items()},
                    )
                    self._start_encoding(state)
                return

            self._encode_frame(state, ts, track, data, timestamp_ms)
            ts.frame_count += 1

    # -- internal helpers ----------------------------------------------------

    @staticmethod
    def _track_ready(ts: _TrackState) -> bool:
        if ts.track.kind != "video":
            return True
        if ts.track.codec:
            return True
        if ts.track.width is not None and ts.track.height is not None:
            return True
        return bool(ts.pending)

    def _all_tracks_ready(self, state: _RecordingState) -> bool:
        return all(self._track_ready(ts) for ts in state.tracks.values())

    def _start_encoding(self, state: _RecordingState) -> None:
        # Probe dimensions for encoded video tracks
        for ts in state.tracks.values():
            if (
                ts.track.kind == "video"
                and ts.track.codec in ENCODED_VIDEO_CODECS
                and ts.track.width is None
                and ts.pending
            ):
                dims = probe_encoded_dimensions(
                    self._av,
                    ts.pending,
                    ts.track.codec,
                )
                if dims:
                    ts.track.width, ts.track.height = dims
                    logger.info(
                        "Probed video %s: %s %dx%d",
                        ts.track.id,
                        ts.track.codec,
                        dims[0],
                        dims[1],
                    )

        # Skip video tracks whose dimensions are still unknown
        skipped: set[str] = set()
        for ts in state.tracks.values():
            if (
                ts.track.kind == "video"
                and ts.track.codec in ENCODED_VIDEO_CODECS
                and (ts.track.width is None or ts.track.height is None)
            ):
                skipped.add(ts.track.id)
                logger.warning(
                    "Skipping video track %s — unknown dimensions",
                    ts.track.id,
                )

        # Disable strict interleaving — video encoders (libx264) buffer
        # frames, so audio can advance well ahead before any video packets
        # are produced.  Without this, the MP4 muxer rejects audio with
        # EINVAL once the interleave gap exceeds ~1 second.
        state.container = self._av.open(
            state.path,
            mode="w",
            options={"max_interleave_delta": "0"},
        )
        for ts in state.tracks.values():
            if ts.track.id not in skipped:
                ts.stream = create_stream(
                    state.container,
                    ts.track,
                    state.config,
                )
                if ts.track.kind == "video":
                    ts.video_fps = state.config.video_fps

        state.encoding_started = True

        # Per-track t0: each stream starts at PTS=0 from its own first
        # frame.  Camera init is slower than mic so audio pending frames
        # captured before the first video frame are dropped.  This keeps
        # both streams aligned — PTS=0 is the moment the LAST track
        # became ready (typically the camera).
        now = time.monotonic() * 1000
        latest_first: float | None = None
        for ts in state.tracks.values():
            for _, ts_ms in ts.pending:
                if ts_ms is not None:
                    if latest_first is None or ts_ms > latest_first:
                        latest_first = ts_ms
                    break  # only need first pending per track
        sync_t0 = latest_first if latest_first is not None else now
        for ts in state.tracks.values():
            ts.t0_ms = sync_t0
        pending_counts = {ts.track.id: len(ts.pending) for ts in state.tracks.values()}
        logger.info(
            "Encoding started: pending=%s",
            pending_counts,
        )

        # Flush buffered frames, dropping audio captured before sync_t0.
        for ts in state.tracks.values():
            if ts.stream is None:
                ts.pending.clear()
                continue
            for data, ts_ms in ts.pending:
                # Drop audio frames from before the sync point
                if ts.track.kind == "audio" and ts_ms is not None and ts_ms < sync_t0:
                    continue
                try:
                    self._encode_frame(state, ts, ts.track, data, ts_ms)
                    ts.frame_count += 1
                except Exception:
                    logger.error(
                        "Flush failed for track %s at frame %d — skipping",
                        ts.track.id,
                        ts.frame_count,
                        exc_info=True,
                    )
                    # Skip this frame, keep flushing — one corrupt packet
                    # must not drop every subsequent buffered frame.
                    continue
            ts.pending.clear()

    def _encode_frame(
        self,
        state: _RecordingState,
        ts: _TrackState,
        track: RecordingTrack,
        data: bytes,
        timestamp_ms: float | None,
    ) -> None:
        if track.kind == "video":
            self._write_video(state, ts, data, timestamp_ms)
        elif track.kind == "audio":
            self._write_audio(state, ts, data, timestamp_ms)

    def _write_video(
        self,
        state: _RecordingState,
        ts: _TrackState,
        data: bytes,
        timestamp_ms: float | None,
    ) -> None:
        if ts.stream is None:
            return
        if ts.track.codec in ENCODED_VIDEO_CODECS:
            self._write_encoded_video(state, ts, data, timestamp_ms)
        else:
            self._write_raw_video(state, ts, data, timestamp_ms)

    def _write_raw_video(
        self,
        state: _RecordingState,
        ts: _TrackState,
        data: bytes,
        timestamp_ms: float | None,
    ) -> None:
        import numpy as np

        w, h = ts.stream.width, ts.stream.height
        expected = w * h * 3
        if len(data) < expected:
            data = data + b"\x00" * (expected - len(data))
        arr = np.frombuffer(data[:expected], dtype=np.uint8).reshape(h, w, 3)
        frame = self._av.VideoFrame.from_ndarray(arr, format="rgb24")
        frame.pts = compute_pts(
            timestamp_ms,
            ts.t0_ms,
            ts.video_fps,
            ts.last_pts,
            ts.frame_count,
        )
        ts.last_pts = frame.pts
        safe_mux(
            ts.stream,
            state.container,
            frame,
            ts,
            state.path,
            label="raw_video",
        )

    def _write_encoded_video(
        self,
        state: _RecordingState,
        ts: _TrackState,
        data: bytes,
        timestamp_ms: float | None,
    ) -> None:
        if ts.stream is None:
            return
        if ts.decoder is None:
            ts.decoder = self._av.CodecContext.create(ts.track.codec, "r")

        # Each data blob is a single NAL from RTP depacketization
        raw = h264_annex_b(data) if ts.track.codec == "h264" else data
        try:
            decoded_frames = ts.decoder.decode(self._av.Packet(raw))
        except Exception:
            logger.debug("Decode error for track %s", ts.track.id)
            return

        for decoded_frame in decoded_frames:
            decoded_frame.pts = compute_pts(
                timestamp_ms,
                ts.t0_ms,
                ts.video_fps,
                ts.last_pts,
                ts.frame_count,
            )
            ts.last_pts = decoded_frame.pts
            safe_mux(
                ts.stream,
                state.container,
                decoded_frame,
                ts,
                state.path,
                label=f"encoded_video:{ts.track.codec}",
            )

    def _write_audio(
        self,
        state: _RecordingState,
        ts: _TrackState,
        data: bytes,
        timestamp_ms: float | None,
    ) -> None:
        import numpy as np

        stream = ts.stream
        if stream is None:
            return

        samples = np.frombuffer(data, dtype=np.int16).reshape(1, -1)
        num_samples = len(samples[0])

        # Where this frame should start (wall-clock position for A/V sync).
        if timestamp_ms is not None:
            wall_pos = max(round((timestamp_ms - ts.t0_ms) / 1000.0 * stream.rate), 0)
        else:
            wall_pos = ts.audio_end

        # PTS = max(wall_clock, audio_cursor).
        # - Normal: wall_pos ≈ audio_end → follows wall-clock (A/V sync).
        # - Burst:  wall_pos < audio_end → sample-rate spacing (AAC safe).
        # - After burst: wall_pos > audio_end → snaps back to clock.
        # - Gap:    wall_pos >> audio_end → silence injected first.
        pts = max(wall_pos, ts.audio_end)

        # Inject silence for large gaps so the AAC encoder flushes.
        gap = pts - ts.audio_end
        if gap > stream.rate // 10:  # > 100 ms
            self._write_silence(state, ts, gap)

        frame = self._av.audio.frame.AudioFrame.from_ndarray(
            samples,
            format="s16",
            layout="mono",
        )
        frame.sample_rate = stream.rate
        frame.pts = max(wall_pos, ts.audio_end)
        ts.audio_end = frame.pts + num_samples
        ts.last_pts = frame.pts
        safe_mux(
            stream,
            state.container,
            frame,
            ts,
            state.path,
            label="audio",
        )

    def _write_silence(
        self,
        state: _RecordingState,
        ts: _TrackState,
        num_samples: int,
    ) -> None:
        """Inject silence frames to fill a gap in the audio stream."""
        import numpy as np

        stream = ts.stream
        if stream is None:
            return
        chunk = min(num_samples, stream.rate)
        remaining = num_samples
        while remaining > 0:
            n = min(remaining, chunk)
            silence = np.zeros((1, n), dtype=np.int16)
            frame = self._av.audio.frame.AudioFrame.from_ndarray(
                silence,
                format="s16",
                layout="mono",
            )
            frame.sample_rate = stream.rate
            frame.pts = ts.audio_end
            ts.audio_end += n
            ts.last_pts = frame.pts
            if not safe_mux(
                stream,
                state.container,
                frame,
                ts,
                state.path,
                label="audio",
            ):
                break
            remaining -= n

    def close(self) -> None:
        for handle_id in list(self._recordings):
            state = self._recordings.pop(handle_id, None)
            if state is not None and state.container is not None:
                with state.lock:
                    if state.container is not None:
                        state.container.close()
                        state.container = None
