# `safe-file-example`

## Description

A python package for interacting with SAFE File transfer API

## Current Functionalities

- Generate a JWT Token 
- Import a File
- Export a File

## Prerequisite 

- Having minimum Python 3.12 installed in your system and setting up a Python Virtual Environment. 

## Workflow

- Activate your Python Virtual Environment, 
- Then run the following command.

```bash
pip install safe-file-example
```
- To see all the available commands and options run the following

```bash
safe-file-example
```

**Usage**:

```console
$ safe-file-example [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--help`: Show this message and exit.

**Commands**:

* `token`: Get and store access token
* `import-file`: Import a file
* `export-file`: Export a file
* `interactive`: Run interactive mode

## `safe-file-example token`

Get and store access token

**Usage**:

```console
$ safe-file-example token [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.

## `safe-file-example import-file`

Import a file

**Usage**:

```console
$ safe-file-example import-file [OPTIONS]
```

**Options**:

* `--server TEXT`: Server name
* `--file-path FILE`: Path to file to import
* `-i, --interactive`: Run import interactively
* `--help`: Show this message and exit.

## `safe-file-example export-file`

Export a file

**Usage**:

```console
$ safe-file-example export-file [OPTIONS]
```

**Options**:

* `--server TEXT`: Server name
* `--filename TEXT`: Filename to export
* `--output-dir DIRECTORY`: Output directory
* `-i, --interactive`: Run export interactively
* `--help`: Show this message and exit.

## `safe-file-example interactive`

Run interactive mode

**Usage**:

```console
$ safe-file-example interactive [OPTIONS]
```

**Options**:

* `--help`: Show this message and exit.