import sys
import typer
import webbrowser
import jwt
import os
import time
import tkinter as tk
from tkinter import filedialog
from pathlib import Path
import safe.modules.import_module as import_module
import safe.modules.export_module as export_module
import safe.modules.list_export_module as list_export_module
import safe.modules.select_helper as select_option
import importlib.resources
try:
    import readline
except ImportError:
    pass

app = typer.Typer(invoke_without_command=True, add_completion=False)

# Variables
config_dir = os.path.expanduser("~/.safe-cli")
token_file = os.path.join(config_dir, "token.json")
base_url = "https://api.safe.uib.no/v1"
logo_path = importlib.resources.files("safe.assets").joinpath("safe_logo.png")

def get_access_token():
    endpoint = "/auth"
    auth_url = f"{base_url}{endpoint}"
    webbrowser.open(auth_url)
    
    Access_token = input("Paste You're JWT token here: ")
    
    os.makedirs(config_dir, exist_ok=True)
    with open(token_file, "w") as f:
        f.write(Access_token)
    if os.name != 'nt':
        os.chmod(token_file, 0o600) #Change the ownership on Linux/MacOS
    print("token succesfully stored")

def exit_cli():
    sys.exit()

def importFile():
    endpoint = "/files/import"
    url = f"{base_url}{endpoint}"

    # Read token from stored file
    if not os.path.exists(token_file):
        print("No token found. Run option 1 to authenticate.")
        return

    with open(token_file, "r") as f:
        token = f.read().strip()

    while True:
        server = input("Enter the server name: ").strip()
        if not server:
            print("Please enter a valid server.")
            continue
        # File picker
        print("opening file picker")
        root = tk.Tk()
        app_icon = tk.PhotoImage(file=str(logo_path))
        root.withdraw()
        root.attributes('-topmost', True)
        root.iconphoto(True, app_icon)
        root.update()
        file_path_str = filedialog.askopenfilename(title="Select a file to import", initialdir=os.path.expanduser("~"))
        root.attributes('-topmost', False)
        root.iconphoto(False, app_icon)
        root.destroy()

        if not file_path_str:
            print("No file selected, try again.")
            continue

        file_path = Path(file_path_str)
        
        print("\n--- Import Summary ---")
        print(f"\nServer: {server}")
        print(f"File:   {file_path.name}\n")

        proceed = input("Proceed? (yes/no/change): ").strip().lower()

        if proceed == "yes":
            success = import_module.upload_file(
                file_path=file_path,
                url=url,
                token=token,
                filename_param=file_path.name,
                server=server,
            )
            print(f"Import result: {success}")
            break

        elif proceed == "change":
            continue
        else:
            print("Import cancelled.")
            break

def exportFile():
    export_endpoint = "/files/export"
    export_url = f"{base_url}{export_endpoint}"

    # Read token
    if not os.path.exists(token_file):
        print("No token found. Run option 1 to authenticate.")
        return

    with open(token_file, "r") as f:
        token = f.read().strip()

    while True:
        server = input("Enter the server name: ").strip()
        if not server:
            print("Please enter a valid server.")
            continue

        # ---- LIST AVAILABLE FILES ----
        files = list_export_module.list_export_files(
            base_url=base_url,
            token=token,
            server=server,
        )

        if not files:
            print("No exportable files found.")
            return

        while True:
            filename = select_option.select_from_list(
                files,
                "Select file by number or type filename: "
            )
            if filename:
                break


        # ---- Directory picker ----
        print("Select output directory")
        root = tk.Tk()
        app_icon = tk.PhotoImage(file=str(logo_path))
        root.withdraw()
        root.attributes("-topmost", True)
        root.iconphoto(True, app_icon)
        root.update()
        output_dir = filedialog.askdirectory(title="Select output directory", initialdir=os.path.expanduser("~"))
        root.attributes("-topmost", False)
        root.iconphoto(False, app_icon)
        root.destroy()
        # ---------------------------

        if not output_dir:
            print("No directory selected, try again.")
            continue

        output_path = Path(output_dir) / filename

        print("\n--- Export Summary ---")
        print(f"Server:   {server}")
        print(f"Filename: {filename}")
        print(f"Output:   {output_path}")
        print("----------------------\n")

        proceed = input("Proceed? (yes/no/change): ").strip().lower()

        if proceed == "yes":
            success = export_module.write_file_to_disk(
                download_path=output_path,
                download_url=export_url,
                token=token,
                server=server,
                filename=filename,
            )
            print(f"Export result: {success}")
            return

        elif proceed == "change":
            continue

        else:
            print("Export cancelled.")
            return

def check_token():
    if os.path.exists(token_file):
        with open(token_file, "r") as f:
            token = f.read().strip()
        try:
            decoded = jwt.decode(token, options={"verify_signature": False})
            exp = decoded.get("exp")
            if exp is not None:
                current_time = int(time.time())
                if current_time > exp:
                    print("The stored JWT token is expired.")
                else:
                    print("The stored JWT token is valid.")
            else:
                print("No expiration (exp) claim found in the JWT token.")
        except Exception as e:
            print(f"Failed to decode JWT token: {e}")
    else:
        print("No JWT token found in the token file.")

@app.callback()
def main(ctx:typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()

@app.command()
def token():
    """Get and store access token"""
    get_access_token()

@app.command()
def import_file(
    server: str = typer.Option(None, help="Server name"),
    file_path: Path = typer.Option(None, exists=True, file_okay=True, dir_okay=False, readable=True, help="Path to file to import"),
    interactive: bool = typer.Option(False, "-i", "--interactive", help="Run import interactively"),
):
    """Import a file"""
    if interactive or not (server and file_path):
        # Run interactive import
        importFile()
    else:
        # Non-interactive import
        endpoint = "/files/import"
        url = f"{base_url}{endpoint}"

        if not os.path.exists(token_file):
            typer.echo("No token found. Run 'get-token' to authenticate.")
            raise typer.Exit(code=1)

        with open(token_file, "r") as f:
            token = f.read().strip()

        typer.echo(f"Importing file {file_path} to server {server}...")

        success = import_module.upload_file(
            file_path=file_path,
            url=url,
            token=token,
            filename_param=file_path.name,
            server=server,
        )
        typer.echo(f"Import result: {success}")

@app.command()
def export_file(
    server: str = typer.Option(None, help="Server name"),
    filename: str = typer.Option(None, help="Filename to export"),
    output_dir: Path = typer.Option(None, exists=True, file_okay=False, dir_okay=True, writable=True, help="Output directory"),
    interactive: bool = typer.Option(False, "-i", "--interactive", help="Run export interactively"),
):
    """Export a file"""
    if interactive or not (server and filename and output_dir):
        # Run interactive export
        exportFile()
    else:
        # Non-interactive export
        export_endpoint = "/files/export"
        export_url = f"{base_url}{export_endpoint}"

        if not os.path.exists(token_file):
            typer.echo("No token found. Run 'get-token' to authenticate.")
            raise typer.Exit(code=1)

        with open(token_file, "r") as f:
            token = f.read().strip()

        output_path = output_dir / filename

        typer.echo(f"Exporting file {filename} from server {server} to {output_path}...")

        success = export_module.write_file_to_disk(
            download_path=output_path,
            download_url=export_url,
            token=token,
            server=server,
            filename=filename,
        )
        typer.echo(f"Export result: {success}")


def interactive_menu():
    check_token()
    choices: list = [get_access_token, importFile, exportFile, exit_cli]
    while True:
        print("\n--- SAFE CLI ---")
        for index, item in enumerate(choices, start=1):
            print(f"{index}. {item.__name__}")

        menu_names = [fn.__name__ for fn in choices]
        selection = select_option.select_from_list(
            menu_names,
            "Enter menu number or command name: "
        )
        if not selection:
            continue

        selected_fn = choices[menu_names.index(selection)]

        if selected_fn == exit_cli:
            exit_cli()
            return
        else:
            selected_fn()

@app.command(name="interactive")
def interactive_command():
    """Run interactive mode"""
    interactive_menu()

app.command()(token)
app.command()(import_file)
app.command()(export_file)

if __name__ == "__main__":
    app()
    