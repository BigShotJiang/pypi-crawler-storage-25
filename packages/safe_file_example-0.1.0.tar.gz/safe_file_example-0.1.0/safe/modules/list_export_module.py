import requests
from typing import List

def list_export_files(
    base_url: str,
    token: str,
    server: str,
    page: int = 1,
    pagination: bool = True,
    timeout: int = 30,
) -> List[str]:

    url = f"{base_url}/files/info/list/export"

    headers = {
        "Authorization": f"Bearer {token}"
    }

    params = {
        "server": server,
        "page": page,
        "pagination": pagination,
    }

    try:
        resp = requests.get(
            url,
            headers=headers,
            params=params,
            timeout=timeout,
        )
        resp.raise_for_status()

        data = resp.json()

        files = []

        # Extract filenames
        content = data.get("content", {})
        entries = content.get("Files and Directories", [])
        for entry in entries:
            if isinstance(entry, dict):
                files.extend(entry.keys())

        # Pretty print
        print("\n--- Available export files ---")
        if not files:
            print("(No files found)")
        else:
            for i, name in enumerate((files), start=1):
                print(f"{i}. {name}")
        print("------------------------------\n")

        return files

    except requests.HTTPError as e:
        print(f"HTTP {e.response.status_code}: {e.response.text}")
        return []
    except Exception as e:
        print(f"Unexpected error: {e}")
        return []
