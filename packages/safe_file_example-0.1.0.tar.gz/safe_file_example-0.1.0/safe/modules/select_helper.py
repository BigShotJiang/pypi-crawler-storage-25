
def select_from_list(options: list[str], prompt: str) -> str | None:
    """
    Allow selection by number or exact name.
    Returns the selected string or None if invalid.
    """
    choice = input(prompt).strip()

    # Number selection
    if choice.isdigit():
        idx = int(choice) - 1
        if 0 <= idx < len(options):
            return options[idx]
        print("Invalid number.")
        return None

    # Name selection
    if choice in options:
        return choice

    print("Invalid selection.")
    return None
