import os
import mimetypes
import requests
from pathlib import Path


def open_file_stream(path: Path):
    return path.open("rb")


def upload_file(
    file_path: Path,
    url: str,
    token: str,
    filename_param: str,
    server: str,
) -> bool:
    if not file_path.is_file():
        raise FileNotFoundError(f"File not found: {file_path}")
    if not server:
        raise RuntimeError("Server name not provided")

    mime, _ = mimetypes.guess_type(file_path.name)
    content_type = mime or "application/octet-stream"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": content_type,
    }
    params = {"filename": filename_param, "server": server}

    print(f"Uploading {file_path.name} ({content_type})...")

    try:
        with open_file_stream(file_path) as f:
            resp = requests.post(
                url,
                headers=headers,
                params=params,
                data=f,
            )

        # Error handling
        if resp.status_code == 400:
            print("Bad Request - invalid filename or no file.")
            print(resp.text)
            return False
        if resp.status_code == 401:
            print("Unauthorized - no import access.")
            print(resp.text)
            return False
        if resp.status_code == 409:
            print("Conflict - file already exists.")
            print(resp.text)
            return False
        if resp.status_code == 500:
            print("Internal server error.")
            print(resp.text)
            return False

        resp.raise_for_status()
        print("Upload succeeded:", resp.text)
        return True

    except requests.HTTPError as http_err:
        print("Unexpected HTTP error:", http_err)
        print("Response:", http_err.response.text)
        return False
    except Exception as e:
        print("Unexpected error:", type(e).__name__, e)
        return False