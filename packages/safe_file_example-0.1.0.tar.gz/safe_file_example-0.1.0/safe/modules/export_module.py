from pathlib import Path
import os
import shutil
import requests


def write_file_to_disk(
    download_path: Path,
    download_url: str,
    token: str,
    server: str,
    filename: str,
    chunk_size: int = 8 * 1024 * 1024,
    connect_timeout: float = 15,
    read_timeout: float = 600,
) -> bool:
    print(f"Starting download to {download_path}")

    temp_path = download_path.with_suffix(download_path.suffix + ".safetmp")
    download_path.parent.mkdir(parents=True, exist_ok=True)

    headers = {
        "Authorization": f"Bearer {token}"
    }

    params = {
        "filename": filename,
        "server": server,
    }

    try:
        with requests.get(
            download_url,
            headers=headers,
            params=params,
            stream=True,
            timeout=(connect_timeout, read_timeout),
        ) as response:
            response.raise_for_status()

            total = int(response.headers.get("Content-Length") or 0)
            if total:
                free = shutil.disk_usage(download_path.parent).free
                if total > free:
                    raise OSError(
                        f"Not enough free disk space ({free} bytes) for {total} bytes"
                    )

            with open(temp_path, "wb") as f:
                for chunk in response.iter_content(chunk_size=chunk_size):
                    if chunk:
                        f.write(chunk)

        os.replace(temp_path, download_path)
        print("download completed:", download_path)
        return True

    except Exception as e:
        if temp_path.exists():
            try:
                temp_path.unlink()
            except Exception:
                pass
        print("Download failed")
        return False