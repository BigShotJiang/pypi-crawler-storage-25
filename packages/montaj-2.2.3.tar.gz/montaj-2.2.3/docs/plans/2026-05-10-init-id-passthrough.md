# Init ID Passthrough — let callers pin a project's `id`

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Allow callers of `POST /api/run` (and `python -m project.init`) to supply the `id` field that Montaj writes into `project.json`, instead of forcing a server-generated `uuid.uuid4()`. When absent, current behavior is preserved.

**Architecture:** One CLI flag (`--id`) on `project/init.py` plus one body field (`id`) on `POST /api/run`. Both parse the input via `uuid.UUID()` and store the **canonicalized** result (`str(uuid.UUID(raw))`) — that is, lowercase 8-4-4-4-12 hex with dashes — substituted into `project.json["id"]` in two places: the `_build_carousel_project` helper and the inline general project dict in `main()`. All downstream consumers (`find_project_dir`, the SSE watcher, `lib/ai_video.py`) already read `project.json["id"]` as opaque, so no further plumbing is needed. Pure additive change — no migration, no behavior change for existing callers.

**Tech Stack:** Python 3.12, FastAPI (server), `argparse` (CLI), `uuid` stdlib (parse + validate), pytest (tests), Montaj's existing `bad_request`/`fail` error helpers.

---

## Atomized Changes

| File | Action | Purpose |
|---|---|---|
| `project/init.py` | Modify | Add `--id` argparse argument with UUID-format validation. Substitute the value into both project dicts (carousel at line ~124, general at line ~535) instead of `str(uuid.uuid4())`; fall back to `uuid.uuid4()` when absent. Validation lives at the top of `main()` alongside other early arg checks. |
| `serve/routes/projects.py` | Modify | `POST /api/run`: read `body.get("id")`, validate UUID format with a single shared `_validate_optional_uuid` helper, and forward as `--id <value>` to the init.py subprocess in BOTH branches (carousel fast path at line ~217-238 and general path at line ~370-409). Validation happens before any subprocess is forked. |
| `tests/test_init.py` | Modify | Add CLI-level tests: `--id <valid-uuid>` produces a `project.json` whose `id` matches; `--id <invalid>` exits non-zero with `invalid_id`; absence preserves current generated-UUID behavior. Cover both carousel and non-carousel paths. |
| `tests/test_server_subnesting.py` | Modify | Add HTTP-level tests: `POST /api/run` with `id` in body produces a project whose `id` matches; with malformed `id` returns 400 `invalid_id`; without `id` keeps current behavior. Cover both carousel and non-carousel workflows. The test file already exercises `/api/run` end-to-end against a real init.py subprocess, which is the right harness here. |
| `CHANGELOG.md` | Modify | One-line entry: callers can now pin `project.json["id"]` via `POST /api/run` body field `id` or `init.py --id`; absent → server generates a UUID as before. |
| `docs/plans/2026-05-10-init-id-passthrough.md` | Create | This plan. |

No file deletions. No changes to `serve/common.py`, `serve/watcher.py`, `lib/ai_video.py`, or any CLI command — all already treat `project.json["id"]` as opaque.

---

## Plain-English Summary

**The problem.** Today, every Montaj project is born with a `uuid.uuid4()` ID generated inside `project/init.py`. Callers passing `projectPath` to `POST /api/run` get the workspace subdirectory they asked for, but `project.json["id"]` is whatever Montaj decides. Montaj's project lookup (`find_project_dir`) then matches by that id field. So a downstream system that already has its own ID for the project (e.g. Hub, which is the immediate driver) can't address it back — `GET /api/projects/<hub-id>` returns 404 because the id field inside `project.json` is a different UUID.

**What changes for callers.**
- `POST /api/run` accepts an optional `id` field in the request body. If present, Montaj uses it as `project.json["id"]`. If absent, Montaj generates one as today.
- `python -m project.init --id <uuid>` does the same on the CLI.
- All subsequent project-scoped endpoints (`GET /api/projects/<id>`, `PUT`, `/stream`, `/render`, etc.) work with the supplied id since they all delegate to `find_project_dir`, which already matches by the id field.

**What is explicitly NOT changing.**
- Existing callers that don't pass `id` see no behavior difference — the same `uuid.uuid4()` path runs.
- The on-disk project layout, file format, and version (`"version": "0.2"`) are identical.
- The HTTP contract is purely additive: a new optional field. No status codes change for existing flows.
- No id-collision check, no uniqueness enforcement. If two callers pass the same id (or one collides with a previously generated one), `find_project_dir` still picks the first match it walks — same as today. Callers (Hub) that own ID generation are responsible for uniqueness; deferring server-side dedup to a follow-up if real callers actually collide.
- The `projectPath` field is unchanged. `id` (project.json identity) and `projectPath` (workspace directory location) remain orthogonal — exactly the same as today, just with one of them now caller-pinnable.

**The trade.** Tiny added validation surface (one argparse arg, one body field, one helper). Net contract simplification for any consumer that already has a project ID — they can now use a single shared identifier across both systems instead of maintaining a translation table.

**Decisions made and why.**
- **Validate via `uuid.UUID(value)` and canonicalize on store.** `uuid.UUID()` accepts several equivalent forms — canonical 8-4-4-4-12, hex32 (no dashes), braced (`{...}`), `urn:uuid:...` prefix, mixed-case hex. Rather than reject all but canonical (which would force callers to pre-format), we accept any form `uuid.UUID()` parses and store `str(uuid.UUID(raw))` — always lowercase 8-4-4-4-12 with dashes. Rationale: (a) `find_project_dir` does a string `==` match, so two callers passing logically-equal-but-textually-different ids would diverge if we stored verbatim; canonicalize-on-store eliminates that trap. (b) Cheaper than the explicit-canonical check (one parse vs. parse + format-equality compare). (c) Truly malformed inputs (truncated, non-hex, empty, non-string) still raise `ValueError` and get rejected with `invalid_id`. Callers that hand back the canonicalized id from the response and use it on subsequent calls always succeed.
- **No collision detection in V1.** Scanning the workspace on every init is O(N projects) for a feature that's redundant when callers (Hub) already enforce uniqueness via their own DB. Add this back as a fast follow-up if any third-party caller actually collides.
- **Validate at HTTP boundary AND in the CLI.** The HTTP path validates first (fast 400, no subprocess fork on bad input), the CLI path validates again (defensive — direct CLI use bypasses HTTP validation). Same regex/parse logic shared via a tiny helper rather than duplicated.
- **`id` not `projectId` as the body field name.** Matches the field that already exists inside `project.json` (`"id"`). The `PUT /api/projects/{project_id}` endpoint already uses `body.get("id")` for its match check (line 508) — using the same key on POST avoids inventing a parallel name.
- **Failure behavior on malformed UUID is `400 invalid_id`, not `422`.** Consistent with Montaj's existing `invalid_field` / `invalid_project_path` errors which are all 400.

**Follow-up plans (NOT in scope).**
- ID-uniqueness enforcement at init time (would require either a workspace scan or a small `.montaj/index.json` manifest). Skipped until a real caller collides; Hub's DB uniqueness is sufficient for the V1 driver.
- Hub-side change to pass `id: project.id` in `ScratchService.ensureActive`. Tracked separately in the Hub repo; this Montaj plan only ships the receiving end.
- Public docs page in `landing-montaj` documenting the field. Skipped until the Hub integration ships and the field actually has external callers; CHANGELOG entry is sufficient internal record for V1.

---

## Tasks

### Task 1: CLI — add `--id` arg with validation

**Files:**
- Modify: `project/init.py` (around lines 152-206 for argparse, 124 + 535 for substitution)

**Step 1: Write the failing test**

Add to `tests/test_init.py` (alongside existing init-args tests). Pick a fixed UUID literal so the assertion is stable:

```python
CANONICAL_ID = "550e8400-e29b-41d4-a716-446655440000"


def test_init_with_explicit_id_uses_supplied_value(tmp_path, monkeypatch):
    """--id <canonical-uuid> overrides the server-generated UUID in project.json."""
    monkeypatch.setenv("MONTAJ_WORKSPACE_DIR", str(tmp_path))
    result = subprocess.run(
        [sys.executable, "-m", "project.init",
         "--prompt", "test",
         "--workflow", "carousel",
         "--carousel-aspect", "square",
         "--id", CANONICAL_ID,
         "--project-path", "explicit-id-test"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    project_json = json.loads((tmp_path / "explicit-id-test" / "project.json").read_text())
    assert project_json["id"] == CANONICAL_ID


@pytest.mark.parametrize("non_canonical", [
    "550E8400-E29B-41D4-A716-446655440000",                # uppercase hex
    "550e8400e29b41d4a716446655440000",                    # hex32, no dashes
    "{550e8400-e29b-41d4-a716-446655440000}",              # braced
    "urn:uuid:550e8400-e29b-41d4-a716-446655440000",       # urn prefix
])
def test_init_with_non_canonical_id_is_canonicalized(tmp_path, monkeypatch, non_canonical):
    """Non-canonical-but-parseable UUID forms are accepted and stored canonicalized.
    This is the contract that makes find_project_dir's string-equality match safe
    against logically-equal-but-textually-different ids."""
    monkeypatch.setenv("MONTAJ_WORKSPACE_DIR", str(tmp_path))
    # Use a unique project-path per parametrize case — same canonical id under
    # different surface forms would otherwise collide on directory creation.
    safe_subdir = f"non-canon-{abs(hash(non_canonical))}"
    result = subprocess.run(
        [sys.executable, "-m", "project.init",
         "--prompt", "test",
         "--workflow", "carousel",
         "--carousel-aspect", "square",
         "--id", non_canonical,
         "--project-path", safe_subdir],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    project_json = json.loads((tmp_path / safe_subdir / "project.json").read_text())
    assert project_json["id"] == CANONICAL_ID


def test_init_without_id_generates_uuid(tmp_path, monkeypatch):
    """Absence of --id preserves current behavior — generated UUID, valid format."""
    monkeypatch.setenv("MONTAJ_WORKSPACE_DIR", str(tmp_path))
    result = subprocess.run(
        [sys.executable, "-m", "project.init",
         "--prompt", "test",
         "--workflow", "carousel",
         "--carousel-aspect", "square",
         "--project-path", "no-id-test"],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, result.stderr
    project_json = json.loads((tmp_path / "no-id-test" / "project.json").read_text())
    # Round-trips through uuid.UUID — proves it's a valid canonical UUID string.
    assert str(uuid.UUID(project_json["id"])) == project_json["id"]


@pytest.mark.parametrize("bad_id", [
    "not-a-uuid",
    "550e8400-e29b-41d4-a716",                       # truncated
    "",                                              # empty
    "550e8400-e29b-41d4-a716-44665544000Z",          # invalid hex character
    "zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz",          # all non-hex
])
def test_init_with_invalid_id_rejected(tmp_path, monkeypatch, bad_id):
    """Truly malformed --id exits non-zero with invalid_id error, no project created."""
    monkeypatch.setenv("MONTAJ_WORKSPACE_DIR", str(tmp_path))
    result = subprocess.run(
        [sys.executable, "-m", "project.init",
         "--prompt", "test",
         "--workflow", "carousel",
         "--carousel-aspect", "square",
         "--id", bad_id,
         "--project-path", "bad-id-test"],
        capture_output=True, text=True,
    )
    assert result.returncode != 0
    err = json.loads(result.stderr)
    assert err["error"] == "invalid_id"
    # No project directory should have been created on validation failure.
    assert not (tmp_path / "bad-id-test").exists()
```

Add `import json, sys, uuid` and `import pytest` at the top of `test_init.py` if not already present.

**Step 2: Run test to verify it fails**

```bash
pytest tests/test_init.py -k "test_init_with_explicit_id or test_init_without_id or test_init_with_invalid_id" -v
```

Expected: all 7 cases FAIL — `--id` is an unrecognized argparse argument so subprocess returncode is 2 with "unrecognized arguments" on stderr.

**Step 3: Add the argparse arg**

In `project/init.py:main()`, after the `--carousel-aspect` line (~206), add:

```python
parser.add_argument("--id", dest="project_id", default=None,
                    help="Optional project id. If supplied, used as project.json['id'] verbatim. "
                         "Must be a canonical UUID string (8-4-4-4-12 hex). When absent, a fresh "
                         "UUID is generated server-side.")
```

**Step 4: Add the early-validation block (parse + canonicalize)**

In `project/init.py:main()`, near the other early arg validations (around line 213-214 where `--canvas` + `--clips` are checked), add:

```python
# Parse --id BEFORE any on-disk side effects and canonicalize. uuid.UUID()
# raises ValueError on truly malformed input (wrong length, non-hex, empty,
# non-string). It also accepts non-canonical forms (hex32, braced,
# urn:uuid:..., uppercase) — for those, str(uuid.UUID(raw)) returns the
# canonical lowercase 8-4-4-4-12 form, which is what we store. This makes
# find_project_dir's string-equality match safe against callers who pass
# logically-equal-but-textually-different ids.
if args.project_id is not None:
    try:
        args.project_id = str(uuid.UUID(args.project_id))
    except (ValueError, AttributeError):
        fail("invalid_id",
             f"--id must be a parseable UUID (got {args.project_id!r})")
```

**Step 5: Substitute in both project dicts**

In `_build_carousel_project` (line ~117-148), change line 124:

```python
        "id": args.project_id or str(uuid.uuid4()),
```

In the general project dict inlined in `main()` (line ~533-553), change line 535 the same way:

```python
        "id": args.project_id or str(uuid.uuid4()),
```

`args.project_id` here is already the canonicalized form set by Step 4, so both paths store canonical UUIDs whether caller-supplied or generated. `_build_carousel_project` already accepts `args` so no signature change is needed; the general path uses `args` directly.

**Step 6: Run tests to verify they pass**

```bash
pytest tests/test_init.py -k "test_init_with_explicit_id or test_init_without_id or test_init_with_invalid_id" -v
```

Expected: all 7 cases PASS.

**Step 7: Run the full init test suite to confirm no regressions**

```bash
pytest tests/test_init.py tests/test_init_project_path.py -v
```

Expected: all green, no existing tests broken.

**Step 8: Commit**

```bash
git add project/init.py tests/test_init.py
git commit -m "init: accept --id to pin project.json id (default: generated UUID)"
```

---

### Task 2: HTTP — accept `id` body field on `POST /api/run`

**Files:**
- Modify: `serve/routes/projects.py` (around lines 191-238 carousel branch, 370-409 general branch)
- Test: `tests/test_server_subnesting.py`

**Step 1: Write the failing tests**

Add to `tests/test_server_subnesting.py` (which already has `/api/run` integration coverage):

```python
CANONICAL_ID_HTTP = "550e8400-e29b-41d4-a716-446655440000"


def test_post_run_with_id_uses_supplied_value(workspace, client):
    """POST /api/run with body.id=<uuid> produces a project.json whose id matches."""
    resp = client.post("/api/run", json={
        "prompt": "test",
        "workflow": "carousel",
        "carouselAspect": "square",
        "id": CANONICAL_ID_HTTP,
        "projectPath": "explicit-id",
    })
    assert resp.status_code == 201, resp.text
    body = resp.json()
    assert body["id"] == CANONICAL_ID_HTTP
    # And the on-disk file matches.
    on_disk = json.loads((workspace / "explicit-id" / "project.json").read_text())
    assert on_disk["id"] == CANONICAL_ID_HTTP


def test_post_run_with_id_animations_workflow(workspace, client):
    """`animations` has requires_clips=false and exercises the general (non-
    carousel) init path without needing clips. Confirms id passthrough wiring
    in the general branch of run_project."""
    fixed_id = "abcdef00-0000-0000-0000-000000000001"
    resp = client.post("/api/run", json={
        "prompt": "test",
        "workflow": "animations",
        "id": fixed_id,
        "projectPath": "explicit-id-animations",
    })
    assert resp.status_code == 201, resp.text
    assert resp.json()["id"] == fixed_id


def test_post_run_canonicalizes_non_canonical_id(workspace, client):
    """Non-canonical-but-parseable forms (hex32, uppercase, braced, urn:uuid:)
    are accepted and stored canonical. Mirrors the CLI-side contract."""
    resp = client.post("/api/run", json={
        "prompt": "test",
        "workflow": "carousel",
        "carouselAspect": "square",
        "id": "550E8400E29B41D4A716446655440000",  # uppercase hex32
        "projectPath": "non-canon-http",
    })
    assert resp.status_code == 201, resp.text
    assert resp.json()["id"] == CANONICAL_ID_HTTP


@pytest.mark.parametrize("bad_id", [
    "not-a-uuid",
    "550e8400-e29b-41d4-a716",   # truncated
    "",                          # empty
    123,                         # non-string
])
def test_post_run_with_invalid_id_returns_400(client, bad_id):
    """Truly malformed body.id rejected with 400 invalid_id BEFORE init subprocess fires."""
    resp = client.post("/api/run", json={
        "prompt": "test",
        "workflow": "carousel",
        "carouselAspect": "square",
        "id": bad_id,
        "projectPath": "should-not-exist",
    })
    assert resp.status_code == 400
    assert resp.json()["detail"]["error"] == "invalid_id"


def test_post_run_without_id_preserves_current_behavior(workspace, client):
    """Absent body.id → server generates a UUID (existing behavior)."""
    resp = client.post("/api/run", json={
        "prompt": "test",
        "workflow": "carousel",
        "carouselAspect": "square",
        "projectPath": "no-id-supplied",
    })
    assert resp.status_code == 201, resp.text
    body = resp.json()
    # Server-generated, but well-formed UUID.
    assert str(uuid.UUID(body["id"])) == body["id"]
```

Add `import uuid` if not already imported in this test file.

**Step 2: Run tests to verify they fail**

```bash
pytest tests/test_server_subnesting.py -k "test_post_run_with_id or test_post_run_with_invalid_id or test_post_run_without_id_preserves" -v
```

Expected: 4 of 5 cases FAIL — `test_post_run_without_id_preserves_current_behavior` already passes (existing behavior); the new-feature cases fail because `id` is not yet read from the body or forwarded to init.py.

**Step 3: Add the shared validation helper**

At the top of `serve/routes/projects.py` (alongside other helpers like `_validate_remote_items`), add:

```python
def _validate_optional_id(body: dict) -> str | None:
    """Returns the id field from the body parsed and canonicalized via uuid.UUID,
    or None when absent. Raises bad_request('invalid_id', ...) on malformed input.

    Validation runs at the HTTP boundary so a bad id never reaches the init.py
    subprocess. The CLI-level uuid.UUID parse in init.py is the second line of
    defense for direct CLI use. Canonicalize-on-store: any form uuid.UUID()
    accepts (canonical, hex32, braced, urn:uuid:..., uppercase) is normalized
    to lowercase 8-4-4-4-12. Truly malformed input (truncated, non-hex, empty,
    non-string) is rejected.
    """
    raw = body.get("id")
    if raw is None:
        return None
    if not isinstance(raw, str):
        raise bad_request(
            "invalid_id",
            f"'id' must be a string (got {type(raw).__name__}: {raw!r})",
        )
    try:
        return str(uuid.UUID(raw))
    except ValueError:
        raise bad_request(
            "invalid_id",
            f"'id' must be a parseable UUID (got {raw!r})",
        )
```

Add `import uuid` at the top of the file if not already present — check existing imports first.

**Step 4: Parse the id once at the top of `run_project`, before the carousel branch**

In `run_project` (line ~191), the existing body reads run from line 193 to 201. Immediately after `remote_assets = body.get("remoteAssets", [])` (line 201) and BEFORE the carousel-branch decision `wf_data = read_workflow(workflow)` (line ~204), add:

```python
    project_id_arg = _validate_optional_id(body)
```

This makes the canonicalized id available to both branches without duplication. Validation fires before any subprocess fork, so a bad id 400s without side effects.

**Step 5: Pass `--id` through to init.py in both branches**

In the carousel `cmd` construction (after the `if project_path_arg:` line at ~228-229), add:

```python
        if project_id_arg:
            cmd += ["--id", project_id_arg]
```

In the general `cmd` construction (after the `if project_path_arg:` line at ~378-379), add the same:

```python
    if project_id_arg:
        cmd += ["--id", project_id_arg]
```

**Step 6: Run tests to verify they pass**

```bash
pytest tests/test_server_subnesting.py -k "test_post_run_with_id or test_post_run_with_invalid_id or test_post_run_without_id_preserves" -v
```

Expected: all 5 cases PASS, including the parametrized invalid-id cases.

**Step 7: Run the full server test suite to confirm no regressions**

```bash
pytest tests/test_server_subnesting.py tests/test_server_intake.py tests/test_server_workspace.py -v
```

Expected: all green. The existing `/api/run` tests continue to pass because `id` is optional and absent in those bodies.

**Step 8: Commit**

```bash
git add serve/routes/projects.py tests/test_server_subnesting.py
git commit -m "POST /api/run: accept optional id field, forward to init.py --id"
```

---

### Task 3: End-to-end smoke — confirm `GET /api/projects/<id>` resolves the supplied id

**Files:**
- Modify: `tests/test_server_subnesting.py` (add one round-trip test)

**Step 1: Write the failing test**

This is the test that proves the original problem (Hub-id ≠ Montaj-id) is solved. Add:

```python
def test_post_run_id_round_trips_through_get(workspace, client):
    """The supplied id must be addressable on subsequent GET /api/projects/<id>.
    This is the actual user-facing contract — single shared identity across
    POST + GET, where today the server generates an unrelated UUID and GET
    on the caller's id returns 404."""
    fixed_id = "deadbeef-0000-0000-0000-000000000001"
    resp = client.post("/api/run", json={
        "prompt": "test",
        "workflow": "carousel",
        "carouselAspect": "square",
        "id": fixed_id,
        "projectPath": "round-trip-test",
    })
    assert resp.status_code == 201, resp.text

    # The exact failure mode this plan solves: BEFORE this change, the server
    # would have generated its own UUID, and GET on the caller's id would 404.
    get_resp = client.get(f"/api/projects/{fixed_id}")
    assert get_resp.status_code == 200, get_resp.text
    assert get_resp.json()["id"] == fixed_id
```

**Step 2: Run test to verify it passes**

```bash
pytest tests/test_server_subnesting.py::test_post_run_id_round_trips_through_get -v
```

Expected: PASS (Tasks 1-2 already implement the underlying behavior; this test proves the cross-endpoint contract holds).

**Step 3: Commit**

```bash
git add tests/test_server_subnesting.py
git commit -m "test: round-trip POST /api/run id → GET /api/projects/{id}"
```

---

### Task 4: CHANGELOG

**Files:**
- Modify: `CHANGELOG.md`

**Step 1: Add the entry**

Open `CHANGELOG.md` and add a single bullet under the next-release section (or under an "Unreleased" header if that's the convention — check the file's existing shape first):

```markdown
- `POST /api/run` and `python -m project.init` now accept an optional caller-supplied project id (`id` body field / `--id` CLI flag). When provided, the value is used verbatim as `project.json["id"]`; when absent, the server generates a UUID as before. Enables consumers (e.g. Hub) to maintain a single shared identifier across both systems instead of mapping between Montaj's generated id and their own.
```

**Step 2: Verify rendering / no syntax oddities**

```bash
git diff CHANGELOG.md
```

Eyeball the surrounding lines — match list indentation and bullet style of existing entries.

**Step 3: Commit**

```bash
git add CHANGELOG.md
git commit -m "changelog: init id passthrough"
```

---

### Task 5: Final verification — full Montaj test suite

**Files:** none (verification only)

**Step 1: Run the full Python test suite**

```bash
pytest tests/ -v
```

Expected: all green. No new failures, no unrelated regressions.

**Step 2: Manual smoke (optional but valuable)**

If a real Montaj server is running locally:

```bash
# With supplied id:
curl -s -X POST http://localhost:3000/api/run \
  -H 'content-type: application/json' \
  -d '{"prompt":"smoke","workflow":"carousel","carouselAspect":"square","id":"deadbeef-0000-0000-0000-000000000002","projectPath":"manual-smoke"}' | jq .id

# Should print "deadbeef-0000-0000-0000-000000000002".

curl -s http://localhost:3000/api/projects/deadbeef-0000-0000-0000-000000000002 | jq .id

# Should also print "deadbeef-0000-0000-0000-000000000002" — proving the
# round-trip that was broken before this plan landed.
```

**Step 3: Done**

No commit needed for verification step.

---

## Done criteria

- [ ] `pytest tests/` is fully green.
- [ ] `POST /api/run` with `id` produces `project.json["id"]` matching the supplied value (carousel + non-carousel workflows).
- [ ] `POST /api/run` without `id` preserves current `uuid.uuid4()` behavior.
- [ ] `POST /api/run` with malformed `id` returns 400 `invalid_id` BEFORE the init subprocess fires.
- [ ] `python -m project.init --id <uuid>` works on the CLI for both carousel and non-carousel workflows.
- [ ] `python -m project.init --id <bad>` exits non-zero with `invalid_id` and creates no project directory.
- [ ] `GET /api/projects/<supplied-id>` returns the project (round-trip works).
- [ ] CHANGELOG entry added.
- [ ] No changes to `serve/common.py`, `serve/watcher.py`, `lib/ai_video.py`, or any CLI command — those treat `project.json["id"]` as opaque and need no edits.
