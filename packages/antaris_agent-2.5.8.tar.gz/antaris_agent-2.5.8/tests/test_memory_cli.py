"""
tests/test_memory_cli.py

Comprehensive tests for:
  - BotMemory.stats()            — correct structure & fields
  - BotMemory.search_memories()  — with mocked MemorySystem
  - BotMemory.export_memories()  — writes valid JSON
  - BotMemory.clear_memories()   — deletes files, returns count
  - UserTracker.extract_facts()  — name/job/location pattern detection
  - UserTracker.update_user_md() — creates file, appends section, deduplicates
  - UserTracker.process_message()— end-to-end convenience method
  - Pipeline integration          — UserTracker wired into ingest stage
  - Deduplication                 — facts already in USER.md are not duplicated
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from antaris_agent.core.memory import BotMemory
from antaris_agent.persona.user_tracker import UserTracker
from antaris_agent.channels.base import InboundMessage
from antaris_agent.llm.base import LLMResponse
from antaris_agent.core.pipeline import Pipeline, PipelineResult


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_search_result(content="test", relevance=0.8, source="conversation",
                        timestamp=None, score=0.8):
    r = MagicMock()
    r.content = content
    r.relevance = relevance
    r.score = score
    r.source = source
    r.timestamp = timestamp
    r.category = "chat"
    r.matched_terms = []
    r.explanation = ""
    return r


def make_inbound(text="Hello", user_id="user-test"):
    return InboundMessage(
        id="msg-1",
        user_id=user_id,
        user_name="TestUser",
        channel_id="ch-1",
        platform="terminal",
        text=text,
        timestamp_ms=0,
    )


def make_pipeline(user_tracker=None):
    """Build a Pipeline with mocked dependencies (no real I/O)."""
    config = MagicMock()
    config.model = "test-model"
    # Must be real ints so RateLimiter/session autosave comparisons work
    config.rate_limit_messages = 1000
    config.rate_limit_window_seconds = 60
    config.owner_user_id = ""
    config.session_save_interval = 999999
    config.cost_tracking_save_interval = 10

    memory = MagicMock()
    memory.recall = AsyncMock(return_value=[])
    memory.ingest = AsyncMock()

    guard = MagicMock()
    guard.check_input = AsyncMock(return_value=(True, ""))
    guard.check_output = AsyncMock(return_value=(True, "Bot response"))

    persona = MagicMock()
    persona.build_system_prompt = MagicMock(return_value="You are Antaris.")
    persona.update_user_context = MagicMock()
    persona.config_dir = ""   # empty → no UserTracker by default

    llm = MagicMock()
    llm.complete = AsyncMock(return_value=LLMResponse(
        content="Bot response",
        model="test-model",
        input_tokens=10,
        output_tokens=5,
        cost_usd=0.0001,
    ))

    adapter = MagicMock()
    adapter.format_for_surface = MagicMock(side_effect=lambda x: x)

    pipeline = Pipeline(config, memory, guard, persona, llm)
    if user_tracker is not None:
        pipeline.user_tracker = user_tracker
    return pipeline, adapter


# ─────────────────────────────────────────────────────────────────────────────
# 1. BotMemory.stats()
# ─────────────────────────────────────────────────────────────────────────────

class TestBotMemoryStats:

    def _make_mem(self, tmp_path, total=0):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        mock_store = MagicMock()
        mock_store.stats.return_value = {"total": total}
        mock_store.search.return_value = []
        mem._stores["user1"] = mock_store
        (tmp_path / "store" / "user1").mkdir(parents=True, exist_ok=True)
        return mem

    def test_stats_returns_dict(self, tmp_path):
        mem = self._make_mem(tmp_path)
        assert isinstance(mem.stats("user1"), dict)

    def test_stats_has_required_keys(self, tmp_path):
        result = self._make_mem(tmp_path).stats("user1")
        for key in ("user_id", "entry_count", "store_size_bytes",
                    "store_path", "oldest_entry", "newest_entry"):
            assert key in result, f"Missing key: {key}"

    def test_stats_user_id_matches(self, tmp_path):
        assert self._make_mem(tmp_path).stats("user1")["user_id"] == "user1"

    def test_stats_entry_count_from_memory_system(self, tmp_path):
        assert self._make_mem(tmp_path, total=42).stats("user1")["entry_count"] == 42

    def test_stats_store_size_bytes_is_int(self, tmp_path):
        result = self._make_mem(tmp_path).stats("user1")
        assert isinstance(result["store_size_bytes"], int)
        assert result["store_size_bytes"] >= 0

    def test_stats_oldest_newest_none_when_empty_dir(self, tmp_path):
        result = self._make_mem(tmp_path).stats("user1")
        assert result["oldest_entry"] is None
        assert result["newest_entry"] is None

    def test_stats_oldest_newest_iso_when_files_present(self, tmp_path):
        mem = self._make_mem(tmp_path)
        (tmp_path / "store" / "user1" / "mem.json").write_text("{}")
        result = mem.stats("user1")
        assert result["oldest_entry"] is not None
        assert result["newest_entry"] is not None
        from datetime import datetime
        datetime.fromisoformat(result["oldest_entry"].replace("Z", "+00:00"))

    def test_stats_aggregate_has_user_count(self, tmp_path):
        mem = self._make_mem(tmp_path)
        assert "user_count" in mem.stats()


# ─────────────────────────────────────────────────────────────────────────────
# 2. BotMemory.search_memories()
# ─────────────────────────────────────────────────────────────────────────────

class TestBotMemorySearchMemories:

    def _make_mem(self, tmp_path, results):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        mock_store = MagicMock()
        mock_store.search.return_value = results
        mock_store.stats.return_value = {"total": len(results)}
        mem._stores["user1"] = mock_store
        (tmp_path / "store" / "user1").mkdir(parents=True, exist_ok=True)
        return mem

    def test_returns_list(self, tmp_path):
        assert isinstance(self._make_mem(tmp_path, []).search_memories("user1", "q"), list)

    def test_returns_correct_count(self, tmp_path):
        fakes = [_make_search_result(f"m{i}") for i in range(3)]
        assert len(self._make_mem(tmp_path, fakes).search_memories("user1", "q")) == 3

    def test_result_has_required_keys(self, tmp_path):
        fake = _make_search_result("hello")
        results = self._make_mem(tmp_path, [fake]).search_memories("user1", "hello")
        for key in ("content", "score", "timestamp", "source"):
            assert key in results[0]

    def test_content_matches(self, tmp_path):
        fake = _make_search_result("unique xyz")
        results = self._make_mem(tmp_path, [fake]).search_memories("user1", "xyz")
        assert results[0]["content"] == "unique xyz"

    def test_respects_limit(self, tmp_path):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        mock_store = MagicMock()
        mock_store.search.return_value = []
        mem._stores["user1"] = mock_store
        (tmp_path / "store" / "user1").mkdir(parents=True, exist_ok=True)
        mem.search_memories("user1", "q", limit=7)
        mock_store.search.assert_called_once_with("q", limit=7)


# ─────────────────────────────────────────────────────────────────────────────
# 3. BotMemory.export_memories()
# ─────────────────────────────────────────────────────────────────────────────

class TestBotMemoryExportMemories:

    def _make_mem(self, tmp_path, results):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        mock_store = MagicMock()
        mock_store.search.return_value = results
        mock_store.stats.return_value = {"total": len(results)}
        mem._stores["user1"] = mock_store
        (tmp_path / "store" / "user1").mkdir(parents=True, exist_ok=True)
        return mem

    def test_creates_file(self, tmp_path):
        out = str(tmp_path / "export.json")
        self._make_mem(tmp_path, []).export_memories("user1", out)
        assert Path(out).exists()

    def test_writes_valid_json(self, tmp_path):
        out = str(tmp_path / "export.json")
        self._make_mem(tmp_path, [_make_search_result()]).export_memories("user1", out)
        with open(out) as f:
            data = json.load(f)
        assert isinstance(data, dict)

    def test_returns_entry_count(self, tmp_path):
        fakes = [_make_search_result(f"m{i}") for i in range(4)]
        out = str(tmp_path / "export.json")
        count = self._make_mem(tmp_path, fakes).export_memories("user1", out)
        assert count == 4

    def test_json_has_entries_key(self, tmp_path):
        out = str(tmp_path / "export.json")
        self._make_mem(tmp_path, []).export_memories("user1", out)
        with open(out) as f:
            assert "entries" in json.load(f)

    def test_json_has_user_id(self, tmp_path):
        out = str(tmp_path / "export.json")
        self._make_mem(tmp_path, []).export_memories("user1", out)
        with open(out) as f:
            assert json.load(f)["user_id"] == "user1"

    def test_zero_count_for_empty_store(self, tmp_path):
        out = str(tmp_path / "export.json")
        count = self._make_mem(tmp_path, []).export_memories("user1", out)
        assert count == 0


# ─────────────────────────────────────────────────────────────────────────────
# 4. BotMemory.clear_memories()
# ─────────────────────────────────────────────────────────────────────────────

class TestBotMemoryClearMemories:

    def test_returns_zero_for_nonexistent_user(self, tmp_path):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        assert mem.clear_memories("ghost") == 0

    def test_deletes_files_returns_count(self, tmp_path):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        d = tmp_path / "store" / "user1"
        d.mkdir(parents=True)
        for i in range(3):
            (d / f"m{i}.json").write_text("{}")
        assert mem.clear_memories("user1") == 3

    def test_files_gone_after_clear(self, tmp_path):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        d = tmp_path / "store" / "user1"
        d.mkdir(parents=True)
        (d / "data.json").write_text("{}")
        mem.clear_memories("user1")
        assert [f for f in d.rglob("*") if f.is_file()] == []

    def test_user_directory_survives(self, tmp_path):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        d = tmp_path / "store" / "user1"
        d.mkdir(parents=True)
        (d / "x.json").write_text("{}")
        mem.clear_memories("user1")
        assert d.exists()

    def test_evicts_cached_store(self, tmp_path):
        mem = BotMemory(store_path=str(tmp_path / "store"))
        mock_store = MagicMock()
        mock_store.stats.return_value = {"total": 0}
        mem._stores["user1"] = mock_store
        (tmp_path / "store" / "user1").mkdir(parents=True)
        mem.clear_memories("user1")
        assert "user1" not in mem._stores


# ─────────────────────────────────────────────────────────────────────────────
# 5. UserTracker.extract_facts()
# ─────────────────────────────────────────────────────────────────────────────

class TestUserTrackerExtractFacts:

    def setup_method(self):
        self.t = UserTracker("/tmp/__nodir__")

    def test_returns_list(self):
        assert isinstance(self.t.extract_facts("Hello"), list)

    def test_name_pattern(self):
        facts = self.t.extract_facts("My name is Alice")
        assert any("Alice" in f for f in facts)

    def test_call_me_pattern(self):
        facts = self.t.extract_facts("Call me Bob")
        assert any("Bob" in f for f in facts)

    def test_work_at_pattern(self):
        facts = self.t.extract_facts("I work at Google")
        assert any("Google" in f for f in facts)

    def test_work_for_pattern(self):
        facts = self.t.extract_facts("I work for Acme Corp")
        assert any("Acme" in f for f in facts)

    def test_live_in_pattern(self):
        facts = self.t.extract_facts("I live in Seattle")
        assert any("Seattle" in f for f in facts)

    def test_am_a_role_pattern(self):
        assert len(self.t.extract_facts("I am a software developer")) >= 1

    def test_likes_pattern(self):
        facts = self.t.extract_facts("I like coffee")
        assert any("coffee" in f.lower() for f in facts)

    def test_loves_pattern(self):
        assert len(self.t.extract_facts("I love hiking")) >= 1

    def test_uses_pattern(self):
        assert len(self.t.extract_facts("I use Python 3")) >= 1

    def test_prefers_pattern(self):
        assert len(self.t.extract_facts("I prefer dark mode")) >= 1

    def test_my_property_pattern(self):
        assert len(self.t.extract_facts("My favorite color is blue")) >= 1

    def test_neutral_message_returns_list(self):
        result = self.t.extract_facts("What time is it?")
        assert isinstance(result, list)


# ─────────────────────────────────────────────────────────────────────────────
# 6. UserTracker.update_user_md()
# ─────────────────────────────────────────────────────────────────────────────

class TestUserTrackerUpdateUserMd:

    def test_creates_file(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.update_user_md(["Name: TestUser"])
        assert t.user_md_path.exists()

    def test_returns_true_on_update(self, tmp_path):
        assert UserTracker(str(tmp_path)).update_user_md(["Name: Alice"]) is True

    def test_returns_false_for_empty(self, tmp_path):
        assert UserTracker(str(tmp_path)).update_user_md([]) is False

    def test_creates_learned_facts_section(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.update_user_md(["Name: Bob"])
        assert "## Learned Facts" in t.user_md_path.read_text()

    def test_fact_as_bullet_point(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.update_user_md(["Name: Carol"])
        assert "- Name: Carol" in t.user_md_path.read_text()

    def test_no_duplicate_facts(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.update_user_md(["Name: Dave"])
        t.update_user_md(["Name: Dave"])
        assert t.user_md_path.read_text().count("Name: Dave") == 1

    def test_multiple_facts_appended(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.update_user_md(["Name: Eve"])
        t.update_user_md(["Lives in: Paris"])
        content = t.user_md_path.read_text()
        assert "Name: Eve" in content
        assert "Lives in: Paris" in content

    def test_returns_false_all_duplicate(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.update_user_md(["Name: Frank"])
        assert t.update_user_md(["Name: Frank"]) is False


# ─────────────────────────────────────────────────────────────────────────────
# 7. UserTracker.process_message()
# ─────────────────────────────────────────────────────────────────────────────

class TestUserTrackerProcessMessage:

    def test_returns_list(self, tmp_path):
        assert isinstance(UserTracker(str(tmp_path)).process_message("Hello!"), list)

    def test_writes_to_file(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.process_message("My name is Grace")
        if t.user_md_path.exists():
            assert "Grace" in t.user_md_path.read_text()

    def test_duplicate_returns_empty(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.process_message("My name is Henry")
        assert t.process_message("My name is Henry") == []

    def test_end_to_end_live_in(self, tmp_path):
        t = UserTracker(str(tmp_path))
        t.process_message("I live in Tokyo")
        if t.user_md_path.exists():
            assert "Tokyo" in t.user_md_path.read_text()


# ─────────────────────────────────────────────────────────────────────────────
# 8. Pipeline integration
# ─────────────────────────────────────────────────────────────────────────────

class TestPipelineUserTrackerIntegration:

    @pytest.mark.asyncio
    async def test_pipeline_calls_process_message(self):
        mock_tracker = MagicMock()
        mock_tracker.process_message.return_value = []
        pipeline, adapter = make_pipeline(user_tracker=mock_tracker)

        await pipeline.process(make_inbound("My name is Iris"), adapter)
        mock_tracker.process_message.assert_called_once()
        call_args = mock_tracker.process_message.call_args
        # The tracker is invoked with processed message text plus the raw user_id.
        assert call_args[0][0] is not None
        assert call_args[1].get("user_id") == "user-test"  # keyword: user_id from make_inbound

    @pytest.mark.asyncio
    async def test_metadata_contains_learned_facts(self):
        mock_tracker = MagicMock()
        mock_tracker.process_message.return_value = ["Name: Jack"]
        pipeline, adapter = make_pipeline(user_tracker=mock_tracker)

        result = await pipeline.process(make_inbound("My name is Jack"), adapter)
        assert result.success is True
        assert "Name: Jack" in result.metadata.get("learned_facts", [])

    @pytest.mark.asyncio
    async def test_metadata_empty_when_no_facts(self):
        mock_tracker = MagicMock()
        mock_tracker.process_message.return_value = []
        pipeline, adapter = make_pipeline(user_tracker=mock_tracker)

        result = await pipeline.process(make_inbound("What is 2+2?"), adapter)
        assert result.success is True
        assert not result.metadata.get("learned_facts")

    @pytest.mark.asyncio
    async def test_pipeline_result_has_metadata_field(self):
        pr = PipelineResult(success=True, response_text="hi")
        assert hasattr(pr, "metadata")
        assert isinstance(pr.metadata, dict)

    @pytest.mark.asyncio
    async def test_tracker_failure_does_not_crash_pipeline(self):
        mock_tracker = MagicMock()
        mock_tracker.process_message.side_effect = RuntimeError("boom")
        pipeline, adapter = make_pipeline(user_tracker=mock_tracker)

        result = await pipeline.process(make_inbound("I work at ACME"), adapter)
        assert result.success is True
