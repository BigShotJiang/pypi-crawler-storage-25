"""Tests for tool system wiring in bot.py."""

import tempfile
import json
from pathlib import Path
from contextlib import contextmanager
from unittest.mock import patch, MagicMock

import pytest

from antaris_agent.core.bot import Bot
from antaris_agent.core.config import Config


@contextmanager
def patched_bot_init():
    with patch('antaris_agent.core.bot.setup_logging'), \
         patch.object(Config, 'memory_storage_backend', 'filesystem', create=True), \
         patch.object(Config, 'memory_session_awareness', True, create=True), \
         patch.object(Config, 'memory_tiered_storage', False, create=True):
        yield


@pytest.fixture
def temp_config_dir():
    """Create a temporary config directory with minimal config."""
    with tempfile.TemporaryDirectory() as temp_dir:
        config_dir = Path(temp_dir)
        config_path = config_dir / "config.json"
        
        # Minimal config for testing
        config_data = {
            "bot": {"name": "TestBot"},
            "provider": {"name": "anthropic", "apiKey": "test-key", "model": "claude-sonnet-4-6"},
            "channels": {"discord": {"enabled": False}},
            "memory": {"store": str(config_dir / "memory")},
            "guard": {"mode": "monitor"},
            "security": {"mode": "sandboxed"},
            "tools": {}
        }
        
        with open(config_path, 'w') as f:
            json.dump(config_data, f)
        
        yield config_dir, config_path


def test_tools_config_loading(temp_config_dir):
    """Test that tools config is loaded from config.json."""
    config_dir, config_path = temp_config_dir
    
    # Add tools config
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "web_fetch": {"enabled": True},
        "brave_search": {"enabled": True, "apiKey": "test-brave-key"},
        "browser": {"enabled": False}
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    # Load config
    config = Config.load(str(config_path))
    assert config is not None
    assert hasattr(config, '_tools_config')
    assert config._tools_config["web_fetch"]["enabled"] is True
    assert config._tools_config["brave_search"]["apiKey"] == "test-brave-key"


def test_tools_initialization_no_tools(temp_config_dir):
    """Test tool registry initialization when no tools are configured."""
    config_dir, config_path = temp_config_dir
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        # Should return None when no tools are configured
        assert bot.tool_registry is None


def test_tools_initialization_with_web_fetch(temp_config_dir):
    """Test tool registry initialization with web_fetch enabled."""
    config_dir, config_path = temp_config_dir
    
    # Add web_fetch tool config
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "web_fetch": {"enabled": True}
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        assert bot.tool_registry is not None
        assert 'web_fetch' in bot.tool_registry.list_tools()


def test_tools_initialization_with_brave_search(temp_config_dir):
    """Test tool registry initialization with brave_search configured."""
    config_dir, config_path = temp_config_dir
    
    # Add brave_search tool config
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "brave_search": {"enabled": True, "apiKey": "test-key"}
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        assert bot.tool_registry is not None
        assert 'web_search' in bot.tool_registry.list_tools()


def test_tools_initialization_multiple_tools(temp_config_dir):
    """Test tool registry initialization with multiple tools."""
    config_dir, config_path = temp_config_dir
    
    # Add multiple tools config
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "web_fetch": {"enabled": True},
        "brave_search": {"enabled": True, "apiKey": "test-key"},
        "file_ops": {"enabled": True},
        "shell": {"enabled": True},
        "video": {"enabled": True}
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        assert bot.tool_registry is not None
        
        tools = bot.tool_registry.list_tools()
        expected_tools = ['web_fetch', 'web_search', 'file_ops', 'shell', 'video']
        
        for expected_tool in expected_tools:
            assert expected_tool in tools


def test_tool_registry_passed_to_pipeline(temp_config_dir):
    """Test that tool registry is passed to the pipeline."""
    config_dir, config_path = temp_config_dir
    
    # Add tools config
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "web_fetch": {"enabled": True}
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        
        assert bot.tool_registry is not None
        assert bot.pipeline.tool_registry is bot.tool_registry


def test_brave_search_without_api_key(temp_config_dir):
    """Test that brave_search is not registered without an API key."""
    config_dir, config_path = temp_config_dir
    
    # Add brave_search tool config without API key
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "brave_search": {"enabled": True}  # no apiKey
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        
        # Should not register brave_search without API key
        if bot.tool_registry:
            assert 'web_search' not in bot.tool_registry.list_tools()


def test_video_tool_registered(temp_config_dir):
    """Test that video tool is registered when enabled."""
    config_dir, config_path = temp_config_dir

    with open(config_path, 'r') as f:
        config_data = json.load(f)

    config_data["tools"] = {
        "video": {"enabled": True}
    }

    with open(config_path, 'w') as f:
        json.dump(config_data, f)

    with patched_bot_init():
        bot = Bot(str(config_path))
        assert bot.tool_registry is not None
        assert 'video' in bot.tool_registry.list_tools()


def test_disabled_tools_not_registered(temp_config_dir):
    """Test that disabled tools are not registered."""
    config_dir, config_path = temp_config_dir
    
    # Add tools config with some disabled
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "web_fetch": {"enabled": True},
        "browser": {"enabled": False},
        "file_ops": {"enabled": False}
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        
        assert bot.tool_registry is not None
        tools = bot.tool_registry.list_tools()
        
        # Only web_fetch should be registered
        assert 'web_fetch' in tools
        assert 'browser' not in tools
        assert 'file_ops' not in tools


@pytest.mark.asyncio
async def test_mcp_servers_initialization(temp_config_dir):
    """Test that MCP servers are initialized in async context."""
    config_dir, config_path = temp_config_dir
    
    # Add MCP server config
    with open(config_path, 'r') as f:
        config_data = json.load(f)
    
    config_data["tools"] = {
        "mcp_servers": [
            {
                "name": "test-server",
                "transport": "stdio",
                "command": ["echo", "test"]
            }
        ]
    }
    
    with open(config_path, 'w') as f:
        json.dump(config_data, f)
    
    with patched_bot_init():
        bot = Bot(str(config_path))
        
        # Mock the MCP client connection
        with patch.object(bot.tool_registry, 'add_mcp_server') as mock_add_mcp:
            await bot._init_mcp_servers()
            mock_add_mcp.assert_called_once_with(
                name="test-server",
                transport="stdio",
                command=["echo", "test"],
                env=None,
                url=None
            )


def test_js_bridges_detection(temp_config_dir):
    """Test that JS bridges are detected if js_bridges.json exists."""
    config_dir, config_path = temp_config_dir
    
    # Create js_bridges.json
    tools_dir = config_dir / "tools"
    tools_dir.mkdir(exist_ok=True)
    js_bridges_path = tools_dir / "js_bridges.json"
    
    bridges_data = {
        "bridges": [
            {
                "name": "test-bridge",
                "script_path": "/path/to/bridge.js"
            }
        ]
    }
    
    with open(js_bridges_path, 'w') as f:
        json.dump(bridges_data, f)
    
    with patched_bot_init(), \
         patch('antaris_agent.core.bot.logger') as mock_logger:
        bot = Bot(str(config_path))
        
        # Should log the JS bridge detection
        mock_logger.info.assert_any_call(
            "JS bridge detected: %s at %s", 
            "test-bridge", 
            "/path/to/bridge.js"
        )