"""Tests for the subagent system."""
import asyncio
import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from antaris_agent.core.subagents import (
    SubagentRegistry,
    SubagentStatus,
    _auto_name,
)


# ---------------------------------------------------------------------------
# Auto-name tests
# ---------------------------------------------------------------------------

def test_auto_name_first():
    assert _auto_name(set()) == "a"


def test_auto_name_sequential():
    existing = {"a", "b", "c"}
    assert _auto_name(existing) == "d"


def test_auto_name_full_alpha():
    existing = set("abcdefghijklmnopqrstuvwxyz")
    assert _auto_name(existing) == "a1"


def test_auto_name_overflow():
    existing = set("abcdefghijklmnopqrstuvwxyz") | {f"a1", "b1"}
    assert _auto_name(existing) == "c1"


# ---------------------------------------------------------------------------
# Registry tests
# ---------------------------------------------------------------------------

def make_bot(max_agents=4):
    bot = MagicMock()
    bot.memory = None  # disable memory for tests
    bot._active_discord_channel = None
    # Mock dispatcher
    resp = MagicMock()
    resp.text = "Task complete."
    resp.usage = {"total_tokens": 100}
    bot.dispatcher.complete = AsyncMock(return_value=resp)
    return bot


@pytest.mark.asyncio
async def test_spawn_single():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)
    ok, msg = await registry.spawn(task="Research antaris competitors")
    assert ok
    assert "a" in msg
    assert registry.active_count == 1


@pytest.mark.asyncio
async def test_spawn_named():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)
    ok, msg = await registry.spawn(task="Write a summary", name="scout")
    assert ok
    assert "scout" in msg


@pytest.mark.asyncio
async def test_spawn_respects_max():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=2)

    # Patch _run to hang so agents stay RUNNING
    async def hang(agent, on_done):
        await asyncio.sleep(999)

    with patch.object(registry, "_run", hang):
        ok1, _ = await registry.spawn(task="task 1")
        ok2, _ = await registry.spawn(task="task 2")
        ok3, msg3 = await registry.spawn(task="task 3")

    assert ok1 and ok2
    assert not ok3
    assert "Max concurrent" in msg3


@pytest.mark.asyncio
async def test_spawn_auto_names_sequential():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    async def hang(agent, on_done):
        await asyncio.sleep(999)

    with patch.object(registry, "_run", hang):
        await registry.spawn(task="task 1")
        await registry.spawn(task="task 2")
        await registry.spawn(task="task 3")

    names = list(registry._agents.keys())
    assert names == ["a", "b", "c"]


@pytest.mark.asyncio
async def test_spawn_many():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    async def hang(agent, on_done):
        await asyncio.sleep(999)

    with patch.object(registry, "_run", hang):
        results = await registry.spawn_many(["task1", "task2", "task3"])

    assert len(results) == 3
    assert all(ok for ok, _ in results)


@pytest.mark.asyncio
async def test_kill_running():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    async def hang(agent, on_done):
        try:
            await asyncio.sleep(999)
        except asyncio.CancelledError:
            agent.status = SubagentStatus.KILLED

    with patch.object(registry, "_run", hang):
        await registry.spawn(task="task", name="target")

    ok, msg = await registry.kill("target")
    assert ok
    assert "target" in msg


@pytest.mark.asyncio
async def test_kill_nonexistent():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)
    ok, msg = await registry.kill("ghost")
    assert not ok


@pytest.mark.asyncio
async def test_result_text_none_before_done():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    async def hang(agent, on_done):
        await asyncio.sleep(999)

    with patch.object(registry, "_run", hang):
        await registry.spawn(task="task", name="pending")

    assert registry.result_text("pending") is None
    assert registry.result_text("nonexistent") is None


@pytest.mark.asyncio
async def test_run_completes_and_sets_result():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    ok, _ = await registry.spawn(task="Do something", name="worker")
    assert ok

    # Wait for the task to finish
    agent = registry.get("worker")
    if agent and agent.task_handle:
        try:
            await asyncio.wait_for(agent.task_handle, timeout=5.0)
        except (asyncio.TimeoutError, Exception):
            pass

    agent = registry.get("worker")
    assert agent is not None
    assert agent.status in (SubagentStatus.DONE, SubagentStatus.FAILED)


@pytest.mark.asyncio
async def test_status_board_empty():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)
    board = registry.status_board()
    assert "No subagents" in board


@pytest.mark.asyncio
async def test_status_board_with_agents():
    bot = make_bot()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    async def hang(agent, on_done):
        await asyncio.sleep(999)

    with patch.object(registry, "_run", hang):
        await registry.spawn(task="Research task", name="scout")

    board = registry.status_board()
    assert "scout" in board
    assert "running" in board.lower() or "⏳" in board


# ---------------------------------------------------------------------------
# Config integration test
# ---------------------------------------------------------------------------

def test_config_max_subagents_default():
    from antaris_agent.core.config import Config
    cfg = Config()
    assert cfg.max_subagents == 4


def test_config_max_subagents_load():
    from antaris_agent.core.config import Config
    import json, tempfile, os
    data = {"bot": {"maxSubagents": 8}}
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(data, f)
        path = f.name
    try:
        cfg = Config.load(path)
        assert cfg is not None
        assert cfg.max_subagents == 8
    finally:
        os.unlink(path)



def make_bot_with_memory():
    bot = make_bot()
    mem = MagicMock()
    mem.recall = AsyncMock(return_value=["prior scoped memory"])
    mem.add_task = AsyncMock(return_value="")
    mem.complete_task = AsyncMock(return_value=None)
    mem.ingest = AsyncMock(return_value=None)
    mem._get_store = MagicMock(side_effect=AssertionError("direct store access should not be used"))
    bot.memory = mem
    return bot, mem


@pytest.mark.asyncio
async def test_subagent_scopes_memory_ops_to_parent_user_id():
    bot, mem = make_bot_with_memory()
    registry = SubagentRegistry(bot=bot, max_agents=4)

    ok, _ = await registry.spawn(task="Investigate scoped task", name="scoped", parent_user_id="user-123")
    assert ok

    agent = registry.get("scoped")
    assert agent is not None and agent.task_handle is not None
    await asyncio.wait_for(agent.task_handle, timeout=5.0)

    mem.recall.assert_awaited_once_with(user_id="user-123", query="Investigate scoped task", session_id="")
    mem.add_task.assert_awaited_once_with("user-123", "subagent-scoped", "subagent:scoped")
    mem.complete_task.assert_awaited_once_with("user-123", "subagent-scoped", "subagent:scoped")
    assert mem._get_store.call_count == 0

    mem.ingest.assert_awaited_once()
    ingest_kwargs = mem.ingest.await_args.kwargs
    assert ingest_kwargs["user_id"] == "user-123"
    assert ingest_kwargs["session_id"] == "subagent-scoped"
