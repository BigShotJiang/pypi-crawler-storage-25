"""
HTTP/API Tool — General-purpose HTTP requests.

Makes structured HTTP requests with proper JSON handling,
headers, auth, and response parsing. Replaces the need
for shell + curl for API work.

Operations:
  get      — HTTP GET
  post     — HTTP POST (JSON body)
  put      — HTTP PUT (JSON body)
  patch    — HTTP PATCH (JSON body)
  delete   — HTTP DELETE
  head     — HTTP HEAD (headers only)

Drop into: antaris_agent/tools/native/http_tool.py
"""

from __future__ import annotations

import json
import logging
from typing import Any, Dict, Optional

import httpx

from .base import NativeTool, ToolResult

logger = logging.getLogger(__name__)

# Block requests to private/local networks by default
_BLOCKED_HOSTS = {
    "localhost", "127.0.0.1", "0.0.0.0", "::1",
    "metadata.google.internal",  # GCP metadata
    "169.254.169.254",           # AWS/GCP/Azure metadata
}


class HTTPTool(NativeTool):
    """General-purpose HTTP request tool."""

    def __init__(self, timeout: float = 30.0, max_response_bytes: int = 500_000,
                 allow_local: bool = False):
        self._timeout = timeout
        self._max_response = max_response_bytes
        self._allow_local = allow_local

    @property
    def name(self) -> str:
        return "http"

    @property
    def description(self) -> str:
        return (
            "Make HTTP requests to APIs. Supports GET, POST, PUT, PATCH, DELETE, HEAD. "
            "Handles JSON bodies, custom headers, and auth headers. "
            "Use this instead of shell+curl for structured API work."
        )

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "method": {
                    "type": "string",
                    "description": "HTTP method",
                    "enum": ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"],
                },
                "url": {
                    "type": "string",
                    "description": "Request URL (must include https:// or http://)",
                },
                "headers": {
                    "type": "object",
                    "description": "Request headers as key-value pairs",
                },
                "body": {
                    "type": "object",
                    "description": "JSON request body (for POST/PUT/PATCH)",
                },
                "body_raw": {
                    "type": "string",
                    "description": "Raw string body (alternative to JSON body)",
                },
                "auth_bearer": {
                    "type": "string",
                    "description": "Bearer token (adds Authorization: Bearer <token> header)",
                },
                "auth_api_key": {
                    "type": "string",
                    "description": "API key value (pair with auth_api_key_header)",
                },
                "auth_api_key_header": {
                    "type": "string",
                    "description": "Header name for API key (default: X-API-Key)",
                    "default": "X-API-Key",
                },
                "timeout": {
                    "type": "number",
                    "description": "Request timeout in seconds (default: 30)",
                },
                "follow_redirects": {
                    "type": "boolean",
                    "description": "Follow HTTP redirects (default: true)",
                    "default": True,
                },
            },
            "required": ["method", "url"],
        }

    def _check_url(self, url: str) -> Optional[str]:
        """Validate URL. Returns error message or None if OK."""
        if not url:
            return "URL is required"
        if not url.startswith(("http://", "https://")):
            return "URL must start with http:// or https://"

        if not self._allow_local:
            try:
                from urllib.parse import urlparse
                parsed = urlparse(url)
                hostname = (parsed.hostname or "").lower()
                if hostname in _BLOCKED_HOSTS:
                    return f"Requests to {hostname} are blocked (local/metadata endpoint)"
                # Block private IP ranges
                if hostname.startswith(("10.", "192.168.", "172.")):
                    return f"Requests to private IP {hostname} are blocked"
            except Exception:
                pass

        return None

    async def execute(self, arguments: Dict[str, Any]) -> ToolResult:
        method = arguments.get("method", "GET").upper()
        url = arguments.get("url", "")

        # Validate URL
        url_error = self._check_url(url)
        if url_error:
            return ToolResult(
                success=False, content="",
                error=url_error, is_error=True,
            )

        # Build headers
        headers = dict(arguments.get("headers", {}) or {})
        if arguments.get("auth_bearer"):
            headers["Authorization"] = f"Bearer {arguments['auth_bearer']}"
        if arguments.get("auth_api_key"):
            key_header = arguments.get("auth_api_key_header", "X-API-Key")
            headers[key_header] = arguments["auth_api_key"]

        # Build body
        body_json = arguments.get("body")
        body_raw = arguments.get("body_raw")
        content = None
        json_body = None

        if body_json is not None:
            json_body = body_json
            if "Content-Type" not in headers:
                headers["Content-Type"] = "application/json"
        elif body_raw is not None:
            content = body_raw

        timeout = min(arguments.get("timeout", self._timeout), 120)
        follow = arguments.get("follow_redirects", True)

        try:
            async with httpx.AsyncClient(
                timeout=timeout,
                follow_redirects=follow,
                max_redirects=5,
            ) as client:
                response = await client.request(
                    method=method,
                    url=url,
                    headers=headers,
                    json=json_body,
                    content=content,
                )

            # Build result
            status = response.status_code
            resp_headers = dict(response.headers)

            # HEAD requests: return headers only
            if method == "HEAD":
                header_lines = [f"{k}: {v}" for k, v in resp_headers.items()]
                return ToolResult(
                    success=True,
                    content=(
                        f"HTTP {status}\n"
                        + "\n".join(header_lines)
                    ),
                )

            # Read body
            resp_text = response.text
            if len(resp_text) > self._max_response:
                resp_text = resp_text[:self._max_response] + "\n\n[Truncated at 500KB]"

            # Try to pretty-print JSON
            content_type = resp_headers.get("content-type", "")
            if "json" in content_type:
                try:
                    parsed = response.json()
                    resp_text = json.dumps(parsed, indent=2, ensure_ascii=False)
                    if len(resp_text) > self._max_response:
                        resp_text = resp_text[:self._max_response] + "\n\n[Truncated]"
                except Exception:
                    pass  # fall back to raw text

            result_content = f"HTTP {status}\n\n{resp_text}"

            return ToolResult(
                success=(200 <= status < 400),
                content=result_content,
                error=f"HTTP {status}" if status >= 400 else None,
                is_error=(status >= 400),
            )

        except httpx.TimeoutException:
            return ToolResult(
                success=False, content="",
                error=f"Request timed out after {timeout}s",
                is_error=True,
            )
        except httpx.ConnectError as e:
            return ToolResult(
                success=False, content="",
                error=f"Connection failed: {e}",
                is_error=True,
            )
        except Exception as e:
            logger.exception("HTTP tool error")
            return ToolResult(
                success=False, content="",
                error=f"HTTP request failed: {e}",
                is_error=True,
            )
