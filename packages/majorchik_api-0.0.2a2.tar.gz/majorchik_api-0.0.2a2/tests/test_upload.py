import os
import sys

# Подтягиваем локальный пакет перед тестом
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from browser_ai import get_ai_client, AuthRequiredError, SUPPORTED_MODELS

def create_dummy_file():
    filename = "test_dummy_file.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write("Привет! Это тестовый файл. Если ты можешь это прочитать, значит прикрепление файлов работает успешно!")
    return filename

def main():
    print("Создаем тестовый файл...")
    dummy_file = create_dummy_file()
    
    print("1. Тест Google AI Studio")
    print("2. Тест DeepSeek")
    choice = input("Какую модель тестируем? (1/2): ").strip()
    
    profile_dir = input("Введите абсолютный или относительный путь до папки профиля (например ./my_profiles/google_ai_studio_default): ").strip()

    ai = None
    try:
        if choice == "1":
            print("Запускаем Google AI Studio (без headless, чтобы видеть процесс)...")
            ai = get_ai_client("google_ai_studio", profile_dir=profile_dir, headless=False)
        elif choice == "2":
            print("Запускаем DeepSeek (без headless, чтобы видеть процесс)...")
            ai = get_ai_client("deepseek", profile_dir=profile_dir, headless=False)
        else:
            print("Неверный выбор")
            return

        print("Отправляем файл и промпт...")
        abs_path = os.path.abspath(dummy_file)
        response = ai.ask("Прочитай прикрепленный файл и скажи, что в нем написано.", files=[abs_path])
        
        print("\n[Ответ модели]:")
        print(response)
        
    except AuthRequiredError as e:
        print(f"\n[ОШИБКА АВТОРИЗАЦИИ] {e}")
    except Exception as e:
        print(f"\nПроизошла ошибка: {e}")
    finally:
        if ai:
            ai.close()
        if os.path.exists(dummy_file):
            os.remove(dummy_file)
            print("\nТестовый файл удален.")

if __name__ == '__main__':
    main()
