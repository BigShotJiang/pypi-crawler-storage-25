import os
import sys

# Подтягиваем локальный пакет перед тестом
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from browser_ai import get_ai_client, SUPPORTED_MODELS

def main():
    print("=== Тест создания/пересоздания профиля ===")
    
    models_list = list(SUPPORTED_MODELS.keys())
    print("Доступные модели:")
    for i, model in enumerate(models_list, 1):
        print(f"{i}. {model}")
        
    choice = input(f"Выберите модель (1-{len(models_list)}): ").strip()
    
    try:
        choice_idx = int(choice) - 1
        if choice_idx < 0 or choice_idx >= len(models_list):
            print("Неверный выбор.")
            return
        selected_model = models_list[choice_idx]
    except ValueError:
        print("Неверный ввод.")
        return

    default_profile_name = f"{selected_model}_test_profile"
    profile_name = input(f"Введите название папки профиля (нажмите Enter для '{default_profile_name}'): ").strip()
    
    if not profile_name:
        profile_name = default_profile_name
        
    # Сохраняем профиль в папку profiles в корне проекта
    base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'profiles'))
    profile_dir = os.path.join(base_dir, profile_name)
    
    print(f"\nЗапускаем настройку профиля для {selected_model.upper()}...")
    print(f"Директория профиля: {profile_dir}")
    print("Откроется браузер. Пожалуйста, пройдите авторизацию и все проверки (например, Cloudflare).")
    
    ai = None
    try:
        ai = get_ai_client(selected_model, profile_dir=profile_dir, headless=False, setup_mode=True)
        input("\nНажмите Enter в этой консоли, когда интерфейс чата полностью загрузится, чтобы сохранить профиль и выйти...")
        print(f"Профиль '{profile_name}' успешно сохранен или обновлен.")
    except Exception as e:
        print(f"\nПроизошла ошибка при настройке: {e}")
    finally:
        if ai:
            ai.close()

if __name__ == '__main__':
    main()
