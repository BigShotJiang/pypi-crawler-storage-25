from .google_ai_studio_api import GoogleAIStudioAPI
from .deepseek_api import DeepSeekAPI
from .exceptions import UnsupportedModelError

SUPPORTED_MODELS = {
    "google_ai_studio": GoogleAIStudioAPI,
    "deepseek": DeepSeekAPI
}

def get_ai_client(model_name: str, profile_dir: str, headless: bool = True, setup_mode: bool = False, **kwargs):
    """
    Фабричная функция для получения экземпляра API нужной модели.
    
    :param model_name: Название модели (например, 'google_ai_studio' или 'deepseek').
    :param profile_dir: Путь к директории профиля браузера.
    :param headless: Запуск в скрытом режиме.
    :param setup_mode: Режим настройки (для первой авторизации).
    :param kwargs: Дополнительные параметры (например, expert_mode для deepseek).
    :return: Экземпляр BaseWebAPI.
    """
    model_name_lower = model_name.lower()
    if model_name_lower not in SUPPORTED_MODELS:
        raise UnsupportedModelError(
            f"Неподдерживаемая ИИ-модель: '{model_name}'. "
            f"Доступные модели: {', '.join(SUPPORTED_MODELS.keys())}"
        )
    
    return SUPPORTED_MODELS[model_name_lower](
        profile_dir=profile_dir,
        headless=headless,
        setup_mode=setup_mode,
        **kwargs
    )
