from .base_api import BaseWebAPI
from .exceptions import AuthRequiredError, FirstTokenTimeoutError, ResponseTimeoutError
import time
import re

def _clean_text(text: str) -> str:
    return re.sub(r'\n{3,}', '\n\n', text).strip()

class DeepSeekAPI(BaseWebAPI):
    def __init__(self, profile_dir: str, headless: bool = True, setup_mode: bool = False, **kwargs):
        super().__init__(
            profile_dir=profile_dir,
            url="https://chat.deepseek.com/",
            headless=headless,
            disable_images=False,
            setup_mode=setup_mode,
            **kwargs
        )

    def wait_for_ready(self):
        self._handle_cloudflare()
        for _ in range(30):
            if "sign_in" in self.page.url:
                raise AuthRequiredError("Требуется повторная авторизация в DeepSeek.")
            if self.page.locator("#chat-input, textarea,[contenteditable='true']").count() > 0:
                return
            time.sleep(1)
        self.page.wait_for_selector("#chat-input, textarea, [contenteditable='true']", timeout=1000)

    def _handle_cloudflare(self):
        time.sleep(3)
        try:
            for frame in self.page.frames:
                if "cloudflare" in frame.url or "turnstile" in frame.url:
                    print("Обнаружен Cloudflare, пытаюсь пройти проверку...")
                    box = frame.locator("input[type='checkbox'], .cb-c, body")
                    if box.count() > 0:
                        box.first.click()
                        time.sleep(5)
        except Exception as e:
            print(f"Ошибка при прохождении Cloudflare: {e}")

    def ask(self, prompt: str, files: list = None, timeout: int = 600, first_token_timeout: int = 60, headless: bool = None, **kwargs) -> str:
        if headless is not None and headless != self.headless:
            self._start_browser(headless)
            
        overall_start_time = time.time()
        mode = kwargs.get("mode", None)
        if mode is not None:
            try:
                mode_loc = self.page.get_by_text(mode, exact=True)
                if mode_loc.count() > 0 and mode_loc.first.is_visible():
                    mode_loc.first.click()
                    time.sleep(0.5)
            except:
                pass

        js_toggles = r"""
        (params) => {
            const { thinking, webSearch } = params;
            
            const isActive = (el) => {
                if (el.getAttribute('aria-checked') === 'true') return true;
                if (el.getAttribute('aria-pressed') === 'true') return true;
                if (el.className && typeof el.className === 'string' && el.className.match(/(active|checked|selected)/i)) return true;
                
                const style = window.getComputedStyle(el);
                const color = style.color;
                const match = color.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
                if (match) {
                    const r = parseInt(match[1]), g = parseInt(match[2]), b = parseInt(match[3]);
                    if (b > r + 20 && b > g) return true;
                }
                return false;
            };

            const buttons = Array.from(document.querySelectorAll('div[role="button"], button'));
            
            const thinkBtn = buttons.find(b => b.innerText && b.innerText.match(/(DeepThink|Глубокое мышление)/i));
            if (thinkBtn) {
                if (isActive(thinkBtn) !== thinking) {
                    thinkBtn.click();
                }
            }
            
            const searchBtn = buttons.find(b => b.innerText && b.innerText.match(/(Умный поиск|Web Search|Search)/i));
            if (searchBtn) {
                if (isActive(searchBtn) !== webSearch) {
                    searchBtn.click();
                }
            }
        }
        """
        try:
            self.page.evaluate(js_toggles, {
                "thinking": kwargs.get("thinking", True),
                "webSearch": kwargs.get("web_search", True)
            })
            time.sleep(0.5)
        except Exception as e:
            print(f"Ошибка при переключении параметров: {e}")

        self.page.evaluate("navigator.clipboard.writeText('').catch(() => {})")

        if files:
            try:
                file_input = self.page.locator('input[type="file"]')
                file_input.set_input_files(files)
                time.sleep(1.5)
                loading_texts =["обработка", "Uploading", "Parsing", "processing", "В ожидании", "Загрузка"]
                for text in loading_texts:
                    try:
                        for el in self.page.get_by_text(text).all():
                            if el.is_visible():
                                el.wait_for(state="hidden", timeout=30000)
                    except:
                        pass
                time.sleep(2)
            except Exception as e:
                print(f"Не удалось прикрепить файлы: {e}")

        md_selector = ".ds-markdown, .markdown-body, div[class*='markdown'], div[class*='prose']"
        
        try:
            initial_md_count = self.page.locator(md_selector).count()
            initial_texts = self.page.locator(md_selector).all_inner_texts()
            initial_last_text = initial_texts[-1].strip() if initial_texts else ""
        except:
            initial_md_count = 0
            initial_last_text = ""

        chat_input = self.page.locator("#chat-input, textarea, [contenteditable='true']").first
        chat_input.fill(prompt)
        time.sleep(0.5)
        chat_input.press("Enter")

        last_text = ""
        stable_count = 0
        first_token_start_time = time.time()

        js_find_and_click = """
        () => {
            const mds = document.querySelectorAll('.ds-markdown, .markdown-body, div[class*="markdown"], div[class*="prose"]');
            if (mds.length === 0) return false;
            const lastMd = mds[mds.length - 1];
            let curr = lastMd;
            for (let i = 0; i < 5; i++) {
                if (!curr) break;
                let sibling = curr.nextElementSibling;
                while (sibling) {
                    const isInputBlock = (sibling.matches && sibling.matches('textarea, #chat-input, form, [contenteditable="true"]')) || 
                                         (sibling.querySelector && sibling.querySelector('textarea, #chat-input, form, [contenteditable="true"]'));
                    if (isInputBlock) {
                        sibling = sibling.nextElementSibling;
                        continue;
                    }
                    const btns = sibling.querySelectorAll('div.ds-icon-button[role="button"]');
                    if (btns.length >= 2) {
                        btns[0].click();
                        return true;
                    }
                    sibling = sibling.nextElementSibling;
                }
                curr = curr.parentElement;
            }
            return false;
        }
        """

        first_token_received = False

        while True:
            if time.time() - overall_start_time > timeout:
                raise ResponseTimeoutError(f"Превышено максимальное время ожидания ответа ({timeout} сек).")
            time.sleep(1)
            if "sign_in" in self.page.url:
                raise AuthRequiredError("Сессия истекла. Требуется повторная авторизация в DeepSeek.")
            try:
                current_md_count = self.page.locator(md_selector).count()
                texts = self.page.locator(md_selector).all_inner_texts()
                texts =[t.strip() for t in texts if t.strip()]
                current_text = texts[-1] if texts else ""
            except:
                current_md_count = 0
                current_text = ""

            has_new_message = False
            if current_md_count > initial_md_count:
                has_new_message = True
            elif current_text and current_text != initial_last_text:
                has_new_message = True

            if not first_token_received:
                if has_new_message:
                    first_token_received = True
                elif time.time() - first_token_start_time > first_token_timeout:
                    raise FirstTokenTimeoutError(f"Модель не начала генерацию ответа за {first_token_timeout} секунд.")

            if has_new_message:
                clicked = self.page.evaluate(js_find_and_click)
                if clicked:
                    time.sleep(0.5)
                    clip_val = self.page.evaluate("navigator.clipboard.readText().catch(() => '')")
                    if clip_val:
                        return clip_val
                
                if current_text and current_text == last_text:
                    stable_count += 1
                else:
                    stable_count = 0

                last_text = current_text

                if stable_count >= 15:
                    break

        if last_text:
            return _clean_text(last_text)
        else:
            return "Не удалось найти ответ в DOM. Возможно, изменилась верстка."
