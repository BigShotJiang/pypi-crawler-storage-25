class ProfileNotFoundError(Exception):
    """Возникает, когда указанная директория профиля не существует или пуста."""
    pass

class AuthRequiredError(Exception):
    """Возникает, когда требуется повторная авторизация в аккаунте."""
    pass

class UnsupportedModelError(Exception):
    """Возникает, когда запрашиваемая ИИ-модель не поддерживается."""
    pass

class FirstTokenTimeoutError(Exception):
    """Возникает, когда модель не начала генерировать ответ (или думать) за отведенное время."""
    pass

class ResponseTimeoutError(Exception):
    """Возникает, когда превышено общее время ожидания ответа от модели (по параметру timeout)."""
    pass

class QuotaExceededError(Exception):
    """Возникает, когда исчерпан лимит запросов (токены/квота) к ИИ-модели."""
    pass
