# Majorchik API (Browser AI)

Пакет для автоматизации работы с ИИ (DeepSeek, Google AI Studio) через браузер с использованием Playwright.

## Установка

```bash
pip install majorchik-api
```

Локальная установка для разработки:
```bash
pip install -e .
```

Обязательно установите браузеры Playwright после установки пакета:
```bash
playwright install chromium
```

## Использование

Используйте консольную команду `browser-ai`:

```bash
# 1. Настройте профиль и пройдите авторизацию (откроется окно браузера)
browser-ai setup deepseek --profile-dir ./my_profile

# 2. Запустите чат в консоли (по умолчанию браузер работает в фоне)
browser-ai chat deepseek --profile-dir ./my_profile
```
