"""
Motor IO: Smart S3 Exporter (S3Finalizer)
=========================================
Maneja la "Última Milla" del procesamiento de PySpark en AWS.
Convierte las salidas nativas de Spark (ej. part-0000...) en archivos limpios, legibles y secuenciados.
"""
import time
import logging
import concurrent.futures
from typing import List, Optional

try:
    import boto3
    from botocore.exceptions import ClientError
except ImportError:
    boto3 = None

logger = logging.getLogger(__name__)

class S3Finalizer:
    """
    Abstracción inteligente para manejar las operaciones en S3.
    Evita el molesto comportamiento por defecto de Spark limpiando archivos 
    intermedios y renombrando la salida.
    """
    
    def __init__(self, bucket_name: str, aws_region: str = 'us-east-1', mock_s3_client=None):
        self.bucket = bucket_name
        self.region = aws_region
        
        if mock_s3_client:
            self.s3 = mock_s3_client
        elif boto3:
            self.s3 = boto3.client('s3', region_name=self.region)
        else:
            raise ImportError("La librería 'boto3' no está instalada.")
            
    def list_keys(self, prefix: str) -> List[str]:
        keys = []
        paginator = self.s3.get_paginator('list_objects_v2')
        pages = paginator.paginate(Bucket=self.bucket, Prefix=prefix)
        for page in pages:
            for obj in page.get('Contents', []):
                keys.append(obj['Key'])
        return keys

    def rename_spark_output(self, s3_prefix: str, final_filename: str, max_retries: int = 3) -> bool:
        """
        Archivos únicos: Cambia part-0000.ext a final_filename.
        (Ideal para salidas coalescidas df.coalesce(1))
        """
        if not s3_prefix.endswith('/'): s3_prefix += '/'

        all_keys = []
        for attempt in range(max_retries):
            all_keys = self.list_keys(s3_prefix)
            if any(k.split("/")[-1].startswith("part-") for k in all_keys):
                break
            time.sleep(2)
            
        part_key = None
        keys_to_delete = []
        
        for key in all_keys:
            basename = key.split("/")[-1]
            if basename.startswith("part-"):
                part_key = key
            elif basename != final_filename:
                keys_to_delete.append({'Key': key})
                
        if not part_key:
            logger.warning(f"No se encontró salida 'part-' en {self.bucket}/{s3_prefix}")
            return False
            
        new_key = f"{s3_prefix}{final_filename}"
        try:
            self.s3.copy_object(Bucket=self.bucket, CopySource={'Bucket': self.bucket, 'Key': part_key}, Key=new_key)
            keys_to_delete.append({'Key': part_key})
            logger.info(f"Éxito: Salida renombrada a s3://{self.bucket}/{new_key}")
            self._batch_delete(keys_to_delete)
            return True
        except Exception as e:
            logger.error(f"Fallo al renombrar {s3_prefix}: {str(e)}")
            return False

    def sequence_spark_outputs(self, s3_prefix: str, pattern: str, extension: Optional[str] = None, max_retries: int = 3, max_workers: int = 20) -> int:
        """
        Archivos Múltiples: Encuentra TODOS los part-*.ext generados por Spark, 
        los ordena, y los renombra secuencialmente usando "hilos" en paralelo de Boto3.
        
        :param s3_prefix: La ruta de salida.
        :param pattern: El patrón del nombre deseado, ej: 'SBX.202701.{seq:04d}.SAL.gz'
        :param extension: Opcional. Si se provee, ignora partes que no tengan esta extensión.
        :param max_workers: Cantidad de hilos de red concurrentes de AWS.
        :return: Número de archivos renombrados correctamente.
        """
        if not s3_prefix.endswith('/'): s3_prefix += '/'

        all_keys = []
        for attempt in range(max_retries):
            all_keys = self.list_keys(s3_prefix)
            if any(k.split("/")[-1].startswith("part-") for k in all_keys):
                break
            time.sleep(2)

        part_keys = []
        keys_to_delete = []

        # Filtrar
        for key in all_keys:
            basename = key.split("/")[-1]
            if basename.startswith("part-"):
                if extension and not basename.endswith(extension):
                    keys_to_delete.append({'Key': key})
                else:
                    part_keys.append(key)
            elif "_SUCCESS" in basename:
                keys_to_delete.append({'Key': key})

        if not part_keys:
            logger.warning(f"No hay partes coincidentes ('{extension}') en {s3_prefix}")
            return 0

        # Ordenar (part-00000, part-00001...) nos asegura secuenciación determinista
        part_keys.sort()
        
        rename_tasks = []
        for i, old_part_key in enumerate(part_keys, start=1):
            # Soporta formato {seq:04d} -> 0001, 0002...
            try:
                new_basename = pattern.format(seq=i)
            except KeyError:
                new_basename = pattern.replace("{seq}", str(i)) # Seguridad por si el usuario pasa un string roto
                
            new_key = f"{s3_prefix}{new_basename}"
            rename_tasks.append((old_part_key, new_key))
            keys_to_delete.append({'Key': old_part_key})

        successful_renames = 0

        def _copy(task):
            src, dst = task
            try:
                self.s3.copy_object(Bucket=self.bucket, CopySource={'Bucket': self.bucket, 'Key': src}, Key=dst)
                return True
            except Exception as e:
                logger.error(f"Fallo copiando {src} a {dst}: {e}")
                return False

        # Procesamiento Paralelo en AWS
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            results = executor.map(_copy, rename_tasks)
            successful_renames = sum(1 for r in results if r)

        logger.info(f"Éxito: {successful_renames}/{len(part_keys)} archivos secuenciados.")
        self._batch_delete(keys_to_delete)
        return successful_renames
        
    def _batch_delete(self, keys: List[dict]):
        if not keys: return
        for i in range(0, len(keys), 1000):
            try: # maximoAWS permite 1000 borrados por batch
                self.s3.delete_objects(Bucket=self.bucket, Delete={'Objects': keys[i:i+1000], 'Quiet': True})
            except Exception as e:
                logger.error(f"Fallo limpiando basura S3: {e}")
