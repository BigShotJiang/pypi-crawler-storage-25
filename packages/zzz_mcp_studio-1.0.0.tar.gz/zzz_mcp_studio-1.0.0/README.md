# zzz-mcp-studio

ZZZ Studio 生图场（test-field）的 MCP 封装。把图像生成能力以 MCP 工具形式暴露给 Claude Desktop / Cursor 等 MCP 客户端。

## 工具

- `list_models()` — 列出可用图像模型
- `list_person_libraries()` — 列出人物库（自建 + 推荐）
- `list_persons_in_library(library_id)` — 列出库内人物，拿 person_id 给 generate_image 用
- `generate_image(prompt, model_ids?, aspect_ratio?, person_refs?, reference_image_paths?)` — 文生图 / 图生图（多模型并行、人物库参考、本地图片参考）
- `get_task_status(task_id)` — 查任务状态（超时后手动追踪用）

## 安装

需要 Python 3.10+ 和 [`uv`](https://docs.astral.sh/uv/)（推荐）或 `pip`。

### 方式 1：uvx 直接跑（推荐，不用手动安装）

在 Claude Desktop / Cursor 的 MCP 配置里：

```json
{
  "mcpServers": {
    "zzz-studio": {
      "command": "uvx",
      "args": [
        "--from",
        "git+https://<你们的 git 地址>/ZZZ-Studio.git#subdirectory=tools/mcp_zzz_studio",
        "zzz-mcp-studio"
      ],
      "env": {
        "ZZZ_BACKEND_URL": "https://<公网地址或局域网地址>:8000",
        "ZZZ_ACCESS_TOKEN": "<你的 JWT access_token>",
        "ZZZ_TIMEOUT_SECONDS": "120"
      }
    }
  }
}
```

### 方式 2：本地 pip 装

```bash
pip install git+https://<你们的 git 地址>/ZZZ-Studio.git#subdirectory=tools/mcp_zzz_studio
```

然后配置里 `command: "python", args: ["-m", "zzz_mcp_studio"]`，env 同上。

## 环境变量

| Key | 必填 | 默认 | 说明 |
| --- | --- | --- | --- |
| `ZZZ_BACKEND_URL` | ✓ | — | backend 根地址，如 `http://192.168.x.x:8000` 或公网 URL |
| `ZZZ_ACCESS_TOKEN` | ✓ | — | backend 的 JWT access_token（通过 `/api/auth/login` 拿到）|
| `ZZZ_TIMEOUT_SECONDS` | | `120` | 单次生图最长等待秒数 |
| `ZZZ_POLL_INTERVAL` | | `2.0` | 任务轮询间隔秒数 |

## Token 怎么拿

向管理员要，或用同事自己的浏览器登录后端后从 DevTools → Application → Local Storage → `access_token` 里取。Token 过期（默认 8h）后需要重新登录拿新的。

## 使用示例

配置好后，在 Claude Desktop 里直接说：

> 帮我用 nano banana 生成一张"一只穿西装的柯基坐在沙发上看电视"，尺寸 16:9

LLM 会自动调 `generate_image` 返回图片。

## 使用示例

**文生图（单模型）**
> 帮我生成一张"穿着西装的柯基坐在沙发上看电视"，16:9

**多模型对比**
> 用 gemini-3-pro-image-preview-vertex 和 doubao-seedream-4-5-251128 同时生成一张"宋代山水画，水墨风格"，比较效果

**图生图（用人物库参考）**
> 先列一下有哪些人物库，然后用其中的某个人做一张机甲风肖像

LLM 会自动串联调用 `list_person_libraries` → `list_persons_in_library` → `generate_image(person_refs=...)`。

**图生图（传本地图片）**
> 参考 D:\photos\me.jpg 和 D:\photos\friend.jpg，生成一张"两个人在海边散步的插画"

LLM 会把 `reference_image_paths=["D:\\photos\\me.jpg", "D:\\photos\\friend.jpg"]` 传给 `generate_image`，
MCP 自动把图上传到后端人物库（库名 `mcp_ref_<时间戳>`）再用于生成。单张 ≤ 10MB。

## 已知限制（v0.2）

- 合影 / 多人合成、自定义分辨率、任务取消、补跑单图 等功能走 web UI（按需补，暂未进 MCP）
- 本地图片上传会在后端建一个临时人物库（`mcp_ref_<时间戳>`），任务结束后自动删除；不会在 web UI 留下残留
- 单次生图最多内联返 10 张图，超出只返 URL
- 同步阻塞等待，超过 `ZZZ_TIMEOUT_SECONDS` 自动放弃，可用 `get_task_status` 手动追踪
