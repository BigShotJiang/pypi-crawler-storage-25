# 交付包说明（给你自己看）

## 发给同事的两样东西
1. `zzz-mcp-studio-v0.2.2.zip` — MCP 包本体
2. `给同事看的安装说明.md` — 一页纸说明（已经把 token、URL、device_id 全填好）

把这两个文件打包发给同事即可。微信 / 邮件 / 网盘都行。

---

## 本次已帮你做的事

- 为同事生成了一个固定的 `device_id`：`cbe023d2-1212-4da7-9177-02f1974a6b18`
- 给这个 device_id 签了一个 **30 天** access_token（到期日：2026-05-15）
- 把 device_id 登记到后端 `users.json`（便于后续用量统计 / 权限管理）
- 把 MCP 代码（pyproject.toml + src/ + README.md）打成 zip
- 写好"给同事看的安装说明.md"，把 token、公网 URL、device_id 全内嵌好

同事侧需要自己装的只有：
- Claude Desktop（或 Cursor）
- Python 3.10+
- uv

这些说明里都写明了。

---

## 30 天后怎么续 token

到 2026-05-15 前后同事的 token 会过期，告诉你报 "401 Missing or invalid token" 时，在后端机上跑：

```bash
cd D:\PJ\ZZZ-Studio\backend
./.venv/Scripts/python.exe -c "
from infrastructure.auth.jwt_auth import create_access_token
print(create_access_token('cbe023d2-1212-4da7-9177-02f1974a6b18', ttl_seconds=30*24*3600))
"
```

把打印出来的新 token 给他，让他替换配置里的 `ZZZ_ACCESS_TOKEN` 字段，重启 Claude Desktop 即可。

---

## 给第二个同事签 token 的方法

把上面脚本里的 device_id 改成一个**新的 UUID**（Python 里 `import uuid; uuid.uuid4()` 生成），并记得再跑一次 `get_or_create_user + save` 让新 device_id 落到 users.json：

```bash
./.venv/Scripts/python.exe -c "
import asyncio, uuid
from infrastructure.auth.jwt_auth import create_access_token
from infrastructure.admin import get_user_store

new_device_id = str(uuid.uuid4())
token = create_access_token(new_device_id, ttl_seconds=30*24*3600)

async def persist():
    us = get_user_store()
    us.load()
    us.get_or_create_user(new_device_id)
    await us.save()

asyncio.run(persist())
print('DEVICE_ID:', new_device_id)
print('TOKEN:', token)
"
```

复制输出填到一份新的安装说明里发给第二个同事。

---

## 升级 MCP 包的办法

如果以后 MCP 代码改了（比如加新工具），重新打 zip：

```bash
cd D:\PJ\ZZZ-Studio\tools\mcp_zzz_studio
powershell.exe -Command "Compress-Archive -Path 'pyproject.toml','README.md','src' -DestinationPath 'delivery\zzz-mcp-studio-vX.Y.Z.zip' -Force"
```

把新 zip 发给同事，让他覆盖原来的解压目录，重启 Claude Desktop 即可。
