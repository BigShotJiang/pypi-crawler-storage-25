"""ZZZ Studio MCP Server — 通用引擎，从后端动态加载 tool 定义"""

import asyncio
import logging

from mcp.server.fastmcp import FastMCP

from .config import Config
from .http_client import HttpClient
from .engine.tool_builder import build_tool_function

logger = logging.getLogger(__name__)

mcp = FastMCP("zzz-studio")


def _init_sync():
    """启动时从后端拉取 tool schema 并动态注册所有 tools"""
    config = Config.from_env()
    client = HttpClient(config)

    async def _fetch_and_register():
        try:
            resp = await client.get("/api/mcp/tools-schema")
            schema = resp.json()
            tools = schema.get("tools", [])
            logger.info("从后端加载了 %d 个 MCP tool 定义", len(tools))
            for tool_def in tools:
                fn = build_tool_function(tool_def, client)
                mcp.add_tool(fn, name=tool_def["name"], description=tool_def.get("description", ""))
                logger.info("  注册 tool: %s", tool_def["name"])
        except Exception:
            logger.exception("从后端加载 MCP tool schema 失败")
            raise

    asyncio.get_event_loop().run_until_complete(_fetch_and_register())


_init_sync()


def run() -> None:
    """stdio 入口"""
    mcp.run(transport="stdio")
