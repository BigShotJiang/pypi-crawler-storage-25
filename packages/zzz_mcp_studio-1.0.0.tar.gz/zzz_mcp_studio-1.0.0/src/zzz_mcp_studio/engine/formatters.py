"""结果格式化：根据 result_type 将 API 返回转换为 MCP 内容"""

import base64
import logging
from typing import Any, Dict, List

from mcp.types import ImageContent, TextContent

from ..http_client import HttpClient

logger = logging.getLogger(__name__)


async def format_list_response(data: Dict[str, Any], response_config: Dict[str, Any]) -> str:
    """格式化列表响应为文本"""
    data_key = response_config.get("data_key", "")
    display_fields = response_config.get("display_fields", [])
    items = data.get(data_key, []) if data_key else data
    if not items:
        return "(空列表)"
    lines = []
    for item in items:
        if isinstance(item, dict):
            parts = [f"{k}={item.get(k, '')}" for k in display_fields if item.get(k) is not None]
            lines.append("- " + "  ".join(parts))
        else:
            lines.append(f"- {item}")
    return "\n".join(lines)


async def format_task_status(data: Dict[str, Any]) -> str:
    """格式化任务状态"""
    task = data.get("task", data)
    status = task.get("status") or "?"
    stage = task.get("stage_label") or task.get("stage") or ""
    progress = ""
    if task.get("progress_total"):
        progress = f" progress={task.get('progress_current')}/{task.get('progress_total')}"
    task_id = task.get("id") or task.get("task_id") or "?"
    return f"task_id={task_id} status={status} stage={stage}{progress}".strip()


async def format_result(
    client: HttpClient,
    task_id: str,
    result_data: Dict[str, Any],
    async_config: Dict[str, Any],
    max_inline: int = 10,
) -> list[Any]:
    """根据 result_type 格式化任务结果为 MCP 内容列表"""
    result_type = async_config.get("result_type", "json")
    result_key = async_config.get("result_key")

    if result_type == "video":
        video_url = result_data.get(result_key, "") if result_key else ""
        if not video_url:
            video_url = result_data.get("video_url") or result_data.get("output_url") or ""
        return [TextContent(type="text", text=f"task_id={task_id}\n视频地址: {video_url}")]

    if result_type == "text":
        text = result_data.get(result_key, "") if result_key else str(result_data)
        return [TextContent(type="text", text=text)]

    if result_type == "json":
        import json
        text = json.dumps(result_data, ensure_ascii=False, indent=2)
        return [TextContent(type="text", text=f"task_id={task_id}\n{text}")]

    if result_type == "image":
        return await _format_image_result(client, task_id, result_data, async_config, max_inline)

    return [TextContent(type="text", text=f"task_id={task_id}\n{result_data}")]


async def _format_image_result(
    client: HttpClient,
    task_id: str,
    result_data: Dict[str, Any],
    async_config: Dict[str, Any],
    max_inline: int,
) -> list[Any]:
    """下载图片并内联返回（超限则只返 URL）"""
    result_key = async_config.get("result_key")

    # 情况1：结果是图片列表（如 test_field、common_persons_v2）
    if result_key and isinstance(result_data.get(result_key), list):
        images = result_data[result_key]
        successes = [im for im in images if im.get("success", True)]
        failures = [im for im in images if not im.get("success", True)]

        header = f"task_id={task_id}\n共 {len(images)} 张（成功 {len(successes)} / 失败 {len(failures)}）"
        content: list[Any] = [TextContent(type="text", text=header)]

        if len(successes) > max_inline:
            url_lines = [f"图片过多（>{max_inline}），仅返 URL："]
            for im in successes:
                url = im.get("image_url") or im.get("oss_url") or im.get("source_url") or ""
                label = im.get("model_name") or im.get("model_id") or ""
                url_lines.append(f"  - {label}: {url}")
            content.append(TextContent(type="text", text="\n".join(url_lines)))
            return content

        for im in successes:
            url = im.get("image_url") or im.get("oss_url") or im.get("source_url") or ""
            if not url:
                continue
            try:
                img_bytes, mime = await client.download(url)
                label = im.get("model_name") or im.get("model_id") or ""
                content.append(TextContent(type="text", text=label))
                content.append(ImageContent(
                    type="image",
                    data=base64.b64encode(img_bytes).decode("ascii"),
                    mimeType=mime,
                ))
            except Exception as exc:
                content.append(TextContent(type="text", text=f"[下载失败] {url}: {exc!r}"))
        return content

    # 情况2：结果是单张图片（如 word_meme、timemachine），通过 result_image_endpoint 取
    image_endpoint = async_config.get("result_image_endpoint")
    if image_endpoint:
        url = image_endpoint.replace("{task_id}", task_id)
        try:
            img_bytes, mime = await client.download(url)
            return [
                TextContent(type="text", text=f"task_id={task_id}"),
                ImageContent(type="image", data=base64.b64encode(img_bytes).decode("ascii"), mimeType=mime),
            ]
        except Exception as exc:
            return [TextContent(type="text", text=f"task_id={task_id}\n图片下载失败: {exc!r}")]

    # 情况3：result 字段本身是 OSS URL
    result_val = result_data.get(result_key, "") if result_key else ""
    if isinstance(result_val, str) and result_val.startswith("http"):
        try:
            img_bytes, mime = await client.download(result_val)
            return [
                TextContent(type="text", text=f"task_id={task_id}"),
                ImageContent(type="image", data=base64.b64encode(img_bytes).decode("ascii"), mimeType=mime),
            ]
        except Exception:
            return [TextContent(type="text", text=f"task_id={task_id}\n图片地址: {result_val}")]

    return [TextContent(type="text", text=f"task_id={task_id}\n{result_data}")]
