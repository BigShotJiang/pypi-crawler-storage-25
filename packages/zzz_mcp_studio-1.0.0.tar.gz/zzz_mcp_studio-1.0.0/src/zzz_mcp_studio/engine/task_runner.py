"""通用异步任务轮询：提交 → 等待完成 → 取结果"""

import asyncio
import time
from typing import Any, Dict

from ..http_client import HttpClient


async def poll_until_complete(
    client: HttpClient,
    task_id: str,
    timeout: float | None = None,
    poll_interval: float | None = None,
) -> Dict[str, Any]:
    """轮询 /api/tasks/{task_id} 直到 completed / failed / 超时，返回 task dict"""
    _timeout = timeout or client.config.timeout_seconds
    _interval = poll_interval or client.config.poll_interval
    deadline = time.monotonic() + _timeout

    while True:
        resp = await client.get(f"/api/tasks/{task_id}")
        task = (resp.json() or {}).get("task", {}) or {}
        status = (task.get("status") or "").lower()

        if status == "completed":
            return task
        if status == "failed":
            err = task.get("error_message") or task.get("status_reason") or "未知错误"
            raise RuntimeError(f"任务失败: {err}")
        if time.monotonic() > deadline:
            raise TimeoutError(
                f"任务 {task_id} 在 {_timeout}s 内未完成（当前 status={status}）。"
                f"可用 get_task_status 手动追踪。"
            )
        await asyncio.sleep(_interval)


async def get_task_result(
    client: HttpClient,
    task_id: str,
    result_endpoint: Dict[str, str],
) -> Dict[str, Any]:
    """根据 result_endpoint 配置取结果"""
    path = result_endpoint["path"].replace("{task_id}", task_id)
    resp = await client.get(path)
    return resp.json() or {}
