"""tool_builder — 根据后端 tool schema 动态生成 MCP tool 函数"""

import inspect
import logging
from typing import Any, Dict, List, Optional

from ..http_client import HttpClient
from .task_runner import poll_until_complete, get_task_result
from .formatters import format_list_response, format_task_status, format_result

logger = logging.getLogger(__name__)

# Python type annotation mapping
_TYPE_MAP = {
    "string": str,
    "integer": int,
    "number": float,
    "boolean": bool,
    "array": list,
    "object": dict,
}


def _build_signature(params_schema: Dict[str, Any]) -> inspect.Signature:
    """从 schema parameters 构建 Python 函数签名"""
    parameters = []
    # required 参数在前，optional 在后
    for name, spec in sorted(params_schema.items(), key=lambda x: (not x[1].get("required", False), x[0])):
        annotation = _TYPE_MAP.get(spec.get("type", "string"), str)
        if spec.get("required", False):
            param = inspect.Parameter(
                name,
                inspect.Parameter.KEYWORD_ONLY,
                annotation=annotation,
            )
        else:
            default = spec.get("default")
            # For Optional types with None default
            if default is None and not spec.get("required"):
                annotation = Optional[annotation]
            param = inspect.Parameter(
                name,
                inspect.Parameter.KEYWORD_ONLY,
                default=default,
                annotation=annotation,
            )
        parameters.append(param)
    return inspect.Signature(parameters)


def _build_request_body(tool_def: Dict[str, Any], kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """根据 tool schema 构建请求体"""
    params_schema = tool_def.get("parameters", {})
    transform = tool_def.get("request_transform", {})

    body = {}

    # 添加 extra_fields（如 dimension_mode: "preset"）
    extra = transform.get("extra_fields", {})
    body.update(extra)

    # 字段映射
    field_mapping = transform.get("field_mapping", {})

    for key, value in kwargs.items():
        if value is None:
            continue
        # person_id → model_id 转换
        if key == "person_refs" and transform.get("person_id_to_model_id"):
            mapped_key = field_mapping.get(key, key)
            body[mapped_key] = [
                {"library_id": p["library_id"], "model_id": p["person_id"]}
                for p in value
            ] if value else None
            continue
        mapped_key = field_mapping.get(key, key)
        body[mapped_key] = value

    return body


def build_tool_function(tool_def: Dict[str, Any], client: HttpClient):
    """根据 tool schema 生成一个 async function 供 FastMCP 注册"""
    endpoint = tool_def["endpoint"]
    method = endpoint["method"].upper()
    path_template = endpoint["path"]
    params_schema = tool_def.get("parameters", {})
    param_mapping = tool_def.get("param_mapping", {})  # e.g. {"library_id": "query"}
    response_config = tool_def.get("response", {})
    async_config = tool_def.get("async_task")
    response_format = response_config.get("format", "json")

    async def tool_fn(**kwargs) -> Any:
        # 替换路径参数
        path = path_template
        query_params = {}
        body_kwargs = dict(kwargs)

        for key, value in list(body_kwargs.items()):
            placeholder = "{" + key + "}"
            if placeholder in path:
                path = path.replace(placeholder, str(value))
                del body_kwargs[key]
            elif param_mapping.get(key) == "query":
                query_params[key] = value
                del body_kwargs[key]

        if method == "GET":
            # GET 请求：剩余参数作为 query params
            query_params.update(body_kwargs)
            resp = await client.get(path, params=query_params or None)
            data = resp.json() or {}

            if response_format == "list":
                return await format_list_response(data, response_config)
            if response_format == "task_status":
                return await format_task_status(data)
            if response_format == "json":
                import json
                return json.dumps(data, ensure_ascii=False, indent=2)
            return str(data)

        # POST 请求
        body = _build_request_body(tool_def, body_kwargs)
        resp = await client.post(path, json=body)
        data = resp.json() or {}

        if not async_config:
            import json
            return json.dumps(data, ensure_ascii=False, indent=2)

        # 异步任务：提交 → 轮询 → 取结果 → 格式化
        task_id = data.get("task_id")
        if not task_id:
            raise RuntimeError(f"提交成功但无 task_id: {data}")

        await poll_until_complete(client, task_id)

        result_data = await get_task_result(client, task_id, async_config["result_endpoint"])

        return await format_result(
            client, task_id, result_data, async_config,
            max_inline=client.config.max_inline_media,
        )

    # 设置函数签名和 docstring
    tool_fn.__signature__ = _build_signature(params_schema)
    tool_fn.__doc__ = tool_def.get("description", "")
    tool_fn.__name__ = tool_def["name"]
    tool_fn.__qualname__ = tool_def["name"]

    return tool_fn
