import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Config:
    backend_url: str
    access_token: str
    timeout_seconds: int
    poll_interval: float
    max_inline_media: int

    @classmethod
    def from_env(cls) -> "Config":
        backend_url = os.environ.get("ZZZ_BACKEND_URL", "").rstrip("/")
        access_token = os.environ.get("ZZZ_ACCESS_TOKEN", "").strip()
        if not backend_url:
            raise RuntimeError("ZZZ_BACKEND_URL 环境变量未设置")
        if not access_token:
            raise RuntimeError("ZZZ_ACCESS_TOKEN 环境变量未设置")
        timeout = int(os.environ.get("ZZZ_TIMEOUT_SECONDS", "120"))
        poll = float(os.environ.get("ZZZ_POLL_INTERVAL", "2.0"))
        max_inline = int(os.environ.get("ZZZ_MAX_INLINE_MEDIA", "10"))
        return cls(
            backend_url=backend_url,
            access_token=access_token,
            timeout_seconds=max(10, timeout),
            poll_interval=max(0.5, poll),
            max_inline_media=max(1, max_inline),
        )
