"""通用 HTTP 客户端 — 所有 MCP 请求的入口，自动携带 auth + X-Source 标识"""

from typing import Any

import httpx

from .config import Config


class HttpClient:
    def __init__(self, config: Config):
        self.config = config
        self._http = httpx.AsyncClient(
            base_url=config.backend_url,
            headers={
                "Authorization": f"Bearer {config.access_token}",
                "X-Source": "mcp",
            },
            timeout=httpx.Timeout(connect=15, read=60, write=30, pool=15),
        )

    async def get(self, path: str, *, params: dict[str, Any] | None = None) -> httpx.Response:
        resp = await self._http.get(path, params=params)
        resp.raise_for_status()
        return resp

    async def post(self, path: str, *, json: dict[str, Any] | None = None) -> httpx.Response:
        resp = await self._http.post(path, json=json)
        resp.raise_for_status()
        return resp

    async def download(self, url: str) -> tuple[bytes, str]:
        """下载图片/视频，相对路径走 auth，绝对 URL 走匿名"""
        if url.startswith("/"):
            resp = await self._http.get(url)
        else:
            async with httpx.AsyncClient(timeout=60.0) as anon:
                resp = await anon.get(url)
        resp.raise_for_status()
        mime = resp.headers.get("content-type", "image/png").split(";")[0].strip()
        return resp.content, mime

    async def aclose(self):
        await self._http.aclose()
