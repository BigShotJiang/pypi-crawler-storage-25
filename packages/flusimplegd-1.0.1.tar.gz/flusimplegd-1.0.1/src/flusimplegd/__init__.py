from .core import (
    code
)

__version__ = "1.0.0"
__author__ = "Flu3f"