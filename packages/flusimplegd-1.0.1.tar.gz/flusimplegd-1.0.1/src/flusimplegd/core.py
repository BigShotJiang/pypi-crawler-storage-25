"""Stack Machine"""

## Errors

class GoToError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class MathError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')
    
class CycleError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class AddressError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class IfError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class QuantityError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

class DefineError(Exception):
    def __init__(self, message):
        super().__init__(f'{message}')

## Lexer

class Lexer:
    def __init__(self, data):
        self.data = data
    
    @property
    def form(self):
        result = []
        
        for line in self.data.strip().split('\n'):
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            parts = line.split()
            if len(parts) == 2:
                string_val = parts[0]
                second_val = parts[1]
                if second_val.startswith('(') and second_val.endswith(')'):
                    tuple_content = second_val[1:-1].strip()
                    if tuple_content:
                        tuple_parts = [p.strip() for p in tuple_content.split(',')]
                        try:
                            converted = []
                            for p in tuple_parts:
                                num = float(p)
                                if num.is_integer():
                                    num = int(num)
                                converted.append(num)
                            second_val = converted
                        except ValueError:
                            pass
                    else:
                        second_val = []
                else:
                    try:
                        number_val = float(second_val)
                        if number_val.is_integer():
                            number_val = int(number_val)
                        second_val = number_val
                    except ValueError:
                        pass
                
                result.append(string_val)
                result.append(second_val)
        
        return result
    
    @property
    def start(self):
        result = []
        if len(self.data) % 2 != 0:
            raise QuantityError(f'There is an unfinished "Operation-Value" pair in the code')
        for i in range(0, len(self.data), 2):
            result.append([self.data[i], self.data[i+1]])
        return result

## Operations

change_list = ['change', 'jump', 'to', 'goto']
add_list = ['add', 'plus', 'sum']
sub_list = ['sub', 'subtract', 'minus']
copy_list = ['copy', 'move']
set_list = ['set', 'make']
output_list = ['output', 'print', 'write']
cycle_start_list = ['[', 'cycle_start', '(']
cycle_end_list = [']', 'cycle_end', ')']
if_list = ['if', 'when']
def_start_list = ['fun', 'function', 'op', 'operation']
def_end_list = ['fun_end', 'end', 'op_end']

## Parser

class Parser:
    def __init__(self, data, len, num_cells=6):
        if num_cells < 1 or not(isinstance(num_cells, int)):
            raise QuantityError(f'The number of cells must be natural and greater than 1')
        self.data = data
        self.current_cell = 1
        self.pos = 1
        self.cells, self.output = [0 for i in range(num_cells)], 0
        self.cycles = [[] for i in range(len)]
        self.code_len = len
        self.address_to = -1
        self.num_cells = num_cells
        self.fun_names = []
        self.fun_pos = []
        self.read_def = False
        self.num_op = 0
        self.value = []
        self.in_fun = False

    def to(self, address_to=-1):
        if address_to == -1:
            self.pos += 1
        elif address_to == -2:
            self.pos -= 1
        else:
            self.pos = address_to
    
    @property
    def do(self):
        operation = self.data[self.pos-1][0]
        value = self.data[self.pos-1][1]
        if not isinstance(value, (int, str, list)):
            raise MathError(f'Cannot work with non-integer numbers')

        if operation in change_list:
            if 1 <= value <= self.num_cells:
                self.current_cell = value
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')

        elif operation in add_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if value >= 0:
                self.cells[self.current_cell-1] += value
            else:
                if value < -self.num_cells:
                    raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
                self.cells[self.current_cell-1] += self.cells[-1-value]

        elif operation in sub_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if value >= 0:
                self.cells[self.current_cell-1] -= value
            else:
                if value < -self.num_cells:
                    raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
                self.cells[self.current_cell-1] -= self.cells[-1-value]
        
        elif operation in copy_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if self.num_cells >= value >= 1:
                self.cells[value-1] = self.cells[self.current_cell-1]
            elif -self.num_cells <= value <= -1:
                self.cells[self.current_cell-1] = self.cells[-value-1]
            else:
                raise GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
        
        elif operation in set_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            self.cells[self.current_cell-1] = value
        
        elif operation in output_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if 1 <= value <= self.num_cells:
                self.output = self.cells[value-1]
            else:
                GoToError(f'Cell numbers are natural numbers from 1 to {self.num_cells} inclusive')
        
        elif operation in cycle_start_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if value < -2:
                raise CycleError(f'Cannot repeat the cycle {value} times')
            
            if value > 0:
                self.cycles[self.pos-1] = [value]
            elif value == 0:
                self.cycles[self.pos-1] = ['=']
            elif value == -1:
                self.cycles[self.pos-1] = ['>']
            elif value == -2:
                self.cycles[self.pos-1] = ['<']
        
        elif operation in cycle_end_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if value > self.code_len or value < 1:
                raise AddressError(f'Cannot go beyond the code boundary')
            type = self.cycles[value-1][0]
            if type == '=':
                if self.cells[self.current_cell-1] == 0:
                    self.address_to = -1
                else:
                    self.address_to = value+1
            elif type == '>':
                if self.cells[self.current_cell-1] > 0:
                    self.address_to = -1
                else:
                    self.address_to = value+1
            elif type == '<':
                if self.cells[self.current_cell-1] < 0:
                    self.address_to = -1
                else:
                    self.address_to = value+1
            else:
                if type > 1:
                    self.address_to = value+1
                    self.cycles[value-1][0] -= 1
                else:
                    self.address_to = -1
        
        elif operation in if_list:
            if isinstance(value, str) and value.startswith('val'):
                try:
                    value = self.value[int(value[3:])-1]
                except IndexError:
                    raise QuantityError(f'Not enough elements')
            if 1 <= value <= self.code_len:
                if self.cells[self.current_cell-1] <= 0:
                    self.address_to = value
                else:
                    self.address_to = -1
            elif -1 >= value >= -self.code_len:
                if self.cells[self.current_cell-1] >= 0:
                    self.address_to = -value
                else:
                    self.address_to = -1
            else:
                raise AddressError(f'Cannot go beyond the code boundary')
        
        elif operation in def_start_list:
            if not self.in_fun:
                if value in (self.fun_names + change_list + add_list + sub_list + copy_list + set_list + cycle_start_list + cycle_end_list + if_list + def_start_list + def_end_list):
                    raise NameError('Operation with this name already exists')
                self.fun_names.append(value)
                self.fun_pos.append(self.pos+1)
                self.read_def = True
            else:
                raise DefineError(f'Cannot define function in function')

        elif operation in def_end_list:
            self.address_to = self.num_op + 1
            self.in_fun = False

        elif operation in self.fun_names:
            if not self.in_fun:
                self.num_op = self.pos
                self.address_to = self.fun_pos[self.fun_names.index(operation)]
                self.value = value
                self.in_fun = True
            else:
                raise GoToError(f'Cannot run a function within a function')

        else:
            raise NameError('Invalid operation name')

    @property    
    def start(self):
        while self.pos <= self.code_len:
            self.do
            if self.read_def:
                while not self.data[self.pos-1][0] in def_end_list:
                    self.to()
                self.read_def = False
            self.to(self.address_to)
            self.address_to = -1
        return self.cells + [self.output]

def code(code, num_cells=6):
    lexer = Lexer(Lexer(code).form).start
    print(Parser(lexer, len(lexer), num_cells).start)