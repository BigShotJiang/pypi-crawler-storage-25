# Wazuh API Kit

The Wazuh API kit Project equips you with the necessary tools for a flexible and reliable interaction with the Wazuh API.

The library’s core component, the `WazuhApiConnection` class, enables you to seamlessly file requests against the Wazuh API. Redundant tasks, such as authentication and refreshing authorization tokens, as well as common pitfalls, namely expired authorization tokens and rate limitations, are being taken care of.

Build on top of the WazuhApiConnection, the `WazuhApiClient` class provides methods, which abstracts API endpoints and translates their responses to well documented python objects.

## Key Features

- Automated authentication and authorization token renewal
- Customizable rate limitation
- Translated responses that allow you to work on Python objects rather than plain JSON dictionaries
- Comprehensive error logging and deprecation warnings

## Documentation

For more information and examples take a look at our [Documentation](https://lumirio.pages.lyfr.org/wazuh-api-kit/).

## Installation

``` shell
pip install wazuh-api-kit
```

## Usage Examples

Request the `GET /` endpoint (Get API Info) via the `WazuhApiConnection` class.
```python
from http import HTTPMethod

from wazuh_api_kit import WazuhApiConnection
from wazuh_api_kit.model import WazuhResponse

connection: WazuhApiConnection = WazuhApiConnection(
    wazuh_api_url="https://localhost:55000",
    wazuh_api_username="wazuh",
    wazuh_api_password="wazuh",
    wazuh_api_insecure=True,
)

api_info: WazuhResponse = connection.request(
    method=HTTPMethod.GET,
    path="/"
)

print(api_info.data["api_version"])
```
---
Request the `GET /` endpoint (Get API Info) via the `WazuhApiClient` class.
```python
from wazuh_api_kit import WazuhApiConnection, WazuhApiClient
from wazuh_api_kit.model import WazuhApiInfo

connection: WazuhApiConnection = WazuhApiConnection(
    wazuh_api_url="https://localhost:55000",
    wazuh_api_username="wazuh",
    wazuh_api_password="wazuh",
    wazuh_api_insecure=True,
)

api_client: WazuhApiClient = WazuhApiClient(
    wazuh_api_connection=connection
)

api_info: WazuhApiInfo = api_client.api_info_get()

print(api_info.version)
```

## Contribute

Please read the [Contribution guidelines](./CONTRIBUTING.md) before making contributions or submitting an issue.

## License

The project is licensed under the [MIT License](LICENSE.txt).

[Third party notices](THIRD-PARTY-NOTICES.txt)
