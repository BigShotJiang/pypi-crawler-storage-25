"""
Provides the :class:`RateLimiter` class, which allows to limit the amount of actions
that may be performed within a defined time frame.
"""

import collections
import logging
import threading
import time
from collections import deque


class RateLimiter:
    """
    A thread safe class which allows to enforce rate limits.
    """

    __max_actions: int
    __period: int
    __sleep_time: int
    __actions: deque

    def __init__(self, max_actions: int, period: int, sleep_time: int = 2):
        """
        Arguments
        ---------
        max_actions : int
            Maximum actions, that may be performed within the period of time.
        period : int
            Time frame in which the amount of actions may not be exceeded.
        sleep_time : int, optional
            Time span in seconds the thread should be put to sleep upon reaching the rate limit.
            Defaults to 2 seconds
        """
        self.__max_actions = max_actions
        self.__period = period
        self.__sleep_time = sleep_time

        self._lock = threading.Lock()

        # Queue which tracks the execution times of actions
        self.__actions = collections.deque()

    # pylint: disable=consider-using-with
    def apply(self):
        """
        Creates a record of an action and forces the caller to
        wait in case the rate limit would be exceeded.
        """
        self._lock.acquire()

        self.__remove_entries_outside_time_frame()

        # Wait until the amount of actions is below the threshold
        while len(self.__actions) >= self.__max_actions:
            logging.debug(
                "Limiting rate: Thread set to sleep for %s seconds.",
                self.__sleep_time,
            )

            self._lock.release()
            time.sleep(self.__sleep_time)
            self._lock.acquire()

            self.__remove_entries_outside_time_frame()

        # Create a record of the action
        self.__actions.append(time.time())

        self._lock.release()

    def __remove_entries_outside_time_frame(self):
        """
        Removes action entries that are not within the defined time frame.
        """
        frame_begin = time.time() - self.__period

        # Action records are sorted. Remove entries from the left until
        # the time frame beginning is reached.
        while len(self.__actions) > 0 and self.__actions[0] < frame_begin:
            self.__actions.popleft()
