"""
Provides the :class:`~WazuhApiClient` class, which abstracts api calls and translates
response json dictionaries to objects.
"""

import logging
from functools import wraps
from http import HTTPMethod
from typing import Iterable

from semver import Version
from wazuh_api_kit.model import (
    WazuhActiveResponseCommand,
    WazuhAgent,
    WazuhAgentAddRequest,
    WazuhAgentCredentials,
    WazuhApiInfo,
    WazuhBulkResponse,
    WazuhResponse,
)
from wazuh_api_kit.model.agent.wazuh_agent_component_constants import (
    WazuhAgentComponent,
    WazuhAgentComponentConstants,
)
from wazuh_api_kit.model.agent.wazuh_agent_status_constants import WazuhAgentStatus
from wazuh_api_kit.model.agent.wazuh_agent_wmodules import WazuhAgentModules
from wazuh_api_kit.model.configuration.internal import (
    WazuhInternalConfiguration,
    WazuhInternalExecdConfiguration,
    WazuhInternalLogcollectorConfiguration,
    WazuhInternalSyscheckConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent import (
    WazuhAgentAntiTamperingConfiguration,
    WazuhAgentBufferConfiguration,
    WazuhAgentClientConfiguration,
    WazuhAgentLabelsConfiguration,
    WazuhAgentLocalfileConfiguration,
    WazuhAgentLoggingConfiguration,
    WazuhAgentRootcheckConfiguration,
    WazuhAgentSocketConfiguration,
    WazuhAgentSyscheckConfiguration,
)
from wazuh_api_kit.model.configuration.wazuh_agent_configuration_constants import (
    WazuhAgentConfiguration,
    WazuhAgentConfigurationConstants,
)
from wazuh_api_kit.model.manager import WazuhManagerStatus
from wazuh_api_kit.wazuh_api_connection import (
    WazuhApiConnection,
)


class WazuhApiClient:
    """
    Abstraction which allows to interact with the Wazuh API without the need to forge
    requests and parse responses. Tasks such as authentication and rate limiting are
    handled by the underlying :class:`~WazuhApiConnection` class.
    """

    __logger: logging.Logger = logging.getLogger("WazuhApiClient")
    __connection: WazuhApiConnection

    def __init__(self, wazuh_api_connection: WazuhApiConnection):
        """
        Arguments
        ---------
            wazuh_api_connection: WazuhApiConnection
                :class:`~WazuhApiConnection` instance which will be used to perform request.
        """
        self.__connection = wazuh_api_connection

    # ##########################################################################################################################
    # Decorator
    # ##########################################################################################################################

    @staticmethod
    # pylint: disable-next=unused-private-member
    def __version_restrictions(
        min_version: str = None,
        max_version: str = None,
        deprecated_since: str = None,
    ) -> callable:
        """
        Decorator which allows to specify the minimum and maximum supported version of
        an API endpoint. Additionally the version in which an API endpoint has been
        deprecated may be specified. The through the :class:`~WazuhApiConnection` class
        exposed :class:`~WazuhApiInfo`'s version info will be compared against the
        limitations. Should a version requirement not be met a RuntimeError will be
        thrown. The usage of deprecated API endpoints will be written to the logs as a
        warning.
        """

        def decorator(api_function: callable) -> callable:

            @wraps(api_function)
            def enforce_version_restrictions(self, *args, **kwargs) -> any:
                api_version: Version = self.connection.get_api_info().get_version()

                # Check if the API version is lower than the minimum required version
                if min_version is not None and -1 == api_version.compare(min_version):
                    raise RuntimeError(f"""
                        Maximum version requirement for API function {api_function.__name__} not met.
                        Minimum required version: {min_version}
                        Actual version: {api_version}
                        """)
                if max_version is not None and 1 == api_version.compare(max_version):
                    raise RuntimeError(f"""
                        Maximum version requirement for API function {api_function.__name__} not met.
                        Maximum supported version: {max_version}
                        Actual version: {api_version}
                        """)
                if deprecated_since is not None:
                    suffix = (
                        f" and won't be available beyond version {max_version}."
                        if max_version is not None
                        else "."
                    )

                    # pylint: disable-next=protected-access
                    self.__logger.warning(
                        "API function %s has been deprecated in version %s%s",
                        api_function.__name__,
                        deprecated_since,
                        suffix,
                    )

                # The API function is now safe to use
                return api_function(self, *args, **kwargs)

            return enforce_version_restrictions

        return decorator

    @staticmethod
    def __raise_for_manager_id(api_function: callable) -> callable:
        """
        Decorator which allows to raise an exception when the `agent_id`
        argument is the manager id. The decorator will also raise an error
        when the arguments do not contain the `agent_id` key.

        Raises
        ------
        RuntimeError
            The decorated method's arguments do not contain the `agent_id` key.
        ValueError
            The to the decorated method passed value for the `agent_id` argument
            resembles the manager's id ("000").
        """

        @wraps(api_function)
        def raise_on_manager_id(self, *args, **kwargs) -> any:
            if "agent_id" not in kwargs:
                decorated_method = getattr(api_function, "__name__", repr(callable))
                raise RuntimeError(
                    f"{decorated_method} was decorated with @__raise_for_manager_id but has no agent_id argument"
                )
            if int(kwargs.get("agent_id")) == 0:
                raise ValueError("Method may not be called for the manager (agent_id='000')")

            return api_function(self, *args, **kwargs)

        return raise_on_manager_id

    # ##########################################################################################################################
    # API INFO | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/API-Info
    #
    # - GET     /   Get API info
    # ##########################################################################################################################

    def api_info_get(self) -> WazuhApiInfo:
        """
        Fetches Wazuh API information.

        Returns
        -------
        WazuhApiInfo
            The requested Wazuh API information object.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        HTTPError
            Non Wazuh API related exception.
        """
        response: WazuhResponse = self.__connection.request(method=HTTPMethod.GET, path="/")

        return WazuhApiInfo(**response.data)

    # ##########################################################################################################################
    # ACTIVE-RESPONSE | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Active-response
    #
    # - PUT     /active-response    Run command
    # ##########################################################################################################################

    def active_response_run_command(
        self, command: WazuhActiveResponseCommand, agents_list: list[str] = None
    ) -> WazuhBulkResponse[str, str]:
        """
        Run an Active Response command on all or a list of agents.

        Arguments
        ---------
        command: WazuhActiveResponseCommand
            The command specification that will be executed on the agents.
        agents_list: list[str], optional
            List of agents the command will be executed on.

            Default: None (Command will be executed on all agents)

        Returns
        -------
        WazuhBulkResponse
            Summary of agents on which the command has been triggered successfully
            (affected_items: list[agent_id: str]) and agents on which the execution
            of the command failed (failed_items: list[agent_id: str]).
        """

        parameters: dict[str:any] = {"wait_for_complete": True}

        if agents_list is not None:
            parameters["agents_list"] = str(agents_list)

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.PUT,
            path="/active-response",
            parameters=parameters,
            payload=command.json(),
        )

        return WazuhBulkResponse(response.data)

    # ##########################################################################################################################
    # AGENTS | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Agents
    #
    # - DELETE  /agents                                                 Delete agents
    # - GET     /agents                                                 List agents
    # - POST    /agents                                                 Add agent
    # - GET     /agents/{agent_id}/config/{component}/{configuration}   Get active configuration
    # - DELETE  /agents/{agent_id}/group                                Remove agent from groups
    # - GET     /agents/{agent_id}/group/is_sync                        Get configuration sync status <<Deprecated since 4.4.x>>
    # - DELETE  /agents/{agent_id}/group/{group_id}                     Remove agent from group
    # - PUT     /agents/{agent_id}/group/{group_id}                     Assign agent to group
    # - GET     /agents/{agent_id}/key                                  Get key
    # - PUT     /agents/{agent_id}/restart                              Restart agent
    # - GET     /agents/{agent_id}/daemons/stats                        Get Wazuh daemon stats from an agent
    # - GET     /agents/{agent_id}/stats/{component}                    Get agent's component stats
    # - PUT     /agents/upgrade                                         Upgrade agents
    # - PUT     /agents/upgrade_custom                                  Upgrade agents custom
    # - GET     /agents/upgrade_result                                  Get upgrade results
    # - GET     /agents/uninstall                                       Check user's permission to uninstall agents
    # - DELETE  /agents/group                                           Remove agents from group
    # - PUT     /agents/group                                           Assign agents to group
    # - PUT     /agents/group/{group_id}/restart                        Restart agents in group
    # - POST    /agents/insert                                          Add agent full
    # - POST    /agents/insert/quick                                    Add agent quick
    # - GET     /agents/no_group                                        List agents without group
    # - PUT     /agents/node/{node_id}/restart                          Restart agents in node
    # - GET     /agents/outdated                                        List outdated agents
    # - PUT     /agents/reconnect                                       Force reconnect agents
    # - PUT     /agents/restart                                         Restart agents
    # - GET     /agents/stats/distinct                                  List agents distinct
    # - GET     /agents/summary                                         Summarize agents information
    # - GET     /agents/summary/os                                      Summarize agents OS
    # - GET     /agents/summary/status                                  Summarize agents status
    # ##########################################################################################################################

    def agent_delete(
        self,
        agent_list: list[str],
        status: str = "all",
        older_than: str = "0d",
        purge: bool = False,
    ) -> WazuhBulkResponse[str, str]:
        """
        Delete a single or multiple Wazuh agents.

        Arguments
        ---------
        agent_list: list[str]
            List of the agent's ids which will be deleted. Alternatively a list
            with only the keyword `all` may be used to select all agents.
        status: AgentStatus
            Acceptable status of agents for deletion. Accepted values:
            ["all", "active", "pending", "never_connected", "disconnected"]

            Default: "all"
        older_than: str, optional
            Minimum required age of the wazuh agent to be eligible for deletion.

            Default: 0d
        purge: bool, optional
            Delete the agent permanently.

            Default: False

        Returns
        -------
        WazuhBulkResponse
            Summary of the deleted agents (affected_items: list[agent_id: str])
            and agents which could not be deleted (failed_items: list[agent_id: str]).
        """

        parameters: dict[str:any] = {
            "wait_for_complete": True,
            "agents_list": ",".join(agent_list),
            "status": status,
            "older_than": older_than,
            "purge": purge,
        }

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.DELETE,
            path="/agents",
            parameters=parameters,
        )

        return WazuhBulkResponse(response.data)

    def agents_list(
        self,
        page_size: int = 500,
        agent_list: list[str] | None = None,
        status: WazuhAgentStatus | None = None,
    ) -> Iterable[WazuhAgent]:
        """
        List all or a subset of agents.

        Arguments
        ---------
        page_size: int, optional
            Limits the amount of Wazuh agents that will be responded
            with each request.

            Default: 500
        agent_list: list[str], optional
            Optional agent id filter which ensures that the response only
            contains agents whose identifier is a member of the list.

            Default: None
        status: AgentStatus, optional
            Optional agent status filter. Accepted values:
            ["active", "pending", "never_connected", "disconnected"]

            Default: None
        """

        parameters: dict[str:any] = {}

        if status is not None:
            parameters["status"] = status

        if agent_list is not None:
            parameters["agents_list"] = ",".join(agent_list)

        return self.__connection.get_stream(
            path="/agents",
            parameters=parameters,
            page_size=page_size,
            mapping=lambda agent_dict: WazuhAgent(**agent_dict),
        )

    def agent_add(self, name: str, ip: str = None) -> WazuhAgentCredentials:
        """
        Registers a new Wazuh agent.

        Arguments
        ---------
        name: str
            Name of the new Wazuh agent.
        ip: str, optional
            Optional IP address of the new Wazuh agent.
            Not providing the IP address will instruct the Wazuh manager/worker
            to fetch the missing information automatically.

            Default: None

        Returns
        -------
        WazuhAgentCredentials
            ID and key of the new registered Wazuh agent.
        """

        parameters: dict[str:any] = {"wait_for_complete": True}

        request_payload = WazuhAgentAddRequest(name, ip).json()

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.POST,
            path="/agents",
            parameters=parameters,
            payload=request_payload,
        )

        return WazuhAgentCredentials(**response.data)

    def agent_get_active_configuration_raw(
        self,
        agent_id: str,
        component: WazuhAgentComponent,
        configuration: WazuhAgentConfiguration,
    ) -> dict[str:any]:
        """
        Request the raw configuration of a wazuh agent for a specific component.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
        component: WazuhAgentComponent
            The component the configuration will be requested for.
        configuration: WazuhAgentConfiguration
            The configuration section of the component that will be requested.

        Raises
        ------
        WazuhApiError {`http_status_code = 400`}
            The requested component configuration could not be fetched for the
            agent. This may indicate that the configuration is not present for
            the agent.

        Returns
        -------
        dict[str:any]
            The raw configuration dictionary of the components configuration section.
        """

        WazuhAgentConfigurationConstants.raise_if_configuration_is_not_available_for_component(
            component=component, configuration=configuration
        )

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return response.data

    @__raise_for_manager_id
    def agent_get_agent_anti_tampering_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentAntiTamperingConfiguration:
        """
        Request the `anti_tampering` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `agent`:`anti_tampering` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentAntiTamperingConfiguration
            The `anti_tampering` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/anti-tampering.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.AGENT
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.ANTI_TAMPERING

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentAntiTamperingConfiguration(**response.data)

    @__raise_for_manager_id
    def agent_get_agent_buffer_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentBufferConfiguration:
        """
        Request the `client_buffer` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `agent`:`buffer` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentBufferConfiguration
            The `client_buffer` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client-buffer.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.AGENT
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.BUFFER

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentBufferConfiguration(**response.data["buffer"])

    @__raise_for_manager_id
    def agent_get_agent_client_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentClientConfiguration:
        """
        Request the `client` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `agent`:`client` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentClientConfiguration
            The `client` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.AGENT
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.CLIENT

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentClientConfiguration(**response.data["client"])

    @__raise_for_manager_id
    def agent_get_agent_internal_configuration(
        self,
        agent_id: str,
    ) -> WazuhInternalConfiguration:
        """
        Request the internal configuration of a wazuh agent.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `agent`:`internal` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhInternalConfiguration
            The internal configuration of the wazuh agent.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/internal-options.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.AGENT
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.INTERNAL

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhInternalConfiguration(**response.data["internal"])

    @__raise_for_manager_id
    def agent_get_agent_labels_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentLabelsConfiguration:
        """
        Request the `labels` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `agent`:`labels` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentLabelsConfiguration
            The `labels` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/labels.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.AGENT
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.LABELS

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentLabelsConfiguration(**response.data)

    @__raise_for_manager_id
    def agent_get_com_internal_configuration(
        self,
        agent_id: str,
    ) -> WazuhInternalExecdConfiguration:
        """
        Request the `execd` configuration section of a wazuh agent's internal configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `com`:`internal` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhInternalExecdConfiguration
            The `execd` section of the wazuh agent's internal configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#execd)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.COM
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.INTERNAL

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhInternalExecdConfiguration(**response.data["internal"]["execd"])

    @__raise_for_manager_id
    def agent_get_com_logging_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentLoggingConfiguration:
        """
        Request the `logging` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `com`:`logging` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentLoggingConfiguration
            The `logging` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/logging.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.COM
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.LOGGING

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentLoggingConfiguration(**response.data["logging"])

    @__raise_for_manager_id
    def agent_get_logcollector_internal_configuration(
        self,
        agent_id: str,
    ) -> WazuhInternalLogcollectorConfiguration:
        """
        Request the `logcollector` configuration section of a wazuh agent's internal configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `logcollector`:`internal` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhInternalLogcollectorConfiguration
            The `logcollector` section of the wazuh agent's internal configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#logcollector)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.LOGCOLLECTOR
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.INTERNAL

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhInternalLogcollectorConfiguration(**response.data["internal"]["logcollector"])

    @__raise_for_manager_id
    def agent_get_logcollector_localfile_configuration(
        self,
        agent_id: str,
    ) -> list[WazuhAgentLocalfileConfiguration]:
        """
        Request the `localfile` configuration section of a wazuh agent's local configuration.

        WARNING! Use with caution. Wazuh does not escape the command and query.value fields
        which may raise a JSONDecodeError

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `logcollector`:`localfile` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentLocalfileConfiguration
            The `localfile` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/localfile.html)
        JSONDecodeError
            The wazuh API responded with malformed json.
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.LOGCOLLECTOR
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.LOCALFILE

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        localfile_configurations: list[WazuhAgentLocalfileConfiguration] = []

        raw_localfile_configs = response.data.get("localfile", [])
        for raw_localfile_config in raw_localfile_configs:
            localfile_configurations.append(
                WazuhAgentLocalfileConfiguration(**raw_localfile_config)
            )

        return localfile_configurations

    @__raise_for_manager_id
    def agent_get_logcollector_socket_configuration(
        self,
        agent_id: str,
    ) -> list[WazuhAgentSocketConfiguration]:
        """
        Request the `socket` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `logcollector`:`socket` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentSocketConfiguration
            The `socket` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/socket.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.LOGCOLLECTOR
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.SOCKET

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        socket_configurations: list[WazuhAgentSocketConfiguration] = []

        raw_socket_configs = response.data.get("socket", [])
        for raw_socket_config in raw_socket_configs:
            socket_configurations.append(WazuhAgentSocketConfiguration(**raw_socket_config))

        return socket_configurations

    @__raise_for_manager_id
    def agent_get_syscheck_internal_configuration(
        self,
        agent_id: str,
    ) -> WazuhInternalSyscheckConfiguration:
        """
        Request the `syscheck` configuration section of a wazuh agent's internal configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `syscheck`:`internal` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhInternalSyscheckConfiguration
            The `syscheck` section of the wazuh agent's internal configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#syscheck)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.SYSCHECK
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.INTERNAL

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhInternalSyscheckConfiguration(**response.data["internal"]["syscheck"])

    @__raise_for_manager_id
    def agent_get_syscheck_rootcheck_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentRootcheckConfiguration:
        """
        Request the `rootcheck` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `syscheck`:`rootcheck` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentRootcheckConfiguration
            The `rootcheck` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/rootcheck.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.SYSCHECK
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.ROOTCHECK

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentRootcheckConfiguration(**response.data["rootcheck"])

    @__raise_for_manager_id
    def agent_get_syscheck_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentSyscheckConfiguration:
        """
        Request the `syscheck` configuration section of a wazuh agent's local configuration.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `syscheck`:`syscheck` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentSyscheckConfiguration
            The `syscheck` configuration section of the wazuh agent's
            local configuration.\n
            [wazuh reference](https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html)
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.SYSCHECK
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.SYSCHECK

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentSyscheckConfiguration(**response.data["syscheck"])

    @__raise_for_manager_id
    def agent_get_wmodules_configuration(
        self,
        agent_id: str,
    ) -> WazuhAgentModules:
        """
        Request the configuration of the wmodules of a wazuh agent.

        Arguments
        ---------
        agent_id: str
            The id of the agent whose configuration will be requested.
            The id may not be "000" (manager id).

        Raises
        ------
        ValueError
            The `agent_id` argument must not be "000" (manager id).
        WazuhApiError {`http_status_code = 400`}
            The requested `wmodules`:`wmodules` configuration could not be
            fetched for the agent. This may indicate that the configuration
            is not present for the agent.

        Returns
        -------
        WazuhAgentModules
            The configuration of the various wmodules of the wazuh agent
        """

        component: WazuhAgentComponent = WazuhAgentComponentConstants.WMODULES
        configuration: WazuhAgentConfiguration = WazuhAgentConfigurationConstants.WMODULES

        path: str = f"/agents/{agent_id}/config/{component}/{configuration}"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhAgentModules(**response.data)

    # ##########################################################################################################################
    # CISCAT | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Ciscat
    #
    # - GET     /ciscat/{agent_id}/results      Get results
    # ##########################################################################################################################

    # ##########################################################################################################################
    # CLUSTER | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Cluster
    #
    # - GET     /cluster/local/info                                             Get local node info
    # - GET     /cluster/local/config                                           Get local node config
    # - GET     /cluster/nodes                                                  Get nodes info
    # - GET     /cluster/healthcheck                                            Get nodes healthcheck
    # - GET     /cluster/ruleset/synchronization                                Get cluster nodes ruleset synchronization status
    # - GET     /cluster/status                                                 Get cluster status
    # - GET     /cluster/api/config                                             Get nodes API config
    # - GET     /cluster/{node_id}/status                                       Get node status
    # - GET     /cluster/{node_id}/info                                         Get node info
    # - GET     /cluster/{node_id}/configuration                                Get node config
    # - PUT     /cluster/{node_id}/configuration                                Update node configuration
    # - GET     /cluster/{node_id}/daemons/stats                                Get Wazuh daemon stats from a cluster node
    # - GET     /cluster/{node_id}/stats                                        Get node stats
    # - GET     /cluster/{node_id}/stats/hourly                                 Get node stats hour
    # - GET     /cluster/{node_id}/stats/weekly                                 Get node stats week
    # - GET     /cluster/{node_id}/stats/analysisd                              Get node stats analysisd <<Deprecated since 4.4.x>>
    # - GET     /cluster/{node_id}/stats/remoted                                Get node stats remoted <<Deprecated since 4.4.x>>
    # - GET     /cluster/{node_id}/logs                                         Get node logs
    # - GET     /cluster/{node_id}/logs/summary                                 Get node logs summary
    # - PUT     /cluster/restart                                                Restart nodes
    # - PUT     /cluster/analysisd/reload                                       Reloads the analysisd process for the nodes
    # - GET     /cluster/configuration/validation                               Check nodes config
    # - GET     /cluster/{node_id}/configuration/{component}/{configuration}    Get node active configuration
    # ##########################################################################################################################

    # ##########################################################################################################################
    # DECODERS | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Decoders
    #
    # - GET     /decoders                       List decoders
    # - GET     /decoders/files                 Get files
    # - GET     /decoders/files/{filename}      Get decoders file content
    # - PUT     /decoders/files/{filename}      Update decoders file
    # - DELETE  /decoders/files/{filename}      Delete decoders file
    # - GET     /decoders/parents               Get parent decoders
    # ##########################################################################################################################

    # ##########################################################################################################################
    # EVENTS | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Events
    #
    # - POST    /events     Ingest events
    # ##########################################################################################################################

    # ##########################################################################################################################
    # EXPERIMENTAL | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Experimental
    #
    # - DELETE  /experimental/rootcheck                 Clear rootcheck results
    # - DELETE  /experimental/syscheck                  Clear agents FIM results
    # - GET     /experimental/ciscat/results            Get agents CIS-CAT results
    # - GET     /experimental/syscollector/hardware     Get agents hardware
    # - GET     /experimental/syscollector/netaddr      Get agents netaddr
    # - GET     /experimental/syscollector/netiface     Get agents netiface
    # - GET     /experimental/syscollector/netproto     Get agents netproto
    # - GET     /experimental/syscollector/os           Get agents OS
    # - GET     /experimental/syscollector/packages     Get agents packages
    # - GET     /experimental/syscollector/ports        Get agents ports
    # - GET     /experimental/syscollector/processes    Get agents processes
    # - GET     /experimental/syscollector/hotfixes     Get agents hotfixes
    # ##########################################################################################################################

    # ##########################################################################################################################
    # GROUPS | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Groups
    #
    # - DELETE  /groups                                 Delete groups
    # - GET     /groups                                 Get groups
    # - POST    /groups                                 Create a group
    # - GET     /groups/{group_id}/agents               Get agents in a group
    # - GET     /groups/{group_id}/configuration        Get group configuration
    # - PUT     /groups/{group_id}/configuration        Update group configuration
    # - GET     /groups/{group_id}/files                Get group files
    # - GET     /groups/{group_id}/files/{file_name}    Get a file in group
    # ##########################################################################################################################

    # ##########################################################################################################################
    # LISTS | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Lists
    #
    # - GET     /lists                      Get CDB lists info
    # - GET     /lists/files/{filename}     Get CDB list file content
    # - PUT     /lists/files/{filename}     Update CDB list file
    # - DELETE  /lists/files/{filename}     Delete CDB list file
    # - GET     /lists/files                Get CDB list files
    # ##########################################################################################################################

    # ##########################################################################################################################
    # LOGTEST | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Logtest
    #
    # - PUT     /logtest                    Run logtest
    # - DELETE  /logtest/sessions/{token}   End session
    # ##########################################################################################################################

    # ##########################################################################################################################
    # MANAGER | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Manager
    #
    # - GET     /manager/status                                     Get status
    # - GET     /manager/info                                       Get information
    # - GET     /manager/configuration                              Get configuration
    # - PUT     /manager/configuration                              Update Wazuh configuration
    # - GET     /manager/daemons/stats                              GetWazuh daemon stats
    # - GET     /manager/stats                                      Get stats
    # - GET     /manager/stats/hourly                               Get stats hour
    # - GET     /manager/stats/week                                 Get stats week
    # - GET     /manager/stats/analysisd                            Get stats analysisd
    # - GET     /manager/stats/remoted                              Get stats remoted
    # - GET     /manager/logs                                       Get logs
    # - GET     /manager/logs/summary                               Get logs summary
    # - GET     /manager/api/config                                 Get API config
    # - PUT     /manager/analysisd/reload                           Reload analysisd
    # - PUT     /manager/restart                                    Restart manager
    # - GET     /manager/configuration/validation                   Check config
    # - GET     /manager/configuration/{component}/{configuration}  Get active configuration
    # - GET     /manager/version/check                              Check available updates
    # ##########################################################################################################################

    def managers_get_status(
        self,
    ) -> list[WazuhManagerStatus]:
        """
        Fetches the status information of the wazuh managers.

        Returns
        -------
        list[WazuhManagerStatus]
            The statuses of the wazuh managers
        """

        path: str = "/manager/status"

        parameters: dict[str:any] = {"wait_for_complete": True}

        response: WazuhResponse = self.__connection.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return WazuhBulkResponse[WazuhManagerStatus, any](
            response_data=response.data,
            affected_map=lambda raw: WazuhManagerStatus(**raw),
        ).affected_items

    # ##########################################################################################################################
    # MITRE | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/MITRE
    #
    # - GET     /mitre/groups       Get MITRE groups
    # - GET     /mitre/metadata     Get MITRE metadata
    # - GET     /mitre/mitigations  Get MITRE mitigations
    # - GET     /mitre/references   Get MITRE references
    # - GET     /mitre/software     Get MITRE software
    # - GET     /mitre/tactics      Get MITRE tactics
    # - GET     /mitre/techniques   Get MITRE techniques
    # ##########################################################################################################################

    # ##########################################################################################################################
    # OVERVIEW | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Overview
    #
    # - GET     /overview/agents    Get agents overview
    # ##########################################################################################################################

    # ##########################################################################################################################
    # ROOTCHECK | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Rootcheck
    #
    # - PUT     /rootcheck              Run scan
    # - GET     /rootcheck/{agent_id}   Get results
    # - DELETE  /rootcheck/{agent_id}   Clear results
    # - GET     /rootcheck/{agent_id}   Get last scan datetime
    # ##########################################################################################################################

    # ##########################################################################################################################
    # RULES | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Rules
    #
    # - GET     /rules                              List rules
    # - GET     /rules/groups                       Get groups
    # - GET     /rules/requirement/{requirement}    Get requirements
    # - GET     /rules/files                        Get files
    # - GET     /rules/files/{filename}             Get rules file content
    # - PUT     /rules/file/{filename}              Update rules file
    # - DELETE  /rules/files/{filename}             Delete rules file
    # ##########################################################################################################################

    # ##########################################################################################################################
    # SCA | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/SCA
    #
    # - GET     /sca/{agent_id}                     Get results
    # - GET     /sca/{agent_id}/checks/{policy_id}  Get policy checks
    # ##########################################################################################################################

    # ##########################################################################################################################
    # SECURITY | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Security
    #
    # - POST    /security/user/authenticate         Login
    # - GET     /security/user/authenticate         Login <<Deprecated since 4.4.x>>
    # - DELETE  /security/user/authenticate         Logout current user
    # - POST    /security/user/authenticate/run_as  Login auth_context
    # - GET     /security/users/me                  Get current user info
    # - GET     /security/users/me/policies         Get current user processed policies
    # - PUT     /security/user/revoke               Revoke JWT tokens
    # - PUT     /security/users/{user_id}/run_as    Enable/Disable run_as
    # - GET     /security/actions                   List RBAC actions
    # - GET     /security/resources                 List RBAC resources
    # - GET     /security/users                     List users
    # - POST    /security/users                     Add user
    # - DELETE  /security/users                     Delete users
    # - PUT     /security/users/{user_id}           Update users
    # - GET     /security/roles                     List roles
    # - POST    /security/roles                     Add role
    # - DELETE  /security/roles                     Delete roles
    # - PUT     /security/roles/{role_id}           Update role
    # - GET     /security/rules                     List security rules
    # - POST    /security/rules                     Add security rule
    # - DELETE  /security/rules                     Delete security rules
    # - PUT     /security/rules/{rule_id}           Update security rule
    # - GET     /security/policies                  List policies
    # - POST    /security/policies                  Add policy
    # - DELETE  /security/policies                  Delete policies
    # - PUT     /security/policies/{policy_id}      Update policy
    # - POST    /security/users/{user_id}/roles     Add roles to user
    # - DELETE  /security/users/{user_id}/roles     Remove roles from user
    # - POST    /security/roles/{role_id}/policies  Add policies to role
    # - DELETE  /security/roles/{role_id}/policies  Remove policies from role
    # - POST    /security/roles/{role_id}/rules     Add security rules to role
    # - DELETE  /security/roles/{role_id}/rules     Remove security rules from role
    # - GET     /security/config                    GET security config
    # - PUT     /security/config                    Update security config
    # - DELETE  /security/config                    Restore default security config
    # ##########################################################################################################################

    # ##########################################################################################################################
    # SYSCHECK | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Syscheck
    #
    # - PUT     /syscheck                       Run scan
    # - GET     /syscheck/{agent_id}            Get results
    # - DELETE  /syscheck/{agent_id}            Clear results
    # - GET     /syscheck/{agent_id}/last_scan  Get last scan datetime
    # ##########################################################################################################################

    # ##########################################################################################################################
    # SYSCOLLECTOR | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Syscollector
    #
    # - GET     /syscollector/{agent_id}/hardware               Get agent hardware
    # - GET     /syscollector/{agent_id}/hotfixes               Get agent hotfixes
    # - GET     /syscollector/{agent_id}/netaddr                Get agent network address info
    # - GET     /syscollector/{agent_id}/netiface               Get agent network interface info
    # - GET     /syscollector/{agent_id}/netproto               Get agent routing configuration
    # - GET     /syscollector/{agent_id}/os                     Get agent OS
    # - GET     /syscollector/{agent_id}/packages               Get agent packages
    # - GET     /syscollector/{agent_id}/ports                  Get agent ports
    # - GET     /syscollector/{agent_id}/processes              Get agent processes
    # - GET     /syscollector/{agent_id}/users                  Get agent users
    # - GET     /syscollector/{agent_id}/groups                 Get agent groups
    # - GET     /syscollector/{agent_id}/browser_extensions     Get agent browser extensions
    # - GET     /syscollector/{agent_id}/services               Get agent services
    # ##########################################################################################################################

    # ##########################################################################################################################
    # TASK | https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Tasks
    #
    # - GET     /tasks/status       List tasks
    # ##########################################################################################################################
