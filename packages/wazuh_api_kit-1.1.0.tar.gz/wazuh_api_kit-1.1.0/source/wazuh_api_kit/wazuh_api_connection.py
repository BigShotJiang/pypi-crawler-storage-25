"""
Provides the :class:`~WazuhApiConnection` class which simplifies the
communication with the wazuh API.
"""

import datetime
import logging
import time
from base64 import b64encode
from functools import wraps
from http import HTTPMethod, HTTPStatus
from typing import Callable, Iterator
from urllib.parse import urljoin

import requests
import urllib3
from requests import Session
from wazuh_api_kit.model import (
    WazuhApiInfo,
    WazuhAuthenticationResult,
)
from wazuh_api_kit.model.response import (
    WazuhApiError,
    WazuhResponse,
)
from wazuh_api_kit.util import (
    RateLimiter,
)


class WazuhApiConnection:
    """
    This class allows to safely perform requests against the Wazuh API
    with guardrails that automatically handle the most common faults,
    such as expired authorization tokens and exceeded rate limits.
    """

    __logger: logging.Logger = logging.getLogger("WazuhApiConnection")

    __wazuh_api_base_url: str
    __wazuh_api_username: str
    __wazuh_api_password: str
    __wazuh_api_insecure: bool
    __legacy_auth: bool
    __token_ttl: int
    __rate_limiter: RateLimiter

    __session: Session | None = None
    """Session that will be used to perform requests once authenticated."""

    __api_info: WazuhApiInfo = None
    """Cached API info; Will be refreshed with every token refresh."""

    __token_creation_time: datetime = 0
    """The timestamp of the last token refresh."""

    def __init__(
        self,
        wazuh_api_url: str,
        wazuh_api_username: str,
        wazuh_api_password: str,
        wazuh_api_insecure: bool = False,
        legacy_auth: bool = False,
        token_lifetime: int = 840,
        rate_limiter: RateLimiter = None,
    ):
        """
        Arguments
        ---------
            wazuh_api_url: str
                URL of the Wazuh API the requests will be filed against.
            wazuh_api_username: str
                Username of the account that will be used to perform the
                API requests.
            wazuh_api_password: str
                Corresponding password of the account that will be used
                to perform the API requests.
            wazuh_api_insecure: bool, optional
                Defines whether the server tls certificate will be
                verified or not.

                Default: False (The server certificate will be verified)
            legacy_auth: bool
                Indicates whether the deprecated HTTP GET authentication
                endpoint should be used instead of the HTTP POST
                authentication endpoint. The HTTP POST authentication
                endpoint was introduced with the Wazuh version 4.4.x .

                Default: False
            token_lifetime: int, optional
                TTL in seconds of the authorization token. Access tokens will
                be renewed automatically.

                Default: 840 seconds
            rate_limiter: RateLimiter
                Optional RateLimiter which will limit the amount of
                requests may be made against the API in a given
                timeframe.

                Default: Will default to 12 actions per 3 Seconds
                (~240 requests per minute).

                Warning: Increasing the limit may result in errors since
                wazuh only allows 300 requests per minute. See
                [wazuh reference](https://documentation.wazuh.com/current/user-manual/api/securing-api.html#set-maximum-number-of-requests-per-minute)
                for details on how to increase the limit.
        """

        self.__wazuh_api_base_url = wazuh_api_url
        self.__wazuh_api_username = wazuh_api_username
        self.__wazuh_api_password = wazuh_api_password
        self.__wazuh_api_insecure = wazuh_api_insecure
        self.__legacy_auth = legacy_auth
        self.__token_ttl = token_lifetime

        if rate_limiter is None:
            # 12 Actions per 3 seconds -> 240 Actions per minute
            # The default configuration of wazuh allows 300 actions per minute
            # Reference:
            # https://documentation.wazuh.com/current/user-manual/api/securing-api.html#set-maximum-number-of-requests-per-minute
            rate_limiter = RateLimiter(max_actions=12, period=3, sleep_time=1)

        self.__rate_limiter = rate_limiter

        # Disable warnings when using the insecure option
        if self.__wazuh_api_insecure:
            urllib3.disable_warnings()
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # ---Decorator---
    # Reauthenticate and reattempt request on HTTP Unauthorized (401) response
    @staticmethod
    def __retry_on_unauthorized_response(request: callable) -> callable:
        """
        Decorator which intercepts an WazuhApiError once. Should the intercepted
        Exception been thrown due to an HTTP 401 UNAUTHORIZED error response,
        a refresh of the session will be triggered followed by another attempt
        to request the resource. Subsequent errors won't be intercepted.
        """

        @wraps(request)
        def reauthenticate_on_unauthorized_error(self, *args, **kwargs) -> WazuhResponse:

            try:
                return request(self, *args, **kwargs)

            except WazuhApiError as wazuh_api_error:

                if wazuh_api_error.http_status_code != HTTPStatus.UNAUTHORIZED:
                    raise wazuh_api_error

                # pylint: disable-next=protected-access
                self.__logger.warning("""
                    Unexpected HTTP 401 - UNAUTHORIZED response!
                    The session will be refreshed and a new attempt to request the resource will be performed.
                    Please check your configuration. Most likely the configured token_lifetime is to large.
                    See https://documentation.wazuh.com/current/user-manual/api/reference.html#section/Authentication
                    for more information.
                    """)

                # Attempt to get a new authorization token and issue the request again
                # pylint: disable-next=protected-access
                self.__refresh_session()
                return request(self, *args, **kwargs)

        return reauthenticate_on_unauthorized_error

    def __refresh_session_if_required(self):
        """
        Triggers a session refresh when the current authorization
        token's age exceeds the defined TTL value.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        """

        time_since_last_refresh = time.time() - self.__token_creation_time

        if time_since_last_refresh < self.__token_ttl:
            # The authorization token is still valid
            return

        self.__refresh_session()

    def __refresh_session(self):
        """
        Triggers an authentication against the Wazuh API and creates
        a configured session which will use the authorization token
        for future requests.

        Additionally the Wazuh API information will be updated to
        ensure that potential changes/upgrades will be noticed.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        """

        self.__logger.info("Refreshing the authorization token")
        auth_token = self.__authenticate()
        self.__token_creation_time = time.time()

        session = requests.Session()
        session.headers["Content-Type"] = "application/json"
        session.headers["Authorization"] = f"Bearer {auth_token}"

        session.verify = not self.__wazuh_api_insecure

        self.__session = session

        # The API endpoint may have been upgraded. Update the API info.
        # Don't use the self.request method to prevent potential infinite loops!
        self.__rate_limiter.apply()
        self.__api_info = WazuhApiInfo(
            **self.__session.get(url=urljoin(self.__wazuh_api_base_url, "/")).json()
        )

    def __authenticate(self) -> str:
        """
        Performs an authentication against the Wazuh API.

        Returns
        -------
        str
            The successfully fetched authorization token.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        """

        login_url = f"{self.__wazuh_api_base_url}/security/user/authenticate"
        basic_auth = f"{self.__wazuh_api_username}:{self.__wazuh_api_password}".encode()
        login_headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {b64encode(basic_auth).decode()}",
        }

        self.__logger.info(
            "Authenticating against %s as user '%s' ...",
            self.__wazuh_api_base_url,
            self.__wazuh_api_username,
        )

        request_method: HTTPMethod = HTTPMethod.GET if self.__legacy_auth else HTTPMethod.POST
        response: requests.Response = requests.request(
            method=request_method,
            url=login_url,
            headers=login_headers,
            verify=(not self.__wazuh_api_insecure),
            timeout=10,
        )

        if response.status_code != 200:
            raise WazuhApiError(response.status_code, **response.json())

        self.__logger.info("Authentication successful")

        wazuh_response: WazuhResponse = WazuhResponse(**response.json())
        auth_result: WazuhAuthenticationResult = WazuhAuthenticationResult(**wazuh_response.data)

        return auth_result.token

    def get_api_info(self) -> WazuhApiInfo:
        """
        Retrieves the potentially cached Wazuh API information. Alternatively it
        will trigger the authentication process which will fetch the information.

        Returns
        -------
        WazuhApiInfo
            Object representation of the received Wazuh API info.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        """

        if self.__api_info is None:
            self.__refresh_session()

        return self.__api_info

    @__retry_on_unauthorized_response
    def request(
        self,
        method: HTTPMethod,
        path: str,
        parameters: dict[str:any] = None,
        payload: str = None,
    ) -> WazuhResponse:
        """
        Allows to perform a request against the Wazuh API. It will automatically refresh the
        authorization token if required and ensure that the rate limit won't be exceeded.

        Arguments
        ---------
        method: HTTPMethod
            HTTP request method. Supported values: {GET, PUT, POST, DELETE}
        path: str
            Path to the API endpoint.
        parameters: dict[str:any], optional
            Optional request parameter dictionary. Default value: None
        parameters: str, optional
            Optional payload. Default value: None

        Returns
        -------
        WazuhResponse
            Object representation of the json response.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        HTTPError
            Non Wazuh API related exception regarding the request.
        """

        self.__rate_limiter.apply()

        self.__refresh_session_if_required()
        endpoint = urljoin(self.__wazuh_api_base_url, path)

        logging.debug(
            "Performing %s request against %s with\nParameters:\n%s\nPayload:\n%s",
            method,
            endpoint,
            parameters,
            payload,
        )

        with self.__session.request(
            method=method, url=endpoint, params=parameters, data=payload
        ) as response:

            logging.debug("Response: %s", response.content)

            if response.status_code == 200:
                return WazuhResponse(**response.json())

            raise WazuhApiError(response.status_code, **response.json())

    def get_stream[T](
        self,
        path: str,
        page_size: int = 500,
        parameters: dict[str:any] | None = None,
        mapping: Callable[[any], T] = lambda raw_value: raw_value,
    ) -> Iterator[T]:
        """

        Exhaustively stream all entries of HTTP GET API endpoints which
        respond with pages of entries. (e.g. List users: GET /security/users)

        Arguments
        ---------
        path: str
            Path to the API endpoint.
        page_size: int, optional
            Optional page size limitation. Defines the maximum number of
            entries that will be returned for each request.

            Default: 500
        parameters: dict[str:any], optional
            Optional request parameter dictionary. Default value: {}
        map: Callable[T]
            Mapping function which will be applied to every item.

            Default: lambda raw_value: raw_value
        Returns
        -------
        Iterator[T]
            Iterator of the requested entries.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        """

        offset: int = 0

        keep_requesting: bool = True
        while keep_requesting:

            page: list[dict[str:any]] = self.__get_page(
                path=path, offset=offset, page_size=page_size, parameters=parameters
            )

            for result in page:
                offset += 1
                yield mapping(result)

            if len(page) < page_size:
                # The amount of items was smaller than the defined page size.
                # Performing another request will yield an empty response.
                keep_requesting = False

    def __get_page(
        self, path: str, offset: int, page_size: int, parameters: dict[str:any] | None = None
    ) -> list[dict[str:any]]:
        """

        Retrieves a page of entries from the HTTP GET API endpoint.

        Arguments
        ---------
        path: str
            Path to the API endpoint.
        offset: int
            Offset which will skip the first n entries.
        page_size: int
            Page size limitation. Defines the maximum number of
            entries that will be returned.
        parameters: dict[str:any], optional
            Optional request parameter dictionary. Default value: {}

        Returns
        -------
        list[dict[str:any]]
            List of the requested entries.

        Raises
        ------
        WazuhApiError
            Exception which contains the error response's details.
        """

        if parameters is None:
            parameters = {}

        parameters["limit"] = page_size
        parameters["offset"] = offset
        parameters["wait_for_complete"] = True

        response: WazuhResponse = self.request(
            method=HTTPMethod.GET, path=path, parameters=parameters
        )

        return response.data["affected_items"]
