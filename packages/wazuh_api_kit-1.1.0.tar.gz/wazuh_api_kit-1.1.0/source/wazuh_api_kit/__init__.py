"""
Provides the :class:`~WazuhApiClient` and :class:`~WazuhApiConnection` class which simplify
the interaction with the Wazuh API.
"""

from wazuh_api_kit.wazuh_api_client import WazuhApiClient
from wazuh_api_kit.wazuh_api_connection import WazuhApiConnection
