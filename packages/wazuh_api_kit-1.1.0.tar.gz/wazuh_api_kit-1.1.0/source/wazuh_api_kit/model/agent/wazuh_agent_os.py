"""
Provides the :class:`WazuhAgentOS` class, which allows
to parse the `os` section of a wazuh agent response json dictionary.
"""


class WazuhAgentOS:
    """
    Object representation of an Wazuh agent's operating system information.
    """

    name: str
    """
    Name of the operating system.
    """

    codename: str
    """
    Codename of the operating system e.g. "Oracular Oriole", "Trixie", etc.
    """

    platform: str
    """
    Name of the operating system's platform.
    """

    architecture: str
    """
    The architecture of processor.
    """

    version: str
    """
    Version of the operating system.
    """

    major: str
    """
    Major version of the operating system.
    """

    minor: str
    """
    Minor version of the operating system.
    """

    kernel_information: str
    """
    Information regarding the kernel of the operating system. (uname)
    """

    def __init__(self, **kwargs):

        self.name = kwargs.get("name")
        self.codename = kwargs.get("codename")
        self.platform = kwargs.get("platform")
        self.architecture = kwargs.get("arch")
        self.version = kwargs.get("version")
        self.major = kwargs.get("major")
        self.minor = kwargs.get("minor")
        self.kernel_information = kwargs.get("uname")
