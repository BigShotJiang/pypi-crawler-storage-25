"""
Provides constants regarding an agent's status.
"""

from typing import Final, Literal

WazuhAgentStatus = Literal["active", "pending", "never_connected", "disconnected"]


class WazuhAgentStatusConstants:
    """
    Collection of wazuh Agent status constants.
    """

    ACTIVE: Final[WazuhAgentStatus] = "active"
    """
    Wazuh agent 'active' status constant.
    """

    PENDING: Final[WazuhAgentStatus] = "pending"
    """
    Wazuh agent 'pending' status constant.
    """

    NEVER_CONNECTED: Final[WazuhAgentStatus] = "never_connected"
    """
    Wazuh agent 'never_connected' status constant.
    """

    DISCONNECTED: Final[WazuhAgentStatus] = "disconnected"
    """
    Wazuh agent 'disconnected' status constant.
    """
