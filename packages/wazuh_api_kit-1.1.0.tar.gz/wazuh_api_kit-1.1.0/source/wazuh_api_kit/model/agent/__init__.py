"""
Provides constants and classes to create json request bodies and parse responses
that are linked to the Wazuh "Agents" api endpoints.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Agents
"""

from wazuh_api_kit.model.agent.wazuh_agent import WazuhAgent
from wazuh_api_kit.model.agent.wazuh_agent_add_request import WazuhAgentAddRequest
from wazuh_api_kit.model.agent.wazuh_agent_component_constants import (
    WazuhAgentComponent,
    WazuhAgentComponentConstants,
)
from wazuh_api_kit.model.agent.wazuh_agent_credentials import WazuhAgentCredentials
from wazuh_api_kit.model.agent.wazuh_agent_os import WazuhAgentOS
from wazuh_api_kit.model.agent.wazuh_agent_status_constants import (
    WazuhAgentStatus,
    WazuhAgentStatusConstants,
)
from wazuh_api_kit.model.agent.wazuh_agent_wmodules import WazuhAgentModules
