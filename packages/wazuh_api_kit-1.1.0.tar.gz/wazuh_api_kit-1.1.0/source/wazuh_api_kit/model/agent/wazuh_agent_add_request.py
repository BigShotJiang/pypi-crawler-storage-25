"""
Provides the :class:`WazuhAgentAddRequest` class, which allows
to create the json request body for the `POST /agents` api endpoint.
"""

import json


class WazuhAgentAddRequest:
    """
    Object representation of the Wazuh agent add request body.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Agents/operation/api.controllers.agent_controller.add_agent
    """

    name: str
    """
    Name of the new Wazuh agent.
    """

    ip: str
    """
    IP address of the new agent.
    """

    def __init__(self, name: str, ip: str = None):

        self.name = name
        self.ip = ip

    def json(self) -> str:
        """
        Creates a json string which is safe to use for Agent add API requests.

        Returns
        -------
        str
            Agent add request JSON body.
        """

        json_dict: dict[str:any] = {"name": self.name}

        if self.ip is not None:
            json_dict["ip"] = self.ip

        return json.dumps(json_dict)
