"""
Provides the :type:`WazuhAgentComponent` Literal type and the :class:`WazuhAgentComponentConstants` class
which defines constants regarding the components of Wazuh agents.
"""

from typing import Final, Literal

WazuhAgentComponent = Literal[
    "agent",
    "agentless",
    "analysis",
    "auth",
    "com",
    "csyslog",
    "integrator",
    "logcollector",
    "mail",
    "monitor",
    "request",
    "syscheck",
    "wazuh-db",
    "wmodules",
]


class WazuhAgentComponentConstants:
    """
    Collection of wazuh Agent component constants.
    """

    AGENT: Final[WazuhAgentComponent] = "agent"
    """
    Wazuh agent `agent` component constant.
    """

    AGENTLESS: Final[WazuhAgentComponent] = "agentless"
    """
    Wazuh agent `agentless` component constant.
    """

    ANALYSIS: Final[WazuhAgentComponent] = "analysis"
    """
    Wazuh agent `analysis` component constant.
    """

    AUTH: Final[WazuhAgentComponent] = "auth"
    """
    Wazuh agent `auth` component constant.
    """

    COM: Final[WazuhAgentComponent] = "com"
    """
    Wazuh agent `com` component constant.
    """

    CSYSLOG: Final[WazuhAgentComponent] = "csyslog"
    """
    Wazuh agent `csyslog` component constant.
    """

    INTEGRATOR: Final[WazuhAgentComponent] = "integrator"
    """
    Wazuh agent `integrator` component constant.
    """

    LOGCOLLECTOR: Final[WazuhAgentComponent] = "logcollector"
    """
    Wazuh agent `logcollector` component constant.
    """

    MAIL: Final[WazuhAgentComponent] = "mail"
    """
    Wazuh agent `mail` component constant.
    """

    MONITOR: Final[WazuhAgentComponent] = "monitor"
    """
    Wazuh agent `monitor` component constant.
    """

    REQUEST: Final[WazuhAgentComponent] = "request"
    """
    Wazuh agent `request` component constant.
    """

    SYSCHECK: Final[WazuhAgentComponent] = "syscheck"
    """
    Wazuh agent `syscheck` component constant.
    """

    WAZUH_DB: Final[WazuhAgentComponent] = "wazuh-db"
    """
    Wazuh agent `wazuh-db` component constant.
    """

    WMODULES: Final[WazuhAgentComponent] = "wmodules"
    """
    Wazuh agent `wmodules` component constant.
    """
