"""
Provides the :class:`WazuhAgentCredentials` class, which allows
to parse the `POST /agents` api endpoint's response data.
"""


class WazuhAgentCredentials:
    """
    Object representation of an Wazuh agent add response.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Agents/operation/api.controllers.agent_controller.add_agent
    """

    id: str
    """
    Id of the new agent.
    """

    key: str
    """
    Base64 encoded key of the new agent.
    """

    def __init__(self, **kwargs):

        self.id = kwargs.get("id")
        self.key = kwargs.get("key")
