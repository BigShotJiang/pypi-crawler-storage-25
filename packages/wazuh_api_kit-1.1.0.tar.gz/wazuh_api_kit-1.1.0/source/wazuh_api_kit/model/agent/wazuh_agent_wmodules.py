"""
Provides the :class:`WazuhAgentCredentials` class, which allows
to parse an agent's `wmodules:wmodules` configuration from the
`GET /agents/{agent_id}/config/{component}/{configuration}` api
endpoint's response data.
"""

from wazuh_api_kit.model.configuration.local.agent import (
    WazuhAgentFluentForwardConfiguration,
    WazuhAgentGcpBucketConfiguration,
    WazuhAgentGcpPubsubConfiguration,
    WazuhAgentGithubConfiguration,
    WazuhAgentMsGraphConfiguration,
    WazuhAgentOffice365Configuration,
    WazuhAgentScaConfiguration,
    WazuhAgentUpgradeConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle import (
    WazuhWodleAwsS3Configuration,
    WazuhWodleAzureLogsConfiguration,
    WazuhWodleCommandConfiguration,
    WazuhWodleDockerListenerConfiguration,
    WazuhWodleOsqueryConfiguration,
    WazuhWodleSyscollectorConfiguration,
)


class WazuhAgentModules:
    """
    Object representation of an Wazuh agent get active configuration response
    for the `wmodules` component and `wmodules` configuration option.
    """

    agent_upgrade_module: WazuhAgentUpgradeConfiguration | None
    fluent_forward_module: WazuhAgentFluentForwardConfiguration | None
    gcp_bucket_module: WazuhAgentGcpBucketConfiguration | None
    gcp_pubsub_module: WazuhAgentGcpPubsubConfiguration | None
    github_module: WazuhAgentGithubConfiguration | None
    ms_graph_module: WazuhAgentMsGraphConfiguration | None
    office365_module: WazuhAgentOffice365Configuration | None
    sca_module: WazuhAgentScaConfiguration | None
    aws_s3_module: WazuhWodleAwsS3Configuration | None
    azure_logs_module: WazuhWodleAzureLogsConfiguration | None
    command_module: WazuhWodleCommandConfiguration | None
    docker_listener_module: WazuhWodleDockerListenerConfiguration | None
    osquery_module: WazuhWodleOsqueryConfiguration | None
    syscollector_module: WazuhWodleSyscollectorConfiguration | None

    def __init__(self, **kwargs):

        modules: list[dict[str:any]] = kwargs.get("wmodules", [])
        for module in modules:

            module_name = list(module.keys())[0]
            module_config = module[module_name]

            match module_name:
                case "agent-upgrade":
                    self.agent_upgrade_module = WazuhAgentUpgradeConfiguration(**module_config)
                case "fluent-forward":
                    self.fluent_forward_module = WazuhAgentFluentForwardConfiguration(
                        **module_config
                    )
                case "gcp-bucket":
                    self.gcp_bucket_module = WazuhAgentGcpBucketConfiguration(**module_config)
                case "gcp-pubsub":
                    self.gcp_pubsub_module = WazuhAgentGcpPubsubConfiguration(**module_config)
                case "github":
                    self.github_module = WazuhAgentGithubConfiguration(**module_config)
                case "ms_graph":
                    self.ms_graph_module = WazuhAgentMsGraphConfiguration(**module_config)
                case "office365":
                    self.office365_module = WazuhAgentOffice365Configuration(**module_config)
                case "sca":
                    self.sca_module = WazuhAgentScaConfiguration(**module_config)
                case "aws-s3":
                    self.aws_s3_module = WazuhWodleAwsS3Configuration(**module_config)
                case "azure-logs":
                    self.azure_logs_module = WazuhWodleAzureLogsConfiguration(**module_config)
                case "command":
                    self.command_module = WazuhWodleCommandConfiguration(**module_config)
                case "docker-listener":
                    self.docker_listener_module = WazuhWodleDockerListenerConfiguration(
                        **module_config
                    )
                case "osquery":
                    self.osquery_module = WazuhWodleOsqueryConfiguration(**module_config)
                case "syscollector":
                    self.syscollector_module = WazuhWodleSyscollectorConfiguration(**module_config)
