"""
Provides the :class:`WazuhAgentCredentials` class, which allows
to parse an agent's data from the `GET /agents` api endpoint's response data.
"""

import re

from semver.version import Version
from wazuh_api_kit.model.agent.wazuh_agent_os import WazuhAgentOS


class WazuhAgent:
    """
    Object representation of an Wazuh agent's information.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Agents/operation/api.controllers.agent_controller.get_agents
    """

    id: str
    """
    The agent's ID.
    """

    name: str
    """
    Name of the agent.
    """

    version: str
    """
    Version of the agent. Format: `Wazuh v<major>.<minor>.<patch>`
    """

    status: str
    """
    Current connection status of the Agent
    """

    groups: list[str]
    """
    List of groups the agent is assigned to.
    """

    operating_system: WazuhAgentOS | None
    """
    Information about the Operating System the agent is installed on.
    """

    manager: str
    """
    Hostname of the manager the agent is responding to.
    """

    node_name: str
    """
    ID of the node the agent is reporting to.
    """

    ip: str
    """
    The agents IP address. Defaults to register_ip when the
    manager is not able to obtain the information.
    """

    register_ip: str
    """
    The agent's IP that has been used during the enrollment.
    """

    last_keep_alive: str
    """
    Date of the last received keep alive. Format: `yyyy-mm-ddThh:MM:SSZ`
    """

    registration_date: str
    """
    Date of the agent's enrollment. Format: `yyyy-mm-ddThh:MM:SSZ`
    """

    group_config_status: str
    """
    Status of the agent's groups configuration synchronization.
    Possible values: ["synced", "not synced"]
    """

    group_config_checksum: str
    """
    MD5 checksum of the agent's group configuration file (agent.conf).
    """

    group_shared_files_checksum: str
    """
    MD5 checksum of all group shared files (merged in merged.mg).
    """

    def __init__(self, **kwargs):

        self.id = kwargs.get("id")
        self.name = kwargs.get("name")
        self.version = kwargs.get("version")
        self.status = kwargs.get("status")
        self.groups = kwargs.get("group")

        if "os" in kwargs:
            self.operating_system = WazuhAgentOS(**kwargs.get("os"))

        self.manager = kwargs.get("manager")
        self.node_name = kwargs.get("node_name")

        self.ip = kwargs.get("ip")
        self.register_ip = kwargs.get("registerIP")

        self.last_keep_alive = kwargs.get("lastKeepAlive")
        self.registration_date = kwargs.get("dateAdd")

        self.group_config_status = kwargs.get("group_config_status")
        self.group_config_checksum = kwargs.get("configSum")
        self.group_shared_files_checksum = kwargs.get("mergedSum")

    def get_version(self) -> Version:
        """
        Creates a semver.Version representation of the agent's version string.

        Returns
        -------
            Semantic version representation of the agent's version.
        """

        return Version.parse(re.search(r"\d+\.\d+\.\d+", self.version).group())
