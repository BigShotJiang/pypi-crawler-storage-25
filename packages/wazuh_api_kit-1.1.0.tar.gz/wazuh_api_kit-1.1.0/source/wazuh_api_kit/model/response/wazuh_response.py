"""
Provides the :class:`WazuhResponse` class, which allows to parse
regular responses from the wazuh api.
"""


class WazuhResponse:
    """
    Default wazuh response object for successful requests.
    """

    data: dict[str:any]
    """
    The responded data.
    """

    message: str | None = None
    """
    Optional message.
    """

    error: int | None = None
    """
    Optional error message.
    """

    def __init__(self, **kwargs):

        # Non standard response; Store the dict as data
        if "data" not in kwargs:
            self.data = {**kwargs}
            return

        self.data = kwargs.get("data")

        if "message" in kwargs:
            self.message = kwargs.get("message")

        if "error" in kwargs:
            self.error = kwargs.get("error")

    def __str__(self) -> str:
        """
        Default string representation of the response.

        Returns
        -------
        str
            String representation of the WazuhResponse object.
        """

        representation = f"data:\n{self.data.__str__()}"

        if self.message is not None:
            representation += f"\nmessage: {self.message}"

        if self.error is not None:
            representation += f"\nmessage: {self.error}"

        return representation
