"""
Collection of object which may be used to parse wazuh api responses.
"""

from wazuh_api_kit.model.response.wazuh_api_error import WazuhApiError
from wazuh_api_kit.model.response.wazuh_bulk_response import WazuhBulkResponse
from wazuh_api_kit.model.response.wazuh_dapi_error import WazuhDapiError
from wazuh_api_kit.model.response.wazuh_response import WazuhResponse
