"""
Provides the :class:`WazuhBulkResponse` class, which allows to parse
bulk responses from the wazuh api.
"""

from typing import Callable, TypeVar

AffectedT = TypeVar("AffectedT")
FailedT = TypeVar("FailedT")


class WazuhBulkResponse[AffectedT, FailedT]:
    """
    Bulk response object representation.
    """

    affected_items: list[AffectedT]
    """
    List of items on which were affected.
    """

    total_affected_items: int
    """
    Amount of items which were affected.
    """

    failed_items: list[FailedT]
    """
    List of items which were not affected.
    """

    total_failed_items: int
    """
    Amount of items that were not affected.
    """

    def __init__(
        self,
        response_data: dict[str:any],
        affected_map: Callable[[any], AffectedT] = lambda raw_value: raw_value,
        failed_map: Callable[[any], FailedT] = lambda raw_value: raw_value,
    ):

        affected_items = response_data.get("affected_items", [])
        self.affected_items = [affected_map(affected_item) for affected_item in affected_items]

        self.total_affected_items = response_data.get("total_affected_items")

        failed_items = response_data.get("failed_items", [])
        self.failed_items = [failed_map(failed_item) for failed_item in failed_items]

        self.total_failed_items = response_data.get("total_failed_items")
