"""
Provides the :class:`WazuhDapiError` class, which allows to parse the
`dapi_errors` section of wazuh api error responses.
"""


class WazuhDapiError:
    """
    Dapi error object.
    """

    node: str
    """
    Name of the node.
    """

    error_message: str | None = None
    """
    Description of the issue.
    """

    logfile: str | None = None
    """
    Path to a logfile.
    """

    def __init__(self, node: str, **kwargs):

        self.node = node

        if "error" in kwargs:
            self.error_message = kwargs.get("error")

        if "logfile" in kwargs:
            self.logfile = kwargs.get("logfile")
