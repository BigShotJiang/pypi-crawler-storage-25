"""
Provides the :class:`WazuhApiError` class, which allows to parse
error responses from the wazuh api.
"""

from .wazuh_dapi_error import WazuhDapiError


class WazuhApiError(Exception):
    """
    Wazuh API related exception which indicates a problem with a request.
    The received status code and received information may be used to
    understand the underlying issue.
    """

    http_status_code: int
    """
    HTTP status code.
    """

    title: str
    """
    Title of the error.
    """

    detail: str
    """
    Error details that lead to the exception.
    """

    remediation: str | None
    """
    Optional additional information that help to resolve the issue.
    """

    error_code: int | None
    """
    Optional Wazuh error code.
    """

    dapi_errors: list[WazuhDapiError] = None
    """
    Optional list of dapi_error information.
    """

    def __init__(self, http_status_code: int, **kwargs):

        self.http_status_code = http_status_code
        self.title = kwargs.get("title")
        self.detail = kwargs.get("detail")

        error_message = f"{self.detail}"

        error_message += f"\nHTTP status code: {http_status_code}"

        if "remediation" in kwargs:
            self.remediation = kwargs.get("remediation")
            error_message += f"\nRemediation: {self.remediation}"

        if "code" in kwargs:
            self.error_code = kwargs.get("code")
            error_message += f"\nError Code: {self.error_code}"
        elif "error" in kwargs:
            self.error_code = kwargs.get("error")
            error_message += f"\nError Code: {self.error_code}"

        if "dapi_errors" in kwargs:

            error_message += "\nDapi Errors:\n"

            self.dapi_errors = []
            dapi_errors_json: dict[str:any] = kwargs.get("dapi_errors")
            for node in dapi_errors_json:
                dapi_error = WazuhDapiError(node, **dapi_errors_json[node])
                self.dapi_errors.append(dapi_error)

                if self.dapi_errors is not None:
                    error_message += f"\t{dapi_error.node}: {dapi_error.error_message}"

        super().__init__(error_message)
