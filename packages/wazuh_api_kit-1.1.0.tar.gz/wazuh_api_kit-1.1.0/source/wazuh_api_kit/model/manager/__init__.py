"""
Provides classes to parse responses that are linked to Wazuh "Manager" API endpoints.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Manager
"""

from wazuh_api_kit.model.manager.wazuh_manager_status import WazuhManagerStatus
