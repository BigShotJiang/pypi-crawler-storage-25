"""
Provides the :class:`WazuhManagerStatus` class, which allows to parse a managers's
status from the `GET /manager/status` api endpoint's response data.
"""


class WazuhManagerStatus:
    """
    Object representation of an Wazuh manager's status.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Manager/operation/api.controllers.manager_controller.get_status
    """

    is_agentlessd_running: bool
    """
    Indicates whether the agentlessd module is running or not.
    """

    is_analysisd_running: bool
    """
    Indicates whether the analysisd module is running or not.
    """

    is_authd_running: bool
    """
    Indicates whether the authd module is running or not.
    """

    is_csyslogd_running: bool
    """
    Indicates whether the csyslogd module is running or not.
    """

    is_dbd_running: bool
    """
    Indicates whether the dbd module is running or not.
    """

    is_execd_running: bool
    """
    Indicates whether the execd module is running or not.
    """

    is_integratord_running: bool
    """
    Indicates whether the integratord module is running or not.
    """

    is_logcollector_running: bool
    """
    Indicates whether the logcollector module is running or not.
    """

    is_maild_running: bool
    """
    Indicates whether the maild module is running or not.
    """

    is_monitord_running: bool
    """
    Indicates whether the monitord module is running or not.
    """

    is_remoted_running: bool
    """
    Indicates whether the remoted module is running or not.
    """

    is_reportd_running: bool
    """
    Indicates whether the reportd module is running or not.
    """

    is_syscheckd_running: bool
    """
    Indicates whether the syscheckd module is running or not.
    """

    is_apid_running: bool
    """
    Indicates whether the apid module is running or not.
    """

    is_clusterd_running: bool
    """
    Indicates whether the clusterd module is running or not.
    """

    is_db_running: bool
    """
    Indicates whether the db module is running or not.
    """

    is_modulesd_running: bool
    """
    Indicates whether the modulesd module is running or not.
    """

    def __init__(self, **kwargs):

        self.is_agentlessd_running = kwargs.get("wazuh-agentlessd") == "running"
        self.is_analysisd_running = kwargs.get("wazuh-analysisd") == "running"
        self.is_authd_running = kwargs.get("wazuh-authd") == "running"
        self.is_csyslogd_running = kwargs.get("wazuh-csyslogd") == "running"
        self.is_dbd_running = kwargs.get("wazuh-dbd") == "running"
        self.is_execd_running = kwargs.get("wazuh-execd") == "running"
        self.is_integratord_running = kwargs.get("wazuh-integratord") == "running"
        self.is_logcollector_running = kwargs.get("wazuh-logcollector") == "running"
        self.is_maild_running = kwargs.get("wazuh-maild") == "running"
        self.is_monitord_running = kwargs.get("wazuh-monitord") == "running"
        self.is_remoted_running = kwargs.get("wazuh-remoted") == "running"
        self.is_reportd_running = kwargs.get("wazuh-reportd") == "running"
        self.is_syscheckd_running = kwargs.get("wazuh-syscheckd") == "running"
        self.is_apid_running = kwargs.get("wazuh-apid") == "running"
        self.is_clusterd_running = kwargs.get("wazuh-clusterd") == "running"
        self.is_db_running = kwargs.get("wazuh-db") == "running"
        self.is_modulesd_running = kwargs.get("wazuh-modulesd") == "running"
        self.is_authd_running = kwargs.get("wazuh-authd") == "running"

    def __str__(self):
        return f"""
agentlessd: {"running" if self.is_agentlessd_running else "stopped"}
analysisd: {"running" if self.is_analysisd_running else "stopped"}
authd: {"running" if self.is_authd_running else "stopped"}
csyslogd: {"running" if self.is_csyslogd_running else "stopped"}
dbd: {"running" if self.is_dbd_running else "stopped"}
execd: {"running" if self.is_execd_running else "stopped"}
integratord: {"running" if self.is_integratord_running else "stopped"}
logcollector: {"running" if self.is_logcollector_running else "stopped"}
maild: {"running" if self.is_maild_running else "stopped"}
monitord: {"running" if self.is_monitord_running else "stopped"}
remoted: {"running" if self.is_remoted_running else "stopped"}
reportd: {"running" if self.is_reportd_running else "stopped"}
syscheckd: {"running" if self.is_syscheckd_running else "stopped"}
apid: {"running" if self.is_apid_running else "stopped"}
clusterd: {"running" if self.is_clusterd_running else "stopped"}
db: {"running" if self.is_db_running else "stopped"}
modulesd: {"running" if self.is_modulesd_running else "stopped"}
authd: {"running" if self.is_authd_running else "stopped"}
        """
