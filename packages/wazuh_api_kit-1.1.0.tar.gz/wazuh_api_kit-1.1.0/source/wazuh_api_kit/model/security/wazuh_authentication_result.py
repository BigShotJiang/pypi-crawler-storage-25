"""
Provides the :class:`WazuhAuthenticationResult` class, which allows
to parse the `/security/user/authenticate` api endpoint response data.
"""


class WazuhAuthenticationResult:
    """
    Object representation of the wazuh `/security/user/authenticate` api endpoint.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Security/operation/api.controllers.security_controller.login_user
    """

    token: str
    """
    JWT authorization token.
    """

    def __init__(self, **kwargs):

        self.token = kwargs.get("token")
