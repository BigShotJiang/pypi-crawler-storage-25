"""
Provides constants and classes to create json request bodies and parse responses
that are linked to the Wazuh "Security" api endpoints.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Security
"""

from wazuh_api_kit.model.security.wazuh_authentication_result import (
    WazuhAuthenticationResult,
)
