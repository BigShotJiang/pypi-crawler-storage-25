"""
Provides classes to parse responses that are linked to the Wazuh "API-Info" api endpoints.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/API-Info
"""

from wazuh_api_kit.model.api_info.wazuh_api_info import WazuhApiInfo
