"""
Provides the :class:`WazuhApiInfo` class, which allows
to parse the `GET /` api endpoint's response data.
"""

from semver import Version


class WazuhApiInfo:
    """
    Object representation of the wazuh `GET /` api endpoint.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/API-Info/operation/api.controllers.default_controller.default_info
    """

    title: str
    """
    API title name.
    """

    version: str
    """
    API version of the Wazuh manager. The version
    has a semantic versioning format with a ``v`` prefix:\n
    ``v<major>.<minor>.<patch>``
    """

    revision: str
    """
    API revision.
    """

    license_name: str
    """
    API license name.
    """

    license_url: str
    """
    API license url.
    """

    hostname: str
    """
    Server hostname.
    """

    timestamp: str
    """
    Timestamp of the record.
    """

    def __init__(self, **kwargs):

        self.title = kwargs.get("title")
        self.version = kwargs.get("api_version")
        self.revision = kwargs.get("revision")
        self.license_name = kwargs.get("license_name")
        self.license_url = kwargs.get("license_url")
        self.hostname = kwargs.get("hostname")
        self.timestamp = kwargs.get("timestamp")

    def get_version(self) -> Version:
        """
        Creates a semver.Version representation of
        the API's version string.

        Returns
        -------
        Version
            semver.Version representation of the API version.
        """

        return Version.parse(self.version.replace("v", ""))
