"""
Provides the :type:`WazuhAgentConfiguration` Literal type and the
:class:`WazuhAgentConfigurationConstants` which provides constants and
validation methods regarding the wazuh component's configuration
sections and their mapping.
"""

from typing import Final, Literal

from wazuh_api_kit.model.agent.wazuh_agent_component_constants import (
    WazuhAgentComponent,
    WazuhAgentComponentConstants,
)

WazuhAgentConfiguration = Literal[
    "client",
    "buffer",
    "labels",
    "internal",
    "anti_tampering",
    "agentless",
    "global",
    "active_response",
    "alerts",
    "command",
    "rules",
    "decoders",
    "auth",
    "logging",
    "reports",
    "active-response",
    "cluster",
    "csyslog",
    "integration",
    "localfile",
    "socket",
    "remote",
    "syscheck",
    "rootcheck",
    "wdb",
    "wmodules",
    "rule_test",
]


class WazuhAgentConfigurationConstants:
    """
    Collection of wazuh Agent configuration constants.
    """

    CLIENT: Final[WazuhAgentConfiguration] = "client"
    """
    Wazuh agent `client` configuration section constant.
    """

    BUFFER: Final[WazuhAgentConfiguration] = "buffer"
    """
    Wazuh agent `buffer` configuration section constant.
    """

    LABELS: Final[WazuhAgentConfiguration] = "labels"
    """
    Wazuh agent `labels` configuration section constant.
    """

    INTERNAL: Final[WazuhAgentConfiguration] = "internal"
    """
    Wazuh agent `internal` configuration section constant.
    """

    ANTI_TAMPERING: Final[WazuhAgentConfiguration] = "anti_tampering"
    """
    Wazuh agent `anti_tampering` configuration section constant.
    """

    AGENTLESS: Final[WazuhAgentConfiguration] = "agentless"
    """
    Wazuh agent `agentless` configuration section constant.
    """

    GLOBAL: Final[WazuhAgentConfiguration] = "global"
    """
    Wazuh agent `global` configuration section constant.
    """

    ACTIVE_RESPONSE: Final[WazuhAgentConfiguration] = "active_response"
    """
    Wazuh agent `active_response` configuration section constant.
    """

    ALERTS: Final[WazuhAgentConfiguration] = "alerts"
    """
    Wazuh agent `alerts` configuration section constant.
    """

    COMMAND: Final[WazuhAgentConfiguration] = "command"
    """
    Wazuh agent `command` configuration section constant.
    """

    RULES: Final[WazuhAgentConfiguration] = "rules"
    """
    Wazuh agent `rules` configuration section constant.
    """

    DECODERS: Final[WazuhAgentConfiguration] = "decoders"
    """
    Wazuh agent `decoders` configuration section constant.
    """

    AUTH: Final[WazuhAgentConfiguration] = "auth"
    """
    Wazuh agent `auth` configuration section constant.
    """

    LOGGING: Final[WazuhAgentConfiguration] = "logging"
    """
    Wazuh agent `logging` configuration section constant.
    """

    REPORTS: Final[WazuhAgentConfiguration] = "reports"
    """
    Wazuh agent `reports` configuration section constant.
    """

    ACTIVE: Final[WazuhAgentConfiguration] = "active"
    """
    Wazuh agent `active` configuration section constant.
    """

    CLUSTER: Final[WazuhAgentConfiguration] = "cluster"
    """
    Wazuh agent `cluster` configuration section constant.
    """

    CSYSLOG: Final[WazuhAgentConfiguration] = "csyslog"
    """
    Wazuh agent `csyslog` configuration section constant.
    """

    INTEGRATION: Final[WazuhAgentConfiguration] = "integration"
    """
    Wazuh agent `integration` configuration section constant.
    """

    LOCALFILE: Final[WazuhAgentConfiguration] = "localfile"
    """
    Wazuh agent `localfile` configuration section constant.
    """

    SOCKET: Final[WazuhAgentConfiguration] = "socket"
    """
    Wazuh agent `socket` configuration section constant.
    """

    REMOTE: Final[WazuhAgentConfiguration] = "remote"
    """
    Wazuh agent `remote` configuration section constant.
    """

    SYSCHECK: Final[WazuhAgentConfiguration] = "syscheck"
    """
    Wazuh agent `syscheck` configuration section constant.
    """

    ROOTCHECK: Final[WazuhAgentConfiguration] = "rootcheck"
    """
    Wazuh agent `rootcheck` configuration section constant.
    """

    WDB: Final[WazuhAgentConfiguration] = "wdb"
    """
    Wazuh agent `wdb` configuration section constant.
    """

    WMODULES: Final[WazuhAgentConfiguration] = "wmodules"
    """
    Wazuh agent `wmodules` configuration section constant.
    """

    RULE_TEST: Final[WazuhAgentConfiguration] = "rule_test"
    """
    Wazuh agent `rule_test` configuration section constant.
    """

    CONFIGURATION_MAPPING: dict[WazuhAgentComponent : list[WazuhAgentConfiguration]] = {
        WazuhAgentComponentConstants.AGENT: [
            CLIENT,
            BUFFER,
            LABELS,
            INTERNAL,
            ANTI_TAMPERING,
        ],
        WazuhAgentComponentConstants.AGENTLESS: [AGENTLESS],
        WazuhAgentComponentConstants.ANALYSIS: [
            GLOBAL,
            ACTIVE_RESPONSE,
            ALERTS,
            COMMAND,
            RULES,
            DECODERS,
            INTERNAL,
            RULE_TEST,
        ],
        WazuhAgentComponentConstants.AUTH: [AUTH],
        WazuhAgentComponentConstants.COM: [
            ACTIVE_RESPONSE,
            LOGGING,
            INTERNAL,
            CLUSTER,
        ],
        WazuhAgentComponentConstants.CSYSLOG: [CSYSLOG],
        WazuhAgentComponentConstants.INTEGRATOR: [INTEGRATION],
        WazuhAgentComponentConstants.LOGCOLLECTOR: [LOCALFILE, SOCKET, INTERNAL],
        WazuhAgentComponentConstants.MAIL: [GLOBAL, ALERTS, INTERNAL],
        WazuhAgentComponentConstants.MONITOR: [GLOBAL, INTERNAL, REPORTS],
        WazuhAgentComponentConstants.REQUEST: [GLOBAL, REMOTE, INTERNAL],
        WazuhAgentComponentConstants.SYSCHECK: [SYSCHECK, ROOTCHECK, INTERNAL],
        WazuhAgentComponentConstants.WAZUH_DB: [INTERNAL, WDB],
        WazuhAgentComponentConstants.WMODULES: [WMODULES],
    }
    """
    :type:`WazuhAgentComponent` to :type:`WazuhAgentConfiguration` mapping.
    """

    @staticmethod
    def raise_if_configuration_is_not_available_for_component(
        configuration: WazuhAgentConfiguration, component: WazuhAgentComponent
    ):
        """
        Validates a component|configuration combination and raises
        a ValueError for invalid combinations.

        Raises
        ------
        ValueError
            The passed component|configuration combination is invalid.
        """

        if not WazuhAgentConfigurationConstants.is_configuration_available_for_component(
            configuration=configuration, component=component
        ):
            raise ValueError(f"""
                The passed component|configuration combination
                '(component: {component}, configuration: {configuration})'
                does not exit.

                Valid combinations: {WazuhAgentConfigurationConstants.CONFIGURATION_MAPPING}
                """)

    @staticmethod
    def is_configuration_available_for_component(
        configuration: WazuhAgentConfiguration, component: WazuhAgentComponent
    ) -> bool:
        """
        Validates a component|configuration combination.

        Returns
        -------
        bool
            Indicates whether the passed component|configuration
            combination is valid or not.
        """

        if component not in WazuhAgentConfigurationConstants.CONFIGURATION_MAPPING:
            return False

        if configuration in WazuhAgentConfigurationConstants.CONFIGURATION_MAPPING[component]:
            return True

        return False
