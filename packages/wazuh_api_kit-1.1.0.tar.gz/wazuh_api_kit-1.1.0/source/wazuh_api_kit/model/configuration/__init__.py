"""
Collection of objects and constants which allow to parse responses that are
related to wazuh's local and internal configuration.
"""

from wazuh_api_kit.model.configuration.internal import *
from wazuh_api_kit.model.configuration.local import *
from wazuh_api_kit.model.configuration.wazuh_agent_configuration_constants import *
