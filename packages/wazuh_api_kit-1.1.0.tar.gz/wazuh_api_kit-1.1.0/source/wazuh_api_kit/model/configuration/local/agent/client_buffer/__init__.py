"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`client_buffer` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client-buffer.html
"""

from wazuh_api_kit.model.configuration.local.agent.client_buffer.wazuh_agent_buffer_configuration import (
    WazuhAgentBufferConfiguration,
)
