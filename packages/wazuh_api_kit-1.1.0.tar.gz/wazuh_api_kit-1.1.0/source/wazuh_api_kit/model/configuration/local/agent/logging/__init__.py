"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`logging` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/logging.html
"""

from wazuh_api_kit.model.configuration.local.agent.logging.wazuh_agent_logging_configuration import (
    WazuhAgentLoggingConfiguration,
)
