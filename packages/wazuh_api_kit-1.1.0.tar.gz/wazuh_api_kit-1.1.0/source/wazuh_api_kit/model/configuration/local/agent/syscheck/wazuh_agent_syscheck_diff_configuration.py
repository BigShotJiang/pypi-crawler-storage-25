"""
Provides the :class:`WazuhAgentSyscheckDiffConfiguration` which allows to parse the
`diff` subsection of the `syscheck` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_diff_disk_quota_configuration import (
    WazuhAgentSyscheckDiffDiskQuotaConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_diff_file_size_configuration import (
    WazuhAgentSyscheckDiffFileSizeConfiguration,
)


class WazuhAgentSyscheckDiffConfiguration:
    """
    Object representation of an agent's `syscheck.diff` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#diff
    """

    disk_quota: WazuhAgentSyscheckDiffDiskQuotaConfiguration | None
    """
    Disk limitation configuration.
    """

    file_size: WazuhAgentSyscheckDiffFileSizeConfiguration | None
    """
    File size limitation configuration.
    """

    def __init__(self, **kwargs):

        if "disk_quota" in kwargs:
            self.disk_quota = WazuhAgentSyscheckDiffDiskQuotaConfiguration(
                **kwargs.get("disk_quota")
            )

        if "file_size" in kwargs:
            self.file_size = WazuhAgentSyscheckDiffFileSizeConfiguration(
                **kwargs.get("file_size"),
            )
