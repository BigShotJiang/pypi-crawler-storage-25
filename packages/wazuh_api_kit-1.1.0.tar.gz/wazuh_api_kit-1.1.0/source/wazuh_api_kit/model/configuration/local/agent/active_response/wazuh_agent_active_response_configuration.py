"""
Provides the :class:`WazuhAgentActiveResponseConfiguration` which allows to parse the
`active_response` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentActiveResponseConfiguration:
    """
    Object representation of an agent's `active_response` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/active-response.html
    """

    disabled: bool
    """
    Toggles the active-response capability on and off.
    """

    repeated_offenders: list[int] | None
    """
    Sets timeouts in minutes for repeat offenders. This is a
    list of increasing timeouts that can contain a maximum
    of 5 entries.
    """

    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"

        repeated_offenders: str | None = kwargs.get("repeated_offenders")
        if repeated_offenders is not None:
            self.repeated_offenders = []
            timeouts: list[str] = repeated_offenders.split(",")

            for timeout in timeouts:
                self.repeated_offenders.append(int(timeout))
