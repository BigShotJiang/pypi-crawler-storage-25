"""
Provides the :class:`WazuhAgentFluentForwardConfiguration` which allows to parse the
`fluent-forward` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.fluent_forward.wazuh_agent_fluent_forward_keepalive_configuration import (
    WazuhAgentFluentForwardKeepaliveConfiguration,
)


class WazuhAgentFluentForwardConfiguration:
    """
    Object representation of an agent's `fluent-forward` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/fluent-forward.html
    """

    enabled: bool
    """
    Indicates whether the module is enabled or not.
    """

    tag: str | None
    """
    Tag that will be added to forwarded messages.
    """

    object_key: str | None
    """
    The key of the log object.
    """

    socket_path: str | None
    """
    Path of the UDP socket the agent is listening on.
    """

    address: str | None
    """
    Address of the Fluentd server.
    """

    port: int | None
    """
    Port of the Fluentd server.
    """

    shared_key: str | None
    """
    Authentication key for the Fluentd server.
    The presence of this value implies that the
    TLS secure mode is enabled.
    """

    ca_file: str | None
    """
    CA certificate file which will be used to
    validate the Fluentd server's identity.
    """

    user: str | None
    """
    Username which is being used to authenticate
    against the Fluentd server.
    """

    password: str | None
    """
    Password which is being used to authenticate
    against the Fluentd server.
    """

    timeout: int | None
    """
    Timeout in seconds the module enforces for
    sending and receiving when communicating
    with the Fluentd server.
    """

    poll_interval: int | None
    """
    Connection health check interval in seconds.
    """

    keepalive: WazuhAgentFluentForwardKeepaliveConfiguration | None
    """
    TCP keepalive configuration section.
    """

    def __init__(self, **kwargs):

        self.enabled = kwargs.get("enabled") == "yes"
        self.tag = kwargs.get("tag")
        self.object_key = kwargs.get("object_key")
        self.socket_path = kwargs.get("socket_path")
        self.address = kwargs.get("address")
        self.port = kwargs.get("port")
        self.shared_key = kwargs.get("shared_key")
        self.ca_file = kwargs.get("ca_file")
        self.user = kwargs.get("user")
        self.password = kwargs.get("password")
        self.timeout = kwargs.get("timeout")
        self.poll_interval = kwargs.get("poll_interval")

        if "keepalive" in kwargs:
            self.keepalive = WazuhAgentFluentForwardKeepaliveConfiguration(
                **kwargs.get("keepalive")
            )
