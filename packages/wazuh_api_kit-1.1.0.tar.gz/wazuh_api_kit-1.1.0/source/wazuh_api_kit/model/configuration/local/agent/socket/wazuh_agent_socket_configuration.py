"""
Provides the :class:`WazuhAgentSocketConfiguration` which allows to parse the
`socket` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSocketConfiguration:
    """
    Object representation of an agent's `socket` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/socket.html
    """

    name: str
    """
    Name of the socket.
    """

    location: str
    """
    Path of the socket.
    """

    mode: str
    """
    UNIX socket communication protocol (tcp or udp).
    """

    prefix: str | None
    """
    Prefix which is being applied to messages.
    """

    def __init__(self, **kwargs):

        self.name = kwargs.get("name")
        self.location = kwargs.get("location")
        self.mode = kwargs.get("mode")
        self.prefix = kwargs.get("prefix")
