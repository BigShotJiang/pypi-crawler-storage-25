"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`ms-graph` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/ms-graph-module.html
"""

from wazuh_api_kit.model.configuration.local.agent.ms_graph.wazuh_agent_ms_graph_api_auth_configuration import (
    WazuhAgentMsGraphApiAuthConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.ms_graph.wazuh_agent_ms_graph_configuration import (
    WazuhAgentMsGraphConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.ms_graph.wazuh_agent_ms_graph_resource_configuration import (
    WazuhAgentMsGraphResourceConfiguration,
)
