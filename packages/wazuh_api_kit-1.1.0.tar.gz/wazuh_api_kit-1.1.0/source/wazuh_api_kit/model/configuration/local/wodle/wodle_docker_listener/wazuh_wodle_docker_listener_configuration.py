"""
Provides the :class:`WazuhWodleDockerListenerConfiguration` which allows to parse the
`docker-listener` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhWodleDockerListenerConfiguration:
    """
    Object representation of an agent's `docker-listener` wodle configuration.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-docker.html
    """

    attempts: int | None
    """
    Maximum amount of attempts the module will perform.
    """

    disabled: bool
    """
    Indicates whether the module is disabled or not.
    """

    run_on_start: bool = True
    """
    Indicates whether the module will be executed on agent start.
    """

    interval: int | None
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    def __init__(self, **kwargs):

        self.attempts = kwargs.get("attempts")
        self.disabled = kwargs.get("disabled") == "yes"

        if "run_on_start" in kwargs:
            self.run_on_start = kwargs.get("run_on_start") == "yes"

        self.interval = kwargs.get("interval")
        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")
