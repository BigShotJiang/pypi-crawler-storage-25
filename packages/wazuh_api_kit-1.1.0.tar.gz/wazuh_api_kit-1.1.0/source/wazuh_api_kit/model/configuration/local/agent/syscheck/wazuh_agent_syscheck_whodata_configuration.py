"""
Provides the :class:`WazuhAgentSyscheckWhodataConfiguration` which allows to parse the
`whodata` subsection of the `syscheck` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckWhodataConfiguration:
    """
    Object representation of an agent's `syscheck.whodata` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#whodata
    """

    provider: str | None
    """
    The who-data provider.\n
    Possible values: ["audit", "ebpf"]
    """

    restart_audit: bool = True
    """
    Indicates whether auditd may be restarted by the agent or not.
    """

    audit_key: list[str]
    """
    List of keys which will be used to collect Audit events.
    """

    startup_healthcheck: bool = True
    """
    Indicates whether an Audit healthcheck will be performed on startup or not.
    """

    queue_size: int | None
    """
    Maximum capacity of the audit event dispatcher queue.
    """

    def __init__(self, **kwargs):

        self.provider = kwargs.get("provider")

        if "restart_audit" in kwargs:
            self.restart_audit = kwargs.get("restart_audit") == "yes"

        self.audit_key = kwargs.get("audit_key", [])

        if "startup_healthcheck" in kwargs:
            self.startup_healthcheck = kwargs.get("startup_healthcheck") == "yes"

        self.queue_size = kwargs.get("queue_size")
