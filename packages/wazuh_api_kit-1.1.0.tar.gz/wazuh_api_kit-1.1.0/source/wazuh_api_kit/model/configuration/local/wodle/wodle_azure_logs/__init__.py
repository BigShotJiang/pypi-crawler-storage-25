"""
Provides classes to parse responses that are linked to `azure-logs` module configuration section
in the Wazuh local configuration.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-azure-logs.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_azure_logs.wazuh_wodle_azure_logs_configuration import (
    WazuhWodleAzureLogsConfiguration,
)
