"""
Provides the :class:`WazuhAgentGithubConfiguration` which allows to parse the
`github` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.github.wazuh_agent_github_api_auth_configuration import (
    WazuhAgentGithubApiAuthConfiguration,
)


class WazuhAgentGithubConfiguration:
    """
    Object representation of an agent's `github` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/github-module.html
    """

    enabled: bool = True
    """
    Indicates whether the module is enabled or not.
    """

    only_future_events: bool = True
    """
    Indicates wether only future events are being collected or not.
    """

    interval: int
    """
    Frequency in seconds in which the module will be triggered.
    """

    time_delay: int
    """
    Delay in seconds the module will wait before collecting logs.
    """

    curl_max_size: int
    """
    The maximum accepted response size in bytes.
    """

    api_auth: list[WazuhAgentGithubApiAuthConfiguration]
    """
    List of credential definitions.
    """

    event_type: str | None
    """
    Event types the module collects:\n
    **web:** returns web (non-Git) events.\n
    **git:** returns Git events.\n
    **all:** returns both web and Git events.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        if "only_future_events" in kwargs:
            self.only_future_events = kwargs.get("only_future_events") == "yes"

        self.interval = kwargs.get("interval")
        self.time_delay = kwargs.get("time_delay")
        self.curl_max_size = kwargs.get("curl_max_size")

        self.api_auth = []

        api_auths = kwargs.get("api_auth", [])
        for api_auth in api_auths:
            self.api_auth.append(WazuhAgentGithubApiAuthConfiguration(**api_auth))

        self.event_type = kwargs.get("event_type")
