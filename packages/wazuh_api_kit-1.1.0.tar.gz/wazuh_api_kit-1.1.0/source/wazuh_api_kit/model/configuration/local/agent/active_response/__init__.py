"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`active_response` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/active-response.html
"""

from wazuh_api_kit.model.configuration.local.agent.active_response.wazuh_agent_active_response_configuration import (
    WazuhAgentActiveResponseConfiguration,
)
