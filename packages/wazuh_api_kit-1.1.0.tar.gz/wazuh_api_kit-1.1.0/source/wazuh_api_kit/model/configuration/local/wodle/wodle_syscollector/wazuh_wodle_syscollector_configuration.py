"""
Provides the :class:`WazuhWodleSyscollectorConfiguration` which allows to parse the
`syscollector` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_syscollector.wazuh_wodle_syscollector_synchronization_configuration import (
    WazuhWodleSyscollectorSynchronizationConfiguration,
)


class WazuhWodleSyscollectorConfiguration:
    """
    Object representation of an agent's `syscollector` wodle configuration.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-syscollector.html
    """

    disabled: bool = False
    """
    Disable the Syscollector wodle.
    """

    interval: int | None
    """
    Interval in seconds in which the system will be scanned.
    """

    scan_on_start: bool = True
    """
    Run a system scan immediately when the service is started.
    """

    hardware: bool = True
    """
    Indicates whether the hardware scans are enabled or not.
    """

    os: bool = True
    """
    Indicates whether the OS scan is enabled or not.
    """

    network: bool = True
    """
    Indicates whether the network scan is enabled or not.
    """

    packages: bool = True
    """
    Indicates whether the package scan is enabled or not.
    """

    ports: bool = True
    """
    Indicates whether the port scan is enabled or not.
    """

    processes: bool = True
    """
    Indicates whether the process scan is enabled or not.
    """

    hotfixes: bool = True
    """
    Indicates whether the hotfix scan is enabled or not.
    """

    users: bool = True
    """
    Indicates whether the user account information scan is 
    enabled or not.
    """

    groups: bool = True
    """
    Indicates whether the user account group scan is
    enabled or not.
    """

    services: bool = True
    """
    Indicates whether the service scan is enabled or not.
    """

    browser_extensions: bool = True
    """
    Indicates whether the browser extension scan is 
    enabled or not.
    """

    synchronization: WazuhWodleSyscollectorSynchronizationConfiguration | None
    """
    The database synchronization configuration.
    """

    # Justification:
    #
    # The amount of branches has been exceeded so that potentially
    # missing optional key word arguments won't be assigned to their
    # respective field. This allows the only overwrite the default
    # value of fields if the key word argument is explicitly set.
    #
    # pylint: disable-next=too-many-branches
    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"
        self.interval = kwargs.get("interval")

        if "scan_on_start" in kwargs:
            self.scan_on_start = kwargs.get("scan_on_start") == "yes"

        if "hardware" in kwargs:
            self.hardware = kwargs.get("hardware") == "yes"

        if "os" in kwargs:
            self.os = kwargs.get("os") == "yes"

        if "network" in kwargs:
            self.network = kwargs.get("network") == "yes"

        if "packages" in kwargs:
            self.packages = kwargs.get("packages") == "yes"

        if "ports" in kwargs:
            self.ports = kwargs.get("ports") == "yes"

        if "processes" in kwargs:
            self.processes = kwargs.get("processes") == "yes"

        if "hotfixes" in kwargs:
            self.hotfixes = kwargs.get("hotfixes") == "yes"

        if "users" in kwargs:
            self.users = kwargs.get("users") == "yes"

        if "groups" in kwargs:
            self.groups = kwargs.get("groups") == "yes"

        if "services" in kwargs:
            self.services = kwargs.get("services") == "yes"

        if "browser_extensions" in kwargs:
            self.browser_extensions = kwargs.get("browser_extensions") == "yes"

        if "synchronization" in kwargs:
            self.synchronization = WazuhWodleSyscollectorSynchronizationConfiguration(
                **kwargs.get("synchronization")
            )
