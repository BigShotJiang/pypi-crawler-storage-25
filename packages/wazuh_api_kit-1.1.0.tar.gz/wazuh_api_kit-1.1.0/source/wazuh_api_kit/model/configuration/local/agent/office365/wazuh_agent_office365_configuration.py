"""
Provides the :class:`WazuhAgentOffice365Configuration` which allows to parse the
`office365` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.office365.wazuh_agent_office365_api_auth_configuration import (
    WazuhAgentOffice365ApiAuthConfiguration,
)


class WazuhAgentOffice365Configuration:
    """
    Object representation of an agent's `office365` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/office365-module.html
    """

    enabled: bool = True
    """
    Enabled the Office365 wodle.
    """

    only_future_events: bool = True
    """
    Indicates wether only future events are being collected or not.
    """

    interval: int | None
    """
    The interval between Wazuh wodle executions.
    """

    curl_max_size: int | None
    """
    The maximum accepted response size in bytes.
    """

    api_auth: list[WazuhAgentOffice365ApiAuthConfiguration] | None
    """
    List of Office365 API credentials.
    """

    subscriptions: list[str] | None
    """
    List of Office365 log source subscriptions.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        if "only_future_events" in kwargs:
            self.only_future_events = kwargs.get("only_future_events") == "yes"

        self.interval = kwargs.get("interval")
        self.curl_max_size = kwargs.get("curl_max_size")

        self.api_auth = []
        authentication_configs: list[dict[str:str]] = kwargs.get("api_auth", [])
        for authentication_conf in authentication_configs:
            self.api_auth.append(WazuhAgentOffice365ApiAuthConfiguration(**authentication_conf))

        self.subscriptions = kwargs.get("subscriptions")
