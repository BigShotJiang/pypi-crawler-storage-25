"""
Provides the :class:`WazuhWodleCommandConfiguration` which allows to parse the
`command` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhWodleCommandConfiguration:
    """
    Object representation of an agent's `command` wodle configuration.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-command.html
    """

    disabled: bool
    """
    Indicates whether the module is disabled or not.
    """

    tag: str | None
    """
    Descriptive name of the command.
    """

    command: str | None
    """
    Path and arguments of the command that is being executed.
    """

    ignore_output: bool
    """
    Indicates whether the output of the command will be ignored or not.
    """

    timeout: int | None
    """
    Timeout in seconds which will abort the command execution. A value equal to 
    0 indicates that the command will run indefinitely.
    """

    verify_md5: str | None
    """
    MD5 checksum which is being compared to the binary.
    """

    verify_sha1: str | None
    """
    SHA1 checksum which is being compared to the binary.
    """

    verify_sha256: str | None
    """
    SHA256 checksum which is being compared to the binary.
    """

    skip_verification: bool
    """
    Indicates whether the verification of the checksum will be skipped or not.
    """

    run_on_start: bool = True
    """
    Indicates whether the module will be executed on agent start.
    """

    interval: int | None
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"
        self.tag = kwargs.get("tag")
        self.command = kwargs.get("command")
        self.ignore_output = kwargs.get("ignore_output") == "yes"
        self.timeout = kwargs.get("timeout")
        self.verify_md5 = kwargs.get("verify_md5")
        self.verify_sha1 = kwargs.get("verify_sha1")
        self.verify_sha256 = kwargs.get("verify_sha256")
        self.skip_verification = kwargs.get("skip_verification") == "yes"

        if "run_on_start" in kwargs:
            self.run_on_start = kwargs.get("run_on_start") == "yes"

        self.interval = kwargs.get("interval")
        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")
