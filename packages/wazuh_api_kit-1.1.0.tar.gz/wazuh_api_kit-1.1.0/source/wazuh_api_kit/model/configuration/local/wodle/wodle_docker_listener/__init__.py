"""
Provides classes to parse responses that are linked to `docker-listener` module configuration section
in the Wazuh local configuration.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-docker.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_docker_listener.wazuh_wodle_docker_listener_configuration import (
    WazuhWodleDockerListenerConfiguration,
)
