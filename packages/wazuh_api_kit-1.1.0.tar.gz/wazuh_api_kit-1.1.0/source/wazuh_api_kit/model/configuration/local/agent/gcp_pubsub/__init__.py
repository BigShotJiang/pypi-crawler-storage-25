"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`gcp-pubsub` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/gcp-pubsub.html
"""

from wazuh_api_kit.model.configuration.local.agent.gcp_pubsub.wazuh_agent_gcp_pubsub_configuration import (
    WazuhAgentGcpPubsubConfiguration,
)
