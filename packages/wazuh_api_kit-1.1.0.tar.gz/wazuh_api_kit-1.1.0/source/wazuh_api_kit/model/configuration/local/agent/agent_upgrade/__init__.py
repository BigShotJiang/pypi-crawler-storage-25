"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`agent-upgrade` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/agent-upgrade.html#agent-side
"""

from wazuh_api_kit.model.configuration.local.agent.agent_upgrade.wazuh_agent_upgrade_configuration import (
    WazuhAgentUpgradeConfiguration,
)
