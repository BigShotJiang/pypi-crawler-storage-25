"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`localfile` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/localfile.html
"""

from wazuh_api_kit.model.configuration.local.agent.localfile.wazuh_agent_localfile_configuration import (
    WazuhAgentLocalfileConfiguration,
)
