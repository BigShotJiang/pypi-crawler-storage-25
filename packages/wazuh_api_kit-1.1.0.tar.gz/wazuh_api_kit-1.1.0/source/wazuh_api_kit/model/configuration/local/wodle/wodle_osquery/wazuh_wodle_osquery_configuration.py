"""
Provides the :class:`WazuhWodleOsqueryConfiguration` which allows to parse the
`osquery` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_osquery.wazuh_wodle_osquery_pack_configuration import (
    WazuhWodleOsqueryPackConfiguration,
)


class WazuhWodleOsqueryConfiguration:
    """
    Object representation of an agent's `osquery` wodle configuration.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-osquery.html
    """

    disabled: bool
    """
    Disable the osquery wodle.
    """

    run_daemon: bool = True
    """
    Indicates whether the module's osqueryd runs as a subprocess or not.
    """

    bin_path: str | None
    """
    Absolute path to the directory containing the osqueryd executable
    """

    log_path: str | None
    """
    Absolute path to the Osquery log file.
    """

    config_path: str | None
    """
    Path to the Osquery configuration file.
    """

    add_labels: bool = True
    """
    Indicates whether the agent's labels are being added to the events.
    """

    packs: list[WazuhWodleOsqueryPackConfiguration]
    """
    List of query packs.
    """

    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"

        if "run_daemon" in kwargs:
            self.run_daemon = kwargs.get("run_daemon") == "yes"

        self.bin_path = kwargs.get("bin_path")
        self.log_path = kwargs.get("log_path")
        self.config_path = kwargs.get("config_path")

        if "add_labels" in kwargs:
            self.add_labels = kwargs.get("add_labels") == "yes"

        self.packs = []

        packs: list[dict[str:any]] = kwargs.get("packs", [])
        for pack in packs:
            self.packs.append(WazuhWodleOsqueryPackConfiguration(**pack))
