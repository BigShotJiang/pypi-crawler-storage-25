"""
Provides classes to parse responses that are linked to `syscollector` module configuration section
in the Wazuh local configuration.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-syscollector.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_syscollector.wazuh_wodle_syscollector_configuration import (
    WazuhWodleSyscollectorConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_syscollector.wazuh_wodle_syscollector_synchronization_configuration import (
    WazuhWodleSyscollectorSynchronizationConfiguration,
)
