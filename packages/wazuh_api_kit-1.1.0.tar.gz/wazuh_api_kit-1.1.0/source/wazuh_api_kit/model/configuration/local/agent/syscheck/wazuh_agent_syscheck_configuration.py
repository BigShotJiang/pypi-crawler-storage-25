"""
Provides the :class:`WazuhAgentSyscheckConfiguration` which allows to parse the
`syscheck` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_diff_configuration import (
    WazuhAgentSyscheckDiffConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_directory_configuration import (
    WazuhAgentSyscheckDirectoryConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_file_limit_configuration import (
    WazuhAgentSyscheckFileLimitConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_registry_limit_configuration import (
    WazuhAgentSyscheckRegistryLimitConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_synchronization_configuration import (
    WazuhAgentSyscheckSynchronizationConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_whodata_configuration import (
    WazuhAgentSyscheckWhodataConfiguration,
)


class WazuhAgentSyscheckConfiguration:
    """
    Object representation of an agent's `syscheck` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html
    """

    alert_new_files: bool = True
    """
    alert_new_files: bool
    Indicates whether the file integrity monitoring alerts
    the creation of new files.
    """

    allow_remote_prefilter_cmd: bool = False
    """
    Indicates whether prefilter commands are applied or not.
    """

    database: str | None
    """
    Location of the database.\n
    Possible Values: ["disk", "memory"]
    """

    file_limit: WazuhAgentSyscheckFileLimitConfiguration | None
    """
    File limitation configuration.
    """

    registry_limit: WazuhAgentSyscheckRegistryLimitConfiguration | None
    """
    Registry entry limitation configuration.
    """

    diff: WazuhAgentSyscheckDiffConfiguration | None
    """
    Diff configuration.
    """

    nodiff: list[str]
    """
    List of files that are ignored for diffs.
    """

    directories: list[WazuhAgentSyscheckDirectoryConfiguration] | None
    """
    List of directories that are being monitored.
    """

    disabled: bool = False
    """
    Indicates whether the syscheck scan ist disabled or not.
    """

    frequency: int | None
    """
    Frequency in seconds in which the syscheck is being performed.
    """

    ignore: list[str]
    """
    List of files and directories which are ignored.
    """

    ignore_sregex: list[str]
    """
    List of regular expression patterns of files and directories 
    which are ignored.
    """

    max_eps: int | None
    """
    The maximum amount of events that may be generated per second.
    """

    max_files_per_second: int | None
    """
    The maximum amount of files that may be scanned per second.
    A value equal to 0 indicates that no limitation is being applied.
    """

    prefilter_cmd: str | None
    """
    Command which is being executed bevor every file check.
    """

    process_priority: int | None
    """
    The ``nice`` value of the Syscheck process.
    """

    scan_on_start: bool = True
    """
    Indicates whether the scan will be performed on agent start.
    """

    scan_day: str | None
    """
    Day of the week on which the scan will be performed.
    """

    scan_time: str | None
    """
    Time of the day (``hh:mm``) the scan will be triggered at.
    """

    skip_dev: bool = True
    """
    Indicates whether ``/dev`` will be skipped or not.
    """

    skip_nfs: bool = True
    """
    Indicates whether network mounted filesystems will be skipped or not.
    """

    skip_proc: bool = True
    """
    Indicates whether ``/proc`` will be skipped or not.
    """

    skip_sys: bool = True
    """
    Indicates whether ``/sys`` will be skipped or not.
    """

    synchronization: WazuhAgentSyscheckSynchronizationConfiguration | None
    """
    Database synchronization configuration.
    """

    whodata: WazuhAgentSyscheckWhodataConfiguration | None
    """
    Whodata configuration.
    """

    windows_audit_interval: str | None
    """
    Frequency in seconds in which the Windows Audit Policies and SACLs of the
    whodata monitored directories are checked.
    """

    def __init__(self, **kwargs):

        if "alert_new_files" in kwargs:
            self.alert_new_files = kwargs.get("alert_new_files") == "yes"

        self.allow_remote_prefilter_cmd = kwargs.get("allow_remote_prefilter_cmd") == "yes"
        self.database = kwargs.get("database")

        if "file_limit" in kwargs:
            self.file_limit = WazuhAgentSyscheckFileLimitConfiguration(
                **kwargs.get("file_limit"),
            )

        if "registry_limit" in kwargs:
            self.registry_limit = WazuhAgentSyscheckRegistryLimitConfiguration(
                **kwargs.get("registry_limit")
            )

        if "diff" in kwargs:
            self.diff = WazuhAgentSyscheckDiffConfiguration(
                **kwargs.get("diff"),
            )

        self.nodiff = kwargs.get("nodiff", [])

        self.directories = []
        directories = kwargs.get("directories", [])
        for directory in directories:
            self.directories.append(
                WazuhAgentSyscheckDirectoryConfiguration(**directory),
            )

        self.disabled = kwargs.get("disabled") == "yes"
        self.frequency = kwargs.get("frequency")
        self.ignore = kwargs.get("ignore", [])
        self.ignore_sregex = kwargs.get("ignore_sregex", [])
        self.max_eps = kwargs.get("max_eps")
        self.max_files_per_second = kwargs.get("max_files_per_second")
        self.prefilter_cmd = kwargs.get("prefilter_cmd")
        self.process_priority = kwargs.get("process_priority")

        if "scan_on_start" in kwargs:
            self.scan_on_start = kwargs.get("scan_on_start") == "yes"

        self.scan_day = kwargs.get("scan_day")
        self.scan_time = kwargs.get("scan_time")

        if "skip_dev" in kwargs:
            self.skip_dev = kwargs.get("skip_dev") == "yes"

        if "skip_nfs" in kwargs:
            self.skip_nfs = kwargs.get("skip_nfs") == "yes"

        if "skip_proc" in kwargs:
            self.skip_proc = kwargs.get("skip_proc") == "yes"

        if "skip_sys" in kwargs:
            self.skip_sys = kwargs.get("skip_sys") == "yes"

        if "synchronization" in kwargs:
            self.synchronization = WazuhAgentSyscheckSynchronizationConfiguration(
                **kwargs.get("synchronization")
            )

        if "whodata" in kwargs:
            self.whodata = WazuhAgentSyscheckWhodataConfiguration(
                **kwargs.get("whodata"),
            )

        self.windows_audit_interval = kwargs.get("windows_audit_interval")
