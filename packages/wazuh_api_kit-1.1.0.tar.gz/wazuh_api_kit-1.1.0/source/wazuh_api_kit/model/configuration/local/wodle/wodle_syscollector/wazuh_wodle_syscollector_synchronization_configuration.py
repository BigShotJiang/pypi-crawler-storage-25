"""
Provides the :class:`WazuhWodleSyscollectorSynchronizationConfiguration` which allows to parse the
`synchronization` subsection of the `syscollector` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhWodleSyscollectorSynchronizationConfiguration:
    """
    Object representation of an agent's `syscollector` wodle
    configuration's `synchronization` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-syscollector.html#synchronization
    """

    max_eps: int | None
    """
    The maximum throughput measured in events per second.
    """

    def __init__(self, **kwargs):

        self.max_eps = kwargs.get("max_eps")
