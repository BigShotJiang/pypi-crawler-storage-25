"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`github` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/github-module.html
"""

from wazuh_api_kit.model.configuration.local.agent.github.wazuh_agent_github_api_auth_configuration import (
    WazuhAgentGithubApiAuthConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.github.wazuh_agent_github_configuration import (
    WazuhAgentGithubConfiguration,
)
