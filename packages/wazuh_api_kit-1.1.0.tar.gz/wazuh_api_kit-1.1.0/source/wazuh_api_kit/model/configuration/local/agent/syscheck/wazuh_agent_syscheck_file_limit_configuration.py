"""
Provides the :class:`WazuhAgentSyscheckFileLimitConfiguration` which allows to parse the
`file_limit` subsection of the `syscheck` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckFileLimitConfiguration:
    """
    Object representation of an agent's `syscheck.file_limit` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#file-limit
    """

    enabled: bool = True
    """
    Indicates wether the file limit is enabled or not.
    """

    entries: int | None
    """
    The maximum amount of files that may be monitored.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        self.entries = kwargs.get("entries")
