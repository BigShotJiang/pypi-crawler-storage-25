"""
Provides the :class:`~WazuhAgentLocalfileOutFormatConfiguration` which allows to parse
`out_format` configuration objects of an agent's local configuration `localfile` section.
"""


class WazuhAgentLocalfileOutFormatConfiguration:
    """
    Object representation of a localfile configuration's `out_format` configuration.
    """

    target: str
    """
    The target the output format should be applied to. E.g. "all", "custom_socket", etc.
    """
    format: str
    """
    Specifies the desired output format of logs.\n
    Possible values: ["log", "json_escaped_log", "base64_log", "output", "location",
    "command", "timestamp", "timestamp <FORMAT>", "hostname", "host_ip"]
    """

    def __init__(self, **kwargs):

        self.target = kwargs.get("target")
        self.format = kwargs.get("format")
