"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`sca` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/sca.html
"""

from wazuh_api_kit.model.configuration.local.agent.sca.wazuh_agent_sca_configuration import (
    WazuhAgentScaConfiguration,
)
