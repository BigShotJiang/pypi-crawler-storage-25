"""
Provides the :class:`WazuhAgentMsGraphApiAuthConfiguration` which allows to parse the
`api_auth` subsection of the `ms-graph` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentMsGraphApiAuthConfiguration:
    """
    Object representation of an agent's `ms-graph.api_auth` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/ms-graph-module.html#api-auth
    """

    tenant_id: str | None
    """
    Tenant ID of the App Registration.
    """

    client_id: str | None
    """
    Client ID of the App Registration.
    """

    secret_value: str | None
    """
    Secret associated with the App Registration.
    """

    api_type: str | None
    """
    Type of the Microsoft 365 subscription plan.
    global refers to either a commercial or GCC tenant.
    """

    def __init__(self, **kwargs):

        self.tenant_id = kwargs.get("tenant_id")
        self.client_id = kwargs.get("client_id")
        self.secret_value = kwargs.get("secret_value")
        self.api_type = kwargs.get("api_type")
