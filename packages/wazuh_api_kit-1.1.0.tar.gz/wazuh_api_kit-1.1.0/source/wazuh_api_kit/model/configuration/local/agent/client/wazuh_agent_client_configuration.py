"""
Provides the :class:`WazuhAgentClientConfiguration` which allows to parse the
`client` section of the Wazuh local configuration (ossec.conf).
"""

from .wazuh_agent_client_enrollment_configuration import (
    WazuhAgentClientEnrollmentConfiguration,
)
from .wazuh_agent_client_server_configuration import WazuhAgentClientServerConfiguration


class WazuhAgentClientConfiguration:
    """
    Object representation of an agent's `client` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client.html
    """

    config_profiles: list[str]
    """
    List of profiles the agent is assigned to.
    """

    notify_time: int
    """
    The frequency in seconds in which the agent contacts the
    manager to check for potential configuration updates.
    """

    reconnect_delay: int
    """
    The time in seconds the agent will wait before attempting
    a reconnection.
    """

    force_reconnect_interval: int
    """
    Interval in which the agent will be forced to reconnect to
    the manager. A value of 0 indicates that no forced
    reconnection will be performed.
    """

    ip_update_interval: int
    """
    Specifies the interval in seconds an agent will query the
    control module for its main IP address.
    """

    auto_restart_enabled: bool
    """
    Indicates whether the agent will restart automatically after
    receiving a new and valid configuration from the manager.
    """

    remote_conf_enabled: bool
    """
    Indicates whether the shared configuration will be applied
    to the agent.
    """

    crypto_method: str
    """
    The algorithm that is being utilized to encrypt the messages
    the agent sends to the manager.
    """

    server: list[WazuhAgentClientServerConfiguration]
    """
    List of connection parameters the agent uses to contact the manager.
    """

    enrollment: WazuhAgentClientEnrollmentConfiguration
    """
    The agent's enrollment configuration.
    """

    def __init__(self, **kwargs):

        config_profile: str = kwargs.get("config-profile", "")
        self.config_profiles = list[str]()
        if config_profile is not None and config_profile != "":
            self.config_profiles = list(config_profile.split(","))

        self.notify_time = kwargs.get("notify_time")
        self.reconnect_delay = kwargs.get("time-reconnect")
        self.force_reconnect_interval = kwargs.get("force_reconnect_interval")
        self.ip_update_interval = kwargs.get("ip_update_interval")

        self.auto_restart_enabled: str = kwargs.get("auto_restart") == "yes"
        self.remote_conf_enabled = kwargs.get("remote_conf") == "yes"

        self.crypto_method = kwargs.get("crypto_method")

        self.server = []
        server_list = kwargs.get("server", [])
        for server in server_list:
            self.server.append(WazuhAgentClientServerConfiguration(**server))

        if "enrollment" in kwargs:
            self.enrollment = WazuhAgentClientEnrollmentConfiguration(**kwargs.get("enrollment"))
