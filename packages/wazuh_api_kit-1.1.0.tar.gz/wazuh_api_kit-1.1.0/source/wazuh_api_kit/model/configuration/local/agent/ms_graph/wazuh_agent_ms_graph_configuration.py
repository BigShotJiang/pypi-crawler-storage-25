"""
Provides the :class:`WazuhAgentMsGraphConfiguration` which allows to parse the
`ms-graph` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.ms_graph.wazuh_agent_ms_graph_api_auth_configuration import (
    WazuhAgentMsGraphApiAuthConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.ms_graph.wazuh_agent_ms_graph_resource_configuration import (
    WazuhAgentMsGraphResourceConfiguration,
)


class WazuhAgentMsGraphConfiguration:
    """
    Object representation of an agent's `ms-graph` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/ms-graph-module.html
    """

    enabled: bool = True
    """
    Enables the Microsoft Graph module.
    """

    only_future_events: bool = True
    """
    Indicates wether only future events are being collected or not.
    """

    interval: int | None
    """
    The length of time the module will wait
    before searching for logs.
    """

    curl_max_size: int | None
    """
    The maximum accepted response size in bytes.
    """

    page_size: int | None
    """
    Maximum amount of events for individual requests.
    """

    time_delay: int | None
    """
    Delay in seconds the module will wait before collecting logs.
    """

    run_on_start: bool = True
    """
    Indicates whether the module will be executed on agent start.
    """

    version: str | None
    """
    Configured version of the Microsoft Graph API.
    """

    api_auth: WazuhAgentMsGraphApiAuthConfiguration | None
    """
    API authentication credentials configuration.
    """

    resources: list[WazuhAgentMsGraphResourceConfiguration]
    """
    List of Microsoft Graph log sources.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        if "only_future_events" in kwargs:
            self.only_future_events = kwargs.get("only_future_events") == "yes"

        self.interval = kwargs.get("interval")
        self.curl_max_size = kwargs.get("curl_max_size")
        self.page_size = kwargs.get("page_size")
        self.time_delay = kwargs.get("time_delay")

        if "run_on_start" in kwargs:
            self.run_on_start = kwargs.get("run_on_start") == "yes"

        self.version = kwargs.get("version")

        if "api_auth" in kwargs:
            self.api_auth = WazuhAgentMsGraphApiAuthConfiguration(**kwargs.get("api_auth"))

        self.resources = []
        resources: dict[str:str] = kwargs.get("resources", [])
        for resource in resources:
            self.resources.append(WazuhAgentMsGraphResourceConfiguration(**resource))
