"""
Provides classes to parse responses that are linked to `aws_s3` module configuration section
in the Wazuh local configuration.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-s3.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_aws_s3.wazuh_wodle_aws_s3_bucket_configuration import (
    WazuhWodleAwsS3BucketConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_aws_s3.wazuh_wodle_aws_s3_configuration import (
    WazuhWodleAwsS3Configuration,
)
