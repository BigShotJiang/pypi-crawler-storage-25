"""
Provides the :class:`~WazuhAgentLocalfileRegexConfiguration` which allows to parse regular
expression configuration objects of an agent's local configuration `localfile` section.
"""


class WazuhAgentLocalfileRegexConfiguration:
    """
    Object representation of a localfile configuration's regular expression configuration.

    Wazuh references:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/localfile.html#ignore
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/localfile.html#restrict
    """

    value: str | None
    """
    The regular expression.
    """

    type: str
    """
    The type of the regular expression.\n
    Possible values: ["osregex", "osmatch", "pcre2"]
    """

    def __init__(self, **kwargs):

        self.value = kwargs.get("value")
        self.type = kwargs.get("type")
