"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`client` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client.html
"""

from wazuh_api_kit.model.configuration.local.agent.client.wazuh_agent_client_configuration import (
    WazuhAgentClientConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.client.wazuh_agent_client_enrollment_configuration import (
    WazuhAgentClientEnrollmentConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.client.wazuh_agent_client_server_configuration import (
    WazuhAgentClientServerConfiguration,
)
