"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`labels` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/labels.html
"""

from wazuh_api_kit.model.configuration.local.agent.labels.wazuh_agent_label_configuration import (
    WazuhAgentLabelConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.labels.wazuh_agent_labels_configuration import (
    WazuhAgentLabelsConfiguration,
)
