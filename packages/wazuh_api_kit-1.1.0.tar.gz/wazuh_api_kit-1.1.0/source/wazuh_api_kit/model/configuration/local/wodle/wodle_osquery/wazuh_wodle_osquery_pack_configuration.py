"""
Provides the :class:`WazuhWodleOsqueryPackConfiguration` which allows to parse the
`pack` subsection of the `osquery` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhWodleOsqueryPackConfiguration:
    """
    Object representation of an agent's `osquery` wodle configuration's `pack` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-osquery.html#pack
    """

    name: str | None
    """
    Name of the pack.
    """

    path: str | None
    """
    Path to the pack configuration file.
    """

    def __init__(self, **kwargs):

        self.name = kwargs.get("name")
        self.path = kwargs.get("path")
