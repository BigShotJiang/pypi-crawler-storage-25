"""
Provides the :class:`WazuhAgentLoggingConfiguration` which allows to parse the
`logging` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentLoggingConfiguration:
    """
    Object representation of an agent's `logging` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/logging.html
    """

    plain: bool
    """
    Indicates whether logs will be written as plain text.
    (ossec.log)
    """

    json: bool
    """
    Indicates whether logs will be written in json format.
    (ossec.json)
    """

    def __init__(self, **kwargs):

        self.plain = kwargs.get("plain") == "yes"
        self.json = kwargs.get("json") == "yes"
