"""
Provides the :class:`WazuhAgentLabelsConfiguration` which allows to parse the
`localfile` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.localfile.wazuh_agent_localfile_out_format_configuration import (
    WazuhAgentLocalfileOutFormatConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.localfile.wazuh_agent_localfile_regex_configuration import (
    WazuhAgentLocalfileRegexConfiguration,
)


class WazuhAgentLocalfileConfiguration:
    """
    Object representation of an agent's `localfile` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/localfile.html
    """

    location: str | None
    """
    Specifies the log source location. may be a path, the windows event channel,
    macOS ULS or journald.
    """

    command: str | None
    """
    The command that is being executed to retrieve the events.
    """

    alias: str | None
    """
    Optional name which substitutes the command in the ossec logs.
    """

    frequency: int | None
    """
    Frequency in seconds in which the command is being executed.
    """

    only_future_events: bool = True
    """
    Indicates wether only future events are being collected or not.
    """

    query: dict[str:any] | None
    """
    Windows eventchannel or macOS ULS log query.
    """

    labels: dict[str:str] | None
    """
    Dictionary of additional JSON fields that are appended to the events.
    """

    target: list[str] | None
    """
    List of sockets the events will be written to.
    """

    log_format: str | None
    """
    Specifies the read log format.\n
    Possible values: ["apache", "audit", "command", "djb-multilog", "eventchannel",
    "eventlog", "full_command", "generic", "iis", "journald", "json", "macos",
    "multi-line", "multi-line-regex", "mysql_log", "mssql_log", "nmapg",
    "ossecalert", "postgresql_log", "snort-fast", "snort-full", "squid",
    "syslog", "syslog-pipe"]
    """

    out_format: list[WazuhAgentLocalfileOutFormatConfiguration]
    """
    List of output formats and their targets.
    """

    ignore_binaries: bool
    """
    Indicates whether binary files will be ignored or not.
    """

    age: str | None
    """
    Time span in which a file must not have been modified to be collected.\n
    Examples: `1s`, `2m` `3h`, `4d`
    """

    exclude: str | None
    """
    Pattern of log source locations that will be excluded.
    """

    reconnect_time: str | None
    """
    Time span after which the windows event channel will be queried again
    after encountering an error.\n
    Examples: `1s`, `2m` `3h`, `4d`
    """

    multiline_regex: str | None
    """
    Regular expression for the interpretation of multiple log lines as one event.
    """

    ignore: list[WazuhAgentLocalfileRegexConfiguration]
    """
    List of regular expressions which match log lines that will be ignored.
    """

    restrict: list[WazuhAgentLocalfileRegexConfiguration]
    """
    List of regular expressions which will redact specific parts of log messages.
    """

    filter: str | None
    """
    Collects journald logs selectively by filtering specific fields.
    """

    def __init__(self, **kwargs):

        self.location = kwargs.get("location")
        self.command = kwargs.get("command")
        self.alias = kwargs.get("alias")
        self.frequency = kwargs.get("frequency")

        if "only-future-events" in kwargs:
            self.only_future_events = kwargs.get("only-future-events") == "yes"

        self.query = kwargs.get("query")
        self.labels = kwargs.get("labels")
        self.target = kwargs.get("target", [])
        self.log_format = kwargs.get("logformat")

        self.out_format = []
        output_formats: list[dict[str:str]] = kwargs.get("out_format", [])
        for output_format in output_formats:
            self.out_format.append(WazuhAgentLocalfileOutFormatConfiguration(**output_format))

        self.ignore_binaries = kwargs.get("ignore_binaries") == "yes"
        self.age = kwargs.get("age")
        self.exclude = kwargs.get("exclude")
        self.reconnect_time = kwargs.get("reconnect_time")
        self.multiline_regex = kwargs.get("multiline_regex")

        self.ignore = []
        ignore_patterns: list[dict[str:str]] = kwargs.get("ignore", [])
        for ignore_pattern in ignore_patterns:
            self.ignore.append(WazuhAgentLocalfileRegexConfiguration(**ignore_pattern))

        self.restrict = []
        restrict_patterns: list[dict[str:str]] = kwargs.get("restrict", [])
        for restrict_pattern in restrict_patterns:
            self.restrict.append(WazuhAgentLocalfileRegexConfiguration(**restrict_pattern))

        self.filter = kwargs.get("filter")
