"""
Provides the :class:`WazuhAgentClientServerConfiguration` which allows to parse the
`server` subsection of the `client` section of the Wazuh local
configuration (ossec.conf).
"""


class WazuhAgentClientServerConfiguration:
    """
    Object representation of the wazuh agent's `client.server` section.

    Wazuh Reference: https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client.html#server
    """

    address: str
    """
    IP address or hostname of the Wazuh manager.
    """

    port: int
    """
    The port on which the agent sends events to the manager.
    """

    protocol: str
    """
    The protocol the agent uses when contacting the manager.
    """

    interface_index: int | None
    """
    The index by which the agent must try to connect to the
    server when setting link-local IPv6 addresses.
    """

    max_retries: int
    """
    The maximum number of connection attempts.
    """

    retry_interval: int
    """
    Interval in seconds between the connection attempts.
    """

    def __init__(self, **kwargs):

        self.address = kwargs.get("address")
        self.port = kwargs.get("port")
        self.protocol = kwargs.get("protocol")
        self.interface_index = kwargs.get("interface_index")
        self.max_retries = kwargs.get("max_retries")
        self.retry_interval = kwargs.get("retry_interval")
