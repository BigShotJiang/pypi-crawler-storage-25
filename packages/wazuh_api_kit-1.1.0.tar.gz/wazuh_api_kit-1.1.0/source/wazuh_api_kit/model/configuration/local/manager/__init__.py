"""
Collection of objects which allow to parse responses that are related to the local
configuration (ossec.conf) of a Wazuh manager.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/index.html
"""
