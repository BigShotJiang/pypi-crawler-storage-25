"""
Provides the :class:`WazuhAgentGcpBucketConfiguration` which allows to parse the
`gcp-bucket` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.gcp_bucket.wazuh_agent_gcp_bucket_bucket_configuration import (
    WazuhAgentGcpBucketBucketConfiguration,
)


class WazuhAgentGcpBucketConfiguration:
    """
    Object representation of an agent's `gcp-bucket` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/gcp-bucket.html
    """

    enabled: bool
    """
    Indicates whether the module is enabled or not.
    """

    run_on_start: bool = True
    """
    Indicates whether the module will be executed on agent start.
    """

    interval: int | None
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    buckets: list[WazuhAgentGcpBucketBucketConfiguration]
    """
    List of bucket definitions.
    """

    def __init__(self, **kwargs):

        self.enabled = kwargs.get("enabled") == "yes"

        if "run_on_start" in kwargs:
            self.run_on_start = kwargs.get("run_on_start") == "yes"
        self.interval = kwargs.get("interval")
        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")

        self.buckets = []

        buckets: list[dict[str:any]] = kwargs.get("buckets", [])

        for bucket in buckets:
            self.buckets.append(WazuhAgentGcpBucketBucketConfiguration(**bucket))
