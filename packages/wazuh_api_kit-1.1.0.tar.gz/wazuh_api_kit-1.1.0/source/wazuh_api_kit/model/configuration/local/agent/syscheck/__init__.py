"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`syscheck` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html
"""

from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_configuration import (
    WazuhAgentSyscheckConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_diff_configuration import (
    WazuhAgentSyscheckDiffConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_diff_disk_quota_configuration import (
    WazuhAgentSyscheckDiffDiskQuotaConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_diff_file_size_configuration import (
    WazuhAgentSyscheckDiffFileSizeConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_directory_configuration import (
    WazuhAgentSyscheckDirectoryConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_file_limit_configuration import (
    WazuhAgentSyscheckFileLimitConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_registry_limit_configuration import (
    WazuhAgentSyscheckRegistryLimitConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_synchronization_configuration import (
    WazuhAgentSyscheckSynchronizationConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck.wazuh_agent_syscheck_whodata_configuration import (
    WazuhAgentSyscheckWhodataConfiguration,
)
