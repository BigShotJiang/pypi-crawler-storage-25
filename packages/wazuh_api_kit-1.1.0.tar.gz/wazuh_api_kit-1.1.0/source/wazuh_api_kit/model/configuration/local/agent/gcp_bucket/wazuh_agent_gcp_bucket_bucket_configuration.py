"""
Provides the :class:`WazuhAgentGcpBucketBucketConfiguration` which allows to parse the
`bucket` subsection of the `gcp-bucket` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentGcpBucketBucketConfiguration:
    """
    Object representation of an agent's `gcp-bucket.bucket` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/gcp-bucket.html#bucket
    """

    bucket: str
    """
    Name of the Google Cloud Storage bucket from which logs are read.
    """

    credentials_file: str
    """
    Path to the Google Cloud credentials file. It can be an absolute
    path or relative to WAZUH_HOME.
    """

    type: str | None
    """
    Specifies the type of bucket.
    """

    prefix: str | None
    """
    Bucket path or prefix.
    """

    only_logs_after: str | None
    """
    Optional date in the format `YYYY-MM-DD`. Presence of this value
    implies that only logs from after the specified date will be collected.
    """

    def __init__(self, **kwargs):

        self.bucket = kwargs.get("bucket")
        self.type = kwargs.get("type")
        self.credentials_file = kwargs.get("credentials_file")
        self.prefix = kwargs.get("prefix")
        self.only_logs_after = kwargs.get("only_logs_after")
