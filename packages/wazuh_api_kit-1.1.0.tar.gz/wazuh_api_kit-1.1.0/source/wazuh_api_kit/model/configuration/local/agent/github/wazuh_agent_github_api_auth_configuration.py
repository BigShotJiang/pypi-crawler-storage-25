"""
Provides the :class:`WazuhAgentGithubApiAuthConfiguration` which allows to parse the
`api_auth` subsection of the `github` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentGithubApiAuthConfiguration:
    """
    Object representation of an agent's `github.api_auth` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/github-module.html#api-auth
    """

    org_name: str | None
    """
    Name of the organization in GitHub.
    """

    api_token: str | None
    """
    The GitHub API Access token.
    """

    def __init__(self, **kwargs):

        self.org_name = kwargs.get("org_name")
        self.api_token = kwargs.get("api_token")
