"""
Provides the :class:`WazuhAgentSyscheckDirectoryConfiguration` which allows to parse the
`directories` subsection of the `syscheck` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckDirectoryConfiguration:
    """
    Object representation of an agent's `syscheck.directories` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#directories
    """

    realtime: bool = False
    """
    Indicates whether real-time/continuous monitoring is enabled or not.
    """

    whodata: bool = False
    """
    Indicates whether the who-data monitoring is enabled or not.
    """

    report_changes: bool = False
    """
    Indicates whether (text)file changes will be reported or not.
    """

    diff_size_limit: int | None
    """
    File size cutoff in bytes on which diffs won't be performed.
    """

    check_all: bool
    """
    Indicates whether all check will be performed or not.
    """

    check_sum: bool
    """
    Indicates whether MD5, SHA-1 and SHA-256 hashes will be checked or not.
    """

    check_sha1sum: bool
    """
    Indicates whether SHA-1 hash of files will be checked or not.
    """

    check_md5sum: bool
    """
    Indicates whether the MD5 hash of files will be checked or not.
    """

    check_sha256sum: bool
    """
    Indicates whether the SHA-256 hash of files will be checked or not.
    """

    check_size: bool
    """
    Indicates whether the size of files will be checked or not.
    """

    check_owner: bool
    """
    Indicates whether the ownership of files will be checked or not.
    """

    check_group: bool
    """
    Indicates whether the group ownership of files will be checked or not.
    """

    check_perm: bool
    """
    Indicates whether the permissions of files will be checked or not.
    """

    check_attrs: bool
    """
    Indicates whether the attributes of files will be checked or not.
    """

    check_mtime: bool
    """
    Indicates whether the modification time of files will be checked.
    """

    check_inode: bool
    """
    Indicates whether the inode of files will be checked or not.
    """

    restrict: str | None
    """
    Regular expression which limits the checks to files that match.
    """

    tags: list[str]
    """
    List of tags that will added to alerts.
    """

    recursion_level: int | None
    """
    The maximum level of recursion.
    """

    follow_symbolic_link: bool = False
    """
    Indicates wether symlinks will be followed or not.
    """

    def __init__(self, **kwargs):

        self.realtime = kwargs.get("realtime") == "yes"
        self.whodata = kwargs.get("whodata") == "yes"
        self.report_changes = kwargs.get("report_changes") == "yes"
        self.diff_size_limit = kwargs.get("diff_size_limit")

        options: list[str] = kwargs.get("opts", [])

        self.check_all = "check_all" in options
        self.check_sum = "check_sum" in options
        self.check_sha1sum = "check_sha1sum" in options
        self.check_md5sum = "check_md5sum" in options
        self.check_md5sum = "check_md5sum" in options
        self.check_sha256sum = "check_sha256sum" in options
        self.check_size = "check_size" in options
        self.check_owner = "check_owner" in options
        self.check_group = "check_group" in options
        self.check_perm = "check_perm" in options
        self.check_attrs = "check_attrs" in options
        self.check_mtime = "check_mtime" in options
        self.check_inode = "check_inode" in options

        self.restrict = kwargs.get("restrict")

        tags: str = kwargs.get("tags", "")
        self.tags = list[str](tags.split(","))

        self.recursion_level = kwargs.get("recursion_level")
        self.follow_symbolic_link = kwargs.get("follow_symbolic_link") == "yes"
