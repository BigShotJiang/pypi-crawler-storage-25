"""
Provides the :class:`WazuhAgentRootcheckConfiguration` which allows to parse the
`rootcheck` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentRootcheckConfiguration:
    """
    Object representation of an agent's `rootcheck` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/rootcheck.html
    """

    base_directory: str
    """
    Base directory on which the rootcheck is being performed.
    """

    ignore: list[str]
    """
    List of files or directories that will be ignored.
    """

    ignore_sregex: list[str]
    """
    List of regular expression patterns on files or directories that will be ignored.
    """

    rootkit_files: str | None
    """
    Path to the rootkit files database file.
    """

    rootkit_trojans: str | None
    """
    Path to the rootkit trojans database file.
    """

    windows_audit: str | None
    """
    Path to the Windows audit definition file.
    """

    system_audit: str | None
    """
    Path to the audit definition file.
    """

    windows_apps: str | None
    """
    Path to the Windows application definition file.
    """

    windows_malware: str | None
    """
    Path to the Windows malware definition file.
    """

    scanall: bool = False
    """
    Indicates whether rootcheck scans the entire system or not.
    """

    readall: bool = False
    """
    Indicates whether the rootcheck will read and compare all system files.
    """

    frequency: int | None
    """
    Frequency in seconds in which the rootcheck is being performed.
    """

    disabled: bool = False
    """
    Indicates whether rootcheck is disabled for the agent or not.
    """

    check_dev: bool = True
    """
    Indicates whether `/dev` is being checked or not.
    """

    check_files: bool = True
    """
    Indicates whether files are being checked or not.
    """

    check_if: bool = True
    """
    Indicates whether network interfaces are being checked or not.
    """

    check_pids: bool = True
    """
    Indicates whether process IDs are being checked or not.
    """

    check_ports: bool = True
    """
    Indicates whether network ports are being checked or not.
    """

    check_sys: bool = True
    """
    Indicates whether anomalous file system objects are being checked or not.
    """

    check_trojans: bool = True
    """
    Indicates whether the system is being checked for trojans or not.
    """

    check_unixaudit: bool = True
    """
    Indicates whether unixaudit is being checked or not.
    """

    check_winapps: bool = True
    """
    Indicates whether winapps are being checked or not.
    """

    check_winaudit: bool = True
    """
    Indicates whether winaudit is being checked or not.
    """

    check_winmalware: bool = True
    """
    Indicates whether the system is being checked for Windows malware or not.
    """

    skip_nfs: bool = True
    """
    Indicates whether network mounted filesystems will be skipped or not.
    """

    def __init__(self, **kwargs):

        self.base_directory = kwargs.get("base_directory")
        self.ignore = kwargs.get("ignore", [])
        self.ignore_sregex = kwargs.get("ignore_sregex", [])
        self.rootkit_files = kwargs.get("rootkit_files")
        self.rootkit_trojans = kwargs.get("rootkit_trojans")
        self.windows_audit = kwargs.get("windows_audit")
        self.system_audit = kwargs.get("system_audit")
        self.windows_apps = kwargs.get("windows_apps")
        self.windows_malware = kwargs.get("windows_malware")
        self.scanall = kwargs.get("scanall") == "yes"
        self.readall = kwargs.get("readall") == "yes"
        self.frequency = kwargs.get("frequency")
        self.disabled = kwargs.get("disabled") == "yes"

        if "check_dev" in kwargs:
            self.check_dev = kwargs.get("check_dev") == "yes"

        if "check_files" in kwargs:
            self.check_files = kwargs.get("check_files") == "yes"

        if "check_if" in kwargs:
            self.check_if = kwargs.get("check_if") == "yes"

        if "check_pids" in kwargs:
            self.check_pids = kwargs.get("check_pids") == "yes"

        if "check_ports" in kwargs:
            self.check_ports = kwargs.get("check_ports") == "yes"

        if "check_sys" in kwargs:
            self.check_sys = kwargs.get("check_sys") == "yes"

        if "check_trojans" in kwargs:
            self.check_trojans = kwargs.get("check_trojans") == "yes"

        if "check_unixaudit" in kwargs:
            self.check_unixaudit = kwargs.get("check_unixaudit") == "yes"

        if "check_winapps" in kwargs:
            self.check_winapps = kwargs.get("check_winapps") == "yes"

        if "check_winaudit" in kwargs:
            self.check_winaudit = kwargs.get("check_winaudit") == "yes"

        if "check_winmalware" in kwargs:
            self.check_winmalware = kwargs.get("check_winmalware") == "yes"

        if "skip_nfs" in kwargs:
            self.skip_nfs = kwargs.get("skip_nfs") == "yes"
