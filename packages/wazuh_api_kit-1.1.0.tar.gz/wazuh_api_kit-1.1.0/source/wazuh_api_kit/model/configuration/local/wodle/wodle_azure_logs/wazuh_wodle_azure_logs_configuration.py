"""
Provides the :class:`WazuhWodleAzureLogsConfiguration` which allows to parse the
`azure-logs` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhWodleAzureLogsConfiguration:
    """
    Object representation of an agent's `azure-logs` wodle configuration.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-azure-logs.html
    """

    disabled: bool
    """
    Indicates whether the module is disabled or not.
    """

    interval: int | None
    """
    Indicates whether the module will be executed on agent start.
    """

    run_on_start: bool = True
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    timeout: int | None
    """
    Timeout for each evaluation. In case the execution takes
    longer than the specified timeout, it stops.
    """

    content: list[dict[str:any]]
    """
    List of dictionary's containing the raw configuration
    of the wazuh module. **WARNING: incomplete**
    """

    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"
        self.interval = kwargs.get("interval")

        if "run_on_start" in kwargs:
            self.run_on_start = kwargs.get("run_on_start") == "yes"

        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")
        self.timeout = kwargs.get("timeout")

        self.log_analytics = []
        self.graph = []
        self.storage = []

        # Nope Nope Nope; Won't event try to untangle this mess
        self.content = kwargs.get("content", [])
