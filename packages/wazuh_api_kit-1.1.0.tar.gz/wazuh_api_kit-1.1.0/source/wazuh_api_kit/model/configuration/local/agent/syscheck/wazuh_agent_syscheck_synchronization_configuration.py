"""
Provides the :class:`WazuhAgentSyscheckSynchronizationConfiguration` which allows to parse the
`synchronization` subsection of the `syscheck` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckSynchronizationConfiguration:
    """
    Object representation of an agent's `syscheck.synchronization` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#synchronization
    """

    enabled: bool = True
    """
    Indicates whether periodic inventory synchronizations are enabled or not.
    """

    registry_enabled: bool = True
    """
    Indicates wether the inventory synchronization is enabled for the registry or not.
    """

    interval: int | None
    """
    The initial interval in seconds in which inventory synchronizations will be performed.
    (Will be doubled with each failure until the max_interval has been reached)
    """

    max_interval: int | None
    """
    The maximum interval in seconds in which inventory synchronizations will be performed.
    """

    response_timeout: int | None
    """
    Timeout in seconds for sync messages.
    """

    queue_size: int | None
    """
    Queue size for manager synchronization responses.
    """

    thread_pool: int | None
    """
    Number of threads for the FIM database synchronization.
    """

    max_eps: int | None
    """
    Maximum throughput of synchronization messages per second.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        if "registry_enabled" in kwargs:
            self.registry_enabled = kwargs.get("registry_enabled") == "yes"

        self.interval = kwargs.get("interval")
        self.max_interval = kwargs.get("max_interval")
        self.response_timeout = kwargs.get("response_timeout")
        self.queue_size = kwargs.get("queue_size")
        self.thread_pool = kwargs.get("thread_pool")
        self.max_eps = kwargs.get("max_eps")
