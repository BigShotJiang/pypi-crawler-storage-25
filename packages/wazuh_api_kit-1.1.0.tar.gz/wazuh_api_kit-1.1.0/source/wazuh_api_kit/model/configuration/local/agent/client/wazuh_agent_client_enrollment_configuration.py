"""
Provides the :class:`WazuhAgentClientEnrollmentConfiguration` which allows to parse the
`enrollment` subsection of the `client` section of the Wazuh local
configuration (ossec.conf).
"""


class WazuhAgentClientEnrollmentConfiguration:
    """
    Object representation of the wazuh agent's
    `client.enrollment` configuration section.

    Wazuh reference:
    Wazuh Reference: https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client.html#enrollment
    """

    enabled: bool
    """
    Indicates whether the enrollment is enabled or disabled.
    """

    manager_address: str
    """
    IP address or hostname of the manager the agent enrolls on.
    """

    port: int
    """
    Port on which the agent will send the enrollment request.
    """

    interface_index: int | None
    """
    The index by which the agent will send an enrollment requests.
    """

    agent_name: str
    """
    The name the agent uses on enrollment.
    """

    groups: list[str]
    """
    Initial set of groups.
    """

    agent_address: str | None
    """
    The IP address the agent announces on enrollment.
    """

    ssl_cipher: str | None
    """
    SSL cipher override.
    """

    server_ca_path: str | None
    """
    Path to the Certificate Authority file.
    """

    agent_certificate_path: str | None
    """
    Path to the enrollment certificate file.
    """

    agent_key_path: str | None
    """
    Path to the enrollment certificate's key file.
    """

    authorization_pass_path: str | None
    """
    Path to the enrollment password file.
    """

    negotiate_tls: bool
    """
    Indicates whether TLS v1.2 (`False`) or the most secure
    common SSL/TLS method will be negotiated with the manager.
    """

    delay_after_enrollment: int
    """
    Time in seconds the agent will wait to connect after a
    successful registration.
    """

    use_source_ip: bool
    """
    Indicates whether the manager will be forced to compute
        the agent's IP address from the agent's message.
    """

    def __init__(self, **kwargs):

        self.enabled = kwargs.get("enabled") == "yes"
        self.manager_address = kwargs.get("manager_address")
        self.port = kwargs.get("port")
        self.interface_index = kwargs.get("interface_index")
        self.agent_name = kwargs.get("agent_name")

        groups: str = kwargs.get("groups", "")
        self.groups = list[str](groups.split(","))

        self.agent_address = kwargs.get("agent_address")
        self.ssl_cipher = kwargs.get("ssl_cipher")
        self.server_ca_path = kwargs.get("server_ca_path")
        self.agent_certificate_path = kwargs.get("agent_certificate_path")
        self.agent_key_path = kwargs.get("agent_key_path")
        self.authorization_pass_path = kwargs.get("authorization_pass_path")
        self.negotiate_tls = kwargs.get("auto_method") == "yes"
        self.delay_after_enrollment = kwargs.get("delay_after_enrollment")
        self.use_source_ip = kwargs.get("use_source_ip") == "yes"
