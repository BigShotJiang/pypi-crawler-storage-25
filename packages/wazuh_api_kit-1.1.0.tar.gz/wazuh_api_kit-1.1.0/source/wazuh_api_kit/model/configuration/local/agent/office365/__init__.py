"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`office365` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/office365-module.html
"""

from wazuh_api_kit.model.configuration.local.agent.office365.wazuh_agent_office365_api_auth_configuration import (
    WazuhAgentOffice365ApiAuthConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.office365.wazuh_agent_office365_configuration import (
    WazuhAgentOffice365Configuration,
)
