"""
Provides the :class:`WazuhAgentMsGraphResourceConfiguration` which allows to parse the
`resource` subsection of the `ms-graph` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentMsGraphResourceConfiguration:
    """
    Object representation of an agent's `ms-graph.resource` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/ms-graph-module.html#resource-name
    """

    name: str | None
    """
    Name of the Microsoft Graph resource.
    """

    relationship: str | None
    """
    Relationship content type from which the logs are being obtained.
    """

    def __init__(self, **kwargs):

        # TODO: Create Issue; The json response does not contain the name value
        self.name = kwargs.get("name")
        self.relationship = kwargs.get("relationship")
