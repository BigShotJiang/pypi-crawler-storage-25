"""
Provides the :class:`WazuhAgentAntiTamperingConfiguration` which allows to parse the
`anti_tampering` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentAntiTamperingConfiguration:
    """
    Object representation of an agent's `anti_tampering` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/anti-tampering.html
    """

    package_uninstallation: bool
    """
    Indicates whether the validation requirement for a user to uninstall the
    agent is enabled or not.
    """

    def __init__(self, **kwargs):

        self.package_uninstallation = False

        # WTF?
        package_uninstallation_list: list[str] | None = kwargs.get("package_uninstallation")
        if package_uninstallation_list is not None and len(package_uninstallation_list) > 0:
            self.package_uninstallation = package_uninstallation_list[0] == "yes"
