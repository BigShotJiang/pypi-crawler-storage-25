"""
Provides the :class:`WazuhAgentLabelsConfiguration` which allows to parse the
`labels` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.agent.labels.wazuh_agent_label_configuration import (
    WazuhAgentLabelConfiguration,
)


class WazuhAgentLabelsConfiguration:
    """
    Object representation of an agent's `labels` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/labels.html
    """

    labels: list[WazuhAgentLabelConfiguration]
    """
    List of the user-defined labels that are assigned to the agent.
    """

    def __init__(self, **kwargs):

        self.labels = []

        for label in kwargs.get("labels", []):
            self.labels.append(WazuhAgentLabelConfiguration(**label))
