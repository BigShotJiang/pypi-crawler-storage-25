"""
Provides classes to parse responses that are linked to `osquery` module configuration section
in the Wazuh local configuration.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-osquery.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_osquery.wazuh_wodle_osquery_configuration import (
    WazuhWodleOsqueryConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_osquery.wazuh_wodle_osquery_pack_configuration import (
    WazuhWodleOsqueryPackConfiguration,
)
