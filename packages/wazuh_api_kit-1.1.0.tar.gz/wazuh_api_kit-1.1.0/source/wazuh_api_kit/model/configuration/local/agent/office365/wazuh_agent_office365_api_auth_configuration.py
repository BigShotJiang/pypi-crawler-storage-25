"""
Provides the :class:`WazuhAgentOffice365ApiAuthConfiguration` which allows to parse the
`auth_config` subsection of the `office365` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentOffice365ApiAuthConfiguration:
    """
    Object representation of an agent's `office365.auth_config` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/office365-module.html#api-auth
    """

    tenant_id: str | None
    """
    Azure tenant id.
    """

    client_id: str | None
    """
    Azure App Registration id.
    """

    client_secret_path: str | None
    """
    Path of the client secret file.
    """

    client_secret: str | None
    """
    Client secret value.
    """

    api_type: str | None
    """
    The configured Microsoft 365 subscription plan type.
    """

    def __init__(self, **kwargs):

        self.tenant_id = kwargs.get("tenant_id")
        self.client_id = kwargs.get("client_id")
        self.client_secret_path = kwargs.get("client_secret_path")
        self.client_secret = kwargs.get("client_secret")
        self.api_type = kwargs.get("api_type")
