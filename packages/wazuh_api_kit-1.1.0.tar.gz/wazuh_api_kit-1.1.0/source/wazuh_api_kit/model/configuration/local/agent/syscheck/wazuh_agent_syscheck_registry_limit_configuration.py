"""
Provides the :class:`WazuhAgentSyscheckRegistryLimitConfiguration` which allows to parse the
`registry_limit` subsection of the `syscheck` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckRegistryLimitConfiguration:
    """
    Object representation of an agent's `syscheck.registry_limit` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#registry-limit
    """

    enabled: bool = True
    """
    Indicates wether the registry limit is enabled or not.
    """

    entries: int | None
    """
    The maximum number of registry entries that may be monitored.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        self.entries = kwargs.get("entries")
