"""
Provides the :class:`WazuhAgentGcpPubsubConfiguration` which allows to parse the
`gcp-pubsub` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentGcpPubsubConfiguration:
    """
    Object representation of an agent's `gcp-pubsub` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/gcp-pubsub.html
    """

    enabled: bool
    """
    Indicates whether the module is enabled or not.
    """

    project_id: str | None
    """
    Google Cloud project ID.
    """

    subscription_name: str | None
    """
    Name of the subscription.
    """

    credentials_file: str | None
    """
    Path to the Google Cloud credentials file. Absolute or
    relative to WAZUH_HOME.
    """

    max_messages: int | None
    """
    Maximum number of messages pulled in each iteration.
    """

    num_threads: int | None
    """
    Number of threads that pull logs in each iteration.
    """

    pull_on_start: bool = True
    """
    Indicates whether logs will be pulled on Wazuh agent start.
    """

    interval: int | None
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    def __init__(self, **kwargs):

        self.enabled = kwargs.get("enabled") == "yes"

        self.project_id = kwargs.get("project_id")
        self.subscription_name = kwargs.get("subscription_name")
        self.credentials_file = kwargs.get("credentials_file")
        self.max_messages = kwargs.get("max_messages")
        self.num_threads = kwargs.get("num_threads")

        if "pull_on_start" in kwargs:
            self.pull_on_start = kwargs.get("pull_on_start") == "yes"

        self.interval = kwargs.get("interval")
        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")
