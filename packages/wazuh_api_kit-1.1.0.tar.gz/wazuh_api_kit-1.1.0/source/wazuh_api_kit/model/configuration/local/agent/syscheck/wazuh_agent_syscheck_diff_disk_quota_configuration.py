"""
Provides the :class:`WazuhAgentSyscheckDiffDiskQuotaConfiguration` which allows to parse the
`disk-quota` subsection of the `syscheck.diff` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckDiffDiskQuotaConfiguration:
    """
    Object representation of an agent's `syscheck.diff.disk-quota` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#disk-quota
    """

    enabled: bool = True
    """
    Indicates whether the disk quota limitation is enabled or not.
    """

    limit: int | None
    """
    The size limit in bytes for the `queue/diff/local` directory.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        self.limit = kwargs.get("limit")
