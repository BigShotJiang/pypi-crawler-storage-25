"""
Provides the :class:`WazuhWodleAwsS3Configuration` which allows to parse the
`aws-s3` section of the Wazuh local configuration (ossec.conf).
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_aws_s3.wazuh_wodle_aws_s3_bucket_configuration import (
    WazuhWodleAwsS3BucketConfiguration,
)


class WazuhWodleAwsS3Configuration:
    """
    Object representation of an agent's `aws-s3` wodle configuration.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-s3.html
    """

    disabled: bool
    """
    Indicates whether the module is disabled or not.
    """

    skip_on_error: bool = True
    """
    When unable to process and parse a log, skip it and continue processing.
    If set to no, the module will abort the execution once it encounters an error.
    """

    run_on_start: bool = True
    """
    Indicates whether the module will be executed on agent start.
    """

    interval: int | None
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    buckets: list[WazuhWodleAwsS3BucketConfiguration]
    """
    List of asw bucket definitions.
    """

    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"

        if "skip_on_error" in kwargs:
            self.skip_on_error = kwargs.get("skip_on_error") == "yes"

        if "run_on_start" in kwargs:
            self.run_on_start = kwargs.get("run_on_start") == "yes"

        self.interval = kwargs.get("interval")
        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")

        buckets: list[dict[str:any]] = kwargs.get("buckets", [])

        self.buckets = []
        for bucket in buckets:
            self.buckets.append(WazuhWodleAwsS3BucketConfiguration(**bucket))
