"""
Collection of objects which allow to parse responses that are related to the local
configuration (ossec.conf) of wazuh agents, managers and their wmodules.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/index.html
"""

from wazuh_api_kit.model.configuration.local.agent import *
from wazuh_api_kit.model.configuration.local.manager import *
from wazuh_api_kit.model.configuration.local.wodle import *
