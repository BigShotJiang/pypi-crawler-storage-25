"""
Provides the :class:`WazuhAgentUpgradeConfiguration` which allows to parse the
`agent-upgrade` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentUpgradeConfiguration:
    """
    Object representation of an agent's `agent-upgrade` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/agent-upgrade.html#agent-side
    """

    enabled: bool = True
    """
    Indicates whether agent upgrades are enabled or not.
    """

    notification_wait_start: str | None
    """
    Initial time that the agent will wait to retry sending the
    upgrade confirmation if the first attempt remains unanswered.
    Can use second, minute and hour format.
    """

    notification_wait_factor: float | None
    """
    Time increase factor between successive notifications.
    """

    notification_wait_max: str | None
    """
    Maximum time allowed between successive notifications.
    Can use second, minute and hour format.
    """

    ca_verification: bool = True
    """
    Indicates whether the signature of incoming WPK upgrade packages
    will be verified or not.
    """

    ca_store: list[str]
    """
    List of paths to CA certificates. CA certificates are required
    for the verification of a WPK package's signature.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        self.notification_wait_start = kwargs.get("notification_wait_start")
        self.notification_wait_factor = kwargs.get("notification_wait_factor")
        self.notification_wait_max = kwargs.get("notification_wait_max")

        if "ca_verification" in kwargs:
            self.ca_verification = kwargs.get("ca_verification") == "yes"

        self.ca_store = kwargs.get("ca_store", [])
