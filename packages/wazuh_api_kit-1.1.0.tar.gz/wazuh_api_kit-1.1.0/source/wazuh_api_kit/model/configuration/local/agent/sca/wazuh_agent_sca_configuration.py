"""
Provides the :class:`WazuhAgentScaConfiguration` which allows to parse the
`sca` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentScaConfiguration:
    """
    Object representation of an agent's `sca` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/sca.html
    """

    enabled: bool = True
    """
    Indicates whether the module is enabled or not.
    """

    skip_nfs: bool = True
    """
    Indicates whether network mounted files will be scanned or not.
    """

    policies: list[str]
    """
    List of paths to policy files.
    """

    scan_on_start: bool = True
    """
    Indicates whether the module will be executed on agent start.
    """

    interval: int | None
    """
    Frequency in seconds in which the module will be triggered.
    """

    day: int | None
    """
    Day of the month the module will be triggered at.
    """

    wday: str | None
    """
    Day of the week the module will be triggered at.
    """

    time: str | None
    """
    Time of the day (``hh:mm``) the module will be triggered at.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        if "skip_nfs" in kwargs:
            self.skip_nfs = kwargs.get("skip_nfs") == "yes"

        self.policies = kwargs.get("policies", [])

        if "scan_on_start" in kwargs:
            self.scan_on_start = kwargs.get("scan_on_start") == "yes"

        self.interval = kwargs.get("interval")
        self.day = kwargs.get("day")
        self.wday = kwargs.get("wday")
        self.time = kwargs.get("time")
