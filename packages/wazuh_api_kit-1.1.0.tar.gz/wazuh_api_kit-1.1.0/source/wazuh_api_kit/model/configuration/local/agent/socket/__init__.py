"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`socket` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/socket.html
"""

from wazuh_api_kit.model.configuration.local.agent.socket.wazuh_agent_socket_configuration import (
    WazuhAgentSocketConfiguration,
)
