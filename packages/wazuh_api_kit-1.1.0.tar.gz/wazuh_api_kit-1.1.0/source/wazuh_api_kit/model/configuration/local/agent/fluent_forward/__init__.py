"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`fluent-forward` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/fluent-forward.html
"""

from wazuh_api_kit.model.configuration.local.agent.fluent_forward.wazuh_agent_fluent_forward_configuration import (
    WazuhAgentFluentForwardConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.fluent_forward.wazuh_agent_fluent_forward_keepalive_configuration import (
    WazuhAgentFluentForwardKeepaliveConfiguration,
)
