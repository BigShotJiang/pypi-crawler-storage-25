"""
Provides classes to parse responses that are linked to `command` module configuration section
in the Wazuh local configuration.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-command.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_command.wazuh_wodle_command_configuration import (
    WazuhWodleCommandConfiguration,
)
