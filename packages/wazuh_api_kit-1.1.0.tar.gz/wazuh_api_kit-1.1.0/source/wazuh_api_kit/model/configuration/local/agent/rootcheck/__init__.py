"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`rootcheck` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/rootcheck.html
"""

from wazuh_api_kit.model.configuration.local.agent.rootcheck.wazuh_agent_rootcheck_configuration import (
    WazuhAgentRootcheckConfiguration,
)
