"""
Provides the :class:`WazuhAgentBufferConfiguration` which allows to parse the
`client_buffer` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentBufferConfiguration:
    """
    Object representation of an agent's `client_buffer` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/client-buffer.html
    """

    disabled: bool
    """
    Indicates whether the agent's event buffer is enabled or not.
    """

    queue_size: int
    """
    The maximum number of events the buffer will hold.
    """

    events_per_second: int
    """
    The maximum number of events that may
    be sent per second to the manager.
    """

    def __init__(self, **kwargs):

        self.disabled = kwargs.get("disabled") == "yes"
        self.queue_size = kwargs.get("queue_size")
        self.events_per_second = kwargs.get("events_per_second")
