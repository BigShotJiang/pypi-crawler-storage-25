"""
Provides the :class:`WazuhAgentFluentForwardKeepaliveConfiguration` which allows
to parse the `keepalive` subsection of the `fluent-forward` section of the Wazuh
local configuration (ossec.conf).
"""


class WazuhAgentFluentForwardKeepaliveConfiguration:
    """
    Object representation of an agent's `fluent-forward.keepalive` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/fluent-forward.html#keepalive
    """

    enabled: bool = True
    """
    Indicates whether TCP keepalive is activated or not.
    """

    count: int | None
    """
    The maximum number of probes that may fail before the
    connection will be closed.
    """

    idle: int | None
    """
    Number of seconds the agent will wait before starting
    to send probes.
    """

    interval: int | None
    """
    Interval (in seconds) between probes.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"
        self.count = kwargs.get("count")
        self.idle = kwargs.get("idle")
        self.interval = kwargs.get("interval")
