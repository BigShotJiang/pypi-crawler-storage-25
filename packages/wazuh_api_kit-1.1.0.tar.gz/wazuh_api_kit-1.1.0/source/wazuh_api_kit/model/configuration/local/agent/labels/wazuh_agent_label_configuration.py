"""
Provides the :class:`WazuhAgentLabelConfiguration` which allows to parse the
`label` subsection of the `labels` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentLabelConfiguration:
    """
    Object representation of an agent's `label` in the `labels` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/labels.html
    """

    key: str | None
    """
    Key of the label.
    """

    value: str | None
    """
    Value of the label.
    """

    hidden: bool
    """
    Indicates whether the label is hidden or not.
    """

    def __init__(self, **kwargs):
        self.key = kwargs.get("key")
        self.value = kwargs.get("value")
        self.hidden = kwargs.get("hidden") == "yes"
