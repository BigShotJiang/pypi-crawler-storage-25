"""
Provides the :class:`WazuhAgentSyscheckDiffFileSizeConfiguration` which allows to parse the
`file-size` subsection of the `syscheck.diff` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhAgentSyscheckDiffFileSizeConfiguration:
    """
    Object representation of an agent's `syscheck.diff.file-size` configuration section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/syscheck.html#file-size
    """

    enabled: bool = True
    """
    Indicates whether file size limits are enabled or not.
    """

    limit: int | None
    """
    The file size cutoff in bytes, on which diffs won't be performed.
    """

    def __init__(self, **kwargs):

        if "enabled" in kwargs:
            self.enabled = kwargs.get("enabled") == "yes"

        self.limit = kwargs.get("limit")
