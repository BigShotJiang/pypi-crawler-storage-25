"""
Collection of objects which allow to parse responses that are related to the modules
in the local configuration (ossec.conf) of a Wazuh agent.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/index.html
"""

from wazuh_api_kit.model.configuration.local.wodle.wodle_aws_s3 import (
    WazuhWodleAwsS3BucketConfiguration,
    WazuhWodleAwsS3Configuration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_azure_logs import (
    WazuhWodleAzureLogsConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_command import (
    WazuhWodleCommandConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_docker_listener import (
    WazuhWodleDockerListenerConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_osquery import (
    WazuhWodleOsqueryConfiguration,
    WazuhWodleOsqueryPackConfiguration,
)
from wazuh_api_kit.model.configuration.local.wodle.wodle_syscollector import (
    WazuhWodleSyscollectorConfiguration,
    WazuhWodleSyscollectorSynchronizationConfiguration,
)
