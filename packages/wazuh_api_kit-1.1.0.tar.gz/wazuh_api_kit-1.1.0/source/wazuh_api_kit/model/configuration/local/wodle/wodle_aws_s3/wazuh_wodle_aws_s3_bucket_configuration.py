"""
Provides the :class:`WazuhWodleAwsS3BucketConfiguration` which allows to parse the
`buckets` subsection of the `aws-s3` section of the Wazuh local configuration (ossec.conf).
"""


class WazuhWodleAwsS3BucketConfiguration:
    """
    Object representation of an agent's `aws-s3` wodle configuration's `buckets` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/wodle-s3.html#buckets
    """

    name: str | None
    """
    Name of the S3 bucket from where logs are read.
    """

    type: str | None
    """
    Type of the configured service.
    """

    aws_account_id: str | None
    """
    The ID of the AWS Account, which is used to request the logs.
    """

    aws_account_alias: str | None
    """
    Name for the AWS account.
    """

    access_key: str | None
    """
    ***Deprecated since version 4.4.0***\n
    The access key ID of the IAM user.
    """

    secret_key: str | None
    """
    ***Deprecated since version 4.4.0***\n
    The secret key of the IAM user.
    """

    aws_profile: str | None
    """
    Shared Credential profile name.
    """

    iam_role_arn: str | None
    """
    Role ARN.
    """

    iam_role_duration: str | None
    """
    Expiration time in seconds for which a session with the assumed role is valid.
    """

    path: str | None
    """
    Prefixed bucket path.
    """

    path_suffix: str | None
    """
    Suffixed bucket path.
    """

    only_logs_after: str | None
    """
    Date in the format ``YYYY-MMM-DD`` from which logs will be requested onward.
    """

    regions: list[str]
    """
    List of regions the logs are being collected for.
    """

    aws_organization_id: str | None
    """
    Name of the AWS organization.
    """

    discard_regex: str | None
    """
    Regular expression which causes events to be discarded when matched.
    """

    remove_from_bucket: bool
    """
    Indicates whether collected logs will be deleted after they have been collected.
    """

    sts_endpoint: str | None
    """
    URL of the AWS Security Token Service VPC endpoint.
    """

    service_endpoint: str | None
    """
    URL of the AWS S3 endpoint.
    """

    def __init__(self, **kwargs):

        self.name = kwargs.get("name")
        self.type = kwargs.get("type")
        self.aws_account_id = kwargs.get("aws_account_id")
        self.aws_account_alias = kwargs.get("aws_account_alias")
        self.access_key = kwargs.get("access_key")
        self.secret_key = kwargs.get("secret_key")
        self.aws_profile = kwargs.get("aws_profile")
        self.iam_role_arn = kwargs.get("iam_role_arn")
        self.iam_role_duration = kwargs.get("iam_role_duration")
        self.path = kwargs.get("path")
        self.path_suffix = kwargs.get("path_suffix")
        self.only_logs_after = kwargs.get("only_logs_after")

        self.regions = []
        regions: str = kwargs.get("regions", "")
        for region in regions.split(","):
            self.regions.append(region)

        self.aws_organization_id = kwargs.get("aws_organization_id")
        self.discard_regex = kwargs.get("discard_regex")
        self.remove_from_bucket = kwargs.get("remove_from_bucket") == "yes"
        self.sts_endpoint = kwargs.get("sts_endpoint")
        self.service_endpoint = kwargs.get("service_endpoint")
