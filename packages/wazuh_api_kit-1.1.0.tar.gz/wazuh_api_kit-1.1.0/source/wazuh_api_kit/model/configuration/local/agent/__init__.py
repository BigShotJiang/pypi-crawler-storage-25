"""
Collection of objects which allow to parse responses that are related to the local
configuration (ossec.conf) of a Wazuh agent.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/index.html
"""

from wazuh_api_kit.model.configuration.local.agent.active_response import (
    WazuhAgentActiveResponseConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.agent_upgrade import (
    WazuhAgentUpgradeConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.anti_tampering import (
    WazuhAgentAntiTamperingConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.client import (
    WazuhAgentClientConfiguration,
    WazuhAgentClientEnrollmentConfiguration,
    WazuhAgentClientServerConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.client_buffer import (
    WazuhAgentBufferConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.fluent_forward import (
    WazuhAgentFluentForwardConfiguration,
    WazuhAgentFluentForwardKeepaliveConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.gcp_bucket import (
    WazuhAgentGcpBucketBucketConfiguration,
    WazuhAgentGcpBucketConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.gcp_pubsub import (
    WazuhAgentGcpPubsubConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.github import (
    WazuhAgentGithubApiAuthConfiguration,
    WazuhAgentGithubConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.labels import (
    WazuhAgentLabelsConfiguration,
    wazuh_agent_label_configuration,
)
from wazuh_api_kit.model.configuration.local.agent.localfile import (
    WazuhAgentLocalfileConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.logging import (
    WazuhAgentLoggingConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.ms_graph import (
    WazuhAgentMsGraphApiAuthConfiguration,
    WazuhAgentMsGraphConfiguration,
    WazuhAgentMsGraphResourceConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.office365 import (
    WazuhAgentOffice365ApiAuthConfiguration,
    WazuhAgentOffice365Configuration,
)
from wazuh_api_kit.model.configuration.local.agent.rootcheck import (
    WazuhAgentRootcheckConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.sca import (
    WazuhAgentScaConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.socket import (
    WazuhAgentSocketConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.syscheck import (
    WazuhAgentSyscheckConfiguration,
    WazuhAgentSyscheckDiffConfiguration,
    WazuhAgentSyscheckDiffDiskQuotaConfiguration,
    WazuhAgentSyscheckDiffFileSizeConfiguration,
    WazuhAgentSyscheckDirectoryConfiguration,
    WazuhAgentSyscheckFileLimitConfiguration,
    WazuhAgentSyscheckRegistryLimitConfiguration,
    WazuhAgentSyscheckSynchronizationConfiguration,
    WazuhAgentSyscheckWhodataConfiguration,
)
