"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`gcp-bucket` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/gcp-bucket.html
"""

from wazuh_api_kit.model.configuration.local.agent.gcp_bucket.wazuh_agent_gcp_bucket_bucket_configuration import (
    WazuhAgentGcpBucketBucketConfiguration,
)
from wazuh_api_kit.model.configuration.local.agent.gcp_bucket.wazuh_agent_gcp_bucket_configuration import (
    WazuhAgentGcpBucketConfiguration,
)
