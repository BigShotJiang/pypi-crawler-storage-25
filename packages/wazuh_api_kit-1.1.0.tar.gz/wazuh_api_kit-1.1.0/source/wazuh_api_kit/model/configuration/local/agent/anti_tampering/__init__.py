"""
Provides classes to parse responses that are linked to the Wazuh agent local configuration's
`anti_tampering` section.

Wazuh reference:
https://documentation.wazuh.com/current/user-manual/reference/ossec-conf/anti-tampering.html
"""

from wazuh_api_kit.model.configuration.local.agent.anti_tampering.wazuh_agent_anti_tampering_configuration import (
    WazuhAgentAntiTamperingConfiguration,
)
