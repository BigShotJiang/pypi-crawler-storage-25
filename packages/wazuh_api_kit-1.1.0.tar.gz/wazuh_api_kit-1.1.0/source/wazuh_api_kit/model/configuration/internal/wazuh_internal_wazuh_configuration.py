"""
Provides the :class:`WazuhInternalWazuhConfiguration` which allows to parse the
`wazuh` section of the Wazuh internal configuration.
"""


class WazuhInternalWazuhConfiguration:
    """
    Object representation of the wazuh agent's internal option `wazuh` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#wazuh
    """

    thread_stack_size: int | None
    """
    Stack size assigned for child threads created in Wazuh (in KiB).
    """

    def __init__(self, **kwargs):

        self.thread_stack_size = kwargs.get("thread_stack_size")
