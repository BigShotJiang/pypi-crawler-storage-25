"""
Provides the :class:`WazuhInternalIntegratorConfiguration` which allows to parse the `integrator` section
of the Wazuh internal configuration.
"""


class WazuhInternalIntegratorConfiguration:
    """
    Object representation of the wazuh agent's internal option `integrator` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#integrator
    """

    debug: int
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    def __init__(self, **kwargs):

        self.debug = kwargs.get("debug")
