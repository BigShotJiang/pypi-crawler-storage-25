"""
Provides the :class:`WazuhInternalSyscheckConfiguration` which allows to parse the
`syscheck` section of the Wazuh internal configuration.
"""


class WazuhInternalSyscheckConfiguration:
    """
    Object representation of the wazuh agent's internal option `syscheck` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#syscheck
    """

    rt_delay: int | None
    """
    Time in milliseconds for delay between alerts in real-time.
    """

    max_fd_win_rt: int | None
    """
    Maximum numbers of directories can be configured in
    ossec.conf for Windows in realtime and whodata mode.
    """

    max_audit_entries: int | None
    """
    Maximum number of directories monitored for who-data on Linux.
    """

    default_max_depth: int | None
    """
    Maximum level of recursion allowed while reading directories.
    """

    symlink_scan_interval: int | None
    """
    Check interval of the symbolic links configured in the directories section.
    """

    file_max_size: int | None
    """
    Maximum file size for calculating integrity hashes (in mebibytes).
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    def __init__(self, **kwargs):

        self.rt_delay = kwargs.get("rt_delay")
        self.max_fd_win_rt = kwargs.get("max_fd_win_rt")
        self.max_audit_entries = kwargs.get("max_audit_entries")
        self.default_max_depth = kwargs.get("default_max_depth")
        self.symlink_scan_interval = kwargs.get("symlink_scan_interval")
        self.file_max_size = kwargs.get("file_max_size")
        self.debug = kwargs.get("debug")
