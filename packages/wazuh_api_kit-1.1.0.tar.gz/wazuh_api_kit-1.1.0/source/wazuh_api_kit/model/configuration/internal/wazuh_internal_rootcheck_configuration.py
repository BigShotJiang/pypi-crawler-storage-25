"""
Provides the :class:`WazuhInternalRootcheckConfiguration` which allows to parse the
`rootcheck` section of the Wazuh internal configuration.
"""


class WazuhInternalRootcheckConfiguration:
    """
    Object representation of the wazuh agent's internal option `rootcheck` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#rootcheck
    """

    sleep: int | None
    """
    Number of milliseconds to sleep after reading one PID or suspicious port.
    """

    def __init__(self, **kwargs):

        self.sleep = kwargs.get("sleep")
