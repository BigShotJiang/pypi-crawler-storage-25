"""
Provides the :class:`WazuhInternalWazuhClusterdConfiguration` which allows to parse the
`wazuh-clusterd` section of the Wazuh internal configuration.
"""


class WazuhInternalWazuhClusterdConfiguration:
    """
    Object representation of the wazuh agent's internal option `wazuh-clusterd` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#wazuh-clusterd
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    def __init__(self, **kwargs):

        self.debug = kwargs.get("debug")
