"""
Provides the :class:`WazuhInternalLogcollectorConfiguration` which allows to parse the
`logcollector` section of the Wazuh internal configuration.
"""


class WazuhInternalLogcollectorConfiguration:
    """
    Object representation of the wazuh agent's internal option `logcollector` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#logcollector
    """

    loop_timeout: int | None
    """
    File polling interval.
    """

    open_attempts: int | None
    """
    Number of attempts to open a log file.
    The value 0 means that the number of attempts is infinite.
    """

    remote_commands: int | None
    """
    Toggles Logcollector to accept remote commands from the manager or not.
    """

    vcheck_files: int | None
    """
    File checking interval, in seconds.
    """

    max_lines: int | None
    """
    Maximum number of logs read from the same file in each iteration.
    """

    sample_log_length: int | None
    """
    Sample log length limit for errors about large input logs.
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    input_threads: int | None
    """
    Number of input threads reading files.
    """

    queue_size: int | None
    """
    Queue size for each type of socket.
    """

    max_files: int | None
    """
    Maximum number of files to be monitored.
    """

    sock_fail_time: int | None
    """
    Time to reattempt a socket connection after a failure, in seconds.
    """

    rlimit_nofile: int | None
    """
    Maximum number of file descriptors that Logcollector can open.
    This value must be greater than or equal to (logcollector.max_files + 100).
    """

    force_reload: bool
    """
    Force file handler reloading: close and reopen monitored files.
    """

    reload_interval: int | None
    """
    File reloading interval, in seconds.
    This parameter only applies if logcollector.force_reload is set to 1.
    """

    reload_delay: int | None
    """
    File reloading delay (between close and open), in milliseconds.
    This parameter only applies if logcollector.force_reload is set to 1.
    """

    exclude_files_interval: int | None
    """
    Excluded files refresh interval, in seconds.
    """

    state_interval: int | None
    """
    Statistics generation interval, in seconds.
    """

    ip_update_interval: int | None
    """
    IP update interval, in seconds. This specifies how often the system IP
    is obtained when the out_format option is used.
    """

    def __init__(self, **kwargs):

        self.loop_timeout = kwargs.get("loop_timeout")
        self.open_attempts = kwargs.get("open_attempts")
        self.remote_commands = kwargs.get("remote_commands")
        self.vcheck_files = kwargs.get("vcheck_files")
        self.max_lines = kwargs.get("max_lines")
        self.sample_log_length = kwargs.get("sample_log_length")
        self.debug = kwargs.get("debug")
        self.input_threads = kwargs.get("input_threads")
        self.queue_size = kwargs.get("queue_size")
        self.max_files = kwargs.get("max_files")
        self.sock_fail_time = kwargs.get("sock_fail_time")
        self.rlimit_nofile = kwargs.get("rlimit_nofile")
        self.force_reload = kwargs.get("force_reload") == 1
        self.reload_interval = kwargs.get("reload_interval")
        self.reload_delay = kwargs.get("reload_delay")
        self.exclude_files_interval = kwargs.get("exclude_files_interval")
        self.state_interval = kwargs.get("state_interval")
        self.ip_update_interval = kwargs.get("ip_update_interval")
