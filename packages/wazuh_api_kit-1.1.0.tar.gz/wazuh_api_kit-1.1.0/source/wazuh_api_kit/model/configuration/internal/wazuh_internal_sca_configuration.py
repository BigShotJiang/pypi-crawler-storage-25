"""
Provides the :class:`WazuhInternalScaConfiguration` which allows to parse the
`sca` section of the Wazuh internal configuration.
"""


class WazuhInternalScaConfiguration:
    """
    Object representation of the wazuh agent's internal option `sca` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#rootcheck
    """

    request_db_interval: int | None
    """
    In case of integrity fail, this is the maximum interval
    (minutes) to resend the scan information to the manager.
    """

    remote_commands: bool
    """
    Enable the execution of commands in policy files received
    from the manager (Files in etc/shared).
    """

    commands_timeout: int | None
    """
    Timeout for the commands execution.
    """

    def __init__(self, **kwargs):

        self.request_db_interval = kwargs.get("request_db_interval")
        self.remote_commands = kwargs.get("remote_commands")
        self.commands_timeout = kwargs.get("commands_timeout")
