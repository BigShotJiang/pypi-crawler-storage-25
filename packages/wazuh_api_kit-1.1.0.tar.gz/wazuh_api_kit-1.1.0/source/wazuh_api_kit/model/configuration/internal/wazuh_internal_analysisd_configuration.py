"""
Provides the :class:`WazuhInternalAnalysisdConfiguration` which allows to parse the `analysisd` section
of the Wazuh internal configuration.
"""


class WazuhInternalAnalysisdConfiguration:
    """
    Object representation of the wazuh agent's internal option `analysisd` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#analysisd
    """

    default_timeframe: int | None
    """
    Default rule time-frame.
    """

    stats_maxdiff: int | None
    """
    Stats maximum diff.
    """

    stats_mindiff: int | None
    """
    Stats minimum diff.
    """

    stats_percent_diff: int | None
    """
    Stats percentage (how much to differ from average).
    """

    fts_list_size: int | None
    """
    FTS list size.
    """

    fts_min_size_for_str: int | None
    """
    FTS minimum string size.
    """

    firewall_logging_enabled: bool = True
    """
    Toggles firewall log on and off (at logs/firewall/firewall.log).
    """

    decoder_order_size: int | None
    """
    Maximum number of fields in a decoder (order tag).
    """

    geoip_output_as_json: bool
    """
    Toggle to turn on or off the output of GeoIP data in JSON alerts.
    """

    label_cache_maxage: int | None
    """
    Number of in seconds without reloading labels in cache from agents.
    """

    show_hidden_labels: bool
    """
    Make hidden labels visible in alerts.
    """

    rlimit_nofile: int | None
    """
    Maximum number of file descriptors that Analysisd can open.
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    min_rotate_interval: int | None
    """
    Minimum interval between log rotations. Supersedes max_output_size option.
    """

    event_threads: int | None
    """
    Number of event decoder threads.
    """

    syscheck_threads: int | None
    """
    Number of syscheck event decoder threads.
    """

    syscollector_threads: int | None
    """
    Number of Syscollector event decoder threads.
    """

    rootcheck_threads: int | None
    """
    Number of Rootcheck event decoder threads.
    """

    sca_threads: int | None
    """
    Number of SCA event decoder threads.
    """

    hostinfo_threads: int | None
    """
    Number of hostinfo event decoder threads.
    """

    rule_matching_threads: int | None
    """
    Number of rule matching threads.
    """

    dbsync_threads: int | None
    """
    Number of database synchronization dispatcher threads.
    """

    winevt_threads: int | None
    """
    Number of Windows event decoder threads.
    """

    decode_event_queue_size: int | None
    """
    Sets the decode event queue size.
    """

    decode_syscheck_queue_size: int | None
    """
    Sets the decode Syscheck queue size.
    """

    decode_syscollector_queue_size: int | None
    """
    Sets the decode Syscollector queue size.
    """

    decode_rootcheck_queue_size: int | None
    """
    Sets the decode Rootcheck queue size.
    """

    decode_sca_queue_size: int | None
    """
    Sets the decode SCA queue size.
    """

    decode_hostinfo_queue_size: int | None
    """
    Sets the decode hostinfo queue size.
    """

    decode_output_queue_size: int | None
    """
    Sets the decode output queue size.
    """

    decode_winevt_queue_size: int | None
    """
    Sets the Windows event decode queue size.
    """

    archives_queue_size: int | None
    """
    Sets the archives log queue size.
    """

    statistical_queue_size: int | None
    """
    Sets the statistical log queue size.
    """

    alerts_queue_size: int | None
    """
    Sets the alerts log queue size.
    """

    firewall_queue_size: int | None
    """
    Sets the firewall log queue size.
    """

    fts_queue_size: int | None
    """
    Sets the fts log queue size.
    """

    dbsync_queue_size: int | None
    """
    Sets the database synchronization message queue size.
    """

    upgrade_queue_size: int | None
    """
    Sets the upgrade message queue size.
    """

    state_interval: int | None
    """
    Sets the Analysisd interval for updating the state file in seconds.
    """

    def __init__(self, **kwargs):

        self.default_timeframe = kwargs.get("default_timeframe")
        self.stats_maxdiff = kwargs.get("stats_maxdiff")
        self.stats_mindiff = kwargs.get("stats_mindiff")
        self.stats_percent_diff = kwargs.get("stats_percent_diff")
        self.fts_list_size = kwargs.get("fts_list_size")
        self.fts_min_size_for_str = kwargs.get("fts_min_size_for_str")

        if "log_fw" in kwargs:
            self.firewall_logging_enabled = kwargs.get("log_fw") == 1

        self.decoder_order_size = kwargs.get("decoder_order_size")
        self.geoip_output_as_json = kwargs.get("geoip_jsonout") == 1
        self.label_cache_maxage = kwargs.get("label_cache_maxage")
        self.show_hidden_labels = kwargs.get("show_hidden_labels") == 1
        self.rlimit_nofile = kwargs.get("rlimit_nofile")
        self.debug = kwargs.get("debug")
        self.min_rotate_interval = kwargs.get("min_rotate_interval")
        self.event_threads = kwargs.get("event_threads")
        self.syscheck_threads = kwargs.get("syscheck_threads")
        self.syscollector_threads = kwargs.get("syscollector_threads")
        self.rootcheck_threads = kwargs.get("rootcheck_threads")
        self.sca_threads = kwargs.get("sca_threads")
        self.hostinfo_threads = kwargs.get("hostinfo_threads")
        self.rule_matching_threads = kwargs.get("rule_matching_threads")
        self.dbsync_threads = kwargs.get("dbsync_threads")
        self.winevt_threads = kwargs.get("winevt_threads")
        self.decode_event_queue_size = kwargs.get("decode_event_queue_size")
        self.decode_syscheck_queue_size = kwargs.get("decode_syscheck_queue_size")
        self.decode_syscollector_queue_size = kwargs.get("decode_syscollector_queue_size")
        self.decode_rootcheck_queue_size = kwargs.get("decode_rootcheck_queue_size")
        self.decode_sca_queue_size = kwargs.get("decode_sca_queue_size")
        self.decode_hostinfo_queue_size = kwargs.get("decode_hostinfo_queue_size")
        self.decode_output_queue_size = kwargs.get("decode_output_queue_size")
        self.decode_winevt_queue_size = kwargs.get("decode_winevt_queue_size")
        self.archives_queue_size = kwargs.get("archives_queue_size")
        self.statistical_queue_size = kwargs.get("statistical_queue_size")
        self.alerts_queue_size = kwargs.get("alerts_queue_size")
        self.firewall_queue_size = kwargs.get("firewall_queue_size")
        self.fts_queue_size = kwargs.get("fts_queue_size")
        self.dbsync_queue_size = kwargs.get("dbsync_queue_size")
        self.upgrade_queue_size = kwargs.get("upgrade_queue_size")
        self.state_interval = kwargs.get("state_interval")
