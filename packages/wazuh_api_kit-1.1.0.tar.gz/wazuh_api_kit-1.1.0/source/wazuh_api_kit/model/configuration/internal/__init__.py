"""
Provides classes to parse responses that are linked to the Wazuh internal configuration.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html
"""

from wazuh_api_kit.model.configuration.internal.wazuh_internal_agent_configuration import (
    WazuhInternalAgentConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_analysisd_configuration import (
    WazuhInternalAnalysisdConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_authd_configuration import (
    WazuhInternalAuthdConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_configuration import (
    WazuhInternalConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_dbd_configuration import (
    WazuhInternalDbdConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_execd_configuration import (
    WazuhInternalExecdConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_integrator_configuration import (
    WazuhInternalIntegratorConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_logcollector_configuration import (
    WazuhInternalLogcollectorConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_maild_configuration import (
    WazuhInternalMaildConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_monitord_configuration import (
    WazuhInternalMonitordConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_remoted_configuration import (
    WazuhInternalRemotedConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_rootcheck_configuration import (
    WazuhInternalRootcheckConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_sca_configuration import (
    WazuhInternalScaConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_syscheck_configuration import (
    WazuhInternalSyscheckConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_vulnerability_detection_configuration import (
    WazuhInternalVulnerabilityDetectionConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_wazuh_clusterd_configuration import (
    WazuhInternalWazuhClusterdConfiguration,
)
from wazuh_api_kit.model.configuration.internal.wazuh_internal_wazuh_configuration import (
    WazuhInternalWazuhConfiguration,
)
