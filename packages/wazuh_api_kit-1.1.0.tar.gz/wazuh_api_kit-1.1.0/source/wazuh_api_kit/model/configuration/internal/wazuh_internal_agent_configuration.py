"""
Provides the :class:`WazuhInternalAgentConfiguration` which allows to parse the `agent` section
of the Wazuh internal configuration.
"""


class WazuhInternalAgentConfiguration:
    """
    Object representation of the wazuh agent's internal option `agent` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#agent
    """

    tolerance: int | None = None
    """
    Number of seconds the agent's event buffer must remain full
    before triggering a flood alert.
    """

    warn_level: int | None = None
    """
    Threshold in percent of occupied space in the agent's event buffer
    after which a warning alert will be triggered.
    """

    normal_level: int | None = None
    """
    Threshold in percent of occupied space in the agent's event buffer
    after which a the agent will return to it's normal state.
    """

    min_eps: int | None = None
    """
    The minimum permitted amount of events that may be sent to the
    manager within a second.
    """

    timeout: int | None = None
    """
    The maximum amount of time in seconds the agent will wait for a
    response from the TCP client socket.
    """

    state_interval: int | None = None
    """
    Frequency in seconds in which the agent will update it's status file.
    """

    debug: int | None = None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    remote_conf_enabled: bool = True
    """
    Indicates whether the agent allows or refuses remote configuration.
    """

    def __init__(self, **kwargs):

        self.tolerance = kwargs.get("tolerance")
        self.warn_level = kwargs.get("warn_level")
        self.normal_level = kwargs.get("normal_level")
        self.min_eps = kwargs.get("min_eps")
        self.timeout = kwargs.get("recv_timeout")
        self.state_interval = kwargs.get("state_interval")
        self.debug = kwargs.get("debug")
        if "remote_conf" in kwargs:
            self.remote_conf_enabled = kwargs.get("remote_conf") == 1
