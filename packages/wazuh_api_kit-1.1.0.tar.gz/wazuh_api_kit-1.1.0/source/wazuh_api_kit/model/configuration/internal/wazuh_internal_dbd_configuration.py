"""
Provides the :class:`WazuhInternalDbdConfiguration` which allows to parse the `dbd` section
of the Wazuh internal configuration.
"""


class WazuhInternalDbdConfiguration:
    """
    Object representation of the wazuh agent's internal option `dbd` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#dbd
    """

    reconnect_attempts: int | None
    """
    Number of times wazuh-dbd will attempt to reconnect to the database.
    """

    def __init__(self, **kwargs):

        self.reconnect_attempts = kwargs.get("reconnect_attempts")
