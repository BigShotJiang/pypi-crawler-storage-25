"""
Provides the :class:`WazuhInternalExecdConfiguration` which allows to parse the `execd` section
of the Wazuh internal configuration.
"""


class WazuhInternalExecdConfiguration:
    """
    Object representation of the wazuh agent's internal option `execd` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#execd
    """

    request_timeout: int | None
    """
    Timeout in seconds to execute remote requests.
    """

    max_restart_lock: int | None
    """
    Maximum timeout that the agent cannot restart while updating.
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    def __init__(self, **kwargs):

        self.request_timeout = kwargs.get("request_timeout")
        self.max_restart_lock = kwargs.get("max_restart_lock")
        self.debug = kwargs.get("debug")
