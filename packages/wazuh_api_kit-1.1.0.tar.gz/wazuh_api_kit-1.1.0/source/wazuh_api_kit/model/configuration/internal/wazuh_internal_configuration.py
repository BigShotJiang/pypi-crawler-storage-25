"""
Provides the :class:`WazuhInternalConfiguration` which allows to parse responses
that contain Wazuh internal configuration data.
"""

from .wazuh_internal_agent_configuration import WazuhInternalAgentConfiguration
from .wazuh_internal_analysisd_configuration import (
    WazuhInternalAnalysisdConfiguration,
)
from .wazuh_internal_authd_configuration import WazuhInternalAuthdConfiguration
from .wazuh_internal_dbd_configuration import WazuhInternalDbdConfiguration
from .wazuh_internal_execd_configuration import WazuhInternalExecdConfiguration
from .wazuh_internal_integrator_configuration import (
    WazuhInternalIntegratorConfiguration,
)
from .wazuh_internal_logcollector_configuration import (
    WazuhInternalLogcollectorConfiguration,
)
from .wazuh_internal_maild_configuration import WazuhInternalMaildConfiguration
from .wazuh_internal_monitord_configuration import (
    WazuhInternalMonitordConfiguration,
)
from .wazuh_internal_remoted_configuration import (
    WazuhInternalRemotedConfiguration,
)
from .wazuh_internal_rootcheck_configuration import (
    WazuhInternalRootcheckConfiguration,
)
from .wazuh_internal_sca_configuration import WazuhInternalScaConfiguration
from .wazuh_internal_syscheck_configuration import (
    WazuhInternalSyscheckConfiguration,
)
from .wazuh_internal_vulnerability_detection_configuration import (
    WazuhInternalVulnerabilityDetectionConfiguration,
)
from .wazuh_internal_wazuh_clusterd_configuration import (
    WazuhInternalWazuhClusterdConfiguration,
)
from .wazuh_internal_wazuh_configuration import WazuhInternalWazuhConfiguration


class WazuhInternalConfiguration:
    """
    Object representation of the wazuh agent's internal options.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html
    """

    agent: WazuhInternalAgentConfiguration | None
    """
    Internal options section `agent`.
    """

    analysisd: WazuhInternalAnalysisdConfiguration | None
    """
    Internal options section `analysisd`.
    """

    authd: WazuhInternalAuthdConfiguration | None
    """
    Internal options section `authd`.
    """

    dbd: WazuhInternalDbdConfiguration | None
    """
    Internal options section `dbd`.
    """

    execd: WazuhInternalExecdConfiguration | None
    """
    Internal options section `execd`.
    """

    integrator: WazuhInternalIntegratorConfiguration | None
    """
    Internal options section `integrator`.
    """

    logcollector: WazuhInternalLogcollectorConfiguration | None
    """
    Internal options section `logcollector`.
    """

    maild: WazuhInternalMaildConfiguration | None
    """
    Internal options section `maild`.
    """

    monitord: WazuhInternalMonitordConfiguration | None
    """
    Internal options section `monitord`.
    """

    remoted: WazuhInternalRemotedConfiguration | None
    """
    Internal options section `remoted`.
    """

    syscheck: WazuhInternalSyscheckConfiguration | None
    """
    Internal options section `syscheck`.
    """

    rootcheck: WazuhInternalRootcheckConfiguration | None
    """
    Internal options section `rootcheck`.
    """

    sca: WazuhInternalScaConfiguration | None
    """
    Internal options section `sca`.
    """

    vulnerability_detection: WazuhInternalVulnerabilityDetectionConfiguration | None
    """
    Internal options section `vulnerability`.
    """

    wazuh: WazuhInternalWazuhConfiguration | None
    """
    Internal options section `wazuh`.
    """

    wazuh_clusterd: WazuhInternalWazuhClusterdConfiguration | None
    """
    Internal options section `wazuh_clusterd`.
    """

    def __init__(self, **kwargs):

        if "agent" in kwargs:
            self.agent = WazuhInternalAgentConfiguration(**kwargs.get("agent"))

        if "analysisd" in kwargs:
            self.analysisd = WazuhInternalAnalysisdConfiguration(**kwargs.get("analysisd"))

        if "authd" in kwargs:
            self.authd = WazuhInternalAuthdConfiguration(**kwargs.get("authd"))

        if "dbd" in kwargs:
            self.dbd = WazuhInternalDbdConfiguration(**kwargs.get("dbd"))

        if "execd" in kwargs:
            self.execd = WazuhInternalExecdConfiguration(**kwargs.get("execd"))

        if "integrator" in kwargs:
            self.integrator = WazuhInternalIntegratorConfiguration(**kwargs.get("integrator"))

        if "logcollector" in kwargs:
            self.logcollector = WazuhInternalLogcollectorConfiguration(**kwargs.get("logcollector"))

        if "maild" in kwargs:
            self.maild = WazuhInternalMaildConfiguration(**kwargs.get("maild"))

        if "monitord" in kwargs:
            self.monitord = WazuhInternalMonitordConfiguration(**kwargs.get("monitord"))

        if "remoted" in kwargs:
            self.remoted = WazuhInternalRemotedConfiguration(**kwargs.get("remoted"))

        if "syscheck" in kwargs:
            self.syscheck = WazuhInternalSyscheckConfiguration(**kwargs.get("syscheck"))

        if "rootcheck" in kwargs:
            self.rootcheck = WazuhInternalRootcheckConfiguration(**kwargs.get("rootcheck"))

        if "sca" in kwargs:
            self.sca = WazuhInternalScaConfiguration(**kwargs.get("sca"))

        if "vulnerability-detection" in kwargs:
            self.vulnerability_detection = WazuhInternalVulnerabilityDetectionConfiguration(
                **kwargs.get("vulnerability-detection")
            )

        if "wazuh" in kwargs:
            self.wazuh = WazuhInternalWazuhConfiguration(**kwargs.get("wazuh"))

        if "wazuh_clusterd" in kwargs:
            self.wazuh_clusterd = WazuhInternalWazuhClusterdConfiguration(
                **kwargs.get("wazuh_clusterd")
            )
