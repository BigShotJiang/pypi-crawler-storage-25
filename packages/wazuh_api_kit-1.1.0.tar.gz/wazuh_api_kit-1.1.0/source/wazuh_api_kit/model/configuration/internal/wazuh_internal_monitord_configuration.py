"""
Provides the :class:`WazuhInternalMonitordConfiguration` which allows to parse the
`monitord` section of the Wazuh internal configuration.
"""


class WazuhInternalMonitordConfiguration:
    """
    Object representation of the wazuh agent's internal option `monitord` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#monitord
    """

    day_wait: int | None
    """
    Number of seconds to wait before compressing or signing the files.
    """

    compress: bool = True
    """
    Toggle to enable or disable log file compression.
    """

    sign: bool = True
    """
    Toggle to enable or disable signing the log files.
    """

    monitor_agents: bool = True
    """
    Toggle to enable or disable monitoring of agents.
    """

    rotate_log: bool = True
    """
    Toggle to enable or disable daily rotation of internal logs.
    """

    keep_log_days: int | None
    """
    Number of days to keep rotated internal logs.
    """

    size_rotate: int | None
    """
    Maximum size in Megabytes of internal logs to trigger rotation.
    """

    daily_rotations: int | None
    """
    Maximum number of rotations per day for internal logs.
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    delete_old_agents: int | None
    """
    Number of minutes before deleting an old disconnected agent.
    This is a time-lapse after the agent is considered as disconnected
    because of the disconnection time.
    """

    def __init__(self, **kwargs):

        self.day_wait = kwargs.get("day_wait")

        if "compress" in kwargs:
            self.compress = kwargs.get("compress") == 1

        if "sign" in kwargs:
            self.sign = kwargs.get("sign") == 1

        if "monitor_agents" in kwargs:
            self.monitor_agents = kwargs.get("monitor_agents") == 1

        if "rotate_log" in kwargs:
            self.rotate_log = kwargs.get("rotate_log") == 1

        self.keep_log_days = kwargs.get("keep_log_days")
        self.size_rotate = kwargs.get("size_rotate")
        self.daily_rotations = kwargs.get("daily_rotations")
        self.debug = kwargs.get("debug")
        self.delete_old_agents = kwargs.get("delete_old_agents")
