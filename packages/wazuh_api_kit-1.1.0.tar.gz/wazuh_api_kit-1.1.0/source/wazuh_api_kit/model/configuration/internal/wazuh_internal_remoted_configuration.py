"""
Provides the :class:`WazuhInternalRemotedConfiguration` which allows to parse the
`remoted` section of the Wazuh internal configuration.
"""


class WazuhInternalRemotedConfiguration:
    """
    Object representation of the wazuh agent's internal option `remoted` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#remoted
    """

    recv_counter_flush: int | None
    """
    Flush rate for the receive counter.
    """

    comp_average_printout: int | None
    """
    Compression averages printout.
    """

    verify_msg_id: bool
    """
    Toggle to enable or disable verification of msg id.
    This setting doesn't work with multiple threads (worker_pool > 1).
    """

    pass_empty_keyfile: bool = True
    """
    Toggle to enable or disable acceptance of empty ``client.keys``.
    """

    sender_pool: int | None
    """
    Number of parallel threads to send the shared file.
    """

    request_pool: int | None
    """
    Limit of parallel threads to dispatch requests.
    """

    request_timeout: int | None
    """
    Time (in seconds) the remote request listener rejects a new request.
    """

    response_timeout: int | None
    """
    Time (in seconds) the remote request listener rejects a request response.
    """

    request_rto_sec: int | None
    """
    Re-transmission timeout in seconds for UDP.
    """

    request_rto_msec: int | None
    """
    Re-transmission timeout in milliseconds for UDP.
    """

    max_attempts: int | None
    """
    Maximum number of sending attempts.
    """

    merge_shared: bool = True
    """
    Merge shared configuration to be broadcast to agents.
    """

    disk_storage: int | None
    """
    Store the temporary shared configuration file on disk.
    """

    shared_reload: int | None
    """
    Number of seconds between reloading of shared files.
    """

    rlimit_nofile: int | None
    """
    Maximum number of file descriptors that Remoted can open.
    """

    recv_timeout: int | None
    """
    Maximum number of seconds to wait for client response in TCP.
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    keyupdate_interval: int | None
    """
    Keys file reloading latency (seconds).
    """

    worker_pool: int | None
    """
    Number of threads that process the payload reception.
    """

    state_interval: int | None
    """
    Interval between the updates of the status file in seconds.
    """

    guess_agent_group: bool
    """
    Toggle to enable or disable the guessing of the group to which
    the agent belongs when registering it again.
    """

    receive_chunk: int | None
    """
    Reception buffer size for TCP (bytes).
    Amount of data that Remoted can receive per operation.
    """

    send_chunk: int | None
    """
    Send buffer size for TCP (bytes).
    Amount of data that Remoted can send per operation.
    """

    send_buffer_size: int | None
    """
    Send queue size for TCP (bytes).
    Amount of data that Remoted can queue to send
    (one queue per agent).
    """

    ctrl_msg_queue_size: int | None
    """
    Maximum number of control messages that can be queued for
    processing. When the queue reaches this limit, backpressure
    is applied to prevent memory exhaustion.
    """

    send_timeout_to_retry: int | None
    """
    Maximum number of seconds to wait before retrying to
    queue a packet to send in TCP.
    """

    buffer_relax: int | None
    """
    Method for memory deallocation after accepting input data.
    This option applies in TCP mode only.
    """

    tcp_keepidle: int | None
    """
    Time (in seconds) the connection needs to remain idle
    before TCP starts sending keepalive probes.
    """

    tcp_keepintvl: int | None
    """
    The time (in seconds) between individual keepalive probes.
    """

    tcp_keepcnt: int | None
    """
    Maximum number of keepalive probes TCP should send before
    dropping the connection.
    """

    def __init__(self, **kwargs):

        self.recv_counter_flush = kwargs.get("recv_counter_flush")
        self.comp_average_printout = kwargs.get("comp_average_printout")
        self.verify_msg_id = kwargs.get("verify_msg_id") == 1

        if "pass_empty_keyfile" in kwargs:
            self.pass_empty_keyfile = kwargs.get("pass_empty_keyfile") == 1

        self.sender_pool = kwargs.get("sender_pool")
        self.request_pool = kwargs.get("request_pool")
        self.request_timeout = kwargs.get("request_timeout")
        self.response_timeout = kwargs.get("response_timeout")
        self.request_rto_sec = kwargs.get("request_rto_sec")
        self.request_rto_msec = kwargs.get("request_rto_msec")
        self.max_attempts = kwargs.get("max_attempts")

        if "merge_shared" in kwargs:
            self.merge_shared = kwargs.get("merge_shared") == 1

        self.disk_storage = kwargs.get("disk_storage")
        self.shared_reload = kwargs.get("shared_reload")
        self.rlimit_nofile = kwargs.get("rlimit_nofile")
        self.recv_timeout = kwargs.get("recv_timeout")
        self.debug = kwargs.get("debug")
        self.keyupdate_interval = kwargs.get("keyupdate_interval")
        self.worker_pool = kwargs.get("worker_pool")
        self.state_interval = kwargs.get("state_interval")
        self.guess_agent_group = kwargs.get("guess_agent_group") == 1
        self.receive_chunk = kwargs.get("receive_chunk")
        self.send_chunk = kwargs.get("send_chunk")
        self.send_buffer_size = kwargs.get("send_buffer_size")
        self.ctrl_msg_queue_size = kwargs.get("ctrl_msg_queue_size")
        self.send_timeout_to_retry = kwargs.get("send_timeout_to_retry")
        self.buffer_relax = kwargs.get("buffer_relax")
        self.tcp_keepidle = kwargs.get("tcp_keepidle")
        self.tcp_keepintvl = kwargs.get("tcp_keepintvl")
        self.tcp_keepcnt = kwargs.get("tcp_keepcnt")
