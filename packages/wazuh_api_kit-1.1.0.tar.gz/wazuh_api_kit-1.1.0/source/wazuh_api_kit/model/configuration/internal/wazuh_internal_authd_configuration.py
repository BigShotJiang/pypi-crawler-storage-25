"""
Provides the :class:`WazuhInternalAuthdConfiguration` which allows to parse the `authd` section
of the Wazuh internal configuration.
"""


class WazuhInternalAuthdConfiguration:
    """
    Object representation of the wazuh agent's internal option `authd` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#authd
    """

    debug: int | None
    """
    The debug log level configuration of the wazuh agent.

    0: No debug output\n
    1: Standard debug output\n
    2: Verbose debug output
    """

    timeout_seconds: int | None
    """
    Network timeout to automatically close connections (second part).
    """

    timeout_microseconds: int | None
    """
    Network timeout to automatically close connections (microsecond part).
    """

    def __init__(self, **kwargs):

        self.debug = kwargs.get("debug")
        self.timeout_seconds = kwargs.get("timeout_seconds")
        self.timeout_microseconds = kwargs.get("timeout_microseconds")
