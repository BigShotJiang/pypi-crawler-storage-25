"""
Provides the :class:`WazuhInternalMaildConfiguration` which allows to parse the
`maild` section of the Wazuh internal configuration.
"""


class WazuhInternalMaildConfiguration:
    """
    Object representation of the wazuh agent's internal option `maild` section.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/reference/internal-options.html#maild
    """

    strict_checking: bool = True
    """
    Toggle to enable or disable strict checking.
    """

    grouping: bool = True
    """
    Toggle to enable or disable grouping of alerts into a single email.
    """

    full_subject: bool
    """
    Toggle to enable or disable full subject in alert emails.
    """

    geoip: bool = True
    """
    Toggle to enable or disable GeoIP data in alert emails.
    """

    def __init__(self, **kwargs):

        if "strict_checking" in kwargs:
            self.strict_checking = kwargs.get("strict_checking") == 1

        if "grouping" in kwargs:
            self.grouping = kwargs.get("grouping") == 1

        self.full_subject = kwargs.get("full_subject") == 1

        if "geoip" in kwargs:
            self.geoip = kwargs.get("geoip") == 1
