"""
Provides classes to create json request bodies for "Active-response" api endpoints.

Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Active-response
"""

from wazuh_api_kit.model.active_response.wazuh_active_response_command import (
    WazuhActiveResponseCommand,
)
