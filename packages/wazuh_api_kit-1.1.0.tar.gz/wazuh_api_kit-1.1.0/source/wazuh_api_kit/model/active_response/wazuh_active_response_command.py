"""
Provides the :class:`WazuhActiveResponseCommand` class, which allows
to parse the `/active-response` api endpoint response data.
"""

import json


class WazuhActiveResponseCommand:
    """
    Object representation of the Active Response Command request body.

    Wazuh reference:
    https://documentation.wazuh.com/current/user-manual/api/reference.html#tag/Active-response/operation/api.controllers.active_response_controller.run_command
    """

    command: str
    """
    Command which will be executed by the agents. If this value starts with !,
    then it refers to a script name instead of a command name.
    """

    arguments: list[str]
    """
    List of arguments.
    """

    alert: dict[str:any]
    """
    Alert data of the Active Response command.
    """

    def __init__(
        self,
        command: str,
        arguments: list[str] | None = None,
        alert: dict[str:any] | None = None,
    ):
        """
        Arguments
        ---------
        command: str
            Command which will be executed by the agents. If this value starts with !,
            then it refers to a script name instead of a command name.
        arguments: list[str], optional
            List of arguments.

            Default value: None
        alert: dict[str:any], optional
            Alert data of the Active Response command.

            Default value: None
        """

        if arguments is None:
            arguments = []

        if alert is None:
            alert = {"data": {}}

        self.command = command
        self.arguments = arguments
        self.alert = alert

    def json(self) -> str:
        """
        Creates a json string which is safe to use for Active
        Response run API requests
        """

        json_dict: dict[str:any] = {
            "arguments": self.arguments,
            "command": self.command,
            "alert": self.alert,
        }

        return json.dumps(json_dict)
