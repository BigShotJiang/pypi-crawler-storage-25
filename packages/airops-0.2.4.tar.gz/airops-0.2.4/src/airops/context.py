"""Per-run context propagation via contextvars."""

from contextvars import ContextVar

# The run ID of the currently executing tool run.
# Set by the server during handler execution, read by the HTTP client
# to propagate X-Parent-Tool-Run-Id headers on step API calls.
current_run_id: ContextVar[str | None] = ContextVar("current_run_id", default=None)
