"""FastAPI application factory for tool runtime."""

from __future__ import annotations

import os
from collections.abc import Callable
from typing import Any

import sentry_sdk
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response
from pydantic import BaseModel
from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint

from airops.auth_context import request_auth_token
from airops.server.routes import create_routes
from airops.server.store import RunStore, get_store
from airops.server.ui import create_ui_routes


class AuthTokenMiddleware(BaseHTTPMiddleware):
    """Extracts the Bearer token from the Authorization header and sets
    the request_auth_token ContextVar for the duration of the request."""

    async def dispatch(self, request: Request, call_next: RequestResponseEndpoint) -> Response:
        auth_header = request.headers.get("authorization", "")
        token = (
            auth_header.removeprefix("Bearer ").strip()
            if auth_header.startswith("Bearer ")
            else None
        )
        reset = request_auth_token.set(token)
        try:
            return await call_next(request)
        finally:
            request_auth_token.reset(reset)


def create_app(
    tool_name: str,
    tool_description: str,
    handler: Callable[[Any], Any],
    input_model: type[BaseModel],
    output_model: type[BaseModel],
    *,
    ui: bool = True,
    store: RunStore | None = None,
) -> FastAPI:
    """Create a FastAPI application for a tool.

    Args:
        tool_name: Name of the tool.
        tool_description: Description of the tool.
        handler: The tool handler function.
        input_model: Pydantic model for input validation.
        output_model: Pydantic model for output validation.
        ui: Whether to enable the local testing UI (default: True).
        store: Optional run store (uses global store if not provided).

    Returns:
        Configured FastAPI application.
    """
    load_dotenv()

    sentry_dsn = os.environ.get("SENTRY_DSN")
    if sentry_dsn:
        sentry_sdk.init(
            dsn=sentry_dsn,
            send_default_pii=True,
            enable_logs=True,
            traces_sample_rate=1.0,
            profile_session_sample_rate=1.0,
            profile_lifecycle="trace",
        )

    app = FastAPI(
        title=tool_name,
        description=tool_description,
        version="1.0.0",
    )

    app.add_middleware(AuthTokenMiddleware)

    # Use provided store or global store
    run_store = store or get_store()

    # Add API routes
    api_routes = create_routes(run_store, handler, input_model, output_model)
    app.include_router(api_routes)

    # Add UI routes if enabled
    if ui:
        ui_routes = create_ui_routes(
            tool_name, tool_description, input_model, output_model, handler, run_store
        )
        app.include_router(ui_routes)

    return app
