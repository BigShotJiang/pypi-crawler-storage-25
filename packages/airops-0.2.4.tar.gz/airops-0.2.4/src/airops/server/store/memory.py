"""In-memory run store for local development."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from threading import Lock
from typing import Any

from airops.server.store.base import Run, RunError, RunStatus
from airops.steps.cost_tracker import ToolExecutionCost


class MemoryRunStore:
    """In-memory store for tool runs.

    Uses a dict with a thread lock for safety. All methods are async
    to satisfy the RunStore protocol, but perform no real I/O.
    """

    def __init__(self) -> None:
        self._runs: dict[str, Run] = {}
        self._lock = Lock()

    async def create(self, inputs: dict[str, Any]) -> Run:
        """Create a new run in queued state."""
        run_id = str(uuid.uuid4())
        now = datetime.now(UTC)

        run = Run(
            run_id=run_id,
            status=RunStatus.QUEUED,
            created_at=now,
            updated_at=now,
            inputs=inputs,
        )

        with self._lock:
            self._runs[run_id] = run

        return run

    async def get(self, run_id: str) -> Run | None:
        """Get a run by ID."""
        with self._lock:
            return self._runs.get(run_id)

    async def set_running(self, run_id: str) -> None:
        """Mark a run as running."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.status = RunStatus.RUNNING
                run.updated_at = datetime.now(UTC)

    async def set_success(
        self, run_id: str, outputs: dict[str, Any], cost: ToolExecutionCost | None = None
    ) -> None:
        """Mark a run as successful with outputs and optional cost data."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.status = RunStatus.SUCCESS
                run.outputs = outputs
                run.cost = cost
                run.updated_at = datetime.now(UTC)

    async def set_error(self, run_id: str, error: RunError) -> None:
        """Mark a run as failed with error details."""
        with self._lock:
            run = self._runs.get(run_id)
            if run:
                run.status = RunStatus.ERROR
                run.error = error
                run.updated_at = datetime.now(UTC)

    async def clear(self) -> None:
        """Clear all runs."""
        with self._lock:
            self._runs.clear()
