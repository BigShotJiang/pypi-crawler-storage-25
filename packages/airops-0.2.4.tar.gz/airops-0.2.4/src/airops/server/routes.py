"""HTTP routes for the tool runtime server."""

from __future__ import annotations

import traceback as tb
from collections.abc import Callable, Coroutine
from typing import Any

from fastapi import APIRouter, BackgroundTasks, HTTPException
from pydantic import BaseModel

from airops.auth_context import request_auth_token
from airops.context import current_run_id
from airops.result import ToolResult
from airops.server.store import RunError, RunStore
from airops.steps import cost_tracker
from airops.steps.cost_tracker import ToolExecutionCost

router = APIRouter()


class StartRunRequest(BaseModel):
    """Request body for starting a run."""

    inputs: dict[str, Any]


class StartRunResponse(BaseModel):
    """Response for starting a run."""

    run_id: str
    status: str


class RunErrorResponse(BaseModel):
    """Error details in run response."""

    code: str
    message: str
    details: dict[str, Any] | None = None
    traceback: str | None = None


class StepCostResponse(BaseModel):
    """Cost details for a single step execution in the response."""

    step_type: str
    execution_id: str
    tasks_used: int


class CostResponse(BaseModel):
    """Aggregated cost data in the response."""

    base_tasks_cost: int
    steps_tasks_cost: int
    steps: list[StepCostResponse] = []


class GetRunResponse(BaseModel):
    """Response for getting run status."""

    run_id: str
    status: str
    outputs: dict[str, Any] | None = None
    error: RunErrorResponse | None = None
    cost: CostResponse | None = None


class HealthResponse(BaseModel):
    """Health check response."""

    status: str


HandlerFunc = Callable[[Any], Coroutine[Any, Any, Any]]


def create_routes(
    store: RunStore,
    handler: HandlerFunc,
    input_model: type[BaseModel],
    output_model: type[BaseModel],
) -> APIRouter:
    """Create API routes for a tool.

    Args:
        store: The run store for tracking executions.
        handler: The tool handler function.
        input_model: Pydantic model for input validation.
        output_model: Pydantic model for output validation.

    Returns:
        FastAPI router with configured routes.
    """
    routes = APIRouter()

    @routes.post("/runs", response_model=StartRunResponse, status_code=202)
    async def start_run(
        body: StartRunRequest,
        background_tasks: BackgroundTasks,
    ) -> StartRunResponse:
        """Start a new tool run."""
        # Validate inputs against the input model
        try:
            validated_inputs = input_model.model_validate(body.inputs)
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        run = await store.create(body.inputs)

        # Capture current token for the background task (which runs
        # outside the middleware's ContextVar scope).
        bearer_token = request_auth_token.get()

        # Execute in background
        background_tasks.add_task(
            execute_handler,
            store,
            run.run_id,
            handler,
            validated_inputs,
            output_model,
            bearer_token,
        )

        return StartRunResponse(
            run_id=run.run_id,
            status=run.status.value,
        )

    @routes.get("/runs/{run_id}", response_model=GetRunResponse)
    async def get_run(run_id: str) -> GetRunResponse:
        """Get the status of a run."""
        run = await store.get(run_id)

        if run is None:
            raise HTTPException(status_code=404, detail=f"Run {run_id} not found")

        error_response = None
        if run.error:
            error_response = RunErrorResponse(
                code=run.error.code,
                message=run.error.message,
                details=run.error.details,
                traceback=run.error.traceback,
            )

        cost_response = None
        if run.cost:
            cost_response = CostResponse(
                base_tasks_cost=run.cost.base_tasks_cost,
                steps_tasks_cost=run.cost.steps_tasks_cost,
                steps=[
                    StepCostResponse(
                        step_type=step.step_type,
                        execution_id=step.execution_id,
                        tasks_used=step.tasks_used,
                    )
                    for step in run.cost.steps
                ],
            )

        return GetRunResponse(
            run_id=run.run_id,
            status=run.status.value,
            outputs=run.outputs,
            error=error_response,
            cost=cost_response,
        )

    @routes.get("/health", response_model=HealthResponse)
    async def health_check() -> HealthResponse:
        """Health check endpoint."""
        return HealthResponse(status="ok")

    return routes


async def execute_handler(
    store: RunStore,
    run_id: str,
    handler: HandlerFunc,
    inputs: BaseModel,
    output_model: type[BaseModel],
    auth_token: str | None = None,
) -> None:
    """Execute the handler in background and update run state.

    Args:
        store: The run store.
        run_id: The run ID to update.
        handler: Async tool handler function.
        inputs: Validated input model instance.
        output_model: Pydantic model for output validation.
        auth_token: Per-request bearer token captured from the middleware.
    """
    token_reset = request_auth_token.set(auth_token)
    run_id_reset = current_run_id.set(run_id)
    cost_tracker.reset()
    try:
        await store.set_running(run_id)

        result = await handler(inputs)

        outputs, cost = _extract_outputs_and_cost(result, output_model)

        await store.set_success(run_id, outputs, cost=cost)

    except Exception as exc:
        await store.set_error(
            run_id,
            RunError(
                code="EXECUTION_ERROR",
                message=str(exc),
                details={"type": type(exc).__name__},
                traceback=tb.format_exc(),
            ),
        )
    finally:
        request_auth_token.reset(token_reset)
        current_run_id.reset(run_id_reset)


def _extract_outputs_and_cost(
    result: Any, output_model: type[BaseModel]
) -> tuple[dict[str, Any], ToolExecutionCost | None]:
    """Extract outputs and optional cost data from the handler result.

    Returns:
        A tuple of (outputs_dict, cost_or_none).
    """
    if isinstance(result, ToolResult):
        raw_output = result.output
        base_tasks_cost = result.tasks_cost
    else:
        raw_output = result
        base_tasks_cost = None

    if isinstance(raw_output, output_model):
        outputs = raw_output.model_dump()
    elif isinstance(raw_output, dict):
        validated = output_model.model_validate(raw_output)
        outputs = validated.model_dump()
    else:
        outputs = output_model.model_validate(raw_output).model_dump()

    if base_tasks_cost is None:
        return outputs, None

    cost = ToolExecutionCost(
        base_tasks_cost=base_tasks_cost,
        steps_tasks_cost=cost_tracker.get_total(),
        steps=cost_tracker.get_entries(),
    )
    return outputs, cost
