"""ToolResult wrapper for returning outputs with cost information."""

from airops.outputs import ToolOutputs


class ToolResult[OutputT: ToolOutputs]:
    """Wraps tool outputs with execution cost information.

    SDK tool handlers must return a ToolResult to declare their cost.
    The tasks_cost represents the tool's own cost (minimum 1 task),
    separate from any step API call costs which are tracked automatically.

    Example:
        @tool.handler
        async def run(inputs: Inputs) -> ToolResult[Outputs]:
            results = await steps.execute("google_search", {"query": inputs.query})
            return ToolResult(
                output=Outputs(results=results),
                tasks_cost=2,
            )
    """

    def __init__(self, output: OutputT, tasks_cost: int) -> None:
        if not isinstance(tasks_cost, int):
            raise TypeError(f"tasks_cost must be an int, got {type(tasks_cost).__name__}")
        if tasks_cost < 1:
            raise ValueError(f"tasks_cost must be at least 1, got {tasks_cost}")
        self.output = output
        self.tasks_cost = tasks_cost
