"""Tracks step execution costs accumulated during a tool run."""

from contextvars import ContextVar
from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass
class StepCostEntry:
    """Cost details for a single step execution."""

    step_type: str
    execution_id: str
    tasks_used: int


@dataclass
class ToolExecutionCost:
    """Aggregated cost of a tool execution."""

    base_tasks_cost: int
    steps_tasks_cost: int
    steps: list[StepCostEntry] = field(default_factory=list)

    @property
    def total_tasks_cost(self) -> int:
        return self.base_tasks_cost + self.steps_tasks_cost

    def to_dict(self) -> dict[str, Any]:
        return {
            "base_tasks_cost": self.base_tasks_cost,
            "steps_tasks_cost": self.steps_tasks_cost,
            "steps": [asdict(step) for step in self.steps],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ToolExecutionCost":
        steps_raw: list[dict[str, Any]] = data.get("steps") or []
        steps = [
            StepCostEntry(
                step_type=step["step_type"],
                execution_id=step["execution_id"],
                tasks_used=int(step["tasks_used"]),
            )
            for step in steps_raw
        ]
        return cls(
            base_tasks_cost=int(data["base_tasks_cost"]),
            steps_tasks_cost=int(data["steps_tasks_cost"]),
            steps=steps,
        )


_accumulated_steps: ContextVar[list[StepCostEntry] | None] = ContextVar(
    "_accumulated_steps", default=None
)


def _get_steps() -> list[StepCostEntry]:
    steps = _accumulated_steps.get()
    if steps is None:
        steps = []
        _accumulated_steps.set(steps)
    return steps


def reset() -> None:
    """Reset the accumulated step costs for the current context."""
    _accumulated_steps.set([])


def record(entry: StepCostEntry) -> None:
    """Record a completed step's cost."""
    _get_steps().append(entry)


def get_total() -> int:
    """Return the total tasks used across all recorded steps."""
    return sum(entry.tasks_used for entry in _get_steps())


def get_entries() -> list[StepCostEntry]:
    """Return all recorded step cost entries."""
    return list(_get_steps())
