"""
CLI Application - Main entry point for the TUI mode.

Initializes all services (same as MCP server) and runs the interactive terminal UI.
"""

import asyncio
import sys
from pathlib import Path
from loguru import logger

from .utils import console, print_banner, print_error


class CLIApp:
    """Interactive CLI/TUI application for GitHub Issue Solver."""

    def __init__(self, env_file: str = None, investigate_url: str = None):
        self.env_file = env_file
        self.investigate_url = investigate_url
        self.config = None
        self.services = {}

    def run(self):
        """Main entry point — runs the async event loop."""
        try:
            asyncio.run(self._run_async())
        except KeyboardInterrupt:
            console.print("\n[dim]Goodbye![/dim]")
            sys.exit(0)

    async def _run_async(self):
        """Async main loop."""
        print_banner()

        # Check if first run (missing .env or missing required keys)
        if self._needs_onboarding():
            from .onboarding import run_onboarding
            run_onboarding()
            # After onboarding, re-check
            if self._needs_onboarding():
                print_error("Setup incomplete. Please configure your .env file manually.")
                sys.exit(1)

        # Initialize services
        if not await self._initialize():
            sys.exit(1)

        # Direct investigation mode (--investigate flag)
        if self.investigate_url:
            from .screens.investigation import InvestigationPipeline
            pipeline = InvestigationPipeline(self.config, self.services)
            await pipeline.run(self.investigate_url)
            return

        # Run main menu loop
        from .screens.main_menu import MainMenuScreen
        menu = MainMenuScreen(self.config, self.services)
        await menu.run()

    def _needs_onboarding(self) -> bool:
        """Check if onboarding is needed (missing critical env vars)."""
        import os
        from dotenv import load_dotenv

        if self.env_file and Path(self.env_file).exists():
            load_dotenv(self.env_file)
        else:
            load_dotenv()

        github_token = os.getenv("GITHUB_TOKEN")
        google_key = os.getenv("GOOGLE_API_KEY")
        anthropic_key = os.getenv("ANTHROPIC_API_KEY")
        llm_provider = os.getenv("LLM_PROVIDER", "gemini").lower()

        # Must have GitHub token
        if not github_token:
            return True
        # Must have the right API key for the chosen LLM
        if llm_provider == "gemini" and not google_key:
            return True
        if llm_provider == "claude" and not anthropic_key:
            return True
        return False

    async def _initialize(self) -> bool:
        """Initialize config and services (mirrors server.py pattern)."""
        try:
            from ..config import Config
            from ..services import (
                StateManager, RepositoryService, EmbeddingService,
                IngestionService, AnalysisService, PatchService,
                HealthService, LearningService, LLMService,
            )
            from ..license import LicenseValidator

            console.print("[dim]Initializing services...[/dim]")
            self.config = Config(self.env_file)

            self.services['license_validator'] = LicenseValidator(
                self.config.supabase_url,
                self.config.supabase_anon_key,
            )
            self.services['state_manager'] = StateManager(self.config)
            self.services['repository'] = RepositoryService(self.config)
            self.services['embedding'] = EmbeddingService(self.config)
            self.services['llm'] = LLMService(self.config)
            self.services['ingestion'] = IngestionService(
                self.config,
                self.services['repository'],
                self.services['state_manager'],
                self.services['embedding'],
            )
            self.services['analysis'] = AnalysisService(
                self.config,
                self.services['repository'],
                self.services['state_manager'],
                self.services['llm'],
            )
            self.services['patch'] = PatchService(
                self.config,
                self.services['state_manager'],
                self.services['llm'],
            )
            self.services['health'] = HealthService(
                self.config,
                self.services['state_manager'],
                self.services['repository'],
            )
            self.services['learning'] = LearningService(
                self.config,
                self.services['embedding'],
            )

            console.print("[success]All services initialized.[/success]")
            return True

        except Exception as e:
            print_error(f"Initialization failed: {e}", "Check your .env configuration and try again.")
            logger.exception("CLI initialization error")
            return False
