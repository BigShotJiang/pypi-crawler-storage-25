"""CLI TUI module for GitHub Issue Solver."""

from .app import CLIApp

__all__ = ["CLIApp"]
