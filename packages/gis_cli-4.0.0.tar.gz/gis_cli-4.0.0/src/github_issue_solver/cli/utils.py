"""Rich TUI helper utilities for the CLI app."""

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.theme import Theme

# Shared console instance with custom theme
THEME = Theme({
    "info": "cyan",
    "success": "green",
    "warning": "yellow",
    "error": "bold red",
    "header": "bold magenta",
    "accent": "bold blue",
})

console = Console(theme=THEME)


def print_banner():
    """Print the application banner."""
    banner_text = Text()
    banner_text.append("  GitHub Issue Solver  ", style="bold white on blue")
    banner_text.append("  v3.0  ", style="bold white on magenta")

    ascii_art = r"""
   _____ ___ ____    ____        _
  / ____|_ _/ ___|  / ___|  ___ | |_   _____ _ __
 | |  __ | |\___ \  \___ \ / _ \| \ \ / / _ \ '__|
 | |_| || | ___) |  ___) | (_) | |\ V /  __/ |
  \____|___|____/  |____/ \___/|_| \_/ \___|_|
"""
    console.print(Panel(
        f"[bold cyan]{ascii_art}[/bold cyan]\n"
        "[bold white]AI-Powered GitHub Issue Resolution[/bold white]\n"
        "[dim]Ingest repos, analyze issues, generate patches — all from your terminal[/dim]",
        border_style="blue",
        padding=(0, 2),
    ))


def print_status_header(llm_provider: str, model_name: str, license_tier: str, repos_count: int = 0):
    """Print the status header bar for the main menu."""
    table = Table(show_header=False, show_edge=False, pad_edge=False, expand=True)
    table.add_column(ratio=1)
    table.add_column(ratio=1)
    table.add_column(ratio=1)

    table.add_row(
        f"[accent]LLM:[/accent] {llm_provider} ({model_name})",
        f"[accent]License:[/accent] {license_tier}",
        f"[accent]Repos:[/accent] {repos_count} ingested",
    )
    console.print(Panel(table, border_style="dim", padding=(0, 1)))


def print_error(message: str, suggestion: str = None):
    """Print a formatted error panel."""
    content = f"[error]{message}[/error]"
    if suggestion:
        content += f"\n[dim]{suggestion}[/dim]"
    console.print(Panel(content, title="[error]Error[/error]", border_style="red"))


def print_success(message: str):
    """Print a formatted success message."""
    console.print(f"[success]{message}[/success]")


def print_info(message: str):
    """Print a formatted info message."""
    console.print(f"[info]{message}[/info]")


def prompt_choice(prompt_text: str, choices: list, default: str = None) -> str:
    """Prompt user to select from numbered choices. Returns the selected value."""
    console.print(f"\n[bold]{prompt_text}[/bold]")
    for i, choice in enumerate(choices, 1):
        marker = " (default)" if choice == default else ""
        console.print(f"  [accent]{i}.[/accent] {choice}{marker}")

    while True:
        raw = console.input("\n[bold]> [/bold]").strip()
        if not raw and default:
            return default
        try:
            idx = int(raw)
            if 1 <= idx <= len(choices):
                return choices[idx - 1]
        except ValueError:
            # Allow typing the choice directly
            if raw in choices:
                return raw
        console.print("[warning]Invalid choice. Try again.[/warning]")


def prompt_input(prompt_text: str, default: str = None, password: bool = False) -> str:
    """Prompt for text input with optional default."""
    suffix = f" [{default}]" if default else ""
    raw = console.input(f"[bold]{prompt_text}{suffix}:[/bold] ", password=password).strip()
    return raw if raw else (default or "")


def confirm(prompt_text: str, default: bool = True) -> bool:
    """Yes/No confirmation prompt."""
    hint = "Y/n" if default else "y/N"
    raw = console.input(f"[bold]{prompt_text} ({hint}):[/bold] ").strip().lower()
    if not raw:
        return default
    return raw in ("y", "yes")


def print_divider():
    """Print a horizontal rule."""
    console.rule(style="dim")


def print_phase_banner(num: int, name: str):
    """Convenience delegate to phase_display widget."""
    from .widgets.phase_display import render_phase_banner
    render_phase_banner(num, name)
