"""Rich rendering helpers for investigation phases."""

from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.columns import Columns
from rich.syntax import Syntax

from ..utils import console


def render_phase_banner(num: int, name: str):
    """Print a boxed phase header with number."""
    header = Text()
    header.append(f"  Phase {num}  ", style="bold white on blue")
    header.append(f"  {name}  ", style="bold white")
    console.print()
    console.print(Panel(header, border_style="blue", padding=(0, 1)))


def render_phase_complete(num: int, name: str, elapsed: float):
    """Print green check + timing for completed phase."""
    console.print(
        f"  [green]v Phase {num}: {name}[/green]  [dim]({elapsed:.1f}s)[/dim]"
    )


def render_phase_error(num: int, name: str, error: str):
    """Print red error panel for a failed phase."""
    console.print(Panel(
        f"[bold red]Phase {num} Failed: {name}[/bold red]\n\n{error}",
        border_style="red",
        title="[red]Error[/red]",
    ))


def render_file_table(files: list):
    """Render affected files table (file, lines, reason)."""
    if not files:
        console.print("[dim]  No affected files identified.[/dim]")
        return

    table = Table(title="Affected Files", show_lines=True, expand=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("File", style="cyan", ratio=2)
    table.add_column("Lines", justify="center", width=12)
    table.add_column("Details", ratio=3)

    for i, f in enumerate(files, 1):
        if isinstance(f, dict):
            table.add_row(
                str(i),
                f.get("file_path", f.get("filePath", "?")),
                str(f.get("line_numbers", f.get("lines", "?"))),
                (f.get("explanation", f.get("description", "")))[:80],
            )
        elif isinstance(f, str):
            table.add_row(str(i), f, "-", "")
    console.print(table)


def render_hypothesis_panel(hypothesis: str, index: int, confidence: str = "medium"):
    """Render a color-coded hypothesis card."""
    color_map = {"high": "green", "medium": "yellow", "low": "red"}
    color = color_map.get(confidence.lower(), "yellow")
    console.print(Panel(
        hypothesis,
        title=f"[bold]Hypothesis {index}[/bold]  [{color}]{confidence.upper()}[/{color}]",
        border_style=color,
        padding=(0, 2),
    ))


def render_checklist(items: list, title: str = "Checklist"):
    """Render a checkbox-style list."""
    if not items:
        return
    lines = "\n".join(f"  [ ] {item}" for item in items)
    console.print(Panel(lines, title=f"[bold]{title}[/bold]", border_style="cyan"))


def render_never_do_warnings(rules: list):
    """Render NEVER DO rules in a red-bordered panel."""
    if not rules:
        return
    lines = []
    for r in rules:
        if isinstance(r, dict):
            lines.append(f"  [bold red]X[/bold red] {r.get('rule', r.get('content', str(r)))}")
            reason = r.get("reason", "")
            if reason:
                lines.append(f"    [dim]{reason}[/dim]")
        else:
            lines.append(f"  [bold red]X[/bold red] {r}")
    console.print(Panel(
        "\n".join(lines),
        title="[bold red]NEVER DO[/bold red]",
        border_style="red",
    ))


def render_key_value_panel(data: dict, title: str, border: str = "cyan"):
    """Render a key-value panel."""
    table = Table(show_header=False, show_edge=False, padding=(0, 2), expand=True)
    table.add_column(style="bold", ratio=1)
    table.add_column(ratio=3)
    for k, v in data.items():
        table.add_row(str(k), str(v) if v else "[dim]N/A[/dim]")
    console.print(Panel(table, title=f"[bold]{title}[/bold]", border_style=border))


def render_code_panel(code: str, language: str = "python", title: str = ""):
    """Render syntax-highlighted code in a panel."""
    syntax = Syntax(code, language, theme="monokai", line_numbers=True)
    console.print(Panel(syntax, title=f"[bold]{title}[/bold]" if title else "", border_style="cyan"))


def render_search_results(results: list, title: str = "Search Results"):
    """Render learning search results."""
    if not results:
        console.print(f"  [dim]No results for: {title}[/dim]")
        return
    table = Table(title=title, show_lines=True, expand=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Content", ratio=4)
    table.add_column("Type", width=14)
    table.add_column("Score", justify="right", width=6)

    for i, r in enumerate(results[:5], 1):
        content = r.get("content", "")[:100]
        ltype = r.get("metadata", {}).get("type", "unknown")
        score = r.get("relevance_score", 0)
        table.add_row(str(i), content, ltype, f"{score:.2f}")
    console.print(table)


def render_investigation_summary(ctx):
    """Render final investigation summary with phase timings."""
    from datetime import datetime

    console.print()
    console.print(Panel(
        "[bold white on green]  Investigation Complete  [/bold white on green]",
        border_style="green",
    ))

    # Phase timings table
    if ctx.phase_timings:
        table = Table(title="Phase Timings", show_lines=True)
        table.add_column("Phase", style="bold", ratio=3)
        table.add_column("Duration", justify="right", width=10)

        total = 0.0
        for name, elapsed in ctx.phase_timings.items():
            total += elapsed
            table.add_row(name, f"{elapsed:.1f}s")
        table.add_row("[bold]Total[/bold]", f"[bold]{total:.1f}s[/bold]")
        console.print(table)

    # Root cause summary
    if ctx.analysis_result and ctx.analysis_result.success:
        analysis = ctx.analysis_result.analysis or {}
        summary_data = {
            "Repository": ctx.repo_full_name,
            "Issue": f"#{ctx.issue_number}" + (f" - {ctx.issue_info.title}" if ctx.issue_info else ""),
            "Root Cause": analysis.get("root_cause", "N/A"),
            "Confidence": analysis.get("confidence", "N/A"),
            "Complexity": f"{analysis.get('complexity', 'N/A')}/5",
        }
        render_key_value_panel(summary_data, "Investigation Summary", border="green")

    console.print()
