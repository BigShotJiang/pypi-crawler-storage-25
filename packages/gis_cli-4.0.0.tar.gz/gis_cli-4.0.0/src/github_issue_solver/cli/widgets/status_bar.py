"""Reusable status bar widget."""

from rich.table import Table
from rich.panel import Panel

from ..utils import console


def render_status_bar(items: dict) -> None:
    """Render a bottom-style status bar from key-value pairs.

    Args:
        items: Dictionary of label -> value pairs to display.
    """
    table = Table(show_header=False, show_edge=False, pad_edge=False, expand=True)
    for _ in items:
        table.add_column(ratio=1)
    table.add_row(*[f"[bold]{k}:[/bold] {v}" for k, v in items.items()])
    console.print(Panel(table, border_style="dim", padding=(0, 1)))
