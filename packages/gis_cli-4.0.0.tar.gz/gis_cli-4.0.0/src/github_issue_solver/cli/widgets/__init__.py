"""Reusable TUI widgets."""
