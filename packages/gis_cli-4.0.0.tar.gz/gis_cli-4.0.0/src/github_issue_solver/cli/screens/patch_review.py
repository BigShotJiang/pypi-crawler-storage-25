"""Patch review screen - Syntax-highlighted diffs with save options."""

import os
from pathlib import Path
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax

from ..utils import console, print_error, print_success, prompt_input, confirm


class PatchReviewScreen:
    """Interactive patch review with diff display."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services
        self.patch_service = services['patch']

    async def run(self):
        """Run patch generation and review workflow."""
        console.print(Panel("[bold]Patch Generation[/bold]", border_style="blue"))

        issue_body = prompt_input("Describe the issue (or paste issue body)")
        if not issue_body:
            print_error("Issue description is required.")
            return

        repo_name = prompt_input("Enter repository (owner/repo)")
        if not repo_name or "/" not in repo_name:
            print_error("Invalid format. Use owner/repo")
            return

        console.print("[dim]Generating patches...[/dim]")

        try:
            result = await self.patch_service.generate_code_patch(issue_body, repo_name)
        except Exception as e:
            print_error(f"Patch generation failed: {e}")
            return

        if not result.success:
            print_error(f"Patch generation failed: {result.error_message}")
            return

        self._display_result(result)

        # Save option
        if result.files_to_update and confirm("Save patches to files?"):
            self._save_patches(result)

    def _display_result(self, result):
        """Display patch result with syntax highlighting."""
        # Summary
        console.print(Panel(
            result.summary_of_changes or "No summary available.",
            title="[bold]Summary of Changes[/bold]",
            border_style="green",
        ))

        if not result.files_to_update:
            console.print("[dim]No specific file patches generated. See summary for guidance.[/dim]")
            return

        # Per-file diffs
        for i, patch in enumerate(result.files_to_update, 1):
            console.print(f"\n[bold accent]File {i}: {patch.file_path}[/bold accent] ({patch.operation})")

            if patch.patch_content:
                syntax = Syntax(patch.patch_content, "diff", theme="monokai", line_numbers=True)
                console.print(Panel(syntax, border_style="cyan"))

    def _save_patches(self, result):
        """Save patches to a patches/ directory."""
        patches_dir = Path.cwd() / "patches"
        patches_dir.mkdir(exist_ok=True)

        for patch in result.files_to_update:
            if patch.patch_content:
                safe_name = patch.file_path.replace("/", "_").replace("\\", "_")
                out_path = patches_dir / f"{safe_name}.patch"
                out_path.write_text(patch.patch_content)
                console.print(f"  [dim]Saved: {out_path}[/dim]")

        print_success(f"Patches saved to {patches_dir}/")
