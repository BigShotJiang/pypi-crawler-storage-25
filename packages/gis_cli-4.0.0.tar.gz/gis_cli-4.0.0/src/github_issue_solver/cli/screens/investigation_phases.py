"""
10-phase investigation pipeline functions.

Each phase signature: async def phase_X(services, ctx) -> None
Phases mutate ctx (InvestigationContext) in place and print rich output.
"""

import asyncio
import time
from loguru import logger
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax

from ..utils import console, print_error, print_success, confirm
from ..widgets.phase_display import (
    render_key_value_panel,
    render_file_table,
    render_hypothesis_panel,
    render_checklist,
    render_never_do_warnings,
    render_search_results,
    render_code_panel,
)


# ---------------------------------------------------------------------------
# Phase 1: Setup & Learning
# ---------------------------------------------------------------------------

async def phase_setup(services: dict, ctx) -> None:
    """Parse URL, fetch issue & repo info, auto-ingest if needed, load learnings."""

    repo_svc = services["repository"]
    state_mgr = services["state_manager"]
    ingestion_svc = services["ingestion"]
    learning_svc = services["learning"]

    # 1a. Parse URL
    owner, repo, issue_number = repo_svc.parse_github_url(ctx.issue_url)
    ctx.owner = owner
    ctx.repo = repo
    ctx.repo_full_name = f"{owner}/{repo}"
    ctx.issue_number = issue_number
    console.print(f"  [accent]Repository:[/accent] {ctx.repo_full_name}")
    console.print(f"  [accent]Issue:[/accent] #{issue_number}")

    # 1b. Fetch issue info
    with console.status("[bold cyan]Fetching issue from GitHub..."):
        ctx.issue_info = await repo_svc.get_github_issue(owner, repo, issue_number)

    render_key_value_panel(
        {
            "Title": ctx.issue_info.title,
            "State": ctx.issue_info.state,
            "Labels": ", ".join(ctx.issue_info.labels) if ctx.issue_info.labels else "none",
            "Assignees": ", ".join(ctx.issue_info.assignees) if ctx.issue_info.assignees else "none",
        },
        title=f"Issue #{issue_number}",
        border="cyan",
    )

    # 1c. Fetch repo info
    with console.status("[bold cyan]Fetching repository info..."):
        ctx.repo_info = await repo_svc.get_repository_info(ctx.repo_full_name)

    render_key_value_panel(
        {
            "Language": ctx.repo_info.get("language", "?"),
            "Stars": ctx.repo_info.get("stars", 0),
            "Default Branch": ctx.repo_info.get("default_branch", "?"),
            "Open Issues": ctx.repo_info.get("open_issues", 0),
        },
        title="Repository Info",
        border="blue",
    )

    # 1d. Check ingestion status — auto-ingest if needed
    ctx.repo_status = state_mgr.get_repository_status(ctx.repo_full_name)

    if not ctx.repo_status or ctx.repo_status.overall_status.value != "completed":
        console.print(
            "\n[warning]Repository not fully ingested. Starting auto-ingestion...[/warning]"
        )
        await _auto_ingest(ingestion_svc, ctx.repo_full_name)
        ctx.repo_status = state_mgr.get_repository_status(ctx.repo_full_name)
    else:
        console.print(
            f"  [success]Repository ingested[/success]  "
            f"[dim]({ctx.repo_status.total_documents} docs, "
            f"{len(ctx.repo_status.collections)} collections)[/dim]"
        )

    # 1e. Load learnings
    try:
        results = await asyncio.to_thread(
            learning_svc.search_learnings, ctx.repo_full_name, ctx.issue_info.title
        )
        ctx.learnings = results
        if results:
            render_search_results(results, title="Prior Learnings")
        else:
            console.print("  [dim]No prior learnings found for this repository.[/dim]")
    except Exception as e:
        logger.debug(f"Learnings search skipped: {e}")
        console.print("  [dim]Learnings unavailable.[/dim]")


async def _auto_ingest(ingestion_svc, repo_name: str):
    """Run 4-step ingestion with progress bars."""
    steps = [
        ("Documentation", "ingest_documentation"),
        ("Source Code", "ingest_code"),
        ("Issues", "ingest_issues"),
        ("Pull Requests", "ingest_prs"),
    ]

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        overall = progress.add_task("[bold]Ingesting repository", total=len(steps))

        # Initialize ingestion
        try:
            await ingestion_svc.start_repository_ingestion(repo_name)
        except Exception:
            pass  # may already exist

        for step_name, method_name in steps:
            task_id = progress.add_task(f"  {step_name}", total=1)
            try:
                method = getattr(ingestion_svc, method_name)
                await method(repo_name)
                progress.update(task_id, completed=1)
            except Exception as e:
                progress.update(
                    task_id, completed=1,
                    description=f"  {step_name} [red](failed: {str(e)[:40]})[/red]",
                )
            progress.update(overall, advance=1)

    print_success("Auto-ingestion complete.")


# ---------------------------------------------------------------------------
# Phase 2: Understand the Bug
# ---------------------------------------------------------------------------

async def phase_understand_bug(services: dict, ctx) -> None:
    """Run AI analysis on the issue."""

    analysis_svc = services["analysis"]

    with console.status("[bold cyan]Running AI analysis (this may take 15-60s)..."):
        ctx.analysis_result = await analysis_svc.analyze_github_issue(ctx.issue_url)

    if not ctx.analysis_result.success:
        print_error(f"Analysis failed: {ctx.analysis_result.error_message}")
        return

    analysis = ctx.analysis_result.analysis or {}

    # Summary table
    render_key_value_panel(
        {
            "Summary": analysis.get("summary", "N/A"),
            "Root Cause": analysis.get("root_cause", "N/A"),
            "Complexity": f"{analysis.get('complexity', 'N/A')}/5",
            "Confidence": analysis.get("confidence", "N/A"),
            "Similar Issues": ", ".join(analysis.get("similar_issues", [])) or "none",
        },
        title="Analysis Results",
        border="green",
    )

    # Proposed solution
    solution = analysis.get("proposed_solution", "")
    if solution:
        console.print(Panel(
            solution,
            title="[bold]Proposed Solution[/bold]",
            border_style="yellow",
        ))


# ---------------------------------------------------------------------------
# Phase 3: Architecture Understanding
# ---------------------------------------------------------------------------

async def phase_architecture(services: dict, ctx) -> None:
    """Display architecture context from repo info and analysis."""

    analysis_svc = services["analysis"]

    with console.status("[bold cyan]Loading repository structure..."):
        structure = await analysis_svc.get_repository_structure_summary(ctx.repo_full_name)

    if structure.get("available"):
        info = structure.get("repo_info", {})
        render_key_value_panel(
            {
                "Language": info.get("language", "?"),
                "Total Documents": structure.get("total_documents", 0),
                "Collections": ", ".join(structure.get("collections", [])) or "-",
                "Ingestion Status": structure.get("ingestion_status", "?"),
            },
            title="Knowledge Base",
            border="blue",
        )

        steps = structure.get("steps_completed", {})
        if steps:
            table = Table(title="Ingestion Steps", show_lines=True)
            table.add_column("Step", style="bold")
            table.add_column("Status")
            for step_name, completed in steps.items():
                status = "[green]completed[/green]" if completed else "[yellow]pending[/yellow]"
                table.add_row(step_name, status)
            console.print(table)
    else:
        console.print(f"  [dim]Structure info unavailable: {structure.get('error', 'unknown')}[/dim]")

    # Show relevant subsystems from analysis
    if ctx.analysis_result and ctx.analysis_result.success:
        analysis = ctx.analysis_result.analysis or {}
        root_cause = analysis.get("root_cause", "")
        if root_cause:
            console.print(Panel(
                root_cause,
                title="[bold]Relevant Subsystem (from root cause)[/bold]",
                border_style="magenta",
            ))


# ---------------------------------------------------------------------------
# Phase 4: Code Investigation
# ---------------------------------------------------------------------------

async def phase_code_investigation(services: dict, ctx) -> None:
    """Show affected files and suggest grep commands."""

    learning_svc = services["learning"]

    if not ctx.analysis_result or not ctx.analysis_result.success:
        console.print("  [dim]Skipped — no analysis available.[/dim]")
        return

    analysis = ctx.analysis_result.analysis or {}
    files = analysis.get("affected_files", [])

    render_file_table(files)

    # Suggest grep commands
    if files:
        file_paths = []
        for f in files:
            if isinstance(f, dict):
                file_paths.append(f.get("file_path", f.get("filePath", "")))
            elif isinstance(f, str):
                file_paths.append(f)

        grep_cmds = []
        for fp in file_paths[:5]:
            if fp:
                grep_cmds.append(f'rg -n "TODO|FIXME|HACK" {fp}')

        if grep_cmds:
            console.print(Panel(
                "\n".join(grep_cmds),
                title="[bold]Suggested Search Commands[/bold]",
                border_style="yellow",
            ))

    # Search learnings for code patterns
    try:
        results = await asyncio.to_thread(
            learning_svc.search_learnings,
            ctx.repo_full_name,
            "code patterns implementation conventions",
        )
        if results:
            render_search_results(results, title="Related Code Patterns")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Phase 5: Hypothesis Testing
# ---------------------------------------------------------------------------

async def phase_hypothesis_testing(services: dict, ctx) -> None:
    """Present hypotheses from analysis with confidence levels."""

    learning_svc = services["learning"]

    if not ctx.analysis_result or not ctx.analysis_result.success:
        console.print("  [dim]Skipped — no analysis available.[/dim]")
        return

    analysis = ctx.analysis_result.analysis or {}

    # Build hypotheses from analysis data
    hypotheses = []

    root_cause = analysis.get("root_cause", "")
    if root_cause:
        hypotheses.append({
            "text": f"Primary: {root_cause}",
            "confidence": analysis.get("confidence", "medium"),
        })

    solution = analysis.get("proposed_solution", "")
    if solution:
        hypotheses.append({
            "text": f"Fix approach: {solution[:200]}",
            "confidence": "medium",
        })

    # Add interpretations if present
    for interp in analysis.get("interpretations", []):
        if isinstance(interp, str):
            hypotheses.append({"text": interp, "confidence": "low"})
        elif isinstance(interp, dict):
            hypotheses.append({
                "text": interp.get("description", str(interp)),
                "confidence": interp.get("confidence", "low"),
            })

    if not hypotheses:
        console.print("  [dim]No hypotheses could be extracted from analysis.[/dim]")
        return

    for i, h in enumerate(hypotheses, 1):
        render_hypothesis_panel(h["text"], i, h.get("confidence", "medium"))

        # Search learnings per hypothesis
        try:
            results = await asyncio.to_thread(
                learning_svc.search_learnings,
                ctx.repo_full_name,
                h["text"][:200],
            )
            if results:
                render_search_results(results, title=f"Evidence for Hypothesis {i}")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Phase 6: Key Files
# ---------------------------------------------------------------------------

async def phase_key_files(services: dict, ctx) -> None:
    """Show priority-ordered files and pre-PR checklist."""

    learning_svc = services["learning"]

    if not ctx.analysis_result or not ctx.analysis_result.success:
        console.print("  [dim]Skipped — no analysis available.[/dim]")
        return

    analysis = ctx.analysis_result.analysis or {}
    files = analysis.get("affected_files", [])

    if files:
        # Priority table
        table = Table(title="Key Files (Priority Order)", show_lines=True, expand=True)
        table.add_column("Priority", style="bold", width=8)
        table.add_column("File", style="cyan", ratio=2)
        table.add_column("Reason", ratio=3)

        for i, f in enumerate(files):
            priority = f"P{min(i, 3)}"
            p_style = {0: "bold red", 1: "bold yellow", 2: "yellow", 3: "dim"}.get(min(i, 3), "dim")
            if isinstance(f, dict):
                table.add_row(
                    f"[{p_style}]{priority}[/{p_style}]",
                    f.get("file_path", f.get("filePath", "?")),
                    (f.get("explanation", f.get("description", "")))[:80],
                )
            elif isinstance(f, str):
                table.add_row(f"[{p_style}]{priority}[/{p_style}]", f, "")
        console.print(table)

        # Pre-PR checklist
        file_paths = []
        for f in files:
            if isinstance(f, dict):
                file_paths.append(f.get("file_path", f.get("filePath", "")))
            elif isinstance(f, str):
                file_paths.append(f)

        try:
            checklist = await asyncio.to_thread(
                learning_svc.get_pre_pr_checklist,
                ctx.repo_full_name,
                file_paths,
            )
            ctx.pre_pr_checklist = checklist

            # Render checklists
            for cl_name, items in checklist.get("applicable_checklists", {}).items():
                render_checklist(items, title=f"Checklist: {cl_name}")

        except Exception as e:
            logger.debug(f"Pre-PR checklist skipped: {e}")
    else:
        console.print("  [dim]No key files identified.[/dim]")


# ---------------------------------------------------------------------------
# Phase 7: Search Queries
# ---------------------------------------------------------------------------

async def phase_search_queries(services: dict, ctx) -> None:
    """Derive semantic search queries and show results."""

    learning_svc = services["learning"]

    if not ctx.issue_info:
        console.print("  [dim]Skipped — no issue info.[/dim]")
        return

    # Derive queries from issue keywords + analysis
    queries = []
    queries.append(ctx.issue_info.title)

    if ctx.analysis_result and ctx.analysis_result.success:
        analysis = ctx.analysis_result.analysis or {}
        rc = analysis.get("root_cause", "")
        if rc:
            queries.append(rc[:200])
        sol = analysis.get("proposed_solution", "")
        if sol:
            queries.append(sol[:200])

    # Show queries
    console.print(Panel(
        "\n".join(f"  {i}. {q}" for i, q in enumerate(queries, 1)),
        title="[bold]Semantic Search Queries[/bold]",
        border_style="cyan",
    ))

    # Run searches
    for q in queries[:3]:
        try:
            results = await asyncio.to_thread(
                learning_svc.search_learnings,
                ctx.repo_full_name,
                q,
            )
            if results:
                render_search_results(results, title=f"Results: {q[:60]}...")
        except Exception:
            pass

    # Suggested grep/ripgrep commands
    if ctx.analysis_result and ctx.analysis_result.success:
        analysis = ctx.analysis_result.analysis or {}
        keywords = []
        for f in analysis.get("affected_files", []):
            if isinstance(f, dict):
                fp = f.get("file_path", "")
                if fp:
                    keywords.append(fp.split("/")[-1].replace(".py", "").replace(".rs", ""))

        if keywords:
            cmds = [f'rg -n "{kw}" .' for kw in keywords[:5]]
            console.print(Panel(
                "\n".join(cmds),
                title="[bold]Grep Commands[/bold]",
                border_style="yellow",
            ))


# ---------------------------------------------------------------------------
# Phase 8: Related Issues & PRs
# ---------------------------------------------------------------------------

async def phase_related_issues(services: dict, ctx) -> None:
    """Show similar issues and PR takeaways."""

    learning_svc = services["learning"]

    if not ctx.analysis_result or not ctx.analysis_result.success:
        console.print("  [dim]Skipped — no analysis available.[/dim]")
        return

    analysis = ctx.analysis_result.analysis or {}

    # Similar issues from analysis
    similar = analysis.get("similar_issues", [])
    if similar:
        console.print(Panel(
            "\n".join(f"  - {s}" for s in similar),
            title="[bold]Similar Issues[/bold]",
            border_style="cyan",
        ))
    else:
        console.print("  [dim]No similar issues identified in analysis.[/dim]")

    # PR takeaways from learnings
    try:
        results = await asyncio.to_thread(
            learning_svc.search_learnings,
            ctx.repo_full_name,
            ctx.issue_info.title if ctx.issue_info else "bug fix",
            5,
            "pr_takeaway",
        )
        if results:
            render_search_results(results, title="PR Takeaways")
        else:
            console.print("  [dim]No PR takeaways found.[/dim]")
    except Exception:
        console.print("  [dim]PR takeaway search unavailable.[/dim]")


# ---------------------------------------------------------------------------
# Phase 9: Root Cause Locations
# ---------------------------------------------------------------------------

async def phase_root_cause(services: dict, ctx) -> None:
    """Synthesize root cause with file locations from context."""

    if not ctx.analysis_result or not ctx.analysis_result.success:
        console.print("  [dim]Skipped — no analysis available.[/dim]")
        return

    analysis = ctx.analysis_result.analysis or {}
    root_cause = analysis.get("root_cause", "N/A")
    confidence = analysis.get("confidence", "medium")
    files = analysis.get("affected_files", [])

    # Confidence color
    conf_color = {"high": "green", "medium": "yellow", "low": "red"}.get(
        confidence.lower() if isinstance(confidence, str) else "medium", "yellow"
    )

    console.print(Panel(
        f"[bold]Root Cause:[/bold] {root_cause}\n\n"
        f"[bold]Confidence:[/bold] [{conf_color}]{confidence}[/{conf_color}]",
        title="[bold]Root Cause Analysis[/bold]",
        border_style=conf_color,
    ))

    # File location cards
    if files:
        for f in files:
            if isinstance(f, dict):
                fp = f.get("file_path", f.get("filePath", "?"))
                lines = f.get("line_numbers", f.get("lines", "?"))
                desc = f.get("explanation", f.get("description", ""))
                console.print(Panel(
                    f"[cyan]{fp}[/cyan]  lines: {lines}\n{desc}",
                    border_style="dim",
                    padding=(0, 2),
                ))


# ---------------------------------------------------------------------------
# Phase 10: Verification & Patch
# ---------------------------------------------------------------------------

async def phase_verification(services: dict, ctx) -> None:
    """Show proposed fix, verification checklist, and optional patch generation."""

    patch_svc = services["patch"]
    learning_svc = services["learning"]

    if not ctx.analysis_result or not ctx.analysis_result.success:
        console.print("  [dim]Skipped — no analysis available.[/dim]")
        return

    analysis = ctx.analysis_result.analysis or {}
    issue_desc = ctx.issue_info.body if ctx.issue_info else ""

    # Implementation guidance
    with console.status("[bold cyan]Getting implementation guidance..."):
        guidance = await patch_svc.get_implementation_guidance(ctx.repo_full_name, issue_desc)

    if guidance and not guidance.get("error"):
        render_key_value_panel(
            {
                "Issue Type": guidance.get("issue_type", "general"),
                "Approach": guidance.get("general_approach", "N/A"),
            },
            title="Implementation Guidance",
            border="yellow",
        )

        suggestions = guidance.get("specific_suggestions", [])
        if suggestions:
            render_checklist(suggestions, title="Specific Suggestions")

        next_steps = guidance.get("next_steps", [])
        if next_steps:
            render_checklist(next_steps, title="Next Steps")

    # Verification checklist from learnings (reuse Phase 6 data if available)
    try:
        if ctx.pre_pr_checklist:
            checklist = ctx.pre_pr_checklist
        else:
            checklist = await asyncio.to_thread(
                learning_svc.get_pre_pr_checklist,
                ctx.repo_full_name,
            )
            ctx.pre_pr_checklist = checklist

        # NEVER DO warnings
        warnings = checklist.get("never_do_warnings", [])
        render_never_do_warnings(warnings)

        # Applicable checklists
        for cl_name, items in checklist.get("applicable_checklists", {}).items():
            render_checklist(items, title=f"Pre-PR: {cl_name}")
    except Exception:
        pass

    # Optional patch generation
    console.print()
    if confirm("Generate code patches now?", default=False):
        with console.status("[bold cyan]Generating patches (this may take a while)..."):
            ctx.patch_result = await patch_svc.generate_code_patch(
                issue_desc, ctx.repo_full_name
            )

        if ctx.patch_result and ctx.patch_result.success:
            # Summary
            if ctx.patch_result.summary_of_changes:
                console.print(Panel(
                    ctx.patch_result.summary_of_changes,
                    title="[bold]Summary of Changes[/bold]",
                    border_style="green",
                ))

            # Per-file diffs
            for i, patch in enumerate(ctx.patch_result.files_to_update, 1):
                console.print(
                    f"\n[bold accent]File {i}: {patch.file_path}[/bold accent] ({patch.operation})"
                )
                if patch.patch_content:
                    syntax = Syntax(patch.patch_content, "diff", theme="monokai", line_numbers=True)
                    console.print(Panel(syntax, border_style="cyan"))
        else:
            err = ctx.patch_result.error_message if ctx.patch_result else "Unknown error"
            print_error(f"Patch generation failed: {err}")
    else:
        console.print("  [dim]Patch generation skipped.[/dim]")
