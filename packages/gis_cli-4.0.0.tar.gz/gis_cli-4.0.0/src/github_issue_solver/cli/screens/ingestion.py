"""Ingestion screen - 4-step repository ingestion with progress tracking."""

import time
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.panel import Panel
from rich.table import Table

from ..utils import console, print_error, print_success, prompt_input, confirm


class IngestionScreen:
    """Interactive repository ingestion with progress bars."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services
        self.ingestion_service = services['ingestion']

    async def run(self):
        """Run ingestion workflow."""
        console.print(Panel("[bold]Repository Ingestion[/bold]", border_style="blue"))

        repo_name = prompt_input("Enter repository (owner/repo)")
        if not repo_name or "/" not in repo_name:
            print_error("Invalid format. Use owner/repo (e.g., facebook/react)")
            return

        if not confirm(f"Ingest '{repo_name}'?"):
            return

        steps = [
            ("Documentation", "ingest_docs"),
            ("Source Code", "ingest_code"),
            ("Issues", "ingest_issues"),
            ("Pull Requests", "ingest_prs"),
        ]

        results = {}
        start_time = time.time()

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            overall = progress.add_task("[bold]Overall Progress", total=len(steps))

            for step_name, method_name in steps:
                task_id = progress.add_task(f"  {step_name}", total=1)
                try:
                    result = await self._run_step(method_name, repo_name)
                    results[step_name] = result
                    progress.update(task_id, completed=1)
                    progress.update(overall, advance=1)
                except Exception as e:
                    results[step_name] = {"error": str(e)}
                    progress.update(task_id, completed=1, description=f"  {step_name} [red](failed)[/red]")
                    progress.update(overall, advance=1)

        duration = time.time() - start_time
        self._print_summary(repo_name, results, duration)

    async def _run_step(self, method_name: str, repo_name: str):
        """Run a single ingestion step."""
        svc = self.ingestion_service
        if method_name == "ingest_docs":
            return await svc.ingest_documentation(repo_name)
        elif method_name == "ingest_code":
            return await svc.ingest_code(repo_name)
        elif method_name == "ingest_issues":
            return await svc.ingest_issues(repo_name)
        elif method_name == "ingest_prs":
            return await svc.ingest_prs(repo_name)

    def _print_summary(self, repo_name: str, results: dict, duration: float):
        """Print ingestion summary."""
        table = Table(title=f"Ingestion Summary: {repo_name}", show_lines=True)
        table.add_column("Step", style="bold")
        table.add_column("Status")
        table.add_column("Documents")

        total_docs = 0
        for step_name, result in results.items():
            if isinstance(result, dict) and "error" in result:
                table.add_row(step_name, "[red]Failed[/red]", result["error"][:50])
            else:
                doc_count = getattr(result, 'documents_processed', 0) if result else 0
                total_docs += doc_count
                table.add_row(step_name, "[green]OK[/green]", str(doc_count))

        console.print(table)
        console.print(f"\n[dim]Total: {total_docs} documents in {duration:.1f}s[/dim]")
        print_success(f"Repository '{repo_name}' ingestion complete!")
