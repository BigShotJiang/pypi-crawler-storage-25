"""Investigation pipeline orchestrator — runs the 10-phase investigation."""

import time
from datetime import datetime
from loguru import logger

from ..utils import console, print_error, print_divider
from ..models import InvestigationContext
from ..widgets.phase_display import (
    render_phase_banner,
    render_phase_complete,
    render_phase_error,
    render_investigation_summary,
)
from .investigation_phases import (
    phase_setup,
    phase_understand_bug,
    phase_architecture,
    phase_code_investigation,
    phase_hypothesis_testing,
    phase_key_files,
    phase_search_queries,
    phase_related_issues,
    phase_root_cause,
    phase_verification,
)


class InvestigationPipeline:
    """Runs a structured 10-phase investigation on a GitHub issue."""

    PHASES = [
        ("Setup & Learning", phase_setup),
        ("Understand the Bug", phase_understand_bug),
        ("Architecture Understanding", phase_architecture),
        ("Code Investigation", phase_code_investigation),
        ("Hypothesis Testing", phase_hypothesis_testing),
        ("Key Files", phase_key_files),
        ("Search Queries", phase_search_queries),
        ("Related Issues & PRs", phase_related_issues),
        ("Root Cause", phase_root_cause),
        ("Verification & Patch", phase_verification),
    ]

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services

    async def run(self, issue_url: str):
        """Execute the full investigation pipeline."""

        ctx = InvestigationContext(issue_url=issue_url, started_at=datetime.now())

        # Header
        print_divider()
        console.print(
            "\n[bold white on blue]  Investigation Pipeline  [/bold white on blue]"
            f"  [dim]{issue_url}[/dim]\n"
        )

        skip_next = False

        for idx, (name, phase_func) in enumerate(self.PHASES, 1):
            # Skip logic
            if skip_next:
                skip_next = False
                console.print(f"  [dim]Phase {idx}: {name} — skipped[/dim]")
                continue

            render_phase_banner(idx, name)

            start = time.time()
            try:
                await phase_func(self.services, ctx)
                elapsed = time.time() - start
                ctx.phase_timings[f"{idx}. {name}"] = elapsed
                render_phase_complete(idx, name, elapsed)

            except KeyboardInterrupt:
                console.print("\n[dim]Investigation interrupted.[/dim]")
                break

            except Exception as e:
                elapsed = time.time() - start
                ctx.phase_timings[f"{idx}. {name}"] = elapsed
                logger.exception(f"Phase {idx} error")
                render_phase_error(idx, name, str(e))

                # Ask whether to continue
                try:
                    choice = console.input(
                        "\n[bold]Continue? (Enter=yes / q=quit):[/bold] "
                    ).strip().lower()
                    if choice == "q":
                        break
                except (KeyboardInterrupt, EOFError):
                    break

            # Semi-interactive pause (skip for last phase)
            if idx < len(self.PHASES):
                try:
                    choice = console.input(
                        "\n[dim]Enter=continue | s=skip next | q=stop > [/dim]"
                    ).strip().lower()
                    if choice == "q":
                        break
                    elif choice == "s":
                        skip_next = True
                except (KeyboardInterrupt, EOFError):
                    break

        # Final summary
        render_investigation_summary(ctx)
        return ctx
