"""Main menu screen — issue-URL-centric hub with letter-key navigation."""

import re
import sys
from rich.panel import Panel
from rich.table import Table

from ..utils import console, print_status_header, print_error


GITHUB_ISSUE_RE = re.compile(r"https://github\.com/[^/]+/[^/]+/issues/\d+")


class MainMenuScreen:
    """Interactive main menu for the CLI app."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services

    async def run(self):
        """Run the main menu loop."""
        while True:
            try:
                self._print_header()
                self._print_menu()
                choice = console.input("\n[bold]> [/bold]").strip()
                await self._handle_choice(choice)
            except KeyboardInterrupt:
                console.print("\n[dim]Goodbye![/dim]")
                sys.exit(0)

    def _print_header(self):
        """Print status header."""
        llm_svc = self.services.get("llm")
        provider = llm_svc.provider_name if llm_svc else "gemini"
        model = llm_svc.model_name if llm_svc else "gemini-2.5-flash"
        license_tier = "trial"
        if self.config.license_info:
            license_tier = self.config.license_info.tier

        state_mgr = self.services.get("state_manager")
        repos_count = 0
        if state_mgr:
            try:
                repos = state_mgr.list_repositories()
                repos_count = len(repos) if repos else 0
            except Exception:
                pass

        print_status_header(provider, model, license_tier, repos_count)

    def _print_menu(self):
        """Print the new letter-key menu."""
        menu_text = (
            "[bold accent][I][/bold accent] Investigate Issue     [dim]Full 10-phase pipeline[/dim]\n"
            "    [dim]Paste a GitHub issue URL to start[/dim]\n"
            "\n"
            "[bold accent][R][/bold accent] Manage Repositories   "
            "[bold accent][H][/bold accent] Health Dashboard\n"
            "[bold accent][L][/bold accent] Browse Learnings      "
            "[bold accent][S][/bold accent] Settings\n"
            "[bold accent][Q][/bold accent] Quit"
        )
        console.print(Panel(
            menu_text,
            title="[bold]GitHub Issue Solver v3.0[/bold]",
            border_style="blue",
            padding=(1, 2),
        ))

    async def _handle_choice(self, choice: str):
        """Dispatch based on letter key or auto-detect a pasted URL."""
        choice_upper = choice.upper()

        # Auto-detect pasted GitHub issue URL
        if GITHUB_ISSUE_RE.search(choice):
            url = GITHUB_ISSUE_RE.search(choice).group(0)
            await self._launch_investigation(url)
            return

        try:
            if choice_upper == "I":
                url = console.input("[bold]GitHub issue URL: [/bold]").strip()
                if not url or not GITHUB_ISSUE_RE.search(url):
                    print_error(
                        "Invalid URL.",
                        "Format: https://github.com/owner/repo/issues/123",
                    )
                    return
                await self._launch_investigation(url)

            elif choice_upper == "R":
                from .repo_manager import RepoManagerScreen
                screen = RepoManagerScreen(self.config, self.services)
                await screen.run()

            elif choice_upper == "H":
                from .health import HealthScreen
                screen = HealthScreen(self.config, self.services)
                await screen.run()

            elif choice_upper == "L":
                from .learnings import LearningsScreen
                screen = LearningsScreen(self.config, self.services)
                await screen.run()

            elif choice_upper == "S":
                from .settings import SettingsScreen
                screen = SettingsScreen(self.config, self.services)
                await screen.run()

            elif choice_upper == "Q":
                console.print("[dim]Goodbye![/dim]")
                sys.exit(0)

            else:
                console.print("[warning]Invalid option. Press I, R, H, L, S, Q or paste an issue URL.[/warning]")

        except KeyboardInterrupt:
            console.print("\n[dim]Returning to main menu...[/dim]")
        except Exception as e:
            print_error(str(e), "Check logs for details.")

    async def _launch_investigation(self, url: str):
        """Launch the investigation pipeline."""
        from .investigation import InvestigationPipeline
        pipeline = InvestigationPipeline(self.config, self.services)
        await pipeline.run(url)
