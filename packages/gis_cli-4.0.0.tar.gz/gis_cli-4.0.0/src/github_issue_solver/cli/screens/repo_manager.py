"""Repository manager screen — combines ingestion + status views."""

import time
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn

from ..utils import console, print_error, print_success, prompt_input, confirm


class RepoManagerScreen:
    """Manage ingested repositories: view status, ingest new, retry failed."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services

    async def run(self):
        """Run the repo manager loop."""
        while True:
            console.print(Panel("[bold]Repository Manager[/bold]", border_style="blue"))
            self._show_repos()

            console.print(
                "\n[bold accent][N][/bold accent] Ingest new repo  "
                "[bold accent][B][/bold accent] Back to menu"
            )
            choice = console.input("\n[bold]> [/bold]").strip().upper()

            if choice == "N":
                await self._ingest_new()
            elif choice == "B" or choice == "":
                return
            else:
                console.print("[warning]Invalid option.[/warning]")

    def _show_repos(self):
        """Display table of ingested repositories."""
        state_mgr = self.services.get("state_manager")
        if not state_mgr:
            print_error("State manager not available.")
            return

        try:
            repos = state_mgr.list_repositories()
        except Exception as e:
            print_error(f"Failed to list repositories: {e}")
            return

        if not repos:
            console.print("[dim]No repositories ingested yet.[/dim]")
            return

        table = Table(title="Ingested Repositories", show_lines=True, expand=True)
        table.add_column("#", style="dim", width=3)
        table.add_column("Repository", style="bold cyan", ratio=2)
        table.add_column("Status", width=12)
        table.add_column("Docs", justify="right", width=6)
        table.add_column("Completion", justify="right", width=10)

        for i, repo_name in enumerate(repos, 1):
            try:
                status = state_mgr.get_repository_status(repo_name)
                if status:
                    overall = status.overall_status.value
                    style = "green" if overall == "completed" else "yellow" if overall != "error" else "red"
                    pct = status.get_completion_percentage()
                    table.add_row(
                        str(i),
                        repo_name,
                        f"[{style}]{overall}[/{style}]",
                        str(status.total_documents),
                        f"{pct:.0f}%",
                    )
                else:
                    table.add_row(str(i), repo_name, "[dim]unknown[/dim]", "-", "-")
            except Exception:
                table.add_row(str(i), repo_name, "[red]error[/red]", "-", "-")

        console.print(table)

    async def _ingest_new(self):
        """Ingest a new repository with progress bars."""
        repo_name = prompt_input("Enter repository (owner/repo)")
        if not repo_name or "/" not in repo_name:
            print_error("Invalid format. Use owner/repo (e.g., facebook/react)")
            return

        if not confirm(f"Ingest '{repo_name}'?"):
            return

        ingestion_svc = self.services["ingestion"]

        steps = [
            ("Documentation", "ingest_documentation"),
            ("Source Code", "ingest_code"),
            ("Issues", "ingest_issues"),
            ("Pull Requests", "ingest_prs"),
        ]

        start_time = time.time()

        # Initialize
        try:
            await ingestion_svc.start_repository_ingestion(repo_name)
        except Exception:
            pass

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            overall = progress.add_task("[bold]Overall Progress", total=len(steps))

            for step_name, method_name in steps:
                task_id = progress.add_task(f"  {step_name}", total=1)
                try:
                    method = getattr(ingestion_svc, method_name)
                    await method(repo_name)
                    progress.update(task_id, completed=1)
                except Exception as e:
                    progress.update(
                        task_id, completed=1,
                        description=f"  {step_name} [red](failed)[/red]",
                    )
                progress.update(overall, advance=1)

        duration = time.time() - start_time
        print_success(f"Repository '{repo_name}' ingestion complete in {duration:.1f}s!")
