"""Health dashboard screen."""

from rich.panel import Panel
from rich.table import Table

from ..utils import console, print_error


class HealthScreen:
    """System health dashboard."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services

    async def run(self):
        """Display health dashboard."""
        console.print(Panel("[bold]Health Dashboard[/bold]", border_style="blue"))

        health_svc = self.services.get('health')
        if not health_svc:
            print_error("Health service not available.")
            return

        try:
            health_data = await health_svc.get_health_status()
        except Exception as e:
            print_error(f"Failed to get health status: {e}")
            return

        # Overall status (HealthStatus is a dataclass, not a dict)
        overall = health_data.status
        style = "green" if overall == "healthy" else "yellow" if overall == "degraded" else "red"
        console.print(f"\n[bold]Overall Status:[/bold] [{style}]{overall}[/{style}]")

        # Component table (checks is Dict[str, bool], details is Dict[str, Any])
        checks = health_data.checks or {}
        details = health_data.details or {}
        if checks:
            table = Table(title="Components", show_lines=True)
            table.add_column("Component", style="bold")
            table.add_column("Status")
            table.add_column("Details")

            for name, ok in checks.items():
                s = "green" if ok else "red"
                status_text = "healthy" if ok else "unhealthy"
                detail_text = str(details.get(name, "")) if details else ""
                table.add_row(name, f"[{s}]{status_text}[/{s}]", detail_text)

            console.print(table)

        # Config status
        config_status = self.config.get_status()
        limits = config_status.get("limits", {})
        if limits:
            limit_table = Table(title="Configuration Limits", show_lines=True)
            limit_table.add_column("Setting", style="bold")
            limit_table.add_column("Value", justify="right")
            for key, val in limits.items():
                limit_table.add_row(key, str(val))
            console.print(limit_table)

        console.input("\n[dim]Press Enter to return...[/dim]")
