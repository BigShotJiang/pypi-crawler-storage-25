"""Analysis screen - Issue analysis display with structured panels."""

import json
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax

from ..utils import console, print_error, print_success, prompt_input


class AnalysisScreen:
    """Interactive issue analysis display."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services
        self.analysis_service = services['analysis']

    async def run(self):
        """Run analysis workflow."""
        console.print(Panel("[bold]Issue Analysis[/bold]", border_style="blue"))

        issue_url = prompt_input("Enter GitHub issue URL")
        if not issue_url or "github.com" not in issue_url:
            print_error("Invalid GitHub issue URL. Format: https://github.com/owner/repo/issues/123")
            return

        console.print("[dim]Analyzing issue...[/dim]")

        try:
            result = await self.analysis_service.analyze_github_issue(issue_url)
        except Exception as e:
            print_error(f"Analysis failed: {e}")
            return

        if not result.success:
            print_error(f"Analysis failed: {result.error_message}")
            return

        self._display_result(result)
        print_success("Analysis complete!")

    def _display_result(self, result):
        """Display analysis result with rich formatting."""
        analysis = result.analysis or {}
        issue = result.issue_info

        # Issue metadata
        if issue:
            meta_table = Table(show_header=False, show_edge=False, padding=(0, 2))
            meta_table.add_column(style="bold")
            meta_table.add_column()
            meta_table.add_row("Issue", f"#{issue.number} - {issue.title}")
            meta_table.add_row("Repository", issue.repository)
            meta_table.add_row("State", issue.state)
            meta_table.add_row("URL", issue.url)
            console.print(Panel(meta_table, title="[bold]Issue Info[/bold]", border_style="cyan"))

        # Summary & Root Cause
        summary = analysis.get("summary", "N/A")
        root_cause = analysis.get("root_cause", "N/A")
        confidence = analysis.get("confidence", "N/A")
        complexity = analysis.get("complexity", "N/A")

        console.print(Panel(
            f"[bold]Summary:[/bold] {summary}\n\n"
            f"[bold]Root Cause:[/bold] {root_cause}\n\n"
            f"[bold]Confidence:[/bold] {confidence}  |  [bold]Complexity:[/bold] {complexity}/5",
            title="[bold]Analysis[/bold]",
            border_style="green",
        ))

        # Affected Files
        files = analysis.get("affected_files", [])
        if files:
            file_table = Table(title="Affected Files", show_lines=True)
            file_table.add_column("File", style="cyan")
            file_table.add_column("Lines")
            file_table.add_column("Details")

            for f in files:
                if isinstance(f, dict):
                    file_table.add_row(
                        f.get("file_path", "?"),
                        str(f.get("line_numbers", "?")),
                        f.get("explanation", f.get("description", ""))[:80],
                    )
            console.print(file_table)

        # Proposed Solution
        solution = analysis.get("proposed_solution", "N/A")
        console.print(Panel(solution, title="[bold]Proposed Solution[/bold]", border_style="yellow"))
