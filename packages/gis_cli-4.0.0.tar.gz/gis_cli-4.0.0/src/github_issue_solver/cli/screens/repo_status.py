"""Repository status screen - Shows ingested repositories and their completion."""

from rich.panel import Panel
from rich.table import Table

from ..utils import console, print_error


class RepoStatusScreen:
    """Display ingested repository status."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services

    async def run(self):
        """Show repository status overview."""
        console.print(Panel("[bold]Repository Status[/bold]", border_style="blue"))

        state_mgr = self.services.get('state_manager')
        if not state_mgr:
            print_error("State manager not available.")
            return

        try:
            repos = state_mgr.list_repositories()
        except Exception as e:
            print_error(f"Failed to list repositories: {e}")
            return

        if not repos:
            console.print("[dim]No repositories ingested yet. Use option 1 to ingest a repository.[/dim]")
            return

        table = Table(title="Ingested Repositories", show_lines=True)
        table.add_column("#", style="dim")
        table.add_column("Repository", style="bold cyan")
        table.add_column("Status")
        table.add_column("Documents", justify="right")
        table.add_column("Collections")

        for i, repo_name in enumerate(repos, 1):
            try:
                status = state_mgr.get_repository_status(repo_name)
                if status:
                    overall = status.overall_status.value
                    style = "green" if overall == "completed" else "yellow"
                    table.add_row(
                        str(i),
                        repo_name,
                        f"[{style}]{overall}[/{style}]",
                        str(status.total_documents),
                        ", ".join(status.collections) if status.collections else "-",
                    )
                else:
                    table.add_row(str(i), repo_name, "[dim]unknown[/dim]", "-", "-")
            except Exception:
                table.add_row(str(i), repo_name, "[red]error[/red]", "-", "-")

        console.print(table)
        console.input("\n[dim]Press Enter to return...[/dim]")
