"""Learnings screen - View and search stored learnings."""

import asyncio
from rich.panel import Panel

from ..utils import console, print_error, prompt_input


class LearningsScreen:
    """Browse and search learnings from the learning service."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services
        self.learning_service = services.get('learning')
        self.state_manager = services.get('state_manager')

    async def run(self):
        """Display learnings UI."""
        console.print(Panel("[bold]Learnings[/bold]", border_style="blue"))

        if not self.learning_service:
            print_error("Learning service not available.")
            return

        # Get repo name for scoped search
        repo_name = prompt_input("Enter repository (owner/repo) to search learnings for")
        if not repo_name or "/" not in repo_name:
            print_error("Invalid format. Use owner/repo")
            return

        query = prompt_input("Search query (or press Enter for general search)")
        if not query:
            query = "common patterns and solutions"

        try:
            # search_learnings is sync, run in thread
            results = await asyncio.to_thread(
                self.learning_service.search_learnings,
                repo_name, query
            )
        except Exception as e:
            print_error(f"Failed to fetch learnings: {e}")
            return

        if not results:
            console.print("[dim]No learnings found for this repository. Learnings are generated as you analyze issues.[/dim]")
            console.input("\n[dim]Press Enter to return...[/dim]")
            return

        # Display learnings
        for i, learning in enumerate(results, 1):
            if isinstance(learning, dict):
                title = learning.get("title", learning.get("pattern", f"Learning #{i}"))
                content = learning.get("content", learning.get("description", str(learning)))
                score = learning.get("score", "")
                subtitle = f" (relevance: {score:.2f})" if isinstance(score, (int, float)) else ""
                console.print(Panel(str(content), title=f"[bold]{title}{subtitle}[/bold]", border_style="cyan"))
            else:
                console.print(Panel(str(learning), title=f"[bold]Learning #{i}[/bold]", border_style="cyan"))

        console.input("\n[dim]Press Enter to return...[/dim]")
