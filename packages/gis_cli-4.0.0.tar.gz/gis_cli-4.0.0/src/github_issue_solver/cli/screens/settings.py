"""Settings screen - Reconfigure application settings."""

from rich.panel import Panel
from rich.table import Table

from ..utils import console, print_success, prompt_choice, confirm


class SettingsScreen:
    """Reconfigure application settings."""

    def __init__(self, config, services: dict):
        self.config = config
        self.services = services

    async def run(self):
        """Display settings UI."""
        console.print(Panel("[bold]Settings[/bold]", border_style="blue"))

        # Show current settings
        table = Table(title="Current Configuration", show_lines=True)
        table.add_column("Setting", style="bold")
        table.add_column("Value")

        llm_svc = self.services.get('llm')
        table.add_row("LLM Provider", llm_svc.provider_name if llm_svc else "unknown")
        table.add_row("LLM Model", llm_svc.model_name if llm_svc else "unknown")
        table.add_row("Embedding Provider", self.config.embedding_provider)
        table.add_row("Max Issues", str(self.config.max_issues))
        table.add_row("Max PRs", str(self.config.max_prs))
        table.add_row("Log Level", self.config.log_level)
        table.add_row("ChromaDB Dir", str(self.config.chroma_persist_dir))
        table.add_row("Patch Generation", str(self.config.enable_patch_generation))
        console.print(table)

        choice = prompt_choice(
            "What would you like to do?",
            ["Re-run setup wizard", "Back to menu"],
            default="Back to menu",
        )

        if "wizard" in choice.lower():
            from ..onboarding import run_onboarding
            run_onboarding()
            console.print("\n[warning]Restart the CLI to apply changes.[/warning]")

        elif "back" in choice.lower():
            return
