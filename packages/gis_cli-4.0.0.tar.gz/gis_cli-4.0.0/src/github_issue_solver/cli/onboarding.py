"""
First-run onboarding wizard.

Walks the user through configuring LLM provider, API keys, embedding provider,
GitHub PAT, and saves everything to .env.
"""

import os
from pathlib import Path

from rich.table import Table
from rich.panel import Panel

from .utils import (
    console, print_banner, print_success, print_error,
    prompt_choice, prompt_input, confirm,
)


def run_onboarding():
    """Run the interactive first-run setup wizard."""
    console.print(Panel(
        "[bold]Welcome to GitHub Issue Solver![/bold]\n\n"
        "Let's configure your environment. This will create/update a [cyan].env[/cyan] file\n"
        "in the project root with your API keys and preferences.",
        title="[bold magenta]Setup Wizard[/bold magenta]",
        border_style="magenta",
    ))

    env_values = {}

    # ----- Step 1: Choose LLM Provider -----
    console.print("\n[bold]Step 1/5:[/bold] Choose your LLM provider\n")

    table = Table(title="LLM Provider Comparison", show_lines=True)
    table.add_column("Feature", style="bold")
    table.add_column("Gemini", style="cyan")
    table.add_column("Claude", style="green")
    table.add_row("Provider", "Google", "Anthropic")
    table.add_row("Default Model", "gemini-2.5-flash", "claude-sonnet-4-20250514")
    table.add_row("Free Tier", "Yes (generous)", "No (paid)")
    table.add_row("Speed", "Fast", "Moderate")
    table.add_row("Code Quality", "Good", "Excellent")
    console.print(table)

    llm_provider = prompt_choice(
        "Select LLM provider:",
        ["Gemini (recommended)", "Claude"],
        default="Gemini (recommended)",
    )
    env_values["LLM_PROVIDER"] = "gemini" if "Gemini" in llm_provider else "claude"

    # Optional model override
    if confirm("Use default model?", default=True):
        env_values["LLM_MODEL_NAME"] = ""
    else:
        env_values["LLM_MODEL_NAME"] = prompt_input("Enter model name")

    # ----- Step 2: API Keys -----
    console.print("\n[bold]Step 2/5:[/bold] Enter API keys\n")

    if env_values["LLM_PROVIDER"] == "gemini":
        console.print("[dim]Get your Google API key from: https://makersuite.google.com/app/apikey[/dim]")
        env_values["GOOGLE_API_KEY"] = prompt_input("Google API Key", password=True)
    else:
        console.print("[dim]Get your Anthropic API key from: https://console.anthropic.com/settings/keys[/dim]")
        env_values["ANTHROPIC_API_KEY"] = prompt_input("Anthropic API Key", password=True)

    # ----- Step 3: Embedding Provider -----
    console.print("\n[bold]Step 3/5:[/bold] Choose embedding provider\n")

    embed_choice = prompt_choice(
        "Select embedding provider:",
        ["FastEmbed - offline, free (recommended)", "Google - cloud, uses API quota"],
        default="FastEmbed - offline, free (recommended)",
    )
    env_values["EMBEDDING_PROVIDER"] = "fastembed" if "FastEmbed" in embed_choice else "google"

    # If using Google embeddings + Claude LLM, need Google API key too
    if env_values["EMBEDDING_PROVIDER"] == "google" and env_values["LLM_PROVIDER"] == "claude":
        if "GOOGLE_API_KEY" not in env_values:
            console.print("[dim]Google API key needed for Google embeddings[/dim]")
            env_values["GOOGLE_API_KEY"] = prompt_input("Google API Key", password=True)

    # ----- Step 4: GitHub Token -----
    console.print("\n[bold]Step 4/5:[/bold] GitHub Personal Access Token\n")
    console.print("[dim]Get from: https://github.com/settings/tokens[/dim]")
    console.print("[dim]Required scopes: repo, read:org, read:user[/dim]")
    env_values["GITHUB_TOKEN"] = prompt_input("GitHub PAT", password=True)

    # ----- Step 5: Advanced Settings -----
    console.print("\n[bold]Step 5/5:[/bold] Advanced settings (optional)\n")

    if confirm("Configure advanced settings?", default=False):
        env_values["MAX_ISSUES"] = prompt_input("Max issues per ingestion", default="100")
        env_values["MAX_PRS"] = prompt_input("Max PRs per ingestion", default="15")
        env_values["LOG_LEVEL"] = prompt_choice(
            "Log level:", ["INFO", "DEBUG", "WARNING", "ERROR"], default="INFO"
        )
    else:
        env_values["MAX_ISSUES"] = "100"
        env_values["MAX_PRS"] = "15"
        env_values["LOG_LEVEL"] = "INFO"

    # ----- Summary -----
    console.print()
    summary_table = Table(title="Configuration Summary", show_lines=True)
    summary_table.add_column("Setting", style="bold")
    summary_table.add_column("Value")

    for key, value in env_values.items():
        display = _mask_key(value) if "KEY" in key or "TOKEN" in key else value
        summary_table.add_row(key, display or "(default)")

    console.print(summary_table)

    if not confirm("\nSave this configuration?", default=True):
        console.print("[warning]Setup cancelled. No changes saved.[/warning]")
        return

    # ----- Save to .env -----
    _save_env(env_values)
    print_success("Configuration saved to .env!")
    console.print("[dim]You can edit .env manually at any time, or run --mode cli again to reconfigure.[/dim]\n")


def _mask_key(value: str) -> str:
    """Mask an API key for display (show first 4 and last 4 chars)."""
    if not value or len(value) < 10:
        return "****"
    return f"{value[:4]}...{value[-4:]}"


def _save_env(new_values: dict):
    """Read existing .env, merge new values, and write back."""
    env_path = Path.cwd() / ".env"
    existing = {}

    # Read existing .env if present
    if env_path.exists():
        with open(env_path, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, _, val = line.partition("=")
                    existing[key.strip()] = val.strip()

    # Merge new values (overwrite existing)
    existing.update({k: v for k, v in new_values.items() if v})

    # Write back
    with open(env_path, "w") as f:
        f.write("# GitHub Issue Solver - Auto-generated configuration\n")
        f.write("# Edit manually or re-run: python main.py --mode cli\n\n")
        for key, val in existing.items():
            f.write(f"{key}={val}\n")
