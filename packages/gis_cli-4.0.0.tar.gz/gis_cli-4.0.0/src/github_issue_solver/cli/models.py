"""Investigation context model for the pipeline TUI."""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from datetime import datetime

from ..models import IssueInfo, AnalysisResult, PatchResult, RepositoryStatus


@dataclass
class InvestigationContext:
    """Accumulates state across investigation phases."""

    issue_url: str
    owner: str = ""
    repo: str = ""
    repo_full_name: str = ""
    issue_number: int = 0

    # Fetched data
    issue_info: Optional[IssueInfo] = None
    repo_info: Optional[dict] = None
    repo_status: Optional[RepositoryStatus] = None
    learnings: list = field(default_factory=list)

    # Analysis & patch results
    analysis_result: Optional[AnalysisResult] = None
    patch_result: Optional[PatchResult] = None
    pre_pr_checklist: Optional[dict] = None

    # Timing
    phase_timings: Dict[str, float] = field(default_factory=dict)
    started_at: Optional[datetime] = None
