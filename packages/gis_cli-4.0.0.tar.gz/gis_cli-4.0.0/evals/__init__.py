"""GIS RAG evaluation framework."""
