# btc2

Simple cryptocurrency price fetching from CEX + DEX + Wallet balance.

## Install

```bash
pip install btc2
```

## Quick Start

```python
import btc2

# Price (no parentheses needed)
print(btc2.btc)        # → 80000.00
print(btc2.eth)       # → 2400.00
print(btc2.sol)       # → 85.00

# Specific exchange
print(btc2.btc.binance)    # → Binance price
print(btc2.btc.coinbase)  # → Coinbase price

# DEX prices (DexScreener, Raydium, etc.)
print(btc2.sol.dexscreener)  # → Solana token prices

# All prices
print(btc2.btc.all)    # → {"binance": 80000, ...}

# Wallet balance (Solana)
print(btc2.wallet("ADDRESS"))
print(btc2.wallet_info("ADDRESS"))

# Calculations
price = float(btc2.btc)  # → 80000.00
```

## Supported Coins

- btc, bitcoin → BTC
- eth, ethereum → ETH
- sol, solana → SOL
- xrp, ripple → XRP
- ada, cardano → ADA
- doge, dogecoin → DOGE
- dot, polkadot → DOT
- avax, avalanche → AVAX
- link, chainlink → LINK
- matic, polygon → MATIC
- And 50+ more coins

## CEX Exchanges (11)

binance, coinbase, kucoin, huobi, mexc, bitstamp, gemini, exmo, coingecko, coinpaprika, cryptocompare

## DEX Exchanges (7)

uniswap, pancakeswap, sushiswap, curve, orca, raydium, dexscreener

## Wallet

```python
import btc2

# Get SOL balance
btc2.wallet("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU")
# → {'address': '7xKX...', 'sol': 50.53, 'tokens': []}

# Pretty print
btc2.wallet_info("ADDRESS")
```

## API Reference

| Syntax | Description |
|--------|-------------|
| `btc.binance` | BTC on Binance spot |
| `btc.binance.fut` | BTC on Binance futures |
| `btc.dexscreener` | DEX price from DexScreener |
| `btc.all` | All exchange prices |
| `btc()` | First available price |
| `btc.sol` | First available (CEX or DEX) |
| `btc2.wallet("addr")` | SOL wallet balance |

## Notes

- No API keys required
- Prices cached for 1 second
- Async parallel fetching
- Free public RPC for wallet

MIT