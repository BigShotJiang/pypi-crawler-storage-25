import pytest
import asyncio
from btc2 import get_price, get_all_prices, EXCHANGES
from btc2.coins import normalize_coin, COIN_SYMBOLS


class TestCoins:
    def test_normalize_btc(self):
        assert normalize_coin("btc") == "BTC"
        assert normalize_coin("BTC") == "BTC"
        assert normalize_coin("bitcoin") == "BTC"

    def test_normalize_eth(self):
        assert normalize_coin("eth") == "ETH"
        assert normalize_coin("ETH") == "ETH"
        assert normalize_coin("ethereum") == "ETH"

    def test_normalize_unknown(self):
        assert normalize_coin("unknown") == "UNKNOWN"

    def test_coin_symbols_contains_top_coins(self):
        assert "btc" in COIN_SYMBOLS
        assert "eth" in COIN_SYMBOLS
        assert "sol" in COIN_SYMBOLS
        assert "bitcoin" in COIN_SYMBOLS


class TestExchanges:
    def test_exchanges_list(self):
        expected = [
            "binance", "bybit", "okx", "coinbase",
            "kraken", "kucoin", "gate", "bitget",
            "huobi", "mexc"
        ]
        assert EXCHANGES == expected


@pytest.mark.asyncio
class TestGetPrice:
    async def test_get_price_binance(self):
        price = await get_price("binance", "btc", "spot")
        assert price is None or isinstance(price, (int, float))

    async def test_get_price_unknown_exchange(self):
        price = await get_price("unknown_exchange", "btc", "spot")
        assert price is None


@pytest.mark.asyncio
class TestGetAllPrices:
    async def test_get_all_prices_btc(self):
        prices = await get_all_prices("btc", "spot")
        assert isinstance(prices, dict)

    async def test_get_all_prices_eth(self):
        prices = await get_all_prices("eth", "spot")
        assert isinstance(prices, dict)


class TestAPI:
    def test_import_works(self):
        import btc2
        assert hasattr(btc2, "get_price")
        assert hasattr(btc2, "get_all_prices")

    def test_version(self):
        import btc2
        assert btc2.__version__ == "0.1.0"