"""
btc2 - crypto price from 11 CEX + 7 DEX + Wallet balance

CEX: binance, coinbase, kucoin, huobi, mexc, bitstamp, gemini, exmo, coingecko, coinpaprika, cryptocompare
DEX: uniswap, pancakeswap, sushiswap, curve, orca, raydium, dexscreener
Wallet: btc2.wallet("ADDRESS") - get Solana wallet balance

Quick start:
    import btc2
    print(btc2.btc)           # first available
    print(btc2.wallet("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU")
    print(btc2.btc.all)      # all CEX prices
"""
import asyncio
import aiohttp
from typing import Optional, Union
from .coins import normalize_coin, COIN_SYMBOLS
from .exchange import get_price, get_all_prices, EXCHANGES, get_dex_price, get_all_dex_prices, DEX_EXCHANGES


class Market:
    """Market price for specific exchange and coin."""
    def __init__(self, coin: str, exchange: str, market_type: str = "spot"):
        self._coin = coin
        self._exchange = exchange
        self._market_type = market_type

    async def _get(self) -> Optional[float]:
        return await get_price(self._exchange, self._coin, self._market_type)

    def __call__(self) -> Optional[float]:
        return asyncio.run(self._get())

    @property
    def spot(self) -> Optional[float]:
        return asyncio.run(get_price(self._exchange, self._coin, "spot"))

    @property
    def fut(self) -> Optional[float]:
        return asyncio.run(get_price(self._exchange, self._coin, "fut"))

    def __repr__(self):
        price = self()
        return str(price) if price is not None else "N/A"

    def __str__(self):
        return self.__repr__()


class AllExchanges:
    def __init__(self, coin: str, market_type: str = "spot"):
        self._coin = coin
        self._market_type = market_type

    @property
    def spot(self):
        return AllExchanges(self._coin, "spot")

    @property
    def fut(self):
        return AllExchanges(self._coin, "fut")

    def _get_all(self):
        return asyncio.run(get_all_prices(self._coin, self._market_type))

    def __call__(self) -> dict:
        return self._get_all()

    def __repr__(self):
        data = self()
        return str(data) if data else "{}"

    def __str__(self):
        return self.__repr__()


class Coin:
    def __init__(self, coin: str):
        self._coin = coin

    def __getattr__(self, exchange: str):
        if exchange == "all":
            return AllExchanges(self._coin, "spot")
        return Market(self._coin, exchange, "spot")

    def __call__(self) -> dict:
        return asyncio.get_event_loop().run_until_complete(
            get_all_prices(self._coin, "spot")
        )


class _CoinProxy:
    def __init__(self, coin: str):
        self._coin = coin

    def __getattr__(self, item: str):
        if item == "all":
            return AllExchanges(self._coin, "spot")
        return Market(self._coin, item, "spot")

    def __call__(self) -> dict:
        return asyncio.run(get_all_prices(self._coin, "spot"))

    def __float__(self):
        return asyncio.run(get_price("binance", self._coin, "spot"))

    def __repr__(self):
        return f"Coin({self._coin})"


class _DefaultCoin:
    DEFAULT_EXCHANGE = "binance"

    def __init__(self, coin: str):
        self._coin = coin

    async def _get_first_price(self) -> Optional[float]:
        prices = await get_all_prices(self._coin, "spot")
        if prices:
            return list(prices.values())[0]
        dex_prices = await get_all_dex_prices(self._coin)
        if dex_prices:
            return list(dex_prices.values())[0]
        return None

    def __getattr__(self, item: str):
        item_lower = item.lower()
        if item_lower == "all":
            return AllExchanges(self._coin, "spot")
        if item_lower == "sol":  # первая доступная цена
            return _FirstPrice(self._coin)
        if item_lower in DEX_EXCHANGES:
            return DexMarket(self._coin, item_lower)
        return Market(self._coin, item, "spot")

    def __call__(self) -> Optional[float]:
        return asyncio.run(self._get_first_price())

    def __float__(self):
        return self()

    def __repr__(self):
        price = self()
        return str(price) if price is not None else "N/A"

    def __str__(self):
        return self.__repr__()


class DexMarket:
    def __init__(self, coin: str, dex: str):
        self._coin = coin
        self._dex = dex

    def __call__(self) -> Optional[float]:
        return asyncio.run(get_dex_price(self._dex, self._coin))

    def __repr__(self):
        price = self()
        return str(price) if price is not None else "N/A"

    def __str__(self):
        return self.__repr__()


class _FirstPrice:
    def __init__(self, coin: str):
        self._coin = coin

    def __call__(self) -> Optional[float]:
        return asyncio.run(self._get())

    async def _get(self) -> Optional[float]:
        prices = await get_all_prices(self._coin, "spot")
        if prices:
            return list(prices.values())[0]
        
        dex_prices = await get_all_dex_prices(self._coin)
        if dex_prices:
            return list(dex_prices.values())[0]
        
        return None

    def __repr__(self):
        price = self()
        return str(price) if price is not None else "N/A"

    def __str__(self):
        return self.__repr__()


class DexAll:
    def __init__(self, coin: str):
        self._coin = coin

    def __call__(self) -> dict:
        return asyncio.run(get_all_dex_prices(self._coin))

    def __repr__(self):
        data = self()
        return str(data) if data else "{}"

    def __str__(self):
        return self.__repr__()


class _AllProxy:
    def __init__(self):
        pass

    def __getattr__(self, item: str):
        return AllExchanges(item, "spot")


class _Dollar:
    def __getattr__(self, coin: str):
        return _DefaultCoin(coin.lower())

    def __getitem__(self, coin: str):
        return _DefaultCoin(coin.lower())

    def __repr__(self):
        return "crp.$"

    def __str__(self):
        return "crp.$"


_dollar = _Dollar()


def __getattr__(name: str):
    name_lower = name.lower()
    if name_lower == "all":
        return _AllProxy()
    if name_lower in COIN_SYMBOLS:
        return _DefaultCoin(name_lower)
    if name_lower == "$":
        return _dollar
    raise AttributeError(f"module 'btc2' has no attribute '{name}'")


__all__ = [
    "get_price",
    "get_all_prices",
    "EXCHANGES",
]

SOLANA_RPC = "https://api.mainnet-beta.solana.com"
SOL_TOKEN = "So11111111111111111111111111111111111111112"


def wallet(address: str) -> dict:
    """
    Get Solana wallet balance
    
    Args:
        address: Solana wallet address
        
    Returns:
        dict with 'sol' (float) and 'tokens' (list of dict)
        
    Example:
        import btc2
        print(btc2.wallet("7xKXtg2CW87d97TXJSDpbD5jBkheTqA83TZRuJosgAsU"))
    """
    return asyncio.run(_get_wallet(address))


def wallet_info(address: str) -> str:
    """Pretty print wallet info"""
    data = wallet(address)
    lines = [f"Wallet: {address[:8]}...{address[-4:]}", f"  SOL: {data['sol']:.4f}"]
    if data['tokens']:
        lines.append(f"  Tokens ({len(data['tokens'])}):")
        for t in data['tokens'][:5]:
            lines.append(f"    {t['mint'][:8]}...: {t['amount']}")
    return "\n".join(lines)


async def _get_wallet(address: str) -> dict:
    result = {"address": address, "sol": 0.0, "tokens": []}
    
    async with aiohttp.ClientSession() as session:
        # Get SOL balance
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "getBalance",
            "params": [address]
        }
        async with session.post(SOLANA_RPC, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
            data = await resp.json()
            lamports = data.get("result", {}).get("value", 0)
            result["sol"] = lamports / 1e9
        
        # Get token accounts
        for program in ["TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss6VQ6AD7PGK", "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHn7CXkS3tAa2F3A"]:
            payload = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "getTokenAccountsByOwner",
                "params": [
                    address,
                    {"programId": program},
                    {"encoding": "jsonParsed"}
                ]
            }
            async with session.post(SOLANA_RPC, json=payload, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                data = await resp.json()
                accounts = data.get("result", {}).get("value", [])
                for acc in accounts:
                    info = acc.get("account", {}).get("data", {}).get("parsed", {}).get("info", {})
                    mint = info.get("mint")
                    amount = info.get("amount", "0")
                    decimals = info.get("decimals", 0)
                    if int(amount) > 0:
                        result["tokens"].append({
                            "mint": mint,
                            "amount": int(amount) / (10**decimals),
                            "decimals": decimals
                        })
    
    return result


__version__ = "0.1.0"