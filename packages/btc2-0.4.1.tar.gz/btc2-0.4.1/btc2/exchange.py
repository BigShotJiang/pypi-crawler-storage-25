import asyncio
from typing import Optional
import aiohttp
from .coins import normalize_coin, get_trading_symbol

EXCHANGES = [
    "binance",
    "coinbase",
    "kucoin",
    "huobi",
    "mexc",
    "bitstamp",
    "gemini",
    "exmo",
    "coingecko",
    "coinpaprika",
    "cryptocompare",
]

EXCHANGE_URLS = {
    "binance": {
        "spot": "https://data-api.binance.vision/api/v3/ticker/price",
        "fut": "https://api.binance.com/fapi/v1/ticker/price",
    },
    "bybit": {
        "spot": "https://api.bybit.com/v5/market/tickers",
        "fut": "https://api.bybit.com/v5/market/tickers",
    },
    "okx": {
        "spot": "https://okx.com/api/v5/public/index-tickers",
        "fut": "https://okx.com/api/v5/public/index-tickers",
    },
    "coinbase": {
        "spot": "https://api.coinbase.com/v2/prices/{symbol}/spot",
        "fut": None,
    },
    "kraken": {
        "spot": "https://api.kraken.com/0/public/Ticker",
        "fut": None,
    },
    "kucoin": {
        "spot": "https://api.kucoin.com/api/v1/market/orderbook/level1",
        "fut": "https://api.kucoin.com/api/v1/market/orderbook/level1",
    },
    "gate": {
        "spot": "https://api.gateio.ws/api/v4/spot/tickers",
        "fut": "https://api.gateio.ws/api/v4/spot/tickers",
    },
    "bitget": {
        "spot": "https://api.bitget.com/spot/v1/market/ticker",
        "fut": "https://api.bitget.com/spot/v1/market/ticker",
    },
    "huobi": {
        "spot": "https://api.huobi.pro/market/detail/merged",
        "fut": None,
    },
    "mexc": {
        "spot": "https://api.mexc.com/api/v3/ticker/price",
        "fut": "https://api.mexc.com/api/v1/contract/ticker",
    },
    "coingecko": {
        "spot": "https://api.coingecko.com/api/v3/simple/price",
        "fut": None,
    },
    "coinpaprika": {
        "spot": "https://api.coinpaprika.com/v1/tickers",
        "fut": None,
    },
    "cryptocompare": {
        "spot": "https://min-api.cryptocompare.com/data/price",
        "fut": None,
    },
}


class PriceCache:
    def __init__(self, ttl: float = 1.0):
        self._cache: dict = {}
        self._ttl = ttl

    def get(self, key: str) -> Optional[float]:
        if key in self._cache:
            value, timestamp = self._cache[key]
            if asyncio.get_event_loop().time() - timestamp < self._ttl:
                return value
        return None

    def set(self, key: str, value: float):
        self._cache[key] = (value, asyncio.get_event_loop().time())


_price_cache = PriceCache()


async def _fetch_price(
    session: aiohttp.ClientSession,
    exchange: str,
    market_type: str,
    symbol: str,
) -> Optional[float]:
    if exchange not in EXCHANGE_URLS:
        return None

    urls = EXCHANGE_URLS[exchange]
    url = urls.get(market_type)

    if url is None:
        return None

    cache_key = f"{exchange}:{market_type}:{symbol}"
    cached = _price_cache.get(cache_key)
    if cached is not None:
        return cached

    try:
        if exchange == "binance":
            params = {"symbol": f"{symbol}USDT"} if market_type == "spot" else {"symbol": f"{symbol}USDT"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if "price" in data:
                    price = float(data["price"])
                    _price_cache.set(cache_key, price)
                    return price

        elif exchange == "bybit":
            category = "spot" if market_type == "spot" else "linear"
            params = {"category": category, "symbol": f"{symbol}USDT"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if data.get("retCode") == 0:
                    list_data = data.get("result", {}).get("list", [])
                    if list_data:
                        price = float(list_data[0].get("lastPrice", 0))
                        if price > 0:
                            _price_cache.set(cache_key, price)
                            return price

        elif exchange == "okx":
            params = {"instId": f"{symbol}-USDT" if market_type == "spot" else f"{symbol}-USDT-PERP"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if data.get("code") == "0":
                    data_list = data.get("data", [])
                    if data_list:
                        price = float(data_list[0].get("last", 0))
                        if price > 0:
                            _price_cache.set(cache_key, price)
                            return price

        elif exchange == "coinbase":
            if market_type == "spot":
                url_filled = url.format(symbol=symbol.upper())
                async with session.get(url_filled, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    data = await resp.json()
                    if "data" in data and "amount" in data["data"]:
                        price = float(data["data"]["amount"])
                        _price_cache.set(cache_key, price)
                        return price

        elif exchange == "kraken":
            if market_type == "spot":
                pair = f"X{symbol.upper()}ZUSD"
                params = {"pair": pair}
                async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    data = await resp.json()
                    if data.get("error") == [] and "result" in data:
                        result = data["result"]
                        for k, v in result.items():
                            if "c" in v:
                                price = float(v["c"][0])
                                _price_cache.set(cache_key, price)
                                return price

        elif exchange == "kucoin":
            params = {"symbol": f"{symbol}-USDT"} if market_type == "spot" else {"symbol": f"{symbol}-USDT-PERP"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if data.get("code") == "200000":
                    data_obj = data.get("data", {})
                    price = float(data_obj.get("price", 0))
                    if price > 0:
                        _price_cache.set(cache_key, price)
                        return price

        elif exchange == "gate":
            if market_type == "spot":
                params = {"currency_pair": f"{symbol}_USDT"}
            else:
                params = {"currency_pair": f"{symbol}_USDT"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if isinstance(data, list) and len(data) > 0:
                    price = float(data[0].get("last", 0))
                    if price > 0:
                        _price_cache.set(cache_key, price)
                        return price

        elif exchange == "bitget":
            params = {"symbol": f"{symbol}USDT"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if data.get("code") == "0":
                    data_list = data.get("data", [])
                    if data_list:
                        price = float(data_list[0].get("lastPr", 0))
                        if price > 0:
                            _price_cache.set(cache_key, price)
                            return price

        elif exchange == "huobi":
            if market_type == "spot":
                params = {"symbol": f"{symbol.lower()}usdt"}
                async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    data = await resp.json()
                    if data.get("status") == "ok":
                        tick = data.get("tick", {})
                        price = float(tick.get("close", 0))
                        if price > 0:
                            _price_cache.set(cache_key, price)
                            return price

        elif exchange == "mexc":
            if market_type == "spot":
                params = {"symbol": f"{symbol}USDT"}
            else:
                params = {"symbol": f"{symbol}_USDT"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                if data.get("success", True):
                    if market_type == "spot":
                        price = float(data.get("price", 0))
                    else:
                        price = float(data.get("data", {}).get("lastPrice", 0))
                    if price > 0:
                        _price_cache.set(cache_key, price)
                        return price

        elif exchange == "coinbase":
            if market_type == "spot":
                url_filled = url.format(symbol=symbol.upper())
                async with session.get(url_filled, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                    data = await resp.json()
                    if "data" in data and "amount" in data["data"]:
                        price = float(data["data"]["amount"])
                        if price > 0:
                            _price_cache.set(cache_key, price)
                            return price

        elif exchange == "bitstamp":
            params = {}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                price = data.get("last")
                if price:
                    price_float = float(price)
                    if price_float > 0:
                        _price_cache.set(cache_key, price_float)
                        return price_float

        elif exchange == "gemini":
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                price = data.get("last")
                if price:
                    price_float = float(price)
                    if price_float > 0:
                        _price_cache.set(cache_key, price_float)
                        return price_float

        elif exchange == "exmo":
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                pair = f"{symbol}_USD"
                if pair in data:
                    price = data[pair].get("last_trade")
                    if price:
                        price_float = float(price)
                        if price_float > 0:
                            _price_cache.set(cache_key, price_float)
                            return price_float

        elif exchange == "coingecko":
            coin_id = symbol.lower()
            if coin_id == "btc":
                coin_id = "bitcoin"
            elif coin_id == "eth":
                coin_id = "ethereum"
            elif coin_id == "sol":
                coin_id = "solana"
            params = {"ids": coin_id, "vs_currencies": "usd"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                price = data.get(coin_id, {}).get("usd")
                if price:
                    price_float = float(price)
                    if price_float > 0:
                        _price_cache.set(cache_key, price_float)
                        return price_float

        elif exchange == "coinpaprika":
            params = {}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                for item in data:
                    if item.get("symbol") == symbol.upper():
                        price = item.get("quotes", {}).get("USD", {}).get("price")
                        if price:
                            price_float = float(price)
                            if price_float > 0:
                                _price_cache.set(cache_key, price_float)
                                return price_float

        elif exchange == "cryptocompare":
            params = {"fsym": symbol.upper(), "tsyms": "USD"}
            async with session.get(url, params=params, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                data = await resp.json()
                price = data.get("USD")
                if price:
                    price_float = float(price)
                    if price_float > 0:
                        _price_cache.set(cache_key, price_float)
                        return price_float

    except Exception:
        pass

    return None


async def get_price(
    exchange: str,
    coin: str,
    market_type: str = "spot",
) -> Optional[float]:
    coin_symbol = normalize_coin(coin)

    async with aiohttp.ClientSession() as session:
        return await _fetch_price(session, exchange, market_type, coin_symbol)


async def get_all_prices(
    coin: str,
    market_type: str = "spot",
) -> dict:
    coin_symbol = normalize_coin(coin)

    async with aiohttp.ClientSession() as session:
        tasks = [
            _fetch_price(session, exchange, market_type, coin_symbol)
            for exchange in EXCHANGES
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    prices = {}
    for exchange, result in zip(EXCHANGES, results):
        if isinstance(result, float):
            prices[exchange] = result
        elif result is not None:
            prices[exchange] = result

    return prices


# DEX Exchanges
DEX_EXCHANGES = [
    "uniswap",
    "pancakeswap",
    "sushiswap",
    "curve",
    "orca",
    "raydium",
    "dexscreener",
]

# Token addresses for different networks
DEX_TOKENS = {
    "ethereum": {
        "BTC": "0x2260fac5e5542a773aa44fbcfedf7c193bc2c599",
        "ETH": "0x0000000000000000000000000000000000000000",  # WETH
    },
    "bsc": {
        "BTC": "0x7130d2a12b9bcbfae4f2634d864a1bc1e0961da6",
        "ETH": "0x2170ed0880ac9a75581da2c1dd11356b0bc2a67b",
    },
    "solana": {
        "BTC": "DezXAZ8z7PnrnzjzT6TFLZdgS6Q9KxZ5wPLS2e9xGNwn",
        "ETH": "7vfCXTUXx5WJV5JADk17DUJ4kswc7K1ScEJJwUmCpMP",
    },
}


DEX_URLS = {
    "uniswap": {
        "network": "ethereum",
        "base_url": "https://api.dexpaprika.com/networks/ethereum",
    },
    "pancakeswap": {
        "network": "bsc",
        "base_url": "https://api.dexpaprika.com/networks/bsc",
    },
    "sushiswap": {
        "network": "ethereum",
        "base_url": "https://api.dexpaprika.com/networks/ethereum",
    },
    "curve": {
        "network": "ethereum",
        "base_url": "https://api.dexpaprika.com/networks/ethereum",
    },
"raydium": {
        "network": "solana",
        "base_url": "https://api.dexpaprika.com/networks/solana",
    },
    "dexscreener": {
        "network": "solana",
        "base_url": "https://api.dexscreener.com/latest/dex",
    },
}


async def get_dex_price(
    dex: str,
    coin: str,
) -> Optional[float]:
    coin_symbol = normalize_coin(coin)

    if dex not in DEX_URLS:
        return None

    dex_info = DEX_URLS[dex]
    network = dex_info["network"]
    base_url = dex_info["base_url"]

    # Get token address (not required for dexscreener search)
    token_addr = DEX_TOKENS.get(network, {}).get(coin_symbol)
    if not token_addr and dex != "dexscreener":
        return None

    cache_key = f"dex:{dex}:{coin_symbol}"
    cached = _price_cache.get(cache_key)
    if cached is not None:
        return cached

    try:
        if dex == "dexscreener":
            url = f"{base_url}/search?q={coin_symbol}"
        else:
            url = f"{base_url}/tokens/{token_addr}"
        
        async with aiohttp.ClientSession() as session:
            async with session.get(url, timeout=aiohttp.ClientTimeout(total=5)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    
                    if dex == "dexscreener":
                        pairs = data.get("pairs", [])
                        if pairs and len(pairs) > 0:
                            pair = pairs[0]
                            quote_symbol = pair.get("quoteToken", {}).get("symbol", "")
                            price = pair.get("priceUsd")
                            if price:
                                price_float = float(price)
                                if quote_symbol == "SOL":
                                    sol_url = "https://api.coingecko.com/api/v3/simple/price?ids=solana&vs_currencies=usd"
                                    async with session.get(sol_url, timeout=aiohttp.ClientTimeout(total=5)) as sol_resp:
                                        if sol_resp.status == 200:
                                            sol_data = await sol_resp.json()
                                            sol_price = sol_data.get("solana", {}).get("usd")
                                            if sol_price:
                                                price_float = price_float * sol_price
                                _price_cache.set(cache_key, price_float)
                                return price_float
                    else:
                        price = data.get("summary", {}).get("price_usd")
                        if not price:
                            price = data.get("data", {}).get("price_usd")
                        if price:
                            price_float = float(price)
                            _price_cache.set(cache_key, price_float)
                            return price_float
    except Exception:
        pass

    return None


async def get_all_dex_prices(coin: str) -> dict:
    coin_symbol = normalize_coin(coin)

    async with aiohttp.ClientSession() as session:
        tasks = [get_dex_price(dex, coin_symbol) for dex in DEX_EXCHANGES]
        results = await asyncio.gather(*tasks, return_exceptions=True)

    prices = {}
    for dex, result in zip(DEX_EXCHANGES, results):
        if isinstance(result, Exception):
            continue
        if isinstance(result, float):
            prices[dex] = result
        elif result is not None:
            try:
                price = float(result)
                if price > 0:
                    prices[dex] = price
            except (ValueError, TypeError):
                pass

    return prices