#WebGUIAPI

## History of version
Version 1.2604.2805: 2026/04/28<BR>
Re-write&design TListBox code
Fix problem:TComboBox compatible with vcl framework<BR>
            remove option and value property.

Version 1.2604.2803: 2026/04/28<BR>
Fix problem:
TEdit component err --> NameError: name 'v' is not defined

Version 1.2604.2802: 2026/04/28<BR>
1.Add TListBox component.
2.Improve TButton add TButtonShape property.

Version 1.2604.2801: 2026/04/28<BR>
Create WebGUI component for VCL framework like.