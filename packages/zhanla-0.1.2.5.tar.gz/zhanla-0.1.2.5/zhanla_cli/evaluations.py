"""Trigger-backed managed web autorater evaluation helpers."""
import time
import sys
from typing import Optional

import httpx


def start_evaluation(
    base_url: str,
    access_token: str,
    autorater_id: Optional[str] = None,
    autorater_name: Optional[str] = None,
    dataset_id: Optional[str] = None,
    component_family_id: Optional[str] = None,
    component_definition_id: Optional[str] = None,
    prompt_id: Optional[str] = None,
    model_endpoint: Optional[str] = None,
    variable_mappings: Optional[list] = None,
    top_k: Optional[int] = None,
    temperature: Optional[float] = None,
    layered_score: Optional[bool] = None,
    org_id: Optional[str] = None,
) -> dict:
    """Start the full managed two-step autorater flow.

    This path mirrors the web app flow:
    1. The server renders prompts and fetches component responses with the
       user's configured provider API key.
    2. The platform runs the managed autorater against those responses.

    Calls POST /api/v1/sdk/evaluations/start and returns
    { runId, triggerRunId }.

    Args:
        base_url:         App base URL (e.g. https://benchmark-black.vercel.app).
        access_token:     Short-lived SDK JWT obtained from get_fresh_token().
        autorater_id:     Target autorater UUID. Use this OR autorater_name.
        autorater_name:   Target autorater by name (errors on zero/multiple matches).
        dataset_id:       Override autorater default dataset.
        component_family_id: Override autorater default component family.
        component_definition_id: Override the exact component definition/config version.
        prompt_id:        Legacy alias for component_definition_id.
        model_endpoint:   Override autorater default model endpoint.
        variable_mappings: Override autorater default variable mappings.
        top_k:            Override autorater default top_k.
        temperature:      Override autorater default temperature.
        layered_score:    Override autorater default layered_score.

    Returns:
        dict with keys 'runId' and 'triggerRunId'.

    Raises:
        httpx.HTTPStatusError: on non-2xx response.
        RuntimeError:          if the response body is unexpected.
    """
    payload: dict = {}
    if autorater_id:
        payload["autorater_id"] = autorater_id
    elif autorater_name:
        payload["autorater_name"] = autorater_name
    else:
        raise ValueError("autorater_id or autorater_name is required")

    if dataset_id is not None:
        payload["dataset_id"] = dataset_id
    if component_family_id is not None:
        payload["component_family_id"] = component_family_id
    if component_definition_id is not None:
        payload["component_definition_id"] = component_definition_id
    if prompt_id is not None:
        payload["prompt_id"] = prompt_id
    if model_endpoint is not None:
        payload["model_endpoint"] = model_endpoint
    if variable_mappings is not None:
        payload["variable_mappings"] = variable_mappings
    if top_k is not None:
        payload["top_k"] = top_k
    if temperature is not None:
        payload["temperature"] = temperature
    if layered_score is not None:
        payload["layered_score"] = layered_score

    headers: dict = {"Authorization": f"Bearer {access_token}"}
    if org_id:
        headers["X-Org-Id"] = org_id

    resp = httpx.post(
        f"{base_url}/api/v1/sdk/evaluations/start",
        json=payload,
        headers=headers,
        timeout=30.0,
    )
    if not resp.is_success:
        try:
            detail = resp.json().get("error", resp.text)
        except Exception:
            detail = resp.text
        raise RuntimeError(f"HTTP {resp.status_code}: {detail}")
    data = resp.json()
    if "runId" not in data:
        raise RuntimeError(f"Unexpected response from evaluation start: {data}")
    return data


def poll_evaluation(
    base_url: str,
    access_token: str,
    run_id: str,
    poll_interval: float = 3.0,
    timeout: float = 1800.0,
    org_id: Optional[str] = None,
) -> dict:
    """Poll GET /api/v1/sdk/evaluations/:runId until completed or failed.

    Prints an in-place progress bar to stderr while waiting.

    Args:
        base_url:      App base URL.
        access_token:  Short-lived SDK JWT.
        run_id:        UUID of the autorater_runs row.
        poll_interval: Seconds between polls (default 3).
        timeout:       Maximum total wait time in seconds (default 30 min).

    Returns:
        Final status dict: { status, overall_score, error, items_total, items_completed }.

    Raises:
        TimeoutError:          if the run does not complete within timeout.
        httpx.HTTPStatusError: on non-2xx poll response.
    """
    deadline = time.monotonic() + timeout
    url = f"{base_url}/api/v1/sdk/evaluations/{run_id}"
    headers: dict = {"Authorization": f"Bearer {access_token}"}
    if org_id:
        headers["X-Org-Id"] = org_id

    while True:
        resp = httpx.get(url, headers=headers, timeout=15.0)
        resp.raise_for_status()
        data = resp.json()

        status = data.get("status", "unknown")
        items_total = data.get("items_total") or 0
        items_completed = data.get("items_completed") or 0

        # In-place progress line on stderr
        if items_total > 0:
            bar_width = 30
            filled = int(bar_width * items_completed / items_total)
            bar = "█" * filled + "░" * (bar_width - filled)
            pct = int(100 * items_completed / items_total)
            line = f"\r  [{bar}] {items_completed}/{items_total} ({pct}%)  status: {status}   "
        else:
            line = f"\r  status: {status}   "

        sys.stderr.write(line)
        sys.stderr.flush()

        if status in ("completed", "failed"):
            sys.stderr.write("\n")
            sys.stderr.flush()
            return data

        if time.monotonic() > deadline:
            sys.stderr.write("\n")
            sys.stderr.flush()
            raise TimeoutError(
                f"Evaluation run {run_id} did not complete within {timeout}s."
            )

        time.sleep(poll_interval)
