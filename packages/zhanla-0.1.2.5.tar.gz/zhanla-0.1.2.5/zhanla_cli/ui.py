"""Rich terminal UI helpers for the bench CLI."""
from urllib.parse import urlparse

from rich.console import Console
from rich.progress import Progress, BarColumn, TextColumn, MofNCompleteColumn
from rich.table import Table
from rich.text import Text

from zhanla_cli.contracts import EvalTrace

console = Console()


def _truncate_text(text: str, limit: int = 96) -> str:
    normalized = " ".join(text.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: limit - 3] + "..."


def _summarize_eval_output(output: dict | None) -> str:
    if not isinstance(output, dict):
        return ""

    for key in ("reason", "reasoning"):
        value = output.get(key)
        if isinstance(value, str) and value.strip():
            return _truncate_text(value)

    extra = {k: v for k, v in output.items() if k != "score"}
    if not extra:
        return "Score recorded"

    scalar_parts: list[str] = []
    for key, value in extra.items():
        if isinstance(value, bool):
            scalar_parts.append(f"{key}={str(value).lower()}")
        elif isinstance(value, (int, float, str)):
            scalar_parts.append(f"{key}={value}")

    if scalar_parts:
        return _truncate_text(", ".join(scalar_parts[:2]))

    return f"{len(extra)} metric groups reported"


def _print_result_link(url: str) -> None:
    parsed = urlparse(url)
    label = f"Open run ({parsed.netloc})" if parsed.netloc else "Open run"
    console.print(
        Text.assemble(
            ("Open: ", "dim"),
            (label, f"cyan underline link {url}"),
        )
    )


def print_components_table(components) -> None:
    """Print a formatted table of discovered components."""
    table = Table(title="Discovered Components")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="magenta")
    for c in components:
        table.add_row(c.name, c.component_type.value)
    console.print(table)


def create_progress(*, transient: bool = False) -> Progress:
    """Create a Rich progress bar for dataset row execution."""
    return Progress(
        TextColumn("[bold blue]{task.description}"),
        BarColumn(),
        MofNCompleteColumn(),
        TextColumn("[dim]{task.fields[status]}"),
        console=console,
        transient=transient,
    )


def print_score_summary(
    component_traces: list[EvalTrace],
    eval_traces: list[EvalTrace | None],
    component_name: str,
    dry_run: bool = False,
    uploaded: bool = True,
    result_url: str | None = None,
    autorater_id: str | None = None,
    autorater_run_id: str | None = None,
    upload_started_at: str | None = None,
    upload_completed_at: str | None = None,
) -> None:
    """Print a per-item score table with aggregate mean."""
    table = Table(title=f"Scores — {component_name}")
    table.add_column("#", style="dim")
    table.add_column("Score", style="cyan")
    table.add_column("Eval Run")
    table.add_column("Summary", style="dim")

    scores: list[float] = []
    for i, trace in enumerate(eval_traces):
        component_trace = component_traces[i] if i < len(component_traces) else None
        if trace is None:
            if component_trace is not None and component_trace.status == "failed":
                table.add_row(
                    str(i + 1),
                    "—",
                    "[yellow]skipped[/yellow]",
                    component_trace.error or "Component failed before evaluation.",
                )
            else:
                table.add_row(str(i + 1), "—", "[red]not configured[/red]", "")
            continue

        score_val = None
        summary = ""
        if trace.output and isinstance(trace.output, dict):
            score_val = trace.output.get("score")
            summary = _summarize_eval_output(trace.output)

        if trace.status == "failed":
            status_icon = "[red]failed[/red]"
            summary = trace.error or summary or "Evaluation failed."
        else:
            status_icon = "[green]completed[/green]"

        if score_val is not None:
            scores.append(float(score_val))
            table.add_row(str(i + 1), f"{float(score_val):.3f}", status_icon, summary)
        else:
            fallback_summary = summary or "No numeric score returned."
            table.add_row(str(i + 1), "—", status_icon, fallback_summary)

    console.print(table)

    mean = sum(scores) / len(scores) if scores else 0.0
    console.print(f"\n[bold]Mean score:[/bold] {mean:.3f}  ({len(scores)} items scored)")

    if dry_run:
        console.print("[dim]Dry run — nothing uploaded[/dim]")
    elif uploaded and result_url:
        console.print("[dim]Results uploaded[/dim]")
        if upload_started_at:
            console.print(f"[dim]Upload started at: {upload_started_at}[/dim]")
        if upload_completed_at:
            console.print(f"[dim]Upload completed at: {upload_completed_at}[/dim]")
        if autorater_id:
            console.print(f"[dim]Autorater ID: {autorater_id}[/dim]")
        if autorater_run_id:
            console.print(f"[dim]Autorater Run ID: {autorater_run_id}[/dim]")
        _print_result_link(result_url)
    elif uploaded:
        console.print("[dim]Results uploaded[/dim]")
        if upload_started_at:
            console.print(f"[dim]Upload started at: {upload_started_at}[/dim]")
        if upload_completed_at:
            console.print(f"[dim]Upload completed at: {upload_completed_at}[/dim]")
    else:
        console.print("[red]Upload failed[/red]")
        if upload_started_at:
            console.print(f"[dim]Upload started at: {upload_started_at}[/dim]")
        if upload_completed_at:
            console.print(f"[dim]Upload ended at: {upload_completed_at}[/dim]")


def print_remote_evaluation_summary(
    *,
    component_name: str,
    run_status: dict,
    result_url: str | None = None,
    autorater_id: str | None = None,
    autorater_run_id: str | None = None,
    upload_started_at: str | None = None,
    upload_completed_at: str | None = None,
) -> None:
    """Print a compact summary for a remote web evaluation run."""
    table = Table(title=f"Remote Evaluation — {component_name}")
    table.add_column("Status", style="cyan")
    table.add_column("Score", style="magenta")
    table.add_column("Progress", style="dim")
    table.add_column("Error", style="red")

    status = str(run_status.get("status", "unknown"))
    overall_score = run_status.get("overall_score")
    score_text = f"{float(overall_score):.3f}" if overall_score is not None else "—"
    progress_text = f"{run_status.get('items_completed', 0)}/{run_status.get('items_total', 0)}"
    table.add_row(status, score_text, progress_text, str(run_status.get("error") or ""))
    console.print(table)

    if autorater_id:
        console.print(f"[dim]Autorater ID: {autorater_id}[/dim]")
    if autorater_run_id:
        console.print(f"[dim]Autorater Run ID: {autorater_run_id}[/dim]")
    if upload_started_at:
        console.print(f"[dim]Upload started at: {upload_started_at}[/dim]")
    if upload_completed_at:
        console.print(f"[dim]Upload completed at: {upload_completed_at}[/dim]")
    if result_url:
        _print_result_link(result_url)
