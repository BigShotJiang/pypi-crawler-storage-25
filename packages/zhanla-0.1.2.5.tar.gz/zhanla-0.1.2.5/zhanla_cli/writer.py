"""Write definition syncs and eval results to Supabase — definition-first flow."""
import base64
import inspect
import json
import re
import textwrap
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any
from typing import Optional

from supabase import create_client, Client

from zhanla_cli.contracts import ComponentType, EvalTrace, component_type_value
from zhanla_cli.eval_contract import (
    derive_model_response as _derive_model_response_impl,
    stringify_value as _stringify_value_impl,
)
from zhanla_cli.manifest import (
    ComponentManifest,
    _ref_to_dict,
    compute_behavior_hash,
    compute_snapshot_hash,
    to_manifest,
)


@dataclass
class SyncedComponentVersion:
    family_id: str
    definition_id: str
    version: int


@dataclass
class UploadResult:
    dataset_id: str | None = None
    dataset_item_ids: list[str] | None = None
    autorater_id: str | None = None
    autorater_run_id: str | None = None


ATOMIC_EVAL_TYPES = {
    ComponentType.CODE_EVAL.value,
    ComponentType.LLM_EVAL.value,
}

_JSON_OUTPUT_ERROR_MARKERS = (
    "unterminated string in json",
    "unexpected end of json input",
    "jsondecodeerror",
    "expecting value",
    "extra data",
    "unexpected token",
)
_OUTPUT_SCHEMA_MISMATCH_REASON = "Model response doesn't match the requested output schema."


def _component_type_name(value: object) -> str:
    raw = getattr(value, "component_type", value)
    return component_type_value(raw)


def _get_fn_source(fn: Any) -> str:
    if fn is None:
        return ""
    try:
        return textwrap.dedent(inspect.getsource(fn))
    except (OSError, TypeError):
        return ""


def _manifest_from_component(component: Any) -> ComponentManifest:
    manifest = getattr(component, "_manifest", None)
    if isinstance(manifest, ComponentManifest):
        return manifest
    return to_manifest(component)


def _is_branch_node(node: object) -> bool:
    return (
        hasattr(node, "eval")
        and hasattr(node, "threshold")
        and hasattr(node, "if_pass")
        and hasattr(node, "if_fail")
    )


def _is_leaf_node(node: object) -> bool:
    return hasattr(node, "eval") and not _is_branch_node(node)


def get_supabase_client(supabase_url: str, supabase_anon_key: str, access_token: str) -> Client:
    """Create a Supabase client authenticated with the SDK JWT."""
    client = create_client(supabase_url, supabase_anon_key)
    client.postgrest.auth(access_token)
    return client


def _result_data(result) -> list[dict]:
    data = getattr(result, "data", None)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        return [data]
    return []


def _maybe_select_one(query) -> Optional[dict]:
    result = query.execute()
    rows = _result_data(result)
    return rows[0] if rows else None


def _select_rows(query) -> list[dict]:
    result = query.execute()
    return _result_data(result)


def _stringify_value(value: object) -> str:
    return _stringify_value_impl(value)


def _derive_model_response(output: object) -> str:
    """Serialize structured component output into the text eval contract.

    Stored traces/results may remain structured, but anything feeding code/LLM
    eval execution should be normalized to plain text so eval code owns parsing.
    """
    return _derive_model_response_impl(output)


def _build_component_result_note(component_trace: EvalTrace | None) -> dict[str, object]:
    if component_trace is None or not isinstance(component_trace.output, dict):
        return {}
    error = component_trace.output.get("_component_error")
    if not isinstance(error, str):
        return {}
    normalized = error.lower()
    if any(marker in normalized for marker in _JSON_OUTPUT_ERROR_MARKERS):
        return {
            "passed": False,
            "reason": _OUTPUT_SCHEMA_MISMATCH_REASON,
            "output_schema_error": error,
        }
    return {}


def infer_run_model_choice(
    component: Any,
    closure: list[ComponentManifest] | None,
) -> str | None:
    direct_model = getattr(component, "model", None)
    if isinstance(direct_model, str) and direct_model.strip():
        return direct_model.strip()

    if not closure:
        return None

    models: list[str] = []
    for manifest in closure:
        model = getattr(manifest, "model", None)
        if not isinstance(model, str):
            continue
        normalized = model.strip()
        if normalized and normalized not in models:
            models.append(normalized)

    if len(models) == 1:
        return models[0]
    return None


def _infer_run_temperature(
    component: Any,
    closure: list[ComponentManifest] | None,
) -> float | None:
    direct_temperature = getattr(component, "temperature", None)
    if isinstance(direct_temperature, (int, float)):
        return float(direct_temperature)

    if not closure:
        return None

    temperatures: list[float] = []
    for manifest in closure:
        temperature = getattr(manifest, "temperature", None)
        if not isinstance(temperature, (int, float)):
            continue
        normalized = float(temperature)
        if normalized not in temperatures:
            temperatures.append(normalized)

    if len(temperatures) == 1:
        return temperatures[0]
    return None


def _find_existing(client: Client, table: str, filters: dict[str, object]) -> Optional[dict]:
    query = client.table(table).select("id")
    for key, value in filters.items():
        query = query.eq(key, value)
    return _maybe_select_one(query.limit(1))


def _exists(client: Client, table: str, filters: dict[str, object], select_col: str = "*") -> bool:
    query = client.table(table).select(select_col)
    for key, value in filters.items():
        query = query.eq(key, value)
    result = query.limit(1).execute()
    return bool(_result_data(result))


def _extract_jinja_variables(text: str) -> list[str]:
    """Extract variable names from Jinja {{ varName }} expressions in a prompt."""
    JINJA_KEYWORDS = {"true", "false", "none", "not", "and", "or", "in", "if", "else", "elif", "end", "loop", "range"}
    pattern = r"\{\{\s*([\w][\w.]*)\s*(?:\|[^}]*)?\}\}"
    found: list[str] = []
    for match in re.finditer(pattern, text):
        name = match.group(1).split(".")[0]
        if name.lower() not in JINJA_KEYWORDS and name not in found:
            found.append(name)
    return found


def _get_user_id_from_token(access_token: str) -> str:
    """Extract the user UUID from a Supabase JWT access token."""
    try:
        payload_b64 = access_token.split(".")[1]
        padded = payload_b64 + "=" * (4 - len(payload_b64) % 4)
        payload = json.loads(base64.urlsafe_b64decode(padded))
        return payload.get("user_id") or payload.get("sub", "")
    except Exception:
        return ""




def _insert_and_get_id(client: Client, table: str, payload: dict, lookup_filters: dict[str, object]) -> str:
    result = client.table(table).insert(payload).execute()
    rows = _result_data(result)
    if rows and rows[0].get("id"):
        return rows[0]["id"]

    created = _find_existing(client, table, lookup_filters)
    if created and created.get("id"):
        return created["id"]
    raise RuntimeError(f"Failed to resolve inserted {table} record for {lookup_filters!r}")


def _lookup_or_create(client: Client, table: str, lookup_filters: dict[str, object], insert_payload: dict) -> str:
    try:
        existing = _find_existing(client, table, lookup_filters)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to read existing {table} row for {lookup_filters!r}: {exc}"
        ) from exc
    if existing and existing.get("id"):
        return existing["id"]
    try:
        return _insert_and_get_id(client, table, insert_payload, lookup_filters)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to insert {table} row for {lookup_filters!r}: {exc}"
        ) from exc


def _ensure_component_dataset_link(
    client: Client,
    *,
    owner_id: str,
    owner_type: str,
    dataset_id: str,
) -> None:
    link_lookup = {
        "owner_id": owner_id,
        "owner_type": owner_type,
        "dataset_id": dataset_id,
    }
    if not _exists(client, "component_datasets", link_lookup, select_col="owner_id"):
        try:
            client.table("component_datasets").insert(link_lookup).execute()
        except Exception as exc:
            raise RuntimeError(
                f"Failed to link dataset {dataset_id} to {owner_type} {owner_id}: {exc}"
            ) from exc


def _infer_input_columns(dataset_rows: list[dict]) -> dict[str, str]:
    """Infer dataset input columns from row keys and runtime value types."""
    columns: dict[str, str] = {}
    for row in dataset_rows:
        if not isinstance(row, dict):
            continue
        for key, value in row.items():
            if key in columns:
                continue
            if value is None:
                columns[key] = "null"
            elif isinstance(value, bool):
                columns[key] = "boolean"
            elif isinstance(value, int) and not isinstance(value, bool):
                columns[key] = "integer"
            elif isinstance(value, float):
                columns[key] = "number"
            elif isinstance(value, list):
                columns[key] = "array"
            elif isinstance(value, dict):
                columns[key] = "object"
            else:
                columns[key] = "string"
    return columns


def _normalize_declared_input_columns(schema: object) -> dict[str, Any] | None:
    """Return an explicit dataset schema payload when one was supplied."""
    if not isinstance(schema, dict):
        return None
    return json.loads(json.dumps(schema))


def _canonicalize_dataset_row(row: dict) -> str:
    return json.dumps(row, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def _ensure_dataset_with_items(
    client: Client,
    *,
    org_id: str,
    owner_id: str,
    owner_type: str,
    dataset_name: str,
    dataset_rows: list[dict],
    dataset_input_columns: Optional[dict[str, Any]] = None,
    dataset_id: Optional[str] = None,
) -> tuple[str, list[str]]:
    """Create or reuse a local CLI dataset and materialize dataset items."""
    resolved_dataset_id = dataset_id
    input_columns = (
        _normalize_declared_input_columns(dataset_input_columns)
        or _infer_input_columns(dataset_rows)
    )
    if resolved_dataset_id is None:
        dataset_lookup = {"name": dataset_name, "organization_id": org_id}
        existing_dataset = _find_existing(client, "datasets", dataset_lookup)
        if existing_dataset and existing_dataset.get("id"):
            resolved_dataset_id = existing_dataset["id"]
            client.table("datasets").update(
                {
                    "description": "Imported by bench CLI",
                    "input_columns": input_columns,
                }
            ).eq("id", resolved_dataset_id).execute()
        else:
            resolved_dataset_id = _insert_and_get_id(
                client,
                "datasets",
                {
                    "name": dataset_name,
                    "description": "Imported by bench CLI",
                    "organization_id": org_id,
                    "input_columns": input_columns,
                    "output_schema": None,
                },
                dataset_lookup,
            )
    else:
        client.table("datasets").update(
            {
                "description": "Imported by bench CLI",
                "input_columns": input_columns,
            }
        ).eq("id", resolved_dataset_id).execute()

    _ensure_component_dataset_link(
        client,
        owner_id=owner_id,
        owner_type=owner_type,
        dataset_id=resolved_dataset_id,
    )

    existing_items = _select_rows(
        client.table("dataset_items")
        .select("id,input,is_active")
        .eq("dataset_id", resolved_dataset_id)
    )
    existing_by_key: dict[str, list[dict]] = {}
    for item in existing_items:
        key = _canonicalize_dataset_row(item.get("input", {}) or {})
        existing_by_key.setdefault(key, []).append(item)

    dataset_item_ids: list[str] = []
    for row in dataset_rows:
        key = _canonicalize_dataset_row(row)
        existing_matches = existing_by_key.get(key, [])
        if existing_matches:
            reused = existing_matches.pop(0)
            if not reused.get("is_active", True):
                client.table("dataset_items").update({"is_active": True}).eq("id", reused["id"]).execute()
            dataset_item_ids.append(reused["id"])
            continue

        insert_result = client.table("dataset_items").insert(
            {
                "dataset_id": resolved_dataset_id,
                "input": row,
                "is_active": True,
            }
        ).execute()
        rows = _result_data(insert_result)
        if not rows or not rows[0].get("id"):
            raise RuntimeError("Failed to create dataset_items row for SDK upload")
        dataset_item_ids.append(rows[0]["id"])

    for leftovers in existing_by_key.values():
        for item in leftovers:
            if item.get("is_active", True):
                client.table("dataset_items").update({"is_active": False}).eq("id", item["id"]).execute()

    return resolved_dataset_id, dataset_item_ids


# ---------------------------------------------------------------------------
# Family-based definition sync (append-only versioning)
# ---------------------------------------------------------------------------

def _enrich_ref(ref: Any, family_id_map: dict[tuple[str, str], str] | None) -> dict:
    """Convert a manifest ref to the 3-field persisted shape: {key, family_id, component_type}."""
    if isinstance(ref, dict):
        key, ct = ref["key"], ref["component_type"]
    else:
        key, ct = ref.key, ref.component_type
    if family_id_map is not None:
        fid = family_id_map.get((ct, key))
        if not fid:
            raise RuntimeError(
                f"Missing synced family_id for dependency ({ct!r}, {key!r}). "
                f"Closure must include every transitive dependency in leaf-first order."
            )
    else:
        fid = ""
    return {"key": key, "family_id": fid, "component_type": ct}


def _enrich_eval_node(node: dict, family_id_map: dict[tuple[str, str], str] | None) -> dict:
    """Recursively enrich eval_ref fields inside an eval-tree node."""
    if not isinstance(node, dict):
        return node
    result = dict(node)
    if "eval_ref" in result:
        result["eval_ref"] = _enrich_ref(result["eval_ref"], family_id_map)
    for branch_key in ("if_pass", "if_fail"):
        if branch_key in result and isinstance(result[branch_key], list):
            result[branch_key] = [
                {**e, "node": _enrich_eval_node(e["node"], family_id_map)}
                if isinstance(e, dict) and "node" in e else e
                for e in result[branch_key]
            ]
    return result


def _build_canonical_definition(
    manifest: ComponentManifest,
    family_id_map: dict[tuple[str, str], str] | None = None,
) -> dict:
    """Build the canonical definition JSON stored in component_definitions.definition.

    Persisted refs use the 3-field shape: {key, family_id, component_type}.
    The graph stores pointer/linking structure only (componentType, componentKey,
    componentFamilyId). Exact child prompt/code provenance lives in run traces.
    """
    defn: dict = {
        "name": manifest.name,
        "description": manifest.description or "",
        "component_type": manifest.component_type,
        "key": manifest.key,
        "key_source": manifest.key_source,
        "execution_mode": manifest.execution_mode,
    }
    if manifest.instructions is not None:
        defn["instructions"] = manifest.instructions
    if manifest.model is not None:
        defn["model"] = manifest.model
    if manifest.temperature is not None:
        defn["temperature"] = manifest.temperature
    if manifest.output_schema is not None:
        defn["output_schema"] = manifest.output_schema
    if manifest.tool_refs:
        defn["tool_refs"] = [_enrich_ref(r, family_id_map) for r in manifest.tool_refs]
    if manifest.skill_refs:
        defn["skill_refs"] = [_enrich_ref(r, family_id_map) for r in manifest.skill_refs]
    if manifest.agent_refs:
        defn["agent_refs"] = [_enrich_ref(r, family_id_map) for r in manifest.agent_refs]
    if manifest.steps:
        if manifest.component_type == "orchestration":
            from zhanla_cli.graph_builder import build_graph_from_steps
            # Build graph from original steps to preserve display metadata
            defn["graph"] = build_graph_from_steps(manifest.steps, family_id_map=family_id_map)
        # Store 3-field enriched refs in persisted steps
        defn["steps"] = [
            {**s, "component_ref": _enrich_ref(s["component_ref"], family_id_map)}
            if "component_ref" in s else s
            for s in manifest.steps
        ]
    if manifest.eval_refs:
        defn["eval_refs"] = [_enrich_ref(r, family_id_map) for r in manifest.eval_refs]
    if manifest.weights is not None:
        defn["weights"] = manifest.weights
    if manifest.root is not None:
        defn["root"] = _enrich_eval_node(manifest.root, family_id_map)
    if manifest.source_code:
        defn["source_code"] = manifest.source_code
    if manifest.source_language:
        defn["source_language"] = manifest.source_language
    if manifest.source_format:
        defn["source_format"] = manifest.source_format
    if manifest.fn_present is not None:
        defn["fn_present"] = manifest.fn_present
    if manifest.is_async is not None:
        defn["is_async"] = manifest.is_async
    if manifest.model_response_format is not None:
        defn["model_response_format"] = manifest.model_response_format
    return defn


def _get_or_create_family(
    client: Client,
    *,
    org_id: str,
    component_type: str,
    key: str,
    key_source: str,
) -> str:
    """Look up or create a component_families row. Returns the family id."""
    lookup = {"organization_id": org_id, "component_type": component_type, "key": key}
    existing = _find_existing(client, "component_families", lookup)
    if existing and existing.get("id"):
        return existing["id"]
    return _insert_and_get_id(
        client,
        "component_families",
        {
            "organization_id": org_id,
            "component_type": component_type,
            "key": key,
            "key_source": key_source,
        },
        lookup,
    )


def _get_latest_version(client: Client, *, family_id: str) -> Optional[dict]:
    """Return the highest-version row for a family, or None."""
    result = (
        client.table("component_definitions")
        .select("id,version,behavior_hash,snapshot_hash")
        .eq("family_id", family_id)
        .order("version", desc=True)
        .limit(1)
        .execute()
    )
    rows = _result_data(result)
    return rows[0] if rows else None


def _sync_component_version(
    client: Client,
    manifest: ComponentManifest,
    org_id: str,
    user_id: Optional[str] = None,
    family_id_map: dict[tuple[str, str], str] | None = None,
) -> tuple[str, str, int]:
    """Sync a component version using the family-based append-only model.

    1. Resolve the family by explicit key.
    2. Check if the snapshot_hash already exists → no-op.
    3. Insert a new version row (v1 is auto-prod, v2+ is draft).

    Hashes are computed from the manifest (not the DB-enriched definition).
    The family_id_map is used only to enrich persisted refs with family_id.

    Returns (component_definitions row id, family_id, version).
    """
    behavior_hash = compute_behavior_hash(manifest)
    snapshot_hash = compute_snapshot_hash(manifest)

    family_id = _resolve_family(
        client,
        manifest=manifest,
        org_id=org_id,
    )

    # No-op: snapshot already exists in this family
    existing = _maybe_select_one(
        client.table("component_definitions")
        .select("id,version")
        .eq("family_id", family_id)
        .eq("snapshot_hash", snapshot_hash)
        .limit(1)
    )
    if existing:
        return existing["id"], family_id, existing.get("version", 0)

    # Determine next version number and parent
    latest = _get_latest_version(client, family_id=family_id)
    next_version = (latest["version"] + 1) if latest else 1
    parent_version_id = latest["id"] if latest else None

    # v1 is auto-prod so first sync is immediately usable; later versions are draft
    is_prod = (next_version == 1)

    definition = _build_canonical_definition(manifest, family_id_map=family_id_map)

    try:
        result = client.table("component_definitions").insert({
            "family_id": family_id,
            "version": next_version,
            "parent_version_id": parent_version_id,
            "is_prod": is_prod,
            "created_by": user_id,
            "name": manifest.name,
            "description": manifest.description or "",
            "behavior_hash": behavior_hash,
            "snapshot_hash": snapshot_hash,
            "execution_mode": manifest.execution_mode,
            "definition": definition,
        }).execute()
        rows = _result_data(result)
    except Exception as exc:
        # Race condition: another sync inserted the same snapshot_hash concurrently.
        # The unique constraint on (family_id, snapshot_hash) will surface this as a
        # duplicate-key error. Re-query for the winning row and return it as a no-op.
        if "duplicate" not in str(exc).lower() and "unique" not in str(exc).lower():
            raise
        winner = _maybe_select_one(
            client.table("component_definitions")
            .select("id,version")
            .eq("family_id", family_id)
            .eq("snapshot_hash", snapshot_hash)
            .limit(1)
        )
        if winner:
            return winner["id"], family_id, winner.get("version", 0)
        raise  # constraint exists but row vanished — re-raise

    return (rows[0]["id"] if rows else ""), family_id, next_version


def _resolve_family(
    client: Client,
    *,
    manifest: ComponentManifest,
    org_id: str,
) -> str:
    """Resolve the family_id for a manifest by explicit key, creating if needed."""
    return _get_or_create_family(
        client,
        org_id=org_id,
        component_type=manifest.component_type,
        key=manifest.key,
        key_source=manifest.key_source,
    )


# ---------------------------------------------------------------------------
# Slim entity upsert — typed tables store only id/org/component_family_id
# ---------------------------------------------------------------------------

def _upsert_agent(client: Client, org_id: str, family_id: str) -> str:
    lookup = {"organization_id": org_id, "component_family_id": family_id}
    existing = _find_existing(client, "agents", lookup)
    if existing and existing.get("id"):
        return existing["id"]
    return _insert_and_get_id(
        client, "agents",
        {"organization_id": org_id, "component_family_id": family_id},
        lookup,
    )


def _upsert_tool(client: Client, org_id: str, family_id: str) -> str:
    lookup = {"organization_id": org_id, "component_family_id": family_id}
    existing = _find_existing(client, "tools", lookup)
    if existing and existing.get("id"):
        return existing["id"]
    return _insert_and_get_id(
        client, "tools",
        {"organization_id": org_id, "component_family_id": family_id, "category": "sdk"},
        lookup,
    )


def _upsert_skill(client: Client, org_id: str, family_id: str, created_by: Optional[str] = None) -> str:
    lookup = {"organization_id": org_id, "component_family_id": family_id}
    existing = _find_existing(client, "skills", lookup)
    if existing and existing.get("id"):
        return existing["id"]
    return _insert_and_get_id(
        client, "skills",
        {"organization_id": org_id, "component_family_id": family_id, "created_by": created_by},
        lookup,
    )


def _upsert_orchestration(client: Client, org_id: str, family_id: str) -> str:
    lookup = {"organization_id": org_id, "component_family_id": family_id}
    existing = _find_existing(client, "orchestrations", lookup)
    if existing and existing.get("id"):
        return existing["id"]
    return _insert_and_get_id(
        client, "orchestrations",
        {"organization_id": org_id, "component_family_id": family_id},
        lookup,
    )


def _upsert_autorater(
    client: Client,
    eval_component: Any,
    org_id: str,
    owner_id: str,
    owner_type: str,
) -> str:
    lookup = {
        "name": eval_component.name,
        "organization_id": org_id,
        "owner_id": owner_id,
        "owner_type": owner_type,
    }
    existing = _find_existing(client, "autoraters", lookup)
    payload = {
        "name": eval_component.name,
        "organization_id": org_id,
        "owner_id": owner_id,
        "owner_type": owner_type,
        "description": eval_component.description,
        "mode": _autorater_mode(eval_component),
        "simple_eval_item_id": None,
    }
    if existing and existing.get("id"):
        client.table("autoraters").update(payload).eq("id", existing["id"]).execute()
        return existing["id"]
    return _insert_and_get_id(client, "autoraters", payload, lookup)


def _autorater_mode(eval_component: Any) -> str:
    component_type = _component_type_name(eval_component)
    if component_type in ATOMIC_EVAL_TYPES:
        return "simple"
    if component_type == ComponentType.CHECKLIST.value:
        return "checklist"
    if component_type == ComponentType.EVAL_TREE.value:
        return "tree"
    raise RuntimeError(
        f"Unsupported eval component type for managed autorater sync: "
        f"{component_type}"
    )


def _clear_autorater_storage(client: Client, autorater_id: str) -> None:
    client.table("autoraters").update({"simple_eval_item_id": None}).eq("id", autorater_id).execute()
    client.table("autorater_edges").delete().eq("autorater_id", autorater_id).execute()
    client.table("autorater_nodes").delete().eq("autorater_id", autorater_id).execute()
    client.table("autorater_checklist_item").delete().eq("autorater_id", autorater_id).execute()
    client.table("autorater_eval_items").delete().eq("autorater_id", autorater_id).execute()


def _create_eval_item(
    client: Client,
    *,
    autorater_id: str,
    comp: Any,
) -> str:
    source_language = getattr(comp, "source_language", None)
    source_code = getattr(comp, "source_code", None)
    component_type = _component_type_name(comp)
    if component_type == ComponentType.CODE_EVAL.value:
        item_type = "code_typescript" if source_language == "typescript" else "code_python"
        payload = {
            "autorater_id": autorater_id,
            "name": comp.name,
            "type": item_type,
            "content": source_code or _get_fn_source(getattr(comp, "fn", None)),
            "description": comp.description,
            "output_type": getattr(comp, "model_response_format", "JSON"),
        }
    elif component_type == ComponentType.LLM_EVAL.value:
        payload = {
            "autorater_id": autorater_id,
            "name": comp.name,
            "type": "prompt",
            "content": getattr(comp, "instructions", ""),
            "description": comp.description,
            "output_type": "TEXT",
        }
    else:
        raise RuntimeError(
            f"Unsupported nested eval component '{comp.name}' "
            f"of type {component_type}"
        )

    lookup = {
        "autorater_id": autorater_id,
        "name": comp.name,
        "type": payload["type"],
    }
    return _insert_and_get_id(client, "autorater_eval_items", payload, lookup)


def _sync_simple_autorater(
    client: Client,
    *,
    autorater_id: str,
    eval_component: Any,
) -> None:
    eval_item_id = _create_eval_item(client, autorater_id=autorater_id, comp=eval_component)
    client.table("autoraters").update({"simple_eval_item_id": eval_item_id}).eq("id", autorater_id).execute()


def _sync_checklist_autorater(
    client: Client,
    *,
    autorater_id: str,
    eval_component: Any,
) -> None:
    evals = list(getattr(eval_component, "evals", []) or [])
    weights = list(getattr(eval_component, "weights", []) or [])
    if not weights:
        weights = [1.0] * len(evals)

    for index, child in enumerate(evals):
        child_type = _component_type_name(child)
        if child_type not in ATOMIC_EVAL_TYPES:
            raise RuntimeError(
                f"Checklist '{eval_component.name}' contains unsupported child "
                f"eval type '{child_type}'."
            )
        eval_item_id = _create_eval_item(client, autorater_id=autorater_id, comp=child)
        client.table("autorater_checklist_item").insert(
            {
                "autorater_id": autorater_id,
                "eval_item_id": eval_item_id,
                "weight": weights[index],
                "order_index": index,
            }
        ).execute()


def _sync_eval_tree_autorater(
    client: Client,
    *,
    autorater_id: str,
    eval_component: Any,
) -> None:
    root = getattr(eval_component, "root", None)
    if not _is_branch_node(root):
        raise RuntimeError(f"EvalTree '{eval_component.name}' is missing a valid root branch.")

    next_position = {"x": 120, "y": 120}

    def insert_tree_edge(*, source_node_id: str, target_node_id: str, branch_label: str) -> None:
        payload = {
            "autorater_id": autorater_id,
            "source_node_id": source_node_id,
            "target_node_id": target_node_id,
            "branch_label": branch_label,
        }
        try:
            client.table("autorater_edges").insert(payload).execute()
        except Exception as exc:
            # Backward compatibility for databases that have not yet added
            # autorater_edges.branch_label.
            if "branch_label" in str(exc):
                client.table("autorater_edges").insert(
                    {
                        "autorater_id": autorater_id,
                        "source_node_id": source_node_id,
                        "target_node_id": target_node_id,
                    }
                ).execute()
                return
            raise

    def insert_node(comp: Any, *, weight: float, is_root: bool) -> str:
        component_type = _component_type_name(comp)
        if component_type not in ATOMIC_EVAL_TYPES:
            raise RuntimeError(
                f"EvalTree '{eval_component.name}' contains unsupported child "
                f"eval type '{component_type}'."
            )
        eval_item_id = _create_eval_item(client, autorater_id=autorater_id, comp=comp)
        payload = {
            "autorater_id": autorater_id,
            "eval_item_id": eval_item_id,
            "weight": weight,
            "is_root": is_root,
            "is_gating": False,
            "position_x": next_position["x"],
            "position_y": next_position["y"],
        }
        next_position["x"] += 220
        if next_position["x"] > 980:
            next_position["x"] = 120
            next_position["y"] += 180
        return _insert_and_get_id(
            client,
            "autorater_nodes",
            payload,
            {"autorater_id": autorater_id, "eval_item_id": eval_item_id, "is_root": is_root},
        )

    def walk_branch(branch: Any, *, incoming_weight: float, is_root: bool) -> str:
        node_id = insert_node(branch.eval, weight=incoming_weight, is_root=is_root)
        for edge in branch.if_pass:
            child_id = walk_edge(edge)
            insert_tree_edge(
                source_node_id=node_id,
                target_node_id=child_id,
                branch_label="if_pass",
            )
        for edge in branch.if_fail:
            child_id = walk_edge(edge)
            insert_tree_edge(
                source_node_id=node_id,
                target_node_id=child_id,
                branch_label="if_fail",
            )
        return node_id

    def walk_edge(edge) -> str:
        child = edge.node
        if _is_leaf_node(child):
            return insert_node(child.eval, weight=edge.weight, is_root=False)
        if _is_branch_node(child):
            return walk_branch(child, incoming_weight=edge.weight, is_root=False)
        raise RuntimeError(f"Unsupported EvalTree edge node for '{eval_component.name}'.")

    walk_branch(root, incoming_weight=1.0, is_root=True)


def _sync_managed_autorater(
    client: Client,
    *,
    eval_component: Any,
    org_id: str,
    owner_id: str,
    owner_type: str,
) -> str:
    autorater_id = _upsert_autorater(
        client,
        eval_component,
        org_id,
        owner_id,
        owner_type,
    )
    _clear_autorater_storage(client, autorater_id)

    component_type = _component_type_name(eval_component)
    if component_type in ATOMIC_EVAL_TYPES:
        _sync_simple_autorater(client, autorater_id=autorater_id, eval_component=eval_component)
    elif component_type == ComponentType.CHECKLIST.value:
        _sync_checklist_autorater(client, autorater_id=autorater_id, eval_component=eval_component)
    elif component_type == ComponentType.EVAL_TREE.value:
        _sync_eval_tree_autorater(client, autorater_id=autorater_id, eval_component=eval_component)
    else:
        raise RuntimeError(
            f"Unsupported eval component type for managed autorater sync: "
            f"{component_type}"
        )

    return autorater_id


def _get_owner_type(ct: object) -> str:
    component_type = component_type_value(ct)
    if component_type == ComponentType.AGENT.value:
        return "agent"
    if component_type == ComponentType.ORCHESTRATION.value:
        return "orchestration"
    if component_type == ComponentType.SKILL.value:
        return "skill"
    if component_type == ComponentType.TOOL.value:
        return "tool"
    return "agent"


def _upsert_owner_entity(
    client: Client,
    component: Any,
    org_id: str,
    family_id: str,
    user_id: Optional[str] = None,
) -> str:
    component_type = _component_type_name(component)
    if component_type == ComponentType.TOOL.value:
        return _upsert_tool(client, org_id, family_id)
    if component_type == ComponentType.SKILL.value:
        return _upsert_skill(client, org_id, family_id, created_by=user_id)
    if component_type == ComponentType.ORCHESTRATION.value:
        return _upsert_orchestration(client, org_id, family_id)
    return _upsert_agent(client, org_id, family_id)


_OWNER_TABLES: dict[str, str] = {
    "tool": "tools",
    "agent": "agents",
    "skill": "skills",
    "orchestration": "orchestrations",
}


def _upsert_owner_entity_from_manifest(
    client: Client,
    manifest: ComponentManifest,
    org_id: str,
    family_id: str,
    user_id: Optional[str] = None,
) -> Optional[str]:
    """Upsert a typed owner row for a manifest. Returns entity id or None for eval types."""
    ct = manifest.component_type
    if ct == "tool":
        return _upsert_tool(client, org_id, family_id)
    if ct == "skill":
        return _upsert_skill(client, org_id, family_id, created_by=user_id)
    if ct == "orchestration":
        return _upsert_orchestration(client, org_id, family_id)
    if ct == "agent":
        return _upsert_agent(client, org_id, family_id)
    # Eval types and llm_processor don't have dedicated owner tables
    return None


def _check_closure_conflicts(manifests: list[ComponentManifest]) -> None:
    """Fail fast if two manifests in the closure share a (component_type, key) with different behavior."""
    seen: dict[tuple[str, str], str] = {}
    for m in manifests:
        ck = (m.component_type, m.key)
        bh = compute_behavior_hash(m)
        if ck in seen and seen[ck] != bh:
            raise ValueError(
                f"Conflict: two components claim ({m.component_type}, {m.key}) "
                f"with different behavior hashes."
            )
        seen[ck] = bh


def _iter_ref_component_keys(refs: Any) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    if not isinstance(refs, list):
        return out
    for ref in refs:
        ref_dict = _ref_to_dict(ref)
        ct = ref_dict.get("component_type")
        key = ref_dict.get("key")
        if isinstance(ct, str) and isinstance(key, str) and key:
            out.append((ct, key))
    return out


def _iter_eval_node_component_keys(node: Any) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    if not isinstance(node, dict):
        return out
    eval_ref = node.get("eval_ref")
    if eval_ref is not None:
        ref_dict = _ref_to_dict(eval_ref)
        ct = ref_dict.get("component_type")
        key = ref_dict.get("key")
        if isinstance(ct, str) and isinstance(key, str) and key:
            out.append((ct, key))
    for branch_key in ("if_pass", "if_fail"):
        branch = node.get(branch_key)
        if not isinstance(branch, list):
            continue
        for edge in branch:
            if isinstance(edge, dict) and "node" in edge:
                out.extend(_iter_eval_node_component_keys(edge["node"]))
    return out


def _iter_manifest_child_component_keys(manifest: ComponentManifest) -> list[tuple[str, str]]:
    out: list[tuple[str, str]] = []
    out.extend(_iter_ref_component_keys(manifest.tool_refs))
    out.extend(_iter_ref_component_keys(manifest.skill_refs))
    out.extend(_iter_ref_component_keys(manifest.agent_refs))
    out.extend(_iter_ref_component_keys(manifest.eval_refs))
    if isinstance(manifest.steps, list):
        for step in manifest.steps:
            if not isinstance(step, dict) or step.get("is_conditional"):
                continue
            component_ref = step.get("component_ref")
            if component_ref is None:
                continue
            ref_dict = _ref_to_dict(component_ref)
            ct = ref_dict.get("component_type")
            key = ref_dict.get("key")
            if isinstance(ct, str) and isinstance(key, str) and key:
                out.append((ct, key))
    if manifest.root is not None:
        out.extend(_iter_eval_node_component_keys(manifest.root))
    return out


def _validate_closure(
    closure: Optional[list[ComponentManifest]],
    component: Any,
) -> None:
    """Validate that a closure is well-formed and leaf-first for upload.

    The root is identified by (component_type, key). Raises RuntimeError on failure.
    """
    if closure is None:
        raise RuntimeError(
            f"Closure is required for upload but was not provided for "
            f"'{getattr(component, 'name', component)}'."
        )
    if not closure:
        raise RuntimeError(
            f"Closure is empty — cannot upload '{getattr(component, 'name', component)}'."
        )
    ct = _component_type_name(component)
    key = getattr(component, "key", "")
    closure_by_key: dict[tuple[str, str], ComponentManifest] = {}
    closure_index: dict[tuple[str, str], int] = {}
    for idx, manifest in enumerate(closure):
        ck = (manifest.component_type, manifest.key)
        closure_by_key.setdefault(ck, manifest)
        closure_index.setdefault(ck, idx)
    root = (ct, key)
    if root not in closure_by_key:
        available = [(m.component_type, m.key) for m in closure]
        raise RuntimeError(
            f"Root component ({ct!r}, {key!r}) is not present in the closure. "
            f"Available: {available}"
        )
    for manifest in closure:
        parent = (manifest.component_type, manifest.key)
        parent_index = closure_index[parent]
        for child in _iter_manifest_child_component_keys(manifest):
            if child not in closure_by_key:
                raise RuntimeError(
                    f"Closure is missing dependency {child!r} required by "
                    f"{parent!r}."
                )
            child_index = closure_index[child]
            if child_index >= parent_index:
                raise RuntimeError(
                    f"Closure must be leaf-first. Dependency {child!r} for "
                    f"{parent!r} appears at position {child_index}, which is "
                    f"not earlier than the parent position {parent_index}."
                )


def _annotate_path_taken(
    path_taken: dict | None,
    synced_versions: dict[tuple[str, str], SyncedComponentVersion],
) -> dict | None:
    """Recursively annotate orchestration trace steps with synced child identities."""
    if not isinstance(path_taken, dict):
        return path_taken
    if path_taken.get("kind") != "orchestration":
        return path_taken
    steps = path_taken.get("steps")
    if not isinstance(steps, list):
        return path_taken
    annotated: list[dict] = []
    for step in steps:
        if not isinstance(step, dict):
            annotated.append(step)
            continue
        step_copy = dict(step)
        ct = step_copy.get("component_type", "")
        key = step_copy.get("component_key", "")
        synced = synced_versions.get((ct, key))
        if synced:
            step_copy["family_id"] = synced.family_id
            step_copy["component_definition_id"] = synced.definition_id
            step_copy["version"] = synced.version
        nested_trace = step_copy.get("trace")
        if isinstance(nested_trace, dict):
            step_copy["trace"] = _annotate_path_taken(nested_trace, synced_versions)
        annotated.append(step_copy)
    return {**path_taken, "steps": annotated}


def sync_closure(
    client: Client,
    closure: list[ComponentManifest],
    org_id: str,
    user_id: Optional[str] = None,
) -> dict[tuple[str, str], SyncedComponentVersion]:
    """Sync all manifests in the closure. Returns mapping of (type, key) -> SyncedComponentVersion.

    The closure must be in leaf-first order so that when a parent is synced,
    all of its child family_ids are already in the accumulated map.
    """
    _check_closure_conflicts(closure)
    synced: dict[tuple[str, str], SyncedComponentVersion] = {}
    family_ids: dict[tuple[str, str], str] = {}
    for manifest in closure:
        def_id, family_id, version = _sync_component_version(
            client, manifest, org_id, user_id=user_id, family_id_map=family_ids
        )
        _upsert_owner_entity_from_manifest(client, manifest, org_id, family_id, user_id=user_id)
        family_ids[(manifest.component_type, manifest.key)] = family_id
        synced[(manifest.component_type, manifest.key)] = SyncedComponentVersion(
            family_id=family_id,
            definition_id=def_id,
            version=version,
        )
    return synced


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def write_run_results(
    component: Any,
    eval_component: Any,
    component_traces: list[EvalTrace],
    eval_traces: list[EvalTrace | None],
    supabase_url: str,
    supabase_anon_key: str,
    access_token: str,
    org_id: str,
    closure: Optional[list[ComponentManifest]] = None,
    dataset_id: Optional[str] = None,
    dataset_item_ids: Optional[list[str]] = None,
    dataset_name: Optional[str] = None,
    dataset_rows: Optional[list[dict]] = None,
    dataset_input_columns: Optional[dict[str, Any]] = None,
    sync_managed_eval_only: bool = False,
    component_model_choice: Optional[str] = None,
) -> UploadResult | None:
    """Sync definitions then write run results.

    1. Sync component closure definitions (all transitive deps) or single component
    2. Sync eval definition
    3. Create autorater_runs row
    4. Create autorater_results rows
    """
    client = get_supabase_client(supabase_url, supabase_anon_key, access_token)

    user_id = _get_user_id_from_token(access_token)
    owner_type = _get_owner_type(component.component_type)

    # Step 1: Validate closure, sync all definitions, then annotate traces with synced identity.
    try:
        _validate_closure(closure, component)
        synced_versions = sync_closure(client, closure, org_id, user_id=user_id or None)
        root_synced = synced_versions[(_component_type_name(component), component.key)]
        family_id = root_synced.family_id
        for comp_trace in component_traces:
            if comp_trace.path_taken is not None:
                comp_trace.path_taken = _annotate_path_taken(comp_trace.path_taken, synced_versions)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to sync component definition for '{component.name}': {exc}"
        ) from exc

    # Step 2: Upsert slim entity row in the typed table.
    try:
        entity_id = _upsert_owner_entity(client, component, org_id, family_id, user_id=user_id or None)
    except Exception as exc:
        raise RuntimeError(
            f"Failed to upsert {_component_type_name(component)} entity '{component.name}': {exc}"
        ) from exc

    resolved_dataset_id = dataset_id
    resolved_dataset_item_ids = dataset_item_ids
    if dataset_rows and (resolved_dataset_id is None or not resolved_dataset_item_ids):
        inferred_dataset_name = dataset_name or f"{component.name}_dataset"
        try:
            resolved_dataset_id, resolved_dataset_item_ids = _ensure_dataset_with_items(
                client,
                org_id=org_id,
                owner_id=entity_id,
                owner_type=owner_type,
                dataset_name=inferred_dataset_name,
                dataset_rows=dataset_rows,
                dataset_input_columns=dataset_input_columns,
                dataset_id=resolved_dataset_id,
            )
        except Exception as exc:
            raise RuntimeError(
                f"Failed to create/upload dataset '{inferred_dataset_name}' for '{component.name}': {exc}"
            ) from exc
    elif resolved_dataset_id is not None:
        try:
            _ensure_component_dataset_link(
                client,
                owner_id=entity_id,
                owner_type=owner_type,
                dataset_id=resolved_dataset_id,
            )
        except Exception as exc:
            raise RuntimeError(
                f"Failed to link existing dataset {resolved_dataset_id} to '{component.name}': {exc}"
            ) from exc

    valid_eval_traces = [t for t in eval_traces if t is not None]
    if sync_managed_eval_only:
        autorater_id = _sync_managed_autorater(
            client,
            eval_component=eval_component,
            org_id=org_id,
            owner_id=entity_id,
            owner_type=owner_type,
        )
        return UploadResult(
            dataset_id=resolved_dataset_id,
            dataset_item_ids=resolved_dataset_item_ids,
            autorater_id=autorater_id,
        )

    # Step 2: Upsert autorater
    if not valid_eval_traces:
        return UploadResult(
            dataset_id=resolved_dataset_id,
            dataset_item_ids=resolved_dataset_item_ids,
        )

    autorater_id = _sync_managed_autorater(
        client,
        eval_component=eval_component,
        org_id=org_id,
        owner_id=entity_id,
        owner_type=owner_type,
    )

    # Step 3: Aggregate stats
    scores = [
        float(t.output.get("score", 0.0))
        for t in valid_eval_traces
        if t.output and isinstance(t.output, dict) and "score" in t.output
    ]
    avg_score = sum(scores) / len(scores) if scores else 0.0
    items_total = len(eval_traces)
    items_completed = sum(1 for t in valid_eval_traces if t.status == "completed")
    items_failed = sum(1 for t in valid_eval_traces if t.status == "failed")
    items_failed += sum(1 for t in eval_traces if t is None)
    overall_status = "completed" if items_failed == 0 else "failed"
    now = datetime.now(timezone.utc).isoformat()

    trigger_run_id = valid_eval_traces[0].trigger_run_id
    model_choice = component_model_choice or infer_run_model_choice(component, closure)
    component_temperature = _infer_run_temperature(component, closure)
    component_top_k = getattr(component, "top_k", None)

    run_payload: dict = {
        "autorater_id": autorater_id,
        "status": overall_status,
        "overall_score": avg_score,
        "dataset_id": resolved_dataset_id,
        "error": valid_eval_traces[0].error if items_failed > 0 else None,
        "trigger_run_id": trigger_run_id,
        "trigger_source": "sdk",
        "items_total": items_total,
        "items_completed": items_completed,
        "items_failed": items_failed,
        "completed_at": now,
    }
    if model_choice:
        run_payload["model_choice"] = model_choice
    if component_temperature is not None:
        run_payload["temperature"] = component_temperature
    if component_top_k is not None:
        run_payload["top_k"] = component_top_k

    run_result = client.table("autorater_runs").insert(run_payload).execute()

    run_rows = _result_data(run_result)
    autorater_run_id: Optional[str] = run_rows[0].get("id") if run_rows else None

    # Step 4: Write per-item results
    if autorater_run_id:
        for i, eval_trace in enumerate(eval_traces):
            if eval_trace is None:
                continue

            item_score = 0.0
            result_metadata = {}
            if eval_trace.output and isinstance(eval_trace.output, dict):
                item_score = float(eval_trace.output.get("score", 0.0))
                result_metadata = {
                    k: v
                    for k, v in eval_trace.output.items()
                    if k not in {"score", "output"}
                }
            component_note = _build_component_result_note(
                component_traces[i] if i < len(component_traces) else None
            )
            if component_note:
                result_metadata = {
                    **result_metadata,
                    **component_note,
                }

            row_payload: dict = {
                "autorater_run_id": autorater_run_id,
                "result": result_metadata if result_metadata else {},
                "status": eval_trace.status,
                "overall_score": item_score,
                "llm_response": (
                    _derive_model_response(component_traces[i].output)
                    if i < len(component_traces)
                    else ""
                ),
                "path_taken": (
                    component_traces[i].path_taken
                    if i < len(component_traces)
                    else None
                ),
                "completed_at": now if eval_trace.status in ("completed", "failed") else None,
            }

            if resolved_dataset_item_ids and i < len(resolved_dataset_item_ids):
                row_payload["dataset_item_id"] = resolved_dataset_item_ids[i]

            client.table("autorater_results").insert(row_payload).execute()

    if autorater_run_id is None:
        return None

    return UploadResult(
        dataset_id=resolved_dataset_id,
        dataset_item_ids=resolved_dataset_item_ids,
        autorater_id=autorater_id,
        autorater_run_id=autorater_run_id,
    )
