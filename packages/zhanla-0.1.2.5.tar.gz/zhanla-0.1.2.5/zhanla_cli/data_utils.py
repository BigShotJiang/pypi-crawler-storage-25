"""Dataset loading and schema validation shared by Python and TS runs."""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

_JSON_OUTPUT_ERROR_MARKERS = (
    "unterminated string in json",
    "unexpected end of json input",
    "jsondecodeerror",
    "expecting value",
    "extra data",
    "unexpected token",
)


def load_dataset(path: str) -> tuple[list[dict], dict | None]:
    """Load a dataset file and return (rows, config_or_None)."""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Dataset file not found: {path}")

    if p.suffix == ".json":
        data = json.loads(p.read_text())
        if isinstance(data, dict):
            rows = data.get("rows")
            if not isinstance(rows, list):
                raise ValueError(
                    "JSON dataset object form must include a top-level 'rows' array."
                )
            config = {key: value for key, value in data.items() if key != "rows"} or None
            return rows, config

        if not isinstance(data, list):
            raise ValueError(
                "JSON dataset must be a top-level array of objects or a legacy object with 'rows'."
            )

        config: dict[str, Any] | None = None
        rows = []
        saw_data_row = False
        for item in data:
            if (
                not saw_data_row
                and isinstance(item, dict)
                and ("_config" in item or "_schema" in item)
            ):
                merged_config = dict(config or {})
                raw_config = item.get("_config")
                if isinstance(raw_config, dict):
                    merged_config.update(raw_config)
                elif raw_config is not None:
                    merged_config["_config"] = raw_config
                if "_schema" in item:
                    merged_config["schema"] = item["_schema"]
                config = merged_config or None
                continue

            saw_data_row = True
            rows.append(item)
        return rows, config

    if p.suffix == ".csv":
        with p.open(newline="") as f:
            return list(csv.DictReader(f)), None

    raise ValueError(f"Unsupported dataset format: {p.suffix!r}. Expected .json or .csv.")


def validate_output_schema(output: dict, schema: Any, component_name: str) -> str | None:
    """Validate output against declared schema. Returns error message or None."""
    if schema is None:
        return None

    expected_keys: dict[str, Any] = {}
    if isinstance(schema, dict):
        if schema.get("type") == "object" and isinstance(schema.get("properties"), dict):
            expected_keys = schema["properties"]
        else:
            expected_keys = schema
    elif isinstance(schema, type) and hasattr(schema, "model_fields"):
        expected_keys = {name: field.annotation for name, field in schema.model_fields.items()}
    else:
        return None

    if not expected_keys:
        return None

    actual_keys = {k for k in output.keys() if not k.startswith("_")}
    expected_key_set = set(expected_keys.keys())

    missing = expected_key_set - actual_keys
    extra = actual_keys - expected_key_set

    errors: list[str] = []
    if missing:
        errors.append(f"Missing keys: {', '.join(sorted(missing))}")
    if extra:
        errors.append(f"Extra keys: {', '.join(sorted(extra))}")

    for key in expected_key_set & actual_keys:
        expected_type = expected_keys[key]
        actual_value = output[key]
        if isinstance(expected_type, dict):
            json_type = expected_type.get("type")
            if json_type is not None:
                type_map: dict[str, tuple[type, ...]] = {
                    "string": (str,),
                    "number": (int, float),
                    "integer": (int,),
                    "boolean": (bool,),
                    "array": (list,),
                    "object": (dict,),
                    "null": (type(None),),
                }
                allowed_types = type_map.get(json_type)
                if allowed_types is not None and not isinstance(actual_value, allowed_types):
                    errors.append(
                        f"Type mismatch for '{key}': expected {json_type}, "
                        f"got {type(actual_value).__name__}"
                    )
        elif isinstance(expected_type, type) and not isinstance(actual_value, expected_type):
            errors.append(
                f"Type mismatch for '{key}': expected {expected_type.__name__}, "
                f"got {type(actual_value).__name__}"
            )

    if not errors:
        return None
    return f"Output doesn't match declared output_schema for '{component_name}': {'; '.join(errors)}"


def is_json_output_error(error: str) -> bool:
    normalized = error.lower()
    return any(marker in normalized for marker in _JSON_OUTPUT_ERROR_MARKERS)
