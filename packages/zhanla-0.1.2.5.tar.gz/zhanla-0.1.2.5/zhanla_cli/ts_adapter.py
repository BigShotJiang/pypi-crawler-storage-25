"""Adapters that project TypeScript manifests/results onto the Python CLI contract."""
from __future__ import annotations

from typing import Callable

from zhanla_cli.contracts import (
    BranchNode,
    ComponentType,
    ConditionalStep,
    Edge,
    EvalTrace,
    LeafNode,
    OrchestrationStep,
    Step,
)
from zhanla_cli.manifest import ComponentManifest

_VALID_PATH_TAKEN_KINDS = {"agent", "orchestration", "skill", "tool"}


def _ref_key(ref: object) -> str:
    """Extract the key from a ComponentRef dict or object."""
    if isinstance(ref, dict):
        return ref["key"]
    return str(getattr(ref, "key", ""))


class ManifestBackedComponent:
    """Minimal component object backed by a ComponentManifest."""

    def __init__(self, manifest: ComponentManifest) -> None:
        self._manifest = manifest
        self.component_type = ComponentType(manifest.component_type)
        self.key = manifest.key
        self.name = manifest.name
        self.description = manifest.description
        self.instructions = manifest.instructions or ""
        self.model = manifest.model
        self.temperature = manifest.temperature
        self.output_schema = manifest.output_schema
        self.tools: list[object] = []
        self.skills: list[object] = []
        self.agents: list[object] = []
        self.steps: list[OrchestrationStep] = []
        self.evals: list[object] = []
        self.weights = manifest.weights
        self.root: BranchNode | None = None
        self.fn = None
        self.is_async = bool(manifest.is_async)
        self.source_code = manifest.source_code
        self.source_language = manifest.source_language
        self.source_format = manifest.source_format
        self.model_response_format = manifest.model_response_format or "JSON"
        self.is_runnable = manifest.is_runnable
        self.is_eval = manifest.is_eval


def build_manifest_component(
    manifest: ComponentManifest,
    available_manifests: list[ComponentManifest],
) -> ManifestBackedComponent:
    """Rehydrate a manifest into a minimal ZhanlaComponent tree for writer sync.

    Resolution is key-based: nested component refs contain keys, and we look
    up manifests by their stable key rather than their mutable name.
    """
    by_key = {m.key: m for m in available_manifests}
    cache: dict[str, ManifestBackedComponent] = {}

    def resolve(key: str) -> ManifestBackedComponent:
        if key in cache:
            return cache[key]
        nested_manifest = by_key.get(key)
        if nested_manifest is None:
            raise RuntimeError(
                f"Missing nested manifest with key '{key}' "
                f"required by '{manifest.name}' (key={manifest.key})"
            )
        comp = ManifestBackedComponent(nested_manifest)
        cache[key] = comp

        if nested_manifest.tool_refs:
            comp.tools = [resolve(_ref_key(r)) for r in nested_manifest.tool_refs]
        if nested_manifest.skill_refs:
            comp.skills = [resolve(_ref_key(r)) for r in nested_manifest.skill_refs]
        if nested_manifest.agent_refs:
            comp.agents = [resolve(_ref_key(r)) for r in nested_manifest.agent_refs]
        if nested_manifest.eval_refs:
            comp.evals = [resolve(_ref_key(r)) for r in nested_manifest.eval_refs]
        if nested_manifest.steps:
            comp.steps = [_step_from_manifest(step) for step in nested_manifest.steps]
        if nested_manifest.root:
            comp.root = _branch_from_manifest(nested_manifest.root, resolve)

        return comp

    def _step_from_manifest(step: dict) -> OrchestrationStep:
        if step.get("is_conditional"):
            component = ConditionalStep(
                condition=lambda _ctx: True,
                if_true=step.get("if_true", ""),
                if_false=step.get("if_false", ""),
            )
        else:
            component = resolve(_ref_key(step["component_ref"]))
        return OrchestrationStep(
            name=step["name"],
            component=component,
            next=list(step.get("next") or []),
        )

    def _edge_from_manifest(edge: dict, resolver: Callable[[str], ManifestBackedComponent]) -> Edge:
        node = edge["node"]
        if node["type"] == "leaf":
            child = LeafNode(eval=resolver(_ref_key(node["eval_ref"])))
        else:
            child = _branch_from_manifest(node, resolver)
        return Edge(weight=float(edge["weight"]), node=child)

    def _branch_from_manifest(
        branch: dict,
        resolver: Callable[[str], ManifestBackedComponent],
    ) -> BranchNode:
        return BranchNode(
            eval=resolver(_ref_key(branch["eval_ref"])),
            threshold=float(branch["threshold"]),
            if_pass=[_edge_from_manifest(edge, resolver) for edge in branch.get("if_pass", [])],
            if_fail=[_edge_from_manifest(edge, resolver) for edge in branch.get("if_fail", [])],
        )

    return resolve(manifest.key)


def ts_result_to_traces(
    *,
    row: dict,
    row_result: dict,
    component: object,
    eval_component: object | None,
    trigger_run_id: str,
) -> tuple[EvalTrace, EvalTrace | None]:
    """Convert a TS row result into Python-style EvalTrace objects."""
    status = row_result.get("status")
    output = row_result.get("output") if status == "ok" else None
    error = row_result.get("error") if status == "error" else None

    component_trace = EvalTrace(
        name=component.name,
        component_type=component.component_type,
        input=row,
        output=output if isinstance(output, dict) else None,
        error=error,
        latency_ms=float(row_result.get("latency_ms") or 0.0),
        steps=_steps_from_payload(row_result.get("component_trace")),
        status="completed" if status == "ok" else "failed",
        trigger_run_id=trigger_run_id,
        path_taken=_path_taken_from_payload(
            row_result.get("pathTaken", row_result.get("path_taken"))
        ),
    )

    if eval_component is None or status != "ok":
        return component_trace, None

    eval_output = row_result.get("eval_output")
    eval_error = row_result.get("eval_error")
    eval_trace = EvalTrace(
        name=eval_component.name,
        component_type=eval_component.component_type,
        input={**row, **(output or {})},
        output=eval_output if isinstance(eval_output, dict) else None,
        error=eval_error if isinstance(eval_error, str) else None,
        latency_ms=float(row_result.get("eval_latency_ms") or 0.0),
        steps=_steps_from_payload(row_result.get("eval_trace")),
        status="failed" if eval_error else "completed",
        trigger_run_id=trigger_run_id,
    )
    return component_trace, eval_trace


def _steps_from_payload(payload: object) -> list[Step]:
    if not isinstance(payload, list):
        return []
    out: list[Step] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        name = item.get("name")
        if not isinstance(name, str):
            continue
        out.append(Step(name=name, data=item.get("data")))
    return out


def _path_taken_from_payload(payload: object) -> dict | None:
    if not isinstance(payload, dict):
        return None
    kind = payload.get("kind")
    if not isinstance(kind, str) or kind not in _VALID_PATH_TAKEN_KINDS:
        return None
    return payload
