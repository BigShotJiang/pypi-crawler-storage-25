"""Background update-notifier for the zhanla CLI and related SDKs."""
import atexit
import json
import os
import subprocess
import sys
import threading
from datetime import datetime, timedelta, timezone
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as pkg_version
from pathlib import Path

CACHE_FILE = Path.home() / ".benchmark" / "version_cache.json"
CACHE_TTL = timedelta(hours=24)

_notices: list[str] = []
_lock = threading.Lock()


def _should_skip() -> bool:
    return bool(os.environ.get("CI") or os.environ.get("NO_UPDATE_NOTIFIER"))


def _version_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.strip().split("."))
    except (ValueError, AttributeError):
        return ()


def _is_newer(latest: str, current: str) -> bool:
    return _version_tuple(latest) > _version_tuple(current)


def _load_cache() -> dict | None:
    try:
        data = json.loads(CACHE_FILE.read_text())
        checked_at = datetime.fromisoformat(data["checked_at"])
        if datetime.now(tz=timezone.utc) - checked_at < CACHE_TTL:
            return data
    except Exception:
        pass
    return None


def _save_cache(latest: dict[str, str]) -> None:
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        CACHE_FILE.write_text(
            json.dumps(
                {
                    "checked_at": datetime.now(tz=timezone.utc).isoformat(),
                    "latest": latest,
                }
            )
        )
    except Exception:
        pass


def _fetch_latest_pypi(package: str) -> str | None:
    try:
        import httpx
        r = httpx.get(f"https://pypi.org/pypi/{package}/json", timeout=5)
        r.raise_for_status()
        return r.json()["info"]["version"]
    except Exception:
        return None


def _fetch_latest_npm(package: str) -> str | None:
    try:
        import httpx
        encoded = package.replace("/", "%2F")
        r = httpx.get(f"https://registry.npmjs.org/{encoded}/latest", timeout=5)
        r.raise_for_status()
        return r.json()["version"]
    except Exception:
        return None


def _get_ts_sdk_installed_version() -> str | None:
    try:
        result = subprocess.run(
            ["npx", "--no-install", "zhanla-sdk-ts", "version"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip() or None
    except Exception:
        pass
    return None


def _check_worker() -> None:
    cache = _load_cache()
    if cache:
        latest = cache["latest"]
    else:
        latest = {}
        py_cli = _fetch_latest_pypi("zhanla")
        if py_cli:
            latest["zhanla"] = py_cli
        py_sdk = _fetch_latest_pypi("zhanla-sdk-py")
        if py_sdk:
            latest["zhanla-sdk-py"] = py_sdk
        ts_sdk = _fetch_latest_npm("@zhanla/sdk-ts")
        if ts_sdk:
            latest["@zhanla/sdk-ts"] = ts_sdk
        if latest:
            _save_cache(latest)

    notices: list[str] = []

    cli_latest = latest.get("zhanla")
    if cli_latest:
        try:
            cli_current = pkg_version("zhanla")
            if _is_newer(cli_latest, cli_current):
                notices.append(
                    f"Update available: zhanla {cli_current} -> {cli_latest}\n"
                    f"  Run: pip install --upgrade zhanla"
                )
        except PackageNotFoundError:
            pass

    py_sdk_latest = latest.get("zhanla-sdk-py")
    if py_sdk_latest:
        try:
            py_sdk_current = pkg_version("zhanla-sdk-py")
            if _is_newer(py_sdk_latest, py_sdk_current):
                notices.append(
                    f"Update available: zhanla-sdk-py {py_sdk_current} -> {py_sdk_latest}\n"
                    f"  Run: pip install --upgrade zhanla-sdk-py"
                )
        except PackageNotFoundError:
            pass

    ts_sdk_latest = latest.get("@zhanla/sdk-ts")
    if ts_sdk_latest:
        ts_sdk_current = _get_ts_sdk_installed_version()
        if ts_sdk_current and _is_newer(ts_sdk_latest, ts_sdk_current):
            notices.append(
                f"Update available: @zhanla/sdk-ts {ts_sdk_current} -> {ts_sdk_latest}\n"
                f"  Run: npm install -g @zhanla/sdk-ts@latest"
            )

    with _lock:
        _notices.extend(notices)


def _print_notices_at_exit(thread: threading.Thread) -> None:
    thread.join(timeout=3)
    with _lock:
        if not _notices:
            return
    try:
        from rich.console import Console
        from rich.panel import Panel

        err_console = Console(stderr=True, highlight=False)
        body = "\n\n".join(_notices)
        err_console.print(
            Panel(body, title="[bold yellow]Updates available[/bold yellow]", border_style="yellow"),
            soft_wrap=True,
        )
    except Exception:
        for notice in _notices:
            print(notice, file=sys.stderr)


def start_version_check() -> None:
    if _should_skip():
        return
    thread = threading.Thread(target=_check_worker, daemon=True, name="zhanla-version-check")
    thread.start()
    atexit.register(_print_notices_at_exit, thread)
