from enum import StrEnum

from zbxtemplar.dicts.Schema import Schema, SchemaField
from zbxtemplar.decree.DecreeEntity import DecreeEntity
from zbxtemplar.decree.Token import Token
from zbxtemplar.decree.constants import ActiveStatus


class Severity(StrEnum):
    """Trigger severity levels."""
    NOT_CLASSIFIED = "NOT_CLASSIFIED"
    INFORMATION = "INFORMATION"
    WARNING = "WARNING"
    AVERAGE = "AVERAGE"
    HIGH = "HIGH"
    DISASTER = "DISASTER"

    @staticmethod
    def mask(severities: list) -> int:
        mask = 0
        for s in severities:
            mask |= Severity._API_VALUES[s]
        return mask


Severity._API_VALUES = {
    "NOT_CLASSIFIED": 1, "INFORMATION": 2, "WARNING": 4,
    "AVERAGE": 8, "HIGH": 16, "DISASTER": 32,
}

from zbxtemplar.decree.UserGroup import UserGroup


class UserMedia(DecreeEntity):
    """Notification media configuration for a managed user."""

    _SCHEMA = [
        SchemaField("type", optional=False, type=str, description="Zabbix media type name."),
        SchemaField("sendto", optional=False, type=str, description="Recipient address or target for the media type."),
        SchemaField("active", str_type="ENABLED or DISABLED", type=ActiveStatus,
                    description="Whether the media is enabled."),
        SchemaField("severity", type=list[Severity], str_type="list[Severity]",
                    description="Enabled trigger severities."),
        SchemaField("period", type=str, description="Zabbix media active time period, for example 1-7,00:00-24:00."),
    ]

    def __init__(self, media_type: str, sendto: str):
        self.type = media_type
        self.sendto = sendto

    def set_severity(self, severity: list):
        """Set which trigger severities activate this media. Pass a list of Severity constants."""
        self.severity = severity
        return self

    def set_period(self, period: str):
        """Set the active time window, e.g. ``"1-7,00:00-24:00"``."""
        self.period = period
        return self

    def severity_to_list(self):
        return ",".join(self.severity)


class User(DecreeEntity, Schema):
    """Zabbix user account managed by decree YAML."""

    _SCHEMA = [
        SchemaField("username", optional=False, description="Zabbix username."),
        SchemaField("role", optional=False, description="Zabbix role name assigned to the user."),
        SchemaField("password", description="Password to set when creating or updating the user."),
        SchemaField("groups", str_type="list[str]", description="User group names to attach to the user."),
        SchemaField("medias", str_type="list[UserMedia]", description="Media definitions for the user."),
        SchemaField("token", str_type="Token", description="API token provisioning configuration for the user."),
        SchemaField("force_token", str_type="bool", description="Update and re-generate an existing token with the same name."),
    ]

    def __init__(self, username: str, role: str):
        self.username = username
        self.role = role
        self.password = None
        self.groups = []
        self.medias = []
        self.token = None
        self.force_token = None

    def set_password(self, password: str):
        """Set the login password. Supports env-var placeholder syntax, e.g. ``"${ZBX_PASSWORD}"``."""
        self.password = password
        return self

    def link_group(self, group):
        """Assign to a user group. Accepts a UserGroup object or name string. Raises on duplicate."""
        name = group.name if isinstance(group, UserGroup) else group
        if name in self.groups:
            raise ValueError(
                f"Duplicate group '{name}' on user '{self.username}'"
            )
        self.groups.append(name)
        return self

    def add_media(self, media_type: str, sendto: str, severity: list | None = None, period: str | None = None) -> "UserMedia":
        """Create and attach a notification media entry. Returns the created UserMedia."""
        media = UserMedia(media_type, sendto)
        if severity is not None:
            media.set_severity(severity)
        if period is not None:
            media.set_period(period)
        self.medias.append(media)
        return media

    def set_token(self, name: str, store_at, expires_at=None, force: bool = False) -> Token:
        """Create and provision an API token for this user. Returns the created Token."""
        self.token = Token(name, store_at=store_at, expires_at=expires_at)
        if force:
            self.force_token = True
        return self.token

    def medias_to_list(self):
        return [m.to_dict() for m in self.medias]

    @classmethod
    def from_dict(cls, data: dict, user_groups=None):
        cls.validate(data)
        user = cls(data["username"], data["role"])
        if "password" in data:
            user.set_password(data["password"])
        for g in data.get("groups", []):
            user.link_group(g)
            if user_groups is not None and g not in user_groups:
                user_groups[g] = UserGroup(g)
        for m in data.get("medias", []):
            user.medias.append(UserMedia.from_dict(m))
        if "token" in data:
            user.token = Token.from_dict(data["token"])
            if data.get("force_token"):
                user.force_token = True
        return user
