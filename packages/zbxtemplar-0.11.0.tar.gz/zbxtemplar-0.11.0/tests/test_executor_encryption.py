from unittest.mock import MagicMock

import pytest

from zbxtemplar.decree.Encryption import HostEncryption, EncryptionMode
from zbxtemplar.dicts.Decree import Decree, EncryptionDecree
from zbxtemplar.executor.operations.EncryptionOperation import EncryptionOperation
from zbxtemplar.executor.DecreeExecutor import DecreeExecutor


@pytest.fixture
def api_mock():
    return MagicMock()


def _encryption_op(api, entries: list[HostEncryption]):
    """Wrap HostEncryption entries in an EncryptionDecree for the operation."""
    node = EncryptionDecree.__new__(EncryptionDecree)
    node.host_defaults = None
    node.hosts = entries
    return EncryptionOperation([node], api)


def test_encryption_executor_missing_host(api_mock):
    api_mock.host.get.return_value = []
    entry = HostEncryption("host1", connect_unencrypted=True, accept_unencrypted=True)

    op = _encryption_op(api_mock, [entry])
    with pytest.raises(ValueError, match="Host 'host1' not found"):
        op.execute()


def test_encryption_executor_update_psk(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1001",
        "host": "host1",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    entry = HostEncryption("host1", accept_unencrypted=True)
    entry.set_psk(connect=True, accept=True, identity="myid", psk="mypsk")

    op = _encryption_op(api_mock, [entry])
    op.execute()

    api_mock.host.update.assert_called_once_with(
        hostid="1001",
        tls_connect=2,
        tls_accept=3,  # 1 (UNENCRYPTED) | 2 (PSK)
        tls_psk_identity="myid",
        tls_psk="mypsk"
    )


def test_encryption_executor_no_update_needed(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1002",
        "host": "host2",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    entry = HostEncryption("host2", connect_unencrypted=True, accept_unencrypted=True)

    op = _encryption_op(api_mock, [entry])
    op.execute()
    api_mock.host.update.assert_not_called()


def _run_decree(api, data):
    decree = Decree.from_dict(data)
    ex = DecreeExecutor(decree, api)
    ex.execute()


def test_decree_merges_defaults(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1003",
        "host": "defaulted_host",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    _run_decree(api_mock, {"encryption": [{
        "host_defaults": {"connect": "UNENCRYPTED", "accept": "UNENCRYPTED"},
        "hosts": [{"host": "defaulted_host", "connect": "UNENCRYPTED", "accept": "UNENCRYPTED"}]
    }]})

    api_mock.host.get.assert_called_once()
    api_mock.host.update.assert_not_called()


def test_decree_psk_in_defaults(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1004",
        "host": "psk_host",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    _run_decree(api_mock, {"encryption": [{
        "host_defaults": {
            "connect": "PSK", "accept": "PSK",
            "psk_identity": "root_id", "psk": "root_secret"
        },
        "hosts": [{"host": "psk_host"}]
    }]})

    api_mock.host.update.assert_called_once_with(
        hostid="1004", tls_connect=2, tls_accept=2,
        tls_psk_identity="root_id", tls_psk="root_secret"
    )


def test_decree_host_overrides_psk_defaults_to_cert(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1005",
        "host": "cert_host",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    _run_decree(api_mock, {"encryption": [{
        "host_defaults": {
            "connect": "PSK", "accept": "UNENCRYPTED, PSK",
            "psk_identity": "default_id", "psk": "default_secret"
        },
        "hosts": [{
            "host": "cert_host",
            "connect": "CERT", "accept": "UNENCRYPTED, CERT",
            "issuer": "my_issuer", "subject": "my_subject"
        }]
    }]})

    api_mock.host.update.assert_called_once_with(
        hostid="1005", tls_connect=4,
        tls_accept=5,  # 1 | 4
        tls_issuer="my_issuer", tls_subject="my_subject"
    )


def test_decree_host_overrides_cert_defaults_to_psk(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1006",
        "host": "psk_only",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    _run_decree(api_mock, {"encryption": [{
        "host_defaults": {
            "connect": "CERT", "accept": "CERT",
            "issuer": "default_issuer", "subject": "default_subject"
        },
        "hosts": [{
            "host": "psk_only",
            "connect": "PSK", "accept": "PSK",
            "psk_identity": "my_id", "psk": "my_secret"
        }]
    }]})

    api_mock.host.update.assert_called_once_with(
        hostid="1006", tls_connect=2, tls_accept=2,
        tls_psk_identity="my_id", tls_psk="my_secret"
    )


def test_decree_host_inherits_defaults(api_mock):
    api_mock.host.get.return_value = [{
        "hostid": "1007",
        "host": "inheriting_host",
        "tls_connect": "1",
        "tls_accept": "1",
        "tls_issuer": "",
        "tls_subject": "",
        "tls_psk_identity": ""
    }]

    _run_decree(api_mock, {"encryption": [{
        "host_defaults": {
            "connect": "PSK", "accept": "UNENCRYPTED, PSK",
            "psk_identity": "shared_id", "psk": "shared_secret"
        },
        "hosts": [{"host": "inheriting_host"}]
    }]})

    api_mock.host.update.assert_called_once_with(
        hostid="1007", tls_connect=2,
        tls_accept=3,  # 1 | 2
        tls_psk_identity="shared_id", tls_psk="shared_secret"
    )
