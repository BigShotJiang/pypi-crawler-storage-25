from __future__ import annotations

import os
import signal
import subprocess
import sys
import time
from collections import defaultdict

import click
import psycopg

from plain.cli import register_cli

from ..database_url import postgres_cli_args, postgres_cli_env
from ..db import get_connection
from ..dialect import quote_name
from .converge import converge
from .decorators import database_management_command
from .diagnose import diagnose
from .schema import schema
from .sync import sync


@register_cli("postgres")
@click.group()
def cli() -> None:
    """Postgres operations"""


cli.add_command(converge)
cli.add_command(diagnose)
cli.add_command(schema)
cli.add_command(sync)


@cli.command()
@click.argument("parameters", nargs=-1)
@database_management_command
def shell(parameters: tuple[str, ...]) -> None:
    """Open an interactive database shell"""
    config = get_connection().settings_dict
    args = ["psql", *postgres_cli_args(config), *parameters, config["DATABASE"]]
    env = {**os.environ, **postgres_cli_env(config)}
    sigint_handler = signal.getsignal(signal.SIGINT)
    try:
        # Allow SIGINT to pass to psql to abort queries.
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        subprocess.run(args, env=env, check=True)
    except FileNotFoundError:
        # FileNotFoundError almost always means psql isn't installed or on
        # PATH, but could be raised for other reasons — the message covers
        # the common case.
        click.secho(
            "You appear not to have the 'psql' program installed or on your path.",
            fg="red",
            err=True,
        )
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        click.secho(
            '"{}" returned non-zero exit status {}.'.format(
                " ".join(e.cmd),
                e.returncode,
            ),
            fg="red",
            err=True,
        )
        sys.exit(e.returncode)
    finally:
        signal.signal(signal.SIGINT, sigint_handler)


@cli.command("drop-unknown-tables")
@click.option(
    "--yes",
    "-y",
    is_flag=True,
    help="Skip confirmation prompt.",
)
@database_management_command
def drop_unknown_tables(yes: bool) -> None:
    """Drop all tables not associated with a Plain model"""
    from ..introspection import get_unknown_tables

    conn = get_connection()
    unknown_tables = get_unknown_tables(conn)

    if not unknown_tables:
        click.echo("No unknown tables found.")
        return

    unknown_set = set(unknown_tables)
    table_count = len(unknown_tables)
    tables_label = f"{table_count} table{'s' if table_count != 1 else ''}"

    # Find foreign key constraints from kept tables that reference unknown tables
    cascade_warnings: defaultdict[str, list[tuple[str, str]]] = defaultdict(list)
    with conn.cursor() as cursor:
        for table in unknown_tables:
            cursor.execute(
                """
                SELECT conname, conrelid::regclass
                FROM pg_constraint
                WHERE confrelid = %s::regclass AND contype = 'f'
                """,
                [table],
            )
            for constraint_name, referencing_table in cursor.fetchall():
                if str(referencing_table) not in unknown_set:
                    cascade_warnings[table].append(
                        (constraint_name, str(referencing_table))
                    )

    click.secho("Unknown tables:", fg="yellow", bold=True)
    for table in unknown_tables:
        click.echo(f"  - {table}")
        for constraint_name, referencing_table in cascade_warnings[table]:
            click.secho(
                f"    ⚠ CASCADE will drop constraint {constraint_name} on {referencing_table}",
                fg="red",
            )
    click.echo()

    if not yes:
        if not click.confirm(f"Drop {tables_label} (CASCADE)? This cannot be undone."):
            return

    with conn.cursor() as cursor:
        for table in unknown_tables:
            click.echo(f"  Dropping {table}...", nl=False)
            cursor.execute(f"DROP TABLE IF EXISTS {quote_name(table)} CASCADE")
            click.echo(" OK")

    click.secho(f"✓ Dropped {tables_label}.", fg="green")


@cli.command()
def wait() -> None:
    """Wait for the database to be ready"""
    attempts = 0
    while True:
        attempts += 1
        waiting_for = False

        try:
            get_connection().ensure_connection()
        except psycopg.OperationalError:
            waiting_for = True

        if waiting_for:
            if attempts > 1:
                # After the first attempt, start printing them
                click.secho(
                    f"Waiting for database (attempt {attempts})",
                    fg="yellow",
                )
            time.sleep(1.5)
        else:
            click.secho("✔ Database ready", fg="green")
            break
