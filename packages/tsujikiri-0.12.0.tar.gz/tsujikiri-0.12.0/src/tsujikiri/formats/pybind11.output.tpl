{%- block prologue -%}
// DO NOT EDIT - Auto-generated pybind11 bindings for {{ module_name }} by tsujikiri
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

{% for inc in includes %}
#include {{ inc }}
{%- endfor %}
{%- block api_version %}
{%- if api_version %}

static constexpr const char* k_{{ module_name }}_api_version = "{{ api_version }}";
{%- endif %}
{%- endblock %}

namespace py = pybind11;

PYBIND11_MODULE({{ module_name }}, m)
{
{{ code_injections | code_at("beginning") }}
{%- endblock %}
{%- block api_version_registration %}
{%- if api_version %}
  m.attr("__api_version__") = k_{{ module_name }}_api_version;
{%- endif %}
{%- endblock %}
{%- block exception_registrations %}
{%- for exc in exception_registrations %}
  py::register_exception<{{ exc.cpp_type }}>(m, "{{ exc.python_name }}");
{%- endfor %}
{%- endblock %}
{%- for enum in enums %}
{%- block enum scoped %}
{%- if enum.is_anonymous %}
{%- for value in enum.values %}
{%- block anon_enum_value scoped %}
  m.attr("{{ value.name }}") = static_cast<int>({{ value.number }});
{%- endblock %}
{%- endfor %}
{%- else %}

  py::enum_<{{ enum.qualified_name }}>(m, "{{ enum.name }}"{% if enum.is_arithmetic %}, py::arithmetic(){% endif %}{% if enum.doc %}, "{{ enum.doc }}"{% endif %})
{%- for value in enum.values %}
{%- block enum_value scoped %}
    .value("{{ value.name }}", {{ enum.qualified_name }}::{{ value.original_name }}{% if value.doc %}, "{{ value.doc }}"{% endif %})
{%- endblock %}
{%- endfor %}
{%- if not enum.is_scoped %}
    .export_values();
{%- else %}
    ;
{%- endif %}
{%- endif %}
{%- endblock %}
{%- endfor %}
{%- for group in function_groups %}
{%- block function_group scoped %}
{%- if group.is_overloaded %}
{%- for fn in group.functions %}
{%- block function_overloaded scoped %}
{%- if fn.wrapper_code %}
  m.def("{{ group.name | camel_to_snake }}", {{ fn.wrapper_code }}{% if fn.doc %}, "{{ fn.doc }}"{% endif %});
{%- else %}
  m.def("{{ group.name | camel_to_snake }}", py::overload_cast<{{ fn.params | map(attribute='raw_type') | join(', ') }}>(&{{ fn.spelling }}){% for p in fn.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% if fn.return_ownership == "cpp" %}, py::return_value_policy::reference_internal{% elif fn.return_ownership == "script" %}, py::return_value_policy::take_ownership{% endif %}{% for p in fn.params %}{% if p.ownership == "cpp" %}, py::keep_alive<1, {{ loop.index + 1 }}>(){% endif %}{% endfor %}{% if fn.return_keep_alive %}, py::keep_alive<0, 1>(){% endif %}{% if fn.allow_thread %}, py::call_guard<py::gil_scoped_release>(){% endif %}{% if fn.is_deprecated %}, py::deprecated("{{ fn.deprecation_message }}"){% endif %}{% if fn.doc %}, "{{ fn.doc }}"{% endif %});
{%- endif %}
{%- endblock %}
{%- endfor %}
{%- else %}
{%- set fn = group.functions[0] %}
{%- if fn.wrapper_code %}
  m.def("{{ group.name | camel_to_snake }}", {{ fn.wrapper_code }}{% if fn.doc %}, "{{ fn.doc }}"{% endif %});
{%- else %}
  m.def("{{ group.name | camel_to_snake }}", &{{ fn.spelling }}{% for p in fn.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% if fn.return_ownership == "cpp" %}, py::return_value_policy::reference_internal{% elif fn.return_ownership == "script" %}, py::return_value_policy::take_ownership{% endif %}{% for p in fn.params %}{% if p.ownership == "cpp" %}, py::keep_alive<1, {{ loop.index + 1 }}>(){% endif %}{% endfor %}{% if fn.return_keep_alive %}, py::keep_alive<0, 1>(){% endif %}{% if fn.allow_thread %}, py::call_guard<py::gil_scoped_release>(){% endif %}{% if fn.is_deprecated %}, py::deprecated("{{ fn.deprecation_message }}"){% endif %}{% if fn.doc %}, "{{ fn.doc }}"{% endif %});
{%- endif %}
{%- endif %}
{%- endblock %}
{%- endfor %}
{%- for cls in classes %}
{%- block class scoped %}
{%- if cls.has_virtual_methods %}

  class {{ cls.trampoline_name }} : public {{ cls.qualified_name }} {
  public:
    using {{ cls.qualified_name }}::{{ cls.cpp_name }};
{%- for vm in cls.virtual_methods %}
{%- block trampoline_method scoped %}
    {{ vm.raw_return_type }} {{ vm.name }}({% for p in vm.params %}{{ p.raw_type }} {{ p.name }}{% if not loop.last %}, {% endif %}{% endfor %}){% if vm.is_const %} const{% endif %} override {
        {% if vm.is_pure_virtual %}PYBIND11_OVERRIDE_PURE_NAME{% else %}PYBIND11_OVERRIDE_NAME{% endif %}({{ vm.raw_return_type }}, {{ cls.qualified_name }}, "{{ vm.name | camel_to_snake }}", {{ vm.name }}{% for p in vm.params %}, {{ p.name }}{% endfor %});
    }
{%- endblock %}
{%- endfor %}
{%- if cls.has_exposed_protected %}
{%- for pm in cls.exposed_protected_methods %}
{%- block trampoline_using scoped %}
    using {{ cls.qualified_name }}::{{ pm.spelling }};
{%- endblock %}
{%- endfor %}
{%- endif %}
{{ cls.declaration_injections | code_at("declaration") }}
  };
{%- endif %}
  {{ cls.code_injections | code_at("beginning") }}

  py::class_<{{ cls.qualified_name }}{% if cls.has_virtual_methods %}, {{ cls.trampoline_name }}{% endif %}{% if cls.holder_type %}, {{ cls.holder_type }}<{{ cls.qualified_name }}>{% endif %}{% for b in cls.public_bases %}, {{ b.qualified_name }}{% endfor %}>(m, "{{ cls.name }}"{% if cls.doc %}, "{{ cls.doc }}"{% endif %})
{%- block class_constructors scoped %}
{%- if not cls.force_abstract %}
{%- for ctor in cls.constructor_group.constructors %}
{%- block class_constructor_group scoped %}
    .def(py::init<{{ ctor.params | map(attribute='raw_type') | join(', ') }}>(){% for p in ctor.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% if ctor.doc %}, "{{ ctor.doc }}"{% endif %})
{%- endblock %}
{%- endfor %}
{%- endif %}
{%- endblock %}
{%- block class_methods scoped %}
{%- for group in cls.method_groups %}
{%- if group.is_static %}
{%- block class_static_method_group scoped %}
{%- if group.is_overloaded %}
{%- for method in group.methods %}
{%- block class_overloaded_static_method scoped %}
    .def_static("{{ group.name | camel_to_snake }}", py::overload_cast<{{ method.params | map(attribute='raw_type') | join(', ') }}>(&{{ cls.qualified_name }}::{{ method.spelling }}){% for p in method.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- endblock %}
{%- endfor %}
{%- else %}
{%- set method = group.methods[0] %}
{%- if method.wrapper_code %}
    .def_static("{{ group.name | camel_to_snake }}", {{ method.wrapper_code }}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- else %}
    .def_static("{{ group.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ method.spelling }}{% for p in method.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- endif %}
{%- endif %}
{%- endblock %}
{%- else %}
{%- block class_method_group scoped %}
{%- if group.is_overloaded %}
{%- for method in group.methods %}
{%- block class_overloaded_method scoped %}
{%- if method.is_operator and method.operator_name == "__repr__" %}
    .def("__repr__", [](const {{ cls.qualified_name }}& self) -> std::string { std::ostringstream _ss; _ss << self; return _ss.str(); })
{%- elif method.is_operator and method.operator_name %}
    .def("{{ method.operator_name }}", py::overload_cast<{{ method.params | map(attribute='raw_type') | join(', ') }}>(&{{ cls.qualified_name }}::{{ method.spelling }}{% if method.is_const %}, py::const_{% endif %}){% if method.return_ownership == "cpp" %}, py::return_value_policy::reference_internal{% elif method.return_ownership == "script" %}, py::return_value_policy::take_ownership{% endif %}{% for p in method.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- else %}
    .def("{{ group.name | camel_to_snake }}", py::overload_cast<{{ method.params | map(attribute='raw_type') | join(', ') }}>(&{{ cls.qualified_name }}::{{ method.spelling }}{% if method.is_const %}, py::const_{% endif %}){% if method.return_ownership == "cpp" %}, py::return_value_policy::reference_internal{% elif method.return_ownership == "script" %}, py::return_value_policy::take_ownership{% endif %}{% for p in method.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% for p in method.params %}{% if p.ownership == "cpp" %}, py::keep_alive<1, {{ loop.index + 1 }}>(){% endif %}{% endfor %}{% if method.return_keep_alive %}, py::keep_alive<0, 1>(){% endif %}{% if method.allow_thread %}, py::call_guard<py::gil_scoped_release>(){% endif %}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- endif %}
{%- endblock %}
{%- endfor %}
{%- else %}
{%- set method = group.methods[0] %}
{%- if method.is_operator and method.operator_name == "__repr__" %}
    .def("__repr__", [](const {{ cls.qualified_name }}& self) -> std::string { std::ostringstream _ss; _ss << self; return _ss.str(); })
{%- elif method.is_operator and method.operator_name %}
    .def("{{ method.operator_name }}", {% if method.wrapper_code %}{{ method.wrapper_code }}{% else %}&{{ cls.qualified_name }}::{{ method.spelling }}{% if method.return_ownership == "cpp" %}, py::return_value_policy::reference_internal{% elif method.return_ownership == "script" %}, py::return_value_policy::take_ownership{% endif %}{% for p in method.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% endif %}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- elif method.wrapper_code %}
    .def("{{ group.name | camel_to_snake }}", {{ method.wrapper_code }}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- else %}
    .def("{{ group.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ method.spelling }}{% if method.return_ownership == "cpp" %}, py::return_value_policy::reference_internal{% elif method.return_ownership == "script" %}, py::return_value_policy::take_ownership{% endif %}{% for p in method.params %}, py::arg("{{ p.name }}"){% if p.default %} = {{ p.default }}{% endif %}{% endfor %}{% for p in method.params %}{% if p.ownership == "cpp" %}, py::keep_alive<1, {{ loop.index + 1 }}>(){% endif %}{% endfor %}{% if method.return_keep_alive %}, py::keep_alive<0, 1>(){% endif %}{% if method.allow_thread %}, py::call_guard<py::gil_scoped_release>(){% endif %}{% if method.doc %}, "{{ method.doc }}"{% endif %})
{%- endif %}
{%- endif %}
{%- endblock %}
{%- endif %}
{%- endfor %}
{%- endblock %}
{%- block class_fields scoped %}
{%- for field in cls.fields %}
{%- block class_field scoped %}
{%- if field.is_static %}
{%- if field.read_only %}
    .def_readonly_static("{{ field.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ field.original_name }}{% if field.doc %}, "{{ field.doc }}"{% endif %})
{%- else %}
    .def_readwrite_static("{{ field.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ field.original_name }}{% if field.doc %}, "{{ field.doc }}"{% endif %})
{%- endif %}
{%- else %}
{%- if field.read_only %}
    .def_readonly("{{ field.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ field.original_name }}{% if field.doc %}, "{{ field.doc }}"{% endif %})
{%- else %}
    .def_readwrite("{{ field.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ field.original_name }}{% if field.doc %}, "{{ field.doc }}"{% endif %})
{%- endif %}
{%- endif %}
{%- endblock %}
{%- endfor %}
{%- endblock %}
{%- block class_properties scoped %}
{%- for prop in cls.properties %}
{%- block class_property scoped %}
{%- if prop.setter %}
    .def_property("{{ prop.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ prop.getter }}, &{{ cls.qualified_name }}::{{ prop.setter }}{% if prop.doc %}, "{{ prop.doc }}"{% endif %})
{%- else %}
    .def_property_readonly("{{ prop.name | camel_to_snake }}", &{{ cls.qualified_name }}::{{ prop.getter }}{% if prop.doc %}, "{{ prop.doc }}"{% endif %})
{%- endif %}
{%- endblock %}
{%- endfor %}
{%- endblock %}
{%- if cls.generate_hash %}
    .def("__hash__", [](const {{ cls.qualified_name }}& self) { return std::hash<{{ cls.qualified_name }}>{}(self); })
{%- endif %}
{%- if cls.has_free_ostream_op %}
    .def("__repr__", [](const {{ cls.qualified_name }}& self) -> std::string { std::ostringstream _ss; _ss << self; return _ss.str(); })
{%- endif %}
{{ cls.code_injections | code_at("end") }}
  ;
{%- endblock %}
{%- endfor %}
{%- block epilogue %}
  {{ code_injections | code_at("end") }}
}
{%- endblock %}
