# SPDX-License-Identifier: Apache-2.0
"""Conformance fixtures match the daemon's type contract.

Every JSON file under ``tests/conformance-fixtures/`` represents a real
shape the daemon emits. The test suite below validates the fixtures
against the daemon's own Pydantic models, so hand-authored drift from
the contract fails loudly.

Rust and Swift consumers read the same files and verify independently
against their own model layers — the contract bridge is the
*shape*, not a shared runtime.

If you intentionally change a response shape, regenerate or edit the
corresponding fixture file in the same PR. See the directory's
README.md for the full list.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from vaner.intent.deep_run_defaults import DeepRunDefaults
from vaner.mcp.contracts import Resolution
from vaner.setup.hardware import HardwareProfile
from vaner.setup.policy import VanerPolicyBundle
from vaner.setup.select import SelectionResult
from vaner.setup.serializers import answers_from_payload

FIXTURES = Path(__file__).parent.parent / "conformance-fixtures"

PREDICTION_SHAPE_KEYS = {
    "id": str,
    "spec": dict,
    "run": dict,
    "artifacts": dict,
}
SPEC_KEYS = {
    "label": str,
    "source": str,
    "confidence": float,
    "hypothesis_type": str,
    "specificity": str,
    "created_at": float,
}
RUN_KEYS = {
    "weight": float,
    "token_budget": int,
    "tokens_used": int,
    "model_calls": int,
    "scenarios_spawned": int,
    "scenarios_complete": int,
    "readiness": str,
    "updated_at": float,
}
ARTIFACTS_KEYS = {
    "scenario_ids": list,
    "evidence_score": float,
    "has_draft": bool,
    "has_briefing": bool,
    "thinking_trace_count": int,
}
PREDICTION_TRUST_KEYS = {
    "trust_status": str,
    "freshness": str,
    "invalidated_by": list,
    "watched_sources": list,
    "changed_sources": list,
    "diagnostic_status": str,
}


def _assert_shape(row: dict, expected: dict[str, type]) -> None:
    for key, expected_type in expected.items():
        assert key in row, f"missing key: {key}"
        value = row[key]
        if value is None:
            continue
        # float fields accept ints (JSON doesn't distinguish 0 vs 0.0)
        if expected_type is float and isinstance(value, int):
            continue
        assert isinstance(value, expected_type), f"key {key!r} expected {expected_type.__name__}, got {type(value).__name__}"


def _load(name: str) -> dict:
    path = FIXTURES / name
    return json.loads(path.read_text())


def test_predictions_active_envelope_shape():
    body = _load("predictions_active_sample.json")
    assert list(body.keys()) == ["predictions"], "envelope must be single `predictions` key"
    assert isinstance(body["predictions"], list)
    assert len(body["predictions"]) >= 1

    for row in body["predictions"]:
        _assert_shape(row, PREDICTION_SHAPE_KEYS)
        _assert_shape(row, PREDICTION_TRUST_KEYS)
        _assert_shape(row["spec"], SPEC_KEYS)
        _assert_shape(row["run"], RUN_KEYS)
        _assert_shape(row["artifacts"], ARTIFACTS_KEYS)
        # Enum-valued strings must be drawn from the documented sets
        assert row["spec"]["source"] in {
            "arc",
            "pattern",
            "llm_branch",
            "macro",
            "history",
            "goal",
            "artefact_item",
            "composer_intent",
        }
        assert row["spec"]["hypothesis_type"] in {"likely_next", "possible_branch", "long_tail"}
        assert row["spec"]["specificity"] in {"concrete", "category", "anchor"}
        assert row["run"]["readiness"] in {
            "queued",
            "grounding",
            "evidence_gathering",
            "drafting",
            "ready",
            "stale",
        }
        assert row["trust_status"] in {"ready", "preparing", "invalidated"}
        assert row["freshness"] in {"fresh", "recent", "stale"}


def test_predictions_single_shape():
    row = _load("predictions_single_sample.json")
    _assert_shape(row, PREDICTION_SHAPE_KEYS)
    _assert_shape(row, PREDICTION_TRUST_KEYS)
    _assert_shape(row["spec"], SPEC_KEYS)
    _assert_shape(row["run"], RUN_KEYS)
    _assert_shape(row["artifacts"], ARTIFACTS_KEYS)


def test_predictions_active_composer_fixture():
    """0.8.7 WS8: composer_intent prediction with composer_engagement.

    Exercises the present-case for the new optional fields the Rust
    mirror gained (PredictedPrompt.composer_engagement, ComposerEngagement
    struct). The fixture itself is the contract: if it stops parsing,
    either the Rust mirror or the Python serializer drifted.
    """
    body = _load("predictions_active_composer_sample.json")
    assert list(body.keys()) == ["predictions"]
    assert len(body["predictions"]) == 1
    row = body["predictions"][0]
    assert row["spec"]["source"] == "composer_intent"
    # composer_engagement is the new optional block.
    assert "composer_engagement" in row
    engagement = row["composer_engagement"]
    assert isinstance(engagement["composer_event_id"], str) and engagement["composer_event_id"]
    assert engagement["lifecycle_state"] in {
        "observing",
        "tentative",
        "stabilizing",
        "actionable",
        "submitted",
        "cleared",
        "abandoned",
    }
    # Optional fields may be present + typed, or absent.
    if engagement.get("inferred_intent_label") is not None:
        assert isinstance(engagement["inferred_intent_label"], str)
    if engagement.get("inferred_intent_confidence") is not None:
        assert isinstance(engagement["inferred_intent_confidence"], (int, float))
        assert 0.0 <= engagement["inferred_intent_confidence"] <= 1.0


def test_adopt_response_composer_carries_composer_event_id():
    """0.8.7 WS8: when an adopted prediction is composer_intent-sourced,
    Resolution.composer_event_id is populated for adoption-telemetry
    attribution. Other Resolution fixtures keep it as None.
    """
    body = _load("adopt_response_composer.json")
    resolution = Resolution.model_validate(body)
    assert resolution.composer_event_id == body["composer_event_id"]
    assert resolution.adopted_from_prediction_id == body["adopted_from_prediction_id"]


def test_legacy_adopt_responses_have_no_composer_event_id():
    """The 0.8.6 fixtures predate composer_event_id; they MUST decode
    cleanly with the field as None (byte-compat invariant)."""
    for fixture in ("adopt_response_rich.json", "adopt_response_minimal.json"):
        body = _load(fixture)
        assert "composer_event_id" not in body
        resolution = Resolution.model_validate(body)
        assert resolution.composer_event_id is None


@pytest.mark.parametrize(
    "fixture",
    [
        "adopt_response_rich.json",
        "adopt_response_minimal.json",
        # 0.8.7 WS8 — composer_event_id present case
        "adopt_response_composer.json",
    ],
)
def test_adopt_response_roundtrips_through_pydantic(fixture):
    """The Resolution Pydantic model must accept every shape the
    fixture represents. If validation fails the daemon's `Resolution`
    has drifted and the fixture needs updating (or the drift was
    unintended).

    Roundtrip-by-equality is intentionally NOT asserted — Pydantic
    fills in default fields (e.g. `provenance.memory: null`,
    `metrics: null`) that the fixture omits, and that's fine: Rust
    and Swift consumers use `#[serde(default)]` / `Codable` optionals
    for the same reason. Strict validation + field-presence is the
    contract; byte-identical roundtrip isn't.
    """
    body = _load(fixture)
    resolution = Resolution.model_validate(body)
    # Every fixture key must survive on the decoded object (as a field
    # or exposed attribute).
    for key in body:
        assert hasattr(resolution, key), f"Pydantic dropped attribute: {key}"
    # Spot-check the load-bearing fields — if these drift the client
    # ecosystem breaks.
    assert resolution.intent == body["intent"]
    assert resolution.confidence == body["confidence"]
    assert resolution.resolution_id == body["resolution_id"]
    assert resolution.adopted_from_prediction_id == body["adopted_from_prediction_id"]
    assert resolution.provenance.mode == body["provenance"]["mode"]


@pytest.mark.parametrize(
    "fixture,code",
    [
        ("error_codes/adopt_not_found.json", "not_found"),
        ("error_codes/adopt_engine_unavailable.json", "engine_unavailable"),
        ("error_codes/adopt_invalid_input.json", "invalid_input"),
    ],
)
def test_error_fixture_shape(fixture, code):
    body = _load(fixture)
    assert set(body.keys()) == {"code", "message"}, f"error body must be exactly code+message, got {sorted(body.keys())}"
    assert body["code"] == code
    assert isinstance(body["message"], str) and body["message"]


def test_every_fixture_is_registered():
    """Fail if a new JSON file appears in the fixtures directory
    without a test referencing it — prevents accidental orphans."""
    known = {
        "predictions_active_sample.json",
        "predictions_single_sample.json",
        "adopt_response_rich.json",
        "adopt_response_minimal.json",
        "error_codes/adopt_not_found.json",
        "error_codes/adopt_engine_unavailable.json",
        "error_codes/adopt_invalid_input.json",
        # 0.8.6 WS12a — setup-wizard fixtures.
        "setup_answers_sample.json",
        "setup_hardware_profile_sample.json",
        "setup_selection_sample.json",
        "setup_deep_run_defaults_sample.json",
        # 0.8.7 WS8 — composer_intent + composer_engagement fixtures.
        "predictions_active_composer_sample.json",
        "adopt_response_composer.json",
    }
    found = {str(p.relative_to(FIXTURES)) for p in FIXTURES.rglob("*.json")}
    orphans = found - known
    missing = known - found
    assert not orphans, f"unregistered fixtures: {sorted(orphans)}"
    assert not missing, f"expected fixtures absent from disk: {sorted(missing)}"


# ---------------------------------------------------------------------------
# 0.8.6 WS12a — setup-wizard fixture round-trips
# ---------------------------------------------------------------------------


def test_setup_answers_fixture_round_trips_through_python():
    """``answers_from_payload`` must accept the wire shape Rust mirrors."""
    body = _load("setup_answers_sample.json")
    answers = answers_from_payload(body)
    assert answers.work_styles == ("coding", "research")
    assert answers.priority == "quality"
    assert answers.compute_posture == "available_power"
    assert answers.cloud_posture == "hybrid_when_worth_it"
    assert answers.background_posture == "idle_more"


def test_setup_hardware_profile_fixture_matches_dataclass():
    """The fixture must construct a valid :class:`HardwareProfile`.

    Tuples in the dataclass become JSON arrays on the wire; we
    re-tuplise here to check construction succeeds.
    """
    body = _load("setup_hardware_profile_sample.json")
    profile = HardwareProfile(
        os=body["os"],
        cpu_class=body["cpu_class"],
        ram_gb=body["ram_gb"],
        gpu=body["gpu"],
        gpu_vram_gb=body["gpu_vram_gb"],
        is_battery=body["is_battery"],
        thermal_constrained=body["thermal_constrained"],
        detected_runtimes=tuple(body["detected_runtimes"]),
        detected_models=tuple(tuple(row) for row in body["detected_models"]),
        tier=body["tier"],
    )
    assert profile.os == "linux"
    assert profile.tier == "high_performance"
    assert profile.detected_models[0] == ("ollama", "llama3.1:8b", "4.7GB")


def _bundle_from_dict(raw: dict) -> VanerPolicyBundle:
    return VanerPolicyBundle(
        id=raw["id"],
        label=raw["label"],
        description=raw["description"],
        local_cloud_posture=raw["local_cloud_posture"],
        runtime_profile=raw["runtime_profile"],
        spend_profile=raw["spend_profile"],
        latency_profile=raw["latency_profile"],
        privacy_profile=raw["privacy_profile"],
        prediction_horizon_bias=dict(raw["prediction_horizon_bias"]),
        drafting_aggressiveness=raw["drafting_aggressiveness"],
        exploration_ratio=raw["exploration_ratio"],
        persistence_strength=raw["persistence_strength"],
        goal_weighting=raw["goal_weighting"],
        context_injection_default=raw["context_injection_default"],
        deep_run_profile=raw["deep_run_profile"],
    )


def test_setup_selection_fixture_matches_dataclass():
    """The fixture must construct a valid :class:`SelectionResult`."""
    body = _load("setup_selection_sample.json")
    result = SelectionResult(
        bundle=_bundle_from_dict(body["bundle"]),
        score=body["score"],
        reasons=tuple(body["reasons"]),
        runner_ups=tuple(_bundle_from_dict(b) for b in body["runner_ups"]),
        forced_fallback=body["forced_fallback"],
    )
    assert result.bundle.id == "hybrid_balanced"
    assert not result.forced_fallback
    assert len(result.reasons) == 3
    assert len(result.runner_ups) == 1
    assert result.runner_ups[0].id == "local_balanced"


def test_setup_deep_run_defaults_fixture_matches_dataclass():
    """The fixture must construct a valid :class:`DeepRunDefaults`."""
    body = _load("setup_deep_run_defaults_sample.json")
    defaults = DeepRunDefaults(
        preset=body["preset"],
        horizon_bias=body["horizon_bias"],
        locality=body["locality"],
        cost_cap_usd=body["cost_cap_usd"],
        focus=body["focus"],
        source_bundle_id=body["source_bundle_id"],
        reasons=tuple(body["reasons"]),
    )
    assert defaults.preset == "balanced"
    assert defaults.locality == "local_preferred"
    assert defaults.cost_cap_usd == 1.0
    assert defaults.source_bundle_id == "hybrid_balanced"
    assert len(defaults.reasons) == 5
