# SPDX-License-Identifier: Apache-2.0

"""Tests for `vaner clients` CLI (0.8.5 WS12)."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from vaner.cli.commands.app import app
from vaner.cli.commands.clients import clients_app

runner = CliRunner()


@pytest.fixture
def fake_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Pin HOME / Path.home() / shutil.which / APPDATA so clients are
    detectable under tmp_path with no leakage to the real machine.

    Mirrors the pattern from `tests/test_cli/test_init.py`.
    """
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    monkeypatch.setattr(Path, "home", staticmethod(lambda: home))
    monkeypatch.setenv("APPDATA", str(home / "AppData"))
    # Make `vaner` look installed at a stable absolute path so the launcher
    # ends up deterministic across platforms.
    monkeypatch.setattr(
        "vaner.cli.commands.mcp_clients.shutil.which",
        lambda name: f"/fake/bin/{name}" if name == "vaner" else None,
    )
    return home


def _seed_cursor(home: Path, repo_root: Path) -> None:
    # Cursor's user dir is what `_detect_cursor` looks for; create it.
    (home / ".cursor").mkdir(parents=True, exist_ok=True)


def _seed_claude_desktop(home: Path, monkeypatch: pytest.MonkeyPatch | None = None) -> None:
    """Seed Claude Desktop's config dir under the current host's
    detection path. Anthropic only ships Claude Desktop on macOS and
    Windows, so the post-fix detector returns None on Linux even
    when `~/.config/Claude/` exists (Vaner installs into that dir
    too — see commit "fix(cli): claude-desktop Linux false-positive").

    When called with a monkeypatch, force the detector to behave as
    if running on macOS so the claude-desktop path stays exercised
    on every CI runner. Tests that *want* the Linux behaviour
    (false-positive guard) don't pass a monkeypatch.
    """
    from vaner.cli.commands import mcp_clients

    if monkeypatch is not None:
        monkeypatch.setattr(mcp_clients, "_platform", lambda: "darwin")
    target_dir = mcp_clients._claude_desktop_dir()
    target_dir.mkdir(parents=True, exist_ok=True)


def _seed_continue(home: Path) -> None:
    (home / ".continue").mkdir(parents=True, exist_ok=True)


# ---------------------------------------------------------------------------
# detect
# ---------------------------------------------------------------------------


def test_detect_returns_every_known_client(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(
        clients_app,
        ["detect", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    ids = {c["id"] for c in payload["clients"]}
    expected = {
        "cursor",
        "claude-desktop",
        "claude-code",
        "vscode-copilot",
        "codex-cli",
        "windsurf",
        "zed",
        "continue",
        "cline",
        "roo",
    }
    assert expected.issubset(ids)


def test_detect_marks_seeded_clients_as_installed(fake_home: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    _seed_claude_desktop(fake_home, monkeypatch)
    _seed_continue(fake_home)
    result = runner.invoke(clients_app, ["detect", "--repo-root", str(repo), "--format", "json"])
    payload = json.loads(result.output)
    by_id = {c["id"]: c for c in payload["clients"]}
    assert by_id["cursor"]["detected"] is True
    assert by_id["claude-desktop"]["detected"] is True
    assert by_id["continue"]["detected"] is True
    # Unseeded clients remain missing.
    assert by_id["zed"]["detected"] is False
    assert by_id["windsurf"]["detected"] is False


def test_detect_skips_claude_desktop_on_linux(fake_home: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Anthropic doesn't ship Claude Desktop on Linux; seeing the
    config dir alone (Vaner's own installer creates it) must not
    flag the client as detected. Regression guard for the
    `_detect_claude_desktop` platform gate."""
    from vaner.cli.commands import mcp_clients

    monkeypatch.setattr(mcp_clients, "_platform", lambda: "linux")
    # Seed without forcing darwin — exercises the production Linux path.
    target_dir = mcp_clients._claude_desktop_dir()
    target_dir.mkdir(parents=True, exist_ok=True)

    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(clients_app, ["detect", "--repo-root", str(repo), "--format", "json"])
    payload = json.loads(result.output)
    by_id = {c["id"]: c for c in payload["clients"]}
    assert by_id["claude-desktop"]["detected"] is False


def test_detect_pretty_format_renders_table(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    result = runner.invoke(clients_app, ["detect", "--repo-root", str(repo)])
    assert result.exit_code == 0
    assert "MCP clients" in result.output
    assert "Cursor" in result.output


# ---------------------------------------------------------------------------
# install
# ---------------------------------------------------------------------------


def test_install_writes_to_cursor(fake_home: Path, tmp_path: Path) -> None:
    """Default install path runs the full leverage stack — MCP layer
    is the one this test cares about. Layer detail lives in
    test_launch.py / test_skills.py / test_primer.py."""

    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    result = runner.invoke(
        clients_app,
        ["install", "cursor", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    assert payload["results"][0]["client_id"] == "cursor"
    mcp_layer = next(layer for layer in payload["results"][0]["layers"] if layer["layer"] == "mcp")
    assert mcp_layer["action"] in ("added", "updated")
    config_path = Path(mcp_layer["path"])
    assert config_path.exists()
    blob = json.loads(config_path.read_text(encoding="utf-8"))
    assert "vaner" in blob["mcpServers"]
    assert blob["mcpServers"]["vaner"]["command"] == "/fake/bin/vaner"


def test_install_mcp_only_skips_other_layers(fake_home: Path, tmp_path: Path) -> None:
    """``--mcp-only`` is the legacy MCP-only behaviour for callers that
    want exactly the pre-Phase-C output shape (single ``action`` /
    ``path`` per result, no layers)."""

    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    result = runner.invoke(
        clients_app,
        ["install", "cursor", "--repo-root", str(repo), "--mcp-only", "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    # Legacy shape: action + path live at the top level of each result.
    assert payload["results"][0]["client_id"] == "cursor"
    assert payload["results"][0]["action"] in ("added", "updated")
    config_path = Path(payload["results"][0]["path"])
    assert config_path.exists()


def test_install_all_writes_to_every_detected(fake_home: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    _seed_claude_desktop(fake_home, monkeypatch)
    result = runner.invoke(
        clients_app,
        ["install", "--all", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    ids = [r["client_id"] for r in payload["results"]]
    assert "cursor" in ids
    assert "claude-desktop" in ids


def test_install_idempotent_when_entry_present(fake_home: Path, tmp_path: Path) -> None:
    """Re-running install on a wired client produces ``skipped`` for
    every applicable layer that already matches the rendered output."""

    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    runner.invoke(clients_app, ["install", "cursor", "--repo-root", str(repo)])
    second = runner.invoke(
        clients_app,
        ["install", "cursor", "--repo-root", str(repo), "--format", "json"],
    )
    payload = json.loads(second.output)
    mcp_layer = next(layer for layer in payload["results"][0]["layers"] if layer["layer"] == "mcp")
    assert mcp_layer["action"] == "skipped"


def test_install_preserves_user_other_servers(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    cursor_cfg = fake_home / ".cursor" / "mcp.json"
    cursor_cfg.write_text(
        json.dumps({"mcpServers": {"github": {"command": "/usr/local/bin/gh-mcp", "args": []}}}, indent=2),
        encoding="utf-8",
    )
    result = runner.invoke(clients_app, ["install", "cursor", "--repo-root", str(repo)])
    assert result.exit_code == 0
    blob = json.loads(cursor_cfg.read_text(encoding="utf-8"))
    assert "github" in blob["mcpServers"], "user's other MCP servers must survive install"
    assert "vaner" in blob["mcpServers"]


def test_install_dry_run_does_not_write(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    config_path = fake_home / ".cursor" / "mcp.json"
    assert not config_path.exists()
    result = runner.invoke(
        clients_app,
        ["install", "cursor", "--repo-root", str(repo), "--dry-run"],
    )
    assert result.exit_code == 0
    # The config file must NOT exist after a dry-run.
    assert not config_path.exists(), "dry-run must not write any files"


def test_install_unknown_client_errors(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(clients_app, ["install", "nonsense", "--repo-root", str(repo)])
    assert result.exit_code != 0
    assert "unknown client" in result.output.lower() or "Known:" in result.output


def test_install_requires_name_or_all(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(clients_app, ["install", "--repo-root", str(repo)])
    assert result.exit_code != 0


def test_install_claude_desktop_uses_repo_scoped_server_key(fake_home: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    from vaner.cli.commands import mcp_clients

    repo = tmp_path / "myrepo"
    repo.mkdir()
    _seed_claude_desktop(fake_home, monkeypatch)
    result = runner.invoke(
        clients_app,
        ["install", "claude-desktop", "--repo-root", str(repo)],
    )
    assert result.exit_code == 0
    # Resolve the platform-canonical config path the same way the daemon
    # does, so this test passes on macOS + Linux + Windows runners alike.
    cfg = mcp_clients._claude_desktop_dir() / "claude_desktop_config.json"
    blob = json.loads(cfg.read_text(encoding="utf-8"))
    # Wizard convention: vaner-<reponame> so multiple repos coexist.
    assert "vaner-myrepo" in blob["mcpServers"]


# ---------------------------------------------------------------------------
# uninstall
# ---------------------------------------------------------------------------


def test_uninstall_removes_only_vaner_entries(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    cursor_cfg = fake_home / ".cursor" / "mcp.json"
    cursor_cfg.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"command": "/usr/local/bin/gh-mcp", "args": []},
                    "vaner": {"command": "/fake/bin/vaner", "args": ["mcp", "--path", "."]},
                }
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    result = runner.invoke(
        clients_app,
        ["uninstall", "cursor", "--repo-root", str(repo)],
    )
    assert result.exit_code == 0
    blob = json.loads(cursor_cfg.read_text(encoding="utf-8"))
    assert "vaner" not in blob["mcpServers"]
    assert "github" in blob["mcpServers"]


def test_uninstall_when_no_entry_skips_cleanly(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    # No vaner entry; just an empty config.
    cfg = fake_home / ".cursor" / "mcp.json"
    cfg.write_text(json.dumps({"mcpServers": {}}, indent=2), encoding="utf-8")
    result = runner.invoke(
        clients_app,
        ["uninstall", "cursor", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["results"][0]["action"] == "skipped"


# ---------------------------------------------------------------------------
# doctor — launcher drift
# ---------------------------------------------------------------------------


def test_doctor_clean_when_no_drift(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    runner.invoke(clients_app, ["install", "cursor", "--repo-root", str(repo)])
    result = runner.invoke(
        clients_app,
        ["doctor", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["drift_count"] == 0


def test_doctor_detects_launcher_drift(fake_home: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    _seed_cursor(fake_home, repo)
    runner.invoke(clients_app, ["install", "cursor", "--repo-root", str(repo)])
    # Now simulate `vaner` moving (e.g. uv → pipx reinstall).
    monkeypatch.setattr(
        "vaner.cli.commands.mcp_clients.shutil.which",
        lambda name: "/new/bin/vaner" if name == "vaner" else None,
    )
    result = runner.invoke(
        clients_app,
        ["doctor", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code != 0  # non-zero exit signals drift to CI
    payload = json.loads(result.output)
    assert payload["drift_count"] >= 1
    cursor_drift = next(d for d in payload["drift"] if d["client_id"] == "cursor")
    assert cursor_drift["drift"] is True
    assert cursor_drift["current_in_config"] == "/fake/bin/vaner"
    assert cursor_drift["expected"] == "/new/bin/vaner"


# ---------------------------------------------------------------------------
# verify
# ---------------------------------------------------------------------------


def test_verify_json_returns_per_layer_status_for_every_client(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(
        clients_app,
        ["verify", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    ids = {r["client_id"] for r in payload["results"]}
    # The full registry of supported clients shows up.
    assert {"claude-code", "cursor", "zed", "windsurf", "roo"}.issubset(ids)
    # Every entry exposes the four layers, even when "applicable" is False.
    for r in payload["results"]:
        assert set(r["layers"].keys()) == {"mcp", "primer", "skill", "plugin"}
        assert r["overall"] in {"ready", "wired-mcp-only", "partial", "missing", "not-detected"}


def test_verify_marks_zed_primer_applicable(fake_home: Path, tmp_path: Path) -> None:
    """Zed is one of the three primer clients added in the recent
    PR (Phase A). The verify surface must report primer.applicable=true
    so the desktop wizard knows the layer is reachable here.
    """

    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(
        clients_app,
        ["verify", "--repo-root", str(repo), "--format", "json"],
    )
    assert result.exit_code == 0, result.output
    payload = json.loads(result.output)
    zed = next(r for r in payload["results"] if r["client_id"] == "zed")
    assert zed["layers"]["primer"]["applicable"] is True
    # No primer file written → wired=False, expected path is .rules.
    assert zed["layers"]["primer"]["wired"] is False
    assert zed["layers"]["primer"]["path"].endswith("/.rules")


def test_verify_marks_skill_layer_inapplicable_for_zed_and_claude_desktop(
    fake_home: Path,
    tmp_path: Path,
) -> None:
    """The skill layer is applicable wherever Vaner ships a vaner-feedback
    surface today. After Phase C, that's claude-code, cursor, codex-cli,
    continue, cline, windsurf, roo. The two genuine non-skill clients
    are Zed (no skill abstraction) and Claude Desktop (cloud-only, no
    local-disk integration). Those two stay ``applicable=False``.
    """

    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(
        clients_app,
        ["verify", "--repo-root", str(repo), "--format", "json"],
    )
    payload = json.loads(result.output)
    by_id = {r["client_id"]: r for r in payload["results"]}
    # Genuinely non-applicable per the capability matrix.
    assert by_id["zed"]["layers"]["skill"]["applicable"] is False
    assert by_id["claude-desktop"]["layers"]["skill"]["applicable"] is False
    # Phase C: Vaner now ships skill/workflow/prompt surfaces for these.
    assert by_id["claude-code"]["layers"]["skill"]["applicable"] is True
    assert by_id["cursor"]["layers"]["skill"]["applicable"] is True
    assert by_id["codex-cli"]["layers"]["skill"]["applicable"] is True
    assert by_id["continue"]["layers"]["skill"]["applicable"] is True
    assert by_id["cline"]["layers"]["skill"]["applicable"] is True
    assert by_id["windsurf"]["layers"]["skill"]["applicable"] is True
    assert by_id["roo"]["layers"]["skill"]["applicable"] is True


def test_verify_pretty_format_emits_table(fake_home: Path, tmp_path: Path) -> None:
    repo = tmp_path / "repo"
    repo.mkdir()
    result = runner.invoke(
        clients_app,
        ["verify", "--repo-root", str(repo), "--format", "pretty"],
    )
    assert result.exit_code == 0, result.output
    assert "Client leverage stack" in result.output
    assert "MCP" in result.output
    assert "Primer" in result.output


# ---------------------------------------------------------------------------
# Top-level command registration
# ---------------------------------------------------------------------------


def test_clients_subapp_registered_on_top_level_app() -> None:
    result = runner.invoke(app, ["clients", "--help"])
    assert result.exit_code == 0
    assert "MCP clients" in result.output or "mcp clients" in result.output.lower()
