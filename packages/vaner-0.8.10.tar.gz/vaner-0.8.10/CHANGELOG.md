# Changelog

All notable changes to this project are documented in this file.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project follows [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.8.10] - 2026-05-02

### Changed

- First PyPI publish via the `pypa/gh-action-pypi-publish` trusted-publisher OIDC flow (no API token in CI). The `release.yml` workflow gates the PyPI step on `vars.PYPI_PUBLISH=1`; flipping the variable on the repo enables auto-publish on every `v*` tag push. No code changes from 0.8.9 — this is a release-pipeline shake-down.

## [0.8.9] - 2026-05-02

### Added

- `vaner up --json` emits a single structured stdout line (`{"started", "reattached", "ready", "cockpit_url", "daemon_pid", "cockpit_pid", "ports", "inotify"}`) so desktop apps and scripts can read the bring-up result without parsing human prose. (#221)
- `HardwareProfile.gpu_devices` per-device GPU enumeration (NVML → nvidia-smi → lspci on Linux, `system_profiler` on macOS). The desktop reads `gpu_devices[0].name` to show "NVIDIA GeForce RTX 5090" instead of the generic "NVIDIA GPU" fallback. `HardwareProfile` also gains `memory_total_bytes` / `memory_display_gb` / `memory_is_unified` for sub-GB-precision budget calc. (#221, #211)
- `vaner setup catalog refresh` — regenerates `model_registry.json` from real Ollama manifests with family-aware sampling defaults (`temperature`, `top_p`, `top_k`, `repeat_penalty`, `min_p`), runtime defaults (`keep_alive`, `num_ctx`, `num_predict`), and per-family architectural max context. The bundled registry now ships honest `params_b` derived from each family's `vnd.ollama.image.model` layer bytes. (#211)
- `vaner setup models-recommended` — JSON CLI surface that emits the `ModelsRecommendedPayload` shape Vaner Desktop's onboarding wizard binds against (`registry`, `budget`, `hardware`, `selected`, `alternatives`, `user.next_actions`, …). Backed by `vaner.setup.model_recommendation.recommend_local_model` with hardware-aware effective-context-window calc + best-effort Ollama install probe. (#211)
- `compute_effective_context_window()` picks a runtime-effective context per archetype + accelerator memory: 32K floor, model-architectural max ceiling, scaled by available memory headroom and boosted for long-context archetypes (coding, research, planning, mixed). (#211)
- Cockpit refresh: new `/goals`, `/artefacts`, `/artefacts/{id}`, `/learning/recent`; `/predictions/active?include_all=true` returns the five-lane `by_state` (queued → grounding → evidence_gathering → drafting → ready); `/scenarios/{id}` attaches `latest_invalidation_signal`; `/work-products/{id}/inspect` returns `self_eval`, `events`, `status`, `adoptability`, `feedback_state`. The cockpit UI's Goals destination, ActivePredictionsPanel state-machine view, Inspector score-factor stacked bar, PreparedWorkPanel self-eval bars, and LearningPanel left-rail footer all bind against these. (#211)
- `vaner launch <client>` end-to-end installer for Claude Code / Cursor / Codex CLI / VS Code / Zed / Windsurf / Cline / Continue / Roo Code — drops the four-layer leverage stack (MCP entry + primer + skill + plugin/hook) in one shot. (#218)
- `vaner clients verify` reports per-layer status (MCP / Primer / Skill / Plugin) per detected client; the desktop's onboarding-completion verification panel and Companion → Agents pane both consume the same payload. (#214)
- Per-client skill / workflow / prompt installers for Claude Code, Cursor, Codex CLI, VS Code, Cline, Continue, Roo Code (`vaner-feedback` skill across all seven). (#215)
- Cline + Windsurf prompt-submit hooks (Phase C4) so those clients participate in Vaner's intent-capture lifecycle without manual plumbing. (#217)
- Cursor primer surface (parallel to `plugins/vaner/`) plus Zed, Windsurf, Roo Code primers. (#213, #216)
- Phase D-1 integration testbed: containerized Ubuntu 24.04 with Claude Code + Codex CLI + Vaner CLI installed from the working tree. `tests/integration/testbed/test-launch-clients.sh` smoke runs `vaner launch` against every supported CLI client and asserts every leverage layer landed. (#219)
- Phase D-2 GUI testbed: full Ubuntu desktop in a container (Xvfb + metacity + x11vnc + websockify + noVNC), exposed at `http://localhost:6080/vnc.html` for end-to-end Vaner Desktop verification. (#222)

### Changed

- `vaner init` auto-applies the recommended policy bundle when answers can be safely defaulted; the five-question wizard is now opt-in instead of unavoidable on every new repo. (#220)
- Local-model picker rebalanced (`stability * 1.5 + quality * 3.0 + recency * 1.0 + download_savings * 0.5`) so `vaner setup models-recommended` lands on the latest + highest-quality model that fits ("Vaner picks the best model that fits") rather than the safest small model. The "recommended" tier is also relaxed from `recommended_effective_memory_gb` (computed against the family's max context window) to `min_effective_memory_gb + 4 GB` (weights + a sensible 32K-ish KV cache), matching what `compute_effective_context_window` actually picks at runtime. RTX 5090 + Q4 now lands on Qwen 3.6 instead of Qwen 3.5. (#224)

### Fixed

- `vaner clients` Linux false-positive on Claude Desktop. Anthropic ships Claude Desktop only on macOS and Windows; the Linux config dir (`~/.config/Claude/`) was being created by Vaner's own installer (and other tools), so the detector flagged it as installed on every Linux machine that had ever wired a Vaner MCP entry. `_detect_claude_desktop` now gates on platform first. (#222)
- `vaner clients install claude-code` / `codex-cli` MCP wiring: `claude mcp add` / `codex mcp add` refuse to add when a `vaner` entry already exists. The desktop's wizard "Repair" button used to bounce on this and report `mcp=failed`. The CLI now recovers automatically — drops the stale entry with the matching `mcp remove vaner [--scope user]` and retries the add — returning `action="updated"` on success. (#222)

### Validation

- 0.8.9 inherits 0.8.8's release-gate suite (schema, coverage, quality, regression, performance, cost, leak scan, reproducibility); no regression detected on the cockpit-refresh + model-catalog deltas.

## [0.8.8] - 2026-04-30

### Added

- Prepared Work is now the primary user-facing surface for Vaner-prepared review notes, bug hypotheses, docs drift, virtual diffs, research briefs, and prediction-backed opportunities.
- WorkProduct storage, lifecycle, self-evaluation gates, non-mutating inspect/export/dismiss/feedback surfaces, and stale/supersession handling.
- Exact component targeting for predictions through deterministic target normalization and lightweight symbol indexing across Python, TypeScript, JavaScript, Rust, and Go.
- Evidence-bound answer prompting so warm answers stay grounded in selected paths and explicitly flag evidence gaps instead of inventing missing details.
- Retrieval-floor and answerability scoring for context packages, including transparent quality, cost, and readiness signals.
- Benchmark governance profiles with stable gates, reproducibility metadata, leak scanning, and schema-locked release reports.

### Changed

- Named definitions, tests, and usages now outrank broad working-set, graph-neighbor, recency, docs, and generated-file evidence when a concrete component is named.
- Weak component matches remain evidence-ready only instead of becoming draft-ready.
- Prepared Work cards hide internal prediction/work-product lifecycle terms from normal UI clients while preserving diagnostic fields for debug surfaces.
- Release benchmark reporting now compares naked, RAG, and Vaner across writer, researcher, learner, developer/SWE, and codebase-navigation archetypes.

### Fixed

- Broad or stale clusters can no longer drive draft adoption when an exact named component is missing.
- Cold-start and evidence packaging paths now abstain more conservatively when the primary evidence is weak.
- Public benchmark/report artifacts are scanned for absolute local paths and private workspace wording before release publication.
- GitHub release verification handles per-artifact attestation checks without relying on unsupported glob behavior.

### Validation

- 0.8.8 medium release benchmark passed on 2026-04-30 with Qwen 3.6 for Vaner exploration, Claude Sonnet as the answer model, and Claude Opus as judge.
- Scenario benchmark: 20/20 related coverage, 18/20 exact matches, 0 misses, mean relevance 0.856.
- Quality A/B: Vaner-context answers won 6/8 judged pairs.
- Broad public benchmark: 125 cases across five required archetypes; Vaner quality 8.13 vs RAG 7.70 vs naked 4.80.
- Release gates passed: schema, coverage, quality, regression, performance, cost, leak scan, and reproducibility.

## [0.8.7] - 2026-04-26

### Added

#### Live Intent Capture (Phase 1) + L0 Claude Code adapter

The first slice of a new product direction: Vaner consumes explicit composer/prompt lifecycle events from supported clients via a `ComposerAdapter` contract. Vaner is **not** a client — only documented client-level hooks/plugins/extensions are honored. The L0 reference adapter ships in the Claude Code plugin via the `UserPromptSubmit` hook.

##### `ComposerAdapter` contract (WS2)
- **`src/vaner/signals/composer/`** — pydantic source of truth for `DraftIntentSnapshot`, `ComposerAdapterCapabilities`, `LifecycleState` / `CapabilityLevel` / `HostKind` / `FieldRole` literals. JSON Schema artifact at `docs/specs/composer-adapter.schema.json` regenerated from pydantic via the new `vaner-composer-schema` console script. CI guards drift via `git diff --exit-code`.
- **Privacy contract pinned in code**: no field for `text` / `preview` / `draft_text` / `raw_text` / `local_text_ref`. Adapters send only `text_hash` (sha256 hex, regex-pinned) + `length_chars`. `text_preview` / `local_text_ref` from the longer product spec are deferred until a redaction module exists.
- **Capability matrix**: 11 existing client surfaces audited (Claude Code at L0, 10 MCP-only clients as N/A, Vaner VS Code extension explicitly excluded under "Vaner is not a client").

##### Engine plumbing (WS3 + WS4 + WS5 + WS8)
- **`src/vaner/engine.py::observe()`** branches on `event.kind`: `composer_lifecycle` payloads validate as `DraftIntentSnapshot` BEFORE the store insert (malformed payloads never reach persistence) and publish to a new `ComposerSignalPump`. Persist-before-publish ordering means a misbehaving subscriber cannot lose the durable record.
- **`PredictionRun.compose_signal_strength`** (WS4 — data backbone for v0.8.8) and **`IntentPriorAdjustments.composer_signal_weight_multiplier`** (WS5 — values per WorkStyle: writing 1.4, research 1.3, planning 1.2, support/learning 1.1, coding/general/mixed/unsure 1.0). Both fields are documented v0.8.8 wiring gaps; default-0/1.0 invariants preserve byte-identical engine behavior for default-config users.
- **`composer_intent` prediction source** + invalidation handler: `composer_cancelled` / `composer_abandoned` signals stale every `composer_intent`-sourced prediction whose `spec.anchor` matches the cancelled session_id.
- **`Resolution.composer_event_id`** + **`PredictedPrompt.composer_engagement`** (Python + Rust mirror). Both default-None — existing wire-format conformance fixtures pass byte-identical when absent. Rust `PredictionSource` enum gains `ComposerIntent` variant.

##### L0 Claude Code adapter (WS7)
- **`plugins/vaner/hooks/hooks.json`** registers `UserPromptSubmit` alongside `SessionStart`. Translator script `composer_submit.py` reads stdin JSON, computes `sha256(prompt)`, POSTs a `DraftIntentSnapshot` to the daemon at `http://127.0.0.1:8473/signals/composer` with a 1s timeout. Top-level try/except → exit 0 on every failure path so a misconfigured daemon never blocks the user's prompt.
- **`POST /signals/composer`** daemon endpoint validates the snapshot, enforces capability declaration (rejects lifecycle states not in `capabilities.emits`), envelopes into `SignalEvent(kind="composer_lifecycle")`, and records to `draft_events` with a separate counter prefix (`composer_lifecycle_*_total`).

##### Telemetry (WS6)
- **`draft_events.event_type`** column with default `'legacy_draft'`. Idempotent `PRAGMA table_info` ALTER migration handles pre-0.8.7 DBs. Composer rows write `event_type='composer_lifecycle'` and bump a separate counter prefix so the existing `draft_{served|useful|wrong|unused}_total` counters that 0.8.6 dashboards depend on remain untouched.
- Telemetry metadata stores `length_bucket` (coarse band) instead of exact `length_chars` — defeats short-prompt sha256 brute-force across the cross-store correlation surface.

#### CI / supply-chain hardening (WS1 + carry-overs)
- **SLSA-3 verify-chain decouple**: `verify` job's `needs:` changed from `[publish, slsa-provenance]` to `publish`. The slsa-github-generator's `final` aggregation step has a known cosmetic-failure mode that no longer skips end-to-end SLSA-3 verification. v0.8.6 hit exactly this on run #24939687147.
- **Rust workflow unblocked**: pre-existing `cargo fmt` drift in `lib.rs` + `setup.rs` (red since 0.8.6) fixed via `cargo fmt --all`. New `composer_intent_round_trips` Rust test pins the snake_case wire-form against the Python contract.
- **CodeQL**: declared `prediction_id()`'s SHA-1 as `usedforsecurity=False` (it's a deterministic identifier truncated to 16 hex chars, not a cryptographic primitive); replaced JSON-decode exception interpolation with a static error message in `POST /signals/composer`. Both alerts resolved.
- **SQLite concurrency**: `MetricsStore.initialize()` opens with `aiosqlite.connect(..., timeout=5.0)` so the SQLite busy handler is set at connection time. Two concurrent first-time initialize calls (one per composer-event POST) wait for the writer lock instead of failing with `database is locked`.

### Cross-repo
- **vaner-docs PR #25**: ComposerAdapter integration docs page at `content/docs/integrations/composer-adapter.mdx`.
- **vaner-docs issue #26**: tracking removal of the five temporary lychee exclusions for the new 0.8.6 doc routes (blocked on docs.vaner.ai redeploy).

### Test counts
83 new tests across the 8 workstreams + hardening pass. 1655 total tests passing on the full pytest suite (-m "not slow and not integration"). All CI-equivalent local checks green: pre-commit, mypy (3 CI scopes), pip-audit, actionlint, AGENTS.md primer + plugin parity scripts, replay regression, cargo fmt/clippy/test (default + ts-rs + no-default-features), `claude plugin validate`, sensitivity guard.

### Deferred to v0.8.8
- Inline composer UI (Phase 3 — `Prepared` / `Preparing` pills near the composer)
- Real Level-1 adapters (true pre-submit draft lifecycle) — needs ecosystem partner with documented draft hooks
- The three v0.8.8 wiring-gap consumers (composer signal pump subscriber, frontier scoring on `composer_signal_weight_multiplier`, registry update from `compose_signal_strength`)
- `text_preview` / `local_text_ref` snapshot fields (need redaction module first)
- Cloud processing of unsent draft text (opt-in policy work)

## [0.8.6] - 2026-04-25

### Added

#### Simple Mode + Advanced Mode + policy bundles + Deep-Run UX

The headline change: ordinary users now configure Vaner by **outcome** (work style, priority, cloud posture, compute posture, background preparation), not by mechanism (runtime, model, quantization, endpoint, model band). Power users keep full control via Advanced Mode. The 0.8.6 stack ships across five repos: Vaner (engine + CLI + cockpit), the eval workspace (bench corpus + LLM judge), vaner-desktop-macos, vaner-desktop-linux, vaner-docs.

##### Setup primitives, hardware detection, selection algorithm (WS1+WS2+WS3)
- **`src/vaner/setup/`** — `Literal` enums (`WorkStyle`, `Priority`, `ComputePosture`, `CloudPosture`, `BackgroundPosture`, `HardwareTier`); `SetupAnswers` frozen dataclass with empty-`work_styles` rejection; `VanerPolicyBundle` frozen dataclass with `MappingProxyType`-frozen mappings; `PROFILE_CATALOG` of seven bundles (`local_lightweight`, `local_balanced`, `local_heavy`, `hybrid_balanced`, `hybrid_quality`, `cost_saver`, `deep_research`); `bundle_by_id()` raises `KeyError` on unknowns.
- **`SetupConfig` + `PolicyConfig`** Pydantic models on `VanerConfig`. `policy.selected_bundle_id` defaults to `"hybrid_balanced"` (no-op against pre-0.8.6 behaviour).
- **`src/vaner/setup/hardware.py`** — read-only fail-safe probes for OS / CPU class / RAM / GPU (NVIDIA / AMD / Apple Silicon / integrated) / battery / thermal / detected local runtimes / detected models. Four-tier mapping (`light` / `capable` / `high_performance` / `unknown`) via `tier_for()`. Imports cleanly on any supported platform.
- **`select_policy_bundle(answers, hardware) → SelectionResult`** — pure deterministic function. Filter → score → pick. Six small named match functions. Property test over the cartesian product of priority × cloud_posture × hardware_tier (96 cases) confirms totality.

##### Engine wiring (WS4+WS5)
- **`src/vaner/intent/work_style_priors.py`** — `WORK_STYLE_PRIORS` table maps each `WorkStyle` to `IntentPriorAdjustments`. Priors compose multiplicatively at three engine points: frontier scoring, drafter evidence/volatility gates, briefing assembler artefact-template hints. The `mixed` style is the identity element — engines on default config see byte-identical behaviour to pre-0.8.6.
- **`src/vaner/setup/apply.py::apply_policy_bundle()`** — pure function that materialises bundle defaults onto `BackendConfig.prefer_local`, `BackendConfig.remote_budget_per_hour`, `ExplorationConfig.endpoints` (localhost-only filter under `local_only`), `ExplorationConfig.economics_first_routing`, `IntegrationsConfig.context_injection.mode`. `AppliedPolicy.overrides_applied` carries `WIDENS_CLOUD_POSTURE_SENTINEL`-prefixed strings when the new bundle widens cloud posture relative to the prior bundle. Engine stores result on `engine._applied_policy` (snapshot, not config mutation). `engine._refresh_policy_bundle_state()` is callable for hot-reload.
- `test_apply_no_autonomy` enforces the prepare/promote/adopt/execute boundary at bundle-application time — no `auto_execute` / `auto_adopt` / `auto_send` / `auto_commit` flag-writes possible from a bundle.

##### CLI surface (WS6 + cloud-widening guard follow-up)
- **`vaner setup`** Typer sub-app with six subcommands: `wizard` / `show` / `recommend` / `apply` / `advanced` / `hardware`.
- `wizard` runs the five-question Rich flow, surfaces bundle reasoning + cloud-widening warnings (interactive y/N), persists `[setup]` and `[policy]` to `.vaner/config.toml`.
- `recommend` is the JSON-out programmatic surface. `apply --bundle-id <id>` is the non-interactive batch path.
- `vaner init` chains into the wizard interactively (skip via `--non-interactive`).
- **`vaner setup apply --confirm-cloud-widening`** (follow-up) — non-interactive opt-in for cloud-posture widening. Without the flag, `apply` calls `apply_policy_bundle()` server-side, detects the `WIDENS_CLOUD_POSTURE` sentinel, and aborts (`exit 1`) with the warning details. Lets the Linux desktop drop its client-side pre-flight and rely on engine enforcement.

##### MCP and HTTP surfaces (WS7+WS8+WS9)
- **Five new MCP tools**: `vaner.setup.questions`, `vaner.setup.recommend`, `vaner.setup.apply`, `vaner.setup.status`, `vaner.policy.show`. WS9 adds `vaner.deep_run.defaults`. Tool count 27 → 33.
- **`src/vaner/setup/serializers.py`** — public canonical JSON-shape source. CLI/MCP/HTTP all import from here so the wire format stays in lock-step. `bundle_to_dict`, `selection_to_dict`, `hardware_to_dict`, `answers_from_payload`, `AnswersValidationError`.
- **Eight new HTTP endpoints** on the daemon: `GET /setup/questions`, `POST /setup/recommend`, `POST /setup/apply`, `GET /setup/status`, `GET /policy/current`, `GET /hardware/profile`, `POST /policy/refresh`, `GET /deep-run/defaults`. Endpoint count 23 → 31. Loopback-only auth.
- **`POST /policy/refresh`** triggers `engine._refresh_policy_bundle_state()` so `vaner setup apply` gets a hot reload without a daemon restart.
- **`GET /hardware/profile`** caches `detect()` for the daemon process lifetime.

##### Deep-Run user-facing refinements (WS9)
- **`deep_run_defaults_for(bundle, setup) → DeepRunDefaults`** — pure function translating the active bundle + Simple-Mode answers into Deep-Run session-start seeds (preset / horizon_bias / locality / cost_cap_usd / focus). Single source of truth across CLI / MCP / HTTP / desktops via `GET /deep-run/defaults` and `vaner.deep_run.defaults`.
- UX label rename for `horizon_bias` values in **rendering only** (storage literals stay): "Likely next moves" / "Long-horizon work" / "Finish what's in progress" / "Balanced".
- Anti-autonomy reminder card at the start-confirmation step: *"Deep-Run prepares; it does not act."* Both human Rich panel and `prepare_only_notice` field in `--json` mode.
- Duration helper extracted from `vaner/cli/commands/deep_run.py` to `vaner/cli/duration.py` for desktop reuse.

##### Cockpit + accessibility (WS10)
- **`BundleSummaryCard`** + **`HardwareProfilePanel`** React components. Read-only views fed by the WS8 daemon endpoints; fetch helpers gracefully return `null` on 404.
- Full axe-core / pa11y accessibility pass on the cockpit + the MCP Apps UI bundle (deferred from 0.8.5). `cockpit-a11y.yml` GitHub Action workflow fails on regressions.

##### 0.8.5 carry-overs (WS11)
- **Labelled Deep-Run corpus expansion** (the eval workspace) — 40 synthetic `LabelledSession` fixtures (10 per archetype × writer / researcher / developer / planner). Each carries `synthetic: true` so future κ reports can split synthetic vs real corpora.
- **`llm_external_judge`** (the eval workspace) — `ExternalJudgeCallable` against a higher-capacity LLM. Two adapters: `anthropic_llm_callable` (Claude API) and `openai_llm_callable_for_judge` (OpenAI-compatible / vLLM / LM Studio / ollama-OAI). Temperature=0; deterministic cache keyed on `(model_id, sha256(canonical_json(inputs)))`. Wired via `--external-judge llm --judge-model <id>`.
- **ts-rs `cargo run --example export_bindings`** — single-command bindings export for vaner-desktop-linux. README documents the predev/prebuild rsync pattern.

##### Setup-types Rust mirrors (follow-up shipped in 0.8.6)
- **`crates/vaner-contract/src/setup.rs`** — Rust + ts-rs mirrors of `SetupAnswers`, `VanerPolicyBundle`, `HardwareProfile`, `SelectionResult`, `AppliedPolicy`, `SetupConfig`, `PolicyConfig`, `DeepRunDefaults`, `SetupQuestion` + supporting enums (18 types). Conformance fixtures at `tests/conformance-fixtures/setup_*_sample.json` validated by both Rust and Python.

#### Cross-repo

- **`Borgels/vaner-desktop-macos`** branch `0.8.6/setup-and-simple-mode` — OnboardingWindow extended from 3 to 6 steps. New `SetupModels` / `SetupStore` / `DeepRunStartSheet`. PreferencesPane gains a Simple/Advanced toggle. Hardware tier readout in popover.
- **`Borgels/vaner-desktop-linux`** branch `0.8.6/setup-and-simple-mode` — `/setup` first-run wizard; activated `/preferences/engine` and `/preferences/telemetry` tabs (previously stubbed); Engine tab Simple/Advanced segmented control; Tauri commands shell out to `vaner setup --json`; `regen-contract-bindings.mjs` predev script.
- **`Borgels/vaner-docs`** branch `0.8.6/setup-and-simple-mode` — Getting Started fork into Simple Mode / Advanced Mode paths. New pages: `simple-mode.mdx`, `advanced-mode.mdx`, `policy-bundles.mdx`, `hardware-tiers.mdx`, `deep-run.mdx`. `cli.mdx` updated with the `vaner setup` command group.

### Removed
- **`IntentConfig.domain`** field — the unused `Literal["coding","research","writing","ops"]` field is deleted outright (zero callers; no external users yet). Superseded by the multi-select `setup.work_styles` field on `SetupConfig`.

### Tests
- **+329 tests** vs the 0.8.5 baseline of 1241 → **1570 total passing** on the full Vaner suite (15 skipped, 0 failed). Confirmed on the hardening tip (`0.8.6/ws12b-hardening` at `9be88e7`).
- Property test over (priority × cloud_posture × hardware_tier) cartesian product asserts `select_policy_bundle()` is total.
- `test_apply_no_autonomy` enforces the prepare/promote/adopt/execute invariant.
- `test_engine_no_op_when_default` confirms WS4 priors are byte-identical to pre-0.8.6 when `setup.work_styles=["mixed"]`.
- Two security-review passes (against WS5+WS6+WS10+WS11 surface, then WS7+WS8+WS9 surface). **Zero HIGH or MEDIUM findings at confidence ≥ 0.8.** All ten threat surfaces cleared.

### Bench / ship gates
- κ anti-self-judging gate harness runs end-to-end on the synthetic corpus with the `reference_match` judge — structural pass (per-archetype Δ ≥ +0.15 holds; harness exit 0). The numeric κ is artefact of corpus uniformity (synthetic fixtures have no inter-judge variance to disagree on); real κ validation requires a real-LLM judge run against a corpus with variance — `--external-judge llm --judge-model <id>` is wired and ready.

### Internal
- Setup primitives are pure functions; no I/O outside `hardware.detect()`. Bundle application is pure and reversible.
- 1Password SSH-signing was disabled for the v0.8.6 development session; commits in this stack are unsigned (`%G? = N`). The chain is internally consistent.

## [0.8.4] - 2026-04-24

### Added

#### Refinement generalization architecture (WS3)
- **`RefinementContext`** (`src/vaner/intent/deep_run_maturation.py`) replaces the `DeepRunSession` parameter on `mature_one()` and `select_maturation_candidates()`. Two factory methods: `from_deep_run_session()` (preserves 0.8.3 behaviour exactly) and `background_default()` (new, for ordinary-cycle refinement). `session_id=None` on the background path suppresses `deep_run_pass_log` writes, so background passes are audit-log-free by design.
- **Engine hook** (`_run_background_refinement_pass()`) in `src/vaner/engine.py` runs `mature_one()` over the top-K READY predictions post-frontier, gated on `refinement.enabled` + presence of an injected drafter + user-idle (via `PredictionGovernor.should_continue()`) + remaining cycle deadline ≥ `min_remaining_deadline_seconds`. Ships **default-off** in 0.8.4; 0.8.5 flips the default after the κ anti-self-judging bench gate passes.
- **`RefinementConfig`** added to `VanerConfig` (`src/vaner/models/config.py`) — six fields: `enabled`, `max_candidates_per_cycle`, `min_remaining_deadline_seconds`, `require_idle_cpu`, `adoption_pending_confirm_cycles`, `adoption_rejection_on_stale`.
- **Injectable drafter** via `engine.set_refinement_drafter()` — default `None` = no-op. Production wiring lands in 0.8.5 alongside flag activation; tests inject stubs.

#### Adoption-outcome feedback log (WS4)
- **`PredictionAdoptionOutcome`** (`src/vaner/models/prediction_adoption_outcome.py`) + a new `prediction_adoption_outcomes` SQLite table (owned by `ArtefactStore.initialize()` alongside the 0.8.2/0.8.3 tables). Rows transition `pending → {confirmed, rejected, stale}`.
- **Write points**: `PredictionRegistry.record_adoption()` queues a pending descriptor (sync path); engine's `_flush_pending_adoption_outcomes()` drains the queue to the store at end-of-cycle. **Writes happen unconditionally** — not gated on `refinement.enabled` — so the log accumulates from day one.
- **Resolution**: engine's `_sweep_pending_adoption_outcomes()` flips outcomes to `confirmed` after a wall-clock cutoff (`adoption_pending_confirm_cycles × 30s` nominal). Rollback integration: `_reject_pending_adoptions_for_predictions()` batch-rejects when `rollback_kept_maturation()` fires during probation or when a prediction is invalidated while its adoption is still pending.
- **Scoring**: `adoption_success_factor(confirmed, rejected)` helper uses a symmetric Beta(1, 1) prior so cold-start → neutral 1.0; `score_maturation_value()` accepts an `adoption_success_factor_value` multiplier (default 1.0 = pre-WS4 behaviour). 0.8.5 wires the per-label-hash lookup; 0.8.4 seeds the data only.
- **Judge-field-accuracy metric**: `P(outcome=confirmed | had_kept_maturation=1) - P(outcome=confirmed | had_kept_maturation=0)` becomes computable against the log, providing an in-the-wild approximation of the 0.8.3 κ agreement gate that compounds over time.
- **Stable identity across cycles**: `prediction_label_hash(label, anchor)` — sha1 of the label+anchor tuple — keys aggregation so "the same question asked across sessions" aggregates in one bucket.

#### Labelled fixture corpus + external judge scaffolding (WS1+WS2)
- **`LabelledSession` schema** (`the eval workspace/tests/fixtures/deep_run/schema.py`) — dataclass + JSON round-trip for the labelled morning-briefing corpus required by the §14.1 cross-archetype ship gate (≥10 sessions per archetype × 4 archetypes = ≥40 labelled). Schema + harness ship in 0.8.4; labelled content lands through 0.8.4.x as labellers produce it.
- **`ExternalJudgeCallable` Protocol** (`the eval workspace/eval/deep_run_external_judge.py`) + baseline `reference_match_external_judge` (programmatic, LLM-free). Scaffolding ensures the bench pipeline is exercisable before labelled content lands; stronger-model external judge plugs in at the same Protocol boundary in 0.8.4.x.
- **Bench runner entrypoint** (`the eval workspace/eval/run_deep_run_bench.py`) — `--corpus <path> --external-judge reference_match --out <report>.md`. Feeds into the existing `compute_maturation_metrics()` + `evaluate_ship_gates()` (shipped in 0.8.3 WS5). Returns exit code 0 on pass, 1 on fail, 2 on empty corpus, 3 on unknown judge.

#### Contract crate (WS5, via merge of `feat/vaner-contract-crate`)
- **`vaner-contract` Rust crate** (`crates/vaner-contract/`) — cross-language contract definitions for Vaner API / MCP / SSE / handoff payloads. L1 (Linux desktop baseline) + L2 (cross-language fixtures). Source: `lib.rs`, `models.rs`, `reducer.rs`, `sse.rs`, `ts.rs`, `http.rs`, `enums.rs`, `errors.rs`, `handoff.rs`.
- **Conformance fixtures** at `tests/conformance-fixtures/` — shared JSON samples validated by both the Rust crate's conformance tests (`crates/vaner-contract/tests/conformance.rs`) and a Python side (`tests/test_conformance/test_fixtures_match.py`, 8 tests). Any future cross-language consumer of the Vaner API can validate against the same fixture set.
- **New CI workflow**: `.github/workflows/rust.yml` — `cargo fmt --check` + `cargo clippy` + `cargo test --workspace --all-targets`. Path-filtered to fire only when the Rust workspace or fixtures change; the Python CI remains authoritative for everything else.

### Changed
- **`mature_one()` and `select_maturation_candidates()` signatures** now accept `context: RefinementContext` instead of `session: DeepRunSession`. The public API surface is stable on the **outcome side** (`MaturationOutcome.session_id` is now `str | None`); callers migrate by replacing `session=session, cycle_index=N` with `context=RefinementContext.from_deep_run_session(session, cycle_index=N)`. No behavioural change for 0.8.3 call sites; only signature shape.

### Security
- **Dependabot alerts #3, #4, #5 dismissed as `tolerable_risk`** (GHSA-58qw-9mgm-455v / CVE-2026-3219 against `pip <= 26.0.1`). No upstream patch available (pip 26.0.1 is both the latest and the vulnerable version as of ship date). Compensating control: CI uses `pip --require-hashes` against `requirements/ci.txt`, bounding archive-parsing drift. Re-open when pip ships a patch.

### Internal
- **Cleanup**: removed hardcoded `<home>/` paths from `.cursor/mcp.json` (now uses `vaner` on `$PATH`) and purged three outdated testing docs (`docs/cockpit-dogfood-report.md`, `docs/testing/2026-04-v0.6.0-install-findings.md`, `docs/testing/2026-04-v0.6.1-install-findings.md`) from git — all referenced v0.6.x install flows superseded by the 0.8 release line.
- Tests: +51 new Vaner tests (12 WS3 engine + 21 WS4 store + 10 WS4 engine + 11 WS1 schema round-trip + a few MCP smoke updates for the 0.8.3 tool-list carried forward). the eval workspace: +4 external-judge scaffolding tests. Full Vaner suite: 1071 passing, 14 skipped (zero new skips).

### Safety gate behaviour in 0.8.4
- Background refinement **stays off by default**. Adoption-outcome log **writes unconditionally** — data accumulates from day one so 0.8.5 activation has real numbers to consume.
- 0.8.3 Deep-Run behaviour preserved exactly. All 0.8.3 maturation tests pass post-refactor (regression invariant: 1020-baseline).

## [0.8.3] - 2026-04-24

### Added

#### Overnight / Deep-Run Mode (WS1–WS3)
- **Policy layer** distinguishing intent ("user is away for the night") from incidental idleness. Introduces a persisted `DeepRunSession` record (`src/vaner/intent/deep_run.py`, `src/vaner/store/deep_run.py`) with single-active-session enforced by a UNIQUE partial index on `status='active'` plus a defensive store-layer check. Sessions resume on daemon restart; expired sessions auto-close with `cancelled_reason="expired_on_restart"`.
- **Three presets** (Conservative / Balanced / Aggressive) compose the existing engine knobs (exploit/invest/no-regret ratio biases, drafter thresholds, frontier weights, `idle_curve_multiplier`, per-cycle utilisation). `src/vaner/intent/deep_run_policy.py` ships the immutable preset table + four horizon biases (`likely_next` / `long_horizon` / `finish_partials` / `balanced`) + the focus admission gate (`active_goals` / `current_workspace` / `all_recent`).
- **`PredictionGovernor.Mode.DEEP_RUN`** added alongside BACKGROUND / DEDICATED / BUDGET. Continues unless explicitly stopped; pause/resume gating is delegated to the engine via gate probes.
- **Resource / cost / locality gates** (`src/vaner/intent/deep_run_gates.py`):
  - `ResourceGateProbe` Protocol + `NoOpResourceGateProbe` default for tests; `evaluate_resource_gates()` returns the active pause-reason set (battery / thermal / user-input / engine-error-rate).
  - `try_consume_cost()` — thread-safe in-memory cumulative spend counter, gates remote calls when `cost_cap_usd > 0`. `cost_cap_usd = 0` (the default) means *no remote spend permitted* — a hard router-layer block, not a budget warning.
  - `is_remote_call_allowed()` — `local_only` blocks remote URLs.
  - Routing-state singleton (`set_active_session_for_routing()` / `get_active_session_for_routing()`) lets the router consult the active session without parameter-passing through every LLM call.
- **Router-layer enforcement** (`src/vaner/router/backends.py`): new `_enforce_deep_run_gates_for_remote()` helper plus `DeepRunRemoteCallBlockedError` raised when locality or cost gates fire. Wired into the four remote-call paths (sync + streaming, primary + fallback). Zero behaviour change when no Deep-Run session is active.
- **Maturation revisiting** (`src/vaner/intent/deep_run_maturation.py`) — the central new mechanism. A maturation pass re-enters the drafter on already-`READY` predictions to deepen evidence, refine drafts, and resolve contradictions. Critical defenses against the well-known same-model self-judging anti-pattern (per Anthropic Engineering's *Harness design for long-running apps*):
  - **Generator/judge role separation.** Drafter and judge are distinct callables with distinct prompts. Default `JudgeCallable` is a programmatic, skeptical, rubric-based judge — `kept=False` unless concrete contract clauses are satisfied.
  - **Per-pass `MaturationContract`** built from the prediction's current weakness signal *before* the drafter runs. Universal forbidden clauses (no length-only growth, no silent evidence-ref removal, anchor preserved) plus weakness-specific must-clauses (e.g. "≥2 new evidence_refs not in the prior set").
  - **Probationary persistence + diminishing-returns thresholds.** Kept maturations are probationary for N cycles; subsequent reconciliation contradictions roll them back via `rollback_kept_maturation()`. Persistence threshold tightens with each `revision`.
  - `select_maturation_candidates()` ranks READY predictions by goal-confidence × evidence-room × revision decay × state factor, respecting per-prediction failure caps and probation windows.
- **Honest 4-counter discipline** (spec §9.2 / §14.1): `DeepRunSession` and `DeepRunSummary` carry `matured_kept`, `matured_discarded`, `matured_rolled_back`, `matured_failed` as four separate values. Every surface (CLI, MCP, HTTP, cockpit) renders all four; never collapses into a single inflated "matured" total.
- **`PredictionRun` extension** with `revision`, `last_matured_cycle`, `probationary_until_cycle`, `failed_revisits`, `maturation_eligible`.

#### Surfaces (WS4)
- **CLI** — `vaner deep-run start | stop | status | list | show` (`src/vaner/cli/commands/deep_run.py`). `--until` accepts duration (`8h`, `45m`), time-of-day (`07:00`), or ISO-8601. Dual output: human Rich rendering + `--json` for machine consumers.
- **MCP** — five new tools (`vaner.deep_run.start`, `.stop`, `.status`, `.list`, `.show`); `vaner.status` extended with a `deep_run` field carrying the active session record.
- **Daemon HTTP** — `POST /deep-run/start`, `POST /deep-run/stop`, `GET /deep-run/status`, `GET /deep-run/sessions`, `GET /deep-run/sessions/{id}` (`src/vaner/daemon/http.py`).
- **Cockpit (React)** — `ui/cockpit/src/types/deepRun.ts` (TS schema mirrors), `ui/cockpit/src/api/deepRun.ts` (fetch helpers), `ui/cockpit/src/components/DeepRunPanel.tsx` (status pill + start card + history table). All four maturation counters surfaced separately.
- **Desktop hand-off** — `docs/0.8.3/desktop-hand-off.md` documents the wire format, SwiftUI scope, and integration points for the separate `vaner-desktop` repo (popover quick action, menu-bar indicator, preferences card).
- **Single canonical record across surfaces.** `DeepRunSession` row is the one source of truth; CLI / MCP / HTTP / cockpit all read it. Stable-schema serializers (`_session_to_dict` / `_summary_to_dict`) shared between CLI and MCP and HTTP.

#### Bench primitives + ship gates (WS5)
- `the eval workspace/eval/deep_run_bench.py` — `MaturationBenchOutcome`, `MaturationBenchMetrics`, `compute_maturation_metrics()`, `evaluate_ship_gates()`. Five binding ship gates encoded in `SHIP_GATES`:
  - `maturation_effectiveness` — external-judged mean improvement Δ ≥ +0.30 per kept pass.
  - `judge_external_agreement` — Cohen's κ ≥ 0.70 between in-engine and external judges. The anti-self-judging gate.
  - `persistence_rate_in_band` — kept fraction in [0.25, 0.55].
  - `probationary_rollback_rate` — ≤ 0.15.
  - `stale_by_morning_rate` — ≤ 0.15.
- Per-archetype floor: no archetype's mean Δ may be below +0.15; all four of writer/researcher/developer/planner must have ≥1 session in the fixture.
- Validation report at `docs/benchmarks/0.8.3-deep-run-validation.md` documents the gates + lists the remaining follow-up work (labelled fixture corpus, external judge wiring, bench run).

### Internal
- Tests: +211 across WS1–WS5. Full Vaner suite: 1020 passing, 14 skipped (zero new skips).
- Pre-existing tool-list assertions in `tests/test_mcp/test_protocol_roundtrip.py`, `test_scenario_tools.py`, `test_server_boot.py` updated to include the five new `vaner.deep_run.*` tools (26 tools total, up from 21).
- Hard safety gates verified in code + tests: cost-cap compliance (no overshoot under 100-thread concurrency), local-only fidelity (zero remote calls when `local_only`), single-active session enforcement, four-counter integrity, resume-on-restart, reconciliation rollback inside probation.

### Why this is different from idle mode
Idle mode answers a *resource* question ("is the machine free right now?") and must hedge against the user returning at any moment. Deep-Run answers a *policy* question ("is the user telling me they will be away for a long, predictable window and want me to use it well?") and adopts a different stance: longer per-cycle utilisation, broader frontier, deeper drafting bars, **maturation passes on already-ready predictions**, accumulated provenance, post-session summary. Deep-Run never *infers* itself from idleness alone — it requires explicit user opt-in via CLI / MCP / cockpit / desktop.

### Why this does not turn Vaner into an autonomous agent harness
Deep-Run only ever does *more* prepare and *more* promote work. The **prepare ≠ promote ≠ adopt ≠ execute** boundary is preserved: adoption requires an explicit MCP/HTTP/CLI call from a user or authorised agent; execution endpoints with `side_effects ∈ {"read", "mutate"}` are out of scope. Deep-Run lets Vaner *think* harder while you sleep; it does not let Vaner *do* anything you did not already authorise it to do during the day.

## [0.8.0] - 2026-04-23

### Added

#### Persistent prediction pool (WS6)
- **Registry survives across cycles.** `VanerEngine._merge_prediction_specs` now merges new specs into a long-lived `PredictionRegistry` instead of rebuilding one per cycle. Existing predictions keep their accumulated `evidence_score`, `scenarios_complete`, `prepared_briefing`, `draft_answer`, `thinking_traces`, and `file_content_hashes`.
- **Signal-driven invalidation.** New `src/vaner/intent/invalidation.py` emits `file_change`, `commit`, `category_shift`, and `adoption` signals from git + observation state. `PredictionRegistry.apply_invalidation_signals()` applies them: file-change halves weight and clears the briefing, commit stales phase-anchored predictions, category-shift demotes anchored predictions.
- **Per-path content hashes.** `src/vaner/daemon/signals/git_reader.py` gains `read_head_sha`, `read_commit_subjects`, and `read_content_hashes` (git `hash-object` with SHA-256 fallback). Briefing-attach sites capture hashes so invalidation can compare against disk state.

#### BriefingAssembler (WS9)
- `src/vaner/intent/briefing.py` — new `Briefing` / `BriefingSection` / `BriefingAssembler` with `from_prediction` / `from_paths` / `from_artefacts` builders. Single canonical briefing assembler; approximation warning latched so operators know when heuristic token counts are in play. Wired into the engine's evidence-threshold path (replaces the deleted `_synthesise_briefing_from_scenarios`) and MCP `_build_adopt_resolution`.

#### Drafter (WS10)
- `src/vaner/intent/drafter.py` — single `Drafter` class owning the rewrite + draft LLM templates and gate arithmetic. `VanerEngine._precompute_predicted_responses` routes through it; arc / pattern / history / goal-sourced predictions all drive the same path.

#### Workspace Goals (WS7)
- New `src/vaner/intent/goals.py` (`WorkspaceGoal`, `GoalEvidence`, `GoalSource`, `GoalStatus`) and `src/vaner/intent/branch_parser.py` (heuristic goal extractor from branch names like `feat/jwt-migration`).
- New `workspace_goals` SQLite table with indexes on `status` and `created_at`; `ArtefactStore.upsert_workspace_goal`, `list_workspace_goals`, `update_workspace_goal_status`, `delete_workspace_goal`.
- `VanerEngine._merge_prediction_specs` seeds `PredictionSpec(source="goal")` from active goals; goal-anchored predictions surface in `get_active_predictions()` and flow through the full readiness lifecycle.
- Four new MCP tools: `vaner.goals.list`, `vaner.goals.declare`, `vaner.goals.update_status`, `vaner.goals.delete`.

#### Unified resolution path (WS8)
- `VanerEngine.resolve_query(query, *, context, include_briefing, include_predicted_response) -> Resolution` — single canonical `query → Resolution` entry. Consults the prediction registry for a label-match (populating `predicted_response` from the cached draft and `alternatives_considered` from runners-up) and falls back to the heuristic `query()` path, building the Resolution from the returned ContextPackage via `BriefingAssembler.from_artefacts`.
- `Resolution.predicted_response`, `alternatives_considered`, and `briefing_token_used` / `briefing_token_budget` are now populated honestly on the adopt path; briefing rendering comes from `BriefingAssembler`.

#### Calibrated predictions
- `IsotonicCalibrator` in `src/vaner/intent/calibration.py` — pure-Python isotonic curve consumer, no scikit-learn at inference. Loaded from `calibration_curve.json` in the defaults bundle, applied after `IntentScorer._predict()` to convert raw GBDT scores into calibrated probabilities.
- Fail-closed: malformed curve JSON → uncalibrated fallback (same as pre-0.8.0 bundles).

#### Bundle integrity enforcement
- `DefaultsIntegrityError` — SHA256 mismatches in the defaults manifest now **raise** instead of silently returning a sentinel path. Set `VANER_DEFAULTS_ALLOW_MISMATCH=1` for permissive mode with a telemetry log accessible via `drain_checksum_mismatches()`.
- `DefaultsVersionError` — manifests can now declare `min_reader_version`; loader refuses bundles that require a newer vaner than the current runtime.

#### Event stream
- `scenarios` stage is now emitted by default alongside `prediction`, `calibration`, `draft`, `budget`. Operators can opt stages out with `VANER_EVENT_STAGES` env var or the `?stages=` query param.

### Changed
- Manifests in `src/vaner/defaults/*/manifest.json` are regenerated to match shipped file contents; checksum drift is now a hard error rather than a silent skip.
- `_version_tuple` in the defaults loader parses version strings robustly (stops at first non-digit per segment).

### Internal
- Tests: +28 across `test_defaults/test_loader_checksum.py` and `test_intent/test_calibration.py`.
- **0.8.0 architectural cleanup tests (+~100 across WS6–WS10 + WS7 + WS8):** `tests/test_intent/test_prediction_invalidation.py` (17), `tests/test_intent/test_briefing.py` (9), `tests/test_intent/test_drafter.py` (15), `tests/test_intent/test_goals.py` (28), `tests/test_engine/test_goal_seeded_predictions.py` (2), `tests/test_engine/test_resolve_query.py` (4), `tests/test_engine/test_file_change_invalidates_persistent_briefing.py` (2, WS6 end-to-end file-edit invalidation), extended `tests/test_daemon/test_signals.py` (+3), plus MCP-surface updates in `test_mcp/test_protocol_roundtrip.py`, `test_mcp/test_scenario_tools.py`, `test_mcp/test_server_boot.py`, and `tests/test_mcp_v2/test_goals_tool.py` (8). Full suite: 780 passing.

### Evaluation — three delivery modes, three validation tracks

Vaner has three independent delivery modes. The 0.8.0 evaluation validates each one on its own terms rather than asking a single metric to underwrite all three.

- **(A) Context augmentation for a backend LLM.** User prompts their frontier LLM → LLM calls Vaner via MCP → Vaner returns a prepared briefing → LLM answers. *Quality* claim.
- **(B) Instant-answer delivery via the predictive cache.** User sees ready predictions, clicks one, Vaner's prepared package is served directly — the frontier may not be called at all. *UX + performance + marginal-cost* claim.
- **(C) Persistent preparation engine.** Vaner accumulates evidence across cycles and invalidates only on real signals (file edits, commits, category shifts, adoption). *Architecture correctness* claim.

The framing is **not** "Vaner beats frontier models." It is: Vaner improves frontier-model responses through precomputed context (mode A), and sometimes bypasses the frontier call entirely by serving prepared work (mode B), with persistence (mode C) as the foundation that makes A and B compound across successive user turns.

#### Track A — answer-quality uplift (MCP-assisted flow)

Harness: `the eval workspace/eval/session_replay_bench.py` with `--judge-answer-quality --include-rag`. Naked (no context) vs RAG (naive top-K embedding retrieval) vs Vaner (prepared briefing). Blind shuffled judge, 1–10 absolute scores + preference.

Config: `qwen3.5:35b` ponder on local RTX 5090 via Ollama; `gpt-5.3-chat-latest` answer via OpenAI; `gpt-5` judge via OpenAI. 4 archetype sessions (developer / researcher / writer / learner), realistic trace idle (15-min cap, ranges 90s–780s per turn, total precompute ~3h wall-clock).

**Results (bench: `ws4-realdeploy-3way-20260423T210832Z.json`):**

| archetype | naked | RAG | Vaner | Δ (V−R) | wins: V / R / naked / tie |
|---|---|---|---|---|---|
| developer | 2.50 | **6.38** | 5.62 | −0.76 | 1 / 4 / 1 / 2 |
| researcher | 1.00 | 4.25 | **6.75** | **+2.50** | 5 / 1 / 0 / 2 |
| writer | 1.00 | 3.86 | **5.29** | **+1.43** | 4 / 1 / 0 / 2 |
| learner | 1.00 | **5.88** | 2.38 | −3.50 | 0 / 5 / 0 / 3 |
| **overall** | **1.38** | **5.09** | **5.01** | **−0.08** | 10 / 11 / 1 / 9 |

Vaner beats naked on every archetype (so context value is real) and roughly matches RAG overall, but **archetype variance is large**. Vaner wins clearly on researcher (+2.50) and writer (+1.43) — the archetypes where multi-turn semantic intent and cross-file context matter. Vaner loses on developer (−0.76, small) and learner (−3.50, large). Interpretation: naive embedding retrieval is hard to beat when the user's question has a clearly-matching passage in the corpus (algorithms textbook; Flask API docs in the dev's memory), and Vaner's strength is in synthesizing *across* evidence for narrative/research work.

**0.8.0 Track A ship-posture:** *do not* claim a blanket "Vaner beats RAG." Instead: "Vaner is competitive with RAG overall and wins clearly on long-horizon document and narrative work. On algorithms-study and code-reference queries, naive RAG retrieval is a strong baseline Vaner does not yet beat — WS8 unified resolve is the 0.8.1 focus that addresses this."

#### Track B — instant-adopt UX/perf (predictive cache)

Harness: same bench run, `--test-adopt` fields aggregated by `the eval workspace/eval/aggregate_track_b.py`. Measures adoption hit-rate (fraction of turns with a matching ready/drafting prediction), adopted-answer quality vs naked + vs Vaner-heuristic, and latency ratio (adopt path vs live heuristic path, both under the bench's judge-a-fresh-answer constraint).

**Results:**

| archetype | hit-rate | adopt | naked (adopted turns) | Vaner-heuristic (adopted turns) | latency adopt / Vaner |
|---|---|---|---|---|---|
| developer | 0% | — | — | — | — |
| researcher | 87.5% | 3.71 | 1.00 | 6.29 | 1701ms / 2351ms |
| writer | 50% | 3.00 | 1.00 | 4.00 | 2527ms / 2420ms |
| learner | 62.5% | 1.40 | 1.00 | 3.20 | 1672ms / 2386ms |
| **overall** | **50%** | **2.81** | **1.00** | **4.75** | **1898ms / 2379ms (ratio 0.80)** |

Hit-rate is above the 40% ship-gate floor — the adopt surface has real content half the time. Adopt quality is above naked (+1.81) but meaningfully below Vaner-heuristic (−1.94) — meaning the label-match heuristic in `VanerEngine.resolve_query` is often selecting a prediction whose prepared draft is close but not quite the user's actual prompt. WS8.1's unified resolve (semantic matching, not just label overlap) is designed to close this gap.

Bench-mode latency ratio 0.80 → adopt is ~20% faster than Vaner-heuristic because the briefing is already built; **production** latency ratio with a verbatim-draft-served adopt (no frontier call at all) would be ~0.01 (milliseconds vs seconds). The bench can't measure that directly because it always calls the answer model so the judge can score.

**0.8.0 Track B ship-posture:** adopt UX available for ~50% of prompts, produces better-than-naked answers, and is a latency improvement over the live pipeline even when still calling the frontier. Production prepared-draft-serving is a UX-side 0.8.1 follow-up.

Developer 0% hit-rate is a surprise worth investigation — likely a mismatch between the developer session's prompt vocabulary (Flask-specific verbs like "implement", "add", "debug") and the prediction labels synthesised by `_merge_prediction_specs`. Filed as WS8.1 investigation.

#### Track C — persistent preparation correctness (architecture)

Test-driven. 27 unit tests across `test_prediction_invalidation.py` + `test_prediction_persistence.py` cover the WS6 invariants: merge preserves accumulated state across cycles; file_change demotes + clears briefing; commit stales phase-anchored; category-shift demotes anchored; adoption marks spent; no-hash predictions untouched.

End-to-end integration smoke: `test_file_change_invalidates_persistent_briefing.py` runs two consecutive `precompute_cycle` calls on a real engine with a file edit in between and asserts the captured briefing is cleared and the invalidation reason recorded — plus the inverse that no edits means no clearing.

**Track C ship-gate:** all unit + integration tests green (status: 29 tests, all passing).

### Known limitations / deferred to 0.8.1

- **True agent-with-search baseline.** The Track A "naked" arm is zero-context, not "frontier model with its own search tool." Deferred: a harness that runs multi-call agent loops so Vaner's uplift can be measured against a realistic code-assistant control.
- **Same-family judge.** Track A uses `gpt-5` to judge `gpt-5.3-chat-latest` answers. Claude-as-judge (or another family) independence check is an 0.8.1 follow-up.
- **Workspace Goals.** Ships with branch-name inference and MCP declaration; commit-subject clustering and query-embedding clustering deferred.
- **MCP resolve convergence.** MCP `vaner.resolve` still uses its own scenario-store path; `VanerEngine.resolve_query` is the canonical Python API and both will converge in 0.8.1 via a thin daemon-HTTP wrapper.
- **SWE-Bench Verified.** Task-completion metric is 0.8.1+ — requires an Agentless-style harness replacing localization with Vaner, not yet built.

## [0.7.1] - 2026-04-22

### Added

#### Activity-timing aware cycle budget

- Added `ActivityTimingModel` (`src/vaner/intent/timing.py`) — an EMA-based estimator of inter-prompt cadence seeded from `query_history` timestamps and live-updated every time `VanerEngine.query()` is called. The model distinguishes "active session" cadence from session boundaries (gaps longer than `active_session_gap_seconds`, default 3 min, are treated as AFK and excluded from the EMA so one overnight break doesn't poison the estimate).
- Wired the timing model into `VanerEngine.precompute_cycle`: when `compute.adaptive_cycle_budget = true` (default), the cycle deadline now shrinks to roughly `adaptive_cycle_utilisation × estimated_seconds_until_next_prompt` during active sessions. When the user is idle the budget expands back up to `compute.max_cycle_seconds`. The static `max_cycle_seconds` cap remains the hard upper bound — the adaptive model only ever *shortens* the cycle, so existing operators retain their safety net.
- New config knobs: `ComputeConfig.adaptive_cycle_budget`, `adaptive_cycle_min_seconds`, `adaptive_cycle_utilisation`.

#### Unused-prediction decay

- Added access tracking to `prediction_cache` (schema v7): new `access_count` + `last_accessed_at` columns updated by `ArtefactStore.touch_prediction_cache()` whenever `TieredPredictionCache.match()` returns an entry above cold-miss tier.
- Added `ArtefactStore.purge_unused_prediction_cache(max_age_seconds_without_access, min_access_count_to_protect)` and wired it into the end-of-cycle cleanup. Entries that Vaner precomputed but the developer never consumed within `exploration.unused_cache_max_age_seconds` (default 30 min) are now removed independently of TTL. Entries with at least one real cache hit are protected regardless of age. Set the config field to `0.0` to fall back to TTL-only behavior.

#### Predicted-response precompute (opt-in)

- Added `VanerEngine._precompute_predicted_responses()` and an opt-in gate (`exploration.predicted_response_enabled`, default `false`). When enabled and the cycle has budget remaining, Vaner picks the top validated prompt macros (`use_count ≥ exploration.predicted_response_min_macro_use_count`, default 3) and spends dedicated LLM calls to draft a short response per macro. The draft is stashed in the cache enrichment as `predicted_response` alongside the normal context package, so agents consuming Vaner can surface a ready-made answer the moment the expected prompt arrives.
- New config knobs: `exploration.predicted_response_enabled`, `predicted_response_min_macro_use_count`, `predicted_response_max_per_cycle` (default 1) — the per-cycle cap keeps the feature from starving the exploration loop.

#### Deep-drill on high-priority predictions

- Added a high-priority deep-drill pathway to the exploration frontier. Scenarios whose *effective* priority clears `exploration.deep_drill_priority_threshold` (default `0.60`) are now treated as high-confidence next-prompt predictions and get more compute invested:
  - `_explore_scenario_with_llm()` receives a `high_priority` flag and widens the LLM prompt to accept up to `exploration.deep_drill_max_followons` follow-on branches (default `5` vs. the original hard-coded `3`). The prompt is also tagged `[HIGH-PRIORITY]` so the model knows to invest effort in surfacing second-order context (callers, callees, tests, configuration) rather than stopping at breadth.
  - Children of high-priority parents inherit a decrementing `depth_bonus` budget (default `2`). The frontier's admission gate now allows `depth > max_exploration_depth` by up to `depth_bonus` hops, so a promising lineage can drill past the base depth cap without raising the cap for the whole frontier. The bonus shrinks by 1 per LLM hop so the drill-down is bounded.
  - High-priority branches use a softer `deep_drill_branch_decay` (default `0.88`) instead of the general `branch_priority_decay` (default `0.70`), so the deep line keeps ranking near the top of the heap instead of getting crowded out by fresh shallow seeds.
- Fixed a latent bug in `_explore_scenario_with_llm`: the `if not callable(self.llm)` guard previously returned a 2-tuple where the declared return type expected a 4-tuple, which would have raised at the call site. Now returns `([], [], "", 0.0)`.

## [0.7.0] - 2026-04-22

### Added

#### Claude Code plugin surface (supersedes manual MCP wiring for Claude Code)

- Added a supported Claude Code plugin (`plugins/vaner/`) distributed via a same-repo marketplace at `.claude-plugin/marketplace.json`. Claude Code users can now install with `/plugin marketplace add Borgels/Vaner` followed by `/plugin install vaner@vaner`. Bundles the Vaner MCP server, the `vaner-feedback` skill (now namespaced as `/vaner:vaner-feedback`), a `/vaner:install` skill that wraps the canonical installer behind a Bash-tool permission prompt, and a SessionStart hook that reports when the `vaner` CLI is missing from PATH — otherwise injects the canonical Vaner usage primer on every session.
- Added a `/vaner:next` skill in the plugin that calls `mcp__vaner__suggest` and renders top-N candidate next moves as structured numbered cards (label, why-now, confidence/readiness hint) rather than raw predictions. When Vaner's daemon is live the SessionStart hook also surfaces the cockpit URL (`http://127.0.0.1:8473/`) so the model can point the user at the live pipeline view.
- Added a plugin monitor that tails `.vaner/memory/log.md` on first `/vaner:next` invocation, so the model stays aware of scenario events (resolve, feedback, promotion) mid-session.

#### Canonical usage primer

- Added per-client usage primers to `vaner init`. MCP wiring alone does not teach a model when and how to use Vaner; `init` now also installs a short guidance block into each detected client's native rules surface: `.claude/CLAUDE.md` (Claude Code), `.cursor/rules/vaner.mdc` (Cursor), `.github/copilot-instructions.md` (VS Code Copilot), `AGENTS.md` (Codex CLI), `.clinerules` (Cline), and `.continue/rules/vaner.md` (Continue). The primer is sourced from a single canonical file at `src/vaner/defaults/prompts/agent-primer.md` and wrapped client-specifically. Non-destructive: existing files get the primer appended in a delimited `<!-- vaner-primer:start … -->…<!-- vaner-primer:end -->` block that re-runs replace in place without touching surrounding content. Opt-out via `--no-primer`; `--user-primer` additionally writes the Claude Code primer at `~/.claude/CLAUDE.md` for always-on global guidance. Clients without a well-defined primer surface (Claude Desktop, Windsurf, Zed, Roo) are left as-is for this release.

#### Ponder parallelism

- Wired `compute.exploration_concurrency` (default 4) into the daemon's exploration loop. Previously a dead config — exposed by the cockpit UI and HTTP API but ignored by the engine. The scenario loop now runs up to `exploration_concurrency` LLM calls in parallel via an `asyncio.Semaphore`, with an `asyncio.Lock` guarding frontier mutations, follow-on branch pushes, and the covered-paths accumulator. Live benchmark on a single-GPU box with ollama 0.20.7 + `qwen2.5-coder:7b`: 9 scenarios in **140s at `exploration_concurrency=1` → 77s at `exploration_concurrency=4` (1.8× speedup)**. Server-side concurrency (vLLM natively, ollama with `OLLAMA_NUM_PARALLEL≥4`) determines the ceiling; a server that truly serializes requests will *degrade* below serial — a direct curl test against a single-slot backend measured 8 parallel calls as ~3× slower than 8 serial calls. The daemon emits a one-time `WARNING` log line whenever `exploration_concurrency > 1` reminding the operator to tune the server side. Individual scenario LLM failures no longer kill the whole cycle — they're logged and skipped. See `docs/performance.md` for the tuning ladder.
- Added an idle-aware concurrency ramp. When `compute.idle_only = true`, the effective per-cycle concurrency now scales smoothly with current load (`max(1, int(exploration_concurrency × (1 − load)))`), so Vaner shares the machine gracefully under light foreground load instead of the previous binary "run at full speed or skip the cycle" behaviour. The hard idle-skip cutoff still applies above `idle_cpu_threshold` / `idle_gpu_threshold`.
- Added multi-endpoint exploration routing. Set `exploration.endpoints = [...]` in `.vaner/config.toml` to dispatch exploration LLM calls across a pool of OpenAI-compatible endpoints (vLLM, remote ollama, LM Studio, etc.) via weighted round-robin. The pool tracks per-endpoint health (consecutive failures, total calls) and skips endpoints that have failed three or more times in a row for a 60-second cooldown before trying them half-open again. When `exploration.endpoints` is empty, behaviour is unchanged and Vaner uses the existing single-endpoint path.

### Fixed

- Fixed primer grammar: step 1 of the canonical primer now reads "Prepare context early" (imperative, parallel with steps 2 and 3) instead of "Prepared context early" — caught by Vaner's own `/vaner:next` card-pick flow during live testing.
- Fixed the plugin's SessionStart hook preview of missing-binary tool names: now advertises the real Claude Code namespacing (`mcp__plugin_vaner_vaner__vaner.resolve`, etc.) instead of the pre-namespace form.
- Fixed dogfood skill drift: `.cursor/skills/vaner/vaner-feedback/SKILL.md` in this repo was stuck on the v0.2.0 tool names (`list_scenarios`, `report_outcome`); now matches the canonical v0.6.x template.

### Docs

- Added `docs/performance.md` with the full ponder-throughput tuning ladder (`exploration_concurrency` → `OLLAMA_NUM_PARALLEL` → `CUDA_VISIBLE_DEVICES` multi-GPU → multi-endpoint pool) and an emphatic warning about raising concurrency without a concurrent backend.
- Added a scripted / non-interactive mode section to `docs/claude-plugin.md` covering `--permission-mode bypassPermissions`, `--allowedTools`, the MCP tool naming convention, and the minimum CLI version (v0.6.0) required for the primer's tool references to resolve.
- Added a CLI-version parity note to `CONTRIBUTING.md` for the plugin distribution.

### CI

- Added `.github/workflows/validate-claude-plugin.yml`: parity scripts (skill, primer, version), JSON well-formedness, hook smoke tests (both missing-binary and vaner-present branches), and `claude plugin validate`.
- Added `.github/workflows/creds-tripwire.yml`: narrow `git grep` for known test-only credentials and private-infrastructure hostnames on every PR and push.

## [0.6.2] - 2026-04-21

### Fixed

- Fixed version-pinned installer fallback so `VANER_VERSION=<tag>` can fall back to the matching GitHub tag when PyPI does not have that release yet.
- Fixed the default install/query path to degrade gracefully when `sentence-transformers` is unavailable instead of crashing at first query-time embedding use.
- Fixed `vaner uninstall` so repo-local Cursor MCP wiring is removed correctly when `vaner init` created `.cursor/mcp.json`.
- Fixed managed feedback skill content drift by shipping a single current `vaner.feedback`-based skill template instead of duplicated legacy tool instructions.
- Improved MCP v1 `suggest` / `search` ranking in fresh repos so Vaner-managed config/skill files are downranked unless the query explicitly targets them.

### Added

- Added regression tests for pinned installer fallback, uninstall symmetry, managed skill content, graceful missing-embedding fallback, and MCP ranking around Vaner-managed files.

## [0.6.1] - 2026-04-21

### Fixed

- Fixed MCP server startup for both stdio and SSE by passing explicit `NotificationOptions` during capability initialization (resolves `tools_changed` crash on connect).
- Fixed `vaner config show` / `vaner config keys` crashes by restoring `intent` settings in `VanerConfig` and wiring `[intent]` + `[intent.skills_loop]` config loading.
- Fixed repeated MCP client wiring from creating unbounded `*.vaner-backup-*` files by skipping backups on no-op merges and rotating backups to keep only the latest 3.
- Hardened installer behavior for uv by retrying with explicit MCP dependencies (`mcp[cli]`, `starlette`) when extras resolution fails.

### Added

- Added `vaner uninstall` command to remove managed MCP wiring + managed skill files, with `--keep-state` support for preserving local `.vaner` state.
- Added regression tests for MCP boot/session readiness, config command intent keys, and MCP backup idempotence/rotation.

## [0.6.0] - 2026-04-20

### Changed (BREAKING)

- Replaced the legacy 5-tool MCP surface with the v1.0 tool set: `vaner.status`, `vaner.suggest`, `vaner.resolve`, `vaner.expand`, `vaner.search`, `vaner.explain`, `vaner.feedback`, `vaner.warm`, `vaner.inspect`, and `vaner.debug.trace`. See `docs/mcp-migration.md`.
- Scenario storage now uses memory semantics (`memory_state`, `memory_confidence`, `memory_evidence_hashes_json`) and keeps `pinned` only as a compatibility alias for `memory_state == 'trusted'`.
- `vaner.feedback` no longer auto-promotes on one `useful` signal; promotion is gated by memory policy rules documented in `docs/memory-semantics.md`.

### Added

- Added first-class memory policy rules in `src/vaner/memory/policy.py` for promotion gating, evidence invalidation, contradiction-aware conflict detection, and decision reuse.
- Added memory quality metrics surfaced by `vaner.status` and `vaner.debug.trace` (`predictive_hit_rate`, `stale_hit_rate`, `promotion_precision`, `contradiction_rate`, `correction_survival_rate`, `demotion_recovery_rate`, `trusted_evidence_avg`, `abstain_rate`).
- Added inspectability traces at `.vaner/memory/log.md` and `.vaner/memory/index.md` (explicitly not the semantic memory layer).

## [0.5.0] - 2026-04-20

### Added

- Added a full `vaner init` onboarding wizard with backend/compute prompts, multi-client MCP selection, safe config merges, and backup files.
- Added new init controls: `--clients auto|all|none|other|csv`, `--dry-run`, and stronger `--force` handling for malformed files.
- Added an explicit escape hatch for unsupported clients that prints a generic MCP snippet, docs links, and a support issue URL.
- Added CLI tests for MCP client registry/merge behavior and the new onboarding wizard interaction flows.

### Changed

- Updated onboarding docs and landing flows to promote `curl | bash` followed by `vaner init` as the default path.
- Switched client config writes to a single MCP client registry implementation that supports Cursor, Claude Desktop/Code, VS Code, Codex CLI, Windsurf, Zed, Continue, Cline, and Roo.

### Removed

- Removed the legacy `write_mcp_configs(repo_root)` path from init in favor of the new wizard + registry flow.

## [0.2.0] - 2026-04-19

### Removed

- Removed deprecated MCP compatibility tools: `legacy_get_context`, `legacy_precompute`, and `legacy_get_metrics`.
- Removed deprecated `ExplorationPolicy`; `ScoringPolicy` is now the sole exploration policy surface.

### Changed

- Hardened MCP tests with explicit tool-matrix assertions, per-tool error-path checks, telemetry checks, and an in-memory protocol round-trip test.
- Added CLI MCP smoke tests for `stdio`/`sse` wiring and non-loopback SSE safety checks.
- Added docs drift tests to prevent reintroducing removed MCP tool names in docs examples.
- Hardened release CI with strict provenance enforcement, keyless Sigstore signing for artifacts, SBOM attestation, and release verification gates.
- Added container provenance/SBOM output plus keyless SBOM attestation for Docker releases.
- Added VSIX provenance attestation and Sigstore bundle upload to GitHub releases.
