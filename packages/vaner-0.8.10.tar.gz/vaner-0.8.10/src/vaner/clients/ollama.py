# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Literal

from vaner.clients.llm_response import LLMResponse, approx_tokens, split_thinking_and_content
from vaner.defaults.loader import reasoning_defaults_for_model
from vaner.models.cost import TokenUsage, usage_from_ollama_payload

ReasoningMode = Literal["off", "allowed", "required", "provider_default"]


def ollama_llm(
    *,
    model: str,
    base_url: str = "http://127.0.0.1:11434",
    timeout: float = 120.0,
) -> Callable[[str], Awaitable[str]]:
    """Ollama inference client (bare-string return — legacy contract).

    For richer returns (thinking trace separation + structured output), use
    :func:`ollama_llm_structured` instead.
    """
    structured = ollama_llm_structured(
        model=model,
        base_url=base_url,
        timeout=timeout,
        reasoning_mode="off",
    )

    async def _call(prompt: str) -> str:
        response = await structured(prompt)
        return response.content

    return _call


def ollama_llm_structured(
    *,
    model: str,
    base_url: str = "http://127.0.0.1:11434",
    timeout: float = 120.0,
    max_tokens: int | None = None,
    response_format: dict | None = None,
    extra_body: dict | None = None,
    reasoning_mode: ReasoningMode = "provider_default",
) -> Callable[..., Awaitable[LLMResponse]]:
    """Ollama client that returns a structured LLMResponse.

    Ollama's ``/api/generate`` supports ``options`` (e.g. ``num_predict``)
    and ``format: "json"``. We translate Vaner's provider-neutral parameters
    to Ollama's idiom:

    - ``max_tokens`` → ``options.num_predict``
    - ``response_format={"type": "json_object"}`` → ``format: "json"``
    - ``extra_body`` is merged into the body (useful for ``options`` overrides
      or chat-template toggles).
    - ``reasoning_mode`` applies the same tolerant parsing semantics as
      :func:`vaner.clients.openai.openai_llm_structured`. When
      ``provider_default`` is left and ``model`` matches a known reasoning
      model in the defaults manifest, the recommended mode is applied.
    """
    if reasoning_mode == "provider_default":
        manifest_entry = reasoning_defaults_for_model(model)
        if manifest_entry is not None:
            reasoning_mode = manifest_entry["reasoning_mode"]  # type: ignore[assignment]
            if not extra_body:
                extra_body = dict(manifest_entry.get("extra_body") or {})
    _base = base_url.rstrip("/")

    async def _call(prompt: str, *, max_tokens: int | None = max_tokens) -> LLMResponse:
        import httpx

        use_chat_api = reasoning_mode == "off"
        body: dict
        if use_chat_api:
            body = {"model": model, "messages": [{"role": "user", "content": prompt}], "stream": False}
        else:
            body = {"model": model, "prompt": prompt, "stream": False}
        options: dict = {}
        if max_tokens is not None and max_tokens > 0:
            options["num_predict"] = int(max_tokens)
        if options:
            body["options"] = options
        if response_format is not None:
            rf_type = response_format.get("type")
            if rf_type in ("json_object", "json"):
                body["format"] = "json"
        merged_extra = dict(extra_body or {})
        if reasoning_mode == "off":
            # Modern Ollama reasoning models support a top-level ``think``
            # switch and return reasoning in a separate ``thinking`` field.
            # The chat API is the reliable path for current Qwen/Gemma
            # models; the generate API may still spend the full budget in
            # the hidden thinking channel and return empty ``response``.
            body["think"] = False
        body.update(merged_extra)

        async with httpx.AsyncClient(timeout=timeout) as client:
            endpoint = "/api/chat" if use_chat_api else "/api/generate"
            response = await client.post(f"{_base}{endpoint}", json=body)
            response.raise_for_status()
            payload = response.json()
            if use_chat_api:
                message = payload.get("message")
                if isinstance(message, dict):
                    raw = str(message.get("content", ""))
                    provider_thinking = str(message.get("thinking", ""))
                else:
                    raw = ""
                    provider_thinking = ""
            else:
                raw = str(payload.get("response", ""))
                provider_thinking = str(payload.get("thinking", ""))

        split = split_thinking_and_content(raw)
        usage = usage_from_ollama_payload(payload, prompt=prompt, completion=split.content, thinking=split.thinking)
        if provider_thinking:
            thinking = provider_thinking.strip()
            if split.thinking:
                thinking = f"{thinking}\n{split.thinking}".strip()
            thinking_tokens = max(int(usage.thinking_tokens or 0), approx_tokens(thinking))
            usage = TokenUsage(
                prompt_tokens=usage.prompt_tokens,
                completion_tokens=usage.completion_tokens,
                thinking_tokens=thinking_tokens,
                cached_input_tokens=usage.cached_input_tokens,
                total_tokens=max(usage.total_tokens, usage.prompt_tokens + usage.completion_tokens + thinking_tokens),
                usage_source=usage.usage_source,
                usage_estimated=usage.usage_estimated,
                provider_usage_raw=usage.provider_usage_raw,
            )
            split = LLMResponse(thinking=thinking, content=split.content, raw=raw, usage=usage)
        else:
            split = LLMResponse(thinking=split.thinking, content=split.content, raw=split.raw, usage=usage)

        if reasoning_mode == "required" and not split.thinking:
            raise ValueError(
                f"reasoning_mode='required' but response contained no detected thinking preamble (raw len={approx_tokens(raw)} tokens)"
            )
        if reasoning_mode == "off" and split.thinking:
            raise ValueError("reasoning_mode='off' but response still contained a thinking preamble — provider did not honour /no_think")
        return split

    return _call
