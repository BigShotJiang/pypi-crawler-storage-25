# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

import asyncio
import json
import logging
import random
import re
import signal
import time
import uuid
from collections import deque
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, StreamingResponse

from vaner.api import aquery
from vaner.broker.prompting import build_evidence_bound_context_prompt
from vaner.cli.commands.config import load_config, set_compute_value
from vaner.daemon.cockpit_html import build_cockpit_html
from vaner.events.bus import build_stage_payloads
from vaner.intent.arcs import derive_prompt_macro
from vaner.models.config import VanerConfig
from vaner.models.cost import CostLedgerEntry, ModelPricing, TurnCostSummary, estimate_cost, usage_from_openai_payload
from vaner.models.decision import DecisionRecord
from vaner.models.signal import SignalEvent
from vaner.router.backends import (
    forward_chat_completion_with_request,
    stream_chat_completion_with_request,
    validate_backend_config,
)
from vaner.store.artefacts import ArtefactStore
from vaner.telemetry.metrics import MetricsStore, RequestMetrics

logger = logging.getLogger(__name__)


def _inject_context(payload: dict[str, Any], context: str) -> dict[str, Any]:
    messages = payload.get("messages", [])
    system_content = build_evidence_bound_context_prompt(context)
    system_message = {"role": "system", "content": system_content}
    return {**payload, "messages": [system_message, *messages]}


def _normalize_message_content(content: Any) -> str:
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and item.get("type") == "text":
                text = item.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "\n".join(parts)
    return ""


_FOLLOW_UP_ACTION_PATTERNS = (
    ("would_you_like_me_to", "offer", re.compile(r"\bwould you like me to\s+(.+?)(?:\?|\.|$)", re.IGNORECASE | re.DOTALL)),
    ("do_you_want_me_to", "offer", re.compile(r"\bdo you want me to\s+(.+?)(?:\?|\.|$)", re.IGNORECASE | re.DOTALL)),
    ("want_me_to", "offer", re.compile(r"\bwant me to\s+(.+?)(?:\?|\.|$)", re.IGNORECASE | re.DOTALL)),
    ("shall_i", "proposal", re.compile(r"\bshall i\s+(.+?)(?:\?|\.|$)", re.IGNORECASE | re.DOTALL)),
    ("i_can_next", "can_do_next", re.compile(r"\bi can\s+(.+?)\s+next(?:\?|\.|$)", re.IGNORECASE | re.DOTALL)),
)
_AFFIRMATIVE_PROMPT_RE = re.compile(
    r"^(?:yes|yep|yeah|sure|ok|okay|go ahead|please do|do it|sounds good|that works|let'?s do it)\b",
    re.IGNORECASE,
)


def _extract_follow_up_offer(assistant_text: str) -> dict[str, str]:
    normalized = " ".join(assistant_text.split())
    if not normalized:
        return {}
    for pattern_id, phrase_family, pattern in _FOLLOW_UP_ACTION_PATTERNS:
        match = pattern.search(normalized)
        if not match:
            continue
        action = " ".join(match.group(1).split()).strip(" .")
        if action:
            return {
                "action": action,
                "phrase_pattern_id": pattern_id,
                "phrase_family": phrase_family,
            }
    return {}


def _extract_follow_up_action(assistant_text: str) -> str:
    offer = _extract_follow_up_offer(assistant_text)
    return str(offer.get("action", ""))


def _build_retrieval_prompt(messages: list[dict[str, Any]], user_prompt: str, *, follow_up_action: str = "") -> str:
    prompt = user_prompt.strip()
    if not prompt:
        return ""
    if not _AFFIRMATIVE_PROMPT_RE.match(prompt):
        return prompt
    action = follow_up_action.strip()
    if not action:
        assistant_messages = [msg for msg in messages if msg.get("role") == "assistant"]
        if not assistant_messages:
            return prompt
        last_assistant = _normalize_message_content(assistant_messages[-1].get("content"))
        action = _extract_follow_up_action(last_assistant)
    if not action:
        return prompt
    return f"{prompt}\n\nfollow_up_request: {action}"


def _metrics_db_path(repo_root: Path) -> Path:
    return repo_root / ".vaner" / "metrics.db"


class _RateLimiter:
    def __init__(self, max_requests_per_minute: int) -> None:
        self.max_requests_per_minute = max(1, max_requests_per_minute)
        self._timestamps = deque()

    def allow(self) -> bool:
        now = time.monotonic()
        cutoff = now - 60.0
        while self._timestamps and self._timestamps[0] < cutoff:
            self._timestamps.popleft()
        if len(self._timestamps) >= self.max_requests_per_minute:
            return False
        self._timestamps.append(now)
        return True


class _PrometheusCounters:
    """Minimal in-process Prometheus-compatible counters (no external deps)."""

    def __init__(self) -> None:
        self.requests_total: int = 0
        self.requests_by_tier: dict[str, int] = {}
        self.context_retrieval_sum_ms: float = 0.0
        self.llm_total_sum_ms: float = 0.0
        self.total_e2e_sum_ms: float = 0.0

    def record(self, m: RequestMetrics) -> None:
        self.requests_total += 1
        tier = m.cache_tier or "unknown"
        self.requests_by_tier[tier] = self.requests_by_tier.get(tier, 0) + 1
        self.context_retrieval_sum_ms += m.context_retrieval_ms
        self.llm_total_sum_ms += m.llm_total_ms
        self.total_e2e_sum_ms += m.total_e2e_ms

    def render(self) -> str:
        lines = [
            "# HELP vaner_requests_total Total requests handled by Vaner proxy",
            "# TYPE vaner_requests_total counter",
            f"vaner_requests_total {self.requests_total}",
        ]
        for tier, count in self.requests_by_tier.items():
            lines.append(f'vaner_requests_by_tier{{tier="{tier}"}} {count}')
        n = max(self.requests_total, 1)
        lines += [
            "# HELP vaner_context_retrieval_ms_avg Average context retrieval latency (ms)",
            "# TYPE vaner_context_retrieval_ms_avg gauge",
            f"vaner_context_retrieval_ms_avg {self.context_retrieval_sum_ms / n:.2f}",
            "# HELP vaner_llm_total_ms_avg Average LLM generation latency (ms)",
            "# TYPE vaner_llm_total_ms_avg gauge",
            f"vaner_llm_total_ms_avg {self.llm_total_sum_ms / n:.2f}",
            "# HELP vaner_total_e2e_ms_avg Average end-to-end latency (ms)",
            "# TYPE vaner_total_e2e_ms_avg gauge",
            f"vaner_total_e2e_ms_avg {self.total_e2e_sum_ms / n:.2f}",
        ]
        return "\n".join(lines) + "\n"


def create_app(config: VanerConfig, store: ArtefactStore) -> FastAPI:
    validate_backend_config(config)

    metrics_store = MetricsStore(_metrics_db_path(config.repo_root))
    prom = _PrometheusCounters()

    # Track in-flight requests for graceful shutdown
    _inflight: set[asyncio.Task] = set()
    _shutting_down = False

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await store.initialize()
        await metrics_store.initialize()

        loop = asyncio.get_running_loop()

        def _handle_sigterm():
            nonlocal _shutting_down
            _shutting_down = True

            # Wait for in-flight requests to drain, then stop
            async def _drain():
                if _inflight:
                    await asyncio.gather(*_inflight, return_exceptions=True)

            asyncio.ensure_future(_drain())

        try:
            loop.add_signal_handler(signal.SIGTERM, _handle_sigterm)
        except (NotImplementedError, RuntimeError):
            pass  # Windows or non-main thread

        yield

        try:
            loop.remove_signal_handler(signal.SIGTERM)
        except (NotImplementedError, RuntimeError):
            pass

    app = FastAPI(title="Vaner Proxy", version="0.2.0", lifespan=lifespan)
    limiter = _RateLimiter(config.proxy.max_requests_per_minute)
    required_token = (config.proxy.proxy_token or "").strip()
    shadow_rate = max(0.0, min(config.gateway.shadow_rate, 1.0))
    decision_stream_subscribers: set[asyncio.Queue[dict[str, Any] | None]] = set()
    gateway_enabled = bool(config.gateway.passthrough_enabled)

    @app.get("/health")
    async def health() -> dict[str, str]:
        """Liveness probe -- always returns 200 when the server is running."""
        return {"status": "ok"}

    @app.get("/ready")
    async def ready() -> dict[str, str]:
        """Readiness probe -- returns 200 when the store is initialized and available."""
        if _shutting_down:
            raise HTTPException(status_code=503, detail="Shutting down")
        try:
            await store.initialize()
            return {"status": "ready"}
        except Exception as exc:
            raise HTTPException(status_code=503, detail=f"Store unavailable: {exc}") from exc

    @app.get("/metrics", response_class=PlainTextResponse)
    async def prometheus_metrics() -> str:
        """Prometheus-compatible metrics endpoint."""
        return prom.render()

    @app.get("/compute/devices")
    async def compute_devices() -> JSONResponse:
        devices: list[dict[str, Any]] = [{"id": "cpu", "label": "CPU", "kind": "cpu"}]
        try:  # pragma: no cover - GPU visibility depends on environment
            import torch

            if torch.cuda.is_available():
                for idx in range(torch.cuda.device_count()):
                    props = torch.cuda.get_device_properties(idx)
                    devices.append(
                        {
                            "id": f"cuda:{idx}",
                            "label": props.name,
                            "kind": "cuda",
                            "total_memory_bytes": props.total_memory,
                        }
                    )
            if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
                devices.append({"id": "mps", "label": "Apple Metal (MPS)", "kind": "mps"})
        except Exception:
            pass
        return JSONResponse({"devices": devices, "selected": config.compute.device})

    @app.get("/impact/summary")
    async def impact_summary(last: int = 500) -> JSONResponse:
        summary = await metrics_store.shadow_summary(last_n=max(1, min(last, 2000)))
        idle_path = config.repo_root / ".vaner" / "runtime" / "idle_usage.json"
        idle_seconds = 0.0
        if idle_path.exists():
            try:
                parsed = json.loads(idle_path.read_text(encoding="utf-8"))
                idle_seconds = float(parsed.get("idle_seconds_used", 0.0))
            except Exception:
                idle_seconds = 0.0
        summary["idle_seconds_used"] = round(idle_seconds, 3)
        return JSONResponse(summary)

    @app.get("/status")
    async def cockpit_status() -> JSONResponse:
        quality = await metrics_store.memory_quality_snapshot()
        calibration = await metrics_store.calibration_snapshot()
        return JSONResponse(
            {
                "health": "ok",
                "gateway_enabled": gateway_enabled,
                "compute": config.compute.model_dump(mode="json"),
                "backend": config.backend.model_dump(mode="json"),
                "prediction_metrics": quality,
                "prediction_calibration": calibration,
            }
        )

    @app.post("/compute")
    async def update_compute(payload: dict[str, Any]) -> JSONResponse:
        allowed_keys = {
            "device",
            "cpu_fraction",
            "gpu_memory_fraction",
            "idle_only",
            "idle_cpu_threshold",
            "idle_gpu_threshold",
            "embedding_device",
            "exploration_concurrency",
            "max_parallel_precompute",
        }
        for key, value in payload.items():
            if key not in allowed_keys:
                raise HTTPException(status_code=400, detail=f"Unsupported compute key: {key}")
            set_compute_value(config.repo_root, key, value)
        refreshed = load_config(config.repo_root)
        config.compute = refreshed.compute
        return JSONResponse({"ok": True, "compute": config.compute.model_dump(mode="json")})

    @app.post("/gateway/toggle")
    async def toggle_gateway(payload: dict[str, Any]) -> JSONResponse:
        nonlocal gateway_enabled
        gateway_enabled = bool(payload.get("enabled", True))
        return JSONResponse({"ok": True, "gateway_enabled": gateway_enabled})

    @app.get("/", response_class=HTMLResponse)
    async def cockpit() -> str:
        return build_cockpit_html("proxy")

    @app.get("/ui")
    async def cockpit_ui() -> RedirectResponse:
        return RedirectResponse(url="/", status_code=307)

    async def _publish_decision_event(event: dict[str, Any]) -> None:
        if not decision_stream_subscribers:
            return
        stale_subscribers: list[asyncio.Queue[dict[str, Any] | None]] = []
        for subscriber in decision_stream_subscribers:
            try:
                subscriber.put_nowait(event)
            except asyncio.QueueFull:
                stale_subscribers.append(subscriber)
        for stale in stale_subscribers:
            decision_stream_subscribers.discard(stale)

    def _serialize_decision(record: DecisionRecord) -> dict[str, Any]:
        payload = record.model_dump(mode="json")
        payload["selection_count"] = len(record.selections)
        return payload

    def _load_recent_decisions(repo_root: Path, limit: int) -> list[dict[str, Any]]:
        ids = DecisionRecord.list_recent_ids(repo_root, limit=limit)
        items: list[dict[str, Any]] = []
        for decision_id in ids:
            record = DecisionRecord.read_by_id(repo_root, decision_id)
            if record is None:
                continue
            items.append(_serialize_decision(record))
        return items

    @app.get("/decisions")
    async def list_decisions(request: Request, limit: int = 200) -> JSONResponse:
        repo_root = _resolve_repo_root(request)
        bounded_limit = max(1, min(limit, 500))
        return JSONResponse({"items": _load_recent_decisions(repo_root, bounded_limit)})

    @app.get("/decisions/stream")
    async def stream_decisions() -> StreamingResponse:
        queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue(maxsize=200)
        decision_stream_subscribers.add(queue)

        async def _event_stream():
            try:
                while True:
                    event = await queue.get()
                    if event is None:
                        break
                    yield f"data: {json.dumps(event)}\n\n"
            finally:
                decision_stream_subscribers.discard(queue)

        return StreamingResponse(_event_stream(), media_type="text/event-stream")

    @app.get("/events/stream")
    async def stream_events(stages: str | None = None, limit: int | None = None) -> StreamingResponse:
        selected = {item.strip() for item in (stages or "").split(",") if item.strip()}
        if not selected:
            selected = {"prediction", "calibration", "draft", "budget"}

        async def _event_stream():
            sent = 0
            last_decision_fingerprint = ""
            stage_fingerprints: dict[str, str] = {}
            while True:
                if "decisions" in selected:
                    recent = _load_recent_decisions(config.repo_root, limit=10)
                    decision_payload = json.dumps(recent, sort_keys=True)
                    if decision_payload != last_decision_fingerprint:
                        yield f"data: {json.dumps({'stage': 'decisions', 'payload': recent})}\n\n"
                        last_decision_fingerprint = decision_payload
                        sent += 1
                stage_payloads = await build_stage_payloads(metrics_store)
                for stage, payload in stage_payloads.items():
                    if stage not in selected:
                        continue
                    serialized = json.dumps(payload, sort_keys=True)
                    if serialized != stage_fingerprints.get(stage, ""):
                        yield f"data: {json.dumps({'stage': stage, 'payload': payload})}\n\n"
                        stage_fingerprints[stage] = serialized
                        sent += 1
                if limit is not None and sent >= max(1, limit):
                    return
                yield ": keepalive\n\n"
                await asyncio.sleep(2.0)

        return StreamingResponse(_event_stream(), media_type="text/event-stream")

    @app.websocket("/decisions")
    async def websocket_decisions(websocket: WebSocket) -> None:
        await websocket.accept()
        queue: asyncio.Queue[dict[str, Any] | None] = asyncio.Queue(maxsize=200)
        decision_stream_subscribers.add(queue)
        try:
            while True:
                event = await queue.get()
                if event is None:
                    break
                await websocket.send_json(event)
        except WebSocketDisconnect:
            pass
        finally:
            decision_stream_subscribers.discard(queue)

    def _resolve_repo_root(request: Request) -> Path:
        """Determine which repo root to use for a request.

        Clients can override the default via ``X-Vaner-Repo`` header (absolute
        path) or by mounting the proxy at a sub-path like ``/repos/myproject/v1/...``.
        Falls back to the config default.
        """
        override = request.headers.get("X-Vaner-Repo", "").strip()
        if override:
            p = Path(override)
            if p.is_dir():
                return p
        return config.repo_root

    @app.post("/v1/chat/completions")
    async def chat_completions(payload: dict[str, Any], request: Request) -> Any:
        if _shutting_down:
            raise HTTPException(status_code=503, detail="Shutting down, please retry.")
        if required_token:
            auth_header = request.headers.get("Authorization", "")
            token_header = request.headers.get("X-Vaner-Proxy-Token", "")
            if token_header != required_token and auth_header != f"Bearer {required_token}":
                raise HTTPException(status_code=401, detail="Missing or invalid proxy token.")
        if not limiter.allow():
            raise HTTPException(status_code=429, detail="Rate limit exceeded.")

        metrics = RequestMetrics()
        metrics.t0_received = time.monotonic()
        metrics.is_stream = payload.get("stream") is True

        repo_root = _resolve_repo_root(request)
        messages = payload.get("messages", [])
        assistant_messages = [msg for msg in messages if msg.get("role") == "assistant"]
        user_messages = [msg for msg in messages if msg.get("role") == "user"]
        prompt = _normalize_message_content(user_messages[-1].get("content")) if user_messages else ""
        prompt_macro = derive_prompt_macro(prompt) if prompt else "general"
        corpus_id = "repo"
        await store.initialize()
        if assistant_messages:
            last_assistant = _normalize_message_content(assistant_messages[-1].get("content"))
            offer = _extract_follow_up_offer(last_assistant)
            if offer:
                action = str(offer.get("action", ""))
                phrase_pattern_id = str(offer.get("phrase_pattern_id", ""))
                phrase_family = str(offer.get("phrase_family", ""))
                await store.insert_signal_event(
                    SignalEvent(
                        id=str(uuid.uuid4()),
                        source="proxy",
                        kind="follow_up_offer_detected",
                        timestamp=time.time(),
                        payload={
                            "action": action,
                            "phrase_pattern_id": phrase_pattern_id,
                            "phrase_family": phrase_family,
                            "prompt_macro": prompt_macro,
                            "corpus_id": corpus_id,
                            "privacy_zone": "local",
                        },
                    )
                )
                if prompt and _AFFIRMATIVE_PROMPT_RE.match(prompt):
                    await store.insert_signal_event(
                        SignalEvent(
                            id=str(uuid.uuid4()),
                            source="proxy",
                            kind="follow_up_offer_accepted",
                            timestamp=time.time(),
                            payload={
                                "action": action,
                                "phrase_pattern_id": phrase_pattern_id,
                                "phrase_family": phrase_family,
                                "prompt_macro": prompt_macro,
                                "corpus_id": corpus_id,
                                "privacy_zone": "local",
                            },
                        )
                    )
        else:
            offer = {}
        retrieval_prompt = _build_retrieval_prompt(messages, prompt, follow_up_action=str(offer.get("action", "")))
        metrics.prompt_tokens = len(prompt.split())
        if gateway_enabled:
            context_package = await aquery(retrieval_prompt, repo_root, config=config, top_n=6)
            metrics.t1_context_ready = time.monotonic()
            metrics.cache_tier = context_package.cache_tier
            metrics.partial_similarity = context_package.partial_similarity
            metrics.context_tokens = context_package.token_used
            metrics.injected_context_tokens = context_package.token_used
            enriched = _inject_context(payload, context_package.injected_context)
        else:
            context_package = type("Package", (), {"cache_tier": "disabled", "partial_similarity": 0.0, "token_used": 0})()
            metrics.t1_context_ready = time.monotonic()
            metrics.cache_tier = "disabled"
            metrics.partial_similarity = 0.0
            metrics.context_tokens = 0
            metrics.injected_context_tokens = 0
            enriched = payload
        metrics.t2_forwarded = time.monotonic()
        decision_record = DecisionRecord.read_latest(repo_root)
        decision_id = decision_record.id if decision_record is not None else "unknown"
        request_authorization = request.headers.get("Authorization")

        async def _finalize_metrics() -> None:
            metrics.finalize()
            prom.record(metrics)
            try:
                await metrics_store.record(metrics)
                await metrics_store.increment_mode_usage("proxy")
            except Exception:
                metrics.primary_usage_record_error = "record_failed"
                logger.debug("Failed to record best-effort primary usage metrics", exc_info=True)

        response_headers = {
            "X-Vaner-Decision": decision_id,
            "X-Vaner-Context-Tokens": str(context_package.token_used),
            "X-Vaner-Hit-Tier": context_package.cache_tier,
        }

        def _backend_pricing() -> ModelPricing | None:
            model_name = str(enriched.get("model") or config.backend.model or "")
            pricing = config.cost.model_pricing.get(model_name) or config.cost.model_pricing.get(config.backend.model)
            if pricing is not None:
                return pricing
            base_url = config.backend.base_url or ""
            if "127.0.0.1" in base_url or "localhost" in base_url:
                return ModelPricing(local_or_cloud="local", source="unknown_zero")
            return None

        async def _record_primary_usage(result: dict[str, Any]) -> None:
            choices = result.get("choices") if isinstance(result, dict) else None
            completion = ""
            if isinstance(choices, list) and choices:
                first = choices[0]
                message = first.get("message") if isinstance(first, dict) else None
                if isinstance(message, dict):
                    completion = _normalize_message_content(message.get("content"))
            prompt_text = "\n".join(
                _normalize_message_content(msg.get("content")) for msg in enriched.get("messages", []) if isinstance(msg, dict)
            )
            usage = usage_from_openai_payload(result, prompt=prompt_text, completion=completion)
            pricing = _backend_pricing()
            cost = estimate_cost(usage, pricing)
            base_url = config.backend.base_url or ""
            local_or_cloud = "local" if ("127.0.0.1" in base_url or "localhost" in base_url) else "cloud"
            metrics.primary_llm_input_tokens = usage.prompt_tokens
            metrics.primary_llm_output_tokens = usage.completion_tokens
            metrics.primary_llm_thinking_tokens = usage.thinking_tokens
            metrics.primary_llm_cost_usd = cost.total_cost_usd
            if pricing is not None:
                metrics.expected_incremental_primary_cost_usd = (metrics.injected_context_tokens / 1000.0) * pricing.input_cost_per_1k
            metrics.primary_llm_usage_known = not usage.usage_estimated
            metrics.total_known_cloud_cost_usd = cost.total_cost_usd if local_or_cloud == "cloud" and not cost.estimated else 0.0
            metrics.total_estimated_cloud_cost_usd = cost.total_cost_usd if local_or_cloud == "cloud" else 0.0
            metrics.pricing_snapshot_id = cost.pricing_snapshot_id
            metrics.usage_source_summary = usage.usage_source
            try:
                await metrics_store.record_llm_usage(
                    CostLedgerEntry(
                        request_id=metrics.request_id,
                        turn_id=metrics.request_id,
                        provider=config.backend.name or "openai_compatible",
                        model=str(enriched.get("model") or config.backend.model or "unknown"),
                        endpoint=config.backend.base_url,
                        call_role="primary_forward",
                        local_or_cloud=local_or_cloud,
                        usage=usage,
                        cost=cost,
                        latency_ms=metrics.llm_total_ms,
                    )
                )
                await metrics_store.record_turn_cost(
                    TurnCostSummary(
                        turn_id=metrics.request_id,
                        request_id=metrics.request_id,
                        injected_context_tokens=metrics.injected_context_tokens,
                        expected_incremental_primary_cost_usd=metrics.expected_incremental_primary_cost_usd,
                        primary_llm_input_tokens=usage.prompt_tokens,
                        primary_llm_output_tokens=usage.completion_tokens,
                        primary_llm_thinking_tokens=usage.thinking_tokens,
                        primary_llm_cost_usd=cost.total_cost_usd,
                        primary_llm_usage_known=not usage.usage_estimated,
                        total_known_cloud_cost_usd=metrics.total_known_cloud_cost_usd,
                        total_estimated_cloud_cost_usd=metrics.total_estimated_cloud_cost_usd,
                    )
                )
            except Exception:
                pass

        if decision_record is not None:
            await _publish_decision_event(_serialize_decision(decision_record))

        async def _run_shadow_sample(with_context_ms: float) -> None:
            if shadow_rate <= 0.0:
                return
            if metrics.is_stream:
                return
            if random.random() > shadow_rate:
                return
            started = time.monotonic()
            try:
                await forward_chat_completion_with_request(
                    config,
                    payload,
                    authorization_header=request_authorization,
                )
            except Exception:
                return
            without_context_ms = (time.monotonic() - started) * 1000.0
            await metrics_store.record_shadow_pair(
                request_id=metrics.request_id,
                with_context_total_ms=with_context_ms,
                without_context_total_ms=without_context_ms,
                with_context_tokens=context_package.token_used,
                without_context_tokens=0,
            )

        try:
            if metrics.is_stream:

                async def _instrumented_stream():
                    first_token_set = False
                    try:
                        async for chunk in stream_chat_completion_with_request(
                            config,
                            enriched,
                            authorization_header=request.headers.get("Authorization"),
                        ):
                            if not first_token_set and chunk:
                                metrics.t3_first_token = time.monotonic()
                                first_token_set = True
                            yield chunk
                    finally:
                        metrics.t4_complete = time.monotonic()
                        await _finalize_metrics()

                return StreamingResponse(
                    _instrumented_stream(),
                    media_type="text/event-stream",
                    headers=response_headers,
                )
            else:
                result = await forward_chat_completion_with_request(
                    config,
                    enriched,
                    authorization_header=request_authorization,
                )
                metrics.t4_complete = time.monotonic()
                metrics.finalize()
                await _record_primary_usage(result)
                await _finalize_metrics()
                await _run_shadow_sample(metrics.total_e2e_ms)
                response_headers["X-Vaner-Latency-Ms"] = f"{metrics.total_e2e_ms:.2f}"
                return JSONResponse(result, headers=response_headers)
        except Exception as exc:  # pragma: no cover - network errors
            metrics.t4_complete = time.monotonic()
            await _finalize_metrics()
            raise HTTPException(status_code=502, detail=str(exc)) from exc

    return app
