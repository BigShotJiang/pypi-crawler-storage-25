# SPDX-License-Identifier: Apache-2.0
"""`vaner clients` CLI — install Vaner into MCP clients.

0.8.5 WS12: thin non-interactive surface over :mod:`vaner.cli.commands.mcp_clients`,
so desktop apps and CI pipelines can drive install/uninstall/status/doctor
through a stable contract instead of the interactive `vaner init` wizard.

The per-client adapter knowledge (config paths, JSON vs YAML vs CLI shell-out,
backup rotation, atomic writes) all lives in `mcp_clients`. This module is
just the typer-shaped entry point.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table

from vaner.cli.commands import mcp_clients

clients_app = typer.Typer(
    help=(
        "Install Vaner into MCP clients (Cursor, Claude Desktop, Claude Code, "
        "Cline, Continue, Zed, Windsurf, VS Code, Codex CLI, Roo). Idempotent; "
        "safe to re-run after Vaner upgrades."
    ),
    no_args_is_help=True,
)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


_STATUS_GLYPH = {
    mcp_clients.ClientStatus.CONFIGURED: ("[green]✓[/green]", "Configured"),
    mcp_clients.ClientStatus.INSTALLED: ("[yellow]·[/yellow]", "Detected"),
    mcp_clients.ClientStatus.MISSING: ("[dim]✗[/dim]", "Missing"),
}


def _detected_to_dict(detected: mcp_clients.DetectedClient) -> dict[str, object]:
    return {
        "id": detected.spec.id,
        "label": detected.spec.label,
        "kind": detected.spec.kind,
        "status": detected.status.value,
        "detected": detected.status != mcp_clients.ClientStatus.MISSING,
        "configured": detected.status == mcp_clients.ClientStatus.CONFIGURED,
        "config_path": str(detected.path) if detected.path is not None else None,
        "detail": detected.detail,
    }


def _result_to_dict(result: mcp_clients.WriteResult) -> dict[str, object]:
    return {
        "client_id": result.client_id,
        "path": str(result.path) if result.path is not None else None,
        "action": result.action,
        "backup": str(result.backup) if result.backup is not None else None,
        "error": result.error,
        "manual_snippet": result.manual_snippet,
    }


def _drift_to_dict(report: mcp_clients.LauncherDrift) -> dict[str, object]:
    return {
        "client_id": report.client_id,
        "label": report.label,
        "config_path": str(report.config_path) if report.config_path is not None else None,
        "drift": report.drift,
        "current_in_config": report.current_in_config,
        "expected": report.expected,
        "detail": report.detail,
    }


def _print_detect_table(detected_list: list[mcp_clients.DetectedClient]) -> None:
    console = Console()
    table = Table(title="MCP clients", show_lines=False)
    table.add_column("Client")
    table.add_column("Status")
    table.add_column("Path")
    for detected in detected_list:
        glyph, label = _STATUS_GLYPH[detected.status]
        path = str(detected.path) if detected.path is not None else "-"
        table.add_row(detected.spec.label, f"{glyph} {label}", path)
    console.print(table)


def _print_install_results(results: list[mcp_clients.WriteResult]) -> None:
    console = Console()
    for r in results:
        if r.action == "added":
            console.print(f"[green]✓[/green] {r.client_id}: added at {r.path}")
        elif r.action == "updated":
            console.print(f"[green]✓[/green] {r.client_id}: updated at {r.path}")
        elif r.action == "skipped":
            note = f" ({r.error})" if r.error else ""
            console.print(f"[yellow]·[/yellow] {r.client_id}: skipped{note}")
        elif r.action == "failed":
            console.print(f"[red]✗[/red] {r.client_id}: failed — {r.error or 'unknown error'}")


def _resolve_repo_root(repo_root: Path | None) -> Path:
    return repo_root if repo_root is not None else Path.cwd()


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


@clients_app.command("detect", help="List MCP clients found on this machine and their config status.")
def detect_cmd(
    repo_root: Annotated[
        Path | None,
        typer.Option("--repo-root", "-C", help="Repo root for per-repo detection (default: cwd)."),
    ] = None,
    format: Annotated[
        str,
        typer.Option("--format", help="Output format: pretty (default), json."),
    ] = "pretty",
) -> None:
    root = _resolve_repo_root(repo_root)
    detected_list = mcp_clients.detect_all(root)
    if format == "json":
        typer.echo(json.dumps({"clients": [_detected_to_dict(d) for d in detected_list]}, indent=2))
        return
    if format != "pretty":
        raise typer.BadParameter(f"unknown format {format!r}. Choose from: pretty, json")
    _print_detect_table(detected_list)


@clients_app.command(
    "install",
    help=(
        "Install Vaner into one or all MCP clients. By default, every "
        "applicable layer (MCP + primer + skill + hooks) is installed; "
        "pass --mcp-only for the legacy MCP-only behaviour."
    ),
)
def install_cmd(
    name: Annotated[
        str | None,
        typer.Argument(help="Client id (e.g. cursor, claude-desktop). Omit when using --all."),
    ] = None,
    install_all: Annotated[
        bool,
        typer.Option("--all", help="Install Vaner for every detected MCP client."),
    ] = False,
    mcp_only: Annotated[
        bool,
        typer.Option(
            "--mcp-only",
            help=("Only write the MCP server entry; skip primer, skill, and hook layers. Equivalent to the pre-Phase-C behaviour."),
        ),
    ] = False,
    server_key: Annotated[
        str,
        typer.Option(
            "--server-key",
            help="Override the JSON `mcpServers` key (Claude Desktop uses `vaner-<reponame>` by default).",
        ),
    ] = "vaner",
    repo_root: Annotated[
        Path | None,
        typer.Option("--repo-root", "-C", help="Repo root (default: cwd)."),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would change; do not write any files."),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", help="Re-write the MCP entry even when it already matches."),
    ] = False,
    format: Annotated[
        str,
        typer.Option("--format", help="Output format: pretty (default), json."),
    ] = "pretty",
) -> None:
    if not install_all and name is None:
        raise typer.BadParameter("specify a client id or pass --all")
    if install_all and name is not None:
        raise typer.BadParameter("--all and a client name are mutually exclusive")

    root = _resolve_repo_root(repo_root)
    detected_list = mcp_clients.detect_all(root)

    if install_all:
        target_ids = [d.spec.id for d in detected_list if d.status != mcp_clients.ClientStatus.MISSING]
    else:
        match = [d for d in detected_list if d.spec.id == name]
        if not match:
            ids = ", ".join(d.spec.id for d in detected_list)
            raise typer.BadParameter(f"unknown client id {name!r}. Known: {ids}")
        if match[0].status == mcp_clients.ClientStatus.MISSING:
            typer.secho(
                f"warning: {name} not detected on this machine — writing config anyway",
                fg=typer.colors.YELLOW,
                err=True,
            )
        target_ids = [match[0].spec.id]

    if mcp_only:
        # Legacy path — keep the MCP-only writer for callers that
        # explicitly opt in. Same JSON shape as before.
        targets = [d for d in detected_list if d.spec.id in target_ids]
        launcher_cmd, launcher_args = mcp_clients.resolve_launcher(root)
        results: list[mcp_clients.WriteResult] = []
        for detected in targets:
            key = server_key
            if key == "vaner" and detected.spec.id == "claude-desktop":
                key = f"vaner-{root.name}"
            results.append(
                mcp_clients.write_client(
                    detected,
                    launcher_cmd=launcher_cmd,
                    launcher_args=launcher_args,
                    server_key=key,
                    dry_run=dry_run,
                    force=force,
                )
            )
        if format == "json":
            typer.echo(json.dumps({"results": [_result_to_dict(r) for r in results]}, indent=2))
            return
        if format != "pretty":
            raise typer.BadParameter(f"unknown format {format!r}. Choose from: pretty, json")
        _print_install_results(results)
        if any(r.action == "failed" for r in results):
            raise typer.Exit(code=1)
        return

    # Default path — full leverage stack per client (MCP + primer +
    # skill + hooks where applicable). Same orchestrator powers the
    # top-level ``vaner launch <client>`` alias.
    from vaner.cli.commands.launch import launch_client

    launch_results = [
        launch_client(
            client_id,
            root,
            server_key=server_key,
            dry_run=dry_run,
            force=force,
        )
        for client_id in target_ids
    ]

    if format == "json":
        typer.echo(
            json.dumps(
                {
                    "results": [
                        {
                            "client_id": r.client_id,
                            "label": r.label,
                            "detected": r.detected,
                            "overall": r.overall,
                            "layers": [
                                {
                                    "layer": layer.layer,
                                    "applicable": layer.applicable,
                                    "action": layer.action,
                                    "path": str(layer.path) if layer.path else None,
                                    "error": layer.error,
                                }
                                for layer in r.layers
                            ],
                        }
                        for r in launch_results
                    ]
                },
                indent=2,
            )
        )
        if any(layer.action == "failed" for r in launch_results for layer in r.layers if layer.applicable):
            raise typer.Exit(code=1)
        return

    if format != "pretty":
        raise typer.BadParameter(f"unknown format {format!r}. Choose from: pretty, json")

    for result in launch_results:
        overall_color = {
            "ready": typer.colors.GREEN,
            "partial": typer.colors.YELLOW,
            "failed": typer.colors.RED,
            "missing": typer.colors.RED,
        }.get(result.overall, typer.colors.WHITE)
        typer.secho(
            f"{result.label} ({result.client_id}) — {result.overall}",
            fg=overall_color,
            bold=True,
        )
        for layer in result.layers:
            if not layer.applicable:
                typer.echo(f"  - {layer.layer:6s} —")
                continue
            color = {
                "added": typer.colors.GREEN,
                "updated": typer.colors.GREEN,
                "skipped": typer.colors.WHITE,
                "failed": typer.colors.RED,
            }.get(layer.action, typer.colors.YELLOW)
            tail = f" → {layer.path}" if layer.path else ""
            typer.secho(f"  - {layer.layer:6s} {layer.action}{tail}", fg=color)
            if layer.error:
                typer.secho(f"    error: {layer.error}", fg=typer.colors.RED)
    if any(layer.action == "failed" for r in launch_results for layer in r.layers if layer.applicable):
        raise typer.Exit(code=1)


@clients_app.command("uninstall", help="Remove the Vaner entry from one or all MCP clients.")
def uninstall_cmd(
    name: Annotated[
        str | None,
        typer.Argument(help="Client id; omit with --all."),
    ] = None,
    uninstall_all: Annotated[
        bool,
        typer.Option("--all", help="Remove Vaner from every configured MCP client."),
    ] = False,
    repo_root: Annotated[
        Path | None,
        typer.Option("--repo-root", "-C", help="Repo root (default: cwd)."),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would change; do not delete."),
    ] = False,
    format: Annotated[
        str,
        typer.Option("--format", help="Output format: pretty (default), json."),
    ] = "pretty",
) -> None:
    if not uninstall_all and name is None:
        raise typer.BadParameter("specify a client id or pass --all")
    if uninstall_all and name is not None:
        raise typer.BadParameter("--all and a client name are mutually exclusive")

    root = _resolve_repo_root(repo_root)
    detected_list = mcp_clients.detect_all(root)
    if uninstall_all:
        targets = [d for d in detected_list if d.status == mcp_clients.ClientStatus.CONFIGURED]
    else:
        targets = [d for d in detected_list if d.spec.id == name]
        if not targets:
            ids = ", ".join(d.spec.id for d in detected_list)
            raise typer.BadParameter(f"unknown client id {name!r}. Known: {ids}")

    results = [mcp_clients.remove_client(d, dry_run=dry_run) for d in targets]
    if format == "json":
        typer.echo(json.dumps({"results": [_result_to_dict(r) for r in results]}, indent=2))
        return
    if format != "pretty":
        raise typer.BadParameter(f"unknown format {format!r}. Choose from: pretty, json")
    for r in results:
        if r.action == "updated":
            typer.echo(f"✓ {r.client_id}: removed from {r.path}")
        elif r.action == "skipped":
            typer.echo(f"· {r.client_id}: nothing to remove" + (f" ({r.error})" if r.error else ""))
        else:
            typer.secho(f"✗ {r.client_id}: {r.error or 'failed'}", fg=typer.colors.RED, err=True)


@clients_app.command("status", help="Show install/configured matrix for every supported MCP client.")
def status_cmd(
    repo_root: Annotated[
        Path | None,
        typer.Option("--repo-root", "-C"),
    ] = None,
    format: Annotated[
        str,
        typer.Option("--format", help="Output format: pretty (default), json."),
    ] = "pretty",
) -> None:
    detect_cmd(repo_root=repo_root, format=format)


@clients_app.command(
    "verify",
    help=(
        "Report each client's leverage stack (MCP / primer / skill / plugin). "
        "Use --format json for the desktop wizard's verification panel."
    ),
)
def verify_cmd(
    repo_root: Annotated[
        Path | None,
        typer.Option("--repo-root", "-C"),
    ] = None,
    format: Annotated[
        str,
        typer.Option("--format", help="Output format: pretty (default), json."),
    ] = "pretty",
) -> None:
    """Probe every supported client at all four leverage layers.

    Layers (per docs.vaner.ai/integrations/client-capabilities):

    1. MCP server — is the client's MCP config wired to Vaner?
    2. Primer — is the per-client rules file populated with Vaner's primer?
    3. Skill — is the ``vaner-feedback`` skill installed where supported?
    4. Plugin — is the Vaner plugin installed where supported?
    """

    root = _resolve_repo_root(repo_root)
    results = mcp_clients.verify_all(root)

    if format == "json":
        typer.echo(
            json.dumps(
                {"results": [_verification_to_dict(v) for v in results]},
                indent=2,
            )
        )
        return

    if format != "pretty":
        raise typer.BadParameter(f"unknown format {format!r}. Choose from: pretty, json")

    console = Console()
    table = Table(title="Client leverage stack", show_lines=False)
    table.add_column("Client")
    table.add_column("Detected")
    table.add_column("MCP")
    table.add_column("Primer")
    table.add_column("Skill")
    table.add_column("Plugin")
    table.add_column("Status")

    def _layer_cell(layer: mcp_clients.LayerStatus) -> str:
        if not layer.applicable:
            return "—"
        return "✓" if layer.wired else "✗"

    chip_color = {
        "ready": "green",
        "wired-mcp-only": "yellow",
        "partial": "yellow",
        "missing": "red",
        "not-detected": "dim",
    }

    for r in results:
        chip = f"[{chip_color.get(r.overall, 'dim')}]{r.overall}[/{chip_color.get(r.overall, 'dim')}]"
        table.add_row(
            r.label,
            "yes" if r.detected else "no",
            _layer_cell(r.layers["mcp"]),
            _layer_cell(r.layers["primer"]),
            _layer_cell(r.layers["skill"]),
            _layer_cell(r.layers["plugin"]),
            chip,
        )
    console.print(table)


def _verification_to_dict(v: mcp_clients.ClientVerification) -> dict[str, object]:
    return {
        "client_id": v.client_id,
        "label": v.label,
        "detected": v.detected,
        "overall": v.overall,
        "layers": {
            name: {
                "applicable": layer.applicable,
                "wired": layer.wired,
                "path": str(layer.path) if layer.path is not None else None,
                "detail": layer.detail,
            }
            for name, layer in v.layers.items()
        },
    }


@clients_app.command(
    "doctor",
    help="Detect launcher path drift after Vaner is reinstalled / moved.",
)
def doctor_cmd(
    repo_root: Annotated[
        Path | None,
        typer.Option("--repo-root", "-C"),
    ] = None,
    format: Annotated[
        str,
        typer.Option("--format", help="Output format: pretty (default), json."),
    ] = "pretty",
) -> None:
    root = _resolve_repo_root(repo_root)
    detected_list = mcp_clients.detect_all(root)
    reports = [mcp_clients.launcher_drift(d) for d in detected_list]
    drifted = [r for r in reports if r.drift]

    if format == "json":
        typer.echo(
            json.dumps(
                {
                    "drift": [_drift_to_dict(r) for r in reports],
                    "drift_count": len(drifted),
                    "fix_command": "vaner clients install --all --force",
                },
                indent=2,
            )
        )
        if drifted:
            sys.exit(1)
        return

    if format != "pretty":
        raise typer.BadParameter(f"unknown format {format!r}. Choose from: pretty, json")

    console = Console()
    if not drifted:
        console.print("[green]All configured MCP clients use the current `vaner` binary.[/green]")
        return
    table = Table(title="Launcher drift", show_lines=False)
    table.add_column("Client")
    table.add_column("Configured")
    table.add_column("Expected")
    for r in drifted:
        table.add_row(r.label, r.current_in_config or "-", r.expected)
    console.print(table)
    console.print()
    console.print("[yellow]Fix:[/yellow] run `vaner clients install --all --force`")
    raise typer.Exit(code=1)
