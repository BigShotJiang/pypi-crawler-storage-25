# Architecture

Vaner is a local-first predictive context engine for coding assistants.

## High-level flow

1. Signal collectors observe repository and editor activity.
2. The daemon prepares artefacts and relation edges in a local store.
3. The intent layer predicts likely next prompts and context targets.
4. The broker ranks and assembles context packages under policy controls.
5. CLI/API/proxy layers expose the same engine for different client surfaces.

## Core packages

- `src/vaner/engine.py`: orchestration and runtime loop
- `src/vaner/intent/`: prediction, scoring, and frontier state
- `src/vaner/store/`: persistence and retrieval for artefacts/signals
- `src/vaner/broker/`: context selection and package assembly
- `src/vaner/router/`: OpenAI-compatible proxy and translation paths
- `src/vaner/cli/`: command-line controls and maintenance workflows

## Data boundaries

- Default mode is local-first with explicit repository scope.
- Safety and privacy policy modules gate what leaves local storage.
- Training and sensitive evaluation workflows are intentionally isolated from the public runtime repository.

## Agent skills loop

- Vaner discovers workspace `SKILL.md` files and emits `skill_loaded` intent signals.
- Skills seed tactical frontier candidates through trigger/path matching and optional `vaner.kind`.
- MCP tools accept an optional `skill` label so outcomes are attributed to the active skill.
- Feedback is fed back into source multipliers, reinforcing successful frontier sources.
- `vaner distill-skill` converts successful decision records into managed reusable skills.

## Decision transparency

- Every `query` writes a structured decision record to `.vaner/runtime/decisions/`.
- The record captures package-level metadata (`cache_tier`, `partial_similarity`, token usage), per-selection scoring factors, and prediction links when the package came from precompute/frontier exploration.
- CLI surfaces share this record:
  - `vaner inspect --last [--verbose|--json]`
  - `vaner why [decision-id] [--list|--verbose|--json]`
  - `vaner query --explain [--verbose|--json]`

## Claude Code plugin packaging

Vaner ships a Claude Code plugin under `plugins/vaner/`, catalogued by a repo-root marketplace at `.claude-plugin/marketplace.json`. The plugin is a thin wrapper — it registers the `vaner` MCP server, the `vaner-feedback` skill, and a SessionStart hook that checks whether the `vaner` CLI is on PATH. The actual code still ships via PyPI and `scripts/install.sh`; the plugin only wires Claude Code to the installed CLI. Version parity between `pyproject.toml`, `plugins/vaner/.claude-plugin/plugin.json`, and the marketplace entry is enforced by `scripts/bump-plugin-version.sh` (pre-commit and CI).

## More details

Detailed architecture docs live at `https://docs.vaner.ai/architecture`.

## Memory semantics

Vaner keeps persistent learning on top of scenario artefacts instead of a separate wiki layer. The memory model lives in scenario state and policy logic (`memory_state`, `memory_confidence`, evidence fingerprints, promotion/demotion/invalidation rules), while MCP exposes those results as structured outputs.

Operator-facing traces are written to `.vaner/memory/log.md` and `.vaner/memory/index.md`; those files are inspectability surfaces, not the semantic memory store itself.

See `docs/memory-semantics.md` for state transitions, promotion gate criteria, conflict-aware abstention, and decision reuse policy. A future full "Vaner Memory" wiki layer remains deferred.
