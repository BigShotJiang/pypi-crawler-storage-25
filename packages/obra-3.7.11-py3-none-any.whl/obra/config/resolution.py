"""Model/provider resolution for the Obra CLI.

Resolves effective runtime values from CLI flags and environment variables.
Resolution precedence (highest to lowest): CLI flag > env var > None.

These are pure functions with no Obra framework dependencies.
"""

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class RunConfig:
    """Resolved runtime configuration from CLI flags and environment variables."""

    orch_provider: str | None = None
    orch_model: str | None = None
    orch_reasoning_level: str | None = None
    model: str | None = None
    fast_model: str | None = None
    high_model: str | None = None
    provider: str | None = None
    reasoning_level: str | None = None


def resolve_model(cli_model: str | None) -> str | None:
    """Resolve effective model from CLI flag or environment variable.

    Resolution precedence (highest to lowest):
    1. CLI flag: --model <value>
    2. Environment variable: OBRA_MODEL=<value>
    3. None (caller uses DEFAULT_MODEL)

    Args:
        cli_model: Value from --model CLI flag (None if not specified)

    Returns:
        Effective model string, or None to use default
    """
    if cli_model is not None:
        return cli_model

    env_model = os.environ.get("OBRA_MODEL", "").strip()
    if env_model:
        return env_model

    return None


def resolve_orchestrator_model(cli_model: str | None) -> str | None:
    """Resolve effective orchestrator model from CLI flag or environment variable."""
    if cli_model is not None:
        return cli_model

    env_model = os.environ.get("OBRA_ORCH_MODEL", "").strip()
    if env_model:
        return env_model

    return None


def resolve_tier_model(cli_model: str | None, tier: str) -> str | None:
    """Resolve effective tier override from CLI flag or environment variable."""
    if cli_model is not None:
        return cli_model

    env_value = os.environ.get(f"OBRA_{tier.upper()}_MODEL", "").strip()
    if env_value:
        return env_value

    return None


def resolve_provider(cli_provider: str | None) -> str | None:
    """Resolve effective provider from CLI flag or environment variable.

    Resolution precedence (highest to lowest):
    1. CLI flag: --impl-provider <value>
    2. Environment variable: OBRA_PROVIDER=<value>
    3. None (caller uses DEFAULT_PROVIDER or auto-detection)

    Args:
        cli_provider: Value from --impl-provider CLI flag (None if not specified)

    Returns:
        Effective provider string, or None to use default/auto-detection
    """
    if cli_provider is not None:
        return cli_provider

    env_provider = os.environ.get("OBRA_PROVIDER", "").strip()
    if env_provider:
        return env_provider

    return None


def resolve_orchestrator_provider(cli_provider: str | None) -> str | None:
    """Resolve effective orchestrator provider from CLI flag or environment variable."""
    if cli_provider is not None:
        return cli_provider

    env_provider = os.environ.get("OBRA_ORCH_PROVIDER", "").strip()
    if env_provider:
        return env_provider

    return None


def resolve_reasoning_level(cli_reasoning: str | None) -> str | None:
    """Resolve effective reasoning level from CLI flag or environment variable.

    Resolution precedence (highest to lowest):
    1. CLI flag: --reasoning-level <value>
    2. Environment variable: OBRA_REASONING_LEVEL=<value>
    3. None (caller uses DEFAULT_REASONING_LEVEL)

    Args:
        cli_reasoning: Value from --reasoning-level CLI flag (None if not specified)

    Returns:
        Effective reasoning level string, or None to use default
    """
    if cli_reasoning is not None:
        return cli_reasoning

    env_reasoning = os.environ.get("OBRA_REASONING_LEVEL", "").strip()
    if env_reasoning:
        return env_reasoning

    return None


def resolve_orchestrator_reasoning_level(cli_reasoning: str | None) -> str | None:
    """Resolve effective orchestrator reasoning from CLI flag or environment variable."""
    if cli_reasoning is not None:
        return cli_reasoning

    env_reasoning = os.environ.get("OBRA_ORCH_REASONING_LEVEL", "").strip()
    if env_reasoning:
        return env_reasoning

    return None


def resolve_run_config(
    cli_orch_provider: str | None = None,
    cli_orch_model: str | None = None,
    cli_orch_reasoning_level: str | None = None,
    cli_model: str | None = None,
    cli_fast_model: str | None = None,
    cli_high_model: str | None = None,
    cli_provider: str | None = None,
    cli_reasoning_level: str | None = None,
) -> RunConfig:
    """Resolve all runtime configuration from CLI flags and environment variables.

    Args:
        cli_model: Value from --model CLI flag
        cli_fast_model: Value from --fast-model CLI flag
        cli_high_model: Value from --high-model CLI flag
        cli_provider: Value from --impl-provider CLI flag
        cli_reasoning_level: Value from --reasoning-level CLI flag

    Returns:
        RunConfig with all fields resolved (None means use framework default)
    """
    return RunConfig(
        orch_provider=resolve_orchestrator_provider(cli_orch_provider),
        orch_model=resolve_orchestrator_model(cli_orch_model),
        orch_reasoning_level=resolve_orchestrator_reasoning_level(cli_orch_reasoning_level),
        model=resolve_model(cli_model),
        fast_model=resolve_tier_model(cli_fast_model, "fast"),
        high_model=resolve_tier_model(cli_high_model, "high"),
        provider=resolve_provider(cli_provider),
        reasoning_level=resolve_reasoning_level(cli_reasoning_level),
    )
