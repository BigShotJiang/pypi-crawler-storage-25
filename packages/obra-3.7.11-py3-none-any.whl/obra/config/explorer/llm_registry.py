"""LLM Registry facade for Config Explorer.

Provides a simplified interface to obra.model_registry for use in the
config explorer widgets. This is the single source of truth for LLM
provider and model data in the explorer.

All model data is dynamically loaded from MODEL_REGISTRY - no hardcoded model names.
"""

from __future__ import annotations

from typing import Any

# Lazy-loaded caches
_PROVIDERS_CACHE: list[tuple[str, str, str]] | None = None
_MODELS_CACHE: dict[str, list[tuple[str, str, str]]] | None = None

# Re-export from canonical location (obra.config.llm_compat)
from obra.config.llm_compat import ROLE_TIER_DEFAULTS

_INFRASTRUCTURE_ROLE_DEFAULTS: dict[str, dict[str, str]] = {
    "json_conversion": {"profile": "orchestrator", "tier": "fast"}
}


def _get_inherited_provider_default_model(provider: str) -> str | None:
    """Return provider default model only for providers whose default is an auto router."""
    from obra.model_registry import get_default_model

    default_model = get_default_model(provider)
    if default_model and default_model.startswith("auto"):
        return default_model
    return None


def get_role_tier_defaults(provider: str, role: str) -> dict[str, str]:
    """Get tier defaults for a specific provider and role.

    When "Let Obra choose" (value="default") is selected, these are the
    actual models that will be used at runtime.

    Args:
        provider: Provider ID (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)

    Returns:
        Dict mapping tier names (fast, medium, high) to model IDs.

    Example:
        >>> get_role_tier_defaults('anthropic', 'orchestrator')
        {'fast': 'sonnet', 'medium': 'opus', 'high': 'opus'}
    """
    provider_defaults = ROLE_TIER_DEFAULTS.get(provider, {})
    role_defaults = provider_defaults.get(role, {})
    if role_defaults:
        return role_defaults
    # Fall back to generic provider tier defaults
    return get_provider_tier_defaults(provider)


def resolve_tier_model_display(provider: str, role: str, tier: str, model_id: str) -> str:
    """Resolve a tier's model to display name, using role defaults for 'default'.

    When model_id is 'default', uses ROLE_TIER_DEFAULTS to show what Obra
    will actually use for this provider/role/tier combination.

    Args:
        provider: Provider ID (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)
        tier: Tier name (fast, medium, high)
        model_id: Model ID (may be 'default')

    Returns:
        Human-readable model display name
    """
    from obra.model_registry import MODEL_REGISTRY

    provider_config = MODEL_REGISTRY.get(provider)
    if not provider_config:
        return model_id

    # If not "default", just resolve the model directly
    if model_id != "default":
        model_info = provider_config.models.get(model_id)
        return model_info.display_name if model_info else model_id

    # For "default", use the Obra-recommended role/tier defaults
    role_defaults = get_role_tier_defaults(provider, role)
    actual_id = role_defaults.get(tier, provider_config.default_model or "auto")
    model_info = provider_config.models.get(actual_id)
    return model_info.display_name if model_info else actual_id


def build_tier_preview(
    orch_provider: str,
    orch_model: str,
    impl_provider: str,
    impl_model: str,
    *,
    orch_tiers: dict[str, str] | None = None,
    impl_tiers: dict[str, str] | None = None,
    orch_extra_lines: list[str] | None = None,
) -> str:
    """Build side-by-side preview text showing tier assignments.

    Shows Orchestrator on left, Implementation on right. Used by both
    SimpleLLMView and ModerateLLMView for consistent preview display.

    Args:
        orch_provider: Orchestrator provider ID
        orch_model: Orchestrator model ID (used if orch_tiers not provided)
        impl_provider: Implementation provider ID
        impl_model: Implementation model ID (used if impl_tiers not provided)
        orch_tiers: Optional dict of tier->model for orchestrator
        impl_tiers: Optional dict of tier->model for implementation

    Returns:
        Formatted string with side-by-side tier assignments.
    """

    # Resolve each tier - use per-tier values if provided, otherwise use role model
    def get_orch_tier(tier: str) -> str:
        model = (orch_tiers or {}).get(tier, orch_model)
        return resolve_tier_model_display(orch_provider, "orchestrator", tier, model)

    def get_impl_tier(tier: str) -> str:
        model = (impl_tiers or {}).get(tier, impl_model)
        return resolve_tier_model_display(impl_provider, "implementation", tier, model)

    # Build side-by-side layout with dynamic width so long orchestrator model
    # names do not shift right-column alignment.
    left_lines = [
        "Orchestrator:",
        f"  Fast:   {get_orch_tier('fast')}",
        f"  Medium: {get_orch_tier('medium')}",
        f"  High:   {get_orch_tier('high')}",
    ]
    left_lines.extend(orch_extra_lines or [])
    right_lines = [
        "Implementation:",
        f"  Fast:   {get_impl_tier('fast')}",
        f"  Medium: {get_impl_tier('medium')}",
        f"  High:   {get_impl_tier('high')}",
    ]
    right_lines.extend([""] * max(0, len(left_lines) - len(right_lines)))

    min_left_width = 24
    right_column_gap = 20
    left_width = max(min_left_width, max(len(line) for line in left_lines) + right_column_gap)

    lines = [
        f"{left:<{left_width}}{right}" for left, right in zip(left_lines, right_lines, strict=False)
    ]
    return "\n".join(lines)


def _extract_tier_model(tier_value: Any, fallback_model: str = "default") -> str:
    """Extract model id from a tier entry (string or mapping)."""
    if isinstance(tier_value, dict):
        model = tier_value.get("model", fallback_model)
        return str(model)
    if tier_value is None:
        return fallback_model
    return str(tier_value)


def _normalize_reasoning_tiers(
    reasoning_tiers: dict[str, str] | None,
    fallback_reasoning: str,
) -> dict[str, str]:
    """Normalize reasoning tiers with fallbacks for missing values."""
    return {
        "fast": (reasoning_tiers or {}).get("fast", fallback_reasoning),
        "medium": (reasoning_tiers or {}).get("medium", fallback_reasoning),
        "high": (reasoning_tiers or {}).get("high", fallback_reasoning),
    }


def _get_provider_display_name(provider: str) -> str:
    """Resolve a provider id to the explorer-facing display name."""
    from obra.model_registry import MODEL_REGISTRY

    provider_config = MODEL_REGISTRY.get(provider)
    if not provider_config:
        return provider
    if provider_config.name.lower() == provider_config.cli.lower():
        return provider_config.name
    return f"{provider_config.name} {provider_config.cli}"


def _resolve_tier_model_id(provider: str, role: str, tier: str, model_id: str) -> str:
    """Resolve concrete model id for a role/tier.

    Args:
        provider: Provider id
        role: Role name (orchestrator, implementation)
        tier: Tier name (fast, medium, high)
        model_id: Configured model id ("default" or explicit)

    Returns:
        Concrete model id used at runtime.
    """
    from obra.model_registry import MODEL_REGISTRY

    if model_id != "default":
        return model_id

    role_defaults = get_role_tier_defaults(provider, role)
    provider_config = MODEL_REGISTRY.get(provider)
    provider_default_model = provider_config.default_model if provider_config else None
    return role_defaults.get(tier, provider_default_model or "default")


def _resolve_authoritative_tier_model(
    provider: str,
    role: str,
    tier: str,
    tier_model: str,
    parent_model: str,
) -> str:
    """Resolve tier model for preview, honoring parent auto-router defaults."""
    if tier_model != "default":
        return tier_model
    if parent_model not in {"default", "per-tier", "per-role"}:
        return parent_model
    if parent_model == "default":
        # Preview must mirror runtime resolution, not merely show role-tier capability tables.
        # When a role-level `default` resolves to an auto router like Google `auto`, inherited
        # tier `default` should display that router because that is what runtime executes.
        inherited_model = _get_inherited_provider_default_model(provider)
        if inherited_model:
            return inherited_model
    return tier_model


def _resolve_tier_reasoning(
    *,
    provider: str,
    role: str,
    tier: str,
    model_id: str,
    configured_reasoning: str,
    fallback_reasoning: str,
) -> str:
    """Resolve reasoning level for display/runtime preview semantics."""
    raw_value = configured_reasoning or fallback_reasoning
    if raw_value != "default":
        return raw_value
    return get_model_default_reasoning(
        provider,
        model_id,
        fallback_reasoning="default",
        role=role,
        tier=tier,
    )


def _resolve_role_preview_block(
    *,
    provider: str,
    role: str,
    parent_model: str,
    tiers: dict[str, Any],
    reasoning_tiers: dict[str, str] | None,
    fallback_reasoning: str,
) -> tuple[dict[str, str], dict[str, str]]:
    """Resolve one preview role block to concrete model/reasoning display inputs."""
    resolved_models = {
        tier: _resolve_authoritative_tier_model(
            provider,
            role,
            tier,
            _extract_tier_model(tiers.get(tier), parent_model),
            parent_model,
        )
        for tier in ("fast", "medium", "high")
    }
    normalized_reasoning = _normalize_reasoning_tiers(reasoning_tiers, fallback_reasoning)
    resolved_reasoning = {
        tier: _resolve_tier_reasoning(
            provider=provider,
            role=role,
            tier=tier,
            model_id=_resolve_tier_model_id(provider, role, tier, resolved_models[tier]),
            configured_reasoning=normalized_reasoning[tier],
            fallback_reasoning=fallback_reasoning,
        )
        for tier in ("fast", "medium", "high")
    }
    return resolved_models, resolved_reasoning


def _resolve_auxiliary_preview_line(
    *,
    role_id: str,
    role_configs: dict[str, dict[str, Any]] | None,
    orch_provider: str,
    impl_provider: str,
    orch_models: dict[str, str],
    impl_models: dict[str, str],
) -> str | None:
    """Resolve one auxiliary role preview line from parent tiers plus Menu 4 overrides."""
    defaults = _INFRASTRUCTURE_ROLE_DEFAULTS.get(role_id)
    if defaults is None:
        return None

    role_cfg = role_configs.get(role_id, {}) if isinstance(role_configs, dict) else {}
    profile = str(role_cfg.get("profile") or defaults["profile"])
    tier = str(role_cfg.get("tier") or defaults["tier"])
    provider = str(
        role_cfg.get("provider")
        or (orch_provider if profile == "orchestrator" else impl_provider)
    )
    inherited_models = orch_models if profile == "orchestrator" else impl_models
    if role_cfg.get("model"):
        model_id = str(role_cfg["model"])
    elif role_cfg.get("provider"):
        model_id = "default"
    else:
        model_id = inherited_models.get(tier, "default")

    display_model = resolve_tier_model_display(provider, profile, tier, model_id)
    return f"  JSON Conversion: {display_model}"


def build_authoritative_llm_preview(
    *,
    orch_provider: str,
    impl_provider: str,
    orch_model: str = "default",
    impl_model: str = "default",
    orch_tiers: dict[str, Any],
    impl_tiers: dict[str, Any],
    orch_reasoning_tiers: dict[str, str] | None,
    impl_reasoning_tiers: dict[str, str] | None,
    orch_fallback_reasoning: str = "default",
    impl_fallback_reasoning: str = "default",
    role_configs: dict[str, dict[str, Any]] | None = None,
    fallback_enabled: bool = False,
    fallback_orch_provider: str | None = None,
    fallback_impl_provider: str | None = None,
    fallback_orch_model: str = "default",
    fallback_impl_model: str = "default",
    fallback_orch_tiers: dict[str, Any] | None = None,
    fallback_impl_tiers: dict[str, Any] | None = None,
    fallback_orch_reasoning_tiers: dict[str, str] | None = None,
    fallback_impl_reasoning_tiers: dict[str, str] | None = None,
    fallback_orch_fallback_reasoning: str = "default",
    fallback_impl_fallback_reasoning: str = "default",
) -> str:
    """Build preview from effective parent tiers + explicit child overrides.

    This is intended for menu previews where the displayed state should reflect
    final effective config, including explicit per-action overrides.
    """

    orch_models, resolved_orch_reasoning = _resolve_role_preview_block(
        provider=orch_provider,
        role="orchestrator",
        parent_model=orch_model,
        tiers=orch_tiers,
        reasoning_tiers=orch_reasoning_tiers,
        fallback_reasoning=orch_fallback_reasoning,
    )
    impl_models, resolved_impl_reasoning = _resolve_role_preview_block(
        provider=impl_provider,
        role="implementation",
        parent_model=impl_model,
        tiers=impl_tiers,
        reasoning_tiers=impl_reasoning_tiers,
        fallback_reasoning=impl_fallback_reasoning,
    )

    preview = build_tier_preview(
        orch_provider=orch_provider,
        orch_model=orch_model,
        impl_provider=impl_provider,
        impl_model=impl_model,
        orch_tiers=orch_models,
        impl_tiers=impl_models,
        orch_extra_lines=[
            line
            for line in [
                _resolve_auxiliary_preview_line(
                    role_id="json_conversion",
                    role_configs=role_configs,
                    orch_provider=orch_provider,
                    impl_provider=impl_provider,
                    orch_models=orch_models,
                    impl_models=impl_models,
                )
            ]
            if line
        ],
    )
    lines = [
        preview,
        "",
        "Reasoning by tier:",
        (
            "  Orchestrator: "
            f"fast={resolved_orch_reasoning['fast']}, "
            f"medium={resolved_orch_reasoning['medium']}, "
            f"high={resolved_orch_reasoning['high']}"
        ),
        (
            "  Implementation: "
            f"fast={resolved_impl_reasoning['fast']}, "
            f"medium={resolved_impl_reasoning['medium']}, "
            f"high={resolved_impl_reasoning['high']}"
        ),
    ]

    if fallback_orch_provider or fallback_impl_provider:
        resolved_fallback_orch_provider = fallback_orch_provider or orch_provider
        resolved_fallback_impl_provider = fallback_impl_provider or impl_provider
        lines.extend(
            [
                "",
                "Fallback configuration:",
                f"  Enabled: {'yes' if fallback_enabled else 'no'}",
                (
                    "  Orchestrator provider: "
                    f"{_get_provider_display_name(resolved_fallback_orch_provider)}"
                ),
                (
                    "  Implementation provider: "
                    f"{_get_provider_display_name(resolved_fallback_impl_provider)}"
                ),
            ]
        )
        if fallback_orch_tiers is not None and fallback_impl_tiers is not None:
            resolved_fallback_orch_models, resolved_fallback_orch_reasoning = (
                _resolve_role_preview_block(
                    provider=resolved_fallback_orch_provider,
                    role="orchestrator",
                    parent_model=fallback_orch_model,
                    tiers=fallback_orch_tiers,
                    reasoning_tiers=fallback_orch_reasoning_tiers,
                    fallback_reasoning=fallback_orch_fallback_reasoning,
                )
            )
            resolved_fallback_impl_models, resolved_fallback_impl_reasoning = (
                _resolve_role_preview_block(
                    provider=resolved_fallback_impl_provider,
                    role="implementation",
                    parent_model=fallback_impl_model,
                    tiers=fallback_impl_tiers,
                    reasoning_tiers=fallback_impl_reasoning_tiers,
                    fallback_reasoning=fallback_impl_fallback_reasoning,
                )
            )
            fallback_preview = build_tier_preview(
                orch_provider=resolved_fallback_orch_provider,
                orch_model=fallback_orch_model,
                impl_provider=resolved_fallback_impl_provider,
                impl_model=fallback_impl_model,
                orch_tiers=resolved_fallback_orch_models,
                impl_tiers=resolved_fallback_impl_models,
            )
            lines.extend(
                [
                    "",
                    "Fallback tiers:",
                    fallback_preview,
                    "",
                    "Fallback reasoning by tier:",
                    (
                        "  Orchestrator: "
                        f"fast={resolved_fallback_orch_reasoning['fast']}, "
                        f"medium={resolved_fallback_orch_reasoning['medium']}, "
                        f"high={resolved_fallback_orch_reasoning['high']}"
                    ),
                    (
                        "  Implementation: "
                        f"fast={resolved_fallback_impl_reasoning['fast']}, "
                        f"medium={resolved_fallback_impl_reasoning['medium']}, "
                        f"high={resolved_fallback_impl_reasoning['high']}"
                    ),
                ]
            )

    override_lines: list[str] = []
    for action, role_cfg in sorted((role_configs or {}).items()):
        if not isinstance(role_cfg, dict):
            continue
        parts: list[str] = []
        if role_cfg.get("provider"):
            parts.append(f"provider={role_cfg['provider']}")
        if role_cfg.get("model"):
            parts.append(f"model={role_cfg['model']}")
        if role_cfg.get("reasoning_level"):
            parts.append(f"reasoning={role_cfg['reasoning_level']}")
        if parts:
            override_lines.append(f"  {action}: {', '.join(parts)}")

    lines.append("")
    if override_lines:
        lines.append("Explicit child overrides (Menu 3):")
        lines.extend(override_lines)
    else:
        lines.append("Explicit child overrides (Menu 3): none")

    return "\n".join(lines)


def _load_providers() -> list[tuple[str, str, str]]:
    """Load provider definitions from MODEL_REGISTRY.

    Uses authoritative data from MODEL_REGISTRY:
    - name: Provider company (Anthropic, Google, OpenAI, Ollama)
    - cli: Product/CLI name (Claude, Gemini, Codex, Ollama)
    - description: Short description for UI

    Returns:
        List of (provider_id, display_name, description) tuples.
        display_name format: "{name} {cli}" (e.g., "Anthropic Claude")
        If name == cli (e.g., Ollama), just use the name once.

        Ordered: Claude, Codex, Gemini, Ollama, then any future providers.
    """
    from obra.model_registry import MODEL_REGISTRY

    # Preferred ordering for UI (new providers go at end)
    provider_order = ["anthropic", "openai", "google", "ollama"]

    providers = []
    for provider_id, config in MODEL_REGISTRY.items():
        # Format: "Anthropic Claude", "Google Gemini", "OpenAI Codex"
        # But if name == cli (Ollama), just use the name once
        if config.name.lower() == config.cli.lower():
            display_name = config.name
        else:
            display_name = f"{config.name} {config.cli}"
        description = config.description
        providers.append((provider_id, display_name, description))

    # Sort by preferred order, unknown providers go at end
    def sort_key(p: tuple[str, str, str]) -> int:
        try:
            return provider_order.index(p[0])
        except ValueError:
            return len(provider_order)  # Unknown providers at end

    providers.sort(key=sort_key)
    return providers


def _load_models() -> dict[str, list[tuple[str, str, str]]]:
    """Load model definitions per provider from MODEL_REGISTRY.

    Smart alias filtering:
    - If alias target exists in registry: Hide alias (avoid duplicates)
    - If alias target doesn't exist: Show FIRST alias only (prefer shorter names)

    Models are sorted by tier: recommended → high → medium → fast.

    Returns:
        Dict mapping provider_id to list of (model_id, display_string, tier) tuples.
        Tier is one of: 'recommended', 'high', 'medium', 'fast'.
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus, resolve_quality_tier

    # Tier sort order: recommended first, then high → medium → fast
    tier_order = {"recommended": 0, "high": 1, "medium": 2, "fast": 3}

    models = {}
    for provider_name, provider_config in MODEL_REGISTRY.items():
        # Start with recommended option
        provider_models: list[tuple[str, str, str]] = [
            ("default", "Let Obra choose", "recommended")
        ]

        # Track which alias targets we've already included
        seen_targets = set()

        # Add non-deprecated models with smart alias filtering
        for model_id, model_info in provider_config.models.items():
            # Skip deprecated models
            if model_info.status == ModelStatus.DEPRECATED:
                continue

            # Smart alias handling
            if hasattr(model_info, "resolves_to") and model_info.resolves_to is not None:
                target = model_info.resolves_to

                # If target exists in registry, skip this alias (avoid duplicates)
                if target in provider_config.models and not (
                    provider_name == "google" and model_id == "auto"
                ):
                    continue

                # If we've already shown an alias for this target, skip this one
                if target in seen_targets:
                    continue

                # Mark this target as seen
                seen_targets.add(target)

            # Get the quality tier for this model
            tier = resolve_quality_tier(provider_name, model_id)

            display = model_info.display_name
            if model_info.description:
                display += f" - {model_info.description}"
            provider_models.append((model_id, display, tier))

        # Sort by tier order (recommended first, then high → medium → fast)
        provider_models.sort(key=lambda x: tier_order.get(x[2], 99))

        models[provider_name] = provider_models

    return models


def get_providers() -> list[tuple[str, str, str]]:
    """Get list of available LLM providers.

    Returns:
        List of (provider_id, display_name, description) tuples.

    Example:
        >>> providers = get_providers()
        >>> providers[0]
        ('anthropic', 'Claude', 'AI thinking partner for developers')
    """
    global _PROVIDERS_CACHE
    if _PROVIDERS_CACHE is None:
        _PROVIDERS_CACHE = _load_providers()
    return _PROVIDERS_CACHE


def get_models() -> dict[str, list[tuple[str, str, str]]]:
    """Get available models per provider, sorted by tier.

    Models are sorted: recommended → high → medium → fast.

    Returns:
        Dict mapping provider_id to list of (model_id, display_string, tier) tuples.
        Tier is one of: 'recommended', 'high', 'medium', 'fast'.

    Example:
        >>> models = get_models()
        >>> models['anthropic'][0]
        ('default', 'Let Obra choose', 'recommended')
        >>> models['anthropic'][1]
        ('opus', 'Claude Opus 4.6 - ...', 'high')
    """
    global _MODELS_CACHE
    if _MODELS_CACHE is None:
        _MODELS_CACHE = _load_models()
    return _MODELS_CACHE


def get_model_cost(provider: str, model_id: str) -> str:
    """Get cost indicator for a model based on quality tier.

    Derives cost dynamically from the model's quality tier:
    - high tier: '$$$'
    - medium tier: '$$'
    - fast tier: '$'
    - Local providers (api_key_env is None): 'Free'

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier

    Returns:
        Cost indicator string: '$', '$$', '$$$', or 'Free'

    Example:
        >>> get_model_cost('anthropic', 'opus')
        '$$$'
        >>> get_model_cost('anthropic', 'haiku')
        '$'
        >>> get_model_cost('ollama', 'qwen2.5-coder:32b')
        'Free'
    """
    from obra.model_registry import MODEL_REGISTRY, resolve_quality_tier

    # Check if provider is local (no API key required)
    config = MODEL_REGISTRY.get(provider)
    if config and config.api_key_env is None:
        return "Free"

    # Handle 'default' model by using provider's default
    if model_id == "default":
        if config and config.default_model:
            model_id = config.default_model
        else:
            return "$$"  # Safe default for unknown

    # Derive cost from quality tier
    tier = resolve_quality_tier(provider, model_id)
    tier_to_cost = {
        "high": "$$$",
        "medium": "$$",
        "fast": "$",
    }
    return tier_to_cost.get(tier, "$$")


def supports_thinking(provider: str, model_id: str) -> bool:
    """Check whether a model supports extended thinking.

    Delegates to obra.model_registry.supports_extended_thinking().

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model_id: Model identifier

    Returns:
        True if extended thinking is supported, False otherwise.

    Example:
        >>> supports_thinking('anthropic', 'opus')
        True
        >>> supports_thinking('anthropic', 'haiku')
        False
    """
    from obra.model_registry import supports_extended_thinking

    # Handle 'default' model by using provider's default
    if model_id == "default":
        from obra.model_registry import MODEL_REGISTRY

        config = MODEL_REGISTRY.get(provider)
        if config and config.default_model:
            model_id = config.default_model
        else:
            return True  # Safe default

    return supports_extended_thinking(provider, model_id)


def get_model_default_reasoning(
    provider: str,
    model_id: str,
    fallback_reasoning: str = "medium",
    *,
    role: str | None = None,
    tier: str | None = None,
) -> str:
    """Get model default reasoning for provider/model/role/tier context.

    Returns:
        Model/context default when available, otherwise the provided fallback.
    """
    from obra.model_registry import get_reasoning_profile

    if fallback_reasoning != "default":
        return fallback_reasoning
    profile = get_reasoning_profile(provider, model_id, role=role, tier=tier)
    return profile.default_level if profile.default_level else "medium"


def get_provider_tier_defaults(provider: str) -> dict[str, str]:
    """Get mapping of quality tiers to default model IDs for a provider.

    Used by personas to resolve tier references to actual models.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)

    Returns:
        Dict mapping tier ('fast', 'medium', 'high') to model_id.

    Example:
        >>> get_provider_tier_defaults('anthropic')
        {'fast': 'haiku', 'medium': 'sonnet', 'high': 'opus'}
    """
    from obra.config.loaders import (
        get_provider_tier_defaults as get_runtime_provider_tier_defaults,
    )
    from obra.model_registry import (
        MODEL_REGISTRY,
        resolve_quality_tier,
    )

    runtime_defaults = get_runtime_provider_tier_defaults()
    provider_defaults = runtime_defaults.get(provider)
    if isinstance(provider_defaults, dict) and provider_defaults:
        return {
            tier: model
            for tier, model in provider_defaults.items()
            if tier in {"fast", "medium", "high"}
        }

    config = MODEL_REGISTRY.get(provider)
    if not config:
        return {}

    tier_defaults: dict[str, str] = {}
    for model_id, model_info in config.models.items():
        # Skip deprecated models and aliases
        from obra.model_registry import ModelStatus

        if model_info.status == ModelStatus.DEPRECATED:
            continue
        if model_info.resolves_to is not None:
            continue

        tier = resolve_quality_tier(provider, model_id)
        # Use first model found for each tier (prefer shorter aliases)
        if tier not in tier_defaults:
            tier_defaults[tier] = model_id

    return tier_defaults


def clear_cache() -> None:
    """Clear cached provider and model data.

    Useful for testing or when MODEL_REGISTRY is updated.
    """
    global _PROVIDERS_CACHE, _MODELS_CACHE
    _PROVIDERS_CACHE = None
    _MODELS_CACHE = None
