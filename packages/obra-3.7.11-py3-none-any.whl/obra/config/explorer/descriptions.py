"""Setting descriptions for the Configuration Explorer.

Provides human-readable descriptions for all configuration options,
used for inline documentation in the TUI.
"""

from typing import Any

# Mapping from dot-notation path to description text.
# Descriptions should be concise but informative, explaining what the
# setting does and any important considerations.
CONFIG_DESCRIPTIONS: dict[str, str] = {
    # ==========================================================================
    # Advanced / Diagnostics
    # ==========================================================================
    "advanced": "Advanced and diagnostic settings (use with care).",
    "advanced.logging": "CLI logging settings (level, format, file rotation).",
    "advanced.debug": "Development/debug flags (disable in production).",
    "advanced.audit": "Audit logging settings for destructive operations.",
    "advanced.metrics": "Work unit metrics reporting configuration.",
    # ==========================================================================
    # Connectors
    # ==========================================================================
    "connectors.google_drive.oauth.client_id": (
        "Google OAuth client id used by Workflow Studio to start the Google Drive "
        "browser authorization flow."
    ),
    "connectors.google_drive.oauth.client_secret": (
        "Google OAuth client secret used by the local gateway to exchange and refresh "
        "Google Drive user tokens. This value is editable from Studio but is never "
        "returned to the browser after save."
    ),
    # ==========================================================================
    # LLM Settings - Local Config
    # ==========================================================================
    "llm": "LLM provider configuration for orchestration and implementation layers.",
    "llm.reasoning_level": (
        "Default reasoning level used when stage defaults are not specified. "
        "Normalized levels: off, low, medium, high, maximum."
    ),
    "llm.reasoning": (
        "Reasoning selection overrides and constraints applied after stage defaults."
    ),
    "llm.reasoning.force_level": (
        "Force a fixed reasoning level across operations. Set to null to allow stage defaults."
    ),
    "llm.reasoning.strict_mode": (
        "Error when a requested reasoning level is unsupported. "
        "When false, Obra warns and downgrades."
    ),
    "llm.reasoning.tiers": "Per-tier reasoning bounds (fast/medium/high).",
    "llm.reasoning.tiers.fast": "Reasoning bounds for fast tier models.",
    "llm.reasoning.tiers.fast.min_level": "Minimum reasoning level for fast tier.",
    "llm.reasoning.tiers.fast.max_level": "Maximum reasoning level for fast tier.",
    "llm.reasoning.tiers.medium": "Reasoning bounds for medium tier models.",
    "llm.reasoning.tiers.medium.min_level": "Minimum reasoning level for medium tier.",
    "llm.reasoning.tiers.medium.max_level": "Maximum reasoning level for medium tier.",
    "llm.reasoning.tiers.high": "Reasoning bounds for high tier models.",
    "llm.reasoning.tiers.high.min_level": "Minimum reasoning level for high tier.",
    "llm.reasoning.tiers.high.max_level": "Maximum reasoning level for high tier.",
    "llm.orchestrator": (
        "Settings for the orchestration layer LLM (planning, validation, decisions)."
    ),
    "llm.orchestrator.provider": (
        "LLM provider for the orchestration layer. "
        "Handles planning, validation, and decision-making. "
        "Options: anthropic (Claude), openai (OpenAI Codex), "
        "google (Gemini), ollama (local models via Codex local-provider mode; "
        "requires codex CLI plus running Ollama)."
    ),
    "llm.orchestrator.model": (
        "Model to use for orchestration. "
        "Options vary by provider: "
        "Anthropic: sonnet, opus, haiku | "
        "Google: auto, auto-gemini-3, auto-gemini-2.5, gemini-3.1-pro-preview, gemini-3-flash-preview, gemini-2.5-pro, gemini-2.5-flash | "
        "OpenAI: codex, gpt-5.5, gpt-5.4, gpt-5.4-mini, gpt-5.3-codex, gpt-5.3-codex-spark, gpt-5.2, gpt-5.2-codex, gpt-5.1-codex-max, gpt-5.1-codex-mini | "
        "Ollama: locally pulled model tags (for example qwen2.5-coder, qwen2.5, llama3.3). "
        "Use 'default' to follow Obra tier defaults."
    ),
    "llm.orchestrator.auth_method": (
        "Authentication method for the orchestration LLM. "
        "'oauth' uses flat-rate billing through Obra subscription. "
        "'api_key' bills directly to your provider account (pay-per-token). "
        "For Ollama local runtime, no API key is required."
    ),
    "llm.orchestrator.reasoning_level": (
        "Default reasoning level for orchestration calls. "
        "Normalized levels: off, low, medium, high, maximum."
    ),
    "llm.orchestrator.tiers": (
        "Tiered model configuration for orchestrator adaptive complexity handling. "
        "Define fast/medium/high tiers to automatically select appropriate models "
        "based on task complexity. "
        "Tiers use the orchestrator provider (llm.orchestrator.provider)."
    ),
    "llm.orchestrator.tiers.fast": (
        "Fast tier model for orchestrator - simple, low-complexity tasks. "
        "Use lower reasoning on capable models (e.g., Anthropic: 'haiku', "
        "OpenAI: 'gpt-5.5', Google: 'gemini-2.5-flash'). "
        "Dropdown options match the orchestrator provider."
    ),
    "llm.orchestrator.tiers.medium": (
        "Medium tier model for orchestrator - moderate-complexity tasks. "
        "Use balanced models (e.g., Anthropic: 'sonnet', "
        "OpenAI: 'gpt-5.5', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the orchestrator provider."
    ),
    "llm.orchestrator.tiers.high": (
        "High tier model for orchestrator - complex, critical tasks. "
        "Use frontier models (e.g., Anthropic: 'opus', "
        "OpenAI: 'gpt-5.5', Google: 'gemini-3.1-pro-preview'). "
        "Dropdown options match the orchestrator provider."
    ),
    "llm.implementation": (
        "Settings for the implementation layer LLM (code generation, file modifications)."
    ),
    "llm.implementation.provider": (
        "LLM provider for the implementation layer. "
        "Handles code generation and file modifications. "
        "Options: anthropic (Claude Code), openai (OpenAI Codex), "
        "google (Gemini CLI), ollama (local models via Codex local-provider mode; "
        "requires codex CLI plus running Ollama)."
    ),
    "llm.implementation.model": (
        "Model to use for implementation. "
        "Options vary by provider: "
        "Anthropic: sonnet, opus, haiku | "
        "Google: auto, auto-gemini-3, auto-gemini-2.5, gemini-3.1-pro-preview, gemini-3-flash-preview, gemini-2.5-pro, gemini-2.5-flash | "
        "OpenAI: codex, gpt-5.5, gpt-5.4, gpt-5.4-mini, gpt-5.3-codex, gpt-5.3-codex-spark, gpt-5.2, gpt-5.2-codex, gpt-5.1-codex-max, gpt-5.1-codex-mini | "
        "Ollama: locally pulled model tags (for example qwen2.5-coder, qwen2.5, llama3.3). "
        "Use 'default' to follow Obra tier defaults."
    ),
    "llm.implementation.auth_method": (
        "Authentication method for the implementation LLM. "
        "'oauth' uses your provider's CLI authentication. "
        "'api_key' requires setting the provider's API key environment variable. "
        "For Ollama local runtime, no API key is required."
    ),
    "llm.implementation.reasoning_level": (
        "Default reasoning level for implementation calls. "
        "Normalized levels: off, low, medium, high, maximum."
    ),
    "llm.implementation.tiers": (
        "Tiered model configuration for implementation adaptive complexity handling. "
        "Define fast/medium/high tiers to automatically select appropriate models "
        "based on task complexity. "
        "Tiers use the implementation provider (llm.implementation.provider)."
    ),
    "llm.implementation.tiers.fast": (
        "Fast tier model for implementation - simple, low-complexity tasks. "
        "Use lower reasoning on capable models (e.g., Anthropic: 'haiku', "
        "OpenAI: 'gpt-5.5', Google: 'gemini-2.5-flash'). "
        "Dropdown options match the implementation provider."
    ),
    "llm.implementation.tiers.medium": (
        "Medium tier model for implementation - moderate-complexity tasks. "
        "Use balanced models (e.g., Anthropic: 'sonnet', "
        "OpenAI: 'gpt-5.5', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the implementation provider."
    ),
    "llm.implementation.tiers.high": (
        "High tier model for implementation - complex, critical tasks. "
        "Use frontier models (e.g., Anthropic: 'opus', "
        "OpenAI: 'gpt-5.5', Google: 'gemini-2.5-pro'). "
        "Dropdown options match the implementation provider."
    ),
    "llm.fallback.enabled": (
        "Enable automatic fallback to alternative models when the primary hits a transient "
        "provider failure such as quota, timeout, or a temporary 5xx outage. "
        "When enabled, Obra tries the fallback models configured below before failing the request. "
        "Default: disabled."
    ),
    "llm.fallback.startup_failover_enabled": (
        "Allow startup/session warm-up to activate fallback when the primary fails with a "
        "transient error. Deterministic setup failures such as auth or invalid models still fail fast."
    ),
    "llm.fallback.cooldown_s": (
        "Seconds to avoid a failed provider/model before retrying it in the active-fallback path. "
        "Default: 300."
    ),
    "llm.fallback.transient_error_classes": (
        "Shared failure classes eligible for automatic fallback. Default: rate_limit, transient."
    ),
    "llm.fallback.recovery.enabled": (
        "Allow a conservative return-to-primary canary after cooldown. Obra never sends background probes; "
        "the next real request is used as the canary."
    ),
    "llm.fallback.recovery.cooldown_s": (
        "Seconds to wait before one real request may canary the primary again. Default: 900."
    ),
    "llm.fallback.recovery.max_canary_attempts_per_session": (
        "Maximum primary recovery canaries per session. Default: 1."
    ),
    "llm.fallback.recovery.require_natural_boundary": (
        "When true, recovery only happens on real invocation boundaries. No synthetic probe prompts are sent."
    ),
    "llm.fallback.orchestrator.provider": (
        "Fallback provider for the orchestrator role when the primary provider has a transient failure."
    ),
    "llm.fallback.orchestrator.tiers.fast": "Fallback model for orchestrator fast tier.",
    "llm.fallback.orchestrator.tiers.fast.model": "Fallback model for orchestrator fast tier.",
    "llm.fallback.orchestrator.tiers.fast.reasoning_level": (
        "Fallback reasoning level for orchestrator fast tier."
    ),
    "llm.fallback.orchestrator.tiers.medium": "Fallback model for orchestrator medium tier.",
    "llm.fallback.orchestrator.tiers.medium.model": "Fallback model for orchestrator medium tier.",
    "llm.fallback.orchestrator.tiers.medium.reasoning_level": (
        "Fallback reasoning level for orchestrator medium tier."
    ),
    "llm.fallback.orchestrator.tiers.high": "Fallback model for orchestrator high tier.",
    "llm.fallback.orchestrator.tiers.high.model": "Fallback model for orchestrator high tier.",
    "llm.fallback.orchestrator.tiers.high.reasoning_level": (
        "Fallback reasoning level for orchestrator high tier."
    ),
    "llm.fallback.implementation.provider": (
        "Fallback provider for the implementation role when the primary provider has a transient failure."
    ),
    "llm.fallback.implementation.tiers.fast": "Fallback model for implementation fast tier.",
    "llm.fallback.implementation.tiers.fast.model": "Fallback model for implementation fast tier.",
    "llm.fallback.implementation.tiers.fast.reasoning_level": (
        "Fallback reasoning level for implementation fast tier."
    ),
    "llm.fallback.implementation.tiers.medium": "Fallback model for implementation medium tier.",
    "llm.fallback.implementation.tiers.medium.model": (
        "Fallback model for implementation medium tier."
    ),
    "llm.fallback.implementation.tiers.medium.reasoning_level": (
        "Fallback reasoning level for implementation medium tier."
    ),
    "llm.fallback.implementation.tiers.high": "Fallback model for implementation high tier.",
    "llm.fallback.implementation.tiers.high.model": "Fallback model for implementation high tier.",
    "llm.fallback.implementation.tiers.high.reasoning_level": (
        "Fallback reasoning level for implementation high tier."
    ),
    "llm.codex": (
        "Codex runtime controls for codex-backed providers (OpenAI and Ollama local-provider mode)."
    ),
    "llm.codex.approval_mode": (
        "Codex approval mode when sandbox bypass is disabled. "
        "Options: suggest, auto-edit, full-auto."
    ),
    "llm.codex.bypass_sandbox": (
        "Bypass Codex sandbox and approval gates. "
        "Dangerous: only use in externally sandboxed environments."
    ),
    "llm.codex.enable_features": (
        "List of Codex CLI features to force-enable for each invocation "
        "via repeatable --enable flags."
    ),
    "llm.codex.disable_features": (
        "List of Codex CLI features to force-disable for each invocation "
        "via repeatable --disable flags."
    ),
    # ==========================================================================
    # LLM Git Repository Settings (GIT-HARD-001)
    # ==========================================================================
    "llm.git": "Git repository validation settings for LLM execution.",
    "llm.git.skip_check": (
        "Skip git repository validation before LLM execution. "
        "Auto-enabled for Codex-backed providers (OpenAI and Ollama local-provider mode). "
        "When false, Obra requires projects to be in a git repository "
        "for change tracking and safe rollbacks. "
        "You can manually override this setting if needed."
    ),
    "llm.git.auto_init": (
        "Auto-initialize git repository if not present. "
        "When true, Obra will run 'git init' and create a default .gitignore "
        "if the project directory is not already a git repository. "
        "Useful for new projects. Default: false."
    ),
    "llm.git.auto_init_require_depth": (
        "Minimum depth from home directory for auto-init safety. "
        "Prevents auto-init in shallow paths like ~/ or ~/myapp. "
        "Example: ~/projects/myapp has depth 2 (projects, myapp). "
        "Default: 2."
    ),
    "llm.git.auto_init_max_files": (
        "Maximum files allowed for auto-init safety. "
        "Blocks auto-init if directory has more than this many files. "
        "Prevents polluting existing projects. "
        "Default: 1000."
    ),
    "llm.git.auto_init_blacklist": (
        "Additional paths to block from auto-init. "
        "List of absolute paths that should never be auto-initialized "
        "(e.g., ['/srv', '/mnt']). System paths like / and /tmp are "
        "always blocked. Default: []."
    ),
    # ==========================================================================
    # LLM Role-Based Configuration (ADR-069)
    # ==========================================================================
    "llm.roles": (
        "Configure which model handles each pipeline action. "
        "Each role can reference a profile (orchestrator/implementation) or "
        "specify custom provider/model settings."
    ),
    # Planning phase roles
    "llm.roles.derive": (
        "Model for plan derivation. Breaks down objectives into executable plans. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.examine": (
        "Model for plan examination. Reviews plans for issues and improvements. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.revise": (
        "Model for plan revision. Updates plans based on examination feedback. "
        "Defaults to orchestrator profile."
    ),
    # Execution phase roles
    "llm.roles.execute": (
        "Model for task execution. Implements code changes and file operations. "
        "Defaults to implementation profile."
    ),
    "llm.roles.fix": (
        "Model for fixing issues. Resolves problems found during execution. "
        "Defaults to implementation profile."
    ),
    "llm.roles.review": (
        "Model for code review. Performs quality and architecture review. "
        "Defaults to implementation profile."
    ),
    "llm.roles.json_conversion": (
        "Model for Obra's shared JSON formatter. Selects the provider/model for "
        "the NL-to-JSON conversion step; the conversion reasoning level is still "
        "controlled by pipeline.json_conversion.reasoning_level."
    ),
    "llm.roles.json_conversion.profile": (
        "Base profile for the shared JSON formatter model. Defaults to orchestrator."
    ),
    "llm.roles.json_conversion.tier": (
        "Tier inherited by the shared JSON formatter model. Defaults to fast."
    ),
    # Pre-planning phase roles (intent enrichment)
    "llm.roles.enrichment_assumptions": (
        "Model for gathering assumptions. Identifies what is not explicitly stated. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.enrichment_analogues": (
        "Model for finding analogous solutions. Identifies similar problems/patterns. "
        "Defaults to orchestrator profile."
    ),
    "llm.roles.enrichment_brief": (
        "Model for generating planning briefs. Creates structured planning documents. "
        "Defaults to orchestrator profile."
    ),
    # ==========================================================================
    # Planning - Intent Enrichment
    # ==========================================================================
    "planning": "Planning configuration for derivation and intent enrichment.",
    "planning.enrichment": "Intent enrichment stages before derivation.",
    "planning.enrichment.enabled": (
        "Enable intent enrichment (assumptions, analogues, brief, review)."
    ),
    "planning.enrichment.always_on": (
        "When enabled, always run enrichment stages for derive (unless --no-enrich)."
    ),
    "planning.enrichment.stages": "Stage-specific configuration for intent enrichment.",
    "planning.enrichment.stages.assumptions": (
        "Stage A: gather assumptions and non-inferable questions."
    ),
    "planning.enrichment.stages.assumptions.model_tier": (
        "Model tier for the assumptions stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.assumptions.reasoning_level": (
        "Reasoning level for the assumptions stage."
    ),
    "planning.enrichment.stages.assumptions.max_passes": (
        "Max attempts for the assumptions stage."
    ),
    "planning.enrichment.stages.assumptions.timeout_s": (
        "Timeout in seconds for the assumptions stage. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "planning.enrichment.stages.assumptions.max_questions": (
        "Max non-inferable questions to ask in interactive runs."
    ),
    "planning.enrichment.stages.analogues": (
        "Stage B: domain inference and expert-aligned intent updates."
    ),
    "planning.enrichment.stages.analogues.model_tier": (
        "Model tier for the analogues stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.analogues.reasoning_level": (
        "Reasoning level for the analogues stage."
    ),
    "planning.enrichment.stages.analogues.max_passes": ("Max attempts for the analogues stage."),
    "planning.enrichment.stages.analogues.timeout_s": (
        "Timeout in seconds for the analogues stage. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "planning.enrichment.stages.brief": ("Stage C: consolidate a clean intent brief."),
    "planning.enrichment.stages.brief.model_tier": (
        "Model tier for the brief stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.brief.reasoning_level": ("Reasoning level for the brief stage."),
    "planning.enrichment.stages.brief.max_passes": ("Max attempts for the brief stage."),
    "planning.enrichment.stages.brief.timeout_s": (
        "Timeout in seconds for the brief stage. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "planning.enrichment.stages.derive": ("Stage D: derive plan from enriched intent."),
    "planning.enrichment.stages.derive.model_tier": (
        "Model tier for the derive stage (fast/medium/high)."
    ),
    "planning.enrichment.stages.derive.reasoning_level": ("Reasoning level for the derive stage."),
    "planning.enrichment.stages.derive.max_passes": ("Max attempts for the derive stage."),
    "planning.enrichment.stages.derive.timeout_s": (
        "Timeout in seconds for the derive stage. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "planning.enrichment.non_inferable_categories": (
        "Categories that require user input when missing (interactive only)."
    ),
    "planning.enrichment.diff": "Intent diff output settings.",
    "planning.enrichment.diff.path_template": (
        "Template for intent diff path (supports {intent_id})."
    ),
    "planning.enrichment.diff.retention": "Retention policy for intent diffs.",
    "planning.enrichment.diff.retention.max_files": ("Max diff files to retain."),
    "planning.enrichment.artifacts": "Stage artifact output settings.",
    "planning.enrichment.artifacts.dir": "Directory for enrichment stage artifacts.",
    "planning.enrichment.artifacts.retention": "Retention policy for stage artifacts.",
    "planning.enrichment.artifacts.retention.max_files": ("Max artifacts to retain."),
    # ==========================================================================
    # Derivation - Hierarchical Planning
    # ==========================================================================
    "derivation": "Derivation engine settings for structured plan generation.",
    "derivation.hierarchy": "Hierarchical derivation settings (epic/story/task/subtask).",
    "derivation.hierarchy.task.max_files": (
        "Maximum estimated files touched per task before triggering validation violations."
    ),
    "derivation.hierarchy.task.max_loc": (
        "Maximum estimated LOC per task before triggering validation violations."
    ),
    "derivation.hierarchy.task.max_words": (
        "Maximum estimated words per task before triggering validation violations."
    ),
    "derivation.hierarchy.subtask.max_files": (
        "Maximum estimated files touched per subtask before triggering validation violations."
    ),
    "derivation.hierarchy.subtask.max_loc": (
        "Maximum estimated LOC per subtask before triggering validation violations."
    ),
    "derivation.hierarchy.subtask.max_words": (
        "Maximum estimated words per subtask before triggering validation violations."
    ),
    "derivation.hierarchy.validation": "Validation gating for hierarchical derivation.",
    "derivation.hierarchy.validation.max_passes": (
        "Maximum re-prompt attempts per hierarchy level when validation fails."
    ),
    "derivation.hierarchy.validation.block_on_fail": (
        "Block derivation and raise an error when validation violations persist."
    ),
    "planning.enrichment.analogue_cache": "Project-scoped analogue replay settings for expert guidance.",
    "planning.enrichment.analogue_cache.global_path": (
        "Legacy shared analogue cache path. Set to null to disable cross-project replay."
    ),
    "planning.enrichment.analogue_cache.project_path": ("Project-scoped analogue cache path."),
    "planning.enrichment.analogue_cache.max_entries": (
        "Maximum number of recent project analogue entries to retain and replay."
    ),
    "planning.enrichment.analogue_cache.max_render_tokens": (
        "Approximate token budget for rendered project analogue replay in prompts."
    ),
    "planning.enrichment.telemetry": "Telemetry output settings for enrichment runs.",
    "planning.enrichment.telemetry.enabled": "Enable local telemetry logging.",
    "planning.enrichment.telemetry.include_content": (
        "Include raw model outputs in telemetry logs."
    ),
    "planning.enrichment.telemetry.output_path": "Telemetry JSONL output path.",
    "planning.intent_alignment": "Intent alignment QA settings for derived epics/stories.",
    "planning.intent_alignment.model_tier": (
        "Model tier for intent alignment QA (fast/medium/high)."
    ),
    "planning.intent_alignment.reasoning_level": ("Reasoning level for intent alignment QA."),
    "planning.intent_alignment.max_passes": "Max attempts for intent alignment QA.",
    "planning.intent_alignment.timeout_s": (
        "Timeout in seconds for intent alignment QA. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "planning.intent_alignment.block_on_fail": (
        "Block derivation when intent alignment fails (coverage_status=fail)."
    ),
    "planning.intent_alignment.max_concurrent": (
        "Parallel workers for per-story intent alignment checks (1-8). "
        "Higher values speed up intent coverage verification but may hit rate limits."
    ),
    "planning.intent_gap_check": "Post-execution intent gap check settings.",
    "planning.intent_gap_check.story_enabled": "Enable story-level gap checks.",
    "planning.intent_gap_check.epic_enabled": "Enable epic-level gap checks.",
    "planning.intent_gap_check.auto_append": (
        "Auto-append follow-up stories when gaps are detected."
    ),
    "planning.intent_gap_check.max_new_stories": (
        "Maximum number of follow-up stories to append per epic."
    ),
    "planning.intent_gap_check.model_tier": (
        "Model tier for intent gap checks (fast/medium/high)."
    ),
    "planning.intent_gap_check.reasoning_level": ("Reasoning level for intent gap checks."),
    "planning.intent_gap_check.max_passes": "Max attempts for intent gap checks.",
    "planning.intent_gap_check.timeout_s": (
        "Timeout in seconds for intent gap checks. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "planning.intent_gap_check.artifacts_dir": ("Directory for intent gap report artifacts."),
    "orchestration.domain": (
        "Default runtime domain for new runs, derivations, and workflow launches. "
        "This is the configured default and may be overridden per run with --domain."
    ),
    # ==========================================================================
    # Local Settings
    # ==========================================================================
    # ==========================================================================
    # Orchestration Settings - Timeouts
    # ==========================================================================
    "orchestration": "Orchestration settings for workflow execution and agent management.",
    "orchestration.prompts": "Prompt file retention and cleanup settings.",
    "orchestration.prompts.retain": (
        "Keep prompt files on disk after execution for debugging. Default: false."
    ),
    "orchestration.prompts.max_files": (
        "Maximum prompt files to retain (used by explicit cleanup command). Default: 200."
    ),
    "orchestration.prompts.cleanup_age_hours": (
        "Age threshold in hours for prompt file cleanup. Default: 24."
    ),
    "orchestration.timeouts.llm_call_s": (
        "Canonical baseline timeout in seconds for individual LLM calls. "
        "Child timeout settings may override it; null child values inherit this baseline."
    ),
    "orchestration.timeouts.llm_request_s": (
        "Optional timeout override in seconds for API-style single-call LLM requests. "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "orchestration.template_retention": (
        "Retention policy for template-edit JSON outputs (ADR-063)."
    ),
    "orchestration.template_retention.keep_on_success": (
        "Keep template files after successful validation. Default: false."
    ),
    "orchestration.template_retention.keep_on_error": (
        "Keep template files when validation fails for debugging. Default: true."
    ),
    "orchestration.timeouts": "Timeout configurations for various orchestration operations.",
    "orchestration.timeouts.agent_execution_s": (
        "Timeout in seconds for agent execution (execute and fix handlers). "
        "Controls how long Obra waits for agent task completion. "
        "Can be overridden with OBRA_AGENT_EXECUTION_TIMEOUT environment variable. "
        "Default: 5400 (90 minutes)."
    ),
    "orchestration.timeouts.review_agent_s": (
        "Timeout in seconds for review agents (security, testing, code quality, documentation). "
        "Controls how long each review agent runs before timing out. "
        "Can be overridden with OBRA_REVIEW_AGENT_TIMEOUT environment variable. "
        "Default: 1800 (30 minutes)."
    ),
    "orchestration.timeouts.cli_runner_s": (
        "Timeout in seconds for CLI LLM runner when no explicit timeout is provided. "
        "Fallback timeout for LLM operations via CLI. "
        "Default: 7200 (120 minutes)."
    ),
    "orchestration.timeouts.llm_stream_idle_s": (
        "Idle timeout in seconds for streaming LLM output. "
        "If no stdout/stderr arrives within this window, the subprocess is terminated "
        "and retried. Set to 0 to disable. This is the general idle guard, not the "
        "adaptive decomposition control surface for execute mode. Default: 300."
    ),
    # ==========================================================================
    # Orchestration Settings - Adaptive Decomposition
    # ==========================================================================
    "orchestration.decomposition": (
        "Adaptive task decomposition controls for execute duration, review non-convergence, "
        "and repeated execution failures."
    ),
    "orchestration.decomposition.enabled": (
        "Enable adaptive decomposition routing. Legacy orchestration.auto_decompose_on_timeout "
        "remains a compatibility alias. Default: true."
    ),
    "orchestration.decomposition.duration_threshold_s": (
        "Elapsed execute time before adaptive decomposition is triggered. "
        "Can be overridden with OBRA_DECOMPOSE_DURATION_S. "
        "Default: 1800 (30 minutes)."
    ),
    "orchestration.decomposition.warning_threshold_ratio": (
        "Derived warning ratio used when warning_threshold_s is unset. "
        "Can be overridden with OBRA_DECOMPOSE_WARNING_RATIO. "
        "Default: 0.8."
    ),
    "orchestration.decomposition.warning_threshold_s": (
        "Elapsed execute time before emitting a decomposition warning. "
        "Can be overridden with OBRA_DECOMPOSE_WARNING_S. "
        "When unset, Obra derives it as duration_threshold_s * warning_threshold_ratio. "
        "Default: null -> derived."
    ),
    "orchestration.decomposition.execute_stream_idle_s": (
        "Execute-mode stream idle timeout in seconds. This guard must be 0 or greater "
        "than or equal to orchestration.decomposition.duration_threshold_s so "
        "duration-based decomposition can fire first. When unset, Obra uses "
        "duration_threshold_s. Default: null -> derived."
    ),
    "orchestration.decomposition.failure_threshold": (
        "Consecutive same-item execution failures before the server routes to decomposition. "
        "Legacy derivation.auto_decompose.failure_threshold remains a compatibility alias. "
        "Default: 3."
    ),
    "orchestration.decomposition.max_attempts": (
        "Maximum decomposition attempts per task before escalation. Default: 2."
    ),
    "orchestration.decomposition.summary_max_chars": (
        "Maximum characters stored for partial work summaries. Default: 2000."
    ),
    # ==========================================================================
    # Orchestration Settings - Progress Visibility
    # ==========================================================================
    "orchestration.progress": "Progress visibility settings for execution monitoring.",
    "orchestration.progress.heartbeat_interval_s": (
        "Interval in seconds between heartbeat progress messages during agent execution. "
        "Automatically scaled by verbosity: QUIET (3x), PROGRESS (1x), DETAIL (0.5x). "
        "Can be overridden with OBRA_HEARTBEAT_INTERVAL environment variable. "
        "Default: 60 seconds."
    ),
    "orchestration.progress.heartbeat_initial_delay_s": (
        "Delay in seconds before first heartbeat message is shown. "
        "Prevents noise for quick tasks. Set to 0 for immediate heartbeat visibility. "
        "Can be overridden with OBRA_HEARTBEAT_INITIAL_DELAY environment variable. "
        "Default: 30 seconds."
    ),
    # ==========================================================================
    # Orchestration Settings - Quality Gates (ADR-068)
    # ==========================================================================
    "orchestration.quality": "Quality gate thresholds for review scoring.",
    "orchestration.quality.pass_threshold": (
        "Minimum score to pass quality gate (default: 0.7). "
        "Scores at or above this threshold result in PASS decision."
    ),
    "orchestration.quality.warn_threshold": (
        "Minimum score before warning (default: 0.5). "
        "Scores below pass but at or above this threshold result in WARN decision."
    ),
    # ==========================================================================
    # Orchestration Settings - Content Limits (ADR-068)
    # ==========================================================================
    "orchestration.content": (
        "Content truncation settings derived from model context windows. "
        "Used by ContentChunker for safe content sizing."
    ),
    "orchestration.content.safety_margin": (
        "Fraction of context window to use (default: 0.8). "
        "Reserves headroom for system prompts and response tokens."
    ),
    "orchestration.content.chars_per_token": (
        "Average characters per token estimate (default: 4). "
        "Used to convert token limits to character limits."
    ),
    "orchestration.content.preserve_ends": (
        "Keep start and end when truncating (default: true). "
        "When true, preserves context from both ends with middle truncation marker."
    ),
    # ==========================================================================
    # Orchestration Settings - Resilience Policies (ADR-068)
    # ==========================================================================
    "orchestration.resilience": (
        "Handler-specific retry and timeout policies. "
        "Loaded via ResiliencePolicy.for_handler(name)."
    ),
    "orchestration.resilience.default": ("Default resilience policy for unspecified handlers."),
    "orchestration.resilience.default.max_retries": (
        "Maximum retry attempts (default: 3). "
        "Number of times to retry a failed operation before giving up."
    ),
    "orchestration.resilience.default.base_delay_s": (
        "Initial backoff delay in seconds (default: 1.0). "
        "Starting delay between retries, used with backoff strategy."
    ),
    "orchestration.resilience.default.max_delay_s": (
        "Maximum backoff delay in seconds (default: 60.0). "
        "Upper bound on delay regardless of backoff calculation."
    ),
    "orchestration.resilience.default.timeout_window_s": (
        "Total timeout window in seconds (default: 3600). "
        "Maximum time to spend on all retry attempts combined."
    ),
    "orchestration.resilience.derive": (
        "Resilience policy for derivation handler (planning phase)."
    ),
    "orchestration.resilience.derive.max_retries": (
        "Maximum retry attempts for derivation (default: 5)."
    ),
    "orchestration.resilience.derive.base_delay_s": (
        "Initial backoff delay for derivation (default: 1.0)."
    ),
    "orchestration.resilience.derive.max_delay_s": (
        "Maximum backoff delay for derivation (default: 60.0)."
    ),
    "orchestration.resilience.derive.timeout_window_s": (
        "Total timeout window for derivation (default: 900)."
    ),
    "orchestration.resilience.fix": ("Resilience policy for fix handler (issue resolution phase)."),
    "orchestration.resilience.fix.max_retries": ("Maximum retry attempts for fix (default: 3)."),
    "orchestration.resilience.fix.base_delay_s": ("Initial backoff delay for fix (default: 1.0)."),
    "orchestration.resilience.fix.max_delay_s": ("Maximum backoff delay for fix (default: 60.0)."),
    "orchestration.resilience.fix.timeout_window_s": (
        "Total timeout window for fix (default: 600)."
    ),
    # ==========================================================================
    # Orchestration Settings - Parallel Worker Staggering
    # ==========================================================================
    "orchestration.parallel": (
        "Parallel worker staggering to avoid provider rate limit exhaustion. "
        "Applies across all pipeline phases (derivation, intent alignment, review agents)."
    ),
    "orchestration.parallel.worker_delay_s": (
        "Default delay (seconds) between starting each parallel worker. "
        "Prevents rate limit exhaustion when dispatching multiple concurrent LLM calls. "
        "Set to 0 to disable staggering. Can be overridden per-provider or via "
        "OBRA_PARALLEL_WORKER_DELAY_S env var. Default: 1.0. "
        "DEPRECATED: Rate limiting is now handled by orchestration.governor. This setting is "
        "used as fallback when governor config is absent."
    ),
    "orchestration.parallel.provider_overrides": (
        "Per-provider delay overrides (seconds). Providers with tighter rate limits "
        "(e.g., Gemini free tier) can use longer delays without affecting other providers. "
        "DEPRECATED: Rate limiting is now handled by orchestration.governor. This setting is "
        "used as fallback when governor config is absent."
    ),
    "orchestration.parallel.provider_overrides.google": (
        "Override delay for Google Gemini API. Gemini free tier has tight RPM limits "
        "(~2-5 RPM), so a longer delay is recommended. Default: 10.0."
    ),
    # ==========================================================================
    # Orchestration Settings - LLM Concurrency Governor
    # ==========================================================================
    "orchestration.governor": (
        "Process-wide LLM concurrency governor. Centrally enforces per-provider concurrency "
        "limits and cooldown spacing, replacing scattered worker_delay_s stagger mechanisms. "
        "Instrumented at run_llm_subprocess() and LLMInvoker.invoke/invoke_stream()."
    ),
    "orchestration.governor.enabled": (
        "Master switch for process-wide LLM concurrency governance. "
        "When false, all permits are no-ops (NullGovernor). Default: true."
    ),
    "orchestration.governor.max_concurrent_calls": (
        "Maximum concurrent LLM API calls across all providers. "
        "Per-provider overrides take precedence when set. Default: 6."
    ),
    "orchestration.governor.cooldown_s": (
        "Minimum seconds between consecutive calls to the same provider. "
        "Per-provider overrides take precedence when set. Default: 0.5."
    ),
    "orchestration.governor.cooldown_jitter": (
        "Randomization factor applied to per-provider cooldown delays. "
        "A value of 0.15 means each cooldown is randomized by +/-15%, "
        "preventing exact-interval call patterns. Default: 0.15."
    ),
    "orchestration.governor.pacing_s": (
        "Global minimum seconds between any two LLM calls, regardless of provider. "
        "Acts as a defensive floor against tight request loops that could strain "
        "provider APIs or local resources. Set to 0 to disable. Default: 5.0."
    ),
    "orchestration.governor.pacing_jitter": (
        "Randomization factor applied to the global pacing delay. "
        "A value of 0.3 means each pacing delay is randomized by +/-30% "
        "(e.g., 5.0s pacing becomes 3.5-6.5s effective range). Default: 0.3."
    ),
    "orchestration.governor.acquire_timeout_s": (
        "Maximum seconds to wait for a permit before raising TimeoutError. "
        "Prevents indefinite blocking when all slots are held. Default: 120."
    ),
    "orchestration.governor.providers.anthropic.max_concurrent_calls": (
        "Maximum concurrent calls to Anthropic Claude API. Default: 8."
    ),
    "orchestration.governor.providers.anthropic.cooldown_s": (
        "Minimum seconds between consecutive Anthropic Claude calls. Default: 0.2."
    ),
    "orchestration.governor.providers.openai.max_concurrent_calls": (
        "Maximum concurrent calls to OpenAI API. Default: 8."
    ),
    "orchestration.governor.providers.openai.cooldown_s": (
        "Minimum seconds between consecutive OpenAI calls. Default: 0.2."
    ),
    "orchestration.governor.providers.google.max_concurrent_calls": (
        "Maximum concurrent calls to Google Gemini API. "
        "Gemini free tier has tight RPM limits (~2-5 RPM). Default: 2."
    ),
    "orchestration.governor.providers.google.cooldown_s": (
        "Minimum seconds between consecutive Google Gemini calls. "
        "Gemini free tier requires long delays between calls. Default: 10.0."
    ),
    "orchestration.governor.providers.ollama.max_concurrent_calls": (
        "Maximum concurrent calls to local Ollama models. Default: 2."
    ),
    "orchestration.governor.providers.ollama.cooldown_s": (
        "Minimum seconds between consecutive Ollama calls. "
        "Local models have no rate limit — default is 0.0."
    ),
    # ==========================================================================
    # Execution Settings
    # ==========================================================================
    "execution": "Execution settings for DerivedPlan items.",
    "execution.parallel": "Parallel execution settings for DerivedPlan items.",
    "execution.parallel.enabled": (
        "Enable parallel execution of DerivedPlan items when --parallel is used. Default: false."
    ),
    "execution.parallel.max_workers": (
        "Maximum number of concurrent workers for parallel execution. Default: 4."
    ),
    # ==========================================================================
    # Orchestration Settings - Session Watchdog (ISSUE-HYBRID-003)
    # ==========================================================================
    "orchestration.watchdog": "Session stall detection settings.",
    "orchestration.watchdog.enabled": (
        "Enable session stall detection. When enabled, monitors for sessions that "
        "make no progress (no events logged) while no LLM subprocess is active. "
        "Default: true."
    ),
    "orchestration.watchdog.stall_timeout_s": (
        "Seconds of no events before a session is considered stalled. "
        "Only triggers when no LLM subprocess is active (LLM calls have their own monitoring). "
        "Increase for slow network environments. "
        "Default: 300 (5 minutes)."
    ),
    # ==========================================================================
    # Orchestration Settings - Interactive Guard
    # ==========================================================================
    "orchestration.interactive_guard": (
        "Interactive command guard settings for detecting and blocking prompts."
    ),
    "orchestration.interactive_guard.enabled": (
        "Enable interactive prompt detection on LLM subprocess output. Default: true."
    ),
    "orchestration.interactive_guard.patterns": (
        "List of regex patterns used to detect interactive shell prompts. "
        "Matched lines trigger LLM_INTERACTIVE_BLOCKED. "
        "Default: curated list for password/confirmation prompts."
    ),
    "orchestration.interactive_guard.retry_max": (
        "Maximum retries after interactive guard triggers. Default: 1."
    ),
    "orchestration.interactive_guard.rollback": ("Rollback policy for interactive guard triggers."),
    "orchestration.interactive_guard.rollback.enabled": (
        "Restore workspace snapshot when a rollback-triggered error occurs. Default: true."
    ),
    "orchestration.interactive_guard.rollback.trigger_codes": (
        "Error codes that trigger rollback + retry in handlers. "
        "Default: ['LLM_INTERACTIVE_BLOCKED']."
    ),
    # ==========================================================================
    # Development Debug Settings (FEAT-DEV-DEBUG)
    # ==========================================================================
    "features.development_debug": "Development and debug feature flags.",
    "features.development_debug.enabled": (
        "Master toggle for development debug features. Default: false."
    ),
    "features.development_debug.debug_features": "Individual debug feature toggles.",
    "features.development_debug.debug_features.debug_mode": (
        "Enable debug mode for verbose internal logging. Default: false."
    ),
    "features.development_debug.debug_features.verbose_logging": (
        "Enable extra-verbose debug logging output. Default: false."
    ),
    "features.development_debug.debug_features.save_interactions": (
        "Persist all LLM request/response pairs for debugging. Default: false."
    ),
    "features.development_debug.debug_features.audit_logging": (
        "Log destructive operations for audit trail. Default: false."
    ),
    "features.development_debug.breakpoints": "Fail-safe intervention point settings.",
    "features.development_debug.breakpoints.enabled": (
        "Enable fail-safe intervention points during execution. Default: false."
    ),
    "features.development_debug.breakpoints.triggers": ("Conditions that trigger breakpoints."),
    "features.development_debug.breakpoints.triggers.validation_failed": (
        "Break on validation failures. Default: true."
    ),
    "features.development_debug.breakpoints.triggers.rate_limit_hit": (
        "Break on LLM rate limit errors. Default: true."
    ),
    "features.development_debug.breakpoints.triggers.unexpected_error": (
        "Break on unexpected errors. Default: true."
    ),
    "features.development_debug.monitoring": "Monitoring feature toggles.",
    "features.development_debug.monitoring.file_watcher": (
        "Monitor file system changes during execution (CLI only). Default: false."
    ),
    "features.development_debug.monitoring.output_monitor": (
        "Monitor agent output streams during execution. Default: false."
    ),
    "features.development_debug.production_logging": "Production logging settings.",
    "features.development_debug.production_logging.enabled": (
        "Always-on structured logging for production diagnostics. Default: false."
    ),
    # ==========================================================================
    # Auth Display Fields (read-only)
    # ==========================================================================
    # ==========================================================================
    # Server Settings - Features
    # ==========================================================================
    "features": "Feature flags and capabilities that can be enabled or disabled.",
    "features.performance_control": "Performance and resource management settings.",
    "features.performance_control.budgets": "Unified budget control for orchestration sessions.",
    "features.performance_control.budgets.enabled": (
        "Enable unified budget control for orchestration sessions. "
        "When enabled, Obra tracks time, iteration, token, and progress budgets. "
        "Sessions pause when budgets are exceeded, preventing runaway costs."
    ),
    "features.quality_automation": "Quality automation tools and agents.",
    "features.quality_automation.enabled": (
        "Master toggle for quality automation features. "
        "When disabled, all quality automation agents are inactive regardless of individual settings."
    ),
    "features.quality_automation.agents": "Specialized agents for automated tasks.",
    "features.quality_automation.agents.security_audit": "Security audit agent settings.",
    "features.quality_automation.agents.security_audit.enabled": (
        "Enable automatic security vulnerability scanning. "
        "Runs OWASP Top 10 checks on code changes. "
        "Recommended for production codebases."
    ),
    "features.quality_automation.agents.security_audit.llm.provider": "LLM provider override for the security audit agent.",
    "features.quality_automation.agents.security_audit.llm.model": "Optional explicit model override for the security audit agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.security_audit.llm.model_tier": "Model tier override for the security audit agent.",
    "features.quality_automation.agents.security_audit.llm.reasoning_level": "Reasoning level override for the security audit agent.",
    "features.quality_automation.agents.rca_agent": "Root cause analysis agent settings.",
    "features.quality_automation.agents.rca_agent.enabled": (
        "Enable root cause analysis agent. "
        "Automatically investigates test failures, errors, and unexpected behavior. "
        "Provides detailed analysis reports."
    ),
    "features.quality_automation.agents.rca_agent.llm.provider": "LLM provider override for the root cause analysis agent.",
    "features.quality_automation.agents.rca_agent.llm.model": "Optional explicit model override for the root cause analysis agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.rca_agent.llm.model_tier": "Model tier override for the root cause analysis agent.",
    "features.quality_automation.agents.rca_agent.llm.reasoning_level": "Reasoning level override for the root cause analysis agent.",
    "features.quality_automation.agents.doc_audit": "Documentation audit agent settings.",
    "features.quality_automation.agents.doc_audit.enabled": (
        "Enable documentation audit agent. "
        "Checks documentation for accuracy, completeness, and staleness. "
        "Uses ROT methodology (Redundant, Outdated, Trivial)."
    ),
    "features.quality_automation.agents.doc_audit.llm.provider": "LLM provider override for the documentation audit agent.",
    "features.quality_automation.agents.doc_audit.llm.model": "Optional explicit model override for the documentation audit agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.doc_audit.llm.model_tier": "Model tier override for the documentation audit agent.",
    "features.quality_automation.agents.doc_audit.llm.reasoning_level": "Reasoning level override for the documentation audit agent.",
    "features.quality_automation.agents.test_generation": "Test generation agent settings.",
    "features.quality_automation.agents.test_generation.enabled": (
        "Enable test generation agent. "
        "Creates or updates tests based on code changes and objectives."
    ),
    "features.quality_automation.agents.test_generation.llm.provider": "LLM provider override for the test generation agent.",
    "features.quality_automation.agents.test_generation.llm.model": "Optional explicit model override for the test generation agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.test_generation.llm.model_tier": "Model tier override for the test generation agent.",
    "features.quality_automation.agents.test_generation.llm.reasoning_level": "Reasoning level override for the test generation agent.",
    "features.quality_automation.agents.test_execution": "Test execution agent settings.",
    "features.quality_automation.agents.test_execution.enabled": (
        "Enable test execution agent. Runs relevant test suites during review and verification."
    ),
    "features.quality_automation.agents.test_execution.llm.provider": "LLM provider override for the test execution agent.",
    "features.quality_automation.agents.test_execution.llm.model": "Optional explicit model override for the test execution agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.test_execution.llm.model_tier": "Model tier override for the test execution agent.",
    "features.quality_automation.agents.test_execution.llm.reasoning_level": "Reasoning level override for the test execution agent.",
    "features.quality_automation.agents.code_review": "Code review agent settings.",
    "features.quality_automation.agents.code_review.enabled": (
        "Enable automatic code review agent. "
        "Reviews code changes for best practices, potential issues, and style consistency."
    ),
    "features.quality_automation.agents.code_review.llm.provider": "LLM provider override for the code review agent.",
    "features.quality_automation.agents.code_review.llm.model": "Optional explicit model override for the code review agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.code_review.llm.model_tier": "Model tier override for the code review agent.",
    "features.quality_automation.agents.code_review.llm.reasoning_level": "Reasoning level override for the code review agent.",
    "features.quality_automation.agents.sense_check": "SenseCheck agent settings.",
    "features.quality_automation.agents.sense_check.enabled": (
        "Enable SenseCheck semantic validation agent (opt-in). "
        "Validates root cause accuracy, detects band-aid fixes, and flags brittle patterns."
    ),
    "features.quality_automation.agents.sense_check.llm.provider": "LLM provider override for the SenseCheck agent.",
    "features.quality_automation.agents.sense_check.llm.model": "Optional explicit model override for the SenseCheck agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.sense_check.llm.model_tier": "Model tier override for the SenseCheck agent.",
    "features.quality_automation.agents.sense_check.llm.reasoning_level": "Reasoning level override for the SenseCheck agent.",
    "features.quality_automation.agents.code_verify": "CodeVerify agent settings.",
    "features.quality_automation.agents.code_verify.enabled": (
        "Enable CodeVerify plan/code validation. "
        "Runs post-derivation and as Story Pre-flight to validate plans against source code."
    ),
    "features.quality_automation.agents.code_verify.llm.provider": "LLM provider override for the CodeVerify agent.",
    "features.quality_automation.agents.code_verify.llm.model": "Optional explicit model override for the CodeVerify agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.code_verify.llm.model_tier": "Model tier override for the CodeVerify agent.",
    "features.quality_automation.agents.code_verify.llm.reasoning_level": "Reasoning level override for the CodeVerify agent.",
    "features.quality_automation.agents.escalation_fixer": "Escalation fixer agent settings.",
    "features.quality_automation.agents.escalation_fixer.enabled": (
        "Enable the dedicated LLM tier used for bounded pre-escalation recovery analysis."
    ),
    "features.quality_automation.agents.escalation_fixer.llm.provider": "LLM provider override for the escalation fixer agent.",
    "features.quality_automation.agents.escalation_fixer.llm.model": "Optional explicit model override for the escalation fixer agent. Leave this unset to follow normal role/provider defaults.",
    "features.quality_automation.agents.escalation_fixer.llm.model_tier": "Model tier override for the escalation fixer agent.",
    "features.quality_automation.agents.escalation_fixer.llm.reasoning_level": "Reasoning level override for the escalation fixer agent.",
    "features.quality_automation.agents.ignore_patterns": (
        "Glob patterns or directory names to exclude from agent file scanning. "
        "Use short names to match any path component (e.g., 'logs', 'research')."
    ),
    # Agent shortcuts (UX-CONFIG-001)
    "agents.sense_check": "Enable SenseCheck semantic validation agent (opt-in)",
    "agents.code_verify": "Enable CodeVerify plan/code validation agent",
    # Alternative paths for quality_automation features (direct placement in some configs)
    "features.advanced_planning": "Advanced planning capabilities.",
    "features.advanced_planning.enabled": (
        "Enable advanced planning features. "
        "Includes derivative plan architecture and enhanced task breakdown capabilities."
    ),
    "features.userplan": "UserPlan pipeline feature flags.",
    "features.userplan.intent_alignment": "Intent alignment QA controls for derived plans.",
    "features.userplan.intent_alignment.enabled": (
        "Run epic/story intent alignment QA during derivation."
    ),
    "features.userplan.intent_gap_check": "Post-execution intent gap check controls.",
    "features.userplan.intent_gap_check.enabled": (
        "Run story/epic intent gap checks after execution."
    ),
    "features.documentation_governance": "Documentation governance settings.",
    "features.documentation_governance.enabled": (
        "Enable documentation governance (DG-001). "
        "Keeps documentation synchronized with code through INDEX.yaml coupling."
    ),
    "features.user_experience": "User experience and interactive CLI settings.",
    "features.user_experience.enabled": (
        "Enable user experience features like clarification and dashboard output."
    ),
    "features.user_experience.dashboard": "CLI dashboard display settings.",
    "features.user_experience.dashboard.enabled": ("Master toggle for CLI dashboard UI elements."),
    "features.user_experience.dashboard.footer_hint": (
        "Show the Ctrl+C footer hint with resume instructions."
    ),
    "features.user_experience.dashboard.task_tracker": (
        "Show a task tracker with current and upcoming plan items."
    ),
    "features.user_experience.dashboard.task_tracker_max_next": (
        "Maximum number of upcoming tasks to display in the tracker."
    ),
    "features.test_generation.requirements_driven.enabled": (
        "Enable the requirements-driven acceptance-test generation workflow before derivation. Default: false."
    ),
    "features.test_generation.requirements_driven.brownfield_index.enabled": (
        "Build a brownfield test index so generated tests follow the repository's existing test conventions. Default: true."
    ),
    "features.test_generation.requirements_driven.brownfield_index.cache_ttl_hours": (
        "How long to reuse the brownfield test index cache before rebuilding it from the workspace. Default: 24."
    ),
    "features.test_generation.requirements_driven.closeout_epic.enabled": (
        "Inject closeout plan items that rerun generated acceptance tests, the broader test suite, and intent-alignment validation before completion. Default: true."
    ),
    "features.test_generation.requirements_driven.closeout_epic.remediation_max_cycles": (
        "Maximum number of remediation derive cycles triggered by failed closeout gates before escalation. Default: 2."
    ),
    "features.test_generation.requirements_driven.closeout_epic.intent_alignment_gate": (
        "How strictly closeout treats intent-alignment mismatches for requirements-driven work. Typical values: warn or fail. Default: warn."
    ),
    # ==========================================================================
    # Server Settings - Presets
    # ==========================================================================
    # ==========================================================================
    # Advanced Settings (additional entries)
    # ==========================================================================
    # ==========================================================================
    # Review - SenseCheck Agent (FEAT-SENSECHECK-001)
    # ==========================================================================
    "review.sense_check": "SenseCheck agent configuration for semantic validation.",
    "review.sense_check.enabled": "Master toggle for SenseCheck agent",
    "review.sense_check.enhancement": "Optional post-processing of SenseCheck findings.",
    "review.sense_check.enhancement.enabled": "Enable report enhancement pass",
    "review.sense_check.enhancement.timeout_s": "Timeout for enhancement LLM call (seconds)",
    "review.sense_check.sequencer": "Fix ordering sequencer for dependency-aware fixes.",
    "review.sense_check.sequencer.enabled": "Enable fix ordering sequencer",
    "review.sense_check.sequencer.mode": "Sequencer mode: llm (LLM-based) or rules (rule-based)",
    "review.sense_check.sequencer.model_tier": "Model tier for sequencer LLM calls",
    "review.sense_check.sequencer.timeout_s": "Timeout for sequencer LLM call (seconds)",
    "review.sense_check.sequencer.fallback_to_rules": "Fall back to rule-based if LLM fails",
    "review.sense_check.pipeline": "SenseCheck pipeline integration settings.",
    "review.sense_check.pipeline.framework": "Validator framework configuration for SenseCheck.",
    "review.sense_check.pipeline.framework.enabled": (
        "Enable validator framework for stage-aware validation"
    ),
    "review.sense_check.pipeline.framework.decision_log": (
        "Persist validator decision logs for auditability"
    ),
    "review.sense_check.pipeline.framework.conflict_policy": (
        "Conflict policy for multiple validator decisions: priority_wins or first_wins"
    ),
    "review.sense_check.pipeline.framework.ordering": (
        "Validator ordering by stage for the framework"
    ),
    "review.sense_check.pipeline.framework.ordering.intent": (
        "Validator ordering for intent validation stage"
    ),
    "review.sense_check.pipeline.framework.ordering.plan": (
        "Validator ordering for plan validation stage"
    ),
    "review.sense_check.pipeline.framework.ordering.review_filter": (
        "Validator ordering for review filter stage"
    ),
    "review.sense_check.pipeline.framework.schema_validation": (
        "Validate validator payloads against shared schema"
    ),
    "review.sense_check.pipeline.framework.prompt_provenance": (
        "Require prompt provenance fields for validator requests"
    ),
    "review.sense_check.pipeline.intent": "Intent-stage SenseCheck validation settings.",
    "review.sense_check.pipeline.intent.enabled": (
        "Validate intent before derivation to catch overengineering"
    ),
    "review.sense_check.pipeline.intent.timeout_s": ("Timeout for intent validation (seconds)"),
    "review.sense_check.pipeline.intent.model_tier": ("Model tier for intent validation LLM calls"),
    "review.sense_check.pipeline.plan": "Plan-stage SenseCheck validation settings.",
    "review.sense_check.pipeline.plan.enabled": (
        "Validate plan after derivation to simplify bloated plans"
    ),
    "review.sense_check.pipeline.plan.timeout_s": "Timeout for plan validation (seconds)",
    "review.sense_check.pipeline.plan.model_tier": ("Model tier for plan validation LLM calls"),
    "review.sense_check.pipeline.plan.auto_revise": (
        "Automatically trigger revision when plan issues are found"
    ),
    "review.sense_check.pipeline.plan.auto_revise_threshold": (
        "Minimum issue priority to trigger auto-revision (P0-P3)"
    ),
    "review.sense_check.pipeline.plan.max_revision_attempts": (
        "Maximum auto-revision attempts before escalation"
    ),
    "review.sense_check.pipeline.review_filter": (
        "Review filter SenseCheck settings for agent report filtering."
    ),
    "review.sense_check.pipeline.review_filter.enabled": (
        "Filter review agent reports to remove false positives"
    ),
    "review.sense_check.pipeline.review_filter.timeout_s": (
        "Timeout for review filter validation (seconds)"
    ),
    "review.sense_check.pipeline.review_filter.model_tier": (
        "Model tier for review filter LLM calls"
    ),
    "review.sense_check.pipeline.review_filter.remove_false_positives": (
        "Allow filter to remove false positive findings"
    ),
    "review.sense_check.pipeline.review_filter.adjust_severity": (
        "Allow filter to adjust issue severity levels"
    ),
    "review.escalation_fixer": "Bounded pre-escalation recovery routing settings.",
    "review.escalation_fixer.enabled": (
        "Enable the server-side escalation fixer gate before eligible human escalations"
    ),
    "review.escalation_fixer.timeout_s": (
        "Timeout for the escalation fixer validator call (seconds)"
    ),
    "review.escalation_fixer.max_attempts_per_episode": (
        "Maximum fixer attempts per escalation episode; V1 only allows one"
    ),
    "review.escalation_fixer.allowed_routes": (
        "Allowed bounded recovery routes the fixer may recommend"
    ),
    "review.escalation_fixer.eligible_reason_codes": (
        "Escalation reason codes that are eligible for one fixer attempt"
    ),
    # ==========================================================================
    # Fix - Delivery Mode (FEAT-SENSECHECK-001)
    # ==========================================================================
    "fix.delivery": "Fix delivery configuration.",
    "fix.delivery.mode": "Fix delivery mode: batch (all at once) or sequential (one at a time)",
    # ==========================================================================
    # Pipeline - Custom Stage Configuration (FEAT-PIPELINE-001)
    # ==========================================================================
    "pipeline": "Custom pipeline stage and runner-catalog configuration for inserting validation stages at trigger points.",
    "pipeline.json_conversion": (
        "Settings for Step 2 JSON template conversion in two-step pipeline stages."
    ),
    "pipeline.json_conversion.reasoning_level": (
        "Reasoning level for the JSON conversion step. This stays isolated from global LLM reasoning settings so schema filling remains mechanical."
    ),
    "pipeline.runner_catalog": "Runner catalog configuration for durable runner IDs, versions/selectors, and project-local overlays.",
    "pipeline.runner_catalog.project_overlay": "Project-local runner catalog layer. These entries define machine-local activation details and are not the durable workflow contract.",
    "pipeline.runner_catalog.project_overlay.entries": "Catalog-backed runner declarations for this project. Use shared scope for cross-domain runners, domain scope for explicit domain allowlists, portable for package-discovered runners, and local_only for workspace-specific factories or commands.",
    "pipeline.custom_stages": "List of custom stage definitions (see pipeline-configuration-guide.md). Stages should reference runner.runner_id plus runner_version or runner_selector as the durable contract.",
    "pipeline.defaults": "Default values for stage configuration.",
    "pipeline.defaults.max_iterations": "Maximum re-validate iterations per stage before escalation (default: 3).",
    "pipeline.defaults.timeout_s": "Default timeout per stage execution in seconds (default: 600; Obra enforces a 10-minute minimum).",
    # ==========================================================================
    # CLI Settings
    # ==========================================================================
    "cli": "Command-line interface settings (updates, retry behavior, cache monitoring).",
    "cli.check_for_updates": "Check PyPI for new Obra versions on startup (notification only).",
    "cli.update_notification_cooldown_minutes": "Minimum minutes between update notification banners.",
    "cli.auto_update": "Automatically install new Obra versions when behind.",
    "cli.auto_update_cooldown_minutes": "Minimum minutes between auto-update checks.",
    "cli.auto_update_max_retries": "Maximum upgrade attempts.",
    "cli.auto_update_retry_delay_s": "Base delay between retries in seconds (doubles each attempt).",
    "cli.auto_update_pipx_timeout_s": "Timeout per upgrade attempt in seconds.",
    # ==========================================================================
    # Handler Settings
    # ==========================================================================
    "handlers": "Handler-specific configuration for fix, derive, and preflight stages.",
    "handlers.fix": "Fix handler configuration for issue resolution.",
    "handlers.fix.parallel_enabled": (
        "Enable concurrent execution of disjoint file batches during fix passes. "
        "When true, batches targeting different files run in parallel via ParallelExecutor. "
        "Disabled by default. Override with OBRA_FIX_HANDLER_PARALLEL_ENABLED env var."
    ),
    "handlers.fix.parallel_workers": (
        "Maximum concurrent workers for parallel fix batch processing. "
        "Only used when handlers.fix.parallel_enabled is true. Default: 4. "
        "Override with OBRA_FIX_HANDLER_PARALLEL_WORKERS env var."
    ),
    "handlers.fix.doc_timeout_s": "Timeout for documentation generation during fix process (seconds).",
    "handlers.fix.max_retries": "Maximum retry attempts for fix operations. Default: 3.",
    "handlers.fix.min_file_size_bytes": "Minimum file size to process (bytes). Files below this threshold are skipped.",
    "handlers.fix.llm_suggestion_timeout_s": (
        "Timeout for LLM suggestion generation during fix (seconds). "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    "handlers.fix.llm_test_gap_timeout_s": (
        "Timeout for LLM test gap inference during fix (seconds). "
        "Set to null to inherit orchestration.timeouts.llm_call_s."
    ),
    # BEGIN FALLBACK CONFIG DESCRIPTIONS
    "advanced.logging.format": (
        "Python logging format string for advanced log output. Default: \"%(asctime)s - %(name)s - %(levelname)s - %(message)s\"."
    ),
    "agent.ssh.host": (
        "Hostname for the remote SSH target used by the agent bridge. Default: \"localhost\"."
    ),
    "agent.ssh.key_path": (
        "Private key path used for SSH authentication when connecting to the remote agent target. Default: \"~/.ssh/id_rsa\"."
    ),
    "agent.ssh.port": (
        "SSH port used for the remote agent connection. Default: 22."
    ),
    "agent.ssh.user": (
        "Username used for SSH connections to the remote agent target. Default: \"claude\"."
    ),
    "api.connection_pool.connections": (
        "Number of base HTTP connections kept ready in the API connection pool. Default: 10."
    ),
    "api.connection_pool.maxsize": (
        "Maximum total HTTP connections the API connection pool can open. Default: 10."
    ),
    "api.connection_pool.retry_backoff": (
        "Backoff multiplier, in seconds, between API connection retry attempts. Default: 0.5."
    ),
    "api.connection_pool.retry_connect": (
        "How many times the API client retries failed connection attempts. Default: 3."
    ),
    "api.connection_pool.retry_total": (
        "Total retry budget for transient API connection failures. Default: 3."
    ),
    "api.connection_pool.timeout_s": (
        "Socket timeout, in seconds, for API connection-pool operations. Default: 10."
    ),
    "api.limits.events": (
        "Per-request API cap for events. Default: 100."
    ),
    "api.limits.plans": (
        "Per-request API cap for plans. Default: 50."
    ),
    "api.limits.sessions": (
        "Per-request API cap for sessions. Default: 10."
    ),
    "api.limits.user_feedback": (
        "Per-request API cap for user feedback. Default: 20."
    ),
    "api.retry_delays_s": (
        "Backoff schedule, in seconds, between API retry attempts. Default: [1, 2, 4]."
    ),
    "api.timeouts.feedback_submission_s": (
        "How long feedback submission requests may run before timing out. Default: 60."
    ),
    "benchmark.repo_root": (
        "Repository root used for benchmark runs. Default: \"~/projects/Obra\"."
    ),
    "benchmark.dockerhub_username": (
        "Docker Hub namespace that hosts the SWE-bench Pro eval images for benchmark auto-eval and campaigns."
    ),
    "benchmark.eval_harness_dir": (
        "Filesystem path to the local SWE-bench Pro eval harness checkout used for benchmark validation runs."
    ),
    "benchmark.timeout_s": (
        "Maximum time allowed for a benchmark run before it is terminated. Default: 7200."
    ),
    "benchmark.workspace_directory": (
        "Workspace directory used for benchmark checkouts and scratch files. Default: \"~/swebench-workdir\"."
    ),
    "benchmark.remediation.result_root_directory": (
        "Root directory where benchmark remediation missions persist protocol, packets, plans, and verification artifacts. Default: \"~/swebench-workdir/remediation\"."
    ),
    "benchmark.remediation.repair_workspace_directory": (
        "Parent directory for isolated Obra repair workspaces created per remediation attempt. Default: \"~/swebench-workdir/remediation-repair-workspaces\"."
    ),
    "benchmark.remediation.default_workspace_mode": (
        "How a remediation repair workspace is materialized from the Obra checkout: \"copy\" duplicates files, \"link\" hard-links them. Default: \"copy\"."
    ),
    "benchmark.remediation.default_checkout_python": (
        "Python interpreter used inside the isolated repair workspace when reinstalling Obra and rerunning the benchmark target. Default: \"python\"."
    ),
    "benchmark.remediation.max_attempts": (
        "Maximum number of full remediation attempts (investigate → plan → patch → rerun) before the mission gives up. Default: 3."
    ),
    "benchmark.remediation.max_planning_rounds": (
        "Maximum number of planning rounds the remediation planner is allowed within a single attempt. Default: 2."
    ),
    "benchmark.remediation.max_patch_attempts": (
        "Maximum number of patch attempts the remediation worker may try to apply within a single attempt. Default: 2."
    ),
    "benchmark.remediation.max_no_improvement_attempts": (
        "Number of consecutive attempts with no benchmark improvement before the remediation loop halts as no-improvement. Default: 1."
    ),
    "benchmark.remediation.progress_poll_interval_s": (
        "Polling interval, in seconds, for refreshing persisted remediation progress while a benchmark run or rerun is still active. Default: 5."
    ),
    "benchmark.remediation.worker_timeout_s": (
        "Timeout, in seconds, for each remediation worker subprocess (planning, patching, rerun). Default: 600."
    ),
    "breakpoints.confirmation_timeout_seconds": (
        "How long Obra waits for a breakpoint confirmation before timing out. Default: 60 seconds."
    ),
    "breakpoints.triggers.rate_limit_hit.enabled": (
        "Pause at the rate-limit breakpoint when Obra hits provider or API throttling. Enabled by default."
    ),
    "breakpoints.triggers.unexpected_error.enabled": (
        "Pause at the unexpected-error breakpoint when an unhandled failure occurs. Enabled by default."
    ),
    "breakpoints.triggers.validation_failed.enabled": (
        "Pause at the validation-failed breakpoint when a required validation step fails. Enabled by default."
    ),
    "checkpoint_manager.triggers.event.enabled": (
        "Allow named events to trigger automatic checkpoints. Enabled by default."
    ),
    "checkpoint_manager.triggers.event.events": (
        "Event names that should trigger an automatic checkpoint. Default: [\"task_complete\", \"milestone_reached\", \"validation_pass\"]."
    ),
    "checkpoint_manager.triggers.operation.enabled": (
        "Allow operation-count thresholds to trigger automatic checkpoints. Enabled by default."
    ),
    "checkpoint_manager.triggers.operation.interval_operations": (
        "Create a checkpoint after this many operations when operation-based checkpointing is enabled. Default: 10."
    ),
    "checkpoint_manager.triggers.threshold.enabled": (
        "Allow context-usage thresholds to trigger automatic checkpoints. Enabled by default."
    ),
    "checkpoint_manager.triggers.threshold.percentage": (
        "Context-usage percentage that triggers an automatic checkpoint. Default: 0.7."
    ),
    "checkpoint_manager.triggers.time.enabled": (
        "Allow elapsed time to trigger automatic checkpoints. Enabled by default."
    ),
    "checkpoint_manager.triggers.time.interval_minutes": (
        "Minutes between time-based automatic checkpoints. Default: 15."
    ),
    "clarification.archive_path": (
        "Directory where archived clarification sessions are stored. Default: \"~/.obra-runtime/archives/clarifications\"."
    ),
    "config_version": (
        "Config schema version marker. Leave this alone unless a documented migration tells you to change it. Default: \"1\"."
    ),
    "connectors.credentials.key_path": (
        "Path to the machine key used to protect stored connector credentials. Default: \"~/.obra/.machine-key\"."
    ),
    "connectors.credentials.refresh_margin_s": (
        "Refresh connector credentials this many seconds before they expire. Default: 300 seconds."
    ),
    "connectors.credentials.store_path": (
        "Directory where connector credentials are stored locally. Default: \"~/.obra/credentials\"."
    ),
    "connectors.google_drive.oauth.authorize_url": (
        "Google OAuth authorization endpoint used to start the Drive login flow. Default: \"https://accounts.google.com/o/oauth2/v2/auth\"."
    ),
    "connectors.google_drive.oauth.credential_name": (
        "Credential record name used for the Google Drive connector. Default: \"google-drive\"."
    ),
    "connectors.google_drive.oauth.revoke_url": (
        "Google OAuth endpoint used to revoke stored Drive tokens. Default: \"https://oauth2.googleapis.com/revoke\"."
    ),
    "connectors.google_drive.oauth.scopes": (
        "Google Drive OAuth scopes requested during connector authorization. Default: [\"https://www.googleapis.com/auth/drive.file\"]."
    ),
    "connectors.google_drive.oauth.token_url": (
        "Google OAuth token endpoint used to exchange or refresh Drive tokens. Default: \"https://oauth2.googleapis.com/token\"."
    ),
    "context.prioritization": (
        "Priority order for keeping context when prompts need to be trimmed. Earlier entries win when the token budget is tight. Default order: [\"recent_interactions\", \"task_description\", \"relevant_files\", \"project_context\"]."
    ),
    "derivation.auto_derive_on_execute": (
        "Automatically derive a structured plan when execution starts from an underspecified request. Enabled by default."
    ),
    "derivation.hierarchy.enabled": (
        "Turn hierarchical Epic/Story/Task/Subtask derivation on or off. Enabled by default."
    ),
    "derivation.hierarchy.epic.max_per_objective": (
        "Maximum number of epics Obra may derive for a single objective. Default: 1."
    ),
    "derivation.hierarchy.story.max_per_epic": (
        "Maximum number of stories allowed under one epic. Default: 10."
    ),
    "derivation.hierarchy.story.max_tasks": (
        "Maximum number of tasks allowed inside one story. Default: 8."
    ),
    "derivation.hierarchy.story.require_closeout": (
        "Require derived stories to include an explicit close-out step. Enabled by default."
    ),
    "derivation.hierarchy.subtask.forbid_compound_titles": (
        "Reject subtask titles that bundle multiple actions into one item. Enabled by default."
    ),
    "derivation.hierarchy.subtask.max_acceptance_criteria": (
        "Maximum acceptance-criteria bullets allowed on a subtask. Default: 5."
    ),
    "derivation.hierarchy.subtask.max_description_words": (
        "Maximum subtask description length, in words. Default: 150."
    ),
    "derivation.hierarchy.subtask.max_per_task": (
        "Maximum number of subtasks allowed under one task. Default: 4."
    ),
    "derivation.hierarchy.task.forbid_compound_titles": (
        "Reject task titles that bundle multiple actions into one item. Enabled by default."
    ),
    "derivation.hierarchy.task.max_acceptance_criteria": (
        "Maximum acceptance-criteria bullets allowed on a task. Default: 5."
    ),
    "derivation.hierarchy.task.max_description_words": (
        "Maximum task description length, in words. Default: 150."
    ),
    "derivation.light_plan_bounds.simple_max_stories": (
        "Upper bound on stories for work classified as simple. Default: 3."
    ),
    "derivation.light_plan_bounds.simple_max_tasks": (
        "Upper bound on total tasks for work classified as simple. Default: 6."
    ),
    "derivation.light_plan_bounds.trivial_max_stories": (
        "Upper bound on stories for work classified as trivial. Default: 2."
    ),
    "derivation.light_plan_bounds.trivial_max_tasks": (
        "Upper bound on total tasks for work classified as trivial. Default: 4."
    ),
    "derivation.light_plan_bounds.complex_max_stories": (
        "Upper bound on stories for LIGHT-rigor work classified as complex. Default: 3."
    ),
    "derivation.light_plan_bounds.complex_max_tasks": (
        "Upper bound on total tasks for LIGHT-rigor work classified as complex. Default: 6."
    ),
    "derivation.plan_validation.enabled": (
        "Run plan-validation checks on derived plans before accepting them. Enabled by default."
    ),
    "derivation.sizing.enabled": (
        "Run derivation sizing so Obra can route work by complexity. Enabled by default."
    ),
    "derivation.sizing.guidance.complex.description": (
        "Prompt guidance that describes what Obra means by the complex sizing bucket. Default: \"A cross-cutting change requiring architectural consideration\"."
    ),
    "derivation.sizing.guidance.complex.scope": (
        "Prompt guidance describing the expected scope of complex work. Default: \"Multiple subsystems, plan for sequencing\"."
    ),
    "derivation.sizing.guidance.complex.use_single_shot": (
        "Prefer single-shot execution for work classified as complex. Disabled by default."
    ),
    "derivation.sizing.guidance.moderate.description": (
        "Prompt guidance that describes what Obra means by the moderate sizing bucket. Default: \"A cohesive feature with clear boundaries\"."
    ),
    "derivation.sizing.guidance.moderate.scope": (
        "Prompt guidance describing the expected scope of moderate work. Default: \"Multiple files, keep boundaries explicit\"."
    ),
    "derivation.sizing.guidance.moderate.use_single_shot": (
        "Prefer single-shot execution for work classified as moderate. Disabled by default."
    ),
    "derivation.sizing.guidance.simple.description": (
        "Prompt guidance that describes what Obra means by the simple sizing bucket. Default: \"A focused, self-contained change\"."
    ),
    "derivation.sizing.guidance.simple.scope": (
        "Prompt guidance describing the expected scope of simple work. Default: \"Small surface area, limited dependencies\"."
    ),
    "derivation.sizing.guidance.simple.use_single_shot": (
        "Prefer single-shot execution for work classified as simple. Enabled by default."
    ),
    "derivation.sizing.guidance.trivial.description": (
        "Prompt guidance that describes what Obra means by the trivial sizing bucket. Default: \"A quick fix or minor tweak\"."
    ),
    "derivation.sizing.guidance.trivial.scope": (
        "Prompt guidance describing the expected scope of trivial work. Default: \"Single file or tiny change\"."
    ),
    "derivation.sizing.guidance.trivial.use_single_shot": (
        "Prefer single-shot execution for work classified as trivial. Enabled by default."
    ),
    "derivation.sizing.llm.fallback_to_heuristic": (
        "Fall back to heuristic sizing if the LLM sizing pass fails. Enabled by default."
    ),
    "derivation.sizing.llm.max_retries": (
        "Maximum retry attempts for the LLM sizing pass. Default: 2."
    ),
    "derivation.sizing.llm.model": (
        "Optional explicit model override for the LLM sizing pass. Leave null to use normal model resolution."
    ),
    "derivation.sizing.pre_filter.fallback_on_error": (
        "Classification to use when the sizing pre-filter cannot decide cleanly. Default: \"uncertain\"."
    ),
    "derivation.sizing.pre_filter.max_retries": (
        "Maximum retry attempts for the sizing pre-filter stage. Default: 1."
    ),
    "derivation.sizing.pre_filter.model": (
        "Optional explicit model override for the sizing pre-filter. Leave null to use normal model resolution."
    ),
    "derivation.sizing.routing.inferred_rigor_by_size.complex": (
        "Rigor level to apply when the derived work size is complex. Default: \"thorough\"."
    ),
    "derivation.sizing.routing.inferred_rigor_by_size.moderate": (
        "Rigor level to apply when the derived work size is moderate. Default: \"balanced\"."
    ),
    "derivation.sizing.routing.inferred_rigor_by_size.simple": (
        "Rigor level to apply when the derived work size is simple. Default: \"light\"."
    ),
    "derivation.sizing.routing.inferred_rigor_by_size.trivial": (
        "Rigor level to apply when the derived work size is trivial. Default: \"light\"."
    ),
    "derivation.sizing.routing.policies.balanced.skip_analogues": (
        "Skip analogous-change discovery when using the balanced routing policy. Enabled by default."
    ),
    "derivation.sizing.routing.policies.balanced.skip_brief": (
        "Skip brief generation when using the balanced routing policy. Disabled by default."
    ),
    "derivation.sizing.routing.policies.balanced.use_single_shot": (
        "Prefer single-shot execution when using the balanced routing policy. Disabled by default."
    ),
    "derivation.sizing.routing.policies.balanced.validation_intensity": (
        "Validation intensity to use for the balanced routing policy. Default: \"standard\"."
    ),
    "derivation.sizing.routing.policies.light.skip_analogues": (
        "Skip analogous-change discovery when using the light routing policy. Enabled by default."
    ),
    "derivation.sizing.routing.policies.light.skip_brief": (
        "Skip brief generation when using the light routing policy. Enabled by default."
    ),
    "derivation.sizing.routing.policies.light.use_single_shot": (
        "Prefer single-shot execution when using the light routing policy. Enabled by default."
    ),
    "derivation.sizing.routing.policies.light.validation_intensity": (
        "Validation intensity to use for the light routing policy. Default: \"light\"."
    ),
    "derivation.sizing.routing.policies.thorough.skip_analogues": (
        "Skip analogous-change discovery when using the thorough routing policy. Disabled by default."
    ),
    "derivation.sizing.routing.policies.thorough.skip_brief": (
        "Skip brief generation when using the thorough routing policy. Disabled by default."
    ),
    "derivation.sizing.routing.policies.thorough.use_single_shot": (
        "Prefer single-shot execution when using the thorough routing policy. Disabled by default."
    ),
    "derivation.sizing.routing.policies.thorough.validation_intensity": (
        "Validation intensity to use for the thorough routing policy. Default: \"thorough\"."
    ),
    "derivation.workflow.enabled": (
        "Use the derivation workflow orchestration instead of ad hoc derivation steps. Enabled by default."
    ),
    "derivation.workflow.llm.max_retries": (
        "Maximum retry attempts for workflow-level derivation LLM calls. Default: 2."
    ),
    "derivation.workflow.llm.tier": (
        "Model tier used for the derivation workflow LLM stage. Default: \"medium\"."
    ),
    "derivation.workflow.operator_review.max_pending_points": (
        "Maximum unresolved review points before operator review is required. Default: 8."
    ),
    "derivation.workflow.validation.require_compile_ready_w2": (
        "Require the W2 output to be compile-ready before the workflow can advance. Enabled by default."
    ),
    "derivation.workflow.validation.require_operator_review_for_inferred_inputs": (
        "Require operator review when the workflow had to infer important inputs. Enabled by default."
    ),
    "display.ascii_mode": (
        "Turn ascii mode on or off. Disabled by default."
    ),
    "documentation.maintenance_targets": (
        "Documentation paths that automatic maintenance and close-out routines should audit first. Default set: [\"CHANGELOG.md\", \"docs/architecture/ARCHITECTURE.md\", \"docs/README.md\", \"docs/decisions/\", ...]."
    ),
    "ecosystem_conflict_markers.go": (
        "Files that identify a Go project when Obra checks for ecosystem conflicts. Default: [\"go.mod\"]."
    ),
    "ecosystem_conflict_markers.node": (
        "Files that identify a Node project when Obra checks for ecosystem conflicts. Default: [\"package.json\", \"pnpm-lock.yaml\", \"yarn.lock\"]."
    ),
    "ecosystem_conflict_markers.python": (
        "Files that identify a Python project when Obra checks for ecosystem conflicts. Default: [\"pyproject.toml\", \"setup.py\", \"requirements.txt\"]."
    ),
    "ecosystem_conflict_markers.ruby": (
        "Files that identify a Ruby project when Obra checks for ecosystem conflicts. Default: [\"Gemfile\"]."
    ),
    "ecosystem_conflict_markers.rust": (
        "Files that identify a Rust project when Obra checks for ecosystem conflicts. Default: [\"Cargo.toml\"]."
    ),
    "execution.mcp_servers.enabled": (
        "Enable configured MCP servers for execution flows. Enabled by default."
    ),
    "execution.mcp_servers.servers": (
        "Configured MCP server definitions available to execution flows. Leave empty to disable custom server registrations. Default: []."
    ),
    "features.advanced_planning.derivative_plans": (
        "Feature flag for advanced planning derivative plans. Enabled by default."
    ),
    "features.advanced_planning.description": (
        "Human-readable summary for the advanced planning feature group. Default: \"Structured workflows, patterns, and execution strategies\"."
    ),
    "features.advanced_planning.workflow_orchestration": (
        "Feature flag for advanced planning workflow orchestration. Enabled by default."
    ),
    "features.core_orchestration.config_loading": (
        "Feature flag for core orchestration config loading. Enabled by default."
    ),
    "features.core_orchestration.context_awareness": (
        "Feature flag for core orchestration context awareness. Enabled by default."
    ),
    "features.core_orchestration.description": (
        "Human-readable summary for the core orchestration feature group. Default: \"Essential orchestration - cannot run without these\"."
    ),
    "features.core_orchestration.implementation_agent": (
        "Feature flag for core orchestration implementation agent. Enabled by default."
    ),
    "features.core_orchestration.llm_provider": (
        "Feature flag for the core orchestration LLM-provider subsystem. Enabled by default."
    ),
    "features.core_orchestration.orchestrator": (
        "Feature flag for core orchestration orchestrator. Enabled by default."
    ),
    "features.core_orchestration.response_validation": (
        "Feature flag for core orchestration response validation. Enabled by default."
    ),
    "features.core_orchestration.state_manager": (
        "Feature flag for core orchestration state manager. Enabled by default."
    ),
    "features.core_orchestration.working_memory": (
        "Feature flag for core orchestration working memory. Enabled by default."
    ),
    "features.development_debug.breakpoints.description": (
        "Human-readable summary for the development debug breakpoints feature group. Default: \"Fail-safe intervention points (ADR-017)\"."
    ),
    "features.development_debug.debug_features.description": (
        "Human-readable summary for the development debug debug features feature group. Default: \"Development-only troubleshooting tools\"."
    ),
    "features.development_debug.description": (
        "Human-readable summary for the development debug feature group. Default: \"Logging, monitoring, breakpoints, and debugging\"."
    ),
    "features.development_debug.interactive.description": (
        "Human-readable summary for the development debug interactive feature group. Default: \"Rich terminal experience\"."
    ),
    "features.development_debug.interactive.rich_output": (
        "Feature flag for development debug interactive rich output. Enabled by default."
    ),
    "features.development_debug.interactive.syntax_highlighting": (
        "Feature flag for development debug interactive syntax highlighting. Enabled by default."
    ),
    "features.development_debug.production_logging.description": (
        "Human-readable summary for the development debug production logging feature group. Default: \"Always-on structured logging for monitoring (LOG-001)\"."
    ),
    "features.development_debug.production_logging.events.breakpoint_hit": (
        "Feature flag for development debug production logging events breakpoint hit. Enabled by default."
    ),
    "features.development_debug.production_logging.events.heartbeat": (
        "Feature flag for development debug production logging events heartbeat. Enabled by default."
    ),
    "features.development_debug.production_logging.events.iteration_results": (
        "Feature flag for development debug production logging events iteration results. Enabled by default."
    ),
    "features.development_debug.production_logging.events.task_completion": (
        "Feature flag for development debug production logging events task completion. Enabled by default."
    ),
    "features.development_debug.production_logging.privacy.redact_pii": (
        "Feature flag for development debug production logging privacy redact pii. Enabled by default."
    ),
    "features.development_debug.production_logging.privacy.redact_secrets": (
        "Feature flag for development debug production logging privacy redact secrets. Enabled by default."
    ),
    "features.development_debug.production_logging.rotation.backup_count": (
        "Number of rotated production log files to keep. Default: 10."
    ),
    "features.development_debug.production_logging.rotation.max_bytes": (
        "Maximum size of one production log file before rotation. Default: 104857600."
    ),
    "features.documentation_governance.description": (
        "Human-readable summary for the documentation governance feature group. Default: \"Automatic documentation maintenance and synchronization\"."
    ),
    "features.documentation_governance.maintenance.auto_archive": (
        "Feature flag for documentation governance maintenance auto archive. Enabled by default."
    ),
    "features.documentation_governance.maintenance.description": (
        "Human-readable summary for the documentation governance maintenance feature group. Default: \"Auto-maintain docs at lifecycle events (ADR-015)\"."
    ),
    "features.documentation_governance.maintenance.enabled": (
        "Feature flag for documentation governance maintenance enabled. Enabled by default."
    ),
    "features.documentation_governance.maintenance.triggers.epic_complete": (
        "Feature flag for documentation governance maintenance triggers epic complete. Enabled by default."
    ),
    "features.documentation_governance.maintenance.triggers.milestone": (
        "Feature flag for documentation governance maintenance triggers milestone. Enabled by default."
    ),
    "features.documentation_governance.maintenance.triggers.periodic": (
        "Feature flag for documentation governance maintenance triggers periodic. Enabled by default."
    ),
    "features.documentation_governance.maintenance.triggers.version_bump": (
        "Feature flag for documentation governance maintenance triggers version bump. Enabled by default."
    ),
    "features.intake.validation.garbage_patterns": (
        "Low-information user prompts that should trigger clarification instead of direct execution. Default: [\"do it\", \"do stuff\", \"help\", \"fix it\", \"make it work\"]."
    ),
    "features.integration_automation.description": (
        "Human-readable summary for the integration automation feature group. Default: \"Git automation and external tool integration\"."
    ),
    "features.integration_automation.git.auto_commit": (
        "Feature flag for integration automation git auto commit. Disabled by default."
    ),
    "features.integration_automation.git.auto_pr": (
        "Feature flag for integration automation git auto pr. Disabled by default."
    ),
    "features.integration_automation.git.create_branch": (
        "Feature flag for integration automation git create branch. Disabled by default."
    ),
    "features.integration_automation.git.description": (
        "Human-readable summary for the integration automation git feature group. Default: \"Automatic commits, branches, and PRs\"."
    ),
    "features.integration_automation.git.enabled": (
        "Feature flag for integration automation git enabled. Disabled by default."
    ),
    "features.integration_automation.retry_on_failure": (
        "Feature flag for integration automation retry on failure. Enabled by default."
    ),
    "features.intent.quality_check.non_empty_fields": (
        "Intent fields that must not be empty before the quality check passes. Default: [\"problem_statement\"]."
    ),
    "features.intent.quality_check.required_fields": (
        "Intent fields that must be present before the quality check passes. Default: [\"problem_statement\", \"requirements\"]."
    ),
    "features.performance_control.auto_retry": (
        "Feature flag for performance control auto retry. Enabled by default."
    ),
    "features.performance_control.budgets.description": (
        "Human-readable summary for the performance control budgets feature group. Default: \"Enforce resource limits (ADR-020)\"."
    ),
    "features.performance_control.budgets.progress.no_progress_threshold": (
        "Number of no-progress cycles allowed before stall detection fires. Default: 3."
    ),
    "features.performance_control.budgets.progress.stall_detection": (
        "Feature flag for performance control budgets progress stall detection. Enabled by default."
    ),
    "features.performance_control.budgets.tokens.enforce": (
        "Feature flag for performance control budgets tokens enforce. Disabled by default."
    ),
    "features.performance_control.checkpointing.basic_checkpoints": (
        "Feature flag for performance control checkpointing basic checkpoints. Enabled by default."
    ),
    "features.performance_control.checkpointing.description": (
        "Human-readable summary for the performance control checkpointing feature group. Default: \"Save progress at key points (ADR-019)\"."
    ),
    "features.performance_control.checkpointing.enabled": (
        "Feature flag for performance control checkpointing enabled. Enabled by default."
    ),
    "features.performance_control.checkpointing.manager.enabled": (
        "Feature flag for performance control checkpointing manager enabled. Enabled by default."
    ),
    "features.performance_control.description": (
        "Human-readable summary for the performance control feature group. Default: \"Budget limits, checkpointing, and session management\"."
    ),
    "features.performance_control.memory.context_summarization": (
        "Feature flag for performance control memory context summarization. Enabled by default."
    ),
    "features.performance_control.memory.description": (
        "Human-readable summary for the performance control memory feature group. Default: \"Context and narrative compression (ADR-018)\"."
    ),
    "features.performance_control.memory.session_memory": (
        "Feature flag for performance control memory session memory. Enabled by default."
    ),
    "features.performance_control.session_continuity.continuation_prompts": (
        "Feature flag for performance control session continuity continuation prompts. Enabled by default."
    ),
    "features.performance_control.session_continuity.decision_records": (
        "Feature flag for performance control session continuity decision records. Enabled by default."
    ),
    "features.performance_control.session_continuity.description": (
        "Human-readable summary for the performance control session continuity feature group. Default: \"Preserve state across sessions (ADR-019)\"."
    ),
    "features.performance_control.session_continuity.enabled": (
        "Feature flag for performance control session continuity enabled. Enabled by default."
    ),
    "features.performance_control.session_continuity.metrics": (
        "Feature flag for performance control session continuity metrics. Enabled by default."
    ),
    "features.performance_control.session_continuity.progress_reporting": (
        "Feature flag for performance control session continuity progress reporting. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.brownfield_threshold": (
        "Modification-count threshold after which code verification treats a change as brownfield work. Default: 50."
    ),
    "features.quality_automation.agents.code_verify.checks.compliance": (
        "Feature flag for quality automation agents code verify checks compliance. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.checks.dependency_graph": (
        "Feature flag for quality automation agents code verify checks dependency graph. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.checks.grounding": (
        "Feature flag for quality automation agents code verify checks grounding. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.greenfield_skip_story1": (
        "Feature flag for quality automation agents code verify greenfield skip story1. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.max_findings": (
        "Maximum number of findings the code-verify agent should report in one pass. Default: 50."
    ),
    "features.quality_automation.agents.code_verify.parallel_calls": (
        "Feature flag for quality automation agents code verify parallel calls. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.checks": (
        "Checklist IDs required during story preflight before code verification proceeds. Default: [\"C1\", \"C2\", \"C3\", \"C4\", \"C7\", \"C8\", \"C9\"]."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.enabled": (
        "Feature flag for quality automation agents code verify story preflight enabled. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.max_task_modifications": (
        "Maximum number of task edits story preflight will tolerate before escalating. Default: 10."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.max_verification_passes": (
        "Maximum verification passes allowed during story preflight. Default: 5."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.scope_to_modified": (
        "Feature flag for quality automation agents code verify story preflight scope to modified. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.sense_check": (
        "Feature flag for quality automation agents code verify story preflight sense check. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.timeout_s": (
        "Timeout for quality automation agents code verify story preflight. Default: 600."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.track_resolved": (
        "Feature flag for quality automation agents code verify story preflight track resolved. Enabled by default."
    ),
    "features.quality_automation.agents.code_verify.story_preflight.v0_action": (
        "Action to take when story preflight detects a V0-severity issue. Default: \"escalate\"."
    ),
    "features.quality_automation.agents.code_verify.timeout_s": (
        "Timeout for quality automation agents code verify. Default: 900."
    ),
    "features.quality_automation.agents.description": (
        "Human-readable summary for the quality automation agents feature group. Default: \"Specialized agents for quality tasks\"."
    ),
    "features.quality_automation.description": (
        "Human-readable summary for the quality automation feature group. Default: \"Automated code quality, security, and debugging\"."
    ),
    "features.quality_automation.quality_assessment": (
        "Feature flag for quality automation quality assessment. Enabled by default."
    ),
    "features.quality_automation.retry_system": (
        "Feature flag for quality automation retry system. Enabled by default."
    ),
    "features.saas_parity.analytics.complexity_estimates": (
        "Feature flag for saas parity analytics complexity estimates. Enabled by default."
    ),
    "features.saas_parity.analytics.parallel_attempts": (
        "Feature flag for saas parity analytics parallel attempts. Enabled by default."
    ),
    "features.saas_parity.analytics.parameter_tracking": (
        "Feature flag for saas parity analytics parameter tracking. Enabled by default."
    ),
    "features.saas_parity.analytics.rule_violations": (
        "Feature flag for saas parity analytics rule violations. Enabled by default."
    ),
    "features.saas_parity.collections.clarifications": (
        "Feature flag for saas parity collections clarifications. Enabled by default."
    ),
    "features.saas_parity.collections.interactions": (
        "Feature flag for saas parity collections interactions. Enabled by default."
    ),
    "features.saas_parity.description": (
        "Human-readable summary for the saas parity feature group. Default: \"Controls new Firestore collections from EPIC-SAAS-PARITY-001\"."
    ),
    "features.user_experience.description": (
        "Human-readable summary for the user experience feature group. Default: \"Natural language commands and quality clarification\"."
    ),
    "features.user_experience.interactive_repl.emacs_mode": (
        "Feature flag for user experience interactive repl emacs mode. Disabled by default."
    ),
    "features.user_experience.interactive_repl.enabled": (
        "Feature flag for user experience interactive repl enabled. Enabled by default."
    ),
    "features.user_experience.interactive_repl.vi_mode": (
        "Feature flag for user experience interactive repl vi mode. Disabled by default."
    ),
    "features.user_experience.nl_commands.confidence_threshold": (
        "Minimum confidence required before a natural-language command is accepted automatically. Default: 0.8."
    ),
    "features.user_experience.nl_commands.description": (
        "Human-readable summary for the user experience nl commands feature group. Default: \"Natural language interface for commands\"."
    ),
    "features.user_experience.nl_commands.max_context_turns": (
        "Maximum conversation turns included when interpreting a natural-language command. Default: 5."
    ),
    "features.user_experience.quality_clarification.auto_fill_on_pass": (
        "Feature flag for user experience quality clarification auto fill on pass. Enabled by default."
    ),
    "features.user_experience.quality_clarification.description": (
        "Human-readable summary for the user experience quality clarification feature group. Default: \"Internal LLM-to-LLM quality refinement loop (ADR-022)\"."
    ),
    "features.user_experience.quality_clarification.enabled": (
        "Feature flag for user experience quality clarification enabled. Enabled by default."
    ),
    "features.user_experience.quality_clarification.max_iterations": (
        "Maximum clarification iterations allowed before the loop stops. Default: 5."
    ),
    "features.user_experience.smart_defaults.assumption_generation.cache_max_size": (
        "Maximum cached assumption-generation results retained in memory. Default: 100."
    ),
    "features.user_experience.smart_defaults.description": (
        "Human-readable summary for the user experience smart defaults feature group. Default: \"Intelligent assumption generation for underspecified prompts\"."
    ),
    "features.user_experience.smart_defaults.enabled": (
        "Feature flag for user experience smart defaults enabled. Enabled by default."
    ),
    "features.user_experience.smart_defaults.thresholds.offer_options": (
        "Confidence cutoff below which Obra should offer explicit options instead of assuming one path. Default: 0.2."
    ),
    "features.user_experience.smart_defaults.thresholds.show_assumptions": (
        "Confidence cutoff below which Obra should show its assumptions to the user. Default: 0.4."
    ),
    "features.userplan.description": (
        "Human-readable summary for the userplan feature group. Default: \"Controls UserPlan validation and derivation pipeline features\"."
    ),
    "fix.verification.tools": (
        "Explicit verification commands for fix loops. Leave this empty to let tooling discovery choose the project's real verification tools. Default: []."
    ),
    "gateway.assistant.phase_detection.entry_point_defaults.clone": (
        "Default entry-point classification for clone projects when phase detection cannot infer one. Default: \"draft\"."
    ),
    "gateway.assistant.phase_detection.entry_point_defaults.import": (
        "Default entry-point classification for import projects when phase detection cannot infer one. Default: \"computed\"."
    ),
    "gateway.assistant.phase_detection.entry_point_defaults.starter": (
        "Default entry-point classification for starter projects when phase detection cannot infer one. Default: \"draft\"."
    ),
    "gateway.assistant.readiness.next_action_priorities": (
        "Ordered list of readiness actions the gateway assistant should prefer when suggesting the next step. Earlier actions are considered first. Default starts with fix_blocking_issues, fix_improvement_issues, and enrich_least_complete_stage."
    ),
    "gateway.assistant.section_priorities.carry_forward_context": (
        "Relative priority for the carry forward context section in gateway assistant context assembly. Lower numbers appear earlier. Default: 4."
    ),
    "gateway.assistant.section_priorities.conversation_history": (
        "Relative priority for the conversation history section in gateway assistant context assembly. Lower numbers appear earlier. Default: 5."
    ),
    "gateway.assistant.section_priorities.graph_structure": (
        "Relative priority for the graph structure section in gateway assistant context assembly. Lower numbers appear earlier. Default: 7."
    ),
    "gateway.assistant.section_priorities.interaction_log": (
        "Relative priority for the interaction log section in gateway assistant context assembly. Lower numbers appear earlier. Default: 9."
    ),
    "gateway.assistant.section_priorities.knowledge_docs": (
        "Relative priority for the knowledge docs section in gateway assistant context assembly. Lower numbers appear earlier. Default: 4."
    ),
    "gateway.assistant.section_priorities.latest_run": (
        "Relative priority for the latest run section in gateway assistant context assembly. Lower numbers appear earlier. Default: 6."
    ),
    "gateway.assistant.section_priorities.preamble": (
        "Relative priority for the preamble section in gateway assistant context assembly. Lower numbers appear earlier. Default: 1."
    ),
    "gateway.assistant.section_priorities.proactive_guidance": (
        "Relative priority for the proactive guidance section in gateway assistant context assembly. Lower numbers appear earlier. Default: 7."
    ),
    "gateway.assistant.section_priorities.recent_changes": (
        "Relative priority for the recent changes section in gateway assistant context assembly. Lower numbers appear earlier. Default: 8."
    ),
    "gateway.assistant.section_priorities.recent_transcript": (
        "Relative priority for the recent transcript section in gateway assistant context assembly. Lower numbers appear earlier. Default: 4."
    ),
    "gateway.assistant.section_priorities.revision_history": (
        "Relative priority for the revision history section in gateway assistant context assembly. Lower numbers appear earlier. Default: 10."
    ),
    "gateway.assistant.section_priorities.run_comparison": (
        "Relative priority for the run comparison section in gateway assistant context assembly. Lower numbers appear earlier. Default: 5."
    ),
    "gateway.assistant.section_priorities.selected_stage": (
        "Relative priority for the selected stage section in gateway assistant context assembly. Lower numbers appear earlier. Default: 2."
    ),
    "gateway.assistant.section_priorities.thread_summary": (
        "Relative priority for the thread summary section in gateway assistant context assembly. Lower numbers appear earlier. Default: 4."
    ),
    "gateway.assistant.section_priorities.ui_state": (
        "Relative priority for the ui state section in gateway assistant context assembly. Lower numbers appear earlier. Default: 7."
    ),
    "gateway.assistant.section_priorities.workflow_definition": (
        "Relative priority for the workflow definition section in gateway assistant context assembly. Lower numbers appear earlier. Default: 3."
    ),
    "gateway.assistant.section_priorities.workflow_readiness": (
        "Relative priority for the workflow readiness section in gateway assistant context assembly. Lower numbers appear earlier. Default: 3."
    ),
    "gateway.desktop.preserved_env_vars": (
        "Environment variables preserved when the desktop gateway launches subprocesses. Keep this list small and security-conscious. Default preserves runtime, emulator, locale, path, and API credential variables."
    ),
    "gateway.desktop.stderr_log_filename": (
        "Filename used for the desktop gateway stderr log inside the gateway log directory. Default: \"gateway.stderr.log\"."
    ),
    "gateway.desktop.stdout_log_filename": (
        "Filename used for the desktop gateway stdout log inside the gateway log directory. Default: \"gateway.stdout.log\"."
    ),
    "gateway.max_working_dir_length": (
        "Maximum working-directory path length the gateway accepts before rejecting the request. Default: 4096."
    ),
    "gateway.onboarding.providers": (
        "Built-in provider catalog shown during gateway onboarding, including install/auth guidance and handler wiring for Claude Code, OpenAI Codex, Gemini, and Ollama."
    ),
    "handlers.escalate.interactive": (
        "Allow escalation handlers to pause for interactive operator input. Disabled by default."
    ),
    "handlers.story0.capability_checks.audio.fallback.env_vars": (
        "Environment variables Story0 checks as a fallback signal that audio capabilities exist. Default: [\"PULSE_SERVER\"]."
    ),
    "handlers.story0.capability_checks.audio.indicators": (
        "Keywords that suggest a task needs audio capability checks. Default: [\"audio\", \"sound\", \"speaker\", \"microphone\"]."
    ),
    "handlers.story0.capability_checks.audio.platforms.darwin.always_available": (
        "Treat audio as always available on macOS during Story0 capability checks. Enabled by default."
    ),
    "handlers.story0.capability_checks.audio.platforms.linux.env_vars": (
        "Linux environment variables Story0 checks to confirm audio support. Default: [\"PULSE_SERVER\", \"ALSA_CARD\"]."
    ),
    "handlers.story0.capability_checks.audio.platforms.win32.always_available": (
        "Treat audio as always available on Windows during Story0 capability checks. Enabled by default."
    ),
    "handlers.story0.capability_checks.display.fallback.env_vars": (
        "Environment variables Story0 checks as a fallback signal that display access exists. Default: [\"DISPLAY\"]."
    ),
    "handlers.story0.capability_checks.display.indicators": (
        "Keywords that suggest a task needs display or GUI capability checks. Default: [\"gui\", \"display\", \"window\", \"screen\", \"graphical\"]."
    ),
    "handlers.story0.capability_checks.display.platforms.darwin.always_available": (
        "Treat display access as always available on macOS during Story0 capability checks. Enabled by default."
    ),
    "handlers.story0.capability_checks.display.platforms.linux.env_vars": (
        "Linux environment variables Story0 checks to confirm display access. Default: [\"DISPLAY\", \"WAYLAND_DISPLAY\"]."
    ),
    "handlers.story0.capability_checks.display.platforms.win32.always_available": (
        "Treat display access as always available on Windows during Story0 capability checks. Enabled by default."
    ),
    "handlers.story0.capability_checks.filesystem_write.always_available": (
        "Assume filesystem write access is available during Story0 checks. Enabled by default."
    ),
    "handlers.story0.capability_checks.filesystem_write.indicators": (
        "Keywords that suggest a task needs filesystem write capability. Default: [\"write permission\", \"writable\", \"filesystem\"]."
    ),
    "handlers.story0.capability_checks.python_runtime.commands": (
        "Commands Story0 runs to verify that a Python interpreter is available. Default tries python3 and python."
    ),
    "handlers.story0.capability_checks.python_runtime.indicators": (
        "Keywords that suggest a task needs Python runtime checks. Default: [\"python interpreter\", \"python 3 interpreter\", \"python3 interpreter\", \"python runtime\", \"python3 runtime\"]."
    ),
    "handlers.story0.capability_checks.tkinter.commands": (
        "Commands Story0 runs to verify that Tkinter is installed and importable. Default tries python3 and python import checks."
    ),
    "handlers.story0.capability_checks.tkinter.indicators": (
        "Keywords that suggest a task needs Tkinter support. Default: [\"tkinter\", \"tk gui\", \"tk bindings\", \"python3-tk\"]."
    ),
    "handlers.story0.port_mappings.mongodb": (
        "Default container port for MongoDB when Story0 proposes local services. Default: 27017."
    ),
    "handlers.story0.port_mappings.mysql": (
        "Default container port for MySQL when Story0 proposes local services. Default: 3306."
    ),
    "handlers.story0.port_mappings.postgres": (
        "Default container port for Postgres when Story0 proposes local services. Default: 5432."
    ),
    "handlers.story0.port_mappings.redis": (
        "Default container port for Redis when Story0 proposes local services. Default: 6379."
    ),
    "handlers.story0.service_images.mongodb": (
        "Default container image Story0 suggests for MongoDB. Default: \"mongo:6\"."
    ),
    "handlers.story0.service_images.mysql": (
        "Default container image Story0 suggests for MySQL. Default: \"mysql:8\"."
    ),
    "handlers.story0.service_images.postgres": (
        "Default container image Story0 suggests for Postgres. Default: \"postgres:15\"."
    ),
    "handlers.story0.service_images.redis": (
        "Default container image Story0 suggests for Redis. Default: \"redis:7\"."
    ),
    "inferred_install_allowlist._common": (
        "Packages Story0 may infer and propose across all ecosystems when they are missing from manifests. Each entry records the package name and whether it is runtime, dev, or both. Default includes pre-commit."
    ),
    "inferred_install_allowlist.go": (
        "Go packages Story0 may infer and propose when the project appears to need standard tooling. Each entry records the package name and whether it is runtime or dev-only. Default includes golangci-lint."
    ),
    "inferred_install_allowlist.node": (
        "Node packages Story0 may infer and propose when the project appears to need standard tooling. Each entry records the package name and whether it is runtime or dev-only. Default includes eslint, prettier, vitest, and react."
    ),
    "inferred_install_allowlist.python": (
        "Python packages Story0 may infer and propose when the project appears to need standard tooling. Each entry records the package name and whether it is runtime or dev-only. Default includes pytest, ruff, black, mypy, and fastapi."
    ),
    "inferred_install_allowlist.ruby": (
        "Ruby packages Story0 may infer and propose when the project appears to need standard tooling. Each entry records the package name and whether it is runtime or dev-only. Default includes rubocop and rspec."
    ),
    "inferred_install_allowlist.rust": (
        "Rust packages Story0 may infer and propose when the project appears to need standard tooling. Each entry records the package name and whether it is runtime or dev-only. Default includes cargo-nextest and clippy."
    ),
    "intent.token_budget": (
        "Token budget reserved for the intent understanding stage. Default: 120000."
    ),
    "learned_patterns.confidence_threshold": (
        "Minimum confidence score a learned pattern must reach before Obra reuses it automatically. Default: 0.6."
    ),
    "learned_patterns.injection_budget_tokens": (
        "Maximum prompt budget reserved for injecting learned patterns into a request. Default: 2000 tokens."
    ),
    "learned_patterns.max_pattern_age_days": (
        "Discard learned patterns older than this many days. Default: 90."
    ),
    "learned_patterns.max_patterns": (
        "Maximum number of learned patterns retained in memory. Default: 30."
    ),
    "learned_patterns.storage_path": (
        "Path to the learned-pattern cache file. Default: \".obra/memory/learned_patterns.json\"."
    ),
    "llm.codex.force_sandbox_bypass": (
        "Force Codex requests to run with sandbox bypass when the provider supports it. Use sparingly. Disabled by default."
    ),
    "llm.ollama.endpoint": (
        "Base URL for the local Ollama API endpoint. Default: \"http://localhost:11434\"."
    ),
    "llm.provider_defaults.anthropic.fast": (
        "Fallback model alias for the Anthropic fast tier when model selection resolves to provider defaults. Default: \"sonnet\"."
    ),
    "llm.provider_defaults.anthropic.high": (
        "Fallback model alias for the Anthropic high tier when model selection resolves to provider defaults. Default: \"opus\"."
    ),
    "llm.provider_defaults.anthropic.medium": (
        "Fallback model alias for the Anthropic medium tier when model selection resolves to provider defaults. Default: \"opus\"."
    ),
    "llm.provider_defaults.google.fast": (
        "Fallback model alias for the Google fast tier when model selection resolves to provider defaults. Default: \"gemini-3-flash-preview\"."
    ),
    "llm.provider_defaults.google.high": (
        "Fallback model alias for the Google high tier when model selection resolves to provider defaults. Default: \"gemini-3.1-pro-preview\"."
    ),
    "llm.provider_defaults.google.medium": (
        "Fallback model alias for the Google medium tier when model selection resolves to provider defaults. Default: \"gemini-3-flash-preview\"."
    ),
    "llm.provider_defaults.ollama.fast": (
        "Fallback model alias for the Ollama fast tier when model selection resolves to provider defaults. Default: \"default\"."
    ),
    "llm.provider_defaults.ollama.high": (
        "Fallback model alias for the Ollama high tier when model selection resolves to provider defaults. Default: \"default\"."
    ),
    "llm.provider_defaults.ollama.medium": (
        "Fallback model alias for the Ollama medium tier when model selection resolves to provider defaults. Default: \"default\"."
    ),
    "llm.provider_defaults.openai.fast": (
        "Fallback model alias for the OpenAI fast tier when model selection resolves to provider defaults. Default: \"gpt-5.5\"."
    ),
    "llm.provider_defaults.openai.high": (
        "Fallback model alias for the OpenAI high tier when model selection resolves to provider defaults. Default: \"gpt-5.5\"."
    ),
    "llm.provider_defaults.openai.medium": (
        "Fallback model alias for the OpenAI medium tier when model selection resolves to provider defaults. Default: \"gpt-5.5\"."
    ),
    "llm.role_defaults.anthropic.implementation.fast": (
        "Role-specific fallback model alias for implementation work on Anthropic when the requested model is left at default for the fast tier. Default: \"sonnet\"."
    ),
    "llm.role_defaults.anthropic.implementation.high": (
        "Role-specific fallback model alias for implementation work on Anthropic when the requested model is left at default for the high tier. Default: \"opus\"."
    ),
    "llm.role_defaults.anthropic.implementation.medium": (
        "Role-specific fallback model alias for implementation work on Anthropic when the requested model is left at default for the medium tier. Default: \"opus\"."
    ),
    "llm.role_defaults.anthropic.orchestrator.fast": (
        "Role-specific fallback model alias for orchestrator work on Anthropic when the requested model is left at default for the fast tier. Default: \"sonnet\"."
    ),
    "llm.role_defaults.anthropic.orchestrator.high": (
        "Role-specific fallback model alias for orchestrator work on Anthropic when the requested model is left at default for the high tier. Default: \"opus\"."
    ),
    "llm.role_defaults.anthropic.orchestrator.medium": (
        "Role-specific fallback model alias for orchestrator work on Anthropic when the requested model is left at default for the medium tier. Default: \"opus\"."
    ),
    "llm.role_defaults.google.implementation.fast": (
        "Role-specific fallback model alias for implementation work on Google when the requested model is left at default for the fast tier. Default: \"gemini-3-flash-preview\"."
    ),
    "llm.role_defaults.google.implementation.high": (
        "Role-specific fallback model alias for implementation work on Google when the requested model is left at default for the high tier. Default: \"gemini-3.1-pro-preview\"."
    ),
    "llm.role_defaults.google.implementation.medium": (
        "Role-specific fallback model alias for implementation work on Google when the requested model is left at default for the medium tier. Default: \"gemini-3-flash-preview\"."
    ),
    "llm.role_defaults.google.orchestrator.fast": (
        "Role-specific fallback model alias for orchestrator work on Google when the requested model is left at default for the fast tier. Default: \"gemini-3-flash-preview\"."
    ),
    "llm.role_defaults.google.orchestrator.high": (
        "Role-specific fallback model alias for orchestrator work on Google when the requested model is left at default for the high tier. Default: \"gemini-3.1-pro-preview\"."
    ),
    "llm.role_defaults.google.orchestrator.medium": (
        "Role-specific fallback model alias for orchestrator work on Google when the requested model is left at default for the medium tier. Default: \"gemini-3-flash-preview\"."
    ),
    "llm.role_defaults.ollama.implementation.fast": (
        "Role-specific fallback model alias for implementation work on Ollama when the requested model is left at default for the fast tier. Default: \"default\"."
    ),
    "llm.role_defaults.ollama.implementation.high": (
        "Role-specific fallback model alias for implementation work on Ollama when the requested model is left at default for the high tier. Default: \"default\"."
    ),
    "llm.role_defaults.ollama.implementation.medium": (
        "Role-specific fallback model alias for implementation work on Ollama when the requested model is left at default for the medium tier. Default: \"default\"."
    ),
    "llm.role_defaults.ollama.orchestrator.fast": (
        "Role-specific fallback model alias for orchestrator work on Ollama when the requested model is left at default for the fast tier. Default: \"default\"."
    ),
    "llm.role_defaults.ollama.orchestrator.high": (
        "Role-specific fallback model alias for orchestrator work on Ollama when the requested model is left at default for the high tier. Default: \"default\"."
    ),
    "llm.role_defaults.ollama.orchestrator.medium": (
        "Role-specific fallback model alias for orchestrator work on Ollama when the requested model is left at default for the medium tier. Default: \"default\"."
    ),
    "llm.role_defaults.openai.implementation.fast": (
        "Role-specific fallback model alias for implementation work on OpenAI when the requested model is left at default for the fast tier. Default: \"gpt-5.5\"."
    ),
    "llm.role_defaults.openai.implementation.high": (
        "Role-specific fallback model alias for implementation work on OpenAI when the requested model is left at default for the high tier. Default: \"gpt-5.5\"."
    ),
    "llm.role_defaults.openai.implementation.medium": (
        "Role-specific fallback model alias for implementation work on OpenAI when the requested model is left at default for the medium tier. Default: \"gpt-5.5\"."
    ),
    "llm.role_defaults.openai.orchestrator.fast": (
        "Role-specific fallback model alias for orchestrator work on OpenAI when the requested model is left at default for the fast tier. Default: \"gpt-5.5\"."
    ),
    "llm.role_defaults.openai.orchestrator.high": (
        "Role-specific fallback model alias for orchestrator work on OpenAI when the requested model is left at default for the high tier. Default: \"gpt-5.5\"."
    ),
    "llm.role_defaults.openai.orchestrator.medium": (
        "Role-specific fallback model alias for orchestrator work on OpenAI when the requested model is left at default for the medium tier. Default: \"gpt-5.5\"."
    ),
    "llm.thinking.default_budget": (
        "Default token budget for extended LLM thinking when a request does not override it. Default: 10000."
    ),
    "llm.thinking.max_tokens": (
        "Maximum token budget allowed for extended LLM thinking. Default: 31999."
    ),
    "llm.thinking.min_tokens": (
        "Minimum token budget allowed when extended LLM thinking is enabled. Default: 1024."
    ),
    "llm.thinking.standard_tokens": (
        "Standard token budget used for normal extended-thinking requests. Default: 8000."
    ),
    "llm.tier_fallbacks.fast": (
        "Fallback tier order to try when the requested fast tier is unavailable for the selected provider. Default: [\"fast\", \"medium\", \"high\"]."
    ),
    "llm.tier_fallbacks.high": (
        "Fallback tier order to try when the requested high tier is unavailable for the selected provider. Default: [\"high\", \"medium\"]."
    ),
    "llm.tier_fallbacks.medium": (
        "Fallback tier order to try when the requested medium tier is unavailable for the selected provider. Default: [\"medium\", \"high\"]."
    ),
    "monitoring.file_watcher.enabled": (
        "Emit or enable file watcher enabled monitoring behavior. Enabled by default."
    ),
    "monitoring.file_watcher.ignore_patterns": (
        "Glob patterns the file watcher ignores to avoid noisy or expensive filesystem scans. Default covers caches, VCS state, virtual environments, build outputs, and dependency directories."
    ),
    "monitoring.output_monitor.completion_markers": (
        "Text markers that the output monitor treats as successful completion signals. Default: [\"Task completed\", \"Done\", \"Finished\"]."
    ),
    "monitoring.output_monitor.error_markers": (
        "Text markers that the output monitor treats as failure signals. Default: [\"Error:\", \"Failed:\", \"Exception:\"]."
    ),
    "monitoring.production_logging.enabled": (
        "Emit or enable production logging enabled monitoring behavior. Enabled by default."
    ),
    "monitoring.production_logging.events.context_pressure": (
        "Emit or enable production logging events context pressure monitoring behavior. Enabled by default."
    ),
    "monitoring.production_logging.events.task_termination": (
        "Emit or enable production logging events task termination monitoring behavior. Enabled by default."
    ),
    "monitoring.production_logging.path": (
        "Path to the production event log written by runtime monitoring. Default: \"~/.obra-runtime/logs/production.jsonl\"."
    ),
    "nl_commands.auto_confirm_destructive": (
        "Turn auto confirm destructive on or off. Disabled by default."
    ),
    "nl_commands.confidence_threshold": (
        "Threshold for confidence threshold. Default: 0.7."
    ),
    "observability.events.issues_found": (
        "Emit observability events for issues found. Enabled by default."
    ),
    "observability.events.iteration_progress": (
        "Emit observability events for iteration progress. Enabled by default."
    ),
    "observability.events.session_completed": (
        "Emit observability events for session completed. Enabled by default."
    ),
    "observability.events.session_escalated": (
        "Emit observability events for session escalated. Enabled by default."
    ),
    "observability.events.task_completed": (
        "Emit observability events for task completed. Enabled by default."
    ),
    "observability.events.validation_failed": (
        "Emit observability events for validation failed. Enabled by default."
    ),
    "orchestration.cleanup.auto_retry_backoff_seconds": (
        "Backoff delay between cleanup retry attempts. Default: 2."
    ),
    "orchestration.cleanup.auto_retry_max_attempts": (
        "Maximum number of cleanup retry attempts for retryable failures. Default: 2."
    ),
    "orchestration.cleanup.auto_retry_sources": (
        "Cleanup failure categories that qualify for automatic retry. Use this to limit retries to transient problems instead of persistent misconfigurations. Default: [\"transient_exhausted\", \"external_dependency\"]."
    ),
    "orchestration.cleanup.output_dir": (
        "Directory where cleanup and skip-tracking artifacts are written. Default: \".obra/skip-tracking/cleanup\"."
    ),
    "orchestration.file_access.additional_allowed_paths": (
        "Extra filesystem path patterns the orchestrator may access outside the standard workspace sandbox. Default: [\"/tmp/obra-*\"]."
    ),
    "orchestration.governor.telemetry.log_wait_times": (
        "Emit telemetry for governor wait times so slow scheduling decisions are visible in logs. Enabled by default."
    ),
    "orchestration.llm.slow_call_threshold_ms.balanced": (
        "Millisecond threshold after which balanced LLM calls are logged as slow. Default: 30000."
    ),
    "orchestration.llm.slow_call_threshold_ms.fast": (
        "Millisecond threshold after which fast LLM calls are logged as slow. Default: 15000."
    ),
    "orchestration.llm.slow_call_threshold_ms.quality": (
        "Millisecond threshold after which quality LLM calls are logged as slow. Default: 60000."
    ),
    "orchestration.policy_engine.max_refinement_iterations_cap": (
        "Hard cap on policy-engine-directed refinement iterations. Default: 5."
    ),
    "orchestration.policy_engine.oscillation_recurrence_threshold": (
        "Recurrence threshold used to decide when the policy engine treats behavior as oscillation. Default: 0.5."
    ),
    "orchestration.quality.policy_mode": (
        "How the orchestration quality policy is selected. Use \"auto\" to let Obra pick the policy from runtime context. Default: \"medium\"."
    ),
    "orchestration.skip_tracking.closeout_summary": (
        "Include a skip-tracking summary during close-out. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.auto_runner": (
        "Record skip-tracking events originating from auto runner. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.derive_handler": (
        "Record skip-tracking events originating from derive handler. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.orchestrator": (
        "Record skip-tracking events originating from orchestrator. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.permissive_mode": (
        "Record skip-tracking events originating from permissive mode. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.quality_loop": (
        "Record skip-tracking events originating from quality loop. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.revision": (
        "Record skip-tracking events originating from revision. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.story0": (
        "Record skip-tracking events originating from story0. Enabled by default."
    ),
    "orchestration.skip_tracking.sources.user_bypass": (
        "Record skip-tracking events originating from user bypass. Disabled by default."
    ),
    "orchestration.spike_first.evaluator_timeout_s": (
        "Timeout for spike-first evaluation passes. Default: 600."
    ),
    "orchestration.spike_first.grounding_extractor.enabled": (
        "Enable the fast-tier grounding extractor used by spike evaluator gates. Default: true."
    ),
    "orchestration.spike_first.grounding_extractor.timeout_s": (
        "Timeout for spike grounding extractor LLM calls. Minimum 600 seconds. Default: 600."
    ),
    "orchestration.spike_first.grounding_extractor.tier": (
        "LLM tier used for spike grounding extraction. Valid values: fast, medium, high. Default: fast."
    ),
    "orchestration.spike_first.executor_timeout_s": (
        "Timeout for spike-first execution passes. Default: 1800."
    ),
    "orchestration.spike_first.max_spikes.balanced": (
        "Maximum number of spike attempts allowed for the balanced rigor level. Default: 1."
    ),
    "orchestration.spike_first.max_spikes.light": (
        "Maximum number of spike attempts allowed for the light rigor level. Default: 1."
    ),
    "orchestration.spike_first.max_spikes.thorough": (
        "Maximum number of spike attempts allowed for the thorough rigor level. Default: 2."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.manual.enabled": (
        "Allow manual actions to create session continuity checkpoints. Enabled by default."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.operation_count.count_threshold": (
        "Operation count that triggers a session continuity checkpoint. Default: 50."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.operation_count.enabled": (
        "Allow operation-count thresholds to create session continuity checkpoints. Enabled by default."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.threshold.enabled": (
        "Allow context-usage thresholds to create session continuity checkpoints. Enabled by default."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.threshold.usage_threshold": (
        "Context-usage threshold that triggers a session continuity checkpoint. Default: 0.85."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.time.enabled": (
        "Allow elapsed time to create session continuity checkpoints. Enabled by default."
    ),
    "orchestrator.session_continuity.checkpoints.triggers.time.interval_minutes": (
        "Elapsed time, in minutes, between time-based session continuity checkpoints. Default: 30."
    ),
    "pipeline.runner_kind_timeout_floors.builtin_agent_adapter": (
        "Minimum timeout floor for the built-in agent adapter runner kind. Default: 600."
    ),
    "pipeline.runner_kind_timeout_floors.command_runner": (
        "Minimum timeout floor for command-runner pipeline steps. Default: 5."
    ),
    "pipeline.runner_kind_timeout_floors.http_runner": (
        "Minimum timeout floor for HTTP-runner pipeline steps. Default: 30."
    ),
    "pipeline.runner_kind_timeout_floors.python_runner": (
        "Minimum timeout floor for Python-runner pipeline steps. Default: 5."
    ),
    "planning.enrichment.stages.revise.model_tier": (
        "Model tier used for the revise stage during plan enrichment. Default: \"high\"."
    ),
    "planning.enrichment.stages.revise.reasoning_level": (
        "Reasoning intensity used for the revise stage during plan enrichment. Default: \"high\"."
    ),
    "planning.plan_integrity.auto_repair_max_attempts": (
        "Maximum automatic repair attempts when plan-integrity validation fails. Default: 2."
    ),
    "planning.plan_integrity.auto_repair_timeout_s": (
        "Timeout for one automatic plan-integrity repair attempt. Default: 120."
    ),
    "provider_validation.auth_probe_enabled": (
        "Run lightweight authentication probes during provider validation so misconfigured credentials are caught early. Enabled by default."
    ),
    "quality.enabled": (
        "Master switch for quality scoring and gates. Enabled by default."
    ),
    "quality.generated_plan_threshold": (
        "Minimum quality score a generated plan must reach before it is accepted without further refinement. Default: 0.4."
    ),
    "refinement.llm.error": (
        "Record refinement-stage LLM errors in refinement state and metrics. Enabled by default."
    ),
    "refinement.metrics.enabled": (
        "Enable refinement-stage metrics collection. Enabled by default."
    ),
    "refinement.metrics.record_iteration_metrics": (
        "Record per-iteration refinement metrics for analysis and debugging. Enabled by default."
    ),
    "refinement.metrics.record_quality_metrics": (
        "Record refinement quality metrics alongside iteration metrics. Enabled by default."
    ),
    "refinement.redaction.enabled": (
        "Enable redaction of sensitive values in refinement artifacts. Enabled by default."
    ),
    "refinement.redaction.types": (
        "Sensitive data types the refinement redactor should scrub from stored artifacts. Default: [\"email\", \"ip_address\", \"api_key\", \"jwt_token\", ...]."
    ),
    "review.blocking_policy.low_priority_strict": (
        "Treat low-priority findings as blocking during review. Disabled by default."
    ),
    "review.convergence.fresh_fix_enabled": (
        "Allow the review loop to request a fresh fix attempt after stale cycles. Enabled by default."
    ),
    "review.convergence.identity_overlap_threshold": (
        "Similarity threshold used to decide whether consecutive finding sets are materially the same. Default: 0.5."
    ),
    "review.convergence.max_template_failure_cycles": (
        "Maximum consecutive template-failure cycles before escalation. Default: 3."
    ),
    "review.convergence.stale_cycles_for_escalate": (
        "Number of stale review cycles before escalation is triggered. Default: 3."
    ),
    "review.convergence.stale_cycles_for_fresh_fix": (
        "Number of stale review cycles before Obra tries a fresh fix path. Default: 2."
    ),
    "review.feedback.rating_adjustments.1": (
        "Score adjustment applied when user feedback is rated 1 star. Default: -0.3."
    ),
    "review.feedback.rating_adjustments.4": (
        "Score adjustment applied when user feedback is rated 4 stars. Default: 0.1."
    ),
    "review.feedback.rating_adjustments.5": (
        "Score adjustment applied when user feedback is rated 5 stars. Default: 0.2."
    ),
    "review.intent_context.enabled": (
        "Include intent context in review prompts. Enabled by default."
    ),
    "review.intent_context.max_chars": (
        "Maximum total characters of intent context included in a review prompt. Default: 1200."
    ),
    "review.intent_context.max_item_chars": (
        "Maximum characters allowed for one intent-context item. Default: 200."
    ),
    "review.intent_context.max_items": (
        "Maximum number of intent-context items included in a review prompt. Default: 5."
    ),
    "review.loop_exit_policy.enabled": (
        "Apply the structured review-loop exit policy instead of stopping ad hoc. Enabled by default."
    ),
    "review.loop_exit_policy.max_non_critical_review_cycles": (
        "Maximum extra review cycles allowed once only non-critical issues remain. Default: 2."
    ),
    "review.loop_exit_policy.require_no_new_critical": (
        "Require the latest review pass to avoid introducing any new critical findings. Enabled by default."
    ),
    "review.loop_exit_policy.require_required_checks_pass": (
        "Require all mandatory verification checks to pass before the review loop can stop. Disabled by default."
    ),
    "review.loop_exit_policy.require_threshold_met": (
        "Require the review loop to hit its target score before Obra can stop iterating. Enabled by default."
    ),
    "review.loop_exit_policy.score_plateau_max_delta": (
        "Maximum score change that still counts as a plateau between review cycles. Default: 0.0."
    ),
    "review.loop_exit_policy.score_plateau_min_review_cycles": (
        "Minimum review cycles before score-plateau detection is considered. Default: 2."
    ),
    "review.loop_exit_policy.unverifiable_accept_after_cycles": (
        "Allow acceptance after this many cycles when findings are unverifiable rather than fixable. Default: 1."
    ),
    "review.revision_integrity.plan_shrinkage_block_threshold": (
        "Block a revision when plan shrinkage exceeds this threshold. Leave at 0.0 to disable the block. Default: 0.0."
    ),
    "runtime.platform.fd_soft_limit_minimum": (
        "Minimum file-descriptor soft limit Obra tries to enforce at runtime. Default: 1024."
    ),
    "story0.auto_approve": (
        "Automatically approve Story0 install and setup actions that would otherwise require confirmation. Disabled by default."
    ),
    "story0.package_manager_preference.go": (
        "Preferred Go package manager for Story0 environment setup. Use \"auto\" to let Obra detect the right tool. Default: \"auto\"."
    ),
    "validation.quality.enabled": (
        "Enable validation-stage quality checks. Enabled by default."
    ),
    "validation.response.check_code_blocks_closed": (
        "Require generated responses to close fenced code blocks correctly. Enabled by default."
    ),
    "validation.response.check_completeness": (
        "Check generated responses for obvious truncation or missing required sections. Enabled by default."
    ),
    "workflow.budgets.progress.stall_detection_enabled": (
        "Detect workflow stalls when progress stops advancing. Enabled by default."
    ),
    "workflow.drift_detection.enabled": (
        "Detect workflow drift between planned and actual execution. Enabled by default."
    ),
    "workflow.max_turns.by_obra_task_type.EPIC": (
        "Maximum allowed turns for EPIC work items. Default: 150."
    ),
    "workflow.max_turns.by_obra_task_type.STORY": (
        "Maximum allowed turns for STORY work items. Default: 100."
    ),
    "workflow.max_turns.by_obra_task_type.SUBTASK": (
        "Maximum allowed turns for SUBTASK work items. Default: 50."
    ),
    "workflow.max_turns.by_obra_task_type.TASK": (
        "Maximum allowed turns for TASK work items. Default: 100."
    ),
    "workflow.turn_calculation.adaptive_learning.min_similar_tasks": (
        "Minimum number of similar historical tasks required before adaptive turn learning is used. Default: 10."
    ),
    "workflow.turn_calculation.adaptive_learning.percentile": (
        "Historical percentile used when estimating turns from similar tasks. Default: 95."
    ),
    "workflow.turn_calculation.adaptive_learning.safety_margin": (
        "Extra safety margin added to adaptive turn estimates. Default: 0.2."
    ),
    "workflow.turn_calculation.token_aware.historical_window_days": (
        "How many days of historical runs to consider for token-aware turn estimates. Default: 30."
    ),    # END FALLBACK CONFIG DESCRIPTIONS
    # BEGIN AUTO-SEEDED CONFIG DESCRIPTIONS
    "advanced.audit.destructive_operations_file": (
        "Audit log file for destructive operations (JSONL format). Default: 'logs/destructive_operations_audit.jsonl'."
    ),
    "advanced.debug.enabled": (
        "Enable debug mode. Default: false."
    ),
    "advanced.debug.save_interactions": (
        "Save all interactions for debugging. Default: true."
    ),
    "advanced.debug.verbose_logging": (
        "Extra verbose logging. Default: false."
    ),
    "advanced.llm_logging.preview_enabled": (
        "Include prompt/response previews in llm_call events. Default: true."
    ),
    "advanced.llm_logging.preview_max_prompt_chars": (
        "Maximum characters to include from prompt (truncated if longer). Default: 500."
    ),
    "advanced.llm_logging.preview_max_response_chars": (
        "Maximum characters to include from response (truncated if longer). Default: 1000."
    ),
    "advanced.llm_logging.stream_chunks_enabled": (
        "Enable streaming chunk logging (disabled by default for performance). Default: false."
    ),
    "advanced.logging.backup_count": (
        "Number of backup files to keep. Default: 5."
    ),
    "advanced.logging.file": (
        "Log file path. Default: 'logs/orchestrator.log'."
    ),
    "advanced.logging.level": (
        "Log level: DEBUG, INFO, WARNING, ERROR, CRITICAL. Default: 'INFO'."
    ),
    "advanced.logging.max_bytes": (
        "Max log file size (10MB). Default: 10485760."
    ),
    "advanced.metrics.config_initialized": (
        "Config initialization tracking flag (auto-set true after first config init) Tracks when config was auto-initialized from bundled default_config.yaml. Default: false."
    ),
    "advanced.metrics.display_on_completion": (
        "Display summary in terminal when work unit completes (epic/story/milestone). Default: true."
    ),
    "advanced.metrics.file_format": (
        "File format for saved reports (generates both MD and JSON when true). Default: 'json'."
    ),
    "advanced.metrics.first_run_explainer_shown": (
        "First-run explainer shown flag (auto-set true after first display) Shows educational footer explaining what the metrics mean. Default: false."
    ),
    "advanced.metrics.min_tasks_for_report": (
        "Minimum tasks in work unit before showing report (suppress for trivial work). Default: 1."
    ),
    "advanced.metrics.reports_dir": (
        "Reports directory (relative to project root). Default: '.obra/reports'."
    ),
    "advanced.metrics.save_to_file": (
        "Save report files to .obra/reports/. Default: true."
    ),
    "advanced.metrics.verbosity": (
        "Verbosity level: minimal (~8 lines), standard (~15 lines), detailed (~25 lines). Default: 'standard'."
    ),
    "agent.codex.approval_mode": (
        "Approval policy: suggest, auto-edit, full-auto. Default: 'full-auto'."
    ),
    "agent.codex.bypass_sandbox": (
        "Bypass sandbox restrictions (DANGEROUS). Default: false."
    ),
    "agent.codex.command": (
        "Codex CLI command (or full path). Default: 'codex'."
    ),
    "agent.codex.model": (
        "Model: null = auto-select (RECOMMENDED). Default: null."
    ),
    "agent.codex.skip_git_check": (
        "Allow non-git directories. Default: true."
    ),
    "agent.codex.timeout_response": (
        "Seconds to wait for response (2 hours). Default: 7200."
    ),
    "agent.codex.workspace_dir": (
        "Workspace directory for agent. Default: './workspace'."
    ),
    "agent.gemini.auto_approve": (
        "Auto-approve all actions (--yolo flag). Default: true."
    ),
    "agent.gemini.command": (
        "Gemini CLI command (or full path: /usr/local/bin/gemini). Default: 'gemini'."
    ),
    "agent.gemini.model": (
        "Model: null = auto-select (RECOMMENDED). Default: null."
    ),
    "agent.gemini.timeout_response": (
        "Seconds to wait for response (2 hours). Default: 7200."
    ),
    "agent.gemini.verify_cli": (
        "Verify CLI is available on initialization. Default: true."
    ),
    "agent.gemini.workspace_dir": (
        "Workspace directory for agent. Default: './workspace'."
    ),
    "agent.local.command": (
        "Claude Code CLI command (or full path). Default: 'claude'."
    ),
    "agent.local.timeout_ready": (
        "Seconds to wait for agent ready signal. Default: 30."
    ),
    "agent.local.timeout_response": (
        "Seconds to wait for response (30 minutes). Default: 1800."
    ),
    "agent.local.workspace_dir": (
        "Workspace directory for agent. Default: './workspace'."
    ),
    "agent.max_retries": (
        "Maximum retry attempts on failure. Default: 3."
    ),
    "agent.timeout": (
        "Default timeout for agent operations (30 minutes for complex coding tasks). Default: 1800."
    ),
    "agent.workspace_path": (
        "Agent workspace directory. Default: './workspace'."
    ),
    "agents.code_review": (
        "Architecture/quality review. Default: true."
    ),
    "agents.doc_audit": (
        "Documentation audits (ROT checks). Default: false."
    ),
    "agents.rca": (
        "Root cause analysis agent. Default: true."
    ),
    "agents.security": (
        "Security audits (OWASP scanning) - enterprise opt-in. Default: false."
    ),
    "agents.test_exec": (
        "Run tests during review. Default: true."
    ),
    "agents.test_gen": (
        "Intelligent test generation. Default: true."
    ),
    "api.client.default_timeout_s": (
        "Default timeout for API calls (minimum 120s per Rule 22). Default: 120."
    ),
    "auth.oauth.poll_interval_s": (
        "Polling interval for OAuth status checks (seconds). Default: 0.1."
    ),
    "auth.oauth.thread_join_timeout_s": (
        "Timeout for thread cleanup during OAuth flow (seconds). Default: 1.0."
    ),
    "automation_mode": (
        "off | guided | auto_safe | auto_full (default: auto_full). Default: 'auto_full'."
    ),
    "breakpoints.auto_resolve_timeout": (
        "Auto-resolve timeout (seconds, 0 = wait forever). Default: 300."
    ),
    "breakpoints.enabled": (
        "Enable breakpoint system. Default: true."
    ),
    "breakpoints.triggers.validation_failed.max_retries": (
        "Trigger after this many validation failures. Default: 3."
    ),
    "checkpoint_manager.enabled": (
        "Enable checkpoint manager. Default: true."
    ),
    "checkpoint_manager.storage_path": (
        "Checkpoint storage directory. Default: '.obra/memory/checkpoints'."
    ),
    "clarification.auto_archive": (
        "Auto-archive on startup (requires manual trigger for now). Default: false."
    ),
    "clarification.loop.enabled": (
        "Enable clarification loop for quality refinement. Default: true."
    ),
    "clarification.loop.max_iterations": (
        "Maximum iterations before stopping (per PRD default). Default: 3."
    ),
    "clarification.loop.quality_delta_threshold": (
        "Stop if improvement < 5% (diminishing returns). Default: 0.05."
    ),
    "clarification.loop.target_quality": (
        "Quality score to achieve for threshold_reached termination. Default: 0.8."
    ),
    "clarification.retention_days": (
        "Days to keep before archiving. Default: 30."
    ),
    "cli.cache.critical_threshold_mb": (
        "Critical threshold for cache size (MB). Default: 1000."
    ),
    "cli.cache.warn_threshold_mb": (
        "Warn when cache size exceeds this (MB). Default: 500."
    ),
    "cli.cleanup.runtime_log_backup_count": (
        "Number of rotated backups to keep per unmanaged log. Default: 3."
    ),
    "cli.cleanup.runtime_log_max_size_bytes": (
        "10MB threshold before rotating hybrid/session logs. Default: 10485760."
    ),
    "cli.force_exit_threshold": (
        "Third+ Ctrl+C total bypasses countdown. Default: 3."
    ),
    "cli.force_quit_window_s": (
        "Time window for force quit detection (seconds). Default: 3.0."
    ),
    "cli.interrupt_threshold": (
        "Second Ctrl+C within window triggers force quit. Default: 2."
    ),
    "cli.retry.backoff_multiplier": (
        "Exponential backoff multiplier (2s, 4s, 8s). Default: 2."
    ),
    "cli.retry.initial_delay_s": (
        "Initial retry delay in seconds. Default: 2."
    ),
    "cli.retry.max_attempts": (
        "Maximum retry attempts for transient failures. Default: 3."
    ),
    "config_explorer.notification_timeout_s": (
        "Timeout for notification display (seconds). Default: 10."
    ),
    "context.max_tokens": (
        "Fallback when model context window unknown. Default: 100000."
    ),
    "context.summarization.enabled": (
        "Summarize old context when limit reached. Default: true."
    ),
    "context.summarization.keep_recent": (
        "Keep this many recent interactions unsummarized. Default: 5."
    ),
    "database.backend": (
        "Default: standalone CLI mode. Default: 'sqlalchemy'."
    ),
    "database.echo": (
        "Log SQL queries (set true for debugging). Default: false."
    ),
    "database.max_overflow": (
        "Max overflow connections. Default: 20."
    ),
    "database.pool_size": (
        "Connection pool size. Default: 10."
    ),
    "database.schema.auto_migrate": (
        "Auto-apply pending migrations on startup. Default: true."
    ),
    "database.schema.require_exact": (
        "Require database exactly at HEAD revision. Default: false."
    ),
    "database.url": (
        "SQLite for simplicity. Default: 'sqlite:///data/orchestrator.db'."
    ),
    "dependencies.allow_cycles": (
        "Whether to allow circular dependencies. Default: false."
    ),
    "dependencies.fail_on_dependency_error": (
        "Fail task if dependency fails. Default: true."
    ),
    "dependencies.max_depth": (
        "Maximum dependency chain depth. Default: 10."
    ),
    "derivation.agent": (
        "Options: orch (orchestrator LLM), imp (implementation agent). Default: 'orch'."
    ),
    "derivation.approval_required": (
        "Require user approval for derived plans. Default: true."
    ),
    "derivation.auto_decompose.failure_threshold": (
        "Trigger decomposition after N failed attempts. Default: 3."
    ),
    "derivation.auto_decompose.max_depth": (
        "Maximum decomposition depth. Default: 3."
    ),
    "derivation.budget.decompose_threshold": (
        "Trigger decomposition at 80% budget consumption. Default: 0.8."
    ),
    "derivation.budget.min_subtask_ratio": (
        "Minimum 10% of budget for subtasks. Default: 0.1."
    ),
    "derivation.budget.warning_threshold": (
        "Warn at 60% budget consumption. Default: 0.6."
    ),
    "derivation.epic_item_rederive_threshold": (
        "Re-derive epic items if count exceeds this threshold. Default: 30."
    ),
    "derivation.epic_output_token_limit": (
        "Estimated-token limit for epic derivation (safety net; item count is primary guard). Default: 12000."
    ),
    "derivation.exploration_lookback_minutes": (
        "Minutes to look back when exploring prior context (3 hours). Default: 180."
    ),
    "derivation.hierarchy.max_depth": (
        "Epic (0) -> Story (1) -> Task (2) -> Subtask (3). Default: 4."
    ),
    "derivation.hierarchy.story.closeout_min_rigor": (
        "Minimum resolved rigor posture for close-out injection. Default: 'thorough'."
    ),
    "derivation.hierarchy.story.closeout_min_size": (
        "Minimum objective size for close-out injection. Default: 'moderate'."
    ),
    "derivation.hierarchy.story.forbid_compound_titles": (
        "Options: trivial, simple, moderate, complex Legacy fallback only when resolved rigor is unavailable. Default: true."
    ),
    "derivation.max_depth": (
        "How deep to decompose (Epic \u2192 Story \u2192 Task). Default: 3."
    ),
    "derivation.max_depth_warning_threshold": (
        "Warn when derivation depth reaches 80% of max_depth. Default: 0.8."
    ),
    "derivation.pipeline.stall_warning_threshold": (
        "Warn after N seconds of no output. Default: 30."
    ),
    "derivation.pipeline.step_timeouts.serialize": (
        "Step 3 timeout (seconds) - JSON serialization. Default: 90."
    ),
    "derivation.pipeline.step_timeouts.structure": (
        "Step 1 timeout (seconds) - structure derivation. Default: 180."
    ),
    "derivation.pipeline.step_timeouts.tasks": (
        "Step 2 timeout (seconds) - task breakdown. Default: 180."
    ),
    "derivation.plan_validation.auto_fix.enabled": (
        "Enable automatic fixing of common YAML issues. Default: true."
    ),
    "derivation.plan_validation.auto_fix.level": (
        "Fix level: common (safe patterns), aggressive (more patterns), off (disable). Default: 'common'."
    ),
    "derivation.plan_validation.auto_fix.log_details": (
        "Log detailed per-fix information at DEBUG level. Default: false."
    ),
    "derivation.plan_validation.auto_fix.max_attempts": (
        "Maximum sanitization attempts to prevent infinite loops. Default: 3."
    ),
    "derivation.plan_validation.use_pydantic": (
        "Use Pydantic schema validation instead of legacy multi-layer validator. Default: false."
    ),
    "derivation.preview.raw_response_limit": (
        "Character limit for raw LLM response preview. Default: 200."
    ),
    "derivation.preview.raw_response_warn_limit": (
        "Warn if raw response exceeds this character limit. Default: 10000."
    ),
    "derivation.preview.readme_limit": (
        "Character limit for README preview in derivation context. Default: 2000."
    ),
    "derivation.review_gate.strict": (
        "When true: fail if review requires changes but returns no valid plan. Default: true."
    ),
    "derivation.serialize.max_concurrent": (
        "Parallel workers for per-epic JSON serialization. Default: 4."
    ),
    "derivation.serialize.worker_delay_s": (
        "Delay (seconds) between starting each parallel worker. Default: 1.0."
    ),
    "derivation.sizing.llm.timeout_s": (
        "10 min minimum per Rule 22. Default: 600."
    ),
    "derivation.sizing.pre_filter.timeout_s": (
        "10 min minimum per Rule 22. Default: 600."
    ),
    "derivation.steps.step1_tier": (
        "Epic derivation needs strong reasoning (Opus). Default: 'high'."
    ),
    "derivation.steps.step2_tier": (
        "Story/task expansion needs strong reasoning (Opus). Default: 'high'."
    ),
    "derivation.steps.step3_tier": (
        "JSON serialization is mechanical (Sonnet sufficient). Default: 'fast'."
    ),
    "derivation.story_range": (
        "Non-strict per-epic story count target for Step 2. Default: '3-6'."
    ),
    "derivation.strict_story_range": (
        "Strict retry story count target for Step 2. Default: '2-4'."
    ),
    "derivation.strict_task_range": (
        "Strict retry task count target for Step 2. Default: '2-3'."
    ),
    "derivation.task.cost_budget_usd": (
        "Default cost budget per task (USD). Default: 0.5."
    ),
    "derivation.task.token_budget": (
        "Default token budget per task. Default: 100000."
    ),
    "derivation.task_range": (
        "Non-strict per-story task count target for Step 2. Default: '2-5'."
    ),
    "derivation.workflow.llm.timeout_s": (
        "Null inherits orchestration.timeouts.llm_call_s. Default: null."
    ),
    "display.celebration_mode": (
        "Show celebration banner when all epics complete with quality >= 70. Default: true."
    ),
    "display.limits.description_max_chars": (
        "Objective/description truncation limit. Default: 60."
    ),
    "display.limits.list_preview_max_items": (
        "Max items to show in list previews. Default: 10."
    ),
    "display.limits.note_max_chars": (
        "Status note truncation limit. Default: 50."
    ),
    "display.limits.objective_preview_max_chars": (
        "Long objective preview truncation limit. Default: 500."
    ),
    "display.limits.seconds_before_minutes": (
        "Time threshold for switching from Xs to Xm Ys format. Default: 60."
    ),
    "display.limits.summary_max_chars": (
        "Summary line truncation limit. Default: 80."
    ),
    "display.limits.title_max_chars": (
        "Epic/story title truncation limit. Default: 40."
    ),
    "display.spinner.accent_enabled": (
        "Subtle shimmer accent on spinner phrases. Default: true."
    ),
    "display.spinner.accent_highlight_color": (
        "7aa7ff\"  # Highlight color for shimmer accent. Default: '#7aa7ff'."
    ),
    "display.spinner.accent_highlight_gradient": (
        "Subtle gradient across highlight width. Default: true."
    ),
    "display.spinner.accent_highlight_width": (
        "Highlight width in characters. Default: 5."
    ),
    "display.spinner.accent_pause_max_s": (
        "Max pause between sweeps. Default: 9."
    ),
    "display.spinner.accent_pause_min_s": (
        "Min pause between sweeps. Default: 5."
    ),
    "display.spinner.accent_step_max_ms": (
        "Max step duration (ms) for short phrases. Default: 200."
    ),
    "display.spinner.accent_step_min_ms": (
        "Min step duration (ms) for long phrases. Default: 80."
    ),
    "display.spinner.accent_sweep_target_s": (
        "Target duration for one shimmer sweep. Default: 6."
    ),
    "display.spinner.enabled": (
        "Enable animated spinner during LLM calls. Default: true."
    ),
    "display.spinner.phrase_rotation_interval_s": (
        "Fallback seconds between phrase rotations. Default: 300."
    ),
    "display.spinner.phrase_rotation_max_s": (
        "Jittered rotation max (11 minutes). Default: 660."
    ),
    "display.spinner.phrase_rotation_min_s": (
        "Jittered rotation min (4 minutes). Default: 240."
    ),
    "display.spinner.refresh_rate_hz": (
        "Animation refresh rate. Default: 10."
    ),
    "documentation.archive.archive_dir": (
        "Archive destination. Default: 'docs/archive/development'."
    ),
    "documentation.archive.enabled": (
        "Enable automatic archiving. Default: true."
    ),
    "documentation.archive.patterns": (
        "File patterns to archive (glob syntax). Default: ['*_IMPLEMENTATION_PLAN.md', '*_COMPLETION_PLAN.md', '*_GUIDE.md']."
    ),
    "documentation.archive.source_dir": (
        "Source directory to scan. Default: 'docs/development'."
    ),
    "documentation.auto_maintain": (
        "Automatically create maintenance tasks (vs just notify). Default: true."
    ),
    "documentation.enabled": (
        "Master enable/disable switch for documentation maintenance. Default: false."
    ),
    "documentation.freshness_thresholds.critical": (
        "CHANGELOG, README (update within 30 days). Default: 30."
    ),
    "documentation.freshness_thresholds.important": (
        "Architecture docs, ADRs (update within 60 days). Default: 60."
    ),
    "documentation.freshness_thresholds.normal": (
        "Guides, design docs (update within 90 days). Default: 90."
    ),
    "documentation.task_config.assigned_agent": (
        "null = use platform default implementation executor. Default: null."
    ),
    "documentation.task_config.assigned_llm": (
        "null = use default LLM from llm.type. Default: null."
    ),
    "documentation.task_config.auto_execute": (
        "Require manual approval before execution. Default: false."
    ),
    "documentation.task_config.priority": (
        "Task priority (1-10, lower = higher priority). Default: 3."
    ),
    "documentation.triggers.epic_complete.auto_create_task": (
        "Automatically create task (vs notification only). Default: true."
    ),
    "documentation.triggers.epic_complete.enabled": (
        "Enable epic completion trigger. Default: true."
    ),
    "documentation.triggers.epic_complete.scope": (
        "Maintenance scope: lightweight | comprehensive | full_review. Default: 'lightweight'."
    ),
    "documentation.triggers.milestone_achieved.auto_create_task": (
        "Automatically create task. Default: true."
    ),
    "documentation.triggers.milestone_achieved.enabled": (
        "Enable milestone achievement trigger. Default: true."
    ),
    "documentation.triggers.milestone_achieved.scope": (
        "Always comprehensive for milestones. Default: 'comprehensive'."
    ),
    "documentation.triggers.periodic.auto_create_task": (
        "Automatically create task (vs notification only). Default: true."
    ),
    "documentation.triggers.periodic.enabled": (
        "Enable periodic freshness checks. Default: true."
    ),
    "documentation.triggers.periodic.interval_days": (
        "Check interval in days (7 = weekly, 30 = monthly). Default: 7."
    ),
    "documentation.triggers.periodic.scope": (
        "Maintenance scope: lightweight | comprehensive | full_review. Default: 'lightweight'."
    ),
    "documentation.triggers.version_bump.auto_create_task": (
        "Automatically create task. Default: true."
    ),
    "documentation.triggers.version_bump.enabled": (
        "Enable version bump trigger. Default: true."
    ),
    "documentation.triggers.version_bump.scope": (
        "Full review of all documentation. Default: 'full_review'."
    ),
    "episodic_memory.archive_after_days": (
        "Archive episodes older than 90 days. Default: 90."
    ),
    "episodic_memory.enabled": (
        "Enable episodic memory (long-term storage). Default: true."
    ),
    "episodic_memory.max_episodes": (
        "Maximum episodes to keep. Default: 100."
    ),
    "episodic_memory.storage_path": (
        "Episode storage directory. Default: '.obra/memory/episodes'."
    ),
    "episodic_memory.use_embeddings": (
        "Future: embedding-based similarity search. Default: false."
    ),
    "execution.mcp_servers.max_tools": (
        "Max tools across all MCP servers to avoid context budget exhaustion. Claude Code's practical limit is ~40 tools before quality degrades. Default: 40."
    ),
    "execution.quality.default_threshold": (
        "Default quality score threshold for plan acceptance (0.0-1.0). Default: 0.6."
    ),
    "execution.quality.generated_plan_threshold": (
        "Lower threshold for generated plans vs user-provided plans. Default: 0.4."
    ),
    "features.advanced_planning.auto_decompose": (
        "Auto-decompose on timeout. Default: true."
    ),
    "features.advanced_planning.drift_detection": (
        "Detect deviations from patterns. Default: true."
    ),
    "features.advanced_planning.pattern_library": (
        "Reusable workflow patterns. Default: true."
    ),
    "features.core_orchestration.enabled": (
        "Cannot be disabled - system will not function. Default: true."
    ),
    "features.documentation_governance.tracking.dg001_coupling": (
        "Doc-code coupling (DG-001). Default: true."
    ),
    "features.documentation_governance.tracking.issue_log": (
        "Manual testing log maintenance. Default: true."
    ),
    "features.intake.validation.enabled": (
        "Reject garbage objectives before wasting LLM calls. Default: true."
    ),
    "features.intake.validation.min_words": (
        "Minimum words required in objective. Default: 3."
    ),
    "features.integration_automation.enabled": (
        "Opt-in for automation. Default: false."
    ),
    "features.intent.quality_check.enabled": (
        "Check intent quality after enrichment. Default: true."
    ),
    "features.intent.quality_check.min_score": (
        "Minimum quality score (0.0-1.0) for enriched intent. Default: 0.5."
    ),
    "features.performance_control.budgets.max_turns.enabled": (
        "Disabled by default (use token budgets instead). Default: false."
    ),
    "features.performance_control.budgets.tokens.agent_budget": (
        "Claude Code tokens per task. Default: 150000."
    ),
    "features.performance_control.budgets.tokens.llm_budget": (
        "Qwen tokens per task. Default: 75000."
    ),
    "features.performance_control.checkpointing.manager.triggers.event": (
        "Event-based trigger. Default: true."
    ),
    "features.performance_control.checkpointing.manager.triggers.operation": (
        "Operation count trigger. Default: true."
    ),
    "features.performance_control.checkpointing.manager.triggers.threshold": (
        "Context usage trigger. Default: true."
    ),
    "features.performance_control.checkpointing.manager.triggers.time": (
        "Time-based (disabled by default). Default: false."
    ),
    "features.performance_control.checkpointing.verification": (
        "Expensive - disabled by default. Default: false."
    ),
    "features.performance_control.enabled": (
        "Default: enabled (standard preset). Default: true."
    ),
    "features.performance_control.memory.episodic_memory": (
        "Opt-in for long-term storage. Default: false."
    ),
    "features.performance_control.memory.learned_patterns": (
        "Opt-in for cross-session operational heuristics. Default: false."
    ),
    "features.performance_control.session_continuity.self_handoff": (
        "Advanced feature - disabled by default. Default: false."
    ),
    "features.saas_parity.collections.breakpoints": (
        "Events requiring human intervention. Default: true."
    ),
    "features.saas_parity.collections.checkpoints": (
        "State snapshots for rollback. Default: true."
    ),
    "features.saas_parity.collections.file_changes": (
        "Workspace file tracking. Default: true."
    ),
    "features.saas_parity.enabled": (
        "Default: enabled (all new collections active). Default: true."
    ),
    "features.user_experience.nl_commands.enabled": (
        "Opt-in (requires LLM). Default: false."
    ),
    "features.user_experience.smart_defaults.assumption_generation.cache_enabled": (
        "Cache LLM-generated assumptions. Default: true."
    ),
    "features.user_experience.smart_defaults.assumption_generation.llm_fallback": (
        "Fall back to LLM for unrecognized patterns. Default: true."
    ),
    "features.user_experience.smart_defaults.assumption_generation.pattern_confidence": (
        "Pattern confidence threshold (use pattern if above this). Default: 0.6."
    ),
    "features.user_experience.smart_defaults.assumption_generation.pattern_matching": (
        "Use pattern-based matching first (fast). Default: true."
    ),
    "features.user_experience.smart_defaults.interaction.allow_editing": (
        "Allow editing/customizing assumptions. Default: true."
    ),
    "features.user_experience.smart_defaults.interaction.show_attribution": (
        "Show attribution message when proceeding with defaults. Default: true."
    ),
    "features.user_experience.smart_defaults.interaction.show_rationale": (
        "Show assumption rationale by default. Default: true."
    ),
    "features.user_experience.smart_defaults.thresholds.auto_proceed": (
        ">0.7: READY - Proceed automatically (prompt has sufficient detail). Default: 0.7."
    ),
    "features.userplan.auto_decompose.enabled": (
        "Automatically break down large/complex tasks during derivation. Default: true."
    ),
    "features.userplan.enabled": (
        "Default: enabled (UserPlan pipeline active). Default: true."
    ),
    "features.userplan.hierarchical_derivation.enabled": (
        "Use hierarchical (Epic->Story->Task) derivation structure. Default: true."
    ),
    "features.userplan.quality_gate.enabled": (
        "Validate UserPlan quality before allowing derivation. Default: true."
    ),
    "features.userplan.require_persistence": (
        "Default: false (allow standalone operation). Default: false."
    ),
    "features.userplan.source_step_mapping.enabled": (
        "Enable automatic source_step_id assignment. Default: true."
    ),
    "features.userplan.source_step_mapping.timeout_s": (
        "Timeout for LLM classification call (10 min minimum per Rule 22). Default: 600."
    ),
    "file_tracking.max_file_size_bytes": (
        "10MB - maximum file size to track (skip larger files). Default: 10485760."
    ),
    "fix.batching.enabled": (
        "Default: batch issues by file. Set false for one-at-a-time (legacy). Default: true."
    ),
    "fix.batching.max_batch_size": (
        "Max issues per batch to avoid context overflow. Default: 5."
    ),
    "fix.batching.split_on_retry": (
        "Disable batching on server-initiated fix retries to isolate failures. Default: true."
    ),
    "fix.max_attempts_per_issue": (
        "ISSUE-HYBRID-044: Skip canonical issues after this many consecutive failures. Default: 2."
    ),
    "fix.max_failures_per_file": (
        "FIX-HYBRID-048: Skip all issues in a file after this many cumulative failures. Default: 4."
    ),
    "fix.test_gap.inference.confidence_threshold": (
        "Minimum confidence to accept inferred target. Default: 0.6."
    ),
    "fix.test_gap.inference.enabled": (
        "Use LLM inference to select a test file when missing. Default: true."
    ),
    "fix.test_gap.inference.max_candidates": (
        "Max candidate test files to consider. Default: 3."
    ),
    "fix.verification.auto_install": (
        "Auto-install missing verification tools (mode-derived). Default: true."
    ),
    "fix.verification.chain_order": (
        "Gated verification order. Default: ['lint', 'typecheck', 'security', 'tests']."
    ),
    "fix.verification.discovery_enabled": (
        "Use ToolingDiscovery to infer verification tools. Default: true."
    ),
    "fix.verification.discovery_force_refresh": (
        "Ignore cached tooling discovery results. Default: false."
    ),
    "fix.verification.early_exit": (
        "Stop the gated chain after the first failed check. Default: true."
    ),
    "fix.verification.failure_context_max_chars": (
        "Max chars of verification error output to propagate to retry prompt. Default: 500."
    ),
    "fix.verification.format_before_lint": (
        "Run safe file-scoped formatters before gated verification. Default: true."
    ),
    "fix.verification.install_policy": (
        "manifest_only | manifest_then_inferred | manifest_or_inferred. Default: 'manifest_or_inferred'."
    ),
    "fix.verification.install_target": (
        "project_local | existing_env_only | system. Default: 'project_local'."
    ),
    "fix.verification.max_retries": (
        "Max verification retries during FIX. Default: 3."
    ),
    "fix.verification.preflight.max_attempts": (
        "Max Story 0 verification-preflight retries before FIX proceeds without tools. Default: 2."
    ),
    "fix.verification.required": (
        "Require verification tools before FIX (default true). Default: true."
    ),
    "fix.verification.scope.hard_cap_diff_lines": (
        "Hard abort: revert when diff lines exceed this. Default: 500."
    ),
    "fix.verification.scope.hard_cap_files": (
        "Hard abort: revert when file count exceeds this. Default: 30."
    ),
    "fix.verification.scope.warn_diff_lines": (
        "Revert fix when diff lines (added+removed) exceed this. Default: 200."
    ),
    "fix.verification.scope.warn_files": (
        "Revert fix when modified file count exceeds this. Default: 10."
    ),
    "gateway.allow_public_bind": (
        "Require explicit opt-in before binding to non-loopback hosts. Default: false."
    ),
    "gateway.allowed_working_dir_base": (
        "Working directory must resolve within this base path. Default: '~/obra-projects'."
    ),
    "gateway.assistant.conversation_history.max_proposal_turns": (
        "Max recent proposal turns to include. Default: 10."
    ),
    "gateway.assistant.conversation_history.message_preview_chars": (
        "Chars to show per turn in history summary. Default: 80."
    ),
    "gateway.assistant.knowledge.max_document_bytes": (
        "100KB per document. Default: 102400."
    ),
    "gateway.assistant.knowledge.max_total_bytes": (
        "2MB total knowledge storage. Default: 2097152."
    ),
    "gateway.assistant.knowledge.token_budget": (
        "Token budget for knowledge section. Default: 2000."
    ),
    "gateway.assistant.logging.aggregate_backup_count": (
        "Number of rotated backups to keep. Default: 5."
    ),
    "gateway.assistant.logging.aggregate_max_bytes": (
        "10MB aggregate rotation threshold. Default: 10485760."
    ),
    "gateway.assistant.logging.enabled": (
        "Enable session logging. Default: true."
    ),
    "gateway.assistant.logging.include_full_messages": (
        "Log full message text. Default: true."
    ),
    "gateway.assistant.logging.include_system_prompt": (
        "Log full system prompt. Default: true."
    ),
    "gateway.assistant.logging.max_sessions": (
        "Max per-session files to keep. Default: 20."
    ),
    "gateway.assistant.logging.redact_screenshots": (
        "Replace screenshot data with placeholder. Default: true."
    ),
    "gateway.assistant.memory.mode_event_limit": (
        "Persisted mode-change events exposed to prompts. Default: 6."
    ),
    "gateway.assistant.memory.recent_turns": (
        "Raw turns kept in prompt memory. Default: 6."
    ),
    "gateway.assistant.memory.summary_message_chars": (
        "Preview chars per summarized turn. Default: 160."
    ),
    "gateway.assistant.memory.summary_turns": (
        "Older turns summarized into compact memory. Default: 12."
    ),
    "gateway.assistant.model.default_model": (
        "Default LLM model alias for assistant. Default: 'sonnet'."
    ),
    "gateway.assistant.model.default_provider": (
        "Default LLM provider. Default: 'anthropic'."
    ),
    "gateway.assistant.model.health_check_cache_ttl_s": (
        "Cache TTL for model health check results. Default: 300."
    ),
    "gateway.assistant.model.health_check_on_startup": (
        "Probe model health on gateway start. Default: true."
    ),
    "gateway.assistant.persistence.storage_path": (
        "Relative to OBRA runtime dir unless overridden. Default: 'assistant/threads.json'."
    ),
    "gateway.assistant.phase_detection.draft_instruction_threshold": (
        "Fraction lacking stage instructions to remain in draft. Default: 0.5."
    ),
    "gateway.assistant.phase_detection.enabled": (
        "Compute workflow development phase descriptor. Default: true."
    ),
    "gateway.assistant.phase_detection.min_stages_for_full_model": (
        "Small workflows collapse draft to enrich in compact model. Default: 3."
    ),
    "gateway.assistant.phase_detection.stable_run_threshold": (
        "Runs needed before stable-workflow guidance can trigger. Default: 3."
    ),
    "gateway.assistant.phase_detection.validate_min_run_count": (
        "Legacy \u2014 no longer used for phase detection (retained for config compat). Default: 1."
    ),
    "gateway.assistant.pipelines.bulk_template_timeout_s": (
        "Bulk template generation pipeline base timeout. Default: 600."
    ),
    "gateway.assistant.pipelines.compliance_audit_timeout_s": (
        "Compliance audit pipeline timeout. Default: 600."
    ),
    "gateway.assistant.pipelines.default_timeout_s": (
        "Base timeout for assistant pipeline executions. Default: 600."
    ),
    "gateway.assistant.pipelines.diagnostic_timeout_s": (
        "Diagnostic pipeline timeout. Default: 600."
    ),
    "gateway.assistant.pipelines.llm_model_tier": (
        "Canonical Obra model tier for assistant pipeline steps. Default: 'fast'."
    ),
    "gateway.assistant.pipelines.llm_reasoning_level": (
        "Optional reasoning override; default follows tier resolution. Default: 'default'."
    ),
    "gateway.assistant.pipelines.max_pipeline_sessions": (
        "Maximum concurrent background assistant pipeline sessions. Default: 10."
    ),
    "gateway.assistant.pipelines.operation_stale_after_s": (
        "Last-event age before a running assistant pipeline operation is marked stale. Default: 3900."
    ),
    "gateway.assistant.pipelines.per_step_timeout_budget_s": (
        "Per-step timeout budget; aligns with orchestration.timeouts.llm_call_s. Default: 3600."
    ),
    "gateway.assistant.pipelines.pipeline_session_eviction_ttl_seconds": (
        "Retain terminal pipeline sessions for reconnect/discovery. Default: 7200."
    ),
    "gateway.assistant.pipelines.self_review_auto_min_stage_count": (
        "Auto-trigger self-review at or above this stage count. Default: 5."
    ),
    "gateway.assistant.pipelines.self_review_timeout_s": (
        "Background scaffold self-review timeout. Default: 600."
    ),
    "gateway.assistant.pipelines.sse_heartbeat_interval_s": (
        "SSE keepalive interval during pipeline execution (seconds). Default: 15."
    ),
    "gateway.assistant.prompt_budget_tokens": (
        "Total system prompt token budget (floor; dynamic model-aware scaling may raise). Default: 16000."
    ),
    "gateway.assistant.prompt_sections.workflow_readiness_max_tokens": (
        "Max tokens allocated before section-local truncation. Default: 800."
    ),
    "gateway.assistant.prompt_sections.workflow_readiness_priority": (
        "Readiness section priority in token budget assembly. Default: 3."
    ),
    "gateway.assistant.readiness.first_use_intro_enabled": (
        "Reserve config seam for first-use guided copy. Default: true."
    ),
    "gateway.assistant.readiness.preflight_check_enabled": (
        "Reserve config seam for future run preflight checks. Default: true."
    ),
    "gateway.assistant.readiness.recap_enabled": (
        "Enable workflow readiness recap section. Default: true."
    ),
    "gateway.assistant.readiness.recap_max_tokens": (
        "Keep assistant recap concise after readiness responses. Default: 150."
    ),
    "gateway.assistant.readiness.seed_alignment_min_keyword_matches": (
        "Minimum deterministic keyword overlap to map a seed requirement to a stage. Default: 2."
    ),
    "gateway.assistant.retention.archive_after_days": (
        "Auto-archive stale active threads. Default: 30."
    ),
    "gateway.assistant.retention.delete_after_days": (
        "Auto-delete stale archived threads. Default: 180."
    ),
    "gateway.assistant.retention.max_active_threads": (
        "Oldest active threads auto-archive beyond this count. Default: 20."
    ),
    "gateway.assistant.revision_history.max_revisions": (
        "Max workflow revisions to include. Default: 5."
    ),
    "gateway.assistant.run_timeline.max_events": (
        "Max run replay events to include. Default: 10."
    ),
    "gateway.assistant.screenshot.fallback_quality": (
        "Fallback quality if oversized. Default: 0.5."
    ),
    "gateway.assistant.screenshot.fallback_scale": (
        "Fallback scale if oversized. Default: 0.3."
    ),
    "gateway.assistant.screenshot.initial_scale": (
        "Initial html2canvas scale. Default: 0.5."
    ),
    "gateway.assistant.screenshot.jpeg_quality": (
        "Initial JPEG quality. Default: 0.7."
    ),
    "gateway.assistant.screenshot.max_bytes": (
        "200KB max screenshot size. Default: 204800."
    ),
    "gateway.assistant.stage_detail.max_dependency_chain_stages": (
        "Max stages in dependency chain rendering. Default: 20."
    ),
    "gateway.assistant.strategy.design_guidance_max_stages": (
        "Max stages to trigger design guidance mode. Default: 3."
    ),
    "gateway.auth_tokens": (
        "Additional bearer tokens: [{token, scopes: [read|operate|admin], label}]. Default: []."
    ),
    "gateway.batch_max_concurrency": (
        "Max concurrent item launches for workflow-run batch requests. Default: 10."
    ),
    "gateway.cors_allow_credentials": (
        "Whether CORS responses allow credentials when origins are safe. Default: true."
    ),
    "gateway.cors_origins": (
        "Allowed CORS origins (only used when enable_cors is true). Default: ['*']."
    ),
    "gateway.desktop.monitor_interval_s": (
        "Gateway health monitor poll interval. Default: 3."
    ),
    "gateway.desktop.path_prefixes": (
        "Finder-launched PATH augmentation prefixes for provider CLI discovery. "
        "Entries starting with '~' are expanded against the spawning user's home. "
        "Default: ['/opt/homebrew/bin', '/usr/local/bin', '~/.local/bin', "
        "'~/.claude/local', '~/.npm-global/bin']."
    ),
    "gateway.desktop.port_scan_end": (
        "End of port scan range for desktop gateway. Default: 18800."
    ),
    "gateway.desktop.port_scan_start": (
        "Start of port scan range for desktop gateway. Default: 18790."
    ),
    "gateway.desktop.restart_backoff_s": (
        "Delay before restarting crashed gateway. Default: 2."
    ),
    "gateway.desktop.restart_failure_window_s": (
        "Time window for counting restart failures. Default: 60."
    ),
    "gateway.desktop.restart_max_attempts": (
        "Max restart attempts within failure window. Default: 3."
    ),
    "gateway.desktop.shutdown_timeout_s": (
        "Grace period before SIGKILL on gateway shutdown. Default: 5."
    ),
    "gateway.desktop.stable_window_s": (
        "Uptime before crash counter resets. Default: 30."
    ),
    "gateway.enable_app_rate_limit": (
        "Enable in-gateway per-IP token-bucket throttling. Default: true."
    ),
    "gateway.enable_cors": (
        "Enable CORS middleware for cross-origin requests. Default: false."
    ),
    "gateway.escalation_timeout_s": (
        "Max wait for escalation decision before auto-resolve (seconds). Default: 300."
    ),
    "gateway.host": (
        "Gateway server bind address. Default: '127.0.0.1'."
    ),
    "gateway.idempotency_key_ttl_s": (
        "Retention window for workflow-run idempotency keys. Default: 3600."
    ),
    "gateway.logs_expose_absolute_paths": (
        "Expose absolute host log file paths in gateway payloads. Default: false."
    ),
    "gateway.logs_session_cookie_name": (
        "HttpOnly cookie name for gateway log-viewer browser sessions. Default: 'obra_logs_session'."
    ),
    "gateway.logs_session_cookie_secure": (
        "Set true when served behind TLS termination. Default: false."
    ),
    "gateway.logs_session_ttl_s": (
        "Gateway log-viewer browser session TTL in seconds. Default: 900."
    ),
    "gateway.logs_stream_idle_timeout_s": (
        "Maximum allowed stream connection age before forced reconnect. Default: 900."
    ),
    "gateway.logs_stream_max_clients_per_ip": (
        "Max concurrent log stream clients per client IP. Default: 20."
    ),
    "gateway.logs_stream_max_clients_total": (
        "Max concurrent log stream clients across all IPs. Default: 100."
    ),
    "gateway.max_event_queue_size": (
        "Maximum queued events per session before oldest events are dropped. Default: 1000."
    ),
    "gateway.max_objective_length": (
        "Maximum objective length in characters. Default: 10000."
    ),
    "gateway.max_project_id_length": (
        "Maximum project_id length in characters. Default: 256."
    ),
    "gateway.max_sessions": (
        "Maximum concurrent orchestration sessions. Default: 5."
    ),
    "gateway.max_ws_connections_per_ip": (
        "Max concurrent WebSocket connections per client IP. Default: 20."
    ),
    "gateway.max_ws_connections_total": (
        "Max concurrent WebSocket connections across all clients. Default: 200."
    ),
    "gateway.onboarding.auth_check_timeout_s": (
        "Timeout for provider auth status check. Default: 5."
    ),
    "gateway.onboarding.auth_timeout_s": (
        "Overall auth flow timeout (user completing OAuth). Default: 300."
    ),
    "gateway.onboarding.banner_poll_interval_s": (
        "Interval for credential health banner polling. Default: 60."
    ),
    "gateway.onboarding.detection_timeout_s": (
        "Timeout for provider binary detection subprocess. Default: 5."
    ),
    "gateway.onboarding.health_cache_ttl_s": (
        "TTL for cached provider health check results. Default: 30."
    ),
    "gateway.onboarding.ready_retry_interval_s": (
        "Retry interval when waiting for gateway readiness. Default: 2."
    ),
    "gateway.onboarding.status_poll_interval_s": (
        "Interval for polling provider auth completion. Default: 30."
    ),
    "gateway.onboarding.success_dwell_s": (
        "Dwell time showing success before auto-advancing. Default: 2."
    ),
    "gateway.output_delivery_retry_backoff_schedule": (
        "Retry delays for output delivery after 5xx responses. Default: [1, 5, 30]."
    ),
    "gateway.output_delivery_timeout_s": (
        "Per-attempt timeout for platform-managed output delivery. Default: 10."
    ),
    "gateway.pagination_default_limit": (
        "Default page size for gateway list routes when pagination is requested. Default: 50."
    ),
    "gateway.pagination_max_limit": (
        "Maximum page size for gateway list routes. Default: 200."
    ),
    "gateway.port": (
        "Gateway server port. Default: 18790."
    ),
    "gateway.profile": (
        "Gateway profile: standard or private-automation. Default: 'standard'."
    ),
    "gateway.public_bind_tls_terminated": (
        "Acknowledge TLS is terminated by trusted edge before public bind. Default: false."
    ),
    "gateway.rest_rate_limit_burst": (
        "Additional REST burst capacity per client IP. Default: 60."
    ),
    "gateway.rest_rate_limit_per_minute": (
        "Sustained REST request rate per client IP. Default: 120."
    ),
    "gateway.session_eviction_ttl_seconds": (
        "Time to retain terminal sessions before eviction (seconds). Default: 3600."
    ),
    "gateway.session_isolation": (
        "Session execution model: \"thread\" (in-process) or \"process\" (subprocess isolation). Default: 'thread'."
    ),
    "gateway.session_timeout_s": (
        "Max runtime before gateway watchdog cancels a running session. Default: 7200."
    ),
    "gateway.studio_launch_token_ttl_s": (
        "One-time `obra studio` browser bootstrap handoff lifetime. Default: 120."
    ),
    "gateway.studio_session_cookie_name": (
        "HttpOnly cookie name for packaged Workflow Studio browser sessions. Default: 'obra_studio_session'."
    ),
    "gateway.studio_session_cookie_secure": (
        "Set true when Workflow Studio is served behind TLS termination. Default: false."
    ),
    "gateway.studio_session_ttl_s": (
        "Workflow Studio browser session TTL in seconds (12 hours). Default: 43200."
    ),
    "gateway.transcription.max_audio_bytes": (
        "Maximum accepted voice upload size in bytes (25 MiB). Default: 26214400."
    ),
    "gateway.transcription.model_size": (
        "faster-whisper model size to lazy-load on first transcription. Default: 'base'."
    ),
    "gateway.transcription.provider": (
        "Local speech-to-text provider for Workflow Studio voice input. Default: 'local-whisper'."
    ),
    "gateway.trusted_proxy_cidrs": (
        "Proxy source CIDRs allowed to supply forwarded client IP headers. Default: []."
    ),
    "gateway.webhooks_allow_private_networks": (
        "Allow webhook callbacks to private-network HTTPS targets. Default: false."
    ),
    "gateway.webhooks_cleanup_interval_s": (
        "Background cleanup interval for expired webhook deletion. Default: 60."
    ),
    "gateway.webhooks_delivery_timeout_s": (
        "Per-attempt webhook delivery timeout in seconds. Default: 10."
    ),
    "gateway.webhooks_failure_threshold_disabled": (
        "Consecutive failures before webhook status becomes disabled. Default: 20."
    ),
    "gateway.webhooks_failure_threshold_failing": (
        "Consecutive failures before webhook status becomes failing. Default: 5."
    ),
    "gateway.webhooks_max_per_owner": (
        "Max webhook registrations scoped to one authenticated gateway owner. Default: 50."
    ),
    "gateway.webhooks_retention_seconds": (
        "Expired webhook retention window measured from expired_at. Default: 86400."
    ),
    "gateway.webhooks_retry_backoff_schedule": (
        "Retry delays after a failed attempt in seconds. Default: [1, 5, 30]."
    ),
    "gateway.workflow_storage": (
        "Workflow storage mode: cloud (default) or local (offline-only). Default: 'cloud'."
    ),
    "gateway.workflow_events.heartbeat_seconds": (
        "Server heartbeat interval for canonical workflow event-stream clients. Default: 15."
    ),
    "gateway.workflow_events.stale_after_missed_heartbeats": (
        "Mark event-stream clients stale after this many missed heartbeat ACKs. Default: 3."
    ),
    "gateway.workflow_changes.proposal_ttl_seconds": (
        "Time in seconds before an unaccepted proposed workflow change is auto-revoked. Default: 1800."
    ),
    "gateway.workflow_changes.retention_days": (
        "Days to retain workflow change-log entries before archival or cleanup. Default: null (retain indefinitely)."
    ),
    "gateway.workspace_cleanup": (
        "Automatically clean up per-run workspace directories when session completes. Set to retain to preserve run directories. Default: 'on_complete'."
    ),
    "gateway.workspace_isolation": (
        "Workspace isolation mode: off (shared project dir) or per_run (isolated run directories). Default: 'off'."
    ),
    "gateway.ws_auth_timeout_s": (
        "Max seconds to wait for first WebSocket auth frame. Default: 5."
    ),
    "gateway.ws_max_message_bytes": (
        "Max inbound WebSocket message size in bytes (1 MiB). Default: 1048576."
    ),
    "gateway.ws_rate_limit_burst": (
        "Additional WebSocket method-call burst capacity per client IP. Default: 120."
    ),
    "gateway.ws_rate_limit_per_minute": (
        "Sustained WebSocket method-call rate per client IP. Default: 240."
    ),
    "git.auto_commit": (
        "Automatically commit after task completion. Default: true."
    ),
    "git.auto_pr": (
        "Automatically create pull requests. Default: false."
    ),
    "git.branch_prefix": (
        "Branch name prefix. Default: 'obra/task-'."
    ),
    "git.commit_message_template": (
        "Commit message style. Default: 'semantic'."
    ),
    "git.commit_strategy": (
        "per_task | per_milestone | manual. Default: 'per_task'."
    ),
    "git.create_branch": (
        "Create branch per task. Default: true."
    ),
    "git.enabled": (
        "Enable git auto-integration (opt-in). Default: false."
    ),
    "git.include_metadata": (
        "Include Obra metadata in commits. Default: true."
    ),
    "git.pr_base_branch": (
        "Base branch for PRs. Default: 'main'."
    ),
    "handlers.clarification.max_iterations": (
        "Maximum number of clarification iterations. Default: 3."
    ),
    "handlers.clarification.quality_delta_threshold": (
        "Quality delta threshold - minimum improvement to continue iteration. Default: 0.05."
    ),
    "handlers.clarification.target_quality": (
        "Target quality score to achieve (0.0-1.0). Default: 0.8."
    ),
    "handlers.derivation.pre_filter_timeout_s": (
        "Timeout for pre-filter LLM operations (relevance checks) 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.derivation.sizing_gate_timeout_s": (
        "Timeout for sizing gate LLM operations (complexity assessment) 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.derive.alignment_timeout_s": (
        "Timeout for alignment validation between user intent and execution plan 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.derive.cache_max_age_s": (
        "Cache duration for derivation results (seconds). Default: 3600."
    ),
    "handlers.derive.complexity_thresholds.medium_max_steps": (
        "Maximum steps to classify as medium complexity task. Default: 8."
    ),
    "handlers.derive.complexity_thresholds.simple_max_steps": (
        "Maximum steps to classify as simple task. Default: 3."
    ),
    "handlers.derive.llm_timeout_s": (
        "Null inherits orchestration.timeouts.llm_call_s. Default: null."
    ),
    "handlers.derive.mapping_timeout_s": (
        "Timeout for mapping user intent to execution plan 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.derive.max_relevant_files": (
        "Maximum number of relevant files to include in derivation context. Default: 10."
    ),
    "handlers.derive.max_retries": (
        "Maximum retry attempts for derivation operations. Default: 3."
    ),
    "handlers.derive.model_tier": (
        "Model tier for derive stage (fast/medium/high) Controls reasoning effort via reasoning_role_tier_defaults on the model. Default: 'high'."
    ),
    "handlers.derive.raw_response_log_preview": (
        "Character limit for raw LLM response preview in logs (truncation point). Default: 200."
    ),
    "handlers.escalate.default_action": (
        "FIX-HYBRID-038: Default action when prompt times out or in non-interactive mode. Values: force_complete, continue_fixing, skip_issues, abandon. Default: 'force_complete'."
    ),
    "handlers.escalate.description_truncation_chars": (
        "Character limit for description truncation in escalation messages. Default: 57."
    ),
    "handlers.escalate.prompt_timeout_s": (
        "FIX-HYBRID-038: Prompt timeout for interactive escalation decisions. If user doesn't respond within this many seconds, the default_action is taken. 0 = no timeout (block forever). Only applies to interactive terminals. Default: 300."
    ),
    "handlers.escalate.timeout_s": (
        "Timeout for escalation operations 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.examine.bypass_sandbox": (
        "Whether to bypass sandbox restrictions for examine operations. Default: false."
    ),
    "handlers.examine.max_retries": (
        "Maximum retry attempts for examine operations. Default: 3."
    ),
    "handlers.examine.model_tier": (
        "Orchestrator tier for examination (fast, medium, high). Default: 'high'."
    ),
    "handlers.execute.min_file_size_bytes": (
        "Minimum file size to process (bytes) - skip files below this threshold. Default: 100."
    ),
    "handlers.execute.parallel_max_workers": (
        "Number of parallel workers for execution batch processing. Default: 4."
    ),
    "handlers.execute.subprocess_timeout_s": (
        "Timeout for subprocess operations (seconds). Default: 30."
    ),
    "handlers.execute.thread_join_timeout_s": (
        "Timeout for thread join operations (seconds). Default: 5."
    ),
    "handlers.execute.verification_timeout_s": (
        "Timeout for post-execute verification commands such as tests and lint (seconds). Default: 120."
    ),
    "handlers.fix.model_tier": (
        "Implementation tier for fix agents (fast, medium, high). Default: 'high'."
    ),
    "handlers.intent.bypass_sandbox": (
        "Whether to bypass sandbox restrictions for intent operations. Default: false."
    ),
    "handlers.intent.max_retries": (
        "Maximum retry attempts for intent operations. Default: 3."
    ),
    "handlers.intent.model_tier": (
        "Orchestrator tier for intent generation (fast, medium, high). Default: 'high'."
    ),
    "handlers.intent.rate_limit_max_retries": (
        "Maximum retry attempts for rate-limited operations. Default: 3."
    ),
    "handlers.review.max_retries": (
        "Maximum retry attempts for review operations. Default: 2."
    ),
    "handlers.review.model_tier": (
        "Implementation tier for review agents (fast, medium, high). Default: 'high'."
    ),
    "handlers.review.timeout_s": (
        "Timeout for review operations 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.revise.bypass_sandbox": (
        "Whether to bypass sandbox restrictions for revise operations. Default: false."
    ),
    "handlers.revise.max_retries": (
        "Maximum retry attempts for revise operations. Default: 3."
    ),
    "handlers.revise.model_tier": (
        "Orchestrator tier for revision (fast, medium, high). Default: 'high'."
    ),
    "handlers.story0.docker_timeout_s": (
        "Timeout for Docker operations (container start, health checks). Default: 600."
    ),
    "handlers.story0.llm_schema_timeout_s": (
        "Null inherits orchestration.timeouts.llm_call_s. Default: null."
    ),
    "handlers.story0.max_retries": (
        "Maximum retry attempts for story0 operations. Default: 2."
    ),
    "handlers.story0.model_tier": (
        "Orchestrator tier for story0 derivation (fast, medium, high) Should match planning.enrichment.stages.derive.model_tier. Default: 'high'."
    ),
    "handlers.story0.service_poll_interval_s": (
        "Service health check polling interval (seconds). Default: 0.2."
    ),
    "handlers.story0.service_poll_max_attempts": (
        "Maximum polling attempts for service readiness checks. Default: 20."
    ),
    "handlers.story0.timeout_s": (
        "Timeout for story0 operations (service setup, environment setup, etc.) 10 min minimum per Rule 22. Default: 600."
    ),
    "handlers.template_edit.max_retries": (
        "Maximum retry attempts for template edit operations. Default: 2."
    ),
    "handlers.tooling_discovery.timeout_s": (
        "Timeout for tooling discovery LLM operations 10 min minimum per Rule 22. Default: 600."
    ),
    "hybrid.polling.backoff_multiplier": (
        "Multiplier for exponential backoff. Default: 2.0."
    ),
    "hybrid.polling.base_delay_s": (
        "Initial delay between polls (seconds). Default: 1.0."
    ),
    "hybrid.polling.max_delay_s": (
        "Maximum delay between polls (seconds). Default: 30.0."
    ),
    "intake.min_words": (
        "Minimum word count for valid objective/input. Default: 3."
    ),
    "intent.chunking.overlap_tokens": (
        "Overlap between chunks for context continuity. Default: 2000."
    ),
    "intent.chunking.size_tokens": (
        "Chunk size in tokens. Default: 80000."
    ),
    "intent.chunking.warning_threshold": (
        "Warn at 80% of token budget. Default: 0.8."
    ),
    "intent.context.max_chars": (
        "Maximum total characters for all context. Default: 1200."
    ),
    "intent.context.max_item_chars": (
        "Maximum characters per context item. Default: 200."
    ),
    "intent.context.max_items": (
        "Maximum number of context items to include. Default: 5."
    ),
    "intent.detection.min_detail_markers": (
        "Minimum detail markers to classify as rich (e.g., \"should\", \"must\"). Default: 2."
    ),
    "intent.detection.min_keyword_matches": (
        "Minimum keyword matches for PRD/plan detection. Default: 2."
    ),
    "intent.detection.rich_min_words": (
        "Minimum word count to classify as rich natural language. Default: 50."
    ),
    "intent.rate_limit.backoff_delays_s": (
        "Exponential backoff delays in seconds. Default: [2.0, 4.0, 8.0]."
    ),
    "intent.rate_limit.max_retries": (
        "Maximum retry attempts on rate limit. Default: 3."
    ),
    "intent.slug_max_length": (
        "Maximum length for generated slugs. Default: 50."
    ),
    "intent.templates.summary_preview_length": (
        "Character limit for intent summary previews. Default: 60."
    ),
    "intent.thresholds.detection_empty": (
        "Minimum word count for empty project intent detection. Default: 5."
    ),
    "intent.thresholds.detection_existing": (
        "Minimum word count for existing project intent detection. Default: 50."
    ),
    "intent.thresholds.interrogative_ratio": (
        "Threshold for interrogative vs declarative sentence ratio. Default: 0.5."
    ),
    "intent.thresholds.token_warning": (
        "Warn when intent token usage reaches 80% of context limit. Default: 0.8."
    ),
    "intent.user_stories.enabled": (
        "Enable automatic user story generation. Default: true."
    ),
    "intent.user_stories.max_stories": (
        "Maximum number of user stories to generate. Default: 10."
    ),
    "intent.user_stories.model_tier": (
        "Model tier for generation (fast/balanced/thorough). Default: 'fast'."
    ),
    "intent.user_stories.timeout_s": (
        "Null inherits orchestration.timeouts.llm_call_s. Default: null."
    ),
    "interactive.editing_mode": (
        "Editing mode: 'emacs' (default) or 'vi'. Default: 'emacs'."
    ),
    "interactive.rich_output": (
        "Enable rich output formatting (tables, colors). Default: true."
    ),
    "interactive.syntax_highlighting": (
        "Enable syntax highlighting for slash commands. Default: true."
    ),
    "learned_patterns.enabled": (
        "Enable client-side learned operational heuristics. Default: false."
    ),
    "llm.bypass_permissions": (
        "Auto-approve for automated orchestration. Default: true."
    ),
    "llm.input_budget.enabled": (
        "Enable/disable budget preflight checks. Default: true."
    ),
    "llm.input_budget.on_exceed": (
        "Policy when exceeded: \"warn\" (log + continue) or \"fail\" (return error). Default: 'warn'."
    ),
    "llm.input_budget.warning_threshold": (
        "Utilization ratio that triggers warning (85%). Default: 0.85."
    ),
    "llm.model": (
        "Quick setting: per-tier lets tiers decide, real value cascades. Default: 'per-tier'."
    ),
    "llm.provider": (
        "Quick setting: per-role lets roles decide, real value cascades. Default: 'per-role'."
    ),
    "llm.retry_attempts": (
        "Number of retry attempts on failure. Default: 3."
    ),
    "llm.thinking_budget": (
        "Token budget for extended thinking (API only); null = provider default. Default: null."
    ),
    "llm.timeout": (
        "Deprecated compatibility alias for orchestration.timeouts.llm_call_s. Default: 3600."
    ),
    "mcp.gateway_base_url": (
        "Obra gateway URL the MCP server connects to. Default: 'http://127.0.0.1:18790'."
    ),
    "mcp.http_port": (
        "Port for streamable-http transport. Default: 3100."
    ),
    "mcp.transport": (
        "Default transport: 'stdio' or 'http'. Default: 'stdio'."
    ),
    "monitoring.agent.base_timeout_s": (
        "Base timeout for agent operations (seconds). Default: 1200."
    ),
    "monitoring.agent.extended_timeout_s": (
        "Extended timeout for long-running operations (seconds). Default: 3600."
    ),
    "monitoring.agent.graceful_termination_wait_s": (
        "Time to wait for graceful termination before force kill (seconds). Default: 2.0."
    ),
    "monitoring.agent.liveness_check_interval_s": (
        "Interval for liveness checks (seconds). Default: 180."
    ),
    "monitoring.file_watcher.debounce_ms": (
        "Debounce rapid changes. Default: 500."
    ),
    "monitoring.hang_investigation.confidence.external_blocking": (
        "External blocking - agent blocked by external dependency. Default: 0.75."
    ),
    "monitoring.hang_investigation.confidence.io_blocking_with_file": (
        "I/O blocking with file activity - agent waiting on file I/O. Default: 0.85."
    ),
    "monitoring.hang_investigation.confidence.io_blocking_without": (
        "I/O blocking without file activity - agent waiting on network/DB I/O. Default: 0.65."
    ),
    "monitoring.hang_investigation.confidence.real_hang": (
        "Real hang - agent is completely stuck with no progress. Default: 0.95."
    ),
    "monitoring.hang_investigation.confidence.slow_progress": (
        "Slow progress - agent making progress but slower than expected. Default: 0.6."
    ),
    "monitoring.hang_investigation.confidence.unknown": (
        "Unknown - unable to classify hang type. Default: 0.3."
    ),
    "monitoring.liveness.cpu_delta_threshold": (
        "CPU delta threshold - minimum CPU usage change to indicate activity. Default: 1.0."
    ),
    "monitoring.liveness.db_update_window_s": (
        "Database update window - seconds to check for recent DB writes. Default: 300."
    ),
    "monitoring.liveness.file_mtime_window_s": (
        "File modification window - seconds to check for recent file changes. Default: 300."
    ),
    "monitoring.liveness.log_silence_threshold_s": (
        "Log silence threshold - seconds without log output before flagging as inactive. Default: 300."
    ),
    "monitoring.liveness.min_alive_indicators": (
        "Minimum number of alive indicators required to consider agent healthy. Default: 2."
    ),
    "monitoring.production_logging.events.agent_receive": (
        "Agent communication - received messages (verbose). Default: false."
    ),
    "monitoring.production_logging.events.agent_send": (
        "Agent communication - sent messages (verbose). Default: false."
    ),
    "monitoring.production_logging.events.errors": (
        "Errors with stage and context. Default: true."
    ),
    "monitoring.production_logging.events.execution_results": (
        "Task execution outcomes. Default: true."
    ),
    "monitoring.production_logging.events.heartbeat": (
        "Periodic heartbeat for stall detection (Story 4). Default: true."
    ),
    "monitoring.production_logging.events.implementer_responses": (
        "Implementer responses (verbose). Default: false."
    ),
    "monitoring.production_logging.events.iteration_results": (
        "Per-iteration metrics (Story 2 - CRITICAL for monitoring). Default: true."
    ),
    "monitoring.production_logging.events.nl_results": (
        "NL parsing results with quality metrics. Default: true."
    ),
    "monitoring.production_logging.events.orchestrator_prompts": (
        "Orchestrator\u2192Implementer prompts (verbose). Default: false."
    ),
    "monitoring.production_logging.events.pattern_applied": (
        "Pattern application events (FW-001). Default: true."
    ),
    "monitoring.production_logging.events.user_input": (
        "User commands and natural language input. Default: true."
    ),
    "monitoring.production_logging.flush.immediate": (
        "Flush after each event for real-time monitoring (tail -f). Default: true."
    ),
    "monitoring.production_logging.privacy.redact_pii": (
        "Redact emails, IPs, SSNs, phone numbers. Default: true."
    ),
    "monitoring.production_logging.privacy.redact_secrets": (
        "Redact API keys, tokens. Default: true."
    ),
    "monitoring.production_logging.rotation.max_file_size_mb": (
        "Rotate when log exceeds this size. Default: 100."
    ),
    "monitoring.production_logging.rotation.max_files": (
        "Keep this many backup files. Default: 10."
    ),
    "nl.interpreter_type": (
        "Options: '5_stage' (v1.8, deprecated - requires archived templates), 'single_shot_claude' (v2.0). Default: 'single_shot_claude'."
    ),
    "nl.single_shot.confidence_threshold": (
        "Minimum confidence to execute (0.0-1.0). Default: 0.5."
    ),
    "nl_commands.enabled": (
        "Enable NL command processing (master kill switch). Default: true."
    ),
    "nl_commands.experimental_features": (
        "Enable experimental NL features. Default: false."
    ),
    "nl_commands.fallback_to_info": (
        "Fallback to informational response for QUESTION intent. Default: true."
    ),
    "nl_commands.llm_provider": (
        "LLM provider for NL processing (uses llm.type if not specified). Default: 'ollama'."
    ),
    "nl_commands.max_context_turns": (
        "Maximum conversation history turns to keep. Default: 10."
    ),
    "nl_commands.require_confirmation_for": (
        "Operations requiring user confirmation. Default: ['delete', 'update', 'execute']."
    ),
    "nl_commands.schema_path": (
        "Path to Obra schema for entity extraction. Default: 'src/nl/schemas/obra_schema.json'."
    ),
    "observability.auto_flush": (
        "Automatically flush batch when size reached. Default: true."
    ),
    "observability.batch_size": (
        "Number of events to batch before writing to Firestore. Default: 50."
    ),
    "observability.cache_monitor.subdir_threshold_mb": (
        "Show subdirectories >= this size in MB. Default: 50."
    ),
    "observability.cache_monitor.top_subdirs_count": (
        "Number of top subdirectories to display in reports. Default: 3."
    ),
    "observability.emit_to_firestore": (
        "Emit to Firestore (SaaS mode only) Set to false to only write to Cloud Logging without Firestore persistence. Default: true."
    ),
    "observability.enabled": (
        "Master enable/disable switch for the observability system. Default: true."
    ),
    "observability.events.gate_decision": (
        "Quality events (from refinement). Default: true."
    ),
    "observability.events.iteration_result": (
        "Iteration events. Default: true."
    ),
    "observability.events.session_started": (
        "Session lifecycle events. Default: true."
    ),
    "observability.events.task_started": (
        "Task events. Default: true."
    ),
    "observability.events.validation_passed": (
        "Validation events. Default: true."
    ),
    "observability.log_viewer.graceful_shutdown_delay_s": (
        "Delay before graceful shutdown \u2014 long enough for browser refresh. Default: 5.0."
    ),
    "observability.log_viewer.host": (
        "Log viewer server host. Default: '127.0.0.1'."
    ),
    "observability.log_viewer.index_rotation_files": (
        "Number of rotated .jsonl.N files to scan for session indexing. Default: 3."
    ),
    "observability.log_viewer.max_events": (
        "Maximum events to keep in memory. Default: 500."
    ),
    "observability.log_viewer.max_snapshot_bytes": (
        "2MB - maximum snapshot size in bytes. Default: 2097152."
    ),
    "observability.log_viewer.port": (
        "Log viewer server port. Default: 8844."
    ),
    "observability.log_viewer.stream_sleep_s": (
        "Sleep duration between stream updates (seconds). Default: 0.2."
    ),
    "observability.log_viewer.tail_limit": (
        "Number of recent log entries to show. Default: 200."
    ),
    "observability.production_logger.backup_count": (
        "Number of rotated log files to keep. Default: 10."
    ),
    "observability.production_logger.max_size_bytes": (
        "100MB - maximum log file size before rotation. Default: 104857600."
    ),
    "observability.retention.max_events_per_session": (
        "Maximum events to keep per session (0 = unlimited). Default: 10000."
    ),
    "observability.retention.ttl_days": (
        "TTL for events in Firestore (days). Default: 30."
    ),
    "orchestration.auto.enabled": (
        "Enable autonomous workplan runner. Default: true."
    ),
    "orchestration.auto.error_assessor": (
        "LLM error assessment: null=disabled, \"fast\"=use fast-tier model, or specific model name. Default: null."
    ),
    "orchestration.auto.escalate_on_skip": (
        "Escalate (halt) when story is skipped after retries. Default: true."
    ),
    "orchestration.auto.parallel_max_workers": (
        "Maximum parallel workers for concurrent story execution. Default: 4."
    ),
    "orchestration.auto.retry_count": (
        "Number of retries for transient failures. Default: 2."
    ),
    "orchestration.auto.retry_delay_seconds": (
        "Delay between retries (seconds). Default: 30."
    ),
    "orchestration.auto.story_timeout_s": (
        "Story execution timeout (1 hour). Default: 3600."
    ),
    "orchestration.auto_decompose_on_timeout": (
        "Compatibility alias for orchestration.decomposition.enabled. Default: true."
    ),
    "orchestration.auto_retry": (
        "Automatically retry failed operations. Default: true."
    ),
    "orchestration.budgets.enabled": (
        "Disable budget framework by default (simpler execution). Default: false."
    ),
    "orchestration.budgets.max_turns.enabled": (
        "Disable max_turns limiter (use token budgets instead). Default: false."
    ),
    "orchestration.cleanup.auto_prompt": (
        "Prompt for cleanup after sessions with skips. Default: true."
    ),
    "orchestration.cleanup.interactive_default": (
        "Default to interactive cleanup. Default: true."
    ),
    "orchestration.cleanup.investigation.max_hints": (
        "Maximum investigation hints to provide. Default: 5."
    ),
    "orchestration.cleanup.investigation.tier_context": (
        "Context depth for tier selection. Default: 2."
    ),
    "orchestration.cleanup.investigation.tier_gap": (
        "Gap between tiers for hint escalation. Default: 1."
    ),
    "orchestration.cleanup.min_skips_for_epic": (
        "Minimum skips to trigger cleanup. Default: 1."
    ),
    "orchestration.cleanup.sleep_cap_s": (
        "Maximum sleep duration for retry backoff (seconds). Default: 0.5."
    ),
    "orchestration.concurrent_tasks": (
        "Number of tasks to run in parallel. Default: 1."
    ),
    "orchestration.context_quality.failure_context_enabled": (
        "Enable failure context in prompts. Default: true."
    ),
    "orchestration.context_quality.failure_history_limit": (
        "Number of recent failures to include (default: 2). Default: 2."
    ),
    "orchestration.context_quality.iteration_overrun_threshold": (
        "Flag if iterations >2x estimated. Default: 2.0."
    ),
    "orchestration.context_quality.objective_recap_enabled": (
        "Enable objective recap in task prompts. Default: true."
    ),
    "orchestration.context_quality.quality_decay_detection_enabled": (
        "Enable quality decay heuristics. Default: true."
    ),
    "orchestration.context_quality.response_length_decline_threshold": (
        "Flag if response <50% of recent average. Default: 0.5."
    ),
    "orchestration.context_quality.tool_success_rate_threshold": (
        "Flag if tool success rate <70%. Default: 0.7."
    ),
    "orchestration.decision_core.issue_ledger.enabled": (
        "IssueLedger: canonical issue identity and lifecycle tracking. Default: true."
    ),
    "orchestration.decision_core.phase_guard.mode": (
        "PhaseGuard: 'enforce' blocks invalid transitions, 'log_only' warns. Default: 'enforce'."
    ),
    "orchestration.decision_core.policy_engine.enabled": (
        "PolicyEngine: deterministic revise/escalate/complete decisions. Default: true."
    ),
    "orchestration.exploration.cache.max_age_seconds": (
        "Maximum cache entry age (1 hour default). Default: 3600."
    ),
    "orchestration.exploration.cache.max_file_delta": (
        "Invalidate if file count changes by more than this. Default: 10."
    ),
    "orchestration.exploration.context.key_file_max_lines": (
        "Maximum lines to read from each key file. Default: 50."
    ),
    "orchestration.exploration.context.key_file_patterns": (
        "Glob patterns used to pull in high-signal project-defining files during exploration. Default covers common readmes, manifests, build files, and container definitions."
    ),
    "orchestration.exploration.context.max_context_chars": (
        "Total context size cap (prevents context overflow). Default: 30000."
    ),
    "orchestration.exploration.context.tree_max_depth": (
        "Maximum directory tree depth to include. Default: 4."
    ),
    "orchestration.exploration.context.tree_max_entries": (
        "Maximum entries (files + dirs) in tree output. Default: 200."
    ),
    "orchestration.exploration.enabled": (
        "Master switch for auto-exploration. Default: true."
    ),
    "orchestration.exploration.max_relevant_files": (
        "Maximum files to include in exploration output. Default: 25."
    ),
    "orchestration.exploration.model_tier": (
        "fast tier = cheapest model (haiku, gpt-5.1-codex-mini, etc.). Default: 'fast'."
    ),
    "orchestration.exploration.skip.bug_fix_with_path": (
        "Skip for bug fixes with explicit file paths. Default: true."
    ),
    "orchestration.exploration.skip.empty_project_files": (
        "Skip if project has fewer than N meaningful files. Default: 10."
    ),
    "orchestration.exploration.skip.recent_exploration_hours": (
        "Skip if exploration ran within N hours. Default: 3."
    ),
    "orchestration.exploration.timeout_s": (
        "Timeout for context collection + single LLM inference call. Default: 120."
    ),
    "orchestration.file_access.allow_identical_directories": (
        "Forbid identical paths (default: false). Default: false."
    ),
    "orchestration.file_access.create_directory_on_project_creation": (
        "Auto-create working_dir (default: true). Default: true."
    ),
    "orchestration.file_access.overlap_policy": (
        "Options: allow, warn (default: warn). Default: 'warn'."
    ),
    "orchestration.file_access.validate_directory_exists_before_task": (
        "Check before each task (default: true). Default: true."
    ),
    "orchestration.file_access.working_dir_enforcement.enabled": (
        "Enforce that file writes stay within working_directory (default: true). Default: true."
    ),
    "orchestration.governor.telemetry.warn_threshold_s": (
        "Log warning when permit wait exceeds this many seconds. Default: 10."
    ),
    "orchestration.hang_investigation.auto_kill_on_confirmed_hang": (
        "Auto-kill on confirmed real hang. Default: true."
    ),
    "orchestration.hang_investigation.enabled": (
        "Enable hang investigation for ambiguous cases. Default: true."
    ),
    "orchestration.hang_investigation.max_investigation_time_s": (
        "Max time for investigation (5 minutes). Default: 300."
    ),
    "orchestration.hierarchy.max_stories_per_epic": (
        "Maximum stories allowed per epic. Default: 15."
    ),
    "orchestration.hierarchy.max_subtasks_per_task": (
        "Maximum subtasks allowed per task. Default: 5."
    ),
    "orchestration.hierarchy.max_tasks_per_story": (
        "Maximum tasks allowed per story. Default: 10."
    ),
    "orchestration.iteration_timeout_s": (
        "10 min minimum per Rule 22. Default: 600."
    ),
    "orchestration.limits.batch_size_default": (
        "Default batch size for bulk operations. Default: 100."
    ),
    "orchestration.limits.max_fix_attempts": (
        "Maximum attempts for fix operations. Default: 2."
    ),
    "orchestration.limits.max_iterations": (
        "Maximum loop iterations before bailout. Default: 10."
    ),
    "orchestration.limits.max_retries_critical": (
        "Retry count for critical path operations. Default: 5."
    ),
    "orchestration.limits.max_retries_default": (
        "Default retry count for general operations. Default: 3."
    ),
    "orchestration.limits.page_limit": (
        "Default page size for paginated results. Default: 50."
    ),
    "orchestration.max_iterations": (
        "Maximum iterations per task (increased from 50 for complex tasks). Default: 100."
    ),
    "orchestration.monitoring.enabled": (
        "Enable liveness monitoring thread (default: true). Default: true."
    ),
    "orchestration.planning.complexity_thresholds.complexity_threshold": (
        "Score 0-59 routes to LIGHT mode. Default: 60."
    ),
    "orchestration.planning.mode": (
        "Rigor override: auto (default), light, balanced, or thorough. Default: 'auto'."
    ),
    "orchestration.process_cleanup.enabled": (
        "Enable process lifecycle management (default: true). Default: true."
    ),
    "orchestration.process_cleanup.terminate_timeout": (
        "Seconds to wait after SIGTERM before SIGKILL (default: 3.0). Default: 3.0."
    ),
    "orchestration.project_context.injection_enabled": (
        "Enable project context injection into prompts. Default: true."
    ),
    "orchestration.session_token_budget.max_total_tokens": (
        "Explicit cumulative session token cap. When null (default), the budget is computed dynamically as (per_call_input + per_call_output) * per_model_multiplier from the orchestrator's resolved model. Set an integer to override."
    ),
    "orchestration.session_token_budget.per_model_multiplier": (
        "Multiplier applied to the orchestrator model's per-call capacity to derive the dynamic session budget. Default: 50 (gives ~10M tokens for Sonnet 200K, ~50M for Opus 1M, ~19M for GPT-5.5 400K)."
    ),
    "orchestration.simulation.campaign.analysis_tier": (
        "Tier used for structured non-nightly failure analysis worker. Default: 'high'."
    ),
    "orchestration.simulation.campaign.bootstrap_ready_timeout_s": (
        "Timeout for emulator/browser-rig readiness checks during campaign bootstrap. Default: 60."
    ),
    "orchestration.simulation.campaign.child_poll_interval_s": (
        "Poll interval when the campaign waits for service health or child step completion. Default: 5."
    ),
    "orchestration.simulation.campaign.confirmation_reruns": (
        "Extra confirmation reruns after a fixed non-nightly leaf passes. Default: 1."
    ),
    "orchestration.simulation.campaign.enable_llm_fixes": (
        "Allow campaign-owned bounded fix loops for non-nightly leaves. Default: true."
    ),
    "orchestration.simulation.campaign.fix_tier": (
        "Tier used for bounded non-nightly fix worker execution. Default: 'high'."
    ),
    "orchestration.simulation.campaign.max_fix_loops": (
        "Maximum bounded fix loops for one non-nightly campaign leaf. Default: 2."
    ),
    "orchestration.simulation.campaign.worker_timeout_s": (
        "Timeout for campaign analysis/fix worker LLM calls (seconds). Default: 3600."
    ),
    "orchestration.simulation.nightly.allow_force_complete": (
        "Allow fallback force-complete before rerun when repair cannot reconcile a stuck session. Default: false."
    ),
    "orchestration.simulation.nightly.analysis_tier": (
        "Tier used for structured failure analysis worker. Default: 'high'."
    ),
    "orchestration.simulation.nightly.enable_llm_fixes": (
        "Allow nightly missions to run bounded LLM fix loops. Default: true."
    ),
    "orchestration.simulation.nightly.enable_session_repair": (
        "Allow local nightly missions to invoke session repair automatically. Default: true."
    ),
    "orchestration.simulation.nightly.fix_tier": (
        "Tier used for bounded fix worker execution. Default: 'high'."
    ),
    "orchestration.simulation.nightly.max_fix_loops": (
        "Maximum bounded LLM fix loops before the mission aborts. Default: 3."
    ),
    "orchestration.simulation.nightly.max_repair_attempts": (
        "Maximum session repair attempts before falling back to rerun/abort. Default: 1."
    ),
    "orchestration.simulation.nightly.max_target_retries": (
        "Rerun budget for failed scenario/suite targets. Default: 3."
    ),
    "orchestration.simulation.nightly.max_total_loops": (
        "Hard cap on deterministic controller iterations per mission. Default: 8."
    ),
    "orchestration.simulation.nightly.repair_cooldown_s": (
        "Cooldown between repair attempt and rerun. Default: 10."
    ),
    "orchestration.simulation.nightly.wait_poll_interval_s": (
        "Poll interval when a nightly mission re-checks long-running work. Default: 5."
    ),
    "orchestration.simulation.nightly.worker_timeout_s": (
        "Timeout for analyzer/fix worker LLM calls (seconds). Default: 3600."
    ),
    "orchestration.skip_tracking.auto_classify": (
        "Enable heuristic classification. Default: true."
    ),
    "orchestration.skip_tracking.enabled": (
        "Master toggle for skip tracking. Default: true."
    ),
    "orchestration.skip_tracking.max_logs_chars": (
        "Truncate error logs beyond this length. Default: 2000."
    ),
    "orchestration.skip_tracking.redact_patterns": (
        "Optional additional redaction regex patterns. Default: []."
    ),
    "orchestration.skip_tracking.redact_secrets": (
        "Redact secrets/PII before persistence. Default: true."
    ),
    "orchestration.skip_tracking.retention_days": (
        "Auto-archive resolved skips after N days. Default: 90."
    ),
    "orchestration.skip_tracking.storage_dir": (
        "Local mirror; StateManager is source of truth. Default: '.obra/skip-tracking'."
    ),
    "orchestration.spike_first.enabled": (
        "Umbrella toggle - loads spike infrastructure. Individual phases controlled below. Default: false."
    ),
    "orchestration.spike_first.per_story_enabled": (
        "Requires spike_first.enabled to also be true. Default: false."
    ),
    "orchestration.spike_first.per_story_skip_on_rigor": (
        "Optional rigor skip list: light, balanced, thorough. Default: []."
    ),
    "orchestration.spike_first.per_story_timeout_s": (
        "Shared timeout used for story-scoped executor and evaluator calls. Default: 600."
    ),
    "orchestration.spike_first.pre_derive_enabled": (
        "Controls the pre-derive spike phase independently. Requires enabled: true. Default: true."
    ),
    "orchestration.spike_first.exclude_dirs": (
        "Directory names excluded from spike workspace copies and heartbeat scans to avoid caches, virtualenvs, build artifacts, and vendor-managed context folders. Default: [.git, .hg, .svn, .obra, __pycache__, node_modules, .venv, venv, .tox, .mypy_cache, .pytest_cache, .ruff_cache, build, dist, .claude, .gemini, .cursor, .windsurf, .agents]."
    ),
    "orchestration.spike_first.exclude_files": (
        "Vendor meta-files excluded from managed spike workspace copies. Default: [CLAUDE.md, CLAUDE.local.md, AGENTS.md, AGENTS.override.md, GEMINI.md, .cursorrules, .windsurfrules, .github/copilot-instructions.md]."
    ),
    "orchestration.task_timeout_s": (
        "Overall task timeout (seconds). Default: 3600."
    ),
    "orchestration.timeouts.default_s": (
        "Default timeout for general network operations (seconds). Default: 30."
    ),
    "orchestration.timeouts.liveness.base_timeout_s": (
        "20 minutes if no liveness detected. Default: 1200."
    ),
    "workspace.context.enabled": (
        "Enable managed workspace context and vendor meta-file suppression. Default: true."
    ),
    "workspace.context.mode": (
        "Workspace context mode: managed suppresses vendor meta-files, passthrough lets vendor CLIs read them. Default: managed."
    ),
    "workspace.context.auto_import": (
        "Automatically rerun `obra context import` when drift is detected before invocation. Default: false."
    ),
    "orchestration.timeouts.liveness.check_interval_s": (
        "Check liveness every 3 minutes. Default: 180."
    ),
    "orchestration.timeouts.liveness.cpu_delta_threshold": (
        "Minimum CPU seconds per check interval. Default: 1.0."
    ),
    "orchestration.timeouts.liveness.db_update_window_s": (
        "Max seconds since last DB write (5 min). Default: 300."
    ),
    "orchestration.timeouts.liveness.extended_timeout_s": (
        "60 minutes for tasks showing progress. Default: 3600."
    ),
    "orchestration.timeouts.liveness.file_mtime_window_s": (
        "Max seconds since last file modification (5 min). Default: 300."
    ),
    "orchestration.timeouts.liveness.log_silence_threshold_s": (
        "Max seconds without new log entries (5 min). Default: 300."
    ),
    "orchestration.timeouts.liveness.min_alive_indicators": (
        "Minimum indicators (of 5) to consider task alive. Default: 2."
    ),
    "orchestration.validation.cpu_stagnation_window_s": (
        "Seconds to measure CPU delta for stagnation. Default: 30."
    ),
    "orchestration.validation.enabled": (
        "Response validation (quality checks, completeness verification). Default: true."
    ),
    "orchestration.validation.expected_extensions": (
        "Optional list of expected file extensions. Default: null."
    ),
    "orchestration.validation.min_file_size_bytes": (
        "Minimum bytes for a file to be considered meaningful (default: 10). Default: 10."
    ),
    "orchestration.validation.subprocess_timeout_s": (
        "Seconds before declaring subprocess hung. Default: 60."
    ),
    "orchestration.watchdog.max_silent_seconds": (
        "ISSUE-HYBRID-008: Absolute max silence timeout (default: 5 minutes). Default: 300."
    ),
    "orchestration.workflow.enabled": (
        "\u2705 RE-ENABLED: Fixing workflow orchestration bug. Default: true."
    ),
    "orchestrator.checkpoint.verification.enabled": (
        "Enable checkpoint verification. Default: true."
    ),
    "orchestrator.checkpoint.verification.max_age_hours": (
        "Max checkpoint age (1 week). Default: 168."
    ),
    "orchestrator.checkpoint.verification.min_coverage": (
        "Minimum coverage threshold (88% baseline). Default: 0.88."
    ),
    "orchestrator.checkpoint.verification.quick_test_timeout": (
        "Timeout for quick tests (seconds). Default: 30."
    ),
    "orchestrator.checkpoint.verification.require_file_existence": (
        "Require checkpoint files exist. Default: true."
    ),
    "orchestrator.checkpoint.verification.require_verification": (
        "Fail checkpoint if verification fails. Default: true."
    ),
    "orchestrator.checkpoint.verification.verify_coverage": (
        "Require coverage meets baseline. Default: true."
    ),
    "orchestrator.checkpoint.verification.verify_git_clean": (
        "Require clean git state. Default: true."
    ),
    "orchestrator.checkpoint.verification.verify_task_boundary": (
        "Require task at boundary (optional). Default: false."
    ),
    "orchestrator.checkpoint.verification.verify_tests_on_resume": (
        "Run tests when resuming checkpoint. Default: false."
    ),
    "orchestrator.checkpoint.verification.verify_tests_passing": (
        "Require tests passing. Default: true."
    ),
    "orchestrator.checkpoint.verification.warn_on_branch_mismatch": (
        "Warn on git branch mismatch. Default: true."
    ),
    "orchestrator.context_window.archive_path": (
        "Archived operations. Default: '.obra/archive'."
    ),
    "orchestrator.context_window.artifact_storage_path": (
        "External artifacts storage. Default: '.obra/memory/artifacts'."
    ),
    "orchestrator.context_window.checkpoint_dir": (
        "Checkpoint files. Default: '.obra/memory/checkpoints'."
    ),
    "orchestrator.context_window.checkpoints.auto_checkpoint_orange": (
        "Auto-checkpoint in orange zone. Default: true."
    ),
    "orchestrator.context_window.checkpoints.auto_checkpoint_red": (
        "Auto-checkpoint in red zone (mandatory). Default: true."
    ),
    "orchestrator.context_window.checkpoints.enabled": (
        "Enable automatic checkpointing. Default: true."
    ),
    "orchestrator.context_window.checkpoints.max_checkpoints": (
        "Keep last 10 checkpoints. Default: 10."
    ),
    "orchestrator.context_window.checkpoints.verification_enabled": (
        "Verify checkpoints after creation. Default: true."
    ),
    "orchestrator.context_window.externalization_threshold": (
        "Externalize large items >2000 tokens. Default: 2000."
    ),
    "orchestrator.context_window.fallback_context_window": (
        "Fallback if auto-detection fails. Default: 16384."
    ),
    "orchestrator.context_window.summarization_threshold": (
        "Summarize operations >500 tokens. Default: 500."
    ),
    "orchestrator.context_window.utilization_limit": (
        "Use 85% of context window (red zone threshold). Default: 0.85."
    ),
    "orchestrator.context_window.working_memory.eviction_policy": (
        "First-in-first-out eviction. Default: 'fifo'."
    ),
    "orchestrator.context_window.working_memory.max_age_hours": (
        "Prune operations older than 1 hour. Default: 1."
    ),
    "orchestrator.context_window.working_memory.max_operations": (
        "Maximum operations to keep (adaptive sizing). Default: 20."
    ),
    "orchestrator.context_window.zones.green_threshold": (
        "0-45%: green zone. Default: 0.45."
    ),
    "orchestrator.context_window.zones.orange_threshold": (
        "65-75%: orange zone. Default: 0.75."
    ),
    "orchestrator.context_window.zones.red_threshold": (
        "75-85%: red zone. Default: 0.85."
    ),
    "orchestrator.context_window.zones.yellow_threshold": (
        "45-65%: yellow zone. Default: 0.65."
    ),
    "orchestrator.session_continuity.checkpoints.retention.keep_count": (
        "Keep last 10 checkpoints. Default: 10."
    ),
    "orchestrator.session_continuity.checkpoints.retention.max_age_hours": (
        "Delete checkpoints older than 24h. Default: 24."
    ),
    "orchestrator.session_continuity.checkpoints.retention.preserve_milestones": (
        "Never delete milestone checkpoints. Default: true."
    ),
    "orchestrator.session_continuity.checkpoints.verification.enabled": (
        "Verify checkpoints after creation. Default: true."
    ),
    "orchestrator.session_continuity.checkpoints.verification.verify_completeness": (
        "Check all required fields present. Default: true."
    ),
    "orchestrator.session_continuity.checkpoints.verification.verify_git_clean": (
        "Require clean git state (optional). Default: false."
    ),
    "orchestrator.session_continuity.checkpoints.verification.verify_state_consistency": (
        "Validate state consistency. Default: true."
    ),
    "orchestrator.session_continuity.continuation_prompts.auto_generate_on_handoff": (
        "Auto-generate during handoff. Default: true."
    ),
    "orchestrator.session_continuity.continuation_prompts.enabled": (
        "Generate continuation prompts. Default: true."
    ),
    "orchestrator.session_continuity.continuation_prompts.include_context_summary": (
        "Include context summary. Default: true."
    ),
    "orchestrator.session_continuity.continuation_prompts.include_next_steps": (
        "Include suggested next steps. Default: true."
    ),
    "orchestrator.session_continuity.continuation_prompts.include_recent_operations": (
        "Include last N operations. Default: 5."
    ),
    "orchestrator.session_continuity.continuation_prompts.output_dir": (
        "Output directory. Default: 'docs/development/.continuation_prompts'."
    ),
    "orchestrator.session_continuity.decision_records.auto_number": (
        "Auto-number ADRs. Default: true."
    ),
    "orchestrator.session_continuity.decision_records.enabled": (
        "Generate decision records. Default: true."
    ),
    "orchestrator.session_continuity.decision_records.format": (
        "Format: adr, markdown, json. Default: 'adr'."
    ),
    "orchestrator.session_continuity.decision_records.include_context": (
        "Include full context in records. Default: true."
    ),
    "orchestrator.session_continuity.decision_records.output_dir": (
        "Output directory. Default: 'docs/decisions'."
    ),
    "orchestrator.session_continuity.metrics.collect_context_usage": (
        "Track context usage over time. Default: true."
    ),
    "orchestrator.session_continuity.metrics.collect_decision_quality": (
        "Track decision quality scores. Default: true."
    ),
    "orchestrator.session_continuity.metrics.collect_handoff_stats": (
        "Track handoff statistics. Default: true."
    ),
    "orchestrator.session_continuity.metrics.collect_operation_types": (
        "Track operation type distribution. Default: true."
    ),
    "orchestrator.session_continuity.metrics.enabled": (
        "Enable metrics collection. Default: true."
    ),
    "orchestrator.session_continuity.metrics.retention_days": (
        "Keep metrics for 30 days. Default: 30."
    ),
    "orchestrator.session_continuity.progress_reporting.enabled": (
        "Enable progress reports. Default: true."
    ),
    "orchestrator.session_continuity.progress_reporting.include_context_usage": (
        "Include context usage stats. Default: true."
    ),
    "orchestrator.session_continuity.progress_reporting.include_metrics": (
        "Include performance metrics. Default: true."
    ),
    "orchestrator.session_continuity.progress_reporting.log_to_production": (
        "Log to production logger. Default: true."
    ),
    "orchestrator.session_continuity.progress_reporting.report_frequency": (
        "When to report: iteration, task, milestone. Default: 'iteration'."
    ),
    "orchestrator.session_continuity.self_handoff.enabled": (
        "Enable automatic self-handoff. Default: true."
    ),
    "orchestrator.session_continuity.self_handoff.max_handoffs_per_session": (
        "Maximum handoffs in single session. Default: 5."
    ),
    "orchestrator.session_continuity.self_handoff.min_operations_before_handoff": (
        "Minimum operations before first handoff. Default: 10."
    ),
    "orchestrator.session_continuity.self_handoff.trigger_zone": (
        "Zone that triggers handoff (yellow/orange/red). Default: 'red'."
    ),
    "performance.cache_ttl": (
        "Cache time-to-live (seconds). Default: 300."
    ),
    "performance.enable_caching": (
        "Enable caching where applicable. Default: true."
    ),
    "planning.enrichment.stages.revise.max_concurrent": (
        "Parallel workers for per-story enrichment review (1-8). Default: 4."
    ),
    "planning.enrichment.stages.revise.max_passes": (
        "Retry on parse failure. Default: 2."
    ),
    "planning.enrichment.stages.revise.max_refinement_cycles": (
        "Max review-refine iterations per story. Default: 1."
    ),
    "planning.enrichment.stages.revise.timeout_s": (
        "Null inherits orchestration.timeouts.llm_call_s. Default: null."
    ),
    "process_registry.terminate_timeout_s": (
        "Timeout in seconds for process termination. Default: 3.0."
    ),
    "projects.default_directory": (
        "Default directory for Obra-managed projects Separate from Obra's dev code (~/projects/Obra) and runtime data (~/.obra-runtime). Default: '~/obra-projects'."
    ),
    "prompts.template_dir": (
        "Directory for Jinja2 templates. Default: 'config/prompt_templates'."
    ),
    "quality.assessment_model": (
        "Options: orch (orchestrator LLM), imp (implementation agent). Default: 'orch'."
    ),
    "quality.auto_fill_on_pass": (
        "Generate missing context fields when quality passes. Default: true."
    ),
    "quality.max_clarification_iterations": (
        "Maximum iterations in clarification loop. Default: 5."
    ),
    "quality.threshold_needs_detail": (
        "Below this: demand more detail. Default: 0.3."
    ),
    "quality.threshold_needs_hints": (
        "Below this: offer hints + defaults. Default: 0.5."
    ),
    "rederivation.preserve_completed": (
        "Keep completed execution items on re-derivation. Default: true."
    ),
    "rederivation.trigger": (
        "Options: on_execute, on_edit, manual. Default: 'on_execute'."
    ),
    "refinement.cloud_logging.include_trace_context": (
        "Include X-Cloud-Trace-Context for distributed tracing. Default: true."
    ),
    "refinement.cloud_logging.log_name": (
        "Log name in Cloud Logging. Default: 'obra-events'."
    ),
    "refinement.escalation_continue_iteration_reset": (
        "Iteration value to reset to when user selects \"continue fixing\" after a max-refinement-iterations escalation.  0 = full budget (restart from iteration 0); higher values grant fewer additional cycles. Default: 0."
    ),
    "refinement.llm.default_interface": (
        "Default interface type (api, cli). Default: 'cli'."
    ),
    "refinement.llm.default_provider": (
        "Default provider for refinement operations (null = inherit main provider). Default: null."
    ),
    "refinement.llm.heartbeat": (
        "System events. Default: true."
    ),
    "refinement.llm.providers_config": (
        "Load provider config from config/llm_providers.yaml. Default: 'config/llm_providers.yaml'."
    ),
    "refinement.max_iterations": (
        "Global refinement iteration cap (can be overridden per sub-feature). Default: 10."
    ),
    "refinement.metrics.record_session_metrics": (
        "Metric categories to record. Default: true."
    ),
    "refinement.parallel.max_workers": (
        "Max concurrent workers for parallel batch dispatch. Default: 4."
    ),
    "refinement.planning.derivation.improvement_threshold": (
        "Minimum improvement to continue. Default: 0.1."
    ),
    "refinement.planning.derivation.max_passes": (
        "Maximum derivation passes. Default: 3."
    ),
    "refinement.planning.enabled": (
        "Enable iterative plan refinement (D1). Default: true."
    ),
    "refinement.planning.feedback.apply_patterns": (
        "Apply feedback patterns to future derivations. Default: true."
    ),
    "refinement.planning.feedback.enabled": (
        "Enable feedback collection. Default: true."
    ),
    "refinement.planning.feedback.store_history": (
        "Store feedback history. Default: true."
    ),
    "refinement.planning.max_iterations": (
        "Override max iterations for plan refinement. Default: 10."
    ),
    "refinement.planning.quality_gate.enabled": (
        "Enable quality gates. Default: true."
    ),
    "refinement.planning.quality_gate.enforce_strict": (
        "Block on quality failure (vs warning). Default: false."
    ),
    "refinement.planning.quality_gate.min_score": (
        "Minimum quality score to pass (0.0-1.0). Default: 0.7."
    ),
    "refinement.planning.thinking_mode.enabled": (
        "Enable extended thinking on first pass. Default: true."
    ),
    "refinement.planning.thinking_mode.first_pass_only": (
        "Only use extended thinking on initial derivation. Default: true."
    ),
    "refinement.planning.thinking_mode.level": (
        "Default thinking level: off, minimal, standard, high, maximum. Default: 'high'."
    ),
    "refinement.planning.versioning.auto_increment": (
        "Auto-increment version on update. Default: true."
    ),
    "refinement.planning.versioning.enabled": (
        "Enable plan versioning. Default: true."
    ),
    "refinement.planning.versioning.max_versions": (
        "Maximum versions to retain. Default: 10."
    ),
    "refinement.planning.versioning.track_changes": (
        "Track changes between versions. Default: true."
    ),
    "refinement.regression_min_delta": (
        "Require at least this absolute blocking-issue increase before regression escalation. Default: 3."
    ),
    "refinement.regression_threshold_multiplier": (
        "Escalate if blocking issues spike by this multiplier post-revise. Default: 3.0."
    ),
    "refinement.straggler_alert_threshold": (
        "Emit alert when batch straggler ratio exceeds this. Default: 1.5."
    ),
    "retry.auth_max_attempts": (
        "Maximum retries for auth errors. Default: 3."
    ),
    "retry.backoff_multiplier": (
        "Exponential backoff multiplier (8s \u2192 16s \u2192 32s \u2192 ...). Default: 2.0."
    ),
    "retry.base_delay": (
        "Initial delay in seconds. Default: 8.0."
    ),
    "retry.jitter": (
        "Random jitter factor (0.0-1.0) to spread retry bursts. Default: 0.2."
    ),
    "retry.max_attempts": (
        "Maximum retry attempts for transient errors (network, 5xx). Default: 3."
    ),
    "retry.max_delay": (
        "Maximum delay in seconds (caps exponential growth). Default: 120.0."
    ),
    "retry.rate_limit_max_attempts": (
        "Rate-limit retries kept minimal (provider CLI already retries). Default: 1."
    ),
    "retry.retryable_errors": (
        "Error substrings that qualify a failure for retry handling. Default covers rate limits, timeouts, transient network faults, streaming disconnects, and common 5xx-style server errors."
    ),
    "review.agents.max_workers": (
        "Max concurrent agents when parallel=true. Default: 4."
    ),
    "review.agents.parallel": (
        "Default: parallel execution. Set false for sequential (legacy). Default: true."
    ),
    "review.complexity.medium.max_files": (
        "Max files for medium complexity review. Default: 5."
    ),
    "review.complexity.medium.max_lines": (
        "Max lines for medium complexity review. Default: 200."
    ),
    "review.complexity.simple.max_files": (
        "Max files modified for simple review. Default: 2."
    ),
    "review.complexity.simple.max_lines": (
        "Max lines changed for simple review. Default: 50."
    ),
    "review.complexity.simple.max_words": (
        "Max word count for simple review (quick pass/fail). Default: 20."
    ),
    "review.default_quality_threshold": (
        "Used when quality assessment fails (graceful degradation). Default: 0.7."
    ),
    "review.feedback.default_initial_quality_score": (
        "Default initial quality score for new work (0.0-1.0). Default: 0.7."
    ),
    "review.feedback.fail_adjustment": (
        "Adjustment when review fails. Default: -0.2."
    ),
    "review.feedback.flag_penalty_cap": (
        "Maximum total penalty from flags (prevents excessive deductions). Default: 0.5."
    ),
    "review.feedback.flag_weights.incomplete": (
        "Work is missing required components or functionality. Default: 0.2."
    ),
    "review.feedback.flag_weights.incorrect": (
        "Implementation has errors or produces wrong results (most severe). Default: 0.3."
    ),
    "review.feedback.flag_weights.off_topic": (
        "Work doesn't address the original requirements. Default: 0.25."
    ),
    "review.feedback.flag_weights.quality_issue": (
        "General quality problems (style, maintainability). Default: 0.1."
    ),
    "review.feedback.flag_weights.unclear": (
        "Code/docs are hard to understand or ambiguous. Default: 0.15."
    ),
    "review.feedback.pass_adjustment": (
        "Adjustment when review passes. Default: 0.1."
    ),
    "review.feedback.pass_rating_threshold": (
        "Minimum rating considered passing (1-5 scale). Default: 3."
    ),
    "review.feedback.rating_adjustments.2": (
        "Below expectations. Default: -0.15."
    ),
    "review.feedback.rating_adjustments.3": (
        "Acceptable/neutral. Default: 0.0."
    ),
    "review.feedback.rederivation_threshold": (
        "Quality threshold below which rederivation is triggered (0.0-1.0). Default: 0.4."
    ),
    "review.permissive_mode": (
        "When true, P1 issues are warnings instead of blockers. Default: false."
    ),
    "review.revision_integrity.plan_shrinkage_warning_threshold": (
        "Disabled: brittle numeric guard caused false escalations when SenseCheck-initiated revisions legitimately restructured plans. Re-enable with non-zero values if data-loss regressions appear. Default: 0.0."
    ),
    "security.prompt_sanitizer.strict_mode": (
        "When true, detected prompt-injection content is wrapped in quotes (defense-in-depth). Default: true."
    ),
    "session_memory.budget_percentage": (
        "Use 20% of context window for session narrative. Default: 0.2."
    ),
    "session_memory.compression_trigger_pct": (
        "Compress when 80% of budget used. Default: 0.8."
    ),
    "session_memory.enabled": (
        "Enable session memory management. Default: true."
    ),
    "session_memory.min_events_for_compression": (
        "Minimum events before compression. Default: 5."
    ),
    "session_memory.recent_events_to_keep": (
        "Keep N most recent events uncompressed. Default: 3."
    ),
    "skip_tracking.max_logs_chars": (
        "Maximum character count for log messages in skip records. Default: 2000."
    ),
    "story0.allow_inferred_installs": (
        "Gate inferred installs in manifest_then_inferred. Default: true."
    ),
    "story0.allowed_empty_markers": (
        "Files allowed in \"empty\" repo (glob patterns ok). Default: ['.git', '.obra', 'README*', '.gitignore', '.vscode', '.idea', 'LICENSE*', '.editorconfig', '.pre-commit-config.yaml']."
    ),
    "story0.auto_env_setup": (
        "Prompt user before creating manifests (guided mode). Default: false."
    ),
    "story0.default_manifest_type": (
        "Auto-detect from project files; do not assume a language. Default: null."
    ),
    "story0.default_mock_level": (
        "stub | fixture | emulator. Default: 'fixture'."
    ),
    "story0.dependency_resolution.allow_edit_commands": (
        "Let user modify proposed commands in guided mode. Default: true."
    ),
    "story0.dependency_resolution.allow_rescan": (
        "Let user trigger re-scan after manual install. Default: true."
    ),
    "story0.dependency_resolution.continue_on_non_blocking": (
        "Continue resolver loops for non-blocking entries with remaining attempt budget. Default: true."
    ),
    "story0.dependency_resolution.elevation_warning": (
        "Warn when commands may need sudo. Default: true."
    ),
    "story0.dependency_resolution.manual_behavior": (
        "Policy for prerequisites that require manual user intervention prompt_once: batch all manual items, prompt once after auto-install completes continue_with_warnings: skip manual items, emit warnings, continue abort_if_blocking: abort session if any blocking manual item exists. Default: 'prompt_once'."
    ),
    "story0.dependency_resolution.max_attempts_per_dependency": (
        "Resolver-level escalation points; each LLM escalation may attempt multiple internal retries. Default: 3."
    ),
    "story0.dependency_resolution.max_loops": (
        "Max detect-install-verify cycles. Default: 3."
    ),
    "story0.dependency_resolution.mission_timeout_s": (
        "Maximum wall-clock time for all attempts on a single dependency. Default: 300."
    ),
    "story0.dependency_resolution.present_table": (
        "Show dependency table to console. Default: true."
    ),
    "story0.dependency_resolution.unknown_behavior": (
        "Policy for prerequisites with unknown category or no registered probe unverified_non_blocking: treat as unverified, non-blocking (continue) manual: route to manual prompt fail: treat as blocking failure. Default: 'unverified_non_blocking'."
    ),
    "story0.dependency_resolution.verify_executables": (
        "Preflight check on proposed commands before presenting. Default: true."
    ),
    "story0.docker.cleanup_on_complete": (
        "Stop containers on session end. Default: true."
    ),
    "story0.docker.enabled": (
        "Allow Docker service starts. Default: true."
    ),
    "story0.docker.orphan_check_on_start": (
        "Check for orphaned containers on startup. Default: true."
    ),
    "story0.enabled": (
        "Master toggle for Story 0. Default: true."
    ),
    "story0.env_creation": (
        "never | when_missing | always. Default: 'always'."
    ),
    "story0.force_continue": (
        "Make ALL prerequisite failures non-blocking (--skip-preflight). Default: false."
    ),
    "story0.install_policy": (
        "manifest_only | manifest_then_inferred | manifest_or_inferred. Default: 'manifest_or_inferred'."
    ),
    "story0.install_target": (
        "project_local | existing_env_only | system. Default: 'project_local'."
    ),
    "story0.log_decisions": (
        "Emit structured decision logs/events. Default: true."
    ),
    "story0.multi_manifest": (
        "Allow multiple manifests for polyglot/monorepo. Default: true."
    ),
    "story0.never_overwrite_manifest": (
        "Skip writing if manifest already exists. Default: true."
    ),
    "story0.package_manager_preference.node": (
        "auto | npm | pnpm | yarn | bun. Default: 'auto'."
    ),
    "story0.package_manager_preference.python": (
        "auto | pip | uv | poetry | pipenv. Default: 'auto'."
    ),
    "story0.package_manager_preference.ruby": (
        "auto | bundler | gem. Default: 'auto'."
    ),
    "story0.package_manager_preference.rust": (
        "auto | cargo. Default: 'auto'."
    ),
    "story0.prompt_for_env_setup": (
        "Prompt before environment setup in guided mode. Default: true."
    ),
    "story0.timeout_seconds": (
        "Max time for user input. Default: 300."
    ),
    "timeouts.auto_assessor_s": (
        "Quality assessment timeout (15 min). Default: 900."
    ),
    "timeouts.auto_story_s": (
        "Full story execution timeout (1 hour). Default: 3600."
    ),
    "timeouts.display.status_update_interval_s": (
        "Interval between status updates (seconds). Default: 30.0."
    ),
    "timeouts.handler.socket_connect_s": (
        "Socket connection timeout. Default: 2."
    ),
    "timeouts.handler.subprocess_s": (
        "Subprocess operation timeout. Default: 5."
    ),
    "timeouts.handler.thread_join_s": (
        "Thread join timeout. Default: 2.0."
    ),
    "timeouts.http.request_s": (
        "Standard HTTP request timeout (seconds). Default: 30."
    ),
    "timeouts.http.upload_s": (
        "Upload operation timeout (seconds). Default: 120."
    ),
    "timeouts.llm_subprocess_s": (
        "LLM subprocess calls timeout (15 min). Default: 900."
    ),
    "timeouts.ollama.default_s": (
        "Default Ollama LLM call timeout (15 min). Default: 900."
    ),
    "timeouts.ollama.status_ready_s": (
        "Ready check timeout (not LLM call). Default: 10."
    ),
    "timeouts.ollama.status_s": (
        "Status check timeout (not LLM call). Default: 5."
    ),
    "timeouts.subprocess_runner.error_cleanup_s": (
        "Error cleanup timeout. Default: 1."
    ),
    "timeouts.subprocess_runner.poll_interval_s": (
        "Subprocess polling interval. Default: 0.5."
    ),
    "timeouts.subprocess_runner.process_wait_s": (
        "Process wait timeout. Default: 5."
    ),
    "tooling_discovery.max_manifest_bytes": (
        "Maximum size in bytes for tooling manifest files. Default: 2048."
    ),
    "validation.plan_item.max_acceptance_criteria": (
        "Maximum acceptance criteria per plan item. Default: 5."
    ),
    "validation.plan_item.max_description_words": (
        "Maximum word count for plan item descriptions. Default: 150."
    ),
    "validation.plan_item.max_files_per_task": (
        "Maximum files modified per task. Default: 5."
    ),
    "validation.plan_item.max_loc": (
        "Maximum lines of code per task. Default: 400."
    ),
    "validation.plan_item.max_tasks": (
        "Maximum tasks per story. Default: 8."
    ),
    "validation.quality.check_syntax": (
        "Validate code syntax. Default: true."
    ),
    "validation.quality.run_tests": (
        "Execute tests if applicable. Default: true."
    ),
    "validation.quality.threshold": (
        "Minimum acceptable quality score (0.0-1.0). Default: 0.7."
    ),
    "validation.response.min_length": (
        "Minimum response length (characters). Default: 10."
    ),
    "work_type.scoring.base_score": (
        "Baseline score for any work type match (50%). Default: 0.5."
    ),
    "work_type.scoring.max_bonus": (
        "Maximum bonus score from weighted features (50%). Default: 0.5."
    ),
    "work_type.weights.keywords": (
        "Weight for keyword matching (e.g., \"bug\", \"feature\", \"refactor\"). Default: 0.25."
    ),
    "work_type.weights.phrases": (
        "Weight for phrase matching (e.g., \"add support for\", \"fix issue\"). Default: 0.35."
    ),
    "work_type.weights.regex_patterns": (
        "Weight for regex pattern matching (e.g., issue IDs, commit patterns). Default: 0.15."
    ),
    "workflow.auto_checkpoint": (
        "Auto-create checkpoints between steps. Default: true."
    ),
    "workflow.budgets.progress.max_no_diff_iterations": (
        "No changes 2x = stalled. Default: 2."
    ),
    "workflow.budgets.progress.max_repeated_errors": (
        "Same error 3x = stalled. Default: 3."
    ),
    "workflow.budgets.progress.quality_stuck_threshold": (
        "Quality range <5% = stuck. Default: 0.05."
    ),
    "workflow.budgets.tokens.enforce": (
        "Hard limits (true) vs warnings (false). Default: true."
    ),
    "workflow.budgets.tokens.max_agent_tokens": (
        "Claude Code tokens per task. Default: 150000."
    ),
    "workflow.budgets.tokens.max_local_llm_tokens": (
        "Qwen tokens per task. Default: 75000."
    ),
    "workflow.drift_detection.severity_threshold": (
        "Warn on medium+ severity (low/medium/high). Default: 'medium'."
    ),
    "workflow.max_corrective_attempts": (
        "Max retries for failed validation. Default: 3."
    ),
    "workflow.max_turns.default": (
        "Default max_turns (was 50, increased for better UX). Default: 100."
    ),
    "workflow.max_turns.max": (
        "Maximum allowed (complex epics). Default: 150."
    ),
    "workflow.max_turns.min": (
        "Minimum allowed (simple tasks). Default: 3."
    ),
    "workflow.pattern_weighting.keyword_weight": (
        "Weight for keyword-based workflow matches (40%). Default: 0.4."
    ),
    "workflow.pattern_weighting.pattern_weight": (
        "Weight for pattern-based workflow matches (60%). Default: 0.6."
    ),
    "workflow.patterns_path": (
        "Pattern library configuration. Default: 'config/patterns.yaml'."
    ),
    "workflow.priority_order.P0": (
        "Critical priority (blocks deployment, data loss). Default: 0."
    ),
    "workflow.priority_order.P1": (
        "High priority (major feature broken, security issue). Default: 1."
    ),
    "workflow.priority_order.P2": (
        "Medium priority (minor feature broken, degraded UX). Default: 2."
    ),
    "workflow.priority_order.P3": (
        "Low priority (cosmetic, nice-to-have). Default: 3."
    ),
    "workflow.triage.high_confidence": (
        "Threshold for high-confidence workflow matches. Default: 0.9."
    ),
    "workflow.triage.low_confidence": (
        "Threshold for low-confidence workflow matches. Default: 0.3."
    ),
    "workflow.triage.medium_confidence": (
        "Threshold for medium-confidence workflow matches. Default: 0.5."
    ),
    "workflow.turn_calculation.adaptive_learning.enabled": (
        "DEPRECATED. Default: false."
    ),
    "workflow.turn_calculation.mode": (
        "DEPRECATED - Options: heuristic, token_aware, adaptive, token_aware_adaptive. Default: 'token_aware'."
    ),
    "workflow.turn_calculation.token_aware.enabled": (
        "DEPRECATED. Default: true."
    ),
    # END AUTO-SEEDED CONFIG DESCRIPTIONS
}

# Metadata for configuration paths (used by CLI and TUI helpers)
# Currently supports: sensitive (bool)
CONFIG_METADATA: dict[str, dict[str, object]] = {
    # Auth/session secrets
    "auth_token": {"sensitive": True},
    "refresh_token": {"sensitive": True},
    "firebase_uid": {"sensitive": True},
    "firebase_api_key": {"sensitive": True},
    "token_expires_at": {"sensitive": True},
    # Core orchestration toggles - locked to prevent breaking the system
    "features.core_orchestration.enabled": {
        "locked": True,
        "lock_reason": "Core system setting; use presets instead.",
    },
    "features.core_orchestration.state_manager": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks state management.",
    },
    "features.core_orchestration.orchestrator": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks orchestration.",
    },
    "features.core_orchestration.llm_provider": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks provider selection.",
    },
    "features.core_orchestration.implementation_agent": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks implementation.",
    },
    "features.core_orchestration.config_loading": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks config loading.",
    },
    "features.core_orchestration.response_validation": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks validation.",
    },
    "features.core_orchestration.context_awareness": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks context handling.",
    },
    "features.core_orchestration.working_memory": {
        "locked": True,
        "lock_reason": "Core system setting; disabling breaks working memory.",
    },
}

def get_description(path: str) -> str | None:
    """Get description for a configuration path.

    Args:
        path: Dot-notation path like "llm.orchestrator.provider"

    Returns:
        Description string or None if not found
    """
    return CONFIG_DESCRIPTIONS.get(path)

def is_sensitive(path: str) -> bool:
    """Check if a configuration path is marked as sensitive.

    Args:
        path: Dot-notation path like "llm.orchestrator.provider"

    Returns:
        True if the path should be redacted by default
    """
    meta = CONFIG_METADATA.get(path)
    if meta:
        return bool(meta.get("sensitive"))

    # Fallback pattern checks for unknown paths
    if path.startswith(("auth.", "providers.")):
        return True
    return bool(path.endswith((".api_key", ".token")))

def is_locked(path: str) -> bool:
    """Check if a configuration path is locked (read-only)."""
    meta = CONFIG_METADATA.get(path)
    if meta:
        return bool(meta.get("locked"))
    return False

def get_lock_reason(path: str) -> str | None:
    """Return lock reason for a path, if any."""
    meta = CONFIG_METADATA.get(path)
    if meta:
        reason = meta.get("lock_reason")
        if isinstance(reason, str):
            return reason
    return None

def get_all_paths() -> list[str]:
    """Get all documented configuration paths.

    Returns:
        List of all paths that have descriptions
    """
    return list(CONFIG_DESCRIPTIONS.keys())

# Provider-specific model choices - DYNAMICALLY LOADED from obra.model_registry
# This ensures config command always shows correct, up-to-date model lists
def _load_provider_model_choices() -> dict[str, list[str]]:
    """Load model choices from authoritative MODEL_REGISTRY.

    Returns dict mapping provider name to list of usable model IDs.
    Smart alias filtering:
    - Prefer explicit full names (claude-sonnet-4-6) over short aliases (sonnet)
    - When multiple aliases point to same target, prefer the longer/explicit one
    - Skip deprecated models

    Note: Returns actual model names only. Callers add "per-tier" or other
    special options as needed for their context.
    """
    from obra.model_registry import MODEL_REGISTRY, ModelStatus

    choices: dict[str, list[str]] = {}
    for provider_name, provider_config in MODEL_REGISTRY.items():
        # Start with empty list - actual model names only (no "default")
        model_list: list[str] = []

        # Group models by their resolve target
        # Key: target (or model_id if no target), Value: list of (model_id, length)
        target_groups: dict[str, list[tuple[str, int]]] = {}

        for model_id, model_info in provider_config.models.items():
            # Skip deprecated models
            if model_info.status == ModelStatus.DEPRECATED:
                continue

            # Determine the target (what this model resolves to)
            target = getattr(model_info, "resolves_to", None) or model_id

            if target not in target_groups:
                target_groups[target] = []
            target_groups[target].append((model_id, len(model_id)))

        # For each target, pick the LONGEST model_id (most explicit name)
        for _target, model_ids in target_groups.items():
            # Sort by length descending, pick longest
            model_ids.sort(key=lambda x: -x[1])
            best_model_id = model_ids[0][0]
            model_list.append(best_model_id)

        choices[provider_name] = model_list

    return choices

# Lazy-loaded to avoid circular imports
_PROVIDER_MODEL_CHOICES_CACHE: dict[str, list[str]] | None = None

def _get_provider_model_choices() -> dict[str, list[str]]:
    """Get cached provider model choices, loading on first access."""
    global _PROVIDER_MODEL_CHOICES_CACHE
    if _PROVIDER_MODEL_CHOICES_CACHE is None:
        _PROVIDER_MODEL_CHOICES_CACHE = _load_provider_model_choices()
    return _PROVIDER_MODEL_CHOICES_CACHE

# Mapping of paths to their choices (for enum types)
# Note: model choices are dynamically determined by provider via MODEL_REGISTRY
# Provider list is also dynamically loaded from MODEL_REGISTRY
def _get_provider_list(include_local: bool = True) -> list[str]:
    """Get list of supported providers from MODEL_REGISTRY.

    Args:
        include_local: Include local providers like Ollama.
    """
    from obra.model_registry import get_provider_names

    providers = get_provider_names()
    if include_local:
        return providers
    return [p for p in providers if p != "ollama"]

CONFIG_CHOICES: dict[str, list[str] | None] = {
    # Providers loaded dynamically - will be populated by get_choices()
    "llm.orchestrator.provider": None,
    "llm.orchestrator.model": ["per-tier"],  # Fallback - dynamically populated by provider
    "llm.orchestrator.auth_method": ["oauth", "api_key"],
    "llm.reasoning_level": ["off", "low", "medium", "high", "extra high", "maximum"],
    "pipeline.json_conversion.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.force_level": ["null", "off", "low", "medium", "high", "maximum"],
    "llm.reasoning.tiers.fast.min_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.fast.max_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.medium.min_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.medium.max_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.high.min_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.reasoning.tiers.high.max_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.orchestrator.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.orchestrator.tiers.fast": None,  # Dynamically populated by orchestrator provider
    "llm.orchestrator.tiers.medium": None,  # Dynamically populated by orchestrator provider
    "llm.orchestrator.tiers.high": None,  # Dynamically populated by orchestrator provider
    "llm.implementation.provider": None,
    "llm.implementation.model": ["per-tier"],  # Fallback - dynamically populated by provider
    "llm.implementation.auth_method": ["oauth", "api_key"],
    "llm.fallback.enabled": ["false", "true"],
    "llm.fallback.startup_failover_enabled": ["false", "true"],
    "llm.fallback.recovery.enabled": ["false", "true"],
    "llm.fallback.recovery.require_natural_boundary": ["false", "true"],
    "llm.implementation.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "extra high",
        "maximum",
    ],
    "llm.implementation.tiers.fast": None,  # Dynamically populated by implementation provider
    "llm.implementation.tiers.medium": None,  # Dynamically populated by implementation provider
    "llm.implementation.tiers.high": None,  # Dynamically populated by implementation provider
    "planning.enrichment.stages.assumptions.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.analogues.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.brief.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.derive.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.review.model_tier": ["fast", "medium", "high"],
    "planning.intent_alignment.model_tier": ["fast", "medium", "high"],
    "planning.intent_gap_check.model_tier": ["fast", "medium", "high"],
    "planning.enrichment.stages.assumptions.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.analogues.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.brief.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.derive.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.enrichment.stages.review.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.intent_alignment.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
    "planning.intent_gap_check.reasoning_level": [
        "off",
        "low",
        "medium",
        "high",
        "maximum",
    ],
}

# ---------------------------------------------------------------------------
# get_choices dispatch table
# ---------------------------------------------------------------------------
# Each entry is (matcher, resolver):
#   matcher(path, current_config) -> bool decides whether this pair applies.
#   resolver(path, current_config) -> list[str] | None returns the committed
#     choice list, or None to indicate "fall through to the next pair".
# The runner iterates in source order; if every resolver returns None, the
# runner falls through to CONFIG_CHOICES.get(path) - matching the original
# behaviour of get_choices which ended with that lookup.


def _match_llm_provider(path: str, _cfg: dict | None) -> bool:
    return path == "llm.provider"


def _resolve_llm_provider(_path: str, _cfg: dict | None) -> list[str] | None:
    return ["per-role", *_get_provider_list()]


def _match_llm_model(path: str, _cfg: dict | None) -> bool:
    return path == "llm.model"


def _resolve_llm_model(_path: str, _cfg: dict | None) -> list[str] | None:
    # Collect all models from non-Ollama providers (Ollama is advanced/local
    # only). Note: 'default' is NOT included - use 'per-tier' for default.
    all_models = ["per-tier"]
    model_choices = _get_provider_model_choices()
    seen = {"per-tier", "default"}
    visible_providers = set(_get_provider_list(include_local=False))
    for provider, models in model_choices.items():
        if provider not in visible_providers:
            continue
        for m in models:
            if m not in seen:
                all_models.append(m)
                seen.add(m)
    return all_models


def _match_role_provider(path: str, _cfg: dict | None) -> bool:
    return path in ("llm.orchestrator.provider", "llm.implementation.provider")


def _resolve_role_provider(_path: str, _cfg: dict | None) -> list[str] | None:
    return ["per-tier", *_get_provider_list()]


def _match_fallback_role_provider(path: str, _cfg: dict | None) -> bool:
    return path in (
        "llm.fallback.orchestrator.provider",
        "llm.fallback.implementation.provider",
    )


def _resolve_fallback_role_provider(_path: str, _cfg: dict | None) -> list[str] | None:
    return _get_provider_list()


def _match_fallback_tier(path: str, current_config: dict | None) -> bool:
    return bool(current_config) and path.startswith("llm.fallback.") and ".tiers." in path


def _resolve_fallback_tier(path: str, current_config: dict | None) -> list[str] | None:
    if path.endswith(".reasoning_level"):
        return ["default", "off", "low", "medium", "high", "extra high", "maximum"]
    if not (path.endswith(".model") or path.count(".") == 4):
        return None
    if ".orchestrator." in path:
        provider_path = "llm.fallback.orchestrator.provider"
    else:
        provider_path = "llm.fallback.implementation.provider"
    assert current_config is not None  # matcher guarantees truthy cfg
    tier_provider = _get_nested_value(current_config, provider_path)
    if isinstance(tier_provider, str):
        model_choices = _get_provider_model_choices()
        if tier_provider in model_choices:
            return ["default", *model_choices[tier_provider]]
    return None


def _match_any_provider(path: str, _cfg: dict | None) -> bool:
    return path.endswith(".provider")


def _resolve_any_provider(_path: str, _cfg: dict | None) -> list[str] | None:
    return _get_provider_list()


def _match_role_model(path: str, current_config: dict | None) -> bool:
    return (
        path in ("llm.orchestrator.model", "llm.implementation.model")
        and bool(current_config)
    )


def _resolve_role_model(path: str, current_config: dict | None) -> list[str] | None:
    assert current_config is not None  # matcher guarantees truthy cfg
    if "orchestrator" in path:
        provider_path = "llm.orchestrator.provider"
    else:
        provider_path = "llm.implementation.provider"

    role_provider: Any = _get_nested_value(current_config, provider_path)
    if not isinstance(role_provider, str) or role_provider == "per-role":
        top_provider = _get_nested_value(current_config, "llm.provider")
        if isinstance(top_provider, str) and top_provider != "per-role":
            role_provider = top_provider

    if isinstance(role_provider, str) and role_provider != "per-role":
        model_choices = _get_provider_model_choices()
        if role_provider in model_choices:
            return ["per-tier"] + model_choices[role_provider]
    return None


def _match_tier_model(path: str, current_config: dict | None) -> bool:
    return (
        bool(current_config)
        and ".tiers." in path
        and path.endswith((".fast", ".medium", ".high"))
    )


def _tier_models_for_per_tier() -> list[str] | None:
    model_choices = _get_provider_model_choices()
    tier_models: list[str] = ["default"]
    tier_seen: set[str] = {"default"}
    visible_providers = set(_get_provider_list())
    for prov, models in model_choices.items():
        if prov not in visible_providers:
            continue
        for m in models:
            if m not in tier_seen:
                tier_models.append(m)
                tier_seen.add(m)
    return tier_models if tier_models else None


def _resolve_tier_model(path: str, current_config: dict | None) -> list[str] | None:
    assert current_config is not None  # matcher guarantees truthy cfg
    if "llm.orchestrator.tiers" in path:
        provider_path = "llm.orchestrator.provider"
    elif "llm.implementation.tiers" in path:
        provider_path = "llm.implementation.provider"
    else:
        # Preserve original semantic: fall through to CONFIG_CHOICES.get(path).
        return None

    tier_provider: Any = _get_nested_value(current_config, provider_path)
    if not isinstance(tier_provider, str) or tier_provider == "per-role":
        top_provider = _get_nested_value(current_config, "llm.provider")
        if isinstance(top_provider, str) and top_provider != "per-role":
            tier_provider = top_provider

    if tier_provider == "per-tier":
        return _tier_models_for_per_tier()

    if isinstance(tier_provider, str) and tier_provider not in ("per-role", "per-tier"):
        model_choices = _get_provider_model_choices()
        if tier_provider in model_choices:
            return ["default", *model_choices[tier_provider]]
    return None


# Ordered dispatch table - order mirrors the original if-block sequence.
_CHOICES_DISPATCH: list[tuple[Any, Any]] = [
    (_match_llm_provider, _resolve_llm_provider),
    (_match_llm_model, _resolve_llm_model),
    (_match_role_provider, _resolve_role_provider),
    (_match_fallback_role_provider, _resolve_fallback_role_provider),
    (_match_fallback_tier, _resolve_fallback_tier),
    (_match_any_provider, _resolve_any_provider),
    (_match_role_model, _resolve_role_model),
    (_match_tier_model, _resolve_tier_model),
]


def get_choices(path: str, current_config: dict | None = None) -> list[str] | None:
    """Get valid choices for an enum-type setting.

    For model settings, returns provider-specific choices if provider is known.
    For provider settings, returns dynamic list from MODEL_REGISTRY.

    Args:
        path: Dot-notation path
        current_config: Optional current config dict to determine provider

    Returns:
        List of valid choices or None if not an enum type
    """
    for matcher, resolver in _CHOICES_DISPATCH:
        if matcher(path, current_config):
            result = resolver(path, current_config)
            if result is not None:
                return result
    return CONFIG_CHOICES.get(path)

def _get_nested_value(config: dict, path: str) -> object | None:
    """Get a nested value from config dict using dot notation.

    Args:
        config: Configuration dictionary
        path: Dot-notation path like "llm.orchestrator.provider"

    Returns:
        Value at that path or None if not found
    """
    parts = path.split(".")
    current = config
    for part in parts:
        if isinstance(current, dict) and part in current:
            current = current[part]
        else:
            return None
    return current

# Mapping of paths to their default values
CONFIG_DEFAULTS: dict[str, object] = {
    # Quick settings - special defaults for fast-config pattern
    "llm.provider": "per-role",  # per-role = children decide their own provider
    "llm.model": "per-tier",  # per-tier = tiers decide their own model
    "llm.reasoning_level": "medium",
    "llm.reasoning.force_level": None,
    "llm.reasoning.strict_mode": False,
    "llm.reasoning.tiers.fast.min_level": "off",
    "llm.reasoning.tiers.fast.max_level": "maximum",
    "llm.reasoning.tiers.medium.min_level": "off",
    "llm.reasoning.tiers.medium.max_level": "maximum",
    "llm.reasoning.tiers.high.min_level": "off",
    "llm.reasoning.tiers.high.max_level": "maximum",
    # Role-specific defaults
    "llm.orchestrator.provider": "anthropic",
    "llm.orchestrator.model": "per-tier",  # per-tier = tiers decide their own model
    "llm.orchestrator.auth_method": "oauth",
    "llm.orchestrator.reasoning_level": "medium",
    "llm.git.skip_check": True,
    "llm.git.auto_init": False,
    "llm.git.auto_init_require_depth": 2,
    "llm.git.auto_init_max_files": 1000,
    "llm.git.auto_init_blacklist": [],
    "llm.codex.approval_mode": "full-auto",
    "llm.codex.bypass_sandbox": True,
    "llm.codex.enable_features": [],
    "llm.codex.disable_features": ["multi_agent"],
    # Tier defaults preserve "Let Obra choose" semantics.
    "llm.orchestrator.tiers.fast": "default",
    "llm.orchestrator.tiers.medium": "default",
    "llm.orchestrator.tiers.high": "default",
    "llm.implementation.provider": "anthropic",
    "llm.implementation.model": "per-tier",  # per-tier = tiers decide their own model
    "llm.implementation.auth_method": "oauth",
    "llm.implementation.reasoning_level": "medium",
    "llm.implementation.tiers.fast": "default",
    "llm.implementation.tiers.medium": "default",
    "llm.implementation.tiers.high": "default",
    # Role-based LLM configuration defaults (ADR-069)
    "llm.roles.derive": "orchestrator",
    "llm.roles.examine": "orchestrator",
    "llm.roles.revise": "orchestrator",
    "llm.roles.execute": "implementation",
    "llm.roles.fix": "implementation",
    "llm.roles.review": "implementation",
    "llm.roles.json_conversion": {"profile": "orchestrator", "tier": "fast"},
    "llm.roles.enrichment_assumptions": "orchestrator",
    "llm.roles.enrichment_analogues": "orchestrator",
    "llm.roles.enrichment_brief": "orchestrator",
    "llm_timeout": 3600,
    "orchestration.prompts.retain": False,
    "orchestration.prompts.max_files": 200,
    "orchestration.prompts.cleanup_age_hours": 24,
    "orchestration.timeouts.llm_call_s": 3600,
    "orchestration.timeouts.llm_request_s": None,
    "orchestration.template_retention.keep_on_success": False,
    "orchestration.template_retention.keep_on_error": True,
    "orchestration.timeouts.agent_execution_s": 5400,
    "orchestration.timeouts.review_agent_s": 1800,
    "orchestration.timeouts.cli_runner_s": 7200,
    "orchestration.timeouts.llm_stream_idle_s": 300,
    "orchestration.decomposition.enabled": True,
    "orchestration.decomposition.duration_threshold_s": 1800,
    "orchestration.decomposition.warning_threshold_ratio": 0.8,
    "orchestration.decomposition.warning_threshold_s": None,
    "orchestration.decomposition.execute_stream_idle_s": None,
    "orchestration.decomposition.failure_threshold": 3,
    "orchestration.decomposition.max_attempts": 2,
    "orchestration.decomposition.summary_max_chars": 2000,
    "orchestration.progress.heartbeat_interval_s": 60,
    "orchestration.progress.heartbeat_initial_delay_s": 30,
    "orchestration.watchdog.enabled": True,
    "orchestration.watchdog.stall_timeout_s": 300,
    "orchestration.interactive_guard.enabled": True,
    "orchestration.interactive_guard.patterns": [
        r"(?i)\bpassword\b",
        r"(?i)enter passphrase",
        r"(?i)are you sure.*\?(\s*\[y/n\]|\s*\(y/n\))?",
        r"(?i)continue\?\s*(\[y/n\]|\(y/n\))?",
        r"(?i)press any key",
        r"(?i)enter .* to continue",
    ],
    "orchestration.interactive_guard.retry_max": 1,
    "orchestration.interactive_guard.rollback.enabled": True,
    "orchestration.interactive_guard.rollback.trigger_codes": ["LLM_INTERACTIVE_BLOCKED"],
    "features.performance_control.budgets.enabled": True,
    "features.performance_control.budgets.defaults.time_minutes": 30,
    "features.performance_control.budgets.defaults.iterations": 50,
    "features.quality_automation.agents.security_audit.enabled": False,
    "features.quality_automation.agents.security_audit.llm.provider": "inherit",
    "features.quality_automation.agents.security_audit.llm.model": "inherit",
    "features.quality_automation.agents.security_audit.llm.model_tier": "inherit",
    "features.quality_automation.agents.security_audit.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.rca_agent.enabled": True,
    "features.quality_automation.agents.rca_agent.llm.provider": "inherit",
    "features.quality_automation.agents.rca_agent.llm.model": "inherit",
    "features.quality_automation.agents.rca_agent.llm.model_tier": "inherit",
    "features.quality_automation.agents.rca_agent.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.doc_audit.enabled": False,
    "features.quality_automation.agents.doc_audit.llm.provider": "inherit",
    "features.quality_automation.agents.doc_audit.llm.model": "inherit",
    "features.quality_automation.agents.doc_audit.llm.model_tier": "inherit",
    "features.quality_automation.agents.doc_audit.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.code_review.enabled": True,
    "features.quality_automation.agents.code_review.llm.provider": "inherit",
    "features.quality_automation.agents.code_review.llm.model": "inherit",
    "features.quality_automation.agents.code_review.llm.model_tier": "inherit",
    "features.quality_automation.agents.code_review.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.test_generation.enabled": True,
    "features.quality_automation.agents.test_generation.llm.provider": "inherit",
    "features.quality_automation.agents.test_generation.llm.model": "inherit",
    "features.quality_automation.agents.test_generation.llm.model_tier": "inherit",
    "features.quality_automation.agents.test_generation.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.test_execution.enabled": True,
    "features.quality_automation.agents.test_execution.llm.provider": "inherit",
    "features.quality_automation.agents.test_execution.llm.model": "inherit",
    "features.quality_automation.agents.test_execution.llm.model_tier": "inherit",
    "features.quality_automation.agents.test_execution.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.sense_check.enabled": False,
    "features.quality_automation.agents.sense_check.llm.provider": "inherit",
    "features.quality_automation.agents.sense_check.llm.model": "inherit",
    "features.quality_automation.agents.sense_check.llm.model_tier": "inherit",
    "features.quality_automation.agents.sense_check.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.code_verify.enabled": True,
    "features.quality_automation.agents.code_verify.llm.provider": "inherit",
    "features.quality_automation.agents.code_verify.llm.model": "inherit",
    "features.quality_automation.agents.code_verify.llm.model_tier": "inherit",
    "features.quality_automation.agents.code_verify.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.escalation_fixer.enabled": False,
    "features.quality_automation.agents.escalation_fixer.llm.provider": "inherit",
    "features.quality_automation.agents.escalation_fixer.llm.model": "inherit",
    "features.quality_automation.agents.escalation_fixer.llm.model_tier": "inherit",
    "features.quality_automation.agents.escalation_fixer.llm.reasoning_level": "inherit",
    "features.quality_automation.agents.ignore_patterns": [
        "logs",
        "firebase-seed-data",
        "research",
        "emulator-backup",
    ],
    "review.escalation_fixer.enabled": False,
    "review.escalation_fixer.timeout_s": 600,
    "review.escalation_fixer.max_attempts_per_episode": 1,
    "review.escalation_fixer.allowed_routes": [
        "amend_plan",
        "fix_code",
        "reclassify_review",
        "retry_stage",
        "escalate",
    ],
    "review.escalation_fixer.eligible_reason_codes": [
        "blocking_issues_unresolved",
        "convergence_stalled",
        "quality_threshold_not_met",
        "max_iterations",
        "revision_merge_rejected",
        "max_refinement_iterations",
        "pre_dispatch_invariant",
    ],
    "features.workflow.enabled": True,
    "advanced.debug_mode": False,
    "advanced.experimental_features": False,
    "advanced.telemetry.enabled": True,
    # Development debug defaults
    "features.development_debug.enabled": False,
    "features.development_debug.debug_features.verbose_logging": False,
    "features.development_debug.debug_features.save_interactions": False,
    "features.development_debug.debug_features.audit_logging": False,
    "features.development_debug.breakpoints.enabled": False,
    "features.development_debug.breakpoints.triggers.validation_failed": True,
    "features.development_debug.breakpoints.triggers.rate_limit_hit": True,
    "features.development_debug.breakpoints.triggers.unexpected_error": True,
    "features.development_debug.monitoring.file_watcher": False,
    "features.development_debug.monitoring.output_monitor": False,
    "features.development_debug.production_logging.enabled": False,
    "orchestration.resilience.default.max_retries": 3,
    "planning.enrichment.enabled": True,
    "planning.enrichment.always_on": False,  # Smart mode default
    "planning.enrichment.stages.assumptions.model_tier": "medium",
    "planning.enrichment.stages.assumptions.reasoning_level": "medium",
    "planning.enrichment.stages.assumptions.max_passes": 3,
    "planning.enrichment.stages.assumptions.timeout_s": None,
    "planning.enrichment.stages.assumptions.max_questions": 3,
    "planning.enrichment.stages.analogues.model_tier": "high",
    "planning.enrichment.stages.analogues.reasoning_level": "high",
    "planning.enrichment.stages.analogues.max_passes": 3,
    "planning.enrichment.stages.analogues.timeout_s": None,
    "planning.enrichment.stages.brief.model_tier": "medium",
    "planning.enrichment.stages.brief.reasoning_level": "medium",
    "planning.enrichment.stages.brief.max_passes": 3,
    "planning.enrichment.stages.brief.timeout_s": None,
    "planning.enrichment.stages.derive.model_tier": "high",
    "planning.enrichment.stages.derive.reasoning_level": "high",
    "planning.enrichment.stages.derive.max_passes": 3,
    "planning.enrichment.stages.derive.timeout_s": None,
    "planning.enrichment.stages.review.model_tier": "high",
    "planning.enrichment.stages.review.reasoning_level": "high",
    "planning.enrichment.stages.review.max_passes": 3,
    "planning.enrichment.stages.review.timeout_s": None,
    "planning.enrichment.stages.review.max_concurrent": 4,
    "planning.enrichment.non_inferable_categories": [],  # Empty by default
    "planning.enrichment.diff.path_template": "~/.obra/intents/{intent_id}.diff.json",
    "planning.enrichment.diff.retention.max_files": 200,
    "planning.enrichment.artifacts.dir": "~/.obra/intents/artifacts",
    "planning.enrichment.artifacts.retention.max_files": 200,
    "planning.enrichment.analogue_cache.global_path": None,
    "planning.enrichment.analogue_cache.project_path": ".obra/analogue_cache.json",
    "planning.enrichment.analogue_cache.max_entries": 10,
    "planning.enrichment.analogue_cache.max_render_tokens": 5000,
    "planning.enrichment.telemetry.enabled": False,
    "planning.enrichment.telemetry.include_content": False,
    "planning.enrichment.telemetry.output_path": "~/.obra/telemetry/enrichment.jsonl",
    "planning.intent_alignment.model_tier": "high",
    "planning.intent_alignment.reasoning_level": "high",
    "planning.intent_alignment.max_passes": 3,
    "planning.intent_alignment.timeout_s": None,
    "planning.intent_alignment.block_on_fail": False,
    "planning.intent_alignment.max_concurrent": 4,
    "planning.intent_gap_check.story_enabled": True,
    "planning.intent_gap_check.epic_enabled": True,
    "planning.intent_gap_check.auto_append": True,
    "planning.intent_gap_check.max_new_stories": 3,
    "planning.intent_gap_check.model_tier": "high",
    "planning.intent_gap_check.reasoning_level": "high",
    "planning.intent_gap_check.max_passes": 3,
    "planning.intent_gap_check.timeout_s": None,
    "planning.intent_gap_check.artifacts_dir": "~/.obra/intent_gap_reports",
}

def get_default(path: str) -> object:
    """Get default value for a setting.

    Args:
        path: Dot-notation path

    Returns:
        Default value or None if not defined
    """
    return CONFIG_DEFAULTS.get(path)

# Setting tier mapping (basic, standard, advanced)
SETTING_TIERS: dict[str, str] = {
    # Basic - most users need these
    "llm.orchestrator.provider": "basic",
    "llm.orchestrator.model": "basic",
    "llm.implementation.provider": "basic",
    "llm.implementation.model": "basic",
    "llm.fallback.enabled": "basic",
    "preset": "basic",
    # Standard - common use
    "llm.reasoning_level": "standard",
    "llm.reasoning": "standard",
    "llm.reasoning.force_level": "standard",
    "llm.reasoning.strict_mode": "standard",
    "llm.reasoning.tiers": "standard",
    "llm.reasoning.tiers.fast": "standard",
    "llm.reasoning.tiers.fast.min_level": "standard",
    "llm.reasoning.tiers.fast.max_level": "standard",
    "llm.reasoning.tiers.medium": "standard",
    "llm.reasoning.tiers.medium.min_level": "standard",
    "llm.reasoning.tiers.medium.max_level": "standard",
    "llm.reasoning.tiers.high": "standard",
    "llm.reasoning.tiers.high.min_level": "standard",
    "llm.reasoning.tiers.high.max_level": "standard",
    "llm.orchestrator.reasoning_level": "standard",
    "llm.implementation.reasoning_level": "standard",
    "llm.orchestrator.auth_method": "standard",
    "llm.implementation.auth_method": "standard",
    "llm.orchestrator.tiers": "standard",
    "llm.orchestrator.tiers.fast": "standard",
    "llm.orchestrator.tiers.medium": "standard",
    "llm.orchestrator.tiers.high": "standard",
    "llm.implementation.tiers": "standard",
    "llm.implementation.tiers.fast": "standard",
    "llm.implementation.tiers.medium": "standard",
    "llm.implementation.tiers.high": "standard",
    "llm.fallback.cooldown_s": "standard",
    "llm.fallback.startup_failover_enabled": "standard",
    "llm.fallback.transient_error_classes": "advanced",
    "llm.fallback.recovery.enabled": "standard",
    "llm.fallback.recovery.cooldown_s": "standard",
    "llm.fallback.recovery.max_canary_attempts_per_session": "standard",
    "llm.fallback.recovery.require_natural_boundary": "standard",
    "llm.fallback.orchestrator.provider": "standard",
    "llm.fallback.orchestrator.tiers.fast": "standard",
    "llm.fallback.orchestrator.tiers.fast.model": "standard",
    "llm.fallback.orchestrator.tiers.fast.reasoning_level": "standard",
    "llm.fallback.orchestrator.tiers.medium": "standard",
    "llm.fallback.orchestrator.tiers.medium.model": "standard",
    "llm.fallback.orchestrator.tiers.medium.reasoning_level": "standard",
    "llm.fallback.orchestrator.tiers.high": "standard",
    "llm.fallback.orchestrator.tiers.high.model": "standard",
    "llm.fallback.orchestrator.tiers.high.reasoning_level": "standard",
    "llm.fallback.implementation.provider": "standard",
    "llm.fallback.implementation.tiers.fast": "standard",
    "llm.fallback.implementation.tiers.fast.model": "standard",
    "llm.fallback.implementation.tiers.fast.reasoning_level": "standard",
    "llm.fallback.implementation.tiers.medium": "standard",
    "llm.fallback.implementation.tiers.medium.model": "standard",
    "llm.fallback.implementation.tiers.medium.reasoning_level": "standard",
    "llm.fallback.implementation.tiers.high": "standard",
    "llm.fallback.implementation.tiers.high.model": "standard",
    "llm.fallback.implementation.tiers.high.reasoning_level": "standard",
    "features.performance_control.budgets.enabled": "standard",
    "features.quality_automation.agents.security_audit.enabled": "standard",
    "features.quality_automation.agents.security_audit.llm.provider": "standard",
    "features.quality_automation.agents.security_audit.llm.model": "standard",
    "features.quality_automation.agents.security_audit.llm.model_tier": "standard",
    "features.quality_automation.agents.security_audit.llm.reasoning_level": "standard",
    "features.quality_automation.agents.rca_agent.enabled": "standard",
    "features.quality_automation.agents.rca_agent.llm.provider": "standard",
    "features.quality_automation.agents.rca_agent.llm.model": "standard",
    "features.quality_automation.agents.rca_agent.llm.model_tier": "standard",
    "features.quality_automation.agents.rca_agent.llm.reasoning_level": "standard",
    "features.quality_automation.agents.doc_audit.enabled": "standard",
    "features.quality_automation.agents.doc_audit.llm.provider": "standard",
    "features.quality_automation.agents.doc_audit.llm.model": "standard",
    "features.quality_automation.agents.doc_audit.llm.model_tier": "standard",
    "features.quality_automation.agents.doc_audit.llm.reasoning_level": "standard",
    "features.quality_automation.agents.code_review.enabled": "standard",
    "features.quality_automation.agents.code_review.llm.provider": "standard",
    "features.quality_automation.agents.code_review.llm.model": "standard",
    "features.quality_automation.agents.code_review.llm.model_tier": "standard",
    "features.quality_automation.agents.code_review.llm.reasoning_level": "standard",
    "features.quality_automation.agents.test_generation.enabled": "standard",
    "features.quality_automation.agents.test_generation.llm.provider": "standard",
    "features.quality_automation.agents.test_generation.llm.model": "standard",
    "features.quality_automation.agents.test_generation.llm.model_tier": "standard",
    "features.quality_automation.agents.test_generation.llm.reasoning_level": "standard",
    "features.quality_automation.agents.test_execution.enabled": "standard",
    "features.quality_automation.agents.test_execution.llm.provider": "standard",
    "features.quality_automation.agents.test_execution.llm.model": "standard",
    "features.quality_automation.agents.test_execution.llm.model_tier": "standard",
    "features.quality_automation.agents.test_execution.llm.reasoning_level": "standard",
    "features.quality_automation.agents.sense_check.enabled": "standard",
    "features.quality_automation.agents.sense_check.llm.provider": "standard",
    "features.quality_automation.agents.sense_check.llm.model": "standard",
    "features.quality_automation.agents.sense_check.llm.model_tier": "standard",
    "features.quality_automation.agents.sense_check.llm.reasoning_level": "standard",
    "features.quality_automation.agents.code_verify.enabled": "standard",
    "features.quality_automation.agents.code_verify.llm.provider": "standard",
    "features.quality_automation.agents.code_verify.llm.model": "standard",
    "features.quality_automation.agents.code_verify.llm.model_tier": "standard",
    "features.quality_automation.agents.code_verify.llm.reasoning_level": "standard",
    "features.quality_automation.agents.escalation_fixer.enabled": "standard",
    "features.quality_automation.agents.escalation_fixer.llm.provider": "standard",
    "features.quality_automation.agents.escalation_fixer.llm.model": "standard",
    "features.quality_automation.agents.escalation_fixer.llm.model_tier": "standard",
    "features.quality_automation.agents.escalation_fixer.llm.reasoning_level": "standard",
    "features.quality_automation.agents.ignore_patterns": "standard",
    "review.escalation_fixer.enabled": "standard",
    "review.escalation_fixer.timeout_s": "standard",
    "review.escalation_fixer.max_attempts_per_episode": "standard",
    "review.escalation_fixer.allowed_routes": "standard",
    "review.escalation_fixer.eligible_reason_codes": "standard",
    "features.workflow.enabled": "standard",
    # Git settings - visible for provider-aware auto-configuration
    "llm.git": "basic",
    "llm.git.skip_check": "basic",
    "llm.git.auto_init": "standard",
    "llm.git.auto_init_require_depth": "standard",
    "llm.git.auto_init_max_files": "standard",
    "llm.git.auto_init_blacklist": "advanced",
    # Role-based LLM configuration (ADR-069) - advanced for fine-grained control
    "llm.roles": "advanced",
    "llm.roles.derive": "advanced",
    "llm.roles.examine": "advanced",
    "llm.roles.revise": "advanced",
    "llm.roles.execute": "advanced",
    "llm.roles.fix": "advanced",
    "llm.roles.review": "advanced",
    "llm.roles.json_conversion": "advanced",
    "llm.roles.enrichment_assumptions": "advanced",
    "llm.roles.enrichment_analogues": "advanced",
    "llm.roles.enrichment_brief": "advanced",
    # Advanced - expert users
    "api_base_url": "advanced",
    "llm_timeout": "advanced",
    "orchestration.timeouts.llm_call_s": "advanced",
    "orchestration.timeouts.llm_request_s": "advanced",
    "orchestration.template_retention": "advanced",
    "orchestration.template_retention.keep_on_success": "advanced",
    "orchestration.template_retention.keep_on_error": "advanced",
    "orchestration.timeouts.agent_execution_s": "advanced",
    "orchestration.timeouts.review_agent_s": "advanced",
    "orchestration.timeouts.cli_runner_s": "advanced",
    "orchestration.timeouts.llm_stream_idle_s": "advanced",
    "orchestration.decomposition": "advanced",
    "orchestration.decomposition.enabled": "advanced",
    "orchestration.decomposition.duration_threshold_s": "advanced",
    "orchestration.decomposition.warning_threshold_ratio": "advanced",
    "orchestration.decomposition.warning_threshold_s": "advanced",
    "orchestration.decomposition.execute_stream_idle_s": "advanced",
    "orchestration.decomposition.failure_threshold": "advanced",
    "orchestration.decomposition.max_attempts": "advanced",
    "orchestration.decomposition.summary_max_chars": "advanced",
    "orchestration.progress.heartbeat_interval_s": "advanced",
    "orchestration.progress.heartbeat_initial_delay_s": "advanced",
    "orchestration.watchdog.enabled": "advanced",
    "orchestration.watchdog.stall_timeout_s": "advanced",
    "orchestration.interactive_guard.enabled": "advanced",
    "orchestration.interactive_guard.patterns": "advanced",
    "orchestration.interactive_guard.retry_max": "advanced",
    "orchestration.interactive_guard.rollback.enabled": "advanced",
    "orchestration.interactive_guard.rollback.trigger_codes": "advanced",
    "advanced.debug_mode": "advanced",
    "advanced.experimental_features": "advanced",
    "advanced.telemetry.enabled": "advanced",
    # Prompt retention
    "orchestration.prompts": "advanced",
    "orchestration.prompts.retain": "advanced",
    "orchestration.prompts.max_files": "advanced",
    "orchestration.prompts.cleanup_age_hours": "advanced",
    # Development debug
    "features.development_debug": "advanced",
    "features.development_debug.enabled": "advanced",
    "features.development_debug.debug_features.verbose_logging": "advanced",
    "features.development_debug.debug_features.save_interactions": "advanced",
    "features.development_debug.debug_features.audit_logging": "advanced",
    "features.development_debug.breakpoints.enabled": "advanced",
    "features.development_debug.breakpoints.triggers.validation_failed": "advanced",
    "features.development_debug.breakpoints.triggers.rate_limit_hit": "advanced",
    "features.development_debug.breakpoints.triggers.unexpected_error": "advanced",
    "features.development_debug.monitoring.file_watcher": "advanced",
    "features.development_debug.monitoring.output_monitor": "advanced",
    "features.development_debug.production_logging.enabled": "advanced",
    "orchestration.resilience.default.max_retries": "advanced",
    "features.performance_control.budgets.defaults.time_minutes": "advanced",
    "features.performance_control.budgets.defaults.iterations": "advanced",
    "planning": "advanced",
    "planning.enrichment": "advanced",
    "planning.enrichment.enabled": "advanced",
    "planning.enrichment.always_on": "advanced",
    "planning.enrichment.stages": "advanced",
    "planning.enrichment.stages.assumptions": "advanced",
    "planning.enrichment.stages.assumptions.model_tier": "advanced",
    "planning.enrichment.stages.assumptions.reasoning_level": "advanced",
    "planning.enrichment.stages.assumptions.max_passes": "advanced",
    "planning.enrichment.stages.assumptions.timeout_s": "advanced",
    "planning.enrichment.stages.assumptions.max_questions": "advanced",
    "planning.enrichment.stages.analogues": "advanced",
    "planning.enrichment.stages.analogues.model_tier": "advanced",
    "planning.enrichment.stages.analogues.reasoning_level": "advanced",
    "planning.enrichment.stages.analogues.max_passes": "advanced",
    "planning.enrichment.stages.analogues.timeout_s": "advanced",
    "planning.enrichment.stages.brief": "advanced",
    "planning.enrichment.stages.brief.model_tier": "advanced",
    "planning.enrichment.stages.brief.reasoning_level": "advanced",
    "planning.enrichment.stages.brief.max_passes": "advanced",
    "planning.enrichment.stages.brief.timeout_s": "advanced",
    "planning.enrichment.stages.derive": "advanced",
    "planning.enrichment.stages.derive.model_tier": "advanced",
    "planning.enrichment.stages.derive.reasoning_level": "advanced",
    "planning.enrichment.stages.derive.max_passes": "advanced",
    "planning.enrichment.stages.derive.timeout_s": "advanced",
    "planning.enrichment.stages.review": "advanced",
    "planning.enrichment.stages.review.model_tier": "advanced",
    "planning.enrichment.stages.review.reasoning_level": "advanced",
    "planning.enrichment.stages.review.max_passes": "advanced",
    "planning.enrichment.stages.review.timeout_s": "advanced",
    "planning.enrichment.stages.review.max_concurrent": "advanced",
    "planning.enrichment.non_inferable_categories": "advanced",
    "planning.enrichment.diff": "advanced",
    "planning.enrichment.diff.path_template": "advanced",
    "planning.enrichment.diff.retention": "advanced",
    "planning.enrichment.diff.retention.max_files": "advanced",
    "planning.enrichment.artifacts": "advanced",
    "planning.enrichment.artifacts.dir": "advanced",
    "planning.enrichment.artifacts.retention": "advanced",
    "planning.enrichment.artifacts.retention.max_files": "advanced",
    "planning.enrichment.analogue_cache": "advanced",
    "planning.enrichment.analogue_cache.global_path": "advanced",
    "planning.enrichment.analogue_cache.project_path": "advanced",
    "planning.enrichment.analogue_cache.max_entries": "advanced",
    "planning.enrichment.analogue_cache.max_render_tokens": "advanced",
    "planning.enrichment.telemetry": "advanced",
    "planning.enrichment.telemetry.enabled": "advanced",
    "planning.enrichment.telemetry.include_content": "advanced",
    "planning.enrichment.telemetry.output_path": "advanced",
    "planning.intent_alignment.max_concurrent": "advanced",
    "pipeline.json_conversion.reasoning_level": "advanced",
}

def get_tier(path: str) -> str:
    """Get visibility tier for a setting.

    Args:
        path: Dot-notation path

    Returns:
        "basic", "standard", or "advanced" (defaults to "standard")
    """
    if path.startswith("advanced."):
        return "advanced"
    return SETTING_TIERS.get(path, "standard")
