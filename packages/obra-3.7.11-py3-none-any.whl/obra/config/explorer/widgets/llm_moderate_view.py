"""Moderate LLM Configuration View widget.

Provides an interface for configuring provider and tier-based models
(fast/medium/high) for both orchestrator and implementation roles.
"""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, ScrollableContainer, Vertical
from textual.message import Message
from textual.widgets import Label, Rule, Select, Static

from obra.config.explorer.llm_registry import (
    build_authoritative_llm_preview,
    get_model_cost,
    get_models,
    get_providers,
    get_role_tier_defaults,
    resolve_tier_model_display,
)
from obra.config.explorer.widgets.navigation_menu import get_menu_info
from obra.config.explorer.widgets.saveable_view import SaveableViewMixin
from obra.model_registry import REASONING_LEVELS

DEFAULT_REASONING_VALUE = "default"


class ModerateLLMView(SaveableViewMixin, Static):
    """Moderate LLM configuration view with tier-based model selection.

    For each role (orchestrator/implementation), configures:
    - Provider: Which LLM provider to use
    - Fast tier: Model for quick, simple operations
    - Medium tier: Model for balanced performance
    - High tier: Model for complex reasoning tasks

    Emits:
        Changed: When any configuration changes.
    """

    DEFAULT_CSS = """
    ModerateLLMView {
        width: 100%;
        height: 100%;
        padding: 1 2;
    }

    ModerateLLMView #content-scroll {
        width: 100%;
        height: 1fr;
        min-height: 10;
    }

    ModerateLLMView .header {
        text-style: bold;
        text-align: center;
        margin-bottom: 1;
        width: 100%;
    }

    ModerateLLMView .description {
        color: $text-muted;
        text-align: center;
        margin-bottom: 2;
        width: 100%;
    }

    ModerateLLMView .role-section {
        width: 100%;
        height: auto;
        padding: 1;
        margin-bottom: 1;
    }

    ModerateLLMView .role-header {
        text-style: bold;
        margin-bottom: 1;
        color: $primary;
    }

    ModerateLLMView .config-row {
        width: 100%;
        height: auto;
        margin-bottom: 1;
    }

    ModerateLLMView .config-label {
        width: 18;
    }

    ModerateLLMView .config-select {
        width: 1fr;
    }

    ModerateLLMView .tier-label {
        width: 18;
        color: $text-muted;
    }

    ModerateLLMView .tier-hint {
        color: $text-muted;
        margin-left: 18;
        margin-bottom: 1;
    }

    ModerateLLMView .tier-hint-resolved {
        color: $success;
    }

    ModerateLLMView .help-text {
        color: $text-muted;
        margin-top: 2;
        text-align: left;
        width: 100%;
        padding: 1;
        background: $surface;
    }

    ModerateLLMView .preview-box {
        width: 100%;
        height: auto;
        min-height: 6;
        margin-top: 2;
        padding: 1 2;
        background: $surface;
        border: solid $primary-darken-2;
        text-align: left;
        color: $text;
    }

    ModerateLLMView Rule {
        margin: 1 0;
    }

    ModerateLLMView .fallback-section {
        width: 100%;
        height: auto;
        padding: 1;
        background: $surface;
    }

    ModerateLLMView #fallback-controls {
        width: 100%;
        height: auto;
    }

    ModerateLLMView .disabled-section {
        opacity: 0.4;
    }
    """

    class Changed(Message):
        """Message emitted when LLM configuration changes."""

        def __init__(
            self,
            orchestrator_provider: str,
            orchestrator_tiers: dict[str, str],
            orchestrator_reasoning_tiers: dict[str, str],
            implementation_provider: str,
            implementation_tiers: dict[str, str],
            implementation_reasoning_tiers: dict[str, str],
            *,
            fallback_enabled: bool = False,
            fallback_cooldown_s: int = 300,
            fallback_transient_error_classes: list[str] | None = None,
            fallback_startup_failover_enabled: bool = True,
            fallback_recovery_enabled: bool = True,
            fallback_recovery_cooldown_s: int = 900,
            fallback_recovery_max_canary_attempts_per_session: int = 1,
            fallback_recovery_require_natural_boundary: bool = True,
            fallback_orchestrator_provider: str = "anthropic",
            fallback_orchestrator_tiers: dict[str, str] | None = None,
            fallback_orchestrator_reasoning_tiers: dict[str, str] | None = None,
            fallback_implementation_provider: str = "openai",
            fallback_implementation_tiers: dict[str, str] | None = None,
            fallback_implementation_reasoning_tiers: dict[str, str] | None = None,
        ) -> None:
            """Initialize the Changed message.

            Args:
                orchestrator_provider: Orchestrator provider ID
                orchestrator_tiers: Dict of tier->model for orchestrator
                orchestrator_reasoning_tiers: Dict of tier->reasoning for orchestrator
                implementation_provider: Implementation provider ID
                implementation_tiers: Dict of tier->model for implementation
                implementation_reasoning_tiers: Dict of tier->reasoning for implementation
            """
            super().__init__()
            self.orchestrator_provider = orchestrator_provider
            self.orchestrator_tiers = orchestrator_tiers
            self.orchestrator_reasoning_tiers = orchestrator_reasoning_tiers
            self.implementation_provider = implementation_provider
            self.implementation_tiers = implementation_tiers
            self.implementation_reasoning_tiers = implementation_reasoning_tiers
            self.fallback_enabled = fallback_enabled
            self.fallback_cooldown_s = fallback_cooldown_s
            self.fallback_transient_error_classes = list(
                fallback_transient_error_classes or ["rate_limit", "transient"]
            )
            self.fallback_startup_failover_enabled = fallback_startup_failover_enabled
            self.fallback_recovery_enabled = fallback_recovery_enabled
            self.fallback_recovery_cooldown_s = fallback_recovery_cooldown_s
            self.fallback_recovery_max_canary_attempts_per_session = (
                fallback_recovery_max_canary_attempts_per_session
            )
            self.fallback_recovery_require_natural_boundary = (
                fallback_recovery_require_natural_boundary
            )
            self.fallback_orchestrator_provider = fallback_orchestrator_provider
            self.fallback_orchestrator_tiers = fallback_orchestrator_tiers or {
                "fast": "default",
                "medium": "default",
                "high": "default",
            }
            self.fallback_orchestrator_reasoning_tiers = (
                fallback_orchestrator_reasoning_tiers
                or {"fast": "default", "medium": "default", "high": "default"}
            )
            self.fallback_implementation_provider = fallback_implementation_provider
            self.fallback_implementation_tiers = fallback_implementation_tiers or {
                "fast": "default",
                "medium": "default",
                "high": "default",
            }
            self.fallback_implementation_reasoning_tiers = (
                fallback_implementation_reasoning_tiers
                or {"fast": "default", "medium": "default", "high": "default"}
            )

    def __init__(
        self,
        current_provider: str = "anthropic",
        current_reasoning: str = DEFAULT_REASONING_VALUE,
        orchestrator_provider: str | None = None,
        orchestrator_tiers: dict[str, str] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_tiers: dict[str, str] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
        role_configs: dict[str, dict[str, Any]] | None = None,
        fallback_enabled: bool = False,
        fallback_cooldown_s: int = 300,
        fallback_transient_error_classes: list[str] | None = None,
        fallback_startup_failover_enabled: bool = True,
        fallback_recovery_enabled: bool = True,
        fallback_recovery_cooldown_s: int = 900,
        fallback_recovery_max_canary_attempts_per_session: int = 1,
        fallback_recovery_require_natural_boundary: bool = True,
        fallback_orchestrator_provider: str = "anthropic",
        fallback_orchestrator_tiers: dict[str, str] | None = None,
        fallback_orchestrator_reasoning_tiers: dict[str, str] | None = None,
        fallback_implementation_provider: str = "openai",
        fallback_implementation_tiers: dict[str, str] | None = None,
        fallback_implementation_reasoning_tiers: dict[str, str] | None = None,
        **kwargs,
    ) -> None:
        """Initialize the ModerateLLMView.

        Args:
            current_provider: Default provider (backward compat)
            current_reasoning: Default reasoning level (backward compat)
            orchestrator_provider: Orchestrator provider
            orchestrator_tiers: Orchestrator tier models {fast, medium, high}
            orchestrator_reasoning_tiers: Orchestrator tier reasoning {fast, medium, high}
            implementation_provider: Implementation provider
            implementation_tiers: Implementation tier models {fast, medium, high}
            implementation_reasoning_tiers: Implementation tier reasoning {fast, medium, high}
            role_configs: Optional explicit llm.roles.* overrides from Menu 3
        """
        super().__init__(**kwargs)

        # Initialize providers
        self._orch_provider = orchestrator_provider or current_provider
        self._impl_provider = implementation_provider or current_provider

        self._init_primary_tiers(
            orchestrator_tiers,
            implementation_tiers,
            orchestrator_reasoning_tiers,
            implementation_reasoning_tiers,
            current_reasoning,
        )
        self._init_fallback_scalars(
            fallback_enabled=fallback_enabled,
            fallback_cooldown_s=fallback_cooldown_s,
            fallback_transient_error_classes=fallback_transient_error_classes,
            fallback_startup_failover_enabled=fallback_startup_failover_enabled,
            fallback_recovery_enabled=fallback_recovery_enabled,
            fallback_recovery_cooldown_s=fallback_recovery_cooldown_s,
            fallback_recovery_max_canary_attempts_per_session=fallback_recovery_max_canary_attempts_per_session,
            fallback_recovery_require_natural_boundary=fallback_recovery_require_natural_boundary,
        )
        self._init_fallback_tier_state(
            fallback_orchestrator_provider=fallback_orchestrator_provider,
            fallback_orchestrator_tiers=fallback_orchestrator_tiers,
            fallback_orchestrator_reasoning_tiers=fallback_orchestrator_reasoning_tiers,
            fallback_implementation_provider=fallback_implementation_provider,
            fallback_implementation_tiers=fallback_implementation_tiers,
            fallback_implementation_reasoning_tiers=fallback_implementation_reasoning_tiers,
        )
        self._role_configs = role_configs or {}

        # Suppress change emissions during initial mount
        self._initializing = True
        # Take snapshot for dirty tracking
        self._snapshot_state()

    def _init_primary_tiers(
        self,
        orchestrator_tiers: dict[str, str] | None,
        implementation_tiers: dict[str, str] | None,
        orchestrator_reasoning_tiers: dict[str, str] | None,
        implementation_reasoning_tiers: dict[str, str] | None,
        current_reasoning: str,
    ) -> None:
        """Populate primary-role tier/reasoning state (orchestrator + implementation)."""
        # Initialize tier models - default to "default" (Let Obra choose)
        # The preview will resolve "default" to actual models via ROLE_TIER_DEFAULTS
        self._orch_tiers = {
            "fast": (orchestrator_tiers or {}).get("fast", "default"),
            "medium": (orchestrator_tiers or {}).get("medium", "default"),
            "high": (orchestrator_tiers or {}).get("high", "default"),
        }

        self._impl_tiers = {
            "fast": (implementation_tiers or {}).get("fast", "default"),
            "medium": (implementation_tiers or {}).get("medium", "default"),
            "high": (implementation_tiers or {}).get("high", "default"),
        }

        # Tier reasoning (Menu 2 specific)
        self._orch_reasoning_tiers = {
            "fast": (orchestrator_reasoning_tiers or {}).get("fast", current_reasoning),
            "medium": (orchestrator_reasoning_tiers or {}).get("medium", current_reasoning),
            "high": (orchestrator_reasoning_tiers or {}).get("high", current_reasoning),
        }
        self._impl_reasoning_tiers = {
            "fast": (implementation_reasoning_tiers or {}).get("fast", current_reasoning),
            "medium": (implementation_reasoning_tiers or {}).get("medium", current_reasoning),
            "high": (implementation_reasoning_tiers or {}).get("high", current_reasoning),
        }

    def _init_fallback_scalars(
        self,
        *,
        fallback_enabled: bool,
        fallback_cooldown_s: int,
        fallback_transient_error_classes: list[str] | None,
        fallback_startup_failover_enabled: bool,
        fallback_recovery_enabled: bool,
        fallback_recovery_cooldown_s: int,
        fallback_recovery_max_canary_attempts_per_session: int,
        fallback_recovery_require_natural_boundary: bool,
    ) -> None:
        """Populate scalar fallback toggles + recovery-knob state."""
        self._fallback_enabled = "true" if fallback_enabled else "false"
        self._fallback_cooldown_s = int(fallback_cooldown_s)
        self._fallback_transient_error_classes = list(
            fallback_transient_error_classes or ["rate_limit", "transient"]
        )
        self._fallback_startup_failover_enabled = (
            "true" if fallback_startup_failover_enabled else "false"
        )
        self._fallback_recovery_enabled = "true" if fallback_recovery_enabled else "false"
        self._fallback_recovery_cooldown_s = str(fallback_recovery_cooldown_s)
        self._fallback_recovery_max_canary_attempts = str(
            fallback_recovery_max_canary_attempts_per_session
        )
        self._fallback_recovery_require_natural_boundary = (
            "true" if fallback_recovery_require_natural_boundary else "false"
        )

    def _init_fallback_tier_state(
        self,
        *,
        fallback_orchestrator_provider: str,
        fallback_orchestrator_tiers: dict[str, str] | None,
        fallback_orchestrator_reasoning_tiers: dict[str, str] | None,
        fallback_implementation_provider: str,
        fallback_implementation_tiers: dict[str, str] | None,
        fallback_implementation_reasoning_tiers: dict[str, str] | None,
    ) -> None:
        """Populate fallback-role tier state (orchestrator + implementation)."""
        self._fb_orch_provider = fallback_orchestrator_provider
        self._fb_orch_tiers = {
            "fast": (fallback_orchestrator_tiers or {}).get("fast", "default"),
            "medium": (fallback_orchestrator_tiers or {}).get("medium", "default"),
            "high": (fallback_orchestrator_tiers or {}).get("high", "default"),
        }
        self._fb_orch_reasoning_tiers = {
            "fast": (fallback_orchestrator_reasoning_tiers or {}).get("fast", "default"),
            "medium": (fallback_orchestrator_reasoning_tiers or {}).get("medium", "default"),
            "high": (fallback_orchestrator_reasoning_tiers or {}).get("high", "default"),
        }
        self._fb_impl_provider = fallback_implementation_provider
        self._fb_impl_tiers = {
            "fast": (fallback_implementation_tiers or {}).get("fast", "default"),
            "medium": (fallback_implementation_tiers or {}).get("medium", "default"),
            "high": (fallback_implementation_tiers or {}).get("high", "default"),
        }
        self._fb_impl_reasoning_tiers = {
            "fast": (fallback_implementation_reasoning_tiers or {}).get("fast", "default"),
            "medium": (fallback_implementation_reasoning_tiers or {}).get("medium", "default"),
            "high": (fallback_implementation_reasoning_tiers or {}).get("high", "default"),
        }

    def compose(self) -> ComposeResult:
        """Create the view content."""
        menu_info = get_menu_info("moderate_llm")
        yield Static(menu_info["label"], classes="header")
        yield Static(menu_info["subtitle"], classes="description")

        with ScrollableContainer(id="content-scroll"):
            # Orchestrator section
            with Vertical(classes="role-section"):
                yield Static("Orchestrator (Planning)", classes="role-header")

                # Provider
                with Horizontal(classes="config-row"):
                    yield Label("Provider", classes="config-label")
                    yield Select(
                        self._build_provider_options(),
                        id="orch-provider-select",
                        value=self._orch_provider,
                        allow_blank=False,
                        classes="config-select",
                    )

                # Fast tier
                with Horizontal(classes="config-row"):
                    yield Label("Fast Tier", classes="tier-label")
                    yield Select(
                        self._build_model_options(self._orch_provider),
                        id="orch-fast-select",
                        value=self._orch_tiers["fast"],
                        allow_blank=False,
                        classes="config-select",
                    )
                yield Static("", id="orch-fast-hint", classes="tier-hint")

                # Medium tier
                with Horizontal(classes="config-row"):
                    yield Label("Medium Tier", classes="tier-label")
                    yield Select(
                        self._build_model_options(self._orch_provider),
                        id="orch-medium-select",
                        value=self._orch_tiers["medium"],
                        allow_blank=False,
                        classes="config-select",
                    )
                yield Static("", id="orch-medium-hint", classes="tier-hint")

                # High tier
                with Horizontal(classes="config-row"):
                    yield Label("High Tier", classes="tier-label")
                    yield Select(
                        self._build_model_options(self._orch_provider),
                        id="orch-high-select",
                        value=self._orch_tiers["high"],
                        allow_blank=False,
                        classes="config-select",
                    )
                yield Static("", id="orch-high-hint", classes="tier-hint")

                # Fast reasoning
                with Horizontal(classes="config-row"):
                    yield Label("Fast Reasoning", classes="tier-label")
                    yield Select(
                        self._build_reasoning_options(),
                        id="orch-fast-reasoning-select",
                        value=self._orch_reasoning_tiers["fast"],
                        allow_blank=False,
                        classes="config-select",
                    )

                # Medium reasoning
                with Horizontal(classes="config-row"):
                    yield Label("Medium Reasoning", classes="tier-label")
                    yield Select(
                        self._build_reasoning_options(),
                        id="orch-medium-reasoning-select",
                        value=self._orch_reasoning_tiers["medium"],
                        allow_blank=False,
                        classes="config-select",
                    )

                # High reasoning
                with Horizontal(classes="config-row"):
                    yield Label("High Reasoning", classes="tier-label")
                    yield Select(
                        self._build_reasoning_options(),
                        id="orch-high-reasoning-select",
                        value=self._orch_reasoning_tiers["high"],
                        allow_blank=False,
                        classes="config-select",
                    )

            yield Rule()

            # Implementation section
            with Vertical(classes="role-section"):
                yield Static("Implementation (Execution)", classes="role-header")

                # Provider
                with Horizontal(classes="config-row"):
                    yield Label("Provider", classes="config-label")
                    yield Select(
                        self._build_provider_options(),
                        id="impl-provider-select",
                        value=self._impl_provider,
                        allow_blank=False,
                        classes="config-select",
                    )

                # Fast tier
                with Horizontal(classes="config-row"):
                    yield Label("Fast Tier", classes="tier-label")
                    yield Select(
                        self._build_model_options(self._impl_provider),
                        id="impl-fast-select",
                        value=self._impl_tiers["fast"],
                        allow_blank=False,
                        classes="config-select",
                    )
                yield Static("", id="impl-fast-hint", classes="tier-hint")

                # Medium tier
                with Horizontal(classes="config-row"):
                    yield Label("Medium Tier", classes="tier-label")
                    yield Select(
                        self._build_model_options(self._impl_provider),
                        id="impl-medium-select",
                        value=self._impl_tiers["medium"],
                        allow_blank=False,
                        classes="config-select",
                    )
                yield Static("", id="impl-medium-hint", classes="tier-hint")

                # High tier
                with Horizontal(classes="config-row"):
                    yield Label("High Tier", classes="tier-label")
                    yield Select(
                        self._build_model_options(self._impl_provider),
                        id="impl-high-select",
                        value=self._impl_tiers["high"],
                        allow_blank=False,
                        classes="config-select",
                    )
                yield Static("", id="impl-high-hint", classes="tier-hint")

                # Fast reasoning
                with Horizontal(classes="config-row"):
                    yield Label("Fast Reasoning", classes="tier-label")
                    yield Select(
                        self._build_reasoning_options(),
                        id="impl-fast-reasoning-select",
                        value=self._impl_reasoning_tiers["fast"],
                        allow_blank=False,
                        classes="config-select",
                    )

                # Medium reasoning
                with Horizontal(classes="config-row"):
                    yield Label("Medium Reasoning", classes="tier-label")
                    yield Select(
                        self._build_reasoning_options(),
                        id="impl-medium-reasoning-select",
                        value=self._impl_reasoning_tiers["medium"],
                        allow_blank=False,
                        classes="config-select",
                    )

                # High reasoning
                with Horizontal(classes="config-row"):
                    yield Label("High Reasoning", classes="tier-label")
                    yield Select(
                        self._build_reasoning_options(),
                        id="impl-high-reasoning-select",
                        value=self._impl_reasoning_tiers["high"],
                        allow_blank=False,
                        classes="config-select",
                    )

            yield Rule()

            with Vertical(classes="fallback-section"):
                yield Static("Fallback Configuration", classes="role-header")
                with Horizontal(classes="config-row"):
                    yield Label("Enable Fallback", classes="config-label")
                    yield Select(
                        [("Off", "false"), ("On", "true")],
                        id="fallback-enabled-select",
                        value=self._fallback_enabled,
                        allow_blank=False,
                        classes="config-select",
                    )
                with Vertical(id="fallback-controls"):
                    with Horizontal(classes="config-row"):
                        yield Label("Startup Failover", classes="config-label")
                        yield Select(
                            [("On", "true"), ("Off", "false")],
                            id="fallback-startup-select",
                            value=self._fallback_startup_failover_enabled,
                            allow_blank=False,
                            classes="config-select",
                        )
                    with Horizontal(classes="config-row"):
                        yield Label("Recovery", classes="config-label")
                        yield Select(
                            [("On", "true"), ("Off", "false")],
                            id="fallback-recovery-enabled-select",
                            value=self._fallback_recovery_enabled,
                            allow_blank=False,
                            classes="config-select",
                        )
                    with Horizontal(classes="config-row"):
                        yield Label("Recovery Wait", classes="config-label")
                        yield Select(
                            [
                                ("300s", "300"),
                                ("900s", "900"),
                                ("1800s", "1800"),
                                ("3600s", "3600"),
                            ],
                            id="fallback-recovery-cooldown-select",
                            value=self._fallback_recovery_cooldown_s,
                            allow_blank=False,
                            classes="config-select",
                        )
                    with Horizontal(classes="config-row"):
                        yield Label("Recovery Attempts", classes="config-label")
                        yield Select(
                            [("0", "0"), ("1", "1"), ("2", "2")],
                            id="fallback-recovery-attempts-select",
                            value=self._fallback_recovery_max_canary_attempts,
                            allow_blank=False,
                            classes="config-select",
                        )
                    with Horizontal(classes="config-row"):
                        yield Label("Real Requests Only", classes="config-label")
                        yield Select(
                            [("Required", "true"), ("Allow direct retry", "false")],
                            id="fallback-recovery-natural-boundary-select",
                            value=self._fallback_recovery_require_natural_boundary,
                            allow_blank=False,
                            classes="config-select",
                        )
                    with Vertical(classes="role-section"):
                        yield Static("Fallback Orchestrator", classes="role-header")
                        with Horizontal(classes="config-row"):
                            yield Label("Provider", classes="config-label")
                            yield Select(
                                self._build_provider_options(),
                                id="fb-orch-provider-select",
                                value=self._fb_orch_provider,
                                allow_blank=False,
                                classes="config-select",
                            )
                        for tier in ("fast", "medium", "high"):
                            with Horizontal(classes="config-row"):
                                yield Label(f"{tier.capitalize()} Tier", classes="tier-label")
                                yield Select(
                                    self._build_model_options(self._fb_orch_provider),
                                    id=f"fb-orch-{tier}-select",
                                    value=self._fb_orch_tiers[tier],
                                    allow_blank=False,
                                    classes="config-select",
                                )
                            with Horizontal(classes="config-row"):
                                yield Label(
                                    f"{tier.capitalize()} Reasoning", classes="tier-label"
                                )
                                yield Select(
                                    self._build_reasoning_options(),
                                    id=f"fb-orch-{tier}-reasoning-select",
                                    value=self._fb_orch_reasoning_tiers[tier],
                                    allow_blank=False,
                                    classes="config-select",
                                )
                    with Vertical(classes="role-section"):
                        yield Static("Fallback Implementation", classes="role-header")
                        with Horizontal(classes="config-row"):
                            yield Label("Provider", classes="config-label")
                            yield Select(
                                self._build_provider_options(),
                                id="fb-impl-provider-select",
                                value=self._fb_impl_provider,
                                allow_blank=False,
                                classes="config-select",
                            )
                        for tier in ("fast", "medium", "high"):
                            with Horizontal(classes="config-row"):
                                yield Label(f"{tier.capitalize()} Tier", classes="tier-label")
                                yield Select(
                                    self._build_model_options(self._fb_impl_provider),
                                    id=f"fb-impl-{tier}-select",
                                    value=self._fb_impl_tiers[tier],
                                    allow_blank=False,
                                    classes="config-select",
                                )
                            with Horizontal(classes="config-row"):
                                yield Label(
                                    f"{tier.capitalize()} Reasoning", classes="tier-label"
                                )
                                yield Select(
                                    self._build_reasoning_options(),
                                    id=f"fb-impl-{tier}-reasoning-select",
                                    value=self._fb_impl_reasoning_tiers[tier],
                                    allow_blank=False,
                                    classes="config-select",
                                )

            # Preview box - single Static with full content
            yield Static(
                self._build_preview_with_title(),
                id="preview-content",
                classes="preview-box",
            )

        yield Static(
            "★ Let Obra choose = Obra picks model + reasoning defaults for each tier",
            classes="help-text",
        )

    def on_mount(self) -> None:
        """Initialize preview and hints after widget is mounted."""
        from obra.config.explorer.debug import is_debug_enabled, log_action

        # Ensure preview is populated with current values
        preview_text = self._build_preview_with_title()
        if is_debug_enabled():
            log_action("on_mount_preview", f"text_length={len(preview_text)}")

        try:
            preview = self.query_one("#preview-content", Static)
            preview.update(preview_text)
            if is_debug_enabled():
                log_action("on_mount_preview", "update successful")
        except Exception as e:
            if is_debug_enabled():
                log_action("on_mount_preview", f"ERROR: {e}")

        # Initialize tier hints
        self._update_tier_hints()
        self._update_fallback_controls()

        # CRITICAL: Use call_after_refresh to delay setting _initializing = False
        # until AFTER all queued Select.Changed events from initial value setting
        # have been processed. This prevents phantom changes from mount events.
        def finish_initialization() -> None:
            self._initializing = False
            # Re-snapshot state AFTER all mount events are processed
            self._snapshot_state()
            if is_debug_enabled():
                log_action(
                    "ModerateLLMView.on_mount.finish_init",
                    f"_initializing={self._initializing}, snapshot taken",
                )

        self.call_after_refresh(finish_initialization)

    def _build_provider_options(self) -> list[tuple[str, str]]:
        """Build provider options for Select widget."""
        providers = get_providers()
        options = []
        for provider_id, display_name, _description in providers:
            options.append((display_name, provider_id))
        return options

    def _build_model_options(self, provider: str) -> list[tuple[str, str]]:
        """Build model options for a specific provider.

        Options are sorted by tier: Recommended → High → Medium → Fast.
        Each option shows a cost indicator ($, $$, $$$).
        """
        all_models = get_models()
        models = all_models.get(provider, all_models.get("anthropic", []))

        options = []
        for model_id, display, _tier in models:
            cost = get_model_cost(provider, model_id)
            # Recommended gets a star, others get cost indicator
            label = f"★  {display}" if model_id == "default" else f"{cost} {display}"
            options.append((label, model_id))
        return options

    def _build_reasoning_options(self) -> list[tuple[str, str]]:
        """Build reasoning level options for Select widget."""
        return [("★  Let Obra choose", DEFAULT_REASONING_VALUE)] + [
            (level.capitalize(), level) for level in REASONING_LEVELS
        ]

    def _build_preview_text(self) -> str:
        """Build preview text from authoritative effective config."""
        return build_authoritative_llm_preview(
            orch_provider=self._orch_provider,
            impl_provider=self._impl_provider,
            orch_tiers=self._orch_tiers,
            impl_tiers=self._impl_tiers,
            orch_reasoning_tiers=self._orch_reasoning_tiers,
            impl_reasoning_tiers=self._impl_reasoning_tiers,
            orch_fallback_reasoning=self._orch_reasoning_tiers["medium"],
            impl_fallback_reasoning=self._impl_reasoning_tiers["medium"],
            role_configs=self._role_configs,
            fallback_enabled=self._fallback_enabled == "true",
            fallback_orch_provider=self._fb_orch_provider,
            fallback_impl_provider=self._fb_impl_provider,
            fallback_orch_model="default",
            fallback_impl_model="default",
            fallback_orch_tiers=self._fb_orch_tiers,
            fallback_impl_tiers=self._fb_impl_tiers,
            fallback_orch_reasoning_tiers=self._fb_orch_reasoning_tiers,
            fallback_impl_reasoning_tiers=self._fb_impl_reasoning_tiers,
            fallback_orch_fallback_reasoning=self._fb_orch_reasoning_tiers["medium"],
            fallback_impl_fallback_reasoning=self._fb_impl_reasoning_tiers["medium"],
        )

    def _build_preview_with_title(self) -> str:
        """Build preview text with title header."""
        return f"[bold]What Obra will use:[/bold]\n\n{self._build_preview_text()}"

    def _update_preview(self) -> None:
        """Update the preview box."""
        try:
            preview = self.query_one("#preview-content", Static)
            preview.update(self._build_preview_with_title())
        except Exception:
            pass

    def _get_tier_hint(self, role: str, tier: str, model_id: str) -> str:
        """Get the hint text for a tier dropdown.

        Shows what model will be used when "Let Obra choose" is selected,
        or hides the hint if a specific model is chosen.

        Args:
            role: Role name (orchestrator, implementation)
            tier: Tier name (fast, medium, high)
            model_id: Current model selection (may be 'default')

        Returns:
            Hint text to display, or empty string if no hint needed.
        """
        if model_id != "default":
            # User chose a specific model, no hint needed
            return ""

        # Resolve what "Let Obra choose" means for this tier
        provider = self._orch_provider if role == "orchestrator" else self._impl_provider
        resolved = resolve_tier_model_display(provider, role, tier, "default")
        return f"→ {resolved}"

    def _update_tier_hints(self) -> None:
        """Update all tier hint labels to show resolved models."""
        # Orchestrator hints
        for tier in ("fast", "medium", "high"):
            try:
                hint = self.query_one(f"#orch-{tier}-hint", Static)
                hint_text = self._get_tier_hint("orchestrator", tier, self._orch_tiers[tier])
                hint.update(hint_text)
                # Add/remove resolved class for styling
                hint.set_class(bool(hint_text), "tier-hint-resolved")
            except Exception:
                pass

        # Implementation hints
        for tier in ("fast", "medium", "high"):
            try:
                hint = self.query_one(f"#impl-{tier}-hint", Static)
                hint_text = self._get_tier_hint("implementation", tier, self._impl_tiers[tier])
                hint.update(hint_text)
                hint.set_class(bool(hint_text), "tier-hint-resolved")
            except Exception:
                pass

    def on_select_changed(self, event: Select.Changed) -> None:
        """Handle select widget changes."""
        # Skip processing during initial mount to prevent spurious state changes
        if self._initializing:
            return

        from obra.config.explorer.debug import is_debug_enabled, log_action

        select_id = event.select.id
        if not select_id:
            return

        # Handle Select.BLANK sentinel with field-appropriate fallback
        if event.value is Select.BLANK:
            value = (
                DEFAULT_REASONING_VALUE
                if (select_id or "").endswith("reasoning-select")
                else "default"
            )
        else:
            value = str(event.value)

        if is_debug_enabled():
            log_action("select_changed", f"id={select_id}, value={value}")

        handler = _SELECT_DISPATCH.get(select_id)
        if handler is not None:
            handler(self, value)
            return

        # Prefix fall-through for dynamic fb-orch-<tier>-{reasoning-,}select ids.
        if select_id.startswith("fb-orch-") and select_id.endswith("-select"):
            self._apply_fb_tier_select(self._fb_orch_tiers, self._fb_orch_reasoning_tiers,
                                       "fb-orch-", select_id, value)
            return
        if select_id.startswith("fb-impl-") and select_id.endswith("-select"):
            self._apply_fb_tier_select(self._fb_impl_tiers, self._fb_impl_reasoning_tiers,
                                       "fb-impl-", select_id, value)
            return

    # --- dispatch handlers (match on fixed select-id) ---

    def _handle_orch_fast_select(self, value: str) -> None:
        self._orch_tiers["fast"] = value
        self._apply_tier_model_default_reasoning("orchestrator", "fast")
        self._update_and_emit()

    def _handle_orch_medium_select(self, value: str) -> None:
        self._orch_tiers["medium"] = value
        self._apply_tier_model_default_reasoning("orchestrator", "medium")
        self._update_and_emit()

    def _handle_orch_high_select(self, value: str) -> None:
        self._orch_tiers["high"] = value
        self._apply_tier_model_default_reasoning("orchestrator", "high")
        self._update_and_emit()

    def _handle_orch_fast_reasoning(self, value: str) -> None:
        self._orch_reasoning_tiers["fast"] = value
        self._update_and_emit()

    def _handle_orch_medium_reasoning(self, value: str) -> None:
        self._orch_reasoning_tiers["medium"] = value
        self._update_and_emit()

    def _handle_orch_high_reasoning(self, value: str) -> None:
        self._orch_reasoning_tiers["high"] = value
        self._update_and_emit()

    def _handle_impl_fast_select(self, value: str) -> None:
        self._impl_tiers["fast"] = value
        self._apply_tier_model_default_reasoning("implementation", "fast")
        self._update_and_emit()

    def _handle_impl_medium_select(self, value: str) -> None:
        self._impl_tiers["medium"] = value
        self._apply_tier_model_default_reasoning("implementation", "medium")
        self._update_and_emit()

    def _handle_impl_high_select(self, value: str) -> None:
        self._impl_tiers["high"] = value
        self._apply_tier_model_default_reasoning("implementation", "high")
        self._update_and_emit()

    def _handle_impl_fast_reasoning(self, value: str) -> None:
        self._impl_reasoning_tiers["fast"] = value
        self._update_and_emit()

    def _handle_impl_medium_reasoning(self, value: str) -> None:
        self._impl_reasoning_tiers["medium"] = value
        self._update_and_emit()

    def _handle_impl_high_reasoning(self, value: str) -> None:
        self._impl_reasoning_tiers["high"] = value
        self._update_and_emit()

    def _handle_fallback_enabled(self, value: str) -> None:
        self._fallback_enabled = value
        self._update_fallback_controls()
        self._update_and_emit()

    def _handle_fallback_startup(self, value: str) -> None:
        self._fallback_startup_failover_enabled = value
        self._update_and_emit()

    def _handle_fallback_recovery_enabled(self, value: str) -> None:
        self._fallback_recovery_enabled = value
        self._update_and_emit()

    def _handle_fallback_recovery_cooldown(self, value: str) -> None:
        self._fallback_recovery_cooldown_s = value
        self._update_and_emit()

    def _handle_fallback_recovery_attempts(self, value: str) -> None:
        self._fallback_recovery_max_canary_attempts = value
        self._update_and_emit()

    def _handle_fallback_recovery_natural_boundary(self, value: str) -> None:
        self._fallback_recovery_require_natural_boundary = value
        self._update_and_emit()

    def _handle_fb_orch_provider(self, value: str) -> None:
        self._handle_fallback_provider_change("orchestrator", value)

    def _handle_fb_impl_provider(self, value: str) -> None:
        self._handle_fallback_provider_change("implementation", value)

    def _apply_fb_tier_select(
        self,
        tiers: dict[str, str],
        reasoning_tiers: dict[str, str],
        prefix: str,
        select_id: str,
        value: str,
    ) -> None:
        """Shared prefix-fallback handler for fb-{orch,impl}-<tier>[-reasoning]-select."""
        tier = select_id.removeprefix(prefix).removesuffix("-select")
        if tier.endswith("-reasoning"):
            reasoning_tier = tier.removesuffix("-reasoning")
            reasoning_tiers[reasoning_tier] = value
        else:
            tiers[tier] = value
        self._update_and_emit()

    def _handle_orch_provider_change(self, new_provider: str) -> None:
        """Handle orchestrator provider change."""
        self._orch_provider = new_provider
        new_options = self._build_model_options(new_provider)
        valid_ids = [opt[1] for opt in new_options]

        # Get new role-specific defaults
        defaults = get_role_tier_defaults(new_provider, "orchestrator")

        # Update each tier dropdown
        for tier in ("fast", "medium", "high"):
            try:
                select = self.query_one(f"#orch-{tier}-select", Select)
                select.set_options(new_options)

                # Reset to provider default if current not valid
                if self._orch_tiers[tier] not in valid_ids:
                    self._orch_tiers[tier] = defaults.get(
                        tier, valid_ids[0] if valid_ids else "default"
                    )
                    self._apply_tier_model_default_reasoning("orchestrator", tier)
                select.value = self._orch_tiers[tier]
            except Exception:
                pass

        self._update_and_emit()

    def _handle_impl_provider_change(self, new_provider: str) -> None:
        """Handle implementation provider change."""
        self._impl_provider = new_provider
        new_options = self._build_model_options(new_provider)
        valid_ids = [opt[1] for opt in new_options]

        # Get new role-specific defaults
        defaults = get_role_tier_defaults(new_provider, "implementation")

        # Update each tier dropdown
        for tier in ("fast", "medium", "high"):
            try:
                select = self.query_one(f"#impl-{tier}-select", Select)
                select.set_options(new_options)

                # Reset to provider default if current not valid
                if self._impl_tiers[tier] not in valid_ids:
                    self._impl_tiers[tier] = defaults.get(
                        tier, valid_ids[0] if valid_ids else "default"
                    )
                    self._apply_tier_model_default_reasoning("implementation", tier)
                select.value = self._impl_tiers[tier]
            except Exception:
                pass

        self._update_and_emit()

    def _update_and_emit(self) -> None:
        """Update preview, hints, and emit change.

        Skips emission during initial mount to prevent spurious changes.
        """
        self._update_preview()
        self._update_tier_hints()

        # Don't emit during initial mount - only after user interaction
        if self._initializing:
            return

        from obra.config.explorer.debug import is_debug_enabled, log_action

        if is_debug_enabled():
            log_action(
                "emit_changed",
                f"orch={self._orch_provider}/{self._orch_tiers}, impl={self._impl_provider}/{self._impl_tiers}",
            )

        self.post_message(
            self.Changed(
                self._orch_provider,
                self._orch_tiers.copy(),
                self._orch_reasoning_tiers.copy(),
                self._impl_provider,
                self._impl_tiers.copy(),
                self._impl_reasoning_tiers.copy(),
                fallback_enabled=self._fallback_enabled == "true",
                fallback_cooldown_s=self._fallback_cooldown_s,
                fallback_transient_error_classes=self._fallback_transient_error_classes.copy(),
                fallback_startup_failover_enabled=(
                    self._fallback_startup_failover_enabled == "true"
                ),
                fallback_recovery_enabled=self._fallback_recovery_enabled == "true",
                fallback_recovery_cooldown_s=int(self._fallback_recovery_cooldown_s),
                fallback_recovery_max_canary_attempts_per_session=int(
                    self._fallback_recovery_max_canary_attempts
                ),
                fallback_recovery_require_natural_boundary=(
                    self._fallback_recovery_require_natural_boundary == "true"
                ),
                fallback_orchestrator_provider=self._fb_orch_provider,
                fallback_orchestrator_tiers=self._fb_orch_tiers.copy(),
                fallback_orchestrator_reasoning_tiers=self._fb_orch_reasoning_tiers.copy(),
                fallback_implementation_provider=self._fb_impl_provider,
                fallback_implementation_tiers=self._fb_impl_tiers.copy(),
                fallback_implementation_reasoning_tiers=self._fb_impl_reasoning_tiers.copy(),
            )
        )

    def _apply_tier_model_default_reasoning(self, role: str, tier: str) -> None:
        """Apply model-specific reasoning defaults for a role tier."""
        _ = role, tier

    def set_values(
        self,
        provider: str | None = None,
        orchestrator_model: str | None = None,
        implementation_model: str | None = None,
        reasoning: str | None = None,
        orchestrator_provider: str | None = None,
        orchestrator_tiers: dict[str, str] | None = None,
        orchestrator_reasoning_tiers: dict[str, str] | None = None,
        implementation_provider: str | None = None,
        implementation_tiers: dict[str, str] | None = None,
        implementation_reasoning_tiers: dict[str, str] | None = None,
        role_configs: dict[str, dict[str, Any]] | None = None,
    ) -> None:
        """Set the current values.

        Supports both legacy (single model per role) and new (tier-based) signatures.

        Args:
            provider: Legacy shared provider
            orchestrator_model: Legacy orchestrator model (maps to medium tier)
            implementation_model: Legacy implementation model (maps to medium tier)
            reasoning: Legacy single reasoning level
            orchestrator_provider: Orchestrator provider
            orchestrator_tiers: Orchestrator tier models
            orchestrator_reasoning_tiers: Orchestrator tier reasoning
            implementation_provider: Implementation provider
            implementation_tiers: Implementation tier models
            implementation_reasoning_tiers: Implementation tier reasoning
            role_configs: Optional explicit llm.roles.* overrides from Menu 3
        """
        # Set providers
        self._orch_provider = orchestrator_provider or provider or "anthropic"
        self._impl_provider = implementation_provider or provider or "anthropic"

        # Set orchestrator tiers - use "default" (Let Obra choose) as fallback
        # Preview will resolve "default" to actual model names via ROLE_TIER_DEFAULTS
        if orchestrator_tiers:
            self._orch_tiers = {
                "fast": orchestrator_tiers.get("fast", "default"),
                "medium": orchestrator_tiers.get("medium", "default"),
                "high": orchestrator_tiers.get("high", "default"),
            }
        elif orchestrator_model:
            # Legacy: use single model for all tiers
            self._orch_tiers = {
                "fast": "default",
                "medium": orchestrator_model,
                "high": "default",
            }
        else:
            self._orch_tiers = {
                "fast": "default",
                "medium": "default",
                "high": "default",
            }

        # Set implementation tiers - use "default" (Let Obra choose) as fallback
        if implementation_tiers:
            self._impl_tiers = {
                "fast": implementation_tiers.get("fast", "default"),
                "medium": implementation_tiers.get("medium", "default"),
                "high": implementation_tiers.get("high", "default"),
            }
        elif implementation_model:
            # Legacy: use single model for all tiers
            self._impl_tiers = {
                "fast": "default",
                "medium": implementation_model,
                "high": "default",
            }
        else:
            self._impl_tiers = {
                "fast": "default",
                "medium": "default",
                "high": "default",
            }

        self._orch_reasoning_tiers = {
            "fast": (orchestrator_reasoning_tiers or {}).get(
                "fast", reasoning or DEFAULT_REASONING_VALUE
            ),
            "medium": (orchestrator_reasoning_tiers or {}).get(
                "medium", reasoning or DEFAULT_REASONING_VALUE
            ),
            "high": (orchestrator_reasoning_tiers or {}).get(
                "high", reasoning or DEFAULT_REASONING_VALUE
            ),
        }
        self._impl_reasoning_tiers = {
            "fast": (implementation_reasoning_tiers or {}).get(
                "fast", reasoning or DEFAULT_REASONING_VALUE
            ),
            "medium": (implementation_reasoning_tiers or {}).get(
                "medium", reasoning or DEFAULT_REASONING_VALUE
            ),
            "high": (implementation_reasoning_tiers or {}).get(
                "high", reasoning or DEFAULT_REASONING_VALUE
            ),
        }
        if role_configs is not None:
            self._role_configs = role_configs

        # Update UI
        self._update_all_dropdowns()
        self._update_preview()

    def _update_all_dropdowns(self) -> None:
        """Update all dropdowns and hints to reflect current state."""
        try:
            # Orchestrator
            orch_prov = self.query_one("#orch-provider-select", Select)
            orch_prov.value = self._orch_provider

            orch_options = self._build_model_options(self._orch_provider)
            for tier in ("fast", "medium", "high"):
                select = self.query_one(f"#orch-{tier}-select", Select)
                select.set_options(orch_options)
                select.value = self._orch_tiers[tier]

            # Implementation
            impl_prov = self.query_one("#impl-provider-select", Select)
            impl_prov.value = self._impl_provider

            impl_options = self._build_model_options(self._impl_provider)
            for tier in ("fast", "medium", "high"):
                select = self.query_one(f"#impl-{tier}-select", Select)
                select.set_options(impl_options)
                select.value = self._impl_tiers[tier]

            # Reasoning selectors
            reasoning_options = self._build_reasoning_options()
            for tier in ("fast", "medium", "high"):
                orch_reasoning = self.query_one(f"#orch-{tier}-reasoning-select", Select)
                orch_reasoning.set_options(reasoning_options)
                orch_reasoning.value = self._orch_reasoning_tiers[tier]

                impl_reasoning = self.query_one(f"#impl-{tier}-reasoning-select", Select)
                impl_reasoning.set_options(reasoning_options)
                impl_reasoning.value = self._impl_reasoning_tiers[tier]

            fb_enabled = self.query_one("#fallback-enabled-select", Select)
            fb_enabled.value = self._fallback_enabled
            self.query_one("#fallback-startup-select", Select).value = (
                self._fallback_startup_failover_enabled
            )
            self.query_one("#fallback-recovery-enabled-select", Select).value = (
                self._fallback_recovery_enabled
            )
            self.query_one("#fallback-recovery-cooldown-select", Select).value = (
                self._fallback_recovery_cooldown_s
            )
            self.query_one("#fallback-recovery-attempts-select", Select).value = (
                self._fallback_recovery_max_canary_attempts
            )
            self.query_one("#fallback-recovery-natural-boundary-select", Select).value = (
                self._fallback_recovery_require_natural_boundary
            )

            fb_orch_provider = self.query_one("#fb-orch-provider-select", Select)
            fb_orch_provider.value = self._fb_orch_provider
            fb_orch_options = self._build_model_options(self._fb_orch_provider)
            for tier in ("fast", "medium", "high"):
                select = self.query_one(f"#fb-orch-{tier}-select", Select)
                select.set_options(fb_orch_options)
                select.value = self._fb_orch_tiers[tier]
                reasoning_select = self.query_one(f"#fb-orch-{tier}-reasoning-select", Select)
                reasoning_select.set_options(reasoning_options)
                reasoning_select.value = self._fb_orch_reasoning_tiers[tier]

            fb_impl_provider = self.query_one("#fb-impl-provider-select", Select)
            fb_impl_provider.value = self._fb_impl_provider
            fb_impl_options = self._build_model_options(self._fb_impl_provider)
            for tier in ("fast", "medium", "high"):
                select = self.query_one(f"#fb-impl-{tier}-select", Select)
                select.set_options(fb_impl_options)
                select.value = self._fb_impl_tiers[tier]
                reasoning_select = self.query_one(f"#fb-impl-{tier}-reasoning-select", Select)
                reasoning_select.set_options(reasoning_options)
                reasoning_select.value = self._fb_impl_reasoning_tiers[tier]

            # Update hints after dropdowns
            self._update_tier_hints()
            self._update_fallback_controls()
        except Exception:
            pass

    def _handle_fallback_provider_change(self, role: str, new_provider: str) -> None:
        """Handle fallback provider changes and refresh matching model options."""
        if role == "orchestrator":
            self._fb_orch_provider = new_provider
            tiers = self._fb_orch_tiers
            prefix = "#fb-orch-"
        else:
            self._fb_impl_provider = new_provider
            tiers = self._fb_impl_tiers
            prefix = "#fb-impl-"

        new_options = self._build_model_options(new_provider)
        valid_ids = [opt[1] for opt in new_options]
        for tier in ("fast", "medium", "high"):
            if tiers[tier] not in valid_ids:
                tiers[tier] = valid_ids[0] if valid_ids else "default"
            try:
                select = self.query_one(f"{prefix}{tier}-select", Select)
                select.set_options(new_options)
                select.value = tiers[tier]
            except Exception:
                pass
        self._update_and_emit()

    def _update_fallback_controls(self) -> None:
        """Apply toggle-gated disabled state to fallback controls."""
        controls_enabled = self._fallback_enabled == "true"
        try:
            controls = self.query_one("#fallback-controls", Vertical)
            controls.set_class(not controls_enabled, "disabled-section")
            for control_id in (
                "#fb-orch-provider-select",
                "#fb-orch-fast-select",
                "#fb-orch-fast-reasoning-select",
                "#fb-orch-medium-select",
                "#fb-orch-medium-reasoning-select",
                "#fb-orch-high-select",
                "#fb-orch-high-reasoning-select",
                "#fb-impl-provider-select",
                "#fb-impl-fast-select",
                "#fb-impl-fast-reasoning-select",
                "#fb-impl-medium-select",
                "#fb-impl-medium-reasoning-select",
                "#fb-impl-high-select",
                "#fb-impl-high-reasoning-select",
            ):
                self.query_one(control_id, Select).disabled = not controls_enabled
        except Exception:
            pass

    # --- SaveableViewMixin implementation ---

    def _get_saveable_state(self) -> dict[str, Any]:
        """Get current state for dirty tracking.

        Returns config paths mapped to current values.
        """
        state: dict[str, Any] = {
            "llm.orchestrator.provider": self._orch_provider,
            "llm.orchestrator.reasoning_level": self._orch_reasoning_tiers["medium"],
            "llm.implementation.provider": self._impl_provider,
            "llm.implementation.reasoning_level": self._impl_reasoning_tiers["medium"],
            "llm.fallback.enabled": self._fallback_enabled == "true",
            "llm.fallback.cooldown_s": self._fallback_cooldown_s,
            "llm.fallback.transient_error_classes": self._fallback_transient_error_classes.copy(),
            "llm.fallback.startup_failover_enabled": (
                self._fallback_startup_failover_enabled == "true"
            ),
            "llm.fallback.recovery.enabled": self._fallback_recovery_enabled == "true",
            "llm.fallback.recovery.cooldown_s": int(self._fallback_recovery_cooldown_s),
            "llm.fallback.recovery.max_canary_attempts_per_session": int(
                self._fallback_recovery_max_canary_attempts
            ),
            "llm.fallback.recovery.require_natural_boundary": (
                self._fallback_recovery_require_natural_boundary == "true"
            ),
            "llm.fallback.orchestrator.provider": self._fb_orch_provider,
            "llm.fallback.implementation.provider": self._fb_impl_provider,
        }
        for tier in ("fast", "medium", "high"):
            state[f"llm.orchestrator.tiers.{tier}"] = {
                "model": self._orch_tiers[tier],
                "reasoning_level": self._orch_reasoning_tiers[tier],
            }
            state[f"llm.implementation.tiers.{tier}"] = {
                "model": self._impl_tiers[tier],
                "reasoning_level": self._impl_reasoning_tiers[tier],
            }
            state[f"llm.fallback.orchestrator.tiers.{tier}"] = {
                "model": self._fb_orch_tiers[tier],
                "reasoning_level": self._fb_orch_reasoning_tiers[tier],
            }
            state[f"llm.fallback.implementation.tiers.{tier}"] = {
                "model": self._fb_impl_tiers[tier],
                "reasoning_level": self._fb_impl_reasoning_tiers[tier],
            }
        return state

    def _restore_state(self, state: dict[str, Any]) -> None:
        """Restore state from snapshot and update UI."""
        self._orch_provider = state.get("llm.orchestrator.provider", self._orch_provider)
        self._impl_provider = state.get("llm.implementation.provider", self._impl_provider)
        self._fallback_enabled = (
            "true" if bool(state.get("llm.fallback.enabled", self._fallback_enabled == "true")) else "false"
        )
        self._fallback_cooldown_s = int(
            state.get("llm.fallback.cooldown_s", self._fallback_cooldown_s)
        )
        transient_error_classes = state.get(
            "llm.fallback.transient_error_classes",
            self._fallback_transient_error_classes,
        )
        if isinstance(transient_error_classes, list):
            self._fallback_transient_error_classes = list(transient_error_classes)
        self._fallback_startup_failover_enabled = (
            "true"
            if bool(
                state.get(
                    "llm.fallback.startup_failover_enabled",
                    self._fallback_startup_failover_enabled == "true",
                )
            )
            else "false"
        )
        self._fallback_recovery_enabled = (
            "true"
            if bool(
                state.get(
                    "llm.fallback.recovery.enabled",
                    self._fallback_recovery_enabled == "true",
                )
            )
            else "false"
        )
        self._fallback_recovery_cooldown_s = str(
            state.get(
                "llm.fallback.recovery.cooldown_s",
                self._fallback_recovery_cooldown_s,
            )
        )
        self._fallback_recovery_max_canary_attempts = str(
            state.get(
                "llm.fallback.recovery.max_canary_attempts_per_session",
                self._fallback_recovery_max_canary_attempts,
            )
        )
        self._fallback_recovery_require_natural_boundary = (
            "true"
            if bool(
                state.get(
                    "llm.fallback.recovery.require_natural_boundary",
                    self._fallback_recovery_require_natural_boundary == "true",
                )
            )
            else "false"
        )
        self._fb_orch_provider = state.get(
            "llm.fallback.orchestrator.provider", self._fb_orch_provider
        )
        self._fb_impl_provider = state.get(
            "llm.fallback.implementation.provider", self._fb_impl_provider
        )
        for tier in ("fast", "medium", "high"):
            orch_value = state.get(f"llm.orchestrator.tiers.{tier}", self._orch_tiers[tier])
            impl_value = state.get(f"llm.implementation.tiers.{tier}", self._impl_tiers[tier])

            if isinstance(orch_value, dict):
                self._orch_tiers[tier] = str(orch_value.get("model", self._orch_tiers[tier]))
                self._orch_reasoning_tiers[tier] = str(
                    orch_value.get("reasoning_level", self._orch_reasoning_tiers[tier])
                )
            else:
                self._orch_tiers[tier] = str(orch_value)

            if isinstance(impl_value, dict):
                self._impl_tiers[tier] = str(impl_value.get("model", self._impl_tiers[tier]))
                self._impl_reasoning_tiers[tier] = str(
                    impl_value.get("reasoning_level", self._impl_reasoning_tiers[tier])
                )
            else:
                self._impl_tiers[tier] = str(impl_value)

            fb_orch_value = state.get(
                f"llm.fallback.orchestrator.tiers.{tier}",
                self._fb_orch_tiers[tier],
            )
            fb_impl_value = state.get(
                f"llm.fallback.implementation.tiers.{tier}",
                self._fb_impl_tiers[tier],
            )
            if isinstance(fb_orch_value, dict):
                self._fb_orch_tiers[tier] = str(
                    fb_orch_value.get("model", self._fb_orch_tiers[tier])
                )
                self._fb_orch_reasoning_tiers[tier] = str(
                    fb_orch_value.get("reasoning_level", self._fb_orch_reasoning_tiers[tier])
                )
            else:
                self._fb_orch_tiers[tier] = str(fb_orch_value)

            if isinstance(fb_impl_value, dict):
                self._fb_impl_tiers[tier] = str(
                    fb_impl_value.get("model", self._fb_impl_tiers[tier])
                )
                self._fb_impl_reasoning_tiers[tier] = str(
                    fb_impl_value.get("reasoning_level", self._fb_impl_reasoning_tiers[tier])
                )
            else:
                self._fb_impl_tiers[tier] = str(fb_impl_value)

        self._orch_reasoning_tiers["medium"] = state.get(
            "llm.orchestrator.reasoning_level", self._orch_reasoning_tiers["medium"]
        )
        self._impl_reasoning_tiers["medium"] = state.get(
            "llm.implementation.reasoning_level", self._impl_reasoning_tiers["medium"]
        )
        self._update_all_dropdowns()
        self._update_preview()


# Dispatch table for on_select_changed. Keys mirror the original elif chain
# select-id order so semantics are preserved byte-for-byte. Provider-change
# handlers delegate back into the pre-existing methods (_handle_orch_provider_change,
# _handle_impl_provider_change, _handle_fallback_provider_change).
_SELECT_DISPATCH: dict[str, Any] = {
    "orch-provider-select": lambda self, v: self._handle_orch_provider_change(v),
    "orch-fast-select": lambda self, v: self._handle_orch_fast_select(v),
    "orch-medium-select": lambda self, v: self._handle_orch_medium_select(v),
    "orch-high-select": lambda self, v: self._handle_orch_high_select(v),
    "orch-fast-reasoning-select": lambda self, v: self._handle_orch_fast_reasoning(v),
    "orch-medium-reasoning-select": lambda self, v: self._handle_orch_medium_reasoning(v),
    "orch-high-reasoning-select": lambda self, v: self._handle_orch_high_reasoning(v),
    "impl-provider-select": lambda self, v: self._handle_impl_provider_change(v),
    "impl-fast-select": lambda self, v: self._handle_impl_fast_select(v),
    "impl-medium-select": lambda self, v: self._handle_impl_medium_select(v),
    "impl-high-select": lambda self, v: self._handle_impl_high_select(v),
    "impl-fast-reasoning-select": lambda self, v: self._handle_impl_fast_reasoning(v),
    "impl-medium-reasoning-select": lambda self, v: self._handle_impl_medium_reasoning(v),
    "impl-high-reasoning-select": lambda self, v: self._handle_impl_high_reasoning(v),
    "fallback-enabled-select": lambda self, v: self._handle_fallback_enabled(v),
    "fallback-startup-select": lambda self, v: self._handle_fallback_startup(v),
    "fallback-recovery-enabled-select": lambda self, v: self._handle_fallback_recovery_enabled(v),
    "fallback-recovery-cooldown-select": lambda self, v: self._handle_fallback_recovery_cooldown(v),
    "fallback-recovery-attempts-select": lambda self, v: self._handle_fallback_recovery_attempts(v),
    "fallback-recovery-natural-boundary-select": lambda self, v: self._handle_fallback_recovery_natural_boundary(v),
    "fb-orch-provider-select": lambda self, v: self._handle_fb_orch_provider(v),
    "fb-impl-provider-select": lambda self, v: self._handle_fb_impl_provider(v),
}
