"""Edit Modal widget for string and enum value editing.

Provides a modal dialog for editing configuration values with
string input or enum choice selection.
"""

from typing import Any

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.message import Message
from textual.screen import ModalScreen
from textual.widgets import Button, Input, Label, OptionList, Static
from textual.widgets._input import Selection
from textual.widgets.option_list import Option

from obra.config.explorer.descriptions import _get_provider_model_choices
from obra.config.explorer.models import ConfigNode, ConfigTree, ValueType


class EditModal(ModalScreen[Any]):
    """Modal dialog for editing string/enum configuration values.

    For string values: shows a text input field.
    For enum values: shows a selection list with Tab cycling.
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel"),
        Binding("enter", "submit", "Save", priority=True),
        Binding("tab", "next_choice", "Next", show=False),
        Binding("shift+tab", "prev_choice", "Previous", show=False),
    ]

    DEFAULT_CSS = """
    EditModal {
        align: center middle;
    }

    EditModal > Container {
        width: 60;
        height: auto;
        max-height: 20;
        background: $surface;
        border: thick $primary;
        padding: 1 2;
    }

    EditModal #title {
        text-style: bold;
        margin-bottom: 1;
    }

    EditModal #description {
        color: $text-muted;
        margin-bottom: 1;
    }

    EditModal Input {
        margin-bottom: 1;
    }

    EditModal OptionList {
        height: auto;
        max-height: 8;
        margin-bottom: 1;
    }

    EditModal .buttons {
        height: 3;
        align: right middle;
    }

    EditModal Button {
        margin-left: 1;
    }

    EditModal #dependency-warning {
        color: $warning;
        background: $warning-darken-3;
        padding: 0 1;
        margin-bottom: 1;
    }

    EditModal #origin-warning {
        color: $warning;
        background: $warning-darken-3;
        padding: 0 1;
        margin-bottom: 1;
    }
    """

    def __init__(self, node: ConfigNode, config_tree: ConfigTree | None = None) -> None:
        """Initialize the edit modal.

        Args:
            node: ConfigNode to edit
            config_tree: Optional ConfigTree for provider-aware model choices
        """
        super().__init__()
        self.node = node
        self._original_value = node.value
        self._config_tree = config_tree
        # Check if this is a provider setting that has model dependencies
        self._has_dependency_warning = self._check_for_dependencies()
        self._origin_warning = self._check_for_origin_warning()
        # Get provider-aware choices for model fields
        self._dynamic_choices = self._get_dynamic_choices()

    def _check_for_dependencies(self) -> bool:
        """Check if this setting has dependencies that may need updating.

        Returns:
            True if this is a provider setting with model dependencies
        """
        if not self.node.path:
            return False
        # Check if this is a provider setting
        return self.node.key == "provider" and (
            "orchestrator" in self.node.path or "implementation" in self.node.path
        )

    def _check_for_origin_warning(self) -> str | None:
        """Return warning text if the setting is shadowed by a higher layer."""
        origin = self.node.origin
        if not origin or origin == "user":
            return None
        return (
            f"Warning: This value is set by the {origin} layer. "
            "Edits will be saved to your user config only."
        )

    def _get_dynamic_choices(self) -> list[str] | None:
        """Get dynamic choices for model fields based on current provider.

        Dispatch-table with fall-through: each (matcher, resolver) pair is
        evaluated in order; matcher gates resolver; resolver returning None
        continues to the next pair. The tail default preserves the original
        ``return None`` semantics (no `CONFIG_CHOICES`-equivalent lookup for
        this function).

        Returns:
            Provider-specific model choices if this is a model field, otherwise None
        """
        if not self.node.path or not self._config_tree:
            return None

        for matcher, resolver in _DYNAMIC_CHOICES_DISPATCH:
            if matcher(self):
                result = resolver(self)
                if result is not None:
                    return result
        return None

    def _resolve_provider_with_fallback(self, provider_path: str) -> str | None:
        """Read provider at path; fall back to top-level llm.provider if per-role/blank.

        Mirrors the original body's fast-config fallback semantics.
        """
        assert self._config_tree is not None
        provider_node = self._config_tree.get_node(provider_path)
        provider = str(provider_node.value) if provider_node and provider_node.value else None

        if not provider or provider == "per-role":
            top_provider_node = self._config_tree.get_node("llm.provider")
            if (
                top_provider_node
                and top_provider_node.value
                and top_provider_node.value != "per-role"
            ):
                provider = str(top_provider_node.value)

        return provider

    def compose(self) -> ComposeResult:
        """Create the modal content."""
        with Container():
            yield Label(f"Edit: {self.node.key}", id="title")

            if self.node.description:
                yield Static(self.node.description, id="description")

            # Show dependency warning for provider settings
            if self._has_dependency_warning:
                yield Static(
                    "[yellow]Warning: Changing provider may reset model to 'default'[/yellow]",
                    id="dependency-warning",
                )
            if self._origin_warning:
                yield Static(
                    f"[yellow]{self._origin_warning}[/yellow]",
                    id="origin-warning",
                )

            # Use dynamic choices if available, otherwise fall back to node's static choices
            choices = self._dynamic_choices if self._dynamic_choices else self.node.choices

            if self.node.value_type == ValueType.ENUM and choices:
                # Enum editing with option list
                yield Label("Select a value:")
                yield OptionList(
                    *[Option(choice, id=choice) for choice in choices],
                    id="choices",
                )
            else:
                # String/integer editing with input
                yield Label("Enter new value:")
                yield Input(
                    value=str(self.node.value) if self.node.value is not None else "",
                    id="input",
                )

            with Horizontal(classes="buttons"):
                yield Button("Cancel", variant="default", id="cancel")
                yield Button("Save", variant="primary", id="save")

    def on_mount(self) -> None:
        """Focus the appropriate widget when mounted."""
        # Use dynamic choices if available
        choices = self._dynamic_choices if self._dynamic_choices else self.node.choices

        if self.node.value_type == ValueType.ENUM and choices:
            option_list = self.query_one("#choices", OptionList)
            # Pre-select current value if it exists in choices
            if self.node.value in choices:
                idx = choices.index(self.node.value)
                option_list.highlighted = idx
            option_list.focus()
        else:
            input_widget = self.query_one("#input", Input)
            input_widget.focus()
            # Select all text for easy replacement
            input_widget.selection = Selection(0, len(input_widget.value))

    def action_cancel(self) -> None:
        """Cancel editing and close modal."""
        self.dismiss(None)

    def action_submit(self) -> None:
        """Submit the new value and close modal."""
        new_value = self._get_new_value()
        # None means validation failed - stay in modal
        if new_value is None:
            return
        if new_value != self._original_value:
            self.dismiss(new_value)
        else:
            self.dismiss(None)

    def action_next_choice(self) -> None:
        """Move to next choice in enum list."""
        if self.node.value_type == ValueType.ENUM:
            try:
                option_list = self.query_one("#choices", OptionList)
                if option_list.highlighted is not None:
                    next_idx = (option_list.highlighted + 1) % option_list.option_count
                    option_list.highlighted = next_idx
            except Exception:
                pass

    def action_prev_choice(self) -> None:
        """Move to previous choice in enum list."""
        if self.node.value_type == ValueType.ENUM:
            try:
                option_list = self.query_one("#choices", OptionList)
                if option_list.highlighted is not None:
                    prev_idx = (option_list.highlighted - 1) % option_list.option_count
                    option_list.highlighted = prev_idx
            except Exception:
                pass

    def _get_new_value(self) -> Any | None:
        """Get the new value from the appropriate widget.

        Returns:
            The new value, or None if validation failed (modal should stay open).
        """
        # Use dynamic choices if available
        choices = self._dynamic_choices if self._dynamic_choices else self.node.choices

        if self.node.value_type == ValueType.ENUM and choices:
            option_list = self.query_one("#choices", OptionList)
            if option_list.highlighted is not None:
                return choices[option_list.highlighted]
            return self._original_value
        input_widget = self.query_one("#input", Input)
        new_str = input_widget.value

        # Convert to appropriate type
        if self.node.value_type == ValueType.INTEGER:
            try:
                return int(new_str)
            except ValueError:
                self.app.notify(
                    "Invalid number. Please enter a valid integer.",
                    severity="error",
                )
                return None  # Signal validation failure
        return new_str

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "cancel":
            self.action_cancel()
        elif event.button.id == "save":
            self.action_submit()

    def on_option_list_option_selected(self, _event: OptionList.OptionSelected) -> None:
        """Handle option selection (double-click or Enter on option)."""
        self.action_submit()

    class ValueSaved(Message):
        """Message posted when a value is saved."""

        def __init__(self, path: str, value: Any) -> None:
            super().__init__()
            self.path = path
            self.value = value


# --- _get_dynamic_choices dispatch table --------------------------------------
#
# Order mirrors the original if-block sequence. Matcher gates resolver; resolver
# returning None continues to the next pair. Preserves original precedence:
#   (1) role-level model fields (llm.orchestrator.model / llm.implementation.model)
#   (2) tier model fields (llm.{orchestrator,implementation}.tiers.{fast,medium,high})
# Both outer matchers can hit and have the resolver decline to the tail `return None`
# (e.g., provider unresolvable or not present in MODEL_REGISTRY).


def _match_role_model(modal: EditModal) -> bool:
    return modal.node.path in ("llm.orchestrator.model", "llm.implementation.model")


def _resolve_role_model(modal: EditModal) -> list[str] | None:
    # Determine the provider path based on whether this is orchestrator or implementation
    if "orchestrator" in modal.node.path:
        provider_path = "llm.orchestrator.provider"
    else:
        provider_path = "llm.implementation.provider"

    provider = modal._resolve_provider_with_fallback(provider_path)

    if provider and provider != "per-role":
        model_choices = _get_provider_model_choices()
        models = model_choices.get(provider)
        if models:
            # Role-level: prepend "per-tier" to allow delegation to tier settings
            return ["per-tier", *models]

    return None


def _match_tier_model(modal: EditModal) -> bool:
    # Keep "default" available so deeper menus can preserve
    # "Let Obra choose" instead of forcing an explicit model.
    path = modal.node.path or ""
    return ".tiers." in path and (
        path.endswith(".fast") or path.endswith(".medium") or path.endswith(".high")
    )


def _resolve_tier_model(modal: EditModal) -> list[str] | None:
    # Determine the role provider path based on whether this is orchestrator or implementation
    if "llm.orchestrator.tiers" in modal.node.path:
        provider_path = "llm.orchestrator.provider"
    elif "llm.implementation.tiers" in modal.node.path:
        provider_path = "llm.implementation.provider"
    else:
        return None

    provider = modal._resolve_provider_with_fallback(provider_path)

    if provider and provider != "per-role":
        model_choices = _get_provider_model_choices()
        models = model_choices.get(provider)
        if models:
            return ["default", *models]

    return None


_DYNAMIC_CHOICES_DISPATCH: list[tuple[Any, Any]] = [
    (_match_role_model, _resolve_role_model),
    (_match_tier_model, _resolve_tier_model),
]
