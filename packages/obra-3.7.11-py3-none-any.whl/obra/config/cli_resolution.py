"""Shared CLI discovery helpers for provider binaries.

Finder/launchd-spawned desktop processes inherit a minimal PATH that usually
excludes user-local install locations (`~/.local/bin`, `~/.claude/local`,
non-sudo npm global prefixes). Provider CLIs installed via the official
scripts land in those directories, so detection must fall back to probing
them directly when PATH lookup fails.

When no static probe finds the binary, :func:`resolve_cli_path` can also
consult the user's login shell (``$SHELL -lc 'command -v <cli>'``) to pick
up exotic shim layouts (volta, fnm, custom dotfile PATH entries). That
path is opt-in and gated by ``gateway.onboarding.shell_path_probe`` because
running a login shell inherits dotfile side effects and takes ~100–500 ms
on first call.

Once a binary is located, :func:`verify_provider_binary` runs a short probe
command (typically ``--version``) and requires the output to match a
provider-specific signature pattern. This guards against name collisions
with unrelated binaries (e.g. Homebrew's ``brianium/claude`` formula vs.
Anthropic's Claude Code CLI) that a plain PATH lookup cannot distinguish.
"""

from __future__ import annotations

import os
import platform
import re
import shutil
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Pattern, Sequence

_MACOS_FALLBACK_DIRS: tuple[Path, ...] = (
    Path("/opt/homebrew/bin"),
    Path("/usr/local/bin"),
)

# User-local install locations, probed on both macOS and Linux.
# Kept as string templates so tests can monkeypatch HOME and re-resolve.
_USER_LOCAL_FALLBACK_TEMPLATES: tuple[str, ...] = (
    "~/.local/bin",
    "~/.claude/local",
    "~/.npm-global/bin",
)


def _user_local_fallback_dirs() -> tuple[Path, ...]:
    """Expand user-local fallback templates against the current HOME.

    Resolved at call time (not import time) so that a Finder-launched
    subprocess with a freshly injected HOME sees the correct paths.
    """
    dirs: list[Path] = []
    for template in _USER_LOCAL_FALLBACK_TEMPLATES:
        expanded = Path(os.path.expanduser(template))
        if expanded not in dirs:
            dirs.append(expanded)
    return tuple(dirs)


def resolve_cli_path(cli_name: str) -> str | None:
    """Resolve a provider CLI path from PATH or common install locations.

    Lookup order:
    1. ``shutil.which`` on the current PATH.
    2. macOS-only Homebrew prefixes (``/opt/homebrew/bin``, ``/usr/local/bin``).
    3. User-local install directories on all POSIX platforms
       (``~/.local/bin``, ``~/.claude/local``, ``~/.npm-global/bin``).
    4. (Opt-in) Login-shell probe — ``$SHELL -lc 'command -v <cli>'``.
       Enabled via ``gateway.onboarding.shell_path_probe.enabled``.
    """
    resolved = shutil.which(cli_name)
    if resolved:
        return resolved

    candidates: list[Path] = []
    if platform.system() == "Darwin":
        candidates.extend(_MACOS_FALLBACK_DIRS)
    candidates.extend(_user_local_fallback_dirs())

    seen: set[str] = set()
    for base_dir in candidates:
        key = str(base_dir)
        if key in seen:
            continue
        seen.add(key)
        candidate = base_dir / cli_name
        if candidate.exists() and os.access(candidate, os.X_OK):
            return str(candidate)

    # Last resort — ask the user's login shell. This covers volta/fnm/nvm
    # shims and custom dotfile PATH entries we can't enumerate statically.
    shell_result = _probe_via_login_shell(cli_name)
    if shell_result is not None:
        return shell_result
    return None


# Per-CLI cache keyed by name → (resolved_path_or_none, expires_at_monotonic).
# Keeps the cost of the login-shell probe bounded across repeated calls.
_shell_probe_cache: dict[str, tuple[str | None, float]] = {}
_shell_probe_lock = threading.Lock()


def _shell_probe_config() -> dict[str, object]:
    """Return the shell-probe config subdict, with safe defaults on error."""
    # Imported lazily to avoid a cycle: config.loaders transitively imports
    # cli_resolution via the onboarding providers.
    try:
        from obra.config.loaders import get_gateway_onboarding_config

        return dict(get_gateway_onboarding_config().get("shell_path_probe") or {})
    except Exception:
        return {}


def _probe_via_login_shell(cli_name: str) -> str | None:
    """Ask the user's login shell where ``cli_name`` lives.

    Returns the resolved path if the shell reports one and the file exists
    and is executable. Returns ``None`` on timeout, exec error, or when the
    feature is disabled. Safe for repeated calls — results are cached per
    CLI name for ``cache_ttl_s`` seconds.
    """
    config = _shell_probe_config()
    if not config.get("enabled"):
        return None

    shell = os.environ.get("SHELL")
    if not shell or not os.path.exists(shell):
        return None

    # Reject pathological names to avoid shell injection via cli_name. The
    # caller is always provider code passing literals, but defense in depth
    # matters when this can be driven by config changes.
    if not _looks_like_cli_name(cli_name):
        return None

    now = time.monotonic()
    ttl = float(config.get("cache_ttl_s", 300))
    with _shell_probe_lock:
        cached = _shell_probe_cache.get(cli_name)
        if cached is not None and now < cached[1]:
            return cached[0]

    timeout = float(config.get("timeout_s", 2))
    try:
        result = subprocess.run(
            [shell, "-lc", f"command -v {cli_name}"],
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (subprocess.TimeoutExpired, OSError):
        _set_shell_probe_cache(cli_name, None, now + ttl)
        return None

    if result.returncode != 0:
        _set_shell_probe_cache(cli_name, None, now + ttl)
        return None

    # First line of stdout is the path. `command -v` can output a shell
    # builtin or alias for other names, but CLI names we care about are
    # always file paths; check existence to filter.
    candidate = result.stdout.strip().splitlines()
    resolved = candidate[0] if candidate else ""
    if not resolved or not Path(resolved).exists() or not os.access(resolved, os.X_OK):
        _set_shell_probe_cache(cli_name, None, now + ttl)
        return None

    _set_shell_probe_cache(cli_name, resolved, now + ttl)
    return resolved


_CLI_NAME_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._+-]*$")


def _looks_like_cli_name(name: str) -> bool:
    return bool(_CLI_NAME_PATTERN.match(name))


def _set_shell_probe_cache(cli_name: str, value: str | None, expires_at: float) -> None:
    with _shell_probe_lock:
        _shell_probe_cache[cli_name] = (value, expires_at)


def _reset_shell_probe_cache() -> None:
    """Test helper — clears the shell-probe cache."""
    with _shell_probe_lock:
        _shell_probe_cache.clear()


# Maximum bytes of probe stdout/stderr preserved for diagnostic surfaces.
# Enough to capture typical --version / --help banners without blowing up
# the onboarding status payload.
_PROBE_OUTPUT_EXCERPT_BYTES = 400


@dataclass(frozen=True)
class BinaryVerification:
    """Outcome of a provider binary verification probe.

    Attributes:
        matched: True when the probe output matched the expected signature.
        probe_output: Captured stdout/stderr excerpt from the probe (truncated,
            newlines normalized). Empty string on non-execution errors.
        exit_code: Exit code of the probe subprocess. ``None`` when the
            subprocess could not be started or timed out.
        issue: Categorized reason on mismatch; one of ``binary_mismatch``,
            ``binary_unresponsive``, ``binary_exec_error``. ``None`` on match.
    """

    matched: bool
    probe_output: str
    exit_code: int | None
    issue: str | None


def _excerpt(text: str) -> str:
    """Truncate and normalize probe output for diagnostic payloads."""
    if not text:
        return ""
    normalized = text.replace("\r\n", "\n").strip()
    if len(normalized) <= _PROBE_OUTPUT_EXCERPT_BYTES:
        return normalized
    return normalized[:_PROBE_OUTPUT_EXCERPT_BYTES] + "…"


def excerpt_diagnostic_text(text: str) -> str:
    """Public entry point for :func:`_excerpt` — used by auth-check helpers
    that want to surface stderr excerpts on the onboarding status payload.
    """
    return _excerpt(text)


def verify_provider_binary(
    binary_path: str,
    *,
    probe_args: Sequence[str] = ("--version",),
    signature_pattern: Pattern[str] | str,
    timeout_s: float,
) -> BinaryVerification:
    """Run a probe command against a resolved binary and match its output.

    A match requires both that the probe subprocess returned exit code 0
    *and* that stdout+stderr contains the provider signature. A non-zero
    exit code means the binary can execute but is reporting a problem (we
    treat that as an unresponsive binary rather than a mismatch, so the
    caller can surface a different diagnostic). Pattern matches are
    case-sensitive by default; compile with ``re.IGNORECASE`` to loosen.
    """
    if isinstance(signature_pattern, str):
        pattern = re.compile(re.escape(signature_pattern))
    else:
        pattern = signature_pattern

    try:
        result = subprocess.run(
            [binary_path, *probe_args],
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
    except subprocess.TimeoutExpired:
        return BinaryVerification(
            matched=False, probe_output="", exit_code=None, issue="binary_unresponsive",
        )
    except OSError as err:
        return BinaryVerification(
            matched=False,
            probe_output=f"{type(err).__name__}: {err}",
            exit_code=None,
            issue="binary_exec_error",
        )

    combined = f"{result.stdout}\n{result.stderr}"
    excerpt = _excerpt(combined)

    if result.returncode != 0:
        return BinaryVerification(
            matched=False,
            probe_output=excerpt,
            exit_code=result.returncode,
            issue="binary_unresponsive",
        )

    if pattern.search(combined):
        return BinaryVerification(
            matched=True, probe_output=excerpt, exit_code=result.returncode, issue=None,
        )

    return BinaryVerification(
        matched=False,
        probe_output=excerpt,
        exit_code=result.returncode,
        issue="binary_mismatch",
    )
