"""Pipeline getter owners."""

from __future__ import annotations

import os
from typing import Any

from obra.config.typed_schema import ExecutionConfig
from obra.exceptions import ConfigurationError

from .. import _core

__all__ = [
    "get_mcp_servers_config",
    "get_pipeline_custom_stages",
    "get_pipeline_max_iterations",
    "get_pipeline_registered_runners",
    "get_pipeline_stage_defaults",
    "get_pipeline_stage_timeout",
]


def get_pipeline_custom_stages() -> list[dict[str, Any]]:
    """Get enabled custom pipeline stages from configuration.

    Resolution order:
    1. pipeline.custom_stages from config file

    Returns:
        List of enabled stage configurations (filtered to enabled=True only)
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")
    custom_stages = pipeline_config.get("custom_stages", [])
    if not isinstance(custom_stages, list):
        raise ConfigurationError("pipeline.custom_stages must be a list")
    return [stage for stage in custom_stages if stage.get("enabled", True)]


def get_pipeline_registered_runners() -> list[dict[str, Any]]:
    """Get enabled canonical project-overlay Python runners in loader format."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")

    runner_catalog = pipeline_config.get("runner_catalog", {})
    if runner_catalog is not None and not isinstance(runner_catalog, dict):
        raise ConfigurationError("pipeline.runner_catalog must be a dictionary")

    project_overlay = (
        runner_catalog.get("project_overlay", {}) if isinstance(runner_catalog, dict) else {}
    )
    if project_overlay is not None and not isinstance(project_overlay, dict):
        raise ConfigurationError("pipeline.runner_catalog.project_overlay must be a dictionary")

    overlay_entries = (
        project_overlay.get("entries", []) if isinstance(project_overlay, dict) else []
    )
    if not isinstance(overlay_entries, list):
        raise ConfigurationError("pipeline.runner_catalog.project_overlay.entries must be a list")

    normalized_runners: list[dict[str, Any]] = []
    for entry in overlay_entries:
        if not isinstance(entry, dict) or not entry.get("enabled", True):
            continue
        if entry.get("kind") != "python_runner":
            continue
        activation = entry.get("activation", {})
        if not isinstance(activation, dict):
            continue
        factory = activation.get("factory")
        if not factory:
            continue
        normalized_runners.append(
            {
                "id": entry.get("id"),
                "factory": factory,
                "enabled": bool(entry.get("enabled", True)),
                "version": entry.get("version"),
            }
        )

    return normalized_runners


def get_pipeline_stage_defaults() -> dict[str, int]:
    """Get validated default pipeline-stage settings from configuration."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    pipeline_config = config.get("pipeline")
    if not isinstance(pipeline_config, dict):
        raise ConfigurationError("pipeline section not found in config")

    defaults = pipeline_config.get("defaults")
    if not isinstance(defaults, dict):
        raise ConfigurationError("pipeline.defaults section not found in config")

    timeout_value = defaults.get("timeout_s")
    if timeout_value is None:
        raise ConfigurationError("pipeline.defaults.timeout_s not found in config")
    try:
        timeout_s = int(timeout_value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("pipeline.defaults.timeout_s must be an integer") from exc
    if timeout_s < 600:
        raise ConfigurationError("pipeline.defaults.timeout_s must be >= 600")

    max_iterations_value = defaults.get("max_iterations")
    if max_iterations_value is None:
        raise ConfigurationError("pipeline.defaults.max_iterations not found in config")
    try:
        max_iterations = int(max_iterations_value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError("pipeline.defaults.max_iterations must be an integer") from exc

    return {
        "max_iterations": max_iterations,
        "timeout_s": timeout_s,
    }


def get_pipeline_stage_timeout(stage_name: str) -> int:
    """Get timeout for a specific pipeline stage.

    Resolution order:
    1. OBRA_PIPELINE_STAGE_TIMEOUT_S environment variable
    2. Stage-specific timeout from config (if defined)
    3. pipeline.defaults.timeout_s from config
    """
    env_val = os.environ.get("OBRA_PIPELINE_STAGE_TIMEOUT_S")
    if env_val:
        try:
            timeout_s = int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_PIPELINE_STAGE_TIMEOUT_S"
            raise ConfigurationError(msg) from None
        if timeout_s < 600:
            raise ConfigurationError("OBRA_PIPELINE_STAGE_TIMEOUT_S must be >= 600")
        return timeout_s

    custom_stages = get_pipeline_custom_stages()
    for stage in custom_stages:
        if stage.get("name") == stage_name and "timeout_s" in stage:
            try:
                timeout_s = int(stage["timeout_s"])
            except (TypeError, ValueError) as exc:
                raise ConfigurationError(
                    f"pipeline.custom_stages[{stage_name}].timeout_s must be an integer"
                ) from exc
            if timeout_s < 600:
                raise ConfigurationError(
                    f"pipeline.custom_stages[{stage_name}].timeout_s must be >= 600"
                )
            return timeout_s

    return get_pipeline_stage_defaults()["timeout_s"]


def get_pipeline_max_iterations() -> int:
    """Get maximum re-validate iterations for pipeline stages.

    Resolution order:
    1. OBRA_PIPELINE_MAX_ITERATIONS environment variable
    2. pipeline.defaults.max_iterations from config
    3. 3 (default)
    """
    env_val = os.environ.get("OBRA_PIPELINE_MAX_ITERATIONS")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_PIPELINE_MAX_ITERATIONS"
            raise ConfigurationError(msg) from None

    return get_pipeline_stage_defaults()["max_iterations"]


def get_mcp_servers_config() -> list[dict[str, Any]]:
    """Get MCP server definitions for agent sessions.

    Returns validated server entries from execution.mcp_servers.servers.
    Each entry must have an 'id' and either 'command' (stdio) or 'url' (HTTP).
    Returns empty list when execution.mcp_servers.enabled is false.
    """
    try:
        config, _, _ = _core.load_layered_config(include_defaults=True)
        execution = ExecutionConfig.model_validate(config.get("execution", {}))
        mcp_config = execution.mcp_servers
    except Exception:
        return []
    if not mcp_config.enabled:
        return []

    validated: list[dict[str, Any]] = []
    for entry in mcp_config.servers:
        if not entry.id or (not entry.command and not entry.url):
            continue
        payload = entry.model_dump(exclude_none=True)
        validated.append(payload)
    return validated
