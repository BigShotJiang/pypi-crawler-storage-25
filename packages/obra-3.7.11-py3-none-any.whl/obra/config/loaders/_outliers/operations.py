"""Runtime-operations getter owners."""

from __future__ import annotations

import logging
import os
from typing import Any

from obra.config.typed_schema import ParallelConfig
from obra.exceptions import ConfigurationError

from .. import _core, _defaults

# Re-export from split modules for backward compatibility
from .governor_config import get_governor_config
from .interactive_guard import (
    get_interactive_guard_enabled,
    get_interactive_guard_patterns,
    get_interactive_guard_retry_max,
    get_interactive_guard_rollback_codes,
    get_interactive_guard_rollback_enabled,
)

logger = logging.getLogger(__name__)

__all__ = [
    "get_derivation_serialize_worker_delay_s",
    "get_enrichment_review_max_concurrent",
    "get_governor_config",
    "get_hang_confidence",
    "get_hierarchy_limit",
    "get_hybrid_polling_config",
    "get_intent_alignment_max_concurrent",
    "get_interactive_guard_enabled",
    "get_interactive_guard_patterns",
    "get_interactive_guard_retry_max",
    "get_interactive_guard_rollback_codes",
    "get_interactive_guard_rollback_enabled",
    "get_limit",
    "get_parallel_worker_delay_s",
    "get_retry_config",
]


def get_retry_config() -> Any:
    """Get retry configuration for LLM invocations.

    Loads settings from the orchestration.retry section in config.
    Returns a RetryConfig object from obra.llm.retry.

    Resolution order:
    1. orchestration.retry.* from config file
    2. DEFAULT_RETRY_* constants

    Returns:
        RetryConfig object with retry settings
    """
    from obra.llm.retry import RetryConfig

    config, _, _ = _core.load_layered_config()
    retry_section = config.get("retry", {})

    if not isinstance(retry_section, dict):
        return RetryConfig()

    max_attempts = retry_section.get("max_attempts", _defaults.DEFAULT_RETRY_MAX_ATTEMPTS)
    auth_max_attempts = retry_section.get(
        "auth_max_attempts", _defaults.DEFAULT_RETRY_AUTH_MAX_ATTEMPTS
    )
    rate_limit_max_attempts = retry_section.get(
        "rate_limit_max_attempts", _defaults.DEFAULT_RETRY_RATE_LIMIT_MAX_ATTEMPTS
    )
    base_delay = retry_section.get(
        "base_delay",
        retry_section.get("base_delay_s", _defaults.DEFAULT_RETRY_BASE_DELAY),
    )
    max_delay = retry_section.get(
        "max_delay",
        retry_section.get("max_delay_s", _defaults.DEFAULT_RETRY_MAX_DELAY),
    )
    backoff_multiplier = retry_section.get(
        "backoff_multiplier", _defaults.DEFAULT_RETRY_BACKOFF_MULTIPLIER
    )
    jitter = retry_section.get("jitter", _defaults.DEFAULT_RETRY_JITTER)
    configured_patterns = retry_section.get("retryable_errors")
    if isinstance(configured_patterns, list):
        normalized_configured = [
            str(pattern).strip() for pattern in configured_patterns if str(pattern).strip()
        ]
        retryable_patterns = list(
            dict.fromkeys([*normalized_configured, *_defaults.DEFAULT_RETRY_PATTERNS])
        )
    else:
        retryable_patterns = list(_defaults.DEFAULT_RETRY_PATTERNS)

    env_rl = os.environ.get("OBRA_RETRY_RATE_LIMIT_MAX_ATTEMPTS")
    if env_rl:
        rate_limit_max_attempts = env_rl

    return RetryConfig(
        max_attempts=int(max_attempts),
        auth_max_attempts=int(auth_max_attempts),
        rate_limit_max_attempts=int(rate_limit_max_attempts),
        base_delay=float(base_delay),
        max_delay=float(max_delay),
        backoff_multiplier=float(backoff_multiplier),
        jitter=float(jitter),
        retryable_patterns=list(retryable_patterns),
    )


def get_parallel_worker_delay_s(provider: str | None = None) -> float:
    """Get inter-worker delay for parallel LLM dispatchers.

    Resolution order:
    1. OBRA_PARALLEL_WORKER_DELAY_S_<PROVIDER> environment variable (if provider given)
    2. OBRA_PARALLEL_WORKER_DELAY_S environment variable
    3. orchestration.parallel.provider_overrides.<provider> (if provider given)
    4. orchestration.parallel.worker_delay_s from config file
    5. Default: 1.0
    """
    provider_lower = provider.lower() if provider else None

    if provider_lower:
        env_key = f"OBRA_PARALLEL_WORKER_DELAY_S_{provider_lower.upper()}"
        env_val = os.environ.get(env_key)
        if env_val:
            try:
                value = float(env_val)
                if value >= 0:
                    return value
                logger.warning("%s must be >= 0 (got %s)", env_key, env_val)
            except (TypeError, ValueError):
                logger.warning("%s must be a number (got %s)", env_key, env_val)

    env_val = os.environ.get("OBRA_PARALLEL_WORKER_DELAY_S")
    if env_val:
        try:
            value = float(env_val)
            if value >= 0:
                return value
            logger.warning(
                "OBRA_PARALLEL_WORKER_DELAY_S must be >= 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_PARALLEL_WORKER_DELAY_S must be a number (got %s)",
                env_val,
            )

    try:
        config, _, _ = _core.load_layered_config()
        orch_config = config.get("orchestration", {})
        parallel_config = ParallelConfig.model_validate(
            orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
        )
        if provider_lower:
            provider_delay = parallel_config.provider_overrides.get(provider_lower)
            if provider_delay is not None:
                value = float(provider_delay)
                if value >= 0:
                    return value
                logger.warning(
                    "orchestration.parallel.provider_overrides.%s must be >= 0 (got %s)",
                    provider_lower,
                    provider_delay,
                )

        value = float(parallel_config.worker_delay_s)
        if value >= 0:
            return value
        logger.warning(
            "orchestration.parallel.worker_delay_s must be >= 0 (got %s)",
            parallel_config.worker_delay_s,
        )
    except Exception:
        logger.debug("Falling back to default parallel worker delay", exc_info=True)

    return 1.0


def get_derivation_serialize_worker_delay_s(provider: str | None = None) -> float:
    """Get inter-worker delay for derivation serialization.

    Delegates to get_parallel_worker_delay_s() — kept for backward
    compatibility with existing config overrides.
    """
    return get_parallel_worker_delay_s(provider=provider)


def get_intent_alignment_max_concurrent() -> int:
    """Get max concurrent workers for intent story checks.

    Resolution order:
    1. OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT environment variable
    2. planning.intent_alignment.max_concurrent from config file
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_INTENT_ALIGNMENT_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    planning_config = config.get("planning", {})
    if isinstance(planning_config, dict):
        alignment_config = planning_config.get("intent_alignment", {})
        if isinstance(alignment_config, dict):
            max_concurrent = alignment_config.get("max_concurrent")
            if max_concurrent is not None:
                try:
                    value = int(max_concurrent)
                    if value > 0:
                        return value
                    logger.warning(
                        "planning.intent_alignment.max_concurrent must be > 0 (got %s)",
                        max_concurrent,
                    )
                except (TypeError, ValueError):
                    logger.warning(
                        "planning.intent_alignment.max_concurrent must be an integer (got %s)",
                        max_concurrent,
                    )

    return 4


def get_enrichment_review_max_concurrent() -> int:
    """Get max concurrent workers for enrichment story review.

    Resolution order:
    1. OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT environment variable
    2. planning.enrichment.stages.review.max_concurrent from config file
    3. Default: 4

    Returns:
        Max concurrent workers (default: 4)
    """
    env_val = os.environ.get("OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT")
    if env_val:
        try:
            value = int(env_val)
            if value > 0:
                return value
            logger.warning(
                "OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT must be > 0 (got %s)",
                env_val,
            )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_ENRICHMENT_REVIEW_MAX_CONCURRENT must be an integer (got %s)",
                env_val,
            )

    config, _, _ = _core.load_layered_config()
    planning_config = config.get("planning", {})
    if isinstance(planning_config, dict):
        enrichment_config = planning_config.get("enrichment", {})
        if isinstance(enrichment_config, dict):
            stages_config = enrichment_config.get("stages", {})
            if isinstance(stages_config, dict):
                review_config = stages_config.get("review")
                if not isinstance(review_config, dict):
                    review_config = stages_config.get("revise", {})
                if isinstance(review_config, dict):
                    max_concurrent = review_config.get("max_concurrent")
                    if max_concurrent is not None:
                        try:
                            value = int(max_concurrent)
                            if value > 0:
                                return value
                            logger.warning(
                                "planning.enrichment.stages.review.max_concurrent must be > 0 (got %s)",
                                max_concurrent,
                            )
                        except (TypeError, ValueError):
                            logger.warning(
                                "planning.enrichment.stages.review.max_concurrent must be an integer (got %s)",
                                max_concurrent,
                            )

    return 4


def get_hang_confidence(hang_type: str) -> float:
    """Get confidence score for hang type classification.

    Args:
        hang_type: Type of hang (real_hang, io_blocking_with_file,
                  io_blocking_without, slow_progress, external_blocking, unknown)

    Returns:
        Confidence score for hang type (0.0-1.0)
    """
    config, _, _ = _core.load_layered_config()
    monitoring_config = config.get("monitoring", {})
    if isinstance(monitoring_config, dict):
        hang_config = monitoring_config.get("hang_investigation", {})
        if isinstance(hang_config, dict):
            confidence_config = hang_config.get("confidence", {})
            if isinstance(confidence_config, dict):
                confidence = confidence_config.get(hang_type)
                if confidence is not None:
                    try:
                        return float(confidence)
                    except (TypeError, ValueError):
                        pass
    return _defaults.DEFAULT_HANG_CONFIDENCE.get(hang_type, 0.30)


def get_hybrid_polling_config() -> dict:
    """Get hybrid orchestration polling configuration.

    Returns:
        Dict with max_delay_s, backoff_multiplier, base_delay_s keys
    """
    config, _, _ = _core.load_layered_config()
    hybrid_config = config.get("hybrid", {})
    if isinstance(hybrid_config, dict):
        polling_config = hybrid_config.get("polling", {})
        if isinstance(polling_config, dict):
            return {
                "max_delay_s": polling_config.get(
                    "max_delay_s", _defaults.DEFAULT_HYBRID_POLLING_CONFIG["max_delay_s"]
                ),
                "backoff_multiplier": polling_config.get(
                    "backoff_multiplier",
                    _defaults.DEFAULT_HYBRID_POLLING_CONFIG["backoff_multiplier"],
                ),
                "base_delay_s": polling_config.get(
                    "base_delay_s", _defaults.DEFAULT_HYBRID_POLLING_CONFIG["base_delay_s"]
                ),
            }
    return _defaults.DEFAULT_HYBRID_POLLING_CONFIG.copy()


def get_limit(name: str) -> int:
    """Get operational limit by name.

    Resolution order (Rule 22):
    1. OBRA_LIMIT_{NAME} environment variable (uppercase)
    2. orchestration.limits.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of the valid limit names.

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid limit name
        ConfigurationError: If limit is not found in config
    """
    if name not in _defaults._LIMIT_NAMES:
        valid_names = ", ".join(sorted(_defaults._LIMIT_NAMES))
        msg = f"Invalid limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    env_name = f"OBRA_LIMIT_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        limits_config = config["orchestration"]["limits"]
        return int(limits_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Limit '{name}' not found in config at orchestration.limits.{name}"
        raise ConfigurationError(msg) from exc


def get_hierarchy_limit(name: str) -> int:
    """Get hierarchy constraint limit by name.

    Resolution order (Rule 22):
    1. OBRA_HIERARCHY_{NAME} environment variable (uppercase)
    2. orchestration.hierarchy.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of 'max_stories_per_epic', 'max_tasks_per_story', 'max_subtasks_per_task'

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid hierarchy limit name
        ConfigurationError: If limit is not found in config
    """
    if name not in _defaults._HIERARCHY_LIMIT_NAMES:
        valid_names = ", ".join(sorted(_defaults._HIERARCHY_LIMIT_NAMES))
        msg = f"Invalid hierarchy limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    env_name = f"OBRA_HIERARCHY_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        hierarchy_config = config["orchestration"]["hierarchy"]
        return int(hierarchy_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Hierarchy limit '{name}' not found in config at orchestration.hierarchy.{name}"
        raise ConfigurationError(msg) from exc
