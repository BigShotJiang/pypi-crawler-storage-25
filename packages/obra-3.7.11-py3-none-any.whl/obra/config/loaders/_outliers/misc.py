"""Residual getter owners with no stronger family match."""

from __future__ import annotations

from obra.config.typed_schema import IntentConfig

from .. import _core, _defaults

__all__ = [
    "get_agent_ignore_patterns",
    "get_intent_chunking_config",
    "get_intent_rate_limit_config",
]


def get_agent_ignore_patterns() -> list[str]:
    """Get ignore patterns for agent file scanning.

    Returns:
        List of glob patterns or directory names to skip during agent scans.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    patterns = (
        config.get("features", {})
        .get("quality_automation", {})
        .get("agents", {})
        .get("ignore_patterns")
    )
    if isinstance(patterns, list):
        return [str(item) for item in patterns if item]
    return []


def get_intent_chunking_config() -> dict:
    """Get intent chunking configuration.

    Returns:
        Dict with size_tokens, overlap_tokens, warning_threshold keys
    """
    try:
        config, _, _ = _core.load_layered_config()
        intent = IntentConfig.model_validate(config.get("intent", {}))
        chunking = intent.chunking
    except Exception:
        return _defaults.DEFAULT_INTENT_CHUNKING_CONFIG.copy()
    return {
        "size_tokens": chunking.size_tokens,
        "overlap_tokens": chunking.overlap_tokens,
        "warning_threshold": chunking.warning_threshold,
    }


def get_intent_rate_limit_config() -> dict:
    """Get intent rate limit configuration.

    Returns:
        Dict with max_retries, backoff_delays_s (list) keys
    """
    try:
        config, _, _ = _core.load_layered_config()
        intent = IntentConfig.model_validate(config.get("intent", {}))
        rate_limit = intent.rate_limit
    except Exception:
        return _defaults.DEFAULT_INTENT_RATE_LIMIT_CONFIG.copy()
    return {
        "max_retries": rate_limit.max_retries,
        "backoff_delays_s": list(rate_limit.backoff_delays_s),
    }
