"""Default schema loading and configuration validation.

Loads ``default_config.yaml`` from package resources, caches it for the
process lifetime, and provides startup validation that fails fast when
the installation is corrupted.

CIRCULAR DEPENDENCY NOTE: ``validate_default_schema()`` calls
``load_layered_config()`` from ``_loading.py``.  ``_loading.py`` imports
``_get_default_schema_cached()`` from this module at the top level.
The cycle is broken by using a **deferred import** of ``_loading``
inside ``validate_default_schema()``'s function body.
"""

from __future__ import annotations

import logging
import sys
from copy import deepcopy
from typing import Any

from obra.exceptions import ConfigurationError
from obra.workflow.quality_loop import collect_stage_quality_loop_issues
from obra.workflow.runner_catalog import RunnerCatalogEntry
from obra.workflow.stage_contract import collect_stage_contract_issues

from . import _defaults
from ._paths import _yaml_safe_load

logger = logging.getLogger(__name__)

# Config validation cache - ensures validation runs only once per process
_config_validated = False
_DEFAULT_SCHEMA_CACHE: dict[str, Any] | None = None


def _load_default_schema() -> dict[str, Any]:
    """Load the default configuration schema from package resources.

    Raises:
        ConfigurationError: If default_config.yaml is missing or unreadable.

            This indicates a corrupted installation that should be fixed
            by reinstalling the package.
    """
    from importlib import resources

    try:
        default_path = resources.files("obra.config").joinpath("default_config.yaml")
        content = default_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        msg = (
            "default_config.yaml not found in package. "
            "Installation may be corrupted. "
            "Path searched: obra.config/default_config.yaml. "
            "Try: pip install --force-reinstall obra"
        )
        raise ConfigurationError(msg) from None
    except Exception as exc:
        msg = (
            f"Failed to read default_config.yaml: {exc}. "
            "Installation may be corrupted. "
            "Try: pip install --force-reinstall obra"
        )
        raise ConfigurationError(msg) from exc

    data = _yaml_safe_load(content) or {}
    if not isinstance(data, dict):
        msg = (
            "default_config.yaml has invalid format (expected dict). "
            "Installation may be corrupted. "
            "Try: pip install --force-reinstall obra"
        )
        raise ConfigurationError(msg)
    return data


def _get_default_schema_cached() -> dict[str, Any]:
    """Return cached default schema for this process.

    Safe because packaged defaults are immutable for the lifetime of a process.
    """
    global _DEFAULT_SCHEMA_CACHE
    if _DEFAULT_SCHEMA_CACHE is None:
        _DEFAULT_SCHEMA_CACHE = _load_default_schema()
    return _DEFAULT_SCHEMA_CACHE


def validate_default_schema() -> None:
    """Validate that the default configuration schema is available and valid.

    Call this early in CLI initialization to fail fast if the installation
    is corrupted or config has missing/invalid keys. This must run before
    handler imports to provide clear error messages.

    Uses caching to ensure validation runs only once per process.

    Raises:
        SystemExit: If configuration validation fails (exits with code 1).

    Related:
        - ADR-047: Config single source of truth
        - S4.T1: Startup schema validation
    """
    global _config_validated

    # First check that default_config.yaml exists and is loadable
    defaults = _load_default_schema()
    global _DEFAULT_SCHEMA_CACHE
    if _DEFAULT_SCHEMA_CACHE is None:
        _DEFAULT_SCHEMA_CACHE = defaults

    if _config_validated:
        return

    # Then validate config values against comprehensive schema
    try:
        from obra.config.schema import validate_config

        # Deferred import to break circular dependency with _loading.py
        from ._loading import load_layered_config

        # Load config with defaults to validate complete merged config
        config, _, _ = load_layered_config(include_defaults=True)
        is_valid, errors = validate_config(config)

        if not is_valid:
            print("Config validation failed:", file=sys.stderr)
            for err in errors:
                print(f"  - {err}", file=sys.stderr)
            print(
                "\nPlease check your config or run: obra config reset --force",
                file=sys.stderr,
            )
            sys.exit(1)

        # Validate pipeline configuration (FEAT-PIPELINE-001)
        pipeline_errors = validate_pipeline_config(config)
        if pipeline_errors:
            print("Pipeline configuration validation failed:", file=sys.stderr)
            for err in pipeline_errors:
                print(f"  - {err}", file=sys.stderr)
            print(
                "\nPlease check your pipeline config, migrate deprecated keys, "
                "or verify the bundled defaults match the active validator. See: "
                "docs/guides/obra/pipeline-configuration-guide.md",
                file=sys.stderr,
            )
            sys.exit(1)

        _config_validated = True

    except ImportError as e:
        # Schema module not available - log warning but don't fail
        # This ensures backward compatibility during development
        logger.warning(f"Config schema validation unavailable: {e}")
        _config_validated = True


def _get_default_code_verify_config() -> dict[str, Any]:
    """Get bundled default config for code_verify agent."""
    defaults = _load_default_schema()
    try:
        value = defaults["features"]["quality_automation"]["agents"]["code_verify"]
        if isinstance(value, dict):
            return deepcopy(value)
    except KeyError:
        pass

    # Defensive fallback if bundled schema is missing keys
    return {
        "enabled": True,
        "llm": deepcopy(_defaults.AGENT_LLM_DEFAULTS) | {"model_tier": "inherit"},
        "checks": {
            "grounding": True,
            "compliance": True,
            "dependency_graph": True,
        },
        "parallel_calls": True,
        "timeout_s": 900,
        "max_findings": 50,
        "brownfield_threshold": 50,
        "greenfield_skip_story1": True,
        "story_preflight": {
            "enabled": True,
            "sense_check": True,
            "checks": ["C1", "C2", "C3", "C4", "C7", "C8", "C9"],
            "v0_action": "escalate",
            "timeout_s": 600,
            "max_task_modifications": 10,
            "max_verification_passes": 5,
            "scope_to_modified": True,
            "track_resolved": True,
        },
    }


def _get_default_escalation_fixer_config() -> dict[str, Any]:
    """Get bundled default config for escalation_fixer agent."""
    defaults = _load_default_schema()
    try:
        value = defaults["features"]["quality_automation"]["agents"]["escalation_fixer"]
        if isinstance(value, dict):
            return deepcopy(value)
    except KeyError:
        pass

    return {
        "enabled": False,
        "llm": deepcopy(_defaults.AGENT_LLM_DEFAULTS) | {"model_tier": "inherit"},
    }


def _validate_runner_catalog(pipeline_config: dict[str, Any], errors: list[str]) -> None:
    """Validate pipeline.runner_catalog.project_overlay.entries block.

    Appends any errors found to ``errors``. Mirrors the original
    in-place accumulation order exactly (per-entry errors in the order the
    entries appear in the overlay list).
    """
    runner_catalog = pipeline_config.get("runner_catalog", {})
    if runner_catalog is None:
        runner_catalog = {}
    if not isinstance(runner_catalog, dict):
        errors.append("pipeline.runner_catalog must be a dictionary")
        runner_catalog = {}

    project_overlay = runner_catalog.get("project_overlay", {})
    if project_overlay is None:
        project_overlay = {}
    if not isinstance(project_overlay, dict):
        errors.append("pipeline.runner_catalog.project_overlay must be a dictionary")
        project_overlay = {}

    overlay_entries = project_overlay.get("entries", [])
    if not isinstance(overlay_entries, list):
        errors.append("pipeline.runner_catalog.project_overlay.entries must be a list")
        overlay_entries = []

    seen_runner_identities: set[tuple[str, str]] = set()
    for idx, entry in enumerate(overlay_entries):
        if not isinstance(entry, dict):
            errors.append(
                f"pipeline.runner_catalog.project_overlay.entries[{idx}] must be a dictionary"
            )
            continue
        try:
            normalized_entry = RunnerCatalogEntry.from_mapping(entry)
        except ValueError as exc:
            errors.append(f"pipeline.runner_catalog.project_overlay.entries[{idx}] {exc}")
            continue

        enabled_value = entry.get("enabled")
        if enabled_value is not None and not isinstance(enabled_value, bool):
            errors.append(
                f"pipeline.runner_catalog.project_overlay.entries[{idx}].enabled must be a boolean"
            )

        identity = normalized_entry.identity_key
        if identity in seen_runner_identities:
            errors.append(
                "pipeline.runner_catalog.project_overlay.entries"
                f"[{idx}] duplicates runner identity {identity}"
            )
        else:
            seen_runner_identities.add(identity)


def _validate_registered_runners_rejected(
    pipeline_config: dict[str, Any], errors: list[str]
) -> None:
    """Reject the deprecated ``pipeline.registered_runners`` key."""
    if "registered_runners" in pipeline_config:
        errors.append(
            "pipeline.registered_runners is not supported; use pipeline.runner_catalog.project_overlay.entries."
        )


def _validate_defaults(pipeline_config: dict[str, Any], errors: list[str]) -> bool:
    """Validate ``pipeline.defaults``.

    Returns:
        ``True`` when validation should continue (defaults is a dict, even if
        timeout_s is bad). ``False`` when defaults is not a dict, matching the
        original function's ``return errors`` short-circuit at that point.
    """
    defaults = pipeline_config.get("defaults", {})
    if not isinstance(defaults, dict):
        errors.append("pipeline.defaults must be a dictionary")
        return False

    default_timeout = defaults.get("timeout_s")
    if default_timeout is None:
        errors.append("pipeline.defaults.timeout_s is required")
    else:
        try:
            if int(default_timeout) < 600:
                errors.append("pipeline.defaults.timeout_s must be >= 600")
        except (TypeError, ValueError):
            errors.append("pipeline.defaults.timeout_s must be an integer >= 600")
    return True


def _validate_single_stage(idx: int, stage: Any, errors: list[str]) -> None:
    """Validate a single custom_stages entry, appending any errors."""
    if not isinstance(stage, dict):
        errors.append(f"Stage {idx} must be a dictionary")
        return

    stage_name = stage.get("name", f"stage-{idx}")

    # Validate trigger
    trigger = stage.get("trigger")
    if trigger and trigger not in _defaults.VALID_TRIGGERS:
        errors.append(
            f"Stage '{stage_name}': invalid trigger '{trigger}'. "
            f"Must be one of: {', '.join(_defaults.VALID_TRIGGERS)}"
        )

    errors.extend(collect_stage_contract_issues(stage))
    if stage.get("runner_config") is not None and not isinstance(
        stage.get("runner_config"), dict
    ):
        errors.append(f"Stage '{stage_name}': runner_config must be a dictionary")

    stage_timeout = stage.get("timeout_s")
    if stage_timeout is not None:
        try:
            if int(stage_timeout) < 600:
                errors.append(f"Stage '{stage_name}': timeout_s must be >= 600")
        except (TypeError, ValueError):
            errors.append(f"Stage '{stage_name}': timeout_s must be an integer >= 600")

    if stage.get("quality_loop") is None:
        errors.append(f"Stage '{stage_name}': quality_loop is required")

    for issue in collect_stage_quality_loop_issues(stage):
        message = str(issue.get("message") or "Stage quality_loop configuration is invalid.")
        errors.append(f"Stage '{stage_name}': {message}")


def _validate_custom_stages(pipeline_config: dict[str, Any], errors: list[str]) -> None:
    """Validate ``pipeline.custom_stages`` block.

    Handles the "missing" and "not a list" short-circuits internally via
    early return so the main function stays flat.
    """
    if "custom_stages" not in pipeline_config:
        return  # Empty stages is valid

    custom_stages = pipeline_config.get("custom_stages", [])
    if not isinstance(custom_stages, list):
        errors.append("pipeline.custom_stages must be a list")
        return

    for idx, stage in enumerate(custom_stages):
        _validate_single_stage(idx, stage, errors)


def validate_pipeline_config(config: dict[str, Any]) -> list[str]:
    """Validate pipeline configuration against schema.

    Validates:
        1. Trigger values against VALID_TRIGGERS
        2. Canonical runner config
        3. Actor values against valid options
        4. Action values against valid options
        5. Then values against valid options
        6. On_sound values against valid options

    Args:
        config: Configuration dictionary to validate

    Returns:
        List of error strings (empty if valid)

    Example:
        >>> config = load_layered_config()[0]
        >>> errors = validate_pipeline_config(config)
        >>> if errors:
        ...     print("\\n".join(errors))
    """
    errors: list[str] = []

    # Check if pipeline config exists
    if "pipeline" not in config:
        return errors  # No pipeline config is valid (optional feature)

    pipeline_config = config["pipeline"]
    _validate_runner_catalog(pipeline_config, errors)
    _validate_registered_runners_rejected(pipeline_config, errors)
    if not _validate_defaults(pipeline_config, errors):
        return errors
    _validate_custom_stages(pipeline_config, errors)
    return errors
