"""Config file path resolution and YAML loading.

Provides path helpers for the layered config system and a thin
wrapper around PyYAML's safe loader that prefers the C extension.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import yaml

from . import _defaults

try:
    from yaml import CSafeLoader as _YAML_SAFE_LOADER
except ImportError:  # pragma: no cover - depends on PyYAML build
    from yaml import SafeLoader as _YAML_SAFE_LOADER


def _yaml_safe_load(content: str) -> Any:
    """Parse YAML content with the fastest available safe loader."""
    return yaml.load(content, Loader=_YAML_SAFE_LOADER)


def get_config_path() -> Path:
    """Get path to user configuration file.

    Returns:
        Path to ~/.obra/config-layers/01-user.yaml
    """
    return _defaults.CONFIG_PATH


def get_workspace_layer_path(workspace_id: str) -> Path:
    """Return the workspace layer path for a workspace identifier."""
    return _defaults.CONFIG_LAYER_DIR / f"{_defaults.PROJECT_LAYER_PREFIX}{workspace_id}.yaml"


def get_session_layer_path(session_id: str) -> Path:
    """Return the session layer path for a session identifier."""
    return _defaults.CONFIG_LAYER_DIR / f"{_defaults.SESSION_LAYER_PREFIX}{session_id}.yaml"


def get_session_layer_override() -> Path | None:
    """Return the session layer override path from environment, if set."""
    value = os.environ.get(_defaults.SESSION_CONFIG_ENV_VAR)
    if not value:
        return None
    return Path(value).expanduser()


def _ensure_user_config_exists() -> None:
    if _defaults.CONFIG_PATH.exists():
        return
    _defaults.CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    _defaults.CONFIG_PATH.write_text("{}\n", encoding="utf-8")
