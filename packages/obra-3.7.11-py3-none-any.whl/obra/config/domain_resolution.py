"""Domain resolution for Obra orchestration.

Resolves the effective runtime domain from CLI flags, project config,
and layered config, in precedence order.
"""

import logging
from pathlib import Path
from typing import Any

import yaml

from obra.domains.resolution import (
    DomainResolutionResult,
    normalize_domain_id,
    resolve_domain_precedence,
    unresolved_domain,
)
from obra.exceptions import ConfigurationError

from .loaders import (
    get_workspace_layer_path,
    load_layered_config,
)

logger = logging.getLogger(__name__)


def _extract_domain_name(
    raw_config: dict[str, Any], *, source_label: str
) -> DomainResolutionResult:
    orchestration_section = raw_config.get("orchestration")
    if orchestration_section is not None:
        if not isinstance(orchestration_section, dict):
            return DomainResolutionResult(
                status="invalid",
                source=source_label,
                message=f"Invalid orchestration section in {source_label} (expected mapping).",
            )
        else:
            domain_value = orchestration_section.get("domain")
            if domain_value is not None:
                normalized = normalize_domain_id(domain_value)
                if normalized is None:
                    return DomainResolutionResult(
                        status="invalid",
                        source=f"{source_label}:orchestration.domain",
                        raw_value=str(domain_value),
                        message=f"Invalid orchestration.domain in {source_label} (expected non-empty string).",
                    )
                return DomainResolutionResult(
                    status="configured_default",
                    domain_id=normalized,
                    source=f"{source_label}:orchestration.domain",
                )

    planning_section = raw_config.get("planning")
    if isinstance(planning_section, dict):
        domain_value = planning_section.get("domain")
        if domain_value is not None:
            normalized = normalize_domain_id(domain_value)
            if normalized is None:
                return DomainResolutionResult(
                    status="invalid",
                    source=f"{source_label}:planning.domain",
                    raw_value=str(domain_value),
                    message=f"Invalid planning.domain in {source_label} (expected non-empty string).",
                )
            return DomainResolutionResult(
                status="configured_default",
                domain_id=normalized,
                source=f"{source_label}:planning.domain",
            )
    elif planning_section is not None:
        return DomainResolutionResult(
            status="invalid",
            source=source_label,
            message=f"Invalid planning section in {source_label} (expected mapping).",
        )

    domain_top = raw_config.get("domain")
    if domain_top is not None:
        normalized = normalize_domain_id(domain_top)
        if normalized is None:
            return DomainResolutionResult(
                status="invalid",
                source=f"{source_label}:domain",
                raw_value=str(domain_top),
                message=f"Invalid top-level domain in {source_label} (expected non-empty string).",
            )
        return DomainResolutionResult(
            status="configured_default",
            domain_id=normalized,
            source=f"{source_label}:domain",
        )
    return unresolved_domain(source=source_label)


def get_project_orchestration_domain(project_path: Path | None) -> DomainResolutionResult:
    """Load the project-level runtime domain override, if any."""
    if project_path is None:
        return unresolved_domain(source="project config")

    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_workspace_id(project_path)
    config_path = get_workspace_layer_path(project_id)
    if not config_path.exists():
        return unresolved_domain(source="project config")

    try:
        with config_path.open(encoding="utf-8") as config_file:
            raw_config = yaml.safe_load(config_file) or {}
    except yaml.YAMLError as exc:
        msg = f"Invalid YAML in {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Fix the YAML syntax in the project config layer and try again.",
        ) from exc
    except OSError as exc:
        msg = f"Unable to read {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Check file permissions for the project config layer and retry.",
        ) from exc

    return _extract_domain_name(raw_config, source_label=str(config_path))


def resolve_orchestration_domain(
    cli_domain: str | None,
    *,
    project_path: Path | None,
    config: dict[str, Any] | None = None,
) -> DomainResolutionResult:
    """Resolve the effective runtime domain for a session."""
    if cli_domain is not None:
        return resolve_domain_precedence(((cli_domain, "explicit", "cli.domain"),))

    project_domain = get_project_orchestration_domain(project_path)
    if project_domain.status == "invalid":
        return project_domain
    if project_domain.is_resolved:
        return resolve_domain_precedence(
            (
                (
                    project_domain.domain_id,
                    "configured_default",
                    project_domain.source or "project config",
                ),
            )
        )

    layered_config = config
    if layered_config is None:
        layered_config, _, _ = load_layered_config(include_defaults=True)

    config_domain = _extract_domain_name(layered_config, source_label="layered config")
    if config_domain.status == "invalid":
        return config_domain
    if config_domain.is_resolved:
        return resolve_domain_precedence(
            (
                (
                    config_domain.domain_id,
                    "configured_default",
                    config_domain.source or "layered config",
                ),
            )
        )
    return unresolved_domain(
        source="layered config",
        message=(
            "No explicit domain was selected and no explicit configured default domain "
            "was found in project or layered config."
        ),
    )
