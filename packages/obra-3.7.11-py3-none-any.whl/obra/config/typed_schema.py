"""Typed config schema (Pydantic v2) for the migrated runtime sections.

This module wraps the layered YAML config in Pydantic models so downstream
code can stop relying on raw ``config["section"]["key"]`` lookups for the
sections covered here. Unknown keys remain tolerated via
``ConfigDict(extra="ignore")`` because operators may layer additional config.

Deferred dynamic-key subsections:
- ``orchestration.resilience``
- ``orchestration.governor.providers`` (operator/provider keyed)
- ``review.feedback.flag_weights``
- ``review.feedback.rating_adjustments``
- ``review.sense_check.pipeline.framework.ordering``
- ``derivation.sizing.guidance``
- ``derivation.sizing.routing.policies``
- ``derivation.workflow.llm`` (LLM config remains on specialized loaders)
"""

from __future__ import annotations

from functools import lru_cache
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class ObraBaseModel(BaseModel):
    """Shared base model for tolerant typed-config parsing."""

    model_config = ConfigDict(extra="ignore")


# =============================================================================
# Section: orchestration.*
# =============================================================================


class PolicyEngineConfig(ObraBaseModel):
    """``orchestration.policy_engine``."""

    oscillation_recurrence_threshold: float
    max_refinement_iterations_cap: int = Field(..., ge=1)


class SpikeMaxAttempts(ObraBaseModel):
    """Per-rigor-mode spike attempt limits."""

    light: int = Field(..., ge=0)
    balanced: int = Field(..., ge=0)
    thorough: int = Field(..., ge=0)


class GroundingExtractorConfig(ObraBaseModel):
    """``orchestration.spike_first.grounding_extractor``."""

    enabled: bool
    timeout_s: int = Field(..., ge=600)
    tier: str


class SpikeFirstConfig(ObraBaseModel):
    """``orchestration.spike_first``."""

    enabled: bool
    pre_derive_enabled: bool
    max_spikes: SpikeMaxAttempts
    executor_timeout_s: int = Field(..., ge=1)
    evaluator_timeout_s: int = Field(..., ge=1)
    grounding_extractor: GroundingExtractorConfig
    per_story_enabled: bool
    per_story_timeout_s: int = Field(..., ge=1)
    per_story_skip_on_rigor: list[str] = Field(default_factory=list)


class LivenessConfig(ObraBaseModel):
    """``orchestration.timeouts.liveness``."""

    check_interval_s: int = Field(..., ge=1)
    min_alive_indicators: int = Field(..., ge=1)
    base_timeout_s: int = Field(..., ge=1)
    extended_timeout_s: int = Field(..., ge=1)
    cpu_delta_threshold: float = Field(..., ge=0)
    log_silence_threshold_s: int = Field(..., ge=0)
    file_mtime_window_s: int = Field(..., ge=0)
    db_update_window_s: int = Field(..., ge=0)


class TimeoutsConfig(ObraBaseModel):
    """``orchestration.timeouts``."""

    default_s: int = Field(..., ge=1)
    llm_call_s: int = Field(..., ge=1)
    llm_request_s: int | None = Field(default=None, ge=1)
    agent_execution_s: int = Field(..., ge=1)
    review_agent_s: int = Field(..., ge=1)
    cli_runner_s: int = Field(..., ge=1)
    llm_stream_idle_s: int = Field(..., ge=0)
    liveness: LivenessConfig


class DecompositionConfig(ObraBaseModel):
    """``orchestration.decomposition``."""

    enabled: bool
    duration_threshold_s: int = Field(..., ge=1)
    failure_threshold: int = Field(..., ge=1)
    max_attempts: int = Field(..., ge=1)
    summary_max_chars: int = Field(..., ge=1)
    warning_threshold_ratio: float = Field(..., ge=0)
    warning_threshold_s: int | None = Field(default=None, ge=0)
    execute_stream_idle_s: int | None = Field(default=None, ge=0)


class ParallelConfig(ObraBaseModel):
    """``orchestration.parallel``."""

    worker_delay_s: float = Field(..., ge=0)
    provider_overrides: dict[str, float] = Field(default_factory=dict)


class BudgetMaxTurnsConfig(ObraBaseModel):
    """``orchestration.budgets.max_turns``."""

    enabled: bool


class BudgetsConfig(ObraBaseModel):
    """``orchestration.budgets``."""

    enabled: bool
    max_turns: BudgetMaxTurnsConfig


class WorkflowConfig(ObraBaseModel):
    """``orchestration.workflow``."""

    enabled: bool


class OrchestrationSubset(ObraBaseModel):
    """Typed subset of ``orchestration.*``."""

    policy_engine: PolicyEngineConfig
    spike_first: SpikeFirstConfig
    timeouts: TimeoutsConfig
    decomposition: DecompositionConfig
    parallel: ParallelConfig
    budgets: BudgetsConfig
    workflow: WorkflowConfig


# =============================================================================
# Section: intent.*
# =============================================================================


class IntentContextLimits(ObraBaseModel):
    max_items: int = Field(..., ge=1)
    max_item_chars: int = Field(..., ge=1)
    max_chars: int = Field(..., ge=1)


class UserStoriesConfig(ObraBaseModel):
    enabled: bool
    timeout_s: int | None = Field(default=None, ge=1)
    max_stories: int = Field(..., ge=1)
    model_tier: str


class IntentChunkingConfig(ObraBaseModel):
    size_tokens: int = Field(..., ge=1)
    overlap_tokens: int = Field(..., ge=0)
    warning_threshold: float = Field(..., ge=0)


class IntentRateLimitConfig(ObraBaseModel):
    max_retries: int = Field(..., ge=0)
    backoff_delays_s: list[float] = Field(default_factory=list)


class DetectionConfig(ObraBaseModel):
    rich_min_words: int = Field(..., ge=0)
    min_keyword_matches: int = Field(..., ge=0)
    min_detail_markers: int = Field(..., ge=0)


class TemplatesConfig(ObraBaseModel):
    summary_preview_length: int = Field(..., ge=1)


class ThresholdsConfig(ObraBaseModel):
    detection_empty: float = Field(..., ge=0)
    detection_existing: float = Field(..., ge=0)
    interrogative_ratio: float = Field(..., ge=0)
    token_warning: float = Field(..., ge=0)


class IntentConfig(ObraBaseModel):
    """``intent``."""

    token_budget: int = Field(..., ge=1)
    slug_max_length: int = Field(..., ge=1)
    context: IntentContextLimits
    user_stories: UserStoriesConfig
    chunking: IntentChunkingConfig
    rate_limit: IntentRateLimitConfig
    detection: DetectionConfig
    templates: TemplatesConfig
    thresholds: ThresholdsConfig


# =============================================================================
# Section: execution.*
# =============================================================================


class ParallelExecutionConfig(ObraBaseModel):
    enabled: bool
    max_workers: int = Field(..., ge=1)


class QualityExecutionConfig(ObraBaseModel):
    default_threshold: float = Field(..., ge=0, le=1)
    generated_plan_threshold: float = Field(..., ge=0, le=1)


class MCPServerEntry(BaseModel):
    """``execution.mcp_servers.servers[]`` supports command- or URL-based entries."""

    model_config = ConfigDict(extra="allow")

    id: str
    command: str | None = None
    url: str | None = None
    args: list[str] | None = None
    env: dict[str, str] | None = None


class MCPServersConfig(ObraBaseModel):
    enabled: bool
    max_tools: int = Field(..., ge=0)
    servers: list[MCPServerEntry] = Field(default_factory=list)


class ExecutionConfig(ObraBaseModel):
    """``execution``."""

    parallel: ParallelExecutionConfig
    quality: QualityExecutionConfig
    mcp_servers: MCPServersConfig


# =============================================================================
# Section: review.*
# =============================================================================


class SenseCheckPlanConfig(ObraBaseModel):
    """``review.sense_check.pipeline.plan``."""

    enabled: bool
    timeout_s: int = Field(..., ge=1)
    model_tier: str
    auto_revise: bool
    auto_revise_threshold: str
    max_revision_attempts: int = Field(..., ge=1)


class ReviewSenseCheckIntentConfig(ObraBaseModel):
    enabled: bool
    model_tier: str
    timeout_s: int = Field(..., ge=1)


class ReviewSenseCheckReviewFilterConfig(ObraBaseModel):
    enabled: bool
    model_tier: str
    timeout_s: int = Field(..., ge=1)
    remove_false_positives: bool
    adjust_severity: bool


class ReviewSenseCheckFrameworkConfig(ObraBaseModel):
    enabled: bool
    conflict_policy: str
    decision_log: bool
    prompt_provenance: bool
    schema_validation: bool


class ReviewSenseCheckEnhancementConfig(ObraBaseModel):
    enabled: bool
    timeout_s: int = Field(..., ge=1)


class ReviewSenseCheckSequencerConfig(ObraBaseModel):
    enabled: bool
    mode: str
    model_tier: str
    timeout_s: int = Field(..., ge=1)
    fallback_to_rules: bool


class ReviewSenseCheckPipeline(ObraBaseModel):
    framework: ReviewSenseCheckFrameworkConfig
    intent: ReviewSenseCheckIntentConfig
    plan: SenseCheckPlanConfig
    review_filter: ReviewSenseCheckReviewFilterConfig


class ReviewSenseCheck(ObraBaseModel):
    enabled: bool
    enhancement: ReviewSenseCheckEnhancementConfig
    sequencer: ReviewSenseCheckSequencerConfig
    pipeline: ReviewSenseCheckPipeline


class ConvergenceConfig(ObraBaseModel):
    fresh_fix_enabled: bool
    stale_cycles_for_fresh_fix: int = Field(..., ge=0)
    stale_cycles_for_escalate: int = Field(..., ge=0)
    identity_overlap_threshold: float = Field(..., ge=0)
    max_template_failure_cycles: int = Field(..., ge=0)


class RevisionIntegrityConfig(ObraBaseModel):
    plan_shrinkage_warning_threshold: float = Field(..., ge=0)
    plan_shrinkage_block_threshold: float = Field(..., ge=0)


class BlockingPolicyConfig(ObraBaseModel):
    low_priority_strict: bool


class LoopExitPolicyConfig(ObraBaseModel):
    enabled: bool
    max_non_critical_review_cycles: int = Field(..., ge=0)
    require_no_new_critical: bool
    require_required_checks_pass: bool
    require_threshold_met: bool
    score_plateau_max_delta: float = Field(..., ge=0)
    score_plateau_min_review_cycles: int = Field(..., ge=0)
    unverifiable_accept_after_cycles: int = Field(..., ge=0)


class IntentContextConfig(ObraBaseModel):
    enabled: bool
    max_items: int = Field(..., ge=1)
    max_item_chars: int = Field(..., ge=1)
    max_chars: int = Field(..., ge=1)


class AgentsConfig(ObraBaseModel):
    parallel: bool
    max_workers: int = Field(..., ge=1)


class EscalationFixerConfig(ObraBaseModel):
    enabled: bool
    timeout_s: int = Field(..., ge=1)
    max_attempts_per_episode: int = Field(..., ge=1)
    allowed_routes: list[str] = Field(default_factory=list)
    eligible_reason_codes: list[str] = Field(default_factory=list)


class ReviewComplexitySimpleConfig(ObraBaseModel):
    max_words: int = Field(..., ge=0)
    max_files: int = Field(..., ge=0)
    max_lines: int = Field(..., ge=0)


class ReviewComplexityMediumConfig(ObraBaseModel):
    max_files: int = Field(..., ge=0)
    max_lines: int = Field(..., ge=0)


class ComplexityConfig(ObraBaseModel):
    simple: ReviewComplexitySimpleConfig
    medium: ReviewComplexityMediumConfig


class ReviewSubset(ObraBaseModel):
    """Typed static portion of ``review.*``.

    Deferred dynamic-key subsections:
    - ``review.feedback.flag_weights``
    - ``review.feedback.rating_adjustments``
    - ``review.sense_check.pipeline.framework.ordering``
    """

    default_quality_threshold: float = Field(..., ge=0, le=1)
    permissive_mode: bool
    convergence: ConvergenceConfig
    revision_integrity: RevisionIntegrityConfig
    blocking_policy: BlockingPolicyConfig
    loop_exit_policy: LoopExitPolicyConfig
    intent_context: IntentContextConfig
    agents: AgentsConfig
    escalation_fixer: EscalationFixerConfig
    complexity: ComplexityConfig
    sense_check: ReviewSenseCheck


# =============================================================================
# Section: refinement.*
# =============================================================================


class RefinementPlanningConfig(ObraBaseModel):
    enabled: bool
    max_iterations: int = Field(..., ge=1)


class RefinementConfig(ObraBaseModel):
    max_iterations: int = Field(..., ge=1)
    planning: RefinementPlanningConfig
    escalation_continue_iteration_reset: int | None = Field(default=None, ge=0)
    regression_threshold_multiplier: float | None = Field(default=None, ge=0)
    regression_min_delta: int | None = Field(default=None, ge=0)


# =============================================================================
# Section: derivation.*
# =============================================================================


class LightPlanBoundsConfig(ObraBaseModel):
    trivial_max_stories: int = Field(..., ge=1)
    trivial_max_tasks: int = Field(..., ge=1)
    simple_max_stories: int = Field(..., ge=1)
    simple_max_tasks: int = Field(..., ge=1)
    complex_max_stories: int = Field(..., ge=1)
    complex_max_tasks: int = Field(..., ge=1)


class DerivationPipelineConfig(ObraBaseModel):
    step_timeouts: dict[str, int] = Field(default_factory=dict)
    stall_warning_threshold: int = Field(..., ge=0)


class DerivationSerializeConfig(ObraBaseModel):
    max_concurrent: int = Field(..., ge=1)
    worker_delay_s: float = Field(..., ge=0)


class DerivationStepsConfig(ObraBaseModel):
    step1_tier: str
    step2_tier: str
    step3_tier: str


class DerivationEpicConfig(ObraBaseModel):
    max_per_objective: int = Field(..., ge=1)


class DerivationStoryConfig(ObraBaseModel):
    closeout_min_rigor: str
    closeout_min_size: str
    forbid_compound_titles: bool
    max_per_epic: int = Field(..., ge=1)
    max_tasks: int = Field(..., ge=1)
    require_closeout: bool


class DerivationTaskHierarchyConfig(ObraBaseModel):
    forbid_compound_titles: bool
    max_acceptance_criteria: int = Field(..., ge=0)
    max_description_words: int = Field(..., ge=0)
    max_files: int = Field(..., ge=0)
    max_loc: int = Field(..., ge=0)
    max_words: int = Field(..., ge=0)


class DerivationSubtaskConfig(DerivationTaskHierarchyConfig):
    max_per_task: int = Field(..., ge=1)


class DerivationTaskStructureConfig(DerivationTaskHierarchyConfig):
    pass


class HierarchyValidationConfig(ObraBaseModel):
    block_on_fail: bool
    max_passes: int = Field(..., ge=0)


class HierarchyConfig(ObraBaseModel):
    enabled: bool
    max_depth: int = Field(..., ge=1)
    epic: DerivationEpicConfig
    story: DerivationStoryConfig
    task: DerivationTaskStructureConfig
    subtask: DerivationSubtaskConfig
    validation: HierarchyValidationConfig


class ReviewGateConfig(ObraBaseModel):
    strict: bool


class PlanValidationAutoFixConfig(ObraBaseModel):
    enabled: bool
    level: str
    log_details: bool
    max_attempts: int = Field(..., ge=0)


class PlanValidationConfig(ObraBaseModel):
    enabled: bool
    use_pydantic: bool
    auto_fix: PlanValidationAutoFixConfig


class PreviewConfig(ObraBaseModel):
    raw_response_limit: int = Field(..., ge=1)
    raw_response_warn_limit: int = Field(..., ge=1)
    readme_limit: int = Field(..., ge=1)


class AutoDecomposeConfig(ObraBaseModel):
    failure_threshold: int = Field(..., ge=1)
    max_depth: int = Field(..., ge=1)


class DerivationBudgetConfig(ObraBaseModel):
    decompose_threshold: float = Field(..., ge=0)
    warning_threshold: float = Field(..., ge=0)
    min_subtask_ratio: float = Field(..., ge=0)


class DerivationTaskConfig(ObraBaseModel):
    token_budget: int = Field(..., ge=1)
    cost_budget_usd: float = Field(..., ge=0)


class DerivationWorkflowValidationConfig(ObraBaseModel):
    require_compile_ready_w2: bool
    require_operator_review_for_inferred_inputs: bool


class DerivationWorkflowOperatorReviewConfig(ObraBaseModel):
    max_pending_points: int = Field(..., ge=1)


class DerivationWorkflowConfig(ObraBaseModel):
    enabled: bool
    validation: DerivationWorkflowValidationConfig
    operator_review: DerivationWorkflowOperatorReviewConfig


class DerivationConfig(ObraBaseModel):
    """Typed static portion of ``derivation.*``.

    Deferred dynamic-key subsections:
    - ``derivation.sizing.guidance``
    - ``derivation.sizing.routing.policies``
    - ``derivation.workflow.llm``
    """

    agent: str
    max_depth: int = Field(..., ge=1)
    approval_required: bool
    auto_derive_on_execute: bool
    story_range: str
    task_range: str
    strict_story_range: str
    strict_task_range: str
    epic_output_token_limit: int = Field(..., ge=1)
    epic_item_rederive_threshold: int = Field(..., ge=1)
    exploration_lookback_minutes: int = Field(..., ge=0)
    max_depth_warning_threshold: float = Field(..., ge=0)
    light_plan_bounds: LightPlanBoundsConfig
    pipeline: DerivationPipelineConfig
    serialize: DerivationSerializeConfig
    steps: DerivationStepsConfig
    hierarchy: HierarchyConfig
    review_gate: ReviewGateConfig
    plan_validation: PlanValidationConfig
    preview: PreviewConfig
    auto_decompose: AutoDecomposeConfig
    budget: DerivationBudgetConfig
    task: DerivationTaskConfig
    workflow: DerivationWorkflowConfig


# =============================================================================
# Top-level container / loader integration
# =============================================================================


class ObraTypedConfig(ObraBaseModel):
    """Top-level typed view over the migrated YAML sections."""

    orchestration: OrchestrationSubset
    intent: IntentConfig
    execution: ExecutionConfig
    review: ReviewSubset
    derivation: DerivationConfig
    refinement: RefinementConfig

    @field_validator(
        "orchestration",
        "intent",
        "execution",
        "review",
        "derivation",
        "refinement",
        mode="before",
    )
    @classmethod
    def _reject_none(cls, value: Any) -> Any:
        if value is None:
            raise ValueError("config section is required and cannot be null")
        return value


def _load_layered_dict() -> dict[str, Any]:
    """Load the layered YAML config as a plain dict."""
    from obra.config.loaders._loading import load_layered_config

    raw, _, _ = load_layered_config(include_defaults=True)
    return raw


def load_typed_config() -> ObraTypedConfig:
    """Load and cache the typed config view."""
    return _load_typed_config_cached()


@lru_cache(maxsize=1)
def _load_typed_config_cached() -> ObraTypedConfig:
    return ObraTypedConfig.model_validate(_load_layered_dict())


def reset_typed_config_cache() -> None:
    """Reset the cached typed config for tests."""
    _load_typed_config_cached.cache_clear()


# =============================================================================
# Preferred section accessors
# =============================================================================


def get_policy_engine() -> PolicyEngineConfig:
    return load_typed_config().orchestration.policy_engine


def get_spike_first() -> SpikeFirstConfig:
    return load_typed_config().orchestration.spike_first


def get_timeouts() -> TimeoutsConfig:
    return load_typed_config().orchestration.timeouts


def get_decomposition() -> DecompositionConfig:
    return load_typed_config().orchestration.decomposition


def get_parallel() -> ParallelConfig:
    return load_typed_config().orchestration.parallel


def get_budgets() -> BudgetsConfig:
    return load_typed_config().orchestration.budgets


def get_workflow() -> WorkflowConfig:
    return load_typed_config().orchestration.workflow


def get_intent() -> IntentConfig:
    return load_typed_config().intent


def get_execution() -> ExecutionConfig:
    return load_typed_config().execution


def get_sense_check_plan() -> SenseCheckPlanConfig:
    return load_typed_config().review.sense_check.pipeline.plan


def get_review() -> ReviewSubset:
    return load_typed_config().review


def get_review_convergence() -> ConvergenceConfig:
    return load_typed_config().review.convergence


def get_review_revision_integrity() -> RevisionIntegrityConfig:
    return load_typed_config().review.revision_integrity


def get_review_escalation_fixer() -> EscalationFixerConfig:
    return load_typed_config().review.escalation_fixer


def get_derivation() -> DerivationConfig:
    return load_typed_config().derivation


def get_derivation_hierarchy() -> HierarchyConfig:
    return load_typed_config().derivation.hierarchy


def get_refinement() -> RefinementConfig:
    return load_typed_config().refinement


__all__ = [
    "AgentsConfig",
    "AutoDecomposeConfig",
    "BlockingPolicyConfig",
    "BudgetMaxTurnsConfig",
    "BudgetsConfig",
    "ComplexityConfig",
    "ConvergenceConfig",
    "DecompositionConfig",
    "DerivationBudgetConfig",
    "DerivationConfig",
    "DerivationEpicConfig",
    "DerivationPipelineConfig",
    "DerivationSerializeConfig",
    "DerivationStepsConfig",
    "DerivationStoryConfig",
    "DerivationSubtaskConfig",
    "DerivationTaskConfig",
    "DerivationTaskHierarchyConfig",
    "DerivationTaskStructureConfig",
    "DerivationWorkflowConfig",
    "EscalationFixerConfig",
    "ExecutionConfig",
    "HierarchyConfig",
    "HierarchyValidationConfig",
    "IntentChunkingConfig",
    "IntentConfig",
    "IntentContextConfig",
    "IntentContextLimits",
    "IntentRateLimitConfig",
    "LightPlanBoundsConfig",
    "LivenessConfig",
    "LoopExitPolicyConfig",
    "MCPServerEntry",
    "MCPServersConfig",
    "ObraTypedConfig",
    "OrchestrationSubset",
    "ParallelConfig",
    "ParallelExecutionConfig",
    "PlanValidationAutoFixConfig",
    "PlanValidationConfig",
    "PolicyEngineConfig",
    "PreviewConfig",
    "QualityExecutionConfig",
    "RefinementConfig",
    "RefinementPlanningConfig",
    "ReviewComplexityMediumConfig",
    "ReviewComplexitySimpleConfig",
    "ReviewGateConfig",
    "ReviewSenseCheck",
    "ReviewSenseCheckEnhancementConfig",
    "ReviewSenseCheckFrameworkConfig",
    "ReviewSenseCheckIntentConfig",
    "ReviewSenseCheckPipeline",
    "ReviewSenseCheckReviewFilterConfig",
    "ReviewSenseCheckSequencerConfig",
    "ReviewSubset",
    "RevisionIntegrityConfig",
    "SenseCheckPlanConfig",
    "SpikeFirstConfig",
    "SpikeMaxAttempts",
    "TemplatesConfig",
    "ThresholdsConfig",
    "TimeoutsConfig",
    "UserStoriesConfig",
    "WorkflowConfig",
    "get_budgets",
    "get_decomposition",
    "get_derivation",
    "get_derivation_hierarchy",
    "get_execution",
    "get_intent",
    "get_parallel",
    "get_policy_engine",
    "get_refinement",
    "get_review",
    "get_review_convergence",
    "get_review_escalation_fixer",
    "get_review_revision_integrity",
    "get_sense_check_plan",
    "get_spike_first",
    "get_timeouts",
    "get_workflow",
    "load_typed_config",
    "reset_typed_config_cache",
]
