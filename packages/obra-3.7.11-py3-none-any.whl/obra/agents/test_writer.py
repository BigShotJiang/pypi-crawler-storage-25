"""Requirements-driven acceptance-test writer agent."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.agents.registry import register_agent
from obra.api.protocol import AgentType, Priority
from obra.domains.capabilities import Capability
from obra.hybrid.pipeline_factories import build_enrichment_pipeline
from obra.hybrid.two_step_pipeline import run_reasoning_then_json
from obra.prompts.testing import (
    build_requirements_tests_json_prompt,
    build_requirements_tests_prompt,
)
from obra.testing import BrownfieldTestIndex, GeneratedTest, TestManifest

logger = logging.getLogger(__name__)


@register_agent(AgentType.TEST_WRITER, capabilities=[Capability.TEST_GENERATION])
class TestWriterAgent(BaseAgent):
    """Generate failing acceptance tests when test generation is supported."""

    agent_type = AgentType.TEST_WRITER

    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Generate failing acceptance tests for a plan item.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches the plan item id
                or objective routed into the test-writer agent.
            changed_files: If provided, MUST be a list of repository-relative paths
                used as advisory project context for test generation.
            timeout_ms: If None, uses the config-based agent timeout. If provided,
                MUST be a positive integer.

        Args:
            item_id: Plan item or objective identifier to generate tests for.
            changed_files: Optional changed-file hints for repository context.
            timeout_ms: Optional maximum execution time in milliseconds.

        Returns:
            AgentResult summarizing generated failing acceptance tests.
        """
        timeout_ms = self._resolve_timeout_ms(timeout_ms)
        self._validate_analyze_params(item_id, timeout_ms)
        manifest = self.generate_tests(
            objective=item_id,
            project_context={"changed_files": changed_files or []},
        )
        issue = AgentIssue(
            id=f"{item_id}:generated_tests",
            title="Generated failing acceptance tests",
            description=manifest.generation_summary or "Generated failing acceptance tests.",
            file_path=manifest.file_paths[0] if manifest.file_paths else "",
            line_number=0,
            priority=Priority.P2,
            category="test_generation",
        )
        return AgentResult(
            agent_type=self.agent_type,
            status="complete",
            issues=[issue] if manifest.tests else [],
            scores={"test_generation": 1.0 if manifest.tests else 0.0},
            execution_time_ms=0,
            metadata={"generated_tests": len(manifest.tests)},
        )

    def generate_tests(
        self,
        *,
        objective: str,
        project_context: dict[str, Any],
        intent_context: dict[str, Any] | None = None,
        brownfield_index: BrownfieldTestIndex | None = None,
    ) -> TestManifest:
        """Generate, write, and validate failing acceptance tests."""
        if self._domain is not None and not self._domain.supports(Capability.TEST_GENERATION):
            msg = (
                f"Domain {getattr(self._domain, 'name', '<unknown>')!r} does not "
                "support requirements-driven test generation"
            )
            raise RuntimeError(msg)

        if not self._llm_config:
            logger.warning("TestWriterAgent invoked without llm_config; returning empty manifest")
            return TestManifest(
                generation_summary="Test generation skipped because no llm_config was provided.",
            )

        index = brownfield_index or BrownfieldTestIndex.build(self.working_dir)

        prompt = build_requirements_tests_prompt(
            objective=objective,
            project_context=project_context,
            brownfield_index=index.summary(),
            intent_context=intent_context,
        )
        template = {
            "generation_summary": "",
            "tests": [],
            "_instructions": (
                "Fill tests with repository-relative failing acceptance tests. "
                "Each test object must include file_path, content, rationale, framework, and test_names."
            ),
        }

        def validator(data: dict[str, Any]) -> tuple[bool, str | None]:
            tests = data.get("tests", [])
            if not isinstance(tests, list):
                return False, "tests must be a list"
            for entry in tests:
                if not isinstance(entry, dict):
                    return False, "each generated test must be an object"
                if not str(entry.get("file_path", "")).strip():
                    return False, "generated tests require file_path"
                if not str(entry.get("content", "")):
                    return False, "generated tests require content"
            return True, None

        result_data, _metadata = run_reasoning_then_json(
            working_dir=self.working_dir,
            action_name="requirements_test_generation",
            reasoning_prompt=prompt,
            json_prompt_builder=build_requirements_tests_json_prompt,
            template_content=template,
            validator=validator,
            fallback_fn=lambda: {"generation_summary": "", "tests": []},
            llm_config=self._llm_config,
            pipeline_builder=build_enrichment_pipeline,
            pipeline_builder_kwargs={"log_event": self._log_event},
            call_site="requirements_test_generation",
        )

        generated = [
            GeneratedTest.from_dict(entry)
            for entry in result_data.get("tests", [])
            if isinstance(entry, dict)
        ]
        written_tests = self._write_and_validate_tests(generated)
        return TestManifest(
            tests=written_tests,
            generation_summary=str(result_data.get("generation_summary", "")).strip(),
            brownfield_index_summary=index.summary(),
        )

    def _write_and_validate_tests(
        self,
        generated_tests: list[GeneratedTest],
    ) -> list[GeneratedTest]:
        """Persist generated tests and drop invalid syntax when feasible."""
        written: list[GeneratedTest] = []
        for generated in generated_tests:
            normalized_path = generated.file_path.strip().lstrip("/")
            if not normalized_path:
                continue
            destination = (self.working_dir / normalized_path).resolve()
            try:
                destination.relative_to(self.working_dir.resolve())
            except ValueError:
                logger.warning("Skipping generated test outside working dir: %s", generated.file_path)
                continue

            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(generated.content, encoding="utf-8")
            if not self._syntax_is_valid(destination, generated.content):
                destination.unlink(missing_ok=True)
                logger.warning("Skipping generated test with invalid syntax: %s", generated.file_path)
                continue

            written.append(
                GeneratedTest(
                    file_path=str(destination.relative_to(self.working_dir)),
                    content=generated.content,
                    rationale=generated.rationale,
                    framework=generated.framework,
                    test_names=list(generated.test_names),
                )
            )
        return written

    @staticmethod
    def _syntax_is_valid(path: Path, content: str) -> bool:
        if path.suffix == ".py":
            try:
                compile(content, str(path), "exec")
            except SyntaxError:
                return False
        return True
