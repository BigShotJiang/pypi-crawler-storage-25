"""Base class and types for review agents.

This module defines the BaseAgent abstract class that all review agents
must implement. AgentIssue and AgentResult are re-exported from
obra.agents.types for backward compatibility.

Agent Architecture:
    - Agents are lightweight, stateless workers
    - Each agent runs as a subprocess for isolation
    - Agents analyze code and return structured results
    - Results include issues (with priority) and dimension scores

Related:
    - obra/agents/deployer.py
    - obra/api/protocol.py
"""

import logging
import time
from abc import ABC, abstractmethod
from collections.abc import Callable
from pathlib import Path
from typing import Any, cast

from obra.agents.escalation_detector import EscalationDetector
from obra.agents.file_scanner import FileScanner
from obra.agents.response_parser import AgentResponseParser
from obra.agents.types import AgentIssue, AgentResult
from obra.api.protocol import AgentType, Priority
from obra.config import get_review_agent_timeout
from obra.exceptions import ErrorContext, ExecutionError
from obra.llm.content_chunker import ContentChunker
from obra.llm.subprocess_config import resolve_skip_git_check_for_provider
from obra.review.quality_tiers import IssueCountTier

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """Abstract base class for review agents.

    All review agents must implement this interface. Agents analyze code
    in a workspace and return structured results with issues and scores.

    Implementing a new agent:
        1. Subclass BaseAgent
        2. Implement analyze() method
        3. Register with AgentRegistry
        4. Add to obra/agents/__init__.py

    See also:
        docs/guides/parameter-validation-guide.md - Parameter validation patterns (ADR-042)

    Example:
        >>> class MyAgent(BaseAgent):
        ...     agent_type = AgentType.SECURITY
        ...
        ...     def analyze(self, item_id, changed_files, timeout_ms):
        ...         issues = self._check_for_issues(changed_files)
        ...         scores = self._calculate_scores(changed_files)
        ...         return AgentResult(
        ...             agent_type=self.agent_type,
        ...             status="complete",
        ...             issues=issues,
        ...             scores=scores
        ...         )
    """

    # Subclasses must set this
    agent_type: AgentType

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        domain: Any = None,
    ) -> None:
        """Initialize agent.

        Args:
            working_dir: Working directory containing code to analyze
            llm_config: Optional LLM configuration dict for CLI-based analysis.
                       If None, agent returns empty results (no analysis performed).
            log_event: Optional callback for event logging (observability)
            domain: Optional domain module for prompt/filter specialization
        """
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._log_event = log_event
        self._domain = domain
        self._intent_context: str | None = None
        self._scanner = FileScanner(working_dir, domain)
        self._parser = AgentResponseParser()
        self._escalation = EscalationDetector()
        # Backward-compatible attribute delegation for tests that access internals
        self._composed_ignore_dirs = self._scanner._composed_ignore_dirs
        self._composed_ignore_dir_suffixes = self._scanner._composed_ignore_dir_suffixes
        self._composed_binary_extensions = self._scanner._composed_binary_extensions
        self._composed_excluded_files = self._scanner._composed_excluded_files
        self._composed_excluded_patterns = self._scanner._composed_excluded_patterns
        logger.debug(f"Initialized {self.__class__.__name__} for {working_dir}")

    def _is_ignored_path(self, path: Path) -> bool:
        """Delegate to FileScanner."""
        return self._scanner._is_ignored_path(path)

    @property
    def working_dir(self) -> Path:
        """Get working directory."""
        return self._working_dir

    def set_intent_context(self, intent_context: str | None) -> None:
        """Set intent context for prompt injection."""
        normalized = str(intent_context or "").strip()
        self._intent_context = normalized or None

    def _inject_intent_context(self, prompt: str) -> str:
        """Prepend intent context when available."""
        if not self._intent_context:
            return prompt
        return f"{self._intent_context}\n\n{prompt}"

    @staticmethod
    def _compact_error_message(error_message: str) -> str:
        """Collapse multi-line CLI/provider errors into one actionable line."""
        normalized = str(error_message or "").strip()
        if not normalized:
            return "Unknown error"

        lines = [line.strip() for line in normalized.splitlines() if line.strip()]
        if not lines:
            return "Unknown error"

        ignored_exact = {"--------", "task interrupted", "exec"}
        ignored_prefixes = (
            "tokens used",
            "workdir:",
            "model:",
            "provider:",
            "approval:",
            "sandbox:",
            "reasoning effort:",
            "reasoning summaries:",
            "session id:",
            "user",
        )
        error_markers = (
            "error",
            "failed",
            "failure",
            "timed out",
            "timeout",
            "invalid",
            "denied",
            "rejected",
            "blocked",
            "not found",
            "exception",
        )

        candidates: list[str] = []
        for line in lines:
            lower = line.lower()
            if lower in ignored_exact:
                continue
            if "failure_class=" in lower:
                continue
            if any(lower.startswith(prefix) for prefix in ignored_prefixes):
                continue
            candidates.append(line)

        if not candidates:
            return lines[-1]

        for line in reversed(candidates):
            lower = line.lower()
            if any(marker in lower for marker in error_markers):
                return line

        return candidates[-1]

    def _invoke_cli(
        self,
        call_site: str,
        prompt: str,
        timeout_ms: int | None = None,
    ) -> str:
        """Invoke LLM via CLI subprocess for analysis.

        Uses the shared subprocess runner module for consistent behavior
        with execute/fix handlers.

        Args:
            call_site: Identifier for where the LLM is being called from
                      (e.g., "security_tier1", "testing_analysis")
            prompt: The prompt to send to the LLM
            timeout_ms: Maximum execution time in milliseconds (None = use config default)

        Returns:
            Response text from the LLM (unwrapped from JSON if applicable)
        """
        from obra.llm import (
            LLMSubprocessConfig,
            LLMSubprocessResult,
            run_llm_subprocess,
        )

        if not self._llm_config:
            logger.warning(f"{call_site}: No LLM config available, returning empty response")
            return ""

        # Resolve timeout (convert ms to seconds for subprocess)
        timeout_s = (timeout_ms or (get_review_agent_timeout() * 1000)) / 1000

        # Inject intent context into prompt
        prepared_prompt = self._inject_intent_context(prompt)

        # Get provider config
        provider = self._llm_config.get("provider", "anthropic")
        model = self._llm_config.get("model", "default")
        reasoning_level = self._llm_config.get("reasoning_level", "medium")
        auth_method = self._llm_config.get("auth_method", "oauth")

        # Resolve skip_git_check: default to True for Codex-backed providers
        git_config = self._llm_config.get("git", {})
        skip_git_check = resolve_skip_git_check_for_provider(provider, git_config)
        codex_config = cast(dict, self._llm_config.get("codex", {}))
        bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
        approval_mode = codex_config.get("approval_mode")

        # Use trace_id if available (set by deployer), otherwise let subprocess_runner generate UUID
        run_id = getattr(self, "_trace_id", None)

        # Build config for subprocess runner
        config = LLMSubprocessConfig(
            prompt=prepared_prompt,
            cwd=self._working_dir,
            provider=provider,
            model=model,
            reasoning_level=reasoning_level,
            mode="text",  # Review agents: inference-only, no file writes
            auth_method=auth_method,
            timeout_s=int(timeout_s),
            skip_git_check=skip_git_check,
            bypass_sandbox=bypass_sandbox,
            approval_mode=approval_mode,
            streaming=False,  # Review agents don't stream
            log_event=self._log_event,
            call_site=call_site,
            run_id=run_id,
        )

        # Execute via shared subprocess runner
        result: LLMSubprocessResult = run_llm_subprocess(config)

        if not result.success:
            raw_error_message = result.error or "Unknown error"
            error_message = self._compact_error_message(raw_error_message)
            if result.failure_class and "failure_class=" not in error_message:
                error_message = f"{error_message} (failure_class={result.failure_class})"
            if result.error_details and result.error_details.request_id:
                if "request_id=" not in error_message:
                    error_message = (
                        f"{error_message} (request_id={result.error_details.request_id})"
                    )
            if result.retry_count and "retries=" not in error_message:
                error_message = f"{error_message} (retries={result.retry_count})"
            error_context = ErrorContext(
                request_id=(result.error_details.request_id if result.error_details else None),
                retry_count=result.retry_count,
            )
            logger.error(f"{call_site}: LLM subprocess failed: {error_message}")
            if logger.isEnabledFor(logging.DEBUG) and raw_error_message != error_message:
                logger.debug(
                    "%s: LLM subprocess raw error detail: %s",
                    call_site,
                    raw_error_message,
                )
            # ISSUE-HYBRID-045: llm_call event is emitted by subprocess_runner
            # (authoritative source with full field coverage). No duplicate
            # emission needed here.
            raise ExecutionError(
                error_message,
                exit_code=result.returncode,
                stderr=raw_error_message,
                error_context=error_context,
            )

        response_text: str = result.output.strip()

        # ISSUE-HYBRID-045: llm_call event is emitted by subprocess_runner
        # (authoritative source with full field coverage). Duplicate emission
        # removed to prevent paired events in telemetry.

        return response_text

    def _validate_analyze_params(
        self,
        item_id: str,
        timeout_ms: int,
    ) -> None:
        """Validate analyze() parameters (ADR-042 Contract 3).

        Agent implementations SHOULD call this at the start of their
        analyze() method to ensure parameter contracts are enforced.

        Args:
            item_id: Plan item ID to validate
            timeout_ms: Timeout value to validate

        Raises:
            ValueError: If item_id is empty or timeout_ms is invalid
        """
        if not item_id or not item_id.strip():
            msg = "item_id must be non-empty string"
            raise ValueError(msg)

        if timeout_ms <= 0:
            msg = f"timeout_ms must be positive, got {timeout_ms}"
            raise ValueError(msg)

    def _resolve_timeout_ms(self, timeout_ms: int | None) -> int:
        """Resolve timeout_ms to a concrete value.

        Uses config-based timeout from get_review_agent_timeout() if None provided.

        Args:
            timeout_ms: Explicit timeout in milliseconds, or None to use config default

        Returns:
            Timeout in milliseconds (config default converted from seconds if None was passed)
        """
        if timeout_ms is None:
            timeout_seconds = int(get_review_agent_timeout())
            return timeout_seconds * 1000
        return timeout_ms

    @abstractmethod
    def analyze(
        self,
        item_id: str,
        changed_files: list[str] | None = None,
        timeout_ms: int | None = None,
    ) -> AgentResult:
        """Analyze code and return results.

        This is the main entry point for agent execution. Agents should
        analyze the code in working_dir and return issues and scores.

        Parameter Contracts (ADR-042):
            item_id: MUST be non-empty string. Typically matches [A-Z]+-[0-9]+ format.
            changed_files: If None, analyzes all files in working_dir.
                          If empty list, returns empty result.
                          If non-empty, only analyzes specified files.
                          Files are passed to get_files_to_analyze() which respects
                          agent-specific extensions filtering.
            timeout_ms: If None, uses config-based timeout via get_review_agent_timeout().
                       If provided, MUST be positive integer. Typical range: [5000-300000].
                       Applies to entire analysis, not per-file.

        Parameter Interactions:
            - changed_files paths are resolved relative to working_dir
            - Extensions filtering (agent-specific) applies to changed_files
            - timeout_ms enforced by agent implementation (may vary)
            - When timeout_ms is None, resolved via orchestration.timeouts.review_agent_s config

        Args:
            item_id: Plan item ID being reviewed
            changed_files: List of files that changed (optional, for focused review)
            timeout_ms: Maximum execution time in milliseconds (None = use config default)

        Returns:
            AgentResult with issues and scores

        Raises:
            ValueError: If item_id is empty or timeout_ms <= 0
            TimeoutError: If analysis exceeds timeout_ms
            Exception: If analysis fails
        """

    # adr-042-skip — contracts on FileScanner.get_files_to_analyze
    def get_files_to_analyze(
        self,
        changed_files: list[str] | None = None,
        extensions: list[str] | None = None,
        exclude_binary: bool = True,
    ) -> list[Path]:
        """Delegate to FileScanner."""
        return self._scanner.get_files_to_analyze(changed_files, extensions, exclude_binary)

    def read_file(self, path: Path) -> str:
        """Delegate to FileScanner."""
        return self._scanner.read_file(path)

    def _generate_issue_id(self, prefix: str, index: int) -> str:
        """Delegate to AgentResponseParser."""
        return self._parser._generate_issue_id(prefix, index)

    def _generate_stable_issue_id(self, prefix: str, issue: dict[str, Any]) -> str:
        """Delegate to AgentResponseParser."""
        return self._parser._generate_stable_issue_id(prefix, issue)

    # adr-042-skip — contracts on FileScanner.is_test_file
    def is_test_file(self, path: Path, patterns: list[str] | None = None) -> bool:
        """Delegate to FileScanner."""
        return self._scanner.is_test_file(path, patterns)

    def is_excluded_file(self, path: Path) -> bool:
        """Delegate to FileScanner."""
        return self._scanner.is_excluded_file(path)

    # adr-042-skip — contracts on AgentResponseParser.parse_structured_response
    def parse_structured_response(
        self,
        response: str,
        prefix: str = "ISSUE",
    ) -> list[AgentIssue]:
        """Delegate to AgentResponseParser."""
        return self._parser.parse_structured_response(response, prefix)

    # Backward-compatible class-level references to escalation constants
    ESCALATION_PATHS = EscalationDetector.ESCALATION_PATHS
    ESCALATION_KEYWORDS = EscalationDetector.ESCALATION_KEYWORDS

    def _needs_escalation(
        self,
        file_path: Path | str | None = None,
        content: str | None = None,
    ) -> bool:
        """Delegate to EscalationDetector."""
        return self._escalation.needs_escalation(file_path=file_path, content=content)

    # ------------------------------------------------------------------
    # Default implementations shared across agent subclasses
    # ------------------------------------------------------------------

    def _collect_files_for_analysis(
        self,
        files: list[Path],
        deadline: float,
    ) -> tuple[dict[str, str], dict[str, int | bool]]:
        """Collect file contents for analysis, filtering test/excluded/init files.

        Args:
            files: List of files to process
            deadline: Timeout deadline

        Returns:
            Tuple of (files_content dict, collection_stats dict)
        """
        files_content: dict[str, str] = {}
        stats: dict[str, int | bool] = {
            "excluded_count": 0,
            "test_file_count": 0,
            "init_file_count": 0,
            "read_fail_count": 0,
            "timeout_during_collection": False,
        }

        for file_path in files:
            if time.time() > deadline:
                logger.warning("%s timed out during file collection", self.__class__.__name__)
                stats["timeout_during_collection"] = True
                break

            if self.is_test_file(file_path):
                stats["test_file_count"] = int(stats["test_file_count"]) + 1
                continue
            if file_path.name == "__init__.py":
                stats["init_file_count"] = int(stats["init_file_count"]) + 1
                continue
            if self.is_excluded_file(file_path):
                stats["excluded_count"] = int(stats["excluded_count"]) + 1
                continue

            content = self.read_file(file_path)
            if content:
                try:
                    rel_path = str(file_path.relative_to(self._working_dir))
                except ValueError:
                    rel_path = str(file_path)
                files_content[rel_path] = content
            else:
                stats["read_fail_count"] = int(stats["read_fail_count"]) + 1

        return files_content, stats

    def _format_code_for_prompt(self, files_content: dict[str, str]) -> str:
        """Format file contents for LLM prompt.

        Args:
            files_content: Dict mapping file paths to contents

        Returns:
            Formatted string with file headers
        """
        # Get model from agent config for content chunking
        model = "sonnet"  # Default model
        provider = "anthropic"  # Default provider
        if self._llm_config:
            model = self._llm_config.get("model", model)
            provider = self._llm_config.get("provider", provider)
        chunker = ContentChunker(model=model, provider=provider)

        parts = []
        for file_path, content in files_content.items():
            # Limit content size to avoid token limits (model-aware)
            truncated = chunker.truncate(content)
            numbered = "\n".join(
                f"{line_no:>4}: {line}"
                for line_no, line in enumerate(truncated.splitlines(), start=1)
            )
            parts.append(f"=== FILE: {file_path} ===\n{numbered}")
        return "\n\n".join(parts)

    def _error_result(self, error: str, start_time: float) -> AgentResult:
        """Build an error result.

        Args:
            error: Error message
            start_time: Analysis start time

        Returns:
            AgentResult with error status
        """
        return AgentResult(
            agent_type=self.agent_type,
            status="error",
            error=error,
            execution_time_ms=int((time.time() - start_time) * 1000),
        )

    def _empty_files_result(
        self,
        files: list[Path],
        stats: dict[str, int | bool],
        extra_issues: list[AgentIssue],
        extra_score: float,
        start_time: float,
    ) -> AgentResult:
        """Build result when no files remain after filtering.

        Subclasses with agent-specific metadata or score dimensions should
        override this method.

        Args:
            files: Original file list
            stats: Collection statistics
            extra_issues: Additional issues from non-LLM checks (e.g. README)
            extra_score: Score from non-LLM checks
            start_time: Analysis start time

        Returns:
            AgentResult with appropriate status
        """
        has_extra_findings = len(extra_issues) > 0
        status = "complete" if has_extra_findings else "skipped"

        if not has_extra_findings:
            logger.warning(
                "%s: No analyzable files and no extra findings. "
                "working_dir=%s, files_scanned=%d, test_files=%s, init_files=%s, "
                "excluded=%s, read_failed=%s, timeout=%s",
                self.__class__.__name__,
                self._working_dir,
                len(files),
                stats.get("test_file_count", 0),
                stats.get("init_file_count", 0),
                stats.get("excluded_count", 0),
                stats.get("read_fail_count", 0),
                stats.get("timeout_during_collection", False),
            )
        else:
            logger.info(
                "%s: No files for LLM analysis, but extra checks found %d issues.",
                self.__class__.__name__,
                len(extra_issues),
            )

        skip_metadata: dict[str, Any] = {
            "files_analyzed": 0,
            "mode": "llm",
            "skip_reason": "no_files_after_filter",
            "extra_findings": len(extra_issues),
            "working_dir": str(self._working_dir),
            "files_scanned": len(files),
            "files_test": stats.get("test_file_count", 0),
            "files_init": stats.get("init_file_count", 0),
            "files_excluded": stats.get("excluded_count", 0),
            "files_read_failed": stats.get("read_fail_count", 0),
            "timeout_during_collection": stats.get("timeout_during_collection", False),
        }

        return AgentResult(
            agent_type=self.agent_type,
            status=status,
            issues=extra_issues,
            scores={},
            execution_time_ms=int((time.time() - start_time) * 1000),
            metadata=skip_metadata,
        )

    def _calculate_scores_from_issues(
        self,
        issues: list[AgentIssue],
    ) -> dict[str, float]:
        """Calculate dimension scores based on issues.

        The base implementation uses IssueCountTier to map issue counts to
        scores. Subclasses should override to provide agent-specific
        dimension mappings and scoring logic.

        Args:
            issues: All issues found

        Returns:
            Dict of dimension scores
        """
        dimension_counts: dict[str, int] = {}
        for issue in issues:
            dim = issue.dimension or "general"
            dimension_counts[dim] = dimension_counts.get(dim, 0) + 1

        return {
            dim: IssueCountTier.from_count(count).base_score
            for dim, count in dimension_counts.items()
        }


__all__ = [
    "AgentIssue",
    "AgentResult",
    "BaseAgent",
]
