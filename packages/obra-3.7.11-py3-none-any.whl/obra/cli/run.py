"""Run/derive lifecycle commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""

import logging
import os
import re
import sys
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

import click
import typer
import yaml  # type: ignore[import-untyped]

from obra.api.protocol import (
    ActionType,
    EscalationDecision,
    EscalationNotice,
    EscalationReason,
    UserDecisionChoice,
)
from obra.cli._shared import (
    _resolve_command_verbosity,
    require_terms_accepted,
    setup_logging,
)
from obra.cli.interrupt import (
    _manager as _interrupt_manager,
)
from obra.cli.interrupt import (
    _print_session_resume_hints,
)
from obra.cli.run_support.command_surface import (
    VALID_WORK_TYPES,
    prepare_derive_invocation,
    prepare_run_invocation,
)
from obra.cli.run_support.config_overrides import (
    build_override_dict,
    materialize_override_layer,
)
from obra.cli.run_support.escalation import (  # noqa: F401 - accessed as module attr
    _build_escalation_callback,
)
from obra.cli.run_support.heartbeat import (  # noqa: F401 - accessed as module attr
    _refresh_local_session_heartbeat,
)
from obra.cli.run_support.interaction_mode import (
    InteractionMode,
    resolve_interaction_mode,
    restore_current_mode,
    set_current_mode,
)
from obra.cli.run_support.planning_context import (  # noqa: F401 - accessed as module attr
    _install_imported_plan_handler,
)
from obra.cli.run_support.shared_options import (
    CommonRunOptions,
    OptAutoInitGit,
    OptAutoReport,
    OptContinueFrom,
    OptConfigOverride,
    OptDefaultsJson,
    OptDomain,
    OptExecutePipeline,
    OptFailOnP1,
    OptFailOnP2,
    OptFastModel,
    OptForceExplore,
    OptFullReview,
    OptHighModel,
    OptImplProvider,
    OptInteractive,
    OptIsolated,
    OptLocal,
    OptMosaic,
    OptModel,
    OptNoCloseout,
    OptNoCodeQuality,
    OptNoDocs,
    OptNoExtendedThinking,
    OptNoIsolated,
    OptNonInteractive,
    OptNoSecurity,
    OptNoTesting,
    OptObjective,
    OptOrchModel,
    OptOrchProvider,
    OptOrchReasoning,
    OptPermissive,
    OptPlanFile,
    OptPlanId,
    OptPlanOnly,
    OptReasoningLevel,
    OptResumeSession,
    OptReviewAgents,
    OptReviewFormat,
    OptReviewIntent,
    OptReviewQuiet,
    OptReviewSummaryOnly,
    OptReviewTimeout,
    OptSkipComplexityCheck,
    OptSkipExplore,
    OptSkipGitCheck,
    OptSkipIntent,
    OptSkipPlanQualityGate,
    OptSkipReview,
    OptSpikeFirst,
    OptNoSpikeFirst,
    OptPlanFirst,
    OptStream,
    OptVerbose,
    OptWithCodeQuality,
    OptWithDocs,
    OptWithSecurity,
    OptWithTesting,
    OptWorkingDir,
)
from obra.config import (
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    DEFAULT_REASONING_LEVEL,
    REASONING_LEVELS,
    infer_provider_from_model,
    load_config,
)
from obra.core.interrupts import (
    GracefulInterrupt,
    clear_interrupt_request,
    defer_interrupts,
)
from obra.display import (
    EscalationRenderer,
    ObservabilityConfig,
    ProgressEmitter,
    console,
    glyphs,
    handle_encoding_errors,
    print_banner,
    print_error,
    print_info,
    print_success,
    print_warning,
    set_runtime_verbosity,
)
from obra.display.closeout import (
    _log_closeout_rendered,
    _print_git_file_summary,
    build_closeout_message,
)
from obra.display.closeout_context import (
    _build_closeout_context,
    _build_interrupted_closeout_context,
    _extract_completion_context,
)
from obra.display.errors import display_error, display_obra_error
from obra.display.event_router import (
    _route_progress_event,
)
from obra.display.session_banner import (
    _format_environment_label,
    _format_git_status,
    _format_run_mode,
    _resolve_project_display,
    _summarize_config_layers,
)
from obra.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ObraError,
)
from obra.exceptions import (
    ConnectionError as ObraConnectionError,
)
from obra.feedback.session_logger import (
    rename_session_logging,
    start_session_logging,
    stop_session_logging,
)
from obra.messages import get_message
from obra.model_registry import resolve_quality_tier
from obra.review.config import ALLOWED_AGENTS
from obra.session.working_dir import (
    resolve_working_dir_selection as _resolve_working_dir_selection,
)

logger = logging.getLogger(__name__)


@contextmanager
def _apply_interaction_mode(mode: InteractionMode) -> Iterator[None]:
    """Apply the resolved interaction mode for one CLI invocation.

    Sets the module-level current mode and, for headless runs, forces the
    OBRA_HEADLESS / OBRA_UNATTENDED env vars so downstream code that still
    reads ambient state (e.g. is_headless()) stays consistent.
    """
    from obra.hybrid import interaction_mode as _interaction_mode

    previous_mode = _interaction_mode._current_mode
    previous_explicit = _interaction_mode._mode_explicitly_set
    set_current_mode(mode)

    if mode is InteractionMode.INTERACTIVE:
        try:
            yield
        finally:
            restore_current_mode(previous_mode, explicit=previous_explicit)
        return

    # Headless: set env vars for backward compatibility with code that
    # still reads ambient state.
    previous = {
        "OBRA_UNATTENDED": os.environ.get("OBRA_UNATTENDED"),
        "OBRA_HEADLESS": os.environ.get("OBRA_HEADLESS"),
    }
    os.environ["OBRA_UNATTENDED"] = "1"
    os.environ["OBRA_HEADLESS"] = "1"
    try:
        yield
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        restore_current_mode(previous_mode, explicit=previous_explicit)


@contextmanager
def _apply_config_override_layer(config_overrides: list[str] | None) -> Iterator[None]:
    """Materialize one temporary session-layer override for a CLI invocation."""
    if not config_overrides:
        yield
        return

    previous_session_config = os.environ.get("OBRA_SESSION_CONFIG")
    layer_path: Path | None = None
    try:
        override_payload = build_override_dict(list(config_overrides))
        layer_path = materialize_override_layer(override_payload)
        os.environ["OBRA_SESSION_CONFIG"] = str(layer_path)
        yield
    finally:
        if previous_session_config is None:
            os.environ.pop("OBRA_SESSION_CONFIG", None)
        else:
            os.environ["OBRA_SESSION_CONFIG"] = previous_session_config
        if layer_path is not None:
            layer_path.unlink(missing_ok=True)


@handle_encoding_errors
@require_terms_accepted
def run_objective(
    ctx: typer.Context,
    objective: OptObjective = None,
    working_dir: OptWorkingDir = None,
    domain: OptDomain = None,
    resume_session: OptResumeSession = None,
    continue_from: OptContinueFrom = None,
    resume_from: str | None = typer.Option(
        None,
        "--from",
        help=(
            "Resume from a specific phase: environment/env-setup (rerun setup), "
            "derivation/plan (skip environment setup validation), execution (resume execution)."
        ),
        show_choices=True,
        click_type=click.Choice(
            ["environment", "env-setup", "story-0", "derivation", "plan", "execution"],
            case_sensitive=False,
        ),
        rich_help_panel="Session",
    ),
    rerun_setup: bool = typer.Option(
        False,
        "--rerun-setup",
        help="Re-run environment setup (alias for --from environment)",
        rich_help_panel="Session",
    ),
    plan_id: OptPlanId = None,
    plan_file: OptPlanFile = None,
    orch_provider: OptOrchProvider = None,
    orch_model: OptOrchModel = None,
    orch_reasoning: OptOrchReasoning = None,
    mosaic: OptMosaic = None,
    model: OptModel = None,
    fast_model: OptFastModel = None,
    high_model: OptHighModel = None,
    impl_provider: OptImplProvider = None,
    reasoning_level: OptReasoningLevel = None,
    no_extended_thinking: OptNoExtendedThinking = False,
    verbose: OptVerbose = 0,
    progress_json: bool = typer.Option(
        False,
        "--progress-json",
        help="Emit progress events as JSON lines to stdout",
        rich_help_panel="Output",
    ),
    interactive: OptInteractive = False,
    non_interactive: OptNonInteractive = False,
    stream: OptStream = False,
    plan_only: OptPlanOnly = False,
    execute_pipeline: OptExecutePipeline = False,
    permissive: OptPermissive = False,
    defaults_json: OptDefaultsJson = False,
    config_override: OptConfigOverride = None,
    spike_first: OptSpikeFirst = False,
    no_spike_first: OptNoSpikeFirst = False,
    plan_first: OptPlanFirst = False,
    no_closeout: OptNoCloseout = False,
    skip_intent: OptSkipIntent = False,
    review_intent: OptReviewIntent = False,
    enrich: bool = typer.Option(
        False,
        "--enrich",
        help="Force intent enrichment (requires planning.enrichment.enabled)",
        rich_help_panel="Planning & Execution",
    ),
    no_enrich: bool = typer.Option(
        False,
        "--no-enrich",
        help="Skip intent enrichment even when enabled",
        rich_help_panel="Planning & Execution",
    ),
    isolated: OptIsolated = None,
    no_isolated: OptNoIsolated = None,
    full_review: OptFullReview = False,
    skip_review: OptSkipReview = False,
    review_agents: OptReviewAgents = None,
    with_security: OptWithSecurity = False,
    with_testing: OptWithTesting = False,
    with_docs: OptWithDocs = False,
    with_code_quality: OptWithCodeQuality = False,
    no_security: OptNoSecurity = False,
    no_testing: OptNoTesting = False,
    no_docs: OptNoDocs = False,
    no_code_quality: OptNoCodeQuality = False,
    review_format: OptReviewFormat = None,
    review_quiet: OptReviewQuiet = False,
    review_summary_only: OptReviewSummaryOnly = False,
    fail_on_p1: OptFailOnP1 = False,
    fail_on_p2: OptFailOnP2 = False,
    review_timeout: OptReviewTimeout = None,
    auto_report: OptAutoReport = False,
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Auto-approve prerequisite confirmation prompts (useful with --interactive)",
        rich_help_panel="Advanced",
    ),
    mock_credentials: bool = typer.Option(
        False,
        "--mock-credentials",
        help="Automatically mock all required credentials",
        rich_help_panel="Advanced",
    ),
    skip_env_setup: bool = typer.Option(
        False,
        "--skip-env-setup",
        help="Make all environment-setup prerequisite failures non-blocking (for benchmarking or repos with known missing deps)",
        rich_help_panel="Advanced",
    ),
    skip_git_check: OptSkipGitCheck = False,
    auto_init_git: OptAutoInitGit = False,
    skip_plan_quality_gate: OptSkipPlanQualityGate = False,
    skip_complexity_check: OptSkipComplexityCheck = False,
    parallel: bool = typer.Option(
        False,
        "--parallel",
        help="Enable parallel execution of independent plan items (uses parallel_group assignments)",
        rich_help_panel="Planning & Execution",
    ),
    skip_tier_check: bool = typer.Option(
        False,
        "--skip-tier-check",
        help="Skip server tier mismatch validation (proceed despite client/server tier disagreement)",
        rich_help_panel="Advanced",
    ),
    skip_explore: OptSkipExplore = False,
    force_explore: OptForceExplore = False,
    plan_mode: str | None = typer.Option(
        None,
        "--plan-mode",
        help=(
            "Rigor override: auto (default), light, balanced, or thorough. "
            "Compatibility aliases: quick=light, standard=balanced"
        ),
        rich_help_panel="Planning & Execution",
    ),
    local: OptLocal = False,
) -> None:
    """Run AI-orchestrated workflow for an objective.

    LLM fast path:
        1. obra models        # Discover provider/model names
        2. obra help domains  # Discover installed domains
        3. obra help run      # Review flags
        4. obra run --domain <domain> "objective"

    Examples:
        obra run "Add user authentication"
        obra run "Fix the failing tests" --dir /my/project
        obra run "Refactor payment module" --stream -vv
        obra run --domain software "Implement feature X" --model opus
        obra run --domain business "Review invoice workflow" --model gemini-2.5-flash
        obra run "Improve tests" --impl-provider openai --model gpt-5.2
        obra run "Mosaic routing" --mosaic claude-sonnet-4-6:claude-3-5-haiku
        obra run "Split routing" --orch-model claude-sonnet-4-6 --model claude-3-5-haiku
        obra run "Complex refactor" --reasoning-level high
        obra run --plan-only "Design API endpoints"
        obra run "Test feature" --isolated  # Isolated session
        obra run --interactive "Interactive run"  # Opt in to stdin prompts (default is headless)
        obra run --continue-from abc123  # Continue from failed session
        obra run --resume abc123 --from story-0  # Re-run environment setup, then resume
        obra run "Quick fix" --no-extended-thinking  # Disable extended thinking
        obra run "Multi-task feature" --parallel  # Enable parallel execution
        obra run "Test feature" --local  # Use local Firebase emulator

    Environment Variables:
        OBRA_MODEL          Default model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        OBRA_ORCH_MODEL     Default orchestrator model override
        OBRA_FAST_MODEL     Fast tier override (e.g., haiku, gpt-5.1-codex-mini)
        OBRA_HIGH_MODEL     High tier override (e.g., opus, gpt-5.2)
        OBRA_PROVIDER       Default provider (anthropic, openai, google)
        OBRA_ORCH_PROVIDER  Default orchestrator provider override
        OBRA_REASONING_LEVEL Default reasoning level (off, low, medium, high, maximum)
        OBRA_ORCH_REASONING_LEVEL Default orchestrator reasoning level
        OBRA_ISOLATED       Enable/disable isolation (true/false)

    Domain Resolution:
        `obra run` needs an explicit resolved domain from --domain, project
        config, or layered config. If none resolve, the run fails before
        session creation. Use `obra help domains` to inspect available domains.

    Precedence: CLI flags > environment variables > config file
    """
    verbose = _resolve_command_verbosity(ctx, verbose)

    mode = resolve_interaction_mode(interactive=interactive, non_interactive=non_interactive)
    with _apply_interaction_mode(mode):
        # Display startup banner
        print_banner()
        console.print(
            f"{glyphs.logs} Logs: run 'obra logs viewer' for live session logs", style="cyan"
        )
        if mode is InteractionMode.HEADLESS and sys.stdin.isatty():
            console.print("[dim]Headless mode (default). Use --interactive for prompts.[/dim]")
        console.print()

        from obra.cli.run_support.session_flow import run_derive as _session_run_derive

        with _apply_config_override_layer(config_override):
            _session_run_derive(
                **prepare_run_invocation(
                    objective=objective,
                    working_dir=working_dir,
                    domain=domain,
                    resume_session=resume_session,
                    continue_from=continue_from,
                    resume_from=resume_from,
                    rerun_setup=rerun_setup,
                    plan_id=plan_id,
                    plan_file=plan_file,
                    orch_provider=orch_provider,
                    orch_model=orch_model,
                    orch_reasoning=orch_reasoning,
                    mosaic=mosaic,
                    model=model,
                    fast_model=fast_model,
                    high_model=high_model,
                    impl_provider=impl_provider,
                    reasoning_level=reasoning_level,
                    no_extended_thinking=no_extended_thinking,
                    verbose=verbose,
                    stream=stream,
                    plan_only=plan_only,
                    execute_pipeline=execute_pipeline,
                    permissive=permissive,
                    defaults_json=defaults_json,
                    spike_first=spike_first,
                    no_spike_first=no_spike_first,
                    plan_first=plan_first,
                    no_closeout=no_closeout,
                    skip_intent=skip_intent,
                    review_intent=review_intent,
                    enrich=enrich,
                    no_enrich=no_enrich,
                    isolated=isolated,
                    no_isolated=no_isolated,
                    full_review=full_review,
                    skip_review=skip_review,
                    review_agents=review_agents,
                    with_security=with_security,
                    with_testing=with_testing,
                    with_docs=with_docs,
                    with_code_quality=with_code_quality,
                    no_security=no_security,
                    no_testing=no_testing,
                    no_docs=no_docs,
                    no_code_quality=no_code_quality,
                    review_format=review_format,
                    review_quiet=review_quiet,
                    review_summary_only=review_summary_only,
                    fail_on_p1=fail_on_p1,
                    fail_on_p2=fail_on_p2,
                    review_timeout=review_timeout,
                    auto_report=auto_report,
                    yes=yes,
                    mock_credentials=mock_credentials,
                    skip_env_setup=skip_env_setup,
                    skip_git_check=skip_git_check,
                    auto_init_git=auto_init_git,
                    skip_plan_quality_gate=skip_plan_quality_gate,
                    skip_complexity_check=skip_complexity_check,
                    parallel=parallel,
                    skip_tier_check=skip_tier_check,
                    skip_explore=skip_explore,
                    force_explore=force_explore,
                    plan_mode=plan_mode,
                    local=local,
                )
            )


def _should_isolate(
    isolated: bool | None = None,
    no_isolated: bool | None = None,
) -> bool:
    """Determine whether to run in isolated mode.

    Resolution precedence (highest to lowest):
    1. CLI flags: --isolated (True) or --no-isolated (False)
    2. Environment variable: OBRA_ISOLATED=true/false
    3. CI environment: CI=true enables isolation automatically
    4. Config file: ~/.obra/config-layers/01-user.yaml agent.isolated_mode
    5. Default: True (isolation enabled for reproducibility)

    Args:
        isolated: CLI --isolated flag value (True if flag present)
        no_isolated: CLI --no-isolated flag value (True if flag present)

    Returns:
        True if isolation should be enabled, False otherwise
    """
    # Priority 1: CLI flags (--isolated or --no-isolated)
    if isolated:
        return True
    if no_isolated:
        return False

    # Priority 2: Environment variable OBRA_ISOLATED
    env_isolated = os.environ.get("OBRA_ISOLATED", "").lower()
    if env_isolated in ("true", "1", "yes"):
        return True
    if env_isolated in ("false", "0", "no"):
        return False

    # Priority 3: CI environment auto-enable
    # Common CI environment variables: CI, GITHUB_ACTIONS, GITLAB_CI, CIRCLECI, etc.
    ci_env = os.environ.get("CI", "").lower()
    if ci_env in ("true", "1", "yes"):
        return True

    # Priority 4: Config file (agent.isolated_mode)
    from obra.config import get_isolated_mode

    config_isolated = get_isolated_mode()
    if config_isolated is True:
        return True
    if config_isolated is False:
        return False

    # Priority 5: Default (isolation enabled for reproducibility)
    return True


# =============================================================================
# Derive Command (FEAT-AUTO-INTENT-001 S3.T0, S3.T1)
# =============================================================================


@handle_encoding_errors
@require_terms_accepted
def derive(
    ctx: typer.Context,
    objective: str | None = typer.Argument(
        None,
        help="Objective to derive (uses active intent if not provided)",
    ),
    working_dir: OptWorkingDir = None,
    domain: OptDomain = None,
    continue_intent: bool = typer.Option(
        False,
        "--continue",
        help="Continue with active intent (explicit flag, S3.T1)",
    ),
    resume_session: OptResumeSession = None,
    continue_from: OptContinueFrom = None,
    plan_id: OptPlanId = None,
    plan_file: OptPlanFile = None,
    orch_provider: OptOrchProvider = None,
    orch_model: OptOrchModel = None,
    orch_reasoning: OptOrchReasoning = None,
    mosaic: OptMosaic = None,
    model: OptModel = None,
    fast_model: OptFastModel = None,
    high_model: OptHighModel = None,
    impl_provider: OptImplProvider = None,
    reasoning_level: OptReasoningLevel = None,
    no_extended_thinking: OptNoExtendedThinking = False,
    verbose: OptVerbose = 0,
    interactive: OptInteractive = False,
    non_interactive: OptNonInteractive = False,
    stream: OptStream = False,
    plan_only: OptPlanOnly = False,
    permissive: OptPermissive = False,
    defaults_json: OptDefaultsJson = False,
    config_override: OptConfigOverride = None,
    spike_first: OptSpikeFirst = False,
    no_spike_first: OptNoSpikeFirst = False,
    plan_first: OptPlanFirst = False,
    no_closeout: OptNoCloseout = False,
    skip_intent: OptSkipIntent = False,
    review_intent: OptReviewIntent = False,
    _enrich: bool = typer.Option(
        False,
        "--enrich",
        help="Force intent enrichment (requires planning.enrichment.enabled)",
    ),
    _no_enrich: bool = typer.Option(
        False,
        "--no-enrich",
        help="Skip intent enrichment even when enabled",
    ),
    isolated: OptIsolated = None,
    no_isolated: OptNoIsolated = None,
    full_review: OptFullReview = False,
    skip_review: OptSkipReview = False,
    review_agents: OptReviewAgents = None,
    with_security: OptWithSecurity = False,
    with_testing: OptWithTesting = False,
    with_docs: OptWithDocs = False,
    with_code_quality: OptWithCodeQuality = False,
    no_security: OptNoSecurity = False,
    no_testing: OptNoTesting = False,
    no_docs: OptNoDocs = False,
    no_code_quality: OptNoCodeQuality = False,
    review_format: OptReviewFormat = None,
    review_quiet: OptReviewQuiet = False,
    review_summary_only: OptReviewSummaryOnly = False,
    fail_on_p1: OptFailOnP1 = False,
    fail_on_p2: OptFailOnP2 = False,
    review_timeout: OptReviewTimeout = None,
    auto_report: OptAutoReport = False,
    skip_git_check: OptSkipGitCheck = False,
    auto_init_git: OptAutoInitGit = False,
    skip_plan_quality_gate: OptSkipPlanQualityGate = False,
    skip_complexity_check: OptSkipComplexityCheck = False,
    force_empty: bool = typer.Option(
        False, "--force-empty", help="Force EMPTY project state (new/minimal project)"
    ),
    force_existing: bool = typer.Option(
        False,
        "--force-existing",
        help="Force EXISTING project state (established codebase)",
    ),
    from_step: int | None = typer.Option(
        None,
        "--from-step",
        "-f",
        min=1,
        help="Re-derive from step N onwards (1-indexed). Steps 1 to N-1 retain existing derivation.",
    ),
    cascade: bool = typer.Option(
        False,
        "--cascade",
        help="Mark sibling steps after the edited/re-derived step as STALE for staleness propagation.",
    ),
    work_type: str | None = typer.Option(
        None,
        "--work-type",
        "-w",
        help=(
            f"Override automatic work type detection. "
            f"Valid types: {', '.join(VALID_WORK_TYPES[:-1])}. "
            f"When provided, bypasses auto-detection and uses the specified work type."
        ),
    ),
    skip_explore: OptSkipExplore = False,
    force_explore: OptForceExplore = False,
    plan_mode: str | None = typer.Option(
        None,
        "--plan-mode",
        help=(
            "Rigor override: auto (default), light, balanced, or thorough. "
            "Compatibility aliases: quick=light, standard=balanced"
        ),
    ),
    local: OptLocal = False,
) -> None:
    """Derive execution plan from objective or active intent.

    Obra's derive command creates an execution plan from your objective.
    If you don't provide an objective, it will use the active intent
    for the current project (created via 'obra intent new').

    Examples:
        obra derive "add user authentication"
        obra derive                              # Uses active intent
        obra derive --continue                   # Explicit continue with active intent
        obra derive "refactor API" --plan-only
        obra derive --stream -vv
        obra derive "mosaic planning" --mosaic claude-sonnet-4-6:claude-3-5-haiku
        obra derive --from-step 3                # Re-derive from step 3 onwards
        obra derive --no-extended-thinking       # Disable extended thinking
        obra derive "investigate flaky test" --plan-mode balanced
        obra derive "add auth" --local           # Use local Firebase emulator

    With active intent:
        obra intent new "add auth"
        obra derive                              # Uses "add auth" intent
        obra derive --continue                   # Explicit form

    Incremental re-derivation:
        obra derive --from-step N                # Re-derive steps N, N+1, N+2, ...
                                                 # Steps 1 to N-1 retain existing derivation
        obra derive --from-step N --cascade      # Re-derive step N and mark steps after N as STALE

    Environment Variables:
        OBRA_MODEL          Default model (e.g., opus, gpt-5.2, gemini-2.5-flash)
        OBRA_ORCH_MODEL     Default orchestrator model override
        OBRA_FAST_MODEL     Fast tier override (e.g., haiku, gpt-5.1-codex-mini)
        OBRA_HIGH_MODEL     High tier override (e.g., opus, gpt-5.2)
        OBRA_PROVIDER       Default provider (anthropic, openai, google)
        OBRA_ORCH_PROVIDER  Default orchestrator provider override
        OBRA_REASONING_LEVEL Default reasoning level (off, low, medium, high, maximum)
        OBRA_ORCH_REASONING_LEVEL Default orchestrator reasoning level
        OBRA_ISOLATED       Enable/disable isolation (true/false)

    Precedence: CLI flags > environment variables > config file

    Interaction Mode:
        Default is headless (no stdin prompts). Use --interactive to enable
        prompts for intent review and manual approvals.

    Reference: FEAT-AUTO-INTENT-001 S3.T0, S3.T1
    """
    verbose = _resolve_command_verbosity(ctx, verbose)
    mode = resolve_interaction_mode(interactive=interactive, non_interactive=non_interactive)
    with _apply_interaction_mode(mode):
        if mode is InteractionMode.HEADLESS and sys.stdin.isatty():
            console.print("[dim]Headless mode (default). Use --interactive for prompts.[/dim]")
        from obra.cli.run_support.session_flow import run_derive as _session_run_derive

        with _apply_config_override_layer(config_override):
            _session_run_derive(
                **prepare_derive_invocation(
                    objective=objective,
                    working_dir=working_dir,
                    domain=domain,
                    continue_intent=continue_intent,
                    resume_session=resume_session,
                    continue_from=continue_from,
                    plan_id=plan_id,
                    plan_file=plan_file,
                    orch_provider=orch_provider,
                    orch_model=orch_model,
                    orch_reasoning=orch_reasoning,
                    mosaic=mosaic,
                    model=model,
                    fast_model=fast_model,
                    high_model=high_model,
                    impl_provider=impl_provider,
                    reasoning_level=reasoning_level,
                    no_extended_thinking=no_extended_thinking,
                    verbose=verbose,
                    stream=stream,
                    plan_only=plan_only,
                    permissive=permissive,
                    defaults_json=defaults_json,
                    spike_first=spike_first,
                    no_spike_first=no_spike_first,
                    plan_first=plan_first,
                    no_closeout=no_closeout,
                    skip_intent=skip_intent,
                    review_intent=review_intent,
                    isolated=isolated,
                    no_isolated=no_isolated,
                    full_review=full_review,
                    skip_review=skip_review,
                    review_agents=review_agents,
                    with_security=with_security,
                    with_testing=with_testing,
                    with_docs=with_docs,
                    with_code_quality=with_code_quality,
                    no_security=no_security,
                    no_testing=no_testing,
                    no_docs=no_docs,
                    no_code_quality=no_code_quality,
                    review_format=review_format,
                    review_quiet=review_quiet,
                    review_summary_only=review_summary_only,
                    fail_on_p1=fail_on_p1,
                    fail_on_p2=fail_on_p2,
                    review_timeout=review_timeout,
                    auto_report=auto_report,
                    skip_git_check=skip_git_check,
                    auto_init_git=auto_init_git,
                    skip_plan_quality_gate=skip_plan_quality_gate,
                    skip_complexity_check=skip_complexity_check,
                    force_empty=force_empty,
                    force_existing=force_existing,
                    from_step=from_step,
                    cascade=cascade,
                    work_type=work_type,
                    skip_explore=skip_explore,
                    force_explore=force_explore,
                    plan_mode=plan_mode,
                    local=local,
                )
            )


# =============================================================================
# Verify Command
# =============================================================================


@handle_encoding_errors
def verify(
    auto: bool = typer.Option(
        False,
        "--auto",
        help="Attempt automatic verification (best-effort file checks)",
    ),
    intent_id: str | None = typer.Option(
        None,
        "--intent",
        help="Verify specific intent ID (default: active intent)",
    ),
) -> None:
    """Verify completion against active intent acceptance criteria.

    Checks the current project state against the acceptance criteria
    defined in the active intent. Generates a verification report
    and optionally archives the intent if all criteria pass.

    Examples:
        obra verify              # Verify active intent (manual review)
        obra verify --auto       # Attempt automatic verification
        obra verify --intent add-auth  # Verify specific intent
    """
    from pathlib import Path

    from obra.intent.storage import IntentStorage
    from obra.intent.verification import (
        archive_intent,
        save_verification_report,
        verify_completion,
    )

    try:
        storage = IntentStorage()
        working_dir = Path.cwd()
        project = storage.get_workspace_id(working_dir)

        # Load intent to verify
        if intent_id:
            # Resolve partial ID
            resolved_id = storage.resolve_id(intent_id, project)
            if not resolved_id:
                console.print()
                print_error(f"Intent not found: {intent_id}")
                console.print()
                console.print("  [dim]Use 'obra intent list' to see available intents[/dim]")
                console.print()
                raise typer.Exit(1)
            intent = storage.load(resolved_id, project)
            if not intent:
                console.print()
                print_error(f"Failed to load intent: {resolved_id}")
                console.print()
                raise typer.Exit(1)
        else:
            # Use active intent
            intent = storage.load_active(project)
            if not intent:
                console.print()
                print_error("No active intent to verify")
                console.print()
                console.print("  [dim]Use 'obra intent list' to see available intents[/dim]")
                console.print()
                console.print('  [dim]Or create one with: obra derive "objective"[/dim]')
                console.print()
                raise typer.Exit(1)

        console.print()
        console.print(f"[bold]Verifying Intent:[/bold] {intent.id}")
        console.print(f"[dim]Problem: {intent.problem_statement}[/dim]")
        console.print()

        # Run verification
        report = verify_completion(
            intent,
            project_dir=working_dir if auto else None,
            auto_verify=auto,
        )

        # Save verification report
        report_path = save_verification_report(report)

        # Display results
        status_emoji = {
            "passed": glyphs.success,
            "failed": glyphs.failure,
            "partial": glyphs.warning,
            "skipped": "o",
        }
        emoji = status_emoji.get(report.status.value, "?")

        console.print(f"[bold]Verification Status:[/bold] {emoji} {report.status.value.upper()}")
        console.print()
        console.print(f"  {report.summary}")
        console.print()

        if report.results:
            console.print("[bold]Acceptance Criteria:[/bold]")
            console.print()
            for result in report.results:
                check = (
                    f"[green]{glyphs.success}[/green]"
                    if result.passed
                    else f"[red]{glyphs.failure}[/red]"
                )
                console.print(f"  {check} {result.criterion}")
                if result.notes:
                    console.print(f"    [dim]{result.notes}[/dim]")
            console.print()

        console.print("[bold]Statistics:[/bold]")
        console.print(f"  Total: {report.total_criteria}")
        console.print(f"  Passed: {report.passed_criteria}")
        console.print(f"  Failed: {report.failed_criteria}")
        console.print()

        console.print(f"[dim]Report saved: {report_path}[/dim]")
        console.print()

        # If all criteria passed, offer to archive
        if report.passed:
            console.print("[bold green]All acceptance criteria met![/bold green]")
            console.print()

            # Auto-archive the intent
            if archive_intent(intent.id, project, storage):
                console.print("[dim]Intent archived and marked complete[/dim]")
                console.print()
            else:
                console.print("[dim yellow]Warning: Failed to archive intent[/dim]")
                console.print()
        else:
            console.print(
                "[yellow]Some criteria not yet met. Continue working on this intent.[/yellow]"
            )
            console.print()
            console.print("  [dim]Use: obra derive --continue[/dim]")
            console.print()

    except typer.Exit:
        raise
    except Exception as e:
        console.print()
        display_error(e, console)
        logger.exception("Verification failed")
        raise typer.Exit(1) from e


# =============================================================================
# Autonomous Runner
# =============================================================================


@handle_encoding_errors
def auto(
    plan: str = typer.Option(
        ...,
        "--plan",
        "-p",
        help="WORK_ID for the machine plan (e.g., AUTO-RUN-001)",
    ),
    max_stories: int | None = typer.Option(
        None,
        "--max-stories",
        "-m",
        help="Maximum number of stories to execute (default: all)",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show execution plan without running stories",
    ),
) -> None:
    """Execute multi-story workplans autonomously.

    The auto-runner executes stories sequentially from MACHINE_PLAN.json
    without continuous LLM attention, solving the completion bias problem.

    Examples:
        obra auto --plan AUTO-RUN-001              # Execute all stories
        obra auto --plan AUTO-RUN-001 --max-stories 2  # Execute 2 stories
        obra auto --plan AUTO-RUN-001 --dry-run    # Show plan only

    Story Execution:
        Each story runs as a separate `obra run` session.
        The runner updates story status in the machine plan after completion.

    Error Handling:
        - Transient errors: Automatic retry (configurable)
        - Breakpoints: Halt execution for human intervention
        - Failed stories: Skip and continue (or escalate based on config)

    Configuration:
        Set in ~/.obra/config-layers/01-user.yaml or config/default_config.yaml:
            auto:
              enabled: true
              retry_count: 3
              retry_delay_seconds: 5
              error_assessor: null  # null=disabled, "fast"=use fast-tier, or model name
              escalate_on_skip: true

    Related Commands:
        - obra run: Execute a single story objective
        - obra derive: Create execution plans from objectives
    """

    from obra.auto.runner import AutoRunner

    # Build plan path
    plan_path = Path.cwd() / "docs" / "development" / f"{plan}_MACHINE_PLAN.json"

    if not plan_path.exists():
        print_error(f"Machine plan not found: {plan_path}")
        print_info("Expected location: docs/development/{WORK_ID}_MACHINE_PLAN.json")
        raise typer.Exit(1)

    if dry_run:
        print_info(f"[DRY-RUN] Autonomous execution plan for {plan}")
        print_info(f"Plan file: {plan_path}")
        print()

    try:
        # Load configuration from default config file
        # Note: obra package uses direct YAML loading, not src.core.config.Config
        config_path = Path(__file__).parent.parent / "config" / "default_config.yaml"
        if not config_path.exists():
            # Fallback for installed package (config not bundled)
            logger.warning(f"Config file not found at {config_path}, using defaults")
            auto_config = {}
        else:
            config = yaml.safe_load(config_path.read_text())
            auto_config = config.get("orchestration", {}).get("auto", {})

        # Extract configuration values
        retry_count = auto_config.get("retry_count", 2)
        retry_delay = auto_config.get("retry_delay_seconds", 30)
        escalate_on_skip = auto_config.get("escalate_on_skip", True)
        error_assessor_config = auto_config.get("error_assessor")

        # Create error assessor if configured
        error_assessor = None
        if error_assessor_config:
            from obra.auto.assessor import ErrorAssessor
            from obra.config import get_llm_config

            # Resolve model name (handle "fast" tier)
            # "fast" maps to haiku for cost-effective error assessment
            model_name = "haiku" if error_assessor_config == "fast" else error_assessor_config

            # Get LLM config from obra.config (client config)
            # This gives us provider, model, auth info for CLI subprocess invocation
            llm_config = get_llm_config()

            # Override model with the assessor-specific model
            if llm_config:
                llm_config = dict(llm_config)  # Make a copy
                llm_config["model"] = model_name
            else:
                # Fallback if no LLM config available
                llm_config = {"provider": "anthropic", "model": model_name}

            error_assessor = ErrorAssessor(enabled=True, llm_config=llm_config)
            logger.info(f"Error assessor enabled with model: {model_name}")

        runner = AutoRunner(
            str(plan_path),
            retry_count=retry_count,
            retry_delay_seconds=retry_delay,
            escalate_on_skip=escalate_on_skip,
            error_assessor=error_assessor,
        )
        exit_code = runner.run(max_stories=max_stories, dry_run=dry_run)

        if exit_code == 0:
            print_success("Autonomous execution completed successfully.")
        else:
            print_error(f"Autonomous execution failed with exit code {exit_code}")
            raise typer.Exit(exit_code)

    except KeyboardInterrupt:
        print_warning("\nAutonomous execution interrupted by user.")
        print_info("Current story state has been saved to plan.")
        raise typer.Exit(0) from None
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Autonomous execution error: {e}")
        logger.exception("Auto-runner failed")
        raise typer.Exit(1) from e
