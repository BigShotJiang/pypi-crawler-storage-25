"""Runner catalog inspection CLI."""

from __future__ import annotations

import json
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import typer

from obra.cli.business import _pushd
from obra.domains import get_available_domains
from obra.workflow.runner_catalog_sources import (
    effective_catalog_for_domain,
    project_catalog_entry,
)

catalog_app = typer.Typer(help="Inspect the effective runner catalog")


def _resolve_project_dir(project_dir: str | None) -> Path | None:
    if not project_dir:
        return None
    return Path(project_dir).expanduser().resolve(strict=False)


def _require_known_domain(domain_id: str) -> str:
    normalized = str(domain_id or "").strip()
    if not normalized:
        raise typer.BadParameter("--domain must be a non-empty domain id")
    available = set(get_available_domains())
    if normalized not in available:
        raise typer.BadParameter(
            f"Unknown domain {normalized!r}. Available domains: {', '.join(sorted(available))}"
        )
    return normalized


@catalog_app.command("list")
def list_catalog(
    domain: str = typer.Option(..., "--domain", help="Domain id to inspect"),
    kind: str | None = typer.Option(None, "--kind", help="Optional runner kind filter"),
    project_dir: str | None = typer.Option(
        None,
        "--project-dir",
        help="Optional base directory used for layered config and overlay resolution",
    ),
    json_output: bool = typer.Option(False, "--json", help="Emit JSON instead of a table"),
) -> None:
    """List runner catalog entries visible to one domain."""
    normalized_domain = _require_known_domain(domain)
    resolved_project_dir = _resolve_project_dir(project_dir)
    context = _pushd(resolved_project_dir) if resolved_project_dir is not None else nullcontext()
    with context:
        payload = [project_catalog_entry(entry) for entry in effective_catalog_for_domain(normalized_domain)]

    normalized_kind = str(kind or "").strip()
    if normalized_kind:
        payload = [entry for entry in payload if str(entry.get("kind") or "") == normalized_kind]

    if json_output:
        typer.echo(json.dumps({"runners": payload}, indent=2, sort_keys=True))
        return

    columns = ("id", "version", "kind", "input_types", "stage_archetypes", "portability", "source")
    typer.echo("\t".join(columns))
    for entry in payload:
        typer.echo(
            "\t".join(
                [
                    str(entry.get("id") or ""),
                    str(entry.get("version") or ""),
                    str(entry.get("kind") or ""),
                    ",".join(str(item) for item in entry.get("input_types", []) or []),
                    ",".join(str(item) for item in entry.get("stage_archetypes", []) or []),
                    str(entry.get("portability") or ""),
                    str(entry.get("source") or ""),
                ]
            )
        )
