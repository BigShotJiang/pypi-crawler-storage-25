"""CLI helpers for persisted spike artifacts."""

from __future__ import annotations

from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from obra.hybrid.spike.persistence import load_session_spike_artifacts

spike_app = typer.Typer(
    name="spike",
    help="Inspect persisted spike phase artifacts.",
    no_args_is_help=True,
)

_console = Console()


@spike_app.command("inspect")
def inspect_command(
    session_id: str = typer.Argument(...),
    phase: str = typer.Option(
        "pre_derive",
        "--phase",
        help="Spike phase to inspect: pre_derive or per_story.",
    ),
    patch: str | None = typer.Option(
        None,
        "--patch",
        help="Dump the raw diff for the given attempt_id to stdout.",
    ),
    runtime_dir: Path | None = typer.Option(
        None,
        "--runtime-dir",
        help="Override the runtime root used to locate spike artifacts.",
    ),
) -> None:
    """Inspect one persisted spike artifact payload."""
    try:
        artifacts = load_session_spike_artifacts(
            session_id,
            phase=phase,
            runtime_dir=runtime_dir,
        )
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc
    if artifacts is None:
        typer.echo(
            (
                f"No spike artifacts found for session {session_id} phase {phase}. "
                "Either the session did not run that spike phase or the artifacts file is missing."
            ),
            err=True,
        )
        raise typer.Exit(code=1)

    if patch is not None:
        for attempt in artifacts.attempts:
            if str(attempt.get("attempt_id", "")) == patch:
                typer.echo(str(attempt.get("patch", "")), nl=False)
                return
        typer.echo(f"No spike attempt found for attempt_id={patch}.", err=True)
        raise typer.Exit(code=1)

    table = Table(title=f"Spike artifacts: {session_id} ({artifacts.phase})")
    table.add_column("attempt_id")
    table.add_column("success")
    table.add_column("files_changed")
    table.add_column("elapsed_s")
    table.add_column("evaluator_verdict", no_wrap=True)
    for index, attempt in enumerate(artifacts.attempts):
        verdict = artifacts.evaluator_verdicts[index] if index < len(artifacts.evaluator_verdicts) else {}
        selected_template = str(verdict.get("selected_template") or "-")
        verdict_value = str(verdict.get("verdict") or "-")
        files_changed = attempt.get("files_changed")
        files_changed_count = len(files_changed) if isinstance(files_changed, list) else 0
        elapsed_value = attempt.get("elapsed_s")
        elapsed_text = f"{float(elapsed_value):.1f}" if elapsed_value is not None else ""
        table.add_row(
            str(attempt.get("attempt_id", "")),
            str(bool(attempt.get("success", False))),
            str(files_changed_count),
            elapsed_text,
            f"{verdict_value}/{selected_template}",
        )
    _console.print(table)
    _console.print(f"phase={artifacts.phase}")
    _console.print(f"completed_at={artifacts.completed_at}")
    _console.print(f"applied_to_source={artifacts.applied_to_source}")
    _console.print(f"final_attempt_id={artifacts.final_attempt_id}")
    _console.print(f"final_verdict={artifacts.final_verdict}")
    final_evaluator_verdict = artifacts.final_evaluator_verdict or {}
    if final_evaluator_verdict:
        _console.print(
            "final_evaluator_verdict="
            f"{final_evaluator_verdict.get('verdict', '-')}/"
            f"{final_evaluator_verdict.get('selected_template', '-')}"
        )
