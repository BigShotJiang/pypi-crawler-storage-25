"""Top-level workspace context commands."""

from __future__ import annotations

from pathlib import Path

import typer

from obra.config.loaders import load_layered_config
from obra.workspace.context_import import run_import

context_app = typer.Typer(help="Manage imported workspace context")


@context_app.command("import")
def import_context(
    repo_path: Path = typer.Argument(
        Path("."),
        exists=True,
        file_okay=False,
        dir_okay=True,
        resolve_path=True,
        help="Repository root to scan for vendor meta-files.",
    ),
) -> None:
    """Import vendor meta-files into `.obra/context/project-context.md`."""
    config, _, _ = load_layered_config(include_defaults=True)
    result = run_import(repo_path, config)
    if result["status"] == "no_vendor_files":
        typer.echo(f"No vendor meta-files found under {Path(repo_path).resolve()}.")
        return

    typer.echo(f"Discovered {len(result['vendor_files'])} vendor meta-file(s).")
    typer.echo(f"Wrote project context: {result['output_path']}")
    typer.echo(f"Wrote import manifest: {result['manifest_path']}")
