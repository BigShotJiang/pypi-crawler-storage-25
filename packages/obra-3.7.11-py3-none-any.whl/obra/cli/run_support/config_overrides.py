"""Helpers for per-run config override layers."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path
from typing import Any

import typer
import yaml  # type: ignore[import-untyped]

from obra.utils.obra_home import get_runtime_dir

_JSON_METACHARS = frozenset("{}[],:\"")


def parse_config_override(spec: str) -> tuple[list[str], Any]:
    """Parse one ``dotted.path=json_value`` override spec."""
    key, separator, raw_value = spec.partition("=")
    if separator == "":
        raise typer.BadParameter(
            "Config override must use dotted.path=json_value syntax.",
        )
    key = key.strip()
    if not key:
        raise typer.BadParameter("Config override key cannot be empty.")
    path = [segment.strip() for segment in key.split(".")]
    if any(not segment for segment in path):
        raise typer.BadParameter("Config override key cannot contain empty path segments.")
    return path, _parse_override_value(raw_value.strip(), spec=spec)


def build_override_dict(specs: list[str]) -> dict[str, Any]:
    """Merge override specs into one nested dict."""
    payload: dict[str, Any] = {}
    for spec in specs:
        path, value = parse_config_override(spec)
        _insert_override_value(payload, path, value)
    return payload


def materialize_override_layer(payload: dict[str, Any]) -> Path:
    """Write one override layer YAML under the canonical runtime root."""
    overrides_dir = get_runtime_dir() / "config-overrides"
    overrides_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        prefix="obra-cli-override-",
        suffix=".yaml",
        dir=overrides_dir,
        delete=False,
    ) as handle:
        yaml.safe_dump(payload, handle, sort_keys=False)
        return Path(handle.name)


def _parse_override_value(raw_value: str, *, spec: str) -> Any:
    if raw_value == "":
        return ""
    try:
        return json.loads(raw_value)
    except json.JSONDecodeError as exc:
        if any(char in _JSON_METACHARS for char in raw_value):
            raise typer.BadParameter(
                f"Config override value must be valid JSON when using JSON punctuation: {spec}"
            ) from exc
        return raw_value


def _insert_override_value(payload: dict[str, Any], path: list[str], value: Any) -> None:
    current: dict[str, Any] = payload
    for segment in path[:-1]:
        existing = current.get(segment)
        if existing is None:
            next_level: dict[str, Any] = {}
            current[segment] = next_level
            current = next_level
            continue
        if not isinstance(existing, dict):
            dotted_path = ".".join(path)
            raise ValueError(
                f"Conflicting config override path '{dotted_path}': '{segment}' is already a value."
            )
        current = existing

    leaf = path[-1]
    existing_leaf = current.get(leaf)
    if isinstance(existing_leaf, dict):
        dotted_path = ".".join(path)
        raise ValueError(
            f"Conflicting config override path '{dotted_path}': existing value is a nested object."
        )
    if existing_leaf is not None and existing_leaf != value:
        dotted_path = ".".join(path)
        raise ValueError(
            f"Duplicate config override path '{dotted_path}' has conflicting values."
        )
    current[leaf] = value


__all__ = [
    "build_override_dict",
    "materialize_override_layer",
    "parse_config_override",
]
