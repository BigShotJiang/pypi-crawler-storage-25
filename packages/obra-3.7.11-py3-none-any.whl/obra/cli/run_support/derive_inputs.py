"""Derive-input preparation helpers for CLI run/derive flows."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, cast

from obra.display import console, glyphs
from obra.exceptions import ConfigurationError
from obra.review.config import ALLOWED_AGENTS, ReviewConfig, ReviewConfigCLIInputs

logger = logging.getLogger(__name__)

# Common tech stack keywords that indicate specificity
_TECH_KEYWORDS = frozenset(
    [
        "python",
        "javascript",
        "typescript",
        "go",
        "rust",
        "java",
        "ruby",
        "php",
        "swift",
        "kotlin",
        "c#",
        "csharp",
        "c++",
        "scala",
        "elixir",
        "fastapi",
        "django",
        "flask",
        "express",
        "nextjs",
        "next.js",
        "react",
        "vue",
        "angular",
        "svelte",
        "rails",
        "spring",
        "gin",
        "echo",
        "actix",
        "nestjs",
        "nuxt",
        "remix",
        "astro",
        "laravel",
        "symfony",
        "postgresql",
        "postgres",
        "mysql",
        "mongodb",
        "redis",
        "sqlite",
        "dynamodb",
        "firestore",
        "supabase",
        "prisma",
        "sqlalchemy",
        "typeorm",
        "docker",
        "kubernetes",
        "k8s",
        "aws",
        "gcp",
        "azure",
        "vercel",
        "heroku",
        "terraform",
        "cloudflare",
    ]
)

_MIN_WORD_COUNT = 10
_TRIVIAL_WORD_COUNT = 5


def _parse_review_agents_csv(review_agents: str | None) -> list[str] | None:
    """Parse a comma-separated agent list from CLI input."""
    if review_agents is None:
        return None
    agents = [part.strip() for part in review_agents.split(",") if part.strip()]
    return agents or None


def _load_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Load planning config from project config layer if present."""
    from obra.config.planning import get_project_planning_config

    return cast(dict[str, Any], get_project_planning_config(project_path))


def _build_review_config_from_cli(
    *,
    full_review: bool,
    skip_review: bool,
    review_agents: str | None,
    with_security: bool,
    with_testing: bool,
    with_docs: bool,
    with_code_quality: bool,
    no_security: bool,
    no_testing: bool,
    no_docs: bool,
    no_code_quality: bool,
    review_format: str | None,
    review_quiet: bool,
    review_summary_only: bool,
    fail_on_p1: bool,
    fail_on_p2: bool,
    review_timeout: int | None,
    project_path: Path | None = None,
) -> ReviewConfig:
    """Build ReviewConfig from CLI flags and project config defaults."""
    explicit_agents = _parse_review_agents_csv(review_agents)
    add_agents = [
        name
        for name, enabled in (
            ("security", with_security),
            ("testing", with_testing),
            ("docs", with_docs),
            ("code_quality", with_code_quality),
        )
        if enabled
    ]
    remove_agents = [
        name
        for name, enabled in (
            ("security", no_security),
            ("testing", no_testing),
            ("docs", no_docs),
            ("code_quality", no_code_quality),
        )
        if enabled
    ]

    fail_threshold: str | None = None
    if fail_on_p2:
        fail_threshold = "p2"
    elif fail_on_p1:
        fail_threshold = "p1"

    try:
        cli_inputs = ReviewConfigCLIInputs(
            explicit_agents=explicit_agents,
            add_agents=add_agents,
            remove_agents=remove_agents,
            full_review=full_review,
            skip_review=skip_review,
            output_format=review_format,
            quiet=review_quiet,
            summary_only=review_summary_only,
            fail_threshold=fail_threshold,
            timeout_seconds=review_timeout,
        )
        return ReviewConfig.from_cli_and_config(
            project_path=project_path,
            cli_inputs=cli_inputs,
        )
    except ConfigurationError:
        raise
    except ValueError as exc:
        raise ConfigurationError(str(exc), "Update review CLI flags or review config.") from exc


def _detect_input_quality_issues(objective: str) -> list[str]:
    """Detect common input quality problems in user objectives."""
    issues = []
    words = objective.split()
    word_count = len(words)
    objective_lower = objective.lower()

    if word_count < _MIN_WORD_COUNT:
        if word_count <= _TRIVIAL_WORD_COUNT:
            issues.append(f"Very short objective ({word_count} words) - may be too vague")
        else:
            issues.append(f"Short objective ({word_count} words) - consider adding more detail")

    has_tech = any(tech in objective_lower for tech in _TECH_KEYWORDS)
    if not has_tech and word_count >= _TRIVIAL_WORD_COUNT:
        issues.append("No tech stack detected - specify language/framework/database")

    vague_patterns = [
        ("build a website", "What kind? E-commerce, blog, SaaS? What features?"),
        ("add authentication", "What type? JWT, OAuth2, session-based?"),
        ("add auth", "What type? JWT, OAuth2, session-based?"),
        ("fix the bug", "Which bug? What's the symptom? What file?"),
        ("fix bug", "Which bug? What's the symptom? What file?"),
        ("make it faster", "Which part? API? Page load? Database?"),
        ("improve performance", "Which part? API? Page load? Database?"),
        ("add tests", "What tests? Unit, integration, E2E? For which components?"),
        ("refactor", "What specifically? Which files/modules? What's the goal?"),
    ]

    for pattern, suggestion in vague_patterns:
        if pattern in objective_lower:
            issues.append(f"Vague pattern '{pattern}' - {suggestion}")
            break

    return issues


def _show_input_quality_warning(issues: list[str]) -> None:
    """Display input quality warning with actionable guidance."""
    console.print()
    console.print(f"[yellow]{glyphs.warning}  Input Quality Check:[/yellow]")
    for issue in issues:
        console.print(f"  [dim]•[/dim] {issue}")
    console.print()
    console.print(f"[dim]{glyphs.hint} For better results: [/dim][cyan]obra briefing quick[/cyan]")
    console.print()
