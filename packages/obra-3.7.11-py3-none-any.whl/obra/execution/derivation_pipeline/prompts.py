"""DerivationPromptBuilder — thin RPC shim (ADR-103).

The builder now wraps :class:`DerivationPromptRPCClient`, providing the same
per-engine method surface that :class:`DerivationEngine` and its orchestrators
already call. All authoritative prompt content is authored server-side under
``functions/src/domains/<name>/``; the client only assembles RPC calls and
runs :class:`PromptEnricher` locally before returning.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from obra.config.loaders import (
    get_derivation_story_range,
    get_derivation_task_range,
    load_layered_config,
)
from obra.hybrid.prompt_cache import PromptCache
from obra.hybrid.derivation.prompt_rpc_client import DerivationPromptRPCClient
from obra.hybrid.prompt_enricher import PromptEnricher

logger = logging.getLogger(__name__)

WORK_TYPES_NEEDING_EXPLORATION = [
    "feature_implementation",
    "refactoring",
    "integration",
]


class DerivationPromptBuilder:
    """RPC-backed facade used by :class:`DerivationEngine`.

    The builder is instantiated as ``DerivationPromptBuilder(self)`` by the
    engine; this shim resolves:

    - ``ObraApiClient`` from ``owner._api_client`` (required);
    - :class:`PromptEnricher` against ``owner._working_dir``;
    - :class:`PromptCache` (shared default location).

    All builder methods delegate to the underlying
    :class:`DerivationPromptRPCClient`; both the per-step enrichment and the
    offline cache are implemented there. This class intentionally keeps no
    local prompt templates.
    """

    def __init__(self, owner: Any, *, cache: PromptCache | None = None) -> None:
        self._owner = owner
        self._cache = cache

    # -- lazy RPC client resolution ---------------------------------------------

    def _rpc_client(self) -> DerivationPromptRPCClient:
        if getattr(self, "_rpc_client_instance", None) is not None:
            return self._rpc_client_instance  # type: ignore[return-value]

        api_client = getattr(self._owner, "_api_client", None)
        if api_client is None:
            raise RuntimeError(
                "DerivationPromptBuilder requires owner._api_client "
                "(ADR-103: client fetches server-authored prompts via RPC)."
            )
        working_dir = getattr(self._owner, "_working_dir", None)
        if working_dir is None:
            working_dir = Path.cwd()
        enricher = PromptEnricher(Path(working_dir))
        cache = self._cache if self._cache is not None else PromptCache()
        client = DerivationPromptRPCClient(
            owner=self._owner,
            api_client=api_client,
            enricher=enricher,
            cache=cache,
        )
        self._rpc_client_instance = client  # type: ignore[attr-defined]
        return client

    # -- context-building helpers (unchanged, client-local) ---------------------

    def build_prompt(
        self,
        objective: str,
        context: dict[str, Any],
        constraints: dict[str, Any],
        work_type: str,
    ) -> str:
        """Single-shot convenience that routes through the server family."""
        context_section = self._owner._context_builder.build_context_section(context)
        setattr(self._owner, "_derivation_context_section", context_section)
        max_items = constraints.get("max_items", self._owner._max_items)
        constraint_lines: list[str] = []
        if max_items:
            constraint_lines.append(
                f"- Advisory: Aim for ~{max_items} plan items if they stay small "
                f"and testable; no hard cap—split oversized work instead of dropping items."
            )
        if constraints.get("scope_boundaries"):
            constraint_lines.append(
                f"- Scope boundaries: {', '.join(constraints['scope_boundaries'])}"
            )
        constraints_section = (
            ("\n".join(constraint_lines) + "\n") if constraint_lines else ""
        )
        spike_findings = constraints.get("spike_findings") if isinstance(
            constraints, dict
        ) else None
        return self._rpc_client().build_single_shot_prompt(
            work_type=work_type,
            objective=objective,
            constraints_section=constraints_section,
            context_section=context_section,
            spike_findings=spike_findings if isinstance(spike_findings, dict) else None,
        )

    @staticmethod
    def resolve_hierarchy_config(constraints: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve hierarchy configuration from config and constraints."""
        hierarchy: dict[str, Any] = {}
        try:
            config, _, _ = load_layered_config(include_defaults=True)
            hierarchy = config.get("derivation", {}).get("hierarchy", {}) or {}
        except Exception as exc:
            logger.warning(
                "Failed to load hierarchy config; defaulting to disabled: %s", exc
            )
            hierarchy = {}

        if constraints and isinstance(constraints.get("hierarchy"), dict):
            hierarchy = {**hierarchy, **constraints["hierarchy"]}

        if hierarchy.get("enabled"):
            required_keys = ["max_depth", "epic", "story", "task", "subtask"]
            missing = [key for key in required_keys if key not in hierarchy]
            if missing:
                msg = f"Hierarchy config missing required keys: {', '.join(missing)}"
                logger.error(msg)
                raise ValueError(msg)
        return hierarchy

    # -- per-step builder methods (all go through RPC) --------------------------

    def build_single_shot_prompt(
        self,
        work_type: str,
        objective: str,
        constraints_section: str,
        context_section: str,
        spike_findings: dict[str, Any] | None = None,
    ) -> str:
        setattr(self._owner, "_derivation_context_section", context_section)
        return self._rpc_client().build_single_shot_prompt(
            work_type=work_type,
            objective=objective,
            constraints_section=constraints_section,
            context_section=context_section,
            spike_findings=spike_findings,
        )

    def build_step1_prompt(
        self, objective: str, constraints: str, context: str
    ) -> str:
        setattr(self._owner, "_derivation_context_section", context)
        return self._rpc_client().build_step1_epics_only_prompt(
            objective=objective,
            constraints=constraints,
            context=context,
        )

    def build_step1_epics_only_prompt(
        self, objective: str, constraints: str, context: str
    ) -> str:
        return self.build_step1_prompt(objective, constraints, context)

    def build_step1_epics_template(self, story_range: str) -> dict[str, Any]:
        return self._rpc_client().build_step1_epics_template(story_range)

    def build_step2_prompt(self, objective: str, prose_from_step_1: str) -> str:
        return self._rpc_client().build_step2_prompt(
            objective=objective,
            prose_from_step_1=prose_from_step_1,
            story_range=get_derivation_story_range(),
            task_range=get_derivation_task_range(),
        )

    def build_step2_per_epic_prompt(
        self,
        *,
        objective: str,
        all_epics_prose: str,
        completed_epic_details: list[str],
        target_epic: str,
        target_epic_id: str,
        story_range: str,
        task_range: str,
        strict: bool = False,
        intent_markdown: str | None = None,
        exploration_context: str | None = None,
    ) -> str:
        return self._rpc_client().build_step2_per_epic_prompt(
            objective=objective,
            all_epics_prose=all_epics_prose,
            completed_epic_details=completed_epic_details,
            target_epic=target_epic,
            target_epic_id=target_epic_id,
            story_range=story_range,
            task_range=task_range,
            strict=strict,
        )

    def build_step2_per_epic_template(
        self, target_epic_id: str, story_range: str, task_range: str
    ):
        return self._rpc_client().build_step2_per_epic_template(
            target_epic_id=target_epic_id,
            story_range=story_range,
            task_range=task_range,
        )

    def build_step2_repair_prompt(
        self,
        *,
        objective: str,
        target_epic_id: str,
        incomplete_output: str,
        missing_stories: list[str],
    ) -> str:
        return self._rpc_client().build_step2_repair_prompt(
            objective=objective,
            target_epic_id=target_epic_id,
            incomplete_output=incomplete_output,
            missing_stories=missing_stories,
        )

    def build_step2_repair_template(
        self, target_epic_id: str, existing_stories: list[dict[str, str]]
    ):
        return self._rpc_client().build_step2_repair_template(
            target_epic_id=target_epic_id,
            existing_stories=existing_stories,
        )

    def build_step2_consolidation_prompt(
        self,
        *,
        objective: str,
        target_epic_id: str,
        current_output: str,
        story_count: int,
        story_range: str,
    ) -> str:
        return self._rpc_client().build_step2_consolidation_prompt(
            objective=objective,
            target_epic_id=target_epic_id,
            current_output=current_output,
            story_count=story_count,
            story_range=story_range,
        )

    def build_step3_prompt(self, prose_from_step_2: str) -> str:
        return self._rpc_client().build_step3_prompt(prose_from_step_2)

    def build_step3_per_epic_prompt(self, epic_prose: str, epic_id: str) -> str:
        return self._rpc_client().build_step3_per_epic_prompt(
            epic_prose=epic_prose, epic_id=epic_id
        )

    def build_step3_per_epic_prompt_strict(
        self,
        epic_prose: str,
        epic_id: str,
        expected_story_count: int,
        expected_task_count: int,
    ) -> str:
        return self._rpc_client().build_step3_per_epic_prompt_strict(
            epic_prose=epic_prose,
            epic_id=epic_id,
            expected_story_count=expected_story_count,
            expected_task_count=expected_task_count,
        )

    def build_refinement_prompt(
        self, prose_step2: str, violations: list[str]
    ) -> str:
        return self._rpc_client().build_refinement_prompt(
            prose_step2=prose_step2, violations=violations
        )


__all__ = ["DerivationPromptBuilder", "WORK_TYPES_NEEDING_EXPLORATION"]
