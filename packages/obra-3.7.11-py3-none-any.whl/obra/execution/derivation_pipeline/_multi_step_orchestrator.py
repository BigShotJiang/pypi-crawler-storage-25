"""Multi-step derivation orchestrator — coordinates step 1 / step 2 / step 3.

Extracted from DerivationSerializationService.derive_multi_step_plan to isolate
the multi-step orchestration logic from the serialization facade.
"""

from __future__ import annotations

import json
import logging
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from obra.config.llm import resolve_tier_config
from obra.exceptions import ObraError
from obra.hybrid.template_edit_pipeline import TemplateEditPipeline

from ._epic_parser import EpicParser
from ._plan_validator import PlanValidator

logger = logging.getLogger(__name__)

_STRUCTURAL_CONVERGENCE_REASON_CODES = frozenset(
    {
        "no_stories",
        "no_tasks",
        "no_tasks_for_story",
        "wrong_epic_ids",
        "orphan_tasks",
    }
)


def _engine_attr(name: str, default: Any) -> Any:
    """Resolve an attribute from the derivation engine module, if loaded."""
    import sys

    module = sys.modules.get("obra.execution.derivation")
    if module is None:
        return default
    return getattr(module, name, default)


def _validate_epic_convergence(
    text: str,
    epic_id: str,
    validator: Any,
) -> dict[str, Any] | None:
    """Return a convergence failure for one epic, if structural checks fail."""
    stories, tasks = validator.count_epic_story_task_ids(text, epic_id)
    reason_codes = validator.extract_reason_codes_for_epic(text, epic_id)
    structural_reasons = [
        code for code in reason_codes if code in _STRUCTURAL_CONVERGENCE_REASON_CODES
    ]
    if not structural_reasons:
        return None
    return {
        "epic_id": epic_id,
        "reason_codes": structural_reasons,
        "stories": stories,
        "tasks": tasks,
    }


@dataclass
class StepResult:
    """Intermediate result from a derivation step."""

    parsed_epics: list[dict[str, Any]] = field(default_factory=list)
    epics_prose: str = ""
    all_epic_details: list[str] = field(default_factory=list)
    plan_items: list[dict[str, Any]] = field(default_factory=list)
    tokens: int = 0
    items_produced: int = 0
    duration_ms: int = 0


class MultiStepOrchestrator:
    """Orchestrates the multi-step derivation pipeline.

    Coordinates the three derivation steps:
      1. Structure (epic extraction via LLM)
      2. Tasks (per-epic or one-shot task derivation)
      3. Serialize (parse, validate, refine)

    Extracted from ``DerivationSerializationService.derive_multi_step_plan``
    to keep the facade thin.
    """

    def __init__(
        self,
        owner: Any,
        serialization_service: Any,
        epic_parser: EpicParser,
        plan_validator: PlanValidator,
        epic_limits: Callable[[], tuple[int, int]],
    ) -> None:
        self._owner = owner
        self._serialization = serialization_service
        self._parser = epic_parser
        self._validator = plan_validator
        self._epic_limits = epic_limits

    def orchestrate_step1(
        self,
        objective: str,
        project_context: str,
        constraints: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> StepResult:
        """Step 1 — derive epic structure from the objective.

        Builds the step-1 prompt, invokes the LLM via TemplateEditPipeline,
        parses and normalises epics.

        Returns:
            StepResult with ``parsed_epics``, ``epics_prose``, ``tokens``,
            ``items_produced``, and ``duration_ms`` populated.
        """
        if progress_callback:
            progress_callback(
                "derivation_step_started",
                {"step": 1, "step_name": "structure"},
            )

        step1_start = time.perf_counter()
        heartbeat_stop = threading.Event()
        heartbeat_thread: threading.Thread | None = None
        if progress_callback:
            heartbeat_start = time.perf_counter()

            def _step1_heartbeat(
                _stop: threading.Event = heartbeat_stop,
                _start: float = heartbeat_start,
            ) -> None:
                while not _stop.wait(30.0):
                    progress_callback(
                        "derivation_step_heartbeat",
                        {
                            "step": 1,
                            "step_name": "structure",
                            "elapsed_s": int(time.perf_counter() - _start),
                        },
                    )

            heartbeat_thread = threading.Thread(target=_step1_heartbeat, daemon=True)
            heartbeat_thread.start()

        tokens1 = 0
        parsed_epics: list[dict[str, Any]] = []
        epics_prose = ""
        prose_step1 = ""
        items_step1 = 0
        try:
            resolve_tier = _engine_attr("resolve_tier_config", resolve_tier_config)
            pipeline_cls = _engine_attr("TemplateEditPipeline", TemplateEditPipeline)
            tier_config = resolve_tier(
                tier="fast",
                role="orchestrator",
                override_provider=provider,
            )
            llm_config = {
                "provider": provider,
                "model": tier_config.get("model"),
                "thinking_enabled": self._owner._thinking_enabled,
                "allowed_tools": ["Read", "Glob", "Grep", "Edit"],
            }

            story_range = "3-6"
            template = self._owner._prompt_builder.build_step1_epics_template(story_range)
            template_epics = template.get("epics") if isinstance(template, dict) else None
            min_epics = len(template_epics) if isinstance(template_epics, list) else 1

            def validator(content: dict) -> tuple[bool, str | None]:
                return self._parser.validate_step1_epics(content, min_epics)

            base_prompt = self._owner._build_step1_prompt(
                objective=objective,
                constraints=constraints,
                context=project_context,
            )
            pipeline = pipeline_cls(
                working_dir=self._owner._working_dir,
                action_name="derivation_step1",
                output_format="json",
                log_event=getattr(self._owner, "_log_event", None),
                production_logger=getattr(self._owner, "_production_logger", None),
            )
            data, metadata = pipeline.execute(
                base_prompt=base_prompt,
                template_content=template,
                validator=validator,
                fallback_fn=lambda: {"epics": []},
                llm_config=llm_config,
            )

            parsed_epics = self._parser.normalize_epics(data.get("epics", []))
            epics_prose = self._parser.render_epics_prose(parsed_epics) if parsed_epics else ""
            prose_step1 = epics_prose
            items_step1 = len(parsed_epics)
            tokens1 = metadata.get("tokens", 0)
        finally:
            if heartbeat_thread:
                heartbeat_stop.set()
                heartbeat_thread.join(timeout=5)

        step1_duration_ms = int((time.perf_counter() - step1_start) * 1000)

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 1,
                    "step_name": "structure",
                    "duration_ms": step1_duration_ms,
                    "items_produced": items_step1,
                    "prose": prose_step1,
                },
            )

        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 1,
                "step_name": "structure",
                "duration_ms": step1_duration_ms,
                "tokens": tokens1,
                "items_produced": items_step1,
            },
        )
        logger.debug("Step 1 (structure) completed: %d tokens", tokens1)

        return StepResult(
            parsed_epics=parsed_epics,
            epics_prose=epics_prose,
            tokens=tokens1,
            items_produced=items_step1,
            duration_ms=step1_duration_ms,
        )

    def orchestrate_step2(
        self,
        objective: str,
        step1_result: StepResult,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
        validation_intensity: str = "light",
    ) -> tuple[list[dict[str, Any]], int]:
        """Steps 2 and 3 — derive tasks and serialize the plan.

        Routes to per-epic or one-shot derivation based on epic count,
        validates convergence, then serializes and optionally refines.

        Args:
            objective: The derivation objective.
            step1_result: Output from ``orchestrate_step1``.
            provider: LLM provider string.
            progress_callback: Optional progress callback.
            validation_intensity: ``"none"``, ``"light"``, or ``"thorough"``.

        Returns:
            A 2-tuple of (plan_items, total_tokens_used_in_step2_and_step3).
        """
        parsed_epics = step1_result.parsed_epics
        epics_prose = step1_result.epics_prose

        # Step 2: derive tasks (per-epic or one-shot)
        prose_step2, all_epic_details, tokens2 = self._derive_tasks(
            objective=objective,
            parsed_epics=parsed_epics,
            epics_prose=epics_prose,
            provider=provider,
            progress_callback=progress_callback,
        )

        # Convergence validation (raises ObraError on failure)
        self._validate_convergence(
            parsed_epics=parsed_epics,
            all_epic_details=all_epic_details,
            prose_step2=prose_step2,
            progress_callback=progress_callback,
        )

        # Step 3: serialize plan items
        plan_items, tokens3 = self._serialize_plan(
            all_epic_details=all_epic_details,
            parsed_epics=parsed_epics,
            prose_step2=prose_step2,
            provider=provider,
            progress_callback=progress_callback,
        )

        # Validation and refinement
        plan_items, tokens_refine = self._validate_and_refine(
            plan_items=plan_items,
            prose_step2=prose_step2,
            provider=provider,
            validation_intensity=validation_intensity,
            progress_callback=progress_callback,
        )

        total_tokens = tokens2 + tokens3 + tokens_refine
        return plan_items, total_tokens

    # ------------------------------------------------------------------
    # Private helpers — extracted from orchestrate_step2
    # ------------------------------------------------------------------

    def _derive_tasks(
        self,
        objective: str,
        parsed_epics: list[dict[str, Any]],
        epics_prose: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[str, list[str], int]:
        """Step 2 — task derivation with per-epic vs one-shot routing.

        Returns:
            A 3-tuple of (prose_step2, all_epic_details, tokens).
        """
        if progress_callback:
            progress_callback(
                "derivation_step_started",
                {"step": 2, "step_name": "tasks"},
            )

        step2_start = time.perf_counter()
        epic_count = len(parsed_epics)
        use_per_epic = epic_count > 2
        if not parsed_epics:
            logger.warning(
                "No epics parsed from Step 1 JSON; using phased derivation with default epic scaffolding",
            )
            use_per_epic = False

        logger.info(
            "Complexity routing: %d epics -> %s mode",
            epic_count,
            "per-epic" if use_per_epic else "one-shot",
        )

        all_epic_details: list[str] = []
        if use_per_epic:
            prose_step2, all_epic_details, tokens2 = self._owner._derive_per_epic(
                objective=objective,
                epics_prose=epics_prose,
                parsed_epics=parsed_epics,
                provider=provider,
                progress_callback=progress_callback,
                intent_markdown=self._owner._intent_markdown,
                exploration_context=self._owner._exploration_context,
            )
        else:
            step2_prompt = self._owner._build_step2_prompt(
                objective=objective,
                prose_from_step_1=epics_prose,
            )
            prose_step2, tokens2 = self._owner._invoke_llm(
                prompt=step2_prompt,
                provider=provider,
                _work_type="feature_implementation",
            )

        step2_duration_ms = int((time.perf_counter() - step2_start) * 1000)
        items_step2 = prose_step2.count(".T")

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 2,
                    "step_name": "tasks",
                    "duration_ms": step2_duration_ms,
                    "items_produced": items_step2,
                    "prose": prose_step2,
                },
            )

        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 2,
                "step_name": "tasks",
                "duration_ms": step2_duration_ms,
                "tokens": tokens2,
                "items_produced": items_step2,
            },
        )
        logger.debug("Step 2 (tasks) completed: %d tokens", tokens2)

        return prose_step2, all_epic_details, tokens2

    def _validate_convergence(
        self,
        parsed_epics: list[dict[str, Any]],
        all_epic_details: list[str],
        prose_step2: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> None:
        """Validate structural convergence between step 1 epics and step 2 output.

        Raises:
            ObraError: When convergence validation finds structural failures.
        """
        convergence_failures: list[dict[str, Any]] = []
        if parsed_epics:
            if all_epic_details:
                if len(all_epic_details) != len(parsed_epics):
                    convergence_failures.append(
                        {
                            "epic_id": "unknown",
                            "reason_codes": ["missing_epic_details"],
                            "stories": len(all_epic_details),
                            "tasks": 0,
                        }
                    )
                for epic, epic_detail in zip(parsed_epics, all_epic_details, strict=False):
                    epic_id = str(epic.get("id", "")).strip()
                    if not epic_id:
                        continue
                    failure = _validate_epic_convergence(
                        epic_detail,
                        epic_id,
                        self._validator,
                    )
                    if failure is not None:
                        convergence_failures.append(failure)
            else:
                for epic in parsed_epics:
                    epic_id = str(epic.get("id", "")).strip()
                    if not epic_id:
                        continue
                    failure = _validate_epic_convergence(
                        prose_step2,
                        epic_id,
                        self._validator,
                    )
                    if failure is not None:
                        convergence_failures.append(failure)

        if convergence_failures:
            if progress_callback:
                progress_callback(
                    "derivation_convergence_failed",
                    {
                        "step": 2,
                        "step_name": "tasks",
                        "failures": convergence_failures,
                    },
                )
            failure = convergence_failures[0]
            raise ObraError(
                "Step 2 convergence failed before serialization for "
                f"{failure['epic_id']} (stories={failure['stories']}, tasks={failure['tasks']}, "
                f"reasons={','.join(failure['reason_codes'])})."
            )

    def _serialize_plan(
        self,
        all_epic_details: list[str],
        parsed_epics: list[dict[str, Any]],
        prose_step2: str,
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Step 3 — serialize derivation prose into structured plan items.

        Returns:
            A 2-tuple of (plan_items, tokens).
        """
        if progress_callback:
            progress_callback(
                "derivation_step_started",
                {"step": 3, "step_name": "serialize"},
            )

        step3_start = time.perf_counter()
        if all_epic_details and parsed_epics:
            plan_items, tokens3 = self._owner._serialize_per_epic(
                all_epic_details=all_epic_details,
                parsed_epics=parsed_epics,
                provider=provider,
                progress_callback=progress_callback,
            )
        else:
            step3_prompt = self._owner._build_step3_prompt(prose_from_step_2=prose_step2)
            plan_items = self._owner._parse_flat_response_via_pipeline(
                step3_prompt,
                provider,
            )
            tokens3 = len(step3_prompt) // 4 + len(json.dumps(plan_items)) // 4

        if not plan_items:
            recovered_items = self._recover_plan_items_from_step2(
                parsed_epics=parsed_epics,
                all_epic_details=all_epic_details,
                prose_step2=prose_step2,
            )
            if recovered_items:
                recovery_payload = {
                    "step": 3,
                    "step_name": "serialize",
                    "items_recovered": len(recovered_items),
                    "severity": "error",
                    "primary_path_status": "failed_empty_plan",
                    "recovery_source": "validated_step2_structure",
                    "operator_action_required": True,
                }
                logger.error(
                    "Step 3 serialization returned no plan items; recovered %d items "
                    "from Step 2 structure. Investigate the Step 3 primary path.",
                    len(recovered_items),
                    extra=recovery_payload,
                )
                if progress_callback:
                    progress_callback(
                        "derivation_serialization_recovered",
                        recovery_payload,
                    )
                plan_items = recovered_items
                tokens3 += len(json.dumps(recovered_items)) // 4
            else:
                raise ObraError(
                    "Step 3 serialization produced no plan items and Step 2 structure "
                    "could not be converted into a non-empty plan."
                )

        step3_duration_ms = int((time.perf_counter() - step3_start) * 1000)
        items_step3 = len(plan_items)

        if progress_callback:
            progress_callback(
                "derivation_step_completed",
                {
                    "step": 3,
                    "step_name": "serialize",
                    "duration_ms": step3_duration_ms,
                    "items_produced": items_step3,
                    "raw_json": json.dumps(plan_items),
                },
            )

        logger.debug(
            "derivation_step_completed",
            extra={
                "step": 3,
                "step_name": "serialize",
                "duration_ms": step3_duration_ms,
                "tokens": tokens3,
                "items_produced": items_step3,
            },
        )

        return plan_items, tokens3

    def _recover_plan_items_from_step2(
        self,
        *,
        parsed_epics: list[dict[str, Any]],
        all_epic_details: list[str],
        prose_step2: str,
    ) -> list[dict[str, Any]]:
        """Build structured plan items from validated Step 2 prose."""
        if not parsed_epics:
            return []

        details_by_epic: dict[str, str] = {}
        for epic, epic_detail in zip(parsed_epics, all_epic_details, strict=False):
            epic_id = str(epic.get("id", "")).strip()
            if epic_id and epic_detail:
                details_by_epic[epic_id] = epic_detail

        recovered_items: list[dict[str, Any]] = []
        for epic in parsed_epics:
            epic_id = str(epic.get("id", "")).strip()
            if not epic_id:
                continue
            epic_title = str(epic.get("title") or epic_id).strip()
            epic_description = str(epic.get("description") or epic_title).strip()
            epic_detail = details_by_epic.get(epic_id, prose_step2)
            stories, tasks = self._validator.extract_epic_story_task_titles(
                epic_detail,
                epic_id,
            )
            if not stories or not tasks:
                continue

            epic_items = self._serialization.build_partial_plan_items(
                epic_id,
                epic_title,
                stories,
                tasks,
            )
            for item in epic_items:
                title = str(item.get("title") or item.get("id") or "Untitled").strip()
                if item.get("id") == epic_id:
                    item["description"] = epic_description
                else:
                    item["description"] = title
                item.setdefault("acceptance_criteria", [])
                item.setdefault("dependencies", [])
            recovered_items.extend(epic_items)

        return recovered_items

    def _validate_and_refine(
        self,
        plan_items: list[dict[str, Any]],
        prose_step2: str,
        provider: str,
        validation_intensity: str = "light",
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Validate plan items and refine via LLM if violations are found.

        Returns:
            A 2-tuple of (plan_items, total_refinement_tokens).
        """
        total_refine_tokens = 0

        if validation_intensity == "none":
            logger.debug("Validation skipped (intensity=none)")
            return plan_items, total_refine_tokens

        max_passes = 2 if validation_intensity == "thorough" else 1
        pass_count = 0
        violations = self._owner._validate_plan_items(plan_items)

        while violations and pass_count < max_passes:
            pass_count += 1
            if progress_callback:
                progress_callback(
                    "derivation_validation_started",
                    {"pass": pass_count, "max_passes": max_passes},
                )

            logger.info(
                "Plan validation failed (pass %d/%d): %d violations",
                pass_count,
                max_passes,
                len(violations),
            )
            logger.debug("Violations: %s", violations)

            refinement_prompt = self._owner._prompt_builder.build_refinement_prompt(
                prose_step2, violations
            )
            try:
                plan_items = self._owner._parse_flat_response_via_pipeline(
                    refinement_prompt,
                    provider,
                )
                tokens_refine = len(refinement_prompt) // 4 + len(json.dumps(plan_items)) // 4
                total_refine_tokens += tokens_refine
                logger.debug(
                    "Refinement pass %d: estimated %d tokens",
                    pass_count,
                    tokens_refine,
                )

                violations = self._owner._validate_plan_items(plan_items)
                if progress_callback:
                    progress_callback(
                        "derivation_validation_completed",
                        {
                            "pass": pass_count,
                            "violations": len(violations),
                            "passed": len(violations) == 0,
                        },
                    )
                if not violations:
                    logger.info(
                        "Plan validation passed after %d refinement pass(es)",
                        pass_count,
                    )
                    break
            except Exception as exc:
                logger.warning("Refinement pass %d failed: %s", pass_count, exc)
                break

        if violations:
            logger.warning(
                "Plan validation failed after %d pass(es), using best-effort plan with %d violations",
                max_passes,
                len(violations),
            )

        return plan_items, total_refine_tokens
